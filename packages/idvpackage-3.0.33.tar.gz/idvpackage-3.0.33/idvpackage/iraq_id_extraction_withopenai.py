import base64
import json
import logging
import re
import time
from openai import OpenAI
from pydantic import BaseModel, Field

PROMPT_PASSPORT_IRQ = """
You are a strict extraction engine for Iraqi passport data pages (REGULAR and DIPLOMATIC).
Copy values physically printed on the document. Never invent, infer, or guess.

Inputs: OCR_TEXT (Google Vision, may have noise) + IMAGE (passport photo).

━━━ INPUT PRIORITY ━━━
• All fields : use OCR_TEXT as primary source, verify against image.
  If OCR is missing or clearly wrong, read the value DIRECTLY from the image.
  Every field listed below is physically present on the passport — never leave a field
  empty just because OCR missed it. If OCR has nothing, find it in the image.
• Always cross-verify every extracted value against the image before outputting.

━━━ HARD RULES ━━━
• Return "" ONLY if the field is genuinely not visible in either OCR or image.
• Never copy a value across fields.
• MRZ must be read from the image — do NOT reconstruct from data-page fields.
• occupation → "" on REGULAR passports. mother_name → "" on DIPLOMATIC passports.
• Fixed-length fields when visible: id_number=9 chars, mrz1=44 chars, mrz2=44 chars.

━━━ OCR FIXES (apply before storing) ━━━
• Label bleed: strip up to and including the last ":" or "/" on the line.
• Newline split: if value is missing, take the next line.
• Dates: normalise DD.MM.YYYY / DD-MM-YYYY / YYYY-MM-DD → DD/MM/YYYY.
• MRZ: strip spaces; fix 0↔O, 1↔I, 5↔S, 8↔B by positional context only, dont add or remove chars.
• MRZ character set is absolute: only uppercase A-Z, digits 0-9, and "<" are allowed. Replace any other character with "<".

━━━ STEP 1 — ocr_text ━━━
Copy OCR_TEXT verbatim. Do not modify.

━━━ STEP 2 — passport_type (determine FIRST) ━━━
Sub-heading below "REPUBLIC OF IRAQ" (left) confirmed by Arabic right side:
  "DIPLOMATIC PASSPORT" + جواز سفر دبلوماسي → "DIPLOMATIC"
  "PASSPORT"            + جواز السفر          → "REGULAR"
  Unreadable                                   → ""

━━━ STEP 3 — Centre bar fields ━━━
id_number: next to "Passport No / رقم الجواز".
  Pattern: exactly 1 letter + 8 digits (9 chars total). Strip spaces.
  Position [0]=letter, [1–8]=digits. Apply O↔0/I↔1 by position.
  Must match mrz2[0:9]. Return "" only if unresolvable to 9 chars.

issuing_country: next to "Country Code / رمز البلد". Transcribe as printed.
  Return "" if obscured — do NOT auto-fill.

━━━ STEP 4 — Personal details (left-column English labels) ━━━
Use Arabic right column only to resolve OCR ambiguity — not to invent values.

full_name:   "Full Name" — given names chain, uppercase, space-separated.
             Do NOT include surname. Return as printed (1–3 tokens).
last_name:   "Surname" — family/tribal name, uppercase. "" if blank.
gender_letter: "Sex" — "M" or "F" only. Primary: label "Sex / الجنس" in OCR.
             If OCR misses it, read directly from the image (look for M/F next to "Sex",
             or Arabic ذكر=M / أنثى=F). Do not infer from name alone. "" only if truly illegible.
nationality: "Nationality" — transcribe exactly as printed. "" if obscured.

━━━ STEP 5 — Conditional fields ━━━
occupation  [DIPLOMATIC ONLY]:
  "Occupation" / الوظيفة. Extract English value as printed.
  MUST be "" on REGULAR passports.

mother_name [REGULAR ONLY]:
  "Mother's Name" / اسم الأم. Extract English full name as printed.
  MUST be "" on DIPLOMATIC passports.

place_of_birth: "Place of Birth" / محل الميلاد. English city as printed.
  If English absent, transliterate from Arabic. "" if illegible.

issuing_authority: "Issuing Authority" / جهة الإصدار. English city as printed.
  If only Arabic visible, transliterate. "" if illegible.

━━━ STEP 6 — Dates ━━━
Output always DD/MM/YYYY. All three dates present on every passport.
Read from image if OCR missed. Sanity: day 01–31, month 01–12, dob < issue_date < expiry_date.
If data-page and MRZ dates differ, prefer data-page value.
  dob:         "Date of Birth"
  issue_date:  "Date of Issue"
  expiry_date: "Date of Expiry"

━━━ STEP 7 — MRZ ━━━
Two monospace lines at the bottom of the page.
Read BOTH lines from the IMAGE. Use OCR only as a secondary check.
Each line is EXACTLY 44 characters long.
Both MRZ lines may contain ONLY uppercase letters A-Z, digits 0-9, and the filler character "<".
No spaces, no punctuation, no unicode, no control characters, and no other symbols are ever allowed.
If any non-allowed character appears in your reading, replace it with "<" before output.

━━━ MRZ CHARACTER SET (ABSOLUTE) ━━━
The only characters that may ever appear in mrz1 or mrz2 are:
  • Uppercase letters A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
  • Digits 0 1 2 3 4 5 6 7 8 9
  • The filler character "<"
NOTHING ELSE IS PERMITTED — not null bytes (\u0000), not spaces, not newlines,
not any unicode character, not any control character, not any punctuation.
If you are about to output any character outside the above set, STOP and replace
it with "<" (the filler character). There are no exceptions.

━━━ PADDING (CRITICAL) ━━━
When a name zone or filler zone does not fill its allocated positions, you MUST
pad with the "<" character — never with anything else.
Procedure: write the content, then count the total characters output so far.
If count < 44, append "<" characters one by one until count == 44.
Do NOT use null bytes, zeros, or spaces as padding under any circumstances.

━━━ mrz1 (line 1) ━━━
Positions: [0]="P"  [1]="<"  [2–4]="IRQ"  [5–43]=name zone
Name zone format: SURNAME<<GIVEN1<GIVEN2<GIVEN3
  • Hyphens in names → "<"  (e.g. AL-NAEB → AL<NAEB)
  • Separator between surname and given names → "<<"
  • Separator between given names → "<"
  • After all name tokens are written, fill the rest of [5–43] with "<" until position [43].

━━━ mrz2 (line 2) ━━━
Positions: [0–8]=passport no  [9]=check digit  [10–12]="IRQ"
           [13–18]=DOB YYMMDD  [19]=check digit  [20]=sex (M or F)
           [21–26]=expiry YYMMDD  [27]=check digit  [28–42]=filler "<"  [43]=composite check digit
  • Pad positions [28–42] with "<" only. Never change position [43].

Derived from mrz2 (slice mechanically — do not re-read from data page):
  id_number_mrz:    mrz2[0:9]            → 9 chars exactly
  dob_mrz:          mrz2[13:19] YYMMDD  → DD/MM/YYYY (YY≥26→19YY, YY<26→20YY)
  expiry_date_mrz:  mrz2[21:27] YYMMDD  → DD/MM/YYYY (same rule)
  gender_mrz:       mrz2[20] "M"→"MALE", "F"→"FEMALE"

━━━ STEP 8 — header_verified ━━━
True if ANY of the following is visible in OCR or image:
  (a) "REPUBLIC OF IRAQ"
  (b) "جمهورية العراق" or "کۆماری عێراق" or "كوماری عێراق"
  (c) sub-heading "PASSPORT" or "DIPLOMATIC PASSPORT"
  (d) mrz1 starts with "P<IRQ"
False only if none of (a)–(d) are present.

━━━ OUTPUT ━━━
Single valid JSON object. No markdown. Absent/unreadable → "". Dates → DD/MM/YYYY.
mrz1/mrz2 → exactly 44 chars. id_number/id_number_mrz → exactly 9 chars.
"""


class IraqiPassport(BaseModel):
    ocr_text: str = Field(..., description="OCR_TEXT input copied verbatim. Do not modify.")

    passport_type: str = Field(
        default="",
        description=(
            "Sub-heading below 'REPUBLIC OF IRAQ': "
            "'DIPLOMATIC' if left reads 'DIPLOMATIC PASSPORT' / right shows 'جواز سفر دبلوماسي'; "
            "'REGULAR' if left reads 'PASSPORT' / right shows 'جواز السفر'. "
            "'' if unreadable. Determine FIRST — controls occupation vs mother_name."
        ),
    )

    full_name: str = Field(
        ...,
        description=(
            "English given names next to 'Full Name' — verbatim, UPPERCASE, space-separated. "
            "1–3 tokens (first + father + grandfather). Exclude surname (last_name). "
            "Use Arabic right column only to resolve OCR noise. '' if unreadable."
        ),
    )
    last_name: str = Field(
        default="",
        description=(
            "English surname next to 'Surname' — verbatim, UPPERCASE. "
            "'' if blank — many passports leave this empty."
        ),
    )
    gender_letter: str = Field(
        ...,
        description=(
            "'M' or 'F' from label 'Sex / الجنس'. "
            "Primary: OCR value next to 'Sex'. If OCR missed it, read from the image — "
            "look for M or F printed next to the Sex label, or Arabic ذكر→M / أنثى→F. "
            "Do not infer from name alone. '' only if genuinely illegible in both OCR and image."
        ),
    )
    nationality: str = Field(
        ...,
        description=(
            "Value next to 'Nationality' — transcribed exactly as printed. "
            "Do NOT auto-fill. '' if obscured."
        ),
    )
    issuing_country: str = Field(
        ...,
        description=(
            "Value next to 'Country Code' in the centre bar — transcribed exactly as printed. "
            "'' if obscured — do NOT auto-fill."
        ),
    )

    occupation: str = Field(
        default="",
        description=(
            "[DIPLOMATIC ONLY] English value next to 'Occupation' / الوظيفة. "
            "MUST be '' on REGULAR passports."
        ),
    )
    mother_name: str = Field(
        default="",
        description=(
            "[REGULAR ONLY] English full name next to \"Mother's Name\" / اسم الأم. "
            "MUST be '' on DIPLOMATIC passports."
        ),
    )
    place_of_birth: str = Field(
        ...,
        description=(
            "English city next to 'Place of Birth' / محل الميلاد — verbatim, UPPERCASE. "
            "Transliterate from Arabic/Kurdish if English absent. '' if illegible."
        ),
    )
    issuing_authority: str = Field(
        ...,
        description=(
            "English city next to 'Issuing Authority' / جهة الإصدار — verbatim, UPPERCASE. "
            "Transliterate from Arabic if only Arabic visible. '' if illegible."
        ),
    )

    dob: str = Field(
        ...,
        description=(
            "Date of birth from 'Date of Birth' → DD/MM/YYYY. "
            "Normalise DD.MM.YYYY / YYYY-MM-DD / DD-MM-YYYY. "
            "Sanity: day 01–31, month 01–12, must be before issue_date. '' if illegible."
        ),
    )
    issue_date: str = Field(
        ...,
        description=(
            "Date of issue from 'Date of Issue' → DD/MM/YYYY. "
            "Normalise any separator format. Must be after dob and before expiry_date. '' if illegible."
        ),
    )
    expiry_date: str = Field(
        ...,
        description=(
            "Date of expiry from 'Date of Expiry' → DD/MM/YYYY. "
            "Normalise any separator format. Must be after issue_date. '' if illegible."
        ),
    )

    id_number: str = Field(
        default="",
        pattern=r"^([A-Z][0-9]{8}|)$",
        description=(
            "Passport number next to 'Passport No / رقم الجواز' — EXACTLY 9 chars: "
            "1 uppercase letter + 8 digits. Strip spaces. "
            "Apply O↔0/I↔1 by position ([0]=letter, [1–8]=digits). "
            "Must match mrz2[0:9]. Never truncate. '' if unresolvable to 9 chars."
        ),
    )

    mrz1: str = Field(
        ...,
        min_length=44,
        max_length=44,
        description=(
            "MRZ line 1 — EXACTLY 44 chars. Read from image; OCR secondary. "
            "ONLY uppercase A–Z, digits 0–9, and '<' are allowed — NO null bytes, "
            "spaces, newlines, or any other character. If a position is unclear, "
            "cross-check image and OCR and replace with the correct A–Z/0–9/< char. "
            "[0]='P', [1]='<' (both REGULAR and DIPLOMATIC), [2–4]='IRQ', "
            "[5–43]=SURNAME<<GIVEN1<GIVEN2<GIVEN3 padded with '<'. "
            "Hyphens in names → '<'. "
            "PADDING: after writing names, count total characters; if < 44 append '<' "
            "until exactly 44. The ONLY valid padding character is '<' — never null bytes. "
            "Apply 0↔O/1↔I/5↔S/8↔B by position. Must return exactly 44 chars."
        ),
    )
    mrz2: str = Field(
        ...,
        min_length=44,
        max_length=44,
        description=(
            "MRZ line 2 — EXACTLY 44 chars. Read from image; OCR secondary. "
            "ONLY uppercase A–Z, digits 0–9, and '<' are allowed — NO null bytes, "
            "spaces, newlines, or any other character. If a position is unclear, "
            "cross-check image and OCR and replace with the correct A–Z/0–9/< char. "
            "[0–8]=passport no, [9]=check, [10–12]='IRQ', "
            "[13–18]=DOB YYMMDD, [19]=check, [20]=sex M/F, "
            "[21–26]=expiry YYMMDD, [27]=check, [28–42]=filler '<', [43]=composite check. "
            "Pad [28–42] with '<'. NEVER alter [43]. "
            "Apply 0↔O/1↔I/5↔S/8↔B by position. Must return exactly 44 chars."
        ),
    )

    id_number_mrz: str = Field(
        ...,
        min_length=9,
        max_length=9,
        description=(
            "Slice mrz2[0:9] mechanically — EXACTLY 9 chars. "
            "Do not re-read from data page. '' if mrz2 shorter than 9 chars."
        ),
    )
    dob_mrz: str = Field(
        ...,
        description=(
            "Slice mrz2[13:19] (YYMMDD) → DD/MM/YYYY mechanically. "
            "Century rule: YY≥26→19YY; YY<26→20YY. '' if mrz2 shorter than 19 chars."
        ),
    )
    expiry_date_mrz: str = Field(
        ...,
        description=(
            "Slice mrz2[21:27] (YYMMDD) → DD/MM/YYYY mechanically. Same century rule. "
            "'' if mrz2 shorter than 27 chars."
        ),
    )
    gender_mrz: str = Field(
        ...,
        description=(
            "mrz2[20]: 'M'→'MALE', 'F'→'FEMALE'. Slice mechanically. "
            "'' if mrz2 shorter than 21 chars or char not M/F."
        ),
    )

    header_verified: bool = Field(
        ...,
        description=(
            "True if ANY of these is visible in OCR or image: "
            "(1) 'REPUBLIC OF IRAQ', "
            "(2) 'جمهورية العراق' or 'کۆماری عێراق'/'كوماری عێراق', "
            "(3) sub-heading 'PASSPORT' or 'DIPLOMATIC PASSPORT', "
            "(4) mrz1 starts with 'P<IRQ'. "
            "False only if none of (1)–(4) are present."
        ),
    )



PROMPT_FRONT_IRQ = """
You are an expert extraction engine for Iraqi National ID cards.
You receive two inputs: OCR TEXT (raw text from Google Vision API) and the card IMAGE.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
HOW TO USE INPUTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Use OCR TEXT as your primary source for all fields.
• Always cross-check every field against the IMAGE.
• If the image shows a clearer or more complete value than OCR → use the image.
• Never leave a field empty if its value is visible in the image.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FIELD LABELS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Each field is identified by its Arabic/Kurdish label. Extract the value that follows the label.

  الاسم   / ناو         → first_name
  الأب    / باوك        → father_name
  الجد    / بابير       → third_name        (paternal grandfather — FIRST occurrence)
  اللقب   / نازناو      → last_name         (tribal/family name — often blank)
  الأم    / دابك / دايك → mother_first_name
  الجد    / بابير       → mother_last_name  (maternal grandfather — SECOND occurrence)
  الجنس   / ردگار       → gender
  فصيلة الدم / خووی خوون → blood_type
  البطاقة الوطنية        → id_number (12 digits)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 1 — RECORD OCR TEXT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Copy the OCR TEXT verbatim into the `ocr_text` field. Do not modify it.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 2 — EXTRACT NAME FIELDS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Locate each label in the OCR text and extract the value after it.

OCR NOISE — fix these problems before storing any name:

  1. LABEL BLEED: OCR merges label text with the value on the same line.
     The real value always comes after the last colon (:) or slash (/) on the line.
       "الاسم الار: میثم"    → میثم
       "الام اديك : انعام"  → انعام
       "الجد ابايير : صباح" → صباح

  2. NEWLINE SPLIT: The value is on the line after the colon.
     If nothing remains after stripping the label, look at the next \n-delimited line.
       "باير:\nمجید"  → مجید

  3. SPACE IN NAME — MANDATORY TWO-SOURCE CHECK:
     If OCR gives a value that contains a space, execute this exact process before storing:

     a) NOTE what OCR says — e.g. "ده رباز" (space present).
     b) LOOK at the IMAGE at that field's position. Read the printed characters directly.
        Do the printed characters show a visible gap between two distinct words,
        or do they run together as one continuous word with no gap?
     c) DECIDE based on BOTH sources:
        • If image shows a clear visible gap → keep the space (two separate words).
        • If image shows the characters run together (no gap) → remove the space and
          treat as a single word (OCR falsely split one word into two).
        • If image is ambiguous → remove the space (OCR-split errors are far more common
          than real two-part Arabic/Kurdish first names).
     d) STORE the image-verified value (with or without space based on step c).

     OCR commonly splits one Arabic/Kurdish word into two — e.g. "ده رباز" should be
     "دهرباز". Always verify with the image before accepting any space in a name.

  4. MISSING CHARACTER or EMPTY: If OCR value looks wrong or is missing entirely,
     read the name directly from the image.

  RULE: After extracting each name, ALWAYS verify the final Arabic value against the
  IMAGE before storing it. Store exactly what the image shows.

  NOTE on last_name: اللقب / نازناو is optional — many cards leave it blank.
  OCR often misreads the label itself as "الزناو", "تازناو", "ئازناو" — these are
  label artefacts, NOT the name value. Return "" if no real value is present.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 3 — TRANSLITERATE NAMES TO ENGLISH
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Produce the English transliteration for every non-empty Arabic/Kurdish name field.
Output MUST be UPPERCASE. Every non-empty Arabic field MUST produce a non-empty _en field.

CRITICAL — TRANSLITERATE ONLY THE IMAGE-VERIFIED SPELLING:
  In STEP 2 you already verified each name against the image and resolved any spaces.
  Use THAT verified Arabic value as the input to transliteration — not the raw OCR.
  If the verified value has no space (one word), transliterate it as one word.
  If the verified value has a space (two words), transliterate each word separately.
  Never transliterate a space that the image did not confirm.

Use Iraqi passport romanisation standard. Apply these rules in order:

1. VOWELS — the most important rules:
   Long ا  after a consonant  → A
   Long و  after a consonant  → OO
   Long ي  after a consonant  → EE
   ى  at word end             → A
   Diphthong ـيْ or ـاي       → AI
   Diphthong ـاو or ـوْ       → AW
   Short vowel (no letter)    → A    (default between two consonants)

2. SILENT LETTERS:
   ع at word start  → omit ع, write only the vowel that follows
   ع mid/end-word   → omit silently
   ة at word end    → A
   اء at word end   → AA

3. WORD-END ي → I

4. DEFINITE ARTICLE:
   ال → AL  attached to the stem, no hyphen
   عبد+ال compounds → ABDUL  (عبدالرحمن→ABDULRAHMAN, عبدالكريم→ABDULKAREEM)
   عبدالله → ABDULLAH  (fixed spelling)

5. TRIBAL NAMES (last_name only):
   Always start with AL. Ending pattern determines the suffix:
   ـوري → OURI    ـيدي → EIDI    ـيني → EINI
   ـيمي → EIMI    ـيشي → AYSHI   ـاري → ARI
   For any other ending, apply rules 1–3 to the stem after AL.

6. KURDISH NAMES: use standard Kurdish Latin transcription.
   چ→CH, ژ→ZH, ڤ→V, پ→P, گ→G, ێ→EE, ۆ→O, ئ→vowel only.

FINAL CHECK — before writing output:
   Every _en field must be non-empty if its Arabic counterpart is non-empty.
   If any _en is empty while Arabic is not, go back and fill it now.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 4 — GENDER
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Read gender only from the label "الجنس" / "ردگار". Do NOT infer from name or photo.
  ذكر (variants: ذکر, ذکور, ركاز) → gender_ar = "ذكر",  gender = "Male"
  أنثى (variants: ئێمه, مؤنث)     → gender_ar = "أنثى", gender = "Female"
If missing or unreadable → return "" for both.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 5 — DOCUMENT NUMBERS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
id_number (12 digits):
  • Strip all spaces from the candidate. Must be exactly 12 digits.
  • Correct OCR errors: O↔0, I↔1, l↔1. Use image if OCR value is wrong.
  • Return "" if not resolvable to exactly 12 digits.

card_number (9 characters):
  Pattern: 1 uppercase letter + 8 digits (e.g. G87187836, H32878911).
  Some cards use 2 uppercase letters + 7 digits (e.g. AY6907464).
  Total length is always exactly 9 characters.

  Extraction order:
    1. Split OCR text by \n, strip spaces on each line, and scan EVERY line for
       a token matching [A-Z]{1,2}[0-9]{7,8} with total length = 9.
    2. ⚠ OCR frequently misses this field. If not found in OCR, you MUST look at
       the image. The card_number is printed in the lower-left area of the card,
       directly below the photo, as a standalone unlabelled token. Read it
       character by character from the image.

  OCR corrections: O↔0, I↔1, l↔1 (first 1–2 chars must be letters, rest digits).

  Do NOT confuse with:
    • 12-digit id_number (البطاقة الوطنية) — entirely different field
    • 6-digit serial_number — shorter, all digits
    • 3-letter tokens IRQ / IRO / TRO — noise, ignore

  Return "" only if the token is invisible in both OCR and image.

serial_number (6 digits):
  • Strip all spaces from the candidate. Must be exactly 6 digits.
  • Correct OCR errors: O↔0, I↔1, l↔1. Use image if OCR value is wrong.
  • Return "" if not resolvable to exactly 6 digits.

blood_type:
  • Always present on every Iraqi ID. Read from OCR, verify against image.
  • Valid values: A+, A-, B+, B-, AB+, AB-, O+, O-
  • Common OCR errors: "0+" → O+,  "8+" → B+,  "A8+" → AB+,  bare "0"/"O" → check image.
  • If OCR has only the sign (+ or -) without the letter → read full value from image.
  • Return "" only if completely illegible in both OCR and image.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 6 — HEADER VERIFICATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Set header_verified = true if OCR or image contains ANY of:
  "جمهورية العراق"  "وزارة الداخلية"  "مديرية الأحوال المدنية"
  "كوماری عێراق"   "کوماری عیراق"    "وه‌زاره‌تی ناوخۆ"   "پارێزگای"
Set header_verified = false if none appear.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ABSOLUTE RULES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Never guess or hallucinate a value.
• If a field is absent or unreadable → return "".
• Do NOT merge fields or copy a value across fields.
• Output MUST be a single valid JSON object — no markdown, no commentary.
"""


PROMPT_BACK_IRQ = """
You are an expert extraction engine for the BACK side of an Iraqi National ID card.
You receive two inputs: OCR TEXT (raw text from Google Vision API) and the card IMAGE.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
HOW TO USE INPUTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Use OCR TEXT as your primary source for all fields.
• Always cross-check every field against the IMAGE.
• If the image shows a clearer or more complete value than OCR → use the image.
• Never leave a field empty if its value is visible in the image.

Common OCR problems on the back side — fix before storing:
  • Label bleed: strip everything up to and including the last colon (:) or slash (/)
  • Spaces inside numbers: strip all spaces from numeric/alphanumeric values
  • Date separators misread as letters (e.g. "2022O4O12" → "2022/04/12")
  • Dropped characters in long codes: recover from image

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FIELD LABELS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  جهة الإصدار   / ئەلبئی درچوون   → issuing_authority
  تاريخ الإصدار / رووی درچوون     → issue_date
  تاريخ النفاذ  / رووی بەسرچوون   → expiry_date
  محل الإصدار   / شوێنی درچوون    → place_of_issue
  تاريخ الولادة / رووی لەداک بوون → dob
  محل الولادة   / شوێنی لەداک بوون → place_of_birth
  الرقم العائلي / ژمارەی خێزانی   → family_number (18-char alphanumeric)

  MRZ — 3 lines at the bottom, each exactly 30 characters:
    mrz1: starts with "IDIRQ"
    mrz2: encodes DOB, gender, expiry
    mrz3: surname << given names

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 1 — RECORD OCR TEXT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Copy the OCR TEXT verbatim into the `ocr_text` field. Do not modify it.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 2 — DATES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
All dates MUST be output as DD/MM/YYYY.
Convert any format you find: YYYY/MM/DD, YYYY-MM-DD, DD.MM.YYYY → DD/MM/YYYY.
All three dates (issue_date, expiry_date, dob) are always present on every card.
If OCR missed one, read it from the image.
Return "" only if genuinely illegible in both OCR and image.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 3 — TEXT FIELDS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
issuing_authority: Extract Arabic text exactly as printed. Cross-check with image.

issuing_authority_en: Translate to English using your knowledge.
  مديرية الأحوال المدنية → "Civil Status Directorate"
  مديرية الجنسية والمعلومات المدنية → "Directorate of Nationality and Civil Information"
  Append the city name if present in the Arabic text. Do not invent a city.
  MUST be non-empty if issuing_authority is non-empty.

place_of_issue: Extract Arabic text exactly as printed. Return "" if absent.

place_of_issue_en: Translate or transliterate to English.
  Use well-known English city names where applicable (Baghdad, Basra, Mosul, Erbil,
  Kirkuk, Najaf, Karbala, Sulaymaniyah, Nineveh, etc.).
  MUST be non-empty if place_of_issue is non-empty.

place_of_birth: Extract Arabic text exactly as printed. Cross-check with image.

place_of_birth_en: Translate every part to English. No Arabic characters in output.
  May be compound e.g. "بعشيقة - موصل - نينوى" → "Bashiqa - Mosul - Nineveh".
  Preserve " - " separators. Use your knowledge for city names; transliterate unknowns.
  MUST be non-empty if place_of_birth is non-empty.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 4 — FAMILY NUMBER
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
family_number is ALWAYS present on every Iraqi ID back side — never skip it.
It is an 18-character alphanumeric code (digits + uppercase letters, e.g. "1004E1420215000000").

  1. Read from OCR, strip all spaces.
  2. Always cross-check against the image — use image value if clearer.
  3. Must be exactly 18 characters after stripping spaces.
     If 17 chars: one character was dropped — recover it from the image.
     If still not 18 → return "".
  Common OCR errors: O↔0, I↔1, S↔5, B↔8 — resolve using image.

family_number_en: same value as family_number (not translatable).

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 5 — MRZ
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Each MRZ line is exactly 30 characters. Allowed: A–Z, 0–9, and "<" ONLY. No spaces.
Pad with < at the END if shorter (except mrz2: pad BEFORE the last check digit).
Return "" for any line completely absent from both OCR and image.

⚠ STRICT CHARACTER RULE: MRZ may contain ONLY uppercase A–Z, digits 0–9, and "<".
  Any other character — including null bytes (\u0000), newlines, spaces, punctuation,
  or any unicode character — is STRICTLY FORBIDDEN.
  If your reading contains such a character, cross-check that position against the
  IMAGE and OCR, then replace it with the correct A–Z/0–9/< character.
  Never output a null byte, control character, or any non-ASCII character in MRZ.

mrz1: starts with "IDIRQ". Document number is at positions 5–13 (0-indexed).
mrz2: positions 0–5=DOB(YYMMDD), 7=gender(M/F), 8–13=expiry(YYMMDD), 15–17="IRQ".
mrz3: surname << given names.

Common OCR errors in MRZ: 0↔O, 1↔I, 5↔S, 8↔B — use position context to resolve.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 6 — FIELDS DERIVED FROM MRZ
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
card_number_mrz: characters 5–13 of mrz1. Return "" if mrz1 too short.

dob_mrz: characters 0–5 of mrz2 (YYMMDD) → DD/MM/YYYY.
  YY ≥ 26 → 19YY,  YY < 26 → 20YY. Return "" if mrz2 empty.

expiry_date_mrz: characters 8–13 of mrz2 (YYMMDD) → DD/MM/YYYY. Same year rule.

gender_mrz: character 7 of mrz2. Return "M" or "F". Return "" if absent.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 7 — HEADER VERIFICATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Set header_verified = true if mrz1 starts with "IDIRQ" OR OCR contains "IDIRQ".
Set header_verified = false otherwise.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ABSOLUTE RULES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Never guess or hallucinate a value.
• If a field is absent or unreadable → return "".
• Do NOT merge fields or copy a value across fields.
• Output MUST be a single valid JSON object — no markdown, no commentary.
"""


class IraqNationalIDFront(BaseModel):
    """
    Structured extraction for the FRONT side of an Iraqi National ID card.
    The front side contains personal names (patronymic chain), gender, blood type,
    the 12-digit national ID number, the 9-character document/card number, and
    a 6-digit serial number printed vertically on the card edge.
    It does NOT contain any dates — those are on the back side.
    """

    # ── Raw OCR ──────────────────────────────────────────────────────────────
    ocr_text: str = Field(
        ...,
        description=(
            "OCR_TEXT input copied verbatim. Do not modify, trim, or reformat it."
        ),
    )

    # ── Personal name fields (Arabic/Kurdish) ────────────────────────────────
    first_name: str = Field(
        ...,
        description=(
            "Person's own first name in Arabic or Kurdish, exactly as printed next to "
            "label 'الاسم' or 'ناو'. "
            "Apply label-bleed fix: strip everything up to and including the last ':' or '/'. "
            "Apply space-in-name check: if OCR gives a space, verify against the image — "
            "keep the space only if image shows a clear visible gap, otherwise remove it. "
            "Return '' if genuinely absent or unreadable."
        ),
    )
    first_name_en: str = Field(
        ...,
        description=(
            "first_name transliterated to English UPPERCASE using Iraqi passport romanisation. "
            "Transliterate the image-verified Arabic spelling — not raw OCR. "
            "MUST be non-empty whenever first_name is non-empty."
        ),
    )
    father_name: str = Field(
        ...,
        description=(
            "Father's first name in Arabic or Kurdish, exactly as printed next to "
            "label 'الأب' or 'باوك'. "
            "Apply same label-bleed and space-in-name fixes as first_name. "
            "Return '' if genuinely absent or unreadable."
        ),
    )
    father_name_en: str = Field(
        ...,
        description=(
            "father_name transliterated to English UPPERCASE using Iraqi passport romanisation. "
            "MUST be non-empty whenever father_name is non-empty."
        ),
    )
    third_name: str = Field(
        ...,
        description=(
            "Paternal grandfather's first name in Arabic or Kurdish, exactly as printed next to "
            "the FIRST occurrence of 'الجد' or 'بابير'. "
            "Apply same label-bleed and space-in-name fixes as first_name. "
            "Return '' if genuinely absent or unreadable."
        ),
    )
    third_name_en: str = Field(
        ...,
        description=(
            "third_name transliterated to English UPPERCASE using Iraqi passport romanisation. "
            "MUST be non-empty whenever third_name is non-empty."
        ),
    )
    last_name: str = Field(
        default="",
        description=(
            "Family or tribal name in Arabic or Kurdish, next to label 'اللقب' or 'نازناو'. "
            "OPTIONAL — many cards leave this blank. "
            "OCR often misreads the label itself as 'الزناو', 'الزنار', 'تازناو', 'ئازناو' — "
            "these are corrupted label artefacts, NOT the field value. "
            "Return '' if no actual family name value is present after excluding label noise."
        ),
    )
    last_name_en: str = Field(
        default="",
        description=(
            "last_name transliterated to English UPPERCASE using Iraqi passport romanisation. "
            "Tribal names always start with AL (e.g. 'الحمداني' → 'ALHAMDANI'). "
            "MUST be non-empty whenever last_name is non-empty. "
            "Return '' only if last_name is empty."
        ),
    )
    mother_first_name: str = Field(
        ...,
        description=(
            "Mother's own first name in Arabic or Kurdish, exactly as printed next to "
            "label 'الأم', 'دابك', or 'دايك'. "
            "Apply same label-bleed and space-in-name fixes as first_name. "
            "Return '' if genuinely absent or unreadable."
        ),
    )
    mother_first_name_en: str = Field(
        ...,
        description=(
            "mother_first_name transliterated to English UPPERCASE using Iraqi passport romanisation. "
            "MUST be non-empty whenever mother_first_name is non-empty."
        ),
    )
    mother_last_name: str = Field(
        ...,
        description=(
            "Maternal grandfather's first name in Arabic or Kurdish, exactly as printed next to "
            "the SECOND occurrence of 'الجد' or 'بابير' — the one that appears after the mother's name row. "
            "Apply same label-bleed and space-in-name fixes as first_name. "
            "Return '' if genuinely absent or unreadable."
        ),
    )
    mother_last_name_en: str = Field(
        ...,
        description=(
            "mother_last_name transliterated to English UPPERCASE using Iraqi passport romanisation. "
            "MUST be non-empty whenever mother_last_name is non-empty."
        ),
    )

    # ── Gender ───────────────────────────────────────────────────────────────
    gender_ar: str = Field(
        ...,
        description=(
            "Gender in Arabic/Kurdish exactly as printed next to label 'الجنس' or 'ردگار'. "
            "Read from OCR, verify against image. Do NOT infer from name or photo. "
            "Accepted Arabic variants: ذكر / ذکر / ذکور / ركاز → store as 'ذكر'. "
            "Accepted female variants: أنثى / ئێمه / مؤنث → store as 'أنثى'. "
            "Return '' if missing or unreadable."
        ),
    )
    gender: str = Field(
        ...,
        description=(
            "English gender derived from gender_ar: "
            "'ذكر' → 'Male',  'أنثى' → 'Female'. "
            "Return '' if gender_ar is empty."
        ),
    )

    # ── Document numbers ─────────────────────────────────────────────────────
    id_number: str = Field(
        ...,
        description=(
            "12-digit National ID Number next to label 'البطاقة الوطنية', displayed prominently on the card. "
            "Primary source: OCR. Cross-check against image. "
            "Strip all spaces. Correct OCR errors: O↔0, I↔1, l↔1. "
            "Must be exactly 12 digits after cleaning. "
            "Return '' if not resolvable to exactly 12 digits."
        ),
    )
    card_number: str = Field(
        ...,
        description=(
            "9-character document number. Pattern: 1 uppercase letter + 8 digits "
            "(e.g. 'G87187836', 'H32878911'), or 2 uppercase letters + 7 digits (e.g. 'AY6907464'). "
            "Total length always exactly 9 characters. "
            "Step 1 (OCR): split OCR text by newline, strip spaces per line, scan every line "
            "for a token matching [A-Z]{1,2}[0-9]{7,8} with total length = 9. "
            "Step 2 (IMAGE fallback — use if OCR yields nothing): read the standalone unlabelled token "
            "printed in the lower-left area of the card directly below the photo, "
            "character by character from the image. "
            "OCR corrections: O↔0, I↔1, l↔1 (first 1–2 positions must be letters, remainder digits). "
            "Ignore 3-letter noise tokens: IRQ, IRO, TRO, ROH. "
            "Do NOT confuse with the 12-digit id_number or the 6-digit serial_number. "
            "Return '' only if invisible in both OCR and image."
        ),
    )
    serial_number: str = Field(
        default="",
        description=(
            "6-digit serial number printed vertically along the right edge of the card. "
            "Primary source: OCR. Strip all spaces. Correct OCR errors: O↔0, I↔1, l↔1. "
            "Must be exactly 6 digits after cleaning. "
            "Do NOT confuse with the 12-digit id_number or the 9-character card_number. "
            "Return '' if not resolvable to exactly 6 digits."
        ),
    )
    blood_type: str = Field(
        default="",
        description=(
            "Blood type next to label 'فصيلة الدم' or 'خووی خوون'. "
            "ALWAYS present on every Iraqi National ID — never skip this field. "
            "Valid values: A+, A-, B+, B-, AB+, AB-, O+, O-. "
            "Primary source: OCR. If OCR does not contain a recognisable blood type, "
            "read it from the image (bottom-left region near the blood group label). "
            "Correct OCR errors: '0+' → 'O+', 'o+' → 'O+', '8+' → 'B+', 'A8+' → 'AB+'. "
            "If OCR has only the sign (+ or -) without the letter, read the full value from the image. "
            "Return '' only if completely illegible in both OCR and image."
        ),
    )

    # ── Header verification ──────────────────────────────────────────────────
    header_verified: bool = Field(
        ...,
        description=(
            "True if OCR text or image contains AT LEAST ONE of the following strings: "
            "'جمهورية العراق', 'وزارة الداخلية', 'مديرية الأحوال المدنية', "
            "'كوماری عێراق', 'کوماری عیراق', 'وه‌زاره‌تی ناوخۆ', 'پارێزگای'. "
            "False if none appear. This confirms the document is an Iraqi National ID front."
        ),
    )

class IraqNationalIDBack(BaseModel):
    """
    Structured extraction for the BACK side of an Iraqi National ID card.
    The back side contains dates (issue, expiry, DOB), issuing authority,
    place of birth, the 18-character family number, and the 3-line MRZ zone.
    It does NOT contain personal names — those are on the front side (and MRZ line 3).
    """

    # ── Raw OCR ──────────────────────────────────────────────────────────────
    ocr_text: str = Field(
        ...,
        description=(
            "OCR_TEXT input copied verbatim. Do not modify, trim, or reformat it."
        ),
    )

    # ── Date fields ───────────────────────────────────────────────────────────
    issue_date: str = Field(
        ...,
        description=(
            "Date of issue in DD/MM/YYYY format, next to label 'تاريخ الإصدار' or 'رووی درچوون'. "
            "Convert any format found: YYYY/MM/DD, YYYY-MM-DD, DD.MM.YYYY → DD/MM/YYYY. "
            "All three dates are always present — if OCR missed it, read from the image. "
            "Return '' only if genuinely illegible in both OCR and image."
        ),
    )
    expiry_date: str = Field(
        ...,
        description=(
            "Date of expiry in DD/MM/YYYY format, next to label 'تاريخ النفاذ' or 'رووی بەسرچوون'. "
            "Convert any format found: YYYY/MM/DD, YYYY-MM-DD, DD.MM.YYYY → DD/MM/YYYY. "
            "All three dates are always present — if OCR missed it, read from the image. "
            "Return '' only if genuinely illegible in both OCR and image."
        ),
    )
    dob: str = Field(
        ...,
        description=(
            "Date of birth in DD/MM/YYYY format, next to label 'تاريخ الولادة' or 'رووی لەداک بوون'. "
            "Convert any format found: YYYY/MM/DD, YYYY-MM-DD, DD.MM.YYYY → DD/MM/YYYY. "
            "All three dates are always present — if OCR missed it, read from the image. "
            "Return '' only if genuinely illegible in both OCR and image."
        ),
    )

    # ── Issuing authority ─────────────────────────────────────────────────────
    issuing_authority: str = Field(
        ...,
        description=(
            "Issuing authority in Arabic exactly as printed next to label 'جهة الإصدار' or 'ئەلبئی درچوون'. "
            "Apply label-bleed fix: strip everything up to and including the last ':' or '/'. "
            "Cross-check with image. Return '' if missing or unreadable."
        ),
    )
    issuing_authority_en: str = Field(
        ...,
        description=(
            "issuing_authority translated to English. "
            "Use known translations: "
            "'مديرية الأحوال المدنية' → 'Civil Status Directorate', "
            "'مديرية الجنسية والمعلومات المدنية' → 'Directorate of Nationality and Civil Information'. "
            "Append the city name if present in the Arabic text — do NOT invent a city if absent. "
            "MUST be non-empty whenever issuing_authority is non-empty."
        ),
    )

    # ── Place of issue ────────────────────────────────────────────────────────
    place_of_issue: str = Field(
        default="",
        description=(
            "Place of issue in Arabic exactly as printed next to label 'محل الإصدار' or 'شوێنی درچوون'. "
            "Apply label-bleed fix. Return '' if absent or unreadable."
        ),
    )
    place_of_issue_en: str = Field(
        default="",
        description=(
            "place_of_issue translated or transliterated to English. "
            "Use well-known English city names where applicable "
            "(Baghdad, Basra, Mosul, Erbil, Kirkuk, Najaf, Karbala, Sulaymaniyah, Nineveh, etc.). "
            "MUST be non-empty whenever place_of_issue is non-empty. "
            "Return '' only if place_of_issue is empty."
        ),
    )

    # ── Place of birth ────────────────────────────────────────────────────────
    place_of_birth: str = Field(
        ...,
        description=(
            "Place of birth in Arabic exactly as printed next to label 'محل الولادة' or 'شوێنی لەداک بوون'. "
            "Apply label-bleed fix. Cross-check with image. Return '' if missing or unreadable."
        ),
    )
    place_of_birth_en: str = Field(
        ...,
        description=(
            "place_of_birth translated fully to English — no Arabic characters in output. "
            "May be compound: 'بعشيقة - موصل - نينوى' → 'Bashiqa - Mosul - Nineveh'. "
            "Preserve ' - ' separators. Use known city names; transliterate unknowns. "
            "MUST be non-empty whenever place_of_birth is non-empty."
        ),
    )

    # ── Family number ─────────────────────────────────────────────────────────
    family_number: str = Field(
        ...,
        description=(
            "18-character alphanumeric family number next to label 'الرقم العائلي' or 'ژمارەی خێزانی'. "
            "ALWAYS present on every Iraqi National ID back side — never skip this field. "
            "Contains digits and uppercase letters (e.g. '1004E1420215000000'). "
            "Step 1: read from OCR, strip all spaces. "
            "Step 2: always cross-check against the image — use image value if clearer. "
            "Must be exactly 18 characters after stripping. "
            "If 17 chars: one character was dropped — recover it from the image. "
            "Correct OCR errors: O↔0, I↔1, S↔5, B↔8 using image context. "
            "Return '' only if genuinely unresolvable to exactly 18 characters."
        ),
    )
    family_number_en: str = Field(
        ...,
        description=(
            "Same value as family_number — this is an alphanumeric code, not translatable. "
            "Return '' only if family_number is empty."
        ),
    )

    # ── MRZ lines ─────────────────────────────────────────────────────────────
    mrz1: str = Field(
        ...,
        description=(
            "MRZ line 1 — exactly 30 characters. "
            "ONLY uppercase A–Z, digits 0–9, and '<' are allowed — NO null bytes, "
            "spaces, newlines, or any other character. "
            "Starts with 'IDIRQ'. Document number is at positions 5–13 (0-indexed). "
            "Pad with '<' at END if the visible line is shorter than 30 chars. "
            "Correct OCR errors: 0↔O, 1↔I, 5↔S, 8↔B using positional context."
        ),
    )
    mrz2: str = Field(
        ...,
        description=(
            "MRZ line 2 — exactly 30 characters. "
            "ONLY uppercase A–Z, digits 0–9, and '<' are allowed — NO null bytes, "
            "spaces, newlines, or any other character. "
            "Positions (0-indexed): [0-5]=DOB(YYMMDD), [6]=DOB check digit, [7]=gender(M/F), "
            "[8-13]=expiry(YYMMDD), [14]=expiry check digit, [15-17]=nationality('IRQ'), "
            "[18-28]=filler '<', [29]=composite check digit. "
            "Pad with '<' in positions [18-28] only — never alter position [29]. "
            "Correct OCR errors: 0↔O, 1↔I, 5↔S, 8↔B using positional context."
        ),
    )
    mrz3: str = Field(
        ...,
        description=(
            "MRZ line 3 — exactly 30 characters. "
            "ONLY uppercase A–Z, digits 0–9, and '<' are allowed — NO null bytes, "
            "spaces, newlines, or any other character. "
            "Format: SURNAME<<GIVENNAMES, with '<' between name tokens and '<<' separating surname from given names. "
            "Pad with '<' at END if shorter than 30 chars. "
            "Correct OCR errors: 0↔O, 1↔I, 5↔S, 8↔B using positional context."
        ),
    )

    # ── Fields derived from MRZ ───────────────────────────────────────────────
    card_number_mrz: str = Field(
        ...,
        description=(
            "9-character document number derived mechanically from mrz1[5:14] (positions 5–13, 0-indexed). "
            "Do not re-read from the card — slice directly from the extracted mrz1 string. "
            "Return '' if mrz1 is empty or shorter than 14 characters."
        ),
    )
    dob_mrz: str = Field(
        ...,
        description=(
            "Date of birth decoded mechanically from mrz2[0:6] (YYMMDD) → DD/MM/YYYY. "
            "Century rule: YY ≥ 26 → 19YY;  YY < 26 → 20YY. "
            "Return '' if mrz2 is empty or too short."
        ),
    )
    expiry_date_mrz: str = Field(
        ...,
        description=(
            "Expiry date decoded mechanically from mrz2[8:14] (YYMMDD) → DD/MM/YYYY. "
            "Same century rule as dob_mrz. "
            "Return '' if mrz2 is empty or too short."
        ),
    )
    gender_mrz: str = Field(
        ...,
        description=(
            "Gender decoded mechanically from mrz2[7]: 'M' or 'F'. "
            "Return '' if mrz2 is empty or character at position 7 is neither M nor F."
        ),
    )

    # ── Header verification ───────────────────────────────────────────────────
    header_verified: bool = Field(
        ...,
        description=(
            "True if mrz1 starts with 'IDIRQ' OR the OCR text contains 'IDIRQ' anywhere. "
            "False otherwise. This confirms the document is an Iraqi National ID back side."
        ),
    )



def process_image_irq(side):
    if side == "front":
        prompt = PROMPT_FRONT_IRQ
        model = IraqNationalIDFront

    elif side == "back":
        prompt = PROMPT_BACK_IRQ
        model = IraqNationalIDBack

    elif side  == "page1":
        prompt = PROMPT_PASSPORT_IRQ
        model = IraqiPassport
    else:
        raise ValueError(
            "Invalid document side specified. Use 'front', 'back', or 'page1'."
        )

    return model, prompt


MRZ_ALLOWED_CHARACTERS = re.compile(r"[^A-Z0-9<]")


def sanitize_mrz_value(value, expected_length):
    if not value:
        return ""

    normalized_value = str(value).upper()
    normalized_value = MRZ_ALLOWED_CHARACTERS.sub("<", normalized_value)

    if len(normalized_value) < expected_length:
        normalized_value = normalized_value.ljust(expected_length, "<")
    elif len(normalized_value) > expected_length:
        normalized_value = normalized_value[:expected_length]

    logging.info(f"Original MRZ value: {value}")
    logging.info(f"Sanitized MRZ value: {normalized_value}")
    return normalized_value


def sanitize_irq_response_mrz(side, response_data):
    mrz_lengths_by_side = {
        "page1": {"mrz1": 44, "mrz2": 44},
    }

    for field_name, expected_length in mrz_lengths_by_side.get(side, {}).items():
        response_data[field_name] = sanitize_mrz_value(
            response_data.get(field_name, ""), expected_length
        )

    return response_data


def get_openai_response_irq(prompt: str, model_type, image: str, genai_key, ocr_text: str = None):
    # covert byte io to utf-8 string

    for attempt in range(3):
        try:
            client = OpenAI(api_key=genai_key)
            user_content = [
                {"type": "input_text", "text": prompt},
            ]
            if ocr_text:
                user_content.append({"type": "input_text", "text": f"OCR extracted text from the document:\n{ocr_text}"})
            user_content.append(
                {
                    "type": "input_image",
                    "image_url": f"data:image/jpeg;base64,{image}",
                    "detail": "high",
                }
            )
            response = client.responses.parse(
                model="gpt-5.4-mini",
                input=[
                    {
                        "role": "system",
                        "content": "You are an expert at extracting information from identity documents.",
                    },
                    {
                        "role": "user",
                        "content": user_content,
                    },
                ],
                text_format=model_type,
            )
            return response.output_parsed
        except Exception as e:
            logging.info(f"[ERROR] Attempt {attempt + 1} failed: {str(e)}")
            time.sleep(2)
    return None


def get_response_from_openai_irq(image, side, openai_key, ocr_text: str = None):
    logging.info(f"Processing Iraqi document side: {side}")
    image_bytes = base64.b64encode(image).decode("utf-8")
    try:
        model, prompt = process_image_irq(side)
    except ValueError as ve:
        logging.error(f"Error: {ve}")
        return {"error": str(ve)}
    logging.info(f"Using prompt for side and prompt {side} selected.{prompt[:50]}...")
    try:
        start_time = time.time()
        response = get_openai_response_irq(prompt, model, image_bytes, openai_key, ocr_text=ocr_text)
        elapsed_time = time.time() - start_time
        logging.info(f"OpenAI extraction took {elapsed_time:.2f} seconds")
    except Exception as e:
        logging.error(f"Error during OCR extraction: {e}")
        return {"error": "OCR extraction failed."}
    response_data = response.dict() if response else {}
    response_data = sanitize_irq_response_mrz(side, response_data)

    logging.info(
        f"Openai response: {json.dumps(response_data, ensure_ascii=False, indent=2)}"
    )
    return response_data