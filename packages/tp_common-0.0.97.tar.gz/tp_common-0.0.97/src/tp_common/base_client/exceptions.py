"""Исключения для базового HTTP клиента.

Иерархия исключений:

    TpException
    ├── ClientException                       # ошибки HTTP-клиента
    │   ├── ClientResponseErrorException      # ответ с кодом >= 400
    │   │   ├── ClientRequestErrorException   # 4xx (кроме 429)
    │   │   │   ├── ClientAuthorizationException  # 401, 403
    │   │   │   ├── ClientValidationException     # 400, 422
    │   │   │   └── ClientResourceNotFoundException  # 404
    │   │   ├── ClientTooManyRequestsException   # 429
    │   │   └── ClientServerErrorException       # 5xx
    │   │       ├── ClientInternalServerException # 500
    │   │       └── ClientServiceUnavailableException  # 502, 503, 504
    │   └── ClientNetworkErrorException          # нет ответа (сеть/соединение)
    │       ├── ClientConnectionException        # ошибка соединения
    │       ├── ClientTimeoutException           # таймаут
    │       ├── ClientProxyException             # ошибка прокси
    │       └── ClientDNSException               # ошибка DNS
    ├── ClientSessionNotOpenException           # сессия не открыта (совместимость: RuntimeError)
    └── ClientCookieJarNotSaveableException     # cookie jar не сохраняется (совместимость: RuntimeError)

У сетевых и прочих ошибок без HTTP-ответа в `status_code` для TpMiddleware передаётся 502 (BAD_GATEWAY).
"""

from __future__ import annotations

import uuid
from http import HTTPStatus

from tp_common.exceptions.exceptions import TpException


class ClientException(TpException):
    """Базовое исключение для всех ошибок клиента."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
        status_code: int | HTTPStatus | None = None,
        response_body: str | None = None,
        method: str | None = None,
        duration_ms: int | None = None,
        response_headers: dict[str, str] | None = None,
        trace_id: uuid.UUID | None = None,
    ) -> None:
        tp_status = HTTPStatus.BAD_GATEWAY if status_code is None else int(status_code)
        super().__init__(message, status_code=tp_status, trace_id=trace_id)
        self.url = url
        self.response_body = response_body
        self.method = method
        self.duration_ms = duration_ms
        self.response_headers = response_headers


class ClientSessionNotOpenException(TpException, RuntimeError):
    """Сессия не открыта: операция требует активной сессии (например cookies_to_bytes)."""

    def __init__(
        self,
        message: str = "Сессия не открыта: сначала выполните запрос внутри async with",
    ) -> None:
        super().__init__(message)


class ClientCookieJarNotSaveableException(TpException, RuntimeError):
    """Текущая cookie jar не поддерживает сохранение (например DummyCookieJar)."""

    def __init__(
        self,
        message: str = "Текущая cookie jar не поддерживает сохранение (например DummyCookieJar)",
    ) -> None:
        super().__init__(message)


class ClientResponseErrorException(ClientException):
    """Исключение при неуспешном HTTP статусе (>=400)."""


class ClientRequestErrorException(ClientResponseErrorException):
    """Базовое исключение для ошибок клиентского запроса (4xx, кроме 429)."""


class ClientAuthorizationException(ClientRequestErrorException):
    """Исключение при ошибке авторизации (401, 403)."""


class ClientValidationException(ClientRequestErrorException):
    """Исключение при ошибке валидации данных (400, 422)."""


class ClientResourceNotFoundException(ClientRequestErrorException):
    """Исключение при отсутствии ресурса (404)."""


class ClientTooManyRequestsException(ClientResponseErrorException):
    """Исключение при превышении лимита запросов (429)."""


class ClientServerErrorException(ClientResponseErrorException):
    """Базовое исключение для ошибок сервера (500, 502, 503, 504)."""


class ClientInternalServerException(ClientServerErrorException):
    """Исключение при ошибке сервера (500)."""


class ClientServiceUnavailableException(ClientServerErrorException):
    """Исключение при недоступности сервиса (502, 503, 504)."""


class ClientNetworkErrorException(ClientException):
    """Базовое исключение для сетевых ошибок (ответ не получен: соединение, таймаут, прокси, DNS)."""


class ClientConnectionException(ClientNetworkErrorException):
    """Исключение при ошибке соединения (не удалось установить соединение)."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
        method: str | None = None,
        duration_ms: int | None = None,
    ) -> None:
        super().__init__(message, url, method=method, duration_ms=duration_ms)


class ClientTimeoutException(ClientNetworkErrorException):
    """Исключение при таймауте соединения."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
        method: str | None = None,
        duration_ms: int | None = None,
    ) -> None:
        super().__init__(message, url, method=method, duration_ms=duration_ms)


class ClientProxyException(ClientNetworkErrorException):
    """Исключение при ошибке прокси."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
        proxy: str | None = None,
        method: str | None = None,
        duration_ms: int | None = None,
    ) -> None:
        super().__init__(message, url, method=method, duration_ms=duration_ms)
        self.proxy = proxy


class ClientDNSException(ClientNetworkErrorException):
    """Исключение при ошибке DNS (не удалось разрешить доменное имя)."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
        method: str | None = None,
        duration_ms: int | None = None,
    ) -> None:
        super().__init__(message, url, method=method, duration_ms=duration_ms)


def get_response_exception_class(
    status_code: int,
) -> type[ClientResponseErrorException]:
    """Возвращает класс исключения для HTTP статус-кода (>=400)."""
    if status_code in (401, 403):
        return ClientAuthorizationException
    if status_code == 404:
        return ClientResourceNotFoundException
    if status_code in (400, 422):
        return ClientValidationException
    if status_code == 429:
        return ClientTooManyRequestsException
    if status_code == 500:
        return ClientInternalServerException
    if status_code in (502, 503, 504):
        return ClientServiceUnavailableException
    if 400 <= status_code < 500:
        return ClientRequestErrorException
    if status_code >= 500:
        return ClientServerErrorException
    return ClientResponseErrorException
