"""Поиск корня репозитория с ``alembic.ini`` и каталогом ``alembic``."""

from __future__ import annotations

from pathlib import Path

ALEMBIC_INI_MARKER = "alembic.ini"
ALEMBIC_DIR_MARKER = "alembic"


def is_alembic_project_root(path: Path) -> bool:
    return (path / ALEMBIC_INI_MARKER).is_file() and (
        path / ALEMBIC_DIR_MARKER
    ).is_dir()


def discover_alembic_project_root(*, library_fallback_root: Path | None = None) -> Path:
    """Ищет от ``cwd``, затем от ``library_fallback_root`` (по умолчанию — каталог этого модуля)."""
    cwd = Path.cwd().resolve()
    for candidate in (cwd, *cwd.parents):
        if is_alembic_project_root(candidate):
            return candidate

    fb = (
        library_fallback_root
        if library_fallback_root is not None
        else Path(__file__).resolve().parent
    )
    for candidate in (fb, *fb.parents):
        if is_alembic_project_root(candidate):
            return candidate

    raise RuntimeError(
        "Не удалось определить корень проекта: ожидаются alembic.ini и каталог alembic. "
        "Передайте project_root явно.",
    )
