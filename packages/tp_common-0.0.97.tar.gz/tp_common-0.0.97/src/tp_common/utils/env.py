"""Вспомогательные функции для .env без внешних зависимостей (поиск файла, merge в os.environ)."""

from __future__ import annotations

import os
from pathlib import Path


def find_env_file(*, anchor: Path | None = None) -> str | None:
    """
    Ищет ``.env``: сначала в текущей директории, затем (если задан ``anchor``)
    в каталоге файла ``anchor`` и во всех родителях. Первый найденный путь.
    """
    candidates: list[Path] = [Path.cwd()]
    if anchor is not None:
        here = anchor.resolve()
        candidates.append(here.parent)
        candidates.extend(here.parents)

    seen: set[Path] = set()
    for base in candidates:
        if base in seen:
            continue
        seen.add(base)
        env_path = base / ".env"
        if env_path.exists() and env_path.is_file():
            return str(env_path)
    return None


def load_env_file(path: str) -> None:
    """
    Минимальный разбор .env:
    строки ``KEY=VALUE``, кавычки ``"..."`` / ``'...'``, ``#`` и пустые строки пропускаются.
    В ``os.environ`` пишет только через ``setdefault`` (не перезаписывает уже заданные переменные).
    """
    try:
        text = Path(path).read_text(encoding="utf-8")
    except OSError:
        return
    for line in text.splitlines():
        raw = line.strip()
        if not raw or raw.startswith("#") or "=" not in raw:
            continue
        key, value = raw.split("=", 1)
        key = key.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        os.environ.setdefault(key, value)
