from .exceptions import TpException

__all__ = ["TpException"]
