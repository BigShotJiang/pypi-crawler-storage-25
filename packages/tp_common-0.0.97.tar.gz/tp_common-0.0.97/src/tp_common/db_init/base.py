"""Базовый сценарий инициализации БД: один sync Engine, Redis, состояние, стандарт schema+CDC."""

from __future__ import annotations

from abc import abstractmethod
from pathlib import Path

from redis.asyncio import Redis

from tp_common.db_init.debezium import DebeziumInit
from tp_common.db_init.migration import DbInitMigration
from tp_common.redis.system_state_service import SystemState, SystemStateService
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger
from tp_common.utils import discover_alembic_project_root


class BaseDbInit:
    """Общие зависимости и **стандартный** шаг :py:meth:`run_schema_and_cdc` (Alembic и опционально Debezium).

    ``redis_client`` и ``service_name`` — для :class:`SystemStateService`. ``MAINTENANCE`` перед
    накатом выставляет ``DbInitMigration``. ``NORMAL`` после успеха сюда не пишется (его
    выставляет API при старте).

    В конструктор передаются ``db_url`` (async PostgreSQL URL) и ``environment`` (тип окружения).
    Корень репозитория с Alembic — :func:`tp_common.utils.discover_alembic_project_root`.
    ``run_debezium`` (по умолчанию ``True``) можно отключить, оставив только миграции.

    Точка входа — :py:meth:`run`: сначала ``run_schema_and_cdc``, затем :py:meth:`start`
    (переопределите в подклассе). Ошибка в ``start`` логируется отдельно; любая ошибка
    схемы или ``start`` — ``NORMAL`` в Redis; в ``finally`` — ``redis_client.aclose()``.
    """

    def __init__(
        self,
        *,
        logger: TpLogger,
        redis_client: Redis,
        service_name: str,
        db_url: str,
        environment: EnvironmentType,
        run_debezium: bool = True,
        debezium_schema: str = "public",
        debezium_file_pattern: str = "src/domain/**/event.py",
    ) -> None:
        """
        :param logger: логгер сервиса.
        :param redis_client: async-клиент Redis для :class:`SystemStateService`.
        :param service_name: префикс ключа состояния в Redis.
        :param db_url: async URL PostgreSQL (как в конфиге приложения).
        :param environment: тип окружения (логирование/поведение сервиса).
        :param run_debezium: выполнять ли шаг Debezium после миграций.
        :param debezium_schema: схема PostgreSQL для ``REPLICA IDENTITY``.
        :param debezium_file_pattern: glob относительно :py:attr:`project_root` для поиска ``event.py``.
        """
        self.logger = logger
        self.redis_client = redis_client
        self.service_name = service_name
        self.db_url = db_url
        self.environment = environment
        self._project_root = discover_alembic_project_root(
            library_fallback_root=Path(__file__).resolve().parent,
        )
        self.run_debezium = run_debezium
        self._debezium_schema = debezium_schema
        self._debezium_file_pattern = debezium_file_pattern
        self.state_svc = SystemStateService(service_name, redis_client, logger)
        self.migration = self._build_migration()

    @property
    def project_root(self) -> Path:
        """Корень репозитория с ``alembic.ini`` (результат авто-поиска)."""
        return self._project_root

    def _build_migration(self) -> DbInitMigration:
        return DbInitMigration(
            logger=self.logger,
            state_svc=self.state_svc,
            db_url=self.db_url,
            project_root=self.project_root,
        )

    async def run_schema_and_cdc(self) -> None:
        """Стандарт: миграции Alembic; при ``run_debezium`` — ``REPLICA IDENTITY FULL`` (Debezium). Один Engine."""
        engine = self.migration.create_migration_engine()
        try:
            await self.migration.start(engine=engine)
            if self.run_debezium:
                DebeziumInit(self.logger, engine).start(
                    schema=self._debezium_schema,
                    source_dir=self.project_root,
                    file_pattern=self._debezium_file_pattern,
                )
        finally:
            engine.dispose()

    @abstractmethod
    async def run_after_start(self) -> None:
        """Обязательный метод для всех воркеров."""
        pass

    async def start(self) -> None:
        try:
            await self.run_schema_and_cdc()
            try:
                await self.run_after_start()
            except Exception as exc:
                self.logger.critical(
                    "%s: сбой в run_after_start() после миграций: %s: %s",
                    self.__class__.__name__,
                    type(exc).__name__,
                    exc,
                    exc_info=True,
                )
                raise
        except Exception:
            self.logger.critical(
                "%s: критическая ошибка при инициализации БД",
                self.__class__.__name__,
                exc_info=True,
            )
            await self.state_svc.set(SystemState.NORMAL)
            raise
        finally:
            await self.redis_client.aclose()
