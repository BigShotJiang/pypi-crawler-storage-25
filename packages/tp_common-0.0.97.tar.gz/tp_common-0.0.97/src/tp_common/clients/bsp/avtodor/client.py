from __future__ import annotations

from tp_common.clients.bsp.avtodor.request import TariffsRequest
from tp_common.clients.bsp.avtodor.response import TariffsResponse
from tp_common.keycloak.client import KeycloakClient
from tp_common.keycloak.oauth_client import KeycloakOAuthClient
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger


class BspAvtodorClient(KeycloakClient):
    """Клиент bsp-avtodor: только пути и модели; Bearer и retry — в KeycloakClient."""

    def __init__(
        self,
        logger: TpLogger,
        keycloak_url: str | None = None,
        avtodor_url: str | None = None,
        keycloak_oauth: KeycloakOAuthClient | None = None,
        audience: str = "bsp-avtodor",
        env_type: EnvironmentType = EnvironmentType.LOCAL,
        max_retries: int = 3,
        token_min_ttl_s: int = 30,
        verify_ssl: bool = False,
    ) -> None:
        base_url = self._build_base_url(avtodor_url=avtodor_url, env_type=env_type)
        super().__init__(
            base_url=base_url,
            logger=logger,
            audience=audience,
            keycloak_oauth=keycloak_oauth,
            keycloak_url=keycloak_url,
            env_type=env_type,
            max_retries=max_retries,
            token_min_ttl_s=token_min_ttl_s,
            verify_ssl=verify_ssl,
        )

    @classmethod
    def _build_base_url(
        cls, *, avtodor_url: str | None, env_type: EnvironmentType
    ) -> str:
        return (avtodor_url or cls._base_url_by_env_type(env_type)).rstrip("/") + "/"

    @staticmethod
    def _base_url_by_env_type(env_type: EnvironmentType) -> str:
        match env_type:
            case EnvironmentType.STAGING:
                return "https://avtodor.bsp-staging.bz/api"
            case EnvironmentType.PROD:
                return "https://bsp.8525.ru/avtodor/api"
            case _:
                return "https://avtodor.bsp-dev.bz/api"

    async def get_tariffs(self, request: TariffsRequest) -> TariffsResponse:
        """GET /v1/tariffs — список тарифов с фильтрами и пагинацией.

        Параметры запроса передаются в query string в camelCase
        (alias_generator у `BaseRequest`); enum-значения — строки
        (`use_enum_values=True` у `BaseQueryRequest`).
        """
        return await self.get(
            uri="/v1/tariffs",
            response_schema=TariffsResponse,
            params=request,
        )
