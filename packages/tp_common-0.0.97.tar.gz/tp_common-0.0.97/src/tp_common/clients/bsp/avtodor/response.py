"""Схемы ответов клиента bsp-avtodor.

Зеркалят `bsp-avtodor/src/api/v1/tariffs/dto.py` (камуфлокс-паттерн).
Имена синхронизированы с сервисными DTO для симметрии: `TariffRoad`,
`TariffSegment`, `TariffFull`.
"""

from __future__ import annotations

import uuid
from datetime import datetime, time
from decimal import Decimal
from enum import StrEnum

from tp_common.clients.bsp.avtodor.request import (
    DayPattern,
    PaymentMethod,
    RoadCode,
    VehicleClass,
)
from tp_common.route.schemes import BaseQueryResponse, BaseResponse


class TariffSource(StrEnum):
    """Источник тарифа: парсер сайта или ручная корректировка оператором."""

    PARSER = "parser"
    MANUAL = "manual"


class TariffRoad(BaseResponse):
    """Краткая информация о дороге, денормализованная в тариф."""

    code: RoadCode
    short_name: str
    name: str


class TariffSegment(BaseResponse):
    """Краткая информация об участке дороги, денормализованная в тариф."""

    segment_id: uuid.UUID
    km_from: int
    km_to: int | None
    name_from: str | None
    name_to: str | None
    length_km: int | None


class TariffFull(BaseResponse):
    """Полная схема тарифа в выдаче списка. JSON в camelCase через alias_generator."""

    tariff_id: uuid.UUID
    road: TariffRoad
    segment: TariffSegment
    vehicle_class: VehicleClass
    day_pattern: DayPattern
    time_from: time | None
    time_to: time | None
    payment_method: PaymentMethod
    price_rub: Decimal
    parsed_at: datetime
    source: TariffSource


class TariffsResponse(BaseQueryResponse[TariffFull]):
    """Список тарифов с total для пагинации."""
