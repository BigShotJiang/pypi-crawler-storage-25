from __future__ import annotations

import uuid
from enum import StrEnum
from typing import Self

from pydantic import BaseModel, model_validator

from tp_common.route.schemes import BaseRequest


class BrowserName(StrEnum):
    CAMOUFOX = "camoufox"
    FIREFOX = "firefox"


class BrowserProxyRequest(BaseModel):
    server: str
    username: str | None = None
    password: str | None = None
    bypass: str | None = None


class BrowserLaunchRequest(BaseRequest):
    browser_id: uuid.UUID
    browser: BrowserName = BrowserName.CAMOUFOX
    proxy: BrowserProxyRequest | None = None
    viewport_width: int | None = None
    viewport_height: int | None = None

    @model_validator(mode="after")
    def _viewport_dimensions_pair(self) -> Self:
        w, h = self.viewport_width, self.viewport_height
        if (w is None) ^ (h is None):
            raise ValueError("Поля viewport_width и viewport_height задаются вместе")
        if w is not None and h is not None and (w < 1 or h < 1):
            raise ValueError("viewport_width и viewport_height должны быть >= 1")
        return self


class BrowserCloseRequest(BaseRequest):
    browser_id: uuid.UUID
