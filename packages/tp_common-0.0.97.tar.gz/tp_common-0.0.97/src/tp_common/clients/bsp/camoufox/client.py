from __future__ import annotations

import uuid

from tp_common.keycloak.client import KeycloakClient
from tp_common.keycloak.oauth_client import KeycloakOAuthClient
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger

from .request import BrowserCloseRequest, BrowserLaunchRequest
from .response import (
    BrowserCloseResponse,
    BrowserLaunchResponse,
    BrowserStateClearResponse,
)


class CamoufoxClient(KeycloakClient):
    """Клиент bsp-camoufox: только пути и модели; Bearer и retry — в KeycloakClient.

    Размер окна/вьюпорта задаётся в :class:`BrowserLaunchRequest` полями
    ``viewport_width`` и ``viewport_height`` (оба или ни одного).
    """

    def __init__(
        self,
        *,
        keycloak_url: str | None = None,
        logger: TpLogger,
        camoufox_url: str = "http://bsp-camoufox.bz/",
        keycloak_oauth: KeycloakOAuthClient | None = None,
        audience: str = "bsp-camoufox",
        env_type: EnvironmentType = EnvironmentType.LOCAL,
        max_retries: int = 3,
        token_min_ttl_s: int = 30,
        verify_ssl: bool = False,
    ) -> None:
        super().__init__(
            base_url=camoufox_url,
            logger=logger,
            audience=audience,
            keycloak_oauth=keycloak_oauth,
            keycloak_url=keycloak_url,
            env_type=env_type,
            max_retries=max_retries,
            token_min_ttl_s=token_min_ttl_s,
            verify_ssl=verify_ssl,
        )

    async def launch_browser(
        self, request: BrowserLaunchRequest
    ) -> BrowserLaunchResponse:
        resp = await self.post_response(
            uri="/api/v1/browser/launch",
            json=request.model_dump(mode="json"),
        )
        return BrowserLaunchResponse.model_validate(resp.json())

    async def close_browser(self, request: BrowserCloseRequest) -> BrowserCloseResponse:
        resp = await self.post_response(
            uri="/api/v1/browser/close",
            json=request.model_dump(mode="json"),
        )
        return BrowserCloseResponse.model_validate(resp.json())

    async def clear_browser_state(
        self, browser_id: uuid.UUID
    ) -> BrowserStateClearResponse:
        resp = await self.delete_response(
            uri=f"/api/v1/browser/state/{browser_id}",
        )
        return BrowserStateClearResponse.model_validate(resp.json())
