from __future__ import annotations

from tp_common.route.schemes import BaseResponse


class BrowserLaunchResponse(BaseResponse):
    url: str


class BrowserCloseResponse(BaseResponse):
    closed: bool


class BrowserStateClearResponse(BaseResponse):
    cleared: bool
