"""Схемы запросов клиента bsp-mos-pass.

Зеркалят ``bsp-mos-pass/src/api/v1/*/request.py``; при изменении API сервиса
схемы нужно синхронизировать здесь.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Self

from pydantic import Field, model_validator

from tp_common.route.schemes import BaseQueryRequest, BaseRequest


class TimeOfDay(StrEnum):
    DAY = "day"
    NIGHT = "night"


class PassAllowedZone(StrEnum):
    MKAD = "МКАД"
    SK = "СК"
    TTK = "ТТК"
    MO = "МО"


class PassSeries(StrEnum):
    AA = "АА"
    BA = "БА"
    AB = "АБ"
    BB = "ББ"
    MB = "МБ"
    MK = "МК"
    MA = "МА"
    MO = "МО"
    II = "ЯЯ"
    MOJD = "МОЖД"


class TaskStatus(StrEnum):
    PENDING = "pending"
    COMPLETED = "completed"
    ERROR = "error"


class PassStatus(StrEnum):
    ACTIVE = "active"
    EXPIRED = "expired"
    WAITING_ACTIVATION = "waiting_activation"
    NOT_FOUND = "not_found"
    CANCELLED = "cancelled"


class PassFields(StrEnum):
    PASS_ID = "pass_id"
    DRIVER_ID = "driver_id"
    ID = "id"
    UID = "uid"
    VEHICLE_ID = "vehicle_id"
    NUMBER = "number"
    SERIES = "series"
    TIME_OF_DAY = "time_of_day"
    ALLOWED_ZONE = "allowed_zone"
    START_DATE = "start_date"
    END_DATE = "end_date"
    CANCEL_DATE = "cancel_date"
    CANCEL_DETECTED_AT = "cancel_detected_at"
    STATUS = "status"
    UPDATED_AT = "updated_at"


class PassesRequest(BaseQueryRequest[PassFields]):
    updated_from: int | None = Field(
        default=None,
        ge=0,
        description="Фильтр по дате обновления (Unix timestamp, секунды).",
    )
    reg_number: str | None = Field(
        default=None,
        min_length=4,
        max_length=32,
        description="Фильтр по государственному регистрационному знаку.",
    )
    series: PassSeries | None = None
    number: str | None = Field(
        default=None,
        min_length=7,
        max_length=7,
        description="Фильтр по номеру пропуска (только вместе с series).",
    )

    @model_validator(mode="after")
    def validate_series_number_pair(self) -> Self:
        has_series = self.series is not None
        has_number = self.number is not None
        if has_series != has_number:
            msg = "Поля series и number должны быть заданы вместе."
            raise ValueError(msg)
        return self


class TaskFields(StrEnum):
    TASK_ID = "task_id"
    VEHICLE_ID = "vehicle_id"
    REG_NUMBER = "reg_number"
    NUMBER = "number"
    SERIES = "series"
    FOUND_ALL = "found_all"
    FOUND_NEW = "found_new"
    FOUND_CANCEL = "found_cancel"
    PRIORITY = "priority"
    LAST_USED_AT = "last_used_at"
    COMPLETED_AT = "completed_at"
    TASK_STATUS = "task_status"
    UPDATED_AT = "updated_at"
    CREATED_AT = "created_at"


class TasksRequest(BaseQueryRequest[TaskFields]):
    task_id: int | None = Field(default=None, ge=1)
    is_completed: bool | None = Field(
        default=None,
        description="True — только завершённые; False — только незавершённые.",
    )
    updated_from: int | None = Field(
        default=None,
        ge=0,
        description="updated_at >= значения (Unix timestamp, секунды).",
    )
    completed_from: int | None = Field(
        default=None,
        ge=0,
        description="completed_at >= значения (Unix timestamp, секунды).",
    )
    created_from: int | None = Field(
        default=None,
        ge=0,
        description="created_at >= значения (Unix timestamp, секунды).",
    )


class VehicleBulkCreateEntryRequest(BaseRequest):
    reg_number: str = Field(
        min_length=4,
        max_length=32,
        description="Государственный регистрационный знак",
    )
    priority: int = Field(ge=0, description="Приоритет")


class VehicleCreateRequest(BaseRequest):
    reg_number: str = Field(
        min_length=4,
        max_length=32,
        description="Государственный регистрационный знак",
    )


class VehicleBulkCreateRequest(BaseRequest):
    vehicles: list[VehicleBulkCreateEntryRequest] = Field(
        min_length=1,
        description="Список ТС",
    )


class VehicleSyncRequest(BaseRequest):
    reg_numbers: list[str] = Field(
        min_length=1,
        description="Полный желаемый список ГРЗ",
    )


class VehicleRetryTaskUpdateRequest(BaseRequest):
    reg_number: str = Field(
        min_length=4,
        max_length=32,
        description="Государственный регистрационный знак",
    )
    priority: int = Field(ge=0, description="Приоритет")


class EventsRequest(BaseRequest):
    timestamp: int | None = Field(
        default=None,
        ge=0,
        description=(
            "Unix timestamp в миллисекундах. "
            "Если не передан, используется текущее время на момент запроса."
        ),
    )
    limit: int | None = Field(
        default=None,
        ge=1,
        le=10_000,
        description="Максимальное количество сообщений в ответе.",
    )
    timeout: float = Field(
        default=25.0,
        ge=1.0,
        le=120.0,
        description="Максимальное время ожидания сообщений в секундах.",
    )
