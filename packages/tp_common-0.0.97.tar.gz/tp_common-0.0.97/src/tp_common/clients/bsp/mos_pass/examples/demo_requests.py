"""
Пример запроса к MosPassClient: list_tasks.

Переменные окружения:
  KEYCLOAK_URL   — обязательно, https://client_id:client_secret@keycloak.host
  MOS_PASS_URL   — опционально, по умолчанию как у клиента
  ENV_TYPE       — опционально, LOCAL | DEV | … (см. EnvironmentType)

Запуск (из корня репозитория, с PYTHONPATH=src):
  set KEYCLOAK_URL=...
  python -m tp_common.clients.bsp.mos_pass.examples.demo_requests
"""

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

from tp_common.clients.bsp.mos_pass.client import MosPassClient
from tp_common.clients.bsp.mos_pass.request import TasksRequest
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLoggerFactory
from tp_common.utils import find_env_file, load_env_file

_env_path = find_env_file(anchor=Path(__file__))
if _env_path:
    load_env_file(_env_path)


def _parse_env_type(value: str | None) -> EnvironmentType:
    raw = (value or "").strip().upper()
    if not raw:
        return EnvironmentType.LOCAL
    try:
        return EnvironmentType[raw]
    except KeyError:
        return EnvironmentType.LOCAL


async def _run() -> None:
    keycloak_url = os.getenv("MOS_PASS_KEYCLOAK_URL", "").strip()
    if not keycloak_url:
        print(
            "Укажите KEYCLOAK_URL, например:\n"
            "  https://my_client:secret@keycloak.example.com",
            file=sys.stderr,
        )
        raise SystemExit(2)

    env_type = _parse_env_type(os.getenv("ENV_TYPE"))
    logger = TpLoggerFactory(env_type).get_logger(
        "bsp_mos_pass_examples", use_queue=False
    )

    client = MosPassClient(
        logger=logger,
        keycloak_url=keycloak_url,
        env_type=EnvironmentType.DEV,
        # mos_pass_url="http://127.0.0.1:8000/api",
    )

    try:
        async with client:
            resp = await client.list_tasks(TasksRequest())
            print("list_tasks ->", resp.model_dump())
    except Exception:
        ...


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
