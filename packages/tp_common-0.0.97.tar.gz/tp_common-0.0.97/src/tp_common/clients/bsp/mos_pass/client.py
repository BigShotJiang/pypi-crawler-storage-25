from __future__ import annotations

from tp_common.clients.bsp.mos_pass.request import (
    EventsRequest,
    PassesRequest,
    TasksRequest,
    VehicleBulkCreateRequest,
    VehicleCreateRequest,
    VehicleRetryTaskUpdateRequest,
    VehicleSyncRequest,
)
from tp_common.clients.bsp.mos_pass.response import (
    AppEventsResponse,
    PassesResponse,
    TasksResponse,
    Vehicle,
    VehicleResponse,
    VehiclesResponse,
    VehicleSyncResponse,
)
from tp_common.keycloak.client import KeycloakClient
from tp_common.keycloak.oauth_client import KeycloakOAuthClient
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger


class MosPassClient(KeycloakClient):
    """Клиент bsp-mos-pass: пути и модели; Bearer и retry — в ``KeycloakClient``."""

    def __init__(
        self,
        *,
        keycloak_url: str | None = None,
        logger: TpLogger,
        mos_pass_url: str | None = None,
        keycloak_oauth: KeycloakOAuthClient | None = None,
        audience: str = "bsp-mos-pass",
        env_type: EnvironmentType = EnvironmentType.LOCAL,
        max_retries: int = 3,
        token_min_ttl_s: int = 30,
        verify_ssl: bool = False,
    ) -> None:
        base_url = self._build_base_url(mos_pass_url=mos_pass_url, env_type=env_type)
        super().__init__(
            base_url=base_url,
            logger=logger,
            audience=audience,
            keycloak_oauth=keycloak_oauth,
            keycloak_url=keycloak_url,
            env_type=env_type,
            max_retries=max_retries,
            token_min_ttl_s=token_min_ttl_s,
            verify_ssl=verify_ssl,
        )

    @classmethod
    def _build_base_url(
        cls, *, mos_pass_url: str | None, env_type: EnvironmentType
    ) -> str:
        base = (mos_pass_url or cls._base_url_by_env_type(env_type)).rstrip("/")
        return f"{base}{cls._api_version_path().rstrip('/')}/"

    @staticmethod
    def _api_version_path() -> str:
        return "/v1"

    @staticmethod
    def _base_url_by_env_type(env_type: EnvironmentType) -> str:
        match env_type:
            case EnvironmentType.STAGING:
                return "https://mos-pass.bsp-staging.bz/api"
            case EnvironmentType.PROD:
                return "https://bsp.8525.ru/mos-pass/api"
            case _:
                return "https://mos-pass.bsp-dev.bz/api"

    async def list_passes(self, request: PassesRequest) -> PassesResponse:
        return await self.get(
            uri="/passes",
            response_schema=PassesResponse,
            params=request,
        )

    async def list_tasks(self, request: TasksRequest) -> TasksResponse:
        return await self.get(
            uri="/tasks",
            response_schema=TasksResponse,
            params=request,
        )

    async def create_vehicle(self, request: VehicleCreateRequest) -> Vehicle:
        return await self.post(
            uri="/vehicles",
            response_schema=Vehicle,
            json=request.model_dump(mode="json"),
        )

    async def ensure_vehicle(self, request: VehicleCreateRequest) -> VehicleResponse:
        """POST /vehicles/ensure: ТС + задача или повышение приоритета активной задачи."""
        return await self.post(
            uri="/vehicles/ensure",
            response_schema=VehicleResponse,
            json=request.model_dump(mode="json"),
        )

    async def create_vehicles_bulk(
        self, request: VehicleBulkCreateRequest
    ) -> VehiclesResponse:
        return await self.post(
            uri="/vehicles/bulk",
            response_schema=VehiclesResponse,
            json=request.model_dump(mode="json"),
        )

    async def sync_vehicles(self, request: VehicleSyncRequest) -> VehicleSyncResponse:
        return await self.post(
            uri="/vehicles/sync",
            response_schema=VehicleSyncResponse,
            json=request.model_dump(mode="json"),
        )

    async def retry_vehicle_task(
        self, request: VehicleRetryTaskUpdateRequest
    ) -> VehicleResponse:
        return await self.patch(
            uri="/vehicles/retry-task",
            response_schema=VehicleResponse,
            json=request.model_dump(mode="json"),
        )

    async def get_events(self, request: EventsRequest) -> AppEventsResponse:
        return await self.get(
            uri="/events",
            response_schema=AppEventsResponse,
            params=request,
        )
