"""Схемы ответов клиента bsp-mos-pass (зеркало ``bsp-mos-pass/src/api/v1/*/response.py``)."""

from __future__ import annotations

import uuid
from datetime import date, datetime
from enum import StrEnum

from pydantic import Field, RootModel

from tp_common.clients.bsp.mos_pass.request import (
    PassAllowedZone,
    PassSeries,
    PassStatus,
    TaskStatus,
    TimeOfDay,
)
from tp_common.route.schemes import BaseQueryResponse, BaseResponse


class PassFull(BaseResponse):
    pass_id: uuid.UUID
    pass_foreign_id: int = Field(
        description="Идентификатор пропуска во внешней системе (t.mos.ru)"
    )
    pass_uuid: uuid.UUID
    time_of_day: TimeOfDay
    reg_number: str
    series: PassSeries
    number: str
    allowed_zone: PassAllowedZone
    start_date: date
    end_date: date
    cancel_date: date | None
    pass_type: str
    pass_status: PassStatus
    change_date: datetime | None
    drivers: str


class PassesResponse(BaseQueryResponse[PassFull]):
    """Список пропусков."""


class Task(BaseResponse):
    task_id: int
    vehicle_id: uuid.UUID | None
    reg_number: str | None
    number: str | None
    series: PassSeries | None
    found_all: int
    found_new: int
    found_cancel: int
    priority: int
    last_used_at: datetime | None
    completed_at: datetime | None
    task_status: TaskStatus
    updated_at: datetime
    created_at: datetime


class TasksResponse(BaseQueryResponse[Task]):
    """Список задач."""


class Vehicle(BaseResponse):
    vehicle_id: uuid.UUID
    reg_number: str
    priority: int
    retry_at: datetime | None
    created_at: datetime
    updated_at: datetime


class VehicleResponse(Vehicle):
    """Ответ PATCH /vehicles/retry-task."""


class VehiclesResponse(RootModel[list[Vehicle]]):
    """Массовое создание ТС: массив в корне JSON."""


class VehicleSyncResponse(BaseResponse):
    added: int
    deleted: int


class AppEventType(StrEnum):
    FOUND = "found"
    NOT_FOUND = "not_found"
    CANCELLED = "cancelled"
    ACTIVATED = "activated"
    EXPIRED = "expired"
    ERROR = "error"


class AppEventPayload(BaseResponse):
    pass_id: uuid.UUID
    driver_id: uuid.UUID
    id: int
    uid: uuid.UUID
    vehicle_id: uuid.UUID | None
    number: str
    series: PassSeries
    time_of_day: TimeOfDay
    allowed_zone: PassAllowedZone
    start_date: date
    end_date: date
    cancel_date: date | None
    cancel_detected_at: datetime | None
    status: PassStatus
    updated_at: datetime


class AppEvent(BaseResponse):
    timestamp: datetime
    service_id: str
    reg_number: str
    event: AppEventType
    payload: AppEventPayload | None = None


class AppEventsResponse(RootModel[list[AppEvent]]):
    """Список событий: массив в корне JSON."""
