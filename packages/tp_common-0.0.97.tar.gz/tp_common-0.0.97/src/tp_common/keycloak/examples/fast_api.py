from __future__ import annotations

import asyncio
import os
import threading
import time
from pathlib import Path

from fastapi import Depends, FastAPI

from tp_common.base_client.client import BaseClient
from tp_common.keycloak import KeycloakMiddleware
from tp_common.keycloak.depends import get_keycloak_payload, get_keycloak_service_id
from tp_common.keycloak.oauth_client import KeycloakOAuthClient
from tp_common.tp_fastapi import TpMiddleware
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLoggerFactory
from tp_common.utils import find_env_file, load_env_file, parse_url_with_auth


def _parse_env_type(value: str | None) -> EnvironmentType:
    raw = (value or "").strip().upper()
    if not raw:
        return EnvironmentType.DEV
    return EnvironmentType[raw]


def _parse_bool(value: str | None) -> bool:
    return (value or "").strip().lower() in {"1", "true", "yes", "y", "on"}


_ENV_FILE = find_env_file(anchor=Path(__file__))
if _ENV_FILE:
    load_env_file(_ENV_FILE)

KEYCLOAK_URL = os.getenv(
    "KEYCLOAK_URL", "https://client_id:client_secret@keycloak.host"
)
CLIENT_KEYCLOAK_URL = os.getenv("CLIENT_KEYCLOAK_URL", "").strip()
AUDIENCE_OVERRIDE = os.getenv("AUDIENCE", "bsp-gosuslugi").strip()
ENV_TYPE = _parse_env_type(os.getenv("ENV_TYPE"))
ACCEPT_ANY_REALM_ON_DOMAIN = _parse_bool(os.getenv("ACCEPT_ANY_REALM_ON_DOMAIN"))
PORT_DEFAULT = int(os.getenv("PORT", "8000"))

app = FastAPI(title="tp-common: KeycloakMiddleware example")

app.add_middleware(
    KeycloakMiddleware,
    keycloak_url=KEYCLOAK_URL,
    env_type=ENV_TYPE,
    accept_any_realm_on_domain=ACCEPT_ANY_REALM_ON_DOMAIN,
    exempt_paths=("/health", "/docs", "/openapi.json"),
)
app.add_middleware(TpMiddleware)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/me")
async def me(
    payload: dict[str, object] = Depends(get_keycloak_payload),
) -> dict[str, object]:
    return payload


@app.get("/client")
async def client(
    service_id: str = Depends(get_keycloak_service_id),
) -> dict[str, object]:
    return {"service_id": service_id}


class ExpKeycloakClient(BaseClient):
    """Клиент для вызова demo API без прямого aiohttp в примере."""

    async def get_health(self) -> object:
        return (await self.get_response("/health")).json()

    async def get_client(self) -> object:
        return (await self.get_response("/client")).json()

    async def get_me(self) -> object:
        return (await self.get_response("/me")).json()


if __name__ == "__main__":
    import uvicorn

    PORT = PORT_DEFAULT
    _, audience, _ = parse_url_with_auth(KEYCLOAK_URL)
    audience = AUDIENCE_OVERRIDE or (audience or "")

    if not audience:
        raise RuntimeError(
            "Не удалось извлечь audience (client_id) из KEYCLOAK_URL. "
            "Ожидается формат https://client_id:client_secret@keycloak.host"
        )

    if not CLIENT_KEYCLOAK_URL:
        print(
            "CLIENT_KEYCLOAK_URL не задан. Поднимаю только API, без demo-запросов.\n"
            "Чтобы выполнить demo (получить токен через KeycloakOAuthClient и сходить в /me), задай:\n"
            '  CLIENT_KEYCLOAK_URL="https://caller_client:caller_secret@keycloak.host"'
        )
        uvicorn.run(app, host="127.0.0.1", port=PORT, log_level="info")
        raise SystemExit(0)

    # Пример: поднять API и выполнить запросы через KeycloakOAuthClient.
    # Важно: тут НЕ используем reload, иначе будет отдельный reloader-процесс
    # и demo-поток окажется не там.
    config = uvicorn.Config(app=app, host="127.0.0.1", port=PORT, log_level="info")
    server = uvicorn.Server(config)

    def _run_server() -> None:
        server.run()

    server_thread = threading.Thread(
        target=_run_server, name="uvicorn-server", daemon=True
    )
    server_thread.start()

    async def _wait_for_health(*, timeout_s: float = 10.0) -> None:
        deadline = time.time() + timeout_s
        logger = TpLoggerFactory(ENV_TYPE).get_logger("api_health", use_queue=False)
        async with ExpKeycloakClient(
            base_url=f"http://127.0.0.1:{PORT}",
            logger=logger,
        ) as api:
            while time.time() < deadline:
                try:
                    _ = await api.get_health()
                    return
                except Exception:  # noqa: BLE001
                    await asyncio.sleep(0.2)
        raise RuntimeError("FastAPI did not start in time")

    async def _demo_requests() -> None:
        await _wait_for_health(timeout_s=10.0)

        logger = TpLoggerFactory(ENV_TYPE).get_logger("keycloak_demo", use_queue=False)

        try:
            async with KeycloakOAuthClient(
                CLIENT_KEYCLOAK_URL,
                logger,
                env_type=ENV_TYPE,
            ) as kc:
                bearer = (await kc.get_service_token(audience=audience)).access_token
        except Exception as exc:  # noqa: BLE001
            # BaseClient прокидывает response_body — выведем его, чтобы сразу видеть причину.
            body = getattr(exc, "response_body", None)
            if body:
                print("Keycloak error response:", body)
            raise

        async with ExpKeycloakClient(
            base_url=f"http://127.0.0.1:{PORT}",
            logger=logger,
        ) as api:
            api.set_bearer_token(bearer)
            print("GET /client ->", await api.get_client())
            print("GET /me ->", await api.get_me())

    def _run_demo() -> None:
        try:
            asyncio.run(_demo_requests())
        finally:
            server.should_exit = True

    demo_thread = threading.Thread(target=_run_demo, name="keycloak-demo", daemon=True)
    demo_thread.start()

    demo_thread.join(timeout=30.0)
    server_thread.join(timeout=5.0)
