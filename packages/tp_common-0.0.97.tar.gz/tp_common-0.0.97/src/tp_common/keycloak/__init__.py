"""Интеграция с Keycloak (JWKS, middleware для FastAPI)."""

from tp_common.keycloak.client import KeycloakClient
from tp_common.keycloak.exceptions import (
    KeycloakException,
    KeycloakInvalidAudience,
    KeycloakInvalidAuthorizationHeader,
    KeycloakInvalidConfiguration,
    KeycloakInvalidIssuer,
    KeycloakInvalidToken,
    KeycloakMissingAuthorizationHeader,
    KeycloakMissingOAuthDependency,
    KeycloakMissingRequiredRole,
    KeycloakTokenExpired,
)
from tp_common.keycloak.middleware import KeycloakMiddleware
from tp_common.keycloak.oauth_client import KeycloakOAuthClient, KeycloakTokenResponse

__all__ = [
    "KeycloakMiddleware",
    "KeycloakOAuthClient",
    "KeycloakClient",
    "KeycloakTokenResponse",
    "KeycloakException",
    "KeycloakInvalidConfiguration",
    "KeycloakMissingAuthorizationHeader",
    "KeycloakMissingOAuthDependency",
    "KeycloakInvalidAuthorizationHeader",
    "KeycloakTokenExpired",
    "KeycloakInvalidIssuer",
    "KeycloakInvalidToken",
    "KeycloakInvalidAudience",
    "KeycloakMissingRequiredRole",
]
