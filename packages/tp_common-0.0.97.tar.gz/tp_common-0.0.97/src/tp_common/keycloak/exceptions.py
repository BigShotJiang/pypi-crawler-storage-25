"""Ошибки проверки токена Keycloak (JWKS), наследники TPException."""

from __future__ import annotations

from http import HTTPStatus

from tp_common.exceptions import TpException


class KeycloakException(TpException):
    """Базовое исключение Keycloak middleware / декодирования access token."""


class KeycloakInvalidConfiguration(KeycloakException):
    def __init__(self, message: str = "Invalid keycloak configuration") -> None:
        super().__init__(message, status_code=HTTPStatus.INTERNAL_SERVER_ERROR)


class KeycloakMissingAuthorizationHeader(KeycloakException):
    def __init__(self) -> None:
        super().__init__(
            "Missing Authorization header",
            status_code=HTTPStatus.UNAUTHORIZED,
        )


class KeycloakInvalidAuthorizationHeader(KeycloakException):
    def __init__(self) -> None:
        super().__init__(
            "Invalid Authorization header",
            status_code=HTTPStatus.UNAUTHORIZED,
        )


class KeycloakTokenExpired(KeycloakException):
    def __init__(self) -> None:
        super().__init__("Token expired", status_code=HTTPStatus.UNAUTHORIZED)


class KeycloakInvalidIssuer(KeycloakException):
    def __init__(self, message: str = "Invalid issuer") -> None:
        super().__init__(message, status_code=HTTPStatus.UNAUTHORIZED)


class KeycloakInvalidToken(KeycloakException):
    def __init__(self) -> None:
        super().__init__("Invalid token", status_code=HTTPStatus.UNAUTHORIZED)


class KeycloakInvalidAudience(KeycloakException):
    def __init__(self) -> None:
        super().__init__("Invalid audience", status_code=HTTPStatus.FORBIDDEN)


class KeycloakMissingRequiredRole(KeycloakException):
    def __init__(self) -> None:
        super().__init__(
            "Missing required role",
            status_code=HTTPStatus.FORBIDDEN,
        )


class KeycloakClientException(KeycloakException):
    """Ошибки Keycloak HTTP-клиента (получение/обмен токена)."""


class KeycloakMissingOAuthDependency(KeycloakClientException):
    """Не передан ни keycloak_oauth, ни keycloak_url при создании KeycloakClient."""

    def __init__(self) -> None:
        super().__init__(
            "Нужен keycloak_oauth или keycloak_url для авторизации к Keycloak",
            status_code=HTTPStatus.BAD_REQUEST,
        )


class KeycloakTokenResponseInvalid(KeycloakClientException):
    def __init__(self, message: str = "Invalid Keycloak token response") -> None:
        super().__init__(message, status_code=HTTPStatus.BAD_GATEWAY)


class KeycloakTokenMissingAccessToken(KeycloakClientException):
    def __init__(self, message: str = "Keycloak response has no access_token") -> None:
        super().__init__(message, status_code=HTTPStatus.BAD_GATEWAY)
