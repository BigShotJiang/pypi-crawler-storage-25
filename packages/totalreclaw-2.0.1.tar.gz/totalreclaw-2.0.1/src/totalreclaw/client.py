"""
TotalReclaw Client -- High-level API.

Usage:
    from totalreclaw import TotalReclaw

    client = TotalReclaw(recovery_phrase="abandon abandon ...")
    await client.remember("Pedro prefers dark mode")
    results = await client.recall("What does Pedro prefer?")
    await client.forget(results[0].id)
    facts = await client.export_all()
    status = await client.status()
    await client.close()

Legacy parameter names (mnemonic, relay_url) are still accepted for
backwards compatibility but are deprecated.
"""
from __future__ import annotations
from typing import Optional

from .crypto import (
    derive_keys_from_mnemonic,
    derive_lsh_seed,
    compute_auth_key_hash,
    DerivedKeys,
)
from .lsh import LSHHasher
from .relay import RelayClient, BillingStatus, _default_relay_url
from .reranker import RerankerResult
from .operations import (
    store_fact,
    search_facts,
    forget_fact,
    export_facts,
    pin_fact,
    unpin_fact,
)

# Smart Account address derivation constants
# These match the CREATE2 deterministic address generation used by
# SimpleSmartAccount in the permissionless library
SIMPLE_ACCOUNT_FACTORY = "0x91E60e0613810449d098b0b5Ec8b51A0FE8c8985"
ENTRYPOINT_V07 = "0x0000000071727De22E5E9d8BAf0edAc6f37da032"


def _get_eoa_account(mnemonic: str):
    """Derive the EOA (externally-owned account) from a BIP-39 mnemonic.

    Returns the full ``LocalAccount`` so callers can access both address and
    private key.
    """
    from eth_account import Account
    Account.enable_unaudited_hdwallet_features()
    return Account.from_mnemonic(mnemonic.strip(), account_path="m/44'/60'/0'/0/0")


def _get_eoa_address(mnemonic: str) -> str:
    """Derive the EOA address from a BIP-39 mnemonic."""
    return _get_eoa_account(mnemonic).address


async def _derive_smart_account_address(mnemonic: str, rpc_url: str = "https://sepolia.base.org") -> str:
    """Derive the CREATE2 Smart Account address by querying the factory contract.

    Calls SimpleAccountFactory.getAddress(owner, 0) via eth_call on a public RPC.
    This matches the `toSimpleSmartAccount` logic in permissionless/viem.

    Factory: 0x91E60e0613810449d098b0b5Ec8b51A0FE8c8985 (v0.7)
    Method: getAddress(address owner, uint256 salt) view returns (address)
    """
    import httpx

    eoa_address = _get_eoa_address(mnemonic)

    # ABI-encode: getAddress(address,uint256)
    # keccak256("getAddress(address,uint256)")[:4] = 0x8cb84e18
    selector = "8cb84e18"

    # Pad owner address to 32 bytes and salt (0) to 32 bytes
    owner_padded = eoa_address.lower().replace("0x", "").zfill(64)
    salt_padded = "0" * 64

    calldata = f"0x{selector}{owner_padded}{salt_padded}"

    async with httpx.AsyncClient(timeout=15.0) as client:
        resp = await client.post(
            rpc_url,
            json={
                "jsonrpc": "2.0",
                "method": "eth_call",
                "params": [
                    {"to": SIMPLE_ACCOUNT_FACTORY, "data": calldata},
                    "latest",
                ],
                "id": 1,
            },
        )
        result = resp.json().get("result", "")
        if not result or result == "0x" or len(result) < 66:
            # Fallback to EOA if RPC fails
            return eoa_address.lower()
        # Result is ABI-encoded address (32 bytes, last 20 bytes are the address)
        address = "0x" + result[-40:]
        return address.lower()


class TotalReclaw:
    """High-level TotalReclaw client with remember/recall/forget/export/status.

    The wallet_address is the CREATE2 Smart Account address. If not provided,
    call `await client.resolve_address()` before using remember/recall/forget/export
    to derive it via an RPC call to the SimpleAccountFactory contract.

    Parameters
    ----------
    recovery_phrase : str
        BIP-39 12-word recovery phrase (preferred name).
    server_url : str
        Relay server URL (preferred name, default: ``https://api.totalreclaw.xyz``).
    mnemonic : str
        Deprecated alias for ``recovery_phrase``.
    relay_url : str
        Deprecated alias for ``server_url``.
    wallet_address : str, optional
        Pre-resolved Smart Account address.
    is_test : bool
        Send ``X-TotalReclaw-Test: true`` header.
    """

    def __init__(
        self,
        recovery_phrase: Optional[str] = None,
        server_url: Optional[str] = None,
        wallet_address: Optional[str] = None,
        is_test: bool = False,
        *,
        mnemonic: Optional[str] = None,
        relay_url: Optional[str] = None,
    ):
        resolved_mnemonic = recovery_phrase or mnemonic
        if not resolved_mnemonic:
            raise ValueError("recovery_phrase is required")
        self._mnemonic = resolved_mnemonic.strip()
        self._keys = derive_keys_from_mnemonic(self._mnemonic)
        self._lsh_seed = derive_lsh_seed(self._mnemonic, self._keys.salt)
        self._lsh_hasher: Optional[LSHHasher] = None
        self._auth_key_hex = self._keys.auth_key.hex()
        resolved_url = server_url or relay_url or _default_relay_url()
        self._relay_url = resolved_url

        # Derive EOA account (address + private key) for UserOp signing
        eoa_acct = _get_eoa_account(self._mnemonic)
        self._eoa_address: str = eoa_acct.address
        self._eoa_private_key: bytes = bytes(eoa_acct.key)

        # Store Smart Account address. If provided at construction time, mark as
        # resolved. Otherwise, leave as None — callers MUST call
        # ``await client.resolve_address()`` (or any remember/recall/forget/export,
        # which lazily triggers resolution) before reading ``.wallet_address``.
        # We intentionally do NOT fall back to the EOA placeholder here: silently
        # exposing the EOA misled QA tooling in v2.0.0 into querying the subgraph
        # with the wrong address. See DIAG-PYTHON-V2-20260418.md.
        if wallet_address is not None:
            self._wallet_address: Optional[str] = wallet_address.lower()
            self._address_resolved = True
        else:
            self._wallet_address = None
            self._address_resolved = False
        self._relay = RelayClient(
            relay_url=resolved_url,
            auth_key_hex=self._auth_key_hex,
            wallet_address=self._wallet_address,
            is_test=is_test,
        )
        self._registered = False

    async def resolve_address(self) -> str:
        """Resolve the CREATE2 Smart Account address via RPC.

        Must be called before remember/recall/forget/export if wallet_address
        was not provided at construction time. Also called automatically by
        remember/recall/forget/export via ``_ensure_address``.
        """
        if self._address_resolved and self._wallet_address is not None:
            return self._wallet_address

        self._wallet_address = await _derive_smart_account_address(self._mnemonic)
        self._address_resolved = True
        # Update relay client with resolved address
        self._relay._wallet_address = self._wallet_address
        return self._wallet_address

    async def _ensure_address(self) -> None:
        """Lazily resolve the Smart Account address if not yet done."""
        if not self._address_resolved:
            await self.resolve_address()

    async def _ensure_registered(self) -> None:
        """Register auth key with relay if not yet done (idempotent).

        Without this, all relay queries return 401. The relay returns 200
        for already-registered users, so this is safe to call on every startup.
        """
        if self._registered:
            return
        try:
            await self.register()
        except Exception:
            # Best-effort — relay may be unreachable; will retry on next call.
            pass

    def _get_lsh_hasher(self, dims: int = 640) -> LSHHasher:
        if self._lsh_hasher is None:
            self._lsh_hasher = LSHHasher(self._lsh_seed, dims)
        return self._lsh_hasher

    @property
    def wallet_address(self) -> str:
        """Return the CREATE2 Smart Account (SA) address.

        **Contract:** this property is only valid once the SA has been
        resolved. Resolution happens either:

        * at construction time (if ``wallet_address=`` was passed in),
        * explicitly via ``await client.resolve_address()``, or
        * implicitly on the first ``remember/recall/forget/export`` call,
          which internally calls ``_ensure_address``.

        If you read this property before any of the above has happened it
        will raise ``RuntimeError``. Historically (<=2.0.0) it silently
        returned the EOA placeholder, which led QA tooling to query the
        subgraph with the wrong address and report false negatives. See
        DIAG-PYTHON-V2-20260418.md.

        Returns
        -------
        str
            The lowercase 0x-prefixed Smart Account address.

        Raises
        ------
        RuntimeError
            If called before the address has been resolved.
        """
        if not self._address_resolved or self._wallet_address is None:
            raise RuntimeError(
                "Smart Account address not yet resolved. Call "
                "`await client.resolve_address()` before reading "
                "`wallet_address`, or simply call `remember`/`recall`/"
                "`forget`/`export` first (they resolve lazily). "
                "See DIAG-PYTHON-V2-20260418.md for background."
            )
        return self._wallet_address

    async def get_wallet_address(self) -> str:
        """Async-safe getter that resolves the SA address if needed.

        Prefer this in code that may run before any remember/recall call —
        it guarantees you get the Smart Account address without needing
        to sequence a separate ``await client.resolve_address()`` first.
        """
        await self._ensure_address()
        assert self._wallet_address is not None  # _ensure_address guarantees this
        return self._wallet_address

    @property
    def keys(self) -> DerivedKeys:
        return self._keys

    async def register(self) -> str:
        """Register with the relay. Returns user_id."""
        auth_hash = compute_auth_key_hash(self._keys.auth_key)
        user_id = await self._relay.register(auth_hash, self._keys.salt.hex())
        self._registered = True
        return user_id

    async def remember(
        self,
        text: str,
        embedding: Optional[list[float]] = None,
        importance: float = 0.5,
        source: str = "python-client",
        fact_type: str = "claim",
        entities: Optional[list] = None,
        confidence: float = 0.85,
        # v1 taxonomy fields — part of the default write path as of 2.0.0.
        provenance: str = "user",
        scope: str = "unspecified",
        reasoning: Optional[str] = None,
        volatility: Optional[str] = None,
    ) -> str:
        """Store a fact. Returns the fact ID.

        Memory Taxonomy v1 is the default (and only) write path. The stored
        blob is a v1 JSON payload (``schema_version == "1.0"``) and the
        outer protobuf wrapper is tagged ``version == 4``.

        Parameters
        ----------
        text : str
            The fact text (max 512 chars after v1 normalization).
        embedding : list[float], optional
            Pre-computed embedding. When supplied, LSH trapdoors are generated.
        importance : float
            1-10 integer, or 0-1 float (auto-normalized). Defaults to 0.5 → 5.
        source : str
            The client-source tag written to the outer protobuf ``source``
            field (legacy / server-side analytics field). For v1 provenance
            (user vs assistant), use ``provenance`` below.
        fact_type : str, default "claim"
            v1 type (claim | preference | directive | commitment | episode
            | summary). Legacy v0 tokens (fact, decision, episodic, goal,
            context, rule) are coerced transparently.
        entities : list, optional
            List of entity dicts or ``ExtractedEntity`` instances.
        confidence : float, default 0.85
            LLM-self-reported confidence.
        provenance : str, default "user"
            v1 source field written into the canonical claim. Default
            ``"user"`` since the explicit tool path means the caller typed it.
        scope : str, default "unspecified"
            v1 life-domain scope.
        reasoning : str, optional
            "because Y" clause — only meaningful for decision-style claims
            (type=claim with an explicit reasoning clause).
        volatility : str, optional
            Post-extraction rescored volatility; usually left blank on
            explicit remember calls (the store path picks a default).
        """
        await self._ensure_address()
        await self._ensure_registered()
        lsh = self._get_lsh_hasher() if embedding else None
        return await store_fact(
            text=text,
            keys=self._keys,
            owner=self._wallet_address,
            relay=self._relay,
            lsh_hasher=lsh,
            embedding=embedding,
            importance=importance,
            source=source,
            fact_type=fact_type,
            entities=entities,
            confidence=confidence,
            provenance=provenance,
            scope=scope,
            reasoning=reasoning,
            volatility=volatility,
            eoa_private_key=self._eoa_private_key,
            eoa_address=self._eoa_address,
            sender=self._wallet_address,
        )

    async def recall(
        self,
        query: str,
        query_embedding: Optional[list[float]] = None,
        max_candidates: int = 250,
        top_k: int = 8,
    ) -> list[RerankerResult]:
        """Search for facts matching a query. Returns ranked results."""
        await self._ensure_address()
        await self._ensure_registered()
        lsh = self._get_lsh_hasher() if query_embedding else None
        return await search_facts(
            query=query,
            keys=self._keys,
            owner=self._wallet_address,
            relay=self._relay,
            query_embedding=query_embedding,
            lsh_hasher=lsh,
            max_candidates=max_candidates,
            top_k=top_k,
        )

    async def forget(self, fact_id: str) -> bool:
        """Soft-delete a fact by writing a tombstone."""
        await self._ensure_address()
        await self._ensure_registered()
        return await forget_fact(
            fact_id,
            self._wallet_address,
            self._relay,
            eoa_private_key=self._eoa_private_key,
            eoa_address=self._eoa_address,
            sender=self._wallet_address,
        )

    async def pin_fact(self, fact_id: str) -> dict:
        """Pin a claim so auto-resolution cannot supersede it.

        Delegates to :func:`totalreclaw.operations.pin_fact` with this
        client's derived keys, wallet address, and EOA signing key.

        Returns
        -------
        dict
            ``{success, fact_id, new_fact_id, previous_status, new_status}``
            where ``fact_id`` is the original tombstoned id and
            ``new_fact_id`` is the replacement with pinned status. On
            no-op: ``{success, fact_id, previous_status, new_status, idempotent: True}``.
        """
        await self._ensure_address()
        await self._ensure_registered()
        return await pin_fact(
            fact_id=fact_id,
            keys=self._keys,
            owner=self._wallet_address,
            relay=self._relay,
            eoa_private_key=self._eoa_private_key,
            eoa_address=self._eoa_address,
            sender=self._wallet_address,
        )

    async def unpin_fact(self, fact_id: str) -> dict:
        """Move a pinned claim back to ``active`` status.

        Delegates to :func:`totalreclaw.operations.unpin_fact`. Idempotent
        on claims that are already active.
        """
        await self._ensure_address()
        await self._ensure_registered()
        return await unpin_fact(
            fact_id=fact_id,
            keys=self._keys,
            owner=self._wallet_address,
            relay=self._relay,
            eoa_private_key=self._eoa_private_key,
            eoa_address=self._eoa_address,
            sender=self._wallet_address,
        )

    async def export_all(self) -> list[dict]:
        """Export all active facts, decrypted."""
        await self._ensure_address()
        await self._ensure_registered()
        return await export_facts(self._keys, self._wallet_address, self._relay)

    async def status(self) -> BillingStatus:
        """Get billing status."""
        await self._ensure_address()
        await self._ensure_registered()
        return await self._relay.get_billing_status()

    async def close(self):
        """Close the HTTP client."""
        await self._relay.close()
