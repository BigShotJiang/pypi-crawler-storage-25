"""forithmus-cli: Local validation + submission tool for Forithmus Research Hub."""
__version__ = "0.1.4"
