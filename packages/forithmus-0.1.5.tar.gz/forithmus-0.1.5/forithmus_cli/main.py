"""
forithmus-cli: Forithmus Research Hub command-line tool.

Commands:
  login                        Authenticate with the platform
  logout                       Clear stored credentials
  whoami                       Show current user info
  challenges                   List your challenges
  init <slug>                  Download schema and set up local config
  generate                     Generate dummy test data from schema
  test <image>                 Run and validate Docker container locally
  validate <output-dir>        Validate output files against schema
  submit <file>                Submit Docker container or prediction file
  upload-data <file>           Upload test data to a phase
  upload-gt <file>             Upload ground truth to a phase
  upload-eval <file>           Upload evaluation container to a phase
  status                       Check phase data status
"""
import os
import sys
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from forithmus_cli.branding import print_banner, print_header, VERSION
from forithmus_cli.auth import login_cmd, logout_cmd, whoami_cmd, get_token
from forithmus_cli.api import api_get, api_post, upload_file, poll_status
from forithmus_cli.validator import validate_output
from forithmus_cli.docker_runner import run_docker_test
from forithmus_cli.schema import load_config, save_config, generate_dummy_data
from forithmus_cli.buddy import fori, THINKING, HAPPY, SAD, CELEBRATE

app = typer.Typer(
    name="forithmus",
    help="Forithmus Research Hub CLI",
    invoke_without_command=True,
    add_completion=False,
)
console = Console()


@app.callback()
def main(ctx: typer.Context):
    """Forithmus Research Hub CLI"""
    if ctx.invoked_subcommand is None:
        print_banner(console)
        fori.greet()
        console.print(ctx.get_help())
        raise typer.Exit()


def _require_auth():
    token = get_token()
    if not token:
        console.print("[red]Not logged in. Run: forithmus login[/red]")
        raise typer.Exit(1)
    return token


def _require_config():
    config = load_config()
    if not config:
        console.print("[red]No config found. Run: forithmus init <challenge-slug>[/red]")
        raise typer.Exit(1)
    return config


def _resolve_phase(challenge_slug: str, phase_ref: str) -> tuple[str, str]:
    """Resolve a --phase argument (slug or UUID) against the challenge's phase list.
    Returns (phase_id, phase_name). Aborts with a clear error if not found.
    """
    try:
        phases = api_get(f"/challenges/{challenge_slug}/phases") or []
    except Exception as e:
        console.print(f"[red]Could not fetch phases for {challenge_slug}: {e}[/red]")
        raise typer.Exit(1)

    # Match by id first (UUID), then by slug, then by name (case-insensitive).
    for p in phases:
        if p.get("id") == phase_ref:
            return p["id"], p.get("name", "")
    for p in phases:
        if p.get("slug") == phase_ref:
            return p["id"], p.get("name", "")
    for p in phases:
        if (p.get("name") or "").lower() == phase_ref.lower():
            return p["id"], p.get("name", "")

    # Not found — list the available ones to help the user pick.
    console.print(f"[red]Phase '{phase_ref}' not found in challenge '{challenge_slug}'.[/red]")
    console.print("[yellow]Available phases:[/yellow]")
    for p in phases:
        edition = p.get("edition") or "-"
        enabled = "open" if p.get("submissions_enabled") else "closed"
        console.print(f"  - {p.get('slug','?')} ({p.get('name','?')}, edition={edition}, {enabled})")
    raise typer.Exit(1)


def _check_phase_open(challenge_slug: str, phase_id: str) -> None:
    """Verify the phase is still on the challenge's current_edition and open for submissions.
    Fails fast here so the user doesn't upload a multi-GB tarball only to be
    rejected at the /submissions endpoint.
    """
    try:
        ch = api_get(f"/challenges/{challenge_slug}") or {}
    except Exception:
        return  # Network hiccup — let the server be the source of truth.
    current_edition = ch.get("current_edition")

    try:
        phases = api_get(f"/challenges/{challenge_slug}/phases") or []
    except Exception:
        return
    phase = next((p for p in phases if p.get("id") == phase_id), None)
    if not phase:
        console.print(f"[red]Configured phase {phase_id} not found in {challenge_slug}.[/red]")
        console.print("[yellow]Your local config points at a phase that no longer exists. "
                      "Run `forithmus init <challenge>` to refresh, or pass --phase.[/yellow]")
        raise typer.Exit(1)

    p_edition = phase.get("edition")
    if current_edition and p_edition and p_edition != current_edition:
        console.print(f"[red]Phase '{phase.get('name')}' is from edition {p_edition}, "
                      f"but the challenge's current edition is {current_edition}.[/red]")
        console.print("[yellow]Pass --phase <slug-or-id> for the current edition, "
                      "or re-run `forithmus init` to refresh your config.[/yellow]")
        raise typer.Exit(1)


def _select_phase(
    challenge_slug: str,
    config: dict,
    override,
) -> tuple:
    """Pick which phase a CLI command should target.

    Priority:
      1. If `--phase` override supplied: resolve it (slug/name/UUID) against the
         challenge's full phase list. No edition filter — the user knows what
         they asked for.
      2. Otherwise: look up the challenge on the server and pick the phase
         matching `current_edition`. If the local config has a phase name
         (e.g. "Main"), prefer that one when multiple phases share the same
         edition. This is the safe default — it means a stale local config
         that still points at last year's edition won't silently send uploads
         to a closed phase.
      3. If we can't talk to the server (offline): fall back to the config's
         cached phase_id as a last resort, so the CLI still works offline.

    Returns (phase_id, phase_name).
    """
    if override:
        return _resolve_phase(challenge_slug, override)

    # Talk to the server to find the current-edition phase.
    try:
        ch = api_get(f"/challenges/{challenge_slug}") or {}
        phases = api_get(f"/challenges/{challenge_slug}/phases") or []
    except Exception as e:
        # Offline fallback. Still prefer config — but warn so the user knows.
        console.print(f"[yellow]Could not reach server ({e}); using cached phase from config.[/yellow]")
        return config["phase_id"], config.get("phase_name", "")

    current_edition = ch.get("current_edition")
    candidates = phases
    if current_edition:
        candidates = [p for p in phases if p.get("edition") == current_edition] or phases

    if not candidates:
        console.print(f"[red]No phases found for {challenge_slug}.[/red]")
        raise typer.Exit(1)

    # Prefer the phase whose name matches the one the user chose at `init` time.
    hint_name = (config.get("phase_name") or config.get("phase") or "").lower()
    if hint_name:
        for p in candidates:
            if (p.get("name") or "").lower() == hint_name or (p.get("slug") or "").lower() == hint_name:
                return p["id"], p.get("name", "")

    if len(candidates) == 1:
        return candidates[0]["id"], candidates[0].get("name", "")

    # Multiple current-edition phases and no hint match — force the user to pick.
    console.print(f"[yellow]Multiple phases in edition {current_edition}. Pass --phase to pick one:[/yellow]")
    for p in candidates:
        console.print(f"  - {p.get('slug','?')}  ({p.get('name','?')})")
    raise typer.Exit(1)


# ─── Auth commands ───

def _get_api_url() -> str:
    """Resolve API URL from env var or default."""
    return os.environ.get("FORITHMUS_API_URL", "https://research.forithmus.com/api")

@app.command()
def login():
    """Authenticate with the Forithmus Research Hub via browser."""
    print_banner(console)
    url = _get_api_url()
    login_cmd(url)


@app.command()
def logout():
    """Clear stored credentials."""
    logout_cmd()
    fori.bye()


@app.command()
def whoami():
    """Show current user info and connection status."""
    whoami_cmd()


# ─── Challenge commands ───

@app.command()
def challenges():
    """List challenges you've joined."""
    _require_auth()
    data = api_get("/challenges?mine=true&limit=100")
    items = data.get("items", data) if isinstance(data, dict) else data
    if not items:
        console.print("[dim]No challenges found.[/dim]")
        return

    table = Table(title="My Challenges", border_style="dim")
    table.add_column("Title", style="bold")
    table.add_column("Slug", style="dim")
    table.add_column("Role", style="cyan")
    table.add_column("Status")
    table.add_column("Submissions", justify="right")

    for ch in items:
        status_style = {"open": "green", "draft": "yellow", "closed": "red"}.get(ch.get("status", ""), "")
        table.add_row(
            ch["title"],
            ch["slug"],
            ch.get("my_role", ""),
            f"[{status_style}]{ch.get('status', '')}[/{status_style}]",
            str(ch.get("submission_count", 0)),
        )

    console.print(table)


@app.command()
def phases(
    challenge_slug: str = typer.Argument(
        None,
        help="Challenge slug (defaults to the one from your local config)",
    ),
):
    """List phases for a challenge, with edition and submission status.

    The row marked * is the one CLI commands will target by default
    (current edition + matching your init'd phase name).
    """
    _require_auth()
    if not challenge_slug:
        config = load_config()
        if not config:
            console.print("[red]No local config. Pass a challenge slug or run `forithmus init` first.[/red]")
            raise typer.Exit(1)
        challenge_slug = config["challenge"]

    try:
        ch = api_get(f"/challenges/{challenge_slug}") or {}
        phs = api_get(f"/challenges/{challenge_slug}/phases") or []
    except Exception as e:
        console.print(f"[red]Could not fetch phases: {e}[/red]")
        raise typer.Exit(1)

    if not phs:
        console.print(f"[dim]No phases for {challenge_slug}.[/dim]")
        return

    current_edition = ch.get("current_edition")

    # Compute which phase is the "default target" so we can mark it with *.
    config = load_config() or {}
    try:
        default_phase_id, _ = _select_phase(challenge_slug, {**config, "challenge": challenge_slug}, None)
    except Exception:
        default_phase_id = None

    table = Table(title=f"Phases — {ch.get('title', challenge_slug)}", border_style="dim")
    table.add_column("", width=1)  # marker
    table.add_column("Slug", style="bold")
    table.add_column("Name")
    table.add_column("Edition")
    table.add_column("Submissions")
    table.add_column("Type", style="dim")
    table.add_column("ID", style="dim")

    for p in phs:
        edition = p.get("edition") or "-"
        is_current = current_edition and edition == current_edition
        edition_style = "green" if is_current else "dim"
        enabled = p.get("submissions_enabled")
        enabled_text = "[green]open[/green]" if enabled else "[red]closed[/red]"
        marker = "[bold cyan]*[/bold cyan]" if p.get("id") == default_phase_id else " "
        table.add_row(
            marker,
            p.get("slug", ""),
            p.get("name", ""),
            f"[{edition_style}]{edition}[/{edition_style}]",
            enabled_text,
            p.get("submission_type", ""),
            p.get("id", "")[:8] + "...",
        )

    console.print(table)
    if current_edition:
        console.print(f"[dim]Current edition: {current_edition}. * marks the default target for CLI commands.[/dim]")


@app.command()
def init(
    challenge_slug: str = typer.Argument(help="Challenge slug"),
    phase: str = typer.Option(None, "--phase", "-p", help="Phase slug (defaults to the default phase)"),
):
    """Download challenge schema and set up local config for testing."""
    _require_auth()
    print_header(console, "Initializing", f"Challenge: {challenge_slug}")

    challenge = api_get(f"/challenges/{challenge_slug}")
    if not challenge:
        console.print(f"[red]Challenge '{challenge_slug}' not found.[/red]")
        raise typer.Exit(1)

    phases = api_get(f"/challenges/{challenge_slug}/phases")
    if not phases:
        console.print("[red]No phases found.[/red]")
        raise typer.Exit(1)

    # Find target phase
    if phase:
        target = next((p for p in phases if p["slug"] == phase), None)
    else:
        target = next((p for p in phases if p.get("is_default")), phases[0])

    if not target:
        slugs = ", ".join(p["slug"] for p in phases)
        console.print(f"[red]Phase '{phase}' not found. Available: {slugs}[/red]")
        raise typer.Exit(1)

    # Clear old test data if switching challenges
    import shutil
    old_config = load_config()
    if old_config and old_config.get("challenge") != challenge_slug:
        test_data = Path(".forithmus") / "test_data"
        if test_data.exists():
            shutil.rmtree(test_data)
            console.print("[dim]Cleared old test data from previous challenge.[/dim]")

    config = {
        "challenge": challenge_slug,
        "challenge_title": challenge.get("title", ""),
        "phase": target["slug"],
        "phase_id": target["id"],
        "phase_name": target.get("name", ""),
        "submission_type": target["submission_type"],
        "data_schema": target.get("data_schema", {}),
        "ranking_config": target.get("ranking_config", {}),
    }
    save_config(config)

    console.print(f"[green]Initialized:[/green] {challenge['title']}")
    console.print(f"  Phase: {target['name']} ({target['submission_type']})")
    console.print(f"  Config: .forithmus/config.json")

    schema = config["data_schema"]
    if schema:
        sections = [k for k in ("input", "output", "ground_truth", "prediction") if schema.get(k)]
        console.print(f"  Schema: {', '.join(sections)}")
    else:
        console.print("  [yellow]No data schema defined yet.[/yellow]")

    console.print()
    console.print("[dim]Next steps:[/dim]")
    console.print("  forithmus generate        Generate dummy test data")
    console.print("  forithmus test <image>     Test your Docker container locally")
    console.print("  forithmus submit <file>    Submit to the platform")


@app.command()
def generate():
    """Generate dummy test data from the challenge schema."""
    config = _require_config()
    schema = config.get("data_schema", {})
    if not schema:
        console.print("[yellow]No data schema. Nothing to generate.[/yellow]")
        raise typer.Exit(1)

    print_header(console, "Generating dummy data", config.get("challenge_title", ""))

    fori.say(THINKING, "Generating mock data...")
    input_dir, gt_dir = generate_dummy_data(schema)
    console.print(f"[green]Input data:[/green]  {input_dir}")
    if gt_dir:
        console.print(f"[green]Ground truth:[/green] {gt_dir}")

    # Count generated files
    input_count = sum(1 for _ in Path(input_dir).rglob("*") if _.is_file())
    console.print(f"\n  {input_count} files generated")
    fori.happy(f"{input_count} mock files ready!")
    console.print(f"[dim]Test your container:[/dim]")
    console.print(f"  forithmus test <your-docker-image>")


# ─── Test & validate commands ───

@app.command()
def test(
    image: str = typer.Argument(help="Docker image name or .tar.gz path"),
    timeout: int = typer.Option(300, "--timeout", "-t", help="Timeout in seconds"),
):
    """Run and validate your Docker container locally against the challenge schema."""
    config = _require_config()
    schema = config.get("data_schema", {})

    print_header(console, "Local test", f"{image}")

    # Step 1: Generate dummy data
    console.print("\n[bold cyan]Step 1/3[/bold cyan] Generating dummy input data...")
    input_dir, gt_dir = generate_dummy_data(schema) if schema else (None, None)
    if not input_dir:
        console.print("[yellow]No schema, using empty input.[/yellow]")
        import tempfile
        input_dir = tempfile.mkdtemp(prefix="forithmus_input_")

    input_count = sum(1 for _ in Path(input_dir).rglob("*") if _.is_file())
    console.print(f"  {input_count} input files generated")

    # Step 2: Run Docker
    console.print(f"\n[bold cyan]Step 2/3[/bold cyan] Running container (timeout: {timeout}s)...")
    output_dir, success, logs = run_docker_test(image, input_dir, timeout)

    if logs:
        # Show last few lines of logs
        lines = logs.strip().split("\n")
        for line in lines[-10:]:
            console.print(f"  [dim]{line}[/dim]")

    if not success:
        fori.sad("Container failed. Check the logs above.")
        raise typer.Exit(1)

    console.print(f"  [green]Container exited successfully[/green]")

    # Step 3: Validate output
    console.print(f"\n[bold cyan]Step 3/3[/bold cyan] Validating output...")
    output_count = sum(1 for _ in Path(output_dir).rglob("*") if _.is_file())
    console.print(f"  {output_count} output files found")

    if schema:
        errors = validate_output(output_dir, schema, input_dir)
        if errors:
            fori.sad(f"Found {len(errors)} issue{'s' if len(errors) > 1 else ''} with your output!")
            console.print()
            for i, err in enumerate(errors[:10], 1):
                console.print(f"  [red]{i}.[/red] {err}")
                console.print()
            if len(errors) > 10:
                console.print(f"  [dim]... and {len(errors) - 10} more issues[/dim]")
            console.print("[dim]Fix the issues above and run the test again.[/dim]")
            raise typer.Exit(1)
        console.print(f"  [green]All checks passed[/green]")
    else:
        console.print(f"  [yellow]No schema to validate against[/yellow]")

    fori.celebrate("Ready to submit!")
    console.print(f"  forithmus submit {image}")


@app.command()
def validate(
    output_dir: str = typer.Argument(help="Path to output directory to validate"),
    input_dir: str = typer.Option(None, "--input", "-i", help="Path to input directory (for case count matching)"),
):
    """Validate output files against the challenge schema (without running Docker)."""
    config = _require_config()
    schema = config.get("data_schema", {})
    if not schema:
        console.print("[yellow]No data schema to validate against.[/yellow]")
        return

    errors = validate_output(output_dir, schema, input_dir)

    if errors:
        fori.sad(f"Found {len(errors)} issue{'s' if len(errors) > 1 else ''} with your output!")
        console.print()
        for i, err in enumerate(errors, 1):
            console.print(f"  [red]{i}.[/red] {err}")
            console.print()
        console.print("[dim]Fix the issues above and validate again.[/dim]")
        raise typer.Exit(1)

    fori.celebrate("Output looks perfect!")


# ─── Submit command ───

@app.command()
def submit(
    target: str = typer.Argument(help="Docker .tar.gz path or prediction file"),
    tier: str = typer.Option("cpu-4", "--tier",
        help="Compute tier: cpu-4, gpu-t4, gpu-l4, gpu-v100, gpu-a100. See `forithmus tiers`."),
    time_budget: int = typer.Option(60, "--time-budget", "-t", help="Time budget in minutes"),
    description: str = typer.Option("", "--desc", "-d", help="Submission description"),
    phase: str = typer.Option(None, "--phase", "-p",
        help="Phase slug or UUID (overrides the one stored by `init`). Prevents "
             "accidentally submitting to the wrong phase/edition."),
):
    """Submit a Docker container or prediction file to the platform."""
    _require_auth()
    config = _require_config()

    slug = config["challenge"]
    sub_type = config.get("submission_type", "docker")

    # Always resolve the target phase at runtime. Default is the current-edition
    # phase on the server; --phase overrides. Prevents a stale local config from
    # silently submitting to a closed legacy phase (prior incident: 8.7 GB
    # upload rejected at the "create submission" step because init had cached
    # the 2025 phase).
    phase_id, phase_name = _select_phase(slug, config, phase)

    # Extra guard: even if user passed --phase explicitly, block submit if it's
    # from a closed edition.
    _check_phase_open(slug, phase_id)

    print_header(console, "Submitting", f"{config.get('challenge_title', slug)} / {phase_name}")
    fori.say(THINKING, "Let me check your submission...")

    filepath = Path(target)
    if not filepath.exists():
        console.print(f"[red]File not found: {target}[/red]")
        raise typer.Exit(1)

    size_mb = filepath.stat().st_size / (1024 * 1024)
    console.print(f"  File: {filepath.name} ({size_mb:.0f} MB)")
    console.print(f"  Type: {sub_type}")
    console.print(f"  Phase: {phase_name} ({phase_id[:8]}...)")
    if sub_type == "docker":
        console.print(f"  Tier: {tier}, Budget: {time_budget} min")

    if sub_type == "docker":
        # Direct-to-GCS upload (same flow as data uploads): no backend bandwidth
        from forithmus_cli.api import upload_docker_direct
        console.print(f"\n[bold cyan]Step 1/2[/bold cyan] Uploading directly to GCS...")
        resp = upload_docker_direct(
            path=target,
            slug=slug,
            phase_id=phase_id,
            desc="Uploading Docker image",
        )
        if not resp:
            fori.sad("Upload failed.")
            raise typer.Exit(1)

        gcs_key = resp.get("gcs_key")
        upload_id = resp.get("upload_id")
        console.print(f"  Upload ID: {upload_id}")
        console.print(f"  [green]Scan passed[/green]")

        # Step 2: Create submission
        console.print(f"\n[bold cyan]Step 2/2[/bold cyan] Creating submission...")
        from forithmus_cli.auth import get_api_url
        import httpx
        url = get_api_url()
        from forithmus_cli.api import _headers
        res = httpx.post(
            f"{url}/challenges/{slug}/submissions/upload-docker",
            headers=_headers(),
            data={
                "phase_id": phase_id,
                "gcs_key": gcs_key,
                "tier": tier,
                "time_budget_minutes": str(time_budget),
                "description": description,
            },
            timeout=30,
        )
        if res.status_code >= 400:
            detail = "Submission failed"
            try:
                detail = res.json().get("detail", detail)
            except Exception:
                pass
            console.print(f"[red]Error: {detail}[/red]")
            raise typer.Exit(1)

        sub = res.json()
        fori.celebrate("Submitted! Now let's see how it scores!")
        console.print(f"  ID: {sub.get('id', '')}")
        console.print(f"  Status: {sub.get('status', '')}")

    else:
        # File submission: direct upload
        console.print(f"\n[bold cyan]Uploading prediction file...[/bold cyan]")
        resp = upload_file(
            target,
            f"/challenges/{slug}/submissions/upload-file",
            field_name="file",
            extra_fields={"phase_id": phase_id, "description": description},
            desc="Uploading predictions",
        )
        if not resp:
            raise typer.Exit(1)
        sub = resp
        console.print(f"  [green]Submitted![/green]")
        console.print(f"  ID: {sub.get('id', '')}")

    from forithmus_cli.auth import get_api_url, _get_frontend_url
    base = _get_frontend_url(get_api_url())
    console.print(f"\n[dim]View results at: {base}/challenges/{slug}/submissions/{sub.get('id', '')}[/dim]")


# ─── Host data upload commands ───

@app.command("upload-data")
def upload_data(
    file: str = typer.Argument(help="Test data ZIP file"),
    phase: str = typer.Option(None, "--phase", "-p",
        help="Phase slug or UUID (overrides current-edition default)."),
):
    """Upload test data for a phase (host only).

    Defaults to the current-edition phase. Pass --phase to target a different
    one (e.g. `--phase validation`). Supports multi-hundred-GB files."""
    from forithmus_cli.api import upload_direct_to_gcs
    _require_auth()
    config = _require_config()
    slug = config["challenge"]
    phase_id, phase_name = _select_phase(slug, config, phase)

    print_header(console, "Upload test data", phase_name)
    resp = upload_direct_to_gcs(
        file, data_type="test-data", slug=slug, phase_id=phase_id,
        desc="Uploading test data",
    )
    if resp:
        fori.happy("Test data uploaded!")
        console.print(f"[dim]Check status: forithmus status[/dim]")
    else:
        fori.sad("Upload failed. Check your connection and file path.")
        raise typer.Exit(1)


@app.command("upload-gt")
def upload_gt(
    file: str = typer.Argument(help="Ground truth ZIP file"),
    phase: str = typer.Option(None, "--phase", "-p",
        help="Phase slug or UUID (overrides current-edition default)."),
):
    """Upload ground truth for a phase (host only).

    Defaults to the current-edition phase. Pass --phase to target a different one."""
    from forithmus_cli.api import upload_direct_to_gcs
    _require_auth()
    config = _require_config()
    slug = config["challenge"]
    phase_id, phase_name = _select_phase(slug, config, phase)

    print_header(console, "Upload ground truth", phase_name)
    resp = upload_direct_to_gcs(
        file, data_type="ground-truth", slug=slug, phase_id=phase_id,
        desc="Uploading ground truth",
    )
    if resp:
        fori.happy("Ground truth uploaded!")
        console.print(f"[dim]Check status: forithmus status[/dim]")
    else:
        fori.sad("Upload failed. Check your connection and file path.")
        raise typer.Exit(1)


@app.command("upload-eval")
def upload_eval(
    file: str = typer.Argument(help="Evaluation container .tar.gz"),
    phase: str = typer.Option(None, "--phase", "-p",
        help="Phase slug or UUID (overrides current-edition default)."),
):
    """Upload evaluation container (.tar.gz) for a phase (host only).

    Defaults to the current-edition phase. Pass --phase to target a different one."""
    from forithmus_cli.api import upload_direct_to_gcs
    _require_auth()
    config = _require_config()
    slug = config["challenge"]
    phase_id, phase_name = _select_phase(slug, config, phase)

    print_header(console, "Upload evaluation container", phase_name)
    resp = upload_direct_to_gcs(
        file, data_type="eval-container", slug=slug, phase_id=phase_id,
        desc="Uploading evaluation container",
    )
    if resp:
        fori.happy("Eval container uploaded!")
        console.print(f"[dim]Check status: forithmus status[/dim]")
    else:
        fori.sad("Upload failed. Check your connection and file path.")
        raise typer.Exit(1)


@app.command()
def status():
    """Check data upload status for the current phase."""
    _require_auth()
    config = _require_config()
    slug = config["challenge"]
    phase_id = config["phase_id"]

    print_header(console, "Phase status", f"{config.get('challenge_title', slug)} / {config.get('phase_name', '')}")

    data = api_get(f"/challenges/{slug}/phases/{phase_id}/data/status")
    if not data:
        console.print("[red]Failed to fetch status.[/red]")
        return

    for key in ("test_data", "ground_truth", "eval_container"):
        info = data.get(key, {})
        uploaded = info.get("uploaded", False)
        status_val = info.get("processing_status", "")
        icon = "[green]OK[/green]" if uploaded else "[red]Missing[/red]"
        label = key.replace("_", " ").title()
        extra = f" ({status_val})" if status_val and status_val != "complete" else ""
        console.print(f"  {icon} {label}{extra}")

    # Also check readiness
    readiness = api_get(f"/challenges/{slug}/phases/{phase_id}/readiness")
    if readiness:
        console.print()
        ready = readiness.get("ready", False)
        if ready:
            console.print("[green bold]Phase is ready to accept submissions.[/green bold]")
        else:
            console.print("[yellow]Phase is not ready:[/yellow]")
            for issue in readiness.get("issues", []):
                console.print(f"  [yellow]![/yellow] {issue}")


@app.command("download-image")
def download_image(
    submission_id: str = typer.Argument(help="Submission ID to download Docker image for"),
    output: str = typer.Option(None, "--output", "-o", help="Output filename (default: <submission_id>.tar)"),
):
    """Download a kept Docker image for a submission (host only).

    Only works when keep_docker_images is enabled on the challenge.
    Limited to once per image per week.
    """
    _require_auth()
    config = _require_config()
    slug = config["challenge"]

    if not output:
        output = f"{submission_id[:12]}.tar"

    print_header(console, "Download Docker image", f"Submission: {submission_id[:12]}...")

    from forithmus_cli.auth import get_api_url
    import httpx

    url = get_api_url()
    from forithmus_cli.api import _headers

    fori.say(THINKING, "Fetching image from registry...")

    try:
        with httpx.stream(
            "GET",
            f"{url}/challenges/{slug}/submissions/{submission_id}/docker-image",
            headers=_headers(),
            timeout=httpx.Timeout(600.0, connect=30.0),
        ) as response:
            if response.status_code == 429:
                fori.sad("Download limit reached. You can download each image once per week.")
                raise typer.Exit(1)
            if response.status_code == 403:
                fori.sad("Docker image download not available for this challenge.")
                raise typer.Exit(1)
            if response.status_code == 404:
                fori.sad("No Docker image found. It may have been deleted or keep_docker_images is disabled.")
                raise typer.Exit(1)
            if response.status_code >= 400:
                detail = "Download failed"
                try:
                    detail = response.json().get("detail", detail)
                except Exception:
                    pass
                fori.sad(detail)
                raise typer.Exit(1)

            # Stream download with progress
            total = int(response.headers.get("content-length", 0))
            from rich.progress import Progress, BarColumn, TextColumn, DownloadColumn, TransferSpeedColumn

            with Progress(
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                DownloadColumn(),
                TransferSpeedColumn(),
                console=console,
            ) as progress:
                task = progress.add_task("Downloading", total=total or None)
                with open(output, "wb") as f:
                    for chunk in response.iter_bytes(chunk_size=1024 * 1024):
                        f.write(chunk)
                        progress.update(task, advance=len(chunk))

        size_mb = os.path.getsize(output) / (1024 * 1024)
        fori.happy(f"Downloaded! {size_mb:.0f} MB saved to {output}")
        console.print(f"\n[dim]Load with: docker load -i {output}[/dim]")

    except httpx.RequestError as e:
        fori.sad(f"Connection error: {e}")
        raise typer.Exit(1)


@app.command()
def tiers():
    """List compute tiers available for submissions (with price per hour)."""
    _require_auth()
    try:
        data = api_get("/resources") or []
    except Exception as e:
        console.print(f"[red]Could not fetch tiers: {e}[/red]")
        raise typer.Exit(1)

    if not data:
        console.print("[dim]No tiers available.[/dim]")
        return

    table = Table(title="Compute tiers", border_style="dim")
    table.add_column("Slug", style="bold")
    table.add_column("Name")
    table.add_column("Specs", style="dim")
    table.add_column("$/hr", justify="right", style="cyan")

    for t in data:
        price = t.get("price_per_hour")
        price_str = f"${price:.2f}" if isinstance(price, (int, float)) else "-"
        table.add_row(
            t.get("slug", ""),
            t.get("name", ""),
            t.get("specs", ""),
            price_str,
        )
    console.print(table)


@app.command()
def version():
    """Show CLI version."""
    print_banner(console)


    fori.bye()


def _cli():
    """Entry point with banner on no-args."""
    if len(sys.argv) == 1:
        print_banner(console)
    app()


if __name__ == "__main__":
    _cli()
