"""
Fori: the Forithmus CLI buddy.

A small medical AI robot companion that reacts to CLI events.
Wears a stethoscope and has a medical cross on its chest.
"""
from __future__ import annotations

import random
import sys
import threading
from rich.console import Console

# ── Fori the medical AI bot ──
# A small robot with antenna, screen face, chest, and arms.
#
#      _|_        <- antenna
#     [o.o]       <- screen face
#    -|___|-      <- body, arms
#      | |        <- legs
#

# Each frame uses | as a fixed left margin guide (stripped before display).

def _f(s: str) -> str:
    """Strip the leading pipe margin from frame lines."""
    lines = s.strip("\n").split("\n")
    return "\n".join(line.lstrip("|") for line in lines)

IDLE = _f("""
|     _|_
|    [o.o]
|   -|___|=-
|     | |
""")

HAPPY = _f("""
|     _|_
|    [^.^]
|   -|___|=-
|     | |
""")

THINKING = _f("""
|     _|_    ?
|    [o.o]
|   -|___|=-
|     | |
""")

WORKING = [_f("""
|     _|_
|    [o.-]   .
|   -|___|=-
|     | |
"""), _f("""
|     _|_
|    [-.o]    .
|   -|___|=-
|     | |
"""), _f("""
|     _|_
|    [o.-]     .
|   -|___|=-
|     | |
"""), _f("""
|     _|_
|    [-.o]      .
|   -|___|=-
|     | |
""")]

CELEBRATE = [_f("""
|     \\|/
|    [^o^]   *
|   \\|___|=/
|     | |
"""), _f("""
|     \\|/    *
|    [^o^]  *
|   \\|___|=/
|     | |
"""), _f("""
|     \\|/   *
|    [^o^]   *
|   \\|___|=/
|     | |
"""), _f("""
|     \\|/  *
|    [^o^]  *
|   \\|___|=/
|     | |
""")]

SAD = _f("""
|     _|_
|    [;.;]
|   -|___|=-
|     | |
""")

SHOCKED = _f("""
|     _!_
|    [O.O]  !!
|   -|___|=-
|     | |
""")

SLEEPING = [_f("""
|     _|_
|    [-.-]  z
|   -|___|=-
|     | |
"""), _f("""
|     _|_    z
|    [-.-]
|   -|___|=-
|     | |
"""), _f("""
|     _|_     z
|    [-.-]
|   -|___|=-
|     | |
"""), _f("""
|     _|_      z
|    [-.-]
|   -|___|=-
|     | |
""")]

SCANNING = [_f("""
|     _|_
|    [o.o]  [=   ]
|   -|___|=-
|     | |
"""), _f("""
|     _|_
|    [o.o]  [==  ]
|   -|___|=-
|     | |
"""), _f("""
|     _|_
|    [o.o]  [=== ]
|   -|___|=-
|     | |
"""), _f("""
|     _|_
|    [^.^]  [====]
|   -|___|=-
|     | |
""")]

UPLOADING = [_f("""
|     _|_
|    [o.o]  >>  .
|   -|___|=-
|     | |
"""), _f("""
|     _|_
|    [o.o]  >> ..
|   -|___|=-
|     | |
"""), _f("""
|     _|_
|    [o.o]  >>...
|   -|___|=-
|     | |
"""), _f("""
|     _|_
|    [^.^]  >> OK
|   -|___|=-
|     | |
""")]

# ── Fori's dialogue ──

GREETINGS = [
    "Ready for some medical AI research?",
    "Welcome back, researcher!",
    "Let's push the boundaries of medical imaging!",
    "Hi! What are we diagnosing today?",
    "Neural networks warmed up. Let's go!",
]

UPLOAD_START = [
    "Uploading to the secure cloud...",
    "Sending data to the research hub!",
    "Transmitting... stay HIPAA compliant!",
    "Beaming up your research data!",
]

UPLOAD_DONE = [
    "Upload complete! Data is safe.",
    "All done! Ready for processing.",
    "Files secured in the research hub!",
]

SUBMIT_START = [
    "Submitting your model... let's see those metrics!",
    "Launching your algorithm!",
    "Time to see what your neural net learned!",
]

SUCCESS = [
    "Excellent results, researcher!",
    "Pipeline passed! Great work!",
    "All checks cleared!",
    "Your model is looking good!",
]

FAILURE = [
    "Something went wrong... let's debug!",
    "Hmm, check the error output above.",
    "Don't worry, every model needs iterations!",
    "Let's look at those logs together.",
]

WAITING = [
    "Processing... analyzing the data...",
    "Running inference... *beep boop*",
    "Computing metrics... patience!",
    "Evaluating your predictions...",
]

GOODBYE = [
    "See you next time, researcher!",
    "Goodbye! May your dice scores be high!",
    "Until next time! Keep innovating!",
    "Shutting down... good luck with your paper!",
]


class Fori:
    """The Forithmus medical AI buddy."""

    def __init__(self, console: Console | None = None):
        self.console = console or Console()
        self._anim_thread: threading.Thread | None = None
        self._anim_stop = threading.Event()

    def _frame_height(self, face: str) -> int:
        """Count lines in a face frame (for cursor movement)."""
        return len(face.strip("\n").split("\n")) + 2  # +2 for message line and blank

    def say(self, face: str, message: str | None = None):
        """Show Fori with a face and optional message."""
        from rich.text import Text
        lines = face.strip("\n").split("\n")
        art = "\n".join(f"  {line}" for line in lines)
        self.console.print(Text(art, style="cyan"))
        if message:
            self.console.print(f"  [dim italic]{message}[/dim italic]")
        self.console.print()

    def greet(self):
        """Animated greeting: robot boots up and waves."""
        from rich.text import Text
        import time
        msg = random.choice(GREETINGS)
        # All frames must have exactly 4 lines for consistent cursor movement
        boot_seq = [
            (_f("|\n|     _|_\n|\n|"), ""),
            (_f("|\n|     _|_\n|    [   ]\n|"), ""),
            (_f("|     _|_\n|    [-.-]\n|   -|___|=-\n|"), "Booting up..."),
            (_f("|     _|_\n|    [-.-]\n|   -|___|=-\n|     | |"), "Systems online..."),
            (_f("|     _|_\n|    [o.o]\n|   -|___|=-\n|     | |"), msg),
        ]
        # height = 4 art lines + 1 message + 1 blank = 6
        height = 6
        for i, (frame, boot_msg) in enumerate(boot_seq):
            if i > 0:
                sys.stdout.write(f"\033[{height}A\033[J")
                sys.stdout.flush()
            lines = frame.strip("\n").split("\n")
            # Pad to 4 lines
            while len(lines) < 4:
                lines.append("")
            art = "\n".join(f"  {line}" for line in lines)
            self.console.print(Text(art, style="cyan"))
            self.console.print(f"  [dim italic]{boot_msg}[/dim italic]" if boot_msg else "")
            self.console.print()
            time.sleep(0.3)

    def happy(self, message: str | None = None):
        self.say(HAPPY, message or random.choice(SUCCESS))

    def sad(self, message: str | None = None):
        self.say(SAD, message or random.choice(FAILURE))

    def shocked(self, message: str | None = None):
        self.say(SHOCKED, message)

    def celebrate(self, message: str | None = None):
        """Animated celebration with sparks flying around the robot."""
        from rich.text import Text
        import time
        msg = message or random.choice(SUCCESS)
        height = self._frame_height(CELEBRATE[0])
        for i in range(8):
            if i > 0:
                sys.stdout.write(f"\033[{height}A\033[J")
                sys.stdout.flush()
            frame = CELEBRATE[i % len(CELEBRATE)]
            lines = frame.strip("\n").split("\n")
            art = "\n".join(f"  {line}" for line in lines)
            self.console.print(Text(art, style="cyan"))
            self.console.print(f"  [dim italic]{msg}[/dim italic]")
            self.console.print()
            time.sleep(0.2)
        # Leave final frame visible


    def bye(self):
        """Animated goodbye with z's floating up."""
        from rich.text import Text
        import time
        msg = random.choice(GOODBYE)
        height = self._frame_height(SLEEPING[0])
        for i in range(8):
            if i > 0:
                sys.stdout.write(f"\033[{height}A\033[J")
                sys.stdout.flush()
            frame = SLEEPING[i % len(SLEEPING)]
            lines = frame.strip("\n").split("\n")
            art = "\n".join(f"  {line}" for line in lines)
            self.console.print(Text(art, style="cyan"))
            self.console.print(f"  [dim italic]{msg}[/dim italic]")
            self.console.print()
            time.sleep(0.3)

    # ── Full robot animated spinner ──
    # Redraws the full robot in place using ANSI cursor movement.
    # Each frame shows the robot with different eyes/effects.

    def _animate(self, frames: list[str], message: str):
        """Run full-robot animation in a background thread."""
        self._anim_stop.clear()
        height = self._frame_height(frames[0])

        def loop():
            from rich.text import Text
            idx = 0
            while not self._anim_stop.is_set():
                if idx > 0:
                    # Move cursor up and clear previous frame
                    sys.stdout.write(f"\033[{height}A\033[J")
                    sys.stdout.flush()
                lines = frames[idx % len(frames)].strip("\n").split("\n")
                art = "\n".join(f"  {line}" for line in lines)
                self.console.print(Text(art, style="cyan"))
                self.console.print(f"  [dim italic]{message}[/dim italic]")
                self.console.print()
                idx += 1
                self._anim_stop.wait(0.35)

        self._anim_thread = threading.Thread(target=loop, daemon=True)
        self._anim_thread.start()

    def _stop_anim(self, success: bool = True, message: str | None = None):
        """Stop animation and show result face."""
        self._anim_stop.set()
        if self._anim_thread:
            self._anim_thread.join(timeout=1)
            self._anim_thread = None
        # Clear the last frame
        height = self._frame_height(IDLE)
        sys.stdout.write(f"\033[{height}A\033[J")
        sys.stdout.flush()
        if success:
            self.happy(message)
        else:
            self.sad(message)

    def start_working(self, message: str | None = None):
        self._animate(WORKING, message or random.choice(WAITING))

    def stop_working(self, success: bool = True, message: str | None = None):
        self._stop_anim(success, message)

    def start_uploading(self, message: str | None = None):
        self._animate(UPLOADING, message or random.choice(UPLOAD_START))

    def stop_uploading(self, success: bool = True, message: str | None = None):
        self._stop_anim(success, message)

    def start_scanning(self, message: str | None = None):
        self._animate(SCANNING, message or "Scanning for issues...")

    def stop_scanning(self, success: bool = True, message: str | None = None):
        self._stop_anim(success, message)


# ── Global buddy instance ──
fori = Fori()
