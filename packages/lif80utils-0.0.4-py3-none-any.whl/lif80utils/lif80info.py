#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import sys
import argparse
import os

from .lif_error import LifError

from .source import Source

def main ( ) -> int:
    # Parse the command line arguments.
    parser = argparse.ArgumentParser \
        ( formatter_class = argparse.ArgumentDefaultsHelpFormatter
        , description = 'Prints information about a LIF volume'
        )

    # Optional with MASS STORAGE IS
    parser.add_argument( "source", nargs='?', help=":lifpath")

    # codepage: 'ascii', 'cp1252', 'utf-8', 'focal'
    parser.add_argument( "-c", "--codepage", help="codepage", default="focal")
    parser.add_argument( "-m", "--mass-storage", help="MASS STORAGE IS", default=os.getenv( 'MASS_STORAGE', ":."))

    parser.add_argument( "-v", "--verbose", help="verbose mode", action="store_true")
    parser.add_argument( "-x", "--extended", help="extended mode", action="store_true")

    args = parser.parse_args( )

    try:
        # info reads only from a source.
        source = Source( args.source, args)

        # info does not take a file name.
        if source.file_name_dec:
            raise LifError( 126) # "Error 126 : MSUS"

        source.open( )

        # Get the LIF Volume Sector.
        v = source.vol.v

        print( f"      lif_identifier: 0x{v.lif_identifier( ):04x}")
        print( f" lif_identifier_3000: 0x{v.lif_identifier_3000( ):04x}")
        print( f"         lif_version: {v.lif_version( )}")

        print( f'        Volume label: "{v.vol_label( ).decode( args.codepage)}"')
        print( f"Creation date & time: {v.init_date( )}")

        print( f"     dir_start_block: {v.dir_start_block( )}")
        print( f"      no_dir_sectors: {v.no_dir_sectors( )}")

        print( f"            surfaces: {v.surfaces( )}")
        print( f"  tracks_per_surface: {v.tracks_per_surface( )}")
        print( f"   Sectors per track: {v.sectors_per_track( )}")

    except LifError as e:
        print( e)
        return e.code

    return 0
