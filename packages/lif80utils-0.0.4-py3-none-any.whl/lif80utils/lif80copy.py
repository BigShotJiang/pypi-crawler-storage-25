#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import sys
import argparse
import os

from .lif_error import LifError

from .source import Source
from .target import Target

def _copy_file ( source, target):

    if not source.find_dir_entry( ):
        raise LifError( 67) # File not found: "Error 67 : FILE NAME".

    # We need some additional information from the source file.
    target.fix_from( source)

    if target.find_dir_entry( ):
        # if args.force:
        #     target.purge( )
        # else
        raise LifError( 63) # File exists: "Error 63 : DUP NAME".

    file_size = source.file_size( )

    target.find_free_spot( file_size)
    target.write_file( source)

    return


def main ( ) -> int:
    # Parse the command line arguments.
    parser = argparse.ArgumentParser \
        ( formatter_class = argparse.ArgumentDefaultsHelpFormatter
        , description = 'Copy a named file, or all files from a directory, to destination'
        )

    parser.add_argument( "source")
    parser.add_argument( "destination")

    # codepage: 'ascii', 'cp1252', 'utf-8', 'focal'
    parser.add_argument( "-c", "--codepage", help="codepage", default="focal")
    parser.add_argument( "-m", "--mass-storage", help="MASS STORAGE IS", default=os.getenv( 'MASS_STORAGE', ":."))

    parser.add_argument( "-v", "--verbose", help="verbose mode", action="store_true")
    parser.add_argument( "-x", "--extended", help="extended mode", action="store_true")

    args = parser.parse_args( )

    try:
        # Instantiate source and target.
        source = Source( args.source, args)
        source.open( )

        target = Target( args.destination, args)
        target.open( )

        # Source and destination specifiers do not have to be the same.
        # That will fail with "Error 63 : DUP NAME" (File exists) anyway.

        if not source.file_name_dec:
            # Copy all files.
            if args.verbose:
                print( "copy all")

            if target.file_name_dec:
                raise LifError( 126) # "Error 126 : MSUS"

            for d in source.get_dir_entries( ):
                if args.verbose:
                    print( f"{d.file_name( ).decode( args.codepage):10}  {d.file_type( ):04X}  {d.bytes_per_record( ):5}  {d.file_length( ):5}  {d.file_start( ):5}  {d.bytes_per_file( ):5}  {d.bytes_per_record( ) * d.file_length( ):5}  {d.creation_date( )}")

                source.file_name_dec = d.file_name( ).decode( args.codepage)
                source.file_name = d.file_name( )
                target.file_name_dec = d.file_name( ).decode( args.codepage)
                target.file_name = d.file_name( )

                _copy_file( source, target)

        else:
            # Copy specified file.
            _copy_file( source, target)

    except LifError as e:
        print( e)
        return e.code

    return 0
