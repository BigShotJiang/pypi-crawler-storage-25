"""TUI screens (history viewers)."""
