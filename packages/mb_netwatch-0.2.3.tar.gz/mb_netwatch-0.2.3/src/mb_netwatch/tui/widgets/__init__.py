"""TUI custom widgets."""
