"""TUI adapter."""
