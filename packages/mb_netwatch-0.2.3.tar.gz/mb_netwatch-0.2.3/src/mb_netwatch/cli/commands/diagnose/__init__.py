"""On-demand diagnostic commands."""
