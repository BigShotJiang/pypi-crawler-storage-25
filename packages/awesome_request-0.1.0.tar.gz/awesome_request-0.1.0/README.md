# awesome_request

A simple and elegant HTTP client for Python — zero dependencies, pure stdlib.

## Installation

```bash
pip install awesome_request
```

## Quick Start

```python
import awesome_request as ar

# Simple GET
resp = ar.get("https://httpbin.org/get")
print(resp.status_code)  # 200
print(resp.json)         # parsed JSON body

# GET with query parameters
resp = ar.get("https://httpbin.org/get", params={"page": 1, "limit": 20})

# POST JSON
resp = ar.post(
    "https://httpbin.org/post",
    json_data={"name": "Alice", "age": 30},
)
resp.raise_for_status()  # raises HTTPError if 4xx/5xx
print(resp.json)

# POST form data
resp = ar.post(
    "https://httpbin.org/post",
    data={"username": "alice", "password": "secret"},
)

# PUT / PATCH / DELETE
ar.put("https://httpbin.org/put", json_data={"id": 1, "name": "Bob"})
ar.patch("https://httpbin.org/patch", json_data={"name": "Bob"})
ar.delete("https://httpbin.org/delete")
```

## Sessions

Use a `Session` to share a base URL and default headers across multiple requests.

```python
from awesome_request import Session

session = Session(base_url="https://api.example.com", timeout=10)
session.headers["Authorization"] = "Bearer YOUR_TOKEN"

users = session.get("/users").json
post  = session.post("/posts", json_data={"title": "Hello"}).json
```

## API Reference

### Module-level functions

| Function | Description |
|----------|-------------|
| `ar.get(url, *, params, headers, timeout)` | Send GET request |
| `ar.post(url, *, params, headers, data, json_data, timeout)` | Send POST request |
| `ar.put(url, *, ...)` | Send PUT request |
| `ar.patch(url, *, ...)` | Send PATCH request |
| `ar.delete(url, *, params, headers, timeout)` | Send DELETE request |
| `ar.head(url, *, params, headers, timeout)` | Send HEAD request |
| `ar.request(method, url, **kwargs)` | Send any HTTP request |

### `Response` object

| Attribute / Method | Description |
|--------------------|-------------|
| `.status_code` | HTTP status code (int) |
| `.ok` | `True` if status is 2xx |
| `.text` | Body decoded as string |
| `.json` | Body parsed as JSON |
| `.content` | Raw body bytes |
| `.headers` | Response headers dict |
| `.url` | Final URL |
| `.raise_for_status()` | Raise `HTTPError` on 4xx/5xx |

### `Session(base_url, headers, timeout)`

Persistent session for shared config. Has the same `.get()`, `.post()`, `.put()`, `.patch()`, `.delete()`, `.head()`, and `.request()` methods as module level.

## License

MIT
