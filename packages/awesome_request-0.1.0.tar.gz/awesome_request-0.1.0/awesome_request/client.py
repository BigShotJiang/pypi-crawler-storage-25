"""
awesome_request - A simple and elegant HTTP client for Python.
"""

import json
import urllib.request
import urllib.parse
import urllib.error
from typing import Any, Dict, Optional, Union


class Response:
    """Represents an HTTP response."""

    def __init__(self, status_code: int, headers: Dict[str, str], content: bytes, url: str):
        self.status_code = status_code
        self.headers = headers
        self.content = content
        self.url = url
        self.ok = 200 <= status_code < 300

    @property
    def text(self) -> str:
        """Return response body as a string."""
        encoding = self._detect_encoding()
        return self.content.decode(encoding, errors="replace")

    @property
    def json(self) -> Any:
        """Parse response body as JSON."""
        return json.loads(self.text)

    def _detect_encoding(self) -> str:
        content_type = self.headers.get("Content-Type", "")
        if "charset=" in content_type:
            return content_type.split("charset=")[-1].split(";")[0].strip()
        return "utf-8"

    def raise_for_status(self):
        """Raise an exception if the response status code indicates an error."""
        if not self.ok:
            raise HTTPError(f"HTTP Error {self.status_code} for URL: {self.url}", self)

    def __repr__(self):
        return f"<Response [{self.status_code}]>"


class HTTPError(Exception):
    """Raised when an HTTP request returns an error status code."""

    def __init__(self, message: str, response: Optional[Response] = None):
        super().__init__(message)
        self.response = response


class Session:
    """
    An HTTP session that persists headers and base URL across requests.

    Example:
        session = Session(base_url="https://api.example.com")
        session.headers["Authorization"] = "Bearer TOKEN"
        resp = session.get("/users")
    """

    def __init__(
        self,
        base_url: str = "",
        headers: Optional[Dict[str, str]] = None,
        timeout: int = 30,
    ):
        self.base_url = base_url.rstrip("/")
        self.headers: Dict[str, str] = headers or {}
        self.timeout = timeout

    def _build_url(self, url: str) -> str:
        if url.startswith("http://") or url.startswith("https://"):
            return url
        return self.base_url + "/" + url.lstrip("/")

    def request(
        self,
        method: str,
        url: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        data: Optional[Union[Dict, str, bytes]] = None,
        json_data: Optional[Any] = None,
        timeout: Optional[int] = None,
    ) -> Response:
        full_url = self._build_url(url)

        if params:
            query_string = urllib.parse.urlencode(params, doseq=True)
            full_url = f"{full_url}?{query_string}"

        merged_headers = {**self.headers, **(headers or {})}

        body: Optional[bytes] = None
        if json_data is not None:
            body = json.dumps(json_data).encode("utf-8")
            merged_headers.setdefault("Content-Type", "application/json")
        elif isinstance(data, dict):
            body = urllib.parse.urlencode(data).encode("utf-8")
            merged_headers.setdefault("Content-Type", "application/x-www-form-urlencoded")
        elif isinstance(data, str):
            body = data.encode("utf-8")
        elif isinstance(data, bytes):
            body = data

        req = urllib.request.Request(
            full_url,
            data=body,
            headers=merged_headers,
            method=method.upper(),
        )

        try:
            with urllib.request.urlopen(req, timeout=timeout or self.timeout) as resp:
                return Response(
                    status_code=resp.status,
                    headers=dict(resp.headers),
                    content=resp.read(),
                    url=full_url,
                )
        except urllib.error.HTTPError as e:
            content = e.read()
            return Response(
                status_code=e.code,
                headers=dict(e.headers),
                content=content,
                url=full_url,
            )
        except urllib.error.URLError as e:
            raise ConnectionError(f"Failed to connect to {full_url}: {e.reason}") from e

    def get(self, url: str, *, params=None, headers=None, timeout=None) -> Response:
        """Send a GET request."""
        return self.request("GET", url, params=params, headers=headers, timeout=timeout)

    def post(self, url: str, *, params=None, headers=None, data=None, json_data=None, timeout=None) -> Response:
        """Send a POST request."""
        return self.request("POST", url, params=params, headers=headers, data=data, json_data=json_data, timeout=timeout)

    def put(self, url: str, *, params=None, headers=None, data=None, json_data=None, timeout=None) -> Response:
        """Send a PUT request."""
        return self.request("PUT", url, params=params, headers=headers, data=data, json_data=json_data, timeout=timeout)

    def patch(self, url: str, *, params=None, headers=None, data=None, json_data=None, timeout=None) -> Response:
        """Send a PATCH request."""
        return self.request("PATCH", url, params=params, headers=headers, data=data, json_data=json_data, timeout=timeout)

    def delete(self, url: str, *, params=None, headers=None, timeout=None) -> Response:
        """Send a DELETE request."""
        return self.request("DELETE", url, params=params, headers=headers, timeout=timeout)

    def head(self, url: str, *, params=None, headers=None, timeout=None) -> Response:
        """Send a HEAD request."""
        return self.request("HEAD", url, params=params, headers=headers, timeout=timeout)
