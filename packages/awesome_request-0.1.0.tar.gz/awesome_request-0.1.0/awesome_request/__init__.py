"""
awesome_request
~~~~~~~~~~~~~~~

A simple and elegant HTTP client for Python.

Basic usage::

    import awesome_request as ar

    resp = ar.get("https://httpbin.org/get")
    print(resp.status_code)   # 200
    print(resp.json)          # {...}

    resp = ar.post("https://httpbin.org/post", json_data={"key": "value"})
    resp.raise_for_status()

Using a Session::

    session = ar.Session(base_url="https://api.example.com")
    session.headers["Authorization"] = "Bearer TOKEN"
    resp = session.get("/users")

:license: MIT
"""

from .client import Session, Response, HTTPError

__version__ = "0.1.0"
__all__ = ["get", "post", "put", "patch", "delete", "head", "request", "Session", "Response", "HTTPError"]

# ---------------------------------------------------------------------------
# Module-level convenience functions (use a fresh session per call)
# ---------------------------------------------------------------------------

def request(method, url, **kwargs):
    """Send an HTTP request."""
    return Session().request(method, url, **kwargs)


def get(url, *, params=None, headers=None, timeout=30):
    """Send a GET request."""
    return Session(timeout=timeout).get(url, params=params, headers=headers)


def post(url, *, params=None, headers=None, data=None, json_data=None, timeout=30):
    """Send a POST request."""
    return Session(timeout=timeout).post(url, params=params, headers=headers, data=data, json_data=json_data)


def put(url, *, params=None, headers=None, data=None, json_data=None, timeout=30):
    """Send a PUT request."""
    return Session(timeout=timeout).put(url, params=params, headers=headers, data=data, json_data=json_data)


def patch(url, *, params=None, headers=None, data=None, json_data=None, timeout=30):
    """Send a PATCH request."""
    return Session(timeout=timeout).patch(url, params=params, headers=headers, data=data, json_data=json_data)


def delete(url, *, params=None, headers=None, timeout=30):
    """Send a DELETE request."""
    return Session(timeout=timeout).delete(url, params=params, headers=headers)


def head(url, *, params=None, headers=None, timeout=30):
    """Send a HEAD request."""
    return Session(timeout=timeout).head(url, params=params, headers=headers)
