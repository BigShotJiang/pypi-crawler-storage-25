"""Tests for awesome_request."""

import json
import sys
import os
from unittest.mock import patch, MagicMock
from io import BytesIO

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import awesome_request as ar
from awesome_request.client import Response, HTTPError, Session


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_fake_response(status: int, body: bytes, headers: dict = None):
    """Return a mock that mimics urllib's http.client.HTTPResponse."""
    mock_resp = MagicMock()
    mock_resp.status = status
    mock_resp.headers = headers or {"Content-Type": "application/json"}
    mock_resp.read.return_value = body
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)
    return mock_resp


# ---------------------------------------------------------------------------
# Response tests
# ---------------------------------------------------------------------------

class TestResponse:
    def test_ok_true_for_2xx(self):
        r = Response(200, {}, b"", "http://x.com")
        assert r.ok is True

    def test_ok_false_for_4xx(self):
        r = Response(404, {}, b"", "http://x.com")
        assert r.ok is False

    def test_text(self):
        r = Response(200, {"Content-Type": "text/plain"}, b"hello", "http://x.com")
        assert r.text == "hello"

    def test_json_property(self):
        payload = {"key": "value"}
        r = Response(200, {}, json.dumps(payload).encode(), "http://x.com")
        assert r.json == payload

    def test_raise_for_status_ok(self):
        r = Response(200, {}, b"", "http://x.com")
        r.raise_for_status()  # should not raise

    def test_raise_for_status_error(self):
        r = Response(500, {}, b"", "http://x.com")
        try:
            r.raise_for_status()
            assert False, "Expected HTTPError"
        except HTTPError as e:
            assert e.response is r

    def test_repr(self):
        r = Response(201, {}, b"", "http://x.com")
        assert "201" in repr(r)


# ---------------------------------------------------------------------------
# Session tests
# ---------------------------------------------------------------------------

class TestSession:
    def test_build_url_absolute(self):
        s = Session(base_url="https://api.example.com")
        assert s._build_url("https://other.com/path") == "https://other.com/path"

    def test_build_url_relative(self):
        s = Session(base_url="https://api.example.com")
        assert s._build_url("/users") == "https://api.example.com/users"

    @patch("urllib.request.urlopen")
    def test_get_request(self, mock_urlopen):
        body = json.dumps({"result": "ok"}).encode()
        mock_urlopen.return_value = _make_fake_response(200, body)

        resp = ar.get("https://httpbin.org/get")
        assert resp.status_code == 200
        assert resp.json == {"result": "ok"}

    @patch("urllib.request.urlopen")
    def test_post_json(self, mock_urlopen):
        body = json.dumps({"posted": True}).encode()
        mock_urlopen.return_value = _make_fake_response(201, body)

        resp = ar.post("https://httpbin.org/post", json_data={"x": 1})
        assert resp.status_code == 201

    @patch("urllib.request.urlopen")
    def test_session_base_url(self, mock_urlopen):
        body = b'{"ok": true}'
        mock_urlopen.return_value = _make_fake_response(200, body)

        s = Session(base_url="https://api.example.com")
        s.headers["X-Token"] = "abc"
        resp = s.get("/ping")
        assert resp.status_code == 200

    @patch("urllib.request.urlopen")
    def test_params_appended_to_url(self, mock_urlopen):
        body = b'{}'
        mock_urlopen.return_value = _make_fake_response(200, body)

        ar.get("https://example.com/search", params={"q": "python", "page": 2})
        called_url = mock_urlopen.call_args[0][0].full_url
        assert "q=python" in called_url
        assert "page=2" in called_url

    @patch("urllib.request.urlopen")
    def test_delete(self, mock_urlopen):
        mock_urlopen.return_value = _make_fake_response(204, b"")
        resp = ar.delete("https://example.com/items/1")
        assert resp.status_code == 204

    @patch("urllib.request.urlopen")
    def test_put(self, mock_urlopen):
        mock_urlopen.return_value = _make_fake_response(200, b'{"updated": true}')
        resp = ar.put("https://example.com/items/1", json_data={"name": "Bob"})
        assert resp.ok

    @patch("urllib.request.urlopen")
    def test_patch(self, mock_urlopen):
        mock_urlopen.return_value = _make_fake_response(200, b'{}')
        resp = ar.patch("https://example.com/items/1", json_data={"name": "Bob"})
        assert resp.ok

    @patch("urllib.request.urlopen")
    def test_head(self, mock_urlopen):
        mock_urlopen.return_value = _make_fake_response(200, b"")
        resp = ar.head("https://example.com/")
        assert resp.status_code == 200


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
