"""
tests/test_sdk.py
=================
Unit tests for the Daily Life Pharmacy SDK.

Uses the ``responses`` library to mock HTTP calls — no real server needed.

Run::

    pip install pytest responses
    pytest tests/test_sdk.py -v
"""

import json
import pytest

try:
    import responses as resp_lib
    RESPONSES_AVAILABLE = True
except ImportError:
    RESPONSES_AVAILABLE = False

pytestmark = pytest.mark.skipif(
    not RESPONSES_AVAILABLE,
    reason="'responses' library not installed. Run: pip install responses"
)

if RESPONSES_AVAILABLE:
    import responses

from dlp_sdk import (
    DLPClient, AuthenticationError, NotFoundError,
    ValidationError, NetworkError,
    Product, Order, CartTotals, AdminStats,
)

BASE = "http://testserver"


@pytest.fixture
def sdk():
    return DLPClient(BASE, verify_ssl=False)


# ─────────────────────────────────────────────────────────────────────────────
# Health
# ─────────────────────────────────────────────────────────────────────────────

@responses.activate
def test_health(sdk):
    responses.add(responses.GET, f"{BASE}/api/health",
                  json={"status": "ok", "service": "api"}, status=200)
    result = sdk.health()
    assert result["status"] == "ok"


# ─────────────────────────────────────────────────────────────────────────────
# Auth
# ─────────────────────────────────────────────────────────────────────────────

@responses.activate
def test_admin_login_success(sdk):
    responses.add(responses.POST, f"{BASE}/auth/admin/login",
                  json={"success": True}, status=200)
    result = sdk.auth.admin_login("admin", "secret")
    assert result["success"] is True


@responses.activate
def test_admin_login_bad_password(sdk):
    responses.add(responses.POST, f"{BASE}/auth/admin/login",
                  json={"error": "Invalid username or password."}, status=401)
    with pytest.raises(AuthenticationError) as exc_info:
        sdk.auth.admin_login("admin", "wrong")
    assert exc_info.value.status_code == 401


@responses.activate
def test_otp_request(sdk):
    responses.add(responses.POST, f"{BASE}/auth/otp/request",
                  json={"phone": "+8801712345678", "sent": True, "otp": "123456"}, status=200)
    result = sdk.auth.otp_request("+8801712345678")
    assert result.phone == "+8801712345678"
    assert result.otp == "123456"


@responses.activate
def test_otp_verify_valid(sdk):
    responses.add(responses.POST, f"{BASE}/auth/otp/verify",
                  json={"valid": True, "customer_name": "Ahmed Rahman"}, status=200)
    result = sdk.auth.otp_verify("+8801712345678", "123456")
    assert result.valid is True
    assert result.customer_name == "Ahmed Rahman"


@responses.activate
def test_otp_verify_invalid(sdk):
    responses.add(responses.POST, f"{BASE}/auth/otp/verify",
                  json={"valid": False, "reason": "OTP expired."}, status=400)
    with pytest.raises(ValidationError):
        sdk.auth.otp_verify("+8801712345678", "000000")


# ─────────────────────────────────────────────────────────────────────────────
# Catalog
# ─────────────────────────────────────────────────────────────────────────────

PRODUCT_JSON = {
    "id": 1, "slug": "paracetamol-500mg", "name": "Paracetamol 500mg",
    "price": 12.0, "stock": 200, "is_featured": True,
    "category_slug": "painkiller", "category_name": "Painkiller",
    "brand_name": "Square", "badge": "new", "description": "Pain relief.",
    "old_price": 15.0, "rating": 4.8, "review_count": 42, "image_url": None,
}


@responses.activate
def test_list_products(sdk):
    responses.add(responses.GET, f"{BASE}/api/catalog/products",
                  json=[PRODUCT_JSON], status=200)
    products = sdk.catalog.list_products()
    assert len(products) == 1
    p = products[0]
    assert isinstance(p, Product)
    assert p.name == "Paracetamol 500mg"
    assert p.price == 12.0
    assert p.old_price == 15.0


@responses.activate
def test_get_product(sdk):
    responses.add(responses.GET, f"{BASE}/api/catalog/products/1",
                  json=PRODUCT_JSON, status=200)
    p = sdk.catalog.get_product(1)
    assert p.id == 1
    assert p.slug == "paracetamol-500mg"


@responses.activate
def test_get_product_not_found(sdk):
    responses.add(responses.GET, f"{BASE}/api/catalog/products/999",
                  json={"error": "Not found"}, status=404)
    with pytest.raises(NotFoundError):
        sdk.catalog.get_product(999)


# ─────────────────────────────────────────────────────────────────────────────
# Cart
# ─────────────────────────────────────────────────────────────────────────────

CART_JSON = {
    "items": [{"id": 1, "slug": "paracetamol-500mg", "name": "Paracetamol 500mg",
                "price": 12.0, "qty": 2, "stock": 200, "subtotal": 24.0}],
    "subtotal": 24.0, "delivery": 60.0, "discount": 0.0,
    "grand_total": 84.0, "promo_code": None,
}


@responses.activate
def test_cart_add(sdk):
    responses.add(responses.POST, f"{BASE}/api/cart/add",
                  json=CART_JSON, status=200)
    cart = sdk.cart.add(product_id=1, quantity=2)
    assert isinstance(cart, CartTotals)
    assert cart.grand_total == 84.0
    assert len(cart.items) == 1
    assert cart.items[0].qty == 2


@responses.activate
def test_cart_apply_promo(sdk):
    responses.add(responses.POST, f"{BASE}/api/cart/promo",
                  json={"valid": True, "code": "SAVE10",
                        "discount_pct": 10, "discount_amount": 2.4}, status=200)
    result = sdk.cart.apply_promo("SAVE10")
    assert result["valid"] is True
    assert result["discount_amount"] == 2.4


# ─────────────────────────────────────────────────────────────────────────────
# Orders
# ─────────────────────────────────────────────────────────────────────────────

ORDER_JSON = {
    "id": 7, "order_code": "DLP12345678", "status": "Confirmed",
    "customer_name": "Fatima Khanam", "customer_phone": "+8801987654321",
    "delivery_city": "Dhaka", "payment_method": "bKash",
    "subtotal": 24.0, "delivery_fee": 60.0, "discount": 0.0,
    "grand_total": 84.0, "eta": "2–4 hours",
    "items": [{"product_id": 1, "product_name": "Paracetamol 500mg",
               "unit_price": 12.0, "quantity": 2, "subtotal": 24.0}],
    "created_at": "2026-04-06T12:00:00", "updated_at": "2026-04-06T12:00:00",
}


@responses.activate
def test_create_order(sdk):
    responses.add(responses.POST, f"{BASE}/api/orders",
                  json=ORDER_JSON, status=200)
    order = sdk.orders.create(
        name="Fatima Khanam", phone="+8801987654321",
        address="House 7, Mirpur", payment_method="bKash",
    )
    assert isinstance(order, Order)
    assert order.order_code == "DLP12345678"
    assert order.grand_total == 84.0
    assert len(order.items) == 1


@responses.activate
def test_get_order(sdk):
    responses.add(responses.GET, f"{BASE}/api/orders/DLP12345678",
                  json=ORDER_JSON, status=200)
    order = sdk.orders.get("DLP12345678")
    assert order.status == "Confirmed"
    assert order.eta == "2–4 hours"


def test_create_order_bad_payment_method(sdk):
    with pytest.raises(ValueError, match="Invalid payment_method"):
        sdk.orders.create(
            name="Test", phone="+880", address="Dhaka",
            payment_method="CRYPTO",
        )


# ─────────────────────────────────────────────────────────────────────────────
# Admin
# ─────────────────────────────────────────────────────────────────────────────

@responses.activate
def test_admin_stats(sdk):
    responses.add(responses.GET, f"{BASE}/api/admin/stats",
                  json={"order_count": 100, "pending_orders": 5,
                        "product_count": 200, "customer_count": 80,
                        "revenue": 50000.0, "unread_messages": 3}, status=200)
    stats = sdk.admin.stats()
    assert isinstance(stats, AdminStats)
    assert stats.revenue == 50000.0
    assert stats.pending_orders == 5


@responses.activate
def test_admin_stats_forbidden(sdk):
    responses.add(responses.GET, f"{BASE}/api/admin/stats",
                  json={"error": "forbidden"}, status=403)
    from dlp_sdk import AuthorizationError
    with pytest.raises(AuthorizationError):
        sdk.admin.stats()


@responses.activate
def test_download_invoice_returns_bytes(sdk):
    pdf_bytes = b"%PDF-1.4 fake pdf content"
    responses.add(responses.GET, f"{BASE}/admin/orders/7/invoice",
                  body=pdf_bytes, status=200,
                  content_type="application/pdf")
    pdf = sdk.admin.download_invoice(7)
    assert pdf == pdf_bytes


@responses.activate
def test_download_barcode_returns_bytes(sdk):
    pdf_bytes = b"%PDF-1.4 barcode pdf"
    responses.add(responses.GET, f"{BASE}/admin/products/1/barcode",
                  body=pdf_bytes, status=200,
                  content_type="application/pdf")
    pdf = sdk.admin.download_barcode(1)
    assert pdf[:4] == b"%PDF"


# ─────────────────────────────────────────────────────────────────────────────
# Mobile
# ─────────────────────────────────────────────────────────────────────────────

@responses.activate
def test_mobile_home(sdk):
    from dlp_sdk import MobileHome
    responses.add(responses.GET, f"{BASE}/api/mobile/home",
                  json={"banners": [{"id": 1, "title": "Sale!", "subtitle": "50% off",
                                     "image_url": "/img/sale.jpg"}],
                        "blog_posts": [{"slug": "health-tips", "title": "Health Tips",
                                        "excerpt": "Stay healthy."}]},
                  status=200)
    home = sdk.mobile.home()
    assert isinstance(home, MobileHome)
    assert home.banners[0].title == "Sale!"
    assert home.blog_posts[0].slug == "health-tips"


@responses.activate
def test_newsletter_subscribe(sdk):
    responses.add(responses.POST, f"{BASE}/api/newsletter/subscribe",
                  json={"success": True, "email": "user@example.com"}, status=200)
    result = sdk.mobile.newsletter_subscribe("user@example.com")
    assert result["success"] is True


# ─────────────────────────────────────────────────────────────────────────────
# Error handling
# ─────────────────────────────────────────────────────────────────────────────

@responses.activate
def test_rate_limit_error(sdk):
    from dlp_sdk import RateLimitError
    responses.add(responses.POST, f"{BASE}/auth/otp/request",
                  json={"error": "Too many requests"}, status=429)
    with pytest.raises(RateLimitError):
        sdk.auth.otp_request("+8801712345678")


@responses.activate
def test_server_error(sdk):
    from dlp_sdk import ServerError
    responses.add(responses.GET, f"{BASE}/api/health",
                  json={"error": "Internal Server Error"}, status=500)
    with pytest.raises(ServerError):
        sdk.health()


def test_network_error(sdk):
    # No responses registered → ConnectionError
    with pytest.raises(NetworkError):
        sdk.health()
