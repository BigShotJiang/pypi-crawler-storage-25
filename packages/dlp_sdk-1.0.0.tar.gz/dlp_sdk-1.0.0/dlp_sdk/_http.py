"""
dlp_sdk._http
~~~~~~~~~~~~~
Low-level HTTP transport layer.

Handles:
  - Session cookie jar (Flask-Session / browser-style cookies)
  - CSRF token refresh before state-changing requests
  - Automatic error mapping to SDK exceptions
  - Optional request / response logging
"""

from __future__ import annotations

import json
import logging
from typing import Any
from urllib.parse import urljoin

try:
    import requests
    from requests import Response, Session
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "The 'requests' library is required by dlp-sdk. "
        "Install it with:  pip install requests"
    ) from exc

from .exceptions import (
    AuthenticationError,
    AuthorizationError,
    DLPError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)

log = logging.getLogger("dlp_sdk")


class HTTPClient:
    """
    Thin wrapper around a ``requests.Session`` that:

    * Persists cookies across calls (Flask server-side sessions rely on a
      cookie to look up the session; the SDK must echo it back).
    * Reads the CSRF token from the ``X-CSRFToken`` response header or from
      a ``csrf_token`` field in JSON bodies, and injects it on every
      state-changing request.
    * Maps HTTP status codes to typed SDK exceptions.
    """

    DEFAULT_TIMEOUT = 15  # seconds

    def __init__(
        self,
        base_url: str,
        *,
        timeout: int = DEFAULT_TIMEOUT,
        verify_ssl: bool = True,
        debug: bool = False,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.verify_ssl = verify_ssl
        self._session = Session()
        self._session.verify = verify_ssl
        self._session.headers.update(
            {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "X-Requested-With": "XMLHttpRequest",
            }
        )
        self._csrf_token: str | None = None

        if debug:
            logging.basicConfig(level=logging.DEBUG)
            log.setLevel(logging.DEBUG)

    # ── public helpers ────────────────────────────────────────────────────────

    def get(self, path: str, **kwargs) -> Any:
        return self._request("GET", path, **kwargs)

    def post(self, path: str, body: dict | None = None, **kwargs) -> Any:
        return self._request("POST", path, json=body, **kwargs)

    def patch(self, path: str, body: dict | None = None, **kwargs) -> Any:
        return self._request("PATCH", path, json=body, **kwargs)

    def delete(self, path: str, **kwargs) -> Any:
        return self._request("DELETE", path, **kwargs)

    def download(self, path: str) -> bytes:
        """Fetch a binary response (PDF download) and return raw bytes."""
        url = self._url(path)
        log.debug("GET (binary) %s", url)
        try:
            resp = self._session.get(
                url,
                timeout=self.timeout,
                headers={"Accept": "application/pdf,application/octet-stream,*/*"},
            )
        except requests.exceptions.RequestException as exc:
            raise NetworkError(str(exc)) from exc
        self._raise_for_status(resp)
        return resp.content

    # ── internals ────────────────────────────────────────────────────────────

    def _url(self, path: str) -> str:
        return urljoin(self.base_url + "/", path.lstrip("/"))

    def _inject_csrf(self, kwargs: dict) -> None:
        if self._csrf_token:
            headers = kwargs.setdefault("headers", {})
            headers["X-CSRFToken"] = self._csrf_token

    def _store_csrf(self, resp: Response) -> None:
        token = resp.headers.get("X-CSRFToken")
        if token:
            self._csrf_token = token
        else:
            # Some Flask-WTF setups embed it in the JSON body
            try:
                data = resp.json()
                if isinstance(data, dict) and "csrf_token" in data:
                    self._csrf_token = data["csrf_token"]
            except Exception:
                pass

    def _request(self, method: str, path: str, **kwargs) -> Any:
        url = self._url(path)
        if method in ("POST", "PATCH", "PUT", "DELETE"):
            self._inject_csrf(kwargs)

        log.debug("%s %s  body=%s", method, url, kwargs.get("json"))
        try:
            resp = self._session.request(
                method, url, timeout=self.timeout, **kwargs
            )
        except requests.exceptions.Timeout as exc:
            raise NetworkError(f"Request timed out: {url}") from exc
        except requests.exceptions.ConnectionError as exc:
            raise NetworkError(f"Connection error: {url}") from exc
        except requests.exceptions.RequestException as exc:
            raise NetworkError(str(exc)) from exc

        self._store_csrf(resp)
        log.debug("← %s  %s bytes", resp.status_code, len(resp.content))
        self._raise_for_status(resp)

        if not resp.content:
            return {}
        try:
            return resp.json()
        except Exception:
            return {}

    @staticmethod
    def _raise_for_status(resp: Response) -> None:
        code = resp.status_code
        if code < 400:
            return

        try:
            detail = resp.json()
            message = detail.get("error") or detail.get("message") or resp.text
        except Exception:
            message = resp.text or f"HTTP {code}"

        if code == 401:
            raise AuthenticationError(message, status_code=code, response=resp)
        if code == 403:
            raise AuthorizationError(message, status_code=code, response=resp)
        if code == 404:
            raise NotFoundError(message, status_code=code, response=resp)
        if code == 422 or code == 400:
            raise ValidationError(message, status_code=code, response=resp)
        if code == 429:
            raise RateLimitError(message, status_code=code, response=resp)
        if code >= 500:
            raise ServerError(message, status_code=code, response=resp)
        raise DLPError(message, status_code=code, response=resp)
