"""
dlp-sdk  –  Daily Life Pharmacy Python SDK
==========================================

Quick start::

    from dlp_sdk import DLPClient

    sdk = DLPClient("https://pharmacy.example.com")
    sdk.auth.admin_login("admin", "password")
    stats = sdk.admin.stats()
    print(stats.revenue)
"""

from .client import DLPClient
from .exceptions import (
    AuthenticationError, AuthorizationError, DLPError,
    NetworkError, NotFoundError, RateLimitError, ServerError, ValidationError,
)
from .models import (
    AdminStats, Banner, BlogPost, CartItem, CartTotals,
    IntegrationsSummary, MobileHome, OperationsSummary, Order, OrderItem,
    OTPResult, OTPVerifyResult, Product, ReportsSummary, SalesSummary, TopProduct,
)

__version__ = "1.0.0"
__author__ = "Daily Life Pharmacy Engineering"

__all__ = [
    "DLPClient",
    "DLPError","AuthenticationError","AuthorizationError","NotFoundError",
    "ValidationError","RateLimitError","ServerError","NetworkError",
    "Product","Order","OrderItem","CartItem","CartTotals",
    "OTPResult","OTPVerifyResult","AdminStats","ReportsSummary",
    "SalesSummary","OperationsSummary","TopProduct","IntegrationsSummary",
    "Banner","BlogPost","MobileHome",
]
