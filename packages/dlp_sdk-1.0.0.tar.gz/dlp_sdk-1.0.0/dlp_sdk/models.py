"""
dlp_sdk.models
~~~~~~~~~~~~~~
Typed dataclass representations of every API resource.
All fields match the JSON keys returned by the server.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# ──────────────────────────────────────────────────────────────────────────────
# Catalog
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class Product:
    id: int
    slug: str
    name: str
    price: float
    stock: int
    is_featured: bool
    category_slug: str | None = None
    category_name: str | None = None
    brand_name: str | None = None
    badge: str = "new"
    description: str | None = None
    old_price: float | None = None
    rating: float = 4.5
    review_count: int = 0
    image_url: str | None = None

    @classmethod
    def from_dict(cls, d: dict) -> "Product":
        return cls(
            id=d["id"],
            slug=d["slug"],
            name=d["name"],
            price=float(d["price"]),
            stock=int(d.get("stock", 0)),
            is_featured=bool(d.get("is_featured", False)),
            category_slug=d.get("category_slug"),
            category_name=d.get("category_name"),
            brand_name=d.get("brand_name"),
            badge=d.get("badge", "new"),
            description=d.get("description"),
            old_price=float(d["old_price"]) if d.get("old_price") is not None else None,
            rating=float(d.get("rating", 4.5)),
            review_count=int(d.get("review_count", 0)),
            image_url=d.get("image_url"),
        )


# ──────────────────────────────────────────────────────────────────────────────
# Orders
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class OrderItem:
    product_id: int
    product_name: str
    unit_price: float
    quantity: int
    subtotal: float

    @classmethod
    def from_dict(cls, d: dict) -> "OrderItem":
        return cls(
            product_id=int(d["product_id"]),
            product_name=d["product_name"],
            unit_price=float(d["unit_price"]),
            quantity=int(d["quantity"]),
            subtotal=float(d["subtotal"]),
        )


@dataclass
class Order:
    id: int
    order_code: str
    status: str
    customer_name: str
    customer_phone: str
    delivery_city: str
    payment_method: str
    subtotal: float
    delivery_fee: float
    discount: float
    grand_total: float
    items: list[OrderItem] = field(default_factory=list)
    customer_email: str | None = None
    delivery_address: str | None = None
    promo_code: str | None = None
    eta: str | None = None
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, d: dict) -> "Order":
        return cls(
            id=int(d["id"]),
            order_code=d["order_code"],
            status=d["status"],
            customer_name=d["customer_name"],
            customer_phone=d["customer_phone"],
            delivery_city=d["delivery_city"],
            payment_method=d["payment_method"],
            subtotal=float(d["subtotal"]),
            delivery_fee=float(d["delivery_fee"]),
            discount=float(d["discount"]),
            grand_total=float(d["grand_total"]),
            items=[OrderItem.from_dict(i) for i in d.get("items", [])],
            customer_email=d.get("customer_email"),
            delivery_address=d.get("delivery_address"),
            promo_code=d.get("promo_code"),
            eta=d.get("eta"),
            created_at=d.get("created_at"),
            updated_at=d.get("updated_at"),
        )


# ──────────────────────────────────────────────────────────────────────────────
# Cart
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class CartItem:
    id: int
    slug: str
    name: str
    price: float
    qty: int
    stock: int
    subtotal: float
    image_url: str | None = None

    @classmethod
    def from_dict(cls, d: dict) -> "CartItem":
        return cls(
            id=int(d["id"]),
            slug=d["slug"],
            name=d["name"],
            price=float(d["price"]),
            qty=int(d["qty"]),
            stock=int(d.get("stock", 0)),
            subtotal=float(d["subtotal"]),
            image_url=d.get("image_url"),
        )


@dataclass
class CartTotals:
    items: list[CartItem]
    subtotal: float
    delivery: float
    discount: float
    grand_total: float
    promo_code: str | None = None

    @classmethod
    def from_dict(cls, d: dict) -> "CartTotals":
        return cls(
            items=[CartItem.from_dict(i) for i in d.get("items", [])],
            subtotal=float(d["subtotal"]),
            delivery=float(d["delivery"]),
            discount=float(d["discount"]),
            grand_total=float(d["grand_total"]),
            promo_code=d.get("promo_code"),
        )


# ──────────────────────────────────────────────────────────────────────────────
# Auth
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class OTPResult:
    phone: str
    sent: bool
    otp: str | None = None          # only present in demo/dev mode
    expires_in: int | None = None   # seconds

    @classmethod
    def from_dict(cls, d: dict) -> "OTPResult":
        return cls(
            phone=d.get("phone", ""),
            sent=bool(d.get("sent", True)),
            otp=d.get("otp"),
            expires_in=d.get("expires_in"),
        )


@dataclass
class OTPVerifyResult:
    valid: bool
    reason: str | None = None
    customer_name: str | None = None

    @classmethod
    def from_dict(cls, d: dict) -> "OTPVerifyResult":
        return cls(
            valid=bool(d.get("valid", False)),
            reason=d.get("reason"),
            customer_name=d.get("customer_name"),
        )


# ──────────────────────────────────────────────────────────────────────────────
# Admin / Reports
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class AdminStats:
    order_count: int
    pending_orders: int
    product_count: int
    customer_count: int
    revenue: float
    unread_messages: int

    @classmethod
    def from_dict(cls, d: dict) -> "AdminStats":
        return cls(
            order_count=int(d["order_count"]),
            pending_orders=int(d["pending_orders"]),
            product_count=int(d["product_count"]),
            customer_count=int(d["customer_count"]),
            revenue=float(d["revenue"]),
            unread_messages=int(d["unread_messages"]),
        )


@dataclass
class TopProduct:
    product_id: int
    name: str
    units: int
    sales: float

    @classmethod
    def from_dict(cls, d: dict) -> "TopProduct":
        return cls(
            product_id=int(d["product_id"]),
            name=d["name"],
            units=int(d["units"]),
            sales=float(d["sales"]),
        )


@dataclass
class SalesSummary:
    revenue: float
    orders: int
    customers: int
    average_order: float

    @classmethod
    def from_dict(cls, d: dict) -> "SalesSummary":
        return cls(
            revenue=float(d["revenue"]),
            orders=int(d["orders"]),
            customers=int(d["customers"]),
            average_order=float(d["average_order"]),
        )


@dataclass
class OperationsSummary:
    active_promos: int
    newsletter_subscribers: int
    prescription_requests: int

    @classmethod
    def from_dict(cls, d: dict) -> "OperationsSummary":
        return cls(
            active_promos=int(d["active_promos"]),
            newsletter_subscribers=int(d["newsletter_subscribers"]),
            prescription_requests=int(d["prescription_requests"]),
        )


@dataclass
class ReportsSummary:
    sales: SalesSummary
    operations: OperationsSummary
    top_products: list[TopProduct]

    @classmethod
    def from_dict(cls, d: dict) -> "ReportsSummary":
        return cls(
            sales=SalesSummary.from_dict(d["sales"]),
            operations=OperationsSummary.from_dict(d["operations"]),
            top_products=[TopProduct.from_dict(p) for p in d.get("top_products", [])],
        )


@dataclass
class IntegrationsSummary:
    subscribers: int
    email_logs: int
    whatsapp_logs: int
    label_documents: int

    @classmethod
    def from_dict(cls, d: dict) -> "IntegrationsSummary":
        return cls(
            subscribers=int(d["subscribers"]),
            email_logs=int(d["email_logs"]),
            whatsapp_logs=int(d["whatsapp_logs"]),
            label_documents=int(d["label_documents"]),
        )


# ──────────────────────────────────────────────────────────────────────────────
# Mobile / Content
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class Banner:
    id: int
    title: str
    subtitle: str | None = None
    image_url: str | None = None

    @classmethod
    def from_dict(cls, d: dict) -> "Banner":
        return cls(
            id=int(d["id"]),
            title=d["title"],
            subtitle=d.get("subtitle"),
            image_url=d.get("image_url"),
        )


@dataclass
class BlogPost:
    slug: str
    title: str
    excerpt: str | None = None

    @classmethod
    def from_dict(cls, d: dict) -> "BlogPost":
        return cls(slug=d["slug"], title=d["title"], excerpt=d.get("excerpt"))


@dataclass
class MobileHome:
    banners: list[Banner]
    blog_posts: list[BlogPost]

    @classmethod
    def from_dict(cls, d: dict) -> "MobileHome":
        return cls(
            banners=[Banner.from_dict(b) for b in d.get("banners", [])],
            blog_posts=[BlogPost.from_dict(p) for p in d.get("blog_posts", [])],
        )
