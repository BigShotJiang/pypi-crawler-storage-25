"""
dlp_sdk.auth
~~~~~~~~~~~~
Authentication resource:
  - Admin login (username + password, optional TOTP)
  - Admin logout
  - Customer OTP request & verify
  - 2FA QR URI fetch
"""

from __future__ import annotations

from ._http import HTTPClient
from .models import OTPResult, OTPVerifyResult


class AuthClient:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    # ── Admin ─────────────────────────────────────────────────────────────────

    def admin_login(
        self,
        username: str,
        password: str,
        *,
        totp_code: str | None = None,
    ) -> dict:
        """
        Authenticate as an admin/staff user.

        Args:
            username:   Admin username.
            password:   Admin password.
            totp_code:  6-digit TOTP code (required if 2FA is enabled for this account).

        Returns:
            dict with ``{"success": True}`` on success.

        Raises:
            AuthenticationError: Invalid credentials or TOTP code.
        """
        body: dict = {"username": username, "password": password}
        if totp_code:
            body["totp_code"] = totp_code
        return self._http.post("/auth/admin/login", body)

    def admin_logout(self) -> dict:
        """Log out the current admin session."""
        return self._http.post("/auth/admin/logout")

    # ── Customer OTP ──────────────────────────────────────────────────────────

    def otp_request(self, phone: str) -> OTPResult:
        """
        Request a one-time password for a customer phone number.

        In **development / demo** mode the server returns the OTP in the
        response body (``otp`` field). In production that field is absent and
        the code is sent via SMS.

        Args:
            phone: Customer phone number (e.g. ``+8801712345678``).

        Returns:
            :class:`~dlp_sdk.models.OTPResult`

        Raises:
            RateLimitError: If called too many times within a minute.
        """
        data = self._http.post("/auth/otp/request", {"phone": phone})
        return OTPResult.from_dict(data)

    def otp_verify(self, phone: str, code: str) -> OTPVerifyResult:
        """
        Verify the OTP and start a customer session.

        Args:
            phone: Customer phone number.
            code:  6-digit OTP received via SMS (or from :meth:`otp_request` in dev).

        Returns:
            :class:`~dlp_sdk.models.OTPVerifyResult`

        Raises:
            ValidationError: Code is wrong or expired.
        """
        data = self._http.post("/auth/otp/verify", {"phone": phone, "code": code})
        return OTPVerifyResult.from_dict(data)

    # ── 2FA ───────────────────────────────────────────────────────────────────

    def totp_qr_uri(self) -> str:
        """
        Return the ``otpauth://`` URI for setting up an authenticator app.

        Requires an active admin session.
        """
        data = self._http.get("/auth/admin/2fa/qr-uri")
        return data["qr_uri"]
