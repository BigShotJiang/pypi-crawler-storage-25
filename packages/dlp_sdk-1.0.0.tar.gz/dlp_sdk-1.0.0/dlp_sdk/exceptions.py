"""
dlp_sdk.exceptions
~~~~~~~~~~~~~~~~~~
All custom exceptions raised by the Daily Life Pharmacy SDK.
"""


class DLPError(Exception):
    """Base class for all SDK errors."""

    def __init__(self, message: str, status_code: int | None = None, response=None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.args[0]!r}, status_code={self.status_code})"


class AuthenticationError(DLPError):
    """Raised when credentials are invalid or a session has expired."""


class AuthorizationError(DLPError):
    """Raised when the current user lacks permission for an action."""


class NotFoundError(DLPError):
    """Raised when a requested resource does not exist."""


class ValidationError(DLPError):
    """Raised when request data is invalid (e.g. bad promo code, empty cart)."""


class RateLimitError(DLPError):
    """Raised when the server responds with 429 Too Many Requests."""


class ServerError(DLPError):
    """Raised on 5xx responses from the server."""


class NetworkError(DLPError):
    """Raised when a network-level error occurs (timeout, connection refused, etc.)."""
