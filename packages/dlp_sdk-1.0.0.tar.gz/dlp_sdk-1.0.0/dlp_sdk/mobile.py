"""
dlp_sdk.mobile
~~~~~~~~~~~~~~
Mobile app resources: home feed, wishlist, newsletter.
"""

from __future__ import annotations

from ._http import HTTPClient
from .models import MobileHome, Product


class MobileClient:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def home(self) -> MobileHome:
        """
        Fetch the mobile home-screen data (banners + latest blog posts).

        Returns:
            :class:`~dlp_sdk.models.MobileHome`

        Example::

            home = sdk.mobile.home()
            for banner in home.banners:
                print(banner.title, banner.image_url)
        """
        data = self._http.get("/api/mobile/home")
        return MobileHome.from_dict(data)

    def wishlist(self) -> list[Product]:
        """
        Retrieve the current session wishlist.

        Returns:
            List of :class:`~dlp_sdk.models.Product`
        """
        data = self._http.get("/api/mobile/wishlist")
        if isinstance(data, list):
            return [Product.from_dict(p) for p in data]
        return []

    def wishlist_add(self, product_id: int) -> dict:
        """
        Add a product to the session wishlist.

        Args:
            product_id: Product ID to add.

        Returns:
            ``{"success": True, "count": <total items in wishlist>}``

        Raises:
            NotFoundError: Product does not exist.
        """
        return self._http.post("/api/mobile/wishlist/add", {"product_id": product_id})

    def newsletter_subscribe(self, email: str) -> dict:
        """
        Subscribe an email address to the newsletter.

        Args:
            email: Valid email address.

        Returns:
            ``{"success": True, "email": "<email>"}``

        Raises:
            ValidationError: Invalid or already-subscribed email.

        Example::

            sdk.mobile.newsletter_subscribe("customer@example.com")
        """
        return self._http.post("/api/newsletter/subscribe", {"email": email})
