"""
dlp_sdk.client
~~~~~~~~~~~~~~
Top-level SDK entry point.

Usage::

    from dlp_sdk import DLPClient

    sdk = DLPClient("https://pharmacy.example.com")
    sdk.auth.admin_login("admin", "secret")

    stats = sdk.admin.stats()
    print(stats.pending_orders)
"""

from __future__ import annotations

from ._http import HTTPClient
from .admin import AdminClient
from .auth import AuthClient
from .cart import CartClient
from .catalog import CatalogClient
from .mobile import MobileClient
from .orders import OrdersClient


class DLPClient:
    """
    Daily Life Pharmacy SDK client.

    All API resources are accessible as attributes:

    - :attr:`auth`    — :class:`~dlp_sdk.auth.AuthClient`
    - :attr:`catalog` — :class:`~dlp_sdk.catalog.CatalogClient`
    - :attr:`cart`    — :class:`~dlp_sdk.cart.CartClient`
    - :attr:`orders`  — :class:`~dlp_sdk.orders.OrdersClient`
    - :attr:`admin`   — :class:`~dlp_sdk.admin.AdminClient`
    - :attr:`mobile`  — :class:`~dlp_sdk.mobile.MobileClient`

    Args:
        base_url:   Base URL of the pharmacy server, e.g.
                    ``"https://pharmacy.example.com"`` or
                    ``"http://localhost:5000"`` for local dev.
        timeout:    Per-request timeout in seconds (default 15).
        verify_ssl: Verify TLS certificates (default ``True``).
                    Set ``False`` for self-signed certs in development.
        debug:      Enable verbose HTTP request/response logging.

    Example::

        from dlp_sdk import DLPClient

        sdk = DLPClient("http://localhost:5000", debug=True)

        # Admin workflow
        sdk.auth.admin_login("admin", "adminpass")
        stats = sdk.admin.stats()

        # Customer workflow
        sdk.cart.add(product_id=1, quantity=2)
        sdk.cart.apply_promo("SAVE10")
        order = sdk.orders.create(
            name="Ahmed Rahman",
            phone="+8801712345678",
            address="House 5, Dhanmondi",
            payment_method="bKash",
        )
        print(order.order_code)
    """

    def __init__(
        self,
        base_url: str,
        *,
        timeout: int = 15,
        verify_ssl: bool = True,
        debug: bool = False,
    ) -> None:
        self._http = HTTPClient(
            base_url, timeout=timeout, verify_ssl=verify_ssl, debug=debug
        )
        self.auth    = AuthClient(self._http)
        self.catalog = CatalogClient(self._http)
        self.cart    = CartClient(self._http)
        self.orders  = OrdersClient(self._http)
        self.admin   = AdminClient(self._http)
        self.mobile  = MobileClient(self._http)

    def health(self) -> dict:
        """
        Ping the server health endpoint.

        Returns:
            ``{"status": "ok", "service": "api"}``

        Raises:
            NetworkError: Server is unreachable.
        """
        return self._http.get("/api/health")

    def __repr__(self) -> str:
        return f"DLPClient(base_url={self._http.base_url!r})"
