"""
dlp_sdk.orders
~~~~~~~~~~~~~~
Order placement and lookup resource.
"""

from __future__ import annotations

from ._http import HTTPClient
from .models import Order


# Valid payment methods accepted by the server
PAYMENT_METHODS = frozenset({"COD", "bKash", "Nagad", "VISA", "Mastercard"})


class OrdersClient:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def create(
        self,
        *,
        name: str,
        phone: str,
        address: str,
        city: str = "Dhaka",
        payment_method: str = "COD",
        email: str | None = None,
        note: str | None = None,
    ) -> Order:
        """
        Place an order from the current session cart.

        The cart must not be empty and must have been built up via
        :class:`~dlp_sdk.cart.CartClient` prior to calling this method.

        Args:
            name:           Customer full name.
            phone:          Customer phone (e.g. ``"+8801712345678"``).
            address:        Delivery street address.
            city:           Delivery city (default ``"Dhaka"``).
            payment_method: One of ``COD`` | ``bKash`` | ``Nagad`` |
                            ``VISA`` | ``Mastercard`` (default ``"COD"``).
            email:          Optional customer email.
            note:           Optional delivery note.

        Returns:
            Placed :class:`~dlp_sdk.models.Order`

        Raises:
            ValidationError: Cart is empty, invalid payment method, or
                             insufficient product stock.

        Example::

            sdk.cart.add(product_id=3, quantity=2)
            order = sdk.orders.create(
                name="Fatima Khanam",
                phone="+8801987654321",
                address="House 7, Mirpur-1",
                city="Dhaka",
                payment_method="bKash",
            )
            print(order.order_code, order.eta)
        """
        if payment_method not in PAYMENT_METHODS:
            raise ValueError(
                f"Invalid payment_method {payment_method!r}. "
                f"Choose one of: {sorted(PAYMENT_METHODS)}"
            )
        body: dict = {
            "name": name,
            "phone": phone,
            "address": address,
            "city": city,
            "payment_method": payment_method,
        }
        if email:
            body["email"] = email
        if note:
            body["note"] = note

        data = self._http.post("/api/orders", body)
        return Order.from_dict(data)

    def get(self, order_code: str) -> Order:
        """
        Look up an order by its order code.

        Args:
            order_code: The ``DLP`` prefixed order code (e.g. ``"DLP00123456"``).

        Returns:
            :class:`~dlp_sdk.models.Order`

        Raises:
            NotFoundError: No order exists with that code.
        """
        data = self._http.get(f"/api/orders/{order_code}")
        return Order.from_dict(data)

    def validate_promo(self, code: str, subtotal: float) -> dict:
        """
        Validate a promo code without applying it.

        Args:
            code:     Promo code string.
            subtotal: Current cart subtotal in BDT.

        Returns:
            ``{"valid": bool, "reason": str | None, "discount_pct": int,
               "discount_amount": float}``
        """
        return self._http.post(
            "/api/orders/promo/validate", {"code": code, "subtotal": subtotal}
        )
