"""
dlp_sdk.cart
~~~~~~~~~~~~
Session-based shopping cart resource.

The server stores the cart in the Flask session (Redis-backed).
The SDK preserves the session cookie automatically via ``requests.Session``.
"""

from __future__ import annotations

from ._http import HTTPClient
from .models import CartTotals


class CartClient:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def get(self) -> CartTotals:
        """
        Retrieve current cart contents and computed totals.

        Returns:
            :class:`~dlp_sdk.models.CartTotals`

        Example::

            cart = sdk.cart.get()
            print(f"Grand total: ৳{cart.grand_total}")
            for item in cart.items:
                print(item.name, "×", item.qty)
        """
        data = self._http.get("/api/cart")
        return CartTotals.from_dict(data)

    def add(self, product_id: int, quantity: int = 1) -> CartTotals:
        """
        Add a product to the cart (or increase its quantity).

        Args:
            product_id: ID of the product to add.
            quantity:   Units to add (default 1, capped at 99 by server).

        Returns:
            Updated :class:`~dlp_sdk.models.CartTotals`

        Raises:
            NotFoundError: Product does not exist.
        """
        data = self._http.post("/api/cart/add", {"product_id": product_id, "quantity": quantity})
        return CartTotals.from_dict(data)

    def update(self, product_id: int, quantity: int) -> CartTotals:
        """
        Set the quantity of a cart item.  Pass ``quantity=0`` to remove.

        Args:
            product_id: ID of the product to update.
            quantity:   New quantity (0 removes the item).

        Returns:
            Updated :class:`~dlp_sdk.models.CartTotals`
        """
        data = self._http.post("/api/cart/update", {"product_id": product_id, "quantity": quantity})
        return CartTotals.from_dict(data)

    def remove(self, product_id: int) -> CartTotals:
        """
        Remove a product from the cart entirely.

        Args:
            product_id: ID of the product to remove.

        Returns:
            Updated :class:`~dlp_sdk.models.CartTotals`
        """
        data = self._http.post("/api/cart/remove", {"product_id": product_id})
        return CartTotals.from_dict(data)

    def clear(self) -> dict:
        """Empty the cart and remove any applied promo code."""
        return self._http.post("/api/cart/clear")

    def apply_promo(self, code: str) -> dict:
        """
        Apply a promo code to the current cart.

        Args:
            code: Promo code string (case-insensitive).

        Returns:
            ``{"valid": True, "code": "...", "discount_pct": 10, "discount_amount": 50.0}``

        Raises:
            ValidationError: Code is invalid, expired, or minimum order not met.

        Example::

            result = sdk.cart.apply_promo("SAVE10")
            print(f"Saved ৳{result['discount_amount']}")
        """
        return self._http.post("/api/cart/promo", {"code": code})

    def remove_promo(self) -> dict:
        """Remove the currently applied promo code."""
        return self._http.post("/api/cart/promo/remove")
