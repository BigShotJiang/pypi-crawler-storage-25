"""
dlp_sdk.catalog
~~~~~~~~~~~~~~~
Product catalog resource: browse products, filter, search.
"""

from __future__ import annotations

from ._http import HTTPClient
from .models import Product


class CatalogClient:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def list_products(
        self,
        *,
        category: str | None = None,
        search: str | None = None,
        featured: bool = False,
        sort: str = "id",
        limit: int | None = None,
    ) -> list[Product]:
        """
        Fetch a list of active products.

        Args:
            category: Filter by category slug (e.g. ``"antibiotics"``).
            search:   Full-text search query against name and description.
            featured: If ``True``, only return featured products.
            sort:     One of ``id`` | ``price_asc`` | ``price_desc`` |
                      ``rating`` | ``name`` | ``stock``.
            limit:    Maximum number of results.

        Returns:
            List of :class:`~dlp_sdk.models.Product` objects.

        Example::

            products = sdk.catalog.list_products(
                category="painkiller", sort="price_asc", limit=20
            )
            for p in products:
                print(p.name, p.price)
        """
        params: dict = {"sort": sort}
        if category:
            params["category"] = category
        if search:
            params["search"] = search
        if featured:
            params["featured"] = "1"
        if limit is not None:
            params["limit"] = limit

        data = self._http.get("/api/catalog/products", params=params)
        # Server returns a list directly
        if isinstance(data, list):
            return [Product.from_dict(p) for p in data]
        return [Product.from_dict(p) for p in data.get("products", [])]

    def get_product(self, product_id: int) -> Product:
        """
        Fetch a single product by ID.

        Args:
            product_id: Integer product ID.

        Returns:
            :class:`~dlp_sdk.models.Product`

        Raises:
            NotFoundError: Product does not exist.
        """
        data = self._http.get(f"/api/catalog/products/{product_id}")
        return Product.from_dict(data)

    def get_product_by_slug(self, slug: str) -> Product:
        """
        Fetch a single product by its URL slug.

        Args:
            slug: Product slug (e.g. ``"paracetamol-500mg"``).

        Returns:
            :class:`~dlp_sdk.models.Product`

        Raises:
            NotFoundError: Product does not exist.
        """
        data = self._http.get(f"/api/catalog/products/slug/{slug}")
        return Product.from_dict(data)

    def related_products(self, product_id: int, *, limit: int = 4) -> list[Product]:
        """
        Fetch products in the same category as *product_id*.

        Args:
            product_id: Source product ID.
            limit:      Maximum results.

        Returns:
            List of :class:`~dlp_sdk.models.Product` objects.
        """
        params = {"limit": limit}
        data = self._http.get(f"/api/catalog/products/{product_id}/related", params=params)
        if isinstance(data, list):
            return [Product.from_dict(p) for p in data]
        return [Product.from_dict(p) for p in data.get("products", [])]
