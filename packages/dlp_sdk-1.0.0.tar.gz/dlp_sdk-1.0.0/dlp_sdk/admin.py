"""
dlp_sdk.admin
~~~~~~~~~~~~~
Admin-only resources:
  - Dashboard statistics
  - Sales / operations reports
  - Integration summary
  - Invoice PDF download
  - WhatsApp invoice link
  - Barcode / QR code PDF download
  - Shipping & item label PDF download
"""

from __future__ import annotations

from ._http import HTTPClient
from .models import AdminStats, IntegrationsSummary, ReportsSummary


class AdminClient:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    # ── Dashboard ─────────────────────────────────────────────────────────────

    def stats(self) -> AdminStats:
        """
        Fetch live dashboard statistics.

        Requires an active admin/staff session.

        Returns:
            :class:`~dlp_sdk.models.AdminStats`

        Raises:
            AuthorizationError: Not logged in as admin or staff.

        Example::

            sdk.auth.admin_login("admin", "s3cr3t")
            s = sdk.admin.stats()
            print(f"Pending orders: {s.pending_orders}")
            print(f"Revenue: ৳{s.revenue:,.2f}")
        """
        return AdminStats.from_dict(self._http.get("/api/admin/stats"))

    # ── Reports ───────────────────────────────────────────────────────────────

    def reports(self) -> ReportsSummary:
        """
        Fetch the full reports summary (sales, operations, top products).

        Returns:
            :class:`~dlp_sdk.models.ReportsSummary`

        Example::

            rep = sdk.admin.reports()
            print(f"Total revenue: ৳{rep.sales.revenue:,.2f}")
            for tp in rep.top_products[:5]:
                print(tp.name, tp.units, "units sold")
        """
        return ReportsSummary.from_dict(self._http.get("/api/reports/summary"))

    # ── Integrations ──────────────────────────────────────────────────────────

    def integrations(self) -> IntegrationsSummary:
        """
        Fetch counts for all integration resources.

        Returns:
            :class:`~dlp_sdk.models.IntegrationsSummary`
        """
        return IntegrationsSummary.from_dict(
            self._http.get("/api/integrations/summary")
        )

    # ── Invoice PDF ───────────────────────────────────────────────────────────

    def download_invoice(self, order_id: int, dest_path: str | None = None) -> bytes:
        """
        Generate and download a PDF invoice for an order.

        Args:
            order_id:  Integer order ID (from the admin panel or DB).
            dest_path: If given, the PDF bytes are also written to this file path.

        Returns:
            Raw PDF bytes.

        Raises:
            NotFoundError:     Order does not exist.
            AuthorizationError: Not logged in as admin/staff.

        Example::

            pdf = sdk.admin.download_invoice(42, dest_path="/tmp/invoice.pdf")
            print(f"Invoice: {len(pdf)} bytes")
        """
        pdf = self._http.download(f"/admin/orders/{order_id}/invoice")
        if dest_path:
            with open(dest_path, "wb") as fh:
                fh.write(pdf)
        return pdf

    # ── WhatsApp ──────────────────────────────────────────────────────────────

    def whatsapp_link(self, order_id: int) -> str:
        """
        Generate a WhatsApp deep-link for sending the invoice to the customer.

        The server creates a PDF invoice, logs it to ``whatsapp_invoice_logs``,
        and returns the ``wa.me`` URL.

        Args:
            order_id: Integer order ID.

        Returns:
            ``https://wa.me/<phone>?text=...`` URL string.

        Example::

            link = sdk.admin.whatsapp_link(42)
            print("Open in browser:", link)
        """
        data = self._http.get(f"/api/admin/orders/{order_id}/whatsapp-link")
        return data["whatsapp_link"]

    # ── Barcode / QR ─────────────────────────────────────────────────────────

    def download_barcode(
        self, product_id: int, dest_path: str | None = None
    ) -> bytes:
        """
        Download a Code-128 barcode PDF for a product (80 × 44 mm thermal).

        Args:
            product_id: Integer product ID.
            dest_path:  Optional file path to write the PDF.

        Returns:
            Raw PDF bytes.

        Example::

            pdf = sdk.admin.download_barcode(7, "/tmp/barcode_7.pdf")
        """
        pdf = self._http.download(f"/admin/products/{product_id}/barcode")
        if dest_path:
            with open(dest_path, "wb") as fh:
                fh.write(pdf)
        return pdf

    def download_qr(self, product_id: int, dest_path: str | None = None) -> bytes:
        """
        Download a QR code PDF for a product (50 × 55 mm).

        Args:
            product_id: Integer product ID.
            dest_path:  Optional file path to write the PDF.

        Returns:
            Raw PDF bytes.
        """
        pdf = self._http.download(f"/admin/products/{product_id}/qr")
        if dest_path:
            with open(dest_path, "wb") as fh:
                fh.write(pdf)
        return pdf

    # ── Labels ────────────────────────────────────────────────────────────────

    def download_shipping_label(
        self, order_id: int, dest_path: str | None = None
    ) -> bytes:
        """
        Download a shipping label PDF (10 × 7 cm landscape with QR + address).

        Args:
            order_id:  Integer order ID.
            dest_path: Optional file path to write the PDF.

        Returns:
            Raw PDF bytes.

        Example::

            label = sdk.admin.download_shipping_label(42, "/tmp/ship_label.pdf")
        """
        pdf = self._http.download(f"/admin/orders/{order_id}/label/shipping")
        if dest_path:
            with open(dest_path, "wb") as fh:
                fh.write(pdf)
        return pdf

    def download_item_labels(
        self, order_id: int, dest_path: str | None = None
    ) -> bytes:
        """
        Download per-item barcode labels PDF (one Code-128 per line item).

        Args:
            order_id:  Integer order ID.
            dest_path: Optional file path to write the PDF.

        Returns:
            Raw PDF bytes.
        """
        pdf = self._http.download(f"/admin/orders/{order_id}/label/item")
        if dest_path:
            with open(dest_path, "wb") as fh:
                fh.write(pdf)
        return pdf
