from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from typing import Any

from .config import get_db_path

TOKEN_COLUMNS = [
    "id",
    "symbol",
    "name",
    "web_slug",
    "market_cap_rank",
    "asset_platform_id",
    "hashing_algorithm",
    "block_time_in_minutes",
    "categories_json",
    "description_json",
    "links_json",
    "image_json",
    "circulating_supply",
    "total_supply",
    "max_supply",
    "community_data_json",
    "developer_data_json",
    "public_interest_stats_json",
    "raw_json",
    "last_updated",
    "fetched_at",
]

LEGACY_CONTRACT_COLUMNS = {"contract_addresses_json", "platform_details_json"}


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _json_dumps(value: Any) -> str | None:
    if value is None:
        return None
    return json.dumps(value, ensure_ascii=True, sort_keys=True)


def _parse_timestamp(value: Any) -> str | None:
    if not value:
        return None
    if isinstance(value, datetime):
        dt = value
    else:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.isoformat()


def _table_columns(conn: sqlite3.Connection, table_name: str) -> list[str]:
    rows = conn.execute(f"PRAGMA table_info({table_name})").fetchall()
    return [row["name"] for row in rows]


def _load_json_blob(value: Any, default: Any) -> Any:
    if value is None:
        return default
    if isinstance(value, str):
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return default
    return value


def _backfill_contracts_from_legacy_rows(
    conn: sqlite3.Connection, table_name: str, columns: list[str]
) -> None:
    if not LEGACY_CONTRACT_COLUMNS.intersection(columns):
        return

    select_columns = ["id", "fetched_at"]
    if "contract_addresses_json" in columns:
        select_columns.append("contract_addresses_json")
    if "platform_details_json" in columns:
        select_columns.append("platform_details_json")

    rows = conn.execute(
        f"SELECT {', '.join(select_columns)} FROM {table_name}"
    ).fetchall()

    for row in rows:
        token_id = row["id"]
        fetched_at = row["fetched_at"] or _utcnow()
        records_by_chain: dict[tuple[str, str], tuple[Any, ...]] = {}

        for chain, address in _load_json_blob(
            row["contract_addresses_json"] if "contract_addresses_json" in row.keys() else None,
            {},
        ).items():
            if not chain or not address:
                continue
            records_by_chain[(chain, address)] = (
                token_id,
                chain,
                address,
                None,
                "coingecko_legacy",
                fetched_at,
            )

        for platform in _load_json_blob(
            row["platform_details_json"] if "platform_details_json" in row.keys() else None,
            [],
        ):
            if not isinstance(platform, dict):
                continue
            chain = platform.get("platform")
            address = platform.get("contract_address")
            if not chain or not address:
                continue
            records_by_chain[(chain, address)] = (
                token_id,
                chain,
                address,
                platform.get("decimals"),
                "coingecko_legacy",
                fetched_at,
            )

        if records_by_chain:
            conn.executemany(
                """
                INSERT OR IGNORE INTO token_contracts (
                    token_id, chain, contract_address, decimals, source, fetched_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                list(records_by_chain.values()),
            )


def _rebuild_tokens_table(conn: sqlite3.Connection) -> None:
    existing_column_list = _table_columns(conn, "tokens")
    existing_columns = set(existing_column_list)
    copy_columns = [column for column in TOKEN_COLUMNS if column in existing_columns]

    conn.execute("ALTER TABLE tokens RENAME TO tokens_legacy")
    conn.execute(
        """
        CREATE TABLE tokens (
            id                  TEXT PRIMARY KEY,
            symbol              TEXT,
            name                TEXT,
            web_slug            TEXT,
            market_cap_rank     INTEGER,
            asset_platform_id   TEXT,
            hashing_algorithm   TEXT,
            block_time_in_minutes INTEGER,
            categories_json     TEXT,
            description_json    TEXT,
            links_json          TEXT,
            image_json          TEXT,
            circulating_supply  REAL,
            total_supply        REAL,
            max_supply          REAL,
            community_data_json TEXT,
            developer_data_json TEXT,
            public_interest_stats_json TEXT,
            raw_json            TEXT,
            last_updated        TEXT,
            fetched_at          TEXT NOT NULL
        )
        """
    )

    if copy_columns:
        column_sql = ", ".join(copy_columns)
        conn.execute(
            f"""
            INSERT INTO tokens ({column_sql})
            SELECT {column_sql}
            FROM tokens_legacy
            """
        )

    conn.execute("DROP TABLE tokens_legacy")


def _ensure_tokens_schema(conn: sqlite3.Connection) -> bool:
    rebuilt = False
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS tokens (
            id                  TEXT PRIMARY KEY,
            symbol              TEXT,
            name                TEXT,
            web_slug            TEXT,
            market_cap_rank     INTEGER,
            asset_platform_id   TEXT,
            hashing_algorithm   TEXT,
            block_time_in_minutes INTEGER,
            categories_json     TEXT,
            description_json    TEXT,
            links_json          TEXT,
            image_json          TEXT,
            circulating_supply  REAL,
            total_supply        REAL,
            max_supply          REAL,
            community_data_json TEXT,
            developer_data_json TEXT,
            public_interest_stats_json TEXT,
            raw_json            TEXT,
            last_updated        TEXT,
            fetched_at          TEXT NOT NULL
        )
        """
    )

    if _table_columns(conn, "tokens") != TOKEN_COLUMNS:
        _rebuild_tokens_table(conn)
        rebuilt = True

    return rebuilt


def _ensure_contracts_schema(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS token_contracts (
            token_id          TEXT NOT NULL,
            chain             TEXT NOT NULL,
            contract_address  TEXT NOT NULL,
            decimals          INTEGER,
            source            TEXT NOT NULL DEFAULT 'coingecko',
            fetched_at        TEXT NOT NULL,
            PRIMARY KEY (token_id, chain, contract_address),
            FOREIGN KEY (token_id) REFERENCES tokens(id) ON DELETE CASCADE
        )
        """
    )


def _backfill_contracts_from_token_raw(conn: sqlite3.Connection) -> None:
    rows = conn.execute(
        """
        SELECT id, raw_json, fetched_at
        FROM tokens
        WHERE raw_json IS NOT NULL
          AND NOT EXISTS (
              SELECT 1 FROM token_contracts WHERE token_id = tokens.id
          )
        """
    ).fetchall()

    for row in rows:
        raw = _load_json_blob(row["raw_json"], {})
        platforms = raw.get("platforms") or {}
        detail_platforms = raw.get("detail_platforms") or {}
        records_by_chain: dict[tuple[str, str], tuple[Any, ...]] = {}

        for chain, address in platforms.items():
            if not chain or not address:
                continue
            records_by_chain[(chain, address)] = (
                row["id"],
                chain,
                address,
                None,
                "coingecko_raw",
                row["fetched_at"] or _utcnow(),
            )

        for chain, detail in detail_platforms.items():
            if not isinstance(detail, dict):
                continue
            address = detail.get("contract_address")
            if not chain or not address:
                continue
            records_by_chain[(chain, address)] = (
                row["id"],
                chain,
                address,
                detail.get("decimal_place"),
                "coingecko_raw",
                row["fetched_at"] or _utcnow(),
            )

        if records_by_chain:
            conn.executemany(
                """
                INSERT OR IGNORE INTO token_contracts (
                    token_id, chain, contract_address, decimals, source, fetched_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                list(records_by_chain.values()),
            )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_token_contracts_token_id
        ON token_contracts(token_id)
        """
    )


def _ensure_aliases_schema(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS token_aliases (
            query             TEXT PRIMARY KEY,
            token_id          TEXT NOT NULL,
            match_type        TEXT NOT NULL,
            is_user_confirmed INTEGER NOT NULL DEFAULT 0,
            updated_at        TEXT NOT NULL,
            FOREIGN KEY (token_id) REFERENCES tokens(id) ON DELETE CASCADE
        )
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_token_aliases_token_id
        ON token_aliases(token_id)
        """
    )


def _init_tables(db_path: str | None = None) -> sqlite3.Connection:
    if db_path is None:
        db_path = str(get_db_path())

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")

    _ensure_tokens_schema(conn)
    _ensure_contracts_schema(conn)
    _ensure_aliases_schema(conn)
    _backfill_contracts_from_token_raw(conn)

    conn.commit()
    return conn


def token_data_to_record(token_data: dict[str, Any]) -> dict[str, Any]:
    supply = token_data.get("supply") or {}

    return {
        "id": token_data.get("id"),
        "symbol": token_data.get("symbol"),
        "name": token_data.get("name"),
        "web_slug": token_data.get("web_slug"),
        "market_cap_rank": token_data.get("market_cap_rank"),
        "asset_platform_id": token_data.get("asset_platform_id"),
        "hashing_algorithm": token_data.get("hashing_algorithm"),
        "block_time_in_minutes": token_data.get("block_time_in_minutes"),
        "categories_json": _json_dumps(token_data.get("categories") or []),
        "description_json": _json_dumps(token_data.get("description") or {}),
        "links_json": _json_dumps(token_data.get("links") or {}),
        "image_json": _json_dumps(token_data.get("image") or {}),
        "circulating_supply": supply.get("circulating_supply"),
        "total_supply": supply.get("total_supply"),
        "max_supply": supply.get("max_supply"),
        "community_data_json": _json_dumps(token_data.get("community_data") or {}),
        "developer_data_json": _json_dumps(token_data.get("developer_data") or {}),
        "public_interest_stats_json": _json_dumps(
            token_data.get("public_interest_stats") or {}
        ),
        "raw_json": _json_dumps(token_data.get("raw")),
        "last_updated": _parse_timestamp(token_data.get("last_updated")),
        "fetched_at": _utcnow(),
    }


def token_contracts_to_records(token_data: dict[str, Any]) -> list[dict[str, Any]]:
    token_id = token_data["id"]
    fetched_at = _utcnow()
    by_chain: dict[str, dict[str, Any]] = {}

    for chain, address in (token_data.get("contract_addresses") or {}).items():
        if not chain or not address:
            continue
        by_chain[chain] = {
            "token_id": token_id,
            "chain": chain,
            "contract_address": address,
            "decimals": None,
            "source": "coingecko",
            "fetched_at": fetched_at,
        }

    for platform in token_data.get("platform_details") or []:
        chain = platform.get("platform")
        address = platform.get("contract_address")
        if not chain or not address:
            continue
        by_chain[chain] = {
            "token_id": token_id,
            "chain": chain,
            "contract_address": address,
            "decimals": platform.get("decimals"),
            "source": "coingecko",
            "fetched_at": fetched_at,
        }

    return list(by_chain.values())


def fetch_token_row(conn: sqlite3.Connection, token_id: str) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM tokens WHERE lower(id) = lower(?)",
        [token_id],
    ).fetchone()


def fetch_token_contract_rows(
    conn: sqlite3.Connection, token_id: str
) -> list[sqlite3.Row]:
    return conn.execute(
        """
        SELECT chain, contract_address, decimals, source, fetched_at
        FROM token_contracts
        WHERE token_id = ?
        ORDER BY chain ASC
        """,
        [token_id],
    ).fetchall()


def get_alias_resolution(conn: sqlite3.Connection, query: str) -> sqlite3.Row | None:
    normalized = query.strip().casefold()
    if not normalized:
        return None
    return conn.execute(
        "SELECT * FROM token_aliases WHERE query = ?",
        [normalized],
    ).fetchone()


def upsert_alias_resolution(
    query: str,
    token_id: str,
    match_type: str,
    conn: sqlite3.Connection,
    *,
    is_user_confirmed: bool = False,
) -> None:
    normalized = query.strip().casefold()
    if not normalized:
        return

    conn.execute(
        """
        INSERT INTO token_aliases (query, token_id, match_type, is_user_confirmed, updated_at)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(query) DO UPDATE SET
            token_id = excluded.token_id,
            match_type = excluded.match_type,
            is_user_confirmed = excluded.is_user_confirmed,
            updated_at = excluded.updated_at
        """,
        [normalized, token_id, match_type, int(is_user_confirmed), _utcnow()],
    )


def upsert_token_data(
    token_data: dict[str, Any], conn: sqlite3.Connection | None = None
) -> None:
    owns_connection = conn is None
    if conn is None:
        conn = _init_tables()

    record = token_data_to_record(token_data)
    columns = list(record.keys())
    assignments = ", ".join(
        f"{column} = excluded.{column}" for column in columns if column != "id"
    )
    column_names = ", ".join(columns)
    placeholders = ", ".join("?" for _ in columns)

    conn.execute(
        f"""
        INSERT INTO tokens ({column_names})
        VALUES ({placeholders})
        ON CONFLICT(id) DO UPDATE SET {assignments}
        """,
        [record[column] for column in columns],
    )

    token_id = record["id"]
    conn.execute("DELETE FROM token_contracts WHERE token_id = ?", [token_id])
    contract_records = token_contracts_to_records(token_data)
    if contract_records:
        conn.executemany(
            """
            INSERT INTO token_contracts (
                token_id, chain, contract_address, decimals, source, fetched_at
            ) VALUES (?, ?, ?, ?, ?, ?)
            """,
            [
                (
                    contract["token_id"],
                    contract["chain"],
                    contract["contract_address"],
                    contract["decimals"],
                    contract["source"],
                    contract["fetched_at"],
                )
                for contract in contract_records
            ],
        )

    upsert_alias_resolution(record["id"], token_id, "coin_id", conn)
    if record.get("symbol"):
        upsert_alias_resolution(record["symbol"], token_id, "symbol", conn)

    conn.commit()

    if owns_connection:
        conn.close()
