import os
import json
import platform
from pathlib import Path

ENV_VAR = "GECKO_RS_DB"
CONFIG_DIR = "geckors"
CONFIG_FILE = "config.json"
DEFAULT_DB = "gecko_rs.db"


def _get_config_dir() -> Path:
    system = platform.system()
    if system == "Windows":
        # %APPDATA%/geckors
        base = os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming")
    elif system == "Darwin":
        # ~/Library/Application Support/geckors
        base = Path.home() / "Library" / "Application Support"
    else:
        # ~/.config/geckors (Linux/BSD)
        base = os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")

    return Path(base) / CONFIG_DIR


def _get_data_dir() -> Path:
    system = platform.system()
    if system == "Windows":
        # %LOCALAPPDATA%/geckors
        base = os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local")
    elif system == "Darwin":
        # ~/Library/Application Support/geckors
        base = Path.home() / "Library" / "Application Support"
    else:
        # ~/.local/share/geckors or $XDG_DATA_HOME/geckors (Linux/BSD)
        base = os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")

    return Path(base) / CONFIG_DIR


def get_db_path() -> Path:
    # 1. Environment variable override
    env_path = os.environ.get(ENV_VAR, "")
    if env_path:
        return Path(env_path)

    # 2. Config file override in the config directory
    config_dir = _get_config_dir()
    config_path = config_dir / CONFIG_FILE

    if config_path.exists():
        try:
            with open(config_path) as f:
                config = json.load(f)
            db_path = config.get("database", "")
            if db_path:
                return Path(db_path)
        except (json.JSONDecodeError, OSError):
            pass

    # 3. Default: store the SQLite database in the data directory
    data_dir = _get_data_dir()
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir / DEFAULT_DB
