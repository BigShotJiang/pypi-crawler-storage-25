from __future__ import annotations

import json
from typing import Any

from .data.db import (
    _init_tables,
    fetch_token_contract_rows,
    fetch_token_row,
    get_alias_resolution,
    upsert_alias_resolution,
    upsert_token_data,
)
from .fetch import (
    CoinGeckoError,
    CoinGeckoRateLimitError,
    fetch_coin_data_by_id,
    fetch_coin_id_map,
    resolve_coin,
)


def _normalize_query(value: str) -> str:
    return value.strip().casefold()


def _decode_json(value: Any, default: Any) -> Any:
    if value is None:
        return default
    if isinstance(value, str):
        return json.loads(value)
    return value


def _deserialize_token_row(row: dict[str, Any]) -> dict[str, Any]:
    return {
        **row,
        "categories_json": _decode_json(row.get("categories_json"), []),
        "description_json": _decode_json(row.get("description_json"), {}),
        "links_json": _decode_json(row.get("links_json"), {}),
        "image_json": _decode_json(row.get("image_json"), {}),
        "community_data_json": _decode_json(row.get("community_data_json"), {}),
        "developer_data_json": _decode_json(row.get("developer_data_json"), {}),
        "public_interest_stats_json": _decode_json(
            row.get("public_interest_stats_json"), {}
        ),
        "raw_json": _decode_json(row.get("raw_json"), None),
    }


def _contract_rows_to_details(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            "platform": row["chain"],
            "contract_address": row["contract_address"],
            "decimals": row["decimals"],
            "source": row["source"],
            "fetched_at": row["fetched_at"],
        }
        for row in rows
        if row["chain"] and row["contract_address"]
    ]


def _resolve_symbol_candidates(
    query: str, candidates: list[dict[str, Any]]
) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    normalized = _normalize_query(query)
    if not candidates:
        return None, []

    exact_id_matches = [
        coin for coin in candidates if str(coin.get("id", "")).casefold() == normalized
    ]
    if exact_id_matches:
        return exact_id_matches[0], []

    if len(candidates) == 1:
        return candidates[0], []

    exact_name_matches = [
        coin for coin in candidates if str(coin.get("name", "")).casefold() == normalized
    ]
    if len(exact_name_matches) == 1:
        return exact_name_matches[0], []

    return None, sorted(
        candidates,
        key=lambda coin: (
            coin.get("market_cap_rank") is None,
            coin.get("market_cap_rank") or float("inf"),
            str(coin.get("id", "")),
        ),
    )


class Token:
    def __init__(self, query: str, conn=None, *, auto_fetch: bool = True):
        self.query = query
        self._owns_connection = conn is None
        self.conn = conn or _init_tables()
        self._token_id = self._resolve_token_id(query, auto_fetch=auto_fetch)
        self._data = self._load_token_data(self._token_id) if self._token_id else None

    def __del__(self):
        if getattr(self, "_owns_connection", False):
            conn = getattr(self, "conn", None)
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass

    def _resolve_token_id(self, query: str, *, auto_fetch: bool) -> str | None:
        normalized = _normalize_query(query)
        if not normalized:
            return None

        alias = get_alias_resolution(self.conn, normalized)
        if alias is not None:
            return alias["token_id"]

        exact_row = fetch_token_row(self.conn, normalized)
        if exact_row is not None:
            upsert_alias_resolution(normalized, exact_row["id"], "coin_id", self.conn)
            self.conn.commit()
            return exact_row["id"]

        if not auto_fetch:
            return None

        resolved = resolve_coin(query)
        token_id = str(resolved["id"])
        upsert_alias_resolution(normalized, token_id, "search", self.conn)

        if fetch_token_row(self.conn, token_id) is None:
            token_data = fetch_coin_data_by_id(token_id, include_market_data=False)
            upsert_token_data(token_data, self.conn)
        else:
            self.conn.commit()

        return token_id

    def _load_token_data(self, token_id: str | None) -> dict[str, Any] | None:
        if not token_id:
            return None

        token_row = fetch_token_row(self.conn, token_id)
        if token_row is None:
            return None

        contracts = fetch_token_contract_rows(self.conn, token_id)
        data = _deserialize_token_row(dict(token_row))
        data["platform_details"] = _contract_rows_to_details([dict(row) for row in contracts])
        data["contract_addresses"] = {
            contract["platform"]: contract["contract_address"]
            for contract in data["platform_details"]
        }
        return data

    def refresh(self, *, include_supply: bool = False) -> dict[str, Any]:
        resolved = resolve_coin(self.query)
        token_id = str(resolved["id"])
        token_data = fetch_coin_data_by_id(token_id, include_market_data=include_supply)
        upsert_token_data(token_data, self.conn)
        upsert_alias_resolution(_normalize_query(self.query), token_id, "search", self.conn)
        self.conn.commit()
        self._token_id = token_id
        self._data = self._load_token_data(token_id)
        if self._data is None:
            raise RuntimeError(f"Failed to load token data for {self.query!r} after fetch")
        return self._data

    @property
    def exists(self) -> bool:
        return self._data is not None

    @property
    def data(self) -> dict[str, Any]:
        if self._data is None:
            raise LookupError(f"No token data available for {self.query!r}")
        return self._data

    @property
    def id(self) -> str | None:
        return self.data.get("id")

    @property
    def symbol(self) -> str | None:
        return self.data.get("symbol")

    @property
    def name(self) -> str | None:
        return self.data.get("name")

    @property
    def market_cap_rank(self) -> int | None:
        return self.data.get("market_cap_rank")

    @property
    def asset_platform_id(self) -> str | None:
        return self.data.get("asset_platform_id")

    @property
    def contract_addresses(self) -> dict[str, Any]:
        return self.data.get("contract_addresses") or {}

    @property
    def platform_details(self) -> list[dict[str, Any]]:
        return self.data.get("platform_details") or []

    @property
    def decimals(self) -> dict[str, Any]:
        return {
            platform["platform"]: platform.get("decimals")
            for platform in self.platform_details
            if platform.get("platform")
        }

    def get_address(self, chain: str) -> str | None:
        return self.contract_addresses.get(chain)

    @property
    def homepage(self) -> str | None:
        links = self.links.get("homepage") or []
        return next((url for url in links if url), None)

    @property
    def circulating_supply(self):
        return self.data.get("circulating_supply")

    @property
    def total_supply(self):
        return self.data.get("total_supply")

    @property
    def max_supply(self):
        return self.data.get("max_supply")

    @property
    def categories(self) -> list[str]:
        return self.data.get("categories_json") or []

    @property
    def links(self) -> dict[str, Any]:
        return self.data.get("links_json") or {}

    @property
    def image(self) -> dict[str, Any]:
        return self.data.get("image_json") or {}

    @property
    def description(self) -> dict[str, Any]:
        return self.data.get("description_json") or {}

    @property
    def developer_data(self) -> dict[str, Any]:
        return self.data.get("developer_data_json") or {}

    @property
    def community_data(self) -> dict[str, Any]:
        return self.data.get("community_data_json") or {}

    @property
    def public_interest_stats(self) -> dict[str, Any]:
        return self.data.get("public_interest_stats_json") or {}

    @property
    def raw(self) -> dict[str, Any] | None:
        return self.data.get("raw_json")


def _build_coin_maps(
    coins: list[dict[str, Any]],
) -> tuple[dict[str, list[dict[str, Any]]], dict[str, dict[str, Any]]]:
    by_symbol: dict[str, list[dict[str, Any]]] = {}
    by_id: dict[str, dict[str, Any]] = {}

    for coin in coins:
        coin_id = str(coin.get("id", "")).casefold()
        if coin_id:
            by_id[coin_id] = coin

        symbol = coin.get("symbol")
        if symbol:
            by_symbol.setdefault(_normalize_query(symbol), []).append(coin)

    return by_symbol, by_id


def populate_token_ids(
    coin_ids: list[str],
    conn=None,
    *,
    include_supply: bool = False,
    include_raw: bool = True,
    stop_on_rate_limit: bool = True,
) -> dict[str, Any]:
    owns_connection = conn is None
    if conn is None:
        conn = _init_tables()

    requested = []
    seen: set[str] = set()
    for coin_id in coin_ids:
        normalized = _normalize_query(coin_id)
        if normalized and normalized not in seen:
            requested.append((coin_id, normalized))
            seen.add(normalized)

    inserted_ids: list[str] = []
    skipped: list[str] = []
    failed: list[dict[str, str]] = []
    processed: list[str] = []
    rate_limited = False
    retry_after = None

    try:
        for original, normalized in requested:
            processed.append(original)

            if fetch_token_row(conn, normalized) is not None:
                skipped.append(original)
                upsert_alias_resolution(normalized, normalized, "coin_id", conn)
                conn.commit()
                continue

            try:
                token_data = fetch_coin_data_by_id(
                    normalized,
                    include_raw=include_raw,
                    include_market_data=include_supply,
                )
            except CoinGeckoRateLimitError as exc:
                rate_limited = True
                retry_after = exc.retry_after
                failed.append({"query": original, "reason": str(exc)})
                if stop_on_rate_limit:
                    break
                continue
            except CoinGeckoError as exc:
                failed.append({"query": original, "reason": str(exc)})
                continue

            upsert_token_data(token_data, conn)
            upsert_alias_resolution(original, token_data["id"], "coin_id", conn)
            conn.commit()
            inserted_ids.append(token_data["id"])
    finally:
        if owns_connection:
            conn.close()

    return {
        "requested": [original for original, _ in requested],
        "processed": processed,
        "remaining": [original for original, _ in requested if original not in processed],
        "inserted_ids": inserted_ids,
        "inserted_count": len(inserted_ids),
        "skipped": skipped,
        "skipped_count": len(skipped),
        "failed": failed,
        "failed_count": len(failed),
        "rate_limited": rate_limited,
        "retry_after": retry_after,
    }


def populate_tokens(
    queries: list[str],
    conn=None,
    *,
    include_supply: bool = False,
    refresh_existing: bool = False,
    include_raw: bool = True,
    stop_on_rate_limit: bool = True,
) -> dict[str, Any]:
    owns_connection = conn is None
    if conn is None:
        conn = _init_tables()

    requested = []
    seen: set[str] = set()
    for query in queries:
        normalized = _normalize_query(query)
        if normalized and normalized not in seen:
            requested.append((query, normalized))
            seen.add(normalized)

    id_map = fetch_coin_id_map(include_platforms=False)
    coins_by_symbol, coins_by_id = _build_coin_maps(id_map)

    resolved: list[dict[str, str]] = []
    skipped: list[str] = []
    unresolved: list[str] = []
    ambiguous: list[dict[str, Any]] = []
    failed: list[dict[str, str]] = []
    processed: list[str] = []
    inserted_ids: list[str] = []
    rate_limited = False
    retry_after = None

    try:
        for original, normalized in requested:
            processed.append(original)

            alias = get_alias_resolution(conn, normalized)
            if alias is not None:
                token_id = alias["token_id"]
                resolved.append({"query": original, "token_id": token_id, "source": "alias"})
                if not refresh_existing and fetch_token_row(conn, token_id) is not None:
                    skipped.append(original)
                    continue
            elif normalized in coins_by_id:
                token_id = normalized
                resolved.append({"query": original, "token_id": token_id, "source": "coin_id"})
                if not refresh_existing and fetch_token_row(conn, token_id) is not None:
                    upsert_alias_resolution(normalized, token_id, "coin_id", conn)
                    conn.commit()
                    skipped.append(original)
                    continue
            else:
                candidate, alternatives = _resolve_symbol_candidates(
                    original, coins_by_symbol.get(normalized, [])
                )
                if candidate is None:
                    if alternatives:
                        ambiguous.append(
                            {
                                "query": original,
                                "candidates": [
                                    {
                                        "id": item.get("id"),
                                        "symbol": item.get("symbol"),
                                        "name": item.get("name"),
                                        "market_cap_rank": item.get("market_cap_rank"),
                                    }
                                    for item in alternatives[:10]
                                ],
                            }
                        )
                    else:
                        unresolved.append(original)
                    continue

                token_id = str(candidate["id"])
                resolved.append({"query": original, "token_id": token_id, "source": "symbol"})
                if not refresh_existing and fetch_token_row(conn, token_id) is not None:
                    upsert_alias_resolution(normalized, token_id, "symbol", conn)
                    conn.commit()
                    skipped.append(original)
                    continue

            try:
                token_data = fetch_coin_data_by_id(
                    token_id,
                    include_raw=include_raw,
                    include_market_data=include_supply,
                )
            except CoinGeckoRateLimitError as exc:
                rate_limited = True
                retry_after = exc.retry_after
                failed.append({"query": original, "reason": str(exc)})
                if stop_on_rate_limit:
                    break
                continue
            except CoinGeckoError as exc:
                failed.append({"query": original, "reason": str(exc)})
                continue

            upsert_token_data(token_data, conn)
            upsert_alias_resolution(normalized, token_data["id"], "symbol", conn)
            conn.commit()
            inserted_ids.append(token_data["id"])
    finally:
        if owns_connection:
            conn.close()

    return {
        "requested": [original for original, _ in requested],
        "processed": processed,
        "remaining": [original for original, _ in requested if original not in processed],
        "resolved": resolved,
        "resolved_count": len(resolved),
        "inserted_ids": inserted_ids,
        "inserted_count": len(inserted_ids),
        "skipped": skipped,
        "skipped_count": len(skipped),
        "unresolved": unresolved,
        "unresolved_count": len(unresolved),
        "ambiguous": ambiguous,
        "ambiguous_count": len(ambiguous),
        "failed": failed,
        "failed_count": len(failed),
        "rate_limited": rate_limited,
        "retry_after": retry_after,
    }
