from __future__ import annotations

import json
import os
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

BASE_URL = "https://api.coingecko.com/api/v3"
DEFAULT_TIMEOUT_SECONDS = 30


class CoinGeckoError(RuntimeError):
    """Raised when CoinGecko data cannot be fetched or resolved."""


class CoinGeckoRateLimitError(CoinGeckoError):
    """Raised when CoinGecko rejects a request due to rate limiting."""

    def __init__(self, message: str, *, retry_after: int | None = None):
        super().__init__(message)
        self.retry_after = retry_after


def _coingecko_headers() -> dict[str, str]:
    headers = {
        "accept": "application/json",
        "user-agent": "geckors/0.1.0",
    }

    demo_key = os.getenv("COINGECKO_DEMO_API_KEY")
    pro_key = os.getenv("COINGECKO_PRO_API_KEY")

    if pro_key:
        headers["x-cg-pro-api-key"] = pro_key
    elif demo_key:
        headers["x-cg-demo-api-key"] = demo_key

    return headers


def _get_json(path: str, params: dict[str, Any] | None = None) -> Any:
    url = f"{BASE_URL}{path}"
    if params:
        encoded = urlencode(params)
        if encoded:
            url = f"{url}?{encoded}"

    request = Request(url, headers=_coingecko_headers(), method="GET")

    try:
        with urlopen(request, timeout=DEFAULT_TIMEOUT_SECONDS) as response:
            return json.load(response)
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        retry_after = exc.headers.get("Retry-After")
        retry_after_seconds = None
        if retry_after:
            try:
                retry_after_seconds = int(retry_after)
            except ValueError:
                retry_after_seconds = None
        if exc.code == 429:
            raise CoinGeckoRateLimitError(
                f"CoinGecko rate limit exceeded for {url}: {detail}",
                retry_after=retry_after_seconds,
            ) from exc
        raise CoinGeckoError(
            f"CoinGecko request failed with HTTP {exc.code} for {url}: {detail}"
        ) from exc
    except URLError as exc:
        raise CoinGeckoError(f"CoinGecko request failed for {url}: {exc.reason}") from exc


def _resolve_coin_id(ticker: str) -> dict[str, Any]:
    query = ticker.strip()
    if not query:
        raise ValueError("ticker must not be empty")

    search_results = _get_json("/search", {"query": query})
    coins = search_results.get("coins", [])
    if not coins:
        raise CoinGeckoError(f"No CoinGecko results found for ticker {ticker!r}")

    normalized = query.casefold()
    exact_symbol_matches = [
        coin for coin in coins if str(coin.get("symbol", "")).casefold() == normalized
    ]
    exact_id_matches = [
        coin for coin in coins if str(coin.get("id", "")).casefold() == normalized
    ]

    candidates = exact_symbol_matches or exact_id_matches or coins
    candidates.sort(key=lambda coin: coin.get("market_cap_rank") or float("inf"))
    return candidates[0]


def resolve_coin(ticker: str) -> dict[str, Any]:
    return _resolve_coin_id(ticker)


def fetch_coin_id_map(*, include_platforms: bool = False) -> list[dict[str, Any]]:
    return _get_json("/coins/list", {"include_platform": str(include_platforms).lower()})


def _normalize_platforms(detail_platforms: dict[str, Any]) -> list[dict[str, Any]]:
    platforms: list[dict[str, Any]] = []
    for platform_name, details in detail_platforms.items():
        if not isinstance(details, dict):
            continue
        platforms.append(
            {
                "platform": platform_name,
                "contract_address": details.get("contract_address"),
                "decimals": details.get("decimal_place"),
            }
        )
    return platforms


def _build_coin_result(payload: dict[str, Any], *, include_raw: bool) -> dict[str, Any]:
    market_data = payload.get("market_data") or {}
    links = payload.get("links") or {}
    detail_platforms = payload.get("detail_platforms") or {}

    result = {
        "id": payload.get("id"),
        "symbol": payload.get("symbol"),
        "name": payload.get("name"),
        "web_slug": payload.get("web_slug"),
        "market_cap_rank": payload.get("market_cap_rank"),
        "asset_platform_id": payload.get("asset_platform_id"),
        "hashing_algorithm": payload.get("hashing_algorithm"),
        "block_time_in_minutes": payload.get("block_time_in_minutes"),
        "categories": payload.get("categories") or [],
        "description": payload.get("description") or {},
        "links": {
            "homepage": links.get("homepage") or [],
            "blockchain_site": links.get("blockchain_site") or [],
            "official_forum_url": links.get("official_forum_url") or [],
            "chat_url": links.get("chat_url") or [],
            "announcement_url": links.get("announcement_url") or [],
            "twitter_screen_name": links.get("twitter_screen_name"),
            "facebook_username": links.get("facebook_username"),
            "telegram_channel_identifier": links.get("telegram_channel_identifier"),
            "subreddit_url": links.get("subreddit_url"),
            "repos_url": links.get("repos_url") or {},
        },
        "image": payload.get("image") or {},
        "contract_addresses": payload.get("platforms") or {},
        "platform_details": _normalize_platforms(detail_platforms),
        "supply": {
            "circulating_supply": market_data.get("circulating_supply"),
            "total_supply": market_data.get("total_supply"),
            "max_supply": market_data.get("max_supply"),
        },
        "market_data": {
            "current_price": market_data.get("current_price") or {},
            "market_cap": market_data.get("market_cap") or {},
            "fully_diluted_valuation": market_data.get("fully_diluted_valuation") or {},
            "total_volume": market_data.get("total_volume") or {},
            "high_24h": market_data.get("high_24h") or {},
            "low_24h": market_data.get("low_24h") or {},
            "ath": market_data.get("ath") or {},
            "ath_change_percentage": market_data.get("ath_change_percentage") or {},
            "ath_date": market_data.get("ath_date") or {},
            "atl": market_data.get("atl") or {},
            "atl_change_percentage": market_data.get("atl_change_percentage") or {},
            "atl_date": market_data.get("atl_date") or {},
            "price_change_24h": market_data.get("price_change_24h"),
            "price_change_percentage_24h": market_data.get(
                "price_change_percentage_24h"
            ),
            "price_change_percentage_7d": market_data.get(
                "price_change_percentage_7d"
            ),
            "price_change_percentage_14d": market_data.get(
                "price_change_percentage_14d"
            ),
            "price_change_percentage_30d": market_data.get(
                "price_change_percentage_30d"
            ),
            "price_change_percentage_60d": market_data.get(
                "price_change_percentage_60d"
            ),
            "price_change_percentage_200d": market_data.get(
                "price_change_percentage_200d"
            ),
            "price_change_percentage_1y": market_data.get(
                "price_change_percentage_1y"
            ),
            "circulating_supply": market_data.get("circulating_supply"),
            "total_supply": market_data.get("total_supply"),
            "max_supply": market_data.get("max_supply"),
            "last_updated": market_data.get("last_updated"),
        },
        "community_data": payload.get("community_data") or {},
        "developer_data": payload.get("developer_data") or {},
        "public_interest_stats": payload.get("public_interest_stats") or {},
        "last_updated": payload.get("last_updated"),
    }

    if include_raw:
        result["raw"] = payload

    return result


def fetch_coin_data_by_id(
    coin_id: str,
    *,
    include_raw: bool = True,
    include_market_data: bool = True,
) -> dict[str, Any]:
    payload = _get_json(
        f"/coins/{coin_id}",
        {
            "localization": "false",
            "tickers": "false",
            "market_data": str(include_market_data).lower(),
            "community_data": "true",
            "developer_data": "true",
            "sparkline": "false",
        },
    )
    return _build_coin_result(payload, include_raw=include_raw)


def fetch_coin_data(
    ticker: str,
    *,
    include_raw: bool = True,
    include_market_data: bool = True,
) -> dict[str, Any]:
    """
    Fetch normalized CoinGecko metadata and market data for a ticker or coin id.

    The function resolves the best matching CoinGecko coin via `/search`, then
    fetches `/coins/{id}` and returns a compact structure that surfaces the most
    useful fields for token metadata, supply, links, and market statistics.
    """
    resolved = _resolve_coin_id(ticker)
    return fetch_coin_data_by_id(
        resolved["id"],
        include_raw=include_raw,
        include_market_data=include_market_data,
    )
