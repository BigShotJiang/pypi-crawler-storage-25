from __future__ import annotations

import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from geckors.data.db import (
    _init_tables,
    fetch_token_contract_rows,
    fetch_token_row,
    get_alias_resolution,
    upsert_token_data,
)
from geckors.fetch import CoinGeckoRateLimitError
from geckors.token import Token, populate_token_ids, populate_tokens


def sample_token_data(
    token_id: str = "ethereum",
    symbol: str = "eth",
    name: str = "Ethereum",
) -> dict:
    return {
        "id": token_id,
        "symbol": symbol,
        "name": name,
        "web_slug": token_id,
        "market_cap_rank": 2,
        "asset_platform_id": None,
        "hashing_algorithm": "Ethash",
        "block_time_in_minutes": 12,
        "categories": ["Layer 1"],
        "description": {"en": "test"},
        "links": {"homepage": ["https://example.com"]},
        "image": {"thumb": "https://example.com/thumb.png"},
        "contract_addresses": {
            "ethereum": "0x123",
            "arbitrum-one": "0x123",
        },
        "platform_details": [
            {
                "platform": "ethereum",
                "contract_address": "0x123",
                "decimals": 18,
            },
            {
                "platform": "arbitrum-one",
                "contract_address": "0x123",
                "decimals": 18,
            },
        ],
        "supply": {
            "circulating_supply": 10.0,
            "total_supply": 20.0,
            "max_supply": None,
        },
        "community_data": {},
        "developer_data": {"stars": 1},
        "public_interest_stats": {},
        "last_updated": "2026-04-22T00:00:00Z",
        "raw": {"id": token_id},
    }


class TokenWorkflowTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmpdir = tempfile.TemporaryDirectory()
        self.db_path = str(Path(self.tmpdir.name) / "geckors.db")
        self.conn = _init_tables(self.db_path)

    def tearDown(self) -> None:
        self.conn.close()
        self.tmpdir.cleanup()

    def test_upsert_stores_contracts_in_child_table(self) -> None:
        upsert_token_data(sample_token_data(), self.conn)

        token_row = fetch_token_row(self.conn, "ethereum")
        contract_rows = fetch_token_contract_rows(self.conn, "ethereum")

        self.assertIsNotNone(token_row)
        self.assertEqual(token_row["name"], "Ethereum")
        self.assertEqual(len(contract_rows), 2)
        self.assertEqual(contract_rows[0]["chain"], "arbitrum-one")

    def test_token_prefers_alias_resolution_and_contracts_property(self) -> None:
        upsert_token_data(sample_token_data(), self.conn)

        with mock.patch("geckors.token.resolve_coin") as resolve_coin:
            token = Token("ETH", conn=self.conn, auto_fetch=False)
            self.assertEqual(token.id, "ethereum")
            self.assertEqual(token.get_address("ethereum"), "0x123")
            self.assertEqual(token.decimals["ethereum"], 18)
            resolve_coin.assert_not_called()

    def test_populate_tokens_reports_ambiguity(self) -> None:
        with mock.patch(
            "geckors.token.fetch_coin_id_map",
            return_value=[
                {"id": "m-by-mexc", "symbol": "m", "name": "M by MEXC", "market_cap_rank": None},
                {"id": "marinade", "symbol": "m", "name": "Marinade", "market_cap_rank": 200},
            ],
        ):
            result = populate_tokens(["M"], conn=self.conn)

        self.assertEqual(result["ambiguous_count"], 1)
        self.assertEqual(result["inserted_count"], 0)
        self.assertEqual(result["ambiguous"][0]["query"], "M")
        self.assertEqual(len(result["ambiguous"][0]["candidates"]), 2)

    def test_populate_token_ids_handles_rate_limit_without_crashing(self) -> None:
        with mock.patch(
            "geckors.token.fetch_coin_data_by_id",
            side_effect=CoinGeckoRateLimitError("rate limited", retry_after=15),
        ):
            result = populate_token_ids(["ethereum"], conn=self.conn)

        self.assertTrue(result["rate_limited"])
        self.assertEqual(result["retry_after"], 15)
        self.assertEqual(result["failed_count"], 1)

    def test_populate_tokens_persists_aliases(self) -> None:
        with mock.patch(
            "geckors.token.fetch_coin_id_map",
            return_value=[
                {
                    "id": "ethereum",
                    "symbol": "eth",
                    "name": "Ethereum",
                    "market_cap_rank": 2,
                }
            ],
        ), mock.patch(
            "geckors.token.fetch_coin_data_by_id",
            return_value=sample_token_data(),
        ):
            result = populate_tokens(["ETH"], conn=self.conn)

        alias = get_alias_resolution(self.conn, "eth")
        self.assertEqual(result["inserted_count"], 1)
        self.assertIsNotNone(alias)
        self.assertEqual(alias["token_id"], "ethereum")


class MigrationTests(unittest.TestCase):
    def test_old_schema_is_migrated(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = str(Path(tmpdir) / "legacy.db")
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            conn.execute(
                """
                CREATE TABLE tokens (
                    id TEXT PRIMARY KEY,
                    symbol TEXT,
                    name TEXT,
                    current_price_json TEXT,
                    fetched_at TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                INSERT INTO tokens (id, symbol, name, current_price_json, fetched_at)
                VALUES ('ethereum', 'eth', 'Ethereum', '{}', '2026-04-22T00:00:00+00:00')
                """
            )
            conn.commit()
            conn.close()

            migrated = _init_tables(db_path)
            columns = [row["name"] for row in migrated.execute("PRAGMA table_info(tokens)")]
            row = migrated.execute("SELECT id, symbol, name FROM tokens").fetchone()
            migrated.close()

        self.assertNotIn("current_price_json", columns)
        self.assertEqual(tuple(row), ("ethereum", "eth", "Ethereum"))

    def test_legacy_raw_json_is_backfilled_into_token_contracts(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = str(Path(tmpdir) / "legacy_contracts.db")
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            conn.execute(
                """
                CREATE TABLE tokens (
                    id TEXT PRIMARY KEY,
                    symbol TEXT,
                    name TEXT,
                    raw_json TEXT,
                    fetched_at TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                INSERT INTO tokens (
                    id, symbol, name, raw_json, fetched_at
                ) VALUES (?, ?, ?, ?, ?)
                """,
                (
                    "dai",
                    "dai",
                    "Dai",
                    '{"platforms":{"ethereum":"0x6b175474e89094c44da98b954eedeac495271d0f"},"detail_platforms":{"ethereum":{"contract_address":"0x6b175474e89094c44da98b954eedeac495271d0f","decimal_place":18}}}',
                    "2026-04-22T00:00:00+00:00",
                ),
            )
            conn.commit()
            conn.close()

            migrated = _init_tables(db_path)
            contracts = migrated.execute(
                """
                SELECT chain, contract_address, decimals
                FROM token_contracts
                WHERE token_id = 'dai'
                """
            ).fetchall()
            migrated.close()

        self.assertEqual(len(contracts), 1)
        self.assertEqual(
            tuple(contracts[0]),
            ("ethereum", "0x6b175474e89094c44da98b954eedeac495271d0f", 18),
        )


if __name__ == "__main__":
    unittest.main()
