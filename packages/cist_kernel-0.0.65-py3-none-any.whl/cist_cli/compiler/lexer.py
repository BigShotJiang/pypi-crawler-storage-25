"""CIST lexer / compiler — parses .cis source into a validated IR dict."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class ValidationError(Exception):
    """Raised when CIST syntax or semantic validation fails."""


@dataclass(frozen=True)
class SyntaxIssue:
    line: int
    message: str
    severity: str = "error"


class CISTCompiler:
    """Perform local validation for CIST source files and produce an IR dict.

    The IR dict has the following keys:

    * ``content``     – raw source text
    * ``modules``     – list of ``use`` module names
    * ``data_streams``– count of ``from data(…)`` expressions
    * ``line_count``  – total lines in the file
    * ``contracts``   – list of ``contract <Name>:`` identifiers found
    * ``functions``   – list of ``write fn <name>`` / ``write <name>`` identifiers found
    * ``structs``     – list of ``struct <Name>:`` identifiers found
    * ``macros``      – list of ``macro <name>(…)`` identifiers found
    * ``typed_vars``  – list of ``{"name": str, "type": str}`` for explicit typed declarations
    * ``warnings``    – list of :class:`SyntaxIssue` with severity ``"warning"``
    """

    # ── pattern constants ────────────────────────────────────────────────────
    USE_PATTERN         = re.compile(r"^use\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*$")
    FROM_DATA_PATTERN   = re.compile(r"\bfrom\s+data\b(?=\s*\()")
    CONTRACT_PATTERN    = re.compile(r"^contract\s+([A-Za-z_][A-Za-z0-9_]*)\s*:")
    FUNCTION_PATTERN    = re.compile(r"^write\s+(?:fn\s+)?([a-zA-Z_][a-zA-Z0-9_]*)\s*\(")
    STRUCT_PATTERN      = re.compile(r"^struct\s+([A-Za-z_][A-Za-z0-9_]*)\s*:")
    MACRO_PATTERN       = re.compile(r"^macro\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\(")
    # Matches:  name::type [props] =  (the '=' anchors that this is a declaration)
    TYPED_DECL_PATTERN  = re.compile(
        r"^([a-zA-Z_][a-zA-Z0-9_]*)::([a-zA-Z_][a-zA-Z0-9_]*)"
        r"\s*(?:\[([^\]]*)\])?\s*="
    )

    # ── type system constants ────────────────────────────────────────────────
    _PRIMITIVE_TYPES     = frozenset({"str", "int", "float", "bool", "list", "dict"})
    _VALID_STR_ENCODINGS = frozenset({"utf-8", "ascii", "utf-16"})
    _VALID_INT_SIZES     = frozenset({"1", "2", "4", "8"})
    _VALID_FLOAT_SIZES   = frozenset({"4", "8"})
    _VALID_BOOL_MODES    = frozenset({"strict", "lax"})

    # ── helpers ──────────────────────────────────────────────────────────────

    @staticmethod
    def _is_escaped(line: str, index: int) -> bool:
        backslash_count = 0
        cursor = index - 1
        while cursor >= 0 and line[cursor] == "\\":
            backslash_count += 1
            cursor -= 1
        return backslash_count % 2 == 1

    def _validate_type_properties(
        self, type_name: str, props_str: str | None, line_num: int
    ) -> list[SyntaxIssue]:
        """Validate the property list for a typed declaration.

        Validation only runs when *props_str* is provided (static / explicit
        mode).  In lax / interpreted mode (``props_str`` is ``None``) no
        issues are raised — the LLM adapter fills in the defaults at runtime.
        Non-primitive type names (e.g. a struct or contract) are also skipped.
        """
        issues: list[SyntaxIssue] = []

        if type_name not in self._PRIMITIVE_TYPES or props_str is None:
            return issues

        parts = [p.strip() for p in props_str.split(",")]

        if type_name == "str":
            # [capacity, encoding]
            if len(parts) > 2:
                issues.append(SyntaxIssue(
                    line=line_num,
                    message="str properties: expected [capacity, encoding]  e.g. [32, utf-8]",
                ))
            else:
                cap = parts[0]
                if cap != "dynamic":
                    try:
                        if int(cap) < 1:
                            raise ValueError
                    except ValueError:
                        issues.append(SyntaxIssue(
                            line=line_num,
                            message=f"str capacity must be a positive integer or 'dynamic', got '{cap}'",
                        ))
                if len(parts) == 2:
                    enc = parts[1].lower()
                    if enc not in self._VALID_STR_ENCODINGS:
                        issues.append(SyntaxIssue(
                            line=line_num,
                            message=(
                                f"str encoding '{parts[1]}' not recognised; "
                                f"expected one of: {', '.join(sorted(self._VALID_STR_ENCODINGS))}"
                            ),
                        ))

        elif type_name == "int":
            # [size_bytes, padding]
            if len(parts) > 2:
                issues.append(SyntaxIssue(
                    line=line_num,
                    message="int properties: expected [size_bytes, padding]  e.g. [4, 0]",
                ))
            elif parts:
                size = parts[0]
                if size not in self._VALID_INT_SIZES:
                    issues.append(SyntaxIssue(
                        line=line_num,
                        message=(
                            f"int size '{size}' not valid; "
                            f"expected one of: {', '.join(sorted(self._VALID_INT_SIZES))} (bytes)"
                        ),
                    ))
                if len(parts) == 2:
                    try:
                        int(parts[1])
                    except ValueError:
                        issues.append(SyntaxIssue(
                            line=line_num,
                            message=f"int padding must be an integer, got '{parts[1]}'",
                        ))

        elif type_name == "float":
            # [size_bytes, precision]
            if len(parts) > 2:
                issues.append(SyntaxIssue(
                    line=line_num,
                    message="float properties: expected [size_bytes, precision]  e.g. [8, 2]",
                ))
            elif parts:
                size = parts[0]
                if size not in self._VALID_FLOAT_SIZES:
                    issues.append(SyntaxIssue(
                        line=line_num,
                        message=f"float size '{size}' not valid; expected 4 (32-bit) or 8 (64-bit)",
                    ))
                if len(parts) == 2:
                    try:
                        if int(parts[1]) < 0:
                            raise ValueError
                    except ValueError:
                        issues.append(SyntaxIssue(
                            line=line_num,
                            message=f"float precision must be a non-negative integer, got '{parts[1]}'",
                        ))

        elif type_name == "bool":
            # [strict|lax]
            if len(parts) != 1:
                issues.append(SyntaxIssue(
                    line=line_num,
                    message="bool properties: expected exactly [strict] or [lax]",
                ))
            else:
                mode = parts[0].lower()
                if mode not in self._VALID_BOOL_MODES:
                    issues.append(SyntaxIssue(
                        line=line_num,
                        message=f"bool mode must be 'strict' or 'lax', got '{parts[0]}'",
                    ))

        elif type_name == "list":
            # [capacity, element_type]
            if len(parts) > 2:
                issues.append(SyntaxIssue(
                    line=line_num,
                    message="list properties: expected [capacity, element_type]  e.g. [100, int]",
                ))
            elif parts:
                cap = parts[0]
                if cap != "dynamic":
                    try:
                        if int(cap) < 1:
                            raise ValueError
                    except ValueError:
                        issues.append(SyntaxIssue(
                            line=line_num,
                            message=f"list capacity must be a positive integer or 'dynamic', got '{cap}'",
                        ))

        elif type_name == "dict":
            # [capacity, key_type]
            if len(parts) > 2:
                issues.append(SyntaxIssue(
                    line=line_num,
                    message="dict properties: expected [capacity, key_type]  e.g. [50, str]",
                ))
            elif parts:
                cap = parts[0]
                if cap != "dynamic":
                    try:
                        if int(cap) < 1:
                            raise ValueError
                    except ValueError:
                        issues.append(SyntaxIssue(
                            line=line_num,
                            message=f"dict capacity must be a positive integer or 'dynamic', got '{cap}'",
                        ))

        return issues

    # ── core scanner ─────────────────────────────────────────────────────────

    def _scan(self, content: str) -> tuple[list[SyntaxIssue], dict[str, Any]]:
        """Scan *content* and return ``(all_issues, partial_ir)``.

        Never raises — all problems are collected as :class:`SyntaxIssue`
        objects.  Callers decide whether to raise or return a structured result.
        """
        lines = content.split("\n")
        issues: list[SyntaxIssue] = []
        modules:    list[str]           = []
        contracts:  list[str]           = []
        functions:  list[str]           = []
        structs:    list[str]           = []
        macros:     list[str]           = []
        typed_vars: list[dict[str, str]] = []
        data_stream_count = 0

        bracket_stack: list[tuple[str, int]] = []
        open_chars  = {"(", "[", "{"}
        close_chars = {")": "(", "]": "[", "}": "{"}
        in_string        = False
        string_char: str | None = None
        string_start_line = 0

        for line_num, line in enumerate(lines, start=1):
            # ── indentation check ────────────────────────────────────────────
            leading = line[: len(line) - len(line.lstrip(" \t"))]
            if " " in leading and "\t" in leading:
                issues.append(SyntaxIssue(
                    line=line_num,
                    message="Mixed tabs and spaces in indentation",
                    severity="warning",
                ))

            # ── character-level scan (bracket matching + string tracking) ────
            code_buffer: list[str] = []
            index = 0
            while index < len(line):
                char = line[index]

                if in_string:
                    if char == string_char and not self._is_escaped(line, index):
                        in_string = False
                        string_char = None
                        string_start_line = 0
                    index += 1
                    continue

                if char == "#":
                    break

                if char in {'"', "'"}:
                    in_string = True
                    string_char = char
                    string_start_line = line_num
                    index += 1
                    continue

                code_buffer.append(char)
                if char in open_chars:
                    bracket_stack.append((char, line_num))
                elif char in close_chars:
                    if not bracket_stack:
                        issues.append(SyntaxIssue(
                            line=line_num,
                            message=f"Unmatched closing bracket '{char}'",
                        ))
                    else:
                        last_open, last_line = bracket_stack.pop()
                        if last_open != close_chars[char]:
                            issues.append(SyntaxIssue(
                                line=line_num,
                                message=(
                                    f"Mismatched bracket: {last_open} closed with {char} "
                                    f"(opened line {last_line})"
                                ),
                            ))

                index += 1

            stripped_code = "".join(code_buffer).strip()

            # ── keyword-level checks ─────────────────────────────────────────

            # use <module>
            if stripped_code.startswith("use "):
                match = self.USE_PATTERN.fullmatch(stripped_code)
                if match is None:
                    issues.append(SyntaxIssue(line=line_num, message="Invalid use statement"))
                else:
                    modules.append(match.group(1))

            # from data(…)
            if "from data" in stripped_code:
                if not self.FROM_DATA_PATTERN.search(stripped_code):
                    issues.append(SyntaxIssue(line=line_num, message="Invalid 'from data' expression"))
                else:
                    data_stream_count += len(self.FROM_DATA_PATTERN.findall(stripped_code))

            # contract <Name>:
            contract_match = self.CONTRACT_PATTERN.match(stripped_code)
            if contract_match:
                contracts.append(contract_match.group(1))

            # write [fn] <name>(…)
            fn_match = self.FUNCTION_PATTERN.match(stripped_code)
            if fn_match:
                functions.append(fn_match.group(1))

            # struct <Name>:
            struct_match = self.STRUCT_PATTERN.match(stripped_code)
            if struct_match:
                structs.append(struct_match.group(1))

            # macro <name>(…)
            macro_match = self.MACRO_PATTERN.match(stripped_code)
            if macro_match:
                macros.append(macro_match.group(1))

            # name::type [props] = val  →  typed / static declaration
            typed_match = self.TYPED_DECL_PATTERN.match(stripped_code)
            if typed_match:
                var_name  = typed_match.group(1)
                type_name = typed_match.group(2)
                props_str = typed_match.group(3)   # None when no [props] supplied
                typed_vars.append({"name": var_name, "type": type_name})
                issues.extend(
                    self._validate_type_properties(type_name, props_str, line_num)
                )

        # ── end-of-file bracket / string checks ──────────────────────────────
        for char, open_line in bracket_stack:
            issues.append(SyntaxIssue(line=open_line, message=f"Unclosed bracket '{char}'"))

        if in_string:
            issues.append(SyntaxIssue(
                line=string_start_line or len(lines),
                message="Unclosed string at end of file",
            ))

        ir: dict[str, Any] = {
            "content":     content,
            "modules":     modules,
            "contracts":   contracts,
            "functions":   functions,
            "structs":     structs,
            "macros":      macros,
            "typed_vars":  typed_vars,
            "data_streams": data_stream_count,
            "line_count":  len(lines),
        }
        return issues, ir

    # ── public API ───────────────────────────────────────────────────────────

    def parse(self, content: str) -> dict[str, Any]:
        """Validate CIST source text and return the IR dict.

        Raises :class:`ValidationError` if any errors are found.
        """
        issues, ir = self._scan(content)
        errors = [i for i in issues if i.severity == "error"]
        if errors:
            summary = "\n".join(f"Line {i.line}: {i.message}" for i in errors[:5])
            raise ValidationError(f"Syntax validation failed:\n{summary}")
        return {**ir, "warnings": [i for i in issues if i.severity == "warning"]}

    def check_source(self, content: str) -> dict[str, Any]:
        """Check CIST source text and return structured diagnostics.

        Never raises.  Returns a dict with keys:

        * ``ok``       – ``True`` when there are no errors
        * ``errors``   – list of ``{"line", "col", "message", "severity"}`` dicts
        * ``warnings`` – list of ``{"line", "col", "message", "severity"}`` dicts
        * ``ir``       – the IR dict when ``ok`` is ``True``, else ``None``
        """
        issues, ir = self._scan(content)
        errors   = [i for i in issues if i.severity == "error"]
        warnings = [i for i in issues if i.severity == "warning"]

        def _to_dict(issue: SyntaxIssue) -> dict[str, Any]:
            return {"line": issue.line, "col": 0, "message": issue.message, "severity": issue.severity}

        return {
            "ok":       not errors,
            "errors":   [_to_dict(i) for i in errors],
            "warnings": [_to_dict(i) for i in warnings],
            "ir":       {**ir, "warnings": warnings} if not errors else None,
        }

    def check_file(self, filepath: Path) -> dict[str, Any]:
        """Check a ``.cis`` file and return structured diagnostics without raising."""
        try:
            content = filepath.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            return {
                "ok": False,
                "errors": [{"line": 1, "col": 0, "message": "File is not valid UTF-8 encoding", "severity": "error"}],
                "warnings": [],
                "ir": None,
            }
        except OSError as exc:
            return {
                "ok": False,
                "errors": [{"line": 1, "col": 0, "message": f"Cannot read file: {exc}", "severity": "error"}],
                "warnings": [],
                "ir": None,
            }
        return self.check_source(content)

    def compile_file(self, filepath: Path) -> dict[str, Any]:
        """Validate a ``.cis`` file from disk and return the IR dict.

        Raises :class:`ValidationError` on syntax / IO errors.
        """
        try:
            content = filepath.read_text(encoding="utf-8")
        except UnicodeDecodeError as exc:
            raise ValidationError("File is not valid UTF-8 encoding") from exc
        except OSError as exc:
            raise ValidationError(f"Cannot read file: {exc}") from exc
        return self.parse(content)

    def validate_file(self, filepath: Path) -> dict[str, Any]:
        """Alias for :meth:`compile_file`."""
        return self.compile_file(filepath)
