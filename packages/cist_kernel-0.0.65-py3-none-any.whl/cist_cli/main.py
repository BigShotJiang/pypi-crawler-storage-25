from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Any

import typer
from dotenv import load_dotenv
from rich.console import Console
from rich.rule import Rule
from rich.progress import Progress, SpinnerColumn, TextColumn

from . import __version__
from .compiler import CISTCompiler, MexWriter, MexReader, ValidationError
from .network import CloudCourier
from .workspace import init_workspace

load_dotenv()

# On Windows, pip --user installs scripts to a folder not on PATH by default.
# Detect this and print a one-time actionable fix before the user hits a
# confusing "not recognized" error (they'd have to be running via python -m to
# even reach this point, so we can give them instructions to fix it properly).

def _warn_windows_path() -> None:
    if sys.platform != "win32":
        return
    scripts_dir = Path(os.environ.get("APPDATA", "")) / "Python" / f"Python{sys.version_info.major}{sys.version_info.minor}" / "Scripts"
    if not scripts_dir.exists():
        return
    path_dirs = [Path(p) for p in os.environ.get("PATH", "").split(os.pathsep)]
    if scripts_dir not in path_dirs:
        _console = Console(stderr=True)
        _console.print(
            f"\n[yellow bold]Windows PATH notice:[/yellow bold] "
            f"[cyan]{scripts_dir}[/cyan] is not on your PATH.\n"
            f"Run this once in PowerShell to fix it permanently, then reopen your terminal:\n\n"
            f'  [bold][Environment]::SetEnvironmentVariable("PATH", $env:PATH + ";{scripts_dir}", "User")[/bold]\n'
        )

_warn_windows_path()

# Target old versions and historical typos for deletion
_LEGACY_EXTENSION_IDS: list[str] = [
    "tooig research lab.cist",
    "tooig-research-lab.cist", 
]

def _extension_install_roots() -> list[Path]:
    """Generate a list of all possible extension directories."""
    configured_root = os.environ.get("VSCODE_EXTENSIONS", "").strip()
    user_home = Path(os.environ.get("USERPROFILE") or str(Path.home()))

    roots: list[Path] = []
    if configured_root:
        roots.append(Path(configured_root))

    roots.extend([
        user_home / ".antigravity" / "extensions",
        user_home / ".vscode" / "extensions",
        user_home / ".vscode-insiders" / "extensions"
    ])

    return list(set(roots))

def _read_vsix_package(vsix: Path) -> dict[str, str]:
    with zipfile.ZipFile(vsix) as archive:
        with archive.open("extension/package.json") as package_file:
            package = json.load(package_file)

    return {
        "publisher": str(package["publisher"]),
        "name": str(package["name"]),
        "version": str(package["version"]),
    }

def _extract_vsix_to_dir(vsix: Path, target_dir: Path) -> None:
    """Extract VSIX contents into a fresh *target_dir*."""
    if target_dir.exists():
        shutil.rmtree(target_dir)
    target_dir.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(vsix) as archive:
        for member in archive.infolist():
            if member.is_dir() or not member.filename.startswith("extension/"):
                continue
            relative_name = member.filename[len("extension/"):]
            if not relative_name:
                continue
            destination = target_dir / relative_name
            destination.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(member) as source, destination.open("wb") as output:
                shutil.copyfileobj(source, output)


def _register_obsolete_dirs(root: Path, prefixes: list[str], exclude: Path) -> None:
    """Register old extension dirs in VS Code's ``.obsolete`` marker file.

    Listed directories are left completely untouched on disk so the running
    editor keeps loading them (icons, highlighting, language features) until
    the user reloads the window.  VS Code's ``cleanUp()`` on the very next
    full startup reads ``.obsolete`` and permanently removes the listed dirs.
    Directories are never renamed or deleted by us.
    """
    if not root.is_dir():
        return
    candidates = [
        e for e in root.iterdir()
        if e.is_dir() and e != exclude
        and any(e.name.lower().startswith(p.lower()) for p in prefixes)
    ]
    if not candidates:
        return
    obsolete_path = root / ".obsolete"
    try:
        data: dict[str, bool] = {}
        if obsolete_path.exists():
            try:
                data = json.loads(obsolete_path.read_text("utf-8"))
            except (json.JSONDecodeError, OSError):
                data = {}
        for entry in candidates:
            data[entry.name] = True
        obsolete_path.write_text(json.dumps(data), encoding="utf-8")
    except OSError:
        pass  # best-effort; stale dirs are cosmetic, not critical

def _latest_bundled_vsix() -> Path | None:
    assets_dir = Path(__file__).parent / "assets"
    vsix_files = sorted(assets_dir.glob("*.vsix"))
    if not vsix_files:
        return None
    return vsix_files[-1]

def _install_vscode_extension(vsix: Path) -> tuple[bool, str, bool]:
    """Silently extract the VSIX.  Returns ``(ok, message, is_new_install)``.

    *is_new_install* is ``False`` when every target root already had the
    correct version installed, meaning no editor reload is required.
    """
    try:
        package = _read_vsix_package(vsix)
    except Exception as exc:
        return False, f"Could not read VSIX metadata: {exc}", False

    extension_id = f"{package['publisher']}.{package['name']}"
    version = package["version"]

    installed_paths: list[str] = []
    skipped_paths: list[str] = []
    install_error: str | None = None

    for root in _extension_install_roots():
        try:
            # Standard versioned directory name — same scheme VS Code itself
            # uses.  VS Code's extension scanner picks the highest semver when
            # multiple versions of the same extension are present, so the new
            # dir wins on reload while the old one stays alive during the
            # current session (icons & highlighting remain intact).
            target_dir = root / f"{extension_id}-{version}"

            # Already installed this exact version — nothing to do.
            if target_dir.exists():
                skipped_paths.append(str(root.parent.name))
                continue

            root.mkdir(parents=True, exist_ok=True)

            # Prefixes covering the current id and all known legacy ids.  The
            # unversioned fixed-name dir (tooig-research-lab.cist/) from the
            # previous install scheme is also included so it gets cleaned up.
            all_prefixes = (
                [f"{ext_id.lower()}-" for ext_id in _LEGACY_EXTENSION_IDS]
                + [f"{extension_id.lower()}-", extension_id.lower()]
            )

            # 1. Register old dirs in .obsolete — they are left on disk so the
            #    running editor keeps them loaded until the user reloads.
            #    VS Code's cleanUp() removes them on the next full startup.
            _register_obsolete_dirs(root, all_prefixes, exclude=target_dir)

            # 2. Extract new versioned dir fresh.
            _extract_vsix_to_dir(vsix, target_dir)

            # 3. Bust extensions.json so VS Code rescans on next reload.
            cache_file = root / "extensions.json"
            if cache_file.exists():
                cache_file.unlink()

            installed_paths.append(str(root.parent.name))
        except Exception as exc:
            install_error = str(exc)

    is_new_install = bool(installed_paths)

    if installed_paths or skipped_paths:
        parts: list[str] = []
        if installed_paths:
            parts.append(f"Installed to: {', '.join(installed_paths)}")
        if skipped_paths:
            parts.append(f"already v{version} in: {', '.join(skipped_paths)}")
        return True, "; ".join(parts), is_new_install

    return False, install_error or "Unable to install to any extensions directory", False

def _sync_vscode_extension() -> tuple[bool, str]:
    if os.environ.get("CIST_SKIP_VSCODE_INSTALL") == "1":
        return False, "[dim]Extension install skipped (CIST_SKIP_VSCODE_INSTALL=1)[/dim]"

    vsix = _latest_bundled_vsix()
    
    if vsix is None:
        return False, "[yellow]![/yellow] Bundled extension not found in cist_cli/assets"

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
        disable=not sys.stdout.isatty(),
    ) as progress:
        progress.add_task(description="Getting you all set...", total=None)
        ok, install_output, is_new_install = _install_vscode_extension(vsix)

    if ok:
        if is_new_install:
            detail = f"[dim]{install_output}[/dim]  " if install_output else ""
            return True, (
                f"[green]✓[/green] Extension [bold]v{vsix.stem.split('-')[-1]}[/bold]  "
                f"{detail}"
                f"[yellow]reload to activate[/yellow]  "
                f"[dim]Ctrl+Shift+P → Reload Window[/dim]"
            )
        return True, (
            f"[green]✓[/green] Extension [bold]v{vsix.stem.split('-')[-1]}[/bold]  "
            f"[dim]already up to date[/dim]"
        )

    detail = f"[dim]{install_output}[/dim]" if install_output else ""
    return (
        False,
        f"[yellow]![/yellow] Extension install failed  {detail}"
    )

app = typer.Typer(
    name="cist",
    help="Contract Instruction Set",
    no_args_is_help=True,
)
console = Console()


def _resolve_cis_path(filepath: Path) -> Path:
    resolved = filepath.expanduser().resolve()
    if resolved.suffix.lower() != ".cis":
        console.print(f"[red]Error:[/red] Expected .cis file, got {resolved.suffix}")
        raise typer.Exit(1)
    return resolved


def _print_warnings(result: dict[str, Any]) -> None:
    warnings = result.get("warnings", [])
    for warning in warnings:
        console.print(
            f"[yellow]! Line {warning.line}:[/yellow] {warning.message}"
        )


@app.callback()
def callback() -> None:
    """CIST - Contract Instruction Set Toolkit."""


def _init_workspace(path: Path) -> None:
    paths = init_workspace(path)
    _, ext_line = _sync_vscode_extension()

    console.print()
    console.print(Rule(f" [bold]cist[/bold] [dim]v{__version__}[/dim] ", style="bright_black", align="center"))
    console.print()

    rows = [
        ("workspace", str(paths["root"])),
        ("contracts", str(paths["contracts_dir"])),
        ("contract",  str(paths["contract_file"])),
        ("bench",     str(paths["bench_dir"])),
        ("config",    str(paths["toml_file"])),
        ("env",       str(paths["env_file"])),
    ]
    for label, value in rows:
        console.print(f"  [dim]{label:<12}[/dim][cyan]{value}[/cyan]")

    console.print()
    console.print(f"  {ext_line}")
    console.print()

    console.print(Rule(" [dim]next steps[/dim] ", style="bright_black", align="center"))
    console.print()
    console.print(f"  [dim]1[/dim]  add api key to [bold].env[/bold]")
    console.print(f"  [dim]2[/dim]  open [bold]{paths['contract_file'].name}[/bold] and start writing")
    console.print(f"  [dim]3[/dim]  [bold]cist compile {paths['contract_file'].name}[/bold]")
    console.print()


@app.command()
def init(
    path: Path = typer.Option(
        Path("."),
        "--path",
        "-p",
        file_okay=False,
        help="Target directory",
    ),
) -> None:
    """Initialize a CIST workspace."""
    _init_workspace(path=path)


@app.command("sync-vscode-extension")
def sync_vscode_extension() -> None:
    """Install or update the bundled VS Code extension."""
    ok, message = _sync_vscode_extension()
    console.print(message)
    if not ok:
        raise typer.Exit(1)


@app.command()
def check(
    filepath: Path = typer.Argument(
        ...,
        exists=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help="Path to .cis file",
    ),
    json_out: bool = typer.Option(
        False,
        "--json",
        help="Write diagnostics as JSON to stdout (used by the VS Code extension).",
    ),
) -> None:
    """Validate a .cis file and report all syntax diagnostics."""
    resolved = _resolve_cis_path(filepath)
    compiler = CISTCompiler()
    result = compiler.check_file(resolved)

    if json_out:
        # Write directly to stdout, bypassing Rich entirely so no ANSI escape
        # codes or markup can contaminate the JSON that the VS Code extension parses.
        sys.stdout.write(json.dumps(result, default=str) + "\n")
        sys.stdout.flush()
        if not result["ok"]:
            raise typer.Exit(1)
        return

    # ── rich terminal output ──────────────────────────────────────────────────
    for issue in result.get("errors", []):
        console.print(f"[red]✗ Line {issue['line']}:[/red] {issue['message']}")
    for issue in result.get("warnings", []):
        console.print(f"[yellow]! Line {issue['line']}:[/yellow] {issue['message']}")

    if result["ok"]:
        ir = result.get("ir") or {}
        modules_str = ", ".join(ir.get("modules", [])) or "none"
        console.print(
            f"[green]✓[/green] [bold]{resolved.name}[/bold]  "
            f"[dim]{ir.get('line_count', 0)} lines · modules: {modules_str}[/dim]"
        )
    else:
        raise typer.Exit(1)


@app.command()
def build(
    filepath: Path = typer.Argument(
        ...,
        exists=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help="Path to .cis file",
    ),
    debug: bool = typer.Option(
        False,
        "--debug",
        help="Write the .mex as human-readable JSON (overrides cist.toml debug setting).",
    ),
) -> None:
    """Validate and build the local .mex file (no cloud upload).

    Debug mode is read from cist.toml [compiler] debug = true in the workspace.
    Pass --debug to override on the command line.
    """
    resolved = _resolve_cis_path(filepath)
    compiler = CISTCompiler()

    # Resolve debug flag: CLI --debug overrides, else read from cist.toml
    effective_debug = debug or _read_toml_debug(resolved)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
        disable=not sys.stdout.isatty(),
    ) as progress:
        progress.add_task(description="Checking syntax...", total=None)
        try:
            ast = compiler.compile_file(resolved)
        except ValidationError as exc:
            console.print(f"[red]Syntax error:[/red] {exc}")
            raise typer.Exit(1) from exc

    _print_warnings(ast)
    modules_str = ", ".join(ast["modules"]) or "none"
    console.print(
        f"[green]✓[/green] [bold]{resolved.name}[/bold]  "
        f"[dim]{ast['line_count']} lines · modules: {modules_str} · "
        f"{ast['data_streams']} data stream(s)[/dim]"
    )

    mex_path = resolved.parent / "program.mex"
    try:
        MexWriter().write(ast, mex_path, debug=effective_debug)
        if effective_debug:
            console.print(f"[green]✓[/green] Debug JSON written → [cyan]{mex_path}[/cyan]")
        else:
            console.print(f"[green]✓[/green] Binary written → [cyan]{mex_path}[/cyan]")
    except OSError as exc:
        console.print(f"[yellow]![/yellow] Could not write .mex file: {exc}")
        raise typer.Exit(1) from exc


def _read_toml_debug(cis_path: Path) -> bool:
    """Walk up from *cis_path* to find cist.toml and return [compiler] debug value."""
    for parent in [cis_path.parent, *cis_path.parents]:
        toml_path = parent / "cist.toml"
        if toml_path.exists():
            try:
                content = toml_path.read_text(encoding="utf-8")
                in_compiler = False
                for line in content.splitlines():
                    stripped = line.strip()
                    if stripped == "[compiler]":
                        in_compiler = True
                        continue
                    if stripped.startswith("[") and stripped.endswith("]"):
                        in_compiler = False
                    if in_compiler and stripped.startswith("debug"):
                        # e.g.  debug = true
                        _, _, val = stripped.partition("=")
                        return val.strip().lower() == "true"
            except OSError:
                pass
        if parent == parent.parent:
            break
    return False


@app.command()
def compile(
    filepath: Path = typer.Argument(
        ...,
        exists=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help="Path to .cis file",
    ),
    deploy: bool = typer.Option(
        False,
        "--deploy",
        "-d",
        help="Deploy to live execution",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose output"),
    debug: bool = typer.Option(
        False,
        "--debug",
        help="Write the .mex file as human-readable JSON (debug mode) instead of binary.",
    ),
) -> None:
    """Compile locally, then stream the CIST source to the cloud compiler."""
    resolved = _resolve_cis_path(filepath)
    compiler = CISTCompiler()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task(description="Checking syntax...", total=None)
        try:
            ast = compiler.compile_file(resolved)
        except ValidationError as exc:
            console.print(f"[red]Syntax error:[/red] {exc}")
            raise typer.Exit(1) from exc

    _print_warnings(ast)
    modules_str = ", ".join(ast["modules"]) or "none"
    console.print(
        f"[green]✓[/green] [bold]{resolved.name}[/bold]  "
        f"[dim]{ast['line_count']} lines · modules: {modules_str} · "
        f"{ast['data_streams']} data stream(s)[/dim]"
    )
    if verbose:
        console.print(f"[dim]  modules  : {ast['modules']}[/dim]")
        console.print(f"[dim]  streams  : {ast['data_streams']}[/dim]")

    # ── emit .mex file ────────────────────────────────────────────────────────
    mex_path = resolved.parent / "program.mex"
    try:
        MexWriter().write(ast, mex_path, debug=debug)
        if debug:
            console.print(f"[green]✓[/green] Debug JSON written → [cyan]{mex_path}[/cyan]")
        else:
            console.print(f"[green]✓[/green] Binary written → [cyan]{mex_path}[/cyan]")
    except OSError as exc:
        console.print(f"[yellow]![/yellow] Could not write .mex file: {exc}")

    console.print("[cyan]Connecting to CIST Cloud...[/cyan]")
    try:
        courier = CloudCourier()
        for event in courier.stream_compile(ast, deploy=deploy):
            event_type = event.get("type")
            if event_type == "log":
                console.print(f"[dim][Cloud][/dim] {event.get('message', '')}")
            elif event_type == "artifact":
                console.print(
                    f"[bold green]ok Compiled:[/bold green] {event.get('artifact_id', 'unknown')}"
                )
            elif event_type == "error":
                console.print(
                    f"[bold red]x Build Error:[/bold red] {event.get('message', '')}"
                )
                raise typer.Exit(1)
            elif event_type == "complete":
                console.print("[green]Compilation complete[/green]")
    except ValueError as exc:
        console.print(f"[bold red]Configuration Error:[/bold red] {exc}")
        raise typer.Exit(1) from exc
    except ConnectionError as exc:
        console.print(f"[bold red]Connection Failed:[/bold red] {exc}")
        raise typer.Exit(1) from exc


if __name__ == "__main__":
    app()