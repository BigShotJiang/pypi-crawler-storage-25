<script lang="ts">
	import { onMount } from 'svelte';
	import {
		fetchFlowBuilderOptions,
		seedFlow,
		validateFlow,
		saveFlow
	} from '$lib/api/flow';
	import { saveProviderKey } from '$lib/api/providers';
	import { ApiError } from '$lib/api/client';
	import { page } from '$app/state';
	import { toast } from '$lib/stores/toast.svelte';
	import { setCrumbs } from '$lib/stores/breadcrumb.svelte';

	$effect(() => { setCrumbs([{ label: 'Flows', href: '/flows' }, { label: 'New Flow' }]); });
	import { Skeleton } from '$lib/components/ui/skeleton';
	import LoadError from '$lib/components/ui/LoadError.svelte';
	import AgentPicker from '$lib/components/ui/AgentPicker.svelte';
	import ModelSelector from '$lib/components/ui/ModelSelector.svelte';
	import type {
		FlowBuilderOptions,
		PatternInfo,
		SlotAssignment,
		ValidationIssue
	} from '$lib/api/types';
	import {
		ArrowLeft,
		ArrowRight,
		Loader2,
		CircleX,
		TriangleAlert,
		CheckCircle,
		Minus,
		Plus,
		ChevronDown,
		ChevronRight,
		Copy,
		Check,
		Info
	} from 'lucide-svelte';

	// -- State ----------------------------------------------------------------

	type Step = 'configure' | 'editor' | 'success';

	let step: Step = $state('configure');
	let options = $state<FlowBuilderOptions | null>(null);
	let optionsLoading = $state(true);
	let optionsError: string | null = $state(null);

	// Configure
	let selectedPattern = $state<PatternInfo | null>(null);
	let agentCount = $state(3);
	let slots = $state<{ name: string; agentId: string | null }[]>([]);
	let sharedMemory = $state(false);
	let routingStrategy = $state<'all' | 'keyword' | 'sense'>('all');
	let routingDetailOpen = $state(false);
	let selectedProvider = $state('');
	let selectedModel = $state('');
	let customModelName = $state('');
	let customBaseUrl = $state('');
	let apiKey = $state('');
	let projectName = $state('');
	let generating = $state(false);
	let generateError: string | null = $state(null);

	// Editor
	let flowYaml = $state('');
	let roleYamls = $state<Record<string, string>>({});
	let issues = $state<ValidationIssue[]>([]);
	let isReady = $state(false);
	let saving = $state(false);
	let saveError: string | null = $state(null);
	let selectedDir = $state('');
	let showRoles = $state(false);

	// Validation debounce
	let validateTimer: ReturnType<typeof setTimeout> | undefined;

	// Success
	let savePath = $state('');
	let nextSteps = $state<string[]>([]);
	let flowId = $state('');
	let copied = $state(false);

	// -- Derived --------------------------------------------------------------

	const canGenerate = $derived(selectedPattern !== null && projectName.trim().length > 0);
	const isRoutePattern = $derived(selectedPattern?.name === 'route');

	// Quality indicators for route specialist slots
	function slotQuality(slot: { name: string; agentId: string | null }): 'good' | 'ok' | 'needs-tags' {
		if (!slot.agentId || !options) return 'needs-tags';
		const agent = options.agents.find((a) => a.id === slot.agentId);
		if (!agent) return 'needs-tags';
		if (agent.tags.length > 0 && agent.description) return 'good';
		if (agent.description || agent.tags.length > 0) return 'ok';
		return 'needs-tags';
	}

	const customPresetNames = $derived(
		new Set((options?.custom_presets ?? []).map((p) => p.name))
	);
	const isCustomEndpoint = $derived(customPresetNames.has(selectedProvider));
	const activePreset = $derived(
		(options?.custom_presets ?? []).find((p) => p.name === selectedProvider) ?? null
	);

	// -- Slot management ------------------------------------------------------

	const ROUTE_SPECIALISTS = [
		'researcher', 'responder', 'escalator', 'analyst',
		'summarizer', 'validator', 'coordinator', 'reviewer'
	];

	function updateSlots() {
		if (!selectedPattern) return;
		let names: string[];
		if (selectedPattern.fixed_topology) {
			names = [...selectedPattern.slot_names];
		} else if (selectedPattern.name === 'chain') {
			names = Array.from({ length: agentCount }, (_, i) => `step-${i + 1}`);
		} else if (selectedPattern.name === 'route') {
			const specialistCount = agentCount - 1;
			names = ['intake', ...ROUTE_SPECIALISTS.slice(0, specialistCount)];
		} else {
			// fan-out
			const workers = agentCount - 1;
			names = ['dispatcher', ...Array.from({ length: workers }, (_, i) => `worker-${i + 1}`)];
		}
		// Preserve existing assignments
		const existing = new Map(slots.map((s) => [s.name, s.agentId]));
		slots = names.map((n) => ({ name: n, agentId: existing.get(n) ?? null }));
	}

	function selectPattern(p: PatternInfo) {
		selectedPattern = p;
		agentCount = p.fixed_topology ? p.min_agents : 3;
		if (p.name === 'route') {
			routingStrategy = 'sense';
			routingDetailOpen = true;
		} else {
			routingStrategy = 'all';
			routingDetailOpen = false;
		}
		updateSlots();
	}

	function adjustCount(delta: number) {
		if (!selectedPattern || selectedPattern.fixed_topology) return;
		const next = agentCount + delta;
		if (next < selectedPattern.min_agents) return;
		if (selectedPattern.max_agents && next > selectedPattern.max_agents) return;
		agentCount = next;
		updateSlots();
	}

	// -- Actions --------------------------------------------------------------

	async function generate() {
		if (!options || !selectedPattern) return;
		generating = true;
		generateError = null;
		try {
			let resolvedApiKeyEnv: string | undefined;
			if (apiKey.trim() && isCustomEndpoint) {
				const keyResult = await saveProviderKey({
					preset: activePreset?.name !== 'custom' ? activePreset?.name : undefined,
					base_url: selectedProvider === 'custom' ? customBaseUrl : undefined,
					api_key: apiKey.trim()
				});
				resolvedApiKeyEnv = keyResult.env_var;
			} else if (isCustomEndpoint && activePreset?.key_configured) {
				resolvedApiKeyEnv = activePreset.api_key_env;
			}

			const services: SlotAssignment[] = slots.map((s) => ({
				slot: s.name,
				agent_id: s.agentId
			}));
			const result = await seedFlow({
				pattern: selectedPattern.name,
				name: projectName.trim(),
				agents: services,
				agent_count: agentCount,
				shared_memory: sharedMemory,
				provider: selectedProvider || 'openai',
				model: (isCustomEndpoint ? customModelName.trim() : selectedModel) || null,
				base_url: customBaseUrl || null,
				api_key_env: resolvedApiKeyEnv,
				routing_strategy: selectedPattern.name === 'route' ? routingStrategy : null
			});
			flowYaml = result.flow_yaml;
			roleYamls = result.role_yamls;
			issues = result.issues;
			isReady = result.ready;
			step = 'editor';
		} catch (err) {
			generateError = err instanceof ApiError ? err.detail : String(err);
		} finally {
			generating = false;
		}
	}

	function onYamlInput() {
		clearTimeout(validateTimer);
		validateTimer = setTimeout(async () => {
			try {
				const result = await validateFlow(flowYaml);
				issues = result.issues;
				isReady = result.ready;
			} catch {
				// ignore
			}
		}, 500);
	}

	async function save() {
		if (!options) return;
		saving = true;
		saveError = null;
		try {
			const result = await saveFlow({
				flow_yaml: flowYaml,
				role_yamls: roleYamls,
				directory: selectedDir,
				project_name: projectName.trim()
			});
			savePath = result.path;
			nextSteps = result.next_steps;
			flowId = result.flow_id;
			step = 'success';
		} catch (err) {
			if (err instanceof ApiError && err.status === 409) {
				saveError = 'Directory already exists. Change the project name or enable force overwrite.';
			} else {
				saveError = err instanceof ApiError ? err.detail : String(err);
			}
		} finally {
			saving = false;
		}
	}

	function createAnother() {
		step = 'configure';
		selectedPattern = null;
		agentCount = 3;
		slots = [];
		sharedMemory = false;
		customModelName = '';
		customBaseUrl = '';
		apiKey = '';
		projectName = '';
		flowYaml = '';
		roleYamls = {};
		issues = [];
		isReady = false;
		generateError = null;
		saveError = null;
	}

	async function copyPath() {
		await navigator.clipboard.writeText(savePath);
		copied = true;
		setTimeout(() => (copied = false), 2000);
	}

	// -- Init -----------------------------------------------------------------

	onMount(async () => {
		try {
			options = await fetchFlowBuilderOptions();
			if (options.detected_provider) selectedProvider = options.detected_provider;
			if (options.detected_model) selectedModel = options.detected_model;
			if (options.save_dirs.length > 0) selectedDir = options.save_dirs[0];

			// Handle ?starter= URL param
			const starterSlug = page.url.searchParams.get('starter');
			if (starterSlug && options.detected_provider) {
				generating = true;
				try {
					const result = await seedFlow({
						mode: 'starter',
						starter_slug: starterSlug,
						name: starterSlug,
						provider: options.detected_provider,
						model: options.detected_model ?? undefined
					});
					flowYaml = result.flow_yaml;
					roleYamls = result.role_yamls;
					issues = result.issues;
					isReady = result.ready;
					projectName = starterSlug;
					step = 'editor';
				} catch {
					toast.error(`Failed to load starter: ${starterSlug}`);
				} finally {
					generating = false;
				}
			}
		} catch {
			optionsError = 'Could not load builder options.';
			toast.error('Failed to load builder options');
		} finally {
			optionsLoading = false;
		}
	});
</script>

<div class="space-y-5">
	<!-- Back link -->
	<a href="/flows" class="inline-flex items-center gap-1 text-[12px] text-fg-faint transition-[color] duration-150 hover:text-fg-muted">
		<ArrowLeft size={12} />
		Flows
	</a>

	<!-- Step indicator -->
	<div class="flex items-center gap-2 text-[12px] font-mono text-fg-faint">
		<span class:text-accent-primary={step === 'configure'} class:font-medium={step === 'configure'}>Configure</span>
		<span class="text-fg-faint/40">></span>
		<span class:text-accent-primary={step === 'editor'} class:font-medium={step === 'editor'}>Editor</span>
		<span class="text-fg-faint/40">></span>
		<span class:text-accent-primary={step === 'success'} class:font-medium={step === 'success'}>Saved</span>
	</div>

	{#if optionsLoading}
		<Skeleton class="h-64 bg-surface-1" />

	{:else if optionsError}
		<LoadError message={optionsError} onRetry={() => location.reload()} />

	{:else if step === 'configure'}
		<!-- STEP 1: CONFIGURE -->
		<div class="space-y-5">
			<h2 class="text-2xl font-semibold tracking-[-0.03em] text-fg">New Flow</h2>

			<!-- Project name -->
			<div>
				<label for="project-name" class="mb-1 block text-[12px] font-medium text-fg-muted">Project name</label>
				<input
					id="project-name"
					bind:value={projectName}
					placeholder="my-pipeline"
					class="w-full max-w-sm border border-edge bg-surface-1 px-3 py-2 font-mono text-[13px] text-fg outline-none transition-[border-color,box-shadow] duration-150 placeholder:text-fg-faint focus:border-accent-primary/40 focus:shadow-[0_0_0_3px_oklch(0.91_0.20_128/0.08)]"
				/>
			</div>

			<!-- Pattern picker -->
			<div>
				<span class="mb-2 block text-[12px] font-medium text-fg-muted">Pattern</span>
				<div class="grid grid-cols-1 gap-2 md:grid-cols-3">
					{#if options}
						{#each options.patterns as pattern}
							<button
								class="border p-4 text-left transition-[border-color,background-color] duration-150 {selectedPattern?.name === pattern.name ? 'border-accent-primary/40 bg-accent-primary/[0.06]' : 'border-edge bg-surface-1 hover:border-accent-primary/20'}"
								onclick={() => selectPattern(pattern)}
							>
								<div class="flex items-center justify-between">
									<span class="font-mono text-[13px] font-medium text-fg">{pattern.name}</span>
									{#if pattern.name === 'route'}
										<span class="rounded-full border border-accent-primary/30 bg-accent-primary/10 px-1.5 py-0.5 font-mono text-[10px] text-accent-primary">sense</span>
									{:else if pattern.fixed_topology}
										<span class="rounded-full border border-edge bg-surface-2 px-1.5 py-0.5 font-mono text-[10px] text-fg-faint">fixed</span>
									{/if}
								</div>
								<p class="mt-1 text-[12px] text-fg-faint">{pattern.description}</p>
								<p class="mt-1 font-mono text-[11px] text-fg-faint/60">
									{#if pattern.fixed_topology}
										{pattern.slot_names.length} agents
									{:else}
										{pattern.min_agents}+ agents
									{/if}
								</p>
							</button>
						{/each}
					{/if}
				</div>
			</div>

			<!-- Slot picker -->
			{#if selectedPattern}
				<div>
					<div class="mb-2 flex items-center justify-between">
						<span class="text-[12px] font-medium text-fg-muted">Agents</span>
						{#if !selectedPattern.fixed_topology}
							<div class="flex items-center gap-1.5">
								<button
									class="rounded-full border border-edge bg-surface-1 p-1 text-fg-faint transition-[color,background-color] duration-150 hover:bg-surface-2 hover:text-fg-muted disabled:opacity-30"
									onclick={() => adjustCount(-1)}
									disabled={agentCount <= selectedPattern.min_agents}
								>
									<Minus size={12} />
								</button>
								<span class="font-mono text-[12px] text-fg-muted">{agentCount}</span>
								<button
									class="rounded-full border border-edge bg-surface-1 p-1 text-fg-faint transition-[color,background-color] duration-150 hover:bg-surface-2 hover:text-fg-muted disabled:opacity-30"
									onclick={() => adjustCount(1)}
									disabled={selectedPattern.max_agents !== null && agentCount >= selectedPattern.max_agents}
								>
									<Plus size={12} />
								</button>
							</div>
						{/if}
					</div>

					<!-- Slot flow diagram -->
					<div class="space-y-1.5">
						{#each slots as slot, idx}
							<div class="flex items-center gap-2">
								{#if idx > 0}
									<div class="ml-4 -mt-1.5 -mb-0.5 h-3 w-px bg-fg-faint/20"></div>
								{/if}
							</div>
							<div class="flex items-center gap-2">
								<span class="w-24 shrink-0 text-right font-mono text-[12px] text-fg-faint">{slot.name}</span>
								<ArrowRight size={12} class="shrink-0 text-fg-faint/40" />
								{#if options}
									<div class="flex-1">
										<AgentPicker
											agents={options.agents}
											selected={slot.agentId}
											onSelect={(agent) => { slots[idx].agentId = agent?.id ?? null; }}
											placeholder="Generate placeholder"
										/>
									</div>
								{/if}
							</div>
						{/each}
					</div>
				</div>

				<!-- Routing strategy (route pattern only) -->
				{#if isRoutePattern}
					<div class="space-y-3 border-t border-edge pt-4">
						<span class="block section-label">Routing strategy</span>
						<div class="flex gap-1">
							{#each [
								{ value: 'all', label: 'Broadcast', tip: 'Fastest. No intelligence.' },
								{ value: 'keyword', label: 'Keyword', tip: 'Near-zero cost. Shines with good tags.' },
								{ value: 'sense', label: 'Sense', tip: 'Highest accuracy. LLM only on ties.' }
							] as strat}
								<button
									class="relative px-3 py-1.5 font-mono text-[12px] transition-[color,background-color,border-color] duration-150 border
										{routingStrategy === strat.value
											? 'border-accent-primary/30 bg-accent-primary/10 text-accent-primary'
											: 'border-edge bg-surface-1 text-fg-faint hover:text-fg-muted hover:bg-surface-2'}"
									title={strat.tip}
									onclick={() => {
										routingStrategy = strat.value as typeof routingStrategy;
										routingDetailOpen = routingStrategy !== 'all';
									}}
								>
									{strat.label}
									{#if strat.value === 'sense'}
										<span class="ml-1 rounded-full bg-accent-primary/20 px-1 py-0.5 text-[9px] text-accent-primary">Recommended</span>
									{/if}
								</button>
							{/each}
						</div>

						<!-- Collapse-reveal scoring detail -->
						{#if routingStrategy !== 'all'}
							<button
								class="flex items-center gap-1 font-mono text-[11px] text-fg-faint transition-[color] duration-150 hover:text-fg-muted"
								onclick={() => (routingDetailOpen = !routingDetailOpen)}
							>
								{#if routingDetailOpen}
									<ChevronDown size={11} />
								{:else}
									<ChevronRight size={11} />
								{/if}
								Scoring detail
							</button>

							{#if routingDetailOpen}
								<div class="space-y-3 pl-0.5">
									<!-- Scoring weights -->
									<div class="space-y-1">
										<span class="font-mono text-[10px] font-medium uppercase tracking-[0.08em] text-fg-faint/60">How scoring works</span>
										{#each [
											{ label: 'tags', weight: 3, pct: 100 },
											{ label: 'name', weight: 2, pct: 67 },
											{ label: 'description', weight: 1.5, pct: 50 }
										] as w}
											<div class="flex items-center gap-2">
												<span class="w-20 text-right font-mono text-[11px] text-fg-faint">{w.label}</span>
												<div class="h-1.5 w-24 bg-surface-2">
													<div class="h-full bg-accent-primary/40" style="width: {w.pct}%"></div>
												</div>
												<span class="font-mono text-[10px] text-fg-faint/60">{w.weight}x</span>
											</div>
										{/each}
									</div>

									<!-- Target quality indicators -->
									<div class="space-y-1">
										<span class="font-mono text-[10px] font-medium uppercase tracking-[0.08em] text-fg-faint/60">Target quality</span>
										{#each slots.filter((_, i) => i > 0) as slot}
											{@const q = slotQuality(slot)}
											<div class="flex items-center gap-2">
												<span class="w-20 text-right font-mono text-[11px] text-fg-faint">{slot.name}</span>
												<div class="h-1.5 w-24 bg-surface-2">
													<div class="h-full {q === 'good' ? 'bg-status-ok' : q === 'ok' ? 'bg-status-warn' : 'bg-fg-faint/20'}"
														style="width: {q === 'good' ? '100' : q === 'ok' ? '60' : '10'}%"></div>
												</div>
												<span class="font-mono text-[10px] {q === 'good' ? 'text-status-ok' : q === 'ok' ? 'text-status-warn' : 'text-fg-faint'}">{q === 'needs-tags' ? 'needs tags' : q}</span>
											</div>
										{/each}
									</div>

									<div class="flex items-start gap-2 border-l-2 border-l-info pl-2.5 py-1">
										<Info size={11} class="mt-0.5 shrink-0 text-info" />
										<span class="font-mono text-[11px] text-fg-faint/70">Well-tagged roles route more accurately. Customize generated role files after saving.</span>
									</div>
								</div>
							{/if}
						{/if}
					</div>
				{/if}

				<!-- Options -->
				<div class="flex flex-wrap items-center gap-4 border-t border-edge pt-4">
					<label class="flex items-center gap-2 text-[12px] text-fg-muted">
						<input type="checkbox" bind:checked={sharedMemory} class="accent-accent-primary" />
						Shared memory
					</label>
				</div>

				{#if options}
					<ModelSelector
						providers={options.providers}
						customPresets={options.custom_presets}
						ollamaModels={options.ollama_models}
						ollamaBaseUrl={options.ollama_base_url}
						bind:selectedProvider
						bind:selectedModel
						bind:customModelName
						bind:customBaseUrl
						bind:apiKey
						compact={true}
					/>
				{/if}

				<!-- Generate button -->
				<div class="flex items-center gap-3">
					<button
						class="flex items-center gap-1.5 rounded-[2px] border border-accent-primary/30 bg-accent-primary/10 px-4 py-2 font-mono text-[13px] text-accent-primary transition-[background-color] duration-150 hover:bg-accent-primary/20 disabled:opacity-40 disabled:cursor-not-allowed"
						onclick={generate}
						disabled={!canGenerate || generating}
					>
						{#if generating}
							<Loader2 size={14} class="animate-spin" />
							Generating...
						{:else}
							Generate
						{/if}
					</button>
					{#if generateError}
						<span class="text-[12px] text-status-fail">{generateError}</span>
					{/if}
				</div>
			{/if}
		</div>

	{:else if step === 'editor'}
		<!-- STEP 2: EDITOR -->
		<div class="space-y-4">
			<h2 class="text-2xl font-semibold tracking-[-0.03em] text-fg">flow.yaml</h2>

			<!-- YAML editor -->
			<textarea
				class="h-80 w-full border border-edge bg-surface-1 p-3 font-mono text-[12px] text-fg outline-none transition-[border-color] duration-150 focus:border-accent-primary/40"
				bind:value={flowYaml}
				oninput={onYamlInput}
				spellcheck="false"
			></textarea>

			<!-- Validation issues -->
			{#if issues.length > 0}
				<div class="space-y-1">
					{#each issues as issue}
						<div class="flex items-start gap-2 text-[12px]">
							{#if issue.severity === 'error'}
								<CircleX size={13} class="mt-0.5 shrink-0 text-status-fail" />
							{:else}
								<TriangleAlert size={13} class="mt-0.5 shrink-0 text-status-warn" />
							{/if}
							<span class="text-fg-faint"><span class="font-mono text-fg-muted">{issue.field}</span>: {issue.message}</span>
						</div>
					{/each}
				</div>
			{:else if isReady}
				<div class="flex items-center gap-1.5 text-[12px] text-status-ok">
					<CheckCircle size={13} />
					Valid
				</div>
			{/if}

			<!-- Generated roles (collapsible) -->
			{#if Object.keys(roleYamls).length > 0}
				<button
					class="flex items-center gap-1.5 text-[12px] text-fg-faint transition-[color] duration-150 hover:text-fg-muted"
					onclick={() => (showRoles = !showRoles)}
				>
					<ChevronDown size={12} class="transition-transform duration-150 {showRoles ? 'rotate-0' : '-rotate-90'}" />
					Generated roles ({Object.keys(roleYamls).length})
				</button>
				{#if showRoles}
					<div class="space-y-2 border-l-2 border-edge pl-3">
						{#each Object.entries(roleYamls) as [filename, yaml]}
							<div>
								<p class="mb-1 font-mono text-[11px] text-fg-muted">roles/{filename}</p>
								<pre class="max-h-40 overflow-auto border border-edge bg-surface-2 p-2 font-mono text-[11px] text-fg-faint">{yaml}</pre>
							</div>
						{/each}
					</div>
				{/if}
			{/if}

			<!-- Save controls -->
			<div class="flex flex-wrap items-end gap-3 border-t border-edge pt-4">
				{#if options && options.save_dirs.length > 0}
					<div>
						<label for="save-dir" class="mb-1 block text-[12px] text-fg-faint">Directory</label>
						<select
							id="save-dir"
							bind:value={selectedDir}
							class="border border-edge bg-surface-1 px-2 py-1.5 font-mono text-[12px] text-fg outline-none"
						>
							{#each options.save_dirs as dir}
								<option value={dir}>{dir}</option>
							{/each}
						</select>
					</div>
				{/if}
				<button
					class="flex items-center gap-1.5 rounded-[2px] border border-accent-primary/30 bg-accent-primary/10 px-4 py-2 font-mono text-[13px] text-accent-primary transition-[background-color] duration-150 hover:bg-accent-primary/20 disabled:opacity-40 disabled:cursor-not-allowed"
					onclick={save}
					disabled={saving || !isReady}
				>
					{#if saving}
						<Loader2 size={14} class="animate-spin" />
						Saving...
					{:else}
						Save
					{/if}
				</button>
				{#if saveError}
					<span class="text-[12px] text-status-fail">{saveError}</span>
				{/if}
			</div>

			<!-- Back to configure -->
			<button
				class="text-[12px] text-fg-faint transition-[color] duration-150 hover:text-fg-muted"
				onclick={() => (step = 'configure')}
			>
				Back to configure
			</button>
		</div>

	{:else if step === 'success'}
		<!-- STEP 3: SUCCESS -->
		<div class="mx-auto max-w-lg space-y-5 py-8 text-center">
			<div class="mx-auto flex h-12 w-12 items-center justify-center rounded-full border border-status-ok/30 bg-status-ok/10">
				<CheckCircle size={24} class="text-status-ok" />
			</div>
			<h2 class="text-2xl font-semibold tracking-[-0.03em] text-fg">Flow saved</h2>

			<!-- Path -->
			<button
				class="mx-auto flex items-center gap-2 border border-edge bg-surface-1 px-3 py-1.5 font-mono text-[12px] text-fg-muted transition-[border-color] duration-150 hover:border-accent-primary/30"
				onclick={copyPath}
			>
				{savePath}
				{#if copied}
					<Check size={12} class="text-status-ok" />
				{:else}
					<Copy size={12} />
				{/if}
			</button>

			<!-- Next steps -->
			<div class="mx-auto max-w-sm text-left">
				<p class="mb-2 text-[12px] font-medium text-fg-muted">Next steps</p>
				<div class="space-y-1">
					{#each nextSteps as ns}
						<pre class="border border-edge bg-surface-1 px-3 py-1.5 font-mono text-[12px] text-fg-faint">{ns}</pre>
					{/each}
				</div>
			</div>

			<!-- Actions -->
			<div class="flex items-center justify-center gap-3">
				<a
					href="/flows/{flowId}"
					class="rounded-[2px] border border-accent-primary/30 bg-accent-primary/10 px-4 py-2 font-mono text-[12px] text-accent-primary transition-[background-color] duration-150 hover:bg-accent-primary/20"
				>
					View Flow
				</a>
				<button
					class="rounded-[2px] border border-edge bg-surface-1 px-4 py-2 font-mono text-[12px] text-fg-faint transition-[color,background-color] duration-150 hover:bg-surface-2 hover:text-fg-muted"
					onclick={createAnother}
				>
					Create Another
				</button>
			</div>
		</div>
	{/if}
</div>
