# Triggers — Configuration Reference

Triggers allow agents to run automatically in response to events — cron schedules, file changes, incoming webhooks, or messaging platforms. They are configured in the `spec.triggers` list and activated with the `initrunner run <role> --daemon` command.

Triggers follow the same discriminated-union pattern as tools and sinks, keyed on the `type` field.

## Trigger Types

| Type | Description |
|------|-------------|
| `cron` | Fire on a cron schedule |
| `file_watch` | Fire when files change in watched directories |
| `webhook` | Fire on incoming HTTP requests (localhost only) |
| `heartbeat` | Read a markdown checklist on a fixed interval |
| `telegram` | Respond to Telegram messages via long-polling (outbound only) |
| `discord` | Respond to Discord DMs and @mentions via WebSocket (outbound only) |

## Quick Example

```yaml
spec:
  triggers:
    - type: cron
      schedule: "0 9 * * 1"
      prompt: "Generate weekly status report."
    - type: file_watch
      paths: ["./watched"]
      extensions: [".md", ".txt"]
      prompt_template: "File changed: {path}. Summarize the changes."
    - type: webhook
      path: /webhook
      port: 8080
      secret: ${WEBHOOK_SECRET}
```

Run with:

```bash
initrunner run role.yaml --daemon
```

## Cron Trigger

Fires the agent on a cron schedule using [croniter](https://github.com/kiorky/croniter) syntax.

```yaml
triggers:
  - type: cron
    schedule: "0 9 * * 1"                    # required
    prompt: "Generate weekly status report."  # required
    timezone: UTC                             # default: UTC
```

### Options

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `schedule` | `str` | *(required)* | Cron expression. Standard 5-field syntax (`min hour day month weekday`). |
| `prompt` | `str` | *(required)* | The prompt sent to the agent when the trigger fires. |
| `timezone` | `str` | `"UTC"` | Timezone for schedule evaluation. |

### Schedule Syntax

Uses standard cron expressions:

| Field | Values |
|-------|--------|
| Minute | `0-59` |
| Hour | `0-23` |
| Day of month | `1-31` |
| Month | `1-12` |
| Day of week | `0-7` (0 and 7 are Sunday) |

Examples:
- `"0 9 * * 1"` — Every Monday at 9:00 AM
- `"*/5 * * * *"` — Every 5 minutes
- `"0 0 1 * *"` — First day of every month at midnight
- `"30 14 * * 1-5"` — Weekdays at 2:30 PM

### Behavior

- The trigger calculates the next fire time from the current UTC time.
- It sleeps in 1-second increments to allow clean shutdown on signal.
- When the fire time arrives, the configured `prompt` is sent to the agent.
- The trigger event includes `metadata: {"schedule": "..."}` with the cron expression.

## File Watch Trigger

Fires when files change in watched directories. Uses [watchfiles](https://watchfiles.helpmanual.io/) for efficient filesystem monitoring.

```yaml
triggers:
  - type: file_watch
    paths:                                              # required
      - "./watched"
      - "./data"
    extensions: [".md", ".txt"]                         # default: [] (all files)
    prompt_template: "File changed: {path}. Summarize." # default: "File changed: {path}"
    debounce_seconds: 1.0                               # default: 1.0
```

### Options

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `paths` | `list[str]` | *(required)* | Directories to watch for changes. |
| `extensions` | `list[str]` | `[]` | File extensions to filter on. Empty list watches all files. Include the dot (e.g. `".md"`). |
| `prompt_template` | `str` | `"File changed: {path}"` | Template for the prompt sent to the agent. `{path}` is replaced with the changed file's path. |
| `debounce_seconds` | `float` | `1.0` | Debounce interval in seconds. Multiple changes within this window are batched. |
| `process_existing` | `bool` | `false` | When `true`, fire once for each matching file already present in the watched directories on startup, before starting live monitoring. |

### Behavior

- Watches all specified `paths` simultaneously.
- When `extensions` is set, only files matching those extensions trigger events.
- Each changed file generates a separate trigger event with the rendered `prompt_template`.
- The `debounce_seconds` value is converted to milliseconds and passed to `watchfiles`.
- The trigger event includes `metadata: {"path": "..."}` with the changed file's absolute path.

### Startup Scan

When `process_existing: true`, the trigger scans each watched directory on startup before beginning live monitoring:

- One event is fired per existing file that matches the configured `extensions`.
- Files are processed in sorted order (alphabetical).
- After the initial scan completes, live monitoring begins normally.
- This is useful in flow pipelines where an agent should process both existing and new files -- for example, a content watcher that needs to handle drafts already present in a directory at startup.

### Template Variables

| Variable | Description |
|----------|-------------|
| `{path}` | Absolute path to the changed file |

## Webhook Trigger

Fires when an HTTP request is received on a local endpoint. Useful for integrating with GitHub webhooks, CI/CD systems, or other services that can send HTTP callbacks.

```yaml
triggers:
  - type: webhook
    path: /webhook          # default: "/webhook"
    port: 8080              # default: 8080
    method: POST            # default: "POST"
    secret: ${WEBHOOK_SECRET}  # default: null (no verification)
```

### Options

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `path` | `str` | `"/webhook"` | URL path to listen on. |
| `port` | `int` | `8080` | Port to listen on. |
| `method` | `str` | `"POST"` | HTTP method to accept. Other methods return 405. |
| `secret` | `str \| null` | `null` | HMAC secret for signature verification. When set, requests must include a valid `X-Hub-Signature-256` header. |

### HMAC Verification

When `secret` is set, the webhook validates incoming requests using GitHub-style HMAC-SHA256 signatures:

1. The server computes `sha256=HMAC(secret, request_body)`.
2. It compares this with the `X-Hub-Signature-256` header using constant-time comparison.
3. Requests with invalid or missing signatures receive a `403 Forbidden` response.

This is compatible with GitHub webhook signatures and any system that uses the same signing scheme.

### Behavior

- The webhook server binds to `127.0.0.1` only (localhost). It is not exposed to external networks.
- The request body (decoded as UTF-8) becomes the prompt sent to the agent.
- The server is run via uvicorn in a thread with `log_level: warning`.
- The trigger event includes `metadata: {"path": "..."}` with the configured path.
- On success, the webhook returns `{"status": "ok"}` with a 200 status code.

### Example: GitHub Webhook

```yaml
triggers:
  - type: webhook
    path: /github
    port: 9000
    secret: ${GITHUB_WEBHOOK_SECRET}
```

```bash
# Test locally
curl -X POST http://127.0.0.1:9000/github \
  -H "Content-Type: application/json" \
  -H "X-Hub-Signature-256: sha256=..." \
  -d '{"action": "opened", "pull_request": {"title": "Fix bug"}}'
```

## Heartbeat Trigger

Fires on a fixed interval, reading a markdown checklist file and prompting the agent with any unchecked items. Useful for batching multiple periodic tasks into a single trigger instead of separate cron entries.

```yaml
triggers:
  - type: heartbeat
    file: ./tasks.md                    # required
    interval_seconds: 3600              # default: 3600 (1 hour)
    autonomous: true                    # default: false
    active_hours: [9, 17]              # default: null (always active)
    timezone: America/New_York         # default: UTC
```

### Options

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `file` | `str` | *(required)* | Path to the markdown checklist file. |
| `interval_seconds` | `int` | `3600` | Seconds between heartbeat checks. Must be > 0. |
| `prompt_prefix` | `str` | `"You are processing a periodic task checklist..."` | Text prepended to the checklist content in the prompt. |
| `active_hours` | `list[int] \| null` | `null` | Two-element list `[start, end]` defining active hours (0-23). `null` means always active. |
| `timezone` | `str` | `"UTC"` | Timezone for `active_hours` evaluation. Must be a valid IANA timezone (e.g. `America/New_York`). |

### Active Hours

When `active_hours` is set, the trigger only fires during the specified window:

- **Normal window** (e.g. `[9, 17]`): fires when `start <= hour < end`
- **Midnight-spanning** (e.g. `[22, 6]`): fires when `hour >= start` or `hour < end`
- **Always active**: omit `active_hours` or set to `null`

### Behavior

- The first heartbeat fires after one full interval from daemon startup (not immediately).
- On each heartbeat, the file is read (capped at 64KB with `[truncated]` marker).
- Unchecked items (`- [ ]`) are counted. If there are zero open items, no event is fired.
- The prompt is composed as: `prompt_prefix + "\n\n" + file_content`.
- The trigger event includes `metadata: {"file": "...", "item_count": "...", "interval_seconds": "..."}`.

### Example Checklist

```markdown
# Daily Tasks

- [ ] Check deployment health
- [x] Review overnight alerts
- [ ] Update documentation
- [ ] Run integration tests
```

No new dependencies — uses stdlib `zoneinfo` (Python 3.9+).

## Channel Adapter Protocol

Telegram and Discord are implemented as **channel adapters** -- bidirectional adapters that handle both inbound (listening) and outbound (sending) in a single class. The `ChannelAdapter` ABC in `initrunner/triggers/base.py` defines the protocol:

```python
class ChannelAdapter(ABC):
    @property
    def platform(self) -> str: ...       # e.g. "telegram", "discord"
    def start(self, callback) -> None: ...  # block and listen for inbound
    def stop(self) -> None: ...             # signal shutdown
    def send(self, target, text) -> None: ...  # send to a route token
```

### Adding a New Channel

To add a new messaging platform (e.g. Slack, WhatsApp), implement `ChannelAdapter`:

1. Create `initrunner/triggers/myplatform.py` with a class implementing `ChannelAdapter`.
2. `start(callback)` must block and call `callback(TriggerEvent(...))` for each inbound message. Set `metadata["channel_target"]` to an opaque route token identifying the conversation.
3. `send(target, text)` sends a message to the given route token. Must be thread-safe and never raise.
4. Register a builder in `initrunner/triggers/dispatcher.py`:
   ```python
   @register_trigger_builder(MyPlatformTriggerConfig)
   def _build_myplatform(config, callback):
       from initrunner.triggers.myplatform import MyPlatformAdapter
       return ChannelTriggerBridge(MyPlatformAdapter(config), callback)
   ```
5. `ChannelTriggerBridge` handles threading and auto-registers the platform as conversational.

### Shared Metadata

Channel adapters set `channel_target` in trigger event metadata. This is used by:
- `TriggerEvent.conversation_key` for conversation history routing
- `ChannelSinkBridge` (in `initrunner/sinks/base.py`) for outbound sink delivery

The `channel_target` value is opaque to the framework -- adapters can encode chat IDs, thread IDs, DM channels, or any platform-specific route.

## Daemon Mode

The `initrunner run <role> --daemon` command starts all configured triggers and waits for events:

```bash
initrunner run role.yaml --daemon
initrunner run role.yaml --daemon --audit-db ./custom-audit.db
initrunner run role.yaml --daemon --no-audit
```

### CLI Options

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `role_file` | `Path` | *(required)* | Path to the role YAML file. |
| `--daemon` | `bool` | `false` | Run in daemon mode with triggers. |
| `--autopilot` | `bool` | `false` | Daemon mode with all triggers autonomous. |
| `--audit-db` | `Path` | `~/.initrunner/audit.db` | Path to audit database. |
| `--no-audit` | `bool` | `false` | Disable audit logging. |

### Lifecycle

1. The role is loaded and the agent is built.
2. All triggers are started in daemon threads via `TriggerDispatcher`.
3. When a trigger fires, the prompt is sent to the agent.
4. **All trigger types** (cron, file watch, webhook, Telegram, Discord, heartbeat) use the autonomous loop when `autonomous: true` is set on the trigger config. The `--autopilot` flag forces all triggers into autonomous mode regardless of per-trigger config.
5. For **messaging triggers** (Telegram, Discord), the final output of the autonomous run is sent back to the originating channel. For **other triggers**, the result is displayed and dispatched to sinks.
6. Triggers without `autonomous: true` (and not in `--autopilot` mode) use direct single-shot execution.
7. The daemon continues until interrupted.

### Hot-Reload

By default, the daemon watches the role YAML and referenced skill files for changes. When a change is detected, the role and agent are reloaded without restarting the daemon.

```yaml
spec:
  daemon:
    hot_reload: true                    # default: true
    reload_debounce_seconds: 1.0        # default: 1.0
```

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `hot_reload` | `bool` | `true` | Enable file-watching for role YAML and skill files. |
| `reload_debounce_seconds` | `float` | `1.0` | Debounce interval (0-30 seconds) for batching rapid writes. |

**Fail-open policy**: if the reloaded YAML is invalid, the daemon keeps the last known-good config and logs a warning.

**What is reloaded**: role YAML, skill files, model config, tools, triggers, autonomy config.

**What is NOT reloaded** (requires daemon restart): memory store, audit logger, `.env` files, sink dispatcher configuration.

**Thread safety**: in-flight trigger runs use a snapshot of the old agent/role. New runs after a reload use the updated config. Trigger dispatchers are restarted only if the trigger config actually changed.

Hot-reload requires a `role_path` -- it is automatically enabled when running `initrunner run role.yaml --daemon`. Ephemeral roles (e.g. from `initrunner run`) do not support hot-reload.

### Signal Handling

The daemon installs handlers for `SIGINT` (Ctrl+C) and `SIGTERM`:

1. The signal sets a stop event.
2. All triggers are stopped via `TriggerDispatcher.stop_all()`.
3. Trigger threads are joined with a 5-second timeout.
4. The process exits cleanly.

### Trigger Events

Every trigger fires a `TriggerEvent` containing:

| Field | Type | Description |
|-------|------|-------------|
| `trigger_type` | `str` | `"cron"`, `"file_watch"`, `"webhook"`, `"heartbeat"`, `"telegram"`, or `"discord"` |
| `prompt` | `str` | The prompt to send to the agent |
| `timestamp` | `str` | ISO 8601 timestamp of when the event was created |
| `metadata` | `dict[str, str]` | Type-specific metadata (schedule, path, user, etc.). Channel adapters always include `channel_target`. |
| `reply_fn` | `Callable \| None` | Optional callback to send the agent's response back to the originating channel |

## Dashboard Monitoring

The dashboard provides operational visibility for triggered agents. On the agent detail page (`/agents/{id}`), a **Trigger Panel** appears above the tabs for agents with configured triggers.

Each trigger displays:

| Field | Source | Description |
|-------|--------|-------------|
| Type + summary | Trigger config | e.g. `cron: 0 9 * * *` |
| Fire count | Audit trail | Total number of trigger-initiated runs |
| Success rate | Audit trail | Color-coded (green/yellow/red) |
| Avg duration | Audit trail | Mean execution time across all fires |
| Last fired | Audit trail | Relative time (e.g. "2m ago") |
| Next check | Computed | Cron: next schedule evaluation (UTC). Heartbeat: last fire + interval. |
| Last error | Audit trail | Most recent error from a failed trigger run (collapsed) |

Stats are derived from the audit trail. No additional runtime state is required. The Config tab preserves the static trigger configuration listing as a fallback.

**Timeline tab**: agents with triggers also get a **Timeline** tab showing a Gantt-style chart of runs over the last 24 hours. Bars are color-coded by outcome (green=success, red=error) and swim lanes are dynamically assigned when runs overlap in time. Hover tooltips show trigger type, duration, token count, and estimated cost. A stats strip above the chart summarizes total runs, success rate, token consumption, average duration, and total cost. The timeline auto-refreshes every 30 seconds and is powered by `GET /api/agents/{id}/timeline`, which queries the audit trail with lightweight column selection (no prompt/output payloads). Start times are derived from `timestamp - duration_ms` since the audit log records completion time.

**Limitation (v1)**: stats are aggregated per `trigger_type`. If an agent has two triggers of the same type (e.g. two cron schedules), their stats are combined. The timeline only shows completed runs -- currently executing runs are not visible until they finish.

## Telegram Trigger

Responds to Telegram messages using long-polling via [python-telegram-bot](https://python-telegram-bot.org/). Outbound HTTPS only — no ports opened, no inbound connections required.

### Setup

1. Create a bot with [@BotFather](https://t.me/BotFather) and copy the token.
2. Set the token as an environment variable: `export TELEGRAM_BOT_TOKEN=your-token`.
3. Install the optional dependency: `pip install initrunner[telegram]`.

```yaml
triggers:
  - type: telegram
    token_env: TELEGRAM_BOT_TOKEN      # default
    allowed_users: ["alice", "bob"]    # empty = allow all
    allowed_user_ids: [123456789]      # empty = allow all
    prompt_template: "{message}"       # default
```

### Options

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `token_env` | `str` | `"TELEGRAM_BOT_TOKEN"` | Environment variable holding the bot token. |
| `allowed_users` | `list[str]` | `[]` | Telegram usernames allowed to interact. Empty list allows all users. |
| `allowed_user_ids` | `list[int]` | `[]` | Telegram user IDs allowed to interact. Empty list allows all users. Prefer over `allowed_users` -- usernames are mutable, IDs are not. |
| `prompt_template` | `str` | `"{message}"` | Template for the prompt. `{message}` is replaced with the user's message text. |
| `autonomous` | `bool` | `false` | Use the autonomous loop for each message (multi-step research before replying). |

### Behavior

- Uses long-polling (outbound HTTPS) -- no ports opened, no webhooks to configure.
- Only text messages are processed (commands like `/start` are ignored).
- When `allowed_users` or `allowed_user_ids` is set, messages from unmatched users are silently dropped. Access is granted if the user matches **either** field (union semantics).
- The agent's response is sent back to the originating chat, automatically chunked to Telegram's 4096-character message limit.
- Chunks are split at newline boundaries when possible for cleaner output.
- The trigger event includes `metadata: {"channel_target": "...", "user": "...", "chat_id": "...", "user_id": "..."}`.

### Security

- **Store the bot token securely** -- use environment variables or a secrets manager, never commit it to version control.
- **Prefer `allowed_user_ids`** over `allowed_users` -- user IDs are immutable. Use `allowed_users` as a convenience alongside IDs.
- **Set `daemon_daily_token_budget`** in guardrails to prevent runaway costs.

## Discord Trigger

Responds to Discord DMs and @mentions via WebSocket client using [discord.py](https://discordpy.readthedocs.io/). Outbound only — no ports opened.

### Setup

1. Create a bot in the [Discord Developer Portal](https://discord.com/developers/applications).
2. Enable the **Message Content Intent** under Bot settings.
3. Invite the bot to your server with the `bot` scope and `Send Messages` + `Read Message History` permissions.
4. Set the token: `export DISCORD_BOT_TOKEN=your-token`.
5. Install the optional dependency: `pip install initrunner[discord]`.

```yaml
triggers:
  - type: discord
    token_env: DISCORD_BOT_TOKEN       # default
    channel_ids: ["123456789"]         # empty = all channels
    allowed_roles: ["Admin", "Bot-User"]  # empty = all roles
    allowed_user_ids: ["111222333444555666"]  # empty = allow all
    prompt_template: "{message}"       # default
```

### Options

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `token_env` | `str` | `"DISCORD_BOT_TOKEN"` | Environment variable holding the bot token. |
| `channel_ids` | `list[str]` | `[]` | Channel IDs to respond in. Empty list allows all channels. Only applies to guild channels — DMs are not affected. |
| `allowed_roles` | `list[str]` | `[]` | Role names required to interact. Empty list allows all users. DMs are denied when only roles are configured. |
| `allowed_user_ids` | `list[str]` | `[]` | Discord user IDs allowed to interact. Works in both guild channels and DMs. |
| `prompt_template` | `str` | `"{message}"` | Template for the prompt. `{message}` is replaced with the user's message text. |
| `autonomous` | `bool` | `false` | Use the autonomous loop for each message (multi-step research before replying). |

### Behavior

- Uses WebSocket client connection -- outbound only, no ports opened.
- Responds to **DMs** and **@mentions** only (not every message in every channel).
- When only `allowed_roles` is set, **DMs are denied** (DMs have no role context). When `allowed_user_ids` is also set, a user ID match grants DM access.
- `channel_ids` restricts guild channels only — DMs are not affected by the channel filter.
- When both `allowed_roles` and `allowed_user_ids` are set, access is granted if either matches (union semantics for guild messages; user ID only for DMs).
- Bot @mention is stripped from the message content using the mention ID pattern for robustness.
- The agent's response is sent back to the originating channel, automatically chunked to Discord's 2000-character message limit.
- The trigger event includes `metadata: {"channel_target": "...", "user": "...", "channel_id": "...", "user_id": "..."}`.

### Security

- **Store the bot token securely** -- never commit it to version control.
- **Use `allowed_user_ids`** for reliable per-user access control that works in both guild channels and DMs.
- **Use `channel_ids`** to restrict the bot to specific guild channels.
- **Use `allowed_roles`** to restrict access to specific server roles. Note that DMs are automatically denied when only roles are configured.
- **Set `daemon_daily_token_budget`** in guardrails to prevent runaway costs.
