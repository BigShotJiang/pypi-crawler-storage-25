"""Role YAML template generators."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

# Setup guidance for templates that require external prerequisites.
# Only populated for templates needing env vars, extras, or multi-step setup.
TEMPLATE_SETUP: dict[str, dict[str, Any]] = {
    "discord": {
        "steps": [
            "Create a Discord Application at discord.com/developers/applications",
            "Go to Bot tab > Reset Token > copy the token",
            "Enable Message Content Intent (Bot > Privileged Gateway Intents)",
            "OAuth2 tab: select 'bot' scope, enable Send Messages + Read Message History",
            "Copy the invite URL and add the bot to your server",
        ],
        "env_vars": ["DISCORD_BOT_TOKEN"],
        "extras": ["discord"],
        "docs_url": "https://www.initrunner.ai/docs/discord",
    },
    "telegram": {
        "steps": [
            "Open Telegram and search for @BotFather",
            "Send /newbot and follow the prompts to name your bot",
            "Copy the token BotFather gives you",
        ],
        "env_vars": ["TELEGRAM_BOT_TOKEN"],
        "extras": ["telegram"],
        "docs_url": "https://www.initrunner.ai/docs/telegram",
    },
    "email": {
        "steps": [
            "Get your IMAP/SMTP server details (Gmail: imap.gmail.com / smtp.gmail.com)",
            "For Gmail: enable 2FA, then create an App Password at myaccount.google.com",
            "For Outlook: use outlook.office365.com for both IMAP and SMTP",
            "Set the four email env vars (see below)",
            "(Optional) Create a Slack incoming webhook for urgent alerts",
        ],
        "env_vars": [
            "EMAIL_IMAP_HOST",
            "EMAIL_SMTP_HOST",
            "EMAIL_USER",
            "EMAIL_PASS",
        ],
        "extras": [],
        "docs_url": "",
    },
}

# Curated popular models per provider. First entry is the default.
# Keep this list up-to-date when providers release new models.
# Users can always type a custom model name not in this list.
PROVIDER_MODELS: dict[str, list[tuple[str, str]]] = {
    "openai": [
        ("gpt-5.4", "Frontier (best quality, higher cost)"),
        ("gpt-5-mini", "Balanced (good quality, lower cost)"),
        ("gpt-5-nano", "Lightweight (fastest, lowest cost)"),
        ("gpt-4.1", "Previous gen, reliable"),
        ("o4-mini", "Reasoning, fast"),
        ("o3", "Reasoning, frontier"),
    ],
    "anthropic": [
        ("claude-sonnet-4-6", "Balanced (fast, capable)"),
        ("claude-opus-4-6", "Frontier (best quality, higher cost)"),
        ("claude-haiku-4-5-20251001", "Lightweight (fastest, lowest cost)"),
    ],
    "google": [
        ("gemini-2.5-flash", "Balanced (fast multimodal)"),
        ("gemini-2.5-pro", "Frontier (best quality)"),
        ("gemini-2.5-flash-lite", "Lightweight (lowest cost)"),
    ],
    "groq": [
        ("llama-4-scout-17b-16e", "Llama 4 Scout, ultra-fast"),
        ("llama-3.3-70b-versatile", "Llama 70B, high quality"),
        ("llama-3.1-8b-instant", "Llama 8B, lowest latency"),
    ],
    "mistral": [
        ("mistral-large-latest", "Frontier (best quality)"),
        ("mistral-small-latest", "Balanced (fast, efficient)"),
        ("codestral-latest", "Code-optimized"),
        ("devstral-small-2505", "Agentic coding"),
    ],
    "cohere": [
        ("command-a", "Frontier (256K context)"),
        ("command-r-plus", "Advanced RAG"),
        ("command-r", "Balanced"),
    ],
    "bedrock": [
        ("us.anthropic.claude-sonnet-4-6-v1:0", "Claude Sonnet 4.6 (balanced)"),
        ("us.anthropic.claude-haiku-4-5-v1:0", "Claude Haiku 4.5 (lightweight)"),
        ("us.meta.llama4-scout-17b-instruct-v1:0", "Llama 4 Scout"),
    ],
    "xai": [
        ("grok-4", "Frontier (best quality)"),
        ("grok-4-fast", "Balanced (fast, 2M context)"),
        ("grok-3-mini-beta", "Lightweight"),
    ],
    "ollama": [
        ("llama3.2", "General purpose, 3B"),
        ("llama3.1", "General purpose, 8B"),
        ("mistral", "Mistral 7B"),
        ("codellama", "Code-optimized"),
        ("qwen2.5", "Multilingual"),
    ],
}


def _default_model_name(provider: str) -> str:
    models = PROVIDER_MODELS.get(provider, [])
    if models:
        return models[0][0]
    raise ValueError(
        f"No models defined for provider '{provider}'. Add it to PROVIDER_MODELS in templates.py."
    )


def template_basic(name: str, provider: str, model_name: str | None = None) -> str:
    model_name = model_name or _default_model_name(provider)
    return f"""\
apiVersion: initrunner/v1
kind: Agent
metadata:
  name: {name}
  spec_version: 2
  description: A new InitRunner agent
  tags:
    - general
spec:
  role: |
    You are a helpful assistant.
  model:
    provider: {provider}
    name: {model_name}
    temperature: 0.1
    max_tokens: 4096
  guardrails:
    max_tokens_per_run: 50000
    max_tool_calls: 20
    timeout_seconds: 300
    max_request_limit: 50
    # input_tokens_limit: 100000     # per-run input token cap
    # total_tokens_limit: 200000     # per-run total token cap
    # session_token_budget: 500000   # cumulative REPL session limit
"""


def template_rag(name: str, provider: str, model_name: str | None = None) -> str:
    model_name = model_name or _default_model_name(provider)
    return f"""\
apiVersion: initrunner/v1
kind: Agent
metadata:
  name: {name}
  spec_version: 2
  description: RAG agent with document ingestion
  tags:
    - rag
spec:
  role: |
    You are a knowledge assistant. Use search_documents to find relevant
    content before answering. Always cite your sources.
  model:
    provider: {provider}
    name: {model_name}
    temperature: 0.1
    max_tokens: 4096
  ingest:
    sources:
      - "./docs/**/*.md"
      - "./docs/**/*.txt"
    chunking:
      strategy: fixed
      chunk_size: 512
      chunk_overlap: 50
  guardrails:
    max_tokens_per_run: 50000
    max_tool_calls: 20
    timeout_seconds: 300
    max_request_limit: 50
    # input_tokens_limit: 100000     # per-run input token cap
    # total_tokens_limit: 200000     # per-run total token cap
    # session_token_budget: 500000   # cumulative REPL session limit
"""


def template_daemon(name: str, provider: str, model_name: str | None = None) -> str:
    model_name = model_name or _default_model_name(provider)
    return f"""\
apiVersion: initrunner/v1
kind: Agent
metadata:
  name: {name}
  spec_version: 2
  description: Daemon agent with triggers
  tags:
    - daemon
spec:
  role: |
    You are a monitoring assistant that responds to events.
  model:
    provider: {provider}
    name: {model_name}
    temperature: 0.1
    max_tokens: 4096
  triggers:
    - type: file_watch
      paths: ["./watched"]
      extensions: [".md", ".txt"]
      prompt_template: "File changed: {{path}}. Summarize the changes."
    - type: cron
      schedule: "0 9 * * 1"
      prompt: "Generate weekly status report."
  # sinks:
  #   - type: webhook
  #     url: ${{SLACK_WEBHOOK_URL}}
  #     retry_count: 2
  #   - type: file
  #     path: ./agent-results.jsonl
  #     format: json
  guardrails:
    max_tokens_per_run: 50000
    max_tool_calls: 20
    timeout_seconds: 300
    max_request_limit: 50
    # input_tokens_limit: 100000     # per-run input token cap
    # total_tokens_limit: 200000     # per-run total token cap
    # daemon_token_budget: 2000000        # lifetime limit (resets on restart)
    # daemon_daily_token_budget: 200000   # resets daily (UTC midnight)
"""


def template_memory(name: str, provider: str, model_name: str | None = None) -> str:
    model_name = model_name or _default_model_name(provider)
    return f"""\
apiVersion: initrunner/v1
kind: Agent
metadata:
  name: {name}
  spec_version: 2
  description: Agent with long-term memory
  tags:
    - memory
spec:
  role: |
    You are a helpful assistant with long-term memory.
    Use the remember() tool to save important information.
    Use the recall() tool to search your memories before answering.
    Use the list_memories() tool to browse recent memories.
  model:
    provider: {provider}
    name: {model_name}
    temperature: 0.1
    max_tokens: 4096
  memory:
    max_sessions: 10
    max_resume_messages: 20
    semantic:
      max_memories: 1000
  guardrails:
    max_tokens_per_run: 50000
    max_tool_calls: 20
    timeout_seconds: 300
    max_request_limit: 50
    # input_tokens_limit: 100000     # per-run input token cap
    # total_tokens_limit: 200000     # per-run total token cap
    # session_token_budget: 500000   # cumulative REPL session limit
"""


def template_ollama(name: str, provider: str, model_name: str | None = None) -> str:
    # Always use ollama provider for this template, regardless of --provider flag
    model_name = model_name or _default_model_name("ollama")
    return f"""\
apiVersion: initrunner/v1
kind: Agent
metadata:
  name: {name}
  spec_version: 2
  description: Agent using local Ollama model
  tags:
    - ollama
    - local
spec:
  role: |
    You are a helpful assistant running on a local Ollama model.
  model:
    provider: ollama
    name: {model_name}  # Run: ollama pull {model_name}
    # base_url: http://localhost:11434/v1  # default; override for remote Ollama
    temperature: 0.1
    max_tokens: 4096
  guardrails:
    max_tokens_per_run: 50000
    max_tool_calls: 20
    timeout_seconds: 300
    max_request_limit: 50
    # input_tokens_limit: 100000     # per-run input token cap
    # total_tokens_limit: 200000     # per-run total token cap
    # session_token_budget: 500000   # cumulative REPL session limit
"""


def template_tool(name: str, provider: str) -> str:
    # Returns a Python file, not YAML
    return f'''\
"""Custom tools for InitRunner.

Reference this module in your role.yaml:

  tools:
    - type: custom
      module: {name}
      # function: greet  # omit to auto-discover all public functions
      config:
        greeting: "Hello"

Functions that accept a `tool_config` parameter will receive
the `config` dict from the YAML definition.
"""


def greet(name: str) -> str:
    """Greet someone by name."""
    return f"Hello, {{name}}!"


def greet_with_config(name: str, tool_config: dict) -> str:
    """Greet someone using a configurable greeting.

    The tool_config parameter is automatically injected from
    the `config` section of your role YAML — the LLM never sees it.
    """
    greeting = tool_config.get("greeting", "Hello")
    return f"{{greeting}}, {{name}}!"


def add_numbers(a: int, b: int) -> str:
    """Add two numbers together."""
    return str(a + b)
'''


def template_api(name: str, provider: str, model_name: str | None = None) -> str:
    model_name = model_name or _default_model_name(provider)
    return f"""\
apiVersion: initrunner/v1
kind: Agent
metadata:
  name: {name}
  spec_version: 2
  description: Agent with declarative API tools
  tags:
    - api
spec:
  role: |
    You are a helpful assistant with API access.
    Use the available tools to fetch data from external APIs.
  model:
    provider: {provider}
    name: {model_name}
    temperature: 0.1
    max_tokens: 4096
  tools:
    - type: api
      name: weather
      description: Weather API
      base_url: https://api.example.com
      headers:
        Authorization: "Bearer ${{API_KEY}}"
      endpoints:
        - name: get_weather
          method: GET
          path: "/weather/{{city}}"
          description: Get current weather for a city
          parameters:
            - name: city
              type: string
              required: true
              description: City name
          response_extract: "$.current"
        - name: get_forecast
          method: GET
          path: "/forecast/{{city}}"
          description: Get weather forecast
          parameters:
            - name: city
              type: string
              required: true
              description: City name
            - name: days
              type: integer
              required: false
              default: 3
              description: Number of forecast days
          query_params:
            days: "{{days}}"
  guardrails:
    max_tokens_per_run: 50000
    max_tool_calls: 20
    timeout_seconds: 300
    max_request_limit: 50
    # input_tokens_limit: 100000     # per-run input token cap
    # total_tokens_limit: 200000     # per-run total token cap
    # session_token_budget: 500000   # cumulative REPL session limit
"""


def template_telegram(name: str, provider: str, model_name: str | None = None) -> str:
    model_name = model_name or _default_model_name(provider)
    return f"""\
apiVersion: initrunner/v1
kind: Agent
metadata:
  name: {name}
  spec_version: 2
  description: Telegram bot agent
  tags:
    - telegram
    - daemon
spec:
  role: |
    You are a helpful assistant responding to Telegram messages.
    Keep responses concise and well-formatted for mobile reading.
  model:
    provider: {provider}
    name: {model_name}
    temperature: 0.1
    max_tokens: 4096
  triggers:
    - type: telegram
      token_env: TELEGRAM_BOT_TOKEN
      allowed_users: []  # add usernames to restrict access
      prompt_template: "{{message}}"
  guardrails:
    max_tokens_per_run: 50000
    max_tool_calls: 20
    timeout_seconds: 300
    max_request_limit: 50
    daemon_daily_token_budget: 200000
"""


def template_discord(name: str, provider: str, model_name: str | None = None) -> str:
    model_name = model_name or _default_model_name(provider)
    return f"""\
apiVersion: initrunner/v1
kind: Agent
metadata:
  name: {name}
  spec_version: 2
  description: Discord bot agent
  tags:
    - discord
    - daemon
spec:
  role: |
    You are a helpful assistant responding to Discord messages.
    Keep responses concise. You respond to DMs and @mentions.
  model:
    provider: {provider}
    name: {model_name}
    temperature: 0.1
    max_tokens: 4096
  triggers:
    - type: discord
      token_env: DISCORD_BOT_TOKEN
      channel_ids: []     # restrict to specific channels
      allowed_roles: []   # restrict to specific roles
      prompt_template: "{{message}}"
  guardrails:
    max_tokens_per_run: 50000
    max_tool_calls: 20
    timeout_seconds: 300
    max_request_limit: 50
    daemon_daily_token_budget: 200000
"""


def template_skill(name: str, provider: str) -> str:
    return f"""\
---
name: {name}
description: A reusable skill bundle. Use when the agent needs these capabilities.
compatibility: Requires initrunner
metadata:
  author: ""
  version: "1.0"
# InitRunner extensions — tool configs and requirements
tools:
  - type: filesystem
    root_path: "."
    read_only: true
requires:
  env: []
  bins: []
  # env:
  #   - MY_API_KEY
  # bins:
  #   - jq
---

You have access to the {name} skill capabilities.

## Instructions

- Describe step-by-step how the agent should use these tools
- Include examples of expected inputs and outputs
"""


TEMPLATES: dict[str, Callable[..., str]] = {
    "basic": template_basic,
    "rag": template_rag,
    "daemon": template_daemon,
    "memory": template_memory,
    "ollama": template_ollama,
    "tool": template_tool,
    "api": template_api,
    "telegram": template_telegram,
    "discord": template_discord,
    "skill": template_skill,
}

# --- Tool prompt configs for wizard ---

# Each entry: (field_name, prompt_text, default_value)
TOOL_PROMPT_FIELDS: dict[str, list[tuple[str, str, str]]] = {
    "filesystem": [
        ("root_path", "Root path", "."),
        ("read_only", "Read-only?", "true"),
    ],
    "git": [
        ("repo_path", "Repository path", "."),
        ("read_only", "Read-only?", "true"),
    ],
    "python": [
        ("require_confirmation", "Require confirmation?", "true"),
        ("network_disabled", "Disable network?", "true"),
    ],
    "shell": [
        ("require_confirmation", "Require confirmation?", "true"),
        ("timeout_seconds", "Timeout (seconds)", "30"),
    ],
    "http": [
        ("base_url", "Base URL", "https://api.example.com"),
    ],
    "web_reader": [],
    "sql": [
        ("database", "Database path", "./data.db"),
        ("read_only", "Read-only?", "true"),
    ],
    "datetime": [
        ("default_timezone", "Default timezone", "UTC"),
    ],
    "mcp": [
        ("command", "Server command", ""),
    ],
    "slack": [
        ("webhook_url", "Webhook URL", ""),
    ],
}

# Short descriptions for tool selection menu
TOOL_DESCRIPTIONS: dict[str, str] = {
    "filesystem": "Read/write files",
    "git": "Git operations",
    "python": "Execute Python code",
    "shell": "Run shell commands",
    "http": "HTTP requests",
    "web_reader": "Fetch web pages",
    "sql": "Query SQLite databases",
    "datetime": "Date/time utilities",
    "mcp": "MCP server integration",
    "slack": "Send Slack messages",
}

# Wizard template descriptions
WIZARD_TEMPLATES: dict[str, str] = {
    "basic": "Simple assistant",
    "rag": "Answers from your documents",
    "memory": "Remembers across sessions",
    "daemon": "Runs on schedule / watches files",
    "api": "Declarative REST API tools",
    "blank": "Just the essentials, add everything yourself",
}

# Listable role templates (excludes blank, tool, skill)
LISTABLE_TEMPLATES: dict[str, str] = {
    "basic": "Simple assistant",
    "rag": "Answers from your documents",
    "daemon": "Runs on schedule / watches files",
    "memory": "Remembers across sessions",
    "ollama": "Local Ollama model",
    "api": "Declarative REST API tools",
    "telegram": "Telegram bot agent",
    "discord": "Discord bot agent",
}


# Compose scaffold patterns
COMPOSE_PATTERNS: dict[str, str] = {
    "chain": "Linear A -> B -> C chain",
    "fan-out": "One dispatcher fans out to multiple workers",
    "route": "Intake routes to specialists via intent sensing",
}


def build_role_yaml(
    *,
    name: str,
    description: str = "",
    provider: str = "openai",
    model_name: str | None = None,
    system_prompt: str = "You are a helpful assistant.",
    tools: list[dict[str, Any]] | None = None,
    tags: list[str] | None = None,
    memory: bool = False,
    ingest: dict[str, Any] | None = None,
    triggers: list[dict[str, Any]] | None = None,
    sinks: list[dict[str, Any]] | None = None,
    temperature: float = 0.1,
    max_tokens: int = 4096,
) -> str:
    """Build role YAML programmatically from structured parameters.

    Returns a YAML string ready to write to disk.
    """
    import yaml

    if model_name is None:
        model_name = _default_model_name(provider)

    role: dict[str, Any] = {
        "apiVersion": "initrunner/v1",
        "kind": "Agent",
        "metadata": {
            "name": name,
            "spec_version": 2,
            "description": description,
            "tags": tags if tags is not None else [],
        },
        "spec": {
            "role": system_prompt,
            "model": {
                "provider": provider,
                "name": model_name,
                "temperature": temperature,
                "max_tokens": max_tokens,
            },
            "guardrails": {
                "max_tokens_per_run": 50000,
                "max_tool_calls": 20,
                "timeout_seconds": 300,
                "max_request_limit": 50,
            },
        },
    }

    if tools:
        role["spec"]["tools"] = tools  # type: ignore[invalid-assignment]

    if triggers:
        role["spec"]["triggers"] = triggers  # type: ignore[invalid-assignment]

    if sinks:
        role["spec"]["sinks"] = sinks  # type: ignore[invalid-assignment]

    if memory:
        role["spec"]["memory"] = {  # type: ignore[invalid-assignment]
            "max_sessions": 10,
            "max_resume_messages": 20,
            "semantic": {"max_memories": 1000},
        }

    if ingest:
        role["spec"]["ingest"] = ingest  # type: ignore[invalid-assignment]

    return yaml.dump(role, default_flow_style=False, sort_keys=False, allow_unicode=True)
