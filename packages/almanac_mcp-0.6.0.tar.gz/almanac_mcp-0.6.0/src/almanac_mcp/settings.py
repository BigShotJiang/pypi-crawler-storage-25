"""Configuración del MCP client v0.2.

v0.2 cambia el modelo: en lugar de pegarle directo a Postgres / R2,
todas las tools delegan al endpoint HTTP /api/mcp/v1/invoke del web
de Almanac. El client solo necesita URL del site + API key del user.
"""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    """Configuración inmutable del client. Sin I/O en __init__."""

    site_url: str
    api_key: str

    @classmethod
    def from_env(cls) -> Settings:
        api_key = os.environ.get("ALMANAC_API_KEY", "").strip()
        if not api_key:
            raise RuntimeError(
                "ALMANAC_API_KEY no está definida. Generá una key en "
                "https://almanac.ar/account/api-keys (requiere plan Pro+ o Enterprise) "
                "y configurala en el env del cliente MCP."
            )
        if not api_key.startswith("alm_"):
            raise RuntimeError(
                "ALMANAC_API_KEY tiene formato inválido. Las keys de Almanac "
                "arrancan con 'alm_'. Revisá tu config."
            )
        site_url = os.environ.get("ALMANAC_SITE_URL", "https://almanac.ar").rstrip("/")
        return cls(site_url=site_url, api_key=api_key)

    @property
    def invoke_url(self) -> str:
        """URL del endpoint multiplexor JSON del web server."""
        return f"{self.site_url}/api/mcp/v1/invoke"
