"""FastMCP server v0.6 — delega todo al endpoint HTTP /api/mcp/v1/invoke.

Las 7 tools v0.6 (underscore naming — Claude regex):
    catalog_list          → punto de entrada dual (sin args: lista;
                            con dataset_id: ficha completa). Reemplaza
                            el flow viejo catalog_list → catalog_get.
    catalog_get           → DEPRECATED, alias de catalog_list(dataset_id).
                            Se remueve en v0.7.0.
    data_summary          → row count + min/max/distinct. Universal
                            Postgres + DuckDB sobre parquet (v0.6.0).
    data_distinct_values  → top-N valores categóricos con count + search.
                            Whitelist desde DB (no hardcoded server).
    data_snapshot_url     → signed URL al snapshot productivo completo (R2)
    data_query            → ejecuta SQL contra Postgres data_* (datos completos)
    data_query_parquet    → ejecuta SQL DuckDB contra parquet en R2

Workflow recomendado v0.6:
    catalog_list() → catalog_list(dataset_id="...") → data_summary →
    data_distinct_values → data_query / data_query_parquet.

El client Python ya NO toca Postgres ni R2 directo. Todo el compute y
security pasa por el web server. Beneficios:
    - Cero credenciales en el cliente (solo ALMANAC_API_KEY)
    - Schema discovery + AI metadata viven server-side y se actualizan sin
      bump de versión del client
    - Telemetry centralizado en mcp_invocations
"""

from __future__ import annotations

import logging
import platform
from typing import Any

from mcp.server.fastmcp import FastMCP

from almanac_mcp import __version__
from almanac_mcp.client import MCPHttpClient
from almanac_mcp.settings import Settings

log = logging.getLogger(__name__)


def _client_info() -> dict[str, str]:
    """Metadata del client para telemetry server-side."""
    return {
        "client": "almanac-mcp",
        "version": __version__,
        "os": platform.system().lower(),
    }


def build_server(settings: Settings | None = None) -> FastMCP:
    """Construye el server MCP con las 7 tools registradas."""
    if settings is None:
        settings = Settings.from_env()

    mcp = FastMCP("almanac")
    client = MCPHttpClient(settings)

    @mcp.tool(name="catalog_list")
    def catalog_list(
        dataset_id: str | None = None,
        include_download_only: bool = False,
    ) -> Any:
        """Punto de entrada de discovery del catálogo Almanac. Modo dual.

        Sin dataset_id → lista compacta de datasets publicados queryables vía
        SQL. Cada item trae: dataset_id, name, source, description, frequency,
        historical_depth, country, queryable_via_sql, table_name,
        downloadable_via_snapshot_url, content_advisory.

        Con dataset_id → ficha completa del dataset. Llamada equivalente a la
        vieja catalog_get pero enriquecida: business_questions, example_queries
        (templates SQL/polars), gotchas conocidos, methodology_notes,
        related_datasets, mcp.columns (schema legible), mcp.summary_columns y
        mcp.explorable_columns (whitelists para data_summary y
        data_distinct_values), snapshot stats (rows_count, snapshot_at),
        content_advisory, update_pattern, freshness_sla, country,
        source_native_language, compliance_notes.

        Workflow recomendado:
            1. catalog_list() → ver qué hay
            2. catalog_list(dataset_id="x.y.z") → leer la ficha del dataset elegido
            3. data_summary(dataset_id) → confirmar volumen y rangos
            4. data_distinct_values(dataset_id, column) → ver valores categoricos
            5. data_query / data_query_parquet → SQL real

        Args:
            dataset_id: Si se pasa, devuelve ficha completa. Si no, lista corta.
            include_download_only: Solo aplica en modo lista. Si True, incluye
                datasets parquet-only (consultables vía data_snapshot_url o
                data_query_parquet, no via data_query).
        """
        params: dict[str, Any] = {}
        if dataset_id is not None:
            params["dataset_id"] = dataset_id
        if include_download_only:
            params["include_download_only"] = True
        return client.invoke(
            "catalog_list",
            params,
            client_info=_client_info(),
        ).result

    @mcp.tool(name="catalog_get")
    def catalog_get(dataset_id: str) -> dict[str, Any]:
        """DEPRECATED: usar catalog_list(dataset_id=...) en su lugar.

        Mantenido como alias durante v0.6.x para retrocompatibilidad. Será
        removido en v0.7.0 (target 2026-Q3). El response incluye un
        deprecated_notice para que el agente aprenda a usar el flow nuevo.

        Devuelve exactamente la misma ficha que catalog_list(dataset_id="..."):
        metadata completa + schema + columns + summary_columns +
        explorable_columns + snapshot stats + advisory + compliance + freshness.

        Args:
            dataset_id: Identificador formato {fuente}.{categoria}.{nombre},
                ej: 'bcra.monetarias.indicadores'.
        """
        return client.invoke(
            "catalog_get",
            {"dataset_id": dataset_id},
            client_info=_client_info(),
        ).result

    @mcp.tool(name="data_snapshot_url")
    def data_snapshot_url(dataset_id: str, format: str = "parquet") -> dict[str, Any]:
        """Devuelve una URL firmada R2 de 10 minutos al snapshot productivo completo.

        Útil cuando el cliente quiere bajar el dataset completo y trabajarlo
        localmente (DuckDB, polars, pandas, R, etc). Para queries SQL rápidas
        sobre los datos completos sin descarga, usar `data_query`.

        Args:
            dataset_id: Identificador del dataset.
            format: 'parquet' (recomendado) o 'csv'.

        Returns:
            { url, expires_in_seconds, dataset_id, format,
              snapshot: { snapshot_at, rows_count, file_size_bytes } }
        """
        return client.invoke(
            "data_snapshot_url",
            {"dataset_id": dataset_id, "format": format},
            client_info=_client_info(),
        ).result

    @mcp.tool(name="data_summary")
    def data_summary(dataset_id: str) -> dict[str, Any]:
        """Caracterización rápida del dataset. Universal Postgres + parquet.

        Llamar SIEMPRE antes de empezar a samplear con data_query. Evita
        inferir cobertura desde un LIMIT 1 (ej. "abril 2026 solo tiene Cuyo"
        cuando en realidad hay 7 regiones — Cuyo era la primera fila que
        devolvió el sample).

        Universal desde v0.6.0:
            - Si el dataset tiene tabla data_* en Postgres → query directa
              con role mcp_query.
            - Si solo está en R2 (parquet snapshot) → DuckDB sobre el parquet
              con signed URL, MIN/MAX/COUNT DISTINCT sobre las columnas
              declaradas como summary_columns en el AI metadata.

        Returns:
            { dataset_id, table_name (puede ser null si es parquet-only),
              backend ("postgres" | "duckdb+r2-parquet"), total_rows,
              snapshot_at (en path parquet),
              columns: [{name, distinct_count, min, max}] }
        """
        return client.invoke(
            "data_summary",
            {"dataset_id": dataset_id},
            client_info=_client_info(),
        ).result

    @mcp.tool(name="data_distinct_values")
    def data_distinct_values(
        dataset_id: str,
        column: str,
        search: str | None = None,
        limit: int = 25,
    ) -> dict[str, Any]:
        """Top-N valores distintos de una columna con su count, opcionalmente filtrados por substring.

        Pensado para datasets con dimensiones categóricas de alta cardinalidad
        (1.220 id_variable en BCRA monetarias, ~500 concept XBRL en SEC,
        miles de codigos contables). Permite encontrar el valor exacto a
        filtrar en data_query sin tener que adivinar con ILIKE.

        Args:
            dataset_id: Identificador del dataset.
            column: Nombre de la columna a explorar. Debe estar en el
                whitelist server-side (ver catalog_get → mcp.columns).
            search: Substring opcional para filtrar valores (ILIKE).
            limit: Top-N por count, default 25, max 100.

        Returns:
            { dataset_id, column, total_distinct, values: [{value, row_count}], truncated }
        """
        return client.invoke(
            "data_distinct_values",
            {
                "dataset_id": dataset_id,
                "column": column,
                **({"search": search} if search else {}),
                "limit": limit,
            },
            client_info=_client_info(),
        ).result

    @mcp.tool(name="data_query")
    def data_query(sql: str) -> dict[str, Any]:
        """Ejecuta una query SQL SELECT/WITH/EXPLAIN sobre las tablas de Almanac.

        Las tablas disponibles tienen prefijo `data_*` (ver catalog_get →
        mcp.table_name por dataset). Soporta JOINs cross-dataset entre BCRA,
        INDEC, CNV, SEC. Solo lectura — DDL/DML rechazados.

        Constraints server-side:
            - statement_timeout: 30s
            - cap de filas: 10.000 (truncated=true si excede)
            - work_mem: 32 MB

        Args:
            sql: Query SQL válida. Ej:
                "SELECT fecha, valor FROM data_bcra_monetarias_indicadores
                 WHERE id_variable = 1 AND fecha >= '2024-01-01'
                 ORDER BY fecha DESC LIMIT 100"

        Returns:
            { rows: list[dict], row_count: int, truncated: bool,
              columns: list[str] }
        """
        return client.invoke(
            "data_query",
            {"sql": sql},
            client_info=_client_info(),
        ).result

    @mcp.tool(name="data_query_parquet")
    def data_query_parquet(dataset_id: str, sql: str) -> dict[str, Any]:
        """Ejecuta SQL contra el snapshot parquet del dataset en R2 (DuckDB server-side).

        Usar para datasets grandes que NO están en Postgres (balances, deudores,
        indicadores bancarios, plan-cuentas, etc — todos los que catalog_list
        muestra con queryable_via_sql=false). DuckDB hace predicate pushdown
        sobre el parquet, así que filtros por columna son eficientes incluso
        con datasets de millones de filas.

        Escribir el SQL referenciando el table_name como si fuera Postgres
        (ej. `data_bcra_entidades_financieras_balances`). El server reemplaza
        ese nombre por `read_parquet('<signed-url>')` antes de pasarlo a
        DuckDB. La SQL debe ser DuckDB-compatible (mismas funciones que
        Postgres más algunas extras).

        Constraints server-side:
            - cap 10.000 filas (truncated=true si excede)
            - timeout 30s
            - memory_limit 512MB
            - threads 2

        Args:
            dataset_id: Identificador del dataset.
            sql: Query SQL DuckDB-compatible. Ej:
                "SELECT cuit, fecha, valor FROM
                 data_bcra_entidades_financieras_balances
                 WHERE cuit = '30-50001091-2' AND fecha >= '2024-01-01'
                 ORDER BY fecha DESC LIMIT 100"

        Returns:
            { rows, row_count, truncated, columns, backend, snapshot_at }
        """
        return client.invoke(
            "data_query_parquet",
            {"dataset_id": dataset_id, "sql": sql},
            client_info=_client_info(),
        ).result

    return mcp
