"""Cliente HTTP del MCP server. Habla con /api/mcp/v1/invoke.

Funcionalidad: invoca tools por nombre, maneja retries con backoff
exponencial para 5xx (server transient), no retry para 4xx (input
inválido del agente), traduce errores estructurados a excepciones
Python pythónicas.

Tipos de error:
    InvalidParams      → el agente mandó params malformados; corregir SQL/args
    ToolUnknown        → tool name no existe en el server (versión mismatch)
    NotFound           → dataset/snapshot no existe
    TierRequired       → API key con tier insuficiente (Pro+ requerido)
    RateLimited        → 429, esperar y reintentar
    Timeout            → query > 30s, refinar
    InternalError      → 500 del server (poco común)
    NetworkError       → connection refused / DNS / etc.
"""

from __future__ import annotations

import logging
import time
import uuid
from dataclasses import dataclass
from typing import Any

import httpx

from almanac_mcp.settings import Settings

log = logging.getLogger(__name__)

USER_AGENT = "almanac-mcp/0.2.0 (+https://almanac.ar/mcp)"
REQUEST_TIMEOUT_S = 60.0
MAX_RETRIES = 3
RETRY_BASE_DELAY_S = 0.5


class MCPClientError(Exception):
    """Base de errors del client."""

    code: str

    def __init__(self, message: str, code: str = "unknown", details: dict[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.details = details or {}


class InvalidParams(MCPClientError):
    code = "invalid_params"


class ToolUnknown(MCPClientError):
    code = "tool_unknown"


class NotFound(MCPClientError):
    code = "not_found"


class TierRequired(MCPClientError):
    code = "tier_required"


class RateLimited(MCPClientError):
    code = "rate_limited"


class TimeoutError(MCPClientError):  # noqa: A001
    code = "timeout"


class InternalError(MCPClientError):
    code = "internal"


class NetworkError(MCPClientError):
    code = "network"


_ERROR_BY_CODE: dict[str, type[MCPClientError]] = {
    "invalid_params": InvalidParams,
    "tool_unknown": ToolUnknown,
    "not_found": NotFound,
    "tier_required": TierRequired,
    "rate_limited": RateLimited,
    "timeout": TimeoutError,
    "internal": InternalError,
}


@dataclass(frozen=True)
class InvokeResult:
    result: Any
    request_id: str
    latency_ms: int


class MCPHttpClient:
    """Cliente HTTP del MCP server. Singleton por proceso típicamente."""

    def __init__(self, settings: Settings, *, transport: httpx.BaseTransport | None = None):
        self.settings = settings
        self._http = httpx.Client(
            base_url=settings.site_url,
            timeout=REQUEST_TIMEOUT_S,
            headers={
                "Authorization": f"Bearer {settings.api_key}",
                "User-Agent": USER_AGENT,
                "Content-Type": "application/json",
            },
            transport=transport,
        )

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> MCPHttpClient:
        return self

    def __exit__(self, *_exc_info: Any) -> None:
        self.close()

    def invoke(
        self,
        tool: str,
        params: dict[str, Any] | None = None,
        *,
        client_info: dict[str, str] | None = None,
    ) -> InvokeResult:
        request_id = str(uuid.uuid4())
        body: dict[str, Any] = {"tool": tool, "request_id": request_id}
        if params is not None:
            body["params"] = params
        if client_info:
            body["client_info"] = client_info

        last_exc: Exception | None = None
        for attempt in range(MAX_RETRIES):
            try:
                resp = self._http.post("/api/mcp/v1/invoke", json=body)
            except httpx.RequestError as e:
                last_exc = e
                if attempt < MAX_RETRIES - 1:
                    self._sleep_backoff(attempt)
                    continue
                raise NetworkError(f"Error de red contra Almanac: {e}") from e

            # 5xx → retry; 4xx → fail immediate; 2xx → parse
            if resp.status_code >= 500:
                last_exc = httpx.HTTPStatusError(
                    f"Server {resp.status_code}", request=resp.request, response=resp
                )
                if attempt < MAX_RETRIES - 1:
                    self._sleep_backoff(attempt)
                    continue
                # Out of retries, fall through to parse the error body.

            return self._parse_response(resp, request_id)

        # Solo llegamos acá si NetworkError no relanzó (no debería pasar).
        raise NetworkError(f"Sin respuesta del server tras {MAX_RETRIES} intentos: {last_exc}")

    @staticmethod
    def _sleep_backoff(attempt: int) -> None:
        delay = RETRY_BASE_DELAY_S * (2**attempt)
        log.debug("mcp_client.retry", extra={"attempt": attempt, "delay_s": delay})
        time.sleep(delay)

    @staticmethod
    def _parse_response(resp: httpx.Response, request_id: str) -> InvokeResult:
        try:
            payload = resp.json()
        except ValueError as e:
            raise InternalError(
                f"Server devolvió body no-JSON (status {resp.status_code}): {resp.text[:200]}",
            ) from e

        latency_ms = int(payload.get("latency_ms") or 0)
        server_request_id = payload.get("request_id") or request_id

        if payload.get("ok") is True:
            return InvokeResult(
                result=payload.get("result"),
                request_id=server_request_id,
                latency_ms=latency_ms,
            )

        error = payload.get("error") or {}
        code = error.get("code") or "internal"
        message = error.get("message") or f"Server error {resp.status_code}"
        details = error.get("details") or {}
        exc_cls = _ERROR_BY_CODE.get(code, InternalError)
        raise exc_cls(message, code=code, details=details)
