# mineralML
[![PyPI](https://badgen.net/pypi/v/mineralML)](https://pypi.org/project/mineralML/)
[![Build Status](https://github.com/SarahShi/mineralML/actions/workflows/main.yml/badge.svg?branch=main)](https://github.com/SarahShi/mineralML/actions/workflows/main.yml)
[![Documentation Status](https://readthedocs.org/projects/mineralml/badge/?version=latest)](https://mineralml.readthedocs.io/en/latest/?badge=latest)
[![codecov](https://codecov.io/gh/SarahShi/mineralML/branch/main/graph/badge.svg)](https://codecov.io/gh/SarahShi/mineralML/branch/main)
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/SarahShi/mineralML/blob/main/mineralML_colab.ipynb)
[![Python 3.8](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/release/python-380/)
[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![DOI](https://zenodo.org/badge/567486761.svg)](https://doi.org/10.5281/zenodo.15741887)

We present mineralML (mineral classification using Machine Learning) for probabilistic classification of common igneous minerals. mineralML provides functions for calculating stoichiometries and crystallographic sites based on this classification, along with functions for handling mapped EDS data. Utilizing this package allows for the identification of misclassified mineral phases and poor-quality data. We streamline data processing and cleaning to allow for the rapid transition to usable data, improving the utility of data curated in these databases and furthering computing and modeling capabilities. 

## Documentation
Read the [documentation](https://mineralml.readthedocs.io/en/latest/?badge=latest) for a run-through of the mineralML code. 

## Citation
If you use mineralML in your work, please cite this abstract. This package represents a significant time investment. Proper citation helps support continued development and academic recognition.

```console
Shi, S., Wieser, P., Gordon, C., Toth, N., Antoshechkina, P.M., Gleeson, M., Lehnert, K., (2026) mineralML: Leveraging Machine Learning for Probabilistic Mineral Classification in Geochemical Databases", Earth ArXiv. doi:10.31223/X53J2M
```

```
@article{Shietal2026,
  doi       = {10.31223/X53J2M},
  url       = {https://doi.org/10.31223/X53J2M},
  year      = {2026},
  author    = {Shi, Sarah C and Wieser, Penny E and Gordon, Charlotte and Toth, Norbert and Antoshechkina, Paula M and Gleeson, Matthew LM and Lehnert, Kerstin},
  title     = {mineralML: Leveraging Machine Learning for Probabilistic Mineral Classification},
  journal   = {Earth ArXiv},
}
```

## Run on the Cloud 
If you do not have Python installed locally, run mineralML on [Google Colab](https://colab.research.google.com/github/SarahShi/mineralML/blob/main/mineralML_colab.ipynb). The Cloud-based version runs rapidly, with test cases of >10,000 microanalyses classified within 4 seconds. 


## Run and Install Locally
Obtain a version of Python between 3.8 and 3.12 if you do not already have it installed. mineralML can be installed with one line. Open terminal and type the following:

```
pip install mineralML
```

Make sure that you keep up with the latest version of mineralML. To upgrade to the latest version of mineralML, open terminal and type the following: 

```
pip install mineralML --upgrade
```