"""Download a dataset from the Cluster Protocol marketplace."""
from cluster_sdk import ClusterClient

client = ClusterClient()  # Uses CLUSTER_API_KEY env var

# List available datasets
listing = client.datasets.list(search="smart contract")
print(f"Found {listing.pagination.total} datasets\n")

# Download the first result
if listing.datasets:
    ds = listing.datasets[0]
    print(f"Downloading: {ds.name} ({len(ds.files)} files)")
    result = client.datasets.download(ds.slug, output_dir="./downloads", progress=True)
    print(f"\nDownloaded {len(result.files)} files ({result.total_bytes / 1048576:.1f} MB)")
    for f in result.files:
        print(f"  {f.filename} -> {f.path}")
    if result.skipped:
        print(f"\nSkipped {len(result.skipped)} files (no IPFS CID):")
        for name in result.skipped:
            print(f"  {name}")

client.close()
