"""Check your Cluster Protocol account balance."""

from cluster_sdk import ClusterClient

client = ClusterClient(api_key="sk-cluster-xxxx")

balance = client.balance.get()
print(f"Balance:    ${balance.usd:.2f}")
print(f"Deposited:  ${balance.total_deposited:.2f}")
print(f"Spent:      ${balance.total_spent:.2f}")
