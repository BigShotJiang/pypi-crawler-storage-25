"""Basic chat completion example."""

from cluster_sdk import ClusterClient

client = ClusterClient(api_key="sk-cluster-xxxx")

response = client.chat.completions.create(
    model="llama-3.1-8b",
    messages=[{"role": "user", "content": "What is the meaning of life?"}],
    temperature=0.7,
)

print(response.choices[0].message.content)
