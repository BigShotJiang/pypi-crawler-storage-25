"""Compare responses from multiple models side-by-side."""

from cluster_sdk import ClusterClient

client = ClusterClient(api_key="sk-cluster-xxxx")

models_to_compare = ["llama-3.1-8b", "mixtral-8x7b"]
prompt = "Explain quantum computing in one sentence."

for model_id in models_to_compare:
    response = client.chat.completions.create(
        model=model_id,
        messages=[{"role": "user", "content": prompt}],
        max_tokens=100,
    )
    print(f"[{model_id}]")
    print(response.choices[0].message.content)
    print()
