"""Streaming chat completion example."""

from cluster_sdk import ClusterClient

client = ClusterClient(api_key="sk-cluster-xxxx")

stream = client.chat.completions.create(
    model="llama-3.1-8b",
    messages=[{"role": "user", "content": "Write a short poem about AI."}],
    stream=True,
)

for chunk in stream:
    content = chunk.choices[0].delta.content
    if content:
        print(content, end="", flush=True)

print()  # newline at the end
