"""List all available models on the Cluster Protocol network."""

from cluster_sdk import ClusterClient

client = ClusterClient(api_key="sk-cluster-xxxx")

models = client.models.list()
for model in models:
    print(f"{model.id:30s} owned_by={model.owned_by}")
