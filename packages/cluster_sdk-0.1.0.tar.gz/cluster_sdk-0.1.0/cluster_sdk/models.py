from __future__ import annotations

from typing import Any, List, Optional, Union

from pydantic import BaseModel, ConfigDict, Field, field_validator


class Usage(BaseModel):
    """Token usage statistics for a completion."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class Message(BaseModel):
    """A chat message."""

    role: str
    content: Optional[str] = None


class Delta(BaseModel):
    """A streaming delta update."""

    role: Optional[str] = None
    content: Optional[str] = None


class Choice(BaseModel):
    """A completion choice."""

    index: int = 0
    message: Message
    finish_reason: Optional[str] = None


class StreamChoice(BaseModel):
    """A streaming completion choice."""

    index: int = 0
    delta: Delta
    finish_reason: Optional[str] = None


class ChatCompletion(BaseModel):
    """A chat completion response."""

    id: str = ""
    object: str = "chat.completion"
    created: int = 0
    model: str = ""
    choices: List[Choice] = Field(default_factory=list)
    usage: Optional[Usage] = None


class ChatCompletionChunk(BaseModel):
    """A streaming chat completion chunk."""

    id: str = ""
    object: str = "chat.completion.chunk"
    created: int = 0
    model: str = ""
    choices: List[StreamChoice] = Field(default_factory=list)


class Model(BaseModel):
    """An available model."""

    id: str
    object: str = "model"
    created: int = 0
    owned_by: str = ""


class UserBalance(BaseModel):
    """User account balance."""

    model_config = ConfigDict(populate_by_name=True)

    usd: float = Field(0.0, alias="balanceUsd")
    total_deposited: float = Field(0.0, alias="totalDeposited")
    total_spent: float = Field(0.0, alias="totalSpent")

    @field_validator("usd", "total_deposited", "total_spent", mode="before")
    @classmethod
    def _coerce_str_to_float(cls, v: Any) -> float:
        if isinstance(v, str):
            return float(v)
        return v


class UsageRecord(BaseModel):
    """A single usage log entry."""

    model: str = ""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cost: float = 0.0
    created_at: str = ""


class UsageResponse(BaseModel):
    """Usage stats response."""

    model_config = ConfigDict(populate_by_name=True)

    total_requests: int = Field(0, alias="totalRequests")
    total_tokens_in: int = Field(0, alias="totalTokensIn")
    total_tokens_out: int = Field(0, alias="totalTokensOut")
    total_tokens: int = Field(0, alias="totalTokens")
    total_cost: float = Field(0.0, alias="totalCost")
    avg_cost_per_request: float = Field(0.0, alias="avgCostPerRequest")
    avg_latency_ms: float = Field(0.0, alias="avgLatencyMs")

    @field_validator("total_cost", "avg_cost_per_request", "avg_latency_ms", mode="before")
    @classmethod
    def _coerce_str_to_float(cls, v: Any) -> float:
        if isinstance(v, str):
            return float(v)
        return v


# ── Embedding types ─────────────────────────────────────────

class Embedding(BaseModel):
    """A single embedding vector."""

    object: str = "embedding"
    embedding: List[float] = Field(default_factory=list)
    index: int = 0


class EmbeddingUsage(BaseModel):
    """Token usage for an embedding request."""

    prompt_tokens: int = 0
    total_tokens: int = 0


class EmbeddingResponse(BaseModel):
    """Response from the embeddings endpoint."""

    object: str = "list"
    data: List[Embedding] = Field(default_factory=list)
    model: str = ""
    usage: Optional[EmbeddingUsage] = None


# ── Dataset types ───────────────────────────────────────────

class DatasetFile(BaseModel):
    """A file within a dataset."""

    id: str = ""
    filename: str = ""
    ipfsCid: Optional[str] = None
    sizeBytes: Optional[int] = None
    format: Optional[str] = None


class DatasetCreator(BaseModel):
    """Dataset creator info."""

    id: str = ""
    username: str = ""


class Dataset(BaseModel):
    """A dataset in the marketplace."""

    id: str = ""
    name: str = ""
    slug: str = ""
    description: str = ""
    longDescription: Optional[str] = None
    license: str = ""
    pricingType: str = "free"
    priceUsd: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    taskCategories: List[str] = Field(default_factory=list)
    status: str = ""
    downloadCount: int = 0
    numRows: Optional[int] = None
    totalSizeBytes: Optional[int] = None
    numFiles: Optional[int] = None
    formats: List[str] = Field(default_factory=list)
    files: List[DatasetFile] = Field(default_factory=list)
    creator: Optional[DatasetCreator] = None
    createdAt: Optional[str] = None
    updatedAt: Optional[str] = None


class DatasetPagination(BaseModel):
    """Pagination info for dataset listing."""

    total: int = 0
    page: int = 1
    limit: int = 20


class DatasetList(BaseModel):
    """Paginated list of datasets."""

    datasets: List[Dataset] = Field(default_factory=list)
    pagination: DatasetPagination = Field(default_factory=DatasetPagination)


class PurchaseResult(BaseModel):
    """Result of a dataset purchase."""

    id: Optional[str] = None
    datasetId: str = ""
    status: str = ""
    message: Optional[str] = None


class AccessCheck(BaseModel):
    """Result of a dataset access check."""

    hasAccess: bool = False
    reason: Optional[str] = None


# ── Download types ──────────────────────────────────────────

class DownloadedFile(BaseModel):
    """A successfully downloaded file."""

    filename: str
    path: str
    size_bytes: int
    ipfs_cid: str
    format: Optional[str] = None


class DownloadResult(BaseModel):
    """Result of downloading dataset files."""

    dataset_id: str
    dataset_slug: str
    output_dir: str
    files: List[DownloadedFile] = Field(default_factory=list)
    skipped: List[str] = Field(default_factory=list)
    total_bytes: int = 0
