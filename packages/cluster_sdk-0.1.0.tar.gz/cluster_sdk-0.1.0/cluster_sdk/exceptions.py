from __future__ import annotations


class ClusterError(Exception):
    """Base exception for all Cluster SDK errors."""

    def __init__(self, message: str, status_code: int | None = None, body: object | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class AuthenticationError(ClusterError):
    """Raised when the API key is invalid or missing (HTTP 401)."""


class InsufficientBalanceError(ClusterError):
    """Raised when the account balance is too low (HTTP 402)."""


class ModelNotFoundError(ClusterError):
    """Raised when the requested model does not exist (HTTP 404)."""


class RateLimitError(ClusterError):
    """Raised when the rate limit is exceeded (HTTP 429)."""


class ServerError(ClusterError):
    """Raised on server-side errors (HTTP 5xx)."""


class StreamError(ClusterError):
    """Raised when a streaming connection fails."""


class TimeoutError(ClusterError):
    """Raised when a request times out."""
