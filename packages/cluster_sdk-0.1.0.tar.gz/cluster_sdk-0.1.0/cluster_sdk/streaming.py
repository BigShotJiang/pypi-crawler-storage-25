from __future__ import annotations

import json
from typing import AsyncIterator, Iterator

import httpx

from .exceptions import StreamError
from .models import ChatCompletionChunk


def parse_sse_stream(response: httpx.Response) -> Iterator[ChatCompletionChunk]:
    """Parse a Server-Sent Events stream into ChatCompletionChunk objects.

    Reads lines from an httpx streaming response, extracts JSON from
    'data:' prefixed lines, and yields parsed chunks until '[DONE]'.
    """
    try:
        for line in response.iter_lines():
            line = line.strip()
            if not line:
                continue
            if not line.startswith("data:"):
                continue
            payload = line[len("data:"):].strip()
            if payload == "[DONE]":
                return
            try:
                data = json.loads(payload)
            except json.JSONDecodeError:
                continue
            yield ChatCompletionChunk.model_validate(data)
    except httpx.RemoteProtocolError as exc:
        raise StreamError(f"Stream connection lost: {exc}") from exc


async def parse_sse_stream_async(response: httpx.Response) -> AsyncIterator[ChatCompletionChunk]:
    """Async version of the SSE stream parser."""
    try:
        async for line in response.aiter_lines():
            line = line.strip()
            if not line:
                continue
            if not line.startswith("data:"):
                continue
            payload = line[len("data:"):].strip()
            if payload == "[DONE]":
                return
            try:
                data = json.loads(payload)
            except json.JSONDecodeError:
                continue
            yield ChatCompletionChunk.model_validate(data)
    except httpx.RemoteProtocolError as exc:
        raise StreamError(f"Stream connection lost: {exc}") from exc
