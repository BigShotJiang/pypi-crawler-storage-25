from __future__ import annotations

import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Union

import httpx

from ._version import __version__

from .constants import (
    API_KEY_ENV_VAR,
    BASE_URL_ENV_VAR,
    DEFAULT_BASE_URL,
    DEFAULT_MAX_RETRIES,
    DEFAULT_NON_INFERENCE_TIMEOUT,
    DEFAULT_TIMEOUT,
)
from .exceptions import (
    AuthenticationError,
    ClusterError,
    InsufficientBalanceError,
    ModelNotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError,
)
from .models import (
    AccessCheck,
    ChatCompletion,
    ChatCompletionChunk,
    Dataset,
    DatasetList,
    DownloadedFile,
    DownloadResult,
    EmbeddingResponse,
    Model,
    PurchaseResult,
    UsageResponse,
    UserBalance,
)
from .streaming import parse_sse_stream


class _Completions:
    """Namespace for chat completion operations."""

    def __init__(self, client: ClusterClient) -> None:
        self._client = client

    def create(
        self,
        *,
        model: str,
        messages: List[Dict[str, str]],
        temperature: float = 1.0,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        **kwargs: Any,
    ) -> Union[ChatCompletion, Iterator[ChatCompletionChunk]]:
        """Create a chat completion.

        Args:
            model: Model ID to use.
            messages: List of message dicts with 'role' and 'content'.
            temperature: Sampling temperature (0-2).
            max_tokens: Maximum tokens to generate.
            stream: If True, return an iterator of chunks.
            **kwargs: Additional parameters passed to the API.
        """
        body: Dict[str, Any] = {"model": model, "messages": messages, "temperature": temperature, **kwargs}
        if max_tokens is not None:
            body["max_tokens"] = max_tokens
        if stream:
            body["stream"] = True
            resp = self._client._request("POST", "/v1/chat/completions", json=body, stream=True)
            if resp.status_code >= 400:
                resp.read()
                _raise_for_status(resp)
            return parse_sse_stream(resp)
        resp = self._client._request("POST", "/v1/chat/completions", json=body)
        return ChatCompletion.model_validate(resp.json())


class _Chat:
    """Namespace for chat operations."""

    def __init__(self, client: ClusterClient) -> None:
        self.completions = _Completions(client)


class _Models:
    """Namespace for model operations."""

    def __init__(self, client: ClusterClient) -> None:
        self._client = client

    def list(self) -> List[Model]:
        """List all available models."""
        resp = self._client._request("GET", "/v1/models", timeout=DEFAULT_NON_INFERENCE_TIMEOUT)
        data = resp.json()
        items = data.get("data", data) if isinstance(data, dict) else data
        return [Model.model_validate(m) for m in items]

    def retrieve(self, model_id: str) -> Model:
        """Retrieve details for a specific model."""
        resp = self._client._request("GET", f"/v1/models/{model_id}", timeout=DEFAULT_NON_INFERENCE_TIMEOUT)
        return Model.model_validate(resp.json())


class _Balance:
    """Namespace for balance operations."""

    def __init__(self, client: ClusterClient) -> None:
        self._client = client

    def get(self) -> UserBalance:
        """Get current account balance."""
        resp = self._client._request("GET", "/api/balance", timeout=DEFAULT_NON_INFERENCE_TIMEOUT)
        return UserBalance.model_validate(resp.json())


class _Usage:
    """Namespace for usage operations."""

    def __init__(self, client: ClusterClient) -> None:
        self._client = client

    def get(self) -> UsageResponse:
        """Get usage history."""
        resp = self._client._request("GET", "/api/usage", timeout=DEFAULT_NON_INFERENCE_TIMEOUT)
        return UsageResponse.model_validate(resp.json())


class _Embeddings:
    """Namespace for embedding operations."""

    def __init__(self, client: ClusterClient) -> None:
        self._client = client

    def create(
        self,
        *,
        input: Union[str, List[str]],
        model: str,
    ) -> EmbeddingResponse:
        """Create embeddings for the given input.

        Args:
            input: Text or list of texts to embed.
            model: Embedding model ID.
        """
        body: Dict[str, Any] = {"model": model, "input": input}
        resp = self._client._request("POST", "/v1/embeddings", json=body, timeout=DEFAULT_NON_INFERENCE_TIMEOUT)
        return EmbeddingResponse.model_validate(resp.json())


class _Datasets:
    """Namespace for dataset marketplace operations."""

    def __init__(self, client: ClusterClient) -> None:
        self._client = client

    def list(
        self,
        *,
        search: Optional[str] = None,
        category: Optional[str] = None,
        page: int = 1,
        limit: int = 20,
    ) -> DatasetList:
        """List datasets in the marketplace.

        Args:
            search: Free-text search query.
            category: Filter by task category.
            page: Page number (1-indexed).
            limit: Results per page (max 100).
        """
        params: Dict[str, Any] = {"page": str(page), "limit": str(limit)}
        if search:
            params["q"] = search
        if category:
            params["category"] = category
        resp = self._client._request("GET", "/api/datasets", params=params, timeout=DEFAULT_NON_INFERENCE_TIMEOUT)
        return DatasetList.model_validate(resp.json())

    def get(self, slug: str) -> Dataset:
        """Get dataset detail by slug or ID.

        Args:
            slug: Dataset slug or UUID.
        """
        resp = self._client._request("GET", f"/api/datasets/{slug}", timeout=DEFAULT_NON_INFERENCE_TIMEOUT)
        return Dataset.model_validate(resp.json())

    def purchase(
        self,
        dataset_id: str,
        *,
        tx_hash: Optional[str] = None,
        payment_method: str = "balance",
    ) -> PurchaseResult:
        """Purchase access to a dataset.

        Args:
            dataset_id: Dataset UUID.
            tx_hash: On-chain transaction hash (for crypto payments).
            payment_method: Payment method — "balance", "eth", or "token".
        """
        body: Dict[str, Any] = {"paymentMethod": payment_method}
        if tx_hash:
            body["txHash"] = tx_hash
        resp = self._client._request("POST", f"/api/datasets/{dataset_id}/purchase", json=body, timeout=DEFAULT_NON_INFERENCE_TIMEOUT)
        return PurchaseResult.model_validate(resp.json())

    def check_access(self, dataset_id: str) -> AccessCheck:
        """Check if the authenticated user has access to a dataset.

        Args:
            dataset_id: Dataset UUID.
        """
        resp = self._client._request("GET", f"/api/datasets/{dataset_id}/access", timeout=DEFAULT_NON_INFERENCE_TIMEOUT)
        return AccessCheck.model_validate(resp.json())

    def download(
        self,
        slug_or_id: str,
        output_dir: str = ".",
        *,
        progress: bool = False,
    ) -> DownloadResult:
        """Download all files for a dataset from IPFS.

        Args:
            slug_or_id: Dataset slug or UUID.
            output_dir: Directory to save files to (created if doesn't exist).
            progress: If True, print download progress per file.

        Returns:
            DownloadResult with list of downloaded file paths and metadata.
        """
        dataset = self.get(slug_or_id)
        Path(output_dir).mkdir(parents=True, exist_ok=True)

        downloaded: List[DownloadedFile] = []
        skipped: List[str] = []
        total_bytes = 0

        for f in dataset.files:
            if not f.ipfsCid:
                skipped.append(f.filename)
                continue
            out_path = str(Path(output_dir) / f.filename)
            self.download_file(
                dataset.id,
                f.ipfsCid,
                out_path,
                expected_size=f.sizeBytes,
                progress=progress,
            )
            file_size = Path(out_path).stat().st_size
            total_bytes += file_size
            downloaded.append(DownloadedFile(
                filename=f.filename,
                path=out_path,
                size_bytes=file_size,
                ipfs_cid=f.ipfsCid,
                format=f.format,
            ))
            if progress:
                print()  # newline after progress bar

        return DownloadResult(
            dataset_id=dataset.id,
            dataset_slug=dataset.slug,
            output_dir=output_dir,
            files=downloaded,
            skipped=skipped,
            total_bytes=total_bytes,
        )

    def download_file(
        self,
        dataset_id: str,
        file_cid: str,
        output_path: str,
        *,
        expected_size: Optional[int] = None,
        progress: bool = False,
    ) -> Path:
        """Download a single file by CID from IPFS.

        Args:
            dataset_id: Dataset UUID (for access control).
            file_cid: IPFS CID of the file.
            output_path: Path to write the file to.
            expected_size: Expected file size in bytes (for progress).
            progress: If True, print download progress.

        Returns:
            Path to the downloaded file.
        """
        resp = self._client._request(
            "GET",
            f"/api/datasets/{dataset_id}/ipfs-download/{file_cid}",
            stream=True,
        )
        total = int(resp.headers.get("content-length", 0)) or expected_size or 0
        filename = Path(output_path).name
        downloaded = 0
        with open(output_path, "wb") as f:
            for chunk in resp.iter_bytes(chunk_size=8192):
                f.write(chunk)
                downloaded += len(chunk)
                if progress and total > 0:
                    _print_progress(filename, downloaded, total)
        resp.close()
        return Path(output_path)


def _print_progress(filename: str, downloaded: int, total: int) -> None:
    """Print a simple progress bar to stdout."""
    pct = downloaded / total * 100
    bar_len = 30
    filled = int(bar_len * downloaded / total)
    bar = "\u2588" * filled + "\u2591" * (bar_len - filled)
    mb_done = downloaded / 1048576
    mb_total = total / 1048576
    print(f"\r  {filename}: [{bar}] {pct:.0f}% ({mb_done:.1f}/{mb_total:.1f} MB)", end="", flush=True)


class ClusterClient:
    """Synchronous client for the Cluster Protocol API.

    Args:
        api_key: API key for authentication. Falls back to CLUSTER_API_KEY env var.
        base_url: API base URL. Falls back to CLUSTER_BASE_URL env var.
        timeout: Default request timeout in seconds.
        max_retries: Maximum retry attempts on 5xx errors.

    Example::

        client = ClusterClient(api_key="sk-cluster-xxxx")
        response = client.chat.completions.create(
            model="llama-3.1-8b",
            messages=[{"role": "user", "content": "Hello!"}],
        )
        print(response.choices[0].message.content)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        self.api_key = api_key or os.environ.get(API_KEY_ENV_VAR, "")
        self.base_url = (base_url or os.environ.get(BASE_URL_ENV_VAR, DEFAULT_BASE_URL)).rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self._http = httpx.Client(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "User-Agent": f"ClusterSDK/{__version__} Python/{sys.version_info[0]}.{sys.version_info[1]}",
            },
            timeout=self.timeout,
        )
        self.chat = _Chat(self)
        self.models = _Models(self)
        self.balance = _Balance(self)
        self.usage = _Usage(self)
        self.embeddings = _Embeddings(self)
        self.datasets = _Datasets(self)

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        stream: bool = False,
        timeout: Optional[float] = None,
    ) -> httpx.Response:
        """Send an HTTP request with retry logic."""
        last_exc: Optional[Exception] = None
        resp: Optional[httpx.Response] = None
        for attempt in range(self.max_retries + 1):
            try:
                if timeout is not None:
                    extensions = {"timeout": {"connect": timeout, "read": timeout, "write": timeout, "pool": timeout}}
                else:
                    extensions = {}
                req = self._http.build_request(method, path, json=json, params=params, extensions=extensions)
                resp = self._http.send(req, stream=stream)
                _raise_for_status(resp)
                return resp
            except RateLimitError as exc:
                last_exc = exc
                if attempt < self.max_retries:
                    retry_after = _parse_retry_after(resp)
                    time.sleep(retry_after if retry_after > 0 else min(2**attempt, 8))
                    continue
                raise
            except (ServerError, httpx.TransportError) as exc:
                last_exc = exc
                if attempt < self.max_retries:
                    time.sleep(min(2**attempt, 8))
                    continue
                raise
            except httpx.TimeoutException as exc:
                raise TimeoutError(f"Request timed out: {exc}") from exc
        raise last_exc  # type: ignore[misc]

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._http.close()

    def __enter__(self) -> ClusterClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


def _raise_for_status(resp: httpx.Response) -> None:
    """Raise a typed exception based on HTTP status code."""
    if resp.status_code < 400:
        return
    try:
        body = resp.json()
    except Exception:
        body = resp.text
    msg = body.get("error", {}).get("message", str(body)) if isinstance(body, dict) else str(body)
    code = resp.status_code
    if code == 401:
        raise AuthenticationError(msg, status_code=code, body=body)
    if code == 402:
        raise InsufficientBalanceError(msg, status_code=code, body=body)
    if code == 404:
        raise ModelNotFoundError(msg, status_code=code, body=body)
    if code == 429:
        raise RateLimitError(msg, status_code=code, body=body)
    if code >= 500:
        raise ServerError(msg, status_code=code, body=body)
    raise ClusterError(msg, status_code=code, body=body)


def _parse_retry_after(resp: Optional[httpx.Response]) -> float:
    """Extract Retry-After header value in seconds. Returns 0 if absent."""
    if resp is None:
        return 0
    header = resp.headers.get("retry-after", "")
    if not header:
        return 0
    try:
        return float(header)
    except ValueError:
        return 0
