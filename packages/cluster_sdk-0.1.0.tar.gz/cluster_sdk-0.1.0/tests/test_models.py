from __future__ import annotations

from cluster_sdk.models import (
    AccessCheck,
    ChatCompletion,
    ChatCompletionChunk,
    Choice,
    Dataset,
    DatasetFile,
    DatasetList,
    Delta,
    Embedding,
    EmbeddingResponse,
    EmbeddingUsage,
    Message,
    Model,
    PurchaseResult,
    StreamChoice,
    Usage,
    UsageResponse,
    UserBalance,
)


def test_chat_completion_parsing() -> None:
    raw = {
        "id": "chatcmpl-abc123",
        "object": "chat.completion",
        "created": 1700000000,
        "model": "llama-3.1-8b",
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": "Hello!"},
                "finish_reason": "stop",
            }
        ],
        "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
    }
    comp = ChatCompletion.model_validate(raw)
    assert comp.id == "chatcmpl-abc123"
    assert comp.choices[0].message.content == "Hello!"
    assert comp.usage is not None
    assert comp.usage.total_tokens == 15


def test_chat_completion_chunk_parsing() -> None:
    raw = {
        "id": "chatcmpl-abc123",
        "object": "chat.completion.chunk",
        "created": 1700000000,
        "model": "llama-3.1-8b",
        "choices": [{"index": 0, "delta": {"content": "Hi"}, "finish_reason": None}],
    }
    chunk = ChatCompletionChunk.model_validate(raw)
    assert chunk.choices[0].delta.content == "Hi"


def test_model_parsing() -> None:
    raw = {"id": "llama-3.1-8b", "object": "model", "created": 1700000000, "owned_by": "meta"}
    model = Model.model_validate(raw)
    assert model.id == "llama-3.1-8b"
    assert model.owned_by == "meta"


def test_user_balance_defaults() -> None:
    balance = UserBalance()
    assert balance.usd == 0.0
    assert balance.total_deposited == 0.0


def test_message_optional_content() -> None:
    msg = Message(role="assistant")
    assert msg.content is None


def test_delta_optional_fields() -> None:
    delta = Delta()
    assert delta.role is None
    assert delta.content is None


def test_choice_defaults() -> None:
    choice = Choice(message=Message(role="assistant", content="test"))
    assert choice.index == 0
    assert choice.finish_reason is None


def test_stream_choice() -> None:
    sc = StreamChoice(delta=Delta(content="hello"))
    assert sc.delta.content == "hello"


def test_usage_defaults() -> None:
    usage = Usage()
    assert usage.prompt_tokens == 0


def test_embedding_parsing() -> None:
    raw = {"object": "embedding", "embedding": [0.1, 0.2, 0.3], "index": 0}
    emb = Embedding.model_validate(raw)
    assert emb.embedding == [0.1, 0.2, 0.3]
    assert emb.index == 0


def test_embedding_response_parsing() -> None:
    raw = {
        "object": "list",
        "data": [{"object": "embedding", "embedding": [0.5], "index": 0}],
        "model": "bge-large",
        "usage": {"prompt_tokens": 3, "total_tokens": 3},
    }
    resp = EmbeddingResponse.model_validate(raw)
    assert len(resp.data) == 1
    assert resp.usage is not None
    assert resp.usage.total_tokens == 3


def test_embedding_usage_defaults() -> None:
    eu = EmbeddingUsage()
    assert eu.prompt_tokens == 0


def test_dataset_parsing() -> None:
    raw = {
        "id": "d1", "name": "Test", "slug": "test", "description": "desc",
        "pricingType": "free", "tags": ["nlp"], "downloadCount": 42,
        "files": [{"id": "f1", "filename": "data.csv", "sizeBytes": 100}],
    }
    ds = Dataset.model_validate(raw)
    assert ds.slug == "test"
    assert ds.downloadCount == 42
    assert len(ds.files) == 1


def test_dataset_list_parsing() -> None:
    raw = {
        "datasets": [{"id": "d1", "name": "T", "slug": "t", "description": "d", "pricingType": "free"}],
        "pagination": {"total": 50, "page": 2, "limit": 20},
    }
    dl = DatasetList.model_validate(raw)
    assert dl.pagination.total == 50
    assert dl.pagination.page == 2


def test_purchase_result_parsing() -> None:
    raw = {"id": "p1", "datasetId": "d1", "status": "completed", "message": "ok"}
    pr = PurchaseResult.model_validate(raw)
    assert pr.status == "completed"


def test_access_check_parsing() -> None:
    raw = {"hasAccess": True, "reason": "purchased"}
    ac = AccessCheck.model_validate(raw)
    assert ac.hasAccess is True
    assert ac.reason == "purchased"


def test_dataset_file_defaults() -> None:
    df = DatasetFile()
    assert df.filename == ""
    assert df.sizeBytes is None


def test_user_balance_from_api_camelcase() -> None:
    """API returns camelCase string values — verify alias + coercion."""
    raw = {"balanceUsd": "4.99982408", "totalDeposited": "0.00000000", "totalSpent": "0.00020545"}
    balance = UserBalance.model_validate(raw)
    assert abs(balance.usd - 4.99982408) < 1e-8
    assert balance.total_deposited == 0.0
    assert abs(balance.total_spent - 0.00020545) < 1e-8


def test_user_balance_from_snake_case() -> None:
    """Backwards-compat: snake_case field names still work."""
    balance = UserBalance(usd=10.0, total_deposited=20.0, total_spent=5.0)
    assert balance.usd == 10.0


def test_usage_response_from_api() -> None:
    """API returns flat camelCase stats with string numbers."""
    raw = {
        "totalRequests": 27,
        "totalTokensIn": 338,
        "totalTokensOut": 103,
        "totalTokens": 441,
        "totalCost": "0.00020545",
        "avgCostPerRequest": "0.000007609259259259259259",
        "avgLatencyMs": 294,
    }
    usage = UsageResponse.model_validate(raw)
    assert usage.total_requests == 27
    assert usage.total_tokens == 441
    assert abs(usage.total_cost - 0.00020545) < 1e-10
    assert usage.avg_latency_ms == 294.0


def test_usage_response_defaults() -> None:
    usage = UsageResponse()
    assert usage.total_requests == 0
    assert usage.total_cost == 0.0
