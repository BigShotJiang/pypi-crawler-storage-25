from __future__ import annotations

import json
import os
from unittest.mock import patch, MagicMock

import httpx
import pytest

from cluster_sdk import ClusterClient
from cluster_sdk.exceptions import AuthenticationError, ModelNotFoundError, ServerError


@pytest.fixture
def mock_transport():
    """Create a mock httpx transport for testing."""
    return httpx.MockTransport(lambda req: httpx.Response(200, json={}))


def _make_client(**kwargs) -> ClusterClient:
    """Create a client pointing at a dummy URL."""
    return ClusterClient(api_key="sk-cluster-test", base_url="http://localhost:9999", max_retries=0, **kwargs)


class TestClientInit:
    def test_api_key_from_arg(self) -> None:
        client = _make_client()
        assert client.api_key == "sk-cluster-test"
        client.close()

    def test_api_key_from_env(self) -> None:
        with patch.dict(os.environ, {"CLUSTER_API_KEY": "sk-cluster-env"}):
            client = ClusterClient(base_url="http://localhost:9999", max_retries=0)
            assert client.api_key == "sk-cluster-env"
            client.close()

    def test_base_url_from_env(self) -> None:
        with patch.dict(os.environ, {"CLUSTER_BASE_URL": "http://custom:8080"}):
            client = ClusterClient(api_key="test", max_retries=0)
            assert client.base_url == "http://custom:8080"
            client.close()

    def test_context_manager(self) -> None:
        with _make_client() as client:
            assert client.api_key == "sk-cluster-test"

    def test_trailing_slash_stripped(self) -> None:
        client = ClusterClient(api_key="test", base_url="http://localhost:9999/", max_retries=0)
        assert client.base_url == "http://localhost:9999"
        client.close()


class TestErrorHandling:
    def test_401_raises_auth_error(self) -> None:
        transport = httpx.MockTransport(
            lambda req: httpx.Response(401, json={"error": {"message": "Invalid API key"}})
        )
        client = ClusterClient(api_key="bad", base_url="http://test", max_retries=0)
        client._http = httpx.Client(transport=transport, base_url="http://test")
        with pytest.raises(AuthenticationError, match="Invalid API key"):
            client.models.list()
        client.close()

    def test_404_raises_model_not_found(self) -> None:
        transport = httpx.MockTransport(
            lambda req: httpx.Response(404, json={"error": {"message": "Model not found"}})
        )
        client = ClusterClient(api_key="test", base_url="http://test", max_retries=0)
        client._http = httpx.Client(transport=transport, base_url="http://test")
        with pytest.raises(ModelNotFoundError):
            client.models.retrieve("nonexistent")
        client.close()

    def test_500_raises_server_error(self) -> None:
        transport = httpx.MockTransport(
            lambda req: httpx.Response(500, json={"error": {"message": "Internal error"}})
        )
        client = ClusterClient(api_key="test", base_url="http://test", max_retries=0)
        client._http = httpx.Client(transport=transport, base_url="http://test")
        with pytest.raises(ServerError):
            client.models.list()
        client.close()


class TestChatCompletions:
    def test_create_non_streaming(self) -> None:
        response_data = {
            "id": "chatcmpl-abc",
            "object": "chat.completion",
            "created": 1700000000,
            "model": "llama-3.1-8b",
            "choices": [
                {"index": 0, "message": {"role": "assistant", "content": "Hi there!"}, "finish_reason": "stop"}
            ],
            "usage": {"prompt_tokens": 5, "completion_tokens": 3, "total_tokens": 8},
        }
        transport = httpx.MockTransport(lambda req: httpx.Response(200, json=response_data))
        client = ClusterClient(api_key="test", base_url="http://test", max_retries=0)
        client._http = httpx.Client(transport=transport, base_url="http://test")
        result = client.chat.completions.create(
            model="llama-3.1-8b", messages=[{"role": "user", "content": "Hello"}]
        )
        assert result.choices[0].message.content == "Hi there!"
        assert result.usage is not None
        assert result.usage.total_tokens == 8
        client.close()


class TestModels:
    def test_list_models(self) -> None:
        response_data = {
            "data": [
                {"id": "llama-3.1-8b", "object": "model", "created": 1700000000, "owned_by": "meta"},
                {"id": "mixtral-8x7b", "object": "model", "created": 1700000000, "owned_by": "mistral"},
            ]
        }
        transport = httpx.MockTransport(lambda req: httpx.Response(200, json=response_data))
        client = ClusterClient(api_key="test", base_url="http://test", max_retries=0)
        client._http = httpx.Client(transport=transport, base_url="http://test")
        models = client.models.list()
        assert len(models) == 2
        assert models[0].id == "llama-3.1-8b"
        client.close()

    def test_retrieve_model(self) -> None:
        response_data = {"id": "llama-3.1-8b", "object": "model", "created": 1700000000, "owned_by": "meta"}
        transport = httpx.MockTransport(lambda req: httpx.Response(200, json=response_data))
        client = ClusterClient(api_key="test", base_url="http://test", max_retries=0)
        client._http = httpx.Client(transport=transport, base_url="http://test")
        model = client.models.retrieve("llama-3.1-8b")
        assert model.id == "llama-3.1-8b"
        assert model.owned_by == "meta"
        client.close()


class TestBalance:
    def test_get_balance(self) -> None:
        response_data = {"usd": 42.50, "total_deposited": 100.0, "total_spent": 57.50}
        transport = httpx.MockTransport(lambda req: httpx.Response(200, json=response_data))
        client = ClusterClient(api_key="test", base_url="http://test", max_retries=0)
        client._http = httpx.Client(transport=transport, base_url="http://test")
        balance = client.balance.get()
        assert balance.usd == 42.50
        assert balance.total_spent == 57.50
        client.close()


class TestEmbeddings:
    def test_create_embedding_single(self) -> None:
        response_data = {
            "object": "list",
            "data": [{"object": "embedding", "embedding": [0.1, 0.2, 0.3], "index": 0}],
            "model": "bge-large-en-v1.5",
            "usage": {"prompt_tokens": 7, "total_tokens": 7},
        }
        transport = httpx.MockTransport(lambda req: httpx.Response(200, json=response_data))
        client = ClusterClient(api_key="test", base_url="http://test", max_retries=0)
        client._http = httpx.Client(transport=transport, base_url="http://test")
        result = client.embeddings.create(input="hello world", model="bge-large-en-v1.5")
        assert len(result.data) == 1
        assert result.data[0].embedding == [0.1, 0.2, 0.3]
        assert result.usage is not None
        assert result.usage.total_tokens == 7
        client.close()

    def test_create_embedding_batch(self) -> None:
        response_data = {
            "object": "list",
            "data": [
                {"object": "embedding", "embedding": [0.1, 0.2], "index": 0},
                {"object": "embedding", "embedding": [0.3, 0.4], "index": 1},
            ],
            "model": "bge-large-en-v1.5",
            "usage": {"prompt_tokens": 10, "total_tokens": 10},
        }
        transport = httpx.MockTransport(lambda req: httpx.Response(200, json=response_data))
        client = ClusterClient(api_key="test", base_url="http://test", max_retries=0)
        client._http = httpx.Client(transport=transport, base_url="http://test")
        result = client.embeddings.create(input=["hello", "world"], model="bge-large-en-v1.5")
        assert len(result.data) == 2
        assert result.data[1].index == 1
        client.close()


class TestDatasets:
    def test_list_datasets(self) -> None:
        response_data = {
            "datasets": [
                {"id": "d1", "name": "Test Dataset", "slug": "test-dataset", "description": "A test", "pricingType": "free"},
            ],
            "pagination": {"total": 1, "page": 1, "limit": 20},
        }
        transport = httpx.MockTransport(lambda req: httpx.Response(200, json=response_data))
        client = ClusterClient(api_key="test", base_url="http://test", max_retries=0)
        client._http = httpx.Client(transport=transport, base_url="http://test")
        result = client.datasets.list()
        assert len(result.datasets) == 1
        assert result.datasets[0].slug == "test-dataset"
        assert result.pagination.total == 1
        client.close()

    def test_get_dataset(self) -> None:
        response_data = {
            "id": "d1", "name": "IMDB Reviews", "slug": "imdb-reviews",
            "description": "Movie reviews", "pricingType": "paid", "priceUsd": "5.00",
            "files": [{"id": "f1", "filename": "reviews.csv", "sizeBytes": 1024}],
            "creator": {"id": "u1", "username": "cluster"},
        }
        transport = httpx.MockTransport(lambda req: httpx.Response(200, json=response_data))
        client = ClusterClient(api_key="test", base_url="http://test", max_retries=0)
        client._http = httpx.Client(transport=transport, base_url="http://test")
        ds = client.datasets.get("imdb-reviews")
        assert ds.name == "IMDB Reviews"
        assert ds.priceUsd == "5.00"
        assert len(ds.files) == 1
        assert ds.creator is not None
        assert ds.creator.username == "cluster"
        client.close()

    def test_purchase_dataset(self) -> None:
        response_data = {"id": "p1", "datasetId": "d1", "status": "completed"}
        transport = httpx.MockTransport(lambda req: httpx.Response(200, json=response_data))
        client = ClusterClient(api_key="test", base_url="http://test", max_retries=0)
        client._http = httpx.Client(transport=transport, base_url="http://test")
        result = client.datasets.purchase("d1")
        assert result.status == "completed"
        assert result.datasetId == "d1"
        client.close()

    def test_check_access(self) -> None:
        response_data = {"hasAccess": True, "reason": "purchased"}
        transport = httpx.MockTransport(lambda req: httpx.Response(200, json=response_data))
        client = ClusterClient(api_key="test", base_url="http://test", max_retries=0)
        client._http = httpx.Client(transport=transport, base_url="http://test")
        result = client.datasets.check_access("d1")
        assert result.hasAccess is True
        assert result.reason == "purchased"
        client.close()


class TestUserAgent:
    def test_custom_user_agent_set(self) -> None:
        client = _make_client()
        ua = client._http.headers["user-agent"]
        assert ua.startswith("ClusterSDK/")
        assert "Python/" in ua
        client.close()


class TestBalanceCamelCase:
    def test_get_balance_camelcase_api(self) -> None:
        """Verify camelCase + string values from the real API are handled."""
        response_data = {"balanceUsd": "4.99982408", "totalDeposited": "0.00", "totalSpent": "0.00020545"}
        transport = httpx.MockTransport(lambda req: httpx.Response(200, json=response_data))
        client = ClusterClient(api_key="test", base_url="http://test", max_retries=0)
        client._http = httpx.Client(transport=transport, base_url="http://test")
        balance = client.balance.get()
        assert abs(balance.usd - 4.99982408) < 1e-8
        assert abs(balance.total_spent - 0.00020545) < 1e-8
        client.close()


class TestUsageNewShape:
    def test_get_usage_flat_stats(self) -> None:
        response_data = {
            "totalRequests": 27, "totalTokensIn": 338, "totalTokensOut": 103,
            "totalTokens": 441, "totalCost": "0.00020545",
            "avgCostPerRequest": "0.000007609", "avgLatencyMs": 294,
        }
        transport = httpx.MockTransport(lambda req: httpx.Response(200, json=response_data))
        client = ClusterClient(api_key="test", base_url="http://test", max_retries=0)
        client._http = httpx.Client(transport=transport, base_url="http://test")
        usage = client.usage.get()
        assert usage.total_requests == 27
        assert usage.total_tokens == 441
        client.close()


class TestStreamingErrorHandling:
    def test_stream_error_reads_body_before_raising(self) -> None:
        """When streaming request gets 401, body should be read and proper error raised."""
        transport = httpx.MockTransport(
            lambda req: httpx.Response(401, json={"error": {"message": "Invalid API key"}})
        )
        client = ClusterClient(api_key="bad", base_url="http://test", max_retries=0)
        client._http = httpx.Client(transport=transport, base_url="http://test")
        with pytest.raises(AuthenticationError, match="Invalid API key"):
            client.chat.completions.create(
                model="test", messages=[{"role": "user", "content": "Hi"}], stream=True
            )
        client.close()


class TestDatasetDownload:
    """Tests for dataset IPFS download functionality."""

    DATASET_RESPONSE = {
        "id": "ds-001",
        "name": "Test Dataset",
        "slug": "test-dataset",
        "description": "A test dataset",
        "pricingType": "free",
        "files": [
            {"id": "f1", "filename": "train.parquet", "ipfsCid": "QmTRAIN", "sizeBytes": 1024, "format": "parquet"},
            {"id": "f2", "filename": "test.parquet", "ipfsCid": "QmTEST", "sizeBytes": 512, "format": "parquet"},
        ],
    }

    DATASET_WITH_MISSING_CID = {
        "id": "ds-002",
        "name": "Partial Dataset",
        "slug": "partial-dataset",
        "description": "Has a file without CID",
        "pricingType": "free",
        "files": [
            {"id": "f1", "filename": "data.csv", "ipfsCid": "QmDATA", "sizeBytes": 256, "format": "csv"},
            {"id": "f2", "filename": "metadata.json", "sizeBytes": 64, "format": "json"},
        ],
    }

    def _make_download_client(self, dataset_resp: dict, file_content: bytes = b"fake binary data") -> ClusterClient:
        """Create a client that serves dataset metadata and file downloads."""
        def handler(req: httpx.Request) -> httpx.Response:
            path = req.url.path
            if path.startswith("/api/datasets/") and "/ipfs-download/" in path:
                return httpx.Response(
                    200,
                    content=file_content,
                    headers={"content-length": str(len(file_content)), "content-type": "application/octet-stream"},
                )
            if path.startswith("/api/datasets/"):
                return httpx.Response(200, json=dataset_resp)
            return httpx.Response(404, json={"error": {"message": "Not found"}})

        client = ClusterClient(api_key="test", base_url="http://test", max_retries=0)
        client._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
        return client

    def test_download_creates_directory(self, tmp_path) -> None:
        """download() creates the output directory if it doesn't exist."""
        out_dir = str(tmp_path / "nested" / "output")
        client = self._make_download_client(self.DATASET_RESPONSE)
        result = client.datasets.download("test-dataset", out_dir)
        assert (tmp_path / "nested" / "output").is_dir()
        assert len(result.files) == 2
        client.close()

    def test_download_streams_files(self, tmp_path) -> None:
        """download() writes file content correctly."""
        content = b"hello parquet world"
        client = self._make_download_client(self.DATASET_RESPONSE, file_content=content)
        result = client.datasets.download("test-dataset", str(tmp_path))
        assert len(result.files) == 2
        assert result.dataset_id == "ds-001"
        assert result.dataset_slug == "test-dataset"
        assert result.total_bytes == len(content) * 2
        for f in result.files:
            assert open(f.path, "rb").read() == content
        client.close()

    def test_download_skips_files_without_cid(self, tmp_path) -> None:
        """Files without ipfsCid are skipped and listed in result.skipped."""
        client = self._make_download_client(self.DATASET_WITH_MISSING_CID)
        result = client.datasets.download("partial-dataset", str(tmp_path))
        assert len(result.files) == 1
        assert result.files[0].filename == "data.csv"
        assert result.skipped == ["metadata.json"]
        client.close()

    def test_download_file_writes_correctly(self, tmp_path) -> None:
        """download_file() writes the exact bytes from the response."""
        content = b"\x00\x01\x02binary content\xff"
        client = self._make_download_client(self.DATASET_RESPONSE, file_content=content)
        out_path = str(tmp_path / "output.bin")
        result_path = client.datasets.download_file("ds-001", "QmTRAIN", out_path)
        assert result_path.exists()
        assert result_path.read_bytes() == content
        client.close()

    def test_download_file_returns_path(self, tmp_path) -> None:
        """download_file() returns a Path object."""
        from pathlib import Path as P
        client = self._make_download_client(self.DATASET_RESPONSE)
        out_path = str(tmp_path / "file.dat")
        result = client.datasets.download_file("ds-001", "QmTRAIN", out_path)
        assert isinstance(result, P)
        assert str(result) == out_path
        client.close()

    def test_download_result_metadata(self, tmp_path) -> None:
        """DownloadResult contains correct metadata fields."""
        client = self._make_download_client(self.DATASET_RESPONSE)
        result = client.datasets.download("test-dataset", str(tmp_path))
        assert result.output_dir == str(tmp_path)
        assert result.files[0].ipfs_cid == "QmTRAIN"
        assert result.files[0].format == "parquet"
        assert result.files[1].ipfs_cid == "QmTEST"
        client.close()


class TestRetryAfter:
    def test_429_with_retry_after_header(self) -> None:
        """Verify that a 429 with max_retries=0 raises RateLimitError."""
        from cluster_sdk.exceptions import RateLimitError

        transport = httpx.MockTransport(
            lambda req: httpx.Response(
                429,
                json={"error": {"message": "too many requests"}},
                headers={"retry-after": "1"},
            )
        )
        client = ClusterClient(api_key="test", base_url="http://test", max_retries=0)
        client._http = httpx.Client(transport=transport, base_url="http://test")
        with pytest.raises(RateLimitError, match="too many requests"):
            client.models.list()
        client.close()
