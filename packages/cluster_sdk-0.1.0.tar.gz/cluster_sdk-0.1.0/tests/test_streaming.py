from __future__ import annotations

import json
from typing import Iterator
from unittest.mock import MagicMock

from cluster_sdk.streaming import parse_sse_stream
from cluster_sdk.models import ChatCompletionChunk


def _make_mock_response(lines: list[str]) -> MagicMock:
    """Create a mock httpx.Response that yields lines from iter_lines."""
    resp = MagicMock()
    resp.iter_lines.return_value = iter(lines)
    return resp


def test_parse_single_chunk() -> None:
    chunk_data = {
        "id": "chatcmpl-1",
        "object": "chat.completion.chunk",
        "created": 1700000000,
        "model": "llama-3.1-8b",
        "choices": [{"index": 0, "delta": {"content": "Hello"}, "finish_reason": None}],
    }
    lines = [f"data: {json.dumps(chunk_data)}", "", "data: [DONE]"]
    resp = _make_mock_response(lines)
    chunks = list(parse_sse_stream(resp))
    assert len(chunks) == 1
    assert chunks[0].choices[0].delta.content == "Hello"


def test_parse_multiple_chunks() -> None:
    lines = []
    for i, word in enumerate(["Hello", " world", "!"]):
        chunk = {
            "id": "chatcmpl-1",
            "object": "chat.completion.chunk",
            "created": 1700000000,
            "model": "test",
            "choices": [{"index": 0, "delta": {"content": word}, "finish_reason": None}],
        }
        lines.append(f"data: {json.dumps(chunk)}")
        lines.append("")
    lines.append("data: [DONE]")
    resp = _make_mock_response(lines)
    chunks = list(parse_sse_stream(resp))
    assert len(chunks) == 3
    assert "".join(c.choices[0].delta.content or "" for c in chunks) == "Hello world!"


def test_parse_skips_empty_and_comments() -> None:
    chunk_data = {
        "id": "chatcmpl-1",
        "object": "chat.completion.chunk",
        "created": 1700000000,
        "model": "test",
        "choices": [{"index": 0, "delta": {"content": "ok"}, "finish_reason": None}],
    }
    lines = ["", ": comment", "event: message", f"data: {json.dumps(chunk_data)}", "data: [DONE]"]
    resp = _make_mock_response(lines)
    chunks = list(parse_sse_stream(resp))
    assert len(chunks) == 1


def test_parse_handles_malformed_json() -> None:
    lines = ["data: {invalid json", "data: [DONE]"]
    resp = _make_mock_response(lines)
    chunks = list(parse_sse_stream(resp))
    assert len(chunks) == 0


def test_parse_stops_at_done() -> None:
    chunk = {
        "id": "chatcmpl-1",
        "object": "chat.completion.chunk",
        "created": 1700000000,
        "model": "test",
        "choices": [{"index": 0, "delta": {"content": "a"}, "finish_reason": None}],
    }
    lines = [f"data: {json.dumps(chunk)}", "data: [DONE]", f"data: {json.dumps(chunk)}"]
    resp = _make_mock_response(lines)
    chunks = list(parse_sse_stream(resp))
    assert len(chunks) == 1
