"""Integration-style tests for the Cluster SDK.

All HTTP calls are mocked — no running server required.
"""
from __future__ import annotations

import json

import httpx
import pytest

from cluster_sdk import ClusterClient
from cluster_sdk.exceptions import AuthenticationError, RateLimitError


def _client_with(handler) -> ClusterClient:
    transport = httpx.MockTransport(handler)
    c = ClusterClient(api_key="sk-test", base_url="http://test", max_retries=0)
    c._http = httpx.Client(transport=transport, base_url="http://test")
    return c


class TestRegisterFlow:
    def test_register_returns_api_key(self) -> None:
        data = {"userId": "u1", "email": "a@b.com", "apiKey": "cp_new", "balance": "5.00"}
        transport = httpx.MockTransport(lambda r: httpx.Response(201, json=data))
        resp = httpx.Client(transport=transport, base_url="http://test").post(
            "/api/auth/register", json={"email": "a@b.com", "password": "secure123"}
        )
        assert resp.status_code == 201
        assert resp.json()["apiKey"] == "cp_new"


class TestListModels:
    def test_list_returns_models(self) -> None:
        data = {"data": [{"id": "llama-3.1-8b", "object": "model", "created": 0, "owned_by": "meta"}]}
        client = _client_with(lambda r: httpx.Response(200, json=data))
        models = client.models.list()
        assert len(models) == 1
        assert models[0].id == "llama-3.1-8b"
        client.close()

    def test_retrieve_single_model(self) -> None:
        data = {"id": "mixtral-8x7b", "object": "model", "created": 0, "owned_by": "mistral"}
        client = _client_with(lambda r: httpx.Response(200, json=data))
        m = client.models.retrieve("mixtral-8x7b")
        assert m.id == "mixtral-8x7b"
        client.close()


class TestChatCompletion:
    def test_non_streaming_completion(self) -> None:
        data = {
            "id": "cmpl-1", "object": "chat.completion", "created": 1, "model": "llama-3.1-8b",
            "choices": [{"index": 0, "message": {"role": "assistant", "content": "Hello!"}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 4, "completion_tokens": 2, "total_tokens": 6},
        }
        client = _client_with(lambda r: httpx.Response(200, json=data))
        result = client.chat.completions.create(model="llama-3.1-8b", messages=[{"role": "user", "content": "Hi"}])
        assert result.choices[0].message.content == "Hello!"
        client.close()

    def test_streaming_completion(self) -> None:
        chunks = [
            'data: {"id":"c1","object":"chat.completion.chunk","created":1,"model":"m","choices":[{"index":0,"delta":{"role":"assistant","content":"Hi"},"finish_reason":null}]}\n\n',
            "data: [DONE]\n\n",
        ]
        def handler(req: httpx.Request) -> httpx.Response:
            return httpx.Response(200, content="".join(chunks).encode(), headers={"content-type": "text/event-stream"})
        client = _client_with(handler)
        stream = client.chat.completions.create(
            model="m", messages=[{"role": "user", "content": "Hi"}], stream=True
        )
        items = list(stream)
        assert len(items) == 1
        assert items[0].choices[0].delta.content == "Hi"
        client.close()


class TestErrorHandling:
    def test_invalid_api_key_raises_auth_error(self) -> None:
        client = _client_with(lambda r: httpx.Response(401, json={"error": {"message": "bad key"}}))
        with pytest.raises(AuthenticationError, match="bad key"):
            client.models.list()
        client.close()

    def test_rate_limit_raises_rate_limit_error(self) -> None:
        client = _client_with(lambda r: httpx.Response(429, json={"error": {"message": "too many"}}))
        with pytest.raises(RateLimitError, match="too many"):
            client.models.list()
        client.close()
