from .funcs import *
__version__="1.1.1"
AUTHOR="HZY"