"""Tests for cli/server.py — DashboardHandler and serve_dashboard."""
import http.client
import json
import socket
import threading
from unittest.mock import MagicMock, patch

import pytest


# ── Fixtures ──────────────────────────────────────────────────────────────────

TEST_HTML = b"<html><body>dashboard</body></html>"
TEST_PORT = 18765


@pytest.fixture
def mock_config():
    return {
        "paths": {"gml_file": "test.gml"},
        "query": {"max_depth": None},
    }


@pytest.fixture
def live_server(mock_config):
    """Start a DashboardHandler server in a daemon thread; yield it; shut down."""
    from http.server import HTTPServer
    from cli.server import DashboardHandler

    DashboardHandler.html_bytes = TEST_HTML
    DashboardHandler.gis = MagicMock()
    DashboardHandler.config = mock_config

    srv = HTTPServer(("localhost", TEST_PORT), DashboardHandler)
    t = threading.Thread(target=srv.serve_forever)
    t.daemon = True
    t.start()
    yield srv
    srv.shutdown()


def _get(path, port=TEST_PORT):
    conn = http.client.HTTPConnection("localhost", port, timeout=5)
    conn.request("GET", path)
    resp = conn.getresponse()
    body = resp.read()
    conn.close()
    return resp.status, body


# ── Tests ─────────────────────────────────────────────────────────────────────

def test_handler_get_root_returns_html(live_server):
    """GET / must return 200 with the HTML bytes."""
    status, body = _get("/")
    assert status == 200
    assert body == TEST_HTML


def test_handler_get_query_valid_item(live_server, mock_config):
    """GET /query?id=abc must return 200 JSON with nodes/edges/meta."""
    from unittest.mock import patch, MagicMock
    from arcgis_item_graph.query import QueryResult

    mock_result = MagicMock(spec=QueryResult)
    mock_result.nodes = [MagicMock()]  # non-empty

    mock_data = {"nodes": [], "edges": [], "meta": {"queried_ids": ["abc"]}}

    with patch("arcgis_item_graph.ItemGraphQuery") as MockQ, \
         patch("arcgis_item_graph.visualizer.ItemGraphVisualizer") as MockV:
        MockQ.return_value.query.return_value = mock_result
        MockV.return_value.serialize.return_value = mock_data

        status, body = _get("/query?id=abc")

    assert status == 200
    data = json.loads(body)
    assert "nodes" in data
    assert "meta" in data


def test_handler_get_query_unknown_item(live_server, mock_config):
    """GET /query?id=unknown must return 404 JSON with an error key."""
    from unittest.mock import patch, MagicMock
    from arcgis_item_graph.query import QueryResult

    mock_result = MagicMock(spec=QueryResult)
    mock_result.nodes = []  # empty → not found

    with patch("arcgis_item_graph.ItemGraphQuery") as MockQ:
        MockQ.return_value.query.return_value = mock_result
        status, body = _get("/query?id=doesnotexist")

    assert status == 404
    data = json.loads(body)
    assert "error" in data


def test_serve_dashboard_advances_port_on_conflict(mock_config, capsys):
    """serve_dashboard() tries the next port automatically when preferred is in use."""
    from cli.server import serve_dashboard
    with patch("cli.server.HTTPServer") as MockHTTP, \
         patch("cli.server.webbrowser.open") as mock_browser:
        instance = MagicMock()
        instance.serve_forever.return_value = None
        # First call raises (port busy); second call succeeds
        MockHTTP.side_effect = [OSError("Address already in use"), instance]
        serve_dashboard(
            html_bytes=TEST_HTML, gis=MagicMock(), config=mock_config, port=9100,
        )
    # HTTPServer must have been attempted twice and the server actually started
    assert MockHTTP.call_count == 2
    assert instance.serve_forever.called
    # Browser must have been opened (server did start)
    assert mock_browser.called
    assert "9101" in mock_browser.call_args[0][0]  # opened on the advanced port
    captured = capsys.readouterr()
    assert "9100" in captured.out  # mentioned the skipped port


def test_serve_dashboard_all_ports_exhausted(mock_config, capsys):
    """serve_dashboard() prints an error and returns when the full port range is busy."""
    from cli.server import serve_dashboard
    with patch("cli.server.HTTPServer") as MockHTTP, \
         patch("cli.server.webbrowser.open") as mock_browser:
        MockHTTP.side_effect = OSError("Address already in use")
        serve_dashboard(
            html_bytes=TEST_HTML, gis=MagicMock(), config=mock_config, port=9200,
        )
    # Browser must NOT have been opened — no server started
    assert not mock_browser.called
    # HTTPServer must have been tried more than once (exhausted the range)
    assert MockHTTP.call_count > 1
    captured = capsys.readouterr()
    assert "Cannot start" in captured.out or "no free port" in captured.out.lower()


def test_handler_get_unknown_path(live_server):
    """GET /nonexistent must return 404."""
    status, body = _get("/nonexistent")
    assert status == 404


def test_handler_export_excel_valid(live_server, mock_config):
    """GET /export/excel?ids=abc must return 200 with xlsx content-type."""
    from unittest.mock import patch, MagicMock
    from arcgis_item_graph.query import QueryResult

    mock_result = MagicMock(spec=QueryResult)
    mock_result.nodes = [MagicMock()]  # non-empty

    fake_xlsx = b"PK\x03\x04fake-xlsx-bytes"

    with patch("arcgis_item_graph.ItemGraphQuery") as MockQ, \
         patch("arcgis_item_graph.reporter.ItemGraphReporter") as MockR:
        MockQ.return_value.query.return_value = mock_result
        MockR.return_value.to_excel_bytes.return_value = fake_xlsx

        status, body = _get("/export/excel?ids=abc")

    assert status == 200
    assert body == fake_xlsx


def test_handler_export_excel_missing_ids(live_server):
    """GET /export/excel with no ids param must return 400."""
    status, body = _get("/export/excel")
    assert status == 400
    assert "error" in json.loads(body)


def test_handler_export_excel_not_found(live_server):
    """GET /export/excel?ids=missing returns 404 when query yields no nodes."""
    from unittest.mock import patch, MagicMock
    from arcgis_item_graph.query import QueryResult

    mock_result = MagicMock(spec=QueryResult)
    mock_result.nodes = []  # empty → not found

    with patch("arcgis_item_graph.ItemGraphQuery") as MockQ:
        MockQ.return_value.query.return_value = mock_result
        status, body = _get("/export/excel?ids=doesnotexist")

    assert status == 404
    assert "error" in json.loads(body)
