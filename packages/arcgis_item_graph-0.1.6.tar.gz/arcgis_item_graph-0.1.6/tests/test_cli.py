"""tests/test_cli.py — Unit tests for the CLI entry point."""
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch, mock_open

import pytest
import yaml

from tests.conftest import make_config


# ── load_config ───────────────────────────────────────────────────────────────

class TestLoadConfig:
    def test_returns_dict_for_valid_yaml(self, tmp_path):
        from cli.main import load_config
        cfg_file = tmp_path / "config.yaml"
        cfg_file.write_text("auth:\n  profile: test\n")
        result = load_config(cfg_file)
        assert result == {"auth": {"profile": "test"}}

    def test_exits_with_message_when_file_missing(self, tmp_path, capsys):
        from cli.main import load_config
        with pytest.raises(SystemExit) as exc:
            load_config(tmp_path / "nonexistent.yaml")
        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "config.example.yaml" in captured.out

    def test_exits_when_yaml_is_not_a_mapping(self, tmp_path, capsys):
        from cli.main import load_config
        cfg_file = tmp_path / "config.yaml"
        cfg_file.write_text("- item1\n- item2\n")
        with pytest.raises(SystemExit) as exc:
            load_config(cfg_file)
        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "list" in captured.out

    def test_default_config_is_relative_string(self):
        """DEFAULT_CONFIG must be a plain relative path, not tied to the package location."""
        from cli.main import DEFAULT_CONFIG
        from pathlib import Path
        # Must be relative so it resolves to the user's CWD, not site-packages
        assert not Path(DEFAULT_CONFIG).is_absolute(), (
            f"DEFAULT_CONFIG must be relative, got: {DEFAULT_CONFIG}"
        )
        assert str(DEFAULT_CONFIG) == "config/config.yaml"


# ── validate_config ───────────────────────────────────────────────────────────

class TestValidateConfig:
    def test_passes_for_valid_config(self):
        from cli.main import validate_config
        config = make_config()
        validate_config(config, Path("config/config.yaml"))  # must not raise or exit

    def test_exits_when_required_section_missing(self, capsys):
        from cli.main import validate_config
        config = make_config()
        del config["paths"]
        with pytest.raises(SystemExit) as exc:
            validate_config(config, Path("config/config.yaml"))
        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "paths" in captured.out

    def test_exits_when_required_sub_key_missing(self, capsys):
        from cli.main import validate_config
        config = make_config()
        del config["paths"]["gml_file"]
        with pytest.raises(SystemExit) as exc:
            validate_config(config, Path("config/config.yaml"))
        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "paths.gml_file" in captured.out

    def test_exits_when_section_value_is_null(self, capsys):
        from cli.main import validate_config
        config = make_config()
        config["paths"] = None  # bare `paths:` in YAML produces None
        with pytest.raises(SystemExit) as exc:
            validate_config(config, Path("config/config.yaml"))
        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "paths." in captured.out  # e.g. "paths.gml_file"

    def test_exits_when_output_formats_is_scalar(self, capsys):
        from cli.main import validate_config
        config = make_config()
        config["query"]["output_formats"] = "csv"  # scalar, not YAML list
        with pytest.raises(SystemExit) as exc:
            validate_config(config, Path("config/config.yaml"))
        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "output_formats" in captured.out


# ── resolve_gis ───────────────────────────────────────────────────────────────

class TestResolveGis:
    def test_uses_profile_when_set(self):
        from cli.main import resolve_gis
        args = MagicMock(profile="psa_profile", url=None, user=None, password=None)
        config = make_config(**{"auth": {"profile": "psa_profile", "verify_cert": False}})
        with patch("cli.main.GIS") as mock_gis:
            resolve_gis(config, args)
            mock_gis.assert_called_once_with(profile="psa_profile", verify_cert=False)

    def test_uses_env_vars_when_no_profile(self, monkeypatch):
        from cli.main import resolve_gis
        monkeypatch.setenv("ARCGIS_URL", "https://test.arcgis.com")
        monkeypatch.setenv("ARCGIS_USER", "admin")
        monkeypatch.setenv("ARCGIS_PASSWORD", "secret")
        args = MagicMock(profile=None, url=None, user=None, password=None)
        config = make_config(**{"auth": {"profile": "", "verify_cert": False}})
        with patch("cli.main.GIS") as mock_gis:
            resolve_gis(config, args)
            mock_gis.assert_called_once_with(
                url="https://test.arcgis.com",
                username="admin",
                password="secret",
                verify_cert=False,
            )

    def test_cli_flags_override_config_profile(self):
        from cli.main import resolve_gis
        args = MagicMock(profile="override_profile", url=None, user=None, password=None)
        config = make_config(**{"auth": {"profile": "config_profile", "verify_cert": False}})
        with patch("cli.main.GIS") as mock_gis:
            resolve_gis(config, args)
            mock_gis.assert_called_once_with(profile="override_profile", verify_cert=False)

    def test_exits_with_message_when_no_auth(self, monkeypatch, capsys):
        from cli.main import resolve_gis
        monkeypatch.delenv("ARCGIS_URL", raising=False)
        monkeypatch.delenv("ARCGIS_USER", raising=False)
        monkeypatch.delenv("ARCGIS_PASSWORD", raising=False)
        args = MagicMock(profile=None, url=None, user=None, password=None)
        config = make_config(**{"auth": {"profile": "", "verify_cert": False}})
        with pytest.raises(SystemExit) as exc:
            resolve_gis(config, args)
        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "ARCGIS_URL" in captured.out

    def test_prints_warning_when_password_flag_used(self, caplog):
        import logging
        from cli.main import resolve_gis
        args = MagicMock(
            profile=None, url="https://test.arcgis.com",
            user="admin", password="secret123"
        )
        config = make_config(**{"auth": {"profile": "", "verify_cert": False}})
        with patch("cli.main.GIS"), caplog.at_level(logging.WARNING):
            resolve_gis(config, args)
        assert "shell history" in caplog.text


# ── cmd_create ────────────────────────────────────────────────────────────────

class TestCmdCreate:
    def test_calls_creator_with_config_values(self, tmp_path):
        from cli.main import cmd_create
        args = MagicMock(
            profile="prof", url=None, user=None, password=None,
            gml_file=None, timestamp_file=None, max_items=None,
        )
        config = make_config()
        config["paths"]["gml_file"] = str(tmp_path / "graph.gml")
        config["paths"]["timestamp_file"] = str(tmp_path / "graph.timestamp")

        mock_gis = MagicMock()
        mock_gis.users.me.username = "testuser"
        gml_file = tmp_path / "graph.gml"
        gml_file.touch()  # simulate creator writing the file so archive copy succeeds
        mock_result = {"success": True, "items_indexed": 42, "gml_file": str(gml_file)}

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphCreator") as MockCreator:
            MockCreator.return_value.create.return_value = mock_result
            cmd_create(args, config)
            MockCreator.assert_called_once()
            MockCreator.return_value.create.assert_called_once()

    def test_exits_on_creator_failure(self, tmp_path, capsys):
        from cli.main import cmd_create
        args = MagicMock(
            profile="prof", url=None, user=None, password=None,
            gml_file=None, timestamp_file=None, max_items=None,
        )
        config = make_config()
        config["paths"]["gml_file"] = str(tmp_path / "graph.gml")
        config["paths"]["timestamp_file"] = str(tmp_path / "graph.timestamp")

        mock_gis = MagicMock()
        mock_gis.users.me.username = "testuser"

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphCreator") as MockCreator:
            MockCreator.return_value.create.return_value = {"success": False, "error": "timeout"}
            with pytest.raises(SystemExit) as exc:
                cmd_create(args, config)
            assert exc.value.code == 1


# ── cmd_update ────────────────────────────────────────────────────────────────

class TestCmdUpdate:
    def test_calls_updater_with_config_values(self, tmp_path):
        from cli.main import cmd_update
        gml = tmp_path / "graph.gml"
        gml.write_text("")  # file must exist for updater
        args = MagicMock(
            profile="prof", url=None, user=None, password=None,
            gml_file=str(gml), timestamp_file=None,
            max_retries=None, retry_delay=None, skip_if_fresh=False,
        )
        config = make_config()
        config["paths"]["timestamp_file"] = str(tmp_path / "ts.txt")

        mock_gis = MagicMock()
        mock_gis.users.me.username = "testuser"

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphUpdater") as MockUpdater:
            MockUpdater.return_value.update.return_value = {"duration": 1.5}
            cmd_update(args, config)
            MockUpdater.assert_called_once()
            MockUpdater.return_value.update.assert_called_once()

    def test_helpful_message_when_no_gml(self, tmp_path, capsys):
        from cli.main import cmd_update
        args = MagicMock(
            profile="prof", url=None, user=None, password=None,
            gml_file=str(tmp_path / "missing.gml"),
            timestamp_file=None, max_retries=None, retry_delay=None,
            skip_if_fresh=False,
        )
        config = make_config()
        config["paths"]["timestamp_file"] = str(tmp_path / "ts.txt")
        mock_gis = MagicMock()
        mock_gis.users.me.username = "testuser"

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphUpdater") as MockUpdater:
            MockUpdater.return_value.update.side_effect = FileNotFoundError
            with pytest.raises(SystemExit) as exc:
                cmd_update(args, config)
            assert exc.value.code == 1
            captured = capsys.readouterr()
            assert "create" in captured.out.lower()


# ── cmd_query ─────────────────────────────────────────────────────────────────

class TestCmdQuery:
    def _base_args(self, **kw):
        defaults = dict(
            profile="prof", url=None, user=None, password=None,
            gml_file=None, output_dir=None, format=None,
            item_id=None, search=None,
            serve=False, port=8765,
        )
        defaults.update(kw)
        return MagicMock(**defaults)

    def test_query_by_item_id(self, tmp_path):
        from cli.main import cmd_query
        args = self._base_args(item_id="abc123")
        config = make_config()
        config["paths"]["output_dir"] = str(tmp_path)
        config["paths"]["gml_file"] = "outputs/graph.gml"

        import pandas as pd
        mock_gis = MagicMock()
        mock_gis.users.me.username = "testuser"
        mock_result = MagicMock()
        mock_result.nodes = ["n1", "n2"]
        mock_result.to_dataframe.return_value = pd.DataFrame([{
            "item_id": "abc123",
            "title": "Test Item",
            "type": "Web Map",
            "owner": "admin",
            "contains_count": 2,
            "required_by_count": 1,
            "queried_item": True,
        }])

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphQuery") as MockQuery:
            MockQuery.return_value.query.return_value = mock_result
            cmd_query(args, config)
            MockQuery.return_value.query.assert_called_once_with(ids=["abc123"])

    def test_query_by_search(self, tmp_path):
        from cli.main import cmd_query
        args = self._base_args(search="owner:jsmith type:Dashboard")
        config = make_config()
        config["paths"]["output_dir"] = str(tmp_path)

        import pandas as pd
        mock_gis = MagicMock()
        mock_gis.users.me.username = "testuser"
        mock_result = MagicMock()
        mock_result.nodes = ["n1"]
        mock_result.to_dataframe.return_value = pd.DataFrame([{
            "item_id": "xyz789",
            "title": "Dashboard",
            "type": "Dashboard",
            "owner": "jsmith",
            "contains_count": 3,
            "required_by_count": 0,
            "queried_item": True,
        }])

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphQuery") as MockQuery:
            MockQuery.return_value.query.return_value = mock_result
            cmd_query(args, config)
            MockQuery.return_value.query.assert_called_once_with(
                search="owner:jsmith type:Dashboard"
            )

    def test_exits_when_no_item_id_or_search(self, capsys):
        from cli.main import cmd_query
        args = self._base_args()  # no item_id, no search
        config = make_config()
        mock_gis = MagicMock()
        with patch("cli.main.resolve_gis", return_value=mock_gis):
            with pytest.raises(SystemExit) as exc:
                cmd_query(args, config)
            assert exc.value.code == 1

    def test_query_excel_format(self, tmp_path):
        from cli.main import cmd_query
        args = self._base_args(item_id="abc123")
        config = make_config()
        config["paths"]["output_dir"] = str(tmp_path)
        config["query"]["output_formats"] = ["excel"]

        import pandas as pd
        mock_gis = MagicMock()
        mock_gis.users.me.username = "testuser"
        mock_result = MagicMock()
        mock_result.nodes = ["n1"]
        mock_result.to_dataframe.return_value = pd.DataFrame([{
            "item_id": "abc123", "title": "Item", "type": "Web Map",
            "owner": "admin", "status": "healthy",
            "contains_count": 0, "required_by_count": 0, "queried_item": True,
        }])

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphQuery") as MockQuery, \
             patch("arcgis_item_graph.reporter.ItemGraphReporter") as MockReporter:
            MockQuery.return_value.query.return_value = mock_result
            cmd_query(args, config)
            MockReporter.assert_called_once_with(mock_result)
            xlsx_path = MockReporter.return_value.to_excel.call_args[0][0]
            assert xlsx_path.endswith(".xlsx")

    def test_exits_when_both_item_id_and_search_provided(self, capsys):
        from cli.main import build_parser
        parser = build_parser()
        with pytest.raises(SystemExit) as exc:
            parser.parse_args(["query", "--item-id", "abc123", "--search", "owner:jsmith"])
        assert exc.value.code == 2   # argparse exits with 2 for usage errors
        captured = capsys.readouterr()
        assert "--item-id" in captured.err or "--search" in captured.err

    def test_query_serve_flag_parsed(self):
        """--serve and --port must appear in the parsed namespace."""
        from cli.main import build_parser
        parser = build_parser()
        args = parser.parse_args([
            "query", "--item-id", "abc123", "--serve", "--port", "9000"
        ])
        assert args.serve is True
        assert args.port == 9000

    def test_query_serve_defaults_false(self):
        """--serve must default to False when not supplied."""
        from cli.main import build_parser
        parser = build_parser()
        args = parser.parse_args(["query", "--item-id", "abc123"])
        assert args.serve is False
        assert args.port == 8765


# ── cmd_setup ─────────────────────────────────────────────────────────────────

class TestCmdSetup:
    """Tests for the interactive config-creation wizard."""

    def _run_setup(self, monkeypatch, tmp_path, inputs, getpass_return="secret"):
        """Helper: cd to tmp_path, mock input/getpass, run cmd_setup."""
        import argparse
        from cli.main import DEFAULT_CONFIG, cmd_setup
        monkeypatch.chdir(tmp_path)
        input_iter = iter(inputs)
        monkeypatch.setattr("builtins.input", lambda _prompt: next(input_iter))
        monkeypatch.setattr("getpass.getpass", lambda _prompt: getpass_return)
        args = argparse.Namespace(config=str(DEFAULT_CONFIG))
        cmd_setup(args)

    def test_creates_config_with_named_profile(self, monkeypatch, tmp_path):
        self._run_setup(monkeypatch, tmp_path, inputs=[
            "https://myorg.maps.arcgis.com",  # portal URL
            "1",                               # auth: named profile
            "my_profile",                      # profile name
            "",                                # verify_cert (default Y)
            "",                                # output_dir (default outputs)
        ])
        config_path = tmp_path / "config" / "config.yaml"
        assert config_path.exists()
        cfg = yaml.safe_load(config_path.read_text())
        assert cfg["auth"]["profile"] == "my_profile"
        assert cfg["auth"]["verify_cert"] is True
        assert cfg["paths"]["output_dir"] == "outputs"
        assert not (tmp_path / ".env").exists()

    def test_creates_env_file_for_username_password(self, monkeypatch, tmp_path):
        self._run_setup(monkeypatch, tmp_path, inputs=[
            "https://myorg.maps.arcgis.com",  # portal URL
            "2",                               # auth: username/password
            "admin",                           # username
            "",                                # verify_cert
            "",                                # output_dir
        ], getpass_return="p@ssw0rd")
        env_content = (tmp_path / ".env").read_text()
        assert "ARCGIS_URL=https://myorg.maps.arcgis.com" in env_content
        assert "ARCGIS_USER=admin" in env_content
        assert "ARCGIS_PASSWORD=p@ssw0rd" in env_content
        cfg = yaml.safe_load((tmp_path / "config" / "config.yaml").read_text())
        assert cfg["auth"]["profile"] == ""

    def test_aborts_when_user_declines_overwrite(self, monkeypatch, tmp_path, capsys):
        (tmp_path / "config").mkdir()
        config_path = tmp_path / "config" / "config.yaml"
        config_path.write_text("original: true\n")
        import argparse
        from cli.main import cmd_setup
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr("builtins.input", lambda _: "n")
        cmd_setup(argparse.Namespace(config=str(config_path)))
        assert config_path.read_text() == "original: true\n"
        assert "cancelled" in capsys.readouterr().out.lower()

    def test_overwrites_config_when_confirmed(self, monkeypatch, tmp_path):
        (tmp_path / "config").mkdir()
        config_path = tmp_path / "config" / "config.yaml"
        config_path.write_text("original: true\n")
        self._run_setup(monkeypatch, tmp_path, inputs=[
            "y",                               # confirm overwrite
            "https://myorg.maps.arcgis.com",
            "1",
            "new_profile",
            "",
            "",
        ])
        cfg = yaml.safe_load(config_path.read_text())
        assert cfg["auth"]["profile"] == "new_profile"

    def test_uses_defaults_on_blank_input(self, monkeypatch, tmp_path):
        self._run_setup(monkeypatch, tmp_path, inputs=[
            "",   # portal URL → default https://www.arcgis.com
            "1",  # auth: named profile
            "p",  # profile name
            "",   # verify_cert → default Y → True
            "",   # output_dir → default outputs
        ])
        cfg = yaml.safe_load((tmp_path / "config" / "config.yaml").read_text())
        assert cfg["paths"]["gml_file"] == "outputs/graph.gml"
        assert cfg["auth"]["verify_cert"] is True
        assert cfg["paths"]["output_dir"] == "outputs"

    def test_config_passes_validate_config(self, monkeypatch, tmp_path):
        """Config written by setup wizard must pass validate_config without exits."""
        from cli.main import validate_config
        self._run_setup(monkeypatch, tmp_path, inputs=[
            "https://myorg.maps.arcgis.com",
            "1",
            "some_profile",
            "",
            "",
        ])
        cfg = yaml.safe_load((tmp_path / "config" / "config.yaml").read_text())
        # Should not raise SystemExit
        validate_config(cfg, tmp_path / "config" / "config.yaml")


# ── setup subcommand wiring ────────────────────────────────────────────────────

class TestSetupSubcommand:
    def test_setup_registered_in_parser(self):
        from cli.main import build_parser
        parser = build_parser()
        args = parser.parse_args(["setup"])
        assert args.command == "setup"

    def test_setup_has_no_required_flags(self):
        """setup must parse successfully with no flags beyond the subcommand name."""
        from cli.main import build_parser
        parser = build_parser()
        # Should not raise
        args = parser.parse_args(["setup"])
        assert args.command == "setup"

    def test_main_calls_cmd_setup_without_loading_config(self, monkeypatch, tmp_path):
        """main() must call cmd_setup and return before load_config when command=setup."""
        from cli import main as cli_main
        monkeypatch.setattr("sys.argv", ["arcgis-graph", "setup"])
        setup_called = []
        monkeypatch.setattr(cli_main, "cmd_setup", lambda args: setup_called.append(True))
        monkeypatch.setattr(cli_main, "load_config", lambda p: (_ for _ in ()).throw(
            AssertionError("load_config must not be called during setup")
        ))
        cli_main.main()
        assert setup_called == [True]


# ── load_dotenv path derivation ────────────────────────────────────────────────

class TestLoadDotenvPath:
    """Verify load_dotenv is called with the correct absolute path and override=True."""

    def test_dotenv_loaded_from_config_parent_with_override(self, monkeypatch, tmp_path):
        """main() must derive .env path from config location, not CWD."""
        from cli import main as cli_main
        config_dir = tmp_path / "config"
        config_dir.mkdir()
        config_file = config_dir / "config.yaml"
        config_file.write_text(
            "auth:\n  profile: ''\n  verify_cert: true\n"
            "paths:\n  gml_file: outputs/graph.gml\n"
            "  timestamp_file: outputs/graph.timestamp\n"
            "  output_dir: outputs\n"
            "create:\n  max_items: 10000\n"
            "update:\n  max_retries: 5\n  retry_delay: 5.0\n"
            "query:\n  max_depth: null\n  output_formats:\n    - excel\n"
        )
        dotenv_calls = []
        monkeypatch.setattr("sys.argv", ["arcgis-graph", "--config", str(config_file), "setup"])
        monkeypatch.setattr(cli_main, "load_dotenv", lambda **kwargs: dotenv_calls.append(kwargs))
        monkeypatch.setattr(cli_main, "cmd_setup", lambda args: None)

        cli_main.main()

        assert len(dotenv_calls) == 1
        assert dotenv_calls[0]["dotenv_path"] == tmp_path / ".env"
        assert dotenv_calls[0].get("override") is True


# ── _safe_title ────────────────────────────────────────────────────────────────

class TestSafeTitle:
    def test_basic_title(self):
        from cli.main import _safe_title
        assert _safe_title("My Web Map") == "My_Web_Map"

    def test_windows_illegal_chars(self):
        from cli.main import _safe_title
        assert _safe_title('Report: FY2026/Q1 "final"') == "Report_FY2026_Q1_final"

    def test_collapses_runs_of_underscores(self):
        from cli.main import _safe_title
        assert _safe_title("A  B   C") == "A_B_C"

    def test_truncates_to_40_chars(self):
        from cli.main import _safe_title
        long_title = "A" * 50
        result = _safe_title(long_title)
        assert len(result) == 40

    def test_backslash_and_colon(self):
        from cli.main import _safe_title
        assert _safe_title("Server\\Share:Data") == "Server_Share_Data"


# ── Run-log helpers ────────────────────────────────────────────────────────────

import json
from datetime import datetime, timedelta



class TestCheckPathWritable:
    def test_writable_path_succeeds(self, tmp_path):
        """_check_path_writable passes silently for a valid writable directory."""
        from cli.main import _check_path_writable
        # Should not raise or exit
        _check_path_writable(tmp_path / "subdir" / "graph.gml", "GML file")

    def test_unwritable_path_exits(self, tmp_path):
        """_check_path_writable calls sys.exit(1) when write is denied."""
        from cli.main import _check_path_writable
        from unittest.mock import patch
        with patch("pathlib.Path.write_text", side_effect=PermissionError("denied")):
            with pytest.raises(SystemExit) as exc:
                _check_path_writable(tmp_path / "graph.gml", "GML file")
        assert exc.value.code == 1

    def test_readback_mismatch_exits(self, tmp_path):
        """_check_path_writable exits when read-back content doesn't match."""
        from cli.main import _check_path_writable
        from unittest.mock import patch
        with patch("pathlib.Path.read_text", return_value="wrong-content"):
            with pytest.raises(SystemExit) as exc:
                _check_path_writable(tmp_path / "graph.gml", "GML file")
        assert exc.value.code == 1

    def test_no_sentinel_left_behind(self, tmp_path):
        """_check_path_writable cleans up the sentinel file on success."""
        from cli.main import _check_path_writable
        _check_path_writable(tmp_path / "graph.gml", "GML file")
        leftover = list(tmp_path.glob(".arcgis_graph_write_check*"))
        assert leftover == [], f"Sentinel not cleaned up: {leftover}"

    def test_resolved_path_printed(self, tmp_path, capsys):
        """_check_path_writable prints the resolved absolute path for diagnostics."""
        from cli.main import _check_path_writable
        _check_path_writable(tmp_path / "graph.gml", "GML file")
        out = capsys.readouterr().out
        assert str(tmp_path.resolve()) in out


class TestRunLog:
    def test_run_log_path_explicit(self, tmp_path):
        from cli.main import _run_log_path
        cfg = make_config(**{"paths": {"run_log": str(tmp_path / "custom.json")}})
        assert _run_log_path(cfg) == Path(str(tmp_path / "custom.json"))

    def test_run_log_path_derived(self, tmp_path):
        from cli.main import _run_log_path
        cfg = make_config(**{"paths": {"gml_file": str(tmp_path / "graph.gml")}})
        assert _run_log_path(cfg) == tmp_path / "graph_run_log.json"

    def test_read_run_log_missing_returns_none(self, tmp_path):
        from cli.main import _read_run_log
        assert _read_run_log(tmp_path / "nonexistent.json") is None

    def test_read_run_log_corrupt_returns_none(self, tmp_path):
        from cli.main import _read_run_log
        p = tmp_path / "run_log.json"
        p.write_text("not json{{", encoding="utf-8")
        assert _read_run_log(p) is None

    def test_read_run_log_valid(self, tmp_path):
        from cli.main import _read_run_log
        data = {"last_update": "2026-04-14T11:00:00"}
        p = tmp_path / "run_log.json"
        p.write_text(json.dumps(data), encoding="utf-8")
        assert _read_run_log(p) == data

    def test_write_run_log_creates_file(self, tmp_path):
        from cli.main import _write_run_log
        data = {"last_create": "2026-04-14T08:00:00", "last_update": "2026-04-14T11:00:00"}
        p = tmp_path / "run_log.json"
        _write_run_log(p, data)
        assert p.exists()
        assert json.loads(p.read_text()) == data

    def test_write_run_log_atomic_no_tmp_left(self, tmp_path):
        from cli.main import _write_run_log
        p = tmp_path / "run_log.json"
        _write_run_log(p, {"x": 1})
        assert not (tmp_path / "run_log.tmp.json").exists()

    def test_write_run_log_unc_fallback(self, tmp_path):
        """_write_run_log falls back to direct write when os.replace raises PermissionError.

        Reproduces WinError 5 on Windows UNC network shares.
        """
        from unittest.mock import patch
        from cli.main import _write_run_log

        data = {"last_create": "2026-04-15T10:00:00"}
        p = tmp_path / "run_log.json"

        with patch("cli.main.os.replace", side_effect=PermissionError("WinError 5")):
            _write_run_log(p, data)

        assert p.exists()
        assert json.loads(p.read_text()) == data
        assert not (tmp_path / "run_log.tmp.json").exists()


# ── cmd_create writes run-log ──────────────────────────────────────────────────

class TestCreateWritesRunLog:
    def test_create_writes_run_log(self, tmp_path, mock_gis):
        from unittest.mock import patch, MagicMock
        from cli.main import cmd_create, _read_run_log
        import argparse

        gml = tmp_path / "graph.gml"
        gml.touch()
        log_path = tmp_path / "graph_run_log.json"
        cfg = make_config(**{
            "paths": {
                "gml_file": str(gml),
                "timestamp_file": str(tmp_path / "graph.timestamp"),
                "output_dir": str(tmp_path),
            }
        })
        args = argparse.Namespace(
            gml_file=None, timestamp_file=None, max_items=None, profile=None
        )
        mock_result = {"success": True, "items_indexed": 500, "gml_file": str(gml)}

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphCreator") as MockCreator:
            MockCreator.return_value.create.return_value = mock_result
            cmd_create(args, cfg)

        log = _read_run_log(log_path)
        assert log is not None
        assert log["create_items_indexed"] == 500
        assert log["last_create"] == log["last_update"]  # create sets both equal
        assert log["update_stats"] is None


class TestLocalFirst:
    """Tests for arcgis-graph create --local-first."""

    def _run(self, tmp_path, mock_gis, local_dir, share_ok=True):
        """Helper: run cmd_create --local-first with mocked creator and share paths."""
        from unittest.mock import patch, MagicMock
        from cli.main import cmd_create, _read_run_log
        import argparse

        share_gml = tmp_path / "share" / "graph.gml"
        share_ts  = tmp_path / "share" / "graph.timestamp"
        share_log = tmp_path / "share" / "graph_run_log.json"

        cfg = make_config(**{
            "paths": {
                "gml_file":       str(share_gml),
                "timestamp_file": str(share_ts),
                "run_log":        str(share_log),
                "output_dir":     str(tmp_path / "share"),
            }
        })

        mock_creator = MagicMock()
        mock_creator.return_value.create.return_value = {
            "success": True,
            "items_indexed": 42,
            "gml_file": str(local_dir / "graph.gml"),
            "timestamp_file": str(local_dir / "graph.timestamp"),
        }
        # Create a real local gml so shutil.copy2 has something to copy
        (local_dir / "graph.gml").parent.mkdir(parents=True, exist_ok=True)
        (local_dir / "graph.gml").write_text("graph []", encoding="utf-8")
        (local_dir / "graph.timestamp").write_text("1234567890", encoding="utf-8")

        args = argparse.Namespace(
            gml_file=None, timestamp_file=None, max_items=None,
            local_first=True, profile=None,
        )

        if share_ok:
            (tmp_path / "share").mkdir(parents=True, exist_ok=True)

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphCreator", mock_creator), \
             patch("cli.main._local_staging_dir", return_value=local_dir):
            cmd_create(args, cfg)

        return share_gml, share_log

    def test_local_first_writes_locally(self, tmp_path, mock_gis):
        """--local-first writes GML to the local staging dir."""
        local_dir = tmp_path / "local"
        self._run(tmp_path, mock_gis, local_dir)
        assert (local_dir / "graph.gml").exists()

    def test_local_first_copies_to_share(self, tmp_path, mock_gis):
        """--local-first copies GML to the configured share path on success."""
        local_dir = tmp_path / "local"
        share_gml, _ = self._run(tmp_path, mock_gis, local_dir)
        assert share_gml.exists()

    def test_local_first_writes_run_log_on_share_success(self, tmp_path, mock_gis):
        """--local-first writes run log to share when copy succeeds."""
        from cli.main import _read_run_log
        local_dir = tmp_path / "local"
        _, share_log = self._run(tmp_path, mock_gis, local_dir)
        log = _read_run_log(share_log)
        assert log is not None
        assert log["create_items_indexed"] == 42

    def test_local_first_share_fail_preserves_local(self, tmp_path, mock_gis, capsys):
        """--local-first keeps local files and warns when share copy fails."""
        from unittest.mock import patch, MagicMock
        from cli.main import cmd_create
        import argparse, shutil

        # Capture the real copy2 BEFORE the patch replaces it
        _real_copy2 = shutil.copy2

        local_dir = tmp_path / "local"
        share_dir = tmp_path / "share"

        cfg = make_config(**{
            "paths": {
                "gml_file":       str(share_dir / "graph.gml"),
                "timestamp_file": str(share_dir / "graph.timestamp"),
                "run_log":        str(share_dir / "run_log.json"),
                "output_dir":     str(share_dir),
            }
        })
        (local_dir / "graph.gml").parent.mkdir(parents=True, exist_ok=True)
        (local_dir / "graph.gml").write_text("graph []", encoding="utf-8")
        (local_dir / "graph.timestamp").write_text("123", encoding="utf-8")

        mock_creator = MagicMock()
        mock_creator.return_value.create.return_value = {
            "success": True, "items_indexed": 10,
            "gml_file": str(local_dir / "graph.gml"),
            "timestamp_file": str(local_dir / "graph.timestamp"),
        }
        args = argparse.Namespace(
            gml_file=None, timestamp_file=None, max_items=None,
            local_first=True, profile=None,
        )

        def selective_copy(src, dst):
            if str(share_dir) in str(dst):
                raise OSError("share unavailable")
            _real_copy2(src, dst)

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphCreator", mock_creator), \
             patch("cli.main._local_staging_dir", return_value=local_dir), \
             patch("cli.main.shutil.copy2", side_effect=selective_copy):
            cmd_create(args, cfg)

        out = capsys.readouterr().out
        assert "⚠" in out
        assert str(local_dir) in out
        assert (local_dir / "graph.gml").exists()

    def test_local_staging_dir_returns_documents_path(self):
        """_local_staging_dir() returns ~/Documents/arcgis-graph."""
        from pathlib import Path
        from cli.main import _local_staging_dir
        expected = Path.home() / "Documents" / "arcgis-graph"
        assert _local_staging_dir() == expected


# ── cmd_update run-log + --skip-if-fresh ───────────────────────────────────────

class TestUpdateRunLog:
    def test_update_writes_run_log(self, tmp_path, mock_gis):
        from unittest.mock import patch
        from cli.main import cmd_update, _read_run_log, _write_run_log
        import argparse, json

        gml = tmp_path / "graph.gml"
        gml.touch()
        log_path = tmp_path / "graph_run_log.json"
        # Pre-seed run log with a create entry
        _write_run_log(log_path, {
            "last_create": "2026-04-14T08:00:00",
            "last_update": "2026-04-14T08:00:00",
            "create_items_indexed": 500,
            "update_stats": None,
        })
        cfg = make_config(**{
            "paths": {
                "gml_file": str(gml),
                "timestamp_file": str(tmp_path / "graph.timestamp"),
                "output_dir": str(tmp_path),
            }
        })
        args = argparse.Namespace(
            gml_file=None, timestamp_file=None, max_retries=None,
            retry_delay=None, profile=None, skip_if_fresh=False
        )
        mock_stats = {"duration": 1.5, "added": 3, "modified": 2, "removed": 0}

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphUpdater") as MockUpdater:
            MockUpdater.return_value.update.return_value = mock_stats
            cmd_update(args, cfg)

        log = _read_run_log(log_path)
        assert log["last_create"] == "2026-04-14T08:00:00"  # preserved
        assert log["update_stats"] == {"added": 3, "modified": 2, "removed": 0}
        assert log["last_update"] != "2026-04-14T08:00:00"  # updated

    def test_update_skip_if_fresh(self, tmp_path, mock_gis, capsys):
        from unittest.mock import patch
        from cli.main import cmd_update, _write_run_log
        import argparse
        from datetime import datetime, timedelta

        gml = tmp_path / "graph.gml"
        gml.touch()
        log_path = tmp_path / "graph_run_log.json"
        recent = (datetime.now() - timedelta(minutes=10)).isoformat(timespec="seconds")
        _write_run_log(log_path, {
            "last_create": recent,
            "last_update": recent,
            "create_items_indexed": 500,
            "update_stats": None,
        })
        cfg = make_config(**{
            "paths": {
                "gml_file": str(gml),
                "timestamp_file": str(tmp_path / "graph.timestamp"),
                "output_dir": str(tmp_path),
            }
        })
        args = argparse.Namespace(
            gml_file=None, timestamp_file=None, max_retries=None,
            retry_delay=None, profile=None, skip_if_fresh=True
        )

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphUpdater") as MockUpdater:
            cmd_update(args, cfg)
            MockUpdater.return_value.update.assert_not_called()

        out = capsys.readouterr().out
        assert "skipping" in out.lower()


# ── cmd_query staleness warning ────────────────────────────────────────────────

class TestQueryStalenessWarning:
    def _run_query(self, tmp_path, mock_gis, run_log_data, capsys, extra_cfg=None):
        """Helper: run cmd_query with a mocked run_log and return captured output."""
        from unittest.mock import patch, MagicMock
        from cli.main import cmd_query, _write_run_log
        import argparse

        gml = tmp_path / "graph.gml"
        gml.touch()
        if run_log_data is not None:
            _write_run_log(tmp_path / "graph_run_log.json", run_log_data)

        cfg = make_config(**{
            "paths": {
                "gml_file": str(gml),
                "timestamp_file": str(tmp_path / "graph.timestamp"),
                "output_dir": str(tmp_path),
            }
        })
        if extra_cfg:
            for k, v in extra_cfg.items():
                cfg[k] = v

        args = argparse.Namespace(
            item_id="abc123", search=None, gml_file=None, output_dir=None,
            format=None, profile=None, force_refresh=False,
            serve=False,
        )
        mock_result = MagicMock()
        mock_result.nodes = []
        mock_result.to_dataframe.return_value = __import__("pandas").DataFrame()

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphQuery") as MockQ:
            MockQ.return_value.query.return_value = mock_result
            cmd_query(args, cfg)

        return capsys.readouterr().out

    def test_staleness_warning_when_stale(self, tmp_path, mock_gis, capsys):
        from datetime import datetime, timedelta
        old = (datetime.now() - timedelta(hours=3)).isoformat(timespec="seconds")
        log = {"last_create": old, "last_update": old, "create_items_indexed": 100, "update_stats": None}
        out = self._run_query(tmp_path, mock_gis, log, capsys)
        assert "⚠" in out
        assert "arcgis-graph update" in out

    def test_no_warning_when_fresh(self, tmp_path, mock_gis, capsys):
        from datetime import datetime, timedelta
        recent = (datetime.now() - timedelta(minutes=10)).isoformat(timespec="seconds")
        log = {"last_create": recent, "last_update": recent, "create_items_indexed": 100, "update_stats": None}
        out = self._run_query(tmp_path, mock_gis, log, capsys)
        assert "⚠" not in out

    def test_no_run_log_graceful(self, tmp_path, mock_gis, capsys):
        out = self._run_query(tmp_path, mock_gis, None, capsys)
        assert "run_log.json not found" in out
        assert "staleness check skipped" in out


# ── cmd_query cache lookup + --force-refresh ───────────────────────────────────

class TestQueryCache:
    def _make_cache_folder(self, base: Path, item_id: str, title: str,
                           age_hours: float, formats: list = None) -> Path:
        """Create a fake cache folder with the required output files."""
        from datetime import datetime, timedelta
        from cli.main import _safe_title
        formats = formats or ["csv", "html", "gml"]  # matches make_config() defaults
        safe = _safe_title(title)
        item_dir = base / "reports" / "query" / f"{safe}_{item_id}"
        ts = (datetime.now() - timedelta(hours=age_hours)).strftime("%Y%m%d_%H%M%S")
        run_dir = item_dir / ts
        run_dir.mkdir(parents=True, exist_ok=True)
        file_map = {
            "excel": "dependency_report.xlsx",
            "html": "dependency_graph.html",
            "gml": "query_subgraph.gml",
            "csv": "dependency_report.csv",
        }
        for fmt in formats:
            (run_dir / file_map[fmt]).write_text("fake", encoding="utf-8")
        return run_dir

    def _run_query_with_cache(self, tmp_path, mock_gis, capsys,
                               force_refresh=False, extra_cfg=None):
        from unittest.mock import patch, MagicMock
        from cli.main import cmd_query
        import argparse

        gml = tmp_path / "graph.gml"
        gml.touch()
        cfg = make_config(**{
            "paths": {
                "gml_file": str(gml),
                "timestamp_file": str(tmp_path / "graph.timestamp"),
                "output_dir": str(tmp_path),
            },
            "cache": {"update_warn_hours": 1, "query_cache_hours": 24},
        })
        if extra_cfg:
            cfg.update(extra_cfg)

        args = argparse.Namespace(
            item_id="abc123", search=None, gml_file=None, output_dir=None,
            format=None, profile=None, force_refresh=force_refresh,
            serve=False,
        )
        mock_result = MagicMock()
        mock_result.nodes = []
        mock_result.to_dataframe.return_value = __import__("pandas").DataFrame()

        with patch("cli.main.resolve_gis", return_value=mock_gis), \
             patch("cli.main.ItemGraphQuery") as MockQ, \
             patch("cli.main._read_run_log", return_value=None):  # skip staleness
            MockQ.return_value.query.return_value = mock_result
            cmd_query(args, cfg)
            query_was_called = MockQ.return_value.query.called

        return capsys.readouterr().out, query_was_called

    def test_uses_fresh_cache(self, tmp_path, mock_gis, capsys):
        self._make_cache_folder(tmp_path, "abc123", "My Map", age_hours=2.0)
        out, query_called = self._run_query_with_cache(tmp_path, mock_gis, capsys)
        assert "Using cached result" in out
        assert "2h" in out or "1h" in out  # age displayed
        assert not query_called

    def test_ignores_stale_cache(self, tmp_path, mock_gis, capsys):
        self._make_cache_folder(tmp_path, "abc123", "My Map", age_hours=30.0)
        out, query_called = self._run_query_with_cache(tmp_path, mock_gis, capsys)
        assert "Using cached result" not in out
        assert query_called

    def test_force_refresh_bypasses_cache(self, tmp_path, mock_gis, capsys):
        self._make_cache_folder(tmp_path, "abc123", "My Map", age_hours=1.0)
        out, query_called = self._run_query_with_cache(
            tmp_path, mock_gis, capsys, force_refresh=True
        )
        assert "Using cached result" not in out
        assert query_called

    def test_no_cache_folder_runs_query(self, tmp_path, mock_gis, capsys):
        out, query_called = self._run_query_with_cache(tmp_path, mock_gis, capsys)
        assert query_called

    def test_incomplete_cache_ignored(self, tmp_path, mock_gis, capsys):
        # Create cache folder missing the html file (html is in ["csv", "html", "gml"] defaults)
        self._make_cache_folder(tmp_path, "abc123", "My Map", age_hours=1.0,
                                 formats=["csv", "gml"])  # missing html
        out, query_called = self._run_query_with_cache(tmp_path, mock_gis, capsys)
        # html is in default formats, so cache is incomplete → re-run
        assert query_called
