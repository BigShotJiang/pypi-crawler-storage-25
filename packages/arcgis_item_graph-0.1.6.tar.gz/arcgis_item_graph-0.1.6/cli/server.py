"""
cli/server.py — Lightweight HTTP server for the --serve dashboard mode.

Starts a local HTTP server that serves the generated HTML dashboard and
exposes a /query endpoint for live item re-queries from the browser.
"""
import json
import logging
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from arcgis.gis import GIS

logger = logging.getLogger(__name__)


class DashboardHandler(BaseHTTPRequestHandler):
    """HTTP request handler for the live dependency graph dashboard.

    Class-level attributes are set by serve_dashboard() before the server starts.
    They are read-only during request handling (thread-safe).
    """

    html_bytes: bytes = b""
    gis = None
    config: dict = {}

    def log_message(self, format, *args):  # noqa: A002
        """Route request logs to Python logger instead of stdout."""
        logger.debug("HTTP %s", format % args)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/":
            self._serve_html()
        elif parsed.path == "/query":
            params = parse_qs(parsed.query)
            item_id = (params.get("id") or [None])[0]
            self._serve_query(item_id)
        elif parsed.path == "/export/excel":
            params = parse_qs(parsed.query)
            ids_str = (params.get("ids") or [None])[0]
            self._serve_excel(ids_str)
        else:
            self._send_json(404, {"error": f"Not found: {self.path}"})

    def _serve_html(self) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(self.html_bytes)))
        self.end_headers()
        self.wfile.write(self.html_bytes)

    def _serve_query(self, item_id: str | None) -> None:
        if not item_id:
            self._send_json(400, {"error": "Missing id parameter"})
            return
        try:
            from arcgis_item_graph import ItemGraphQuery
            from arcgis_item_graph.visualizer import ItemGraphVisualizer
            gml_file = self.config["paths"]["gml_file"]
            max_depth = self.config["query"].get("max_depth")
            q = ItemGraphQuery(gis=self.gis, gml_file=gml_file, max_depth=max_depth)
            result = q.query(ids=[item_id])
            if not result.nodes:
                self._send_json(404, {"error": f"Item not found: {item_id}"})
                return
            data = ItemGraphVisualizer(result).serialize()
            self._send_json(200, data)
        except Exception as e:
            logger.warning("Re-query failed for %s: %s", item_id, e)
            self._send_json(500, {"error": str(e)})

    def _serve_excel(self, ids_str: str | None) -> None:
        """Serve a dependency_report.xlsx for the given comma-separated item IDs."""
        if not ids_str:
            self._send_json(400, {"error": "Missing ids parameter"})
            return
        ids = [i.strip() for i in ids_str.split(",") if i.strip()]
        if not ids:
            self._send_json(400, {"error": "No valid IDs provided"})
            return
        try:
            from arcgis_item_graph import ItemGraphQuery
            from arcgis_item_graph.reporter import ItemGraphReporter
            gml_file = self.config["paths"]["gml_file"]
            max_depth = self.config["query"].get("max_depth")
            q = ItemGraphQuery(gis=self.gis, gml_file=gml_file, max_depth=max_depth)
            result = q.query(ids=ids)
            if not result.nodes:
                self._send_json(404, {"error": f"No items found for IDs: {ids}"})
                return
            xlsx_bytes = ItemGraphReporter(result).to_excel_bytes()
            self.send_response(200)
            self.send_header(
                "Content-Type",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
            self.send_header(
                "Content-Disposition",
                'attachment; filename="dependency_report.xlsx"',
            )
            self.send_header("Content-Length", str(len(xlsx_bytes)))
            self.end_headers()
            self.wfile.write(xlsx_bytes)
        except Exception as e:
            logger.warning("Excel export failed for %s: %s", ids, e)
            self._send_json(500, {"error": str(e)})

    def _send_json(self, status: int, data: dict) -> None:
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def serve_dashboard(
    html_bytes: bytes,
    gis,
    config: dict,
    port: int = 8765,
    max_port_attempts: int = 10,
) -> None:
    """Start a local HTTP server serving the dashboard and re-query endpoint.

    Tries up to *max_port_attempts* consecutive ports starting from *port*,
    advancing automatically if a port is already in use. Blocks until Ctrl+C.
    Opens the browser automatically.

    Args:
        html_bytes:        The rendered HTML file contents to serve at GET /.
        gis:               Authenticated GIS connection for live re-queries.
        config:            Loaded config dict (needs paths.gml_file, query.max_depth).
        port:              First port to try (default 8765).
        max_port_attempts: How many consecutive ports to attempt before giving up.
    """
    DashboardHandler.html_bytes = html_bytes
    DashboardHandler.gis = gis
    DashboardHandler.config = config

    server = None
    actual_port = port
    for attempt in range(max_port_attempts):
        try:
            server = HTTPServer(("localhost", actual_port), DashboardHandler)
            break
        except OSError:
            next_port = actual_port + 1
            if attempt < max_port_attempts - 1:
                print(f"  ⚠ Port {actual_port} in use — trying {next_port}…")
                actual_port = next_port
            else:
                print(f"✗ Cannot start server: no free port found in range {port}–{actual_port}.")
                print(f"  Try a different starting port with --port.")
                return

    url = f"http://localhost:{actual_port}/"
    if actual_port != port:
        print(f"  (started on port {actual_port} — port {port} was in use)")
    print(f"\n✓ Dashboard served at {url}")
    print("  Press Ctrl+C to stop.\n")
    webbrowser.open(url)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.server_close()
