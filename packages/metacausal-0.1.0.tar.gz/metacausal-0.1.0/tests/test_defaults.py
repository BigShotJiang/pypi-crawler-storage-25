"""Tests for ``default_methods()``.

The smoke test that actually fits every default component on Lalonde is
marked ``slow`` because the stochtree BCF sampler adds noticeable
wall-clock time. Run with ``pytest -m slow`` to opt in, or
``pytest -m ''`` to run everything.
"""

from __future__ import annotations

import pytest

from metacausal import CausalEnsemble
from metacausal.datasets import load_lalonde
from metacausal.defaults import default_methods


def test_default_library_has_ten_components_spanning_four_frameworks():
    """Enumeration check: no fitting, just construction and name verification."""
    methods = default_methods()
    assert len(methods) == 10

    ens = CausalEnsemble(methods=methods)
    names = set(ens.method_names)

    expected = {
        # DoubleML
        "DoubleMLIRM", "DoubleMLPLR",
        # EconML
        "CausalForestDML", "DRLearner",
        "SLearner", "TLearner", "XLearner",
        # CausalML
        "BaseRRegressor", "TMLELearner",
        # stochtree
        "BCF",
    }
    assert names == expected, f"missing={expected - names}, unexpected={names - expected}"


@pytest.mark.slow
def test_default_ensemble_fits_on_lalonde():
    """Every default component fits on Lalonde and produces a finite ATE."""
    X, T, Y = load_lalonde()

    ens = CausalEnsemble()
    ens.fit(X, T, Y, random_state=42)

    result = ens.ate()

    # Ensemble ATE is finite
    assert result.ate == result.ate  # not NaN
    assert abs(result.ate) < 1e6  # not inf-ish

    # All ten components produced a finite ATE
    assert len(result.component_estimates) == 10
    for name, est in result.component_estimates.items():
        assert est.ate == est.ate, f"{name} returned NaN"
