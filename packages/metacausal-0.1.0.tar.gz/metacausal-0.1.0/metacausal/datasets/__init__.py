"""Built-in datasets for MetaCausal."""

from __future__ import annotations

import importlib.resources

import numpy as np
import pandas as pd


def load_lalonde(
    raw: bool = False,
) -> pd.DataFrame | tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Load the Lalonde job training dataset.

    The dataset contains 445 observations with a binary treatment indicator
    (job training program) and a continuous outcome (earnings in 1978).

    Parameters:
        raw: If True, return a DataFrame. If False (default), return
            ``(X, T, Y)`` numpy arrays.

    Returns:
        If ``raw=False``: tuple of (X, T, Y) where
            - X: covariate matrix, shape (n, 10)
            - T: binary treatment vector, shape (n,)
            - Y: continuous outcome vector, shape (n,)
        If ``raw=True``: DataFrame with all columns.
    """
    pkg = importlib.resources.files("metacausal.datasets")
    path = pkg.joinpath("lalonde.csv")
    df = pd.read_csv(path.open("r"))

    if raw:
        return df

    T = df["treat"].to_numpy(dtype=int)
    Y = df["re78"].to_numpy(dtype=float)
    X = df.drop(columns=["treat", "re78"]).to_numpy(dtype=float)

    return X, T, Y
