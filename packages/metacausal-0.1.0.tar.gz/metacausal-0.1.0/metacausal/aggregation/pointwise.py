"""Pointwise aggregation strategies: Median, Mean, and TrimmedMean."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from metacausal.aggregation.base import PointwiseStrategy


@dataclass
class Median(PointwiseStrategy):
    """Pointwise median aggregation.

    Default aggregation strategy. 50% breakdown point: the ensemble is
    unaffected by up to half the component models producing wildly wrong
    estimates.
    """

    def aggregate_cate(self, cate_matrix: np.ndarray) -> np.ndarray:
        return np.median(cate_matrix, axis=0)

    def aggregate_ate_scalars(self, component_ates: np.ndarray) -> float:
        return float(np.median(component_ates))


@dataclass
class Mean(PointwiseStrategy):
    """Pointwise mean aggregation."""

    def aggregate_cate(self, cate_matrix: np.ndarray) -> np.ndarray:
        return np.mean(cate_matrix, axis=0)

    def aggregate_ate_scalars(self, component_ates: np.ndarray) -> float:
        return float(np.mean(component_ates))


@dataclass
class TrimmedMean(PointwiseStrategy):
    """Pointwise trimmed-mean aggregation.

    Drops the ``trim_count`` highest and lowest component estimates at each
    point, then averages the remainder. A tunable middle ground between
    :class:`Mean` (no trimming) and :class:`Median` (maximal trimming).

    Parameters
    ----------
    trim_count : int
        Number of models to drop from each tail. Default 1.
        Must satisfy ``2 * trim_count < K`` where K is the number of
        component models.
    """

    trim_count: int = 1

    def _check(self, k: int) -> None:
        if 2 * self.trim_count >= k:
            raise ValueError(
                f"trim_count={self.trim_count} leaves no models after trimming "
                f"(K={k}). Reduce trim_count or add more component estimators."
            )

    def aggregate_cate(self, cate_matrix: np.ndarray) -> np.ndarray:
        k = cate_matrix.shape[0]
        self._check(k)
        sorted_matrix = np.sort(cate_matrix, axis=0)
        return sorted_matrix[self.trim_count : k - self.trim_count].mean(axis=0)

    def aggregate_ate_scalars(self, component_ates: np.ndarray) -> float:
        k = len(component_ates)
        self._check(k)
        sorted_ates = np.sort(component_ates)
        return float(sorted_ates[self.trim_count : k - self.trim_count].mean())


# Maps string aliases to strategy classes. Values are classes, not instances —
# CausalEnsemble.__init__ calls them as constructors to get fresh instances.
_STRING_FACTORIES: dict[str, type[PointwiseStrategy]] = {
    "median": Median,
    "mean": Mean,
    "trimmed_mean": TrimmedMean,
}
