"""AggregationStrategy protocol, PointwiseStrategy, AgreementStrategy, and SupervisedStrategy."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, ClassVar

import numpy as np

from metacausal.aggregation.splitting import CrossFitSplit, TrainAvgSplit
from metacausal.aggregation.weights import EnsembleWeights


try:
    from typing import runtime_checkable, Protocol
except ImportError:
    from typing_extensions import runtime_checkable, Protocol  # type: ignore[assignment]


@runtime_checkable
class AggregationStrategy(Protocol):
    """Base protocol for all aggregation strategies.

    All concrete strategy families (PointwiseStrategy, AgreementStrategy,
    SupervisedStrategy) satisfy this protocol structurally (duck typing).
    This protocol exists for type-hinting and documentation; runtime
    dispatch should use isinstance() checks against the concrete base
    classes (PointwiseStrategy, AgreementStrategy, etc.).
    """

    def aggregate_cate(self, cate_matrix: np.ndarray) -> np.ndarray:
        """Aggregate component CATE vectors into an ensemble CATE.

        Parameters
        ----------
        cate_matrix : array of shape (K, n)
            Component CATE predictions, one row per model.

        Returns
        -------
        Array of shape (n,) — the aggregated CATE.
        """
        ...

    @property
    def ensemble_weights(self) -> EnsembleWeights | None:
        """Ensemble weights, if applicable. None for pointwise strategies."""
        ...


@dataclass
class PointwiseStrategy:
    """Base class for strategies that apply a fixed statistical rule pointwise.

    Subclasses must implement aggregate_cate() and aggregate_ate_scalars().
    Pointwise strategies are stateless: no weights are computed at fit time.
    """

    strategy_family: ClassVar[str] = "pointwise"

    @property
    def ensemble_weights(self) -> None:
        return None

    def aggregate_cate(self, cate_matrix: np.ndarray) -> np.ndarray:
        """Aggregate component CATEs pointwise across models.

        Parameters
        ----------
        cate_matrix : array of shape (K, n)

        Returns
        -------
        Array of shape (n,).
        """
        raise NotImplementedError(
            f"{type(self).__name__} must implement aggregate_cate()"
        )

    def aggregate_ate_scalars(self, component_ates: np.ndarray) -> float:
        """Aggregate scalar component ATEs.

        Parameters
        ----------
        component_ates : array of shape (K,)

        Returns
        -------
        Scalar ensemble ATE.
        """
        raise NotImplementedError(
            f"{type(self).__name__} must implement aggregate_ate_scalars()"
        )


@dataclass
class AgreementStrategy:
    """Base class for strategies that select/weight models by inter-model agreement.

    Weights are computed at fit time from training-data CATE predictions
    (no outcome data involved). Subclasses implement compute_weights().

    ATE is computed as the mean of the ensemble CATE, not by aggregating
    scalar component ATEs. For bootstrap replicates, weights are recomputed
    from resampled training-data CATE predictions.
    """

    strategy_family: ClassVar[str] = "agreement"

    _weights: EnsembleWeights | None = field(default=None, init=False, repr=False)

    def compute_weights(
        self,
        cate_matrix: np.ndarray,
        model_names: list[str],
    ) -> EnsembleWeights:
        """Compute weights from inter-model agreement on training predictions.

        Called once during fit(), after component models are fitted on full
        training data. Subclasses implement this.

        Parameters
        ----------
        cate_matrix : array of shape (K, n)
            Training-data CATE predictions, one row per model.
        model_names : list[str]
            Adapter names in the same order as rows of cate_matrix.

        Returns
        -------
        EnsembleWeights populated with this strategy's weights.
        """
        raise NotImplementedError(
            f"{type(self).__name__} must implement compute_weights()"
        )

    def aggregate_cate(self, cate_matrix: np.ndarray) -> np.ndarray:
        """Aggregate component CATEs using stored weights.

        Parameters
        ----------
        cate_matrix : array of shape (K, n)

        Returns
        -------
        Array of shape (n,).
        """
        w = self._weights
        return w.intercept + w.weights @ cate_matrix

    @property
    def ensemble_weights(self) -> EnsembleWeights | None:
        """Ensemble weights computed during fit(). None before fit()."""
        return self._weights


@dataclass
class SupervisedStrategy:
    """Base class for outcome-supervised aggregation strategies.

    Weights are learned by optimizing a causal loss on outcome data, using
    out-of-fold CATE predictions and nuisance model estimates. Subclasses
    implement fit_weights().

    ATE is computed as the mean of the ensemble CATE (same as AgreementStrategy).
    ATE-only adapters (supports_cate=False) are excluded from both CATE and ATE
    computation when this strategy is active.

    Parameters
    ----------
    split : CrossFitSplit or TrainAvgSplit
        Data splitting strategy for cross-fitting. Default: 5-fold cross-fitting.
    propensity_model : sklearn classifier or None
        Model for P(T=1|X). Default: HistGradientBoostingClassifier (from defaults.py).
    outcome_model : sklearn regressor or None
        Model for E[Y|X,T]. Default: HistGradientBoostingRegressor (from defaults.py).
    propensity_trim : float
        Clip propensity scores to [trim, 1-trim] to enforce overlap.
    fit_nuisance_fn : callable or None
        Optional replacement for the default ``fit_nuisance`` function.
        Must have the same signature::

            fit_nuisance_fn(X, T, Y, fold_spec,
                            propensity_model, outcome_model,
                            propensity_trim, random_state) -> NuisanceEstimates

        Use this to inject BART-based nuisance, a single pooled outcome model
        with T as a feature, or any other custom nuisance pipeline.
        ``None`` (default) uses the standard two-model cross-fitted procedure.
    """

    strategy_family: ClassVar[str] = "supervised"

    split: CrossFitSplit | TrainAvgSplit = field(default_factory=CrossFitSplit)
    propensity_model: Any = None
    outcome_model: Any = None
    propensity_trim: float = 0.01
    fit_nuisance_fn: Any = field(default=None, repr=False)

    _weights: EnsembleWeights | None = field(default=None, init=False, repr=False)

    def fit_weights(
        self,
        cate_predictions: np.ndarray,
        Y: np.ndarray,
        T: np.ndarray,
        X: np.ndarray,
        nuisance: Any,  # NuisanceEstimates — avoid importing nuisance.py here
    ) -> EnsembleWeights:
        """Compute ensemble weights from OOF predictions and nuisance estimates.

        Parameters
        ----------
        cate_predictions : array of shape (K, m)
            Out-of-fold CATE predictions. m = n for CrossFitSplit;
            m = len(averaging set) for TrainAvgSplit.
        Y, T, X : arrays of shape (m,), (m,), (m, p)
            Outcome, treatment, and covariates for the same m observations.
        nuisance : NuisanceEstimates
            Out-of-fold nuisance predictions for the same m observations.

        Returns
        -------
        EnsembleWeights with optimized weights.
        """
        raise NotImplementedError(
            f"{type(self).__name__} must implement fit_weights()"
        )

    def aggregate_cate(self, cate_matrix: np.ndarray) -> np.ndarray:
        """Aggregate component CATEs using stored weights.

        Parameters
        ----------
        cate_matrix : array of shape (K, n)

        Returns
        -------
        Array of shape (n,).
        """
        w = self._weights
        return w.intercept + w.weights @ cate_matrix

    @property
    def ensemble_weights(self) -> EnsembleWeights | None:
        """Ensemble weights computed during fit(). None before fit()."""
        return self._weights
