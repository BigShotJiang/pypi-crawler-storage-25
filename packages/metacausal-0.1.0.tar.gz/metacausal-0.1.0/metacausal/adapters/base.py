"""Base protocol for causal estimators."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

import numpy as np

from metacausal.estimators import ComponentAteEstimate, ComponentCateEstimate


@runtime_checkable
class CausalEstimator(Protocol):
    """Protocol that all causal estimator adapters must satisfy.

    Any object with a ``name`` property, ``supports_cate`` flag, and
    ``fit``/``ate`` methods matching this signature can be used as a
    component in :class:`CausalEnsemble`.
    """

    @property
    def name(self) -> str: ...

    @property
    def supports_cate(self) -> bool: ...

    def fit(
        self,
        X: np.ndarray,
        T: np.ndarray,
        Y: np.ndarray,
        **kwargs,
    ) -> None: ...

    def ate(self, X: np.ndarray | None = None) -> ComponentAteEstimate: ...

    def cate(self, X: np.ndarray) -> ComponentCateEstimate: ...
