"""Generic adapters for callables and simple estimators."""

from __future__ import annotations

from typing import Any, Callable

import numpy as np

from metacausal.estimators import ComponentAteEstimate, ComponentCateEstimate


class GenericATEAdapter:
    """Wrap a callable ``fn(X, T, Y) -> float`` as an ATE-only causal estimator.

    Parameters:
        fn: A function that takes ``(X, T, Y)`` and returns a scalar ATE
            or a :class:`ComponentAteEstimate`.
        name: Display name for this estimator. Default ``"custom"``.
    """

    def __init__(self, fn: Callable, name: str = "custom") -> None:
        self._fn = fn
        self._name = name
        self._X: np.ndarray | None = None
        self._T: np.ndarray | None = None
        self._Y: np.ndarray | None = None
        self._is_fitted = False

    @property
    def name(self) -> str:
        return self._name

    @property
    def supports_cate(self) -> bool:
        return False

    def fit(
        self,
        X: np.ndarray,
        T: np.ndarray,
        Y: np.ndarray,
        **kwargs,
    ) -> None:
        self._X = X
        self._T = T
        self._Y = Y
        self._is_fitted = True

    def ate(self, X: np.ndarray | None = None) -> ComponentAteEstimate:
        if not self._is_fitted:
            raise RuntimeError(
                f"{self._name} is not fitted. Call fit() first."
            )
        result = self._fn(self._X, self._T, self._Y)
        if isinstance(result, ComponentAteEstimate):
            return result
        return ComponentAteEstimate(ate=float(result))

    def cate(self, X: np.ndarray) -> ComponentCateEstimate:
        raise NotImplementedError(
            f"{self._name} does not support CATE estimation."
        )


# Backward-compatible alias
GenericAdapter = GenericATEAdapter


class GenericCATEAdapter:
    """Wrap callables as a CATE-capable causal estimator.

    Reduces the barrier for prototyping custom CATE estimators to two or three
    functions — one for fitting, one for CATE prediction, and an optional one
    for ATE — without implementing the full ``CausalEstimator`` protocol.

    Parameters
    ----------
    fn_fit : callable
        ``fn_fit(X, T, Y, **kwargs) -> state``

        Called during ``fit()``. Receives the training arrays and any keyword
        arguments forwarded by ``CausalEnsemble`` (e.g. ``random_state``).
        Returns an opaque *state* object (fitted model, dict, namedtuple,
        ``None`` for stateless callables …) passed to ``fn_cate`` and
        ``fn_ate`` at prediction time.

        **Reproducibility:** if ``fn_fit`` uses randomness, it is the caller's
        responsibility to consume ``kwargs.get("random_state")``.
        ``CausalEnsemble`` forwards the seed but cannot enforce its use.

        **Deep-copy requirement:** ``state`` must survive
        ``copy.deepcopy()`` so that bootstrap resampling and supervised
        cross-fitting work correctly. Closures over PyTorch tensors, open file
        handles, or GPU state may fail — see the extensibility guide for
        workarounds.

    fn_cate : callable
        ``fn_cate(state, X) -> array-like of shape (n,)``

        Called during ``cate()``. Receives the fitted *state* and an
        evaluation covariate matrix ``X`` of shape ``(n, p)``. Must return a
        1-D array (or ``(n, 1)`` array, which is automatically squeezed) of
        CATE predictions.

    fn_ate : callable or None
        ``fn_ate(state, X) -> float | ComponentAteEstimate``

        Optional. Called during ``ate()``. Receives the fitted *state* and
        the evaluation covariate matrix ``X``. Returns either a scalar ATE or
        a :class:`ComponentAteEstimate` (useful when the estimator provides
        a native, more efficient ATE — e.g. a DR/AIPW mean rather than
        ``mean(cate(X))``).

        If ``None`` (default), ``ate()`` falls back to ``mean(cate(X_eval))``.

    name : str
        Display name used in ``CateEstimate.component_estimates`` and warning
        messages. Default ``"custom_cate"``.

    Examples
    --------
    Wrap a T-learner with a native DR ATE estimator::

        from sklearn.linear_model import LinearRegression

        def fit_fn(X, T, Y, **kwargs):
            treated = T == 1
            m1 = LinearRegression().fit(X[treated], Y[treated])
            m0 = LinearRegression().fit(X[~treated], Y[~treated])
            return m1, m0

        def cate_fn(state, X):
            m1, m0 = state
            return m1.predict(X) - m0.predict(X)

        def ate_fn(state, X):
            # Example: return a pre-computed DR estimate stored in state
            m1, m0 = state
            return float((m1.predict(X) - m0.predict(X)).mean())

        adapter = GenericCATEAdapter(fit_fn, cate_fn, fn_ate=ate_fn,
                                     name="t_learner")
        ens = CausalEnsemble(methods=[adapter], aggregation="median")
    """

    def __init__(
        self,
        fn_fit: Callable,
        fn_cate: Callable,
        fn_ate: Callable | None = None,
        name: str = "custom_cate",
    ) -> None:
        self._fn_fit = fn_fit
        self._fn_cate = fn_cate
        self._fn_ate = fn_ate
        self._name = name
        self._state: Any = None
        self._X_train: np.ndarray | None = None
        self._is_fitted = False

    @property
    def name(self) -> str:
        return self._name

    @property
    def supports_cate(self) -> bool:
        return True

    def fit(
        self,
        X: np.ndarray,
        T: np.ndarray,
        Y: np.ndarray,
        **kwargs,
    ) -> None:
        """Fit by calling ``fn_fit(X, T, Y, **kwargs)`` and storing the state."""
        self._state = self._fn_fit(X, T, Y, **kwargs)
        self._X_train = np.asarray(X)
        self._is_fitted = True

    def cate(self, X: np.ndarray) -> ComponentCateEstimate:
        """Return CATE predictions by calling ``fn_cate(state, X)``.

        Accepts ``(n,)`` or ``(n, 1)`` output; raises ``ValueError`` otherwise.
        """
        if not self._is_fitted:
            raise RuntimeError(
                f"'{self._name}' is not fitted. Call fit() first."
            )
        raw = np.asarray(
            self._fn_cate(self._state, np.asarray(X)), dtype=float
        )
        if raw.ndim == 2 and raw.shape[1] == 1:
            raw = raw[:, 0]
        if raw.ndim != 1:
            raise ValueError(
                f"fn_cate for '{self._name}' must return shape (n,) or (n, 1), "
                f"got {raw.shape}"
            )
        return ComponentCateEstimate(cate=raw)

    def ate(self, X: np.ndarray | None = None) -> ComponentAteEstimate:
        """Return the ATE.

        If ``fn_ate`` was provided, calls ``fn_ate(state, X_eval)``.
        Otherwise returns ``mean(cate(X_eval))``.

        ``X_eval`` is ``X`` if given, otherwise the training data from
        ``fit()``.
        """
        if not self._is_fitted:
            raise RuntimeError(
                f"'{self._name}' is not fitted. Call fit() first."
            )
        X_eval = np.asarray(X) if X is not None else self._X_train

        if self._fn_ate is not None:
            result = self._fn_ate(self._state, X_eval)
            if isinstance(result, ComponentAteEstimate):
                return result
            return ComponentAteEstimate(ate=float(result))

        return ComponentAteEstimate(ate=float(self.cate(X_eval).cate.mean()))
