"""Adapters for wrapping causal ML libraries."""

from metacausal.adapters.base import CausalEstimator
from metacausal.adapters.causalml import CausalMLAdapter, _is_causalml
from metacausal.adapters.doubleml import DoubleMLAdapter
from metacausal.adapters.econml import EconMLAdapter
from metacausal.adapters.generic import GenericAdapter, GenericATEAdapter, GenericCATEAdapter
from metacausal.adapters.stochtree import StochtreeAdapter

__all__ = [
    "CausalEstimator",
    "CausalMLAdapter",
    "DoubleMLAdapter",
    "EconMLAdapter",
    "GenericATEAdapter",
    "GenericAdapter",        # backward-compatible alias for GenericATEAdapter
    "GenericCATEAdapter",
    "StochtreeAdapter",
]
