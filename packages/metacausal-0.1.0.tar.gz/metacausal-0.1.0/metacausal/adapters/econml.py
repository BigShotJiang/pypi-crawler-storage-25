"""Adapter for EconML estimators."""

from __future__ import annotations

import numpy as np

from metacausal.estimators import ComponentAteEstimate, ComponentCateEstimate


def _is_econml(obj) -> bool:
    """Check if an object is an EconML estimator (without importing econml)."""
    module = type(obj).__module__ or ""
    return module.startswith("econml")


class EconMLAdapter:
    """Wrap an initialized-but-unfitted EconML estimator.

    Supports any EconML estimator with ``.fit(Y, T, X=X)`` and
    ``.ate(X=X)`` or ``.effect(X=X)`` methods. The estimator template
    is deep-copied during ``fit()`` so that the original remains
    reusable for bootstrap resampling.

    Parameters:
        model: An initialized (unfitted) EconML estimator instance.
        name: Display name. Defaults to the class name.
    """

    def __init__(self, model, name: str | None = None) -> None:
        self._model = model
        self._name = name or type(model).__name__
        self._fitted_model = None
        self._X_train: np.ndarray | None = None
        self._is_fitted = False

    @property
    def name(self) -> str:
        return self._name

    @property
    def supports_cate(self) -> bool:
        return True

    # Attributes on EconML estimators that hold nested sub-models.
    _SUB_MODEL_ATTRS = (
        "model_y", "model_t", "model_final",
        "model_regression", "model_propensity",
        "models", "overall_model", "propensity_model",
    )

    def fit(
        self,
        X: np.ndarray,
        T: np.ndarray,
        Y: np.ndarray,
        **kwargs,
    ) -> None:
        import copy

        random_state = kwargs.pop("random_state", None)

        model = copy.deepcopy(self._model)
        if random_state is not None:
            self._seed_model(model, random_state)
        model.fit(Y, T, X=X)

        self._fitted_model = model
        self._X_train = X
        self._is_fitted = True

    def ate(self, X: np.ndarray | None = None) -> ComponentAteEstimate:
        if not self._is_fitted:
            raise RuntimeError(
                f"{self._name} is not fitted. Call fit() first."
            )

        model = self._fitted_model
        X_eval = X if X is not None else self._X_train

        # EconML estimators expose ate() or effect()
        if hasattr(model, "ate"):
            ate = float(model.ate(X=X_eval))
        elif hasattr(model, "effect"):
            ate = float(np.mean(model.effect(X=X_eval)))
        else:
            raise AttributeError(
                f"{self._name} has neither .ate() nor .effect() method"
            )

        # Extract CI if available
        ci_lower, ci_upper = None, None
        if hasattr(model, "ate_interval"):
            try:
                lo, hi = model.ate_interval(X=X_eval)
                ci_lower, ci_upper = float(lo), float(hi)
            except Exception:
                pass
        elif hasattr(model, "effect_interval"):
            try:
                lo, hi = model.effect_interval(X=X_eval)
                ci_lower = float(np.mean(lo))
                ci_upper = float(np.mean(hi))
            except Exception:
                pass

        return ComponentAteEstimate(
            ate=ate, ci_lower=ci_lower, ci_upper=ci_upper
        )

    def cate(self, X: np.ndarray) -> ComponentCateEstimate:
        if not self._is_fitted:
            raise RuntimeError(
                f"{self._name} is not fitted. Call fit() first."
            )

        model = self._fitted_model
        cate = np.asarray(model.effect(X=X), dtype=np.float64).ravel()

        # Extract per-observation CIs if available
        ci_lower, ci_upper = None, None
        if hasattr(model, "effect_interval"):
            try:
                lo, hi = model.effect_interval(X=X)
                ci_lower = np.asarray(lo, dtype=np.float64).ravel()
                ci_upper = np.asarray(hi, dtype=np.float64).ravel()
            except Exception:
                pass

        return ComponentCateEstimate(
            cate=cate, ci_lower=ci_lower, ci_upper=ci_upper
        )

    @classmethod
    def _seed_model(cls, model, random_state: int) -> None:
        """Set random_state on *model* and its nested sub-estimators."""
        rng = np.random.default_rng(random_state)
        if hasattr(model, "random_state"):
            model.random_state = int(rng.integers(0, 2**32 - 1))
        for attr in cls._SUB_MODEL_ATTRS:
            sub = getattr(model, attr, None)
            if sub is None:
                continue
            if isinstance(sub, list):
                for item in sub:
                    if hasattr(item, "random_state"):
                        item.random_state = int(rng.integers(0, 2**32 - 1))
            elif hasattr(sub, "random_state"):
                sub.random_state = int(rng.integers(0, 2**32 - 1))
