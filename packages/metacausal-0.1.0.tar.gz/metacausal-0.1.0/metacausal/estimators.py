"""Data classes for causal estimates."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from metacausal.aggregation.weights import EnsembleWeights


@dataclass
class ComponentAteEstimate:
    """Result from a single causal estimator.

    Attributes:
        ate: Average treatment effect point estimate.
        ci_lower: Lower bound of confidence interval (if available).
        ci_upper: Upper bound of confidence interval (if available).
        details: Method-specific additional information.
    """

    ate: float
    ci_lower: float | None = None
    ci_upper: float | None = None
    details: dict | None = None


# Backward-compatible alias
CausalEstimate = ComponentAteEstimate


@dataclass
class AteEstimate:
    """Result from the ensemble of causal estimators.

    Attributes:
        ate: Aggregated treatment effect point estimate.
        component_estimates: Per-method estimates, keyed by method name.
        aggregation: Aggregation strategy class name.
        component_fit_times: Wall-clock fit time in seconds for each method
            on the full dataset. Does not include bootstrap iterations.
    """

    ate: float
    component_estimates: dict[str, ComponentAteEstimate]
    aggregation: str
    component_fit_times: dict[str, float] | None = field(default=None, repr=False)

    @property
    def component_ates(self) -> dict[str, float]:
        """ATEs from each component method."""
        return {k: v.ate for k, v in self.component_estimates.items()}

    @property
    def spread(self) -> float:
        """Range (max - min) of component ATEs."""
        ates = list(self.component_ates.values())
        return max(ates) - min(ates)

    @property
    def n_methods(self) -> int:
        """Number of methods that produced estimates."""
        return len(self.component_estimates)


# Backward-compatible alias
EnsembleEstimate = AteEstimate


@dataclass
class ComponentCateEstimate:
    """CATE result from a single component method.

    Attributes:
        cate: Per-observation treatment effect estimates, shape (n,).
        ci_lower: Lower bounds of confidence/credible intervals, shape (n,).
            From the method's native inference (e.g., EconML analytical CIs,
            stochtree posterior quantiles). None if unavailable.
        ci_upper: Upper bounds, shape (n,). None if unavailable.
        details: Method-specific additional information.
    """

    cate: np.ndarray
    ci_lower: np.ndarray | None = None
    ci_upper: np.ndarray | None = None
    details: dict | None = None


@dataclass
class CateEstimate:
    """Ensemble CATE result. Pure data, no model references.

    Attributes:
        cate: Aggregated per-observation treatment effects, shape (n,).
        component_estimates: Per-method CATE results, keyed by method name.
            Only includes methods with ``supports_cate=True``.
        aggregation: Aggregation strategy class name.
        ensemble_weights: Weight vector from the aggregation strategy.
            None for pointwise strategies (Median, Mean).
    """

    cate: np.ndarray
    component_estimates: dict[str, ComponentCateEstimate]
    aggregation: str
    ensemble_weights: EnsembleWeights | None = None

    @property
    def component_cates(self) -> dict[str, np.ndarray]:
        """CATE arrays from each component method."""
        return {k: v.cate for k, v in self.component_estimates.items()}

    @property
    def n_methods(self) -> int:
        """Number of methods that produced CATE estimates."""
        return len(self.component_estimates)
