"""Shared parallel-execution helpers.

Every site in the codebase that dispatches independent tasks to workers
should go through :func:`parallel_map` so the backend choice and thread
pinning stay consistent. See issue #10 for the "exclusive outer
parallelism" design.
"""

from __future__ import annotations

import os
from typing import Any, Callable, Iterable


_THREAD_PIN_VARS = (
    "OMP_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "MKL_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
)


def _pin_threads() -> None:
    """Pin inner threadpools to 1 thread in a worker process.

    Called as the ``initializer`` of every ``joblib.Parallel`` dispatch.
    Sets env vars for the OpenMP, OpenBLAS, MKL, numexpr, and Apple
    Accelerate runtimes. loky spawns fresh processes, so these take
    effect before any numeric library initializes its threadpool.
    """
    for var in _THREAD_PIN_VARS:
        os.environ[var] = "1"


def parallel_map(
    n_jobs: int,
    func: Callable[..., Any],
    tasks: Iterable[tuple],
) -> list[Any]:
    """Dispatch ``func(*task)`` for each task, in parallel or sequentially.

    Uses the loky backend with :func:`_pin_threads` as worker initializer.
    Falls back to a sequential list comprehension when ``n_jobs == 1``
    to avoid joblib dispatch overhead and to keep stack traces readable
    during debugging.

    Parameters
    ----------
    n_jobs : int
        1 → sequential. -1 → all cores. Any other positive int → that many
        worker processes.
    func : callable
        Applied as ``func(*task)`` per task. Must be picklable.
    tasks : iterable of tuple
        Each tuple is unpacked as positional arguments to ``func``.

    Returns
    -------
    list
        Results in task order.
    """
    tasks = list(tasks)
    if n_jobs == 1 or len(tasks) <= 1:
        return [func(*t) for t in tasks]

    try:
        from joblib import Parallel, delayed
    except ImportError:
        return [func(*t) for t in tasks]

    n_workers = n_jobs if n_jobs > 0 else os.cpu_count()
    return Parallel(
        n_jobs=n_workers,
        backend="loky",
        initializer=_pin_threads,
    )(delayed(func)(*t) for t in tasks)
