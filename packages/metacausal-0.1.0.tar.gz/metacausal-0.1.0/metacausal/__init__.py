"""MetaCausal — Robust treatment effect estimation via ensembling."""

from metacausal.aggregation import (
    AggregationStrategy,
    AgreementStrategy,
    BootstrapResult,
    CBA,
    EnsembleWeights,
    Mean,
    Median,
    PointwiseStrategy,
    TrimmedMean,
)
from metacausal.adapters.causalml import CausalMLAdapter
from metacausal.adapters.generic import GenericAdapter, GenericATEAdapter, GenericCATEAdapter
from metacausal.ensemble import CausalEnsemble
from metacausal.estimators import (
    AteEstimate,
    CausalEstimate,
    CateEstimate,
    ComponentAteEstimate,
    ComponentCateEstimate,
    EnsembleEstimate,
)

__version__ = "0.1.0"

__all__ = [
    "CausalEnsemble",
    # Estimator result types
    "ComponentAteEstimate",
    "AteEstimate",
    "ComponentCateEstimate",
    "CateEstimate",
    # Aggregation
    "AggregationStrategy",
    "PointwiseStrategy",
    "AgreementStrategy",
    "Median",
    "Mean",
    "TrimmedMean",
    "CBA",
    "EnsembleWeights",
    "BootstrapResult",
    # Library adapters
    "CausalMLAdapter",
    # Generic adapters
    "GenericATEAdapter",
    "GenericAdapter",        # backward-compatible alias
    "GenericCATEAdapter",
    # Backward-compatible aliases
    "CausalEstimate",
    "EnsembleEstimate",
]
