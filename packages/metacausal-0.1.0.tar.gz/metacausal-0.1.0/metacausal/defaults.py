"""Default method configurations.

This module imports heavy dependencies (econml, doubleml, causalml,
stochtree). It is only loaded when the user calls ``CausalEnsemble()``
without specifying methods, or calls ``default_methods()`` directly.
"""

from __future__ import annotations


def default_propensity_model():
    """Default propensity model: HistGradientBoostingClassifier."""
    from sklearn.ensemble import HistGradientBoostingClassifier
    return HistGradientBoostingClassifier(
        max_iter=200, early_stopping=True, validation_fraction=0.15,
        n_iter_no_change=10,
    )


def default_outcome_model():
    """Default outcome model: HistGradientBoostingRegressor."""
    from sklearn.ensemble import HistGradientBoostingRegressor
    return HistGradientBoostingRegressor(
        max_iter=200, early_stopping=True, validation_fraction=0.15,
        n_iter_no_change=10,
    )


def default_methods() -> list:
    """Return a default set of causal estimators.

    Requires: econml, doubleml, causalml, stochtree, sklearn.
    Install via ``pip install metacausal[all]`` for the full default library.

    Returns a list of ten components spanning the four supported frameworks::

        DoubleML:   DoubleMLIRM, DoubleMLPLR
        EconML:     CausalForestDML, DRLearner, SLearner, TLearner, XLearner
        CausalML:   BaseRRegressor (R-Learner), TMLELearner
        stochtree:  Bayesian Causal Forest
    """
    from econml.dml import CausalForestDML
    from econml.dr import DRLearner
    from econml.metalearners import SLearner, TLearner, XLearner

    from metacausal.adapters.causalml import CausalMLAdapter
    from metacausal.adapters.doubleml import DoubleMLAdapter
    from metacausal.adapters.stochtree import StochtreeAdapter

    # Lazy imports to avoid top-level dependency
    from causalml.inference.meta import BaseRRegressor, TMLELearner
    from doubleml import DoubleMLIRM, DoubleMLPLR

    return [
        # Semiparametric doubly-robust
        DoubleMLAdapter(DoubleMLIRM, ml_g=default_outcome_model(), ml_m=default_propensity_model()),
        DoubleMLAdapter(DoubleMLPLR, ml_l=default_outcome_model(), ml_m=default_propensity_model()),
        # Tree-based
        CausalForestDML(
            model_y=default_outcome_model(),
            model_t=default_propensity_model(),
            discrete_treatment=True,
            n_estimators=200,
        ),
        # DR-Learner
        DRLearner(model_regression=default_outcome_model(), model_propensity=default_propensity_model()),
        # Meta-learners
        SLearner(overall_model=default_outcome_model()),
        TLearner(models=default_outcome_model()),
        XLearner(
            models=default_outcome_model(),
            propensity_model=default_propensity_model(),
        ),
        # R-Learner (CausalML — auto-wrapped by CausalEnsemble)
        BaseRRegressor(
            outcome_learner=default_outcome_model(),
            propensity_learner=default_propensity_model(),
            effect_learner=default_outcome_model(),
        ),
        # TMLE (CausalML, ATE-only — explicit adapter so the propensity
        # model is fitted via CausalMLAdapter's dedicated slot)
        CausalMLAdapter(
            TMLELearner(learner=default_outcome_model()),
            propensity_model=default_propensity_model(),
        ),
        # Bayesian Causal Forest (stochtree — explicit adapter required)
        StochtreeAdapter(propensity_model=default_propensity_model()),
    ]
