import logging

logger=logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
handler=logging.FileHandler("aki.log",mode="w")
formatter=logging.Formatter("%(asctime)s %(levelname)s %(message)s")
handler.setFormatter(formatter)
logger.addHandler(handler)

logger.debug("Session started")

def debug(message):
    logger.debug(message)

def info(message):
    logger.info(message)

def warning(message):
    logger.warning(message)

def error(message):
    logger.error(message)

def critical(message):
    logger.error(message)

def exception(message):
    logger.exception(message)