class OptionNotAvailable(RuntimeError):
    """A error class when a person enters another value except yes or no(y/n)"""