from colorama import init, Fore
import log_in_file as log
from errors import OptionNotAvailable
import smtplib
from email.message import EmailMessage
import os
init(autoreset=True)

__version__="0.1.0"
score=0

def get_float_input(prompt:str) -> float:
    while True:
        try:
            global value
            value=float(input(f"{prompt}"))
            return value
        except ValueError as err:
            log.exception("ValueError")
            print(Fore.RED+"Please enter a numerical value")
        
    
def get_bool_f_string(prompt:str) -> bool:
    while True:
        value=input(f"{prompt}")
        if "y" in value.lower():
            return True
        elif "n" in value.lower():
            return False
        else:
            try:
                raise OptionNotAvailable("The option entred is not valid(it is not a yes or no answer)")
            except OptionNotAvailable:
                log.exception("Option is entred wrongly by the user")
            print(Fore.RED+"The answer entered is not valid. Please try again")

def get_values() -> dict:
    get_float_input("Please type the creatinine value of the patient: ")
    creat=value
    get_float_input("Please type the baseline creatinine, if not available type 0: ")
    basecreat=value
    urine_output=get_bool_f_string("Is the urine output of the patient low?(y/n): ")
    dehydrate=get_bool_f_string("Is the patient dehydrated?(y/n): ")
    infection=get_bool_f_string("Does the patient have any infection?(y/n): ")
    output={
        "creat":creat,
        "base":basecreat,
        "uo":urine_output,
        "de":dehydrate,
        "in":infection
    }
    return output

def analyse():
    values=get_values()
    creat=values['creat']
    global score
    if values['base']!=0:
        basecreat=values['base']
        if creat<=(1.5*basecreat):
            pass
        elif creat<=(1.9*basecreat):
            score+=2
        elif creat<=(2.9*basecreat):
            score+=3
        elif creat>=(3*basecreat):
            score+=4
        else:
            raise RuntimeError("Problem in creat analysis with basecreat")
    else:
        if creat<=1.2:
            pass
        elif creat<=1.9:
            score+=2
        elif creat<=2.9:
            score+=3
        elif creat>=3:
            score+=4
        else:
            raise RuntimeError("Problem in creat analysis without basecreat")
    if values['uo']:
        score+=3
    else:
        pass
    if values['de']:
        score+=1
    else:
        pass
    if values['in']:
        score+=1
    else:
        pass
    return [score,values]

def output_ask_email(smtp_server="",smtp_emailid="",smtp_password="",smtp_port=0):
    holder=analyse()
    score=holder[0]
    out=holder[1]
    text_cont=""
    html_cont=""
    print("Values entered".center(20,"="))
    text_cont+=("Values entered".center(20,"=")+"\r\n")
    html_cont+="<h2><b>Values entered</b></h2><br/>"
    print(f"Creatinine value: {out['creat']}")
    text_cont+=f"Creatinine value: {out['creat']}\r\n"
    html_cont+=f"Creatinine value: {out['creat']}<br/>"
    print(f"Baseline creatinine value: {"Not available" if out['base']==0 else out['base']}")
    text_cont+=f"Baseline creatinine value: {"Not available" if out['base']==0 else out['base']}\r\n"
    html_cont+=f"Baseline creatinine value: {"Not available" if out['base']==0 else out['base']}<br/>"
    print(f"Urine output: {"Low" if out['uo'] else "Normal"}")
    text_cont+=f"Urine output: {"Low" if out['uo'] else "Normal"}\r\n"
    html_cont+=f"Urine output: {"Low" if out['uo'] else "Normal"}<br/>"
    print(f"Other conditions:-")
    text_cont+=f"Other conditions:-\r\n"
    html_cont+=f"Other conditions:-<br/><ul>"
    if out['de']:
        print(f"\t- Dehydrated")
        text_cont+="\t- Dehydrated\r\n"
        html_cont+="<li>Dehydrated</li>"
    if out['in']:
        print(f"\t- Infection")
        text_cont+="\t- Infection\r\n"
        html_cont+="<li>Infection</li>"
    if not (out['de'] and out['in']):
        print("\t- No conditions")
        text_cont+="\t- No conditions\r\n"
        html_cont+="<li>No conditions</li>"
    html_cont+="</ul>"
    print("**End of entered values**".center(30,"="))
    text_cont+=("**End of entered values**".center(30,"=")+"\r\n")
    html_cont+="<b>End of entered values</b><br/>"
    print("Caclulated results".center(20,"="))
    text_cont+=("Caclulated results".center(20,"=")+"\r\n")
    html_cont+="<h2><b>Calculated results</b></h2><br/>"
    if score==0:
        print(Fore.GREEN+f"Risk score: 0")
        text_cont+=f"Risk score: 0"
        html_cont+=f"<span style='color:red'>Risk score: 0</span><br/>"
    elif score<=2:
        print(Fore.YELLOW+f"Risk score: {score}")
        text_cont+=f"Risk score: {score}"
        html_cont+=f"<span style='color:yellow'>Risk score:{score}</span><br/>"
    elif score<=5:
        print(Fore.MAGENTA+f"Risk score: {score}")
        text_cont+=f"Risk score: {score}"
        html_cont+=f"<span style='color:magenta'>Risk score: {score}</span><br/>"
    elif score>=6:
        print(Fore.RED+f"Risk score: {score}")
        text_cont+=f"Risk score: {score}"
        html_cont+=f"<span style='color:red'>Risk score: {score}</span><br/>"
    text_cont+="This is an autogenerated email. Please do not reply"
    html_cont+="<span style='color:grey'>This is an autogenerated email. Please do not reply</span>"
    send_mail=get_bool_f_string("Do you want to send the results to your email?(y/n): ")
    if send_mail:
        if smtp_server:
            server=smtp_server
        else:
            server=os.environ['SMTP_SERVER']
        if smtp_port:
            port=int(smtp_port)
        else:
            port=int(os.environ['SMTP_PORT'])
        if smtp_emailid:
            emailid=smtp_emailid
        else:
            emailid=os.environ['SMTP_EMAILID']
        if smtp_password:
            password=smtp_password
        else:
            password=os.environ['SMTP_PASSWORD']
        email=input("Please enter your email: ")
        message=EmailMessage()
        message['From']=f"AKI Risk score Calculator <{smtp_emailid}>"
        message['To']=email
        message['Subject']="AKI Risk score calculator results"
        message.set_content(text_cont)
        message.add_alternative(html_cont,subtype="html")
        s=smtplib.SMTP(server,port)
        s.ehlo()
        s.starttls()
        s.login(emailid,password)
        if s.send_message(message)=={}:
            print("Email sent successfully")
            
            
def output():
    holder=analyse()
    score=holder[0]
    out=holder[1]
    print("Values entered".center(20,"="))
    print(f"Creatinine value: {out['creat']}")
    print(f"Baseline creatinine value: {"Not available" if out['base']==0 else out['base']}")
    print(f"Urine output: {"Low" if out['uo'] else "Normal"}")
    print(f"Other conditions:-")
    if out['de']:
        print(f"\t- Dehydrated")
    if out['in']:
        print(f"\t- Infection")
    if not (out['de'] and out['in']):
        print("\t- No conditions")
    print("**End of entered values**".center(30,"="))
    print("Caclulated results".center(20,"="))
    if score==0:
        print(Fore.GREEN+f"Risk score: 0")
    elif score<=2:
        print(Fore.YELLOW+f"Risk score: {score}")
    elif score<=5:
        print(Fore.MAGENTA+f"Risk score: {score}")
    elif score>=6:
        print(Fore.RED+f"Risk score: {score}")
    

                

    
def main():   
    try:
        print("Welcome to the AKI Risk score calculator")
        print("Initialising..",end="\r")
        print("Note: A file called aki.log is created in the directory where this .exe/.app file is kept.")
        
        output_ask_email()
        input("Please type enter to close....")
        log.debug("Session closed")

    except KeyboardInterrupt:
        log.exception("Operation cancelled by user")
        log.debug("Session closed due to keyboard interrput")
        input("\nKeyboard interrupt(Ctrl+C) detected. Closing program \nPress enter to exit... ")

    except Exception as ex:
        log.exception(f"Unhandled error: {ex}")
        log.debug("Session closed due to error")
        print("An error has occured. You can view the logs in a file called aki.log in the director where the .exe file is placed")
    
if __name__=="__main__":
    main()