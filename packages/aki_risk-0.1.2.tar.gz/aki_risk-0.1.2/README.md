# AKI Risk Score calculator

This is a AKI(Acute Kideny Injury) risk calculator. It will take vitals from patients and then use them to create a risk score value between 0 to 9. You can use it as a Python module or call it by using aki-risk.exe