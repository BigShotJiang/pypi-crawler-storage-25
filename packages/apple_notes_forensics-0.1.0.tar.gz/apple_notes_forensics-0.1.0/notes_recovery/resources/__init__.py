"""Package resources (queries, templates)."""
