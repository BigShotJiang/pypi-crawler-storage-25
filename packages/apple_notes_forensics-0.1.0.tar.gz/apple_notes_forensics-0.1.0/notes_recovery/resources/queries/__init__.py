"""SQL query templates."""
