# f69-edge (Python SDK)

Small **httpx-based** client for the f69-edge HTTP API.

Requires **Python 3.11+**.

## Install

```bash
pip install f69
```


## Usage

```python
import os

from f69 import F69EdgeClient, F69EdgeError

client = F69EdgeClient(
    base_url=os.environ.get("F69_EDGE_URL", "http://127.0.0.1:8081"),
    # From control plane: POST .../service-accounts - use bearer_token or `<id>.<secret_key>`.
    # Tokens are reader (evaluate only) or writer (identify + evaluate); each token is bound to one environment.
    api_key=os.environ["F69_SERVICE_ACCOUNT_BEARER"],
)

client.health()  # GET /health (no auth)

client.identify(
    {
        "type": "user",
        "external_id": "user_42",
        "attributes": {"plan": "pro", "region": "eu"},
    }
)

flags = client.evaluate({"id": "user_42", "type": "user"})
# flags → [
#   {"key": "new_checkout", "value": True, "reason": "TARGETING_MATCH", "version": "live"},
#   ...
# ]

client.close()
```

### Evaluate semantics

`POST /v1/evaluate` takes `{"id", "type"}` and optional `"keys"`. Omit `keys` to evaluate every workspace flag; pass a non-empty `keys` list to
evaluate only those feature keys. The server looks up the entity in the
token's environment (it must have been identified first via `/v1/identify`)
and replies with a list of results. Each entry carries `key`, `value`,
`reason` (one of `TARGETING_MATCH`, `SPLIT`, `DEFAULT`, `FALLBACK`,
`ERROR`), and a manifest `version` string.

Use as a context manager to close the underlying HTTP client:

```python
with F69EdgeClient(base_url="http://127.0.0.1:8081", api_key="...") as client:
    client.health()
```

Errors on non-2xx responses raise **`F69EdgeError`** with `status`, `url`, and parsed `body` when available.

## API surface

| Method | HTTP | Auth |
|--------|------|------|
| `health()` | `GET /health` | No |
| `identify(body)` | `POST /v1/identify` | `Authorization: Bearer <serviceAccountId>.<secretKey>` |
| `evaluate(body)` | `POST /v1/evaluate` | Same |
