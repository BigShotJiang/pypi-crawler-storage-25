from __future__ import annotations

from typing import Literal, TypedDict

JsonValue = (
    None | bool | int | float | str | list["JsonValue"] | dict[str, "JsonValue"]
)


class _IdentifyRequestBase(TypedDict):
    type: str
    external_id: str


class IdentifyRequest(_IdentifyRequestBase, total=False):
    attributes: dict[str, JsonValue]


class IdentifyResponse(TypedDict):
    id: str
    type: str
    external_id: str
    attributes: dict[str, JsonValue]


class _EvaluateRequestBase(TypedDict):
    id: str
    type: str


class EvaluateRequest(_EvaluateRequestBase, total=False):
    """Evaluate request body: ``id``, ``type``, and optional ``keys``.

    The server looks up the entity in the token's environment (it must have
    been identified first via ``POST /v1/identify``) and uses its stored
    attributes during evaluation. When ``keys`` is present it must be
    non-empty; omit it to evaluate every workspace feature.
    """

    keys: list[str]


EvaluationReason = Literal[
    "TARGETING_MATCH",
    "SPLIT",
    "DEFAULT",
    "FALLBACK",
    "ERROR",
]


class EvaluatedFlag(TypedDict):
    """A single evaluated flag in the response list."""

    key: str
    value: bool
    reason: EvaluationReason
    version: str


EvaluateResponse = list[EvaluatedFlag]


class HealthResponse(TypedDict, total=False):
    ok: bool
    service: str
