"""Integration tests for pytest-llm-assert with real LLM calls.

These tests verify that LLM-powered assertions work correctly with actual models.
Primary provider: OpenAI (configured by default).
Additional providers available: Azure OpenAI, Google Gemini (see fixtures).

To test with different providers, modify the llm fixture params list.

Run with: pytest -m integration -v
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest


# Load .env from workspace root (search upward)
def _find_env_file() -> Path | None:
    path = Path(__file__).resolve()
    for parent in path.parents:
        env_file = parent / ".env"
        if env_file.exists():
            return env_file
    return None


if env_file := _find_env_file():
    from dotenv import load_dotenv

    load_dotenv(env_file)

pytestmark = pytest.mark.integration


# =============================================================================
# Provider Configuration (from environment)
# =============================================================================

# OpenAI model (default: gpt-4o-mini - fast and cheap)
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")

# Azure deployment name (default: gpt-4o-mini - fast and cheap)
AZURE_DEPLOYMENT = os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-4o-mini")

# Google Gemini model (default: gemini-2.0-flash - fast and capable)
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.0-flash")


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def openai_llm_factory():
    """Factory to create LLMAssert for OpenAI.

    Uses API key from OPENAI_API_KEY environment variable.
    """
    from pytest_llm_assert import LLMAssert

    if not os.environ.get("OPENAI_API_KEY"):
        pytest.skip("OPENAI_API_KEY not set")

    def create(model: str) -> LLMAssert:
        return LLMAssert(model=f"openai:{model}")

    return create


@pytest.fixture
def azure_llm_factory():
    """Factory to create LLMAssert for Azure OpenAI.

    Uses Entra ID authentication automatically via environment variables.
    Requires: AZURE_OPENAI_ENDPOINT environment variable.
    Auth: az login or managed identity - no API key needed.
    """
    from pytest_llm_assert import LLMAssert

    endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
    if not endpoint:
        pytest.skip("AZURE_OPENAI_ENDPOINT not set")

    def create(deployment: str) -> LLMAssert:
        # Entra ID auth is automatic via environment variables
        return LLMAssert(model=f"azure:{deployment}")

    return create


@pytest.fixture
def gemini_llm_factory():
    """Factory to create LLMAssert for Google Gemini.

    Uses Application Default Credentials via Pydantic AI.
    Requires: GEMINI_API_KEY or Google Cloud credentials.
    """
    from pytest_llm_assert import LLMAssert

    if not os.environ.get("GEMINI_API_KEY") and not os.environ.get(
        "GOOGLE_APPLICATION_CREDENTIALS"
    ):
        pytest.skip("GEMINI_API_KEY or GOOGLE_APPLICATION_CREDENTIALS not set")

    def create(model: str) -> LLMAssert:
        return LLMAssert(model=f"gemini:{model}")

    return create


# Combined fixture for running same tests across providers
@pytest.fixture(params=["openai"])
def llm(request, openai_llm_factory):
    """LLM instance that cycles through available providers.

    Default is OpenAI only for quick testing.
    Can be extended to include azure and gemini when those credentials are available.
    """
    if request.param == "openai":
        return openai_llm_factory(OPENAI_MODEL)
    else:
        msg = f"Unknown provider: {request.param}"
        raise ValueError(msg)


class TestBasicAssertions:
    """Test basic pass/fail assertions."""

    def test_success_message_passes(self, llm):
        """A success message should be recognized."""
        result = llm(
            "Operation completed successfully. 3 records updated.",
            "Does this indicate the operation succeeded?",
        )
        assert result

    def test_error_message_detected(self, llm):
        """An error message should fail a success check."""
        result = llm(
            "Error: Connection refused. Unable to reach database.",
            "Does this indicate success?",
        )
        assert not result


class TestSemanticVariations:
    """Test the core value: handling variations that string matching can't.

    This is WHY you use pytest-llm-assert instead of regular assertions.
    """

    def test_success_message_variations(self, llm):
        """Different ways to indicate success should all pass."""
        success_messages = [
            "Operation completed successfully",
            "Done. 5 items processed.",
            "Build succeeded with 0 errors",
            "All tests passed",
            "Request fulfilled",
            "Task finished without errors",
        ]
        for msg in success_messages:
            result = llm(msg, "Does this indicate the operation succeeded?")
            assert result, f"Failed to recognize success: {msg}"

    def test_error_message_variations(self, llm):
        """Different ways to indicate failure should all be detected.

        Allow minor LLM inconsistency - require 5/6 to pass (AI can be flaky).
        """
        error_messages = [
            "Error: file not found",
            "Failed to connect to database",
            "Build failed with 3 errors",
            "Exception: NullPointerException",
            "Unable to process request",
            "FATAL: Out of memory",
        ]
        passed_count = 0
        for msg in error_messages:
            result = llm(msg, "Does this indicate an error or failure?")
            if result:
                passed_count += 1

        # Allow 1 flaky failure - LLMs can be inconsistent
        min_required = len(error_messages) - 1
        assert passed_count >= min_required, (
            f"Only {passed_count}/{len(error_messages)} error messages recognized "
            f"(need at least {min_required})"
        )


class TestSQLSemanticEquivalence:
    """Test SQL validation - the README hero example."""

    def test_valid_sql_variations(self, llm):
        """Different valid SQL for the same intent should all pass."""
        valid_queries = [
            "SELECT name FROM users WHERE age > 21",
            "SELECT name FROM users WHERE age >= 22",
            "select NAME from USERS where AGE > 21",  # Case insensitive
            "SELECT u.name FROM users u WHERE u.age > 21",  # With alias
            "SELECT name FROM users WHERE age > 21 ORDER BY name",  # With ORDER BY
        ]
        for sql in valid_queries:
            result = llm(
                sql,
                "Is this a valid SQL query that selects user names filtered by age?",
            )
            assert result, f"Failed to validate: {sql}"

    def test_invalid_sql_detected(self, llm):
        """Invalid or wrong SQL should fail."""
        invalid_queries = [
            "SELEC name FROM users",  # Typo
            "SELECT name WHERE age > 21",  # Missing FROM
            "DELETE FROM users",  # Wrong operation
        ]
        for sql in invalid_queries:
            result = llm(sql, "Is this a valid SELECT query for user names?")
            assert not result, f"Should have rejected: {sql}"


class TestSemanticUnderstanding:
    """Test that LLM understands semantic meaning, not just keywords."""

    def test_understands_equivalent_logic(self, llm):
        """LLM should recognize logically equivalent code."""
        code = "if not (x > 0 and y > 0): return False"
        result = llm(
            code, "Does this code return False when either x or y is not positive?"
        )
        assert result

    def test_detects_potential_bug(self, llm):
        """LLM should detect a potential off-by-one error."""
        code = "for i in range(len(items)): print(items[i+1])"
        result = llm(code, "Does this code have a potential index out of bounds error?")
        assert result
