"""
EDGE by Predigy — Official Python SDK

Usage:
    from edge_sdk import EdgeClient

    async with EdgeClient(base_url="...", api_key="...") as client:
        markets = await client.list_markets()                      # 1.x flat
        ticket = await client.retail.mint_ticket(...)              # 2.x grouped
        parlay = await client.parlay.create_parlay(...)            # 2.x grouped
        report = await client.compliance.daily_results(...)        # 2.x grouped
        lp = await client.lp.designate_lp(...)                     # 2.x grouped
"""

__version__ = "2.0.2"

from edge_sdk.client import EdgeClient
from edge_sdk.compliance import ComplianceClient
from edge_sdk.lp import LPClient
from edge_sdk.parlay import ParlayClient
from edge_sdk.retail import RetailClient
from edge_sdk.webhook import verify_signature
from edge_sdk.exceptions import EdgeAPIError, EdgeAuthError, EdgeRateLimitError

__all__ = [
    "EdgeClient",
    "RetailClient",
    "ParlayClient",
    "ComplianceClient",
    "LPClient",
    "verify_signature",
    "EdgeAPIError",
    "EdgeAuthError",
    "EdgeRateLimitError",
]
