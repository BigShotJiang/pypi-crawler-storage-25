"""`forerunner.config.yaml` schema + loader. See SPEC.md §T25."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

CONFIG_FILENAME = "forerunner.config.yaml"

_KNOWN_PROVIDERS = {"anthropic", "openai", "google", "ollama"}
_KNOWN_SEVERITIES = {"HIGH", "MEDIUM", "LOW"}


class ConfigError(Exception):
    """Schema violation in forerunner.config.yaml."""


@dataclass(frozen=True)
class CheckConfig:
    block_on: tuple[str, ...] = ("HIGH", "MEDIUM")
    warn_on: tuple[str, ...] = ("LOW",)
    enabled_rules: tuple[str, ...] | None = None  # None = all rules enabled
    ignore_paths: tuple[str, ...] = ()


@dataclass(frozen=True)
class VersionAuditConfig:
    enabled: bool = True
    stale_after_days: int = 30
    fetch_live_eol_data: bool = False


@dataclass(frozen=True)
class ForerunnerConfig:
    provider: str = "anthropic"
    model: str = "claude-opus-4-7"
    output_dir: Path = field(default_factory=lambda: Path("docs"))
    context_max_files: int = 30
    context_max_lines_per_file: int = 300
    approaching_eol_threshold_months: int = 6
    ignore_patterns: tuple[str, ...] = ()
    api_key_env: dict[str, str] = field(default_factory=dict)
    check: CheckConfig = field(default_factory=CheckConfig)
    version_audit: VersionAuditConfig = field(default_factory=VersionAuditConfig)


def _require_type(value: Any, expected: type, field_name: str) -> Any:
    if not isinstance(value, expected):
        raise ConfigError(
            f"{field_name}: expected {expected.__name__}, got {type(value).__name__}"
        )
    return value


def _coerce_str_tuple(value: Any, field_name: str) -> tuple[str, ...]:
    if value is None:
        return ()
    if not isinstance(value, list):
        raise ConfigError(f"{field_name}: expected list, got {type(value).__name__}")
    out: list[str] = []
    for i, item in enumerate(value):
        if not isinstance(item, str):
            raise ConfigError(f"{field_name}[{i}]: expected string, got {type(item).__name__}")
        out.append(item)
    return tuple(out)


def _parse_api_key_env(raw: Any) -> dict[str, str]:
    if raw is None:
        return {}
    if not isinstance(raw, dict):
        raise ConfigError(f"api_key_env: expected dict, got {type(raw).__name__}")
    out: dict[str, str] = {}
    for k, v in raw.items():
        if not isinstance(k, str):
            raise ConfigError(
                f"api_key_env: keys must be strings, got {type(k).__name__}"
            )
        if k not in _KNOWN_PROVIDERS:
            raise ConfigError(
                f"api_key_env: unknown provider '{k}' (expected one of {sorted(_KNOWN_PROVIDERS)})"
            )
        if not isinstance(v, str) or not v:
            raise ConfigError(
                f"api_key_env[{k}]: expected non-empty string, got {type(v).__name__}"
            )
        out[k] = v
    return out


def _parse_check(raw: Any) -> CheckConfig:
    if raw is None:
        return CheckConfig()
    _require_type(raw, dict, "tasks.check")
    block_on = _coerce_str_tuple(raw.get("block_on", ["HIGH", "MEDIUM"]), "tasks.check.block_on")
    warn_on = _coerce_str_tuple(raw.get("warn_on", ["LOW"]), "tasks.check.warn_on")
    for sev in (*block_on, *warn_on):
        if sev not in _KNOWN_SEVERITIES:
            raise ConfigError(
                f"tasks.check: unknown severity '{sev}' (expected one of {sorted(_KNOWN_SEVERITIES)})"
            )
    enabled_rules_raw = raw.get("enabled_rules")
    enabled_rules = (
        _coerce_str_tuple(enabled_rules_raw, "tasks.check.enabled_rules")
        if enabled_rules_raw is not None
        else None
    )
    ignore_paths = _coerce_str_tuple(raw.get("ignore_paths", []), "tasks.check.ignore_paths")
    return CheckConfig(
        block_on=block_on,
        warn_on=warn_on,
        enabled_rules=enabled_rules,
        ignore_paths=ignore_paths,
    )


def _parse_version_audit(raw: Any) -> VersionAuditConfig:
    if raw is None:
        return VersionAuditConfig()
    _require_type(raw, dict, "tasks.version_audit")
    return VersionAuditConfig(
        enabled=bool(raw.get("enabled", True)),
        stale_after_days=int(raw.get("stale_after_days", 30)),
        fetch_live_eol_data=bool(raw.get("fetch_live_eol_data", False)),
    )


def parse(raw: dict[str, Any] | None) -> ForerunnerConfig:
    """Validate a parsed YAML mapping into a ForerunnerConfig."""
    if raw is None:
        return ForerunnerConfig()
    _require_type(raw, dict, "<root>")

    provider = raw.get("provider", "anthropic")
    _require_type(provider, str, "provider")
    if provider not in _KNOWN_PROVIDERS:
        raise ConfigError(
            f"provider: unknown '{provider}' (expected one of {sorted(_KNOWN_PROVIDERS)})"
        )

    tasks = raw.get("tasks") or {}
    _require_type(tasks, dict, "tasks")

    return ForerunnerConfig(
        provider=provider,
        model=_require_type(raw.get("model", "claude-opus-4-7"), str, "model"),
        output_dir=Path(_require_type(raw.get("output_dir", "docs"), str, "output_dir")),
        context_max_files=int(raw.get("context_max_files", 30)),
        context_max_lines_per_file=int(raw.get("context_max_lines_per_file", 300)),
        approaching_eol_threshold_months=int(raw.get("approaching_eol_threshold_months", 6)),
        ignore_patterns=_coerce_str_tuple(raw.get("ignore_patterns", []), "ignore_patterns"),
        api_key_env=_parse_api_key_env(raw.get("api_key_env")),
        check=_parse_check(tasks.get("check")),
        version_audit=_parse_version_audit(tasks.get("version_audit")),
    )


def load(path: Path) -> ForerunnerConfig:
    """Load and validate a config file. Empty file = all defaults."""
    text = path.read_text(encoding="utf-8")
    try:
        raw = yaml.safe_load(text)
    except yaml.YAMLError as e:
        raise ConfigError(f"{path}: invalid YAML: {e}") from e
    return parse(raw)


def load_from_repo(repo: Path) -> ForerunnerConfig | None:
    """Return parsed config when `forerunner.config.yaml` is present, else None."""
    p = repo / CONFIG_FILENAME
    if not p.is_file():
        return None
    return load(p)
