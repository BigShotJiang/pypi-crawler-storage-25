"""Minimal stdio MCP server exposing prompt bundles as tools. See SPEC.md §D.mcp.

Hand-rolled JSON-RPC 2.0 over line-delimited stdio. Stdlib only.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Iterable

from codeforerunner import __version__ as _pkg_version
from codeforerunner.bundle import find_prompts_root, resolve_bundle

PROTOCOL_VERSION = "2025-03-26"
SERVER_NAME = "codeforerunner"
SERVER_VERSION = _pkg_version


def _list_tasks(prompts_root: Path) -> list[Path]:
    tasks_dir = prompts_root / "tasks"
    if not tasks_dir.is_dir():
        return []
    return sorted(tasks_dir.glob("*.md"))


def _description_for(task_path: Path) -> str:
    """First non-empty markdown line, stripped of leading '#' and whitespace."""
    for raw in task_path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line:
            continue
        return line.lstrip("#").strip()
    return task_path.stem


def _tools(prompts_root: Path) -> list[dict[str, Any]]:
    return [
        {
            "name": p.stem,
            "description": _description_for(p),
            "inputSchema": {"type": "object", "properties": {}, "required": []},
        }
        for p in _list_tasks(prompts_root)
    ]


def _ok(req_id: Any, result: Any) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": req_id, "result": result}


def _err(req_id: Any, code: int, message: str) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": req_id, "error": {"code": code, "message": message}}


SCAN_EXEMPT_TOOLS = frozenset({"init-agent-onboarding", "scan"})


def _handle(prompts_root: Path, msg: dict[str, Any], state: dict[str, Any]) -> dict[str, Any] | None:
    method = msg.get("method")
    req_id = msg.get("id")
    params = msg.get("params") or {}

    if method == "notifications/initialized":
        return None
    if req_id is None and isinstance(method, str) and method.startswith("notifications/"):
        return None

    if method == "initialize":
        return _ok(
            req_id,
            {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {"tools": {}},
                "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
            },
        )

    if method == "tools/list":
        return _ok(req_id, {"tools": _tools(prompts_root)})

    if method == "tools/call":
        name = params.get("name")
        task_path = prompts_root / "tasks" / f"{name}.md"
        if not isinstance(name, str) or not task_path.is_file():
            return _err(req_id, -32602, f"unknown tool: {name!r}")
        if name not in SCAN_EXEMPT_TOOLS and not state.get("scan_called"):
            return _err(
                req_id,
                -32000,
                "scan-first required: call tools/call name=scan before this task (SPEC V2)",
            )
        if name == "scan":
            state["scan_called"] = True
        try:
            text = resolve_bundle(prompts_root, name)
        except Exception as e:  # pragma: no cover - defensive
            return _err(req_id, -32603, f"internal error: {e}")
        return _ok(
            req_id,
            {"content": [{"type": "text", "text": text}], "isError": False},
        )

    return _err(req_id, -32601, f"method not found: {method!r}")


def serve(prompts_root: Path, stdin: Iterable[str] = sys.stdin, stdout=sys.stdout, stderr=sys.stderr) -> int:
    state: dict[str, Any] = {"scan_called": False}
    for raw in stdin:
        line = raw.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError as e:
            print(f"mcp_server: invalid JSON: {e}", file=stderr)
            resp = {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "parse error"}}
            stdout.write(json.dumps(resp) + "\n")
            stdout.flush()
            continue

        try:
            resp = _handle(prompts_root, msg, state)
        except Exception as e:  # pragma: no cover - defensive
            print(f"mcp_server: handler error: {e}", file=stderr)
            resp = _err(msg.get("id"), -32603, f"internal error: {e}")

        if resp is not None:
            stdout.write(json.dumps(resp) + "\n")
            stdout.flush()
    return 0


def main(argv: list[str] | None = None) -> int:
    try:
        prompts_root = find_prompts_root()
    except FileNotFoundError as e:
        print(f"mcp_server: {e}", file=sys.stderr)
        return 2
    return serve(prompts_root)


if __name__ == "__main__":
    raise SystemExit(main())
