"""Tool registry — single source of truth for agent tool definitions.

Every adapter (Claude, OpenAI, dynamic-discovery via tools.json) reads
from this registry. Each entry pairs a Pydantic args schema with a
handler that takes ``(client, **validated_args)`` and returns a
JSON-serialisable result.

Descriptions follow Anthropic's "use when X" pattern — agents read
descriptions to decide *when* to call a tool, so the first sentence
must describe the trigger condition. Param names mirror the SDK
(``dataset_name``, ``image_uuid``) so an agent that learned the SDK
docstrings can use the tools without re-learning the surface.

Why a registry (vs. one decorator per resource method): keeping the
list explicit lets us (1) curate which methods are agent-safe, (2)
attach role + credit_cost metadata for guardrails, (3) emit one
canonical JSON Schema for dynamic-discovery agents.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from pydantic import BaseModel

from pictograph.agents import _args
from pictograph.workflows.annotate import auto_annotate_dataset
from pictograph.workflows.pipeline import full_pipeline
from pictograph.workflows.train import train_pipeline
from pictograph.workflows.upload import upload_dataset_from_folder

if TYPE_CHECKING:
    from collections.abc import Callable

    from pictograph import Client


RequiredRole = Literal["viewer", "member", "admin", "owner"]
"""Minimum role required to invoke a tool. Backend re-enforces server-side."""


@dataclass(frozen=True)
class ToolDescriptor:
    """A single agent-callable tool.

    Attributes:
        name: Snake-case identifier exposed to agents (e.g. ``upload_dataset_from_folder``).
        description: Agent-facing description. Lead with "Use when X" — agents
            read this to choose between tools.
        args_schema: Pydantic v2 model class. Generates the JSON Schema agents see;
            handler receives an instance of this model.
        handler: ``(client, args_model) -> Any``. Returns a JSON-serialisable result
            (dict, list, primitive). Pydantic models are dumped via ``model_dump``.
        idempotent: When True, agents may safely retry on transient failures.
            False for create/delete/upload (avoid double-charge).
        required_role: Minimum org-member role.
        credit_cost: Approximate cost (0 for read-only / free ops). Agents may
            gate based on this + ``client.credits.balance()``.
    """

    name: str
    description: str
    args_schema: type[BaseModel]
    handler: Callable[[Client, BaseModel], Any]
    idempotent: bool
    required_role: RequiredRole
    credit_cost: int


# ═════════════════════════════════════════════════════════════════════
# Handlers
#
# Each handler accepts (client, args) where args is the Pydantic model
# instance. Returns a JSON-serialisable result. Pydantic models from
# the SDK are dumped via model_dump(mode="json"); workflow report
# dataclasses are converted via __dict__ + manual dataclass walking
# (asdict isn't safe with Pydantic models inside).
# ═════════════════════════════════════════════════════════════════════


def _dump(obj: Any) -> Any:
    """Recursively coerce Pydantic models / dataclasses to JSON-friendly dicts."""
    if isinstance(obj, BaseModel):
        return obj.model_dump(mode="json", exclude_none=True)
    if isinstance(obj, list | tuple):
        return [_dump(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _dump(v) for k, v in obj.items()}
    if hasattr(obj, "__dataclass_fields__"):
        return {f: _dump(getattr(obj, f)) for f in obj.__dataclass_fields__}
    return obj


# ───────────── workflows ─────────────


def _h_upload_dataset_from_folder(
    client: Client, args: BaseModel
) -> Any:
    assert isinstance(args, _args.UploadDatasetFromFolderArgs)
    report = upload_dataset_from_folder(
        client,
        args.dataset_name,
        args.folder,
        organize_by_class=args.organize_by_class,
        max_workers=args.max_workers,
        skip_existing=args.skip_existing,
    )
    return _dump(report)


def _h_auto_annotate_dataset(
    client: Client, args: BaseModel
) -> Any:
    assert isinstance(args, _args.AutoAnnotateDatasetArgs)
    report = auto_annotate_dataset(
        client,
        args.dataset_name,
        classes=args.classes,
        mode=args.mode,
        confidence_threshold=args.confidence_threshold,
        overwrite=args.overwrite,
        max_images=args.max_images,
    )
    return _dump(report)


def _h_train_pipeline(client: Client, args: BaseModel) -> Any:
    assert isinstance(args, _args.TrainPipelineArgs)
    run, model = train_pipeline(
        client,
        args.dataset_name,
        pipeline=args.pipeline,
        gpu=args.gpu,
        name=args.name,
        config=args.config,
        wait=args.wait,
    )
    return {"training_run": _dump(run), "model": _dump(model)}


def _h_full_pipeline(client: Client, args: BaseModel) -> Any:
    assert isinstance(args, _args.FullPipelineArgs)
    report = full_pipeline(
        client,
        dataset_name=args.dataset_name,
        folder=args.folder,
        classes=args.classes,
        pipeline=args.pipeline,
        gpu=args.gpu,
        annotate=args.annotate,
        train=args.train,
    )
    return _dump(report)


# ───────────── datasets ─────────────


def _h_list_datasets(client: Client, args: BaseModel) -> Any:
    assert isinstance(args, _args.ListDatasetsArgs)
    datasets = client.datasets.list(limit=args.limit)
    return {"datasets": _dump(datasets), "count": len(datasets)}


def _h_get_dataset(client: Client, args: BaseModel) -> Any:
    assert isinstance(args, _args.GetDatasetArgs)
    dataset = client.datasets.get(
        args.name,
        include_images=args.include_images,
        images_limit=args.images_limit,
    )
    return _dump(dataset)


def _h_create_dataset(client: Client, args: BaseModel) -> Any:
    assert isinstance(args, _args.CreateDatasetArgs)
    project = client.projects.create(args.name, description=args.description)
    return _dump(project)


def _h_delete_dataset(client: Client, args: BaseModel) -> Any:
    assert isinstance(args, _args.DeleteDatasetArgs)
    client.projects.delete(args.name)
    return {"deleted": True, "name": args.name}


# ───────────── images ─────────────


def _h_upload_image(client: Client, args: BaseModel) -> Any:
    assert isinstance(args, _args.UploadImageArgs)
    project = client.projects.get(args.dataset_name)
    image = client.images.upload(
        dataset_id=project.id,
        file_path=Path(args.file_path),
        folder_path=args.folder_path,
    )
    return _dump(image)


def _h_delete_image(client: Client, args: BaseModel) -> Any:
    assert isinstance(args, _args.DeleteImageArgs)
    client.images.delete(args.image_uuid)
    return {"deleted": True, "image_uuid": args.image_uuid}


# ───────────── annotations ─────────────


def _h_get_annotations(client: Client, args: BaseModel) -> Any:
    assert isinstance(args, _args.GetAnnotationsArgs)
    anns = client.annotations.get(args.image_uuid)
    return {"annotations": _dump(anns), "count": len(anns)}


def _h_save_annotations(client: Client, args: BaseModel) -> Any:
    from pydantic import TypeAdapter

    from pictograph.models.annotation import Annotation

    assert isinstance(args, _args.SaveAnnotationsArgs)
    adapter: TypeAdapter[list[Annotation]] = TypeAdapter(list[Annotation])
    parsed = adapter.validate_python(args.annotations)
    result = client.annotations.save(args.image_uuid, parsed)
    return _dump(result)


# ───────────── auto-annotate (single prompt) ─────────────


def _h_auto_annotate_point(
    client: Client, args: BaseModel
) -> Any:
    if not isinstance(args, _args.AutoAnnotatePointArgs):
        raise TypeError(f"Expected AutoAnnotatePointArgs, got {type(args).__name__}")
    pos = (
        [(p[0], p[1]) for p in args.positive_points]
        if args.positive_points
        else None
    )
    neg = (
        [(p[0], p[1]) for p in args.negative_points]
        if args.negative_points
        else None
    )
    result = client.auto_annotate.point(
        dataset_name=args.dataset_name,
        image_filename=args.image_filename,
        x=args.x,
        y=args.y,
        name=args.name,
        positive_points=pos,
        negative_points=neg,
        score_threshold=args.score_threshold,
    )
    return _dump(result)


def _h_auto_annotate_box(client: Client, args: BaseModel) -> Any:
    if not isinstance(args, _args.AutoAnnotateBoxArgs):
        raise TypeError(f"Expected AutoAnnotateBoxArgs, got {type(args).__name__}")
    result = client.auto_annotate.box(
        dataset_name=args.dataset_name,
        image_filename=args.image_filename,
        box=args.box,
        name=args.name,
        confidence_threshold=args.confidence_threshold,
        return_polygon=args.return_polygon,
        negative_boxes=args.negative_boxes,
    )
    return _dump(result)


def _h_auto_annotate_text(
    client: Client, args: BaseModel
) -> Any:
    assert isinstance(args, _args.AutoAnnotateTextArgs)
    result = client.auto_annotate.text(
        dataset_name=args.dataset_name,
        image_filename=args.image_filename,
        text_prompt=args.text_prompt,
        output_type=args.output_type,
        confidence_threshold=args.confidence_threshold,
    )
    return _dump(result)


# ───────────── search ─────────────


def _h_search_by_tag(client: Client, args: BaseModel) -> Any:
    assert isinstance(args, _args.SearchByTagArgs)
    results = client.search.by_tag(
        dataset_name=args.dataset_name,
        objects=args.objects,
        scenes=args.scenes,
        attributes=args.attributes,
        limit=args.limit,
    )
    return {"images": _dump(results), "count": len(results)}


def _h_search_by_similarity(
    client: Client, args: BaseModel
) -> Any:
    assert isinstance(args, _args.SearchBySimilarityArgs)
    results = client.search.by_similarity(
        args.image_id,
        threshold=args.threshold,
        limit=args.limit,
        folder_path=args.folder_path,
    )
    return {"images": _dump(results), "count": len(results)}


# ───────────── exports ─────────────


def _h_create_export(client: Client, args: BaseModel) -> Any:
    assert isinstance(args, _args.CreateExportArgs)
    export = client.exports.create(
        args.dataset_name,
        args.name,
        format=args.format,
        include_images=args.include_images,
        class_filter=args.class_filter,
        status_filter=args.status_filter,
        wait=True,
    )
    return _dump(export)


def _h_list_exports(client: Client, args: BaseModel) -> Any:
    assert isinstance(args, _args.ListExportsArgs)
    exports = client.exports.list(limit=args.limit)
    return {"exports": _dump(exports), "count": len(exports)}


def _h_download_export(client: Client, args: BaseModel) -> Any:
    assert isinstance(args, _args.DownloadExportArgs)
    path = client.exports.download(
        args.dataset_name, args.export_name, output_path=Path(args.output_path)
    )
    return {"output_path": str(path)}


# ───────────── training ─────────────


def _h_get_training_status(
    client: Client, args: BaseModel
) -> Any:
    assert isinstance(args, _args.GetTrainingStatusArgs)
    run = client.training.get(args.run_id)
    return _dump(run)


def _h_cancel_training(client: Client, args: BaseModel) -> Any:
    assert isinstance(args, _args.CancelTrainingArgs)
    run = client.training.cancel(args.run_id)
    return _dump(run)


# ───────────── models ─────────────


def _h_list_models(client: Client, args: BaseModel) -> Any:
    assert isinstance(args, _args.ListModelsArgs)
    models = client.models.list(limit=args.limit)
    return {"models": _dump(models), "count": len(models)}


def _h_download_model(client: Client, args: BaseModel) -> Any:
    assert isinstance(args, _args.DownloadModelArgs)
    path = client.models.download(args.model_id, output_path=Path(args.output_path))
    return {"output_path": str(path)}


# ───────────── credits ─────────────


def _h_get_credit_balance(
    client: Client, args: BaseModel  # noqa: ARG001
) -> Any:
    balance = client.credits.balance()
    return _dump(balance)


def _h_estimate_credit_cost(
    client: Client, args: BaseModel
) -> Any:
    assert isinstance(args, _args.EstimateCreditCostArgs)
    estimate = client.credits.estimate(args.operation, quantity=args.quantity)
    return _dump(estimate)


# ───────────── connectors ─────────────


def _h_validate_connector(
    client: Client, args: BaseModel
) -> Any:
    assert isinstance(args, _args.ValidateConnectorArgs)
    result = client.connectors.validate(
        provider=args.provider, api_key=args.api_key,
    )
    return _dump(result)


def _h_import_from_connector(
    client: Client, args: BaseModel
) -> Any:
    assert isinstance(args, _args.ImportFromConnectorArgs)
    job = client.connectors.import_(
        args.provider,
        args.api_key,
        args.datasets,
    )
    return _dump(job)


# ═════════════════════════════════════════════════════════════════════
# REGISTRY — the canonical, ordered list of every agent-callable tool
# ═════════════════════════════════════════════════════════════════════


REGISTRY: list[ToolDescriptor] = [
    # ─── workflows (highest leverage, agent-friendly orchestration) ───
    ToolDescriptor(
        name="upload_dataset_from_folder",
        description=(
            "Use when the user asks to upload a folder of images to a dataset. "
            "Walks the folder recursively, ensures the dataset exists, and uploads "
            "every supported image (jpg/png/webp/etc.). Subdirectories become virtual "
            "folders by default. Returns a per-file failure report — partial success "
            "does not raise."
        ),
        args_schema=_args.UploadDatasetFromFolderArgs,
        handler=_h_upload_dataset_from_folder,
        idempotent=False,
        required_role="member",
        credit_cost=0,
    ),
    ToolDescriptor(
        name="auto_annotate_dataset",
        description=(
            "Use when the user wants to auto-annotate a dataset with one or more "
            "classes via SAM3. Default 'batch' mode runs an async job over many "
            "images (best for >10 images); 'text' mode runs synchronous per-image "
            "prompts (better for small datasets). Skips already-annotated images "
            "unless overwrite=True."
        ),
        args_schema=_args.AutoAnnotateDatasetArgs,
        handler=_h_auto_annotate_dataset,
        idempotent=False,
        required_role="member",
        credit_cost=10,  # SAM3 minimum session
    ),
    ToolDescriptor(
        name="train_pipeline",
        description=(
            "Use when the user wants to train a CV model from an existing annotated "
            "dataset. Creates a timestamped export, kicks off training on the chosen "
            "GPU tier, and (when wait=True) returns the trained model. Pipeline "
            "choice maps to model architecture (yolox=detection, "
            "detectron2=segmentation, etc.)."
        ),
        args_schema=_args.TrainPipelineArgs,
        handler=_h_train_pipeline,
        idempotent=False,
        required_role="member",
        credit_cost=100,  # rough estimate per run
    ),
    ToolDescriptor(
        name="full_pipeline",
        description=(
            "Use when the user wants the complete 'annotate this folder and give me "
            "an ONNX model' workflow. Chains upload -> auto-annotate -> train. Each "
            "phase short-circuits on failure; report carries every sub-report so "
            "you can pinpoint where the chain broke."
        ),
        args_schema=_args.FullPipelineArgs,
        handler=_h_full_pipeline,
        idempotent=False,
        required_role="member",
        credit_cost=110,
    ),
    # ─── datasets ───
    ToolDescriptor(
        name="list_datasets",
        description=(
            "Use to enumerate datasets in the user's organization. Returns up to "
            "`limit` datasets with name, image counts, and class definitions."
        ),
        args_schema=_args.ListDatasetsArgs,
        handler=_h_list_datasets,
        idempotent=True,
        required_role="viewer",
        credit_cost=0,
    ),
    ToolDescriptor(
        name="get_dataset",
        description=(
            "Use when you need details on a specific dataset by name. "
            "Set include_images=True to also get image summaries (id, filename, "
            "annotation_count) — useful before iterating images."
        ),
        args_schema=_args.GetDatasetArgs,
        handler=_h_get_dataset,
        idempotent=True,
        required_role="viewer",
        credit_cost=0,
    ),
    ToolDescriptor(
        name="create_dataset",
        description=(
            "Use to create a new empty dataset (project). Names must be unique within "
            "the organization. Most workflows auto-create datasets — only call this "
            "directly when the user explicitly asks to create one."
        ),
        args_schema=_args.CreateDatasetArgs,
        handler=_h_create_dataset,
        idempotent=False,
        required_role="member",
        credit_cost=0,
    ),
    ToolDescriptor(
        name="delete_dataset",
        description=(
            "Use to permanently delete a dataset and all its images. THIS IS "
            "IRREVERSIBLE. Only call after explicit user confirmation."
        ),
        args_schema=_args.DeleteDatasetArgs,
        handler=_h_delete_dataset,
        idempotent=True,
        required_role="admin",
        credit_cost=0,
    ),
    # ─── images ───
    ToolDescriptor(
        name="upload_image",
        description=(
            "Use to upload a single image to a dataset. For bulk uploads from a "
            "folder, prefer upload_dataset_from_folder."
        ),
        args_schema=_args.UploadImageArgs,
        handler=_h_upload_image,
        idempotent=False,
        required_role="member",
        credit_cost=0,
    ),
    ToolDescriptor(
        name="delete_image",
        description=(
            "Use to permanently delete a single image. THIS IS IRREVERSIBLE. "
            "Only call after explicit user confirmation."
        ),
        args_schema=_args.DeleteImageArgs,
        handler=_h_delete_image,
        idempotent=True,
        required_role="member",
        credit_cost=0,
    ),
    # ─── annotations ───
    ToolDescriptor(
        name="get_annotations",
        description=(
            "Use to read the current annotations on an image. Returns a list of "
            "typed annotation objects (bbox, polygon, polyline, keypoint)."
        ),
        args_schema=_args.GetAnnotationsArgs,
        handler=_h_get_annotations,
        idempotent=True,
        required_role="viewer",
        credit_cost=0,
    ),
    ToolDescriptor(
        name="save_annotations",
        description=(
            "Use to replace the annotations on an image (FULL OVERWRITE — pass "
            "the complete list every time). Each annotation requires id, name "
            "(class label), type, and the type-specific geometry field. The class "
            "label MUST exist in the dataset's project_config."
        ),
        args_schema=_args.SaveAnnotationsArgs,
        handler=_h_save_annotations,
        idempotent=True,  # POST is full-replacement, so retries are safe
        required_role="member",
        credit_cost=0,
    ),
    # ─── auto-annotate (single prompt) ───
    ToolDescriptor(
        name="auto_annotate_point",
        description=(
            "Use when the user knows the location of an object and wants SAM3 to "
            "segment it from a click. Provide one or more positive points (label=1) "
            "to include and optional negative points (label=0) to exclude. Returns "
            "annotation(s) — does NOT save them. Call save_annotations to persist."
        ),
        args_schema=_args.AutoAnnotatePointArgs,
        handler=_h_auto_annotate_point,
        idempotent=False,
        required_role="member",
        credit_cost=1,
    ),
    ToolDescriptor(
        name="auto_annotate_box",
        description=(
            "Use when the user wants SAM3 to segment everything inside a bounding "
            "box. Returns annotation(s) — does NOT save them. Call save_annotations "
            "to persist."
        ),
        args_schema=_args.AutoAnnotateBoxArgs,
        handler=_h_auto_annotate_box,
        idempotent=False,
        required_role="member",
        credit_cost=1,
    ),
    ToolDescriptor(
        name="auto_annotate_text",
        description=(
            "Use when the user wants SAM3 to find all instances of a described class "
            "in an image (e.g. 'find all red cars'). Returns annotation(s) — does NOT "
            "save them. Call save_annotations to persist."
        ),
        args_schema=_args.AutoAnnotateTextArgs,
        handler=_h_auto_annotate_text,
        idempotent=False,
        required_role="member",
        credit_cost=1,
    ),
    # ─── search ───
    ToolDescriptor(
        name="search_by_tag",
        description=(
            "Use when the user wants to find images by automatic content tags "
            "(objects/scenes/attributes). Pass at least one of objects, scenes, or "
            "attributes. Empty/None means 'any'."
        ),
        args_schema=_args.SearchByTagArgs,
        handler=_h_search_by_tag,
        idempotent=True,
        required_role="viewer",
        credit_cost=0,
    ),
    ToolDescriptor(
        name="search_by_similarity",
        description=(
            "Use when the user wants images visually similar to a reference image "
            "(SigLIP2 cosine similarity). Returns up to `limit` similar images, "
            "ranked by similarity score."
        ),
        args_schema=_args.SearchBySimilarityArgs,
        handler=_h_search_by_similarity,
        idempotent=True,
        required_role="viewer",
        credit_cost=0,
    ),
    # ─── exports ───
    ToolDescriptor(
        name="create_export",
        description=(
            "Use when the user wants a downloadable ZIP of a dataset's images and "
            "annotations in a chosen format. Blocks until the export is built. "
            "Default format is 'pictograph' (canonical JSON); other options support "
            "common ML formats (COCO, YOLO, etc.)."
        ),
        args_schema=_args.CreateExportArgs,
        handler=_h_create_export,
        idempotent=False,
        required_role="member",
        credit_cost=0,
    ),
    ToolDescriptor(
        name="list_exports",
        description="Use to list previously created exports.",
        args_schema=_args.ListExportsArgs,
        handler=_h_list_exports,
        idempotent=True,
        required_role="viewer",
        credit_cost=0,
    ),
    ToolDescriptor(
        name="download_export",
        description=(
            "Use to download an export ZIP to a local file path. Streams the file in "
            "chunks; safe for large exports."
        ),
        args_schema=_args.DownloadExportArgs,
        handler=_h_download_export,
        idempotent=True,
        required_role="viewer",
        credit_cost=0,
    ),
    # ─── training ───
    ToolDescriptor(
        name="get_training_status",
        description=(
            "Use to check the status of a training run by ID. Returns current "
            "status, progress %, current epoch, and metrics."
        ),
        args_schema=_args.GetTrainingStatusArgs,
        handler=_h_get_training_status,
        idempotent=True,
        required_role="viewer",
        credit_cost=0,
    ),
    ToolDescriptor(
        name="cancel_training",
        description=(
            "Use to cancel an in-flight training run. Stops the Modal worker and "
            "refunds remaining GPU minutes. Only call after user confirmation."
        ),
        args_schema=_args.CancelTrainingArgs,
        handler=_h_cancel_training,
        idempotent=True,
        required_role="member",
        credit_cost=0,
    ),
    # ─── models ───
    ToolDescriptor(
        name="list_models",
        description=(
            "Use to list trained models in the organization. Returns model "
            "metadata (architecture, metrics, status)."
        ),
        args_schema=_args.ListModelsArgs,
        handler=_h_list_models,
        idempotent=True,
        required_role="viewer",
        credit_cost=0,
    ),
    ToolDescriptor(
        name="download_model",
        description=(
            "Use to download a trained model's ONNX weights to a local file. "
            "Only 'ready' models are downloadable."
        ),
        args_schema=_args.DownloadModelArgs,
        handler=_h_download_model,
        idempotent=True,
        required_role="viewer",
        credit_cost=0,
    ),
    # ─── credits ───
    ToolDescriptor(
        name="get_credit_balance",
        description=(
            "Use to check the organization's current credit balance. Returns "
            "remaining credits, monthly allowance, and last 20 ledger entries."
        ),
        args_schema=_args.GetCreditBalanceArgs,
        handler=_h_get_credit_balance,
        idempotent=True,
        required_role="viewer",
        credit_cost=0,
    ),
    ToolDescriptor(
        name="estimate_credit_cost",
        description=(
            "Use BEFORE invoking a paid operation (training, batch SAM3, image "
            "generation) to check whether the org has enough credits. Inspect "
            ".sufficient on the result to gate."
        ),
        args_schema=_args.EstimateCreditCostArgs,
        handler=_h_estimate_credit_cost,
        idempotent=True,
        required_role="viewer",
        credit_cost=0,
    ),
    # ─── connectors ───
    ToolDescriptor(
        name="validate_connector",
        description=(
            "Use to validate a V7 or Roboflow API key and list the user's available "
            "remote datasets. Call before import_from_connector."
        ),
        args_schema=_args.ValidateConnectorArgs,
        handler=_h_validate_connector,
        idempotent=True,
        required_role="member",
        credit_cost=0,
    ),
    ToolDescriptor(
        name="import_from_connector",
        description=(
            "Use to import one or more remote datasets from V7 or Roboflow into "
            "Pictograph. Returns an import job ID; poll connectors for status."
        ),
        args_schema=_args.ImportFromConnectorArgs,
        handler=_h_import_from_connector,
        idempotent=False,
        required_role="member",
        credit_cost=0,
    ),
]
"""Canonical tool list. Adapter outputs derive entirely from this."""


def get_tool(name: str) -> ToolDescriptor:
    """Look up a tool by name. Raises ``KeyError`` if missing."""
    for tool in REGISTRY:
        if tool.name == name:
            return tool
    raise KeyError(f"No agent tool registered with name {name!r}")


def tool_names() -> list[str]:
    """All registered tool names, in registry order."""
    return [t.name for t in REGISTRY]
