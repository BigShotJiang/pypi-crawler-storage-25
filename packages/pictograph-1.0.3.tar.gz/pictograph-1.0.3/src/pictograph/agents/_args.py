"""Pydantic argument schemas for every agent tool.

These models are the source of truth for the tool registry's
``input_schema`` JSON Schemas. Keeping them in their own module
ensures: (1) handlers in ``_registry.py`` import only from here,
(2) Pydantic generates a stable JSON Schema per tool, and
(3) descriptions in ``Field(..., description=...)`` flow through to
the agent-facing schema unmodified — agents read these descriptions
to decide *when* to use a parameter.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class _ToolArgs(BaseModel):
    """Common config: agents must pass exactly the declared fields."""

    model_config = ConfigDict(extra="forbid")


# ───────────── workflows ─────────────


class UploadDatasetFromFolderArgs(_ToolArgs):
    """Walk a local folder, ensure the dataset exists, upload every supported image."""

    dataset_name: str = Field(
        description="Destination dataset (project) name within your organization. Created if missing.",
    )
    folder: str = Field(
        description=(
            "Absolute or ~-relative path to the local folder. Walked recursively. "
            "Supported extensions: jpg/jpeg/png/webp/bmp/tif/tiff/gif/heic."
        ),
    )
    organize_by_class: bool = Field(
        default=True,
        description=(
            "When true, each first-level subdirectory becomes a virtual folder on "
            "the dataset (e.g. 'images/cars/x.jpg' lands under '/cars'). When false, "
            "every image lands at root."
        ),
    )
    max_workers: int = Field(
        default=8,
        ge=1,
        le=32,
        description="Concurrent upload threads. Default 8.",
    )
    skip_existing: bool = Field(
        default=True,
        description=(
            "When true (default), images that already exist in the same folder are "
            "recorded as 'skipped' rather than failures."
        ),
    )


class AutoAnnotateDatasetArgs(_ToolArgs):
    """Run SAM3 over a dataset and save the resulting annotations."""

    dataset_name: str = Field(
        description="Dataset (project) name. Must already exist.",
    )
    classes: list[dict[str, str]] = Field(
        description=(
            "Class configs to detect. Each entry: "
            "{'name': 'car', 'output_type': 'polygon'|'bbox'|'tag'}. "
            "Default output_type is 'polygon'."
        ),
        min_length=1,
    )
    mode: Literal["batch", "text"] = Field(
        default="batch",
        description=(
            "'batch' (default) — async batch job over many images. "
            "'text' — synchronous per-image text prompt (slow; small datasets only)."
        ),
    )
    confidence_threshold: float = Field(
        default=0.5,
        ge=0.0,
        le=1.0,
        description="SAM3 confidence cutoff. Detections below this are dropped.",
    )
    overwrite: bool = Field(
        default=False,
        description=(
            "When false (default), images that already have annotations are skipped. "
            "When true, every image is re-annotated."
        ),
    )
    max_images: int | None = Field(
        default=None,
        ge=1,
        description="Cap the number of images processed (useful for dry-runs).",
    )


class TrainPipelineArgs(_ToolArgs):
    """Export a dataset and kick off a training run end-to-end."""

    dataset_name: str = Field(description="Dataset (project) name.")
    pipeline: Literal[
        "yolox", "detectron2", "sm_pytorch", "classification",
        "rfdetr_detection", "rfdetr_segmentation",
    ] = Field(
        description=(
            "Training pipeline. yolox=object detection, detectron2=instance segmentation, "
            "sm_pytorch=semantic segmentation, classification=image-level labels, "
            "rfdetr_detection/segmentation=DETR-based."
        ),
    )
    gpu: Literal["a10g", "a100", "h100"] = Field(
        default="a10g",
        description="GPU tier. Higher tiers cost more credits per minute.",
    )
    name: str | None = Field(
        default=None,
        description="Training run name. Defaults to a timestamped slug.",
    )
    config: dict[str, Any] | None = Field(
        default=None,
        description="Pipeline-specific hyperparameters (e.g. {'epochs': 50}). Defaults to pipeline defaults.",
    )
    wait: bool = Field(
        default=True,
        description="Block until training reaches a terminal state. Set false to fire-and-forget.",
    )


class FullPipelineArgs(_ToolArgs):
    """Upload → auto-annotate → train, end-to-end."""

    dataset_name: str = Field(description="Destination dataset (created if missing).")
    folder: str = Field(description="Local folder of images to upload.")
    classes: list[dict[str, str]] = Field(
        description="Class configs for both annotation and training. See auto_annotate_dataset for shape.",
        min_length=1,
    )
    pipeline: Literal[
        "yolox", "detectron2", "sm_pytorch", "classification",
        "rfdetr_detection", "rfdetr_segmentation",
    ] = Field(description="Training pipeline.")
    gpu: Literal["a10g", "a100", "h100"] = Field(default="a10g")
    annotate: bool = Field(
        default=True,
        description="When false, skip the auto-annotate phase (annotations already saved).",
    )
    train: bool = Field(
        default=True,
        description="When false, skip the training phase (annotate-only).",
    )


# ───────────── datasets ─────────────


class ListDatasetsArgs(_ToolArgs):
    """List datasets in the authenticated organization."""

    limit: int = Field(default=100, ge=1, le=1000, description="Max datasets returned.")


class GetDatasetArgs(_ToolArgs):
    """Fetch a dataset by name."""

    name: str = Field(description="Dataset (project) name.")
    include_images: bool = Field(
        default=False,
        description="When true, include the first images_limit image summaries.",
    )
    images_limit: int = Field(default=1000, ge=1, le=10000)


class CreateDatasetArgs(_ToolArgs):
    """Create a new dataset (project)."""

    name: str = Field(description="Dataset name. Unique within the organization.")
    description: str | None = Field(default=None)


class DeleteDatasetArgs(_ToolArgs):
    """Permanently delete a dataset and all its images."""

    name: str = Field(description="Dataset name.")


# ───────────── images ─────────────


class UploadImageArgs(_ToolArgs):
    """Upload a single image to a dataset."""

    dataset_name: str = Field(description="Destination dataset name.")
    file_path: str = Field(description="Absolute path to the local image file.")
    folder_path: str = Field(
        default="/",
        description="Virtual folder path on the dataset (e.g. '/cars').",
    )


class DeleteImageArgs(_ToolArgs):
    """Delete a single image by UUID."""

    image_uuid: str = Field(description="Image UUID.")


# ───────────── annotations ─────────────


class GetAnnotationsArgs(_ToolArgs):
    """Fetch the annotations attached to an image."""

    image_uuid: str = Field(description="Image UUID.")


class SaveAnnotationsArgs(_ToolArgs):
    """Replace the annotations on an image (full overwrite)."""

    image_uuid: str = Field(description="Image UUID.")
    annotations: list[dict[str, Any]] = Field(
        description=(
            "List of annotation dicts in canonical Pictograph JSON. Each requires: "
            "id, name, type ('bbox'|'polygon'|'polyline'|'keypoint'), and the type-specific "
            "geometry field (bounding_box / polygon / polyline / keypoint)."
        ),
    )


# ───────────── auto-annotate (single prompt) ─────────────


class AutoAnnotatePointArgs(_ToolArgs):
    """Run a single SAM3 point prompt on an image. Use for 'click here, segment that object'."""

    dataset_name: str = Field(description="Dataset name.")
    image_filename: str = Field(description="Image filename (within the dataset).")
    x: int = Field(description="Anchor point X coordinate in absolute pixels.")
    y: int = Field(description="Anchor point Y coordinate in absolute pixels.")
    name: str = Field(default="object", description="Class label for the resulting annotation.")
    positive_points: list[list[int]] | None = Field(
        default=None,
        description="Extra positive (include) anchor points as [[x, y], ...].",
    )
    negative_points: list[list[int]] | None = Field(
        default=None,
        description="Negative (exclude) anchor points as [[x, y], ...].",
    )
    score_threshold: float = Field(default=0.75, ge=0.0, le=1.0)


class AutoAnnotateBoxArgs(_ToolArgs):
    """Run a single SAM3 box prompt on an image. Use for 'segment everything inside this box'."""

    dataset_name: str = Field(description="Dataset name.")
    image_filename: str = Field(description="Image filename.")
    box: dict[str, float] = Field(
        description="Box prompt as {x, y, w, h} in pixel coordinates.",
    )
    name: str = Field(description="Class label.")
    confidence_threshold: float = Field(default=0.5, ge=0.0, le=1.0)
    return_polygon: bool = Field(
        default=True,
        description="When true, return a polygon annotation in addition to the refined bbox.",
    )
    negative_boxes: list[dict[str, float]] | None = Field(
        default=None,
        description="Boxes to exclude from segmentation (shift-drag exclusion zones).",
    )


class AutoAnnotateTextArgs(_ToolArgs):
    """Run a SAM3 open-vocabulary text prompt on an image. Use for 'find all <thing>'."""

    dataset_name: str = Field(description="Dataset name.")
    image_filename: str = Field(description="Image filename.")
    text_prompt: str = Field(
        description="Open-vocabulary text prompt (e.g. 'red cars', 'damaged tiles').",
    )
    output_type: Literal["polygon", "bbox"] = Field(default="polygon")
    confidence_threshold: float = Field(default=0.5, ge=0.0, le=1.0)


# ───────────── search ─────────────


class SearchByTagArgs(_ToolArgs):
    """Find images tagged with one or more auto-tags (objects/scenes/attributes)."""

    dataset_name: str = Field(description="Dataset name.")
    objects: list[str] | None = Field(
        default=None,
        description="Object tags (e.g. ['car', 'truck']). At least one of objects/scenes/attributes required.",
    )
    scenes: list[str] | None = Field(
        default=None,
        description="Scene tags (e.g. ['outdoor', 'urban']).",
    )
    attributes: list[str] | None = Field(
        default=None,
        description="Attribute tags (e.g. ['blurry', 'low-light']).",
    )
    limit: int = Field(default=50, ge=1, le=500)


class SearchBySimilarityArgs(_ToolArgs):
    """Find images visually similar to a reference image (SigLIP2 cosine similarity)."""

    image_id: str = Field(description="UUID of the reference image. Scope is its dataset + folder.")
    threshold: float = Field(
        default=0.6,
        ge=0.0,
        le=1.0,
        description="Minimum cosine similarity. Default 0.6 = 'visually related' cutoff.",
    )
    limit: int = Field(default=50, ge=1, le=500)
    folder_path: str | None = Field(
        default=None,
        description="Override the source image's folder. Pass '/' to search the dataset root.",
    )


# ───────────── exports ─────────────


class CreateExportArgs(_ToolArgs):
    """Create a dataset export (ZIP of images + annotations in chosen format)."""

    dataset_name: str = Field(description="Dataset name.")
    name: str = Field(description="Export name. Must be unique within the dataset.")
    format: Literal[
        "pictograph", "coco", "csv", "cvat", "labelme", "pascal_voc", "yolo"
    ] = Field(default="pictograph", description="Export format.")
    include_images: bool = Field(
        default=True,
        description="When true, embeds the original image files in the ZIP.",
    )
    class_filter: list[str] | None = Field(
        default=None,
        description="Limit the export to these class names. None = all classes.",
    )
    status_filter: Literal["all", "complete", "in_progress", "new"] = Field(
        default="complete",
        description="Image-status filter. Default 'complete' = annotation-finalised images only.",
    )


class ListExportsArgs(_ToolArgs):
    """List all exports in the authenticated organization."""

    limit: int = Field(default=50, ge=1, le=500)


class DownloadExportArgs(_ToolArgs):
    """Download an export ZIP to a local file."""

    dataset_name: str = Field(description="Dataset name.")
    export_name: str = Field(description="Export name.")
    output_path: str = Field(description="Local path to write the ZIP file.")


# ───────────── training ─────────────


class GetTrainingStatusArgs(_ToolArgs):
    """Fetch the current state of a training run."""

    run_id: str = Field(description="Training run UUID.")


class CancelTrainingArgs(_ToolArgs):
    """Cancel an in-flight training run."""

    run_id: str = Field(description="Training run UUID.")


# ───────────── models ─────────────


class ListModelsArgs(_ToolArgs):
    """List trained models in the authenticated organization."""

    limit: int = Field(default=50, ge=1, le=500)


class DownloadModelArgs(_ToolArgs):
    """Download a trained model's ONNX weights to a local file."""

    model_id: str = Field(description="Model UUID.")
    output_path: str = Field(description="Local path to write the ONNX file.")


# ───────────── credits ─────────────


class GetCreditBalanceArgs(_ToolArgs):
    """Fetch the organization's current credit balance and last 20 ledger entries."""


class EstimateCreditCostArgs(_ToolArgs):
    """Estimate the credit cost of a planned operation before invoking it."""

    operation: str = Field(
        description=(
            "Operation slug. Common values: 'training_a10g', 'training_a100', "
            "'training_h100', 'sam3_auto_annotation', 'inference_t4', "
            "'image_generate_imagen_fast', 'image_edit_gemini_flash'."
        ),
    )
    quantity: int = Field(default=1, ge=1, description="Units (minutes/images/runs).")


# ───────────── connectors ─────────────


class ValidateConnectorArgs(_ToolArgs):
    """Validate a V7/Roboflow API key and list available remote datasets."""

    provider: Literal["v7", "roboflow"] = Field(description="Connector provider.")
    api_key: str = Field(description="API key for the remote service.")


class ImportFromConnectorArgs(_ToolArgs):
    """Kick off a remote dataset import from V7 or Roboflow."""

    provider: Literal["v7", "roboflow"] = Field(description="Connector provider.")
    api_key: str = Field(description="API key for the remote service.")
    datasets: list[dict[str, Any]] = Field(
        description=(
            "Remote datasets to import. Each entry: {id, name, slug, "
            "image_count?, version?}. Typically obtained from validate_connector."
        ),
        min_length=1,
    )
