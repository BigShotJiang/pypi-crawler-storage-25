"""Train-pipeline workflow.

Chains export creation → training run → optional model fetch into a
single call. The export is auto-named ``"<pipeline>-<timestamp>"`` so the
workflow doesn't collide with manual exports the user may have created.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pictograph import Client
    from pictograph.models.model import Model
    from pictograph.models.training import GpuType, PipelineType, TrainingRun


def train_pipeline(
    client: Client,
    dataset_name: str,
    *,
    pipeline: PipelineType,
    gpu: GpuType = "a10g",
    name: str | None = None,
    config: dict[str, Any] | None = None,
    export_name: str | None = None,
    class_filter: list[str] | None = None,
    status_filter: str = "complete",
    wait: bool = True,
    poll_interval: float = 5.0,
    timeout: float = 7200.0,
) -> tuple[TrainingRun, Model | None]:
    """Export a dataset and kick off a training run end-to-end.

    Args:
        client: Authenticated :class:`pictograph.Client`.
        dataset_name: Project name.
        pipeline: Training pipeline (``"yolox"``, ``"detectron2"``, …).
        gpu: GPU type (``"a10g"`` default, ``"a100"``, ``"h100"``).
        name: Training run name. Defaults to a timestamp-based slug.
        config: Pipeline-specific hyperparameters (epochs, batch_size, …).
            Defaults to ``{}`` (pipeline defaults).
        export_name: Override the auto-generated export name.
        class_filter: Limit the export (and thus training) to these classes.
        status_filter: Image-status filter for the export. Defaults to
            ``"complete"`` — train only on annotation-finalised images.
        wait: When ``True`` (default), block until the training run
            reaches a terminal status. Returns ``(TrainingRun, Model)``
            on success. When ``False``, the second tuple element is
            ``None``.
        poll_interval: Seconds between training poll checks (5s default).
        timeout: Max seconds to wait for training (default 7200 = 2h).

    Returns:
        A tuple ``(TrainingRun, Model | None)``. The model is fetched
        only when ``wait=True`` and training completed successfully.

    Raises:
        NotFoundError: Dataset doesn't exist or has no completed images.
        ValidationError: Pipeline / gpu invalid.
        PaymentRequiredError: Insufficient credits.
        ApiError: Training failed (when ``wait=True``).
        PollTimeoutError: Deadline elapsed (when ``wait=True``).
    """
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    resolved_export_name = export_name or f"{pipeline}-{timestamp}"
    resolved_run_name = name or f"{pipeline}-run-{timestamp}"

    # Step 1: create the export and wait for it.
    client.exports.create(
        dataset_name,
        resolved_export_name,
        format="pictograph",
        include_images=True,
        class_filter=class_filter,
        status_filter=status_filter,
        wait=True,
    )

    # Step 2: spawn training. ``wait`` controls whether we poll training too.
    run = client.training.create(
        dataset_name,
        resolved_export_name,
        pipeline_type=pipeline,
        name=resolved_run_name,
        config=config or {},
        gpu_type=gpu,
        wait=wait,
        poll_interval=poll_interval,
        timeout=timeout,
    )

    # Step 3: fetch the resulting model when training succeeded.
    model: Model | None = None
    if wait and run.status == "completed" and run.model_id:
        model = client.models.get(run.model_id)

    return run, model
