"""Batteries-included workflows that compose multiple resources.

Each helper takes a :class:`pictograph.Client` plus a small set of
arguments and orchestrates the multi-step recipe an agent would
otherwise have to chain together. They're standalone functions (not
methods on Client) so they can be imported individually and so the
Client class stays a thin resource container.

Three building blocks + one chain:

- :func:`upload_dataset_from_folder` — walk a local directory, create
  the dataset if missing, upload every image, optionally use
  subdirectory names as virtual folders.
- :func:`auto_annotate_dataset` — paginate the dataset, run SAM3
  text/box prompts per image, save the annotations.
- :func:`train_pipeline` — create an export, wait, kick off training,
  wait, return the trained Model.
- :func:`full_pipeline` — chain all three end-to-end.

Every workflow returns a structured report so partial failures don't
silently swallow data — inspect ``.failures`` to retry the subset.
"""

from pictograph.workflows.annotate import (
    AnnotateReport,
    AnnotationFailure,
    auto_annotate_dataset,
)
from pictograph.workflows.pipeline import PipelineReport, full_pipeline
from pictograph.workflows.train import train_pipeline
from pictograph.workflows.upload import (
    UploadFailure,
    UploadReport,
    upload_dataset_from_folder,
)

__all__ = [
    "AnnotateReport",
    "AnnotationFailure",
    "PipelineReport",
    "UploadFailure",
    "UploadReport",
    "auto_annotate_dataset",
    "full_pipeline",
    "train_pipeline",
    "upload_dataset_from_folder",
]
