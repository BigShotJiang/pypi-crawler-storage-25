"""Upload-from-folder workflow.

Walks a local directory of images, ensures the destination dataset
exists, and uploads every supported image with optional virtual-folder
mapping from subdirectory names. Returns a :class:`UploadReport` with
per-file failure context — partial success doesn't raise.
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from pictograph.exceptions import ApiError, ConflictError, NotFoundError

if TYPE_CHECKING:
    from collections.abc import Callable

    from pictograph import Client

_DEFAULT_WORKERS = 8
_IMAGE_EXTS = frozenset(
    {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff", ".gif", ".heic"}
)


@dataclass(frozen=True)
class UploadFailure:
    """One file that failed to upload (kind: ``upload_error`` / ``conflict``)."""

    path: Path
    reason: str


@dataclass
class UploadReport:
    """Outcome of an :func:`upload_dataset_from_folder` invocation.

    ``success`` is ``True`` only when every supported file landed.
    Inspect ``failures`` to retry the subset.
    """

    dataset_name: str
    images_attempted: int = 0
    images_uploaded: int = 0
    images_skipped: int = 0
    failures: list[UploadFailure] = field(default_factory=list)

    @property
    def success(self) -> bool:
        return not self.failures and self.images_uploaded > 0


def upload_dataset_from_folder(
    client: Client,
    dataset_name: str,
    folder: str | Path,
    *,
    organize_by_class: bool = True,
    parallel: bool = True,
    max_workers: int = _DEFAULT_WORKERS,
    skip_existing: bool = True,
    create_if_missing: bool = True,
    progress: Callable[[int, int, str | None], None] | None = None,
) -> UploadReport:
    """Walk ``folder`` and upload every supported image to ``dataset_name``.

    Args:
        client: Authenticated :class:`pictograph.Client`.
        dataset_name: Destination dataset (project) within your org.
        folder: Local directory to walk. Recursive by default.
        organize_by_class: When ``True`` (default), each first-level
            subdirectory becomes a virtual folder on the destination
            dataset (e.g. ``./images/cars/x.jpg`` lands under ``/cars``).
            When ``False``, all files land at root.
        parallel: Use a thread pool for concurrent uploads.
        max_workers: Pool size when ``parallel=True``. Defaults to 8 —
            higher values risk hitting the per-org rate limit.
        skip_existing: When ``True`` (default), conflict errors (image
            with the same filename already exists in the same folder)
            are recorded as ``skipped`` rather than failures.
        create_if_missing: When ``True`` (default), create the dataset
            if it doesn't exist. Pass ``False`` to require the dataset
            to be pre-created (and raise otherwise).
        progress: Optional ``(completed, total, filename)`` callback,
            fired after each file finishes (success or failure).

    Returns:
        :class:`UploadReport` with per-file failure context.

    Raises:
        FileNotFoundError: ``folder`` doesn't exist or isn't a directory.
        NotFoundError: ``dataset_name`` missing and ``create_if_missing=False``.
    """
    root = Path(folder).expanduser()
    if not root.is_dir():
        raise FileNotFoundError(f"Folder not found or not a directory: {root}")

    # Ensure dataset exists; capture the UUID for client.images.upload().
    try:
        project = client.projects.get(dataset_name)
    except NotFoundError:
        if not create_if_missing:
            raise
        project = client.projects.create(dataset_name)
    dataset_id = project.id

    # Discover image files.
    @dataclass(frozen=True)
    class _Task:
        local_path: Path
        virtual_folder_path: str

    tasks: list[_Task] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        if path.suffix.lower() not in _IMAGE_EXTS:
            continue
        if organize_by_class:
            relative = path.relative_to(root)
            virtual = (
                "/" + relative.parts[0] if len(relative.parts) > 1 else "/"
            )
        else:
            virtual = "/"
        tasks.append(_Task(local_path=path, virtual_folder_path=virtual))

    report = UploadReport(dataset_name=dataset_name, images_attempted=len(tasks))
    if not tasks:
        return report

    def _upload_one(task: _Task) -> tuple[_Task, str | None, str | None]:
        """Returns (task, status, error). status is "uploaded" / "skipped" / None."""
        try:
            client.images.upload(
                dataset_id=dataset_id,
                file_path=task.local_path,
                folder_path=task.virtual_folder_path,
            )
            return task, "uploaded", None
        except ConflictError as e:
            if skip_existing:
                return task, "skipped", str(e)
            return task, None, f"conflict: {e}"
        except ApiError as e:
            # Backend currently raises 400 (not 409) on duplicate filename in a folder.
            # Treat "already exists" as a conflict for skip_existing purposes so the
            # workflow stays idempotent across re-runs even before the backend fixes
            # the status code.
            if skip_existing and "already exists" in str(e).lower():
                return task, "skipped", str(e)
            return task, None, str(e)
        except OSError as e:
            return task, None, str(e)

    completed = 0
    if parallel and len(tasks) > 1:
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            futures = [pool.submit(_upload_one, t) for t in tasks]
            for future in as_completed(futures):
                task, status, error = future.result()
                completed += 1
                if status == "uploaded":
                    report.images_uploaded += 1
                elif status == "skipped":
                    report.images_skipped += 1
                else:
                    report.failures.append(
                        UploadFailure(path=task.local_path, reason=error or "unknown")
                    )
                if progress is not None:
                    progress(completed, len(tasks), task.local_path.name)
    else:
        for task in tasks:
            t, status, error = _upload_one(task)
            completed += 1
            if status == "uploaded":
                report.images_uploaded += 1
            elif status == "skipped":
                report.images_skipped += 1
            else:
                report.failures.append(
                    UploadFailure(path=t.local_path, reason=error or "unknown")
                )
            if progress is not None:
                progress(completed, len(tasks), t.local_path.name)

    return report
