"""End-to-end full-pipeline workflow.

Chains :func:`upload_dataset_from_folder` →
:func:`auto_annotate_dataset` → :func:`train_pipeline` into one call.
This is the agent-friendly "annotate this folder of road signs and give
me an ONNX model" workflow.

Each phase short-circuits on failure: if the upload report has zero
successes, annotation and training are skipped (returned as ``None``).
The :class:`PipelineReport` accumulates the per-phase reports so callers
can introspect partial progress.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from pictograph.workflows.annotate import (
    AnnotateReport,
    auto_annotate_dataset,
)
from pictograph.workflows.train import train_pipeline
from pictograph.workflows.upload import UploadReport, upload_dataset_from_folder

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path

    from pictograph import Client
    from pictograph.models.auto_annotate import BatchClass
    from pictograph.models.model import Model
    from pictograph.models.training import GpuType, PipelineType, TrainingRun
    from pictograph.workflows.annotate import AnnotateMode


@dataclass
class PipelineReport:
    """Aggregated outcome of :func:`full_pipeline`.

    Each sub-report is populated only if its phase ran (upload always
    runs; annotation runs only if upload succeeded; training runs only
    if annotation succeeded — assuming ``annotate=True``).

    ``credit_skip_reason`` is set when a phase was skipped because the
    org's credit balance was below the configured ``min_credits``
    threshold — agents inspect this to surface a top-up prompt.
    """

    dataset_name: str
    upload: UploadReport
    annotate: AnnotateReport | None = None
    training_run: TrainingRun | None = None
    model: Model | None = None
    credit_skip_reason: str | None = None

    @property
    def success(self) -> bool:
        if not self.upload.success:
            return False
        if self.annotate is not None and not self.annotate.success:
            return False
        if self.credit_skip_reason is not None:
            return False
        return not (
            self.training_run is not None
            and self.training_run.status != "completed"
        )


def full_pipeline(
    client: Client,
    *,
    dataset_name: str,
    folder: str | Path,
    classes: Sequence[BatchClass | tuple[str, str] | dict[str, str]],
    pipeline: PipelineType,
    gpu: GpuType = "a10g",
    annotate: bool = True,
    annotate_mode: AnnotateMode = "batch",
    train: bool = True,
    upload_workers: int = 8,
    train_config: dict[str, Any] | None = None,
    train_timeout: float = 7200.0,
    min_credits: int | None = 1,
) -> PipelineReport:
    """Upload → auto-annotate → train, end-to-end.

    Each phase fails open: a failure in upload skips annotate + train; a
    failure in annotate skips train. The :class:`PipelineReport` carries
    every sub-report so callers can pinpoint where the chain broke.

    Args:
        client: Authenticated :class:`pictograph.Client`.
        dataset_name: Destination dataset (created if missing).
        folder: Local folder of images to upload.
        classes: Class configs for annotation + training.
        pipeline: Training pipeline.
        gpu: GPU type for training.
        annotate: When ``False``, skip the auto-annotate phase (useful
            when annotations are already saved).
        annotate_mode: ``"batch"`` (default) or ``"text"``.
        train: When ``False``, skip the training phase (useful for
            "annotate-only" runs).
        upload_workers: Concurrent upload threads.
        train_config: Pipeline hyperparameters.
        train_timeout: Max seconds for training (default 7200 = 2h).
        min_credits: Minimum credit balance required before kicking off
            credit-consuming phases (auto-annotate + train). Pass
            ``None`` to disable the pre-flight check (proceed regardless).
            Default ``1`` — refuse to start any paid phase on a zero
            balance, surface ``credit_skip_reason`` on the report.

    Returns:
        :class:`PipelineReport` with every populated sub-report.
    """
    upload_report = upload_dataset_from_folder(
        client,
        dataset_name=dataset_name,
        folder=folder,
        organize_by_class=True,
        parallel=True,
        max_workers=upload_workers,
        create_if_missing=True,
    )
    report = PipelineReport(dataset_name=dataset_name, upload=upload_report)
    if not upload_report.success:
        return report

    # Credit pre-flight: refuse to kick off paid phases on a zero balance.
    # The estimate would need pre-known image counts and GPU minutes to be
    # exact; a balance>=1 check is a coarse but agent-friendly safety net.
    # Backend's PaymentRequiredError remains the authoritative answer
    # mid-run.
    if min_credits is not None and (annotate or train):
        balance = client.credits.balance()
        if balance.credits_remaining < min_credits:
            report.credit_skip_reason = (
                f"Insufficient credits: {balance.credits_remaining} available, "
                f"{min_credits} required. Skipping annotate + train."
            )
            return report

    if annotate:
        report.annotate = auto_annotate_dataset(
            client,
            dataset_name=dataset_name,
            classes=classes,
            mode=annotate_mode,
        )
        if not report.annotate.success:
            return report

    if train:
        run, model = train_pipeline(
            client,
            dataset_name=dataset_name,
            pipeline=pipeline,
            gpu=gpu,
            config=train_config,
            timeout=train_timeout,
        )
        report.training_run = run
        report.model = model

    return report
