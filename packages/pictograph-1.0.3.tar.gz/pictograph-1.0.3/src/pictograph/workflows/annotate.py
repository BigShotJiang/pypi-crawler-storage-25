"""Auto-annotate-dataset workflow.

Paginates a dataset's images, runs SAM3 (text or batch) over the
unfiltered subset, and surfaces a per-image report. The default
``mode="batch"`` uses the SAM3 batch endpoint (one job, polled until
complete) — the right call for >10 images. ``mode="text"`` falls back
to one synchronous text-prompt per image (useful for small datasets or
debugging single-image behaviour).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal, cast

from pictograph.exceptions import ApiError, NotFoundError
from pictograph.models.auto_annotate import BatchClass

if TYPE_CHECKING:
    from collections.abc import Sequence

    from pictograph import Client

AnnotateMode = Literal["batch", "text"]
"""``batch`` is the default — one async job over many images. ``text``
runs a synchronous SAM3 text prompt per image (slower; useful for small
datasets or single-image debugging)."""


@dataclass(frozen=True)
class AnnotationFailure:
    """One image that failed to auto-annotate."""

    image_filename: str
    reason: str


@dataclass
class AnnotateReport:
    """Outcome of an :func:`auto_annotate_dataset` invocation.

    ``job_id`` is set only when ``mode="batch"`` — the underlying
    ``BatchJob`` ID for follow-up polling or cancellation.
    """

    dataset_name: str
    images_attempted: int = 0
    images_processed: int = 0
    images_skipped: int = 0
    annotations_added: int = 0
    failures: list[AnnotationFailure] = field(default_factory=list)
    job_id: str | None = None

    @property
    def success(self) -> bool:
        return not self.failures and self.images_processed > 0


def auto_annotate_dataset(
    client: Client,
    dataset_name: str,
    classes: Sequence[BatchClass | tuple[str, str] | dict[str, str]],
    *,
    mode: AnnotateMode = "batch",
    confidence_threshold: float = 0.5,
    overwrite: bool = False,
    max_images: int | None = None,
    poll_interval: float = 5.0,
    timeout: float = 1800.0,
) -> AnnotateReport:
    """Run SAM3 over a dataset and save the resulting annotations.

    Args:
        client: Authenticated :class:`pictograph.Client`.
        dataset_name: Project name within your org.
        classes: Class configs to detect. Accepts:
            - :class:`BatchClass` instances (canonical),
            - ``(name, output_type)`` tuples (shorthand),
            - ``{"name": ..., "output_type": ...}`` dicts.
            ``output_type`` defaults to ``"polygon"`` for tuples without one.
        mode: ``"batch"`` (default) — async batch job; ``"text"`` —
            synchronous per-image text prompt.
        confidence_threshold: SAM3 confidence cutoff (0-1).
        overwrite: When ``False`` (default), skip images that already
            have at least one annotation. When ``True``, re-annotate every
            image.
        max_images: Cap the number of images processed (useful for
            dry-runs). ``None`` means "all".
        poll_interval: ``"batch"`` mode only — seconds between polls.
        timeout: ``"batch"`` mode only — max seconds to wait.

    Returns:
        :class:`AnnotateReport`. Inspect ``failures`` for per-image errors.

    Raises:
        NotFoundError: ``dataset_name`` doesn't exist.
        PaymentRequiredError: Insufficient credits for the estimate.
    """
    # Normalize classes input. ``BatchClass.output_type`` is a strict
    # Literal — Pydantic re-validates whichever string we pass through.
    canonical_classes: list[BatchClass] = []
    for c in classes:
        if isinstance(c, BatchClass):
            canonical_classes.append(c)
        elif isinstance(c, tuple):
            name, output_type = c if len(c) == 2 else (c[0], "polygon")
            canonical_classes.append(
                BatchClass(name=name, output_type=cast("Any", output_type))
            )
        elif isinstance(c, dict):
            canonical_classes.append(BatchClass(**cast("dict[str, Any]", c)))
        else:
            raise ValueError(f"Unsupported class spec: {c!r}")

    # Fetch the image list — Dataset.images populated when include_images=True.
    try:
        dataset = client.datasets.get(dataset_name, include_images=True)
    except NotFoundError:
        raise

    images = dataset.images or []
    if not overwrite:
        images = [img for img in images if img.annotation_count == 0]
    if max_images is not None:
        images = images[:max_images]

    report = AnnotateReport(
        dataset_name=dataset_name,
        images_attempted=len(images),
        images_skipped=len(dataset.images or []) - len(images),
    )
    if not images:
        return report

    if mode == "batch":
        try:
            job = client.auto_annotate.batch(
                dataset_name=dataset_name,
                image_filenames=[img.filename for img in images],
                classes=canonical_classes,
                confidence_threshold=confidence_threshold,
                wait=True,
                poll_interval=poll_interval,
                timeout=timeout,
            )
            report.images_processed = job.processed_images
            report.annotations_added = job.total_annotations_added
            report.job_id = job.job_id
            if job.failed_images:
                report.failures.append(
                    AnnotationFailure(
                        image_filename="<batch>",
                        reason=(
                            f"{job.failed_images} images failed during batch processing"
                        ),
                    )
                )
        except ApiError as e:
            report.failures.append(
                AnnotationFailure(image_filename="<batch>", reason=str(e))
            )
        return report

    # mode == "text" — synchronous per-image SAM3 text prompt with each class.
    for img in images:
        per_image_added = 0
        per_image_failures: list[str] = []
        for cls in canonical_classes:
            try:
                result = client.auto_annotate.text(
                    dataset_name=dataset_name,
                    image_filename=img.filename,
                    text_prompt=cls.name,
                    output_type=(
                        cls.output_type if cls.output_type != "tag" else "polygon"
                    ),
                    confidence_threshold=confidence_threshold,
                )
                if result.status == "success" and result.annotations:
                    save_result = client.annotations.save(
                        img.id,
                        annotations=result.annotations,
                    )
                    per_image_added += save_result.new_count - save_result.previous_count
            except ApiError as e:
                per_image_failures.append(f"{cls.name}: {e}")

        if per_image_failures:
            report.failures.append(
                AnnotationFailure(
                    image_filename=img.filename,
                    reason="; ".join(per_image_failures),
                )
            )
        else:
            report.images_processed += 1
        report.annotations_added += per_image_added

    return report
