"""Exception hierarchy for the Pictograph SDK.

All errors raised by the SDK derive from :class:`PictographError`. HTTP-level
errors derive from :class:`ApiError` and carry ``status_code``, ``request_id``,
``fix`` (one-line actionable suggestion) and ``docs_url``.

Catch patterns::

    try:
        client.training.create(...)
    except PaymentRequiredError as e:
        # Out of credits. e.credits_remaining tells you how many you have.
        ...
    except RateLimitError as e:
        # Back off. e.retry_after gives seconds (None if not provided).
        ...
    except ApiError as e:
        # Any other HTTP-level error.
        logger.error("Pictograph %s: %s -- %s", e.status_code, e, e.fix)
    except PictographError:
        # Catch-all for transport/config/network issues too.
        raise

The ``.fix`` and ``.docs_url`` fields exist so SDK callers (especially LLM
agents) can self-heal without parsing tracebacks.
"""

from __future__ import annotations

from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Mapping

DOCS_BASE = "https://pictograph.io/docs"


class PictographError(Exception):
    """Base class for every error raised by the Pictograph SDK."""

    # Class-level defaults; instances may override via __init__.
    fix: str | None = None
    docs_url: str | None = None

    def __init__(
        self,
        message: str,
        *,
        fix: str | None = None,
        docs_url: str | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        if fix is not None:
            self.fix = fix
        if docs_url is not None:
            self.docs_url = docs_url

    def __str__(self) -> str:
        parts = [self.message]
        if self.fix:
            parts.append(f"  Fix: {self.fix}")
        if self.docs_url:
            parts.append(f"  Docs: {self.docs_url}")
        return "\n".join(parts)

    def __repr__(self) -> str:
        return f"{type(self).__name__}({self.message!r})"


# ───────────── configuration & setup ─────────────


class ConfigurationError(PictographError):
    """The SDK is misconfigured — missing key, bad base URL, unreadable config file."""

    docs_url: str | None = f"{DOCS_BASE}/installation"


# ───────────── transport (pre-response) ─────────────


class NetworkError(PictographError):
    """An HTTP request failed before producing a response (DNS, TCP, TLS, etc)."""

    docs_url: str | None = f"{DOCS_BASE}/error-handling"
    fix: str | None = (
        "Check your internet connection and that api.pictograph.io is reachable."
    )


class RequestTimeoutError(NetworkError):
    """An HTTP request exceeded its configured timeout."""

    fix: str | None = (
        "Increase Client(timeout=...) for slow endpoints, or break large "
        "requests into smaller batches."
    )


class PollTimeoutError(PictographError):
    """An asynchronous server-side operation did not finish in the polling window.

    Distinct from :class:`RequestTimeoutError`: each individual HTTP poll
    succeeded, but the underlying job (export, training run, batch SAM3) is
    still in progress when the caller's timeout elapsed. The job continues
    running on the server — fetch its status later via
    ``client.<resource>.get(...)`` to check.
    """

    docs_url: str | None = f"{DOCS_BASE}/error-handling"
    fix: str | None = (
        "Increase the timeout= kwarg, or fetch status later via the "
        "resource's .get() method — the server-side job is still running."
    )


# ───────────── HTTP response errors ─────────────


class ApiError(PictographError):
    """Base for any error reported by the API via an HTTP response.

    Attributes:
        status_code: HTTP status code (3-digit integer) or ``None`` if synthesised.
        request_id: Server-issued ``X-Request-Id`` header value, useful for support.
        response: Parsed JSON body (a dict, typically) or raw text fallback.
    """

    docs_url: str | None = f"{DOCS_BASE}/error-handling"

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        request_id: str | None = None,
        response: Any = None,
        fix: str | None = None,
        docs_url: str | None = None,
    ) -> None:
        super().__init__(message, fix=fix, docs_url=docs_url)
        self.status_code = status_code
        self.request_id = request_id
        self.response = response

    def __str__(self) -> str:
        header = self.message
        meta: list[str] = []
        if self.status_code is not None:
            meta.append(f"status={self.status_code}")
        if self.request_id:
            meta.append(f"request_id={self.request_id}")
        if meta:
            header = f"{header} ({', '.join(meta)})"
        parts = [header]
        if self.fix:
            parts.append(f"  Fix: {self.fix}")
        if self.docs_url:
            parts.append(f"  Docs: {self.docs_url}")
        return "\n".join(parts)


class AuthError(ApiError):
    """401 — the API key is missing, malformed, expired, or revoked."""

    docs_url: str | None = f"{DOCS_BASE}/authentication"
    fix: str | None = (
        "Verify PICTOGRAPH_API_KEY is set and starts with 'pk_live_'. "
        "Generate a new key at Settings → API Keys."
    )


class ForbiddenError(ApiError):
    """403 — the key authenticated, but lacks role for this action or org scope."""

    docs_url: str | None = f"{DOCS_BASE}/authentication"
    fix: str | None = (
        "The API key's role does not permit this action. "
        "Write/delete operations require admin or owner role."
    )


class NotFoundError(ApiError):
    """404 — the requested resource does not exist (or is not visible to this key)."""

    fix: str | None = (
        "Verify the ID or name. Names are case-sensitive. "
        "Use the resource's .iter() method to enumerate what's available."
    )


class ValidationError(ApiError):
    """400 / 422 — request payload or query parameters failed validation.

    ``field_errors`` carries per-field details when the backend returns them in
    FastAPI / Pydantic format::

        [{"loc": ["body", "annotations", 0, "name"], "msg": "field required"}]
    """

    def __init__(
        self,
        message: str,
        *,
        field_errors: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(message, **kwargs)
        self.field_errors: list[dict[str, Any]] = field_errors or []


class ConflictError(ApiError):
    """409 — request conflicts with current state (duplicate name, version mismatch)."""

    fix: str | None = (
        "Resource already exists or operation conflicts with current state. "
        "Pick a different name, or fetch the existing resource first."
    )


class PaymentRequiredError(ApiError):
    """402 — insufficient credits or feature requires a paid plan.

    Attributes:
        credit_cost: Credits the operation would have consumed.
        credits_remaining: Credits the organization has available now.
        upgrade_url: Direct link to the billing page for the org (when provided).
    """

    docs_url: str | None = f"{DOCS_BASE}/concepts/credits-and-billing"
    fix: str | None = (
        "Top up credits in Settings → Billing, or upgrade your plan. "
        "Use client.credits.estimate(...) to gate operations before invoking."
    )

    def __init__(
        self,
        message: str,
        *,
        credit_cost: int | None = None,
        credits_remaining: int | None = None,
        upgrade_url: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(message, **kwargs)
        self.credit_cost = credit_cost
        self.credits_remaining = credits_remaining
        self.upgrade_url = upgrade_url


class RateLimitError(ApiError):
    """429 — request rate exceeded.

    ``retry_after`` is the parsed ``Retry-After`` header in seconds, or ``None``
    if absent. The SDK auto-waits when ``retry_after < 120``.
    """

    docs_url: str | None = f"{DOCS_BASE}/rate-limits"

    def __init__(
        self,
        message: str,
        *,
        retry_after: float | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(message, **kwargs)
        self.retry_after = retry_after
        if "fix" not in kwargs or kwargs.get("fix") is None:
            # Tailor the fix message to whether we know how long to wait.
            if retry_after is not None:
                self.fix = (
                    f"Wait {retry_after:.0f}s before retrying. "
                    "The SDK auto-retries when retry_after < 120s."
                )
            else:
                self.fix = (
                    "Reduce request rate or upgrade for a higher rate-limit tier."
                )


class ServerError(ApiError):
    """5xx — server-side failure. Usually transient; the SDK auto-retries 5xx."""

    fix: str | None = (
        "The server encountered an error. If this persists, contact "
        "support@pictograph.io with the request_id."
    )


# ───────────── factory ─────────────


# Status codes mapped to direct subclass constructors. Special-case codes
# (402, 422, 429) are handled in `from_response` so they can extract extra
# fields from headers/body before instantiation.
_STATUS_TO_EXCEPTION: dict[int, type[ApiError]] = {
    401: AuthError,
    403: ForbiddenError,
    404: NotFoundError,
    409: ConflictError,
}


def from_response(
    status_code: int,
    *,
    message: str | None = None,
    body: Any = None,
    request_id: str | None = None,
    headers: Mapping[str, str] | None = None,
) -> ApiError:
    """Construct the right :class:`ApiError` subclass for an HTTP response.

    Args:
        status_code: 3-digit HTTP status from the response.
        message: Override message; if absent, derived from ``body['detail']``.
        body: Parsed JSON body (dict). Used to extract context (credits, fields).
        request_id: ``X-Request-Id`` header value, if present.
        headers: Response headers, scanned for ``Retry-After`` on 429.

    Returns:
        An ``ApiError`` instance whose concrete type matches ``status_code``.
    """
    msg = _resolve_message(message, body, status_code)
    common: dict[str, Any] = {
        "status_code": status_code,
        "request_id": request_id,
        "response": body,
    }

    if status_code == 429:
        return RateLimitError(
            msg,
            retry_after=_parse_retry_after(headers),
            **common,
        )

    if status_code == 402 and isinstance(body, dict):
        # FastAPI's `HTTPException(detail={...})` nests context under
        # ``body["detail"]``. Look at both the top level (where flat error
        # bodies put the fields) and the nested detail (real backend shape).
        detail_raw = body.get("detail")
        detail: dict[str, Any] = detail_raw if isinstance(detail_raw, dict) else {}
        return PaymentRequiredError(
            msg,
            credit_cost=_first_present(body, "credit_cost", "required")
            or _first_present(detail, "credit_cost", "required"),
            credits_remaining=_first_present(body, "credits_remaining", "remaining")
            or _first_present(detail, "credits_remaining", "remaining"),
            upgrade_url=body.get("upgrade_url") or detail.get("upgrade_url"),
            **common,
        )

    if status_code in (400, 422):
        return ValidationError(
            msg,
            field_errors=_extract_field_errors(body),
            **common,
        )

    cls = _STATUS_TO_EXCEPTION.get(status_code)
    if cls is not None:
        return cls(msg, **common)

    if 500 <= status_code < 600:
        return ServerError(msg, **common)

    return ApiError(msg, **common)


def _resolve_message(message: str | None, body: Any, status_code: int) -> str:
    """Pick the best human message: explicit > body['detail'] (string) > fallback."""
    if message:
        return message
    if isinstance(body, dict):
        detail = body.get("detail") or body.get("error") or body.get("message")
        if isinstance(detail, str) and detail:
            return detail
    return f"HTTP {status_code}"


def _extract_field_errors(body: Any) -> list[dict[str, Any]] | None:
    """FastAPI returns ``{"detail": [{"loc": [...], "msg": "..."}, ...]}``."""
    if not isinstance(body, dict):
        return None
    detail = body.get("detail")
    if not isinstance(detail, list):
        return None
    return [d for d in detail if isinstance(d, dict)]


def _first_present(body: Mapping[str, Any], *keys: str) -> Any:
    """Return the first value present (and not None) for any of ``keys``."""
    for key in keys:
        if key in body and body[key] is not None:
            return body[key]
    return None


def _parse_retry_after(headers: Mapping[str, str] | None) -> float | None:
    """Parse ``Retry-After`` — supports plain seconds and HTTP-date formats.

    Returns ``None`` if missing or unparseable. Negative durations clamp to 0.
    """
    if headers is None:
        return None
    raw = headers.get("Retry-After") or headers.get("retry-after")
    if not raw:
        return None
    raw = str(raw).strip()
    # Most APIs use plain seconds.
    try:
        return max(0.0, float(raw))
    except ValueError:
        pass
    # RFC 7231 also allows HTTP-date format.
    try:
        target = parsedate_to_datetime(raw)
    except (TypeError, ValueError):
        return None
    if target.tzinfo is None:
        target = target.replace(tzinfo=timezone.utc)
    delta = (target - datetime.now(timezone.utc)).total_seconds()
    return max(0.0, delta)
