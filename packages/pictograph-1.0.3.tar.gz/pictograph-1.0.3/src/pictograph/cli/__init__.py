"""Pictograph CLI — invokable as ``pictograph`` after install.

The CLI mirrors the SDK 1:1: every command maps to one or more SDK
calls. Typer + Rich are optional deps gated under the ``[cli]`` extra::

    pip install 'pictograph[cli]'

The entry point ``pictograph = pictograph.cli._app:app`` lives in
``pyproject.toml``. Importing ``pictograph.cli`` directly is rare —
users invoke the CLI binary, not the Python module.
"""
