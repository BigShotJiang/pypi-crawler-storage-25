"""CLI config file — ``~/.pictograph/config.toml`` resolution.

Resolution order for the API key (highest wins):
1. ``--api-key`` flag on a command.
2. ``PICTOGRAPH_API_KEY`` environment variable.
3. ``~/.pictograph/config.toml`` ``[default].api_key``.
4. Nothing → :class:`pictograph.exceptions.ConfigurationError` from Client.
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path

# tomllib is stdlib in 3.11+; tomli is a back-compat dep for 3.10.
if sys.version_info >= (3, 11):
    import tomllib
else:  # pragma: no cover
    import tomli as tomllib

CONFIG_DIR = Path.home() / ".pictograph"
CONFIG_PATH = CONFIG_DIR / "config.toml"


@dataclass(frozen=True)
class CliConfig:
    """Resolved config — written by ``pictograph login``, read on every command."""

    api_key: str | None = None
    base_url: str | None = None


def load_config() -> CliConfig:
    """Read ``~/.pictograph/config.toml``. Returns empty config when missing."""
    if not CONFIG_PATH.is_file():
        return CliConfig()
    with CONFIG_PATH.open("rb") as fh:
        data = tomllib.load(fh)
    default = data.get("default", {})
    return CliConfig(
        api_key=default.get("api_key"),
        base_url=default.get("base_url"),
    )


def write_config(*, api_key: str, base_url: str | None = None) -> Path:
    """Write the API key (and optional base_url) to ``~/.pictograph/config.toml``.

    Creates the directory with mode 0700 and the file with mode 0600.
    Overwrites an existing file silently — interactive ``login`` is the
    expected caller, and the prior value is irrelevant after rotation.
    """
    CONFIG_DIR.mkdir(mode=0o700, exist_ok=True)
    lines = ["[default]", f'api_key = "{api_key}"']
    if base_url:
        lines.append(f'base_url = "{base_url}"')
    body = "\n".join(lines) + "\n"
    CONFIG_PATH.write_text(body, encoding="utf-8")
    CONFIG_PATH.chmod(0o600)
    return CONFIG_PATH


def resolve_api_key(override: str | None = None) -> str | None:
    """Apply the documented resolution order; returns None when nothing found."""
    if override:
        return override
    env = os.environ.get("PICTOGRAPH_API_KEY")
    if env:
        return env
    return load_config().api_key
