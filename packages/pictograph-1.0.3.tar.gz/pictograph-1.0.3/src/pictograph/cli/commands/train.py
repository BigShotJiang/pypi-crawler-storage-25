"""``pictograph train {start,status,cancel,logs}``."""

from __future__ import annotations

import json as json_module
from typing import Annotated

import typer

from pictograph.cli._client import get_client
from pictograph.cli._format import print_json
from pictograph.workflows import train_pipeline

app = typer.Typer(no_args_is_help=True)


@app.command("start", help="Kick off a training run on a dataset.")
def start_training(
    dataset: Annotated[str, typer.Argument(help="Dataset name.")],
    pipeline: Annotated[
        str,
        typer.Option(
            "--pipeline", "-p",
            help="yolox / detectron2 / sm_pytorch / classification / "
                 "rfdetr_detection / rfdetr_segmentation",
        ),
    ],
    gpu: Annotated[str, typer.Option("--gpu", help="a10g / a100 / h100")] = "a10g",
    name: Annotated[str | None, typer.Option("--name")] = None,
    config: Annotated[
        str | None,
        typer.Option(
            "--config",
            help="JSON dict of pipeline-specific hyperparameters.",
        ),
    ] = None,
    no_wait: Annotated[
        bool, typer.Option("--no-wait", help="Fire-and-forget; print run_id and exit.")
    ] = False,
    timeout: Annotated[float, typer.Option("--timeout")] = 7200.0,
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    config_dict = json_module.loads(config) if config else None
    client = get_client(api_key)
    run, model = train_pipeline(
        client,
        dataset,
        pipeline=pipeline,  # type: ignore[arg-type]
        gpu=gpu,  # type: ignore[arg-type]
        name=name,
        config=config_dict,
        wait=not no_wait,
        timeout=timeout,
    )
    print_json({
        "run_id": run.id,
        "status": run.status,
        "progress": run.progress,
        "model_id": model.id if model else None,
    })


@app.command("status", help="Fetch a training run's status.")
def status(
    run_id: Annotated[str, typer.Argument(help="Training run UUID.")],
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    client = get_client(api_key)
    run = client.training.get(run_id)
    print_json(run.model_dump(mode="json", exclude_none=True))


@app.command("cancel", help="Cancel an in-flight training run.")
def cancel(
    run_id: Annotated[str, typer.Argument(help="Training run UUID.")],
    yes: Annotated[bool, typer.Option("--yes", "-y")] = False,
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    if not yes and not typer.confirm(f"Cancel training run {run_id!r}?"):
        raise typer.Abort()
    client = get_client(api_key)
    run = client.training.cancel(run_id)
    print_json({"run_id": run.id, "status": run.status})


@app.command("logs", help="Tail training logs (placeholder — backend SSE pending).")
def logs(
    run_id: Annotated[str, typer.Argument(help="Training run UUID.")],
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    """Streaming logs require the backend SSE endpoint shipping in Phase 9."""
    client = get_client(api_key)
    run = client.training.get(run_id)
    typer.echo(
        f"Run {run_id}: status={run.status}, progress={run.progress}%, "
        f"epoch={run.current_epoch}/{run.total_epochs}"
    )
    if run.error_message:
        typer.echo(f"error: {run.error_message}", err=True)
    typer.echo(
        "Live log streaming arrives with the SSE endpoint in v1.1 — "
        "use `pictograph train status` to poll for now.",
        err=True,
    )
