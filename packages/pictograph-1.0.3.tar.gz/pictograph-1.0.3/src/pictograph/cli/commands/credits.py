"""``pictograph credits {balance,history,estimate}``."""

from __future__ import annotations

from typing import Annotated

import typer

from pictograph.cli._client import get_client
from pictograph.cli._format import print_json, print_table

app = typer.Typer(no_args_is_help=True)


@app.command("balance", help="Show current credit balance + recent activity.")
def balance(
    json_output: Annotated[bool, typer.Option("--json")] = False,
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    client = get_client(api_key)
    bal = client.credits.balance()
    if json_output:
        print_json(bal.model_dump(mode="json", exclude_none=True))
        return
    typer.echo(f"Remaining:        {bal.credits_remaining}")
    typer.echo(f"Monthly allowance: {bal.credits_monthly_allowance}")
    if bal.credits_reset_at:
        typer.echo(f"Resets:           {bal.credits_reset_at}")


@app.command("history", help="Page through the credit ledger (newest first).")
def history(
    limit: Annotated[int, typer.Option("--limit", "-n")] = 50,
    offset: Annotated[int, typer.Option("--offset")] = 0,
    json_output: Annotated[bool, typer.Option("--json")] = False,
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    client = get_client(api_key)
    entries = client.credits.history(limit=limit, offset=offset)
    if json_output:
        print_json([e.model_dump(mode="json", exclude_none=True) for e in entries])
        return
    rows = [
        {
            "when": str(e.created_at),
            "operation": e.operation,
            "amount": e.amount,
            "balance_after": e.balance_after,
        }
        for e in entries
    ]
    print_table(rows, title=f"Credit history ({len(rows)})")


@app.command("estimate", help="Estimate the credit cost of a planned operation.")
def estimate(
    operation: Annotated[
        str,
        typer.Argument(
            help="Operation slug (e.g., training_a10g, sam3_auto_annotation).",
        ),
    ],
    quantity: Annotated[int, typer.Option("--quantity", "-q")] = 1,
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    client = get_client(api_key)
    est = client.credits.estimate(operation, quantity=quantity)
    print_json(est.model_dump(mode="json", exclude_none=True))
