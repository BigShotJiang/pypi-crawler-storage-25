"""``pictograph models {list,download}``."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from pictograph.cli._client import get_client
from pictograph.cli._format import print_json, print_table

app = typer.Typer(no_args_is_help=True)


@app.command("list", help="List trained models in your organization.")
def list_models(
    limit: Annotated[int, typer.Option("--limit", "-n")] = 50,
    json_output: Annotated[bool, typer.Option("--json")] = False,
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    client = get_client(api_key)
    models = client.models.list(limit=limit)
    if json_output:
        print_json([m.model_dump(mode="json", exclude_none=True) for m in models])
        return
    rows = [
        {
            "name": m.name,
            "id": m.id,
            "type": m.model_type,
            "arch": m.architecture,
            "status": m.status,
            "version": m.version,
        }
        for m in models
    ]
    print_table(rows, title=f"Models ({len(rows)})")


@app.command("download", help="Download a trained model's ONNX weights.")
def download_model(
    model_id: Annotated[str, typer.Argument(help="Model UUID.")],
    output: Annotated[Path, typer.Option("--output", "-o")],
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    client = get_client(api_key)
    output.parent.mkdir(parents=True, exist_ok=True)
    client.models.download(model_id, output_path=output)
    print_json({
        "model_id": model_id,
        "output_path": str(output),
        "size_bytes": output.stat().st_size if output.is_file() else None,
    })
