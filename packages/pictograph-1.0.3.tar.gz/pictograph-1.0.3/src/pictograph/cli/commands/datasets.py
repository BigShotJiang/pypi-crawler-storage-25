"""``pictograph datasets {list,get,download,create,delete}``."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from pictograph.cli._client import get_client
from pictograph.cli._format import print_json, print_table

app = typer.Typer(no_args_is_help=True)


@app.command("list", help="List datasets in your organization.")
def list_datasets(
    limit: Annotated[int, typer.Option("--limit", "-n")] = 100,
    json_output: Annotated[bool, typer.Option("--json", help="Emit raw JSON.")] = False,
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    client = get_client(api_key)
    datasets = client.datasets.list(limit=limit)
    rows = [
        {
            "name": d.name,
            "id": d.id,
            "images": d.image_count,
            "completed": d.completed_image_count,
            "size": d.total_size,
        }
        for d in datasets
    ]
    if json_output:
        print_json([d.model_dump(mode="json", exclude_none=True) for d in datasets])
    else:
        print_table(rows, title=f"Datasets ({len(rows)})")


@app.command("get", help="Fetch a dataset by name.")
def get_dataset(
    name: Annotated[str, typer.Argument(help="Dataset name.")],
    include_images: Annotated[
        bool, typer.Option("--include-images", "-I")
    ] = False,
    images_limit: Annotated[int, typer.Option("--images-limit")] = 100,
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    client = get_client(api_key)
    dataset = client.datasets.get(
        name, include_images=include_images, images_limit=images_limit
    )
    print_json(dataset.model_dump(mode="json", exclude_none=True))


@app.command("create", help="Create a new dataset.")
def create_dataset(
    name: Annotated[str, typer.Argument(help="Dataset name.")],
    description: Annotated[str | None, typer.Option("--description", "-d")] = None,
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    client = get_client(api_key)
    project = client.projects.create(name, description=description)
    print_json(project.model_dump(mode="json", exclude_none=True))


@app.command("delete", help="Permanently delete a dataset and its images.")
def delete_dataset(
    name: Annotated[str, typer.Argument(help="Dataset name.")],
    yes: Annotated[
        bool, typer.Option("--yes", "-y", help="Skip the confirmation prompt.")
    ] = False,
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    if not yes and not typer.confirm(
        f"Permanently delete dataset {name!r}? This is irreversible."
    ):
        raise typer.Abort()
    client = get_client(api_key)
    client.projects.delete(name)
    typer.echo(f"Deleted dataset {name!r}.")


@app.command("download", help="Bulk-download a dataset's images and annotations.")
def download_dataset(
    name: Annotated[str, typer.Argument(help="Dataset name.")],
    output_dir: Annotated[Path, typer.Option("--output", "-o")] = Path("./dataset"),
    mode: Annotated[
        str, typer.Option(help="full / images_only / annotations_only")
    ] = "full",
    workers: Annotated[int, typer.Option("--workers", "-w")] = 10,
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    client = get_client(api_key)
    report = client.datasets.download(
        name,
        output_dir=output_dir,
        mode=mode,  # type: ignore[arg-type]
        max_workers=workers,
    )
    print_json({
        "dataset_id": report.dataset_id,
        "images_downloaded": report.images_downloaded,
        "annotations_downloaded": report.annotations_downloaded,
        "failures": len(report.failures),
        "output_dir": str(output_dir),
    })
