"""``pictograph images {upload,download,delete}``."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from pictograph.cli._client import get_client
from pictograph.cli._format import print_json

app = typer.Typer(no_args_is_help=True)


@app.command("upload", help="Upload a single image to a dataset.")
def upload_image(
    dataset: Annotated[str, typer.Argument(help="Dataset name.")],
    file_path: Annotated[Path, typer.Argument(help="Local image path.")],
    folder: Annotated[
        str, typer.Option("--folder", "-f", help="Virtual folder (e.g. /cars).")
    ] = "/",
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    client = get_client(api_key)
    project = client.projects.get(dataset)
    image = client.images.upload(
        dataset_id=project.id, file_path=file_path, folder_path=folder,
    )
    print_json(image.model_dump(mode="json", exclude_none=True))


@app.command("download", help="Download a single image to a local file.")
def download_image(
    image_id: Annotated[str, typer.Argument(help="Image UUID.")],
    output: Annotated[Path, typer.Option("--output", "-o")],
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    client = get_client(api_key)
    output.parent.mkdir(parents=True, exist_ok=True)
    client.images.download(image_id, output_path=output)
    print_json({"image_id": image_id, "output_path": str(output)})


@app.command("delete", help="Permanently delete a single image.")
def delete_image(
    image_id: Annotated[str, typer.Argument(help="Image UUID.")],
    yes: Annotated[bool, typer.Option("--yes", "-y")] = False,
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    if not yes and not typer.confirm(f"Permanently delete image {image_id!r}?"):
        raise typer.Abort()
    client = get_client(api_key)
    client.images.delete(image_id)
    typer.echo(f"Deleted image {image_id!r}.")
