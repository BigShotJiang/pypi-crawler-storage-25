"""``pictograph annotations {get,save,delete}``."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer
from pydantic import TypeAdapter

from pictograph.cli._client import get_client
from pictograph.cli._format import print_json
from pictograph.models.annotation import Annotation

app = typer.Typer(no_args_is_help=True)


@app.command("get", help="Fetch annotations attached to an image.")
def get_annotations(
    image_id: Annotated[str, typer.Argument(help="Image UUID.")],
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    client = get_client(api_key)
    annotations = client.annotations.get(image_id)
    print_json([a.model_dump(mode="json", exclude_none=True) for a in annotations])


@app.command("save", help="Replace annotations on an image (full overwrite).")
def save_annotations(
    image_id: Annotated[str, typer.Argument(help="Image UUID.")],
    file: Annotated[
        Path,
        typer.Option(
            "--file", "-f",
            help="Path to a JSON file containing a list of annotations.",
        ),
    ],
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    raw = json.loads(file.read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        typer.echo(
            "JSON file must contain a list of annotations at the top level.",
            err=True,
        )
        raise typer.Exit(2)
    adapter: TypeAdapter[list[Annotation]] = TypeAdapter(list[Annotation])
    parsed = adapter.validate_python(raw)
    client = get_client(api_key)
    result = client.annotations.save(image_id, parsed)
    print_json({
        "image_id": result.image_id,
        "previous_count": result.previous_count,
        "new_count": result.new_count,
        "status": result.status,
    })


@app.command("delete", help="Remove every annotation from an image.")
def delete_annotations(
    image_id: Annotated[str, typer.Argument(help="Image UUID.")],
    yes: Annotated[bool, typer.Option("--yes", "-y")] = False,
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
) -> None:
    if not yes and not typer.confirm(
        f"Delete all annotations on image {image_id!r}?"
    ):
        raise typer.Abort()
    client = get_client(api_key)
    result = client.annotations.delete(image_id)
    print_json({
        "image_id": result.image_id,
        "deleted_count": result.deleted_count,
    })
