"""Rich rendering helpers for CLI output.

Two output modes:
- **table** (default) — Rich tables for human-friendly terminals.
- **json** — pretty-printed JSON for piping into ``jq`` / scripting.
"""

from __future__ import annotations

import json
import sys
from typing import Any

from rich.console import Console
from rich.table import Table

console = Console()
err_console = Console(stderr=True)


def print_json(payload: Any) -> None:
    """Print ``payload`` as indented JSON to stdout. Used for ``--json`` output."""
    sys.stdout.write(json.dumps(payload, indent=2, default=str))
    sys.stdout.write("\n")


def print_table(
    rows: list[dict[str, Any]],
    *,
    columns: list[str] | None = None,
    title: str | None = None,
) -> None:
    """Render ``rows`` as a Rich table.

    Args:
        rows: List of dicts. Empty list prints "No results."
        columns: Column names. Defaults to keys of the first row.
        title: Optional table title.
    """
    if not rows:
        console.print("[dim]No results.[/dim]")
        return
    cols = columns or list(rows[0].keys())
    table = Table(title=title, show_lines=False, header_style="bold")
    for col in cols:
        table.add_column(col)
    for row in rows:
        table.add_row(*[_render_cell(row.get(col, "")) for col in cols])
    console.print(table)


def _render_cell(value: Any) -> str:
    """Coerce arbitrary values into Rich-friendly strings."""
    if value is None:
        return "[dim]—[/dim]"
    if isinstance(value, bool):
        return "[green]✓[/green]" if value else "[red]✗[/red]"
    if isinstance(value, list | tuple):
        return ", ".join(str(v) for v in value)
    if isinstance(value, dict):
        return json.dumps(value, default=str)
    return str(value)


def print_error(message: str) -> None:
    """Bold-red error to stderr — used by exception handlers."""
    err_console.print(f"[bold red]error:[/bold red] {message}")
