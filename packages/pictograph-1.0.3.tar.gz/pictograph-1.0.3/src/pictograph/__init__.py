"""Pictograph — agent-native computer vision annotation SDK.

Public surface:

- :class:`Client` — entry point for all API operations.
- Annotation Pydantic models (:class:`BBoxAnnotation`, :class:`PolygonAnnotation`,
  :class:`PolylineAnnotation`, :class:`KeypointAnnotation`) and the
  discriminated :data:`Annotation` union.
- Geometry primitives (:class:`Point`, :class:`BoundingBox`,
  :class:`PolygonGeometry`, :class:`PolylineGeometry`).
- Resource models — :class:`Dataset`, :class:`Image`, :class:`Export`,
  :class:`TrainingRun`, :class:`Model`, :class:`CreditBalance`, etc.
- Exception hierarchy rooted at :class:`PictographError`.

Anything not re-exported here is private and may change without notice.
"""

from __future__ import annotations

from pictograph._version import __version__
from pictograph.agents import (
    REGISTRY,
    Toolkit,
    create_toolkit,
    for_anthropic_messages,
    for_claude_agent_sdk,
    for_openai_agents,
    for_openai_responses,
)
from pictograph.client import Client
from pictograph.exceptions import (
    ApiError,
    AuthError,
    ConfigurationError,
    ConflictError,
    ForbiddenError,
    NetworkError,
    NotFoundError,
    PaymentRequiredError,
    PictographError,
    PollTimeoutError,
    RateLimitError,
    RequestTimeoutError,
    ServerError,
    ValidationError,
)
from pictograph.models.annotation import (
    Annotation,
    AnnotationType,
    BBoxAnnotation,
    KeypointAnnotation,
    PolygonAnnotation,
    PolygonGeometry,
    PolylineAnnotation,
    PolylineGeometry,
)
from pictograph.models.api_key import ApiKey, ApiKeyRole, CreatedApiKey
from pictograph.models.auto_annotate import (
    BatchClass,
    BatchJob,
    BatchJobStatus,
    PromptResult,
    PromptStatus,
)
from pictograph.models.batch import BatchFailure, BatchResult, DuplicateHandling
from pictograph.models.common import BoundingBox, NonBlankStr, Point
from pictograph.models.connector import (
    ConnectorProvider,
    DatasetImportProgress,
    DatasetImportStatus,
    ImportJob,
    ImportStatus,
    LimitCheckResult,
    LimitType,
    RemoteDataset,
    ValidationResult,
)
from pictograph.models.credit import CreditBalance, CreditEstimate, CreditLedgerEntry
from pictograph.models.dataset import Dataset, DatasetClass, DatasetImage
from pictograph.models.export import Export, ExportFormat, ExportStatus
from pictograph.models.image import Image, ImageStatus
from pictograph.models.model import Model, ModelStatus, ModelType, ModelVisibility
from pictograph.models.organization import (
    InviteRole,
    InviteStatus,
    Organization,
    OrganizationInvite,
    OrganizationMember,
    OrganizationRole,
    SubscriptionTier,
)
from pictograph.models.project import Project, ProjectAnnotationType, ProjectClass
from pictograph.models.search import SimilarImage, TaggedImage
from pictograph.models.training import (
    GpuType,
    PipelineType,
    TrainingRun,
    TrainingStatus,
)
from pictograph.models.video import (
    VideoExtractionJob,
    VideoJobStatus,
    VideoMetadata,
    VideoUploadInfo,
)

__all__ = [
    "REGISTRY",
    "Annotation",
    "AnnotationType",
    "ApiError",
    "ApiKey",
    "ApiKeyRole",
    "AuthError",
    "BBoxAnnotation",
    "BatchClass",
    "BatchFailure",
    "BatchJob",
    "BatchJobStatus",
    "BatchResult",
    "BoundingBox",
    "Client",
    "ConfigurationError",
    "ConflictError",
    "ConnectorProvider",
    "CreatedApiKey",
    "CreditBalance",
    "CreditEstimate",
    "CreditLedgerEntry",
    "Dataset",
    "DatasetClass",
    "DatasetImage",
    "DatasetImportProgress",
    "DatasetImportStatus",
    "DuplicateHandling",
    "Export",
    "ExportFormat",
    "ExportStatus",
    "ForbiddenError",
    "GpuType",
    "Image",
    "ImageStatus",
    "ImportJob",
    "ImportStatus",
    "InviteRole",
    "InviteStatus",
    "KeypointAnnotation",
    "LimitCheckResult",
    "LimitType",
    "Model",
    "ModelStatus",
    "ModelType",
    "ModelVisibility",
    "NetworkError",
    "NonBlankStr",
    "NotFoundError",
    "Organization",
    "OrganizationInvite",
    "OrganizationMember",
    "OrganizationRole",
    "PaymentRequiredError",
    "PictographError",
    "PipelineType",
    "Point",
    "PollTimeoutError",
    "PolygonAnnotation",
    "PolygonGeometry",
    "PolylineAnnotation",
    "PolylineGeometry",
    "Project",
    "ProjectAnnotationType",
    "ProjectClass",
    "PromptResult",
    "PromptStatus",
    "RateLimitError",
    "RemoteDataset",
    "RequestTimeoutError",
    "ServerError",
    "SimilarImage",
    "SubscriptionTier",
    "TaggedImage",
    "Toolkit",
    "TrainingRun",
    "TrainingStatus",
    "ValidationError",
    "ValidationResult",
    "VideoExtractionJob",
    "VideoJobStatus",
    "VideoMetadata",
    "VideoUploadInfo",
    "__version__",
    "create_toolkit",
    "for_anthropic_messages",
    "for_claude_agent_sdk",
    "for_openai_agents",
    "for_openai_responses",
]
