"""Images resource: metadata, streaming download, chunked upload, delete.

Upload uses the backend's three-step signed-URL flow (``upload-url`` →
chunked ``PUT`` to GCS → ``register``) rather than the convenience
``POST /upload`` endpoint. The three-step path:

- Sends bytes directly to GCS, never relayed through the backend (cheaper,
  faster, and bypasses the 10 MB request-body limit).
- Lets us stream chunks with a progress callback.
- Yields the same final result (a registered :class:`Image` row) as the
  one-step path.

Image dimensions are extracted client-side via Pillow when possible and
sent to ``register`` so the backend doesn't have to re-decode the bytes.
A missing or undecodable file falls through with ``width=None, height=None``
(the backend tolerates this).
"""

from __future__ import annotations

import contextlib
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

try:
    from PIL import Image as _PILImage, UnidentifiedImageError as _UnidentifiedImageError

    _PIL_AVAILABLE = True
except ImportError:  # pragma: no cover — Pillow is a base dep, but degrade if absent
    _PIL_AVAILABLE = False

from pictograph._http.streaming import DEFAULT_CHUNK_SIZE
from pictograph.models.image import Image
from pictograph.resources._base import Resource

if TYPE_CHECKING:
    from collections.abc import Callable


_API_PATH = "/api/v1/developer/images"

# Filename suffix → MIME type. Backend accepts anything image/*; an unknown
# suffix falls back to a generic binary type and the backend will reject it,
# which is the right behaviour (don't silently pretend a .txt is an image).
_CONTENT_TYPE_BY_SUFFIX: dict[str, str] = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".bmp": "image/bmp",
    ".webp": "image/webp",
    ".tiff": "image/tiff",
    ".tif": "image/tiff",
    ".heic": "image/heic",
    ".heif": "image/heif",
}


class Images(Resource):
    """Operations on individual images within a dataset."""

    # ───────────── metadata ─────────────

    def get(self, image_id: str) -> Image:
        """Fetch metadata for a single image.

        For the actual annotations on the image, use
        :meth:`Annotations.get` — the SDK exposes annotations as a separate
        resource so the data ownership boundary stays clean.
        """
        response = self._transport.request("GET", f"{_API_PATH}/{image_id}/metadata")
        return self._parse(Image, response["image"])

    # ───────────── download ─────────────

    def download(
        self,
        image_id: str,
        output_path: str | Path,
        *,
        chunk_size: int = DEFAULT_CHUNK_SIZE,
    ) -> Path:
        """Stream image bytes to ``output_path``; return the path.

        Parent directories are created if missing. Bytes land in a sibling
        ``<name>.part`` file first and are renamed atomically onto
        ``output_path`` only after the transfer completes — a 404 / 5xx /
        network failure mid-download leaves no partial file at the
        destination, so retries are safe with the same call.
        """
        out = Path(output_path).expanduser()
        out.parent.mkdir(parents=True, exist_ok=True)
        tmp = out.with_name(out.name + ".part")
        try:
            with tmp.open("wb") as fh:
                for chunk in self._transport.stream_bytes(
                    "GET",
                    f"{_API_PATH}/{image_id}",
                ):
                    fh.write(chunk)
                    _ = chunk_size  # forward-compat hint; httpx default chunking
        except BaseException:
            with contextlib.suppress(OSError):
                tmp.unlink()
            raise
        tmp.replace(out)
        return out

    # ───────────── upload ─────────────

    def upload(
        self,
        dataset_id: str,
        file_path: str | Path,
        *,
        folder_path: str = "/",
        filename: str | None = None,
        content_type: str | None = None,
        progress: Callable[[int, int], None] | None = None,
    ) -> Image:
        """Upload an image to a dataset via the three-step signed-URL flow.

        Args:
            dataset_id: Target dataset UUID.
            file_path: Local file to upload. Read in chunks; never loaded
                fully into memory.
            folder_path: Virtual folder within the dataset (created if
                missing). Defaults to root (``"/"``).
            filename: Override the destination filename. Defaults to the
                local file's basename.
            content_type: Override the inferred MIME type. Defaults to a
                lookup by file extension (``.jpg`` → ``image/jpeg``, etc).
            progress: Optional ``(bytes_sent, total_bytes)`` callback fired
                during the GCS upload phase.

        Returns:
            The newly-registered :class:`Image`.

        Raises:
            FileNotFoundError: ``file_path`` does not exist.
            ValueError: ``content_type`` cannot be inferred and was not given.
            ApiError / NetworkError: Per-step backend or transport failures.
        """
        path = Path(file_path).expanduser()
        if not path.is_file():
            raise FileNotFoundError(f"Image file not found: {path}")

        resolved_filename = filename or path.name
        resolved_content_type = content_type or _infer_content_type(resolved_filename)
        if resolved_content_type == "application/octet-stream":
            raise ValueError(
                f"Could not infer image MIME type from filename '{resolved_filename}'. "
                f"Pass content_type=... explicitly (e.g. 'image/jpeg')."
            )

        file_size = path.stat().st_size
        width, height = _safe_image_dimensions(path)

        # Step 1 — request a signed upload URL.
        url_response = self._transport.request(
            "POST",
            f"{_API_PATH}/upload-url",
            json={
                "dataset_id": dataset_id,
                "filename": resolved_filename,
                "folder_path": folder_path,
                "content_type": resolved_content_type,
            },
        )

        # Step 2 — PUT bytes to GCS in chunks (no SDK auth on this URL).
        self._transport.upload_external(
            url_response["upload_url"],
            path,
            content_type=resolved_content_type,
            progress=progress,
        )

        # Step 3 — register the uploaded blob in the database.
        register_response = self._transport.request(
            "POST",
            f"{_API_PATH}/register",
            data={
                "dataset_id": dataset_id,
                "filename": resolved_filename,
                "gcs_bucket": url_response["gcs_bucket"],
                "gcs_path": url_response["gcs_path"],
                "gcs_uri": url_response["gcs_uri"],
                "folder_path": folder_path,
                "file_size": file_size,
                "mime_type": resolved_content_type,
                "image_width": width,
                "image_height": height,
            },
        )

        return self.get(register_response["image_id"])

    # ───────────── delete ─────────────

    def delete(self, image_id: str, *, permanent: bool = False) -> None:
        """Archive (default) or permanently delete an image.

        Archived images survive in the Archive tab and can be restored. A
        ``permanent=True`` delete removes the GCS object and the database
        row irreversibly — there is no undo. Requires admin or owner role.
        """
        params: dict[str, Any] | None = (
            {"permanent": "true"} if permanent else None
        )
        self._transport.request(
            "DELETE",
            f"{_API_PATH}/{image_id}",
            params=cast("Any", params),
        )


# ───────────── module-private helpers ─────────────


def _infer_content_type(filename: str) -> str:
    """Map a filename suffix to a MIME type.

    Returns ``application/octet-stream`` when the suffix is unrecognised; the
    caller decides whether that's an error (it is, for image upload).
    """
    suffix = Path(filename).suffix.lower()
    return _CONTENT_TYPE_BY_SUFFIX.get(suffix, "application/octet-stream")


def _safe_image_dimensions(path: Path) -> tuple[int | None, int | None]:
    """Extract ``(width, height)`` via Pillow without raising.

    Returns ``(None, None)`` when Pillow is not installed, the file is not a
    decodable image, or the dimensions can't be read for any reason. The
    backend tolerates ``None`` and stores ``NULL`` in the column.
    """
    if not _PIL_AVAILABLE:
        return (None, None)
    try:
        with _PILImage.open(path) as img:
            width, height = img.size
            return (width, height)
    except (_UnidentifiedImageError, OSError):
        return (None, None)
