"""Annotations resource — read, save, delete annotations for an image.

The wire format on this resource is the **canonical Pictograph JSON**
defined in :mod:`pictograph.models.annotation`. There is no shorthand:
``BoundingBox`` is always ``{"x", "y", "w", "h"}`` (object), polygon paths
are always lists of ``{"x", "y"}`` point objects, polyline path is a single
list of point objects, keypoint is a point object. The SDK serialises
``Annotation`` Pydantic models via ``model_dump(mode="json", exclude_none=True)``
and the result is bit-for-bit what lands in ``project_images.annotations_json``.

The backend rejects any other shape with a structured ``ValidationError`` —
that's what catches old shorthand usage early.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from pydantic import TypeAdapter

from pictograph.models.annotation import Annotation
from pictograph.resources._base import Resource

if TYPE_CHECKING:
    from collections.abc import Sequence

_API_PATH = "/api/v1/developer/annotations"

# Module-level adapter is built once and reused — Pydantic v2 TypeAdapter
# construction is non-trivial (compiles a discriminated-union validator).
_ANNOTATION_LIST_ADAPTER: TypeAdapter[list[Annotation]] = TypeAdapter(list[Annotation])


@dataclass(frozen=True)
class SaveResult:
    """Outcome of :meth:`Annotations.save`.

    Attributes:
        image_id: Image whose annotations were updated.
        previous_count: Number of annotations the image had before this call.
        new_count: Number of annotations after this call.
        status: New annotation lifecycle status — ``"new"``, ``"in_progress"``,
            or ``"complete"``. Set automatically by the backend based on count.
    """

    image_id: str
    previous_count: int
    new_count: int
    status: str


@dataclass(frozen=True)
class DeleteResult:
    """Outcome of :meth:`Annotations.delete`."""

    image_id: str
    deleted_count: int


class Annotations(Resource):
    """Read, save, and delete annotations for individual images."""

    def get(self, image_id: str) -> list[Annotation]:
        """Fetch the annotations attached to ``image_id``.

        Returns a list of typed :data:`Annotation` (discriminated union over
        bbox / polygon / polyline / keypoint subclasses). An image with zero
        annotations returns an empty list — never raises ``NotFoundError``
        for the "no annotations" case (only for "no such image").
        """
        response = self._transport.request("GET", f"{_API_PATH}/{image_id}")
        raw = response.get("annotations", [])
        return _ANNOTATION_LIST_ADAPTER.validate_python(raw)

    def save(
        self,
        image_id: str,
        annotations: Sequence[Annotation],
    ) -> SaveResult:
        """Replace the annotations on ``image_id`` with the given list.

        This is a *full* replacement: the existing annotations are
        overwritten. Pass an empty list to clear (equivalent to
        :meth:`delete`).

        Args:
            image_id: Image to update.
            annotations: Annotation objects in canonical Pictograph JSON
                format. The SDK validates each via Pydantic at construction;
                the backend re-validates the wire payload as a defence in
                depth.

        Returns:
            :class:`SaveResult` with previous/new annotation counts and the
            updated lifecycle status.

        Raises:
            ValidationError: Backend rejected the payload (e.g., a class
                name not in the project's class set).
            ForbiddenError: API key role lacks write permission.
            NotFoundError: ``image_id`` does not exist.
        """
        body = {
            "image_id": image_id,
            "annotations": [
                ann.model_dump(mode="json", exclude_none=True)
                for ann in annotations
            ],
        }
        response = self._transport.request(
            "POST",
            f"{_API_PATH}/{image_id}",
            json=body,
        )
        return SaveResult(
            image_id=response["image_id"],
            previous_count=response["previous_count"],
            new_count=response["new_count"],
            status=response["status"],
        )

    def delete(self, image_id: str) -> DeleteResult:
        """Remove all annotations from ``image_id``.

        Equivalent to :meth:`save` with an empty list, but uses ``DELETE``
        and requires admin/owner role server-side.
        """
        response = self._transport.request("DELETE", f"{_API_PATH}/{image_id}")
        return DeleteResult(
            image_id=response.get("image_id", image_id),
            deleted_count=response.get("deleted_count", 0),
        )
