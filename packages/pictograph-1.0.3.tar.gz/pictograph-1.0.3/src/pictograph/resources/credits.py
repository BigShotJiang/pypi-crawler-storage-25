"""Credits resource — balance, ledger history, pre-operation cost estimation.

This is the gating surface for agents: call :meth:`Credits.estimate` before
any operation that consumes credits (training, batch SAM3, image
generation/edit) to decide whether to proceed. The estimate's
``sufficient`` flag tells you whether the org has enough credits **at the
moment of the call** — there's no race-free guarantee against another
caller draining credits between the estimate and the actual operation, so
the SDK and backend both treat the operation's own
:class:`PaymentRequiredError` as the authoritative answer.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from pictograph._http.pagination import OffsetPager
from pictograph.models.credit import CreditBalance, CreditEstimate, CreditLedgerEntry
from pictograph.resources._base import Resource

if TYPE_CHECKING:
    from collections.abc import Mapping

_API_PATH = "/api/v1/developer/credits"


class Credits(Resource):
    """Read credit balance and ledger; estimate operation costs."""

    def balance(self) -> CreditBalance:
        """Current balance + monthly allowance + last 20 ledger entries."""
        response = self._transport.request("GET", f"{_API_PATH}/balance")
        return self._parse(CreditBalance, response)

    def history(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
    ) -> list[CreditLedgerEntry]:
        """Single page of credit-ledger entries, newest first.

        Args:
            limit: Page size (backend cap: 100).
            offset: Page offset for paginating manually.
        """
        response = self._transport.request(
            "GET",
            f"{_API_PATH}/history",
            params={"limit": limit, "offset": offset},
        )
        return self._parse_list(CreditLedgerEntry, response.get("entries", []))

    def iter(
        self,
        *,
        page_size: int = 100,
        max_total: int | None = None,
    ) -> OffsetPager[CreditLedgerEntry]:
        """Auto-paging iterator across the entire credit ledger."""

        def fetch(offset: int, limit: int) -> Mapping[str, Any]:
            return cast(
                "Mapping[str, Any]",
                self._transport.request(
                    "GET",
                    f"{_API_PATH}/history",
                    params={"offset": offset, "limit": limit},
                ),
            )

        return OffsetPager(
            fetch,
            items_key="entries",
            page_size=page_size,
            max_total=max_total,
            parse_item=lambda raw: self._parse(CreditLedgerEntry, raw),
        )

    def estimate(self, operation: str, *, quantity: int = 1) -> CreditEstimate:
        """Estimate the credit cost of a planned operation.

        Args:
            operation: Operation slug. Common values:
              ``"training_a10g"``, ``"training_a100"``, ``"training_h100"``,
              ``"sam3_auto_annotation"``, ``"inference_t4"``,
              ``"image_generate_imagen_fast"``, ``"image_edit_gemini_flash"``.
              Full list lives in ``utils.tier_limits.CREDIT_COSTS`` server-side.
            quantity: Number of units (minutes for ``per_minute`` ops, calls
                for ``per_call`` ops). Ops with a minimum charge are clamped
                server-side (e.g., training has a 5-minute floor).

        Returns:
            :class:`CreditEstimate` — inspect ``.sufficient`` to gate the
            operation. Note that the underlying operation may still raise
            :class:`PaymentRequiredError` if credits drain between the
            estimate and the call (race window is small but real).

        Raises:
            ValidationError: ``operation`` is not a known credit operation.
        """
        response = self._transport.request(
            "GET",
            f"{_API_PATH}/estimate",
            params={"operation": operation, "quantity": quantity},
        )
        return self._parse(CreditEstimate, response)
