"""Training resource — create, list, get, cancel, wait_for_completion.

Training is asynchronous: :meth:`Training.create` queues a Modal job and
returns immediately. The default ``wait=True`` polls until the run reaches
a terminal status (``completed`` / ``failed`` / ``cancelled``). Pass
``wait=False`` to fire-and-forget and poll later via
:meth:`Training.wait_for_completion`.

Credit handling is fully server-side — the backend pre-charges based on
the requested ``epochs`` and ``gpu_type``, then refunds the unused portion
after Modal reports actual GPU minutes. Insufficient credits surface as
:class:`PaymentRequiredError` (HTTP 402) before the Modal spawn happens.
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any, cast

from pictograph._http.pagination import OffsetPager
from pictograph.exceptions import ApiError, PollTimeoutError
from pictograph.models.training import GpuType, PipelineType, TrainingRun, TrainingStatus
from pictograph.resources._base import Resource

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

_API_PATH = "/api/v1/developer/training/"
_DEFAULT_POLL_INTERVAL = 5.0
_DEFAULT_TIMEOUT = 7200.0  # 2h — Modal training service hard cap
_TERMINAL_STATUSES: frozenset[TrainingStatus] = frozenset(
    {"completed", "failed", "cancelled"}
)


class Training(Resource):
    """Operations on training runs."""

    def create(
        self,
        dataset_name: str,
        export_name: str,
        *,
        pipeline_type: PipelineType,
        name: str,
        config: dict[str, Any] | None = None,
        gpu_type: GpuType = "a10g",
        wait: bool = True,
        poll_interval: float = _DEFAULT_POLL_INTERVAL,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> TrainingRun:
        """Spawn a new training run.

        The backend looks up dataset and export by name within your
        organization, validates the export is ``completed``, deducts the
        estimated credit cost, and spawns the Modal job. Returns the
        :class:`TrainingRun` — pending if ``wait=False``, terminal status
        otherwise.

        Args:
            dataset_name: Project name within your organization.
            export_name: Completed export's name (within the dataset).
            pipeline_type: ``"yolox"``, ``"detectron2"``, ``"sm_pytorch"``,
                ``"classification"``, ``"rfdetr_detection"``, or
                ``"rfdetr_segmentation"``.
            name: Human-readable label for this run (1-100 chars).
            config: Pipeline-specific hyperparameters: ``epochs``,
                ``batch_size``, ``learning_rate``, ``model_type``, etc.
                Empty dict uses pipeline defaults.
            gpu_type: ``"a10g"`` (default), ``"a100"``, or ``"h100"``.
            wait: When ``True`` (default), poll until the run reaches a
                terminal status. When ``False``, return after the spawn.
            poll_interval: Seconds between status checks when waiting.
                Defaults to 5s — training is slow, frequent polling wastes
                requests against your rate limit.
            timeout: Maximum seconds to wait. Defaults to 2 hours, matching
                the Modal training service's hard timeout.

        Returns:
            The :class:`TrainingRun` (pending if ``wait=False``, terminal
            otherwise).

        Raises:
            NotFoundError: ``dataset_name`` or ``export_name`` doesn't exist.
            ValidationError: Export is not in ``completed`` status, GPU
                type invalid, or pipeline type invalid.
            PaymentRequiredError: Insufficient credits for the estimated
                cost. The error carries ``credit_cost`` and
                ``credits_remaining`` for agent decision-making.
            ApiError: The training run was spawned but reached ``failed``
                status. ``error_message`` is in the exception's response.
            PollTimeoutError: ``timeout`` elapsed before the run reached a
                terminal status. The Modal job is still running — fetch
                its status later via :meth:`get`.
        """
        body: dict[str, Any] = {
            "dataset_name": dataset_name,
            "export_name": export_name,
            "pipeline_type": pipeline_type,
            "name": name,
            "gpu_type": gpu_type,
            "config": config or {},
        }
        response = self._transport.request("POST", _API_PATH, json=body)
        run = self._parse(TrainingRun, response["training_run"])
        if not wait:
            return run
        return self.wait_for_completion(
            run.id, poll_interval=poll_interval, timeout=timeout
        )

    def list(
        self,
        *,
        dataset_name: str | None = None,
        status: TrainingStatus | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[TrainingRun]:
        """Single-page list of training runs in your organization."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if dataset_name is not None:
            params["dataset_name"] = dataset_name
        if status is not None:
            params["status"] = status
        response = self._transport.request("GET", _API_PATH, params=params)
        return self._parse_list(TrainingRun, response.get("training_runs", []))

    def iter(
        self,
        *,
        dataset_name: str | None = None,
        status: TrainingStatus | None = None,
        page_size: int = 50,
        max_total: int | None = None,
    ) -> OffsetPager[TrainingRun]:
        """Auto-paging iterator across every training run in your org."""
        base: dict[str, Any] = {}
        if dataset_name is not None:
            base["dataset_name"] = dataset_name
        if status is not None:
            base["status"] = status

        def fetch(offset: int, limit: int) -> Mapping[str, Any]:
            params = {**base, "offset": offset, "limit": limit}
            return cast(
                "Mapping[str, Any]",
                self._transport.request("GET", _API_PATH, params=params),
            )

        return OffsetPager(
            fetch,
            items_key="training_runs",
            page_size=page_size,
            max_total=max_total,
            parse_item=lambda raw: self._parse(TrainingRun, raw),
        )

    def get(self, run_id: str) -> TrainingRun:
        """Fetch a single training run's current status, metrics, and progress."""
        response = self._transport.request("GET", f"{_API_PATH}{run_id}")
        return self._parse(TrainingRun, response["training_run"])

    def cancel(self, run_id: str) -> TrainingRun:
        """Mark a training run as cancelled.

        Note: this updates the database immediately, but Modal jobs already
        spawned continue to completion (Modal lacks in-flight cancellation).
        The completion callback refunds unused pre-charged credits.
        """
        response = self._transport.request(
            "POST", f"{_API_PATH}{run_id}/cancel"
        )
        return self._parse(TrainingRun, response["training_run"])

    def wait_for_completion(
        self,
        run_id: str,
        *,
        poll_interval: float = _DEFAULT_POLL_INTERVAL,
        timeout: float = _DEFAULT_TIMEOUT,
        sleep: Callable[[float], None] | None = None,
    ) -> TrainingRun:
        """Poll a training run until it reaches a terminal status.

        Args:
            run_id: Training run UUID.
            poll_interval: Seconds between checks (default 5s).
            timeout: Maximum seconds to wait (default 7200 = 2h).
            sleep: Override the sleep function (testing hook).

        Returns:
            The :class:`TrainingRun` in ``completed`` status.

        Raises:
            ApiError: The run reached ``failed`` or ``cancelled`` status.
                ``error_message`` is in the exception's response.
            PollTimeoutError: ``timeout`` elapsed before completion. The
                run is still running on Modal.
        """
        if poll_interval <= 0:
            raise ValueError(f"poll_interval must be > 0, got {poll_interval}")
        if timeout <= 0:
            raise ValueError(f"timeout must be > 0, got {timeout}")
        sleep_fn = sleep if sleep is not None else time.sleep
        deadline = time.monotonic() + timeout
        while True:
            run = self.get(run_id)
            if run.status == "completed":
                return run
            if run.status in ("failed", "cancelled"):
                raise ApiError(
                    f"Training run '{run.name}' ended with status "
                    f"'{run.status}': {run.error_message or 'no error message provided'}",
                    response=run.model_dump(mode="json"),
                )
            if time.monotonic() >= deadline:
                raise PollTimeoutError(
                    f"Training run '{run.name}' did not complete within "
                    f"{timeout:.0f}s (last status: {run.status}). The Modal "
                    f"job is still running — fetch later via client.training.get(...)."
                )
            sleep_fn(poll_interval)
