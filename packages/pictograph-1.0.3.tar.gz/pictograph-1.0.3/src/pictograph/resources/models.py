"""Models resource — read, download, delete trained models.

Models are produced by the training pipeline; they are never created
directly via this resource. Use :meth:`Training.create` to train one.

Download streams the ONNX weights via a backend-issued signed GCS URL
(60-min TTL), with the same atomic ``.part`` file rename as
``client.images.download`` so a failed transfer leaves no partial file at
the destination.
"""

from __future__ import annotations

import contextlib
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

import httpx

from pictograph._http.pagination import OffsetPager
from pictograph._http.streaming import DEFAULT_CHUNK_SIZE
from pictograph.exceptions import ApiError
from pictograph.models.model import Model, ModelStatus, ModelType
from pictograph.resources._base import Resource

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

_API_PATH = "/api/v1/developer/models/"


class Models(Resource):
    """Operations on trained CV models in your organization."""

    # ───────────── list / iter ─────────────

    def list(
        self,
        *,
        dataset_name: str | None = None,
        status: ModelStatus | None = None,
        model_type: ModelType | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Model]:
        """Single-page list of models in your organization.

        Args:
            dataset_name: Restrict to models trained on this dataset.
            status: Restrict to a lifecycle status.
            model_type: Restrict to one of the four model categories.
            limit: Page size (backend cap: 100).
            offset: Page offset for paginating manually.
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if dataset_name is not None:
            params["dataset_name"] = dataset_name
        if status is not None:
            params["status"] = status
        if model_type is not None:
            params["model_type"] = model_type
        response = self._transport.request("GET", _API_PATH, params=params)
        return self._parse_list(Model, response.get("models", []))

    def iter(
        self,
        *,
        dataset_name: str | None = None,
        status: ModelStatus | None = None,
        model_type: ModelType | None = None,
        page_size: int = 50,
        max_total: int | None = None,
    ) -> OffsetPager[Model]:
        """Auto-paging iterator across every model in your organization."""
        base: dict[str, Any] = {}
        if dataset_name is not None:
            base["dataset_name"] = dataset_name
        if status is not None:
            base["status"] = status
        if model_type is not None:
            base["model_type"] = model_type

        def fetch(offset: int, limit: int) -> Mapping[str, Any]:
            params = {**base, "offset": offset, "limit": limit}
            return cast(
                "Mapping[str, Any]",
                self._transport.request("GET", _API_PATH, params=params),
            )

        return OffsetPager(
            fetch,
            items_key="models",
            page_size=page_size,
            max_total=max_total,
            parse_item=lambda raw: self._parse(Model, raw),
        )

    # ───────────── get / download / delete ─────────────

    def get(self, model_id: str) -> Model:
        """Fetch a single model by UUID."""
        response = self._transport.request("GET", f"{_API_PATH}{model_id}")
        return self._parse(Model, response["model"])

    def download(
        self,
        model_id: str,
        output_path: str | Path,
        *,
        chunk_size: int = DEFAULT_CHUNK_SIZE,
        progress: Callable[[int, int], None] | None = None,
    ) -> Path:
        """Download the model's ONNX weights file.

        Fetches a signed GCS URL from the backend, then streams bytes from
        GCS via a scoped ``httpx.Client`` (no SDK auth on the GCS URL).
        Bytes land in a sibling ``.part`` file and are renamed atomically
        on success — failures leave nothing at the destination.

        Args:
            model_id: Model UUID.
            output_path: Local path for the ONNX file. Parent dirs created.
            chunk_size: Streaming chunk size (default 8 MB).
            progress: Optional ``(bytes_so_far, total_bytes)`` callback.
                ``total_bytes`` is ``0`` if the GCS response has no
                ``Content-Length``.

        Returns:
            The output path.

        Raises:
            NotFoundError: Model UUID doesn't exist or weights file missing.
            ValidationError: Model status is not ``ready``.
            ApiError: GCS download failed.
        """
        url_response = self._transport.request(
            "GET", f"{_API_PATH}{model_id}/download"
        )
        download_url: str = url_response["download_url"]

        out = Path(output_path).expanduser()
        out.parent.mkdir(parents=True, exist_ok=True)
        tmp = out.with_name(out.name + ".part")

        try:
            with (
                httpx.Client(
                    http2=True,
                    timeout=httpx.Timeout(self._transport._config.timeout, read=600.0),
                ) as gcs,
                gcs.stream("GET", download_url) as response,
            ):
                if response.status_code >= 300:
                    response.read()
                    raise ApiError(
                        f"Model download failed: HTTP {response.status_code}",
                        status_code=response.status_code,
                        response=response.text,
                    )
                total = int(response.headers.get("Content-Length", 0))
                sent = 0
                with tmp.open("wb") as fh:
                    for chunk in response.iter_bytes(chunk_size=chunk_size):
                        fh.write(chunk)
                        sent += len(chunk)
                        if progress is not None:
                            progress(sent, total)
        except BaseException:
            with contextlib.suppress(OSError):
                tmp.unlink()
            raise

        tmp.replace(out)
        return out

    def delete(self, model_id: str) -> None:
        """Delete a model. Requires admin or owner role.

        Removes the database row immediately. GCS cleanup runs as a
        background task — the file may linger briefly after this call
        returns.
        """
        self._transport.request("DELETE", f"{_API_PATH}{model_id}")
