"""Auto-annotate resource — SAM3 point / box / text + batch jobs.

Single-image SAM3 calls are synchronous and fast (subsecond after the
first warmup). The batch surface kicks off a background job and returns
a :class:`BatchJob` that callers poll to terminal status.

Annotations land in canonical Pictograph JSON — the same Pydantic models
:class:`pictograph.annotations.save` consumes. Common pattern:

    result = client.auto_annotate.box(
        "road-signs", "frame_001.jpg",
        box={"x": 100, "y": 100, "w": 200, "h": 200},
        name="stop_sign",
    )
    if result.status == "success":
        client.annotations.save("img-uuid", annotations=result.annotations)

Credit charging happens server-side at the prompt boundary (3-credit SAM3
minimum per call; batch math is ``3 + ceil(0.1 · n_images)`` for SAM3 or
``2 + ceil(0.03 · n_images)`` for trained ONNX models).
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any

from pictograph.exceptions import ApiError, PollTimeoutError
from pictograph.models.auto_annotate import (
    BatchClass,
    BatchJob,
    BatchJobStatus,
    PromptResult,
)
from pictograph.resources._base import Resource

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence

_API_PATH = "/api/v1/developer/auto-annotate"
_DEFAULT_POLL_INTERVAL = 5.0
_DEFAULT_BATCH_TIMEOUT = 1800.0  # 30 minutes — SAM3 batch hard cap
_TERMINAL_STATUSES: frozenset[BatchJobStatus] = frozenset(
    {"completed", "failed", "cancelled"}
)


class AutoAnnotate(Resource):
    """SAM3 prompts (point / box / text) + batch jobs."""

    # ───────────── single-image prompts ─────────────

    def point(
        self,
        dataset_name: str,
        image_filename: str,
        *,
        x: int,
        y: int,
        name: str = "object",
        positive_points: Sequence[tuple[int, int]] | None = None,
        negative_points: Sequence[tuple[int, int]] | None = None,
        score_threshold: float = 0.75,
    ) -> PromptResult:
        """SAM3 point prompt → single polygon annotation.

        The first prompt on a new image triggers GPU embedding generation
        (~1-2s on a warm container). Subsequent prompts on the same image
        are sub-second.

        Args:
            dataset_name: Project name within your org.
            image_filename: Image filename (NOT the UUID — agent-friendly
                lookup via ``(dataset_name, image_filename)``).
            x, y: Anchor point coordinates in absolute pixels.
            name: Class label for the resulting annotation.
            positive_points: Extra positive anchors as ``[(x, y), ...]``.
            negative_points: Negative-prompt anchors (excluded regions).
            score_threshold: Minimum SAM3 score to include (0-1).

        Returns:
            :class:`PromptResult` — ``status="success"`` carries one polygon
            annotation in ``annotations[0]``.

        Raises:
            NotFoundError: Dataset or image missing.
            PaymentRequiredError: Insufficient credits (3-credit minimum).
        """
        body: dict[str, Any] = {
            "dataset_name": dataset_name,
            "image_filename": image_filename,
            "x": x,
            "y": y,
            "name": name,
            "score_threshold": score_threshold,
        }
        if positive_points is not None:
            body["positive_points"] = [list(p) for p in positive_points]
        if negative_points is not None:
            body["negative_points"] = [list(p) for p in negative_points]
        response = self._transport.request(
            "POST", f"{_API_PATH}/sam3/point", json=body
        )
        # Backend wraps the single annotation under "annotation" rather than
        # "annotations" — normalise into a list before parsing.
        ann = response.get("annotation")
        normalised = {
            "status": response.get("status", "success"),
            "annotations": [ann] if ann else [],
            "score": response.get("score"),
            "inference_time": response.get("inference_time"),
        }
        return self._parse(PromptResult, normalised)

    def box(
        self,
        dataset_name: str,
        image_filename: str,
        *,
        box: dict[str, float],
        name: str,
        confidence_threshold: float = 0.5,
        return_polygon: bool = True,
        negative_boxes: Sequence[dict[str, float]] | None = None,
    ) -> PromptResult:
        """SAM3 box prompt → bbox + optional polygon annotation(s).

        Args:
            dataset_name: Project name.
            image_filename: Image filename.
            box: ``{"x": float, "y": float, "w": float, "h": float}`` in
                absolute pixels.
            name: Class label.
            confidence_threshold: Minimum SAM3 confidence to include.
            return_polygon: When ``True`` (default), include a polygon
                annotation in addition to the refined bbox. Set ``False``
                if only the bbox is wanted.
            negative_boxes: Boxes to exclude from segmentation (e.g.
                shift-drag exclusion zones).

        Returns:
            :class:`PromptResult` — ``annotations`` may be empty if status
            is ``no_detection`` or ``below_threshold``.
        """
        body: dict[str, Any] = {
            "dataset_name": dataset_name,
            "image_filename": image_filename,
            "box": box,
            "name": name,
            "confidence_threshold": confidence_threshold,
            "return_polygon": return_polygon,
        }
        if negative_boxes is not None:
            body["negative_boxes"] = [dict(b) for b in negative_boxes]
        response = self._transport.request(
            "POST", f"{_API_PATH}/sam3/box", json=body
        )
        return self._parse(
            PromptResult,
            {
                "status": response.get("status", "success"),
                "annotations": response.get("annotations", []),
                "score": response.get("score"),
                "inference_time": response.get("inference_time"),
            },
        )

    def text(
        self,
        dataset_name: str,
        image_filename: str,
        *,
        text_prompt: str,
        output_type: str = "polygon",
        confidence_threshold: float = 0.3,
        max_detections: int = 50,
    ) -> PromptResult:
        """SAM3 text prompt → list of detected annotations.

        Searches the image for instances matching ``text_prompt`` (e.g.
        ``"person"``, ``"red car"``). Returns up to ``max_detections``
        bounding boxes or polygons, sorted by confidence.

        Args:
            dataset_name, image_filename: As with :meth:`point` / :meth:`box`.
            text_prompt: Natural language description.
            output_type: ``"polygon"`` (default) or ``"bbox"``.
            confidence_threshold: Minimum confidence (0-1).
            max_detections: Cap on result count (1-100).
        """
        body: dict[str, Any] = {
            "dataset_name": dataset_name,
            "image_filename": image_filename,
            "text_prompt": text_prompt,
            "output_type": output_type,
            "confidence_threshold": confidence_threshold,
            "max_detections": max_detections,
        }
        response = self._transport.request(
            "POST", f"{_API_PATH}/sam3/text", json=body
        )
        return self._parse(
            PromptResult,
            {
                "status": response.get("status", "success"),
                "annotations": response.get("annotations", []),
                "score": None,
                "inference_time": response.get("inference_time"),
            },
        )

    # ───────────── batch ─────────────

    def batch(
        self,
        dataset_name: str,
        image_filenames: Sequence[str],
        classes: Sequence[BatchClass | dict[str, Any]],
        *,
        confidence_threshold: float = 0.5,
        model_id: str | None = None,
        top_k: int = 1,
        wait: bool = True,
        poll_interval: float = _DEFAULT_POLL_INTERVAL,
        timeout: float = _DEFAULT_BATCH_TIMEOUT,
    ) -> BatchJob:
        """Spawn an auto-annotate batch job over many images.

        SAM3 path (``model_id=None`` or ``"sam3"``) requires at least one
        class. Trained-model path (``model_id=<uuid>``) supports
        classification models with empty classes (predicted classes land
        as tags).

        Args:
            dataset_name: Project name.
            image_filenames: Filenames to process (1-500).
            classes: Class configs — :class:`BatchClass` instances or raw
                dicts ``{"name": str, "output_type": "polygon"|"bbox"|"tag"}``.
            confidence_threshold: Minimum confidence to include.
            model_id: Trained-model UUID, or ``None`` (default) for SAM3.
            top_k: Classifier-only — how many predicted tags per image.
            wait: When ``True`` (default), poll until terminal status.
            poll_interval: Seconds between checks (default 5s).
            timeout: Max seconds to wait (default 1800 = 30 min).

        Returns:
            :class:`BatchJob`. If ``wait=True``, returns the terminal-state
            snapshot; if ``wait=False``, returns the kick-off snapshot.

        Raises:
            NotFoundError: Dataset or no matching images.
            PaymentRequiredError: Insufficient credits for the estimate.
            ValidationError: SAM3 path with no classes.
            ApiError: Job ended in ``failed`` status (when ``wait=True``).
            PollTimeoutError: Deadline elapsed (when ``wait=True``).
        """
        body: dict[str, Any] = {
            "dataset_name": dataset_name,
            "image_filenames": list(image_filenames),
            "classes": [
                c.model_dump(exclude_none=True)
                if isinstance(c, BatchClass)
                else dict(c)
                for c in classes
            ],
            "confidence_threshold": confidence_threshold,
            "top_k": top_k,
        }
        if model_id is not None:
            body["model_id"] = model_id
        response = self._transport.request("POST", f"{_API_PATH}/batch", json=body)
        job = self._parse(BatchJob, response)
        if not wait:
            return job
        return self.wait_for_batch(
            job.job_id, poll_interval=poll_interval, timeout=timeout
        )

    def get_batch(self, job_id: str) -> BatchJob:
        """Fetch the current status of a batch job."""
        response = self._transport.request("GET", f"{_API_PATH}/batch/{job_id}")
        return self._parse(BatchJob, response)

    def cancel_batch(self, job_id: str) -> BatchJob:
        """Cancel a pending or running batch job.

        Does NOT refund pre-charged credits — Modal's container has
        already spun up by the time SDK callers see the job.
        """
        response = self._transport.request(
            "POST", f"{_API_PATH}/batch/{job_id}/cancel"
        )
        return self._parse(BatchJob, response)

    def wait_for_batch(
        self,
        job_id: str,
        *,
        poll_interval: float = _DEFAULT_POLL_INTERVAL,
        timeout: float = _DEFAULT_BATCH_TIMEOUT,
        sleep: Callable[[float], None] | None = None,
    ) -> BatchJob:
        """Poll a batch job until terminal status or timeout."""
        if poll_interval <= 0:
            raise ValueError(f"poll_interval must be > 0, got {poll_interval}")
        if timeout <= 0:
            raise ValueError(f"timeout must be > 0, got {timeout}")
        sleep_fn = sleep if sleep is not None else time.sleep
        deadline = time.monotonic() + timeout
        while True:
            job = self.get_batch(job_id)
            if job.status == "completed":
                return job
            if job.status in ("failed", "cancelled"):
                raise ApiError(
                    f"Batch job {job_id} ended with status '{job.status}': "
                    f"{job.error_message or 'no error message provided'}",
                    response=job.model_dump(mode="json"),
                )
            if time.monotonic() >= deadline:
                raise PollTimeoutError(
                    f"Batch job {job_id} did not complete within {timeout:.0f}s "
                    f"(last status: {job.status}). Fetch later via "
                    f"client.auto_annotate.get_batch(...)."
                )
            sleep_fn(poll_interval)
