"""Datasets resource: list, get-by-name/uuid, batch download.

The Pictograph "dataset" is a project — a collection of images sharing a
class set. Datasets are unique by ``(organization, name)`` and the public
SDK strongly prefers name-based lookups (agents pass strings users gave
them; UUID indirection is friction). UUID lookup is exposed via
:meth:`Datasets.get_by_id` for callers that already have an ID in hand.

The :meth:`Datasets.download` method is the workhorse: it fetches a batch
of signed GCS URLs in one call, then downloads images and annotations in
parallel via a worker pool. Failures don't halt the operation — the call
returns a structured :class:`DownloadReport` with a per-file failure list
so callers can retry the subset.
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, cast

import httpx

from pictograph._http.pagination import OffsetPager
from pictograph._http.streaming import DEFAULT_CHUNK_SIZE
from pictograph.exceptions import ApiError
from pictograph.models.dataset import Dataset
from pictograph.resources._base import Resource

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

DownloadMode = Literal["full", "images_only", "annotations_only"]
"""Three modes mapped 1:1 to the backend ``download`` endpoint."""

_API_PATH = "/api/v1/developer/datasets/"
_DEFAULT_DOWNLOAD_WORKERS = 10
_DEFAULT_DOWNLOAD_LIMIT = 10000  # backend caps at 10000


@dataclass(frozen=True)
class DownloadFailure:
    """Single failed download — collected and returned, not raised."""

    filename: str
    kind: Literal["image", "annotation"]
    reason: str


@dataclass
class DownloadReport:
    """Result of a :meth:`Datasets.download` invocation.

    Inspect ``failures`` to retry a partial failure. ``success`` is ``True``
    only when every requested file landed.
    """

    dataset_id: str
    images_downloaded: int = 0
    annotations_downloaded: int = 0
    failures: list[DownloadFailure] = field(default_factory=list)

    @property
    def total_attempted(self) -> int:
        return self.images_downloaded + self.annotations_downloaded + len(self.failures)

    @property
    def success(self) -> bool:
        return not self.failures


class Datasets(Resource):
    """Operations on datasets (projects) in the authenticated organization."""

    # ───────────── list / iter ─────────────

    def list(self, *, limit: int = 100) -> list[Dataset]:
        """Single-page list of datasets.

        For full enumeration prefer :meth:`iter`, which auto-pages.

        Args:
            limit: Maximum datasets to return in this page (backend cap: 1000).
        """
        response = self._transport.request("GET", _API_PATH, params={"limit": limit})
        return self._parse_list(Dataset, response.get("datasets", []))

    def iter(
        self,
        *,
        page_size: int = 100,
        max_total: int | None = None,
    ) -> OffsetPager[Dataset]:
        """Auto-paging iterator over every dataset in the organization.

        Returns a :class:`OffsetPager` — iterate it, materialise via
        ``.all()``, or peek with ``.first()``.

        Args:
            page_size: Items fetched per backend round-trip.
            max_total: Stop after this many items, even mid-page. ``None``
                yields every available item.
        """

        def fetch(offset: int, limit: int) -> Mapping[str, Any]:
            return cast(
                "Mapping[str, Any]",
                self._transport.request(
                    "GET",
                    _API_PATH,
                    params={"offset": offset, "limit": limit},
                ),
            )

        return OffsetPager(
            fetch,
            items_key="datasets",
            page_size=page_size,
            max_total=max_total,
            parse_item=lambda raw: self._parse(Dataset, raw),
        )

    # ───────────── get (by name / by id) ─────────────

    def get(
        self,
        name: str,
        *,
        include_images: bool = False,
        images_limit: int = 1000,
        images_offset: int = 0,
    ) -> Dataset:
        """Fetch a dataset by name (unique within an organization).

        Args:
            name: Dataset name. Case-sensitive.
            include_images: When ``True``, the returned dataset includes its
                first ``images_limit`` images. Use :meth:`Datasets.download`
                for bulk image enumeration.
            images_limit: How many images to include (backend cap: 10000).
            images_offset: Paginate the embedded image list.
        """
        params: dict[str, Any] = {}
        if include_images:
            params["include_images"] = "true"
            params["images_limit"] = images_limit
            params["images_offset"] = images_offset
        response = self._transport.request(
            "GET",
            f"{_API_PATH}by-name/{name}",
            params=params or None,
        )
        return self._parse(Dataset, response["dataset"])

    def get_by_id(self, dataset_id: str) -> Dataset:
        """Fetch a dataset by UUID. Prefer :meth:`get` (by name) when possible."""
        response = self._transport.request("GET", f"{_API_PATH}{dataset_id}")
        return self._parse(Dataset, response["dataset"])

    # ───────────── batch download ─────────────

    def download(
        self,
        name: str,
        output_dir: str | Path,
        *,
        mode: DownloadMode = "full",
        status_filter: str | None = None,
        max_workers: int = _DEFAULT_DOWNLOAD_WORKERS,
        progress: Callable[[int, int, str | None], None] | None = None,
    ) -> DownloadReport:
        """Download a dataset's images and/or annotations to a local directory.

        Fetches a batch of signed GCS URLs in one backend call, then
        downloads in parallel via a thread pool.

        Args:
            name: Dataset name.
            output_dir: Local directory to write into. Created if missing.
                Image files land at ``output_dir/<filename>``; annotation
                JSON files at ``output_dir/<filename>.json``.
            mode: ``"full"`` (images + annotations), ``"images_only"``,
                or ``"annotations_only"``.
            status_filter: Restrict to images with this status
                (``"complete"`` / ``"in_progress"`` / ``"new"``).
            max_workers: Concurrent download threads. Defaults to 10.
            progress: Optional ``(completed, total, filename)`` callback,
                fired after each file finishes (success or failure).

        Returns:
            A :class:`DownloadReport`. Inspect ``.failures`` for partial
            failures; the call does not raise on individual file errors.

        Raises:
            ValidationError / NotFoundError: From the initial batch-URL
                fetch (e.g., dataset doesn't exist).
        """
        out = Path(output_dir).expanduser()
        out.mkdir(parents=True, exist_ok=True)

        params: dict[str, Any] = {"mode": mode, "limit": _DEFAULT_DOWNLOAD_LIMIT}
        if status_filter is not None:
            params["status_filter"] = status_filter
        listing = self._transport.request(
            "GET",
            f"{_API_PATH}by-name/{name}/download",
            params=params,
        )

        items: list[dict[str, Any]] = listing.get("items", [])
        dataset_id: str = listing.get("dataset_id", "")
        report = DownloadReport(dataset_id=dataset_id)
        if not items:
            return report

        # Build the list of work units — one per image, plus optionally one per
        # annotation. Order matters only for predictable progress reporting.
        @dataclass(frozen=True)
        class _Task:
            kind: Literal["image", "annotation"]
            url: str
            dest: Path
            filename: str

        tasks: list[_Task] = []
        for item in items:
            filename = item["filename"]
            if mode in ("full", "images_only") and item.get("image_url"):
                tasks.append(
                    _Task(
                        kind="image",
                        url=item["image_url"],
                        dest=out / filename,
                        filename=filename,
                    )
                )
            if mode in ("full", "annotations_only") and item.get("annotation_url"):
                tasks.append(
                    _Task(
                        kind="annotation",
                        url=item["annotation_url"],
                        dest=out / f"{filename}.json",
                        filename=filename,
                    )
                )

        total = len(tasks)
        if total == 0:
            return report

        # Shared external httpx.Client for GCS image downloads (no auth, with
        # connection pooling). Annotation downloads route through the SDK's
        # transport (which adds X-API-Key automatically).
        with httpx.Client(
            http2=True,
            timeout=httpx.Timeout(self._transport._config.timeout, read=300.0),
            limits=httpx.Limits(
                max_connections=max_workers,
                max_keepalive_connections=max_workers,
            ),
        ) as gcs_client:

            def run_task(task: _Task) -> tuple[_Task, str | None]:
                try:
                    if task.kind == "image":
                        _stream_to_file(gcs_client, task.url, task.dest)
                    else:
                        _fetch_annotation_to_file(self._transport, task.url, task.dest)
                    return task, None
                except (httpx.HTTPError, ApiError, OSError) as exc:
                    # ``httpx.HTTPError`` is the union of RequestError (transport
                    # failures) and HTTPStatusError (4xx/5xx from GCS). Both must
                    # land in ``failures``, never propagate from the worker pool.
                    return task, str(exc)

            completed = 0
            with ThreadPoolExecutor(max_workers=max_workers) as pool:
                futures = [pool.submit(run_task, t) for t in tasks]
                for future in as_completed(futures):
                    task, err = future.result()
                    completed += 1
                    if err is None:
                        if task.kind == "image":
                            report.images_downloaded += 1
                        else:
                            report.annotations_downloaded += 1
                    else:
                        report.failures.append(
                            DownloadFailure(
                                filename=task.filename,
                                kind=task.kind,
                                reason=err,
                            )
                        )
                    if progress is not None:
                        progress(completed, total, task.filename)

        return report


# ───────────── module-private helpers ─────────────


def _stream_to_file(
    client: httpx.Client,
    url: str,
    dest: Path,
    *,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
) -> None:
    """Stream a signed GCS URL to disk in chunks."""
    with client.stream("GET", url) as response:
        if response.status_code >= 300:
            response.read()
            raise httpx.HTTPStatusError(
                f"GCS download failed: HTTP {response.status_code}",
                request=response.request,
                response=response,
            )
        with dest.open("wb") as fh:
            for chunk in response.iter_bytes(chunk_size=chunk_size):
                fh.write(chunk)


def _fetch_annotation_to_file(
    transport: Any,  # _http.transport.Transport — typed loosely to avoid runtime import cycle
    url: str,
    dest: Path,
) -> None:
    """Fetch an annotation JSON file via the authenticated SDK transport.

    The annotation download endpoint returns JSON, not bytes, so we pretty-
    print it on disk for human-readable inspection. Bit-for-bit fidelity is
    preserved (json.dumps is round-trip stable for the data we emit).
    """
    import json

    payload = transport.request("GET", url)
    with dest.open("w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2)
