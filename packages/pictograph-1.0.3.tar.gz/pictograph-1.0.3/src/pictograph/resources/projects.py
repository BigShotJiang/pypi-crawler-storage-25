"""Projects resource — create, update, delete + class management.

Companion to :class:`pictograph.resources.datasets.Datasets`. Datasets is
download-side (read + bulk fetch); Projects is workspace-side (create /
update / delete). Both surface the same backend rows under different
mental models.

Naming uses ``name`` everywhere — agents pass strings users gave them,
not UUIDs. Cross-org access returns 404 (consistent with other dev
routes).

Class-list updates are **replace, not merge**. To add or remove a single
class, fetch the project, mutate the list locally, and pass the full
result to :meth:`Projects.update`. This matches the editor's behavior and
keeps the LLM-facing surface simple ("set classes to X" beats "add Y,
remove Z, recolor Z2").
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from pictograph._http.pagination import OffsetPager
from pictograph.models.project import Project, ProjectClass
from pictograph.resources._base import Resource

if TYPE_CHECKING:
    from collections.abc import Sequence

_API_PATH = "/api/v1/developer/projects/"


class Projects(Resource):
    """CRUD on projects + their class config."""

    # ───────────── list / iter ─────────────

    def list(self, *, limit: int = 50, offset: int = 0) -> list[Project]:
        """Single-page list of projects in your organization.

        Args:
            limit: Page size (backend cap: 200).
            offset: Page offset for manual pagination.
        """
        response = self._transport.request(
            "GET", _API_PATH, params={"limit": limit, "offset": offset}
        )
        return self._parse_list(Project, response.get("projects", []))

    def iter(
        self,
        *,
        page_size: int = 50,
        max_total: int | None = None,
    ) -> OffsetPager[Project]:
        """Auto-paging iterator over every project in the org."""

        def fetch(offset: int, limit: int) -> dict[str, Any]:
            return cast(
                "dict[str, Any]",
                self._transport.request(
                    "GET",
                    _API_PATH,
                    params={"offset": offset, "limit": limit},
                ),
            )

        return OffsetPager(
            fetch,
            items_key="projects",
            page_size=page_size,
            max_total=max_total,
            parse_item=lambda raw: self._parse(Project, raw),
        )

    # ───────────── get / create / update / delete ─────────────

    def get(self, name: str) -> Project:
        """Fetch a project by name. Raises ``NotFoundError`` if missing."""
        response = self._transport.request("GET", f"{_API_PATH}{name}")
        return self._parse(Project, response["project"])

    def create(
        self,
        name: str,
        *,
        description: str | None = None,
        annotation_types: Sequence[str] | None = None,
        classes: Sequence[ProjectClass | dict[str, Any]] | None = None,
    ) -> Project:
        """Create a new project + initial class config.

        Args:
            name: Project name. Must be unique within the org.
            description: Optional human-readable description.
            annotation_types: Allowed types on the project. Defaults to
                ``["bbox"]``. Allowed values: ``bbox``/``box``, ``polygon``,
                ``polyline``, ``keypoint``.
            classes: Class definitions. Accepts :class:`ProjectClass`
                instances or raw dicts (validated server-side).

        Returns:
            The newly created :class:`Project` with its initial config.

        Raises:
            ConflictError: A project with this name already exists.
            PaymentRequiredError: Project cap reached for the org's tier.
            ForbiddenError: API key lacks member+/admin/owner role.
            ValidationError: Invalid ``annotation_types`` or class payload.
        """
        body: dict[str, Any] = {"name": name}
        if description is not None:
            body["description"] = description
        if annotation_types is not None:
            body["annotation_types"] = annotation_types
        if classes is not None:
            body["classes"] = [
                c.model_dump(exclude_none=True)
                if isinstance(c, ProjectClass)
                else dict(c)
                for c in classes
            ]
        response = self._transport.request("POST", _API_PATH, json=body)
        return self._parse(Project, response["project"])

    def update(
        self,
        name: str,
        *,
        new_name: str | None = None,
        description: str | None = None,
        annotation_types: Sequence[str] | None = None,
        classes: Sequence[ProjectClass | dict[str, Any]] | None = None,
    ) -> Project:
        """Patch a project's metadata or replace its class list.

        ``classes`` is a *replace* operation, not a merge — if you want to
        add or remove a single class, fetch first and mutate locally:

            p = client.projects.get("road-signs")
            p.classes.append(ProjectClass(name="yield", type="bbox", color="#3cb44b"))
            client.projects.update("road-signs", classes=p.classes)

        Args:
            name: Current project name.
            new_name: Rename to this. Must be unique within the org.
            description: New description.
            annotation_types: Replace the allowed types list.
            classes: Replace the class list.

        Returns:
            The refreshed :class:`Project` after the update.

        Raises:
            NotFoundError: ``name`` doesn't exist in your org.
            ConflictError: ``new_name`` collides with an existing project.
            ForbiddenError: API key lacks member+/admin/owner role.
            ValidationError: Invalid ``annotation_types`` or class payload.
        """
        body: dict[str, Any] = {}
        if new_name is not None:
            body["name"] = new_name
        if description is not None:
            body["description"] = description
        if annotation_types is not None:
            body["annotation_types"] = annotation_types
        if classes is not None:
            body["classes"] = [
                c.model_dump(exclude_none=True)
                if isinstance(c, ProjectClass)
                else dict(c)
                for c in classes
            ]
        if not body:
            raise ValueError(
                "At least one of new_name / description / annotation_types / "
                "classes must be provided."
            )
        response = self._transport.request("PATCH", f"{_API_PATH}{name}", json=body)
        return self._parse(Project, response["project"])

    def delete(self, name: str) -> dict[str, Any]:
        """Permanently delete a project + all its images, folders, GCS blobs.

        Returns the ``deleted`` summary so callers can verify counts.

        Raises:
            NotFoundError: ``name`` doesn't exist in your org.
            ForbiddenError: API key lacks admin/owner role.
        """
        response = self._transport.request("DELETE", f"{_API_PATH}{name}")
        return cast("dict[str, Any]", response.get("deleted", {}))
