"""Video resource — upload, probe, extract frames into a dataset.

Three-step ingestion:

1. :meth:`Video.upload` — uploads a local video file to a temp GCS path
   (3-step: get-url → PUT bytes → return path). Returns
   :class:`VideoUploadInfo`.
2. :meth:`Video.probe` — runs ``ffprobe`` on the uploaded video and
   returns :class:`VideoMetadata`.
3. :meth:`Video.extract_frames` — kicks off a background frame-extraction
   job. Returns a :class:`VideoExtractionJob`. Pass ``wait=True`` (default)
   to poll until the job is terminal.

The temp video lives under ``{org_id}/temp/videos/...`` until extraction
completes; the backend deletes it from GCS on job completion.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

import httpx

from pictograph._http.streaming import DEFAULT_CHUNK_SIZE
from pictograph.exceptions import ApiError, PollTimeoutError
from pictograph.models.video import (
    VideoExtractionJob,
    VideoJobStatus,
    VideoMetadata,
    VideoUploadInfo,
)
from pictograph.resources._base import Resource

if TYPE_CHECKING:
    from collections.abc import Callable

_API_PATH = "/api/v1/developer/video"
_DEFAULT_POLL_INTERVAL = 3.0
_DEFAULT_TIMEOUT = 1800.0  # 30 min — matches Modal-side soft cap
_TERMINAL_STATUSES: frozenset[VideoJobStatus] = frozenset({"complete", "failed"})


class Video(Resource):
    """Upload videos and extract frames into a dataset's virtual folder."""

    # ───────────── upload ─────────────

    def upload(
        self,
        local_path: str | Path,
        *,
        content_type: str = "video/mp4",
    ) -> VideoUploadInfo:
        """Upload a local video file to a temp GCS path.

        Three-step internally: get signed URL → PUT bytes → return path.
        The returned ``gcs_path`` feeds :meth:`probe` and
        :meth:`extract_frames`. The temp file is auto-deleted from GCS
        when extraction finishes.

        Args:
            local_path: Path to the local video file.
            content_type: MIME type (default ``video/mp4``). Set
                explicitly for non-MP4 sources (``video/quicktime``,
                ``video/webm``, etc.).

        Returns:
            :class:`VideoUploadInfo` — pass ``gcs_path`` to subsequent
            video methods.

        Raises:
            FileNotFoundError: ``local_path`` doesn't exist.
            NetworkError / RequestTimeoutError: GCS PUT failed.
        """
        path = Path(local_path).expanduser()
        if not path.is_file():
            raise FileNotFoundError(f"Video file not found: {path}")

        # Step 1: get signed URL.
        info_response = self._transport.request(
            "POST",
            f"{_API_PATH}/upload-url",
            json={"filename": path.name, "content_type": content_type},
        )
        upload_info = self._parse(VideoUploadInfo, info_response)

        # Step 2: stream the bytes directly to GCS — no backend hop.
        # Use a fresh httpx.Client (no auth headers — GCS signed URL
        # carries its own signature). Generous read timeout for big files.
        with (
            httpx.Client(
                timeout=httpx.Timeout(self._transport._config.timeout, read=600.0)
            ) as gcs_client,
            path.open("rb") as fh,
        ):
            response = gcs_client.put(
                upload_info.upload_url,
                content=_chunked_iter(fh),
                headers={"Content-Type": content_type},
            )
            if response.status_code >= 300:
                raise ApiError(
                    f"GCS upload failed: HTTP {response.status_code} "
                    f"({response.text[:200]})",
                    status_code=response.status_code,
                )

        return upload_info

    # ───────────── probe ─────────────

    def probe(self, gcs_path: str) -> VideoMetadata:
        """Probe an uploaded video for duration / fps / dimensions.

        Slow on large files — backend downloads the full bytes and runs
        ``ffprobe``. Don't poll this; call once after :meth:`upload`.

        Args:
            gcs_path: The ``gcs_path`` returned from :meth:`upload`.

        Raises:
            NotFoundError: Path doesn't exist or belongs to another org.
            ValidationError: Backend couldn't parse the file as a video.
        """
        response = self._transport.request(
            "POST", f"{_API_PATH}/probe", json={"gcs_path": gcs_path}
        )
        return self._parse(VideoMetadata, response)

    # ───────────── extract_frames ─────────────

    def extract_frames(
        self,
        dataset_name: str,
        gcs_path: str,
        *,
        folder_name: str,
        sample_fps: float = 1.0,
        parent_folder_path: str = "/",
        wait: bool = True,
        poll_interval: float = _DEFAULT_POLL_INTERVAL,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> VideoExtractionJob:
        """Extract frames from an uploaded video into a dataset folder.

        Frames are decoded at ``sample_fps`` (lossy compression — pick the
        rate to match your annotation needs), uploaded under
        ``{dataset}/{parent_folder_path}/{folder_name}/``, and registered
        in ``project_images`` with SigLIP embeddings spawned automatically.

        Args:
            dataset_name: Project name within your org.
            gcs_path: From :meth:`upload`.
            folder_name: Virtual folder name to create for the frames.
            sample_fps: Frames per second to extract (default 1.0).
            parent_folder_path: Parent folder in the dataset
                (default ``"/"``).
            wait: When ``True`` (default), poll until terminal status.
            poll_interval: Seconds between polls (default 3s).
            timeout: Max seconds to wait (default 1800 = 30 min).

        Returns:
            :class:`VideoExtractionJob` — terminal-state if ``wait=True``.

        Raises:
            NotFoundError: Dataset or gcs_path missing.
            ApiError: Job ended in ``failed`` status (when ``wait=True``).
            PollTimeoutError: Deadline elapsed (when ``wait=True``).
        """
        body = {
            "dataset_name": dataset_name,
            "gcs_path": gcs_path,
            "folder_name": folder_name,
            "sample_fps": sample_fps,
            "parent_folder_path": parent_folder_path,
        }
        response = self._transport.request(
            "POST", f"{_API_PATH}/extract-frames", json=body
        )
        job = self._parse(VideoExtractionJob, response)
        if not wait:
            return job
        return self.wait_for_extraction(
            job.job_id, poll_interval=poll_interval, timeout=timeout
        )

    def get_extraction(self, job_id: str) -> VideoExtractionJob:
        """Fetch the current status of a frame-extraction job."""
        response = self._transport.request(
            "GET", f"{_API_PATH}/extract-frames/{job_id}"
        )
        return self._parse(VideoExtractionJob, response)

    def wait_for_extraction(
        self,
        job_id: str,
        *,
        poll_interval: float = _DEFAULT_POLL_INTERVAL,
        timeout: float = _DEFAULT_TIMEOUT,
        sleep: Callable[[float], None] | None = None,
    ) -> VideoExtractionJob:
        """Poll a frame-extraction job until terminal status."""
        if poll_interval <= 0:
            raise ValueError(f"poll_interval must be > 0, got {poll_interval}")
        if timeout <= 0:
            raise ValueError(f"timeout must be > 0, got {timeout}")
        sleep_fn = sleep if sleep is not None else time.sleep
        deadline = time.monotonic() + timeout
        while True:
            job = self.get_extraction(job_id)
            if job.status == "complete":
                return job
            if job.status == "failed":
                raise ApiError(
                    f"Video extraction job {job_id} failed: "
                    f"{job.error or 'no error message provided'}",
                    response=job.model_dump(mode="json"),
                )
            if time.monotonic() >= deadline:
                raise PollTimeoutError(
                    f"Video extraction job {job_id} did not complete within "
                    f"{timeout:.0f}s (status: {job.status}). Fetch later via "
                    f"client.video.get_extraction(...)."
                )
            sleep_fn(poll_interval)


def _chunked_iter(fh: Any, chunk_size: int = DEFAULT_CHUNK_SIZE) -> Any:
    """Yield bytes from a file in fixed-size chunks (for httpx PUT body)."""
    while True:
        chunk = fh.read(chunk_size)
        if not chunk:
            break
        yield chunk
