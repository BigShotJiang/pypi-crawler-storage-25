"""Image Pydantic model — represents a single image inside a dataset.

Returned by ``client.datasets.get(name, include_images=True)``,
``client.images.get(image_id)``, and ``client.images.iter(...)``. Response-side
schema (``extra="ignore"``) so backend column additions don't break callers.
"""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import AliasChoices, BaseModel, ConfigDict, Field

ImageStatus = Literal["new", "annotate", "review", "complete"]
"""Annotation lifecycle stages stored in ``project_images.status``.

Pinned by the database CHECK constraint — backend rejects any other value.
Stage transitions are caller-controlled (the editor's "Stage" selector,
or an explicit SDK status-set call). The annotations save endpoint never
mutates this field.
"""


class Image(BaseModel):
    """An image within a Pictograph dataset."""

    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    id: str
    filename: str
    status: ImageStatus = Field(
        default="new",
        description="Annotation lifecycle stage. See :data:`ImageStatus`.",
    )
    annotation_count: int = Field(default=0)
    file_size: int = Field(default=0, description="Bytes in GCS.")
    # Backend returns ``image_width``/``image_height`` from /metadata and
    # ``width``/``height`` from list endpoints — accept both.
    width: int | None = Field(
        default=None,
        description="Pixel width (None if unknown).",
        validation_alias=AliasChoices("width", "image_width"),
    )
    height: int | None = Field(
        default=None,
        description="Pixel height (None if unknown).",
        validation_alias=AliasChoices("height", "image_height"),
    )
    mime_type: str | None = Field(default=None, description="Stored MIME type.")
    dataset_id: str | None = Field(
        default=None,
        description="Parent dataset UUID. Populated on /metadata responses.",
    )
    virtual_folder_path: str | None = Field(
        default=None,
        description="Virtual folder path within the dataset (``/`` for root).",
    )
    is_archived: bool = Field(
        default=False,
        description="True when soft-deleted (archived). Use `permanent=True` to hard delete.",
    )
    image_url: str = Field(
        description=(
            "Authenticated CDN URL for fetching the full image. Use "
            "client.images.download() to stream the bytes to disk; do not GET "
            "this URL directly without an X-API-Key header."
        ),
    )
    thumbnail_url: str | None = Field(
        default=None,
        description="CDN URL for a sized thumbnail (typically 200px).",
    )
    annotation_url: str | None = Field(
        default=None,
        description=(
            "API endpoint that returns the annotation JSON file for this image. "
            "Absent when the image has zero annotations."
        ),
    )
    created_at: datetime
