"""Credit models — balance, ledger entries, cost estimates.

Returned by the :class:`pictograph.resources.credits.Credits` resource.
Response-side schema (``extra="ignore"``) so backend column additions
don't break callers.

Credit amounts are signed integers: **negative** for debits (operations
that consume credits) and **positive** for credits/refunds (top-ups,
training-overcharge refunds).
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class CreditLedgerEntry(BaseModel):
    """A single row from the ``credit_ledger`` table.

    ``amount`` sign carries the direction:

    - ``amount < 0`` — debit (operation consumed credits)
    - ``amount > 0`` — credit or refund (top-up, training overcharge refund)

    ``balance_after`` is the org's remaining balance immediately after this
    entry posted — useful for time-travel charts without recomputing from
    the ledger head.
    """

    model_config = ConfigDict(extra="ignore")

    id: str
    operation: str = Field(
        description=(
            "Operation slug (e.g., 'training_a10g', "
            "'image_generate_imagen_fast')."
        ),
    )
    amount: int
    balance_after: int | None = None
    description: str | None = None
    metadata: dict[str, Any] | None = None
    created_at: datetime


class CreditBalance(BaseModel):
    """Current credit state for an organization."""

    model_config = ConfigDict(extra="ignore")

    credits_remaining: int = Field(default=0)
    credits_monthly_allowance: int = Field(
        default=0,
        description="Credits the org's plan tier grants each billing period.",
    )
    credits_reset_at: datetime | None = Field(
        default=None,
        description="When the monthly allowance resets next.",
    )
    recent_history: list[CreditLedgerEntry] = Field(
        default_factory=list,
        description="Last 20 ledger entries, newest first. Convenience for agents.",
    )


class CreditEstimate(BaseModel):
    """Estimated cost of a planned operation, plus an affordability check."""

    model_config = ConfigDict(extra="ignore")

    operation: str
    credits_per_unit: int
    unit: str = Field(description="Unit of measure: 'minute', 'image', 'run', etc.")
    quantity: int
    total_credits: int = Field(
        description=(
            "Total cost (``credits_per_unit * quantity``, clamped to "
            "``minimum`` if set)."
        ),
    )
    minimum: int = Field(
        default=0,
        description="Floor on total_credits (e.g., SAM3 has a 3-credit session minimum).",
    )
    sufficient: bool = Field(
        description=(
            "True if the org has enough credits for ``total_credits``. "
            "Agents should branch on this before invoking the operation."
        ),
    )
    credits_remaining: int = Field(
        description="Org's current balance at the moment the estimate was computed.",
    )
