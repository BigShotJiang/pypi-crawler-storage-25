"""Search Pydantic models — typed results from similarity + tag queries.

Backend strips ``gcs_image_path`` (internal storage detail) before this
SDK ever sees the row, so neither :class:`SimilarImage` nor :class:`TaggedImage`
exposes it. Use :class:`pictograph.resources.images.Images` to download
actual bytes.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from pictograph.models.image import ImageStatus


class SimilarImage(BaseModel):
    """One result from :meth:`pictograph.resources.search.Search.by_similarity`.

    ``similarity`` is cosine similarity in ``[0, 1]`` — 1.0 means identical
    embeddings (the query image is excluded from results).
    """

    model_config = ConfigDict(extra="ignore")

    id: str
    filename: str
    virtual_folder_path: str = "/"
    status: ImageStatus
    annotation_count: int = Field(ge=0)
    image_auto_tags: dict[str, Any] = Field(default_factory=dict)
    similarity: float = Field(ge=0.0, le=1.0)


class TaggedImage(BaseModel):
    """One result from :meth:`pictograph.resources.search.Search.by_tag`.

    Includes the source ``project_id`` since tag search can span multiple
    datasets when ``dataset_name`` is omitted.
    """

    model_config = ConfigDict(extra="ignore")

    id: str
    project_id: str
    filename: str
    virtual_folder_path: str = "/"
    status: ImageStatus
    annotation_count: int = Field(ge=0)
    image_auto_tags: dict[str, Any] = Field(default_factory=dict)
