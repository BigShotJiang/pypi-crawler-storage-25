"""Pictograph annotation models — the canonical wire format.

Every annotation in the platform is one of four types:

============   ===================================================  =================================
``type``       Geometry                                             Discriminator field
============   ===================================================  =================================
``bbox``       :class:`BoundingBox`                                 ``bounding_box``
``polygon``    :class:`PolygonGeometry` (multi-ring)                ``polygon``
``polyline``   :class:`PolylineGeometry` (open path)                ``polyline``
``keypoint``   :class:`Point`                                        ``keypoint``
============   ===================================================  =================================

The :data:`Annotation` type alias is a discriminated union over these classes.
Pydantic dispatches on the ``type`` literal::

    >>> from pydantic import TypeAdapter
    >>> ta = TypeAdapter(Annotation)
    >>> ann = ta.validate_python({
    ...     "id": "ann-1",
    ...     "name": "person",
    ...     "type": "bbox",
    ...     "bounding_box": {"x": 100, "y": 200, "w": 50, "h": 80},
    ... })
    >>> isinstance(ann, BBoxAnnotation)
    True

Polygon and polyline annotations may omit ``bounding_box`` on save — the
backend computes the enclosing rectangle server-side.

The wire format uses snake_case field names (``bounding_box``, ``created_by``)
and matches what the annotation editor emits. There is no shorthand: any
``model_dump(mode="json", exclude_none=True)`` of these models is bit-for-bit
what gets stored in ``project_images.annotations_json``.
"""

from __future__ import annotations

import uuid
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .common import BoundingBox, NonBlankStr, Point

AnnotationType = Literal["bbox", "polygon", "polyline", "keypoint"]


# ───────────── geometry containers ─────────────


class PolygonGeometry(BaseModel):
    """Polygon geometry with multi-ring (hole) support.

    ``paths`` is a list of rings. The first ring is the outer boundary; each
    subsequent ring carves out a hole, rendered via the even-odd fill rule.
    A polygon with disconnected outer regions is represented by emitting two
    separate annotations, not by stuffing both into ``paths``.

    Each ring requires at least three points (a triangle is the minimum
    polygonal area).
    """

    model_config = ConfigDict(extra="forbid")

    paths: list[list[Point]] = Field(
        min_length=1,
        description=(
            "List of rings. First is the outer boundary; subsequent rings are "
            "holes (even-odd fill rule). Each ring needs >= 3 points."
        ),
    )

    @field_validator("paths")
    @classmethod
    def _check_ring_sizes(cls, value: list[list[Point]]) -> list[list[Point]]:
        for index, ring in enumerate(value):
            if len(ring) < 3:
                raise ValueError(
                    f"paths[{index}] has {len(ring)} point(s); "
                    f"a polygon ring requires at least 3 points."
                )
        return value


class PolylineGeometry(BaseModel):
    """Open path: an ordered list of points connected by line segments.

    A polyline has at least two points (a single segment is the minimum). It
    does not close — the last point is not implicitly connected to the first.
    """

    model_config = ConfigDict(extra="forbid")

    path: list[Point] = Field(
        min_length=2,
        description="Ordered list of points (>= 2). Does not close.",
    )


# ───────────── base annotation ─────────────


class _AnnotationBase(BaseModel):
    """Fields shared by every annotation type.

    Field declaration order matches the canonical wire format:
    ``id, name, type, <geometry>, confidence, created_by, attributes``.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    id: NonBlankStr = Field(
        default_factory=lambda: str(uuid.uuid4()),
        description=(
            "Unique annotation ID within the image. Auto-generated as a UUID4 "
            "when omitted — agents can construct annotations without tracking IDs."
        ),
    )
    name: NonBlankStr = Field(
        description=(
            "Class label. Must match a class defined on the project's "
            "project_config.classes — case-sensitive."
        ),
    )


# ───────────── concrete annotations ─────────────


class BBoxAnnotation(_AnnotationBase):
    """Axis-aligned bounding-box annotation."""

    type: Literal["bbox"] = "bbox"
    bounding_box: BoundingBox
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    created_by: str | None = None
    attributes: list[object] = Field(default_factory=list)


class PolygonAnnotation(_AnnotationBase):
    """Polygon annotation, optionally with holes (multi-path).

    ``bounding_box`` may be omitted on save — the backend computes the
    enclosing rectangle from ``polygon.paths`` server-side. When emitted by
    the backend, ``bounding_box`` is always populated.
    """

    type: Literal["polygon"] = "polygon"
    bounding_box: BoundingBox | None = Field(
        default=None,
        description=(
            "Enclosing rectangle. Optional on save — the backend computes it "
            "from polygon.paths when omitted."
        ),
    )
    polygon: PolygonGeometry
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    created_by: str | None = None
    attributes: list[object] = Field(default_factory=list)


class PolylineAnnotation(_AnnotationBase):
    """Open polyline annotation (e.g., road centerlines, lanes)."""

    type: Literal["polyline"] = "polyline"
    bounding_box: BoundingBox | None = Field(
        default=None,
        description=(
            "Enclosing rectangle. Optional on save — the backend computes it "
            "from polyline.path when omitted."
        ),
    )
    polyline: PolylineGeometry
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    created_by: str | None = None
    attributes: list[object] = Field(default_factory=list)


class KeypointAnnotation(_AnnotationBase):
    """Single-point annotation (e.g., facial landmarks, joint locations)."""

    type: Literal["keypoint"] = "keypoint"
    keypoint: Point
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    created_by: str | None = None
    attributes: list[object] = Field(default_factory=list)


# ───────────── discriminated union ─────────────


Annotation = Annotated[
    BBoxAnnotation | PolygonAnnotation | PolylineAnnotation | KeypointAnnotation,
    Field(discriminator="type"),
]
"""Discriminated union over all annotation types.

Use with ``pydantic.TypeAdapter`` for parsing arbitrary annotation dicts::

    from pydantic import TypeAdapter
    ann_adapter = TypeAdapter(Annotation)
    ann = ann_adapter.validate_python(some_dict)  # returns the right subclass

Or as a list type::

    annotations: list[Annotation] = ...
"""
