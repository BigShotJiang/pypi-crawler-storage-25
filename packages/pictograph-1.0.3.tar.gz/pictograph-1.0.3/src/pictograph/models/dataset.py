"""Dataset (project) and dataset-class Pydantic models.

These describe what the backend *returns* on dataset endpoints. Response models
use ``extra="ignore"`` so the SDK is forward-compatible with backend additions
— a new column on the dataset table doesn't break older SDK versions, it just
isn't surfaced as a typed attribute. Request payloads (when the SDK ships
project CRUD in Phase 3) will use ``extra="forbid"`` for the opposite reason:
typos in caller payloads should fail loudly.

The ``Dataset`` model intentionally omits ``gcs_path`` even though the
backend currently leaks it on the ``by-name`` endpoint — that field is an
internal storage detail and should not be part of the public SDK surface.
``extra="ignore"`` discards it silently.
"""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from pictograph.models.image import ImageStatus


class DatasetClass(BaseModel):
    """A class definition declared on a dataset's project_config.

    The backend stores arbitrary keys here (``type``, ``color``, plus
    user-defined attributes); ``extra="ignore"`` lets future backend
    additions land without breaking SDK callers.
    """

    model_config = ConfigDict(extra="ignore")

    name: str
    type: str | None = Field(
        default=None,
        description="Annotation type the class is intended for (bbox/polygon/...).",
    )
    color: str | None = Field(default=None, description="Hex color for UI rendering.")


class DatasetImage(BaseModel):
    """An image summary inside a :class:`Dataset` (when ``include_images=True``).

    The full :class:`pictograph.models.image.Image` is fetched separately
    via :meth:`pictograph.resources.images.Images.get`. This summary is
    enough to drive batch operations (filename + id + annotation_count).
    """

    model_config = ConfigDict(extra="ignore")

    id: str
    filename: str
    status: ImageStatus
    annotation_count: int = Field(default=0, ge=0)
    file_size: int = Field(default=0, ge=0)
    width: int | None = None
    height: int | None = None
    mime_type: str | None = None
    dataset_id: str | None = None
    virtual_folder_path: str | None = None
    is_archived: bool = False
    image_url: str | None = None
    thumbnail_url: str | None = None
    annotation_url: str | None = None
    created_at: datetime


class Dataset(BaseModel):
    """A Pictograph dataset (project) — group of images with shared classes."""

    model_config = ConfigDict(extra="ignore")

    id: str
    name: str
    description: str | None = None
    image_count: int = Field(default=0, description="Total non-archived images.")
    completed_image_count: int = Field(
        default=0,
        description="Images with status='complete' (annotation finalised).",
    )
    total_size: int = Field(
        default=0,
        description="Sum of file sizes in bytes across all non-archived images.",
    )
    archived_images: int = Field(
        default=0,
        description="Soft-deleted images (recoverable from the Archive tab).",
    )
    classes: list[DatasetClass] = Field(
        default_factory=list,
        description=(
            "Class definitions from project_config. Empty when the dataset has "
            "not been configured yet."
        ),
    )
    images: list[DatasetImage] | None = Field(
        default=None,
        description=(
            "Populated only when fetched with ``include_images=True``. "
            "``None`` when not requested. Use :meth:`pictograph.resources.datasets.Datasets.get` "
            "with ``include_images=True`` to populate."
        ),
    )
    created_at: datetime
    organization_id: str | None = Field(
        default=None,
        description="Set on the get-by-name response; absent on list responses.",
    )
