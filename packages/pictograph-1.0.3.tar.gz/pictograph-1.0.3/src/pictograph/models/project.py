"""Project Pydantic models — CRUD-side mirror of :mod:`pictograph.models.dataset`.

``Dataset`` and ``Project`` describe the same backend row (``projects``
table, joined with ``project_config``). The split is naming-driven:

- :class:`Dataset` is the "data scientist's mental model" — what you read,
  download, and train against. Surfaces image counts and class lists.
- :class:`Project` is the "workspace admin's mental model" — what you
  create, configure, and delete. Same data plus the canonical-class type.

The two models can be used interchangeably for reads. The CRUD surface in
:mod:`pictograph.resources.projects` returns :class:`Project`; download
and listing in :mod:`pictograph.resources.datasets` returns :class:`Dataset`.
"""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

ProjectAnnotationType = Literal["bbox", "box", "polygon", "polyline", "keypoint"]
"""Annotation types supported on a project. ``bbox``/``box`` are aliases — the
backend accepts both for legacy frontend compatibility."""


class ProjectClass(BaseModel):
    """A class definition stored in ``project_config.classes``.

    On reads, ``type`` and ``color`` may be missing on legacy projects —
    both default to ``None``. On writes, supply ``name`` and ``type`` at
    minimum; the backend assigns default colors if omitted.
    """

    model_config = ConfigDict(extra="ignore")

    name: str = Field(min_length=1, max_length=120)
    type: str | None = Field(
        default=None,
        description="Annotation type (bbox/polygon/polyline/keypoint).",
    )
    color: str | None = Field(
        default=None,
        description="Hex color for UI rendering (e.g. '#e6194b').",
    )


class Project(BaseModel):
    """A Pictograph project — group of images with shared annotation config.

    Combines ``projects`` row + ``project_config`` row into a single
    surface. Counters (``image_count``, ``completed_image_count``,
    ``total_size``, ``archived_images``) are denormalized at read-time
    from the ``projects`` table itself.
    """

    model_config = ConfigDict(extra="ignore")

    id: str
    organization_id: str
    name: str
    description: str | None = None
    annotation_types: list[str] = Field(default_factory=lambda: ["bbox"])
    classes: list[ProjectClass] = Field(default_factory=list)
    image_count: int = Field(default=0, ge=0)
    completed_image_count: int = Field(default=0, ge=0)
    total_size: int = Field(default=0, ge=0)
    archived_images: int = Field(default=0, ge=0)
    created_at: datetime
    updated_at: datetime | None = None
