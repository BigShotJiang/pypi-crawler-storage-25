"""Model Pydantic model — represents a trained CV model.

Returned by every method on :class:`pictograph.resources.models.Models`.
Created server-side by the training pipeline's completion callback —
SDK callers don't insert ``Model`` rows directly. Instead they
:meth:`Training.create` a training run and the resulting model is exposed
via this resource.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

ModelType = Literal[
    "object_detection",
    "semantic_segmentation",
    "instance_segmentation",
    "classification",
]
"""Output category. Pinned by the database CHECK constraint."""

ModelStatus = Literal["training", "ready", "failed", "archived"]
"""Lifecycle. Only ``ready`` models are downloadable."""

ModelVisibility = Literal["private", "public"]
"""``private`` models are org-scoped; ``public`` are visible across orgs."""


class Model(BaseModel):
    """A trained computer vision model."""

    model_config = ConfigDict(extra="ignore")

    id: str
    organization_id: str
    name: str
    description: str | None = None
    model_type: ModelType
    architecture: str | None = Field(
        default=None,
        description="Backbone family (e.g., 'yolox-s', 'rfdetr-base').",
    )
    visibility: ModelVisibility
    status: ModelStatus
    metrics: dict[str, Any] | None = Field(
        default=None,
        description=(
            "Training metrics (mAP, precision, recall, etc.). Populated when "
            "``status == 'ready'``."
        ),
    )
    class_mapping: dict[str, Any] | None = Field(
        default=None,
        description="Maps class index → class name for inference.",
    )
    version: str = Field(default="1.0.0")
    parent_model_id: str | None = Field(
        default=None,
        description="When set, this model was fine-tuned from another.",
    )
    created_at: datetime
    updated_at: datetime
