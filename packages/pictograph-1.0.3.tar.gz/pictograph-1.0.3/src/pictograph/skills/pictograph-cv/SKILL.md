---
name: pictograph-cv
description: Use when the user wants to annotate images, train computer-vision models, or run end-to-end CV pipelines on Pictograph (https://pictograph.io). Covers dataset upload, SAM3 auto-annotation, model training (YOLOX/Detectron2/SM-PyTorch/RF-DETR), exports (COCO/YOLO/Pascal/CVAT/etc.), and connector imports from V7/Roboflow.
allowed-tools: Bash, Read, Edit, Write
---

# Pictograph CV Skill

Use this skill when the user wants to do anything CV-annotation-related on
**Pictograph** — uploading images, segmenting / boxing / classifying them
with **SAM3**, training a model, or exporting in a standard ML format.

The skill is **wrapper-first**: small Python scripts in `scripts/` shell
out to `pictograph.workflows.*` so an agent can chain operations with one
bash call. Pydantic-typed Python in your conversation is fine too — both
paths use the same SDK underneath.

## When to use this skill

Use it when the user mentions:

- a folder of images to upload
- "auto-annotate", "auto-label", "segment", "draw boxes"
- "train a model", "fine-tune", "ONNX", "YOLO", "Detectron"
- "export", "COCO format", "Pascal VOC", "CVAT"
- importing from V7 (Darwin) or Roboflow

Do **not** use for: bounding-box maths, classical CV without Pictograph,
agent infrastructure questions.

## Setup (one-time)

```bash
pip install pictograph
export PICTOGRAPH_API_KEY=pk_live_…   # get from app.pictograph.io → Settings → API Keys
```

The user can also pass `api_key=...` to `Client(...)` explicitly.

## Quickstart recipes

### 1. Annotate a folder of road signs end-to-end

```bash
python scripts/full_pipeline.py \
  --folder ./road_signs \
  --dataset road-signs \
  --classes "stop_sign:bbox,yield:bbox,speed_limit:bbox" \
  --pipeline yolox
```

What this does (one command, ~5–15 minutes depending on dataset size):
1. Uploads every image under `./road_signs` to a new `road-signs` dataset.
2. Runs SAM3 batch auto-annotation for the three classes.
3. Trains a YOLOX detection model on an A10G GPU.
4. Returns the trained model's UUID — download with `pictograph models download <id>`.

Each phase short-circuits on failure; the final report tells you which.

### 2. Just upload + auto-annotate (skip training)

```bash
python scripts/upload_and_annotate.py \
  --folder ./photos \
  --dataset my-photos \
  --classes "person:polygon,car:bbox"
```

Maps to:

```python
from pictograph import Client
from pictograph.workflows import (
    upload_dataset_from_folder, auto_annotate_dataset,
)

client = Client()
upload_report = upload_dataset_from_folder(client, "my-photos", "./photos")
annotate_report = auto_annotate_dataset(
    client, "my-photos",
    classes=[("person", "polygon"), ("car", "bbox")],
)
```

### 3. Fine-tune from an existing dataset

```bash
python scripts/train.py \
  --dataset my-photos \
  --pipeline detectron2 \
  --gpu a100 \
  --epochs 50
```

`train_pipeline` auto-creates a timestamped export → kicks off training →
returns `(TrainingRun, Model)` when `wait=True` (default).

### 4. Import from V7 / Roboflow, then auto-annotate

```bash
# Step 1: validate API key, list datasets.
python scripts/import_connector.py --provider v7 --api-key $V7_KEY --list

# Step 2: import the chosen datasets.
python scripts/import_connector.py --provider v7 --api-key $V7_KEY \
  --dataset-ids ds_abc,ds_xyz

# Step 3: auto-annotate them with new classes (existing V7 annotations are kept).
python scripts/upload_and_annotate.py --dataset ds_abc \
  --classes "damage:polygon" --no-upload
```

### 5. Export an annotated dataset for a downstream model

```python
from pictograph import Client
client = Client()

export = client.exports.create(
    "road-signs",
    "for-yolov8",
    format="yolo",          # or "coco", "pascal_voc", "cvat", "labelme", "csv"
    include_images=True,
    status_filter="complete",  # only finalised images
)

client.exports.download(
    "road-signs", "for-yolov8", output_path="./road-signs.zip"
)
```

## Annotation format reminders

The class-label field is **`name`**, not `class`:

```json
{"id": "ann-1", "name": "person", "type": "bbox",
 "bounding_box": {"x": 0, "y": 0, "w": 100, "h": 200}}
```

Polygons use **multi-ring `paths`** (outer + holes via even-odd fill rule):

```json
{"id": "ann-2", "name": "lake", "type": "polygon",
 "polygon": {"paths": [[{"x": 0, "y": 0}, {"x": 10, "y": 0}, {"x": 10, "y": 10}]]}}
```

Full schema reference: `references/pictograph-json-schema.md`.

## Credit budget gating

Paid operations (training, batch SAM3, image generation) consume credits.
**Always estimate before acting** when budget is tight:

```python
estimate = client.credits.estimate("training_a10g", quantity=30)
if not estimate.sufficient:
    raise RuntimeError(
        f"Need {estimate.total_credits} cr, have {estimate.credits_remaining}"
    )
```

`full_pipeline` already does this — it skips paid phases on a zero balance
and surfaces `report.credit_skip_reason`.

## When things fail

- **NotFoundError** — dataset name doesn't exist (case-sensitive).
- **ConflictError** — image with same filename in same folder. Default behavior
  is *skip*; pass `skip_existing=False` to fail loudly.
- **PaymentRequiredError** — out of credits. The error carries `upgrade_url`
  so you can prompt the user.
- **ValidationError** — payload shape wrong (often `class` vs `name`, or flat
  polygon array instead of multi-ring `paths`).
- **PollTimeoutError** — long-running job (training, large batch SAM3) didn't
  finish in time. Re-poll with `client.training.get(run_id)` later.

## Reference index

| Topic | File |
|---|---|
| Canonical Pictograph JSON schema | `references/pictograph-json-schema.md` |
| Annotation type cheatsheet | `references/annotation-types.md` |
| SAM3 auto-annotation (point/box/text + batch) | `references/auto-annotation.md` |
| Training pipelines + GPU tiers | `references/training.md` |
| Credit costs + estimation | `references/credits.md` |

## Scripts (drop-in CLI wrappers)

| Script | Purpose |
|---|---|
| `scripts/full_pipeline.py` | Upload → annotate → train, end-to-end. |
| `scripts/upload_and_annotate.py` | Upload a folder, optionally auto-annotate. |
| `scripts/train.py` | Train a model from an existing annotated dataset. |
| `scripts/import_connector.py` | List + import remote datasets from V7/Roboflow. |
| `scripts/export.py` | Create + download a dataset export in any format. |
