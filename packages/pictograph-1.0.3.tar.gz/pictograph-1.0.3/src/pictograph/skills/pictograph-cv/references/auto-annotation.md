# SAM3 auto-annotation

Pictograph runs Meta's SAM3 (Segment Anything Model 3) on T4 GPUs for
auto-annotation. Three single-image prompt modes plus an async batch
endpoint for many images at once.

## Single-image prompts (synchronous)

### Point prompt — "click here, segment that"

Best when the user knows where the object is and clicks/taps.

```python
result = client.auto_annotate.point(
    dataset_name="my-photos",
    image_filename="img-1.jpg",
    x=320, y=240,
    name="car",
    positive_points=[(310, 250)],   # optional extra positives
    negative_points=[(100, 100)],   # exclude regions
    score_threshold=0.75,
)
# result.annotations[0] is the polygon — call client.annotations.save() to persist.
```

Returns `PromptResult.status`:

- `success` — `annotations[0]` is a polygon.
- `no_detection` — SAM3 found nothing matching the point.
- `below_threshold` — all candidates below `score_threshold`.

### Box prompt — "segment everything in this box"

Best when the user has drawn a rough bounding box and wants a precise
mask.

```python
result = client.auto_annotate.box(
    dataset_name="my-photos",
    image_filename="img-1.jpg",
    box={"x": 100, "y": 200, "w": 200, "h": 150},
    name="car",
    return_polygon=True,        # also include polygon (not just bbox)
    confidence_threshold=0.5,
    negative_boxes=[{"x": 50, "y": 50, "w": 30, "h": 30}],  # exclude
)
```

`return_polygon=False` returns only the refined bbox — useful for
detection workflows where polygons are noise.

### Text prompt — "find all <thing>"

Open-vocabulary. Best for large datasets where the user can't click
each object.

```python
result = client.auto_annotate.text(
    dataset_name="my-photos",
    image_filename="img-1.jpg",
    text_prompt="red cars",
    output_type="polygon",       # or "bbox"
    confidence_threshold=0.3,    # text mode: lower default
    max_detections=50,           # cap result count
)
# result.annotations is a list of polygons/bboxes for every red car SAM3 found.
```

## Batch endpoint (asynchronous)

Use for **>10 images**. One job kicks off, you poll until terminal.

```python
job = client.auto_annotate.batch(
    dataset_name="my-photos",
    image_filenames=["img-1.jpg", "img-2.jpg", …],
    classes=[
        BatchClass(name="car", output_type="polygon"),
        BatchClass(name="person", output_type="bbox"),
    ],
    confidence_threshold=0.5,
    wait=True,
    poll_interval=5.0,
    timeout=1800.0,      # 30 min default
)
# job.status == "completed"
# job.processed_images, job.total_annotations_added, job.failed_images
```

`wait=False` returns immediately with a `BatchJob` and you call
`client.auto_annotate.get_batch(job.job_id)` later. The
`auto_annotate_dataset` workflow wraps this with image-list pagination
+ skip-existing logic.

## Choosing a mode

| Scenario | Mode |
|---|---|
| Agent / user clicks one spot | `point` |
| Agent / user drags a rough box | `box` |
| Many images, known class names | `text` per image OR `batch` |
| > 10 images | `batch` (async) |
| Single image, multiple unrelated objects | `text` (returns all matches) |

## Cost

SAM3 is paid:

- **Minimum 3 credits** per session (image embedding generation).
- ~1 credit per additional prompt on the same image (sub-second; embedding cached).
- Batch: charged per image processed.

`client.credits.estimate("sam3_auto_annotation", quantity=N)` for a
minute-based estimate, but the pre-charge is fixed per call — read the
`PaymentRequiredError.required` field on rejection for the exact ask.

## What SAM3 returns

- Polygons via scikit-image contour detection on the SAM3 mask.
- Holes are preserved as additional rings in `polygon.paths`.
- Bboxes are the enclosing rectangle of the mask.
- Tags (output_type=`tag`) are class labels — written to
  `image_auto_tags` not `annotations_json`.

## What SAM3 does not return

- Polylines or keypoints (no analog in segmentation).
- Multi-class panoptic segmentation in one call (run one class at a time
  in batch mode, or one text prompt per class).
