# Annotation types — when to use which

| Want to mark… | Use type | Geometry | Best paired SAM3 prompt |
|---|---|---|---|
| Whole object, axis-aligned | `bbox` | `{x, y, w, h}` | text or box |
| Object with precise outline | `polygon` | multi-ring `paths` | point or text |
| Object with hole(s) | `polygon` | first ring outer, rest holes | point |
| Linear feature (lane, wire, road) | `polyline` | open `path` | manual; SAM3 doesn't return polylines |
| Single landmark (joint, eye) | `keypoint` | `{x, y}` | manual; SAM3 doesn't return keypoints |

## Bounding boxes

- **Use when** the user wants to detect — bbox detectors (YOLOX, RF-DETR,
  YOLOv8) train on bboxes only.
- Coordinates: top-left `{x, y}` + width/height in **absolute pixels**.
- The SDK's `BBoxAnnotation` rejects negative values via Pydantic.

## Polygons

- **Use when** the user wants segmentation, or precise pixel coverage —
  Detectron2 instance segmentation, RF-DETR segmentation.
- `paths: list[list[Point]]`. The first ring is the outer boundary; each
  subsequent ring carves out a hole (even-odd fill rule).
- A polygon that crosses an image boundary should be **clipped** to the
  image rectangle before saving.
- Disconnected outer regions → emit as **two separate annotations**, not
  two outer rings on one annotation.
- Each ring needs **≥ 3 points** (Pydantic enforces).

## Polylines

- **Use when** marking an open linear feature — road centerlines, power
  lines, lanes. Two endpoints are not implicitly connected.
- Each polyline needs **≥ 2 points**.
- Pictograph training pipelines do not currently consume polylines —
  use bboxes/polygons for trainable annotations.

## Keypoints

- **Use when** marking a single position — facial landmarks, joint
  positions, license-plate corners.
- Keypoint datasets pair multiple keypoints under one *image* (not one
  annotation). Each landmark is its own annotation with a distinct
  `name`.

## Auto-annotate output_type

When kicking off SAM3 batch annotation, each class declares an `output_type`:

| `output_type` | Annotation type emitted | Notes |
|---|---|---|
| `polygon` (default) | `polygon` | SAM3 segmentation mask → polygon ring(s). |
| `bbox` | `bbox` | SAM3 mask reduced to enclosing rectangle. |
| `tag` | (no annotation) | Image-level tag (used by classification training). |

`tag` doesn't write to `annotations_json`; it writes to
`image_auto_tags`. Use it only for classification pipelines.
