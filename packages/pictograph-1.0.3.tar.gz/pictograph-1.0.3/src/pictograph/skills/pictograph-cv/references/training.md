# Training pipelines + GPU tiers

Pictograph runs training on **Modal** serverless GPUs and stores ONNX
weights in GCS. Six pipelines map to model architectures:

| `pipeline_type` | Model family | Output | Best for |
|---|---|---|---|
| `yolox` | YOLOX-S/M/L | Object detection (bboxes) | Speed, edge deployment |
| `detectron2` | Detectron2 / Mask R-CNN | Instance segmentation | Polygons + per-instance masks |
| `sm_pytorch` | Segmentation Models PyTorch | Semantic segmentation | Pixel-wise class maps |
| `classification` | timm backbones | Image classification | Tag-style labels (no boxes) |
| `rfdetr_detection` | RT-DETR | Object detection | Higher mAP than YOLOX, slower |
| `rfdetr_segmentation` | RT-DETR + segmentation head | Instance segmentation | Higher mAP than Detectron2 |

Pick by what the user wants to *infer*, not by name recognition.

## GPU tiers

| `gpu_type` | Modal hardware | Approx cost | Notes |
|---|---|---|---|
| `a10g` (default) | A10G | ~$0.30/hr | Good for YOLOX, classification, RF-DETR |
| `a100` | A100 (40GB) | ~$2/hr | Detectron2, large RF-DETR, big batches |
| `h100` | H100 | ~$4/hr | Last resort — only when A100 OOMs |

`client.credits.estimate("training_a10g", quantity=N)` for
exact credit cost (slugs: `training_a10g`, `training_a100`, `training_h100`).

## Minimum dataset size

The training service requires **≥ 5 images** with annotations to split
into train/val/test. Below that, the Modal job fails with
`num_samples=0`. Pre-flight via:

```python
ds = client.datasets.get("my-dataset")
assert ds.completed_image_count >= 5
```

`status_filter="complete"` on the export means only annotation-finalised
images train. Other statuses (`new`, `in_progress`) are excluded.

## End-to-end via the workflow

```python
from pictograph.workflows import train_pipeline

run, model = train_pipeline(
    client,
    dataset_name="road-signs",
    pipeline="yolox",
    gpu="a10g",
    config={"epochs": 50, "batch_size": 16},
    wait=True,
    timeout=7200.0,        # 2h default
)
# run.status == "completed"
# model.id is the trained model UUID
client.models.download(model.id, output_path="./yolox.onnx")
```

`train_pipeline` auto-creates the export with a timestamped name —
override with `export_name=...` if you already have one.

## Polling without waiting

```python
run, _ = train_pipeline(
    client, dataset_name="road-signs", pipeline="yolox", wait=False,
)
# Later (or in another process):
run = client.training.get(run.id)
print(run.status, run.progress, run.current_epoch, "/", run.total_epochs)
if run.status == "completed":
    model = client.models.get(run.model_id)
```

## Cancelling

```python
client.training.cancel(run.id)   # stops Modal worker, refunds remaining minutes
```

## Configuration knobs

The `config` dict is pipeline-specific. Common keys (most pipelines):

| Key | Default | Notes |
|---|---|---|
| `epochs` | pipeline-default (usually 50) | Number of training epochs |
| `batch_size` | auto-tuned per GPU | Override for memory issues |
| `learning_rate` | pipeline-default | Override for fine-tuning |
| `image_size` | 640 (detection), 256 (classification) | Resize target |

Unknown keys are ignored by the pipeline. Read the pipeline source in
`pictograph_training_service.py` for the full set.

## Class filtering at export time

Use `class_filter` to train on a subset of classes without rebuilding
the dataset:

```python
run, model = train_pipeline(
    client, "road-signs",
    pipeline="yolox",
    class_filter=["stop_sign", "yield"],   # ignore others
)
```

The export contains only those classes; the trained model has only
those output indices.

## Debug recipe

If training fails:
1. `client.training.get(run.id)` — inspect `error_message`.
2. Check Modal logs (only the Pictograph admin can): `modal app logs pictograph-training-service`.
3. Common causes:
   - `num_samples=0` — fewer than 5 annotated images, or all annotations
     have classes not in `project_config.classes`.
   - `CUDA out of memory` — switch to a larger GPU tier.
   - `Pipeline type mismatch` — passed `polygon` annotations to a
     bbox-only pipeline (yolox).
