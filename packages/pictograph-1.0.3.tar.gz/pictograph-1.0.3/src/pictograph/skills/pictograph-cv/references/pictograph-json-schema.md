# Pictograph JSON Schema

Canonical wire format for every annotation in Pictograph. Snake-case
field names, no shorthand: bounding boxes are always `{x, y, w, h}`
objects, polygons are always multi-ring `paths`, polylines are always
ordered point lists, keypoints are single points.

The label field is **`name`** (not `class`). Do not improvise.

## Discriminator field

Every annotation has a `type` field that selects the geometry shape:

| `type` | Geometry container | Notes |
|---|---|---|
| `bbox` | `bounding_box: {x, y, w, h}` | Axis-aligned. |
| `polygon` | `polygon: {paths: [[{x, y}, …], …]}` | Multi-ring (holes via even-odd). |
| `polyline` | `polyline: {path: [{x, y}, …]}` | Open path; doesn't close. |
| `keypoint` | `keypoint: {x, y}` | Single point. |

## Required fields (all annotations)

| Field | Type | Notes |
|---|---|---|
| `id` | non-blank string | Unique within the image. UUIDs preferred. |
| `name` | non-blank string | Class label. Must match a class in `project_config.classes` (case-sensitive). |
| `type` | one of `bbox`/`polygon`/`polyline`/`keypoint` | Discriminator. |
| `<geometry>` | see table above | Required field name depends on `type`. |

## Optional fields (all annotations)

| Field | Default | Notes |
|---|---|---|
| `confidence` | `1.0` | `[0.0, 1.0]`. SAM3 sets this; manual annotations get 1.0. |
| `created_by` | `null` | UUID of the creator. Backend fills this for SDK uploads. |
| `attributes` | `[]` | User-defined metadata. Backend stores opaque. |
| `bounding_box` (polygon/polyline) | computed | Backend auto-computes the enclosing rectangle if omitted. |

## Examples

### Bounding box
```json
{"id": "ann-1", "name": "person", "type": "bbox",
 "bounding_box": {"x": 100, "y": 200, "w": 50, "h": 80}}
```

### Polygon (single ring)
```json
{"id": "ann-2", "name": "car", "type": "polygon",
 "polygon": {"paths": [[
   {"x": 10, "y": 20}, {"x": 110, "y": 20},
   {"x": 110, "y": 80}, {"x": 10, "y": 80}
 ]]}}
```

### Polygon with hole (multi-ring)
```json
{"id": "ann-3", "name": "donut", "type": "polygon",
 "polygon": {"paths": [
   [{"x": 0, "y": 0}, {"x": 100, "y": 0}, {"x": 100, "y": 100}, {"x": 0, "y": 100}],
   [{"x": 30, "y": 30}, {"x": 70, "y": 30}, {"x": 70, "y": 70}, {"x": 30, "y": 70}]
 ]}}
```

### Polyline
```json
{"id": "ann-4", "name": "lane_centerline", "type": "polyline",
 "polyline": {"path": [{"x": 0, "y": 100}, {"x": 50, "y": 100}, {"x": 100, "y": 100}]}}
```

### Keypoint
```json
{"id": "ann-5", "name": "left_eye", "type": "keypoint",
 "keypoint": {"x": 250, "y": 180}}
```

## Database storage shape

Stored in `project_images.annotations_json` as a **plain array** — no
wrapper object:

```json
[
  {"id": "ann-1", "name": "person", "type": "bbox", "bounding_box": {…}},
  {"id": "ann-2", "name": "car",    "type": "polygon", "polygon": {…}}
]
```

## Common mistakes

❌ `"class": "person"` — must be `"name"`.
❌ `"polygon": [[10, 20, 30, 40]]` — flat array. Must be `[{"x": …, "y": …}]`.
❌ `"bbox": [x, y, w, h]` — array. Must be `"bounding_box": {x, y, w, h}` object.
❌ Class label not in `project_config.classes` — backend rejects with
   `ValidationError`.
❌ Polygon ring with < 3 points — Pydantic rejects on save.

## Saving via the SDK

```python
from pictograph import Client
from pictograph.models.annotation import (
    BBoxAnnotation, BoundingBox,
)

client = Client()
client.annotations.save(
    image_id,
    [
        BBoxAnnotation(
            id="ann-1", name="person",
            bounding_box=BoundingBox(x=100, y=200, w=50, h=80),
        ),
    ],
)
```

The SDK Pydantic models are the source of truth — they generate the
JSON Schema this doc describes. If a backend rejects your payload, dump
the SDK model with `.model_dump(mode="json", exclude_none=True)` and
diff against the rejection message.
