# Credits — costs, estimation, gating

Pictograph uses a **credit ledger** (signed integers, per organization)
for paid operations. Free actions (uploads, exports, search) cost 0.

## Cost cheatsheet

| Operation | Slug (for `estimate`) | Approx cost |
|---|---|---|
| SAM3 single prompt (point/box/text) | `sam3_auto_annotation` | 3 cr session minimum |
| SAM3 batch | `sam3_auto_annotation` | ~3 cr per image processed |
| Training, A10G | `training_a10g` | 5 cr/min (5 cr minimum) |
| Training, A100 | `training_a100` | 9 cr/min (9 cr minimum) |
| Training, H100 | `training_h100` | 18 cr/min (18 cr minimum) |
| Image generation, Imagen Fast | `image_generate_imagen_fast` | 3 cr/call |
| Image generation, Imagen Standard | `image_generate_imagen_standard` | 5 cr/call |
| Image generation, Imagen Ultra | `image_generate_imagen_ultra` | 8 cr/call |
| Image generation, Gemini Flash | `image_generate_gemini_flash` | 5 cr/call |
| Image generation, Gemini Pro | `image_generate_gemini_pro` | 15 cr/call |
| Image edit, Gemini Flash | `image_edit_gemini_flash` | 5 cr/call |
| Image edit, Gemini Pro | `image_edit_gemini_pro` | 15 cr/call |
| Inference (deployed model, T4) | `inference_t4` | 2 cr/min (2 cr minimum) |

The full cost table lives server-side in `utils.tier_limits.CREDIT_COSTS`.

## Pre-flight estimation

```python
estimate = client.credits.estimate("training_a10g", quantity=30)
# CreditEstimate(operation="training_a10g", credits_per_unit=5, unit="per_minute",
#                quantity=30, total_credits=150, minimum=5,
#                sufficient=True, credits_remaining=1000)
if not estimate.sufficient:
    # Surface the upgrade flow to the user.
    raise RuntimeError(f"Need {estimate.total_credits}, have {estimate.credits_remaining}")
```

`sufficient=True` is **not** a guarantee — another caller may drain
credits between the estimate and the actual operation. The authoritative
answer is the operation's own `PaymentRequiredError`:

```python
from pictograph.exceptions import PaymentRequiredError

try:
    train_pipeline(client, ...)
except PaymentRequiredError as e:
    print(f"Need {e.required}, have {e.remaining}. Upgrade: {e.upgrade_url}")
```

## Gating in workflows

`full_pipeline` already gates on credit balance before kicking off paid
phases:

```python
report = full_pipeline(
    client,
    dataset_name="…",
    folder="…",
    classes=…,
    pipeline="yolox",
    min_credits=1,             # skip annotate + train if balance < 1
)
if report.credit_skip_reason:
    print(report.credit_skip_reason)
```

`min_credits=None` disables the check (useful when the user has
auto-recharge).

## Inspecting recent activity

```python
balance = client.credits.balance()
# balance.credits_remaining, balance.credits_monthly_allowance,
# balance.credits_reset_at, balance.recent_history (last 20 entries)

for entry in client.credits.iter(page_size=100):
    print(entry.created_at, entry.operation, entry.amount, "→",
          entry.balance_after)
```

`amount` sign: **negative** = debit (spent), **positive** = credit
(top-up, refund). `balance_after` lets you reconstruct time-travel
balance without re-summing.

## Refunds

The training pipeline refunds unused GPU minutes when:
- A run is `cancelled` mid-training.
- A run `failed` before consuming the full `timeout` budget.

Refunds appear as positive ledger entries with operation
`training_refund_<gpu>`. They are automatic — no SDK call required.
