#!/usr/bin/env python3
"""Upload → auto-annotate → train, end-to-end.

Wraps :func:`pictograph.workflows.full_pipeline` with a CLI surface
agents can shell out to. Reads ``PICTOGRAPH_API_KEY`` from env.

Usage:
    python full_pipeline.py \\
        --folder ./road_signs \\
        --dataset road-signs \\
        --classes "stop_sign:bbox,yield:bbox" \\
        --pipeline yolox

Class spec format: ``name:output_type,name:output_type,…`` where
``output_type`` is ``polygon``/``bbox``/``tag`` (default ``polygon``).
"""

from __future__ import annotations

import argparse
import json
import sys

from pictograph import Client
from pictograph.workflows import full_pipeline


def _parse_classes(spec: str) -> list[dict[str, str]]:
    """``"car:polygon,person:bbox"`` -> list of dicts."""
    classes: list[dict[str, str]] = []
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        if ":" in part:
            name, output_type = part.split(":", 1)
        else:
            name, output_type = part, "polygon"
        classes.append({"name": name, "output_type": output_type})
    if not classes:
        raise ValueError(f"No classes parsed from {spec!r}")
    return classes


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--folder", required=True, help="Local folder of images.")
    parser.add_argument("--dataset", required=True, help="Destination dataset name.")
    parser.add_argument(
        "--classes",
        required=True,
        help="Comma-separated 'name:output_type' specs (output_type defaults to polygon).",
    )
    parser.add_argument(
        "--pipeline",
        default="yolox",
        choices=[
            "yolox", "detectron2", "sm_pytorch", "classification",
            "rfdetr_detection", "rfdetr_segmentation",
        ],
    )
    parser.add_argument("--gpu", default="a10g", choices=["a10g", "a100", "h100"])
    parser.add_argument("--no-annotate", action="store_true",
                        help="Skip the auto-annotate phase.")
    parser.add_argument("--no-train", action="store_true",
                        help="Skip the training phase.")
    parser.add_argument(
        "--min-credits", type=int, default=1,
        help="Skip paid phases if balance is below this. 0 disables the check.",
    )
    args = parser.parse_args()

    client = Client()
    report = full_pipeline(
        client,
        dataset_name=args.dataset,
        folder=args.folder,
        classes=_parse_classes(args.classes),
        pipeline=args.pipeline,
        gpu=args.gpu,
        annotate=not args.no_annotate,
        train=not args.no_train,
        min_credits=args.min_credits or None,
    )

    print(json.dumps({
        "dataset_name": report.dataset_name,
        "upload": {
            "uploaded": report.upload.images_uploaded,
            "skipped": report.upload.images_skipped,
            "failed": len(report.upload.failures),
        },
        "annotate": (
            None if report.annotate is None else {
                "processed": report.annotate.images_processed,
                "annotations_added": report.annotate.annotations_added,
                "failed": len(report.annotate.failures),
            }
        ),
        "training_run_id": report.training_run.id if report.training_run else None,
        "model_id": report.model.id if report.model else None,
        "credit_skip_reason": report.credit_skip_reason,
        "success": report.success,
    }, indent=2))
    return 0 if report.success else 1


if __name__ == "__main__":
    sys.exit(main())
