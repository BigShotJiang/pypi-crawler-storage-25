#!/usr/bin/env python3
"""Upload a folder + optionally auto-annotate.

Wraps :func:`upload_dataset_from_folder` then (if classes given)
:func:`auto_annotate_dataset`.

Usage:
    python upload_and_annotate.py --folder ./photos --dataset my-photos
    python upload_and_annotate.py --folder ./photos --dataset my-photos \\
        --classes "person:polygon,car:bbox"
    python upload_and_annotate.py --dataset existing --classes "damage:polygon" --no-upload
"""

from __future__ import annotations

import argparse
import json
import sys

from pictograph import Client
from pictograph.workflows import (
    auto_annotate_dataset,
    upload_dataset_from_folder,
)


def _parse_classes(spec: str) -> list[dict[str, str]]:
    """``"car:polygon,person:bbox"`` -> list of dicts."""
    classes: list[dict[str, str]] = []
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        if ":" in part:
            name, output_type = part.split(":", 1)
        else:
            name, output_type = part, "polygon"
        classes.append({"name": name, "output_type": output_type})
    if not classes:
        raise ValueError(f"No classes parsed from {spec!r}")
    return classes


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--folder", help="Local folder. Required unless --no-upload.")
    parser.add_argument("--classes",
                        help="Comma-separated specs. Omit to upload only.")
    parser.add_argument("--no-upload", action="store_true",
                        help="Skip upload (operate on existing dataset).")
    parser.add_argument("--mode", default="batch", choices=["batch", "text"])
    parser.add_argument("--overwrite", action="store_true",
                        help="Re-annotate images that already have annotations.")
    parser.add_argument("--max-workers", type=int, default=8)
    args = parser.parse_args()

    if not args.no_upload and not args.folder:
        parser.error("--folder required unless --no-upload")

    client = Client()
    output: dict[str, object] = {"dataset": args.dataset}

    if not args.no_upload:
        upload_report = upload_dataset_from_folder(
            client, args.dataset, args.folder, max_workers=args.max_workers,
        )
        output["upload"] = {
            "uploaded": upload_report.images_uploaded,
            "skipped": upload_report.images_skipped,
            "failed": len(upload_report.failures),
        }

    if args.classes:
        annotate_report = auto_annotate_dataset(
            client, args.dataset,
            classes=_parse_classes(args.classes),
            mode=args.mode,
            overwrite=args.overwrite,
        )
        output["annotate"] = {
            "processed": annotate_report.images_processed,
            "annotations_added": annotate_report.annotations_added,
            "skipped": annotate_report.images_skipped,
            "failed": len(annotate_report.failures),
            "job_id": annotate_report.job_id,
        }

    print(json.dumps(output, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
