#!/usr/bin/env python3
"""Create + download a dataset export in any supported format.

Usage:
    python export.py --dataset road-signs --name for-yolov8 --format yolo \\
        --output ./road-signs.zip
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from pictograph import Client

_FORMATS = (
    "pictograph", "coco", "csv", "cvat", "labelme", "pascal_voc", "yolo",
)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--name", required=True, help="Export name (unique per dataset).")
    parser.add_argument("--format", default="pictograph", choices=_FORMATS)
    parser.add_argument("--output", required=True, help="Local path for the ZIP.")
    parser.add_argument("--no-images", action="store_true",
                        help="Exclude image files from the ZIP (annotations only).")
    parser.add_argument(
        "--class-filter",
        help="Comma-separated class names; omits everything else.",
    )
    parser.add_argument(
        "--status-filter",
        default="complete",
        choices=["all", "complete", "in_progress", "new"],
    )
    args = parser.parse_args()

    class_filter = (
        [c.strip() for c in args.class_filter.split(",") if c.strip()]
        if args.class_filter
        else None
    )

    client = Client()
    export = client.exports.create(
        args.dataset,
        args.name,
        format=args.format,
        include_images=not args.no_images,
        class_filter=class_filter,
        status_filter=args.status_filter,
        wait=True,
    )
    output_path = Path(args.output).expanduser()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    client.exports.download(args.dataset, args.name, output_path=output_path)

    print(json.dumps({
        "export_id": export.id,
        "format": args.format,
        "status": export.status,
        "image_count": export.image_count,
        "annotation_count": export.annotation_count,
        "output_path": str(output_path),
        "size_bytes": output_path.stat().st_size,
    }, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
