#!/usr/bin/env python3
"""List + import remote datasets from V7 (Darwin) or Roboflow.

Usage (list available remote datasets):
    python import_connector.py --provider v7 --api-key $V7_KEY --list

Usage (import one or more):
    python import_connector.py --provider v7 --api-key $V7_KEY \\
        --dataset-ids ds_abc,ds_xyz
"""

from __future__ import annotations

import argparse
import json
import sys

from pictograph import Client


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--provider", required=True, choices=["v7", "roboflow"])
    parser.add_argument("--api-key", required=True,
                        help="API key for the source provider.")
    parser.add_argument("--list", action="store_true",
                        help="List available datasets without importing.")
    parser.add_argument(
        "--dataset-ids",
        help="Comma-separated remote dataset IDs to import. Required unless --list.",
    )
    parser.add_argument("--no-wait", action="store_true",
                        help="Fire-and-forget; print import_id and exit.")
    args = parser.parse_args()

    client = Client()

    validation = client.connectors.validate(
        provider=args.provider, api_key=args.api_key,
    )
    if not validation.valid:
        print(json.dumps({"error": "API key validation failed", "valid": False}))
        return 2

    if args.list:
        print(json.dumps({
            "provider": args.provider,
            "valid": True,
            "datasets": [d.model_dump(exclude_none=True) for d in validation.datasets],
        }, indent=2))
        return 0

    if not args.dataset_ids:
        parser.error("--dataset-ids required (or use --list to enumerate)")

    requested_ids = {x.strip() for x in args.dataset_ids.split(",") if x.strip()}
    selected = [d for d in validation.datasets if d.id in requested_ids]
    if not selected:
        print(json.dumps({
            "error": "No matching datasets",
            "requested": sorted(requested_ids),
            "available": [d.id for d in validation.datasets],
        }))
        return 2

    job = client.connectors.import_(
        args.provider, args.api_key, selected, wait=not args.no_wait,
    )
    print(json.dumps({
        "import_id": job.import_id,
        "status": job.status,
        "datasets": [d.model_dump(exclude_none=True) for d in job.datasets],
    }, indent=2))
    return 0 if job.status in ("completed", "started", "processing") else 1


if __name__ == "__main__":
    sys.exit(main())
