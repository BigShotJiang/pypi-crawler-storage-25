#!/usr/bin/env python3
"""Train a model from an existing annotated dataset.

Wraps :func:`train_pipeline`. Auto-creates the export, kicks off
training on Modal, polls until completion (default), then prints the
trained model UUID.

Usage:
    python train.py --dataset road-signs --pipeline yolox
    python train.py --dataset road-signs --pipeline detectron2 --gpu a100 --epochs 50
"""

from __future__ import annotations

import argparse
import json
import sys

from pictograph import Client
from pictograph.workflows import train_pipeline


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", required=True)
    parser.add_argument(
        "--pipeline",
        required=True,
        choices=[
            "yolox", "detectron2", "sm_pytorch", "classification",
            "rfdetr_detection", "rfdetr_segmentation",
        ],
    )
    parser.add_argument("--gpu", default="a10g", choices=["a10g", "a100", "h100"])
    parser.add_argument("--name", help="Run name. Defaults to a timestamped slug.")
    parser.add_argument("--epochs", type=int, help="Override epochs.")
    parser.add_argument("--batch-size", type=int, help="Override batch_size.")
    parser.add_argument("--learning-rate", type=float, help="Override learning_rate.")
    parser.add_argument("--no-wait", action="store_true",
                        help="Fire-and-forget; print run_id and exit.")
    parser.add_argument("--timeout", type=float, default=7200.0,
                        help="Max seconds to wait (default 7200 = 2h).")
    parser.add_argument(
        "--class-filter",
        help="Comma-separated class names to limit training to.",
    )
    args = parser.parse_args()

    config: dict[str, object] = {}
    if args.epochs is not None:
        config["epochs"] = args.epochs
    if args.batch_size is not None:
        config["batch_size"] = args.batch_size
    if args.learning_rate is not None:
        config["learning_rate"] = args.learning_rate

    class_filter = (
        [c.strip() for c in args.class_filter.split(",") if c.strip()]
        if args.class_filter
        else None
    )

    client = Client()
    run, model = train_pipeline(
        client,
        args.dataset,
        pipeline=args.pipeline,
        gpu=args.gpu,
        name=args.name,
        config=config or None,
        class_filter=class_filter,
        wait=not args.no_wait,
        timeout=args.timeout,
    )

    print(json.dumps({
        "run_id": run.id,
        "status": run.status,
        "progress": run.progress,
        "current_epoch": run.current_epoch,
        "total_epochs": run.total_epochs,
        "metrics": run.metrics,
        "model_id": model.id if model else None,
        "model_status": model.status if model else None,
    }, indent=2))
    return 0 if run.status in ("completed", "queued") else 1


if __name__ == "__main__":
    sys.exit(main())
