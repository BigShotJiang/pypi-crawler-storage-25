"""Shared pytest fixtures for the Pictograph SDK test suite."""

from __future__ import annotations
