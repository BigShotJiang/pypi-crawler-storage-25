"""Tests for the top-level Typer app + auth resolution.

The CLI is tested via ``typer.testing.CliRunner`` — a synchronous,
in-process invocation that captures stdout/stderr without spawning a
subprocess. Each command's underlying SDK client is mocked at the
import boundary.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from pictograph.cli._app import app
from pictograph.cli._config import (
    CliConfig,
    load_config,
    resolve_api_key,
    write_config,
)
from pictograph.models.credit import CreditBalance
from pictograph.models.dataset import Dataset


def _patch_get_client_everywhere(client: MagicMock) -> Any:
    """Patch ``get_client`` in every command-module namespace at once.

    Because each command does ``from pictograph.cli._client import get_client``,
    patching the source module isn't enough — each importer's local binding has
    to point at the mock too.
    """
    targets = [
        "pictograph.cli.commands.datasets.get_client",
        "pictograph.cli.commands.images.get_client",
        "pictograph.cli.commands.annotations.get_client",
        "pictograph.cli.commands.train.get_client",
        "pictograph.cli.commands.models.get_client",
        "pictograph.cli.commands.credits.get_client",
    ]
    return patch.multiple(
        "pictograph.cli._client",
        **{},  # placeholder; we use stack of context managers below
    ) if False else _StackPatcher(targets, client)


class _StackPatcher:
    def __init__(self, targets: list[str], value: Any) -> None:
        self._patches = [patch(t, return_value=value) for t in targets]

    def __enter__(self) -> Any:
        for p in self._patches:
            p.start()
        return None

    def __exit__(self, *exc: Any) -> None:
        for p in reversed(self._patches):
            p.stop()


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture
def isolated_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect ~/.pictograph/* to tmp_path so tests don't touch real config."""
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    monkeypatch.setenv("HOME", str(fake_home))
    monkeypatch.delenv("PICTOGRAPH_API_KEY", raising=False)
    # The module-level CONFIG_PATH was computed at import — patch it too.
    monkeypatch.setattr(
        "pictograph.cli._config.CONFIG_DIR", fake_home / ".pictograph",
    )
    monkeypatch.setattr(
        "pictograph.cli._config.CONFIG_PATH",
        fake_home / ".pictograph" / "config.toml",
    )
    return fake_home


def _dataset(name: str = "ds") -> Dataset:
    return Dataset(
        id="proj-uuid",
        name=name,
        description=None,
        image_count=4,
        completed_image_count=4,
        total_size=1000,
        archived_images=0,
        classes=[],
        images=None,
        created_at=datetime.now(timezone.utc),
    )


# ───────────── version + help ─────────────


def test_version_flag_prints_version(runner: CliRunner) -> None:
    res = runner.invoke(app, ["--version"])
    assert res.exit_code == 0
    assert "pictograph " in res.stdout


def test_help_lists_subcommand_groups(runner: CliRunner) -> None:
    res = runner.invoke(app, ["--help"])
    assert res.exit_code == 0
    for group in (
        "datasets", "images", "annotations", "train",
        "models", "credits", "agents", "init", "login",
    ):
        assert group in res.stdout, f"missing {group!r} in --help"


# ───────────── auth resolution ─────────────


def test_no_api_key_exits_with_clear_error(
    runner: CliRunner, isolated_config: Path
) -> None:
    res = runner.invoke(app, ["datasets", "list"])
    assert res.exit_code == 2
    # Error goes to stderr (mix_stderr default keeps it folded into stdout).
    assert "API key" in res.stdout or "API key" in (res.stderr or "")


def test_api_key_flag_takes_precedence(
    runner: CliRunner, isolated_config: Path
) -> None:
    """--api-key beats env beats config."""
    os.environ["PICTOGRAPH_API_KEY"] = "pk_live_env"
    try:
        write_config(api_key="pk_live_config")
        assert resolve_api_key("pk_live_flag") == "pk_live_flag"
        assert resolve_api_key() == "pk_live_env"
    finally:
        os.environ.pop("PICTOGRAPH_API_KEY", None)


def test_env_beats_config(
    runner: CliRunner, isolated_config: Path
) -> None:
    write_config(api_key="pk_live_config")
    os.environ["PICTOGRAPH_API_KEY"] = "pk_live_env"
    try:
        assert resolve_api_key() == "pk_live_env"
    finally:
        os.environ.pop("PICTOGRAPH_API_KEY", None)


def test_load_config_returns_empty_when_missing(isolated_config: Path) -> None:
    cfg = load_config()
    assert cfg == CliConfig()


def test_write_then_load_round_trip(isolated_config: Path) -> None:
    path = write_config(api_key="pk_live_xyz", base_url="https://example.com")
    assert path.is_file()
    cfg = load_config()
    assert cfg.api_key == "pk_live_xyz"
    assert cfg.base_url == "https://example.com"


# ───────────── login command ─────────────


def test_login_writes_config(
    runner: CliRunner, isolated_config: Path
) -> None:
    res = runner.invoke(app, ["login", "--api-key", "pk_live_test"])
    assert res.exit_code == 0
    assert "Saved API key" in res.stdout
    assert load_config().api_key == "pk_live_test"


# ───────────── init command ─────────────


def test_init_writes_agents_md(
    runner: CliRunner, tmp_path: Path
) -> None:
    target = tmp_path / "AGENTS.md"
    res = runner.invoke(app, ["init", "-o", str(target)])
    assert res.exit_code == 0
    assert target.is_file()
    body = target.read_text(encoding="utf-8")
    assert "Pictograph" in body
    assert "PICTOGRAPH_API_KEY" in body


def test_init_refuses_to_overwrite_without_force(
    runner: CliRunner, tmp_path: Path
) -> None:
    target = tmp_path / "AGENTS.md"
    target.write_text("existing", encoding="utf-8")
    res = runner.invoke(app, ["init", "-o", str(target)])
    assert res.exit_code == 1
    assert target.read_text() == "existing"


def test_init_force_overwrites(
    runner: CliRunner, tmp_path: Path
) -> None:
    target = tmp_path / "AGENTS.md"
    target.write_text("zzz_sentinel_zzz", encoding="utf-8")
    res = runner.invoke(app, ["init", "-o", str(target), "--force"])
    assert res.exit_code == 0
    assert "zzz_sentinel_zzz" not in target.read_text()
    assert "Pictograph" in target.read_text()


# ───────────── command dispatch (one happy-path per group) ─────────────


def test_datasets_list_renders_json(
    runner: CliRunner, isolated_config: Path
) -> None:
    write_config(api_key="pk_live_x")
    client = MagicMock()
    client.datasets.list.return_value = [_dataset("a"), _dataset("b")]
    with _patch_get_client_everywhere(client):
        res = runner.invoke(app, ["datasets", "list", "--json"])
    assert res.exit_code == 0, res.stdout
    payload = json.loads(res.stdout)
    assert len(payload) == 2
    client.datasets.list.assert_called_once_with(limit=100)


def test_datasets_get(runner: CliRunner, isolated_config: Path) -> None:
    write_config(api_key="pk_live_x")
    client = MagicMock()
    client.datasets.get.return_value = _dataset("ds")
    with _patch_get_client_everywhere(client):
        res = runner.invoke(app, ["datasets", "get", "ds"])
    assert res.exit_code == 0, res.stdout
    payload = json.loads(res.stdout)
    assert payload["name"] == "ds"


def test_credits_balance(runner: CliRunner, isolated_config: Path) -> None:
    write_config(api_key="pk_live_x")
    client = MagicMock()
    client.credits.balance.return_value = CreditBalance(
        credits_remaining=42,
        credits_monthly_allowance=1000,
        credits_reset_at=None,
        recent_history=[],
    )
    with _patch_get_client_everywhere(client):
        res = runner.invoke(app, ["credits", "balance"])
    assert res.exit_code == 0, res.stdout
    assert "Remaining:" in res.stdout
    assert "42" in res.stdout


def test_agents_list_tools(runner: CliRunner) -> None:
    """Rich truncates long names in narrow terminals — assert on stable prefix."""
    res = runner.invoke(app, ["agents", "list-tools"])
    assert res.exit_code == 0, res.stdout
    # Tool names get truncated by Rich at ~22 chars; assert on a prefix present
    # in the rendered table regardless of column width.
    assert "Agent tools" in res.stdout
    assert "upload_dataset" in res.stdout
    assert "credit_balance" in res.stdout


def test_agents_export_tools_to_stdout(runner: CliRunner) -> None:
    res = runner.invoke(app, ["agents", "export-tools"])
    assert res.exit_code == 0, res.stdout
    payload = json.loads(res.stdout)
    assert isinstance(payload, list)
    assert len(payload) >= 25
    names = {t["name"] for t in payload}
    assert "upload_dataset_from_folder" in names


def test_agents_install_skill_to_custom_dir(
    runner: CliRunner, tmp_path: Path
) -> None:
    res = runner.invoke(
        app,
        ["agents", "install-skill",
         "--target", "claude-code",
         "--output", str(tmp_path)],
    )
    assert res.exit_code == 0, res.stdout
    payload = json.loads(res.stdout)
    assert payload["installed"] is True
    assert (tmp_path / "pictograph-cv" / "SKILL.md").is_file()


def test_agents_install_skill_invalid_target(runner: CliRunner) -> None:
    res = runner.invoke(
        app,
        ["agents", "install-skill", "--target", "nonsense"],
    )
    assert res.exit_code == 2


# ───────────── typing import (CliRunner dependency for type checker) ─────────────


