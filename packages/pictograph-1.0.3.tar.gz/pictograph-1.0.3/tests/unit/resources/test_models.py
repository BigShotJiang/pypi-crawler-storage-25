"""Tests for ``pictograph.resources.models.Models``.

Coverage targets:
- ``list`` and ``iter`` with all filter combinations.
- ``get`` happy + 404.
- ``download`` — fetches signed URL, streams ONNX bytes, atomic rename,
  failure leaves no partial file.
- ``delete`` — happy + 403 (insufficient role).
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

import pytest

from pictograph._http.transport import Transport
from pictograph._internal.config import ClientConfig
from pictograph.exceptions import ApiError, ForbiddenError, NotFoundError, ValidationError
from pictograph.models.model import Model
from pictograph.resources.models import Models

if TYPE_CHECKING:
    from pytest_httpx import HTTPXMock

BASE = "https://api.test.local"
KEY = "pk_live_test"


@pytest.fixture
def transport() -> Transport:
    config = ClientConfig(api_key=KEY, base_url=BASE, timeout=10.0, max_retries=0)  # type: ignore[arg-type]
    t = Transport(config, api_key=KEY)
    yield t
    t.close()


@pytest.fixture
def models(transport: Transport) -> Models:
    return Models(transport)


def _model_payload(**overrides: Any) -> dict[str, Any]:
    base: dict[str, Any] = {
        "id": "model-uuid-1",
        "organization_id": "org-uuid",
        "name": "Stop Sign Detector",
        "description": "YOLOX-S trained on road-signs v1",
        "model_type": "object_detection",
        "architecture": "yolox-s",
        "visibility": "private",
        "status": "ready",
        "metrics": {"mAP": 0.87, "precision": 0.91, "recall": 0.85},
        "class_mapping": {"0": "stop_sign", "1": "yield"},
        "version": "1.0.0",
        "parent_model_id": None,
        "created_at": "2026-04-01T00:00:00Z",
        "updated_at": "2026-04-01T01:00:00Z",
    }
    base.update(overrides)
    return base


# ───────────── list / iter ─────────────


def test_list_returns_typed_models(httpx_mock: HTTPXMock, models: Models) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/models/?limit=50&offset=0",
        json={"success": True, "models": [_model_payload(), _model_payload(id="m2", name="Other")]},
    )
    result = models.list()
    assert len(result) == 2
    assert all(isinstance(m, Model) for m in result)


def test_list_passes_all_filter_params(
    httpx_mock: HTTPXMock, models: Models
) -> None:
    httpx_mock.add_response(
        method="GET",
        url=(
            f"{BASE}/api/v1/developer/models/"
            "?limit=20&offset=0&dataset_name=road-signs&status=ready"
            "&model_type=object_detection"
        ),
        json={"models": [_model_payload()]},
    )
    result = models.list(
        dataset_name="road-signs",
        status="ready",
        model_type="object_detection",
        limit=20,
    )
    assert len(result) == 1


def test_list_empty_result(httpx_mock: HTTPXMock, models: Models) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/models/?limit=50&offset=0",
        json={"models": []},
    )
    assert models.list() == []


def test_iter_paginates(httpx_mock: HTTPXMock, models: Models) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/api/v1/developer/models/?offset=0&limit=2",
        json={"models": [_model_payload(id="m1"), _model_payload(id="m2")]},
    )
    httpx_mock.add_response(
        url=f"{BASE}/api/v1/developer/models/?offset=2&limit=2",
        json={"models": [_model_payload(id="m3")]},
    )
    result = list(models.iter(page_size=2))
    assert [m.id for m in result] == ["m1", "m2", "m3"]


# ───────────── get ─────────────


def test_get_returns_typed_model(httpx_mock: HTTPXMock, models: Models) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/models/model-uuid-1",
        json={"success": True, "model": _model_payload()},
    )
    m = models.get("model-uuid-1")
    assert isinstance(m, Model)
    assert m.id == "model-uuid-1"
    assert m.metrics == {"mAP": 0.87, "precision": 0.91, "recall": 0.85}


def test_get_404(httpx_mock: HTTPXMock, models: Models) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/models/missing",
        status_code=404,
        json={"detail": "Model not found"},
    )
    with pytest.raises(NotFoundError):
        models.get("missing")


# ───────────── download ─────────────


def test_download_streams_onnx_to_file_atomically(
    httpx_mock: HTTPXMock, models: Models, tmp_path: Path
) -> None:
    download_url = "https://storage.test/model-token"
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/models/model-uuid-1/download",
        json={
            "success": True,
            "download_url": download_url,
            "model_name": "Stop Sign Detector",
            "filename": "model.onnx",
        },
    )
    httpx_mock.add_response(
        method="GET",
        url=download_url,
        content=b"\x08\x01\x12FAKE_ONNX_BYTES",
        headers={"Content-Length": "17"},
    )
    out = tmp_path / "model.onnx"
    result = models.download("model-uuid-1", out)
    assert result == out
    assert out.read_bytes() == b"\x08\x01\x12FAKE_ONNX_BYTES"
    assert not (tmp_path / "model.onnx.part").exists()


def test_download_progress_callback(
    httpx_mock: HTTPXMock, models: Models, tmp_path: Path
) -> None:
    url = "https://storage.test/u"
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/models/model-uuid-1/download",
        json={"download_url": url},
    )
    httpx_mock.add_response(
        method="GET",
        url=url,
        content=b"X" * 256,
        headers={"Content-Length": "256"},
    )
    seen: list[tuple[int, int]] = []

    def cb(sent: int, total: int) -> None:
        seen.append((sent, total))

    models.download("model-uuid-1", tmp_path / "m.onnx", progress=cb)
    assert seen[-1] == (256, 256)


def test_download_400_when_not_ready(
    httpx_mock: HTTPXMock, models: Models, tmp_path: Path
) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/models/model-uuid-1/download",
        status_code=400,
        json={"detail": "Model status is 'training'; only 'ready' models can be downloaded."},
    )
    with pytest.raises(ValidationError):
        models.download("model-uuid-1", tmp_path / "m.onnx")


def test_download_404_when_weights_missing(
    httpx_mock: HTTPXMock, models: Models, tmp_path: Path
) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/models/model-uuid-1/download",
        status_code=404,
        json={"detail": "Model weights file not found in storage"},
    )
    with pytest.raises(NotFoundError):
        models.download("model-uuid-1", tmp_path / "m.onnx")


def test_download_5xx_from_gcs_no_partial_file(
    httpx_mock: HTTPXMock, models: Models, tmp_path: Path
) -> None:
    url = "https://storage.test/u"
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/models/model-uuid-1/download",
        json={"download_url": url},
    )
    httpx_mock.add_response(method="GET", url=url, status_code=500, content=b"oops")
    out = tmp_path / "m.onnx"
    with pytest.raises(ApiError):
        models.download("model-uuid-1", out)
    assert not out.exists()
    assert not (tmp_path / "m.onnx.part").exists()


def test_download_creates_parent_directories(
    httpx_mock: HTTPXMock, models: Models, tmp_path: Path
) -> None:
    url = "https://storage.test/u"
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/models/model-uuid-1/download",
        json={"download_url": url},
    )
    httpx_mock.add_response(method="GET", url=url, content=b"x")
    out = tmp_path / "deep" / "nested" / "m.onnx"
    models.download("model-uuid-1", out)
    assert out.exists()


# ───────────── delete ─────────────


def test_delete_round_trip(httpx_mock: HTTPXMock, models: Models) -> None:
    httpx_mock.add_response(
        method="DELETE",
        url=f"{BASE}/api/v1/developer/models/model-uuid-1",
        json={"success": True, "message": "Model deleted"},
    )
    models.delete("model-uuid-1")  # returns None; no exception = pass


def test_delete_403_propagates(httpx_mock: HTTPXMock, models: Models) -> None:
    httpx_mock.add_response(
        method="DELETE",
        url=f"{BASE}/api/v1/developer/models/model-uuid-1",
        status_code=403,
        json={"detail": "Insufficient permissions to delete models"},
    )
    with pytest.raises(ForbiddenError):
        models.delete("model-uuid-1")


def test_delete_404_propagates(httpx_mock: HTTPXMock, models: Models) -> None:
    httpx_mock.add_response(
        method="DELETE",
        url=f"{BASE}/api/v1/developer/models/missing",
        status_code=404,
        json={"detail": "Model not found"},
    )
    with pytest.raises(NotFoundError):
        models.delete("missing")
