"""Tests for ``pictograph.resources.datasets.Datasets``.

Coverage targets:
- ``list`` and ``iter`` against the developer datasets endpoint, including
  pagination across multiple pages and the ``max_total`` cap.
- ``get`` (by name) and ``get_by_id`` (by UUID) — happy path and 404.
- ``download`` — the most complex method: fetches a batch of URLs, then
  downloads images (signed GCS URLs, no auth) and annotations (authenticated
  API endpoint) in parallel via a worker pool.
  - Mode permutations (``full`` / ``images_only`` / ``annotations_only``)
  - Partial-failure reporting (failures collected, never raised)
  - Progress callback semantics (one fire per file, monotonic ``completed``)
  - Empty dataset short-circuits cleanly
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING

import pytest

from pictograph._http.transport import Transport
from pictograph._internal.config import ClientConfig
from pictograph.exceptions import NotFoundError, ServerError
from pictograph.models.dataset import Dataset
from pictograph.resources.datasets import (
    Datasets,
    DownloadFailure,
    DownloadReport,
)

if TYPE_CHECKING:
    from pytest_httpx import HTTPXMock

BASE = "https://api.test.local"
KEY = "pk_live_test"

# ───────────── fixtures ─────────────


@pytest.fixture
def transport() -> Transport:
    config = ClientConfig(api_key=KEY, base_url=BASE, timeout=10.0, max_retries=0)  # type: ignore[arg-type]
    t = Transport(config, api_key=KEY)
    yield t
    t.close()


@pytest.fixture
def datasets(transport: Transport) -> Datasets:
    return Datasets(transport)


def _dataset_payload(**overrides: object) -> dict[str, object]:
    """Minimal valid Dataset payload matching the backend's list/get response."""
    base: dict[str, object] = {
        "id": "ds-uuid-1",
        "name": "road-signs",
        "description": "Road signs dataset",
        "image_count": 100,
        "completed_image_count": 80,
        "total_size": 12345,
        "archived_images": 2,
        "classes": [{"name": "stop_sign", "type": "object", "color": "#FF0000"}],
        "created_at": "2026-01-01T00:00:00Z",
    }
    base.update(overrides)
    return base


# ───────────── list ─────────────


def test_list_returns_typed_datasets(
    httpx_mock: HTTPXMock, datasets: Datasets
) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/datasets/?limit=100",
        json={"success": True, "datasets": [_dataset_payload(), _dataset_payload(id="ds-2", name="cars")]},
    )
    result = datasets.list()
    assert len(result) == 2
    assert all(isinstance(d, Dataset) for d in result)
    assert {d.name for d in result} == {"road-signs", "cars"}


def test_list_empty_result(httpx_mock: HTTPXMock, datasets: Datasets) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/datasets/?limit=100",
        json={"success": True, "datasets": []},
    )
    assert datasets.list() == []


def test_list_passes_limit_param(httpx_mock: HTTPXMock, datasets: Datasets) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/datasets/?limit=50",
        json={"datasets": []},
    )
    datasets.list(limit=50)
    sent = httpx_mock.get_request()
    assert sent is not None
    assert "limit=50" in str(sent.url)


def test_list_invalid_dataset_payload_raises_server_error(
    httpx_mock: HTTPXMock, datasets: Datasets
) -> None:
    # Backend returns malformed item (missing required `name`).
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/datasets/?limit=100",
        json={"datasets": [{"id": "x", "image_count": 1, "created_at": "2026-01-01T00:00:00Z"}]},
    )
    with pytest.raises(ServerError):
        datasets.list()


def test_list_missing_datasets_key_returns_empty(
    httpx_mock: HTTPXMock, datasets: Datasets
) -> None:
    # Defensive: backend regression that drops the key shouldn't raise on the
    # client side — empty result is the safe interpretation.
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/datasets/?limit=100",
        json={"success": True},
    )
    assert datasets.list() == []


# ───────────── iter ─────────────


def test_iter_paginates_across_pages(
    httpx_mock: HTTPXMock, datasets: Datasets
) -> None:
    page1 = [_dataset_payload(id="d1", name="n1"), _dataset_payload(id="d2", name="n2")]
    page2 = [_dataset_payload(id="d3", name="n3"), _dataset_payload(id="d4", name="n4")]
    page3: list[dict[str, object]] = [_dataset_payload(id="d5", name="n5")]
    httpx_mock.add_response(
        url=f"{BASE}/api/v1/developer/datasets/?offset=0&limit=2",
        json={"datasets": page1},
    )
    httpx_mock.add_response(
        url=f"{BASE}/api/v1/developer/datasets/?offset=2&limit=2",
        json={"datasets": page2},
    )
    httpx_mock.add_response(
        url=f"{BASE}/api/v1/developer/datasets/?offset=4&limit=2",
        json={"datasets": page3},
    )
    all_items = list(datasets.iter(page_size=2))
    assert [d.name for d in all_items] == ["n1", "n2", "n3", "n4", "n5"]


def test_iter_max_total_caps_results(
    httpx_mock: HTTPXMock, datasets: Datasets
) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/api/v1/developer/datasets/?offset=0&limit=2",
        json={"datasets": [_dataset_payload(id="d1", name="n1"), _dataset_payload(id="d2", name="n2")]},
    )
    httpx_mock.add_response(
        url=f"{BASE}/api/v1/developer/datasets/?offset=2&limit=2",
        json={"datasets": [_dataset_payload(id="d3", name="n3"), _dataset_payload(id="d4", name="n4")]},
    )
    items = list(datasets.iter(page_size=2, max_total=3))
    assert [d.name for d in items] == ["n1", "n2", "n3"]


def test_iter_first_short_page_terminates(
    httpx_mock: HTTPXMock, datasets: Datasets
) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/api/v1/developer/datasets/?offset=0&limit=10",
        json={"datasets": [_dataset_payload(id="x", name="x")]},
    )
    items = list(datasets.iter(page_size=10))
    assert len(items) == 1
    assert len(httpx_mock.get_requests()) == 1


def test_iter_empty_first_page(
    httpx_mock: HTTPXMock, datasets: Datasets
) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/api/v1/developer/datasets/?offset=0&limit=10",
        json={"datasets": []},
    )
    assert list(datasets.iter(page_size=10)) == []


# ───────────── get / get_by_id ─────────────


def test_get_by_name_happy_path(httpx_mock: HTTPXMock, datasets: Datasets) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/api/v1/developer/datasets/by-name/road-signs",
        json={"success": True, "dataset": _dataset_payload(organization_id="org-1")},
    )
    ds = datasets.get("road-signs")
    assert ds.name == "road-signs"
    assert ds.organization_id == "org-1"


def test_get_by_name_404(httpx_mock: HTTPXMock, datasets: Datasets) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/api/v1/developer/datasets/by-name/missing",
        status_code=404,
        json={"detail": "Dataset 'missing' not found"},
    )
    with pytest.raises(NotFoundError):
        datasets.get("missing")


def test_get_with_include_images_passes_query_params(
    httpx_mock: HTTPXMock, datasets: Datasets
) -> None:
    httpx_mock.add_response(
        url=(
            f"{BASE}/api/v1/developer/datasets/by-name/road-signs"
            "?include_images=true&images_limit=500&images_offset=0"
        ),
        json={"dataset": _dataset_payload()},
    )
    datasets.get("road-signs", include_images=True, images_limit=500)
    sent = httpx_mock.get_request()
    assert sent is not None
    url = str(sent.url)
    assert "include_images=true" in url
    assert "images_limit=500" in url


def test_get_without_include_images_omits_image_params(
    httpx_mock: HTTPXMock, datasets: Datasets
) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/api/v1/developer/datasets/by-name/road-signs",
        json={"dataset": _dataset_payload()},
    )
    datasets.get("road-signs")
    sent = httpx_mock.get_request()
    assert sent is not None
    assert "include_images" not in str(sent.url)


def test_get_by_id_happy_path(httpx_mock: HTTPXMock, datasets: Datasets) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/api/v1/developer/datasets/ds-uuid-1",
        json={"success": True, "dataset": _dataset_payload()},
    )
    ds = datasets.get_by_id("ds-uuid-1")
    assert ds.id == "ds-uuid-1"


# ───────────── download ─────────────


@pytest.fixture
def small_image_url() -> str:
    return "https://storage.test/img1.signed?token=abc"


@pytest.fixture
def small_annotation_url() -> str:
    # Relative path → the SDK transport prepends BASE and adds X-API-Key.
    return "/api/v1/developer/annotations/img-1/file"


def _download_listing(image_url: str, annotation_url: str | None) -> dict[str, object]:
    item: dict[str, object] = {
        "id": "img-1",
        "filename": "img_001.jpg",
        "file_size": 100,
        "annotation_count": 1 if annotation_url else 0,
    }
    if image_url:
        item["image_url"] = image_url
    if annotation_url:
        item["annotation_url"] = annotation_url
    return {
        "success": True,
        "dataset_id": "ds-1",
        "items": [item],
        "total_items": 1,
    }


def test_download_full_mode_writes_image_and_annotation_files(
    httpx_mock: HTTPXMock,
    datasets: Datasets,
    tmp_path: Path,
    small_image_url: str,
    small_annotation_url: str,
) -> None:
    httpx_mock.add_response(
        url=(
            f"{BASE}/api/v1/developer/datasets/by-name/road-signs/download"
            "?mode=full&limit=10000"
        ),
        json=_download_listing(small_image_url, small_annotation_url),
    )
    httpx_mock.add_response(
        method="GET",
        url=small_image_url,
        content=b"\xff\xd8\xff\xe0FAKEJPEG",  # JPEG magic + filler
    )
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}{small_annotation_url}",
        json={"image": "img_001.jpg", "annotations": []},
    )
    report = datasets.download("road-signs", tmp_path)
    assert report.success
    assert report.images_downloaded == 1
    assert report.annotations_downloaded == 1
    assert report.dataset_id == "ds-1"
    assert (tmp_path / "img_001.jpg").read_bytes() == b"\xff\xd8\xff\xe0FAKEJPEG"
    ann = json.loads((tmp_path / "img_001.jpg.json").read_text())
    assert ann["image"] == "img_001.jpg"


def test_download_images_only_mode_skips_annotations(
    httpx_mock: HTTPXMock,
    datasets: Datasets,
    tmp_path: Path,
    small_image_url: str,
    small_annotation_url: str,
) -> None:
    httpx_mock.add_response(
        url=(
            f"{BASE}/api/v1/developer/datasets/by-name/road-signs/download"
            "?mode=images_only&limit=10000"
        ),
        json=_download_listing(small_image_url, small_annotation_url),
    )
    httpx_mock.add_response(method="GET", url=small_image_url, content=b"x")
    report = datasets.download("road-signs", tmp_path, mode="images_only")
    assert report.images_downloaded == 1
    assert report.annotations_downloaded == 0
    assert (tmp_path / "img_001.jpg").exists()
    assert not (tmp_path / "img_001.jpg.json").exists()


def test_download_annotations_only_mode_skips_images(
    httpx_mock: HTTPXMock,
    datasets: Datasets,
    tmp_path: Path,
    small_image_url: str,
    small_annotation_url: str,
) -> None:
    httpx_mock.add_response(
        url=(
            f"{BASE}/api/v1/developer/datasets/by-name/road-signs/download"
            "?mode=annotations_only&limit=10000"
        ),
        json=_download_listing(small_image_url, small_annotation_url),
    )
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}{small_annotation_url}",
        json={"image": "img_001.jpg", "annotations": []},
    )
    report = datasets.download("road-signs", tmp_path, mode="annotations_only")
    assert report.images_downloaded == 0
    assert report.annotations_downloaded == 1
    assert not (tmp_path / "img_001.jpg").exists()
    assert (tmp_path / "img_001.jpg.json").exists()


def test_download_creates_output_directory_when_missing(
    httpx_mock: HTTPXMock, datasets: Datasets, tmp_path: Path
) -> None:
    out = tmp_path / "nested" / "fresh"
    httpx_mock.add_response(
        url=(
            f"{BASE}/api/v1/developer/datasets/by-name/road-signs/download"
            "?mode=full&limit=10000"
        ),
        json={"items": [], "dataset_id": "ds-1"},
    )
    report = datasets.download("road-signs", out)
    assert out.exists()
    assert report.success
    assert report.images_downloaded == 0


def test_download_status_filter_propagates(
    httpx_mock: HTTPXMock, datasets: Datasets, tmp_path: Path
) -> None:
    httpx_mock.add_response(
        url=(
            f"{BASE}/api/v1/developer/datasets/by-name/road-signs/download"
            "?mode=full&limit=10000&status_filter=complete"
        ),
        json={"items": [], "dataset_id": "ds-1"},
    )
    datasets.download("road-signs", tmp_path, status_filter="complete")
    sent = [r for r in httpx_mock.get_requests() if "datasets/by-name" in str(r.url)]
    assert len(sent) == 1
    assert "status_filter=complete" in str(sent[0].url)


def test_download_failed_image_recorded_in_report_not_raised(
    httpx_mock: HTTPXMock,
    datasets: Datasets,
    tmp_path: Path,
    small_image_url: str,
) -> None:
    httpx_mock.add_response(
        url=(
            f"{BASE}/api/v1/developer/datasets/by-name/road-signs/download"
            "?mode=images_only&limit=10000"
        ),
        json=_download_listing(small_image_url, None),
    )
    httpx_mock.add_response(
        method="GET",
        url=small_image_url,
        status_code=403,
        content=b"<Error>denied</Error>",
    )
    report = datasets.download("road-signs", tmp_path, mode="images_only")
    assert not report.success
    assert report.images_downloaded == 0
    assert len(report.failures) == 1
    assert report.failures[0].kind == "image"
    assert report.failures[0].filename == "img_001.jpg"


def test_download_progress_callback_fires_once_per_file(
    httpx_mock: HTTPXMock,
    datasets: Datasets,
    tmp_path: Path,
    small_image_url: str,
    small_annotation_url: str,
) -> None:
    httpx_mock.add_response(
        url=(
            f"{BASE}/api/v1/developer/datasets/by-name/road-signs/download"
            "?mode=full&limit=10000"
        ),
        json=_download_listing(small_image_url, small_annotation_url),
    )
    httpx_mock.add_response(method="GET", url=small_image_url, content=b"x")
    httpx_mock.add_response(
        method="GET", url=f"{BASE}{small_annotation_url}", json={"annotations": []}
    )

    events: list[tuple[int, int, str | None]] = []

    def cb(completed: int, total: int, fname: str | None) -> None:
        events.append((completed, total, fname))

    datasets.download("road-signs", tmp_path, progress=cb)
    # Two files (1 image + 1 annotation), so two callbacks.
    assert len(events) == 2
    # Total is constant; completed monotonically increases 1, 2.
    completed_seq = [e[0] for e in events]
    totals = {e[1] for e in events}
    assert completed_seq in ([1, 2],)
    assert totals == {2}


def test_download_empty_dataset_short_circuits_without_workers(
    httpx_mock: HTTPXMock, datasets: Datasets, tmp_path: Path
) -> None:
    httpx_mock.add_response(
        url=(
            f"{BASE}/api/v1/developer/datasets/by-name/road-signs/download"
            "?mode=full&limit=10000"
        ),
        json={"items": [], "dataset_id": "ds-1"},
    )
    report = datasets.download("road-signs", tmp_path)
    assert report.success
    assert report.images_downloaded == 0
    assert report.annotations_downloaded == 0


def test_download_initial_listing_404_propagates(
    httpx_mock: HTTPXMock, datasets: Datasets, tmp_path: Path
) -> None:
    httpx_mock.add_response(
        url=(
            f"{BASE}/api/v1/developer/datasets/by-name/missing/download"
            "?mode=full&limit=10000"
        ),
        status_code=404,
        json={"detail": "Dataset 'missing' not found"},
    )
    with pytest.raises(NotFoundError):
        datasets.download("missing", tmp_path)


def test_download_partial_failure_reports_per_file(
    httpx_mock: HTTPXMock, datasets: Datasets, tmp_path: Path
) -> None:
    # Two items: one downloads, one 404s.
    httpx_mock.add_response(
        url=(
            f"{BASE}/api/v1/developer/datasets/by-name/road-signs/download"
            "?mode=images_only&limit=10000"
        ),
        json={
            "success": True,
            "dataset_id": "ds-1",
            "items": [
                {"id": "i1", "filename": "ok.jpg", "image_url": "https://gcs/ok"},
                {"id": "i2", "filename": "bad.jpg", "image_url": "https://gcs/bad"},
            ],
            "total_items": 2,
        },
    )
    httpx_mock.add_response(method="GET", url="https://gcs/ok", content=b"OK")
    httpx_mock.add_response(method="GET", url="https://gcs/bad", status_code=500)
    report = datasets.download("road-signs", tmp_path, mode="images_only", max_workers=2)
    assert report.images_downloaded == 1
    assert len(report.failures) == 1
    assert report.failures[0].filename == "bad.jpg"
    assert report.total_attempted == 2
    assert not report.success


# ───────────── DownloadReport ─────────────


def test_download_report_success_property() -> None:
    assert DownloadReport(dataset_id="d").success is True
    failed = DownloadReport(
        dataset_id="d",
        failures=[DownloadFailure(filename="x", kind="image", reason="boom")],
    )
    assert failed.success is False


def test_download_report_total_attempted_sums_components() -> None:
    r = DownloadReport(
        dataset_id="d",
        images_downloaded=3,
        annotations_downloaded=2,
        failures=[
            DownloadFailure(filename="a", kind="image", reason="x"),
            DownloadFailure(filename="b", kind="annotation", reason="y"),
        ],
    )
    assert r.total_attempted == 7


def test_download_failure_is_frozen() -> None:
    f = DownloadFailure(filename="x", kind="image", reason="r")
    with pytest.raises(Exception):
        f.filename = "y"  # type: ignore[misc]
