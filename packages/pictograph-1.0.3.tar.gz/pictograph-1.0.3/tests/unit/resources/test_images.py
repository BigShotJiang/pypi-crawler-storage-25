"""Tests for ``pictograph.resources.images.Images``.

Coverage targets:
- ``get`` happy path + 404 propagation.
- ``download`` streams bytes to disk; creates parent dirs.
- ``upload`` three-step flow (signed URL → chunked PUT → register), with:
    - filename / folder / content_type overrides
    - progress callback wiring
    - PIL dimension extraction for valid images
    - graceful degradation for files PIL can't decode
    - missing file raises FileNotFoundError
    - unrecognised extension raises ValueError
- ``delete`` archive (default) vs permanent (query param).
- Helpers: ``_infer_content_type`` and ``_safe_image_dimensions`` boundary cases.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import pytest
from PIL import Image as PILImage

from pictograph._http.transport import Transport
from pictograph._internal.config import ClientConfig
from pictograph.exceptions import ForbiddenError, NotFoundError
from pictograph.models.image import Image
from pictograph.resources.images import (
    Images,
    _infer_content_type,
    _safe_image_dimensions,
)

if TYPE_CHECKING:
    from pytest_httpx import HTTPXMock

BASE = "https://api.test.local"
KEY = "pk_live_test"

# ───────────── fixtures ─────────────


@pytest.fixture
def transport() -> Transport:
    config = ClientConfig(api_key=KEY, base_url=BASE, timeout=10.0, max_retries=0)  # type: ignore[arg-type]
    t = Transport(config, api_key=KEY)
    yield t
    t.close()


@pytest.fixture
def images(transport: Transport) -> Images:
    return Images(transport)


def _image_metadata_payload(**overrides: object) -> dict[str, object]:
    base: dict[str, object] = {
        "id": "img-uuid-1",
        "filename": "img_001.jpg",
        "status": "complete",
        "annotation_count": 3,
        "file_size": 24576,
        "width": 1920,
        "height": 1080,
        "image_url": "https://api.pictograph.io/api/v1/developer/images/img-uuid-1",
        "thumbnail_url": "https://api.pictograph.io/api/cdn/.../img_001.jpg?size=md",
        "annotation_url": "https://api.pictograph.io/api/v1/developer/annotations/img-uuid-1/file",
        "created_at": "2026-01-01T00:00:00Z",
    }
    base.update(overrides)
    return base


def _make_jpeg(path: Path, width: int = 32, height: int = 16) -> Path:
    """Write a real, decodable JPEG to ``path`` of the given dimensions."""
    PILImage.new("RGB", (width, height), color=(128, 64, 32)).save(path, format="JPEG")
    return path


# ───────────── get ─────────────


def test_get_returns_typed_image(httpx_mock: HTTPXMock, images: Images) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/images/img-uuid-1/metadata",
        json={"success": True, "image": _image_metadata_payload()},
    )
    img = images.get("img-uuid-1")
    assert isinstance(img, Image)
    assert img.id == "img-uuid-1"
    assert img.width == 1920
    assert img.height == 1080
    assert img.annotation_count == 3


def test_get_404_raises_not_found(httpx_mock: HTTPXMock, images: Images) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/images/missing/metadata",
        status_code=404,
        json={"detail": "Image not found"},
    )
    with pytest.raises(NotFoundError):
        images.get("missing")


# ───────────── download ─────────────


def test_download_streams_bytes_to_file(
    httpx_mock: HTTPXMock, images: Images, tmp_path: Path
) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/images/img-uuid-1",
        content=b"\xff\xd8\xff\xe0FAKEJPEG_PAYLOAD",
        headers={"Content-Type": "image/jpeg"},
    )
    out = tmp_path / "downloaded.jpg"
    result = images.download("img-uuid-1", out)
    assert result == out
    assert out.read_bytes() == b"\xff\xd8\xff\xe0FAKEJPEG_PAYLOAD"


def test_download_creates_parent_directories(
    httpx_mock: HTTPXMock, images: Images, tmp_path: Path
) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/images/img-uuid-1",
        content=b"x",
    )
    deep = tmp_path / "nested" / "deeper" / "img.jpg"
    images.download("img-uuid-1", deep)
    assert deep.exists()


def test_download_404_raises_before_writing_file(
    httpx_mock: HTTPXMock, images: Images, tmp_path: Path
) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/images/missing",
        status_code=404,
        json={"detail": "Image not found"},
    )
    out = tmp_path / "should-not-exist.jpg"
    with pytest.raises(NotFoundError):
        images.download("missing", out)
    # File was opened for write *only after* the response status was checked.
    # An empty file at the destination would indicate a bug — assert it isn't.
    assert not out.exists()


# ───────────── upload — happy path & overrides ─────────────


def _add_upload_mocks(
    httpx_mock: HTTPXMock,
    *,
    final_image_id: str = "new-img-uuid",
    upload_url: str = "https://storage.test/u-token",
) -> None:
    """Register the four canned responses an upload exercises end to end."""
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/api/v1/developer/images/upload-url",
        json={
            "success": True,
            "upload_url": upload_url,
            "gcs_bucket": "pictograph-app",
            "gcs_path": "org-1/datasets/road-signs/img.jpg",
            "gcs_uri": "gs://pictograph-app/org-1/datasets/road-signs/img.jpg",
        },
    )
    httpx_mock.add_response(method="PUT", url=upload_url, status_code=200)
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/api/v1/developer/images/register",
        json={"success": True, "image_id": final_image_id, "filename": "img.jpg"},
    )
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/images/{final_image_id}/metadata",
        json={
            "success": True,
            "image": _image_metadata_payload(id=final_image_id, filename="img.jpg"),
        },
    )


def test_upload_happy_path_returns_typed_image(
    httpx_mock: HTTPXMock, images: Images, tmp_path: Path
) -> None:
    src = _make_jpeg(tmp_path / "img.jpg", width=64, height=48)
    _add_upload_mocks(httpx_mock)
    result = images.upload("dataset-uuid", src)
    assert isinstance(result, Image)
    assert result.filename == "img.jpg"


def test_upload_calls_endpoints_in_correct_order(
    httpx_mock: HTTPXMock, images: Images, tmp_path: Path
) -> None:
    src = _make_jpeg(tmp_path / "img.jpg")
    _add_upload_mocks(httpx_mock)
    images.upload("dataset-uuid", src)
    # Order: upload-url POST → GCS PUT → register POST → get metadata GET
    paths = [str(r.url) for r in httpx_mock.get_requests()]
    assert paths[0].endswith("/upload-url")
    assert "storage.test" in paths[1]
    assert paths[2].endswith("/register")
    assert paths[3].endswith("/metadata")


def test_upload_missing_file_raises(images: Images, tmp_path: Path) -> None:
    bogus = tmp_path / "does-not-exist.jpg"
    with pytest.raises(FileNotFoundError, match=r"does-not-exist\.jpg"):
        images.upload("dataset-uuid", bogus)


def test_upload_custom_filename_overrides_basename(
    httpx_mock: HTTPXMock, images: Images, tmp_path: Path
) -> None:
    src = _make_jpeg(tmp_path / "local-name.jpg")
    _add_upload_mocks(httpx_mock)
    images.upload("dataset-uuid", src, filename="server-side-name.jpg")
    upload_url_request = httpx_mock.get_requests()[0]
    body = upload_url_request.read().decode()
    assert "server-side-name.jpg" in body
    assert "local-name.jpg" not in body


def test_upload_custom_folder_path_propagates(
    httpx_mock: HTTPXMock, images: Images, tmp_path: Path
) -> None:
    src = _make_jpeg(tmp_path / "img.jpg")
    _add_upload_mocks(httpx_mock)
    images.upload("dataset-uuid", src, folder_path="/train/positive")
    body = httpx_mock.get_requests()[0].read().decode()
    assert "/train/positive" in body


def test_upload_custom_content_type_overrides_inference(
    httpx_mock: HTTPXMock, images: Images, tmp_path: Path
) -> None:
    # File has unknown extension; explicit content_type unblocks the upload.
    src = tmp_path / "data.bin"
    src.write_bytes(b"\x00" * 32)
    _add_upload_mocks(httpx_mock)
    images.upload("dataset-uuid", src, content_type="image/png")
    body = httpx_mock.get_requests()[0].read().decode()
    assert "image/png" in body


def test_upload_unknown_extension_without_explicit_content_type_raises(
    images: Images, tmp_path: Path
) -> None:
    src = tmp_path / "data.bin"
    src.write_bytes(b"\x00")
    with pytest.raises(ValueError, match="MIME type"):
        images.upload("dataset-uuid", src)


def test_upload_progress_callback_is_invoked(
    httpx_mock: HTTPXMock, images: Images, tmp_path: Path
) -> None:
    src = _make_jpeg(tmp_path / "img.jpg")
    _add_upload_mocks(httpx_mock)
    received: list[tuple[int, int]] = []

    def cb(sent: int, total: int) -> None:
        received.append((sent, total))

    images.upload("dataset-uuid", src, progress=cb)
    # At least one progress event for the chunked PUT phase.
    assert len(received) >= 1
    # Final reported value matches the file size on disk.
    assert received[-1][0] == src.stat().st_size
    assert received[-1][1] == src.stat().st_size


def test_upload_extracts_image_dimensions_via_pil(
    httpx_mock: HTTPXMock, images: Images, tmp_path: Path
) -> None:
    src = _make_jpeg(tmp_path / "img.jpg", width=100, height=50)
    _add_upload_mocks(httpx_mock)
    images.upload("dataset-uuid", src)
    register_request = httpx_mock.get_requests()[2]
    body = register_request.read().decode()
    assert "image_width=100" in body
    assert "image_height=50" in body


def test_upload_non_image_falls_through_with_null_dimensions(
    httpx_mock: HTTPXMock, images: Images, tmp_path: Path
) -> None:
    # Garbage bytes with .png suffix → PIL fails to decode → dimensions absent.
    src = tmp_path / "bad.png"
    src.write_bytes(b"this-is-not-a-valid-png")
    _add_upload_mocks(httpx_mock)
    images.upload("dataset-uuid", src)
    register_request = httpx_mock.get_requests()[2]
    body = register_request.read().decode()
    # Form-encoded ``None`` is omitted entirely by httpx, so we assert the
    # dimension fields aren't populated with bogus values.
    assert "image_width=" not in body or "image_width=&" in body or body.endswith("image_width=")


# ───────────── delete ─────────────


def test_delete_archives_by_default(
    httpx_mock: HTTPXMock, images: Images
) -> None:
    httpx_mock.add_response(
        method="DELETE",
        url=f"{BASE}/api/v1/developer/images/img-1",
        json={"success": True, "message": "Image archived"},
    )
    images.delete("img-1")
    sent = httpx_mock.get_request()
    assert sent is not None
    assert "permanent" not in str(sent.url)


def test_delete_permanent_passes_query_param(
    httpx_mock: HTTPXMock, images: Images
) -> None:
    httpx_mock.add_response(
        method="DELETE",
        url=f"{BASE}/api/v1/developer/images/img-1?permanent=true",
        json={"success": True, "message": "Image permanently deleted"},
    )
    images.delete("img-1", permanent=True)
    sent = httpx_mock.get_request()
    assert sent is not None
    assert "permanent=true" in str(sent.url)


def test_delete_forbidden_propagates_typed_error(
    httpx_mock: HTTPXMock, images: Images
) -> None:
    httpx_mock.add_response(
        method="DELETE",
        url=f"{BASE}/api/v1/developer/images/img-1",
        status_code=403,
        json={"detail": "Insufficient permissions to delete images"},
    )
    with pytest.raises(ForbiddenError):
        images.delete("img-1")


def test_delete_404_propagates_typed_error(
    httpx_mock: HTTPXMock, images: Images
) -> None:
    httpx_mock.add_response(
        method="DELETE",
        url=f"{BASE}/api/v1/developer/images/missing",
        status_code=404,
        json={"detail": "Image not found"},
    )
    with pytest.raises(NotFoundError):
        images.delete("missing")


# ───────────── helpers ─────────────


@pytest.mark.parametrize(
    ("filename", "expected"),
    [
        ("photo.jpg", "image/jpeg"),
        ("photo.JPG", "image/jpeg"),  # case-insensitive
        ("photo.jpeg", "image/jpeg"),
        ("photo.png", "image/png"),
        ("photo.gif", "image/gif"),
        ("photo.bmp", "image/bmp"),
        ("photo.webp", "image/webp"),
        ("photo.tiff", "image/tiff"),
        ("photo.tif", "image/tiff"),
        ("photo.heic", "image/heic"),
        ("photo.heif", "image/heif"),
        ("data.bin", "application/octet-stream"),
        ("README", "application/octet-stream"),
        ("something.unknown", "application/octet-stream"),
    ],
)
def test_infer_content_type(filename: str, expected: str) -> None:
    assert _infer_content_type(filename) == expected


def test_safe_image_dimensions_for_real_jpeg(tmp_path: Path) -> None:
    src = _make_jpeg(tmp_path / "img.jpg", width=200, height=100)
    assert _safe_image_dimensions(src) == (200, 100)


def test_safe_image_dimensions_for_garbage_returns_none(tmp_path: Path) -> None:
    src = tmp_path / "bad.png"
    src.write_bytes(b"not an image")
    assert _safe_image_dimensions(src) == (None, None)


def test_safe_image_dimensions_for_missing_file_returns_none(tmp_path: Path) -> None:
    src = tmp_path / "missing.png"
    assert _safe_image_dimensions(src) == (None, None)
