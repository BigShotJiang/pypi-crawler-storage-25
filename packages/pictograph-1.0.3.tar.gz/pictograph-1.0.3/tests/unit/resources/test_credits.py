"""Tests for ``pictograph.resources.credits.Credits``.

Coverage targets:
- ``balance`` returns typed CreditBalance with recent_history typed.
- ``history`` paginates correctly + filter forwarding.
- ``iter`` auto-pages.
- ``estimate`` parses the response shape and surfaces sufficient/cost
  fields for agent decision-making.
- 400 on unknown operation propagates as ValidationError.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import pytest

from pictograph._http.transport import Transport
from pictograph._internal.config import ClientConfig
from pictograph.exceptions import ValidationError
from pictograph.models.credit import CreditBalance, CreditEstimate, CreditLedgerEntry
from pictograph.resources.credits import Credits

if TYPE_CHECKING:
    from pytest_httpx import HTTPXMock

BASE = "https://api.test.local"
KEY = "pk_live_test"


@pytest.fixture
def transport() -> Transport:
    config = ClientConfig(api_key=KEY, base_url=BASE, timeout=10.0, max_retries=0)  # type: ignore[arg-type]
    t = Transport(config, api_key=KEY)
    yield t
    t.close()


@pytest.fixture
def credits(transport: Transport) -> Credits:
    return Credits(transport)


def _ledger_entry(**overrides: Any) -> dict[str, Any]:
    base: dict[str, Any] = {
        "id": "ledger-uuid-1",
        "operation": "training_a10g_per_minute",
        "amount": -150,
        "balance_after": 850,
        "description": "Training pre-charge",
        "metadata": {"run_id": "r1"},
        "created_at": "2026-04-01T00:00:00Z",
    }
    base.update(overrides)
    return base


# ───────────── balance ─────────────


def test_balance_returns_typed_credit_balance(
    httpx_mock: HTTPXMock, credits: Credits
) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/credits/balance",
        json={
            "credits_remaining": 850,
            "credits_monthly_allowance": 1000,
            "credits_reset_at": "2026-05-01T00:00:00Z",
            "recent_history": [
                _ledger_entry(),
                _ledger_entry(id="l2", amount=-3, operation="sam3_per_minute"),
            ],
        },
    )
    balance = credits.balance()
    assert isinstance(balance, CreditBalance)
    assert balance.credits_remaining == 850
    assert balance.credits_monthly_allowance == 1000
    assert len(balance.recent_history) == 2
    assert all(isinstance(e, CreditLedgerEntry) for e in balance.recent_history)


def test_balance_handles_missing_recent_history(
    httpx_mock: HTTPXMock, credits: Credits
) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/credits/balance",
        json={
            "credits_remaining": 0,
            "credits_monthly_allowance": 200,
            "credits_reset_at": None,
        },
    )
    balance = credits.balance()
    assert balance.recent_history == []
    assert balance.credits_reset_at is None


# ───────────── history ─────────────


def test_history_returns_typed_entries(
    httpx_mock: HTTPXMock, credits: Credits
) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/credits/history?limit=50&offset=0",
        json={
            "entries": [_ledger_entry(), _ledger_entry(id="l2")],
            "limit": 50,
            "offset": 0,
        },
    )
    entries = credits.history()
    assert len(entries) == 2
    assert all(isinstance(e, CreditLedgerEntry) for e in entries)


def test_history_passes_pagination_params(
    httpx_mock: HTTPXMock, credits: Credits
) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/credits/history?limit=10&offset=20",
        json={"entries": [], "limit": 10, "offset": 20},
    )
    credits.history(limit=10, offset=20)
    sent = httpx_mock.get_request()
    assert sent is not None
    assert "limit=10" in str(sent.url)
    assert "offset=20" in str(sent.url)


def test_history_empty_result(httpx_mock: HTTPXMock, credits: Credits) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/credits/history?limit=50&offset=0",
        json={"entries": [], "limit": 50, "offset": 0},
    )
    assert credits.history() == []


def test_history_amount_sign_preserved(
    httpx_mock: HTTPXMock, credits: Credits
) -> None:
    """Debits are negative, credits/refunds are positive — sign must survive."""
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/credits/history?limit=50&offset=0",
        json={
            "entries": [
                _ledger_entry(id="debit", amount=-100, operation="sam3_per_minute"),
                _ledger_entry(id="refund", amount=80, operation="training_refund"),
                _ledger_entry(id="topup", amount=200, operation="monthly_reset"),
            ],
            "limit": 50,
            "offset": 0,
        },
    )
    entries = credits.history()
    by_id = {e.id: e for e in entries}
    assert by_id["debit"].amount == -100
    assert by_id["refund"].amount == 80
    assert by_id["topup"].amount == 200


# ───────────── iter ─────────────


def test_iter_paginates(httpx_mock: HTTPXMock, credits: Credits) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/api/v1/developer/credits/history?offset=0&limit=2",
        json={
            "entries": [_ledger_entry(id="l1"), _ledger_entry(id="l2")],
            "limit": 2,
            "offset": 0,
        },
    )
    httpx_mock.add_response(
        url=f"{BASE}/api/v1/developer/credits/history?offset=2&limit=2",
        json={"entries": [_ledger_entry(id="l3")], "limit": 2, "offset": 2},
    )
    entries = list(credits.iter(page_size=2))
    assert [e.id for e in entries] == ["l1", "l2", "l3"]


# ───────────── estimate ─────────────


def test_estimate_returns_typed_credit_estimate(
    httpx_mock: HTTPXMock, credits: Credits
) -> None:
    httpx_mock.add_response(
        method="GET",
        url=(
            f"{BASE}/api/v1/developer/credits/estimate"
            "?operation=training_a10g_per_minute&quantity=20"
        ),
        json={
            "operation": "training_a10g_per_minute",
            "credits_per_unit": 5,
            "unit": "minute",
            "quantity": 20,
            "total_credits": 100,
            "minimum": 0,
            "sufficient": True,
            "credits_remaining": 850,
        },
    )
    estimate = credits.estimate("training_a10g_per_minute", quantity=20)
    assert isinstance(estimate, CreditEstimate)
    assert estimate.total_credits == 100
    assert estimate.sufficient is True
    assert estimate.credits_remaining == 850


def test_estimate_default_quantity_is_one(
    httpx_mock: HTTPXMock, credits: Credits
) -> None:
    httpx_mock.add_response(
        method="GET",
        url=(
            f"{BASE}/api/v1/developer/credits/estimate"
            "?operation=image_generate_imagen_fast&quantity=1"
        ),
        json={
            "operation": "image_generate_imagen_fast",
            "credits_per_unit": 3,
            "unit": "image",
            "quantity": 1,
            "total_credits": 3,
            "minimum": 0,
            "sufficient": True,
            "credits_remaining": 100,
        },
    )
    credits.estimate("image_generate_imagen_fast")
    sent = httpx_mock.get_request()
    assert sent is not None
    assert "quantity=1" in str(sent.url)


def test_estimate_minimum_clamps_total(
    httpx_mock: HTTPXMock, credits: Credits
) -> None:
    """SAM3 has a 3-credit session minimum even when usage is shorter."""
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/credits/estimate?operation=sam3_per_minute&quantity=1",
        json={
            "operation": "sam3_per_minute",
            "credits_per_unit": 3,
            "unit": "minute",
            "quantity": 1,
            "total_credits": 3,
            "minimum": 3,
            "sufficient": True,
            "credits_remaining": 100,
        },
    )
    estimate = credits.estimate("sam3_per_minute", quantity=1)
    assert estimate.minimum == 3
    assert estimate.total_credits == 3


def test_estimate_insufficient_balance(
    httpx_mock: HTTPXMock, credits: Credits
) -> None:
    httpx_mock.add_response(
        method="GET",
        url=(
            f"{BASE}/api/v1/developer/credits/estimate"
            "?operation=training_h100_per_minute&quantity=60"
        ),
        json={
            "operation": "training_h100_per_minute",
            "credits_per_unit": 18,
            "unit": "minute",
            "quantity": 60,
            "total_credits": 1080,
            "minimum": 0,
            "sufficient": False,
            "credits_remaining": 50,
        },
    )
    estimate = credits.estimate("training_h100_per_minute", quantity=60)
    assert estimate.sufficient is False
    assert estimate.credits_remaining < estimate.total_credits


def test_estimate_400_unknown_operation(
    httpx_mock: HTTPXMock, credits: Credits
) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/credits/estimate?operation=bogus&quantity=1",
        status_code=400,
        json={"detail": "Unknown operation: bogus"},
    )
    with pytest.raises(ValidationError):
        credits.estimate("bogus")
