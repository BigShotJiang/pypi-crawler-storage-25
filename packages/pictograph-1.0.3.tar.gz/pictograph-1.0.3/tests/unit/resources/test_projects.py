"""Tests for ``pictograph.resources.projects.Projects``.

Coverage targets:
- ``list`` and ``iter`` — pagination + typed results.
- ``get`` happy + 404.
- ``create`` body serialization (defaults, ProjectClass instances vs dicts);
  errors: 409 conflict, 402 cap, 403 no-write-role, 400 invalid types.
- ``update`` body serialization (no_-update validation, partial updates);
  errors: 404 missing, 409 rename collision, 403 no-write-role.
- ``delete`` happy + 404 + 403.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

import pytest

from pictograph._http.transport import Transport
from pictograph._internal.config import ClientConfig
from pictograph.exceptions import (
    ConflictError,
    ForbiddenError,
    NotFoundError,
    PaymentRequiredError,
    ValidationError,
)
from pictograph.models.project import Project, ProjectClass
from pictograph.resources.projects import Projects

if TYPE_CHECKING:
    from pytest_httpx import HTTPXMock

BASE = "https://api.test.local"
KEY = "pk_live_test"


@pytest.fixture
def transport() -> Transport:
    config = ClientConfig(api_key=KEY, base_url=BASE, timeout=10.0, max_retries=0)  # type: ignore[arg-type]
    t = Transport(config, api_key=KEY)
    yield t
    t.close()


@pytest.fixture
def projects(transport: Transport) -> Projects:
    return Projects(transport)


def _project_payload(**overrides: Any) -> dict[str, Any]:
    base: dict[str, Any] = {
        "id": "proj-uuid-1",
        "organization_id": "org-uuid",
        "name": "road-signs",
        "description": "Road sign detection dataset",
        "annotation_types": ["bbox"],
        "classes": [
            {"name": "stop_sign", "type": "bbox", "color": "#e6194b"},
            {"name": "yield", "type": "bbox", "color": "#3cb44b"},
        ],
        "image_count": 250,
        "completed_image_count": 100,
        "total_size": 50000000,
        "archived_images": 5,
        "created_at": "2026-04-01T00:00:00Z",
        "updated_at": "2026-04-19T00:00:00Z",
    }
    base.update(overrides)
    return base


# ───────────── list / iter ─────────────


def test_list_returns_typed_projects(
    httpx_mock: HTTPXMock, projects: Projects
) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/projects/?limit=50&offset=0",
        json={
            "projects": [
                _project_payload(),
                _project_payload(id="p2", name="vehicles"),
            ],
            "pagination": {"limit": 50, "offset": 0},
        },
    )
    result = projects.list()
    assert len(result) == 2
    assert all(isinstance(p, Project) for p in result)
    assert {p.name for p in result} == {"road-signs", "vehicles"}


def test_list_pagination_params(
    httpx_mock: HTTPXMock, projects: Projects
) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/projects/?limit=10&offset=20",
        json={"projects": [], "pagination": {"limit": 10, "offset": 20}},
    )
    projects.list(limit=10, offset=20)


def test_iter_paginates(httpx_mock: HTTPXMock, projects: Projects) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/api/v1/developer/projects/?offset=0&limit=2",
        json={
            "projects": [
                _project_payload(id="p1"),
                _project_payload(id="p2"),
            ]
        },
    )
    httpx_mock.add_response(
        url=f"{BASE}/api/v1/developer/projects/?offset=2&limit=2",
        json={"projects": [_project_payload(id="p3")]},
    )
    out = list(projects.iter(page_size=2))
    assert [p.id for p in out] == ["p1", "p2", "p3"]


# ───────────── get ─────────────


def test_get_returns_typed_project(
    httpx_mock: HTTPXMock, projects: Projects
) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/projects/road-signs",
        json={"project": _project_payload()},
    )
    p = projects.get("road-signs")
    assert isinstance(p, Project)
    assert p.name == "road-signs"
    assert len(p.classes) == 2


def test_get_404(httpx_mock: HTTPXMock, projects: Projects) -> None:
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE}/api/v1/developer/projects/missing",
        status_code=404,
        json={"detail": "Project 'missing' not found"},
    )
    with pytest.raises(NotFoundError):
        projects.get("missing")


# ───────────── create ─────────────


def test_create_minimal_body(
    httpx_mock: HTTPXMock, projects: Projects
) -> None:
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/api/v1/developer/projects/",
        json={"project": _project_payload(name="new-project", classes=[])},
    )
    projects.create("new-project")
    sent = httpx_mock.get_request()
    assert sent is not None
    body = json.loads(sent.read())
    assert body == {"name": "new-project"}


def test_create_full_body_with_pydantic_classes(
    httpx_mock: HTTPXMock, projects: Projects
) -> None:
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/api/v1/developer/projects/",
        json={"project": _project_payload(name="vehicles")},
    )
    classes = [
        ProjectClass(name="car", type="bbox", color="#4363d8"),
        ProjectClass(name="truck", type="bbox", color="#f58231"),
    ]
    projects.create(
        "vehicles",
        description="Vehicle dataset",
        annotation_types=["bbox", "polygon"],
        classes=classes,
    )
    body = json.loads(httpx_mock.get_request().read())  # type: ignore[union-attr]
    assert body["name"] == "vehicles"
    assert body["description"] == "Vehicle dataset"
    assert body["annotation_types"] == ["bbox", "polygon"]
    assert body["classes"] == [
        {"name": "car", "type": "bbox", "color": "#4363d8"},
        {"name": "truck", "type": "bbox", "color": "#f58231"},
    ]


def test_create_accepts_raw_dict_classes(
    httpx_mock: HTTPXMock, projects: Projects
) -> None:
    """ProjectClass instances and dicts are interchangeable on input."""
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/api/v1/developer/projects/",
        json={"project": _project_payload()},
    )
    projects.create(
        "x",
        classes=[{"name": "person", "type": "bbox", "color": "#911eb4"}],
    )
    body = json.loads(httpx_mock.get_request().read())  # type: ignore[union-attr]
    assert body["classes"] == [
        {"name": "person", "type": "bbox", "color": "#911eb4"}
    ]


def test_create_409_duplicate_name(
    httpx_mock: HTTPXMock, projects: Projects
) -> None:
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/api/v1/developer/projects/",
        status_code=409,
        json={"detail": "A project named 'dup' already exists in this organization."},
    )
    with pytest.raises(ConflictError):
        projects.create("dup")


def test_create_402_cap_exceeded(
    httpx_mock: HTTPXMock, projects: Projects
) -> None:
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/api/v1/developer/projects/",
        status_code=402,
        json={
            "detail": {
                "error": "limit_exceeded",
                "limit_type": "projects",
                "current": 5,
                "limit": 5,
                "upgrade_url": "/settings?tab=billing",
            }
        },
    )
    with pytest.raises(PaymentRequiredError) as exc:
        projects.create("over-cap")
    assert exc.value.upgrade_url == "/settings?tab=billing"


def test_create_403_no_write_role(
    httpx_mock: HTTPXMock, projects: Projects
) -> None:
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/api/v1/developer/projects/",
        status_code=403,
        json={"detail": "Insufficient permissions to modify projects."},
    )
    with pytest.raises(ForbiddenError):
        projects.create("any")


def test_create_400_invalid_annotation_types(
    httpx_mock: HTTPXMock, projects: Projects
) -> None:
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/api/v1/developer/projects/",
        status_code=400,
        json={
            "detail": (
                "Unknown annotation_types: ['mask']. "
                "Allowed: ['bbox', 'box', 'keypoint', 'polygon', 'polyline']"
            )
        },
    )
    with pytest.raises(ValidationError, match="Unknown annotation_types"):
        projects.create("x", annotation_types=["mask"])


# ───────────── update ─────────────


def test_update_partial_body(httpx_mock: HTTPXMock, projects: Projects) -> None:
    httpx_mock.add_response(
        method="PATCH",
        url=f"{BASE}/api/v1/developer/projects/road-signs",
        json={"project": _project_payload(description="Updated description")},
    )
    projects.update("road-signs", description="Updated description")
    body = json.loads(httpx_mock.get_request().read())  # type: ignore[union-attr]
    assert body == {"description": "Updated description"}


def test_update_rename_uses_new_name_key(
    httpx_mock: HTTPXMock, projects: Projects
) -> None:
    """``new_name`` kwarg maps to backend's ``name`` body field."""
    httpx_mock.add_response(
        method="PATCH",
        url=f"{BASE}/api/v1/developer/projects/old-name",
        json={"project": _project_payload(name="new-name")},
    )
    projects.update("old-name", new_name="new-name")
    body = json.loads(httpx_mock.get_request().read())  # type: ignore[union-attr]
    assert body == {"name": "new-name"}


def test_update_full_body(httpx_mock: HTTPXMock, projects: Projects) -> None:
    httpx_mock.add_response(
        method="PATCH",
        url=f"{BASE}/api/v1/developer/projects/road-signs",
        json={"project": _project_payload()},
    )
    projects.update(
        "road-signs",
        new_name="signs-v2",
        description="v2",
        annotation_types=["polygon"],
        classes=[ProjectClass(name="signal", type="polygon", color="#42d4f4")],
    )
    body = json.loads(httpx_mock.get_request().read())  # type: ignore[union-attr]
    assert body["name"] == "signs-v2"
    assert body["description"] == "v2"
    assert body["annotation_types"] == ["polygon"]
    assert body["classes"] == [
        {"name": "signal", "type": "polygon", "color": "#42d4f4"}
    ]


def test_update_requires_at_least_one_field(projects: Projects) -> None:
    """Empty update is a programmer error — fail fast client-side."""
    with pytest.raises(ValueError, match="At least one of"):
        projects.update("road-signs")


def test_update_404_missing(httpx_mock: HTTPXMock, projects: Projects) -> None:
    httpx_mock.add_response(
        method="PATCH",
        url=f"{BASE}/api/v1/developer/projects/missing",
        status_code=404,
        json={"detail": "Project 'missing' not found"},
    )
    with pytest.raises(NotFoundError):
        projects.update("missing", description="x")


def test_update_409_rename_collision(
    httpx_mock: HTTPXMock, projects: Projects
) -> None:
    httpx_mock.add_response(
        method="PATCH",
        url=f"{BASE}/api/v1/developer/projects/old",
        status_code=409,
        json={"detail": "A project named 'taken' already exists in this organization."},
    )
    with pytest.raises(ConflictError):
        projects.update("old", new_name="taken")


def test_update_403_no_write_role(
    httpx_mock: HTTPXMock, projects: Projects
) -> None:
    httpx_mock.add_response(
        method="PATCH",
        url=f"{BASE}/api/v1/developer/projects/road-signs",
        status_code=403,
        json={"detail": "Insufficient permissions to modify projects."},
    )
    with pytest.raises(ForbiddenError):
        projects.update("road-signs", description="x")


# ───────────── delete ─────────────


def test_delete_returns_summary(
    httpx_mock: HTTPXMock, projects: Projects
) -> None:
    httpx_mock.add_response(
        method="DELETE",
        url=f"{BASE}/api/v1/developer/projects/road-signs",
        json={
            "success": True,
            "deleted": {
                "project_id": "proj-uuid-1",
                "images": 250,
                "folders": 5,
                "gcs_blobs": 250,
            },
        },
    )
    summary = projects.delete("road-signs")
    assert summary == {
        "project_id": "proj-uuid-1",
        "images": 250,
        "folders": 5,
        "gcs_blobs": 250,
    }


def test_delete_404(httpx_mock: HTTPXMock, projects: Projects) -> None:
    httpx_mock.add_response(
        method="DELETE",
        url=f"{BASE}/api/v1/developer/projects/missing",
        status_code=404,
        json={"detail": "Project 'missing' not found"},
    )
    with pytest.raises(NotFoundError):
        projects.delete("missing")


def test_delete_403_member_role(
    httpx_mock: HTTPXMock, projects: Projects
) -> None:
    """Members can create/update but not delete — admin/owner only."""
    httpx_mock.add_response(
        method="DELETE",
        url=f"{BASE}/api/v1/developer/projects/road-signs",
        status_code=403,
        json={"detail": "Only admin or owner roles can delete projects."},
    )
    with pytest.raises(ForbiddenError):
        projects.delete("road-signs")
