"""Tests for ``pictograph.workflows.pipeline.full_pipeline``.

The full pipeline chains upload → annotate → train. We mock the
sub-workflow functions at the import site (since pipeline.py imports
them directly) and verify orchestration: phase ordering, short-circuit
on failure, and the assembled PipelineReport.
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from pictograph.models.credit import CreditBalance
from pictograph.models.model import Model
from pictograph.models.training import TrainingRun
from pictograph.workflows.annotate import AnnotateReport
from pictograph.workflows.pipeline import PipelineReport, full_pipeline
from pictograph.workflows.upload import UploadFailure, UploadReport


def _ok_balance(remaining: int = 1000) -> CreditBalance:
    return CreditBalance(
        credits_remaining=remaining,
        credits_monthly_allowance=10000,
        credits_reset_at=None,
        recent_history=[],
    )


def _ok_upload_report() -> UploadReport:
    return UploadReport(
        dataset_name="test-dataset",
        images_attempted=4,
        images_uploaded=4,
        images_skipped=0,
        failures=[],
    )


def _failed_upload_report() -> UploadReport:
    return UploadReport(
        dataset_name="test-dataset",
        images_attempted=4,
        images_uploaded=0,
        images_skipped=0,
        failures=[
            UploadFailure(path=Path("a.jpg"), reason="boom"),
        ],
    )


def _ok_annotate_report() -> AnnotateReport:
    return AnnotateReport(
        dataset_name="test-dataset",
        images_attempted=4,
        images_processed=4,
        annotations_added=8,
        job_id="job-uuid",
    )


def _failed_annotate_report() -> AnnotateReport:
    return AnnotateReport(
        dataset_name="test-dataset",
        images_attempted=4,
        images_processed=0,
        annotations_added=0,
        job_id=None,
    )


def _ok_training_run() -> TrainingRun:
    return TrainingRun(
        id="run-uuid",
        organization_id="org-uuid",
        name="run",
        dataset_id="proj-uuid",
        export_id="export-uuid",
        model_id="model-uuid",
        pipeline_type="yolox",
        gpu_type="a10g",
        status="completed",
        progress=100,
        current_epoch=10,
        total_epochs=10,
        metrics={},
        config={},
        eta_seconds=None,
        training_time_seconds=60,
        error_message=None,
        started_at=datetime.now(timezone.utc),
        completed_at=datetime.now(timezone.utc),
        created_at=datetime.now(timezone.utc),
        created_by=None,
    )


def _ok_model() -> Model:
    return Model(
        id="model-uuid",
        organization_id="org-uuid",
        name="Swift Falcon",
        description=None,
        model_type="object_detection",
        architecture="yolox-s",
        visibility="private",
        status="ready",
        metrics={},
        class_mapping={},
        version="1.0.0",
        parent_model_id=None,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )


@pytest.fixture
def folder(tmp_path: Path) -> Path:
    """Empty folder — sub-workflows are mocked, so contents don't matter."""
    return tmp_path


# ───────────── happy path ─────────────


def test_full_pipeline_chains_all_three_phases(folder: Path) -> None:
    """upload → annotate → train each fire once and the report is fully populated."""
    client = MagicMock()
    client.credits.balance.return_value = _ok_balance()
    with (
        patch(
            "pictograph.workflows.pipeline.upload_dataset_from_folder",
            return_value=_ok_upload_report(),
        ) as mock_upload,
        patch(
            "pictograph.workflows.pipeline.auto_annotate_dataset",
            return_value=_ok_annotate_report(),
        ) as mock_annotate,
        patch(
            "pictograph.workflows.pipeline.train_pipeline",
            return_value=(_ok_training_run(), _ok_model()),
        ) as mock_train,
    ):
        report = full_pipeline(
            client,
            dataset_name="test-dataset",
            folder=folder,
            classes=[("car", "polygon")],
            pipeline="yolox",
        )
    mock_upload.assert_called_once()
    mock_annotate.assert_called_once()
    mock_train.assert_called_once()

    assert isinstance(report, PipelineReport)
    assert report.dataset_name == "test-dataset"
    assert report.upload.success
    assert report.annotate is not None
    assert report.annotate.success
    assert report.training_run is not None
    assert report.training_run.status == "completed"
    assert report.model is not None
    assert report.success


# ───────────── short-circuiting ─────────────


def test_full_pipeline_short_circuits_on_upload_failure(folder: Path) -> None:
    """Failed upload → annotate + train skipped."""
    client = MagicMock()
    client.credits.balance.return_value = _ok_balance()
    with (
        patch(
            "pictograph.workflows.pipeline.upload_dataset_from_folder",
            return_value=_failed_upload_report(),
        ),
        patch(
            "pictograph.workflows.pipeline.auto_annotate_dataset"
        ) as mock_annotate,
        patch(
            "pictograph.workflows.pipeline.train_pipeline"
        ) as mock_train,
    ):
        report = full_pipeline(
            client,
            dataset_name="test-dataset",
            folder=folder,
            classes=[("car", "polygon")],
            pipeline="yolox",
        )
    mock_annotate.assert_not_called()
    mock_train.assert_not_called()
    assert not report.upload.success
    assert report.annotate is None
    assert report.training_run is None
    assert report.model is None
    assert not report.success


def test_full_pipeline_short_circuits_on_annotate_failure(folder: Path) -> None:
    """Failed annotate → train skipped."""
    client = MagicMock()
    client.credits.balance.return_value = _ok_balance()
    with (
        patch(
            "pictograph.workflows.pipeline.upload_dataset_from_folder",
            return_value=_ok_upload_report(),
        ),
        patch(
            "pictograph.workflows.pipeline.auto_annotate_dataset",
            return_value=_failed_annotate_report(),
        ),
        patch(
            "pictograph.workflows.pipeline.train_pipeline"
        ) as mock_train,
    ):
        report = full_pipeline(
            client,
            dataset_name="test-dataset",
            folder=folder,
            classes=[("car", "polygon")],
            pipeline="yolox",
        )
    mock_train.assert_not_called()
    assert report.upload.success
    assert report.annotate is not None
    assert not report.annotate.success
    assert report.training_run is None
    assert not report.success


# ───────────── opt-out flags ─────────────


def test_full_pipeline_annotate_false_skips_annotate(folder: Path) -> None:
    client = MagicMock()
    client.credits.balance.return_value = _ok_balance()
    with (
        patch(
            "pictograph.workflows.pipeline.upload_dataset_from_folder",
            return_value=_ok_upload_report(),
        ),
        patch(
            "pictograph.workflows.pipeline.auto_annotate_dataset"
        ) as mock_annotate,
        patch(
            "pictograph.workflows.pipeline.train_pipeline",
            return_value=(_ok_training_run(), _ok_model()),
        ) as mock_train,
    ):
        report = full_pipeline(
            client,
            dataset_name="test-dataset",
            folder=folder,
            classes=[("car", "polygon")],
            pipeline="yolox",
            annotate=False,
        )
    mock_annotate.assert_not_called()
    mock_train.assert_called_once()
    assert report.annotate is None
    assert report.training_run is not None
    assert report.success


def test_full_pipeline_train_false_skips_training(folder: Path) -> None:
    client = MagicMock()
    client.credits.balance.return_value = _ok_balance()
    with (
        patch(
            "pictograph.workflows.pipeline.upload_dataset_from_folder",
            return_value=_ok_upload_report(),
        ),
        patch(
            "pictograph.workflows.pipeline.auto_annotate_dataset",
            return_value=_ok_annotate_report(),
        ),
        patch(
            "pictograph.workflows.pipeline.train_pipeline"
        ) as mock_train,
    ):
        report = full_pipeline(
            client,
            dataset_name="test-dataset",
            folder=folder,
            classes=[("car", "polygon")],
            pipeline="yolox",
            train=False,
        )
    mock_train.assert_not_called()
    assert report.training_run is None
    assert report.model is None
    assert report.success  # upload + annotate succeeded; no training expected


# ───────────── parameter passthrough ─────────────


def test_full_pipeline_passes_kwargs_to_phases(folder: Path) -> None:
    """upload_workers, annotate_mode, train_config, train_timeout, gpu plumb through."""
    client = MagicMock()
    client.credits.balance.return_value = _ok_balance()
    with (
        patch(
            "pictograph.workflows.pipeline.upload_dataset_from_folder",
            return_value=_ok_upload_report(),
        ) as mock_upload,
        patch(
            "pictograph.workflows.pipeline.auto_annotate_dataset",
            return_value=_ok_annotate_report(),
        ) as mock_annotate,
        patch(
            "pictograph.workflows.pipeline.train_pipeline",
            return_value=(_ok_training_run(), _ok_model()),
        ) as mock_train,
    ):
        full_pipeline(
            client,
            dataset_name="test-dataset",
            folder=folder,
            classes=[("car", "polygon")],
            pipeline="yolox",
            gpu="a100",
            annotate_mode="text",
            upload_workers=16,
            train_config={"epochs": 100},
            train_timeout=3600.0,
        )
    upload_kwargs = mock_upload.call_args.kwargs
    annotate_kwargs = mock_annotate.call_args.kwargs
    train_kwargs = mock_train.call_args.kwargs

    assert upload_kwargs["max_workers"] == 16
    assert upload_kwargs["organize_by_class"] is True
    assert upload_kwargs["create_if_missing"] is True
    assert annotate_kwargs["mode"] == "text"
    assert train_kwargs["gpu"] == "a100"
    assert train_kwargs["pipeline"] == "yolox"
    assert train_kwargs["config"] == {"epochs": 100}
    assert train_kwargs["timeout"] == 3600.0


# ───────────── credit gating ─────────────


def test_full_pipeline_skips_paid_phases_on_low_balance(folder: Path) -> None:
    """Balance < min_credits → annotate + train skipped, reason recorded."""
    client = MagicMock()
    client.credits.balance.return_value = _ok_balance(remaining=0)
    with (
        patch(
            "pictograph.workflows.pipeline.upload_dataset_from_folder",
            return_value=_ok_upload_report(),
        ),
        patch(
            "pictograph.workflows.pipeline.auto_annotate_dataset"
        ) as mock_annotate,
        patch(
            "pictograph.workflows.pipeline.train_pipeline"
        ) as mock_train,
    ):
        report = full_pipeline(
            client,
            dataset_name="test-dataset",
            folder=folder,
            classes=[("car", "polygon")],
            pipeline="yolox",
        )
    mock_annotate.assert_not_called()
    mock_train.assert_not_called()
    assert report.credit_skip_reason is not None
    assert "Insufficient credits" in report.credit_skip_reason
    assert not report.success


def test_full_pipeline_min_credits_none_disables_check(folder: Path) -> None:
    """``min_credits=None`` skips the balance check entirely."""
    client = MagicMock()
    # Even with zero balance, min_credits=None means we don't check.
    with (
        patch(
            "pictograph.workflows.pipeline.upload_dataset_from_folder",
            return_value=_ok_upload_report(),
        ),
        patch(
            "pictograph.workflows.pipeline.auto_annotate_dataset",
            return_value=_ok_annotate_report(),
        ),
        patch(
            "pictograph.workflows.pipeline.train_pipeline",
            return_value=(_ok_training_run(), _ok_model()),
        ),
    ):
        report = full_pipeline(
            client,
            dataset_name="test-dataset",
            folder=folder,
            classes=[("car", "polygon")],
            pipeline="yolox",
            min_credits=None,
        )
    client.credits.balance.assert_not_called()
    assert report.credit_skip_reason is None
    assert report.success


def test_full_pipeline_skips_credit_check_when_no_paid_phases(folder: Path) -> None:
    """annotate=False AND train=False → no balance check needed."""
    client = MagicMock()
    with (
        patch(
            "pictograph.workflows.pipeline.upload_dataset_from_folder",
            return_value=_ok_upload_report(),
        ),
    ):
        full_pipeline(
            client,
            dataset_name="test-dataset",
            folder=folder,
            classes=[("car", "polygon")],
            pipeline="yolox",
            annotate=False,
            train=False,
        )
    client.credits.balance.assert_not_called()


# ───────────── PipelineReport.success edge cases ─────────────


def test_pipeline_report_success_when_training_failed(folder: Path) -> None:
    """training_run.status != 'completed' → report.success is False."""
    failed_run = _ok_training_run()
    failed_run.status = "failed"  # type: ignore[assignment]

    client = MagicMock()
    client.credits.balance.return_value = _ok_balance()
    with (
        patch(
            "pictograph.workflows.pipeline.upload_dataset_from_folder",
            return_value=_ok_upload_report(),
        ),
        patch(
            "pictograph.workflows.pipeline.auto_annotate_dataset",
            return_value=_ok_annotate_report(),
        ),
        patch(
            "pictograph.workflows.pipeline.train_pipeline",
            return_value=(failed_run, None),
        ),
    ):
        report = full_pipeline(
            client,
            dataset_name="test-dataset",
            folder=folder,
            classes=[("car", "polygon")],
            pipeline="yolox",
        )
    assert not report.success
