"""Tests for ``pictograph.workflows.upload.upload_dataset_from_folder``.

The workflow is an orchestrator over Client resources. We mock the
Client's resource methods directly (via ``unittest.mock``) since the
underlying HTTP behavior is exhaustively covered in the resource tests
— we don't want to re-test that here. The workflow tests focus on
orchestration: directory walking, virtual-folder mapping, parallel
upload behavior, conflict handling, and the failure report shape.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest

from pictograph.exceptions import ApiError, ConflictError, NotFoundError
from pictograph.models.project import Project, ProjectClass
from pictograph.workflows.upload import (
    UploadFailure,
    UploadReport,
    upload_dataset_from_folder,
)


def _make_project(name: str = "test-dataset") -> Project:
    """Minimal valid Project for mock returns."""
    return Project(
        id="proj-uuid-1",
        organization_id="org-uuid",
        name=name,
        description=None,
        annotation_types=["bbox"],
        classes=[],
        image_count=0,
        completed_image_count=0,
        total_size=0,
        archived_images=0,
        created_at="2026-04-19T00:00:00Z",  # type: ignore[arg-type]
    )


@pytest.fixture
def populated_folder(tmp_path: Path) -> Path:
    """Folder with two class subdirectories + a root-level image."""
    (tmp_path / "cars").mkdir()
    (tmp_path / "cars" / "car1.jpg").write_bytes(b"\xff\xd8\xff" + b"x" * 100)
    (tmp_path / "cars" / "car2.png").write_bytes(b"\x89PNG" + b"y" * 100)
    (tmp_path / "trucks").mkdir()
    (tmp_path / "trucks" / "truck1.jpg").write_bytes(b"\xff\xd8\xff" + b"z" * 100)
    (tmp_path / "root_image.jpg").write_bytes(b"\xff\xd8\xff" + b"a" * 100)
    # Non-image file should be ignored.
    (tmp_path / "notes.txt").write_text("not an image")
    return tmp_path


def _ok_client(project: Project | None = None) -> MagicMock:
    """Client mock where projects.get returns the dataset and uploads succeed."""
    client = MagicMock()
    client.projects.get.return_value = project or _make_project()
    client.images.upload.return_value = MagicMock(id="img-uuid")
    return client


# ───────────── happy paths ─────────────


def test_upload_walks_directory_and_maps_class_folders(
    populated_folder: Path,
) -> None:
    """First-level subdirectory becomes the virtual_folder_path; root files land at /."""
    client = _ok_client()
    report = upload_dataset_from_folder(
        client, "test-dataset", populated_folder,
        organize_by_class=True, parallel=False,
    )
    assert isinstance(report, UploadReport)
    assert report.images_attempted == 4
    assert report.images_uploaded == 4
    assert report.success

    # Check folder mapping in upload calls.
    call_kwargs = [c.kwargs for c in client.images.upload.call_args_list]
    folders_by_filename = {
        Path(kw["file_path"]).name: kw["folder_path"] for kw in call_kwargs
    }
    assert folders_by_filename["car1.jpg"] == "/cars"
    assert folders_by_filename["car2.png"] == "/cars"
    assert folders_by_filename["truck1.jpg"] == "/trucks"
    assert folders_by_filename["root_image.jpg"] == "/"


def test_upload_organize_by_class_false_flattens(populated_folder: Path) -> None:
    """All files land at root when organize_by_class=False."""
    client = _ok_client()
    upload_dataset_from_folder(
        client, "test-dataset", populated_folder,
        organize_by_class=False, parallel=False,
    )
    folders = {c.kwargs["folder_path"] for c in client.images.upload.call_args_list}
    assert folders == {"/"}


def test_upload_skips_non_image_files(populated_folder: Path) -> None:
    """Files outside the supported extension list are not uploaded."""
    client = _ok_client()
    report = upload_dataset_from_folder(
        client, "test-dataset", populated_folder, parallel=False
    )
    # 4 images, the .txt is skipped.
    assert report.images_attempted == 4
    assert client.images.upload.call_count == 4


# ───────────── parallelism ─────────────


def test_upload_parallel_pool_size(populated_folder: Path) -> None:
    """parallel=True with explicit max_workers fans out via thread pool."""
    client = _ok_client()
    report = upload_dataset_from_folder(
        client, "test-dataset", populated_folder,
        parallel=True, max_workers=4,
    )
    assert report.images_uploaded == 4
    assert client.images.upload.call_count == 4


# ───────────── dataset creation ─────────────


def test_upload_creates_dataset_when_missing(tmp_path: Path) -> None:
    """If projects.get() raises NotFoundError, projects.create() is called."""
    (tmp_path / "img.jpg").write_bytes(b"\xff\xd8\xff" + b"x" * 100)
    client = MagicMock()
    client.projects.get.side_effect = NotFoundError("Project 'new' not found")
    client.projects.create.return_value = _make_project("new")
    client.images.upload.return_value = MagicMock(id="img-uuid")

    upload_dataset_from_folder(client, "new", tmp_path, parallel=False)
    client.projects.create.assert_called_once_with("new")


def test_upload_raises_when_missing_and_create_disabled(tmp_path: Path) -> None:
    """create_if_missing=False propagates the NotFoundError."""
    (tmp_path / "img.jpg").write_bytes(b"\xff\xd8\xff" + b"x" * 100)
    client = MagicMock()
    client.projects.get.side_effect = NotFoundError("missing")

    with pytest.raises(NotFoundError):
        upload_dataset_from_folder(
            client, "missing", tmp_path, create_if_missing=False
        )


# ───────────── failure handling ─────────────


def test_upload_conflict_skipped_by_default(tmp_path: Path) -> None:
    """ConflictError is reported as 'skipped' when skip_existing=True (default)."""
    (tmp_path / "a.jpg").write_bytes(b"\xff\xd8\xff" + b"x" * 100)
    (tmp_path / "b.jpg").write_bytes(b"\xff\xd8\xff" + b"y" * 100)
    client = _ok_client()
    client.images.upload.side_effect = [
        ConflictError("a.jpg already exists"),
        MagicMock(id="img-b"),
    ]
    report = upload_dataset_from_folder(
        client, "test-dataset", tmp_path, parallel=False
    )
    assert report.images_uploaded == 1
    assert report.images_skipped == 1
    assert report.failures == []
    assert report.success  # at least one succeeded, no hard failures


def test_upload_conflict_recorded_as_failure_when_skip_disabled(
    tmp_path: Path,
) -> None:
    (tmp_path / "a.jpg").write_bytes(b"\xff\xd8\xff" + b"x" * 100)
    client = _ok_client()
    client.images.upload.side_effect = ConflictError("a.jpg already exists")

    report = upload_dataset_from_folder(
        client, "test-dataset", tmp_path,
        parallel=False, skip_existing=False,
    )
    assert report.images_uploaded == 0
    assert len(report.failures) == 1
    assert isinstance(report.failures[0], UploadFailure)
    assert "conflict" in report.failures[0].reason


def test_upload_api_error_recorded_as_failure(tmp_path: Path) -> None:
    """Generic ApiError on a single image lands in failures, not raised."""
    (tmp_path / "a.jpg").write_bytes(b"\xff\xd8\xff" + b"x" * 100)
    (tmp_path / "b.jpg").write_bytes(b"\xff\xd8\xff" + b"y" * 100)
    client = _ok_client()
    client.images.upload.side_effect = [
        ApiError("upload exploded"),
        MagicMock(id="img-b"),
    ]
    report = upload_dataset_from_folder(
        client, "test-dataset", tmp_path, parallel=False
    )
    assert report.images_uploaded == 1
    assert len(report.failures) == 1
    assert "upload exploded" in report.failures[0].reason


# ───────────── input validation ─────────────


def test_upload_raises_on_missing_folder(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        upload_dataset_from_folder(
            MagicMock(), "x", tmp_path / "does-not-exist"
        )


def test_upload_empty_folder_returns_empty_report(tmp_path: Path) -> None:
    client = _ok_client()
    report = upload_dataset_from_folder(client, "test-dataset", tmp_path)
    assert report.images_attempted == 0
    assert report.images_uploaded == 0
    assert report.failures == []
    # Don't claim success on empty input — there's nothing to succeed at.
    assert not report.success


# Suppress unused-import warning for the auxiliary class — used for type
# checking in the test fixtures only.
_ = ProjectClass
