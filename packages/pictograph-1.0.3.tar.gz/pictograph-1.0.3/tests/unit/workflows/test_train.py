"""Tests for ``pictograph.workflows.train.train_pipeline``.

The workflow is an orchestrator over Client resources. We mock the
Client's resource methods directly (via ``unittest.mock``) since the
underlying HTTP behavior is exhaustively covered in the resource tests
— we don't want to re-test that here. The workflow tests focus on
orchestration: export creation, training kick-off, the wait/no-wait
branch, and the model-fetch step on completion.
"""

from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import MagicMock

from pictograph.models.model import Model
from pictograph.models.training import TrainingRun
from pictograph.workflows.train import train_pipeline


def _ok_training_run(
    *,
    status: str = "completed",
    model_id: str | None = "model-uuid-1",
    name: str = "yolox-run-20260419-000000",
) -> TrainingRun:
    return TrainingRun(
        id="run-uuid-1",
        organization_id="org-uuid",
        name=name,
        dataset_id="proj-uuid-1",
        export_id="export-uuid-1",
        model_id=model_id,
        pipeline_type="yolox",
        gpu_type="a10g",
        status=status,  # type: ignore[arg-type]
        progress=100 if status == "completed" else 50,
        current_epoch=10,
        total_epochs=10,
        metrics={"mAP": 0.85},
        config={},
        eta_seconds=None,
        training_time_seconds=120,
        error_message=None,
        started_at=datetime.now(timezone.utc),
        completed_at=datetime.now(timezone.utc),
        created_at=datetime.now(timezone.utc),
        created_by=None,
    )


def _ok_model() -> Model:
    return Model(
        id="model-uuid-1",
        organization_id="org-uuid",
        name="Swift Falcon",
        description=None,
        model_type="object_detection",
        architecture="yolox-s",
        visibility="private",
        status="ready",
        metrics={"mAP": 0.85},
        class_mapping={"0": "car"},
        version="1.0.0",
        parent_model_id=None,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )


# ───────────── happy path (wait=True) ─────────────


def test_train_pipeline_chains_export_train_model() -> None:
    """All three resource methods called in order; tuple (run, model) returned."""
    client = MagicMock()
    client.training.create.return_value = _ok_training_run()
    client.models.get.return_value = _ok_model()

    run, model = train_pipeline(
        client, "test-dataset", pipeline="yolox"
    )
    client.exports.create.assert_called_once()
    client.training.create.assert_called_once()
    client.models.get.assert_called_once_with("model-uuid-1")
    assert isinstance(run, TrainingRun)
    assert isinstance(model, Model)
    assert run.status == "completed"
    assert model.id == "model-uuid-1"


def test_train_pipeline_auto_generates_export_and_run_names() -> None:
    """Without explicit names, both export_name and run name are timestamped."""
    client = MagicMock()
    client.training.create.return_value = _ok_training_run()
    client.models.get.return_value = _ok_model()

    train_pipeline(client, "test-dataset", pipeline="yolox")

    export_args = client.exports.create.call_args
    train_args = client.training.create.call_args

    auto_export_name = export_args.args[1]
    auto_run_name = train_args.kwargs["name"]
    assert auto_export_name.startswith("yolox-")
    assert auto_run_name.startswith("yolox-run-")
    # Same export name flows into training.
    assert train_args.args[1] == auto_export_name


def test_train_pipeline_respects_explicit_names() -> None:
    client = MagicMock()
    client.training.create.return_value = _ok_training_run(name="my-run")
    client.models.get.return_value = _ok_model()

    train_pipeline(
        client,
        "test-dataset",
        pipeline="yolox",
        name="my-run",
        export_name="my-export",
    )
    assert client.exports.create.call_args.args[1] == "my-export"
    assert client.training.create.call_args.args[1] == "my-export"
    assert client.training.create.call_args.kwargs["name"] == "my-run"


def test_train_pipeline_passes_class_filter_and_status_filter() -> None:
    """Export creation forwards class_filter and status_filter."""
    client = MagicMock()
    client.training.create.return_value = _ok_training_run()
    client.models.get.return_value = _ok_model()

    train_pipeline(
        client,
        "test-dataset",
        pipeline="yolox",
        class_filter=["car", "truck"],
        status_filter="all",
    )
    kwargs = client.exports.create.call_args.kwargs
    assert kwargs["class_filter"] == ["car", "truck"]
    assert kwargs["status_filter"] == "all"
    assert kwargs["format"] == "pictograph"
    assert kwargs["include_images"] is True
    assert kwargs["wait"] is True


def test_train_pipeline_passes_gpu_and_config() -> None:
    """gpu_type and config dict reach the training resource."""
    client = MagicMock()
    client.training.create.return_value = _ok_training_run()
    client.models.get.return_value = _ok_model()

    train_pipeline(
        client,
        "test-dataset",
        pipeline="yolox",
        gpu="a100",
        config={"epochs": 50, "batch_size": 16},
    )
    kwargs = client.training.create.call_args.kwargs
    assert kwargs["gpu_type"] == "a100"
    assert kwargs["pipeline_type"] == "yolox"
    assert kwargs["config"] == {"epochs": 50, "batch_size": 16}


def test_train_pipeline_passes_poll_settings() -> None:
    client = MagicMock()
    client.training.create.return_value = _ok_training_run()
    client.models.get.return_value = _ok_model()

    train_pipeline(
        client,
        "test-dataset",
        pipeline="yolox",
        poll_interval=10.0,
        timeout=3600.0,
    )
    kwargs = client.training.create.call_args.kwargs
    assert kwargs["poll_interval"] == 10.0
    assert kwargs["timeout"] == 3600.0
    assert kwargs["wait"] is True


# ───────────── wait=False ─────────────


def test_train_pipeline_no_wait_skips_model_fetch() -> None:
    """wait=False → second tuple element is None, no models.get()."""
    client = MagicMock()
    client.training.create.return_value = _ok_training_run(status="queued")

    run, model = train_pipeline(
        client, "test-dataset", pipeline="yolox", wait=False
    )
    assert run.status == "queued"
    assert model is None
    client.models.get.assert_not_called()
    assert client.training.create.call_args.kwargs["wait"] is False


# ───────────── failure modes ─────────────


def test_train_pipeline_skips_model_fetch_on_failure() -> None:
    """status='failed' → no model fetch, model is None."""
    client = MagicMock()
    client.training.create.return_value = _ok_training_run(
        status="failed", model_id=None
    )

    run, model = train_pipeline(client, "test-dataset", pipeline="yolox")
    assert run.status == "failed"
    assert model is None
    client.models.get.assert_not_called()


def test_train_pipeline_skips_model_fetch_when_model_id_missing() -> None:
    """status='completed' but no model_id → defensive skip."""
    client = MagicMock()
    client.training.create.return_value = _ok_training_run(
        status="completed", model_id=None
    )

    _run, model = train_pipeline(client, "test-dataset", pipeline="yolox")
    assert model is None
    client.models.get.assert_not_called()
