"""Tests for ``pictograph.workflows.annotate.auto_annotate_dataset``.

The workflow is an orchestrator over Client resources. We mock the
Client's resource methods directly (via ``unittest.mock``) since the
underlying HTTP behavior is exhaustively covered in the resource tests
— we don't want to re-test that here. The workflow tests focus on
orchestration: class normalization, batch vs text mode, the overwrite
flag, the max_images cap, and per-image failure handling.
"""

from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import MagicMock

import pytest

from pictograph.exceptions import ApiError, NotFoundError
from pictograph.models.auto_annotate import BatchClass, BatchJob
from pictograph.models.dataset import Dataset, DatasetImage
from pictograph.workflows.annotate import (
    AnnotateReport,
    AnnotationFailure,
    auto_annotate_dataset,
)


def _make_image(
    image_id: str,
    filename: str,
    annotation_count: int = 0,
) -> DatasetImage:
    return DatasetImage(
        id=image_id,
        filename=filename,
        status="new",  # type: ignore[arg-type]
        annotation_count=annotation_count,
        file_size=12345,
        width=640,
        height=480,
        image_url=None,
        thumbnail_url=None,
        annotation_url=None,
        created_at=datetime.now(timezone.utc),
    )


def _make_dataset(images: list[DatasetImage] | None = None) -> Dataset:
    return Dataset(
        id="proj-uuid-1",
        name="test-dataset",
        description=None,
        image_count=len(images or []),
        completed_image_count=0,
        total_size=0,
        archived_images=0,
        classes=[],
        images=images,
        created_at=datetime.now(timezone.utc),
    )


def _ok_batch_job(
    processed: int = 3, added: int = 6, failed: int = 0
) -> BatchJob:
    return BatchJob(
        job_id="job-uuid-1",
        status="completed",
        progress=100,
        total_images=processed + failed,
        processed_images=processed,
        total_annotations_added=added,
        failed_images=failed,
        error_message=None,
        estimated_credits=None,
        completed_at=datetime.now(timezone.utc),
    )


# ───────────── class normalization ─────────────


def test_annotate_normalizes_batchclass_tuple_dict() -> None:
    """All three class-spec forms (BatchClass / tuple / dict) work."""
    client = MagicMock()
    client.datasets.get.return_value = _make_dataset(
        images=[_make_image("img-1", "a.jpg")]
    )
    client.auto_annotate.batch.return_value = _ok_batch_job(
        processed=1, added=3
    )

    report = auto_annotate_dataset(
        client,
        "test-dataset",
        classes=[
            BatchClass(name="car", output_type="polygon"),
            ("person", "bbox"),
            {"name": "tree", "output_type": "polygon"},
        ],
    )
    assert report.success
    # Confirm canonical BatchClass list reached the resource.
    sent_classes = client.auto_annotate.batch.call_args.kwargs["classes"]
    assert all(isinstance(c, BatchClass) for c in sent_classes)
    assert {c.name for c in sent_classes} == {"car", "person", "tree"}


def test_annotate_rejects_unknown_class_spec() -> None:
    client = MagicMock()
    client.datasets.get.return_value = _make_dataset()
    with pytest.raises(ValueError, match="Unsupported class spec"):
        auto_annotate_dataset(client, "test-dataset", classes=[12345])  # type: ignore[list-item]


# ───────────── batch mode (default) ─────────────


def test_annotate_batch_mode_aggregates_job_outcome() -> None:
    """processed_images / total_annotations_added / job_id surface on the report."""
    client = MagicMock()
    client.datasets.get.return_value = _make_dataset(
        images=[
            _make_image("img-1", "a.jpg"),
            _make_image("img-2", "b.jpg"),
        ]
    )
    client.auto_annotate.batch.return_value = _ok_batch_job(
        processed=2, added=5
    )

    report = auto_annotate_dataset(
        client, "test-dataset", classes=[("car", "polygon")]
    )
    assert isinstance(report, AnnotateReport)
    assert report.images_attempted == 2
    assert report.images_processed == 2
    assert report.annotations_added == 5
    assert report.job_id == "job-uuid-1"
    assert report.success
    assert report.failures == []


def test_annotate_batch_mode_reports_partial_failures() -> None:
    """failed_images > 0 → batch failure recorded (workflow doesn't raise)."""
    client = MagicMock()
    client.datasets.get.return_value = _make_dataset(
        images=[_make_image("img-1", "a.jpg")]
    )
    client.auto_annotate.batch.return_value = _ok_batch_job(
        processed=4, added=4, failed=2
    )

    report = auto_annotate_dataset(
        client, "test-dataset", classes=[("car", "polygon")]
    )
    assert len(report.failures) == 1
    failure = report.failures[0]
    assert isinstance(failure, AnnotationFailure)
    assert failure.image_filename == "<batch>"
    assert "2 images failed" in failure.reason


def test_annotate_batch_mode_recovers_from_apierror() -> None:
    """ApiError on batch kicker → recorded as failure, not raised."""
    client = MagicMock()
    client.datasets.get.return_value = _make_dataset(
        images=[_make_image("img-1", "a.jpg")]
    )
    client.auto_annotate.batch.side_effect = ApiError("batch endpoint exploded")

    report = auto_annotate_dataset(
        client, "test-dataset", classes=[("car", "polygon")]
    )
    assert report.images_processed == 0
    assert len(report.failures) == 1
    assert "batch endpoint exploded" in report.failures[0].reason


def test_annotate_batch_passes_poll_settings() -> None:
    """poll_interval and timeout flow through to the batch resource."""
    client = MagicMock()
    client.datasets.get.return_value = _make_dataset(
        images=[_make_image("img-1", "a.jpg")]
    )
    client.auto_annotate.batch.return_value = _ok_batch_job(
        processed=1, added=1
    )

    auto_annotate_dataset(
        client,
        "test-dataset",
        classes=[("car", "polygon")],
        poll_interval=2.0,
        timeout=600.0,
    )
    kwargs = client.auto_annotate.batch.call_args.kwargs
    assert kwargs["poll_interval"] == 2.0
    assert kwargs["timeout"] == 600.0
    assert kwargs["wait"] is True


# ───────────── text mode ─────────────


def test_annotate_text_mode_calls_text_per_image_per_class() -> None:
    """One client.auto_annotate.text() call per (image × class) pair."""
    client = MagicMock()
    client.datasets.get.return_value = _make_dataset(
        images=[
            _make_image("img-1", "a.jpg"),
            _make_image("img-2", "b.jpg"),
        ]
    )
    text_result = MagicMock(status="success", annotations=[MagicMock()])
    client.auto_annotate.text.return_value = text_result
    client.annotations.save.return_value = MagicMock(
        previous_count=0, new_count=1
    )

    report = auto_annotate_dataset(
        client,
        "test-dataset",
        classes=[("car", "polygon"), ("truck", "bbox")],
        mode="text",
    )
    # 2 images x 2 classes = 4 text calls.
    assert client.auto_annotate.text.call_count == 4
    # Each successful text call triggers one save.
    assert client.annotations.save.call_count == 4
    assert report.images_processed == 2
    assert report.annotations_added == 4


def test_annotate_text_mode_records_per_class_failures() -> None:
    """A per-class failure surfaces as an AnnotationFailure for that image."""
    client = MagicMock()
    client.datasets.get.return_value = _make_dataset(
        images=[_make_image("img-1", "a.jpg")]
    )
    client.auto_annotate.text.side_effect = ApiError("class not understood")

    report = auto_annotate_dataset(
        client,
        "test-dataset",
        classes=[("car", "polygon")],
        mode="text",
    )
    assert report.images_processed == 0
    assert len(report.failures) == 1
    failure = report.failures[0]
    assert failure.image_filename == "a.jpg"
    assert "car: class not understood" in failure.reason


def test_annotate_text_tag_output_coerced_to_polygon() -> None:
    """``output_type='tag'`` is downgraded to ``polygon`` for SAM3."""
    client = MagicMock()
    client.datasets.get.return_value = _make_dataset(
        images=[_make_image("img-1", "a.jpg")]
    )
    client.auto_annotate.text.return_value = MagicMock(
        status="no_detection", annotations=[]
    )

    auto_annotate_dataset(
        client,
        "test-dataset",
        classes=[BatchClass(name="cat", output_type="tag")],
        mode="text",
    )
    kwargs = client.auto_annotate.text.call_args.kwargs
    assert kwargs["output_type"] == "polygon"


# ───────────── overwrite + max_images ─────────────


def test_annotate_skips_already_annotated_by_default() -> None:
    """``overwrite=False`` (default) skips images with annotation_count > 0."""
    client = MagicMock()
    client.datasets.get.return_value = _make_dataset(
        images=[
            _make_image("img-1", "a.jpg", annotation_count=3),
            _make_image("img-2", "b.jpg", annotation_count=0),
        ]
    )
    client.auto_annotate.batch.return_value = _ok_batch_job(
        processed=1, added=2
    )

    report = auto_annotate_dataset(
        client, "test-dataset", classes=[("car", "polygon")]
    )
    assert report.images_attempted == 1
    assert report.images_skipped == 1
    sent_filenames = client.auto_annotate.batch.call_args.kwargs[
        "image_filenames"
    ]
    assert sent_filenames == ["b.jpg"]


def test_annotate_overwrite_processes_all() -> None:
    """``overwrite=True`` processes every image regardless of count."""
    client = MagicMock()
    client.datasets.get.return_value = _make_dataset(
        images=[
            _make_image("img-1", "a.jpg", annotation_count=3),
            _make_image("img-2", "b.jpg", annotation_count=0),
        ]
    )
    client.auto_annotate.batch.return_value = _ok_batch_job(
        processed=2, added=4
    )

    report = auto_annotate_dataset(
        client,
        "test-dataset",
        classes=[("car", "polygon")],
        overwrite=True,
    )
    assert report.images_attempted == 2
    assert report.images_skipped == 0


def test_annotate_max_images_caps_payload() -> None:
    client = MagicMock()
    client.datasets.get.return_value = _make_dataset(
        images=[
            _make_image(f"img-{i}", f"img-{i}.jpg") for i in range(10)
        ]
    )
    client.auto_annotate.batch.return_value = _ok_batch_job(
        processed=3, added=3
    )

    report = auto_annotate_dataset(
        client,
        "test-dataset",
        classes=[("car", "polygon")],
        max_images=3,
    )
    assert report.images_attempted == 3
    sent_filenames = client.auto_annotate.batch.call_args.kwargs[
        "image_filenames"
    ]
    assert len(sent_filenames) == 3


# ───────────── empty / missing ─────────────


def test_annotate_empty_dataset_returns_empty_report() -> None:
    client = MagicMock()
    client.datasets.get.return_value = _make_dataset(images=[])
    report = auto_annotate_dataset(
        client, "test-dataset", classes=[("car", "polygon")]
    )
    assert report.images_attempted == 0
    assert report.images_processed == 0
    assert report.failures == []
    assert not report.success
    client.auto_annotate.batch.assert_not_called()


def test_annotate_propagates_dataset_not_found() -> None:
    client = MagicMock()
    client.datasets.get.side_effect = NotFoundError("missing dataset")
    with pytest.raises(NotFoundError):
        auto_annotate_dataset(
            client, "missing", classes=[("car", "polygon")]
        )
