"""Tests for the bundled ``pictograph-cv`` Claude Skill.

The skill is content (Markdown + Python wrapper scripts), not code, so
the tests verify it ships in the package, the SKILL.md frontmatter is
valid, and the references + scripts referenced from SKILL.md actually
exist.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from pictograph.skills import list_skills, skill_path

SKILL_NAME = "pictograph-cv"


def test_skill_path_resolves() -> None:
    """``skill_path()`` returns an existing directory containing SKILL.md."""
    path = skill_path(SKILL_NAME)
    assert isinstance(path, Path)
    assert path.is_dir()
    assert (path / "SKILL.md").is_file()


def test_skill_path_unknown_raises() -> None:
    with pytest.raises(FileNotFoundError, match="not_a_real_skill"):
        skill_path("not_a_real_skill")


def test_list_skills_includes_pictograph_cv() -> None:
    skills = list_skills()
    assert SKILL_NAME in skills


def test_skill_md_has_yaml_frontmatter() -> None:
    """SKILL.md begins with `---` frontmatter — Claude requires it."""
    body = (skill_path(SKILL_NAME) / "SKILL.md").read_text(encoding="utf-8")
    assert body.startswith("---\n"), "SKILL.md missing frontmatter"
    end = body.find("\n---\n", 4)
    assert end > 4, "SKILL.md frontmatter not closed with --- on its own line"


def test_skill_md_frontmatter_has_required_fields() -> None:
    body = (skill_path(SKILL_NAME) / "SKILL.md").read_text(encoding="utf-8")
    frontmatter = body.split("\n---\n", 1)[0]
    assert "name: pictograph-cv" in frontmatter
    assert "description:" in frontmatter
    # The description should be at least 50 chars (Anthropic recommends 100+).
    desc_line = next(
        line for line in frontmatter.splitlines() if line.startswith("description:")
    )
    assert len(desc_line) > 60, "skill description too short"


def test_skill_md_under_token_budget() -> None:
    """SKILL.md should fit comfortably under 5000 tokens (~20k chars)."""
    body = (skill_path(SKILL_NAME) / "SKILL.md").read_text(encoding="utf-8")
    estimated_tokens = len(body) // 4
    assert estimated_tokens < 5000, (
        f"SKILL.md is ~{estimated_tokens} tokens — keep under 5000."
    )


def test_skill_references_directory_populated() -> None:
    refs = skill_path(SKILL_NAME) / "references"
    assert refs.is_dir()
    expected = {
        "pictograph-json-schema.md",
        "annotation-types.md",
        "auto-annotation.md",
        "training.md",
        "credits.md",
    }
    actual = {p.name for p in refs.iterdir() if p.is_file()}
    assert expected.issubset(actual), (
        f"Missing references: {expected - actual}"
    )


def test_skill_scripts_directory_populated() -> None:
    scripts = skill_path(SKILL_NAME) / "scripts"
    assert scripts.is_dir()
    expected = {
        "full_pipeline.py",
        "upload_and_annotate.py",
        "train.py",
        "import_connector.py",
        "export.py",
    }
    actual = {p.name for p in scripts.iterdir() if p.is_file()}
    assert expected.issubset(actual), f"Missing scripts: {expected - actual}"


def test_skill_md_links_match_existing_files() -> None:
    """Every relative file path mentioned in SKILL.md must exist."""
    skill_dir = skill_path(SKILL_NAME)
    body = (skill_dir / "SKILL.md").read_text(encoding="utf-8")

    # Match patterns like `references/foo.md` or `scripts/bar.py` (in-text refs).
    import re

    matches = re.findall(r"`((?:references|scripts)/[a-z_\-]+\.(?:md|py))`", body)
    assert matches, "SKILL.md should reference its own files"
    for relative in set(matches):
        candidate = skill_dir / relative
        assert candidate.is_file(), f"SKILL.md references missing file: {relative}"


def test_skill_scripts_are_valid_python() -> None:
    """Each wrapper script must parse as Python (no syntax errors)."""
    import ast

    scripts = skill_path(SKILL_NAME) / "scripts"
    for script in scripts.glob("*.py"):
        source = script.read_text(encoding="utf-8")
        try:
            ast.parse(source, filename=str(script))
        except SyntaxError as exc:
            pytest.fail(f"{script.name}: {exc}")
