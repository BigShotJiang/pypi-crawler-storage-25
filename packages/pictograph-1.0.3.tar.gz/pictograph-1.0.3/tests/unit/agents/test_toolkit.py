"""Tests for ``pictograph.agents._toolkit.Toolkit``.

The toolkit is the dispatcher seam: it validates agent input via
Pydantic, calls the right handler, and serialises the result. Adapter
output shape (Anthropic / OpenAI / JSON Schema) is also asserted here
since each adapter is a thin transform of the same registry.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from unittest.mock import MagicMock

import pytest

from pictograph.agents import Toolkit, create_toolkit
from pictograph.agents._registry import REGISTRY
from pictograph.exceptions import ConfigurationError
from pictograph.models.credit import CreditBalance


def _balance(remaining: int = 1234) -> CreditBalance:
    return CreditBalance(
        credits_remaining=remaining,
        credits_monthly_allowance=10000,
        credits_reset_at=None,
        recent_history=[],
    )


# ───────────── construction ─────────────


def test_toolkit_construction_from_client() -> None:
    client = MagicMock()
    tk = Toolkit(client, max_response_tokens=10000)
    assert tk.client is client
    assert tk.max_response_tokens == 10000


def test_create_toolkit_uses_provided_client() -> None:
    client = MagicMock()
    tk = create_toolkit(client=client)
    assert tk.client is client


def test_create_toolkit_without_api_key_raises() -> None:
    """No api_key + no env var → ConfigurationError from Client init."""
    import os

    saved = os.environ.pop("PICTOGRAPH_API_KEY", None)
    try:
        with pytest.raises(ConfigurationError):
            create_toolkit()
    finally:
        if saved:
            os.environ["PICTOGRAPH_API_KEY"] = saved


# ───────────── dispatch ─────────────


def test_dispatch_calls_handler_with_validated_args() -> None:
    """Dispatch validates via Pydantic, calls handler, returns dump."""
    client = MagicMock()
    client.credits.balance.return_value = _balance(remaining=500)
    tk = Toolkit(client)
    result = tk.dispatch("get_credit_balance", {})
    assert result["credits_remaining"] == 500


def test_dispatch_validates_args_against_schema() -> None:
    from pydantic import ValidationError

    client = MagicMock()
    tk = Toolkit(client)
    # Missing required fields → Pydantic ValidationError.
    with pytest.raises(ValidationError):
        tk.dispatch("get_dataset", {})


def test_dispatch_rejects_extra_args() -> None:
    """All schemas use extra='forbid' — typo'd arg names should fail."""
    from pydantic import ValidationError

    client = MagicMock()
    tk = Toolkit(client)
    with pytest.raises(ValidationError):
        tk.dispatch("list_datasets", {"limit": 5, "bogus_field": True})


def test_dispatch_unknown_tool_raises_keyerror() -> None:
    client = MagicMock()
    tk = Toolkit(client)
    with pytest.raises(KeyError, match="nonexistent_tool"):
        tk.dispatch("nonexistent_tool", {})


def test_dispatch_estimate_credit_cost_round_trip() -> None:
    """Dispatch flows through to client.credits.estimate with the raw kwargs."""
    from pictograph.models.credit import CreditEstimate

    client = MagicMock()
    client.credits.estimate.return_value = CreditEstimate(
        operation="training_a10g_per_minute",
        credits_per_unit=10,
        unit="minute",
        quantity=30,
        total_credits=300,
        minimum=0,
        sufficient=True,
        credits_remaining=1000,
    )
    tk = Toolkit(client)
    result = tk.dispatch(
        "estimate_credit_cost",
        {"operation": "training_a10g_per_minute", "quantity": 30},
    )
    client.credits.estimate.assert_called_once_with(
        "training_a10g_per_minute", quantity=30
    )
    assert result["total_credits"] == 300
    assert result["sufficient"] is True


# ───────────── token-budget enforcement ─────────────


def test_dispatch_truncates_oversized_response() -> None:
    """Result over max_response_tokens collapses to a marker dict."""
    client = MagicMock()
    # 100k chars ≈ 25k tokens at 4 chars/token.
    big_history = [
        {"id": str(i), "operation": "x", "amount": 1, "balance_after": i,
         "description": None, "metadata": None,
         "created_at": datetime.now(timezone.utc).isoformat()}
        for i in range(5000)
    ]
    client.credits.balance.return_value = CreditBalance(
        credits_remaining=0,
        credits_monthly_allowance=0,
        credits_reset_at=None,
        recent_history=[],
    )
    # Patch the dump path: replace _dump indirectly by making balance() huge.
    # Simpler: call with a tiny budget so any real result triggers truncation.
    tk = Toolkit(client, max_response_tokens=1)
    client.credits.balance.return_value = _balance(remaining=42)
    result = tk.dispatch("get_credit_balance", {})
    assert result.get("_truncated") is True
    assert "max_response_tokens=1" in result["_message"]
    # Ensure big_history doesn't sneak through.
    assert big_history is not None  # hush ruff


def test_dispatch_zero_budget_disables_truncation() -> None:
    """max_response_tokens<=0 means 'no truncation' (debug mode)."""
    client = MagicMock()
    client.credits.balance.return_value = _balance(remaining=42)
    tk = Toolkit(client, max_response_tokens=0)
    result = tk.dispatch("get_credit_balance", {})
    assert "_truncated" not in result
    assert result["credits_remaining"] == 42


# ───────────── adapter outputs ─────────────


def test_as_anthropic_tools_shape() -> None:
    """Anthropic tool dicts have name/description/input_schema."""
    client = MagicMock()
    tools = Toolkit(client).as_anthropic_tools()
    assert len(tools) == len(REGISTRY)
    for tool in tools:
        assert set(tool) == {"name", "description", "input_schema"}
        assert tool["input_schema"]["type"] == "object"
        # Pydantic 'title' is stripped for clean schemas.
        assert "title" not in tool["input_schema"]


def test_as_openai_tools_shape() -> None:
    """OpenAI tool dicts have type='function' + name/description/parameters."""
    client = MagicMock()
    tools = Toolkit(client).as_openai_tools()
    assert len(tools) == len(REGISTRY)
    for tool in tools:
        assert tool["type"] == "function"
        assert "name" in tool
        assert "description" in tool
        assert tool["parameters"]["type"] == "object"


def test_as_json_schema_includes_metadata() -> None:
    """JSON Schema export carries required_role / credit_cost / idempotent."""
    client = MagicMock()
    tools = Toolkit(client).as_json_schema()
    assert len(tools) == len(REGISTRY)
    for tool in tools:
        assert {"name", "description", "input_schema",
                "required_role", "credit_cost", "idempotent"}.issubset(tool)


def test_anthropic_tools_match_registry_names() -> None:
    """Anthropic adapter exports every tool — no silent omissions."""
    client = MagicMock()
    names = {t["name"] for t in Toolkit(client).as_anthropic_tools()}
    assert names == {t.name for t in REGISTRY}


def test_openai_tools_match_registry_names() -> None:
    client = MagicMock()
    names = {t["name"] for t in Toolkit(client).as_openai_tools()}
    assert names == {t.name for t in REGISTRY}


def test_anthropic_tool_schemas_are_json_serialisable() -> None:
    """Schemas survive json.dumps (no Python-only types leaked)."""
    client = MagicMock()
    for tool in Toolkit(client).as_anthropic_tools():
        json.dumps(tool)  # raises TypeError if not serialisable
