"""Live: credits balance / history / estimate."""

from __future__ import annotations

import pytest

from pictograph import Client
from pictograph.models.credit import CreditBalance, CreditEstimate, CreditLedgerEntry

pytestmark = pytest.mark.live


def test_balance_shape(client: Client) -> None:
    balance = client.credits.balance()
    assert isinstance(balance, CreditBalance)
    assert balance.credits_remaining >= 0
    assert balance.credits_monthly_allowance > 0
    assert balance.credits_reset_at is not None


def test_history_default_page(client: Client) -> None:
    entries = client.credits.history(limit=5)
    assert isinstance(entries, list)
    for e in entries:
        assert isinstance(e, CreditLedgerEntry)
        assert e.id
        assert e.created_at is not None


def test_history_iter_auto_pages(client: Client) -> None:
    # Pull up to 10 entries via the auto-pager.
    pager = client.credits.iter(page_size=5, max_total=10)
    items = pager.all()
    assert isinstance(items, list)
    assert len(items) <= 10


@pytest.mark.parametrize(
    "operation,expected_unit",
    [
        ("training_a10g", "per_minute"),
        ("training_a100", "per_minute"),
        ("training_h100", "per_minute"),
        ("sam3_auto_annotation", "per_minute"),
        ("inference_t4", "per_minute"),
        ("image_edit_gemini_flash", "per_call"),
        ("image_generate_imagen_fast", "per_call"),
    ],
)
def test_estimate_operations(client: Client, operation: str, expected_unit: str) -> None:
    est = client.credits.estimate(operation, quantity=1)
    assert isinstance(est, CreditEstimate)
    assert est.operation == operation
    assert est.total_credits >= est.minimum
    assert est.unit == expected_unit


def test_estimate_quantity_scales_with_minimum(client: Client) -> None:
    one = client.credits.estimate("training_a10g", quantity=1)
    ten = client.credits.estimate("training_a10g", quantity=10)
    # Training has a 5-credit minimum, so 1-min quantity is clamped.
    assert ten.quantity == 10
    assert ten.total_credits == max(ten.minimum, ten.credits_per_unit * 10)
    assert one.total_credits >= one.minimum
