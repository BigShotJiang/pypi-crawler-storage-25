"""venunite-events: an MCP proxy for the hosted VenuNite event-search service.

This package ships a tiny stdio↔HTTPS bridge. Claude Desktop (and any
other MCP client that only speaks stdio) can install this package and
point at it in the client's config; the bridge translates MCP stdio
traffic to the hosted streamable-HTTP endpoint at
``https://mcp.venunite.com/v1/mcp/`` using the user's API key.

Clients that natively speak streamable-HTTP (Claude.ai Custom
Connectors, etc.) should connect to the hosted URL directly instead —
this proxy exists only because the stdio-only landscape is still the
default for desktop MCP clients.
"""

__version__ = "0.1.0"
