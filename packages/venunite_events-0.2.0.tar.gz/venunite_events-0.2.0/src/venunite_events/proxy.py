"""stdio ↔ streamable-HTTP MCP bridge.

The core of the ``venunite-events`` package. Opens two halves of an
MCP session in parallel:

  1. An **stdio server** reading JSON-RPC from the parent Claude
     Desktop process's stdin/stdout.
  2. A **streamable-HTTP client** connected to the hosted VenuNite
     MCP endpoint over TLS, authenticated with the user's bearer
     token.

Messages arriving on either side are forwarded to the other — the
bridge never inspects or modifies them. Every JSON-RPC method the
hosted server supports (``initialize``, ``tools/list``,
``tools/call``) passes through unchanged, so a future upgrade of
the hosted server's tool set requires zero changes here.

Environment
===========
- ``VENUNITE_API_KEY`` **required**. Provisioned by ``python -m
  scraper.api.admin provision`` and displayed once.
- ``VENUNITE_MCP_URL`` **optional** — defaults to the hosted URL.
  Override for self-hosted or staging deployments.

Failure modes
=============
- Missing key → the bridge prints a single-line JSON error to stderr
  and exits non-zero. Claude Desktop surfaces this in its MCP logs
  so users can see what's wrong.
- Network failure on the HTTPS side → the stdio side gets a
  JSON-RPC error; Claude retries the tool call.
- Server returns 401 → surfaced to Claude as an MCP error payload;
  the user sees "invalid_or_revoked_key" in their client.
"""
from __future__ import annotations

import os
import sys
from typing import Optional

import anyio
from mcp.client.streamable_http import streamablehttp_client
from mcp.server.stdio import stdio_server


_DEFAULT_URL = "https://mcp.venunite.com/v1/mcp/"


async def _pump(
    source,
    sink,
    label: str,
) -> None:
    """One-way forwarder: every message from ``source`` → ``sink``.

    Both sides of the bridge use anyio ``MemoryObjectStream``\\ s so
    message semantics (framing, serialization) are already handled
    by the MCP SDK — this function only needs to ferry values. We
    emit nothing on normal stream closure; exceptions propagate so
    the enclosing task group can cancel the other pump and exit
    cleanly.
    """
    try:
        async for msg in source:
            # The stdio side emits ``SessionMessage | Exception``;
            # the streamable-http side emits the same shape. Forward
            # both — the peer handles message-vs-error dispatch.
            await sink.send(msg)
    except anyio.EndOfStream:
        # Normal close — the peer hung up. Let the task group know
        # by returning; the other pump will exit once its stream
        # also closes (or we cancel it).
        pass


async def run_proxy(
    url: str,
    api_key: str,
) -> None:
    """Open both halves and pipe them together until either closes.

    The two pumps run as siblings inside a single anyio task group
    so a failure on either half cancels the other — we never leak a
    half-open connection to either Claude Desktop or the hosted
    server. After cancellation the outer ``async with`` blocks run
    each transport's own teardown (closing stdio streams, sending a
    DELETE to terminate the HTTP session if applicable).
    """
    headers = {
        "Authorization": f"Bearer {api_key}",
        # Claude Desktop's stdio framing is protocol-version-agnostic
        # — the MCP SDK negotiates versions during ``initialize``.
        # But the hosted side's streamable-HTTP transport requires
        # the header for clients that want the 2025-06-18 features.
        "MCP-Protocol-Version": "2025-06-18",
    }

    async with streamablehttp_client(url, headers=headers) as (
        upstream_read,
        upstream_write,
        _get_session_id,
    ):
        async with stdio_server() as (stdio_read, stdio_write):
            async with anyio.create_task_group() as tg:
                # Claude → hosted server.
                tg.start_soon(_pump, stdio_read, upstream_write, "→upstream")
                # Hosted server → Claude.
                tg.start_soon(_pump, upstream_read, stdio_write, "→stdio")
                # Both pumps block on their source streams; the task
                # group returns when BOTH have exited. anyio cancels
                # the other if one raises.


def main_sync() -> int:
    """Synchronous CLI entrypoint. Resolves config from env, runs
    the proxy, returns a shell exit code.

    Split from ``__main__.main`` so tests can import and call it
    without going through ``python -m``.
    """
    api_key = os.environ.get("VENUNITE_API_KEY")
    if not api_key:
        _eprint("VENUNITE_API_KEY environment variable is required. "
                "Mint one via your VenuNite account — the key is "
                "shown once at creation time.")
        return 2

    url = os.environ.get("VENUNITE_MCP_URL", _DEFAULT_URL)
    if not url.startswith(("http://", "https://")):
        _eprint(f"VENUNITE_MCP_URL must be an http(s) URL, got {url!r}")
        return 2

    try:
        anyio.run(run_proxy, url, api_key)
        return 0
    except KeyboardInterrupt:
        return 0
    except Exception as exc:
        _eprint(f"proxy crashed: {type(exc).__name__}: {exc}")
        return 1


def _eprint(msg: str) -> None:
    """stderr write. Claude Desktop logs stderr per-server at
    ``~/Library/Logs/Claude/mcp-server-<name>.log`` so these messages
    are the primary diagnostic surface when a user's config is
    misconfigured."""
    print(f"[venunite-events] {msg}", file=sys.stderr, flush=True)
