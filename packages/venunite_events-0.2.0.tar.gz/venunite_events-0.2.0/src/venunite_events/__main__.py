"""CLI entrypoint: ``python -m venunite_events`` or the
``venunite-events`` console script declared in ``pyproject.toml``.

Intentionally thin — all real logic lives in ``proxy.py``. This
module exists to give Claude Desktop (and any other MCP client that
invokes servers by command-line) a predictable entrypoint it can
spawn with no arguments.
"""
from __future__ import annotations

import sys

from venunite_events.proxy import main_sync


def main() -> None:
    """Delegate to the proxy's synchronous entrypoint and propagate
    the return code to the process exit status."""
    sys.exit(main_sync())


if __name__ == "__main__":
    main()
