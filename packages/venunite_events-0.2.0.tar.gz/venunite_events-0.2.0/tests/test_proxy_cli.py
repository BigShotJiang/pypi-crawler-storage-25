"""Regression tests for the venunite-events proxy CLI.

Why this test file exists
=========================
The proxy itself is a thin bridge — its happy path (stdio ⟷ HTTPS
forwarding) is exercised end-to-end via Claude Desktop and via the
smoke tests in the parent repo. What CAN regress independently is
the CLI surface: error messages users see BEFORE any MCP traffic
flows.

If a user pastes the Claude Desktop config and forgets to set
``VENUNITE_API_KEY``, the proxy must surface a clear diagnostic to
stderr and exit non-zero — otherwise Claude Desktop silently hangs
waiting for MCP handshake that will never come, and the user has
no hint what's wrong. Same for a mistyped URL scheme.

These tests pin the observable behaviour a user will actually see
in the Claude Desktop logs. No network, no MCP SDK required.
"""
from __future__ import annotations

import io
import os
import sys
from contextlib import redirect_stderr
from unittest.mock import patch


def test_missing_api_key_exits_2_with_diagnostic():
    """Users mis-paste the Claude Desktop config all the time. The
    error message must (a) name the env var exactly, and (b) tell
    them where the key comes from — without that, the first-run
    experience is a silent hang."""
    from venunite_events.proxy import main_sync

    buf = io.StringIO()
    with patch.dict(os.environ, {}, clear=True), redirect_stderr(buf):
        rc = main_sync()

    assert rc == 2, f"expected exit 2, got {rc}"
    err = buf.getvalue()
    assert "VENUNITE_API_KEY" in err
    assert "required" in err.lower()
    # The user needs a breadcrumb to the provisioning flow.
    assert "mint" in err.lower() or "shown once" in err.lower()


def test_invalid_url_scheme_exits_2():
    """``VENUNITE_MCP_URL=file:///etc/passwd`` should not silently
    attempt to read a local file — the hosted MCP is always HTTPS.
    Reject at argv-parse time rather than discovering the problem
    after the user's first query fails mysteriously."""
    from venunite_events.proxy import main_sync

    buf = io.StringIO()
    with patch.dict(os.environ, {
        "VENUNITE_API_KEY": "vn_live_anything_at_all_here_x",
        "VENUNITE_MCP_URL": "ftp://not-a-real-scheme/mcp/",
    }, clear=True), redirect_stderr(buf):
        rc = main_sync()

    assert rc == 2
    err = buf.getvalue()
    assert "VENUNITE_MCP_URL" in err
    assert "http" in err.lower()


def test_default_url_is_hosted_endpoint():
    """The hosted URL must be the canonical path and end with a
    trailing slash — streamable-HTTP routes are path-prefix
    matched, and a missing slash changes the matched route under
    Starlette's routing. Pin the constant so a future ``clean up
    the trailing slash`` PR doesn't silently break every installed
    client."""
    from venunite_events.proxy import _DEFAULT_URL
    assert _DEFAULT_URL == "https://mcp.venunite.com/v1/mcp/"
    assert _DEFAULT_URL.startswith("https://")
    assert _DEFAULT_URL.endswith("/")


def test_main_module_is_importable():
    """``python -m venunite_events`` must work. The ``__main__``
    module re-exports ``main`` so the console-script entry point
    declared in pyproject.toml can resolve it without an extra
    re-export step."""
    import venunite_events.__main__ as m
    assert callable(m.main)


def test_cli_entrypoint_installed():
    """The ``venunite-events`` console script must be on PATH after
    ``pip install``. This test asserts the entry-point spec is
    correct in pyproject.toml; the actual dispatcher is generated
    by the build backend at install time.

    Running the installed console-script here would require a real
    venv layout; instead we import the entry-point module and
    check the function it points at is importable + callable."""
    from venunite_events.__main__ import main
    assert callable(main)
