package net.nytsudoku.sitekit;

/**
 * URL helpers for NYT Sudoku.
 */
public final class NytSudokuLinks {
    /** NYT Sudoku homepage. */
    public static final String BASE_URL = "https://nyt-sudoku.net";

    private NytSudokuLinks() {
    }

    /**
     * Returns the NYT Sudoku homepage URL.
     *
     * @return homepage URL
     */
    public static String homeUrl() {
        return BASE_URL;
    }

    /**
     * Builds an NYT Sudoku page URL from a path slug.
     *
     * @param slug page path slug
     * @return page URL
     */
    public static String pageUrl(String slug) {
        String clean = slug == null ? "" : slug.replaceAll("^/+|/+$", "");
        return clean.isEmpty() ? BASE_URL : BASE_URL + "/" + clean;
    }

    /**
     * Returns the NYT Sudoku game URL.
     *
     * @return game URL
     */
    public static String gameUrl() {
        return pageUrl("#game-component");
    }

    /**
     * Returns the NYT Sudoku introduction URL.
     *
     * @return introduction URL
     */
    public static String introUrl() {
        return pageUrl("#intro");
    }

    /**
     * Returns the NYT Sudoku how-to-play URL.
     *
     * @return how-to-play URL
     */
    public static String howtoUrl() {
        return pageUrl("#howto");
    }

    /**
     * Returns the NYT Sudoku stats URL.
     *
     * @return stats URL
     */
    public static String statsUrl() {
        return pageUrl("stats");
    }

    /**
     * Returns the NYT Sudoku blog URL.
     *
     * @return blog URL
     */
    public static String blogUrl() {
        return pageUrl("#blog");
    }

    /**
     * Returns the NYT Sudoku FAQ URL.
     *
     * @return FAQ URL
     */
    public static String faqUrl() {
        return pageUrl("#faq");
    }
}
