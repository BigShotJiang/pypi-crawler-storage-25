<?php

declare(strict_types=1);

namespace NytSudoku\SiteKit;

final class NytSudokuLinks
{
    public const BASE_URL = 'https://nyt-sudoku.net';

    public static function homeUrl(): string
    {
        return self::BASE_URL;
    }

    public static function pageUrl(string $slug): string
    {
        $clean = trim($slug, '/');
        return $clean === '' ? self::BASE_URL : self::BASE_URL . '/' . $clean;
    }

    public static function gameUrl(): string
    {
        return self::pageUrl('#game-component');
    }

    public static function introUrl(): string
    {
        return self::pageUrl('#intro');
    }

    public static function howtoUrl(): string
    {
        return self::pageUrl('#howto');
    }

    public static function statsUrl(): string
    {
        return self::pageUrl('stats');
    }

    public static function blogUrl(): string
    {
        return self::pageUrl('#blog');
    }

    public static function faqUrl(): string
    {
        return self::pageUrl('#faq');
    }
}
