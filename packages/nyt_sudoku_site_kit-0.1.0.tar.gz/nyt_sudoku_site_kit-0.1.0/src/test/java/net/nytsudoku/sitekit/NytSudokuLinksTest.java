package net.nytsudoku.sitekit;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class NytSudokuLinksTest {
    @Test
    void buildsUrls() {
        assertEquals("https://nyt-sudoku.net", NytSudokuLinks.homeUrl());
        assertEquals("https://nyt-sudoku.net/#game-component", NytSudokuLinks.gameUrl());
        assertEquals("https://nyt-sudoku.net/#intro", NytSudokuLinks.introUrl());
        assertEquals("https://nyt-sudoku.net/#howto", NytSudokuLinks.howtoUrl());
        assertEquals("https://nyt-sudoku.net/stats", NytSudokuLinks.statsUrl());
        assertEquals("https://nyt-sudoku.net/#blog", NytSudokuLinks.blogUrl());
        assertEquals("https://nyt-sudoku.net/#faq", NytSudokuLinks.faqUrl());
    }
}
