defmodule NytSudokuSiteKit.MixProject do
  use Mix.Project

  def project do
    [
      app: :nyt_sudoku_site_kit,
      version: "0.1.0",
      elixir: "~> 1.18",
      start_permanent: Mix.env() == :prod,
      deps: deps(),
      description: "Small URL helpers for nyt-sudoku.net, an unofficial free Sudoku web app.",
      package: package(),
      docs: [
        main: "NytSudokuSiteKit",
        source_url: "https://github.com/bbwdadfg/nyt-sudoku-site-kit"
      ]
    ]
  end

  def application do
    [extra_applications: [:logger]]
  end

  defp deps do
    [
      {:ex_doc, ">= 0.0.0", only: :dev, runtime: false}
    ]
  end

  defp package do
    [
      licenses: ["MIT"],
      links: %{
        "NYT Sudoku" => "https://nyt-sudoku.net",
        "Play" => "https://nyt-sudoku.net/#game-component",
        "How to Play" => "https://nyt-sudoku.net/#howto",
        "Stats" => "https://nyt-sudoku.net/stats",
        "GitHub" => "https://github.com/bbwdadfg/nyt-sudoku-site-kit"
      },
      files: ["lib/nyt_sudoku_site_kit.ex", "mix.exs", "README.md", "LICENSE"]
    ]
  end
end
