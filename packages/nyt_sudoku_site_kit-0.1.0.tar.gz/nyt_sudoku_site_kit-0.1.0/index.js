const BASE_URL = "https://nyt-sudoku.net";

function homeUrl() {
  return BASE_URL;
}

function pageUrl(slug = "") {
  const clean = String(slug).replace(/^\/+|\/+$/g, "");
  return clean ? `${BASE_URL}/${clean}` : BASE_URL;
}

const gameUrl = () => pageUrl("#game-component");
const introUrl = () => pageUrl("#intro");
const howtoUrl = () => pageUrl("#howto");
const statsUrl = () => pageUrl("stats");
const blogUrl = () => pageUrl("#blog");
const faqUrl = () => pageUrl("#faq");

module.exports = {
  BASE_URL,
  homeUrl,
  pageUrl,
  gameUrl,
  introUrl,
  howtoUrl,
  statsUrl,
  blogUrl,
  faqUrl
};
