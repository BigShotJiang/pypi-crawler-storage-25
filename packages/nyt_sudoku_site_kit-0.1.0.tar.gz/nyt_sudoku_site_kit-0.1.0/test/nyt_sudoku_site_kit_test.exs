defmodule NytSudokuSiteKitTest do
  use ExUnit.Case

  test "builds NYT Sudoku URLs" do
    assert NytSudokuSiteKit.home_url() == "https://nyt-sudoku.net"
    assert NytSudokuSiteKit.game_url() == "https://nyt-sudoku.net/#game-component"
    assert NytSudokuSiteKit.intro_url() == "https://nyt-sudoku.net/#intro"
    assert NytSudokuSiteKit.howto_url() == "https://nyt-sudoku.net/#howto"
    assert NytSudokuSiteKit.stats_url() == "https://nyt-sudoku.net/stats"
    assert NytSudokuSiteKit.blog_url() == "https://nyt-sudoku.net/#blog"
    assert NytSudokuSiteKit.faq_url() == "https://nyt-sudoku.net/#faq"
  end
end
