import 'package:test/test.dart';
import 'package:nyt_sudoku_site_kit/nyt_sudoku_site_kit.dart' as links;

void main() {
  test('builds NYT Sudoku URLs', () {
    expect(links.homeUrl(), 'https://nyt-sudoku.net');
    expect(links.gameUrl(), 'https://nyt-sudoku.net/#game-component');
    expect(links.introUrl(), 'https://nyt-sudoku.net/#intro');
    expect(links.howtoUrl(), 'https://nyt-sudoku.net/#howto');
    expect(links.statsUrl(), 'https://nyt-sudoku.net/stats');
    expect(links.blogUrl(), 'https://nyt-sudoku.net/#blog');
    expect(links.faqUrl(), 'https://nyt-sudoku.net/#faq');
  });
}
