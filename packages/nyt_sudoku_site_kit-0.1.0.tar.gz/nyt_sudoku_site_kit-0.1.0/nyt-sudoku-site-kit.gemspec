Gem::Specification.new do |spec|
  spec.name = "nyt-sudoku-site-kit"
  spec.version = "0.1.0"
  spec.summary = "Small URL helpers for NYT Sudoku."
  spec.description = "Small URL helpers for nyt-sudoku.net, an unofficial free Sudoku web app at https://nyt-sudoku.net."
  spec.authors = ["NYT Sudoku"]
  spec.email = ["hello@nyt-sudoku.net"]
  spec.homepage = "https://nyt-sudoku.net"
  spec.license = "MIT"
  spec.files = Dir["lib/**/*.rb", "README.md", "LICENSE"]
  spec.require_paths = ["lib"]
  spec.metadata = {
    "homepage_uri" => "https://nyt-sudoku.net",
    "source_code_uri" => "https://github.com/bbwdadfg/nyt-sudoku-site-kit"
  }
end
