module github.com/bbwdadfg/nyt-sudoku-site-kit

go 1.22
