BASE_URL = "https://nyt-sudoku.net"


def home_url() -> str:
    return BASE_URL


def page_url(slug: str) -> str:
    clean = slug.strip("/")
    return BASE_URL if clean == "" else f"{BASE_URL}/{clean}"


def game_url() -> str:
    return page_url("#game-component")


def intro_url() -> str:
    return page_url("#intro")


def howto_url() -> str:
    return page_url("#howto")


def stats_url() -> str:
    return page_url("stats")


def blog_url() -> str:
    return page_url("#blog")


def faq_url() -> str:
    return page_url("#faq")
