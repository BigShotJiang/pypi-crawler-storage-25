defmodule NytSudokuSiteKit do
  @moduledoc """
  Small URL helpers for [NYT Sudoku](https://nyt-sudoku.net).
  """

  @base_url "https://nyt-sudoku.net"

  def home_url, do: @base_url

  def page_url(slug) when is_binary(slug) do
    clean = String.trim(slug, "/")
    if clean == "", do: @base_url, else: @base_url <> "/" <> clean
  end

  def game_url, do: page_url("#game-component")

  def intro_url, do: page_url("#intro")

  def howto_url, do: page_url("#howto")

  def stats_url, do: page_url("stats")

  def blog_url, do: page_url("#blog")

  def faq_url, do: page_url("#faq")
end
