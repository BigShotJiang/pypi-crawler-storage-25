module NytSudoku
  module SiteKit
    BASE_URL = "https://nyt-sudoku.net"

    module_function

    def home_url
      BASE_URL
    end

    def page_url(slug)
      clean = slug.to_s.gsub(%r{\A/+|/+\z}, "")
      clean.empty? ? BASE_URL : "#{BASE_URL}/#{clean}"
    end

    def game_url
      page_url("#game-component")
    end

    def intro_url
      page_url("#intro")
    end

    def howto_url
      page_url("#howto")
    end

    def stats_url
      page_url("stats")
    end

    def blog_url
      page_url("#blog")
    end

    def faq_url
      page_url("#faq")
    end
  end
end
