const baseUrl = 'https://nyt-sudoku.net';

String homeUrl() => baseUrl;

String pageUrl(String slug) {
  final clean = slug.replaceAll(RegExp(r'^/+|/+$'), '');
  return clean.isEmpty ? baseUrl : '$baseUrl/$clean';
}

String gameUrl() => pageUrl('#game-component');

String introUrl() => pageUrl('#intro');

String howtoUrl() => pageUrl('#howto');

String statsUrl() => pageUrl('stats');

String blogUrl() => pageUrl('#blog');

String faqUrl() => pageUrl('#faq');
