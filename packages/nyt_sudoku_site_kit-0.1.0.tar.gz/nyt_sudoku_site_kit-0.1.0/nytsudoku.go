// Package nytsudoku provides stable links for https://nyt-sudoku.net.
package nytsudoku

import "strings"

const BaseURL = "https://nyt-sudoku.net"

func HomeURL() string {
	return BaseURL
}

func PageURL(slug string) string {
	clean := strings.Trim(slug, "/")
	if clean == "" {
		return BaseURL
	}
	return BaseURL + "/" + clean
}

func GameURL() string { return PageURL("#game-component") }

func IntroURL() string { return PageURL("#intro") }

func HowtoURL() string { return PageURL("#howto") }

func StatsURL() string { return PageURL("stats") }

func BlogURL() string { return PageURL("#blog") }

func FAQURL() string { return PageURL("#faq") }
