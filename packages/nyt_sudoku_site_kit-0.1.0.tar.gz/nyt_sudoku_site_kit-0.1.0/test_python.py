import unittest

import nyt_sudoku_site_kit as links


class NytSudokuSiteKitTest(unittest.TestCase):
    def test_urls(self):
        self.assertEqual(links.home_url(), "https://nyt-sudoku.net")
        self.assertEqual(links.game_url(), "https://nyt-sudoku.net/#game-component")
        self.assertEqual(links.intro_url(), "https://nyt-sudoku.net/#intro")
        self.assertEqual(links.howto_url(), "https://nyt-sudoku.net/#howto")
        self.assertEqual(links.stats_url(), "https://nyt-sudoku.net/stats")
        self.assertEqual(links.blog_url(), "https://nyt-sudoku.net/#blog")
        self.assertEqual(links.faq_url(), "https://nyt-sudoku.net/#faq")


if __name__ == "__main__":
    unittest.main()
