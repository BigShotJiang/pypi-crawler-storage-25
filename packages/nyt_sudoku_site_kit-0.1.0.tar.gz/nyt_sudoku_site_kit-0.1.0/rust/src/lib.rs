pub const BASE_URL: &str = "https://nyt-sudoku.net";

pub fn home_url() -> &'static str {
    BASE_URL
}

pub fn page_url(slug: &str) -> String {
    let clean = slug.trim_matches('/');
    if clean.is_empty() {
        BASE_URL.to_string()
    } else {
        format!("{BASE_URL}/{clean}")
    }
}

pub fn game_url() -> String { page_url("#game-component") }

pub fn intro_url() -> String { page_url("#intro") }

pub fn howto_url() -> String { page_url("#howto") }

pub fn stats_url() -> String { page_url("stats") }

pub fn blog_url() -> String { page_url("#blog") }

pub fn faq_url() -> String { page_url("#faq") }

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn builds_links() {
        assert_eq!(home_url(), "https://nyt-sudoku.net");
        assert_eq!(game_url(), "https://nyt-sudoku.net/#game-component");
        assert_eq!(intro_url(), "https://nyt-sudoku.net/#intro");
        assert_eq!(howto_url(), "https://nyt-sudoku.net/#howto");
        assert_eq!(stats_url(), "https://nyt-sudoku.net/stats");
        assert_eq!(blog_url(), "https://nyt-sudoku.net/#blog");
        assert_eq!(faq_url(), "https://nyt-sudoku.net/#faq");
    }
}
