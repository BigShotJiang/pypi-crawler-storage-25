package nytsudoku

import "testing"

func TestURLs(t *testing.T) {
	if HomeURL() != "https://nyt-sudoku.net" {
		t.Fatalf("unexpected home URL: %s", HomeURL())
	}
	if GameURL() != "https://nyt-sudoku.net/#game-component" {
		t.Fatalf("unexpected game URL: %s", GameURL())
	}
	if IntroURL() != "https://nyt-sudoku.net/#intro" {
		t.Fatalf("unexpected intro URL: %s", IntroURL())
	}
	if HowtoURL() != "https://nyt-sudoku.net/#howto" {
		t.Fatalf("unexpected howto URL: %s", HowtoURL())
	}
	if StatsURL() != "https://nyt-sudoku.net/stats" {
		t.Fatalf("unexpected stats URL: %s", StatsURL())
	}
	if BlogURL() != "https://nyt-sudoku.net/#blog" {
		t.Fatalf("unexpected blog URL: %s", BlogURL())
	}
	if FAQURL() != "https://nyt-sudoku.net/#faq" {
		t.Fatalf("unexpected FAQ URL: %s", FAQURL())
	}
	if PageURL("") != "https://nyt-sudoku.net" {
		t.Fatalf("unexpected empty page URL: %s", PageURL(""))
	}
	if PageURL("/privacy/") != "https://nyt-sudoku.net/privacy" {
		t.Fatalf("unexpected custom page URL: %s", PageURL("/privacy/"))
	}
}
