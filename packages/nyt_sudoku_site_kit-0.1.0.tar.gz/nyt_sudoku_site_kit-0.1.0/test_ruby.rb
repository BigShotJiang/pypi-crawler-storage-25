$LOAD_PATH.unshift(File.expand_path("lib", __dir__))
require "nyt_sudoku/site_kit"

raise "home" unless NytSudoku::SiteKit.home_url == "https://nyt-sudoku.net"
raise "game" unless NytSudoku::SiteKit.game_url == "https://nyt-sudoku.net/#game-component"
raise "intro" unless NytSudoku::SiteKit.intro_url == "https://nyt-sudoku.net/#intro"
raise "howto" unless NytSudoku::SiteKit.howto_url == "https://nyt-sudoku.net/#howto"
raise "stats" unless NytSudoku::SiteKit.stats_url == "https://nyt-sudoku.net/stats"
raise "blog" unless NytSudoku::SiteKit.blog_url == "https://nyt-sudoku.net/#blog"
raise "faq" unless NytSudoku::SiteKit.faq_url == "https://nyt-sudoku.net/#faq"
