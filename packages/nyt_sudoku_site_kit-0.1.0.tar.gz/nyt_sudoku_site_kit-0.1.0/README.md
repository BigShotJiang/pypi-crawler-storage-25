# NYT Sudoku Site Kit

Small URL helpers for [NYT Sudoku](https://nyt-sudoku.net), an unofficial free Sudoku web app with daily puzzles, four difficulty levels, notes, hints, auto-save, and offline play.

## Links

- Website: <https://nyt-sudoku.net>
- Play: <https://nyt-sudoku.net/#game-component>
- Introduction: <https://nyt-sudoku.net/#intro>
- How to play: <https://nyt-sudoku.net/#howto>
- Stats: <https://nyt-sudoku.net/stats>
- Blog: <https://nyt-sudoku.net/#blog>
- FAQ: <https://nyt-sudoku.net/#faq>

## Purpose

This repository keeps tiny, installable helpers for package registry metadata and examples. Each package exposes the same small set of stable NYT Sudoku links.
