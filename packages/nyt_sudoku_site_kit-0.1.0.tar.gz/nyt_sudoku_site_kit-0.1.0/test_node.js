const assert = require("node:assert/strict");
const links = require("./index");

assert.equal(links.homeUrl(), "https://nyt-sudoku.net");
assert.equal(links.gameUrl(), "https://nyt-sudoku.net/#game-component");
assert.equal(links.introUrl(), "https://nyt-sudoku.net/#intro");
assert.equal(links.howtoUrl(), "https://nyt-sudoku.net/#howto");
assert.equal(links.statsUrl(), "https://nyt-sudoku.net/stats");
assert.equal(links.blogUrl(), "https://nyt-sudoku.net/#blog");
assert.equal(links.faqUrl(), "https://nyt-sudoku.net/#faq");
