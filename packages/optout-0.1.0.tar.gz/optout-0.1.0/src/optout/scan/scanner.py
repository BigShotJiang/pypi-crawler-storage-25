"""Checks whether user data appears on a broker's search results."""

from __future__ import annotations

from dataclasses import dataclass, field

from ..brokers.schema import BrokerDef
from ..config import Profile


@dataclass
class ScanMatch:
    text: str
    url: str | None = None


@dataclass
class ScanOutcome:
    result: str  # "clean" | "found" | "inconclusive"
    matches: list[ScanMatch] = field(default_factory=list)
    error: str | None = None


def _name_slug(name: str) -> str:
    """'Jane Q Public' → 'Jane-Q-Public'."""
    return "-".join(name.split())


def _name_in_text(name: str, text: str) -> bool:
    """True if every word of name appears (case-insensitive) in text."""
    words = name.lower().split()
    text_lower = text.lower()
    return all(w in text_lower for w in words)


def _run_scan_on_page(page: object, broker: BrokerDef, profile: Profile) -> ScanOutcome:
    """Execute a scan using an already-open Playwright page."""
    from playwright.sync_api import TimeoutError as PlaywrightTimeoutError

    scan_cfg = broker.scan
    if not scan_cfg:
        return ScanOutcome(result="inconclusive", error="Broker has no scan config")

    url = scan_cfg.search_url_template.format(
        name_slug=_name_slug(profile.legal_name),
        state=profile.current_address.state,
    )

    try:
        page.goto(url, timeout=30_000, wait_until="domcontentloaded")  # type: ignore[union-attr]
        page.wait_for_selector(scan_cfg.result_selector, timeout=10_000)  # type: ignore[union-attr]
    except PlaywrightTimeoutError:
        return ScanOutcome(result="inconclusive", error=f"Timeout loading {url}")
    except Exception as exc:
        return ScanOutcome(result="inconclusive", error=str(exc))

    elements = page.query_selector_all(scan_cfg.result_selector)  # type: ignore[union-attr]
    if not elements:
        return ScanOutcome(result="clean")

    names_to_check = [profile.legal_name] + list(profile.aliases)
    matches: list[ScanMatch] = []
    for el in elements:
        try:
            text = el.inner_text()
        except Exception:
            continue

        href: str | None = None
        try:
            href = el.get_attribute("href")
            if not href:
                link = el.query_selector("a")
                if link:
                    href = link.get_attribute("href")
        except Exception:
            pass

        if any(_name_in_text(n, text) for n in names_to_check):
            matches.append(ScanMatch(text=text[:300], url=href))

    return ScanOutcome(result="found" if matches else "clean", matches=matches)


def scan_broker(
    broker: BrokerDef,
    profile: Profile,
    *,
    headless: bool = False,
    slow_mo_ms: int = 0,
    _page: object = None,
) -> ScanOutcome:
    """Scan a single broker and return a ScanOutcome.

    _page injects a Playwright page object (or mock) for testing.
    """
    if _page is not None:
        return _run_scan_on_page(_page, broker, profile)

    if not broker.scan:
        return ScanOutcome(result="inconclusive", error="Broker has no scan config")

    from playwright.sync_api import sync_playwright

    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=headless, slow_mo=slow_mo_ms)
        page = browser.new_page()
        try:
            return _run_scan_on_page(page, broker, profile)
        finally:
            browser.close()
