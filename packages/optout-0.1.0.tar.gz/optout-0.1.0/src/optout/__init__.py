"""OptOut — self-hosted data broker opt-out tool."""

__version__ = "0.1.0"
