import json
import os
import shutil
import subprocess
import sys
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime, timedelta
from enum import StrEnum
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any

import prompt_toolkit
import questionary
import requests
import typer
from dotenv import load_dotenv, set_key
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from ics import Calendar, Event
from notifypy import Notify
from packaging.version import parse as parse_version
from prompt_toolkit.key_binding import KeyBindings, merge_key_bindings
from prompt_toolkit.keys import Keys
from questionary import Style
from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)
from rich.table import Table

# Initialize Typer and Rich for pretty terminal output
app = typer.Typer(
    help="CLI for Canvas LMS (Uppsala University default)",
    context_settings={"help_option_names": ["-h", "--help"]},
    no_args_is_help=True,
)

console = Console()

# Configuration setup
CONFIG_DIR = Path.home() / ".config" / "studium"
ENV_PATH = CONFIG_DIR / ".env"
if not CONFIG_DIR.exists():
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

# Cache setup
CACHE_DIR = Path.home() / ".cache" / "studium"
CACHE_FILE = CACHE_DIR / "assignments.json"
UPDATE_CHECK_FILE = CACHE_DIR / "last_update_check.txt"

# Google Calendar paths
GOOGLE_TOKEN_FILE = CONFIG_DIR / "google_token.json"
GOOGLE_CREDENTIALS_FILE = CONFIG_DIR / "google_credentials.json"

DEFAULT_BASE_URL = "https://uppsala.instructure.com"

# Google Calendar Scopes
SCOPES = ["https://www.googleapis.com/auth/calendar"]


def get_google_service():
    """Get an authorized Google Calendar service instance."""
    creds = None
    if GOOGLE_TOKEN_FILE.exists():
        creds = Credentials.from_authorized_user_file(str(GOOGLE_TOKEN_FILE), SCOPES)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
            except Exception:
                creds = None

        if not creds:
            if not GOOGLE_CREDENTIALS_FILE.exists():
                console.print(
                    "[bold red]Error:[/bold red] Google credentials not found."
                )
                console.print(
                    f"Please place your 'credentials.json' at [cyan]{GOOGLE_CREDENTIALS_FILE}[/cyan]"
                )
                console.print("You can get them from the Google Cloud Console.")
                return None

            flow = InstalledAppFlow.from_client_secrets_file(
                str(GOOGLE_CREDENTIALS_FILE), SCOPES
            )
            creds = flow.run_local_server(port=0)

        # Save the credentials for the next run
        with open(GOOGLE_TOKEN_FILE, "w") as token:
            token.write(creds.to_json())

    return build("calendar", "v3", credentials=creds)


# Global state
state = {"verbose": False}


class CanvasClient:
    """A persistent client for interacting with the Canvas API."""

    def __init__(self):
        self.session = requests.Session()
        self._headers: dict[str, str] | None = None
        self._base_url: str | None = None
        self._api_url: str | None = None
        # Load environment once
        load_dotenv(ENV_PATH)

    @property
    def base_url(self) -> str:
        if self._base_url is None:
            self._base_url = os.getenv("CANVAS_BASE_URL", DEFAULT_BASE_URL).rstrip("/")
        return self._base_url

    @property
    def api_url(self) -> str:
        if self._api_url is None:
            self._api_url = f"{self.base_url}/api/v1"
        return self._api_url

    def get_headers(self) -> dict[str, str]:
        if self._headers is None:
            token = os.getenv("CANVAS_TOKEN")
            if not token:
                console.print(
                    "[bold red]Error:[/bold red] CANVAS_TOKEN not found in .env."
                )
                console.print(
                    "Run [bold cyan]studium config set-token <YOUR_TOKEN>[/bold cyan] to set it up."
                )
                raise typer.Exit(1)

            token = token.strip().replace(" ", "")
            if state["verbose"]:
                console.print(
                    f"[dim]Debug: Using token starting with {token[:4]}...[/dim]"
                )

            self._headers = {
                "Authorization": f"Bearer {token}",
                "Accept": "application/json",
                "Content-Type": "application/json",
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            }
        return self._headers

    def get(
        self, endpoint: str, params: dict[str, Any] | None = None, **kwargs
    ) -> requests.Response:
        url = f"{self.api_url}/{endpoint.lstrip('/')}"
        return self.session.get(
            url, headers=self.get_headers(), params=params, **kwargs
        )

    def get_full_url(self, url: str, **kwargs) -> requests.Response:
        return self.session.get(url, headers=self.get_headers(), **kwargs)


class OutputFormat(StrEnum):
    TABLE = "table"
    SKETCHYBAR = "sketchybar"
    JSON = "json"


# Global client instance
client = CanvasClient()


def get_current_version():
    """Get the current version of the installed package."""
    try:
        return version("studium-cli")
    except PackageNotFoundError:
        return "0.0.0"


def get_latest_version():
    """Fetch the latest version number from PyPI."""
    url = "https://pypi.org/pypi/studium-cli/json"
    try:
        response = requests.get(url, timeout=2)
        if response.status_code == 200:
            return response.json()["info"]["version"]
    except Exception:
        return None
    return None


def check_for_updates():
    """Check for updates if it's been more than 24 hours since the last check."""
    # Ensure cache dir exists
    CACHE_DIR.mkdir(parents=True, exist_ok=True)

    now = datetime.now().timestamp()
    try:
        if UPDATE_CHECK_FILE.exists():
            last_check = float(UPDATE_CHECK_FILE.read_text().strip())
            if now - last_check < 86400:  # 24 hours
                return
    except (ValueError, OSError):
        pass

    latest = get_latest_version()
    if latest:
        current = get_current_version()
        if parse_version(latest) > parse_version(current):
            console.print(
                f"\n[bold yellow]󰚰 Update available:[/bold yellow] [cyan]{current}[/cyan] -> [bold green]{latest}[/bold green]"
            )
            console.print(
                "[dim]Run [bold cyan]studium update[/bold cyan] to install the latest version.[/dim]\n"
            )

    # Save last check time
    try:
        UPDATE_CHECK_FILE.write_text(str(now))
    except OSError:
        pass


config_app = typer.Typer(
    help="Manage configuration and authentication",
    context_settings={"help_option_names": ["-h", "--help"]},
)
app.add_typer(config_app, name="config")


def version_callback(value: bool):
    if value:
        current = get_current_version()
        console.print(f"studium-cli version: [bold cyan]{current}[/bold cyan]")
        raise typer.Exit()


@app.callback()
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        None,
        "--version",
        "-V",
        callback=version_callback,
        is_eager=True,
        help="Show the version and exit.",
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Enable verbose output."
    ),
):
    """Studium CLI tool."""
    if verbose:
        state["verbose"] = True

    # Only check for updates when running main commands, not sub-apps or the update command itself
    if ctx.invoked_subcommand not in ["update", "config", None]:
        check_for_updates()


@config_app.command("set-token")
def set_token(token: str = typer.Argument(..., help="Your Canvas API token")):
    """Save the Canvas API token to the .env file."""
    set_key(ENV_PATH, "CANVAS_TOKEN", token)
    # Reset cached headers
    client._headers = None
    console.print("[bold green]Success![/bold green] Token saved to .env")


@config_app.command("set-url")
def set_url(
    url: str = typer.Argument(
        ..., help="Your Canvas base URL (e.g. https://canvas.instructure.com)"
    ),
):
    """Save the Canvas base URL to the .env file."""
    url = url.strip().rstrip("/")
    set_key(ENV_PATH, "CANVAS_BASE_URL", url)
    # Reset cached base URL
    client._base_url = None
    client._api_url = None
    console.print(
        f"[bold green]Success![/bold green] Base URL set to [cyan]{url}[/cyan]"
    )


@config_app.command("set-github-token")
def set_github_token(
    token: str = typer.Argument(..., help="Your GitHub Personal Access Token"),
):
    """Save the GitHub token to the .env file for Gist synchronization."""
    set_key(str(ENV_PATH), "GITHUB_TOKEN", token)
    console.print("[bold green]Success![/bold green] GitHub token saved to .env")


@config_app.command("status")
def status():
    """Check if the token and URL are configured and valid."""
    try:
        client.get_headers()
        token = os.getenv("CANVAS_TOKEN", "")
        url = client.base_url
    except typer.Exit:
        return

    masked_token = f"{token[:4]}...{token[-4:]}" if len(token) > 8 else "****"
    console.print(f"[yellow]URL:[/yellow] {url}")
    console.print(
        f"[yellow]Token:[/yellow] Found (len: {len(token)}, {masked_token}), verifying..."
    )

    res = client.get("users/self")

    if res.status_code == 200:
        user_data = res.json()
        user_display = user_data.get("login_id") or f"ID: {user_data.get('id')}"
        console.print(
            f"[bold green]Verified:[/bold green] Connected as {user_data.get('name')} ({user_display})"
        )
    else:
        console.print(
            f"[bold red]Invalid Token:[/bold red] API returned {res.status_code}"
        )
        try:
            error_data = res.json()
            error_msg = error_data.get("errors", [{}])[0].get(
                "message", "No specific error message"
            )
            console.print(f"[red]Message from Canvas:[/red] {error_msg}")
        except Exception:
            pass
        if res.status_code == 401:
            console.print(
                "[dim]Tip: Make sure the token is copied exactly and hasn't expired.[/dim]"
            )


def fetch_all_assignments(limit: int = 5):
    """Fetch all upcoming assignments from Canvas API in parallel."""
    courses_res = client.get("courses", params={"enrollment_state": "active"})

    if courses_res.status_code != 200:
        console.print(
            f"[bold red]Error:[/bold red] Could not fetch courses (HTTP {courses_res.status_code})."
        )
        return None

    courses = courses_res.json()
    all_assignments = []

    def fetch_course_assignments(course):
        if "id" not in course:
            return []

        params = {"bucket": "upcoming", "per_page": limit}
        res = client.get(f"courses/{course['id']}/assignments", params=params)

        course_assigns = []
        if res.status_code == 200:
            for a in res.json():
                course_assigns.append(
                    {
                        "course_code": course.get("course_code", "Unknown Course"),
                        "course_name": course.get("name", "Unnamed Course"),
                        "name": a["name"],
                        "due_at": a.get("due_at"),
                        "html_url": a.get("html_url"),
                    }
                )
        return course_assigns

    with ThreadPoolExecutor(max_workers=10) as executor:
        results = list(executor.map(fetch_course_assignments, courses))

    for result in results:
        all_assignments.extend(result)

    return {"last_updated": datetime.now().isoformat(), "assignments": all_assignments}


def notify(title: str, message: str):
    """Send a cross-platform desktop notification."""
    try:
        notification = Notify()
        notification.title = title
        notification.message = message
        notification.application_name = "Studium"
        notification.send()
    except Exception as e:
        if state["verbose"]:
            console.print(f"[dim red]Debug: Notification error: {e}[/dim red]")


def fetch_announcements(limit: int = 5):
    """Fetch recent announcements from all active courses."""
    courses_res = client.get("courses", params={"enrollment_state": "active"})
    if courses_res.status_code != 200:
        return []

    context_codes = [f"course_{c['id']}" for c in courses_res.json() if "id" in c]
    if not context_codes:
        return []

    params = {"context_codes[]": context_codes, "per_page": limit}
    res = client.get("announcements", params=params)

    if res.status_code == 200:
        return [
            {
                "id": a["id"],
                "title": a["title"],
                "course": a.get("context_code", "Unknown Course"),
                "posted_at": a.get("posted_at"),
                "url": a.get("html_url"),
            }
            for a in res.json()
        ]
    return []


def download_file(url: str, filename: str, destination_dir: Path):
    """Download a file with progress bar."""
    res = client.get_full_url(url, stream=True)
    res.raise_for_status()

    total_size = int(res.headers.get("content-length", 0))
    destination_dir.mkdir(parents=True, exist_ok=True)
    file_path = destination_dir / filename

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        DownloadColumn(),
        TransferSpeedColumn(),
        TimeRemainingColumn(),
    ) as progress:
        task = progress.add_task(f"Downloading {filename}", total=total_size)
        with open(file_path, "wb") as f:
            for data in res.iter_content(chunk_size=1024):
                f.write(data)
                progress.update(task, advance=len(data))

    console.print(f"[bold green]Success![/bold green] Downloaded to {file_path}")


@app.command()
def download(
    file_id: int = typer.Argument(..., help="The ID of the file to download."),
    output: Path = typer.Option(Path.cwd(), "--output", "-o", help="Output directory."),
):
    """Download a specific file by its Canvas ID."""
    # Try fetching file info from Canvas API
    res = client.get(f"files/{file_id}")
    if res.status_code != 200:
        console.print(f"[bold red]Error:[/bold red] File {file_id} not found.")
        raise typer.Exit(1)

    file_info = res.json()
    download_url = file_info.get("url")
    filename = file_info.get("display_name")

    if not download_url:
        console.print(
            f"[bold red]Error:[/bold red] Could not get download URL for file {file_id}."
        )
        raise typer.Exit(1)

    download_file(download_url, filename, output)


def fetch_modules(course_id: int):
    """Fetch all modules for a given course."""
    res = client.get(f"courses/{course_id}/modules", params={"include[]": "items"})
    if res.status_code == 200:
        return res.json()
    return []


@app.command()
def modules(
    course_id: int = typer.Argument(..., help="The ID of the course."),
):
    """List all modules and their items for a course."""
    modules_data = fetch_modules(course_id)

    if not modules_data:
        console.print(f"[yellow]No modules found for course {course_id}.[/yellow]")
        return

    for module in modules_data:
        table = Table(title=f"Module: {module['name']}")
        table.add_column("Type", style="cyan")
        table.add_column("Item Name")
        table.add_column("ID", style="dim")

        items = module.get("items", [])
        for item in items:
            table.add_row(
                item["type"],
                item["title"],
                str(item.get("content_id") or item.get("id")),
            )

        console.print(table)
        console.print()


@app.command()
def sync(limit: int = typer.Option(5, help="Number of items per course.")):
    """Fetch data, update cache, and notify of new items."""
    # Load old data for comparison
    old_data = {}
    if CACHE_FILE.exists():
        try:
            with open(CACHE_FILE) as f:
                old_data = json.load(f)
        except Exception:
            pass

    # Fetch new data
    new_assignments_data = fetch_all_assignments(limit)
    new_announcements = fetch_announcements(limit)

    if not new_assignments_data:
        raise typer.Exit(1)

    full_data = {
        "last_updated": datetime.now().isoformat(),
        "assignments": new_assignments_data["assignments"],
        "announcements": new_announcements,
    }

    # Compare and notify
    old_assign_ids = {a.get("html_url") for a in old_data.get("assignments", [])}
    for a in full_data["assignments"]:
        if a.get("html_url") not in old_assign_ids:
            notify("New Assignment", f"[{a['course_code']}] {a['name']}")

    old_announce_ids = {a.get("id") for a in old_data.get("announcements", [])}
    for a in full_data["announcements"]:
        if a.get("id") not in old_announce_ids:
            notify("New Announcement", f"{a['title']}")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    with open(CACHE_FILE, "w") as f:
        json.dump(full_data, f, indent=2)

    console.print(
        "[bold green]Success![/bold green] Sync complete. Notification check finished."
    )
    # Trigger sketchybar update (macOS only)
    if os.uname().sysname == "Darwin":
        os.system("which sketchybar > /dev/null && sketchybar --trigger studium_update")


@app.command()
def courses():
    """List all active courses."""
    res = client.get("courses", params={"enrollment_state": "active"})
    if res.status_code != 200:
        console.print(
            f"[bold red]Error:[/bold red] Could not fetch courses (HTTP {res.status_code})."
        )
        raise typer.Exit(1)

    table = Table(title="Active Courses")
    table.add_column("ID", style="cyan")
    table.add_column("Course Code", style="magenta")
    table.add_column("Name")

    for course in res.json():
        if "course_code" in course:
            course_id = course["id"]
            name = course["name"]
            url = f"{client.base_url}/courses/{course_id}"
            # Rich supports OSC 8 terminal hyperlinks
            linked_name = f"[link={url}]{name}[/link]"
            table.add_row(str(course_id), course["course_code"], linked_name)

    console.print(table)


def get_relative_time(dt: datetime) -> str:
    """Return a human-readable relative time string."""
    now = datetime.now().astimezone()
    diff = dt.astimezone() - now
    seconds = diff.total_seconds()

    if seconds < 0:
        return "Passed"

    days = int(seconds // 86400)
    hours = int((seconds % 86400) // 3600)
    minutes = int((seconds % 3600) // 60)

    if days > 0:
        return f"{days}d {hours}h"
    if hours > 0:
        return f"{hours}h {minutes}m"
    return f"{minutes}m"


@app.command()
def announcements(
    limit: int = typer.Option(10, help="Number of announcements to show."),
):
    """List recent announcements across all courses."""
    data = fetch_announcements(limit)
    if not data:
        console.print("[yellow]No recent announcements found.[/yellow]")
        return

    table = Table(title="Recent Announcements")
    table.add_column("Posted", style="cyan")
    table.add_column("Course", style="magenta")
    table.add_column("Announcement")

    for a in data:
        posted_at = a.get("posted_at", "N/A")
        if posted_at != "N/A":
            dt = datetime.fromisoformat(posted_at.replace("Z", "+00:00"))
            posted_at = dt.astimezone().strftime("%Y-%m-%d %H:%M")

        linked_title = f"[link={a.get('url', '')}]{a.get('title', 'Untitled')}[/link]"
        table.add_row(posted_at, a.get("course", "Unknown"), linked_title)

    console.print(table)


def fetch_courses():
    """Fetch all active courses."""
    res = client.get("courses", params={"enrollment_state": "active"})
    if res.status_code == 200:
        return [c for c in res.json() if "course_code" in c]
    return []


def fetch_assignments(course_id: int):
    """Fetch assignments for a course."""
    res = client.get(f"courses/{course_id}/assignments", params={"per_page": 50})
    if res.status_code == 200:
        return res.json()
    return []


def get_human_due_date(dt: datetime) -> str:
    """Return a very human-friendly due date string."""
    now = datetime.now().astimezone()
    diff = dt.astimezone() - now
    seconds = diff.total_seconds()

    if seconds < 0:
        return "Passed"

    days = diff.days
    if days == 0:
        return "Today"
    if days == 1:
        return "Tomorrow"
    if days < 7:
        return f"in {days} days"
    if days < 30:
        weeks = days // 7
        return f"in {weeks} week{'s' if weeks > 1 else ''}"

    return dt.astimezone().strftime("%b %d")


TYPE_ICONS = {
    "File": "󰈔",
    "Page": "󱔗",
    "Assignment": "󰃭",
    "Discussion": "󰭻",
    "Quiz": "󰗑",
    "ExternalUrl": "󰌷",
    "ExternalTool": "󰓼",
    "SubHeader": "󰓏",
}

# Custom style for a cleaner look
custom_style = Style(
    [
        ("qmark", "fg:#673ab7 bold"),  # Hidden by qmark=""
        ("question", "bold"),
        ("answer", "fg:#00bcd4 bold"),
        ("pointer", "fg:#ff9800 bold"),
        ("highlighted", "fg:#ff9800 bold"),
        ("selected", "fg:#00bcd4"),
        ("separator", "fg:#cc5454"),
        ("instruction", "fg:#888888 italic"),
        ("text", ""),
        ("disabled", "fg:#858585 italic"),
    ]
)


def get_nav_kb():
    """Custom keybindings for browse navigation."""
    kb = KeyBindings()

    @kb.add("q")
    @kb.add("escape")
    def _(event):
        event.app.exit(result=None)

    @kb.add("h")
    def _(event):
        # Map 'h' to the 'back' value used in our choices
        event.app.exit(result="back")

    @kb.add("l")
    def _(event):
        # Trigger enter to select the current item
        event.app.key_processor.feed(
            prompt_toolkit.key_binding.key_processor.KeyPress(Keys.Enter)
        )

    return kb


def select_with_nav(message, choices, instruction):
    """Helper to run questionary.select with custom navigation keybindings."""
    q = questionary.select(
        message,
        choices=choices,
        style=custom_style,
        qmark="",
        instruction=instruction,
    )
    # Merge custom keybindings with the default ones
    q.application.key_bindings = merge_key_bindings(
        [q.application.key_bindings, get_nav_kb()]
    )
    return q.ask()


@app.command()
def browse():
    """Interactively browse courses, modules, and assignments."""
    courses_data = fetch_courses()
    if not courses_data:
        console.print("[yellow]No active courses found.[/yellow]")
        return

    nav_instruction = "(arrows/hjkl to navigate, q/esc to exit)"

    while True:
        console.clear()
        console.print("[bold cyan]󰗑 Studium Browser[/bold cyan]")
        console.print("[dim]Select a course to begin[/dim]\n")

        course_choices = [
            questionary.Choice(
                title=f" {c['course_code']} {c['name']}",
                value=c,
            )
            for c in courses_data
        ]
        course_choices.append(questionary.Choice(title=" 󰈆 [ Exit ]", value="exit"))

        selected_course = select_with_nav("Course:", course_choices, nav_instruction)

        # Handle q/esc (None) or explicit exit
        if selected_course in [None, "exit"]:
            break

        # 'h' at the top level should also exit
        if selected_course == "back":
            break

        course_id = selected_course["id"]
        course_code = selected_course["course_code"]

        while True:
            console.clear()
            console.print(f"[bold cyan]󰗑 {course_code}[/bold cyan] [dim]>[/dim]")
            console.print(f"[dim]{selected_course['name']}[/dim]\n")

            category = select_with_nav(
                "Navigate:",
                [
                    "󰏗 Modules",
                    "󰃭 Assignments",
                    "󰌷 Open in Browser",
                    "󰁮 Back",
                ],
                nav_instruction,
            )

            if category in [None, "󰁮 Back", "back"]:
                break

            if category == "󰌷 Open in Browser":
                webbrowser.open(f"{client.base_url}/courses/{course_id}")
                continue

            if category == "󰏗 Modules":
                modules_data = fetch_modules(course_id)
                if not modules_data:
                    console.print("[yellow]No modules found.[/yellow]")
                    continue

                while True:
                    module_choices = [
                        questionary.Choice(title=f" 󰏗 {m['name']}", value=m)
                        for m in modules_data
                    ]
                    module_choices.append(
                        questionary.Choice(title=" 󰁮 Back", value="back")
                    )

                    selected_module = select_with_nav(
                        "Module:", module_choices, nav_instruction
                    )

                    if selected_module in [None, "back"]:
                        break

                    while True:
                        item_choices = []
                        for i in selected_module.get("items", []):
                            icon = TYPE_ICONS.get(i["type"], "󰅙")
                            item_choices.append(
                                questionary.Choice(
                                    title=f" {icon} {i['title']}", value=i
                                )
                            )
                        item_choices.append(
                            questionary.Choice(title=" 󰁮 Back", value="back")
                        )

                        selected_item = select_with_nav(
                            "Item:", item_choices, nav_instruction
                        )

                        if selected_item in [None, "back"]:
                            break

                        # Actions
                        if selected_item["type"] == "File":
                            action = select_with_nav(
                                "Action:",
                                [
                                    "󰇚 Download",
                                    "󰌷 Open in Browser",
                                    "󰁮 Back",
                                ],
                                nav_instruction,
                            )

                            if action in [None, "󰁮 Back", "back"]:
                                continue

                            if action == "󰇚 Download":
                                file_id = selected_item.get(
                                    "content_id"
                                ) or selected_item.get("id")
                                res = client.get(f"files/{file_id}")
                                if res.status_code == 200:
                                    f_info = res.json()
                                    download_file(
                                        f_info["url"],
                                        f_info["display_name"],
                                        Path.cwd(),
                                    )
                                else:
                                    console.print(
                                        "[red]Could not fetch file info for download.[/red]"
                                    )
                            elif action == "󰌷 Open in Browser":
                                webbrowser.open(selected_item["html_url"])
                        elif selected_item["type"] == "SubHeader":
                            continue
                        else:
                            webbrowser.open(selected_item["html_url"])

            if category == "󰃭 Assignments":
                assignments_data = fetch_assignments(course_id)
                if not assignments_data:
                    console.print("[yellow]No assignments found.[/yellow]")
                    continue

                while True:
                    assign_choices = []
                    for a in assignments_data:
                        due_str = ""
                        if a.get("due_at"):
                            due_date = datetime.fromisoformat(
                                a["due_at"].replace("Z", "+00:00")
                            )
                            due_str = f" ({get_human_due_date(due_date)})"
                        assign_choices.append(
                            questionary.Choice(
                                title=f" 󰃭 {a['name']}{due_str}", value=a
                            )
                        )
                    assign_choices.append(
                        questionary.Choice(title=" 󰁮 Back", value="back")
                    )

                    selected_assign = select_with_nav(
                        "Assignment:", assign_choices, nav_instruction
                    )

                    if selected_assign in [None, "back"]:
                        break

                    webbrowser.open(selected_assign["html_url"])


@app.command()
def browser(
    id: str = typer.Argument(
        "latest", help="Course ID, Assignment ID, or 'latest' for closest deadline."
    ),
):
    """Open a course or assignment in the browser."""
    url = f"{client.base_url}"

    if id == "latest":
        if CACHE_FILE.exists():
            with open(CACHE_FILE) as f:
                data = json.load(f)

            assigns = data.get("assignments", [])
            if assigns:
                # Sort by due_at
                valid_assigns = [a for a in assigns if a.get("due_at")]
                if valid_assigns:
                    latest = min(
                        valid_assigns,
                        key=lambda x: datetime.fromisoformat(
                            x["due_at"].replace("Z", "+00:00")
                        ),
                    )
                    url = latest.get("html_url", url)
        else:
            console.print("[yellow]Cache not found. Run 'studium sync' first.[/yellow]")
            return
    elif id.isdigit():
        # Heuristic: IDs > 100000 are likely courses or assignments
        # In Canvas, /courses/ID or /assignments/ID works if you have the full URL,
        # but here we just try to guess if it's a course.
        url = f"{client.base_url}/courses/{id}"

    console.print(f"Opening [link={url}]{url}[/link]...")
    webbrowser.open(url)


@app.command()
def assignments(
    limit: int = typer.Option(5, help="Number of assignments per course."),
    format: OutputFormat = typer.Option(OutputFormat.TABLE, help="Output format."),
    force: bool = typer.Option(False, "--force", "-f", help="Force refresh from API."),
    course: str = typer.Option(None, "--course", "-c", help="Filter by course code."),
):
    """List upcoming assignments."""
    # Use cache if available and not forced
    if not force and CACHE_FILE.exists():
        if state["verbose"]:
            console.print("[dim]Debug: Loading data from cache...[/dim]")
        with open(CACHE_FILE) as f:
            data = json.load(f)
    else:
        # Refresh cache
        if state["verbose"]:
            console.print("[dim]Debug: Fetching fresh data from API...[/dim]")
        data = fetch_all_assignments(limit)
        if not data:
            raise typer.Exit(1)
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        with open(CACHE_FILE, "w") as f:
            json.dump(data, f, indent=2)

    assignments_list = data.get("assignments", [])

    # Filter by course
    if course:
        course = course.lower()
        assignments_list = [
            a
            for a in assignments_list
            if course in a.get("course_code", "").lower()
            or course in a.get("course_name", "").lower()
        ]

    if format == OutputFormat.JSON:
        console.print_json(json.dumps(data))
    elif format == OutputFormat.SKETCHYBAR:
        count = len(assignments_list)
        # Use an icon + count format for Sketchybar
        icon = "󰑫"
        if count == 0:
            console.print(f"{icon} 0")
        else:
            console.print(f"{icon} {count}")
    else:
        # Default: Table
        table = Table(
            title=f"Upcoming Assignments (Cached: {data.get('last_updated', 'Unknown')})"
        )
        table.add_column("Course", style="green")
        table.add_column("Assignment", style="yellow")
        table.add_column("Due Date")
        table.add_column("Due In", style="bold cyan")

        now = datetime.now()

        for a in assignments_list:
            due_at_str = a.get("due_at")
            due_display = "No Date"
            due_in = "N/A"
            style = ""

            if due_at_str:
                try:
                    # Canvas uses ISO format with Z (UTC)
                    due_date = datetime.fromisoformat(due_at_str.replace("Z", "+00:00"))
                    # Convert to local time for comparison
                    due_date_local = due_date.astimezone()
                    diff = due_date_local - now.astimezone()

                    due_display = due_date_local.strftime("%Y-%m-%d %H:%M")
                    due_in = get_relative_time(due_date_local)

                    if diff.total_seconds() < 0:
                        style = "dim red"
                        due_display += " (OVERDUE)"
                        due_in = "Passed"
                    elif diff.days < 1:
                        style = "bold red"
                    elif diff.days < 3:
                        style = "yellow"
                except Exception as e:
                    if state["verbose"]:
                        console.print(
                            f"[dim red]Debug: Error parsing date: {e}[/dim red]"
                        )
                    due_display = due_at_str

            table.add_row(
                a.get("course_code", "Unknown"),
                f"[link={a.get('html_url', '')}]{a.get('name', 'Untitled')}[/link]",
                due_display,
                due_in,
                style=style,
            )
        console.print(table)


@app.command()
def update(
    force: bool = typer.Option(
        False, "--force", "-f", help="Force reinstall even if already up to date"
    ),
):
    """Update the CLI to the latest version from PyPI."""
    console.print("Checking for updates on PyPI...")
    current = get_current_version()
    latest = get_latest_version()

    if not force:
        if latest is None:
            console.print(
                "[bold yellow]Warning:[/bold yellow] Could not check for updates. Make sure you have an internet connection."
            )
            return

        if parse_version(current) >= parse_version(latest):
            console.print(
                f"[bold green]You are already on the latest version ({current}).[/bold green]"
            )
            console.print("Use [cyan]--force[/cyan] to force a reinstallation.")
            return

    if force:
        console.print("[bold yellow]Forcing reinstall...[/bold yellow]")

    console.print(f"Current version: [bold cyan]{current}[/bold cyan]")
    if latest:
        console.print(f"Latest version: [bold green]{latest}[/bold green]")

    target_version = latest if latest else "latest"
    console.print(f"Updating to [bold green]{target_version}[/bold green]...")

    try:
        if force:
            # Force reinstall specific version
            cmd = [
                "uv",
                "tool",
                "install",
                "--reinstall",
                f"studium-cli=={target_version}",
            ]
        else:
            # Standard upgrade
            cmd = ["uv", "tool", "upgrade", "studium-cli"]

        console.print(f"Running: [bold cyan]{' '.join(cmd)}[/bold cyan]")

        # We use check=True to raise an exception if the command fails
        subprocess.run(cmd, check=True)

        console.print(
            f"[bold green]Success![/bold green] Studium has been updated to {target_version}."
        )
    except subprocess.CalledProcessError as e:
        console.print(
            f"[bold red]Error:[/bold red] Update failed with exit code {e.returncode}."
        )
        console.print(
            "Try running the command manually: [cyan]uv tool install studium-cli[/cyan]"
        )
    except FileNotFoundError:
        console.print(
            "[bold red]Error:[/bold red] 'uv' command not found. Please install uv first."
        )


# Calendar integration
calendar_app = typer.Typer(help="Calendar integration commands.")
app.add_typer(calendar_app, name="calendar")


def sync_gist(content: str):
    """Sync the .ics content to a GitHub Gist."""
    token = os.getenv("GITHUB_TOKEN")
    if not token:
        console.print(
            "[bold yellow]Warning:[/bold yellow] GITHUB_TOKEN not set. Skipping Gist sync."
        )
        console.print(
            "Run [bold cyan]studium config set-github-token <TOKEN>[/bold cyan] to enable."
        )
        return

    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
    }

    gist_id = os.getenv("GITHUB_GIST_ID")
    filename = "studium_assignments.ics"

    data = {
        "description": "Canvas Assignments (Studium CLI)",
        "files": {filename: {"content": content}},
    }

    try:
        if gist_id:
            # Update existing gist
            url = f"https://api.github.com/gists/{gist_id}"
            res = requests.patch(url, headers=headers, json=data)
        else:
            # Create new secret gist
            url = "https://api.github.com/gists"
            data["public"] = False
            res = requests.post(url, headers=headers, json=data)

        if res.status_code in [200, 201]:
            new_gist_id = res.json()["id"]
            raw_url = res.json()["files"][filename]["raw_url"]
            if not gist_id:
                set_key(str(ENV_PATH), "GITHUB_GIST_ID", new_gist_id)

            console.print("[bold green]Success![/bold green] Gist updated.")
            console.print(f"Raw URL for subscription: [bold cyan]{raw_url}[/bold cyan]")
        else:
            console.print(
                f"[bold red]Error syncing to Gist:[/bold red] {res.status_code} - {res.text}"
            )
    except Exception as e:
        console.print(f"[bold red]Error syncing to Gist:[/bold red] {e}")


@calendar_app.command("export")
def calendar_export(
    file: Path = typer.Option(
        Path("studium_assignments.ics"),
        "--file",
        "-f",
        help="The output .ics file path.",
    ),
    limit: int = typer.Option(10, help="Number of assignments per course to fetch."),
    gist: bool = typer.Option(
        True, help="Automatically sync to GitHub Gist if token is set."
    ),
):
    """Export upcoming assignments to an iCalendar (.ics) file."""
    console.print("[cyan]Fetching assignments...[/cyan]")
    data = fetch_all_assignments(limit=limit)

    if not data or not data.get("assignments"):
        console.print("[yellow]No upcoming assignments found to export.[/yellow]")
        return

    c = Calendar()
    for a in data["assignments"]:
        if not a.get("due_at"):
            continue

        e = Event()
        e.name = a.get("name", "Assignment")
        e.begin = a["due_at"]
        e.make_all_day()
        e.description = f"Link: {a.get('html_url', 'No URL')}"
        c.events.add(e)

    serialized = "".join(c.serialize_iter())

    try:
        with open(file, "w") as f:
            f.write(serialized)
        console.print(
            f"[bold green]Success![/bold green] Calendar exported to [cyan]{file}[/cyan]"
        )
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] Could not write to file: {e}")

    if gist:
        sync_gist(serialized)


@calendar_app.command("setup-google")
def calendar_setup_google():
    """Set up Google Calendar integration."""
    service = get_google_service()
    if not service:
        return

    try:
        # Fetch list of calendars
        calendar_list = service.calendarList().list().execute()
        calendars = calendar_list.get("items", [])

        if not calendars:
            console.print("[yellow]No calendars found.[/yellow]")
            return

        choices = [{"name": c["summary"], "value": c["id"]} for c in calendars]
        choices.append({"name": "[Create New 'Studium' Calendar]", "value": "NEW"})

        selected_id = questionary.select(
            "Which calendar should Studium sync with?",
            choices=choices,
        ).ask()

        if selected_id == "NEW":
            new_calendar = {"summary": "Studium"}
            created_calendar = service.calendars().insert(body=new_calendar).execute()
            selected_id = created_calendar["id"]
            console.print(
                f"[bold green]Created new calendar:[/bold green] {selected_id}"
            )

        set_key(str(ENV_PATH), "GOOGLE_CALENDAR_ID", selected_id)
        console.print(
            f"[bold green]Google Calendar ID set to:[/bold green] {selected_id}"
        )
        console.print(
            "\n[bold cyan]Tip:[/bold cyan] Run [bold green]studium calendar schedule[/bold green] to automatically sync in the background."
        )

    except HttpError as error:
        console.print(f"[bold red]Google API error:[/bold red] {error}")


@calendar_app.command("schedule")
def calendar_schedule():
    """Set up a background task to sync Google Calendar every 2 hours."""
    # Determine the command to run
    # If installed as a tool, 'studium' should be in the path.
    # We want to run both 'sync' (for notifications) and 'calendar sync-google'
    # We'll create a small shell script in the config dir to run both.
    sync_script = CONFIG_DIR / "sync_all.sh"
    studium_bin = shutil.which("studium") or f"{sys.executable} -m studium.cli"

    script_content = (
        f"#!/bin/bash\n{studium_bin} sync\n{studium_bin} calendar sync-google\n"
    )

    with open(sync_script, "w") as f:
        f.write(script_content)
    sync_script.chmod(0o755)

    if sys.platform == "darwin":
        plist_path = Path.home() / "Library" / "LaunchAgents" / "com.studium.sync.plist"
        plist_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <key>ProgramArguments</key>
    <array>
        <string>/bin/bash</string>
        <string>{sync_script}</string>
    </array>
    <key>StartInterval</key>
    <integer>7200</integer>
    <key>RunAtLoad</key>
    <true/>
    <key>StandardErrorPath</key>
    <string>{CACHE_DIR}/sync_error.log</string>
    <key>StandardOutPath</key>
    <string>{CACHE_DIR}/sync_output.log</string>
</dict>
</plist>
"""
        with open(plist_path, "w") as f:
            f.write(plist_content)

        # Load the agent
        subprocess.run(["launchctl", "unload", str(plist_path)], capture_output=True)
        subprocess.run(["launchctl", "load", str(plist_path)], capture_output=True)
        console.print(
            f"[bold green]Success![/bold green] LaunchAgent created at [cyan]{plist_path}[/cyan]"
        )
        console.print("Studium will now sync every 2 hours in the background.")

    elif sys.platform == "linux":
        systemd_user_dir = Path.home() / ".config" / "systemd" / "user"
        systemd_user_dir.mkdir(parents=True, exist_ok=True)

        service_path = systemd_user_dir / "studium-sync.service"
        timer_path = systemd_user_dir / "studium-sync.timer"

        service_content = f"""[Unit]
Description=Studium Canvas Sync Service

[Service]
ExecStart=/bin/bash {sync_script}

[Install]
WantedBy=default.target
"""
        timer_content = """[Unit]
Description=Timer for Studium Canvas Sync

[Timer]
OnBootSec=5min
OnUnitActiveSec=2h
RandomizedDelaySec=5min

[Install]
WantedBy=timers.target
"""
        with open(service_path, "w") as f:
            f.write(service_content)
        with open(timer_path, "w") as f:
            f.write(timer_content)

        subprocess.run(["systemctl", "--user", "daemon-reload"])
        subprocess.run(["systemctl", "--user", "enable", "studium-sync.timer"])
        subprocess.run(["systemctl", "--user", "start", "studium-sync.timer"])

        console.print("[bold green]Success![/bold green] Systemd timer enabled.")
        console.print("Studium will now sync every 2 hours in the background.")
    else:
        console.print(
            f"[bold red]Error:[/bold red] Background scheduling is not supported on {sys.platform}."
        )


@calendar_app.command("sync-google")
def calendar_sync_google(
    limit: int = typer.Option(10, help="Number of assignments per course to fetch."),
):
    """Synchronize upcoming assignments with Google Calendar."""
    service = get_google_service()
    if not service:
        return

    calendar_id = os.getenv("GOOGLE_CALENDAR_ID")
    if not calendar_id:
        console.print("[bold red]Error:[/bold red] GOOGLE_CALENDAR_ID not set.")
        console.print("Run [bold cyan]studium calendar setup-google[/bold cyan] first.")
        return

    console.print("[cyan]Fetching assignments from Canvas...[/cyan]")
    canvas_data = fetch_all_assignments(limit=limit)
    if not canvas_data or not canvas_data.get("assignments"):
        console.print("[yellow]No upcoming assignments found.[/yellow]")
        return

    assignments = canvas_data["assignments"]

    try:
        # Fetch existing events from the calendar (to avoid duplicates)
        # We search for events with a specific private property or just filter by time
        now = datetime.now(UTC).isoformat().replace("+00:00", "Z")
        events_result = (
            service.events()
            .list(
                calendarId=calendar_id,
                timeMin=now,
                singleEvents=True,
                orderBy="startTime",
            )
            .execute()
        )
        existing_events = events_result.get("items", [])

        # Map existing events by our custom property "canvas_url"
        # Since we can't easily use privateExtendedProperties without complex setup,
        # we'll use the description to store the URL as a fallback or just use simple matching.
        # For simplicity, let's use the summary + description match.

        synced_count = 0
        for a in assignments:
            if not a.get("due_at"):
                continue

            summary = a.get("name", "Assignment")
            description = f"Canvas Link: {a.get('html_url')}"

            # Simple check if already exists
            exists = any(
                e.get("summary") == summary and e.get("description") == description
                for e in existing_events
            )

            if not exists:
                # For all-day events, Google expects start.date and end.date (exclusive end)
                # a["due_at"] is e.g. "2024-04-10T23:59:59Z"
                dt = datetime.fromisoformat(a["due_at"].replace("Z", "+00:00"))
                start_date = dt.strftime("%Y-%m-%d")
                end_date = (dt + timedelta(days=1)).strftime("%Y-%m-%d")

                event = {
                    "summary": summary,
                    "description": description,
                    "start": {
                        "date": start_date,
                    },
                    "end": {
                        "date": end_date,
                    },
                }
                service.events().insert(calendarId=calendar_id, body=event).execute()
                synced_count += 1
                if state["verbose"]:
                    console.print(f"Synced: {summary}")

        console.print(
            f"[bold green]Successfully synced {synced_count} new assignments to Google Calendar.[/bold green]"
        )

    except HttpError as error:
        console.print(f"[bold red]Google API error:[/bold red] {error}")


if __name__ == "__main__":
    app()
