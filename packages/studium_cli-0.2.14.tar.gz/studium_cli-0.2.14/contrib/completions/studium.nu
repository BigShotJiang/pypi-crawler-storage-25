# Nushell completions for Studium CLI
module studium {
    export def main [] {
        studium --help
    }

    export def "studium sync" [
        --limit: int # Number of items per course
    ]

    export def "studium courses" []

    export def "studium announcements" [
        --limit: int # Number of announcements to show
    ]

    export def "studium update" []

    export def "studium browser" [
        id: string = "latest" # Course ID, Assignment ID, or 'latest'
    ]

    export def "studium assignments" [
        --limit: int # Number of assignments per course
        --format: string # Output format (table, sketchybar, json)
        --force # Force refresh from API
        --course: string # Filter by course code
    ]

    export def "studium config" []
    export def "studium config set-token" [
        token: string # Your Canvas API token
    ]
    export def "studium config status" []
}

use studium *
