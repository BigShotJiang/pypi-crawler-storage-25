# Linux Integration for Studium

This directory contains configuration for Linux users to integrate `studium` into their desktop environment.

## Automation (systemd)
Instead of `cron`, most modern Linux distributions (like Debian) use `systemd` timers. These are more robust and can be managed easily.

### Setup
1. Copy the files to your local systemd configuration:
   ```bash
   mkdir -p ~/.config/systemd/user
   cp studium-sync.* ~/.config/systemd/user/
   ```

2. Check the path in `studium-sync.service`:
   The default `ExecStart` is `%h/.local/bin/studium`. If you installed via `uv tool install`, you may need to change it to `%h/.cargo/bin/studium`. Check with `which studium`.

3. Enable and start the timer:
   ```bash
   systemctl --user daemon-reload
   systemctl --user enable --now studium-sync.timer
   ```

### Status check
```bash
systemctl --user status studium-sync.timer
systemctl --user list-timers --user
```

## Status Bars
For configuration snippets for Polybar, Waybar, and other status bars, see the main [README.md](../../README.md#linux-status-bars-polybar-waybar-etc).
