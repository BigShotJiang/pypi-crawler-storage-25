#!/bin/bash

# Fetch the formatted string from your CLI (using the cache)
# Note: Ensure 'studium' is in your PATH or use the full path.
# Full path is recommended for Sketchybar: /Users/$(whoami)/.local/bin/studium
# Or if installed via uv: /Users/$(whoami)/.cargo/bin/studium (depending on setup)

OUTPUT=$(studium assignments --format sketchybar)

# Update Sketchybar
# $NAME is passed by Sketchybar when the script is called
sketchybar --set $NAME label="$OUTPUT"
