# Sketchybar Integration for Studium

This directory contains scripts to integrate the `studium` CLI with [Sketchybar](https://github.com/FelixKratz/SketchyBar) on macOS.

## Setup

### 1. Install the Plugin
Copy `plugin.sh` to your Sketchybar plugins directory:

```bash
cp plugin.sh ~/.config/sketchybar/plugins/studium.sh
chmod +x ~/.config/sketchybar/plugins/studium.sh
```

### 2. Configure Sketchybar
Add the following to your `~/.config/sketchybar/sketchybarrc` or a separate item file:

```bash
# Register the studium item
sketchybar --add item studium right \
           --set studium update_obj=60 \
           --set studium script="$PLUGIN_DIR/studium.sh" \
           --set studium icon="󰑫" \
           --set studium icon.color=0xffeed49f \
           --set studium label.padding_left=5
```

### 3. Automated Sync (Cron)
Since `sketchybar` will read from the cache to stay fast, you should set up a cron job to sync with Canvas daily.

Run `crontab -e` and add:
```bash
# Sync Canvas assignments every morning at 9:00 AM
0 9 * * * /Users/YOUR_USERNAME/.local/bin/studium sync > /dev/null 2>&1
```
*(Replace `YOUR_USERNAME` and the path to `studium` as needed. You can find the path with `which studium`.)*

## Troubleshooting
If the icon or label doesn't appear:
- Ensure `studium` is installed and accessible in your shell.
- Run `studium sync` manually once to create the initial cache.
- Check the Sketchybar logs or try running the plugin script manually.
