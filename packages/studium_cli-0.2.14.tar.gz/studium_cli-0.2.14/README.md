# Studium CLI (studium-cli)

A command-line tool for Canvas LMS. While designed with Uppsala University (Studium) as the default, it works with any Canvas instance.

## Installation

### 1. Install using UV (Recommended)

UV is the fastest way to install and manage this tool.

```bash
uv tool install studium-cli
```

### 2. Standard installation (pip)

```bash
pip install studium-cli
```

### From source

```bash
git clone https://github.com/mackrus/studium.git
cd studium
uv tool install .
```

## Features

- **Interactive Browser**: Navigate courses, modules, and assignments with Vim-style (`hjkl`) keys.
- **Assignments**: Beautiful tables with countdown timers and overdue highlighting.
- **Downloads**: Download module files and assignment attachments directly from the CLI.
- **Notifications**: Desktop notifications for new assignments and announcements.
- **Integrations**: Ready-to-use status bar strings for Sketchybar, Polybar, and Waybar.

## Setup

1. **Get an API Token**: Log in to your Canvas instance, go to **Account** > **Settings** > **Approved Integrations**, and click **+ New Access Token**.
2. **Configure the CLI**:

```bash
# Set your token
studium config set-token <YOUR_TOKEN>

# (Optional) Set your Canvas URL if not Uppsala University
studium config set-url https://canvas.your-school.edu
```

3. **Verify Connection**:
```bash
studium config status
```

## Usage

### Interactive Navigation
The easiest way to explore your courses:
```bash
studium browse
```
*(Use arrows or `hjkl` to navigate, `q` or `Esc` to exit)*

### Main Commands
| Command | Description |
| :--- | :--- |
| `studium courses` | List all active courses. |
| `studium assignments` | List upcoming assignments with due dates. |
| `studium announcements` | Show recent announcements across all courses. |
| `studium modules <ID>` | List modules and items for a specific course. |
| `studium download <ID>` | Download a file by its Canvas ID. |
| `studium sync` | Sync data and send desktop notifications. |
| `studium browser` | Open courses or assignments in your default web browser. |
| `studium calendar export` | Export assignments to an .ics file (and sync to Gist). |
| `studium calendar sync-google` | Sync assignments to Google Calendar. |
| `studium calendar schedule` | Set up background sync every 2 hours. |
| `studium update` | Check for and install the latest version. |

## Setup (Calendar Sync)

To get a live, auto-updating subscription in Apple Calendar or Outlook:

1. **GitHub Token**: Generate a [Personal Access Token](https://github.com/settings/tokens) (with `gist` scope).
2. **Configure**:
```bash
studium config set-github-token <YOUR_GITHUB_TOKEN>
```
3. **Sync**:
```bash
studium calendar export
```
4. **Subscribe**: Copy the **Raw URL** provided in the output and add it as a "New Calendar Subscription" in your calendar app.


## Extensions

### Status Bars (Sketchybar, Polybar, Waybar)
The CLI can output formatted strings for status bars using `studium assignments --format sketchybar`.

#### Sketchybar (macOS)
Integration scripts are available in the [`contrib/sketchybar/`](contrib/sketchybar/) directory.

#### Linux Bars
Add a custom module that executes `studium assignments --format sketchybar` (outputs e.g., `󰑫 3`).

## Development

```bash
# Run locally
uv run studium <command>

# Run tests
uv run pytest
```
