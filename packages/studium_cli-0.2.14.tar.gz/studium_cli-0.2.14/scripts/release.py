import os
import subprocess
import sys
import tomllib
from pathlib import Path

import click
from dotenv import load_dotenv


def run_command(cmd, description):
    """Run a shell command and handle errors."""
    click.echo(f"{description}...")
    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as e:
        click.echo(click.style(f"Error during {description}:", fg="red"), err=True)
        click.echo(e.stderr, err=True)
        sys.exit(1)


def get_current_version():
    with open("pyproject.toml", "rb") as f:
        data = tomllib.load(f)
        return data["project"]["version"]


def get_next_patch_version(current_version):
    """Bumps the patch version of a semver string."""
    try:
        major, minor, patch = map(int, current_version.split("."))
        return f"{major}.{minor}.{patch + 1}"
    except (ValueError, AttributeError):
        return None


@click.command()
@click.argument("version", required=False)
@click.option("--no-publish", is_flag=True, help="Skip the PyPI upload step.")
def release(version, no_publish):
    """Release a new version of studium-cli."""
    current_version = get_current_version()
    click.echo(f"Current version: {click.style(current_version, fg='cyan')}")

    if not version:
        version = get_next_patch_version(current_version)
        if not version:
            version = click.prompt("Could not auto-bump version. Enter new version")
        else:
            click.echo(f"Auto-bumping to: {click.style(version, fg='green')}")

    # 1. Run Tests
    run_command(["uv", "run", "pytest"], "Running tests")

    # 2. Run Linting
    run_command(["uv", "run", "ruff", "check", "."], "Linting")

    # 3. Update pyproject.toml
    click.echo(f"Updating version to {version}...")
    pyproject_path = Path("pyproject.toml")
    content = pyproject_path.read_text()
    new_content = content.replace(f'version = "{current_version}"', f'version = "{version}"')
    pyproject_path.write_text(new_content)

    # 4. Commit and Tag
    run_command(["git", "add", "pyproject.toml"], "Staging pyproject.toml")
    run_command(["git", "commit", "-m", f"chore: release v{version}"], f"Committing v{version}")
    run_command(["git", "tag", "-a", f"v{version}", "-m", f"Version {version}"], f"Tagging v{version}")

    # 5. Build
    if Path("dist").exists():
        import shutil
        click.echo("Cleaning old builds...")
        shutil.rmtree("dist")
    run_command(["uv", "build"], "Building package")

    # 6. Publish
    if not no_publish:
        token = os.getenv("UV_PUBLISH_TOKEN")
        if not token:
            load_dotenv(".envrc")
            token = os.getenv("UV_PUBLISH_TOKEN")

        if not token:
            click.echo(click.style("Warning: UV_PUBLISH_TOKEN not found.", fg="yellow"))

        click.echo("Publishing to PyPI...")
        # Note: We don't use run_command here because we want to see the interactive output if token is missing
        try:
            subprocess.run(["uv", "publish"], check=True)
        except subprocess.CalledProcessError:
            click.echo(click.style("Publishing failed!", fg="red"), err=True)
            sys.exit(1)
    else:
        click.echo("Skipping PyPI publish.")

    click.echo(click.style(f"Successfully released v{version}!", fg="green", bold=True))


if __name__ == "__main__":
    release()
