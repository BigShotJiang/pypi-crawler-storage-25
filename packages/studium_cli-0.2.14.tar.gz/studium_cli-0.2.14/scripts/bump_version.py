import re
from pathlib import Path


def bump_patch_version():
    pyproject_path = Path("pyproject.toml")
    if not pyproject_path.exists():
        print("Error: pyproject.toml not found")
        return

    content = pyproject_path.read_text()

    # Simple regex to find the version line in [project] section
    match = re.search(r'version = "(\d+)\.(\d+)\.(\d+)"', content)
    if not match:
        print("Error: version string not found in pyproject.toml")
        return

    major, minor, patch = map(int, match.groups())
    new_version = f"{major}.{minor}.{patch + 1}"

    new_content = re.sub(
        r'version = "\d+\.\d+\.\d+"', f'version = "{new_version}"', content, count=1
    )

    pyproject_path.write_text(new_content)
    print(f"Bumped version from {major}.{minor}.{patch} to {new_version}")


if __name__ == "__main__":
    bump_patch_version()
