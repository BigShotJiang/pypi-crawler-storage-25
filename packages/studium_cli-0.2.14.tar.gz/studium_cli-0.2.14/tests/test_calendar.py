from typer.testing import CliRunner

from studium.cli import app

runner = CliRunner()


def test_calendar_export_success(mocker, tmp_path):
    mock_assignments = {
        "last_updated": "2024-04-04T12:00:00",
        "assignments": [
            {
                "course_code": "MATH101",
                "name": "Homework 1",
                "due_at": "2024-04-10T23:59:59Z",
                "html_url": "https://canvas.example.com/courses/1/assignments/1",
            }
        ],
    }
    mocker.patch("studium.cli.fetch_all_assignments", return_value=mock_assignments)

    export_file = tmp_path / "test.ics"
    result = runner.invoke(app, ["calendar", "export", "--file", str(export_file)])

    assert result.exit_code == 0
    assert "Success!" in result.stdout
    assert export_file.exists()

    content = export_file.read_text()
    assert "Homework 1" in content
    assert "https://canvas.example.com/courses/1/assignments/1" in content


def test_calendar_export_no_assignments(mocker, tmp_path):
    mocker.patch("studium.cli.fetch_all_assignments", return_value={"assignments": []})

    export_file = tmp_path / "empty.ics"
    result = runner.invoke(app, ["calendar", "export", "--file", str(export_file)])

    assert result.exit_code == 0
    assert "No upcoming assignments found" in result.stdout
    assert not export_file.exists()


def test_calendar_sync_google_success(mocker):
    mock_assignments = {
        "assignments": [
            {
                "course_code": "CS101",
                "name": "Project",
                "due_at": "2024-05-01T10:00:00Z",
                "html_url": "https://canvas.example.com/cs101",
            }
        ]
    }
    mocker.patch("studium.cli.fetch_all_assignments", return_value=mock_assignments)
    mocker.patch("os.getenv", return_value="mock_calendar_id")

    # Mock Google Service
    mock_service = mocker.Mock()
    mocker.patch("studium.cli.get_google_service", return_value=mock_service)

    # Mock events().list().execute()
    mock_service.events().list().execute.return_value = {"items": []}

    # Mock events().insert().execute()
    mock_service.events().insert().execute.return_value = {}

    result = runner.invoke(app, ["calendar", "sync-google"])

    assert result.exit_code == 0
    assert "Successfully synced 1 new assignments" in result.stdout
    assert mock_service.events().insert.called


def test_calendar_export_with_gist_sync(mocker, tmp_path):
    mock_assignments = {
        "assignments": [{"due_at": "2024-04-10T23:59:59Z", "name": "Test"}]
    }
    mocker.patch("studium.cli.fetch_all_assignments", return_value=mock_assignments)
    mocker.patch(
        "os.getenv",
        side_effect=lambda k, d=None: "fake_github_token" if k == "GITHUB_TOKEN" else d,
    )

    mock_post = mocker.patch("requests.post")
    mock_post.return_value.status_code = 201
    mock_post.return_value.json.return_value = {
        "id": "new_gist_id",
        "files": {"studium_assignments.ics": {"raw_url": "https://raw.gist.com/test"}},
    }

    mocker.patch("studium.cli.set_key")

    export_file = tmp_path / "gist_test.ics"
    result = runner.invoke(app, ["calendar", "export", "--file", str(export_file)])

    assert result.exit_code == 0
    assert "Gist updated" in result.stdout
    assert "https://raw.gist.com/test" in result.stdout
    assert mock_post.called
