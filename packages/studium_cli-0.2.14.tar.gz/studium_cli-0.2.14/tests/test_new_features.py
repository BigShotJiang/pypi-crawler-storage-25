import pytest
from typer.testing import CliRunner

from studium.cli import app

runner = CliRunner()


@pytest.fixture
def mock_headers(mocker):
    return mocker.patch(
        "studium.cli.CanvasClient.get_headers",
        return_value={"Authorization": "Bearer fake"},
    )


def test_config_set_url(mocker, tmp_path):
    env_path = tmp_path / ".env"
    mocker.patch("studium.cli.ENV_PATH", env_path)
    mock_set_key = mocker.patch("studium.cli.set_key")

    result = runner.invoke(app, ["config", "set-url", "https://canvas.example.com"])
    assert result.exit_code == 0
    assert "Base URL set to https://canvas.example.com" in result.stdout
    mock_set_key.assert_called_once_with(
        env_path, "CANVAS_BASE_URL", "https://canvas.example.com"
    )


def test_config_status(mock_headers, mocker):
    mocker.patch(
        "os.getenv",
        side_effect=lambda k, d=None: {
            "CANVAS_TOKEN": "fake_token",
            "CANVAS_BASE_URL": "https://canvas.example.com",
        }.get(k, d),
    )
    # Reset client state to ensure it picks up the mocked env
    from studium.cli import client

    client._base_url = None

    mock_get = mocker.patch("studium.cli.CanvasClient.get")
    mock_get.return_code = 200
    mock_get.return_value.status_code = 200
    mock_get.return_value.json.return_value = {
        "name": "Test User",
        "login_id": "testuser",
    }

    result = runner.invoke(app, ["config", "status"])
    assert result.exit_code == 0
    assert "URL: https://canvas.example.com" in result.stdout
    assert "Verified: Connected as Test User (testuser)" in result.stdout


def test_modules_list(mock_headers, mocker):
    mock_get = mocker.patch("studium.cli.CanvasClient.get")
    mock_get.return_value.status_code = 200
    mock_get.return_value.json.return_value = [
        {
            "name": "Module 1",
            "items": [
                {"type": "File", "title": "Lecture 1", "id": 101, "content_id": 1001},
                {"type": "Assignment", "title": "Lab 1", "id": 102},
            ],
        }
    ]

    result = runner.invoke(app, ["modules", "123"])
    assert result.exit_code == 0
    assert "Module: Module 1" in result.stdout
    assert "Lecture 1" in result.stdout
    assert "Lab 1" in result.stdout


def test_download_file_success(mock_headers, mocker, tmp_path):
    mock_get = mocker.patch("studium.cli.CanvasClient.get")
    mock_get_full = mocker.patch("studium.cli.CanvasClient.get_full_url")

    # Mock file info response
    mock_file_info = mocker.Mock()
    mock_file_info.status_code = 200
    mock_file_info.json.return_value = {
        "url": "https://canvas.example.com/download/file",
        "display_name": "test.pdf",
    }

    # Mock download response (streaming)
    mock_download = mocker.Mock()
    mock_download.status_code = 200
    mock_download.headers = {"content-length": "10"}
    mock_download.iter_content.return_value = [b"data"]

    mock_get.return_value = mock_file_info
    mock_get_full.return_value = mock_download

    output_dir = tmp_path / "downloads"
    result = runner.invoke(app, ["download", "1001", "--output", str(output_dir)])

    assert result.exit_code == 0
    assert "Downloaded to" in result.stdout
    assert (output_dir / "test.pdf").exists()
