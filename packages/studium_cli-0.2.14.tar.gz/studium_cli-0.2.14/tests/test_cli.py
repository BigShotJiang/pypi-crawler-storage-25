from datetime import datetime, timedelta

import pytest
from typer.testing import CliRunner

from studium.cli import app

runner = CliRunner()


@pytest.fixture
def mock_headers(mocker):
    return mocker.patch(
        "studium.cli.CanvasClient.get_headers",
        return_value={"Authorization": "Bearer fake"},
    )


def test_courses_error_no_token(mocker):
    mocker.patch("studium.cli.CanvasClient.get_headers", side_effect=SystemExit(1))
    result = runner.invoke(app, ["courses"])
    assert result.exit_code != 0


def test_courses_success(mock_headers, mocker):
    mock_get = mocker.patch("studium.cli.CanvasClient.get")
    mock_get.return_value.status_code = 200
    mock_get.return_value.json.return_value = [
        {"id": 1, "course_code": "TEST101", "name": "Intro to Testing"}
    ]

    result = runner.invoke(app, ["courses"])
    assert result.exit_code == 0
    assert "TEST101" in result.stdout


def test_assignments_success_fresh(mock_headers, mocker, tmp_path):
    mocker.patch("studium.cli.CACHE_FILE", tmp_path / "assignments.json")
    mock_get = mocker.patch("studium.cli.CanvasClient.get")
    mock_get.side_effect = [
        mocker.Mock(
            status_code=200, json=lambda: [{"id": 1, "course_code": "TEST101"}]
        ),
        mocker.Mock(
            status_code=200,
            json=lambda: [
                {
                    "name": "Assign 1",
                    "due_at": (datetime.now() + timedelta(days=2)).isoformat() + "Z",
                }
            ],
        ),
    ]

    result = runner.invoke(app, ["assignments", "--force"])
    assert result.exit_code == 0
    assert "Assign 1" in result.stdout


def test_assignments_overdue(mock_headers, mocker, tmp_path):
    mocker.patch("studium.cli.CACHE_FILE", tmp_path / "assignments.json")
    past_date = (datetime.now() - timedelta(days=1)).isoformat() + "Z"
    mock_get = mocker.patch("studium.cli.CanvasClient.get")
    mock_get.side_effect = [
        mocker.Mock(
            status_code=200, json=lambda: [{"id": 1, "course_code": "TEST101"}]
        ),
        mocker.Mock(
            status_code=200, json=lambda: [{"name": "Late Task", "due_at": past_date}]
        ),
    ]

    result = runner.invoke(app, ["assignments", "--force"])
    assert result.exit_code == 0
    assert "OVERDUE" in result.stdout


def test_sync_notification(mock_headers, mocker, tmp_path):
    cache_file = tmp_path / "assignments.json"
    mocker.patch("studium.cli.CACHE_FILE", cache_file)
    mock_notify = mocker.patch("studium.cli.notify")

    mocker.patch(
        "studium.cli.fetch_all_assignments",
        return_value={
            "assignments": [{"html_url": "url1", "course_code": "C1", "name": "A1"}]
        },
    )
    mocker.patch("studium.cli.fetch_announcements", return_value=[])

    # First sync
    runner.invoke(app, ["sync"])
    assert mock_notify.call_count == 1

    # Second sync (should NOT notify if same data)
    mock_notify.reset_mock()
    runner.invoke(app, ["sync"])
    assert mock_notify.call_count == 0


def test_browser_latest(mock_headers, mocker, tmp_path):
    cache_file = tmp_path / "assignments.json"
    mocker.patch("studium.cli.CACHE_FILE", cache_file)
    import json

    with open(cache_file, "w") as f:
        json.dump(
            {
                "assignments": [
                    {"html_url": "http://test.com", "due_at": "2026-01-01T00:00:00Z"}
                ]
            },
            f,
        )

    mock_open = mocker.patch("webbrowser.open")
    result = runner.invoke(app, ["browser", "latest"])
    assert result.exit_code == 0
    mock_open.assert_called_with("http://test.com")


def test_update_command_already_latest(mocker):
    mocker.patch("studium.cli.get_current_version", return_value="0.2.2")
    mocker.patch("studium.cli.get_latest_version", return_value="0.2.2")
    mock_run = mocker.patch("subprocess.run")

    result = runner.invoke(app, ["update"])

    assert result.exit_code == 0
    assert "Checking for updates" in result.stdout
    assert "already on the latest version" in result.stdout
    assert "Use --force" in result.stdout
    mock_run.assert_not_called()


def test_update_command_ahead_of_latest(mocker):
    mocker.patch("studium.cli.get_current_version", return_value="0.2.9")
    mocker.patch("studium.cli.get_latest_version", return_value="0.2.8")
    mock_run = mocker.patch("subprocess.run")

    result = runner.invoke(app, ["update"])

    assert result.exit_code == 0
    assert "Checking for updates" in result.stdout
    assert "already on the latest version" in result.stdout
    mock_run.assert_not_called()


def test_update_command_new_version(mocker):
    mocker.patch("studium.cli.get_current_version", return_value="0.2.2")
    mocker.patch("studium.cli.get_latest_version", return_value="0.2.3")
    mock_run = mocker.patch("subprocess.run")

    result = runner.invoke(app, ["update"])

    assert result.exit_code == 0
    assert "Checking for updates" in result.stdout
    assert "Updating to 0.2.3" in result.stdout
    assert "Success! Studium has been updated to 0.2.3" in result.stdout
    mock_run.assert_called_once()
    # Check if 'uv', 'tool', 'upgrade' are in the command args
    args = mock_run.call_args[0][0]
    assert "uv" in args
    assert "tool" in args
    assert "upgrade" in args
    assert "studium-cli" in args[3]


def test_update_command_force(mocker):
    mocker.patch("studium.cli.get_current_version", return_value="0.2.2")
    mocker.patch("studium.cli.get_latest_version", return_value="0.2.2")
    mock_run = mocker.patch("subprocess.run")

    result = runner.invoke(app, ["update", "--force"])

    assert result.exit_code == 0
    assert "Forcing reinstall..." in result.stdout
    mock_run.assert_called_once()
    args = mock_run.call_args[0][0]
    assert "uv" in args
    assert "tool" in args
    assert "install" in args
    assert "--reinstall" in args
    assert "studium-cli==0.2.2" in args[4]
