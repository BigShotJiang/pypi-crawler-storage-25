#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-12
################################################################

import os, time
import cv2
from dora import Node
from hex_util_runtime import get_dora_node_name, get_dora_bool
from hex_util_robot import depth_to_cmap
from .util import color_decode, depth_decode


def main():
    node_name = get_dora_node_name(os.getenv('NODE_NAME', ""))
    show_color_ts = get_dora_bool(os.getenv('SHOW_COLOR_TS', 'False'))

    os.environ["QT_QPA_FONTDIR"] = "/usr/share/fonts/truetype/dejavu/"
    win_color, depth_win = "color", "depth"

    show_cnt = 0
    color_frame, depth_cmap = None, None
    node = Node(node_name)
    for event in node:
        if event["type"] == "INPUT":
            if event["id"] == "tick":
                show_cnt += 1
                if show_cnt >= 8:
                    show_cnt = 0
                    if color_frame is not None:
                        if show_color_ts:
                            show_frame = cv2.putText(
                                color_frame.copy(),
                                f"{time.perf_counter()}",
                                (10, 60),
                                cv2.FONT_HERSHEY_SIMPLEX,
                                1,
                                (255, 0, 0),
                                2,
                            )
                            cv2.imshow(win_color, show_frame)
                        else:
                            cv2.imshow(win_color, color_frame)
                    if depth_cmap is not None:
                        cv2.imshow(depth_win, depth_cmap)
                    key = cv2.waitKey(1) & 0xFF
                    if key == ord('q'):
                        break

            elif event["id"] == "color":
                color_frame = color_decode(event['value'], event['metadata'])

            elif event["id"] == "depth":
                depth_frame = depth_decode(event['value'], event['metadata'])
                depth_cmap = depth_to_cmap(depth_frame)

    cv2.destroyAllWindows()
