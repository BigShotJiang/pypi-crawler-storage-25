#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-12
################################################################

import os, traceback, time
import cv2
from dora import Node
from hex_util_runtime import get_dora_node_name, get_dora_bool
from hex_driver_camera import HexCamDummy, HexCamDummyParams

from .util import color_encode


def main():
    node_name = get_dora_node_name(os.getenv('NODE_NAME', ""))
    params = HexCamDummyParams(
        # base
        frame_rate=int(os.getenv('FRAME_RATE', '30')),
        height=int(os.getenv('HEIGHT', '480')),
        width=int(os.getenv('WIDTH', '640')),
        cam_buffer_size=int(os.getenv('CAM_BUFFER_SIZE', '8')),
        sens_ts=get_dora_bool(os.getenv('SEN_TS', 'True')),
    )
    color_encoding = os.getenv('COLOR_ENCODING', 'bgr8')
    cam = None
    try:
        cam = HexCamDummy(params)
        cam.start()
        node = Node(node_name)
        for event in node:
            if event["type"] == "INPUT":
                if event["id"] == "tick":
                    color_frame = cam.get_color_img(latest=False)
                    if color_frame is None:
                        continue
                    color = color_frame["data"]
                    color = cv2.putText(
                        color.copy(),
                        f"{time.perf_counter()}",
                        (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        1,
                        (0, 0, 255),
                        2,
                    )
                    storage, metadata = color_encode(
                        color,
                        color_encoding,
                        event["metadata"],
                    )
                    if storage is not None:
                        node.send_output("color", storage, metadata)
                    else:
                        print("Failed to encode color frame")

            elif event["type"] == "ERROR":
                raise RuntimeError(event["error"])

    except Exception:
        traceback.print_exc()
    finally:
        if cam is not None:
            cam.stop()
            cam.deinit_camera()
