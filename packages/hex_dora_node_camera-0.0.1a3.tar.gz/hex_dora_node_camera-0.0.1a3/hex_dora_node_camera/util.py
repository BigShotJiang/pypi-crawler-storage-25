#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-13
################################################################

import cv2
import numpy as np
import pyarrow as pa


def color_encode(color, encoding, metadata):
    metadata.pop("timestamp", None)
    metadata["encoding"] = encoding
    metadata["width"] = int(color.shape[1])
    metadata["height"] = int(color.shape[0])
    metadata["primitive"] = "image"

    storage = None
    if encoding == "bgr8":
        storage = pa.array(color.ravel())
    elif encoding == "mjpg":
        encoded_color = cv2.imencode(
            '.jpg',
            color,
            [cv2.IMWRITE_JPEG_QUALITY, 75],
        )[1].tobytes()
        storage = pa.array(encoded_color)
    else:
        print(f"Unsupported color encoding: {encoding}")

    return storage, metadata


def depth_encode(depth, encoding, metadata):
    metadata.pop("timestamp", None)
    metadata["encoding"] = encoding
    metadata["width"] = int(depth.shape[1])
    metadata["height"] = int(depth.shape[0])
    metadata["primitive"] = "image"

    storage = None
    if encoding == "uint16":
        storage = pa.array(depth.ravel())
    elif encoding == "png":
        encoded_depth = cv2.imencode(
            '.png',
            depth,
            [cv2.IMWRITE_PNG_COMPRESSION, 1],
        )[1].tobytes()
        storage = pa.array(encoded_depth)
    else:
        print(f"Unsupported depth encoding: {encoding}")

    return storage, metadata


def color_decode(storage, metadata):
    color = storage.to_numpy()
    if metadata["encoding"] == "bgr8":
        color = color.reshape(metadata["height"], metadata["width"], 3)
    elif metadata["encoding"] == "mjpg":
        color = cv2.imdecode(color.astype(np.uint8), cv2.IMREAD_COLOR)
    else:
        print(f"Unsupported color encoding: {metadata['encoding']}")
    return color


def depth_decode(storage, metadata):
    depth = storage.to_numpy()
    if metadata["encoding"] == "uint16":
        depth = depth.reshape(metadata["height"], metadata["width"])
    elif metadata["encoding"] == "png":
        depth = cv2.imdecode(depth.astype(np.uint8), cv2.IMREAD_UNCHANGED)
    else:
        print(f"Unsupported depth encoding: {metadata['encoding']}")
    return depth
