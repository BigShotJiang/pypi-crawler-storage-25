"""cfglint - Validate, lint, and diff configuration files."""

__version__ = "1.0.0"
