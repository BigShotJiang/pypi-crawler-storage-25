"""Load cfglint configuration from .cfglintrc files."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from cfglint.models import LintConfig, Severity


_CONFIG_FILES = [".cfglintrc", ".cfglintrc.json", ".cfglintrc.yaml", ".cfglintrc.yml"]


def find_config_file(start_dir: str | None = None) -> Path | None:
    """Search for a .cfglintrc config file walking up from start_dir."""
    if start_dir is None:
        start_dir = str(Path.cwd())

    current = Path(start_dir).resolve()

    while True:
        for name in _CONFIG_FILES:
            candidate = current / name
            if candidate.is_file():
                return candidate

        parent = current.parent
        if parent == current:
            break
        current = parent

    return None


def load_config_file(config_path: str | Path) -> dict[str, Any]:
    """Load and parse a config file."""
    path = Path(config_path)
    content = path.read_text(encoding="utf-8")

    if path.suffix in (".yaml", ".yml"):
        import yaml
        return yaml.safe_load(content) or {}
    else:
        return json.loads(content)


def config_from_dict(data: dict[str, Any]) -> LintConfig:
    """Create a LintConfig from a dictionary."""
    severity_map = {
        "info": Severity.INFO,
        "warning": Severity.WARNING,
        "error": Severity.ERROR,
    }

    return LintConfig(
        severity_threshold=severity_map.get(
            data.get("severity", "info"), Severity.INFO
        ),
        enabled_rules=data.get("enable", []),
        disabled_rules=data.get("disable", []),
        schema_path=data.get("schema"),
        ignore_patterns=data.get("ignore", []),
        custom_secret_patterns=data.get("secret_patterns", []),
    )


def load_config(start_dir: str | None = None) -> LintConfig:
    """Find and load configuration, returning defaults if not found."""
    config_path = find_config_file(start_dir)
    if config_path is None:
        return LintConfig()

    data = load_config_file(config_path)
    return config_from_dict(data)
