"""File watcher for continuous config linting."""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Callable

from cfglint.models import FileFormat, LintResult
from cfglint.parsers.base import detect_format


class FileWatcher:
    """Watch config files for changes and re-lint."""

    def __init__(
        self,
        files: list[str],
        callback: Callable[[str, LintResult], None],
        interval: float = 1.0,
    ) -> None:
        self.files = files
        self.callback = callback
        self.interval = interval
        self._mtimes: dict[str, float] = {}
        self._running = False

    def start(self) -> None:
        """Start watching files. Blocks until stop() is called."""
        from cfglint.linter import Linter

        self._running = True
        linter = Linter()

        # Initialize mtimes
        for fp in self.files:
            try:
                self._mtimes[fp] = os.path.getmtime(fp)
            except OSError:
                self._mtimes[fp] = 0

        while self._running:
            for fp in self.files:
                try:
                    mtime = os.path.getmtime(fp)
                except OSError:
                    continue

                if mtime > self._mtimes.get(fp, 0):
                    self._mtimes[fp] = mtime
                    result = linter.lint_file(fp)
                    self.callback(fp, result)

            time.sleep(self.interval)

    def stop(self) -> None:
        """Stop watching."""
        self._running = False

    def check_once(self) -> list[tuple[str, bool]]:
        """Check all files once, returning (file, changed) pairs."""
        changes: list[tuple[str, bool]] = []
        for fp in self.files:
            try:
                mtime = os.path.getmtime(fp)
                changed = mtime > self._mtimes.get(fp, 0)
                if changed:
                    self._mtimes[fp] = mtime
                changes.append((fp, changed))
            except OSError:
                changes.append((fp, False))
        return changes
