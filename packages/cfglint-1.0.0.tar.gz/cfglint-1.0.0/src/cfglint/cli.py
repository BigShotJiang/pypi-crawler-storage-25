"""CLI interface for cfglint."""

from __future__ import annotations

import sys
from pathlib import Path

import click

from cfglint import __version__
from cfglint.models import LintConfig, Severity


@click.group()
@click.version_option(version=__version__, prog_name="cfglint")
def main() -> None:
    """cfglint - Validate, lint, and diff configuration files.

    Supports YAML, JSON, TOML, INI, and .env files with security checks,
    schema validation, and structural analysis.
    """


@main.command()
@click.argument("files", nargs=-1, required=True, type=click.Path(exists=True))
@click.option(
    "--format", "output_format",
    type=click.Choice(["text", "json", "rich", "sarif"]),
    default="rich",
    help="Output format",
)
@click.option(
    "--severity", "min_severity",
    type=click.Choice(["info", "warning", "error"]),
    default="info",
    help="Minimum severity to report",
)
@click.option(
    "--schema",
    type=click.Path(exists=True),
    help="JSON Schema file to validate against",
)
@click.option(
    "--enable",
    multiple=True,
    help="Enable specific rule(s) by ID",
)
@click.option(
    "--disable",
    multiple=True,
    help="Disable specific rule(s) by ID",
)
@click.option(
    "--strict",
    is_flag=True,
    help="Exit with error code if any warnings found",
)
@click.option(
    "--preset",
    type=click.Choice(["strict", "production", "security", "ci", "minimal"]),
    help="Use a validation preset",
)
def lint(
    files: tuple[str, ...],
    output_format: str,
    min_severity: str,
    schema: str | None,
    enable: tuple[str, ...],
    disable: tuple[str, ...],
    strict: bool,
    preset: str | None,
) -> None:
    """Lint configuration files for issues."""
    from cfglint.linter import Linter

    severity_map = {
        "info": Severity.INFO,
        "warning": Severity.WARNING,
        "error": Severity.ERROR,
    }

    if preset:
        from cfglint.presets import apply_preset
        config = apply_preset(preset)
    else:
        config = LintConfig(
            severity_threshold=severity_map[min_severity],
            enabled_rules=list(enable),
            disabled_rules=list(disable),
            schema_path=schema,
        )

    linter = Linter(config=config)

    # Load schema if provided
    if schema:
        from cfglint.rules.schema import SchemaValidationRule
        schema_rule = linter.registry.get("SCH001")
        if isinstance(schema_rule, SchemaValidationRule):
            schema_rule.load_schema(schema)

    results = linter.lint_files(list(files))

    # Format output
    if output_format == "json":
        from cfglint.formatters.json_fmt import JsonFormatter
        click.echo(JsonFormatter().format_results(results))
    elif output_format == "sarif":
        from cfglint.formatters.sarif_fmt import SarifFormatter
        click.echo(SarifFormatter().format_results(results))
    elif output_format == "rich":
        from cfglint.formatters.rich_fmt import RichFormatter
        click.echo(RichFormatter().format_results(results))
    else:
        from cfglint.formatters.text import TextFormatter
        click.echo(TextFormatter().format_results(results))

    # Exit code
    has_errors = any(r.has_errors for r in results)
    has_warnings = any(r.warning_count > 0 for r in results)

    if has_errors:
        sys.exit(1)
    elif strict and has_warnings:
        sys.exit(1)


@main.command()
@click.argument("file_a", type=click.Path(exists=True))
@click.argument("file_b", type=click.Path(exists=True))
@click.option(
    "--format", "output_format",
    type=click.Choice(["text", "json", "rich"]),
    default="rich",
    help="Output format",
)
def diff(file_a: str, file_b: str, output_format: str) -> None:
    """Compare two configuration files."""
    from cfglint.differ import ConfigDiffer

    differ = ConfigDiffer()
    result = differ.diff_files(file_a, file_b)

    if output_format == "json":
        from cfglint.formatters.json_fmt import JsonFormatter
        click.echo(JsonFormatter().format_diff(result))
    elif output_format == "rich":
        from cfglint.formatters.rich_fmt import RichFormatter
        click.echo(RichFormatter().format_diff(result))
    else:
        from cfglint.formatters.text import TextFormatter
        click.echo(TextFormatter().format_diff(result))

    sys.exit(1 if result.has_changes else 0)


@main.command()
@click.argument("files", nargs=-1, required=True, type=click.Path(exists=True))
@click.option("--dry-run", is_flag=True, help="Show what would be fixed without writing")
def fix(files: tuple[str, ...], dry_run: bool) -> None:
    """Auto-fix configuration issues."""
    from cfglint.fixer import ConfigFixer

    fixer = ConfigFixer()
    total_fixes = 0

    for file_path in files:
        if dry_run:
            from cfglint.linter import Linter
            from cfglint.parsers.base import detect_format
            from pathlib import Path

            raw = Path(file_path).read_text(encoding="utf-8")
            fmt = detect_format(file_path)
            linter = Linter()
            result = linter.lint_content(raw, fmt, file_path)
            _, fixes = fixer.fix_result(result, raw)
            for f in fixes:
                click.echo(f"  [DRY-RUN] {file_path}: {f}")
            total_fixes += len(fixes)
        else:
            _, fixes = fixer.fix_file(file_path)
            for f in fixes:
                click.echo(f"  [FIXED] {file_path}: {f}")
            total_fixes += len(fixes)

    click.echo(f"\nTotal fixes {'(would apply)' if dry_run else 'applied'}: {total_fixes}")


@main.command(name="rules")
def list_rules() -> None:
    """List all available lint rules."""
    from cfglint.linter import Linter

    linter = Linter()
    rules = linter.list_rules()

    for rule in rules:
        click.echo(f"  {rule['rule_id']:8s}  {rule['description']}")


@main.command()
@click.argument("directory", default=".", type=click.Path(exists=True))
@click.option("--format", "output_format",
    type=click.Choice(["text", "json", "rich", "sarif"]),
    default="rich", help="Output format")
@click.option("--recursive/--no-recursive", default=True, help="Search subdirectories")
def scan(directory: str, output_format: str, recursive: bool) -> None:
    """Discover and lint all config files in a directory."""
    from cfglint.discovery import discover_files
    from cfglint.linter import Linter

    files = discover_files(directory, recursive=recursive)
    if not files:
        click.echo("No configuration files found.")
        return

    click.echo(f"Found {len(files)} config file(s)...")
    linter = Linter()
    results = linter.lint_files(files)

    if output_format == "json":
        from cfglint.formatters.json_fmt import JsonFormatter
        click.echo(JsonFormatter().format_results(results))
    elif output_format == "sarif":
        from cfglint.formatters.sarif_fmt import SarifFormatter
        click.echo(SarifFormatter().format_results(results))
    elif output_format == "rich":
        from cfglint.formatters.rich_fmt import RichFormatter
        click.echo(RichFormatter().format_results(results))
    else:
        from cfglint.formatters.text import TextFormatter
        click.echo(TextFormatter().format_results(results))

    has_errors = any(r.has_errors for r in results)
    sys.exit(1 if has_errors else 0)


@main.command()
@click.argument("files", nargs=-1, required=True, type=click.Path(exists=True))
@click.option("--strategy", type=click.Choice(["deep", "override", "keep"]),
    default="deep", help="Merge strategy")
@click.option("--output", "-o", type=click.Path(), help="Output file path")
@click.option("--format", "output_format",
    type=click.Choice(["yaml", "json", "toml"]),
    default="yaml", help="Output format")
def merge(files: tuple[str, ...], strategy: str, output: str | None, output_format: str) -> None:
    """Merge multiple config files."""
    from cfglint.merger import ConfigMerger, MergeStrategy

    strategy_map = {
        "deep": MergeStrategy.DEEP_MERGE,
        "override": MergeStrategy.OVERRIDE,
        "keep": MergeStrategy.KEEP,
    }
    merger = ConfigMerger(strategy_map[strategy])
    result = merger.merge_files(*files)

    # Serialize
    if output_format == "json":
        import json as json_mod
        content = json_mod.dumps(result, indent=2, default=str)
    elif output_format == "toml":
        from cfglint.parsers.toml_parser import TomlParser
        content = TomlParser().dump(result)
    else:
        from cfglint.parsers.yaml_parser import YamlParser
        content = YamlParser().dump(result)

    if output:
        Path(output).write_text(content, encoding="utf-8")
        click.echo(f"Merged config written to {output}")
    else:
        click.echo(content)


@main.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("--to", "target_format", required=True,
    type=click.Choice(["yaml", "json", "toml", "ini", "env"]),
    help="Target format")
@click.option("--output", "-o", type=click.Path(), help="Output file path")
def convert(file: str, target_format: str, output: str | None) -> None:
    """Convert a config file to another format."""
    from cfglint.converter import ConfigConverter

    converter = ConfigConverter()
    fmt = ConfigConverter.format_from_string(target_format)

    try:
        content = converter.convert_file(file, fmt, output)
        if output:
            click.echo(f"Converted to {target_format}: {output}")
        else:
            click.echo(content)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument("file", type=click.Path(exists=True))
def parse(file: str) -> None:
    """Parse and display a config file's structure."""
    import json
    from cfglint.parsers.base import parse_file

    try:
        data, fmt = parse_file(file)
        click.echo(f"Format: {fmt.value}")
        click.echo(f"Keys: {_count_keys(data)}")
        click.echo(f"Structure:")
        click.echo(json.dumps(data, indent=2, default=str))
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command(name="presets")
def list_presets_cmd() -> None:
    """List available validation presets."""
    from cfglint.presets import list_presets

    for preset in list_presets():
        click.echo(f"  {preset['name']:12s}  {preset['description']}")


@main.command()
@click.option("--preset", default="strict",
    type=click.Choice(["strict", "production", "security", "ci", "minimal"]),
    help="Preset to use in config")
def init(preset: str) -> None:
    """Initialize a .cfglintrc config file."""
    import json as json_mod

    config = {"severity": "info", "disable": [], "ignore": []}
    if preset == "ci":
        config["severity"] = "error"
    elif preset == "production":
        config["severity"] = "warning"
    elif preset == "security":
        config["severity"] = "warning"
        config["enable"] = ["SEC001", "SEC002", "SEC003", "SEC004", "NAM002"]

    rc_path = Path(".cfglintrc")
    if rc_path.exists():
        click.echo(".cfglintrc already exists, skipping.")
        return

    rc_path.write_text(json_mod.dumps(config, indent=2) + "\n", encoding="utf-8")
    click.echo(f"Created .cfglintrc with preset '{preset}'")


def _count_keys(data: dict) -> int:
    count = len(data)
    for v in data.values():
        if isinstance(v, dict):
            count += _count_keys(v)
    return count


if __name__ == "__main__":
    main()
