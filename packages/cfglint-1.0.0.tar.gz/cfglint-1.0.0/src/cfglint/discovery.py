"""File discovery for configuration files."""

from __future__ import annotations

import fnmatch
from pathlib import Path

from cfglint.models import FileFormat
from cfglint.parsers.base import detect_format


# Default patterns for config files
DEFAULT_PATTERNS = [
    "*.yaml", "*.yml", "*.json", "*.toml", "*.ini", "*.cfg", "*.conf",
    ".env", ".env.*",
]

# Default ignore patterns
DEFAULT_IGNORES = [
    "node_modules/**", ".git/**", "__pycache__/**", "*.egg-info/**",
    ".venv/**", "venv/**", ".tox/**", "dist/**", "build/**",
    "package-lock.json", "yarn.lock", "pnpm-lock.yaml",
]


def discover_files(
    root: str = ".",
    patterns: list[str] | None = None,
    ignore: list[str] | None = None,
    recursive: bool = True,
) -> list[str]:
    """Discover configuration files in a directory.

    Args:
        root: Root directory to search.
        patterns: Glob patterns to match (default: common config extensions).
        ignore: Glob patterns to ignore.
        recursive: Search subdirectories.

    Returns:
        List of file paths.
    """
    root_path = Path(root).resolve()
    patterns = patterns or DEFAULT_PATTERNS
    ignore = ignore or DEFAULT_IGNORES

    found: list[str] = []

    for pattern in patterns:
        if recursive:
            glob_pattern = f"**/{pattern}"
        else:
            glob_pattern = pattern

        for match in root_path.glob(glob_pattern):
            if not match.is_file():
                continue

            rel = match.relative_to(root_path)
            rel_str = str(rel).replace("\\", "/")

            if _is_ignored(rel_str, ignore):
                continue

            fmt = detect_format(str(match))
            if fmt != FileFormat.UNKNOWN:
                found.append(str(match))

    # Deduplicate and sort
    return sorted(set(found))


def _is_ignored(rel_path: str, patterns: list[str]) -> bool:
    """Check if a relative path matches any ignore pattern."""
    for pattern in patterns:
        if fnmatch.fnmatch(rel_path, pattern):
            return True
        # Also check each path component
        parts = rel_path.split("/")
        for i, part in enumerate(parts):
            partial = "/".join(parts[: i + 1])
            if fnmatch.fnmatch(partial, pattern):
                return True
            if fnmatch.fnmatch(part, pattern):
                return True
    return False
