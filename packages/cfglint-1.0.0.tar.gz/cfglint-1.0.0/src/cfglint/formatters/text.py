"""Plain text output formatter."""

from __future__ import annotations

from cfglint.models import DiffResult, LintResult, Severity


class TextFormatter:
    """Format lint results as plain text."""

    _SEVERITY_SYMBOLS = {
        Severity.ERROR: "E",
        Severity.WARNING: "W",
        Severity.INFO: "I",
    }

    def format_result(self, result: LintResult) -> str:
        """Format a single lint result."""
        lines: list[str] = []

        if result.parse_error:
            lines.append(f"PARSE ERROR: {result.file_path}: {result.parse_error}")
            return "\n".join(lines)

        if not result.findings:
            lines.append(f"{result.file_path}: OK (no issues found)")
            return "\n".join(lines)

        for finding in result.findings:
            symbol = self._SEVERITY_SYMBOLS.get(finding.severity, "?")
            location = finding.file_path
            if finding.line:
                location += f":{finding.line}"
            if finding.column:
                location += f":{finding.column}"

            line = f"[{symbol}] {location}: {finding.rule_id} {finding.message}"
            if finding.key_path:
                line += f" (at {finding.key_path})"
            lines.append(line)

            if finding.suggestion:
                lines.append(f"    -> {finding.suggestion}")

        # Summary
        lines.append("")
        lines.append(
            f"Found {result.error_count} error(s), "
            f"{result.warning_count} warning(s), "
            f"{result.info_count} info(s)"
        )

        return "\n".join(lines)

    def format_results(self, results: list[LintResult]) -> str:
        """Format multiple lint results."""
        parts = [self.format_result(r) for r in results]
        return "\n\n".join(parts)

    def format_diff(self, diff: DiffResult) -> str:
        """Format a diff result."""
        if not diff.has_changes:
            return f"No differences between {diff.file_a} and {diff.file_b}"

        lines: list[str] = [
            f"Diff: {diff.file_a} -> {diff.file_b}",
            f"{'='*60}",
        ]

        for entry in diff.entries:
            if entry.change_type == "added":
                lines.append(f"  + {entry.key_path}: {entry.new_value}")
            elif entry.change_type == "removed":
                lines.append(f"  - {entry.key_path}: {entry.old_value}")
            elif entry.change_type == "modified":
                lines.append(f"  ~ {entry.key_path}:")
                lines.append(f"    old: {entry.old_value}")
                lines.append(f"    new: {entry.new_value}")

        lines.append(f"\nTotal changes: {len(diff.entries)}")
        return "\n".join(lines)
