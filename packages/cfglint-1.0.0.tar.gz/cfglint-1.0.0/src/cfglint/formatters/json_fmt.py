"""JSON output formatter."""

from __future__ import annotations

import json

from cfglint.models import DiffResult, LintResult


class JsonFormatter:
    """Format lint results as JSON."""

    def format_result(self, result: LintResult) -> str:
        """Format a single lint result as JSON."""
        return json.dumps(result.to_dict(), indent=2, ensure_ascii=False)

    def format_results(self, results: list[LintResult]) -> str:
        """Format multiple lint results as JSON."""
        data = {
            "results": [r.to_dict() for r in results],
            "total_errors": sum(r.error_count for r in results),
            "total_warnings": sum(r.warning_count for r in results),
            "total_infos": sum(r.info_count for r in results),
        }
        return json.dumps(data, indent=2, ensure_ascii=False)

    def format_diff(self, diff: DiffResult) -> str:
        """Format a diff result as JSON."""
        return json.dumps(diff.to_dict(), indent=2, ensure_ascii=False)
