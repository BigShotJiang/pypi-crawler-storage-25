"""Rich console output formatter."""

from __future__ import annotations

from io import StringIO

from cfglint.models import DiffResult, LintResult, Severity

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.text import Text
    HAS_RICH = True
except ImportError:
    HAS_RICH = False


class RichFormatter:
    """Format lint results using Rich for terminal output."""

    _SEVERITY_STYLES = {
        Severity.ERROR: ("bold red", "ERROR"),
        Severity.WARNING: ("yellow", "WARN"),
        Severity.INFO: ("blue", "INFO"),
    }

    def format_result(self, result: LintResult, file: StringIO | None = None) -> str:
        """Format and render a single lint result."""
        if not HAS_RICH:
            from cfglint.formatters.text import TextFormatter
            return TextFormatter().format_result(result)

        buf = file or StringIO()
        console = Console(file=buf, force_terminal=True, width=120)

        if result.parse_error:
            console.print(
                Panel(f"[red]{result.parse_error}[/red]",
                      title=f"Parse Error: {result.file_path}")
            )
            return buf.getvalue() if file is None else ""

        if not result.findings:
            console.print(f"[green]{result.file_path}: OK[/green]")
            return buf.getvalue() if file is None else ""

        table = Table(title=result.file_path, show_lines=True)
        table.add_column("Severity", width=8)
        table.add_column("Rule", width=8)
        table.add_column("Message")
        table.add_column("Path", width=30)

        for finding in result.findings:
            style, label = self._SEVERITY_STYLES.get(
                finding.severity, ("white", "?")
            )
            table.add_row(
                Text(label, style=style),
                finding.rule_id,
                finding.message,
                finding.key_path or "-",
            )

        console.print(table)
        console.print(
            f"  Errors: [red]{result.error_count}[/red]  "
            f"Warnings: [yellow]{result.warning_count}[/yellow]  "
            f"Info: [blue]{result.info_count}[/blue]"
        )

        return buf.getvalue() if file is None else ""

    def format_results(self, results: list[LintResult]) -> str:
        """Format multiple lint results."""
        buf = StringIO()
        for result in results:
            self.format_result(result, file=buf)
        return buf.getvalue()

    def format_diff(self, diff: DiffResult) -> str:
        """Format a diff result with Rich."""
        if not HAS_RICH:
            from cfglint.formatters.text import TextFormatter
            return TextFormatter().format_diff(diff)

        buf = StringIO()
        console = Console(file=buf, force_terminal=True, width=120)

        if not diff.has_changes:
            console.print(
                f"[green]No differences between {diff.file_a} and {diff.file_b}[/green]"
            )
            return buf.getvalue()

        table = Table(
            title=f"Diff: {diff.file_a} -> {diff.file_b}",
            show_lines=True,
        )
        table.add_column("Change", width=10)
        table.add_column("Key Path")
        table.add_column("Old Value", width=30)
        table.add_column("New Value", width=30)

        for entry in diff.entries:
            if entry.change_type == "added":
                change = Text("ADDED", style="green")
            elif entry.change_type == "removed":
                change = Text("REMOVED", style="red")
            else:
                change = Text("MODIFIED", style="yellow")

            table.add_row(
                change,
                entry.key_path,
                str(entry.old_value) if entry.old_value is not None else "-",
                str(entry.new_value) if entry.new_value is not None else "-",
            )

        console.print(table)
        return buf.getvalue()
