"""SARIF output formatter (Static Analysis Results Interchange Format)."""

from __future__ import annotations

import json
from typing import Any

from cfglint import __version__
from cfglint.models import DiffResult, LintResult, Severity


class SarifFormatter:
    """Format lint results as SARIF 2.1.0 for CI/CD integration."""

    _SEVERITY_MAP = {
        Severity.ERROR: "error",
        Severity.WARNING: "warning",
        Severity.INFO: "note",
    }

    def format_result(self, result: LintResult) -> str:
        return self.format_results([result])

    def format_results(self, results: list[LintResult]) -> str:
        """Format results as SARIF JSON."""
        sarif: dict[str, Any] = {
            "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/main/sarif-2.1/schema/sarif-schema-2.1.0.json",
            "version": "2.1.0",
            "runs": [
                {
                    "tool": {
                        "driver": {
                            "name": "cfglint",
                            "version": __version__,
                            "informationUri": "https://github.com/JSLEEKR/cfglint",
                            "rules": self._collect_rules(results),
                        }
                    },
                    "results": self._collect_results(results),
                }
            ],
        }
        return json.dumps(sarif, indent=2, ensure_ascii=False)

    def _collect_rules(self, results: list[LintResult]) -> list[dict[str, Any]]:
        """Collect unique rule definitions."""
        seen: dict[str, dict[str, Any]] = {}
        for result in results:
            for finding in result.findings:
                if finding.rule_id not in seen:
                    seen[finding.rule_id] = {
                        "id": finding.rule_id,
                        "shortDescription": {
                            "text": finding.rule_id,
                        },
                    }
        return list(seen.values())

    def _collect_results(self, results: list[LintResult]) -> list[dict[str, Any]]:
        """Collect all findings as SARIF results."""
        sarif_results: list[dict[str, Any]] = []

        for result in results:
            for finding in result.findings:
                entry: dict[str, Any] = {
                    "ruleId": finding.rule_id,
                    "level": self._SEVERITY_MAP.get(finding.severity, "note"),
                    "message": {"text": finding.message},
                    "locations": [
                        {
                            "physicalLocation": {
                                "artifactLocation": {
                                    "uri": finding.file_path or result.file_path,
                                },
                            }
                        }
                    ],
                }

                if finding.line:
                    entry["locations"][0]["physicalLocation"]["region"] = {
                        "startLine": finding.line,
                    }
                    if finding.column:
                        entry["locations"][0]["physicalLocation"]["region"]["startColumn"] = finding.column

                if finding.key_path:
                    entry["locations"][0]["logicalLocations"] = [
                        {"name": finding.key_path, "kind": "configKey"}
                    ]

                if finding.suggestion:
                    entry["fixes"] = [
                        {
                            "description": {"text": finding.suggestion},
                        }
                    ]

                sarif_results.append(entry)

        return sarif_results

    def format_diff(self, diff: DiffResult) -> str:
        """Diff is not natively SARIF, output as JSON."""
        return json.dumps(diff.to_dict(), indent=2)
