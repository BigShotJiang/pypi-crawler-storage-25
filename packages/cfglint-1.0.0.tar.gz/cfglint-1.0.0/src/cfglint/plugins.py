"""Plugin system for custom lint rules."""

from __future__ import annotations

import importlib
import importlib.util
import sys
from pathlib import Path
from typing import Any

from cfglint.rules.base import Rule, RuleRegistry


class PluginLoader:
    """Load custom lint rules from Python modules."""

    def load_module(self, module_path: str) -> list[Rule]:
        """Load rules from a Python module file."""
        path = Path(module_path).resolve()
        if not path.exists():
            raise FileNotFoundError(f"Plugin module not found: {module_path}")

        module_name = f"cfglint_plugin_{path.stem}"
        spec = importlib.util.spec_from_file_location(module_name, str(path))
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot load module: {module_path}")

        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)

        return self._extract_rules(module)

    def load_package(self, package_name: str) -> list[Rule]:
        """Load rules from an installed Python package."""
        try:
            module = importlib.import_module(package_name)
        except ImportError:
            raise ImportError(f"Cannot import package: {package_name}")

        return self._extract_rules(module)

    def _extract_rules(self, module: Any) -> list[Rule]:
        """Extract Rule subclasses from a module."""
        rules: list[Rule] = []

        # Check for explicit RULES list
        if hasattr(module, "RULES"):
            for rule in module.RULES:
                if isinstance(rule, Rule):
                    rules.append(rule)
                elif isinstance(rule, type) and issubclass(rule, Rule) and rule is not Rule:
                    rules.append(rule())
            return rules

        # Auto-discover Rule subclasses
        for attr_name in dir(module):
            attr = getattr(module, attr_name)
            if (
                isinstance(attr, type)
                and issubclass(attr, Rule)
                and attr is not Rule
                and not attr_name.startswith("_")
            ):
                try:
                    rules.append(attr())
                except Exception:
                    pass

        return rules

    def register_plugins(
        self,
        registry: RuleRegistry,
        plugin_paths: list[str] | None = None,
        plugin_packages: list[str] | None = None,
    ) -> int:
        """Load and register plugins into a registry. Returns count loaded."""
        count = 0

        for path in (plugin_paths or []):
            try:
                rules = self.load_module(path)
                for rule in rules:
                    registry.register(rule)
                    count += 1
            except Exception:
                pass

        for package in (plugin_packages or []):
            try:
                rules = self.load_package(package)
                for rule in rules:
                    registry.register(rule)
                    count += 1
            except Exception:
                pass

        return count
