"""Config format converter."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from cfglint.models import FileFormat
from cfglint.parsers.base import detect_format, parse_file, _get_parser


class ConfigConverter:
    """Convert between configuration file formats."""

    SUPPORTED_TARGETS = {
        FileFormat.YAML,
        FileFormat.JSON,
        FileFormat.TOML,
        FileFormat.INI,
        FileFormat.ENV,
    }

    def convert_file(
        self,
        source_path: str,
        target_format: FileFormat,
        target_path: str | None = None,
    ) -> str:
        """Convert a config file to another format.

        Returns the converted content as a string.
        """
        data, source_format = parse_file(source_path)

        if target_format not in self.SUPPORTED_TARGETS:
            raise ValueError(f"Unsupported target format: {target_format.value}")

        content = self.convert_data(data, target_format)

        if target_path:
            Path(target_path).write_text(content, encoding="utf-8")

        return content

    def convert_data(
        self,
        data: dict[str, Any],
        target_format: FileFormat,
    ) -> str:
        """Convert data dictionary to a specific format string."""
        parser = _get_parser(target_format)
        return parser.dump(data)

    @staticmethod
    def format_from_string(fmt_str: str) -> FileFormat:
        """Parse a format string into FileFormat enum."""
        fmt_map = {
            "yaml": FileFormat.YAML,
            "yml": FileFormat.YAML,
            "json": FileFormat.JSON,
            "toml": FileFormat.TOML,
            "ini": FileFormat.INI,
            "env": FileFormat.ENV,
        }
        result = fmt_map.get(fmt_str.lower())
        if result is None:
            raise ValueError(f"Unknown format: {fmt_str}")
        return result
