"""Naming convention lint rules."""

from __future__ import annotations

import re
from typing import Any

from cfglint.models import FileFormat, LintFinding, Severity
from cfglint.rules.base import Rule


class InconsistentNamingRule(Rule):
    """Detect mixed naming conventions (camelCase vs snake_case vs kebab-case)."""

    _CAMEL = re.compile(r"^[a-z][a-zA-Z0-9]*$")
    _SNAKE = re.compile(r"^[a-z][a-z0-9_]*$")
    _KEBAB = re.compile(r"^[a-z][a-z0-9-]*$")
    _UPPER_SNAKE = re.compile(r"^[A-Z][A-Z0-9_]*$")
    _PASCAL = re.compile(r"^[A-Z][a-zA-Z0-9]*$")

    @property
    def rule_id(self) -> str:
        return "NAM001"

    @property
    def description(self) -> str:
        return "Detect inconsistent key naming conventions"

    def check(
        self,
        data: dict[str, Any],
        file_path: str = "",
        file_format: FileFormat = FileFormat.UNKNOWN,
        raw_content: str = "",
    ) -> list[LintFinding]:
        findings: list[LintFinding] = []
        keys = self._collect_keys(data)

        if len(keys) < 3:
            return findings

        # Classify each key
        conventions: dict[str, list[str]] = {
            "camelCase": [],
            "snake_case": [],
            "kebab-case": [],
            "UPPER_SNAKE": [],
            "PascalCase": [],
            "other": [],
        }

        for key in keys:
            if self._UPPER_SNAKE.match(key):
                conventions["UPPER_SNAKE"].append(key)
            elif self._CAMEL.match(key) and any(c.isupper() for c in key[1:]):
                conventions["camelCase"].append(key)
            elif self._PASCAL.match(key) and len(key) > 1:
                conventions["PascalCase"].append(key)
            elif self._SNAKE.match(key) and "_" in key:
                conventions["snake_case"].append(key)
            elif self._KEBAB.match(key) and "-" in key:
                conventions["kebab-case"].append(key)
            else:
                conventions["other"].append(key)

        # Find active conventions (with at least 1 key)
        active = {k: v for k, v in conventions.items()
                  if v and k != "other"}

        if len(active) > 1:
            # Determine dominant convention
            dominant = max(active, key=lambda k: len(active[k]))
            for conv, conv_keys in active.items():
                if conv != dominant:
                    for key in conv_keys:
                        findings.append(LintFinding(
                            rule_id=self.rule_id,
                            severity=Severity.INFO,
                            message=f"Key '{key}' uses {conv}, but dominant convention is {dominant}",
                            file_path=file_path,
                            key_path=key,
                            suggestion=f"Consider using {dominant} for consistency",
                        ))

        return findings

    def _collect_keys(self, data: Any) -> list[str]:
        keys: list[str] = []
        if isinstance(data, dict):
            for key, value in data.items():
                keys.append(key)
                if isinstance(value, (dict, list)):
                    keys.extend(self._collect_keys(value))
        elif isinstance(data, list):
            for item in data:
                keys.extend(self._collect_keys(item))
        return keys


class ReservedKeyRule(Rule):
    """Detect usage of reserved or dangerous key names."""

    _RESERVED_KEYS = {
        "__proto__", "constructor", "prototype",  # JS prototype pollution
        "__class__", "__import__", "__builtins__",  # Python injection
        "eval", "exec", "system", "shell",  # Command execution
        "__file__", "__name__",
    }

    @property
    def rule_id(self) -> str:
        return "NAM002"

    @property
    def description(self) -> str:
        return "Detect reserved or dangerous key names"

    def check(
        self,
        data: dict[str, Any],
        file_path: str = "",
        file_format: FileFormat = FileFormat.UNKNOWN,
        raw_content: str = "",
    ) -> list[LintFinding]:
        findings: list[LintFinding] = []
        self._walk(data, "", findings, file_path)
        return findings

    def _walk(self, data: Any, path: str, findings: list[LintFinding], fp: str) -> None:
        if isinstance(data, dict):
            for key, value in data.items():
                key_path = f"{path}.{key}" if path else key
                if key.lower() in self._RESERVED_KEYS:
                    findings.append(LintFinding(
                        rule_id=self.rule_id,
                        severity=Severity.ERROR,
                        message=f"Reserved/dangerous key name '{key}' at '{key_path}'",
                        file_path=fp,
                        key_path=key_path,
                        suggestion="Rename this key to avoid security issues",
                    ))
                if isinstance(value, (dict, list)):
                    self._walk(value, key_path, findings, fp)
        elif isinstance(data, list):
            for i, item in enumerate(data):
                self._walk(item, f"{path}[{i}]", findings, fp)
