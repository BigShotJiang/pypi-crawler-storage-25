"""Environment-aware lint rules."""

from __future__ import annotations

import re
from typing import Any

from cfglint.models import FileFormat, LintFinding, Severity
from cfglint.rules.base import Rule


class ProductionReadinessRule(Rule):
    """Check for production-readiness issues in config files."""

    _PROD_INDICATORS = re.compile(
        r"(?i)(prod|production|prd|live|release|staging)"
    )

    _DEV_VALUES = {
        "localhost", "127.0.0.1", "0.0.0.0", "::1",
        "dev", "development", "test", "testing", "debug",
    }

    _SENSITIVE_KEYS = re.compile(
        r"(?i)(host|server|endpoint|url|domain|address)"
    )

    @property
    def rule_id(self) -> str:
        return "ENV001"

    @property
    def description(self) -> str:
        return "Check production config for dev/test values"

    def check(
        self,
        data: dict[str, Any],
        file_path: str = "",
        file_format: FileFormat = FileFormat.UNKNOWN,
        raw_content: str = "",
    ) -> list[LintFinding]:
        # Only apply to files that look like production configs
        if not self._is_prod_config(file_path, data):
            return []

        findings: list[LintFinding] = []
        self._walk(data, "", findings, file_path)
        return findings

    def _is_prod_config(self, file_path: str, data: dict[str, Any]) -> bool:
        """Determine if this looks like a production config."""
        if self._PROD_INDICATORS.search(file_path):
            return True

        # Check for environment key
        env = data.get("environment") or data.get("env") or data.get("ENV") or ""
        if isinstance(env, str) and self._PROD_INDICATORS.search(env):
            return True

        return False

    def _walk(self, data: Any, path: str, findings: list[LintFinding], fp: str) -> None:
        if isinstance(data, dict):
            for key, value in data.items():
                key_path = f"{path}.{key}" if path else key
                if isinstance(value, str) and self._SENSITIVE_KEYS.search(key):
                    val_lower = value.lower().strip()
                    if val_lower in self._DEV_VALUES or "localhost" in val_lower:
                        findings.append(LintFinding(
                            rule_id=self.rule_id,
                            severity=Severity.ERROR,
                            message=f"Dev/test value '{value}' in production config at '{key_path}'",
                            file_path=fp,
                            key_path=key_path,
                            suggestion="Use production-appropriate values",
                        ))
                elif isinstance(value, (dict, list)):
                    self._walk(value, key_path, findings, fp)
        elif isinstance(data, list):
            for i, item in enumerate(data):
                self._walk(item, f"{path}[{i}]", findings, fp)


class EnvironmentVariableRule(Rule):
    """Detect values that should use environment variables."""

    _SHOULD_BE_ENV_KEYS = re.compile(
        r"(?i)(database_url|redis_url|mongodb_uri|api_url|"
        r"smtp_host|smtp_password|aws_access_key|"
        r"stripe_key|sendgrid_key|twilio_sid)"
    )

    @property
    def rule_id(self) -> str:
        return "ENV002"

    @property
    def description(self) -> str:
        return "Detect values that should use environment variables"

    def check(
        self,
        data: dict[str, Any],
        file_path: str = "",
        file_format: FileFormat = FileFormat.UNKNOWN,
        raw_content: str = "",
    ) -> list[LintFinding]:
        findings: list[LintFinding] = []
        self._walk(data, "", findings, file_path)
        return findings

    def _walk(self, data: Any, path: str, findings: list[LintFinding], fp: str) -> None:
        if isinstance(data, dict):
            for key, value in data.items():
                key_path = f"{path}.{key}" if path else key
                if isinstance(value, str) and self._SHOULD_BE_ENV_KEYS.search(key):
                    # Check if it's already an env ref
                    if not self._is_env_ref(value):
                        findings.append(LintFinding(
                            rule_id=self.rule_id,
                            severity=Severity.WARNING,
                            message=f"'{key_path}' should reference an environment variable",
                            file_path=fp,
                            key_path=key_path,
                            suggestion="Use ${ENV_VAR} or environment variable reference",
                        ))
                elif isinstance(value, (dict, list)):
                    self._walk(value, key_path, findings, fp)
        elif isinstance(data, list):
            for i, item in enumerate(data):
                self._walk(item, f"{path}[{i}]", findings, fp)

    def _is_env_ref(self, value: str) -> bool:
        """Check if value is already an environment variable reference."""
        return (
            value.startswith("${")
            or value.startswith("{{")
            or value.startswith("<%")
            or value.startswith("%")
        )
