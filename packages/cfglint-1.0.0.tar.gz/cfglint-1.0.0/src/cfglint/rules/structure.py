"""Structural lint rules."""

from __future__ import annotations

from typing import Any

from cfglint.models import FileFormat, LintFinding, Severity
from cfglint.rules.base import Rule


class EmptyValueRule(Rule):
    """Detect empty values in configuration."""

    @property
    def rule_id(self) -> str:
        return "STR001"

    @property
    def description(self) -> str:
        return "Detect empty or null values"

    def check(
        self,
        data: dict[str, Any],
        file_path: str = "",
        file_format: FileFormat = FileFormat.UNKNOWN,
        raw_content: str = "",
    ) -> list[LintFinding]:
        findings: list[LintFinding] = []
        self._walk(data, "", findings, file_path)
        return findings

    def _walk(self, data: Any, path: str, findings: list[LintFinding], fp: str) -> None:
        if isinstance(data, dict):
            for key, value in data.items():
                key_path = f"{path}.{key}" if path else key
                if value is None:
                    findings.append(LintFinding(
                        rule_id=self.rule_id,
                        severity=Severity.WARNING,
                        message=f"Null value at '{key_path}'",
                        file_path=fp,
                        key_path=key_path,
                        suggestion="Set an explicit value or remove the key",
                    ))
                elif isinstance(value, str) and value.strip() == "":
                    findings.append(LintFinding(
                        rule_id=self.rule_id,
                        severity=Severity.INFO,
                        message=f"Empty string at '{key_path}'",
                        file_path=fp,
                        key_path=key_path,
                        suggestion="Set an explicit value or remove the key",
                    ))
                elif isinstance(value, (dict, list)):
                    self._walk(value, key_path, findings, fp)
        elif isinstance(data, list):
            for i, item in enumerate(data):
                self._walk(item, f"{path}[{i}]", findings, fp)


class DuplicateKeyRule(Rule):
    """Detect duplicate keys in raw content (YAML/JSON specific)."""

    @property
    def rule_id(self) -> str:
        return "STR002"

    @property
    def description(self) -> str:
        return "Detect duplicate keys in config"

    def check(
        self,
        data: dict[str, Any],
        file_path: str = "",
        file_format: FileFormat = FileFormat.UNKNOWN,
        raw_content: str = "",
    ) -> list[LintFinding]:
        if not raw_content:
            return []

        findings: list[LintFinding] = []

        if file_format in (FileFormat.YAML, FileFormat.ENV):
            self._check_yaml_dupes(raw_content, findings, file_path)
        elif file_format == FileFormat.JSON:
            self._check_json_dupes(raw_content, findings, file_path)

        return findings

    def _check_yaml_dupes(
        self, content: str, findings: list[LintFinding], fp: str
    ) -> None:
        import re
        seen: dict[str, int] = {}
        # Simple top-level key detection
        for line_num, line in enumerate(content.splitlines(), 1):
            stripped = line.strip()
            if stripped.startswith("#") or not stripped:
                continue
            # Match top-level keys (no leading whitespace)
            if not line[0].isspace() and ":" in line:
                key = line.split(":")[0].strip()
                if key in seen:
                    findings.append(LintFinding(
                        rule_id=self.rule_id,
                        severity=Severity.ERROR,
                        message=f"Duplicate key '{key}' (first at line {seen[key]})",
                        file_path=fp,
                        line=line_num,
                        key_path=key,
                    ))
                else:
                    seen[key] = line_num

    def _check_json_dupes(
        self, content: str, findings: list[LintFinding], fp: str
    ) -> None:
        import json

        seen_keys: list[str] = []

        def pairs_hook(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
            d: dict[str, Any] = {}
            for key, value in pairs:
                if key in d:
                    seen_keys.append(key)
                d[key] = value
            return d

        try:
            json.loads(content, object_pairs_hook=pairs_hook)
        except json.JSONDecodeError:
            pass

        for key in seen_keys:
            findings.append(LintFinding(
                rule_id=self.rule_id,
                severity=Severity.ERROR,
                message=f"Duplicate key '{key}' in JSON",
                file_path=fp,
                key_path=key,
            ))


class DeepNestingRule(Rule):
    """Detect excessively deep nesting."""

    MAX_DEPTH = 8

    @property
    def rule_id(self) -> str:
        return "STR003"

    @property
    def description(self) -> str:
        return "Detect excessively deep nesting"

    def check(
        self,
        data: dict[str, Any],
        file_path: str = "",
        file_format: FileFormat = FileFormat.UNKNOWN,
        raw_content: str = "",
    ) -> list[LintFinding]:
        findings: list[LintFinding] = []
        self._walk(data, "", 0, findings, file_path)
        return findings

    def _walk(
        self,
        data: Any,
        path: str,
        depth: int,
        findings: list[LintFinding],
        fp: str,
    ) -> None:
        if depth > self.MAX_DEPTH:
            findings.append(LintFinding(
                rule_id=self.rule_id,
                severity=Severity.WARNING,
                message=f"Nesting depth {depth} exceeds maximum {self.MAX_DEPTH} at '{path}'",
                file_path=fp,
                key_path=path,
                suggestion="Consider flattening the configuration structure",
            ))
            return

        if isinstance(data, dict):
            for key, value in data.items():
                key_path = f"{path}.{key}" if path else key
                if isinstance(value, (dict, list)):
                    self._walk(value, key_path, depth + 1, findings, fp)
        elif isinstance(data, list):
            for i, item in enumerate(data):
                if isinstance(item, (dict, list)):
                    self._walk(item, f"{path}[{i}]", depth + 1, findings, fp)


class LargeFileRule(Rule):
    """Warn about configuration files that are too large."""

    MAX_KEYS = 500
    MAX_LINES = 2000

    @property
    def rule_id(self) -> str:
        return "STR004"

    @property
    def description(self) -> str:
        return "Detect overly large configuration files"

    def check(
        self,
        data: dict[str, Any],
        file_path: str = "",
        file_format: FileFormat = FileFormat.UNKNOWN,
        raw_content: str = "",
    ) -> list[LintFinding]:
        findings: list[LintFinding] = []

        # Check line count
        if raw_content:
            line_count = len(raw_content.splitlines())
            if line_count > self.MAX_LINES:
                findings.append(LintFinding(
                    rule_id=self.rule_id,
                    severity=Severity.WARNING,
                    message=f"Config file has {line_count} lines (max recommended: {self.MAX_LINES})",
                    file_path=file_path,
                    suggestion="Consider splitting into multiple config files",
                ))

        # Count total keys
        key_count = self._count_keys(data)
        if key_count > self.MAX_KEYS:
            findings.append(LintFinding(
                rule_id=self.rule_id,
                severity=Severity.WARNING,
                message=f"Config file has {key_count} keys (max recommended: {self.MAX_KEYS})",
                file_path=file_path,
                suggestion="Consider splitting into multiple config files",
            ))

        return findings

    def _count_keys(self, data: Any) -> int:
        if isinstance(data, dict):
            return len(data) + sum(self._count_keys(v) for v in data.values())
        if isinstance(data, list):
            return sum(self._count_keys(item) for item in data)
        return 0
