"""Base rule infrastructure."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from cfglint.models import FileFormat, LintFinding


class Rule(ABC):
    """Base class for all lint rules."""

    @property
    @abstractmethod
    def rule_id(self) -> str:
        """Unique identifier for this rule."""
        ...

    @property
    @abstractmethod
    def description(self) -> str:
        """Human-readable description."""
        ...

    @abstractmethod
    def check(
        self,
        data: dict[str, Any],
        file_path: str = "",
        file_format: FileFormat = FileFormat.UNKNOWN,
        raw_content: str = "",
    ) -> list[LintFinding]:
        """Run the rule check and return findings."""
        ...


class RuleRegistry:
    """Registry of all available lint rules."""

    def __init__(self) -> None:
        self._rules: dict[str, Rule] = {}

    def register(self, rule: Rule) -> None:
        """Register a rule."""
        self._rules[rule.rule_id] = rule

    def get(self, rule_id: str) -> Rule | None:
        """Get a rule by ID."""
        return self._rules.get(rule_id)

    def all_rules(self) -> list[Rule]:
        """Get all registered rules."""
        return list(self._rules.values())

    def rule_ids(self) -> list[str]:
        """Get all registered rule IDs."""
        return list(self._rules.keys())


def get_default_registry() -> RuleRegistry:
    """Create a registry with all built-in rules."""
    from cfglint.rules.security import (
        SecretDetectionRule,
        WeakPasswordRule,
        InsecureProtocolRule,
        DebugEnabledRule,
    )
    from cfglint.rules.structure import (
        EmptyValueRule,
        DuplicateKeyRule,
        DeepNestingRule,
        LargeFileRule,
    )
    from cfglint.rules.naming import (
        InconsistentNamingRule,
        ReservedKeyRule,
    )
    from cfglint.rules.schema import SchemaValidationRule
    from cfglint.rules.environment import (
        ProductionReadinessRule,
        EnvironmentVariableRule,
    )
    from cfglint.rules.types import (
        TypeCoercionRule,
        PortRangeRule,
    )
    from cfglint.rules.deprecation import DeprecatedKeyRule

    registry = RuleRegistry()
    for rule_cls in [
        SecretDetectionRule,
        WeakPasswordRule,
        InsecureProtocolRule,
        DebugEnabledRule,
        EmptyValueRule,
        DuplicateKeyRule,
        DeepNestingRule,
        LargeFileRule,
        InconsistentNamingRule,
        ReservedKeyRule,
        SchemaValidationRule,
        ProductionReadinessRule,
        EnvironmentVariableRule,
        TypeCoercionRule,
        PortRangeRule,
        DeprecatedKeyRule,
    ]:
        registry.register(rule_cls())

    return registry
