"""Schema validation rule."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from cfglint.models import FileFormat, LintFinding, Severity
from cfglint.rules.base import Rule


class SchemaValidationRule(Rule):
    """Validate config against a JSON Schema."""

    def __init__(self, schema: dict[str, Any] | None = None) -> None:
        self._schema = schema

    @property
    def rule_id(self) -> str:
        return "SCH001"

    @property
    def description(self) -> str:
        return "Validate configuration against JSON Schema"

    def set_schema(self, schema: dict[str, Any]) -> None:
        """Set the schema to validate against."""
        self._schema = schema

    def load_schema(self, schema_path: str) -> None:
        """Load a schema from a file."""
        content = Path(schema_path).read_text(encoding="utf-8")
        self._schema = json.loads(content)

    def check(
        self,
        data: dict[str, Any],
        file_path: str = "",
        file_format: FileFormat = FileFormat.UNKNOWN,
        raw_content: str = "",
    ) -> list[LintFinding]:
        if self._schema is None:
            return []

        findings: list[LintFinding] = []

        try:
            import jsonschema
            validator = jsonschema.Draft7Validator(self._schema)
            for error in sorted(validator.iter_errors(data), key=lambda e: list(e.path)):
                key_path = ".".join(str(p) for p in error.absolute_path)
                findings.append(LintFinding(
                    rule_id=self.rule_id,
                    severity=Severity.ERROR,
                    message=error.message,
                    file_path=file_path,
                    key_path=key_path or "(root)",
                    suggestion="Fix the value to match the schema",
                ))
        except ImportError:
            findings.append(LintFinding(
                rule_id=self.rule_id,
                severity=Severity.WARNING,
                message="jsonschema package not installed, schema validation skipped",
                file_path=file_path,
            ))

        return findings
