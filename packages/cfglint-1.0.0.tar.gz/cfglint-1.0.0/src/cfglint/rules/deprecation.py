"""Deprecation detection rules."""

from __future__ import annotations

import re
from typing import Any

from cfglint.models import FileFormat, LintFinding, Severity
from cfglint.rules.base import Rule


class DeprecatedKeyRule(Rule):
    """Detect commonly deprecated configuration keys."""

    # Known deprecated keys with their replacements
    _DEPRECATED: dict[str, str] = {
        "slave": "replica",
        "master": "primary",
        "whitelist": "allowlist",
        "blacklist": "denylist",
        "dummy": "placeholder",
        "sanity_check": "validation_check",
    }

    # Common deprecated setting patterns
    _DEPRECATED_PATTERNS: list[tuple[re.Pattern, str]] = [
        (re.compile(r"(?i)ssl_verify\s*=?\s*false"), "Disabling SSL verification is deprecated and insecure"),
        (re.compile(r"(?i)tls_version.*1\.0"), "TLS 1.0 is deprecated, use TLS 1.2+"),
        (re.compile(r"(?i)tls_version.*1\.1"), "TLS 1.1 is deprecated, use TLS 1.2+"),
    ]

    @property
    def rule_id(self) -> str:
        return "DEP001"

    @property
    def description(self) -> str:
        return "Detect deprecated configuration keys and values"

    def check(
        self,
        data: dict[str, Any],
        file_path: str = "",
        file_format: FileFormat = FileFormat.UNKNOWN,
        raw_content: str = "",
    ) -> list[LintFinding]:
        findings: list[LintFinding] = []
        self._walk(data, "", findings, file_path)

        # Check raw content for patterns
        if raw_content:
            for pattern, message in self._DEPRECATED_PATTERNS:
                if pattern.search(raw_content):
                    findings.append(LintFinding(
                        rule_id=self.rule_id,
                        severity=Severity.WARNING,
                        message=message,
                        file_path=file_path,
                    ))

        return findings

    def _walk(self, data: Any, path: str, findings: list[LintFinding], fp: str) -> None:
        if isinstance(data, dict):
            for key, value in data.items():
                key_path = f"{path}.{key}" if path else key
                key_lower = key.lower()

                for deprecated, replacement in self._DEPRECATED.items():
                    if deprecated in key_lower:
                        findings.append(LintFinding(
                            rule_id=self.rule_id,
                            severity=Severity.WARNING,
                            message=f"Key '{key}' uses deprecated term '{deprecated}'",
                            file_path=fp,
                            key_path=key_path,
                            suggestion=f"Consider using '{replacement}' instead",
                        ))
                        break

                if isinstance(value, (dict, list)):
                    self._walk(value, key_path, findings, fp)
        elif isinstance(data, list):
            for i, item in enumerate(data):
                self._walk(item, f"{path}[{i}]", findings, fp)
