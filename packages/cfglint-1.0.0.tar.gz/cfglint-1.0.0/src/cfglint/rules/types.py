"""Type validation rules for config values."""

from __future__ import annotations

import re
from typing import Any

from cfglint.models import FileFormat, LintFinding, Severity
from cfglint.rules.base import Rule


class TypeCoercionRule(Rule):
    """Detect values that might be wrong type (string '3306' for port, etc.)."""

    # Keys that typically should be integers
    _INTEGER_KEYS = re.compile(
        r"(?i)(port|timeout|max_?retries|pool_?size|workers|threads|"
        r"batch_?size|limit|ttl|interval|max_?connections|buffer_?size)"
    )

    # Keys that typically should be booleans
    _BOOLEAN_KEYS = re.compile(
        r"(?i)(enabled|disabled|active|allow|deny|required|optional|"
        r"ssl|tls|verify|strict|force|auto_?commit)"
    )

    _BOOL_STRINGS = {"true", "false", "yes", "no", "on", "off", "1", "0"}

    @property
    def rule_id(self) -> str:
        return "TYP001"

    @property
    def description(self) -> str:
        return "Detect likely type mismatches in values"

    def check(
        self,
        data: dict[str, Any],
        file_path: str = "",
        file_format: FileFormat = FileFormat.UNKNOWN,
        raw_content: str = "",
    ) -> list[LintFinding]:
        findings: list[LintFinding] = []
        self._walk(data, "", findings, file_path)
        return findings

    def _walk(self, data: Any, path: str, findings: list[LintFinding], fp: str) -> None:
        if isinstance(data, dict):
            for key, value in data.items():
                key_path = f"{path}.{key}" if path else key

                if isinstance(value, str):
                    # Check if string should be int
                    if self._INTEGER_KEYS.search(key) and value.isdigit():
                        findings.append(LintFinding(
                            rule_id=self.rule_id,
                            severity=Severity.INFO,
                            message=f"String '{value}' at '{key_path}' looks like it should be an integer",
                            file_path=fp,
                            key_path=key_path,
                            suggestion=f"Use {value} (without quotes) instead of \"{value}\"",
                            auto_fixable=True,
                        ))

                    # Check if string should be bool
                    if self._BOOLEAN_KEYS.search(key) and value.lower() in self._BOOL_STRINGS:
                        findings.append(LintFinding(
                            rule_id=self.rule_id,
                            severity=Severity.INFO,
                            message=f"String '{value}' at '{key_path}' looks like it should be a boolean",
                            file_path=fp,
                            key_path=key_path,
                            suggestion=f"Use {'true' if value.lower() in ('true', 'yes', 'on', '1') else 'false'} instead",
                            auto_fixable=True,
                        ))

                elif isinstance(value, (dict, list)):
                    self._walk(value, key_path, findings, fp)
        elif isinstance(data, list):
            for i, item in enumerate(data):
                self._walk(item, f"{path}[{i}]", findings, fp)


class PortRangeRule(Rule):
    """Validate port numbers are in valid range."""

    @property
    def rule_id(self) -> str:
        return "TYP002"

    @property
    def description(self) -> str:
        return "Validate port numbers are in valid range (1-65535)"

    def check(
        self,
        data: dict[str, Any],
        file_path: str = "",
        file_format: FileFormat = FileFormat.UNKNOWN,
        raw_content: str = "",
    ) -> list[LintFinding]:
        findings: list[LintFinding] = []
        self._walk(data, "", findings, file_path)
        return findings

    def _walk(self, data: Any, path: str, findings: list[LintFinding], fp: str) -> None:
        if isinstance(data, dict):
            for key, value in data.items():
                key_path = f"{path}.{key}" if path else key
                if re.search(r"(?i)port", key):
                    port = self._to_port(value)
                    if port is not None and (port < 1 or port > 65535):
                        findings.append(LintFinding(
                            rule_id=self.rule_id,
                            severity=Severity.ERROR,
                            message=f"Invalid port number {port} at '{key_path}' (must be 1-65535)",
                            file_path=fp,
                            key_path=key_path,
                        ))
                elif isinstance(value, (dict, list)):
                    self._walk(value, key_path, findings, fp)
        elif isinstance(data, list):
            for i, item in enumerate(data):
                self._walk(item, f"{path}[{i}]", findings, fp)

    def _to_port(self, value: Any) -> int | None:
        if isinstance(value, int):
            return value
        if isinstance(value, str) and value.isdigit():
            return int(value)
        return None
