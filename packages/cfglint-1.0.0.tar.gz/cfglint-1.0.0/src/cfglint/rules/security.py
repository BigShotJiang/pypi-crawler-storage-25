"""Security-related lint rules."""

from __future__ import annotations

import re
from typing import Any

from cfglint.models import FileFormat, LintFinding, Severity
from cfglint.rules.base import Rule


class SecretDetectionRule(Rule):
    """Detect potential secrets/credentials in config values."""

    _SECRET_KEY_PATTERNS = [
        re.compile(r"(?i)(password|passwd|pwd)(?!.*(_file|_path|_env|_ref))"),
        re.compile(r"(?i)(secret|token|api_?key|auth_?key|access_?key)(?!.*(_file|_path|_env|_ref))"),
        re.compile(r"(?i)(private_?key|priv_?key)"),
        re.compile(r"(?i)(connection_?string|conn_?str)"),
    ]

    _SECRET_VALUE_PATTERNS = [
        re.compile(r"^(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9_]{36,}$"),  # GitHub tokens
        re.compile(r"^sk-[A-Za-z0-9]{32,}$"),  # OpenAI keys
        re.compile(r"^AKIA[0-9A-Z]{16}$"),  # AWS access keys
        re.compile(r"^(?:eyJ)[A-Za-z0-9_-]{20,}\."),  # JWTs
        re.compile(r"^[A-Za-z0-9+/]{40,}={0,2}$"),  # Base64 long strings
    ]

    _SAFE_PLACEHOLDERS = {
        "", "changeme", "todo", "fixme", "xxx", "your-secret-here",
        "replace-me", "none", "null", "undefined", "placeholder",
        "${", "{{", "<%",
    }

    @property
    def rule_id(self) -> str:
        return "SEC001"

    @property
    def description(self) -> str:
        return "Detect hardcoded secrets and credentials"

    def check(
        self,
        data: dict[str, Any],
        file_path: str = "",
        file_format: FileFormat = FileFormat.UNKNOWN,
        raw_content: str = "",
    ) -> list[LintFinding]:
        findings: list[LintFinding] = []
        self._walk(data, "", findings, file_path)
        return findings

    def _walk(
        self,
        data: Any,
        path: str,
        findings: list[LintFinding],
        file_path: str,
    ) -> None:
        if isinstance(data, dict):
            for key, value in data.items():
                key_path = f"{path}.{key}" if path else key
                if isinstance(value, str) and self._is_secret_key(key):
                    if not self._is_safe_placeholder(value):
                        findings.append(LintFinding(
                            rule_id=self.rule_id,
                            severity=Severity.ERROR,
                            message=f"Potential hardcoded secret in key '{key}'",
                            file_path=file_path,
                            key_path=key_path,
                            suggestion="Use environment variables or a secrets manager",
                            auto_fixable=False,
                        ))
                elif isinstance(value, str) and self._is_secret_value(value):
                    findings.append(LintFinding(
                        rule_id=self.rule_id,
                        severity=Severity.WARNING,
                        message=f"Value at '{key_path}' looks like a secret token",
                        file_path=file_path,
                        key_path=key_path,
                        suggestion="Verify this is not a real credential",
                    ))
                else:
                    self._walk(value, key_path, findings, file_path)
        elif isinstance(data, list):
            for i, item in enumerate(data):
                self._walk(item, f"{path}[{i}]", findings, file_path)

    def _is_secret_key(self, key: str) -> bool:
        return any(p.search(key) for p in self._SECRET_KEY_PATTERNS)

    def _is_secret_value(self, value: str) -> bool:
        return any(p.match(value) for p in self._SECRET_VALUE_PATTERNS)

    def _is_safe_placeholder(self, value: str) -> bool:
        v = value.strip().lower()
        return any(v.startswith(p) if p.endswith("{") else v == p
                   for p in self._SAFE_PLACEHOLDERS)


class WeakPasswordRule(Rule):
    """Detect weak or default passwords."""

    _WEAK_PASSWORDS = {
        "admin", "password", "123456", "12345678", "root", "toor",
        "default", "guest", "test", "letmein", "qwerty", "abc123",
        "password123", "admin123", "1234567890", "welcome",
    }

    @property
    def rule_id(self) -> str:
        return "SEC002"

    @property
    def description(self) -> str:
        return "Detect weak or default passwords"

    def check(
        self,
        data: dict[str, Any],
        file_path: str = "",
        file_format: FileFormat = FileFormat.UNKNOWN,
        raw_content: str = "",
    ) -> list[LintFinding]:
        findings: list[LintFinding] = []
        self._walk(data, "", findings, file_path)
        return findings

    def _walk(self, data: Any, path: str, findings: list[LintFinding], fp: str) -> None:
        if isinstance(data, dict):
            for key, value in data.items():
                key_path = f"{path}.{key}" if path else key
                if isinstance(value, str) and self._is_password_key(key):
                    if value.lower() in self._WEAK_PASSWORDS:
                        findings.append(LintFinding(
                            rule_id=self.rule_id,
                            severity=Severity.ERROR,
                            message=f"Weak/default password detected at '{key_path}'",
                            file_path=fp,
                            key_path=key_path,
                            suggestion="Use a strong, unique password",
                            auto_fixable=False,
                        ))
                elif isinstance(value, (dict, list)):
                    self._walk(value, key_path, findings, fp)
        elif isinstance(data, list):
            for i, item in enumerate(data):
                self._walk(item, f"{path}[{i}]", findings, fp)

    def _is_password_key(self, key: str) -> bool:
        return bool(re.search(r"(?i)(password|passwd|pwd)", key))


class InsecureProtocolRule(Rule):
    """Detect insecure protocol URLs in config values."""

    _INSECURE_PATTERNS = [
        re.compile(r"^http://(?!localhost|127\.0\.0\.1|0\.0\.0\.0|\[::1\])"),
        re.compile(r"^ftp://"),
        re.compile(r"^telnet://"),
    ]

    @property
    def rule_id(self) -> str:
        return "SEC003"

    @property
    def description(self) -> str:
        return "Detect insecure protocol URLs"

    def check(
        self,
        data: dict[str, Any],
        file_path: str = "",
        file_format: FileFormat = FileFormat.UNKNOWN,
        raw_content: str = "",
    ) -> list[LintFinding]:
        findings: list[LintFinding] = []
        self._walk(data, "", findings, file_path)
        return findings

    def _walk(self, data: Any, path: str, findings: list[LintFinding], fp: str) -> None:
        if isinstance(data, dict):
            for key, value in data.items():
                key_path = f"{path}.{key}" if path else key
                if isinstance(value, str):
                    for pattern in self._INSECURE_PATTERNS:
                        if pattern.match(value):
                            proto = value.split("://")[0]
                            findings.append(LintFinding(
                                rule_id=self.rule_id,
                                severity=Severity.WARNING,
                                message=f"Insecure protocol '{proto}://' at '{key_path}'",
                                file_path=fp,
                                key_path=key_path,
                                suggestion=f"Use {'https' if proto == 'http' else 'sftp' if proto == 'ftp' else 'ssh'}:// instead",
                            ))
                            break
                else:
                    self._walk(value, key_path, findings, fp)
        elif isinstance(data, list):
            for i, item in enumerate(data):
                self._walk(item, f"{path}[{i}]", findings, fp)


class DebugEnabledRule(Rule):
    """Detect debug mode enabled in production configs."""

    _DEBUG_KEYS = re.compile(r"(?i)^(debug|verbose|trace|dev_?mode)$")

    @property
    def rule_id(self) -> str:
        return "SEC004"

    @property
    def description(self) -> str:
        return "Detect debug/verbose mode enabled"

    def check(
        self,
        data: dict[str, Any],
        file_path: str = "",
        file_format: FileFormat = FileFormat.UNKNOWN,
        raw_content: str = "",
    ) -> list[LintFinding]:
        findings: list[LintFinding] = []
        self._walk(data, "", findings, file_path)
        return findings

    def _walk(self, data: Any, path: str, findings: list[LintFinding], fp: str) -> None:
        if isinstance(data, dict):
            for key, value in data.items():
                key_path = f"{path}.{key}" if path else key
                if self._DEBUG_KEYS.match(key):
                    if self._is_truthy(value):
                        findings.append(LintFinding(
                            rule_id=self.rule_id,
                            severity=Severity.WARNING,
                            message=f"Debug/verbose mode enabled at '{key_path}'",
                            file_path=fp,
                            key_path=key_path,
                            suggestion="Disable debug mode in production configs",
                        ))
                elif isinstance(value, (dict, list)):
                    self._walk(value, key_path, findings, fp)
        elif isinstance(data, list):
            for i, item in enumerate(data):
                self._walk(item, f"{path}[{i}]", findings, fp)

    def _is_truthy(self, value: Any) -> bool:
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.lower() in ("true", "1", "yes", "on")
        if isinstance(value, (int, float)):
            return value != 0
        return False
