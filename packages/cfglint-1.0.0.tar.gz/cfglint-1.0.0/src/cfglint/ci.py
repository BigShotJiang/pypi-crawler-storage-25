"""CI/CD integration helpers."""

from __future__ import annotations

from typing import Any

from cfglint.models import LintResult, Severity


class GitHubAnnotation:
    """Format findings as GitHub Actions annotations."""

    _LEVEL_MAP = {
        Severity.ERROR: "error",
        Severity.WARNING: "warning",
        Severity.INFO: "notice",
    }

    def format_results(self, results: list[LintResult]) -> str:
        """Format results as GitHub Actions annotation commands."""
        lines: list[str] = []
        for result in results:
            for finding in result.findings:
                level = self._LEVEL_MAP.get(finding.severity, "notice")
                file_part = f"file={finding.file_path or result.file_path}"
                line_part = f",line={finding.line}" if finding.line else ""
                col_part = f",col={finding.column}" if finding.column else ""
                title = f",title={finding.rule_id}"

                msg = finding.message
                if finding.key_path:
                    msg += f" (at {finding.key_path})"

                lines.append(f"::{level} {file_part}{line_part}{col_part}{title}::{msg}")

        return "\n".join(lines)


class ExitCodeCalculator:
    """Calculate CI-appropriate exit codes."""

    def calculate(
        self,
        results: list[LintResult],
        strict: bool = False,
        fail_on_warning: bool = False,
    ) -> int:
        """Calculate exit code. 0 = success, 1 = failure."""
        has_errors = any(r.has_errors for r in results)
        has_warnings = any(r.warning_count > 0 for r in results)
        has_parse_errors = any(r.parse_error is not None for r in results)

        if has_errors or has_parse_errors:
            return 1
        if strict and has_warnings:
            return 1
        if fail_on_warning and has_warnings:
            return 1
        return 0


def generate_github_workflow() -> str:
    """Generate a sample GitHub Actions workflow for cfglint."""
    return """name: Config Lint

on:
  push:
    paths:
      - '**/*.yaml'
      - '**/*.yml'
      - '**/*.json'
      - '**/*.toml'
      - '**/*.ini'
      - '**/*.env'
  pull_request:
    paths:
      - '**/*.yaml'
      - '**/*.yml'
      - '**/*.json'
      - '**/*.toml'
      - '**/*.ini'
      - '**/*.env'

jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.12'

      - name: Install cfglint
        run: pip install cfglint

      - name: Lint config files
        run: cfglint scan . --format sarif > results.sarif

      - name: Upload SARIF
        uses: github/codeql-action/upload-sarif@v3
        with:
          sarif_file: results.sarif
        if: always()
"""
