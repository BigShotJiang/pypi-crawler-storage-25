"""Auto-fix engine for configuration issues."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from cfglint.models import FileFormat, LintFinding, LintResult
from cfglint.parsers.base import detect_format, parse_content


class ConfigFixer:
    """Apply automatic fixes to configuration files."""

    def fix_result(self, result: LintResult, raw_content: str) -> tuple[str, list[str]]:
        """Apply fixes based on lint result. Returns (fixed_content, applied_fixes)."""
        if result.parsed_data is None:
            return raw_content, []

        data = result.parsed_data.copy()
        applied: list[str] = []

        for finding in result.findings:
            if finding.rule_id == "SEC004":
                # Fix debug/verbose enabled
                fixed = self._fix_debug_enabled(data, finding.key_path)
                if fixed:
                    applied.append(f"Disabled debug at '{finding.key_path}'")

            elif finding.rule_id == "STR001" and finding.severity.value == "warning":
                # Remove null values
                fixed = self._remove_key(data, finding.key_path)
                if fixed:
                    applied.append(f"Removed null key '{finding.key_path}'")

            elif finding.rule_id == "SEC003":
                # Fix insecure protocols
                fixed = self._fix_protocol(data, finding.key_path)
                if fixed:
                    applied.append(f"Upgraded protocol at '{finding.key_path}'")

        if not applied:
            return raw_content, []

        # Re-serialize
        from cfglint.parsers.base import _get_parser
        try:
            parser = _get_parser(result.file_format)
            new_content = parser.dump(data)
            return new_content, applied
        except Exception:
            return raw_content, []

    def fix_file(self, file_path: str) -> tuple[str, list[str]]:
        """Fix a file in place. Returns (new_content, applied_fixes)."""
        from cfglint.linter import Linter

        path = Path(file_path)
        raw = path.read_text(encoding="utf-8")
        fmt = detect_format(file_path)

        linter = Linter()
        result = linter.lint_content(raw, fmt, file_path)
        new_content, applied = self.fix_result(result, raw)

        if applied:
            path.write_text(new_content, encoding="utf-8")

        return new_content, applied

    def _fix_debug_enabled(self, data: dict[str, Any], key_path: str) -> bool:
        """Set debug/verbose to false."""
        return self._set_value(data, key_path, False)

    def _fix_protocol(self, data: dict[str, Any], key_path: str) -> bool:
        """Replace insecure protocols with secure ones."""
        value = self._get_value(data, key_path)
        if isinstance(value, str):
            new_value = value
            if value.startswith("http://"):
                new_value = "https://" + value[7:]
            elif value.startswith("ftp://"):
                new_value = "sftp://" + value[6:]
            elif value.startswith("telnet://"):
                new_value = "ssh://" + value[9:]
            if new_value != value:
                return self._set_value(data, key_path, new_value)
        return False

    def _remove_key(self, data: dict[str, Any], key_path: str) -> bool:
        """Remove a key from nested dict."""
        parts = key_path.split(".")
        current = data
        for part in parts[:-1]:
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return False
        if isinstance(current, dict) and parts[-1] in current:
            del current[parts[-1]]
            return True
        return False

    def _get_value(self, data: dict[str, Any], key_path: str) -> Any:
        """Get a value from nested dict by dot-path."""
        parts = key_path.split(".")
        current: Any = data
        for part in parts:
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return None
        return current

    def _set_value(self, data: dict[str, Any], key_path: str, value: Any) -> bool:
        """Set a value in nested dict by dot-path."""
        parts = key_path.split(".")
        current = data
        for part in parts[:-1]:
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return False
        if isinstance(current, dict):
            current[parts[-1]] = value
            return True
        return False
