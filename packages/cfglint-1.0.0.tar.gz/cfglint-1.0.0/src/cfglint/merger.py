"""Config merge engine - merge multiple config files with strategies."""

from __future__ import annotations

from enum import Enum
from typing import Any

from cfglint.parsers.base import parse_file


class MergeStrategy(Enum):
    """How to handle conflicts during merge."""
    OVERRIDE = "override"    # Later values win
    KEEP = "keep"            # Earlier values win
    DEEP_MERGE = "deep"      # Recursively merge dicts


class ConfigMerger:
    """Merge multiple configuration sources."""

    def __init__(self, strategy: MergeStrategy = MergeStrategy.DEEP_MERGE) -> None:
        self.strategy = strategy

    def merge_files(self, *file_paths: str) -> dict[str, Any]:
        """Merge multiple config files."""
        result: dict[str, Any] = {}
        for fp in file_paths:
            data, _ = parse_file(fp)
            result = self.merge_dicts(result, data)
        return result

    def merge_dicts(
        self,
        base: dict[str, Any],
        override: dict[str, Any],
    ) -> dict[str, Any]:
        """Merge two dictionaries according to strategy."""
        if self.strategy == MergeStrategy.OVERRIDE:
            return {**base, **override}
        elif self.strategy == MergeStrategy.KEEP:
            return {**override, **base}
        else:
            return self._deep_merge(base, override)

    def _deep_merge(
        self,
        base: dict[str, Any],
        override: dict[str, Any],
    ) -> dict[str, Any]:
        """Recursively merge two dicts."""
        result = dict(base)
        for key, value in override.items():
            if (
                key in result
                and isinstance(result[key], dict)
                and isinstance(value, dict)
            ):
                result[key] = self._deep_merge(result[key], value)
            else:
                result[key] = value
        return result
