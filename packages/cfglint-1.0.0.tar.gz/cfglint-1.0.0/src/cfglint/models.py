"""Data models for cfglint."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any


class Severity(Enum):
    """Severity levels for lint findings."""
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"

    def __lt__(self, other: "Severity") -> bool:
        if not isinstance(other, Severity):
            return NotImplemented
        order = {Severity.INFO: 0, Severity.WARNING: 1, Severity.ERROR: 2}
        return order[self] < order[other]

    def __le__(self, other: "Severity") -> bool:
        if not isinstance(other, Severity):
            return NotImplemented
        return self == other or self < other

    def __gt__(self, other: "Severity") -> bool:
        if not isinstance(other, Severity):
            return NotImplemented
        return not self <= other

    def __ge__(self, other: "Severity") -> bool:
        if not isinstance(other, Severity):
            return NotImplemented
        return not self < other


class FileFormat(Enum):
    """Supported configuration file formats."""
    YAML = "yaml"
    JSON = "json"
    TOML = "toml"
    INI = "ini"
    ENV = "env"
    UNKNOWN = "unknown"


@dataclass
class LintFinding:
    """A single lint finding."""
    rule_id: str
    severity: Severity
    message: str
    file_path: str = ""
    line: int | None = None
    column: int | None = None
    key_path: str = ""
    suggestion: str = ""
    auto_fixable: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "severity": self.severity.value,
            "message": self.message,
            "file_path": self.file_path,
            "line": self.line,
            "column": self.column,
            "key_path": self.key_path,
            "suggestion": self.suggestion,
            "auto_fixable": self.auto_fixable,
        }


@dataclass
class LintResult:
    """Result of linting a configuration file."""
    file_path: str
    file_format: FileFormat
    findings: list[LintFinding] = field(default_factory=list)
    parsed_data: dict[str, Any] | None = None
    parse_error: str | None = None

    @property
    def error_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.ERROR)

    @property
    def warning_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.WARNING)

    @property
    def info_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.INFO)

    @property
    def has_errors(self) -> bool:
        return self.error_count > 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "file_path": self.file_path,
            "file_format": self.file_format.value,
            "findings": [f.to_dict() for f in self.findings],
            "parse_error": self.parse_error,
            "error_count": self.error_count,
            "warning_count": self.warning_count,
            "info_count": self.info_count,
        }


@dataclass
class DiffEntry:
    """A single diff entry between two config files."""
    key_path: str
    change_type: str  # "added", "removed", "modified"
    old_value: Any = None
    new_value: Any = None

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "key_path": self.key_path,
            "change_type": self.change_type,
        }
        if self.old_value is not None:
            result["old_value"] = self.old_value
        if self.new_value is not None:
            result["new_value"] = self.new_value
        return result


@dataclass
class DiffResult:
    """Result of diffing two config files."""
    file_a: str
    file_b: str
    entries: list[DiffEntry] = field(default_factory=list)

    @property
    def has_changes(self) -> bool:
        return len(self.entries) > 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "file_a": self.file_a,
            "file_b": self.file_b,
            "entries": [e.to_dict() for e in self.entries],
            "total_changes": len(self.entries),
        }


@dataclass
class LintConfig:
    """Configuration for the linter."""
    severity_threshold: Severity = Severity.INFO
    enabled_rules: list[str] = field(default_factory=list)
    disabled_rules: list[str] = field(default_factory=list)
    schema_path: str | None = None
    ignore_patterns: list[str] = field(default_factory=list)
    custom_secret_patterns: list[str] = field(default_factory=list)
