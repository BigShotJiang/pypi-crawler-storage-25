"""Statistics and summary reporting for lint results."""

from __future__ import annotations

from collections import Counter
from typing import Any

from cfglint.models import LintResult, Severity


class LintStats:
    """Compute statistics across multiple lint results."""

    def __init__(self, results: list[LintResult]) -> None:
        self.results = results

    @property
    def total_files(self) -> int:
        return len(self.results)

    @property
    def files_with_errors(self) -> int:
        return sum(1 for r in self.results if r.has_errors)

    @property
    def files_with_warnings(self) -> int:
        return sum(1 for r in self.results if r.warning_count > 0)

    @property
    def clean_files(self) -> int:
        return sum(1 for r in self.results
                   if not r.findings and r.parse_error is None)

    @property
    def total_findings(self) -> int:
        return sum(len(r.findings) for r in self.results)

    @property
    def total_errors(self) -> int:
        return sum(r.error_count for r in self.results)

    @property
    def total_warnings(self) -> int:
        return sum(r.warning_count for r in self.results)

    @property
    def total_infos(self) -> int:
        return sum(r.info_count for r in self.results)

    @property
    def parse_errors(self) -> int:
        return sum(1 for r in self.results if r.parse_error is not None)

    def findings_by_rule(self) -> dict[str, int]:
        """Count findings grouped by rule ID."""
        counter: Counter[str] = Counter()
        for result in self.results:
            for finding in result.findings:
                counter[finding.rule_id] += 1
        return dict(counter.most_common())

    def findings_by_severity(self) -> dict[str, int]:
        """Count findings grouped by severity."""
        return {
            "error": self.total_errors,
            "warning": self.total_warnings,
            "info": self.total_infos,
        }

    def most_common_issues(self, n: int = 5) -> list[tuple[str, int]]:
        """Get the N most common rule violations."""
        counter: Counter[str] = Counter()
        for result in self.results:
            for finding in result.findings:
                counter[finding.rule_id] += 1
        return counter.most_common(n)

    def formats_scanned(self) -> dict[str, int]:
        """Count files by format."""
        counter: Counter[str] = Counter()
        for result in self.results:
            counter[result.file_format.value] += 1
        return dict(counter)

    def to_dict(self) -> dict[str, Any]:
        """Full stats as dictionary."""
        return {
            "total_files": self.total_files,
            "files_with_errors": self.files_with_errors,
            "files_with_warnings": self.files_with_warnings,
            "clean_files": self.clean_files,
            "parse_errors": self.parse_errors,
            "total_findings": self.total_findings,
            "by_severity": self.findings_by_severity(),
            "by_rule": self.findings_by_rule(),
            "formats": self.formats_scanned(),
            "top_issues": self.most_common_issues(),
        }

    def summary_text(self) -> str:
        """Generate a human-readable summary."""
        lines = [
            f"Files scanned: {self.total_files}",
            f"  Clean: {self.clean_files}",
            f"  With errors: {self.files_with_errors}",
            f"  With warnings: {self.files_with_warnings}",
            f"  Parse errors: {self.parse_errors}",
            f"",
            f"Total findings: {self.total_findings}",
            f"  Errors: {self.total_errors}",
            f"  Warnings: {self.total_warnings}",
            f"  Info: {self.total_infos}",
        ]

        top = self.most_common_issues()
        if top:
            lines.append("")
            lines.append("Top issues:")
            for rule_id, count in top:
                lines.append(f"  {rule_id}: {count}")

        return "\n".join(lines)
