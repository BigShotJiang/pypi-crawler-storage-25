"""Validation presets for common config file types."""

from __future__ import annotations

from typing import Any

from cfglint.models import LintConfig, Severity


# Preset definitions: name -> config overrides
PRESETS: dict[str, dict[str, Any]] = {
    "strict": {
        "severity": "info",
        "description": "Report all issues including informational",
    },
    "production": {
        "severity": "warning",
        "enable": ["SEC001", "SEC002", "SEC003", "SEC004", "ENV001", "ENV002"],
        "description": "Production-focused security checks",
    },
    "security": {
        "severity": "warning",
        "enable": ["SEC001", "SEC002", "SEC003", "SEC004", "NAM002", "DEP001"],
        "description": "Security-only checks",
    },
    "ci": {
        "severity": "error",
        "description": "Errors only, suitable for CI/CD pipelines",
    },
    "minimal": {
        "severity": "error",
        "enable": ["SEC001", "SEC002"],
        "description": "Minimal checks: secrets and weak passwords only",
    },
}


def list_presets() -> list[dict[str, str]]:
    """List all available presets."""
    return [
        {"name": name, "description": config.get("description", "")}
        for name, config in PRESETS.items()
    ]


def get_preset(name: str) -> dict[str, Any] | None:
    """Get a preset by name."""
    return PRESETS.get(name)


def apply_preset(name: str, config: LintConfig | None = None) -> LintConfig:
    """Apply a preset to a LintConfig."""
    preset = PRESETS.get(name)
    if preset is None:
        raise ValueError(f"Unknown preset: {name}")

    if config is None:
        config = LintConfig()

    severity_map = {
        "info": Severity.INFO,
        "warning": Severity.WARNING,
        "error": Severity.ERROR,
    }

    if "severity" in preset:
        config.severity_threshold = severity_map.get(
            preset["severity"], Severity.INFO
        )

    if "enable" in preset:
        config.enabled_rules = preset["enable"]

    if "disable" in preset:
        config.disabled_rules = preset["disable"]

    return config
