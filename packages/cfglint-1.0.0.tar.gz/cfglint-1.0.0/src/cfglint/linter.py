"""Core linting engine."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from cfglint.models import (
    FileFormat,
    LintConfig,
    LintFinding,
    LintResult,
    Severity,
)
from cfglint.parsers.base import detect_format, parse_content
from cfglint.rules.base import Rule, RuleRegistry, get_default_registry


class Linter:
    """Main linting engine for configuration files."""

    def __init__(
        self,
        config: LintConfig | None = None,
        registry: RuleRegistry | None = None,
    ) -> None:
        self.config = config or LintConfig()
        self.registry = registry or get_default_registry()

    def lint_file(self, file_path: str) -> LintResult:
        """Lint a configuration file."""
        path = Path(file_path)
        fmt = detect_format(file_path)

        if fmt == FileFormat.UNKNOWN:
            return LintResult(
                file_path=file_path,
                file_format=fmt,
                parse_error=f"Unsupported file format: {path.suffix}",
            )

        try:
            raw_content = path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return LintResult(
                file_path=file_path,
                file_format=fmt,
                parse_error=f"File not found: {file_path}",
            )
        except Exception as e:
            return LintResult(
                file_path=file_path,
                file_format=fmt,
                parse_error=f"Error reading file: {e}",
            )

        return self.lint_content(raw_content, fmt, file_path)

    def lint_content(
        self,
        content: str,
        fmt: FileFormat,
        file_path: str = "<stdin>",
    ) -> LintResult:
        """Lint configuration content."""
        try:
            data = parse_content(content, fmt)
        except Exception as e:
            return LintResult(
                file_path=file_path,
                file_format=fmt,
                parse_error=f"Parse error: {e}",
            )

        result = LintResult(
            file_path=file_path,
            file_format=fmt,
            parsed_data=data,
        )

        # Run all enabled rules
        for rule in self._get_active_rules():
            try:
                findings = rule.check(
                    data=data,
                    file_path=file_path,
                    file_format=fmt,
                    raw_content=content,
                )
                # Filter by severity threshold
                for finding in findings:
                    if finding.severity >= self.config.severity_threshold:
                        result.findings.append(finding)
            except Exception as e:
                result.findings.append(LintFinding(
                    rule_id=rule.rule_id,
                    severity=Severity.WARNING,
                    message=f"Rule {rule.rule_id} failed: {e}",
                    file_path=file_path,
                ))

        return result

    def lint_files(self, file_paths: list[str]) -> list[LintResult]:
        """Lint multiple files."""
        return [self.lint_file(fp) for fp in file_paths]

    def _get_active_rules(self) -> list[Rule]:
        """Get rules that should be active based on config."""
        rules = self.registry.all_rules()

        if self.config.enabled_rules:
            rules = [r for r in rules if r.rule_id in self.config.enabled_rules]

        if self.config.disabled_rules:
            rules = [r for r in rules if r.rule_id not in self.config.disabled_rules]

        return rules

    def list_rules(self) -> list[dict[str, str]]:
        """List all available rules."""
        return [
            {"rule_id": r.rule_id, "description": r.description}
            for r in self.registry.all_rules()
        ]
