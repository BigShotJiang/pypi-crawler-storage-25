"""Config diff engine."""

from __future__ import annotations

from typing import Any

from cfglint.models import DiffEntry, DiffResult
from cfglint.parsers.base import detect_format, parse_file


class ConfigDiffer:
    """Compare two configuration files and find differences."""

    def diff_files(self, file_a: str, file_b: str) -> DiffResult:
        """Diff two configuration files."""
        data_a, _ = parse_file(file_a)
        data_b, _ = parse_file(file_b)
        return self.diff_data(data_a, data_b, file_a, file_b)

    def diff_data(
        self,
        data_a: dict[str, Any],
        data_b: dict[str, Any],
        label_a: str = "a",
        label_b: str = "b",
    ) -> DiffResult:
        """Diff two data dictionaries."""
        result = DiffResult(file_a=label_a, file_b=label_b)
        self._compare(data_a, data_b, "", result.entries)
        return result

    def _compare(
        self,
        a: Any,
        b: Any,
        path: str,
        entries: list[DiffEntry],
    ) -> None:
        if isinstance(a, dict) and isinstance(b, dict):
            all_keys = set(a.keys()) | set(b.keys())
            for key in sorted(all_keys):
                key_path = f"{path}.{key}" if path else key
                if key not in a:
                    entries.append(DiffEntry(
                        key_path=key_path,
                        change_type="added",
                        new_value=b[key],
                    ))
                elif key not in b:
                    entries.append(DiffEntry(
                        key_path=key_path,
                        change_type="removed",
                        old_value=a[key],
                    ))
                else:
                    self._compare(a[key], b[key], key_path, entries)
        elif isinstance(a, list) and isinstance(b, list):
            max_len = max(len(a), len(b))
            for i in range(max_len):
                item_path = f"{path}[{i}]"
                if i >= len(a):
                    entries.append(DiffEntry(
                        key_path=item_path,
                        change_type="added",
                        new_value=b[i],
                    ))
                elif i >= len(b):
                    entries.append(DiffEntry(
                        key_path=item_path,
                        change_type="removed",
                        old_value=a[i],
                    ))
                else:
                    self._compare(a[i], b[i], item_path, entries)
        elif a != b:
            entries.append(DiffEntry(
                key_path=path,
                change_type="modified",
                old_value=a,
                new_value=b,
            ))
