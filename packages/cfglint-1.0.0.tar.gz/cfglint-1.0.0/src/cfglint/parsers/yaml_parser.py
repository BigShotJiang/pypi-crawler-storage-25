"""YAML configuration parser."""

from __future__ import annotations

from typing import Any

import yaml


class YamlParser:
    """Parse YAML configuration files."""

    def parse(self, content: str) -> dict[str, Any]:
        """Parse YAML content into a dictionary."""
        result = yaml.safe_load(content)
        if result is None:
            return {}
        if not isinstance(result, dict):
            raise ValueError("YAML root must be a mapping/object")
        return result

    def dump(self, data: dict[str, Any]) -> str:
        """Serialize data back to YAML."""
        return yaml.dump(data, default_flow_style=False, allow_unicode=True)
