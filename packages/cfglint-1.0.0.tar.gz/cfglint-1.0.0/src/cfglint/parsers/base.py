"""Base parser utilities."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from cfglint.models import FileFormat


# Extension to format mapping
_EXT_MAP: dict[str, FileFormat] = {
    ".yaml": FileFormat.YAML,
    ".yml": FileFormat.YAML,
    ".json": FileFormat.JSON,
    ".toml": FileFormat.TOML,
    ".ini": FileFormat.INI,
    ".cfg": FileFormat.INI,
    ".conf": FileFormat.INI,
    ".env": FileFormat.ENV,
}

# Filename-based detection
_NAME_MAP: dict[str, FileFormat] = {
    ".env": FileFormat.ENV,
    ".env.local": FileFormat.ENV,
    ".env.development": FileFormat.ENV,
    ".env.production": FileFormat.ENV,
    ".env.test": FileFormat.ENV,
    ".env.example": FileFormat.ENV,
}


def detect_format(file_path: str) -> FileFormat:
    """Detect the configuration file format from its extension or name."""
    p = Path(file_path)

    # Check full filename first
    if p.name in _NAME_MAP:
        return _NAME_MAP[p.name]

    # Check by extension
    suffix = p.suffix.lower()
    return _EXT_MAP.get(suffix, FileFormat.UNKNOWN)


def _get_parser(fmt: FileFormat):
    """Get the appropriate parser for a format."""
    from cfglint.parsers.yaml_parser import YamlParser
    from cfglint.parsers.json_parser import JsonParser
    from cfglint.parsers.toml_parser import TomlParser
    from cfglint.parsers.ini_parser import IniParser
    from cfglint.parsers.env_parser import EnvParser

    parsers = {
        FileFormat.YAML: YamlParser,
        FileFormat.JSON: JsonParser,
        FileFormat.TOML: TomlParser,
        FileFormat.INI: IniParser,
        FileFormat.ENV: EnvParser,
    }
    parser_cls = parsers.get(fmt)
    if parser_cls is None:
        raise ValueError(f"Unsupported format: {fmt.value}")
    return parser_cls()


def parse_file(file_path: str) -> tuple[dict[str, Any], FileFormat]:
    """Parse a configuration file and return data + detected format."""
    fmt = detect_format(file_path)
    if fmt == FileFormat.UNKNOWN:
        raise ValueError(f"Cannot detect format for: {file_path}")

    parser = _get_parser(fmt)
    content = Path(file_path).read_text(encoding="utf-8")
    data = parser.parse(content)
    return data, fmt


def parse_content(content: str, fmt: FileFormat) -> dict[str, Any]:
    """Parse configuration content given a known format."""
    parser = _get_parser(fmt)
    return parser.parse(content)
