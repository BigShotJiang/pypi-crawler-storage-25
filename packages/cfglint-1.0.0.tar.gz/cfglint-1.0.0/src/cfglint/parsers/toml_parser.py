"""TOML configuration parser."""

from __future__ import annotations

import sys
from typing import Any

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib


class TomlParser:
    """Parse TOML configuration files."""

    def parse(self, content: str) -> dict[str, Any]:
        """Parse TOML content into a dictionary."""
        return tomllib.loads(content)

    def dump(self, data: dict[str, Any]) -> str:
        """Serialize data back to TOML (basic implementation)."""
        lines: list[str] = []
        self._dump_table(data, lines, prefix="")
        return "\n".join(lines) + "\n"

    def _dump_table(
        self, data: dict[str, Any], lines: list[str], prefix: str
    ) -> None:
        for key, value in data.items():
            full_key = f"{prefix}.{key}" if prefix else key
            if isinstance(value, dict):
                lines.append(f"\n[{full_key}]")
                self._dump_table(value, lines, full_key)
            elif isinstance(value, list):
                items = ", ".join(self._format_value(v) for v in value)
                lines.append(f"{key} = [{items}]")
            else:
                lines.append(f"{key} = {self._format_value(value)}")

    def _format_value(self, value: Any) -> str:
        if isinstance(value, str):
            return f'"{value}"'
        if isinstance(value, bool):
            return "true" if value else "false"
        return str(value)
