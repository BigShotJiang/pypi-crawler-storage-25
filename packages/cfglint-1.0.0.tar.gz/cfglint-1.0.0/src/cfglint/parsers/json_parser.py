"""JSON configuration parser."""

from __future__ import annotations

import json
from typing import Any


class JsonParser:
    """Parse JSON configuration files."""

    def parse(self, content: str) -> dict[str, Any]:
        """Parse JSON content into a dictionary."""
        result = json.loads(content)
        if not isinstance(result, dict):
            raise ValueError("JSON root must be an object")
        return result

    def dump(self, data: dict[str, Any]) -> str:
        """Serialize data back to JSON."""
        return json.dumps(data, indent=2, ensure_ascii=False)
