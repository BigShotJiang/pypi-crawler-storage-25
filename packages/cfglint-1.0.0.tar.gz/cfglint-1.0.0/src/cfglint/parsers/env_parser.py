"""Environment file (.env) parser."""

from __future__ import annotations

import re
from typing import Any


class EnvParser:
    """Parse .env files into a dictionary."""

    # Pattern: KEY=VALUE or KEY="VALUE" or KEY='VALUE'
    _LINE_RE = re.compile(
        r"""^\s*
        (?:export\s+)?        # optional export prefix
        ([A-Za-z_][A-Za-z0-9_]*)  # key
        \s*=\s*               # equals
        (.*)                  # value
        $""",
        re.VERBOSE,
    )

    def parse(self, content: str) -> dict[str, Any]:
        """Parse .env content into a dictionary."""
        result: dict[str, Any] = {}

        for line in content.splitlines():
            line = line.strip()

            # Skip empty lines and comments
            if not line or line.startswith("#"):
                continue

            match = self._LINE_RE.match(line)
            if match:
                key = match.group(1)
                value = match.group(2).strip()

                # Remove surrounding quotes
                if len(value) >= 2:
                    if (value[0] == '"' and value[-1] == '"') or \
                       (value[0] == "'" and value[-1] == "'"):
                        value = value[1:-1]

                result[key] = value

        return result

    def dump(self, data: dict[str, Any]) -> str:
        """Serialize data back to .env format."""
        lines: list[str] = []
        for key, value in data.items():
            value_str = str(value)
            # Quote values with spaces
            if " " in value_str or "=" in value_str:
                value_str = f'"{value_str}"'
            lines.append(f"{key}={value_str}")
        return "\n".join(lines) + "\n"
