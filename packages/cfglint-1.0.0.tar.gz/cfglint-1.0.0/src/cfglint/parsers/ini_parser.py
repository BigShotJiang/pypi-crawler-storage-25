"""INI configuration parser."""

from __future__ import annotations

import configparser
import io
from typing import Any


class IniParser:
    """Parse INI/CFG configuration files."""

    def parse(self, content: str) -> dict[str, Any]:
        """Parse INI content into a nested dictionary."""
        parser = configparser.ConfigParser(interpolation=None)
        parser.read_string(content)

        result: dict[str, Any] = {}

        # Include DEFAULT section if it has values
        if parser.defaults():
            result["DEFAULT"] = dict(parser.defaults())

        for section in parser.sections():
            result[section] = {}
            for key, value in parser.items(section):
                # Skip defaults that appear in every section
                if key in parser.defaults() and parser.defaults()[key] == value:
                    continue
                result[section][key] = value

        return result

    def dump(self, data: dict[str, Any]) -> str:
        """Serialize data back to INI format."""
        parser = configparser.ConfigParser(interpolation=None)

        for section, values in data.items():
            if section == "DEFAULT":
                for key, value in values.items():
                    parser.set("DEFAULT", key, str(value))
            else:
                parser.add_section(section)
                for key, value in values.items():
                    parser.set(section, key, str(value))

        output = io.StringIO()
        parser.write(output)
        return output.getvalue()
