"""QiloBack Python SDK — sync client for the platform-api.

Public surface kept deliberately small so the import line is a single
``from qiloback import Client`` and everything else hangs off the
client. The async variant lands in v0.2 alongside the auto-generated
full-surface client; until then anything not exposed as a typed method
is reachable via ``client.request("GET", "/api/v1/...")`` which
returns the raw ``httpx.Response``.
"""

from __future__ import annotations

from qiloback._client import Client, ComponentsAPI
from qiloback._errors import (
    APIError,
    AuthError,
    NotFoundError,
    QiloBackError,
    ValidationError,
)
from qiloback._models import (
    DSLDiff,
    EjectBundle,
    GenerationLog,
    Project,
    ValidationResult,
)

__version__ = "0.1.0"

__all__ = [
    "APIError",
    "AuthError",
    "Client",
    "ComponentsAPI",
    "DSLDiff",
    "EjectBundle",
    "GenerationLog",
    "NotFoundError",
    "Project",
    "QiloBackError",
    "ValidationError",
    "ValidationResult",
    "__version__",
]
