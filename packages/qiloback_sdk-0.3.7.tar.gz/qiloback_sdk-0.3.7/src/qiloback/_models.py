"""Pydantic models the typed methods return.

Kept narrow: only the fields the SDK actually surfaces. Anything more
exotic should go through ``Client.request(...)`` and be parsed by the
caller.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class _Base(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)


class Project(_Base):
    """Lightweight project record returned by list / get / create."""

    id: UUID
    name: str
    slug: str
    description: str | None = None
    status: str = "active"
    created_at: datetime | None = None
    updated_at: datetime | None = None


class GenerationLog(_Base):
    """One row from ``platform_generation_logs``."""

    id: UUID
    project_id: UUID
    dsl_hash: str
    status: str
    duration_ms: int | None = None
    error_message: str | None = None
    artifacts_generated: list[Any] = Field(default_factory=list)
    created_at: datetime | None = None


class ValidationResult(_Base):
    """The validator's verdict over a project's DSL."""

    valid: bool
    errors: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class DSLDiff(_Base):
    """The structured diff between a stored DSL and a proposed one."""

    valid: bool
    unified_diff: str | None = None
    summary: dict[str, Any] = Field(default_factory=dict)
    errors: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class EjectBundle:
    """In-memory wrapper around the ejected zip.

    Returned by ``client.projects.eject(project_id)``. The bytes are
    accessible directly via ``.content``; ``save_to(path)`` writes the
    file with the suggested filename when the path is a directory.
    """

    __slots__ = ("content", "filename")

    def __init__(self, content: bytes, filename: str) -> None:
        self.content = content
        self.filename = filename

    def save_to(self, path: str | Path) -> Path:
        target = Path(path).expanduser()
        if target.is_dir():
            target = target / (self.filename or "qiloback-eject.zip")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(self.content)
        return target

    def __len__(self) -> int:
        return len(self.content)

    def __repr__(self) -> str:
        return f"<EjectBundle {self.filename!r} ({len(self)} bytes)>"
