"""Sync client for the QiloBack platform-api.

The class layers a small ergonomic surface (``client.projects.list()``)
on top of an httpx.Client. Anything not covered by the typed methods
is reachable through ``client.request(method, path, **kwargs)`` which
returns the raw ``httpx.Response`` (after the 4xx/5xx mapping has run).
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from types import TracebackType
from typing import Any
from uuid import UUID

import httpx

from qiloback._errors import raise_for_response
from qiloback._models import DSLDiff, EjectBundle, GenerationLog, Project, ValidationResult

_FILENAME_RE = re.compile(r'filename="?([^"]+)"?')
_DEFAULT_TIMEOUT = httpx.Timeout(30.0, connect=10.0)


class Client:
    """Sync entry point. Use as a context manager when possible.

    >>> with Client(base_url="...", token="...") as qb:
    ...     for project in qb.projects.list():
    ...         print(project.slug)
    """

    def __init__(
        self,
        *,
        base_url: str,
        token: str | None = None,
        timeout: float | httpx.Timeout = _DEFAULT_TIMEOUT,
        http_client: httpx.Client | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._token = token or ""
        self._owns_http = http_client is None
        self._http = http_client or httpx.Client(
            base_url=self._base_url,
            timeout=timeout,
        )
        self.projects = ProjectsAPI(self)
        self.audit = AuditAPI(self)
        self.components = ComponentsAPI(self)

    # ── Lifecycle ───────────────────────────────────────────────

    def close(self) -> None:
        if self._owns_http:
            self._http.close()

    def __enter__(self) -> Client:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close()

    # ── Auth ────────────────────────────────────────────────────

    def set_token(self, token: str | None) -> None:
        self._token = token or ""

    @property
    def token(self) -> str:
        return self._token

    # ── HTTP ────────────────────────────────────────────────────

    def _headers(self, extra: dict[str, str] | None = None) -> dict[str, str]:
        headers: dict[str, str] = {"Accept": "application/json"}
        if self._token:
            headers["Authorization"] = f"Bearer {self._token}"
        if extra:
            headers.update(extra)
        return headers

    def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any = None,
        headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> httpx.Response:
        """Lower-level call that bypasses the typed surface.

        Useful for endpoints not yet wrapped by a method on the SDK.
        Raises one of the SDK exception classes on a non-2xx status;
        otherwise returns the raw ``httpx.Response``.
        """
        response = self._http.request(
            method,
            path,
            params=params,
            json=json,
            headers=self._headers(headers),
            timeout=timeout if timeout is not None else self._http.timeout,
        )
        raise_for_response(response)
        return response

    # ── High-level helpers ──────────────────────────────────────

    def health(self) -> dict[str, Any]:
        """Hit ``/health`` and return the JSON payload."""
        response = self.request("GET", "/health")
        result = response.json()
        return result if isinstance(result, dict) else {}


# ── Resource façades ────────────────────────────────────────────


class _Resource:
    def __init__(self, client: Client) -> None:
        self._client = client


class ProjectsAPI(_Resource):
    """Wraps everything under ``/api/v1/projects``."""

    def list(self, include_archived: bool = False) -> Sequence[Project]:
        response = self._client.request(
            "GET",
            "/api/v1/projects",
            params={"include_archived": str(include_archived).lower()},
        )
        return [Project.model_validate(row) for row in response.json()]

    def get(self, project_id: UUID | str) -> Project:
        response = self._client.request("GET", f"/api/v1/projects/{project_id}")
        return Project.model_validate(response.json())

    def create(
        self,
        *,
        name: str,
        slug: str,
        description: str | None = None,
    ) -> Project:
        response = self._client.request(
            "POST",
            "/api/v1/projects",
            json={"name": name, "slug": slug, "description": description},
        )
        return Project.model_validate(response.json())

    def delete(self, project_id: UUID | str) -> None:
        self._client.request("DELETE", f"/api/v1/projects/{project_id}")

    # ── DSL ───────────────────────────────────────────────────

    def upload_dsl(self, project_id: UUID | str, content: str) -> dict[str, Any]:
        response = self._client.request(
            "POST",
            f"/api/v1/projects/{project_id}/dsl",
            json={"content": content},
        )
        return dict(response.json())

    def get_dsl(self, project_id: UUID | str) -> dict[str, Any]:
        response = self._client.request("GET", f"/api/v1/projects/{project_id}/dsl")
        return dict(response.json())

    def validate_dsl(self, project_id: UUID | str) -> ValidationResult:
        response = self._client.request("POST", f"/api/v1/projects/{project_id}/validate")
        return ValidationResult.model_validate(response.json())

    def diff_dsl(self, project_id: UUID | str, proposed_content: str) -> DSLDiff:
        response = self._client.request(
            "POST",
            f"/api/v1/projects/{project_id}/dsl/diff",
            json={"content": proposed_content},
        )
        return DSLDiff.model_validate(response.json())

    # ── Codegen ───────────────────────────────────────────────

    def generate(self, project_id: UUID | str) -> GenerationLog:
        response = self._client.request("POST", f"/api/v1/projects/{project_id}/generate")
        return GenerationLog.model_validate(response.json())

    def list_generations(self, project_id: UUID | str) -> Sequence[GenerationLog]:
        response = self._client.request("GET", f"/api/v1/projects/{project_id}/generations")
        return [GenerationLog.model_validate(row) for row in response.json()]

    # ── Eject (the anti-lock-in surface) ─────────────────────

    def eject(self, project_id: UUID | str) -> EjectBundle:
        """Download the portable bundle for a project.

        Returns an :class:`EjectBundle` carrying the zip bytes and the
        filename suggested by the platform — call ``.save_to(path)``
        to write it to disk.
        """
        response = self._client.request(
            "POST",
            f"/api/v1/projects/{project_id}/eject",
        )
        return EjectBundle(
            content=response.content,
            filename=_extract_filename(response.headers.get("content-disposition", "")),
        )


class ComponentsAPI(_Resource):
    """Read access to the platform's component marketplace.

    Same shape the panel and the MCP server consume — list returns
    summaries (light-weight, scannable in a table), get returns the
    full manifest. Both endpoints are unauthenticated by design;
    the marketplace is public information so anyone can browse
    before installing.
    """

    def list(self) -> Sequence[dict[str, Any]]:
        response = self._client.request("GET", "/api/v1/components")
        body = response.json()
        if isinstance(body, dict):
            return list(body.get("components", []))
        return list(body) if isinstance(body, list) else []

    def get(self, name: str) -> dict[str, Any]:
        response = self._client.request("GET", f"/api/v1/components/{name}")
        return dict(response.json())


class AuditAPI(_Resource):
    """Read access to the platform's audit log."""

    def events(
        self,
        *,
        project_id: UUID | str | None = None,
        event_type: str | None = None,
        limit: int = 50,
    ) -> Sequence[dict[str, Any]]:
        params: dict[str, Any] = {"limit": int(limit)}
        if project_id is not None:
            params["project_id"] = str(project_id)
        if event_type is not None:
            params["event_type"] = event_type
        response = self._client.request("GET", "/api/v1/audit/events", params=params)
        body = response.json()
        return list(body) if isinstance(body, list) else list(body.get("events", []))


# ── Helpers ────────────────────────────────────────────────────


def _extract_filename(content_disposition: str) -> str:
    if not content_disposition:
        return "qiloback-eject.zip"
    match = _FILENAME_RE.search(content_disposition)
    return match.group(1) if match else "qiloback-eject.zip"
