"""Error hierarchy for the SDK.

Every SDK call raises ``QiloBackError`` or a subclass; the caller can
catch the broad type and pattern-match by attribute, or catch a
specific subclass for the common flows (auth, missing, validation).
"""

from __future__ import annotations

from typing import Any


class QiloBackError(Exception):
    """Root of the SDK error hierarchy."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        payload: Any = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload


class APIError(QiloBackError):
    """The platform-api responded with a non-2xx status."""


class AuthError(APIError):
    """401/403 — bad token, expired token, missing scope."""


class NotFoundError(APIError):
    """404 — the resource does not exist (or is not visible to this caller)."""


class ValidationError(APIError):
    """422 — the request payload was rejected by the platform's
    validators (DSL parse error, missing field, type mismatch)."""


def raise_for_response(response: Any) -> None:
    """Map a 4xx/5xx response onto the right SDK exception class.

    The platform-api uses 422 for validation errors (matching the
    qiloback_shared.errors.ValidationError default), so we treat 422
    differently from 400 here.
    """
    code = response.status_code
    if code < 400:
        return

    try:
        payload = response.json()
    except Exception:
        payload = response.text

    detail: str
    if isinstance(payload, dict):
        detail = str(payload.get("detail") or payload.get("message") or payload)
    else:
        detail = str(payload)

    if code in (401, 403):
        raise AuthError(detail, status_code=code, payload=payload)
    if code == 404:
        raise NotFoundError(detail, status_code=code, payload=payload)
    if code == 422:
        raise ValidationError(detail, status_code=code, payload=payload)
    raise APIError(detail, status_code=code, payload=payload)
