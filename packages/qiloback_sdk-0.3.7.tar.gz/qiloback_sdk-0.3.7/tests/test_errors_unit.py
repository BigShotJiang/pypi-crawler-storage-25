"""Unit tests for the SDK error hierarchy + ``raise_for_response``.

The HTTP-level tests already cover the common 401/403/404/422
paths. This file pins the helper directly so unusual status codes
(409, 500, 502, etc.) surface as the right subclass, and the
``payload`` attribute lands the parsed JSON when available.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pytest
from qiloback._errors import (
    APIError,
    AuthError,
    NotFoundError,
    QiloBackError,
    ValidationError,
    raise_for_response,
)


@dataclass
class _FakeResponse:
    """Minimal stand-in for httpx.Response — just what
    ``raise_for_response`` reads."""

    status_code: int
    _payload: Any = None
    text: str = ""

    def json(self) -> Any:
        if isinstance(self._payload, Exception):
            raise self._payload
        return self._payload


# ── Hierarchy ────────────────────────────────────────────────────


def test_qiloback_error_carries_status_and_payload() -> None:
    err = QiloBackError("boom", status_code=500, payload={"detail": "boom"})
    assert err.status_code == 500
    assert err.payload == {"detail": "boom"}
    assert str(err) == "boom"


def test_auth_error_inherits_api_error_and_qiloback_error() -> None:
    err = AuthError("nope")
    assert isinstance(err, APIError)
    assert isinstance(err, QiloBackError)


def test_validation_error_inherits_api_error() -> None:
    assert issubclass(ValidationError, APIError)


def test_not_found_error_inherits_api_error() -> None:
    assert issubclass(NotFoundError, APIError)


# ── raise_for_response: success path ─────────────────────────────


@pytest.mark.parametrize("code", [200, 201, 202, 204, 301])
def test_raise_for_response_no_op_on_success(code: int) -> None:
    raise_for_response(_FakeResponse(status_code=code, _payload={"ok": True}))


# ── Status → subclass mapping ────────────────────────────────────


@pytest.mark.parametrize("code", [401, 403])
def test_raise_for_response_maps_401_and_403_to_auth_error(code: int) -> None:
    with pytest.raises(AuthError):
        raise_for_response(_FakeResponse(status_code=code, _payload={"detail": "nope"}))


def test_raise_for_response_maps_404_to_not_found_error() -> None:
    with pytest.raises(NotFoundError):
        raise_for_response(_FakeResponse(status_code=404, _payload={"detail": "missing"}))


def test_raise_for_response_maps_422_to_validation_error() -> None:
    with pytest.raises(ValidationError):
        raise_for_response(_FakeResponse(status_code=422, _payload={"detail": "bad input"}))


@pytest.mark.parametrize("code", [400, 409, 410, 429, 500, 502, 503])
def test_raise_for_response_maps_other_4xx_5xx_to_generic_api_error(code: int) -> None:
    with pytest.raises(APIError) as exc_info:
        raise_for_response(_FakeResponse(status_code=code, _payload={"detail": "x"}))
    # Sanity: must not be a more specific subclass
    assert type(exc_info.value) is APIError


# ── Payload extraction ───────────────────────────────────────────


def test_raise_for_response_pulls_detail_from_payload() -> None:
    with pytest.raises(NotFoundError) as exc_info:
        raise_for_response(_FakeResponse(status_code=404, _payload={"detail": "user not found"}))
    assert "user not found" in str(exc_info.value)


def test_raise_for_response_pulls_message_when_detail_missing() -> None:
    with pytest.raises(APIError) as exc_info:
        raise_for_response(_FakeResponse(status_code=500, _payload={"message": "server crashed"}))
    assert "server crashed" in str(exc_info.value)


def test_raise_for_response_falls_back_to_text_when_json_unparseable() -> None:
    with pytest.raises(APIError) as exc_info:
        raise_for_response(
            _FakeResponse(
                status_code=500,
                _payload=ValueError("not json"),
                text="oops the server returned plain text",
            )
        )
    assert "oops" in str(exc_info.value)


def test_raise_for_response_attaches_status_code_to_error() -> None:
    with pytest.raises(AuthError) as exc_info:
        raise_for_response(_FakeResponse(status_code=403, _payload={}))
    assert exc_info.value.status_code == 403


def test_raise_for_response_attaches_payload_to_error() -> None:
    body = {"detail": "denied", "code": "RBAC_FAIL"}
    with pytest.raises(AuthError) as exc_info:
        raise_for_response(_FakeResponse(status_code=401, _payload=body))
    assert exc_info.value.payload == body


# ── Edge: payload is a list / str / None ─────────────────────────


def test_raise_for_response_handles_list_payload() -> None:
    """Some endpoints return ``[]`` for errors. The helper should
    still raise the right subclass + stringify the list as the
    detail."""
    with pytest.raises(APIError) as exc_info:
        raise_for_response(_FakeResponse(status_code=500, _payload=["err1", "err2"]))
    assert "err" in str(exc_info.value)


def test_raise_for_response_handles_string_payload() -> None:
    with pytest.raises(NotFoundError) as exc_info:
        raise_for_response(_FakeResponse(status_code=404, _payload="just a string"))
    assert "just a string" in str(exc_info.value)


def test_raise_for_response_handles_none_payload() -> None:
    """Empty response body — the helper still raises, with a
    stringified None as detail."""
    with pytest.raises(AuthError):
        raise_for_response(_FakeResponse(status_code=401, _payload=None))
