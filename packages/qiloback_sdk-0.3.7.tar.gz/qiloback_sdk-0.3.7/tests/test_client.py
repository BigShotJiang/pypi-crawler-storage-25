"""Tests for the QiloBack Python SDK.

The SDK is exercised against an httpx ``MockTransport`` so the suite
runs without a live platform-api. Each test pins one piece of the
contract: bearer header, error mapping (auth / not found / validation
/ generic), the projects CRUD surface, the eject bundle wrapper, and
the audit events query.
"""

from __future__ import annotations

import json
from uuid import uuid4

import httpx
import pytest
from qiloback import (
    APIError,
    AuthError,
    Client,
    EjectBundle,
    NotFoundError,
    ValidationError,
)


def _client(handler) -> Client:
    transport = httpx.MockTransport(handler)
    http = httpx.Client(base_url="https://api.test", transport=transport)
    return Client(base_url="https://api.test", token="test-token", http_client=http)


def test_bearer_header_sent_on_each_request() -> None:
    seen: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request.headers.get("authorization", ""))
        return httpx.Response(200, json={"status": "ok"})

    with _client(handler) as qb:
        qb.health()
        qb.set_token("rotated")
        qb.health()

    assert seen == ["Bearer test-token", "Bearer rotated"]


def test_health_returns_payload() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "GET"
        assert request.url.path == "/health"
        return httpx.Response(200, json={"status": "ok", "version": "1.0.0"})

    with _client(handler) as qb:
        body = qb.health()
        assert body["status"] == "ok"


def test_projects_list_returns_typed_models() -> None:
    pid = str(uuid4())

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v1/projects"
        return httpx.Response(
            200,
            json=[
                {"id": pid, "name": "Alpha", "slug": "alpha"},
                {"id": str(uuid4()), "name": "Beta", "slug": "beta"},
            ],
        )

    with _client(handler) as qb:
        projects = qb.projects.list()

    assert len(projects) == 2
    assert projects[0].slug == "alpha"
    assert str(projects[0].id) == pid


def test_projects_create_posts_payload_and_returns_model() -> None:
    pid = str(uuid4())
    seen_payload: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "POST"
        assert request.url.path == "/api/v1/projects"
        nonlocal seen_payload
        seen_payload = json.loads(request.content)
        return httpx.Response(
            201,
            json={
                "id": pid,
                "name": seen_payload["name"],
                "slug": seen_payload["slug"],
                "description": seen_payload.get("description"),
            },
        )

    with _client(handler) as qb:
        project = qb.projects.create(name="Demo", slug="demo", description="Hi")

    assert seen_payload == {"name": "Demo", "slug": "demo", "description": "Hi"}
    assert project.slug == "demo"


def test_projects_eject_bundles_zip_and_filename() -> None:
    pid = uuid4()

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == f"/api/v1/projects/{pid}/eject"
        return httpx.Response(
            200,
            content=b"PK\x03\x04 fake zip content",
            headers={"content-disposition": 'attachment; filename="demo-eject.zip"'},
        )

    with _client(handler) as qb:
        bundle = qb.projects.eject(pid)

    assert isinstance(bundle, EjectBundle)
    assert bundle.filename == "demo-eject.zip"
    assert bundle.content.startswith(b"PK")
    assert len(bundle) == len(b"PK\x03\x04 fake zip content")


def test_eject_bundle_save_to_writes_file(tmp_path) -> None:
    bundle = EjectBundle(content=b"zip-bytes", filename="demo-eject.zip")
    target = tmp_path / "out"
    written = bundle.save_to(target)
    assert written == target
    assert written.read_bytes() == b"zip-bytes"


def test_eject_bundle_save_to_directory_uses_suggested_filename(tmp_path) -> None:
    bundle = EjectBundle(content=b"zip", filename="demo.zip")
    written = bundle.save_to(tmp_path)
    assert written == tmp_path / "demo.zip"
    assert written.read_bytes() == b"zip"


def test_validation_error_raises_on_422() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(422, json={"detail": "Invalid DSL — slug missing"})

    with _client(handler) as qb, pytest.raises(ValidationError) as exc_info:
        qb.projects.validate_dsl(uuid4())

    assert exc_info.value.status_code == 422
    assert "Invalid DSL" in str(exc_info.value)


def test_auth_error_raises_on_401_and_403() -> None:
    def handler_401(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"detail": "Token expired"})

    with _client(handler_401) as qb, pytest.raises(AuthError):
        qb.projects.list()


def test_not_found_raises_on_404() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, json={"detail": "no such project"})

    with _client(handler) as qb, pytest.raises(NotFoundError):
        qb.projects.get(uuid4())


def test_generic_api_error_for_500() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(500, json={"detail": "boom"})

    with _client(handler) as qb, pytest.raises(APIError) as exc_info:
        qb.projects.list()

    assert exc_info.value.status_code == 500


def test_audit_events_serialises_filters_into_query_string() -> None:
    seen_params: list[dict] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen_params.append(dict(request.url.params))
        return httpx.Response(200, json=[{"id": "1", "event_type": "project.created"}])

    with _client(handler) as qb:
        events = qb.audit.events(event_type="project.created", limit=25)

    assert seen_params[0]["event_type"] == "project.created"
    assert seen_params[0]["limit"] == "25"
    assert events == [{"id": "1", "event_type": "project.created"}]


def test_request_lower_level_returns_raw_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"answer": 42})

    with _client(handler) as qb:
        response = qb.request("GET", "/api/v1/anything")

    assert response.status_code == 200
    assert response.json() == {"answer": 42}
