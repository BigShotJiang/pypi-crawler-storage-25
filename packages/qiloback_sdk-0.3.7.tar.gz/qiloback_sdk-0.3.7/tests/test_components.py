"""Tests for the SDK's ``ComponentsAPI``.

Same MockTransport pattern as test_client.py — no live platform-api
needed. Covers the listing endpoint (both response shapes the
platform-api might return), the detail endpoint, and the standard
404 mapping.
"""

from __future__ import annotations

import httpx
import pytest
from qiloback import Client, NotFoundError


def _client(handler) -> Client:
    transport = httpx.MockTransport(handler)
    http = httpx.Client(base_url="https://api.test", transport=transport)
    return Client(base_url="https://api.test", token="test-token", http_client=http)


def test_components_list_unwraps_dict_envelope() -> None:
    """The platform-api returns ``{components: [...]}``; the SDK
    method projects that to a flat list."""
    payload = {
        "components": [
            {"name": "audit-trail", "version": "0.1.0"},
            {"name": "auth-magic-link", "version": "0.1.0"},
        ]
    }

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v1/components"
        return httpx.Response(200, json=payload)

    with _client(handler) as qb:
        result = qb.components.list()

    assert [c["name"] for c in result] == ["audit-trail", "auth-magic-link"]


def test_components_list_handles_bare_list_response() -> None:
    """Older platforms returned a bare list; the SDK still copes."""

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=[{"name": "audit-trail"}])

    with _client(handler) as qb:
        result = qb.components.list()

    assert result == [{"name": "audit-trail"}]


def test_components_list_empty_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"components": []})

    with _client(handler) as qb:
        result = qb.components.list()

    assert list(result) == []


def test_components_get_returns_full_manifest() -> None:
    manifest = {
        "component": {
            "name": "audit-trail",
            "version": "0.1.0",
            "description": "Event-sourced audit log.",
        },
        "tables": [{"name": "events"}],
        "endpoints": [{"method": "GET", "path": "/events"}],
    }

    captured: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        return httpx.Response(200, json=manifest)

    with _client(handler) as qb:
        result = qb.components.get("audit-trail")

    assert captured["path"] == "/api/v1/components/audit-trail"
    assert result["component"]["name"] == "audit-trail"
    assert "tables" in result


def test_components_get_404_raises_not_found() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, json={"detail": "no such component"})

    with _client(handler) as qb, pytest.raises(NotFoundError):
        qb.components.get("nonexistent")


def test_components_list_uses_bearer_header() -> None:
    seen_auth: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen_auth.append(request.headers.get("authorization", ""))
        return httpx.Response(200, json={"components": []})

    with _client(handler) as qb:
        qb.components.list()

    assert seen_auth == ["Bearer test-token"]
