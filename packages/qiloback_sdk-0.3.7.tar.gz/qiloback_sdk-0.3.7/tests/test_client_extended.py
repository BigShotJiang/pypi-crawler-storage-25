"""Extended SDK tests — closes the gap from 87% to 100% coverage.

The base file ``test_client.py`` covers the common surface (auth header,
list/create/eject, error mapping, audit). This module pins:

- close() lifecycle when the SDK owns the underlying httpx.Client
- token property accessor
- _headers() merging extra headers
- get / delete / upload_dsl / get_dsl / validate_dsl / diff_dsl /
  generate / list_generations end-to-end shapes
- audit events with project_id filter
- _extract_filename helpers (default, double-quoted, unquoted)
- Components API list (both array and {components: [...]} payloads)
- Components API get
"""

from __future__ import annotations

import json
from uuid import uuid4

import httpx
from qiloback import Client


def _client(handler) -> Client:
    transport = httpx.MockTransport(handler)
    http = httpx.Client(base_url="https://api.test", transport=transport)
    return Client(base_url="https://api.test", token="t", http_client=http)


# ── Lifecycle ───────────────────────────────────────────────


def test_owned_client_is_closed_on_exit() -> None:
    """When no http_client is provided, the SDK builds its own and is
    responsible for closing it. Cover the close() branch by letting the
    Client manage its own httpx.Client."""
    qb = Client(base_url="https://api.test", token="t")
    assert qb._owns_http is True
    qb.close()
    # Calling close() twice must not raise.
    qb.close()


def test_passed_in_http_client_is_not_closed_by_close() -> None:
    """When the caller passes an http_client, the SDK must not close it
    — the caller owns the lifetime."""
    transport = httpx.MockTransport(lambda r: httpx.Response(200, json={"status": "ok"}))
    http = httpx.Client(base_url="https://api.test", transport=transport)
    qb = Client(base_url="https://api.test", http_client=http)
    qb.close()
    # The httpx.Client should still be usable.
    assert not http.is_closed


# ── Auth ────────────────────────────────────────────────────


def test_token_property_returns_current_value() -> None:
    qb = Client(base_url="https://api.test", token="abc")
    assert qb.token == "abc"
    qb.set_token("rotated")
    assert qb.token == "rotated"
    qb.set_token(None)
    assert qb.token == ""


def test_headers_skips_authorization_when_no_token_set() -> None:
    """Cover the branch where ``_token`` is empty — the Authorization
    header must not appear at all (sending ``Bearer`` alone would be
    a 400 from the platform-api)."""
    seen: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen.update(dict(request.headers))
        return httpx.Response(200, json={"ok": True})

    transport = httpx.MockTransport(handler)
    http = httpx.Client(base_url="https://api.test", transport=transport)
    qb = Client(base_url="https://api.test", http_client=http)  # no token
    qb.health()
    qb.close()

    assert "authorization" not in seen


def test_request_merges_extra_headers() -> None:
    """Cover the ``extra`` branch of ``_headers``."""
    seen: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen.update(dict(request.headers))
        return httpx.Response(200, json={"ok": True})

    with _client(handler) as qb:
        qb.request("GET", "/x", headers={"x-trace-id": "abc-123"})

    assert seen.get("x-trace-id") == "abc-123"
    # Auth header is still attached.
    assert seen.get("authorization") == "Bearer t"


# ── Projects CRUD (uncovered branches) ────────────────────────


def test_projects_get_returns_typed_model() -> None:
    pid = uuid4()

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == f"/api/v1/projects/{pid}"
        return httpx.Response(200, json={"id": str(pid), "name": "X", "slug": "x"})

    with _client(handler) as qb:
        project = qb.projects.get(pid)

    assert project.slug == "x"


def test_projects_delete_returns_none() -> None:
    pid = uuid4()
    seen_method: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen_method.append(request.method)
        assert request.url.path == f"/api/v1/projects/{pid}"
        return httpx.Response(204)

    with _client(handler) as qb:
        result = qb.projects.delete(pid)

    assert result is None
    assert seen_method == ["DELETE"]


# ── DSL surface ──────────────────────────────────────────────


def test_projects_upload_dsl_posts_content() -> None:
    pid = uuid4()
    captured: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(request.content)
        return httpx.Response(200, json={"version": 1})

    with _client(handler) as qb:
        body = qb.projects.upload_dsl(pid, "dsl_version: 1.0\n")

    assert captured["body"] == {"content": "dsl_version: 1.0\n"}
    assert body == {"version": 1}


def test_projects_get_dsl_returns_dict() -> None:
    pid = uuid4()

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == f"/api/v1/projects/{pid}/dsl"
        return httpx.Response(200, json={"content": "dsl_version: 1.0", "hash": "h1"})

    with _client(handler) as qb:
        out = qb.projects.get_dsl(pid)

    assert out["hash"] == "h1"


def test_projects_validate_dsl_returns_validation_result() -> None:
    pid = uuid4()

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={"valid": True, "errors": [], "warnings": []},
        )

    with _client(handler) as qb:
        result = qb.projects.validate_dsl(pid)

    assert result.valid is True
    assert result.errors == []


def test_projects_diff_dsl_returns_dsl_diff() -> None:
    pid = uuid4()
    captured: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(request.content)
        return httpx.Response(
            200,
            json={
                "unified_diff": "+ entity Foo",
                "summary": {"entities_added": ["Foo"]},
                "valid": True,
                "errors": [],
            },
        )

    with _client(handler) as qb:
        diff = qb.projects.diff_dsl(pid, "dsl_version: 1.0\n")

    assert captured["body"] == {"content": "dsl_version: 1.0\n"}
    assert diff.unified_diff == "+ entity Foo"
    assert diff.summary == {"entities_added": ["Foo"]}


# ── Codegen ──────────────────────────────────────────────────


def test_projects_generate_returns_generation_log() -> None:
    pid = uuid4()
    log_id = uuid4()

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "id": str(log_id),
                "project_id": str(pid),
                "dsl_hash": "abc123",
                "status": "running",
                "duration_ms": None,
            },
        )

    with _client(handler) as qb:
        log = qb.projects.generate(pid)

    assert log.status == "running"
    assert str(log.id) == str(log_id)


def test_projects_list_generations_returns_typed_models() -> None:
    pid = uuid4()

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json=[
                {
                    "id": str(uuid4()),
                    "project_id": str(pid),
                    "dsl_hash": "h1",
                    "status": "success",
                    "duration_ms": 1234,
                },
                {
                    "id": str(uuid4()),
                    "project_id": str(pid),
                    "dsl_hash": "h2",
                    "status": "failed",
                    "duration_ms": 50,
                },
            ],
        )

    with _client(handler) as qb:
        logs = qb.projects.list_generations(pid)

    assert len(logs) == 2
    assert {log.status for log in logs} == {"success", "failed"}


# ── Components ───────────────────────────────────────────────


def test_components_list_handles_array_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json=[{"name": "rate-limit", "version": "1.0"}],
        )

    with _client(handler) as qb:
        rows = qb.components.list()

    assert rows[0]["name"] == "rate-limit"


def test_components_list_handles_object_response_with_components_key() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={"components": [{"name": "billing-stripe"}]},
        )

    with _client(handler) as qb:
        rows = qb.components.list()

    assert rows[0]["name"] == "billing-stripe"


def test_components_list_returns_empty_for_unexpected_shape() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"unknown": "shape"})

    with _client(handler) as qb:
        rows = qb.components.list()

    assert rows == []


def test_components_get_returns_full_manifest() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "component": {"name": "rate-limit", "version": "1.0"},
                "tables": [{"name": "rate_limit_buckets"}],
                "endpoints": [{"path": "/api/v1/rate-limit"}],
            },
        )

    with _client(handler) as qb:
        manifest = qb.components.get("rate-limit")

    assert manifest["component"]["name"] == "rate-limit"
    assert manifest["tables"][0]["name"] == "rate_limit_buckets"


# ── Audit ───────────────────────────────────────────────────


def test_audit_events_with_project_id_filter_only() -> None:
    pid = uuid4()
    seen: list[dict] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(dict(request.url.params))
        return httpx.Response(200, json=[])

    with _client(handler) as qb:
        qb.audit.events(project_id=pid, limit=10)

    params = seen[0]
    assert params["project_id"] == str(pid)
    assert params["limit"] == "10"
    assert "event_type" not in params


def test_audit_events_handles_object_with_events_key() -> None:
    """When the platform-api wraps the list in an object with an
    ``events`` key, the SDK unwraps it. Covers the fallback branch
    in AuditAPI.events."""

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"events": [{"id": "1"}], "total": 1})

    with _client(handler) as qb:
        out = qb.audit.events()

    assert out == [{"id": "1"}]


# ── _extract_filename helper ─────────────────────────────────


def test_extract_filename_default_when_no_header() -> None:
    from qiloback._client import _extract_filename

    assert _extract_filename("") == "qiloback-eject.zip"


def test_extract_filename_default_when_pattern_mismatch() -> None:
    from qiloback._client import _extract_filename

    # Header without filename= directive falls back to the default.
    assert _extract_filename("attachment; type=zip") == "qiloback-eject.zip"


def test_extract_filename_strips_quotes() -> None:
    from qiloback._client import _extract_filename

    assert _extract_filename('attachment; filename="my-app.zip"') == "my-app.zip"


def test_extract_filename_handles_unquoted() -> None:
    from qiloback._client import _extract_filename

    assert _extract_filename("attachment; filename=my-app.zip") == "my-app.zip"


# ── _errors edge cases ───────────────────────────────────────


def test_raise_for_response_handles_non_json_body() -> None:
    """Some 5xx responses ship plain text. The SDK falls back to
    response.text and still surfaces a typed APIError."""
    import pytest
    from qiloback import APIError
    from qiloback._errors import raise_for_response

    transport = httpx.MockTransport(
        lambda r: httpx.Response(500, content=b"<html>oops</html>", headers={"content-type": "text/html"}),
    )
    http = httpx.Client(base_url="https://api.test", transport=transport)
    response = http.get("/x")
    with pytest.raises(APIError) as exc_info:
        raise_for_response(response)
    # The exception should still carry the HTTP status.
    assert exc_info.value.status_code == 500


def test_raise_for_response_with_non_dict_json_payload() -> None:
    """A JSON array body still produces a typed error with the array
    stringified into the detail."""
    import pytest
    from qiloback import APIError
    from qiloback._errors import raise_for_response

    transport = httpx.MockTransport(
        lambda r: httpx.Response(500, json=["a", "b"]),
    )
    http = httpx.Client(base_url="https://api.test", transport=transport)
    response = http.get("/x")
    with pytest.raises(APIError) as exc_info:
        raise_for_response(response)
    assert "a" in str(exc_info.value)


# ── EjectBundle helpers ──────────────────────────────────────


def test_eject_bundle_repr_carries_filename_and_size() -> None:
    from qiloback import EjectBundle

    bundle = EjectBundle(content=b"hello", filename="demo.zip")
    text = repr(bundle)
    assert "demo.zip" in text
    assert "5" in text  # bytes
