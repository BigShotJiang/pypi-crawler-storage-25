# qiloback-sdk

Official Python SDK for the QiloBack platform-api.

## Install

```bash
pip install qiloback-sdk
```

## Quick start

```python
from qiloback import Client

with Client(base_url="https://api.qiloback.dev", token="...") as qb:
    project = qb.projects.create(name="My CRM", slug="my_crm")
    qb.projects.upload_dsl(project.id, dsl_yaml)
    log = qb.projects.generate(project.id)
    print(log.status)

    # Eject a portable bundle and write it to disk
    bundle = qb.projects.eject(project.id)
    bundle.save_to("./my-crm.zip")
```

The SDK is intentionally thin: it wraps the most-used surface
(projects, DSL, generations, eject, audit, health) with type-safe
methods, and falls back to a raw `client.request(...)` for anything
not yet covered. The full 193-endpoint surface is auto-generated
from the OpenAPI snapshot in v0.2.

## Auth

```python
qb = Client(base_url="...", token="bearer-token")
# or
qb = Client(base_url="...")
qb.set_token("bearer-token")
```

The SDK is sync today; an async variant (`AsyncClient`) ships in v0.2
with the same surface.

## License

Source-available under FSL-1.1-ALv2. Auto-conversion to Apache 2.0 two
years after each release. See the QiloBack LICENSE-FAQ for details.
