"""Empty package nemo_platform_plugin."""

__version__ = "0.0.0a0"
