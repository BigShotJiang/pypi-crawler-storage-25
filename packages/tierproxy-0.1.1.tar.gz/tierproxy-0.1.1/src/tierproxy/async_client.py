from __future__ import annotations

import os
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

import httpx

from tierproxy._internal.http import Transport
from tierproxy.errors import AuthenticationError
from tierproxy.resources.health import AsyncHealthResource
from tierproxy.resources.me import AsyncMeResource
from tierproxy.resources.usage import AsyncUsageResource
from tierproxy.retry import RetryPolicy

if TYPE_CHECKING:
    from tierproxy.proxy.selector import AsyncSmartSelector


class AsyncTierProxy:
    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = "https://gw.tierproxy.com:8444",
        timeout: float = 30.0,
        http_timeout: float = 30.0,
        max_retries: int = 3,
        retry_policy: RetryPolicy | None = None,
        http_client: httpx.AsyncClient | None = None,
        user_agent_suffix: str | None = None,
        routing: str | None = None,
        monthly_budget_usd: float | None = None,
        on_usage_pct: int | None = None,
        on_usage_callback: Callable[[float], None] | None = None,
    ) -> None:
        key = api_key or os.environ.get("TIERPROXY_API_KEY")
        if not key:
            raise AuthenticationError("No api_key passed and TIERPROXY_API_KEY env var not set")
        retry = retry_policy or RetryPolicy(max_retries=max_retries)
        self._transport = Transport(
            api_key=key,
            base_url=base_url,
            timeout=timeout,
            retry=retry,
            ua_suffix=user_agent_suffix,
            http_client=http_client,
            is_async=True,
        )
        self._me: AsyncMeResource | None = None
        self._usage: AsyncUsageResource | None = None
        self._health: AsyncHealthResource | None = None

        self._http_timeout = http_timeout
        self._routing = routing
        self._monthly_budget_usd = monthly_budget_usd
        self._on_usage_pct = on_usage_pct
        self._on_usage_callback = on_usage_callback
        self._selector: AsyncSmartSelector | None = None
        self._spent_usd_mtd: float = 0.0
        self._budget_cache_ts: float = 0.0
        self._usage_callback_fired: bool = False
        if routing:
            from tierproxy.proxy.selector import AsyncSmartSelector

            self._selector = AsyncSmartSelector(self, strategy=routing)  # type: ignore[arg-type]

    @property
    def me(self) -> AsyncMeResource:
        if self._me is None:
            self._me = AsyncMeResource(self)
        return self._me

    @property
    def usage(self) -> AsyncUsageResource:
        if self._usage is None:
            self._usage = AsyncUsageResource(self)
        return self._usage

    @property
    def health(self) -> AsyncHealthResource:
        if self._health is None:
            self._health = AsyncHealthResource(self)
        return self._health

    async def close(self) -> None:
        client = self._transport._client
        if isinstance(client, httpx.AsyncClient):
            await client.aclose()

    async def __aenter__(self) -> AsyncTierProxy:
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    # -------- Level 1-2: proxy-through helpers --------

    async def request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        from tierproxy._targeting import build_proxy, split_kwargs

        targeting, passthrough = split_kwargs(kwargs)
        host = httpx.URL(self._transport.base_url).host
        proxy = build_proxy(self._transport.api_key, host, 443, targeting)

        if self._selector is not None and not proxy.upstream_hint:
            chosen = await self._selector.pick()
            proxy.upstream_hint = chosen.upstream_id

        headers = passthrough.pop("headers", None) or {}
        headers = {**headers, **proxy.headers()}

        if self._monthly_budget_usd is not None:
            await self._guard_budget_async()

        async with httpx.AsyncClient(proxy=proxy.http_url(), timeout=self._http_timeout) as h:
            resp = await h.request(method, url, headers=headers, **passthrough)

        if self._on_usage_callback is not None and self._on_usage_pct is not None:
            await self._maybe_fire_usage_callback_async()

        return resp

    async def get(self, url: str, **kwargs: Any) -> httpx.Response:
        return await self.request("GET", url, **kwargs)

    async def post(self, url: str, **kwargs: Any) -> httpx.Response:
        return await self.request("POST", url, **kwargs)

    def session(self, **targeting_kwargs: Any) -> httpx.AsyncClient:
        from tierproxy._targeting import build_proxy

        host = httpx.URL(self._transport.base_url).host
        proxy = build_proxy(self._transport.api_key, host, 443, targeting_kwargs)
        return httpx.AsyncClient(
            proxy=proxy.http_url(),
            headers=proxy.headers(),
            timeout=self._http_timeout,
        )

    def target(self, **kwargs: Any) -> AsyncTargetedRequest:
        return AsyncTargetedRequest(self, kwargs)

    # -------- Level 3: cost guard + usage callback --------

    async def _guard_budget_async(self) -> None:
        import time

        from tierproxy._guard import check_budget

        if time.time() - self._budget_cache_ts > 60:
            usage = await self.usage.get()
            self._spent_usd_mtd = usage.total_cost_usd
            self._budget_cache_ts = time.time()
        avg_cost = 4.0
        estimated = avg_cost * (1024 * 1024) / (1024**3)
        assert self._monthly_budget_usd is not None
        check_budget(estimated, self._spent_usd_mtd, self._monthly_budget_usd)

    async def _maybe_fire_usage_callback_async(self) -> None:
        if self._on_usage_callback is None or self._on_usage_pct is None:
            return
        if self._usage_callback_fired:
            return
        try:
            me = await self.me.get()
        except Exception:  # noqa: BLE001
            return
        pct = (me.used_bytes_month / max(1, me.quota_bytes_month)) * 100
        if pct >= self._on_usage_pct:
            self._usage_callback_fired = True
            try:
                self._on_usage_callback(pct)
            except Exception:  # noqa: BLE001
                import logging

                logging.getLogger("tierproxy").exception("on_usage_callback raised")


class AsyncTargetedRequest:
    def __init__(self, client: AsyncTierProxy, targeting: dict[str, Any]) -> None:
        self._client = client
        self._targeting = targeting

    async def get(self, url: str, **kw: Any) -> httpx.Response:
        return await self._client.get(url, **{**self._targeting, **kw})

    async def post(self, url: str, **kw: Any) -> httpx.Response:
        return await self._client.post(url, **{**self._targeting, **kw})

    async def request(self, method: str, url: str, **kw: Any) -> httpx.Response:
        return await self._client.request(method, url, **{**self._targeting, **kw})
