"""Adapters for popular HTTP clients. Hide ProxyURL composition behind one call."""

from __future__ import annotations

from dataclasses import replace
from typing import Any

from tierproxy.proxy.url_builder import ProxyURL


def requests_kwargs(proxy: ProxyURL) -> dict[str, Any]:
    """Returns kwargs to splat into requests.request(): proxies + headers."""
    url = proxy.http_url()
    return {"proxies": {"http": url, "https": url}, "headers": proxy.headers()}


def httpx_kwargs(proxy: ProxyURL) -> dict[str, Any]:
    """Returns kwargs for httpx.Client/AsyncClient or httpx.get."""
    return {"proxy": proxy.http_url(), "headers": proxy.headers()}


def aiohttp_kwargs(proxy: ProxyURL) -> dict[str, Any]:
    """For aiohttp.ClientSession.request(..., proxy=..., proxy_headers=...)."""
    return {"proxy": proxy.http_url(), "proxy_headers": proxy.headers()}


def playwright_proxy_config(proxy: ProxyURL) -> dict[str, str]:
    """For browser.launch(proxy=...).

    Forces username_encoding mode (browsers ignore headers on CONNECT).
    Caller does not need to set mode='username_encoding' manually.
    """
    enc = replace(proxy, mode="username_encoding")
    return {
        "server": f"http://{proxy.host}:{proxy.port_https}",
        "username": enc.encoded_username(),
        "password": proxy.password or "x",
    }
