from __future__ import annotations

import os
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

import httpx

from tierproxy._internal.http import Transport
from tierproxy.errors import AuthenticationError
from tierproxy.resources.health import HealthResource
from tierproxy.resources.me import MeResource
from tierproxy.resources.usage import UsageResource
from tierproxy.retry import RetryPolicy

if TYPE_CHECKING:
    from tierproxy.proxy.selector import SmartSelector


class TierProxy:
    """Sync client for the tierproxy public REST API."""

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = "https://gw.tierproxy.com:8444",
        timeout: float = 30.0,
        http_timeout: float = 30.0,
        max_retries: int = 3,
        retry_policy: RetryPolicy | None = None,
        http_client: httpx.Client | None = None,
        user_agent_suffix: str | None = None,
        routing: str | None = None,
        monthly_budget_usd: float | None = None,
        on_usage_pct: int | None = None,
        on_usage_callback: Callable[[float], None] | None = None,
    ) -> None:
        key = api_key or os.environ.get("TIERPROXY_API_KEY")
        if not key:
            raise AuthenticationError("No api_key passed and TIERPROXY_API_KEY env var not set")
        retry = retry_policy or RetryPolicy(max_retries=max_retries)
        self._transport = Transport(
            api_key=key,
            base_url=base_url,
            timeout=timeout,
            retry=retry,
            ua_suffix=user_agent_suffix,
            http_client=http_client,
            is_async=False,
        )
        self._me: MeResource | None = None
        self._usage: UsageResource | None = None
        self._health: HealthResource | None = None

        self._http_timeout = http_timeout
        self._routing = routing
        self._monthly_budget_usd = monthly_budget_usd
        self._on_usage_pct = on_usage_pct
        self._on_usage_callback = on_usage_callback
        self._selector: SmartSelector | None = None
        self._spent_usd_mtd: float = 0.0
        self._budget_cache_ts: float = 0.0
        self._usage_callback_fired: bool = False
        if routing:
            from tierproxy.proxy.selector import SmartSelector

            self._selector = SmartSelector(self, strategy=routing)  # type: ignore[arg-type]

    @property
    def me(self) -> MeResource:
        if self._me is None:
            self._me = MeResource(self)
        return self._me

    @property
    def usage(self) -> UsageResource:
        if self._usage is None:
            self._usage = UsageResource(self)
        return self._usage

    @property
    def health(self) -> HealthResource:
        if self._health is None:
            self._health = HealthResource(self)
        return self._health

    def close(self) -> None:
        client = self._transport._client
        if isinstance(client, httpx.Client):
            client.close()

    def __enter__(self) -> TierProxy:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    # -------- Level 1-2: proxy-through helpers --------

    def request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        """Make an HTTP request *through* the tierproxy gateway.

        Targeting kwargs (country, session_id, ...) are split out; everything else
        forwards to httpx (timeout, json, data, headers, params, ...).
        """
        from tierproxy._targeting import build_proxy, split_kwargs

        targeting, passthrough = split_kwargs(kwargs)
        host = httpx.URL(self._transport.base_url).host
        proxy = build_proxy(self._transport.api_key, host, 443, targeting)

        if self._selector is not None and not proxy.upstream_hint:
            chosen = self._selector.pick()
            proxy.upstream_hint = chosen.upstream_id

        headers = passthrough.pop("headers", None) or {}
        headers = {**headers, **proxy.headers()}

        if self._monthly_budget_usd is not None:
            self._guard_budget()

        with httpx.Client(proxy=proxy.http_url(), timeout=self._http_timeout) as h:
            resp = h.request(method, url, headers=headers, **passthrough)

        if self._on_usage_callback is not None and self._on_usage_pct is not None:
            self._maybe_fire_usage_callback()

        return resp

    def get(self, url: str, **kwargs: Any) -> httpx.Response:
        return self.request("GET", url, **kwargs)

    def post(self, url: str, **kwargs: Any) -> httpx.Response:
        return self.request("POST", url, **kwargs)

    def session(self, **targeting_kwargs: Any) -> httpx.Client:
        """Return an httpx.Client preconfigured with targeting baked in.

        Useful when the caller wants to make many requests with the same
        targeting (e.g. one scraper job) without rebuilding the proxy every call.
        """
        from tierproxy._targeting import build_proxy

        host = httpx.URL(self._transport.base_url).host
        proxy = build_proxy(self._transport.api_key, host, 443, targeting_kwargs)
        return httpx.Client(
            proxy=proxy.http_url(),
            headers=proxy.headers(),
            timeout=self._http_timeout,
        )

    def target(self, **kwargs: Any) -> TargetedRequest:
        """Builder pattern: g.target(country='US').get('https://x.com')."""
        return TargetedRequest(self, kwargs)

    # -------- Level 3: cost guard + usage callback --------

    def _guard_budget(self) -> None:
        """Fetches latest /v1/usage/me cost and refuses request if over budget.

        Cached for 60s. Caller can clear via ``client._budget_cache_ts = 0``.
        """
        import time

        from tierproxy._guard import check_budget

        if time.time() - self._budget_cache_ts > 60:
            usage = self.usage.get()
            self._spent_usd_mtd = usage.total_cost_usd
            self._budget_cache_ts = time.time()
        avg_cost = 4.0
        estimated = avg_cost * (1024 * 1024) / (1024**3)
        assert self._monthly_budget_usd is not None
        check_budget(estimated, self._spent_usd_mtd, self._monthly_budget_usd)

    def _maybe_fire_usage_callback(self) -> None:
        """If on_usage_pct configured and threshold crossed, fire callback once."""
        if self._on_usage_callback is None or self._on_usage_pct is None:
            return
        if self._usage_callback_fired:
            return
        try:
            me = self.me.get()
        except Exception:  # noqa: BLE001
            return
        pct = (me.used_bytes_month / max(1, me.quota_bytes_month)) * 100
        if pct >= self._on_usage_pct:
            self._usage_callback_fired = True
            try:
                self._on_usage_callback(pct)
            except Exception:  # noqa: BLE001
                import logging

                logging.getLogger("tierproxy").exception("on_usage_callback raised")


class TargetedRequest:
    """One-shot helper that captures targeting kwargs and forwards .get/.post/.request."""

    def __init__(self, client: TierProxy, targeting: dict[str, Any]) -> None:
        self._client = client
        self._targeting = targeting

    def get(self, url: str, **kw: Any) -> httpx.Response:
        return self._client.get(url, **{**self._targeting, **kw})

    def post(self, url: str, **kw: Any) -> httpx.Response:
        return self._client.post(url, **{**self._targeting, **kw})

    def request(self, method: str, url: str, **kw: Any) -> httpx.Response:
        return self._client.request(method, url, **{**self._targeting, **kw})
