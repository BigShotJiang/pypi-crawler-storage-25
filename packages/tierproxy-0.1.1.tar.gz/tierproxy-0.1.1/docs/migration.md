# Migrating to tierproxy

## From Smartproxy

```diff
# Before: Smartproxy URL with modifier suffix
- proxy = "http://customer-USER-cc-US:PASS@gate.smartproxy.com:7000"
- requests.get(target, proxies={"http": proxy, "https": proxy})

# After: tierproxy
+ from tierproxy import ProxyURL
+ proxy = ProxyURL(api_key="tp_live_...", country="US", mode="username_encoding")
+ requests.get(target, proxies={"http": proxy.http_url(), "https": proxy.http_url()})
```

The username-encoding mode produces a Smartproxy-compatible URL shape, so most code only needs the host + auth string change.

## From Bright Data

Bright Data uses `username:password@brd.superproxy.io:22225` style. Swap to:

```python
from tierproxy import ProxyURL
proxy = ProxyURL(api_key="tp_live_...", host="gw.tierproxy.com", port_https=443)
```

Bright Data session zones become tierproxy `session_id`:

```python
proxy = ProxyURL(api_key=..., session_id="zone-static-1", session_duration_minutes=30)
```

## From plain httpx / requests

You don't migrate — you wrap. Keep your existing HTTP stack; just point it at tierproxy:

```python
import httpx
from tierproxy import TierProxy, ProxyURL

g = TierProxy()
proxy = ProxyURL(api_key=g._transport.api_key, country="US")
with httpx.Client(proxy=proxy.http_url(), headers=proxy.headers()) as h:
    r = h.get("https://example.com")
```

Or use the layered API:

```python
import tierproxy
r = tierproxy.get("https://example.com", country="US")
```
