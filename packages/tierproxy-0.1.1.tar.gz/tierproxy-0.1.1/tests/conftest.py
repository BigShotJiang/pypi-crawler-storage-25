import pytest

from tierproxy import TierProxy


@pytest.fixture
def client() -> TierProxy:
    return TierProxy(api_key="tp_test_key", base_url="https://test.local")
