"""GPT-Researcher rotating geo on each query to get region-diverse sources.

Showcases tierproxy's killer feature for AI research: country-targeted IPs
mean the researcher sees the same news story from US, UK, and JP perspectives.

Install: pip install gpt-researcher tierproxy
"""

import asyncio
import os

from gpt_researcher import GPTResearcher
from tierproxy import TierProxy, ProxyURL


async def research_from(country: str, query: str) -> str:
    proxy = ProxyURL(
        api_key=os.environ["TIERPROXY_API_KEY"],
        country=country,
        session_id=f"gptr-{country}",
        session_duration_minutes=20,
    )
    os.environ["HTTP_PROXY"] = proxy.http_url()
    os.environ["HTTPS_PROXY"] = proxy.http_url()

    researcher = GPTResearcher(query=query, report_type="research_report")
    await researcher.conduct_research()
    return await researcher.write_report()


async def main() -> None:
    query = "How do EU and US governments differ on AI regulation as of 2026?"

    # Run from 3 perspectives in parallel
    us, gb, jp = await asyncio.gather(
        research_from("US", query),
        research_from("GB", query),
        research_from("JP", query),
    )
    print("=== US perspective ===\n", us[:1000])
    print("=== UK perspective ===\n", gb[:1000])
    print("=== JP perspective ===\n", jp[:1000])

    client = TierProxy()
    print("\nTotal cost:", client.usage.get().total_cost_usd, "USD")


if __name__ == "__main__":
    asyncio.run(main())
