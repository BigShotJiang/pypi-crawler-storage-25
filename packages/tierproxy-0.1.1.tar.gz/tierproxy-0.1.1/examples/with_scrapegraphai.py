"""ScrapeGraphAI + tierproxy: describe what you want in English, framework
extracts it; tierproxy handles the geo + IP rotation under the hood.

Install: pip install scrapegraphai tierproxy
"""

import os

from tierproxy import TierProxy, ProxyURL
from scrapegraphai.graphs import SmartScraperGraph

client = TierProxy()
proxy = ProxyURL(
    api_key=client._transport.api_key,
    country="US",
    session_id="scrapegraph-1",
)

graph_config = {
    "llm": {
        "model": "openai/gpt-4o-mini",
        "api_key": os.environ.get("OPENAI_API_KEY", "sk-..."),
    },
    "loader_kwargs": {
        "proxy": proxy.http_url(),
        "headers": proxy.headers(),
    },
    "verbose": True,
}

scraper = SmartScraperGraph(
    prompt="Extract every job title + location + posted-date from the page.",
    source="https://news.ycombinator.com/jobs",
    config=graph_config,
)
result = scraper.run()
print(result)
