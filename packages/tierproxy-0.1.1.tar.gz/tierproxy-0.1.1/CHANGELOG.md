# Changelog
## [0.1.1] — MCP Registry submission
- Add `mcp-name` marker in README for PyPI ownership verification
- Add `server.json` describing MCP server tools + PyPI package
- No code changes

## [0.1.0] — Initial release
- Management client (sync + async): `client.me.get()`, `client.usage.get()`, `client.usage.stream()`, `client.health.upstreams()`
- `ProxyURL` builder (header mode + username-encoding mode)
- Client-side cost-aware smart selector
- LangChain, LlamaIndex, Crawl4AI, Playwright examples
