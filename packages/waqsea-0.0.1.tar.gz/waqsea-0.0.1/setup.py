from setuptools import setup, find_packages

setup(
    name="waqsea", 
    version="0.0.1",
    author="waqsea",
    author_email="contact@waqsea.com",
    description="This name is reserved for an upcoming Python project currently under development.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 1 - Planning", 
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)