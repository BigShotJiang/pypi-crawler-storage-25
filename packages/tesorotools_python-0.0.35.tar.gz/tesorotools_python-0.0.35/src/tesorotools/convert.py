# this file may migrate to the utils package

from pathlib import Path
from typing import Any

import pandas as pd

from tesorotools.artists.barh_plot import plot_barh_charts_from_flash
from tesorotools.artists.line_plot import plot_line_charts
from tesorotools.artists.table import generate_tables_from_flash
from tesorotools.artists.type_curve import plot_type_curves
from tesorotools.dependencies.resolution import (
    compute_derivate_series,
    concat_derivate_series,
    resolve_series,
)
from tesorotools.offsets.offsets import trim
from tesorotools.utils.config import read_config


def index_replace(old: str, new: str, index: pd.MultiIndex) -> pd.MultiIndex:
    return pd.MultiIndex.from_tuples(
        [
            tuple(
                x.replace(old, new) if isinstance(x, str) else x
                for x in tuple_index
            )
            for tuple_index in index
        ]
    )


def cheap_convert(old_file: Path) -> pd.DataFrame:
    old: pd.DataFrame = pd.read_feather(old_file)

    trimmed: pd.DataFrame = old.loc[
        (slice(None), "no", "absolute", "value"), :
    ].copy()

    old = old.loc[
        (
            slice(None),
            ["day", "mtd", "week", "year", "tariff_crisis"],
            slice(None),
            slice(None),
        ),
        :,
    ]
    old.index = index_replace("day", "bday", old.index)  # type: ignore[arg-type]
    old.index = index_replace("week", "ftd", old.index)  # type: ignore[arg-type]
    old.index = index_replace("year", "ytd", old.index)  # type: ignore[arg-type]
    old.index = index_replace("roll_var", "roll_std", old.index)  # type: ignore[arg-type]
    old.index = index_replace(  # type: ignore[arg-type]
        "tariff_crisis",
        "2025-04-02",
        old.index,  # type: ignore[arg-type]
    )

    trimmed.index = index_replace("absolute", "no", trimmed.index)  # type: ignore[arg-type]

    new: pd.DataFrame = pd.concat([old, trimmed])
    return new


if __name__ == "__main__":
    preprocess = True
    barh_config_dicts: Any = read_config(Path("examples") / "barh_plots.yaml")
    line_config_dicts: Any = read_config(Path("examples") / "line_plots.yaml")
    type_config_dicts: Any = read_config(Path("examples") / "type_curves.yaml")
    table_config_dicts: Any = read_config(Path("examples") / "tables.yaml")

    full_df: pd.DataFrame
    if preprocess:
        old_file: Path = Path("debug") / "flash.feather"
        dependencies_cfg: Any = read_config(
            Path("examples") / "dependencies.yaml"
        )
        flash: pd.DataFrame = cheap_convert(old_file)
        resolved_dict = resolve_series(
            [
                barh_config_dicts,
                line_config_dicts,
                type_config_dicts,
                table_config_dicts,
            ],
            dependencies_cfg,
        )
        independent_full_df: pd.DataFrame = flash.loc[
            :, list(resolved_dict["independent"])
        ]
        independent_trimmed_df: pd.DataFrame = trim(independent_full_df)  # type: ignore[assignment]
        dependent_trimmed_df: pd.DataFrame = compute_derivate_series(
            resolved_dict["rules"],  # type: ignore[arg-type]
            independent_trimmed_df,
        )
        offsets_config: Any = read_config(Path("examples") / "offsets.yaml")
        full_df = concat_derivate_series(
            independent_full_df,
            dependent_trimmed_df,
            offsets_config,
        )
        full_df.to_feather("derivates.feather")

    full_df = pd.read_feather("derivates.feather")
    trimmed_df: pd.DataFrame = trim(full_df)  # type: ignore[assignment]
    plot_barh_charts_from_flash(Path("."), full_df, barh_config_dicts)
    plot_line_charts(Path("."), trimmed_df, line_config_dicts)
    plot_type_curves(Path("."), trimmed_df, type_config_dicts)
    generate_tables_from_flash(Path("."), full_df, table_config_dicts)
