"""Schema-agnostic YAML → docx driver with a plug-in renderer registry.

Each project that consumes tesorotools wraps its data sources in a
small adapter, and then declares its charts/tables/text blocks in a
YAML file. This module dispatches those declarations to the right
renderer at runtime, so projects share the orchestration code instead
of each one growing its own ``driver.py``.

Typical usage::

    from tesorotools import driver
    from tesorotools.artists.line_plot import LinePlot

    def render_line(document, cfg, ctx):
        chart = LinePlot(out_path=Path(cfg["out_path"]), ...)
        chart.plot()
        # then embed the PNG into ``document``...

    driver.register_renderer("line", render_line)
    items = driver.load(yaml_path)["charts"]
    driver.render(document, items, ctx={"year": 2026})

Renderers are looked up by the ``type`` key on each item; selecting
which items to render in a given pass is done with the ``section``
and ``on_table`` filters, mirroring the diary/reports use case where
some charts go before the tables and others embed inside them.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Mapping

from docx.document import Document

from tesorotools.utils.config import read_config

Renderer = Callable[[Document, dict[str, Any], Mapping[str, Any]], None]

_REGISTRY: dict[str, Renderer] = {}


def register_renderer(type_name: str, renderer: Renderer) -> None:
    """Register *renderer* for items declaring ``type: <type_name>``.

    Calling twice with the same name overwrites the previous entry,
    so projects can swap implementations in tests.
    """
    _REGISTRY[type_name] = renderer


def unregister_renderer(type_name: str) -> None:
    """Remove a previously registered renderer; no-op if absent."""
    _REGISTRY.pop(type_name, None)


def registered_types() -> list[str]:
    """Names currently in the registry, sorted alphabetically."""
    return sorted(_REGISTRY)


def load(path: Path) -> dict[str, Any]:
    """Read a driver YAML file. Pure I/O wrapper around ``read_config``."""
    return read_config(path)


def _substitute_tokens(value: Any, ctx: Mapping[str, Any]) -> Any:
    """Recursively substitute ``{token}`` placeholders in strings.

    Unknown tokens are left literal so partially-templated YAML is
    still readable when ctx is incomplete (useful in tests). Lists
    and dicts are walked; non-string leaves pass through untouched.
    """
    if isinstance(value, str):
        try:
            return value.format_map(_SafeMapping(ctx))
        except (KeyError, IndexError, ValueError):
            return value
    if isinstance(value, list):
        return [_substitute_tokens(v, ctx) for v in value]  # type: ignore[reportUnknownVariableType]
    if isinstance(value, dict):
        return {k: _substitute_tokens(v, ctx) for k, v in value.items()}  # type: ignore[reportUnknownVariableType]
    return value


class _SafeMapping(dict[str, Any]):
    """``str.format_map`` mapping that leaves unknown keys literal."""

    def __init__(self, base: Mapping[str, Any]) -> None:
        super().__init__(base)

    def __missing__(self, key: str) -> str:
        return "{" + key + "}"


def render(
    document: Document,
    items: Mapping[str, dict[str, Any]],
    ctx: Mapping[str, Any] | None = None,
    *,
    section: str | None = None,
    on_table: str | None = None,
) -> None:
    """Render every item in *items* whose filters match.

    *items* maps item ids to configuration dicts; each dict must
    declare a ``type`` key that resolves to a registered renderer.
    String values inside the config (titles, labels, paths) are
    formatted against *ctx*: ``"Bolsas {year}"`` with
    ``ctx={"year": 2026}`` becomes ``"Bolsas 2026"``. Missing tokens
    are left as literals.

    Filters:

    - ``section`` — only render items whose ``section`` field equals
      this value (e.g. ``"pre_tables"`` vs ``"intro"``).
    - ``on_table`` — only render items whose ``on_table`` field
      equals this value, used to embed charts beside specific tables.

    When both filters are ``None`` every item is rendered.
    Items declaring an unknown ``type`` raise ``KeyError`` so the
    misconfiguration surfaces immediately.
    """
    ctx_resolved: Mapping[str, Any] = ctx if ctx is not None else {}
    for item_id, raw_cfg in items.items():
        if section is not None and raw_cfg.get("section") != section:
            continue
        if on_table is not None and raw_cfg.get("on_table") != on_table:
            continue
        cfg: dict[str, Any] = _substitute_tokens(dict(raw_cfg), ctx_resolved)
        cfg["id"] = item_id
        type_name: str = cfg.get("type", "")
        if type_name not in _REGISTRY:
            raise KeyError(
                f"No renderer registered for type {type_name!r} "
                f"(item {item_id!r}). Available: {registered_types()}"
            )
        _REGISTRY[type_name](document, cfg, ctx_resolved)
