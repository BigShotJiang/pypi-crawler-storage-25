from pathlib import Path
from typing import Any

import yaml

from tesorotools.utils.template import TemplateLoader

_tags_registered = False


def _register_all_tags() -> None:
    """Register every YAML tag on TemplateLoader.

    Called once, lazily, the first time ``read_config`` is
    invoked with ``loader=TemplateLoader``.  This removes
    the need for consumers to import ``tesorotools.render``
    or ``tesorotools.artists`` just for their side effects.
    """
    global _tags_registered  # noqa: PLW0603
    if _tags_registered:
        return
    _tags_registered = True

    # -- artists tags --
    from tesorotools.artists.barh_plot import (
        HorizontalBarChart,
    )
    from tesorotools.artists.line_plot import (
        Format,
        Legend,
        LinePlot,
    )
    from tesorotools.artists.stacked import (
        StackedAreaPlot,
        StackedBarPlot,
    )

    TemplateLoader.add_constructor("!line_plot", LinePlot.from_yaml)
    TemplateLoader.add_constructor("!format", Format.from_yaml)
    TemplateLoader.add_constructor("!legend", Legend.from_yaml)
    TemplateLoader.add_constructor("!stacked_area", StackedAreaPlot.from_yaml)
    TemplateLoader.add_constructor("!stacked_bar", StackedBarPlot.from_yaml)
    TemplateLoader.add_constructor("!barh", HorizontalBarChart.from_yaml)

    # -- render tags --
    from tesorotools.render.content.images import (
        Image,
        Images,
    )
    from tesorotools.render.content.section import Section
    from tesorotools.render.content.subtitle import Subtitle
    from tesorotools.render.content.table import Table
    from tesorotools.render.content.text import Text
    from tesorotools.render.content.title import Title
    from tesorotools.render.report import Report

    TemplateLoader.add_constructor("!report", Report.from_yaml)
    TemplateLoader.add_constructor("!section", Section.from_yaml)
    TemplateLoader.add_constructor("!image", Image.from_yaml)
    TemplateLoader.add_constructor("!images", Images.from_yaml)
    TemplateLoader.add_constructor("!table", Table.from_yaml)
    TemplateLoader.add_constructor("!text", Text.from_yaml)
    TemplateLoader.add_constructor("!title", Title.from_yaml)
    TemplateLoader.add_constructor("!subtitle", Subtitle.from_yaml)


def clean_config_dicts(
    config_dicts: dict[str, Any],
) -> dict[str, Any]:
    return {k: v for k, v in config_dicts.items() if not k.startswith(".")}


def read_config(
    config_file: Path,
    loader: type[yaml.FullLoader] | None = None,
    clean: bool = True,
) -> Any:
    actual_loader: type[yaml.FullLoader] = (
        yaml.FullLoader if loader is None else TemplateLoader
    )
    if actual_loader is TemplateLoader:
        _register_all_tags()
    with open(config_file, encoding="utf8") as file:
        config_dict: Any = yaml.load(file, Loader=actual_loader)
        if clean and isinstance(config_dict, dict):
            config_dict = clean_config_dicts(config_dict)  # type: ignore[reportUnknownArgumentType]
    return config_dict


def merge(a: dict[str, Any], b: dict[str, Any]) -> dict[str, Any]:
    # a overrides
    for key in b:
        if key in a:
            if isinstance(a[key], dict) and isinstance(b[key], dict):
                merge(a[key], b[key])
        else:
            a[key] = b[key]
    return a
