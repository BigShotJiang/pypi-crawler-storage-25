import platform
from pathlib import Path


def resolve_shortcut(shortcut: Path) -> Path:
    """Returns the real path behind a shortcut (.lnk on Windows, symlink on Linux/macOS)

    Parameters
    ----------
    shortcut : Path
        Path of the shortcut

    Returns
    -------
    Path
        Real path behind the shortcut
    """
    system: str = platform.system()
    if system in ("Linux", "Darwin"):
        return shortcut.resolve()
    elif system == "Windows":
        # lazy imports
        import pythoncom
        import win32com.client

        pythoncom.CoInitialize()

        try:
            shell = win32com.client.Dispatch("WScript.Shell")
            target: str = shell.CreateShortCut(str(shortcut)).Targetpath
            return Path(target)
        finally:
            pythoncom.CoUninitialize()
    else:
        return shortcut
