from typing import Any

import pandas as pd

from tesorotools.utils.matplotlib import format_annotation


def format_cell(
    raw: float,
    decimals: int,
    unit: str = "",
    *,
    row_unit_override: str = "",
) -> str:
    """Format a numeric cell value with locale-aware separators.

    Wraps :func:`format_annotation` so callers building a custom table
    pipeline have a single entry point that also resolves
    ``row_unit_override``. When the override is a non-empty string it
    replaces the column-level ``unit`` for that cell, enabling tables
    where one column carries rows with heterogeneous units (e.g. a
    "last value" column showing prices in EUR for some rows and USD
    for others).
    """
    final_unit: str = row_unit_override if row_unit_override else unit
    return format_annotation(raw, decimals=decimals, units=final_unit)


def format_table(
    table: pd.DataFrame, format_dict: dict[str, dict[str, Any]]
) -> pd.DataFrame:
    """Formats a pandas dataframe to get it ready for being rendered into a .docx file.

    Parameters
    ----------
    table : pd.DataFrame
    format_dict : dict[str, dict[str, Any]]
        Each key in the dictionary is a column in the dataframe, each value is a dictionary with 3 possible entries: "scale" (integer, default=1), "decimals" (integer, default=0), "units" (string, default="").

    Returns
    -------
    pd.DataFrame
        The formatted dataframe
    """
    for column, fmt in format_dict.items():
        if pd.api.types.is_numeric_dtype(table[column]):
            scale: int = fmt.get("scale", 1)
            table[column] = table[column] / scale
            decimals: int = fmt.get("decimals", 0)
            units: str = fmt.get("units", "")

            def _fmt(x: float, d: int = decimals, u: str = units) -> str:
                return format_annotation(value=x, decimals=d, units=u)

            table[column] = table[column].apply(_fmt)

    for column in table.columns:
        table[column] = table[column].astype(str)
    return table
