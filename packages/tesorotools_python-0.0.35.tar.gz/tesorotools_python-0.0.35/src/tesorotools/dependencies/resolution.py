from __future__ import annotations

from typing import Any

import pandas as pd

from tesorotools.offsets.offsets import process_raw_data, trim
from tesorotools.pipeline.engine import (
    TransformationRule,
    apply_transformations,
)

from .node import Node


def resolve(
    start: Node,
    resolved: list[Node],
    unresolved: list[str],
    independent: set[str],
    dependencies_cfg: dict[str, Any],
) -> None:
    if start.name in dependencies_cfg:
        is_independent: bool = False
        config: dict[str, Any] = dependencies_cfg[start.name]
        start.build_edges(**config)
    else:
        is_independent = True
        independent.add(start.name)

    if not is_independent:
        unresolved.append(start.name)
        for node in start.edges:
            if node.name in unresolved:
                raise ValueError(
                    f"circular dependency: {start.name} <-> {node.name}"
                )
            if node not in resolved:
                resolve(
                    node,
                    resolved,
                    unresolved,
                    independent,
                    dependencies_cfg,
                )
        resolved.append(start)
        unresolved.remove(start.name)


def collect_document_series(
    config_dicts: list[dict[str, Any]],
    find: str = "series",
) -> list[str]:
    series: set[str] = set()
    for config_dict in config_dicts:
        series = series | collect_series(config_dict, find)
    return list(series)


def resolve_series(
    config_dicts: list[dict[str, Any]],
    dependencies_cfg: dict[str, Any],
) -> dict[str, set[str] | list[TransformationRule]]:
    """Resolve which series are independent vs derived.

    Returns
    -------
    dict with keys:
        ``"independent"``
            Set of series names that exist as raw data.
        ``"rules"``
            Topologically sorted list of
            ``TransformationRule`` for derived series.
    """
    series: list[str] = collect_document_series(config_dicts)
    nodes: list[Node] = [Node(name=name) for name in series]
    independent_nodes: set[str] = set()
    resolved: list[Node] = []
    for node in nodes:
        resolve(
            start=node,
            resolved=resolved,
            unresolved=[],
            independent=independent_nodes,
            dependencies_cfg=dependencies_cfg,
        )

    return {
        "independent": independent_nodes,
        "rules": [n.rule for n in resolved],
    }


def compute_derivate_series(
    rules: list[TransformationRule],
    trimmed_data: pd.DataFrame,
) -> pd.DataFrame:
    """Compute derived series and return only the new columns.

    Parameters
    ----------
    rules
        Topologically sorted rules (from ``resolve_series``).
    trimmed_data
        DataFrame with independent series (base values only,
        no MultiIndex).

    Returns
    -------
    pd.DataFrame
        Only the columns produced by the rules.
    """
    result = apply_transformations(trimmed_data, rules)
    derived_cols = [r.output_name for r in rules]
    return result[derived_cols]


def concat_derivate_series(
    independent_full_df: pd.DataFrame,
    derivate_trimmed_df: pd.DataFrame,
    offsets_config: dict[str, Any],
    force_trim: bool = False,
) -> pd.DataFrame:
    if force_trim:
        independent_full_df = process_raw_data(
            trim(independent_full_df),  # type: ignore[arg-type]
            **offsets_config,  # type: ignore[arg-type]
        )

    derivate_full_df: pd.DataFrame = process_raw_data(
        derivate_trimmed_df, **offsets_config
    )
    full: pd.DataFrame = pd.concat(
        [independent_full_df, derivate_full_df], axis=1
    )
    return full


def collect_series(
    config_dict: dict[str, Any], find: str = "series"
) -> set[str]:
    series: set[str] = set()
    if find in config_dict:
        config_series: dict[str, str] = config_dict[find]
        series = series | set(config_series.keys())
    for k, v in config_dict.items():
        if k != find and isinstance(v, dict):
            series = series | collect_series(v, find)  # type: ignore[reportUnknownArgumentType]
    return series
