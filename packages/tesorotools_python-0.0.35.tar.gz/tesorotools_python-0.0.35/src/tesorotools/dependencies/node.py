from tesorotools.pipeline.engine import TransformationRule
from tesorotools.pipeline.rules import FACTORIES


class Node:
    def __init__(self, name: str) -> None:
        self._name: str = name
        self._edges: list["Node"] = []
        self._rule: TransformationRule | None = None

    def add_edge(self, node: "Node") -> None:
        self._edges.append(node)

    def build_edges(
        self,
        *,
        dependencies: list[str],
        function: str,
        **kwargs: object,
    ) -> None:
        factory = FACTORIES.get(function)
        if factory is None:
            raise ValueError(
                f"Unknown function '{function}'. Available: {list(FACTORIES)}"
            )
        self._rule = factory(
            self._name,
            dependencies=dependencies,
            **kwargs,
        )
        for d in dependencies:
            self.add_edge(Node(d))

    @property
    def name(self) -> str:
        return self._name

    @property
    def edges(self) -> list["Node"]:
        return self._edges

    @property
    def rule(self) -> TransformationRule:
        if self._rule is None:
            raise AttributeError(
                f"Node '{self._name}' has no rule. Call build_edges first."
            )
        return self._rule
