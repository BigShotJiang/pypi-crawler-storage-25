"""Cell-level diff between rendered .docx tables.

Useful for bit-for-bit validation when migrating a rendering
pipeline: render the document with both the old and the new code
paths, load both .docx files, and call :func:`compare_tables`. An
empty result means the two outputs are equivalent at the level the
comparator inspects (cell text, font colour, cell shading).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

from docx.document import Document
from docx.oxml.ns import qn
from docx.table import Table as TableDocx
from docx.table import _Cell as TableCell  # pyright: ignore[reportPrivateUsage]

DiscrepancyField = Literal["shape", "text", "color", "shade"]


@dataclass(frozen=True)
class Discrepancy:
    """A single mismatch between two table cells.

    ``table_idx`` is the position of the table in ``doc.tables``.
    ``row`` and ``col`` are zero-based; for a "shape" discrepancy
    they refer to the smaller of the two tables (``-1`` when only
    one document has the table at all).
    ``field`` describes what differs and ``value_a`` / ``value_b``
    are the offending values from each document.
    """

    table_idx: int
    row: int
    col: int
    field: DiscrepancyField
    value_a: Any
    value_b: Any

    def __str__(self) -> str:
        loc = f"T{self.table_idx} r{self.row}c{self.col}"
        return f"{loc} {self.field}: {self.value_a!r} != {self.value_b!r}"


def _font_color_hex(cell: TableCell) -> str | None:
    if not cell.paragraphs:
        return None
    runs = cell.paragraphs[0].runs
    if not runs:
        return None
    rgb = runs[0].font.color.rgb
    return None if rgb is None else str(rgb)


def _as_any(value: object) -> Any:
    """Identity helper that funnels python-docx's partially-typed XML
    nodes through a clean ``Any`` boundary so pyright stops chasing
    Unknown propagations."""
    return value


def _shade_hex(cell: TableCell) -> str | None:
    """Return the cell shading colour (``w:fill``), if any."""
    tcPr = _as_any(cell._tc.tcPr)  # pyright: ignore[reportPrivateUsage, reportUnknownMemberType, reportUnknownArgumentType]
    if tcPr is None:
        return None
    shd = _as_any(tcPr.find(qn("w:shd")))
    if shd is None:
        return None
    fill = _as_any(shd.get(qn("w:fill")))
    return None if fill is None else str(fill)


def _compare_table(
    idx: int,
    table_a: TableDocx,
    table_b: TableDocx,
) -> list[Discrepancy]:
    out: list[Discrepancy] = []

    rows_a = len(table_a.rows)
    rows_b = len(table_b.rows)
    cols_a = len(table_a.columns)
    cols_b = len(table_b.columns)
    if (rows_a, cols_a) != (rows_b, cols_b):
        out.append(
            Discrepancy(
                idx, -1, -1, "shape", (rows_a, cols_a), (rows_b, cols_b)
            )
        )

    rows = min(rows_a, rows_b)
    cols = min(cols_a, cols_b)
    for r in range(rows):
        for c in range(cols):
            cell_a = table_a.cell(r, c)
            cell_b = table_b.cell(r, c)
            if cell_a.text != cell_b.text:
                out.append(
                    Discrepancy(idx, r, c, "text", cell_a.text, cell_b.text)
                )
            color_a = _font_color_hex(cell_a)
            color_b = _font_color_hex(cell_b)
            if color_a != color_b:
                out.append(Discrepancy(idx, r, c, "color", color_a, color_b))
            shade_a = _shade_hex(cell_a)
            shade_b = _shade_hex(cell_b)
            if shade_a != shade_b:
                out.append(Discrepancy(idx, r, c, "shade", shade_a, shade_b))
    return out


def compare_tables(
    doc_a: Document,
    doc_b: Document,
) -> list[Discrepancy]:
    """Compare every table in *doc_a* against the corresponding one in *doc_b*.

    Returns one :class:`Discrepancy` per cell-level difference, plus
    a "shape" entry per table whose dimensions disagree. An empty
    list means the table contents are bit-for-bit equivalent at the
    text/colour/shade granularity. Tables present in only one
    document also surface as "shape" discrepancies on the index that
    lacks them.
    """
    tables_a: list[TableDocx] = list(doc_a.tables)
    tables_b: list[TableDocx] = list(doc_b.tables)

    out: list[Discrepancy] = []
    common = min(len(tables_a), len(tables_b))
    for idx in range(common):
        out.extend(_compare_table(idx, tables_a[idx], tables_b[idx]))

    if len(tables_a) != len(tables_b):
        out.append(
            Discrepancy(
                table_idx=common,
                row=-1,
                col=-1,
                field="shape",
                value_a=len(tables_a),
                value_b=len(tables_b),
            )
        )
    return out
