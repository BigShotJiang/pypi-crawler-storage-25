"""YAML manifest sidecar for published parquet datasets.

Absorbed from the ``src/manifest.py`` copies in ``cnmv_python``
and ``epf``: both had identical ``write_manifest`` and a slightly
different provenance builder (kept per-project).  This module
provides the shared pieces — the YAML writer and the hashing
helper.

A bare ``data.parquet`` in a shared folder is opaque to consumers:
schema and provenance are not visible without opening the file.
The manifest pins both as a YAML sidecar at write time::

    bbdd/cnmv/processed/capa1/concepto=inversiones/ejercicio=2024/
        data.parquet
        _MANIFEST.yaml

Structure
---------
.. code-block:: yaml

    dataset: cnmv/capa1/inversiones/2024
    layer: 1
    row_count: 120013
    parquet_file: data.parquet
    generated_at: 2026-04-21T15:30:00+00:00
    generated_by: cnmv_python
    schema:
      - {name: tipo_fichero, dtype: string[pyarrow]}
      - ...
    provenance:   # optional, caller-supplied
      ...
"""

from __future__ import annotations

import datetime as dt
import hashlib
import logging
from pathlib import Path
from typing import Any

import pandas as pd
import yaml

logger = logging.getLogger(__name__)

MANIFEST_FILENAME = "_MANIFEST.yaml"


def sha256_file(path: Path, chunk: int = 1 << 20) -> str:
    """Compute the SHA-256 of a file, streaming in 1 MiB chunks."""
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            block = f.read(chunk)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def write_manifest(
    parquet_path: Path,
    df: pd.DataFrame,
    dataset: str,
    layer: int,
    provenance: dict[str, Any] | None = None,
    generated_by: str = "",
) -> Path:
    """Write ``_MANIFEST.yaml`` next to *parquet_path*.

    Parameters
    ----------
    parquet_path
        Full path to the ``data.parquet`` that was just written.
        The manifest is placed in the same directory.
    df
        DataFrame used only to derive ``schema`` and ``row_count``
        — not persisted.
    dataset
        Canonical dataset name (e.g. ``"cnmv/capa1/inversiones/2024"``).
    layer
        Convention: ``0`` = raw, ``1`` = processed.
    provenance
        Optional project-specific dict (source files, hashes, ...).
        Omitted from the YAML when ``None``.
    generated_by
        Identifier of the generating project (e.g. ``"cnmv_python"``).

    Returns
    -------
    Path
        The path of the written manifest.
    """
    payload: dict[str, Any] = {
        "dataset": dataset,
        "layer": layer,
        "row_count": int(len(df)),
        "parquet_file": parquet_path.name,
        "generated_at": dt.datetime.now(dt.UTC).isoformat(timespec="seconds"),
        "generated_by": generated_by,
        "schema": [
            {"name": str(col), "dtype": str(df[col].dtype)}
            for col in df.columns
        ],
    }
    if provenance:
        payload["provenance"] = provenance

    out_path = parquet_path.parent / MANIFEST_FILENAME
    with out_path.open("w", encoding="utf-8") as f:
        yaml.safe_dump(
            payload,
            f,
            sort_keys=False,
            allow_unicode=True,
            default_flow_style=False,
        )
    logger.debug("Manifest written: %s", out_path)
    return out_path
