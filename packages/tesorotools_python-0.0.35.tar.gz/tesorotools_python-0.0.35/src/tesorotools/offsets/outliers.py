"""Outlier detection based on rolling statistics."""

from __future__ import annotations

from typing import Any

import pandas as pd

from .offsets import Stat


def flag_outliers(data: pd.DataFrame) -> pd.Series[Any]:
    """Compute z-scores: (value - rolling_mean) / rolling_std."""
    return (data[Stat.VALUE.value] - data[Stat.ROLL_AVG.value]) / data[
        Stat.ROLL_STD.value
    ]


def flag_outliers_with_limit(
    data: pd.DataFrame, limit: float
) -> pd.Series[Any]:
    """Return a boolean Series flagging points whose z-score exceeds *limit*."""
    return (data[Stat.VALUE.value] - data[Stat.ROLL_AVG.value]) / data[
        Stat.ROLL_STD.value
    ] > limit
