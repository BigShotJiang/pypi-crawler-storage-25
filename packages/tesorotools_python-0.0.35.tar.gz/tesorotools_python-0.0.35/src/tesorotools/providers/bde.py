"""Bank of Spain (Banco de Espana, BdE) data provider.

Downloads historical time series from the BdE public REST API.
No authentication required.

Install with::

    pip install tesorotools-python[bde]

API reference
-------------
Endpoint:
    https://app.bde.es/bierest/resources/srdatosapp/listaSeries

Query parameters (names are fixed by the BdE API):
    ``idioma``  : ``"es"`` | ``"en"``
    ``series``  : comma-separated series codes
    ``rango``   : ``"MAX"`` | ``"30M"`` | ``"60M"``

Notes
-----
- ECB DCF series (credit stock data) are also available
  through this API because the BdE redistributes them.
- The API accepts multiple series per request, but may
  time out with too many.  Downloads are batched.
- Timestamps include timezone info (UTC).  They are
  normalized to tz-naive midnight for pandas compatibility.
"""

from __future__ import annotations

import logging
from typing import TypedDict, cast

import pandas as pd
import requests

from tesorotools.providers.base import DataProvider

logger = logging.getLogger(__name__)


class _BdeSeriesEntry(TypedDict):
    """Shape of a single series object in the BdE API
    JSON response."""

    serie: str
    fechas: list[str]
    valores: list[int | float | None]
    decimales: int
    codFrecuencia: str


_LIST_URL = "https://app.bde.es/bierest/resources/srdatosapp/listaSeries"
_PING_URL = "https://app.bde.es/bierest/resources/srdatosapp/favoritas"

DEFAULT_TIMEOUT = 30
BATCH_SIZE = 10


class BdeProvider(DataProvider):
    """Provider that downloads series from the Bank of Spain.

    The BdE API is public and requires no credentials.

    Parameters
    ----------
    language
        Language for metadata.  ``"es"`` for Spanish,
        ``"en"`` for English.
    timeout
        Maximum seconds to wait per HTTP request.
    """

    def __init__(
        self,
        *,
        language: str = "es",
        timeout: int = DEFAULT_TIMEOUT,
    ) -> None:
        self._language = language
        self._timeout = timeout

    def fetch(
        self,
        codes: list[str],
        start: str | None = None,
        end: str | None = None,
    ) -> pd.DataFrame:
        """Download one or more series from the BdE.

        Splits the series into batches of ``BATCH_SIZE``,
        downloads each batch in a single HTTP request, and
        merges the results into one DataFrame.

        Parameters
        ----------
        codes
            BdE series codes.
        start
            Earliest date to include (ISO format).
            If ``None``, fetches the full history.
        end
            Ignored by this provider.  The BdE API always
            returns data up to the latest observation.
        """
        if not codes:
            return pd.DataFrame()

        time_range = _compute_time_range(start)
        frames: list[pd.DataFrame] = []

        for batch in _batches(codes, BATCH_SIZE):
            df = self._download_batch(batch, time_range)
            if not df.empty:
                frames.append(df)

        if not frames:
            return pd.DataFrame()

        result = pd.concat(frames, axis=1)
        result.sort_index(inplace=True)

        if start:
            cutoff = pd.Timestamp(start)
            result = result.loc[result.index >= cutoff]

        return result

    def is_available(self) -> bool:
        """Ping the BdE API to check connectivity."""
        try:
            resp = requests.get(
                _PING_URL,
                params={
                    "idioma": self._language,
                    "series": "DN_1TI2TIE42",
                },
                timeout=5,
            )
            return resp.status_code == 200
        except requests.RequestException:
            return False

    def _download_batch(
        self,
        codes: list[str],
        time_range: str,
    ) -> pd.DataFrame:
        params = {
            "idioma": self._language,
            "series": ",".join(codes),
            "rango": time_range,
        }
        logger.info("BdE: downloading %d series...", len(codes))
        resp = requests.get(
            _LIST_URL,
            params=params,
            timeout=self._timeout,
        )
        resp.raise_for_status()

        payload = resp.json()
        _check_api_error(payload)
        return _parse_series_list(cast(list[_BdeSeriesEntry], payload), codes)


# ----------------------------------------------------------
# Module-level helpers
# ----------------------------------------------------------


class _BdeErrorResponse(TypedDict, total=False):
    errNum: int  # noqa: N815
    errMsgUsr: str  # noqa: N815
    errMsgDebug: str  # noqa: N815


def _check_api_error(payload: object) -> None:
    """Raise RuntimeError if the API returned an error."""
    if not isinstance(payload, dict):
        return
    if "errNum" not in payload:
        return
    err = cast(_BdeErrorResponse, payload)
    raise RuntimeError(
        f"BdE API error {err.get('errNum', '?')}: {err.get('errMsgUsr', '')}"
    )


def _compute_time_range(start: str | None) -> str:
    """Translate a start date into a BdE API range value.

    The BdE API only accepts ``"30M"``, ``"60M"``, or
    ``"MAX"`` for the ``rango`` parameter.  This function
    picks the smallest value that covers the requested
    start date.
    """
    if start is None:
        return "MAX"

    start_ts = pd.Timestamp(start)
    now = pd.Timestamp.now()
    months_needed = (
        (now.year - start_ts.year) * 12
        + (now.month - start_ts.month)
        + 3  # buffer for publication lag
    )

    if months_needed <= 30:
        return "30M"
    if months_needed <= 60:
        return "60M"
    return "MAX"


def _parse_series_list(
    series_list: list[_BdeSeriesEntry],
    requested: list[str],
) -> pd.DataFrame:
    """Convert the JSON series list into a DataFrame."""
    columns: dict[str, pd.Series[float]] = {}

    for entry in series_list:
        code = entry["serie"]
        raw_dates = entry["fechas"]
        raw_values = entry["valores"]

        if not raw_dates:
            logger.warning("BdE: %s returned no data", code)
            continue

        dates = pd.to_datetime(raw_dates, utc=True)
        dates = dates.tz_localize(None).normalize()
        values = [_to_float(v) for v in raw_values]

        columns[code] = pd.Series(values, index=dates, name=code, dtype=float)

    missing = set(requested) - set(columns)
    if missing:
        logger.warning(
            "BdE: series not found: %s",
            ", ".join(sorted(missing)),
        )

    if not columns:
        return pd.DataFrame()

    df = pd.DataFrame(columns)
    df.index.name = "date"
    df.sort_index(inplace=True)
    return df


def _to_float(raw: int | float | None) -> float | None:
    """Convert a raw API value to float, or None."""
    if raw is None:
        return None
    try:
        return float(raw)
    except (ValueError, TypeError):
        return None


def _batches(items: list[str], size: int) -> list[list[str]]:
    """Split a list into sublists of at most ``size``."""
    return [items[i : i + size] for i in range(0, len(items), size)]
