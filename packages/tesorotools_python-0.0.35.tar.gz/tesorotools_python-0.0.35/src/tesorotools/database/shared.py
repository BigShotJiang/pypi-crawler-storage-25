"""Resolver for shared OneDrive folders used as a team database.

Absorbed from the ``src/bbdd.py`` copies in ``cnmv_python`` and
``epf`` — both had the same logic with only a per-project env var
name differing.  The old ``ShortcutDatabase`` (Windows ``.lnk``
per user) is superseded by this resolver for the ``bbdd/``
layout: each member of the team gets the same path auto-discovered
from their OneDrive mount.

Resolution order
----------------
1. An explicit override environment variable (``env_var`` argument,
   e.g. ``"CNMV_BBDD_ROOT"``).  Used for local dev, CI and tests.
2. ``%OneDriveCommercial%`` + glob for a SharePoint folder whose
   name contains ``team_marker`` and that contains ``subdir``.
3. ``%OneDrive%`` as a fallback.
4. ``RuntimeError`` with a diagnostic listing every attempt.

Callers supply their own ``team_marker`` — this module does not
assume any specific SharePoint tenant.  The substring match is
tolerant of the OneDrive client variant (``General - {team}``
vs. ``{team} - General`` depending on locale).
"""

from __future__ import annotations

import logging
import os
from functools import cache
from pathlib import Path

logger = logging.getLogger(__name__)

#: OneDrive env vars published by the Windows client.
_ONEDRIVE_ENV_VARS = ("OneDriveCommercial", "OneDrive")


@cache
def resolve_shared_root(
    *,
    env_var: str,
    team_marker: str,
    subdir: str = "bbdd",
) -> Path:
    """Resolve the local path to a shared OneDrive folder.

    Parameters
    ----------
    env_var
        Name of the environment variable for explicit override
        (e.g. ``"CNMV_BBDD_ROOT"``).  Each project picks its own
        to avoid collisions on shared dev machines.
    team_marker
        Substring matched against the SharePoint folder name.
    subdir
        Shared folder subdirectory under the SharePoint mount
        (default ``"bbdd"``).

    Returns
    -------
    Path
        Absolute path to the existing shared folder.

    Raises
    ------
    RuntimeError
        If none of the resolution steps yields an existing
        directory.  The message lists every attempt so the user
        can see what was tried.
    """
    tried: list[str] = []

    override = os.environ.get(env_var)
    if override:
        p = Path(override)
        if p.is_dir():
            logger.info("shared root resolved via %s: %s", env_var, p)
            return p
        raise RuntimeError(
            f"{env_var}={override!r} does not point to an existing directory."
        )
    tried.append(f"{env_var} (not set)")

    for var in _ONEDRIVE_ENV_VARS:
        val = os.environ.get(var)
        if not val:
            tried.append(f"%{var}% (not set)")
            continue
        root = Path(val)
        if not root.is_dir():
            tried.append(f"%{var}%={val!r} (not a directory)")
            continue
        matches = sorted(
            c for c in root.glob(f"*{team_marker}*/{subdir}") if c.is_dir()
        )
        if matches:
            chosen = matches[0]
            if len(matches) > 1:
                logger.warning(
                    "Multiple %s/ candidates under %s: %s. Picking %s.",
                    subdir,
                    root,
                    matches,
                    chosen,
                )
            logger.info(
                "shared root auto-discovered via %%%s%%: %s", var, chosen
            )
            return chosen
        tried.append(f"%{var}% without '*{team_marker}*/{subdir}' under {root}")

    raise RuntimeError(
        f"Cannot locate the {subdir}/ folder. Attempts:\n  - "
        + "\n  - ".join(tried)
        + f"\nHint: set {env_var} to the local path where OneDrive "
        f"syncs the shared {subdir}/ folder."
    )


class SharedDatabase:
    """Per-project view over a shared OneDrive database folder.

    Replaces ``ShortcutDatabase`` (``.lnk`` per user) for the
    ``bbdd/`` layout: each project has a subtree with
    ``raw/`` and ``processed/`` conventional subdirectories.

    Parameters
    ----------
    project
        Project name (segment under ``{shared_root}/``, e.g.
        ``"cnmv"`` or ``"epf"``).
    env_var
        Environment variable for explicit override of the shared
        root (e.g. ``"CNMV_BBDD_ROOT"``).
    team_marker
        Substring of the SharePoint folder name (see
        :func:`resolve_shared_root`).
    subdir
        Shared folder subdirectory (default ``"bbdd"``).
    """

    def __init__(
        self,
        project: str,
        *,
        env_var: str,
        team_marker: str,
        subdir: str = "bbdd",
    ) -> None:
        self.project = project
        self._env_var = env_var
        self._team_marker = team_marker
        self._subdir = subdir

    @property
    def root(self) -> Path:
        """Resolved path to the shared folder."""
        return resolve_shared_root(
            env_var=self._env_var,
            team_marker=self._team_marker,
            subdir=self._subdir,
        )

    @property
    def project_root(self) -> Path:
        """``{root}/{project}/`` — subtree reserved for this project."""
        return self.root / self.project

    @property
    def processed_root(self) -> Path:
        """``{root}/{project}/processed/`` — datasets for consumers."""
        return self.project_root / "processed"

    @property
    def raw_root(self) -> Path:
        """``{root}/{project}/raw/`` — original source files."""
        return self.project_root / "raw"
