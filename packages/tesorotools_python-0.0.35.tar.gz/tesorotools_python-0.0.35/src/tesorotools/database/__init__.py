"""
Módulo de gestión de bases de datos y persistencia para tesorotools.
Contiene las utilidades para interactuar con bases de datos locales y remotas.
"""

from tesorotools.database.local import LocalDatabase, ShortcutDatabase
from tesorotools.database.shared import SharedDatabase, resolve_shared_root

__all__ = [
    "LocalDatabase",
    "SharedDatabase",
    "ShortcutDatabase",
    "resolve_shared_root",
]
