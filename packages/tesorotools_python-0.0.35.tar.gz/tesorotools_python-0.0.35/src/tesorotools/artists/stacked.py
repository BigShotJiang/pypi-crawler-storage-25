from __future__ import annotations

from pathlib import Path
from typing import Any, Self

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.axes import Axes
from matplotlib.figure import Figure
from yaml.nodes import MappingNode

from tesorotools.artists.line_plot import (
    AX_CONFIG,
    FIG_CONFIG,
    Format,
    Legend,
    adjust_figure_for_plot_size,
    auto_ncol,
    style_baseline,
    style_spines,
)
from tesorotools.utils.config import TemplateLoader


class StackedAreaPlot:
    """Stacked area chart with the tesorotools visual style.

    Parameters match ``LinePlot`` where applicable so that
    chart configs can switch between types by changing a
    single field.
    """

    def __init__(
        self,
        out_path: Path,
        data: pd.DataFrame,
        series: dict[str, str],
        *,
        scale: float = 1,
        start_date: str | None = None,
        end_date: str | None = None,
        baseline: bool = False,
        fmt: Format | None = None,
        legend: Legend | None = None,
        figsize: tuple[float, float] | None = None,
        plot_size: tuple[float, float] | None = None,
    ) -> None:
        if out_path.suffix != ".png":
            raise ValueError(f"out_path must be .png: {out_path}")
        self.out_path = out_path
        self.data = data
        self.series = series
        self.scale = scale
        self.start_date = start_date
        self.end_date = end_date
        self.baseline = baseline
        self.fmt = fmt or Format()
        self.legend = legend
        self.figsize = figsize
        self.plot_size = plot_size

    @classmethod
    def from_yaml(cls, loader: TemplateLoader, node: MappingNode) -> Self:
        cfg: dict[str, Any] = loader.construct_mapping(  # type: ignore[assignment]
            node, deep=True
        )
        cfg.pop("id")
        cfg["out_path"] = Path(cfg["out_path"])
        cfg["data"] = pd.read_feather(cfg.pop("data_path"))
        return cls(**cfg)

    def plot(self) -> Axes:
        start = (
            pd.Timestamp(self.start_date)
            if self.start_date
            else self.data.index.min()
        )
        end = (
            pd.Timestamp(self.end_date)
            if self.end_date
            else self.data.index.max()
        )

        plot_data = self.data.loc[start:end, list(self.series.keys())]
        plot_data = plot_data.dropna(how="all").fillna(0)
        plot_data = plot_data * self.scale

        fig_kw = dict(FIG_CONFIG)
        if self.figsize is not None:
            fig_kw["figsize"] = self.figsize
        fig: Figure = plt.figure(  # type: ignore[reportUnknownMemberType]
            **fig_kw
        )
        ax: Axes = fig.add_subplot()

        labels = list(self.series.values())
        arrays: list[np.ndarray[tuple[int], np.dtype[np.float64]]] = [
            plot_data[col].to_numpy(dtype=np.float64) for col in self.series
        ]
        ax.stackplot(  # type: ignore[reportUnknownMemberType]
            plot_data.index,
            *arrays,
            labels=labels,
            alpha=0.85,
        )

        style_spines(
            ax,
            decimals=self.fmt.decimals,
            units=self.fmt.units,
            **AX_CONFIG["spines"],
        )
        if self.baseline:
            style_baseline(ax, 0, **AX_CONFIG["baseline"])

        fig_width_px: float = fig.get_size_inches()[0] * fig.dpi
        legend_ncol = self.legend.ncol if self.legend else None
        ncol = (
            legend_ncol
            if legend_ncol is not None
            else auto_ncol(ax, labels, available_width_px=fig_width_px)
        )
        handles, label_strs = ax.get_legend_handles_labels()
        fig.legend(  # type: ignore[reportUnknownMemberType]
            handles,
            label_strs,
            loc="outside lower center",
            ncol=ncol,
        )

        if self.plot_size is not None:
            adjust_figure_for_plot_size(fig, ax, self.plot_size)

        fig.savefig(  # type: ignore[reportUnknownMemberType]
            self.out_path
        )
        plt.close(fig)
        return ax


class StackedBarPlot:
    """Stacked bar chart with the tesorotools visual style.

    Positive and negative values are stacked separately so
    that bars extend in both directions from the baseline.

    The ``plot`` method delegates to overridable hooks so
    subclasses can customise individual steps without
    reimplementing the full render pipeline:

    * ``_prepare_data`` — slice, scale, resample
    * ``_format_xticks`` — tick positions, labels, rotation
    """

    def __init__(
        self,
        out_path: Path,
        data: pd.DataFrame,
        series: dict[str, str],
        *,
        scale: float = 1,
        start_date: str | None = None,
        end_date: str | None = None,
        baseline: bool = True,
        fmt: Format | None = None,
        legend: Legend | None = None,
        figsize: tuple[float, float] | None = None,
        overlay_series: dict[str, str] | None = None,
        plot_size: tuple[float, float] | None = None,
        bar_width: float = 0.7,
        x_rotation: float = 0,
    ) -> None:
        if out_path.suffix != ".png":
            raise ValueError(f"out_path must be .png: {out_path}")
        self.out_path = out_path
        self.data = data
        self.series = series
        self.scale = scale
        self.start_date = start_date
        self.end_date = end_date
        self.baseline = baseline
        self.fmt = fmt or Format()
        self.legend = legend
        self.plot_size = plot_size
        self.figsize = figsize
        self.overlay_series = overlay_series or {}
        self.bar_width = bar_width
        self.x_rotation = x_rotation

    @classmethod
    def from_yaml(cls, loader: TemplateLoader, node: MappingNode) -> Self:
        cfg: dict[str, Any] = loader.construct_mapping(  # type: ignore[assignment]
            node, deep=True
        )
        cfg.pop("id")
        cfg["out_path"] = Path(cfg["out_path"])
        cfg["data"] = pd.read_feather(cfg.pop("data_path"))
        return cls(**cfg)

    # -- Overridable hooks -----------------------------------

    def _prepare_data(self) -> pd.DataFrame:
        """Slice, scale, and return plot-ready DataFrame.

        Override to resample, change the index type, etc.
        """
        start = (
            pd.Timestamp(self.start_date)
            if self.start_date
            else self.data.index.min()
        )
        end = (
            pd.Timestamp(self.end_date)
            if self.end_date
            else self.data.index.max()
        )
        all_cols = list(self.series.keys()) + list(self.overlay_series.keys())
        plot_data = self.data.loc[start:end, all_cols]
        plot_data = plot_data.dropna(how="all").fillna(0)
        return plot_data * self.scale

    def _format_xticks(
        self,
        ax: Axes,
        plot_data: pd.DataFrame,
        x: np.ndarray[tuple[int], np.dtype[np.intp]],
    ) -> None:
        """Set tick positions, labels, and rotation.

        Override for custom labels (e.g. string index).
        """
        dates = plot_data.index
        step = max(1, len(dates) // 12)
        tick_pos = list(range(0, len(dates), step))
        tick_labels = [dates[i].strftime("%Y") for i in tick_pos]
        ax.set_xticks(  # type: ignore[reportUnknownMemberType]
            tick_pos
        )
        ax.set_xticklabels(  # type: ignore[reportUnknownMemberType]
            tick_labels, rotation=self.x_rotation
        )

    # -- Main render -----------------------------------------

    def plot(self) -> Axes:
        plot_data = self._prepare_data()

        fig_kw = dict(FIG_CONFIG)
        if self.figsize is not None:
            fig_kw["figsize"] = self.figsize
        fig: Figure = plt.figure(  # type: ignore[reportUnknownMemberType]
            **fig_kw
        )
        ax: Axes = fig.add_subplot()

        cols = list(self.series.keys())
        labels = list(self.series.values())

        x = np.arange(len(plot_data))

        pos_bottom: np.ndarray[tuple[int], np.dtype[np.float64]] = np.zeros(
            len(plot_data)
        )
        neg_bottom: np.ndarray[tuple[int], np.dtype[np.float64]] = np.zeros(
            len(plot_data)
        )

        for col, label in zip(cols, labels):
            values: np.ndarray[tuple[int], np.dtype[np.float64]] = plot_data[
                col
            ].to_numpy(dtype=np.float64)
            pos: np.ndarray[tuple[int], np.dtype[np.float64]] = np.where(
                values >= 0, values, 0.0
            )
            neg: np.ndarray[tuple[int], np.dtype[np.float64]] = np.where(
                values < 0, values, 0.0
            )

            color = (
                ax.bar(  # type: ignore[reportUnknownMemberType]
                    x,
                    pos,
                    bottom=pos_bottom,
                    width=self.bar_width,
                    label=label,
                )
                .patches[0]
                .get_facecolor()
            )
            ax.bar(  # type: ignore[reportUnknownMemberType]
                x,
                neg,
                bottom=neg_bottom,
                width=self.bar_width,
                color=color,
            )
            pos_bottom = pos_bottom + pos
            neg_bottom = neg_bottom + neg

        for o_col, o_label in self.overlay_series.items():
            o_vals = plot_data[o_col].to_numpy(dtype=np.float64)
            ax.plot(  # type: ignore[reportUnknownMemberType]
                x,
                o_vals,
                color="black",
                linewidth=1.5,
                label=o_label,
                zorder=10,
            )

        self._format_xticks(ax, plot_data, x)

        style_spines(
            ax,
            decimals=self.fmt.decimals,
            units=self.fmt.units,
            **AX_CONFIG["spines"],
        )
        if self.baseline:
            style_baseline(ax, 0, **AX_CONFIG["baseline"])

        all_labels = list(self.series.values()) + list(
            self.overlay_series.values()
        )
        fig_width_px: float = fig.get_size_inches()[0] * fig.dpi
        legend_ncol = self.legend.ncol if self.legend else None
        ncol = (
            legend_ncol
            if legend_ncol is not None
            else auto_ncol(ax, all_labels, available_width_px=fig_width_px)
        )
        handles, label_strs = ax.get_legend_handles_labels()
        fig.legend(  # type: ignore[reportUnknownMemberType]
            handles,
            label_strs,
            loc="outside lower center",
            ncol=ncol,
        )

        if self.plot_size is not None:
            adjust_figure_for_plot_size(fig, ax, self.plot_size)

        fig.savefig(  # type: ignore[reportUnknownMemberType]
            self.out_path
        )
        plt.close(fig)
        return ax
