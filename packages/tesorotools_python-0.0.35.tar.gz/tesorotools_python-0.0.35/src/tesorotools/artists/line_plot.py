import datetime
import locale
from pathlib import Path
from typing import Any, Self, cast

import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.axes import Axes
from matplotlib.figure import Figure
from matplotlib.font_manager import FontProperties
from matplotlib.ticker import FuncFormatter
from yaml.nodes import MappingNode

from tesorotools.utils.config import TemplateLoader
from tesorotools.utils.matplotlib import (
    PLOT_CONFIG,
    format_annotation,
    load_fonts,
)

locale.setlocale(locale.LC_ALL, "")

load_fonts()

LINE_PLOT_CONFIG: dict[str, Any] = PLOT_CONFIG["line"]
AX_CONFIG: dict[str, Any] = PLOT_CONFIG["ax"]
FIG_CONFIG: dict[str, Any] = PLOT_CONFIG["figure"]


def adjust_figure_for_plot_size(
    fig: Figure,
    ax: Axes,
    plot_size: tuple[float, float],
) -> None:
    """Resize the figure so the axes area matches *plot_size*.

    Call this **after** adding the legend.  The figure
    height grows to accommodate the legend while keeping
    the plot area at the requested size.

    Parameters
    ----------
    fig
        The figure to resize.
    ax
        The axes whose area should match *plot_size*.
    plot_size
        Desired ``(width, height)`` of the axes area in
        inches.
    """
    fig.canvas.draw()  # type: ignore[reportUnknownMemberType]
    renderer = fig.canvas.get_renderer()  # type: ignore[reportUnknownMemberType]
    ax_bbox = ax.get_tightbbox(renderer)  # type: ignore[reportUnknownArgumentType]
    fig_bbox = fig.get_tightbbox(renderer)  # type: ignore[reportUnknownArgumentType]
    if ax_bbox is None or fig_bbox is None:  # type: ignore[reportUnnecessaryComparison]
        return
    fig_w, fig_h = fig.get_size_inches()
    ax_w_in = ax_bbox.width / fig.dpi
    ax_h_in = ax_bbox.height / fig.dpi
    if ax_w_in <= 0 or ax_h_in <= 0:
        return
    new_w = fig_w * (plot_size[0] / ax_w_in)
    new_h = fig_h * (plot_size[1] / ax_h_in)
    fig.set_size_inches(new_w, new_h)


def auto_ncol(
    ax: Axes,
    labels: list[str],
    available_width_px: float | None = None,
) -> int:
    """Choose the maximum legend ncol that fits the axes.

    Measures legend geometry from ``rcParams`` (``legend.fontsize``,
    ``legend.handlelength``, ``legend.handletextpad``,
    ``legend.columnspacing``) so the result tracks DPI and font size,
    rather than a hard-coded handle-padding constant.

    Pass ``available_width_px`` when the legend will live in
    ``fig.legend`` (figure-wide space) instead of ``ax.legend``;
    defaults to the axes width.
    """
    fig = ax.get_figure()
    if fig is None:
        return len(labels)
    fig.canvas.draw()  # type: ignore[reportUnknownMemberType]
    renderer = fig.canvas.get_renderer()  # type: ignore[reportUnknownMemberType]
    if available_width_px is None:
        available_width_px = ax.get_window_extent(renderer).width  # type: ignore[reportUnknownArgumentType]

    # rcParams['legend.fontsize'] may be a relative string ("medium",
    # "small", ...); FontProperties resolves it to points.
    fontsize_pt: float = FontProperties(
        size=plt.rcParams["legend.fontsize"]
    ).get_size_in_points()
    fs_px: float = fontsize_pt * fig.dpi / 72.0
    handle_px: float = float(plt.rcParams["legend.handlelength"]) * fs_px
    pad_px: float = float(plt.rcParams["legend.handletextpad"]) * fs_px
    col_pad_px: float = float(plt.rcParams["legend.columnspacing"]) * fs_px

    max_label_px = 0.0
    for label in labels:
        t = ax.text(  # type: ignore[reportUnknownMemberType]
            0, 0, label
        )
        bbox = t.get_window_extent(renderer)  # type: ignore[reportUnknownArgumentType]
        max_label_px = max(max_label_px, bbox.width)
        t.remove()

    per_col = handle_px + pad_px + max_label_px
    if per_col <= 0:
        return len(labels)

    for ncol in range(len(labels), 0, -1):
        if ncol * per_col + (ncol - 1) * col_pad_px <= available_width_px:
            return ncol
    return 1


def annotate_last_values(
    ax: Axes,
    plot_data: pd.DataFrame,
    *,
    decimals: int,
    units: str,
    labels: dict[str, str] | None = None,
    series_styles: dict[str, dict[str, Any]] | None = None,
    annotate_color: str | None = None,
) -> None:
    """Label the last non-NaN value of each column on the right.

    ``plot_data.columns`` and ``series_styles`` keys must be
    canonical series IDs.  ``labels`` maps each ID to the
    Matplotlib line label used when the axes were drawn; if
    omitted, the ID itself is used as the line label.

    Colour priority (highest first): ``annotate_color``
    (global override), ``series_styles[col]['color']``,
    the Matplotlib line colour.

    Labels are packed vertically in display space so that
    series ending at nearly the same value do not overlap.
    The x-axis limit is extended by the widest label so
    the text is not clipped by the axes frame.
    """
    fig = ax.get_figure()
    if fig is None:
        return
    styles = series_styles or {}
    label_map = labels or {}

    lines_by_label = {str(line.get_label()): line for line in ax.lines}
    entries: list[tuple[Any, float, str, Any]] = []
    for col in plot_data.columns:
        col_series: pd.Series[float] = plot_data[col].dropna()
        if col_series.empty:
            continue
        last_date = col_series.index[-1]
        last_val = float(col_series.iloc[-1])
        if annotate_color is not None:
            color: Any = annotate_color
        else:
            override = styles.get(col, {}).get("color")
            if override is not None:
                color = override
            else:
                line = lines_by_label.get(label_map.get(col, col))
                color = line.get_color() if line is not None else "black"
        entries.append((last_date, last_val, col, color))

    if not entries:
        return

    fig.canvas.draw()  # type: ignore[reportUnknownMemberType]
    renderer = fig.canvas.get_renderer()  # type: ignore[reportUnknownMemberType]
    trans = ax.transData

    sample = ax.text(  # type: ignore[reportUnknownMemberType]
        0, 0, "0"
    )
    text_height = (
        sample.get_window_extent(renderer).height  # type: ignore[reportUnknownArgumentType]
        * 1.15
    )
    sample.remove()

    entries.sort(key=lambda e: e[1])
    placements: list[float] = []
    prev_y = -float("inf")
    for _, val, _, _ in entries:
        y_display: float = trans.transform((0, val))[1]  # type: ignore[reportUnknownArgumentType]
        if y_display - prev_y < text_height:
            y_display = prev_y + text_height
        placements.append(y_display)
        prev_y = y_display

    max_label_width = 0.0
    for (date, val, _, color), packed_y in zip(entries, placements):
        orig_y: float = trans.transform((0, val))[1]  # type: ignore[reportUnknownArgumentType]
        dy_pts = (packed_y - orig_y) * 72.0 / fig.dpi
        text = format_annotation(val, decimals, units)
        t = ax.annotate(  # type: ignore[reportUnknownMemberType]
            text,
            xy=(date, val),
            xytext=(5, dy_pts),
            textcoords="offset points",
            color=color,
            va="center",
            ha="left",
        )
        width = t.get_window_extent(renderer).width  # type: ignore[reportUnknownArgumentType]
        max_label_width = max(max_label_width, width)

    inv = trans.inverted()
    x0: float = inv.transform((0, 0))[0]  # type: ignore[reportUnknownArgumentType]
    x1: float = inv.transform((max_label_width + 10, 0))[0]  # type: ignore[reportUnknownArgumentType]
    xmin, xmax = ax.get_xlim()
    ax.set_xlim(xmin, xmax + (x1 - x0))


def draw_vlines(ax: Axes, vlines: list[dict[str, Any]]) -> None:
    """Draw labelled vertical event markers on *ax*.

    Each entry must provide ``x`` (date-like). Optional keys
    (``label``, ``color``, ``linestyle``, ``linewidth``, ...) are
    forwarded to ``ax.axvline``. ``linestyle`` defaults to
    ``"dashed"`` so markers are visually distinct from data lines.
    """
    for vline in vlines:
        kwargs: dict[str, Any] = dict(vline)
        x_raw: Any = kwargs.pop("x")
        # matplotlib's stub types axvline's x as float, but at runtime
        # it accepts any date-like recognised by the date converter.
        x_dt = cast(Any, pd.to_datetime(x_raw))  # type: ignore[reportUnknownMemberType]
        kwargs.setdefault("linestyle", "dashed")
        ax.axvline(  # type: ignore[reportUnknownMemberType]
            x=x_dt,
            **kwargs,
        )


def style_spines(
    ax: Axes,
    decimals: int,
    units: str,
    *,
    color: str,
    linewidth: float,
) -> None:
    ax.grid(  # type: ignore[reportUnknownMemberType]
        visible=True, axis="y"
    )
    for spine in ax.spines.values():
        spine.set_color(color)
        spine.set_linewidth(linewidth)
    ax.yaxis.tick_right()

    def _fmt_tick(y: float, _pos: int) -> str:
        return format_annotation(y, decimals, units)

    ax.yaxis.set_major_formatter(FuncFormatter(_fmt_tick))
    ax.set_xlabel(  # type: ignore[reportUnknownMemberType]
        ""
    )

    ax.tick_params(  # type: ignore[reportUnknownMemberType]
        which="minor", size=0, width=0
    )
    ax.tick_params(  # type: ignore[reportUnknownMemberType]
        axis="both", which="major"
    )
    for tick in ax.get_xticklines():
        tick.set_markeredgecolor(color)
    for tick in ax.get_yticklines():
        tick.set_markeredgecolor(color)


def export_legend(
    ax: Axes,
    out_path: Path,
    *,
    ncol: int = 5,
    dpi: int = 500,
) -> None:
    """Save the legend of *ax* as a standalone PNG.

    The plot's own legend is removed after export.
    """
    handles, labels = ax.get_legend_handles_labels()
    fig_leg = plt.figure(  # type: ignore[reportUnknownMemberType]
        figsize=(6, 0.5), dpi=dpi
    )
    fig_leg.legend(  # type: ignore[reportUnknownMemberType]
        handles,
        labels,
        loc="center",
        ncol=ncol,
    )
    fig_leg.savefig(  # type: ignore[reportUnknownMemberType]
        out_path, bbox_inches="tight"
    )
    plt.close(fig_leg)
    legend = ax.get_legend()
    if legend is not None:
        legend.remove()


def style_baseline(
    ax: Axes,
    reference: float = 0,
    **baseline_config: Any,
) -> None:
    """Draw a horizontal baseline at *reference*.

    Always uses ``axhline`` (with high zorder) so callers that
    later restyle the spines do not silently erase the baseline.
    """
    bottom_lim, top_lim = ax.get_ylim()
    ax.set_ylim(
        bottom=min(reference, bottom_lim),
        top=max(reference, top_lim),
    )
    baseline_config.setdefault("zorder", 2.5)
    ax.axhline(  # type: ignore[reportUnknownMemberType]
        y=reference, **baseline_config
    )


def plot_line_chart(
    out_name: Path,
    data: pd.DataFrame,
    *,
    base_100: bool,
    annotate: bool,
    fmt: dict[str, Any],
    **kwargs: Any,
) -> None:
    if base_100:
        data = data / data.iloc[0, :] * 100
    if fmt["units"] == "p.b.":
        data = data * 100
    fig: Figure = plt.figure(  # type: ignore[reportUnknownMemberType]
        **FIG_CONFIG
    )
    ax = fig.add_subplot()
    data.plot(ax=ax)
    if annotate:
        pass

    reference = 100 if base_100 else 0
    style_spines(ax, **fmt, **AX_CONFIG["spines"])
    style_baseline(ax, reference, **AX_CONFIG["baseline"])
    handles, label_strs = ax.get_legend_handles_labels()
    fig.legend(  # type: ignore[reportUnknownMemberType]
        handles,
        label_strs,
        loc="outside lower center",
        ncol=(
            kwargs["legend"]["ncol"]
            if kwargs.get("legend", None) is not None
            else LINE_PLOT_CONFIG["ncol"]
        ),
    )

    fig.savefig(  # type: ignore[reportUnknownMemberType]
        out_name
    )


def plot_line_charts(
    out_path: Path,
    data: pd.DataFrame,
    config_dicts: dict[str, Any],
) -> None:
    for name, config in config_dicts.items():
        start_date: pd.Timestamp = pd.Timestamp(config["start_date"])
        end_date_str: str | None = config["end_date"]
        end_date: pd.Timestamp = (
            data.index.max()
            if end_date_str is None
            else pd.Timestamp(end_date_str)
        )
        series: dict[str, str] = config["series"]
        trimmed_data: pd.DataFrame = data.loc[
            slice(start_date, end_date), series.keys()
        ]
        trimmed_data = trimmed_data.rename(columns=series)
        out_name: Path = out_path / f"{name}.png"
        plot_line_chart(out_name, trimmed_data, **config)


class Format:
    def __init__(self, units: str = "", decimals: int = 0) -> None:
        self.units = units
        self.decimals = decimals

    @classmethod
    def from_yaml(cls, loader: TemplateLoader, node: MappingNode) -> Self:
        loader.flatten_mapping(node)
        format_cfg: dict[str, Any] = loader.construct_mapping(  # type: ignore[assignment]
            node, deep=True
        )
        format_cfg.pop("id")
        return cls(**format_cfg)


class Legend:
    def __init__(
        self,
        ncol: int | None = None,
    ) -> None:
        self.ncol = ncol

    @classmethod
    def from_yaml(cls, loader: TemplateLoader, node: MappingNode) -> Self:
        legend_cfg: dict[str, Any] = loader.construct_mapping(  # type: ignore[assignment]
            node, deep=True
        )
        legend_cfg.pop("id")
        return cls(**legend_cfg)


# as more stuff is needed, seems wise to make a class
class LinePlot:
    def __init__(
        self,
        out_path: Path,
        data_path: Path | None = None,
        series: dict[str, str] | None = None,
        scale: float = 1,
        start_date: datetime.datetime | None = None,
        end_date: datetime.datetime | None = None,
        base_100: bool = False,
        base_100_date: datetime.datetime | str | None = None,
        annotate: bool = False,
        annotate_color: str | None = None,
        baseline: bool = False,
        fmt: Format | None = None,
        legend: Legend | None = None,
        data: pd.DataFrame | None = None,
        figsize: tuple[float, float] | None = None,
        series_styles: dict[str, dict[str, Any]] | None = None,
        plot_size: tuple[float, float] | None = None,
        vlines: list[dict[str, Any]] | None = None,
    ) -> None:

        if out_path.suffix != ".png":
            raise ValueError(f"The out file {out_path} should be a .png file")
        self.out_path = out_path

        if data is not None and data_path is not None:
            raise ValueError("Provide data or data_path, not both")
        if data is not None:
            self.data = data
        elif data_path is not None:
            if data_path.suffix != ".feather":
                raise ValueError(
                    f"The data file {data_path} must be a .feather file"
                )
            self.data = pd.read_feather(data_path)
        else:
            raise ValueError("Provide data or data_path")

        if series is None:
            raise ValueError("series is required")

        self.base_100 = base_100
        self.base_100_date = base_100_date
        self.annotate = annotate
        self.annotate_color = annotate_color
        self.fmt = fmt
        self.start_date = start_date
        self.end_date = end_date
        self.series = series
        self.legend = legend
        self.baseline = baseline
        self.scale = scale
        self.figsize = figsize
        self.series_styles = series_styles or {}
        self.plot_size = plot_size
        self.vlines = vlines or []

    @classmethod
    def from_yaml(cls, loader: TemplateLoader, node: MappingNode) -> Self:
        line_plot_cfg: dict[str, Any] = loader.construct_mapping(  # type: ignore[assignment]
            node, deep=True
        )
        line_plot_cfg.pop("id")
        line_plot_cfg["out_path"] = Path(line_plot_cfg["out_path"])
        line_plot_cfg["data_path"] = Path(line_plot_cfg["data_path"])
        return cls(**line_plot_cfg)

    def build(self) -> tuple[Figure, Axes]:
        """Render the chart in memory without writing to disk.

        Returns the ``(Figure, Axes)`` so callers can post-process
        before saving (extra annotations, override DPI, embed in a
        composite figure). Pair with :meth:`save` to persist.
        """
        start_date: pd.Timestamp = (
            self.data.index.min()
            if self.start_date is None
            else pd.to_datetime(self.start_date)
        )

        end_date: pd.Timestamp = (
            self.data.index.max()
            if self.end_date is None
            else pd.to_datetime(self.end_date)
        )

        plot_data: pd.DataFrame = self.data.loc[
            slice(start_date, end_date), self.series.keys()
        ]

        plot_data = plot_data * self.scale

        if self.base_100:
            if self.base_100_date is None:
                anchor: pd.Series[float] = plot_data.iloc[0, :]
            else:
                anchor_ts: pd.Timestamp = pd.to_datetime(self.base_100_date)
                idx_pos: int = self.data.index.get_indexer(
                    pd.Index([anchor_ts]), method="nearest"
                )[0]
                anchor = (
                    self.data.iloc[idx_pos, :].loc[list(self.series.keys())]
                    * self.scale
                )
            plot_data = plot_data / anchor * 100

        fig_kw = dict(FIG_CONFIG)
        if self.figsize is not None:
            fig_kw["figsize"] = self.figsize
        fig: Figure = plt.figure(  # type: ignore[reportUnknownMemberType]
            **fig_kw
        )
        ax = fig.add_subplot()
        styles = self.series_styles
        for col in plot_data.columns:
            style = styles.get(col, {}) if styles else {}
            plot_data[col].plot(ax=ax, label=self.series[col], **style)

        if self.vlines:
            draw_vlines(ax, self.vlines)

        assert self.fmt is not None
        if self.annotate:
            annotate_last_values(
                ax,
                plot_data,
                decimals=self.fmt.decimals,
                units=self.fmt.units,
                labels=self.series,
                series_styles=self.series_styles,
                annotate_color=self.annotate_color,
            )

        style_spines(  # maybe make this function accept a Format object
            ax,
            decimals=self.fmt.decimals,
            units=self.fmt.units,
            **AX_CONFIG["spines"],
        )
        if self.baseline:
            reference = 100 if self.base_100 else 0
            style_baseline(ax, reference, **AX_CONFIG["baseline"])

        if self.legend is not None:
            labels = [self.series[c] for c in plot_data.columns]
            handles, label_strs = ax.get_legend_handles_labels()
            fig_width_px: float = fig.get_size_inches()[0] * fig.dpi
            ncol = (
                self.legend.ncol
                if self.legend.ncol is not None
                else auto_ncol(ax, labels, available_width_px=fig_width_px)
            )
            fig.legend(  # type: ignore[reportUnknownMemberType]
                handles,
                label_strs,
                loc="outside lower center",
                ncol=ncol,
            )

        if self.plot_size is not None:
            adjust_figure_for_plot_size(fig, ax, self.plot_size)

        return fig, ax

    def save(
        self,
        fig: Figure,
        *,
        path: Path | None = None,
        dpi: int | None = None,
    ) -> Path:
        """Persist *fig* as a PNG. Returns the path written.

        Defaults to ``self.out_path``; pass ``path`` to redirect or
        ``dpi`` to override the figure DPI for the saved file
        (useful when embedding in Word at fixed widths, where the
        default 500 dpi balloons file sizes).
        """
        target: Path = path if path is not None else self.out_path
        save_kwargs: dict[str, Any] = {}
        if dpi is not None:
            save_kwargs["dpi"] = dpi
        fig.savefig(  # type: ignore[reportUnknownMemberType]
            target, **save_kwargs
        )
        return target

    def plot(self) -> Axes:
        """Build the chart and persist it to ``self.out_path``.

        Kept for backwards compatibility; new callers should prefer
        :meth:`build` + :meth:`save` for finer control.
        """
        fig, ax = self.build()
        self.save(fig)
        return ax
