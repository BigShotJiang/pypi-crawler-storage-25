from __future__ import annotations

from math import floor
from pathlib import Path
from typing import Any, Callable

import pandas as pd

from tesorotools.dependencies.resolution import collect_series
from tesorotools.offsets.outliers import flag_outliers
from tesorotools.utils.matplotlib import format_annotation, is_zero

# this file is by far the worst and most spaghettified, must be rewritten

# to global config
GOOD: str = "00c800"
BAD: str = "c80000"
THRESHOLD: float = 1
SHADE_LEVELS: int = 2


def _shade_intensity(
    ratio: float,
    shade_levels: int = 2,
    continuous: bool = False,
) -> str:
    # intensity may vary from 150 (highest) to 255 (lowest), a grand difference of 105
    # there are SHADE_LEVELS levels, so increments will be of 105/SHADE_LEVELS
    corrected_ratio: float = min(ratio, shade_levels)
    corrected_ratio = (
        floor(corrected_ratio) if not continuous else corrected_ratio
    )
    increment: float = (corrected_ratio - 1) * (105 / shade_levels)
    intensity: float = 255 - increment
    intensity_hex: str = f"{int(intensity):x}"
    return intensity_hex


def make_shade_fn(
    levels: int = 2,
    *,
    cap: float | None = None,
    continuous: bool = False,
) -> Callable[[float], str]:
    """Build a closure that maps an outlier ratio to a hex intensity.

    ``levels`` controls how many discrete steps the intensity has
    between 255 (lightest) and 150 (darkest); ``cap`` is the ratio at
    which intensity saturates (defaults to ``levels``); ``continuous``
    skips the discretisation step and yields a smooth gradient.

    The returned callable is suitable as a per-cell shade resolver in
    a custom rendering pipeline that does not go through the
    ``_generate_column`` cube path.
    """
    cap_value: float = float(levels if cap is None else cap)

    def _shade(ratio: float) -> str:
        corrected: float = min(ratio, cap_value)
        if not continuous:
            corrected = float(floor(corrected))
        increment: float = (corrected - 1) * (105 / levels)
        intensity: float = 255 - increment
        return f"{int(intensity):x}"

    return _shade


def _generate_column(
    column_data: pd.Series[Any],
    column_cfg: dict[str, Any],
    outliers_flags: pd.Series[Any] | None = None,
) -> tuple[pd.Series[Any], pd.Series[Any], pd.Series[Any]]:
    # TODO: factor out
    # data
    if column_cfg["show_units_in_title"]:
        column_data.name = f"{column_cfg['name']} ({column_cfg['unit']})"
    else:
        column_data.name = column_cfg["name"]
    column_cfg["formatted_name"] = column_data.name

    unit = (
        column_cfg["unit"]
        if column_cfg["show_units_in_cell"] and column_cfg["unit"] is not None
        else ""
    )
    scaled_data: pd.Series[Any] = column_data * column_cfg["scale"]

    def _fmt(x: float) -> str:
        return format_annotation(x, decimals=column_cfg["decimals"], units=unit)

    formatted_data: pd.Series[Any] = scaled_data.apply(_fmt)

    def _check_zero(x: float) -> bool:
        return is_zero(x, decimals=column_cfg["decimals"])

    zeros: pd.Series[Any] = scaled_data.apply(_check_zero)
    positives: pd.Series[Any] = scaled_data > 0
    negatives: pd.Series[Any] = scaled_data < 0

    # colors
    colors_cfg: bool = column_cfg["colors"]
    color_data: pd.Series[Any] = pd.Series(
        index=formatted_data.index,
        name=column_data.name,
        dtype=str,
    )
    positive_good: bool = False
    if colors_cfg:
        positive_good = column_cfg["positive_good"]
        color_data[positives] = GOOD if positive_good else BAD
        color_data.loc[negatives] = BAD if positive_good else GOOD
        color_data.loc[zeros.values] = pd.NA  # type: ignore[index]

    # shades
    shade_data: pd.Series[Any] = pd.Series(
        index=formatted_data.index,
        name=column_data.name,
        dtype=str,
    )
    if outliers_flags is not None:
        thresholds: pd.Series[Any] = abs(outliers_flags / THRESHOLD)

        def _shade(x: float) -> str:
            return _shade_intensity(x, SHADE_LEVELS)

        intensities: pd.Series[Any] = thresholds.apply(_shade)

        def _color_pos(x: str) -> str:
            return f"00{x}00" if positive_good else f"{x}0000"

        def _color_neg(x: str) -> str:
            return f"{x}0000" if positive_good else f"00{x}00"

        shade_data[(thresholds >= 1) & (outliers_flags > 0)] = intensities[
            (thresholds >= 1) & (outliers_flags > 0)
        ].apply(_color_pos)
        shade_data[(thresholds >= 1) & (outliers_flags < 0)] = intensities[
            (thresholds >= 1) & (outliers_flags < 0)
        ].apply(_color_neg)

    return formatted_data, color_data, shade_data


def _generate_block(
    block_data: pd.DataFrame, block_cfg: dict[str, Any]
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    columns: dict[str, Any] = block_cfg["columns"]
    formatted_columns: list[pd.Series[Any]] = []
    color_columns: list[pd.Series[Any]] = []
    shade_columns: list[pd.Series[Any]] = []
    sort_idx: pd.Index[Any] | None = None
    for column_name, column_cfg in columns.items():
        last_date: pd.Timestamp = block_data.index.get_level_values(
            level=0
        ).max()
        block_data = block_data.rename(columns=block_cfg["series"])
        offset: str = column_cfg["offset"]
        difference: str = column_cfg["difference"]
        stat: str = column_cfg["stat"]
        outliers: bool = column_cfg["outliers"]

        stat_data: pd.DataFrame = block_data.loc[
            (last_date, offset, difference, slice(None)), :
        ]
        stat_data.index = stat_data.index.get_level_values(level=-1)

        outliers_flags: pd.Series[Any] | None = None
        if outliers:
            outliers_flags = flag_outliers(stat_data.T)

        column_data: pd.Series[Any] = stat_data.loc[stat, :]  # type: ignore[assignment]
        # sort capability
        sort: str | None = block_cfg.get("sort", None)
        if sort is not None and column_name == sort:
            column_data = column_data.sort_values(ascending=False)
            sort_idx = column_data.index
        formatted_column, color_column, shade_column = _generate_column(
            column_data, column_cfg, outliers_flags
        )
        formatted_columns.append(formatted_column)
        color_columns.append(color_column)
        shade_columns.append(shade_column)

    if sort_idx is not None:
        formatted_columns = [s.reindex(sort_idx) for s in formatted_columns]
        color_columns = [s.reindex(sort_idx) for s in color_columns]
        shade_columns = [s.reindex(sort_idx) for s in shade_columns]

    formatted_block: pd.DataFrame = pd.concat(formatted_columns, axis=1)
    color_block: pd.DataFrame = pd.concat(color_columns, axis=1)
    shade_block: pd.DataFrame = pd.concat(shade_columns, axis=1)

    formatted_block.columns.name = block_cfg["title"]
    color_block.columns.name = block_cfg["title"]
    shade_block.columns.name = block_cfg["title"]
    return formatted_block, color_block, shade_block


def generate_table(
    table_data: pd.DataFrame, table_cfg: dict[str, Any]
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    blocks: dict[str, dict[str, Any]] = table_cfg["blocks"]
    formatted_blocks: list[pd.DataFrame] = []
    color_blocks: list[pd.DataFrame] = []
    shade_blocks: list[pd.DataFrame] = []
    axis = 0 if table_cfg["axis"] == "vertical" else 1
    # sorting capabilities
    for _block_name, block_cfg in blocks.items():
        series_dict: dict[str, str] = block_cfg["series"]
        block_data: pd.DataFrame = table_data.loc[:, series_dict.keys()]
        formatted_block, color_block, shade_block = _generate_block(
            block_data, block_cfg
        )
        formatted_blocks.append(formatted_block)
        color_blocks.append(color_block)
        shade_blocks.append(shade_block)
    formatted_table: pd.DataFrame = pd.concat(
        formatted_blocks,
        axis=axis,
        keys=[
            formatted_block.columns.name for formatted_block in formatted_blocks
        ],
    )
    color_table: pd.DataFrame = pd.concat(
        color_blocks,
        axis=axis,
        keys=[
            formatted_block.columns.name for formatted_block in formatted_blocks
        ],
    )
    shade_table: pd.DataFrame = pd.concat(
        shade_blocks,
        axis=axis,
        keys=[
            formatted_block.columns.name for formatted_block in formatted_blocks
        ],
    )
    return formatted_table, color_table, shade_table


def generate_tables_from_flash(
    out_path: Path,
    flash: pd.DataFrame,
    config_dicts: dict[str, dict[str, Any]],
) -> None:
    for table_name, table_cfg in config_dicts.items():
        series: list[str] = list(collect_series(table_cfg))
        table_data: pd.DataFrame = flash.loc[:, series]
        formatted_table, color_table, shade_table = generate_table(
            table_data, table_cfg
        )
        formatted_table.to_feather(out_path / f"{table_name}.feather")
        color_table.to_feather(out_path / f"{table_name}_color.feather")
        shade_table.to_feather(out_path / f"{table_name}_shade.feather")
