"""Diagnostic utilities for pipeline configuration.

Helps identify unused series in a catalog — series that
are downloaded but never appear as a dependency of any
rule or in any chart configuration.
"""

from __future__ import annotations

from typing import Any

from tesorotools.dependencies.resolution import (
    collect_document_series,
)
from tesorotools.pipeline.engine import TransformationRule


def unused_series(
    catalog: dict[str, Any],
    rules: list[TransformationRule],
    charts: dict[str, Any] | list[dict[str, Any]] | None = None,
) -> set[str]:
    """Find catalog series not referenced by rules or charts.

    Parameters
    ----------
    catalog
        Instrument catalog (canonical_id -> metadata).
    rules
        All transformation rules for the project.
    charts
        Chart config dict(s).  Can be a single dict or a
        list of dicts (barh, line, type_curve, tables).

    Returns
    -------
    set[str]
        Canonical IDs present in the catalog but not used
        as a dependency of any rule nor referenced in any
        chart config.
    """
    all_ids = set(catalog.keys())

    used: set[str] = set()
    for rule in rules:
        used.add(rule.output_name)
        used.update(rule.dependencies)

    if charts is not None:
        chart_list = charts if isinstance(charts, list) else [charts]
        for name in collect_document_series(chart_list):
            used.add(name)

    return all_ids - used
