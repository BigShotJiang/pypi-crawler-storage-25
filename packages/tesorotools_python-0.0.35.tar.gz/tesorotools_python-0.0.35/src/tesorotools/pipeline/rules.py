"""Built-in transformation rule factories.

Each factory function takes an output name, its source
column(s), and optional parameters, and returns a single
``TransformationRule``.

Projects can register additional factories in the
``FACTORIES`` dict to make them available from YAML config.

NaN-aware operations
--------------------
``yoy_rule`` and ``rolling_sum_rule`` drop NaN before
calling ``shift()`` / ``rolling()`` so that the window
counts real observations, not DataFrame rows.  This is
essential when monthly and quarterly series coexist in
the same DataFrame.
"""

from __future__ import annotations

from collections.abc import Callable

import pandas as pd

from tesorotools.pipeline.engine import TransformationRule


def scale_rule(output: str, source: str, divisor: float) -> TransformationRule:
    """Divide a column by a constant."""
    return TransformationRule(
        output_name=output,
        dependencies=[source],
        compute=lambda df, s=source, d=divisor: df[s] / d,
    )


def sum_rule(output: str, sources: list[str]) -> TransformationRule:
    """Sum multiple columns (NaN-safe with min_count=1)."""
    return TransformationRule(
        output_name=output,
        dependencies=list(sources),
        compute=lambda df, cols=list(sources): df[cols].sum(
            axis=1, min_count=1
        ),
    )


def mean_rule(output: str, sources: list[str]) -> TransformationRule:
    """Row-wise arithmetic mean of multiple columns.

    Equivalent to ``=AVERAGE(...)`` in Excel: NaN components
    are skipped (not treated as zero), so a row with any
    non-NaN value yields the mean of whatever is present.
    A row of all NaN yields NaN.
    """
    return TransformationRule(
        output_name=output,
        dependencies=list(sources),
        compute=lambda df, cols=list(sources): df[cols].mean(axis=1),
    )


def ratio_rule(
    output: str, numerator: str, denominator: str
) -> TransformationRule:
    """Divide one column by another."""
    return TransformationRule(
        output_name=output,
        dependencies=[numerator, denominator],
        compute=lambda df, n=numerator, d=denominator: df[n] / df[d],
    )


def difference_rule(
    output: str,
    dependencies: list[str],
) -> TransformationRule:
    """Subtract the second column from the first."""
    if len(dependencies) != 2:
        raise ValueError(
            f"difference requires exactly 2 dependencies,"
            f" got {len(dependencies)}"
        )
    target, reference = dependencies
    return TransformationRule(
        output_name=output,
        dependencies=[target, reference],
        compute=lambda df, t=target, r=reference: df[t] - df[r],
    )


def inverse_rule(
    output: str,
    dependencies: list[str],
) -> TransformationRule:
    """Compute 1 / source."""
    if len(dependencies) != 1:
        raise ValueError(
            f"inverse requires exactly 1 dependency, got {len(dependencies)}"
        )
    source = dependencies[0]
    return TransformationRule(
        output_name=output,
        dependencies=[source],
        compute=lambda df, s=source: 1 / df[s],
    )


def pct_change_rule(
    output: str, source: str, periods: int = 12
) -> TransformationRule:
    """Periodic percentage change: source_t / source_{t-N} - 1.

    Drops NaN before shifting so that *periods* counts
    actual observations, not DataFrame rows.
    """

    def _compute(
        df: pd.DataFrame,
        s: str = source,
        p: int = periods,
    ) -> pd.Series[float]:
        clean: pd.Series[float] = df[s].dropna()
        return clean / clean.shift(p) - 1

    return TransformationRule(
        output_name=output,
        dependencies=[source],
        compute=_compute,
    )


def rolling_sum_rule(
    output: str, source: str, window: int = 4
) -> TransformationRule:
    """Rolling sum (e.g. 4-quarter annualization).

    Drops NaN before rolling so that *window* counts
    actual observations.
    """

    def _compute(
        df: pd.DataFrame,
        s: str = source,
        w: int = window,
    ) -> pd.Series[float]:
        clean: pd.Series[float] = df[s].dropna()
        return clean.rolling(window=w, min_periods=w).sum()

    return TransformationRule(
        output_name=output,
        dependencies=[source],
        compute=_compute,
    )


def delta_rule(
    output: str, source: str, periods: int = 1
) -> TransformationRule:
    """Level change: source_t - source_{t-periods}.

    Drops NaN before shifting (mixed-frequency safe).
    """

    def _compute(
        df: pd.DataFrame,
        s: str = source,
        p: int = periods,
    ) -> pd.Series[float]:
        clean: pd.Series[float] = df[s].dropna()
        return clean - clean.shift(p)

    return TransformationRule(
        output_name=output,
        dependencies=[source],
        compute=_compute,
    )


def cumsum_rule(output: str, source: str) -> TransformationRule:
    """Cumulative sum of a column.

    Drops NaN before cumsum (mixed-frequency safe).
    """

    def _compute(df: pd.DataFrame, s: str = source) -> pd.Series[float]:
        clean: pd.Series[float] = df[s].dropna()
        return clean.cumsum()

    return TransformationRule(
        output_name=output,
        dependencies=[source],
        compute=_compute,
    )


def resample_rule(
    output: str,
    source: str,
    freq: str,
    agg: str = "mean",
) -> TransformationRule:
    """Resample a series to *freq* with aggregator *agg*.

    NaN-aware: drops NaN before ``resample`` so interior
    gaps in the input do not poison the aggregator.
    """

    def _compute(
        df: pd.DataFrame,
        s: str = source,
        f: str = freq,
        a: str = agg,
    ) -> pd.Series[float]:
        clean: pd.Series[float] = df[s].dropna()
        return clean.resample(f).agg(a)  # type: ignore[reportUnknownMemberType]

    return TransformationRule(
        output_name=output,
        dependencies=[source],
        compute=_compute,
    )


def weighted_average_rule(
    output: str,
    values: list[str],
    weights: list[str],
) -> TransformationRule:
    """Weighted average: ``sum(v_i * w_i) / sum(w_i)``.

    NaN components contribute 0 to both numerator and
    denominator (so they do not propagate NaN across the
    whole row).  A denominator of 0 yields NaN (avoids
    ``inf``).
    """
    if len(values) != len(weights):
        raise ValueError(
            f"weighted_average requires len(values) == len(weights),"
            f" got {len(values)} and {len(weights)}"
        )
    deps = list(values) + list(weights)

    def _compute(
        df: pd.DataFrame,
        vs: list[str] = list(values),
        ws: list[str] = list(weights),
    ) -> pd.Series[float]:
        zero = pd.Series(0.0, index=df.index)
        num: pd.Series[float] = sum(
            (df[v].fillna(0) * df[w].fillna(0) for v, w in zip(vs, ws)),
            start=zero,
        )
        den: pd.Series[float] = sum(
            (df[w].fillna(0) for w in ws),
            start=zero,
        )
        return num / den.replace(0, float("nan"))

    return TransformationRule(
        output_name=output,
        dependencies=deps,
        compute=_compute,
    )


def index_rule(
    output: str,
    source: str,
    reference_date: str | pd.Timestamp,
    base: float = 100.0,
) -> TransformationRule:
    """Rebase to *base* at *reference_date*.

    Returns an empty Series if the reference date is not
    present in the source's index after dropping NaN, or
    if the reference value is zero.  Keeps the pipeline
    from blowing up on partial data.
    """
    ref = pd.Timestamp(reference_date)

    def _compute(
        df: pd.DataFrame,
        s: str = source,
        r: pd.Timestamp = ref,
        b: float = base,
    ) -> pd.Series[float]:
        clean: pd.Series[float] = df[s].dropna()
        if r not in clean.index:
            return pd.Series(dtype="float64")
        ref_val = float(clean.loc[r])
        if ref_val == 0:
            return pd.Series(dtype="float64")
        return clean / ref_val * b

    return TransformationRule(
        output_name=output,
        dependencies=[source],
        compute=_compute,
    )


def forward_fill_rule(
    output: str,
    source: str,
    freq: str = "MS",
    limit: int | None = None,
    extend: int = 0,
) -> TransformationRule:
    """Reindex to a regular *freq* grid and forward-fill.

    Decouples ``limit`` from the host DataFrame's own
    frequency — useful when a quarterly series has to be
    propagated to the months of each quarter inside a
    daily/monthly DataFrame.  ``extend`` adds that many
    extra *freq* steps after the last real observation.
    """

    def _compute(
        df: pd.DataFrame,
        s: str = source,
        f: str = freq,
        lim: int | None = limit,
        ext: int = extend,
    ) -> pd.Series[float]:
        clean: pd.Series[float] = df[s].dropna()
        if clean.empty:
            return pd.Series(dtype="float64")
        start = clean.index.min()
        end = clean.index.max()
        if ext > 0:
            end = end + pd.tseries.frequencies.to_offset(f) * ext  # type: ignore[reportOperatorIssue]
        grid = pd.date_range(start=start, end=end, freq=f)
        return clean.reindex(grid).ffill(limit=lim)

    return TransformationRule(
        output_name=output,
        dependencies=[source],
        compute=_compute,
    )


#: Registry of factory functions, keyed by YAML function name.
#: Projects can add custom factories at runtime.
FACTORIES: dict[
    str,
    Callable[..., TransformationRule],
] = {
    "scale": scale_rule,
    "sum": sum_rule,
    "mean": mean_rule,
    "ratio": ratio_rule,
    "difference": difference_rule,
    "inverse": inverse_rule,
    "pct_change": pct_change_rule,
    "rolling_sum": rolling_sum_rule,
    "delta": delta_rule,
    "cumsum": cumsum_rule,
    "resample": resample_rule,
    "weighted_average": weighted_average_rule,
    "index": index_rule,
    "forward_fill": forward_fill_rule,
}
