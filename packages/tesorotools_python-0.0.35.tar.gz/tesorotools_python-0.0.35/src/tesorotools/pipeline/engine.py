"""Transformation engine.

Provides a generic rule-based transformation system for
DataFrames.  Each rule declares its output column, the
columns it depends on, and a pure function that computes
the output from the DataFrame.

Rules are applied in order.  Each rule may depend on
columns produced by earlier rules, so ordering matters.
Use the DAG resolver in ``tesorotools.dependencies`` to
compute the correct order automatically.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass

import pandas as pd

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class TransformationRule:
    """A single transformation rule.

    Attributes
    ----------
    output_name
        Canonical ID of the derived series.  Will become
        a new column in the DataFrame.
    dependencies
        Column names that must exist in the DataFrame for
        this rule to run.  If any is missing, the rule is
        skipped with a warning.
    compute
        Pure function: receives the full DataFrame, returns
        a Series with the computed values.
    """

    output_name: str
    dependencies: list[str]
    compute: Callable[[pd.DataFrame], pd.Series[float]]


def apply_transformations(
    df: pd.DataFrame,
    rules: list[TransformationRule],
) -> pd.DataFrame:
    """Apply rules sequentially to a DataFrame.

    New columns are accumulated in a dict and merged into
    *result* only when a later rule reads from them (or at
    the end).  This avoids per-rule fragmentation of the
    DataFrame and pandas' ``PerformanceWarning`` when many
    rules (100+) are applied.

    Parameters
    ----------
    df
        Input DataFrame (not modified).
    rules
        Ordered list of rules to apply.

    Returns
    -------
    pd.DataFrame
        Copy of *df* with new columns added by the rules.
    """
    result = df.copy()
    pending: dict[str, pd.Series[float]] = {}
    for rule in rules:
        available = set(result.columns) | set(pending)
        missing = [d for d in rule.dependencies if d not in available]
        if missing:
            logger.warning(
                "Skipping %s: missing dependencies %s",
                rule.output_name,
                missing,
            )
            continue
        # rule.compute() reads from result; flush pending
        # into result if this rule needs any pending column.
        if any(d in pending for d in rule.dependencies):
            result = pd.concat(
                [
                    result,
                    pd.DataFrame(pending, index=result.index),
                ],
                axis=1,
            )
            pending = {}
        pending[rule.output_name] = rule.compute(result)
    if pending:
        result = pd.concat(
            [result, pd.DataFrame(pending, index=result.index)],
            axis=1,
        )
    return result
