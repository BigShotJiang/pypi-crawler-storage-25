---
name: vr-inspect-resources
description: List and inspect VoiceRun resources — agents, environments, functions, secrets, phone numbers, assignments, telephony providers, and templates.
---

# Inspect VoiceRun Resources

You are helping the user list and inspect their VoiceRun resources. The CLI provides two command groups: `vr get` for listing resources and `vr describe` for detailed views. Follow this guide:

## Listing Resources (`vr get`)

### Agents

List all agents in your account:

```bash
vr get agents
```

Displays: agent name, ID, description, voice, and transport.

### Functions

List all function versions for an agent:

```bash
vr get functions <AGENT>
```

`<AGENT>` can be a name or UUID.

```bash
vr get functions my-agent
vr get functions 550e8400-e29b-41d4-a716-446655440000
```

### Environments

List all environments for an agent:

```bash
vr get environments <AGENT>
```

### Secrets

List secrets. Shows organization-level secrets by default:

```bash
# Organization secrets only
vr get secrets

# Include agent-level secrets
vr get secrets --agent my-agent
```

### Phone Numbers

List all organization phone numbers:

```bash
vr get phonenumbers
```

Displays: phone number, friendly name, ID, area code, and country code.

### Telephony Providers

List organization telephony providers:

```bash
vr get telephony
```

Displays: provider name, ID, and provider type (twilio, telnyx, etc.).

### Assignments

List phone number assignments for an agent:

```bash
vr get assignments <AGENT>
```

Displays: phone number ID, environment ID, assignment ID, and creation timestamp.

### Templates

List available agent templates:

```bash
vr get templates
```

Displays: template name, ID, category, description, and public/private status.

## Describing Resources (`vr describe`)

### Agent details

```bash
vr describe agent <NAME_OR_ID>
```

Shows: ID, name, description, voice & transport configuration, organization details, debug & tracing settings, timestamps.

### Function details

```bash
vr describe function <AGENT> <NAME_OR_ID>
```

Shows: ID, name, display name, code language, strategy, multifile flag, code preview, test data, timestamps.

### Environment details

```bash
vr describe environment <AGENT> <NAME_OR_ID>
```

Shows: ID, name, phone number, debug flag, STT configuration (model, language, endpointing), recording settings, error handling (fallback speech, voice, max retries), audio processing settings, VAD mode, timestamps.

This is particularly useful for understanding how an environment is configured:
- **STT model** — Which speech-to-text model is active
- **Recording** — Whether calls are being recorded
- **Error fallback** — What happens when the agent errors
- **VAD mode** — Voice activity detection settings

### Secret details

```bash
vr describe secret <NAME_OR_ID>

# Search agent secrets too
vr describe secret MY_API_KEY --agent my-agent
```

Shows: secret name, ID, timestamps. (Value is not displayed for security.)

### Phone number details

```bash
vr describe phonenumber <ID>
```

Shows: phone number, friendly name, area code, country code, telephony provider ID, timestamps.

### Telephony provider details

```bash
vr describe telephony <NAME_OR_ID>
```

Shows: provider name, type, ID, organization ID, timestamps.

### Assignment details

```bash
vr describe assignment <AGENT> <ASSIGNMENT_ID>
```

Shows: assignment ID, environment ID, phone number ID, timestamps.

## Common Inspection Workflows

### Check agent deployment status

```bash
# List agents
vr get agents

# See environments for an agent
vr get environments my-agent

# Check environment configuration
vr describe environment my-agent production

# See which function version is deployed
vr get functions my-agent
```

### Audit phone number setup

```bash
# List all phone numbers
vr get phonenumbers

# Check assignments for an agent
vr get assignments my-agent

# Describe a specific assignment
vr describe assignment my-agent <ASSIGNMENT_ID>

# Check telephony provider
vr describe telephony <NAME_OR_ID>
```

### Review secrets

```bash
# List all secrets (org + agent)
vr get secrets --agent my-agent

# Describe a specific secret
vr describe secret OPENAI_API_KEY --agent my-agent
```

### Find unassigned phone numbers

Compare phone numbers with assignments to find available numbers:

```bash
# List all phone numbers
vr get phonenumbers

# List assignments for the agent
vr get assignments <AGENT>
```

A phone number is unassigned if its ID does not appear in any assignment.

### Explore available templates

```bash
# List templates
vr get templates

# Initialize from a template
vr init my-agent --template <TEMPLATE_NAME>
```

## Troubleshooting

- **"Agent not found"** — Verify the agent name with `vr get agents`. Names are case-sensitive.
- **"Environment not found"** — List environments with `vr get environments <AGENT>`.
- **Empty tables** — You may not have any resources of that type yet, or you may be in the wrong organization context. Check with `vr context current`.
- **"Authentication required"** — Run `vr signin`.

Help the user find the specific information they need by running the appropriate get/describe commands.
