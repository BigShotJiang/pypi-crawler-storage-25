---
name: vr-debug-session
description: Debug a voice agent session end-to-end. Collect session info, transcript, events, and trace data, reconstruct the conversation timeline, and identify issues like errors, high latency, interrupted turns, and failed tool calls.
---

# Debug a Voice Agent Session

You are helping the user investigate a voice agent session end-to-end: collect data, reconstruct the conversation timeline, identify what went wrong, and optionally propose a fix. **Follow every phase in order.** Each phase builds on the previous one.

## Phase 0: Inputs

Gather the required inputs before starting.

**Required:**
- Session ID (e.g., `ses_abc123`)

**Ask the user for:**
1. Agent handler repo path (local directory containing `handler.py`, `tools.py`, `prompts.py`) — needed only if you want to propose code fixes in Phase 4.

If the user says "skip" or does not have a handler repo, skip Phase 4 entirely.

## Phase 1: Data Collection

Pull all session data using the `vr` CLI. Run commands in parallel where possible.

### Step 1 — Session info

```bash
vr session info <SESSION_ID> --json
```

Extract the **agent ID**, status, start/end timestamps, and tags from the response. You need the agent ID for subsequent commands.

### Step 2 — Transcript, events, and trace

Run these in parallel once you have the agent ID:

```bash
# Full conversation transcript
vr session transcript <AGENT_ID> <SESSION_ID> --json

# Session events (start with limit 500)
vr session events <AGENT_ID> <SESSION_ID> --json --limit 500

# Span-level timing data
vr session trace <SESSION_ID> --json
```

### Step 3 — Page through events

If the events response indicates more results exist (total > returned count), page through them:

```bash
vr session events <AGENT_ID> <SESSION_ID> --json --limit 500 --page 2
vr session events <AGENT_ID> <SESSION_ID> --json --limit 500 --page 3
# ... continue until all events are collected
```

### Checkpoint

Before proceeding, confirm you have:
- Session info (agent ID, status, timestamps)
- Full transcript
- All events (paged through completely)
- Trace data

If any data is missing, note the gap and proceed with what you have.

## Phase 2: Reconstruction

Build a **chronological turn-by-turn timeline** by merging the transcript and events.

### For each turn, note:

| Field | Source |
|-------|--------|
| Turn number | Sequential counter |
| Timestamp | Transcript / event timestamps |
| Speaker | `user` or `agent` |
| Text | Transcript content |
| Tool calls & results | Events with type `tool_call`, `tool_result` |
| TTS events | Events with type `tts_start`, `tts_end` |
| Interrupted | `previous_turn_interrupted` flag or interruption events |
| Input allowed | `input_allowed` state changes |
| Latency | Time between user input end and agent response start |

### Flag anomalies

Mark any of the following with `[!]`:

- **Interrupted turns** — agent speech was cut off before completing
- **Missing tool calls** — agent referenced a tool result that has no matching call
- **Repeated tool failures** — same tool called 3+ times without success
- **High latency** — turn-taking time significantly above normal
- **Unexpected session end** — session ended without graceful closure
- **Empty agent responses** — agent turn with no text content
- **Duplicate questions** — agent asked the same question the user already answered
- **Stop/transfer events** — session ended or transferred unexpectedly

### Output

Present the timeline as a concise numbered list. Place `[!]` markers next to anomalies.

Example:

```
1. [00:00] user: "Hi, I'd like to book an appointment"
2. [00:02] agent: "Sure! What date works for you?" [tool: check_availability → success]
3. [00:05] user: "Tomorrow at 3pm"
4. [00:06] [!] agent: "What date works for you?" [DUPLICATE QUESTION — user already answered]
5. [00:10] [!] agent: "" [EMPTY RESPONSE] [latency: 4200ms — HIGH]
```

## Phase 3: Analysis

Using the timeline from Phase 2, identify the root cause.

### Issue pattern checklist

Check the timeline against these known patterns:

| Pattern | Indicators |
|---------|------------|
| Transfer not completing | Interrupted closing speech, no re-call event, session ends abruptly |
| Availability loop | Repeated time-slot rejections without escalation or fallback |
| Wrong question asked | Agent asks for data the user already provided |
| Language switch false positive | Agent switches language unexpectedly mid-conversation |
| FAQ detection miss | User asked a clear FAQ question, agent didn't recognize it |
| FAQ false positive | Agent triggered FAQ response on a non-FAQ utterance |
| Timeout / retry failure | Tool call timed out, agent retried incorrectly or not at all |
| Unexpected session end | Session ended without graceful goodbye or transfer |
| Tool call error | Tool returned an error the agent didn't handle |
| Repeated failures | Same operation attempted 3+ times without fallback |

### Classify the root cause

Choose exactly one:

| Classification | Meaning | Fix target |
|---------------|---------|------------|
| **Prompt issue** | Instructions unclear, missing, or conflicting | `prompts.py` in agent handler repo |
| **Handler/tools bug** | Logic error in handler or tool code | `handler.py` / `tools.py` in agent handler repo |
| **API failure** | External API returned an error or unexpected data | Note the endpoint and suggest investigation |
| **Expected behavior** | System worked as designed for the given inputs | No code fix — document the finding |

### Output

Summarize your findings:

1. **What happened** — 1-2 sentence summary of the issue
2. **Root cause** — classification + specific reason
3. **Evidence** — reference specific turn numbers from the timeline
4. **Confidence** — high / medium / low with brief reasoning

## Phase 4: Fix (optional)

**Skip this phase if:**
- The user did not provide a handler repo path
- The classification is "Expected behavior" or "API failure"

### Steps

1. **Read relevant code** based on the classification:
   - Prompt issue → read `prompts.py`
   - Handler/tools bug → read `handler.py` and/or `tools.py`

2. **Apply a minimal fix** that addresses the root cause. Do not refactor unrelated code.

3. **Commit** with a message following this format:
   ```
   fix: <description>

   Session: <session_id>
   Root cause: <classification>
   ```

4. **Push and create a PR** using `gh pr create` with:
   - Title: the fix description
   - Body: what happened, root cause, evidence (turn numbers), and the fix applied
