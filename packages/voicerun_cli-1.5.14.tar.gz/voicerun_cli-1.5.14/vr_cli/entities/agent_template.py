from ..utils.utils import is_uuid
from .base import BaseEntity, BaseRepository


class AgentTemplate(BaseEntity):
    def __init__(
        self,
        id: str = None,
        name: str = None,
        description: str = None,
        category: str = None,
        is_public: bool = False,
        variables: list = None,
        files: dict = None,
        code: str = None,
        organization_id: str = None,
        created_by: str = None,
        created_at: str = None,
        updated_at: str = None,
        deleted_at: str = None,
        **kwargs,
    ):
        super().__init__(id=id, created_at=created_at, updated_at=updated_at, deleted_at=deleted_at, **kwargs)
        self.name = name
        self.description = description
        self.category = category
        self.is_public = is_public
        self.variables = variables
        self.files = files
        self.code = code
        self.organization_id = organization_id
        self.created_by = created_by


class AgentTemplateRepository(BaseRepository):
    def __init__(self):
        super().__init__(
            name="agent_template",
            endpoint="/v1/agent-templates",
            entity_class=AgentTemplate,
        )

    def get_by_name_or_id(self, name_or_id: str) -> AgentTemplate:
        """Resolve a template by id or name, preferring the non-public match when both exist.

        The API now guarantees (name, organizationId) uniqueness among non-deleted
        templates, so within the caller's visible set there is at most one public
        and one org-private template that share a name. If both are visible (e.g.
        an org has a private template named the same as a public one), prefer the
        private one — it's the more specific match and is what a user typically
        means when scaffolding from their own org's templates.
        """
        if is_uuid(name_or_id):
            return self.get_by_id(name_or_id)

        matches = [entity for entity in self.get() if entity.name == name_or_id]
        if not matches:
            return None

        return next(
            (entity for entity in matches if not getattr(entity, "is_public", False)),
            matches[0],
        )
