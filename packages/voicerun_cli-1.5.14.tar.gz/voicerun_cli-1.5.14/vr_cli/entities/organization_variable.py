from .base import BaseEntity, BaseRepository


class OrganizationVariable(BaseEntity):
    def __init__(
        self,
        id: str = None,
        organization_id: str = None,
        name: str = None,
        value: str = None,
        masked: bool = None,
        created_at: str = None,
        updated_at: str = None,
        deleted_at: str = None,
        **kwargs,
    ):
        self.id = id
        self.organization_id = organization_id
        self.name = name
        self.value = value
        self.masked = masked
        self.created_at = created_at
        self.updated_at = updated_at
        self.deleted_at = deleted_at or None


class OrganizationVariableRepository(BaseRepository[OrganizationVariable]):
    def __init__(self):
        super().__init__(
            "organization_variable",
            "/v1/organization-variables",
            OrganizationVariable,
        )
