from typing import List

from .base import BaseEntity, BaseRepository, PaginatedResult
from ..utils.utils import make_request


class Evaluation(BaseEntity):
    def __init__(
        self,
        id: str = None,
        session_id: str = None,
        evaluator_id: str = None,
        eval_type: str = None,
        status: str = None,
        trigger: str = None,
        error_message: str = None,
        success: bool = None,
        ruling: dict = None,
        ruling_schema: dict = None,
        success_criteria: dict = None,
        extraction: dict = None,
        extraction_schema: dict = None,
        model: str = None,
        prompt_tokens: int = None,
        completion_tokens: int = None,
        cost: float = None,
        session: dict = None,
        created_at: str = None,
        updated_at: str = None,
        **kwargs,
    ):
        self.id = id
        self.session_id = session_id
        self.evaluator_id = evaluator_id
        self.eval_type = eval_type
        self.status = status
        self.trigger = trigger
        self.error_message = error_message
        self.success = success
        self.ruling = ruling
        self.ruling_schema = ruling_schema
        self.success_criteria = success_criteria
        self.extraction = extraction
        self.extraction_schema = extraction_schema
        self.model = model
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens
        self.cost = cost
        self.session = session
        self.created_at = created_at
        self.updated_at = updated_at


class EvaluationRepository(BaseRepository[Evaluation]):
    def __init__(self):
        super().__init__("evaluation", "/v1/evaluations", Evaluation)


def _paginated_get(repo: BaseRepository, query: dict | None, page: int | None, limit: int | None) -> PaginatedResult:
    query = query or {}
    parts = []
    for key, value in query.items():
        if value is not None:
            parts.append(f"filters[{key}]={value}")
    if page is not None:
        parts.append(f"page={page}")
    if limit is not None:
        parts.append(f"limit={limit}")
    query_string = "&".join(parts)
    response = make_request(f"{repo.endpoint}?{query_string}")

    result = PaginatedResult(page=page or 1, limit=limit or 100)

    if response and "data" in response:
        if isinstance(response["data"], list):
            result.data = [repo._create_entity(item) for item in response["data"]]
        else:
            result.data = [repo._create_entity(response["data"])]

        metadata = response.get("metadata", {})
        if metadata:
            result.page = metadata.get("page", result.page)
            result.limit = metadata.get("limit", result.limit)
            result.total = metadata.get("total")

    return result


class AgentEvaluationRepository(BaseRepository[Evaluation]):
    def __init__(self, agent_id: str):
        self.agent_id = agent_id
        super().__init__("evaluation", f"/v1/agents/{agent_id}/evaluations", Evaluation)

    def get(self, query: dict | None = None, page: int = None, limit: int = None) -> PaginatedResult[Evaluation]:
        return _paginated_get(self, query, page, limit)


class SessionEvaluationRepository(BaseRepository[Evaluation]):
    def __init__(self, session_id: str):
        self.session_id = session_id
        super().__init__("evaluation", f"/v1/sessions/{session_id}/evaluations", Evaluation)

    def get(self, query: dict | None = None, page: int = None, limit: int = None) -> PaginatedResult[Evaluation]:
        return _paginated_get(self, query, page, limit)
