from .base import BaseEntity, BaseRepository


class Organization(BaseEntity):
    def __init__(
        self,
        id: str = None,
        name: str = None,
        tier: str = None,
        billing_enabled: bool = None,
        outbound_enabled: bool = None,
        agent_count: int = None,
        created_at: str = None,
        updated_at: str = None,
        deleted_at: str = None,
        **kwargs,
    ):
        self.id = id
        self.name = name
        self.tier = tier
        self.billing_enabled = billing_enabled
        self.outbound_enabled = outbound_enabled
        self.agent_count = agent_count
        self.created_at = created_at
        self.updated_at = updated_at
        self.deleted_at = deleted_at or None


class OrganizationRepository(BaseRepository[Organization]):
    def __init__(self):
        super().__init__(
            "organization",
            "/v1/organizations",
            Organization,
        )
