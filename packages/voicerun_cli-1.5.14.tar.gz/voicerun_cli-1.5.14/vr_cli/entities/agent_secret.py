from .base import BaseEntity, BaseRepository


class AgentSecret(BaseEntity):
    def __init__(
        self,
        id: str = None,
        agent_id: str = None,
        name: str = None,
        value: str = None,
        created_at: str = None,
        updated_at: str = None,
        deleted_at: str = None,
        **kwargs,
    ):
        self.id = id
        self.agent_id = agent_id
        self.name = name
        self.value = value  # Only used for creation, not returned by API
        self.created_at = created_at
        self.updated_at = updated_at
        self.deleted_at = deleted_at or None


class AgentSecretRepository(BaseRepository[AgentSecret]):
    def __init__(self, agent_id: str):
        super().__init__(
            "agent_secret", f"/v1/agents/{agent_id}/secrets", AgentSecret
        )
