const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  saveAndQuit: (jsonString) => ipcRenderer.send('save-and-quit', jsonString),
  sendEvent: (jsonString) => ipcRenderer.send('headless-event', jsonString),
  onTextInput: (callback) => ipcRenderer.on('stdin-text', (_event, text) => callback(text)),
  onScriptLoad: (callback) => ipcRenderer.on('script-load', (_event, messages) => callback(messages)),
});
