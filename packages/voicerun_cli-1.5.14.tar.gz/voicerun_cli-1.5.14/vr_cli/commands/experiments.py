from datetime import datetime
from pathlib import Path
from typing import Optional

import typer

from ..entities.agent import AgentRepository
from ..utils.agent_lock import load_agent_lock
from ..utils.config import (
    ERROR_STYLE,
    INFO_STYLE,
    NOT_AVAILABLE,
)
from ..utils.utils import console, make_request, print_table, print_json, should_output_json

app = typer.Typer(help="View experiments and A/B test results for agents.")


def _resolve_agent_id(agent: Optional[str]) -> tuple[str, Optional[str]]:
    """Resolve agent ID from argument or agent.lock. Returns (agent_id, agent_name)."""
    if agent:
        agent_repo = AgentRepository()
        agent_entity = agent_repo.get_by_name_or_id(agent)
        if not agent_entity:
            console.print(f"[{ERROR_STYLE}]Agent not found: {agent}[/{ERROR_STYLE}]")
            raise typer.Exit(1)
        return agent_entity.id, agent_entity.name

    voicerun_dir = Path.cwd() / ".voicerun"
    if voicerun_dir.exists():
        lock_data = load_agent_lock(voicerun_dir)
        if lock_data and "id" in lock_data:
            agent_id = lock_data["id"]
            agent_repo = AgentRepository()
            agent_entity = agent_repo.get_by_id(agent_id)
            name = agent_entity.name if agent_entity else agent_id
            return agent_id, name

    return None, None


def _require_agent_id(agent: Optional[str]) -> tuple[str, Optional[str]]:
    """Resolve agent ID, exiting if not found."""
    agent_id, agent_name = _resolve_agent_id(agent)
    if not agent_id:
        console.print(f"[{ERROR_STYLE}]Agent is required. Pass --agent or run from a voicerun project.[/{ERROR_STYLE}]")
        raise typer.Exit(1)
    return agent_id, agent_name


@app.command("list")
def experiments_list(
    agent: Optional[str] = typer.Option(None, "--agent", "-a", help="Agent name or ID (uses agent.lock if omitted)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    table_output: bool = typer.Option(False, "--table", "-t", help="Output as table (default for interactive terminals)"),
):
    """List all experiments for an agent."""
    agent_id, _ = _require_agent_id(agent)

    response = make_request(f"/v1/experiments?agentId={agent_id}")

    if not response or "data" not in response:
        console.print(f"[{ERROR_STYLE}]Failed to fetch experiments.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    data = response["data"]

    if should_output_json(json_output, table_output):
        print_json(data)
        return

    if not data:
        console.print(f"[{INFO_STYLE}]No experiments found.[/{INFO_STYLE}]")
        return

    headers = ["NAME", "SESSIONS", "VARIANTS", "COMPLETED", "LAST UPDATED"]
    rows = []
    for exp in data:
        variants = ", ".join(v["name"] for v in exp.get("variants", []))
        last_updated = exp.get("lastUpdated", NOT_AVAILABLE)
        rows.append([
            exp.get("name", NOT_AVAILABLE),
            str(exp.get("sessionCount", 0)),
            variants or NOT_AVAILABLE,
            str(exp.get("completed", False)),
            str(last_updated),
        ])
    print_table(headers, rows)


@app.command("describe")
def experiments_describe(
    experiment_name: str = typer.Argument(help="Experiment name"),
    agent: Optional[str] = typer.Option(None, "--agent", "-a", help="Agent name or ID (uses agent.lock if omitted)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    table_output: bool = typer.Option(False, "--table", "-t", help="Output as table (default for interactive terminals)"),
):
    """Show detailed results for a specific experiment."""
    agent_id, _ = _require_agent_id(agent)

    response = make_request(f"/v1/experiments/{experiment_name}?agentId={agent_id}")

    if not response or "data" not in response:
        console.print(f"[{ERROR_STYLE}]Failed to fetch experiment detail.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    data = response["data"]

    if should_output_json(json_output, table_output):
        print_json(data)
        return

    console.print(f"[{INFO_STYLE}]Experiment: {data.get('name', NOT_AVAILABLE)}[/{INFO_STYLE}]")
    console.print(f"  Sessions: {data.get('sessionCount', 0)}")
    console.print(f"  Completed: {data.get('completed', False)}")
    console.print(f"  Conversion Metrics: {', '.join(data.get('conversionMetrics', [])) or NOT_AVAILABLE}")

    stop = data.get("stopConditions", {})
    if stop:
        console.print(f"\n[{INFO_STYLE}]Stop Conditions[/{INFO_STYLE}]")
        console.print(f"  Iterations: {stop.get('current_iterations', 0)} / {stop.get('max_iterations', NOT_AVAILABLE)}")
        console.print(f"  Confidence: {stop.get('current_confidence', 0)}% / {stop.get('max_confidence', NOT_AVAILABLE)}%")
        console.print(f"  Target Outcome: {stop.get('target_outcome', NOT_AVAILABLE)}")

    variants = data.get("variants", [])
    if variants:
        console.print(f"\n[{INFO_STYLE}]Variants[/{INFO_STYLE}]")
        headers = ["VARIANT", "SESSIONS"]
        rows = [[v.get("name", NOT_AVAILABLE), str(v.get("sessionCount", 0))] for v in variants]

        # Add conversion rate columns if available
        conversion_keys = set()
        for v in variants:
            conversion_keys.update(v.get("conversions", {}).keys())
        for key in sorted(conversion_keys):
            headers.append(f"{key.upper()} RATE")
            for i, v in enumerate(variants):
                conv = v.get("conversions", {}).get(key, {})
                rate = conv.get("rate")
                rows[i].append(f"{rate:.1%}" if rate is not None else NOT_AVAILABLE)

        print_table(headers, rows)

    significance = data.get("significance", {})
    if significance:
        console.print(f"\n[{INFO_STYLE}]Statistical Significance[/{INFO_STYLE}]")
        headers = ["METRIC", "CONFIDENCE", "P-VALUE", "RESULT"]
        rows = []
        for metric_name, sig in significance.items():
            rows.append([
                metric_name,
                f"{sig.get('confidence', 0):.1f}%",
                f"{sig.get('pValue', 0):.4f}",
                sig.get("significance", NOT_AVAILABLE),
            ])
        print_table(headers, rows)


@app.command("timeseries")
def experiments_timeseries(
    experiment_name: str = typer.Argument(help="Experiment name"),
    metric_name: str = typer.Option(..., "--metric", "-m", help="Metric/outcome name to query"),
    start: str = typer.Option(..., "--start", "-s", help="Start date (ISO 8601, e.g. 2026-03-15T00:00:00Z)"),
    end: str = typer.Option(..., "--end", "-e", help="End date (ISO 8601, e.g. 2026-03-16T00:00:00Z)"),
    step: Optional[str] = typer.Option(None, "--step", help="Time interval for aggregation (e.g. 30m, 1h, 1d). Default: 1h"),
    agent: Optional[str] = typer.Option(None, "--agent", "-a", help="Agent name or ID (uses agent.lock if omitted)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    table_output: bool = typer.Option(False, "--table", "-t", help="Output as table (default for interactive terminals)"),
):
    """Fetch time-series data for an experiment metric, broken down by variant."""
    agent_id, _ = _require_agent_id(agent)

    params = {
        "agentId": agent_id,
        "metricName": metric_name,
        "startDate": start,
        "endDate": end,
    }
    if step:
        params["step"] = step

    query_parts = [f"{k}={v}" for k, v in params.items() if v is not None]
    query_string = "&".join(query_parts)
    url = f"/v1/experiments/{experiment_name}/timeseries?{query_string}"

    response = make_request(url)

    if not response or "data" not in response:
        console.print(f"[{ERROR_STYLE}]Failed to fetch timeseries data.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    data = response["data"]

    if should_output_json(json_output, table_output):
        print_json(data)
        return

    results = data.get("result", [])
    if not results:
        console.print(f"[{INFO_STYLE}]No timeseries data found.[/{INFO_STYLE}]")
        return

    for series in results:
        metric_labels = series.get("metric", {})
        label_parts = [f"{k}={v}" for k, v in metric_labels.items()]
        console.print(f"[{INFO_STYLE}]{', '.join(label_parts) or experiment_name}[/{INFO_STYLE}]")

        values = series.get("values", [])
        if not values:
            console.print(f"[{INFO_STYLE}]  No data points.[/{INFO_STYLE}]")
            continue

        headers = ["TIMESTAMP", "VALUE"]
        rows = [[_format_timestamp(ts), str(val)] for ts, val in values]
        print_table(headers, rows)
        console.print()


@app.command("funnel")
def experiments_funnel(
    experiment_name: str = typer.Argument(help="Experiment name"),
    agent: Optional[str] = typer.Option(None, "--agent", "-a", help="Agent name or ID (uses agent.lock if omitted)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    table_output: bool = typer.Option(False, "--table", "-t", help="Output as table (default for interactive terminals)"),
):
    """Show the conversion funnel for an experiment, comparing variants."""
    agent_id, _ = _require_agent_id(agent)

    response = make_request(f"/v1/experiments/{experiment_name}/funnel?agentId={agent_id}")

    if not response or "data" not in response:
        console.print(f"[{ERROR_STYLE}]Failed to fetch funnel data.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    data = response["data"]

    if should_output_json(json_output, table_output):
        print_json(data)
        return

    console.print(f"[{INFO_STYLE}]Experiment: {data.get('experimentName', experiment_name)}[/{INFO_STYLE}]")
    console.print(f"  Total Sessions: {data.get('totalSessions', 0)}")
    console.print(f"  Conversion Metrics: {', '.join(data.get('conversionMetrics', [])) or NOT_AVAILABLE}")

    funnel = data.get("funnel", [])
    if not funnel:
        console.print(f"[{INFO_STYLE}]No funnel data found.[/{INFO_STYLE}]")
        return

    # Collect all metric keys across variants
    metric_keys = set()
    for entry in funnel:
        metric_keys.update(entry.get("metrics", {}).keys())
    metric_keys = sorted(metric_keys)

    headers = ["VARIANT", "SESSIONS"]
    for key in metric_keys:
        headers.extend([f"{key.upper()} CONV", f"{key.upper()} RATE", f"{key.upper()} LIFT"])

    rows = []
    for entry in funnel:
        row = [entry.get("variant", NOT_AVAILABLE), str(entry.get("sessions", 0))]
        for key in metric_keys:
            m = entry.get("metrics", {}).get(key, {})
            lift = entry.get("lift", {}).get(key)
            row.append(str(m.get("conversions", 0)))
            rate = m.get("rate")
            row.append(f"{rate:.1%}" if rate is not None else NOT_AVAILABLE)
            row.append(f"{lift:+.1%}" if lift is not None else NOT_AVAILABLE)
        rows.append(row)

    print_table(headers, rows)


def _format_timestamp(ts) -> str:
    """Format a unix timestamp to ISO 8601."""
    try:
        return datetime.fromtimestamp(float(ts)).strftime("%Y-%m-%d %H:%M:%S")
    except (TypeError, ValueError, OSError):
        return str(ts)


if __name__ == "__main__":
    app()
