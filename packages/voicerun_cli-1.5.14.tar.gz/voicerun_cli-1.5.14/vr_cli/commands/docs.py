from typing import Optional

import requests
import typer
from rich.markdown import Markdown

from ..utils.config import (
    API_BASE_URL,
    TITLE_STYLE,
    INFO_STYLE,
    ERROR_STYLE,
    ID_STYLE,
)
from ..utils.utils import console, print_json, print_table, should_output_json

app = typer.Typer(help="Browse and search VoiceRun documentation.")


def _docs_request(endpoint: str, params: dict | None = None):
    """Make an unauthenticated GET request to the docs API."""
    try:
        response = requests.get(f"{API_BASE_URL}{endpoint}", params=params)
        response.raise_for_status()
        return response.json()
    except requests.HTTPError as e:
        try:
            detail = e.response.json().get("error", e.response.text)
        except Exception:
            detail = str(e)
        console.print(f"[{ERROR_STYLE}]Error: {detail}[/{ERROR_STYLE}]")
        raise typer.Exit(1)
    except requests.ConnectionError:
        console.print(f"[{ERROR_STYLE}]Error: Could not connect to {API_BASE_URL}[/{ERROR_STYLE}]")
        raise typer.Exit(1)


@app.command("topics")
def list_topics(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    table_output: bool = typer.Option(False, "--table", "-t", help="Output as table"),
):
    """List all available documentation topics."""
    data = _docs_request("/v1/docs/topics")
    topics = data.get("data", {}).get("topics", [])

    if should_output_json(json_output, table_output):
        print_json(data)
        return

    if not topics:
        console.print(f"[{INFO_STYLE}]No topics found.[/{INFO_STYLE}]")
        return

    headers = ["TOPIC", "DESCRIPTION"]
    rows = [[t["name"], t.get("description", "")] for t in topics]
    print_table(headers, rows)


@app.command("topic")
def show_topic(
    name: str = typer.Argument(help="Topic name"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    table_output: bool = typer.Option(False, "--table", "-t", help="Output as table"),
):
    """List pages within a documentation topic."""
    data = _docs_request("/v1/docs/topic", params={"topic": name})
    docs = data.get("data", {}).get("documentation", [])

    if should_output_json(json_output, table_output):
        print_json(data)
        return

    if not docs:
        console.print(f"[{INFO_STYLE}]No pages found for topic '{name}'.[/{INFO_STYLE}]")
        return

    console.print(f"[{TITLE_STYLE}]Topic: {name}[/{TITLE_STYLE}]")
    console.print()

    headers = ["TITLE", "SLUG"]
    rows = [[d["title"], f"[{ID_STYLE}]{d['slug']}[/{ID_STYLE}]"] for d in docs]
    # For table output, strip Rich markup
    plain_rows = [[d["title"], d["slug"]] for d in docs]
    print_table(headers, plain_rows)


@app.command("read")
def read_page(
    slug: str = typer.Argument(help="Page slug"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    table_output: bool = typer.Option(False, "--table", "-t", help="Output as rich format"),
):
    """Read the full content of a documentation page."""
    data = _docs_request("/v1/docs/slug", params={"slug": slug})
    page = data.get("data", {})

    if should_output_json(json_output, table_output):
        print_json(data)
        return

    console.print(f"[{TITLE_STYLE}]{page.get('title', slug)}[/{TITLE_STYLE}]")
    console.print()
    console.print(Markdown(page.get("content", "")))


@app.command("search")
def search_docs(
    query: str = typer.Argument(help="Search query"),
    limit: Optional[int] = typer.Option(None, "--limit", "-l", help="Max results (default 5, max 20)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    table_output: bool = typer.Option(False, "--table", "-t", help="Output as table"),
):
    """Search documentation using natural language."""
    params = {"query": query}
    if limit is not None:
        params["limit"] = str(limit)

    data = _docs_request("/v1/docs/search", params=params)
    results = data.get("data", {}).get("results", [])

    if should_output_json(json_output, table_output):
        print_json(data)
        return

    if not results:
        console.print(f"[{INFO_STYLE}]No results found for '{query}'.[/{INFO_STYLE}]")
        return

    headers = ["TITLE", "SLUG", "MATCHED SECTION", "SIMILARITY"]
    rows = [
        [
            r["title"],
            r["slug"],
            r.get("matchedSection", ""),
            str(r.get("similarity", "")),
        ]
        for r in results
    ]
    print_table(headers, rows)
