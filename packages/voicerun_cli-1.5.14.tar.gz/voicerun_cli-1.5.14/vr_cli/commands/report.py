import platform
import sys
from importlib.metadata import PackageNotFoundError, version
from typing import Optional

import typer

from ..utils.config import ERROR_STYLE, INFO_STYLE, SUCCESS_STYLE, TITLE_STYLE
from ..utils.utils import console, make_request, prompt

try:
    __version__ = version("voicerun-cli")
except PackageNotFoundError:
    __version__ = "unknown"

app = typer.Typer(help="Report issues to VoiceRun.")


@app.command("bug")
def bug(
    title: Optional[str] = typer.Option(None, "--title", "-t", help="Bug title/summary"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Bug description"),
    include_system_info: bool = typer.Option(True, "--include-system-info/--no-system-info", help="Include CLI version and OS info"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would be submitted without sending"),
):
    """Submit a bug report to VoiceRun.\n
    \n
    This command will prompt you for the bug title and description, then submit\n    the report to the VoiceRun team. You'll receive a ticket ID for tracking.\n
    \n
    Examples:\n
        vr report bug\n        vr report bug --title "Login error" --description "Can't log in with SSO"\n        vr report bug --no-system-info\n        vr report bug --dry-run
    """
    console.print(f"[{TITLE_STYLE}]🐛 Submit Bug Report[/{TITLE_STYLE}]\n")

    # Interactive prompts for missing fields
    if not title:
        title = prompt("Title (brief summary of the bug)")

    if not description:
        console.print(f"[{INFO_STYLE}]Enter bug description (press Enter twice to finish):[/{INFO_STYLE}]")
        description_lines = []
        while True:
            try:
                line = input()
                if not line and description_lines and not description_lines[-1]:
                    break
                description_lines.append(line)
            except EOFError:
                break
        description = "\\n".join(description_lines).strip()

    if not title.strip():
        console.print(f"[{ERROR_STYLE}]Error: Title is required[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    if not description.strip():
        console.print(f"[{ERROR_STYLE}]Error: Description is required[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    # Prepare system info
    cli_version = None
    os_info = None

    if include_system_info:
        cli_version = __version__
        os_info = f"{platform.system()} {platform.release()}"
        console.print(f"[{INFO_STYLE}]System info to be included:[/{INFO_STYLE}]")
        console.print(f"  CLI Version: {cli_version}")
        console.print(f"  OS: {os_info}")
        console.print()

    # Dry run: show what would be submitted
    if dry_run:
        console.print(f"[{INFO_STYLE}]Dry run mode - the following would be submitted:[/{INFO_STYLE}]")
        console.print(f"[{TITLE_STYLE}]Title:[/{TITLE_STYLE}] {title.strip()}")
        console.print(f"[{TITLE_STYLE}]Description:[/{TITLE_STYLE}]")
        for line in description.strip().split("\\n"):
            console.print(f"  {line}")
        console.print(f"[{TITLE_STYLE}]Source:[/{TITLE_STYLE}] cli")
        if include_system_info:
            console.print(f"[{TITLE_STYLE}]CLI Version:[/{TITLE_STYLE}] {cli_version}")
            console.print(f"[{TITLE_STYLE}]OS:[/{TITLE_STYLE}] {os_info}")
        console.print(f"\n[{SUCCESS_STYLE}]✓ Dry run complete - nothing was submitted[/{SUCCESS_STYLE}]")
        raise typer.Exit(0)

    # Confirm submission
    if not typer.confirm("Submit this bug report?"):
        console.print(f"[{INFO_STYLE}]Bug report cancelled.[/{INFO_STYLE}]")
        raise typer.Exit(0)

    # Submit to API
    console.print(f"[{INFO_STYLE}]Submitting bug report...[/{INFO_STYLE}]")

    try:
        payload = {
            "title": title.strip(),
            "description": description.strip(),
            "source": "cli",
        }

        if include_system_info:
            payload["cliVersion"] = cli_version
            payload["osInfo"] = os_info

        response = make_request("/v1/bug-tickets", "POST", json=payload)

        if response and "data" in response:
            ticket = response["data"]
            console.print(f"[{SUCCESS_STYLE}]✓ Bug report submitted successfully![/{SUCCESS_STYLE}]")
            console.print(f"[{INFO_STYLE}]Ticket ID:[/{INFO_STYLE}] [{TITLE_STYLE}]{ticket['id']}[/{TITLE_STYLE}]")
            console.print(f"[{INFO_STYLE}]Status:[/{INFO_STYLE}] {ticket['status']}")
            console.print(f"[{INFO_STYLE}]Thank you for helping improve VoiceRun![/{INFO_STYLE}]")
        else:
            console.print(f"[{ERROR_STYLE}]Error: Failed to submit bug report[/{ERROR_STYLE}]")
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[{ERROR_STYLE}]Error: {str(e)}[/{ERROR_STYLE}]")
        raise typer.Exit(1)
