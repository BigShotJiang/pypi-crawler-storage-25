from datetime import datetime
from pathlib import Path
from typing import Optional

import typer

from ..entities.agent import AgentRepository
from ..utils.agent_lock import load_agent_lock
from ..utils.config import (
    ERROR_STYLE,
    INFO_STYLE,
    NOT_AVAILABLE,
)
from ..utils.utils import console, make_request, print_table, print_json, should_output_json

app = typer.Typer(help="Query custom metrics for agents.")


def _resolve_agent_id(agent: Optional[str]) -> tuple[str, Optional[str]]:
    """Resolve agent ID from argument or agent.lock. Returns (agent_id, agent_name)."""
    if agent:
        agent_repo = AgentRepository()
        agent_entity = agent_repo.get_by_name_or_id(agent)
        if not agent_entity:
            console.print(f"[{ERROR_STYLE}]Agent not found: {agent}[/{ERROR_STYLE}]")
            raise typer.Exit(1)
        return agent_entity.id, agent_entity.name

    voicerun_dir = Path.cwd() / ".voicerun"
    if voicerun_dir.exists():
        lock_data = load_agent_lock(voicerun_dir)
        if lock_data and "id" in lock_data:
            agent_id = lock_data["id"]
            agent_repo = AgentRepository()
            agent_entity = agent_repo.get_by_id(agent_id)
            name = agent_entity.name if agent_entity else agent_id
            return agent_id, name

    return None, None


def _metrics_request(path: str, params: dict | None = None) -> dict | None:
    """Make a custom metrics API request and return the data envelope."""
    query_parts = []
    for key, value in (params or {}).items():
        if value is not None:
            query_parts.append(f"{key}={value}")
    query_string = "&".join(query_parts)
    url = f"/v1/custom-metrics/{path}"
    if query_string:
        url += f"?{query_string}"
    response = make_request(url)
    if response and "data" in response:
        return response["data"]
    return None


def _format_timestamp(ts) -> str:
    """Format a unix timestamp to ISO 8601."""
    try:
        return datetime.fromtimestamp(float(ts)).strftime("%Y-%m-%d %H:%M:%S")
    except (TypeError, ValueError, OSError):
        return str(ts)


@app.command("names")
def metrics_names(
    agent: Optional[str] = typer.Argument(None, help="Agent name or ID (optional, filters metric names by agent)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    table_output: bool = typer.Option(False, "--table", "-t", help="Output as table (default for interactive terminals)"),
):
    """List available custom metric names."""
    params = {}
    if agent:
        agent_id, _ = _resolve_agent_id(agent)
        params["agentId"] = agent_id

    data = _metrics_request("names", params)

    if data is None:
        console.print(f"[{ERROR_STYLE}]Failed to fetch metric names.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    if should_output_json(json_output, table_output):
        print_json(data)
        return

    if not data:
        console.print(f"[{INFO_STYLE}]No custom metrics found.[/{INFO_STYLE}]")
        return

    headers = ["METRIC NAME"]
    rows = [[name] for name in data]
    print_table(headers, rows)


@app.command("tags")
def metrics_tags(
    metric: Optional[str] = typer.Option(None, "--metric", "-m", help="Filter tags by metric name"),
    agent: Optional[str] = typer.Option(None, "--agent", "-a", help="Agent name or ID"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    table_output: bool = typer.Option(False, "--table", "-t", help="Output as table (default for interactive terminals)"),
):
    """Discover available tag keys and their values for filtering."""
    params = {}
    if metric:
        params["metricName"] = metric
    if agent:
        agent_id, _ = _resolve_agent_id(agent)
        params["agentId"] = agent_id

    data = _metrics_request("tags", params)

    if data is None:
        console.print(f"[{ERROR_STYLE}]Failed to fetch metric tags.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    if should_output_json(json_output, table_output):
        print_json(data)
        return

    if not data:
        console.print(f"[{INFO_STYLE}]No tags found.[/{INFO_STYLE}]")
        return

    headers = ["TAG KEY", "VALUES"]
    rows = []
    for key, values in data.items():
        rows.append([key, ", ".join(values)])
    print_table(headers, rows)


@app.command("timeseries")
def metrics_timeseries(
    metric_name: str = typer.Argument(help="The metric name to query"),
    start: str = typer.Option(..., "--start", "-s", help="Start date (ISO 8601, e.g. 2026-03-15T00:00:00Z)"),
    end: str = typer.Option(..., "--end", "-e", help="End date (ISO 8601, e.g. 2026-03-16T00:00:00Z)"),
    step: Optional[str] = typer.Option(None, "--step", help="Time interval for aggregation (e.g. 30m, 1h, 1d). Default: 1h"),
    agent: Optional[str] = typer.Option(None, "--agent", "-a", help="Agent name or ID"),
    environment: Optional[str] = typer.Option(None, "--environment", "-E", help="Environment ID"),
    tags: Optional[str] = typer.Option(None, "--tags", help='Tag filters as JSON (e.g. \'{"channel":"phone"}\')'),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    table_output: bool = typer.Option(False, "--table", "-t", help="Output as table (default for interactive terminals)"),
):
    """Fetch time-series data for a custom metric with type-appropriate aggregation."""
    params = {
        "metricName": metric_name,
        "startDate": start,
        "endDate": end,
    }
    if step:
        params["step"] = step
    if agent:
        agent_id, _ = _resolve_agent_id(agent)
        params["agentId"] = agent_id
    if environment:
        params["environmentId"] = environment
    if tags:
        params["tags"] = tags

    data = _metrics_request("timeseries", params)

    if data is None:
        console.print(f"[{ERROR_STYLE}]Failed to fetch timeseries data.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    if should_output_json(json_output, table_output):
        print_json(data)
        return

    results = data.get("result", [])
    if not results:
        console.print(f"[{INFO_STYLE}]No timeseries data found.[/{INFO_STYLE}]")
        return

    for series in results:
        metric_labels = series.get("metric", {})
        metric_type = metric_labels.get("metric_type", NOT_AVAILABLE)
        series_name = metric_labels.get("metric_name", metric_name)
        console.print(f"[{INFO_STYLE}]{series_name} (type: {metric_type})[/{INFO_STYLE}]")

        values = series.get("values", [])
        if not values:
            console.print(f"[{INFO_STYLE}]  No data points.[/{INFO_STYLE}]")
            continue

        headers = ["TIMESTAMP", "VALUE"]
        rows = [[_format_timestamp(ts), str(val)] for ts, val in values]
        print_table(headers, rows)
        console.print()


@app.command("session")
def metrics_session(
    session_id: str = typer.Argument(help="Session ID"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    table_output: bool = typer.Option(False, "--table", "-t", help="Output as table (default for interactive terminals)"),
):
    """Fetch all custom metrics for a specific session."""
    url = f"/v1/custom-metrics/sessions/{session_id}"
    response = make_request(url)

    if not response or "data" not in response:
        console.print(f"[{ERROR_STYLE}]Failed to fetch session metrics.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    data = response["data"]

    if should_output_json(json_output, table_output):
        print_json(data)
        return

    results = data.get("result", [])
    if not results:
        console.print(f"[{INFO_STYLE}]No metrics found for session {session_id}.[/{INFO_STYLE}]")
        return

    headers = ["METRIC", "TYPE", "VALUE", "TIMESTAMP"]
    rows = []
    for entry in results:
        metric_labels = entry.get("metric", {})
        name = metric_labels.get("metric_name", NOT_AVAILABLE)
        metric_type = metric_labels.get("metric_type", NOT_AVAILABLE)
        value = entry.get("value", [])
        ts = _format_timestamp(value[0]) if len(value) > 0 else NOT_AVAILABLE
        val = str(value[1]) if len(value) > 1 else NOT_AVAILABLE
        rows.append([name, metric_type, val, ts])
    print_table(headers, rows)


if __name__ == "__main__":
    app()
