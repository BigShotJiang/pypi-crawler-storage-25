"""Tests for vr report bug command."""

import pytest
from unittest.mock import patch, Mock

from typer.testing import CliRunner

from vr_cli.cli import app

runner = CliRunner()


class TestReportBugCommand:
    """Tests for report bug command."""

    def test_report_help(self):
        """Should show help for report command."""
        result = runner.invoke(app, ["report", "--help"])

        assert result.exit_code == 0
        assert "Report issues" in result.output
        assert "bug" in result.output

    def test_report_bug_help(self):
        """Should show help for report bug command."""
        result = runner.invoke(app, ["report", "bug", "--help"])

        assert result.exit_code == 0
        assert "--title" in result.output
        assert "--description" in result.output
        assert "--include-system-info" in result.output

    def test_report_bug_success(self):
        """Should submit bug report successfully with flags."""
        mock_response = {
            "data": {
                "id": "bug-123-abc",
                "title": "Test Bug",
                "description": "Test description",
                "source": "cli",
                "status": "open",
            }
        }

        with patch("vr_cli.commands.report.make_request") as mock_make_request, \
             patch("vr_cli.commands.report.typer.confirm") as mock_confirm:

            mock_make_request.return_value = mock_response
            mock_confirm.return_value = True

            result = runner.invoke(app, [
                "report", "bug",
                "--title", "Test Bug",
                "--description", "Test description",
            ])

        assert result.exit_code == 0
        assert "submitted successfully" in result.output
        assert "bug-123-abc" in result.output
        assert "open" in result.output

    def test_report_bug_with_system_info(self):
        """Should include system info when flag is set."""
        mock_response = {
            "data": {
                "id": "bug-123-abc",
                "title": "Test Bug",
                "description": "Test description",
                "source": "cli",
                "status": "open",
            }
        }

        with patch("vr_cli.commands.report.make_request") as mock_make_request, \
             patch("vr_cli.commands.report.typer.confirm") as mock_confirm:

            mock_make_request.return_value = mock_response
            mock_confirm.return_value = True

            result = runner.invoke(app, [
                "report", "bug",
                "--title", "Test Bug",
                "--description", "Test description",
                "--include-system-info",
            ])

        assert result.exit_code == 0
        # Verify the call included system info
        call_args = mock_make_request.call_args
        assert "cliVersion" in call_args.kwargs["json"]
        assert "osInfo" in call_args.kwargs["json"]

    def test_report_bug_without_system_info(self):
        """Should not include system info when flag is disabled."""
        mock_response = {
            "data": {
                "id": "bug-123-abc",
                "title": "Test Bug",
                "description": "Test description",
                "source": "cli",
                "status": "open",
            }
        }

        with patch("vr_cli.commands.report.make_request") as mock_make_request, \
             patch("vr_cli.commands.report.typer.confirm") as mock_confirm:

            mock_make_request.return_value = mock_response
            mock_confirm.return_value = True

            result = runner.invoke(app, [
                "report", "bug",
                "--title", "Test Bug",
                "--description", "Test description",
                "--no-system-info",
            ])

        assert result.exit_code == 0
        # Verify the call did not include system info
        call_args = mock_make_request.call_args
        assert "cliVersion" not in call_args.kwargs["json"]
        assert "osInfo" not in call_args.kwargs["json"]

    def test_report_bug_missing_title(self):
        """Should fail when title is whitespace-only."""
        result = runner.invoke(app, [
            "report", "bug",
            "--title", "   ",
            "--description", "Test description",
        ])

        assert result.exit_code != 0
        assert "Title is required" in result.output

    def test_report_bug_missing_description(self):
        """Should fail when description is missing."""
        result = runner.invoke(app, [
            "report", "bug",
            "--title", "Test Bug",
        ])

        assert result.exit_code != 0
        assert "Description is required" in result.output

    def test_report_bug_cancelled(self):
        """Should cancel when user declines confirmation."""
        with patch("vr_cli.commands.report.typer.confirm") as mock_confirm:
            mock_confirm.return_value = False

            result = runner.invoke(app, [
                "report", "bug",
                "--title", "Test Bug",
                "--description", "Test description",
            ])

        assert result.exit_code == 0
        assert "cancelled" in result.output

    def test_report_bug_api_error(self):
        """Should handle API error gracefully."""
        with patch("vr_cli.commands.report.make_request") as mock_make_request, \
             patch("vr_cli.commands.report.typer.confirm") as mock_confirm:

            mock_make_request.return_value = None
            mock_confirm.return_value = True

            result = runner.invoke(app, [
                "report", "bug",
                "--title", "Test Bug",
                "--description", "Test description",
            ])

        assert result.exit_code != 0
        assert "Failed to submit" in result.output

    def test_report_bug_api_exception(self):
        """Should handle API exception gracefully."""
        with patch("vr_cli.commands.report.make_request") as mock_make_request, \
             patch("vr_cli.commands.report.typer.confirm") as mock_confirm:

            mock_make_request.side_effect = Exception("Network error")
            mock_confirm.return_value = True

            result = runner.invoke(app, [
                "report", "bug",
                "--title", "Test Bug",
                "--description", "Test description",
            ])

        assert result.exit_code != 0
        assert "Error" in result.output
