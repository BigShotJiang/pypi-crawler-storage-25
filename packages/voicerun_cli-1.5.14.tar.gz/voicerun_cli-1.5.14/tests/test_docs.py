"""Tests for vr docs commands."""

from unittest.mock import patch, Mock

from typer.testing import CliRunner

from vr_cli.cli import app


runner = CliRunner()


MOCK_TOPICS_RESPONSE = {
    "data": {
        "topics": [
            {"name": "quickstart", "description": "Getting started guides"},
            {"name": "api", "description": "API documentation"},
        ]
    }
}

MOCK_TOPIC_RESPONSE = {
    "data": {
        "topic": "quickstart",
        "documentation": [
            {"title": "Getting Started", "slug": "getting-started", "summary": "Welcome to VoiceRun."},
        ],
    }
}

MOCK_SLUG_RESPONSE = {
    "data": {
        "title": "Getting Started",
        "slug": "getting-started",
        "topic": "quickstart",
        "content": "# Getting Started\n\nWelcome to VoiceRun.",
    }
}

MOCK_SEARCH_RESPONSE = {
    "data": {
        "results": [
            {
                "title": "Getting Started",
                "slug": "getting-started",
                "matchedSection": "Introduction",
                "snippet": "Welcome to VoiceRun",
                "similarity": 0.95,
            },
        ]
    }
}


def _mock_response(json_data, status_code=200):
    mock = Mock()
    mock.status_code = status_code
    mock.json.return_value = json_data
    mock.raise_for_status.return_value = None
    return mock


class TestDocsTopics:
    """Tests for vr docs topics."""

    def test_list_topics(self):
        """Should list all topics."""
        with patch("vr_cli.commands.docs.requests.get") as mock_get:
            mock_get.return_value = _mock_response(MOCK_TOPICS_RESPONSE)

            result = runner.invoke(app, ["docs", "topics"])

        assert result.exit_code == 0
        assert "quickstart" in result.output
        assert "api" in result.output

    def test_list_topics_json(self):
        """Should output JSON with --json flag."""
        with patch("vr_cli.commands.docs.requests.get") as mock_get:
            mock_get.return_value = _mock_response(MOCK_TOPICS_RESPONSE)

            result = runner.invoke(app, ["docs", "topics", "--json"])

        assert result.exit_code == 0
        assert '"quickstart"' in result.output
        assert '"topics"' in result.output

    def test_list_topics_empty(self):
        """Should show message when no topics found."""
        with patch("vr_cli.commands.docs.requests.get") as mock_get:
            mock_get.return_value = _mock_response({"data": {"topics": []}})

            result = runner.invoke(app, ["docs", "topics", "--table"])

        assert result.exit_code == 0
        assert "No topics found" in result.output


class TestDocsTopic:
    """Tests for vr docs topic <name>."""

    def test_show_topic(self):
        """Should list pages in a topic."""
        with patch("vr_cli.commands.docs.requests.get") as mock_get:
            mock_get.return_value = _mock_response(MOCK_TOPIC_RESPONSE)

            result = runner.invoke(app, ["docs", "topic", "quickstart"])

        assert result.exit_code == 0
        assert "Getting Started" in result.output
        assert "getting-started" in result.output

    def test_show_topic_json(self):
        """Should output JSON with --json flag."""
        with patch("vr_cli.commands.docs.requests.get") as mock_get:
            mock_get.return_value = _mock_response(MOCK_TOPIC_RESPONSE)

            result = runner.invoke(app, ["docs", "topic", "quickstart", "--json"])

        assert result.exit_code == 0
        assert '"quickstart"' in result.output


class TestDocsRead:
    """Tests for vr docs read <slug>."""

    def test_read_page(self):
        """Should display page content."""
        with patch("vr_cli.commands.docs.requests.get") as mock_get:
            mock_get.return_value = _mock_response(MOCK_SLUG_RESPONSE)

            result = runner.invoke(app, ["docs", "read", "getting-started"])

        assert result.exit_code == 0
        assert "Getting Started" in result.output

    def test_read_page_json(self):
        """Should output JSON with --json flag."""
        with patch("vr_cli.commands.docs.requests.get") as mock_get:
            mock_get.return_value = _mock_response(MOCK_SLUG_RESPONSE)

            result = runner.invoke(app, ["docs", "read", "getting-started", "--json"])

        assert result.exit_code == 0
        assert '"getting-started"' in result.output
        assert '"content"' in result.output


class TestDocsSearch:
    """Tests for vr docs search <query>."""

    def test_search_docs(self):
        """Should display search results."""
        with patch("vr_cli.commands.docs.requests.get") as mock_get:
            mock_get.return_value = _mock_response(MOCK_SEARCH_RESPONSE)

            result = runner.invoke(app, ["docs", "search", "getting started"])

        assert result.exit_code == 0
        assert "Getting Started" in result.output
        assert "0.95" in result.output

    def test_search_docs_json(self):
        """Should output JSON with --json flag."""
        with patch("vr_cli.commands.docs.requests.get") as mock_get:
            mock_get.return_value = _mock_response(MOCK_SEARCH_RESPONSE)

            result = runner.invoke(app, ["docs", "search", "getting started", "--json"])

        assert result.exit_code == 0
        assert '"results"' in result.output

    def test_search_with_limit(self):
        """Should pass limit parameter."""
        with patch("vr_cli.commands.docs.requests.get") as mock_get:
            mock_get.return_value = _mock_response(MOCK_SEARCH_RESPONSE)

            result = runner.invoke(app, ["docs", "search", "test", "--limit", "3"])

        assert result.exit_code == 0
        mock_get.assert_called_once()
        call_kwargs = mock_get.call_args
        assert call_kwargs[1]["params"]["limit"] == "3"

    def test_search_no_results(self):
        """Should show message when no results found."""
        with patch("vr_cli.commands.docs.requests.get") as mock_get:
            mock_get.return_value = _mock_response({"data": {"results": []}})

            result = runner.invoke(app, ["docs", "search", "nonexistent", "--table"])

        assert result.exit_code == 0
        assert "No results found" in result.output
