"""Tests for phone number assignment commands (get, create, delete, describe)."""

from unittest.mock import patch, Mock

from typer.testing import CliRunner

from vr_cli.cli import app
from vr_cli.entities.organization_phone_number import OrganizationPhoneNumber


runner = CliRunner()


# ============================================================================
# Get Assignments Tests
# ============================================================================


class TestGetAssignments:
    """Tests for get assignments command."""

    def test_get_assignments_lists_matching_agent(self, mock_agent, mock_assignments_list):
        """Should list phone numbers assigned to the target agent only."""
        with patch("vr_cli.utils.agent_lock.AgentRepository") as mock_agent_repo_class, \
             patch("vr_cli.commands.get.OrganizationPhoneNumberRepository") as mock_pn_repo_class:

            mock_agent_repo = Mock()
            mock_agent_repo.get_by_name_or_id.return_value = mock_agent
            mock_agent_repo_class.return_value = mock_agent_repo

            mock_pn_repo = Mock()
            mock_pn_repo.get.return_value = mock_assignments_list
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["get", "assignments", "Test Agent"])

        assert result.exit_code == 0
        assert "pn-1" in result.output
        assert "pn-2" in result.output
        assert "pn-3-other" not in result.output

    def test_get_assignments_shows_environment_id(self, mock_agent, mock_assignments_list):
        """Should show environment IDs in the table."""
        with patch("vr_cli.utils.agent_lock.AgentRepository") as mock_agent_repo_class, \
             patch("vr_cli.commands.get.OrganizationPhoneNumberRepository") as mock_pn_repo_class:

            mock_agent_repo = Mock()
            mock_agent_repo.get_by_name_or_id.return_value = mock_agent
            mock_agent_repo_class.return_value = mock_agent_repo

            mock_pn_repo = Mock()
            mock_pn_repo.get.return_value = mock_assignments_list
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["get", "assignments", "Test Agent"])

        assert result.exit_code == 0
        assert "env-1" in result.output
        assert "env-2" in result.output

    def test_get_assignments_empty(self, mock_agent):
        """Should show message when no assignments found."""
        with patch("vr_cli.utils.agent_lock.AgentRepository") as mock_agent_repo_class, \
             patch("vr_cli.commands.get.OrganizationPhoneNumberRepository") as mock_pn_repo_class:

            mock_agent_repo = Mock()
            mock_agent_repo.get_by_name_or_id.return_value = mock_agent
            mock_agent_repo_class.return_value = mock_agent_repo

            mock_pn_repo = Mock()
            mock_pn_repo.get.return_value = []
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["get", "assignments", "Test Agent"])

        assert result.exit_code == 0
        assert "No assignments found" in result.output

    def test_get_assignments_empty_when_none_match_agent(self, mock_agent):
        """Should show empty message when other agents have assignments but this one does not."""
        other_only = [
            OrganizationPhoneNumber(
                id="pn-other",
                phone_number="+15559999999",
                agent_id="some-other-agent",
                agent_environment_id="env-other",
            ),
        ]

        with patch("vr_cli.utils.agent_lock.AgentRepository") as mock_agent_repo_class, \
             patch("vr_cli.commands.get.OrganizationPhoneNumberRepository") as mock_pn_repo_class:

            mock_agent_repo = Mock()
            mock_agent_repo.get_by_name_or_id.return_value = mock_agent
            mock_agent_repo_class.return_value = mock_agent_repo

            mock_pn_repo = Mock()
            mock_pn_repo.get.return_value = other_only
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["get", "assignments", "Test Agent"])

        assert result.exit_code == 0
        assert "No assignments found" in result.output

    def test_get_assignments_agent_not_found(self):
        """Should fail when agent not found."""
        with patch("vr_cli.utils.agent_lock.AgentRepository") as mock_agent_repo_class:
            mock_agent_repo = Mock()
            mock_agent_repo.get_by_name_or_id.return_value = None
            mock_agent_repo_class.return_value = mock_agent_repo

            result = runner.invoke(app, ["get", "assignments", "nonexistent"])

        assert result.exit_code != 0
        assert "Agent not found" in result.output

    def test_get_assignment_singular_alias(self, mock_agent):
        """Should work with singular assignment alias."""
        with patch("vr_cli.utils.agent_lock.AgentRepository") as mock_agent_repo_class, \
             patch("vr_cli.commands.get.OrganizationPhoneNumberRepository") as mock_pn_repo_class:

            mock_agent_repo = Mock()
            mock_agent_repo.get_by_name_or_id.return_value = mock_agent
            mock_agent_repo_class.return_value = mock_agent_repo

            mock_pn_repo = Mock()
            mock_pn_repo.get.return_value = []
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["get", "assignment", "Test Agent"])

        assert result.exit_code == 0


# ============================================================================
# Create Assignment Tests
# ============================================================================


def _assigned(**overrides):
    defaults = dict(
        id="pn-123",
        phone_number="+15551234567",
        agent_id="test-agent-id-123",
        agent_environment_id="test-env-id-123",
        created_at="2024-01-01T00:00:00Z",
    )
    defaults.update(overrides)
    return OrganizationPhoneNumber(**defaults)


class TestCreateAssignment:
    """Tests for create assignment command."""

    def test_create_assignment_success(self, mock_agent, mock_environment):
        """Should create an assignment successfully."""
        with patch("vr_cli.utils.agent_lock.AgentRepository") as mock_agent_repo_class, \
             patch("vr_cli.commands.create.AgentEnvironmentRepository") as mock_env_repo_class, \
             patch("vr_cli.commands.create.OrganizationPhoneNumberRepository") as mock_pn_repo_class:

            mock_agent_repo = Mock()
            mock_agent_repo.get_by_name_or_id.return_value = mock_agent
            mock_agent_repo_class.return_value = mock_agent_repo

            mock_env_repo = Mock()
            mock_env_repo.get_by_name_or_id.return_value = mock_environment
            mock_env_repo_class.return_value = mock_env_repo

            mock_pn_repo = Mock()
            mock_pn_repo.assign.return_value = _assigned()
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["create", "assignment", "Test Agent", "Test Environment", "pn-123"])

        assert result.exit_code == 0
        assert "created successfully" in result.output
        assert "pn-123" in result.output

    def test_create_assignment_agent_not_found(self):
        """Should fail when agent not found."""
        with patch("vr_cli.utils.agent_lock.AgentRepository") as mock_agent_repo_class:
            mock_agent_repo = Mock()
            mock_agent_repo.get_by_name_or_id.return_value = None
            mock_agent_repo_class.return_value = mock_agent_repo

            result = runner.invoke(app, ["create", "assignment", "nonexistent", "env", "pn-123"])

        assert result.exit_code != 0
        assert "Agent not found" in result.output

    def test_create_assignment_environment_not_found(self, mock_agent):
        """Should fail when environment not found."""
        with patch("vr_cli.utils.agent_lock.AgentRepository") as mock_agent_repo_class, \
             patch("vr_cli.commands.create.AgentEnvironmentRepository") as mock_env_repo_class:

            mock_agent_repo = Mock()
            mock_agent_repo.get_by_name_or_id.return_value = mock_agent
            mock_agent_repo_class.return_value = mock_agent_repo

            mock_env_repo = Mock()
            mock_env_repo.get_by_name_or_id.return_value = None
            mock_env_repo_class.return_value = mock_env_repo

            result = runner.invoke(app, ["create", "assignment", "Test Agent", "nonexistent", "pn-123"])

        assert result.exit_code != 0
        assert "Environment not found" in result.output

    def test_create_assignment_api_failure(self, mock_agent, mock_environment):
        """Should fail when API returns error."""
        with patch("vr_cli.utils.agent_lock.AgentRepository") as mock_agent_repo_class, \
             patch("vr_cli.commands.create.AgentEnvironmentRepository") as mock_env_repo_class, \
             patch("vr_cli.commands.create.OrganizationPhoneNumberRepository") as mock_pn_repo_class:

            mock_agent_repo = Mock()
            mock_agent_repo.get_by_name_or_id.return_value = mock_agent
            mock_agent_repo_class.return_value = mock_agent_repo

            mock_env_repo = Mock()
            mock_env_repo.get_by_name_or_id.return_value = mock_environment
            mock_env_repo_class.return_value = mock_env_repo

            mock_pn_repo = Mock()
            mock_pn_repo.assign.return_value = None
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["create", "assignment", "Test Agent", "Test Environment", "pn-123"])

        assert result.exit_code != 0
        assert "Failed to create assignment" in result.output

    def test_create_assignment_passes_correct_ids(self, mock_agent, mock_environment):
        """Should pass phone number ID, agent ID, and environment ID to repository."""
        with patch("vr_cli.utils.agent_lock.AgentRepository") as mock_agent_repo_class, \
             patch("vr_cli.commands.create.AgentEnvironmentRepository") as mock_env_repo_class, \
             patch("vr_cli.commands.create.OrganizationPhoneNumberRepository") as mock_pn_repo_class:

            mock_agent_repo = Mock()
            mock_agent_repo.get_by_name_or_id.return_value = mock_agent
            mock_agent_repo_class.return_value = mock_agent_repo

            mock_env_repo = Mock()
            mock_env_repo.get_by_name_or_id.return_value = mock_environment
            mock_env_repo_class.return_value = mock_env_repo

            mock_pn_repo = Mock()
            mock_pn_repo.assign.return_value = _assigned(id="pn-999")
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["create", "assignment", "Test Agent", "Test Environment", "pn-999"])

        assert result.exit_code == 0
        mock_pn_repo.assign.assert_called_once_with("pn-999", "test-agent-id-123", "test-env-id-123")

    def test_create_assignment_with_configure(self, mock_agent, mock_environment):
        """Should configure the phone number after assigning with --configure flag."""
        with patch("vr_cli.utils.agent_lock.AgentRepository") as mock_agent_repo_class, \
             patch("vr_cli.commands.create.AgentEnvironmentRepository") as mock_env_repo_class, \
             patch("vr_cli.commands.create.OrganizationPhoneNumberRepository") as mock_pn_repo_class:

            mock_agent_repo = Mock()
            mock_agent_repo.get_by_name_or_id.return_value = mock_agent
            mock_agent_repo_class.return_value = mock_agent_repo

            mock_env_repo = Mock()
            mock_env_repo.get_by_name_or_id.return_value = mock_environment
            mock_env_repo_class.return_value = mock_env_repo

            mock_pn_repo = Mock()
            mock_pn_repo.assign.return_value = _assigned()
            mock_pn_repo.configure.return_value = _assigned()
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["create", "assignment", "Test Agent", "Test Environment", "pn-123", "--configure"])

        assert result.exit_code == 0
        assert "created successfully" in result.output
        assert "configured successfully" in result.output
        mock_pn_repo.assign.assert_called_once()
        mock_pn_repo.configure.assert_called_once_with("pn-123")

    def test_create_assignment_without_configure_does_not_call_configure(self, mock_agent, mock_environment):
        """Should not call configure when --configure flag is not set."""
        with patch("vr_cli.utils.agent_lock.AgentRepository") as mock_agent_repo_class, \
             patch("vr_cli.commands.create.AgentEnvironmentRepository") as mock_env_repo_class, \
             patch("vr_cli.commands.create.OrganizationPhoneNumberRepository") as mock_pn_repo_class:

            mock_agent_repo = Mock()
            mock_agent_repo.get_by_name_or_id.return_value = mock_agent
            mock_agent_repo_class.return_value = mock_agent_repo

            mock_env_repo = Mock()
            mock_env_repo.get_by_name_or_id.return_value = mock_environment
            mock_env_repo_class.return_value = mock_env_repo

            mock_pn_repo = Mock()
            mock_pn_repo.assign.return_value = _assigned()
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["create", "assignment", "Test Agent", "Test Environment", "pn-123"])

        assert result.exit_code == 0
        assert "created successfully" in result.output
        assert "configured successfully" not in result.output
        mock_pn_repo.configure.assert_not_called()

    def test_create_assignment_configure_api_failure(self, mock_agent, mock_environment):
        """Should fail when configure returns None after successful assign."""
        with patch("vr_cli.utils.agent_lock.AgentRepository") as mock_agent_repo_class, \
             patch("vr_cli.commands.create.AgentEnvironmentRepository") as mock_env_repo_class, \
             patch("vr_cli.commands.create.OrganizationPhoneNumberRepository") as mock_pn_repo_class:

            mock_agent_repo = Mock()
            mock_agent_repo.get_by_name_or_id.return_value = mock_agent
            mock_agent_repo_class.return_value = mock_agent_repo

            mock_env_repo = Mock()
            mock_env_repo.get_by_name_or_id.return_value = mock_environment
            mock_env_repo_class.return_value = mock_env_repo

            mock_pn_repo = Mock()
            mock_pn_repo.assign.return_value = _assigned()
            mock_pn_repo.configure.return_value = None
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["create", "assignment", "Test Agent", "Test Environment", "pn-123", "--configure"])

        assert result.exit_code != 0
        assert "created successfully" in result.output
        assert "Failed to configure phone number" in result.output


# ============================================================================
# Delete Assignment Tests
# ============================================================================


class TestDeleteAssignment:
    """Tests for delete assignment command."""

    def test_delete_assignment_success(self, mock_assignment):
        """Should unconfigure and unassign a phone number."""
        with patch("vr_cli.commands.delete.OrganizationPhoneNumberRepository") as mock_pn_repo_class:
            mock_pn_repo = Mock()
            mock_pn_repo.get_by_id.return_value = mock_assignment
            mock_pn_repo.unconfigure.return_value = mock_assignment
            mock_pn_repo.unassign.return_value = mock_assignment
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["delete", "assignment", mock_assignment.id])

        assert result.exit_code == 0
        assert "unassigned successfully" in result.output
        mock_pn_repo.unconfigure.assert_called_once_with(mock_assignment.id)
        mock_pn_repo.unassign.assert_called_once_with(mock_assignment.id)

    def test_delete_assignment_skips_unconfigure_when_flag_set(self, mock_assignment):
        """Should skip the unconfigure step with --skip-unconfigure."""
        with patch("vr_cli.commands.delete.OrganizationPhoneNumberRepository") as mock_pn_repo_class:
            mock_pn_repo = Mock()
            mock_pn_repo.get_by_id.return_value = mock_assignment
            mock_pn_repo.unassign.return_value = mock_assignment
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["delete", "assignment", mock_assignment.id, "--skip-unconfigure"])

        assert result.exit_code == 0
        mock_pn_repo.unconfigure.assert_not_called()
        mock_pn_repo.unassign.assert_called_once_with(mock_assignment.id)

    def test_delete_assignment_skips_unconfigure_when_unassigned(self):
        """Should skip unconfigure when the phone number has no agent assigned."""
        unassigned_pn = OrganizationPhoneNumber(
            id="pn-unassigned",
            phone_number="+15550000000",
            agent_id=None,
            agent_environment_id=None,
        )
        with patch("vr_cli.commands.delete.OrganizationPhoneNumberRepository") as mock_pn_repo_class:
            mock_pn_repo = Mock()
            mock_pn_repo.get_by_id.return_value = unassigned_pn
            mock_pn_repo.unassign.return_value = unassigned_pn
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["delete", "assignment", "pn-unassigned"])

        assert result.exit_code == 0
        mock_pn_repo.unconfigure.assert_not_called()
        mock_pn_repo.unassign.assert_called_once_with("pn-unassigned")

    def test_delete_assignment_phone_number_not_found(self):
        """Should fail when phone number not found."""
        with patch("vr_cli.commands.delete.OrganizationPhoneNumberRepository") as mock_pn_repo_class:
            mock_pn_repo = Mock()
            mock_pn_repo.get_by_id.return_value = None
            mock_pn_repo.get.return_value = []
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["delete", "assignment", "nonexistent"])

        assert result.exit_code != 0
        assert "Phone number not found" in result.output

    def test_delete_assignment_unassign_failure(self, mock_assignment):
        """Should fail when unassign returns None."""
        with patch("vr_cli.commands.delete.OrganizationPhoneNumberRepository") as mock_pn_repo_class:
            mock_pn_repo = Mock()
            mock_pn_repo.get_by_id.return_value = mock_assignment
            mock_pn_repo.unconfigure.return_value = mock_assignment
            mock_pn_repo.unassign.return_value = None
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["delete", "assignment", mock_assignment.id])

        assert result.exit_code != 0
        assert "Failed to unassign" in result.output

    def test_delete_assignment_unconfigure_failure(self, mock_assignment):
        """Should fail when unconfigure returns None."""
        with patch("vr_cli.commands.delete.OrganizationPhoneNumberRepository") as mock_pn_repo_class:
            mock_pn_repo = Mock()
            mock_pn_repo.get_by_id.return_value = mock_assignment
            mock_pn_repo.unconfigure.return_value = None
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["delete", "assignment", mock_assignment.id])

        assert result.exit_code != 0
        assert "Failed to unconfigure" in result.output
        mock_pn_repo.unassign.assert_not_called()


# ============================================================================
# Describe Assignment Tests
# ============================================================================


class TestDescribeAssignment:
    """Tests for describe assignment command."""

    def test_describe_assignment_success(self, mock_assignment):
        """Should describe an assignment by phone number ID."""
        with patch("vr_cli.commands.describe.OrganizationPhoneNumberRepository") as mock_pn_repo_class:
            mock_pn_repo = Mock()
            mock_pn_repo.get_by_id.return_value = mock_assignment
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["describe", "assignment", mock_assignment.id])

        assert result.exit_code == 0
        assert mock_assignment.id in result.output
        assert "test-env-id-123" in result.output
        assert "test-agent-id-123" in result.output

    def test_describe_assignment_not_found(self):
        """Should fail when phone number not found."""
        with patch("vr_cli.commands.describe.OrganizationPhoneNumberRepository") as mock_pn_repo_class:
            mock_pn_repo = Mock()
            mock_pn_repo.get_by_id.return_value = None
            mock_pn_repo.get.return_value = []
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["describe", "assignment", "nonexistent"])

        assert result.exit_code != 0
        assert "Assignment not found" in result.output

    def test_describe_assignment_not_assigned(self):
        """Should fail when phone number exists but has no agent assignment."""
        pn = OrganizationPhoneNumber(
            id="pn-unassigned",
            phone_number="+15550000000",
            agent_id=None,
            agent_environment_id=None,
        )
        with patch("vr_cli.commands.describe.OrganizationPhoneNumberRepository") as mock_pn_repo_class:
            mock_pn_repo = Mock()
            mock_pn_repo.get_by_id.return_value = pn
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["describe", "assignment", "pn-unassigned"])

        assert result.exit_code != 0
        assert "not assigned" in result.output

    def test_describe_assignment_shows_timestamps(self, mock_assignment):
        """Should show timestamps."""
        with patch("vr_cli.commands.describe.OrganizationPhoneNumberRepository") as mock_pn_repo_class:
            mock_pn_repo = Mock()
            mock_pn_repo.get_by_id.return_value = mock_assignment
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["describe", "assignment", mock_assignment.id])

        assert result.exit_code == 0
        assert "2024-01-01T00:00:00Z" in result.output
        assert "2024-01-02T00:00:00Z" in result.output

    def test_describe_assignment_shows_sections(self, mock_assignment):
        """Should show all information sections."""
        with patch("vr_cli.commands.describe.OrganizationPhoneNumberRepository") as mock_pn_repo_class:
            mock_pn_repo = Mock()
            mock_pn_repo.get_by_id.return_value = mock_assignment
            mock_pn_repo_class.return_value = mock_pn_repo

            result = runner.invoke(app, ["describe", "assignment", mock_assignment.id])

        assert result.exit_code == 0
        assert "Assignment Details" in result.output
        assert "Timestamps" in result.output


# ============================================================================
# Help Output Tests
# ============================================================================


class TestAssignmentHelp:
    """Tests for assignment command help output."""

    def test_get_assignments_help(self):
        """Should show help for get assignments command."""
        result = runner.invoke(app, ["get", "assignments", "--help"])

        assert result.exit_code == 0
        assert "Agent name or ID" in result.output

    def test_create_assignment_help(self):
        """Should show help for create assignment command."""
        result = runner.invoke(app, ["create", "assignment", "--help"])

        assert result.exit_code == 0
        assert "Agent name or ID" in result.output
        assert "Environment name or ID" in result.output
        assert "Organization phone number" in result.output
        assert "--configure" in result.output

    def test_delete_assignment_help(self):
        """Should show help for delete assignment command."""
        result = runner.invoke(app, ["delete", "assignment", "--help"])

        assert result.exit_code == 0
        assert "Phone number" in result.output
        assert "--skip-unconfigure" in result.output

    def test_describe_assignment_help(self):
        """Should show help for describe assignment command."""
        result = runner.invoke(app, ["describe", "assignment", "--help"])

        assert result.exit_code == 0
        assert "Phone number" in result.output

    def test_get_help_includes_assignments(self):
        """Should show assignments in get help."""
        result = runner.invoke(app, ["get", "--help"])

        assert result.exit_code == 0
        assert "assignments" in result.output

    def test_create_help_includes_assignment(self):
        """Should show assignment in create help."""
        result = runner.invoke(app, ["create", "--help"])

        assert result.exit_code == 0
        assert "assignment" in result.output

    def test_delete_help_includes_assignment(self):
        """Should show assignment in delete help."""
        result = runner.invoke(app, ["delete", "--help"])

        assert result.exit_code == 0
        assert "assignment" in result.output

    def test_describe_help_includes_assignment(self):
        """Should show assignment in describe help."""
        result = runner.invoke(app, ["describe", "--help"])

        assert result.exit_code == 0
        assert "assignment" in result.output
