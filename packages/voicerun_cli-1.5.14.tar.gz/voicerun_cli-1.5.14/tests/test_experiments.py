"""Tests for vr experiments commands."""

import json
from unittest.mock import patch, MagicMock

from typer.testing import CliRunner

from vr_cli.cli import app


runner = CliRunner()


# ============================================================================
# Fixtures / Mock Data
# ============================================================================

MOCK_AGENT = MagicMock(id="agent-123", name="Test Agent")

MOCK_EXPERIMENTS_LIST = [
    {
        "name": "greeting_style",
        "sessionCount": 150,
        "completed": False,
        "conversionMetrics": ["booking_completed"],
        "variants": [
            {"name": "formal", "sessionCount": 75},
            {"name": "casual", "sessionCount": 75},
        ],
        "lastUpdated": "2026-03-15T12:00:00Z",
    },
    {
        "name": "voice_tone",
        "sessionCount": 200,
        "completed": True,
        "conversionMetrics": ["satisfaction"],
        "variants": [
            {"name": "warm", "sessionCount": 100},
            {"name": "neutral", "sessionCount": 100},
        ],
        "lastUpdated": "2026-03-14T08:00:00Z",
    },
]

MOCK_EXPERIMENT_DETAIL = {
    "name": "greeting_style",
    "agentId": "agent-123",
    "functionId": "fn-456",
    "sessionCount": 150,
    "completed": False,
    "conversionMetrics": ["booking_completed"],
    "stopConditions": {
        "max_iterations": 500,
        "current_iterations": 150,
        "max_confidence": 95,
        "current_confidence": 72,
        "target_outcome": "booking_completed",
        "run_test": True,
        "stop_on": 1,
    },
    "variants": [
        {
            "name": "formal",
            "sessionCount": 75,
            "conversions": {
                "booking_completed": {"count": 30, "rate": 0.4},
            },
            "outcomes": {},
        },
        {
            "name": "casual",
            "sessionCount": 75,
            "conversions": {
                "booking_completed": {"count": 38, "rate": 0.507},
            },
            "outcomes": {},
        },
    ],
    "significance": {
        "booking_completed": {
            "significance": "72.0% Confidence vs casual",
            "confidence": 72.0,
            "pValue": 0.28,
        }
    },
    "lastUpdated": "2026-03-15T12:00:00Z",
}

MOCK_TIMESERIES = {
    "resultType": "matrix",
    "result": [
        {
            "metric": {"experiment_greeting_style": "formal"},
            "values": [[1710590400, "5"], [1710594000, "3"]],
        },
        {
            "metric": {"experiment_greeting_style": "casual"},
            "values": [[1710590400, "8"], [1710594000, "6"]],
        },
    ],
}

MOCK_FUNNEL = {
    "experimentName": "greeting_style",
    "totalSessions": 150,
    "conversionMetrics": ["booking_completed"],
    "funnel": [
        {
            "variant": "formal",
            "sessions": 75,
            "metrics": {
                "booking_completed": {"sessions": 75, "conversions": 30, "rate": 0.4},
            },
            "lift": {"booking_completed": None},
        },
        {
            "variant": "casual",
            "sessions": 75,
            "metrics": {
                "booking_completed": {"sessions": 75, "conversions": 38, "rate": 0.507},
            },
            "lift": {"booking_completed": 0.267},
        },
    ],
}


# ============================================================================
# List Tests
# ============================================================================


class TestExperimentsList:
    """Tests for experiments list command."""

    def test_list_success(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": MOCK_EXPERIMENTS_LIST}):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, ["experiments", "list", "--agent", "Test Agent", "--table"])

        assert result.exit_code == 0
        assert "greeting_style" in result.output
        assert "voice_tone" in result.output
        assert "formal" in result.output
        assert "150" in result.output

    def test_list_json_output(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": MOCK_EXPERIMENTS_LIST}):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, ["experiments", "list", "--agent", "Test Agent", "--json"])

        assert result.exit_code == 0
        output = json.loads(result.output)
        assert len(output) == 2
        assert output[0]["name"] == "greeting_style"

    def test_list_empty(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": []}):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, ["experiments", "list", "--agent", "Test Agent", "--table"])

        assert result.exit_code == 0
        assert "No experiments found" in result.output

    def test_list_api_failure(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value=None):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, ["experiments", "list", "--agent", "Test Agent"])

        assert result.exit_code != 0
        assert "Failed to fetch" in result.output

    def test_list_agent_not_found(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls:
            mock_repo_cls.return_value.get_by_name_or_id.return_value = None
            result = runner.invoke(app, ["experiments", "list", "--agent", "nonexistent"])

        assert result.exit_code != 0
        assert "Agent not found" in result.output

    def test_list_no_agent(self):
        """Should fail when no agent is provided and no agent.lock exists."""
        with patch("vr_cli.commands.experiments.Path") as mock_path:
            mock_path.cwd.return_value.__truediv__ = MagicMock(return_value=MagicMock(exists=MagicMock(return_value=False)))
            result = runner.invoke(app, ["experiments", "list"])

        assert result.exit_code != 0
        assert "Agent is required" in result.output

    def test_list_calls_correct_endpoint(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": []}) as mock_req:
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            runner.invoke(app, ["experiments", "list", "--agent", "Test Agent", "--table"])

        mock_req.assert_called_once_with("/v1/experiments?agentId=agent-123")


# ============================================================================
# Describe Tests
# ============================================================================


class TestExperimentsDescribe:
    """Tests for experiments describe command."""

    def test_describe_success(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": MOCK_EXPERIMENT_DETAIL}):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, ["experiments", "describe", "greeting_style", "--agent", "Test Agent", "--table"])

        assert result.exit_code == 0
        assert "greeting_style" in result.output
        assert "150" in result.output
        assert "booking_completed" in result.output
        assert "formal" in result.output
        assert "casual" in result.output

    def test_describe_shows_stop_conditions(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": MOCK_EXPERIMENT_DETAIL}):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, ["experiments", "describe", "greeting_style", "--agent", "Test Agent", "--table"])

        assert result.exit_code == 0
        assert "Stop Conditions" in result.output
        assert "150 / 500" in result.output
        assert "72%" in result.output

    def test_describe_shows_significance(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": MOCK_EXPERIMENT_DETAIL}):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, ["experiments", "describe", "greeting_style", "--agent", "Test Agent", "--table"])

        assert result.exit_code == 0
        assert "Statistical Significance" in result.output
        assert "72.0%" in result.output
        assert "0.2800" in result.output

    def test_describe_shows_conversion_rates(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": MOCK_EXPERIMENT_DETAIL}):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, ["experiments", "describe", "greeting_style", "--agent", "Test Agent", "--table"])

        assert result.exit_code == 0
        assert "40.0%" in result.output
        assert "50.7%" in result.output

    def test_describe_json_output(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": MOCK_EXPERIMENT_DETAIL}):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, ["experiments", "describe", "greeting_style", "--agent", "Test Agent", "--json"])

        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["name"] == "greeting_style"
        assert len(output["variants"]) == 2
        assert "significance" in output

    def test_describe_api_failure(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value=None):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, ["experiments", "describe", "greeting_style", "--agent", "Test Agent"])

        assert result.exit_code != 0
        assert "Failed to fetch" in result.output

    def test_describe_calls_correct_endpoint(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": MOCK_EXPERIMENT_DETAIL}) as mock_req:
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            runner.invoke(app, ["experiments", "describe", "greeting_style", "--agent", "Test Agent", "--table"])

        mock_req.assert_called_once_with("/v1/experiments/greeting_style?agentId=agent-123")

    def test_describe_no_variants(self):
        data = {**MOCK_EXPERIMENT_DETAIL, "variants": [], "significance": {}}
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": data}):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, ["experiments", "describe", "greeting_style", "--agent", "Test Agent", "--table"])

        assert result.exit_code == 0
        assert "greeting_style" in result.output


# ============================================================================
# Timeseries Tests
# ============================================================================


class TestExperimentsTimeseries:
    """Tests for experiments timeseries command."""

    def test_timeseries_success(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": MOCK_TIMESERIES}):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, [
                "experiments", "timeseries", "greeting_style",
                "--metric", "booking_completed",
                "--start", "2026-03-15T00:00:00Z",
                "--end", "2026-03-16T00:00:00Z",
                "--agent", "Test Agent",
                "--table",
            ])

        assert result.exit_code == 0
        assert "5" in result.output
        assert "3" in result.output

    def test_timeseries_with_step(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": MOCK_TIMESERIES}) as mock_req:
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, [
                "experiments", "timeseries", "greeting_style",
                "--metric", "booking_completed",
                "--start", "2026-03-15T00:00:00Z",
                "--end", "2026-03-16T00:00:00Z",
                "--step", "1d",
                "--agent", "Test Agent",
                "--table",
            ])

        assert result.exit_code == 0
        call_url = mock_req.call_args[0][0]
        assert "step=1d" in call_url

    def test_timeseries_json_output(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": MOCK_TIMESERIES}):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, [
                "experiments", "timeseries", "greeting_style",
                "--metric", "booking_completed",
                "--start", "2026-03-15T00:00:00Z",
                "--end", "2026-03-16T00:00:00Z",
                "--agent", "Test Agent",
                "--json",
            ])

        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["resultType"] == "matrix"
        assert len(output["result"]) == 2

    def test_timeseries_empty_result(self):
        empty_data = {"resultType": "matrix", "result": []}
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": empty_data}):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, [
                "experiments", "timeseries", "greeting_style",
                "--metric", "booking_completed",
                "--start", "2026-03-15T00:00:00Z",
                "--end", "2026-03-16T00:00:00Z",
                "--agent", "Test Agent",
                "--table",
            ])

        assert result.exit_code == 0
        assert "No timeseries data found" in result.output

    def test_timeseries_api_failure(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value=None):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, [
                "experiments", "timeseries", "greeting_style",
                "--metric", "booking_completed",
                "--start", "2026-03-15T00:00:00Z",
                "--end", "2026-03-16T00:00:00Z",
                "--agent", "Test Agent",
            ])

        assert result.exit_code != 0
        assert "Failed to fetch" in result.output

    def test_timeseries_missing_required_metric(self):
        result = runner.invoke(app, [
            "experiments", "timeseries", "greeting_style",
            "--start", "2026-03-15T00:00:00Z",
            "--end", "2026-03-16T00:00:00Z",
            "--agent", "Test Agent",
        ])
        assert result.exit_code != 0

    def test_timeseries_missing_required_start(self):
        result = runner.invoke(app, [
            "experiments", "timeseries", "greeting_style",
            "--metric", "booking_completed",
            "--end", "2026-03-16T00:00:00Z",
            "--agent", "Test Agent",
        ])
        assert result.exit_code != 0

    def test_timeseries_missing_required_end(self):
        result = runner.invoke(app, [
            "experiments", "timeseries", "greeting_style",
            "--metric", "booking_completed",
            "--start", "2026-03-15T00:00:00Z",
            "--agent", "Test Agent",
        ])
        assert result.exit_code != 0

    def test_timeseries_calls_correct_endpoint(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": MOCK_TIMESERIES}) as mock_req:
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            runner.invoke(app, [
                "experiments", "timeseries", "greeting_style",
                "--metric", "booking_completed",
                "--start", "2026-03-15T00:00:00Z",
                "--end", "2026-03-16T00:00:00Z",
                "--agent", "Test Agent",
                "--table",
            ])

        call_url = mock_req.call_args[0][0]
        assert call_url.startswith("/v1/experiments/greeting_style/timeseries?")
        assert "agentId=agent-123" in call_url
        assert "metricName=booking_completed" in call_url
        assert "startDate=2026-03-15T00:00:00Z" in call_url
        assert "endDate=2026-03-16T00:00:00Z" in call_url


# ============================================================================
# Funnel Tests
# ============================================================================


class TestExperimentsFunnel:
    """Tests for experiments funnel command."""

    def test_funnel_success(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": MOCK_FUNNEL}):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, ["experiments", "funnel", "greeting_style", "--agent", "Test Agent", "--table"])

        assert result.exit_code == 0
        assert "greeting_style" in result.output
        assert "formal" in result.output
        assert "casual" in result.output
        assert "150" in result.output

    def test_funnel_shows_conversions(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": MOCK_FUNNEL}):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, ["experiments", "funnel", "greeting_style", "--agent", "Test Agent", "--table"])

        assert result.exit_code == 0
        assert "30" in result.output
        assert "38" in result.output
        assert "40.0%" in result.output
        assert "50.7%" in result.output

    def test_funnel_shows_lift(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": MOCK_FUNNEL}):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, ["experiments", "funnel", "greeting_style", "--agent", "Test Agent", "--table"])

        assert result.exit_code == 0
        assert "+26.7%" in result.output

    def test_funnel_json_output(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": MOCK_FUNNEL}):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, ["experiments", "funnel", "greeting_style", "--agent", "Test Agent", "--json"])

        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["experimentName"] == "greeting_style"
        assert len(output["funnel"]) == 2

    def test_funnel_empty(self):
        empty_data = {"experimentName": "greeting_style", "totalSessions": 0, "conversionMetrics": [], "funnel": []}
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": empty_data}):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, ["experiments", "funnel", "greeting_style", "--agent", "Test Agent", "--table"])

        assert result.exit_code == 0
        assert "No funnel data found" in result.output

    def test_funnel_api_failure(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value=None):
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, ["experiments", "funnel", "greeting_style", "--agent", "Test Agent"])

        assert result.exit_code != 0
        assert "Failed to fetch" in result.output

    def test_funnel_calls_correct_endpoint(self):
        with patch("vr_cli.commands.experiments.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.experiments.make_request", return_value={"data": MOCK_FUNNEL}) as mock_req:
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            runner.invoke(app, ["experiments", "funnel", "greeting_style", "--agent", "Test Agent", "--table"])

        mock_req.assert_called_once_with("/v1/experiments/greeting_style/funnel?agentId=agent-123")


# ============================================================================
# Help Tests
# ============================================================================


class TestExperimentsHelp:
    """Tests for experiments command help output."""

    def test_experiments_help(self):
        result = runner.invoke(app, ["experiments", "--help"])
        assert result.exit_code == 0
        assert "list" in result.output
        assert "describe" in result.output
        assert "timeseries" in result.output
        assert "funnel" in result.output

    def test_experiments_list_help(self):
        result = runner.invoke(app, ["experiments", "list", "--help"])
        assert result.exit_code == 0
        assert "--agent" in result.output

    def test_experiments_describe_help(self):
        result = runner.invoke(app, ["experiments", "describe", "--help"])
        assert result.exit_code == 0
        assert "Experiment name" in result.output
        assert "--agent" in result.output

    def test_experiments_timeseries_help(self):
        result = runner.invoke(app, ["experiments", "timeseries", "--help"])
        assert result.exit_code == 0
        assert "--metric" in result.output
        assert "--start" in result.output
        assert "--end" in result.output
        assert "--step" in result.output
        assert "--agent" in result.output

    def test_experiments_funnel_help(self):
        result = runner.invoke(app, ["experiments", "funnel", "--help"])
        assert result.exit_code == 0
        assert "Experiment name" in result.output
        assert "--agent" in result.output
