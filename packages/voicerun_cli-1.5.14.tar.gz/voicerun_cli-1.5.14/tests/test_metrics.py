"""Tests for vr metrics commands."""

import json
from unittest.mock import patch, MagicMock

from typer.testing import CliRunner

from vr_cli.cli import app


runner = CliRunner()


# ============================================================================
# Fixtures / Mock Data
# ============================================================================

MOCK_NAMES = ["bookings_made", "satisfaction_score", "response_time_ms"]

MOCK_TAGS = {
    "channel": ["phone", "web"],
    "region": ["us", "eu"],
}

MOCK_TIMESERIES = {
    "resultType": "matrix",
    "result": [
        {
            "metric": {
                "metric_name": "bookings_made",
                "metric_type": "counter",
                "organization_id": "org-123",
            },
            "values": [[1710590400, "5"], [1710594000, "3"]],
        }
    ],
}

MOCK_SESSION_METRICS = {
    "resultType": "vector",
    "result": [
        {
            "metric": {
                "metric_name": "satisfaction_score",
                "metric_type": "gauge",
                "organization_id": "org-123",
                "session_id": "session-abc",
            },
            "value": [1710590400, "4.5"],
        },
        {
            "metric": {
                "metric_name": "bookings_made",
                "metric_type": "counter",
                "organization_id": "org-123",
                "session_id": "session-abc",
            },
            "value": [1710590400, "2"],
        },
    ],
}

MOCK_AGENT = MagicMock(id="agent-123", name="Test Agent")


# ============================================================================
# Names Tests
# ============================================================================


class TestMetricsNames:
    """Tests for metrics names command."""

    def test_names_success(self):
        with patch("vr_cli.commands.metrics.make_request", return_value={"data": MOCK_NAMES}):
            result = runner.invoke(app, ["metrics", "names", "--table"])

        assert result.exit_code == 0
        assert "bookings_made" in result.output
        assert "satisfaction_score" in result.output
        assert "response_time_ms" in result.output

    def test_names_with_agent(self):
        with patch("vr_cli.commands.metrics.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.metrics.make_request", return_value={"data": MOCK_NAMES}) as mock_req:
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, ["metrics", "names", "Test Agent", "--table"])

        assert result.exit_code == 0
        call_url = mock_req.call_args[0][0]
        assert "agentId=agent-123" in call_url

    def test_names_json_output(self):
        with patch("vr_cli.commands.metrics.make_request", return_value={"data": MOCK_NAMES}):
            result = runner.invoke(app, ["metrics", "names", "--json"])

        assert result.exit_code == 0
        output = json.loads(result.output)
        assert "bookings_made" in output

    def test_names_empty(self):
        with patch("vr_cli.commands.metrics.make_request", return_value={"data": []}):
            result = runner.invoke(app, ["metrics", "names", "--table"])

        assert result.exit_code == 0
        assert "No custom metrics found" in result.output

    def test_names_api_failure(self):
        with patch("vr_cli.commands.metrics.make_request", return_value=None):
            result = runner.invoke(app, ["metrics", "names"])

        assert result.exit_code != 0
        assert "Failed to fetch" in result.output

    def test_names_agent_not_found(self):
        with patch("vr_cli.commands.metrics.AgentRepository") as mock_repo_cls:
            mock_repo_cls.return_value.get_by_name_or_id.return_value = None
            result = runner.invoke(app, ["metrics", "names", "nonexistent"])

        assert result.exit_code != 0
        assert "Agent not found" in result.output


# ============================================================================
# Tags Tests
# ============================================================================


class TestMetricsTags:
    """Tests for metrics tags command."""

    def test_tags_success(self):
        with patch("vr_cli.commands.metrics.make_request", return_value={"data": MOCK_TAGS}):
            result = runner.invoke(app, ["metrics", "tags", "--table"])

        assert result.exit_code == 0
        assert "channel" in result.output
        assert "phone" in result.output
        assert "region" in result.output

    def test_tags_with_metric_filter(self):
        with patch("vr_cli.commands.metrics.make_request", return_value={"data": MOCK_TAGS}) as mock_req:
            result = runner.invoke(app, ["metrics", "tags", "--metric", "bookings_made", "--table"])

        assert result.exit_code == 0
        call_url = mock_req.call_args[0][0]
        assert "metricName=bookings_made" in call_url

    def test_tags_with_agent(self):
        with patch("vr_cli.commands.metrics.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.metrics.make_request", return_value={"data": MOCK_TAGS}) as mock_req:
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, ["metrics", "tags", "--agent", "Test Agent", "--table"])

        assert result.exit_code == 0
        call_url = mock_req.call_args[0][0]
        assert "agentId=agent-123" in call_url

    def test_tags_json_output(self):
        with patch("vr_cli.commands.metrics.make_request", return_value={"data": MOCK_TAGS}):
            result = runner.invoke(app, ["metrics", "tags", "--json"])

        assert result.exit_code == 0
        output = json.loads(result.output)
        assert "channel" in output
        assert output["channel"] == ["phone", "web"]

    def test_tags_empty(self):
        with patch("vr_cli.commands.metrics.make_request", return_value={"data": {}}):
            result = runner.invoke(app, ["metrics", "tags", "--table"])

        assert result.exit_code == 0
        assert "No tags found" in result.output

    def test_tags_api_failure(self):
        with patch("vr_cli.commands.metrics.make_request", return_value=None):
            result = runner.invoke(app, ["metrics", "tags"])

        assert result.exit_code != 0
        assert "Failed to fetch" in result.output


# ============================================================================
# Timeseries Tests
# ============================================================================


class TestMetricsTimeseries:
    """Tests for metrics timeseries command."""

    def test_timeseries_success(self):
        with patch("vr_cli.commands.metrics.make_request", return_value={"data": MOCK_TIMESERIES}):
            result = runner.invoke(app, [
                "metrics", "timeseries", "bookings_made",
                "--start", "2026-03-15T00:00:00Z",
                "--end", "2026-03-16T00:00:00Z",
                "--table",
            ])

        assert result.exit_code == 0
        assert "bookings_made" in result.output
        assert "counter" in result.output
        assert "5" in result.output
        assert "3" in result.output

    def test_timeseries_with_all_options(self):
        with patch("vr_cli.commands.metrics.AgentRepository") as mock_repo_cls, \
             patch("vr_cli.commands.metrics.make_request", return_value={"data": MOCK_TIMESERIES}) as mock_req:
            mock_repo_cls.return_value.get_by_name_or_id.return_value = MOCK_AGENT
            result = runner.invoke(app, [
                "metrics", "timeseries", "bookings_made",
                "--start", "2026-03-15T00:00:00Z",
                "--end", "2026-03-16T00:00:00Z",
                "--step", "30m",
                "--agent", "Test Agent",
                "--environment", "env-456",
                "--tags", '{"channel":"phone"}',
                "--table",
            ])

        assert result.exit_code == 0
        call_url = mock_req.call_args[0][0]
        assert "metricName=bookings_made" in call_url
        assert "step=30m" in call_url
        assert "agentId=agent-123" in call_url
        assert "environmentId=env-456" in call_url

    def test_timeseries_json_output(self):
        with patch("vr_cli.commands.metrics.make_request", return_value={"data": MOCK_TIMESERIES}):
            result = runner.invoke(app, [
                "metrics", "timeseries", "bookings_made",
                "--start", "2026-03-15T00:00:00Z",
                "--end", "2026-03-16T00:00:00Z",
                "--json",
            ])

        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["resultType"] == "matrix"
        assert len(output["result"]) == 1

    def test_timeseries_empty_result(self):
        empty_data = {"resultType": "matrix", "result": []}
        with patch("vr_cli.commands.metrics.make_request", return_value={"data": empty_data}):
            result = runner.invoke(app, [
                "metrics", "timeseries", "bookings_made",
                "--start", "2026-03-15T00:00:00Z",
                "--end", "2026-03-16T00:00:00Z",
                "--table",
            ])

        assert result.exit_code == 0
        assert "No timeseries data found" in result.output

    def test_timeseries_api_failure(self):
        with patch("vr_cli.commands.metrics.make_request", return_value=None):
            result = runner.invoke(app, [
                "metrics", "timeseries", "bookings_made",
                "--start", "2026-03-15T00:00:00Z",
                "--end", "2026-03-16T00:00:00Z",
            ])

        assert result.exit_code != 0
        assert "Failed to fetch" in result.output

    def test_timeseries_missing_required_start(self):
        result = runner.invoke(app, [
            "metrics", "timeseries", "bookings_made",
            "--end", "2026-03-16T00:00:00Z",
        ])
        assert result.exit_code != 0

    def test_timeseries_missing_required_end(self):
        result = runner.invoke(app, [
            "metrics", "timeseries", "bookings_made",
            "--start", "2026-03-15T00:00:00Z",
        ])
        assert result.exit_code != 0


# ============================================================================
# Session Tests
# ============================================================================


class TestMetricsSession:
    """Tests for metrics session command."""

    def test_session_success(self):
        with patch("vr_cli.commands.metrics.make_request", return_value={"data": MOCK_SESSION_METRICS}):
            result = runner.invoke(app, ["metrics", "session", "session-abc", "--table"])

        assert result.exit_code == 0
        assert "satisfaction_score" in result.output
        assert "gauge" in result.output
        assert "4.5" in result.output
        assert "bookings_made" in result.output
        assert "counter" in result.output

    def test_session_json_output(self):
        with patch("vr_cli.commands.metrics.make_request", return_value={"data": MOCK_SESSION_METRICS}):
            result = runner.invoke(app, ["metrics", "session", "session-abc", "--json"])

        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["resultType"] == "vector"
        assert len(output["result"]) == 2

    def test_session_empty(self):
        empty_data = {"resultType": "vector", "result": []}
        with patch("vr_cli.commands.metrics.make_request", return_value={"data": empty_data}):
            result = runner.invoke(app, ["metrics", "session", "session-abc", "--table"])

        assert result.exit_code == 0
        assert "No metrics found for session" in result.output

    def test_session_api_failure(self):
        with patch("vr_cli.commands.metrics.make_request", return_value=None):
            result = runner.invoke(app, ["metrics", "session", "session-abc"])

        assert result.exit_code != 0
        assert "Failed to fetch" in result.output

    def test_session_calls_correct_endpoint(self):
        with patch("vr_cli.commands.metrics.make_request", return_value={"data": MOCK_SESSION_METRICS}) as mock_req:
            runner.invoke(app, ["metrics", "session", "session-abc", "--table"])

        mock_req.assert_called_once_with("/v1/custom-metrics/sessions/session-abc")


# ============================================================================
# Help Tests
# ============================================================================


class TestMetricsHelp:
    """Tests for metrics command help output."""

    def test_metrics_help(self):
        result = runner.invoke(app, ["metrics", "--help"])
        assert result.exit_code == 0
        assert "names" in result.output
        assert "tags" in result.output
        assert "timeseries" in result.output
        assert "session" in result.output

    def test_metrics_names_help(self):
        result = runner.invoke(app, ["metrics", "names", "--help"])
        assert result.exit_code == 0
        assert "Agent name or ID" in result.output

    def test_metrics_timeseries_help(self):
        result = runner.invoke(app, ["metrics", "timeseries", "--help"])
        assert result.exit_code == 0
        assert "--start" in result.output
        assert "--end" in result.output
        assert "--step" in result.output
        assert "--agent" in result.output
        assert "--tags" in result.output

    def test_metrics_session_help(self):
        result = runner.invoke(app, ["metrics", "session", "--help"])
        assert result.exit_code == 0
        assert "Session ID" in result.output
