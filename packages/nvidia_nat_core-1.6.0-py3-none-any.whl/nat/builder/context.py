# SPDX-FileCopyrightText: Copyright (c) 2025-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import typing
import uuid
from collections.abc import Awaitable
from collections.abc import Callable
from contextlib import contextmanager
from contextvars import ContextVar
from functools import cached_property

from nat.builder.intermediate_step_manager import IntermediateStepManager
from nat.builder.user_interaction_manager import UserInteractionManager
from nat.data_models.authentication import AuthenticatedContext
from nat.data_models.authentication import AuthFlowType
from nat.data_models.authentication import AuthProviderBaseConfig
from nat.data_models.interactive import HumanResponse
from nat.data_models.interactive import InteractionPrompt
from nat.data_models.intermediate_step import IntermediateStep
from nat.data_models.intermediate_step import IntermediateStepPayload
from nat.data_models.intermediate_step import IntermediateStepType
from nat.data_models.intermediate_step import StreamEventData
from nat.data_models.intermediate_step import TraceMetadata
from nat.data_models.invocation_node import InvocationNode
from nat.data_models.runtime_enum import RuntimeTypeEnum
from nat.runtime.user_metadata import RequestAttributes
from nat.utils.reactive.subject import Subject


class Singleton(type):

    def __init__(cls, name, bases, dict):
        super().__init__(name, bases, dict)
        cls.instance = None

    def __call__(cls, *args, **kw):
        if cls.instance is None:
            cls.instance = super().__call__(*args, **kw)
        return cls.instance


class ActiveFunctionContextManager:

    def __init__(self):
        self._output: typing.Any | None = None

    @property
    def output(self) -> typing.Any | None:
        return self._output

    def set_output(self, output: typing.Any):
        self._output = output


class ContextState(metaclass=Singleton):

    def __init__(self):
        self.conversation_id: ContextVar[str | None] = ContextVar("conversation_id", default=None)
        self.user_message_id: ContextVar[str | None] = ContextVar("user_message_id", default=None)
        self.user_id: ContextVar[str | None] = ContextVar("user_id", default=None)
        self.workflow_run_id: ContextVar[str | None] = ContextVar("workflow_run_id", default=None)
        self.workflow_trace_id: ContextVar[int | None] = ContextVar("workflow_trace_id", default=None)
        self.observability_trace_id: ContextVar[str | None] = ContextVar("observability_trace_id", default=None)
        self.input_message: ContextVar[typing.Any] = ContextVar("input_message", default=None)
        self.runtime_type: ContextVar[RuntimeTypeEnum] = ContextVar("runtime_type",
                                                                    default=RuntimeTypeEnum.RUN_OR_SERVE)
        self._metadata: ContextVar[RequestAttributes | None] = ContextVar("request_attributes", default=None)
        self._event_stream: ContextVar[Subject[IntermediateStep] | None] = ContextVar("event_stream", default=None)
        self._active_function: ContextVar[InvocationNode | None] = ContextVar("active_function", default=None)
        self._active_span_id_stack: ContextVar[list[str] | None] = ContextVar("active_span_id_stack", default=None)
        self._root_span_id: ContextVar[int | None] = ContextVar("root_span_id", default=None)
        self._function_path_stack: ContextVar[list[str] | None] = ContextVar("function_path_stack", default=None)
        self._latency_sensitivity_stack: ContextVar[list[int] | None] = ContextVar("latency_sensitivity_stack",
                                                                                   default=None)

        # Cross-workflow observability: parent step id/name for the root of this workflow run
        self.workflow_parent_id: ContextVar[str | None] = ContextVar("workflow_parent_id", default=None)
        self.workflow_parent_name: ContextVar[str | None] = ContextVar("workflow_parent_name", default=None)

        # Default is a lambda no-op which returns NoneType
        self.user_input_callback: ContextVar[Callable[[InteractionPrompt], Awaitable[HumanResponse | None]]
                                             | None] = ContextVar(
                                                 "user_input_callback",
                                                 default=UserInteractionManager.default_callback_handler)
        self.user_auth_callback: ContextVar[Callable[[AuthProviderBaseConfig, AuthFlowType],
                                                     Awaitable[AuthenticatedContext]]
                                            | None] = ContextVar("user_auth_callback", default=None)

    @property
    def metadata(self) -> ContextVar[RequestAttributes]:
        if self._metadata.get() is None:
            self._metadata.set(RequestAttributes())
        return typing.cast(ContextVar[RequestAttributes], self._metadata)

    @property
    def active_function(self) -> ContextVar[InvocationNode]:
        if self._active_function.get() is None:
            self._active_function.set(InvocationNode(function_id="root", function_name="root"))
        return typing.cast(ContextVar[InvocationNode], self._active_function)

    @property
    def event_stream(self) -> ContextVar[Subject[IntermediateStep]]:
        if self._event_stream.get() is None:
            self._event_stream.set(Subject())
        return typing.cast(ContextVar[Subject[IntermediateStep]], self._event_stream)

    @property
    def active_span_id_stack(self) -> ContextVar[list[str]]:
        if self._active_span_id_stack.get() is None:
            self._active_span_id_stack.set(["root"])
        return typing.cast(ContextVar[list[str]], self._active_span_id_stack)

    @property
    def function_path_stack(self) -> ContextVar[list[str]]:
        if self._function_path_stack.get() is None:
            self._function_path_stack.set([])
        return typing.cast(ContextVar[list[str]], self._function_path_stack)

    @property
    def latency_sensitivity_stack(self) -> ContextVar[list[int]]:
        if self._latency_sensitivity_stack.get() is None:
            self._latency_sensitivity_stack.set([2])
        return typing.cast(ContextVar[list[int]], self._latency_sensitivity_stack)

    @staticmethod
    def get() -> "ContextState":
        return ContextState()


class Context:

    def __init__(self, context: ContextState):
        self._context_state = context

    @property
    def input_message(self):
        """
        Retrieves the input message from the context state.

        The input_message property is used to access the message stored in the
        context state. This property returns the message as it is currently
        maintained in the context.

        Returns:
            str: The input message retrieved from the context state.
        """
        return self._context_state.input_message.get()

    @property
    def metadata(self):
        """
        Retrieves the request attributes instance from the current context state
        providing access to user-defined metadata.

        Returns:
            RequestAttributes: The instance of the request attributes
                retrieved from the context state.
        """
        return self._context_state.metadata.get()

    @property
    def user_interaction_manager(self) -> UserInteractionManager:
        """
        Return an instance of UserInteractionManager that uses
        the current context's user_input_callback.
        """
        return UserInteractionManager(self._context_state)

    @cached_property
    def intermediate_step_manager(self) -> IntermediateStepManager:
        """
        Retrieves the intermediate step manager instance from the current context state.

        This property provides access to the intermediate step manager through the context
        state, allowing interaction with intermediate step management functionalities.

        Returns:
            IntermediateStepManager: The instance of the intermediate step manager retrieved
                from the context state.
        """
        return IntermediateStepManager(self._context_state)

    @property
    def conversation_id(self) -> str | None:
        """
        This property retrieves the conversation ID which is the unique identifier for the current chat conversation.

        Returns:
            str | None
        """
        return self._context_state.conversation_id.get()

    @property
    def user_message_id(self) -> str | None:
        """
        This property retrieves the user message ID which is the unique identifier for the current user message.
        """
        return self._context_state.user_message_id.get()

    @property
    def user_id(self) -> str | None:
        """
        This property retrieves the user ID which is the unique identifier for the current user.
        """
        return self._context_state.user_id.get()

    @property
    def workflow_run_id(self) -> str | None:
        """
        Returns a stable identifier for the current workflow/agent invocation (UUID string).
        """
        return self._context_state.workflow_run_id.get()

    @property
    def workflow_trace_id(self) -> int | None:
        """
        Returns the 128-bit trace identifier for the current run, used as the OpenTelemetry trace_id.
        """
        return self._context_state.workflow_trace_id.get()

    @property
    def observability_trace_id(self) -> str | None:
        """
        Returns the root observability trace identifier for the current run.
        """
        return self._context_state.observability_trace_id.get()

    @contextmanager
    def push_active_function(self,
                             function_name: str,
                             input_data: typing.Any | None,
                             metadata: dict[str, typing.Any] | TraceMetadata | None = None):
        """
        Set the 'active_function' in context, push an invocation node,
        AND create an OTel child span for that function call.
        """
        parent_function_node = self._context_state.active_function.get()
        current_function_id = str(uuid.uuid4())
        current_function_node = InvocationNode(function_id=current_function_id,
                                               function_name=function_name,
                                               parent_id=parent_function_node.function_id,
                                               parent_name=parent_function_node.function_name)

        # 1) Set the active function in the contextvar
        fn_token = self._context_state.active_function.set(current_function_node)

        # 1b) Push function name onto path stack
        current_path = self._context_state.function_path_stack.get()
        new_path = current_path + [function_name]
        path_token = self._context_state.function_path_stack.set(new_path)

        # 2) Optionally record function start as an intermediate step
        step_manager = self.intermediate_step_manager
        step_manager.push_intermediate_step(
            IntermediateStepPayload(UUID=current_function_id,
                                    event_type=IntermediateStepType.FUNCTION_START,
                                    name=function_name,
                                    data=StreamEventData(input=input_data),
                                    metadata=metadata))

        manager = ActiveFunctionContextManager()

        try:
            yield manager  # run the function body
        finally:
            # 3) Record function end

            data = StreamEventData(input=input_data, output=manager.output)

            step_manager.push_intermediate_step(
                IntermediateStepPayload(UUID=current_function_id,
                                        event_type=IntermediateStepType.FUNCTION_END,
                                        name=function_name,
                                        data=data))

            # 4a) Pop function name from path stack
            self._context_state.function_path_stack.reset(path_token)

            # 4b) Unset the function contextvar
            self._context_state.active_function.reset(fn_token)

    @property
    def active_function(self) -> InvocationNode:
        """
        Retrieves the active function from the context state.

        This property is used to access the active function stored in the context
        state. The active function is the function that is currently being executed.
        """
        return self._context_state.active_function.get()

    @property
    def function_path(self) -> list[str]:
        """
        Returns a copy of the current function path stack.

        The function path represents the ancestry of the currently executing
        function, from root to the current function.

        Returns:
            list[str]: Copy of the function path stack.
        """
        return list(self._context_state.function_path_stack.get())

    @property
    def active_span_id(self) -> str:
        """
        Retrieves the active span ID from the context state.

        This property provides access to the active span ID stored in the context state. The active span ID represents
        the currently running function/tool/llm/agent/etc and can be used to group telemetry data together.

        Returns:
            str: The active span ID.
        """
        return self._context_state.active_span_id_stack.get()[-1]

    @property
    def user_auth_callback(self) -> Callable[[AuthProviderBaseConfig, AuthFlowType], Awaitable[AuthenticatedContext]]:
        """
        Retrieves the user authentication callback function from the context state.

        This property provides access to the user authentication callback function stored in the context state.
        The callback function is responsible for handling user authentication based on the provided configuration.

        Returns:
            Callable[[AuthenticationBaseConfig], Awaitable[AuthenticatedContext]]: The user authentication
            callback function.

        Raises:
            RuntimeError: If the user authentication callback is not set in the context.
        """
        callback = self._context_state.user_auth_callback.get()
        if callback is None:
            raise RuntimeError("User authentication callback is not set in the context.")
        return callback

    @property
    def is_evaluating(self) -> bool:
        """
        Indicates whether the current context is in evaluation mode.

        This property checks the context state to determine if the current
        operation is being performed in evaluation mode. It returns a boolean
        value indicating the evaluation status.

        Returns:
            bool: True if in evaluation mode, False otherwise.
        """
        return self._context_state.runtime_type.get() == RuntimeTypeEnum.EVALUATE

    @property
    def latency_sensitivity(self) -> int:
        """
        Returns the current latency sensitivity level.

        When multiple sensitivity levels are pushed onto the stack,
        returns the maximum value (higher integers mean higher sensitivity).

        Returns:
            int: The current effective latency sensitivity.
        """
        stack = self._context_state.latency_sensitivity_stack.get()
        return max(stack)

    @property
    def has_manual_latency_sensitivity(self) -> bool:
        """True if any @latency_sensitive decorator is active in the current scope.

        The default stack is [2] (length 1). Any push_latency_sensitivity call
        adds to the stack, making length > 1.
        """
        return len(self._context_state.latency_sensitivity_stack.get()) > 1

    @contextmanager
    def push_latency_sensitivity(self, sensitivity: int):
        """
        Push a latency sensitivity level onto the stack.

        The effective sensitivity is the maximum value across all
        pushed levels. When the context exits, the pushed level is removed.

        Args:
            sensitivity: The latency sensitivity level to push (integer).

        Yields:
            None

        Example:
            >>> ctx = Context.get()
            >>> with ctx.push_latency_sensitivity(3):
            ...     # Inside this block, sensitivity is at least 3
            ...     pass
        """
        stack = self._context_state.latency_sensitivity_stack.get()
        new_stack = stack + [sensitivity]
        token = self._context_state.latency_sensitivity_stack.set(new_stack)
        try:
            yield
        finally:
            self._context_state.latency_sensitivity_stack.reset(token)

    @staticmethod
    @contextmanager
    def scope(**kwargs):
        """
        Create a new context scope with specified context variables.

        This is primarily used for testing to create isolated context scopes.

        Args:
            **kwargs: Context variables to set (e.g., workflow_run_id="test")

        Yields:
            None

        Example:
            >>> with Context.scope(workflow_run_id="test123"):
            ...     ctx = Context.get()
            ...     print(ctx.workflow_run_id)  # "test123"
        """
        state = ContextState.get()
        tokens = []

        # Set each provided context variable
        for key, value in kwargs.items():
            if hasattr(state, key):
                context_var = getattr(state, key)
                token = context_var.set(value)
                tokens.append((context_var, token))

        try:
            yield
        finally:
            # Reset all context variables
            for context_var, token in reversed(tokens):
                context_var.reset(token)

    @staticmethod
    def get() -> "Context":
        """
        Static method to retrieve the current Context instance.

        This method creates and returns an instance of the Context class
        by obtaining the current state from the ContextState.

        Returns:
            Context: The created Context instance.
        """
        return Context(ContextState.get())
