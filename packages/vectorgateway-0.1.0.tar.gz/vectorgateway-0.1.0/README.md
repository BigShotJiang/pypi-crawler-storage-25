# VectorGateway
Protocol middleware for translating vector data across providers, vector databases, and LLM pipelines.
