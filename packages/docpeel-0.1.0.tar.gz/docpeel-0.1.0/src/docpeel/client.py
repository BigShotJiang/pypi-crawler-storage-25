"""HTTP client and resource managers for the DocPeel API."""

from __future__ import annotations

import base64
import os
from typing import Any, BinaryIO, Dict, Optional, Tuple, Union

import requests

from .errors import DocPeelError
from .models import Extraction, ExtractionListResponse

DEFAULT_BASE_URL = "https://api.docpeel.com"
DEFAULT_TIMEOUT = 120.0  # seconds

FileInput = Union[BinaryIO, bytes, bytearray, memoryview, str, os.PathLike]
"""Supported `file` argument types for ``extractions.create``.

* a binary file-like object (``open(path, 'rb')``)
* raw ``bytes`` / ``bytearray`` / ``memoryview``
* a filesystem path (``str`` or ``os.PathLike``)
"""


def _infer_content_type(file_name: Optional[str]) -> Optional[str]:
    if not file_name:
        return None
    ext = file_name.rsplit(".", 1)[-1].lower() if "." in file_name else ""
    return {
        "pdf": "application/pdf",
        "jpg": "image/jpeg",
        "jpeg": "image/jpeg",
        "png": "image/png",
        "webp": "image/webp",
    }.get(ext)


def _coerce_to_base64(
    file: FileInput,
    file_name: Optional[str],
    content_type: Optional[str],
) -> Tuple[str, str, str]:
    """Normalise the ``file`` argument into ``(base64_string, file_name, content_type)``."""

    # Path-like — read it
    if isinstance(file, (str, os.PathLike)):
        path = os.fspath(file)
        resolved_name = file_name or os.path.basename(path)
        with open(path, "rb") as f:
            raw = f.read()
        ct = content_type or _infer_content_type(resolved_name) or "application/octet-stream"
        return base64.b64encode(raw).decode("ascii"), resolved_name, ct

    # Raw bytes
    if isinstance(file, (bytes, bytearray, memoryview)):
        if not file_name:
            raise ValueError(
                "`file_name` is required when `file` is raw bytes (so DocPeel can detect the type)."
            )
        raw = bytes(file)
        ct = content_type or _infer_content_type(file_name) or "application/octet-stream"
        return base64.b64encode(raw).decode("ascii"), file_name, ct

    # File-like
    if hasattr(file, "read"):
        resolved_name = file_name or getattr(file, "name", None)
        if resolved_name and os.sep in resolved_name:
            resolved_name = os.path.basename(resolved_name)
        if not resolved_name:
            raise ValueError(
                "`file_name` is required when `file` is a file-like object without a `.name`."
            )
        raw = file.read()
        if isinstance(raw, str):
            raise TypeError(
                "File-like object must be opened in binary mode (e.g. `open(path, 'rb')`)."
            )
        ct = content_type or _infer_content_type(resolved_name) or "application/octet-stream"
        return base64.b64encode(raw).decode("ascii"), resolved_name, ct

    raise TypeError(
        "Unsupported `file` type. Pass a path, bytes, or a binary file-like object."
    )


class _HttpClient:
    """Thin wrapper around :mod:`requests` that adds auth, JSON parsing, and
    DocPeel-style error handling.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str,
        timeout: float,
        session: Optional[requests.Session] = None,
        user_agent: str = "docpeel-python/0.1.0",
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._session = session or requests.Session()
        self._user_agent = user_agent

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        url = f"{self._base_url}{path}"
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Accept": "application/json",
            "User-Agent": self._user_agent,
        }
        if json is not None:
            headers["Content-Type"] = "application/json"

        try:
            resp = self._session.request(
                method,
                url,
                headers=headers,
                params=params,
                json=json,
                timeout=self._timeout,
            )
        except requests.RequestException as exc:
            raise DocPeelError(
                status=0,
                code="network_error",
                message=f"Network error talking to DocPeel: {exc}",
            ) from exc

        try:
            payload = resp.json() if resp.content else None
        except ValueError:
            payload = None

        if not resp.ok:
            err = (payload or {}).get("error") or {}
            raise DocPeelError(
                status=resp.status_code,
                code=err.get("code") or "http_error",
                message=err.get("message") or f"Request failed with status {resp.status_code}",
                request_id=(payload or {}).get("request_id"),
            )

        return payload or {}


class Extractions:
    """Operations on the ``/v1/extractions`` resource."""

    def __init__(self, http: _HttpClient) -> None:
        self._http = http

    def create(
        self,
        file: Optional[FileInput] = None,
        *,
        file_b64: Optional[str] = None,
        file_name: Optional[str] = None,
        content_type: Optional[str] = None,
        template_id: Optional[str] = None,
    ) -> Extraction:
        """Submit a document for extraction. Returns the completed result.

        The body is sent as JSON with the file base64-encoded, so this works
        in serverless environments and behind strict egress proxies.

        Pass **either**:

        - ``file_b64`` \u2014 a base64 string you already have (recommended; no
          conversion happens). A ``data:`` URI prefix is allowed and stripped.
          Requires ``file_name``.
        - ``file`` \u2014 a path, bytes, or binary file-like; the SDK reads it
          and base64-encodes it for you.

        Args:
            file:         Path, bytes, or binary file-like object.
            file_b64:     Pre-encoded base64 string of the document bytes.
            file_name:    Required for bytes / unnamed file-likes / ``file_b64``.
            content_type: MIME type. Auto-detected from ``file_name`` when possible.
            template_id:  Optional built-in or custom template ID.
        """

        if file_b64 is not None and file is not None:
            raise ValueError("Pass either `file` or `file_b64`, not both.")

        if file_b64 is not None:
            if not file_name:
                raise ValueError("`file_name` is required when passing `file_b64`.")
            cleaned = file_b64.split(",", 1)[1] if file_b64.startswith("data:") else file_b64
            b64 = cleaned
            name = file_name
            ct = content_type or _infer_content_type(file_name) or "application/octet-stream"
        elif file is not None:
            b64, name, ct = _coerce_to_base64(file, file_name, content_type)
        else:
            raise ValueError("Either `file` or `file_b64` is required.")

        body: Dict[str, Any] = {
            "file":         b64,
            "file_name":    name,
            "content_type": ct,
        }
        if template_id:
            body["template_id"] = template_id

        payload = self._http.request("POST", "/v1/extractions", json=body)
        return Extraction.from_dict(payload.get("extraction") or {})

    def retrieve(self, extraction_id: str) -> Extraction:
        """Fetch a single extraction by ID."""
        from urllib.parse import quote

        payload = self._http.request(
            "GET", f"/v1/extractions/{quote(extraction_id, safe='')}"
        )
        return Extraction.from_dict(payload.get("extraction") or {})

    def list(
        self,
        *,
        limit: Optional[int] = None,
        cursor: Optional[str] = None,
    ) -> ExtractionListResponse:
        """List recent extractions for the workspace (cursor-paginated)."""

        params: Dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor

        payload = self._http.request("GET", "/v1/extractions", params=params or None)
        return ExtractionListResponse.from_dict(payload)


class DocPeel:
    """The main DocPeel API client.

    Args:
        api_key:    Your DocPeel API key (e.g. ``dpk_live_...``). Falls back to the
                    ``DOCPEEL_API_KEY`` environment variable when omitted.
        base_url:   Override the API base URL. Defaults to ``https://api.docpeel.com``.
        timeout:    Per-request timeout in seconds. Defaults to 120.
        session:    Optional pre-configured :class:`requests.Session` (for retries,
                    custom adapters, etc).

    Example::

        from docpeel import DocPeel
        client = DocPeel(api_key="dpk_live_...")
        ext = client.extractions.create("invoice.pdf")
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT,
        session: Optional[requests.Session] = None,
    ) -> None:
        resolved_key = api_key or os.environ.get("DOCPEEL_API_KEY")
        if not resolved_key:
            raise ValueError(
                "DocPeel: `api_key` is required (or set DOCPEEL_API_KEY env var)."
            )

        self._http = _HttpClient(
            api_key=resolved_key,
            base_url=base_url or DEFAULT_BASE_URL,
            timeout=timeout,
            session=session,
        )
        self.extractions: Extractions = Extractions(self._http)

    def ping(self) -> Dict[str, Any]:
        """Verify the API key. Returns key + workspace metadata."""
        return self._http.request("GET", "/v1/me")
