"""
docpeel — official Python SDK for the DocPeel API.

Quickstart::

    from docpeel import DocPeel

    client = DocPeel(api_key="dpk_live_...")

    with open("invoice.pdf", "rb") as f:
        extraction = client.extractions.create(file=f, file_name="invoice.pdf")

    for field in extraction.fields:
        print(field.field, "=", field.value)
"""

from .client import DocPeel, Extractions
from .errors import DocPeelError
from .models import Extraction, ExtractionField, ExtractionListResponse

__all__ = [
    "DocPeel",
    "Extractions",
    "DocPeelError",
    "Extraction",
    "ExtractionField",
    "ExtractionListResponse",
]

__version__ = "0.1.0"
