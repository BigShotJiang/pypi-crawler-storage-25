"""Custom exceptions for the DocPeel SDK."""

from __future__ import annotations

from typing import Optional


class DocPeelError(Exception):
    """Raised when the DocPeel API returns an error response.

    Attributes:
        status:      HTTP status code returned by the API.
        code:        Machine-readable error code (e.g. ``rate_limited``).
        message:     Human-readable error message.
        request_id:  Unique request identifier (useful when contacting support).
    """

    def __init__(
        self,
        status: int,
        code: str,
        message: str,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.status: int = status
        self.code: str = code
        self.message: str = message
        self.request_id: Optional[str] = request_id

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"DocPeelError(status={self.status!r}, code={self.code!r}, "
            f"message={self.message!r}, request_id={self.request_id!r})"
        )
