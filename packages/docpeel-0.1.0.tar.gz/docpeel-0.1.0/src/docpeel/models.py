"""Typed data models returned by the DocPeel API."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional


@dataclass
class ExtractionField:
    """A single field extracted from a document."""

    id: int
    field: str
    value: str
    confidence: float
    explanation: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ExtractionField":
        return cls(
            id=data.get("id", 0),
            field=data.get("field", ""),
            value=data.get("value", ""),
            confidence=float(data.get("confidence", 0)),
            explanation=data.get("explanation", ""),
        )


@dataclass
class Extraction:
    """A completed (or in-progress) document extraction."""

    id: str
    status: Literal["processing", "completed", "failed"]
    file_name: str
    file_type: str
    template_id: Optional[str]
    confidence: Optional[float]
    fields: List[ExtractionField] = field(default_factory=list)
    data: Dict[str, Any] = field(default_factory=dict)
    source: Optional[str] = None
    credits_used: Optional[int] = None
    error_message: Optional[str] = None
    created_at: Optional[str] = None
    completed_at: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Extraction":
        return cls(
            id=data.get("id", ""),
            status=data.get("status", "processing"),
            file_name=data.get("file_name", ""),
            file_type=data.get("file_type", ""),
            template_id=data.get("template_id"),
            confidence=data.get("confidence"),
            fields=[ExtractionField.from_dict(f) for f in data.get("fields") or []],
            data=data.get("data") or {},
            source=data.get("source"),
            credits_used=data.get("credits_used"),
            error_message=data.get("error_message"),
            created_at=data.get("created_at"),
            completed_at=data.get("completed_at"),
        )


@dataclass
class ExtractionListResponse:
    """Paginated list of extractions."""

    extractions: List[Extraction]
    next_cursor: Optional[str]
    request_id: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ExtractionListResponse":
        return cls(
            extractions=[Extraction.from_dict(e) for e in data.get("extractions") or []],
            next_cursor=data.get("next_cursor"),
            request_id=data.get("request_id"),
        )
