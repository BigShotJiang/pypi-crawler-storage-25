"""Pure filter and sort helpers for dataframe preview popups."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, time
from decimal import Decimal, InvalidOperation
from typing import Literal

import polars as pl

NULL_FILTER_VALUE = object()
ColumnFilterKind = Literal["distinct", "text", "date", "time", "number", "boolean", "all"]
TextFilterOperation = Literal["equals", "not_equals", "begins_with", "ends_with", "contains", "not_contains"]
TextFilterCondition = tuple[TextFilterOperation, str]
DateFilterRange = tuple[str, str]
TimeFilterRange = tuple[str, str]
BooleanFilterValue = Literal["true", "false", "blank"]
NumberFilterRange = tuple[str, str]


@dataclass(frozen=True)
class PreviewSortState:
    """Immutable multi-column sort state for a dataframe preview.

    Args:
        columns: Ordered ``(column_name, descending)`` sort clauses.
    """

    columns: tuple[tuple[str, bool], ...] = ()

    def apply(self, column_name: str, *, descending: bool, append: bool) -> PreviewSortState:
        """Return state with a column sort applied.

        Args:
            column_name: Column to sort.
            descending: Whether the sort should be descending.
            append: Whether to append a new column to the active sort chain.

        Returns:
            Updated sort state.
        """

        normalized_column = str(column_name)
        updated_sorts = list(self.columns)
        existing_rank = self.rank_for(normalized_column)
        if existing_rank is not None:
            updated_sorts[existing_rank - 1] = (normalized_column, bool(descending))
        elif append:
            updated_sorts.append((normalized_column, bool(descending)))
        else:
            updated_sorts = [(normalized_column, bool(descending))]
        return PreviewSortState(tuple(updated_sorts))

    def clear(self) -> PreviewSortState:
        """Return empty sort state."""

        if not self.columns:
            return self
        return PreviewSortState()

    def remove(self, column_name: str) -> PreviewSortState:
        """Return state with a column removed from the sort chain.

        Args:
            column_name: Column to remove.

        Returns:
            Updated sort state.
        """

        normalized_column = str(column_name)
        updated_sorts = tuple(
            (active_name, active_descending)
            for active_name, active_descending in self.columns
            if active_name != normalized_column
        )
        if len(updated_sorts) == len(self.columns):
            return self
        return PreviewSortState(updated_sorts)

    def rank_for(self, column_name: str) -> int | None:
        """Return the one-based sort rank for a column, if active.

        Args:
            column_name: Column to inspect.

        Returns:
            One-based sort rank, or ``None`` when inactive.
        """

        for index, (active_name, _descending) in enumerate(self.columns, start=1):
            if active_name == column_name:
                return index
        return None

    def direction_for(self, column_name: str) -> bool | None:
        """Return whether a column sorts descending, if active.

        Args:
            column_name: Column to inspect.

        Returns:
            ``True`` for descending, ``False`` for ascending, or ``None`` when inactive.
        """

        for active_name, active_descending in self.columns:
            if active_name == column_name:
                return active_descending
        return None

    def primary_column(self) -> str | None:
        """Return the primary sort column, if any."""

        if not self.columns:
            return None
        return self.columns[0][0]


@dataclass(frozen=True)
class ColumnFilter:
    """Pure filter state for one dataframe preview column.

    Args:
        column_name: Column being filtered.
        kind: Filter family.
        operation: Operation within the filter family.
        values: Operation values.
    """

    column_name: str
    kind: ColumnFilterKind
    operation: str
    values: tuple[object, ...]

    @classmethod
    def distinct(cls, column_name: str, selected_values: tuple[object, ...]) -> ColumnFilter:
        """Build a distinct-value filter state.

        Args:
            column_name: Column being filtered.
            selected_values: Values selected by the distinct checklist.

        Returns:
            Distinct-value filter state.
        """

        return cls(column_name=str(column_name), kind="distinct", operation="is_in", values=selected_values)

    @classmethod
    def text(cls, column_name: str, operation: TextFilterOperation, value: str) -> ColumnFilter:
        """Build a text filter state.

        Args:
            column_name: Column being filtered.
            operation: Text operation to apply.
            value: Text value to compare.

        Returns:
            Text filter state.
        """

        return cls(column_name=str(column_name), kind="text", operation=operation, values=(value,))

    @classmethod
    def text_conditions(cls, column_name: str, conditions: tuple[TextFilterCondition, ...]) -> ColumnFilter:
        """Build a multi-condition text filter state.

        Args:
            column_name: Column being filtered.
            conditions: Ordered ``(operation, value)`` text conditions. Conditions are combined with AND.

        Returns:
            Text filter state containing all non-empty conditions.
        """

        return cls(column_name=str(column_name), kind="text", operation="all", values=conditions)

    @classmethod
    def date_range(cls, column_name: str, start_date: str, end_date: str) -> ColumnFilter:
        """Build an inclusive date range filter state.

        Args:
            column_name: Column being filtered.
            start_date: Inclusive ISO start date.
            end_date: Inclusive ISO end date.

        Returns:
            Date filter state.
        """

        return cls(column_name=str(column_name), kind="date", operation="range", values=((start_date, end_date),))

    @classmethod
    def date_ranges(cls, column_name: str, ranges: tuple[DateFilterRange, ...]) -> ColumnFilter:
        """Build a multi-range date filter state.

        Args:
            column_name: Column being filtered.
            ranges: Inclusive ``(start_date, end_date)`` ranges. Ranges are combined with OR.

        Returns:
            Date filter state containing all ranges.
        """

        return cls(column_name=str(column_name), kind="date", operation="ranges", values=ranges)

    @classmethod
    def time_range(cls, column_name: str, start_time: str, end_time: str) -> ColumnFilter:
        """Build an inclusive time range filter state.

        Args:
            column_name: Column being filtered.
            start_time: Inclusive ISO start time.
            end_time: Inclusive ISO end time.

        Returns:
            Time filter state.
        """

        return cls(column_name=str(column_name), kind="time", operation="range", values=((start_time, end_time),))

    @classmethod
    def time_ranges(cls, column_name: str, ranges: tuple[TimeFilterRange, ...]) -> ColumnFilter:
        """Build a multi-range time filter state.

        Args:
            column_name: Column being filtered.
            ranges: Inclusive ``(start_time, end_time)`` ranges. Ranges are combined with OR.

        Returns:
            Time filter state containing all ranges.
        """

        return cls(column_name=str(column_name), kind="time", operation="ranges", values=ranges)

    @classmethod
    def number_range(cls, column_name: str, min_value: str, max_value: str) -> ColumnFilter:
        """Build an inclusive numeric range filter state.

        Args:
            column_name: Column being filtered.
            min_value: Inclusive lower bound. Blank means no lower bound.
            max_value: Inclusive upper bound. Blank means no upper bound.

        Returns:
            Numeric filter state.
        """

        return cls(column_name=str(column_name), kind="number", operation="range", values=((min_value, max_value),))

    @classmethod
    def number_ranges(cls, column_name: str, ranges: tuple[NumberFilterRange, ...]) -> ColumnFilter:
        """Build a multi-range numeric filter state.

        Args:
            column_name: Column being filtered.
            ranges: Inclusive ``(min_value, max_value)`` ranges. Ranges are combined with OR.

        Returns:
            Numeric filter state containing all non-empty ranges.
        """

        return cls(column_name=str(column_name), kind="number", operation="ranges", values=ranges)

    @classmethod
    def boolean(cls, column_name: str, value: BooleanFilterValue) -> ColumnFilter:
        """Build a boolean filter state.

        Args:
            column_name: Column being filtered.
            value: Boolean value selector. ``"blank"`` matches nulls.

        Returns:
            Boolean filter state.
        """

        return cls(column_name=str(column_name), kind="boolean", operation="is", values=(value,))

    @classmethod
    def all(cls, column_name: str, filters: tuple[ColumnFilter, ...]) -> ColumnFilter:
        """Build a composite filter state.

        Args:
            column_name: Column being filtered.
            filters: Column filters to combine with AND.

        Returns:
            Composite filter state containing active child filters.
        """

        active_filters = tuple(column_filter for column_filter in filters if column_filter.values)
        return cls(column_name=str(column_name), kind="all", operation="all", values=active_filters)


def column_filter_component(column_filter: ColumnFilter | None, kind: str) -> ColumnFilter | None:
    """Return the first matching child filter from a plain or composite column filter.

    Args:
        column_filter: Filter to inspect.
        kind: Filter family to find.

    Returns:
        Matching filter, or ``None`` when absent.
    """

    if column_filter is None:
        return None
    if column_filter.kind == kind:
        return column_filter
    if column_filter.kind != "all":
        return None
    for value in column_filter.values:
        if isinstance(value, ColumnFilter) and value.kind == kind:
            return value
    return None


def build_column_filter_expression(column_filter: ColumnFilter, *, dtype: pl.DataType | None = None):
    """Build a Polars expression for one preview column filter.

    Args:
        column_filter: Filter state to compile.
        dtype: Optional source dtype used by dtype-sensitive operations.

    Returns:
        Polars expression for the filter, or ``None`` when the filter is inactive.
    """

    if column_filter.kind == "distinct":
        return build_distinct_value_filter_expression(column_filter.column_name, column_filter.values, dtype=dtype)
    if column_filter.kind == "text":
        return _build_text_filter_expression(column_filter)
    if column_filter.kind == "date":
        return _build_date_filter_expression(column_filter, dtype=dtype)
    if column_filter.kind == "time":
        return _build_time_filter_expression(column_filter)
    if column_filter.kind == "number":
        return _build_number_filter_expression(column_filter, dtype=dtype)
    if column_filter.kind == "boolean":
        return _build_boolean_filter_expression(column_filter)
    if column_filter.kind == "all":
        return _build_all_filter_expression(column_filter, dtype=dtype)
    raise ValueError(f"Unsupported column filter kind: {column_filter.kind}")


def build_distinct_value_filter_expression(
    column_name: str,
    selected_values: tuple[object, ...],
    *,
    dtype: pl.DataType | None = None,
):
    """Build a Polars expression for a preview distinct-value filter.

    Args:
        column_name: Column to filter.
        selected_values: Values selected by the popup.
        dtype: Optional column dtype used to preserve temporal precision.

    Returns:
        Polars expression for the selected values, or ``None`` when no values are selected.
    """

    if not selected_values:
        return None
    column = pl.col(column_name)
    include_null = any(value is NULL_FILTER_VALUE for value in selected_values)
    concrete_values = [value for value in selected_values if value is not NULL_FILTER_VALUE]
    expression = None
    if concrete_values:
        values = concrete_values if dtype is None else pl.Series(concrete_values, dtype=dtype).implode()
        expression = column.is_in(values)
    if include_null:
        null_expression = column.is_null()
        expression = null_expression if expression is None else (expression | null_expression)
    return expression


def _build_all_filter_expression(column_filter: ColumnFilter, *, dtype: pl.DataType | None = None):
    expressions = []
    for value in column_filter.values:
        if not isinstance(value, ColumnFilter):
            raise TypeError("Composite column filters must contain ColumnFilter values")
        expression = build_column_filter_expression(value, dtype=dtype)
        if expression is not None:
            expressions.append(expression)
    if not expressions:
        return None
    expression = expressions[0]
    for next_expression in expressions[1:]:
        expression = expression & next_expression
    return expression


def _build_text_filter_expression(column_filter: ColumnFilter):
    if not column_filter.values:
        return None
    if column_filter.operation == "all":
        expressions = [
            _build_single_text_filter_expression(column_filter.column_name, str(operation), str(value))
            for operation, value in column_filter.values
            if str(value) != ""
        ]
        expressions = [expression for expression in expressions if expression is not None]
        if not expressions:
            return None
        expression = expressions[0]
        for next_expression in expressions[1:]:
            expression = expression & next_expression
        return expression
    value = str(column_filter.values[0])
    return _build_single_text_filter_expression(column_filter.column_name, column_filter.operation, value)


def _build_single_text_filter_expression(column_name: str, operation: str, value: str):
    if value == "":
        return None
    column = pl.col(column_name).cast(pl.Utf8, strict=False).fill_null("")
    if operation == "equals":
        return column == value
    if operation == "not_equals":
        return column != value
    if operation == "begins_with":
        return column.str.starts_with(value)
    if operation == "ends_with":
        return column.str.ends_with(value)
    if operation == "contains":
        return column.str.contains(value, literal=True)
    if operation == "not_contains":
        return ~column.str.contains(value, literal=True)
    raise ValueError(f"Unsupported text filter operation: {operation}")


def _build_date_filter_expression(column_filter: ColumnFilter, *, dtype: pl.DataType | None = None):
    if not column_filter.values:
        return None
    if column_filter.operation == "ranges":
        expressions = [
            _build_single_date_range_filter_expression(column_filter.column_name, str(start), str(end), dtype=dtype)
            for start, end in column_filter.values
            if str(start) != "" and str(end) != ""
        ]
        expressions = [expression for expression in expressions if expression is not None]
        if not expressions:
            return None
        expression = expressions[0]
        for next_expression in expressions[1:]:
            expression = expression | next_expression
        return expression
    if column_filter.operation == "range":
        start, end = column_filter.values[0]
        return _build_single_date_range_filter_expression(column_filter.column_name, str(start), str(end), dtype=dtype)
    raise ValueError(f"Unsupported date filter operation: {column_filter.operation}")


def _build_single_date_range_filter_expression(
    column_name: str,
    start_value: str,
    end_value: str,
    *,
    dtype: pl.DataType | None = None,
):
    if start_value == "" or end_value == "":
        return None
    start_date = date.fromisoformat(start_value)
    end_date = date.fromisoformat(end_value)
    if start_date > end_date:
        start_date, end_date = end_date, start_date
    column = pl.col(column_name)
    if dtype is not None and dtype.base_type() == pl.Datetime:
        column = column.dt.date()
    return (column >= start_date) & (column <= end_date)


def _build_time_filter_expression(column_filter: ColumnFilter):
    if not column_filter.values:
        return None
    if column_filter.operation == "ranges":
        expressions = [
            _build_single_time_range_filter_expression(column_filter.column_name, str(start), str(end))
            for start, end in column_filter.values
            if str(start) != "" and str(end) != ""
        ]
        expressions = [expression for expression in expressions if expression is not None]
        if not expressions:
            return None
        expression = expressions[0]
        for next_expression in expressions[1:]:
            expression = expression | next_expression
        return expression
    if column_filter.operation == "range":
        start, end = column_filter.values[0]
        return _build_single_time_range_filter_expression(column_filter.column_name, str(start), str(end))
    raise ValueError(f"Unsupported time filter operation: {column_filter.operation}")


def _build_single_time_range_filter_expression(
    column_name: str,
    start_value: str,
    end_value: str,
):
    if start_value == "" or end_value == "":
        return None
    start_time = time.fromisoformat(start_value)
    end_time = time.fromisoformat(end_value)
    if start_time > end_time:
        start_time, end_time = end_time, start_time
    column = pl.col(column_name)
    return (column >= start_time) & (column <= end_time)


def _build_number_filter_expression(column_filter: ColumnFilter, *, dtype: pl.DataType | None = None):
    if not column_filter.values:
        return None
    if column_filter.operation == "ranges":
        expressions = [
            _build_single_number_range_filter_expression(
                column_filter.column_name,
                str(min_value),
                str(max_value),
                dtype=dtype,
            )
            for min_value, max_value in column_filter.values
            if str(min_value).strip() != "" or str(max_value).strip() != ""
        ]
        expressions = [expression for expression in expressions if expression is not None]
        if not expressions:
            return None
        expression = expressions[0]
        for next_expression in expressions[1:]:
            expression = expression | next_expression
        return expression
    if column_filter.operation == "range":
        min_value, max_value = column_filter.values[0]
        return _build_single_number_range_filter_expression(
            column_filter.column_name,
            str(min_value),
            str(max_value),
            dtype=dtype,
        )
    raise ValueError(f"Unsupported number filter operation: {column_filter.operation}")


def _build_single_number_range_filter_expression(
    column_name: str,
    min_value: str,
    max_value: str,
    *,
    dtype: pl.DataType | None = None,
):
    min_value = min_value.strip()
    max_value = max_value.strip()
    if min_value == "" and max_value == "":
        return None
    min_value, max_value = _normalized_number_bounds(min_value, max_value)
    column = pl.col(column_name)
    if dtype is None:
        column = column.cast(pl.Float64, strict=False)
    expression = None
    if min_value != "":
        expression = column >= _number_filter_literal(min_value, dtype=dtype)
    if max_value != "":
        max_expression = column <= _number_filter_literal(max_value, dtype=dtype)
        expression = max_expression if expression is None else expression & max_expression
    return expression


def _number_filter_literal(value: str, *, dtype: pl.DataType | None = None):
    literal = pl.lit(value)
    if dtype is None:
        return literal.cast(pl.Float64, strict=False)
    return literal.cast(dtype, strict=False)


def _normalized_number_bounds(min_value: str, max_value: str) -> tuple[str, str]:
    if min_value == "" or max_value == "":
        return min_value, max_value
    try:
        min_decimal = Decimal(min_value)
        max_decimal = Decimal(max_value)
    except InvalidOperation:
        return min_value, max_value
    if min_decimal > max_decimal:
        return max_value, min_value
    return min_value, max_value


def _build_boolean_filter_expression(column_filter: ColumnFilter):
    if not column_filter.values:
        return None
    value = str(column_filter.values[0])
    column = pl.col(column_filter.column_name)
    if value == "true":
        return column.is_not_null() & column
    if value == "false":
        return column.is_not_null() & ~column
    if value == "blank":
        return column.is_null()
    raise ValueError(f"Unsupported boolean filter value: {value}")


def should_clear_distinct_filter(
    selected_values: tuple[object, ...],
    all_values: tuple[object, ...],
    *,
    complete_domain: bool,
) -> bool:
    """Return whether selected values represent an inactive popup filter.

    Args:
        selected_values: Values selected by the popup.
        all_values: Values available in the popup list.
        complete_domain: Whether ``all_values`` covers the full column domain.

    Returns:
        ``True`` when the filter should be removed.
    """

    return not selected_values or (complete_domain and len(selected_values) == len(all_values))


def merge_selected_values(
    selected_values: tuple[object, ...],
    values: list[tuple[str, object]],
) -> list[tuple[str, object]]:
    """Merge active selected values in front of the loaded value list.

    Args:
        selected_values: Active selected values for a column.
        values: Loaded ``(label, value)`` rows from the preview or distinct-value query.

    Returns:
        Merged values with active selections first and duplicates removed.
    """

    if not selected_values:
        return values
    seen = set()
    merged: list[tuple[str, object]] = []
    for value in selected_values:
        label = "(blank)" if value is NULL_FILTER_VALUE else str(value)
        merged.append((label, value))
        seen.add(value_identity(value))
    for label, value in values:
        identity = value_identity(value)
        if identity in seen:
            continue
        merged.append((label, value))
        seen.add(identity)
    return merged


def value_identity(value: object) -> tuple[str, object]:
    """Return a stable identity for popup filter values."""

    if value is NULL_FILTER_VALUE:
        return ("null", "__blank__")
    return (type(value).__name__, value)
