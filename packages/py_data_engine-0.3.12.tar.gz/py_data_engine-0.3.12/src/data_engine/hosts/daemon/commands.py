"""Daemon IPC command routing."""

from __future__ import annotations

from dataclasses import asdict
import threading
from typing import TYPE_CHECKING, Any

from data_engine.hosts.daemon.runtime_commands import DaemonRuntimeCommandHandler
from data_engine.hosts.daemon.state_sync import DaemonStateSyncHandler

if TYPE_CHECKING:
    from data_engine.hosts.daemon.app import DataEngineDaemonService


class DaemonCommandHandler:
    """Route daemon IPC commands onto narrower host collaborators."""

    def __init__(self, service: "DataEngineDaemonService") -> None:
        self.service = service
        self.runtime_commands = DaemonRuntimeCommandHandler(service)
        self.state_sync = DaemonStateSyncHandler(service)

    def handle(self, payload: Any) -> dict[str, Any]:
        if not isinstance(payload, dict):
            return {"ok": False, "error": "Invalid command payload."}
        command = str(payload.get("command", ""))
        request_id = str(payload.get("request_id", "")).strip() or None
        with self.service._timed_operation(
            "daemon.command",
            command or "unknown",
            fields={"workspace": self.service.paths.workspace_id, "request_id": request_id},
        ):
            if command == "daemon_ping":
                return {"ok": True, "workspace_id": self.service.paths.workspace_id}
            if command == "daemon_status":
                since_version_raw = payload.get("since_version")
                since_version = int(since_version_raw) if isinstance(since_version_raw, int | float) else None
                since_event_sequence_raw = payload.get("since_event_sequence")
                since_event_sequence = (
                    int(since_event_sequence_raw)
                    if isinstance(since_event_sequence_raw, int | float)
                    else None
                )
                return {
                    "ok": True,
                    "status": self.state_sync.status_payload(
                        since_version=since_version,
                        since_event_sequence=since_event_sequence,
                    ),
                }
            if command == "wait_for_daemon_status":
                since_version_raw = payload.get("since_version")
                since_version = int(since_version_raw) if isinstance(since_version_raw, int | float) else 0
                since_event_sequence_raw = payload.get("since_event_sequence")
                since_event_sequence = (
                    int(since_event_sequence_raw)
                    if isinstance(since_event_sequence_raw, int | float)
                    else 0
                )
                timeout_ms_raw = payload.get("timeout_ms")
                timeout_ms = int(timeout_ms_raw) if isinstance(timeout_ms_raw, int | float) else 0
                timeout_seconds = min(max(timeout_ms / 1000.0, 0.0), 30.0)
                return {
                    "ok": True,
                    "status": self.state_sync.wait_for_status_payload(
                        since_version=since_version,
                        since_event_sequence=since_event_sequence,
                        timeout_seconds=timeout_seconds,
                    ),
                }
            if command == "list_flows":
                return {"ok": True, "flows": [asdict(card) for card in self.state_sync.load_flow_cards()]}
            if command == "get_flow":
                name = str(payload.get("name", ""))
                flow = next((card for card in self.state_sync.load_flow_cards() if card.name == name), None)
                if flow is None:
                    return {"ok": False, "error": f"Unknown flow: {name}"}
                return {"ok": True, "flow": asdict(flow)}
            if command == "refresh_flows":
                return {"ok": True, "flows": [asdict(card) for card in self.state_sync.load_flow_cards(force=True)]}
            if command == "run_flow":
                raw_inputs = payload.get("inputs")
                return self.runtime_commands.run_flow(
                    name=str(payload.get("name", "")),
                    wait=bool(payload.get("wait", False)),
                    inputs=raw_inputs if isinstance(raw_inputs, dict) else None,
                    request_id=request_id,
                )
            if command == "start_engine":
                return self.runtime_commands.start_engine(request_id=request_id)
            if command == "stop_engine":
                return self.runtime_commands.stop_engine(
                    request_id=request_id,
                    shutdown_when_idle=bool(payload.get("shutdown_when_idle", False)),
                )
            if command == "stop_flow":
                return self.runtime_commands.stop_flow(str(payload.get("name", "")), request_id=request_id)
            if command == "shutdown_daemon":
                self.service.host.shutdown_event.set()
                threading.Thread(target=self.service._wake_listener, daemon=True).start()
                return {"ok": True}
            return {"ok": False, "error": f"Unknown command: {command}"}

    def checkpoint_once(self, *, status: str) -> None:
        self.state_sync.checkpoint_once(status=status)

    def refresh_observer_snapshot(self) -> None:
        self.state_sync.refresh_observer_snapshot()

    def update_daemon_state(self, *, status: str) -> None:
        self.state_sync.update_daemon_state(status=status)


__all__ = ["DaemonCommandHandler"]
