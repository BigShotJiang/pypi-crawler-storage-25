import typing

from modern_di import errors, types
from modern_di.providers.abstract import AbstractProvider


class ProvidersRegistry:
    __slots__ = ("_providers",)

    def __init__(self) -> None:
        self._providers: dict[type, AbstractProvider[typing.Any]] = {}

    def __len__(self) -> int:
        return len(self._providers)

    def find_provider(self, dependency_type: type[types.T]) -> AbstractProvider[types.T] | None:
        return self._providers.get(dependency_type)

    def register(self, provider_type: type, provider: AbstractProvider[typing.Any]) -> None:
        if provider_type in self._providers:
            raise RuntimeError(errors.PROVIDER_DUPLICATE_TYPE_ERROR.format(provider_type=provider_type))

        self._providers[provider_type] = provider

    def add_providers(self, *args: AbstractProvider[typing.Any]) -> None:
        for provider in args:
            if not provider.bound_type:
                continue

            self.register(provider.bound_type, provider)
