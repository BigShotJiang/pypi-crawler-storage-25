from datetime import datetime as time
import time as tim
# functions only recieve 2 funcs a and b an example ( function(a,b) ) a and b extracted from ((command) (a),(b))
class cpu():
    def __init__(self):
        # an array to store varibles ( you can do your own it's not required )
        self.varb = {}
        self.commands = {}
    def scommand(self,command: str):
        def ff(func):
         self.commands[command] = func
         return func
        return ff
    def run(self,code : str,debug=False):
        s = code.splitlines()
        if debug:
         print("[ {} ] DEBUG MODE RUNNING ".format(time.now().strftime("%Y-%m-%d %H:%M:%S")))
        r = 0
        ns = tim.time()
        for n,i in enumerate(s,start=1):
            timeb = tim.time()
            i = i.strip()
            if not i:
                continue
            if debug:
             r += 1
             print("[ {} ] [ {} ] PARSE → ( {} )".format(time.now().strftime("%Y-%m-%d %H:%M:%S"),n,i))
            parts = i.split(" ", 1)
            if len(parts) < 2:
                raise SyntaxError("missing inputs at line {}".format(n))
            if "," not in parts[1]:
                raise SyntaxError("missing comma at line {}".format(n))
            name, value = parts[1].split(",")
            name = name.strip()
            value = value.strip()
            b = [parts[0], name, value]
            if not b[0] or not b[1] or not b[2]:
                raise RuntimeError("missing input at line {}".format(n))
            self.commands[b[0]](b[1],b[2])
            t = tim.time() - timeb
            if debug:
             print("[ {} ][ {} ] TIME TAKEN → ( {} ) ".format(time.now().strftime("%Y-%m-%d %H:%M:%S"),n,t))
        if debug:
         re = tim.time() - ns
         print("[ {} ] SUMMARY".format(time.now().strftime("%Y-%m-%d %H:%M:%S")))
         print("[ {} ] COMMANDS EXECUTED → ( {} )".format(time.now().strftime("%Y-%m-%d %H:%M:%S"),r))
         print("[ {} ] TIME TAKEN → ( {} )".format(time.now().strftime("%Y-%m-%d %H:%M:%S"),re))


