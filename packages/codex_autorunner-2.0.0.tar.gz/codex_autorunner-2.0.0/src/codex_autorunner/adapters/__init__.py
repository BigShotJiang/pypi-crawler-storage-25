"""Outbound adapter package."""
