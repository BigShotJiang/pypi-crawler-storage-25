"""Telegram adapter package."""
