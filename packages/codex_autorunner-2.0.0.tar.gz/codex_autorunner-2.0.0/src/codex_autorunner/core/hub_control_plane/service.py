from __future__ import annotations

import logging
from importlib import metadata as importlib_metadata
from pathlib import Path
from typing import Any, Optional

from ..automation import (
    AutomationEvent,
    AutomationRule,
    AutomationRuleEngine,
    AutomationSchedule,
    AutomationStore,
)
from ..managed_thread_store import ManagedThreadStore
from ..orchestration.bindings import OrchestrationBindingStore
from ..orchestration.cold_trace_store import ColdTraceStore
from ..orchestration.models import ExecutionRecord, ThreadTarget
from ..orchestration.service import ManagedThreadExecutionStore
from ..orchestration.sqlite import read_orchestration_compatibility_metadata
from ..orchestration.turn_timeline import (
    append_turn_events_to_cold_trace,
    persist_turn_timeline,
)
from ..pma_notification_store import NotificationConversation, PmaNotificationStore
from ..pma_transcripts import PmaTranscriptStore
from .errors import HubControlPlaneError
from .models import (
    AutomationEventListRequest,
    AutomationEventListResponse,
    AutomationEventLookupRequest,
    AutomationEventResponse,
    AutomationJobActionRequest,
    AutomationJobListRequest,
    AutomationJobListResponse,
    AutomationJobLookupRequest,
    AutomationJobResponse,
    AutomationRequest,
    AutomationResult,
    AutomationRuleEnabledRequest,
    AutomationRuleListRequest,
    AutomationRuleListResponse,
    AutomationRuleLookupRequest,
    AutomationRuleResponse,
    AutomationRuleRunRequest,
    AutomationRuleUpsertRequest,
    AutomationScheduleListRequest,
    AutomationScheduleListResponse,
    AutomationScheduleLookupRequest,
    AutomationScheduleResponse,
    ExecutionBackendIdUpdateRequest,
    ExecutionCancelAllRequest,
    ExecutionCancelAllResponse,
    ExecutionCancelRequest,
    ExecutionCancelResponse,
    ExecutionClaimNextRequest,
    ExecutionClaimNextResponse,
    ExecutionColdTraceFinalizeRequest,
    ExecutionColdTraceFinalizeResponse,
    ExecutionCreateRequest,
    ExecutionInterruptRecordRequest,
    ExecutionListResponse,
    ExecutionLookupRequest,
    ExecutionPromoteRequest,
    ExecutionPromoteResponse,
    ExecutionResponse,
    ExecutionResultRecordRequest,
    ExecutionTimelinePersistRequest,
    ExecutionTimelinePersistResponse,
    HandshakeRequest,
    HandshakeResponse,
    LatestExecutionLookupRequest,
    NotificationContinuationBindRequest,
    NotificationDeliveryMarkRequest,
    NotificationLookupRequest,
    NotificationRecord,
    NotificationRecordResponse,
    NotificationReplyTargetLookupRequest,
    PmaSnapshotResponse,
    PreviousCompletedExecutionLookupRequest,
    QueueDepthRequest,
    QueueDepthResponse,
    QueuedExecutionListRequest,
    RunningExecutionLookupRequest,
    RunningThreadTargetIdsRequest,
    RunningThreadTargetIdsResponse,
    SurfaceBindingListRequest,
    SurfaceBindingListResponse,
    SurfaceBindingLookupRequest,
    SurfaceBindingResponse,
    SurfaceBindingUpsertRequest,
    ThreadActivityRecordRequest,
    ThreadBackendIdUpdateRequest,
    ThreadCompactSeedUpdateRequest,
    ThreadTargetArchiveRequest,
    ThreadTargetCreateRequest,
    ThreadTargetListRequest,
    ThreadTargetListResponse,
    ThreadTargetLookupRequest,
    ThreadTargetResponse,
    ThreadTargetResumeRequest,
    TranscriptHistoryRequest,
    TranscriptHistoryResponse,
    TranscriptWriteRequest,
    TranscriptWriteResponse,
    WorkspaceSetupCommandRequest,
    WorkspaceSetupCommandResult,
    deserialize_run_event,
    redact_automation_mapping,
    resolve_thread_target_list_status_fields,
)

CONTROL_PLANE_API_VERSION = "1.0.0"
CONTROL_PLANE_MINIMUM_CLIENT_API_VERSION = "1.0.0"
CONTROL_PLANE_CAPABILITIES: tuple[str, ...] = (
    "automation_requests",
    "automations",
    "compact_seed_updates",
    "compatibility_handshake",
    "notification_continuations",
    "notification_delivery_ack",
    "notification_records",
    "notification_reply_targets",
    "pma_snapshot",
    "surface_bindings",
    "thread_activity_updates",
    "thread_backend_updates",
    "execution_cold_trace_finalization",
    "execution_timeline_persistence",
    "thread_execution_lifecycle",
    "thread_target_creation",
    "thread_targets",
    "transcript_history",
    "transcript_writes",
    "workspace_setup_commands",
)


def _resolve_hub_build_version() -> str:
    for distribution_name in ("codex-autorunner", "codex_autorunner"):
        try:
            version = importlib_metadata.version(distribution_name).strip()
        except importlib_metadata.PackageNotFoundError:
            continue
        if version:
            return version
    return "unknown"


def _coerce_positive_int(
    value: Any, *, field_name: str, default: int, minimum: int = 1
) -> int:
    if value is None:
        return default
    try:
        normalized = int(value)
    except (TypeError, ValueError) as exc:
        raise HubControlPlaneError(
            "hub_rejected",
            f"{field_name} must be an integer",
            details={"field": field_name},
        ) from exc
    if normalized < minimum:
        raise HubControlPlaneError(
            "hub_rejected",
            f"{field_name} must be >= {minimum}",
            details={"field": field_name, "minimum": minimum},
        )
    return normalized


def _thread_target_from_store_row(
    store: ManagedThreadStore, record: dict[str, Any] | None
) -> ThreadTarget | None:
    if record is None:
        return None
    payload = dict(record)
    thread_target_id = str(payload.get("managed_thread_id") or "").strip()
    if thread_target_id:
        runtime_binding = store.get_thread_runtime_binding(thread_target_id)
        if runtime_binding is not None:
            payload["backend_thread_id"] = runtime_binding.backend_thread_id
            payload["backend_runtime_instance_id"] = (
                runtime_binding.backend_runtime_instance_id
            )
    return ThreadTarget.from_mapping(payload)


def _execution_from_record(record: ExecutionRecord | None) -> ExecutionRecord | None:
    return record


def _error_message(exc: BaseException) -> str:
    if exc.args and isinstance(exc.args[0], str):
        return exc.args[0]
    return str(exc)


def _notification_record_from_conversation(
    conversation: NotificationConversation | None,
) -> NotificationRecord | None:
    if conversation is None:
        return None
    return NotificationRecord.from_mapping(conversation.to_dict())


class HubSharedStateService:
    """Hub-owned owner of shared-state control-plane operations."""

    def __init__(
        self,
        *,
        hub_root: Path,
        supervisor: Any,
        hub_asset_version: Optional[str] = None,
        hub_build_version: Optional[str] = None,
        durable_writes: bool = False,
        logger: Optional[logging.Logger] = None,
    ) -> None:
        self._hub_root = Path(hub_root)
        self._supervisor = supervisor
        self._hub_asset_version = (
            str(hub_asset_version).strip() if hub_asset_version else None
        )
        resolved_build_version = (
            str(hub_build_version).strip() if hub_build_version else ""
        )
        self._hub_build_version = resolved_build_version or _resolve_hub_build_version()
        self._durable_writes = bool(durable_writes)
        self._logger = logger or logging.getLogger(__name__)
        self._notification_store = PmaNotificationStore(self._hub_root)
        self._binding_store = OrchestrationBindingStore(
            self._hub_root, durable=self._durable_writes
        )
        self._thread_store = ManagedThreadStore(
            self._hub_root,
            durable=self._durable_writes,
            bootstrap_on_init=False,
        )
        self._execution_store = ManagedThreadExecutionStore(self._thread_store)
        self._automation_store = AutomationStore(
            self._hub_root,
            durable=self._durable_writes,
        )

    @property
    def capabilities(self) -> tuple[str, ...]:
        return CONTROL_PLANE_CAPABILITIES

    def handshake(self, request: HandshakeRequest) -> HandshakeResponse:
        metadata = read_orchestration_compatibility_metadata(self._hub_root)
        if metadata is None:
            raise HubControlPlaneError(
                "hub_unavailable",
                "hub shared-state compatibility metadata is unavailable",
                details={"hub_root": str(self._hub_root)},
            )
        return HandshakeResponse(
            api_version=CONTROL_PLANE_API_VERSION,
            minimum_client_api_version=CONTROL_PLANE_MINIMUM_CLIENT_API_VERSION,
            schema_generation=metadata.schema_generation,
            capabilities=self.capabilities,
            hub_build_version=self._hub_build_version,
            hub_asset_version=self._hub_asset_version,
        )

    def get_notification_record(
        self, request: NotificationLookupRequest
    ) -> NotificationRecordResponse:
        return NotificationRecordResponse(
            record=self._lookup_notification_record(request.notification_id)
        )

    def _lookup_notification_record(
        self, notification_id: str
    ) -> NotificationRecord | None:
        from ..orchestration.sqlite import open_orchestration_sqlite

        with open_orchestration_sqlite(
            self._hub_root,
            durable=self._durable_writes,
            migrate=False,
        ) as conn:
            row = conn.execute(
                """
                SELECT *
                  FROM orch_notification_conversations
                 WHERE notification_id = ?
                 LIMIT 1
                """,
                (notification_id,),
            ).fetchone()
        if row is None:
            return None
        return NotificationRecord.from_mapping(dict(row))

    def get_notification_reply_target(
        self, request: NotificationReplyTargetLookupRequest
    ) -> NotificationRecordResponse:
        conversation = self._notification_store.get_reply_target(
            surface_kind=request.surface_kind,
            surface_key=request.surface_key,
            delivered_message_id=request.delivered_message_id,
        )
        return NotificationRecordResponse(
            record=_notification_record_from_conversation(conversation)
        )

    def bind_notification_continuation(
        self, request: NotificationContinuationBindRequest
    ) -> NotificationRecordResponse:
        conversation = self._notification_store.bind_continuation_thread(
            notification_id=request.notification_id,
            thread_target_id=request.thread_target_id,
        )
        return NotificationRecordResponse(
            record=_notification_record_from_conversation(conversation)
        )

    def mark_notification_delivered(
        self, request: NotificationDeliveryMarkRequest
    ) -> NotificationRecordResponse:
        conversation = self._notification_store.mark_delivered(
            delivery_record_id=request.delivery_record_id,
            delivered_message_id=request.delivered_message_id,
        )
        return NotificationRecordResponse(
            record=_notification_record_from_conversation(conversation)
        )

    def get_surface_binding(
        self, request: SurfaceBindingLookupRequest
    ) -> SurfaceBindingResponse:
        binding = self._binding_store.get_binding(
            surface_kind=request.surface_kind,
            surface_key=request.surface_key,
            include_disabled=request.include_disabled,
        )
        return SurfaceBindingResponse(binding=binding)

    def upsert_surface_binding(
        self, request: SurfaceBindingUpsertRequest
    ) -> SurfaceBindingResponse:
        try:
            binding = self._binding_store.upsert_binding(
                surface_kind=request.surface_kind,
                surface_key=request.surface_key,
                thread_target_id=request.thread_target_id,
                agent_id=request.agent_id,
                repo_id=request.repo_id,
                resource_kind=request.resource_kind,
                resource_id=request.resource_id,
                mode=request.mode,
                metadata=request.metadata,
            )
        except ValueError as exc:
            raise HubControlPlaneError(
                "hub_rejected",
                str(exc),
                details={"operation": "upsert_surface_binding"},
            ) from exc
        return SurfaceBindingResponse(binding=binding)

    def list_surface_bindings(
        self, request: SurfaceBindingListRequest
    ) -> SurfaceBindingListResponse:
        bindings = self._binding_store.list_bindings(
            thread_target_id=request.thread_target_id,
            repo_id=request.repo_id,
            resource_kind=request.resource_kind,
            resource_id=request.resource_id,
            agent_id=request.agent_id,
            surface_kind=request.surface_kind,
            include_disabled=request.include_disabled,
            limit=request.limit,
        )
        return SurfaceBindingListResponse(bindings=tuple(bindings))

    def get_thread_target(
        self, request: ThreadTargetLookupRequest
    ) -> ThreadTargetResponse:
        thread = _thread_target_from_store_row(
            self._thread_store, self._thread_store.get_thread(request.thread_target_id)
        )
        return ThreadTargetResponse(thread=thread)

    def list_thread_targets(
        self, request: ThreadTargetListRequest
    ) -> ThreadTargetListResponse:
        lifecycle_status, runtime_status = resolve_thread_target_list_status_fields(
            status=request.status,
            lifecycle_status=request.lifecycle_status,
            runtime_status=request.runtime_status,
        )
        rows = self._thread_store.list_threads(
            agent=request.agent_id,
            status=lifecycle_status,
            normalized_status=runtime_status,
            repo_id=request.repo_id,
            resource_kind=request.resource_kind,
            resource_id=request.resource_id,
            limit=request.limit,
        )
        threads = tuple(
            thread
            for thread in (
                _thread_target_from_store_row(self._thread_store, row) for row in rows
            )
            if thread is not None
        )
        return ThreadTargetListResponse(threads=threads)

    def resume_thread_target(
        self, request: ThreadTargetResumeRequest
    ) -> ThreadTargetResponse:
        if self._thread_store.get_thread(request.thread_target_id) is None:
            return ThreadTargetResponse(thread=None)
        self._thread_store.set_thread_backend_id(
            request.thread_target_id,
            request.backend_thread_id,
            backend_runtime_instance_id=request.backend_runtime_instance_id,
        )
        self._thread_store.activate_thread(request.thread_target_id)
        return ThreadTargetResponse(
            thread=_thread_target_from_store_row(
                self._thread_store,
                self._thread_store.get_thread(request.thread_target_id),
            )
        )

    def archive_thread_target(
        self, request: ThreadTargetArchiveRequest
    ) -> ThreadTargetResponse:
        if self._thread_store.get_thread(request.thread_target_id) is None:
            return ThreadTargetResponse(thread=None)
        self._thread_store.archive_thread(request.thread_target_id)
        return ThreadTargetResponse(
            thread=_thread_target_from_store_row(
                self._thread_store,
                self._thread_store.get_thread(request.thread_target_id),
            )
        )

    def set_thread_backend_id(self, request: ThreadBackendIdUpdateRequest) -> None:
        self._thread_store.set_thread_backend_id(
            request.thread_target_id,
            request.backend_thread_id,
            backend_runtime_instance_id=request.backend_runtime_instance_id,
        )

    def record_thread_activity(self, request: ThreadActivityRecordRequest) -> None:
        self._thread_store.update_thread_after_turn(
            request.thread_target_id,
            last_turn_id=request.execution_id,
            last_message_preview=request.message_preview,
        )

    def update_thread_compact_seed(
        self, request: ThreadCompactSeedUpdateRequest
    ) -> ThreadTargetResponse:
        if self._thread_store.get_thread(request.thread_target_id) is None:
            return ThreadTargetResponse(thread=None)
        self._thread_store.set_thread_compact_seed(
            request.thread_target_id,
            request.compact_seed,
        )
        return ThreadTargetResponse(
            thread=_thread_target_from_store_row(
                self._thread_store,
                self._thread_store.get_thread(request.thread_target_id),
            )
        )

    def create_thread_target(
        self, request: ThreadTargetCreateRequest
    ) -> ThreadTargetResponse:
        created = self._thread_store.create_thread(
            agent=request.agent_id,
            workspace_root=Path(request.workspace_root),
            repo_id=request.repo_id,
            resource_kind=request.resource_kind,
            resource_id=request.resource_id,
            name=request.display_name,
            backend_thread_id=request.backend_thread_id,
            metadata=request.metadata or None,
        )
        return ThreadTargetResponse(
            thread=_thread_target_from_store_row(self._thread_store, created)
        )

    def _execution_rejected(
        self, *, operation: str, exc: BaseException
    ) -> HubControlPlaneError:
        return HubControlPlaneError(
            "hub_rejected",
            _error_message(exc),
            details={"operation": operation},
        )

    def create_execution(self, request: ExecutionCreateRequest) -> ExecutionResponse:
        try:
            execution = self._execution_store.create_execution(
                request.thread_target_id,
                prompt=request.prompt,
                request_kind=request.request_kind,
                busy_policy=request.busy_policy,
                model=request.model,
                reasoning=request.reasoning,
                client_request_id=request.client_request_id,
                metadata=request.metadata or None,
                queue_payload=request.queue_payload or None,
            )
        except (KeyError, RuntimeError, ValueError) as exc:
            raise self._execution_rejected(
                operation="create_execution",
                exc=exc,
            ) from exc
        return ExecutionResponse(execution=_execution_from_record(execution))

    def get_execution(self, request: ExecutionLookupRequest) -> ExecutionResponse:
        execution = self._execution_store.get_execution(
            request.thread_target_id,
            request.execution_id,
        )
        return ExecutionResponse(execution=_execution_from_record(execution))

    def get_running_execution(
        self, request: RunningExecutionLookupRequest
    ) -> ExecutionResponse:
        execution = self._execution_store.get_running_execution(
            request.thread_target_id
        )
        return ExecutionResponse(execution=_execution_from_record(execution))

    def list_thread_target_ids_with_running_executions(
        self, request: RunningThreadTargetIdsRequest
    ) -> RunningThreadTargetIdsResponse:
        ids = self._execution_store.list_thread_ids_with_running_executions(
            limit=request.limit,
        )
        return RunningThreadTargetIdsResponse(thread_target_ids=tuple(ids))

    def get_latest_execution(
        self, request: LatestExecutionLookupRequest
    ) -> ExecutionResponse:
        execution = self._execution_store.get_latest_execution(request.thread_target_id)
        return ExecutionResponse(execution=_execution_from_record(execution))

    def get_previous_completed_execution(
        self, request: PreviousCompletedExecutionLookupRequest
    ) -> ExecutionResponse:
        execution = self._execution_store.get_previous_completed_execution(
            request.thread_target_id,
            exclude_execution_id=request.exclude_execution_id,
        )
        return ExecutionResponse(execution=_execution_from_record(execution))

    def list_queued_executions(
        self, request: QueuedExecutionListRequest
    ) -> ExecutionListResponse:
        executions = self._execution_store.list_queued_executions(
            request.thread_target_id,
            limit=request.limit,
        )
        return ExecutionListResponse(executions=tuple(executions))

    def get_queue_depth(self, request: QueueDepthRequest) -> QueueDepthResponse:
        return QueueDepthResponse(
            thread_target_id=request.thread_target_id,
            queue_depth=self._execution_store.get_queue_depth(request.thread_target_id),
        )

    def cancel_queued_execution(
        self, request: ExecutionCancelRequest
    ) -> ExecutionCancelResponse:
        return ExecutionCancelResponse(
            thread_target_id=request.thread_target_id,
            execution_id=request.execution_id,
            cancelled=self._execution_store.cancel_queued_execution(
                request.thread_target_id,
                request.execution_id,
            ),
        )

    def promote_queued_execution(
        self, request: ExecutionPromoteRequest
    ) -> ExecutionPromoteResponse:
        return ExecutionPromoteResponse(
            thread_target_id=request.thread_target_id,
            execution_id=request.execution_id,
            promoted=self._execution_store.promote_queued_execution(
                request.thread_target_id,
                request.execution_id,
            ),
        )

    def record_execution_result(
        self, request: ExecutionResultRecordRequest
    ) -> ExecutionResponse:
        try:
            execution = self._execution_store.record_execution_result(
                request.thread_target_id,
                request.execution_id,
                status=request.status,
                assistant_text=request.assistant_text,
                error=request.error,
                backend_turn_id=request.backend_turn_id,
                transcript_turn_id=request.transcript_turn_id,
            )
        except (KeyError, RuntimeError, ValueError) as exc:
            raise self._execution_rejected(
                operation="record_execution_result",
                exc=exc,
            ) from exc
        return ExecutionResponse(execution=_execution_from_record(execution))

    def record_execution_interrupted(
        self, request: ExecutionInterruptRecordRequest
    ) -> ExecutionResponse:
        try:
            execution = self._execution_store.record_execution_interrupted(
                request.thread_target_id,
                request.execution_id,
            )
        except (KeyError, RuntimeError, ValueError) as exc:
            raise self._execution_rejected(
                operation="record_execution_interrupted",
                exc=exc,
            ) from exc
        return ExecutionResponse(execution=_execution_from_record(execution))

    def cancel_queued_executions(
        self, request: ExecutionCancelAllRequest
    ) -> ExecutionCancelAllResponse:
        return ExecutionCancelAllResponse(
            thread_target_id=request.thread_target_id,
            cancelled_count=self._execution_store.cancel_queued_executions(
                request.thread_target_id
            ),
        )

    def set_execution_backend_id(
        self, request: ExecutionBackendIdUpdateRequest
    ) -> None:
        self._execution_store.set_execution_backend_id(
            request.execution_id,
            request.backend_turn_id,
            confirmed_start=request.confirmed_start,
        )

    def claim_next_queued_execution(
        self, request: ExecutionClaimNextRequest
    ) -> ExecutionClaimNextResponse:
        claimed = self._execution_store.claim_next_queued_execution(
            request.thread_target_id
        )
        if claimed is None:
            return ExecutionClaimNextResponse(execution=None, queue_payload={})
        execution, queue_payload = claimed
        return ExecutionClaimNextResponse(
            execution=_execution_from_record(execution),
            queue_payload=dict(queue_payload),
        )

    def persist_execution_timeline(
        self, request: ExecutionTimelinePersistRequest
    ) -> ExecutionTimelinePersistResponse:
        try:
            events = tuple(deserialize_run_event(event) for event in request.events)
            count = persist_turn_timeline(
                self._hub_root,
                execution_id=request.execution_id,
                target_kind=request.target_kind,
                target_id=request.target_id,
                repo_id=request.repo_id,
                run_id=request.run_id,
                resource_kind=request.resource_kind,
                resource_id=request.resource_id,
                metadata=dict(request.metadata),
                events=events,
                start_index=request.start_index,
            )
        except ValueError as exc:
            raise HubControlPlaneError(
                "hub_rejected",
                str(exc),
                details={"operation": "persist_execution_timeline"},
            ) from exc
        except OSError as exc:
            raise HubControlPlaneError(
                "hub_unavailable",
                str(exc),
                details={"operation": "persist_execution_timeline"},
            ) from exc
        return ExecutionTimelinePersistResponse(
            execution_id=request.execution_id,
            persisted_event_count=count,
        )

    def finalize_execution_cold_trace(
        self, request: ExecutionColdTraceFinalizeRequest
    ) -> ExecutionColdTraceFinalizeResponse:
        try:
            events = tuple(deserialize_run_event(event) for event in request.events)
            writer = ColdTraceStore(self._hub_root).open_writer(
                execution_id=request.execution_id,
                backend_thread_id=request.backend_thread_id,
                backend_turn_id=request.backend_turn_id,
            )
            try:
                writer.open()
                append_turn_events_to_cold_trace(writer, events=events)
                manifest = writer.finalize()
            finally:
                writer.close()
        except ValueError as exc:
            raise HubControlPlaneError(
                "hub_rejected",
                str(exc),
                details={"operation": "finalize_execution_cold_trace"},
            ) from exc
        except (OSError, RuntimeError) as exc:
            raise HubControlPlaneError(
                "hub_unavailable",
                str(exc),
                details={"operation": "finalize_execution_cold_trace"},
            ) from exc
        return ExecutionColdTraceFinalizeResponse(
            execution_id=request.execution_id,
            trace_manifest_id=manifest.trace_id,
        )

    def write_transcript(
        self, request: TranscriptWriteRequest
    ) -> TranscriptWriteResponse:
        try:
            PmaTranscriptStore(self._hub_root).write_transcript(
                turn_id=request.turn_id,
                metadata=dict(request.metadata),
                assistant_text=request.assistant_text,
            )
        except OSError as exc:
            raise HubControlPlaneError(
                "hub_unavailable",
                str(exc),
                details={"operation": "write_transcript"},
            ) from exc
        return TranscriptWriteResponse(turn_id=request.turn_id)

    def get_transcript_history(
        self, request: TranscriptHistoryRequest
    ) -> TranscriptHistoryResponse:
        from ..orchestration.transcript_mirror import TranscriptMirrorStore

        entries = TranscriptMirrorStore(self._hub_root).list_target_history(
            target_kind=request.target_kind,
            target_id=request.target_id,
            limit=request.limit,
        )
        return TranscriptHistoryResponse(entries=tuple(entries))

    def get_pma_snapshot(self) -> PmaSnapshotResponse:
        import asyncio

        from ..pma_context import build_hub_snapshot

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop is not None and loop.is_running():
            future = asyncio.run_coroutine_threadsafe(
                build_hub_snapshot(self._supervisor, hub_root=self._hub_root), loop
            )
            snapshot = future.result(timeout=30)
        else:
            snapshot = asyncio.run(
                build_hub_snapshot(self._supervisor, hub_root=self._hub_root)
            )
        return PmaSnapshotResponse(snapshot=snapshot)

    def run_workspace_setup_commands(
        self, request: WorkspaceSetupCommandRequest
    ) -> WorkspaceSetupCommandResult:
        workspace_root = Path(request.workspace_root).expanduser()
        count = self._supervisor.run_setup_commands_for_workspace(
            workspace_root,
            repo_id_hint=request.repo_id_hint,
        )
        return WorkspaceSetupCommandResult(
            workspace_root=str(workspace_root),
            repo_id_hint=request.repo_id_hint,
            setup_command_count=max(0, int(count or 0)),
        )

    def upsert_automation_rule(
        self, request: AutomationRuleUpsertRequest
    ) -> AutomationRuleResponse:
        rule = self._automation_store.upsert_rule(AutomationRule.create(**request.rule))
        schedule_payload = request.schedule
        schedule = None
        if schedule_payload is not None:
            schedule_payload = dict(schedule_payload)
            schedule_payload.setdefault("rule_id", rule.rule_id)
            schedule = self._automation_store.upsert_schedule(
                AutomationSchedule.create(**schedule_payload)
            )
        return AutomationRuleResponse(
            rule=redact_automation_mapping(rule.to_dict()),
            schedule=(
                redact_automation_mapping(schedule.to_dict())
                if schedule is not None
                else None
            ),
        )

    def get_automation_rule(
        self, request: AutomationRuleLookupRequest
    ) -> AutomationRuleResponse:
        rule = self._automation_store.get_rule(request.rule_id)
        if rule is None:
            raise HubControlPlaneError(
                "hub_rejected",
                f"Unknown automation rule: {request.rule_id}",
                details={"rule_id": request.rule_id},
            )
        schedules = self._automation_store.list_schedules(rule_id=rule.rule_id)
        schedule = schedules[0] if schedules else None
        return AutomationRuleResponse(
            rule=redact_automation_mapping(rule.to_dict()),
            schedule=(
                redact_automation_mapping(schedule.to_dict())
                if schedule is not None
                else None
            ),
        )

    def list_automation_rules(
        self, request: AutomationRuleListRequest
    ) -> AutomationRuleListResponse:
        rules = self._automation_store.list_rules(
            enabled=request.enabled,
            trigger_kind=request.trigger_kind,
        )[: request.limit]
        return AutomationRuleListResponse(
            rules=tuple(redact_automation_mapping(rule.to_dict()) for rule in rules)
        )

    def set_automation_rule_enabled(
        self, request: AutomationRuleEnabledRequest
    ) -> AutomationRuleResponse:
        rule = self._automation_store.set_rule_enabled(
            request.rule_id,
            request.enabled,
        )
        if rule is None:
            raise HubControlPlaneError(
                "hub_rejected",
                f"Unknown automation rule: {request.rule_id}",
                details={"rule_id": request.rule_id},
            )
        return AutomationRuleResponse(rule=redact_automation_mapping(rule.to_dict()))

    def run_automation_rule(
        self, request: AutomationRuleRunRequest
    ) -> AutomationJobResponse:
        rule = self._automation_store.get_rule(request.rule_id)
        if rule is None:
            raise HubControlPlaneError(
                "hub_rejected",
                f"Unknown automation rule: {request.rule_id}",
                details={"rule_id": request.rule_id},
            )
        if not rule.enabled:
            raise HubControlPlaneError(
                "hub_rejected",
                f"Automation rule is disabled: {request.rule_id}",
                details={"rule_id": request.rule_id},
            )
        target = {**rule.target, **request.target}
        event = self._automation_store.record_event(
            AutomationEvent.create(
                event_type="manual.run",
                source="hub_control_plane",
                repo_id=target.get("repo_id"),
                target=target,
                payload=request.payload,
                raw_payload=request.payload,
                metadata={
                    "rule_id": rule.rule_id,
                    **(
                        {"manual_dedupe_key": request.dedupe_key}
                        if request.dedupe_key
                        else {}
                    ),
                    **request.metadata,
                },
            )
        )
        engine = AutomationRuleEngine(self._automation_store)
        expected_job = engine.job_for_rule(rule, event)
        result = engine.enqueue_job_for_rule(rule, event)
        job = self._automation_store.get_job_by_dedupe_key(expected_job.dedupe_key)
        if job is None:
            raise HubControlPlaneError(
                "hub_rejected",
                f"Automation rule policy skipped manual run: {request.rule_id}",
                details={
                    "rule_id": request.rule_id,
                    "event_id": event.event_id,
                    "jobs_skipped": result.jobs_skipped,
                },
            )
        return AutomationJobResponse(job=redact_automation_mapping(job.to_dict()))

    def list_automation_jobs(
        self, request: AutomationJobListRequest
    ) -> AutomationJobListResponse:
        jobs = self._automation_store.list_jobs(
            state=request.state,
            rule_id=request.rule_id,
            limit=request.limit,
        )
        return AutomationJobListResponse(
            jobs=tuple(redact_automation_mapping(job.to_dict()) for job in jobs)
        )

    def get_automation_job(
        self, request: AutomationJobLookupRequest
    ) -> AutomationJobResponse:
        job = self._automation_store.get_job(request.job_id)
        if job is None:
            raise HubControlPlaneError(
                "hub_rejected",
                f"Unknown automation job: {request.job_id}",
                details={"job_id": request.job_id},
            )
        attempts = self._automation_store.list_attempts(job.job_id)
        return AutomationJobResponse(
            job=redact_automation_mapping(job.to_dict()),
            attempts=tuple(
                redact_automation_mapping(attempt.to_dict()) for attempt in attempts
            ),
        )

    def cancel_automation_job(
        self, request: AutomationJobActionRequest
    ) -> AutomationJobResponse:
        job = self._automation_store.cancel_job(request.job_id)
        return AutomationJobResponse(job=redact_automation_mapping(job.to_dict()))

    def retry_automation_job(
        self, request: AutomationJobActionRequest
    ) -> AutomationJobResponse:
        job = self._automation_store.retry_job(
            request.job_id,
            available_at=request.available_at,
        )
        return AutomationJobResponse(job=redact_automation_mapping(job.to_dict()))

    def revive_dead_lettered_automation_job(
        self, request: AutomationJobActionRequest
    ) -> AutomationJobResponse:
        job = self._automation_store.revive_dead_lettered_job(
            request.job_id,
            available_at=request.available_at,
        )
        return AutomationJobResponse(job=redact_automation_mapping(job.to_dict()))

    def list_automation_events(
        self, request: AutomationEventListRequest
    ) -> AutomationEventListResponse:
        events = self._automation_store.list_events(
            event_type=request.event_type,
            limit=request.limit,
        )
        return AutomationEventListResponse(
            events=tuple(redact_automation_mapping(event.to_dict()) for event in events)
        )

    def get_automation_event(
        self, request: AutomationEventLookupRequest
    ) -> AutomationEventResponse:
        event = self._automation_store.get_event(request.event_id)
        if event is None:
            raise HubControlPlaneError(
                "hub_rejected",
                f"Unknown automation event: {request.event_id}",
                details={"event_id": request.event_id},
            )
        return AutomationEventResponse(event=redact_automation_mapping(event.to_dict()))

    def list_automation_schedules(
        self, request: AutomationScheduleListRequest
    ) -> AutomationScheduleListResponse:
        schedules = self._automation_store.list_schedules(rule_id=request.rule_id)[
            : request.limit
        ]
        return AutomationScheduleListResponse(
            schedules=tuple(
                redact_automation_mapping(schedule.to_dict()) for schedule in schedules
            )
        )

    def get_automation_schedule(
        self, request: AutomationScheduleLookupRequest
    ) -> AutomationScheduleResponse:
        schedule = self._automation_store.get_schedule(request.schedule_id)
        if schedule is None:
            raise HubControlPlaneError(
                "hub_rejected",
                f"Unknown automation schedule: {request.schedule_id}",
                details={"schedule_id": request.schedule_id},
            )
        return AutomationScheduleResponse(
            schedule=redact_automation_mapping(schedule.to_dict())
        )

    def request_automation(self, request: AutomationRequest) -> AutomationResult:
        operation = request.operation.strip().lower()
        if operation != "process_now":
            raise HubControlPlaneError(
                "hub_rejected",
                f"Unsupported automation operation: {request.operation}",
                details={"operation": request.operation},
            )
        payload = dict(request.payload)
        include_timers = bool(payload.get("include_timers", True))
        limit = _coerce_positive_int(
            payload.get("limit"),
            field_name="limit",
            default=100,
        )
        result = self._supervisor.process_pma_automation_now(
            include_timers=include_timers,
            limit=limit,
        )
        if not isinstance(result, dict):
            result = {"result": result}
        return AutomationResult(
            operation=request.operation,
            accepted=True,
            payload=dict(result),
        )


__all__ = [
    "CONTROL_PLANE_API_VERSION",
    "CONTROL_PLANE_CAPABILITIES",
    "CONTROL_PLANE_MINIMUM_CLIENT_API_VERSION",
    "HubSharedStateService",
]
