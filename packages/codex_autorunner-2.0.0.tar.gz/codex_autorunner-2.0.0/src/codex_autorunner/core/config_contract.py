"""Shared config constants and error types."""

CONFIG_VERSION = 2


class ConfigError(Exception):
    """Raised when configuration is invalid."""


APP_SERVER_OUTPUT_POLICIES = ("all_agent_messages", "final_only")
OPENCODE_SERVER_SCOPE_VALUES = ("global", "workspace")
UPDATE_BACKEND_VALUES = ("auto", "launchd", "systemd-user")
USAGE_CACHE_SCOPE_VALUES = ("global", "repo")

TICKET_FLOW_APPROVAL_MODE_YOLO = "yolo"
TICKET_FLOW_APPROVAL_MODE_REVIEW = "review"
_TICKET_FLOW_APPROVAL_MODE_ALIASES = {
    TICKET_FLOW_APPROVAL_MODE_YOLO: TICKET_FLOW_APPROVAL_MODE_YOLO,
    TICKET_FLOW_APPROVAL_MODE_REVIEW: TICKET_FLOW_APPROVAL_MODE_REVIEW,
}
_TICKET_FLOW_APPROVAL_MODE_ALLOWED = ", ".join(
    [
        TICKET_FLOW_APPROVAL_MODE_YOLO,
        TICKET_FLOW_APPROVAL_MODE_REVIEW,
    ]
)
