"""Core runtime primitives."""
