from __future__ import annotations

import importlib.metadata
import logging
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable, Optional, cast

from ..core.agent_config import AgentConfig, resolve_agent_target_from_agents
from ..core.config import load_hub_config, load_repo_config
from ..core.config_contract import ConfigError
from ..core.orchestration.catalog import KNOWN_CAPABILITIES
from ..plugin_api import CAR_AGENT_ENTRYPOINT_GROUP, CAR_PLUGIN_API_VERSION
from .aliased_harness import AliasedAgentHarness
from .base import AgentHarness
from .codex.harness import CodexHarness
from .hermes.harness import HERMES_CAPABILITIES, HermesHarness
from .hermes.supervisor import (
    HermesApprovalHandler,
    build_hermes_supervisor_from_config,
    hermes_binary_available,
    hermes_runtime_preflight,
)
from .opencode.harness import OpenCodeHarness
from .types import RuntimeCapability, normalize_runtime_capabilities

_logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class AgentDescriptor:
    """A registered agent backend.

    Built-in backends live in `_BUILTIN_AGENTS`. Additional backends MAY be loaded
    via Python entry points (see `CAR_AGENT_ENTRYPOINT_GROUP`).

    Plugins SHOULD set `plugin_api_version` to `CAR_PLUGIN_API_VERSION`.
    """

    id: str
    name: str
    capabilities: frozenset[RuntimeCapability]
    make_harness: Callable[[Any], AgentHarness]
    healthcheck: Optional[Callable[[Any], bool]] = None
    backend_factory: Optional[Callable[[Any, AgentExecutionTarget, Any, Any], Any]] = (
        None
    )
    runtime_preflight: Optional[Callable[[Any, AgentExecutionTarget], Any]] = None
    runtime_kind: Optional[str] = None
    plugin_api_version: int = CAR_PLUGIN_API_VERSION

    def __post_init__(self) -> None:
        normalized_capabilities = normalize_agent_capabilities(self.capabilities)
        unknown_capabilities = {
            capability
            for capability in normalized_capabilities
            if capability not in KNOWN_CAPABILITIES
        }
        if unknown_capabilities:
            raise ValueError(
                "Unknown runtime capabilities: "
                + ", ".join(sorted(unknown_capabilities))
            )
        object.__setattr__(
            self,
            "capabilities",
            normalized_capabilities,
        )
        runtime_kind = str(self.runtime_kind or self.id or "").strip().lower()
        object.__setattr__(
            self,
            "runtime_kind",
            runtime_kind or str(self.id).strip().lower(),
        )


class _RequestedAgentContext:
    def __init__(
        self, delegate: Any, *, agent_id: str, profile: Optional[str] = None
    ) -> None:
        object.__setattr__(self, "_delegate", delegate)
        object.__setattr__(self, "_requested_agent_id", agent_id)
        object.__setattr__(self, "_requested_agent_profile", profile)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._delegate, name)

    def __setattr__(self, name: str, value: Any) -> None:
        setattr(self._delegate, name, value)


@dataclass(frozen=True)
class AgentRuntimeResolution:
    logical_agent_id: str
    logical_profile: Optional[str]
    runtime_agent_id: str
    runtime_profile: Optional[str]
    resolution_kind: str


@dataclass(frozen=True)
class AgentExecutionTarget:
    requested_agent_id: str
    requested_profile: Optional[str]
    logical_agent_id: str
    logical_profile: Optional[str]
    runtime_agent_id: str
    runtime_profile: Optional[str]
    resolution_kind: str


def normalize_agent_capabilities(
    capabilities: Iterable[str],
) -> frozenset[RuntimeCapability]:
    return normalize_runtime_capabilities(capabilities)


def _normalize_optional_text(value: object) -> Optional[str]:
    """Normalize an optional text value: strip, lowercase, or return None."""
    if not isinstance(value, str):
        return None
    normalized = value.strip().lower()
    return normalized or None


def _make_codex_harness(ctx: Any) -> AgentHarness:
    supervisor = ctx.app_server_supervisor
    events = ctx.app_server_events
    if supervisor is None or events is None:
        raise RuntimeError("Codex harness unavailable: supervisor or events missing")
    return CodexHarness(supervisor, events)


def _make_opencode_harness(ctx: Any) -> AgentHarness:
    supervisor = ctx.opencode_supervisor
    if supervisor is None:
        raise RuntimeError("OpenCode harness unavailable: supervisor missing")
    return OpenCodeHarness(supervisor)


def _check_codex_health(ctx: Any) -> bool:
    supervisor = ctx.app_server_supervisor
    return supervisor is not None


def _check_opencode_health(ctx: Any) -> bool:
    supervisor = ctx.opencode_supervisor
    return supervisor is not None


def _resolve_requested_agent_id(ctx: Any, *, default: str) -> str:
    requested = getattr(ctx, "_requested_agent_id", None)
    if isinstance(requested, str) and requested.strip():
        return requested.strip().lower()
    return default


def _resolve_requested_agent_profile(ctx: Any) -> Optional[str]:
    requested = getattr(ctx, "_requested_agent_profile", None)
    if isinstance(requested, str) and requested.strip():
        return requested.strip().lower()
    return None


def _runtime_supervisor_cache(ctx: Any) -> dict[tuple[str, str, str], Any]:
    cache = getattr(ctx, "_agent_runtime_supervisors", None)
    if isinstance(cache, dict):
        return cache
    cache = {}
    try:
        ctx._agent_runtime_supervisors = cache
    except AttributeError:
        _logger.debug("runtime supervisor cache write skipped", exc_info=True)
    return cache


def _run_hermes_preflight(
    config: Any, *, agent_id: str, profile: Optional[str] = None
) -> Any:
    try:
        return hermes_runtime_preflight(
            config,
            agent_id=agent_id,
            profile=profile,
        )
    except TypeError as exc:
        if "agent_id" not in str(exc) and "profile" not in str(exc):
            raise
        return hermes_runtime_preflight(config)


def _make_hermes_harness(ctx: Any) -> AgentHarness:
    target = resolve_agent_execution_target(
        _resolve_requested_agent_id(ctx, default="hermes"),
        _resolve_requested_agent_profile(ctx),
        context=ctx,
    )
    direct_alias_request = (
        target.requested_profile is None
        and target.requested_agent_id != target.logical_agent_id
    )
    if direct_alias_request:
        supervisor_agent_id = target.runtime_agent_id
        supervisor_profile = target.runtime_profile
    else:
        supervisor_agent_id = target.logical_agent_id or target.runtime_agent_id
        supervisor_profile = target.logical_profile
    cache = _runtime_supervisor_cache(ctx)
    cache_key = ("hermes", supervisor_agent_id, supervisor_profile or "")
    supervisor = cache.get(cache_key)
    if (
        supervisor is None
        and supervisor_agent_id == "hermes"
        and supervisor_profile is None
    ):
        supervisor = getattr(ctx, "hermes_supervisor", None)
    if supervisor is None:
        config = _resolve_runtime_agent_config(ctx)
        logger = getattr(ctx, "logger", None)
        if config is None:
            raise RuntimeError("Hermes harness unavailable: config missing")
        supervisor = build_hermes_supervisor_from_config(
            config,
            agent_id=supervisor_agent_id,
            profile=supervisor_profile,
            logger=logger,
            approval_handler=_resolve_surface_approval_handler(ctx),
            default_approval_decision=_resolve_default_approval_decision(ctx),
        )
        if supervisor is None:
            raise RuntimeError("Hermes harness unavailable: binary not configured")
        cache[cache_key] = supervisor
        if supervisor_agent_id == "hermes" and supervisor_profile is None:
            try:
                ctx.hermes_supervisor = supervisor
            except AttributeError:
                _logger.debug("hermes_supervisor cache write skipped", exc_info=True)
    return HermesHarness(supervisor)


def _check_hermes_health(ctx: Any) -> bool:
    target = resolve_agent_execution_target(
        _resolve_requested_agent_id(ctx, default="hermes"),
        _resolve_requested_agent_profile(ctx),
        context=ctx,
    )
    direct_alias_request = (
        target.requested_profile is None
        and target.requested_agent_id != target.logical_agent_id
    )
    if direct_alias_request:
        supervisor_agent_id = target.runtime_agent_id
        supervisor_profile = target.runtime_profile
    else:
        supervisor_agent_id = target.logical_agent_id or target.runtime_agent_id
        supervisor_profile = target.logical_profile
    cache = _runtime_supervisor_cache(ctx)
    supervisor = cache.get(("hermes", supervisor_agent_id, supervisor_profile or ""))
    if (
        supervisor is None
        and supervisor_agent_id == "hermes"
        and supervisor_profile is None
    ):
        supervisor = getattr(ctx, "hermes_supervisor", None)
    if supervisor is not None:
        return True
    config = _resolve_runtime_agent_config(ctx)
    if config is not None:
        result = _run_hermes_preflight(
            config,
            agent_id=supervisor_agent_id,
            profile=supervisor_profile,
        )
        return bool(getattr(result, "status", None) == "ready")
    binary = getattr(ctx, "hermes_binary", None)
    if isinstance(binary, str) and binary.strip():
        return hermes_binary_available(
            type(
                "_InlineConfig",
                (),
                {
                    "agent_binary": staticmethod(lambda _agent_id: binary.strip()),
                    "agent_backend": staticmethod(lambda _agent_id: "hermes"),
                },
            )()
        )
    return False


def _resolve_surface_approval_handler(ctx: Any) -> Optional[HermesApprovalHandler]:
    for attr in ("_handle_backend_approval_request", "_handle_approval_request"):
        handler = getattr(ctx, attr, None)
        if callable(handler):
            return cast(HermesApprovalHandler, handler)
    return None


def _resolve_default_approval_decision(ctx: Any) -> str:
    config = _resolve_runtime_agent_config(ctx)
    ticket_flow = getattr(config, "ticket_flow", None)
    value = getattr(ticket_flow, "default_approval_decision", None)
    if isinstance(value, str) and value.strip():
        return value.strip()
    return "cancel"


def _resolve_runtime_agent_config(ctx: Any) -> Any:
    if callable(getattr(ctx, "agent_binary", None)):
        return ctx
    for attr in ("config", "_config"):
        config = getattr(ctx, attr, None)
        if callable(getattr(config, "agent_binary", None)):
            return config

    root = _resolve_context_root(ctx)
    if root is None:
        return None

    loaders: tuple[Callable[[Path], Any], ...] = (
        lambda path: load_hub_config(path),
        lambda path: load_repo_config(path),
    )
    if isinstance(ctx, Path) or any(
        isinstance(getattr(ctx, attr, None), Path) for attr in ("root", "repo_root")
    ):
        loaders = tuple(reversed(loaders))

    for loader in loaders:
        try:
            config = loader(root)
        except (ValueError, OSError, TypeError, RuntimeError, ConfigError):
            continue
        if callable(getattr(config, "agent_binary", None)):
            return config
    return None


def _resolve_context_root(ctx: Any) -> Optional[Path]:
    if isinstance(ctx, Path):
        return ctx
    for attr in ("root", "repo_root"):
        root = getattr(ctx, attr, None)
        if isinstance(root, Path):
            return root
    for attr in ("config", "_config"):
        config = getattr(ctx, attr, None)
        root = getattr(config, "root", None)
        if isinstance(root, Path):
            return root
    return None


def descriptor_runtime_kind(agent_id: str, descriptor: Any) -> str:
    runtime_kind = str(getattr(descriptor, "runtime_kind", "") or "").strip().lower()
    if runtime_kind:
        return runtime_kind
    normalized_agent_id = str(agent_id or "").strip().lower()
    for separator in ("-", "_"):
        if separator not in normalized_agent_id:
            continue
        prefix = normalized_agent_id.split(separator, 1)[0].strip()
        if prefix and prefix in _all_agents():
            return prefix
    return normalized_agent_id


def resolve_agent_runtime(
    agent_id: str,
    profile: Optional[str] = None,
    *,
    context: Any = None,
) -> AgentRuntimeResolution:
    normalized_agent_id = str(agent_id or "").strip().lower()
    if not normalized_agent_id:
        raise ValueError("agent_id is required")

    descriptors = get_registered_agents(context)
    runtime_alias_kinds: dict[str, str] = {}
    for descriptor_id, descriptor in descriptors.items():
        runtime_kind = descriptor_runtime_kind(descriptor_id, descriptor)
        if runtime_kind != descriptor_id:
            runtime_alias_kinds[descriptor_id] = runtime_kind

    config = _resolve_runtime_agent_config(context)
    raw_config_agents = getattr(config, "agents", None)
    has_config_agents = isinstance(raw_config_agents, dict)
    config_agents = (
        cast(dict[str, AgentConfig], raw_config_agents) if has_config_agents else {}
    )
    try:
        resolved_target = resolve_agent_target_from_agents(
            config_agents if has_config_agents else {},
            normalized_agent_id,
            profile=profile,
            runtime_alias_kinds=runtime_alias_kinds,
            allow_runtime_alias_fallback=not has_config_agents,
        )
    except (ValueError, TypeError, RuntimeError, ConfigError):
        resolved_target = resolve_agent_target_from_agents(
            {},
            normalized_agent_id,
            profile=profile,
            runtime_alias_kinds=runtime_alias_kinds,
            allow_runtime_alias_fallback=True,
        )

    return AgentRuntimeResolution(
        logical_agent_id=resolved_target.logical_agent_id,
        logical_profile=resolved_target.logical_profile,
        runtime_agent_id=resolved_target.runtime_agent_id,
        runtime_profile=resolved_target.runtime_profile,
        resolution_kind=resolved_target.resolution_kind,
    )


def resolve_agent_execution_target(
    agent_id: str,
    profile: Optional[str] = None,
    *,
    context: Any = None,
) -> AgentExecutionTarget:
    normalized_agent_id = str(agent_id or "").strip().lower()
    normalized_profile = _normalize_optional_text(profile)
    resolved = resolve_agent_runtime(
        normalized_agent_id,
        normalized_profile,
        context=context,
    )
    return AgentExecutionTarget(
        requested_agent_id=normalized_agent_id,
        requested_profile=normalized_profile,
        logical_agent_id=resolved.logical_agent_id,
        logical_profile=resolved.logical_profile,
        runtime_agent_id=resolved.runtime_agent_id,
        runtime_profile=resolved.runtime_profile,
        resolution_kind=resolved.resolution_kind,
    )


def configured_agent_execution_targets(
    context: Any = None,
) -> tuple[AgentExecutionTarget, ...]:
    config = _resolve_runtime_agent_config(context)
    configured_agents = getattr(config, "agents", None)
    if not isinstance(configured_agents, dict):
        return ()
    targets: list[AgentExecutionTarget] = []
    for raw_agent_id in sorted(configured_agents):
        agent_id = str(raw_agent_id or "").strip().lower()
        if not agent_id:
            continue
        try:
            targets.append(resolve_agent_execution_target(agent_id, context=context))
        except (ConfigError, RuntimeError, TypeError, ValueError):
            continue
    return tuple(targets)


def run_agent_runtime_preflight(
    agent_id: str,
    profile: Optional[str] = None,
    *,
    context: Any = None,
) -> Any:
    target = resolve_agent_execution_target(agent_id, profile, context=context)
    descriptor = get_agent_descriptor(target.runtime_agent_id, context)
    if descriptor is None or descriptor.runtime_preflight is None:
        return None
    config = _resolve_runtime_agent_config(context)
    return descriptor.runtime_preflight(config, target)


def _build_codex_backend(
    factory: Any,
    target: AgentExecutionTarget,
    state: Any,
    notification_handler: Any,
) -> Any:
    return factory._build_codex_backend(target, state, notification_handler)


def _build_opencode_backend(
    factory: Any,
    target: AgentExecutionTarget,
    state: Any,
    notification_handler: Any,
) -> Any:
    return factory._build_opencode_backend(target, state, notification_handler)


def _preflight_hermes_runtime(config: Any, target: AgentExecutionTarget) -> Any:
    return _run_hermes_preflight(
        config,
        agent_id=target.runtime_agent_id,
        profile=target.runtime_profile,
    )


def wrap_requested_agent_context(
    delegate: Any, *, agent_id: str, profile: Optional[str] = None
) -> Any:
    return _RequestedAgentContext(delegate, agent_id=agent_id, profile=profile)


def _alias_display_name(
    agent_id: str,
    backend_descriptor: AgentDescriptor,
) -> str:
    if agent_id == backend_descriptor.id:
        return backend_descriptor.name
    return f"{backend_descriptor.name} ({agent_id})"


def _infer_backend_id_by_prefix(
    backend_id: str,
    base_agents: dict[str, AgentDescriptor],
) -> Optional[str]:
    """If *backend_id* is not a known backend, try shorter prefixes at ``-``/``_`` boundaries."""
    if not backend_id:
        return None
    boundary_prefixes: list[str] = []
    for i, ch in enumerate(backend_id):
        if ch in "-_" and i > 0:
            boundary_prefixes.append(backend_id[:i])
    if not boundary_prefixes:
        return None
    for prefix in sorted(boundary_prefixes, key=len, reverse=True):
        if prefix in base_agents:
            return prefix
    return None


def _check_canonical_profile(
    config_agents: dict[str, Any],
    agent_id: str,
) -> Optional[tuple[str, str]]:
    normalized = str(agent_id or "").strip().lower()
    if not normalized:
        return None
    for raw_base_id, agent_cfg in config_agents.items():
        base = str(raw_base_id or "").strip().lower()
        if not base or base == normalized:
            continue
        profiles = getattr(agent_cfg, "profiles", None)
        if not isinstance(profiles, dict):
            continue
        profile_keys = {str(k).strip().lower() for k in profiles}
        for sep in ("-", "_"):
            prefix = f"{base}{sep}"
            if not normalized.startswith(prefix):
                continue
            suffix = normalized[len(prefix) :].strip()
            if suffix and suffix in profile_keys:
                return base, suffix
    return None


def _build_config_alias_agents(context: Any) -> dict[str, AgentDescriptor]:
    config = _resolve_runtime_agent_config(context)
    if config is None:
        return {}
    configured_agents = getattr(config, "agents", None)
    if not isinstance(configured_agents, dict):
        return {}
    base_agents = _all_agents()
    aliases: dict[str, AgentDescriptor] = {}
    for raw_agent_id in configured_agents:
        agent_id = str(raw_agent_id or "").strip().lower()
        if not agent_id:
            continue
        if agent_id in base_agents:
            continue
        backend_id = agent_id
        profile_target = _check_canonical_profile(configured_agents, agent_id)
        if callable(getattr(config, "agent_backend", None)):
            try:
                backend_id = str(config.agent_backend(agent_id) or "").strip().lower()
            except (
                ConfigError,
                KeyError,
                AttributeError,
                TypeError,
                ValueError,
                RuntimeError,
            ):
                if profile_target is not None:
                    resolved_backend_id, resolved_profile = profile_target
                    _logger.debug(
                        "Skipping config alias synthesis for %s; treated as %s profile %s",
                        agent_id,
                        resolved_backend_id,
                        resolved_profile,
                    )
                    continue
                raise
        if not backend_id:
            continue
        backend_descriptor = base_agents.get(backend_id)
        if backend_descriptor is None:
            inferred = _infer_backend_id_by_prefix(backend_id, base_agents)
            if inferred is not None:
                _logger.info(
                    "Inferred backend %r for configured agent %r (prefix of unresolved id %r)",
                    inferred,
                    agent_id,
                    backend_id,
                )
                backend_id = inferred
                backend_descriptor = base_agents.get(backend_id)
        if backend_descriptor is None and profile_target is not None:
            resolved_backend_id, resolved_profile = profile_target
            _logger.debug(
                "Skipping unresolved config alias %s; %s profile %s is configured canonically",
                agent_id,
                resolved_backend_id,
                resolved_profile,
            )
            continue
        if backend_descriptor is None:
            _logger.warning(
                "Configured agent %s references unknown backend %s",
                agent_id,
                backend_id,
            )
            continue
        resolved_backend_descriptor = backend_descriptor
        alias_name = _alias_display_name(agent_id, resolved_backend_descriptor)

        def _make_harness(
            ctx: Any,
            *,
            alias_id: str = agent_id,
            alias_name: str = alias_name,
            backend: AgentDescriptor = resolved_backend_descriptor,
        ) -> AgentHarness:
            base_harness = backend.make_harness(
                _RequestedAgentContext(ctx, agent_id=alias_id)
            )
            return AliasedAgentHarness(
                base_harness,
                agent_id=alias_id,
                display_name=alias_name,
            )

        healthcheck = None
        backend_healthcheck = resolved_backend_descriptor.healthcheck
        if backend_healthcheck is not None:
            resolved_backend_healthcheck = cast(
                Callable[[Any], bool],
                backend_healthcheck,
            )

            def _healthcheck(
                ctx: Any,
                *,
                alias_id: str = agent_id,
                backend_healthcheck: Callable[[Any], bool] = (
                    resolved_backend_healthcheck
                ),
            ) -> bool:
                return backend_healthcheck(
                    _RequestedAgentContext(ctx, agent_id=alias_id)
                )

            healthcheck = _healthcheck

        aliases[agent_id] = AgentDescriptor(
            id=agent_id,
            name=alias_name,
            capabilities=resolved_backend_descriptor.capabilities,
            make_harness=_make_harness,
            healthcheck=healthcheck,
            backend_factory=resolved_backend_descriptor.backend_factory,
            runtime_preflight=resolved_backend_descriptor.runtime_preflight,
            runtime_kind=resolved_backend_descriptor.runtime_kind,
            plugin_api_version=resolved_backend_descriptor.plugin_api_version,
        )
    return aliases


_BUILTIN_AGENTS: dict[str, AgentDescriptor] = {
    "codex": AgentDescriptor(
        id="codex",
        name="Codex",
        capabilities=frozenset(
            [
                RuntimeCapability("durable_threads"),
                RuntimeCapability("message_turns"),
                RuntimeCapability("interrupt"),
                RuntimeCapability("active_thread_discovery"),
                RuntimeCapability("review"),
                RuntimeCapability("model_listing"),
                RuntimeCapability("event_streaming"),
                RuntimeCapability("approvals"),
            ]
        ),
        make_harness=_make_codex_harness,
        healthcheck=_check_codex_health,
        backend_factory=_build_codex_backend,
    ),
    "opencode": AgentDescriptor(
        id="opencode",
        name="OpenCode",
        capabilities=frozenset(
            [
                RuntimeCapability("durable_threads"),
                RuntimeCapability("message_turns"),
                RuntimeCapability("interrupt"),
                RuntimeCapability("active_thread_discovery"),
                RuntimeCapability("review"),
                RuntimeCapability("model_listing"),
                RuntimeCapability("event_streaming"),
            ]
        ),
        make_harness=_make_opencode_harness,
        healthcheck=_check_opencode_health,
        backend_factory=_build_opencode_backend,
    ),
    "hermes": AgentDescriptor(
        id="hermes",
        name="Hermes",
        capabilities=HERMES_CAPABILITIES,
        make_harness=_make_hermes_harness,
        healthcheck=_check_hermes_health,
        runtime_preflight=_preflight_hermes_runtime,
        runtime_kind="hermes",
    ),
}

# Lazy-loaded cache of built-in + plugin agents.
_AGENT_CACHE: Optional[dict[str, AgentDescriptor]] = None

# Lock to protect cache initialization and reload from concurrent access.
_AGENT_CACHE_LOCK = threading.Lock()


def _select_entry_points(group: str) -> Iterable[importlib.metadata.EntryPoint]:
    """Compatibility wrapper for `importlib.metadata.entry_points()` across py versions."""

    eps = importlib.metadata.entry_points()
    # Python 3.9: may return a dict
    if isinstance(eps, dict):
        return eps.get(group, [])
    if hasattr(eps, "select"):
        return list(eps.select(group=group))
    return []


def _load_agent_plugins() -> dict[str, AgentDescriptor]:
    loaded: dict[str, AgentDescriptor] = {}
    for ep in _select_entry_points(CAR_AGENT_ENTRYPOINT_GROUP):
        try:
            obj = ep.load()
        except (
            ImportError,
            AttributeError,
            TypeError,
            RuntimeError,
            ValueError,
        ) as exc:  # noqa: BLE001
            _logger.warning(
                "Failed to load agent plugin entry point %s:%s: %s",
                ep.group,
                ep.name,
                exc,
            )
            continue

        descriptor: Optional[AgentDescriptor] = None
        if isinstance(obj, AgentDescriptor):
            descriptor = obj
        elif callable(obj):
            try:
                maybe = obj()
            except (
                TypeError,
                RuntimeError,
                ValueError,
                AttributeError,
            ) as exc:  # noqa: BLE001
                _logger.warning(
                    "Agent plugin entry point %s:%s factory failed: %s",
                    ep.group,
                    ep.name,
                    exc,
                )
                continue
            if isinstance(maybe, AgentDescriptor):
                descriptor = maybe

        if descriptor is None:
            _logger.warning(
                "Ignoring agent plugin entry point %s:%s: expected AgentDescriptor or factory",
                ep.group,
                ep.name,
            )
            continue

        agent_id = (descriptor.id or "").strip().lower()
        if not agent_id:
            _logger.warning(
                "Ignoring agent plugin entry point %s:%s: missing id",
                ep.group,
                ep.name,
            )
            continue

        api_version_raw = getattr(descriptor, "plugin_api_version", None)
        if api_version_raw is None:
            api_version = None
        else:
            try:
                api_version = int(api_version_raw)
            except (ValueError, TypeError):
                api_version = None
        if api_version is None:
            _logger.warning(
                "Ignoring agent plugin %s: invalid api_version %s",
                agent_id,
                api_version_raw,
            )
            continue
        if api_version != CAR_PLUGIN_API_VERSION:
            _logger.warning(
                "Ignoring agent plugin %s: api_version=%s does not match current core (%s)",
                agent_id,
                api_version,
                CAR_PLUGIN_API_VERSION,
            )
            continue

        if agent_id in _BUILTIN_AGENTS:
            _logger.warning(
                "Ignoring agent plugin %s: conflicts with built-in agent id",
                agent_id,
            )
            continue
        if agent_id in loaded:
            _logger.warning(
                "Ignoring duplicate agent plugin id %s from entry point %s:%s",
                agent_id,
                ep.group,
                ep.name,
            )
            continue

        loaded[agent_id] = descriptor
        _logger.info("Loaded agent plugin: %s (%s)", agent_id, descriptor.name)

    return loaded


def _all_agents() -> dict[str, AgentDescriptor]:
    global _AGENT_CACHE
    if _AGENT_CACHE is None:
        with _AGENT_CACHE_LOCK:
            if _AGENT_CACHE is None:
                agents = _BUILTIN_AGENTS.copy()
                agents.update(_load_agent_plugins())
                _AGENT_CACHE = agents
    return _AGENT_CACHE


def reload_agents() -> dict[str, AgentDescriptor]:
    """Clear the plugin cache and reload agent backends.

    This is primarily useful for tests and local development.
    """

    global _AGENT_CACHE
    with _AGENT_CACHE_LOCK:
        _AGENT_CACHE = None
    return get_registered_agents()


def get_registered_agents(context: Any = None) -> dict[str, AgentDescriptor]:
    agents = _all_agents().copy()
    agents.update(_build_config_alias_agents(context))
    return agents


def get_available_agents(app_ctx: Any) -> dict[str, AgentDescriptor]:
    available: dict[str, AgentDescriptor] = {}
    for agent_id, descriptor in get_registered_agents(app_ctx).items():
        if descriptor.healthcheck is None or descriptor.healthcheck(app_ctx):
            available[agent_id] = descriptor
    return available


def get_agent_descriptor(
    agent_id: str,
    context: Any = None,
) -> Optional[AgentDescriptor]:
    normalized = (agent_id or "").strip().lower()
    return get_registered_agents(context).get(normalized)


def validate_agent_id(agent_id: str, context: Any = None) -> str:
    normalized = (agent_id or "").strip().lower()
    registered = get_registered_agents(context)
    if normalized in registered:
        return normalized
    try:
        resolved = resolve_agent_runtime(normalized, context=context)
    except (ConfigError, RuntimeError, TypeError, ValueError):
        resolved = None
    if (
        resolved is not None
        and resolved.resolution_kind != "passthrough"
        and (
            resolved.logical_agent_id in registered
            or resolved.runtime_agent_id in registered
        )
    ):
        return normalized
    raise ValueError(f"Unknown agent: {agent_id!r}")


def has_capability(agent_id: str, capability: str, context: Any = None) -> bool:
    descriptor = get_agent_descriptor(agent_id, context)
    if descriptor is None:
        return False
    normalized = normalize_agent_capabilities([capability])
    if not normalized:
        return False
    return next(iter(normalized)) in descriptor.capabilities


__all__ = [
    "AgentExecutionTarget",
    "AgentRuntimeResolution",
    "CAR_AGENT_ENTRYPOINT_GROUP",
    "CAR_PLUGIN_API_VERSION",
    "AgentDescriptor",
    "configured_agent_execution_targets",
    "descriptor_runtime_kind",
    "get_agent_descriptor",
    "get_available_agents",
    "get_registered_agents",
    "has_capability",
    "normalize_agent_capabilities",
    "reload_agents",
    "resolve_agent_execution_target",
    "resolve_agent_runtime",
    "run_agent_runtime_preflight",
    "validate_agent_id",
    "wrap_requested_agent_context",
]
