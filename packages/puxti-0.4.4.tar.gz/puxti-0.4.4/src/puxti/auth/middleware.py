"""Trial validation middleware — called before any metered CLI command."""
from __future__ import annotations

import typer
from rich.console import Console

from puxti.auth.client import AuthAPIError, auth_client
from puxti.auth.config import auth_config

err_console = Console(stderr=True)

UPGRADE_URL = "https://getpuxti.com/upgrade"


class TrialExpiredError(Exception):
    pass


class LimitReachedError(Exception):
    pass


class NotAuthenticatedError(Exception):
    pass


def require_valid_trial(command: str) -> None:
    """
    Enforce trial state before executing a metered command.

    Checks cached trial state. Hits /v1/auth/validate if cache is stale (>24h).
    Raises SystemExit (via typer) on failure.

    command: "propagation" | "capture" | "scan" (used only for error messaging)
    """
    api_key = auth_config.get_api_key()
    if not api_key:
        err_console.print(
            "\n[red bold]Not authenticated.[/red bold]\n"
            "  Run [bold]puxti auth <api-key>[/bold] to connect your workspace.\n"
            f"  No account yet? Sign up at [bold]{UPGRADE_URL.replace('/upgrade', '/signup')}[/bold]"
        )
        raise typer.Exit(1)

    # Refresh cache if stale
    if not auth_config.is_cache_fresh():
        try:
            result = auth_client.validate(api_key)
        except AuthAPIError as exc:
            err_console.print(f"\n[red bold]Auth error:[/red bold] {exc}")
            err_console.print(
                f"  Check your connection or re-authenticate with [bold]puxti auth <api-key>[/bold]"
            )
            raise typer.Exit(1)

        if not result.get("valid"):
            err_console.print(
                "\n[red bold]API key is no longer valid.[/red bold]\n"
                f"  Visit [bold]getpuxti.com[/bold] or run [bold]puxti auth <api-key>[/bold] with a new key."
            )
            raise typer.Exit(1)

        auth_config.save_auth(
            api_key=api_key,
            workspace_id=result.get("workspace_id", ""),
            plan=result.get("plan", ""),
            trial=result.get("trial", {}),
        )

    trial = auth_config.get_cached_trial() or {}
    plan = auth_config._load().get("auth", {}).get("plan", "trial")

    # Paid plans — no trial limits
    if plan in ("team", "scale", "enterprise"):
        return

    # Trial expired
    if not trial.get("active", False):
        err_console.print(
            "\n[red bold]Trial expired (30 days).[/red bold] Upgrade to continue.\n"
            f"  → [bold]{UPGRADE_URL}[/bold]"
        )
        raise typer.Exit(1)

    # Per-command limit check
    if command == "propagation":
        used = trial.get("propagations_used", 0)
        limit = trial.get("propagations_limit", 10)
        if used >= limit:
            err_console.print(
                f"\n[red bold]Propagation limit reached ({used}/{limit} on Trial).[/red bold]\n"
                f"  → [bold]{UPGRADE_URL}[/bold]  or  [bold]puxti auth --status[/bold]"
            )
            raise typer.Exit(1)

    elif command == "capture":
        used = trial.get("captures_used", 0)
        limit = trial.get("captures_limit", 25)
        if used >= limit:
            err_console.print(
                f"\n[red bold]Capture limit reached ({used}/{limit} on Trial).[/red bold]\n"
                f"  → [bold]{UPGRADE_URL}[/bold]  or  [bold]puxti auth --status[/bold]"
            )
            raise typer.Exit(1)


def record_usage(command: str) -> None:
    """
    Record usage after a successful command.

    Silently swallows errors — usage recording failures should never break
    the CLI for the user.
    """
    api_key = auth_config.get_api_key()
    if not api_key:
        return
    try:
        result = auth_client.record_usage(api_key=api_key, event=command)
        # Update local cache with fresh counters
        trial = result.get("trial", {})
        if trial:
            plan = auth_config._load().get("auth", {}).get("plan", "trial")
            workspace_id = auth_config.get_workspace_id() or ""
            auth_config.save_auth(
                api_key=api_key,
                workspace_id=workspace_id,
                plan=plan,
                trial=trial,
            )
    except Exception:
        pass  # never break the CLI over a usage recording failure
