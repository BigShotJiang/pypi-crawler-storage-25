"""Local auth config — reads/writes ~/.puxti/config.toml."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

try:
    import tomllib  # Python 3.11+
except ImportError:
    import tomli as tomllib  # type: ignore[no-redef]

import tomli_w

CONFIG_PATH = Path.home() / ".puxti" / "config.toml"
CACHE_TTL_HOURS = 24


class AuthConfig:
    """Thin wrapper around ~/.puxti/config.toml."""

    def __init__(self, path: Path = CONFIG_PATH) -> None:
        self._path = path

    # ------------------------------------------------------------------
    # Read helpers
    # ------------------------------------------------------------------

    def _load(self) -> dict:
        if not self._path.exists():
            return {}
        with open(self._path, "rb") as f:
            return tomllib.load(f)

    def _save(self, data: dict) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        with open(self._path, "wb") as f:
            tomli_w.dump(data, f)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_api_key(self) -> Optional[str]:
        return self._load().get("auth", {}).get("api_key")

    def get_workspace_id(self) -> Optional[str]:
        return self._load().get("auth", {}).get("workspace_id")

    def is_cache_fresh(self) -> bool:
        data = self._load()
        cached_until_str = data.get("auth", {}).get("cached_until")
        if not cached_until_str:
            return False
        cached_until = datetime.fromisoformat(cached_until_str)
        return datetime.now(timezone.utc) < cached_until

    def get_cached_trial(self) -> Optional[dict]:
        """Return cached trial section if cache is still fresh."""
        if not self.is_cache_fresh():
            return None
        return self._load().get("trial")

    def save_auth(
        self,
        api_key: str,
        workspace_id: str,
        plan: str,
        trial: dict,
    ) -> None:
        """Persist auth + trial state after a successful /v1/auth/validate response."""
        from datetime import timedelta

        cached_until = datetime.now(timezone.utc) + timedelta(hours=CACHE_TTL_HOURS)
        data = self._load()
        data["auth"] = {
            "api_key": api_key,
            "workspace_id": workspace_id,
            "plan": plan,
            "cached_until": cached_until.isoformat(),
        }
        data["trial"] = {
            "active": trial.get("active", False),
            "expires_at": trial.get("expires_at", ""),
            "propagations_used": trial.get("propagations_used", 0),
            "propagations_limit": trial.get("propagations_limit", 10),
            "captures_used": trial.get("captures_used", 0),
            "captures_limit": trial.get("captures_limit", 25),
        }
        self._save(data)

    def clear(self) -> None:
        """Remove stored credentials (logout)."""
        if self._path.exists():
            self._path.unlink()

    def is_logged_in(self) -> bool:
        return bool(self.get_api_key())

    def get_status_summary(self) -> Optional[dict]:
        """Return a dict suitable for display in `puxti auth --status`."""
        data = self._load()
        auth = data.get("auth", {})
        trial = data.get("trial", {})
        if not auth.get("api_key"):
            return None
        return {
            "api_key": auth.get("api_key", ""),
            "workspace_id": auth.get("workspace_id", ""),
            "plan": auth.get("plan", ""),
            "cache_fresh": self.is_cache_fresh(),
            "cached_until": auth.get("cached_until", ""),
            "trial_active": trial.get("active", False),
            "expires_at": trial.get("expires_at", ""),
            "propagations_used": trial.get("propagations_used", 0),
            "propagations_limit": trial.get("propagations_limit", 10),
            "captures_used": trial.get("captures_used", 0),
            "captures_limit": trial.get("captures_limit", 25),
        }


# Module-level singleton
auth_config = AuthConfig()
