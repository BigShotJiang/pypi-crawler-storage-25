"""HTTP client for the puxti auth API."""
from __future__ import annotations

import os
from typing import Optional

import httpx

PUXTI_API_BASE = os.environ.get("PUXTI_API_URL", "https://api.getpuxti.com")


class AuthAPIError(Exception):
    pass


class AuthClient:
    def __init__(self, base_url: str = PUXTI_API_BASE, timeout: float = 10.0) -> None:
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout

    def validate(self, api_key: str) -> dict:
        """
        POST /v1/auth/validate

        Returns: { valid, workspace_id, plan, trial: { active, expires_at, usage... } }
        Raises AuthAPIError on network error or non-200 response.
        """
        try:
            resp = httpx.post(
                f"{self._base_url}/v1/auth/validate",
                json={"api_key": api_key},
                timeout=self._timeout,
            )
        except httpx.RequestError as exc:
            raise AuthAPIError(f"Network error contacting puxti API: {exc}") from exc

        if resp.status_code == 401:
            raise AuthAPIError("Invalid API key.")
        if not resp.is_success:
            raise AuthAPIError(f"Auth API returned {resp.status_code}: {resp.text}")

        return resp.json()

    def record_usage(self, api_key: str, event: str) -> dict:
        """
        POST /v1/usage/record

        event: "propagation" | "capture" | "scan"
        Returns updated usage counters.
        Raises AuthAPIError on failure.
        """
        try:
            resp = httpx.post(
                f"{self._base_url}/v1/usage/record",
                json={"api_key": api_key, "event": event},
                timeout=self._timeout,
            )
        except httpx.RequestError as exc:
            raise AuthAPIError(f"Network error recording usage: {exc}") from exc

        if not resp.is_success:
            raise AuthAPIError(f"Usage API returned {resp.status_code}: {resp.text}")

        return resp.json()

    def signup(self, email: str, name: str) -> dict:
        """
        POST /v1/auth/signup

        Creates Workspace + Trial + ApiKey, sends key by email.
        """
        try:
            resp = httpx.post(
                f"{self._base_url}/v1/auth/signup",
                json={"email": email, "name": name},
                timeout=self._timeout,
            )
        except httpx.RequestError as exc:
            raise AuthAPIError(f"Network error during signup: {exc}") from exc

        if not resp.is_success:
            raise AuthAPIError(f"Signup API returned {resp.status_code}: {resp.text}")

        return resp.json()


# Module-level singleton
auth_client = AuthClient()
