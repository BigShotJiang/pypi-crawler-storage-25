"""Waitlist endpoints — /v1/waitlist and /v1/admin/waitlist/*."""
from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, HTTPException, Request

from puxti.api.email import send_admin_notification, send_api_key
from puxti.api.limiter import limiter
from puxti.api.models import (
    ApproveResponse,
    RejectResponse,
    WaitlistEntry,
    WaitlistListResponse,
    WaitlistRequest,
    WaitlistResponse,
)
from puxti.api.routes.auth import (
    TRIAL_CAPTURE_LIMIT,
    TRIAL_DAYS,
    TRIAL_PROPAGATION_LIMIT,
    _is_business_email,
)
from puxti.api.store import store

router = APIRouter()

_ADMIN_TOKEN: str = os.environ.get("ADMIN_TOKEN", "")
if not _ADMIN_TOKEN:
    import warnings
    warnings.warn(
        "ADMIN_TOKEN is not set. All /v1/admin/* endpoints will return 401 until it is configured.",
        stacklevel=1,
    )


def _require_admin(request: Request) -> None:
    if not _ADMIN_TOKEN:
        raise HTTPException(status_code=401, detail="Admin authentication required.")
    token = request.headers.get("X-Admin-Token", "")
    if not hmac.compare_digest(token, _ADMIN_TOKEN):
        raise HTTPException(status_code=401, detail="Admin authentication required.")


def _hash_key(raw_key: str) -> str:
    return hashlib.sha256(raw_key.encode()).hexdigest()


def _make_api_key() -> str:
    return "pk_live_" + secrets.token_urlsafe(32)


# ---------------------------------------------------------------------------
# Public: submit waitlist application
# ---------------------------------------------------------------------------


@router.post("/v1/waitlist", response_model=WaitlistResponse)
@limiter.limit("5/hour")
async def join_waitlist(request: Request, body: WaitlistRequest) -> WaitlistResponse:
    if not _is_business_email(body.email):
        raise HTTPException(
            status_code=422,
            detail=(
                "Please use a business email address. "
                "Consumer email providers (Gmail, Outlook, etc.) are not accepted."
            ),
        )

    if await store.get_waitlist_entry_by_email(body.email):
        # Return 200 with the same message to avoid email enumeration
        return WaitlistResponse(
            id="",
            message="Application received. We'll be in touch within a few days.",
        )

    entry_id = "wl_" + uuid.uuid4().hex
    await store.create_waitlist_entry(
        id=entry_id,
        name=body.name,
        email=body.email,
        company=body.company,
        title=body.title,
        consent=body.consent,
        submitted_at=datetime.now(timezone.utc),
    )

    send_admin_notification(
        entry_id=entry_id,
        name=body.name,
        email=body.email,
        company=body.company or "",
        title=body.title or "",
    )

    return WaitlistResponse(
        id=entry_id,
        message="Application received. We'll be in touch within a few days.",
    )


# ---------------------------------------------------------------------------
# Admin: list all entries
# ---------------------------------------------------------------------------


@router.get("/v1/admin/waitlist", response_model=WaitlistListResponse)
@limiter.limit("30/minute")
async def list_waitlist(request: Request) -> WaitlistListResponse:
    _require_admin(request)
    entries = await store.list_waitlist_entries()
    parsed = [WaitlistEntry(**e) for e in entries]
    return WaitlistListResponse(
        entries=parsed,
        total=len(parsed),
        pending=sum(1 for e in parsed if e.status == "pending"),
        approved=sum(1 for e in parsed if e.status == "approved"),
        rejected=sum(1 for e in parsed if e.status == "rejected"),
    )


# ---------------------------------------------------------------------------
# Admin: approve an entry → creates workspace + API key
# ---------------------------------------------------------------------------


@router.post("/v1/admin/waitlist/{entry_id}/approve", response_model=ApproveResponse)
@limiter.limit("20/minute")
async def approve_entry(entry_id: str, request: Request) -> ApproveResponse:
    _require_admin(request)

    entry = await store.get_waitlist_entry(entry_id)
    if entry is None:
        raise HTTPException(status_code=404, detail="Waitlist entry not found.")
    if entry["status"] == "approved":
        raise HTTPException(status_code=409, detail="Entry already approved.")
    if entry["status"] == "rejected":
        raise HTTPException(status_code=409, detail="Entry was rejected — cannot approve.")

    now = datetime.now(timezone.utc)
    workspace_id = "ws_" + uuid.uuid4().hex

    await store.create_workspace(
        id=workspace_id,
        name=entry["name"],
        created_at=now,
        plan="trial",
        email=entry["email"],
    )
    await store.create_trial(
        workspace_id=workspace_id,
        activated_at=now,
        expires_at=now + timedelta(days=TRIAL_DAYS),
        propagations_limit=TRIAL_PROPAGATION_LIMIT,
        captures_limit=TRIAL_CAPTURE_LIMIT,
    )

    raw_key = _make_api_key()
    await store.create_key(
        workspace_id=workspace_id,
        key_hash=_hash_key(raw_key),
        created_at=now,
    )
    await store.update_waitlist_status(entry_id, "approved", now)

    email_sent = send_api_key(to_email=entry["email"], name=entry["name"], api_key=raw_key)
    return ApproveResponse(
        entry_id=entry_id,
        workspace_id=workspace_id,
        email_sent=email_sent,
        message=f"Approved. Workspace {workspace_id} created.",
    )


# ---------------------------------------------------------------------------
# Admin: reject an entry
# ---------------------------------------------------------------------------


@router.post("/v1/admin/waitlist/{entry_id}/reject", response_model=RejectResponse)
@limiter.limit("20/minute")
async def reject_entry(entry_id: str, request: Request) -> RejectResponse:
    _require_admin(request)

    entry = await store.get_waitlist_entry(entry_id)
    if entry is None:
        raise HTTPException(status_code=404, detail="Waitlist entry not found.")
    if entry["status"] == "rejected":
        raise HTTPException(status_code=409, detail="Entry already rejected.")
    if entry["status"] == "approved":
        raise HTTPException(status_code=409, detail="Entry already approved — cannot reject.")

    await store.update_waitlist_status(entry_id, "rejected", datetime.now(timezone.utc))
    return RejectResponse(entry_id=entry_id, message="Entry rejected.")
