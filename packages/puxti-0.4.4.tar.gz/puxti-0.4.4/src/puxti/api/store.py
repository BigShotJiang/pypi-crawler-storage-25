"""
Store layer for the auth API.

InMemoryStore — async, dict-backed, used for local dev and tests.
_StoreContainer — transparent proxy that hot-swaps the underlying store.

When DATABASE_URL is set, main.py lifespan calls store.swap(PostgresStore(engine))
at startup. All callers use the module-level `store` singleton and never need
to change.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional


class InMemoryStore:
    """Async in-memory store for workspaces, trials, and API keys."""

    def __init__(self) -> None:
        self._workspaces: dict[str, dict] = {}
        self._trials: dict[str, dict] = {}
        self._keys: dict[str, dict] = {}
        self._emails: dict[str, str] = {}
        self._waitlist: dict[str, dict] = {}
        self._waitlist_emails: dict[str, str] = {}

    # ------------------------------------------------------------------
    # Workspaces
    # ------------------------------------------------------------------

    async def create_workspace(
        self, id: str, name: str, created_at: datetime, plan: str = "trial",
        email: str = "",
    ) -> None:
        normalised = email.lower().strip()
        self._workspaces[id] = {
            "id": id,
            "name": name,
            "created_at": created_at,
            "plan": plan,
            "email": normalised,
        }
        if normalised:
            self._emails[normalised] = id

    async def get_workspace(self, workspace_id: str) -> Optional[dict]:
        return self._workspaces.get(workspace_id)

    async def get_workspace_by_email(self, email: str) -> Optional[dict]:
        ws_id = self._emails.get(email.lower().strip())
        if ws_id is None:
            return None
        return self._workspaces.get(ws_id)

    # ------------------------------------------------------------------
    # Trials
    # ------------------------------------------------------------------

    async def create_trial(
        self,
        workspace_id: str,
        activated_at: datetime,
        expires_at: datetime,
        propagations_limit: int = 10,
        captures_limit: int = 25,
    ) -> None:
        self._trials[workspace_id] = {
            "workspace_id": workspace_id,
            "activated_at": activated_at,
            "expires_at": expires_at,
            "propagations_used": 0,
            "propagations_limit": propagations_limit,
            "captures_used": 0,
            "captures_limit": captures_limit,
        }

    async def get_trial(self, workspace_id: str) -> Optional[dict]:
        return self._trials.get(workspace_id)

    async def increment_trial(self, workspace_id: str, field: str) -> None:
        if workspace_id in self._trials:
            self._trials[workspace_id][field] = (
                self._trials[workspace_id].get(field, 0) + 1
            )

    # ------------------------------------------------------------------
    # API keys
    # ------------------------------------------------------------------

    async def create_key(
        self, workspace_id: str, key_hash: str, created_at: datetime
    ) -> None:
        self._keys[key_hash] = {
            "workspace_id": workspace_id,
            "key_hash": key_hash,
            "created_at": created_at,
            "last_used_at": None,
            "revoked_at": None,
        }

    async def get_key_by_hash(self, key_hash: str) -> Optional[dict]:
        return self._keys.get(key_hash)

    async def touch_key(self, key_hash: str) -> None:
        if key_hash in self._keys:
            self._keys[key_hash]["last_used_at"] = datetime.now(timezone.utc)

    async def revoke_key(self, key_hash: str) -> None:
        if key_hash in self._keys:
            self._keys[key_hash]["revoked_at"] = datetime.now(timezone.utc)

    # ------------------------------------------------------------------
    # Waitlist
    # ------------------------------------------------------------------

    async def create_waitlist_entry(
        self,
        id: str,
        name: str,
        email: str,
        company: str,
        title: str,
        consent: bool,
        submitted_at: datetime,
    ) -> None:
        normalised = email.lower().strip()
        self._waitlist[id] = {
            "id": id,
            "name": name,
            "email": normalised,
            "company": company,
            "title": title,
            "consent": consent,
            "submitted_at": submitted_at,
            "status": "pending",
            "reviewed_at": None,
        }
        self._waitlist_emails[normalised] = id

    async def get_waitlist_entry(self, entry_id: str) -> Optional[dict]:
        return self._waitlist.get(entry_id)

    async def get_waitlist_entry_by_email(self, email: str) -> Optional[dict]:
        entry_id = self._waitlist_emails.get(email.lower().strip())
        if entry_id is None:
            return None
        return self._waitlist.get(entry_id)

    async def update_waitlist_status(
        self, entry_id: str, status: str, reviewed_at: datetime
    ) -> None:
        if entry_id in self._waitlist:
            self._waitlist[entry_id]["status"] = status
            self._waitlist[entry_id]["reviewed_at"] = reviewed_at

    async def list_waitlist_entries(self) -> list[dict]:
        return sorted(
            self._waitlist.values(),
            key=lambda e: e["submitted_at"],
            reverse=True,
        )


class _StoreContainer:
    """
    Transparent proxy that delegates all attribute lookups to the underlying
    store. Call swap(new_store) at startup to hot-swap InMemoryStore for
    PostgresStore without changing any import in routes or middleware.
    """

    def __init__(self) -> None:
        self._store: InMemoryStore = InMemoryStore()

    def swap(self, new_store: object) -> None:
        self._store = new_store  # type: ignore[assignment]

    def __getattr__(self, name: str):
        return getattr(self._store, name)


# Module-level singleton — all routes and middleware import this.
store = _StoreContainer()
