"""Shared rate limiter instance — import this everywhere instead of creating a new Limiter."""
from slowapi import Limiter
from slowapi.util import get_remote_address
from starlette.requests import Request


def _get_client_ip(request: Request) -> str:
    """Prefer X-Forwarded-For when behind a trusted proxy, fall back to direct IP."""
    forwarded_for = request.headers.get("X-Forwarded-For")
    if forwarded_for:
        # Take the leftmost (client) IP; proxies append their own
        return forwarded_for.split(",")[0].strip()
    return get_remote_address(request)


limiter = Limiter(key_func=_get_client_ip, default_limits=["200/minute"])
