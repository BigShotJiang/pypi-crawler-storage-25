"""
Web app trial gating middleware.

Runs on every authenticated request and enforces trial state:
- Expired trial → 402 with upgrade link (read-only routes still allowed)
- Limit reached → 402 on the specific action only (not the whole app)
- Explore graph (GET /v1/graph/*) stays accessible on expired trial

Usage:
    from puxti.api.middleware.trial import TrialGatingMiddleware
    app.add_middleware(TrialGatingMiddleware)
"""
from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from typing import Callable

from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

from puxti.api.store import store

UPGRADE_URL = "https://getpuxti.com/upgrade"

# Routes that require a live trial or paid plan
# (tuple of (method, path_prefix) pairs)
_METERED_WRITE_ROUTES: tuple[tuple[str, str], ...] = (
    ("POST", "/v1/propagate"),
    ("POST", "/v1/capture"),
    ("POST", "/v1/scan"),
    ("POST", "/v1/redefine"),
    ("POST", "/v1/changes"),
    ("POST", "/v1/pr"),
)

# Routes that stay accessible even on an expired trial (read-only)
_READ_ONLY_ALLOWED_ON_EXPIRED: tuple[str, ...] = (
    "/v1/graph",       # explore graph — best upgrade prompt
    "/v1/entities",    # entity browser
    "/health",
    "/v1/auth",        # auth endpoints always open
)

# Exact paths that bypass trial gating (no auth header expected)
_UNPROTECTED_EXACT: frozenset[str] = frozenset({
    "/",
    "/health",
    "/favicon.ico",
    "/openapi.json",
})

# Prefix-matched paths that bypass trial gating
_UNPROTECTED_PREFIXES: tuple[str, ...] = (
    "/v1/auth/signup",
    "/v1/auth/validate",
    "/v1/auth/status",   # auth enforced by route handler (Bearer header)
    "/v1/usage/record",
    "/v1/waitlist",      # public waitlist submit; admin endpoints use X-Admin-Token
    "/v1/admin",         # admin auth enforced by route handlers (X-Admin-Token header)
    "/docs",
    "/redoc",
)


def _hash_key(raw_key: str) -> str:
    return hashlib.sha256(raw_key.encode()).hexdigest()


def _extract_api_key(request: Request) -> str | None:
    """Extract API key from Authorization: Bearer <key> header."""
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        return auth[7:].strip()
    return None


def _is_unprotected(path: str) -> bool:
    return path in _UNPROTECTED_EXACT or any(path.startswith(p) for p in _UNPROTECTED_PREFIXES)


def _is_read_only_allowed(path: str) -> bool:
    return any(path.startswith(p) for p in _READ_ONLY_ALLOWED_ON_EXPIRED)


def _is_metered_write(method: str, path: str) -> tuple[bool, str]:
    """Returns (is_metered, event_type) where event_type is 'propagation'|'capture'|'scan'."""
    for m, prefix in _METERED_WRITE_ROUTES:
        if method == m and path.startswith(prefix):
            if "propagat" in prefix or "redefin" in prefix or "pr" in prefix:
                return True, "propagation"
            elif "captur" in prefix:
                return True, "capture"
            elif "scan" in prefix:
                return True, "scan"
            return True, "unknown"
    return False, ""


class TrialGatingMiddleware(BaseHTTPMiddleware):
    """
    FastAPI/Starlette middleware that enforces trial state on every request.

    Decision tree:
      1. Unprotected path → pass through
      2. No API key → 401
      3. Invalid / revoked key → 401
      4. Paid plan (team | scale | enterprise) → pass through
      5. Trial active + under limits → pass through
      6. Trial expired:
         - Read-only route → pass through (explore graph stays open)
         - Write route → 402 Upgrade required
      7. Trial active but limit reached on this specific action → 402
    """

    def __init__(self, app: ASGIApp) -> None:
        super().__init__(app)

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        path = request.url.path
        method = request.method

        # 1. Unprotected
        if _is_unprotected(path):
            return await call_next(request)

        # 2. API key required
        api_key = _extract_api_key(request)
        if not api_key:
            return JSONResponse(
                status_code=401,
                content={"detail": "Authentication required. Pass your API key as: Authorization: Bearer <key>"},
            )

        # 3. Validate key
        key_hash = _hash_key(api_key)
        key_record = await store.get_key_by_hash(key_hash)
        if key_record is None or key_record.get("revoked_at") is not None:
            return JSONResponse(
                status_code=401,
                content={"detail": "Invalid or revoked API key."},
            )

        workspace = await store.get_workspace(key_record["workspace_id"])
        if workspace is None:
            return JSONResponse(status_code=401, content={"detail": "Workspace not found."})

        plan = workspace["plan"]

        # 4. Paid plans — no restrictions
        if plan in ("team", "scale", "enterprise"):
            request.state.workspace_id = workspace["id"]
            request.state.plan = plan
            return await call_next(request)

        # 5/6/7. Trial plan checks
        trial = await store.get_trial(workspace["id"])
        now = datetime.now(timezone.utc)
        trial_active = trial is not None and trial["expires_at"] > now

        if not trial_active:
            if _is_read_only_allowed(path):
                # Expired trial — still allow read-only access (explore graph)
                request.state.workspace_id = workspace["id"]
                request.state.plan = "trial_expired"
                return await call_next(request)
            return JSONResponse(
                status_code=402,
                content={
                    "detail": "Trial expired. Upgrade to continue.",
                    "upgrade_url": UPGRADE_URL,
                },
            )

        # Trial is active — check per-action limits on metered writes
        is_metered, event_type = _is_metered_write(method, path)
        if is_metered and trial:
            if event_type == "propagation":
                used, limit = trial["propagations_used"], trial["propagations_limit"]
                if used >= limit:
                    return JSONResponse(
                        status_code=402,
                        content={
                            "detail": f"Propagation limit reached ({used}/{limit} on Trial).",
                            "upgrade_url": UPGRADE_URL,
                        },
                    )
            elif event_type == "capture":
                used, limit = trial["captures_used"], trial["captures_limit"]
                if used >= limit:
                    return JSONResponse(
                        status_code=402,
                        content={
                            "detail": f"Capture limit reached ({used}/{limit} on Trial).",
                            "upgrade_url": UPGRADE_URL,
                        },
                    )

        request.state.workspace_id = workspace["id"]
        request.state.plan = plan
        return await call_next(request)
