"""
PostgreSQL-backed store using SQLAlchemy async Core.

All methods are async and match the InMemoryStore interface exactly.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncEngine

from puxti.api.database import api_keys, trials, waitlist, workspaces


class PostgresStore:
    def __init__(self, engine: AsyncEngine) -> None:
        self._engine = engine

    # ------------------------------------------------------------------
    # Workspaces
    # ------------------------------------------------------------------

    async def create_workspace(
        self, id: str, name: str, created_at: datetime, plan: str = "trial",
        email: str = "",
    ) -> None:
        async with self._engine.begin() as conn:
            await conn.execute(
                workspaces.insert().values(
                    id=id,
                    name=name,
                    email=email.lower().strip(),
                    plan=plan,
                    created_at=created_at,
                )
            )

    async def get_workspace(self, workspace_id: str) -> Optional[dict]:
        async with self._engine.connect() as conn:
            result = await conn.execute(
                select(workspaces).where(workspaces.c.id == workspace_id)
            )
            row = result.mappings().first()
            return dict(row) if row else None

    async def get_workspace_by_email(self, email: str) -> Optional[dict]:
        async with self._engine.connect() as conn:
            result = await conn.execute(
                select(workspaces).where(
                    workspaces.c.email == email.lower().strip()
                )
            )
            row = result.mappings().first()
            return dict(row) if row else None

    # ------------------------------------------------------------------
    # Trials
    # ------------------------------------------------------------------

    async def create_trial(
        self,
        workspace_id: str,
        activated_at: datetime,
        expires_at: datetime,
        propagations_limit: int = 10,
        captures_limit: int = 25,
    ) -> None:
        async with self._engine.begin() as conn:
            await conn.execute(
                trials.insert().values(
                    workspace_id=workspace_id,
                    activated_at=activated_at,
                    expires_at=expires_at,
                    propagations_used=0,
                    propagations_limit=propagations_limit,
                    captures_used=0,
                    captures_limit=captures_limit,
                )
            )

    async def get_trial(self, workspace_id: str) -> Optional[dict]:
        async with self._engine.connect() as conn:
            result = await conn.execute(
                select(trials).where(trials.c.workspace_id == workspace_id)
            )
            row = result.mappings().first()
            return dict(row) if row else None

    async def increment_trial(self, workspace_id: str, field: str) -> None:
        """Atomic increment using UPDATE ... SET col = col + 1."""
        col = getattr(trials.c, field)
        async with self._engine.begin() as conn:
            await conn.execute(
                update(trials)
                .where(trials.c.workspace_id == workspace_id)
                .values({field: col + 1})
            )

    # ------------------------------------------------------------------
    # API keys
    # ------------------------------------------------------------------

    async def create_key(
        self, workspace_id: str, key_hash: str, created_at: datetime
    ) -> None:
        async with self._engine.begin() as conn:
            await conn.execute(
                api_keys.insert().values(
                    key_hash=key_hash,
                    workspace_id=workspace_id,
                    created_at=created_at,
                    last_used_at=None,
                    revoked_at=None,
                )
            )

    async def get_key_by_hash(self, key_hash: str) -> Optional[dict]:
        async with self._engine.connect() as conn:
            result = await conn.execute(
                select(api_keys).where(api_keys.c.key_hash == key_hash)
            )
            row = result.mappings().first()
            return dict(row) if row else None

    async def touch_key(self, key_hash: str) -> None:
        async with self._engine.begin() as conn:
            await conn.execute(
                update(api_keys)
                .where(api_keys.c.key_hash == key_hash)
                .values(last_used_at=datetime.now(timezone.utc))
            )

    async def revoke_key(self, key_hash: str) -> None:
        async with self._engine.begin() as conn:
            await conn.execute(
                update(api_keys)
                .where(api_keys.c.key_hash == key_hash)
                .values(revoked_at=datetime.now(timezone.utc))
            )

    # ------------------------------------------------------------------
    # Waitlist
    # ------------------------------------------------------------------

    async def create_waitlist_entry(
        self,
        id: str,
        name: str,
        email: str,
        company: str,
        title: str,
        consent: bool,
        submitted_at: datetime,
    ) -> None:
        async with self._engine.begin() as conn:
            await conn.execute(
                waitlist.insert().values(
                    id=id,
                    name=name,
                    email=email.lower().strip(),
                    company=company,
                    title=title,
                    consent=consent,
                    submitted_at=submitted_at,
                    status="pending",
                    reviewed_at=None,
                )
            )

    async def get_waitlist_entry(self, entry_id: str) -> Optional[dict]:
        async with self._engine.connect() as conn:
            result = await conn.execute(
                select(waitlist).where(waitlist.c.id == entry_id)
            )
            row = result.mappings().first()
            return dict(row) if row else None

    async def get_waitlist_entry_by_email(self, email: str) -> Optional[dict]:
        async with self._engine.connect() as conn:
            result = await conn.execute(
                select(waitlist).where(
                    waitlist.c.email == email.lower().strip()
                )
            )
            row = result.mappings().first()
            return dict(row) if row else None

    async def update_waitlist_status(
        self, entry_id: str, status: str, reviewed_at: datetime
    ) -> None:
        async with self._engine.begin() as conn:
            await conn.execute(
                update(waitlist)
                .where(waitlist.c.id == entry_id)
                .values(status=status, reviewed_at=reviewed_at)
            )

    async def list_waitlist_entries(self) -> list[dict]:
        async with self._engine.connect() as conn:
            result = await conn.execute(
                select(waitlist).order_by(waitlist.c.submitted_at.desc())
            )
            return [dict(row) for row in result.mappings()]
