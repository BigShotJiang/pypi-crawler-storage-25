# Puxti

Organizational knowledge layer for data teams. Puxti lowers the cost of evolving data models by making implicit definitions explicit at the moment of change — and propagating them downstream as reviewable PRs.

---

> **Early Access — Design Partner Build**
>
> You have access to this software as a Puxti design partner. It is under active development — expect rough edges and breaking changes between versions. Your feedback directly shapes the product.
>
> **What leaves your environment:** Puxti sends your dbt model SQL and schema metadata (model names, column names, descriptions) to the Anthropic API for semantic reasoning. No raw data from your warehouse is accessed or transmitted — only the SQL text and metadata in your dbt project. If your SQL contains sensitive identifiers, be aware before running `scan` or `redefine`.
>
> By using this software you agree to the terms in [LICENSE](./LICENSE). Puxti is a product of Okolico Ventures UG (haftungsbeschränkt).

---

## How it works

Puxti sits in the critical path of making data changes. Every change goes through two layers:

- **Structural layer** — entities, lineage edges, and column-level relationships extracted from your dbt manifest
- **Semantic layer** — business definitions and conceptual dependencies between entities, captured when changes are made

Together, these layers let Puxti reason about what a change *means* across the stack, not just what it touches mechanically.

### Three types of change

| Case | Example | How Puxti handles it |
|------|---------|----------------------|
| Column rename | `order_date` → `recorded_date` | Deterministic find-and-replace across all dbt models, opened as a PR |
| Definition redefinition | `gross_revenue` now excludes refunds | Traverses the semantic graph to find downstream entities whose *meaning* is now affected — annotates files for human review |
| Attribute surfacing | A field becomes a first-class business concept | *(coming in M3)* |

---

## Requirements

- **Python 3.12+**
- **[uv](https://docs.astral.sh/uv/)** — Python package manager
- **Docker** — for running Neo4j locally
- **Anthropic API key** — for semantic reasoning ([get one here](https://console.anthropic.com))
- **GitHub personal access token** — with `repo` scope (Contents + Pull requests write)
- **A dbt project** with a compiled `manifest.json` (`dbt compile` or `dbt run`)

---

## Installation

```bash
pip install puxti
```

### Authenticate

Every CLI command that touches the backend requires an API key. Sign up at [getpuxti.com/signup](https://getpuxti.com/signup) — your key arrives by email.

```bash
puxti auth pk_live_<your-key>
```

This stores the key in `~/.puxti/config.toml`. You only need to do this once per machine.

```bash
puxti auth --status    # show trial usage and days remaining
puxti auth --logout    # remove the stored key
```

**Trial limits:** 30 days · 10 propagations (`redefine`) · 25 captures (`capture`). `--dry-run` on any command does not consume credits.

---

## Configuration

Copy the example env file and fill in your credentials:

```bash
cp .env.example .env
```

| Variable | Description |
|---|---|
| `NEO4J_URI` | Bolt connection string — `bolt://localhost:7687` if running locally via Docker |
| `NEO4J_USERNAME` | Neo4j username — `neo4j` by default |
| `NEO4J_PASSWORD` | Neo4j password — must match `NEO4J_AUTH` in `docker-compose.yml` |
| `ANTHROPIC_API_KEY` | Your Anthropic API key — get one at [console.anthropic.com](https://console.anthropic.com) |
| `GITHUB_TOKEN` | Personal access token with `repo` scope (Contents + Pull requests write) |
| `DBT_PROJECT_DIR` | Path to your dbt project root (the directory containing `dbt_project.yml`) |
| `DBT_PROFILES_DIR` | Path to your dbt profiles directory — usually `~/.dbt` |

```env
# Neo4j — matches the Docker Compose defaults below
NEO4J_URI=bolt://localhost:7687
NEO4J_USERNAME=neo4j
NEO4J_PASSWORD=puxti_dev

# Anthropic
ANTHROPIC_API_KEY=your_api_key_here

# GitHub
GITHUB_TOKEN=your_github_token_here

# dbt
DBT_PROJECT_DIR=./dbt
DBT_PROFILES_DIR=~/.dbt
```

---

## Start Neo4j

Puxti uses Neo4j as its Knowledge Graph store. The included `docker-compose.yml` runs Neo4j 5.20 (Community) with the APOC plugin enabled — required for graph traversal queries.

```bash
docker compose up -d
```

```yaml
services:
  neo4j:
    image: neo4j:5.20-community
    container_name: puxti-neo4j
    ports:
      - "7474:7474"   # Neo4j browser UI
      - "7687:7687"   # Bolt driver (used by Puxti)
    environment:
      NEO4J_AUTH: neo4j/puxti_dev          # matches NEO4J_USERNAME/PASSWORD in .env
      NEO4J_PLUGINS: '["apoc"]'            # required for graph traversal
    volumes:
      - neo4j_data:/data                   # graph data persists across restarts
      - neo4j_logs:/logs
```

Neo4j browser is available at `http://localhost:7474` — useful for inspecting the Knowledge Graph directly. The Bolt endpoint at `bolt://localhost:7687` is what Puxti connects to.

To stop Neo4j without losing data:

```bash
docker compose down
```

To wipe the graph data entirely (e.g. to start fresh):

```bash
docker compose down -v
```

## Verify setup

```bash
uv run puxti health
```

Expected output:

```
✓ Neo4j
✓ Anthropic API key
✓ dbt manifest
```

> **Note:** The Anthropic check confirms your key is valid — it does not verify credit balance. The Anthropic API has no balance endpoint. A depleted account will only surface as an error when you run `capture`.

---

## Usage

### Step 1 — Bootstrap the Knowledge Graph

Run this once before using `capture` or `redefine`. It reads your dbt manifest, populates the structural lineage graph, and uses the LLM to infer starter definitions for each model — using SQL, upstream context, and any descriptions already in your dbt yml files.

Two modes:

- **Interactive** — walks through each model one by one. The LLM proposes a definition; you confirm, edit, or skip before anything is written. Slower, higher accuracy. Recommended for first onboarding.
- **Auto** — generates all definitions in one pass, shows a summary table, and asks for a single confirmation before writing. Faster, but review carefully.

```bash
# Interactive mode
uv run puxti scan --dbt-project-dir /path/to/dbt --interactive

# Auto mode
uv run puxti scan --dbt-project-dir /path/to/dbt
```

Nothing is written to the Knowledge Graph without your explicit confirmation.

After definitions are confirmed, Puxti also proposes initial semantic edges between models (e.g. `customer_lifetime_value` derived from `gross_revenue`) and asks you to confirm those as a group.

---

### Step 2a — Capture a column rename

```bash
uv run puxti capture --entity "model.jaffle_shop.orders.order_date" --before "order_date" --after "recorded_date" --description "Renamed to clarify this is the date the order was recorded in the system, not the transaction date. Downstream KPIs that filter on date ranges are affected." --repo "your-org/your-dbt-repo"
```

Puxti will:

1. Call the LLM to enrich your description and reason about affected entities
2. Scan your dbt models for references to `order_date`
3. Generate diffs replacing all occurrences with `recorded_date`
4. Open a PR on `your-org/your-dbt-repo` with the diffs and semantic context

#### `capture` options

| Flag | Required | Description |
|------|----------|-------------|
| `--entity` / `-e` | Yes | Full entity ID (e.g. `model.project.model.column`) |
| `--before` | Yes | Value before the change (old column name) |
| `--after` | Yes | Value after the change (new column name) |
| `--description` / `-d` | Yes | Human description of what the change means and why |
| `--repo` | Yes | GitHub repo to open the PR against (`owner/repo`) |
| `--base-branch` | No | Base branch for the PR (default: `main`) |
| `--dbt-project-dir` | No | Path to dbt project root (overrides `DBT_PROJECT_DIR`) |
| `--dry-run` | No | Estimate token count and cost without running the capture |

---

### Step 2b — Redefine what an entity means

Use this when the *meaning* of an entity changes — not a rename, a conceptual shift (e.g. a revenue metric now excludes refunds). The structural graph hasn't changed, but downstream entities that depend on that *meaning* may now be wrong.

```bash
uv run puxti redefine --entity "model.jaffle_shop.orders.gross_revenue" --description "gross_revenue now excludes refunds — only settled transactions count." --repo "your-org/your-dbt-repo"
```

Puxti will:

1. Traverse the semantic graph to find downstream entities whose meaning is now affected (falls back to structural lineage if the semantic graph is empty)
2. Walk the structural ancestor chain upstream — every model between the ingestion boundary and the redefined entity needs to pass the new attribute through
3. Generate SQL diffs with depth-aware confidence:
   - Hop 1: `PUXTI [high confidence]` — direct dependent, LLM-generated SQL
   - Hop 2: `PUXTI [verify carefully]` — LLM-generated SQL across 2 hops, logic inferred
   - Hop 3+: `PUXTI [manual review required]` — annotation only, chain too deep to generate reliably
4. Open a single PR with both upstream passthrough diffs and downstream semantic diffs

The PR is **deployable in order**: apply upstream passthrough changes first so new attributes exist before downstream models reference them. Each diff includes an `⚠️ UPSTREAM DEPENDENCY` note where ordering matters.

#### `redefine` options

| Flag | Required | Description |
|------|----------|-------------|
| `--entity` / `-e` | Yes | Entity ID whose meaning is changing |
| `--description` / `-d` | Yes | What the entity now means |
| `--repo` | No | GitHub repo to open the PR against (`owner/repo`) — required unless `--dry-run` |
| `--base-branch` | No | Base branch for the PR (default: `main`) |
| `--dbt-project-dir` | No | Path to dbt project root (overrides `DBT_PROJECT_DIR`) |
| `--dry-run` | No | Estimate token count and cost without calling the LLM or opening a PR |

---

### Step 2c — Correct an inaccurate definition

Use this when puxti inferred a wrong definition during scan, or when you want to refine one without triggering code propagation. This is not a business change — it fixes what puxti got wrong about something that was always true.

```bash
uv run puxti correct --entity "model.jaffle_shop.orders"
```

Puxti will:

1. Show the current definition and all semantic edges involving the entity
2. Ask you to enter the corrected definition
3. Re-evaluate each edge via LLM against the new definition (keep / update / remove)
4. Show a summary and ask you to confirm before writing
5. Ask whether this is a correction (fix KG only) or a real change (hand off to `redefine`)

Nothing is written without your explicit confirmation.

#### `correct` options

| Flag | Required | Description |
|------|----------|-------------|
| `--entity` / `-e` | Yes | Entity ID to correct |
| `--project` / `-p` | No | Validate the entity belongs to this project before proceeding |

---

### Step 3 — Inspect the Knowledge Graph

```bash
# Full overview — all entities grouped by project, all semantic edges
uv run puxti describe

# Filter overview to a single project
uv run puxti describe --project jaffle_shop

# Single entity — full definition, incoming and outgoing edges
uv run puxti describe --entity "model.jaffle_shop.orders"
```

#### `describe` options

| Flag | Required | Description |
|------|----------|-------------|
| `--entity` / `-e` | No | Entity ID to inspect in detail. Omit for full KG overview. |
| `--project` / `-p` | No | Filter overview to a single project. Ignored when `--entity` is set. |

---

### Step 4 — Purge project data

Use this to remove a project's data from the Knowledge Graph — for example, when switching to a new dbt project or cleaning up after testing.

```bash
# Remove a single project
uv run puxti purge --project jaffle_shop

# Wipe the entire Knowledge Graph
uv run puxti purge --all
```

Both variants require typing `yes` in full before anything is deleted. Run `puxti describe` first to see what projects are in the graph.

#### `purge` options

| Flag | Required | Description |
|------|----------|-------------|
| `--project` / `-p` | One of these | Project name to remove |
| `--all` | One of these | Wipe the entire Knowledge Graph |

---

## Known Limitations

These are rough edges we are aware of and actively working on. You do not need to report them — but if you have a strong opinion on priority or approach, the feedback doc is the place to say so.

**Re-scanning after dbt project changes**
`puxti scan` is safe to re-run at any time — it upserts entities and definitions, so new models and columns will be added and existing ones updated. However, there is no prompt or workflow that reminds you to re-scan when your dbt project changes. For now: run `puxti scan` again whenever you add models, rename columns in your dbt layer, or change descriptions in yml files. We are planning a watch/diff mode.

**Finding entity IDs**
Commands like `capture`, `redefine`, and `correct` require a full entity ID (e.g. `model.jaffle_shop.orders.order_date`). If you are not sure of an entity's ID, run `puxti describe` first — it lists all entities with their full IDs. We know this is friction and are working on inline search.

**The `correct` → `redefine` handoff**
When you classify a correction as a "real change", puxti prints the `redefine` command to run next but does not execute it automatically. You need to copy-paste and run it yourself. This seam will be removed in a future version.

---

## Development

### Setup

```bash
uv sync --extra dev    # install runtime + dev dependencies (pytest, ruff, twine)
```

> `uv sync` without `--extra dev` installs only runtime dependencies. Tests and linting tools will not be available until you run `uv sync --extra dev`.

### Running tests

```bash
uv run pytest                    # run all tests
uv run pytest tests/auth/        # run auth/trial layer tests only
uv run pytest tests/test_cli.py  # run CLI command tests only
uv run pytest -v                 # verbose output
```

### Linting and formatting

```bash
uv run ruff check src/     # lint
uv run ruff format src/    # format
```

---

## Project structure

```
src/puxti/
├── cli.py                  # entry point — all commands (including puxti auth)
├── models.py               # all data types (Pydantic)
├── settings.py             # config (reads from .env)
├── auth/
│   ├── config.py           # ~/.puxti/config.toml read/write (API key + trial cache)
│   ├── client.py           # httpx client for /v1/auth/validate and /v1/usage/record
│   └── middleware.py       # require_valid_trial() + record_usage() — wired into CLI commands
├── api/
│   ├── main.py             # FastAPI app — rate limiting, CORS, trial middleware
│   ├── models.py           # API request/response shapes
│   ├── store.py            # in-memory store (replace with PostgreSQL pre-production)
│   ├── limiter.py          # shared slowapi rate limiter instance
│   ├── routes/
│   │   └── auth.py         # /v1/auth/validate, /v1/auth/signup, /v1/usage/record
│   └── middleware/
│       └── trial.py        # TrialGatingMiddleware — enforces trial on web app routes
├── core/
│   ├── capture.py          # semantic capture — LLM enrichment + Knowledge Graph write
│   ├── graph.py            # Knowledge Graph — Neo4j interface
│   ├── scanner.py          # puxti scan — bootstraps KG from dbt manifest
│   └── redefine.py         # puxti redefine — semantic change propagation
├── connectors/
│   ├── base.py             # connector interface
│   ├── dbt.py              # dbt connector — entity extraction + diffs
│   └── github.py           # GitHub connector — PR creation
└── propagation/
    └── engine.py           # propagation engine — orchestrates connectors
```
