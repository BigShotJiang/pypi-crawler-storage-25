"""Shared fixtures — the critical one redirects $HOME to a tmp directory
so tests never touch the real `~/.claude/settings.json` or
`~/.cc-guard/` state.
"""

from __future__ import annotations

from pathlib import Path

import pytest


@pytest.fixture
def fake_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect `Path.home()` to `tmp_path` and scrub leaked env vars.

    All modules in cc_guard resolve `Path.home()` lazily inside
    functions (not at import time), so this works uniformly.

    Also clears:
    - `ANTHROPIC_BASE_URL` (would otherwise leak into doctor / status output)
    - `LANG` / `LC_ALL` / `LC_MESSAGES` (would otherwise make tests
      English-or-Chinese depending on the developer's shell — we pin to
      English so assertions are deterministic; specific i18n tests opt
      back into Chinese explicitly)
    """
    monkeypatch.setenv("HOME", str(tmp_path))
    # pathlib.Path.home() on POSIX reads $HOME via os.path.expanduser
    # Make doubly sure by also monkeypatching Path.home if needed
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    # Clean env so tests don't inherit the developer's shell state
    monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
    monkeypatch.delenv("LANG", raising=False)
    monkeypatch.delenv("LC_ALL", raising=False)
    monkeypatch.delenv("LC_MESSAGES", raising=False)
    # Reset i18n cache so the cleared locale takes effect immediately
    from cc_guard import i18n
    i18n.reset_cache()
    return tmp_path
