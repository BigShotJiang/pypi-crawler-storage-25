"""End-to-end tests: full install → status → doctor → uninstall cycle.

These tests verify that running the CLI commands in sequence leaves
the filesystem in a byte-identical state to where it started — the
strongest guarantee we can offer about clean uninstall.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from cc_guard.cli import app

runner = CliRunner()


def test_full_cycle_byte_identical(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """Install then uninstall must produce byte-identical settings.json
    (modulo JSON formatting which is stable because we use indent=2)."""
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    # Realistic pre-state
    settings = fake_home / ".claude" / "settings.json"
    settings.parent.mkdir(parents=True)
    original = {
        "env": {
            "ANTHROPIC_AUTH_TOKEN": "sk-ant-user-own-token",
            "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1",
        },
        "enabledPlugins": {
            "code-review@official": True,
            "frontend-design@official": False,
        },
        "language": "中文",
        "effortLevel": "high",
    }
    # Write with the same flags atomic_write_json uses, so byte-identical
    # comparison after uninstall is meaningful for non-ASCII content
    settings.write_text(json.dumps(original, indent=2, ensure_ascii=False) + "\n")
    original_bytes = settings.read_bytes()

    # install
    install_result = runner.invoke(
        app,
        ["install", "http://127.0.0.1:9999", "-t", "3000000"],
    )
    assert install_result.exit_code == 0, install_result.stdout

    # Verify during install
    mid = json.loads(settings.read_text())
    assert mid["env"]["ANTHROPIC_BASE_URL"] == "http://127.0.0.1:9999"
    assert mid["env"]["API_TIMEOUT_MS"] == "3000000"
    assert mid["env"]["ANTHROPIC_AUTH_TOKEN"] == "sk-ant-user-own-token"
    assert mid["language"] == "中文"

    # status should report installed
    status_result = runner.invoke(app, ["status"])
    assert status_result.exit_code == 0
    assert "yes" in status_result.stdout.lower()

    # doctor should pass (with no-probe)
    doctor_result = runner.invoke(app, ["doctor", "--no-probe"])
    assert doctor_result.exit_code == 0

    # uninstall
    uninstall_result = runner.invoke(app, ["uninstall"])
    assert uninstall_result.exit_code == 0, uninstall_result.stdout

    # Byte-identical after uninstall
    after_bytes = settings.read_bytes()
    assert after_bytes == original_bytes, (
        f"settings.json drifted:\n"
        f"before: {original_bytes!r}\n"
        f"after:  {after_bytes!r}"
    )

    # state.yaml has been cleared (or doesn't track claude-code)
    import yaml
    state = yaml.safe_load((fake_home / ".cc-guard" / "state.yaml").read_text())
    assert "claude-code" not in (state.get("installs") or {})

    # status after uninstall
    status2 = runner.invoke(app, ["status"])
    assert status2.exit_code == 0
    assert "no" in status2.stdout.lower()


def test_full_cycle_with_shell_rc(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """When .zshrc has a conflicting export, install cleans it, and
    uninstall --restore-shell-rc brings it back exactly."""
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    rc = fake_home / ".zshrc"
    original_rc = """# zsh config
export PATH=$HOME/.local/bin:$PATH
export ANTHROPIC_BASE_URL=https://old.example.com
export ANTHROPIC_API_KEY=sk-ant-stays
alias ll='ls -la'
"""
    rc.write_text(original_rc)

    runner.invoke(
        app,
        ["install", "http://127.0.0.1:9999"],
    )

    # Mid-state: rc is cleaned
    mid_rc = rc.read_text()
    assert "ANTHROPIC_BASE_URL" not in mid_rc
    assert "ANTHROPIC_API_KEY=sk-ant-stays" in mid_rc    # credentials untouched
    assert "alias ll" in mid_rc

    runner.invoke(app, ["uninstall"])

    # After uninstall + --restore-shell-rc: rc is byte-identical
    assert rc.read_text() == original_rc


def test_install_then_install_different_url(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """Two installs without an uninstall between: backup must survive so
    eventual uninstall restores the very original value."""
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    settings = fake_home / ".claude" / "settings.json"
    settings.parent.mkdir(parents=True)
    settings.write_text(json.dumps({
        "env": {"ANTHROPIC_BASE_URL": "https://original.example.com"},
    }))

    # Install A, then B (without uninstalling A first)
    runner.invoke(
        app, ["install", "http://127.0.0.1:9999"],
    )
    runner.invoke(
        app, ["install", "http://127.0.0.1:8888"],
    )

    # State reflects the latest install
    data = json.loads(settings.read_text())
    assert data["env"]["ANTHROPIC_BASE_URL"] == "http://127.0.0.1:8888"

    # Uninstall should restore the *original* (A+B backup should still
    # preserve the earliest value — https://original.example.com)
    runner.invoke(app, ["uninstall"])

    data = json.loads(settings.read_text())
    assert data["env"]["ANTHROPIC_BASE_URL"] == "https://original.example.com"


def test_doctor_detects_manually_broken_settings(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """If the user manually corrupts settings.json, doctor must report it
    as an error (not a warning)."""
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    settings = fake_home / ".claude" / "settings.json"
    settings.parent.mkdir(parents=True)
    settings.write_text("{{{ not valid json")

    result = runner.invoke(app, ["doctor", "--no-probe"])
    assert result.exit_code == 1
    assert "not valid" in result.stdout.lower() or "error" in result.stdout.lower()
