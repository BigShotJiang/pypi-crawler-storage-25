"""CLI tests via typer.testing.CliRunner.

Covers:
  - version / --help
  - install: happy path, dry-run, already installed, confirmation refusal
  - install: shell rc cleanup path
  - uninstall: happy path, not installed, dry-run, --restore-shell-rc
  - status: uninstalled, installed, installed-but-drifted
  - doctor: clean / with warning
"""

from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest
import yaml
from typer.testing import CliRunner

from cc_guard.cli import app

runner = CliRunner()


def _read_settings(path: Path) -> dict:
    return json.loads(path.read_text())


def _read_state(path: Path) -> dict:
    return yaml.safe_load(path.read_text())


# ── trivial commands ────────────────────────────────────────

def test_version():
    result = runner.invoke(app, ["version"])
    assert result.exit_code == 0
    assert "cc-guard" in result.stdout


def test_help():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "install" in result.stdout
    assert "uninstall" in result.stdout
    assert "status" in result.stdout
    assert "doctor" in result.stdout


# ── install ─────────────────────────────────────────────────

def test_install_happy_path(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """Greenfield install — no prior settings, no shell rc conflicts."""
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    result = runner.invoke(
        app,
        ["install", "http://127.0.0.1:9999"],
    )
    assert result.exit_code == 0, result.stdout

    # settings.json has the new URL
    settings = _read_settings(fake_home / ".claude" / "settings.json")
    assert settings["env"]["ANTHROPIC_BASE_URL"] == "http://127.0.0.1:9999"

    # state.yaml records the install
    state = _read_state(fake_home / ".cc-guard" / "state.yaml")
    assert "claude-code" in state["installs"]
    assert state["installs"]["claude-code"]["upstream"] == "http://127.0.0.1:9999"


def test_install_dry_run_does_not_write(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    result = runner.invoke(
        app,
        ["install", "http://127.0.0.1:9999", "--dry-run"],
    )
    assert result.exit_code == 0
    assert "Dry run" in result.stdout

    # Nothing was written
    assert not (fake_home / ".claude" / "settings.json").exists()
    assert not (fake_home / ".cc-guard" / "state.yaml").exists()


def test_install_missing_upstream_fails(fake_home: Path):
    result = runner.invoke(app, ["install"])
    assert result.exit_code != 0


def test_install_already_installed_short_circuits(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    runner.invoke(
        app,
        ["install", "http://127.0.0.1:9999"],
    )

    # Second install: same URL
    result = runner.invoke(
        app,
        ["install", "http://127.0.0.1:9999"],
    )
    assert result.exit_code == 0
    assert "Already installed" in result.stdout


def test_install_warns_on_env_var_override(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """If the current shell env has ANTHROPIC_BASE_URL set to something else,
    install should print a warning in the plan (but still proceed)."""
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")
    monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://existing.example.com")

    result = runner.invoke(
        app,
        ["install", "http://127.0.0.1:9999"],
    )
    assert result.exit_code == 0, result.stdout
    assert "existing.example.com" in result.stdout
    assert "OVERRIDE" in result.stdout
    assert "unset" in result.stdout.lower()


def test_install_no_warning_when_env_matches_upstream(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """If shell env and upstream agree, no override warning."""
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")
    monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://127.0.0.1:9999")

    result = runner.invoke(
        app,
        ["install", "http://127.0.0.1:9999"],
    )
    assert result.exit_code == 0, result.stdout
    assert "OVERRIDE" not in result.stdout


def test_install_cleans_shell_rc(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """Install should remove conflicting export from .zshrc."""
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    rc = fake_home / ".zshrc"
    rc.write_text(
        "export PATH=$HOME/bin:$PATH\n"
        "export ANTHROPIC_BASE_URL=https://old.example.com\n"
        "alias ll='ls -la'\n"
    )

    result = runner.invoke(
        app,
        ["install", "http://127.0.0.1:9999"],
    )
    assert result.exit_code == 0, result.stdout

    # ANTHROPIC_BASE_URL is gone from .zshrc
    after = rc.read_text()
    assert "ANTHROPIC_BASE_URL" not in after
    assert "export PATH" in after            # other lines preserved
    assert "alias ll" in after

    # state.yaml records the shell rc change
    state = _read_state(fake_home / ".cc-guard" / "state.yaml")
    changes = state["installs"]["claude-code"]["shell_rc_changes"]
    assert len(changes) == 1
    assert changes[0]["path"] == str(rc)
    assert changes[0]["removed_line_count"] == 1


def test_install_preserves_auth_token(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """Via the CLI, ANTHROPIC_AUTH_TOKEN must still pass through unchanged."""
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    settings = fake_home / ".claude" / "settings.json"
    settings.parent.mkdir(parents=True)
    settings.write_text(json.dumps({
        "env": {"ANTHROPIC_AUTH_TOKEN": "sk-ant-preserve-me"},
    }))

    runner.invoke(
        app,
        ["install", "http://127.0.0.1:9999"],
    )

    data = _read_settings(settings)
    assert data["env"]["ANTHROPIC_AUTH_TOKEN"] == "sk-ant-preserve-me"
    assert data["env"]["ANTHROPIC_BASE_URL"] == "http://127.0.0.1:9999"


# ── uninstall ───────────────────────────────────────────────

def test_uninstall_without_install(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    result = runner.invoke(app, ["uninstall"])
    assert result.exit_code == 2
    assert "Not installed" in result.stdout


def test_uninstall_happy_path(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    runner.invoke(
        app,
        ["install", "http://127.0.0.1:9999"],
    )

    result = runner.invoke(app, ["uninstall"])
    assert result.exit_code == 0, result.stdout

    # settings.json no longer has our URL
    settings = _read_settings(fake_home / ".claude" / "settings.json")
    assert "env" not in settings or "ANTHROPIC_BASE_URL" not in settings.get("env", {})

    # state.yaml has been cleared of claude-code
    state = _read_state(fake_home / ".cc-guard" / "state.yaml")
    assert "claude-code" not in (state.get("installs") or {})


def test_uninstall_cleans_managed_sidecar_and_hub_token(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """If the install record was for a managed sidecar with a hub token,
    uninstall must stop the sidecar AND delete the hub-token file.

    Otherwise a later `install --hub DIFFERENT_HUB` would silently inherit
    the previous hub's credentials via the env var export.
    """
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    # Seed an install record with a managed sidecar (bypass the real
    # install path — we don't want to spawn a real flowlens here)
    from cc_guard.state import InstallRecord, ManagedSidecar, StateStore
    from cc_guard.sidecar import hub_token_file, write_hub_token

    store = StateStore()
    store.record_install("claude-code", InstallRecord(
        upstream="http://127.0.0.1:28001",
        installed_at="2026-04-09T00:00:00Z",
        settings_backup="/fake/backup.json",
        backup_base_url=None,
        api_timeout_ms=None,
        shell_rc_changes=[],
        sidecar=ManagedSidecar(
            pid=999999,  # not alive, stop_managed_sidecar will short-circuit
            config_path=str(fake_home / ".cc-guard" / "sidecar.yaml"),
            listen="127.0.0.1:28001",
            started_at="2026-04-09T00:00:00Z",
        ),
    ))

    # Seed the hub-token file as if install had written it
    write_hub_token("shared-secret-from-previous-install")
    assert hub_token_file().exists()

    # Pretend the pid file also exists so stop_managed_sidecar goes
    # through its "dead pid → cleanup" branch
    pid_file = fake_home / ".cc-guard" / "sidecar.pid"
    pid_file.write_text("999999")

    # Create minimal settings.json so mgr.uninstall() doesn't choke
    settings = fake_home / ".claude" / "settings.json"
    settings.parent.mkdir(parents=True, exist_ok=True)
    settings.write_text(json.dumps({
        "env": {"ANTHROPIC_BASE_URL": "http://127.0.0.1:28001"},
    }))

    result = runner.invoke(app, ["uninstall"])
    assert result.exit_code == 0, result.stdout

    # Hub token must be gone so a future --hub install to a different
    # hub doesn't leak the old credential
    assert not hub_token_file().exists(), (
        "hub-token leaked past uninstall: " + result.stdout
    )


def test_uninstall_restores_previous_base_url(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """If there was a previous ANTHROPIC_BASE_URL, uninstall restores it."""
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    settings = fake_home / ".claude" / "settings.json"
    settings.parent.mkdir(parents=True)
    settings.write_text(json.dumps({
        "env": {"ANTHROPIC_BASE_URL": "https://original.example.com"},
    }))

    runner.invoke(
        app,
        ["install", "http://127.0.0.1:9999"],
    )
    runner.invoke(app, ["uninstall"])

    after = _read_settings(settings)
    assert after["env"]["ANTHROPIC_BASE_URL"] == "https://original.example.com"


def test_uninstall_dry_run(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    runner.invoke(
        app,
        ["install", "http://127.0.0.1:9999"],
    )

    result = runner.invoke(app, ["uninstall", "--dry-run"])
    assert result.exit_code == 0
    assert "Dry run" in result.stdout

    # settings.json still has our URL (dry-run didn't touch anything)
    settings = _read_settings(fake_home / ".claude" / "settings.json")
    assert settings["env"]["ANTHROPIC_BASE_URL"] == "http://127.0.0.1:9999"


def test_uninstall_restore_shell_rc_flag(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """With --restore-shell-rc, the original .zshrc comes back."""
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    rc = fake_home / ".zshrc"
    original = "export ANTHROPIC_BASE_URL=https://old.example.com\nalias l='ls'\n"
    rc.write_text(original)

    runner.invoke(
        app,
        ["install", "http://127.0.0.1:9999"],
    )
    # Sanity: our install cleaned the rc
    assert "ANTHROPIC_BASE_URL" not in rc.read_text()

    runner.invoke(app, ["uninstall"])

    # rc is back to original
    assert rc.read_text() == original


# ── status ──────────────────────────────────────────────────

def test_status_not_installed(fake_home: Path):
    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "no" in result.stdout.lower()


def test_status_installed(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    runner.invoke(
        app,
        ["install", "http://127.0.0.1:9999"],
    )

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "http://127.0.0.1:9999" in result.stdout
    # Clean install: no "Restores to" noise (nothing was there to back up)
    assert "Restores to" not in result.stdout


def test_status_shows_restores_to_when_overlaying(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """If install overlays an existing ANTHROPIC_BASE_URL, status should
    surface it as 'Restores to' so the user knows what uninstall will
    restore to (not just delete)."""
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    # Seed settings.json with an existing URL (as if chelper or another
    # tool had installed its own proxy before cc-guard)
    settings = fake_home / ".claude" / "settings.json"
    settings.parent.mkdir(parents=True)
    settings.write_text(json.dumps({
        "env": {"ANTHROPIC_BASE_URL": "https://api.z.ai/api/anthropic"},
    }))

    runner.invoke(
        app,
        ["install", "http://127.0.0.1:9999"],
    )

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "http://127.0.0.1:9999" in result.stdout
    assert "Restores to" in result.stdout
    assert "https://api.z.ai/api/anthropic" in result.stdout


def test_status_detects_drift(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """If settings.json was edited behind our back, status should flag it."""
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    runner.invoke(
        app,
        ["install", "http://127.0.0.1:9999"],
    )

    # Manually edit settings.json to simulate drift
    settings_path = fake_home / ".claude" / "settings.json"
    data = json.loads(settings_path.read_text())
    data["env"]["ANTHROPIC_BASE_URL"] = "http://manually.edited"
    settings_path.write_text(json.dumps(data))

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    # Drift is now flagged with a "drift" label row + "does not match"
    assert "drift" in result.stdout
    assert "does not match" in result.stdout
    assert "http://manually.edited" in result.stdout


# ── doctor ──────────────────────────────────────────────────

def test_doctor_clean(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    result = runner.invoke(app, ["doctor", "--no-probe"])
    assert result.exit_code == 0
    assert "all checks passed" in result.stdout


def test_doctor_warns_on_shell_rc_conflict(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")
    (fake_home / ".zshrc").write_text(
        "export ANTHROPIC_BASE_URL=https://example.com\n"
    )

    result = runner.invoke(app, ["doctor", "--no-probe"])
    assert result.exit_code == 1
    assert "warning" in result.stdout.lower()


def test_doctor_warns_on_unreachable_upstream(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """Install something, then probe — upstream fails, doctor warns."""
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")

    runner.invoke(
        app,
        ["install", "http://127.0.0.1:9999"],
    )

    def fake_get(*args, **kwargs):
        raise httpx.ConnectError("refused")

    monkeypatch.setattr(httpx, "get", fake_get)

    result = runner.invoke(app, ["doctor"])
    assert result.exit_code == 1
    assert "not reachable" in result.stdout
