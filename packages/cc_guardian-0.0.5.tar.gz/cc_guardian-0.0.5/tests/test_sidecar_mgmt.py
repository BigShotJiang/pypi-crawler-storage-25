"""Tests for the sidecar management module.

The subprocess spawn path is mocked — we don't need a real flowlens
install to exercise state tracking, pid-file lifecycle, and config
generation. Pure-logic bits (_parse_listen, build_sidecar_config) get
exercised without any mocking at all.
"""

from __future__ import annotations

import os
import signal
from pathlib import Path
from types import SimpleNamespace

import pytest
import yaml

from cc_guard import sidecar
from cc_guard.sidecar import (
    SidecarSettings,
    _parse_listen,
    _split_host_port,
    build_sidecar_config,
    find_flow_runner,
    read_hub_token,
    remove_hub_token,
    sidecar_status,
    start_managed_sidecar,
    stop_managed_sidecar,
    write_hub_token,
    write_sidecar_config,
)


# ── pure helpers ────────────────────────────────────────────

class TestParseListen:
    def test_strips_http_scheme(self):
        assert _parse_listen("http://127.0.0.1:9999") == "127.0.0.1:9999"

    def test_strips_https_scheme(self):
        assert _parse_listen("https://example.com:8443") == "example.com:8443"

    def test_strips_trailing_path(self):
        assert _parse_listen("http://127.0.0.1:9999/api") == "127.0.0.1:9999"

    def test_no_scheme_passthrough(self):
        assert _parse_listen("127.0.0.1:9999") == "127.0.0.1:9999"


class TestSplitHostPort:
    def test_full_host_port(self):
        assert _split_host_port("127.0.0.1:9999") == ("127.0.0.1", 9999)

    def test_port_only(self):
        assert _split_host_port(":9999") == ("127.0.0.1", 9999)

    def test_bare_port(self):
        assert _split_host_port("9999") == ("127.0.0.1", 9999)

    def test_custom_default_host(self):
        assert _split_host_port("9999", default_host="0.0.0.0") == ("0.0.0.0", 9999)


# ── config generation ──────────────────────────────────────

class TestBuildSidecarConfig:
    def test_proxy_mode_without_hub(self):
        s = SidecarSettings(
            listen="http://127.0.0.1:9999",
            upstream="https://api.anthropic.com",
        )
        cfg = build_sidecar_config(s)

        assert cfg["mode"] == "proxy"
        assert cfg["listen"] == "127.0.0.1:9999"
        assert cfg["providers"]["anthropic"]["url"] == "https://api.anthropic.com"
        assert cfg["providers"]["anthropic"]["parser"] == "claude"
        assert cfg["log"]["body_mode"] == "messages"
        # proxy mode does not emit hub / sidecar sections
        assert "hub" not in cfg
        assert "sidecar" not in cfg

    def test_sidecar_mode_with_hub(self):
        s = SidecarSettings(
            listen="http://127.0.0.1:9999",
            upstream="https://api.anthropic.com",
            hub_url="https://hub.example.com:7000",
            hub_token="secret-token",
        )
        cfg = build_sidecar_config(s)

        assert cfg["mode"] == "sidecar"
        assert cfg["hub"]["url"] == "https://hub.example.com:7000"
        # Token is NEVER dumped into yaml in plaintext; we use env ref
        assert cfg["hub"]["token"] == "${CC_GUARD_HUB_TOKEN}"
        assert cfg["hub"]["fail_open"] is True
        assert cfg["sidecar"]["upstream"] == "https://api.anthropic.com"
        # Hub is the audit sink in sidecar mode — avoid double-storing
        assert cfg["log"]["body_mode"] == "none"

    def test_listen_host_port_extracted(self):
        s = SidecarSettings(listen="http://0.0.0.0:28001")
        assert build_sidecar_config(s)["listen"] == "0.0.0.0:28001"


class TestWriteSidecarConfig:
    def test_writes_with_header_and_yaml(self, fake_home: Path, tmp_path: Path):
        cfg = {"mode": "proxy", "listen": "127.0.0.1:9999"}
        path = tmp_path / "sc.yaml"
        returned = write_sidecar_config(cfg, path)

        assert returned == path
        body = path.read_text()
        # Header comment appears
        assert "Managed by cc-guard" in body
        # Body is valid yaml and round-trips
        parsed = yaml.safe_load(body)
        assert parsed == cfg

    def test_default_path(self, fake_home: Path):
        cfg = {"mode": "proxy"}
        path = write_sidecar_config(cfg)
        assert path == fake_home / ".cc-guard" / "sidecar.yaml"
        assert path.exists()

    def test_permissions_0600(self, fake_home: Path, tmp_path: Path):
        cfg = {"mode": "proxy"}
        path = write_sidecar_config(cfg, tmp_path / "sc.yaml")
        mode = path.stat().st_mode & 0o777
        assert mode == 0o600

    def test_atomic_write_no_tmp_left(self, fake_home: Path, tmp_path: Path):
        cfg = {"mode": "proxy"}
        path = tmp_path / "sc.yaml"
        write_sidecar_config(cfg, path)
        # No .tmp.* leftover
        leftovers = list(tmp_path.glob("sc.yaml.tmp.*"))
        assert leftovers == []


# ── hub token lifecycle ────────────────────────────────────

class TestHubToken:
    def test_write_read_roundtrip(self, fake_home: Path):
        write_hub_token("secret-abc")
        assert read_hub_token() == "secret-abc"

    def test_read_missing_returns_none(self, fake_home: Path):
        assert read_hub_token() is None

    def test_permissions_0600(self, fake_home: Path):
        path = write_hub_token("secret")
        assert path.stat().st_mode & 0o777 == 0o600

    def test_strips_trailing_newline(self, fake_home: Path):
        write_hub_token("secret-xyz")
        # File stored with newline, read strips it
        stored = (fake_home / ".cc-guard" / "hub-token").read_text()
        assert stored.endswith("\n")
        assert read_hub_token() == "secret-xyz"

    def test_remove(self, fake_home: Path):
        write_hub_token("secret")
        remove_hub_token()
        assert read_hub_token() is None

    def test_remove_missing_is_noop(self, fake_home: Path):
        # Must not raise on clean system
        remove_hub_token()


# ── runner discovery ───────────────────────────────────────

class TestFindFlowRunner:
    def test_prefers_flow_on_path(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setattr(sidecar.shutil, "which", lambda name: "/usr/local/bin/flow")
        assert find_flow_runner() == ["/usr/local/bin/flow"]

    def test_falls_back_to_python_module(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setattr(sidecar.shutil, "which", lambda name: None)
        # flowlens may or may not be importable in test env — if it is,
        # the fallback should kick in. If not, result is None.
        try:
            import flowlens  # noqa: F401
            result = find_flow_runner()
            assert result is not None
            assert result[-2:] == ["-m", "flowlens"]
        except ImportError:
            assert find_flow_runner() is None

    def test_none_when_nothing_available(
        self, monkeypatch: pytest.MonkeyPatch,
    ):
        monkeypatch.setattr(sidecar.shutil, "which", lambda name: None)
        # Force the ImportError branch by poisoning the module cache
        import sys
        monkeypatch.setitem(sys.modules, "flowlens", None)
        # sys.modules[name] = None triggers ImportError on `import name`
        assert find_flow_runner() is None


# ── sidecar_status ─────────────────────────────────────────

class TestSidecarStatus:
    def test_not_managed_when_no_pid_file(self, fake_home: Path):
        assert sidecar_status() == {"state": "not_managed", "pid": None}

    def test_not_managed_when_pid_file_corrupt(self, fake_home: Path):
        pid_file = fake_home / ".cc-guard" / "sidecar.pid"
        pid_file.parent.mkdir(parents=True)
        pid_file.write_text("not-a-number")
        assert sidecar_status() == {"state": "not_managed", "pid": None}

    def test_dead_when_pid_not_alive(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        pid_file = fake_home / ".cc-guard" / "sidecar.pid"
        pid_file.parent.mkdir(parents=True)
        pid_file.write_text("999999")  # very unlikely to exist

        monkeypatch.setattr(sidecar, "_is_pid_alive", lambda pid: False)
        result = sidecar_status()
        assert result["state"] == "dead"
        assert result["pid"] == 999999

    def test_running_reports_pid(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        pid_file = fake_home / ".cc-guard" / "sidecar.pid"
        pid_file.parent.mkdir(parents=True)
        pid_file.write_text("12345")

        monkeypatch.setattr(sidecar, "_is_pid_alive", lambda pid: True)
        result = sidecar_status()
        assert result["state"] == "running"
        assert result["pid"] == 12345


# ── stop_managed_sidecar ────────────────────────────────────

class TestStopManagedSidecar:
    def test_not_running_when_no_pid_file(self, fake_home: Path):
        result = stop_managed_sidecar()
        assert result == {"state": "not_running", "pid": None}

    def test_not_running_when_pid_corrupt(self, fake_home: Path):
        pid_file = fake_home / ".cc-guard" / "sidecar.pid"
        pid_file.parent.mkdir(parents=True)
        pid_file.write_text("garbage")

        result = stop_managed_sidecar()
        assert result["state"] == "not_running"
        # Pid file was cleaned up
        assert not pid_file.exists()

    def test_not_running_when_pid_dead(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        pid_file = fake_home / ".cc-guard" / "sidecar.pid"
        pid_file.parent.mkdir(parents=True)
        pid_file.write_text("999999")

        monkeypatch.setattr(sidecar, "_is_pid_alive", lambda pid: False)
        result = stop_managed_sidecar()
        assert result["state"] == "not_running"
        assert result["pid"] == 999999
        assert not pid_file.exists()

    def test_stopped_cleanly_after_sigterm(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        pid_file = fake_home / ".cc-guard" / "sidecar.pid"
        pid_file.parent.mkdir(parents=True)
        pid_file.write_text("12345")

        # First check: alive. After SIGTERM: dead on next poll.
        alive_states = iter([True, False])
        monkeypatch.setattr(sidecar, "_is_pid_alive", lambda pid: next(alive_states))

        sent_signals: list[tuple[int, int]] = []
        def fake_kill(pid, sig):
            sent_signals.append((pid, sig))
        monkeypatch.setattr(os, "kill", fake_kill)

        result = stop_managed_sidecar(timeout=1.0)
        assert result["state"] == "stopped"
        assert result["pid"] == 12345
        assert sent_signals == [(12345, signal.SIGTERM)]
        assert not pid_file.exists()

    def test_killed_after_timeout(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        pid_file = fake_home / ".cc-guard" / "sidecar.pid"
        pid_file.parent.mkdir(parents=True)
        pid_file.write_text("12345")

        # Always alive — forces escalation to SIGKILL
        monkeypatch.setattr(sidecar, "_is_pid_alive", lambda pid: True)

        sent_signals: list[tuple[int, int]] = []
        def fake_kill(pid, sig):
            sent_signals.append((pid, sig))
        monkeypatch.setattr(os, "kill", fake_kill)

        result = stop_managed_sidecar(timeout=0.1)
        assert result["state"] == "killed"
        assert result["pid"] == 12345
        # SIGTERM first, then SIGKILL
        assert (12345, signal.SIGTERM) in sent_signals
        assert (12345, signal.SIGKILL) in sent_signals
        assert not pid_file.exists()


# ── start_managed_sidecar ──────────────────────────────────

class _FakePopen:
    """Stand-in for subprocess.Popen that never actually forks."""
    def __init__(self, pid: int = 54321, alive: bool = True):
        self.pid = pid
        self._alive = alive
        self.returncode = None

    def poll(self):
        return None if self._alive else self.returncode


class TestStartManagedSidecar:
    def test_refuses_if_already_running(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch, tmp_path: Path,
    ):
        # Prepare a "running" status from sidecar_status
        monkeypatch.setattr(
            sidecar, "sidecar_status",
            lambda: {"state": "running", "pid": 111},
        )
        with pytest.raises(RuntimeError, match="already running"):
            start_managed_sidecar(tmp_path / "sc.yaml", "http://127.0.0.1:9999")

    def test_raises_when_flowlens_missing(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch, tmp_path: Path,
    ):
        monkeypatch.setattr(
            sidecar, "sidecar_status",
            lambda: {"state": "not_managed", "pid": None},
        )
        monkeypatch.setattr(sidecar, "find_flow_runner", lambda: None)

        with pytest.raises(sidecar.FlowlensNotInstalled):
            start_managed_sidecar(tmp_path / "sc.yaml", "http://127.0.0.1:9999")

    def test_refuses_when_port_in_use(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch, tmp_path: Path,
    ):
        monkeypatch.setattr(
            sidecar, "sidecar_status",
            lambda: {"state": "not_managed", "pid": None},
        )
        monkeypatch.setattr(sidecar, "find_flow_runner", lambda: ["flow"])
        monkeypatch.setattr(sidecar, "_port_in_use", lambda h, p: True)

        with pytest.raises(RuntimeError, match="already in use"):
            start_managed_sidecar(tmp_path / "sc.yaml", "http://127.0.0.1:9999")

    def test_writes_pid_file_and_returns_handle(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch, tmp_path: Path,
    ):
        monkeypatch.setattr(
            sidecar, "sidecar_status",
            lambda: {"state": "not_managed", "pid": None},
        )
        monkeypatch.setattr(sidecar, "find_flow_runner", lambda: ["flow"])

        # First port check: free (before Popen). Second: bound after spawn.
        port_states = iter([False, True])
        monkeypatch.setattr(
            sidecar, "_port_in_use", lambda h, p: next(port_states),
        )

        fake_proc = _FakePopen(pid=54321)
        def fake_popen(*args, **kwargs):
            # Assert token is in env only if we set one
            env = kwargs.get("env", {})
            assert env.get("CC_GUARD_HUB_TOKEN") == "the-token"
            return fake_proc
        monkeypatch.setattr(sidecar.subprocess, "Popen", fake_popen)

        cfg_path = tmp_path / "sc.yaml"
        cfg_path.write_text("mode: proxy\n")  # placeholder

        handle = start_managed_sidecar(
            cfg_path, "http://127.0.0.1:9999", hub_token="the-token",
        )

        assert handle.pid == 54321
        assert handle.config_path == str(cfg_path)
        assert handle.listen == "127.0.0.1:9999"
        assert handle.started_at  # iso timestamp, non-empty

        # pid file written
        pid_file = fake_home / ".cc-guard" / "sidecar.pid"
        assert pid_file.read_text() == "54321"

    def test_detects_early_exit(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch, tmp_path: Path,
    ):
        monkeypatch.setattr(
            sidecar, "sidecar_status",
            lambda: {"state": "not_managed", "pid": None},
        )
        monkeypatch.setattr(sidecar, "find_flow_runner", lambda: ["flow"])
        monkeypatch.setattr(sidecar, "_port_in_use", lambda h, p: False)

        class _DeadProc:
            pid = 99
            returncode = 42
            def poll(self):
                return 42

        monkeypatch.setattr(sidecar.subprocess, "Popen", lambda *a, **k: _DeadProc())

        cfg_path = tmp_path / "sc.yaml"
        cfg_path.write_text("mode: proxy\n")

        with pytest.raises(RuntimeError, match="exited with code 42"):
            start_managed_sidecar(cfg_path, "http://127.0.0.1:9999")

    def test_posix_passes_start_new_session(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch, tmp_path: Path,
    ):
        """POSIX path: detach via start_new_session=True, no creationflags."""
        monkeypatch.setattr(sidecar.os, "name", "posix")
        monkeypatch.setattr(
            sidecar, "sidecar_status",
            lambda: {"state": "not_managed", "pid": None},
        )
        monkeypatch.setattr(sidecar, "find_flow_runner", lambda: ["flow"])
        port_states = iter([False, True])
        monkeypatch.setattr(sidecar, "_port_in_use", lambda h, p: next(port_states))

        captured: dict = {}
        def fake_popen(*args, **kwargs):
            captured.update(kwargs)
            return _FakePopen(pid=1)
        monkeypatch.setattr(sidecar.subprocess, "Popen", fake_popen)

        cfg_path = tmp_path / "sc.yaml"
        cfg_path.write_text("mode: proxy\n")
        start_managed_sidecar(cfg_path, "http://127.0.0.1:9999")

        assert captured.get("start_new_session") is True
        assert "creationflags" not in captured

    def test_windows_passes_creationflags(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch, tmp_path: Path,
    ):
        """Windows path: detach via creationflags (DETACHED_PROCESS |
        CREATE_NEW_PROCESS_GROUP), never set start_new_session
        (would raise ValueError on Windows Python)."""
        monkeypatch.setattr(sidecar.os, "name", "nt")
        monkeypatch.setattr(
            sidecar, "sidecar_status",
            lambda: {"state": "not_managed", "pid": None},
        )
        monkeypatch.setattr(sidecar, "find_flow_runner", lambda: ["flow"])
        port_states = iter([False, True])
        monkeypatch.setattr(sidecar, "_port_in_use", lambda h, p: next(port_states))

        captured: dict = {}
        def fake_popen(*args, **kwargs):
            captured.update(kwargs)
            return _FakePopen(pid=1)
        monkeypatch.setattr(sidecar.subprocess, "Popen", fake_popen)

        cfg_path = tmp_path / "sc.yaml"
        cfg_path.write_text("mode: proxy\n")
        start_managed_sidecar(cfg_path, "http://127.0.0.1:9999")

        assert "start_new_session" not in captured
        cf = captured.get("creationflags")
        assert cf is not None
        # Both flags must be present (bitwise OR). Use literal Win32 values
        # since `subprocess.DETACHED_PROCESS` doesn't exist on POSIX hosts.
        assert cf & 0x00000008  # DETACHED_PROCESS
        assert cf & 0x00000200  # CREATE_NEW_PROCESS_GROUP


# ── Windows-mode behavior of pid liveness + stop ────────────

class TestWindowsPidLiveness:
    """Verify the Windows-specific code paths via os.name monkeypatching.

    These run on a POSIX host but exercise the `if os.name == "nt"` branch
    of _is_pid_alive and stop_managed_sidecar so the Windows code path
    can't silently rot when nobody's testing on a Windows runner.
    """

    def test_is_pid_alive_uses_psutil_on_windows(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        monkeypatch.setattr(sidecar.os, "name", "nt")

        # Inject a fake psutil module so the import inside _is_pid_alive
        # succeeds and we can observe what gets called.
        import sys, types
        fake_psutil = types.ModuleType("psutil")
        fake_psutil.pid_exists = lambda pid: pid == 12345  # type: ignore[attr-defined]
        monkeypatch.setitem(sys.modules, "psutil", fake_psutil)

        assert sidecar._is_pid_alive(12345) is True
        assert sidecar._is_pid_alive(99999) is False

    def test_is_pid_alive_falls_back_when_psutil_missing(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        """Windows but psutil not installed: conservatively assume alive
        so uninstall still attempts termination (instead of skipping it)."""
        monkeypatch.setattr(sidecar.os, "name", "nt")

        # Make `import psutil` raise ImportError by setting the cached
        # module entry to None (Python's documented sentinel for "fail import")
        import sys
        monkeypatch.setitem(sys.modules, "psutil", None)

        assert sidecar._is_pid_alive(12345) is True  # conservative

    def test_stop_managed_sidecar_windows_escalation_uses_sigterm_not_sigkill(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        """On Windows, escalation can't use SIGKILL (doesn't exist).
        It should retry SIGTERM (which is already TerminateProcess on
        Windows) instead of crashing with AttributeError."""
        monkeypatch.setattr(sidecar.os, "name", "nt")

        pid_file = fake_home / ".cc-guard" / "sidecar.pid"
        pid_file.parent.mkdir(parents=True)
        pid_file.write_text("12345")

        # Always alive — forces escalation path
        monkeypatch.setattr(sidecar, "_is_pid_alive", lambda pid: True)

        sent: list[tuple[int, int]] = []
        def fake_kill(pid, sig):
            sent.append((pid, sig))
        monkeypatch.setattr(os, "kill", fake_kill)

        result = stop_managed_sidecar(timeout=0.05)
        assert result["state"] == "killed"
        assert result["pid"] == 12345
        # Two SIGTERMs (initial + escalation), no SIGKILL
        assert sent.count((12345, signal.SIGTERM)) == 2
        assert all(sig == signal.SIGTERM for _, sig in sent)
        assert not pid_file.exists()
