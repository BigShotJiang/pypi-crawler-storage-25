"""Tests for state.py — the yaml-backed install record store."""

from __future__ import annotations

from pathlib import Path

import yaml

from cc_guard.state import (
    InstallRecord,
    SCHEMA_VERSION,
    ShellRcChange,
    StateStore,
    state_path,
)


def _make_record(upstream: str = "http://127.0.0.1:9999") -> InstallRecord:
    return InstallRecord(
        upstream=upstream,
        installed_at="2026-04-09T14:23:45+08:00",
        settings_backup="/tmp/snapshot.1712662320",
        backup_base_url="https://api.z.ai/api/anthropic",
        api_timeout_ms=3000000,
        shell_rc_changes=[
            ShellRcChange(
                path="~/.zshrc",
                backup="/tmp/zshrc.1712662320",
                removed_line_count=1,
            ),
        ],
    )


def test_load_empty_state(fake_home: Path):
    """Missing state.yaml returns an empty dict, never raises."""
    store = StateStore()
    assert store.load() == {}


def test_is_installed_false_when_no_state(fake_home: Path):
    store = StateStore()
    assert store.is_installed("claude-code") is False


def test_record_and_retrieve(fake_home: Path):
    store = StateStore()
    record = _make_record()
    store.record_install("claude-code", record)

    assert store.is_installed("claude-code") is True
    loaded = store.get("claude-code")
    assert loaded == record


def test_roundtrip_preserves_nested_shell_rc_changes(fake_home: Path):
    store = StateStore()
    record = _make_record()
    store.record_install("claude-code", record)

    loaded = store.load()["claude-code"]
    assert len(loaded.shell_rc_changes) == 1
    assert loaded.shell_rc_changes[0].path == "~/.zshrc"
    assert loaded.shell_rc_changes[0].removed_line_count == 1


def test_save_is_human_readable_yaml(fake_home: Path):
    """A user peeking at state.yaml should see clean, sorted YAML with a
    schema version, not some binary blob."""
    store = StateStore()
    store.record_install("claude-code", _make_record())

    raw = yaml.safe_load(store.path.read_text())
    assert raw["version"] == SCHEMA_VERSION
    assert "installs" in raw
    assert "claude-code" in raw["installs"]


def test_remove_install(fake_home: Path):
    store = StateStore()
    store.record_install("claude-code", _make_record())
    assert store.is_installed("claude-code")

    removed = store.remove_install("claude-code")

    assert removed is not None
    assert removed.upstream == "http://127.0.0.1:9999"
    assert store.is_installed("claude-code") is False
    assert store.load() == {}


def test_remove_nonexistent_is_noop(fake_home: Path):
    store = StateStore()
    assert store.remove_install("claude-code") is None


def test_multiple_tools_coexist(fake_home: Path):
    """State store should be tool-keyed so future tools don't collide."""
    store = StateStore()
    store.record_install("claude-code", _make_record("http://127.0.0.1:9999"))
    store.record_install("some-future-tool", _make_record("http://127.0.0.1:8888"))

    records = store.load()
    assert set(records.keys()) == {"claude-code", "some-future-tool"}
    assert records["claude-code"].upstream == "http://127.0.0.1:9999"
    assert records["some-future-tool"].upstream == "http://127.0.0.1:8888"


def test_backward_compatible_missing_optional_fields(fake_home: Path):
    """An older state.yaml without `api_timeout_ms` or `shell_rc_changes`
    should parse cleanly with sensible defaults."""
    store = StateStore()
    store.path.parent.mkdir(parents=True, exist_ok=True)
    store.path.write_text(yaml.safe_dump({
        "version": 1,
        "installs": {
            "claude-code": {
                "upstream": "http://127.0.0.1:9999",
                "installed_at": "2026-04-09T14:23:45+08:00",
                "settings_backup": "/tmp/snapshot.123",
            },
        },
    }))

    record = store.get("claude-code")
    assert record is not None
    assert record.upstream == "http://127.0.0.1:9999"
    assert record.backup_base_url is None
    assert record.api_timeout_ms is None
    assert record.shell_rc_changes == []


def test_forward_compatible_unknown_fields(fake_home: Path):
    """Unknown fields in a future state.yaml should be ignored, not crash."""
    store = StateStore()
    store.path.parent.mkdir(parents=True, exist_ok=True)
    store.path.write_text(yaml.safe_dump({
        "version": 99,
        "installs": {
            "claude-code": {
                "upstream": "http://127.0.0.1:9999",
                "installed_at": "2026-04-09T14:23:45+08:00",
                "settings_backup": "/tmp/snap",
                "future_field": {"nested": True},
            },
        },
        "unknown_top_level": "ignored",
    }))

    record = store.get("claude-code")
    assert record is not None
    assert record.upstream == "http://127.0.0.1:9999"


def test_state_path_uses_fake_home(fake_home: Path):
    assert state_path() == fake_home / ".cc-guard" / "state.yaml"
