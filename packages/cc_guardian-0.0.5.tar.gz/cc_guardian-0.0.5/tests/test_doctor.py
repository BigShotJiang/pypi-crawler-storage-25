"""Tests for doctor.py — each check in isolation + run_all_checks integration."""

from __future__ import annotations

from pathlib import Path

import httpx
import pytest

from cc_guard.claude_code import ClaudeCodeManager
from cc_guard.doctor import (
    check_base_url,
    check_env_var_conflict,
    check_settings_file,
    check_shell_rc_conflict,
    check_state_file,
    check_upstream_reachable,
    run_all_checks,
    summarize,
)
from cc_guard.state import StateStore


# ── check_settings_file ─────────────────────────────────────

def test_check_settings_missing(fake_home: Path):
    mgr = ClaudeCodeManager()
    check, data = check_settings_file(mgr)
    assert check.passed
    assert check.severity == "info"
    assert data is None


def test_check_settings_valid(fake_home: Path):
    mgr = ClaudeCodeManager()
    mgr.path.parent.mkdir(parents=True)
    mgr.path.write_text('{"env": {"ANTHROPIC_BASE_URL": "http://127.0.0.1:9999"}}')
    check, data = check_settings_file(mgr)
    assert check.passed
    assert data is not None
    assert data["env"]["ANTHROPIC_BASE_URL"] == "http://127.0.0.1:9999"


def test_check_settings_invalid_json(fake_home: Path):
    mgr = ClaudeCodeManager()
    mgr.path.parent.mkdir(parents=True)
    mgr.path.write_text("not valid json {")
    check, data = check_settings_file(mgr)
    assert not check.passed
    assert check.severity == "error"
    assert data is None
    assert check.hint is not None


# ── check_base_url ──────────────────────────────────────────

def test_check_base_url_not_set(fake_home: Path):
    check, url = check_base_url({"env": {}})
    assert check.passed
    assert url is None
    assert "not set" in check.message


def test_check_base_url_set(fake_home: Path):
    check, url = check_base_url(
        {"env": {"ANTHROPIC_BASE_URL": "http://127.0.0.1:9999"}}
    )
    assert check.passed
    assert url == "http://127.0.0.1:9999"


def test_check_base_url_data_none(fake_home: Path):
    check, url = check_base_url(None)
    assert check.passed
    assert url is None


# ── check_env_var_conflict ──────────────────────────────────

def test_check_env_var_neither_set(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
    check = check_env_var_conflict(None)
    assert check.passed
    assert check.severity == "info"


def test_check_env_var_only_settings_set(monkeypatch: pytest.MonkeyPatch):
    """Settings.json has a url, shell env is clean — this is the happy state."""
    monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
    check = check_env_var_conflict("http://127.0.0.1:9999")
    assert check.passed
    assert check.severity == "info"


def test_check_env_var_only_env_set(monkeypatch: pytest.MonkeyPatch):
    """Shell env has a url but settings does not — the env will take effect."""
    monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://env.example.com")
    check = check_env_var_conflict(None)
    assert not check.passed
    assert check.severity == "warning"
    assert "env.example.com" in check.message
    assert check.hint is not None
    assert "unset" in check.hint.lower()


def test_check_env_var_agree(monkeypatch: pytest.MonkeyPatch):
    """Shell env and settings agree — info, not warning."""
    monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://127.0.0.1:9999")
    check = check_env_var_conflict("http://127.0.0.1:9999")
    assert check.passed
    assert check.severity == "info"
    assert "agrees" in check.message


def test_check_env_var_disagree(monkeypatch: pytest.MonkeyPatch):
    """Shell env and settings disagree — the shell env wins, warning."""
    monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://env.example.com")
    check = check_env_var_conflict("http://127.0.0.1:9999")
    assert not check.passed
    assert check.severity == "warning"
    assert "env.example.com" in check.message
    assert "127.0.0.1:9999" in check.message
    assert "override" in check.message
    assert check.hint is not None


# ── check_shell_rc_conflict ─────────────────────────────────

def test_check_shell_rc_no_conflict(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")
    rc = fake_home / ".zshrc"
    rc.write_text("export PATH=$HOME/bin:$PATH\n")

    check = check_shell_rc_conflict()
    assert check.passed
    assert check.severity == "info"


def test_check_shell_rc_with_conflict(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")
    rc = fake_home / ".zshrc"
    rc.write_text("export ANTHROPIC_BASE_URL=https://example.com\n")

    check = check_shell_rc_conflict()
    assert not check.passed
    assert check.severity == "warning"
    assert "OVERRIDE" in check.message
    assert check.hint is not None


def test_check_shell_rc_missing_file(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")
    # No .zshrc file created
    check = check_shell_rc_conflict()
    assert check.passed
    assert "does not exist" in check.message


# ── check_upstream_reachable ────────────────────────────────

def test_check_upstream_none(fake_home: Path):
    check = check_upstream_reachable(None)
    assert check.passed
    assert "no upstream" in check.message


def test_check_upstream_unreachable(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """Mock httpx.get to raise a connect error."""

    def fake_get(*args, **kwargs):
        raise httpx.ConnectError("connection refused")

    monkeypatch.setattr(httpx, "get", fake_get)

    check = check_upstream_reachable("http://127.0.0.1:9999")
    assert not check.passed
    assert check.severity == "warning"
    assert "not reachable" in check.message
    assert check.hint is not None


def test_check_upstream_reachable_ok(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """Mock httpx.get to return a response."""

    class FakeResponse:
        status_code = 404

    def fake_get(*args, **kwargs):
        return FakeResponse()

    monkeypatch.setattr(httpx, "get", fake_get)

    check = check_upstream_reachable("http://127.0.0.1:9999")
    assert check.passed
    assert "404" in check.message


# ── check_state_file ────────────────────────────────────────

def test_check_state_missing(fake_home: Path):
    store = StateStore()
    check = check_state_file(store)
    assert check.passed
    assert "not exist" in check.message


def test_check_state_valid(fake_home: Path):
    import yaml
    store = StateStore()
    store.path.parent.mkdir(parents=True)
    store.path.write_text(yaml.safe_dump({"version": 1, "installs": {}}))
    check = check_state_file(store)
    assert check.passed


def test_check_state_corrupted(fake_home: Path):
    store = StateStore()
    store.path.parent.mkdir(parents=True)
    # yaml that parses but has unexpected structure -> dataclass error
    store.path.write_text("installs:\n  claude-code:\n    upstream: 123\n    bad_key_everywhere: yes\n")
    check = check_state_file(store)
    # Either parses with defaults or fails; if it parses, it's still valid
    # (we're tolerant of unknown fields). Let's test with actually-broken yaml:
    store.path.write_text("{{{ invalid yaml")
    check = check_state_file(store)
    assert not check.passed
    assert check.severity == "error"


# ── run_all_checks integration ──────────────────────────────

def test_run_all_checks_clean_state(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """Fresh machine, nothing installed — all checks should be info-level."""
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")
    monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)

    checks = run_all_checks(probe_upstream=False)
    # All checks should be info-level (no warnings, no errors)
    warnings, errors = summarize(checks)
    assert warnings == 0
    assert errors == 0
    # Expected 6 checks
    names = [c.name for c in checks]
    assert names == [
        "settings.json", "base_url", "env_override", "shell_rc", "upstream", "state",
    ]


def test_run_all_checks_with_shell_rc_conflict(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")
    monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
    (fake_home / ".zshrc").write_text(
        "export ANTHROPIC_BASE_URL=https://example.com\n"
    )

    checks = run_all_checks(probe_upstream=False)
    warnings, errors = summarize(checks)
    assert warnings == 1
    assert errors == 0
    # The warning should be the shell_rc one
    conflict = next(c for c in checks if c.name == "shell_rc")
    assert not conflict.passed


def test_run_all_checks_with_env_var_conflict(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """Shell env has ANTHROPIC_BASE_URL set while settings.json does not."""
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")
    monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://env.example.com")

    checks = run_all_checks(probe_upstream=False)
    warnings, errors = summarize(checks)
    assert warnings == 1
    assert errors == 0
    env_check = next(c for c in checks if c.name == "env_override")
    assert not env_check.passed
    assert "env.example.com" in env_check.message


def test_run_all_checks_with_installed_and_unreachable(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")
    monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)

    # Simulate installed state
    mgr = ClaudeCodeManager()
    mgr.path.parent.mkdir(parents=True)
    mgr.path.write_text(
        '{"env": {"ANTHROPIC_BASE_URL": "http://127.0.0.1:9999"}}'
    )

    def fake_get(*args, **kwargs):
        raise httpx.ConnectError("refused")

    monkeypatch.setattr(httpx, "get", fake_get)

    checks = run_all_checks(probe_upstream=True, probe_timeout=0.5)
    warnings, errors = summarize(checks)
    assert warnings == 1   # only the upstream warning
    assert errors == 0

    upstream_check = next(c for c in checks if c.name == "upstream")
    assert not upstream_check.passed
    assert "not reachable" in upstream_check.message
