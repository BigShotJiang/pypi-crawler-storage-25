"""Tests for ClaudeCodeManager.install / uninstall.

Covers:
  - fresh install (no pre-existing settings.json)
  - install preserves unrelated top-level and env fields
  - install backs up a pre-existing ANTHROPIC_BASE_URL
  - install never touches ANTHROPIC_AUTH_TOKEN / ANTHROPIC_API_KEY
  - install is idempotent (repeat == no change, no new backup)
  - uninstall restores backed-up value
  - uninstall deletes field when no backup exists
  - uninstall removes API_TIMEOUT_MS only when we injected it
  - uninstall collapses empty env dict
  - atomic write: failure mid-write leaves original file intact
  - full install -> uninstall cycle is byte-identical
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from cc_guard.claude_code import (
    BACKUP_KEY,
    BASE_URL_KEY,
    API_TIMEOUT_KEY,
    ClaudeCodeManager,
    settings_path,
)


# ── helpers ──────────────────────────────────────────────────

def _write_settings(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n")


def _read_settings(path: Path) -> dict:
    return json.loads(path.read_text())


# ── install: empty / greenfield ──────────────────────────────

def test_install_from_empty(fake_home: Path):
    """settings.json doesn't exist -> install creates it with just our key."""
    mgr = ClaudeCodeManager()
    assert not mgr.path.exists()

    result = mgr.install("http://127.0.0.1:9999")

    assert mgr.path.exists()
    data = _read_settings(mgr.path)
    assert data == {"env": {BASE_URL_KEY: "http://127.0.0.1:9999"}}
    assert result.upstream == "http://127.0.0.1:9999"
    assert result.previous_base_url is None
    assert result.api_timeout_injected is False
    assert result.settings_backup_path is None  # nothing to back up
    assert result.already_installed is False


def test_install_preserves_other_top_level_fields(fake_home: Path):
    """Install must not disturb unrelated fields like enabledPlugins."""
    mgr = ClaudeCodeManager()
    _write_settings(mgr.path, {
        "env": {"CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1"},
        "enabledPlugins": {"some-plugin": True},
        "language": "中文",
        "effortLevel": "high",
    })

    mgr.install("http://127.0.0.1:9999")

    data = _read_settings(mgr.path)
    assert data["enabledPlugins"] == {"some-plugin": True}
    assert data["language"] == "中文"
    assert data["effortLevel"] == "high"
    assert data["env"]["CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS"] == "1"
    assert data["env"][BASE_URL_KEY] == "http://127.0.0.1:9999"


def test_install_backs_up_existing_base_url(fake_home: Path):
    """An existing ANTHROPIC_BASE_URL must be stashed in BACKUP_KEY."""
    mgr = ClaudeCodeManager()
    _write_settings(mgr.path, {
        "env": {BASE_URL_KEY: "https://api.z.ai/api/anthropic"},
    })

    result = mgr.install("http://127.0.0.1:9999")

    data = _read_settings(mgr.path)
    assert data["env"][BASE_URL_KEY] == "http://127.0.0.1:9999"
    assert data["env"][BACKUP_KEY] == "https://api.z.ai/api/anthropic"
    assert result.previous_base_url == "https://api.z.ai/api/anthropic"
    assert result.settings_backup_path is not None
    assert result.settings_backup_path.exists()


def test_install_never_touches_auth_token(fake_home: Path):
    """ANTHROPIC_AUTH_TOKEN / ANTHROPIC_API_KEY must pass through untouched.

    This is the core differentiator from chelper — we're an installer, not
    a credential manager.
    """
    mgr = ClaudeCodeManager()
    _write_settings(mgr.path, {
        "env": {
            "ANTHROPIC_AUTH_TOKEN": "sk-ant-user-own-token",
            "ANTHROPIC_API_KEY": "sk-ant-user-own-key",
        },
    })

    mgr.install("http://127.0.0.1:9999")

    data = _read_settings(mgr.path)
    assert data["env"]["ANTHROPIC_AUTH_TOKEN"] == "sk-ant-user-own-token"
    assert data["env"]["ANTHROPIC_API_KEY"] == "sk-ant-user-own-key"
    assert data["env"][BASE_URL_KEY] == "http://127.0.0.1:9999"


def test_install_with_api_timeout(fake_home: Path):
    """When --api-timeout is given, API_TIMEOUT_MS is written as string."""
    mgr = ClaudeCodeManager()
    result = mgr.install("http://127.0.0.1:9999", api_timeout_ms=3000000)
    data = _read_settings(mgr.path)
    assert data["env"][API_TIMEOUT_KEY] == "3000000"
    assert result.api_timeout_injected is True


# ── install: idempotency ─────────────────────────────────────

def test_install_idempotent_same_url(fake_home: Path):
    """Calling install twice with the same URL short-circuits — no new backup."""
    from cc_guard.backup import backup_dir

    mgr = ClaudeCodeManager()
    # Seed settings.json with some pre-existing state so the first install
    # *does* produce a backup. Otherwise "no new backup" is a trivial
    # assertion since there's nothing to back up from an empty start.
    _write_settings(mgr.path, {
        "env": {"CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1"},
    })

    result1 = mgr.install("http://127.0.0.1:9999")
    assert result1.already_installed is False
    assert result1.settings_backup_path is not None

    backups_before = sorted(p.name for p in backup_dir().iterdir())
    assert len(backups_before) == 1

    # Second install, same URL -> should short-circuit
    result2 = mgr.install("http://127.0.0.1:9999")
    assert result2.already_installed is True
    assert result2.settings_backup_path is None

    backups_after = sorted(p.name for p in backup_dir().iterdir())
    assert backups_after == backups_before  # no new backup

    data = _read_settings(mgr.path)
    assert data["env"][BASE_URL_KEY] == "http://127.0.0.1:9999"
    assert data["env"]["CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS"] == "1"


def test_install_does_not_overwrite_earlier_backup(fake_home: Path):
    """If user installs A, then installs B without uninstalling, we keep
    the _earliest_ value in the backup key. Otherwise uninstall-of-B
    would leave them in A-land instead of pristine."""
    mgr = ClaudeCodeManager()
    _write_settings(mgr.path, {
        "env": {BASE_URL_KEY: "https://original.example.com"},
    })

    mgr.install("http://127.0.0.1:9999")   # A
    mgr.install("http://127.0.0.1:8888")   # B

    data = _read_settings(mgr.path)
    assert data["env"][BASE_URL_KEY] == "http://127.0.0.1:8888"
    assert data["env"][BACKUP_KEY] == "https://original.example.com"


# ── uninstall ────────────────────────────────────────────────

def test_uninstall_restores_original_base_url(fake_home: Path):
    """After install + uninstall, settings.json is back to original state."""
    mgr = ClaudeCodeManager()
    _write_settings(mgr.path, {
        "env": {BASE_URL_KEY: "https://api.z.ai/api/anthropic"},
    })
    mgr.install("http://127.0.0.1:9999")
    mgr.uninstall()

    data = _read_settings(mgr.path)
    assert data == {"env": {BASE_URL_KEY: "https://api.z.ai/api/anthropic"}}
    assert BACKUP_KEY not in data["env"]


def test_uninstall_deletes_base_url_when_no_backup(fake_home: Path):
    """If install was on a clean settings.json (no prior base URL),
    uninstall should remove the key entirely, not leave it as None."""
    mgr = ClaudeCodeManager()
    mgr.install("http://127.0.0.1:9999")
    mgr.uninstall()

    # env was empty before install — after uninstall the env dict should be gone
    data = _read_settings(mgr.path)
    assert data == {}


def test_uninstall_preserves_other_env_fields(fake_home: Path):
    """Uninstall removes only our keys, leaves other env fields alone."""
    mgr = ClaudeCodeManager()
    _write_settings(mgr.path, {
        "env": {
            "ANTHROPIC_AUTH_TOKEN": "sk-ant-user-own",
            "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1",
        },
    })
    mgr.install("http://127.0.0.1:9999")
    mgr.uninstall()

    data = _read_settings(mgr.path)
    assert data["env"]["ANTHROPIC_AUTH_TOKEN"] == "sk-ant-user-own"
    assert data["env"]["CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS"] == "1"
    assert BASE_URL_KEY not in data["env"]
    assert BACKUP_KEY not in data["env"]


def test_uninstall_removes_api_timeout_only_if_flag_set(fake_home: Path):
    """had_api_timeout=False leaves an existing API_TIMEOUT_MS alone
    (the user may have set it themselves). True removes it."""
    mgr = ClaudeCodeManager()
    _write_settings(mgr.path, {
        "env": {"API_TIMEOUT_MS": "10000"},   # user-set
    })
    mgr.install("http://127.0.0.1:9999")      # we did NOT inject API_TIMEOUT_MS
    mgr.uninstall(had_api_timeout=False)

    data = _read_settings(mgr.path)
    # User's own API_TIMEOUT_MS survives
    assert data["env"]["API_TIMEOUT_MS"] == "10000"


def test_uninstall_removes_api_timeout_when_we_injected_it(fake_home: Path):
    mgr = ClaudeCodeManager()
    mgr.install("http://127.0.0.1:9999", api_timeout_ms=3000000)
    mgr.uninstall(had_api_timeout=True)

    data = _read_settings(mgr.path)
    assert data == {}   # everything we injected is gone


# ── atomic write / failure handling ──────────────────────────

def test_atomic_write_failure_leaves_original_intact(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
):
    """If os.replace throws mid-install, settings.json must still be valid."""
    mgr = ClaudeCodeManager()
    _write_settings(mgr.path, {"env": {"KEEP": "me"}, "other": "field"})
    original_bytes = mgr.path.read_bytes()

    import cc_guard.backup as backup_mod
    original_replace = backup_mod.os.replace

    def failing_replace(src, dst):
        raise OSError("simulated disk full")

    monkeypatch.setattr(backup_mod.os, "replace", failing_replace)

    with pytest.raises(OSError):
        mgr.install("http://127.0.0.1:9999")

    # Original file intact
    assert mgr.path.read_bytes() == original_bytes
    # Temp file cleaned up
    tmps = list(mgr.path.parent.glob("settings.json.tmp.*"))
    assert tmps == []


# ── full cycle ───────────────────────────────────────────────

def test_full_cycle_is_byte_identical(fake_home: Path):
    """install -> uninstall -> settings.json should be byte-identical
    to the starting state (modulo JSON formatting stability)."""
    mgr = ClaudeCodeManager()
    original = {
        "env": {
            "ANTHROPIC_AUTH_TOKEN": "sk-ant-preserve",
            "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1",
        },
        "enabledPlugins": {"code-review": True},
        "language": "中文",
    }
    _write_settings(mgr.path, original)
    original_data = _read_settings(mgr.path)

    mgr.install("http://127.0.0.1:9999", api_timeout_ms=3000000)
    mgr.uninstall(had_api_timeout=True)

    assert _read_settings(mgr.path) == original_data


def test_settings_path_resolves_home(fake_home: Path):
    """settings_path() should use the (fake) home, not a cached value."""
    path = settings_path()
    assert path == fake_home / ".claude" / "settings.json"
