"""Tests for the interactive wizard.

We don't drive real questionary prompts — that would need a TTY. Instead
each questionary call is wrapped in a small helper function in wizard.py
(`_prompt_main_action`, `_prompt_upstream`, etc.); tests monkeypatch
those helpers to return canned answers.
"""

from __future__ import annotations

from pathlib import Path

import pytest

import typer

from cc_guard import wizard
from cc_guard.state import InstallRecord, ShellRcChange, StateStore


# ── helpers to script a wizard run ──────────────────────────

class _Scripted:
    """Collect canned answers and record which helpers were called."""
    def __init__(self):
        self.calls: list[tuple[str, tuple, dict]] = []

    def patch(self, monkeypatch: pytest.MonkeyPatch, **answers):
        """Patch wizard._prompt_* functions to return values from `answers`.

        `answers` is a dict like `{"main_action": "install", "proceed": True}`
        — keys match the _prompt_* function suffixes.
        """
        mapping = {
            "main_action": "_prompt_main_action",
            "proceed": "_prompt_proceed",
            "proceed_no_hub": "_prompt_proceed_no_hub",
            "restore_shell_rc": "_prompt_restore_shell_rc",
            "language": "_prompt_language",
        }
        for key, value in answers.items():
            fn_name = mapping[key]

            def make_stub(val, name=key):
                def _stub(*args, **kwargs):
                    self.calls.append((name, args, kwargs))
                    return val
                return _stub

            monkeypatch.setattr(wizard, fn_name, make_stub(value))


# ── main menu dispatch ──────────────────────────────────────

def test_main_menu_exit(fake_home: Path, monkeypatch: pytest.MonkeyPatch):
    """Selecting 'Exit' should return cleanly, nothing called."""
    scripted = _Scripted()
    scripted.patch(monkeypatch, main_action="exit")

    install_called = False
    uninstall_called = False

    def install_fn(url, timeout, sc, cfg):
        nonlocal install_called
        install_called = True

    def uninstall_fn(restore):
        nonlocal uninstall_called
        uninstall_called = True

    with pytest.raises(typer.Exit) as exc_info:
        wizard.run_main_menu(
            install_fn=install_fn,
            uninstall_fn=uninstall_fn,
            status_fn=lambda: None,
            doctor_fn=lambda: None,
        )
    assert exc_info.value.exit_code == 0
    assert not install_called
    assert not uninstall_called


def test_main_menu_ctrl_c(fake_home: Path, monkeypatch: pytest.MonkeyPatch):
    """Ctrl-C at main menu returns None from _prompt_main_action — also exit 0."""
    scripted = _Scripted()
    scripted.patch(monkeypatch, main_action=None)

    with pytest.raises(typer.Exit) as exc_info:
        wizard.run_main_menu(
            install_fn=lambda u, t, sc, cfg: None,
            uninstall_fn=lambda r: None,
            status_fn=lambda: None,
            doctor_fn=lambda: None,
        )
    assert exc_info.value.exit_code == 0


def test_main_menu_status(fake_home: Path, monkeypatch: pytest.MonkeyPatch):
    """Status: action runs once, then menu loops back, user picks Exit."""
    actions = iter(["status", "exit"])
    monkeypatch.setattr(wizard, "_prompt_main_action", lambda: next(actions))

    status_calls = 0
    def status_fn():
        nonlocal status_calls
        status_calls += 1

    with pytest.raises(typer.Exit) as exc_info:
        wizard.run_main_menu(
            install_fn=lambda u, t, sc, cfg: None,
            uninstall_fn=lambda r: None,
            status_fn=status_fn,
            doctor_fn=lambda: None,
        )
    assert exc_info.value.exit_code == 0
    assert status_calls == 1
    # Verify the iterator was fully consumed (loop happened)
    assert next(actions, "DONE") == "DONE"


def test_main_menu_doctor(fake_home: Path, monkeypatch: pytest.MonkeyPatch):
    """Doctor: same loop-back-then-exit pattern."""
    actions = iter(["doctor", "exit"])
    monkeypatch.setattr(wizard, "_prompt_main_action", lambda: next(actions))

    doctor_calls = 0
    def doctor_fn():
        nonlocal doctor_calls
        doctor_calls += 1

    with pytest.raises(typer.Exit) as exc_info:
        wizard.run_main_menu(
            install_fn=lambda u, t, sc, cfg: None,
            uninstall_fn=lambda r: None,
            status_fn=lambda: None,
            doctor_fn=doctor_fn,
        )
    assert exc_info.value.exit_code == 0
    assert doctor_calls == 1
    assert next(actions, "DONE") == "DONE"


def test_main_menu_loops_back_after_language(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """The original feedback that triggered the loop redesign:
    selecting Language must NOT exit the wizard."""
    actions = iter(["language", "exit"])
    monkeypatch.setattr(wizard, "_prompt_main_action", lambda: next(actions))
    monkeypatch.setattr(wizard, "_prompt_language", lambda: "zh")

    with pytest.raises(typer.Exit) as exc_info:
        wizard.run_main_menu(
            install_fn=lambda u, t, sc, cfg: None,
            uninstall_fn=lambda r: None,
            status_fn=lambda: None,
            doctor_fn=lambda: None,
        )
    assert exc_info.value.exit_code == 0
    # Both menu prompts consumed → loop ran twice (language, then exit)
    assert next(actions, "DONE") == "DONE"

    # Bonus: verify language was actually persisted
    from cc_guard.state import StateStore
    assert StateStore().get_language() == "zh"


def test_main_menu_loops_back_after_subwizard_cancel(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """A sub-wizard raising typer.Exit (e.g. install cancel) must not
    kill the main menu loop — user should land back on the main prompt."""
    actions = iter(["install", "exit"])
    monkeypatch.setattr(wizard, "_prompt_main_action", lambda: next(actions))
    # New install wizard: user cancels at the single confirmation prompt
    monkeypatch.setattr(wizard, "_prompt_proceed_no_hub", lambda: False)

    install_calls = 0
    def install_fn(url, timeout, sc, cfg):
        nonlocal install_calls
        install_calls += 1

    with pytest.raises(typer.Exit) as exc_info:
        wizard.run_main_menu(
            install_fn=install_fn,
            uninstall_fn=lambda r: None,
            status_fn=lambda: None,
            doctor_fn=lambda: None,
        )
    assert exc_info.value.exit_code == 0
    assert install_calls == 0
    assert next(actions, "DONE") == "DONE"


# ── install wizard (defaults-driven, single-confirm) ───────
#
# The new install wizard reads defaults from store.get_defaults() and
# hub token from ~/.cc-guard/hub-token, shows a summary, and asks for
# a single confirmation. Individual field prompts are gone — editing
# happens in the separate Configure menu.

def test_install_wizard_happy_path_with_hub(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """Full remote-hub install: defaults + hub_url + hub_token → single
    confirm → install_fn gets SidecarSettings with hub mode."""
    from cc_guard.state import Defaults
    from cc_guard.sidecar import write_hub_token

    store = StateStore()
    store.set_defaults(Defaults(
        listen_url="http://127.0.0.1:28001",
        api_timeout_ms=3_000_000,
        sidecar_enabled=True,
        hub_url="https://hub.example.com",
    ))
    write_hub_token("secret-token")

    monkeypatch.setattr(wizard, "_prompt_proceed", lambda: True)

    captured: dict = {}
    def install_fn(url, timeout, sc, cfg):
        captured["url"] = url
        captured["timeout"] = timeout
        captured["sc"] = sc

    wizard.run_install_wizard(install_fn, store)

    assert captured["url"] == "http://127.0.0.1:28001"
    assert captured["timeout"] == 3_000_000
    assert captured["sc"] is not None
    assert captured["sc"].hub_url == "https://hub.example.com"
    assert captured["sc"].hub_token == "secret-token"


def test_install_wizard_happy_path_no_hub(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """Local proxy mode: sidecar enabled but no hub → _prompt_proceed_no_hub
    is used (default No), user says Yes → install runs in proxy mode."""
    from cc_guard.state import Defaults

    store = StateStore()
    store.set_defaults(Defaults(
        listen_url="http://127.0.0.1:9999",
        sidecar_enabled=True,
        hub_url=None,
    ))

    monkeypatch.setattr(wizard, "_prompt_proceed_no_hub", lambda: True)

    captured: dict = {}
    def install_fn(url, timeout, sc, cfg):
        captured["url"] = url
        captured["sc"] = sc

    wizard.run_install_wizard(install_fn, store)

    assert captured["url"] == "http://127.0.0.1:9999"
    assert captured["sc"] is not None
    assert captured["sc"].hub_url is None  # proxy mode


def test_install_wizard_sidecar_off(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """Sidecar disabled → install_fn gets None for sidecar settings."""
    from cc_guard.state import Defaults

    store = StateStore()
    store.set_defaults(Defaults(sidecar_enabled=False, hub_url=None))

    # Sidecar off + no hub → normal "Proceed?" (not the no-hub warning one)
    monkeypatch.setattr(wizard, "_prompt_proceed", lambda: True)

    captured: dict = {}
    def install_fn(url, timeout, sc, cfg):
        captured["sc"] = sc

    wizard.run_install_wizard(install_fn, store)

    assert captured["sc"] is None


def test_install_wizard_user_cancels(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """User says No at the single confirmation → typer.Exit(3)."""
    monkeypatch.setattr(wizard, "_prompt_proceed_no_hub", lambda: False)

    called = False
    def install_fn(url, timeout, sc, cfg):
        nonlocal called
        called = True

    with pytest.raises(typer.Exit) as exc_info:
        wizard.run_install_wizard(install_fn, StateStore())
    assert exc_info.value.exit_code == 3
    assert not called


def test_install_wizard_hub_set_but_no_token(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """Hub URL configured but no token → wizard refuses to proceed and
    exits with abort code, install_fn is never called."""
    from cc_guard.state import Defaults

    store = StateStore()
    store.set_defaults(Defaults(hub_url="https://hub.example.com"))
    # Deliberately do NOT write a hub token

    called = False
    def install_fn(url, timeout, sc, cfg):
        nonlocal called
        called = True

    with pytest.raises(typer.Exit) as exc_info:
        wizard.run_install_wizard(install_fn, store)
    assert exc_info.value.exit_code == 3
    assert not called


def test_install_wizard_uses_factory_defaults(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """First-time use: no defaults in state.yaml → factory defaults
    (listen_url=25559, sidecar=on, hub=None, timeout=3M)."""
    monkeypatch.setattr(wizard, "_prompt_proceed_no_hub", lambda: True)

    captured: dict = {}
    def install_fn(url, timeout, sc, cfg):
        captured["url"] = url
        captured["timeout"] = timeout
        captured["sc"] = sc

    wizard.run_install_wizard(install_fn, StateStore())

    assert captured["url"] == "http://127.0.0.1:25559"  # factory default
    assert captured["timeout"] == 3_000_000              # factory default
    assert captured["sc"] is not None                    # sidecar=on by default
    assert captured["sc"].hub_url is None                # no hub by default


# ── uninstall wizard ────────────────────────────────────────

def _seed_install(store: StateStore, *, with_shell_rc: bool = True) -> None:
    shell_changes = [
        ShellRcChange(path="/fake/.zshrc", backup="/fake/backup", removed_line_count=1),
    ] if with_shell_rc else []
    store.record_install("claude-code", InstallRecord(
        upstream="http://127.0.0.1:9999",
        installed_at="2026-04-09T00:00:00Z",
        settings_backup="/fake/backup.json",
        backup_base_url=None,
        api_timeout_ms=None,
        shell_rc_changes=shell_changes,
    ))


def test_uninstall_wizard_not_installed(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    with pytest.raises(typer.Exit) as exc_info:
        wizard.run_uninstall_wizard(lambda r: None, StateStore())
    assert exc_info.value.exit_code == 2


def test_uninstall_wizard_happy_path(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    store = StateStore()
    _seed_install(store)

    scripted = _Scripted()
    scripted.patch(monkeypatch, restore_shell_rc=True, proceed=True)

    captured: dict = {}
    def uninstall_fn(restore):
        captured["restore"] = restore

    wizard.run_uninstall_wizard(uninstall_fn, store)

    assert captured["restore"] is True


def test_uninstall_wizard_keep_shell_rc(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    store = StateStore()
    _seed_install(store)

    scripted = _Scripted()
    scripted.patch(monkeypatch, restore_shell_rc=False, proceed=True)

    captured: dict = {}
    def uninstall_fn(restore):
        captured["restore"] = restore

    wizard.run_uninstall_wizard(uninstall_fn, store)

    assert captured["restore"] is False


def test_uninstall_wizard_user_cancels(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    store = StateStore()
    _seed_install(store)

    scripted = _Scripted()
    scripted.patch(monkeypatch, restore_shell_rc=True, proceed=False)

    called = False
    def uninstall_fn(restore):
        nonlocal called
        called = True

    with pytest.raises(typer.Exit) as exc_info:
        wizard.run_uninstall_wizard(uninstall_fn, store)
    assert exc_info.value.exit_code == 3
    assert not called


def test_uninstall_wizard_no_shell_rc_changes(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    """If the install didn't touch shell rc,we shouldn't prompt about it."""
    store = StateStore()
    _seed_install(store, with_shell_rc=False)

    scripted = _Scripted()
    # Note: no restore_shell_rc in scripted answers — prompt should never be called
    scripted.patch(monkeypatch, proceed=True)

    # Fail loudly if the wizard tries to ask about shell rc
    def forbidden(*args, **kwargs):
        raise RuntimeError("should not be called when there are no shell rc changes")
    monkeypatch.setattr(wizard, "_prompt_restore_shell_rc", forbidden)

    captured: dict = {}
    def uninstall_fn(restore):
        captured["restore"] = restore

    wizard.run_uninstall_wizard(uninstall_fn, store)

    # Default (True) should be passed through
    assert captured["restore"] is True
