"""Tests for shell_rc.py."""

from __future__ import annotations

from pathlib import Path

import pytest

from cc_guard.shell_rc import (
    RcMatch,
    detect_shell_rc,
    remove_lines,
    restore_from_backup,
    scan_for_base_url,
)


# ── detection ────────────────────────────────────────────────

@pytest.mark.parametrize("shell_path,expected_name", [
    ("/bin/bash", ".bashrc"),
    ("/usr/bin/zsh", ".zshrc"),
    ("/usr/local/bin/fish", "config.fish"),
    ("/bin/dash", ".profile"),    # fallback
    ("", ".profile"),              # no SHELL env
])
def test_detect_shell_rc(
    shell_path: str, expected_name: str,
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setenv("SHELL", shell_path)
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "posix")
    result = detect_shell_rc()
    assert result is not None
    assert result.name == expected_name


def test_detect_shell_rc_returns_none_on_windows(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setattr("cc_guard.shell_rc.os.name", "nt")
    assert detect_shell_rc() is None


# ── scanning: bash/zsh ───────────────────────────────────────

def test_scan_empty_file(fake_home: Path):
    rc = fake_home / ".zshrc"
    rc.write_text("")
    assert scan_for_base_url(rc) == []


def test_scan_missing_file(fake_home: Path):
    """Missing file is not an error — user may not have one yet."""
    rc = fake_home / ".zshrc"
    assert scan_for_base_url(rc) == []


def test_scan_bash_export_line(fake_home: Path):
    rc = fake_home / ".bashrc"
    rc.write_text(
        "# my bashrc\n"
        "export PATH=$HOME/bin:$PATH\n"
        "export ANTHROPIC_BASE_URL=https://api.z.ai/api/anthropic\n"
        "export ANTHROPIC_API_KEY=sk-ant-xxx\n"      # must NOT be matched
        "alias ll='ls -la'\n"
    )
    matches = scan_for_base_url(rc)
    assert len(matches) == 1
    assert matches[0].line_number == 3
    assert "ANTHROPIC_BASE_URL" in matches[0].content
    # API_KEY line is not in results — we never touch credentials
    assert not any("API_KEY" in m.content for m in matches)


def test_scan_zsh_with_indentation(fake_home: Path):
    """Leading whitespace should still match (some users indent their exports)."""
    rc = fake_home / ".zshrc"
    rc.write_text(
        "if [[ -n $SOMETHING ]]; then\n"
        "    export ANTHROPIC_BASE_URL=https://example.com\n"
        "fi\n"
    )
    matches = scan_for_base_url(rc)
    assert len(matches) == 1
    assert matches[0].line_number == 2


def test_scan_skips_commented_out_lines(fake_home: Path):
    """A commented-out export is not an active binding — leave it alone."""
    rc = fake_home / ".zshrc"
    rc.write_text(
        "# export ANTHROPIC_BASE_URL=https://old.example.com\n"
        "#export ANTHROPIC_BASE_URL=https://also-commented.example.com\n"
        "export ANTHROPIC_BASE_URL=https://active.example.com\n"
    )
    matches = scan_for_base_url(rc)
    assert len(matches) == 1
    assert matches[0].line_number == 3


def test_scan_does_not_match_similar_variable_names(fake_home: Path):
    """Make sure we don't false-match ANTHROPIC_BASE_URL_BACKUP etc."""
    rc = fake_home / ".zshrc"
    rc.write_text(
        "export ANTHROPIC_BASE_URL_BACKUP=https://old.example.com\n"
        "export MY_ANTHROPIC_BASE_URL=https://not-us.example.com\n"
        "export ANTHROPIC_BASE_URL=https://target.example.com\n"
    )
    matches = scan_for_base_url(rc)
    assert len(matches) == 1
    assert matches[0].line_number == 3


def test_scan_multiple_matches(fake_home: Path):
    rc = fake_home / ".zshrc"
    rc.write_text(
        "export ANTHROPIC_BASE_URL=https://first.example.com\n"
        "# some comment\n"
        "export ANTHROPIC_BASE_URL=https://second.example.com\n"
    )
    matches = scan_for_base_url(rc)
    assert len(matches) == 2
    assert [m.line_number for m in matches] == [1, 3]


# ── scanning: fish ───────────────────────────────────────────

def test_scan_fish_set_line(fake_home: Path):
    rc = fake_home / ".config" / "fish" / "config.fish"
    rc.parent.mkdir(parents=True)
    rc.write_text(
        "set -gx PATH $HOME/bin $PATH\n"
        "set -gx ANTHROPIC_BASE_URL https://api.z.ai/api/anthropic\n"
        "set -gx ANTHROPIC_API_KEY sk-ant-xxx\n"
    )
    matches = scan_for_base_url(rc)
    assert len(matches) == 1
    assert matches[0].line_number == 2
    assert not any("API_KEY" in m.content for m in matches)


def test_scan_fish_short_x_flag(fake_home: Path):
    rc = fake_home / ".config" / "fish" / "config.fish"
    rc.parent.mkdir(parents=True)
    rc.write_text("set -x ANTHROPIC_BASE_URL https://example.com\n")
    matches = scan_for_base_url(rc)
    assert len(matches) == 1


# ── remove_lines ─────────────────────────────────────────────

def test_remove_lines_preserves_others(fake_home: Path):
    rc = fake_home / ".zshrc"
    rc.write_text(
        "line1\n"
        "line2\n"
        "line3\n"
        "line4\n"
        "line5\n"
    )
    backup = remove_lines(rc, {2, 4})
    content = rc.read_text()
    assert content == "line1\nline3\nline5\n"
    # Backup has original content
    assert backup.read_text() == "line1\nline2\nline3\nline4\nline5\n"
    assert backup.exists()


def test_remove_lines_empty_set_is_noop(fake_home: Path):
    rc = fake_home / ".zshrc"
    rc.write_text("line1\nline2\n")
    remove_lines(rc, set())
    assert rc.read_text() == "line1\nline2\n"


def test_remove_lines_missing_file_raises(fake_home: Path):
    with pytest.raises(FileNotFoundError):
        remove_lines(fake_home / "nonexistent.rc", {1})


def test_remove_lines_preserves_trailing_newline(fake_home: Path):
    """Files with/without trailing newline should round-trip cleanly."""
    rc = fake_home / ".zshrc"
    rc.write_text("line1\nline2")   # no trailing newline
    remove_lines(rc, {1})
    assert rc.read_text() == "line2"


# ── restore ──────────────────────────────────────────────────

def test_restore_from_backup(fake_home: Path):
    rc = fake_home / ".zshrc"
    rc.write_text("original\ncontent\n")
    backup = remove_lines(rc, {1})
    assert rc.read_text() == "content\n"

    restore_from_backup(rc, backup)
    assert rc.read_text() == "original\ncontent\n"


def test_restore_missing_backup_raises(fake_home: Path):
    with pytest.raises(FileNotFoundError):
        restore_from_backup(fake_home / "rc", fake_home / "nope.bak")


# ── end-to-end workflow on a realistic rc file ──────────────

def test_realistic_zshrc_cleanup(fake_home: Path):
    """A realistic .zshrc with a scattered base_url line in the middle."""
    rc = fake_home / ".zshrc"
    original = """# Zsh config
export EDITOR=vim
export PATH=$HOME/.local/bin:$PATH

# Claude stuff
export ANTHROPIC_API_KEY=sk-ant-user-key
export ANTHROPIC_BASE_URL=https://api.z.ai/api/anthropic

# aliases
alias ll='ls -la'
"""
    rc.write_text(original)

    matches = scan_for_base_url(rc)
    assert len(matches) == 1
    line_nums = {m.line_number for m in matches}
    backup = remove_lines(rc, line_nums)

    after = rc.read_text()
    assert "ANTHROPIC_BASE_URL" not in after
    assert "ANTHROPIC_API_KEY=sk-ant-user-key" in after     # untouched
    assert "alias ll='ls -la'" in after                      # untouched

    # Backup is full original
    assert backup.read_text() == original
