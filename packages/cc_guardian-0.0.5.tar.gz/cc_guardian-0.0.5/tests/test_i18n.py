"""Tests for the i18n framework.

The fake_home fixture clears LANG/LC_ALL by default and resets the
i18n cache, so tests start in a deterministic English state and opt
into Chinese explicitly.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from cc_guard import i18n
from cc_guard.i18n import (
    En,
    Zh,
    available_languages,
    current_language,
    reset_cache,
    set_language,
    t,
)
from cc_guard.state import StateStore


# ── detection from environment ─────────────────────────────

class TestDetectFromEnv:
    def test_no_locale_vars_defaults_to_english(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        # fake_home already cleared the locale vars
        reset_cache()
        assert current_language() == "en"

    def test_lang_zh_cn_utf8_picks_chinese(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        monkeypatch.setenv("LANG", "zh_CN.UTF-8")
        reset_cache()
        assert current_language() == "zh"

    def test_lang_zh_tw_picks_chinese(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        monkeypatch.setenv("LANG", "zh_TW")
        reset_cache()
        assert current_language() == "zh"

    def test_lang_en_us_picks_english(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        monkeypatch.setenv("LANG", "en_US.UTF-8")
        reset_cache()
        assert current_language() == "en"

    def test_lc_all_takes_priority_over_lang(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        monkeypatch.setenv("LANG", "en_US")
        monkeypatch.setenv("LC_ALL", "zh_CN.UTF-8")
        reset_cache()
        assert current_language() == "zh"

    def test_lc_messages_in_between(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        monkeypatch.setenv("LANG", "en_US")
        monkeypatch.setenv("LC_MESSAGES", "zh_CN")
        reset_cache()
        assert current_language() == "zh"

    def test_french_falls_back_to_english(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        """Anything not zh* is treated as English (no French translation)."""
        monkeypatch.setenv("LANG", "fr_FR.UTF-8")
        reset_cache()
        assert current_language() == "en"


# ── persisted choice overrides auto-detect ─────────────────

class TestPersistedChoice:
    def test_set_language_persists_to_state_yaml(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        set_language("zh")
        # Read it back through a fresh StateStore instance
        assert StateStore().get_language() == "zh"

    def test_persisted_overrides_env_detection(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        monkeypatch.setenv("LANG", "en_US.UTF-8")
        set_language("zh")
        # Even though LANG says English, the persisted choice wins
        reset_cache()
        assert current_language() == "zh"

    def test_set_language_clears_cache(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        # Force cache to "en" first
        reset_cache()
        assert current_language() == "en"
        # Now switch — should be visible immediately, no manual reset
        set_language("zh")
        assert current_language() == "zh"

    def test_set_language_invalid_raises(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        with pytest.raises(ValueError, match="unsupported language"):
            set_language("fr")  # type: ignore[arg-type]

    def test_persisted_survives_after_setting(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        """Setting language must not clobber installs / last_upstream."""
        # Seed an install record
        from cc_guard.state import InstallRecord
        store = StateStore()
        store.record_install("claude-code", InstallRecord(
            upstream="http://127.0.0.1:9999",
            installed_at="2026-04-09T00:00:00Z",
            settings_backup="/fake/backup.json",
        ))
        # Now set language
        set_language("zh")
        # Verify everything is still there
        store2 = StateStore()
        assert store2.get_language() == "zh"
        assert store2.is_installed("claude-code")
        assert store2.get_last_upstream() == "http://127.0.0.1:9999"


# ── t() returns the right namespace ────────────────────────

class TestActiveNamespace:
    def test_returns_en_class_in_english(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        reset_cache()
        assert t() is En

    def test_returns_zh_class_in_chinese(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        monkeypatch.setenv("LANG", "zh_CN.UTF-8")
        reset_cache()
        assert t() is Zh

    def test_t_strings_actually_differ(
        self, fake_home: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        reset_cache()
        en_tagline = t().tagline

        monkeypatch.setenv("LANG", "zh_CN.UTF-8")
        reset_cache()
        zh_tagline = t().tagline

        assert en_tagline == "Claude Code security gateway"
        assert zh_tagline == "Claude Code 安全网关"
        assert en_tagline != zh_tagline


# ── Translation completeness (Zh mirrors En) ───────────────

class TestTranslationCompleteness:
    """Catch missing Chinese translations at test time, not at runtime."""

    def test_zh_has_all_en_attributes(self):
        en_attrs = {
            name for name in dir(En)
            if not name.startswith("_")
        }
        zh_attrs = {
            name for name in dir(Zh)
            if not name.startswith("_")
        }
        missing_in_zh = en_attrs - zh_attrs
        assert not missing_in_zh, (
            f"Zh is missing translations for: {sorted(missing_in_zh)}"
        )

    def test_no_orphan_zh_attributes(self):
        """Catch attrs that exist in Zh but not En (typo / refactor leftover)."""
        en_attrs = {n for n in dir(En) if not n.startswith("_")}
        zh_attrs = {n for n in dir(Zh) if not n.startswith("_")}
        orphans = zh_attrs - en_attrs
        assert not orphans, (
            f"Zh has stray attributes not present in En: {sorted(orphans)}"
        )

    def test_format_placeholders_match_between_languages(self):
        """Make sure {url}, {pid} etc. exist in both translations of the
        same key — otherwise .format() would crash for one language."""
        import string
        formatter = string.Formatter()

        for name in dir(En):
            if name.startswith("_"):
                continue
            en_val = getattr(En, name)
            if not isinstance(en_val, str):
                continue
            zh_val = getattr(Zh, name, None)
            if not isinstance(zh_val, str):
                continue

            en_fields = {
                fname for _, fname, _, _ in formatter.parse(en_val)
                if fname
            }
            zh_fields = {
                fname for _, fname, _, _ in formatter.parse(zh_val)
                if fname
            }
            assert en_fields == zh_fields, (
                f"Placeholder mismatch on '{name}': "
                f"En has {en_fields}, Zh has {zh_fields}"
            )


# ── available_languages for the wizard menu ────────────────

class TestAvailableLanguages:
    def test_lists_both_supported(self):
        codes = [code for code, _ in available_languages()]
        assert "en" in codes
        assert "zh" in codes

    def test_each_entry_has_display_name(self):
        for code, display in available_languages():
            assert isinstance(code, str)
            assert isinstance(display, str)
            assert display  # non-empty
