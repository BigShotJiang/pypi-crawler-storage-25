# cc-guard 执行逻辑

这份文档描述 cc-guard 的核心执行流程——`install` / `uninstall` 从参数到磁盘改动、到子进程 spawn、到状态落盘的**完整时序**。读懂了这个就能回答"改 X 会影响什么"、"Y 为什么不还原"之类的问题。

目标读者:维护者 + Agent。不是用户手册。

---

## 1. 组件地图

```
cli.py            命令入口。解析参数 → 调 _do_install/_do_uninstall
wizard.py         零参数交互 UX。收集答案 → 调 _do_install/_do_uninstall
claude_code.py    settings.json 的原子读写 + install/uninstall 纯逻辑
shell_rc.py       bash/zsh/fish rc 检测 + 行级清理 + 备份
sidecar.py        可选的 sidecar 子进程管理(B 方案)
state.py          ~/.cc-guard/state.yaml 存储 InstallRecord
backup.py         原子写 + 备份路径管理
doctor.py         诊断检查(只读,不参与 install/uninstall)
```

**依赖方向**:`cli` / `wizard` → 其它所有模块。其它模块之间**零依赖**(除了 `claude_code` 用 `backup`)。所有"会改磁盘"的副作用都集中在 `_do_install` / `_do_uninstall` 两个函数里。

**单例文件清单**(所有副作用的落脚点):

| 路径 | 写入者 | 卸载时 |
|---|---|---|
| `~/.claude/settings.json` | `ClaudeCodeManager` | 还原备份里的 env 字段 |
| `~/.cc-guard/state.yaml` | `StateStore` | 清空 `installs.claude-code` 条目 |
| `~/.cc-guard/backup/*` | `backup_file()` | 不删(保留以便手动 rollback) |
| `~/.cc-guard/sidecar.yaml` | `write_sidecar_config()` | 不删(下次 install 覆盖) |
| `~/.cc-guard/hub-token` | `write_hub_token()` | **删**(凭证不能跨 install 保留) |
| `~/.cc-guard/sidecar.pid` | `start_managed_sidecar()` | `stop_managed_sidecar` 删 |
| `~/.cc-guard/sidecar.out` | sidecar 子进程 stdout | 不删 |
| `~/.{bashrc,zshrc,...}` | `remove_lines()` | 若 `--restore-shell-rc` 则从备份还原 |

---

## 2. Install 执行时序

入口:`cli.install(upstream, ...)` 或 `wizard.run_install_wizard(...)` → 都汇入 `cli._do_install()`。

### 2.1 阶段划分

```
参数归一化
   ↓
规划(纯读,不改盘)
   ↓  [dry-run 在此 exit]
修改 settings.json          ← 原子
   ↓
清理 shell rc 冲突行        ← 可选,有冲突才跑
   ↓
[Sidecar 路径]              ← 仅当 want_sidecar 为 True
  a. 停旧 sidecar
  b. 生成 sidecar.yaml      (或用 --sidecar-config 提供的)
  c. 写 hub-token           (仅当有 hub_token)
  d. spawn 子进程
   ↓
落盘 state.yaml             ← 最后一步,只有跑到这里才算"装上了"
```

### 2.2 规划阶段(pure read)

```python
current_base = mgr.current_base_url()            # settings.json.env.ANTHROPIC_BASE_URL
rc_matches  = scan_for_base_url(detect_shell_rc())  # 每一条 `export ANTHROPIC_BASE_URL=...`
env_override = os.environ.get("ANTHROPIC_BASE_URL") # 当前 shell 里的泄漏
```

三个探测彼此独立,只用来打印 plan 和早退:

- **提前成功退出**:`current_base == upstream` + 已 installed + 没有 sidecar 参数 → 幂等 no-op。
- **提前失败退出**:`--hub` 没配 `--hub-token` → 拒绝。
- **警告但不阻塞**:`env_override` 和 `upstream` 不一致 → 告诉用户 shell 会覆盖 settings.json。

### 2.3 settings.json 修改(ClaudeCodeManager.install)

`claude_code.py:ClaudeCodeManager.install(upstream, api_timeout_ms)`:

```
1. backup_file(settings.json) → ~/.cc-guard/backup/settings.json.<ts>
2. data = json.loads(settings.json)
3. env = data.setdefault("env", {})
4. previous = env.get("ANTHROPIC_BASE_URL")
   if previous and previous != upstream:
       env["_CC_GUARD_BACKUP_BASE_URL"] = previous  ← 精确还原的关键
5. env["ANTHROPIC_BASE_URL"] = upstream
6. if api_timeout_ms: env["API_TIMEOUT_MS"] = str(api_timeout_ms)
7. atomic_write_json(settings.json, data)           ← 临时文件 + os.replace
```

**精确还原机制**:`_CC_GUARD_BACKUP_BASE_URL` 这个影子字段直接存在 `env` 里而不是 state.yaml。好处是 state.yaml 和 settings.json 不需要同步:即使 state.yaml 丢了,settings.json 自己就能还原。

**幂等性来源**:第 4 步的 `if previous != upstream` 条件确保重复装不会把自己装进自己的备份。

**原子性**:第 7 步走 `atomic_write_json(path, data)` → 写 `path.tmp.<pid>` + `os.replace`。写入过程被 Ctrl-C 中断最多丢失最新一次写,不会损坏原文件。

### 2.4 Shell rc 清理(shell_rc.remove_lines)

只有 `rc_matches` 非空才跑:

```
1. 备份:~/.cc-guard/backup/<basename>.<ts>
2. 读 rc 文件全部行
3. 按行号过滤掉命中的行
4. 原子写回
5. 在 rc_changes 列表里记一条 ShellRcChange
```

为什么按**行号**而不是正则 replace:行号定位确保不做"部分替换",避免出现"匹配一半改一半"这种不幂等场景(chelper 踩过)。

**保守行为**:shell rc 只清 `ANTHROPIC_BASE_URL` 相关行,`ANTHROPIC_API_KEY` / `ANTHROPIC_AUTH_TOKEN` 等 **从不触碰**(透传哲学)。

### 2.5 Sidecar 路径(仅当 `want_sidecar = True`)

触发条件:`--sidecar` / `--upstream` / `--hub` / `--sidecar-config` 任一给了,或者 wizard 里回答要 sidecar。

```
a. stopped_prev = sidecar.sidecar_status()
   if stopped_prev.state == "running":
       sidecar.stop_managed_sidecar()             ← 让 install 可重跑

b. 配置来源二选一:
   - 用户传了 --sidecar-config PATH:直接用那个 yaml
   - 否则:cfg = build_sidecar_config(sidecar_settings)
           cfg_path = write_sidecar_config(cfg)   ← ~/.cc-guard/sidecar.yaml, 0600

c. if sidecar_settings.hub_token:
       write_hub_token(token)                     ← ~/.cc-guard/hub-token, 0600

d. handle = start_managed_sidecar(cfg_path, listen=upstream, hub_token=token)
```

四步任一失败都**会抛异常让 install 整体失败**——不做"装一半"。但 settings.json 和 shell rc 的改动**已经落盘了**(步骤 2.3 和 2.4 在 sidecar 路径之前)。用户下次 uninstall 时会拿到一条"有 sidecar 字段但进程没起来"的记录,`stop_managed_sidecar` 对这种"pid 不存在"的情况是无操作(见 5.3)。

**为什么 settings.json 先改**:想让用户即使 flowlens 没装也能"只改 settings 指向已有的 proxy"这条便捷路径不受 sidecar 路径影响。两个路径互不牵连。

### 2.6 落盘 state.yaml

```python
record = InstallRecord(
    upstream=upstream,
    installed_at=now_iso(),
    settings_backup=str(result.settings_backup_path),
    backup_base_url=result.previous_base_url,   # uninstall 还原用
    api_timeout_ms=api_timeout,                 # 防止 uninstall 误删用户自己设的
    shell_rc_changes=rc_changes,
    sidecar=managed,                            # None or ManagedSidecar(pid, config_path, listen, started_at)
)
store.record_install(TOOL_NAME, record)
# ↑ 等价于 load() → records[tool]=record → save(records, last_upstream=record.upstream)
```

`last_upstream` 独立于 `installs` 字段保存,uninstall 时保留——这样用户下次 install 时 wizard 还能记住上次 URL。

---

## 3. Uninstall 执行时序

入口:`cli.uninstall(...)` 或 `wizard.run_uninstall_wizard(...)` → `cli._do_uninstall()`.

### 3.1 阶段划分

```
读 state.yaml 取 InstallRecord
   ↓  [未装 → exit 2]
打印 plan
   ↓  [dry-run 在此 exit]
停 sidecar 子进程(如有)     ← 先停进程!
   ↓
删 hub-token(如有)
   ↓
改回 settings.json
   ↓
还原 shell rc(如 --restore-shell-rc)
   ↓
清 state.yaml 里的 claude-code 条目
```

### 3.2 为什么先停 sidecar

顺序很重要。如果先改 settings.json 后停 sidecar:

- 改 settings.json 失败 → 用户视角:settings 没变,但 sidecar 还在跑——**静默错位**。
- 停 sidecar 失败 → 用户视角:settings 已变回直连 Anthropic,但 sidecar 还在 127.0.0.1:28001 抢端口——下次 install 会撞端口。

先停进程的话,如果停失败就**整体中止**,用户看到的是"sidecar 还活着 + settings.json 没动"这种**对齐的**中间态,更容易修。

### 3.3 sidecar 停止(stop_managed_sidecar)

```
1. 读 ~/.cc-guard/sidecar.pid → pid
2. if not _is_pid_alive(pid): 删 pid 文件,返回 {state: not_running}
3. os.kill(pid, SIGTERM)
4. 轮询 _is_pid_alive 最多 timeout 秒(默认 5s)
5. 还活着 → os.kill(pid, SIGKILL)
6. 删 pid 文件
```

**幂等保证**:pid 文件不存在 / pid 已死 / pid 对应别的进程 → 函数都不抛异常,返回 `{state: not_running}`。uninstall 对 sidecar 的处理完全可以"盲目调用"。

### 3.4 hub-token 清理

```python
if record.sidecar is not None:
    stop_managed_sidecar()
    remove_hub_token()             # 无条件删,remove_hub_token 本身幂等
```

**为什么一定要删**:hub-token 是跨 install 的凭证文件。如果不删,用户下次 `ccg install --hub 另一个hub --hub-token 新token` 时,虽然 `write_hub_token` 会覆盖文件,但**在覆盖发生之前**如果失败退出,下次启动的 sidecar 会通过 `CC_GUARD_HUB_TOKEN` 环境变量把**旧 hub 的 token 泄漏给新 sidecar 进程**。

这是联调时实际踩到的坑——commit `f401ff7` 修掉的。单元测试:`tests/test_cli.py::test_uninstall_cleans_managed_sidecar_and_hub_token`。

### 3.5 settings.json 还原(ClaudeCodeManager.uninstall)

```python
mgr.uninstall(had_api_timeout=record.api_timeout_ms is not None)
```

内部逻辑:

```
1. backup_file(settings.json)          ← 再备份一次,防止卸载也需要撤销
2. data = json.loads(settings.json)
3. env = data.get("env", {})
4. backup_url = env.pop("_CC_GUARD_BACKUP_BASE_URL", None)
   if backup_url:
       env["ANTHROPIC_BASE_URL"] = backup_url        ← 还原原值
   else:
       env.pop("ANTHROPIC_BASE_URL", None)           ← 原来就没有,直接删
5. if had_api_timeout and "API_TIMEOUT_MS" in env:
       env.pop("API_TIMEOUT_MS")                     ← 仅当是我们注入的才删
6. if not env: data.pop("env", None)                 ← env 空了连字段一起删
7. atomic_write_json(settings.json, data)
```

**关键不变量**:`had_api_timeout` 必须从 state.yaml 读,不能从 settings.json 当前值推断。否则用户自己后来加的 `API_TIMEOUT_MS` 会被误删。

### 3.6 shell rc 还原

```python
if restore_shell_rc:  # 默认 True,--keep-shell-rc 可关
    for change in record.shell_rc_changes:
        restore_from_backup(Path(change.path), Path(change.backup))
```

`restore_from_backup` 是"整文件替换"——把备份的 bytes 原样写回 rc 文件。这样只要备份还在,还原就是 byte-identical 的。

---

## 4. Sidecar 子系统

`sidecar.py` 是一个**独立子系统**,install/uninstall 只是它的调用方。核心契约:所有路径都默认在 `~/.cc-guard/` 下,所有副作用都有对应的清理函数。

### 4.1 配置生成(build_sidecar_config)

输入:`SidecarSettings(listen, upstream, hub_url, hub_token)`。

```
基础层(两种模式共有):
  listen: <解析自 listen URL 的 host:port>
  providers:
    anthropic:
      url: <upstream>
      models: ["*"]
      parser: claude
  log:
    dir: ~/.cc-guard/sidecar-logs
    body_mode: messages

if hub_url:  # sidecar mode
  mode: sidecar
  hub:
    url: <hub_url>
    token: ${CC_GUARD_HUB_TOKEN}   ← 不写明文!
    fail_open: true
  sidecar:
    upstream: <upstream>
  log.body_mode: none              ← hub 是审计 sink,避免双重存储

else:  # proxy mode
  mode: proxy
  # (hub / sidecar 段不存在)
```

**token 从不进 yaml**:配置里只写 `${CC_GUARD_HUB_TOKEN}` 变量引用,真 token 单独存在 `~/.cc-guard/hub-token`(0600),`start_managed_sidecar` 把它塞进子进程环境变量。这样:
- yaml 文件可以用 0600 也可以 0644,泄漏的只是"存在一个 hub"而不是凭证
- 换 token 不用重新生成 yaml

### 4.2 进程启动(start_managed_sidecar)

前置检查(任一失败直接抛异常):

```
1. sidecar_status() != "running"    ← 避免孤儿进程
2. find_flow_runner() != None       ← flowlens 可启动
3. not _port_in_use(host, port)     ← 提前判定端口占用,避免 uvicorn 报错
```

runner 发现顺序:

```
1. shutil.which("flow")                 # PATH 上有 flowlens CLI
2. import flowlens + [sys.executable, "-m", "flowlens"]   # 作为 Python 模块
3. None → 抛 FlowlensNotInstalled,告诉用户 `uv tool install cc-guard[sidecar]`
```

启动:

```python
proc = subprocess.Popen(
    [*runner, "run", "-c", str(config_path)],
    env={**os.environ, "CC_GUARD_HUB_TOKEN": hub_token},  # 仅当有 token
    stdout=open(~/.cc-guard/sidecar.out, "ab"),
    stderr=STDOUT,
    stdin=DEVNULL,
    start_new_session=True,              # 脱离 cc-guard 进程组
)
```

`start_new_session=True` 很关键:用户 Ctrl-C 掉 cc-guard 命令时,**不应该**杀掉后台 sidecar。

readiness check:最多 2 秒内轮询端口,看到端口 bound 就算启动成功。提前 poll 到 `proc.returncode != None`(即子进程已死)则读 `sidecar.out` 尾部 800 字节作为错误上下文抛出。

pid 落盘:`~/.cc-guard/sidecar.pid` 写 PID 字符串。

### 4.3 进程停止(stop_managed_sidecar)

见 3.3。核心原则:**任何异常状态都收敛到"未运行"**,不抛异常,让 uninstall 盲调安全。

### 4.4 状态查询(sidecar_status)

```
{state: "not_managed", pid: None}    pid 文件不存在
{state: "dead",        pid: N}       pid 文件存在但进程已死
{state: "running",     pid: N, uptime_s: F}   进程存活
```

`uptime_s` 从 `/proc/<pid>/stat` 的 mtime 推算(Linux 限定,其它平台返回 None)。仅用于 status 展示。

---

## 4a. Wizard 交互流(可选)

零参数的 `cc-guard` 走 `wizard.run_main_menu`。所有 `questionary` 调用都封装在 `_prompt_*` 函数里,是**为了测试可 mock**——真用户是看不出差别的。

install wizard 的问题顺序(任一 Ctrl-C 都退出 code=3):

```
1. upstream URL            (default 从 _pick_default_upstream 选)
2. 要设 API_TIMEOUT_MS 吗? → 值
3. 要管理 sidecar 吗?
   ├── yes:
   │   ├── sidecar 转发到哪? (默认 https://api.anthropic.com)
   │   ├── 要接 hub 吗?
   │   │   └── yes: hub url → hub token
   └── 最终 confirm
```

`_pick_default_upstream` 的优先级(最后一次联调改的):

```
1. 当前 cc-guard 装着的 upstream(state.yaml installs.claude-code.upstream)
2. 当前 settings.json 的 ANTHROPIC_BASE_URL(可能是别人设的)
3. state.yaml 的 last_upstream(历史记忆)
4. http://127.0.0.1:9999(硬编码兜底)
```

**为什么用户能看到的 > 记忆的**:wizard 顶部会先打印一个 "current state" 块,展示 settings.json 里的实际值。如果 prompt 的默认值和顶部显示不一致会困惑用户。

---

## 5. 关键不变量

这些是"改代码前必须先读一遍"的红线。违反任何一条都可能导致用户数据丢失。

### 5.1 settings.json 写入必须是原子的

所有写都走 `backup.atomic_write_json(path, data)`:

```python
tmp = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
os.replace(tmp, path)       # POSIX 保证原子
```

**禁止直接 `path.write_text(...)`** 去碰 settings.json。Ctrl-C 在 `write_text` 中间的写操作会留下半个文件。

### 5.2 `_CC_GUARD_BACKUP_BASE_URL` 是还原的单一真相源

- install 写入时只在 `previous != upstream` 才设,避免"备份自己"
- uninstall 读取时只要存在就优先还原它,忽略 state.yaml 里 `backup_base_url` 字段(它只是给 status 显示用)

双通道存储是**故意的**:state.yaml 和 settings.json 可以独立丢失、独立恢复。

### 5.3 sidecar 相关操作全部幂等

- `stop_managed_sidecar`:pid 文件不存在 / pid 死 / kill 失败 → 都收敛到 `not_running`
- `remove_hub_token`:文件不存在 → no-op
- `start_managed_sidecar`:发现前一个在跑 → 抛异常(调用方负责先 stop)

install 路径在 2.5.a 显式调了 `stop_managed_sidecar`——这样 `ccg install --hub ...` 可以反复跑(调试 hub URL / token 时很常用)。

### 5.4 凭证处理的边界

- **我们存的唯一凭证**:`~/.cc-guard/hub-token`(0600),install 写 / uninstall 删。
- **我们绝对不动的凭证**:`ANTHROPIC_AUTH_TOKEN` / `ANTHROPIC_API_KEY`——无论在 settings.json 的 env 里还是在 shell rc 里。
- **yaml 从不写明文 token**:sidecar.yaml 用 `${CC_GUARD_HUB_TOKEN}` 引用,真 token 只经由子进程的 env 传递。

### 5.5 state.yaml 的 `last_upstream` 跨 uninstall 保留

`StateStore.save()` 默认保留现有的 `last_upstream`,只有调用者显式传才覆盖。`remove_install` 不传,所以 uninstall 不会擦掉历史记忆。这让用户 `uninstall → install`(无参)走 wizard 时还能一键用回上次的 URL。

---

## 6. 错误码约定

| code | 含义 | 出现场景 |
|---|---|---|
| 0 | 成功 | 正常 / 已经 installed 且 no-op |
| 1 | 运行时错误 | settings.json 解析失败 / IO 错误 / sidecar 启动失败 |
| 2 | 前置条件不满足 | uninstall 时没有 install 记录 |
| 3 | 用户主动取消 | wizard 里 Ctrl-C / 回答 No |

`wizard` 和 `cli` 统一用这个约定。集成到 CI 的外部脚本可以按 exit code 分派处理。

---

## 7. 测试边界

`tests/` 的测试矩阵按模块组织,所有测试共享 `conftest.py` 里的 `fake_home` fixture——把 `$HOME` 指到 tmp_path,`Path.home()` 也被 monkeypatch,所以所有模块写入都落在临时目录,**永远不会污染真实的 `~/.claude/settings.json`**。

子进程测试(`test_sidecar_mgmt.py`)把 `subprocess.Popen` 完全 mock 掉——不需要真实 flowlens 安装就能跑。对应的**真实联调**靠 `docs/` 里没有的东西:人肉启 hub + 跑 `ccg install --hub`,这一步在 B 方案合并时做了一次(commit `44cf942` + `f401ff7`)。

---

## 8. 跨平台支持

cc-guard 0.0.3 起支持 Windows。设计原则:**所有 POSIX-only 系统调用都按 `os.name == "nt"` 分支化**,不靠运行时报错过滤。具体差异:

| 子系统 | POSIX | Windows |
|---|---|---|
| `settings.json` 路径 | `~/.claude/settings.json` | `%USERPROFILE%\.claude\settings.json` (`Path.home()` 自动) |
| `os.chmod(0o600)` | 真实生效 | NTFS 上是 no-op,凭证文件靠用户级 ACL 隐式保护 |
| Shell rc 清理 | bash/zsh/fish 行级清理 | 跳过(`detect_shell_rc()` 返回 None) |
| Sidecar 子进程 detach | `start_new_session=True` | `creationflags=DETACHED_PROCESS \| CREATE_NEW_PROCESS_GROUP` |
| Sidecar 进程探活 | `os.kill(pid, 0)` | `psutil.pid_exists(pid)`(psutil 是 sidecar extra 在 Windows 下的依赖) |
| Sidecar 优雅退出 | `SIGTERM` → 等 5s → `SIGKILL` | `SIGTERM`(=`TerminateProcess`,立即强杀)→ 等 5s → 再 `SIGTERM` 兜底。Windows 没有"优雅退出"语义 |

**设计代价**:Windows 上"优雅退出"不存在——`stop_managed_sidecar` 在第一次 SIGTERM 时其实就把进程立即杀了,后面的轮询和"escalate"是 no-op。这是 Windows 平台的硬约束,不是 cc-guard 的设计选择。

**Win32 常量硬编码**:`sidecar.py` 顶部定义 `_WIN32_DETACHED_PROCESS = 0x8` / `_WIN32_CREATE_NEW_PROCESS_GROUP = 0x200`,而不是 `subprocess.DETACHED_PROCESS`,因为后者在 POSIX 的 subprocess 模块上不存在,会导致即使 if 分支不进入也仍然在 attribute access 时炸。

**测试覆盖**:`test_sidecar_mgmt.py` 里 5 个测试用 `monkeypatch.setattr(sidecar.os, "name", "nt")` 模拟 Windows 跑在 POSIX 上,验证三个分支(Popen detach kwargs / `_is_pid_alive` 走 psutil / stop 不调 SIGKILL)。这些测试在任何 POSIX CI 上都会跑,所以 Windows 代码路径不会无声烂掉。但**真实 Windows 端到端验证仍依赖人肉测试或 Windows CI runner**——目前两者都没有,Windows 支持是 alpha。
