"""Interactive wizard — the zero-argument UX.

When the user runs `cc-guard` with no subcommand, or `cc-guard install`
with no upstream URL, they land in a questionary-based wizard that
presents the current state, asks a minimal set of questions, and lets
them confirm the plan before anything touches their filesystem.

Design goals:

1. **Zero characters to type in the common case.** Just `cc-guard` then
   arrow keys and Enter.
2. **Remember the last upstream** so returning users press Enter to
   reuse it.
3. **Show current state first** so users aren't blind-firing commands.
4. **All questionary calls are wrapped in small helper functions**
   (`_prompt_*`) so tests can monkeypatch them without mocking
   questionary internals.
5. **Graceful Ctrl-C**: questionary returns None on interrupt, we
   handle that as a user abort (exit code 3).
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Callable

import questionary
import typer
from rich.console import Console

from .claude_code import BASE_URL_KEY, ClaudeCodeManager
from .i18n import available_languages, set_language, t
from .shell_rc import detect_shell_rc, scan_for_base_url
from .sidecar import SidecarSettings
from .state import StateStore

_FALLBACK_URL = "http://127.0.0.1:25559"


def _pick_default_upstream(mgr: ClaudeCodeManager, store: StateStore) -> str:
    """Pick the best default URL to prefill in the install wizard.

    Priority, most-specific first:
      1. Currently installed (via cc-guard): the URL recorded in state.yaml
      2. Live value in settings.json (someone — cc-guard or user — set it)
      3. last_upstream from state.yaml (historical preference across uninstalls)
      4. Hard fallback (common local port)

    Rationale: the screen already shows what's in settings.json; if the
    prefilled value in the text prompt doesn't match, users are confused
    (exactly the bug that triggered this fix). Always prefer what the
    user can actually see to an opaque "remembered" value.
    """
    record = store.get("claude-code")
    if record is not None:
        return record.upstream

    current = mgr.current_base_url()
    if current:
        return current

    last = store.get_last_upstream()
    if last:
        return last

    return _FALLBACK_URL

_console = Console()

# Exit code convention (shared with cli.py):
#   0: success
#   1: runtime error
#   2: precondition failed (e.g. not installed)
#   3: user aborted
_ABORT = 3


# ── small questionary wrappers (easy to mock) ───────────────

def _prompt_main_action() -> str | None:
    """Main menu selection. Returns None on Ctrl-C.

    Order: primary actions first (install/uninstall), then read-only
    inquiries (status/doctor), then settings (language), then exit at
    the bottom — mirrors common CLI/GUI conventions.
    """
    s = t()
    return questionary.select(
        s.menu_prompt,
        choices=[
            questionary.Choice(s.menu_install, value="install"),
            questionary.Choice(s.menu_configure, value="configure"),
            questionary.Choice(s.menu_uninstall, value="uninstall"),
            questionary.Choice(s.menu_status, value="status"),
            questionary.Choice(s.menu_doctor, value="doctor"),
            questionary.Choice(s.menu_language, value="language"),
            questionary.Choice(s.menu_exit, value="exit"),
        ],
    ).ask()


def _prompt_language() -> str | None:
    """Language picker. Returns the chosen language code or None on Ctrl-C."""
    return questionary.select(
        t().language_prompt,
        choices=[
            questionary.Choice(display, value=code)
            for code, display in available_languages()
        ],
    ).ask()


def _prompt_restore_shell_rc(default: bool = True) -> bool | None:
    return questionary.confirm(
        t().uninstall_prompt_restore_rc,
        default=default,
    ).ask()


# ── state summary header shown at the top of each wizard view ──

def _print_state_summary(mgr: ClaudeCodeManager, store: StateStore) -> None:
    """Print a quick at-a-glance status block so the user isn't blind."""
    s = t()
    _console.print()
    _console.print(
        f"[bold cyan]cc-guard[/] — {s.tagline}  [dim]({s.subtitle})[/]"
    )
    _console.print()

    record = store.get("claude-code")
    current = mgr.current_base_url()

    if record is not None:
        _console.print(
            "  [cyan]" + s.summary_installed_yes.format(url=record.upstream) + "[/]"
        )
    else:
        _console.print(f"  [yellow]{s.summary_installed_no}[/]")
        if current:
            _console.print(
                "  [cyan]" + s.summary_current_url.format(url=current) + "[/]"
            )

    # Shell env check
    env_val = os.environ.get(BASE_URL_KEY)
    if env_val:
        _console.print(
            "  [yellow]" + s.summary_shell_env_warning.format(val=env_val) + "[/]"
        )

    # Shell rc check
    rc = detect_shell_rc()
    if rc is not None and rc.exists():
        conflicts = scan_for_base_url(rc)
        if conflicts:
            _console.print(
                "  [yellow]" + s.summary_shell_rc_conflict.format(path=rc, n=len(conflicts)) + "[/]"
            )

    _console.print()


# ── wizard entry points ─────────────────────────────────────

# Signature of the install callback passed into the wizard. Separated
# into a type alias so tests and main.py can swap in compatible lambdas.
#   args: (listen_url, api_timeout_ms, sidecar_settings_or_None, sidecar_config_override_or_None)
InstallFn = Callable[
    [str, "int | None", "SidecarSettings | None", "Path | None"],
    None,
]


def run_main_menu(
    install_fn: InstallFn,
    uninstall_fn: Callable[[bool], None],
    status_fn: Callable[[], None],
    doctor_fn: Callable[[], None],
) -> None:
    """`cc-guard` with no subcommand lands here.

    The main menu is a loop: every action returns to this menu after
    completion (success / cancel / error), so the user can do multiple
    things in one session — switch language, then install, then verify
    with status, then exit. Only the explicit "Exit" choice or Ctrl-C at
    the main prompt actually leaves the wizard.

    Sub-wizards (install/uninstall) raise `typer.Exit` internally when
    they complete or cancel; we catch it here so it doesn't propagate up
    and kill the loop. CLI exit codes from those sub-flows are dropped
    in interactive mode (CI / scripting users invoke subcommands directly,
    not the wizard, so they get the proper exit codes via that path).

    The command functions are passed in so we don't import cli at module
    load time (circular dependency) and so tests can swap them out.
    """
    mgr = ClaudeCodeManager()
    store = StateStore()

    while True:
        _print_state_summary(mgr, store)

        action = _prompt_main_action()
        if action is None or action == "exit":
            raise typer.Exit(code=0)

        try:
            if action == "install":
                run_install_wizard(install_fn, store)
            elif action == "configure":
                run_configure_menu(store)
            elif action == "uninstall":
                run_uninstall_wizard(uninstall_fn, store)
            elif action == "status":
                status_fn()
            elif action == "doctor":
                doctor_fn()
            elif action == "language":
                _run_language_picker()
        except typer.Exit:
            # Sub-action exited — don't propagate. Loop back to main menu
            # so the user can pick something else (incl. Exit explicitly).
            pass

        _console.print()  # spacer before re-rendering the state summary


def _run_language_picker() -> None:
    """Show the language menu, persist the choice, then re-enter the
    main panel so the user immediately sees the new language."""
    from .i18n import current_language
    chosen = _prompt_language()
    if chosen is None:
        return  # Ctrl-C — leave language as-is
    set_language(chosen)
    # Confirmation in the *new* language
    pretty = next(
        (display for code, display in available_languages() if code == chosen),
        chosen,
    )
    _console.print(f"[green]✓[/] {t().language_changed.format(lang=pretty)}")


def run_install_wizard(
    install_fn: InstallFn,
    store: StateStore,
) -> None:
    """One-confirm install wizard driven by saved defaults.

    Reads defaults from state.yaml, shows a summary, asks for a single
    confirmation. All field editing happens in the separate Configure
    menu — this function never prompts for individual values.

    If hub_url is set but hub_token is missing, or sidecar is enabled
    but hub is not configured, the summary surfaces a clear warning
    with a hint to go to Configure first.
    """
    from .sidecar import read_hub_token

    s = t()
    defaults = store.get_defaults()
    hub_token = read_hub_token()  # ~/.cc-guard/hub-token (0600)

    # ── Summary ──
    _console.print()
    _console.print(f"[bold]{s.install_summary_title}[/]")
    _console.print()
    _console.print(s.install_summary_listen.format(url=f"[cyan]{defaults.listen_url}[/]"))

    if defaults.sidecar_enabled:
        _console.print(f"[green]{s.install_summary_sidecar_on}[/]")
    else:
        _console.print(f"[dim]{s.install_summary_sidecar_off}[/]")

    has_hub = bool(defaults.hub_url)
    if has_hub:
        _console.print(s.install_summary_hub_set.format(url=f"[cyan]{defaults.hub_url}[/]"))
        _console.print(f"[green]{s.install_summary_mode_remote}[/]")
    else:
        _console.print(f"[yellow]{s.install_summary_hub_unset}[/]")
        _console.print(f"[yellow]{s.install_summary_mode_local}[/]")

    if defaults.api_timeout_ms:
        _console.print(s.install_summary_timeout.format(ms=defaults.api_timeout_ms))
    else:
        _console.print(f"[dim]{s.install_summary_no_timeout}[/]")
    _console.print()

    # ── Pre-flight checks ──
    if has_hub and not hub_token:
        _console.print(f"[red]{s.install_prompt_hub_token_missing}[/]")
        _console.print()
        raise typer.Exit(code=_ABORT)

    if not has_hub and defaults.sidecar_enabled:
        _console.print(f"[yellow]{s.install_hint_no_hub}[/]")
        _console.print()
        confirm = _prompt_proceed_no_hub()
    else:
        confirm = _prompt_proceed()

    if not confirm:
        _console.print(f"[yellow]{s.cancelled}[/]")
        raise typer.Exit(code=_ABORT)

    # ── Build args and call install_fn ──
    upstream = defaults.listen_url
    api_timeout = defaults.api_timeout_ms

    sidecar_settings: SidecarSettings | None = None
    if defaults.sidecar_enabled:
        sidecar_settings = SidecarSettings(
            listen=upstream,
            upstream="https://api.anthropic.com",
            hub_url=defaults.hub_url,
            hub_token=hub_token,
        )

    install_fn(upstream, api_timeout, sidecar_settings, None)


def _prompt_proceed() -> bool | None:
    return questionary.confirm(t().install_prompt_proceed, default=True).ask()


def _prompt_proceed_no_hub() -> bool | None:
    return questionary.confirm(
        t().install_prompt_proceed_no_hub, default=False,
    ).ask()


# ── Configure menu ─────────────────────────────────────────

def run_configure_menu(store: StateStore) -> None:
    """Loop-based configure menu for editing wizard defaults.

    Each field edit persists immediately to state.yaml (via
    `store.set_defaults()`), so the user can Ctrl-C at any point
    without losing earlier edits.
    """
    from .sidecar import read_hub_token, remove_hub_token, write_hub_token

    while True:
        s = t()
        defaults = store.get_defaults()
        hub_token = read_hub_token()

        hub_url_display = defaults.hub_url or f"[yellow]{s.configure_value_unset} ⚠[/]"
        hub_token_display = (
            f"[green]{s.configure_value_set}[/]"
            if hub_token
            else f"[yellow]{s.configure_value_unset} ⚠[/]"
        )
        timeout_display = (
            f"{defaults.api_timeout_ms} ms"
            if defaults.api_timeout_ms
            else s.configure_value_unset
        )
        sidecar_display = (
            s.configure_edit_sidecar_on.split(" — ")[0]
            if defaults.sidecar_enabled
            else s.configure_edit_sidecar_off.split(" — ")[0]
        )

        _console.print()
        choice = questionary.select(
            s.configure_prompt,
            choices=[
                questionary.Choice(
                    s.configure_hub_url.format(value=hub_url_display),
                    value="hub_url",
                ),
                questionary.Choice(
                    s.configure_hub_token.format(value=hub_token_display),
                    value="hub_token",
                ),
                questionary.Choice(
                    s.configure_listen.format(value=defaults.listen_url),
                    value="listen_url",
                ),
                questionary.Choice(
                    s.configure_api_timeout.format(value=timeout_display),
                    value="api_timeout",
                ),
                questionary.Choice(
                    s.configure_sidecar.format(value=sidecar_display),
                    value="sidecar",
                ),
                questionary.Choice(s.configure_reset, value="reset"),
                questionary.Choice(s.configure_back, value="back"),
            ],
        ).ask()

        if choice is None or choice == "back":
            return

        if choice == "reset":
            from .state import Defaults
            store.set_defaults(Defaults.factory())
            remove_hub_token()
            _console.print(f"[green]✓[/] {s.configure_reset_done}")
            continue

        if choice == "hub_url":
            val = questionary.text(
                s.configure_edit_hub_url,
                default=defaults.hub_url or "",
                validate=lambda v: (
                    True
                    if not v or v.startswith("http://") or v.startswith("https://")
                    else "URL must start with http:// or https://"
                ),
            ).ask()
            if val is not None:
                defaults.hub_url = val or None
                store.set_defaults(defaults)
                _console.print(f"[green]✓[/] {s.configure_saved}")

        elif choice == "hub_token":
            val = questionary.password(s.configure_edit_hub_token).ask()
            if val is not None:
                if val:
                    write_hub_token(val)
                    _console.print(f"[green]✓[/] {s.configure_token_saved}")
                else:
                    remove_hub_token()
                    _console.print(f"[green]✓[/] {s.configure_token_cleared}")

        elif choice == "listen_url":
            val = questionary.text(
                s.configure_edit_listen,
                default=defaults.listen_url,
                validate=lambda v: (
                    True
                    if v.startswith("http://") or v.startswith("https://")
                    else "URL must start with http:// or https://"
                ),
            ).ask()
            if val is not None and val:
                defaults.listen_url = val
                store.set_defaults(defaults)
                _console.print(f"[green]✓[/] {s.configure_saved}")

        elif choice == "api_timeout":
            val = questionary.text(
                s.configure_edit_api_timeout,
                default=str(defaults.api_timeout_ms or 0),
                validate=lambda v: (
                    True if v.isdigit() else "must be a non-negative integer"
                ),
            ).ask()
            if val is not None:
                defaults.api_timeout_ms = int(val) or None
                store.set_defaults(defaults)
                _console.print(f"[green]✓[/] {s.configure_saved}")

        elif choice == "sidecar":
            val = questionary.select(
                s.configure_edit_sidecar,
                choices=[
                    questionary.Choice(s.configure_edit_sidecar_on, value=True),
                    questionary.Choice(s.configure_edit_sidecar_off, value=False),
                ],
                default=s.configure_edit_sidecar_on if defaults.sidecar_enabled else s.configure_edit_sidecar_off,
            ).ask()
            if val is not None:
                defaults.sidecar_enabled = val
                store.set_defaults(defaults)
                _console.print(f"[green]✓[/] {s.configure_saved}")


def run_uninstall_wizard(
    uninstall_fn: Callable[[bool], None],
    store: StateStore,
) -> None:
    """Confirm uninstall (show current record) and ask about shell rc."""
    s = t()
    record = store.get("claude-code")
    if record is None:
        _console.print(f"[yellow]{s.uninstall_not_installed}[/]")
        raise typer.Exit(code=2)

    _console.print()
    _console.print(s.uninstall_current.format(url=f"[cyan]{record.upstream}[/]"))
    if record.backup_base_url:
        _console.print(s.uninstall_will_restore.format(url=f"[cyan]{record.backup_base_url}[/]"))
    else:
        _console.print(f"[dim]{s.uninstall_will_remove}[/]")

    restore_rc = True
    if record.shell_rc_changes:
        _console.print()
        for change in record.shell_rc_changes:
            _console.print(
                s.uninstall_shell_rc_info.format(
                    path=change.path, n=change.removed_line_count
                )
            )
        answer = _prompt_restore_shell_rc()
        if answer is None:
            _console.print(f"[yellow]{t().cancelled}[/]")
            raise typer.Exit(code=_ABORT)
        restore_rc = answer

    _console.print()
    confirm = _prompt_proceed()
    if not confirm:
        _console.print(f"[yellow]{t().cancelled}[/]")
        raise typer.Exit(code=_ABORT)

    uninstall_fn(restore_rc)
