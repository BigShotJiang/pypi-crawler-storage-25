"""Platform-specific auto-start registration for the managed sidecar.

Generates a login-time service definition so the sidecar survives
reboots without the user having to remember `ccg start`.

Currently supported:
  - Linux: systemd user service (~/.config/systemd/user/)
  - macOS: launchd plist (~/Library/LaunchAgents/)
  - Windows: not yet (use Task Scheduler manually)

Design: the service runs `ccg start` as ExecStart. This reuses all of
cc-guard's existing logic (config resolution, hub token reading, pid file
writing, runner discovery). systemd tracks the forked sidecar via PIDFile.
"""

from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

_SERVICE_NAME = "cc-guard-sidecar"


# ── Linux: systemd user service ────────────────────────────

def _systemd_service_dir() -> Path:
    return Path.home() / ".config" / "systemd" / "user"


def _systemd_service_path() -> Path:
    return _systemd_service_dir() / f"{_SERVICE_NAME}.service"


def _find_ccg_path() -> str:
    """Find the absolute path of the ccg executable for the service file.
    Prefer cc-guardian, fall back to ccg, then cc-guard.
    """
    for name in ("cc-guardian", "ccg", "cc-guard"):
        path = shutil.which(name)
        if path:
            return path
    # Last resort: assume ~/.local/bin/ccg (uv tool default)
    return str(Path.home() / ".local" / "bin" / "ccg")


def _generate_systemd_unit() -> str:
    ccg = _find_ccg_path()
    pid_file = Path.home() / ".cc-guard" / "sidecar.pid"
    return f"""\
# Managed by cc-guard — regenerate with `ccg enable-autostart`.
[Unit]
Description=cc-guard sidecar — local security gateway for Claude Code
After=network-online.target
Wants=network-online.target

[Service]
Type=forking
PIDFile={pid_file}
ExecStart={ccg} start
ExecStop={ccg} stop
Restart=on-failure
RestartSec=10

[Install]
WantedBy=default.target
"""


def enable_autostart_linux() -> Path:
    """Write the systemd user service and enable it."""
    svc = _systemd_service_path()
    svc.parent.mkdir(parents=True, exist_ok=True)
    svc.write_text(_generate_systemd_unit())

    subprocess.run(
        ["systemctl", "--user", "daemon-reload"],
        check=True, capture_output=True,
    )
    subprocess.run(
        ["systemctl", "--user", "enable", _SERVICE_NAME],
        check=True, capture_output=True,
    )
    # Also enable lingering so user services start before login
    # (requires the user to have sudo or the admin to have enabled it)
    try:
        subprocess.run(
            ["loginctl", "enable-linger", os.getlogin()],
            check=True, capture_output=True, timeout=5,
        )
    except (subprocess.CalledProcessError, OSError, subprocess.TimeoutExpired):
        # Non-fatal: linger is nice-to-have for headless servers.
        # On desktop Linux the service starts at login anyway.
        pass

    return svc


def disable_autostart_linux() -> bool:
    """Stop and disable the systemd user service, remove the file."""
    svc = _systemd_service_path()
    if not svc.exists():
        return False

    try:
        subprocess.run(
            ["systemctl", "--user", "stop", _SERVICE_NAME],
            capture_output=True, timeout=10,
        )
    except (subprocess.CalledProcessError, OSError, subprocess.TimeoutExpired):
        pass

    try:
        subprocess.run(
            ["systemctl", "--user", "disable", _SERVICE_NAME],
            capture_output=True, timeout=10,
        )
    except (subprocess.CalledProcessError, OSError, subprocess.TimeoutExpired):
        pass

    svc.unlink(missing_ok=True)

    try:
        subprocess.run(
            ["systemctl", "--user", "daemon-reload"],
            capture_output=True, timeout=5,
        )
    except (subprocess.CalledProcessError, OSError, subprocess.TimeoutExpired):
        pass

    return True


def is_autostart_enabled_linux() -> bool:
    return _systemd_service_path().exists()


# ── macOS: launchd ─────────────────────────────────────────

def _launchd_plist_path() -> Path:
    return Path.home() / "Library" / "LaunchAgents" / "com.cc-guard.sidecar.plist"


def _generate_launchd_plist() -> str:
    ccg = _find_ccg_path()
    return f"""\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.cc-guard.sidecar</string>
    <key>ProgramArguments</key>
    <array>
        <string>{ccg}</string>
        <string>start</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <dict>
        <key>SuccessfulExit</key>
        <false/>
    </dict>
    <key>StandardOutPath</key>
    <string>{Path.home()}/.cc-guard/sidecar-launchd.out</string>
    <key>StandardErrorPath</key>
    <string>{Path.home()}/.cc-guard/sidecar-launchd.err</string>
</dict>
</plist>
"""


def enable_autostart_macos() -> Path:
    plist = _launchd_plist_path()
    plist.parent.mkdir(parents=True, exist_ok=True)
    plist.write_text(_generate_launchd_plist())
    subprocess.run(
        ["launchctl", "load", str(plist)],
        check=True, capture_output=True,
    )
    return plist


def disable_autostart_macos() -> bool:
    plist = _launchd_plist_path()
    if not plist.exists():
        return False
    try:
        subprocess.run(
            ["launchctl", "unload", str(plist)],
            capture_output=True, timeout=10,
        )
    except (subprocess.CalledProcessError, OSError, subprocess.TimeoutExpired):
        pass
    plist.unlink(missing_ok=True)
    return True


def is_autostart_enabled_macos() -> bool:
    return _launchd_plist_path().exists()


# ── Cross-platform dispatch ────────────────────────────────

import sys

def enable_autostart() -> Path:
    """Enable auto-start for the current platform. Returns the service file path."""
    if sys.platform == "linux":
        return enable_autostart_linux()
    elif sys.platform == "darwin":
        return enable_autostart_macos()
    else:
        raise RuntimeError(
            f"Auto-start is not yet supported on {sys.platform}. "
            "On Windows, use Task Scheduler to run `ccg start` at login."
        )


def disable_autostart() -> bool:
    """Disable auto-start. Returns True if it was enabled, False if not."""
    if sys.platform == "linux":
        return disable_autostart_linux()
    elif sys.platform == "darwin":
        return disable_autostart_macos()
    else:
        raise RuntimeError(f"Auto-start is not yet supported on {sys.platform}.")


def is_autostart_enabled() -> bool:
    """Check if auto-start is currently enabled."""
    if sys.platform == "linux":
        return is_autostart_enabled_linux()
    elif sys.platform == "darwin":
        return is_autostart_enabled_macos()
    return False
