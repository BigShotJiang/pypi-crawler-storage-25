"""State tracking for installed tools.

Records what we've done to the user's machine so uninstall can be
precise and so `status` / `doctor` have something to reference.

Stored at `~/.cc-guard/state.yaml` as a human-readable YAML file.
The schema is versioned so we can migrate if the format evolves.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import yaml

SCHEMA_VERSION = 1


def state_path() -> Path:
    """Resolve state file path at call time so tests can monkeypatch $HOME."""
    return Path.home() / ".cc-guard" / "state.yaml"


@dataclass
class ShellRcChange:
    """One shell rc file that was modified during install."""
    path: str                      # str (not Path) for yaml friendliness
    backup: str                    # absolute path to backup snapshot
    removed_line_count: int


@dataclass
class ManagedSidecar:
    """A sidecar subprocess that cc-guard launched via `install --hub/--upstream`.

    If this field is set on an InstallRecord, `uninstall` will also
    SIGTERM the process (identified by pid) and remove the generated
    config. If it's None, cc-guard did nothing with the sidecar and
    uninstall leaves any running proxy alone.
    """
    pid: int
    config_path: str               # path to the sidecar.yaml cc-guard generated
    listen: str                    # host:port (for display)
    started_at: str                # ISO 8601


@dataclass
class InstallRecord:
    """Everything needed to undo an install cleanly."""
    upstream: str
    installed_at: str              # ISO 8601 timestamp
    settings_backup: str           # absolute path to pre-install settings.json snapshot
    backup_base_url: str | None = None       # previous ANTHROPIC_BASE_URL if any
    api_timeout_ms: int | None = None        # only set if we injected one
    shell_rc_changes: list[ShellRcChange] = field(default_factory=list)
    sidecar: ManagedSidecar | None = None    # set iff cc-guard spawned a sidecar


# Hard-coded factory defaults — used when state.yaml has no `defaults`
# section yet (first-time wizard run). Picked to make the most-common
# "remote hub security gateway" setup come out right with minimum tweaks:
# the user only needs to fill Hub URL + token, everything else just works.
_FACTORY_LISTEN_URL = "http://127.0.0.1:25559"
_FACTORY_API_TIMEOUT_MS = 3_000_000          # 50 minutes — long Claude tasks
_FACTORY_SIDECAR_ENABLED = True              # spawn flowlens by default
_FACTORY_HUB_URL: str | None = None          # user must set this themselves


@dataclass
class Defaults:
    """User-configurable defaults the wizard reads when starting an install.

    Persisted at the top level of state.yaml so they survive
    install/uninstall cycles. The hub *token* is NOT stored here — it
    lives separately at ~/.cc-guard/hub-token (0600) for security; this
    struct only knows whether one is set or not via the sidecar module.

    The sidecar `mode` is **derived**, not stored: empty hub_url ->
    proxy mode, set hub_url -> sidecar mode. The user never picks the
    mode directly.
    """
    listen_url: str = _FACTORY_LISTEN_URL
    api_timeout_ms: int | None = _FACTORY_API_TIMEOUT_MS
    sidecar_enabled: bool = _FACTORY_SIDECAR_ENABLED
    hub_url: str | None = _FACTORY_HUB_URL

    @classmethod
    def factory(cls) -> "Defaults":
        """Reset-to-defaults helper. Same as `Defaults()` but explicit."""
        return cls()


class StateStore:
    """Thin wrapper around a YAML file holding InstallRecords keyed by tool name."""

    def __init__(self, path: Path | None = None):
        self.path = path if path is not None else state_path()

    # ── IO ───────────────────────────────────────────────────

    def _load_raw(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        return yaml.safe_load(self.path.read_text()) or {}

    def load(self) -> dict[str, InstallRecord]:
        """Parse state.yaml. Returns empty dict if file is missing or empty.

        Unknown top-level keys are ignored for forward-compatibility.
        Old entries with missing optional fields are filled with defaults.
        """
        raw = self._load_raw()
        installs = raw.get("installs") or {}
        records: dict[str, InstallRecord] = {}
        for tool, entry in installs.items():
            records[tool] = _record_from_dict(entry)
        return records

    def get_last_upstream(self) -> str | None:
        """Remembered upstream URL from the most recent install.

        Survives uninstall — used by the install wizard as a default so
        users can press Enter to reuse their last choice.
        """
        raw = self._load_raw()
        value = raw.get("last_upstream")
        return value if isinstance(value, str) and value else None

    def get_language(self) -> str | None:
        """User's persisted UI language ('en' / 'zh' / None).

        None means "no explicit choice yet" — i18n module will then fall
        back to auto-detection from $LANG.
        """
        raw = self._load_raw()
        value = raw.get("language")
        return value if isinstance(value, str) and value else None

    def set_language(self, lang: str) -> None:
        """Persist a UI language choice. Survives install/uninstall."""
        records = self.load()
        # Re-use save() so we don't duplicate the YAML write logic
        self.save(records, language=lang)

    def get_defaults(self) -> Defaults:
        """Return user's persisted wizard defaults, or factory defaults
        when none have been saved yet.

        Tolerant deserialization: missing fields fall back to factory
        values, unknown fields are ignored. This means schema additions
        don't break old state.yaml files.
        """
        raw = self._load_raw()
        data = raw.get("defaults") or {}
        if not isinstance(data, dict):
            return Defaults()
        return Defaults(
            listen_url=data.get("listen_url", _FACTORY_LISTEN_URL),
            api_timeout_ms=(
                data["api_timeout_ms"]
                if "api_timeout_ms" in data
                else _FACTORY_API_TIMEOUT_MS
            ),
            sidecar_enabled=data.get("sidecar_enabled", _FACTORY_SIDECAR_ENABLED),
            hub_url=data.get("hub_url", _FACTORY_HUB_URL),
        )

    def set_defaults(self, defaults: Defaults) -> None:
        """Persist wizard defaults. Survives install/uninstall."""
        records = self.load()
        self.save(records, defaults=defaults)

    def save(
        self,
        records: dict[str, InstallRecord],
        *,
        last_upstream: str | None = None,
        language: str | None = None,
        defaults: Defaults | None = None,
    ) -> None:
        """Persist records. Creates parent directory if needed.

        `last_upstream`, `language`, and `defaults` are preserved across
        uninstalls. Pass None to keep whatever was there; pass a new
        value to update it.
        """
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload: dict[str, Any] = {
            "version": SCHEMA_VERSION,
            "installs": {
                tool: _record_to_dict(rec)
                for tool, rec in records.items()
            },
        }
        # Preserve existing top-level keys unless caller overrides them
        preserved_upstream = self.get_last_upstream()
        if last_upstream is not None:
            payload["last_upstream"] = last_upstream
        elif preserved_upstream is not None:
            payload["last_upstream"] = preserved_upstream

        preserved_lang = self.get_language()
        if language is not None:
            payload["language"] = language
        elif preserved_lang is not None:
            payload["language"] = preserved_lang

        if defaults is not None:
            payload["defaults"] = asdict(defaults)
        else:
            # Read-then-write: preserve existing defaults dict from disk
            # if the caller didn't pass new ones, otherwise we'd lose
            # them on every install/uninstall (which calls save() too).
            raw = self._load_raw()
            existing_defaults = raw.get("defaults")
            if isinstance(existing_defaults, dict) and existing_defaults:
                payload["defaults"] = existing_defaults

        self.path.write_text(yaml.safe_dump(payload, sort_keys=False, allow_unicode=True))

    # ── Convenience mutators ────────────────────────────────

    def record_install(self, tool: str, record: InstallRecord) -> None:
        records = self.load()
        records[tool] = record
        # Remember this upstream so the wizard can default to it next time
        self.save(records, last_upstream=record.upstream)

    def remove_install(self, tool: str) -> InstallRecord | None:
        records = self.load()
        removed = records.pop(tool, None)
        self.save(records)  # preserves last_upstream
        return removed

    def get(self, tool: str) -> InstallRecord | None:
        return self.load().get(tool)

    def is_installed(self, tool: str) -> bool:
        return tool in self.load()


# ── Helpers ──────────────────────────────────────────────────

def _record_to_dict(rec: InstallRecord) -> dict[str, Any]:
    """Serialize to a plain dict. Keep None fields so the YAML is explicit
    about what was and wasn't set at install time."""
    return asdict(rec)


def _record_from_dict(entry: dict[str, Any]) -> InstallRecord:
    """Tolerant deserialization: ignore unknown fields, fill missing
    optional fields with defaults."""
    known_fields = {
        "upstream",
        "installed_at",
        "settings_backup",
        "backup_base_url",
        "api_timeout_ms",
        "shell_rc_changes",
        "sidecar",
    }
    filtered = {k: v for k, v in entry.items() if k in known_fields}
    raw_changes = filtered.pop("shell_rc_changes", None) or []
    changes = [ShellRcChange(**c) for c in raw_changes]
    raw_sidecar = filtered.pop("sidecar", None)
    sidecar: ManagedSidecar | None = None
    if isinstance(raw_sidecar, dict):
        # Tolerate missing fields in case the schema evolves
        try:
            sidecar = ManagedSidecar(**{
                k: raw_sidecar[k]
                for k in ("pid", "config_path", "listen", "started_at")
                if k in raw_sidecar
            })
        except TypeError:
            sidecar = None
    return InstallRecord(
        shell_rc_changes=changes,
        sidecar=sidecar,
        **filtered,
    )
