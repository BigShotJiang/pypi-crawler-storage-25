"""Allow `python -m cc_guard` to invoke the CLI."""

from .cli import app


def main() -> None:
    app()


if __name__ == "__main__":
    main()
