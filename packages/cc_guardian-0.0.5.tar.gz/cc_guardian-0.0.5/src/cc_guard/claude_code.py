"""Claude Code settings.json install/uninstall.

The only file this module touches is `~/.claude/settings.json`. Shell rc
cleanup is handled separately in `shell_rc.py` — this module stays focused
on the JSON config so it's easy to test in isolation.

Design invariants:

1. `ANTHROPIC_AUTH_TOKEN` / `ANTHROPIC_API_KEY` are **never** touched.
2. Pre-existing `ANTHROPIC_BASE_URL` is stashed in
   `_CC_GUARD_BACKUP_BASE_URL` before we overwrite it.
3. `API_TIMEOUT_MS` is only written if explicitly requested, and only
   removed on uninstall if we know we wrote it (signalled via
   `had_api_timeout=True`).
4. Every write goes through `atomic_write_json` — partial writes can't
   corrupt the user's settings.
5. Install is idempotent: if the target URL is already in place, we
   short-circuit instead of creating a new backup.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from .backup import atomic_write_json, backup_file

# The field name we use to stash the pre-install value. Prefixed with
# underscore to signal "internal bookkeeping" to any human reading the
# settings file.
BACKUP_KEY = "_CC_GUARD_BACKUP_BASE_URL"
BASE_URL_KEY = "ANTHROPIC_BASE_URL"
API_TIMEOUT_KEY = "API_TIMEOUT_MS"


def settings_path() -> Path:
    """Resolve settings.json path at call time so tests can monkeypatch $HOME."""
    return Path.home() / ".claude" / "settings.json"


@dataclass
class InstallResult:
    """What happened during install. Enough info to build a user-facing diff."""
    upstream: str
    previous_base_url: str | None     # None means ANTHROPIC_BASE_URL wasn't set before
    api_timeout_injected: bool
    settings_backup_path: Path | None  # None if settings.json didn't exist pre-install
    already_installed: bool            # True if upstream was already set — no changes made


@dataclass
class UninstallResult:
    """What happened during uninstall. Enough info to build a user-facing diff."""
    restored_base_url: str | None     # None means we deleted the field entirely
    api_timeout_removed: bool
    settings_backup_path: Path


class ClaudeCodeManager:
    """Install/uninstall a proxy URL into Claude Code's settings.json."""

    def __init__(self, path: Path | None = None):
        self.path = path if path is not None else settings_path()

    # ── Read helpers ─────────────────────────────────────────

    def read(self) -> dict:
        """Parse settings.json. Returns empty dict if missing.

        Raises json.JSONDecodeError on malformed content — caller should
        catch and surface a friendly error.
        """
        if not self.path.exists():
            return {}
        text = self.path.read_text()
        if not text.strip():
            return {}
        return json.loads(text)

    def current_base_url(self) -> str | None:
        """Return the value of env.ANTHROPIC_BASE_URL, or None."""
        try:
            data = self.read()
        except json.JSONDecodeError:
            return None
        return (data.get("env") or {}).get(BASE_URL_KEY)

    # ── Core operations ──────────────────────────────────────

    def install(
        self,
        upstream: str,
        api_timeout_ms: int | None = None,
    ) -> InstallResult:
        """Point Claude Code at `upstream`.

        Idempotent: if settings.json already has `ANTHROPIC_BASE_URL == upstream`,
        we return `already_installed=True` without changing anything.

        If there's an existing value different from `upstream`, we back it
        up to `_CC_GUARD_BACKUP_BASE_URL` so uninstall can restore it.
        """
        # Preserve existing file permissions on re-writes
        existing_mode: int | None = None
        backup: Path | None = None
        if self.path.exists():
            existing_mode = self.path.stat().st_mode & 0o777

        data = self.read()
        env = data.get("env")
        if env is None:
            env = {}
            data["env"] = env

        existing_base = env.get(BASE_URL_KEY)

        # Idempotency: target already set and nothing else we need to change
        if existing_base == upstream and (
            api_timeout_ms is None or env.get(API_TIMEOUT_KEY) == str(api_timeout_ms)
        ):
            return InstallResult(
                upstream=upstream,
                previous_base_url=env.get(BACKUP_KEY),
                api_timeout_injected=False,
                settings_backup_path=None,
                already_installed=True,
            )

        # Back up the whole file before any change
        if self.path.exists():
            backup = backup_file(self.path)

        # Stash the previous base URL if it was set to something different
        previous_for_report: str | None = None
        if existing_base is not None and existing_base != upstream:
            # Don't overwrite an earlier backup — we want the _earliest_ value
            if BACKUP_KEY not in env:
                env[BACKUP_KEY] = existing_base
            previous_for_report = env[BACKUP_KEY]
        elif BACKUP_KEY in env:
            # No current value but an earlier backup exists — preserve it
            previous_for_report = env[BACKUP_KEY]

        env[BASE_URL_KEY] = upstream
        if api_timeout_ms is not None:
            env[API_TIMEOUT_KEY] = str(api_timeout_ms)

        atomic_write_json(self.path, data, mode=existing_mode)

        return InstallResult(
            upstream=upstream,
            previous_base_url=previous_for_report,
            api_timeout_injected=api_timeout_ms is not None,
            settings_backup_path=backup,
            already_installed=False,
        )

    def uninstall(self, had_api_timeout: bool = False) -> UninstallResult:
        """Undo an install, restoring pre-install state as precisely as possible.

        Args:
            had_api_timeout: True if install wrote API_TIMEOUT_MS. We only
                clear that field if we know we put it there — otherwise we
                might nuke something the user set themselves.
        """
        existing_mode: int | None = None
        if self.path.exists():
            existing_mode = self.path.stat().st_mode & 0o777
        backup = backup_file(self.path) if self.path.exists() else _noop_backup()

        data = self.read()
        env = data.get("env") or {}

        # Restore whatever base URL was there before our install
        restored = env.pop(BACKUP_KEY, None)
        if restored is not None:
            env[BASE_URL_KEY] = restored
        else:
            env.pop(BASE_URL_KEY, None)

        api_removed = False
        if had_api_timeout and API_TIMEOUT_KEY in env:
            env.pop(API_TIMEOUT_KEY)
            api_removed = True

        # Collapse an empty env dict so settings.json goes back to its
        # original shape if env was empty to begin with
        if not env and "env" in data:
            del data["env"]
        elif "env" in data:
            data["env"] = env

        atomic_write_json(self.path, data, mode=existing_mode)

        return UninstallResult(
            restored_base_url=restored,
            api_timeout_removed=api_removed,
            settings_backup_path=backup,
        )


def _noop_backup() -> Path:
    """Return a sentinel path used when settings.json didn't exist at uninstall
    time. Shouldn't normally happen — state.yaml would be out of sync — but
    we don't want uninstall to crash on an odd edge case."""
    return Path("/dev/null")
