"""Diagnostic checks — run by `cc-guard doctor`.

Each check returns a `Check` describing what was inspected, whether it
passed, and a human-readable message. The CLI layer renders these as a
checklist and picks an exit code based on the worst severity found.

Severity levels:
  - info:    informational, check passed
  - warning: check failed but the situation is recoverable / non-fatal
  - error:   something is actually broken
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path

import httpx

from .claude_code import BASE_URL_KEY, ClaudeCodeManager
from .shell_rc import detect_shell_rc, scan_for_base_url
from .state import StateStore


@dataclass
class Check:
    name: str
    passed: bool
    severity: str   # "info" | "warning" | "error"
    message: str
    hint: str | None = None    # optional actionable suggestion


def check_settings_file(mgr: ClaudeCodeManager) -> tuple[Check, dict | None]:
    """Parse ~/.claude/settings.json. Return (check, parsed_data_or_None)."""
    if not mgr.path.exists():
        return (
            Check(
                name="settings.json",
                passed=True,
                severity="info",
                message=f"{mgr.path} does not exist (Claude Code may not be installed)",
            ),
            None,
        )
    try:
        data = mgr.read()
        return (
            Check(
                name="settings.json",
                passed=True,
                severity="info",
                message=f"{mgr.path} is valid JSON",
            ),
            data,
        )
    except json.JSONDecodeError as e:
        return (
            Check(
                name="settings.json",
                passed=False,
                severity="error",
                message=f"{mgr.path} is not valid JSON: {e.msg}",
                hint="Restore the last backup from ~/.cc-guard/backup/ or fix manually",
            ),
            None,
        )


def check_base_url(data: dict | None) -> tuple[Check, str | None]:
    """Report whether ANTHROPIC_BASE_URL is currently set, and to what.

    Returns (check, current_base_url_or_None). This check is always
    informational — "not set" is a valid state.
    """
    if data is None:
        return (
            Check(
                name="base_url",
                passed=True,
                severity="info",
                message="env.ANTHROPIC_BASE_URL: (settings file missing)",
            ),
            None,
        )
    env = data.get("env") or {}
    base = env.get(BASE_URL_KEY)
    if base:
        return (
            Check(
                name="base_url",
                passed=True,
                severity="info",
                message=f"env.ANTHROPIC_BASE_URL = {base}",
            ),
            base,
        )
    return (
        Check(
            name="base_url",
            passed=True,
            severity="info",
            message="env.ANTHROPIC_BASE_URL not set (direct to official API)",
        ),
        None,
    )


def check_env_var_conflict(settings_base_url: str | None) -> Check:
    """Warn if the current shell environment exports ANTHROPIC_BASE_URL.

    This is subtler than the shell rc check because the shell env var is
    inherited by any child process Claude Code spawns from — it takes
    precedence over settings.json even if the rc file is "clean". This
    catches two scenarios:

      1. An rc file exported the var before we cleaned the rc file, so
         the current shell session still has it in its environment.
      2. The user exported it manually in this session (`export ...`).

    Unlike the shell rc check, we can't fix this — the user must
    `unset ANTHROPIC_BASE_URL` in their shell or open a new session. So
    we surface it as a warning with a clear remediation.
    """
    env_value = os.environ.get(BASE_URL_KEY)

    if env_value is None:
        return Check(
            name="env_override",
            passed=True,
            severity="info",
            message="no ANTHROPIC_BASE_URL in current shell environment",
        )

    if settings_base_url is None:
        return Check(
            name="env_override",
            passed=False,
            severity="warning",
            message=(
                f"shell env sets ANTHROPIC_BASE_URL={env_value} but "
                "settings.json does not — Claude Code will use the shell value"
            ),
            hint="Run `unset ANTHROPIC_BASE_URL` or open a new shell",
        )

    if env_value == settings_base_url:
        return Check(
            name="env_override",
            passed=True,
            severity="info",
            message=f"shell env ANTHROPIC_BASE_URL agrees with settings.json ({env_value})",
        )

    return Check(
        name="env_override",
        passed=False,
        severity="warning",
        message=(
            f"shell env ANTHROPIC_BASE_URL={env_value} overrides "
            f"settings.json's {settings_base_url}"
        ),
        hint="Run `unset ANTHROPIC_BASE_URL` or open a new shell to let settings.json take effect",
    )


def check_shell_rc_conflict() -> Check:
    """Warn if shell rc has an export that will override settings.json."""
    rc = detect_shell_rc()
    if rc is None:
        return Check(
            name="shell_rc",
            passed=True,
            severity="info",
            message="shell rc not applicable on this platform",
        )
    if not rc.exists():
        return Check(
            name="shell_rc",
            passed=True,
            severity="info",
            message=f"{rc} does not exist",
        )
    matches = scan_for_base_url(rc)
    if not matches:
        return Check(
            name="shell_rc",
            passed=True,
            severity="info",
            message=f"{rc} has no conflicting exports",
        )
    return Check(
        name="shell_rc",
        passed=False,
        severity="warning",
        message=(
            f"{rc} has {len(matches)} line(s) exporting ANTHROPIC_BASE_URL; "
            "these will OVERRIDE settings.json at runtime"
        ),
        hint=(
            f"Remove those lines from {rc}, or run `cc-guard install` "
            "which cleans them automatically (with backup)"
        ),
    )


def check_upstream_reachable(base_url: str | None, *, timeout: float = 2.0) -> Check:
    """Probe the configured upstream URL. Skipped if nothing is set."""
    if base_url is None:
        return Check(
            name="upstream",
            passed=True,
            severity="info",
            message="no upstream configured, nothing to probe",
        )
    try:
        # We don't care about the response status — anything that
        # completes the TCP+TLS handshake and returns an HTTP response
        # means something is listening. A 404 or 401 is fine.
        response = httpx.get(base_url, timeout=timeout)
        return Check(
            name="upstream",
            passed=True,
            severity="info",
            message=f"{base_url} reachable (HTTP {response.status_code})",
        )
    except httpx.HTTPError as e:
        return Check(
            name="upstream",
            passed=False,
            severity="warning",
            message=f"{base_url} not reachable: {type(e).__name__}",
            hint="Is your proxy running? Start it in another terminal.",
        )


def check_state_file(store: StateStore) -> Check:
    """Verify state.yaml is parseable (absent is fine)."""
    if not store.path.exists():
        return Check(
            name="state",
            passed=True,
            severity="info",
            message="state.yaml does not exist (nothing installed)",
        )
    try:
        store.load()
        return Check(
            name="state",
            passed=True,
            severity="info",
            message=f"{store.path} is valid",
        )
    except Exception as e:
        return Check(
            name="state",
            passed=False,
            severity="error",
            message=f"{store.path} is corrupted: {type(e).__name__}: {e}",
            hint="Delete state.yaml to reset (you may lose install records)",
        )


def run_all_checks(
    mgr: ClaudeCodeManager | None = None,
    store: StateStore | None = None,
    *,
    probe_upstream: bool = True,
    probe_timeout: float = 2.0,
) -> list[Check]:
    """Run every check and return the results in reporting order.

    `probe_upstream` can be disabled in tests to avoid network IO.
    """
    mgr = mgr if mgr is not None else ClaudeCodeManager()
    store = store if store is not None else StateStore()

    checks: list[Check] = []

    settings_check, data = check_settings_file(mgr)
    checks.append(settings_check)

    base_check, base_url = check_base_url(data)
    checks.append(base_check)

    checks.append(check_env_var_conflict(base_url))
    checks.append(check_shell_rc_conflict())

    if probe_upstream:
        checks.append(check_upstream_reachable(base_url, timeout=probe_timeout))
    else:
        checks.append(Check(
            name="upstream",
            passed=True,
            severity="info",
            message="upstream probe skipped",
        ))

    checks.append(check_state_file(store))

    return checks


def summarize(checks: list[Check]) -> tuple[int, int]:
    """Return (warning_count, error_count) for exit-code computation."""
    warnings = sum(1 for c in checks if c.severity == "warning")
    errors = sum(1 for c in checks if c.severity == "error")
    return warnings, errors
