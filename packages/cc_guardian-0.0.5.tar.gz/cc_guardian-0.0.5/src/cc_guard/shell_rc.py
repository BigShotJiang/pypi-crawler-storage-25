"""Shell rc file detection and line-level cleanup.

Problem we're solving: `ANTHROPIC_BASE_URL` set in a shell rc file
(`.bashrc` / `.zshrc` / `config.fish`) takes priority over anything in
`~/.claude/settings.json` because Claude Code inherits the user's
environment. If we only modify settings.json and leave the rc file
alone, our redirect silently doesn't work.

Strategy:
  1. Detect the active shell from `$SHELL`.
  2. Scan the corresponding rc file for lines that export
     `ANTHROPIC_BASE_URL`.
  3. If any are found, back up the whole rc file and remove just those
     lines (by line number, not regex-replace inside the line — that
     route leads to non-idempotent partial edits like chelper's).

Deliberately does NOT touch `ANTHROPIC_API_KEY` / `ANTHROPIC_AUTH_TOKEN`
— those are the user's own credentials and the proxy forwards them
untouched.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path

from .backup import backup_file


# Match `export ANTHROPIC_BASE_URL=...` (bash/zsh) with optional leading
# whitespace. Using `re.match` (anchor at start of line) so we don't
# accidentally match something inside a comment or string.
_BASH_ZSH_PATTERN = re.compile(r"^\s*export\s+ANTHROPIC_BASE_URL\s*=")

# Match fish's `set -gx ANTHROPIC_BASE_URL ...` / `set -x ...`
_FISH_PATTERN = re.compile(r"^\s*set\s+(-gx|-x|--global\s+--export|--export)\s+ANTHROPIC_BASE_URL(\s+|$)")


@dataclass
class RcMatch:
    """One matching line in a shell rc file."""
    line_number: int   # 1-based
    content: str       # full line content, no trailing newline


def detect_shell_rc() -> Path | None:
    """Return the current shell's rc file path based on `$SHELL`.

    On Windows, returns None (no shell rc concept in the native terminal).
    For unknown shells, falls back to `~/.profile` which is sourced by
    most POSIX login shells.
    """
    if os.name == "nt":
        return None

    shell_env = os.environ.get("SHELL", "")
    shell_name = Path(shell_env).name if shell_env else ""
    home = Path.home()

    if shell_name == "bash":
        return home / ".bashrc"
    if shell_name == "zsh":
        return home / ".zshrc"
    if shell_name == "fish":
        return home / ".config" / "fish" / "config.fish"
    # Fallback — covers dash, sh, ash, and anything else
    return home / ".profile"


def _is_fish_path(path: Path) -> bool:
    return path.suffix == ".fish" or "fish" in path.parts


def scan_for_base_url(path: Path) -> list[RcMatch]:
    """Return all line numbers where `ANTHROPIC_BASE_URL` is exported.

    Returns an empty list if the file doesn't exist, is empty, or has
    no matches. Line numbers are 1-based to match editor convention.
    """
    if not path.exists():
        return []

    pattern = _FISH_PATTERN if _is_fish_path(path) else _BASH_ZSH_PATTERN
    text = path.read_text()
    matches: list[RcMatch] = []
    for i, line in enumerate(text.splitlines(), start=1):
        # Ignore comments — user may have commented out an old export
        # and we shouldn't touch those
        stripped = line.lstrip()
        if stripped.startswith("#"):
            continue
        if pattern.match(line):
            matches.append(RcMatch(line_number=i, content=line))
    return matches


def remove_lines(path: Path, line_numbers: set[int]) -> Path:
    """Remove the given 1-based line numbers from `path`.

    Backs up the whole file first (to `~/.cc-guard/backup/`) and
    returns the backup path. Writes atomically via a temp file + rename,
    same strategy as `atomic_write_json`.
    """
    if not path.exists():
        raise FileNotFoundError(f"{path} does not exist")

    backup = backup_file(path)
    # Read as list of lines, preserving trailing newlines so we can
    # reconstruct the file byte-for-byte minus the removed lines
    lines = path.read_text().splitlines(keepends=True)
    kept = [line for i, line in enumerate(lines, start=1) if i not in line_numbers]

    tmp = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
    try:
        tmp.write_text("".join(kept))
        os.replace(tmp, path)
    except Exception:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass
        raise

    return backup


def restore_from_backup(rc_path: Path, backup_path: Path) -> None:
    """Copy `backup_path` back over `rc_path`. Used by uninstall when the
    user passes `--restore-shell-rc`."""
    if not backup_path.exists():
        raise FileNotFoundError(f"backup {backup_path} not found")
    rc_path.write_bytes(backup_path.read_bytes())
