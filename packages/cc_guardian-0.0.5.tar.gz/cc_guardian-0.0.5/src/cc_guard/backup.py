"""File backup + atomic JSON write helpers.

Kept deliberately tiny — no cleverness beyond what's needed to avoid
corrupting ~/.claude/settings.json on interrupt or disk-full.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path


def backup_dir() -> Path:
    """Where backup snapshots live. Lazily resolves $HOME every call so
    tests can monkeypatch it via HOME env var."""
    return Path.home() / ".cc-guard" / "backup"


def backup_file(path: Path) -> Path:
    """Copy `path` to `~/.cc-guard/backup/<basename>.<unix_ts>`.

    Returns the backup path. The source file must exist — the caller is
    responsible for that check. Multiple backups of the same file within
    the same second get suffixed with a counter to stay unique.
    """
    dest_dir = backup_dir()
    dest_dir.mkdir(parents=True, exist_ok=True)
    ts = int(time.time())
    dest = dest_dir / f"{path.name}.{ts}"
    # Handle same-second collisions deterministically
    counter = 0
    while dest.exists():
        counter += 1
        dest = dest_dir / f"{path.name}.{ts}.{counter}"
    dest.write_bytes(path.read_bytes())
    return dest


def atomic_write_json(path: Path, data: dict, *, mode: int | None = None) -> None:
    """Write `data` to `path` as indented JSON, atomically.

    Strategy: write to `<path>.tmp.<pid>` then `os.replace()` to target.
    `os.replace` is atomic on POSIX and on Windows (Python docs). If the
    process dies mid-write, the original file is left untouched.

    If `mode` is given (octal file perms), apply it to the new file via
    chmod after rename, so existing permission restrictions survive.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
    payload = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
    try:
        tmp.write_text(payload)
        os.replace(tmp, path)
    except Exception:
        # Clean up the temp file if the rename never happened
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass
        raise
    if mode is not None:
        os.chmod(path, mode)
