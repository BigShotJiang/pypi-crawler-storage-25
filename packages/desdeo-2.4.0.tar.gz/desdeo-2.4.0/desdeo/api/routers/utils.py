"""A selection of utilities for handling routers and data therein.

NOTE: No routers should be defined in this file!
"""

from collections.abc import Iterable
from dataclasses import dataclass
from enum import StrEnum
from typing import Annotated

from fastapi import Depends, HTTPException, status
from sqlmodel import Session, select

from desdeo.api.db import get_session
from desdeo.api.models import (
    ENautilusStepRequest,
    InteractiveSessionDB,
    NautilusNavigatorInitRequest,
    NautilusNavigatorNavigateRequest,
    ProblemDB,
    RPMSolveRequest,
    StateDB,
    User,
    UserRole,
)
from desdeo.api.models.session import CreateSessionRequest
from desdeo.api.routers.user_authentication import get_current_user

RequestType = (
    RPMSolveRequest
    | ENautilusStepRequest
    | CreateSessionRequest
    | NautilusNavigatorInitRequest
    | NautilusNavigatorNavigateRequest
)


def fetch_problem_with_role_check(user: User, problem_id: int, session: Session) -> ProblemDB | None:
    """Fetch a ProblemDB by id, bypassing ownership for analysts and admins.

    Args:
        user (User): the requesting user.
        problem_id (int): id of the problem to fetch.
        session (Session): the database session.

    Returns:
        ProblemDB | None: the matching problem, or None if not found.
    """
    if user.role in (UserRole.analyst, UserRole.admin):
        statement = select(ProblemDB).where(ProblemDB.id == problem_id)
    else:
        statement = select(ProblemDB).where(
            ProblemDB.user_id == user.id,
            ProblemDB.id == problem_id,
        )
    return session.exec(statement).first()


def fetch_interactive_session_with_role_check(user: User, session_id: int, session: Session) -> InteractiveSessionDB:
    """Fetch an InteractiveSessionDB by id, bypassing ownership for analysts and admins.

    Args:
        user (User): the requesting user.
        session_id (int): id of the interactive session to fetch.
        session (Session): the database session.

    Raises:
        HTTPException: when the session is not found (or not owned by the user for non-analysts).

    Returns:
        InteractiveSessionDB: the matching session.
    """
    if user.role in (UserRole.analyst, UserRole.admin):
        statement = select(InteractiveSessionDB).where(InteractiveSessionDB.id == session_id)
    else:
        statement = select(InteractiveSessionDB).where(
            InteractiveSessionDB.id == session_id,
            InteractiveSessionDB.user_id == user.id,
        )
    result = session.exec(statement).first()
    if result is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Could not find interactive session with id={session_id}.",
        )
    return result


def fetch_interactive_session(
    user: User,
    session: Session,
    request: RequestType | None = None,
    session_id: int | None = None,
) -> InteractiveSessionDB | None:
    """Gets the desired instance of `InteractiveSessionDB`.

    Args:
        user (User): the user whose interactive sessions are to be queried.
        request (RequestType): the request with possibly information on which interactive session to query.
        session (Session): the database session (not to be confused with the interactive session) from
            which the interactive session should be queried.
        session_id (int): the id of a session

    Note:
        If no explicit `session_id` is given in `request`, this function will try to fetch the
        currently active interactive session for the `user`, e.g., with id `user.active_session_id`.
        If this is `None`, then the interactive session returned will be `None` as well.

    Raises:
        HTTPException: when an explicit interactive session is requested, but it is not found.

    Returns:
        InteractiveSessionDB | None: an interactive session DB model, or nothing.
    """
    # session_id param has highest priority
    actual_session_id = session_id or (getattr(request, "session_id", None) if request else None)

    if actual_session_id is not None:
        # specific interactive session id is given, try using that
        statement = select(InteractiveSessionDB).where(InteractiveSessionDB.id == actual_session_id)
        interactive_session = session.exec(statement).first()

        if interactive_session is None:
            # Raise if explicitly requested interactive session cannot be found
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Could not find interactive session with id={actual_session_id}.",
            )
    else:
        if user.active_session_id is None:
            return None
        # actual_session_id is None
        # try to use active session instead

        statement = select(InteractiveSessionDB).where(InteractiveSessionDB.id == user.active_session_id)
        interactive_session = session.exec(statement).first()

    # At this point interactive_session is either an instance of InteractiveSessionDB or None (which is fine)

    return interactive_session


def fetch_user_problem(user: User, request: RequestType, session: Session) -> ProblemDB | None:
    """Fetches a user's `ProblemDB` based on the id in the given request.

    Args:
        user (User): the user for which the problem is fetched.
        request (RequestType): request containing details of the problem to be fetched (`request.problem_id`).
        session (Session): the database session from which to fetch the problem.

    Raises:
        HTTPException: a problem with the given id (`request.problem_id`) could not be found (404).

    Returns:
        Problem: the instance of `ProblemDB` with the given id.
    """
    if request.problem_id is None:
        return None

    statement = select(ProblemDB).where(
        ProblemDB.user_id == user.id,
        ProblemDB.id == request.problem_id,
    )
    return session.exec(statement).first()


def fetch_parent_state(
    user: User,
    request: RequestType,
    session: Session,
    interactive_session: InteractiveSessionDB | None = None,
) -> StateDB | None:
    """Fetches the parent state, if an id is given, or if defined in the given interactive session.

    Determines the appropriate parent `StateDB` instance to associate with a new
    state or operation. It first checks whether the `request` explicitly
    provides a `parent_state_id`. If so, it attempts to retrieve the
    corresponding `StateDB` entry from the database. If no such id is provided,
    the function defaults to returning the most recently added state from the
    given `interactive_session`, if available. If neither source provides a
    parent state, `None` is returned.

    Args:
    user (User): the user for which the parent state is fetched.
    request (RequestType): request containing details about the parent state and optionally the
        interactive session.
    session (Session): the database session from which to fetch the parent state.
    interactive_session (InteractiveSessionDB | None, optional): the interactive session containing
        information about the parent state. Defaults to None.

    Raises:
    HTTPException: when `request.parent_state_id` is not `None` and a `StateDB` with this id cannot
        be found in the given database session.

    Returns:
        StateDB | None: if `request.parent_state_id` is given, returns the corresponding `StateDB`.
            If it is not given, returns the latest state defined in `interactive_session.states`.
            If both `request.parent_state_id` and `interactive_session` are `None`, then returns `None`.
    """
    if request.parent_state_id is None:
        # parent state is assumed to be the last sate added to the session.
        # if `interactive_session` is None, then parent state is set to None.
        return interactive_session.states[-1] if interactive_session and interactive_session.states else None

    # request.parent_state_id is not None
    statement = select(StateDB).where(StateDB.id == request.parent_state_id)
    parent_state = session.exec(statement).first()

    # this error is raised because if a parent_state_id is given, it is assumed that the
    # user wished to use that state explicitly as the parent.
    if parent_state is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Could not find state with id={request.parent_state_id}",
        )

    return parent_state


class ContextField(StrEnum):
    """Enum class to specify context fields."""

    PROBLEM = "problem_db"
    INTERACTIVE_SESSION = "interactive_session"
    PARENT_STATE = "parent_state"


@dataclass(frozen=True)
class SessionContext:
    """A generic context to be used in various endpoints."""

    user: User
    db_session: Session
    problem_db: ProblemDB | None = None
    interactive_session: InteractiveSessionDB | None = None
    parent_state: StateDB | None = None


class SessionContextGuard:
    """FastAPI dependency that builds a SessionContext and validates required fields.

    Use ``.post`` for POST endpoints (accepts a request body),
    ``.get`` for GET endpoints (path/query params only), and
    ``.delete`` for DELETE endpoints (path/query params only).

    Calling the guard directly (via ``__call__``) is not allowed and will
    raise an error immediately.
    """

    def __init__(self, require: Iterable[ContextField] | None = None):
        """Init method for the SessionContextGuard class.

        Args:
            require (Iterable[ContextField] | None, optional): fields that the guard will check
                are included in the request. Defaults to None.
        """
        self.require = set(require or [])

    def __call__(self, *args, **kwargs):
        """Direct invocation is not allowed. Use .post, .get, or .delete instead."""
        raise RuntimeError(
            "SessionContextGuard must not be called directly. "
            "Use Depends(SessionContextGuard(...).post), "
            "Depends(SessionContextGuard(...).get), or "
            "Depends(SessionContextGuard(...).delete) instead."
        )

    def post(
        self,
        user: Annotated[User, Depends(get_current_user)],
        db_session: Annotated[Session, Depends(get_session)],
        request: RequestType | None = None,
        problem_id: int | None = None,
    ) -> SessionContext:
        """Dependency for POST endpoints. Accepts a request body (RequestType)."""
        problem_db = None
        interactive_session = None
        parent_state = None

        if request is not None:
            if hasattr(request, "problem_id") and request.problem_id is not None:
                problem_db = fetch_problem_with_role_check(user, request.problem_id, db_session)

            if problem_db is None and problem_id is not None:
                problem_db = fetch_problem_with_role_check(user, problem_id, db_session)

            if hasattr(request, "interactive_session_id") or hasattr(request, "problem_id"):
                interactive_session = fetch_interactive_session(user, db_session, request)

            if hasattr(request, "parent_state_id") or hasattr(request, "problem_id"):
                parent_state = fetch_parent_state(
                    user,
                    request,
                    db_session,
                    interactive_session=interactive_session,
                )
        elif problem_id is not None:
            problem_db = fetch_problem_with_role_check(user, problem_id, db_session)

        context = SessionContext(
            user=user,
            db_session=db_session,
            problem_db=problem_db,
            interactive_session=interactive_session,
            parent_state=parent_state,
        )

        self._validate(context)
        return context

    def get(
        self,
        user: Annotated[User, Depends(get_current_user)],
        db_session: Annotated[Session, Depends(get_session)],
        problem_id: int | None = None,
        session_id: int | None = None,
    ) -> SessionContext:
        """Dependency for GET endpoints. No request body — only path/query params."""
        problem_db = None
        interactive_session = None

        if problem_id is not None:
            problem_db = fetch_problem_with_role_check(user, problem_id, db_session)

        if session_id is not None or (problem_id is not None):
            interactive_session = fetch_interactive_session(
                user,
                db_session,
                session_id=session_id,
            )

        context = SessionContext(
            user=user,
            db_session=db_session,
            problem_db=problem_db,
            interactive_session=interactive_session,
        )

        self._validate(context)
        return context

    def delete(
        self,
        user: Annotated[User, Depends(get_current_user)],
        db_session: Annotated[Session, Depends(get_session)],
        problem_id: int | None = None,
        session_id: int | None = None,
    ) -> SessionContext:
        """Dependency for DELETE endpoints. No request body — delegates to .get logic."""
        return self.get(user=user, db_session=db_session, problem_id=problem_id, session_id=session_id)

    def _validate(self, context: SessionContext) -> None:
        """Ensure required fields exist."""
        for field in self.require:
            if getattr(context, field.value) is None:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"{field} context missing.",
                )
