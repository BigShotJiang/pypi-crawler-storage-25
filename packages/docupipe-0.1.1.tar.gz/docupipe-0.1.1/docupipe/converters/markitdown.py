from __future__ import annotations

import logging
from pathlib import Path

from docupipe.converters import register_converter
from docupipe.converters.base import ConverterBase

logger = logging.getLogger(__name__)


@register_converter("markitdown")
class MarkitdownConverter(ConverterBase):
    name = "markitdown"

    def convert(self, file_path: Path, **kwargs) -> str:
        from markitdown import MarkItDown
        md = MarkItDown()
        result = md.convert(str(file_path), keep_data_uris=True)
        logger.debug("markitdown 转换完成: %s, 长度=%d", file_path.name, len(result.markdown))
        return result.markdown
