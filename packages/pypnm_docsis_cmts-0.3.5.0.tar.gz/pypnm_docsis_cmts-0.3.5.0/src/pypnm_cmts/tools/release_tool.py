# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Maurice Garcia

from __future__ import annotations

import argparse
import atexit
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Final

REPO_ROOT: Final[Path] = Path(__file__).resolve().parents[3]
VERSION_FILE_PATH: Final[Path]           = REPO_ROOT / "src" / "pypnm_cmts" / "version.py"
BUMP_SCRIPT_PATH: Final[Path]            = REPO_ROOT / "tools" / "support" / "bump_version.py"
PYPROJECT_FILE_PATH: Final[Path]         = REPO_ROOT / "pyproject.toml"
README_FILE_PATH: Final[Path]            = REPO_ROOT / "README.md"
DOCS_ROOT: Final[Path]                   = REPO_ROOT / "docs"
README_TAG_PATTERN: Final[re.Pattern[str]] = re.compile(r'TAG="v\d+\.\d+\.\d+\.\d+(?:-rc\d+)?"')
WORKFLOWS_DIR: Final[Path]               = REPO_ROOT / ".github" / "workflows"

VERSION_PART_SEPARATOR: Final[str]       = "."
EXPECTED_VERSION_PARTS: Final[int]       = 4

MAJOR_INDEX: Final[int]                  = 0
MINOR_INDEX: Final[int]                  = 1
MAINTENANCE_INDEX: Final[int]            = 2
BUILD_INDEX: Final[int]                  = 3
RC_SUFFIX_PREFIX: Final[str]             = "-rc"
RC_DEFAULT_NUMBER: Final[int]            = 1

REPORT_DIR_NAME: Final[str]              = "release-reports"
REPORT_FILE_PREFIX: Final[str]           = "release-report"
REPORT_SECTIONS: Final[list[str]]        = [
    "Docs",
    "Docker",
    "K8s",
    "FastAPI",
    "REST",
    "DOCSIS",
    "PNM",
    "PNM-Python",
    "Tools",
    "Install",
]
REPORT_HEADERS: Final[list[str]]         = ["Section", "Files Changed"]
INSTALL_PREFIXES: Final[list[str]]       = ["install.sh", "scripts/install", "deploy/"]
DOCKER_PREFIXES: Final[list[str]]        = ["docker/", "docker-compose", "docs/docker/"]
K8S_PREFIX: Final[str]                   = "docs/kubernetes/"
PYPNM_DOCSIS_DEPENDENCY_PREFIX: Final[str] = "pypnm-docsis"


SUMMARY: dict[str, str] = {}
RELEASE_LOG_DIR: Path | None = None


def _parse_version_parts(version: str) -> list[int]:
    _validate_version_string(version)
    return [int(part) for part in version.split(VERSION_PART_SEPARATOR)]


def _determine_bump_kind(current_version: str, new_version: str) -> str:
    current_parts = _parse_version_parts(current_version)
    new_parts = _parse_version_parts(new_version)
    if new_parts[MAJOR_INDEX] != current_parts[MAJOR_INDEX]:
        return "major"
    if new_parts[MINOR_INDEX] != current_parts[MINOR_INDEX]:
        return "minor"
    if new_parts[MAINTENANCE_INDEX] != current_parts[MAINTENANCE_INDEX]:
        return "maintenance"
    if new_parts[BUILD_INDEX] != current_parts[BUILD_INDEX]:
        return "build"
    return "none"


def _prompt_release_candidate(bump_kind: str) -> str:
    prompt = f"Is this a GA release for the {bump_kind} bump? [y/N]: "
    answer = input(prompt).strip().lower()
    if answer in ("y", "yes"):
        return ""

    rc_input = input(f"RC number (default {RC_DEFAULT_NUMBER}): ").strip()
    if not rc_input:
        rc_number = RC_DEFAULT_NUMBER
    elif rc_input.isdigit():
        rc_number = int(rc_input)
    else:
        print("ERROR: RC number must be a positive integer.", file=sys.stderr)
        sys.exit(1)

    if rc_number < RC_DEFAULT_NUMBER:
        print("ERROR: RC number must be at least 1.", file=sys.stderr)
        sys.exit(1)

    return f"{RC_SUFFIX_PREFIX}{rc_number}"


def _print_banner() -> None:
    banner_path = REPO_ROOT / "tools" / "banner.txt"
    if banner_path.is_file():
        print(banner_path.read_text(encoding="utf-8"))
        print()


def _init_release_logging() -> None:
    """Create a temporary directory for failed-command logs and announce it."""
    global RELEASE_LOG_DIR
    if RELEASE_LOG_DIR is None:
        logs_dir = REPO_ROOT / REPORT_DIR_NAME / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        RELEASE_LOG_DIR = Path(tempfile.mkdtemp(prefix="pypnm-release-logs-", dir=str(logs_dir)))
        print(f"[release] Command failures will be logged under: {RELEASE_LOG_DIR}")


def _sanitize_label(label: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "-", label.strip().lower())
    return safe or "cmd"


def _default_label(cmd: list[str]) -> str:
    return Path(cmd[0]).name


def _log_command_failure(label: str, result: subprocess.CompletedProcess[str]) -> None:
    if RELEASE_LOG_DIR is None:
        return
    safe_label = _sanitize_label(label)
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    log_path = RELEASE_LOG_DIR / f"{safe_label}-{timestamp}.log"
    stdout = result.stdout or ""
    stderr = result.stderr or ""
    log_path.write_text(
        f"$ {' '.join(result.args if isinstance(result.args, (list, tuple)) else [str(result.args)])}\n\n"
        f"STDOUT:\n{stdout}\n\nSTDERR:\n{stderr}\n",
        encoding="utf-8",
    )
    print(f"[release] {label} failed; see {log_path}")


def _run(
    cmd: list[str],
    check: bool = True,
    *,
    label: str | None = None,
    capture_output: bool = True,
) -> subprocess.CompletedProcess[str]:
    """Run a subprocess command, capturing output for logging on failure."""
    if capture_output:
        proc = subprocess.run(cmd, text=True, capture_output=True, check=False, cwd=REPO_ROOT)
    else:
        proc = subprocess.run(cmd, text=True, check=False, cwd=REPO_ROOT)

    if proc.returncode != 0:
        if capture_output:
            _log_command_failure(label or _default_label(cmd), proc)
        if check:
            raise subprocess.CalledProcessError(
                proc.returncode,
                cmd,
                output=proc.stdout,
                stderr=proc.stderr,
            )
    return proc


# Simple status printer with color for TTY output
def _colorize(text: str, color: str) -> str:
    if not sys.stdout.isatty():
        return text
    codes = {
        "green": "\033[32m",
        "red": "\033[31m",
        "yellow": "\033[33m",
        "reset": "\033[0m",
    }
    return f"{codes.get(color, '')}{text}{codes['reset']}"


def _format_state(state: str) -> str:
    match state.lower():
        case "pass":
            return _colorize("PASS", "green")
        case "fail":
            return _colorize("FAIL", "red")
        case "skip":
            return _colorize("SKIP", "yellow")
        case _:
            return state.upper()


def _print_status(label: str, state: str) -> None:
    SUMMARY[label] = state
    print(f"{_format_state(state)} {label}")


def _print_release_summary() -> None:
    if not SUMMARY:
        return
    print("\nRelease step summary:")
    for label, state in SUMMARY.items():
        print(f" {_format_state(state)} {label}")
    if RELEASE_LOG_DIR:
        print(f"Failure logs (if any) stored in: {RELEASE_LOG_DIR}")


atexit.register(_print_release_summary)


def _ensure_clean_worktree() -> None:
    """Ensure the git working tree has no uncommitted changes."""
    result = _run(["git", "status", "--porcelain"], check=False, label="git-status")
    output = (result.stdout or "").strip()
    if output:
        print("ERROR: Working tree is not clean. Commit or stash changes first.", file=sys.stderr)
        sys.exit(1)


def _get_head_commit() -> str:
    result = _run(["git", "rev-parse", "HEAD"], label="git-rev-parse")
    return result.stdout.strip()


def _get_previous_commit() -> str | None:
    result = _run(["git", "rev-parse", "HEAD~1"], check=False, label="git-rev-parse-prev")
    if result.returncode != 0:
        return None
    return result.stdout.strip()


def _get_current_branch() -> str:
    result = _run(["git", "rev-parse", "--abbrev-ref", "HEAD"], label="git-branch")
    return result.stdout.strip()


def _get_upstream_ref() -> str | None:
    result = _run(
        ["git", "rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"],
        check=False,
        label="git-upstream",
    )
    if result.returncode != 0:
        return None
    return result.stdout.strip()


def _list_pending_commits(upstream: str) -> list[str]:
    result = _run(["git", "rev-list", "--reverse", f"{upstream}..HEAD"], label="git-rev-list")
    commits = [line.strip() for line in (result.stdout or "").splitlines() if line.strip()]
    return commits


def _collect_commit_files(commit: str) -> list[str]:
    result = _run(["git", "show", "--pretty=format:", "--name-only", commit], label="git-show")
    paths = [line.strip() for line in (result.stdout or "").splitlines() if line.strip()]
    return paths


def _collect_range_files(range_spec: str) -> list[str]:
    result = _run(["git", "log", "--pretty=format:", "--name-only", range_spec], label="git-log-range")
    seen: set[str] = set()
    paths: list[str] = []
    for line in (result.stdout or "").splitlines():
        path = line.strip()
        if not path or path in seen:
            continue
        seen.add(path)
        paths.append(path)
    return paths


def _classify_path(path: str) -> str:
    normalized = path.replace("\\", "/").lower()
    if normalized.startswith(K8S_PREFIX):
        return "K8s"
    if any(normalized.startswith(prefix) for prefix in DOCKER_PREFIXES):
        return "Docker"
    if normalized.startswith("docs/") or normalized == "readme.md":
        return "Docs"
    if "fastapi" in normalized:
        return "FastAPI"
    if normalized.startswith("src/pypnm_cmts/api/routes/"):
        return "REST"
    if "/rest" in normalized or "rest_" in normalized or "rest-" in normalized:
        return "REST"
    if normalized.startswith("src/pypnm_cmts/") or normalized == "pyproject.toml":
        if normalized.startswith("src/pypnm_cmts/docsis/"):
            return "DOCSIS"
        if normalized.startswith("src/pypnm_cmts/pnm/"):
            return "PNM"
        return "PNM-Python"
    if normalized.startswith("tools/"):
        return "Tools"
    if any(normalized.startswith(prefix) for prefix in INSTALL_PREFIXES):
        return "Install"
    return "Other"


def _summarize_sections(paths: list[str]) -> dict[str, int]:
    counts = {section: 0 for section in REPORT_SECTIONS}
    counts["Other"] = 0
    for path in paths:
        section = _classify_path(path)
        if section in counts:
            counts[section] += 1
        else:
            counts["Other"] += 1
    return counts


def _render_table(counts: dict[str, int]) -> str:
    rows = [(section, str(counts.get(section, 0))) for section in REPORT_SECTIONS]
    if counts.get("Other", 0) > 0:
        rows.append(("Other", str(counts["Other"])))

    header_section, header_count = REPORT_HEADERS
    section_width = max(len(header_section), max(len(row[0]) for row in rows))
    count_width = max(len(header_count), max(len(row[1]) for row in rows))

    def line() -> str:
        return f"+{'-' * (section_width + 2)}+{'-' * (count_width + 2)}+"

    lines = [
        line(),
        f"| {header_section.ljust(section_width)} | {header_count.ljust(count_width)} |",
        line(),
    ]
    for section, count in rows:
        lines.append(f"| {section.ljust(section_width)} | {count.ljust(count_width)} |")
    lines.append(line())
    return "\n".join(lines)


def _render_markdown_table(counts: dict[str, int]) -> str:
    rows = [(section, str(counts.get(section, 0))) for section in REPORT_SECTIONS]
    if counts.get("Other", 0) > 0:
        rows.append(("Other", str(counts["Other"])))

    lines = [
        f"| {REPORT_HEADERS[0]} | {REPORT_HEADERS[1]} |",
        "| --- | --- |",
    ]
    for section, count in rows:
        lines.append(f"| {section} | {count} |")
    return "\n".join(lines)


def _read_workflow_name(path: Path) -> str:
    try:
        text = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return path.name

    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("name:"):
            return stripped.split(":", 1)[1].strip() or path.name

    return path.name


def _collect_workflows() -> list[tuple[str, str]]:
    if not WORKFLOWS_DIR.exists():
        return []

    workflows: list[tuple[str, str]] = [
        (_read_workflow_name(path), os.path.relpath(path, REPO_ROOT))
        for ext in ("*.yml", "*.yaml")
        for path in sorted(WORKFLOWS_DIR.glob(ext))
    ]
    return workflows


def _write_release_report(
    commit: str,
    version: str,
    tag_name: str,
    branch: str,
    report_mode: str,
    extra_sections: list[str] | None = None,
) -> Path:
    report_dir = REPO_ROOT / REPORT_DIR_NAME
    report_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    report_path = report_dir / f"{REPORT_FILE_PREFIX}-{version}-{timestamp}.md"
    files = _collect_commit_files(commit)
    sorted_files = sorted(files)
    counts = _summarize_sections(files)
    workflows = _collect_workflows()
    mode = report_mode

    lines = [
        f"# PyPNM-CMTS {mode} report",
        "",
        f"- Generated: {datetime.now().isoformat(timespec='seconds')}",
        f"- Branch: {branch}",
        f"- Source commit: `{commit}`",
        f"- Release version: `{version}`",
        f"- Release tag: `{tag_name}`",
        "",
        "## Workflows",
        "",
    ]
    if workflows:
        lines.extend(f"- `{name}` (`{path}`)" for name, path in workflows)
    else:
        lines.append("_No workflows found._")
    lines.extend(
        [
            "",
            "## Change summary (commit)",
            "",
            _render_markdown_table(counts),
            "",
            "## Files (commit)",
            "",
        ]
    )
    if sorted_files:
        lines.extend(f"- `{path}`" for path in sorted_files)
    else:
        lines.append("_No files detected._")
    lines.append("")
    if SUMMARY:
        lines.extend(
            [
                "## Release step summary",
                "",
            ]
        )
        for label, state in SUMMARY.items():
            lines.append(f"- {state.upper()} {label}")
        lines.append("")

    if RELEASE_LOG_DIR:
        log_files = sorted(RELEASE_LOG_DIR.glob("*.log"))
        log_dir_display = os.path.relpath(RELEASE_LOG_DIR, REPO_ROOT)
        lines.extend(
            [
                "## Failure logs",
                "",
                f"- [Release Log]({log_dir_display})",
            ]
        )
        if log_files:
            lines.extend(
                f"- [`{os.path.relpath(log_file, REPO_ROOT)}`]({os.path.relpath(log_file, REPO_ROOT)})"
                for log_file in log_files
            )
        else:
            lines.append("- _No failure logs generated._")
        lines.append("")
    if extra_sections:
        lines.extend(extra_sections)
        if lines[-1] != "":
            lines.append("")

    report_path.write_text("\n".join(lines), encoding="utf-8")
    return report_path


def _ensure_virtualenv() -> None:
    """Ensure release is running inside a virtual environment."""
    if os.environ.get("VIRTUAL_ENV"):
        return
    if getattr(sys, "base_prefix", sys.prefix) != sys.prefix:
        return
    setup_cmd = (
        f"{sys.executable} -m venv .venv && "
        ". .venv/bin/activate && "
        "pip install -e '.[dev]'"
    )
    print(
        "ERROR: Release must run inside a Python virtual environment. "
        "Activate the venv (or create one) before running tools/release/release.py.",
        file=sys.stderr,
    )
    print("Suggested setup (copy/paste):", file=sys.stderr)
    print(f"  {setup_cmd}", file=sys.stderr)
    sys.exit(1)


def _ensure_pytest_available() -> None:
    """Ensure pytest is importable in the current environment."""
    try:
        import pytest  # noqa: F401
    except ModuleNotFoundError:
        print(
            "ERROR: pytest is not installed in the active Python environment. "
            "Install dev dependencies in the venv before running the release.",
            file=sys.stderr,
        )
        sys.exit(1)


def _checkout_and_pull(branch: str) -> None:
    """Checkout the target branch and fast-forward pull from origin."""
    _run(["git", "checkout", branch], label="git-checkout")
    _run(["git", "pull", "--ff-only"], label="git-pull")


def _read_current_version() -> str:
    """Read the current __version__ value from the version file."""
    if not VERSION_FILE_PATH.exists():
        print(f"ERROR: Version file not found: {VERSION_FILE_PATH}", file=sys.stderr)
        sys.exit(1)

    text = VERSION_FILE_PATH.read_text(encoding="utf-8")
    prefix = '__version__: str = "'
    start_index = text.find(prefix)
    if start_index < 0:
        print(
            f"ERROR: Could not find __version__ assignment in {VERSION_FILE_PATH}.",
            file=sys.stderr,
        )
        sys.exit(1)

    start_index = start_index + len(prefix)
    end_index = text.find('"', start_index)
    if end_index < 0:
        print(
            f"ERROR: Unterminated __version__ string in {VERSION_FILE_PATH}.",
            file=sys.stderr,
        )
        sys.exit(1)

    return text[start_index:end_index]


def _read_pyproject_version() -> str:
    """Read the [project].version value from pyproject.toml."""
    if not PYPROJECT_FILE_PATH.exists():
        print(f"ERROR: pyproject.toml not found: {PYPROJECT_FILE_PATH}", file=sys.stderr)
        sys.exit(1)

    text = PYPROJECT_FILE_PATH.read_text(encoding="utf-8")
    lines = text.splitlines()
    in_project_section = False

    for line in lines:
        stripped = line.strip()
        if stripped == "[project]":
            in_project_section = True
            continue

        if in_project_section and stripped.startswith("[") and stripped.endswith("]"):
            break

        if in_project_section and stripped.startswith("version") and "=" in stripped and '"' in stripped:
            first_quote = line.find('"')
            second_quote = line.find('"', first_quote + 1)
            if first_quote == -1 or second_quote == -1:
                print(
                    f"ERROR: Malformed [project].version line in {PYPROJECT_FILE_PATH}: {line!r}",
                    file=sys.stderr,
                )
                sys.exit(1)
            return line[first_quote + 1 : second_quote]

    print(
        f"ERROR: Could not find [project].version in {PYPROJECT_FILE_PATH}.",
        file=sys.stderr,
    )
    sys.exit(1)


def _read_pyproject_pypnm_docsis_version() -> str:
    """Read pinned pypnm-docsis dependency version from [project].dependencies."""
    if not PYPROJECT_FILE_PATH.exists():
        print(f"ERROR: pyproject.toml not found: {PYPROJECT_FILE_PATH}", file=sys.stderr)
        sys.exit(1)

    text = PYPROJECT_FILE_PATH.read_text(encoding="utf-8")
    lines = text.splitlines()
    in_project_section = False
    in_dependencies = False

    for line in lines:
        stripped = line.strip()
        if stripped == "[project]":
            in_project_section = True
            continue

        if in_project_section and stripped.startswith("[") and stripped.endswith("]"):
            break

        if not in_project_section:
            continue

        if stripped.startswith("dependencies") and "[" in stripped:
            in_dependencies = True
            continue

        if in_dependencies:
            if stripped.startswith("]"):
                break
            if PYPNM_DOCSIS_DEPENDENCY_PREFIX not in stripped:
                continue
            match = re.search(r'"pypnm-docsis\s*(==)\s*([^"]+)"', stripped)
            if match is None:
                print(
                    "ERROR: pyproject.toml dependency for pypnm-docsis must be pinned with ==.",
                    file=sys.stderr,
                )
                sys.exit(1)
            return match.group(2).strip()

    print(
        "ERROR: Could not find pinned pypnm-docsis dependency in pyproject.toml [project].dependencies.",
        file=sys.stderr,
    )
    sys.exit(1)


def _read_installed_pypnm_docsis_version() -> str:
    """Read installed pypnm-docsis version from the active environment."""
    try:
        import pypnm
    except ModuleNotFoundError:
        print(
            "ERROR: pypnm-docsis is not installed in the active environment.",
            file=sys.stderr,
        )
        sys.exit(1)

    version = getattr(pypnm, "__version__", "")
    if not isinstance(version, str) or version.strip() == "":
        print(
            "ERROR: Unable to resolve installed pypnm-docsis version (__version__ missing).",
            file=sys.stderr,
        )
        sys.exit(1)
    return version.strip()


def _ensure_pypnm_docsis_dependency_match() -> None:
    """Abort release when installed pypnm-docsis does not match pinned pyproject version."""
    pinned_version = _read_pyproject_pypnm_docsis_version()
    installed_version = _read_installed_pypnm_docsis_version()
    if installed_version != pinned_version:
        print(
            "ERROR: pypnm-docsis version mismatch between active environment and pyproject.toml.",
            file=sys.stderr,
        )
        print(
            f"Active environment pypnm-docsis: {installed_version}",
            file=sys.stderr,
        )
        print(
            f"pyproject.toml pinned pypnm-docsis: {pinned_version}",
            file=sys.stderr,
        )
        print(
            "Fix the mismatch before releasing to avoid unintended dependency changes.",
            file=sys.stderr,
        )
        sys.exit(1)


def _validate_version_string(version: str) -> None:
    """Validate that the version string matches MAJOR.MINOR.MAINTENANCE.BUILD."""
    parts = version.split(VERSION_PART_SEPARATOR)
    if len(parts) != EXPECTED_VERSION_PARTS:
        print(
            f"ERROR: Version '{version}' has {len(parts)} parts, expected {EXPECTED_VERSION_PARTS}.",
            file=sys.stderr,
        )
        sys.exit(1)

    if not all(part.isdigit() for part in parts):
        print(
            f"ERROR: Invalid version '{version}'. Expected numeric MAJOR.MINOR.MAINTENANCE.BUILD.",
            file=sys.stderr,
        )
        sys.exit(1)


def _compute_next_version(current_version: str, mode: str) -> str:
    """Compute the next version string by incrementing the requested component."""
    _validate_version_string(current_version)
    parts_str = current_version.split(VERSION_PART_SEPARATOR)
    parts_int = [int(part) for part in parts_str]

    match mode:
        case "major":
            parts_int[MAJOR_INDEX]       = parts_int[MAJOR_INDEX] + 1
            parts_int[MINOR_INDEX]       = 0
            parts_int[MAINTENANCE_INDEX] = 0
            parts_int[BUILD_INDEX]       = 0
        case "minor":
            parts_int[MINOR_INDEX]       = parts_int[MINOR_INDEX] + 1
            parts_int[MAINTENANCE_INDEX] = 0
            parts_int[BUILD_INDEX]       = 0
        case "maintenance":
            parts_int[MAINTENANCE_INDEX] = parts_int[MAINTENANCE_INDEX] + 1
            parts_int[BUILD_INDEX]       = 0
        case "build":
            parts_int[BUILD_INDEX]       = parts_int[BUILD_INDEX] + 1
        case _:
            print(f"ERROR: Unsupported next mode '{mode}'.", file=sys.stderr)
            sys.exit(1)

    return VERSION_PART_SEPARATOR.join(str(part) for part in parts_int)


def _bump_version(new_version: str) -> None:
    """Invoke tools/bump_version.py to update the version string."""
    if not BUMP_SCRIPT_PATH.exists():
        print(f"ERROR: Version bump script not found: {BUMP_SCRIPT_PATH}", file=sys.stderr)
        sys.exit(1)

    _run([sys.executable, str(BUMP_SCRIPT_PATH), new_version], label="bump-version")


def _restore_previous_version(previous_version: str, tag_prefix: str) -> None:
    """Restore version files back to the previous version after a test release."""
    print(f"Restoring version files to {previous_version}...")
    _bump_version(previous_version)
    _update_readme_tag(f"{tag_prefix}{previous_version}")


def _update_readme_tag(new_tag: str) -> None:
    """Rewrite TAG placeholders to the new release tag in README and docs."""
    paths = [README_FILE_PATH]
    if DOCS_ROOT.exists():
        paths.extend([p for p in DOCS_ROOT.rglob("*.md") if p.is_file()])

    for path in paths:
        try:
            text = path.read_text(encoding="utf-8")
        except FileNotFoundError:
            continue

        updated_text, count = README_TAG_PATTERN.subn(f'TAG="{new_tag}"', text)
        if count == 0:
            continue

        path.write_text(updated_text, encoding="utf-8")
        print(f"Updated TAG placeholders in {path} to {new_tag}")


def _run_tests() -> None:
    """Run the test suite before finalizing the release."""
    _ensure_pytest_available()
    print("Running tests (pytest)...")
    result = _run([sys.executable, "-m", "pytest"], check=False, label="pytest")
    if result.returncode != 0:
        print("ERROR: pytest failed. Aborting release.", file=sys.stderr)
        _print_status("Tests", "fail")
        sys.exit(result.returncode)
    _print_status("Tests", "pass")


def _run_repo_hygiene_checks() -> None:
    """Run pre-release hygiene checks (secrets, MAC address scans, etc.)."""
    checks: list[tuple[str, list[str]]] = [
        ("Secret scan", ["./tools/security/scan-secrets.sh"]),
        ("Encrypted secret scan", [sys.executable, "./tools/security/scan-enc-secrets.py"]),
        ("MAC scan", ["./tools/security/scan-mac-addresses.py", "--fail-on-found"]),
    ]
    print("Running repository hygiene checks...")
    for label, cmd in checks:
        script_path = REPO_ROOT / cmd[0]
        if script_path.suffix in {".sh", ".py"} and not script_path.exists():
            print(f"{label}: {script_path} not found, skipping.")
            _print_status(label, "skip")
            continue
        result = _run(cmd, check=False, label=label)
        if result.returncode != 0:
            print(f"ERROR: {label} failed. Aborting release.", file=sys.stderr)
            _print_status(label, "fail")
            sys.exit(result.returncode)
        _print_status(label, "pass")


def _run_release_pretest() -> None:
    """Run the CI parity test runner before release."""
    if not (REPO_ROOT / "tools" / "release" / "test-runner.py").exists():
        print("ERROR: release test runner not found: tools/release/test-runner.py", file=sys.stderr)
        sys.exit(1)
    result = _run([sys.executable, str(REPO_ROOT / "tools" / "release" / "test-runner.py")], check=False, label="pretest")
    if result.returncode != 0:
        print("ERROR: pretest failed. Aborting release.", file=sys.stderr)
        _print_status("Pretest", "fail")
        sys.exit(result.returncode)
    _print_status("Pretest", "pass")


def _prime_sudo_session() -> None:
    """Run sudo -v once so later sudo invocations do not re-prompt."""
    if shutil.which("sudo") is None:
        return
    print("Priming sudo credentials (sudo -v)...")
    result = _run(["sudo", "-v"], check=False, label="sudo-validate", capture_output=False)
    if result.returncode != 0:
        print("ERROR: Unable to validate sudo credentials. Aborting release.", file=sys.stderr)
        _print_status("sudo-validate", "fail")
        sys.exit(result.returncode)
    _print_status("sudo-validate", "pass")


def _run_mkdocs_strict() -> None:
    """Build mkdocs site in strict mode to catch broken links before release."""
    if not (REPO_ROOT / "mkdocs.yml").exists():
        print("mkdocs.yml not found; skipping mkdocs strict build.")
        _print_status("MkDocs", "skip")
        return

    print("Building docs with mkdocs --strict ...")
    result = _run(["mkdocs", "build", "--strict"], check=False, label="mkdocs")
    if result.returncode != 0:
        print("ERROR: mkdocs build failed. Aborting release.", file=sys.stderr)
        _print_status("MkDocs", "fail")
        sys.exit(result.returncode)
    _print_status("MkDocs", "pass")


def _commit_version_bump(new_version: str) -> None:
    """Commit the version bump change (includes README/docs tag updates)."""
    add_paths = [
        str(VERSION_FILE_PATH),
        str(PYPROJECT_FILE_PATH),
        str(README_FILE_PATH),
    ]

    if DOCS_ROOT.exists():
        add_paths.append(str(DOCS_ROOT))

    _run(["git", "add", *add_paths], label="git-add")
    _run(["git", "commit", "-m", f"Release {new_version}"], label="git-commit")


def _create_tag(new_version: str, tag_prefix: str, tag_suffix: str = "") -> str:
    """Create an annotated git tag for the release."""
    tag_name = f"{tag_prefix}{new_version}{tag_suffix}"
    _run(["git", "tag", "-a", tag_name, "-m", f"Release {new_version}"], label="git-tag")
    return tag_name


def _push_branch_and_tag(branch: str, tag_name: str) -> None:
    """Push the branch and tag to the origin remote."""
    _run(["git", "push", "origin", branch], label="git-push-branch")
    _run(["git", "push", "origin", tag_name], label="git-push-tag")


def main() -> None:
    """Automate a release: bump version, run tests, commit, tag, and push.

    Typical flows
    -------------
    1) Let the script compute the next maintenance version:
       pypnm-cmts-release

    2) Let the script compute the next version by mode:
       pypnm-cmts-release --next minor
       pypnm-cmts-release --next major
       pypnm-cmts-release --next maintenance
       pypnm-cmts-release --next build

    3) Release an explicit version:
       pypnm-cmts-release --version 0.2.1.0

    4) Show what would happen without changing anything:
       pypnm-cmts-release --next maintenance --dry-run
       pypnm-cmts-release --dry-run
    """
    _print_banner()
    parser = argparse.ArgumentParser(
        description=(
            "Automate a PyPNM-CMTS release: compute or apply a version using tools/bump_version.py, "
            "run tests, commit, tag, and push."
        )
    )
    parser.add_argument(
        "--version",
        help="Explicit release version in MAJOR.MINOR.MAINTENANCE.BUILD format (e.g. 0.1.0.0).",
    )
    parser.add_argument(
        "--next",
        choices=["major", "minor", "maintenance", "build"],
        help="Compute the next version from the current one (default: maintenance if omitted).",
    )
    parser.add_argument(
        "--branch",
        default="main",
        help="Branch to release from (default: main). Use 'stable' when ready.",
    )
    parser.add_argument(
        "--tag-prefix",
        default="v",
        help="Prefix for git tag names (default: 'v', e.g. v0.1.0.0).",
    )
    parser.add_argument(
        "--skip-tests",
        action="store_true",
        help="Skip running pytest before committing and tagging.",
    )
    parser.add_argument(
        "--skip-pretest",
        action="store_true",
        help="Skip the release pretest runner prompt and execution.",
    )
    parser.add_argument(
        "--skip-docker-test",
        action="store_true",
        help="Skip local docker build/smoke preflight (tools/local/local_container_build.sh).",
    )
    parser.add_argument(
        "--skip-k8s-test",
        action="store_true",
        help="Skip local Kubernetes smoke test (tools/local/local_kubernetes_smoke.sh).",
    )
    parser.add_argument(
        "--test-release",
        action="store_true",
        help="Run locally without commit/tag/push, then restore the prior version.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show planned actions without modifying anything.",
    )
    parser.add_argument(
        "--last-commit-report",
        action="store_true",
        help="Generate a report for the previous commit only (no release actions).",
    )
    parser.add_argument(
        "--latest-commit-report",
        action="store_true",
        help="Generate a report for the current commit only (no release actions).",
    )

    args = parser.parse_args()
    explicit_version: str | None = args.version
    next_mode: str | None        = args.next
    branch: str                  = args.branch
    tag_prefix: str              = args.tag_prefix
    skip_tests: bool             = args.skip_tests
    skip_pretest: bool           = args.skip_pretest
    skip_docker: bool            = args.skip_docker_test
    skip_k8s: bool               = args.skip_k8s_test
    dry_run: bool                = args.dry_run
    test_release: bool           = args.test_release
    last_commit_report: bool     = args.last_commit_report
    latest_commit_report: bool   = args.latest_commit_report

    if last_commit_report and latest_commit_report:
        print("ERROR: --last-commit-report and --latest-commit-report cannot be used together.", file=sys.stderr)
        sys.exit(1)

    if last_commit_report or latest_commit_report:
        if explicit_version or next_mode or skip_tests or skip_docker or skip_k8s or dry_run or test_release:
            print("ERROR: Commit report modes cannot be combined with release options.", file=sys.stderr)
            sys.exit(1)

        current_branch = _get_current_branch()
        if branch != current_branch:
            print(
                f"ERROR: Commit report runs on the current branch ({current_branch}). "
                f"Checkout '{branch}' first or omit --branch.",
                file=sys.stderr,
            )
            sys.exit(1)

        target_commit = _get_previous_commit() if last_commit_report else _get_head_commit()
        if not target_commit:
            print("ERROR: Unable to resolve the requested commit for reporting.", file=sys.stderr)
            sys.exit(1)

        report_version = _read_current_version()
        report_mode = "last-commit" if last_commit_report else "latest-commit"
        report_tag = "n/a"

        pending_counts = None
        pending_count = 0
        pending_upstream = _get_upstream_ref()
        if pending_upstream:
            pending_commits = _list_pending_commits(pending_upstream)
            pending_count = len(pending_commits)
            if pending_count > 1:
                pending_files = _collect_range_files(f"{pending_upstream}..HEAD")
                pending_counts = _summarize_sections(pending_files)

        extra_sections: list[str] = []
        if pending_counts:
            extra_sections.extend(
                [
                    "## Change summary (pending commits ahead of upstream)",
                    "",
                    _render_markdown_table(pending_counts),
                    "",
                    f"- Pending commits: {pending_count}",
                    f"- Upstream: `{pending_upstream}`",
                    "",
                ]
            )

        report_path = _write_release_report(
            target_commit,
            report_version,
            report_tag,
            current_branch,
            report_mode,
            extra_sections=extra_sections or None,
        )

        counts = _summarize_sections(_collect_commit_files(target_commit))
        print("\nCommit change summary:")
        print(_render_table(counts))
        if pending_counts:
            print("\nPending commits summary (ahead of upstream):")
            print(_render_table(pending_counts))
            print(f"Pending commits: {pending_count}")
            print(f"Upstream: {pending_upstream}")
        print(f"Commit report saved to {report_path}")
        return

    current_version = _read_current_version()
    pyproject_version = _read_pyproject_version()

    if current_version != pyproject_version:
        print(
            "ERROR: Version mismatch between src/pypnm_cmts/version.py "
            f"({current_version}) and pyproject.toml [project].version "
            f"({pyproject_version}). Run tools/bump_version.py or fix manually.",
            file=sys.stderr,
        )
        sys.exit(1)

    _ensure_pypnm_docsis_dependency_match()

    if explicit_version is not None and next_mode is not None:
        print("ERROR: --version and --next cannot be used together.", file=sys.stderr)
        sys.exit(1)

    if explicit_version is not None:
        new_version = explicit_version
        _validate_version_string(new_version)
    else:
        mode = next_mode or "maintenance"
        new_version = _compute_next_version(current_version, mode)

    if new_version == current_version:
        print(f"No change: version is already {current_version}.")
        sys.exit(0)

    bump_kind = _determine_bump_kind(current_version, new_version)
    rc_suffix = ""
    release_tag = f"{tag_prefix}{new_version}"

    if dry_run:
        print("Dry run: the following actions would be performed:")
        print("  1) Ensure git working tree is clean")
        print(f"  2) Checkout branch '{branch}' and pull with --ff-only")
        print(f"  3) Update version {current_version} -> {new_version} via tools/bump_version.py")
        print(f"  4) Update README/docs TAG placeholders to {release_tag}")
        print("  5) Run repository hygiene checks (secrets/macs)")
        print("  6) Optionally run the release pretest runner (tools/release/test-runner.py)")
        if not skip_tests:
            print("  7) Run pytest")
        if not skip_docker:
            print("  8) Run local docker preflight (tools/local/local_container_build.sh --smoke)")
        if not skip_k8s:
            print("  9) Run local Kubernetes smoke test (tools/local/local_kubernetes_smoke.sh)")
        print(" 10) Build docs with mkdocs --strict")
        if test_release:
            print(" 11) Skip commit/tag/push (test-only)")
            print(f" 12) Restore version files back to {current_version}")
        else:
            print(f" 11) Commit version bump: 'Release {new_version}'")
            print(f" 12) Create annotated tag '{release_tag}'")
            print(f" 13) Push branch '{branch}' and tag to origin")
        if bump_kind in ("major", "minor", "maintenance"):
            print("Note: you will be prompted to confirm GA; otherwise an -rcX suffix is used.")
        sys.exit(0)

    _ensure_virtualenv()

    if explicit_version is None:
        print(f"Current version: {current_version}")
        print(f"Planned version bump: {current_version} -> {new_version}")
        answer = input("Proceed with release? [y/N]: ").strip().lower()
        if answer not in ("y", "yes"):
            print("Aborted: release was not confirmed.")
            sys.exit(1)

    if bump_kind in ("major", "minor", "maintenance"):
        rc_suffix = _prompt_release_candidate(bump_kind)
        release_tag = f"{tag_prefix}{new_version}{rc_suffix}"

    _init_release_logging()
    if not skip_docker or not skip_k8s:
        _prime_sudo_session()

    _ensure_clean_worktree()
    if not test_release:
        _checkout_and_pull(branch)

    report_commit = _get_head_commit()

    print(f"Bumping version: {current_version} -> {new_version}")
    _bump_version(new_version)
    _update_readme_tag(release_tag)

    _run_repo_hygiene_checks()

    if not skip_pretest:
        answer = input("Run release pretest runner (tools/release/test-runner.py)? [y/N]: ").strip().lower()
        if answer in ("y", "yes"):
            _run_release_pretest()
        else:
            _print_status("Pretest", "skip")
    else:
        _print_status("Pretest", "skip")

    if not skip_tests:
        _run_tests()
    else:
        _print_status("Tests", "skip")

    if not skip_docker:
        print("Running local docker preflight (tools/local/local_container_build.sh --smoke)...")
        cmd = ["./tools/local/local_container_build.sh", "--smoke"]
        result = _run(cmd, check=False, label="docker-smoke")
        if result.returncode != 0:
            err_text = (result.stderr or "") + "\n" + (result.stdout or "")
            if "permission denied" in err_text.lower():
                print("Docker preflight failed; retrying with sudo...")
                result = _run(["sudo"] + cmd, check=False, label="docker-smoke-sudo")
        if result.returncode != 0:
            print("ERROR: local docker preflight failed. Aborting release.", file=sys.stderr)
            print("If this is a Docker permission issue, add your user to the docker group and re-login:")
            print("  sudo usermod -aG docker $USER")
            _print_status("Docker preflight", "fail")
            sys.exit(result.returncode)
        _print_status("Docker preflight", "pass")
    else:
        _print_status("Docker preflight", "skip")

    if not skip_k8s:
        print("Running local Kubernetes smoke test (tools/local/local_kubernetes_smoke.sh)...")
        cmd = ["./tools/local/local_kubernetes_smoke.sh"]
        result = _run(cmd, check=False, label="k8s-smoke")
        if result.returncode != 0:
            err_text = (result.stderr or "") + "\n" + (result.stdout or "")
            if "permission denied" in err_text.lower():
                print("Kubernetes smoke test failed; retrying with sudo...")
                result = _run(["sudo"] + cmd, check=False, label="k8s-smoke-sudo")
        if result.returncode != 0:
            print("ERROR: local Kubernetes smoke test failed. Aborting release.", file=sys.stderr)
            err_text = (result.stderr or "") + "\n" + (result.stdout or "")
            if "missing required command: kind" in err_text.lower() or "missing required command: kubectl" in err_text.lower():
                print("Hint: install kind + kubectl with:")
                print("  ./tools/k8s/pypnm_kind_vm_bootstrap.sh")
                print("Also ensure Docker is running: sudo systemctl start docker")
            _print_status("Kubernetes smoke", "fail")
            sys.exit(result.returncode)
        _print_status("Kubernetes smoke", "pass")
    else:
        _print_status("Kubernetes smoke", "skip")

    _run_mkdocs_strict()

    if test_release:
        print("Skipping commit/tag/push (--test-release set).")
        _restore_previous_version(current_version, tag_prefix)
        _print_status("Commit", "skip")
        _print_status("Tag", "skip")
        _print_status("Push", "skip")
        return

    _commit_version_bump(new_version)
    tag_name = _create_tag(new_version, tag_prefix, rc_suffix)
    _push_branch_and_tag(branch, tag_name)

    _print_status("Release report", "pass")
    report_mode = "test-release" if test_release else "release"
    report_path = _write_release_report(report_commit, new_version, tag_name, branch, report_mode)
    counts = _summarize_sections(_collect_commit_files(report_commit))
    print("\nRelease change summary (last commit):")
    print(_render_table(counts))
    print(f"Release report saved to {report_path}")

    print(f"Release {new_version} completed on branch '{branch}' with tag '{tag_name}'.")


if __name__ == "__main__":
    main()
