use rayon::prelude::*;
use std::collections::HashSet;

/// Result of a bipartite soft matching operation (ToMe algorithm).
#[derive(Debug, Clone)]
pub struct MergeResult {
    /// Indices of tokens that are kept (unmerged + merge destinations).
    pub kept_indices: Vec<usize>,
    /// Source indices (tokens that got merged INTO a destination).
    pub merge_src: Vec<usize>,
    /// Destination indices (tokens that received merged information).
    pub merge_dst: Vec<usize>,
    /// Total output token count after merging.
    pub output_size: usize,
}

/// L2-normalize each row of a 2D embedding array in-place.
fn l2_normalize(embeddings: &[Vec<f64>]) -> Vec<Vec<f64>> {
    embeddings
        .par_iter()
        .map(|row| {
            let norm: f64 = row.iter().map(|&x| x * x).sum::<f64>().sqrt();
            if norm > 1e-12 {
                row.iter().map(|&x| x / norm).collect()
            } else {
                row.clone()
            }
        })
        .collect()
}

/// Compute dot product between two vectors.
#[inline]
fn dot(a: &[f64], b: &[f64]) -> f64 {
    a.iter().zip(b.iter()).map(|(&x, &y)| x * y).sum()
}

/// Token Merging via Bipartite Soft Matching.
///
/// Algorithm (from Meta's ToMe, ICLR 2023 Oral):
/// 1. L2-normalize all token embeddings
/// 2. Partition into set A (even indices) and set B (odd indices)
/// 3. For each token in A, find the most similar token in B (cosine similarity)
/// 4. Sort A tokens by their best match quality (descending)
/// 5. Top-r matches: merge source (A) into destination (B) via averaging
/// 6. Remaining A tokens and all B tokens are kept
///
/// Complexity: O(n_a × n_b × dim) for matching, O(n log n) for sorting
///
/// # Arguments
/// * `embeddings` - Token embeddings, shape [n_tokens, dim]
/// * `r` - Number of tokens to merge (remove). Max = (n - protect_first) / 2
/// * `protect_first` - Number of initial tokens to never merge (attention sinks)
pub fn bipartite_soft_matching(
    embeddings: &[Vec<f64>],
    r: usize,
    protect_first: usize,
) -> MergeResult {
    let n = embeddings.len();

    if n == 0 {
        return MergeResult {
            kept_indices: vec![],
            merge_src: vec![],
            merge_dst: vec![],
            output_size: 0,
        };
    }

    let pf = protect_first.min(n);
    let mergeable = n - pf;
    let r = r.min(mergeable / 2);

    if r == 0 {
        return MergeResult {
            kept_indices: (0..n).collect(),
            merge_src: vec![],
            merge_dst: vec![],
            output_size: n,
        };
    }

    // Step 1: L2 normalize
    let normed = l2_normalize(embeddings);

    // Step 2: Partition — A = even indices, B = odd indices (after protected)
    let a_indices: Vec<usize> = (pf..n).step_by(2).collect();
    let b_indices: Vec<usize> = ((pf + 1)..n).step_by(2).collect();

    if a_indices.is_empty() || b_indices.is_empty() {
        return MergeResult {
            kept_indices: (0..n).collect(),
            merge_src: vec![],
            merge_dst: vec![],
            output_size: n,
        };
    }

    // Step 3: For each A token, find most similar B token (parallel over A)
    let matches: Vec<(f64, usize)> = a_indices
        .par_iter()
        .map(|&a_idx| {
            let a_vec = &normed[a_idx];
            let mut best_score = f64::NEG_INFINITY;
            let mut best_b = 0usize;

            for (bi, &b_idx) in b_indices.iter().enumerate() {
                let score = dot(a_vec, &normed[b_idx]);
                if score > best_score {
                    best_score = score;
                    best_b = bi;
                }
            }

            (best_score, best_b)
        })
        .collect();

    // Step 4: Rank A tokens by match quality
    let mut ranked: Vec<(usize, f64, usize)> = a_indices
        .iter()
        .enumerate()
        .map(|(ai, &a_idx)| (a_idx, matches[ai].0, matches[ai].1))
        .collect();
    ranked.sort_unstable_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));

    // Step 5: Top-r become merge operations
    let merge_src: Vec<usize> = ranked[..r].iter().map(|&(a_idx, _, _)| a_idx).collect();
    let merge_dst: Vec<usize> = ranked[..r]
        .iter()
        .map(|&(_, _, b_match)| b_indices[b_match])
        .collect();

    // Step 6: Everything not merged is kept
    let merged_set: HashSet<usize> = merge_src.iter().copied().collect();
    let mut kept: Vec<usize> = (0..n).filter(|i| !merged_set.contains(i)).collect();
    kept.sort_unstable();

    MergeResult {
        kept_indices: kept,
        merge_src,
        merge_dst,
        output_size: n - r,
    }
}

/// Apply a merge result to token embeddings or any token-level features.
///
/// For each (src, dst) pair, the destination token becomes the
/// average of itself and the source token (weighted merge).
pub fn apply_merge(
    token_values: &[Vec<f64>],
    result: &MergeResult,
) -> Vec<Vec<f64>> {
    if token_values.is_empty() {
        return vec![];
    }

    let dim = token_values[0].len();

    // Start with copies of kept tokens
    let mut merged_map: std::collections::HashMap<usize, Vec<f64>> = result
        .kept_indices
        .iter()
        .map(|&idx| (idx, token_values[idx].clone()))
        .collect();

    // Apply merges: average src into dst
    for (&src, &dst) in result.merge_src.iter().zip(result.merge_dst.iter()) {
        if let Some(dst_vec) = merged_map.get_mut(&dst) {
            for d in 0..dim {
                dst_vec[d] = (dst_vec[d] + token_values[src][d]) / 2.0;
            }
        }
    }

    // Return in sorted order of kept_indices
    result
        .kept_indices
        .iter()
        .filter_map(|idx| merged_map.get(idx))
        .cloned()
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_embeddings(n: usize, dim: usize) -> Vec<Vec<f64>> {
        (0..n)
            .map(|i| (0..dim).map(|d| (i * dim + d) as f64).collect())
            .collect()
    }

    #[test]
    fn test_merge_zero_r() {
        let emb = make_embeddings(6, 4);
        let result = bipartite_soft_matching(&emb, 0, 0);
        assert_eq!(result.output_size, 6);
        assert_eq!(result.kept_indices, vec![0, 1, 2, 3, 4, 5]);
        assert!(result.merge_src.is_empty());
    }

    #[test]
    fn test_merge_basic() {
        let emb = make_embeddings(6, 4);
        let result = bipartite_soft_matching(&emb, 2, 0);
        assert_eq!(result.output_size, 4);
        assert_eq!(result.merge_src.len(), 2);
        assert_eq!(result.merge_dst.len(), 2);
        // Kept = 6 - 2 = 4
        assert_eq!(result.kept_indices.len(), 4);
    }

    #[test]
    fn test_merge_with_protection() {
        let emb = make_embeddings(6, 4);
        let result = bipartite_soft_matching(&emb, 2, 2);
        // With 2 protected, only 4 tokens are mergeable → max r = 2
        assert_eq!(result.output_size, 4);
        // Protected tokens must be in kept_indices
        assert!(result.kept_indices.contains(&0));
        assert!(result.kept_indices.contains(&1));
        // Merged sources must NOT be protected
        for &src in &result.merge_src {
            assert!(src >= 2);
        }
    }

    #[test]
    fn test_merge_similar_tokens() {
        // Create tokens where 0,1 are very similar and 2,3 are very similar
        let emb = vec![
            vec![1.0, 0.0, 0.0, 0.0],
            vec![1.0, 0.001, 0.0, 0.0], // Almost same as 0
            vec![0.0, 1.0, 0.0, 0.0],
            vec![0.0, 1.0, 0.001, 0.0], // Almost same as 2
        ];
        let result = bipartite_soft_matching(&emb, 1, 0);
        assert_eq!(result.output_size, 3);
        // The most similar pair should be merged
        assert_eq!(result.merge_src.len(), 1);
    }

    #[test]
    fn test_apply_merge() {
        let emb = vec![
            vec![1.0, 0.0],
            vec![3.0, 0.0],
            vec![2.0, 0.0],
            vec![4.0, 0.0],
        ];
        let result = MergeResult {
            kept_indices: vec![0, 1, 3],
            merge_src: vec![2],
            merge_dst: vec![3],
            output_size: 3,
        };
        let merged = apply_merge(&emb, &result);
        assert_eq!(merged.len(), 3);
        // Token 3 should be averaged with token 2: (4+2)/2 = 3.0
        assert!((merged[2][0] - 3.0).abs() < 1e-10);
    }

    #[test]
    fn test_l2_normalize() {
        let emb = vec![vec![3.0, 4.0]]; // norm = 5
        let normed = l2_normalize(&emb);
        assert!((normed[0][0] - 0.6).abs() < 1e-10);
        assert!((normed[0][1] - 0.8).abs() < 1e-10);
    }

    #[test]
    fn test_empty() {
        let emb: Vec<Vec<f64>> = vec![];
        let result = bipartite_soft_matching(&emb, 5, 0);
        assert_eq!(result.output_size, 0);
    }
}
