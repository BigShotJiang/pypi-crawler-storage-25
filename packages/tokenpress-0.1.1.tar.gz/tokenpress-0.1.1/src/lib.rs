use pyo3::prelude::*;

mod merge;
mod pipeline;
mod scorer;
mod selector;

/// TokenPress: Blazing-fast LLM token compression engine.
///
/// Reduce API costs by 2-5x with zero quality loss.
/// Built in Rust for maximum performance.
#[pymodule]
fn _core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add("__version__", "0.1.0")?;

    // ─── Scoring ───────────────────────────────────────────
    m.add_function(wrap_pyfunction!(py_score_self_information, m)?)?;
    m.add_function(wrap_pyfunction!(py_score_entropy, m)?)?;
    m.add_function(wrap_pyfunction!(py_score_perplexity, m)?)?;
    m.add_function(wrap_pyfunction!(py_batch_score_self_information, m)?)?;

    // ─── Selection ─────────────────────────────────────────
    m.add_function(wrap_pyfunction!(py_select_topk, m)?)?;
    m.add_function(wrap_pyfunction!(py_select_ratio, m)?)?;
    m.add_function(wrap_pyfunction!(py_select_threshold, m)?)?;
    m.add_function(wrap_pyfunction!(py_select_percentile, m)?)?;
    m.add_function(wrap_pyfunction!(py_select_iqr, m)?)?;

    // ─── Merging ───────────────────────────────────────────
    m.add_function(wrap_pyfunction!(py_bipartite_merge, m)?)?;
    m.add_function(wrap_pyfunction!(py_apply_merge, m)?)?;

    // ─── Pipeline ──────────────────────────────────────────
    m.add_function(wrap_pyfunction!(py_compress, m)?)?;
    m.add_function(wrap_pyfunction!(py_batch_compress, m)?)?;

    Ok(())
}

// ═══════════════════════════════════════════════════════════
// Scoring
// ═══════════════════════════════════════════════════════════

/// Compute self-information scores from log-probabilities.
///
/// I(x_i) = -log_prob(x_i) / ln(2)
///
/// Higher scores = more informative tokens (should be kept).
/// Input: list of log-probabilities (negative floats from a language model).
/// Returns: list of self-information scores (positive floats).
#[pyfunction]
fn py_score_self_information(log_probs: Vec<f64>) -> Vec<f64> {
    scorer::compute_self_information(&log_probs)
}

/// Compute entropy of next-token distributions.
///
/// Input: list of logit vectors, one per position.
/// Returns: entropy (nats) per position.
#[pyfunction]
fn py_score_entropy(logits_per_position: Vec<Vec<f64>>) -> Vec<f64> {
    scorer::compute_entropy(&logits_per_position)
}

/// Compute perplexity of a sequence.
///
/// PPL = exp(-1/N * sum(log_probs))
#[pyfunction]
fn py_score_perplexity(log_probs: Vec<f64>) -> f64 {
    scorer::compute_perplexity(&log_probs)
}

/// Batch compute self-information across multiple sequences (parallel).
#[pyfunction]
fn py_batch_score_self_information(batch: Vec<Vec<f64>>) -> Vec<Vec<f64>> {
    scorer::batch_compute_self_information(&batch)
}

// ═══════════════════════════════════════════════════════════
// Selection
// ═══════════════════════════════════════════════════════════

/// Keep the top-k tokens by importance score.
///
/// Returns sorted indices of tokens to keep.
#[pyfunction]
#[pyo3(signature = (scores, k, preserve_first=0, preserve_last=0))]
fn py_select_topk(
    scores: Vec<f64>,
    k: usize,
    preserve_first: usize,
    preserve_last: usize,
) -> Vec<usize> {
    selector::select_topk(&scores, k, preserve_first, preserve_last)
}

/// Keep a ratio of tokens (e.g., 0.3 = keep 30%).
///
/// Returns sorted indices of tokens to keep.
#[pyfunction]
#[pyo3(signature = (scores, ratio, preserve_first=0, preserve_last=0))]
fn py_select_ratio(
    scores: Vec<f64>,
    ratio: f64,
    preserve_first: usize,
    preserve_last: usize,
) -> Vec<usize> {
    selector::select_ratio(&scores, ratio, preserve_first, preserve_last)
}

/// Keep tokens with score >= threshold.
#[pyfunction]
#[pyo3(signature = (scores, threshold, preserve_first=0, preserve_last=0))]
fn py_select_threshold(
    scores: Vec<f64>,
    threshold: f64,
    preserve_first: usize,
    preserve_last: usize,
) -> Vec<usize> {
    selector::select_threshold(&scores, threshold, preserve_first, preserve_last)
}

/// Keep tokens above the given percentile.
#[pyfunction]
#[pyo3(signature = (scores, percentile, preserve_first=0, preserve_last=0))]
fn py_select_percentile(
    scores: Vec<f64>,
    percentile: f64,
    preserve_first: usize,
    preserve_last: usize,
) -> Vec<usize> {
    selector::select_percentile(&scores, percentile, preserve_first, preserve_last)
}

/// Adaptive selection using IQR method (from TRIM).
#[pyfunction]
#[pyo3(signature = (scores, factor=1.5, preserve_first=0, preserve_last=0))]
fn py_select_iqr(
    scores: Vec<f64>,
    factor: f64,
    preserve_first: usize,
    preserve_last: usize,
) -> Vec<usize> {
    selector::select_iqr(&scores, factor, preserve_first, preserve_last)
}

// ═══════════════════════════════════════════════════════════
// Merging (ToMe)
// ═══════════════════════════════════════════════════════════

/// Bipartite soft matching for token merging (ToMe algorithm).
///
/// Returns: (kept_indices, merge_sources, merge_destinations, output_size)
#[pyfunction]
#[pyo3(signature = (embeddings, r, protect_first=0))]
fn py_bipartite_merge(
    embeddings: Vec<Vec<f64>>,
    r: usize,
    protect_first: usize,
) -> (Vec<usize>, Vec<usize>, Vec<usize>, usize) {
    let result = merge::bipartite_soft_matching(&embeddings, r, protect_first);
    (
        result.kept_indices,
        result.merge_src,
        result.merge_dst,
        result.output_size,
    )
}

/// Apply merge result to token embeddings via weighted averaging.
///
/// Returns the merged embeddings in kept-index order.
#[pyfunction]
fn py_apply_merge(
    token_embeddings: Vec<Vec<f64>>,
    kept_indices: Vec<usize>,
    merge_src: Vec<usize>,
    merge_dst: Vec<usize>,
) -> Vec<Vec<f64>> {
    let result = merge::MergeResult {
        kept_indices,
        merge_src,
        merge_dst,
        output_size: 0,
    };
    merge::apply_merge(&token_embeddings, &result)
}

// ═══════════════════════════════════════════════════════════
// Pipeline
// ═══════════════════════════════════════════════════════════

/// Main compression entry point.
///
/// Takes pre-computed importance scores and returns indices to keep.
///
/// Strategies: "ratio" (default), "topk", "threshold", "percentile", "iqr"
#[pyfunction]
#[pyo3(signature = (scores, ratio=0.5, strategy="ratio", preserve_first=1, preserve_last=0))]
fn py_compress(
    scores: Vec<f64>,
    ratio: f64,
    strategy: &str,
    preserve_first: usize,
    preserve_last: usize,
) -> Vec<usize> {
    pipeline::compress_tokens(&scores, ratio, strategy, preserve_first, preserve_last)
}

/// Batch compress multiple sequences in parallel.
#[pyfunction]
#[pyo3(signature = (batch_scores, ratio=0.5, strategy="ratio", preserve_first=1, preserve_last=0))]
fn py_batch_compress(
    batch_scores: Vec<Vec<f64>>,
    ratio: f64,
    strategy: &str,
    preserve_first: usize,
    preserve_last: usize,
) -> Vec<Vec<usize>> {
    pipeline::batch_compress(&batch_scores, ratio, strategy, preserve_first, preserve_last)
}
