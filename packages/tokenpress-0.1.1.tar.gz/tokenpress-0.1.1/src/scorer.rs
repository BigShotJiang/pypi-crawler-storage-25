use rayon::prelude::*;

/// Compute self-information from log-probabilities.
///
/// Self-information: I(x_i) = -log_prob(x_i) / ln(2)
///
/// Higher values = more informative/surprising tokens → should be PRESERVED
/// Lower values  = more predictable/redundant tokens → safe to REMOVE
pub fn compute_self_information(log_probs: &[f64]) -> Vec<f64> {
    const LN2_INV: f64 = 1.0 / std::f64::consts::LN_2;
    log_probs
        .iter()
        .map(|&lp| {
            if lp.is_nan() || lp.is_infinite() {
                0.0
            } else {
                // log_probs are negative (log of probability ∈ (0,1))
                // -(-|lp|) / ln(2) = |lp| / ln(2) → positive
                (-lp) * LN2_INV
            }
        })
        .collect()
}

/// Batch compute self-information across multiple sequences in parallel.
///
/// Each inner Vec is one sequence's log-probabilities.
/// Uses rayon work-stealing parallelism across sequences.
pub fn batch_compute_self_information(batch: &[Vec<f64>]) -> Vec<Vec<f64>> {
    batch
        .par_iter()
        .map(|seq| compute_self_information(seq))
        .collect()
}

/// Compute the entropy of the next-token distribution at each position.
///
/// Input: for each position, the full logit vector over the vocabulary.
/// Output: entropy in nats at each position (higher = more uncertain).
///
/// Uses numerically stable log-sum-exp computation.
pub fn compute_entropy(logits_per_position: &[Vec<f64>]) -> Vec<f64> {
    logits_per_position
        .par_iter()
        .map(|logits| {
            if logits.is_empty() {
                return 0.0;
            }
            // Numerically stable softmax + entropy
            let max_logit = logits
                .iter()
                .cloned()
                .fold(f64::NEG_INFINITY, f64::max);

            let exp_sum: f64 = logits.iter().map(|&l| (l - max_logit).exp()).sum();
            let log_z = max_logit + exp_sum.ln();

            // H = -sum_i p_i * log(p_i)
            //   = -sum_i exp(l_i - log_z) * (l_i - log_z)
            //   = log_z - (1/Z) * sum_i exp(l_i) * l_i
            let weighted_sum: f64 = logits
                .iter()
                .map(|&l| {
                    let log_p = l - log_z;
                    let p = log_p.exp();
                    if p > 1e-30 {
                        -p * log_p
                    } else {
                        0.0
                    }
                })
                .sum();

            weighted_sum
        })
        .collect()
}

/// Compute perplexity of a sequence from its log-probabilities.
///
/// PPL = exp(-1/N * sum(log_probs))
pub fn compute_perplexity(log_probs: &[f64]) -> f64 {
    if log_probs.is_empty() {
        return 1.0;
    }
    let avg_log_prob: f64 = log_probs.iter().sum::<f64>() / log_probs.len() as f64;
    (-avg_log_prob).exp()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_self_information_basic() {
        // log(0.5) ≈ -0.693
        let _unused = vec![(-0.5_f64).ln(), (-0.1_f64).ln()];
        // Actually log(0.5) = ln(0.5) = -0.693...
        let log_probs = vec![0.5_f64.ln(), 0.1_f64.ln()];
        let scores = compute_self_information(&log_probs);
        // I(0.5) = -log2(0.5) = 1.0
        assert!((scores[0] - 1.0).abs() < 1e-10);
        // I(0.1) = -log2(0.1) ≈ 3.322
        assert!((scores[1] - 3.321928094887362).abs() < 1e-10);
    }

    #[test]
    fn test_self_information_handles_nan() {
        let log_probs = vec![f64::NAN, f64::NEG_INFINITY, 0.5_f64.ln()];
        let scores = compute_self_information(&log_probs);
        assert_eq!(scores[0], 0.0);
        assert_eq!(scores[1], 0.0);
        assert!((scores[2] - 1.0).abs() < 1e-10);
    }

    #[test]
    fn test_batch_parallel() {
        let batch = vec![
            vec![0.5_f64.ln(), 0.25_f64.ln()],
            vec![0.1_f64.ln(), 0.9_f64.ln()],
        ];
        let results = batch_compute_self_information(&batch);
        assert_eq!(results.len(), 2);
        assert!((results[0][0] - 1.0).abs() < 1e-10);
        assert!((results[0][1] - 2.0).abs() < 1e-10);
    }

    #[test]
    fn test_entropy_uniform() {
        // Uniform distribution over 4 items → entropy = ln(4)
        let logits = vec![vec![0.0, 0.0, 0.0, 0.0]];
        let ent = compute_entropy(&logits);
        assert!((ent[0] - 4.0_f64.ln()).abs() < 1e-6);
    }

    #[test]
    fn test_entropy_peaked() {
        // Very peaked distribution → low entropy
        let logits = vec![vec![100.0, 0.0, 0.0, 0.0]];
        let ent = compute_entropy(&logits);
        assert!(ent[0] < 0.01);
    }

    #[test]
    fn test_perplexity() {
        // All tokens equally likely with prob 0.01 → PPL = 100
        let log_probs = vec![0.01_f64.ln(); 10];
        let ppl = compute_perplexity(&log_probs);
        assert!((ppl - 100.0).abs() < 1e-6);
    }
}
