use crate::selector;
use rayon::prelude::*;

/// Compress tokens by scoring and selecting the most important ones.
///
/// This is the main entry point that chains scoring → selection.
/// The caller provides pre-computed importance scores.
///
/// # Arguments
/// * `scores` - Per-token importance scores (higher = more important)
/// * `ratio` - Fraction of tokens to keep (0.3 = keep 30%)
/// * `strategy` - Selection strategy: "ratio", "topk", "threshold", "percentile", "iqr"
/// * `preserve_first` - Always keep these many tokens from the start
/// * `preserve_last` - Always keep these many tokens from the end
///
/// # Returns
/// Sorted indices of tokens to keep.
pub fn compress_tokens(
    scores: &[f64],
    ratio: f64,
    strategy: &str,
    preserve_first: usize,
    preserve_last: usize,
) -> Vec<usize> {
    match strategy {
        "ratio" => selector::select_ratio(scores, ratio, preserve_first, preserve_last),
        "topk" => {
            let k = (scores.len() as f64 * ratio).ceil() as usize;
            selector::select_topk(scores, k.max(1), preserve_first, preserve_last)
        }
        "threshold" => selector::select_threshold(scores, ratio, preserve_first, preserve_last),
        "percentile" => {
            // Convert ratio to percentile: ratio=0.3 means keep top 30% → percentile=70
            let pct = (1.0 - ratio) * 100.0;
            selector::select_percentile(scores, pct, preserve_first, preserve_last)
        }
        "iqr" => selector::select_iqr(scores, 1.5, preserve_first, preserve_last),
        _ => selector::select_ratio(scores, ratio, preserve_first, preserve_last),
    }
}

/// Batch compress multiple sequences in parallel.
///
/// Each inner Vec is one sequence's importance scores.
/// Returns one Vec of kept indices per sequence.
pub fn batch_compress(
    batch_scores: &[Vec<f64>],
    ratio: f64,
    strategy: &str,
    preserve_first: usize,
    preserve_last: usize,
) -> Vec<Vec<usize>> {
    batch_scores
        .par_iter()
        .map(|scores| compress_tokens(scores, ratio, strategy, preserve_first, preserve_last))
        .collect()
}

/// Compute compression statistics.
pub struct CompressionStats {
    pub original_tokens: usize,
    pub compressed_tokens: usize,
    pub compression_ratio: f64,
    pub tokens_removed: usize,
    pub removal_percentage: f64,
}

pub fn compute_stats(original_len: usize, kept_indices: &[usize]) -> CompressionStats {
    let compressed = kept_indices.len();
    CompressionStats {
        original_tokens: original_len,
        compressed_tokens: compressed,
        compression_ratio: if compressed > 0 {
            original_len as f64 / compressed as f64
        } else {
            f64::INFINITY
        },
        tokens_removed: original_len - compressed,
        removal_percentage: if original_len > 0 {
            (original_len - compressed) as f64 / original_len as f64 * 100.0
        } else {
            0.0
        },
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_compress_ratio() {
        let scores = vec![1.0, 5.0, 3.0, 4.0, 2.0];
        let kept = compress_tokens(&scores, 0.4, "ratio", 0, 0);
        // 40% of 5 = 2 tokens
        assert_eq!(kept.len(), 2);
        assert_eq!(kept, vec![1, 3]); // highest scores
    }

    #[test]
    fn test_compress_with_preserve() {
        let scores = vec![1.0, 5.0, 3.0, 4.0, 2.0];
        let kept = compress_tokens(&scores, 0.4, "ratio", 1, 1);
        // Need 2 tokens (40%), but first and last are guaranteed
        // Preserved: 0, 4 (count = 2 ≥ k=2). Done.
        assert!(kept.contains(&0));
        assert!(kept.contains(&4));
    }

    #[test]
    fn test_batch_compress() {
        let batch = vec![
            vec![1.0, 5.0, 3.0, 4.0, 2.0],
            vec![10.0, 1.0, 1.0, 1.0, 1.0],
        ];
        let results = batch_compress(&batch, 0.4, "ratio", 0, 0);
        assert_eq!(results.len(), 2);
        assert_eq!(results[0].len(), 2);
        assert_eq!(results[1].len(), 2);
    }

    #[test]
    fn test_compress_iqr() {
        let scores = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0];
        let kept = compress_tokens(&scores, 0.5, "iqr", 0, 0);
        // IQR method is adaptive — should keep most tokens with default factor
        assert!(!kept.is_empty());
    }

    #[test]
    fn test_stats() {
        let stats = compute_stats(100, &(0..30).collect::<Vec<_>>());
        assert_eq!(stats.original_tokens, 100);
        assert_eq!(stats.compressed_tokens, 30);
        assert!((stats.compression_ratio - 3.333).abs() < 0.01);
        assert_eq!(stats.tokens_removed, 70);
        assert!((stats.removal_percentage - 70.0).abs() < 0.01);
    }
}
