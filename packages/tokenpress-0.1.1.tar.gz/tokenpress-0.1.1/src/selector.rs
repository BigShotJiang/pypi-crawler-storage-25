/// Token selection strategies.
///
/// All selectors return a sorted Vec of indices to KEEP.
/// The `preserve_first` and `preserve_last` parameters ensure
/// that the specified number of tokens at the start/end of the
/// sequence are always included (attention sinks + recency).

/// Keep the top-k tokens by score, plus all preserved tokens.
/// Returned indices are sorted in original order.
pub fn select_topk(
    scores: &[f64],
    k: usize,
    preserve_first: usize,
    preserve_last: usize,
) -> Vec<usize> {
    let n = scores.len();
    if n == 0 {
        return vec![];
    }

    let pf = preserve_first.min(n);
    let pl = preserve_last.min(n.saturating_sub(pf));

    // Build set of guaranteed indices
    let mut kept: Vec<bool> = vec![false; n];
    for i in 0..pf {
        kept[i] = true;
    }
    for i in (n - pl)..n {
        kept[i] = true;
    }

    let guaranteed_count = kept.iter().filter(|&&k| k).count();

    // How many more do we need from the middle?
    let remaining = k.saturating_sub(guaranteed_count);
    if remaining > 0 {
        // Collect scoreable indices (those not already preserved)
        let mut candidates: Vec<(usize, f64)> = scores
            .iter()
            .enumerate()
            .filter(|(i, _)| !kept[*i])
            .map(|(i, &s)| (i, s))
            .collect();

        // Sort by score descending
        candidates.sort_unstable_by(|a, b| {
            b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal)
        });

        // Take top-remaining
        for &(idx, _) in candidates.iter().take(remaining) {
            kept[idx] = true;
        }
    }

    // Return sorted indices
    kept.iter()
        .enumerate()
        .filter(|(_, &k)| k)
        .map(|(i, _)| i)
        .collect()
}

/// Keep a ratio of tokens (e.g., 0.3 = keep 30%).
pub fn select_ratio(
    scores: &[f64],
    ratio: f64,
    preserve_first: usize,
    preserve_last: usize,
) -> Vec<usize> {
    let ratio = ratio.clamp(0.0, 1.0);
    let k = (scores.len() as f64 * ratio).ceil() as usize;
    select_topk(scores, k.max(1), preserve_first, preserve_last)
}

/// Keep all tokens with score >= threshold.
pub fn select_threshold(
    scores: &[f64],
    threshold: f64,
    preserve_first: usize,
    preserve_last: usize,
) -> Vec<usize> {
    let n = scores.len();
    if n == 0 {
        return vec![];
    }

    let pf = preserve_first.min(n);
    let pl = preserve_last.min(n.saturating_sub(pf));

    (0..n)
        .filter(|&i| {
            i < pf || i >= n - pl || scores[i] >= threshold
        })
        .collect()
}

/// Keep all tokens above the given percentile of scores.
///
/// percentile should be in [0, 100]. E.g., 30 = keep tokens above the 30th percentile.
pub fn select_percentile(
    scores: &[f64],
    percentile: f64,
    preserve_first: usize,
    preserve_last: usize,
) -> Vec<usize> {
    if scores.is_empty() {
        return vec![];
    }

    let mut sorted = scores.to_vec();
    sorted.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));

    let idx = ((percentile / 100.0) * (sorted.len() - 1) as f64).round() as usize;
    let threshold = sorted[idx.min(sorted.len() - 1)];

    select_threshold(scores, threshold, preserve_first, preserve_last)
}

/// Adaptive selection using the Interquartile Range (IQR) method.
///
/// Keeps tokens whose score >= Q1 - factor * IQR.
/// This is the method from TRIM (COLING 2025) for adaptive thresholding.
/// factor=1.5 is standard; lower = more aggressive pruning.
pub fn select_iqr(
    scores: &[f64],
    factor: f64,
    preserve_first: usize,
    preserve_last: usize,
) -> Vec<usize> {
    if scores.is_empty() {
        return vec![];
    }

    let mut sorted = scores.to_vec();
    sorted.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));

    let n = sorted.len();
    let q1 = sorted[n / 4];
    let q3 = sorted[3 * n / 4];
    let iqr = q3 - q1;
    let threshold = q1 - factor * iqr;

    select_threshold(scores, threshold, preserve_first, preserve_last)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_topk_basic() {
        let scores = vec![1.0, 5.0, 3.0, 4.0, 2.0];
        let kept = select_topk(&scores, 3, 0, 0);
        assert_eq!(kept, vec![1, 2, 3]); // indices of 5.0, 3.0, 4.0 (sorted)
    }

    #[test]
    fn test_topk_sorted_order() {
        let scores = vec![1.0, 5.0, 3.0, 4.0, 2.0];
        let kept = select_topk(&scores, 2, 0, 0);
        // Top 2: index 1 (5.0) and index 3 (4.0), sorted
        assert_eq!(kept, vec![1, 3]);
    }

    #[test]
    fn test_topk_with_preserve() {
        let scores = vec![1.0, 5.0, 3.0, 4.0, 2.0];
        let kept = select_topk(&scores, 3, 1, 1);
        // Must include index 0 (first) and 4 (last), plus top-1 from rest
        // Preserved: 0, 4. Remaining budget = 1. Best non-preserved: idx 1 (5.0)
        assert_eq!(kept, vec![0, 1, 4]);
    }

    #[test]
    fn test_ratio() {
        let scores = vec![1.0, 5.0, 3.0, 4.0, 2.0];
        let kept = select_ratio(&scores, 0.4, 0, 0); // 40% of 5 = 2
        assert_eq!(kept, vec![1, 3]);
    }

    #[test]
    fn test_threshold() {
        let scores = vec![1.0, 5.0, 3.0, 4.0, 2.0];
        let kept = select_threshold(&scores, 3.0, 0, 0);
        assert_eq!(kept, vec![1, 2, 3]); // 5.0, 3.0, 4.0 are >= 3.0
    }

    #[test]
    fn test_percentile() {
        let scores = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0];
        let kept = select_percentile(&scores, 50.0, 0, 0);
        // 50th percentile: idx = round(0.5 * 9) = 5, threshold = sorted[5] = 6.0
        // Keep all >= 6.0 → indices 5,6,7,8,9
        assert!(kept.contains(&5));
        assert!(kept.contains(&9));
        assert!(!kept.contains(&0));
        assert!(!kept.contains(&4)); // score 5.0 < threshold 6.0
    }

    #[test]
    fn test_iqr() {
        let scores = vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0];
        let kept = select_iqr(&scores, 1.5, 0, 0);
        // Q1 = sorted[2] = 3.0, Q3 = sorted[6] = 7.0, IQR = 4.0
        // threshold = 3.0 - 1.5*4.0 = -3.0 → keeps everything
        assert_eq!(kept.len(), 8);
    }

    #[test]
    fn test_preserve_overrides_score() {
        let scores = vec![10.0, 0.0, 0.0, 0.0, 10.0];
        let kept = select_topk(&scores, 2, 2, 0);
        // Preserved: 0, 1. These count towards k=2. No more needed.
        assert!(kept.contains(&0));
        assert!(kept.contains(&1));
    }

    #[test]
    fn test_empty() {
        let scores: Vec<f64> = vec![];
        assert_eq!(select_topk(&scores, 5, 0, 0), Vec::<usize>::new());
        assert_eq!(select_ratio(&scores, 0.5, 0, 0), Vec::<usize>::new());
    }
}
