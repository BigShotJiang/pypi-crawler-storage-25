<p align="center">
  <img src="https://raw.githubusercontent.com/zamalali/tokenpress/master/logo.png" alt="TokenPress" width="280">
</p>

<h1 align="center">TokenPress</h1>

<p align="center">
  <strong>LLM token compression engine, built in Rust.</strong>
</p>

<p align="center">
  <a href="https://pypi.org/project/tokenpress/"><img alt="PyPI" src="https://img.shields.io/badge/pypi-v0.1.1-blue?style=flat-square&logo=pypi&logoColor=white"></a>
  <a href="https://pypi.org/project/tokenpress/"><img alt="Downloads" src="https://img.shields.io/badge/downloads-new-blue?style=flat-square&logo=pypi&logoColor=white"></a>
  <a href="https://github.com/zamalali/tokenpress/blob/master/LICENSE"><img alt="License" src="https://img.shields.io/badge/license-Apache--2.0-green?style=flat-square"></a>
  <a href="https://github.com/zamalali/tokenpress/actions"><img alt="CI" src="https://img.shields.io/badge/tests-27%20rust%20%2B%209%20python-brightgreen?style=flat-square"></a>
  <img alt="Rust" src="https://img.shields.io/badge/core-Rust-F74C00?style=flat-square&logo=rust&logoColor=white">
  <img alt="Python" src="https://img.shields.io/badge/api-Python%203.9%2B-3776AB?style=flat-square&logo=python&logoColor=white">
</p>

<p align="center">
TokenPress scores every token in your prompt by its information content,<br>
keeps only what matters, and passes a compressed prompt to the LLM.<br>
<b>2–5× fewer tokens. Same or better output quality. Any model, any language.</b>
</p>

---

<br>

> **TL;DR** — Score → Select → Send. Three lines of code, 3× cheaper API calls.
>
> ```python
> import tokenpress
> result = tokenpress.compress("Your very long prompt …", ratio=0.3)   # keep 30 %
> print(result.compressed_text, f"— {result.compression_ratio:.1f}× smaller")
> ```

<br>

## Benchmarks

**18.6 M tok/s** Rust core · **3.3× compression** on GSM8K · **1.92× information density** vs 1.01× random — 7 reproducible suites.

→ **[Full benchmark results](BENCHMARKS.md)** — Rust throughput, GSM8K, info density, baselines, scaling, strategies, batch parallel.

---

## Architecture

```mermaid
flowchart LR
    subgraph PY ["<b>Python layer</b> &nbsp;·&nbsp; tokenpress/"]
        A["compress( ) / wrap( )"]
        B["Tokenizer + Scoring Model<br/><i>distilgpt2 · 82 M params</i>"]
    end

    subgraph RUST ["<b>Rust core</b> &nbsp;·&nbsp; src/ &nbsp;·&nbsp; PyO3"]
        direction TB
        S["<b>scorer</b><br/>self-info · entropy · PPL"]
        SEL["<b>selector</b><br/>ratio · top-k · threshold<br/>percentile · IQR <small>(TRIM)</small>"]
        M["<b>merge</b><br/>ToMe bipartite matching"]
        P["<b>pipeline</b><br/>compress_tokens · batch_compress<br/><i>rayon work-stealing</i>"]
        S --> SEL --> P
        S --> M --> P
    end

    A -->|"token IDs +<br/>log-probs"| S
    P -->|"kept indices"| A

    style PY fill:#1e1e2e,stroke:#89b4fa,stroke-width:2px,color:#cdd6f4
    style RUST fill:#1e1e2e,stroke:#fab387,stroke-width:2px,color:#cdd6f4
    style S fill:#313244,stroke:#89b4fa,color:#cdd6f4
    style SEL fill:#313244,stroke:#89b4fa,color:#cdd6f4
    style M fill:#313244,stroke:#89b4fa,color:#cdd6f4
    style P fill:#313244,stroke:#a6e3a1,color:#cdd6f4
    style A fill:#313244,stroke:#cba6f7,color:#cdd6f4
    style B fill:#313244,stroke:#cba6f7,color:#cdd6f4
```

Text → tokenizer → log-probs → **Rust scores every token** → select / merge → decode. The Python layer owns model inference (the bottleneck); everything after runs in Rust with rayon and adds < 10 ms at 100 K tokens.

---

## Quick start

```bash
pip install tokenpress              # core
pip install "tokenpress[models]"    # + scoring model
pip install "tokenpress[all]"       # + OpenAI & Anthropic wrappers
```

```python
import tokenpress

result = tokenpress.compress(
    text="Your long prompt …",
    ratio=0.3,              # keep 30 % of tokens → 3.3× compression
    strategy="ratio",        # or: topk, threshold, percentile, iqr
    preserve_first=1,        # keep attention-sink tokens (H2O insight)
)

result.compressed_text      # str  — the compressed prompt
result.compression_ratio    # 3.3  — how much smaller
result.tokens_saved         # int  — tokens removed
result.savings_percentage   # 70.0 — percent removed
result.token_scores         # numpy array of per-token importance
```

**Drop-in wrapper** — works with OpenAI and Anthropic:

```python
import openai, tokenpress

# Every prompt is auto-compressed before hitting the API
client = tokenpress.wrap(openai.OpenAI(), ratio=0.3)

response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": very_long_prompt}],
)
# same API, 3× cheaper
```

```python
import anthropic, tokenpress

client = tokenpress.wrap(anthropic.Anthropic(), ratio=0.3)
response = client.messages.create(
    model="claude-sonnet-4-20250514",
    messages=[{"role": "user", "content": long_text}],
    max_tokens=1024,
)
```

**CLI:**

```bash
tokenpress compress document.txt -r 0.3 -o compressed.txt
tokenpress compress "Your long prompt …" -r 0.5
tokenpress bench document.txt        # sweep across ratios
tokenpress version
```

---

### Rust API

Call the Rust core directly via PyO3:

```python
from tokenpress import _core

# ── Scoring ──────────────────────────────────────────
scores  = _core.py_score_self_information(log_probs)         # I(x) = −log₂ P(x|ctx)
entropy = _core.py_score_entropy(logits_per_position)        # H(x) per position
ppl     = _core.py_score_perplexity(log_probs)               # exp(−mean(log_probs))

# ── Selection ────────────────────────────────────────
idx = _core.py_select_ratio(scores, 0.3, preserve_first=1, preserve_last=0)
idx = _core.py_select_topk(scores, k=100, preserve_first=1)
idx = _core.py_select_iqr(scores, factor=1.5)               # adaptive (TRIM)

# ── Token merging (ToMe) ────────────────────────────
kept, src, dst, out = _core.py_bipartite_merge(embeddings, r=50, protect_first=1)

# ── Pipeline / batch (rayon-parallel) ───────────────
idx    = _core.py_compress(scores, 0.3, "ratio", 1, 0)
b_idx  = _core.py_batch_compress(batch_scores, 0.3)
b_scores = _core.py_batch_score_self_information(list_of_log_probs)
```

---

### Strategies

| Strategy | Description | Best for |
|:---|:---|:---|
| `ratio` | Keep top *X %* by score | General use |
| `topk` | Keep *K* highest-scoring tokens | Fixed budget |
| `threshold` | Keep above a score cutoff | Quality-sensitive |
| `percentile` | Keep above *N*-th percentile | Adaptive |
| `iqr` | IQR-based threshold ([TRIM](https://aclanthology.org/2025.coling-main.224/)) | Best trade-off |

---

### Theory

<details>
<summary><b>The core insight</b></summary>

LLM attention is a **finite resource**. When a transformer processes 10 000 tokens, its attention must distribute probability mass across all of them. Research shows this mass is highly concentrated:

- Only 5–10 % of attention heads attend to > 90 % of tokens; the rest focus on a small subset ([H2O, Zhang et al. 2024](#references)).
- Token importance follows a power law — a small fraction carries most of the semantic load ([Selective Context, Li et al. 2023](#references)).
- The first few tokens receive disproportionate attention regardless of content — "attention sinks" ([StreamingLLM, Xiao et al. 2024](#references)).

Most tokens in a prompt are **redundant from the model's perspective**. Removing them doesn't lose meaning — it **focuses** the model.
</details>

<details>
<summary><b>Mathematical foundation</b></summary>

TokenPress uses **self-information** from information theory:

$$I(x_i) = -\log_2 P(x_i \mid x_{<i})$$

- $P(x_i \mid x_{<i})$: conditional probability of token $x_i$ given preceding context.
- **High** $I$ → surprising / informative → **keep**.
- **Low** $I$ → predictable / redundant → safe to **remove**.

This is a pure mathematical measure — language-agnostic, domain-agnostic, model-agnostic.
</details>

<details>
<summary><b>Why compression can <i>improve</i> output quality</b></summary>

Counter-intuitive but well-documented:

| Paper | Finding |
|:---|:---|
| **H2O** (NeurIPS 2024) | Evicting 80 % of KV cache entries **improved** accuracy by +0.73 % on average — attention focused on the right tokens. |
| **LLMLingua-2** (ACL 2024) | Compressed prompts outperformed originals on Mistral-7B — compression removed noise that confused the model. |
| **TRIM** (COLING 2025) | Adaptive IQR thresholding achieves optimal balance; aggregated token safety net prevents information loss. |
| **The Token Company** | 268 K community votes: compressed prompts produce equal or better outputs; +2.7 pp accuracy on FinanceBench. |
</details>

---

### Algorithms

| Algorithm | Paper | Usage in TokenPress |
|:---|:---|:---|
| Self-Information Scoring | [Selective Context](https://arxiv.org/abs/2310.06201) (EMNLP '23) | Core scoring: $I(x)=-\log_2 P(x \mid \text{ctx})$ |
| IQR Adaptive Threshold | [TRIM](https://aclanthology.org/2025.coling-main.224/) (COLING '25) | Outlier-aware threshold: $Q_1 - k \cdot IQR$ |
| Bipartite Token Merging | [ToMe](https://arxiv.org/abs/2210.09461) (ICLR '23 Oral) | Merge instead of drop — zero info loss |
| Attention Sink Preservation | [H2O](https://arxiv.org/abs/2306.14048) (NeurIPS '24) | `preserve_first` for heavy-hitter tokens |
| Task-Agnostic Design | [LLMLingua-2](https://arxiv.org/abs/2403.12968) (ACL '24) | Domain-independent — works on unseen tasks |

---

### Quality guarantee

| Guard | How |
|:---|:---|
| Information theory | Only low-self-information (= high predictability) tokens removed |
| Attention sinks | `preserve_first` keeps heavy-hitter tokens (StreamingLLM, H2O) |
| Adaptive threshold | `iqr` never removes statistical outliers in importance |
| Lossless path | ToMe merges similar embeddings instead of dropping |
| Test coverage | 27 Rust + 9 Python tests; scores match definition to machine ε |

---

### Build from source

```bash
git clone https://github.com/zamalali/tokenpress.git && cd tokenpress
pip install maturin && maturin develop --release
cargo test              # 27 Rust tests
python test_e2e.py      # 9 Python tests
python benchmark.py     # full benchmark suite
```

---

### References

<a id="references"></a>

1. **Selective Context** — Li et al. (2023). *Compressing Context to Enhance Inference Efficiency of Large Language Models.* EMNLP 2023. [arXiv:2310.06201](https://arxiv.org/abs/2310.06201)
2. **TRIM** — Yoon et al. (2025). *Less is More: Token Reduction for Efficient Inference of LLMs via Metrics.* COLING 2025. [ACL Anthology](https://aclanthology.org/2025.coling-main.224/)
3. **Token Merging (ToMe)** — Bolya et al. (2023). *Token Merging: Your ViT But Faster.* ICLR 2023 (Oral). [arXiv:2210.09461](https://arxiv.org/abs/2210.09461)
4. **H2O** — Zhang et al. (2024). *H2O: Heavy-Hitter Oracle for Efficient Generative Inference of Large Language Models.* NeurIPS 2024. [arXiv:2306.14048](https://arxiv.org/abs/2306.14048)
5. **LLMLingua** — Jiang et al. (2023). *LLMLingua: Compressing Prompts for Accelerated Inference of Large Language Models.* EMNLP 2023. [arXiv:2310.05736](https://arxiv.org/abs/2310.05736)
6. **LLMLingua-2** — Pan et al. (2024). *LLMLingua-2: Data Distillation for Efficient and Faithful Task-Agnostic Prompt Compression.* ACL 2024. [arXiv:2403.12968](https://arxiv.org/abs/2403.12968)
7. **StreamingLLM** — Xiao et al. (2024). *Efficient Streaming Language Models with Attention Sinks.* ICLR 2024. [arXiv:2309.17453](https://arxiv.org/abs/2309.17453)
8. **SnapKV** — Li et al. (2024). *SnapKV: LLM Knows What You are Looking for Before Generation.* NeurIPS 2024. [arXiv:2404.14469](https://arxiv.org/abs/2404.14469)
9. **VisionZip** — Yang et al. (2025). *VisionZip: Seeing is Enough to Reduce Visual Token Redundancy.* CVPR 2025. [arXiv:2412.04467](https://arxiv.org/abs/2412.04467)

> **On multimodal compression:** VisionZip shows visual tokens from CLIP/SigLIP exhibit the same redundancy — attention concentrates on a few "dominant" tokens while most are filler. TokenPress handles the text side; VisionZip handles vision. Complementary approaches to the same underlying problem.

---

## License

[Apache-2.0](LICENSE)

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md).
