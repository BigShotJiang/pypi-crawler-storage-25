"""Wrapper for OpenAI and Anthropic clients to auto-compress prompts."""

from __future__ import annotations

from typing import Any


def wrap(
    client: Any,
    ratio: float = 0.5,
    method: str = "self_info",
    model_name: str = "distilgpt2",
    strategy: str = "ratio",
    preserve_first: int = 1,
    preserve_last: int = 0,
    min_tokens: int = 50,
) -> Any:
    """
    Wrap an LLM API client to automatically compress prompts.

    Supports OpenAI and Anthropic clients. All prompts are compressed
    before being sent to the API, reducing token usage and cost.

    Args:
        client: An OpenAI() or Anthropic() client instance.
        ratio: Fraction of tokens to keep (0.3 = keep 30%).
        method: Scoring method ("self_info").
        model_name: HuggingFace model for scoring.
        strategy: Selection strategy ("ratio", "topk", "iqr", etc.).
        preserve_first: Always keep N tokens from start.
        preserve_last: Always keep N tokens from end.
        min_tokens: Don't compress messages shorter than this many words (approximate token threshold).

    Returns:
        A wrapped client with the same API but automatic compression.

    Example:
        >>> import openai, tokenpress
        >>> client = tokenpress.wrap(openai.OpenAI(), ratio=0.3)
        >>> # Use exactly as before — prompts are auto-compressed
        >>> response = client.chat.completions.create(
        ...     model="gpt-4o",
        ...     messages=[{"role": "user", "content": long_text}]
        ... )
    """
    client_type = type(client).__module__

    if "openai" in client_type:
        return _OpenAIWrapper(
            client, ratio, method, model_name, strategy,
            preserve_first, preserve_last, min_tokens,
        )
    elif "anthropic" in client_type:
        return _AnthropicWrapper(
            client, ratio, method, model_name, strategy,
            preserve_first, preserve_last, min_tokens,
        )
    else:
        raise ValueError(
            f"Unsupported client: {type(client).__name__}. "
            "Supported: openai.OpenAI, anthropic.Anthropic"
        )


class _CompressConfig:
    """Shared compression configuration."""

    def __init__(
        self, ratio, method, model_name, strategy,
        preserve_first, preserve_last, min_tokens,
    ):
        self.ratio = ratio
        self.method = method
        self.model_name = model_name
        self.strategy = strategy
        self.preserve_first = preserve_first
        self.preserve_last = preserve_last
        self.min_tokens = min_tokens
        self._total_original = 0
        self._total_compressed = 0

    def compress_text(self, text: str) -> str:
        """Compress a text string if it's long enough."""
        if not isinstance(text, str) or len(text.split()) < self.min_tokens:
            return text

        from tokenpress.compress import compress

        result = compress(
            text,
            ratio=self.ratio,
            method=self.method,
            model_name=self.model_name,
            strategy=self.strategy,
            preserve_first=self.preserve_first,
            preserve_last=self.preserve_last,
        )

        self._total_original += result.original_tokens
        self._total_compressed += result.compressed_tokens

        return result.compressed_text

    @property
    def total_tokens_saved(self) -> int:
        return self._total_original - self._total_compressed


# ─── OpenAI Wrapper ─────────────────────────────────────────


class _OpenAIWrapper:
    """Transparent wrapper around openai.OpenAI with auto-compression."""

    def __init__(self, client, *args, **kwargs):
        self._client = client
        self._config = _CompressConfig(*args, **kwargs)
        self.chat = _OpenAIChatWrapper(self)

    def __getattr__(self, name):
        # Proxy everything else to the real client
        return getattr(self._client, name)


class _OpenAIChatWrapper:
    def __init__(self, wrapper):
        self._wrapper = wrapper
        self.completions = _OpenAICompletionsWrapper(wrapper)


class _OpenAICompletionsWrapper:
    def __init__(self, wrapper):
        self._wrapper = wrapper

    def create(self, **kwargs):
        messages = kwargs.get("messages", [])
        compressed = []

        for msg in messages:
            content = msg.get("content", "")
            role = msg.get("role", "")

            # Only compress user and system messages
            if role in ("user", "system") and isinstance(content, str):
                new_content = self._wrapper._config.compress_text(content)
                compressed.append({**msg, "content": new_content})
            else:
                compressed.append(msg)

        kwargs["messages"] = compressed
        return self._wrapper._client.chat.completions.create(**kwargs)


# ─── Anthropic Wrapper ──────────────────────────────────────


class _AnthropicWrapper:
    """Transparent wrapper around anthropic.Anthropic with auto-compression."""

    def __init__(self, client, *args, **kwargs):
        self._client = client
        self._config = _CompressConfig(*args, **kwargs)
        self.messages = _AnthropicMessagesWrapper(self)

    def __getattr__(self, name):
        return getattr(self._client, name)


class _AnthropicMessagesWrapper:
    def __init__(self, wrapper):
        self._wrapper = wrapper

    def create(self, **kwargs):
        messages = kwargs.get("messages", [])
        compressed = []

        for msg in messages:
            content = msg.get("content", "")
            role = msg.get("role", "")

            if role == "user" and isinstance(content, str):
                new_content = self._wrapper._config.compress_text(content)
                compressed.append({**msg, "content": new_content})
            else:
                compressed.append(msg)

        # Also compress system prompt if provided
        system = kwargs.get("system")
        if system and isinstance(system, str):
            kwargs["system"] = self._wrapper._config.compress_text(system)

        kwargs["messages"] = compressed
        return self._wrapper._client.messages.create(**kwargs)
