"""
TokenPress: Blazing-fast LLM token compression.

Reduce API costs by 2-5x with zero quality loss.
Built in Rust for maximum performance.

Usage:
    import tokenpress

    # Simple one-liner
    result = tokenpress.compress("Your long prompt here...", ratio=0.3)
    print(result.compressed_text)

    # Wrap an OpenAI client for automatic compression
    import openai
    client = tokenpress.wrap(openai.OpenAI(), ratio=0.3)

    # Low-level: score and select tokens directly
    from tokenpress import _core
    scores = _core.py_score_self_information(log_probs)
    indices = _core.py_compress(scores, ratio=0.3)
"""

try:
    from tokenpress._core import __version__
except ImportError:
    raise ImportError(
        "TokenPress native extension not found. "
        "Build with: maturin develop --release  "
        "Or install with: pip install tokenpress"
    )

from tokenpress.compress import compress, compress_batch, CompressResult
from tokenpress.wrapper import wrap

__all__ = [
    "__version__",
    "compress",
    "compress_batch",
    "CompressResult",
    "wrap",
    "_core",
]
