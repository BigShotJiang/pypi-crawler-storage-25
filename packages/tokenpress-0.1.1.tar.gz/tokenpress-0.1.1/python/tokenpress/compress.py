"""High-level compression API."""

from __future__ import annotations

import numpy as np
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Tuple

from tokenpress import _core


@dataclass
class CompressResult:
    """Result of a compression operation."""

    compressed_text: str
    original_tokens: int
    compressed_tokens: int
    ratio: float
    kept_indices: List[int]
    token_scores: Optional[np.ndarray] = field(default=None, repr=False)

    @property
    def compression_ratio(self) -> float:
        """How many X smaller (e.g., 3.2x)."""
        if self.compressed_tokens == 0:
            return float("inf")
        return self.original_tokens / self.compressed_tokens

    @property
    def tokens_saved(self) -> int:
        return self.original_tokens - self.compressed_tokens

    @property
    def savings_percentage(self) -> float:
        if self.original_tokens == 0:
            return 0.0
        return self.tokens_saved / self.original_tokens * 100


# ─── Model cache ────────────────────────────────────────────
_model_cache: dict = {}


def _get_model_and_tokenizer(model_name: str, need_attentions: bool = False):
    """Load and cache a scoring model + tokenizer."""
    cache_key = (model_name, need_attentions)
    if cache_key in _model_cache:
        return _model_cache[cache_key]

    try:
        import torch
        from transformers import AutoTokenizer, AutoModelForCausalLM
    except ImportError:
        raise ImportError(
            "Scoring models require: pip install tokenpress[models]  "
            "(installs transformers + torch)"
        )

    tokenizer = AutoTokenizer.from_pretrained(model_name)
    kwargs = {"dtype": torch.float32}
    if need_attentions:
        # SDPA (default in modern transformers) does not return
        # attention weights.  Force eager implementation so
        # output_attentions=True actually works.
        kwargs["attn_implementation"] = "eager"
    model = AutoModelForCausalLM.from_pretrained(model_name, **kwargs)
    model.eval()

    if torch.cuda.is_available():
        model = model.cuda()

    _model_cache[cache_key] = (model, tokenizer)
    return model, tokenizer


def _compute_log_probs(
    token_ids: List[int], model, tokenizer
) -> np.ndarray:
    """Compute log P(token_i | context) for each token."""
    import torch

    device = next(model.parameters()).device
    input_ids = torch.tensor([token_ids], device=device)

    with torch.no_grad():
        outputs = model(input_ids)
        logits = outputs.logits  # [1, seq_len, vocab_size]

    # logits[i] predicts token[i+1], so shift
    shift_logits = logits[0, :-1, :]  # [seq_len-1, vocab_size]
    shift_labels = input_ids[0, 1:]  # [seq_len-1]

    # Log-softmax → gather the actual token's log probability
    log_probs_all = torch.nn.functional.log_softmax(shift_logits, dim=-1)
    token_log_probs = log_probs_all.gather(
        1, shift_labels.unsqueeze(1)
    ).squeeze(1)

    # First token has no prior context — assign conservative score
    result = torch.zeros(len(token_ids), device=device)
    result[1:] = token_log_probs
    result[0] = token_log_probs.min()  # Treat as highly informative (keep it)

    return result.cpu().numpy().astype(np.float64)


def _compute_token_signals(
    token_ids: List[int], model, tokenizer
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Extract dual importance signals from a single forward pass.

    Returns two complementary signals per token:

    1. Log-probabilities  →  self-information (surprisal)
       I(x_i) = -log P(x_i | x_{<i})
       Measures how unexpected each token is given left context.

    2. Causal attention influence
       A(x_i) = mean_{l,h} Σ_{j>i} attn[l,h,j,i]
       For each token i, sums how much every future position j>i
       attends to it, averaged over all layers and attention heads.

    Together these approximate the pointwise mutual information
    between each token and the rest of the sequence — capturing
    both how *informative* a token is (surprisal) and how much
    subsequent tokens *depend* on it (attention influence).

    A number like '50' in '$50 bill' may have low surprisal
    (predictable token) but extremely high attention influence
    (downstream 'change' computation depends on it). Pure
    self-information drops it; dual scoring preserves it.
    """
    import torch

    device = next(model.parameters()).device
    input_ids = torch.tensor([token_ids], device=device)
    seq_len = len(token_ids)

    with torch.no_grad():
        outputs = model(input_ids, output_attentions=True)
        logits = outputs.logits
        attentions = outputs.attentions  # tuple of [1, n_heads, seq, seq]

    # ── Signal 1: log-probabilities ──
    shift_logits = logits[0, :-1, :]
    shift_labels = input_ids[0, 1:]
    log_probs_all = torch.nn.functional.log_softmax(shift_logits, dim=-1)
    token_log_probs = log_probs_all.gather(
        1, shift_labels.unsqueeze(1)
    ).squeeze(1)

    log_probs = torch.zeros(seq_len, device=device)
    log_probs[1:] = token_log_probs
    log_probs[0] = token_log_probs.min()

    # ── Signal 2: causal attention influence ──
    # Stack layers, drop batch dim → [n_layers, n_heads, seq, seq]
    attn_stack = torch.stack(attentions)[:, 0, :, :, :]
    # Average over layers and heads → [seq, seq]
    # Entry [j, i] = avg attention from query position j to key position i
    avg_attn = attn_stack.mean(dim=(0, 1))
    # For each key position i, sum attention received from
    # strictly future query positions j > i
    causal_mask = torch.triu(
        torch.ones(seq_len, seq_len, device=device), diagonal=1
    )
    causal_influence = (avg_attn * causal_mask).sum(dim=0)

    return (
        log_probs.cpu().numpy().astype(np.float64),
        causal_influence.cpu().numpy().astype(np.float64),
    )


def _rank_normalize(values: np.ndarray) -> np.ndarray:
    """
    Non-parametric rank normalization to [0, 1].

    Maps any score distribution to uniform ranks via the
    probability integral transform.  Distribution-free,
    robust to outliers, and completely language-agnostic.
    """
    n = len(values)
    if n <= 1:
        return np.ones_like(values)
    return np.argsort(np.argsort(values)).astype(np.float64) / (n - 1)


def compress(
    text: str,
    ratio: float = 0.5,
    method: str = "self_info",
    model_name: str = "distilgpt2",
    strategy: str = "ratio",
    preserve_first: int = 1,
    preserve_last: int = 0,
    alpha: float = 0.5,
    tokenizer=None,
    scoring_model=None,
) -> CompressResult:
    """
    Compress a text prompt by removing redundant tokens.

    Args:
        text: Input text to compress.
        ratio: Fraction of tokens to keep (0.3 = keep 30%, i.e. 3.3x compression).
        method: Scoring method:
            - "self_info": pure self-information (surprisal). Fast, good baseline.
            - "influence": dual-signal scoring — combines self-information with
              causal attention influence via non-parametric rank fusion.
              Uses both how *informative* a token is AND how much future
              tokens *depend* on it. Substantially better quality at
              aggressive compression ratios (≤0.3). ~Same latency as
              self_info (attention weights come free from the forward pass).
        model_name: HuggingFace model for scoring (default: distilgpt2, ~82M params).
        strategy: Selection strategy — "ratio", "topk", "threshold", "percentile", "iqr".
        preserve_first: Always keep this many tokens from the start (attention sinks).
        preserve_last: Always keep this many tokens from the end (recency).
        alpha: Balance between self-information and attention influence (0–1).
            Only used with method="influence". Default 0.5 (equal weighting).
            Higher α → emphasise surprisal. Lower α → emphasise downstream
            attention dependency.
        tokenizer: Pre-loaded tokenizer (skips loading).
        scoring_model: Pre-loaded model (skips loading).

    Returns:
        CompressResult with compressed text and metadata.

    Example:
        >>> import tokenpress
        >>> result = tokenpress.compress("Your long prompt...", ratio=0.3, method="influence")
        >>> print(result.compressed_text)
        >>> print(f"Saved {result.tokens_saved} tokens ({result.savings_percentage:.0f}%)")
    """
    # Load model
    if scoring_model is not None and tokenizer is not None:
        model, tok = scoring_model, tokenizer
    else:
        model, tok = _get_model_and_tokenizer(
            model_name, need_attentions=(method == "influence")
        )

    # Tokenize
    token_ids = tok.encode(text)
    n_tokens = len(token_ids)

    # Short text — nothing to compress
    if n_tokens <= max(preserve_first + preserve_last + 1, 3):
        return CompressResult(
            compressed_text=text,
            original_tokens=n_tokens,
            compressed_tokens=n_tokens,
            ratio=1.0,
            kept_indices=list(range(n_tokens)),
        )

    # Score tokens
    if method == "self_info":
        log_probs = _compute_log_probs(token_ids, model, tok)
        scores = _core.py_score_self_information(log_probs.tolist())
    elif method == "influence":
        # Dual-signal scoring: self-information × causal attention influence
        # Single forward pass extracts both signals
        log_probs, causal_influence = _compute_token_signals(
            token_ids, model, tok
        )
        # Self-information from Rust core
        self_info = np.array(
            _core.py_score_self_information(log_probs.tolist())
        )
        # Non-parametric rank fusion — distribution-free, language-agnostic
        # Rank normalization maps any distribution to uniform [0, 1]
        # and is invariant to monotonic transformations of either signal.
        si_ranks = _rank_normalize(self_info)
        ai_ranks = _rank_normalize(causal_influence)
        # Linear combination of rank statistics:
        #   S(x_i) = α · R_I(x_i) + (1-α) · R_A(x_i)
        # where R_I = surprisal rank, R_A = attention influence rank.
        # This approximates pointwise mutual information between each
        # token and the remainder of the sequence.
        scores = (alpha * si_ranks + (1 - alpha) * ai_ranks).tolist()
    else:
        raise ValueError(
            f"Unknown scoring method: {method!r}. "
            f"Supported: 'self_info', 'influence'."
        )

    # Select tokens to keep (Rust core)
    kept_indices = _core.py_compress(
        scores,
        ratio,
        strategy,
        preserve_first,
        preserve_last,
    )

    # Reconstruct text
    kept_tokens = [token_ids[i] for i in kept_indices]
    compressed_text = tok.decode(kept_tokens, skip_special_tokens=False)

    return CompressResult(
        compressed_text=compressed_text,
        original_tokens=n_tokens,
        compressed_tokens=len(kept_indices),
        ratio=len(kept_indices) / n_tokens,
        kept_indices=kept_indices,
        token_scores=np.array(scores),
    )


def compress_batch(
    texts: List[str],
    ratio: float = 0.5,
    method: str = "self_info",
    model_name: str = "distilgpt2",
    strategy: str = "ratio",
    preserve_first: int = 1,
    preserve_last: int = 0,
) -> List[CompressResult]:
    """
    Compress multiple texts. Scoring is sequential (model inference),
    but selection is parallel via Rust's rayon.

    Args:
        texts: List of texts to compress.
        (other args same as compress())

    Returns:
        List of CompressResult, one per input text.
    """
    model, tok = _get_model_and_tokenizer(model_name)

    # Tokenize all
    all_token_ids = [tok.encode(t) for t in texts]

    # Score all (sequential — model inference is the bottleneck)
    all_log_probs = [
        _compute_log_probs(ids, model, tok) for ids in all_token_ids
    ]

    # Convert to scores
    all_scores = _core.py_batch_score_self_information(
        [lp.tolist() for lp in all_log_probs]
    )

    # Batch select (parallel in Rust)
    all_kept = _core.py_batch_compress(
        all_scores,
        ratio,
        strategy,
        preserve_first,
        preserve_last,
    )

    # Reconstruct
    results = []
    for text, token_ids, scores, kept_indices in zip(
        texts, all_token_ids, all_scores, all_kept
    ):
        n = len(token_ids)
        if not kept_indices:
            kept_indices = list(range(n))

        kept_tokens = [token_ids[i] for i in kept_indices]
        compressed_text = tok.decode(kept_tokens, skip_special_tokens=False)

        results.append(
            CompressResult(
                compressed_text=compressed_text,
                original_tokens=n,
                compressed_tokens=len(kept_indices),
                ratio=len(kept_indices) / n if n > 0 else 1.0,
                kept_indices=kept_indices,
                token_scores=np.array(scores),
            )
        )

    return results
