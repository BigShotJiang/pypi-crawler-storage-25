"""CLI for tokenpress."""

from __future__ import annotations

import argparse
import sys
import time


def main():
    parser = argparse.ArgumentParser(
        prog="tokenpress",
        description="Blazing-fast LLM token compression. Reduce API costs by 2-5x.",
    )
    subparsers = parser.add_subparsers(dest="command")

    # ─── compress ────────────────────────────────────────
    p_compress = subparsers.add_parser("compress", help="Compress text or a file")
    p_compress.add_argument("input", help="Text string or path to a file")
    p_compress.add_argument(
        "-r", "--ratio", type=float, default=0.5,
        help="Keep ratio (0.3 = keep 30%%, default: 0.5)",
    )
    p_compress.add_argument(
        "-m", "--model", default="distilgpt2",
        help="Scoring model (default: distilgpt2)",
    )
    p_compress.add_argument(
        "-s", "--strategy", default="ratio",
        choices=["ratio", "topk", "threshold", "percentile", "iqr"],
        help="Selection strategy (default: ratio)",
    )
    p_compress.add_argument(
        "-o", "--output", default=None,
        help="Output file (default: stdout)",
    )

    # ─── bench ───────────────────────────────────────────
    p_bench = subparsers.add_parser("bench", help="Benchmark compression")
    p_bench.add_argument("input", help="Text string or path to a file")
    p_bench.add_argument(
        "-m", "--model", default="distilgpt2",
        help="Scoring model (default: distilgpt2)",
    )

    # ─── version ─────────────────────────────────────────
    subparsers.add_parser("version", help="Show version")

    args = parser.parse_args()

    if args.command == "version":
        from tokenpress._core import __version__
        print(f"tokenpress {__version__}")

    elif args.command == "compress":
        _cmd_compress(args)

    elif args.command == "bench":
        _cmd_bench(args)

    else:
        parser.print_help()


def _read_input(text_or_path: str) -> str:
    """Read from file if path exists, otherwise treat as literal text."""
    import os
    if os.path.isfile(text_or_path):
        with open(text_or_path, "r", encoding="utf-8") as f:
            return f.read()
    return text_or_path


def _cmd_compress(args):
    from tokenpress.compress import compress

    text = _read_input(args.input)

    t0 = time.perf_counter()
    result = compress(
        text,
        ratio=args.ratio,
        model_name=args.model,
        strategy=args.strategy,
    )
    elapsed = time.perf_counter() - t0

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(result.compressed_text)

    print(f"  {result.original_tokens} -> {result.compressed_tokens} tokens "
          f"({result.compression_ratio:.1f}x reduction)", file=sys.stderr)
    print(f"  Saved {result.tokens_saved} tokens "
          f"({result.savings_percentage:.0f}%)", file=sys.stderr)
    print(f"  Time: {elapsed*1000:.0f}ms", file=sys.stderr)

    if not args.output:
        print(result.compressed_text)


def _cmd_bench(args):
    from tokenpress.compress import compress

    text = _read_input(args.input)

    print(f"\n  TokenPress Benchmark")
    print(f"  {'='*50}")
    print(f"  Model: {args.model}")
    print(f"  Input length: ~{len(text.split())} words\n")

    header = f"  {'Ratio':<10} {'Kept':<10} {'Removed':<10} {'Time':<10} {'X Smaller':<10}"
    print(header)
    print(f"  {'-'*50}")

    for ratio in [0.7, 0.5, 0.3, 0.2, 0.1]:
        t0 = time.perf_counter()
        result = compress(
            text, ratio=ratio, model_name=args.model, strategy="ratio",
        )
        elapsed = time.perf_counter() - t0

        print(
            f"  {ratio:<10.0%} "
            f"{result.compressed_tokens:<10} "
            f"{result.tokens_saved:<10} "
            f"{elapsed*1000:<10.0f}ms "
            f"{result.compression_ratio:<10.1f}x"
        )

    print()


if __name__ == "__main__":
    main()
