from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


Difficulty = Literal["easy", "medium", "hard"]
Split = Literal["train", "test"]


class BenchmarkExample(BaseModel):
    example_id: str
    task_family: str
    prompt: str
    context: str | None = None
    reference_answer: str | None = None
    difficulty: Difficulty = "easy"
    split: Split = "train"
    rubric: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)
