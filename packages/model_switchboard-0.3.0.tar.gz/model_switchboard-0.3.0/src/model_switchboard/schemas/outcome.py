from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class RouteDecision(BaseModel):
    request_id: str
    chosen_route: str
    route_reason: dict[str, Any] = Field(default_factory=dict)
    predicted_success: dict[str, float] = Field(default_factory=dict)
    predicted_risk: dict[str, float] = Field(default_factory=dict)
    predicted_latency_ms: dict[str, float] = Field(default_factory=dict)
    predicted_cost_usd: dict[str, float] = Field(default_factory=dict)


class ExecutionOutcome(BaseModel):
    request_id: str
    route: str
    provider: str
    model_name: str
    output_text: str
    tokens_in: int
    tokens_out: int
    latency_ms: int
    cost_usd: float
    verifier_passed: bool = False
    quality_score: float | None = None
    escalated: bool = False
    escalation_target: str | None = None
    failure_reason: str | None = None
