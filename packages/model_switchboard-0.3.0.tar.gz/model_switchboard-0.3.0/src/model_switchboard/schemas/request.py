from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class RequestRecord(BaseModel):
    request_id: str
    prompt: str
    context: str | None = None
    task_family: Literal["classification", "extraction", "summarization", "drafting"]
    metadata: dict[str, Any] = Field(default_factory=dict)
    quality_sla: float = 0.8
    latency_sla_ms: int = 5000
    risk_tier: Literal["low", "medium", "high"] = "low"
