"""Named policy presets for the ModelSwitchboard CLI.

Presets bind a small set of understandable routing defaults behind a single
name (``balanced``, ``cost_saver``, ``quality_max``, ``frontier_guarded``) so a
user can run a reasonable policy without hand-tuning the underlying knobs.

Rules:
- Presets are optional. If a CLI invocation does not pass ``--policy-preset``,
  behavior is identical to a plain run.
- Explicit CLI arguments always override preset-derived defaults.
- Presets currently influence the learned-router ``min_success_threshold`` and
  whether the escalated router runs by default. If no learned model is
  provided, preset defaults for learned/escalated are ignored (we do not try
  to bootstrap a model the user did not ask for).
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class PolicyPreset:
    name: str
    min_success_threshold: float
    enable_learned: bool
    enable_escalated: bool
    description: str


PRESETS: dict[str, PolicyPreset] = {
    "cost_saver": PolicyPreset(
        name="cost_saver",
        min_success_threshold=0.35,
        enable_learned=True,
        enable_escalated=False,
        description="Prefer cheap routes aggressively; escalation disabled.",
    ),
    "balanced": PolicyPreset(
        name="balanced",
        min_success_threshold=0.5,
        enable_learned=True,
        enable_escalated=True,
        description="Learned pick at the 0.5 threshold with escalation on failure.",
    ),
    "quality_max": PolicyPreset(
        name="quality_max",
        min_success_threshold=0.85,
        enable_learned=True,
        enable_escalated=True,
        description="High threshold with full escalation; skews toward frontier.",
    ),
    "frontier_guarded": PolicyPreset(
        name="frontier_guarded",
        min_success_threshold=0.95,
        enable_learned=True,
        enable_escalated=True,
        description="Only trust sub-frontier routes when success is very confident.",
    ),
}


PRESET_NAMES: tuple[str, ...] = tuple(PRESETS.keys())


def resolve_preset(name: str) -> PolicyPreset:
    if name not in PRESETS:
        raise ValueError(
            f"Unknown policy preset {name!r}. "
            f"Expected one of: {', '.join(PRESET_NAMES)}"
        )
    return PRESETS[name]
