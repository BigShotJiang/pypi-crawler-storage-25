"""Hand-written routing rules keyed on extracted features.

The heuristic router is the floor that every learned router must beat. The rules
read as an ordered sequence of domain decisions: high-risk work goes straight to
``frontier``; long-context and security-sensitive work goes to ``mid``; simple
small-token classification/extraction goes to ``small``; everything else falls
through to ``mid``.

Route reasons are exposed as constants so the audit trail is first-class rather
than a set of magic strings scattered across the codebase.
"""

from __future__ import annotations

from model_switchboard.features.extractors import RouteFeatures


# Reason tags. Kept as string constants (not enums) so they serialize as-is into
# CSV output and stay greppable from audit artifacts.
REASON_HIGH_RISK = "high_risk"
REASON_LONG_CONTEXT = "long_context"
REASON_SECURITY_SENSITIVE = "security_sensitive"
REASON_HIGH_REASONING = "high_reasoning"
REASON_SIMPLE_LOW_TOKEN = "simple_task_low_token"
REASON_SHORT_SUMMARY = "short_summary"
REASON_DEFAULT_MID = "default_mid"


def _reason(tag: str) -> dict[str, str]:
    return {"reason": tag}


def choose_heuristic_route(features: RouteFeatures) -> tuple[str, dict]:
    """Return ``(route, {"reason": ...})`` for the given feature row.

    The rules are evaluated top-to-bottom; the first match wins. Ordering
    encodes the policy: guardrails first, then capacity constraints, then
    cost-optimizing happy paths, then a conservative default.
    """
    if features.risk_tier_num >= 2:
        return "frontier", _reason(REASON_HIGH_RISK)

    if features.requires_long_context:
        return "mid", _reason(REASON_LONG_CONTEXT)

    if features.security_keyword_hits > 0:
        return "mid", _reason(REASON_SECURITY_SENSITIVE)

    if features.reasoning_keyword_hits >= 2:
        return "frontier", _reason(REASON_HIGH_REASONING)

    if features.task_family in {"classification", "extraction"} and features.total_tokens < 800:
        return "small", _reason(REASON_SIMPLE_LOW_TOKEN)

    if features.task_family == "summarization" and features.total_tokens < 3000:
        return "small", _reason(REASON_SHORT_SUMMARY)

    return "mid", _reason(REASON_DEFAULT_MID)
