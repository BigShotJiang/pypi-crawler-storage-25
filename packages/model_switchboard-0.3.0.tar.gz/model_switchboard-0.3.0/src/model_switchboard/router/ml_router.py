"""Learned success predictor.

Per-route binary classifiers: for each route ``r``, predict ``P(success | x, r)``
where ``x`` is the feature row produced by ``model_switchboard.features.extractors``.

Design notes:

- **Fitted-state guard.** ``predict_success`` refuses to run before ``fit``.
- **Single-class tolerance.** If a route column is all-0 or all-1 in the training
  data, the learner cannot fit; we substitute a ``_ConstantPredictor`` that
  returns the constant label as a probability, so the rest of the pipeline
  does not branch.
- **Model family.** Phase 7 added a ``model_family`` argument.
  ``"logistic"`` (default) uses ``LogisticRegression`` with ``StandardScaler +
  OneHotEncoder`` preprocessing. ``"gbm"`` uses ``GradientBoostingClassifier``;
  GBM is scale-invariant so we pass numerics through untouched and still
  one-hot encode categoricals.
- **Deterministic.** ``random_state=42``. Training rows are passed in deterministic
  order by the caller.
- **Persistence.** ``save`` / ``load`` use ``joblib`` and store metadata alongside
  the per-route models so downstream code can detect schema drift on reload.
"""

from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from model_switchboard.features.extractors import RouteFeatures


# Numeric columns fed into the per-route classifier.
NUMERIC_COLS: list[str] = [
    # Pre-Phase-7
    "prompt_tokens",
    "context_tokens",
    "total_tokens",
    "instruction_count",
    "question_count",
    "has_structured_output_request",
    "reasoning_keyword_hits",
    "security_keyword_hits",
    "requires_long_context",
    "risk_tier_num",
    # Phase 7 additions
    "difficulty_num",
    "rubric_token_count",
    "rubric_min_length",
    "rubric_max_length",
    "rubric_band_width",
    "context_to_prompt_ratio",
    "has_comparison_cue",
    "has_summary_cue",
    "has_extraction_cue",
]

CATEGORICAL_COLS: list[str] = [
    "task_family",
    "task_family_difficulty",  # Phase 7 composite
]

FEATURE_COLS: list[str] = NUMERIC_COLS + CATEGORICAL_COLS

ARTIFACT_VERSION = 2

ModelFamily = Literal["logistic", "gbm"]
SUPPORTED_FAMILIES: tuple[str, ...] = ("logistic", "gbm")


class _ConstantPredictor:
    """Fallback stand-in for sklearn estimators on single-class labels."""

    def __init__(self, value: float) -> None:
        if value not in (0.0, 1.0):
            raise ValueError(f"_ConstantPredictor expects 0.0 or 1.0, got {value!r}")
        self.value = float(value)

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        n = len(X)
        p_pos = 0.99 if self.value == 1.0 else 0.01
        out = np.zeros((n, 2), dtype=float)
        out[:, 1] = p_pos
        out[:, 0] = 1.0 - p_pos
        return out


class SuccessPredictor:
    """Per-route success probability model."""

    def __init__(self, model_family: ModelFamily = "logistic") -> None:
        if model_family not in SUPPORTED_FAMILIES:
            raise ValueError(
                f"Unsupported model_family={model_family!r}; "
                f"expected one of {SUPPORTED_FAMILIES}"
            )
        self.model_family: ModelFamily = model_family
        self.models: dict[str, Pipeline | _ConstantPredictor] = {}
        self.meta: dict[str, Any] = {}

    # --- construction ---------------------------------------------------

    def _make_pipeline(self) -> Pipeline:
        if self.model_family == "logistic":
            pre = ColumnTransformer(
                transformers=[
                    ("num", StandardScaler(), NUMERIC_COLS),
                    ("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL_COLS),
                ]
            )
            clf = LogisticRegression(random_state=42, max_iter=1000)
        else:  # gbm
            # GradientBoostingClassifier is scale-invariant; leave numerics
            # as-is so integer/count features keep their resolution. One-hot
            # encode categoricals because GBC needs numeric input.
            pre = ColumnTransformer(
                transformers=[
                    ("num", "passthrough", NUMERIC_COLS),
                    ("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL_COLS),
                ]
            )
            clf = GradientBoostingClassifier(random_state=42)

        return Pipeline(
            steps=[
                ("preprocessor", pre),
                ("clf", clf),
            ]
        )

    # --- lifecycle ------------------------------------------------------

    @property
    def fitted(self) -> bool:
        return bool(self.models)

    def fit(self, df: pd.DataFrame, route_label_col_map: dict[str, str]) -> None:
        missing = [c for c in FEATURE_COLS if c not in df.columns]
        if missing:
            raise ValueError(f"training frame missing columns: {missing}")

        X = df[FEATURE_COLS]
        label_distribution: dict[str, dict[str, int]] = {}

        for route, label_col in route_label_col_map.items():
            if label_col not in df.columns:
                raise ValueError(f"label column {label_col!r} missing for route {route!r}")
            y = df[label_col].astype(int)
            positives = int(y.sum())
            negatives = int(len(y) - positives)
            label_distribution[route] = {"positives": positives, "negatives": negatives}

            n_classes = y.nunique()
            if n_classes < 2:
                self.models[route] = _ConstantPredictor(value=float(y.iloc[0]))
            else:
                pipe = self._make_pipeline()
                pipe.fit(X, y)
                self.models[route] = pipe

        self.meta = {
            "artifact_version": ARTIFACT_VERSION,
            "fitted_at": datetime.now(tz=timezone.utc).isoformat(),
            "n_train": int(len(df)),
            "feature_cols": list(FEATURE_COLS),
            "label_distribution": label_distribution,
            "model_family": self.model_family,
        }

    # --- inference ------------------------------------------------------

    def predict_success(self, features: RouteFeatures) -> dict[str, float]:
        if not self.fitted:
            raise RuntimeError("SuccessPredictor is not fitted; call fit() or load() first.")
        row = pd.DataFrame([asdict(features)])[FEATURE_COLS]
        preds: dict[str, float] = {}
        for route, model in self.models.items():
            proba = model.predict_proba(row)[0][1]
            preds[route] = float(proba)
        return preds

    # --- persistence ----------------------------------------------------

    def save(self, path: str | Path) -> Path:
        if not self.fitted:
            raise RuntimeError("refusing to save an unfitted SuccessPredictor")
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({"models": self.models, "meta": self.meta}, target)
        return target

    @classmethod
    def load(cls, path: str | Path) -> "SuccessPredictor":
        artifact = joblib.load(path)
        if not isinstance(artifact, dict) or "models" not in artifact or "meta" not in artifact:
            raise ValueError(f"Unrecognised SuccessPredictor artifact at {path}")
        meta = artifact["meta"]
        feature_cols = list(meta.get("feature_cols") or [])
        missing = [c for c in FEATURE_COLS if c not in feature_cols]
        if missing:
            raise ValueError(
                f"Artifact at {path} is missing feature columns required by the current code: {missing}"
            )

        family = str(meta.get("model_family") or "logistic")
        if family not in SUPPORTED_FAMILIES:
            raise ValueError(
                f"Artifact at {path} declares unsupported model_family={family!r}"
            )
        instance = cls(model_family=family)  # type: ignore[arg-type]
        instance.models = artifact["models"]
        instance.meta = meta
        return instance
