from __future__ import annotations

from model_switchboard.schemas.outcome import RouteDecision
from model_switchboard.schemas.request import RequestRecord


ROUTE_ORDER = ["small", "mid", "frontier"]


def choose_route_from_predictions(
    req: RequestRecord,
    predicted_success: dict[str, float],
    predicted_risk: dict[str, float],
    predicted_latency_ms: dict[str, float],
    predicted_cost_usd: dict[str, float],
    min_success_threshold: float,
    max_risk_threshold: float,
) -> RouteDecision:
    """Constraint-aware cheapest-above-threshold chooser.

    Phase 4 does not yet predict risk or latency; this function is retained for
    the broader Phase 5 policy surface. For Phase 4 see ``choose_learned_route``.
    """
    candidates: list[str] = []

    for route in ROUTE_ORDER:
        if predicted_success[route] < min_success_threshold:
            continue
        if predicted_risk[route] > max_risk_threshold:
            continue
        if predicted_latency_ms[route] > req.latency_sla_ms:
            continue
        candidates.append(route)

    chosen = min(candidates, key=lambda r: predicted_cost_usd[r]) if candidates else "frontier"

    return RouteDecision(
        request_id=req.request_id,
        chosen_route=chosen,
        route_reason={"policy": "constraint_min_cost"},
        predicted_success=predicted_success,
        predicted_risk=predicted_risk,
        predicted_latency_ms=predicted_latency_ms,
        predicted_cost_usd=predicted_cost_usd,
    )


def choose_learned_route(
    predicted_success: dict[str, float],
    cost_by_route: dict[str, float],
    min_success_threshold: float = 0.5,
) -> tuple[str, dict]:
    """Pick the cheapest route whose predicted success clears the threshold.

    Fallback: if no route qualifies, return ``frontier`` with reason
    ``"no_route_meets_threshold"``. Choice is deterministic for fixed inputs:
    ``ROUTE_ORDER`` guarantees a stable tiebreak, and ``min`` respects insertion
    order on equal keys.
    """
    missing_success = [r for r in ROUTE_ORDER if r not in predicted_success]
    if missing_success:
        raise ValueError(f"predicted_success missing routes: {missing_success}")
    missing_cost = [r for r in ROUTE_ORDER if r not in cost_by_route]
    if missing_cost:
        raise ValueError(f"cost_by_route missing routes: {missing_cost}")

    candidates = [r for r in ROUTE_ORDER if predicted_success[r] >= min_success_threshold]
    if not candidates:
        return "frontier", {"reason": "no_route_meets_threshold"}

    chosen = min(candidates, key=lambda r: cost_by_route[r])
    return chosen, {"reason": "learned_min_cost_above_threshold"}
