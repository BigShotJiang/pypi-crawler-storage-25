from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from model_switchboard.schemas.request import RequestRecord


@dataclass
class RouteFeatures:
    # --- Pre-Phase-7 signals (kept byte-identical) ---
    prompt_tokens: int
    context_tokens: int
    total_tokens: int
    task_family: str
    instruction_count: int
    question_count: int
    has_structured_output_request: int
    reasoning_keyword_hits: int
    security_keyword_hits: int
    requires_long_context: int
    risk_tier_num: int
    # --- Phase 7 additions ---
    difficulty_num: int
    rubric_token_count: int
    rubric_min_length: int
    rubric_max_length: int
    rubric_band_width: int
    context_to_prompt_ratio: float
    has_comparison_cue: int
    has_summary_cue: int
    has_extraction_cue: int
    task_family_difficulty: str


REASONING_PATTERNS = [
    r"\bcompare\b",
    r"\banalyze\b",
    r"\bevaluate\b",
    r"\btradeoff\b",
    r"\bjustify\b",
    r"\bwhy\b",
]

SECURITY_PATTERNS = [
    r"\bpii\b",
    r"\bsecret[s]?\b",
    r"\bcredential[s]?\b",
    r"\btoken[s]?\b",
    r"\bsecurity\b",
    r"\bcompliance\b",
]

# Phase 7 cue sets. Lowercased substring checks — deterministic and cheap.
COMPARISON_CUES = (
    "compare",
    " vs ",
    " versus ",
    "tradeoff",
    "trade-off",
    "side-by-side",
)

SUMMARY_CUES = (
    "summari",      # summarize / summarise / summary
    "bullets",
    "bullet points",
    "tl;dr",
    "tldr",
    "executive summary",
)

EXTRACTION_CUES = (
    "extract",
    "identify",
    "return the",
    "return only",
    "find the",
    "pull out",
)

DIFFICULTY_MAP: dict[str, int] = {"easy": 0, "medium": 1, "hard": 2}


def rough_token_count(text: str | None) -> int:
    if not text:
        return 0
    return max(1, len(text) // 4)


def _cue_hit(prompt_lower: str, cues: tuple[str, ...]) -> int:
    return int(any(cue in prompt_lower for cue in cues))


def _rubric_from_hint(hint: dict[str, Any]) -> dict[str, Any]:
    rubric = hint.get("rubric") or {}
    if not isinstance(rubric, dict):
        return {}
    return rubric


def extract_features(req: RequestRecord) -> RouteFeatures:
    prompt = req.prompt or ""
    context = req.context or ""
    prompt_lower = prompt.lower()

    prompt_tokens = rough_token_count(prompt)
    context_tokens = rough_token_count(context)

    instruction_count = len(re.findall(r"\n|- |\d+\.", prompt))
    question_count = prompt.count("?")
    has_structured_output_request = int(
        any(k in prompt_lower for k in ["json", "yaml", "table", "schema", "csv", "bullet"])
    )
    reasoning_keyword_hits = sum(
        len(re.findall(pattern, prompt_lower)) for pattern in REASONING_PATTERNS
    )
    security_keyword_hits = sum(
        len(re.findall(pattern, f"{prompt} {context}".lower())) for pattern in SECURITY_PATTERNS
    )
    requires_long_context = int(context_tokens > 5000)

    risk_tier_num = {"low": 0, "medium": 1, "high": 2}[req.risk_tier]

    # --- Phase 7 signals ---
    hint: dict[str, Any] = {}
    meta_hint = (req.metadata or {}).get("hint")
    if isinstance(meta_hint, dict):
        hint = meta_hint

    difficulty_raw = str(hint.get("difficulty") or "easy").lower()
    difficulty_num = DIFFICULTY_MAP.get(difficulty_raw, 0)

    rubric = _rubric_from_hint(hint)
    must_contain = rubric.get("must_contain") or []
    required_elements = rubric.get("required_elements") or []
    rubric_token_count = len(must_contain) + len(required_elements)
    rubric_min_length = int(rubric.get("min_length") or 0)
    rubric_max_length = int(rubric.get("max_length") or 0)
    rubric_band_width = max(0, rubric_max_length - rubric_min_length)

    context_to_prompt_ratio = float(context_tokens) / float(max(prompt_tokens, 1))

    has_comparison_cue = _cue_hit(prompt_lower, COMPARISON_CUES)
    has_summary_cue = _cue_hit(prompt_lower, SUMMARY_CUES)
    has_extraction_cue = _cue_hit(prompt_lower, EXTRACTION_CUES)

    task_family_difficulty = f"{req.task_family}:{difficulty_raw}"

    return RouteFeatures(
        prompt_tokens=prompt_tokens,
        context_tokens=context_tokens,
        total_tokens=prompt_tokens + context_tokens,
        task_family=req.task_family,
        instruction_count=instruction_count,
        question_count=question_count,
        has_structured_output_request=has_structured_output_request,
        reasoning_keyword_hits=reasoning_keyword_hits,
        security_keyword_hits=security_keyword_hits,
        requires_long_context=requires_long_context,
        risk_tier_num=risk_tier_num,
        difficulty_num=difficulty_num,
        rubric_token_count=rubric_token_count,
        rubric_min_length=rubric_min_length,
        rubric_max_length=rubric_max_length,
        rubric_band_width=rubric_band_width,
        context_to_prompt_ratio=context_to_prompt_ratio,
        has_comparison_cue=has_comparison_cue,
        has_summary_cue=has_summary_cue,
        has_extraction_cue=has_extraction_cue,
        task_family_difficulty=task_family_difficulty,
    )
