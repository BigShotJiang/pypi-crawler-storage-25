from __future__ import annotations

from model_switchboard.eval.scorers import (
    score_classification,
    score_drafting,
    score_extraction,
    score_summarization,
)
from model_switchboard.schemas.benchmark import BenchmarkExample


def verify_output(example: BenchmarkExample, output_text: str) -> tuple[bool, float]:
    if example.task_family == "classification":
        score = score_classification(example, output_text)
    elif example.task_family == "extraction":
        score = score_extraction(example, output_text)
    elif example.task_family == "summarization":
        score = score_summarization(example, output_text)
    elif example.task_family == "drafting":
        score = score_drafting(example, output_text)
    else:
        raise ValueError(f"Unsupported task_family={example.task_family}")

    return score >= 0.7, score
