from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import pandas as pd
from tqdm import tqdm

from model_switchboard.eval.verifier import verify_output
from model_switchboard.execution.escalation import escalation_chain
from model_switchboard.execution.executor import Executor
from model_switchboard.features.extractors import RouteFeatures, extract_features
from model_switchboard.router.heuristic import choose_heuristic_route
from model_switchboard.router.ml_router import SuccessPredictor
from model_switchboard.router.policy import choose_learned_route
from model_switchboard.schemas.benchmark import BenchmarkExample
from model_switchboard.schemas.outcome import ExecutionOutcome
from model_switchboard.schemas.request import RequestRecord


ROUTES: tuple[str, ...] = ("small", "mid", "frontier")


@dataclass(frozen=True)
class _RouteAttempt:
    """Outcome of a single provider call plus its verifier result."""

    outcome: ExecutionOutcome
    passed: bool
    score: float


@dataclass
class _EscalationTrace:
    """Running record of an escalated router's attempts against one example.

    The trace carries just enough state to produce a single reportable row:
    the initial route, the full attempt chain, cumulative cost/latency, and
    the final verifier outcome (regardless of whether it passed).
    """

    initial_route: str
    initial_passed: bool
    routes_attempted: list[str] = field(default_factory=list)
    total_cost_usd: float = 0.0
    total_latency_ms: int = 0
    final_outcome: ExecutionOutcome | None = None
    final_passed: bool = False
    final_score: float = 0.0

    def record(self, route: str, attempt: _RouteAttempt) -> None:
        self.routes_attempted.append(route)
        self.total_cost_usd += float(attempt.outcome.cost_usd)
        self.total_latency_ms += int(attempt.outcome.latency_ms)
        self.final_outcome = attempt.outcome
        self.final_passed = attempt.passed
        self.final_score = attempt.score

    @property
    def final_route(self) -> str:
        return self.routes_attempted[-1]

    @property
    def escalation_count(self) -> int:
        return len(self.routes_attempted) - 1


def _build_request(ex: BenchmarkExample) -> RequestRecord:
    hint: dict[str, Any] = {
        "example_id": ex.example_id,
        "difficulty": ex.difficulty,
        "reference_answer": ex.reference_answer,
        "rubric": dict(ex.rubric or {}),
    }
    return RequestRecord(
        request_id=ex.example_id,
        prompt=ex.prompt,
        context=ex.context,
        task_family=ex.task_family,  # type: ignore[arg-type]
        metadata={"hint": hint},
    )


def _feature_columns(features: RouteFeatures) -> dict[str, Any]:
    """Feature columns surfaced to the all-routes CSV.

    Kept in one place so the benchmark output, the training pivot, and the
    learned router all agree on the schema.
    """
    return {
        "prompt_tokens": features.prompt_tokens,
        "context_tokens": features.context_tokens,
        "total_tokens": features.total_tokens,
        "instruction_count": features.instruction_count,
        "question_count": features.question_count,
        "has_structured_output_request": features.has_structured_output_request,
        "reasoning_keyword_hits": features.reasoning_keyword_hits,
        "security_keyword_hits": features.security_keyword_hits,
        "requires_long_context": features.requires_long_context,
        "risk_tier_num": features.risk_tier_num,
        "difficulty_num": features.difficulty_num,
        "rubric_token_count": features.rubric_token_count,
        "rubric_min_length": features.rubric_min_length,
        "rubric_max_length": features.rubric_max_length,
        "rubric_band_width": features.rubric_band_width,
        "context_to_prompt_ratio": features.context_to_prompt_ratio,
        "has_comparison_cue": features.has_comparison_cue,
        "has_summary_cue": features.has_summary_cue,
        "has_extraction_cue": features.has_extraction_cue,
        "task_family_difficulty": features.task_family_difficulty,
    }


class BenchmarkRunner:
    def __init__(self, executor: Executor) -> None:
        self.executor = executor

    # --- attempt primitives ---------------------------------------------

    def _attempt_route(self, route: str, req: RequestRecord, ex: BenchmarkExample) -> _RouteAttempt:
        outcome = self.executor.run(route, req)
        passed, score = verify_output(ex, outcome.output_text)
        return _RouteAttempt(outcome=outcome, passed=passed, score=score)

    # --- row assembly ---------------------------------------------------

    @staticmethod
    def _base_row(ex: BenchmarkExample) -> dict[str, Any]:
        return {
            "example_id": ex.example_id,
            "task_family": ex.task_family,
            "difficulty": ex.difficulty,
        }

    @staticmethod
    def _learned_prediction_columns(predicted: dict[str, float]) -> dict[str, float]:
        return {
            "predicted_success_small": predicted["small"],
            "predicted_success_mid": predicted["mid"],
            "predicted_success_frontier": predicted["frontier"],
        }

    def _route_attempt_row(
        self,
        ex: BenchmarkExample,
        route: str,
        features: RouteFeatures,
        attempt: _RouteAttempt,
    ) -> dict[str, Any]:
        outcome = attempt.outcome
        return {
            **self._base_row(ex),
            "route": route,
            "prompt": ex.prompt,
            "context": ex.context,
            **_feature_columns(features),
            "output_text": outcome.output_text,
            "tokens_in": outcome.tokens_in,
            "tokens_out": outcome.tokens_out,
            "latency_ms": outcome.latency_ms,
            "cost_usd": outcome.cost_usd,
            "quality_score": attempt.score,
            "success": int(attempt.passed),
        }

    # --- router runs ----------------------------------------------------

    def run_all_routes(self, examples: list[BenchmarkExample]) -> pd.DataFrame:
        """Run every example against every route; one row per (example, route)."""
        rows: list[dict] = []
        for ex in tqdm(examples, desc="Running all routes"):
            req = _build_request(ex)
            features = extract_features(req)
            for route in ROUTES:
                attempt = self._attempt_route(route, req, ex)
                rows.append(self._route_attempt_row(ex, route, features, attempt))
        return pd.DataFrame(rows)

    def run_heuristic_router(self, examples: list[BenchmarkExample]) -> pd.DataFrame:
        rows: list[dict] = []
        for ex in tqdm(examples, desc="Running heuristic router"):
            req = _build_request(ex)
            features = extract_features(req)
            route, reason = choose_heuristic_route(features)
            attempt = self._attempt_route(route, req, ex)

            rows.append(
                {
                    **self._base_row(ex),
                    "chosen_route": route,
                    "route_reason": reason["reason"],
                    "cost_usd": attempt.outcome.cost_usd,
                    "latency_ms": attempt.outcome.latency_ms,
                    "quality_score": attempt.score,
                    "success": int(attempt.passed),
                }
            )
        return pd.DataFrame(rows)

    def run_learned_router(
        self,
        examples: list[BenchmarkExample],
        predictor: SuccessPredictor,
        cost_by_route: dict[str, float],
        min_success_threshold: float = 0.5,
    ) -> pd.DataFrame:
        """Learned path: feature -> predict -> policy -> execute."""
        self._require_fitted(predictor, "run_learned_router")
        rows: list[dict] = []

        for ex in tqdm(examples, desc="Running learned router"):
            req = _build_request(ex)
            features = extract_features(req)
            predicted = predictor.predict_success(features)
            route, reason = choose_learned_route(
                predicted_success=predicted,
                cost_by_route=cost_by_route,
                min_success_threshold=min_success_threshold,
            )
            attempt = self._attempt_route(route, req, ex)

            rows.append(
                {
                    **self._base_row(ex),
                    "chosen_route": route,
                    "route_reason": reason["reason"],
                    **self._learned_prediction_columns(predicted),
                    "cost_usd": attempt.outcome.cost_usd,
                    "latency_ms": attempt.outcome.latency_ms,
                    "quality_score": attempt.score,
                    "success": int(attempt.passed),
                }
            )
        return pd.DataFrame(rows)

    def run_escalated_router(
        self,
        examples: list[BenchmarkExample],
        predictor: SuccessPredictor,
        cost_by_route: dict[str, float],
        min_success_threshold: float = 0.5,
    ) -> pd.DataFrame:
        """Learned initial pick plus verifier-driven retries along the escalation chain.

        On verifier failure the runner walks ``escalation_chain(route)`` until a
        pass or chain exhaustion. Cost and latency are cumulative across
        attempts; the reported row reflects the last attempted route, regardless
        of pass/fail.
        """
        self._require_fitted(predictor, "run_escalated_router")
        rows: list[dict] = []

        for ex in tqdm(examples, desc="Running escalated router"):
            req = _build_request(ex)
            features = extract_features(req)
            predicted = predictor.predict_success(features)
            initial_route, _reason = choose_learned_route(
                predicted_success=predicted,
                cost_by_route=cost_by_route,
                min_success_threshold=min_success_threshold,
            )

            trace = self._walk_escalation_chain(initial_route, req, ex)
            rows.append(self._escalation_row(ex, trace, predicted))

        return pd.DataFrame(rows)

    # --- escalation helpers --------------------------------------------

    def _walk_escalation_chain(
        self,
        initial_route: str,
        req: RequestRecord,
        ex: BenchmarkExample,
    ) -> _EscalationTrace:
        first = self._attempt_route(initial_route, req, ex)
        trace = _EscalationTrace(initial_route=initial_route, initial_passed=first.passed)
        trace.record(initial_route, first)

        if first.passed:
            return trace

        for next_route in escalation_chain(initial_route):
            retry = self._attempt_route(next_route, req, ex)
            trace.record(next_route, retry)
            if retry.passed:
                break

        return trace

    def _escalation_row(
        self,
        ex: BenchmarkExample,
        trace: _EscalationTrace,
        predicted: dict[str, float],
    ) -> dict[str, Any]:
        return {
            **self._base_row(ex),
            "initial_route": trace.initial_route,
            "final_route": trace.final_route,
            "attempted_routes": "|".join(trace.routes_attempted),
            "escalation_count": trace.escalation_count,
            "escalated": trace.escalation_count > 0,
            "verifier_pass_initial": bool(trace.initial_passed),
            **self._learned_prediction_columns(predicted),
            "cost_usd": trace.total_cost_usd,
            "latency_ms": trace.total_latency_ms,
            "quality_score": trace.final_score,
            "success": int(trace.final_passed),
        }

    @staticmethod
    def _require_fitted(predictor: SuccessPredictor, caller: str) -> None:
        if not predictor.fitted:
            raise RuntimeError(f"SuccessPredictor must be fitted before {caller}")

    # --- persistence ----------------------------------------------------

    @staticmethod
    def save(df: pd.DataFrame, path: str | Path) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(path, index=False)
