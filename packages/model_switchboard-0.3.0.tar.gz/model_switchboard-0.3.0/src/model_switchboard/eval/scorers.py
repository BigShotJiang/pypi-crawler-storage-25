from __future__ import annotations

from typing import Any

from model_switchboard.schemas.benchmark import BenchmarkExample


def _rubric(example: BenchmarkExample) -> dict[str, Any]:
    return dict(example.rubric or {})


def _must_contain_ratio(output: str, tokens: list[str]) -> float:
    if not tokens:
        return 1.0
    hits = sum(1 for t in tokens if str(t).lower() in output.lower())
    return hits / len(tokens)


def _length_band_score(output: str, min_length: int, max_length: int | None) -> float:
    n = len(output.strip())
    if min_length and n < min_length:
        return max(0.0, n / max(min_length, 1))
    if max_length and n > max_length:
        # penalise gently for going long, not zero.
        overshoot = (n - max_length) / max(max_length, 1)
        return max(0.3, 1.0 - min(overshoot, 0.7))
    return 1.0


def score_classification(example: BenchmarkExample, output_text: str) -> float:
    if not example.reference_answer:
        return 0.0
    return 1.0 if example.reference_answer.lower().strip() in output_text.lower() else 0.0


def score_extraction(example: BenchmarkExample, output_text: str) -> float:
    if not example.reference_answer:
        return 0.0
    expected = example.reference_answer.lower().strip()
    got = output_text.lower().strip()
    if expected in got:
        return 1.0
    if any(tok in got for tok in expected.split()):
        return 0.5
    return 0.0


def score_summarization(example: BenchmarkExample, output_text: str) -> float:
    """Rubric-driven: must_contain coverage × length-band score."""
    if not output_text.strip():
        return 0.0

    rubric = _rubric(example)
    must_contain: list[str] = list(rubric.get("must_contain") or [])
    min_length: int = int(rubric.get("min_length") or 0)
    max_length = rubric.get("max_length")
    max_length_int: int | None = int(max_length) if max_length is not None else None

    coverage = _must_contain_ratio(output_text, must_contain)
    length = _length_band_score(output_text, min_length, max_length_int)
    return round(coverage * length, 4)


def score_drafting(example: BenchmarkExample, output_text: str) -> float:
    """Rubric-driven: required-element coverage × length-band score."""
    if not output_text.strip():
        return 0.0

    rubric = _rubric(example)
    required_elements: list[str] = list(
        rubric.get("required_elements") or rubric.get("must_contain") or []
    )
    min_length: int = int(rubric.get("min_length") or 0)
    max_length = rubric.get("max_length")
    max_length_int: int | None = int(max_length) if max_length is not None else None

    coverage = _must_contain_ratio(output_text, required_elements)
    length = _length_band_score(output_text, min_length, max_length_int)
    return round(coverage * length, 4)
