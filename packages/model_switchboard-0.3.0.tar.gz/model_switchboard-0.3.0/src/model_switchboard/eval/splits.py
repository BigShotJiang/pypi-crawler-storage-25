"""Stratified train/test splitting keyed on (task_family, difficulty)."""

from __future__ import annotations

import random
from collections import defaultdict
from collections.abc import Iterable

from model_switchboard.schemas.benchmark import BenchmarkExample


def stratified_split(
    examples: Iterable[BenchmarkExample],
    test_ratio: float = 0.25,
    seed: int = 42,
) -> tuple[set[str], set[str]]:
    """Return (train_ids, test_ids) stratified by (task_family, difficulty).

    - Deterministic for a fixed seed.
    - Every cell with >= 2 examples contributes at least one row to each split.
    - Cells with a single example go to train.
    - Per cell, ``round(n * test_ratio)`` examples go to test (min 1 when n >= 2,
      max ``n - 1`` so train is never empty for the cell).
    """
    items = list(examples)
    if not items:
        raise ValueError("stratified_split requires at least one example")

    if not 0 < test_ratio < 1:
        raise ValueError(f"test_ratio must be in (0, 1), got {test_ratio!r}")

    rng = random.Random(seed)
    buckets: dict[tuple[str, str], list[BenchmarkExample]] = defaultdict(list)
    for ex in items:
        buckets[(ex.task_family, str(ex.difficulty))].append(ex)

    train_ids: set[str] = set()
    test_ids: set[str] = set()

    # Sort cell keys for stable iteration order before RNG sampling.
    for key in sorted(buckets.keys()):
        cell = sorted(buckets[key], key=lambda e: e.example_id)
        n = len(cell)

        if n == 1:
            train_ids.add(cell[0].example_id)
            continue

        target_test = max(1, min(n - 1, round(n * test_ratio)))
        indices = list(range(n))
        rng.shuffle(indices)
        test_slice = {indices[i] for i in range(target_test)}

        for i, ex in enumerate(cell):
            if i in test_slice:
                test_ids.add(ex.example_id)
            else:
                train_ids.add(ex.example_id)

    return train_ids, test_ids
