from __future__ import annotations

from rich.console import Console

console = Console()


def log_info(message: str) -> None:
    console.print(f"[bold cyan][switchboard][/bold cyan] {message}")
