from __future__ import annotations


ESCALATION_ORDER = {
    "small": ["mid", "frontier"],
    "mid": ["frontier"],
    "frontier": [],
}


def escalation_chain(route: str) -> list[str]:
    return ESCALATION_ORDER.get(route, [])
