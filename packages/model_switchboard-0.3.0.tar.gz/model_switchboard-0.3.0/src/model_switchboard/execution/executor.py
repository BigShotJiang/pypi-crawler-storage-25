from __future__ import annotations

from typing import Any

from model_switchboard.providers.base import BaseLLMProvider
from model_switchboard.schemas.outcome import ExecutionOutcome
from model_switchboard.schemas.request import RequestRecord


class Executor:
    def __init__(self, providers: dict[str, BaseLLMProvider]) -> None:
        self.providers = providers

    def run(self, route: str, req: RequestRecord) -> ExecutionOutcome:
        provider = self.providers[route]

        # The mock provider uses the hint to simulate route-sensitive quality.
        # Real providers accept **kwargs and ignore it, so this is backward-safe.
        hint: dict[str, Any] = req.metadata.get("hint") or {}

        resp = provider.generate(prompt=req.prompt, context=req.context, hint=hint)

        return ExecutionOutcome(
            request_id=req.request_id,
            route=route,
            provider=resp.provider,
            model_name=resp.model_name,
            output_text=resp.output_text,
            tokens_in=resp.tokens_in,
            tokens_out=resp.tokens_out,
            latency_ms=resp.latency_ms,
            cost_usd=resp.cost_usd,
        )
