from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from model_switchboard.config import load_yaml
from model_switchboard.execution.executor import Executor
from model_switchboard.providers.base import BaseLLMProvider
from model_switchboard.providers.gemini_provider import GeminiProvider
from model_switchboard.providers.grok_provider import GrokProvider
from model_switchboard.providers.mock_provider import MockProvider
from model_switchboard.providers.ollama_provider import OllamaProvider
from model_switchboard.providers.openai_provider import OpenAIProvider


PROVIDER_REGISTRY: dict[str, type[BaseLLMProvider]] = {
    "gemini": GeminiProvider,
    "grok": GrokProvider,
    "mock": MockProvider,
    "ollama": OllamaProvider,
    "openai": OpenAIProvider,
}


def _coerce_provider_kwargs(route_name: str, raw_cfg: Mapping[str, Any]) -> dict[str, Any]:
    provider_key = str(raw_cfg["provider"]).lower()
    provider_kwargs = dict(raw_cfg)
    provider_kwargs.pop("provider", None)

    provider_kwargs.setdefault("provider_name", provider_key)
    provider_kwargs.setdefault("cost_per_1k_input_tokens", 0.0)
    provider_kwargs.setdefault("cost_per_1k_output_tokens", 0.0)
    provider_kwargs.setdefault("max_context_tokens", 0)
    return provider_kwargs


def build_provider(route_name: str, raw_cfg: Mapping[str, Any]) -> BaseLLMProvider:
    if "provider" not in raw_cfg:
        raise ValueError(f"Missing provider for route '{route_name}'.")

    provider_key = str(raw_cfg["provider"]).lower()
    provider_cls = PROVIDER_REGISTRY.get(provider_key)
    if provider_cls is None:
        supported = ", ".join(sorted(PROVIDER_REGISTRY))
        raise ValueError(
            f"Unsupported provider '{provider_key}' for route '{route_name}'. "
            f"Supported providers: {supported}."
        )

    return provider_cls(**_coerce_provider_kwargs(route_name, raw_cfg))


def build_executor_from_config(path: str) -> Executor:
    config = load_yaml(path)
    model_configs = config.get("models")
    if not isinstance(model_configs, Mapping) or not model_configs:
        raise ValueError(f"Expected a non-empty 'models' mapping in {path}.")

    providers = {
        route_name: build_provider(route_name, route_cfg)
        for route_name, route_cfg in model_configs.items()
    }
    return Executor(providers=providers)
