from __future__ import annotations

import hashlib
import random
import time
from typing import Any

from model_switchboard.providers.base import BaseLLMProvider, ProviderResponse


# Per-(model, difficulty) failure rates. Deterministic via hash of (model, example_id).
# Tuned so small passes easy tasks, frontier handles most hard ones — giving the router
# a real quality contrast to optimise against.
FAIL_RATE: dict[str, dict[str, float]] = {
    "small-sim": {"easy": 0.00, "medium": 0.40, "hard": 0.90},
    "mid-sim": {"easy": 0.00, "medium": 0.05, "hard": 0.50},
    "frontier-sim": {"easy": 0.00, "medium": 0.00, "hard": 0.10},
}

BASE_LATENCY_MS: dict[str, int] = {
    "small-sim": 400,
    "mid-sim": 900,
    "frontier-sim": 1800,
}

TIER_TAG: dict[str, str] = {
    "small-sim": "[small-route-response]",
    "mid-sim": "[mid-route-response]",
    "frontier-sim": "[frontier-route-response]",
}


def _deterministic_roll(model_name: str, example_id: str) -> float:
    """Return a stable float in [0, 1) from (model_name, example_id)."""
    digest = hashlib.sha256(f"{model_name}::{example_id}".encode("utf-8")).digest()
    # First 8 bytes as unsigned int, normalised to [0, 1).
    value = int.from_bytes(digest[:8], "big")
    return value / 2**64


def _compose_pass_output(
    tier_tag: str,
    prompt: str,
    reference_answer: str | None,
    must_contain: list[str],
    min_length: int,
) -> str:
    parts: list[str] = [tier_tag]
    if reference_answer:
        parts.append(f"Answer: {reference_answer}.")
    for token in must_contain:
        parts.append(str(token))
    parts.append(prompt[:120])
    text = " ".join(parts).strip()
    if len(text) < min_length:
        text = text + " " + ("filler " * ((min_length - len(text)) // 7 + 1))
    return text.strip()


def _compose_fail_output(tier_tag: str) -> str:
    return f"{tier_tag} unable to complete."


class MockProvider(BaseLLMProvider):
    def generate(self, prompt: str, context: str | None = None, **kwargs: Any) -> ProviderResponse:
        hint: dict[str, Any] = kwargs.get("hint") or {}
        example_id = str(hint.get("example_id") or prompt[:32])
        difficulty = str(hint.get("difficulty") or "easy").lower()
        reference_answer = hint.get("reference_answer")
        rubric: dict[str, Any] = hint.get("rubric") or {}
        # Union of must_contain (summarization) and required_elements (drafting).
        # Pre-Phase-6, this list was must_contain only, which meant drafting
        # pass outputs never carried the tokens the scorer looks for. Order
        # preserved; duplicates removed.
        _raw_tokens: list[str] = list(rubric.get("must_contain") or []) + list(
            rubric.get("required_elements") or []
        )
        _seen: set[str] = set()
        must_contain: list[str] = []
        for _token in _raw_tokens:
            _key = str(_token)
            if _key not in _seen:
                _seen.add(_key)
                must_contain.append(_key)
        min_length: int = int(rubric.get("min_length") or 0)

        joined = f"{prompt}\n{context or ''}".strip()
        tokens_in = max(1, len(joined) // 4)

        tier_tag = TIER_TAG.get(self.model_name, "[unknown-route-response]")
        fail_rate = FAIL_RATE.get(self.model_name, {}).get(difficulty, 0.0)
        roll = _deterministic_roll(self.model_name, example_id)
        failed = roll < fail_rate

        if failed:
            output = _compose_fail_output(tier_tag)
        else:
            output = _compose_pass_output(
                tier_tag=tier_tag,
                prompt=prompt,
                reference_answer=reference_answer,
                must_contain=must_contain,
                min_length=min_length,
            )

        tokens_out = max(20, len(output) // 4)
        base_latency = BASE_LATENCY_MS.get(self.model_name, 1000)
        latency_ms = base_latency + random.randint(-100, 100)
        time.sleep(latency_ms / 1000.0 * 0.001)
        cost = self.estimate_cost(tokens_in=tokens_in, tokens_out=tokens_out)

        return ProviderResponse(
            provider=self.provider_name,
            model_name=self.model_name,
            output_text=output,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            latency_ms=latency_ms,
            cost_usd=cost,
        )
