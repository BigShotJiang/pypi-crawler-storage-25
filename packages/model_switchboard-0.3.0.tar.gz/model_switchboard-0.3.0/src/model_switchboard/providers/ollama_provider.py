from __future__ import annotations

import json
import time
import urllib.error
import urllib.request

from model_switchboard.providers.base import BaseLLMProvider, ProviderResponse


class OllamaProvider(BaseLLMProvider):
    def __init__(
        self,
        provider_name: str,
        model_name: str,
        cost_per_1k_input_tokens: float,
        cost_per_1k_output_tokens: float,
        max_context_tokens: int,
        *,
        host: str = "http://127.0.0.1:11434",
        route_name: str | None = None,
        system_prompt: str | None = None,
        timeout_seconds: int = 120,
    ) -> None:
        super().__init__(
            provider_name=provider_name,
            model_name=model_name,
            cost_per_1k_input_tokens=cost_per_1k_input_tokens,
            cost_per_1k_output_tokens=cost_per_1k_output_tokens,
            max_context_tokens=max_context_tokens,
        )
        self.host = host.rstrip("/")
        self.route_name = route_name
        self.system_prompt = system_prompt
        self.timeout_seconds = timeout_seconds

    def generate(self, prompt: str, context: str | None = None, **kwargs) -> ProviderResponse:
        full_prompt = prompt if context is None else f"Context:\n{context}\n\nTask:\n{prompt}"
        payload: dict[str, object] = {
            "model": self.model_name,
            "prompt": full_prompt,
            "stream": False,
        }
        if self.system_prompt:
            payload["system"] = self.system_prompt

        request = urllib.request.Request(
            f"{self.host}/api/generate",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        started = time.perf_counter()
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                raw = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Ollama request failed with HTTP {exc.code}: {body}") from exc

        latency_ms = int((time.perf_counter() - started) * 1000)
        if raw.get("total_duration"):
            latency_ms = int(raw["total_duration"] / 1_000_000)

        output_text = str(raw.get("response", "")).strip()
        tokens_in = int(raw.get("prompt_eval_count") or max(1, len(full_prompt) // 4))
        tokens_out = int(raw.get("eval_count") or max(1, len(output_text) // 4))
        cost = self.estimate_cost(tokens_in=tokens_in, tokens_out=tokens_out)

        return ProviderResponse(
            provider=self.provider_name,
            model_name=self.model_name,
            output_text=output_text,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            latency_ms=latency_ms,
            cost_usd=cost,
        )
