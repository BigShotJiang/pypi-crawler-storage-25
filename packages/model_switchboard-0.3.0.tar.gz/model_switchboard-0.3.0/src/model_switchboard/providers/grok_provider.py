from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request

from model_switchboard.providers.base import BaseLLMProvider, ProviderResponse


class GrokProvider(BaseLLMProvider):
    def __init__(
        self,
        provider_name: str,
        model_name: str,
        cost_per_1k_input_tokens: float,
        cost_per_1k_output_tokens: float,
        max_context_tokens: int,
        *,
        api_key_env: str = "XAI_API_KEY",
        api_key: str | None = None,
        base_url: str = "https://api.x.ai/v1",
        route_name: str | None = None,
        system_prompt: str | None = None,
        timeout_seconds: int = 120,
    ) -> None:
        super().__init__(
            provider_name=provider_name,
            model_name=model_name,
            cost_per_1k_input_tokens=cost_per_1k_input_tokens,
            cost_per_1k_output_tokens=cost_per_1k_output_tokens,
            max_context_tokens=max_context_tokens,
        )
        self.api_key = api_key or os.environ.get(api_key_env) or os.environ.get("GROK_API_KEY")
        if not self.api_key:
            raise RuntimeError(
                f"Missing API key for route '{route_name or model_name}'. "
                f"Set {api_key_env} or provide api_key in the model config."
            )

        self.base_url = base_url.rstrip("/")
        self.system_prompt = system_prompt
        self.timeout_seconds = timeout_seconds

    def generate(self, prompt: str, context: str | None = None, **kwargs) -> ProviderResponse:
        full_prompt = prompt if context is None else f"Context:\n{context}\n\nTask:\n{prompt}"
        messages: list[dict[str, str]] = []
        if self.system_prompt:
            messages.append({"role": "system", "content": self.system_prompt})
        messages.append({"role": "user", "content": full_prompt})

        payload = {
            "model": self.model_name,
            "messages": messages,
        }
        request = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )

        started = time.perf_counter()
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                raw = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Grok API request failed with HTTP {exc.code}: {body}") from exc

        latency_ms = int((time.perf_counter() - started) * 1000)
        choices = raw.get("choices") or []
        if not choices:
            raise RuntimeError(f"Grok API returned no choices: {raw}")

        message = choices[0].get("message", {})
        content = message.get("content", "")
        if isinstance(content, list):
            output_text = "".join(
                item.get("text", "") for item in content if isinstance(item, dict)
            ).strip()
        else:
            output_text = str(content).strip()

        usage = raw.get("usage", {})
        tokens_in = int(usage.get("prompt_tokens") or max(1, len(full_prompt) // 4))
        tokens_out = int(usage.get("completion_tokens") or max(1, len(output_text) // 4))
        cost = self.estimate_cost(tokens_in=tokens_in, tokens_out=tokens_out)

        return ProviderResponse(
            provider=self.provider_name,
            model_name=self.model_name,
            output_text=output_text,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            latency_ms=latency_ms,
            cost_usd=cost,
        )
