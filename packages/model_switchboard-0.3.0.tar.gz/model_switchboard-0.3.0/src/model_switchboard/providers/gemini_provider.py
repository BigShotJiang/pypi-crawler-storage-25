from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request

from model_switchboard.providers.base import BaseLLMProvider, ProviderResponse


class GeminiProvider(BaseLLMProvider):
    def __init__(
        self,
        provider_name: str,
        model_name: str,
        cost_per_1k_input_tokens: float,
        cost_per_1k_output_tokens: float,
        max_context_tokens: int,
        *,
        api_key_env: str = "GEMINI_API_KEY",
        api_key: str | None = None,
        base_url: str = "https://generativelanguage.googleapis.com/v1beta",
        route_name: str | None = None,
        system_prompt: str | None = None,
        timeout_seconds: int = 120,
    ) -> None:
        super().__init__(
            provider_name=provider_name,
            model_name=model_name,
            cost_per_1k_input_tokens=cost_per_1k_input_tokens,
            cost_per_1k_output_tokens=cost_per_1k_output_tokens,
            max_context_tokens=max_context_tokens,
        )
        self.api_key = api_key or os.environ.get(api_key_env)
        if not self.api_key:
            raise RuntimeError(
                f"Missing API key for route '{route_name or model_name}'. "
                f"Set {api_key_env} or provide api_key in the model config."
            )

        self.base_url = base_url.rstrip("/")
        self.system_prompt = system_prompt
        self.timeout_seconds = timeout_seconds

    def _endpoint(self) -> str:
        model_path = self.model_name
        if not model_path.startswith("models/"):
            model_path = f"models/{model_path}"
        return f"{self.base_url}/{model_path}:generateContent"

    def generate(self, prompt: str, context: str | None = None, **kwargs) -> ProviderResponse:
        user_prompt = prompt if context is None else f"Context:\n{context}\n\nTask:\n{prompt}"
        payload: dict[str, object] = {
            "contents": [{"parts": [{"text": user_prompt}]}],
        }
        if self.system_prompt:
            payload["systemInstruction"] = {"parts": [{"text": self.system_prompt}]}

        request = urllib.request.Request(
            self._endpoint(),
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "x-goog-api-key": self.api_key,
            },
            method="POST",
        )

        started = time.perf_counter()
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                raw = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Gemini API request failed with HTTP {exc.code}: {body}") from exc

        latency_ms = int((time.perf_counter() - started) * 1000)
        candidates = raw.get("candidates") or []
        if not candidates:
            raise RuntimeError(f"Gemini API returned no candidates: {raw}")

        parts = candidates[0].get("content", {}).get("parts", [])
        output_text = "".join(part.get("text", "") for part in parts if isinstance(part, dict)).strip()

        usage = raw.get("usageMetadata", {})
        tokens_in = int(usage.get("promptTokenCount") or max(1, len(user_prompt) // 4))
        tokens_out = int(usage.get("candidatesTokenCount") or max(1, len(output_text) // 4))
        cost = self.estimate_cost(tokens_in=tokens_in, tokens_out=tokens_out)

        return ProviderResponse(
            provider=self.provider_name,
            model_name=self.model_name,
            output_text=output_text,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            latency_ms=latency_ms,
            cost_usd=cost,
        )
