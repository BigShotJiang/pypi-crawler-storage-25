from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class ProviderResponse:
    provider: str
    model_name: str
    output_text: str
    tokens_in: int
    tokens_out: int
    latency_ms: int
    cost_usd: float


class BaseLLMProvider(ABC):
    def __init__(
        self,
        provider_name: str,
        model_name: str,
        cost_per_1k_input_tokens: float,
        cost_per_1k_output_tokens: float,
        max_context_tokens: int,
    ) -> None:
        self.provider_name = provider_name
        self.model_name = model_name
        self.cost_per_1k_input_tokens = cost_per_1k_input_tokens
        self.cost_per_1k_output_tokens = cost_per_1k_output_tokens
        self.max_context_tokens = max_context_tokens

    def estimate_cost(self, tokens_in: int, tokens_out: int) -> float:
        return (
            (tokens_in / 1000.0) * self.cost_per_1k_input_tokens
            + (tokens_out / 1000.0) * self.cost_per_1k_output_tokens
        )

    @abstractmethod
    def generate(self, prompt: str, context: str | None = None, **kwargs) -> ProviderResponse:
        raise NotImplementedError
