from __future__ import annotations

import os

from model_switchboard.providers.base import BaseLLMProvider, ProviderResponse

try:
    from openai import OpenAI
except ImportError:  # pragma: no cover
    OpenAI = None


class OpenAIProvider(BaseLLMProvider):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        if OpenAI is None:
            raise ImportError("Install model-switchboard[openai] to use OpenAIProvider.")
        self.client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

    def generate(self, prompt: str, context: str | None = None, **kwargs) -> ProviderResponse:
        full_prompt = prompt if context is None else f"Context:\n{context}\n\nTask:\n{prompt}"

        response = self.client.responses.create(
            model=self.model_name,
            input=full_prompt,
        )

        output_text = getattr(response, "output_text", "") or str(response)
        usage = getattr(response, "usage", None)

        tokens_in = getattr(usage, "input_tokens", max(1, len(full_prompt) // 4))
        tokens_out = getattr(usage, "output_tokens", max(1, len(output_text) // 4))
        latency_ms = 0
        cost = self.estimate_cost(tokens_in=tokens_in, tokens_out=tokens_out)

        return ProviderResponse(
            provider=self.provider_name,
            model_name=self.model_name,
            output_text=output_text,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            latency_ms=latency_ms,
            cost_usd=cost,
        )
