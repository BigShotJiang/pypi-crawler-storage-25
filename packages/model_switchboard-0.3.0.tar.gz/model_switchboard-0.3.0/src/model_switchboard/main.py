from __future__ import annotations

import argparse
import json
from pathlib import Path

from model_switchboard.eval.benchmark_runner import BenchmarkRunner
from model_switchboard.providers.factory import build_executor_from_config
from model_switchboard.reporting.cards import write_router_cards
from model_switchboard.reporting.manifest import write_manifest
from model_switchboard.router.ml_router import SuccessPredictor
from model_switchboard.router.presets import PRESET_NAMES, PolicyPreset, resolve_preset
from model_switchboard.schemas.benchmark import BenchmarkExample
from model_switchboard.telemetry.logger import log_info


SPLIT_CHOICES = ("train", "test", "all")
BOOL_CHOICES = ("true", "false")
DEFAULT_MIN_SUCCESS_THRESHOLD = 0.5

# Canonical sizing for deterministic route-cost ordering in learned routing.
_CANONICAL_TOKENS_IN = 400
_CANONICAL_TOKENS_OUT = 200


def load_examples(path: str, split: str | None = None) -> list[BenchmarkExample]:
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    examples = [BenchmarkExample(**item) for item in raw]
    if split in (None, "all"):
        return examples
    return [ex for ex in examples if ex.split == split]


def _suffixed(base: str, split: str) -> str:
    if split == "all":
        return base
    stem, _, ext = base.rpartition(".")
    if not stem:
        return f"{base}_{split}"
    return f"{stem}_{split}.{ext}"


def _cost_by_route(executor) -> dict[str, float]:
    out: dict[str, float] = {}
    for route in ("small", "mid", "frontier"):
        provider = executor.providers[route]
        out[route] = provider.estimate_cost(
            tokens_in=_CANONICAL_TOKENS_IN,
            tokens_out=_CANONICAL_TOKENS_OUT,
        )
    return out


def _run_standard_benchmarks(
    runner: BenchmarkRunner,
    examples: list[BenchmarkExample],
    output_dir: str,
    split: str,
) -> list[str]:
    all_routes_name = _suffixed("all_routes.csv", split)
    heuristic_name = _suffixed("heuristic_router.csv", split)

    log_info(f"Running all-routes benchmark (split={split}, n={len(examples)})")
    df_all = runner.run_all_routes(examples)
    runner.save(df_all, f"{output_dir}/{all_routes_name}")

    log_info(f"Running heuristic router benchmark (split={split})")
    df_heur = runner.run_heuristic_router(examples)
    runner.save(df_heur, f"{output_dir}/{heuristic_name}")

    return [all_routes_name, heuristic_name]


def _run_optional_model_benchmarks(
    runner: BenchmarkRunner,
    examples: list[BenchmarkExample],
    output_dir: str,
    split: str,
    run_learned: bool,
    run_escalated: bool,
    predictor: SuccessPredictor,
    cost_by_route: dict[str, float],
    min_success_threshold: float,
) -> list[str]:
    produced: list[str] = []

    if run_learned:
        log_info("Running learned router benchmark")
        df_learned = runner.run_learned_router(
            examples,
            predictor=predictor,
            cost_by_route=cost_by_route,
            min_success_threshold=min_success_threshold,
        )
        learned_name = _suffixed("learned_router.csv", split)
        runner.save(df_learned, f"{output_dir}/{learned_name}")
        produced.append(learned_name)

    if run_escalated:
        log_info("Running escalated router benchmark")
        df_esc = runner.run_escalated_router(
            examples,
            predictor=predictor,
            cost_by_route=cost_by_route,
            min_success_threshold=min_success_threshold,
        )
        esc_name = _suffixed("escalated_router.csv", split)
        runner.save(df_esc, f"{output_dir}/{esc_name}")
        produced.append(esc_name)

    return produced


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run ModelSwitchboard benchmarks.")
    parser.add_argument(
        "--examples-path",
        default="data/raw/benchmark_examples.json",
        help="Path to the benchmark examples JSON file.",
    )
    parser.add_argument(
        "--models-config",
        default="configs/models.yaml",
        help="Path to the models YAML config file.",
    )
    parser.add_argument(
        "--output-dir",
        default="data/results",
        help="Directory where benchmark CSV outputs should be written.",
    )
    parser.add_argument(
        "--split",
        choices=SPLIT_CHOICES,
        default="all",
        help=(
            "Which split to run. 'all' preserves Phase A filenames; 'train' and "
            "'test' suffix the output CSVs so runs do not overwrite each other."
        ),
    )
    parser.add_argument(
        "--run-learned",
        choices=BOOL_CHOICES,
        default=None,
        help=(
            "When 'true', also run the learned router and emit "
            "learned_router{_split}.csv. Requires --model-path. "
            "Default: 'false' unless overridden by --policy-preset."
        ),
    )
    parser.add_argument(
        "--model-path",
        default="data/models/success_predictor.joblib",
        help="Path to a saved SuccessPredictor joblib artifact.",
    )
    parser.add_argument(
        "--min-success-threshold",
        type=float,
        default=None,
        help=(
            "Minimum predicted P(success) for a route to qualify (learned router). "
            f"Default: {DEFAULT_MIN_SUCCESS_THRESHOLD} unless overridden by --policy-preset."
        ),
    )
    parser.add_argument(
        "--run-escalated",
        choices=BOOL_CHOICES,
        default=None,
        help=(
            "When 'true', also run the escalated router (learned pick + "
            "verifier-driven retries along the escalation chain) and emit "
            "escalated_router{_split}.csv. Requires --model-path. "
            "Default: 'false' unless overridden by --policy-preset."
        ),
    )
    parser.add_argument(
        "--policy-preset",
        choices=PRESET_NAMES,
        default=None,
        help=(
            "Named policy preset that supplies defaults for "
            "--min-success-threshold, --run-learned, and --run-escalated. "
            "Explicit CLI arguments always win."
        ),
    )
    return parser.parse_args()


def _load_routing_context(
    executor, model_path: str
) -> tuple[SuccessPredictor, dict[str, float]]:
    predictor = SuccessPredictor.load(model_path)
    cost_by_route = _cost_by_route(executor)
    return predictor, cost_by_route


def resolve_policy(args: argparse.Namespace) -> tuple[bool, bool, float, PolicyPreset | None]:
    preset = resolve_preset(args.policy_preset) if args.policy_preset else None

    run_learned = _resolve_bool(args.run_learned, preset.enable_learned if preset else False)
    run_escalated = _resolve_bool(args.run_escalated, preset.enable_escalated if preset else False)

    if args.min_success_threshold is not None:
        threshold = float(args.min_success_threshold)
    elif preset is not None:
        threshold = preset.min_success_threshold
    else:
        threshold = DEFAULT_MIN_SUCCESS_THRESHOLD

    return run_learned, run_escalated, threshold, preset


def _resolve_bool(cli_value: str | None, preset_default: bool) -> bool:
    if cli_value is None:
        return preset_default
    return cli_value == "true"


def _emit_run_artifacts(
    output_dir: str,
    split: str,
    *,
    config_path: str,
    model_path: str | None,
    threshold: float,
    preset_name: str | None,
) -> None:
    results_dir = Path(output_dir)
    cards = write_router_cards(results_dir, split)
    manifest_path = write_manifest(
        results_dir,
        split,
        config_path=config_path,
        model_path=model_path,
        threshold=threshold,
        policy_preset=preset_name,
    )
    log_info(
        f"Wrote {len(cards)} router card(s) and manifest {manifest_path.name}"
    )


def main() -> None:
    args = parse_args()
    examples = load_examples(args.examples_path, split=args.split)
    if not examples:
        raise SystemExit(
            f"No examples found at {args.examples_path} for split={args.split!r}"
        )

    run_learned, run_escalated, threshold, preset = resolve_policy(args)
    if preset is not None:
        log_info(
            f"Using policy preset {preset.name!r}: threshold={threshold}, "
            f"learned={run_learned}, escalated={run_escalated}"
        )

    executor = build_executor_from_config(args.models_config)
    runner = BenchmarkRunner(executor)
    produced = _run_standard_benchmarks(
        runner=runner,
        examples=examples,
        output_dir=args.output_dir,
        split=args.split,
    )

    model_path_used: str | None = None
    if run_learned or run_escalated:
        predictor, cost_by_route = _load_routing_context(executor, args.model_path)
        model_path_used = args.model_path
        log_info(f"Loaded learned-router model from {args.model_path}")
        produced.extend(
            _run_optional_model_benchmarks(
                runner=runner,
                examples=examples,
                output_dir=args.output_dir,
                split=args.split,
                run_learned=run_learned,
                run_escalated=run_escalated,
                predictor=predictor,
                cost_by_route=cost_by_route,
                min_success_threshold=threshold,
            )
        )

    _emit_run_artifacts(
        output_dir=args.output_dir,
        split=args.split,
        config_path=args.models_config,
        model_path=model_path_used,
        threshold=threshold,
        preset_name=preset.name if preset else None,
    )

    log_info(f"Done. Wrote results to {args.output_dir}/ ({', '.join(produced)})")


if __name__ == "__main__":
    main()
