"""Run manifest — a single JSON file that lets a results directory explain itself.

A results directory by itself is a bag of CSVs. A manifest makes it
self-describing: which routers ran, which splits were recorded, which config
and model produced it, what the row counts were, which reports have been
generated on top of it, and which version of ModelSwitchboard wrote it.

The manifest is best-effort. Optional fields are omitted when unknown rather
than serialised as ``null`` so readers can tell "not recorded" apart from
"explicitly null".
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

from model_switchboard import __version__ as switchboard_version
from model_switchboard.reporting.io import (
    ROUTER_NAMES,
    all_routes_filename,
    load_router_frames,
    router_filename,
    split_suffix,
)


MANIFEST_FILENAME = "manifest.json"

REPORT_FILE_EXTENSIONS: tuple[str, ...] = ("csv", "html", "md")


def build_manifest(
    results_dir: Path,
    split: str,
    *,
    config_path: str | None = None,
    model_path: str | None = None,
    threshold: float | None = None,
    policy_preset: str | None = None,
) -> dict[str, Any]:
    """Assemble the manifest dict for ``results_dir`` on ``split``.

    Required fields always appear. Context passed by the benchmark CLI
    (``config_path``, ``model_path``, ``threshold``, ``policy_preset``) is
    surfaced when provided and omitted otherwise.
    """
    _require_directory(results_dir)

    router_frames = load_router_frames(results_dir, split)
    all_routes_path = results_dir / all_routes_filename(split)

    manifest: dict[str, Any] = {
        "split": split,
        "results_dir": str(results_dir),
        "generated_at": _utc_now_iso(),
        "switchboard_version": switchboard_version,
        "files_present": _files_in(results_dir),
        "routers_present": list(router_frames.keys()),
        "row_counts": _row_counts(router_frames, all_routes_path),
        "source_csvs": _source_csvs(results_dir, split),
        "report_files": _report_files(results_dir, split),
    }

    _attach_optional(manifest, "config_path", config_path, str)
    _attach_optional(manifest, "model_path", model_path, str)
    _attach_optional(manifest, "threshold", threshold, float)
    _attach_optional(manifest, "policy_preset", policy_preset, str)

    return manifest


def write_manifest(
    results_dir: Path,
    split: str,
    **kwargs: Any,
) -> Path:
    """Build the manifest and write it to ``<results_dir>/manifest.json``."""
    manifest = build_manifest(results_dir, split, **kwargs)
    out_path = results_dir / MANIFEST_FILENAME
    out_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return out_path


# --- guardrails and helpers ------------------------------------------------


def _require_directory(results_dir: Path) -> None:
    if not results_dir.is_dir():
        raise FileNotFoundError(
            f"Cannot build manifest: results directory does not exist: {results_dir}"
        )


def _files_in(results_dir: Path) -> list[str]:
    return sorted(p.name for p in results_dir.iterdir() if p.is_file())


def _source_csvs(results_dir: Path, split: str) -> list[str]:
    candidates = [all_routes_filename(split)] + [router_filename(r, split) for r in ROUTER_NAMES]
    return [name for name in candidates if (results_dir / name).exists()]


def _row_counts(
    router_frames: dict[str, pd.DataFrame],
    all_routes_path: Path,
) -> dict[str, int]:
    counts: dict[str, int] = {name: int(len(df)) for name, df in router_frames.items()}
    if all_routes_path.exists():
        counts["all_routes"] = int(len(pd.read_csv(all_routes_path)))
    return counts


def _report_files(results_dir: Path, split: str) -> list[str]:
    suffix = split_suffix(split)
    candidates = [f"report{suffix}.{ext}" for ext in REPORT_FILE_EXTENSIONS]
    return [name for name in candidates if (results_dir / name).exists()]


def _attach_optional(
    manifest: dict[str, Any], key: str, value: Any, cast
) -> None:
    if value is None:
        return
    manifest[key] = cast(value)


def _utc_now_iso() -> str:
    return datetime.now(tz=timezone.utc).isoformat(timespec="seconds")
