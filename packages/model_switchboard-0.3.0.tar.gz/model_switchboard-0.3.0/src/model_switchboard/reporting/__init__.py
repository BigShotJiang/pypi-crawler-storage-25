"""Shared reporting helpers used by report_frontier, report_html, report_markdown,
compare_runs, and the router-card / manifest emitters.

The scripts under ``scripts/`` stay thin: they parse CLI args and hand work to the
routines here. Keeping the pandas logic in one place prevents subtle drift between
the text report, the HTML report, and comparison tooling.
"""

from model_switchboard.reporting.io import (
    ROUTER_NAMES,
    all_routes_filename,
    load_all_routes,
    load_router_frames,
    route_col_for,
    router_filename,
    split_suffix,
)
from model_switchboard.reporting.metrics import (
    ROUTE_TIERS,
    THRESHOLD_GRID,
    aggregate_block,
    cell_block,
    threshold_sweep,
    weak_cells,
)

__all__ = [
    "ROUTER_NAMES",
    "ROUTE_TIERS",
    "THRESHOLD_GRID",
    "aggregate_block",
    "all_routes_filename",
    "cell_block",
    "load_all_routes",
    "load_router_frames",
    "route_col_for",
    "router_filename",
    "split_suffix",
    "threshold_sweep",
    "weak_cells",
]
