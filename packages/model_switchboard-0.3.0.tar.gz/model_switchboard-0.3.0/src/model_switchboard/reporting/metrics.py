"""Pure pandas computations shared by every reporting surface.

No I/O, no side effects. Each helper takes dataframes (already loaded) and
returns a new dataframe. Keeping these pure means the HTML report, the
markdown report, ``report_frontier.py``, and ``compare_runs.py`` can all call
the same functions without fighting over CSV paths.
"""

from __future__ import annotations

import pandas as pd

from model_switchboard.reporting.io import route_col_for
from model_switchboard.router.policy import choose_learned_route


ROUTE_TIERS: tuple[str, ...] = ("small", "mid", "frontier")
AGG_NUMERIC_COLS: tuple[str, ...] = ("quality_score", "cost_usd", "latency_ms", "success")
THRESHOLD_GRID: tuple[float, ...] = (0.3, 0.5, 0.7, 0.9)

SWEEP_EMPTY_COLUMNS: tuple[str, ...] = (
    "threshold", "n", "mean_success", "mean_cost",
    "route_mix_small", "route_mix_mid", "route_mix_frontier",
)


def aggregate_block(router_frames: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """One row per router: n, mean metrics, route mix, mean escalation count."""
    rows: list[dict] = []
    for router, df in router_frames.items():
        row: dict = {"router": router, "n": int(len(df))}
        for col in AGG_NUMERIC_COLS:
            row[f"mean_{col}"] = float(df[col].mean()) if col in df.columns else float("nan")

        route_col = route_col_for(df)
        mix = df[route_col].value_counts(normalize=True).to_dict()
        for route in ROUTE_TIERS:
            row[f"route_mix_{route}"] = float(mix.get(route, 0.0))

        row["mean_escalation_count"] = (
            float(df["escalation_count"].mean()) if "escalation_count" in df.columns else float("nan")
        )
        rows.append(row)
    return pd.DataFrame(rows)


def cell_block(router_frames: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """Per ``(task_family, difficulty)`` success rate per router, with ``n``."""
    keys: set[tuple[str, str]] = set()
    for df in router_frames.values():
        keys.update(zip(df["task_family"], df["difficulty"]))

    if not keys:
        return pd.DataFrame(columns=["task_family", "difficulty", "n"])

    out: list[dict] = []
    for family, difficulty in sorted(keys):
        row: dict = {"task_family": family, "difficulty": difficulty}
        row["n"] = _cell_sample_count(router_frames, family, difficulty)
        for router, df in router_frames.items():
            cell = df[(df["task_family"] == family) & (df["difficulty"] == difficulty)]
            row[f"{router}_success_rate"] = (
                float(cell["success"].mean()) if not cell.empty else float("nan")
            )
        out.append(row)
    return pd.DataFrame(out)


def _cell_sample_count(
    router_frames: dict[str, pd.DataFrame], family: str, difficulty: str
) -> int:
    first = next(iter(router_frames.values()))
    mask = (first["task_family"] == family) & (first["difficulty"] == difficulty)
    return int(mask.sum())


def weak_cells(
    df: pd.DataFrame,
    top_n: int = 3,
) -> list[dict]:
    """Return the ``top_n`` weakest ``(task_family, difficulty)`` cells by
    success rate. The input dataframe must have ``task_family``, ``difficulty``,
    and ``success`` columns (any router's CSV qualifies).
    """
    if df.empty or "success" not in df.columns:
        return []
    grouped = (
        df.groupby(["task_family", "difficulty"])["success"]
        .agg(["mean", "size"])
        .reset_index()
        .sort_values(["mean", "size"], ascending=[True, False])
        .head(top_n)
    )
    return [
        {
            "task_family": str(row["task_family"]),
            "difficulty": str(row["difficulty"]),
            "n": int(row["size"]),
            "success_rate": float(row["mean"]),
        }
        for _, row in grouped.iterrows()
    ]


# --- threshold sweep -------------------------------------------------------


def threshold_sweep(
    learned_df: pd.DataFrame,
    all_routes_df: pd.DataFrame,
    thresholds: tuple[float, ...] = THRESHOLD_GRID,
) -> pd.DataFrame:
    """Counterfactual learned-router picks at multiple thresholds.

    Uses saved ``predicted_success_*`` columns plus the per-route outcomes in
    the all-routes CSV. No provider calls.
    """
    _require_columns(
        learned_df,
        {
            "example_id",
            "predicted_success_small",
            "predicted_success_mid",
            "predicted_success_frontier",
        },
        name="learned CSV",
    )
    _require_columns(
        all_routes_df,
        {"example_id", "route", "success", "cost_usd"},
        name="all-routes CSV",
    )

    cost_by_route = {
        route: float(all_routes_df.loc[all_routes_df["route"] == route, "cost_usd"].mean())
        for route in ROUTE_TIERS
    }
    ar_indexed = all_routes_df.set_index(["example_id", "route"])[["success", "cost_usd"]]

    rows = [
        _sweep_row_for_threshold(threshold, learned_df, ar_indexed, cost_by_route)
        for threshold in thresholds
    ]
    return pd.DataFrame(rows)


def empty_sweep() -> pd.DataFrame:
    return pd.DataFrame(columns=list(SWEEP_EMPTY_COLUMNS))


def _sweep_row_for_threshold(
    threshold: float,
    learned_df: pd.DataFrame,
    ar_indexed: pd.DataFrame,
    cost_by_route: dict[str, float],
) -> dict[str, float | int]:
    picks: list[str] = []
    successes: list[int] = []
    costs: list[float] = []

    for _, ex_row in learned_df.iterrows():
        route = _policy_pick(ex_row, cost_by_route, threshold)
        success, cost = _lookup_route_outcome(ex_row["example_id"], route, ar_indexed)
        picks.append(route)
        successes.append(success)
        costs.append(cost)

    row = _threshold_row(threshold, picks, successes, costs)
    mix = pd.Series(picks).value_counts(normalize=True).to_dict()
    for route in ROUTE_TIERS:
        row[f"route_mix_{route}"] = float(mix.get(route, 0.0))
    return row


def _policy_pick(
    ex_row: pd.Series,
    cost_by_route: dict[str, float],
    threshold: float,
) -> str:
    predicted = {
        "small": float(ex_row["predicted_success_small"]),
        "mid": float(ex_row["predicted_success_mid"]),
        "frontier": float(ex_row["predicted_success_frontier"]),
    }
    route, _reason = choose_learned_route(
        predicted_success=predicted,
        cost_by_route=cost_by_route,
        min_success_threshold=threshold,
    )
    return route


def _lookup_route_outcome(
    example_id: str,
    route: str,
    ar_indexed: pd.DataFrame,
) -> tuple[int, float]:
    key = (example_id, route)
    if key not in ar_indexed.index:
        return 0, float("nan")
    lookup = ar_indexed.loc[key]
    return int(lookup["success"]), float(lookup["cost_usd"])


def _require_columns(df: pd.DataFrame, needed: set[str], name: str) -> None:
    missing = needed - set(df.columns)
    if missing:
        raise ValueError(f"{name} missing columns: {missing}")


def _threshold_row(
    threshold: float,
    picks: list[str],
    successes: list[int],
    costs: list[float],
) -> dict[str, float | int]:
    n = len(picks)
    return {
        "threshold": float(threshold),
        "n": int(n),
        "mean_success": float(sum(successes) / n) if n else float("nan"),
        "mean_cost": float(pd.Series(costs).mean()) if n else float("nan"),
    }
