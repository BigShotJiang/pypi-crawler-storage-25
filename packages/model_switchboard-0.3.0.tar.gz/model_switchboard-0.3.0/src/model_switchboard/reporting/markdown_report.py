"""Shareable markdown summary for a results directory.

Meant for PR descriptions, issue bodies, Slack snippets, and release notes. It
leans on the same shared helpers as the HTML report and stays short — no
per-example explorer, no embedded JS. Missing routers and missing threshold
sweeps are called out honestly rather than hidden.
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from model_switchboard.reporting.io import (
    ROUTER_NAMES,
    all_routes_filename,
    load_all_routes,
    load_router_frames,
    router_filename,
    split_suffix,
)
from model_switchboard.reporting.metrics import (
    ROUTE_TIERS,
    aggregate_block,
    cell_block,
    empty_sweep,
    threshold_sweep,
    weak_cells,
)


REPORT_FILENAME_STEM = "report"


def render_report(results_dir: Path, split: str) -> tuple[str, Path]:
    router_frames = load_router_frames(results_dir, split)
    all_routes = load_all_routes(results_dir, split)
    if not router_frames and all_routes is None:
        raise SystemExit(
            f"No router or all-routes CSVs found in {results_dir} for split={split!r}."
        )

    sections = [
        _section_header(results_dir, split, router_frames),
        _section_topline(router_frames),
        _section_threshold(router_frames, all_routes),
        _section_cells(router_frames),
        _section_wins_and_regressions(router_frames),
        _section_sample_note(router_frames),
        _section_repro(results_dir, split, router_frames, all_routes),
    ]
    body = "\n\n".join(s for s in sections if s)
    out_path = results_dir / f"{REPORT_FILENAME_STEM}{split_suffix(split)}.md"
    return body, out_path


def write_report(results_dir: Path, split: str) -> Path:
    body, out_path = render_report(results_dir, split)
    out_path.write_text(body + "\n", encoding="utf-8")
    return out_path


# --- sections --------------------------------------------------------------


def _section_header(
    results_dir: Path, split: str, router_frames: dict[str, pd.DataFrame]
) -> str:
    generated = datetime.now(tz=timezone.utc).isoformat(timespec="seconds")
    routers = ", ".join(router_frames.keys()) or "none"
    return (
        f"# ModelSwitchboard run summary\n\n"
        f"- **Results directory**: `{results_dir}`\n"
        f"- **Split**: `{split}`\n"
        f"- **Generated (UTC)**: {generated}\n"
        f"- **Routers detected**: {routers}"
    )


def _section_topline(router_frames: dict[str, pd.DataFrame]) -> str:
    if not router_frames:
        return "## Topline\n\n_No router CSVs detected._"
    agg = aggregate_block(router_frames)
    columns = [
        "router", "n", "mean_success", "mean_quality_score",
        "mean_cost_usd", "mean_latency_ms",
        "route_mix_small", "route_mix_mid", "route_mix_frontier",
        "mean_escalation_count",
    ]
    available = [c for c in columns if c in agg.columns]
    return "## Topline\n\n" + _df_to_markdown(agg[available])


def _section_threshold(
    router_frames: dict[str, pd.DataFrame], all_routes: pd.DataFrame | None
) -> str:
    learned = router_frames.get("learned")
    if learned is None or all_routes is None:
        return (
            "## Threshold sweep\n\n"
            "_Learned-router CSV or all-routes CSV not present; sweep skipped._"
        )
    sweep = threshold_sweep(learned, all_routes)
    if sweep.empty:
        sweep = empty_sweep()
    return "## Threshold sweep (learned router)\n\n" + _df_to_markdown(sweep)


def _section_cells(router_frames: dict[str, pd.DataFrame]) -> str:
    if not router_frames:
        return ""
    cells = cell_block(router_frames)
    if cells.empty:
        return ""
    return "## Per-cell success rates\n\n" + _df_to_markdown(cells)


def _section_wins_and_regressions(router_frames: dict[str, pd.DataFrame]) -> str:
    if not router_frames:
        return ""
    lines: list[str] = ["## Highlights"]

    weak_source = next(iter(router_frames.values()))
    weak = weak_cells(weak_source, top_n=3)
    if weak:
        lines.append("\n**Weakest cells:**")
        for w in weak:
            lines.append(
                f"- `{w['task_family']} / {w['difficulty']}` "
                f"(n={w['n']}): success rate {w['success_rate']:.2f}"
            )

    learned = router_frames.get("learned")
    heuristic = router_frames.get("heuristic")
    if learned is not None and heuristic is not None:
        merged = learned[["example_id", "success"]].merge(
            heuristic[["example_id", "success"]],
            on="example_id",
            suffixes=("_learned", "_heuristic"),
        )
        wins = int(((merged["success_learned"] == 1) & (merged["success_heuristic"] == 0)).sum())
        losses = int(((merged["success_learned"] == 0) & (merged["success_heuristic"] == 1)).sum())
        lines.append(
            f"\n**Learned vs heuristic (n={len(merged)})**: "
            f"{wins} wins, {losses} regressions."
        )

    escalated = router_frames.get("escalated")
    if learned is not None and escalated is not None:
        merged = learned[["example_id", "success"]].merge(
            escalated[["example_id", "success"]],
            on="example_id",
            suffixes=("_learned", "_escalated"),
        )
        rescues = int(
            ((merged["success_learned"] == 0) & (merged["success_escalated"] == 1)).sum()
        )
        lines.append(f"\n**Escalation rescues learned on {rescues} examples.**")

    if len(lines) == 1:
        return ""
    return "\n".join(lines)


def _section_sample_note(router_frames: dict[str, pd.DataFrame]) -> str:
    if not router_frames:
        return ""
    sample_size = min(len(df) for df in router_frames.values())
    if sample_size >= 200:
        return ""
    return (
        "## Sample-size note\n\n"
        f"_Results are based on n={sample_size} examples per router. "
        "Interpret per-cell deltas as indicative rather than conclusive._"
    )


def _section_repro(
    results_dir: Path,
    split: str,
    router_frames: dict[str, pd.DataFrame],
    all_routes: pd.DataFrame | None,
) -> str:
    files: list[str] = []
    if all_routes is not None:
        files.append(all_routes_filename(split))
    for router in ROUTER_NAMES:
        path = results_dir / router_filename(router, split)
        if path.exists():
            files.append(path.name)

    list_lines = "\n".join(f"- `{name}`" for name in files) or "_no files_"
    return (
        "## Reproducibility\n\n"
        "This report was generated offline from saved artifacts. No provider calls were made.\n\n"
        "**Source files:**\n"
        f"{list_lines}"
    )


# --- helpers ---------------------------------------------------------------


def _df_to_markdown(df: pd.DataFrame, float_precision: int = 4) -> str:
    if df.empty:
        return "_(empty)_"
    columns = list(df.columns)
    header = "| " + " | ".join(columns) + " |"
    sep = "| " + " | ".join("---" for _ in columns) + " |"
    rows = []
    for _, row in df.iterrows():
        cells = []
        for col in columns:
            value = row[col]
            if isinstance(value, float):
                cells.append(_fmt_float(value, float_precision))
            else:
                cells.append(str(value))
        rows.append("| " + " | ".join(cells) + " |")
    return "\n".join([header, sep, *rows])


def _fmt_float(value: float, precision: int) -> str:
    if pd.isna(value):
        return "—"
    return f"{value:.{precision}f}"
