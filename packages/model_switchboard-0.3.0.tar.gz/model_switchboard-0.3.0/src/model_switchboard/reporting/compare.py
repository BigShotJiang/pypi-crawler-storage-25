"""Compare two results directories and surface aggregate and per-cell deltas.

``candidate`` is what you just ran; ``base`` is what you are comparing against.
A positive success delta means candidate beats base.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import pandas as pd

from model_switchboard.reporting.io import (
    ROUTER_NAMES,
    load_router_frames,
    router_filename,
)
from model_switchboard.reporting.metrics import (
    ROUTE_TIERS,
    aggregate_block,
    cell_block,
)


AGG_DELTA_COLS: tuple[str, ...] = (
    "mean_success",
    "mean_quality_score",
    "mean_cost_usd",
    "mean_latency_ms",
    "route_mix_small",
    "route_mix_mid",
    "route_mix_frontier",
    "mean_escalation_count",
)


@dataclass
class RunComparison:
    """Structured comparison of two run directories on a single split."""

    base_dir: Path
    candidate_dir: Path
    split: str
    routers_in_base: list[str]
    routers_in_candidate: list[str]
    routers_compared: list[str]
    routers_only_in_base: list[str]
    routers_only_in_candidate: list[str]
    aggregate_deltas: pd.DataFrame
    per_cell_deltas: pd.DataFrame
    biggest_wins: pd.DataFrame
    biggest_regressions: pd.DataFrame


def compare_runs(base_dir: Path, candidate_dir: Path, split: str) -> RunComparison:
    base_frames = load_router_frames(base_dir, split)
    candidate_frames = load_router_frames(candidate_dir, split)

    if not base_frames and not candidate_frames:
        raise SystemExit(
            f"Neither {base_dir} nor {candidate_dir} contains router CSVs for split={split!r}"
        )

    shared = [r for r in ROUTER_NAMES if r in base_frames and r in candidate_frames]
    only_base = [r for r in ROUTER_NAMES if r in base_frames and r not in candidate_frames]
    only_candidate = [r for r in ROUTER_NAMES if r in candidate_frames and r not in base_frames]

    agg_deltas = _aggregate_deltas(base_frames, candidate_frames, shared)
    cell_deltas = _per_cell_deltas(base_frames, candidate_frames, shared)
    wins, regressions = _extreme_cell_deltas(cell_deltas, shared, top_n=5)

    return RunComparison(
        base_dir=base_dir,
        candidate_dir=candidate_dir,
        split=split,
        routers_in_base=list(base_frames.keys()),
        routers_in_candidate=list(candidate_frames.keys()),
        routers_compared=shared,
        routers_only_in_base=only_base,
        routers_only_in_candidate=only_candidate,
        aggregate_deltas=agg_deltas,
        per_cell_deltas=cell_deltas,
        biggest_wins=wins,
        biggest_regressions=regressions,
    )


def _aggregate_deltas(
    base_frames: dict[str, pd.DataFrame],
    candidate_frames: dict[str, pd.DataFrame],
    shared: list[str],
) -> pd.DataFrame:
    if not shared:
        return pd.DataFrame()

    base_agg = aggregate_block({r: base_frames[r] for r in shared}).set_index("router")
    candidate_agg = aggregate_block({r: candidate_frames[r] for r in shared}).set_index("router")

    rows: list[dict] = []
    for router in shared:
        base_row = base_agg.loc[router]
        cand_row = candidate_agg.loc[router]
        row: dict = {
            "router": router,
            "n_base": int(base_row["n"]),
            "n_candidate": int(cand_row["n"]),
        }
        for col in AGG_DELTA_COLS:
            base_val = float(base_row[col]) if col in base_row.index else float("nan")
            cand_val = float(cand_row[col]) if col in cand_row.index else float("nan")
            row[f"{col}_base"] = base_val
            row[f"{col}_candidate"] = cand_val
            row[f"{col}_delta"] = cand_val - base_val
        rows.append(row)
    return pd.DataFrame(rows)


def _per_cell_deltas(
    base_frames: dict[str, pd.DataFrame],
    candidate_frames: dict[str, pd.DataFrame],
    shared: list[str],
) -> pd.DataFrame:
    if not shared:
        return pd.DataFrame()

    base_cells = cell_block({r: base_frames[r] for r in shared}).set_index(
        ["task_family", "difficulty"]
    )
    candidate_cells = cell_block({r: candidate_frames[r] for r in shared}).set_index(
        ["task_family", "difficulty"]
    )

    keys = sorted(set(base_cells.index) | set(candidate_cells.index))
    rows: list[dict] = []
    for key in keys:
        family, difficulty = key
        row: dict = {"task_family": family, "difficulty": difficulty}
        row["n_base"] = _cell_n(base_cells, key)
        row["n_candidate"] = _cell_n(candidate_cells, key)
        for router in shared:
            col = f"{router}_success_rate"
            base_val = _cell_value(base_cells, key, col)
            cand_val = _cell_value(candidate_cells, key, col)
            row[f"{router}_base"] = base_val
            row[f"{router}_candidate"] = cand_val
            row[f"{router}_delta"] = cand_val - base_val
        rows.append(row)
    return pd.DataFrame(rows)


def _cell_n(cells: pd.DataFrame, key) -> int:
    if key not in cells.index or "n" not in cells.columns:
        return 0
    return int(cells.loc[key, "n"])


def _cell_value(cells: pd.DataFrame, key, col: str) -> float:
    if key not in cells.index or col not in cells.columns:
        return float("nan")
    value = cells.loc[key, col]
    if pd.isna(value):
        return float("nan")
    return float(value)


def _extreme_cell_deltas(
    cell_deltas: pd.DataFrame, shared: list[str], top_n: int
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return ``(wins, regressions)`` as the ``top_n`` positive and negative
    per-router, per-cell deltas.
    """
    if cell_deltas.empty or not shared:
        return pd.DataFrame(), pd.DataFrame()

    flat_df = _flatten_cell_deltas(cell_deltas, shared)
    if flat_df.empty:
        return pd.DataFrame(), pd.DataFrame()

    wins = flat_df.sort_values("delta", ascending=False).head(top_n).reset_index(drop=True)
    regressions = flat_df.sort_values("delta", ascending=True).head(top_n).reset_index(drop=True)
    return wins, regressions


def _flatten_cell_deltas(cell_deltas: pd.DataFrame, shared: list[str]) -> pd.DataFrame:
    """Project the wide per-cell delta frame into one row per (cell, router)."""
    records: list[dict] = []
    for _, cell_row in cell_deltas.iterrows():
        for router in shared:
            record = _flat_delta_record(cell_row, router)
            if record is not None:
                records.append(record)
    return pd.DataFrame(records)


def _flat_delta_record(cell_row: pd.Series, router: str) -> dict | None:
    delta_col = f"{router}_delta"
    if delta_col not in cell_row.index:
        return None
    delta = cell_row[delta_col]
    if pd.isna(delta):
        return None
    return {
        "router": router,
        "task_family": cell_row["task_family"],
        "difficulty": cell_row["difficulty"],
        "n_base": int(cell_row.get("n_base", 0)),
        "n_candidate": int(cell_row.get("n_candidate", 0)),
        "base": float(cell_row[f"{router}_base"]),
        "candidate": float(cell_row[f"{router}_candidate"]),
        "delta": float(delta),
    }


# --- serialisation ---------------------------------------------------------


def to_summary_dict(cmp: RunComparison) -> dict:
    return {
        "base_dir": str(cmp.base_dir),
        "candidate_dir": str(cmp.candidate_dir),
        "split": cmp.split,
        "routers_in_base": cmp.routers_in_base,
        "routers_in_candidate": cmp.routers_in_candidate,
        "routers_compared": cmp.routers_compared,
        "routers_only_in_base": cmp.routers_only_in_base,
        "routers_only_in_candidate": cmp.routers_only_in_candidate,
        "aggregate_deltas": _df_to_records(cmp.aggregate_deltas),
        "per_cell_deltas": _df_to_records(cmp.per_cell_deltas),
        "biggest_wins": _df_to_records(cmp.biggest_wins),
        "biggest_regressions": _df_to_records(cmp.biggest_regressions),
    }


def _df_to_records(df: pd.DataFrame) -> list[dict]:
    if df.empty:
        return []
    return df.where(pd.notna(df), None).to_dict(orient="records")


def format_summary(cmp: RunComparison) -> str:
    lines: list[str] = []
    lines.append(f"base:      {cmp.base_dir}")
    lines.append(f"candidate: {cmp.candidate_dir}")
    lines.append(f"split:     {cmp.split}")
    lines.append(f"routers compared: {', '.join(cmp.routers_compared) or 'none'}")
    if cmp.routers_only_in_base:
        lines.append(f"only in base:      {', '.join(cmp.routers_only_in_base)}")
    if cmp.routers_only_in_candidate:
        lines.append(f"only in candidate: {', '.join(cmp.routers_only_in_candidate)}")

    if not cmp.routers_compared:
        lines.append("")
        lines.append("No overlapping routers to compare.")
        return "\n".join(lines)

    lines.append("")
    lines.append("=== aggregate deltas (candidate - base) ===")
    lines.append(cmp.aggregate_deltas.to_string(index=False))

    if not cmp.biggest_wins.empty:
        lines.append("")
        lines.append("=== biggest wins ===")
        lines.append(cmp.biggest_wins.to_string(index=False))

    if not cmp.biggest_regressions.empty:
        lines.append("")
        lines.append("=== biggest regressions ===")
        lines.append(cmp.biggest_regressions.to_string(index=False))
    return "\n".join(lines)
