"""Per-router card artifacts.

A router card is a small JSON payload summarising a single router's performance
on a single split. Cards are portable by design — small enough to diff by eye,
attach to a PR, or ship to a dashboard without shipping the full CSVs.

The module keeps two layers intentionally distinct:

- ``RouterCard`` is the in-memory record (immutable).
- ``to_dict`` flattens it into the wire payload written to ``*_router_card.json``.
  Optional fields are omitted from the payload rather than serialised as ``null``.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

from model_switchboard.reporting.io import (
    ROUTER_NAMES,
    load_router_frames,
    route_col_for,
    router_filename,
)
from model_switchboard.reporting.metrics import ROUTE_TIERS, weak_cells


CARD_FILENAME_SUFFIX = "_router_card.json"


@dataclass(frozen=True)
class RouterCard:
    router_name: str
    split: str
    n: int
    mean_success: float
    mean_quality_score: float
    mean_cost_usd: float
    mean_latency_ms: float
    route_mix: dict[str, float]
    mean_escalation_count: float | None
    generated_at: str
    source_file: str
    weak_cells: list[dict[str, Any]]
    notes: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "router_name": self.router_name,
            "split": self.split,
            "n": self.n,
            "mean_success": self.mean_success,
            "mean_quality_score": self.mean_quality_score,
            "mean_cost_usd": self.mean_cost_usd,
            "mean_latency_ms": self.mean_latency_ms,
            "route_mix_small": self.route_mix.get("small", 0.0),
            "route_mix_mid": self.route_mix.get("mid", 0.0),
            "route_mix_frontier": self.route_mix.get("frontier", 0.0),
            "generated_at": self.generated_at,
            "source_file": self.source_file,
            "weak_cells": self.weak_cells,
        }
        if self.mean_escalation_count is not None:
            payload["mean_escalation_count"] = self.mean_escalation_count
        if self.notes is not None:
            payload["notes"] = self.notes
        return payload


def build_card(
    router_name: str,
    df: pd.DataFrame,
    split: str,
    source_file: str,
    notes: str | None = None,
) -> RouterCard:
    """Assemble a ``RouterCard`` from one router's CSV frame.

    Fails fast if ``df`` is empty or missing the chosen-route column; those are
    structural contract violations, not soft warnings.
    """
    if df.empty:
        raise ValueError(
            f"Cannot build router card for {router_name!r}: frame is empty"
        )

    route_mix = _route_mix(df)
    return RouterCard(
        router_name=router_name,
        split=split,
        n=int(len(df)),
        mean_success=_mean(df, "success"),
        mean_quality_score=_mean(df, "quality_score"),
        mean_cost_usd=_mean(df, "cost_usd"),
        mean_latency_ms=_mean(df, "latency_ms"),
        route_mix=route_mix,
        mean_escalation_count=_optional_mean(df, "escalation_count"),
        generated_at=_utc_now_iso(),
        source_file=source_file,
        weak_cells=weak_cells(df),
        notes=notes,
    )


def write_router_cards(results_dir: Path, split: str) -> list[Path]:
    """Write one ``<router>_router_card.json`` per detected router.

    Returns the paths written. Directories with no router CSVs return an empty
    list rather than failing — the benchmark CLI always writes them after a
    successful run, but reporting tools may be pointed at directories that only
    hold an all-routes CSV, and the card emitter should skip quietly in that case.
    """
    frames = load_router_frames(results_dir, split)
    return [_write_card_for(router, df, results_dir, split) for router, df in frames.items()]


# --- helpers ---------------------------------------------------------------


def _write_card_for(
    router: str, df: pd.DataFrame, results_dir: Path, split: str
) -> Path:
    card = build_card(
        router_name=router,
        df=df,
        split=split,
        source_file=router_filename(router, split),
    )
    out_path = results_dir / f"{router}{CARD_FILENAME_SUFFIX}"
    out_path.write_text(json.dumps(card.to_dict(), indent=2), encoding="utf-8")
    return out_path


def _route_mix(df: pd.DataFrame) -> dict[str, float]:
    route_col = route_col_for(df)
    observed = df[route_col].value_counts(normalize=True).to_dict()
    return {route: float(observed.get(route, 0.0)) for route in ROUTE_TIERS}


def _mean(df: pd.DataFrame, col: str) -> float:
    return float(df[col].mean()) if col in df.columns else float("nan")


def _optional_mean(df: pd.DataFrame, col: str) -> float | None:
    return float(df[col].mean()) if col in df.columns else None


def _utc_now_iso() -> str:
    return datetime.now(tz=timezone.utc).isoformat(timespec="seconds")


# Keep ROUTER_NAMES re-exported to avoid forcing callers to chase io.py.
__all__ = [
    "ROUTER_NAMES",
    "RouterCard",
    "build_card",
    "write_router_cards",
]
