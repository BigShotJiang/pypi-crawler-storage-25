"""Static HTML report generator.

Renders a single self-contained HTML file (inline CSS and JS, no CDN, no
external assets) summarising the router outputs in a results directory. The
report is intended to open directly from disk.

The renderer is deliberately plain: a narrow layout, a neutral palette, a
compact set of tables, and inline SVG for the threshold-frontier plot. No
framework, no theme, no fonts fetched from the network.
"""

from __future__ import annotations

import html as html_lib
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from model_switchboard.reporting.io import (
    ROUTER_NAMES,
    all_routes_filename,
    load_all_routes,
    load_router_frames,
    router_filename,
    split_suffix,
)
from model_switchboard.reporting.metrics import (
    ROUTE_TIERS,
    aggregate_block,
    cell_block,
    empty_sweep,
    threshold_sweep,
)


DEFAULT_LEARNED_THRESHOLD: float = 0.5


# --- data assembly ---------------------------------------------------------


@dataclass(frozen=True)
class HtmlReportContext:
    results_dir: Path
    split: str
    generated_at: str
    router_frames: dict[str, pd.DataFrame]
    all_routes: pd.DataFrame | None
    agg: pd.DataFrame
    cells: pd.DataFrame
    sweep: pd.DataFrame


def build_context(results_dir: Path, split: str) -> HtmlReportContext:
    router_frames = load_router_frames(results_dir, split)
    if not router_frames and load_all_routes(results_dir, split) is None:
        raise SystemExit(
            f"No router or all-routes CSVs found in {results_dir} for split={split!r}."
        )

    all_routes = load_all_routes(results_dir, split)
    agg = aggregate_block(router_frames) if router_frames else pd.DataFrame()
    cells = cell_block(router_frames) if router_frames else pd.DataFrame()
    sweep = _build_sweep(router_frames, all_routes)

    return HtmlReportContext(
        results_dir=results_dir,
        split=split,
        generated_at=datetime.now(tz=timezone.utc).isoformat(timespec="seconds"),
        router_frames=router_frames,
        all_routes=all_routes,
        agg=agg,
        cells=cells,
        sweep=sweep,
    )


def _build_sweep(
    router_frames: dict[str, pd.DataFrame], all_routes: pd.DataFrame | None
) -> pd.DataFrame:
    learned = router_frames.get("learned")
    if learned is None or all_routes is None:
        return empty_sweep()
    return threshold_sweep(learned, all_routes)


# --- rendering entry point -------------------------------------------------


def render_report(results_dir: Path, split: str) -> tuple[str, Path]:
    """Return ``(html_text, output_path)``; does not write."""
    ctx = build_context(results_dir, split)
    html = _render(ctx)
    out_path = results_dir / f"report{split_suffix(split)}.html"
    return html, out_path


def write_report(results_dir: Path, split: str) -> Path:
    html, out_path = render_report(results_dir, split)
    out_path.write_text(html, encoding="utf-8")
    return out_path


# --- sections --------------------------------------------------------------


def _render(ctx: HtmlReportContext) -> str:
    sections = [
        _section_header(ctx),
        _section_topline(ctx),
        _section_router_comparison(ctx),
        _section_threshold_frontier(ctx),
        _section_cell_matrix(ctx),
        _section_example_explorer(ctx),
        _section_wins_losses(ctx),
        _section_repro(ctx),
    ]
    body = "\n".join(sections)
    return _page_shell(title=_page_title(ctx), body=body)


def _page_title(ctx: HtmlReportContext) -> str:
    split = "all splits" if ctx.split == "all" else f"split: {ctx.split}"
    return f"ModelSwitchboard report — {split}"


def _section_header(ctx: HtmlReportContext) -> str:
    routers_detected = ", ".join(ctx.router_frames.keys()) or "none"
    row_counts = _router_row_counts(ctx.router_frames)
    rows_html = "".join(
        f"<tr><td>{html_lib.escape(name)}</td><td>{n}</td></tr>"
        for name, n in row_counts.items()
    ) or "<tr><td colspan=2>no router CSVs detected</td></tr>"

    return f"""
<section class="rb-section rb-header">
  <h1>{html_lib.escape(_page_title(ctx))}</h1>
  <div class="rb-meta">
    <div><span class="rb-label">Results dir</span><span class="rb-value">{html_lib.escape(str(ctx.results_dir))}</span></div>
    <div><span class="rb-label">Generated</span><span class="rb-value">{html_lib.escape(ctx.generated_at)}</span></div>
    <div><span class="rb-label">Split</span><span class="rb-value">{html_lib.escape(ctx.split)}</span></div>
    <div><span class="rb-label">Routers detected</span><span class="rb-value">{html_lib.escape(routers_detected)}</span></div>
  </div>
  <table class="rb-table rb-row-counts">
    <thead><tr><th>router</th><th>rows</th></tr></thead>
    <tbody>{rows_html}</tbody>
  </table>
</section>
"""


def _router_row_counts(router_frames: dict[str, pd.DataFrame]) -> dict[str, int]:
    return {name: int(len(df)) for name, df in router_frames.items()}


def _section_topline(ctx: HtmlReportContext) -> str:
    if ctx.agg.empty:
        return _empty_section("Topline metrics", "No router CSVs were available.")
    return f"""
<section class="rb-section">
  <h2>Topline metrics</h2>
  {_df_to_table(ctx.agg, precision=4)}
</section>
"""


def _section_router_comparison(ctx: HtmlReportContext) -> str:
    if ctx.agg.empty:
        return ""
    comparison_cols = [
        "router", "n", "mean_success", "mean_cost_usd",
        "mean_latency_ms", "mean_quality_score",
        "route_mix_small", "route_mix_mid", "route_mix_frontier",
        "mean_escalation_count",
    ]
    existing = [c for c in comparison_cols if c in ctx.agg.columns]
    return f"""
<section class="rb-section">
  <h2>Router comparison</h2>
  <p class="rb-caption">Side-by-side view of detected routers on this split.</p>
  {_df_to_table(ctx.agg[existing], precision=4)}
</section>
"""


def _section_threshold_frontier(ctx: HtmlReportContext) -> str:
    if ctx.sweep.empty:
        return _empty_section(
            "Threshold frontier",
            "Learned-router CSV or all-routes CSV was not available; no sweep to render.",
        )

    svg = _frontier_svg(ctx.sweep, default_threshold=DEFAULT_LEARNED_THRESHOLD)
    return f"""
<section class="rb-section">
  <h2>Threshold frontier</h2>
  <p class="rb-caption">Counterfactual learned-router picks at multiple thresholds. Default threshold (0.5) is highlighted.</p>
  {svg}
  {_df_to_table(ctx.sweep, precision=4)}
</section>
"""


def _frontier_svg(sweep: pd.DataFrame, default_threshold: float) -> str:
    if sweep.empty:
        return ""
    width, height = 520, 260
    pad_left, pad_right = 60, 20
    pad_top, pad_bottom = 24, 40

    x_vals = sweep["mean_cost"].astype(float).tolist()
    y_vals = sweep["mean_success"].astype(float).tolist()
    thresholds = sweep["threshold"].astype(float).tolist()

    x_min, x_max = _axis_bounds(x_vals)
    y_min, y_max = 0.0, 1.0

    def scale_x(value: float) -> float:
        span = x_max - x_min or 1.0
        return pad_left + (value - x_min) / span * (width - pad_left - pad_right)

    def scale_y(value: float) -> float:
        span = y_max - y_min or 1.0
        return height - pad_bottom - (value - y_min) / span * (height - pad_top - pad_bottom)

    points = " ".join(f"{scale_x(x):.2f},{scale_y(y):.2f}" for x, y in zip(x_vals, y_vals))
    circles: list[str] = []
    labels: list[str] = []
    for threshold, x, y in zip(thresholds, x_vals, y_vals):
        cx, cy = scale_x(x), scale_y(y)
        emphasis = "rb-point rb-point-default" if threshold == default_threshold else "rb-point"
        circles.append(f'<circle class="{emphasis}" cx="{cx:.2f}" cy="{cy:.2f}" r="4" />')
        labels.append(
            f'<text class="rb-point-label" x="{cx + 6:.2f}" y="{cy - 6:.2f}">τ={threshold:g}</text>'
        )

    y_axis = (
        f'<line class="rb-axis" x1="{pad_left}" y1="{pad_top}" '
        f'x2="{pad_left}" y2="{height - pad_bottom}" />'
    )
    x_axis = (
        f'<line class="rb-axis" x1="{pad_left}" y1="{height - pad_bottom}" '
        f'x2="{width - pad_right}" y2="{height - pad_bottom}" />'
    )

    y_ticks = "".join(
        f'<text class="rb-tick" x="{pad_left - 8}" y="{scale_y(y):.2f}" text-anchor="end">{y:.1f}</text>'
        for y in (0.0, 0.25, 0.5, 0.75, 1.0)
    )

    return f"""
<svg class="rb-svg" viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Threshold frontier">
  <text class="rb-axis-label" x="{width / 2}" y="{height - 8}" text-anchor="middle">mean cost (USD)</text>
  <text class="rb-axis-label" x="14" y="{height / 2}" text-anchor="middle" transform="rotate(-90, 14, {height / 2})">mean success</text>
  {y_axis}{x_axis}{y_ticks}
  <polyline class="rb-polyline" points="{points}" />
  {''.join(circles)}
  {''.join(labels)}
</svg>
"""


def _axis_bounds(values: list[float]) -> tuple[float, float]:
    if not values:
        return 0.0, 1.0
    lo, hi = min(values), max(values)
    if lo == hi:
        return lo - 0.01, hi + 0.01
    pad = (hi - lo) * 0.1
    return lo - pad, hi + pad


def _section_cell_matrix(ctx: HtmlReportContext) -> str:
    if ctx.cells.empty:
        return _empty_section("Per-cell matrix", "No per-cell data available.")

    rate_cols = [c for c in ctx.cells.columns if c.endswith("_success_rate")]
    rendered_rows: list[str] = []
    for _, row in ctx.cells.iterrows():
        cells_html = [
            f"<td>{html_lib.escape(str(row['task_family']))}</td>",
            f"<td>{html_lib.escape(str(row['difficulty']))}</td>",
            f"<td class='rb-n'>{int(row['n'])}</td>",
        ]
        for col in rate_cols:
            value = row[col]
            cells_html.append(f"<td class='{_cell_class(value)}'>{_fmt_rate(value)}</td>")
        rendered_rows.append("<tr>" + "".join(cells_html) + "</tr>")

    header_cells = (
        "<tr><th>task_family</th><th>difficulty</th><th>n</th>"
        + "".join(f"<th>{html_lib.escape(c)}</th>" for c in rate_cols)
        + "</tr>"
    )
    return f"""
<section class="rb-section">
  <h2>Per-cell success rate</h2>
  <p class="rb-caption">Darker green is better; darker red is worse. Exact values are preserved beside each colour.</p>
  <table class="rb-table rb-cell-matrix">
    <thead>{header_cells}</thead>
    <tbody>{''.join(rendered_rows)}</tbody>
  </table>
</section>
"""


def _cell_class(value: float) -> str:
    if pd.isna(value):
        return "rb-nan"
    if value >= 0.9:
        return "rb-cell-excellent"
    if value >= 0.75:
        return "rb-cell-good"
    if value >= 0.5:
        return "rb-cell-mid"
    if value >= 0.25:
        return "rb-cell-weak"
    return "rb-cell-poor"


def _fmt_rate(value: float) -> str:
    if pd.isna(value):
        return "—"
    return f"{value:.2f}"


# --- example explorer ------------------------------------------------------


def _section_example_explorer(ctx: HtmlReportContext) -> str:
    if ctx.all_routes is None or ctx.all_routes.empty:
        return _empty_section(
            "Example explorer",
            "No all_routes CSV available; per-example view skipped.",
        )

    records = _build_explorer_records(ctx)
    if not records:
        return _empty_section("Example explorer", "No examples to display.")

    payload = json.dumps(records).replace("</", "<\\/")
    rendered = _render_example_rows(records[:50])
    total = len(records)
    shown = min(50, total)
    filter_note = (
        f"Showing {shown} of {total} examples. Use the filter to narrow by "
        "task family, difficulty, or success."
    )
    js = _explorer_js()
    return f"""
<section class="rb-section">
  <h2>Example explorer</h2>
  <p class="rb-caption">{filter_note}</p>
  <div class="rb-explorer-controls">
    <label>Filter<input id="rb-filter" type="text" placeholder="e.g. hard, classification, frontier"></label>
    <label>Hide successful<input id="rb-fail-only" type="checkbox"></label>
    <span id="rb-counter" class="rb-counter"></span>
  </div>
  <table class="rb-table rb-explorer">
    <thead><tr>
      <th>example_id</th><th>task_family</th><th>difficulty</th>
      <th>prompt</th>
      <th>small</th><th>mid</th><th>frontier</th>
      <th>predicted</th><th>attempts</th>
    </tr></thead>
    <tbody id="rb-explorer-body">{rendered}</tbody>
  </table>
  <script id="rb-explorer-data" type="application/json">{payload}</script>
  <script>{js}</script>
</section>
"""


def _build_explorer_records(ctx: HtmlReportContext) -> list[dict]:
    all_routes = ctx.all_routes
    assert all_routes is not None  # guarded by caller

    pivot = all_routes.pivot_table(
        index=["example_id", "task_family", "difficulty"],
        columns="route",
        values=["success", "quality_score", "cost_usd"],
        aggfunc="first",
    )
    prompts = (
        all_routes.groupby("example_id")["prompt"].first().to_dict()
        if "prompt" in all_routes.columns
        else {}
    )

    learned = ctx.router_frames.get("learned")
    escalated = ctx.router_frames.get("escalated")

    predicted_lookup = _predicted_lookup(learned, escalated)
    attempts_lookup = _attempts_lookup(escalated)

    records: list[dict] = []
    for (example_id, family, difficulty), _row in pivot.iterrows():
        per_route = {}
        for route in ROUTE_TIERS:
            per_route[route] = {
                "success": _safe_cell(pivot, "success", route, (example_id, family, difficulty)),
                "quality": _safe_cell(pivot, "quality_score", route, (example_id, family, difficulty)),
                "cost": _safe_cell(pivot, "cost_usd", route, (example_id, family, difficulty)),
            }

        records.append(
            {
                "example_id": str(example_id),
                "task_family": str(family),
                "difficulty": str(difficulty),
                "prompt_preview": _prompt_preview(prompts.get(example_id)),
                "per_route": per_route,
                "predicted": predicted_lookup.get(str(example_id)),
                "attempted_routes": attempts_lookup.get(str(example_id)),
            }
        )
    return records


def _safe_cell(pivot: pd.DataFrame, metric: str, route: str, key) -> float | None:
    try:
        value = pivot.loc[key, (metric, route)]
    except KeyError:
        return None
    if pd.isna(value):
        return None
    return float(value)


def _predicted_lookup(
    learned: pd.DataFrame | None, escalated: pd.DataFrame | None
) -> dict[str, dict[str, float]]:
    source = learned if learned is not None else escalated
    if source is None:
        return {}
    cols = {"predicted_success_small", "predicted_success_mid", "predicted_success_frontier"}
    if not cols.issubset(source.columns):
        return {}
    out: dict[str, dict[str, float]] = {}
    for _, row in source[["example_id", *cols]].iterrows():
        out[str(row["example_id"])] = {
            "small": float(row["predicted_success_small"]),
            "mid": float(row["predicted_success_mid"]),
            "frontier": float(row["predicted_success_frontier"]),
        }
    return out


def _attempts_lookup(escalated: pd.DataFrame | None) -> dict[str, dict]:
    if escalated is None or "attempted_routes" not in escalated.columns:
        return {}
    out: dict[str, dict] = {}
    for _, row in escalated.iterrows():
        out[str(row["example_id"])] = {
            "routes": str(row["attempted_routes"]),
            "count": int(row["escalation_count"]) if "escalation_count" in escalated.columns else 0,
        }
    return out


def _prompt_preview(prompt: object, limit: int = 140) -> str:
    if not isinstance(prompt, str):
        return ""
    cleaned = " ".join(prompt.split())
    if len(cleaned) <= limit:
        return cleaned
    return cleaned[: limit - 1].rstrip() + "…"


def _render_example_rows(records: list[dict]) -> str:
    rows: list[str] = []
    for r in records:
        per_route = r["per_route"]
        predicted = r.get("predicted") or {}
        attempts = r.get("attempted_routes") or {}
        pred_str = (
            ", ".join(f"{route}:{predicted[route]:.2f}" for route in ROUTE_TIERS)
            if predicted
            else "—"
        )
        attempts_str = (
            f"{attempts.get('routes', '')} (n={attempts.get('count', 0)})"
            if attempts
            else "—"
        )
        cells = [
            f"<td>{html_lib.escape(r['example_id'])}</td>",
            f"<td>{html_lib.escape(r['task_family'])}</td>",
            f"<td>{html_lib.escape(r['difficulty'])}</td>",
            f"<td class='rb-prompt'>{html_lib.escape(r['prompt_preview'])}</td>",
        ]
        for route in ROUTE_TIERS:
            cells.append(f"<td>{_route_cell(per_route.get(route) or {})}</td>")
        cells.append(f"<td>{html_lib.escape(pred_str)}</td>")
        cells.append(f"<td>{html_lib.escape(attempts_str)}</td>")
        rows.append("<tr>" + "".join(cells) + "</tr>")
    return "".join(rows)


def _route_cell(per_route: dict) -> str:
    success = per_route.get("success")
    cost = per_route.get("cost")
    if success is None:
        return "—"
    mark = "✓" if success >= 0.5 else "✗"
    cost_text = f"{cost:.2f}" if cost is not None else "—"
    return f"{mark}&nbsp;${cost_text}"


def _explorer_js() -> str:
    return """
(function(){
  var payload = document.getElementById('rb-explorer-data');
  if(!payload) return;
  var data = JSON.parse(payload.textContent || '[]');
  var body = document.getElementById('rb-explorer-body');
  var filter = document.getElementById('rb-filter');
  var failOnly = document.getElementById('rb-fail-only');
  var counter = document.getElementById('rb-counter');

  function esc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(c){
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];
  }); }

  function mark(success){
    if(success === null || success === undefined) return '—';
    return (success >= 0.5 ? '✓' : '✗');
  }

  function render(rows){
    var html = rows.map(function(r){
      var per = r.per_route || {};
      var pred = r.predicted
        ? ['small','mid','frontier'].map(function(k){ return k + ':' + (r.predicted[k] == null ? '—' : r.predicted[k].toFixed(2)); }).join(', ')
        : '—';
      var attempts = r.attempted_routes
        ? (r.attempted_routes.routes + ' (n=' + r.attempted_routes.count + ')')
        : '—';
      function cell(route){
        var p = per[route] || {};
        if(p.success == null) return '<td>—</td>';
        var cost = (p.cost == null ? '—' : p.cost.toFixed(2));
        return '<td>' + mark(p.success) + '&nbsp;$' + cost + '</td>';
      }
      return '<tr>'
        + '<td>' + esc(r.example_id) + '</td>'
        + '<td>' + esc(r.task_family) + '</td>'
        + '<td>' + esc(r.difficulty) + '</td>'
        + '<td class="rb-prompt">' + esc(r.prompt_preview) + '</td>'
        + cell('small') + cell('mid') + cell('frontier')
        + '<td>' + esc(pred) + '</td>'
        + '<td>' + esc(attempts) + '</td>'
        + '</tr>';
    }).join('');
    body.innerHTML = html;
    if(counter) counter.textContent = rows.length + ' of ' + data.length + ' examples';
  }

  function apply(){
    var q = (filter.value || '').toLowerCase().trim();
    var fails = failOnly.checked;
    var filtered = data.filter(function(r){
      var hay = [r.example_id, r.task_family, r.difficulty, r.prompt_preview].join(' ').toLowerCase();
      if(q && hay.indexOf(q) === -1) return false;
      if(fails){
        var allOk = ['small','mid','frontier'].every(function(k){
          var v = (r.per_route || {})[k];
          return v && v.success != null && v.success >= 0.5;
        });
        if(allOk) return false;
      }
      return true;
    });
    render(filtered);
  }

  filter.addEventListener('input', apply);
  failOnly.addEventListener('change', apply);
  apply();
})();
"""


# --- wins / losses ---------------------------------------------------------


def _section_wins_losses(ctx: HtmlReportContext) -> str:
    pieces: list[str] = []

    learned_vs_heuristic = _router_delta(ctx, "learned", "heuristic")
    if learned_vs_heuristic:
        pieces.append(_wins_table("Learned beats heuristic", learned_vs_heuristic))

    escalated_rescues = _escalation_rescues(ctx)
    if escalated_rescues:
        pieces.append(_wins_table("Escalation rescues learned", escalated_rescues))

    hardest = _hardest_cells(ctx)
    if hardest:
        pieces.append(_wins_table("Hardest cells (lowest mean success)", hardest))

    expensive = _most_expensive_operating_points(ctx)
    if expensive:
        pieces.append(_wins_table("Most expensive operating points", expensive))

    if not pieces:
        return _empty_section("Wins & losses", "Not enough data to compute comparisons.")

    return f"""
<section class="rb-section">
  <h2>Wins &amp; losses</h2>
  {''.join(pieces)}
</section>
"""


def _router_delta(ctx: HtmlReportContext, a: str, b: str) -> list[dict]:
    left = ctx.router_frames.get(a)
    right = ctx.router_frames.get(b)
    if left is None or right is None or ctx.cells.empty:
        return []
    rows: list[dict] = []
    left_col = f"{a}_success_rate"
    right_col = f"{b}_success_rate"
    if left_col not in ctx.cells.columns or right_col not in ctx.cells.columns:
        return []
    for _, row in ctx.cells.iterrows():
        delta = float(row[left_col]) - float(row[right_col])
        if delta > 0:
            rows.append(
                {
                    "cell": f"{row['task_family']} / {row['difficulty']}",
                    "n": int(row["n"]),
                    f"{a}": _fmt_rate(row[left_col]),
                    f"{b}": _fmt_rate(row[right_col]),
                    "delta": f"+{delta:.2f}",
                }
            )
    rows.sort(key=lambda r: float(r["delta"]), reverse=True)
    return rows[:5]


def _escalation_rescues(ctx: HtmlReportContext) -> list[dict]:
    learned = ctx.router_frames.get("learned")
    escalated = ctx.router_frames.get("escalated")
    if learned is None or escalated is None:
        return []
    merged = learned[["example_id", "success"]].merge(
        escalated[["example_id", "success", "attempted_routes", "escalation_count"]],
        on="example_id",
        suffixes=("_learned", "_escalated"),
    )
    rescues = merged[(merged["success_learned"] == 0) & (merged["success_escalated"] == 1)]
    return [
        {
            "example_id": str(row["example_id"]),
            "learned_success": "0",
            "escalated_success": "1",
            "routes": str(row["attempted_routes"]),
            "escalation_count": int(row["escalation_count"]),
        }
        for _, row in rescues.head(5).iterrows()
    ]


def _hardest_cells(ctx: HtmlReportContext) -> list[dict]:
    if ctx.cells.empty:
        return []
    rate_cols = [c for c in ctx.cells.columns if c.endswith("_success_rate")]
    if not rate_cols:
        return []
    cells_copy = ctx.cells.copy()
    cells_copy["_mean_success"] = cells_copy[rate_cols].mean(axis=1)
    worst = cells_copy.sort_values("_mean_success").head(5)
    return [
        {
            "cell": f"{row['task_family']} / {row['difficulty']}",
            "n": int(row["n"]),
            "mean_success_across_routers": f"{row['_mean_success']:.2f}",
        }
        for _, row in worst.iterrows()
    ]


def _most_expensive_operating_points(ctx: HtmlReportContext) -> list[dict]:
    if ctx.agg.empty:
        return []
    sorted_rows = ctx.agg.sort_values("mean_cost_usd", ascending=False)
    return [
        {
            "router": str(row["router"]),
            "mean_cost_usd": f"{row['mean_cost_usd']:.4f}",
            "mean_success": f"{row['mean_success']:.2f}",
            "frontier_share": f"{row['route_mix_frontier']:.2f}",
        }
        for _, row in sorted_rows.head(5).iterrows()
    ]


def _wins_table(title: str, rows: list[dict]) -> str:
    if not rows:
        return ""
    headers = list(rows[0].keys())
    thead = "".join(f"<th>{html_lib.escape(h)}</th>" for h in headers)
    body = "".join(
        "<tr>" + "".join(f"<td>{html_lib.escape(str(row[h]))}</td>" for h in headers) + "</tr>"
        for row in rows
    )
    return f"""
<div class="rb-wins-block">
  <h3>{html_lib.escape(title)}</h3>
  <table class="rb-table"><thead><tr>{thead}</tr></thead><tbody>{body}</tbody></table>
</div>
"""


# --- repro -----------------------------------------------------------------


def _section_repro(ctx: HtmlReportContext) -> str:
    files = sorted(
        p.name for p in ctx.results_dir.iterdir()
        if p.is_file() and p.suffix in {".csv", ".json", ".html", ".md"}
    )
    files_html = "".join(f"<li>{html_lib.escape(f)}</li>" for f in files) or "<li>none</li>"
    expected = [all_routes_filename(ctx.split)] + [router_filename(r, ctx.split) for r in ROUTER_NAMES]
    expected_html = ", ".join(html_lib.escape(name) for name in expected)
    return f"""
<section class="rb-section rb-repro">
  <h2>Reproducibility</h2>
  <p class="rb-caption">This report was generated offline from saved artifacts. No provider calls were made.</p>
  <ul class="rb-file-list">{files_html}</ul>
  <p class="rb-caption">Expected source files for split <code>{html_lib.escape(ctx.split)}</code>: {expected_html}</p>
</section>
"""


# --- generic helpers -------------------------------------------------------


def _empty_section(title: str, message: str) -> str:
    return f"""
<section class="rb-section rb-empty">
  <h2>{html_lib.escape(title)}</h2>
  <p class="rb-caption">{html_lib.escape(message)}</p>
</section>
"""


def _df_to_table(df: pd.DataFrame, precision: int = 4) -> str:
    if df.empty:
        return "<p class='rb-caption'>(empty)</p>"
    headers = "".join(f"<th>{html_lib.escape(str(c))}</th>" for c in df.columns)
    rows: list[str] = []
    for _, row in df.iterrows():
        cells = []
        for c in df.columns:
            value = row[c]
            if isinstance(value, float):
                cells.append(f"<td>{_fmt_float(value, precision)}</td>")
            else:
                cells.append(f"<td>{html_lib.escape(str(value))}</td>")
        rows.append("<tr>" + "".join(cells) + "</tr>")
    return f"<table class='rb-table'><thead><tr>{headers}</tr></thead><tbody>{''.join(rows)}</tbody></table>"


def _fmt_float(value: float, precision: int) -> str:
    if pd.isna(value):
        return "—"
    return f"{value:.{precision}f}"


# --- page shell ------------------------------------------------------------


def _page_shell(title: str, body: str) -> str:
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{html_lib.escape(title)}</title>
<style>{_stylesheet()}</style>
</head>
<body>
<main class="rb-main">
{body}
</main>
</body>
</html>
"""


def _stylesheet() -> str:
    return """
  :root {
    --rb-bg: #fafaf8;
    --rb-panel: #ffffff;
    --rb-text: #1f2328;
    --rb-muted: #616572;
    --rb-border: #dcdcdc;
    --rb-accent: #1f6feb;
  }
  * { box-sizing: border-box; }
  body { margin: 0; background: var(--rb-bg); color: var(--rb-text); font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; font-size: 14px; line-height: 1.5; }
  .rb-main { max-width: 1100px; margin: 0 auto; padding: 32px 28px 80px; }
  h1 { font-size: 22px; margin: 0 0 12px; }
  h2 { font-size: 16px; margin: 24px 0 10px; border-bottom: 1px solid var(--rb-border); padding-bottom: 4px; }
  h3 { font-size: 14px; margin: 16px 0 6px; color: var(--rb-muted); text-transform: uppercase; letter-spacing: 0.05em; }
  .rb-section { background: var(--rb-panel); border: 1px solid var(--rb-border); border-radius: 4px; padding: 18px 20px; margin-bottom: 20px; }
  .rb-caption { color: var(--rb-muted); margin: 4px 0 10px; font-size: 13px; }
  .rb-meta { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 8px 16px; margin: 8px 0 16px; }
  .rb-meta .rb-label { color: var(--rb-muted); font-size: 12px; text-transform: uppercase; letter-spacing: 0.04em; display: block; }
  .rb-meta .rb-value { font-weight: 500; word-break: break-word; }
  .rb-table { width: 100%; border-collapse: collapse; font-size: 13px; }
  .rb-table th, .rb-table td { border-bottom: 1px solid var(--rb-border); padding: 6px 10px; text-align: left; vertical-align: top; }
  .rb-table thead th { background: #f3f3f0; font-weight: 600; }
  .rb-table tr:hover td { background: #fcfbf6; }
  .rb-row-counts { max-width: 320px; }
  .rb-n { font-variant-numeric: tabular-nums; }
  .rb-cell-matrix td, .rb-cell-matrix th { text-align: center; }
  .rb-cell-matrix td:first-child, .rb-cell-matrix td:nth-child(2) { text-align: left; }
  .rb-cell-excellent { background: #cdeccd; }
  .rb-cell-good { background: #e0f0d8; }
  .rb-cell-mid { background: #f6ecc8; }
  .rb-cell-weak { background: #f6d6c8; }
  .rb-cell-poor { background: #eebcbc; }
  .rb-nan { color: var(--rb-muted); }
  .rb-svg { display: block; margin: 8px 0 16px; max-width: 100%; background: #fcfcf8; border: 1px solid var(--rb-border); border-radius: 3px; }
  .rb-axis { stroke: #888; stroke-width: 1; }
  .rb-axis-label { font-size: 12px; fill: var(--rb-muted); }
  .rb-tick { font-size: 11px; fill: var(--rb-muted); }
  .rb-polyline { fill: none; stroke: var(--rb-accent); stroke-width: 1.5; opacity: 0.7; }
  .rb-point { fill: #fff; stroke: var(--rb-accent); stroke-width: 1.5; }
  .rb-point-default { fill: var(--rb-accent); }
  .rb-point-label { font-size: 11px; fill: var(--rb-muted); }
  .rb-explorer-controls { display: flex; gap: 16px; align-items: center; margin: 6px 0 10px; flex-wrap: wrap; }
  .rb-explorer-controls label { display: flex; gap: 6px; align-items: center; font-size: 13px; color: var(--rb-muted); }
  .rb-explorer-controls input[type=text] { padding: 4px 8px; border: 1px solid var(--rb-border); border-radius: 3px; min-width: 260px; font-size: 13px; }
  .rb-counter { color: var(--rb-muted); font-size: 12px; }
  .rb-prompt { max-width: 340px; font-family: "SFMono-Regular", Consolas, "Liberation Mono", monospace; font-size: 12px; color: #3b3f4a; }
  .rb-wins-block { margin-top: 16px; }
  .rb-file-list { columns: 2; padding-left: 20px; margin: 8px 0; }
  .rb-empty { background: #fbfbf8; }
  code { background: #f3f3f0; padding: 1px 4px; border-radius: 2px; font-size: 12px; }
"""
