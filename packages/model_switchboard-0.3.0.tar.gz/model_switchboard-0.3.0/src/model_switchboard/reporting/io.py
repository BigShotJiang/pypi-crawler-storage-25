"""File-naming conventions and discovery helpers for results directories.

A results directory is the canonical unit of a benchmark run. Every routing
strategy writes a CSV named ``<router>_router{_split}.csv`` into it, and the
all-routes CSV lives beside them. These helpers centralise that naming so
reporting scripts cannot drift.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd


ROUTER_NAMES: tuple[str, ...] = ("heuristic", "learned", "escalated")

SPLIT_CHOICES: tuple[str, ...] = ("train", "test", "all")


def split_suffix(split: str) -> str:
    """Filename suffix for the given split. ``all`` keeps legacy unsuffixed names."""
    return "" if split == "all" else f"_{split}"


def router_filename(router: str, split: str) -> str:
    return f"{router}_router{split_suffix(split)}.csv"


def all_routes_filename(split: str) -> str:
    return f"all_routes{split_suffix(split)}.csv"


def report_csv_filename(split: str) -> str:
    return f"report{split_suffix(split)}.csv"


def load_router_frames(results_dir: Path, split: str) -> dict[str, pd.DataFrame]:
    """Load every router CSV that exists in the directory for the given split."""
    frames: dict[str, pd.DataFrame] = {}
    for router in ROUTER_NAMES:
        path = results_dir / router_filename(router, split)
        if path.exists():
            frames[router] = pd.read_csv(path)
    return frames


def load_all_routes(results_dir: Path, split: str) -> pd.DataFrame | None:
    path = results_dir / all_routes_filename(split)
    if not path.exists():
        return None
    return pd.read_csv(path)


def route_col_for(df: pd.DataFrame) -> str:
    """Return the column that holds the router's chosen route.

    Heuristic and learned CSVs use ``chosen_route``; escalated CSVs record the
    final tier as ``final_route``. Reports read the final route consistently.
    """
    if "final_route" in df.columns:
        return "final_route"
    if "chosen_route" in df.columns:
        return "chosen_route"
    raise ValueError("router CSV lacks chosen_route / final_route column")
