"""Service app wiring."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from fastapi import FastAPI

from model_switchboard import __version__ as switchboard_version
from model_switchboard.reporting.metrics import ROUTE_TIERS
from model_switchboard.router.heuristic import choose_heuristic_route
from model_switchboard.runtime.compliance import (
    PolicyEngine,
    default_policy_engine,
)
from model_switchboard.runtime.features_adapter import features_for_heuristic
from model_switchboard.runtime.health import HealthRegistry
from model_switchboard.runtime.health_store import (
    FileHealthStore,
    HealthStore,
    InMemoryHealthStore,
)
from model_switchboard.runtime.pricing import (
    PricingTable,
    load_pricing_table,
    pricing_table_from_route_costs,
)
from model_switchboard.runtime.policy import PolicyArtifact, load_policy
from model_switchboard.runtime.rollout import (
    RolloutPolicy,
    RolloutState,
    load_rollout_state,
)
from model_switchboard.runtime.router import RuntimeRouter
from model_switchboard.runtime.telemetry import LoggingTelemetry, Telemetry
from model_switchboard.service import routes as route_module


@dataclass
class ServiceConfig:
    policy_path: Path
    pricing_path: Path | None
    health_store_path: Path | None
    rollout_state_path: Path | None
    request_token: str
    admin_token: str
    tenant_header: str = "x-switchboard-tenant"

    @classmethod
    def from_env(cls, env: dict[str, str] | None = None) -> "ServiceConfig":
        env = env if env is not None else dict(os.environ)
        policy = env.get("SWITCHBOARD_POLICY_PATH")
        if not policy:
            raise RuntimeError(
                "SWITCHBOARD_POLICY_PATH must be set to a packaged policy artifact directory."
            )
        request_token = env.get("SWITCHBOARD_REQUEST_TOKEN")
        if not request_token:
            raise RuntimeError(
                "SWITCHBOARD_REQUEST_TOKEN must be set to a non-empty bearer token."
            )
        admin_token = env.get("SWITCHBOARD_ADMIN_TOKEN")
        if not admin_token:
            raise RuntimeError(
                "SWITCHBOARD_ADMIN_TOKEN must be set to a non-empty admin bearer token."
            )
        return cls(
            policy_path=Path(policy),
            pricing_path=Path(env["SWITCHBOARD_PRICING_PATH"]) if env.get("SWITCHBOARD_PRICING_PATH") else None,
            health_store_path=Path(env["SWITCHBOARD_HEALTH_STORE"]) if env.get("SWITCHBOARD_HEALTH_STORE") else None,
            rollout_state_path=Path(env["SWITCHBOARD_ROLLOUT_STATE"]) if env.get("SWITCHBOARD_ROLLOUT_STATE") else None,
            request_token=request_token,
            admin_token=admin_token,
            tenant_header=env.get("SWITCHBOARD_TENANT_HEADER", "x-switchboard-tenant"),
        )


def load_config_from_env(env: dict[str, str] | None = None) -> ServiceConfig:
    return ServiceConfig.from_env(env)


@dataclass
class ServiceState:
    config: ServiceConfig
    artifact: PolicyArtifact
    pricing: PricingTable
    health: HealthRegistry
    router: RuntimeRouter
    rollout: RolloutPolicy
    policy_engine: PolicyEngine
    telemetry: Telemetry
    baseline_compare_log: list = field(default_factory=list)

    def baseline_route_for(self, request) -> str:
        features = features_for_heuristic(request)
        route, _ = choose_heuristic_route(features)
        return route

    def save_rollout_if_configured(self) -> None:
        if self.config.rollout_state_path is None:
            return
        from model_switchboard.runtime.rollout import save_rollout_state
        save_rollout_state(self.rollout.state, self.config.rollout_state_path)


def build_service_state(
    config: ServiceConfig,
    *,
    telemetry: Telemetry | None = None,
) -> ServiceState:
    artifact = load_policy(config.policy_path)
    pricing = _load_pricing(config, artifact)
    health = _build_health_registry(config)
    policy_engine = default_policy_engine()
    router = RuntimeRouter(
        artifact,
        health=health,
        pricing=pricing,
        policy_engine=policy_engine,
        telemetry=telemetry or LoggingTelemetry(),
    )
    rollout_state = (
        load_rollout_state(config.rollout_state_path) if config.rollout_state_path else RolloutState()
    )
    return ServiceState(
        config=config,
        artifact=artifact,
        pricing=pricing,
        health=health,
        router=router,
        rollout=RolloutPolicy(rollout_state),
        policy_engine=policy_engine,
        telemetry=telemetry or LoggingTelemetry(),
    )


def build_app(state: ServiceState | None = None, config: ServiceConfig | None = None) -> FastAPI:
    if state is None:
        if config is None:
            config = load_config_from_env()
        state = build_service_state(config)

    app = FastAPI(
        title="ModelSwitchboard",
        version=switchboard_version,
        description="Shadow-mode routing control plane for LLM policies.",
    )
    app.state.service_state = state
    route_module.register_routes(app, state)
    return app


# --- helpers ---------------------------------------------------------------


def _load_pricing(config: ServiceConfig, artifact: PolicyArtifact) -> PricingTable:
    if config.pricing_path is not None:
        return load_pricing_table(config.pricing_path)
    return pricing_table_from_route_costs({"small": 0.02, "mid": 0.10, "frontier": 0.60})


def _build_health_registry(config: ServiceConfig) -> HealthRegistry:
    store: HealthStore = (
        FileHealthStore(config.health_store_path)
        if config.health_store_path is not None
        else InMemoryHealthStore()
    )
    return HealthRegistry(ROUTE_TIERS, store=store)
