"""Service routes."""

from __future__ import annotations

from typing import Any, Literal

from fastapi import Depends, FastAPI, Header, HTTPException, Request, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from model_switchboard import __version__ as switchboard_version
from model_switchboard.runtime.decision import decision_to_jsonable
from model_switchboard.runtime.rollout import (
    ArtifactLane,
    RolloutState,
    build_baseline_compare_record,
)
from model_switchboard.runtime.request import RuntimeRequest


ERROR_UNAUTHORIZED = "unauthorized"
ERROR_BAD_REQUEST = "bad_request"
ERROR_UNAVAILABLE = "service_unavailable"


# --- request models --------------------------------------------------------


class DecideRequestBody(BaseModel):
    request_id: str
    task_family: Literal["classification", "extraction", "summarization", "drafting"]
    prompt: str
    context: str | None = None
    latency_budget_ms: int = 5000
    cost_ceiling_usd: float | None = None
    risk_tier: Literal["low", "medium", "high"] = "low"
    workspace_id: str | None = None
    compliance_flags: tuple[str, ...] = ()
    allow_escalation: bool = True
    metadata: dict[str, Any] = Field(default_factory=dict)


class RolloutUpdateBody(BaseModel):
    kill_switch: bool | None = None
    canary_percent: int | None = Field(default=None, ge=0, le=100)
    tenant_pins: dict[str, Literal["candidate", "baseline"]] | None = None
    compare_against_baseline: bool | None = None


# --- auth / tenant dependencies -------------------------------------------


def _require_token(
    header: str | None, expected: str, role: str
) -> None:
    if not header or not header.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error": ERROR_UNAUTHORIZED, "reason": f"missing_{role}_bearer_token"},
        )
    if header.removeprefix("Bearer ") != expected:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error": ERROR_UNAUTHORIZED, "reason": f"invalid_{role}_token"},
        )


# --- registration ---------------------------------------------------------


def register_routes(app: FastAPI, state) -> None:
    tenant_header = state.config.tenant_header

    @app.get("/health")
    def health() -> dict[str, Any]:
        routes = {
            route: health.snapshot()
            for route, health in state.health.as_mapping().items()
        }
        return {
            "status": "ok",
            "switchboard_version": switchboard_version,
            "policy": {
                "artifact_version": state.artifact.policy_artifact_version,
                "preset_name": state.artifact.preset_name,
                "threshold": state.artifact.threshold,
                "model_family": state.artifact.model_family,
                "generated_at": state.artifact.generated_at,
            },
            "routes": routes,
            "rollout": state.rollout.state.to_dict(),
        }

    @app.post("/decide")
    def decide(
        body: DecideRequestBody,
        request: Request,
        authorization: str | None = Header(default=None),
    ) -> JSONResponse:
        _require_token(authorization, state.config.request_token, role="request")

        tenant_id = request.headers.get(tenant_header)
        runtime_request = _runtime_request_from_body(body, tenant_id)
        lane = state.rollout.resolve(runtime_request)

        payload: dict[str, Any]
        if lane.lane is ArtifactLane.CANDIDATE:
            decision = state.router.decide(runtime_request)
            payload = {"lane": lane.lane.value, "reason": lane.reason, "decision": decision_to_jsonable(decision)}
            if lane.compare_against_baseline:
                baseline_route = state.baseline_route_for(runtime_request)
                record = build_baseline_compare_record(
                    runtime_request,
                    candidate_route=decision.initial_route,
                    candidate_reason=decision.route_reason,
                    baseline_route=baseline_route,
                )
                state.baseline_compare_log.append(record)
                payload["baseline_compare"] = record.to_dict()
        else:
            baseline_route = state.baseline_route_for(runtime_request)
            payload = {
                "lane": lane.lane.value,
                "reason": lane.reason,
                "baseline_route": baseline_route,
            }

        return JSONResponse(payload)

    @app.get("/admin/rollout")
    def get_rollout(authorization: str | None = Header(default=None)) -> dict[str, Any]:
        _require_token(authorization, state.config.admin_token, role="admin")
        recent = [
            record.to_dict() for record in list(state.baseline_compare_log)[-20:]
        ]
        return {
            "rollout": state.rollout.state.to_dict(),
            "baseline_compare_recent": recent,
        }

    @app.post("/admin/rollout")
    def update_rollout(
        body: RolloutUpdateBody,
        authorization: str | None = Header(default=None),
    ) -> dict[str, Any]:
        _require_token(authorization, state.config.admin_token, role="admin")
        rollout = state.rollout.state
        if body.kill_switch is not None:
            if body.kill_switch:
                rollout.engage_kill_switch()
            else:
                rollout.release_kill_switch()
        if body.canary_percent is not None:
            rollout.set_canary_percent(body.canary_percent)
        if body.tenant_pins is not None:
            for tenant, lane in body.tenant_pins.items():
                rollout.pin_tenant(tenant, ArtifactLane(lane))
        if body.compare_against_baseline is not None:
            rollout.compare_against_baseline = body.compare_against_baseline

        state.save_rollout_if_configured()
        return {"rollout": rollout.to_dict()}


# --- helpers --------------------------------------------------------------


def _runtime_request_from_body(
    body: DecideRequestBody, tenant_id: str | None
) -> RuntimeRequest:
    return RuntimeRequest(
        request_id=body.request_id,
        task_family=body.task_family,
        prompt=body.prompt,
        context=body.context,
        latency_budget_ms=body.latency_budget_ms,
        cost_ceiling_usd=body.cost_ceiling_usd,
        risk_tier=body.risk_tier,
        tenant_id=tenant_id,
        workspace_id=body.workspace_id,
        compliance_flags=body.compliance_flags,
        allow_escalation=body.allow_escalation,
        metadata=body.metadata,
    )
