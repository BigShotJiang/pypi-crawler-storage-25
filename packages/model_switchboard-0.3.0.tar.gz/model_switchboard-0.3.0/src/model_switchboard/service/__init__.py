"""HTTP serving layer for ModelSwitchboard.

The service is a design surface. It exposes three endpoints:

- ``POST /decide``        — take a request, return a structured routing decision.
- ``GET  /health``        — readiness/liveness plus a per-route health snapshot.
- ``GET/POST /admin/rollout`` — read or update the rollout state (canary %,
  kill switch, tenant pins, baseline-compare flag). Requires an admin token.

What the service deliberately does NOT include:

- A queue or worker pool. Requests are synchronous; scale by running multiple
  replicas behind your load balancer and pointing them at a shared
  :class:`FileHealthStore` (or a real Redis/DB adapter).
- A real auth provider. The shipped middleware checks a static bearer token
  from an env var; real deployments replace it with their SSO/JWT of choice.
- Provider execution. ``/decide`` returns the decision; dispatching is the
  caller's job. An out-of-band executor (shipped in ``runtime.executor``)
  handles execution when a deployment chooses to colocate the two.
"""

from model_switchboard.service.app import (
    ServiceConfig,
    build_app,
    build_service_state,
    load_config_from_env,
)

__all__ = [
    "ServiceConfig",
    "build_app",
    "build_service_state",
    "load_config_from_env",
]
