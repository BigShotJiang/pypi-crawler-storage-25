"""ModelSwitchboard: shadow-mode LLM routing control plane with an offline benchmark."""

__version__ = "0.3.0"
