"""Append-only NDJSON decision log.

One :class:`RoutingDecision` per line. Flush on every write so a crashing
shadow run still leaves an inspectable trail. The logger supports ``with``
so callers can scope it to a single run.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import IO

from model_switchboard.runtime.decision import RoutingDecision, decision_to_jsonable


class DecisionLogger:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._handle: IO[str] | None = None

    # --- lifecycle ---------------------------------------------------------

    def open(self) -> None:
        if self._handle is not None:
            return
        self._handle = self.path.open("w", encoding="utf-8", newline="\n")

    def close(self) -> None:
        if self._handle is None:
            return
        self._handle.flush()
        self._handle.close()
        self._handle = None

    def __enter__(self) -> "DecisionLogger":
        self.open()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    # --- writes ------------------------------------------------------------

    def log(self, decision: RoutingDecision) -> None:
        self._require_open()
        line = json.dumps(decision_to_jsonable(decision), separators=(",", ":"))
        assert self._handle is not None  # narrowed by _require_open
        self._handle.write(line + "\n")
        self._handle.flush()

    def _require_open(self) -> None:
        if self._handle is None:
            raise RuntimeError(
                "DecisionLogger is not open; use 'with DecisionLogger(...)' "
                "or call open() before log()."
            )
