"""Rollout state and lane selection."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any

from model_switchboard.runtime.request import RuntimeRequest


class ArtifactLane(str, Enum):
    CANDIDATE = "candidate"
    BASELINE = "baseline"


@dataclass(frozen=True)
class BaselineCompareRecord:
    request_id: str
    tenant_id: str | None
    candidate_route: str | None
    baseline_route: str
    agreed: bool
    candidate_reason: str
    recorded_at: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "request_id": self.request_id,
            "tenant_id": self.tenant_id,
            "candidate_route": self.candidate_route,
            "baseline_route": self.baseline_route,
            "agreed": self.agreed,
            "candidate_reason": self.candidate_reason,
            "recorded_at": self.recorded_at,
        }


@dataclass
class RolloutState:
    kill_switch: bool = False
    canary_percent: int = 0
    tenant_pins: dict[str, ArtifactLane] = field(default_factory=dict)
    compare_against_baseline: bool = False

    def pin_tenant(self, tenant_id: str, lane: ArtifactLane) -> None:
        self.tenant_pins[tenant_id] = lane

    def unpin_tenant(self, tenant_id: str) -> None:
        self.tenant_pins.pop(tenant_id, None)

    def set_canary_percent(self, percent: int) -> None:
        if not 0 <= percent <= 100:
            raise ValueError(f"canary_percent must be in [0, 100], got {percent}")
        self.canary_percent = int(percent)

    def engage_kill_switch(self) -> None:
        self.kill_switch = True

    def release_kill_switch(self) -> None:
        self.kill_switch = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "kill_switch": self.kill_switch,
            "canary_percent": self.canary_percent,
            "tenant_pins": {k: v.value for k, v in self.tenant_pins.items()},
            "compare_against_baseline": self.compare_against_baseline,
        }


@dataclass(frozen=True)
class LaneDecision:
    lane: ArtifactLane
    reason: str
    compare_against_baseline: bool


class RolloutPolicy:
    def __init__(self, state: RolloutState | None = None) -> None:
        self.state = state or RolloutState()

    def resolve(self, request: RuntimeRequest) -> LaneDecision:
        state = self.state
        if state.kill_switch:
            return LaneDecision(
                lane=ArtifactLane.BASELINE,
                reason="kill_switch_engaged",
                compare_against_baseline=False,
            )

        if request.tenant_id and request.tenant_id in state.tenant_pins:
            return LaneDecision(
                lane=state.tenant_pins[request.tenant_id],
                reason="tenant_pinned",
                compare_against_baseline=state.compare_against_baseline,
            )

        lane = ArtifactLane.CANDIDATE if _hits_canary(request, state.canary_percent) else ArtifactLane.BASELINE
        return LaneDecision(
            lane=lane,
            reason="canary_percent",
            compare_against_baseline=state.compare_against_baseline,
        )


def build_baseline_compare_record(
    request: RuntimeRequest,
    candidate_route: str | None,
    candidate_reason: str,
    baseline_route: str,
) -> BaselineCompareRecord:
    return BaselineCompareRecord(
        request_id=request.request_id,
        tenant_id=request.tenant_id,
        candidate_route=candidate_route,
        baseline_route=baseline_route,
        agreed=(candidate_route == baseline_route),
        candidate_reason=candidate_reason,
        recorded_at=_utc_now_iso(),
    )


# --- helpers ---------------------------------------------------------------


def _hits_canary(request: RuntimeRequest, percent: int) -> bool:
    if percent <= 0:
        return False
    if percent >= 100:
        return True
    bucket_key = f"{request.tenant_id or ''}|{request.request_id}"
    digest = hashlib.sha256(bucket_key.encode("utf-8")).digest()
    bucket = int.from_bytes(digest[:4], "big") % 100
    return bucket < percent


def _utc_now_iso() -> str:
    return datetime.now(tz=timezone.utc).isoformat(timespec="seconds")


# --- optional persistence --------------------------------------------------


def load_rollout_state(path: str | Path) -> RolloutState:
    import json

    p = Path(path)
    if not p.exists():
        return RolloutState()
    payload = json.loads(p.read_text(encoding="utf-8"))
    return RolloutState(
        kill_switch=bool(payload.get("kill_switch", False)),
        canary_percent=int(payload.get("canary_percent", 0)),
        tenant_pins={
            k: ArtifactLane(v) for k, v in (payload.get("tenant_pins") or {}).items()
        },
        compare_against_baseline=bool(payload.get("compare_against_baseline", False)),
    )


def save_rollout_state(state: RolloutState, path: str | Path) -> None:
    import json
    import os
    import tempfile

    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".rollout-", suffix=".json.tmp", dir=str(p.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(state.to_dict(), f, indent=2, sort_keys=True)
        os.replace(tmp, p)
    except Exception:
        tmp_path = Path(tmp)
        if tmp_path.exists():
            tmp_path.unlink()
        raise
