"""Policy artifact packing and loading."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from model_switchboard import __version__ as switchboard_version
from model_switchboard.router.ml_router import (
    ARTIFACT_VERSION as MODEL_ARTIFACT_VERSION,
    CATEGORICAL_COLS,
    FEATURE_COLS,
    NUMERIC_COLS,
    SUPPORTED_FAMILIES,
    SuccessPredictor,
)


POLICY_ARTIFACT_VERSION: int = 1

POLICY_FILENAME = "policy.json"
MODEL_FILENAME = "model.joblib"
FEATURE_SCHEMA_FILENAME = "feature_schema.json"


class PolicyArtifactError(ValueError):
    """Bad or incompatible policy artifact."""


@dataclass(frozen=True)
class PolicyArtifact:
    path: Path
    predictor: SuccessPredictor
    threshold: float
    preset_name: str | None
    policy_artifact_version: int
    model_family: str
    feature_cols: tuple[str, ...]
    numeric_cols: tuple[str, ...]
    categorical_cols: tuple[str, ...]
    generated_at: str
    switchboard_version: str
    model_artifact_version: int
    notes: str | None = None
    training_info: dict[str, Any] = field(default_factory=dict)

    def meta(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "policy_artifact_version": self.policy_artifact_version,
            "switchboard_version": self.switchboard_version,
            "model_artifact_version": self.model_artifact_version,
            "model_family": self.model_family,
            "threshold": self.threshold,
            "preset_name": self.preset_name,
            "feature_schema": {
                "numeric": list(self.numeric_cols),
                "categorical": list(self.categorical_cols),
            },
            "generated_at": self.generated_at,
            "training_info": dict(self.training_info),
        }
        if self.notes:
            payload["notes"] = self.notes
        return payload


# --- packaging --------------------------------------------------------------


def pack_policy(
    output_dir: str | Path,
    *,
    predictor: SuccessPredictor,
    threshold: float,
    preset_name: str | None = None,
    training_info: dict[str, Any] | None = None,
    notes: str | None = None,
) -> Path:
    if not predictor.fitted:
        raise PolicyArtifactError("Refusing to pack an unfitted SuccessPredictor")
    if predictor.model_family not in SUPPORTED_FAMILIES:
        raise PolicyArtifactError(
            f"Unsupported model_family={predictor.model_family!r}; "
            f"expected one of {SUPPORTED_FAMILIES}"
        )

    target = Path(output_dir)
    target.mkdir(parents=True, exist_ok=True)

    model_path = target / MODEL_FILENAME
    predictor.save(model_path)

    feature_schema = {
        "numeric": list(NUMERIC_COLS),
        "categorical": list(CATEGORICAL_COLS),
        "all": list(FEATURE_COLS),
    }
    (target / FEATURE_SCHEMA_FILENAME).write_text(
        json.dumps(feature_schema, indent=2), encoding="utf-8"
    )

    policy_meta = {
        "policy_artifact_version": POLICY_ARTIFACT_VERSION,
        "switchboard_version": switchboard_version,
        "model_artifact_version": MODEL_ARTIFACT_VERSION,
        "model_family": predictor.model_family,
        "threshold": float(threshold),
        "preset_name": preset_name,
        "feature_schema": feature_schema,
        "generated_at": _utc_now_iso(),
        "training_info": dict(training_info or {}),
        "files": {
            "model": MODEL_FILENAME,
            "feature_schema": FEATURE_SCHEMA_FILENAME,
        },
    }
    if notes:
        policy_meta["notes"] = notes

    (target / POLICY_FILENAME).write_text(
        json.dumps(policy_meta, indent=2), encoding="utf-8"
    )
    return target


# --- loading ----------------------------------------------------------------


def load_policy(path: str | Path) -> PolicyArtifact:
    directory = Path(path)
    _require_directory(directory)

    policy_meta = _read_policy_json(directory)
    _require_supported_policy_version(policy_meta, directory)

    feature_schema = _read_feature_schema(directory)
    _require_schema_matches_current_code(feature_schema, directory)

    model_path = directory / MODEL_FILENAME
    if not model_path.exists():
        raise PolicyArtifactError(f"Missing model artifact at {model_path}")
    predictor = SuccessPredictor.load(model_path)

    return PolicyArtifact(
        path=directory,
        predictor=predictor,
        threshold=float(policy_meta.get("threshold", 0.5)),
        preset_name=policy_meta.get("preset_name"),
        policy_artifact_version=int(policy_meta["policy_artifact_version"]),
        model_family=str(predictor.model_family),
        feature_cols=tuple(feature_schema.get("all") or FEATURE_COLS),
        numeric_cols=tuple(feature_schema.get("numeric") or NUMERIC_COLS),
        categorical_cols=tuple(feature_schema.get("categorical") or CATEGORICAL_COLS),
        generated_at=str(policy_meta.get("generated_at", "")),
        switchboard_version=str(policy_meta.get("switchboard_version", "")),
        model_artifact_version=int(policy_meta.get("model_artifact_version", 0)),
        notes=policy_meta.get("notes"),
        training_info=dict(policy_meta.get("training_info") or {}),
    )


# --- guardrails -------------------------------------------------------------


def _require_directory(directory: Path) -> None:
    if not directory.is_dir():
        raise PolicyArtifactError(
            f"Policy artifact path is not a directory: {directory}"
        )


def _read_policy_json(directory: Path) -> dict[str, Any]:
    policy_path = directory / POLICY_FILENAME
    if not policy_path.exists():
        raise PolicyArtifactError(f"Missing {POLICY_FILENAME} at {policy_path}")
    try:
        return json.loads(policy_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise PolicyArtifactError(f"Malformed {POLICY_FILENAME} at {policy_path}: {exc}") from exc


def _require_supported_policy_version(
    policy_meta: dict[str, Any], directory: Path
) -> None:
    version = policy_meta.get("policy_artifact_version")
    if version != POLICY_ARTIFACT_VERSION:
        raise PolicyArtifactError(
            f"Unsupported policy_artifact_version={version!r} in {directory}; "
            f"this build expects {POLICY_ARTIFACT_VERSION}"
        )


def _read_feature_schema(directory: Path) -> dict[str, Any]:
    schema_path = directory / FEATURE_SCHEMA_FILENAME
    if not schema_path.exists():
        raise PolicyArtifactError(f"Missing {FEATURE_SCHEMA_FILENAME} at {schema_path}")
    try:
        return json.loads(schema_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise PolicyArtifactError(
            f"Malformed {FEATURE_SCHEMA_FILENAME} at {schema_path}: {exc}"
        ) from exc


def _require_schema_matches_current_code(
    feature_schema: dict[str, Any], directory: Path
) -> None:
    missing_numeric = set(NUMERIC_COLS) - set(feature_schema.get("numeric") or [])
    missing_categorical = set(CATEGORICAL_COLS) - set(feature_schema.get("categorical") or [])
    missing = sorted(missing_numeric | missing_categorical)
    if missing:
        raise PolicyArtifactError(
            f"Feature schema in {directory} is missing columns required by the "
            f"current ModelSwitchboard build: {missing}"
        )


def _utc_now_iso() -> str:
    return datetime.now(tz=timezone.utc).isoformat(timespec="seconds")
