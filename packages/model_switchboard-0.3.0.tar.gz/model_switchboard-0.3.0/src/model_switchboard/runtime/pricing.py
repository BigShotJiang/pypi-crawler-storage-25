"""Pricing table and token-based cost accounting.

The pricing table replaces the old static ``DEFAULT_ROUTE_COSTS`` constant
with a real per-provider, per-1k-token rate table that loads from YAML. The
runtime uses it to:

- estimate per-request cost for candidate-route eligibility (cost ceiling).
- record actual cost on a dispatched request from observed token counts.

Pricing is explicit and auditable: every route names a provider, a model, and
its input/output rates per 1,000 tokens. A route missing from the table is a
fail-fast error at load time — silently falling back to "free" would hide
real billing risk.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import yaml


CANONICAL_TOKENS_IN: int = 400
CANONICAL_TOKENS_OUT: int = 200


@dataclass(frozen=True)
class RouteRate:
    """Per-1k-token rates for a single route."""

    route: str
    provider: str
    model: str
    input_per_1k_usd: float
    output_per_1k_usd: float

    def cost_for(self, tokens_in: int, tokens_out: int) -> float:
        return (
            (tokens_in / 1000.0) * self.input_per_1k_usd
            + (tokens_out / 1000.0) * self.output_per_1k_usd
        )


@dataclass(frozen=True)
class PricingTable:
    rates: dict[str, RouteRate]

    @property
    def routes(self) -> tuple[str, ...]:
        return tuple(self.rates.keys())

    def rate(self, route: str) -> RouteRate:
        if route not in self.rates:
            raise KeyError(
                f"Route {route!r} is not priced. Known routes: {list(self.rates)}"
            )
        return self.rates[route]

    # --- cost queries -----------------------------------------------------

    def canonical_cost(self, route: str) -> float:
        """Cost for the canonical 400-in/200-out sizing — same signal the
        benchmark layer uses so eligibility filters do not drift with the
        request body.
        """
        return self.cost_for(route, CANONICAL_TOKENS_IN, CANONICAL_TOKENS_OUT)

    def cost_for(self, route: str, tokens_in: int, tokens_out: int) -> float:
        return self.rate(route).cost_for(tokens_in, tokens_out)

    def canonical_cost_map(self) -> dict[str, float]:
        return {route: self.canonical_cost(route) for route in self.rates}


# --- loaders ---------------------------------------------------------------


def load_pricing_table(path: str | Path) -> PricingTable:
    """Load and validate a YAML pricing table."""
    payload = _read_yaml(Path(path))
    return pricing_table_from_dict(payload)


def pricing_table_from_dict(payload: dict[str, Any]) -> PricingTable:
    routes = payload.get("routes")
    if not isinstance(routes, dict) or not routes:
        raise ValueError("Pricing payload must contain a non-empty 'routes' mapping")

    rates: dict[str, RouteRate] = {}
    for route, entry in routes.items():
        rates[route] = _rate_from_entry(route, entry)
    return PricingTable(rates=rates)


def pricing_table_from_route_costs(route_costs: dict[str, float]) -> PricingTable:
    """Adapter for legacy flat cost dicts: backs them by fake per-1k-token rates
    that yield the supplied canonical cost. Useful in tests and for migrating
    from the pre-pricing runtime.
    """
    rates: dict[str, RouteRate] = {}
    for route, cost in route_costs.items():
        # Split the canonical cost across the canonical in/out sizing.
        in_rate = cost * 1000.0 / (CANONICAL_TOKENS_IN + CANONICAL_TOKENS_OUT)
        out_rate = in_rate
        rates[route] = RouteRate(
            route=route,
            provider="legacy",
            model="legacy",
            input_per_1k_usd=float(in_rate),
            output_per_1k_usd=float(out_rate),
        )
    return PricingTable(rates=rates)


# --- helpers ---------------------------------------------------------------


def _read_yaml(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Pricing file not found: {path}")
    return yaml.safe_load(path.read_text(encoding="utf-8")) or {}


def _rate_from_entry(route: str, entry: Any) -> RouteRate:
    if not isinstance(entry, dict):
        raise ValueError(f"Route {route!r} entry must be a mapping, got {type(entry).__name__}")
    required = ("provider", "model", "input_per_1k_usd", "output_per_1k_usd")
    missing = [key for key in required if key not in entry]
    if missing:
        raise ValueError(f"Route {route!r} missing required keys: {missing}")
    return RouteRate(
        route=route,
        provider=str(entry["provider"]),
        model=str(entry["model"]),
        input_per_1k_usd=float(entry["input_per_1k_usd"]),
        output_per_1k_usd=float(entry["output_per_1k_usd"]),
    )


def require_coverage(pricing: PricingTable, routes: Iterable[str]) -> None:
    """Fail fast if any expected route is missing from the pricing table."""
    missing = [r for r in routes if r not in pricing.rates]
    if missing:
        raise ValueError(f"Pricing table is missing rates for routes: {missing}")
