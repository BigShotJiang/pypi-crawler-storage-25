"""Telemetry protocol + built-in implementations.

The runtime emits three shapes of signal:

- **counter** — cardinality-tagged integers (decisions, escalations, errors).
- **histogram** — distribution of numeric samples (latency, cost, predicted
  success).
- **event** — a structured one-off record (policy deployed, kill switch
  tripped, an explicit operator action).

The :class:`Telemetry` protocol is deliberately OpenTelemetry-shaped so a
real OTel exporter slots in by implementing the three methods. The shipped
implementations are:

- :class:`NullTelemetry` — zero-cost default; the runtime's hot path stays
  observably quiet until you plug something in.
- :class:`LoggingTelemetry` — emits one line per signal via the standard
  ``logging`` module. Good for local pilots, CI artifacts, and dev loops.

Deliberately *not* shipped: a real OTel SDK or Prometheus exporter. Adding
those as required deps would bloat the default install; callers adopt them
by implementing :class:`Telemetry` against their existing observability
stack.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Mapping, Protocol


Labels = Mapping[str, str]
EMPTY_LABELS: Labels = {}


class Telemetry(Protocol):
    """Contract for a telemetry sink."""

    def counter(self, name: str, value: int = 1, labels: Labels = EMPTY_LABELS) -> None:
        ...

    def histogram(self, name: str, value: float, labels: Labels = EMPTY_LABELS) -> None:
        ...

    def event(self, name: str, attributes: Mapping[str, Any] = EMPTY_LABELS) -> None:
        ...


# --- null telemetry --------------------------------------------------------


class NullTelemetry:
    def counter(self, name: str, value: int = 1, labels: Labels = EMPTY_LABELS) -> None:
        return None

    def histogram(self, name: str, value: float, labels: Labels = EMPTY_LABELS) -> None:
        return None

    def event(self, name: str, attributes: Mapping[str, Any] = EMPTY_LABELS) -> None:
        return None


# --- logging telemetry -----------------------------------------------------


@dataclass
class LoggingTelemetry:
    """Emit each signal via ``logging.getLogger(logger_name)``.

    Counters and histograms share a single log line format so downstream
    tooling can parse them uniformly; events go out structured.
    """

    logger_name: str = "model_switchboard.telemetry"
    level: int = logging.INFO
    _logger: logging.Logger = field(init=False, repr=False)

    def __post_init__(self) -> None:
        self._logger = logging.getLogger(self.logger_name)

    def counter(self, name: str, value: int = 1, labels: Labels = EMPTY_LABELS) -> None:
        self._logger.log(
            self.level,
            "metric kind=counter name=%s value=%d labels=%s",
            name, int(value), _fmt_labels(labels),
        )

    def histogram(self, name: str, value: float, labels: Labels = EMPTY_LABELS) -> None:
        self._logger.log(
            self.level,
            "metric kind=histogram name=%s value=%.6f labels=%s",
            name, float(value), _fmt_labels(labels),
        )

    def event(self, name: str, attributes: Mapping[str, Any] = EMPTY_LABELS) -> None:
        self._logger.log(
            self.level,
            "event name=%s attrs=%s",
            name, _fmt_labels(attributes),
        )


# --- in-memory telemetry for tests -----------------------------------------


@dataclass
class RecordedSignal:
    kind: str
    name: str
    value: float | None = None
    labels: dict[str, str] = field(default_factory=dict)
    attributes: dict[str, Any] = field(default_factory=dict)


@dataclass
class InMemoryTelemetry:
    """Capture every emitted signal into a list. Useful for tests and for
    inspecting a shadow-replay run without wiring up a real sink.
    """

    signals: list[RecordedSignal] = field(default_factory=list)

    def counter(self, name: str, value: int = 1, labels: Labels = EMPTY_LABELS) -> None:
        self.signals.append(
            RecordedSignal(kind="counter", name=name, value=float(value), labels=dict(labels))
        )

    def histogram(self, name: str, value: float, labels: Labels = EMPTY_LABELS) -> None:
        self.signals.append(
            RecordedSignal(kind="histogram", name=name, value=float(value), labels=dict(labels))
        )

    def event(self, name: str, attributes: Mapping[str, Any] = EMPTY_LABELS) -> None:
        self.signals.append(
            RecordedSignal(kind="event", name=name, attributes=dict(attributes))
        )

    def counters_by_name(self, name: str) -> list[RecordedSignal]:
        return [s for s in self.signals if s.kind == "counter" and s.name == name]


# --- canonical metric names ------------------------------------------------

METRIC_DECISION_COUNT = "switchboard.decisions"
METRIC_DECISION_LATENCY_MS = "switchboard.decision_latency_ms"
METRIC_ROUTE_EXCLUDED = "switchboard.route_excluded"
METRIC_EXECUTION_ATTEMPT = "switchboard.execution_attempt"
METRIC_EXECUTION_SUCCESS = "switchboard.execution_success"
METRIC_EXECUTION_FAILURE = "switchboard.execution_failure"
METRIC_ESCALATION_TRIGGERED = "switchboard.escalation_triggered"
METRIC_BUDGET_EXHAUSTED = "switchboard.budget_exhausted"
METRIC_COST_USD = "switchboard.request_cost_usd"
METRIC_TOKENS_IN = "switchboard.tokens_in"
METRIC_TOKENS_OUT = "switchboard.tokens_out"

EVENT_KILL_SWITCH_TRIPPED = "switchboard.kill_switch_tripped"
EVENT_POLICY_LOADED = "switchboard.policy_loaded"
EVENT_ROLLBACK_TRIGGERED = "switchboard.rollback_triggered"


# --- helpers ---------------------------------------------------------------


def _fmt_labels(labels: Mapping[str, Any]) -> str:
    if not labels:
        return "{}"
    parts = [f"{k}={v}" for k, v in sorted(labels.items())]
    return "{" + ", ".join(parts) + "}"
