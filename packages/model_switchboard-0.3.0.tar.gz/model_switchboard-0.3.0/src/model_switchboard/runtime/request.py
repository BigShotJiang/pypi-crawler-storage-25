"""Runtime request shape.

``RuntimeRequest`` is the request surface the runtime router accepts. It is
intentionally close to what a real production system would already have on
hand — request id, prompt, task family, SLAs — and keeps control-plane
concerns (tenant id, compliance flags, escalation opt-in) explicit rather
than hidden in ``metadata``.

The model is frozen so the router cannot mutate the incoming request; any
derived state (extracted features, eligibility filters, chosen route) lives
on the :class:`RoutingDecision` instead.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from model_switchboard.schemas.request import RequestRecord


TaskFamily = Literal["classification", "extraction", "summarization", "drafting"]
RiskTier = Literal["low", "medium", "high"]


class RuntimeRequest(BaseModel):
    """Production-shaped request the runtime router operates on."""

    model_config = ConfigDict(frozen=True)

    request_id: str
    task_family: TaskFamily
    prompt: str
    context: str | None = None

    latency_budget_ms: int = 5000
    cost_ceiling_usd: float | None = None
    risk_tier: RiskTier = "low"

    tenant_id: str | None = None
    workspace_id: str | None = None
    compliance_flags: tuple[str, ...] = Field(default_factory=tuple)

    allow_escalation: bool = True
    metadata: dict[str, Any] = Field(default_factory=dict)

    def to_request_record(self) -> RequestRecord:
        """Adapt to the benchmark-shaped ``RequestRecord`` used by feature
        extraction. Runtime-specific fields (tenant, compliance, budget) are
        preserved under ``metadata['runtime']`` so feature extractors can
        still read them if needed, but they do not alter the existing
        benchmark feature surface.
        """
        runtime_meta = {
            "latency_budget_ms": self.latency_budget_ms,
            "cost_ceiling_usd": self.cost_ceiling_usd,
            "tenant_id": self.tenant_id,
            "workspace_id": self.workspace_id,
            "compliance_flags": list(self.compliance_flags),
            "allow_escalation": self.allow_escalation,
        }
        merged_metadata = {**self.metadata, "runtime": runtime_meta}
        return RequestRecord(
            request_id=self.request_id,
            prompt=self.prompt,
            context=self.context,
            task_family=self.task_family,
            metadata=merged_metadata,
            latency_sla_ms=int(self.latency_budget_ms),
            risk_tier=self.risk_tier,
        )
