"""Runtime decision record."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class ExcludedRoute(BaseModel):
    model_config = ConfigDict(frozen=True)

    route: str
    reason: str
    detail: str | None = None


class RoutingDecision(BaseModel):
    model_config = ConfigDict(frozen=True)

    # identity / provenance ------------------------------------------------
    request_id: str
    decided_at: str = Field(default_factory=lambda: _utc_now_iso())
    policy_artifact_version: int
    policy_preset: str | None = None
    threshold: float
    model_family: str
    switchboard_version: str

    # inputs (safe summaries, never the raw prompt/context) ----------------
    task_family: str
    risk_tier: str
    feature_summary: dict[str, Any]

    # evaluation -----------------------------------------------------------
    predicted_success: dict[str, float] = Field(default_factory=dict)
    candidate_routes: tuple[str, ...] = ()
    excluded_routes: tuple[ExcludedRoute, ...] = ()
    health_snapshot: dict[str, Any] = Field(default_factory=dict)

    # chosen --------------------------------------------------------------
    allow_escalation: bool
    initial_route: str | None = None
    final_route: str | None = None
    escalation_path: tuple[str, ...] = ()
    escalated: bool = False
    route_reason: str = ""
    notes: str | None = None


def decision_to_jsonable(decision: RoutingDecision) -> dict[str, Any]:
    return decision.model_dump(mode="json")


def _utc_now_iso() -> str:
    return datetime.now(tz=timezone.utc).isoformat(timespec="seconds")
