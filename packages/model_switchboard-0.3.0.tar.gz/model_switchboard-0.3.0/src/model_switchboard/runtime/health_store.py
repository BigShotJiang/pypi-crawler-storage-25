"""Pluggable backing store for the health registry.

``HealthRegistry`` was in-process-only. That is fine for a single-node deployment
but breaks the moment a service runs behind more than one worker: each worker
has its own view of which route is open-circuited, so operator controls like
"disable the frontier tier" apply only to the process that received the admin
request.

This module defines a small :class:`HealthStore` protocol with two shipped
implementations:

- :class:`InMemoryHealthStore` — the previous behaviour, still the default.
- :class:`FileHealthStore` — JSON snapshots persisted to disk with atomic
  writes. Safe across processes on a single host; suitable for local pilots
  and small deployments. A real multi-region deployment should implement the
  same protocol against Redis or a durable store.

The protocol is deliberately narrow: ``load`` returns the full snapshot,
``save`` replaces it. The registry is still the authority on transitions; the
store just carries the state over process restarts and across workers.
"""

from __future__ import annotations

import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Protocol


class HealthStore(Protocol):
    """Backing store for health-registry state."""

    def load(self) -> dict[str, dict[str, Any]]:
        """Return ``{route: snapshot_dict}`` or ``{}`` if nothing persisted."""

    def save(self, snapshot: dict[str, dict[str, Any]]) -> None:
        """Persist ``snapshot`` atomically, replacing any prior state."""


# --- in-memory --------------------------------------------------------------


@dataclass
class InMemoryHealthStore:
    _state: dict[str, dict[str, Any]] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self._state is None:
            self._state = {}

    def load(self) -> dict[str, dict[str, Any]]:
        return {route: dict(snapshot) for route, snapshot in self._state.items()}

    def save(self, snapshot: dict[str, dict[str, Any]]) -> None:
        self._state = {route: dict(s) for route, s in snapshot.items()}


# --- file-backed ------------------------------------------------------------


class FileHealthStore:
    """JSON snapshots on disk with atomic replace.

    Writes go to a temp file in the same directory and then ``os.replace``
    swaps them in. That gives a posix-atomic rename on both Linux and Windows
    (Python 3.3+). Concurrent writers can still overwrite each other's last
    update — this is last-write-wins, not a distributed lock. It is enough
    for operator-driven admin events and periodic circuit-breaker updates
    on one host.
    """

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def load(self) -> dict[str, dict[str, Any]]:
        if not self.path.exists():
            return {}
        text = self.path.read_text(encoding="utf-8").strip()
        if not text:
            return {}
        data = json.loads(text)
        _require_snapshot_shape(data)
        return data

    def save(self, snapshot: dict[str, dict[str, Any]]) -> None:
        _require_snapshot_shape(snapshot)
        fd, tmp_path_str = tempfile.mkstemp(
            prefix=".health-",
            suffix=".json.tmp",
            dir=str(self.path.parent),
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(snapshot, f, indent=2, sort_keys=True)
            os.replace(tmp_path_str, self.path)
        except Exception:
            # Best-effort cleanup of the temp file on failure.
            tmp_path = Path(tmp_path_str)
            if tmp_path.exists():
                tmp_path.unlink()
            raise


# --- helpers ---------------------------------------------------------------


def _require_snapshot_shape(payload: Any) -> None:
    if not isinstance(payload, dict):
        raise ValueError(f"Health snapshot must be a dict, got {type(payload).__name__}")
    for route, entry in payload.items():
        if not isinstance(route, str):
            raise ValueError(f"Health snapshot keys must be route names, got {route!r}")
        if not isinstance(entry, dict):
            raise ValueError(
                f"Health snapshot value for {route!r} must be a dict, "
                f"got {type(entry).__name__}"
            )


def snapshot_keys() -> tuple[str, ...]:
    """Fields serialised in a health snapshot (informational)."""
    return ("route", "status", "recent_failures", "recent_latency_ms", "enabled", "reason")


def empty_snapshot_for(routes: Iterable[str]) -> dict[str, dict[str, Any]]:
    """Build a 'healthy' starting snapshot for the given routes."""
    return {
        route: {
            "route": route,
            "status": "healthy",
            "recent_failures": 0,
            "recent_latency_ms": None,
            "enabled": True,
            "reason": None,
        }
        for route in routes
    }
