"""Runtime routing."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Iterable

from model_switchboard.execution.escalation import escalation_chain
from model_switchboard.features.extractors import RouteFeatures, extract_features
from model_switchboard.reporting.metrics import ROUTE_TIERS
from model_switchboard.runtime import telemetry as tel
from model_switchboard.runtime.compliance import PolicyEngine, default_policy_engine
from model_switchboard.runtime.decision import ExcludedRoute, RoutingDecision
from model_switchboard.runtime.health import HealthRegistry
from model_switchboard.runtime.policy import PolicyArtifact
from model_switchboard.runtime.pricing import (
    PricingTable,
    pricing_table_from_route_costs,
)
from model_switchboard.runtime.request import RuntimeRequest
from model_switchboard.runtime.telemetry import NullTelemetry, Telemetry


REASON_NO_ROUTE_ABOVE_THRESHOLD = "no_route_met_threshold"
REASON_LEARNED_MIN_COST = "learned_min_cost_above_threshold"
REASON_ESCALATION_PLAN = "escalation_chain_planned"

FALLBACK_ROUTE: str = "frontier"

DEFAULT_ROUTE_COSTS: dict[str, float] = {"small": 0.02, "mid": 0.10, "frontier": 0.60}


@dataclass(frozen=True)
class _Candidate:
    route: str
    predicted_success: float
    cost: float


@dataclass
class _EvaluationTrace:
    excluded: list[ExcludedRoute] = field(default_factory=list)

    def exclude(self, route: str, reason: str, detail: str | None = None) -> None:
        self.excluded.append(ExcludedRoute(route=route, reason=reason, detail=detail))


class RuntimeRouter:
    def __init__(
        self,
        artifact: PolicyArtifact,
        *,
        health: HealthRegistry | None = None,
        pricing: PricingTable | None = None,
        policy_engine: PolicyEngine | None = None,
        telemetry: Telemetry | None = None,
        route_costs: dict[str, float] | None = None,
    ) -> None:
        self.artifact = artifact
        self.health = health or HealthRegistry(ROUTE_TIERS)
        self.pricing = _resolve_pricing(pricing, route_costs)
        self.policy_engine = policy_engine or default_policy_engine()
        self.telemetry: Telemetry = telemetry or NullTelemetry()

    # --- public API --------------------------------------------------------

    def decide(self, request: RuntimeRequest) -> RoutingDecision:
        start = time.monotonic()
        trace = _EvaluationTrace()
        features = extract_features(request.to_request_record())
        predicted_success = self.artifact.predictor.predict_success(features)

        eligible = self._build_candidates(request, predicted_success, trace)
        initial_route, route_reason = self._choose_initial_route(eligible, trace)
        escalation_path = self._plan_escalation(initial_route, request)

        decision = RoutingDecision(
            request_id=request.request_id,
            policy_artifact_version=self.artifact.policy_artifact_version,
            policy_preset=self.artifact.preset_name,
            threshold=self.artifact.threshold,
            model_family=self.artifact.model_family,
            switchboard_version=self.artifact.switchboard_version,
            task_family=request.task_family,
            risk_tier=request.risk_tier,
            feature_summary=_feature_summary(features),
            predicted_success=predicted_success,
            candidate_routes=tuple(c.route for c in eligible),
            excluded_routes=tuple(trace.excluded),
            health_snapshot={
                route: self.health.snapshot(route).snapshot()
                for route in ROUTE_TIERS
            },
            allow_escalation=request.allow_escalation,
            initial_route=initial_route,
            final_route=initial_route,
            escalation_path=tuple(escalation_path),
            escalated=False,
            route_reason=route_reason,
        )
        self._emit_decision_metrics(decision, started_at=start)
        return decision

    # --- candidate assembly ------------------------------------------------

    def _build_candidates(
        self,
        request: RuntimeRequest,
        predicted_success: dict[str, float],
        trace: _EvaluationTrace,
    ) -> list[_Candidate]:
        candidates: list[_Candidate] = []
        for route in ROUTE_TIERS:
            if self._is_ineligible(route, request, trace):
                continue
            cost = self.pricing.canonical_cost(route)
            predicted = float(predicted_success.get(route, 0.0))
            if predicted < self.artifact.threshold:
                trace.exclude(
                    route,
                    "below_threshold",
                    detail=f"predicted_success={predicted:.3f} < threshold={self.artifact.threshold:.3f}",
                )
                continue
            candidates.append(_Candidate(route=route, predicted_success=predicted, cost=cost))
        return candidates

    def _is_ineligible(
        self,
        route: str,
        request: RuntimeRequest,
        trace: _EvaluationTrace,
    ) -> bool:
        health_reason = self.health.ineligibility_reason(route)
        if health_reason is not None:
            trace.exclude(route, "health", detail=health_reason)
            return True

        violations = self.policy_engine.violations(request, route)
        if violations:
            first = violations[0]
            trace.exclude(route, "compliance", detail=f"{first.policy}:{first.reason}")
            return True

        cost = self.pricing.canonical_cost(route)
        if request.cost_ceiling_usd is not None and cost > request.cost_ceiling_usd:
            trace.exclude(
                route,
                "cost_ceiling",
                detail=f"route_cost={cost:.4f} > ceiling={request.cost_ceiling_usd:.4f}",
            )
            return True

        return False

    # --- selection ---------------------------------------------------------

    def _choose_initial_route(
        self,
        eligible: list[_Candidate],
        trace: _EvaluationTrace,
    ) -> tuple[str, str]:
        if eligible:
            chosen = min(eligible, key=lambda c: c.cost)
            return chosen.route, REASON_LEARNED_MIN_COST

        fallback = self._fallback_route(trace)
        return fallback, REASON_NO_ROUTE_ABOVE_THRESHOLD

    def _fallback_route(self, trace: _EvaluationTrace) -> str:
        healthy = [r for r in ROUTE_TIERS if self.health.is_eligible(r)]
        if not healthy:
            trace.exclude(
                FALLBACK_ROUTE,
                "all_routes_ineligible",
                detail="no healthy route; returning conservative default",
            )
            return FALLBACK_ROUTE
        return min(healthy, key=lambda r: self.pricing.canonical_cost(r))

    def _plan_escalation(
        self, initial_route: str | None, request: RuntimeRequest
    ) -> list[str]:
        if not request.allow_escalation or initial_route is None:
            return []
        return [
            route
            for route in escalation_chain(initial_route)
            if self.health.is_eligible(route)
        ]

    # --- telemetry ---------------------------------------------------------

    def _emit_decision_metrics(self, decision: RoutingDecision, started_at: float) -> None:
        labels = {
            "task_family": decision.task_family,
            "route": decision.initial_route or "none",
            "reason": decision.route_reason,
        }
        self.telemetry.counter(tel.METRIC_DECISION_COUNT, labels=labels)
        elapsed_ms = (time.monotonic() - started_at) * 1000
        self.telemetry.histogram(
            tel.METRIC_DECISION_LATENCY_MS, elapsed_ms, labels={"stage": "decide"}
        )
        for excluded in decision.excluded_routes:
            self.telemetry.counter(
                tel.METRIC_ROUTE_EXCLUDED,
                labels={"route": excluded.route, "reason": excluded.reason},
            )


# --- helpers ---------------------------------------------------------------


def _resolve_pricing(
    pricing: PricingTable | None, route_costs: dict[str, float] | None
) -> PricingTable:
    if pricing is not None and route_costs is not None:
        raise ValueError(
            "Provide either `pricing` or `route_costs`, not both; pricing wins."
        )
    if pricing is not None:
        _require_coverage(pricing, ROUTE_TIERS)
        return pricing
    return pricing_table_from_route_costs(dict(route_costs or DEFAULT_ROUTE_COSTS))


def _require_coverage(pricing: PricingTable, routes: Iterable[str]) -> None:
    missing = [r for r in routes if r not in pricing.rates]
    if missing:
        raise ValueError(f"Pricing table is missing rates for routes: {missing}")


def _feature_summary(features: RouteFeatures) -> dict[str, object]:
    """Return a compact, log-safe view of the feature row. Deliberately omits
    raw prompt/context so decision logs do not carry user content.
    """
    return {
        "task_family": features.task_family,
        "difficulty_num": int(features.difficulty_num),
        "prompt_tokens": int(features.prompt_tokens),
        "context_tokens": int(features.context_tokens),
        "total_tokens": int(features.total_tokens),
        "reasoning_keyword_hits": int(features.reasoning_keyword_hits),
        "security_keyword_hits": int(features.security_keyword_hits),
        "requires_long_context": int(features.requires_long_context),
        "risk_tier_num": int(features.risk_tier_num),
    }
