"""Tiny bridge from a :class:`RuntimeRequest` to extracted features.

The heuristic router, the learned router, and the baseline-compare mode all
want a :class:`RouteFeatures` row. Centralising the adapter keeps the rest of
the runtime code free of calls to the benchmark's ``RequestRecord`` shape.
"""

from __future__ import annotations

from model_switchboard.features.extractors import RouteFeatures, extract_features
from model_switchboard.runtime.request import RuntimeRequest


def features_for_heuristic(request: RuntimeRequest) -> RouteFeatures:
    return extract_features(request.to_request_record())
