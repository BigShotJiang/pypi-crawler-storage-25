"""Runtime execution."""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeout
from dataclasses import dataclass, field
from typing import Any, Mapping, Protocol

from model_switchboard.runtime import telemetry as tel
from model_switchboard.runtime.decision import RoutingDecision
from model_switchboard.runtime.health import HealthRegistry
from model_switchboard.runtime.pricing import PricingTable
from model_switchboard.runtime.request import RuntimeRequest
from model_switchboard.runtime.telemetry import NullTelemetry, Telemetry


DEFAULT_PER_ROUTE_TIMEOUT_MS: int = 10_000


# --- adapter protocols -----------------------------------------------------


@dataclass(frozen=True)
class ProviderResponse:
    route: str
    output_text: str
    tokens_in: int
    tokens_out: int
    latency_ms: int


class ProviderAdapter(Protocol):
    def invoke(self, route: str, request: RuntimeRequest) -> ProviderResponse:
        ...


class OutcomeVerifier(Protocol):
    def verify(
        self, request: RuntimeRequest, response: ProviderResponse
    ) -> tuple[bool, float]:
        ...


class ProviderError(Exception):
    """Provider call failed."""


class ProviderTimeout(ProviderError):
    """Provider call timed out."""


class BudgetExhausted(RuntimeError):
    """Request budget was exhausted."""


# --- result record ---------------------------------------------------------


@dataclass(frozen=True)
class RouteAttempt:
    route: str
    passed: bool
    score: float
    tokens_in: int
    tokens_out: int
    cost_usd: float
    latency_ms: int
    error: str | None = None


@dataclass(frozen=True)
class ExecutionResult:
    request_id: str
    initial_route: str | None
    final_route: str | None
    passed: bool
    final_score: float
    total_cost_usd: float
    total_latency_ms: int
    attempts: tuple[RouteAttempt, ...]
    escalated: bool
    budget_exhausted: bool = False
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "request_id": self.request_id,
            "initial_route": self.initial_route,
            "final_route": self.final_route,
            "passed": self.passed,
            "final_score": self.final_score,
            "total_cost_usd": self.total_cost_usd,
            "total_latency_ms": self.total_latency_ms,
            "attempts": [
                {
                    "route": a.route,
                    "passed": a.passed,
                    "score": a.score,
                    "tokens_in": a.tokens_in,
                    "tokens_out": a.tokens_out,
                    "cost_usd": a.cost_usd,
                    "latency_ms": a.latency_ms,
                    "error": a.error,
                }
                for a in self.attempts
            ],
            "escalated": self.escalated,
            "budget_exhausted": self.budget_exhausted,
            "error": self.error,
        }


# --- executor --------------------------------------------------------------


class RuntimeExecutor:
    def __init__(
        self,
        provider: ProviderAdapter,
        verifier: OutcomeVerifier,
        pricing: PricingTable,
        *,
        health: HealthRegistry | None = None,
        telemetry: Telemetry | None = None,
        per_route_timeout_ms: int = DEFAULT_PER_ROUTE_TIMEOUT_MS,
    ) -> None:
        self.provider = provider
        self.verifier = verifier
        self.pricing = pricing
        self.health = health
        self.telemetry: Telemetry = telemetry or NullTelemetry()
        self.per_route_timeout_ms = int(per_route_timeout_ms)

    # --- public API --------------------------------------------------------

    def execute(
        self, request: RuntimeRequest, decision: RoutingDecision
    ) -> ExecutionResult:
        attempts: list[RouteAttempt] = []
        total_cost = 0.0
        total_latency = 0
        budget_exhausted = False
        final_error: str | None = None

        plan = self._attempt_plan(decision)
        if not plan:
            return self._empty_result(request, decision, "no_route_available")

        for index, route in enumerate(plan):
            try:
                self._guard_budget(request, total_cost, total_latency, route)
            except BudgetExhausted as exc:
                budget_exhausted = True
                final_error = str(exc)
                break

            attempt = self._attempt_route(request, route)
            attempts.append(attempt)
            total_cost += attempt.cost_usd
            total_latency += attempt.latency_ms

            if attempt.passed:
                self.telemetry.counter(
                    tel.METRIC_EXECUTION_SUCCESS, labels={"route": route}
                )
                if index > 0:
                    self.telemetry.counter(tel.METRIC_ESCALATION_TRIGGERED)
                return self._success_result(request, decision, attempts, total_cost, total_latency)

            if attempt.error:
                self.telemetry.counter(
                    tel.METRIC_EXECUTION_FAILURE,
                    labels={"route": route, "kind": attempt.error},
                )

        return self._failure_result(
            request,
            decision,
            attempts,
            total_cost,
            total_latency,
            budget_exhausted=budget_exhausted,
            error=final_error,
        )

    # --- planning ----------------------------------------------------------

    def _attempt_plan(self, decision: RoutingDecision) -> list[str]:
        plan: list[str] = []
        if decision.initial_route is not None:
            plan.append(decision.initial_route)
        plan.extend(decision.escalation_path)
        return plan

    # --- single attempt ----------------------------------------------------

    def _attempt_route(self, request: RuntimeRequest, route: str) -> RouteAttempt:
        self.telemetry.counter(tel.METRIC_EXECUTION_ATTEMPT, labels={"route": route})
        started = time.monotonic()
        try:
            response = self._invoke_with_timeout(route, request)
        except ProviderTimeout as exc:
            elapsed_ms = int((time.monotonic() - started) * 1000)
            self._record_health_failure(route, reason="timeout")
            return RouteAttempt(
                route=route,
                passed=False,
                score=0.0,
                tokens_in=0,
                tokens_out=0,
                cost_usd=0.0,
                latency_ms=elapsed_ms,
                error="timeout",
            )
        except ProviderError as exc:
            elapsed_ms = int((time.monotonic() - started) * 1000)
            self._record_health_failure(route, reason="provider_error")
            return RouteAttempt(
                route=route,
                passed=False,
                score=0.0,
                tokens_in=0,
                tokens_out=0,
                cost_usd=0.0,
                latency_ms=elapsed_ms,
                error=f"provider_error:{exc}",
            )

        passed, score = self.verifier.verify(request, response)
        cost = self.pricing.cost_for(route, response.tokens_in, response.tokens_out)
        self._emit_attempt_metrics(route, response, cost, passed)
        self._record_health_result(route, passed, response.latency_ms)
        return RouteAttempt(
            route=route,
            passed=bool(passed),
            score=float(score),
            tokens_in=int(response.tokens_in),
            tokens_out=int(response.tokens_out),
            cost_usd=float(cost),
            latency_ms=int(response.latency_ms),
            error=None,
        )

    def _invoke_with_timeout(
        self, route: str, request: RuntimeRequest
    ) -> ProviderResponse:
        with ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(self.provider.invoke, route, request)
            try:
                return future.result(timeout=self.per_route_timeout_ms / 1000.0)
            except FutureTimeout as exc:
                future.cancel()
                raise ProviderTimeout(
                    f"Route {route!r} exceeded {self.per_route_timeout_ms}ms"
                ) from exc

    # --- health wiring -----------------------------------------------------

    def _record_health_result(
        self, route: str, passed: bool, latency_ms: int
    ) -> None:
        if self.health is None:
            return
        if passed:
            self.health.record_success(route, latency_ms=latency_ms)
        else:
            self.health.record_failure(route, reason="verifier_failed")

    def _record_health_failure(self, route: str, reason: str) -> None:
        if self.health is None:
            return
        self.health.record_failure(route, reason=reason)

    # --- telemetry ---------------------------------------------------------

    def _emit_attempt_metrics(
        self,
        route: str,
        response: ProviderResponse,
        cost: float,
        passed: bool,
    ) -> None:
        labels = {"route": route, "outcome": "pass" if passed else "fail"}
        self.telemetry.histogram(tel.METRIC_COST_USD, cost, labels=labels)
        self.telemetry.histogram(
            tel.METRIC_DECISION_LATENCY_MS, float(response.latency_ms), labels=labels
        )
        self.telemetry.histogram(
            tel.METRIC_TOKENS_IN, float(response.tokens_in), labels={"route": route}
        )
        self.telemetry.histogram(
            tel.METRIC_TOKENS_OUT, float(response.tokens_out), labels={"route": route}
        )

    # --- budget enforcement ------------------------------------------------

    def _guard_budget(
        self,
        request: RuntimeRequest,
        cost_so_far: float,
        latency_so_far: int,
        next_route: str,
    ) -> None:
        if request.cost_ceiling_usd is not None:
            projected = cost_so_far + self.pricing.canonical_cost(next_route)
            if projected > request.cost_ceiling_usd:
                self.telemetry.counter(
                    tel.METRIC_BUDGET_EXHAUSTED,
                    labels={"kind": "cost", "route": next_route},
                )
                raise BudgetExhausted(
                    f"cost_ceiling_exceeded: projected={projected:.4f} > "
                    f"ceiling={request.cost_ceiling_usd:.4f}"
                )
        if latency_so_far > 0 and latency_so_far > request.latency_budget_ms:
            self.telemetry.counter(
                tel.METRIC_BUDGET_EXHAUSTED,
                labels={"kind": "latency", "route": next_route},
            )
            raise BudgetExhausted(
                f"latency_budget_exceeded: spent={latency_so_far}ms > "
                f"budget={request.latency_budget_ms}ms"
            )

    # --- result assembly ---------------------------------------------------

    def _empty_result(
        self, request: RuntimeRequest, decision: RoutingDecision, error: str
    ) -> ExecutionResult:
        return ExecutionResult(
            request_id=request.request_id,
            initial_route=decision.initial_route,
            final_route=None,
            passed=False,
            final_score=0.0,
            total_cost_usd=0.0,
            total_latency_ms=0,
            attempts=(),
            escalated=False,
            budget_exhausted=False,
            error=error,
        )

    def _success_result(
        self,
        request: RuntimeRequest,
        decision: RoutingDecision,
        attempts: list[RouteAttempt],
        total_cost: float,
        total_latency: int,
    ) -> ExecutionResult:
        last = attempts[-1]
        return ExecutionResult(
            request_id=request.request_id,
            initial_route=decision.initial_route,
            final_route=last.route,
            passed=True,
            final_score=last.score,
            total_cost_usd=total_cost,
            total_latency_ms=total_latency,
            attempts=tuple(attempts),
            escalated=len(attempts) > 1,
        )

    def _failure_result(
        self,
        request: RuntimeRequest,
        decision: RoutingDecision,
        attempts: list[RouteAttempt],
        total_cost: float,
        total_latency: int,
        *,
        budget_exhausted: bool,
        error: str | None,
    ) -> ExecutionResult:
        final_route = attempts[-1].route if attempts else decision.initial_route
        final_score = attempts[-1].score if attempts else 0.0
        return ExecutionResult(
            request_id=request.request_id,
            initial_route=decision.initial_route,
            final_route=final_route,
            passed=False,
            final_score=final_score,
            total_cost_usd=total_cost,
            total_latency_ms=total_latency,
            attempts=tuple(attempts),
            escalated=len(attempts) > 1,
            budget_exhausted=budget_exhausted,
            error=error,
        )
