"""Production-oriented runtime layer for ModelSwitchboard.

The ``runtime`` package is separate from the benchmark orchestration on purpose:
the benchmark is pandas-heavy and offline; the runtime is request-oriented and
designed for shadow-mode deployment against a saved policy artifact.

Nothing here has been validated against real production traffic. This is a
control-plane surface — policy packaging, a decision layer, a compliance engine,
a pricing table, health + store abstractions, telemetry, an executor, and
structured decision logging — ready for controlled shadow-mode rollout.
"""

from model_switchboard.runtime.compliance import (
    CompliancePolicy,
    NoFrontier,
    PiiStrict,
    PolicyEngine,
    PolicyViolation,
    Redactor,
    Residency,
    RouteAllowlist,
    default_policy_engine,
    default_redactor,
)
from model_switchboard.runtime.decision import (
    ExcludedRoute,
    RoutingDecision,
    decision_to_jsonable,
)
from model_switchboard.runtime.decision_log import DecisionLogger
from model_switchboard.runtime.executor import (
    BudgetExhausted,
    ExecutionResult,
    OutcomeVerifier,
    ProviderAdapter,
    ProviderError,
    ProviderResponse,
    ProviderTimeout,
    RouteAttempt,
    RuntimeExecutor,
)
from model_switchboard.runtime.health import (
    HealthRegistry,
    RouteHealth,
    RouteStatus,
)
from model_switchboard.runtime.health_store import (
    FileHealthStore,
    HealthStore,
    InMemoryHealthStore,
)
from model_switchboard.runtime.policy import (
    POLICY_ARTIFACT_VERSION,
    PolicyArtifact,
    PolicyArtifactError,
    load_policy,
    pack_policy,
)
from model_switchboard.runtime.pricing import (
    PricingTable,
    RouteRate,
    load_pricing_table,
    pricing_table_from_dict,
    pricing_table_from_route_costs,
)
from model_switchboard.runtime.request import RuntimeRequest
from model_switchboard.runtime.router import RuntimeRouter
from model_switchboard.runtime.telemetry import (
    InMemoryTelemetry,
    LoggingTelemetry,
    NullTelemetry,
    RecordedSignal,
    Telemetry,
)

__all__ = [
    # Core runtime
    "RuntimeRouter",
    "RuntimeRequest",
    "RuntimeExecutor",
    "RoutingDecision",
    "ExcludedRoute",
    "DecisionLogger",
    "decision_to_jsonable",
    # Policy
    "PolicyArtifact",
    "PolicyArtifactError",
    "POLICY_ARTIFACT_VERSION",
    "load_policy",
    "pack_policy",
    # Compliance
    "CompliancePolicy",
    "PolicyEngine",
    "PolicyViolation",
    "PiiStrict",
    "NoFrontier",
    "Residency",
    "RouteAllowlist",
    "Redactor",
    "default_policy_engine",
    "default_redactor",
    # Pricing
    "PricingTable",
    "RouteRate",
    "load_pricing_table",
    "pricing_table_from_dict",
    "pricing_table_from_route_costs",
    # Health
    "HealthRegistry",
    "RouteHealth",
    "RouteStatus",
    "HealthStore",
    "InMemoryHealthStore",
    "FileHealthStore",
    # Execution
    "ProviderAdapter",
    "ProviderResponse",
    "ProviderError",
    "ProviderTimeout",
    "BudgetExhausted",
    "OutcomeVerifier",
    "RouteAttempt",
    "ExecutionResult",
    # Telemetry
    "Telemetry",
    "NullTelemetry",
    "LoggingTelemetry",
    "InMemoryTelemetry",
    "RecordedSignal",
]
