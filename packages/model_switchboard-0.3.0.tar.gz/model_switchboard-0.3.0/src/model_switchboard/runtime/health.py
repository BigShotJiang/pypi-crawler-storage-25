"""Provider health and route eligibility.

The health registry is an explicit, in-memory representation of whether each
route is currently safe to use. It is small by design — enough to encode the
failure cases the runtime layer actually reasons about:

- ``healthy``     — free to use.
- ``degraded``    — still usable, but caller/operator should know the route
                    is showing elevated failure or latency.
- ``circuit_open`` — temporarily excluded after consecutive failures.
- ``disabled``    — operator disabled this route explicitly.

Consumers do not mutate ``RouteHealth`` directly. They call ``record_success``
/ ``record_failure`` / ``disable`` / ``enable`` on the registry, which applies
the state transitions and exposes the resulting snapshot.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from time import monotonic
from typing import Iterable, Mapping

from model_switchboard.runtime.health_store import HealthStore, InMemoryHealthStore


class RouteStatus(str, Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    CIRCUIT_OPEN = "circuit_open"
    DISABLED = "disabled"


# Tunables are module-level constants rather than constructor arguments so the
# default behaviour is visible at a glance. The registry exposes overrides via
# its constructor for tests and deployments that need different thresholds.
DEFAULT_CIRCUIT_OPEN_AFTER_FAILURES: int = 3
DEFAULT_CIRCUIT_RESET_SECONDS: float = 30.0
DEFAULT_DEGRADED_LATENCY_MS: int = 2500


@dataclass
class RouteHealth:
    """Latest known state for a single route.

    ``recent_failures`` is the consecutive failure count since the last success.
    ``opened_at`` is the monotonic timestamp at which the circuit opened, or
    ``None`` when the circuit is closed.
    """

    route: str
    status: RouteStatus = RouteStatus.HEALTHY
    recent_failures: int = 0
    recent_latency_ms: int | None = None
    enabled: bool = True
    reason: str | None = None
    opened_at: float | None = None

    def snapshot(self) -> dict[str, object]:
        return {
            "route": self.route,
            "status": self.status.value,
            "recent_failures": int(self.recent_failures),
            "recent_latency_ms": self.recent_latency_ms,
            "enabled": bool(self.enabled),
            "reason": self.reason,
        }


class HealthRegistry:
    """Health tracker for a small set of routes, backed by a pluggable store.

    The registry is the authority on transitions — ``record_success``,
    ``record_failure``, ``disable``, ``enable`` all run here. The store is a
    thin persistence layer: every mutation is flushed to it immediately, and
    queries refresh from it so a second process' admin command becomes visible
    here on the next check.
    """

    def __init__(
        self,
        routes: Iterable[str],
        *,
        circuit_open_after_failures: int = DEFAULT_CIRCUIT_OPEN_AFTER_FAILURES,
        circuit_reset_seconds: float = DEFAULT_CIRCUIT_RESET_SECONDS,
        degraded_latency_ms: int = DEFAULT_DEGRADED_LATENCY_MS,
        store: HealthStore | None = None,
    ) -> None:
        self._routes: dict[str, RouteHealth] = {r: RouteHealth(route=r) for r in routes}
        self._circuit_open_after_failures = int(circuit_open_after_failures)
        self._circuit_reset_seconds = float(circuit_reset_seconds)
        self._degraded_latency_ms = int(degraded_latency_ms)
        self._store: HealthStore = store if store is not None else InMemoryHealthStore()
        self._rehydrate_from_store()

    # --- state transitions -------------------------------------------------

    def record_success(self, route: str, latency_ms: int | None = None) -> None:
        self._rehydrate_from_store()
        health = self._require(route)
        health.recent_failures = 0
        health.recent_latency_ms = latency_ms
        health.opened_at = None
        if health.enabled:
            health.status = self._status_for_latency(latency_ms)
            health.reason = None if health.status is RouteStatus.HEALTHY else "elevated_latency"
        self._flush_to_store()

    def record_failure(self, route: str, reason: str | None = None) -> None:
        self._rehydrate_from_store()
        health = self._require(route)
        health.recent_failures += 1
        if health.recent_failures >= self._circuit_open_after_failures and health.enabled:
            health.status = RouteStatus.CIRCUIT_OPEN
            health.opened_at = monotonic()
            health.reason = reason or "circuit_open_after_consecutive_failures"
        elif health.enabled:
            health.status = RouteStatus.DEGRADED
            health.reason = reason or "recent_failure"
        self._flush_to_store()

    def disable(self, route: str, reason: str = "operator_disabled") -> None:
        self._rehydrate_from_store()
        health = self._require(route)
        health.enabled = False
        health.status = RouteStatus.DISABLED
        health.reason = reason
        self._flush_to_store()

    def enable(self, route: str) -> None:
        self._rehydrate_from_store()
        health = self._require(route)
        health.enabled = True
        health.status = RouteStatus.HEALTHY
        health.recent_failures = 0
        health.reason = None
        health.opened_at = None
        self._flush_to_store()

    # --- queries -----------------------------------------------------------

    def snapshot(self, route: str) -> RouteHealth:
        self._rehydrate_from_store()
        self._maybe_close_circuit(self._require(route))
        return self._require(route)

    def is_eligible(self, route: str) -> bool:
        snapshot = self.snapshot(route)
        return snapshot.status not in (RouteStatus.CIRCUIT_OPEN, RouteStatus.DISABLED)

    def ineligibility_reason(self, route: str) -> str | None:
        """Return ``None`` if ``route`` is eligible, otherwise a short tag."""
        snapshot = self.snapshot(route)
        if snapshot.status is RouteStatus.DISABLED:
            return snapshot.reason or "disabled"
        if snapshot.status is RouteStatus.CIRCUIT_OPEN:
            return snapshot.reason or "circuit_open"
        return None

    def as_mapping(self) -> Mapping[str, RouteHealth]:
        self._rehydrate_from_store()
        for health in self._routes.values():
            self._maybe_close_circuit(health)
        return dict(self._routes)

    # --- helpers -----------------------------------------------------------

    def _require(self, route: str) -> RouteHealth:
        if route not in self._routes:
            raise KeyError(f"Unknown route in health registry: {route!r}")
        return self._routes[route]

    def _maybe_close_circuit(self, health: RouteHealth) -> None:
        if health.status is not RouteStatus.CIRCUIT_OPEN or health.opened_at is None:
            return
        if monotonic() - health.opened_at < self._circuit_reset_seconds:
            return
        health.status = RouteStatus.DEGRADED
        health.opened_at = None
        health.reason = "circuit_reset_window_elapsed"

    def _status_for_latency(self, latency_ms: int | None) -> RouteStatus:
        if latency_ms is None:
            return RouteStatus.HEALTHY
        if latency_ms >= self._degraded_latency_ms:
            return RouteStatus.DEGRADED
        return RouteStatus.HEALTHY

    # --- store integration -------------------------------------------------

    def _rehydrate_from_store(self) -> None:
        """Pull the latest persisted state in. Unknown routes are ignored;
        missing routes keep their current (in-memory) state.
        """
        persisted = self._store.load()
        if not persisted:
            return
        for route, entry in persisted.items():
            if route not in self._routes:
                continue
            self._routes[route] = _health_from_snapshot(entry)

    def _flush_to_store(self) -> None:
        self._store.save({route: health.snapshot() for route, health in self._routes.items()})


def _health_from_snapshot(entry: dict) -> RouteHealth:
    status = RouteStatus(entry.get("status", "healthy"))
    return RouteHealth(
        route=str(entry["route"]),
        status=status,
        recent_failures=int(entry.get("recent_failures", 0)),
        recent_latency_ms=entry.get("recent_latency_ms"),
        enabled=bool(entry.get("enabled", True)),
        reason=entry.get("reason"),
        opened_at=None,  # monotonic clocks are per-process; restart resets circuit timers.
    )
