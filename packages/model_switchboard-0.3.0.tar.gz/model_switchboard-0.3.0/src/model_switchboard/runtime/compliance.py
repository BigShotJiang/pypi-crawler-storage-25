"""Compliance rules and log redaction."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Iterable, Protocol, Sequence

from model_switchboard.runtime.request import RuntimeRequest


@dataclass(frozen=True)
class PolicyViolation:
    policy: str
    route: str
    reason: str
    detail: str | None = None


class CompliancePolicy(Protocol):
    name: str

    def check(self, request: RuntimeRequest, route: str) -> PolicyViolation | None:
        ...


# --- built-in policies -----------------------------------------------------


@dataclass(frozen=True)
class PiiStrict:
    flag: str = "pii_strict"
    banned_route: str = "small"
    name: str = "pii_strict"

    def check(self, request: RuntimeRequest, route: str) -> PolicyViolation | None:
        if self.flag not in request.compliance_flags:
            return None
        if route != self.banned_route:
            return None
        return PolicyViolation(
            policy=self.name,
            route=route,
            reason="pii_strict_forbids_small_tier",
            detail="compliance flag 'pii_strict' forbids routing to the small tier",
        )


@dataclass(frozen=True)
class NoFrontier:
    flag: str = "no_frontier"
    name: str = "no_frontier"

    def check(self, request: RuntimeRequest, route: str) -> PolicyViolation | None:
        if self.flag not in request.compliance_flags:
            return None
        if route != "frontier":
            return None
        return PolicyViolation(
            policy=self.name,
            route=route,
            reason="no_frontier_flag_active",
            detail="compliance flag 'no_frontier' forbids the frontier tier",
        )


@dataclass(frozen=True)
class Residency:
    region_by_route: dict[str, str]
    flag_prefix: str = "residency:"
    name: str = "residency"

    def check(self, request: RuntimeRequest, route: str) -> PolicyViolation | None:
        required = self._required_region(request)
        if required is None:
            return None
        actual = self.region_by_route.get(route)
        if actual == required:
            return None
        return PolicyViolation(
            policy=self.name,
            route=route,
            reason="residency_mismatch",
            detail=f"required_region={required!r} route_region={actual!r}",
        )

    def _required_region(self, request: RuntimeRequest) -> str | None:
        for flag in request.compliance_flags:
            if flag.startswith(self.flag_prefix):
                return flag[len(self.flag_prefix):]
        return None


@dataclass(frozen=True)
class RouteAllowlist:
    by_tenant: dict[str, tuple[str, ...]]
    name: str = "route_allowlist"

    def check(self, request: RuntimeRequest, route: str) -> PolicyViolation | None:
        if request.tenant_id is None:
            return None
        allowed = self.by_tenant.get(request.tenant_id)
        if allowed is None:
            return None
        if route in allowed:
            return None
        return PolicyViolation(
            policy=self.name,
            route=route,
            reason="route_not_in_tenant_allowlist",
            detail=f"tenant={request.tenant_id!r} allowed={list(allowed)}",
        )


# --- engine ----------------------------------------------------------------


@dataclass
class PolicyEngine:
    policies: Sequence[CompliancePolicy] = field(default_factory=tuple)

    def violations(self, request: RuntimeRequest, route: str) -> list[PolicyViolation]:
        """Return every violation this route triggered, in declaration order."""
        found: list[PolicyViolation] = []
        for policy in self.policies:
            violation = policy.check(request, route)
            if violation is not None:
                found.append(violation)
        return found

    def is_route_allowed(self, request: RuntimeRequest, route: str) -> bool:
        return not self.violations(request, route)


def default_policy_engine() -> PolicyEngine:
    return PolicyEngine(policies=(PiiStrict(), NoFrontier()))


# --- regex-based redactor --------------------------------------------------


@dataclass
class Redactor:
    patterns: tuple[re.Pattern[str], ...] = field(default_factory=tuple)
    placeholder: str = "[REDACTED]"

    def redact(self, text: str | None) -> str | None:
        if text is None:
            return None
        out = text
        for pattern in self.patterns:
            out = pattern.sub(self.placeholder, out)
        return out


def default_redactor() -> Redactor:
    return Redactor(
        patterns=(
            re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b"),
            re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
            re.compile(r"\b(?:\d[ -]*?){13,16}\b"),
        )
    )


def merge_policies(*engines: PolicyEngine) -> PolicyEngine:
    merged: list[CompliancePolicy] = []
    for engine in engines:
        merged.extend(engine.policies)
    return PolicyEngine(policies=tuple(merged))


def policy_names(engine: PolicyEngine) -> tuple[str, ...]:
    return tuple(p.name for p in engine.policies)


def _require_known_routes(routes: Iterable[str], allowed: Iterable[str]) -> None:
    unknown = [r for r in routes if r not in set(allowed)]
    if unknown:
        raise ValueError(f"Unknown routes referenced in compliance policy: {unknown}")
