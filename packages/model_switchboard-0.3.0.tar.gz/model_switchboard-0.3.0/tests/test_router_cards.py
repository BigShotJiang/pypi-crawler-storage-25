from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from model_switchboard.reporting.cards import build_card, write_router_cards


def _write_router_csv(dir_path: Path, router: str, rows: list[dict]) -> None:
    dir_path.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(dir_path / f"{router}_router.csv", index=False)


def _sample_rows() -> list[dict]:
    rows = []
    for i in range(6):
        difficulty = "easy" if i < 4 else "hard"
        rows.append(
            {
                "example_id": f"ex-{i:03d}",
                "task_family": "classification",
                "difficulty": difficulty,
                "chosen_route": "small" if difficulty == "easy" else "frontier",
                "route_reason": "test",
                "cost_usd": 0.02 if difficulty == "easy" else 0.60,
                "latency_ms": 500,
                "quality_score": 1.0 if difficulty == "easy" else 0.0,
                "success": 1 if difficulty == "easy" else 0,
            }
        )
    return rows


def test_build_card_captures_core_fields():
    df = pd.DataFrame(_sample_rows())
    card = build_card(
        router_name="heuristic",
        df=df,
        split="test",
        source_file="heuristic_router_test.csv",
    )
    d = card.to_dict()
    assert d["router_name"] == "heuristic"
    assert d["split"] == "test"
    assert d["n"] == 6
    for field in (
        "mean_success", "mean_quality_score", "mean_cost_usd",
        "mean_latency_ms", "route_mix_small", "route_mix_mid",
        "route_mix_frontier", "generated_at", "source_file", "weak_cells",
    ):
        assert field in d


def test_write_router_cards_emits_one_per_router(tmp_path):
    rows = _sample_rows()
    _write_router_csv(tmp_path, "heuristic", rows)
    _write_router_csv(tmp_path, "learned", rows)

    written = write_router_cards(tmp_path, split="all")
    assert len(written) == 2
    names = {p.name for p in written}
    assert "heuristic_router_card.json" in names
    assert "learned_router_card.json" in names

    payload = json.loads((tmp_path / "heuristic_router_card.json").read_text(encoding="utf-8"))
    assert payload["router_name"] == "heuristic"
    assert payload["weak_cells"]  # hard cells are weaker than easy ones
    weakest = payload["weak_cells"][0]
    assert weakest["task_family"] == "classification"
    assert weakest["difficulty"] == "hard"
    assert weakest["success_rate"] == 0.0


def test_escalation_count_appears_only_when_present(tmp_path):
    rows = _sample_rows()
    _write_router_csv(tmp_path, "heuristic", rows)

    # Add an escalated CSV with the escalation_count column
    esc_rows = [
        {
            **r,
            "initial_route": "small",
            "final_route": "small",
            "attempted_routes": "small",
            "escalation_count": 0,
            "escalated": False,
            "verifier_pass_initial": True,
        }
        for r in rows
    ]
    pd.DataFrame(esc_rows).to_csv(tmp_path / "escalated_router.csv", index=False)

    write_router_cards(tmp_path, split="all")
    heur_card = json.loads((tmp_path / "heuristic_router_card.json").read_text())
    esc_card = json.loads((tmp_path / "escalated_router_card.json").read_text())

    assert "mean_escalation_count" not in heur_card
    assert "mean_escalation_count" in esc_card
