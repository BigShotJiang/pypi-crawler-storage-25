from __future__ import annotations

import pytest

from model_switchboard.eval.splits import stratified_split
from model_switchboard.schemas.benchmark import BenchmarkExample


def _mk(example_id: str, task_family: str, difficulty: str) -> BenchmarkExample:
    return BenchmarkExample(
        example_id=example_id,
        task_family=task_family,
        prompt="p",
        difficulty=difficulty,  # type: ignore[arg-type]
    )


def _balanced_grid(per_cell: int = 4) -> list[BenchmarkExample]:
    """4 families × 3 difficulties × per_cell rows."""
    out: list[BenchmarkExample] = []
    for fam in ("classification", "extraction", "summarization", "drafting"):
        for diff in ("easy", "medium", "hard"):
            for i in range(per_cell):
                out.append(_mk(f"{fam}-{diff}-{i:02d}", fam, diff))
    return out


def test_empty_input_raises():
    with pytest.raises(ValueError):
        stratified_split([])


def test_invalid_ratio_raises():
    grid = _balanced_grid(2)
    with pytest.raises(ValueError):
        stratified_split(grid, test_ratio=0.0)
    with pytest.raises(ValueError):
        stratified_split(grid, test_ratio=1.0)


def test_deterministic_for_fixed_seed():
    grid = _balanced_grid(4)
    a_train, a_test = stratified_split(grid, test_ratio=0.25, seed=42)
    b_train, b_test = stratified_split(grid, test_ratio=0.25, seed=42)
    assert a_train == b_train
    assert a_test == b_test


def test_different_seeds_produce_different_splits():
    grid = _balanced_grid(4)
    _, t1 = stratified_split(grid, test_ratio=0.25, seed=1)
    _, t2 = stratified_split(grid, test_ratio=0.25, seed=2)
    assert t1 != t2


def test_every_cell_appears_in_both_splits():
    grid = _balanced_grid(4)
    train, test = stratified_split(grid, test_ratio=0.25, seed=42)

    id_to_cell: dict[str, tuple[str, str]] = {
        ex.example_id: (ex.task_family, str(ex.difficulty)) for ex in grid
    }
    train_cells = {id_to_cell[i] for i in train}
    test_cells = {id_to_cell[i] for i in test}
    all_cells = set(id_to_cell.values())

    assert train_cells == all_cells
    assert test_cells == all_cells


def test_ratio_is_respected_per_cell():
    grid = _balanced_grid(8)  # 8 per cell; round(8*0.25)=2 → 2 test, 6 train
    train, test = stratified_split(grid, test_ratio=0.25, seed=42)

    id_to_cell: dict[str, tuple[str, str]] = {
        ex.example_id: (ex.task_family, str(ex.difficulty)) for ex in grid
    }
    test_counts: dict[tuple[str, str], int] = {}
    for tid in test:
        cell = id_to_cell[tid]
        test_counts[cell] = test_counts.get(cell, 0) + 1

    # Exactly 2 per cell, for all 12 cells.
    assert len(test_counts) == 12
    assert all(count == 2 for count in test_counts.values())


def test_singleton_cell_goes_to_train():
    examples = [
        _mk("solo", "classification", "easy"),
        _mk("a", "extraction", "easy"),
        _mk("b", "extraction", "easy"),
    ]
    train, test = stratified_split(examples, test_ratio=0.5, seed=42)
    assert "solo" in train
    assert "solo" not in test


def test_ids_partition_cleanly():
    grid = _balanced_grid(4)
    train, test = stratified_split(grid, test_ratio=0.25, seed=42)
    all_ids = {ex.example_id for ex in grid}
    assert train.isdisjoint(test)
    assert train | test == all_ids
