from __future__ import annotations

import json
from pathlib import Path

import pytest

from model_switchboard.runtime.request import RuntimeRequest
from model_switchboard.runtime.rollout import (
    ArtifactLane,
    RolloutPolicy,
    RolloutState,
    build_baseline_compare_record,
    load_rollout_state,
    save_rollout_state,
)


def _req(request_id="req-1", tenant_id=None) -> RuntimeRequest:
    return RuntimeRequest(
        request_id=request_id,
        task_family="classification",
        prompt="x",
        tenant_id=tenant_id,
    )


def test_kill_switch_sends_all_traffic_to_baseline():
    state = RolloutState()
    state.canary_percent = 100
    state.engage_kill_switch()
    policy = RolloutPolicy(state)
    lane = policy.resolve(_req())
    assert lane.lane is ArtifactLane.BASELINE
    assert lane.reason == "kill_switch_engaged"


def test_tenant_pin_overrides_canary():
    state = RolloutState()
    state.canary_percent = 0
    state.pin_tenant("tenant-a", ArtifactLane.CANDIDATE)
    policy = RolloutPolicy(state)
    lane = policy.resolve(_req(tenant_id="tenant-a"))
    assert lane.lane is ArtifactLane.CANDIDATE
    assert lane.reason == "tenant_pinned"


def test_canary_zero_sends_everyone_to_baseline():
    policy = RolloutPolicy(RolloutState(canary_percent=0))
    assert policy.resolve(_req()).lane is ArtifactLane.BASELINE


def test_canary_hundred_sends_everyone_to_candidate():
    policy = RolloutPolicy(RolloutState(canary_percent=100))
    assert policy.resolve(_req()).lane is ArtifactLane.CANDIDATE


def test_canary_partial_is_deterministic_for_same_request_id():
    policy = RolloutPolicy(RolloutState(canary_percent=50))
    first = policy.resolve(_req(request_id="req-42"))
    second = policy.resolve(_req(request_id="req-42"))
    assert first.lane is second.lane


def test_canary_partial_splits_traffic_roughly():
    policy = RolloutPolicy(RolloutState(canary_percent=50))
    candidate_hits = 0
    for i in range(200):
        lane = policy.resolve(_req(request_id=f"r-{i}"))
        if lane.lane is ArtifactLane.CANDIDATE:
            candidate_hits += 1
    # Allow a generous margin; this is a sanity check, not a tight bound.
    assert 70 < candidate_hits < 130


def test_canary_percent_bounds_check():
    state = RolloutState()
    with pytest.raises(ValueError):
        state.set_canary_percent(150)


def test_baseline_compare_record_agrees_when_routes_match():
    record = build_baseline_compare_record(
        _req(),
        candidate_route="mid",
        candidate_reason="learned_min_cost_above_threshold",
        baseline_route="mid",
    )
    assert record.agreed is True


def test_rollout_state_round_trip(tmp_path: Path):
    state = RolloutState(
        kill_switch=True,
        canary_percent=42,
        tenant_pins={"tenant-x": ArtifactLane.BASELINE},
        compare_against_baseline=True,
    )
    path = tmp_path / "rollout.json"
    save_rollout_state(state, path)
    loaded = load_rollout_state(path)
    assert loaded.kill_switch is True
    assert loaded.canary_percent == 42
    assert loaded.tenant_pins == {"tenant-x": ArtifactLane.BASELINE}
    assert loaded.compare_against_baseline is True


def test_rollout_state_loads_defaults_when_missing(tmp_path: Path):
    loaded = load_rollout_state(tmp_path / "nonexistent.json")
    assert loaded.kill_switch is False
    assert loaded.canary_percent == 0
