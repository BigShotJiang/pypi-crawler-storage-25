from __future__ import annotations

import re

from model_switchboard.runtime.compliance import (
    NoFrontier,
    PiiStrict,
    PolicyEngine,
    Redactor,
    Residency,
    RouteAllowlist,
    default_policy_engine,
    default_redactor,
)
from model_switchboard.runtime.request import RuntimeRequest


def _req(**overrides) -> RuntimeRequest:
    base = dict(
        request_id="req-1",
        task_family="classification",
        prompt="hello",
    )
    base.update(overrides)
    return RuntimeRequest(**base)


def test_pii_strict_blocks_small_only_when_flag_present():
    engine = PolicyEngine(policies=(PiiStrict(),))
    clean = _req(compliance_flags=())
    flagged = _req(compliance_flags=("pii_strict",))

    assert engine.is_route_allowed(clean, "small")
    assert not engine.is_route_allowed(flagged, "small")
    # Other routes unaffected.
    assert engine.is_route_allowed(flagged, "mid")
    assert engine.is_route_allowed(flagged, "frontier")


def test_no_frontier_blocks_only_frontier():
    engine = PolicyEngine(policies=(NoFrontier(),))
    req = _req(compliance_flags=("no_frontier",))
    assert engine.is_route_allowed(req, "mid")
    assert not engine.is_route_allowed(req, "frontier")
    violations = engine.violations(req, "frontier")
    assert violations[0].reason == "no_frontier_flag_active"


def test_residency_requires_matching_region():
    engine = PolicyEngine(
        policies=(
            Residency(region_by_route={"small": "us-east", "mid": "eu-west", "frontier": "eu-west"}),
        )
    )
    req = _req(compliance_flags=("residency:eu-west",))
    assert not engine.is_route_allowed(req, "small")
    assert engine.is_route_allowed(req, "mid")
    assert engine.is_route_allowed(req, "frontier")


def test_route_allowlist_is_per_tenant():
    engine = PolicyEngine(
        policies=(
            RouteAllowlist(by_tenant={"tenant-a": ("mid", "frontier")}),
        )
    )
    # Unknown tenant: unconstrained
    assert engine.is_route_allowed(_req(), "small")
    # Known tenant without tenant_id propagated on the request: unconstrained
    # Known tenant on request: constrained
    req = _req(tenant_id="tenant-a")
    assert not engine.is_route_allowed(req, "small")
    assert engine.is_route_allowed(req, "mid")


def test_default_engine_has_pii_and_no_frontier():
    engine = default_policy_engine()
    names = [p.name for p in engine.policies]
    assert "pii_strict" in names
    assert "no_frontier" in names


def test_redactor_replaces_emails_and_ssns():
    redactor = default_redactor()
    text = "contact alice@example.com, ssn 123-45-6789"
    cleaned = redactor.redact(text)
    assert "alice@example.com" not in cleaned
    assert "123-45-6789" not in cleaned
    assert cleaned.count("[REDACTED]") >= 2


def test_redactor_accepts_custom_patterns():
    redactor = Redactor(patterns=(re.compile(r"\bcase-\d+\b"),), placeholder="[CASE]")
    assert redactor.redact("see case-0042") == "see [CASE]"
