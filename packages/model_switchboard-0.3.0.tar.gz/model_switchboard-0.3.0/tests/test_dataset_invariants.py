"""Dataset-shape guards for data/raw/benchmark_examples.json.

Failures here mean the benchmark dataset drifted out of the Phase 6 contract
(384 rows, 32 per (family, difficulty), 288 train / 96 test, 24 train/8 test
per cell, rubric-carrying summarization and drafting). Fix the data file, not
these tests, unless a ROADMAP phase formally changes the contract.
"""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

import pytest

from model_switchboard.schemas.benchmark import BenchmarkExample


REPO_ROOT = Path(__file__).resolve().parent.parent
DATASET_PATH = REPO_ROOT / "data" / "raw" / "benchmark_examples.json"
PHASE_A_PATH = REPO_ROOT / "data" / "raw" / "benchmark_examples_phase_a.json"


@pytest.fixture(scope="module")
def dataset() -> list[BenchmarkExample]:
    raw = json.loads(DATASET_PATH.read_text(encoding="utf-8"))
    return [BenchmarkExample(**row) for row in raw]


# --- shape ------------------------------------------------------------------


def test_dataset_has_exactly_three_hundred_eighty_four_examples(dataset):
    assert len(dataset) == 384


def test_each_family_difficulty_cell_has_thirty_two(dataset):
    counts = Counter((ex.task_family, str(ex.difficulty)) for ex in dataset)
    assert len(counts) == 12  # 4 families × 3 difficulties
    assert all(v == 32 for v in counts.values()), dict(counts)


def test_example_ids_are_unique(dataset):
    ids = [ex.example_id for ex in dataset]
    assert len(ids) == len(set(ids))


# --- splits -----------------------------------------------------------------


def test_split_values_are_train_or_test(dataset):
    assert all(ex.split in {"train", "test"} for ex in dataset)


def test_split_sizes_match_contract(dataset):
    splits = Counter(ex.split for ex in dataset)
    assert splits["train"] == 288
    assert splits["test"] == 96


def test_per_cell_split_sizes_are_twenty_four_train_eight_test(dataset):
    train_counts = Counter(
        (ex.task_family, str(ex.difficulty)) for ex in dataset if ex.split == "train"
    )
    test_counts = Counter(
        (ex.task_family, str(ex.difficulty)) for ex in dataset if ex.split == "test"
    )
    assert all(v == 24 for v in train_counts.values()), dict(train_counts)
    assert all(v == 8 for v in test_counts.values()), dict(test_counts)


def test_every_cell_is_covered_in_both_splits(dataset):
    cells_train = {(ex.task_family, str(ex.difficulty)) for ex in dataset if ex.split == "train"}
    cells_test = {(ex.task_family, str(ex.difficulty)) for ex in dataset if ex.split == "test"}
    all_cells = {(ex.task_family, str(ex.difficulty)) for ex in dataset}
    assert cells_train == all_cells
    assert cells_test == all_cells


# --- Phase 2 preservation ---------------------------------------------------


PHASE_2_IDS: set[str] = {
    f"ex-{code}-{n:03d}"
    for code in ("cls", "ext", "sum", "drf")
    for n in range(4, 25)  # Phase 2 added 004..024 per family
}


def test_phase_2_ids_are_all_present(dataset):
    current_ids = {ex.example_id for ex in dataset}
    missing = PHASE_2_IDS - current_ids
    assert not missing, f"Phase 2 IDs dropped from dataset: {sorted(missing)[:10]}"


# --- rubric contract --------------------------------------------------------


def test_summarization_rows_carry_rubric_with_min_length(dataset):
    for ex in dataset:
        if ex.task_family != "summarization":
            continue
        assert "must_contain" in ex.rubric, ex.example_id
        assert ex.rubric.get("min_length"), ex.example_id


def test_drafting_rows_carry_rubric_with_min_length(dataset):
    for ex in dataset:
        if ex.task_family != "drafting":
            continue
        assert ex.rubric.get("required_elements") or ex.rubric.get("must_contain"), ex.example_id
        assert ex.rubric.get("min_length"), ex.example_id


def test_rubric_length_band_is_sane(dataset):
    for ex in dataset:
        mn = ex.rubric.get("min_length")
        mx = ex.rubric.get("max_length")
        if mn and mx:
            assert mn <= mx, ex.example_id


# --- Phase A preservation ---------------------------------------------------


def test_phase_a_snapshot_ids_are_still_present(dataset):
    phase_a = json.loads(PHASE_A_PATH.read_text(encoding="utf-8"))
    phase_a_ids = {row["example_id"] for row in phase_a}
    current_ids = {ex.example_id for ex in dataset}
    missing = phase_a_ids - current_ids
    assert not missing, f"Phase A IDs dropped from main dataset: {missing}"


def test_phase_a_snapshot_content_matches_current_rows(dataset):
    phase_a = json.loads(PHASE_A_PATH.read_text(encoding="utf-8"))
    by_id = {ex.example_id: ex for ex in dataset}
    for row in phase_a:
        live = by_id[row["example_id"]]
        # The prompt, reference_answer, rubric, task_family, difficulty must all match.
        assert live.prompt == row["prompt"], row["example_id"]
        assert live.reference_answer == row.get("reference_answer"), row["example_id"]
        assert dict(live.rubric) == dict(row.get("rubric") or {}), row["example_id"]
        assert live.task_family == row["task_family"], row["example_id"]
        assert str(live.difficulty) == row.get("difficulty", "easy"), row["example_id"]


# --- heuristic-branch coverage (per 02-CONTEXT: ensure router branches fire) ----


def test_dataset_includes_at_least_one_long_context_summarization(dataset):
    long_ctx = [
        ex for ex in dataset
        if ex.task_family == "summarization" and ex.context and len(ex.context) > 20_000
    ]
    assert long_ctx, "expected at least one >20k-char summarization context"
