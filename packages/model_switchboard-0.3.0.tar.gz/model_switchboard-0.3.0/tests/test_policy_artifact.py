from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import pytest

from model_switchboard.router.ml_router import (
    FEATURE_COLS,
    SuccessPredictor,
)
from model_switchboard.runtime.policy import (
    FEATURE_SCHEMA_FILENAME,
    MODEL_FILENAME,
    POLICY_FILENAME,
    PolicyArtifactError,
    load_policy,
    pack_policy,
)


def _fit_predictor() -> SuccessPredictor:
    df = _synthetic_training_frame()
    predictor = SuccessPredictor()
    predictor.fit(
        df,
        {"small": "success_small", "mid": "success_mid", "frontier": "success_frontier"},
    )
    return predictor


def _synthetic_training_frame(n: int = 40) -> pd.DataFrame:
    rows = []
    for i in range(n):
        easy = i % 2 == 0
        row = {col: 0 for col in FEATURE_COLS}
        row["prompt_tokens"] = 50 if easy else 300
        row["context_tokens"] = 100 if easy else 2000
        row["total_tokens"] = row["prompt_tokens"] + row["context_tokens"]
        row["instruction_count"] = 1
        row["question_count"] = 1
        row["reasoning_keyword_hits"] = 0 if easy else 2
        row["security_keyword_hits"] = 0
        row["requires_long_context"] = 0 if easy else 1
        row["risk_tier_num"] = 0
        row["difficulty_num"] = 0 if easy else 2
        row["rubric_token_count"] = 1
        row["rubric_min_length"] = 10
        row["rubric_max_length"] = 50
        row["rubric_band_width"] = 40
        row["context_to_prompt_ratio"] = 2.0 if easy else 6.0
        row["has_comparison_cue"] = 0
        row["has_summary_cue"] = 0
        row["has_extraction_cue"] = 0
        row["task_family"] = "classification"
        row["task_family_difficulty"] = f"classification:{'easy' if easy else 'hard'}"
        row["success_small"] = 1 if easy else 0
        row["success_mid"] = 1 if easy else 1 if i % 3 == 0 else 0
        row["success_frontier"] = 1
        rows.append(row)
    return pd.DataFrame(rows)


def test_pack_policy_writes_expected_files(tmp_path: Path):
    predictor = _fit_predictor()
    out = pack_policy(
        tmp_path / "policy",
        predictor=predictor,
        threshold=0.5,
        preset_name="balanced",
        notes="unit test",
    )
    for name in (POLICY_FILENAME, MODEL_FILENAME, FEATURE_SCHEMA_FILENAME):
        assert (out / name).exists(), f"missing {name}"

    policy = json.loads((out / POLICY_FILENAME).read_text(encoding="utf-8"))
    assert policy["policy_artifact_version"] == 1
    assert policy["threshold"] == 0.5
    assert policy["preset_name"] == "balanced"
    assert policy["model_family"] in ("logistic", "gbm")
    assert "generated_at" in policy
    assert policy["notes"] == "unit test"


def test_load_policy_round_trip(tmp_path: Path):
    predictor = _fit_predictor()
    out = pack_policy(tmp_path / "policy", predictor=predictor, threshold=0.5)

    loaded = load_policy(out)
    assert loaded.threshold == 0.5
    assert loaded.policy_artifact_version == 1
    assert loaded.predictor.fitted
    # Feature schema round-trip
    assert set(loaded.numeric_cols) >= set([
        "prompt_tokens", "context_tokens", "total_tokens",
    ])


def test_load_policy_fails_on_missing_file(tmp_path: Path):
    (tmp_path / "empty_policy").mkdir()
    with pytest.raises(PolicyArtifactError):
        load_policy(tmp_path / "empty_policy")


def test_load_policy_fails_on_feature_schema_mismatch(tmp_path: Path):
    predictor = _fit_predictor()
    out = pack_policy(tmp_path / "policy", predictor=predictor, threshold=0.5)

    # Tamper with the schema so a required numeric column disappears.
    schema_path = out / FEATURE_SCHEMA_FILENAME
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    schema["numeric"] = [c for c in schema["numeric"] if c != "prompt_tokens"]
    schema_path.write_text(json.dumps(schema), encoding="utf-8")

    with pytest.raises(PolicyArtifactError) as exc:
        load_policy(out)
    assert "prompt_tokens" in str(exc.value)


def test_pack_policy_refuses_unfitted(tmp_path: Path):
    with pytest.raises(PolicyArtifactError):
        pack_policy(tmp_path / "policy", predictor=SuccessPredictor(), threshold=0.5)


def test_load_policy_rejects_unknown_version(tmp_path: Path):
    predictor = _fit_predictor()
    out = pack_policy(tmp_path / "policy", predictor=predictor, threshold=0.5)
    meta = json.loads((out / POLICY_FILENAME).read_text(encoding="utf-8"))
    meta["policy_artifact_version"] = 999
    (out / POLICY_FILENAME).write_text(json.dumps(meta), encoding="utf-8")
    with pytest.raises(PolicyArtifactError):
        load_policy(out)
