from __future__ import annotations

from model_switchboard.providers.mock_provider import MockProvider


def _make(model_name: str) -> MockProvider:
    return MockProvider(
        provider_name="mock",
        model_name=model_name,
        cost_per_1k_input_tokens=0.0,
        cost_per_1k_output_tokens=0.0,
        max_context_tokens=128000,
    )


def test_mock_pass_output_contains_reference_answer_and_must_contain_tokens():
    p = _make("frontier-sim")
    resp = p.generate(
        prompt="Summarise.",
        hint={
            "example_id": "ex-sum-001",
            "difficulty": "easy",
            "reference_answer": "latency",
            "rubric": {"must_contain": ["latency", "caching"], "min_length": 80},
        },
    )
    assert "latency" in resp.output_text
    assert "caching" in resp.output_text
    assert len(resp.output_text) >= 80


def test_mock_small_fails_most_hard_examples():
    """Small should fail the majority of 20 distinct hard examples."""
    p = _make("small-sim")
    failures = 0
    for i in range(20):
        resp = p.generate(
            prompt="task",
            hint={"example_id": f"hard-{i}", "difficulty": "hard"},
        )
        if "unable to complete" in resp.output_text:
            failures += 1
    assert failures >= 12  # fail rate 0.9 → expected ~18, guard against RNG flake


def test_mock_frontier_rarely_fails_hard_examples():
    p = _make("frontier-sim")
    failures = 0
    for i in range(20):
        resp = p.generate(
            prompt="task",
            hint={"example_id": f"hard-{i}", "difficulty": "hard"},
        )
        if "unable to complete" in resp.output_text:
            failures += 1
    assert failures <= 5  # fail rate 0.1 → expected ~2


def test_mock_is_deterministic_for_same_model_and_example():
    p = _make("small-sim")
    r1 = p.generate(prompt="task", hint={"example_id": "fixed", "difficulty": "medium"})
    r2 = p.generate(prompt="task", hint={"example_id": "fixed", "difficulty": "medium"})
    # Same pass/fail branch.
    assert ("unable to complete" in r1.output_text) == ("unable to complete" in r2.output_text)


def test_mock_pass_output_includes_required_elements_tokens():
    """Phase 6 fix: drafting rubrics use required_elements, not must_contain.

    Before the fix the mock pass output never carried these tokens, which meant
    drafting rows scored 0.0 even when the tier should have passed.
    """
    p = _make("frontier-sim")
    resp = p.generate(
        prompt="Draft an internal proposal.",
        hint={
            "example_id": "ex-drf-required-elements",
            "difficulty": "easy",
            "reference_answer": "escalation",
            "rubric": {
                "required_elements": ["verifier", "escalation", "risk", "router"],
                "min_length": 120,
            },
        },
    )
    for token in ("verifier", "escalation", "risk", "router"):
        assert token in resp.output_text, token
    assert len(resp.output_text) >= 120


def test_mock_pass_output_unions_must_contain_and_required_elements_without_duplication():
    """Tokens appearing in both lists should not be duplicated in the output."""
    p = _make("frontier-sim")
    resp = p.generate(
        prompt="Mixed rubric prompt.",
        hint={
            "example_id": "ex-mixed-rubric",
            "difficulty": "easy",
            "reference_answer": "answer",
            "rubric": {
                "must_contain": ["shared", "only_summary"],
                "required_elements": ["shared", "only_drafting"],
                "min_length": 40,
            },
        },
    )
    assert resp.output_text.count("shared") == 1
    assert "only_summary" in resp.output_text
    assert "only_drafting" in resp.output_text


def test_mock_easy_always_passes_across_tiers():
    for tier in ("small-sim", "mid-sim", "frontier-sim"):
        p = _make(tier)
        for i in range(10):
            resp = p.generate(
                prompt="task",
                hint={
                    "example_id": f"easy-{i}",
                    "difficulty": "easy",
                    "reference_answer": "answer",
                    "rubric": {"must_contain": ["answer"]},
                },
            )
            assert "unable to complete" not in resp.output_text, tier
