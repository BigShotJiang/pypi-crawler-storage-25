from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pandas as pd

from model_switchboard.reporting.compare import compare_runs


REPO_ROOT = Path(__file__).resolve().parent.parent
SCRIPT_PATH = REPO_ROOT / "scripts" / "compare_runs.py"


def _write_router_csv(
    dir_path: Path,
    router: str,
    rows: list[dict],
) -> None:
    dir_path.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(dir_path / f"{router}_router.csv", index=False)


def _basic_rows(success_pattern: dict[tuple[str, str], int]) -> list[dict]:
    rows: list[dict] = []
    ex_id = 0
    for (family, difficulty), success in success_pattern.items():
        for _ in range(4):
            rows.append(
                {
                    "example_id": f"ex-{ex_id:03d}",
                    "task_family": family,
                    "difficulty": difficulty,
                    "chosen_route": "small",
                    "route_reason": "fixture",
                    "cost_usd": 0.02,
                    "latency_ms": 500,
                    "quality_score": float(success),
                    "success": success,
                }
            )
            ex_id += 1
    return rows


def test_compare_two_dirs_produces_expected_delta_columns(tmp_path):
    base_dir = tmp_path / "base"
    candidate_dir = tmp_path / "candidate"

    base_rows = _basic_rows({
        ("classification", "easy"): 1,
        ("classification", "hard"): 0,
    })
    candidate_rows = _basic_rows({
        ("classification", "easy"): 1,
        ("classification", "hard"): 1,
    })

    _write_router_csv(base_dir, "heuristic", base_rows)
    _write_router_csv(candidate_dir, "heuristic", candidate_rows)

    cmp = compare_runs(base_dir, candidate_dir, split="all")

    assert cmp.routers_compared == ["heuristic"]
    assert not cmp.aggregate_deltas.empty
    assert "mean_success_delta" in cmp.aggregate_deltas.columns
    # candidate beats base on hard cell; aggregate success should rise.
    delta_row = cmp.aggregate_deltas.iloc[0]
    assert delta_row["mean_success_delta"] > 0

    # per-cell deltas should surface the hard-cell win
    hard_row = cmp.per_cell_deltas[
        (cmp.per_cell_deltas["task_family"] == "classification")
        & (cmp.per_cell_deltas["difficulty"] == "hard")
    ].iloc[0]
    assert hard_row["heuristic_delta"] == 1.0

    # biggest wins should contain the hard cell
    assert not cmp.biggest_wins.empty
    top_win = cmp.biggest_wins.iloc[0]
    assert top_win["difficulty"] == "hard"
    assert top_win["delta"] == 1.0


def test_missing_router_in_candidate_is_reported(tmp_path):
    base_dir = tmp_path / "base"
    candidate_dir = tmp_path / "candidate"

    rows = _basic_rows({("classification", "easy"): 1})
    _write_router_csv(base_dir, "heuristic", rows)
    _write_router_csv(base_dir, "learned", rows)
    _write_router_csv(candidate_dir, "heuristic", rows)

    cmp = compare_runs(base_dir, candidate_dir, split="all")
    assert "learned" in cmp.routers_only_in_base
    assert "learned" not in cmp.routers_compared
    assert cmp.routers_compared == ["heuristic"]


def test_compare_cli_writes_csv_and_json(tmp_path):
    base_dir = tmp_path / "base"
    candidate_dir = tmp_path / "candidate"

    rows = _basic_rows({("classification", "easy"): 1})
    _write_router_csv(base_dir, "heuristic", rows)
    _write_router_csv(candidate_dir, "heuristic", rows)

    result = subprocess.run(
        [sys.executable, str(SCRIPT_PATH),
         "--base", str(base_dir),
         "--candidate", str(candidate_dir),
         "--split", "all"],
        capture_output=True, text=True, check=False,
    )
    assert result.returncode == 0, result.stderr

    csv_path = candidate_dir / "compare_runs.csv"
    json_path = candidate_dir / "compare_runs.json"
    assert csv_path.exists()
    assert json_path.exists()

    payload = json.loads(json_path.read_text(encoding="utf-8"))
    assert payload["routers_compared"] == ["heuristic"]
    assert "aggregate_deltas" in payload


def test_compare_does_not_mutate_golden_snapshots(tmp_path):
    baseline = REPO_ROOT / "data" / "results" / "baseline_v0.1"
    phase_a = REPO_ROOT / "data" / "results" / "phase_a"
    before = {p.name: p.stat().st_mtime_ns for p in list(baseline.glob("*.csv")) + list(phase_a.glob("*.csv"))}

    base_dir = tmp_path / "base"
    candidate_dir = tmp_path / "candidate"
    rows = _basic_rows({("classification", "easy"): 1})
    _write_router_csv(base_dir, "heuristic", rows)
    _write_router_csv(candidate_dir, "heuristic", rows)
    compare_runs(base_dir, candidate_dir, split="all")

    after = {p.name: p.stat().st_mtime_ns for p in list(baseline.glob("*.csv")) + list(phase_a.glob("*.csv"))}
    assert before == after


def test_compare_cli_errors_when_no_overlap(tmp_path):
    # both dirs empty -> SystemExit from compare_runs
    (tmp_path / "a").mkdir()
    (tmp_path / "b").mkdir()
    result = subprocess.run(
        [sys.executable, str(SCRIPT_PATH),
         "--base", str(tmp_path / "a"),
         "--candidate", str(tmp_path / "b"),
         "--split", "all"],
        capture_output=True, text=True, check=False,
    )
    assert result.returncode != 0
