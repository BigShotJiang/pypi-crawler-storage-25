from __future__ import annotations

from pathlib import Path

import pandas as pd
import pytest

from model_switchboard.eval.benchmark_runner import BenchmarkRunner
from model_switchboard.router.ml_router import SuccessPredictor
from model_switchboard.schemas.benchmark import BenchmarkExample


EXPECTED_ESC_COLS = {
    "example_id",
    "task_family",
    "difficulty",
    "initial_route",
    "final_route",
    "attempted_routes",
    "escalation_count",
    "escalated",
    "verifier_pass_initial",
    "predicted_success_small",
    "predicted_success_mid",
    "predicted_success_frontier",
    "cost_usd",
    "latency_ms",
    "quality_score",
    "success",
}


ROUTE_LABEL_COLS = {
    "small": "success_small",
    "mid": "success_mid",
    "frontier": "success_frontier",
}


# --- fixtures ---------------------------------------------------------------


@pytest.fixture(scope="module")
def fitted_predictor() -> SuccessPredictor:
    # Reuse the synthetic training frame from test_ml_router so labels are
    # deterministic and match the mock provider's per-difficulty failure rates.
    from tests.test_ml_router import _synthetic_frame

    df = _synthetic_frame(n_per_cell=4)
    p = SuccessPredictor()
    p.fit(df, dict(ROUTE_LABEL_COLS))
    return p


def _costs(small: float = 0.02, mid: float = 0.10, frontier: float = 0.60) -> dict[str, float]:
    return {"small": small, "mid": mid, "frontier": frontier}


def _mk(example_id: str, task_family: str, difficulty: str, **rubric_kwargs) -> BenchmarkExample:
    return BenchmarkExample(
        example_id=example_id,
        task_family=task_family,
        difficulty=difficulty,  # type: ignore[arg-type]
        prompt=f"Classify/summarize/etc: example {example_id}.",
        reference_answer="answer",
        rubric=rubric_kwargs.get("rubric", {}),
    )


# --- unfitted guard ----------------------------------------------------------


def test_run_escalated_router_refuses_unfitted_predictor(
    mock_runner: BenchmarkRunner, sample_examples
):
    empty = SuccessPredictor()
    with pytest.raises(RuntimeError):
        mock_runner.run_escalated_router(
            sample_examples, predictor=empty, cost_by_route=_costs()
        )


# --- output shape -----------------------------------------------------------


def test_escalated_output_has_expected_columns(
    mock_runner: BenchmarkRunner,
    sample_examples,
    fitted_predictor: SuccessPredictor,
):
    df = mock_runner.run_escalated_router(
        sample_examples,
        predictor=fitted_predictor,
        cost_by_route=_costs(),
    )
    assert EXPECTED_ESC_COLS.issubset(df.columns)
    assert len(df) == len(sample_examples)
    assert set(df["initial_route"]).issubset({"small", "mid", "frontier"})
    assert set(df["final_route"]).issubset({"small", "mid", "frontier"})
    # Derived fields are internally consistent.
    for _, row in df.iterrows():
        attempts = row["attempted_routes"].split("|")
        assert row["initial_route"] == attempts[0]
        assert row["final_route"] == attempts[-1]
        assert row["escalation_count"] == len(attempts) - 1
        assert row["escalated"] == (len(attempts) > 1)


# --- pass on first attempt → no escalation ----------------------------------


def test_escalation_does_not_trigger_on_pass(
    mock_runner: BenchmarkRunner, fitted_predictor: SuccessPredictor
):
    """Easy examples pass on the first attempt under the mock's FAIL_RATE table."""
    easy = [
        _mk("esc-easy-1", "classification", "easy"),
        _mk("esc-easy-2", "extraction", "easy"),
    ]
    df = mock_runner.run_escalated_router(
        easy, predictor=fitted_predictor, cost_by_route=_costs()
    )
    assert (df["escalation_count"] == 0).all()
    assert (~df["escalated"]).all()
    assert (df["verifier_pass_initial"]).all()
    assert (df["success"] == 1).all()
    # One route attempted per example.
    assert (df["attempted_routes"].str.count(r"\|") == 0).all()


# --- escalation walks the chain to pass -------------------------------------


def test_escalation_walks_chain_on_hard_classification(
    mock_runner: BenchmarkRunner, fitted_predictor: SuccessPredictor
):
    """Hard classification with a loose threshold starts at small.

    The mock fails small on hard ~90% of the time (deterministic per example
    id). The runner must escalate to mid and frontier until a pass.
    """
    hard = [_mk("esc-hard-cls-1", "classification", "hard")]
    df = mock_runner.run_escalated_router(
        hard,
        predictor=fitted_predictor,
        cost_by_route=_costs(),
        min_success_threshold=0.0,  # force initial=small by always qualifying
    )
    row = df.iloc[0]
    # Initial was small (cheapest after threshold=0.0).
    assert row["initial_route"] == "small"
    # Either escalation happened and we passed later, or the whole chain failed.
    attempts = row["attempted_routes"].split("|")
    assert attempts[0] == "small"
    if row["success"] == 1:
        assert row["escalation_count"] >= 1
        assert row["escalated"] is True or bool(row["escalated"]) is True
    # In either case, cost and latency are cumulative across attempts.
    assert row["cost_usd"] > 0
    assert row["latency_ms"] > 0


# --- cumulative cost assertion ---------------------------------------------


def test_escalation_cost_and_latency_accumulate(
    mock_runner: BenchmarkRunner, fitted_predictor: SuccessPredictor
):
    hard = [_mk(f"esc-cost-{i}", "drafting", "hard") for i in range(3)]
    df = mock_runner.run_escalated_router(
        hard,
        predictor=fitted_predictor,
        cost_by_route=_costs(),
        min_success_threshold=0.0,  # force small as initial
    )
    # On any row that escalated, cost must strictly exceed a plausible single-
    # small-attempt cost floor (the mock's small tier cost for ~1 prompt is
    # tiny but nonzero). We assert monotonicity via attempt count.
    escalated = df[df["escalated"]]
    if not escalated.empty:
        for _, row in escalated.iterrows():
            # Positive cost and matches attempt count > 1.
            assert row["escalation_count"] >= 1
            assert row["cost_usd"] > 0
            assert row["latency_ms"] > 0


# --- chain exhaustion -------------------------------------------------------


def test_chain_exhaustion_records_final_route_and_failure(
    mock_runner: BenchmarkRunner, fitted_predictor: SuccessPredictor
):
    """If the initial pick is frontier, the chain is empty: no escalation,
    and failure cannot be relabelled as success."""
    hard = [_mk(f"esc-fr-{i}", "drafting", "hard") for i in range(2)]
    df = mock_runner.run_escalated_router(
        hard,
        predictor=fitted_predictor,
        cost_by_route=_costs(),
        min_success_threshold=0.99,  # forces frontier fallback
    )
    for _, row in df.iterrows():
        assert row["initial_route"] == "frontier"
        assert row["final_route"] == "frontier"
        assert row["escalation_count"] == 0
        assert not row["escalated"]
        # We record the honest result — could pass or fail, but we never
        # promote a fail into a pass.
        assert int(row["success"]) in {0, 1}


# --- regression guard on existing runner methods ----------------------------


def test_existing_runner_methods_schema_unchanged_after_escalation(
    mock_runner: BenchmarkRunner, sample_examples
):
    all_df = mock_runner.run_all_routes(sample_examples)
    heur_df = mock_runner.run_heuristic_router(sample_examples)
    for col in ("example_id", "task_family", "difficulty", "route", "success"):
        assert col in all_df.columns
    for col in ("example_id", "chosen_route", "route_reason", "cost_usd", "success"):
        assert col in heur_df.columns


# --- snapshot guard ---------------------------------------------------------


def test_escalation_does_not_touch_golden_snapshots(
    mock_runner: BenchmarkRunner,
    sample_examples,
    fitted_predictor: SuccessPredictor,
    repo_root: Path,
):
    baseline = repo_root / "data" / "results" / "baseline_v0.1"
    phase_a = repo_root / "data" / "results" / "phase_a"
    baseline_before = {p.name: p.stat().st_mtime_ns for p in baseline.glob("*.csv")}
    phase_a_before = {p.name: p.stat().st_mtime_ns for p in phase_a.glob("*.csv")}

    mock_runner.run_escalated_router(
        sample_examples, predictor=fitted_predictor, cost_by_route=_costs()
    )

    assert {p.name: p.stat().st_mtime_ns for p in baseline.glob("*.csv")} == baseline_before
    assert {p.name: p.stat().st_mtime_ns for p in phase_a.glob("*.csv")} == phase_a_before
