from __future__ import annotations

import importlib.util
import re
import sys
from pathlib import Path

import pandas as pd
import pytest


REPO_ROOT = Path(__file__).resolve().parent.parent
SCRIPT_PATH = REPO_ROOT / "scripts" / "report_html.py"


from model_switchboard.reporting import html_report  # noqa: E402


# --- fixtures ---------------------------------------------------------------


def _build_fixture_dir(tmp_path: Path, with_learned: bool = True) -> Path:
    results_dir = tmp_path / "results"
    results_dir.mkdir()

    examples = [
        ("classification", "easy"),
        ("classification", "hard"),
        ("extraction", "easy"),
        ("extraction", "hard"),
    ]
    example_ids = [f"{family}-{diff}-{i}" for family, diff in examples for i in range(2)]

    ar_rows: list[dict] = []
    for ex_id in example_ids:
        family, diff, _ = ex_id.rsplit("-", 2)
        for route in ("small", "mid", "frontier"):
            succ = 1 if (diff == "easy" or route == "frontier") else 0
            ar_rows.append(
                {
                    "example_id": ex_id,
                    "task_family": family,
                    "difficulty": diff,
                    "route": route,
                    "prompt": f"example prompt for {ex_id}",
                    "context": "",
                    "prompt_tokens": 50, "context_tokens": 0, "total_tokens": 50,
                    "instruction_count": 1, "question_count": 0,
                    "has_structured_output_request": 0,
                    "reasoning_keyword_hits": 0, "security_keyword_hits": 0,
                    "requires_long_context": 0, "risk_tier_num": 0,
                    "output_text": "x", "tokens_in": 100, "tokens_out": 30,
                    "latency_ms": 500,
                    "cost_usd": {"small": 0.02, "mid": 0.10, "frontier": 0.60}[route],
                    "quality_score": succ, "success": succ,
                }
            )
    pd.DataFrame(ar_rows).to_csv(results_dir / "all_routes.csv", index=False)

    heur = [
        {
            "example_id": ex_id,
            "task_family": ex_id.rsplit("-", 2)[0],
            "difficulty": ex_id.rsplit("-", 2)[1],
            "chosen_route": "small",
            "route_reason": "test",
            "cost_usd": 0.02,
            "latency_ms": 400,
            "quality_score": 1 if ex_id.rsplit("-", 2)[1] == "easy" else 0,
            "success": 1 if ex_id.rsplit("-", 2)[1] == "easy" else 0,
        }
        for ex_id in example_ids
    ]
    pd.DataFrame(heur).to_csv(results_dir / "heuristic_router.csv", index=False)

    if with_learned:
        learned = []
        for ex_id in example_ids:
            diff = ex_id.rsplit("-", 2)[1]
            chosen = "frontier" if diff == "hard" else "small"
            learned.append(
                {
                    "example_id": ex_id,
                    "task_family": ex_id.rsplit("-", 2)[0],
                    "difficulty": diff,
                    "chosen_route": chosen,
                    "route_reason": "learned",
                    "predicted_success_small": 0.8 if diff == "easy" else 0.2,
                    "predicted_success_mid": 0.9 if diff == "easy" else 0.4,
                    "predicted_success_frontier": 0.95,
                    "cost_usd": 0.02 if chosen == "small" else 0.60,
                    "latency_ms": 500,
                    "quality_score": 1,
                    "success": 1,
                }
            )
        pd.DataFrame(learned).to_csv(results_dir / "learned_router.csv", index=False)

        escalated = []
        for ex_id in example_ids:
            diff = ex_id.rsplit("-", 2)[1]
            initial = "small" if diff == "easy" else "frontier"
            escalated.append(
                {
                    "example_id": ex_id,
                    "task_family": ex_id.rsplit("-", 2)[0],
                    "difficulty": diff,
                    "initial_route": initial,
                    "final_route": initial,
                    "attempted_routes": initial,
                    "escalation_count": 0,
                    "escalated": False,
                    "verifier_pass_initial": True,
                    "predicted_success_small": 0.8 if diff == "easy" else 0.2,
                    "predicted_success_mid": 0.9 if diff == "easy" else 0.4,
                    "predicted_success_frontier": 0.95,
                    "cost_usd": 0.02 if initial == "small" else 0.60,
                    "latency_ms": 500,
                    "quality_score": 1.0,
                    "success": 1,
                }
            )
        pd.DataFrame(escalated).to_csv(results_dir / "escalated_router.csv", index=False)

    return results_dir


# --- tests ------------------------------------------------------------------


def test_write_report_creates_file(tmp_path):
    results_dir = _build_fixture_dir(tmp_path)
    out = html_report.write_report(results_dir, "all")
    assert out.exists()
    assert out.name == "report.html"


def test_write_report_split_filename(tmp_path):
    results_dir = _build_fixture_dir(tmp_path)
    # rename to test split
    for csv in list(results_dir.glob("*.csv")):
        csv.rename(csv.with_name(csv.stem + "_test.csv"))
    out = html_report.write_report(results_dir, "test")
    assert out.name == "report_test.html"


def test_report_contains_expected_sections(tmp_path):
    results_dir = _build_fixture_dir(tmp_path)
    out = html_report.write_report(results_dir, "all")
    text = out.read_text(encoding="utf-8")
    for title in (
        "ModelSwitchboard report",
        "Topline metrics",
        "Router comparison",
        "Threshold frontier",
        "Per-cell success rate",
        "Example explorer",
        "Wins &amp; losses",
        "Reproducibility",
    ):
        assert title in text, f"missing section: {title}"


def test_report_embeds_explorer_data(tmp_path):
    results_dir = _build_fixture_dir(tmp_path)
    out = html_report.write_report(results_dir, "all")
    text = out.read_text(encoding="utf-8")
    assert 'id="rb-explorer-data"' in text
    assert "example_id" in text


def test_report_handles_missing_learned_cleanly(tmp_path):
    results_dir = _build_fixture_dir(tmp_path, with_learned=False)
    out = html_report.write_report(results_dir, "all")
    text = out.read_text(encoding="utf-8")
    assert "Threshold frontier" in text
    assert "no sweep to render" in text or "not available" in text.lower() or "was not available" in text


def test_report_has_no_cdn_or_external_assets(tmp_path):
    results_dir = _build_fixture_dir(tmp_path)
    out = html_report.write_report(results_dir, "all")
    text = out.read_text(encoding="utf-8")
    # The SVG namespace URI is the one permitted occurrence; strip it before checking.
    cleaned = text.replace('xmlns="http://www.w3.org/2000/svg"', "")
    assert "http://" not in cleaned
    assert "https://" not in cleaned
    # No <script src=...> or <link rel=stylesheet href=...> to external assets.
    assert re.search(r"<script[^>]+src=", cleaned) is None
    assert re.search(r"<link[^>]+rel=['\"]stylesheet['\"]", cleaned) is None


def test_report_does_not_touch_golden_snapshots(tmp_path):
    baseline = REPO_ROOT / "data" / "results" / "baseline_v0.1"
    phase_a = REPO_ROOT / "data" / "results" / "phase_a"
    before = {p.name: p.stat().st_mtime_ns for p in list(baseline.glob("*.csv")) + list(phase_a.glob("*.csv"))}

    results_dir = _build_fixture_dir(tmp_path)
    html_report.write_report(results_dir, "all")

    after = {p.name: p.stat().st_mtime_ns for p in list(baseline.glob("*.csv")) + list(phase_a.glob("*.csv"))}
    assert before == after


def test_cli_exits_non_zero_when_results_dir_missing(tmp_path):
    import subprocess, sys as _sys
    result = subprocess.run(
        [_sys.executable, str(SCRIPT_PATH), "--results-dir", str(tmp_path / "nope"), "--split", "all"],
        capture_output=True, text=True, check=False,
    )
    assert result.returncode != 0
