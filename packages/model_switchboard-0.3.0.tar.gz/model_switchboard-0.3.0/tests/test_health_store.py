from __future__ import annotations

import json
from pathlib import Path

import pytest

from model_switchboard.runtime.health import HealthRegistry, RouteStatus
from model_switchboard.runtime.health_store import (
    FileHealthStore,
    InMemoryHealthStore,
)


ROUTES = ("small", "mid", "frontier")


def test_file_store_round_trips_snapshots(tmp_path: Path):
    store = FileHealthStore(tmp_path / "health.json")
    assert store.load() == {}
    store.save(
        {
            "small": {
                "route": "small", "status": "healthy", "recent_failures": 0,
                "recent_latency_ms": None, "enabled": True, "reason": None,
            }
        }
    )
    reloaded = store.load()
    assert reloaded["small"]["status"] == "healthy"


def test_file_store_rejects_malformed(tmp_path: Path):
    path = tmp_path / "broken.json"
    path.write_text('["not", "a", "dict"]', encoding="utf-8")
    store = FileHealthStore(path)
    with pytest.raises(ValueError):
        store.load()


def test_registry_flushes_every_transition_to_store(tmp_path: Path):
    store = FileHealthStore(tmp_path / "health.json")
    reg = HealthRegistry(ROUTES, store=store)
    reg.disable("small", reason="ops_pager")

    # A fresh registry constructed on the same store should see the disabled state.
    reg2 = HealthRegistry(ROUTES, store=store)
    assert reg2.snapshot("small").status is RouteStatus.DISABLED
    assert reg2.snapshot("small").reason == "ops_pager"


def test_registry_rehydrates_on_read_across_workers(tmp_path: Path):
    store = FileHealthStore(tmp_path / "health.json")
    worker_a = HealthRegistry(ROUTES, store=store)
    worker_b = HealthRegistry(ROUTES, store=store)

    # Worker A disables a route. Worker B hasn't called anything yet.
    worker_a.disable("frontier")
    # Worker B's next read should reflect the disabled state.
    assert worker_b.snapshot("frontier").status is RouteStatus.DISABLED


def test_in_memory_store_isolates_between_instances():
    store_a = InMemoryHealthStore()
    store_b = InMemoryHealthStore()
    reg_a = HealthRegistry(ROUTES, store=store_a)
    reg_b = HealthRegistry(ROUTES, store=store_b)

    reg_a.disable("mid")
    # b was given its own store: it must not see a's disable.
    assert reg_b.snapshot("mid").status is RouteStatus.HEALTHY


def test_atomic_write_does_not_leave_partial_snapshot(tmp_path: Path):
    path = tmp_path / "health.json"
    store = FileHealthStore(path)
    payload = {
        "small": {
            "route": "small", "status": "disabled", "recent_failures": 0,
            "recent_latency_ms": None, "enabled": False, "reason": "test",
        }
    }
    store.save(payload)
    # Directory should contain only the final json file, no .tmp leftover.
    tmp_leftovers = list(tmp_path.glob(".health-*.tmp"))
    assert tmp_leftovers == []
    # File contents parse cleanly.
    reloaded = json.loads(path.read_text(encoding="utf-8"))
    assert reloaded["small"]["status"] == "disabled"
