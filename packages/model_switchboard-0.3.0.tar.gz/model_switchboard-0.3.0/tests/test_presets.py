from __future__ import annotations

import argparse

import pytest

from model_switchboard.main import resolve_policy, DEFAULT_MIN_SUCCESS_THRESHOLD
from model_switchboard.router.presets import PRESET_NAMES, PRESETS, resolve_preset


def _args(**overrides) -> argparse.Namespace:
    base = dict(
        policy_preset=None,
        run_learned=None,
        run_escalated=None,
        min_success_threshold=None,
    )
    base.update(overrides)
    return argparse.Namespace(**base)


def test_unknown_preset_raises():
    with pytest.raises(ValueError):
        resolve_preset("no_such_preset")


def test_known_presets_cover_expected_names():
    expected = {"cost_saver", "balanced", "quality_max", "frontier_guarded"}
    assert set(PRESET_NAMES) >= expected


def test_no_preset_uses_backward_compatible_defaults():
    run_l, run_e, thr, preset = resolve_policy(_args())
    assert run_l is False
    assert run_e is False
    assert thr == DEFAULT_MIN_SUCCESS_THRESHOLD
    assert preset is None


def test_balanced_preset_applies_defaults():
    run_l, run_e, thr, preset = resolve_policy(_args(policy_preset="balanced"))
    assert preset is not None
    assert preset.name == "balanced"
    assert run_l is True
    assert run_e is True
    assert thr == PRESETS["balanced"].min_success_threshold


def test_cli_threshold_overrides_preset():
    run_l, run_e, thr, _ = resolve_policy(
        _args(policy_preset="balanced", min_success_threshold=0.72)
    )
    assert thr == 0.72
    assert run_l is True  # preset still supplies the enable flags


def test_cli_run_flags_override_preset():
    run_l, run_e, thr, _ = resolve_policy(
        _args(policy_preset="quality_max", run_learned="false", run_escalated="false")
    )
    assert run_l is False
    assert run_e is False
    # threshold still inherited
    assert thr == PRESETS["quality_max"].min_success_threshold


def test_cost_saver_disables_escalation():
    run_l, run_e, thr, _ = resolve_policy(_args(policy_preset="cost_saver"))
    assert run_l is True
    assert run_e is False
    assert thr == PRESETS["cost_saver"].min_success_threshold


def test_explicit_flags_without_preset_still_work():
    run_l, run_e, thr, preset = resolve_policy(
        _args(run_learned="true", run_escalated="true", min_success_threshold=0.4)
    )
    assert run_l is True
    assert run_e is True
    assert thr == 0.4
    assert preset is None
