"""CLI smoke tests for python -m model_switchboard.main.

Shells out to ensure argparse wiring is actually live, not just imported.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parent.parent


def _tiny_dataset(tmp_path: Path) -> Path:
    """Write a 2-row dataset covering both splits so filters always have rows."""
    data = [
        {
            "example_id": "cli-train",
            "task_family": "classification",
            "difficulty": "easy",
            "split": "train",
            "prompt": "Classify: 'I was charged twice.' — billing/tech/access.",
            "reference_answer": "billing",
            "rubric": {},
        },
        {
            "example_id": "cli-test",
            "task_family": "classification",
            "difficulty": "easy",
            "split": "test",
            "prompt": "Classify: 'Password reset link never arrived.' — billing/tech/access.",
            "reference_answer": "access",
            "rubric": {},
        },
    ]
    path = tmp_path / "tiny_examples.json"
    path.write_text(json.dumps(data), encoding="utf-8")
    return path


def _run_cli(*args: str, tmp_path: Path) -> subprocess.CompletedProcess:
    env = os.environ.copy()
    return subprocess.run(
        [sys.executable, "-m", "model_switchboard.main", *args],
        cwd=str(REPO_ROOT),
        env=env,
        capture_output=True,
        text=True,
        timeout=120,
        check=False,
    )


def _snapshot_mtimes(root: Path) -> dict[str, int]:
    return {p.name: p.stat().st_mtime_ns for p in root.glob("*.csv")}


@pytest.mark.parametrize(
    "split_flag, expected_all_routes, expected_heuristic, expected_rows",
    [
        (None, "all_routes.csv", "heuristic_router.csv", 2),
        ("all", "all_routes.csv", "heuristic_router.csv", 2),
        ("train", "all_routes_train.csv", "heuristic_router_train.csv", 1),
        ("test", "all_routes_test.csv", "heuristic_router_test.csv", 1),
    ],
)
def test_cli_split_flag_controls_filenames_and_row_counts(
    tmp_path, split_flag, expected_all_routes, expected_heuristic, expected_rows
):
    dataset = _tiny_dataset(tmp_path)
    out_dir = tmp_path / "out"

    args = [
        "--examples-path", str(dataset),
        "--models-config", str(REPO_ROOT / "configs" / "models.yaml"),
        "--output-dir", str(out_dir),
    ]
    if split_flag is not None:
        args.extend(["--split", split_flag])

    result = _run_cli(*args, tmp_path=tmp_path)
    assert result.returncode == 0, f"stderr:\n{result.stderr}\nstdout:\n{result.stdout}"

    assert (out_dir / expected_all_routes).exists(), list(out_dir.iterdir())
    assert (out_dir / expected_heuristic).exists(), list(out_dir.iterdir())

    # heuristic_router.csv has one row per example — easy to count.
    heuristic_rows = (out_dir / expected_heuristic).read_text(encoding="utf-8").strip().splitlines()
    # 1 header + expected data rows.
    assert len(heuristic_rows) - 1 == expected_rows


def test_cli_help_advertises_split_flag(tmp_path):
    result = _run_cli("--help", tmp_path=tmp_path)
    assert result.returncode == 0
    assert "--split" in result.stdout
    for choice in ("train", "test", "all"):
        assert choice in result.stdout


def test_cli_does_not_touch_golden_snapshots(tmp_path):
    """Running the CLI against tmp_path must not mutate baseline_v0.1 or phase_a."""
    baseline = REPO_ROOT / "data" / "results" / "baseline_v0.1"
    phase_a = REPO_ROOT / "data" / "results" / "phase_a"
    baseline_before = _snapshot_mtimes(baseline)
    phase_a_before = _snapshot_mtimes(phase_a)

    dataset = _tiny_dataset(tmp_path)
    out_dir = tmp_path / "guarded_out"
    result = _run_cli(
        "--examples-path", str(dataset),
        "--models-config", str(REPO_ROOT / "configs" / "models.yaml"),
        "--output-dir", str(out_dir),
        "--split", "test",
        tmp_path=tmp_path,
    )
    assert result.returncode == 0, result.stderr

    assert _snapshot_mtimes(baseline) == baseline_before
    assert _snapshot_mtimes(phase_a) == phase_a_before


def test_cli_run_learned_writes_learned_router_csv(tmp_path):
    """--run-learned true produces learned_router_{split}.csv in addition to the existing outputs."""
    # Build a tiny pivot and train a model inside tmp_path — no shared state.
    import pandas as pd  # local import; keeps non-live deps out of module import

    from model_switchboard.router.ml_router import SuccessPredictor

    rows = []
    for i in range(8):
        rows.append(
            {
                "example_id": f"t-{i}",
                "task_family": "classification",
                "difficulty": "easy",
                "prompt_tokens": 50 + i,
                "context_tokens": 0,
                "total_tokens": 50 + i,
                "instruction_count": 1,
                "question_count": 0,
                "has_structured_output_request": 0,
                "reasoning_keyword_hits": 0,
                "security_keyword_hits": 0,
                "requires_long_context": 0,
                "risk_tier_num": 0,
                # Phase 7 columns
                "difficulty_num": 0,
                "rubric_token_count": 0,
                "rubric_min_length": 0,
                "rubric_max_length": 0,
                "rubric_band_width": 0,
                "context_to_prompt_ratio": 0.0,
                "has_comparison_cue": 0,
                "has_summary_cue": 0,
                "has_extraction_cue": 0,
                "task_family_difficulty": "classification:easy",
                "success_small": i % 2,
                "success_mid": 1,  # exercises the single-class fallback through save/load
                "success_frontier": 1,
            }
        )
    pivot_df = pd.DataFrame(rows)
    predictor = SuccessPredictor()
    predictor.fit(
        pivot_df,
        {"small": "success_small", "mid": "success_mid", "frontier": "success_frontier"},
    )
    model_path = tmp_path / "model.joblib"
    predictor.save(model_path)

    dataset = _tiny_dataset(tmp_path)
    out_dir = tmp_path / "learned_out"

    result = _run_cli(
        "--examples-path", str(dataset),
        "--models-config", str(REPO_ROOT / "configs" / "models.yaml"),
        "--output-dir", str(out_dir),
        "--split", "test",
        "--run-learned", "true",
        "--model-path", str(model_path),
        tmp_path=tmp_path,
    )
    assert result.returncode == 0, f"stderr:\n{result.stderr}\nstdout:\n{result.stdout}"
    assert (out_dir / "learned_router_test.csv").exists(), list(out_dir.iterdir())
    assert (out_dir / "heuristic_router_test.csv").exists()
    assert (out_dir / "all_routes_test.csv").exists()


def test_cli_run_learned_default_false_does_not_emit_learned_csv(tmp_path):
    dataset = _tiny_dataset(tmp_path)
    out_dir = tmp_path / "no_learned"

    result = _run_cli(
        "--examples-path", str(dataset),
        "--models-config", str(REPO_ROOT / "configs" / "models.yaml"),
        "--output-dir", str(out_dir),
        "--split", "test",
        tmp_path=tmp_path,
    )
    assert result.returncode == 0
    produced = {p.name for p in out_dir.iterdir()}
    assert "learned_router_test.csv" not in produced
    assert {"all_routes_test.csv", "heuristic_router_test.csv"} <= produced


def test_cli_help_advertises_run_learned_flag(tmp_path):
    result = _run_cli("--help", tmp_path=tmp_path)
    assert result.returncode == 0
    assert "--run-learned" in result.stdout
    assert "--model-path" in result.stdout


def test_cli_help_advertises_run_escalated_flag(tmp_path):
    result = _run_cli("--help", tmp_path=tmp_path)
    assert result.returncode == 0
    assert "--run-escalated" in result.stdout


def test_cli_run_escalated_writes_escalated_router_csv(tmp_path):
    import pandas as pd

    from model_switchboard.router.ml_router import SuccessPredictor

    rows = []
    for i in range(8):
        rows.append(
            {
                "example_id": f"t-{i}",
                "task_family": "classification",
                "difficulty": "easy",
                "prompt_tokens": 50 + i,
                "context_tokens": 0,
                "total_tokens": 50 + i,
                "instruction_count": 1,
                "question_count": 0,
                "has_structured_output_request": 0,
                "reasoning_keyword_hits": 0,
                "security_keyword_hits": 0,
                "requires_long_context": 0,
                "risk_tier_num": 0,
                # Phase 7 columns
                "difficulty_num": 0,
                "rubric_token_count": 0,
                "rubric_min_length": 0,
                "rubric_max_length": 0,
                "rubric_band_width": 0,
                "context_to_prompt_ratio": 0.0,
                "has_comparison_cue": 0,
                "has_summary_cue": 0,
                "has_extraction_cue": 0,
                "task_family_difficulty": "classification:easy",
                "success_small": i % 2,
                "success_mid": 1,
                "success_frontier": 1,
            }
        )
    predictor = SuccessPredictor()
    predictor.fit(
        pd.DataFrame(rows),
        {"small": "success_small", "mid": "success_mid", "frontier": "success_frontier"},
    )
    model_path = tmp_path / "model.joblib"
    predictor.save(model_path)

    dataset = _tiny_dataset(tmp_path)
    out_dir = tmp_path / "escalated_out"

    result = _run_cli(
        "--examples-path", str(dataset),
        "--models-config", str(REPO_ROOT / "configs" / "models.yaml"),
        "--output-dir", str(out_dir),
        "--split", "test",
        "--run-escalated", "true",
        "--model-path", str(model_path),
        tmp_path=tmp_path,
    )
    assert result.returncode == 0, f"stderr:\n{result.stderr}\nstdout:\n{result.stdout}"
    esc_path = out_dir / "escalated_router_test.csv"
    assert esc_path.exists(), list(out_dir.iterdir())

    # Spot-check schema.
    with esc_path.open(encoding="utf-8") as f:
        header = f.readline().strip().split(",")
    for col in (
        "initial_route",
        "final_route",
        "attempted_routes",
        "escalation_count",
        "escalated",
        "verifier_pass_initial",
    ):
        assert col in header, (col, header)


def test_cli_run_escalated_default_false_does_not_emit_escalated_csv(tmp_path):
    dataset = _tiny_dataset(tmp_path)
    out_dir = tmp_path / "no_escalated"

    result = _run_cli(
        "--examples-path", str(dataset),
        "--models-config", str(REPO_ROOT / "configs" / "models.yaml"),
        "--output-dir", str(out_dir),
        "--split", "test",
        tmp_path=tmp_path,
    )
    assert result.returncode == 0
    produced = {p.name for p in out_dir.iterdir()}
    assert "escalated_router_test.csv" not in produced


def test_cli_run_escalated_fails_without_model(tmp_path):
    dataset = _tiny_dataset(tmp_path)
    out_dir = tmp_path / "missing_model"

    result = _run_cli(
        "--examples-path", str(dataset),
        "--models-config", str(REPO_ROOT / "configs" / "models.yaml"),
        "--output-dir", str(out_dir),
        "--split", "test",
        "--run-escalated", "true",
        "--model-path", str(tmp_path / "does_not_exist.joblib"),
        tmp_path=tmp_path,
    )
    assert result.returncode != 0


def test_cli_errors_cleanly_when_split_is_empty(tmp_path):
    """If the filter yields zero rows, exit non-zero with a helpful message."""
    data = [
        {
            "example_id": "only-train",
            "task_family": "classification",
            "difficulty": "easy",
            "split": "train",
            "prompt": "Classify: billing/tech/access — 'I need a refund.'",
            "reference_answer": "billing",
            "rubric": {},
        }
    ]
    path = tmp_path / "only_train.json"
    path.write_text(json.dumps(data), encoding="utf-8")

    result = _run_cli(
        "--examples-path", str(path),
        "--models-config", str(REPO_ROOT / "configs" / "models.yaml"),
        "--output-dir", str(tmp_path / "out"),
        "--split", "test",
        tmp_path=tmp_path,
    )
    assert result.returncode != 0
    combined = result.stdout + result.stderr
    assert "split" in combined.lower() or "no examples" in combined.lower()
