from __future__ import annotations

from pathlib import Path

import pytest

from model_switchboard.runtime import (
    HealthRegistry,
    RuntimeRequest,
    RuntimeRouter,
    load_policy,
    pack_policy,
)

from tests.test_policy_artifact import _fit_predictor


@pytest.fixture(scope="module")
def artifact_path(tmp_path_factory) -> Path:
    predictor = _fit_predictor()
    out = tmp_path_factory.mktemp("policy")
    return pack_policy(
        out / "artifact",
        predictor=predictor,
        threshold=0.5,
        preset_name="balanced",
    )


@pytest.fixture
def router(artifact_path: Path) -> RuntimeRouter:
    return RuntimeRouter(load_policy(artifact_path))


def _baseline_request(**overrides) -> RuntimeRequest:
    base = dict(
        request_id="req-0001",
        task_family="classification",
        prompt="Classify this ticket: the dashboard is not loading.",
        context="",
        allow_escalation=True,
    )
    base.update(overrides)
    return RuntimeRequest(**base)


def test_decision_captures_request_and_policy_provenance(router: RuntimeRouter):
    decision = router.decide(_baseline_request())
    assert decision.request_id == "req-0001"
    assert decision.policy_artifact_version == 1
    assert decision.threshold == 0.5
    assert decision.policy_preset == "balanced"
    assert decision.model_family in ("logistic", "gbm")
    assert decision.final_route in ("small", "mid", "frontier")


def test_feature_summary_does_not_leak_prompt(router: RuntimeRouter):
    decision = router.decide(_baseline_request(prompt="SENSITIVE internal payload"))
    assert "SENSITIVE" not in str(decision.feature_summary.values())
    # And the summary is compact / structured, not free text.
    assert "prompt_tokens" in decision.feature_summary


def test_cost_ceiling_excludes_expensive_routes(router: RuntimeRouter):
    # With a tight ceiling only the small tier qualifies.
    decision = router.decide(_baseline_request(cost_ceiling_usd=0.05))
    excluded = {ex.route for ex in decision.excluded_routes if ex.reason == "cost_ceiling"}
    assert {"mid", "frontier"}.issubset(excluded)


def test_pii_strict_flag_excludes_small_route(router: RuntimeRouter):
    decision = router.decide(
        _baseline_request(compliance_flags=("pii_strict",))
    )
    small_excluded = any(
        ex.route == "small" and ex.reason == "compliance"
        for ex in decision.excluded_routes
    )
    assert small_excluded
    assert decision.final_route != "small"


def test_no_frontier_flag_excludes_frontier(router: RuntimeRouter):
    decision = router.decide(_baseline_request(compliance_flags=("no_frontier",)))
    excluded = {(ex.route, ex.reason) for ex in decision.excluded_routes}
    assert ("frontier", "compliance") in excluded


def test_disabled_route_is_excluded_via_health(artifact_path: Path):
    artifact = load_policy(artifact_path)
    health = HealthRegistry(("small", "mid", "frontier"))
    health.disable("small", reason="operator_disabled_for_test")
    router = RuntimeRouter(artifact, health=health)

    decision = router.decide(_baseline_request())
    assert decision.final_route != "small"
    health_exclusions = {
        ex.route for ex in decision.excluded_routes if ex.reason == "health"
    }
    assert "small" in health_exclusions


def test_allow_escalation_false_produces_empty_escalation_path(router: RuntimeRouter):
    decision = router.decide(_baseline_request(allow_escalation=False))
    assert decision.escalation_path == ()
    assert decision.escalated is False


def test_every_route_ineligible_returns_fallback(artifact_path: Path):
    artifact = load_policy(artifact_path)
    health = HealthRegistry(("small", "mid", "frontier"))
    for route in ("small", "mid", "frontier"):
        health.disable(route)
    router = RuntimeRouter(artifact, health=health)

    decision = router.decide(_baseline_request())
    assert decision.route_reason == "no_route_met_threshold"
    # Fallback route is still reported even though every route is ineligible.
    assert decision.final_route == "frontier"
