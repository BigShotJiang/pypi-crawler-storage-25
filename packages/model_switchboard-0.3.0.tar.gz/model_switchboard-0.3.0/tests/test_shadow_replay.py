from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

from model_switchboard.runtime.policy import pack_policy

from tests.test_policy_artifact import _fit_predictor


REPO_ROOT = Path(__file__).resolve().parent.parent
SCRIPT_PATH = REPO_ROOT / "scripts" / "replay_shadow.py"
EXAMPLES_PATH = REPO_ROOT / "data" / "raw" / "benchmark_examples_phase_a.json"


def test_shadow_replay_cli_produces_decisions_and_summary(tmp_path: Path):
    artifact_dir = tmp_path / "policy"
    pack_policy(artifact_dir, predictor=_fit_predictor(), threshold=0.5, preset_name="balanced")

    output = tmp_path / "shadow_out"
    result = subprocess.run(
        [
            sys.executable, str(SCRIPT_PATH),
            "--examples-path", str(EXAMPLES_PATH),
            "--policy-path", str(artifact_dir),
            "--output", str(output),
            "--split", "all",
        ],
        capture_output=True, text=True, check=False,
    )
    assert result.returncode == 0, result.stderr

    decisions = output / "decisions.ndjson"
    summary = output / "shadow_summary.json"
    assert decisions.exists()
    assert summary.exists()

    lines = decisions.read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) > 0
    first = json.loads(lines[0])
    assert first["policy_artifact_version"] == 1
    assert first["final_route"] in ("small", "mid", "frontier")

    summary_payload = json.loads(summary.read_text(encoding="utf-8"))
    assert summary_payload["n_examples"] == len(lines)
    assert "initial_route_mix" in summary_payload
    assert 0.0 <= summary_payload["escalation_planned_rate"] <= 1.0
    assert 0.0 <= summary_payload["heuristic_agreement_rate"] <= 1.0
