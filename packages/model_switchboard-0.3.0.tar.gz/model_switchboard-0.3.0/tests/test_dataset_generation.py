"""Regeneration-determinism and shape guards for the dataset generator.

The generator in ``scripts/_expand_dataset.py`` must be idempotent: calling it
twice from a clean state must produce byte-identical ``build_new_rows()`` and
``build_phase_6_rows()`` outputs. This test imports those builders as library
functions so we can assert determinism without reparsing the emitted JSON.
"""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parent.parent
SCRIPT_PATH = REPO_ROOT / "scripts" / "_expand_dataset.py"


def _load_generator_module():
    spec = importlib.util.spec_from_file_location("expand_dataset", SCRIPT_PATH)
    assert spec and spec.loader
    mod = importlib.util.module_from_spec(spec)
    sys.modules["expand_dataset"] = mod
    spec.loader.exec_module(mod)
    return mod


# --- phase 2 builder --------------------------------------------------------


def test_build_new_rows_returns_eighty_four_rows():
    mod = _load_generator_module()
    rows = mod.build_new_rows()
    assert len(rows) == 84


def test_build_new_rows_is_deterministic():
    mod = _load_generator_module()
    a = json.dumps(mod.build_new_rows(), sort_keys=True)
    b = json.dumps(mod.build_new_rows(), sort_keys=True)
    assert a == b


# --- phase 6 builder --------------------------------------------------------


def test_build_phase_6_rows_returns_two_hundred_eighty_eight_rows():
    mod = _load_generator_module()
    rows = mod.build_phase_6_rows()
    assert len(rows) == 288


def test_build_phase_6_rows_is_deterministic():
    mod = _load_generator_module()
    a = json.dumps(mod.build_phase_6_rows(), sort_keys=True)
    b = json.dumps(mod.build_phase_6_rows(), sort_keys=True)
    assert a == b


def test_phase_6_summarization_and_drafting_have_rubrics():
    mod = _load_generator_module()
    rows = mod.build_phase_6_rows()
    for row in rows:
        if row["task_family"] == "summarization":
            assert row["rubric"].get("must_contain"), row["example_id"]
            assert row["rubric"].get("min_length", 0) >= 60, row["example_id"]
        elif row["task_family"] == "drafting":
            assert row["rubric"].get("required_elements"), row["example_id"]
            assert row["rubric"].get("min_length", 0) >= 120, row["example_id"]


def test_phase_6_ids_are_in_expected_range():
    mod = _load_generator_module()
    rows = mod.build_phase_6_rows()
    ids = [row["example_id"] for row in rows]
    for ex_id in ids:
        parts = ex_id.split("-")
        assert parts[0] == "ex"
        assert parts[1] in {"cls", "ext", "sum", "drf"}
        n = int(parts[2])
        assert 25 <= n <= 96, ex_id


def test_phase_6_each_cell_has_twenty_four_rows():
    from collections import Counter

    mod = _load_generator_module()
    rows = mod.build_phase_6_rows()
    cells = Counter((r["task_family"], r["difficulty"]) for r in rows)
    assert len(cells) == 12
    assert all(v == 24 for v in cells.values()), dict(cells)
