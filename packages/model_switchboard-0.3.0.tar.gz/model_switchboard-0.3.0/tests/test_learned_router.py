from __future__ import annotations

from pathlib import Path

import pandas as pd
import pytest

from model_switchboard.eval.benchmark_runner import BenchmarkRunner
from model_switchboard.router.ml_router import SuccessPredictor
from model_switchboard.router.policy import choose_learned_route


ROUTE_LABEL_COLS = {
    "small": "success_small",
    "mid": "success_mid",
    "frontier": "success_frontier",
}

# --- choose_learned_route unit surface ---------------------------------------


def _costs(small: float = 0.02, mid: float = 0.10, frontier: float = 0.60) -> dict[str, float]:
    return {"small": small, "mid": mid, "frontier": frontier}


def test_choose_learned_route_picks_cheapest_above_threshold():
    route, reason = choose_learned_route(
        predicted_success={"small": 0.9, "mid": 0.95, "frontier": 0.99},
        cost_by_route=_costs(),
        min_success_threshold=0.5,
    )
    assert route == "small"
    assert reason["reason"] == "learned_min_cost_above_threshold"


def test_choose_learned_route_falls_back_to_frontier_when_no_qualifier():
    route, reason = choose_learned_route(
        predicted_success={"small": 0.1, "mid": 0.2, "frontier": 0.3},
        cost_by_route=_costs(),
        min_success_threshold=0.5,
    )
    assert route == "frontier"
    assert reason["reason"] == "no_route_meets_threshold"


def test_choose_learned_route_skips_mid_when_below_threshold():
    route, _ = choose_learned_route(
        predicted_success={"small": 0.4, "mid": 0.45, "frontier": 0.9},
        cost_by_route=_costs(),
        min_success_threshold=0.5,
    )
    assert route == "frontier"


def test_choose_learned_route_rejects_missing_routes():
    with pytest.raises(ValueError):
        choose_learned_route(
            predicted_success={"small": 0.9, "mid": 0.9},  # missing frontier
            cost_by_route=_costs(),
        )
    with pytest.raises(ValueError):
        choose_learned_route(
            predicted_success={"small": 0.9, "mid": 0.9, "frontier": 0.9},
            cost_by_route={"small": 0.1, "mid": 0.2},  # missing frontier
        )


# --- runner integration ------------------------------------------------------


@pytest.fixture(scope="module")
def fitted_predictor() -> SuccessPredictor:
    """A predictor fitted on the synthetic-quality pattern used elsewhere in tests."""
    from tests.test_ml_router import _synthetic_frame  # reuse

    df = _synthetic_frame(n_per_cell=4)
    p = SuccessPredictor()
    p.fit(df, dict(ROUTE_LABEL_COLS))
    return p


def test_run_learned_router_emits_expected_columns(
    mock_runner: BenchmarkRunner,
    sample_examples,
    fitted_predictor: SuccessPredictor,
):
    df = mock_runner.run_learned_router(
        sample_examples,
        predictor=fitted_predictor,
        cost_by_route=_costs(),
        min_success_threshold=0.5,
    )
    expected = {
        "example_id",
        "task_family",
        "difficulty",
        "chosen_route",
        "route_reason",
        "predicted_success_small",
        "predicted_success_mid",
        "predicted_success_frontier",
        "cost_usd",
        "latency_ms",
        "quality_score",
        "success",
    }
    assert expected.issubset(df.columns)
    assert len(df) == len(sample_examples)
    assert set(df["chosen_route"]).issubset({"small", "mid", "frontier"})


def test_run_learned_router_probabilities_are_bounded(
    mock_runner: BenchmarkRunner,
    sample_examples,
    fitted_predictor: SuccessPredictor,
):
    df = mock_runner.run_learned_router(
        sample_examples,
        predictor=fitted_predictor,
        cost_by_route=_costs(),
        min_success_threshold=0.5,
    )
    for col in ("predicted_success_small", "predicted_success_mid", "predicted_success_frontier"):
        assert df[col].between(0.0, 1.0).all(), col


def test_run_learned_router_refuses_unfitted_predictor(
    mock_runner: BenchmarkRunner, sample_examples
):
    empty = SuccessPredictor()
    with pytest.raises(RuntimeError):
        mock_runner.run_learned_router(
            sample_examples, predictor=empty, cost_by_route=_costs()
        )


def test_run_learned_router_does_not_touch_golden_snapshots(
    mock_runner: BenchmarkRunner,
    sample_examples,
    fitted_predictor: SuccessPredictor,
    repo_root: Path,
):
    baseline = repo_root / "data" / "results" / "baseline_v0.1"
    phase_a = repo_root / "data" / "results" / "phase_a"
    baseline_before = {p.name: p.stat().st_mtime_ns for p in baseline.glob("*.csv")}
    phase_a_before = {p.name: p.stat().st_mtime_ns for p in phase_a.glob("*.csv")}

    mock_runner.run_learned_router(
        sample_examples, predictor=fitted_predictor, cost_by_route=_costs()
    )

    assert {p.name: p.stat().st_mtime_ns for p in baseline.glob("*.csv")} == baseline_before
    assert {p.name: p.stat().st_mtime_ns for p in phase_a.glob("*.csv")} == phase_a_before


def test_existing_runner_methods_schema_unchanged(
    mock_runner: BenchmarkRunner, sample_examples
):
    """Regression guard: Phase 4 must not have drifted run_all_routes / run_heuristic shape."""
    all_df = mock_runner.run_all_routes(sample_examples)
    heur_df = mock_runner.run_heuristic_router(sample_examples)

    # Spot-check a handful of columns that older tests rely on.
    for col in ("example_id", "task_family", "difficulty", "route", "success", "quality_score"):
        assert col in all_df.columns
    for col in ("example_id", "chosen_route", "route_reason", "cost_usd", "success"):
        assert col in heur_df.columns
