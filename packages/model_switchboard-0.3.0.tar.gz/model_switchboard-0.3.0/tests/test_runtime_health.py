from __future__ import annotations

import pytest

from model_switchboard.runtime.health import HealthRegistry, RouteStatus


ROUTES = ("small", "mid", "frontier")


def test_defaults_are_healthy_and_eligible():
    reg = HealthRegistry(ROUTES)
    for route in ROUTES:
        assert reg.is_eligible(route)
        assert reg.ineligibility_reason(route) is None
        assert reg.snapshot(route).status is RouteStatus.HEALTHY


def test_consecutive_failures_open_the_circuit():
    reg = HealthRegistry(ROUTES, circuit_open_after_failures=2)
    reg.record_failure("mid")
    # One failure is not enough to open
    assert reg.is_eligible("mid")
    reg.record_failure("mid")
    assert not reg.is_eligible("mid")
    assert reg.snapshot("mid").status is RouteStatus.CIRCUIT_OPEN
    assert reg.ineligibility_reason("mid") is not None


def test_success_resets_failure_count_and_closes_circuit():
    reg = HealthRegistry(ROUTES, circuit_open_after_failures=2)
    reg.record_failure("small")
    reg.record_failure("small")
    assert reg.snapshot("small").status is RouteStatus.CIRCUIT_OPEN
    reg.record_success("small", latency_ms=100)
    assert reg.snapshot("small").status is RouteStatus.HEALTHY
    assert reg.snapshot("small").recent_failures == 0


def test_degraded_status_flows_from_elevated_latency():
    reg = HealthRegistry(ROUTES, degraded_latency_ms=1000)
    reg.record_success("frontier", latency_ms=1500)
    assert reg.snapshot("frontier").status is RouteStatus.DEGRADED
    # Degraded is still eligible.
    assert reg.is_eligible("frontier")


def test_disable_overrides_everything():
    reg = HealthRegistry(ROUTES)
    reg.disable("small", reason="operator_test")
    assert not reg.is_eligible("small")
    assert reg.snapshot("small").status is RouteStatus.DISABLED
    assert reg.ineligibility_reason("small") == "operator_test"


def test_enable_restores_eligibility():
    reg = HealthRegistry(ROUTES)
    reg.disable("small")
    reg.enable("small")
    assert reg.is_eligible("small")
    assert reg.snapshot("small").status is RouteStatus.HEALTHY


def test_unknown_route_raises():
    reg = HealthRegistry(ROUTES)
    with pytest.raises(KeyError):
        reg.record_failure("nonexistent")
