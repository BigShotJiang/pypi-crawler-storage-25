"""Opt-in live-provider smoke tests.

These tests are marked `live` and are excluded from the default pytest run
(see `addopts` in pyproject.toml). They also skip cleanly when required
credentials or local services are not present, so opting in never turns into
a spurious failure on an unconfigured machine.

Opt-in:   python -m pytest -m live -q
Default:  python -m pytest -q   (these tests do not run)

Env vars:
    MODEL_SWITCHBOARD_OLLAMA_HOST / _OLLAMA_MODEL / _GEMINI_MODEL
                                  / _GROK_MODEL   / _OPENAI_MODEL
The ``ROUTERBENCH_*`` spellings are accepted as a backward-compatible
fallback for users who wired the repo into their shell before the rename.
"""

from __future__ import annotations

import os
import socket
from contextlib import closing
from urllib.parse import urlparse

import pytest


def _env(name: str, default: str | None = None) -> str | None:
    """Read a switchboard env var with a backward-compat RouterBench fallback."""
    value = os.environ.get(f"MODEL_SWITCHBOARD_{name}")
    if value is not None:
        return value
    return os.environ.get(f"ROUTERBENCH_{name}", default)


def _tcp_reachable(url: str, timeout: float = 0.5) -> bool:
    """Return True if we can open a TCP connection to the host:port of url."""
    parsed = urlparse(url)
    host = parsed.hostname or "127.0.0.1"
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    try:
        with closing(socket.create_connection((host, port), timeout=timeout)):
            return True
    except OSError:
        return False


OLLAMA_HOST = _env("OLLAMA_HOST", "http://127.0.0.1:11434")


# Skip conditions are set at collection time so missing credentials never
# reach provider __init__ (which would raise).
_SKIP_OLLAMA = not _tcp_reachable(OLLAMA_HOST)
_SKIP_GEMINI = not os.environ.get("GEMINI_API_KEY")
_SKIP_GROK = not (os.environ.get("XAI_API_KEY") or os.environ.get("GROK_API_KEY"))
_SKIP_OPENAI = not os.environ.get("OPENAI_API_KEY")


pytestmark = pytest.mark.live


@pytest.mark.skipif(_SKIP_OLLAMA, reason=f"Ollama not reachable at {OLLAMA_HOST}")
def test_live_ollama_smoke():
    from model_switchboard.providers.ollama_provider import OllamaProvider

    provider = OllamaProvider(
        provider_name="ollama",
        model_name=_env("OLLAMA_MODEL", "llama3.2:1b"),
        cost_per_1k_input_tokens=0.0,
        cost_per_1k_output_tokens=0.0,
        max_context_tokens=128000,
        host=OLLAMA_HOST,
        timeout_seconds=30,
    )
    resp = provider.generate(prompt="Reply with the single word: ok.")
    assert resp.output_text.strip()
    assert resp.tokens_in > 0
    assert resp.tokens_out > 0


@pytest.mark.skipif(_SKIP_GEMINI, reason="GEMINI_API_KEY not set")
def test_live_gemini_smoke():
    from model_switchboard.providers.gemini_provider import GeminiProvider

    provider = GeminiProvider(
        provider_name="gemini",
        model_name=_env("GEMINI_MODEL", "gemini-2.5-flash"),
        cost_per_1k_input_tokens=0.0,
        cost_per_1k_output_tokens=0.0,
        max_context_tokens=1_000_000,
    )
    resp = provider.generate(prompt="Reply with the single word: ok.")
    assert resp.output_text.strip()
    assert resp.tokens_in > 0
    assert resp.tokens_out > 0


@pytest.mark.skipif(_SKIP_GROK, reason="XAI_API_KEY / GROK_API_KEY not set")
def test_live_grok_smoke():
    from model_switchboard.providers.grok_provider import GrokProvider

    provider = GrokProvider(
        provider_name="grok",
        model_name=_env("GROK_MODEL", "grok-4-fast-reasoning"),
        cost_per_1k_input_tokens=0.0,
        cost_per_1k_output_tokens=0.0,
        max_context_tokens=256_000,
    )
    resp = provider.generate(prompt="Reply with the single word: ok.")
    assert resp.output_text.strip()
    assert resp.tokens_in > 0
    assert resp.tokens_out > 0


@pytest.mark.skipif(_SKIP_OPENAI, reason="OPENAI_API_KEY not set")
def test_live_openai_smoke():
    pytest.importorskip("openai")
    from model_switchboard.providers.openai_provider import OpenAIProvider

    provider = OpenAIProvider(
        provider_name="openai",
        model_name=_env("OPENAI_MODEL", "gpt-4o-mini"),
        cost_per_1k_input_tokens=0.0,
        cost_per_1k_output_tokens=0.0,
        max_context_tokens=128_000,
    )
    resp = provider.generate(prompt="Reply with the single word: ok.")
    assert resp.output_text.strip()
    assert resp.tokens_in > 0
    assert resp.tokens_out > 0
