from __future__ import annotations

import pytest

from model_switchboard.eval.scorers import (
    score_classification,
    score_drafting,
    score_extraction,
    score_summarization,
)
from model_switchboard.schemas.benchmark import BenchmarkExample


def _ex(task_family: str, **kwargs) -> BenchmarkExample:
    base = dict(
        example_id="test",
        task_family=task_family,
        prompt="ignored",
    )
    base.update(kwargs)
    return BenchmarkExample(**base)


# --- classification ----------------------------------------------------------


def test_classification_hit_returns_one():
    ex = _ex("classification", reference_answer="billing")
    assert score_classification(ex, "This ticket is about billing issues.") == 1.0


def test_classification_miss_returns_zero():
    ex = _ex("classification", reference_answer="billing")
    assert score_classification(ex, "Unable to determine.") == 0.0


# --- extraction --------------------------------------------------------------


def test_extraction_exact_match():
    ex = _ex("extraction", reference_answer="Payments API")
    assert score_extraction(ex, "The affected service is the Payments API.") == 1.0


def test_extraction_partial_token_overlap():
    ex = _ex("extraction", reference_answer="Payments API")
    assert score_extraction(ex, "It's the payments service.") == 0.5


def test_extraction_no_overlap():
    ex = _ex("extraction", reference_answer="Payments API")
    assert score_extraction(ex, "unrelated text") == 0.0


# --- summarization -----------------------------------------------------------


def test_summarization_full_coverage_and_length():
    ex = _ex(
        "summarization",
        rubric={"must_contain": ["latency", "caching"], "min_length": 40, "max_length": 400},
    )
    output = "We reduced latency by introducing caching. " * 3
    assert score_summarization(ex, output) == pytest.approx(1.0)


def test_summarization_partial_coverage_scales_down():
    ex = _ex(
        "summarization",
        rubric={"must_contain": ["latency", "caching"], "min_length": 40, "max_length": 400},
    )
    output = "We reduced latency somewhat. " * 3
    # 1 of 2 tokens present, length in band → 0.5
    assert score_summarization(ex, output) == pytest.approx(0.5)


def test_summarization_length_under_min_scales_down():
    ex = _ex(
        "summarization",
        rubric={"must_contain": ["latency", "caching"], "min_length": 200, "max_length": 400},
    )
    output = "latency caching"  # both tokens, way too short
    score = score_summarization(ex, output)
    assert 0.0 < score < 0.3


def test_summarization_empty_output_is_zero():
    ex = _ex("summarization", rubric={"must_contain": ["x"], "min_length": 10})
    assert score_summarization(ex, "") == 0.0


# --- drafting ----------------------------------------------------------------


def test_drafting_full_required_elements():
    ex = _ex(
        "drafting",
        rubric={
            "required_elements": ["Payments API", "resolved", "postmortem"],
            "min_length": 100,
            "max_length": 600,
        },
    )
    output = (
        "Earlier today the Payments API experienced a brief outage. The incident is "
        "now resolved and we will publish a postmortem within 48 hours."
    )
    assert score_drafting(ex, output) == pytest.approx(1.0)


def test_drafting_missing_element_scales_down():
    ex = _ex(
        "drafting",
        rubric={
            "required_elements": ["Payments API", "resolved", "postmortem"],
            "min_length": 100,
            "max_length": 600,
        },
    )
    output = (
        "Earlier today the Payments API experienced a brief outage. The incident is "
        "now resolved. We will share an update soon with more detail for customers."
    )
    # 2 of 3 required elements → ~0.667 before length multiplier (length is in band)
    assert score_drafting(ex, output) == pytest.approx(2 / 3, rel=1e-3)


def test_drafting_route_insensitive_rubric_yields_contrast_between_outputs():
    """Same rubric should score different-quality outputs differently.

    This is the R4 regression guard: scorers must vary by output.
    """
    ex = _ex(
        "drafting",
        rubric={
            "required_elements": ["escalation", "verifier", "risk"],
            "min_length": 80,
            "max_length": 400,
        },
    )
    high = "The router needs a verifier plus an escalation chain. Risk: latency overhead."
    low = "We should probably improve the router."
    assert score_drafting(ex, high) > score_drafting(ex, low)
