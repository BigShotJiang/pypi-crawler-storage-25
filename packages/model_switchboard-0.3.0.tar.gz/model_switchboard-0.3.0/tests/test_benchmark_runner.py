from __future__ import annotations

from pathlib import Path

from model_switchboard.eval.benchmark_runner import BenchmarkRunner
from model_switchboard.main import load_examples


# Columns guaranteed by BenchmarkRunner.run_all_routes — used to detect silent
# schema drift that would break downstream training pivots and reports.
EXPECTED_ALL_ROUTES_COLS = {
    "example_id",
    "task_family",
    "difficulty",
    "route",
    "prompt",
    "context",
    "prompt_tokens",
    "context_tokens",
    "total_tokens",
    "instruction_count",
    "question_count",
    "has_structured_output_request",
    "reasoning_keyword_hits",
    "security_keyword_hits",
    "requires_long_context",
    "risk_tier_num",
    "output_text",
    "tokens_in",
    "tokens_out",
    "latency_ms",
    "cost_usd",
    "quality_score",
    "success",
}

EXPECTED_HEURISTIC_COLS = {
    "example_id",
    "task_family",
    "difficulty",
    "chosen_route",
    "route_reason",
    "cost_usd",
    "latency_ms",
    "quality_score",
    "success",
}


def test_runner_all_routes_emits_expected_columns(mock_runner: BenchmarkRunner, sample_examples):
    df = mock_runner.run_all_routes(sample_examples)
    assert EXPECTED_ALL_ROUTES_COLS.issubset(df.columns)
    # Every example ran on every route.
    assert len(df) == len(sample_examples) * 3
    assert set(df["route"].unique()) == {"small", "mid", "frontier"}


def test_runner_all_routes_preserves_difficulty(mock_runner: BenchmarkRunner, sample_examples):
    df = mock_runner.run_all_routes(sample_examples)
    assert set(df["difficulty"].unique()) == {"easy", "medium", "hard"}


def test_runner_quality_is_route_sensitive(mock_runner: BenchmarkRunner, sample_examples):
    """R4 regression guard at the integration level: aggregate quality varies by route.

    The mock provider is deterministic per (tier, example), so this is a stable
    expectation — frontier must beat or tie every cheaper tier on the hard item.
    """
    df = mock_runner.run_all_routes(sample_examples)
    mean_by_route = df.groupby("route")["success"].mean()
    assert mean_by_route["frontier"] >= mean_by_route["small"]
    # The hard example should separate tiers: frontier success >= small success.
    hard = df[df["difficulty"] == "hard"].set_index("route")["success"]
    assert hard["frontier"] >= hard["small"]


def test_runner_heuristic_emits_expected_columns(mock_runner: BenchmarkRunner, sample_examples):
    df = mock_runner.run_heuristic_router(sample_examples)
    assert EXPECTED_HEURISTIC_COLS.issubset(df.columns)
    assert len(df) == len(sample_examples)
    # Heuristic must always pick a known route.
    assert set(df["chosen_route"]).issubset({"small", "mid", "frontier"})
    # route_reason strings must be non-empty.
    assert df["route_reason"].astype(str).str.len().min() > 0


def test_runner_does_not_touch_golden_result_snapshots(
    mock_runner: BenchmarkRunner, sample_examples, repo_root: Path
):
    """Guard: integration tests must not mutate saved baselines."""
    baseline = repo_root / "data" / "results" / "baseline_v0.1"
    phase_a = repo_root / "data" / "results" / "phase_a"
    baseline_before = {p.name: p.stat().st_mtime_ns for p in baseline.glob("*.csv")}
    phase_a_before = {p.name: p.stat().st_mtime_ns for p in phase_a.glob("*.csv")}

    mock_runner.run_all_routes(sample_examples)
    mock_runner.run_heuristic_router(sample_examples)

    baseline_after = {p.name: p.stat().st_mtime_ns for p in baseline.glob("*.csv")}
    phase_a_after = {p.name: p.stat().st_mtime_ns for p in phase_a.glob("*.csv")}
    assert baseline_before == baseline_after
    assert phase_a_before == phase_a_after


def test_runner_save_writes_to_tmp_without_touching_data_results(
    mock_runner: BenchmarkRunner, sample_examples, tmp_path: Path
):
    df = mock_runner.run_all_routes(sample_examples)
    out = tmp_path / "custom" / "all_routes.csv"
    mock_runner.save(df, out)
    assert out.exists()
    assert out.read_text(encoding="utf-8").startswith("example_id,")


# --- load_examples split-filter integration ----------------------------------


def test_load_examples_all_returns_full_dataset(repo_root: Path):
    path = str(repo_root / "data" / "raw" / "benchmark_examples.json")
    all_ex = load_examples(path, split="all")
    none_ex = load_examples(path, split=None)
    assert len(all_ex) == 384
    assert len(none_ex) == 384


def test_load_examples_train_is_strict_subset(repo_root: Path):
    path = str(repo_root / "data" / "raw" / "benchmark_examples.json")
    train = load_examples(path, split="train")
    all_ex = load_examples(path, split="all")
    assert 0 < len(train) < len(all_ex)
    assert {ex.split for ex in train} == {"train"}


def test_load_examples_test_is_strict_subset(repo_root: Path):
    path = str(repo_root / "data" / "raw" / "benchmark_examples.json")
    test = load_examples(path, split="test")
    all_ex = load_examples(path, split="all")
    assert 0 < len(test) < len(all_ex)
    assert {ex.split for ex in test} == {"test"}


def test_load_examples_train_and_test_partition_full_set(repo_root: Path):
    path = str(repo_root / "data" / "raw" / "benchmark_examples.json")
    all_ids = {ex.example_id for ex in load_examples(path, split="all")}
    train_ids = {ex.example_id for ex in load_examples(path, split="train")}
    test_ids = {ex.example_id for ex in load_examples(path, split="test")}
    assert train_ids.isdisjoint(test_ids)
    assert train_ids | test_ids == all_ids
