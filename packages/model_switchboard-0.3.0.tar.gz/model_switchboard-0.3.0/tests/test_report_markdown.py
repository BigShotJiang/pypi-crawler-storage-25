from __future__ import annotations

from pathlib import Path

import pandas as pd

from model_switchboard.reporting.markdown_report import write_report


REPO_ROOT = Path(__file__).resolve().parent.parent


def _build_fixture_dir(tmp_path: Path, with_learned: bool = True) -> Path:
    d = tmp_path / "results"
    d.mkdir()
    example_ids = [f"ex-{i:03d}" for i in range(8)]

    ar_rows = []
    for i, ex_id in enumerate(example_ids):
        difficulty = "easy" if i < 4 else "hard"
        for route in ("small", "mid", "frontier"):
            succ = 1 if (difficulty == "easy" or route == "frontier") else 0
            ar_rows.append(
                {
                    "example_id": ex_id,
                    "task_family": "classification",
                    "difficulty": difficulty,
                    "route": route,
                    "prompt": "x",
                    "context": "",
                    "cost_usd": {"small": 0.02, "mid": 0.10, "frontier": 0.60}[route],
                    "latency_ms": 400,
                    "quality_score": succ,
                    "success": succ,
                }
            )
    pd.DataFrame(ar_rows).to_csv(d / "all_routes.csv", index=False)

    heur = []
    for i, ex_id in enumerate(example_ids):
        difficulty = "easy" if i < 4 else "hard"
        succ = 1 if difficulty == "easy" else 0
        heur.append(
            {
                "example_id": ex_id,
                "task_family": "classification",
                "difficulty": difficulty,
                "chosen_route": "small",
                "route_reason": "fixture",
                "cost_usd": 0.02,
                "latency_ms": 400,
                "quality_score": succ,
                "success": succ,
            }
        )
    pd.DataFrame(heur).to_csv(d / "heuristic_router.csv", index=False)

    if with_learned:
        learned = []
        for i, ex_id in enumerate(example_ids):
            difficulty = "easy" if i < 4 else "hard"
            chosen = "frontier" if difficulty == "hard" else "small"
            learned.append(
                {
                    "example_id": ex_id,
                    "task_family": "classification",
                    "difficulty": difficulty,
                    "chosen_route": chosen,
                    "route_reason": "learned",
                    "predicted_success_small": 0.8 if difficulty == "easy" else 0.2,
                    "predicted_success_mid": 0.8,
                    "predicted_success_frontier": 0.95,
                    "cost_usd": 0.02 if chosen == "small" else 0.60,
                    "latency_ms": 500,
                    "quality_score": 1,
                    "success": 1,
                }
            )
        pd.DataFrame(learned).to_csv(d / "learned_router.csv", index=False)
    return d


def test_markdown_report_has_expected_sections(tmp_path):
    d = _build_fixture_dir(tmp_path)
    out = write_report(d, "all")
    assert out.exists()
    text = out.read_text(encoding="utf-8")
    for heading in (
        "# ModelSwitchboard run summary",
        "## Topline",
        "## Threshold sweep",
        "## Per-cell success rates",
        "## Highlights",
        "## Reproducibility",
    ):
        assert heading in text, f"missing heading: {heading}"


def test_markdown_report_flags_small_sample(tmp_path):
    d = _build_fixture_dir(tmp_path)
    out = write_report(d, "all")
    text = out.read_text(encoding="utf-8")
    assert "Sample-size note" in text  # 8 rows triggers the note


def test_markdown_report_handles_missing_learned(tmp_path):
    d = _build_fixture_dir(tmp_path, with_learned=False)
    out = write_report(d, "all")
    text = out.read_text(encoding="utf-8")
    assert "Threshold sweep" in text
    assert "skipped" in text.lower() or "not present" in text.lower()


def test_markdown_report_does_not_touch_golden_snapshots(tmp_path):
    baseline = REPO_ROOT / "data" / "results" / "baseline_v0.1"
    phase_a = REPO_ROOT / "data" / "results" / "phase_a"
    before = {p.name: p.stat().st_mtime_ns for p in list(baseline.glob("*.csv")) + list(phase_a.glob("*.csv"))}

    d = _build_fixture_dir(tmp_path)
    write_report(d, "all")

    after = {p.name: p.stat().st_mtime_ns for p in list(baseline.glob("*.csv")) + list(phase_a.glob("*.csv"))}
    assert before == after
