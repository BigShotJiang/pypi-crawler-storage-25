from __future__ import annotations

import json
from pathlib import Path

import pytest

from model_switchboard.runtime.decision import ExcludedRoute, RoutingDecision
from model_switchboard.runtime.decision_log import DecisionLogger


def _sample_decision(request_id: str = "req-0001") -> RoutingDecision:
    return RoutingDecision(
        request_id=request_id,
        policy_artifact_version=1,
        policy_preset="balanced",
        threshold=0.5,
        model_family="logistic",
        switchboard_version="0.1.0",
        task_family="classification",
        risk_tier="low",
        feature_summary={"prompt_tokens": 42, "total_tokens": 42},
        predicted_success={"small": 0.9, "mid": 0.95, "frontier": 0.99},
        candidate_routes=("small", "mid"),
        excluded_routes=(
            ExcludedRoute(route="frontier", reason="cost_ceiling", detail="too expensive"),
        ),
        health_snapshot={"small": {"status": "healthy"}},
        allow_escalation=True,
        initial_route="small",
        final_route="small",
        escalation_path=(),
        escalated=False,
        route_reason="learned_min_cost_above_threshold",
    )


def test_decision_is_frozen_and_serialisable():
    decision = _sample_decision()
    with pytest.raises(Exception):
        decision.request_id = "other"  # type: ignore[misc]
    payload = decision.model_dump(mode="json")
    assert payload["request_id"] == "req-0001"
    # Pydantic converts the tuple[ExcludedRoute] to a list[dict]
    assert payload["excluded_routes"][0]["route"] == "frontier"


def test_decision_logger_writes_one_line_per_decision(tmp_path: Path):
    log_path = tmp_path / "logs" / "decisions.ndjson"
    with DecisionLogger(log_path) as log:
        log.log(_sample_decision("req-0001"))
        log.log(_sample_decision("req-0002"))

    assert log_path.exists()
    lines = log_path.read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) == 2
    for line in lines:
        payload = json.loads(line)
        assert payload["policy_artifact_version"] == 1
        assert payload["switchboard_version"] == "0.1.0"


def test_decision_logger_requires_open_before_log(tmp_path: Path):
    log = DecisionLogger(tmp_path / "decisions.ndjson")
    with pytest.raises(RuntimeError):
        log.log(_sample_decision())
