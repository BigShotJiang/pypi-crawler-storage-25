from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from model_switchboard.runtime.policy import pack_policy
from model_switchboard.service.app import ServiceConfig, build_app, build_service_state

from tests.test_policy_artifact import _fit_predictor


REQUEST_TOKEN = "test-request-token"
ADMIN_TOKEN = "test-admin-token"


@pytest.fixture
def service_setup(tmp_path: Path):
    policy_dir = tmp_path / "policy"
    pack_policy(
        policy_dir,
        predictor=_fit_predictor(),
        threshold=0.5,
        preset_name="balanced",
    )
    config = ServiceConfig(
        policy_path=policy_dir,
        pricing_path=None,
        health_store_path=None,
        rollout_state_path=None,
        request_token=REQUEST_TOKEN,
        admin_token=ADMIN_TOKEN,
    )
    state = build_service_state(config)
    app = build_app(state=state)
    return state, TestClient(app)


def _auth(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def _decide_body(**overrides) -> dict:
    body = {
        "request_id": "req-1",
        "task_family": "classification",
        "prompt": "Classify: the dashboard is not loading",
        "latency_budget_ms": 3000,
        "allow_escalation": True,
    }
    body.update(overrides)
    return body


def test_health_endpoint_returns_policy_and_route_snapshot(service_setup):
    _, client = service_setup
    resp = client.get("/health")
    assert resp.status_code == 200
    payload = resp.json()
    assert payload["status"] == "ok"
    assert payload["policy"]["preset_name"] == "balanced"
    assert set(payload["routes"].keys()) == {"small", "mid", "frontier"}
    assert "rollout" in payload


def test_decide_requires_request_token(service_setup):
    _, client = service_setup
    resp = client.post("/decide", json=_decide_body())
    assert resp.status_code == 401
    detail = resp.json()["detail"]
    assert detail["error"] == "unauthorized"


def test_decide_rejects_wrong_request_token(service_setup):
    _, client = service_setup
    resp = client.post("/decide", json=_decide_body(), headers=_auth("nope"))
    assert resp.status_code == 401


def test_decide_returns_decision_on_candidate_lane(service_setup):
    state, client = service_setup
    # Default rollout state: canary_percent = 0, so we force candidate via pin.
    state.rollout.state.pin_tenant("tenant-a", state.rollout.state.tenant_pins.__class__())  # no-op sanity
    # Easier: set canary to 100 so every request hits candidate.
    state.rollout.state.canary_percent = 100
    resp = client.post("/decide", json=_decide_body(), headers=_auth(REQUEST_TOKEN))
    assert resp.status_code == 200
    payload = resp.json()
    assert payload["lane"] == "candidate"
    assert payload["decision"]["initial_route"] in {"small", "mid", "frontier"}


def test_decide_returns_baseline_route_when_kill_switch_is_on(service_setup):
    state, client = service_setup
    state.rollout.state.engage_kill_switch()
    resp = client.post("/decide", json=_decide_body(), headers=_auth(REQUEST_TOKEN))
    assert resp.status_code == 200
    payload = resp.json()
    assert payload["lane"] == "baseline"
    assert payload["reason"] == "kill_switch_engaged"
    assert payload["baseline_route"] in {"small", "mid", "frontier"}


def test_tenant_header_is_propagated_to_runtime_request(service_setup):
    state, client = service_setup
    state.rollout.state.canary_percent = 100
    resp = client.post(
        "/decide",
        json=_decide_body(),
        headers={
            **_auth(REQUEST_TOKEN),
            "x-switchboard-tenant": "tenant-abc",
        },
    )
    assert resp.status_code == 200
    # Tenant pinning still requires an explicit pin; this just proves the
    # header round-trips into the runtime request and affects canary bucketing.
    payload = resp.json()
    assert payload["lane"] in {"candidate", "baseline"}


def test_admin_rollout_update_requires_admin_token(service_setup):
    _, client = service_setup
    resp = client.post("/admin/rollout", json={"kill_switch": True})
    assert resp.status_code == 401


def test_admin_rollout_updates_kill_switch_and_canary(service_setup):
    state, client = service_setup
    resp = client.post(
        "/admin/rollout",
        json={"kill_switch": True, "canary_percent": 25},
        headers=_auth(ADMIN_TOKEN),
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["rollout"]["kill_switch"] is True
    assert body["rollout"]["canary_percent"] == 25
    # The registry state reflects the update.
    assert state.rollout.state.kill_switch is True


def test_admin_rollout_pins_tenant_to_candidate(service_setup):
    state, client = service_setup
    resp = client.post(
        "/admin/rollout",
        json={"tenant_pins": {"tenant-vip": "candidate"}},
        headers=_auth(ADMIN_TOKEN),
    )
    assert resp.status_code == 200
    assert "tenant-vip" in state.rollout.state.tenant_pins


def test_baseline_compare_records_accumulate(service_setup):
    state, client = service_setup
    state.rollout.state.canary_percent = 100
    state.rollout.state.compare_against_baseline = True

    for i in range(3):
        resp = client.post(
            "/decide",
            json=_decide_body(request_id=f"req-{i}"),
            headers=_auth(REQUEST_TOKEN),
        )
        assert resp.status_code == 200
        assert "baseline_compare" in resp.json()

    assert len(state.baseline_compare_log) == 3


def test_admin_get_rollout_returns_recent_compares(service_setup):
    state, client = service_setup
    state.rollout.state.canary_percent = 100
    state.rollout.state.compare_against_baseline = True

    for i in range(2):
        client.post(
            "/decide",
            json=_decide_body(request_id=f"req-{i}"),
            headers=_auth(REQUEST_TOKEN),
        )

    resp = client.get("/admin/rollout", headers=_auth(ADMIN_TOKEN))
    assert resp.status_code == 200
    body = resp.json()
    assert len(body["baseline_compare_recent"]) == 2
