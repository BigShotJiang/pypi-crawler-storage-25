from __future__ import annotations

import time
from dataclasses import dataclass

import pytest

from model_switchboard.runtime.decision import RoutingDecision
from model_switchboard.runtime.executor import (
    BudgetExhausted,
    ExecutionResult,
    ProviderError,
    ProviderResponse,
    ProviderTimeout,
    RuntimeExecutor,
)
from model_switchboard.runtime.health import HealthRegistry, RouteStatus
from model_switchboard.runtime.pricing import pricing_table_from_route_costs
from model_switchboard.runtime.request import RuntimeRequest
from model_switchboard.runtime.telemetry import (
    InMemoryTelemetry,
    METRIC_EXECUTION_ATTEMPT,
    METRIC_EXECUTION_SUCCESS,
)


ROUTES = ("small", "mid", "frontier")
PRICING = pricing_table_from_route_costs({"small": 0.02, "mid": 0.10, "frontier": 0.60})


# --- fakes -----------------------------------------------------------------


@dataclass
class FakeProvider:
    script: dict[str, list[object]]  # route -> list of response-or-exception

    def invoke(self, route: str, request: RuntimeRequest) -> ProviderResponse:
        queue = self.script[route]
        if not queue:
            raise ProviderError(f"no more scripted responses for {route}")
        item = queue.pop(0)
        if isinstance(item, Exception):
            raise item
        return item


class AlwaysPassVerifier:
    def verify(self, request, response):
        return True, 1.0


class ScoreGatedVerifier:
    def __init__(self, route_pass: dict[str, bool]):
        self.route_pass = route_pass

    def verify(self, request, response):
        p = self.route_pass.get(response.route, True)
        return p, 1.0 if p else 0.1


def _request(**overrides) -> RuntimeRequest:
    base = dict(
        request_id="req-1",
        task_family="classification",
        prompt="hello",
        allow_escalation=True,
        latency_budget_ms=5000,
    )
    base.update(overrides)
    return RuntimeRequest(**base)


def _decision(initial: str, escalation: tuple[str, ...] = ()) -> RoutingDecision:
    return RoutingDecision(
        request_id="req-1",
        policy_artifact_version=1,
        policy_preset=None,
        threshold=0.5,
        model_family="logistic",
        switchboard_version="0.3.0",
        task_family="classification",
        risk_tier="low",
        feature_summary={},
        predicted_success={},
        candidate_routes=(initial,),
        excluded_routes=(),
        health_snapshot={},
        allow_escalation=True,
        initial_route=initial,
        final_route=initial,
        escalation_path=escalation,
        escalated=False,
        route_reason="learned_min_cost_above_threshold",
    )


# --- tests -----------------------------------------------------------------


def test_happy_path_returns_success_on_first_attempt():
    provider = FakeProvider(
        script={"small": [ProviderResponse(route="small", output_text="ok", tokens_in=100, tokens_out=20, latency_ms=400)]}
    )
    telem = InMemoryTelemetry()
    exec_ = RuntimeExecutor(
        provider=provider, verifier=AlwaysPassVerifier(),
        pricing=PRICING, telemetry=telem,
    )
    result = exec_.execute(_request(), _decision("small"))
    assert result.passed is True
    assert result.final_route == "small"
    assert len(result.attempts) == 1
    assert result.total_cost_usd > 0
    assert telem.counters_by_name(METRIC_EXECUTION_SUCCESS)


def test_escalation_fires_on_verifier_failure():
    provider = FakeProvider(script={
        "small": [ProviderResponse(route="small", output_text="bad", tokens_in=100, tokens_out=20, latency_ms=300)],
        "mid":   [ProviderResponse(route="mid",   output_text="ok",  tokens_in=200, tokens_out=40, latency_ms=600)],
    })
    exec_ = RuntimeExecutor(
        provider=provider,
        verifier=ScoreGatedVerifier({"small": False, "mid": True}),
        pricing=PRICING,
    )
    result = exec_.execute(_request(), _decision("small", ("mid", "frontier")))
    assert result.passed is True
    assert result.final_route == "mid"
    assert result.escalated is True
    assert len(result.attempts) == 2


def test_provider_timeout_is_recorded_and_escalates():
    provider = FakeProvider(script={
        "small": [ProviderTimeout("slow")],
        "mid":   [ProviderResponse(route="mid", output_text="ok", tokens_in=100, tokens_out=20, latency_ms=300)],
    })
    exec_ = RuntimeExecutor(
        provider=provider, verifier=AlwaysPassVerifier(), pricing=PRICING,
    )
    result = exec_.execute(_request(), _decision("small", ("mid",)))
    assert result.attempts[0].error == "timeout"
    assert result.passed is True
    assert result.final_route == "mid"


def test_budget_exhausted_stops_escalation():
    # Small = 0.02 canonical, mid = 0.10. ceiling of 0.05 permits small only.
    provider = FakeProvider(script={
        "small": [ProviderResponse(route="small", output_text="bad", tokens_in=100, tokens_out=20, latency_ms=300)],
        "mid":   [ProviderResponse(route="mid",   output_text="ok",  tokens_in=200, tokens_out=40, latency_ms=600)],
    })
    exec_ = RuntimeExecutor(
        provider=provider,
        verifier=ScoreGatedVerifier({"small": False, "mid": True}),
        pricing=PRICING,
    )
    result = exec_.execute(
        _request(cost_ceiling_usd=0.05),
        _decision("small", ("mid", "frontier")),
    )
    assert result.passed is False
    assert result.budget_exhausted is True
    # Only one attempt happened — escalation refused by budget guard.
    assert len(result.attempts) == 1


def test_health_records_failure_on_provider_error():
    health = HealthRegistry(ROUTES, circuit_open_after_failures=2)
    provider = FakeProvider(script={
        "small": [ProviderError("500"), ProviderError("500")],
        "mid":   [ProviderResponse(route="mid", output_text="ok", tokens_in=100, tokens_out=20, latency_ms=300)],
    })
    exec_ = RuntimeExecutor(
        provider=provider, verifier=AlwaysPassVerifier(),
        pricing=PRICING, health=health,
    )
    # First call: small fails, mid recovers.
    exec_.execute(_request(), _decision("small", ("mid",)))
    # Second call: small fails again; circuit should now be open.
    exec_.execute(_request(request_id="req-2"), _decision("small", ("mid",)))
    assert health.snapshot("small").status is RouteStatus.CIRCUIT_OPEN


def test_telemetry_counters_emit_for_success_and_attempt():
    telem = InMemoryTelemetry()
    provider = FakeProvider(script={
        "small": [ProviderResponse(route="small", output_text="ok", tokens_in=100, tokens_out=20, latency_ms=400)]
    })
    exec_ = RuntimeExecutor(
        provider=provider, verifier=AlwaysPassVerifier(),
        pricing=PRICING, telemetry=telem,
    )
    exec_.execute(_request(), _decision("small"))
    counter_names = {s.name for s in telem.signals if s.kind == "counter"}
    assert METRIC_EXECUTION_ATTEMPT in counter_names
    assert METRIC_EXECUTION_SUCCESS in counter_names
