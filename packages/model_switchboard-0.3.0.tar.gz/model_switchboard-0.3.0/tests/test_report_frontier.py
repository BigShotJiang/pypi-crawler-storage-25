from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pandas as pd
import pytest


REPO_ROOT = Path(__file__).resolve().parent.parent
SCRIPT_PATH = REPO_ROOT / "scripts" / "report_frontier.py"


def _load_report_module():
    """Load scripts/report_frontier.py as a module without running it."""
    spec = importlib.util.spec_from_file_location("report_frontier", SCRIPT_PATH)
    assert spec and spec.loader
    mod = importlib.util.module_from_spec(spec)
    sys.modules["report_frontier"] = mod
    spec.loader.exec_module(mod)
    return mod


@pytest.fixture(scope="module")
def report_mod():
    return _load_report_module()


# --- fixtures: hand-written results dir -------------------------------------


def _example_row(example_id, family, difficulty, chosen_route, success, cost, latency=500,
                 quality=0.8):
    return {
        "example_id": example_id,
        "task_family": family,
        "difficulty": difficulty,
        "chosen_route": chosen_route,
        "route_reason": "test",
        "cost_usd": cost,
        "latency_ms": latency,
        "quality_score": quality,
        "success": success,
    }


def _build_fixture_dir(tmp_path: Path, with_learned: bool = True,
                      with_escalated: bool = True) -> Path:
    results_dir = tmp_path / "fixture_results"
    results_dir.mkdir()

    # 2 families x 2 difficulties x 2 examples = 8 examples.
    combos = [
        ("classification", "easy"),
        ("classification", "hard"),
        ("extraction", "easy"),
        ("extraction", "hard"),
    ]
    example_ids: list[str] = []
    for family, diff in combos:
        for i in range(2):
            example_ids.append(f"{family}-{diff}-{i}")

    # all_routes: each of 8 examples x 3 routes = 24 rows. Success pattern:
    # small passes easy, mid passes easy+medium, frontier passes all.
    ar_rows: list[dict] = []
    for ex_id in example_ids:
        family, diff, _ = ex_id.rsplit("-", 2)
        for route in ("small", "mid", "frontier"):
            if diff == "easy":
                succ = 1
            elif diff == "hard":
                succ = 1 if route == "frontier" else 0
            else:
                succ = 1 if route in ("mid", "frontier") else 0
            ar_rows.append(
                {
                    "example_id": ex_id,
                    "task_family": family,
                    "difficulty": diff,
                    "route": route,
                    "prompt_tokens": 50, "context_tokens": 0, "total_tokens": 50,
                    "instruction_count": 1, "question_count": 0,
                    "has_structured_output_request": 0,
                    "reasoning_keyword_hits": 0, "security_keyword_hits": 0,
                    "requires_long_context": 0, "risk_tier_num": 0,
                    "output_text": "x", "tokens_in": 100, "tokens_out": 30,
                    "latency_ms": 500,
                    "cost_usd": {"small": 0.02, "mid": 0.10, "frontier": 0.60}[route],
                    "quality_score": succ, "success": succ,
                }
            )
    pd.DataFrame(ar_rows).to_csv(results_dir / "all_routes.csv", index=False)

    # heuristic: pick small always (easy example).
    heur_rows = [
        _example_row(ex_id, family, diff, "small",
                     1 if diff == "easy" else 0,
                     0.02)
        for ex_id in example_ids
        for family, diff, _ in [ex_id.rsplit("-", 2)]
    ]
    pd.DataFrame(heur_rows).to_csv(results_dir / "heuristic_router.csv", index=False)

    if with_learned:
        # learned: escalate hard to frontier; keep easy on small.
        learned_rows = []
        for ex_id in example_ids:
            family, diff, _ = ex_id.rsplit("-", 2)
            chosen = "frontier" if diff == "hard" else "small"
            succ = 1  # by our pattern both picks succeed
            row = _example_row(ex_id, family, diff, chosen, succ,
                               {"small": 0.02, "mid": 0.10, "frontier": 0.60}[chosen])
            # Include the predicted_success_* columns so sweep can run.
            row.update(
                {
                    "predicted_success_small": 0.8 if diff == "easy" else 0.2,
                    "predicted_success_mid": 0.9 if diff in ("easy", "medium") else 0.4,
                    "predicted_success_frontier": 0.95,
                }
            )
            learned_rows.append(row)
        pd.DataFrame(learned_rows).to_csv(results_dir / "learned_router.csv", index=False)

    if with_escalated:
        esc_rows = []
        for ex_id in example_ids:
            family, diff, _ = ex_id.rsplit("-", 2)
            initial = "small" if diff == "easy" else "frontier"
            final = initial
            attempts = initial
            row = {
                "example_id": ex_id,
                "task_family": family,
                "difficulty": diff,
                "initial_route": initial,
                "final_route": final,
                "attempted_routes": attempts,
                "escalation_count": 0,
                "escalated": False,
                "verifier_pass_initial": True,
                "predicted_success_small": 0.8 if diff == "easy" else 0.2,
                "predicted_success_mid": 0.9 if diff in ("easy", "medium") else 0.4,
                "predicted_success_frontier": 0.95,
                "cost_usd": {"small": 0.02, "mid": 0.10, "frontier": 0.60}[initial],
                "latency_ms": 500,
                "quality_score": 1.0,
                "success": 1,
            }
            esc_rows.append(row)
        pd.DataFrame(esc_rows).to_csv(results_dir / "escalated_router.csv", index=False)

    return results_dir


# --- aggregate block --------------------------------------------------------


def test_aggregate_has_one_row_per_router(tmp_path, report_mod):
    results_dir = _build_fixture_dir(tmp_path)
    agg, _, _ = report_mod.build_report(results_dir, split="all")
    assert set(agg["router"]) == {"heuristic", "learned", "escalated"}
    for col in (
        "n", "mean_quality_score", "mean_cost_usd", "mean_latency_ms",
        "mean_success", "route_mix_small", "route_mix_mid", "route_mix_frontier",
        "mean_escalation_count",
    ):
        assert col in agg.columns


def test_aggregate_counts_match_input(tmp_path, report_mod):
    results_dir = _build_fixture_dir(tmp_path)
    agg, _, _ = report_mod.build_report(results_dir, split="all")
    assert (agg["n"] == 8).all()


# --- per-cell block ---------------------------------------------------------


def test_per_cell_n_matches_groupby_counts(tmp_path, report_mod):
    results_dir = _build_fixture_dir(tmp_path)
    _, cells, _ = report_mod.build_report(results_dir, split="all")
    assert "n" in cells.columns
    heuristic = pd.read_csv(results_dir / "heuristic_router.csv")
    expected = heuristic.groupby(["task_family", "difficulty"]).size().reset_index(name="n")
    merged = cells.merge(expected, on=["task_family", "difficulty"], suffixes=("_report", "_expected"))
    assert (merged["n_report"] == merged["n_expected"]).all()


# --- threshold sweep --------------------------------------------------------


def test_threshold_sweep_has_expected_rows_and_sums(tmp_path, report_mod):
    results_dir = _build_fixture_dir(tmp_path)
    _, _, sweep = report_mod.build_report(results_dir, split="all")
    assert len(sweep) == 4
    assert set(sweep["threshold"]) == {0.3, 0.5, 0.7, 0.9}
    mix_sums = (
        sweep["route_mix_small"] + sweep["route_mix_mid"] + sweep["route_mix_frontier"]
    )
    for total in mix_sums:
        assert total == pytest.approx(1.0, abs=1e-9)


def test_missing_learned_csv_leaves_sweep_empty(tmp_path, report_mod):
    results_dir = _build_fixture_dir(tmp_path, with_learned=False)
    agg, cells, sweep = report_mod.build_report(results_dir, split="all")
    assert sweep.empty
    # Aggregate + per-cell still produced.
    assert "heuristic" in set(agg["router"])
    assert not cells.empty


# --- write + CLI + guards ---------------------------------------------------


def test_write_report_emits_three_blocks(tmp_path, report_mod):
    results_dir = _build_fixture_dir(tmp_path)
    agg, cells, sweep = report_mod.build_report(results_dir, split="all")
    out = report_mod.write_report(results_dir, "all", agg, cells, sweep)
    assert out.exists()
    text = out.read_text(encoding="utf-8")
    assert "# aggregate" in text
    assert "# per_cell" in text
    assert "# threshold_sweep" in text


def test_cli_exits_non_zero_when_results_dir_missing(tmp_path):
    import subprocess, sys as _sys
    result = subprocess.run(
        [_sys.executable, str(SCRIPT_PATH), "--results-dir", str(tmp_path / "nope"),
         "--split", "all"],
        capture_output=True, text=True, check=False,
    )
    assert result.returncode != 0


def test_report_does_not_touch_golden_snapshots(tmp_path, report_mod):
    baseline = REPO_ROOT / "data" / "results" / "baseline_v0.1"
    phase_a = REPO_ROOT / "data" / "results" / "phase_a"
    before = {p.name: p.stat().st_mtime_ns for p in list(baseline.glob("*.csv")) + list(phase_a.glob("*.csv"))}

    results_dir = _build_fixture_dir(tmp_path)
    agg, cells, sweep = report_mod.build_report(results_dir, split="all")
    report_mod.write_report(results_dir, "all", agg, cells, sweep)

    after = {p.name: p.stat().st_mtime_ns for p in list(baseline.glob("*.csv")) + list(phase_a.glob("*.csv"))}
    assert before == after
