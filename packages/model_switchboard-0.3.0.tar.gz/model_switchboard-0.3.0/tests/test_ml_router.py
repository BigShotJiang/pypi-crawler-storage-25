from __future__ import annotations

from pathlib import Path

import pandas as pd
import pytest

from model_switchboard.features.extractors import RouteFeatures
from model_switchboard.router.ml_router import (
    FEATURE_COLS,
    SuccessPredictor,
    _ConstantPredictor,
)


ROUTE_LABEL_COLS = {
    "small": "success_small",
    "mid": "success_mid",
    "frontier": "success_frontier",
}


def _synthetic_frame(n_per_cell: int = 4) -> pd.DataFrame:
    """Small balanced frame with predictable labels.

    Labels: small passes easy only, mid passes easy+medium, frontier passes all.
    Phase 7 columns are filled in with deterministic, difficulty-aware defaults.
    """
    diff_num_map = {"easy": 0, "medium": 1, "hard": 2}
    rows: list[dict] = []
    for fam in ("classification", "extraction", "summarization", "drafting"):
        for diff_name in ("easy", "medium", "hard"):
            for i in range(n_per_cell):
                rows.append(
                    {
                        "example_id": f"{fam}-{diff_name}-{i}",
                        "task_family": fam,
                        "difficulty": diff_name,
                        "prompt_tokens": 50 + i * 5,
                        "context_tokens": 0,
                        "total_tokens": 50 + i * 5,
                        "instruction_count": 1,
                        "question_count": 0,
                        "has_structured_output_request": 0,
                        "reasoning_keyword_hits": 0,
                        "security_keyword_hits": 0,
                        "requires_long_context": 0,
                        "risk_tier_num": 0,
                        # Phase 7 columns
                        "difficulty_num": diff_num_map[diff_name],
                        "rubric_token_count": 2 if fam in ("summarization", "drafting") else 0,
                        "rubric_min_length": 80 if fam in ("summarization", "drafting") else 0,
                        "rubric_max_length": 400 if fam in ("summarization", "drafting") else 0,
                        "rubric_band_width": 320 if fam in ("summarization", "drafting") else 0,
                        "context_to_prompt_ratio": 0.0,
                        "has_comparison_cue": 1 if diff_name == "hard" else 0,
                        "has_summary_cue": 1 if fam == "summarization" else 0,
                        "has_extraction_cue": 1 if fam == "extraction" else 0,
                        "task_family_difficulty": f"{fam}:{diff_name}",
                        # labels
                        "success_small": 1 if diff_name == "easy" else 0,
                        "success_mid": 1 if diff_name in ("easy", "medium") else 0,
                        "success_frontier": 1,  # ALL positives → single-class fallback
                    }
                )
    return pd.DataFrame(rows)


def _features() -> RouteFeatures:
    return RouteFeatures(
        prompt_tokens=50,
        context_tokens=0,
        total_tokens=50,
        task_family="classification",
        instruction_count=1,
        question_count=0,
        has_structured_output_request=0,
        reasoning_keyword_hits=0,
        security_keyword_hits=0,
        requires_long_context=0,
        risk_tier_num=0,
        difficulty_num=0,
        rubric_token_count=0,
        rubric_min_length=0,
        rubric_max_length=0,
        rubric_band_width=0,
        context_to_prompt_ratio=0.0,
        has_comparison_cue=0,
        has_summary_cue=0,
        has_extraction_cue=0,
        task_family_difficulty="classification:easy",
    )


# --- lifecycle --------------------------------------------------------------


def test_unfitted_predictor_refuses_prediction():
    p = SuccessPredictor()
    assert p.fitted is False
    with pytest.raises(RuntimeError):
        p.predict_success(_features())


def test_unfitted_predictor_refuses_save(tmp_path: Path):
    p = SuccessPredictor()
    with pytest.raises(RuntimeError):
        p.save(tmp_path / "wont_write.joblib")


# --- fit/predict -----------------------------------------------------------


def test_fit_produces_fitted_predictor():
    df = _synthetic_frame()
    p = SuccessPredictor()
    p.fit(df, ROUTE_LABEL_COL_MAP := dict(ROUTE_LABEL_COLS))
    assert p.fitted is True
    preds = p.predict_success(_features())
    assert set(preds.keys()) == {"small", "mid", "frontier"}
    for route, prob in preds.items():
        assert 0.0 <= prob <= 1.0, (route, prob)


def test_meta_records_feature_contract_and_distribution():
    df = _synthetic_frame()
    p = SuccessPredictor()
    p.fit(df, dict(ROUTE_LABEL_COLS))
    assert p.meta["feature_cols"] == FEATURE_COLS
    assert p.meta["n_train"] == len(df)
    dist = p.meta["label_distribution"]
    assert set(dist.keys()) == {"small", "mid", "frontier"}
    # frontier is the all-ones column
    assert dist["frontier"]["positives"] == len(df)
    assert dist["frontier"]["negatives"] == 0


def test_fit_rejects_frame_missing_feature_columns():
    df = _synthetic_frame().drop(columns=["task_family"])
    p = SuccessPredictor()
    with pytest.raises(ValueError):
        p.fit(df, dict(ROUTE_LABEL_COLS))


def test_fit_rejects_missing_label_column():
    df = _synthetic_frame().drop(columns=["success_frontier"])
    p = SuccessPredictor()
    with pytest.raises(ValueError):
        p.fit(df, dict(ROUTE_LABEL_COLS))


# --- single-class fallback --------------------------------------------------


def test_single_class_route_uses_constant_predictor():
    """The frontier column is all-ones in the synthetic frame, which would crash
    LogisticRegression. The fallback should kick in and still expose predict_proba.
    """
    df = _synthetic_frame()
    p = SuccessPredictor()
    p.fit(df, dict(ROUTE_LABEL_COLS))
    assert isinstance(p.models["frontier"], _ConstantPredictor)
    assert p.models["frontier"].value == 1.0
    preds = p.predict_success(_features())
    assert preds["frontier"] >= 0.9  # constant predictor returns ~0.99 for y=1


def test_single_class_all_zero_fallback():
    """Explicit check for the 0-only branch."""
    df = _synthetic_frame()
    df["success_small"] = 0
    p = SuccessPredictor()
    p.fit(df, dict(ROUTE_LABEL_COLS))
    assert isinstance(p.models["small"], _ConstantPredictor)
    assert p.models["small"].value == 0.0
    preds = p.predict_success(_features())
    assert preds["small"] <= 0.1


# --- persistence -----------------------------------------------------------


def test_save_and_load_round_trip_preserves_predictions(tmp_path: Path):
    df = _synthetic_frame()
    p = SuccessPredictor()
    p.fit(df, dict(ROUTE_LABEL_COLS))

    feats = _features()
    before = p.predict_success(feats)

    out = tmp_path / "pred.joblib"
    saved_path = p.save(out)
    assert saved_path == out
    assert out.exists()

    reloaded = SuccessPredictor.load(out)
    assert reloaded.fitted is True
    after = reloaded.predict_success(feats)

    for route in before:
        assert before[route] == pytest.approx(after[route], abs=1e-12)


def test_load_detects_feature_contract_drift(tmp_path: Path):
    df = _synthetic_frame()
    p = SuccessPredictor()
    p.fit(df, dict(ROUTE_LABEL_COLS))
    out = tmp_path / "pred.joblib"
    p.save(out)

    # Corrupt the metadata to drop a required feature column and re-save.
    import joblib

    bundle = joblib.load(out)
    bundle["meta"]["feature_cols"] = [c for c in FEATURE_COLS if c != "prompt_tokens"]
    joblib.dump(bundle, out)

    with pytest.raises(ValueError):
        SuccessPredictor.load(out)


# --- Phase 7: model family --------------------------------------------------


def test_default_model_family_is_logistic():
    p = SuccessPredictor()
    assert p.model_family == "logistic"


def test_unsupported_model_family_raises():
    with pytest.raises(ValueError):
        SuccessPredictor(model_family="xgboost")  # type: ignore[arg-type]


def test_gbm_fits_and_predicts_in_bounds():
    df = _synthetic_frame()
    p = SuccessPredictor(model_family="gbm")
    p.fit(df, dict(ROUTE_LABEL_COLS))
    preds = p.predict_success(_features())
    for route, prob in preds.items():
        assert 0.0 <= prob <= 1.0, (route, prob)


def test_meta_records_model_family(tmp_path: Path):
    for family in ("logistic", "gbm"):
        df = _synthetic_frame()
        p = SuccessPredictor(model_family=family)  # type: ignore[arg-type]
        p.fit(df, dict(ROUTE_LABEL_COLS))
        assert p.meta["model_family"] == family
        out = tmp_path / f"pred_{family}.joblib"
        p.save(out)
        reloaded = SuccessPredictor.load(out)
        assert reloaded.model_family == family


def test_gbm_round_trip_preserves_predictions(tmp_path: Path):
    df = _synthetic_frame()
    p = SuccessPredictor(model_family="gbm")
    p.fit(df, dict(ROUTE_LABEL_COLS))

    feats = _features()
    before = p.predict_success(feats)

    out = tmp_path / "pred_gbm.joblib"
    p.save(out)
    reloaded = SuccessPredictor.load(out)
    after = reloaded.predict_success(feats)

    for route in before:
        assert before[route] == pytest.approx(after[route], abs=1e-6)


def test_load_rejects_phase_6_shaped_artifact(tmp_path: Path):
    """An artifact recorded with only the Phase 6 feature set (10 numeric +
    1 categorical, no difficulty_num / rubric / cue / composite) must fail
    to load under the Phase 7 contract."""
    df = _synthetic_frame()
    p = SuccessPredictor()
    p.fit(df, dict(ROUTE_LABEL_COLS))
    out = tmp_path / "phase_6_shaped.joblib"
    p.save(out)

    import joblib

    phase_6_cols = [
        "prompt_tokens", "context_tokens", "total_tokens", "instruction_count",
        "question_count", "has_structured_output_request", "reasoning_keyword_hits",
        "security_keyword_hits", "requires_long_context", "risk_tier_num",
        "task_family",
    ]
    bundle = joblib.load(out)
    bundle["meta"]["feature_cols"] = phase_6_cols
    joblib.dump(bundle, out)

    with pytest.raises(ValueError):
        SuccessPredictor.load(out)


def test_load_rejects_unknown_model_family(tmp_path: Path):
    df = _synthetic_frame()
    p = SuccessPredictor()
    p.fit(df, dict(ROUTE_LABEL_COLS))
    out = tmp_path / "bad_family.joblib"
    p.save(out)

    import joblib

    bundle = joblib.load(out)
    bundle["meta"]["model_family"] = "quantum_forest"
    joblib.dump(bundle, out)

    with pytest.raises(ValueError):
        SuccessPredictor.load(out)
