from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from model_switchboard.runtime.pricing import (
    CANONICAL_TOKENS_IN,
    CANONICAL_TOKENS_OUT,
    PricingTable,
    load_pricing_table,
    pricing_table_from_dict,
    pricing_table_from_route_costs,
    require_coverage,
)


def _sample_payload() -> dict:
    return {
        "routes": {
            "small": {
                "provider": "mock",
                "model": "small-sim",
                "input_per_1k_usd": 0.15,
                "output_per_1k_usd": 0.60,
            },
            "mid": {
                "provider": "mock",
                "model": "mid-sim",
                "input_per_1k_usd": 1.00,
                "output_per_1k_usd": 3.00,
            },
            "frontier": {
                "provider": "mock",
                "model": "frontier-sim",
                "input_per_1k_usd": 5.00,
                "output_per_1k_usd": 15.00,
            },
        }
    }


def test_pricing_table_reads_yaml(tmp_path: Path):
    path = tmp_path / "pricing.yaml"
    path.write_text(yaml.safe_dump(_sample_payload()), encoding="utf-8")
    table = load_pricing_table(path)
    assert set(table.routes) == {"small", "mid", "frontier"}
    small = table.rate("small")
    assert small.provider == "mock"
    assert small.input_per_1k_usd == 0.15


def test_cost_accounting_uses_actual_token_counts():
    table = pricing_table_from_dict(_sample_payload())
    # 1k tokens in, 1k tokens out on frontier = 5 + 15 = 20 USD
    assert table.cost_for("frontier", 1000, 1000) == pytest.approx(20.0)


def test_canonical_cost_uses_fixed_sizing():
    table = pricing_table_from_dict(_sample_payload())
    expected = (
        CANONICAL_TOKENS_IN / 1000.0 * 0.15 + CANONICAL_TOKENS_OUT / 1000.0 * 0.60
    )
    assert table.canonical_cost("small") == pytest.approx(expected)


def test_missing_route_raises_keyerror():
    table = pricing_table_from_dict(_sample_payload())
    with pytest.raises(KeyError):
        table.cost_for("gpu-cluster", 100, 100)


def test_from_route_costs_preserves_canonical_signal():
    table = pricing_table_from_route_costs({"small": 0.20, "mid": 1.20, "frontier": 6.00})
    assert table.canonical_cost("small") == pytest.approx(0.20)
    assert table.canonical_cost("frontier") == pytest.approx(6.00)


def test_require_coverage_flags_missing_routes():
    table = pricing_table_from_dict({"routes": {"small": _sample_payload()["routes"]["small"]}})
    with pytest.raises(ValueError):
        require_coverage(table, ("small", "mid", "frontier"))


def test_malformed_payload_raises():
    with pytest.raises(ValueError):
        pricing_table_from_dict({"routes": {"small": {"provider": "mock"}}})
