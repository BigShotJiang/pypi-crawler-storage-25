from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from model_switchboard.reporting.manifest import build_manifest, write_manifest


def _make_results_dir(tmp_path: Path) -> Path:
    d = tmp_path / "results"
    d.mkdir()
    pd.DataFrame(
        [
            {
                "example_id": "ex-001",
                "task_family": "classification",
                "difficulty": "easy",
                "chosen_route": "small",
                "route_reason": "test",
                "cost_usd": 0.02,
                "latency_ms": 100,
                "quality_score": 1,
                "success": 1,
            }
        ]
    ).to_csv(d / "heuristic_router.csv", index=False)
    return d


def test_manifest_captures_core_fields(tmp_path):
    d = _make_results_dir(tmp_path)
    manifest = build_manifest(
        d,
        split="all",
        config_path="configs/models.yaml",
        model_path="data/models/predictor.joblib",
        threshold=0.5,
        policy_preset="balanced",
    )
    assert manifest["split"] == "all"
    assert manifest["results_dir"] == str(d)
    assert "heuristic" in manifest["routers_present"]
    assert manifest["row_counts"]["heuristic"] == 1
    assert manifest["source_csvs"] == ["heuristic_router.csv"]
    assert manifest["config_path"] == "configs/models.yaml"
    assert manifest["model_path"] == "data/models/predictor.joblib"
    assert manifest["threshold"] == 0.5
    assert manifest["policy_preset"] == "balanced"
    assert "switchboard_version" in manifest


def test_manifest_omits_unknown_optional_fields(tmp_path):
    d = _make_results_dir(tmp_path)
    manifest = build_manifest(d, split="all")
    for optional in ("config_path", "model_path", "threshold", "policy_preset"):
        assert optional not in manifest


def test_write_manifest_writes_json_file(tmp_path):
    d = _make_results_dir(tmp_path)
    out = write_manifest(d, split="all")
    assert out.exists()
    payload = json.loads(out.read_text(encoding="utf-8"))
    assert payload["routers_present"] == ["heuristic"]
