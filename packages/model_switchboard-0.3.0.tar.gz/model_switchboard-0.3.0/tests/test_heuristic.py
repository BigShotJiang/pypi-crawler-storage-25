from __future__ import annotations

from model_switchboard.features.extractors import RouteFeatures
from model_switchboard.router.heuristic import choose_heuristic_route


def _features(**overrides) -> RouteFeatures:
    base = dict(
        prompt_tokens=100,
        context_tokens=0,
        total_tokens=100,
        task_family="classification",
        instruction_count=0,
        question_count=0,
        has_structured_output_request=0,
        reasoning_keyword_hits=0,
        security_keyword_hits=0,
        requires_long_context=0,
        risk_tier_num=0,
        # Phase 7 defaults (unused by the heuristic router, included for schema parity)
        difficulty_num=0,
        rubric_token_count=0,
        rubric_min_length=0,
        rubric_max_length=0,
        rubric_band_width=0,
        context_to_prompt_ratio=0.0,
        has_comparison_cue=0,
        has_summary_cue=0,
        has_extraction_cue=0,
        task_family_difficulty="classification:easy",
    )
    base.update(overrides)
    return RouteFeatures(**base)  # type: ignore[arg-type]


# --- frontier branches -------------------------------------------------------


def test_high_risk_routes_to_frontier():
    route, reason = choose_heuristic_route(_features(risk_tier_num=2))
    assert route == "frontier"
    assert reason["reason"] == "high_risk"


def test_high_reasoning_routes_to_frontier():
    route, reason = choose_heuristic_route(_features(reasoning_keyword_hits=3))
    assert route == "frontier"
    assert reason["reason"] == "high_reasoning"


# --- mid branches ------------------------------------------------------------


def test_long_context_routes_to_mid():
    route, reason = choose_heuristic_route(_features(requires_long_context=1))
    assert route == "mid"
    assert reason["reason"] == "long_context"


def test_security_sensitive_routes_to_mid():
    route, reason = choose_heuristic_route(_features(security_keyword_hits=1))
    assert route == "mid"
    assert reason["reason"] == "security_sensitive"


def test_default_mid_for_drafting():
    # Drafting task that hits no earlier branch falls through to default_mid.
    route, reason = choose_heuristic_route(
        _features(task_family="drafting", total_tokens=500)
    )
    assert route == "mid"
    assert reason["reason"] == "default_mid"


# --- small branches ----------------------------------------------------------


def test_simple_classification_under_token_budget_routes_to_small():
    route, reason = choose_heuristic_route(
        _features(task_family="classification", total_tokens=200)
    )
    assert route == "small"
    assert reason["reason"] == "simple_task_low_token"


def test_simple_extraction_under_token_budget_routes_to_small():
    route, reason = choose_heuristic_route(
        _features(task_family="extraction", total_tokens=300)
    )
    assert route == "small"
    assert reason["reason"] == "simple_task_low_token"


def test_short_summarization_routes_to_small():
    route, reason = choose_heuristic_route(
        _features(task_family="summarization", total_tokens=1500)
    )
    assert route == "small"
    assert reason["reason"] == "short_summary"


# --- precedence --------------------------------------------------------------


def test_high_risk_beats_simple_classification_shortcut():
    """Risk tier must dominate the cheap classification path."""
    route, _ = choose_heuristic_route(
        _features(task_family="classification", total_tokens=100, risk_tier_num=2)
    )
    assert route == "frontier"


def test_long_context_beats_short_summary_shortcut():
    route, reason = choose_heuristic_route(
        _features(task_family="summarization", total_tokens=1000, requires_long_context=1)
    )
    assert route == "mid"
    assert reason["reason"] == "long_context"
