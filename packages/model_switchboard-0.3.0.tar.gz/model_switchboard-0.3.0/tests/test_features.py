from __future__ import annotations

from typing import Any

import pytest

from model_switchboard.features.extractors import (
    extract_features,
    rough_token_count,
)
from model_switchboard.schemas.request import RequestRecord


def _req(
    prompt: str,
    *,
    context: str | None = None,
    task_family: str = "classification",
    risk_tier: str = "low",
    hint: dict[str, Any] | None = None,
) -> RequestRecord:
    metadata: dict[str, Any] = {}
    if hint is not None:
        metadata["hint"] = hint
    return RequestRecord(
        request_id="t",
        prompt=prompt,
        context=context,
        task_family=task_family,  # type: ignore[arg-type]
        risk_tier=risk_tier,  # type: ignore[arg-type]
        metadata=metadata,
    )


# --- rough_token_count -------------------------------------------------------


def test_rough_token_count_none_is_zero():
    assert rough_token_count(None) == 0
    assert rough_token_count("") == 0


def test_rough_token_count_floors_to_char_over_four():
    # 12 chars → 3 tokens. Floor at 1 for non-empty short strings.
    assert rough_token_count("a" * 12) == 3
    assert rough_token_count("ab") == 1


# --- extract_features basics -------------------------------------------------


def test_total_tokens_is_sum_of_prompt_and_context():
    feats = extract_features(_req("a" * 40, context="b" * 80))
    assert feats.prompt_tokens == 10
    assert feats.context_tokens == 20
    assert feats.total_tokens == 30


def test_task_family_propagated():
    feats = extract_features(_req("hello", task_family="summarization"))
    assert feats.task_family == "summarization"


def test_risk_tier_num_mapping():
    assert extract_features(_req("x", risk_tier="low")).risk_tier_num == 0
    assert extract_features(_req("x", risk_tier="medium")).risk_tier_num == 1
    assert extract_features(_req("x", risk_tier="high")).risk_tier_num == 2


# --- structured output flag --------------------------------------------------


def test_structured_output_json_triggers_flag():
    feats = extract_features(_req("Return a JSON object with fields."))
    assert feats.has_structured_output_request == 1


def test_structured_output_bullet_triggers_flag():
    feats = extract_features(_req("Summarize in 3 bullet points."))
    assert feats.has_structured_output_request == 1


def test_structured_output_absent():
    feats = extract_features(_req("Write a brief paragraph."))
    assert feats.has_structured_output_request == 0


# --- question and instruction counts -----------------------------------------


def test_question_count_counts_question_marks():
    feats = extract_features(_req("What is X? And Y? And Z?"))
    assert feats.question_count == 3


def test_instruction_count_picks_up_list_markers():
    prompt = "Do the following:\n- first\n- second\n1. third"
    feats = extract_features(_req(prompt))
    # At least the three list markers are caught.
    assert feats.instruction_count >= 3


# --- reasoning and security keyword hits -------------------------------------


def test_reasoning_keyword_hits():
    feats = extract_features(_req("Compare and analyze the tradeoff here."))
    assert feats.reasoning_keyword_hits >= 3


def test_security_keyword_hits_include_context():
    feats = extract_features(
        _req(
            "Review the document for compliance.",
            context="Contains user PII and API credentials.",
        )
    )
    assert feats.security_keyword_hits >= 2


# --- long context detection --------------------------------------------------


def test_requires_long_context_short_is_zero():
    feats = extract_features(_req("short", context="a" * 400))
    assert feats.requires_long_context == 0


def test_requires_long_context_above_threshold_is_one():
    # context_tokens = len // 4; need > 5000 → len > 20000
    feats = extract_features(_req("x", context="a" * 20_008))
    assert feats.context_tokens > 5000
    assert feats.requires_long_context == 1


# --- Phase 7: difficulty and hint fallback -----------------------------------


def test_hint_missing_defaults_to_easy_and_zeroed_rubric():
    feats = extract_features(_req("classify this", task_family="classification"))
    assert feats.difficulty_num == 0
    assert feats.rubric_token_count == 0
    assert feats.rubric_min_length == 0
    assert feats.rubric_max_length == 0
    assert feats.rubric_band_width == 0
    assert feats.task_family_difficulty == "classification:easy"


@pytest.mark.parametrize(
    "difficulty,expected_num",
    [("easy", 0), ("medium", 1), ("hard", 2)],
)
def test_difficulty_num_maps_correctly(difficulty, expected_num):
    feats = extract_features(
        _req("p", task_family="extraction", hint={"difficulty": difficulty})
    )
    assert feats.difficulty_num == expected_num
    assert feats.task_family_difficulty == f"extraction:{difficulty}"


# --- Phase 7: rubric complexity ---------------------------------------------


def test_rubric_fields_populate_from_hint():
    hint = {
        "difficulty": "medium",
        "rubric": {
            "must_contain": ["a", "b", "c"],
            "min_length": 100,
            "max_length": 500,
        },
    }
    feats = extract_features(_req("summarize.", task_family="summarization", hint=hint))
    assert feats.rubric_token_count == 3
    assert feats.rubric_min_length == 100
    assert feats.rubric_max_length == 500
    assert feats.rubric_band_width == 400


def test_rubric_required_elements_counted_and_unioned():
    hint = {
        "rubric": {
            "required_elements": ["x", "y"],
            "must_contain": ["z"],
            "min_length": 120,
            "max_length": 120,
        },
    }
    feats = extract_features(_req("draft.", task_family="drafting", hint=hint))
    assert feats.rubric_token_count == 3  # 2 + 1
    assert feats.rubric_band_width == 0  # min == max


def test_rubric_band_width_non_negative_when_only_min_set():
    hint = {"rubric": {"min_length": 80}}
    feats = extract_features(_req("p", task_family="summarization", hint=hint))
    assert feats.rubric_min_length == 80
    assert feats.rubric_max_length == 0
    assert feats.rubric_band_width == 0  # clamped at zero


# --- Phase 7: cue detectors -------------------------------------------------


def test_comparison_cue_triggers_on_compare_and_versus():
    for prompt in ("Compare X and Y.", "X vs Y please.", "Discuss the tradeoff."):
        feats = extract_features(_req(prompt))
        assert feats.has_comparison_cue == 1, prompt


def test_summary_cue_triggers_on_common_variants():
    for prompt in ("Summarize in bullets.", "Please summarise.", "Give a TLDR."):
        feats = extract_features(_req(prompt))
        assert feats.has_summary_cue == 1, prompt


def test_extraction_cue_triggers_on_extract_and_identify():
    for prompt in ("Extract the date.", "Identify the service.", "Return the error code."):
        feats = extract_features(_req(prompt))
        assert feats.has_extraction_cue == 1, prompt


def test_cues_are_zero_when_absent():
    feats = extract_features(_req("A brief note about the change."))
    assert feats.has_comparison_cue == 0
    assert feats.has_summary_cue == 0
    assert feats.has_extraction_cue == 0


def test_cue_detection_is_case_insensitive():
    feats = extract_features(_req("SUMMARIZE THIS FOR ME."))
    assert feats.has_summary_cue == 1


# --- Phase 7: context_to_prompt_ratio ---------------------------------------


def test_context_to_prompt_ratio_zero_when_no_context():
    feats = extract_features(_req("hello"))
    assert feats.context_to_prompt_ratio == 0.0


def test_context_to_prompt_ratio_scales():
    feats = extract_features(_req("a" * 40, context="b" * 80))
    # prompt_tokens=10, context_tokens=20, ratio=2.0
    assert feats.context_to_prompt_ratio == pytest.approx(2.0)


# --- Phase 7: composite key for every cell ----------------------------------


@pytest.mark.parametrize(
    "family,difficulty",
    [
        (fam, diff)
        for fam in ("classification", "extraction", "summarization", "drafting")
        for diff in ("easy", "medium", "hard")
    ],
)
def test_task_family_difficulty_composite_covers_all_cells(family, difficulty):
    feats = extract_features(
        _req("p", task_family=family, hint={"difficulty": difficulty})
    )
    assert feats.task_family_difficulty == f"{family}:{difficulty}"


# --- Phase 7: legacy signal regression guard --------------------------------


def test_legacy_values_unchanged_by_phase_7_additions():
    """Pre-Phase-7 signals must still compute the same values when hint is present."""
    hint = {"difficulty": "hard", "rubric": {"must_contain": ["x"], "min_length": 100}}
    feats = extract_features(
        _req("Compare X and Y.", task_family="summarization", hint=hint)
    )
    # Spot-check that pre-existing fields did not drift.
    assert feats.prompt_tokens == rough_token_count("Compare X and Y.")
    assert feats.task_family == "summarization"
    assert feats.risk_tier_num == 0
    assert feats.reasoning_keyword_hits >= 1  # "compare"
