from __future__ import annotations

import logging

import pytest

from model_switchboard.runtime.telemetry import (
    InMemoryTelemetry,
    LoggingTelemetry,
    NullTelemetry,
    METRIC_DECISION_COUNT,
    METRIC_ROUTE_EXCLUDED,
)


def test_null_telemetry_returns_none_for_everything():
    sink = NullTelemetry()
    assert sink.counter("x") is None
    assert sink.histogram("y", 1.0) is None
    assert sink.event("z") is None


def test_in_memory_telemetry_captures_counters_and_labels():
    sink = InMemoryTelemetry()
    sink.counter(METRIC_DECISION_COUNT, labels={"route": "small"})
    sink.counter(METRIC_DECISION_COUNT, value=3, labels={"route": "mid"})
    counts = sink.counters_by_name(METRIC_DECISION_COUNT)
    assert len(counts) == 2
    assert counts[0].labels == {"route": "small"}
    assert counts[1].value == 3.0


def test_in_memory_telemetry_captures_histograms_and_events():
    sink = InMemoryTelemetry()
    sink.histogram("latency", 42.0, labels={"route": "frontier"})
    sink.event("kill_switch", attributes={"reason": "ops_paged"})
    kinds = [s.kind for s in sink.signals]
    assert kinds == ["histogram", "event"]
    assert sink.signals[0].value == 42.0
    assert sink.signals[1].attributes == {"reason": "ops_paged"}


def test_logging_telemetry_emits_records(caplog):
    sink = LoggingTelemetry(logger_name="model_switchboard.telemetry.test")
    with caplog.at_level(logging.INFO, logger="model_switchboard.telemetry.test"):
        sink.counter(METRIC_ROUTE_EXCLUDED, labels={"route": "frontier", "reason": "health"})
    assert any("counter" in r.message and "route=frontier" in r.message for r in caplog.records)
