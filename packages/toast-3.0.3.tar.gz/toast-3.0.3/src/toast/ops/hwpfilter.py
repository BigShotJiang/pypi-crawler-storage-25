# Copyright (c) 2015-2026 by the parties listed in the AUTHORS file.
# All rights reserved.  Use of this source code is governed by
# a BSD-style license that can be found in the LICENSE file.

from time import time

import numpy as np
import traitlets
from astropy import units as u

from .._libtoast import (
    add_templates, bin_invcov, bin_proj, fourier_templates, legendre_templates
)
from ..data import Data
from ..mpi import MPI
from ..observation import default_values as defaults
from ..timing import Timer, function_timer
from ..traits import Bool, Int, Unicode, trait_docs
from ..utils import Environment, Logger
from .operator import Operator

# Wrappers for more precise timing


@function_timer
def bin_proj_fast(ref, templates, good, proj):
    return bin_proj(ref, templates, good, proj)


@function_timer
def bin_invcov_fast(templates, good, invcov):
    return bin_invcov(templates, good, invcov)


@function_timer
def get_rcond(invcov):
    return 1 / np.linalg.cond(invcov)


@function_timer
def get_inverse(invcov):
    return np.linalg.inv(invcov)


@function_timer
def get_pseudoinverse(invcov):
    return np.linalg.pinv(invcov, rcond=1e-12, hermitian=True)


@function_timer
def lstsq_coeff(invcov, proj):
    cov = np.linalg.inv(invcov)
    return np.linalg.lstsq(invcov, proj, rcond=1e-30)[0]


@trait_docs
class HWPFilter(Operator):
    """Operator that applies HWP-synchronous signal filtering."""

    # Class traits

    API = Int(0, help="Internal interface version for this operator")

    det_data = Unicode(
        defaults.det_data,
        help="Observation detdata key",
    )

    det_mask = Int(
        defaults.det_mask_invalid,
        help="Bit mask value for per-detector flagging",
    )

    shared_flags = Unicode(
        defaults.shared_flags,
        allow_none=True,
        help="Observation shared key for telescope flags to use",
    )

    shared_flag_mask = Int(
        defaults.shared_mask_invalid,
        help="Bit mask value for optional shared flagging",
    )

    det_flags = Unicode(
        defaults.det_flags,
        allow_none=True,
        help="Observation detdata key for flags to use",
    )

    det_flag_mask = Int(
        defaults.det_mask_invalid,
        help="Bit mask value for detector sample flagging",
    )

    hwp_flag_mask = Int(
        defaults.det_mask_invalid,
        help="Bit mask to use when adding flags based on HWP filter failures.",
    )

    hwp_angle = Unicode(
        defaults.hwp_angle, allow_none=True, help="Observation shared key for HWP angle"
    )

    trend_order = Int(
        5, help="Order of a Legendre polynomial to fit along with the HWPSS template."
    )

    filter_order = Int(
        5, help="Order of a Fourier expansion to fit as a function of HWP angle."
    )

    save_amplitudes = Unicode(
        None,
        allow_none=True,
        help="Store the template amplitudes in observation metadata using this key."
    )

    view = Unicode(
        None, allow_none=True, help="Use this view of the data in all observations"
    )

    detrend = Bool(
        False, help="Subtract the fitted trend along with the HWP template"
    )

    reverse = Bool(
        False, help="Instead of subtracting the templates, add them back based "
        "on saved amplitudes",
    )

    @traitlets.validate("det_mask")
    def _check_det_mask(self, proposal):
        check = proposal["value"]
        if check < 0:
            raise traitlets.TraitError("Det mask should be a positive integer")
        return check

    @traitlets.validate("det_flag_mask")
    def _check_det_flag_mask(self, proposal):
        check = proposal["value"]
        if check < 0:
            raise traitlets.TraitError("Flag mask should be a positive integer")
        return check

    @traitlets.validate("shared_flag_mask")
    def _check_shared_flag_mask(self, proposal):
        check = proposal["value"]
        if check < 0:
            raise traitlets.TraitError("Flag mask should be a positive integer")
        return check

    @traitlets.validate("trend_order")
    def _check_trend_order(self, proposal):
        check = proposal["value"]
        if check < 0:
            raise traitlets.TraitError("Trend order should be a non-negative integer")
        return check

    @traitlets.validate("filter_order")
    def _check_filter_order(self, proposal):
        check = proposal["value"]
        if check < 0:
            raise traitlets.TraitError("Filter order should be a non-negative integer")
        return check

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @function_timer
    def build_templates(self, obs):
        """Construct the local HWPSS template hierarchy"""

        # Construct trend templates.  Full domain for x is [-1, 1]

        my_offset = obs.local_index_offset
        my_nsamp = obs.n_local_samples
        nsamp_tot = obs.n_all_samples
        x = np.arange(my_offset, my_offset + my_nsamp) / nsamp_tot * 2 - 1

        legendre_trend = np.zeros([self.trend_order + 1, my_nsamp])
        legendre_templates(x, legendre_trend, 0, self.trend_order + 1)

        # Fourier templates

        hwp_angle = obs.shared[self.hwp_angle].data
        nfilter = 2 * self.filter_order
        ftemplates = np.zeros([nfilter, my_nsamp])
        fourier_templates(hwp_angle, ftemplates, 1, self.filter_order + 1)

        templates = np.vstack([legendre_trend, ftemplates])

        return templates, legendre_trend, ftemplates

    @function_timer
    def fit_templates(
        self,
        templates,
        ref,
        good,
        last_good,
        last_invcov,
        last_cov,
        last_rcond,
    ):
        log = Logger.get()
        ngood = np.sum(good)
        if ngood == 0:
            return None, None, None, None

        ntemplate = len(templates)
        invcov = np.zeros([ntemplate, ntemplate])
        proj = np.zeros(ntemplate)

        bin_proj_fast(ref, templates, good.astype(np.uint8), proj)
        if last_good is not None and np.all(good == last_good):
            # Flags have not changed, we can re-use the last inverse covariance
            invcov = last_invcov
            cov = last_cov
            rcond = last_rcond
        else:
            bin_invcov_fast(templates, good.astype(np.uint8), invcov)
            rcond = get_rcond(invcov)
            cov = None

        self.rcondsum += rcond
        if rcond > 1e-6:
            self.ngood += 1
            if cov is None:
                cov = get_inverse(invcov)
        else:
            self.nsingular += 1
            log.debug(
                f"HWP template matrix is poorly conditioned, "
                f"rcond = {rcond}, using pseudoinverse."
            )
            if cov is None:
                cov = get_pseudoinverse(invcov)
        coeff = np.dot(cov, proj)
        return coeff, invcov, cov, rcond

    @function_timer
    def subtract_templates(self, ref, coeff, legendre_trend, fourier_filter):
        # Trend
        if self.detrend:
            trend = np.zeros_like(ref)
            add_templates(trend, legendre_trend, coeff[: self.trend_order + 1])
            ref[:] -= trend
        # HWP template
        hwptemplate = np.zeros_like(ref)
        add_templates(hwptemplate, fourier_filter, coeff[self.trend_order + 1 :])
        ref[:] -= hwptemplate
        return

    @function_timer
    def _exec(self, data, detectors=None, **kwargs):
        log = Logger.get()
        wcomm = data.comm.comm_world

        if self.reverse and self.save_amplitudes is None:
            msg = f"Cannot reverse HWP filter without saved template amplitudes"
            raise RuntimeError(msg)

        self.nsingular = 0
        self.ngood = 0
        self.rcondsum = 0

        # Each group loops over its own CES:es
        nobs = len(data.obs)
        for iobs, obs in enumerate(data.obs):
            if not obs.is_distributed_by_detector:
                raise RuntimeError("HWPFilter assumes data is split by detector")

            if self.save_amplitudes not in obs:
                if self.reverse:
                    msg = (
                        f"Did not find saved amplitudes called "
                        f"'{self.save_amplitudes}' in {obs.name}"
                    )
                    raise RuntimeError(msg)
                else:
                    # Start a new dictionary for template amplitudes
                    obs[self.save_amplitudes] = {}

            # Prefix for logging
            log_prefix = f"{data.comm.group} : {obs.name} :"

            if self.hwp_angle in obs.shared:
                if obs.comm.group_rank == 0:
                    msg = f"{log_prefix} HWPSS Filter: "
                    msg += f"Processing observation {iobs + 1} / {nobs}"
                    msg += f" ({obs.name}).  reverse = {self.reverse}"
                    log.debug(msg)
            else:
                # This observation has no HWP
                if obs.comm.group_rank == 0:
                    msg = (
                        f"{log_prefix} HWPSS Filter:  skipping observation {obs.name},"
                    )
                    msg += f" which has no HWP"
                    log.debug(msg)
                continue

            # Cache the output common flags
            if self.shared_flags is not None:
                common_flags = (
                    obs.shared[self.shared_flags].data & self.shared_flag_mask
                )
            else:
                common_flags = np.zeros(obs.n_local_samples, dtype=np.uint8)

            t1 = time()
            templates, legendre_trend, fourier_filter = self.build_templates(obs)
            if obs.comm.group_rank == 0:
                msg = (
                    f"{log_prefix} HWPSS Filter: "
                    f"Built templates in {time() - t1:.1f}s"
                )
                log.debug(msg)

            last_good = None
            last_invcov = None
            last_cov = None
            last_rcond = None
            local_dets = obs.select_local_detectors(detectors, flagmask=self.det_mask)
            msg = f"{log_prefix} {obs.comm.group_rank} HWPSS Filter: has {len(local_dets)} local dets"
            log.verbose(msg)
            for det in local_dets:
                msg = f"{log_prefix} {det} HWPSS Filter: starting"
                log.verbose(msg)

                ref = obs.detdata[self.det_data][det]

                if self.reverse:
                    # Add the templates back. Useful if we are deglitching
                    # but want to to retain the offset in demodulation
                    if det not in obs[self.save_amplitudes]:
                        msg = f"No saved amplitudes found for det = {det}"
                        raise RuntimeError(msg)
                    coeff = -obs[self.save_amplitudes][det]
                else:
                    # Fit the templates against the data
                    if self.det_flags is not None:
                        test_flags = obs.detdata[self.det_flags][det] & self.det_flag_mask
                        good = np.logical_and(common_flags == 0, test_flags == 0)
                    else:
                        good = common_flags == 0

                    t1 = time()
                    coeff, last_invcov, last_cov, last_rcond = self.fit_templates(
                        templates,
                        ref,
                        good,
                        last_good,
                        last_invcov,
                        last_cov,
                        last_rcond,
                    )

                    if self.save_amplitudes is not None:
                        obs[self.save_amplitudes][det] = coeff

                    last_good = good
                    msg = (
                        f"{log_prefix} {det} HWPSS Filter: "
                        f"  Fit templates in {time() - t1:.1f}s"
                    )
                    log.verbose(msg)

                    if coeff is None:
                        # All samples flagged or template fit failed.
                        curflag = obs.local_detector_flags[det]
                        obs.update_local_detector_flags(
                            {det: curflag | self.hwp_flag_mask}
                        )
                        continue

                t1 = time()
                self.subtract_templates(ref, coeff, legendre_trend, fourier_filter)
                msg = (
                    f"{log_prefix} {det} HWPSS Filter: "
                    f"  Subtract templates in {time() - t1:.1f}s"
                )
                log.verbose(msg)
            del last_good
            del last_invcov
            del last_cov
            del last_rcond

            msg = f"{log_prefix} {obs.comm.group_rank} HWPSS Filter: at group barrier"
            log.verbose(msg)
            if obs.comm.comm_group is not None:
                obs.comm.comm_group.barrier()

        if wcomm is not None:
            self.nsingular = wcomm.allreduce(self.nsingular)
            self.ngood = wcomm.allreduce(self.ngood)
            self.rcondsum = wcomm.allreduce(self.rcondsum)

        if not self.reverse:
            denominator = self.nsingular + self.ngood
            if denominator == 0:
                log.debug_rank(
                    "HWPSS filter had no observations with a HWP", comm=wcomm
                )
            else:
                rcond_mean = self.rcondsum / denominator
                log.debug_rank(
                    f"Average rcond of template matrix was {rcond_mean}", comm=wcomm
                )

        return

    def _finalize(self, data, **kwargs):
        return

    def _requires(self):
        req = {
            "shared": list(),
            "detdata": [self.det_data],
        }
        if self.shared_flags is not None:
            req["shared"].append(self.shared_flags)
        if self.det_flags is not None:
            req["detdata"].append(self.det_flags)
        return req

    def _provides(self):
        return dict()
