# =====================================================
#   BRScript - Linguagem de programação em português
#   v4 — strings, listas, biblioteca padrão, importar
# =====================================================

import re, sys, os, math

# ──────────────────────────────────────────
# 1. TOKENS
# ──────────────────────────────────────────
TOKEN_TYPES = [
    ('NUMERO',    r'\d+(\.\d+)?'),
    ('TEXTO',     r'"[^"]*"'),
    ('MOSTRE',    r'\bmostre\b'),
    ('SE',        r'\bse\b'),
    ('ENTAO',     r'\bentão\b|\bentao\b'),
    ('SENAO',     r'\bsenão\b|\bsenao\b'),
    ('FIM',       r'\bfim\b'),
    ('ENQUANTO',  r'\benquanto\b'),
    ('FACA',      r'\bfaça\b|\bfaca\b'),
    ('PARA',      r'\bpara\b'),
    ('ATE',       r'\baté\b|\bate\b'),
    ('LEIA',      r'\bleia\b'),
    ('VAR',       r'\bvar\b'),
    ('FUNCAO',    r'\bfuncao\b|\bfunção\b'),
    ('RETORNE',   r'\bretorne\b'),
    ('IMPORTAR',  r'\bimportar\b'),
    ('PARAR',     r'\bparar\b'),
    ('COMO',      r'\bcomo\b'),
    ('CLASSE',    r'\bclasse\b'),
    ('HERDA',     r'\bherda\b'),
    ('NOVO',      r'\bnovo\b'),
    ('EU',        r'\beu\b'),
    ('TENTAR',    r'\btentar\b'),
    ('PEGAR',     r'\bpegar\b'),
    ('FINALMENTE',r'\bfinalmente\b'),
    ('LANCE',     r'\blance\b'),
    ('VERDADEIRO',r'\bverdadeiro\b'),
    ('FALSO',     r'\bfalso\b'),
    ('NULO',      r'\bnulo\b'),
    ('E',         r'\be\b'),
    ('OU',        r'\bou\b'),
    ('NAO',       r'\bnão\b|\bnao\b'),
    ('IGUAL',     r'=='),
    ('DIFERENTE', r'!='),
    ('MAIORIG',   r'>='),
    ('MENORIG',   r'<='),
    ('MAIOR',     r'>'),
    ('MENOR',     r'<'),
    ('ATRIB',     r'='),
    ('MAIS',      r'\+'),
    ('MENOS',     r'-'),
    ('VEZES',     r'\*'),
    ('DIVIDE',    r'/'),
    ('MODULO',    r'%'),
    ('LPAREN',    r'\('),
    ('RPAREN',    r'\)'),
    ('LCOLCH',    r'\['),
    ('RCOLCH',    r'\]'),
    ('LCHAVE',    r'\{'),
    ('RCHAVE',    r'\}'),
    ('DOISPONTOS',r':'),
    ('PONTO',     r'\.'),
    ('VIRGULA',   r','),
    ('NOME',      r'[a-záéíóúãõâêîôûàèìòùçüA-ZÁÉÍÓÚÃÕÂÊÎÔÛÀÈÌÒÙÇÜ_][a-záéíóúãõâêîôûàèìòùçüA-ZÁÉÍÓÚÃÕÂÊÎÔÛÀÈÌÒÙÇÜ0-9_]*'),
    ('NOVA_LINHA',r'\n'),
    ('ESPACO',    r'[ \t]+'),
    ('COMENTARIO',r'#[^\n]*'),
]

class Token:
    def __init__(self, tipo, valor, linha=0):
        self.tipo  = tipo
        self.valor = valor
        self.linha = linha
    def __repr__(self):
        return f'Token({self.tipo}, {self.valor!r}, L{self.linha})'

def tokenizar(codigo):
    tokens, pos, linha = [], 0, 1
    while pos < len(codigo):
        match = None
        for tipo, padrao in TOKEN_TYPES:
            m = re.compile(padrao, re.IGNORECASE).match(codigo, pos)
            if m:
                txt = m.group()
                if tipo == 'NOVA_LINHA':
                    tokens.append(Token(tipo, txt, linha)); linha += 1
                elif tipo not in ('ESPACO', 'COMENTARIO'):
                    tokens.append(Token(tipo, txt, linha))
                pos = m.end(); match = True; break
        if not match:
            raise ErroSintaxe(f"caractere desconhecido: '{codigo[pos]}'", linha)
    tokens.append(Token('EOF', None, linha))
    return tokens

# ──────────────────────────────────────────
# 2. ERROS E CONTROLE DE FLUXO
# ──────────────────────────────────────────
class ErroSintaxe(Exception):
    def __init__(self, msg, linha=None):
        self.msg = msg; self.linha = linha
    def __str__(self):
        return f"\n  ❌ Erro de sintaxe na linha {self.linha}: {self.msg}" if self.linha else f"\n  ❌ Erro de sintaxe: {self.msg}"

class ErroExecucao(Exception):
    def __init__(self, msg, linha=None):
        self.msg = msg; self.linha = linha
    def __str__(self):
        return f"\n  ❌ Erro na linha {self.linha}: {self.msg}" if self.linha else f"\n  ❌ Erro: {self.msg}"

class Retorno(Exception):
    def __init__(self, valor): self.valor = valor

class BRSModulo:
    def __init__(self, nome, variaveis, funcoes):
        self.nome      = nome
        self.variaveis = variaveis
        self.funcoes   = funcoes
    def __repr__(self): return f'<modulo {self.nome}>'
    def obter(self, chave):
        if chave in self.variaveis: return self.variaveis[chave]
        if chave in self.funcoes:   return self.funcoes[chave]
        return None

class BRSClasse:
    def __init__(self, nome, campos, metodos, pai=None):
        self.nome    = nome
        self.campos  = campos
        self.metodos = metodos
        self.pai     = pai  # classe pai para herança
    def __repr__(self): return f'<classe {self.nome}>'
    def buscar_metodo(self, nome):
        if nome in self.metodos: return self.metodos[nome]
        if self.pai: return self.pai.buscar_metodo(nome)
        return None
    def todos_campos(self):
        campos_pai = self.pai.todos_campos() if self.pai else []
        return campos_pai + [c for c in self.campos if c not in campos_pai]

class BRSInstancia:
    def __init__(self, classe):
        self.classe = classe
        self.attrs  = {}
    def __repr__(self): return f'<{self.classe.nome}>'


class ErroUsuario(Exception):
    def __init__(self, msg, linha=None):
        self.msg = msg; self.linha = linha
    def __str__(self):
        return f"\n  ❌ Erro na linha {self.linha}: {self.msg}" if self.linha else f"\n  ❌ Erro: {self.msg}" 

# ──────────────────────────────────────────
# 3. PARSER
# ──────────────────────────────────────────
class Parser:
    def __init__(self, tokens):
        self.tokens = tokens; self.pos = 0

    def atual(self): return self.tokens[self.pos]
    def peek(self, n=1): 
        i = self.pos + n
        return self.tokens[i] if i < len(self.tokens) else Token('EOF', None)

    def consumir(self, tipo=None):
        tok = self.tokens[self.pos]
        if tipo and tok.tipo != tipo:
            raise ErroSintaxe(f"esperava '{tipo.lower()}', mas encontrei '{tok.valor}'", tok.linha)
        self.pos += 1; return tok

    def pular_novas_linhas(self):
        while self.atual().tipo == 'NOVA_LINHA': self.consumir()

    def parse(self):
        stmts = []
        self.pular_novas_linhas()
        while self.atual().tipo != 'EOF':
            stmts.append(self.stmt()); self.pular_novas_linhas()
        return ('bloco', stmts)

    def stmt(self):
        tok = self.atual()
        if tok.tipo == 'VAR':        return self.decl_var()
        elif tok.tipo == 'MOSTRE':   return self.stmt_mostre()
        elif tok.tipo == 'LEIA':     return self.stmt_leia()
        elif tok.tipo == 'SE':       return self.stmt_se()
        elif tok.tipo == 'ENQUANTO': return self.stmt_enquanto()
        elif tok.tipo == 'PARA':     return self.stmt_para()
        elif tok.tipo == 'FUNCAO':   return self.stmt_funcao()
        elif tok.tipo == 'RETORNE':  return self.stmt_retorne()
        elif tok.tipo == 'IMPORTAR': return self.stmt_importar()
        elif tok.tipo == 'CLASSE':   return self.stmt_classe()
        elif tok.tipo == 'EU':       return self.stmt_nome()
        elif tok.tipo == 'TENTAR':   return self.stmt_tentar()
        elif tok.tipo == 'LANCE':    return self.stmt_lance()
        elif tok.tipo == 'PARAR':    return self.stmt_parar()
        elif tok.tipo == 'NOME':     return self.stmt_nome()
        else:
            raise ErroSintaxe(f"instrução desconhecida: '{tok.valor}'", tok.linha)

    def stmt_nome(self):
        # eu.campo = valor
        if self.atual().tipo == 'EU':
            tok = self.consumir('EU')
            self.consumir('PONTO')
            campo = self.consumir('NOME').valor
            if self.atual().tipo == 'LPAREN':
                self.consumir('LPAREN')
                args = self._args(); self.consumir('RPAREN')
                self.pular_novas_linhas()
                return ('eu_chamar_stmt', campo, args, tok.linha)
            self.consumir('ATRIB')
            expr = self.expressao()
            self.pular_novas_linhas()
            return ('eu_set', campo, expr, tok.linha)
        tok = self.atual()
        nome = self.consumir('NOME').valor

        # lista[i] = valor
        if self.atual().tipo == 'LCOLCH':
            self.consumir('LCOLCH')
            idx = self.expressao()
            self.consumir('RCOLCH')
            self.consumir('ATRIB')
            expr = self.expressao()
            self.pular_novas_linhas()
            return ('lista_set', nome, idx, expr, tok.linha)

        # nome.metodo(...)  ou  nome.campo
        if self.atual().tipo == 'PONTO':
            self.consumir('PONTO')
            campo = self.consumir('NOME').valor
            if self.atual().tipo == 'LPAREN':
                self.consumir('LPAREN')
                args = self._args()
                self.consumir('RPAREN')
                self.pular_novas_linhas()
                return ('metodo_stmt', nome, campo, args, tok.linha)
            # campo = valor
            self.consumir('ATRIB')
            expr = self.expressao()
            self.pular_novas_linhas()
            return ('campo_set', nome, campo, expr, tok.linha)

        # chamada normal
        if self.atual().tipo == 'LPAREN':
            self.consumir('LPAREN')
            args = self._args()
            self.consumir('RPAREN')
            self.pular_novas_linhas()
            return ('chamar_stmt', nome, args, tok.linha)

        # atribuição
        self.consumir('ATRIB')
        expr = self.expressao()
        self.pular_novas_linhas()
        return ('atrib', nome, expr, tok.linha)

    def _args(self):
        args = []
        if self.atual().tipo != 'RPAREN':
            args.append(self.expressao())
            while self.atual().tipo == 'VIRGULA':
                self.consumir('VIRGULA'); args.append(self.expressao())
        return args

    def decl_var(self):
        tok = self.consumir('VAR')
        nome = self.consumir('NOME').valor
        self.consumir('ATRIB')
        expr = self.expressao()
        self.pular_novas_linhas()
        return ('var', nome, expr, tok.linha)

    def stmt_mostre(self):
        tok = self.consumir('MOSTRE')
        args = [self.expressao()]
        while self.atual().tipo == 'VIRGULA':
            self.consumir('VIRGULA'); args.append(self.expressao())
        self.pular_novas_linhas()
        return ('mostre', args, tok.linha)

    def stmt_leia(self):
        tok = self.consumir('LEIA')
        nome = self.consumir('NOME').valor
        self.pular_novas_linhas()
        return ('leia', nome, tok.linha)

    def stmt_se(self):
        tok = self.consumir('SE')
        cond = self.expressao(); self.consumir('ENTAO'); self.pular_novas_linhas()
        corpo, senao = [], []
        while True:
            self.pular_novas_linhas()
            if self.atual().tipo in ('FIM', 'SENAO', 'EOF'): break
            corpo.append(self.stmt())
        if self.atual().tipo == 'SENAO':
            self.consumir('SENAO')
            while True:
                self.pular_novas_linhas()
                if self.atual().tipo in ('FIM', 'EOF'): break
                senao.append(self.stmt())
        self.consumir('FIM'); self.pular_novas_linhas()
        return ('se', cond, corpo, senao, tok.linha)

    def stmt_enquanto(self):
        tok = self.consumir('ENQUANTO')
        cond = self.expressao(); self.consumir('FACA')
        corpo = []
        while True:
            self.pular_novas_linhas()
            if self.atual().tipo in ('FIM', 'EOF'): break
            corpo.append(self.stmt())
        self.consumir('FIM'); self.pular_novas_linhas()
        return ('enquanto', cond, corpo, tok.linha)

    def stmt_para(self):
        tok = self.consumir('PARA')
        nome = self.consumir('NOME').valor; self.consumir('ATRIB')
        inicio = self.expressao(); self.consumir('ATE'); fim = self.expressao()
        self.consumir('FACA')
        corpo = []
        while True:
            self.pular_novas_linhas()
            if self.atual().tipo in ('FIM', 'EOF'): break
            corpo.append(self.stmt())
        self.consumir('FIM'); self.pular_novas_linhas()
        return ('para', nome, inicio, fim, corpo, tok.linha)

    def stmt_funcao(self):
        tok = self.consumir('FUNCAO')
        nome = self.consumir('NOME').valor; self.consumir('LPAREN')
        params = []
        if self.atual().tipo != 'RPAREN':
            params.append(self.consumir('NOME').valor)
            while self.atual().tipo == 'VIRGULA':
                self.consumir('VIRGULA'); params.append(self.consumir('NOME').valor)
        self.consumir('RPAREN'); self.pular_novas_linhas()
        corpo = []
        while True:
            self.pular_novas_linhas()
            if self.atual().tipo in ('FIM', 'EOF'): break
            corpo.append(self.stmt())
        self.consumir('FIM'); self.pular_novas_linhas()
        return ('funcao', nome, params, corpo, tok.linha)

    def stmt_retorne(self):
        tok = self.consumir('RETORNE')
        expr = self.expressao(); self.pular_novas_linhas()
        return ('retorne', expr, tok.linha)

    def stmt_importar(self):
        tok = self.consumir('IMPORTAR')
        arquivo = self.consumir('TEXTO').valor[1:-1]
        alias = None
        if self.atual().tipo == 'COMO':
            self.consumir('COMO')
            alias = self.consumir('NOME').valor
        self.pular_novas_linhas()
        return ('importar', arquivo, tok.linha, alias)

    def stmt_tentar(self):
        tok = self.consumir('TENTAR')
        self.pular_novas_linhas()
        corpo = []
        while True:
            self.pular_novas_linhas()
            if self.atual().tipo in ('PEGAR', 'FINALMENTE', 'FIM', 'EOF'): break
            corpo.append(self.stmt())
        # bloco pegar
        var_erro = None
        pegar = []
        if self.atual().tipo == 'PEGAR':
            self.consumir('PEGAR')
            if self.atual().tipo == 'NOME':
                var_erro = self.consumir('NOME').valor
            self.pular_novas_linhas()
            while True:
                self.pular_novas_linhas()
                if self.atual().tipo in ('FINALMENTE', 'FIM', 'EOF'): break
                pegar.append(self.stmt())
        # bloco finalmente
        finalmente = []
        if self.atual().tipo == 'FINALMENTE':
            self.consumir('FINALMENTE')
            self.pular_novas_linhas()
            while True:
                self.pular_novas_linhas()
                if self.atual().tipo in ('FIM', 'EOF'): break
                finalmente.append(self.stmt())
        self.consumir('FIM')
        self.pular_novas_linhas()
        return ('tentar', corpo, var_erro, pegar, finalmente, tok.linha)

    def stmt_classe(self):
        tok  = self.consumir('CLASSE')
        nome = self.consumir('NOME').valor
        # herança opcional: classe Filho herda Pai
        pai_nome = None
        if self.atual().tipo == 'HERDA':
            self.consumir('HERDA')
            pai_nome = self.consumir('NOME').valor
        self.pular_novas_linhas()
        campos  = []
        metodos = {}
        while True:
            self.pular_novas_linhas()
            if self.atual().tipo in ('FIM', 'EOF'): break
            if self.atual().tipo == 'FUNCAO':
                m = self.stmt_funcao()
                metodos[m[1]] = (m[2], m[3])
            elif self.atual().tipo == 'VAR':
                self.consumir('VAR')
                campos.append(self.consumir('NOME').valor)
                self.pular_novas_linhas()
            else:
                break
        self.consumir('FIM')
        self.pular_novas_linhas()
        return ('classe', nome, campos, metodos, pai_nome, tok.linha)

    def stmt_parar(self):
        tok = self.consumir('PARAR')
        self.pular_novas_linhas()
        return ('parar', tok.linha)

    def stmt_lance(self):
        tok = self.consumir('LANCE')
        msg = self.expressao()
        self.pular_novas_linhas()
        return ('lance', msg, tok.linha)

    # ── expressões ──
    def expressao(self): return self.expr_ou()

    def expr_ou(self):
        esq = self.expr_e()
        while self.atual().tipo == 'OU':
            self.consumir(); esq = ('ou', esq, self.expr_e())
        return esq

    def expr_e(self):
        esq = self.expr_nao()
        while self.atual().tipo == 'E':
            self.consumir(); esq = ('e', esq, self.expr_nao())
        return esq

    def expr_nao(self):
        if self.atual().tipo == 'NAO':
            self.consumir(); return ('nao', self.expr_comparacao())
        return self.expr_comparacao()

    def expr_comparacao(self):
        esq = self.expr_soma()
        ops = {'IGUAL':'==','DIFERENTE':'!=','MAIOR':'>','MENOR':'<','MAIORIG':'>=','MENORIG':'<='}
        while self.atual().tipo in ops:
            op = ops[self.consumir().tipo]; esq = ('binop', op, esq, self.expr_soma())
        return esq

    def expr_soma(self):
        esq = self.expr_mult()
        while self.atual().tipo in ('MAIS', 'MENOS'):
            op = '+' if self.consumir().tipo == 'MAIS' else '-'
            esq = ('binop', op, esq, self.expr_mult())
        return esq

    def expr_mult(self):
        esq = self.expr_unaria()
        while self.atual().tipo in ('VEZES', 'DIVIDE', 'MODULO'):
            t = self.consumir().tipo
            op = '*' if t == 'VEZES' else ('/' if t == 'DIVIDE' else '%')
            esq = ('binop', op, esq, self.expr_unaria())
        return esq

    def expr_unaria(self):
        if self.atual().tipo == 'MENOS':
            self.consumir(); return ('neg', self.expr_postfix())
        return self.expr_postfix()

    def expr_postfix(self):
        esq = self.expr_primaria()
        while True:
            if self.atual().tipo == 'LCOLCH':       # lista[i]
                tok = self.atual()
                self.consumir('LCOLCH')
                idx = self.expressao(); self.consumir('RCOLCH')
                esq = ('lista_get', esq, idx, tok.linha)
            elif self.atual().tipo == 'PONTO':      # obj.metodo()
                tok = self.atual()
                self.consumir('PONTO')
                campo = self.consumir('NOME').valor
                if self.atual().tipo == 'LPAREN':
                    self.consumir('LPAREN')
                    args = self._args(); self.consumir('RPAREN')
                    esq = ('metodo', esq, campo, args, tok.linha)
                else:
                    esq = ('campo', esq, campo, tok.linha)
            else:
                break
        return esq

    def expr_primaria(self):
        tok = self.atual()
        if tok.tipo == 'NUMERO':
            self.consumir(); v = tok.valor
            return ('num', float(v) if '.' in v else int(v))
        elif tok.tipo == 'TEXTO':
            self.consumir(); return ('texto', tok.valor[1:-1].replace('\\n', '\n').replace('\\t', '\t'))
        elif tok.tipo == 'VERDADEIRO':
            self.consumir(); return ('bool', True)
        elif tok.tipo == 'FALSO':
            self.consumir(); return ('bool', False)
        elif tok.tipo == 'NULO':
            self.consumir(); return ('nulo',)
        elif tok.tipo == 'LCOLCH':          # literal de lista [1,2,3]
            self.consumir('LCOLCH')
            itens = []
            if self.atual().tipo != 'RCOLCH':
                itens.append(self.expressao())
                while self.atual().tipo == 'VIRGULA':
                    self.consumir('VIRGULA'); itens.append(self.expressao())
            self.consumir('RCOLCH')
            return ('lista_lit', itens, tok.linha)
        elif tok.tipo == 'LCHAVE':          # literal de dicionário {"chave": valor}
            self.consumir('LCHAVE')
            pares = []
            self.pular_novas_linhas()
            if self.atual().tipo != 'RCHAVE':
                chave = self.expressao()
                self.consumir('DOISPONTOS')
                valor = self.expressao()
                pares.append((chave, valor))
                while self.atual().tipo == 'VIRGULA':
                    self.consumir('VIRGULA')
                    self.pular_novas_linhas()
                    if self.atual().tipo == 'RCHAVE': break
                    chave = self.expressao()
                    self.consumir('DOISPONTOS')
                    valor = self.expressao()
                    pares.append((chave, valor))
            self.pular_novas_linhas()
            self.consumir('RCHAVE')
            return ('dic_lit', pares, tok.linha)
        elif tok.tipo == 'NOVO':
            self.consumir('NOVO')
            nome = self.consumir('NOME').valor
            self.consumir('LPAREN')
            args = self._args(); self.consumir('RPAREN')
            return ('novo', nome, args, tok.linha)
        elif tok.tipo == 'EU':
            self.consumir()
            self.consumir('PONTO')
            campo = self.consumir('NOME').valor
            if self.atual().tipo == 'LPAREN':
                self.consumir('LPAREN')
                args = self._args(); self.consumir('RPAREN')
                return ('eu_chamar', campo, args, tok.linha)
            return ('eu_campo', campo, tok.linha)
        elif tok.tipo == 'NOME':
            nome = self.consumir().valor
            if self.atual().tipo == 'LPAREN':
                self.consumir('LPAREN')
                args = self._args(); self.consumir('RPAREN')
                return ('chamar', nome, args, tok.linha)
            return ('nome', nome, tok.linha)
        elif tok.tipo == 'LPAREN':
            self.consumir('LPAREN'); expr = self.expressao(); self.consumir('RPAREN')
            return expr
        else:
            raise ErroSintaxe(f"expressão inválida: '{tok.valor}'", tok.linha)

# ──────────────────────────────────────────
# 4. BIBLIOTECA PADRÃO
# ──────────────────────────────────────────
def _checar_lista(val, nome_func, linha):
    if not isinstance(val, list):
        raise ErroExecucao(f"'{nome_func}' espera uma lista", linha)

def _checar_texto(val, nome_func, linha):
    if not isinstance(val, str):
        raise ErroExecucao(f"'{nome_func}' espera um texto", linha)

BUILTINS = {
    # ── conversão ──
    'numero':    lambda args, l: (float(args[0]) if '.' in str(args[0]) else int(args[0])),
    'texto':     lambda args, l: str(args[0]),
    'logico':    lambda args, l: bool(args[0]),

    # ── matemática ──
    'arredondar': lambda args, l: round(args[0], int(args[1]) if len(args) > 1 else 0),
    'piso':      lambda args, l: math.floor(args[0]),
    'teto':      lambda args, l: math.ceil(args[0]),
    'absoluto':  lambda args, l: abs(args[0]),
    'raiz':      lambda args, l: math.sqrt(args[0]),
    'potencia':  lambda args, l: args[0] ** args[1],
    'aleatorio': lambda args, l: __import__('random').uniform(args[0], args[1]) if len(args)==2 else __import__('random').random(),
    'aleatorio_inteiro': lambda args, l: __import__('random').randint(int(args[0]), int(args[1])),
    'sen':       lambda args, l: math.sin(args[0]),
    'cos':       lambda args, l: math.cos(args[0]),
    'pi':        lambda args, l: math.pi,

    # ── texto ──
    'tamanho':   lambda args, l: len(args[0]),
    'maiusculo': lambda args, l: str(args[0]).upper(),
    'minusculo': lambda args, l: str(args[0]).lower(),
    'juntar':    lambda args, l: str(args[1]).join(str(x) for x in args[0]) if isinstance(args[0], list) else ''.join(str(a) for a in args),
    'dividir':   lambda args, l: str(args[0]).split(str(args[1])),
    'substituir':lambda args, l: str(args[0]).replace(str(args[1]), str(args[2])),
    'contem':    lambda args, l: str(args[1]) in str(args[0]),
    'comeca_com':lambda args, l: str(args[0]).startswith(str(args[1])),
    'termina_com':lambda args, l: str(args[0]).endswith(str(args[1])),
    'aparar':    lambda args, l: str(args[0]).strip(),
    'posicao':   lambda args, l: str(args[0]).find(str(args[1])),
    'fatia':     lambda args, l: str(args[0])[int(args[1]):int(args[2])] if len(args)==3 else str(args[0])[int(args[1]):],

    # ── listas ──
    'lista':     lambda args, l: list(args[0]) if args else [],
    'adicionar': lambda args, l: args[0].append(args[1]) or args[0],
    'remover':   lambda args, l: args[0].pop(int(args[1])) if len(args)>1 else args[0].pop(),
    'inserir':   lambda args, l: args[0].insert(int(args[1]), args[2]) or args[0],
    'ordenar':   lambda args, l: sorted(args[0]),
    'inverter':  lambda args, l: list(reversed(args[0])),
    'primeiro':  lambda args, l: args[0][0],
    'ultimo':    lambda args, l: args[0][-1],
    'fatia_lista':lambda args, l: args[0][int(args[1]):int(args[2])] if len(args)==3 else args[0][int(args[1]):],
    'em':        lambda args, l: args[1] in args[0],

    # ── I/O ──
    'escrever':  lambda args, l: print(*[str(a) for a in args], end='') or None,
    'linha':     lambda args, l: print(),
    'ler_linha': lambda args, l: input(str(args[0]) if args else ''),

    # ── rede HTTP ──
    'http_pegar':   lambda args, l: __import__('urllib.request', fromlist=['urlopen']).urlopen(str(args[0])).read().decode('utf-8'),
    'http_postar':  lambda args, l: __import__('urllib.request', fromlist=['urlopen', 'Request']).urlopen(
        __import__('urllib.request', fromlist=['Request']).Request(
            str(args[0]),
            data=str(args[1]).encode('utf-8') if len(args) > 1 else b'',
            headers={'Content-Type': 'application/json'} if len(args) > 1 else {}
        )
    ).read().decode('utf-8'),
    'http_status':  lambda args, l: __import__('urllib.request', fromlist=['urlopen']).urlopen(str(args[0])).status,
    'json_texto':   lambda args, l: __import__('json').dumps(args[0], ensure_ascii=False),
    'json_ler':     lambda args, l: __import__('json').loads(str(args[0])),

    # ── arquivos ──
    'arquivo_ler':      lambda args, l: open(str(args[0]), encoding='utf-8').read(),
    'arquivo_escrever': lambda args, l: open(str(args[0]), 'w', encoding='utf-8').write(str(args[1])) and None,
    'arquivo_adicionar':lambda args, l: open(str(args[0]), 'a', encoding='utf-8').write(str(args[1])) and None,
    'arquivo_linhas':   lambda args, l: open(str(args[0]), encoding='utf-8').read().splitlines(),
    'arquivo_existe':   lambda args, l: __import__('os').path.exists(str(args[0])),
    'arquivo_apagar':   lambda args, l: __import__('os').remove(str(args[0])) or None,
    'arquivo_renomear': lambda args, l: __import__('os').rename(str(args[0]), str(args[1])) or None,
    'pasta_listar':     lambda args, l: __import__('os').listdir(str(args[0]) if args else '.'),
    'pasta_criar':      lambda args, l: __import__('os').makedirs(str(args[0]), exist_ok=True) or None,
    'pasta_atual':      lambda args, l: __import__('os').getcwd(),

    # ── dicionários ──
    'chaves':    lambda args, l: list(args[0].keys())   if isinstance(args[0], dict) else (_ for _ in ()).throw(Exception("espera dicionário")),
    'valores':   lambda args, l: list(args[0].values()) if isinstance(args[0], dict) else (_ for _ in ()).throw(Exception("espera dicionário")),
    'tem_chave': lambda args, l: args[1] in args[0]     if isinstance(args[0], dict) else False,
    'remover_chave': lambda args, l: args[0].pop(args[1], None),
    'dicionario': lambda args, l: {},
}

# métodos em objetos (lista.adicionar, texto.tamanho, etc.)
METODOS_LISTA = {
    'adicionar': lambda obj, args, l: obj.append(args[0]) or obj,
    'remover':   lambda obj, args, l: obj.pop(int(args[0])) if args else obj.pop(),
    'tamanho':   lambda obj, args, l: len(obj),
    'ordenar':   lambda obj, args, l: sorted(obj),
    'inverter':  lambda obj, args, l: list(reversed(obj)),
    'contem':    lambda obj, args, l: args[0] in obj,
    'juntar':    lambda obj, args, l: str(args[0]).join(str(x) for x in obj),
}

METODOS_TEXTO = {
    'tamanho':    lambda obj, args, l: len(obj),
    'maiusculo':  lambda obj, args, l: obj.upper(),
    'minusculo':  lambda obj, args, l: obj.lower(),
    'dividir':    lambda obj, args, l: obj.split(str(args[0])),
    'substituir': lambda obj, args, l: obj.replace(str(args[0]), str(args[1])),
    'contem':     lambda obj, args, l: str(args[0]) in obj,
    'aparar':     lambda obj, args, l: obj.strip(),
    'comeca_com': lambda obj, args, l: obj.startswith(str(args[0])),
    'termina_com':lambda obj, args, l: obj.endswith(str(args[0])),
    'fatia':      lambda obj, args, l: obj[int(args[0]):int(args[1])] if len(args)==2 else obj[int(args[0]):],
    'posicao':    lambda obj, args, l: obj.find(str(args[0])),
}

METODOS_DIC = {
    'chaves':        lambda obj, args, l: list(obj.keys()),
    'valores':       lambda obj, args, l: list(obj.values()),
    'tem_chave':     lambda obj, args, l: args[0] in obj,
    'remover':       lambda obj, args, l: obj.pop(args[0], None),
    'tamanho':       lambda obj, args, l: len(obj),
}

# ──────────────────────────────────────────
# 5. INTERPRETADOR
# ──────────────────────────────────────────
class Interpretador:
    def __init__(self, arquivo_base=None):
        self.variaveis   = {}
        self.funcoes     = {}
        self.arquivo_base = arquivo_base or os.getcwd()

    def executar(self, no, escopo=None):
        if escopo is None: escopo = self.variaveis
        tipo = no[0]

        if tipo == 'bloco':
            for s in no[1]: self.executar(s, escopo)

        elif tipo in ('var', 'atrib'):
            linha = no[3] if len(no) > 3 else None
            escopo[no[1]] = self.avaliar(no[2], escopo, linha)

        elif tipo == 'mostre':
            linha = no[2] if len(no) > 2 else None
            partes = []
            for a in no[1]:
                v = self.avaliar(a, escopo, linha)
                partes.append(self._repr(v))
            print(' '.join(partes))

        elif tipo == 'leia':
            val = input()
            try:    val = int(val)
            except:
                try: val = float(val)
                except: pass
            escopo[no[1]] = val

        elif tipo == 'se':
            linha = no[4] if len(no) > 4 else None
            if self.avaliar(no[1], escopo, linha):
                for s in no[2]: self.executar(s, escopo)
            else:
                for s in no[3]: self.executar(s, escopo)

        elif tipo == 'enquanto':
            linha = no[3] if len(no) > 3 else None
            while self.avaliar(no[1], escopo, linha):
                for s in no[2]: self.executar(s, escopo)

        elif tipo == 'para':
            nome, ini, fim, corpo = no[1], no[2], no[3], no[4]
            linha = no[5] if len(no) > 5 else None
            i = self.avaliar(ini, escopo, linha)
            f = self.avaliar(fim, escopo, linha)
            while i <= f:
                escopo[nome] = i
                for s in corpo: self.executar(s, escopo)
                i += 1

        elif tipo == 'funcao':
            self.funcoes[no[1]] = (no[2], no[3])

        elif tipo == 'retorne':
            linha = no[2] if len(no) > 2 else None
            raise Retorno(self.avaliar(no[1], escopo, linha))

        elif tipo == 'chamar_stmt':
            linha = no[3] if len(no) > 3 else None
            self.chamar(no[1], no[2], escopo, linha)

        elif tipo == 'metodo_stmt':
            linha = no[4] if len(no) > 4 else None
            obj = escopo.get(no[1]) or self.variaveis.get(no[1])
            if obj is None:
                raise ErroExecucao(f"variável '{no[1]}' não declarada", linha)
            if isinstance(obj, BRSInstancia):
                self._chamar_metodo_inst(obj, no[2], no[3], escopo, linha)
            else:
                self._chamar_metodo(obj, no[2], no[3], escopo, linha)

        elif tipo == 'campo_set':
            linha = no[4] if len(no) > 4 else None
            obj = escopo.get(no[1]) or self.variaveis.get(no[1])
            if isinstance(obj, BRSInstancia):
                obj.attrs[no[2]] = self.avaliar(no[3], escopo, linha)
            elif isinstance(obj, dict):
                obj[no[2]] = self.avaliar(no[3], escopo, linha)
            else:
                raise ErroExecucao(f"'{no[1]}' não suporta atribuição de campo", linha)

        elif tipo == 'lista_set':
            linha = no[4] if len(no) > 4 else None
            lst = escopo.get(no[1]) or self.variaveis.get(no[1])
            if isinstance(lst, dict):
                chave = self.avaliar(no[2], escopo, linha)
                lst[chave] = self.avaliar(no[3], escopo, linha)
            elif isinstance(lst, list):
                idx = int(self.avaliar(no[2], escopo, linha))
                lst[idx] = self.avaliar(no[3], escopo, linha)
            else:
                raise ErroExecucao(f"'{no[1]}' não é uma lista ou dicionário", linha)

        elif tipo == 'importar':
            alias = no[3] if len(no) > 3 else None
            self._importar(no[1], no[2], alias, escopo)

        elif tipo == 'classe':
            nome, campos, metodos = no[1], no[2], no[3]
            pai_nome = no[4] if len(no) > 4 and isinstance(no[4], str) else None
            pai = None
            if pai_nome:
                pai_obj = self.funcoes.get(pai_nome)
                if not isinstance(pai_obj, BRSClasse):
                    linha = no[5] if len(no) > 5 else None
                    raise ErroExecucao(f"'{pai_nome}' não é uma classe", linha)
                pai = pai_obj
            self.funcoes[nome] = BRSClasse(nome, campos, metodos, pai)

        elif tipo == 'eu_set':
            inst = escopo.get('eu')
            if not isinstance(inst, BRSInstancia):
                raise ErroExecucao("'eu' só pode ser usado dentro de métodos", no[3] if len(no)>3 else None)
            inst.attrs[no[1]] = self.avaliar(no[2], escopo)

        elif tipo == 'eu_chamar_stmt':
            inst = escopo.get('eu')
            if not isinstance(inst, BRSInstancia):
                raise ErroExecucao("'eu' só pode ser usado dentro de métodos", no[3] if len(no)>3 else None)
            self._chamar_metodo_inst(inst, no[1], no[2], escopo, no[3] if len(no)>3 else None)


        elif tipo == 'parar':
            # ponto de parada — só age se depurador estiver ativo
            if getattr(self, '_debug_callback', None):
                self._debug_callback(no[1], escopo)

        elif tipo == 'lance':
            linha = no[2] if len(no) > 2 else None
            msg = self.avaliar(no[1], escopo, linha)
            raise ErroUsuario(str(msg), linha)

        elif tipo == 'tentar':
            _, corpo, var_erro, pegar, finalmente, linha = no
            try:
                for s in corpo: self.executar(s, escopo)
            except (ErroExecucao, ErroUsuario) as e:
                if pegar:
                    if var_erro:
                        escopo[var_erro] = e.msg
                    for s in pegar: self.executar(s, escopo)
            except Exception as e:
                if pegar:
                    if var_erro:
                        escopo[var_erro] = str(e)
                    for s in pegar: self.executar(s, escopo)
            finally:
                for s in finalmente: self.executar(s, escopo)

    def _repr(self, v):
        if isinstance(v, bool): return 'verdadeiro' if v else 'falso'
        if v is None: return 'nulo'
        if isinstance(v, list): return '[' + ', '.join(self._repr(x) for x in v) + ']'
        if isinstance(v, BRSInstancia):
            pares = ', '.join(f'{k}: {self._repr(val)}' for k, val in v.attrs.items())
            return f'<{v.classe.nome} {{{pares}}}>' 
        if isinstance(v, dict):
            pares = ', '.join(f'{self._repr(k)}: {self._repr(val)}' for k, val in v.items())
            return '{' + pares + '}'
        if isinstance(v, float) and v == int(v): return str(int(v))
        return str(v)

    def _chamar_metodo_inst(self, inst, nome_metodo, args_nos, escopo, linha):
        cls = inst.classe
        metodo = cls.buscar_metodo(nome_metodo)
        if metodo is None:
            raise ErroExecucao(f"'{cls.nome}' não tem método '{nome_metodo}'", linha)
        params, corpo = metodo
        if len(args_nos) != len(params):
            raise ErroExecucao(f"método '{nome_metodo}' esperava {len(params)} argumento(s)", linha)
        escopo_local = dict(self.variaveis)
        escopo_local['eu'] = inst
        for p, a in zip(params, args_nos):
            escopo_local[p] = self.avaliar(a, escopo, linha)
        try:
            for s in corpo: self.executar(s, escopo_local)
        except Retorno as r:
            return r.valor
        return None

    def _importar(self, arquivo, linha, alias=None, escopo_chamador=None):
        if escopo_chamador is None: escopo_chamador = self.variaveis
        caminho = os.path.join(self.arquivo_base, arquivo)
        if not os.path.exists(caminho):
            raise ErroExecucao(f"arquivo '{arquivo}' não encontrado", linha)
        with open(caminho, encoding='utf-8') as f:
            codigo = f.read()
        tokens = tokenizar(codigo)
        ast    = Parser(tokens).parse()
        sub    = Interpretador(os.path.dirname(os.path.abspath(caminho)))
        if alias:
            # modo namespace: executa em escopo isolado
            sub.variaveis = {}
            sub.funcoes   = {}
            sub.executar(ast)
            # cria objeto namespace com vars e funções do módulo
            ns = BRSModulo(alias, sub.variaveis, sub.funcoes)
            escopo_chamador[alias] = ns
            self.variaveis[alias]  = ns
        else:
            # modo antigo: injeta tudo no escopo global
            sub.variaveis = self.variaveis
            sub.funcoes   = self.funcoes
            sub.executar(ast)

    def chamar(self, nome, args_nos, escopo, linha=None):
        # funções do usuário têm prioridade sobre builtins
        if nome not in self.funcoes and nome in BUILTINS:
            args = [self.avaliar(a, escopo, linha) for a in args_nos]
            try: return BUILTINS[nome](args, linha)
            except ErroExecucao: raise
            except Exception as e: raise ErroExecucao(str(e), linha)
        if nome not in self.funcoes:
            raise ErroExecucao(f"função '{nome}' não foi declarada", linha)
        params, corpo = self.funcoes[nome]
        if len(args_nos) != len(params):
            raise ErroExecucao(f"função '{nome}' esperava {len(params)} argumento(s), recebeu {len(args_nos)}", linha)
        escopo_local = dict(self.variaveis)
        for p, a in zip(params, args_nos):
            escopo_local[p] = self.avaliar(a, escopo, linha)
        try:
            for s in corpo: self.executar(s, escopo_local)
        except Retorno as r:
            return r.valor
        except ErroUsuario:
            raise  # propaga para o tentar/pegar
        return None

    def _chamar_metodo(self, obj, campo, args_nos, escopo, linha):
        args = [self.avaliar(a, escopo, linha) for a in args_nos]
        if isinstance(obj, list):
            if campo not in METODOS_LISTA:
                raise ErroExecucao(f"lista não tem método '{campo}'", linha)
            return METODOS_LISTA[campo](obj, args, linha)
        if isinstance(obj, str):
            if campo not in METODOS_TEXTO:
                raise ErroExecucao(f"texto não tem método '{campo}'", linha)
            return METODOS_TEXTO[campo](obj, args, linha)
        if isinstance(obj, dict):
            if campo not in METODOS_DIC:
                raise ErroExecucao(f"dicionário não tem método '{campo}'", linha)
            return METODOS_DIC[campo](obj, args, linha)
        raise ErroExecucao(f"tipo sem métodos: '{type(obj).__name__}'", linha)

    def avaliar(self, no, escopo=None, linha=None):
        if escopo is None: escopo = self.variaveis
        tipo = no[0]

        if tipo == 'num':   return no[1]
        if tipo == 'texto': return no[1]
        if tipo == 'bool':  return no[1]
        if tipo == 'nulo':  return None
        if tipo == 'neg':   return -self.avaliar(no[1], escopo, linha)

        if tipo == 'lista_lit':
            return [self.avaliar(i, escopo, linha) for i in no[1]]

        if tipo == 'dic_lit':
            d = {}
            for chave_no, valor_no in no[1]:
                k = self.avaliar(chave_no, escopo, linha)
                v = self.avaliar(valor_no, escopo, linha)
                d[k] = v
            return d

        if tipo == 'lista_get':
            lst = self.avaliar(no[1], escopo, linha)
            l   = no[3] if len(no) > 3 else linha
            if isinstance(lst, dict):
                chave = self.avaliar(no[2], escopo, linha)
                if chave not in lst:
                    raise ErroExecucao(f"chave '{chave}' não existe no dicionário", l)
                return lst[chave]
            idx = int(self.avaliar(no[2], escopo, linha))
            if not isinstance(lst, (list, str)):
                raise ErroExecucao("índice só funciona em listas, textos e dicionários", l)
            try: return lst[idx]
            except IndexError: raise ErroExecucao(f"índice {idx} fora do limite", l)

        if tipo == 'nome':
            nome = no[1]; l = no[2] if len(no) > 2 else linha
            if nome in escopo:          return escopo[nome]
            if nome in self.variaveis:  return self.variaveis[nome]
            raise ErroExecucao(f"variável '{nome}' não foi declarada", l)

        if tipo == 'novo':
            l   = no[3] if len(no) > 3 else linha
            cls = self.funcoes.get(no[1])
            if not isinstance(cls, BRSClasse):
                raise ErroExecucao(f"'{no[1]}' não é uma classe", l)
            inst = BRSInstancia(cls)
            # inicializar todos os campos (próprios + herdados) como nulo
            for c in cls.todos_campos(): inst.attrs[c] = None
            # chamar iniciar se existir
            if 'iniciar' in cls.metodos:
                self._chamar_metodo_inst(inst, 'iniciar', no[2], escopo, l)
            return inst

        if tipo == 'eu_campo':
            inst = escopo.get('eu')
            if not isinstance(inst, BRSInstancia):
                raise ErroExecucao("'eu' só pode ser usado dentro de métodos", linha)
            campo = no[1]
            if campo not in inst.attrs:
                raise ErroExecucao(f"atributo '{campo}' não existe", linha)
            return inst.attrs[campo]

        if tipo == 'eu_chamar':
            inst = escopo.get('eu')
            if not isinstance(inst, BRSInstancia):
                raise ErroExecucao("'eu' só pode ser usado dentro de métodos", linha)
            return self._chamar_metodo_inst(inst, no[1], no[2], escopo, linha)

        if tipo == 'chamar':
            l = no[3] if len(no) > 3 else linha
            return self.chamar(no[1], no[2], escopo, l)

        if tipo == 'metodo':
            obj = self.avaliar(no[1], escopo, linha)
            l   = no[4] if len(no) > 4 else linha
            if isinstance(obj, BRSModulo):
                # modulo.funcao(args)
                fn = obj.funcoes.get(no[2])
                if fn is None:
                    raise ErroExecucao(f"módulo '{obj.nome}' não tem função '{no[2]}'", l)
                params, corpo = fn
                args = [self.avaliar(a, escopo, l) for a in no[3]]
                if len(args) != len(params):
                    raise ErroExecucao(f"função '{no[2]}' esperava {len(params)} argumento(s)", l)
                escopo_local = dict(obj.variaveis)
                for p, a in zip(params, args): escopo_local[p] = a
                interp_mod = Interpretador()
                interp_mod.variaveis = escopo_local
                interp_mod.funcoes   = obj.funcoes
                try:
                    for s in corpo: interp_mod.executar(s, escopo_local)
                except Retorno as r: return r.valor
                return None
            if isinstance(obj, BRSInstancia):
                return self._chamar_metodo_inst(obj, no[2], no[3], escopo, l)
            return self._chamar_metodo(obj, no[2], no[3], escopo, l)

        if tipo == 'campo':
            obj = self.avaliar(no[1], escopo, linha)
            l   = no[3] if len(no) > 3 else linha
            if isinstance(obj, BRSModulo):
                val = obj.obter(no[2])
                if val is None:
                    raise ErroExecucao(f"módulo '{obj.nome}' não tem '{no[2]}'", l)
                return val
            if isinstance(obj, BRSInstancia):
                if no[2] not in obj.attrs:
                    raise ErroExecucao(f"atributo '{no[2]}' não existe em '{obj.classe.nome}'", l)
                return obj.attrs[no[2]]
            if isinstance(obj, list) and no[2] == 'tamanho': return len(obj)
            if isinstance(obj, str)  and no[2] == 'tamanho': return len(obj)
            raise ErroExecucao(f"campo '{no[2]}' desconhecido", l)

        if tipo == 'binop':
            e = self.avaliar(no[2], escopo, linha)
            d = self.avaliar(no[3], escopo, linha)
            op = no[1]
            try:
                if op == '+':
                    if isinstance(e, list) and isinstance(d, list): return e + d
                    return e + d
                if op == '-':  return e - d
                if op == '*':  return e * d
                if op == '/':
                    if d == 0: raise ErroExecucao("divisão por zero", linha)
                    return e / d
                if op == '%':  return e % d
                if op == '==': return e == d
                if op == '!=': return e != d
                if op == '>':  return e > d
                if op == '<':  return e < d
                if op == '>=': return e >= d
                if op == '<=': return e <= d
            except ErroExecucao: raise
            except Exception as ex: raise ErroExecucao(str(ex), linha)

        if tipo == 'e':   return self.avaliar(no[1],escopo,linha) and self.avaliar(no[2],escopo,linha)
        if tipo == 'ou':  return self.avaliar(no[1],escopo,linha) or  self.avaliar(no[2],escopo,linha)
        if tipo == 'nao': return not self.avaliar(no[1],escopo,linha)

# ──────────────────────────────────────────
# 6. DEPURADOR
# ──────────────────────────────────────────
class Depurador:
    def __init__(self, codigo, arquivo=None):
        self.codigo       = codigo
        self.arquivo      = arquivo or "<repl>"
        self.linhas       = codigo.splitlines()
        self.breakpoints  = set()
        self.modo         = 'continuar'  # continuar | passo | parado
        self.interp       = Interpretador(os.path.dirname(os.path.abspath(arquivo)) if arquivo else os.getcwd())
        self.linha_atual  = 0

    def _mostrar_contexto(self, linha, escopo):
        print()
        print(f"  ┌─ Parado na linha {linha} ─────────────────")
        # mostrar 2 linhas antes e depois
        inicio = max(0, linha - 3)
        fim    = min(len(self.linhas), linha + 2)
        for i in range(inicio, fim):
            marcador = "→ " if i + 1 == linha else "  "
            print(f"  │ {marcador}{i+1:3}  {self.linhas[i]}")
        print(f"  └────────────────────────────────────────")
        print()

    def _prompt_debug(self, linha, escopo):
        self._mostrar_contexto(linha, escopo)
        print("  Comandos: [p]asso  [c]ontinuar  [v]ars  [f]uncs  [s]air  ou expressão BRScript")
        while True:
            try:
                cmd = input("  debug> ").strip()
            except (KeyboardInterrupt, EOFError):
                print(); return 'sair'

            if cmd in ('s', 'sair'):   return 'sair'
            if cmd in ('c', 'continuar'): self.modo = 'continuar'; return 'continuar'
            if cmd in ('p', 'passo'):  self.modo = 'passo'; return 'passo'

            if cmd in ('v', 'vars'):
                print()
                variaveis = {**self.interp.variaveis, **escopo}
                if variaveis:
                    for k, v in variaveis.items():
                        if k != 'eu':
                            print(f"    {k} = {self.interp._repr(v)}")
                else:
                    print("    Nenhuma variável ainda.")
                print(); continue

            if cmd in ('f', 'funcs'):
                print()
                for k, v in self.interp.funcoes.items():
                    if isinstance(v, BRSClasse):
                        print(f"    classe {k}")
                    elif isinstance(v, tuple):
                        print(f"    funcao {k}({', '.join(v[0])})")
                print(); continue

            if cmd.startswith('b '):
                try:
                    n = int(cmd[2:].strip())
                    self.breakpoints.add(n)
                    print(f"    Breakpoint adicionado na linha {n}")
                except: print("    Uso: b <numero_linha>")
                continue

            if cmd.startswith('rb '):
                try:
                    n = int(cmd[3:].strip())
                    self.breakpoints.discard(n)
                    print(f"    Breakpoint removido da linha {n}")
                except: print("    Uso: rb <numero_linha>")
                continue

            if cmd == 'breaks':
                if self.breakpoints:
                    print(f"    Breakpoints: {sorted(self.breakpoints)}")
                else:
                    print("    Nenhum breakpoint definido.")
                continue

            # executar expressão BRScript no contexto atual
            if cmd:
                try:
                    tokens = tokenizar(cmd)
                    ast    = Parser(tokens).parse()
                    sub    = Interpretador()
                    sub.variaveis = {**self.interp.variaveis, **escopo}
                    sub.funcoes   = self.interp.funcoes
                    sub.executar(ast)
                except Exception as e:
                    print(f"    {e}")
                continue

    def _executar_com_debug(self, no, escopo, linhas_codigo):
        """Executa um nó verificando breakpoints e modo passo a passo."""
        # pegar linha do nó
        linha_no = None
        if isinstance(no, tuple) and len(no) > 1:
            for campo in reversed(no):
                if isinstance(campo, int) and campo > 0:
                    linha_no = campo; break

        if linha_no and (self.modo == 'passo' or linha_no in self.breakpoints):
            acao = self._prompt_debug(linha_no, escopo)
            if acao == 'sair':
                raise SystemExit(0)

        # delegar execução normal
        self.interp.executar(no, escopo)

    def rodar(self):
        tokens = tokenizar(self.codigo)
        ast    = Parser(tokens).parse()
        # modo passo a passo começa parando no início
        self.modo = 'passo'
        print()
        print(f"  🐛 Depurador BRScript — {self.arquivo}")
        print(f"  {len(self.linhas)} linhas de código")
        print()
        print("  Comandos:")
        print("  [p] passo     — executa próxima instrução")
        print("  [c] continuar — roda até próximo breakpoint")
        print("  [b N]         — adiciona breakpoint na linha N")
        print("  [v] vars      — mostra variáveis")
        print("  [f] funcs     — mostra funções")
        print("  [s] sair      — encerra")
        print("  expressão     — avalia código BRScript")
        print()

        try:
            for stmt in ast[1]:
                self._executar_com_debug(stmt, self.interp.variaveis, self.linhas)
        except SystemExit:
            print("  Debug encerrado.")
        except (ErroSintaxe, ErroExecucao, ErroUsuario) as e:
            print(e)
        print()
        print("  ✅ Execução concluída.")

# ──────────────────────────────────────────
# 7. RODAR
# ──────────────────────────────────────────
def rodar(codigo, arquivo_base=None):
    tokens = tokenizar(codigo)
    ast    = Parser(tokens).parse()
    Interpretador(arquivo_base).executar(ast)

PALAVRAS_CHAVE = [
    'var','mostre','leia','se','entao','senao','fim','enquanto','faca',
    'para','ate','funcao','retorne','verdadeiro','falso','nulo','e','ou','nao',
    'classe','herda','novo','eu','tentar','pegar','finalmente','lance',
    'importar','como','maiusculo','minusculo','tamanho','dividir','juntar',
    'substituir','contem','aparar','fatia','arredondar','raiz','potencia',
    'piso','teto','pi','aleatorio','aleatorio_inteiro','absoluto','adicionar',
    'remover','ordenar','inverter','primeiro','ultimo','em','arquivo_ler',
    'arquivo_escrever','arquivo_adicionar','arquivo_linhas','arquivo_existe',
    'arquivo_apagar','pasta_listar','pasta_criar','pasta_atual',
    'http_pegar','http_postar','json_ler','json_texto','numero','texto','logico',
]

def _completar(t, estado):
    ops = [p for p in PALAVRAS_CHAVE if p.startswith(t)]
    return ops[estado] if estado < len(ops) else None

def modo_interativo():
    try:
        import readline, atexit, os as _os
        hist = _os.path.expanduser("~/.brs_historico")
        try: readline.read_history_file(hist)
        except FileNotFoundError: pass
        readline.set_history_length(500)
        atexit.register(readline.write_history_file, hist)
        readline.set_completer(_completar)
        readline.parse_and_bind("tab: complete")
        tem_rl = True
    except ImportError:
        tem_rl = False

    interp = Interpretador()
    buffer = []

    print()
    print("  ╔══════════════════════════════════════════╗")
    print("  ║     BRScript — Modo Interativo           ║")
    print("  ║     'ajuda' para comandos especiais      ║")
    if tem_rl:
        print("  ║     Tab: completar   ↑↓: histórico      ║")
    print("  ╚══════════════════════════════════════════╝")
    print()

    while True:
        try:
            linha = input(">>> " if not buffer else "... ")

            if linha.strip() == 'sair':
                print("  Até mais!"); break

            if linha.strip() == 'ajuda':
                print()
                print("  vars    — variáveis definidas")
                print("  funcs   — funções e classes definidas")
                print("  limpar  — limpa a tela")
                print("  sair    — encerra")
                print()
                continue

            if linha.strip() == 'vars':
                print()
                if interp.variaveis:
                    for k, v in interp.variaveis.items():
                        print(f"  {k} = {interp._repr(v)}")
                else:
                    print("  Nenhuma variável ainda.")
                print(); continue

            if linha.strip() == 'funcs':
                print()
                if interp.funcoes:
                    for k, v in interp.funcoes.items():
                        if isinstance(v, BRSClasse):
                            print(f"  classe {k}")
                        elif isinstance(v, tuple):
                            print(f"  funcao {k}({', '.join(v[0])})")
                else:
                    print("  Nenhuma função ainda.")
                print(); continue

            if linha.strip() == 'limpar':
                print("\033[2J\033[H", end="")
                buffer = []; continue

            buffer.append(linha)
            codigo = '\n'.join(buffer)

            try:
                tokens = tokenizar(codigo)
                ast    = Parser(tokens).parse()
                interp.executar(ast)
                buffer = []
            except ErroSintaxe as e:
                if 'EOF' in e.msg or 'fim' in e.msg.lower():
                    pass
                else:
                    print(e); buffer = []
            except (ErroExecucao, ErroUsuario) as e:
                print(e); buffer = []

        except KeyboardInterrupt:
            if buffer:
                print(); buffer = []
            else:
                print("\n  Até mais!"); break
        except EOFError:
            print("\n  Até mais!"); break
        except Exception as e:
            print(f"\n  ❌ Erro: {e}"); buffer = []

if __name__ == '__main__':
    args = sys.argv[1:]
    debug = '--debug' in args
    args  = [a for a in args if a != '--debug']

    if args:
        try:
            caminho = args[0]
            with open(caminho, encoding='utf-8') as f: codigo = f.read()
            if debug:
                dep = Depurador(codigo, os.path.abspath(caminho))
                dep.rodar()
            else:
                rodar(codigo, os.path.dirname(os.path.abspath(caminho)))
        except (ErroSintaxe, ErroExecucao) as e:
            print(e); sys.exit(1)
        except FileNotFoundError:
            print(f"\n  ❌ Arquivo '{args[0]}' não encontrado"); sys.exit(1)
    else:
        modo_interativo()
