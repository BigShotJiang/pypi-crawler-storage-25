import sys, os

def main():
    from brscript.linguagem_pt import rodar, modo_interativo, Depurador, ErroSintaxe, ErroExecucao
    args  = sys.argv[1:]
    debug = '--debug' in args
    args  = [a for a in args if a != '--debug']
    if args:
        try:
            caminho = args[0]
            with open(caminho, encoding='utf-8') as f: codigo = f.read()
            if debug:
                Depurador(codigo, os.path.abspath(caminho)).rodar()
            else:
                rodar(codigo, os.path.dirname(os.path.abspath(caminho)))
        except (ErroSintaxe, ErroExecucao) as e:
            print(e); sys.exit(1)
        except FileNotFoundError:
            print(f"\n  ❌ Arquivo '{args[0]}' não encontrado"); sys.exit(1)
    else:
        modo_interativo()

if __name__ == '__main__':
    main()
