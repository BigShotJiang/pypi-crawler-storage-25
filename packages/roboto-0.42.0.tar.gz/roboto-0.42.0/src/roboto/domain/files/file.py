# Copyright (c) 2024 Roboto Technologies, Inc.
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from __future__ import annotations

import collections.abc
import datetime
import pathlib
import typing
import urllib.parse

from ...association import Association
from ...fs import FileService
from ...http import BatchRequest, RobotoClient
from ...progress import (
    NoopProgressMonitor,
    TqdmProgressMonitor,
)
from ...query import QuerySpecification
from ...sentinels import (
    NotSet,
    NotSetType,
    remove_not_set,
)
from ...time import TimeUnit
from ...updates import MetadataChangeset
from ..topics import Topic
from .operations import (
    ImportFileRequest,
    RenameFileRequest,
    UpdateFileRecordRequest,
)
from .record import FileRecord, IngestionStatus

if typing.TYPE_CHECKING:
    import pandas  # pants: no-infer-dep


class File:
    """Represents a file within the Roboto platform.

    Files are the fundamental data storage unit in Roboto. They can be uploaded to datasets,
    imported from external sources, or created as outputs from actions. Once in the platform,
    files can be tagged with metadata, post-processed by actions, added to collections,
    visualized in the web interface, and searched using the query system.

    Files contain structured data that can be ingested into topics for analysis and visualization.
    Common file formats include ROS bags, MCAP files, ULOG files, CSV files, and many others.
    Each file has an associated ingestion status that tracks whether its data has been processed
    and made available for querying.

    Files are versioned entities - each modification creates a new version while preserving
    the history. Files are associated with datasets and inherit access permissions from their
    parent dataset.

    The File class provides methods for downloading, updating metadata, managing tags,
    accessing topics, and performing other file operations. It serves as the primary interface
    for file manipulation in the Roboto SDK.
    """

    __file_service: FileService
    __record: FileRecord
    __roboto_client: RobotoClient

    @classmethod
    def from_id(
        cls,
        file_id: str,
        version_id: typing.Optional[int] = None,
        roboto_client: typing.Optional[RobotoClient] = None,
    ) -> File:
        """Create a File instance from a file ID.

        Retrieves file information from the Roboto platform using the provided file ID
        and optionally a specific version.

        Args:
            file_id: Unique identifier for the file.
            version_id: Specific version of the file to retrieve. If None, gets the latest version.
            roboto_client: HTTP client for API communication. If None, uses the default client.

        Returns:
            File instance representing the requested file.

        Raises:
            RobotoNotFoundException: File with the given ID does not exist.
            RobotoUnauthorizedException: Caller lacks permission to access the file.

        Examples:
            >>> file = File.from_id("file_abc123")
            >>> print(file.relative_path)
            'data/sensor_logs.bag'

            >>> old_version = File.from_id("file_abc123", version_id=1)
            >>> print(old_version.version)
            1
        """
        roboto_client = RobotoClient.defaulted(roboto_client)
        record = roboto_client.get(
            f"v1/files/record/{file_id}",
            query={"version_id": version_id} if version_id is not None else None,
        ).to_record(FileRecord)
        return cls(record, roboto_client)

    @classmethod
    def from_path_and_dataset_id(
        cls,
        file_path: typing.Union[str, pathlib.Path],
        dataset_id: str,
        version_id: typing.Optional[int] = None,
        roboto_client: typing.Optional[RobotoClient] = None,
    ) -> File:
        """Create a File instance from a file path and dataset ID.

        Retrieves file information using the file's relative path within a specific dataset.
        This is useful when you know the file's location within a dataset but not its file ID.

        Args:
            file_path: Relative path of the file within the dataset.
            dataset_id: ID of the dataset containing the file.
            version_id: Specific version of the file to retrieve. If None, gets the latest version.
            roboto_client: HTTP client for API communication. If None, uses the default client.

        Returns:
            File instance representing the requested file.

        Raises:
            RobotoNotFoundException: File at the given path does not exist in the dataset.
            RobotoUnauthorizedException: Caller lacks permission to access the file or dataset.

        Examples:
            >>> file = File.from_path_and_dataset_id("logs/session1.bag", "ds_abc123")
            >>> print(file.file_id)
            'file_xyz789'

            >>> file = File.from_path_and_dataset_id(pathlib.Path("data/sensors.csv"), "ds_abc123")
            >>> print(file.relative_path)
            'data/sensors.csv'
        """
        roboto_client = RobotoClient.defaulted(roboto_client)
        url_quoted_file_path = urllib.parse.quote(str(file_path), safe="")
        record = roboto_client.get(
            f"v1/files/record/path/{url_quoted_file_path}/association/{dataset_id}",
            query={"version_id": version_id} if version_id is not None else None,
        ).to_record(FileRecord)
        return cls(record, roboto_client)

    @classmethod
    def import_batch(
        cls,
        requests: collections.abc.Sequence[ImportFileRequest],
        roboto_client: typing.Optional[RobotoClient] = None,
        caller_org_id: typing.Optional[str] = None,
    ) -> collections.abc.Sequence[File]:
        """Import files from customer S3 bring-your-own buckets into Roboto datasets.

        This is the ingress point for importing data stored in customer-owned S3 buckets
        that have been registered as read-only bring-your-own bucket (BYOB) integrations with
        Roboto. Files remain in their original S3 locations while metadata is registered with
        Roboto for discovery, processing, and analysis.

        This method only works with S3 URIs from buckets that have been properly registered
        as BYOB integrations for your organization. It performs batch operations to efficiently
        import multiple files in a single API call, reducing overhead and improving performance.

        Args:
            requests: Sequence of import requests, each specifying file details and metadata.
            roboto_client: HTTP client for API communication. If None, uses the default client.
            caller_org_id: Organization ID of the caller. Required for multi-org users.

        Returns:
            Sequence of File objects representing the imported files.

        Raises:
            RobotoInvalidRequestException: If any URI is not a valid S3 URI, if the batch
                exceeds 500 items, or if bucket integrations are not properly configured.
            RobotoUnauthorizedException: If the caller lacks upload permissions for target
                datasets or if buckets don't belong to the caller's organization.

        Notes:
            - Only works with S3 URIs from registered read-only BYOB integrations
            - Files are not copied; only metadata is imported into Roboto
            - Batch size is limited to 500 items per request
            - All S3 buckets must be registered to the caller's organization

        Examples:
            >>> from roboto.domain.files import ImportFileRequest
            >>> requests = [
            ...     ImportFileRequest(
            ...         dataset_id="ds_abc123",
            ...         relative_path="logs/session1.bag",
            ...         uri="s3://my-bucket/data/session1.bag",
            ...         size=1024000,
            ...     ),
            ...     ImportFileRequest(
            ...         dataset_id="ds_abc123",
            ...         relative_path="logs/session2.bag",
            ...         uri="s3://my-bucket/data/session2.bag",
            ...         size=2048000,
            ...     ),
            ... ]
            >>> files = File.import_batch(requests)
            >>> print(f"Imported {len(files)} files")
            Imported 2 files
        """
        roboto_client = RobotoClient.defaulted(roboto_client)

        # Requests explicitly need to be cast to list because of Pydantic serialization not working appropriately
        # with collections.abc
        request: BatchRequest[ImportFileRequest] = BatchRequest(requests=list(requests))

        records = roboto_client.post(
            "v1/files/import/batch",
            data=request,
            idempotent=True,
            caller_org_id=caller_org_id,
        ).to_record_list(FileRecord)
        return [cls(record, roboto_client) for record in records]

    @classmethod
    def import_one(
        cls,
        dataset_id: str,
        relative_path: str,
        uri: str,
        description: typing.Optional[str] = None,
        tags: typing.Optional[list[str]] = None,
        metadata: typing.Optional[dict[str, typing.Any]] = None,
        device_id: typing.Optional[str] = None,
        roboto_client: typing.Optional[RobotoClient] = None,
    ) -> File:
        """Import a single file from an external bucket into a Roboto dataset. This currently only supports AWS S3.

        This is a convenience method for importing a single file from customer-owned buckets
        that have been registered as bring-your-own bucket (BYOB) integrations with
        Roboto. Unlike :py:meth:`import_batch`, this method automatically determines the file size
        by querying the object store and verifies that the object actually exists before
        importing, providing additional validation and convenience for single-file operations.

        The file remains in its original location while metadata is registered with Roboto
        for discovery, processing, and analysis. This method currently only works with S3 URIs from buckets
        that have been properly registered as BYOB integrations for your organization.

        Args:
            dataset_id: ID of the dataset to import the file into.
            relative_path: Path of the file relative to the dataset root (e.g., `logs/session1.bag`).
            uri: URI where the file is located (e.g., `s3://my-bucket/path/to/file.bag`).
                Must be from a registered BYOB integration.
            description: Optional human-readable description of the file.
            tags: Optional list of tags for file discovery and organization.
            metadata: Optional key-value metadata pairs to associate with the file.
            device_id: Optional identifier of the device that generated this data.
            roboto_client: HTTP client for API communication. If None, uses the default client.

        Returns:
            File object representing the imported file.

        Raises:
            RobotoInvalidRequestException: If the URI is not a valid URI or if the bucket
                integration is not properly configured.
            RobotoNotFoundException: If the specified object does not exist.
            RobotoUnauthorizedException: If the caller lacks upload permissions for the target
                dataset or if the bucket doesn't belong to the caller's organization.

        Notes:
            - Only works with S3 URIs from registered BYOB integrations
            - File size is automatically determined from the object metadata
            - The file is not copied; only metadata is imported into Roboto
            - For importing multiple files efficiently, use :py:meth:`import_batch` instead

        Examples:
            Import a single ROS bag file:

            >>> from roboto.domain.files import File
            >>> file = File.import_one(
            ...     dataset_id="ds_abc123", relative_path="logs/session1.bag", uri="s3://my-bucket/data/session1.bag"
            ... )
            >>> print(f"Imported file: {file.relative_path}")
            Imported file: logs/session1.bag

            Import a file with metadata and tags:

            >>> file = File.import_one(
            ...     dataset_id="ds_abc123",
            ...     relative_path="sensors/lidar_data.pcd",
            ...     uri="s3://my-bucket/sensors/lidar_data.pcd",
            ...     description="LiDAR point cloud from highway test",
            ...     tags=["lidar", "highway", "test"],
            ...     metadata={"sensor_type": "Velodyne", "resolution": "high"},
            ... )
            >>> print(f"File size: {file.size} bytes")
        """
        roboto_client = RobotoClient.defaulted(roboto_client)
        request = ImportFileRequest(
            dataset_id=dataset_id,
            relative_path=relative_path,
            uri=uri,
            description=description,
            tags=tags,
            metadata=metadata,
            device_id=device_id,
        )
        record = roboto_client.post("v1/files/import", data=request).to_record(FileRecord)
        return cls(record, roboto_client)

    @classmethod
    def query(
        cls,
        spec: typing.Optional[QuerySpecification] = None,
        roboto_client: typing.Optional[RobotoClient] = None,
        owner_org_id: typing.Optional[str] = None,
    ) -> collections.abc.Generator[File, None, None]:
        """Query files using a specification with filters and pagination.

        Searches for files matching the provided query specification. Results are returned
        as a generator that automatically handles pagination, yielding File instances as
        they are retrieved from the API.

        Args:
            spec: Query specification with filters, sorting, and pagination options.
                If None, returns all accessible files.
            roboto_client: HTTP client for API communication. If None, uses the default client.
            owner_org_id: Organization ID to scope the query. If None, uses caller's org.

        Yields:
            File instances matching the query specification.

        Raises:
            ValueError: Query specification references unknown file attributes.
            RobotoUnauthorizedException: Caller lacks permission to query files.

        Examples:
            >>> from roboto.query import Comparator, Condition, QuerySpecification
            >>> spec = QuerySpecification(
            ...     condition=Condition(field="tags", comparator=Comparator.Contains, value="sensor-data")
            ... )
            >>> for file in File.query(spec):
            ...     print(f"Found file: {file.relative_path}")
            Found file: logs/sensors_2024_01_01.bag
            Found file: logs/sensors_2024_01_02.bag

            >>> # Query with metadata filter
            >>> spec = QuerySpecification(
            ...     condition=Condition(field="metadata.vehicle_id", comparator=Comparator.Equals, value="vehicle_001")
            ... )
            >>> files = list(File.query(spec))
            >>> print(f"Found {len(files)} files for vehicle_001")
        """
        roboto_client = RobotoClient.defaulted(roboto_client)
        spec = spec or QuerySpecification()

        known = set(FileRecord.model_fields.keys())
        actual = set()
        for field in spec.fields():
            # Support dot notation for nested fields
            # E.g., "metadata.SoftwareVersion"
            if "." in field:
                actual.add(field.split(".")[0])
            else:
                actual.add(field)
        unknown = actual - known
        if unknown:
            plural = len(unknown) > 1
            msg = "are not known attributes of File" if plural else "is not a known attribute of File"
            raise ValueError(f"{unknown} {msg}. Known attributes: {known}")

        while True:
            paginated_results = roboto_client.post(
                "v1/files/query", data=spec, owner_org_id=owner_org_id, idempotent=True
            ).to_paginated_list(FileRecord)

            for record in paginated_results.items:
                yield cls(record, roboto_client)

            if paginated_results.next_token:
                spec.after = paginated_results.next_token
            else:
                break

    def __init__(
        self,
        record: FileRecord,
        roboto_client: typing.Optional[RobotoClient] = None,
        file_service: typing.Optional[FileService] = None,
    ):
        self.__roboto_client = RobotoClient.defaulted(roboto_client)
        self.__file_service = file_service or FileService(self.__roboto_client)
        self.__record = record

    def __repr__(self) -> str:
        return self.__record.model_dump_json()

    @property
    def created(self) -> datetime.datetime:
        """Timestamp when this file was created.

        Returns the UTC datetime when this file was first uploaded or created
        in the Roboto platform. This timestamp is immutable.
        """
        return self.__record.created

    @property
    def created_by(self) -> str:
        """Identifier of the user who created this file.

        Returns the user ID or identifier of the person or service that originally
        uploaded or created this file in the Roboto platform.
        """
        return self.__record.created_by

    @property
    def dataset_id(self) -> str:
        """Identifier of the dataset that contains this file.

        Returns the unique identifier of the dataset that this file belongs to.
        Files are always associated with exactly one dataset.
        """
        return self.__record.association_id

    @property
    def description(self) -> typing.Optional[str]:
        """Human-readable description of this file.

        Returns the optional description text that provides details about the file's
        contents, purpose, or context. Can be None if no description was provided.
        """
        return self.__record.description

    @property
    def device_id(self) -> typing.Optional[str]:
        """Identifier of the device that generated this data.

        Returns the optional identifier of the device that generated the data
        contained within this file. Can be None if the file was not generated
        by a device.
        """
        return self.__record.device_id

    @property
    def file_id(self) -> str:
        """Unique identifier for this file.

        Returns the globally unique identifier assigned to this file when it was
        created. This ID is immutable and used to reference the file across the
        Roboto platform.
        """
        return self.__record.file_id

    @property
    def ingestion_status(self) -> IngestionStatus:
        """Current ingestion status of this file.

        Returns the status indicating whether this file has been processed and
        its data extracted into topics. Used to track ingestion pipeline progress.
        """
        return self.__record.ingestion_status

    @property
    def org_id(self) -> str:
        """Organization identifier that owns this file.

        Returns the unique identifier of the organization that owns and has
        primary access control over this file.
        """
        return self.__record.org_id

    @property
    def record(self) -> FileRecord:
        """Underlying data record for this file.

        Returns the raw :py:class:`~roboto.domain.files.FileRecord` that contains
        all the file's data fields. This provides access to the complete file
        state as stored in the platform.
        """
        return self.__record

    @property
    def relative_path(self) -> str:
        """Path of this file relative to its dataset root.

        Returns the file path within the dataset, using forward slashes as
        separators regardless of the operating system. This path uniquely
        identifies the file within its dataset.
        """
        return self.__record.relative_path

    @property
    def metadata(self) -> dict[str, typing.Any]:
        """Custom metadata associated with this file.

        Returns the file's metadata dictionary containing arbitrary key-value
        pairs for storing custom information. Supports nested structures and
        dot notation for accessing nested fields.
        """
        return self.__record.metadata

    @property
    def modified(self) -> datetime.datetime:
        """Timestamp when this file was last modified.

        Returns the UTC datetime when this file's metadata, tags, or other
        properties were most recently updated. The file content itself is
        immutable, but metadata can be modified.
        """
        return self.__record.modified

    @property
    def modified_by(self) -> str:
        """Identifier of the user who last modified this file.

        Returns the user ID or identifier of the person who most recently updated
        this file's metadata, tags, or other mutable properties.
        """
        return self.__record.modified_by

    @property
    def tags(self) -> list[str]:
        """List of tags associated with this file.

        Returns the list of string tags that have been applied to this file
        for categorization and filtering purposes.
        """
        return self.__record.tags

    @property
    def uri(self) -> str:
        """Storage URI for this file's content.

        Returns the storage location URI where the file's actual content is stored.
        This is typically an S3 URI or similar cloud storage reference.
        """
        return self.__record.uri

    @property
    def version(self) -> int:
        """Version number of this file.

        Returns the version number that increments each time the file's metadata
        or properties are updated. The file content itself is immutable, but
        metadata changes create new versions.
        """
        return self.__record.version

    def add_topic(
        self,
        topic_name: str,
        df: "pandas.DataFrame",
        timestamp_column: typing.Optional[str] = None,
        timestamp_unit: typing.Optional[typing.Union[str, TimeUnit]] = None,
    ) -> Topic:
        """Create a Topic from a pandas DataFrame and associate it with this file.

        If a topic with the same name already exists for this file, it will be updated
        with the new data and schema.

        Args:
            topic_name: Name for the topic. Must be unique within this file.
            df: pandas DataFrame containing the data to ingest. Must include a timestamp
                column (either explicitly specified or automatically detectable).
            timestamp_column: Name of the column to use as the timestamp. If not provided,
                the method will attempt to automatically detect a timestamp column by looking
                for the first column that is a timezone-aware timestamp type.
            timestamp_unit: Unit of the timestamp column values. Required when timestamp_column
                contains numeric values (int, float, decimal).
                Valid values include "s", "ms", "us", "ns".
                Not needed for datetime columns or when timestamp_column is not specified.

        Returns:
            The created or updated Topic instance.

        Raises:
            IngestionException: If the timestamp column cannot be determined, is not present
                in the DataFrame, has an invalid type, or if the timestamp unit is required
                but not provided.
            ImportError: If pandas or pyarrow are not installed. Install with
                ``pip install roboto[ingestion]`` to use this feature.
            RobotoUnauthorizedException: If the caller lacks permission to create topics
                or upload files to this file's dataset.

        Notes:
            - Requires installing this package using the ``roboto[ingestion]`` extra
            - Topic names are unique within a file
            - Schema and statistics are automatically inferred from the DataFrame

        Examples:
            Create a topic with explicit timestamp column and unit:

            >>> import pandas as pd
            >>> from roboto import File
            >>> file = File.from_id("file_abc123")
            >>> df = pd.DataFrame(
            ...     {
            ...         "timestamp": [1763947309.4198897, 1763947316.7686195, 1763947335.0095527],
            ...         "temperature": [20.5, 21.0, 20.8],
            ...         "humidity": [45.2, 46.1, 45.8],
            ...     }
            ... )
            >>> topic = file.add_topic(
            ...     topic_name="sensor_data", df=df, timestamp_column="timestamp", timestamp_unit="s"
            ... )
            >>> print(f"Created topic: {topic.name}")
            Created topic: sensor_data

            Create a topic with automatic timestamp detection:

            >>> import pandas as pd
            >>> from roboto import File
            >>> file = File.from_id("file_abc123")
            >>> df = pd.DataFrame(
            ...     {
            ...         "ts": pd.date_range("2025-11-24", periods=3, freq="1s", tz="UTC"),
            ...         "velocity": [10.5, 11.2, 10.8],
            ...         "acceleration": [0.5, 0.3, -0.2],
            ...     }
            ... )
            >>> topic = file.add_topic("motion_data", df)

            Retrieve the data back

            >>> retrieved_df = topic.get_data_as_df()
            >>> print(f"Retrieved {len(retrieved_df)} rows")
            Retrieved 3 rows

            Add derived data as a new topic to the same file, using the original topic's timestamp index:

            >>> import pandas as pd
            >>> from roboto import File
            >>> file = File.from_id("file_abc123")
            >>> # Get existing topic data as DataFrame
            >>> original_topic = file.get_topic("sensor_data")
            >>> original_df = original_topic.get_data_as_df()
            >>> # Create derived data
            >>> derived_df = pd.DataFrame(
            ...     {
            ...         "temp_category": original_df["temperature"].apply(lambda x: "hot" if x > 25 else "not_hot"),
            ...     },
            ...     index=original_df.index,
            ... )
            >>> derived_topic = file.add_topic(
            ...     "temperature_categories",
            ...     derived_df,
            ... )
        """
        return Topic.create_from_df(
            self.file_id,
            self.dataset_id,
            topic_name,
            df,
            timestamp_column=timestamp_column,
            timestamp_unit=timestamp_unit,
            caller_org_id=self.org_id,
            roboto_client=self.__roboto_client,
        )

    def delete(self) -> None:
        """Delete this file from the Roboto platform.

        Permanently removes the file and all its associated data, including topics
        and metadata. This operation cannot be undone.

        For files that were imported from customer S3 buckets (read-only BYOB
        integrations), this method does not delete the file content from S3. It
        only removes the metadata and references within the Roboto platform.

        Raises:
            RobotoNotFoundException: File does not exist or has already been deleted.
            RobotoUnauthorizedException: Caller lacks permission to delete the file.

        Examples:
            >>> file = File.from_id("file_abc123")
            >>> file.delete()
            # File is now permanently deleted
        """
        self.__roboto_client.delete(f"/v1/files/{self.file_id}")

    def download(
        self,
        local_path: pathlib.Path,
        print_progress: bool = True,
    ):
        """Download this file to a local path.

        Downloads the file content from cloud storage to the specified local path.
        The parent directories are created automatically if they don't exist.

        Args:
            local_path: Local filesystem path where the file should be saved.
            print_progress: Whether to show a progress bar during download.

        Raises:
            RobotoUnauthorizedException: Caller lacks permission to download the file.
            FileNotFoundError: File content is not available in storage.

        Examples:
            >>> import pathlib
            >>> file = File.from_id("file_abc123")
            >>> local_path = pathlib.Path("/tmp/downloaded_file.bag")
            >>> file.download(local_path)
            >>> print(f"Downloaded to {local_path}")
        """
        progress_monitor = (
            TqdmProgressMonitor(
                total=self.record.size,
                desc=f"Downloading {self.relative_path}",
            )
            if print_progress
            else NoopProgressMonitor()
        )

        with progress_monitor:
            self.__file_service.download(
                files=[
                    {"bucket_name": self.record.bucket, "source_uri": self.record.uri, "destination_path": local_path}
                ],
                association=Association.dataset(self.dataset_id),
                caller_org_id=self.org_id,
                on_progress=progress_monitor.update,
            )

    def get_signed_url(
        self,
        override_content_type: typing.Optional[str] = None,
        override_content_disposition: typing.Optional[str] = None,
    ) -> str:
        """Generate a signed URL for direct access to this file.

        Creates a time-limited URL that allows direct access to the file content
        without requiring Roboto authentication. Useful for sharing files or
        integrating with external systems.

        Args:
            override_content_type: Custom MIME type to set in the response headers.
            override_content_disposition: Custom content disposition header value
                (e.g., "attachment; filename=myfile.bag").

        Returns:
            Signed URL string that provides temporary access to the file.

        Raises:
            RobotoUnauthorizedException: Caller lacks permission to access the file.

        Examples:
            >>> file = File.from_id("file_abc123")
            >>> url = file.get_signed_url()
            >>> print(f"Direct access URL: {url}")

            >>> # Force download with custom filename
            >>> download_url = file.get_signed_url(override_content_disposition="attachment; filename=data.bag")
        """
        query_params: dict[str, str] = {}

        if override_content_disposition:
            query_params["override_content_disposition"] = override_content_disposition

        if override_content_type:
            query_params["override_content_type"] = override_content_type

        res = self.__roboto_client.get(
            f"v1/files/{self.file_id}/signed-url",
            query=query_params,
            owner_org_id=self.org_id,
        )
        return res.to_dict(json_path=["data", "url"])

    def get_topic(self, topic_name: str) -> Topic:
        """Get a specific topic from this file by name.

        Retrieves a topic with the specified name that is associated with this file.
        Topics contain the structured data extracted from the file during ingestion.

        Args:
            topic_name: Name of the topic to retrieve (e.g., "/camera/image", "/imu/data").

        Returns:
            Topic instance for the specified topic name.

        Raises:
            RobotoNotFoundException: Topic with the given name does not exist in this file.
            RobotoUnauthorizedException: Caller lacks permission to access the topic.

        Examples:
            >>> file = File.from_id("file_abc123")
            >>> camera_topic = file.get_topic("/camera/image")
            >>> print(f"Topic schema: {camera_topic.schema}")

            >>> # Access topic data
            >>> for record in camera_topic.get_data():
            ...     print(f"Timestamp: {record['timestamp']}")
        """
        return Topic.from_name_and_file(
            topic_name=topic_name,
            file_id=self.file_id,
            owner_org_id=self.org_id,
            roboto_client=self.__roboto_client,
        )

    def get_topics(
        self,
        include: typing.Optional[collections.abc.Sequence[str]] = None,
        exclude: typing.Optional[collections.abc.Sequence[str]] = None,
    ) -> collections.abc.Generator["Topic", None, None]:
        """Get all topics associated with this file, with optional filtering.

        Retrieves all topics that were extracted from this file during ingestion.
        Topics can be filtered by name using include/exclude patterns.

        Args:
            include: If provided, only topics with names in this sequence are yielded.
            exclude: If provided, topics with names in this sequence are skipped.

        Yields:
            Topic instances associated with this file, filtered according to the parameters.

        Examples:
            >>> file = File.from_id("file_abc123")
            >>> for topic in file.get_topics():
            ...     print(f"Topic: {topic.name}")
            Topic: /camera/image
            Topic: /imu/data
            Topic: /gps/fix

            >>> # Only get camera topics
            >>> camera_topics = list(file.get_topics(include=["/camera/image", "/camera/info"]))
            >>> print(f"Found {len(camera_topics)} camera topics")

            >>> # Exclude diagnostic topics
            >>> data_topics = list(file.get_topics(exclude=["/diagnostics"]))
        """
        for topic in Topic.get_by_file(
            owner_org_id=self.org_id,
            file_id=self.file_id,
            roboto_client=self.__roboto_client,
        ):
            if include is not None and topic.name not in include:
                continue

            if exclude is not None and topic.name in exclude:
                continue

            yield topic

    def mark_ingested(self) -> File:
        """Mark this file as fully ingested and ready for post-processing.

        Updates the file's ingestion status to indicate that all data has been
        successfully processed and extracted into topics. This enables triggers
        and other automated workflows that depend on complete ingestion.

        Returns:
            Updated File instance with ingestion status set to Ingested.

        Raises:
            RobotoUnauthorizedException: Caller lacks permission to update the file.

        Notes:
            This method is typically called by ingestion actions after they have
            successfully processed all data in the file. Once marked as ingested,
            the file becomes eligible for additional post-processing actions.

        Examples:
            >>> file = File.from_id("file_abc123")
            >>> print(file.ingestion_status)
            IngestionStatus.NotIngested
            >>> updated_file = file.mark_ingested()
            >>> print(updated_file.ingestion_status)
            IngestionStatus.Ingested
        """
        return self.update(ingestion_complete=True)

    def put_metadata(self, metadata: dict[str, typing.Any]) -> File:
        """Add or update metadata fields for this file.

        Adds new metadata fields or updates existing ones. Existing fields not
        specified in the metadata dict are preserved.

        Args:
            metadata: Dictionary of metadata key-value pairs to add or update.

        Returns:
            Updated File instance with the new metadata.

        Raises:
            RobotoUnauthorizedException: Caller lacks permission to update the file.

        Examples:
            >>> file = File.from_id("file_abc123")
            >>> updated_file = file.put_metadata(
            ...     {"vehicle_id": "vehicle_001", "session_type": "highway_driving", "weather": "sunny"}
            ... )
            >>> print(updated_file.metadata["vehicle_id"])
            'vehicle_001'
        """
        return self.update(metadata_changeset=MetadataChangeset(put_fields=metadata))

    def put_tags(self, tags: list[str]) -> File:
        """Add or update tags for this file.

        Replaces the file's current tags with the provided list. To add tags
        while preserving existing ones, retrieve current tags first and combine them.

        Args:
            tags: List of tag strings to set on the file.

        Returns:
            Updated File instance with the new tags.

        Raises:
            RobotoUnauthorizedException: Caller lacks permission to update the file.

        Examples:
            >>> file = File.from_id("file_abc123")
            >>> updated_file = file.put_tags(["sensor-data", "highway", "sunny"])
            >>> print(updated_file.tags)
            ['sensor-data', 'highway', 'sunny']
        """
        return self.update(metadata_changeset=MetadataChangeset(put_tags=tags))

    def refresh(self) -> File:
        """Refresh this file instance with the latest data from the platform.

        Fetches the current state of the file from the Roboto platform and updates
        this instance's data. Useful when the file may have been modified by other
        processes or users.

        Returns:
            This File instance with refreshed data.

        Raises:
            RobotoNotFoundException: File no longer exists.
            RobotoUnauthorizedException: Caller lacks permission to access the file.

        Examples:
            >>> file = File.from_id("file_abc123")
            >>> # File may have been updated by another process
            >>> refreshed_file = file.refresh()
            >>> print(f"Current version: {refreshed_file.version}")
        """
        self.__record = self.__roboto_client.get(f"v1/files/record/{self.file_id}").to_record(FileRecord)
        return self

    def rename_file(self, file_id: str, new_path: str) -> FileRecord:
        """Rename this file to a new path within its dataset.

        Changes the relative path of the file within its dataset. This updates
        the file's location identifier but does not move the actual file content.

        Args:
            file_id: File ID (currently unused, kept for API compatibility).
            new_path: New relative path for the file within the dataset.

        Returns:
            Updated FileRecord with the new path.

        Raises:
            RobotoUnauthorizedException: Caller lacks permission to rename the file.
            RobotoInvalidRequestException: New path is invalid or conflicts with existing file.

        Examples:
            >>> file = File.from_id("file_abc123")
            >>> print(file.relative_path)
            'old_logs/session1.bag'
            >>> updated_record = file.rename_file("file_abc123", "logs/session1.bag")
            >>> print(updated_record.relative_path)
            'logs/session1.bag'
        """
        response = self.__roboto_client.put(
            f"v1/files/{self.file_id}/rename",
            data=RenameFileRequest(
                association_id=self.dataset_id,
                new_path=new_path,
            ),
        )

        return response.to_record(FileRecord)

    def set_device_id(self, device_id: str) -> File:
        """Set the device ID for this file.

        Args:
            device_id: The device ID to set for this file.

        Returns:
            Updated File instance with the new device ID.

        Raises:
            RobotoUnauthorizedException: Caller lacks permission to update the file.
            RobotoDeviceNotFoundException: The specified device ID does not exist.

        Examples:
            >>> file = File.from_id("file_abc123")
            >>> updated_file = file.set_device_id("device_xyz789")
        """
        return self.update(device_id=device_id)

    def to_association(self) -> Association:
        """Convert this file to an Association reference.

        Creates an Association object that can be used to reference this file
        in other contexts, such as when creating collections or specifying
        action inputs.

        Returns:
            Association object referencing this file and its current version.

        Examples:
            >>> file = File.from_id("file_abc123")
            >>> association = file.to_association()
            >>> print(f"Association: {association.association_type}:{association.association_id}")
            Association: file:file_abc123
        """
        return Association.file(self.file_id, self.version)

    def to_dict(self) -> dict[str, typing.Any]:
        """Convert this file to a dictionary representation.

        Returns the file's data as a JSON-serializable dictionary containing
        all file attributes and metadata.

        Returns:
            Dictionary representation of the file data.

        Examples:
            >>> file = File.from_id("file_abc123")
            >>> file_dict = file.to_dict()
            >>> print(file_dict["relative_path"])
            'logs/session1.bag'
            >>> print(file_dict["metadata"])
            {'vehicle_id': 'vehicle_001', 'session_type': 'highway'}
        """
        return self.__record.model_dump(mode="json")

    def update(
        self,
        description: typing.Optional[typing.Union[str, NotSetType]] = NotSet,
        metadata_changeset: typing.Union[MetadataChangeset, NotSetType] = NotSet,
        ingestion_complete: typing.Union[typing.Literal[True], NotSetType] = NotSet,
        device_id: typing.Optional[typing.Union[str, NotSetType]] = NotSet,
    ) -> File:
        """Update this file's properties.

        Updates various properties of the file including description, metadata,
        and ingestion status. Only specified parameters are updated; others
        remain unchanged.

        Args:
            description: New description for the file. Use NotSet to leave unchanged.
            metadata_changeset: Metadata changes to apply (add, update, or remove fields/tags).
                Use NotSet to leave metadata unchanged.
            ingestion_complete: Set to True to mark the file as fully ingested.
                Use NotSet to leave ingestion status unchanged.
            device_id: New device ID for the file. Use NotSet to leave unchanged.

        Returns:
            Updated File instance with the new properties.

        Raises:
            RobotoUnauthorizedException: Caller lacks permission to update the file.

        Examples:
            >>> file = File.from_id("file_abc123")
            >>> updated_file = file.update(description="Updated sensor data from highway test")
            >>> print(updated_file.description)
            'Updated sensor data from highway test'

            >>> # Update metadata and mark as ingested
            >>> from roboto.updates import MetadataChangeset
            >>> changeset = MetadataChangeset(put_fields={"processed": True})
            >>> updated_file = file.update(metadata_changeset=changeset, ingestion_complete=True)
        """
        request = remove_not_set(
            UpdateFileRecordRequest(
                description=description,
                metadata_changeset=metadata_changeset,
                ingestion_complete=ingestion_complete,
                device_id=device_id,
            )
        )
        self.__record = self.__roboto_client.put(f"v1/files/record/{self.file_id}", data=request).to_record(FileRecord)
        return self
