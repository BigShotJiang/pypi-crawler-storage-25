# Copyright (c) 2025 Roboto Technologies, Inc.
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from typing import Any, Optional

import pydantic

from ...compat import StrEnum
from ..core import (
    AnalysisScope,
    RobotoLLMContext,
)
from ..core.record import (
    AgentContent,
    AgentContentType,
    AgentErrorContent,
    AgentMessage,
    AgentMessageStatus,
    AgentRole,
    AgentSessionDelta,
    AgentSessionRecord,
    AgentSessionStatus,
    AgentTextContent,
    AgentToolResultContent,
    AgentToolUseContent,
    ClientToolSpec,
)


class AgentToolDetailResponse(pydantic.BaseModel):
    """Unsanitized tool request and response details for an agent tool invocation."""

    tool_use: AgentToolUseContent
    tool_result: AgentToolResultContent


class SendMessageRequest(pydantic.BaseModel):
    """Request payload for sending a message to an agent session.

    Contains the message content and optional context for the AI assistant.
    """

    context: Optional[RobotoLLMContext] = None
    """Optional context to include with the message."""

    message: AgentMessage
    """Message content to send."""

    client_tools: Optional[list[ClientToolSpec]] = None
    """Optional client-side tools available for this invocation."""

    analysis_scope: Optional[AnalysisScope] = None
    """Optional replacement analysis scope. When provided, overwrites the session's current analysis scope; the new
    scope takes effect for this turn's tool invocations and every turn thereafter. When ``None``, the session's
    existing analysis scope is left untouched (there is currently no wire-format way to clear a scope via ``send``)."""


class StartAgentSessionRequest(pydantic.BaseModel):
    """Request payload for starting a new agent session.

    Contains the initial messages and configuration for creating a new
    conversation.
    """

    context: Optional[RobotoLLMContext] = None
    """Optional context to include with the message."""

    messages: list[AgentMessage]
    """Initial messages to start the conversation with."""

    system_prompt: Optional[str] = None
    """Optional system prompt to customize AI assistant behavior."""

    client_tools: Optional[list[ClientToolSpec]] = None
    """Optional client-side tools available for this invocation."""

    model_profile: Optional[str] = None
    """Optional model profile ID for the session (e.g. 'standard', 'advanced')."""

    analysis_scope: Optional[AnalysisScope] = None
    """Optional analysis scope for the session. Delivered to every tool invocation on the server side; individual
    tools opt in to honoring it. ``None`` means no scope."""


class ClientToolResultStatus(StrEnum):
    """Outcome of executing a client-side tool."""

    SUCCESS = "success"
    ERROR = "error"
    DECLINED = "declined"


class ClientToolResult(pydantic.BaseModel):
    """Result of executing a client-side tool."""

    tool_use_id: str
    """Identifier of the tool invocation this result corresponds to."""

    tool_name: str
    """Name of the tool that was executed."""

    runtime_ms: int
    """Wall-clock execution time of the tool in milliseconds."""

    status: ClientToolResultStatus
    """Outcome of the tool execution."""

    output: Optional[dict[str, Any]] = None
    """Structured output returned by the tool."""


class SubmitToolResultsRequest(pydantic.BaseModel):
    """Request payload for submitting client-side tool execution results."""

    tool_results: list[ClientToolResult]
    """Tool results from client-side execution."""

    client_tools: Optional[list[ClientToolSpec]] = None
    """Optional updated client-side tools for the next invocation."""


__all__ = [
    "AgentContent",
    "AgentContentType",
    "AgentErrorContent",
    "AgentMessage",
    "AgentMessageStatus",
    "AgentRole",
    "AgentSessionDelta",
    "AgentSessionRecord",
    "AgentSessionStatus",
    "AgentTextContent",
    "AgentToolDetailResponse",
    "AgentToolResultContent",
    "AgentToolUseContent",
    "ClientToolResult",
    "ClientToolResultStatus",
    "ClientToolSpec",
    "SendMessageRequest",
    "StartAgentSessionRequest",
    "SubmitToolResultsRequest",
]
