"""Tests for the Lemon Squeezy license system."""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import yaml

from hiveframe.license import (
    License,
    LicenseResult,
    _clear_cache,
    _read_cache,
    _write_cache,
    clear_license_config,
    load_license_config,
    load_license_key,
    require_pro,
    write_license_config,
)

_KEY = "TEST-KEY-XXXXXXXX-XXXX-XXXX-XXXX"
_INSTANCE_ID = "instance-uuid-abc123"

# ---------------------------------------------------------------------------
# Mock helpers
# ---------------------------------------------------------------------------

def _mock_validate_resp(valid=True, product_id=1009925, expires_at=None, error=None):
    m = MagicMock()
    m.json.return_value = {
        "valid": valid,
        "error": error,
        "license_key": {"expires_at": expires_at},
        "meta": {
            "product_id": product_id,
            "instance_id": _INSTANCE_ID,
        },
    }
    return m


def _mock_activate_resp(activated=True, product_id=1009925, expires_at=None, error=None):
    m = MagicMock()
    m.json.return_value = {
        "activated": activated,
        "error": error,
        "license_key": {"expires_at": expires_at},
        "instance": {"id": _INSTANCE_ID, "name": "hiveframe-cli"},
        "meta": {"product_id": product_id},
    }
    return m


def _mock_deactivate_resp(deactivated=True):
    m = MagicMock()
    m.json.return_value = {"deactivated": deactivated, "error": None}
    return m


# ---------------------------------------------------------------------------
# Config I/O
# ---------------------------------------------------------------------------

class TestLoadLicenseConfig:
    def test_returns_none_none_when_no_config(self, tmp_path, monkeypatch):
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", tmp_path / "config.yaml")
        assert load_license_config() == (None, None)

    def test_returns_key_and_instance_id(self, tmp_path, monkeypatch):
        cfg = tmp_path / "config.yaml"
        cfg.write_text(
            yaml.safe_dump({"license_key": _KEY, "license_instance_id": _INSTANCE_ID}),
            encoding="utf-8",
        )
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        assert load_license_config() == (_KEY, _INSTANCE_ID)

    def test_returns_none_none_when_keys_absent(self, tmp_path, monkeypatch):
        cfg = tmp_path / "config.yaml"
        cfg.write_text(yaml.safe_dump({"nodes": []}), encoding="utf-8")
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        assert load_license_config() == (None, None)


class TestWriteLicenseConfig:
    def test_creates_config_with_both_fields(self, tmp_path, monkeypatch):
        cfg = tmp_path / "config.yaml"
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        write_license_config(_KEY, _INSTANCE_ID)
        data = yaml.safe_load(cfg.read_text())
        assert data["license_key"] == _KEY
        assert data["license_instance_id"] == _INSTANCE_ID

    def test_preserves_existing_settings(self, tmp_path, monkeypatch):
        cfg = tmp_path / "config.yaml"
        cfg.write_text(yaml.safe_dump({"nodes": [{"name": "pve"}]}), encoding="utf-8")
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        write_license_config(_KEY, _INSTANCE_ID)
        data = yaml.safe_load(cfg.read_text())
        assert "nodes" in data
        assert data["license_key"] == _KEY

    def test_passing_none_removes_fields(self, tmp_path, monkeypatch):
        cfg = tmp_path / "config.yaml"
        cfg.write_text(
            yaml.safe_dump({"license_key": _KEY, "license_instance_id": _INSTANCE_ID}),
            encoding="utf-8",
        )
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        write_license_config(None, None)
        data = yaml.safe_load(cfg.read_text()) or {}
        assert "license_key" not in data
        assert "license_instance_id" not in data

    def test_clear_removes_both_fields(self, tmp_path, monkeypatch):
        cfg = tmp_path / "config.yaml"
        cfg.write_text(
            yaml.safe_dump({"license_key": _KEY, "license_instance_id": _INSTANCE_ID}),
            encoding="utf-8",
        )
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        clear_license_config()
        data = yaml.safe_load(cfg.read_text()) or {}
        assert "license_key" not in data
        assert "license_instance_id" not in data

    def test_load_license_key_compat(self, tmp_path, monkeypatch):
        cfg = tmp_path / "config.yaml"
        cfg.write_text(yaml.safe_dump({"license_key": _KEY}), encoding="utf-8")
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        assert load_license_key() == _KEY


# ---------------------------------------------------------------------------
# Cache
# ---------------------------------------------------------------------------

class TestCache:
    def _fresh_data(self, tier="pro", valid=True):
        return {
            "valid": valid,
            "tier": tier,
            "expires_at": None,
            "message": "Pro license active",
            "cached_at": datetime.now(timezone.utc).isoformat(),
        }

    def _stale_data(self, tier="pro", valid=True):
        stale_at = datetime.now(timezone.utc) - timedelta(hours=25)
        return {
            "valid": valid,
            "tier": tier,
            "expires_at": None,
            "message": "Pro license active",
            "cached_at": stale_at.isoformat(),
        }

    def test_read_cache_returns_none_when_absent(self, tmp_path, monkeypatch):
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", tmp_path / ".cache.json")
        assert _read_cache() is None

    def test_read_cache_returns_data_when_fresh(self, tmp_path, monkeypatch):
        cache = tmp_path / ".cache.json"
        cache.write_text(json.dumps(self._fresh_data()), encoding="utf-8")
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", cache)
        assert _read_cache() is not None

    def test_read_cache_returns_none_when_stale(self, tmp_path, monkeypatch):
        cache = tmp_path / ".cache.json"
        cache.write_text(json.dumps(self._stale_data()), encoding="utf-8")
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", cache)
        assert _read_cache() is None

    def test_read_cache_allow_stale_returns_expired_data(self, tmp_path, monkeypatch):
        cache = tmp_path / ".cache.json"
        cache.write_text(json.dumps(self._stale_data()), encoding="utf-8")
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", cache)
        assert _read_cache(allow_stale=True) is not None

    def test_write_then_read_roundtrip(self, tmp_path, monkeypatch):
        cache = tmp_path / ".cache.json"
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", cache)
        result = LicenseResult(
            valid=True, tier="pro",
            license_key=_KEY, instance_id=_INSTANCE_ID,
            expires_at="2027-04-27T00:00:00Z",
            message="Pro license active",
        )
        _write_cache(result)
        data = _read_cache()
        assert data is not None
        assert data["tier"] == "pro"
        assert data["expires_at"] == "2027-04-27T00:00:00Z"

    def test_clear_cache_removes_file(self, tmp_path, monkeypatch):
        cache = tmp_path / ".cache.json"
        cache.write_text(json.dumps(self._fresh_data()), encoding="utf-8")
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", cache)
        _clear_cache()
        assert not cache.exists()


# ---------------------------------------------------------------------------
# License.validate()
# ---------------------------------------------------------------------------

class TestLicenseValidate:
    def test_no_key_returns_free_no_api_call(self, tmp_path, monkeypatch):
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", tmp_path / ".cache.json")
        with patch("httpx.post") as mock_post:
            result = License(None).validate()
        mock_post.assert_not_called()
        assert result.tier == "free"
        assert result.valid is True

    def test_valid_ls_validate_response_returns_pro(self, tmp_path, monkeypatch):
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", tmp_path / ".cache.json")
        with patch("httpx.post", return_value=_mock_validate_resp()) as mock_post:
            result = License(_KEY, _INSTANCE_ID).validate()
        mock_post.assert_called_once()
        assert result.tier == "pro"
        assert result.valid is True

    def test_invalid_ls_response_returns_free(self, tmp_path, monkeypatch):
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", tmp_path / ".cache.json")
        with patch("httpx.post", return_value=_mock_validate_resp(valid=False, error="Disabled")):
            result = License(_KEY, _INSTANCE_ID).validate()
        assert result.tier == "free"
        assert result.valid is False
        assert "Disabled" in result.message

    def test_wrong_product_id_returns_free(self, tmp_path, monkeypatch):
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", tmp_path / ".cache.json")
        with patch("httpx.post", return_value=_mock_validate_resp(product_id=9999)):
            result = License(_KEY, _INSTANCE_ID).validate()
        assert result.tier == "free"
        assert "product" in result.message.lower()

    def test_cache_hit_skips_api_call(self, tmp_path, monkeypatch):
        cache = tmp_path / ".cache.json"
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", cache)
        # Write a fresh cache
        _write_cache(LicenseResult(
            valid=True, tier="pro",
            license_key=_KEY, instance_id=_INSTANCE_ID,
            expires_at=None, message="Pro license active",
        ))
        with patch("httpx.post") as mock_post:
            result = License(_KEY, _INSTANCE_ID).validate()
        mock_post.assert_not_called()
        assert result.tier == "pro"

    def test_stale_cache_triggers_api_call(self, tmp_path, monkeypatch):
        cache = tmp_path / ".cache.json"
        stale_at = datetime.now(timezone.utc) - timedelta(hours=25)
        cache.write_text(json.dumps({
            "valid": True, "tier": "pro", "expires_at": None,
            "message": "Pro", "cached_at": stale_at.isoformat(),
        }), encoding="utf-8")
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", cache)
        with patch("httpx.post", return_value=_mock_validate_resp()) as mock_post:
            License(_KEY, _INSTANCE_ID).validate()
        mock_post.assert_called_once()

    def test_network_timeout_falls_back_to_stale_cache(self, tmp_path, monkeypatch):
        import httpx as _httpx
        cache = tmp_path / ".cache.json"
        stale_at = datetime.now(timezone.utc) - timedelta(hours=25)
        cache.write_text(json.dumps({
            "valid": True, "tier": "pro", "expires_at": None,
            "message": "Pro license active", "cached_at": stale_at.isoformat(),
        }), encoding="utf-8")
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", cache)
        with patch("httpx.post", side_effect=_httpx.TimeoutException("timeout")):
            result = License(_KEY, _INSTANCE_ID).validate()
        assert result.tier == "pro"
        assert "cached" in result.message or "unreachable" in result.message

    def test_network_timeout_no_cache_returns_free(self, tmp_path, monkeypatch):
        import httpx as _httpx
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", tmp_path / ".cache.json")
        with patch("httpx.post", side_effect=_httpx.TimeoutException("timeout")):
            result = License(_KEY, _INSTANCE_ID).validate()
        assert result.tier == "free"
        assert "timeout" in result.message.lower() or "free" in result.message.lower()

    def test_validate_writes_cache_on_success(self, tmp_path, monkeypatch):
        cache = tmp_path / ".cache.json"
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", cache)
        with patch("httpx.post", return_value=_mock_validate_resp()):
            License(_KEY, _INSTANCE_ID).validate()
        assert cache.exists()

    def test_no_instance_id_triggers_activate(self, tmp_path, monkeypatch):
        """validate() with key but no instance_id should auto-activate."""
        cache = tmp_path / ".cache.json"
        cfg = tmp_path / "config.yaml"
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", cache)
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        with patch("httpx.post", return_value=_mock_activate_resp()) as mock_post:
            result = License(_KEY, None).validate()
        # Should have called activate endpoint, not validate
        call_url = mock_post.call_args[0][0]
        assert "activate" in call_url
        assert result.tier == "pro"

    def test_auto_activate_writes_instance_id_to_config(self, tmp_path, monkeypatch):
        cache = tmp_path / ".cache.json"
        cfg = tmp_path / "config.yaml"
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", cache)
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        with patch("httpx.post", return_value=_mock_activate_resp()):
            License(_KEY, None).validate()
        key, instance_id = load_license_config()
        assert instance_id == _INSTANCE_ID


# ---------------------------------------------------------------------------
# License.activate()
# ---------------------------------------------------------------------------

class TestLicenseActivate:
    def test_activate_returns_pro_on_success(self, tmp_path, monkeypatch):
        cfg = tmp_path / "config.yaml"
        cache = tmp_path / ".cache.json"
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", cache)
        with patch("httpx.post", return_value=_mock_activate_resp()):
            result = License(_KEY).activate()
        assert result.tier == "pro"
        assert result.valid is True

    def test_activate_writes_instance_id_to_config(self, tmp_path, monkeypatch):
        cfg = tmp_path / "config.yaml"
        cache = tmp_path / ".cache.json"
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", cache)
        with patch("httpx.post", return_value=_mock_activate_resp()):
            License(_KEY).activate()
        _, stored_id = load_license_config()
        assert stored_id == _INSTANCE_ID

    def test_activate_clears_cache_on_success(self, tmp_path, monkeypatch):
        cfg = tmp_path / "config.yaml"
        cache = tmp_path / ".cache.json"
        cache.write_text('{"valid":true,"tier":"pro","cached_at":"2020-01-01T00:00:00+00:00"}')
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", cache)
        with patch("httpx.post", return_value=_mock_activate_resp()):
            License(_KEY).activate()
        assert not cache.exists()

    def test_activate_returns_free_on_api_failure(self, tmp_path, monkeypatch):
        cfg = tmp_path / "config.yaml"
        cache = tmp_path / ".cache.json"
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", cache)
        with patch("httpx.post", return_value=_mock_activate_resp(activated=False, error="Already at limit")):
            result = License(_KEY).activate()
        assert result.tier == "free"
        assert "limit" in result.message.lower() or "failed" in result.message.lower()

    def test_activate_timeout_returns_invalid(self, tmp_path, monkeypatch):
        import httpx as _httpx
        cfg = tmp_path / "config.yaml"
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", tmp_path / ".cache.json")
        with patch("httpx.post", side_effect=_httpx.TimeoutException("timeout")):
            result = License(_KEY).activate()
        assert result.valid is False
        assert "timeout" in result.message.lower()

    def test_activate_wrong_product_returns_free(self, tmp_path, monkeypatch):
        cfg = tmp_path / "config.yaml"
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", tmp_path / ".cache.json")
        with patch("httpx.post", return_value=_mock_activate_resp(product_id=9999)):
            result = License(_KEY).activate()
        assert result.tier == "free"

    def test_activate_no_key_returns_invalid(self):
        result = License(None).activate()
        assert result.valid is False


# ---------------------------------------------------------------------------
# License.deactivate()
# ---------------------------------------------------------------------------

class TestLicenseDeactivate:
    def test_deactivate_clears_key_and_instance_id(self, tmp_path, monkeypatch):
        cfg = tmp_path / "config.yaml"
        cfg.write_text(
            yaml.safe_dump({"license_key": _KEY, "license_instance_id": _INSTANCE_ID}),
            encoding="utf-8",
        )
        cache = tmp_path / ".cache.json"
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", cache)
        with patch("httpx.post", return_value=_mock_deactivate_resp()):
            result = License(_KEY, _INSTANCE_ID).deactivate()
        assert result.tier == "free"
        key, iid = load_license_config()
        assert key is None
        assert iid is None

    def test_deactivate_clears_cache(self, tmp_path, monkeypatch):
        cfg = tmp_path / "config.yaml"
        cache = tmp_path / ".cache.json"
        cache.write_text('{"valid":true,"tier":"pro","cached_at":"2020-01-01T00:00:00+00:00"}')
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", cfg)
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", cache)
        with patch("httpx.post", return_value=_mock_deactivate_resp()):
            License(_KEY, _INSTANCE_ID).deactivate()
        assert not cache.exists()

    def test_deactivate_no_instance_id_returns_invalid(self, tmp_path, monkeypatch):
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", tmp_path / "config.yaml")
        result = License(_KEY, None).deactivate()
        assert result.valid is False

    def test_deactivate_api_failure_returns_invalid(self, tmp_path, monkeypatch):
        monkeypatch.setattr("hiveframe.license._HOME_CONFIG", tmp_path / "config.yaml")
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", tmp_path / ".cache.json")
        with patch("httpx.post", return_value=_mock_deactivate_resp(deactivated=False)):
            result = License(_KEY, _INSTANCE_ID).deactivate()
        assert result.valid is False


# ---------------------------------------------------------------------------
# License.is_pro()
# ---------------------------------------------------------------------------

class TestLicenseIsPro:
    def test_is_pro_true_for_valid_api_response(self, tmp_path, monkeypatch):
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", tmp_path / ".cache.json")
        with patch("httpx.post", return_value=_mock_validate_resp()):
            assert License(_KEY, _INSTANCE_ID).is_pro() is True

    def test_is_pro_false_for_no_key(self, tmp_path, monkeypatch):
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", tmp_path / ".cache.json")
        assert License(None).is_pro() is False

    def test_is_pro_false_for_invalid_api_response(self, tmp_path, monkeypatch):
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", tmp_path / ".cache.json")
        with patch("httpx.post", return_value=_mock_validate_resp(valid=False)):
            assert License(_KEY, _INSTANCE_ID).is_pro() is False


# ---------------------------------------------------------------------------
# require_pro()
# ---------------------------------------------------------------------------

class TestRequirePro:
    def test_exits_1_on_free_tier(self, monkeypatch):
        monkeypatch.setattr("hiveframe.license.load_license_config", lambda: (None, None))
        with pytest.raises(SystemExit) as exc:
            require_pro("Stack cloning")
        assert exc.value.code == 1

    def test_exits_1_when_api_returns_invalid(self, tmp_path, monkeypatch):
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", tmp_path / ".cache.json")
        monkeypatch.setattr(
            "hiveframe.license.load_license_config", lambda: (_KEY, _INSTANCE_ID)
        )
        with patch("httpx.post", return_value=_mock_validate_resp(valid=False)):
            with pytest.raises(SystemExit) as exc:
                require_pro("Stack cloning")
        assert exc.value.code == 1

    def test_does_not_exit_on_pro(self, tmp_path, monkeypatch):
        monkeypatch.setattr("hiveframe.license._CACHE_PATH", tmp_path / ".cache.json")
        monkeypatch.setattr(
            "hiveframe.license.load_license_config", lambda: (_KEY, _INSTANCE_ID)
        )
        with patch("httpx.post", return_value=_mock_validate_resp()):
            require_pro("Stack cloning")  # must not raise

    def test_upsell_message_contains_store_url(self, monkeypatch):
        monkeypatch.setattr("hiveframe.license.load_license_config", lambda: (None, None))
        from hiveframe.license import _PRO_UPSELL
        assert "lemonsqueezy.com" in _PRO_UPSELL
