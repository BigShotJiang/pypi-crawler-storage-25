"""License management subgroup."""

from __future__ import annotations

import click
from rich.console import Console

console = Console(legacy_windows=False)


@click.group(name="license")
def license_group() -> None:
    """Manage Hiveframe license."""


@license_group.command("status")
def license_status() -> None:
    """Show current license tier, expiry, and masked key."""
    from hiveframe.license import License, load_license_config

    key, instance_id = load_license_config()
    result = License(key, instance_id).validate()

    if result.tier == "pro":
        masked = key[:4] + "-****-****" if key else ""
        expires = result.expires_at or "Lifetime"
        console.print(f"[green]Pro tier[/green] — all features unlocked")
        console.print(f"  Key    : {masked}")
        console.print(f"  Expires: {expires}")
        if "cached" in result.message:
            console.print(f"  [dim]{result.message}[/dim]")
    else:
        if not result.valid:
            console.print(f"[yellow]Warning:[/yellow] {result.message}")
        elif "API" in result.message or "timeout" in result.message.lower():
            console.print(f"[yellow]Warning:[/yellow] {result.message}")
        console.print("[dim]Free tier[/dim] — core features only")
        console.print(
            "  Run [bold]hiveframe license activate <key>[/bold] to unlock Pro."
        )


@license_group.command("activate")
@click.argument("key")
def license_activate(key: str) -> None:
    """Activate a Lemon Squeezy license key."""
    from hiveframe.license import License

    console.print("Activating license...")
    result = License(key).activate()

    if not result.valid or result.tier != "pro":
        console.print(f"[red]FAIL[/red] {result.message}")
        raise SystemExit(1)

    masked = key[:4] + "-****-****"
    expires = result.expires_at or "Lifetime"
    console.print("[green]OK[/green] Pro license activated")
    console.print(f"  Key    : {masked}")
    console.print(f"  Expires: {expires}")


@license_group.command("deactivate")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
def license_deactivate(yes: bool) -> None:
    """Deactivate the current license and return to free tier."""
    from hiveframe.license import License, load_license_config

    key, instance_id = load_license_config()
    if not key:
        console.print("[yellow]No license key configured.[/yellow]")
        return

    if not yes:
        click.confirm("Deactivate license and return to free tier?", abort=True)

    result = License(key, instance_id).deactivate()
    if result.tier == "free" and "deactivated" in result.message.lower():
        console.print("[green]OK[/green] License deactivated — now on free tier")
    else:
        console.print(f"[red]FAIL[/red] {result.message}")
        raise SystemExit(1)
