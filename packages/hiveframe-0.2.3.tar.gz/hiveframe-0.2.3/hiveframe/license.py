"""License key validation via Lemon Squeezy API with local caching."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

import httpx
import yaml

_HOME_CONFIG = Path.home() / ".hiveframe" / "config.yaml"
_CACHE_PATH = Path.home() / ".hiveframe" / ".license_cache.json"
_CACHE_TTL_HOURS = 24
_LS_VALIDATE = "https://api.lemonsqueezy.com/v1/licenses/validate"
_LS_ACTIVATE = "https://api.lemonsqueezy.com/v1/licenses/activate"
_LS_DEACTIVATE = "https://api.lemonsqueezy.com/v1/licenses/deactivate"
_VALID_PRODUCT_IDS = {1009925, 1009929}
_API_TIMEOUT = 5.0


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------

@dataclass
class LicenseResult:
    valid: bool
    tier: Literal["free", "pro"]
    license_key: str | None
    instance_id: str | None
    expires_at: str | None
    message: str


def _free(message: str) -> LicenseResult:
    return LicenseResult(
        valid=True, tier="free",
        license_key=None, instance_id=None, expires_at=None,
        message=message,
    )


def _invalid(message: str) -> LicenseResult:
    return LicenseResult(
        valid=False, tier="free",
        license_key=None, instance_id=None, expires_at=None,
        message=message,
    )


# ---------------------------------------------------------------------------
# Cache
# ---------------------------------------------------------------------------

def _read_cache(allow_stale: bool = False) -> dict | None:
    """Return cache dict if fresh (or stale when allow_stale). None if absent/corrupt."""
    if not _CACHE_PATH.exists():
        return None
    try:
        data = json.loads(_CACHE_PATH.read_text(encoding="utf-8"))
        cached_at = datetime.fromisoformat(data["cached_at"])
        age_s = (datetime.now(timezone.utc) - cached_at).total_seconds()
        if not allow_stale and age_s >= _CACHE_TTL_HOURS * 3600:
            return None
        return data
    except Exception:
        return None


def _write_cache(result: LicenseResult) -> None:
    _CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    _CACHE_PATH.write_text(
        json.dumps({
            "valid": result.valid,
            "tier": result.tier,
            "expires_at": result.expires_at,
            "message": result.message,
            "cached_at": datetime.now(timezone.utc).isoformat(),
        }),
        encoding="utf-8",
    )


def _clear_cache() -> None:
    if _CACHE_PATH.exists():
        _CACHE_PATH.unlink()


def _result_from_cache(
    data: dict, key: str | None, instance_id: str | None, suffix: str = ""
) -> LicenseResult:
    msg = data.get("message", "Pro license active (cached)")
    return LicenseResult(
        valid=data.get("valid", False),
        tier=data.get("tier", "free"),
        license_key=key,
        instance_id=instance_id,
        expires_at=data.get("expires_at"),
        message=msg + suffix if suffix else msg,
    )


# ---------------------------------------------------------------------------
# Config I/O
# ---------------------------------------------------------------------------

def load_license_config() -> tuple[str | None, str | None]:
    """Return (license_key, instance_id) from ~/.hiveframe/config.yaml."""
    if not _HOME_CONFIG.exists():
        return None, None
    data: dict = yaml.safe_load(_HOME_CONFIG.read_text(encoding="utf-8")) or {}
    return data.get("license_key") or None, data.get("license_instance_id") or None


def write_license_config(key: str | None, instance_id: str | None) -> None:
    """Write license fields to config, preserving all other settings."""
    _HOME_CONFIG.parent.mkdir(parents=True, exist_ok=True)
    data: dict = {}
    if _HOME_CONFIG.exists():
        data = yaml.safe_load(_HOME_CONFIG.read_text(encoding="utf-8")) or {}

    if key is not None:
        data["license_key"] = key
    else:
        data.pop("license_key", None)

    if instance_id is not None:
        data["license_instance_id"] = instance_id
    else:
        data.pop("license_instance_id", None)

    _HOME_CONFIG.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")


def clear_license_config() -> None:
    """Remove license_key and license_instance_id from config."""
    write_license_config(None, None)


def load_license_key() -> str | None:
    """Return just license_key from config (kept for compatibility)."""
    return load_license_config()[0]


# ---------------------------------------------------------------------------
# License class
# ---------------------------------------------------------------------------

class License:
    def __init__(self, key: str | None, instance_id: str | None = None) -> None:
        self._key = key
        self._instance_id = instance_id

    # ------------------------------------------------------------------
    # Raw API calls (each raises httpx exceptions on network failure)
    # ------------------------------------------------------------------

    def _api_validate(self) -> LicenseResult:
        payload: dict = {"license_key": self._key}
        if self._instance_id:
            payload["instance_id"] = self._instance_id
        resp = httpx.post(_LS_VALIDATE, json=payload, timeout=_API_TIMEOUT)
        data = resp.json()
        if not data.get("valid"):
            return _invalid(data.get("error") or "License key is invalid or disabled")
        meta = data.get("meta", {})
        if meta.get("product_id") not in _VALID_PRODUCT_IDS:
            return _invalid("Key is not for a Hiveframe Pro product")
        lk = data.get("license_key", {})
        return LicenseResult(
            valid=True, tier="pro",
            license_key=self._key,
            instance_id=self._instance_id,
            expires_at=lk.get("expires_at"),
            message="Pro license active",
        )

    def _api_activate(self) -> LicenseResult:
        resp = httpx.post(
            _LS_ACTIVATE,
            json={"license_key": self._key, "instance_name": "hiveframe-cli"},
            timeout=_API_TIMEOUT,
        )
        data = resp.json()
        if not data.get("activated"):
            return _invalid(data.get("error") or "Activation failed")
        meta = data.get("meta", {})
        if meta.get("product_id") not in _VALID_PRODUCT_IDS:
            return _invalid("Key is not for a Hiveframe Pro product")
        instance_id = (data.get("instance") or {}).get("id")
        lk = data.get("license_key", {})
        return LicenseResult(
            valid=True, tier="pro",
            license_key=self._key,
            instance_id=instance_id,
            expires_at=lk.get("expires_at"),
            message="Pro license activated",
        )

    def _api_deactivate(self) -> bool:
        resp = httpx.post(
            _LS_DEACTIVATE,
            json={"license_key": self._key, "instance_id": self._instance_id},
            timeout=_API_TIMEOUT,
        )
        return bool(resp.json().get("deactivated"))

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def validate(self) -> LicenseResult:
        """Check license, using cache when fresh. Never raises."""
        if not self._key:
            return _free("No license key — free tier")

        cached = _read_cache()
        if cached is not None:
            return _result_from_cache(cached, self._key, self._instance_id)

        try:
            if self._instance_id:
                result = self._api_validate()
            else:
                # First use: activate to obtain an instance_id
                result = self._api_activate()
                if result.valid and result.instance_id:
                    write_license_config(self._key, result.instance_id)
                    self._instance_id = result.instance_id
            if result.valid:
                _write_cache(result)
            return result
        except httpx.TimeoutException:
            stale = _read_cache(allow_stale=True)
            if stale is not None:
                return _result_from_cache(
                    stale, self._key, self._instance_id,
                    " (API unreachable — using cached result)",
                )
            return _free("License API timeout — treating as free tier")
        except Exception:
            stale = _read_cache(allow_stale=True)
            if stale is not None:
                return _result_from_cache(
                    stale, self._key, self._instance_id,
                    " (API unreachable — using cached result)",
                )
            return _free("License check failed — treating as free tier")

    def activate(self) -> LicenseResult:
        """Explicitly activate via LS API and persist the instance_id."""
        if not self._key:
            return _invalid("No license key provided")
        try:
            result = self._api_activate()
        except httpx.TimeoutException:
            return _invalid("License API timeout — check your connection")
        except Exception as exc:
            return _invalid(f"Activation failed: {exc}")
        if result.valid and result.instance_id:
            write_license_config(self._key, result.instance_id)
            _clear_cache()
            self._instance_id = result.instance_id
        return result

    def deactivate(self) -> LicenseResult:
        """Deactivate the instance via LS API and clear config."""
        if not self._key or not self._instance_id:
            return _invalid("No active license instance to deactivate")
        try:
            ok = self._api_deactivate()
        except httpx.TimeoutException:
            return _invalid("License API timeout — check your connection")
        except Exception as exc:
            return _invalid(f"Deactivation failed: {exc}")
        if ok:
            clear_license_config()
            _clear_cache()
            return LicenseResult(
                valid=False, tier="free",
                license_key=None, instance_id=None, expires_at=None,
                message="License deactivated — now on free tier",
            )
        return _invalid("Deactivation rejected — check the Lemon Squeezy dashboard")

    def is_pro(self) -> bool:
        return self.validate().tier == "pro"


# ---------------------------------------------------------------------------
# Pro gate
# ---------------------------------------------------------------------------

_PRO_UPSELL = (
    "\nThis feature requires Hiveframe Pro.\n\n"
    "Hiveframe Pro unlocks:\n"
    "  - Stack cloning\n"
    "  - [future pro features]\n\n"
    "Get Hiveframe Pro at hiveframe.lemonsqueezy.com\n\n"
    "Already have a key? Run:\n"
    "  hiveframe license activate YOUR-KEY-HERE"
)


def require_pro(feature_name: str) -> None:
    """Exit with code 1 if the current license is not Pro."""
    key, instance_id = load_license_config()
    lic = License(key, instance_id)
    result = lic.validate()
    if result.tier != "pro":
        from rich.console import Console
        console = Console(legacy_windows=False)
        if "API" in result.message or "timeout" in result.message.lower() or "failed" in result.message.lower():
            console.print(f"[yellow]Warning:[/yellow] {result.message}")
        console.print(_PRO_UPSELL)
        raise SystemExit(1)
