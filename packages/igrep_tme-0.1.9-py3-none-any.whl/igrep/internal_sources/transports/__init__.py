"""Transport helpers for internal source adapters."""
