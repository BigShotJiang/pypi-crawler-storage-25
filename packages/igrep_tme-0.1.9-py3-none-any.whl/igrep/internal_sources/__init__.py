"""Internal remote search source adapters."""
