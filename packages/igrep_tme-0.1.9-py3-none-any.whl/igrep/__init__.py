"""igrep — agent-first semantic grep / RAG grep CLI."""

from __future__ import annotations

from pathlib import Path


def _read_version() -> str:
    # SSoT: <repo-root>/VERSION (plain text). Two read paths:
    #   1) source tree / editable install → read the live file (no install needed)
    #   2) installed wheel → fall back to package metadata baked in by hatchling
    repo_file = Path(__file__).resolve().parents[2] / "VERSION"
    if repo_file.is_file():
        return repo_file.read_text().strip()
    from importlib.metadata import PackageNotFoundError, version

    try:
        return version("igrep-tme")
    except PackageNotFoundError:
        return "0.0.0+unknown"


__version__ = _read_version()
