"""Transport adapters that serialise ChatEvent to SSE or NDJSON.

The two adapters MUST produce byte-identical event payloads; only the framing
differs. Re-exported for convenient imports:

    from igrep.chat_transports import sse_encode, ndjson_encode
"""

from __future__ import annotations

from igrep.chat_transports.ndjson import ndjson_encode
from igrep.chat_transports.sse import sse_encode

__all__ = ["sse_encode", "ndjson_encode"]
