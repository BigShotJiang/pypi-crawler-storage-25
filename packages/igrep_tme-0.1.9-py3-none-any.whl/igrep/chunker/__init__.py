"""Chunking strategies for igrep document indexing."""

from __future__ import annotations

from igrep.chunker.base import chunk_fallback
from igrep.chunker.code import chunk_code, tokenize_symbol_name
from igrep.chunker.text import (
    chunk_file,
    chunk_markdown,
    chunk_text,
)

__all__ = [
    "chunk_code", "chunk_fallback", "chunk_file", "chunk_markdown",
    "chunk_text", "tokenize_symbol_name",
]
