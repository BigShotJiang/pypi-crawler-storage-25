"""Local AI service setup — public facade.

INTENT: After oMLX brew service migration, this facade is simplified.
        No more managed process lifecycle (bootstrap/lifecycle/pid/health deleted).
        Retained: model download, dependency checks, env config, diagnostics.
"""

from igrep.services.process import (  # noqa: F401 -- re-export facade
    LOGS_DIR,
    REQUIRED_LOCAL_DEPS,
    RERANK_MODEL,
    VLLM_MLX_EMBED_MODEL,
    VLLM_MLX_LLM_EXTRA_BODY,
    VLLM_MLX_LLM_MODEL,
    VLLM_MLX_OCR_MODEL,
    append_or_update_env,
    check_all,
    check_hf_token,
    collect_local_diagnostics,
    download_all_models,
    download_single_model,
    emit_local_diagnostics_layers,
    get_dependency_install_guidance,
    setup_local,
)

__all__ = [
    # process: constants
    "LOGS_DIR",
    "RERANK_MODEL",
    "REQUIRED_LOCAL_DEPS",
    "VLLM_MLX_EMBED_MODEL",
    "VLLM_MLX_LLM_EXTRA_BODY",
    "VLLM_MLX_LLM_MODEL",
    "VLLM_MLX_OCR_MODEL",
    # process: public functions
    "append_or_update_env",
    "check_all",
    "check_hf_token",
    "collect_local_diagnostics",
    "download_all_models",
    "download_single_model",
    "emit_local_diagnostics_layers",
    "get_dependency_install_guidance",
    "setup_local",
]
