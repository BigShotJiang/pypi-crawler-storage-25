"""igrep serve subpackage — HTTP server, routes, and OS service integration."""

from igrep.serve.app import create_management_app, run_web_server

__all__ = ["create_management_app", "run_web_server"]
