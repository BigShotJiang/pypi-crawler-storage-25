# Copyright 2024 Klira AI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Standard framework adapter — default for any Python code.

Works with plain functions and classes, Haystack, AutoGen, or any
custom code agent. This is the fallback when no specific framework
is detected. (Learning #11)
"""

from __future__ import annotations

import logging
from typing import Any, Callable

from klira.sdk.adapters.base_framework import BaseFrameworkAdapter

logger = logging.getLogger(__name__)


class StandardAdapter(BaseFrameworkAdapter):
    """Default adapter for standard Python code.

    No framework-specific behavior — decorators work as-is.
    All adapt_* methods return the function unchanged since
    the core decorators already handle span creation.
    """

    @property
    def framework_name(self) -> str:
        return "standard"

    def adapt_workflow(self, func: Callable[..., Any]) -> Callable[..., Any]:
        """No adaptation needed for standard Python workflows."""
        return func

    def adapt_agent(self, func: Callable[..., Any]) -> Callable[..., Any]:
        """No adaptation needed for standard Python agents."""
        return func

    def adapt_tool(self, func: Callable[..., Any]) -> Callable[..., Any]:
        """No adaptation needed. Must preserve callability (Learning #12)."""
        return func

    def adapt_task(self, func: Callable[..., Any]) -> Callable[..., Any]:
        """No adaptation needed for standard Python tasks."""
        return func

    def patch_framework(self) -> None:
        """No framework to patch."""
        pass

    def verify_suppression(self) -> bool:
        """No native telemetry to suppress."""
        return True
