# Copyright 2024 Klira AI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from klira.sdk.adapters.anthropic import AnthropicAdapter
from klira.sdk.adapters.base_framework import BaseFrameworkAdapter
from klira.sdk.adapters.base_llm import BaseLLMAdapter
from klira.sdk.adapters.crewai import CrewAIAdapter
from klira.sdk.adapters.gemini import GeminiAdapter
from klira.sdk.adapters.langchain import LangChainAdapter
from klira.sdk.adapters.langgraph import LangGraphAdapter
from klira.sdk.adapters.litellm import LiteLLMAdapter
from klira.sdk.adapters.llamaindex import LlamaIndexAdapter
from klira.sdk.adapters.ollama import OllamaAdapter
from klira.sdk.adapters.openai_agents import OpenAIAgentsAdapter
from klira.sdk.adapters.openai_completion import OpenAICompletionAdapter
from klira.sdk.adapters.openai_responses import OpenAIResponsesAdapter
from klira.sdk.adapters.standard import StandardAdapter

__all__ = [
    "BaseLLMAdapter",
    "BaseFrameworkAdapter",
    "StandardAdapter",
    "OpenAICompletionAdapter",
    "OpenAIResponsesAdapter",
    "AnthropicAdapter",
    "GeminiAdapter",
    "OllamaAdapter",
    "LiteLLMAdapter",
    "OpenAIAgentsAdapter",
    "LangChainAdapter",
    "LangGraphAdapter",
    "CrewAIAdapter",
    "LlamaIndexAdapter",
]
