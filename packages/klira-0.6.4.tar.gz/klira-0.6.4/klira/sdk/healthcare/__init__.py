# Copyright 2024 Klira AI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Healthcare features — clinical context, logging, and PHI de-identification."""

from klira.sdk.healthcare.context import (
    set_clinical_context,
    set_interaction_modality,
    set_patient_context,
)
from klira.sdk.healthcare.logging import (
    log_agent_handoff,
    log_clinical_decision,
    log_human_escalation,
    log_rag_retrieval,
    log_safety_check,
)
from klira.sdk.healthcare.phi import PhiScanner

__all__ = [
    "PhiScanner",
    "log_agent_handoff",
    "log_clinical_decision",
    "log_human_escalation",
    "log_rag_retrieval",
    "log_safety_check",
    "set_clinical_context",
    "set_interaction_modality",
    "set_patient_context",
]
