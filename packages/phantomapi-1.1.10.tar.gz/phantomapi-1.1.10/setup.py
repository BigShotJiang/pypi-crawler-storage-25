from setuptools import setup, find_packages

setup(
    name='phantomapi',
    version='1.1.10',
    author='TheZ4th',
    author_email='zethkaretjir@gmail.com',
    description='Phone number OSINT library for Indonesia',
    long_description_content_type='text/markdown',
    packages=find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
    ],
    python_requires='>=3.6',
    include_package_data=True,
    package_data={
        'phantomapi': ['platforms.json'],
    },
)
