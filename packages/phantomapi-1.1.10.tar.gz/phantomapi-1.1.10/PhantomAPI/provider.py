PROVIDERS = {
    # ==================== INDONESIA (62) ====================
    'ID': {
        'name': 'Indonesia',
        'code': '62',
        'prefixes': {
            # Telkomsel
            '0811': 'Telkomsel', '0812': 'Telkomsel', '0813': 'Telkomsel',
            '0821': 'Telkomsel', '0822': 'Telkomsel', '0823': 'Telkomsel',
            '0851': 'Telkomsel', '0852': 'Telkomsel', '0853': 'Telkomsel',
            # Indosat
            '0814': 'Indosat Ooredoo', '0815': 'Indosat Ooredoo', '0816': 'Indosat Ooredoo',
            '0855': 'Indosat Ooredoo', '0856': 'Indosat Ooredoo', '0857': 'Indosat Ooredoo',
            '0858': 'Indosat Ooredoo',
            # XL Axiata
            '0817': 'XL Axiata', '0818': 'XL Axiata', '0819': 'XL Axiata',
            '0877': 'XL Axiata', '0878': 'XL Axiata', '0879': 'XL Axiata',
            # Tri (3)
            '0895': 'Tri', '0896': 'Tri', '0897': 'Tri', '0898': 'Tri', '0899': 'Tri',
            # Smartfren
            '0881': 'Smartfren', '0882': 'Smartfren', '0883': 'Smartfren',
            '0884': 'Smartfren', '0885': 'Smartfren', '0886': 'Smartfren',
            '0887': 'Smartfren', '0888': 'Smartfren', '0889': 'Smartfren',
        },
        'mvno': {
            '0859': 'By.U',  # MVNO Telkomsel
        },
        'regex': r'^62[0-9]{9,12}$'
    },

    # ==================== MALAYSIA (60) ====================
    'MY': {
        'name': 'Malaysia',
        'code': '60',
        'prefixes': {
            '010': 'DiGi', '011': 'U Mobile', '012': 'Maxis', '013': 'Celcom',
            '014': 'Maxis/Celcom', '015': 'Tune Talk', '016': 'DiGi',
            '017': 'Maxis', '018': 'U Mobile', '019': 'Celcom',
        },
        'regex': r'^60[0-9]{8,10}$'
    },

    # ==================== SINGAPURA (65) ====================
    'SG': {
        'name': 'Singapore',
        'code': '65',
        'prefixes': {
            '8111': 'Singtel', '8112': 'Singtel', '8113': 'Singtel',
            '8120': 'Singtel', '8121': 'Singtel', '8122': 'Singtel',
            '8000': 'StarHub', '8001': 'StarHub', '8002': 'StarHub',
            '8100': 'M1', '8101': 'M1', '8102': 'M1',
            '8800': 'SIMBA', '8801': 'SIMBA',
        },
        'mvno': {
            '8600': 'Circles.Life', '8660': 'GOMO', '8661': 'GOMO',
        },
        'regex': r'^65[0-9]{8}$'
    },

    # ==================== THAILAND (66) - NEW! ====================
    'TH': {
        'name': 'Thailand',
        'code': '66',
        'prefixes': {
            '080': 'AIS', '081': 'AIS', '082': 'AIS', '083': 'AIS',
            '084': 'AIS', '085': 'AIS', '086': 'AIS',
            '089': 'AIS',
            '061': 'AIS', '062': 'AIS', '063': 'AIS', '064': 'AIS',
            '065': 'AIS', '069': 'AIS',
            '090': 'DTAC', '091': 'DTAC', '092': 'DTAC', '093': 'DTAC',
            '094': 'DTAC', '095': 'DTAC', '096': 'DTAC', '097': 'DTAC',
            '098': 'DTAC', '099': 'DTAC',
            '0810': 'TrueMove', '0811': 'TrueMove', '0812': 'TrueMove',
            '0610': 'TrueMove', '0611': 'TrueMove', '0612': 'TrueMove',
        },
        'regex': r'^66[0-9]{9,10}$'
    },

    # ==================== VIETNAM (84) - NEW! ====================
    'VN': {
        'name': 'Vietnam',
        'code': '84',
        'prefixes': {
            '086': 'Viettel', '096': 'Viettel', '097': 'Viettel',
            '098': 'Viettel', '032': 'Viettel', '033': 'Viettel',
            '034': 'Viettel', '035': 'Viettel', '036': 'Viettel',
            '037': 'Viettel', '038': 'Viettel', '039': 'Viettel',
            '070': 'Mobifone', '076': 'Mobifone', '077': 'Mobifone',
            '078': 'Mobifone', '079': 'Mobifone', '089': 'Mobifone',
            '090': 'Vinaphone', '091': 'Vinaphone', '088': 'Vinaphone',
            '083': 'Vinaphone', '084': 'Vinaphone', '085': 'Vinaphone',
            '081': 'Vinaphone', '082': 'Vinaphone',
        },
        'regex': r'^84[0-9]{9,10}$'
    },

    # ==================== JEPANG (81) - NEW! ====================
    'JP': {
        'name': 'Japan',
        'code': '81',
        'prefixes': {
            '070': 'NTT Docomo', '080': 'NTT Docomo', '090': 'NTT Docomo',
            '050': 'NTT Docomo',
            '060': 'au (KDDI)', '070': 'au (KDDI)', '080': 'au (KDDI)',
            '090': 'au (KDDI)', '0700': 'au (KDDI)',
            '0701': 'SoftBank', '0801': 'SoftBank', '0901': 'SoftBank',
            '0702': 'SoftBank', '0802': 'SoftBank', '0902': 'SoftBank',
        },
        'regex': r'^81[0-9]{10}$'
    },

    # ==================== PHILIPPINES (63) ====================
    'PH': {
        'name': 'Philippines',
        'code': '63',
        'prefixes': {
            '917': 'Globe', '918': 'Globe', '919': 'Globe', '920': 'Globe',
            '921': 'Globe', '922': 'Globe', '923': 'Globe', '924': 'Globe',
            '925': 'Globe', '926': 'Globe', '927': 'Globe', '928': 'Globe',
            '929': 'Globe', '905': 'Globe', '906': 'Globe', '907': 'Globe',
            '915': 'Globe', '916': 'Globe', '956': 'Globe', '957': 'Globe',
            '908': 'Smart', '909': 'Smart', '910': 'Smart', '911': 'Smart',
            '912': 'Smart', '913': 'Smart', '914': 'Smart',
            '938': 'Smart', '939': 'Smart', '940': 'Smart', '941': 'Smart',
            '942': 'Smart', '943': 'Smart', '944': 'Smart', '945': 'Smart',
            '991': 'DITO', '992': 'DITO', '993': 'DITO', '994': 'DITO',
            '995': 'DITO', '996': 'DITO', '997': 'DITO', '998': 'DITO', '999': 'DITO',
        },
        'regex': r'^63[0-9]{10}$'
    },

    # ==================== INDIA (91) ====================
    'IN': {
        'name': 'India',
        'code': '91',
        'prefixes': {
            '9810': 'Airtel', '9811': 'Airtel', '9812': 'Airtel',
            '9820': 'Vodafone Idea', '9821': 'Vodafone Idea', '9822': 'Vodafone Idea',
            '9870': 'Jio', '9871': 'Jio', '9872': 'Jio', '9873': 'Jio',
            '8888': 'BSNL', '8889': 'BSNL',
        },
        'regex': r'^91[0-9]{10}$'
    },
}
