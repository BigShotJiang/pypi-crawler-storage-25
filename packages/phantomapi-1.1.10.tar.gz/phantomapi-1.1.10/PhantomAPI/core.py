import re
from .provider import PROVIDERS


class PhoneOSINT:
    def __init__(self):
        self.providers = PROVIDERS
    
    def lookup(self, phone: str) -> dict:
        phone = re.sub(r'[^0-9+]', '', phone)
        
        for code, info in self.providers.items():
            if phone.startswith(info['code']):
                local_num = phone[len(info['code']):]
                if not local_num.startswith('0') and code != 'SG':
                    local_num = '0' + local_num
                
                prefixes = sorted(info['prefixes'].keys(), key=len, reverse=True)
                for prefix in prefixes:
                    if local_num.startswith(prefix):
                        return {
                            'valid': True,
                            'number': phone,
                            'international': phone,
                            'country': info['name'],
                            'country_code': code,
                            'carrier': info['prefixes'][prefix],
                            'prefix': prefix,
                            'is_mvno': info.get('mvno', {}).get(prefix, False),
                            'line_type': 'mobile'
                        }
                return {'valid': False, 'error': 'Provider not found'}
        
        return {'valid': False, 'error': 'Country not supported'}
    
    def validate(self, phone: str) -> bool:
        return self.lookup(phone).get('valid', False)
