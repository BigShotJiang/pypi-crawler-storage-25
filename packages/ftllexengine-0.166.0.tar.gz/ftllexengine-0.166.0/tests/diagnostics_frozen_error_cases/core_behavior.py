# mypy: ignore-errors
from __future__ import annotations

import pytest
from hypothesis import assume, event, example, given, settings
from hypothesis import strategies as st

from ftllexengine.diagnostics import (
    Diagnostic,
    DiagnosticCode,
    ErrorCategory,
    FrozenErrorContext,
    FrozenFluentError,
)
from ftllexengine.integrity import ImmutabilityViolationError
from tests.strategies.diagnostics import error_categories

# =============================================================================
# Strategies for generating test data
# =============================================================================


@st.composite
def error_messages(draw: st.DrawFn) -> str:
    """Generate valid error messages."""
    return draw(st.text(min_size=1, max_size=200))


@st.composite
def optional_diagnostics(draw: st.DrawFn) -> Diagnostic | None:
    """Generate optional Diagnostic objects."""
    if draw(st.booleans()):
        code = draw(st.sampled_from(list(DiagnosticCode)))
        message = draw(st.text(min_size=1, max_size=100))
        return Diagnostic(code=code, message=message, severity="error")
    return None


@st.composite
def optional_contexts(draw: st.DrawFn) -> FrozenErrorContext | None:
    """Generate optional FrozenErrorContext objects."""
    if draw(st.booleans()):
        return FrozenErrorContext(
            input_value=draw(st.text(min_size=0, max_size=50)),
            locale_code=draw(st.text(min_size=1, max_size=10)),
            parse_type=draw(st.sampled_from(
                ["", "currency", "date", "datetime", "decimal", "number"]
            )),
            fallback_value=draw(st.text(min_size=0, max_size=50)),
        )
    return None


@st.composite
def frozen_fluent_errors(draw: st.DrawFn) -> FrozenFluentError:
    """Generate FrozenFluentError instances."""
    return FrozenFluentError(
        message=draw(error_messages()),
        category=draw(error_categories()),
        diagnostic=draw(optional_diagnostics()),
        context=draw(optional_contexts()),
    )


# =============================================================================
# Content Hash Properties
# =============================================================================



@pytest.mark.fuzz
class TestContentHashDeterminism:
    """Content hash must be deterministic - same inputs always produce same hash."""

    @given(
        message=error_messages(),
        category=error_categories(),
    )
    @settings(max_examples=100)
    def test_same_inputs_produce_same_hash(
        self, message: str, category: ErrorCategory
    ) -> None:
        """Property: Identical errors have identical content hashes."""
        error1 = FrozenFluentError(message, category)
        error2 = FrozenFluentError(message, category)

        event(f"msg_len={len(message)}")
        assert error1.content_hash == error2.content_hash
        assert error1 == error2
        event("outcome=hash_determinism_success")

    @given(
        message=error_messages(),
        category=error_categories(),
        diagnostic=optional_diagnostics(),
        context=optional_contexts(),
    )
    @settings(max_examples=100)
    def test_same_inputs_with_optional_fields(
        self,
        message: str,
        category: ErrorCategory,
        diagnostic: Diagnostic | None,
        context: FrozenErrorContext | None,
    ) -> None:
        """Property: Identical errors with optional fields have identical hashes."""
        error1 = FrozenFluentError(message, category, diagnostic, context)
        error2 = FrozenFluentError(message, category, diagnostic, context)

        has_diag = diagnostic is not None
        has_ctx = context is not None
        event(f"has_diagnostic={has_diag}")
        event(f"has_context={has_ctx}")
        assert error1.content_hash == error2.content_hash
        assert error1 == error2

    @given(error=frozen_fluent_errors())
    @settings(max_examples=100)
    def test_hash_is_16_bytes(self, error: FrozenFluentError) -> None:
        """Property: Content hash is always 16 bytes (BLAKE2b-128)."""
        event(f"category={error.category.name}")
        assert len(error.content_hash) == 16

@pytest.mark.fuzz
class TestContentHashCollisionResistance:
    """Different inputs should produce different hashes (high probability)."""

    @given(
        message1=error_messages(),
        message2=error_messages(),
        category=error_categories(),
    )
    @settings(max_examples=100)
    def test_different_messages_different_hashes(
        self, message1: str, message2: str, category: ErrorCategory
    ) -> None:
        """Property: Different messages produce different hashes."""
        assume(message1 != message2)

        error1 = FrozenFluentError(message1, category)
        error2 = FrozenFluentError(message2, category)

        event(f"msg1_len={len(message1)}")
        event(f"msg2_len={len(message2)}")
        assert error1.content_hash != error2.content_hash
        assert error1 != error2
        event("outcome=hash_collision_resistance")

    @given(
        message=error_messages(),
        category1=error_categories(),
        category2=error_categories(),
    )
    @settings(max_examples=100)
    def test_different_categories_different_hashes(
        self, message: str, category1: ErrorCategory, category2: ErrorCategory
    ) -> None:
        """Property: Different categories produce different hashes."""
        assume(category1 != category2)

        error1 = FrozenFluentError(message, category1)
        error2 = FrozenFluentError(message, category2)

        event(f"cat1={category1.name}")
        event(f"cat2={category2.name}")
        assert error1.content_hash != error2.content_hash
        assert error1 != error2

@pytest.mark.fuzz
class TestImmutabilityEnforcement:
    """FrozenFluentError must reject all mutations after construction."""

    @given(error=frozen_fluent_errors())
    @settings(max_examples=50)
    def test_cannot_modify_message(self, error: FrozenFluentError) -> None:
        """Property: Cannot modify message after construction."""
        with pytest.raises(ImmutabilityViolationError):
            error._message = "modified"
        event(f"msg_len={len(error.message)}")
        event("outcome=immutability_enforced")

    @given(error=frozen_fluent_errors())
    @settings(max_examples=50)
    def test_cannot_modify_category(self, error: FrozenFluentError) -> None:
        """Property: Cannot modify category after construction."""
        with pytest.raises(ImmutabilityViolationError):
            error._category = ErrorCategory.PARSE
        event(f"category={error.category.name}")

    @given(error=frozen_fluent_errors())
    @settings(max_examples=50)
    def test_cannot_modify_diagnostic(self, error: FrozenFluentError) -> None:
        """Property: Cannot modify diagnostic after construction."""
        with pytest.raises(ImmutabilityViolationError):
            error._diagnostic = None
        has_diag = error.diagnostic is not None
        event(f"has_diagnostic={has_diag}")

    @given(error=frozen_fluent_errors())
    @settings(max_examples=50)
    def test_cannot_modify_context(self, error: FrozenFluentError) -> None:
        """Property: Cannot modify context after construction."""
        with pytest.raises(ImmutabilityViolationError):
            error._context = None
        has_ctx = error.context is not None
        event(f"has_context={has_ctx}")

    @given(error=frozen_fluent_errors())
    @settings(max_examples=50)
    def test_cannot_modify_content_hash(self, error: FrozenFluentError) -> None:
        """Property: Cannot modify content hash after construction."""
        with pytest.raises(ImmutabilityViolationError):
            error._content_hash = b"fake"
        event(f"category={error.category.name}")

    @given(error=frozen_fluent_errors())
    @settings(max_examples=50)
    def test_cannot_delete_attributes(self, error: FrozenFluentError) -> None:
        """Property: Cannot delete any attributes."""
        with pytest.raises(ImmutabilityViolationError):
            del error._message
        event(f"category={error.category.name}")

class TestSealedTypeEnforcement:
    """FrozenFluentError must reject subclassing at runtime."""

    def test_cannot_subclass(self) -> None:
        """FrozenFluentError cannot be subclassed."""
        with pytest.raises(TypeError, match="cannot be subclassed"):
            # pylint: disable=unused-variable,subclassed-final-class
            class MaliciousError(FrozenFluentError):  # type: ignore[misc]
                pass

@pytest.mark.fuzz
class TestVerifyIntegrity:
    """verify_integrity() must correctly detect corruption."""

    @given(error=frozen_fluent_errors())
    @settings(max_examples=100)
    def test_fresh_error_passes_integrity_check(
        self, error: FrozenFluentError
    ) -> None:
        """Property: Freshly constructed errors always pass integrity check."""
        event(f"category={error.category.name}")
        assert error.verify_integrity() is True
        event("outcome=integrity_check_passed")

    @given(error=frozen_fluent_errors())
    @settings(max_examples=100)
    def test_integrity_is_idempotent(self, error: FrozenFluentError) -> None:
        """Property: verify_integrity() can be called multiple times."""
        event(f"category={error.category.name}")
        assert error.verify_integrity() is True
        assert error.verify_integrity() is True
        assert error.verify_integrity() is True

@pytest.mark.fuzz
class TestHashability:
    """FrozenFluentError must be usable in sets and as dict keys."""

    @given(error=frozen_fluent_errors())
    @settings(max_examples=50)
    def test_error_is_hashable(self, error: FrozenFluentError) -> None:
        """Property: Errors are hashable (can use hash())."""
        h = hash(error)
        assert isinstance(h, int)
        event(f"category={error.category.name}")

    @given(error=frozen_fluent_errors())
    @settings(max_examples=50)
    def test_hash_is_stable(self, error: FrozenFluentError) -> None:
        """Property: Hash is stable across multiple calls."""
        h1 = hash(error)
        h2 = hash(error)
        h3 = hash(error)
        assert h1 == h2 == h3
        event(f"category={error.category.name}")

    @given(
        message=error_messages(),
        category=error_categories(),
    )
    @settings(max_examples=50)
    def test_equal_errors_have_equal_hashes(
        self, message: str, category: ErrorCategory
    ) -> None:
        """Property: Equal errors have equal hashes (hash contract)."""
        error1 = FrozenFluentError(message, category)
        error2 = FrozenFluentError(message, category)

        assert error1 == error2
        assert hash(error1) == hash(error2)
        event(f"category={category.name}")

    @given(
        errors=st.lists(frozen_fluent_errors(), min_size=1, max_size=20, unique=True)
    )
    @settings(max_examples=50)
    def test_errors_can_be_added_to_set(
        self, errors: list[FrozenFluentError]
    ) -> None:
        """Property: Errors can be stored in sets."""
        error_set = set(errors)
        assert len(error_set) <= len(errors)
        event(f"set_size={len(error_set)}")

    @given(
        errors=st.lists(frozen_fluent_errors(), min_size=1, max_size=20, unique=True)
    )
    @settings(max_examples=50)
    def test_errors_can_be_dict_keys(
        self, errors: list[FrozenFluentError]
    ) -> None:
        """Property: Errors can be used as dict keys."""
        error_dict = {e: i for i, e in enumerate(errors)}
        assert len(error_dict) <= len(errors)
        event(f"dict_size={len(error_dict)}")

@pytest.mark.fuzz
class TestEquality:
    """FrozenFluentError equality must be based on content."""

    @given(error=frozen_fluent_errors())
    @settings(max_examples=50)
    def test_error_equals_itself(self, error: FrozenFluentError) -> None:
        """Property: Errors are equal to themselves (reflexivity)."""
        same_ref = error
        assert error == same_ref
        event(f"category={error.category.name}")

    @given(
        message=error_messages(),
        category=error_categories(),
    )
    @settings(max_examples=50)
    def test_identical_errors_are_equal(
        self, message: str, category: ErrorCategory
    ) -> None:
        """Property: Identical errors are equal (symmetry)."""
        error1 = FrozenFluentError(message, category)
        error2 = FrozenFluentError(message, category)

        assert error1 == error2
        assert error2 == error1
        event(f"category={category.name}")

    @given(error=frozen_fluent_errors())
    @settings(max_examples=50)
    def test_error_not_equal_to_string(self, error: FrozenFluentError) -> None:
        """Property: Errors are not equal to strings."""
        assert (error == error.message) is False
        event(f"category={error.category.name}")

    @given(error=frozen_fluent_errors())
    @settings(max_examples=50)
    def test_error_not_equal_to_none(self, error: FrozenFluentError) -> None:
        """Property: Errors are not equal to None (tests __eq__ method)."""
        # pylint: disable=singleton-comparison
        assert (error == None) is False  # noqa: E711 - explicit None comparison intentional
        event(f"category={error.category.name}")

@pytest.mark.fuzz
class TestPropertyAccess:
    """FrozenFluentError properties must be accessible."""

    @given(
        message=error_messages(),
        category=error_categories(),
    )
    @settings(max_examples=50)
    def test_message_property(self, message: str, category: ErrorCategory) -> None:
        """Property: message property returns the message."""
        error = FrozenFluentError(message, category)
        assert error.message == message
        event(f"msg_len={len(message)}")

    @given(
        message=error_messages(),
        category=error_categories(),
    )
    @settings(max_examples=50)
    def test_category_property(self, message: str, category: ErrorCategory) -> None:
        """Property: category property returns the category."""
        error = FrozenFluentError(message, category)
        assert error.category == category
        event(f"category={category.name}")

    @given(
        message=error_messages(),
        category=error_categories(),
        diagnostic=optional_diagnostics(),
    )
    @settings(max_examples=50)
    def test_diagnostic_property(
        self,
        message: str,
        category: ErrorCategory,
        diagnostic: Diagnostic | None,
    ) -> None:
        """Property: diagnostic property returns the diagnostic."""
        error = FrozenFluentError(message, category, diagnostic=diagnostic)
        assert error.diagnostic == diagnostic
        has_diag = diagnostic is not None
        event(f"has_diagnostic={has_diag}")

    @given(
        message=error_messages(),
        category=error_categories(),
        context=optional_contexts(),
    )
    @settings(max_examples=50)
    def test_context_property(
        self,
        message: str,
        category: ErrorCategory,
        context: FrozenErrorContext | None,
    ) -> None:
        """Property: context property returns the context."""
        error = FrozenFluentError(message, category, context=context)
        assert error.context == context
        has_ctx = context is not None
        event(f"has_context={has_ctx}")

@pytest.mark.fuzz
class TestContextConvenienceProperties:
    """FrozenFluentError convenience properties for context fields."""

    @given(
        message=error_messages(),
        category=error_categories(),
    )
    @settings(max_examples=50)
    def test_context_properties_empty_without_context(
        self, message: str, category: ErrorCategory
    ) -> None:
        """Property: Context convenience properties return empty strings without context."""
        error = FrozenFluentError(message, category)

        assert error.fallback_value == ""
        assert error.input_value == ""
        assert error.locale_code == ""
        assert error.parse_type == ""
        event(f"category={category.name}")

    @given(
        message=error_messages(),
        category=error_categories(),
    )
    @settings(max_examples=50)
    def test_context_properties_with_context(
        self, message: str, category: ErrorCategory
    ) -> None:
        """Property: Context convenience properties return context values."""
        context = FrozenErrorContext(
            input_value="test_input",
            locale_code="en_US",
            parse_type="number",
            fallback_value="{!NUMBER}",
        )
        error = FrozenFluentError(message, category, context=context)

        assert error.fallback_value == "{!NUMBER}"
        assert error.input_value == "test_input"
        assert error.locale_code == "en_US"
        assert error.parse_type == "number"
        event(f"category={category.name}")

@pytest.mark.fuzz
class TestStringRepresentation:
    """FrozenFluentError must have sensible string representation."""

    @given(error=frozen_fluent_errors())
    @settings(max_examples=50)
    def test_str_returns_message(self, error: FrozenFluentError) -> None:
        """Property: str() returns the error message."""
        assert str(error) == error.message
        event(f"msg_len={len(error.message)}")

    @given(error=frozen_fluent_errors())
    @settings(max_examples=50)
    def test_repr_is_valid(self, error: FrozenFluentError) -> None:
        """Property: repr() returns a valid representation."""
        r = repr(error)
        assert isinstance(r, str)
        assert "FrozenFluentError" in r
        assert "message=" in r
        assert "category=" in r
        event(f"category={error.category.name}")

class TestEdgeCases:
    """Edge case tests for FrozenFluentError."""

    def test_empty_message(self) -> None:
        """FrozenFluentError accepts empty message."""
        error = FrozenFluentError("", ErrorCategory.REFERENCE)
        assert error.message == ""
        assert error.verify_integrity() is True

    def test_unicode_message(self) -> None:
        """FrozenFluentError handles Unicode messages."""
        error = FrozenFluentError("Error: \u4e2d\u6587\u6587\u672c", ErrorCategory.PARSE)
        assert error.verify_integrity() is True

    def test_emoji_message(self) -> None:
        """FrozenFluentError handles emoji in messages."""
        error = FrozenFluentError("Error \U0001F44D occurred", ErrorCategory.FORMATTING)
        assert error.verify_integrity() is True

    @example(message="Test")
    @given(message=st.text())
    @settings(max_examples=100)
    def test_arbitrary_text_messages(self, message: str) -> None:
        """Property: FrozenFluentError handles arbitrary text."""
        error = FrozenFluentError(message, ErrorCategory.RESOLUTION)
        assert error.verify_integrity() is True
        assert error.message == message
        event(f"msg_len={len(message)}")

    def test_all_categories_work(self) -> None:
        """All ErrorCategory values can be used."""
        for category in ErrorCategory:
            error = FrozenFluentError("test", category)
            assert error.category == category
            assert error.verify_integrity() is True

@pytest.mark.fuzz
class TestExceptionBehavior:
    """FrozenFluentError must behave like a proper exception."""

    @given(error=frozen_fluent_errors())
    @settings(max_examples=50)
    def test_can_be_raised(self, error: FrozenFluentError) -> None:
        """Property: FrozenFluentError can be raised and caught."""
        with pytest.raises(FrozenFluentError) as exc_info:
            raise error
        assert exc_info.value is error
        event(f"category={error.category.name}")

    @given(error=frozen_fluent_errors())
    @settings(max_examples=50)
    def test_can_be_caught_as_exception(self, error: FrozenFluentError) -> None:
        """Property: FrozenFluentError can be caught as Exception."""
        caught: Exception | None = None
        try:
            raise error
        except Exception as exc_info:
            caught = exc_info
        assert caught is error
        event(f"category={error.category.name}")

    @given(error=frozen_fluent_errors())
    @settings(max_examples=50)
    def test_exception_args(self, error: FrozenFluentError) -> None:
        """Property: Exception args contain the message."""
        assert error.args == (error.message,)
        event(f"category={error.category.name}")
