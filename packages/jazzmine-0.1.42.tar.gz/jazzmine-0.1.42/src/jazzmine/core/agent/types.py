from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Awaitable, Callable, TypeAlias

from jazzmine.core.tools.sandbox.config import ExecutionMode


TitleGenerationCallback: TypeAlias = (
    Callable[[str], str | Awaitable[str]]
    | Callable[[str, str], str | Awaitable[str]]
)


@dataclass
class AgentConfig:
    name: str
    personality: str
    agent_id: str
    has_tools: bool = True
    default_sandbox_name: str = "default"
    default_execution_mode: ExecutionMode = ExecutionMode.PLAN
    max_task_calls_per_turn: int = 8
    max_interactive_steps: int = 10
    episodic_same_conv_limit: int = 3
    episodic_prev_conv_limit: int = 2
    semantic_top_k: int = 8
    enable_telemetry: bool = True
    energy_per_1k_tokens_kwh: float = 0.001
    co2_per_kwh_g: float = 500.0
    default_api_co2_g: float = 0.02
    api_energy_kwh_per_mb: float = 0.0001
    telemetry_country_iso_code: str = "USA"
    title_generation: TitleGenerationCallback | None = None


@dataclass
class AgentTurnResult:
    response:      str
    message_id:    str
    trace_id:      str
    invoked_flows: list[str]
    invoked_tools: list[str]
    errors:        list[str]
    turn_number:   int
    is_blocked:    bool = False   # True when input or output was blocked by SecurityGuard


def now_ms() -> int:
    return int(time.time() * 1000)