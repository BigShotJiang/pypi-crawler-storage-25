"""
agent_logger.py
───────────────
Structured logging for jazzmine-core agents.

Design
──────
Correlation is handled entirely by structlog's contextvars mechanism.
`AgentLogger.turn_context()` calls `structlog.contextvars.bind_contextvars()`
at the entry of `agent.chat()`.  Every structlog call anywhere in that
coroutine's call stack — enhancer, orchestrator, executor — automatically
inherits the bound fields (trace_id, conversation_id, user_id, agent_id, turn)
without any parameter passing.

Integration with jazzmine-logging
──────────────────────────────────
Pass a raw jazzmine-logging config dict to `AgentLogger.from_config()`.
If jazzmine-logging is not installed the logger falls back to stdlib
logging with identical structured fields — the agent continues to work.

Usage in AgentBuilder
──────────────────────
    agent, td = await (
        AgentBuilder("Aria", agent_id="aria-v1", personality="...")
        .llm(OpenAILLMConfig(...))
        .logging({
            "name":  "aria",
            "level": "INFO",
            "json":  True,
            "sinks": [
                {"type": "console"},
                {"type": "datadog", "api_key": "...", "service": "aria"},
            ],
        })
        .build()
    )

Semantic log events (all carry correlation fields automatically)
───────────────────────────────────────────────────────────────
  turn_start          — request received
  flow_selected       — FlowSelector chose a flow
  flow_event          — flow started / completed / cancelled / topic_shifted
  task_dispatched     — agent emitted <task>
  script_generated    — LLM produced a script body (per attempt)
  script_executed     — container ran a script (per attempt)
  tool_result         — final outcome of one sandbox task
  llm_call            — one LLM round-trip (agent loop or slot extraction)
  memory_recall       — episodic + semantic recall completed
  turn_end            — response sent, full telemetry summary

Each event name is a constant on the `Event` class so dashboards and
alert rules can hard-code stable strings rather than prose messages.
"""

from __future__ import annotations

import contextlib
import logging
from typing import Any, Dict, List, Optional

import structlog
import structlog.contextvars

_stdlib_log = logging.getLogger(__name__)


# ── Event name constants ───────────────────────────────────────────────────────
# Use these in dashboard queries and alert rules.

class Event:
    TURN_START       = "turn_start"
    TURN_END         = "turn_end"
    FLOW_SELECTED    = "flow_selected"
    FLOW_EVENT       = "flow_event"
    TASK_DISPATCHED  = "task_dispatched"
    SCRIPT_GENERATED = "script_generated"
    SCRIPT_EXECUTED  = "script_executed"
    TOOL_RESULT      = "tool_result"
    LLM_CALL         = "llm_call"
    MEMORY_RECALL    = "memory_recall"
    AGENT_ERROR      = "agent_error"


# ── AgentLogger ────────────────────────────────────────────────────────────────

class AgentLogger:
    """
    Structured logger for a jazzmine Agent.

    All semantic methods emit a consistent JSON event shape:

        {
          "event":           "<Event constant>",
          "timestamp":       "<ISO-8601>",
          "level":           "info | warning | error | debug",
          "trace_id":        "<16-hex>",         ← bound by turn_context()
          "conversation_id": "...",              ← bound by turn_context()
          "user_id":         "...",              ← bound by turn_context()
          "agent_id":        "...",              ← bound by turn_context()
          "turn":            <int>,              ← bound by turn_context()
          ... event-specific fields ...
        }

    The correlation fields are injected automatically by structlog's
    merge_contextvars processor — no need to pass them to every call site.
    """

    def __init__(
        self,
        base_logger: Any = None,   # jazzmine.logging.base.BaseLogger or None
        agent_name:  str = "agent",
    ) -> None:
        self._base       = base_logger
        self._agent_name = agent_name
        # structlog logger — correlation fields come from contextvars
        self._sl = structlog.get_logger(f"jazzmine.agent.{agent_name}")

    # ── Factory methods ────────────────────────────────────────────────────────

    @classmethod
    def noop(cls) -> "AgentLogger":
        """
        Logger that emits only to structlog (no extra sinks).
        Used as the default when no .logging() config is supplied to
        AgentBuilder — the agent works without any logging config changes.
        """
        return cls(base_logger=None)

    @classmethod
    def from_config(
        cls,
        config:     Dict[str, Any],
        agent_name: str = "agent",
    ) -> "AgentLogger":
        """
        Build a fully configured AgentLogger from a jazzmine-logging config dict.

        Falls back gracefully to a noop logger if jazzmine-logging is not
        installed or the config is invalid — the agent always continues to work.

        Example config:
            {
                "name":  "aria",
                "level": "INFO",
                "json":  True,
                "sinks": [
                    {"type": "console"},
                    {"type": "datadog", "api_key": "dd-...", "service": "aria-prod"},
                    {"type": "loki",    "url": "http://loki:3100/loki/api/v1/push"},
                ],
            }
        """
        try:
            from jazzmine.logging.base import BaseLogger
            bl = BaseLogger(config)
            bl.resolve_config()
            _stdlib_log.info("AgentLogger configured with %d sink(s).", len(config.get("sinks", [])))
            return cls(base_logger=bl, agent_name=agent_name)
        except ImportError:
            _stdlib_log.warning(
                "jazzmine-logging not installed — AgentLogger will emit to structlog only. "
                "Install jazzmine-logging to enable Datadog / Loki / Kafka sinks."
            )
            return cls(base_logger=None, agent_name=agent_name)
        except Exception as exc:
            _stdlib_log.warning(
                "AgentLogger.from_config() failed (%s) — falling back to structlog only.", exc
            )
            return cls(base_logger=None, agent_name=agent_name)

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Start async sink workers (call once at startup, via AgentBuilder.build)."""
        if self._base is not None:
            try:
                await self._base.start_async_workers()
            except Exception as exc:
                _stdlib_log.warning("AgentLogger.start() failed: %s", exc)

    async def shutdown(self, timeout: float = 2.0) -> None:
        """Drain all sink queues and close connections (called by Teardown)."""
        if self._base is not None:
            try:
                await self._base.shutdown(timeout=timeout)
            except Exception as exc:
                _stdlib_log.warning("AgentLogger.shutdown() failed: %s", exc)

    # ── Correlation context ────────────────────────────────────────────────────

    @contextlib.contextmanager
    def turn_context(
        self,
        trace_id:        str,
        conversation_id: str,
        user_id:         str,
        agent_id:        str,
        turn_number:     int,
    ):
        """
        Bind correlation fields for the duration of one agent turn.

        Every structlog call anywhere in the call stack — including inside
        AgentLogger, orchestrator.py, executor.py, and any jazzmine.* module
        that uses `structlog.get_logger()` — will automatically carry these
        fields because structlog's `merge_contextvars` processor is already
        wired into jazzmine-logging's processor chain.

        Usage:
            with self._logger.turn_context(
                trace_id=trace_id,
                conversation_id=conversation_id,
                user_id=user_id,
                agent_id=self.config.agent_id,
                turn_number=turn_number,
            ):
                ... all log calls in this block carry the correlation fields ...

        asyncio safety: each asyncio Task has its own copy of the context
        (Python 3.7+ ContextVar semantics), so concurrent chat() calls
        running as separate tasks never interfere with each other's trace_id.
        """
        structlog.contextvars.bind_contextvars(
            trace_id        = trace_id,
            conversation_id = conversation_id,
            user_id         = user_id,
            agent_id        = agent_id,
            turn            = turn_number,
        )
        try:
            yield
        finally:
            # Clear only the fields we bound — leaves any outer bindings intact
            structlog.contextvars.unbind_contextvars(
                "trace_id", "conversation_id", "user_id", "agent_id", "turn"
            )

    # ── Internal emit ──────────────────────────────────────────────────────────

    def _emit(self, level: str, event: str, **fields: Any) -> None:
        """
        Route a structured log event to exactly one backend.

        If BaseLogger is configured, emit only to BaseLogger sinks.
        If BaseLogger is not configured, emit only to structlog.

        This prevents duplicate console output when both structlog and a
        BaseLogger console sink are active.
        """
        if self._base is not None:
            base_fn = getattr(self._base, level, self._base.info)
            try:
                base_fn(event, **fields)
            except Exception as exc:
                _stdlib_log.debug("AgentLogger sink emit failed: %s", exc)
            return

        # structlog fallback — correlation fields come from contextvars automatically
        sl_fn = getattr(self._sl, level, self._sl.info)
        sl_fn(event, **fields)

    # ── Semantic log methods ───────────────────────────────────────────────────
    # Each method maps to one monitoring-relevant event.
    # Fields are kept flat (no nesting) for easy Kibana / Datadog faceting.

    def turn_start(
        self,
        content_len: int,
        has_tools:   bool,
        has_memory:  bool,
    ) -> None:
        """Emitted as soon as chat() begins processing the user message."""
        self._emit(
            "info", Event.TURN_START,
            content_len = content_len,
            has_tools   = has_tools,
            has_memory  = has_memory,
        )

    def memory_recall(
        self,
        same_conv_episodes:  int,
        prev_conv_episodes:  int,
        semantic_terms:      int,
        latency_ms:          int,
    ) -> None:
        """Emitted after episodic + semantic memory recall completes."""
        self._emit(
            "debug", Event.MEMORY_RECALL,
            same_conv_episodes = same_conv_episodes,
            prev_conv_episodes = prev_conv_episodes,
            semantic_terms     = semantic_terms,
            latency_ms         = latency_ms,
        )

    def flow_selected(
        self,
        flow_name:  str,
        flow_type:  str,
        score:      float = 0.0,
        method:     str   = "selector",   # "selector" | "llm_fallback"
    ) -> None:
        """Emitted when FlowSelector picks a flow for the turn."""
        self._emit(
            "info", Event.FLOW_SELECTED,
            flow_name = flow_name,
            flow_type = flow_type,
            score     = round(score, 4),
            method    = method,
        )

    def flow_event(
        self,
        flow_name:  str,
        flow_type:  str,
        event_type: str,   # "started" | "completed" | "cancelled" | "topic_shifted"
    ) -> None:
        """Emitted on every flow lifecycle transition."""
        level = "info" if event_type in ("started", "completed") else "warning"
        self._emit(
            level, Event.FLOW_EVENT,
            flow_name  = flow_name,
            flow_type  = flow_type,
            event_type = event_type,
        )

    def task_dispatched(
        self,
        task_index:   int,
        sandbox:      str,
        mode:         str,   # "plan" | "interactive"
        task_preview: str,
    ) -> None:
        """Emitted when the agent emits a <task> tag inside _run_agent_loop."""
        self._emit(
            "info", Event.TASK_DISPATCHED,
            task_index   = task_index,
            sandbox      = sandbox,
            mode         = mode,
            task_preview = task_preview[:120],   # avoid blowing out log lines
        )

    def llm_call(
        self,
        purpose:           str,   # "agent_loop" | "slot_extraction" | "script_gen" | etc.
        model:             str,
        prompt_tokens:     int,
        completion_tokens: int,
        latency_ms:        int,
        success:           bool,
        error:             Optional[str] = None,
    ) -> None:
        """
        Emitted after every LLM round-trip.

        purpose distinguishes:
          agent_loop       — main reasoning call inside _run_agent_loop
          slot_extraction  — extracting slot values from user message
          script_gen       — generating a sandbox script (orchestrator)
          summarizer       — background conversation summarisation
        """
        level = "warning" if not success else "debug"
        self._emit(
            level, Event.LLM_CALL,
            purpose           = purpose,
            model             = model,
            prompt_tokens     = prompt_tokens,
            completion_tokens = completion_tokens,
            total_tokens      = prompt_tokens + completion_tokens,
            latency_ms        = latency_ms,
            success           = success,
            error             = error,
        )

    def script_generated(
        self,
        sandbox:           str,
        attempt:           int,
        prompt_tokens:     int,
        completion_tokens: int,
        latency_ms:        int,
        model:             str,
        ast_violations:    Optional[List[str]] = None,
    ) -> None:
        """
        Emitted after each script generation LLM call inside ToolOrchestrator.

        ast_violations is None on pass, a non-empty list when the AST
        validator rejected the script — these are retried automatically.
        """
        level = "warning" if ast_violations else "debug"
        self._emit(
            level, Event.SCRIPT_GENERATED,
            sandbox           = sandbox,
            attempt           = attempt,
            prompt_tokens     = prompt_tokens,
            completion_tokens = completion_tokens,
            latency_ms        = latency_ms,
            model             = model,
            ast_ok            = not ast_violations,
            ast_violations    = ast_violations or None,
        )

    def script_executed(
        self,
        sandbox:         str,
        attempt:         int,
        success:         bool,
        duration_ms:     int,
        error:           Optional[str]       = None,
        result_keys:     Optional[List[str]] = None,   # keys present in final_data
    ) -> None:
        """Emitted after each container execution attempt inside ToolOrchestrator."""
        level = "warning" if not success else "debug"
        self._emit(
            level, Event.SCRIPT_EXECUTED,
            sandbox     = sandbox,
            attempt     = attempt,
            success     = success,
            duration_ms = duration_ms,
            error       = error,
            result_keys = result_keys,
        )

    def tool_result(
        self,
        sandbox:        str,
        success:        bool,
        total_attempts: int,
        total_ms:       int,
        mode:           str,            # "plan" | "interactive"
        error:          Optional[str] = None,
    ) -> None:
        """
        Emitted once per sandbox task, after all retries are exhausted.

        This is the outer summary — pair it with the granular script_generated /
        script_executed events via trace_id + task_index for full drill-down.
        """
        level = "warning" if not success else "info"
        self._emit(
            level, Event.TOOL_RESULT,
            sandbox        = sandbox,
            success        = success,
            total_attempts = total_attempts,
            total_ms       = total_ms,
            mode           = mode,
            error          = error,
        )

    def agent_error(self, stage: str, error: str) -> None:
        """
        Emitted when a recoverable error occurs during a turn.

        stage values: "enhancement", "memory_recall", "flow_selection",
                      "agent_llm", "orchestrator", "slot_extraction", "turn_trace"
        """
        self._emit("error", Event.AGENT_ERROR, stage=stage, error=error)

    def turn_end(
        self,
        total_latency_ms:        int,
        total_prompt_tokens:     int,
        total_completion_tokens: int,
        invoked_flows:           List[str],
        invoked_tools:           List[str],
        errors:                  List[str],
        response_len:            int,
        total_energy_kwh:        float = 0.0,
        total_co2_g:             float = 0.0,
    ) -> None:
        """
        Emitted at the end of every turn.

        This is the single most useful event for monitoring dashboards:
        one row per turn with latency, token cost, which flows/tools ran,
        and whether anything went wrong.
        """
        level = "warning" if errors else "info"
        self._emit(
            level, Event.TURN_END,
            total_latency_ms        = total_latency_ms,
            total_prompt_tokens     = total_prompt_tokens,
            total_completion_tokens = total_completion_tokens,
            total_tokens            = total_prompt_tokens + total_completion_tokens,
            invoked_flows           = invoked_flows,
            invoked_tools           = invoked_tools,
            error_count             = len(errors),
            errors                  = errors or None,
            response_len            = response_len,
            total_energy_kwh        = total_energy_kwh,
            total_co2_g             = total_co2_g,
        )