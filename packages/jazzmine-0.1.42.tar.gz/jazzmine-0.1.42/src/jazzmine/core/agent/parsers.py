from __future__ import annotations

import json
import re

_TASK_RE = re.compile(
    r'<task\b(?P<attrs>[^>]*)(?:>(?P<body>.*?)</task\s*>|/>)',
    re.DOTALL | re.IGNORECASE,
)
_RESPONSE_RE = re.compile(
    r'<response\b[^>]*>(?P<body>.*?)</response\s*>',
    re.DOTALL | re.IGNORECASE,
)
_RESPONSE_START_TAG_RE = re.compile(r'^\s*<response\b[^>]*>\s*', re.IGNORECASE)
_RESPONSE_END_TAG_RE = re.compile(r'\s*</response\s*>\s*$', re.IGNORECASE)
_FRAMEWORK_TAGS = (
    "response",
    "task",
    "tool_execution",
    "confirm",
    "cancel",
    "flow_complete",
    "pending_confirmation",
    "pending_slots",
    "required_tools_pending",
    "current_turn_tool_calls",
    "completed_tool_calls",
    "known_data",
    "state",
    "domain_terms",
    "entities_in_context",
    "available_sandboxes",
    "user_message",
    "instruction",
    "slot",
    "tool",
)
_FRAMEWORK_TAG_RE = re.compile(
    r'</?(?:' + "|".join(re.escape(tag) for tag in _FRAMEWORK_TAGS) + r')\b[^>]*>',
    re.IGNORECASE,
)
_CONFIRM_RE = re.compile(r'<confirm\b[^>]*/?>', re.IGNORECASE)
_CANCEL_RE = re.compile(r'<cancel\b[^>]*/?>', re.IGNORECASE)
_FLOW_COMPLETE_RE = re.compile(r'<flow_complete\b[^>]*/?>', re.IGNORECASE)
_CONTROL_TAG_RE = re.compile(r'</?(?:confirm|cancel|flow_complete)\b[^>]*>', re.IGNORECASE)
_TOOL_EXEC_RE = re.compile(
    r'<tool_execution\b(?P<attrs>[^>]*)(?:>(?P<body>.*?)</tool_execution\s*>|/>)',
    re.DOTALL | re.IGNORECASE,
)
_TOOL_RESULT_RE = re.compile(
    r'<(?:r|result)\b[^>]*>\s*(.*?)\s*</(?:r|result)\s*>',
    re.DOTALL | re.IGNORECASE,
)
_TOOL_ERROR_RE = re.compile(
    r'<(?:e|error)\b[^>]*>\s*(.*?)\s*</(?:e|error)\s*>',
    re.DOTALL | re.IGNORECASE,
)
_ATTR_RE = re.compile(
    r'([A-Za-z_][\w:.-]*)\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s"\'=<>`]+))',
    re.DOTALL,
)


def _strip_response_boundary_tags(text: str) -> str:
    # Smaller models sometimes leak wrapper tags in plain text output.
    # Strip only boundary tags so any intentional inline literal is preserved.
    stripped = _RESPONSE_START_TAG_RE.sub("", text, count=1)
    stripped = _RESPONSE_END_TAG_RE.sub("", stripped, count=1)
    return stripped.strip()


def _strip_framework_response_tags(text: str) -> str:
    stripped = _FRAMEWORK_TAG_RE.sub("", text)
    # Keep markdown/newlines readable while removing framework tag artifacts.
    stripped = re.sub(r"[ \t]+\n", "\n", stripped)
    stripped = re.sub(r"\n{3,}", "\n\n", stripped)
    return stripped.strip()


def _collapse_consecutive_duplicate_content(text: str) -> str:
    cleaned = (text or "").strip()
    if not cleaned:
        return cleaned

    # First collapse repeated paragraphs separated by blank lines.
    paragraphs = re.split(r"\n{2,}", cleaned)
    deduped_paragraphs: list[str] = []
    prev_key = ""
    for paragraph in paragraphs:
        paragraph_clean = paragraph.strip()
        if not paragraph_clean:
            continue
        key = re.sub(r"\s+", " ", paragraph_clean).strip().lower()
        if key == prev_key:
            continue
        deduped_paragraphs.append(paragraph_clean)
        prev_key = key

    merged = "\n\n".join(deduped_paragraphs) if deduped_paragraphs else ""
    if not merged:
        return ""

    # Then collapse immediate duplicate lines inside the remaining content.
    lines = merged.splitlines()
    deduped_lines: list[str] = []
    prev_line_key = ""
    for line in lines:
        line_clean = line.strip()
        if not line_clean:
            deduped_lines.append("")
            prev_line_key = ""
            continue
        line_key = re.sub(r"\s+", " ", line_clean).strip().lower()
        if line_key == prev_line_key:
            continue
        deduped_lines.append(line)
        prev_line_key = line_key

    merged_lines = "\n".join(deduped_lines)
    merged_lines = re.sub(r"\n{3,}", "\n\n", merged_lines)
    return merged_lines.strip()


def _parse_tag_attributes(raw_attrs: str) -> dict[str, str]:
    attributes: dict[str, str] = {}
    for match in _ATTR_RE.finditer(raw_attrs or ""):
        key = match.group(1).strip().lower()
        value = next((group for group in match.groups()[1:] if group is not None), "")
        attributes[key] = value.strip()
    return attributes


def _to_bool(value: object) -> bool | None:
    if value is None:
        return None
    normalized = str(value).strip().lower()
    if normalized in {"1", "true", "yes", "y", "on"}:
        return True
    if normalized in {"0", "false", "no", "n", "off"}:
        return False
    return None


def _to_int(value: object) -> int | None:
    try:
        if value is None or str(value).strip() == "":
            return None
        return int(str(value).strip())
    except (TypeError, ValueError):
        return None


def _truncate(text: str, limit: int = 280) -> str:
    compact = re.sub(r"\s+", " ", text).strip()
    if len(compact) <= limit:
        return compact
    return compact[: limit - 3].rstrip() + "..."


def _format_scalar(value: object) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    return _truncate(str(value), limit=120)


def _try_json_parse(payload: str) -> object | None:
    try:
        return json.loads(payload)
    except json.JSONDecodeError:
        return None


def _format_generic_payload(payload: object, detail_suffix: str) -> str:
    if isinstance(payload, dict):
        if not payload:
            sentence = "I completed the request and received an empty object."
        else:
            snippets: list[str] = []
            for key, value in payload.items():
                label = str(key).replace("_", " ")
                if isinstance(value, list):
                    snippets.append(f"{label}: {len(value)} item(s)")
                elif isinstance(value, dict):
                    snippets.append(f"{label}: {len(value)} field(s)")
                else:
                    snippets.append(f"{label}: {_format_scalar(value)}")
                if len(snippets) >= 6:
                    break

            sentence = "I completed the request. Key results: " + "; ".join(snippets) + "."
    elif isinstance(payload, list):
        sentence = f"I completed the request and received {len(payload)} result item(s)."
        if payload:
            sample = ", ".join(_format_scalar(item) for item in payload[:3])
            sentence += f" Sample: {sample}."
    else:
        sentence = f"I completed the request. Result: {_format_scalar(payload)}"

    if detail_suffix:
        sentence += f" Execution details{detail_suffix}."
    return sentence


def _extract_tool_execution_parts(block: str) -> tuple[dict[str, str], str]:
    match = _TOOL_EXEC_RE.search(block)
    if match:
        attrs = _parse_tag_attributes(match.group("attrs") or "")
        body = match.group("body") or ""
        return attrs, body

    open_tag = re.search(r'<tool_execution\b([^>]*)>', block, flags=re.IGNORECASE)
    attrs = _parse_tag_attributes(open_tag.group(1) if open_tag else "")
    return attrs, block


def _format_tool_execution_block(block: str) -> str:
    attrs, body = _extract_tool_execution_parts(block)

    parsed_success = _to_bool(attrs.get("success"))
    if parsed_success is None:
        success = _TOOL_ERROR_RE.search(body) is None
    else:
        success = parsed_success

    attempts = _to_int(attrs.get("attempts"))
    elapsed_ms = _to_int(attrs.get("ms"))

    details: list[str] = []
    if attempts is not None:
        details.append(f"{attempts} attempt(s)")
    if elapsed_ms is not None:
        details.append(f"{elapsed_ms} ms")
    detail_suffix = f" ({', '.join(details)})" if details else ""

    if success:
        payload_match = _TOOL_RESULT_RE.search(body)
        payload = payload_match.group(1).strip() if payload_match else ""
        if not payload:
            return f"I completed the request successfully{detail_suffix}."

        parsed = _try_json_parse(payload)
        if parsed is None:
            return (
                f"I completed the request successfully{detail_suffix}. "
                f"Result: {_truncate(payload)}"
            )

        return _format_generic_payload(parsed, detail_suffix)

    error_match = _TOOL_ERROR_RE.search(body)
    error_text = error_match.group(1).strip() if error_match else "Unknown tool error."
    return f"I could not complete the request{detail_suffix}. Error: {_truncate(error_text)}"


def _fallback_without_response_tags(clean: str) -> str:
    matches = list(_TOOL_EXEC_RE.finditer(clean))
    if not matches:
        return clean.strip()

    plain_text = _TOOL_EXEC_RE.sub("", clean).strip()
    if plain_text:
        return plain_text

    return _format_tool_execution_block(matches[-1].group(0))


def parse_task_request(text: str) -> tuple[str, str, str] | None:
    match = _TASK_RE.search(text)
    if not match:
        return None

    attrs = _parse_tag_attributes(match.group("attrs") or "")
    sandbox = (attrs.get("sandbox") or "").strip()
    mode = (attrs.get("mode") or "").strip()
    task = (match.group("body") or "").strip()
    return sandbox, mode, task


def extract_response(text: str) -> str:
    match = _RESPONSE_RE.search(text)
    if match:
        body = _strip_response_boundary_tags(match.group("body"))
        clean_body = _strip_framework_response_tags(body)
        return _collapse_consecutive_duplicate_content(clean_body)
    clean = _TASK_RE.sub("", text)
    clean = _CONTROL_TAG_RE.sub("", clean)
    fallback = _strip_response_boundary_tags(_fallback_without_response_tags(clean))
    clean_fallback = _strip_framework_response_tags(fallback)
    return _collapse_consecutive_duplicate_content(clean_fallback)