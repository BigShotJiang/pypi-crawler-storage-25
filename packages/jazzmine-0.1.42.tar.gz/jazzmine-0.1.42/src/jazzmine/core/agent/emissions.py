from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

DEFAULT_API_CO2_G = 0.02


@dataclass
class EnergyTracker:
    label: str
    enabled: bool = True
    country_iso_code: str = "USA"
    co2_per_kwh_g: float = 500.0

    energy_kwh: float = 0.0
    co2_g: float = 0.0
    duration_ms: int = 0

    _tracker: Any = None
    _started_at: float = 0.0

    def __enter__(self) -> "EnergyTracker":
        self._started_at = time.monotonic()
        self.energy_kwh = 0.0
        self.co2_g = 0.0
        self.duration_ms = 0

        if not self.enabled:
            return self

        self._tracker = _build_offline_tracker(self.country_iso_code)
        if self._tracker is not None:
            try:
                self._tracker.start()
            except Exception:
                self._tracker = None
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.duration_ms = int((time.monotonic() - self._started_at) * 1000)

        if not self.enabled or self._tracker is None:
            return

        emissions_kg = 0.0
        try:
            emissions_kg = float(self._tracker.stop() or 0.0)
        except Exception:
            emissions_kg = 0.0

        self.co2_g = max(0.0, emissions_kg * 1000.0)

        final_data = getattr(self._tracker, "final_emissions_data", None)
        energy_kwh = getattr(final_data, "energy_consumed", 0.0) if final_data is not None else 0.0
        self.energy_kwh = max(0.0, float(energy_kwh or 0.0))

        if self.energy_kwh <= 0.0 and self.co2_g > 0 and self.co2_per_kwh_g > 0:
            self.energy_kwh = self.co2_g / self.co2_per_kwh_g


def estimate_api_emissions(
    request_bytes: int,
    response_bytes: int,
    co2_per_kwh_g: float,
    default_api_co2_g: float = DEFAULT_API_CO2_G,
    api_energy_kwh_per_mb: float = 0.0001,
) -> dict[str, float]:
    req = max(0, int(request_bytes or 0))
    resp = max(0, int(response_bytes or 0))
    total_bytes = req + resp

    if total_bytes <= 0:
        co2_g = max(0.0, float(default_api_co2_g))
        energy_kwh = 0.0
        if co2_per_kwh_g > 0:
            energy_kwh = co2_g / co2_per_kwh_g
        return {
            "energy_kwh": max(0.0, float(energy_kwh)),
            "co2_g": co2_g,
            "request_bytes": float(req),
            "response_bytes": float(resp),
        }

    total_mb = total_bytes / (1024.0 * 1024.0)
    energy_kwh = max(0.0, float(total_mb * api_energy_kwh_per_mb))
    co2_g = max(0.0, float(energy_kwh * co2_per_kwh_g))

    return {
        "energy_kwh": energy_kwh,
        "co2_g": co2_g,
        "request_bytes": float(req),
        "response_bytes": float(resp),
    }


def _build_offline_tracker(country_iso_code: str):
    try:
        from codecarbon import OfflineEmissionsTracker
    except Exception:
        return None

    try:
        return OfflineEmissionsTracker(
            country_iso_code=country_iso_code,
            save_to_file=False,
            log_level="error",
            allow_multiple_runs=True,
        )
    except TypeError:
        try:
            return OfflineEmissionsTracker(
                country_iso_code=country_iso_code,
                save_to_file=False,
                log_level="error",
            )
        except Exception:
            return None
    except Exception:
        return None
