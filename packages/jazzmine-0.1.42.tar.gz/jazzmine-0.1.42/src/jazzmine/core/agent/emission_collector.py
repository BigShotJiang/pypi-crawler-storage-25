from __future__ import annotations

import json
from collections import defaultdict, deque
from pathlib import Path
from threading import Lock
from typing import Any

from jazzmine.core.message_store.models import EmissionRecord


class EmissionsCollector:
    def __init__(self, max_records: int = 10_000, jsonl_path: str | None = None) -> None:
        self._records: deque[dict[str, Any]] = deque(maxlen=max_records)
        self._lock = Lock()
        self._jsonl_path = Path(jsonl_path).expanduser() if jsonl_path else None

        if self._jsonl_path is not None:
            self._jsonl_path.parent.mkdir(parents=True, exist_ok=True)

    def add_records(
        self,
        conversation_id: str,
        turn_number: int,
        records: list[EmissionRecord],
    ) -> None:
        if not records:
            return

        with self._lock:
            for record in records:
                item = {
                    "conversation_id": conversation_id,
                    "turn_number": turn_number,
                    "record": record,
                }
                self._records.append(item)
                self._append_jsonl(item)

    def total_co2_for_conversation(self, conversation_id: str) -> float:
        records = self._records_for_conversation(conversation_id)
        return float(
            sum(
                r["record"].co2_g
                for r in records
                if r["record"].metadata.get("count_in_totals", True)
            )
        )

    def breakdown_per_step(self, conversation_id: str) -> dict[str, float]:
        records = self._records_for_conversation(conversation_id)
        out: dict[str, float] = defaultdict(float)
        for item in records:
            record: EmissionRecord = item["record"]
            step_index = record.metadata.get("task_index")
            if step_index is None:
                step_index = record.metadata.get("step_index", "unknown")
            out[str(step_index)] += float(record.co2_g)
        return dict(out)

    def top_emitters(self, conversation_id: str, limit: int = 5) -> list[dict[str, Any]]:
        records = self._records_for_conversation(conversation_id)
        grouped: dict[str, float] = defaultdict(float)

        for item in records:
            record: EmissionRecord = item["record"]
            label = str(
                record.metadata.get("name")
                or record.metadata.get("purpose")
                or record.metadata.get("host")
                or record.type
            )
            grouped[label] += float(record.co2_g)

        ordered = sorted(grouped.items(), key=lambda x: x[1], reverse=True)
        return [{"emitter": name, "co2_g": co2} for name, co2 in ordered[: max(1, int(limit))]]

    def _records_for_conversation(self, conversation_id: str) -> list[dict[str, Any]]:
        with self._lock:
            return [item for item in self._records if item["conversation_id"] == conversation_id]

    def _append_jsonl(self, item: dict[str, Any]) -> None:
        if self._jsonl_path is None:
            return

        payload = {
            "conversation_id": item["conversation_id"],
            "turn_number": item["turn_number"],
            "record": item["record"].model_dump(mode="json"),
        }
        with self._jsonl_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(payload, ensure_ascii=True) + "\n")
