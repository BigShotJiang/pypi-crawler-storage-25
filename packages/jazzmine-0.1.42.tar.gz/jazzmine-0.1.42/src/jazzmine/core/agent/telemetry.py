from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Iterable

from jazzmine.core.agent.emissions import estimate_api_emissions
from jazzmine.core.llm.emissions import estimate_llm_emissions
from jazzmine.core.llm.utils import estimate_tokens

from jazzmine.core.message_store.models import (
    ConfirmationEvent,
    EmissionRecord,
    FlowEvent,
    LLMCallRecord,
    ScriptGenAttempt,
    SlotEvent,
    TaskEmission,
    ToolTrace,
)
from jazzmine.core.tools.orchestrator import RunRecord


@dataclass
class TurnTelemetry:
    enable_telemetry: bool = True
    energy_per_1k_tokens_kwh: float = 0.001
    co2_per_kwh_g: float = 500.0
    default_api_co2_g: float = 0.02
    api_energy_kwh_per_mb: float = 0.0001

    started_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))
    llm_calls: list[LLMCallRecord] = field(default_factory=list)
    task_emissions: list[TaskEmission] = field(default_factory=list)
    tool_traces: list[ToolTrace] = field(default_factory=list)
    emission_records: list[EmissionRecord] = field(default_factory=list)
    slot_events: list[SlotEvent] = field(default_factory=list)
    confirmation_events: list[ConfirmationEvent] = field(default_factory=list)
    flow_events: list[FlowEvent] = field(default_factory=list)

    def record_llm_ok(self, purpose: str, response: Any, latency_ms: int) -> None:
        call = LLMCallRecord(
            purpose=purpose,
            model=getattr(response, "model", ""),
            prompt_tokens=getattr(response.usage, "prompt_tokens", 0),
            completion_tokens=getattr(response.usage, "completion_tokens", 0),
            total_tokens=getattr(response.usage, "total_tokens", 0),
            latency_ms=latency_ms,
            timestamp_ms=int(time.time() * 1000),
            success=True,
        )
        self.llm_calls.append(call)

        if not self.enable_telemetry:
            return

        token_count = int(call.total_tokens or 0)
        if token_count <= 0:
            token_count = estimate_tokens(
                text=getattr(response, "text", "") or "",
                model=call.model,
            )

        llm_estimate = estimate_llm_emissions(
            tokens=token_count,
            energy_per_1k_tokens_kwh=self.energy_per_1k_tokens_kwh,
            co2_per_kwh_g=self.co2_per_kwh_g,
        )
        self.record_emission(
            EmissionRecord(
                type="llm",
                energy_kwh=llm_estimate["energy_kwh"],
                co2_g=llm_estimate["co2_g"],
                metadata={
                    "name": f"llm:{purpose}",
                    "purpose": purpose,
                    "model": call.model,
                    "tokens": llm_estimate["tokens"],
                    "call_id": call.call_id,
                    "count_in_totals": True,
                },
            )
        )

        api_metrics = getattr(response, "api_metrics", None) or {}
        if api_metrics:
            req_bytes = int(api_metrics.get("request_bytes", 0) or 0)
            resp_bytes = int(api_metrics.get("response_bytes", 0) or 0)
            api_estimate = estimate_api_emissions(
                request_bytes=req_bytes,
                response_bytes=resp_bytes,
                co2_per_kwh_g=self.co2_per_kwh_g,
                default_api_co2_g=self.default_api_co2_g,
                api_energy_kwh_per_mb=self.api_energy_kwh_per_mb,
            )
            self.record_emission(
                EmissionRecord(
                    type="api",
                    energy_kwh=api_estimate["energy_kwh"],
                    co2_g=api_estimate["co2_g"],
                    metadata={
                        "name": f"api:{api_metrics.get('provider', 'llm_provider')}",
                        "source": "llm_provider",
                        "purpose": purpose,
                        "model": call.model,
                        "request_bytes": req_bytes,
                        "response_bytes": resp_bytes,
                        "status_code": api_metrics.get("status_code"),
                        "endpoint": api_metrics.get("endpoint"),
                        "count_in_totals": False,
                    },
                )
            )

    def record_llm_error(self, purpose: str, error: Exception, model: str = "") -> None:
        self.llm_calls.append(
            LLMCallRecord(
                purpose=purpose,
                model=model,
                latency_ms=0,
                timestamp_ms=int(time.time() * 1000),
                success=False,
                error=str(error),
            )
        )

    def add_tool_trace(self, run: RunRecord, task_index: int, description: str) -> None:
        self.tool_traces.append(run_record_to_tool_trace(run, task_index, description))

        if not self.enable_telemetry:
            return

        for attempt in _iter_run_attempts(run):
            tokens = int((attempt.prompt_tokens or 0) + (attempt.completion_tokens or 0))
            if tokens > 0:
                llm_estimate = estimate_llm_emissions(
                    tokens=tokens,
                    energy_per_1k_tokens_kwh=self.energy_per_1k_tokens_kwh,
                    co2_per_kwh_g=self.co2_per_kwh_g,
                )
                self.record_emission(
                    EmissionRecord(
                        type="llm",
                        energy_kwh=llm_estimate["energy_kwh"],
                        co2_g=llm_estimate["co2_g"],
                        metadata={
                            "name": "llm:script_generation",
                            "purpose": "script_generation",
                            "task_index": task_index,
                            "sandbox": run.sandbox_name,
                            "attempt": attempt.attempt,
                            "model": attempt.model,
                            "tokens": llm_estimate["tokens"],
                            "count_in_totals": True,
                        },
                    )
                )

            api_metrics = getattr(attempt, "api_metrics", None) or {}
            if api_metrics:
                req_bytes = int(api_metrics.get("request_bytes", 0) or 0)
                resp_bytes = int(api_metrics.get("response_bytes", 0) or 0)
                api_estimate = estimate_api_emissions(
                    request_bytes=req_bytes,
                    response_bytes=resp_bytes,
                    co2_per_kwh_g=self.co2_per_kwh_g,
                    default_api_co2_g=self.default_api_co2_g,
                    api_energy_kwh_per_mb=self.api_energy_kwh_per_mb,
                )
                self.record_emission(
                    EmissionRecord(
                        type="api",
                        energy_kwh=api_estimate["energy_kwh"],
                        co2_g=api_estimate["co2_g"],
                        metadata={
                            "name": f"api:{api_metrics.get('provider', 'llm_provider')}",
                            "source": "llm_provider",
                            "purpose": "script_generation",
                            "task_index": task_index,
                            "sandbox": run.sandbox_name,
                            "attempt": attempt.attempt,
                            "request_bytes": req_bytes,
                            "response_bytes": resp_bytes,
                            "status_code": api_metrics.get("status_code"),
                            "endpoint": api_metrics.get("endpoint"),
                            "count_in_totals": False,
                        },
                    )
                )

            api_events = getattr(attempt, "api_events", []) or []
            for event in api_events:
                req_bytes = int(event.get("request_bytes", 0) or 0)
                resp_bytes = int(event.get("response_bytes", 0) or 0)
                api_estimate = estimate_api_emissions(
                    request_bytes=req_bytes,
                    response_bytes=resp_bytes,
                    co2_per_kwh_g=self.co2_per_kwh_g,
                    default_api_co2_g=self.default_api_co2_g,
                    api_energy_kwh_per_mb=self.api_energy_kwh_per_mb,
                )
                metadata = dict(event)
                metadata.update(
                    {
                        "name": f"api:{event.get('host', 'unknown')}",
                        "source": "sandbox_proxy",
                        "task_index": task_index,
                        "sandbox": run.sandbox_name,
                        "attempt": attempt.attempt,
                        "count_in_totals": True,
                    }
                )
                self.record_emission(
                    EmissionRecord(
                        type="api",
                        energy_kwh=api_estimate["energy_kwh"],
                        co2_g=api_estimate["co2_g"],
                        metadata=metadata,
                    )
                )

    def record_emission(self, emission: EmissionRecord) -> None:
        self.emission_records.append(emission)

    def total_prompt_tokens(self) -> int:
        gen = sum(sum(a.prompt_tokens for a in tt.generation_attempts) for tt in self.tool_traces)
        return sum(c.prompt_tokens for c in self.llm_calls) + gen

    def total_completion_tokens(self) -> int:
        gen = sum(sum(a.completion_tokens for a in tt.generation_attempts) for tt in self.tool_traces)
        return sum(c.completion_tokens for c in self.llm_calls) + gen

    def total_energy_kwh(self) -> float:
        return float(
            sum(
                r.energy_kwh
                for r in self.emission_records
                if r.metadata.get("count_in_totals", True)
            )
        )

    def total_co2_g(self) -> float:
        return float(
            sum(
                r.co2_g
                for r in self.emission_records
                if r.metadata.get("count_in_totals", True)
            )
        )


def run_record_to_tool_trace(run: RunRecord, task_index: int, description: str) -> ToolTrace:
    gen_attempts: list[ScriptGenAttempt] = []
    api_calls: list[dict] = []

    if run.mode == "plan":
        for a in run.attempts:
            api_calls.extend(getattr(a, "api_events", []) or [])
            gen_attempts.append(
                ScriptGenAttempt(
                    attempt=a.attempt,
                    prompt_tokens=a.prompt_tokens,
                    completion_tokens=a.completion_tokens,
                    latency_ms=a.generation_latency_ms,
                    success=bool(a.success) and not bool(a.ast_violations),
                    parse_error=("; ".join(a.ast_violations) if a.ast_violations else None),
                )
            )
    else:
        global_attempt = 0
        for step in run.steps:
            for a in step.attempts:
                api_calls.extend(getattr(a, "api_events", []) or [])
                global_attempt += 1
                gen_attempts.append(
                    ScriptGenAttempt(
                        attempt=global_attempt,
                        prompt_tokens=a.prompt_tokens,
                        completion_tokens=a.completion_tokens,
                        latency_ms=a.generation_latency_ms,
                        success=bool(a.success) and not bool(a.ast_violations),
                        parse_error=("; ".join(a.ast_violations) if a.ast_violations else None),
                    )
                )

    all_scripts = run.all_scripts
    final_script = all_scripts[-1] if all_scripts else None

    gen_total_tokens = run.total_prompt_tokens + run.total_completion_tokens
    gen_latency_ms = sum(a.latency_ms for a in gen_attempts)

    exec_latency_ms = 0
    if run.mode == "plan" and run.attempts:
        exec_latency_ms = run.attempts[-1].duration_ms
    else:
        for step in run.steps:
            if step.final_attempt:
                exec_latency_ms += step.final_attempt.duration_ms

    all_intermediates: list[dict] = []
    if run.mode == "plan":
        for a in run.attempts:
            all_intermediates.extend(a.intermediates)
    else:
        for step in run.steps:
            for a in step.attempts:
                all_intermediates.extend(a.intermediates)

    return ToolTrace(
        task_index=task_index,
        sandbox=run.sandbox_name,
        mode=run.mode,
        description=description,
        generation_attempts=gen_attempts,
        final_script=final_script,
        generation_total_tokens=gen_total_tokens,
        generation_latency_ms=gen_latency_ms,
        execution_id=run.run_id,
        success=run.success,
        final_data=run.final_data,
        intermediates=all_intermediates,
        error=run.error,
        traceback=run.last_traceback(),
        execution_latency_ms=exec_latency_ms,
        api_calls=api_calls,
        total_latency_ms=run.total_ms,
    )


def _iter_run_attempts(run: RunRecord) -> Iterable[Any]:
    if run.mode == "plan":
        return list(run.attempts)
    return [a for step in run.steps for a in step.attempts]
