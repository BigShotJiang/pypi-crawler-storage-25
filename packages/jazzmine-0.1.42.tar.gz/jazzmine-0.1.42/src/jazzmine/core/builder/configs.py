from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

@dataclass
class JsonStorage:
    """
    File-backed JSON store — suitable for development and low-volume use.
    Leave path="" to auto-create a temp file (cleaned up on teardown).
    """
    path: str = ""

    @property
    def backend(self) -> Literal["json"]: return "json"

    def to_init_config(self) -> dict:
        return {"storage": "json", "path": self.path}


@dataclass
class PostgresStorage:
    """
    PostgreSQL-backed store.
    dsn format: "postgresql://user:pass@host:5432/dbname"
    """
    dsn:      str
    pool_min: int = 2
    pool_max: int = 10

    @property
    def backend(self) -> Literal["postgres"]: return "postgres"

    def to_init_config(self) -> dict:
        return {
            "storage":  "postgres",
            "dsn":      self.dsn,
            "pool_min": self.pool_min,
            "pool_max": self.pool_max,
        }


@dataclass
class MongoDBStorage:
    """
    MongoDB-backed store.
    uri format: "mongodb://user:pass@host:27017"
    """
    uri: str
    db:  str = "jazzmine"

    @property
    def backend(self) -> Literal["mongodb"]: return "mongodb"

    def to_init_config(self) -> dict:
        return {"storage": "mongodb", "uri": self.uri, "db": self.db}


# Union type alias — any of the three concrete storage configs
StorageConfig = JsonStorage | PostgresStorage | MongoDBStorage


# ══════════════════════════════════════════════════════════════════════════════
# Other config value objects
# ══════════════════════════════════════════════════════════════════════════════

# ── LLM provider configs — typed discriminated union ─────────────────────────
# Pass one of these to AgentBuilder.llm() or AgentBuilder.script_gen_llm().
# Common fields (temperature, max_tokens, timeout) are on every config.
# Provider-specific fields (api_key, region, endpoint…) are only on the
# config that needs them — no accidental confusion between providers.

@dataclass
class OpenAILLMConfig:
    """
    Any OpenAI-compatible API: NVIDIA NIM, Together, Groq, Mistral,
    DeepSeek, Ollama, LM Studio, or the original OpenAI endpoint.

    chat_endpoint  Override the default /v1/chat/completions path when the
                   provider uses a different route.
    top_p          Nucleus sampling probability. None = provider default.
    """
    model:         str
    api_key:       str
    base_url:      str
    temperature:   float       = 0.5
    max_tokens:    int         = 1024
    timeout:       float       = 90.0
    top_p:         float|None  = None
    chat_endpoint: str         = "/v1/chat/completions"

    @property
    def provider(self) -> str: return "openai"


@dataclass
class AnthropicLLMConfig:
    """
    Anthropic Claude via the Anthropic API.
    base_url can be overridden for Anthropic-compatible proxies.
    max_tokens is required by the Anthropic API; defaults to 1024.
    """
    model:       str
    api_key:     str
    base_url:    str   = "https://api.anthropic.com"
    temperature: float = 0.5
    max_tokens:  int   = 1024
    timeout:     float = 90.0

    @property
    def provider(self) -> str: return "anthropic"


@dataclass
class GeminiLLMConfig:
    """
    Google Gemini via the Generative Language REST API.
    model examples: "gemini-1.5-pro", "gemini-2.0-flash"
    """
    model:       str
    api_key:     str
    base_url:    str   = "https://generativelanguage.googleapis.com"
    temperature: float = 0.5
    max_tokens:  int   = 1024
    timeout:     float = 90.0

    @property
    def provider(self) -> str: return "gemini"


@dataclass
class AzureLLMConfig:
    """
    Azure OpenAI via a named deployment endpoint.

    api_version  Azure REST API version string.
    endpoint     Your Azure resource URL, e.g. "https://my-res.openai.azure.com"
    deployment_name  The deployment name in Azure (also used as the model name).
    """
    api_key:          str
    endpoint:         str
    deployment_name:  str
    api_version:      str   = "2024-02-15-preview"
    temperature:      float = 0.5
    max_tokens:       int   = 1024
    timeout:          float = 90.0

    @property
    def provider(self) -> str: return "azure"


@dataclass
class CohereLLMConfig:
    """
    Cohere Command models via the Cohere v2 REST API.
    model examples: "command-r-plus", "command-r"
    """
    api_key:     str
    model:       str   = "command-r-plus"
    temperature: float = 0.5
    max_tokens:  int   = 1024
    timeout:     float = 90.0

    @property
    def provider(self) -> str: return "cohere"


@dataclass
class BedrockLLMConfig:
    """
    AWS Bedrock Converse API (Claude, Llama, Titan, Mistral, …).
    Uses boto3/aioboto3 — AWS credentials must be configured via
    environment variables, IAM role, or a shared credentials file.

    region_name  AWS region where your Bedrock endpoint is active.
    model        Bedrock model ID, e.g. "anthropic.claude-3-5-sonnet-20241022-v2:0"
    """
    model:       str
    region_name: str
    temperature: float = 0.5
    max_tokens:  int   = 1024
    timeout:     float = 90.0  # unused by boto3 directly, kept for API consistency

    @property
    def provider(self) -> str: return "bedrock"


@dataclass
class LocalLLMConfig:
    """
    A locally running binary invoked via subprocess (e.g. llama.cpp).

    binary_path  Absolute path to the executable.
                 Must accept: <binary> -p "<prompt>" and write to stdout.
    model        A label for telemetry — not passed to the binary.
    """
    binary_path: str
    model:       str   = "local"
    temperature: float = 0.5
    max_tokens:  int   = 1024
    timeout:     float = 90.0  # not enforced by subprocess; informational only

    @property
    def provider(self) -> str: return "local"


# Union type — any provider config is accepted by .llm() and .script_gen_llm()
LLMConfig = (
    OpenAILLMConfig | AnthropicLLMConfig | GeminiLLMConfig | AzureLLMConfig
    | CohereLLMConfig | BedrockLLMConfig | LocalLLMConfig
)


# ══════════════════════════════════════════════════════════════════════════════
# EmbeddingConfig
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class EmbeddingConfig:
        """
        Configuration for automatic local embedding model setup.

        Set via AgentBuilder.embeddings(). When used, AgentBuilder will
        automatically download, export, and wire up the embedding model
        before memory is initialised — no manual path passing needed.

        ── Model ─────────────────────────────────────────────────────────────────
        model_id      HuggingFace model ID to download and export.
                                    Default "BAAI/bge-small-en-v1.5" (384-dim, fast, production-ready).

                                    Common alternatives and their vector sizes:
                                        "BAAI/bge-small-en-v1.5"                  384-dim (default, fast)
                                        "BAAI/bge-base-en-v1.5"                   768-dim (higher quality)
                                        "BAAI/bge-large-en-v1.5"                  1024-dim (best quality)
                                        "sentence-transformers/all-MiniLM-L6-v2"  384-dim
                                        "sentence-transformers/all-mpnet-base-v2" 768-dim

                                    If you change vector_size in .memory(), update this too.

        ── Output ────────────────────────────────────────────────────────────────
        output_dir    Directory where the model and tokenizer are saved.
                                    Default: ~/.jazzmine/models/<model-slug>/
                                    The directory is created automatically if it does not exist.

        ── Mode ──────────────────────────────────────────────────────────────────
        tokenizer_only
                                    True  = download the tokenizer only, no ONNX export.
                                                    Use this when embeddings are handled by a remote API
                                                    (embed_api_key in .memory()) but local BM25 sparse
                                                    vectors still require a local tokenizer for hybrid search.
                                    False = download and export the full ONNX model for
                                                    fully local, in-process embedding (default).

        ── ONNX export options (ignored when tokenizer_only=True) ────────────────
        quantized     True  = export INT8-quantised ONNX (faster, ~4x smaller, default).
                                    False = export FP32 ONNX (larger, marginally more accurate).

        opset         ONNX opset version (default 17). Rarely needs changing.

        ── Cache ─────────────────────────────────────────────────────────────────
        force_rebuild True  = re-download and re-export on every build() call.
                                    False = skip export if files already exist in output_dir (default).

        ── Dependencies ──────────────────────────────────────────────────────────
        Requires: torch, transformers, onnxruntime-tools (or onnxruntime)
        Install:  pip install torch transformers onnxruntime-tools
        """
        model_id:       str  = "BAAI/bge-small-en-v1.5"
        output_dir:     str  = ""      # empty -> ~/.jazzmine/models/<slug>/
        tokenizer_only: bool = False
        quantized:      bool = True
        opset:          int  = 17
        force_rebuild:  bool = False


@dataclass
class MemoryConfig:
    """
    Complete configuration for the Qdrant vector store, the embedding backend,
    and all three memory systems (episodic, procedural, semantic).

    ── Qdrant connection ─────────────────────────────────────────────────────
    qdrant_url         gRPC URL of the Qdrant instance, e.g.
                       "http://localhost:6334" or "https://xyz.cloud.qdrant.io:6334"
    qdrant_api_key     API key for Qdrant Cloud. None = unauthenticated (local).
    collection_prefix  Prefix applied to all collection names, e.g. "myagent"
                       → "myagent_conversation_summaries", "myagent_flows", …
                       Empty string = no prefix.

    ── Qdrant collection tuning ─────────────────────────────────────────────
    vector_size            Embedding dimension. Must match the model output.
    distance_metric        "cosine" (default) | "euclidean" | "dot"
    use_indexing           Build HNSW index. True = fast ANN search.
                           False = exact search (slower, no index overhead).
    quantization           Vector quantization: None = off, 4 = 4-bit product
                           quantization (PQ, 4× compression), 8 = 8-bit scalar
                           (good balance of speed and accuracy). Default 8.
    on_disk                Store vectors on disk instead of RAM. Cheaper for
                           large collections at the cost of higher latency.
    replication_factor     Number of replicas per shard (default 1 = no HA).
    shard_number           Number of shards per collection (default 1).
    indexing_threshold     Points in a segment before HNSW indexing kicks in.
    flush_interval_sec     Wal flush interval in seconds.
    max_optimization_threads  Max threads for background optimisation (0 = auto).
    use_sparse_vectors     Build a BM25 sparse vector alongside each dense vector
                           for hybrid search. Strongly recommended (default True).

        ── Embedding backend ─────────────────────────────────────────────────────
        When .embeddings() is called in AgentBuilder, tokenizer_path and
        model_dir are resolved automatically — you do not need to set them here.

        Without .embeddings(), set exactly one backend manually:

        LOCAL (ONNX, fully in-process):
            tokenizer_path   Path to tokenizer.json.
            model_dir        Directory containing the ONNX model file.
            quantized        Use int8 ONNX model (True) or fp32 (False).
            max_batch        Max texts per ONNX batch (default 8).

        REMOTE (API, no local model):
            embed_provider   "openai" | "azure" | "gemini" | "cohere" | "huggingface"
                                             | "mistral" | "together" | "voyage" | "jina"
                                             | "nomic" | "openrouter" | "deepinfra"
            embed_api_key    API key for the embedding provider.
            embed_base_url   Override the provider's default base URL (optional).
            embed_model_name Override the provider's default model (optional).
            tokenizer_path   Still required for BM25 sparse vectors (set via
                                             .embeddings(tokenizer_only=True) or manually).
    """
    # Qdrant connection
    qdrant_url:               str
    # tokenizer_path is optional here — auto-resolved when .embeddings() is used.
    tokenizer_path:           str            = ""
    collection_prefix:        str            = "jazzmine"
    qdrant_api_key:           str | None     = None
    qdrant_auto_start:        bool           = True
    qdrant_docker_image:      str            = "qdrant/qdrant"
    qdrant_container_name:    str | None     = None
    qdrant_http_host_port:    int | None     = None
    qdrant_data_volume:       str            = "jazzmine-qdrant-data"
    qdrant_stop_on_shutdown:  bool           = True

    # Qdrant collection tuning
    vector_size:              int            = 384
    distance_metric:          str            = "cosine"
    use_indexing:             bool           = True
    quantization:             int | None     = 8       # None | 4 | 8
    on_disk:                  bool           = False
    replication_factor:       int            = 1
    shard_number:             int            = 1
    indexing_threshold:       int            = 2000
    flush_interval_sec:       int            = 15
    max_optimization_threads: int            = 1
    use_sparse_vectors:       bool           = True

    # Local embedding backend
    model_dir:                str | None     = None
    quantized:                bool           = False
    max_batch:                int            = 8

    # Remote embedding backend
    embed_provider:           str            = "openai"
    embed_api_key:            str | None     = None
    embed_base_url:           str | None     = None
    embed_model_name:         str | None     = None


@dataclass
class FileMount:
    """
    A host filesystem path bind-mounted into the sandbox container.

    Thin wrapper around config.FileResource — keeps users from needing to
    import from deep internal modules.

    host_path       Path on the machine running the Docker daemon (the host).
                    In DooD mode (agent running inside a container) this is the
                    path as seen on the HOST, not inside the agent container.
                    If the agent itself is containerised, use docker_host_path
                    to supply the host-side path explicitly.
    container_path  Where the file/directory appears inside the sandbox.
    read_only       Almost always True. Set False only for an output sink.
    docker_host_path
                    Override for DooD mode. When the agent runs inside a
                    container, its own filesystem paths differ from those the
                    Docker daemon resolves. Provide the host-side path here.

    Example:
        FileMount(
            host_path       = "/home/nour/data/catalog.csv",
            container_path  = "/data/catalog.csv",
        )
    """
    host_path:        str
    container_path:   str
    read_only:        bool         = True
    docker_host_path: str | None   = None

    def to_file_resource(self) -> Any:
        """Convert to jazzmine.core.tools.sandbox.config.FileResource."""
        from jazzmine.core.tools.sandbox.config import FileResource
        return FileResource(
            host_path        = self.host_path,
            container_path   = self.container_path,
            read_only        = self.read_only,
            docker_host_path = self.docker_host_path,
        )


@dataclass
class SandboxSpec:
    """
    Complete specification for one isolated sandbox environment.
    Call AgentBuilder.sandbox() once per sandbox; the first becomes the default.

    ── Identity ─────────────────────────────────────────────────────────────
    name             Unique identifier. Tools reference this by name.
    python_version   Selects the base image (python:<version>-slim).

    ── Resource limits (enforced by Docker cgroups) ─────────────────────────
    cpu_quota        Fraction of one CPU core (0.5 = 50% of one core).
    memory_mb        Hard RAM limit in megabytes.
    memory_swap_mb   Total memory+swap limit. -1 = unlimited. Must be >
                     memory_mb when set. Default -1 (unlimited swap).
    pids_limit       Max number of processes/threads inside the container.
    timeout_sec      Max wall-clock seconds a script may run before SIGALRM.
    max_output_bytes Max bytes the harness reads from container stdout before
                     killing the script. Prevents runaway output.

    ── Storage ───────────────────────────────────────────────────────────────
    scratch_size_mb  Size of the writable tmpfs mounted at /scratch.
    pool_size        Number of warm containers kept ready.

    ── Network policy (egress allowlist, enforced by proxy sidecar) ─────────
    allowed_hosts    Hostnames or IP addresses the script may reach.
                     Empty list = fully isolated (no outbound connections).
    allowed_ports    Per-host port override: {"api.stripe.com": [443, 80]}.
                     Hosts not listed here use default_port.
    default_port     Port used for hosts not in allowed_ports (default 443).

    ── File resources (bind-mounts, read-only by default) ───────────────────
    file_mounts      List of FileMount objects. Each one bind-mounts a path
                     from the host filesystem into the container.
                     Example:
                         file_mounts=[
                             FileMount("/data/catalog.csv", "/data/catalog.csv"),
                             FileMount("/models/embedder", "/models/embedder"),
                         ]

    ── Secrets (environment variables injected at runtime) ──────────────────
    secrets          Dict mapping env-var names to values:
                         {"STRIPE_API_KEY": "sk-...", "DB_URL": "..."}
                     Keys are validated at startup; values are injected into
                     the container env but never logged.
    """
    name:              str
    python_version:    str             = "3.11"

    # Resource limits
    cpu_quota:         float           = 0.5
    memory_mb:         int             = 256
    memory_swap_mb:    int             = -1
    pids_limit:        int             = 64
    timeout_sec:       int             = 30
    max_output_bytes:  int             = 1_048_576

    # Storage
    scratch_size_mb:   int             = 128
    pool_size:         int             = 1
    pool_max_overflow: int             = 10
    pool_host_path_map: dict[str, str] = field(default_factory=dict)


    # Network policy
    allowed_hosts:    list[str]                = field(default_factory=list)
    allowed_ports:    dict[str, list[int]]     = field(default_factory=dict)
    default_port:     int                      = 443

    # File resources
    file_mounts:      list[FileMount]          = field(default_factory=list)

    # Secrets
    secrets:          dict[str, str]           = field(default_factory=dict)

    # pip packages baked into the image at build time
    pip_packages:     list[str]                = field(default_factory=list)

    # Execution mode for this sandbox: "plan" or "interactive"
    execution_mode:   str                      = "plan"


# (key, value, category, aliases, description)
DomainTerm = tuple[str, str, str, list[str], str]


@dataclass
class AgentSettings:
    """
    All behavioural knobs for the Agent and its components.

    Every field maps to a parameter of one specific component.
    Grouped by component for clarity.

    ── Agent / turn loop ────────────────────────────────────────────────
    default_sandbox_name      Sandbox used when <task> omits sandbox attr.
                              Inferred from the first .sandbox() call if blank.
    default_execution_mode    "plan" | "interactive"
    max_task_calls_per_turn   Hard cap on <task> emissions per turn.
    max_interactive_steps     Max steps for execute_interactive().

    ── Memory recall ─────────────────────────────────────────────────────
    episodic_same_conv_limit  Max episodes recalled from current conversation.
    episodic_prev_conv_limit  Max episodes recalled from prior conversations.
    semantic_top_k            Max domain terms returned per turn.

    ── Message enhancer ──────────────────────────────────────────────────
    enhancer_history_window   Recent messages fetched per turn before
                              trimming to the current episode boundary.

    ── Tool orchestrator ─────────────────────────────────────────────────
    max_retries               Max script generation retries per task.

    ── Conversation summariser ───────────────────────────────────────────
    summarizer_trigger        Min unsummarised messages before summarisation.
    max_episode_size          Hard cap on messages per episode.
    min_episode_size          Min messages before a topic shift closes an episode.
    episode_overlap           Messages from episode N prepended to episode N+1
                              for smooth LLM context at boundaries.

    ── Flow selector ─────────────────────────────────────────────────────
    flow_top_k                Max candidate flows recalled from Qdrant.
    flow_rrf_k                RRF fusion k parameter for hybrid search.

    ── Telemetry / emissions ─────────────────────────────────────────────
    enable_telemetry          Master switch for energy + CO2 telemetry.
    energy_per_1k_tokens_kwh  Default kWh estimate per 1K LLM tokens.
    co2_per_kwh_g             Grid carbon intensity in grams CO2 per kWh.
    default_api_co2_g         Fixed fallback CO2 for API calls with no size data.
    api_energy_kwh_per_mb     API transfer energy estimate (kWh per MB).
    telemetry_max_records     Max in-memory emission records retained.
    telemetry_jsonl_path      Optional JSONL path for emission persistence.
    telemetry_country_iso_code Country code used by CodeCarbon offline tracker.
    """

    # Agent / turn loop
    default_sandbox_name:     str   = ""
    default_execution_mode:   str   = "plan"
    max_task_calls_per_turn:  int   = 4
    max_interactive_steps:    int   = 4
    max_retries:              int   = 3


    # Memory recall
    episodic_same_conv_limit: int   = 3
    episodic_prev_conv_limit: int   = 1
    semantic_top_k:           int   = 4

    # Message enhancer
    enhancer_history_window:  int   = 8
    # How many recent messages to fetch before trimming to the current episode
    # boundary. Increase if your episodes regularly exceed 4 turn pairs.

    # Conversation summariser
    summarizer_trigger:       int   = 3
    max_episode_size:         int   = 20
    min_episode_size:         int   = 2
    episode_overlap:          int   = 1

    # Flow selector
    flow_top_k:               int   = 3
    flow_rrf_k:               int   = 10

    # Telemetry / emissions
    enable_telemetry:         bool  = True
    energy_per_1k_tokens_kwh: float = 0.001
    co2_per_kwh_g:            float = 500.0
    default_api_co2_g:        float = 0.02
    api_energy_kwh_per_mb:    float = 0.0001
    telemetry_max_records:    int   = 10_000
    telemetry_jsonl_path:     str | None = None
    telemetry_country_iso_code: str = "USA"

    # Sandbox pool (pool-level, apply across all sandboxes)
    pool_max_overflow:        int               = 10
    # How many extra containers beyond pool_size may be spawned under sustained
    # load before callers start blocking. Total live containers per sandbox is
    # capped at pool_size + pool_max_overflow. Higher values reduce latency
    # spikes at the cost of more Docker memory.

    pool_host_path_map:       dict[str, str]    = field(default_factory=dict)
    # DooD (Docker-out-of-Docker) path prefix translation.
    # When the agent runs inside a container, bind-mount paths must be
    # Docker HOST paths, not agent-container paths. Map agent prefixes to
    # host prefixes here. Longest prefix wins.
    # Example: pool_host_path_map={"/data": "/srv/data", "/models": "/opt/models"}
    # Leave empty on a bare host — no translation is applied.


# ══════════════════════════════════════════════════════════════════════════════
# SecurityConfig — injected components + tuning knobs for SecurityGuard
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class SecurityConfig:
    """
    Configuration for the SecurityGuard injected into every agent turn.

    Components (all optional — omit any you don't need):
    ────────────────────────────────────────────────────
    input_moderator
        An instance of a BaseModerator subclass that classifies user input.
        Uses a fine-tuned HuggingFace transformer (LABEL_0 = safe, LABEL_1 = unsafe).
        Mutually exclusive with toxicity_detector.
        Pass either the built-in JazzmineInputModerator or your own subclass.

    toxicity_detector
        A JazzmineToxicityDetector instance (XGBoost + feature pipeline).
        Classifies user input using a lightweight feature-based model.
        Mutually exclusive with input_moderator.
        Honour the detector's own threshold (set on the instance) rather than
        input_confidence_threshold — the guard respects detector.predict()'s
        is_toxic boolean directly.

    output_moderator
        A BaseModerator subclass instance that classifies the agent's generated
        response before it is returned to the user.
        Fully independent of the input gate.

    file_sanitizer
        A BaseSanitizer subclass instance (JazzminePDFSanitizer, JazzmineCSVSanitizer,
        JazzmineHTMLSanitizer, or your own). NOT invoked in the chat() flow.
        Exposed as agent.security.sanitizer for callers to use explicitly on
        uploaded files before passing content to the agent.

    Thresholds:
    ───────────
    input_confidence_threshold
        Minimum confidence score for LABEL_1 to trigger a block on user input.
        Only applies to input_moderator (not toxicity_detector). Default 0.5.

    output_confidence_threshold
        Same threshold for the output_moderator. Default 0.5.

    Messages returned to the user on block:
    ────────────────────────────────────────
    input_block_message
        Text returned when user input is blocked. Defaults to a professional,
        non-alarming message asking the user to rephrase. Override for:
          • Brand voice
          • Localisation (non-English agents)
          • Compliance-specific language

    output_block_message
        Text returned when the agent's generated response is blocked.
        The original response is discarded and this message is sent instead.

    Operational knobs:
    ──────────────────
    moderation_timeout
        Maximum seconds to wait for a single moderation call. On timeout
        the guard fails open (user is not blocked) unless fail_open=False.
        Default 10.0 seconds.

    fail_open
        True  (default) — timeout or exception → treat content as safe.
                          Recommended for consumer-facing agents.
        False           — timeout or exception → re-raise.
                          Use for high-security / compliance deployments.
    """
    # Components — passed as pre-constructed instances
    input_moderator:             Any | None = None
    toxicity_detector:           Any | None = None
    output_moderator:            Any | None = None
    file_sanitizer:              Any | None = None

    # Confidence thresholds
    input_confidence_threshold:  float      = 0.5
    output_confidence_threshold: float      = 0.5

    # Block messages
    input_block_message:  str = (
        "I'm unable to process this message as it was flagged by our "
        "content safety system. Please rephrase your request and try again. "
        "If you believe this was a mistake, please contact support."
    )
    output_block_message: str = (
        "I wasn't able to generate a safe response for your request. "
        "Please try rephrasing or ask something different."
    )

    # Operational
    moderation_timeout: float = 10.0
    fail_open:          bool  = True



"""
ServerConfig — paste this block at the bottom of configs.py,
just before the final `# ══ Teardown` comment.
"""


@dataclass
class CORSConfig:
    """
    Fine-grained CORS policy for the agent's HTTP server.

    Passed to AgentBuilder.server() as the `cors` keyword argument.
    When omitted, a permissive open-access policy is applied by default
    (all origins, all methods, all headers, no credentials).

    Fields
    ──────
    origins
        List of allowed origins. Use ["*"] to permit any origin.
        When allow_credentials=True you must list explicit origins —
        the wildcard is not permitted by the CORS spec in that case.

    allow_credentials
        Set True to allow cookies / Authorization headers cross-origin.
        Requires explicit origins (not ["*"]).

    allow_methods
        HTTP methods permitted cross-origin. Defaults to all methods.

    allow_headers
        Request headers permitted cross-origin. Defaults to all headers.

    expose_headers
        Response headers the browser is allowed to access.

    max_age
        How long (seconds) the browser may cache a preflight response.
        Default 600 (10 minutes).
    """
    origins:             list[str] = field(default_factory=lambda: ["*"])
    allow_credentials:   bool      = False
    allow_methods:       list[str] = field(default_factory=lambda: ["*"])
    allow_headers:       list[str] = field(default_factory=lambda: ["*"])
    expose_headers:      list[str] = field(default_factory=list)
    max_age:             int       = 600


@dataclass
class ServerConfig:
    """
    Configuration for the FastAPI / uvicorn server wired into an agent
    via AgentBuilder.server().

    Minimal usage — accept all defaults:
        agent, td = await (
            AgentBuilder(name="Aria", agent_id="...", personality="...")
            .llm(...)
            .server(ServerConfig())          # ← listens on 0.0.0.0:1453
            .build()
        )

    Production usage:
        agent, td = await (
            AgentBuilder(name="Aria", agent_id="...", personality="...")
            .llm(...)
            .server(
                ServerConfig(
                    host          = "0.0.0.0",
                    port          = 443,
                    api_key       = os.environ["AGENT_API_KEY"],
                    chat_endpoint = "/v1/chat",
                    cors          = CORSConfig(
                        origins           = ["https://app.example.com"],
                        allow_credentials = True,
                    ),
                    ssl_certfile  = "/etc/ssl/certs/agent.crt",
                    ssl_keyfile   = "/etc/ssl/private/agent.key",
                    docs_url      = None,     # disable in prod
                    log_level     = "warning",
                )
            )
            .build()
        )

    Network
    ───────
    host            Bind address. "0.0.0.0" = all interfaces, "127.0.0.1" = localhost only.
    port            TCP port (1 – 65535). Default 1453.

    Endpoints
    ─────────
    chat_endpoint       Path for the POST chat endpoint. Default "/chat".
    conversations_endpoint
                        Path prefix for conversation management:
                        POST {conversations_endpoint}
                        GET  {conversations_endpoint}
                        GET  {conversations_endpoint}/search
                        GET  {conversations_endpoint}/{conversation_id}/messages
                        PATCH {conversations_endpoint}/{conversation_id}
                        DELETE {conversations_endpoint}/{conversation_id}
                        Default "/conversations".
    health_endpoint     Path for GET health-check. Default "/health".
    info_endpoint       Path for GET agent metadata. Default "/info".
    include_docs        Mount Swagger UI at docs_url and ReDoc at redoc_url.

    Authentication
    ──────────────
    api_key         When set, every request must carry an
                    `Authorization: Bearer <api_key>` header.
                    None = no authentication (open access).

    Request limits
    ──────────────
    request_timeout     Seconds before a chat turn is cancelled. Default 120.
    max_message_length  Maximum user message length in characters. Default 32 768.

    API metadata (shown in /docs)
    ─────────────────────────────
    title           FastAPI app title. Default "Jazzmine Agent API".
    description     Markdown description shown in /docs.
    api_version     Semver string for the API. Default "1.0.0".
    docs_url        Swagger UI path. None = disabled. Default "/docs".
    redoc_url       ReDoc path. None = disabled. Default None.

    TLS / SSL
    ─────────
    ssl_certfile    Path to the PEM certificate file. Requires ssl_keyfile.
    ssl_keyfile     Path to the PEM private-key file. Requires ssl_certfile.

    CORS
    ────
    cors            A CORSConfig instance. Defaults to open access (all origins).

    Server tuning
    ─────────────
    log_level           Uvicorn log level: "critical" | "error" | "warning"
                        | "info" | "debug" | "trace". Default "info".
    backlog             Socket accept-queue depth. Default 2048.
    limit_concurrency   Max concurrent connections before uvicorn returns 503.
                        None = unlimited.
    timeout_keep_alive  Seconds to hold an idle keep-alive connection. Default 5.
    """

    # ── Network ───────────────────────────────────────────────────────────────
    host: str = "0.0.0.0"
    port: int = 1453

    # ── Endpoints ─────────────────────────────────────────────────────────────
    chat_endpoint:          str = "/chat"
    conversations_endpoint: str = "/conversations"
    health_endpoint:        str = "/health"
    info_endpoint:          str = "/info"

    # ── Authentication ────────────────────────────────────────────────────────
    api_key: str | None = None

    # ── Request limits ────────────────────────────────────────────────────────
    request_timeout:     float = 120.0
    max_message_length:  int   = 32_768

    # ── API metadata ──────────────────────────────────────────────────────────
    title:       str       = "Jazzmine Agent API"
    description: str       = ""
    api_version: str       = "1.0.0"
    docs_url:    str | None = "/docs"
    redoc_url:   str | None = None

    # ── CORS ──────────────────────────────────────────────────────────────────
    cors: CORSConfig = field(default_factory=CORSConfig)

    # ── TLS ───────────────────────────────────────────────────────────────────
    ssl_certfile: str | None = None
    ssl_keyfile:  str | None = None

    # ── Server tuning ─────────────────────────────────────────────────────────
    log_level:          str      = "info"
    backlog:            int      = 2048
    limit_concurrency:  int | None = None
    timeout_keep_alive: int      = 5