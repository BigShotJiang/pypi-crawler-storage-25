import json
import asyncpg

from jazzmine.core.message_store.base import MessageStore
from jazzmine.core.message_store.models import (
    Conversation, Message, MessageRole, Entity,
    TurnTrace )

# ── DDL ───────────────────────────────────────────────────────────────────────

_CREATE_CONVERSATIONS = """
CREATE TABLE IF NOT EXISTS conversations (
    id               TEXT    PRIMARY KEY,
    user_id          TEXT    NOT NULL,
    agent_id         TEXT    NOT NULL,
    title            TEXT    NOT NULL,
    created_at       BIGINT  NOT NULL,
    last_updated_at  BIGINT  NOT NULL
);
"""

_CREATE_MESSAGES = """
CREATE TABLE IF NOT EXISTS messages (
    id                TEXT     PRIMARY KEY,
    conversation_id   TEXT     NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    user_id           TEXT     NOT NULL,
    role              TEXT     NOT NULL,
    original_content  TEXT     NOT NULL,
    enhanced_message  TEXT     NOT NULL DEFAULT '',
    explicit_context  JSONB,
    episode_id        INTEGER  NOT NULL DEFAULT 0,
    sentiment_score   FLOAT    NOT NULL DEFAULT 0.0,
    intent            TEXT     NOT NULL DEFAULT 'unknown',
    entities          JSONB    NOT NULL DEFAULT '[]',
    is_cancellation   BOOLEAN  NOT NULL DEFAULT FALSE,
    is_continuation   BOOLEAN  NOT NULL DEFAULT TRUE,
    is_flagged        BOOLEAN  NOT NULL DEFAULT FALSE,
    timestamp         BIGINT   NOT NULL,
    invoked_flows     JSONB,
    invoked_tools     JSONB,
    reasoning_steps   JSONB,
    errors            JSONB
);
"""

# Scalar columns are used for all queryable aggregates so they can be indexed
# with B-tree indexes and used in range queries without reading JSONB.
# Arrays of nested objects live in JSONB columns with GIN indexes for
# containment searches (e.g. "find all traces where any tool_trace errored").
_CREATE_TURN_TRACES = """
CREATE TABLE IF NOT EXISTS turn_traces (
    id                       TEXT     PRIMARY KEY,
    message_id               TEXT     NOT NULL UNIQUE
                                      REFERENCES messages(id) ON DELETE CASCADE,
    conversation_id          TEXT     NOT NULL
                                      REFERENCES conversations(id) ON DELETE CASCADE,
    user_id                  TEXT     NOT NULL,
    agent_id                 TEXT     NOT NULL,
    turn_number              INTEGER  NOT NULL,

    -- Timing (scalar for range queries / dashboards)
    started_at_ms            BIGINT   NOT NULL,
    ended_at_ms              BIGINT   NOT NULL,
    total_latency_ms         INTEGER  NOT NULL,

    -- Token accounting (scalar for cost queries)
    total_prompt_tokens      INTEGER  NOT NULL DEFAULT 0,
    total_completion_tokens  INTEGER  NOT NULL DEFAULT 0,
    total_tokens             INTEGER  NOT NULL DEFAULT 0,

    -- Enhancement summary (scalar for intent / sentiment analysis)
    detected_intent          TEXT     NOT NULL DEFAULT 'unknown',
    sentiment_score          FLOAT    NOT NULL DEFAULT 0.0,
    is_continuation          BOOLEAN  NOT NULL DEFAULT TRUE,
    is_cancellation          BOOLEAN  NOT NULL DEFAULT FALSE,
    total_energy_kwh         DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    total_co2_g              DOUBLE PRECISION NOT NULL DEFAULT 0.0,

    -- Nested arrays in JSONB — full fidelity, GIN-indexed for containment search
    llm_calls                JSONB    NOT NULL DEFAULT '[]',
    task_emissions           JSONB    NOT NULL DEFAULT '[]',
    tool_traces              JSONB    NOT NULL DEFAULT '[]',
    emission_records         JSONB    NOT NULL DEFAULT '[]',
    slot_events              JSONB    NOT NULL DEFAULT '[]',
    confirmation_events      JSONB    NOT NULL DEFAULT '[]',
    flow_events              JSONB    NOT NULL DEFAULT '[]',
    reasoning_steps          JSONB    NOT NULL DEFAULT '[]',
    detected_entities        JSONB    NOT NULL DEFAULT '[]',
    errors                   JSONB    NOT NULL DEFAULT '[]'
);
"""

_CREATE_INDEXES = [
    # conversations
    "CREATE INDEX IF NOT EXISTS idx_conv_user      ON conversations(user_id, last_updated_at DESC);",
    "CREATE INDEX IF NOT EXISTS idx_conv_agent     ON conversations(agent_id, last_updated_at DESC);",
    # messages
    "CREATE INDEX IF NOT EXISTS idx_msg_conv       ON messages(conversation_id, timestamp);",
    "CREATE INDEX IF NOT EXISTS idx_msg_user       ON messages(user_id, timestamp);",
    "CREATE INDEX IF NOT EXISTS idx_msg_episode    ON messages(conversation_id, episode_id);",
    "CREATE INDEX IF NOT EXISTS idx_msg_flagged    ON messages(is_flagged) WHERE is_flagged = TRUE;",
    "CREATE INDEX IF NOT EXISTS idx_msg_cancelled  ON messages(is_cancellation) WHERE is_cancellation = TRUE;",
    "CREATE INDEX IF NOT EXISTS idx_msg_intent     ON messages(intent);",
    # turn_traces — scalar columns for fast aggregate queries
    "CREATE INDEX IF NOT EXISTS idx_tt_conv        ON turn_traces(conversation_id, turn_number);",
    "CREATE INDEX IF NOT EXISTS idx_tt_agent_time  ON turn_traces(agent_id, started_at_ms DESC);",
    "CREATE INDEX IF NOT EXISTS idx_tt_tokens      ON turn_traces(total_tokens DESC);",
    "CREATE INDEX IF NOT EXISTS idx_tt_latency     ON turn_traces(total_latency_ms DESC);",
    "CREATE INDEX IF NOT EXISTS idx_tt_intent      ON turn_traces(detected_intent);",
    "CREATE INDEX IF NOT EXISTS idx_tt_user        ON turn_traces(user_id, started_at_ms DESC);",
    # turn_traces — GIN indexes for JSONB containment search
    # Enables queries like: WHERE tool_traces @> '[{"success": false}]'
    "CREATE INDEX IF NOT EXISTS idx_tt_tool_gin    ON turn_traces USING GIN (tool_traces);",
    "CREATE INDEX IF NOT EXISTS idx_tt_llm_gin     ON turn_traces USING GIN (llm_calls);",
    "CREATE INDEX IF NOT EXISTS idx_tt_flow_gin    ON turn_traces USING GIN (flow_events);",
    "CREATE INDEX IF NOT EXISTS idx_tt_errors_gin  ON turn_traces USING GIN (errors);",
]


# ── Row ↔ model helpers ───────────────────────────────────────────────────────

def _j(v) -> str | None:
    return json.dumps(v) if v is not None else None


def _pj(v):
    if v is None:
        return None
    if isinstance(v, str):
        return json.loads(v)
    return v


def _entities_to_json(entities: list[Entity]) -> str:
    return json.dumps([e.model_dump() for e in entities])


def _json_to_entities(v) -> list[Entity]:
    raw = _pj(v)
    if not raw:
        return []
    return [Entity(name=item["name"], attributes=item.get("attributes", [])) for item in raw]


def _row_to_message(r: asyncpg.Record) -> Message:
    return Message(
        id               = r["id"],
        conversation_id  = r["conversation_id"],
        user_id          = r["user_id"],
        role             = MessageRole(r["role"]),
        original_content = r["original_content"],
        enhanced_message = r["enhanced_message"],
        explicit_context = _pj(r["explicit_context"]),
        episode_id       = r["episode_id"],
        sentiment_score  = r["sentiment_score"],
        intent           = r["intent"],
        entities         = _json_to_entities(r["entities"]),
        is_cancellation  = r["is_cancellation"],
        is_continuation  = r["is_continuation"],
        is_flagged       = r["is_flagged"],
        timestamp        = r["timestamp"],
        invoked_flows    = _pj(r["invoked_flows"]),
        invoked_tools    = _pj(r["invoked_tools"]),
        reasoning_steps  = _pj(r["reasoning_steps"]),
        errors           = _pj(r["errors"]),
    )


def _row_to_conversation(r: asyncpg.Record) -> Conversation:
    return Conversation(
        id              = r["id"],
        user_id         = r["user_id"],
        agent_id        = r["agent_id"],
        title           = r["title"],
        created_at      = r["created_at"],
        last_updated_at = r["last_updated_at"],
    )


def _row_to_turn_trace(r: asyncpg.Record) -> TurnTrace:
    """Reconstruct a TurnTrace from a Postgres row using Pydantic model_validate."""
    return TurnTrace.model_validate({
        "id":                       r["id"],
        "message_id":               r["message_id"],
        "conversation_id":          r["conversation_id"],
        "user_id":                  r["user_id"],
        "agent_id":                 r["agent_id"],
        "turn_number":              r["turn_number"],
        "started_at_ms":            r["started_at_ms"],
        "ended_at_ms":              r["ended_at_ms"],
        "total_latency_ms":         r["total_latency_ms"],
        "total_prompt_tokens":      r["total_prompt_tokens"],
        "total_completion_tokens":  r["total_completion_tokens"],
        "total_tokens":             r["total_tokens"],
        "detected_intent":          r["detected_intent"],
        "sentiment_score":          r["sentiment_score"],
        "is_continuation":          r["is_continuation"],
        "is_cancellation":          r["is_cancellation"],
        "total_energy_kwh":         r["total_energy_kwh"],
        "total_co2_g":              r["total_co2_g"],
        "llm_calls":                _pj(r["llm_calls"])           or [],
        "task_emissions":           _pj(r["task_emissions"])      or [],
        "tool_traces":              _pj(r["tool_traces"])         or [],
        "emission_records":         _pj(r["emission_records"])    or [],
        "slot_events":              _pj(r["slot_events"])         or [],
        "confirmation_events":      _pj(r["confirmation_events"]) or [],
        "flow_events":              _pj(r["flow_events"])         or [],
        "reasoning_steps":          _pj(r["reasoning_steps"])     or [],
        "detected_entities":        _pj(r["detected_entities"])   or [],
        "errors":                   _pj(r["errors"])              or [],
    })


def _turn_trace_args(t: TurnTrace) -> tuple:
    """Positional args matching _UPSERT_TURN_TRACE placeholders."""
    return (
        t.id,
        t.message_id,
        t.conversation_id,
        t.user_id,
        t.agent_id,
        t.turn_number,
        t.started_at_ms,
        t.ended_at_ms,
        t.total_latency_ms,
        t.total_prompt_tokens,
        t.total_completion_tokens,
        t.total_tokens,
        t.detected_intent,
        t.sentiment_score,
        t.is_continuation,
        t.is_cancellation,
        t.total_energy_kwh,
        t.total_co2_g,
        json.dumps([c.model_dump() for c in t.llm_calls]),
        json.dumps([e.model_dump() for e in t.task_emissions]),
        json.dumps([tt.model_dump() for tt in t.tool_traces]),
        json.dumps([e.model_dump(mode="json") for e in t.emission_records]),
        json.dumps([s.model_dump() for s in t.slot_events]),
        json.dumps([c.model_dump() for c in t.confirmation_events]),
        json.dumps([f.model_dump() for f in t.flow_events]),
        json.dumps(t.reasoning_steps),
        json.dumps(t.detected_entities),
        json.dumps(t.errors),
    )


# ── Store ─────────────────────────────────────────────────────────────────────

class PostgresMessageStore(MessageStore):

    def __init__(self, config: dict):
        self._dsn      = config["dsn"]
        self._min_size = config.get("pool_min", 2)
        self._max_size = config.get("pool_max", 10)
        self._pool: asyncpg.Pool | None = None

    async def _init(self) -> None:
        self._pool = await asyncpg.create_pool(
            self._dsn, min_size=self._min_size, max_size=self._max_size
        )
        async with self._pool.acquire() as conn:
            await conn.execute(_CREATE_CONVERSATIONS)
            await conn.execute(_CREATE_MESSAGES)
            await conn.execute(_CREATE_TURN_TRACES)
            await conn.execute(
                "ALTER TABLE turn_traces ADD COLUMN IF NOT EXISTS total_energy_kwh DOUBLE PRECISION NOT NULL DEFAULT 0.0;"
            )
            await conn.execute(
                "ALTER TABLE turn_traces ADD COLUMN IF NOT EXISTS total_co2_g DOUBLE PRECISION NOT NULL DEFAULT 0.0;"
            )
            await conn.execute(
                "ALTER TABLE turn_traces ADD COLUMN IF NOT EXISTS emission_records JSONB NOT NULL DEFAULT '[]';"
            )
            for idx in _CREATE_INDEXES:
                await conn.execute(idx)
            await conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_tt_emissions_gin ON turn_traces USING GIN (emission_records);"
            )

    async def close(self) -> None:
        if self._pool:
            await self._pool.close()

    # ── conversations ─────────────────────────────────────────────────────────

    _UPSERT_CONV = """
        INSERT INTO conversations (id, user_id, agent_id, title, created_at, last_updated_at)
        VALUES ($1, $2, $3, $4, $5, $6)
        ON CONFLICT (id) DO UPDATE SET
            user_id         = EXCLUDED.user_id,
            agent_id        = EXCLUDED.agent_id,
            title           = EXCLUDED.title,
            created_at      = EXCLUDED.created_at,
            last_updated_at = EXCLUDED.last_updated_at;
    """

    async def store_conversation(self, conversation: Conversation) -> None:
        async with self._pool.acquire() as conn:
            await conn.execute(
                self._UPSERT_CONV,
                conversation.id, conversation.user_id, conversation.agent_id,
                conversation.title, conversation.created_at, conversation.last_updated_at,
            )

    async def get_conversation_by_id(self, conversation_id: str) -> Conversation | None:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM conversations WHERE id = $1;", conversation_id
            )
        return _row_to_conversation(row) if row else None

    async def get_conversations_by_user_id(self, user_id: str) -> list[Conversation]:
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM conversations WHERE user_id = $1 ORDER BY last_updated_at DESC;",
                user_id,
            )
        return [_row_to_conversation(r) for r in rows]

    async def get_conversations_by_agent_id(self, agent_id: str) -> list[Conversation]:
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM conversations WHERE agent_id = $1 ORDER BY last_updated_at DESC;",
                agent_id,
            )
        return [_row_to_conversation(r) for r in rows]

    async def update_conversation(self, conversation: Conversation) -> None:
        await self.store_conversation(conversation)

    async def delete_conversation(self, conversation_id: str) -> None:
        # ON DELETE CASCADE on messages and turn_traces handles children.
        async with self._pool.acquire() as conn:
            await conn.execute(
                "DELETE FROM conversations WHERE id = $1;", conversation_id
            )

    # ── messages ──────────────────────────────────────────────────────────────

    _UPSERT_MSG = """
        INSERT INTO messages
            (id, conversation_id, user_id, role, original_content, enhanced_message,
             explicit_context, episode_id, sentiment_score, intent, entities,
             is_cancellation, is_continuation, is_flagged, timestamp,
             invoked_flows, invoked_tools, reasoning_steps, errors)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)
        ON CONFLICT (id) DO UPDATE SET
            conversation_id  = EXCLUDED.conversation_id,
            user_id          = EXCLUDED.user_id,
            role             = EXCLUDED.role,
            original_content = EXCLUDED.original_content,
            enhanced_message = EXCLUDED.enhanced_message,
            explicit_context = EXCLUDED.explicit_context,
            episode_id       = EXCLUDED.episode_id,
            sentiment_score  = EXCLUDED.sentiment_score,
            intent           = EXCLUDED.intent,
            entities         = EXCLUDED.entities,
            is_cancellation  = EXCLUDED.is_cancellation,
            is_continuation  = EXCLUDED.is_continuation,
            is_flagged       = EXCLUDED.is_flagged,
            timestamp        = EXCLUDED.timestamp,
            invoked_flows    = EXCLUDED.invoked_flows,
            invoked_tools    = EXCLUDED.invoked_tools,
            reasoning_steps  = EXCLUDED.reasoning_steps,
            errors           = EXCLUDED.errors;
    """

    def _msg_args(self, m: Message) -> tuple:
        return (
            m.id, m.conversation_id, m.user_id, m.role.value,
            m.original_content, m.enhanced_message,
            _j(m.explicit_context), m.episode_id,
            m.sentiment_score, m.intent, _entities_to_json(m.entities),
            m.is_cancellation, m.is_continuation, m.is_flagged, m.timestamp,
            _j(m.invoked_flows), _j(m.invoked_tools), _j(m.reasoning_steps), _j(m.errors),
        )

    async def store_message(self, message: Message) -> None:
        async with self._pool.acquire() as conn:
            await conn.execute(self._UPSERT_MSG, *self._msg_args(message))

    async def store_messages(self, messages: list[Message]) -> None:
        async with self._pool.acquire() as conn:
            await conn.executemany(self._UPSERT_MSG, [self._msg_args(m) for m in messages])

    async def update_message(self, message: Message) -> None:
        await self.store_message(message)

    async def delete_message(self, message_id: str) -> None:
        # ON DELETE CASCADE on turn_traces handles the linked trace.
        async with self._pool.acquire() as conn:
            await conn.execute("DELETE FROM messages WHERE id = $1;", message_id)

    async def flag_message(self, message_id: str) -> None:
        async with self._pool.acquire() as conn:
            await conn.execute(
                "UPDATE messages SET is_flagged = TRUE WHERE id = $1;", message_id
            )

    async def get_message_by_id(self, message_id: str) -> Message | None:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM messages WHERE id = $1;", message_id
            )
        return _row_to_message(row) if row else None

    async def get_messages_by_ids(self, message_ids: list[str]) -> list[Message]:
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM messages WHERE id = ANY($1::text[]) ORDER BY timestamp;",
                message_ids,
            )
        return [_row_to_message(r) for r in rows]

    async def get_messages_by_conversation_id(self, conversation_id: str) -> list[Message]:
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM messages WHERE conversation_id = $1 ORDER BY timestamp;",
                conversation_id,
            )
        return [_row_to_message(r) for r in rows]

    async def get_messages_by_user_id(self, user_id: str) -> list[Message]:
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM messages WHERE user_id = $1 ORDER BY timestamp;",
                user_id,
            )
        return [_row_to_message(r) for r in rows]

    async def get_immediate_context(self, conversation_id: str, n: int) -> list[Message]:
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT * FROM (
                    SELECT * FROM messages
                    WHERE conversation_id = $1
                      AND is_flagged = FALSE
                    ORDER BY timestamp DESC LIMIT $2
                ) sub ORDER BY timestamp ASC;
                """,
                conversation_id, n,
            )
        return [_row_to_message(r) for r in rows]

    # ── turn traces ───────────────────────────────────────────────────────────

    _UPSERT_TURN_TRACE = """
        INSERT INTO turn_traces (
            id, message_id, conversation_id, user_id, agent_id, turn_number,
            started_at_ms, ended_at_ms, total_latency_ms,
            total_prompt_tokens, total_completion_tokens, total_tokens,
            detected_intent, sentiment_score, is_continuation, is_cancellation,
            total_energy_kwh, total_co2_g,
            llm_calls, task_emissions, tool_traces, emission_records, slot_events,
            confirmation_events, flow_events, reasoning_steps,
            detected_entities, errors
        ) VALUES (
            $1,$2,$3,$4,$5,$6,
            $7,$8,$9,
            $10,$11,$12,
            $13,$14,$15,$16,
            $17,$18,
            $19,$20,$21,$22,$23,
            $24,$25,$26,
            $27,$28
        )
        ON CONFLICT (id) DO UPDATE SET
            message_id               = EXCLUDED.message_id,
            conversation_id          = EXCLUDED.conversation_id,
            user_id                  = EXCLUDED.user_id,
            agent_id                 = EXCLUDED.agent_id,
            turn_number              = EXCLUDED.turn_number,
            started_at_ms            = EXCLUDED.started_at_ms,
            ended_at_ms              = EXCLUDED.ended_at_ms,
            total_latency_ms         = EXCLUDED.total_latency_ms,
            total_prompt_tokens      = EXCLUDED.total_prompt_tokens,
            total_completion_tokens  = EXCLUDED.total_completion_tokens,
            total_tokens             = EXCLUDED.total_tokens,
            detected_intent          = EXCLUDED.detected_intent,
            sentiment_score          = EXCLUDED.sentiment_score,
            is_continuation          = EXCLUDED.is_continuation,
            is_cancellation          = EXCLUDED.is_cancellation,
                total_energy_kwh         = EXCLUDED.total_energy_kwh,
                total_co2_g              = EXCLUDED.total_co2_g,
            llm_calls                = EXCLUDED.llm_calls,
            task_emissions           = EXCLUDED.task_emissions,
            tool_traces              = EXCLUDED.tool_traces,
                emission_records         = EXCLUDED.emission_records,
            slot_events              = EXCLUDED.slot_events,
            confirmation_events      = EXCLUDED.confirmation_events,
            flow_events              = EXCLUDED.flow_events,
            reasoning_steps          = EXCLUDED.reasoning_steps,
            detected_entities        = EXCLUDED.detected_entities,
            errors                   = EXCLUDED.errors;
    """

    async def store_turn_trace(self, trace: TurnTrace) -> None:
        async with self._pool.acquire() as conn:
            await conn.execute(self._UPSERT_TURN_TRACE, *_turn_trace_args(trace))

    async def get_turn_trace_by_id(self, trace_id: str) -> TurnTrace | None:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM turn_traces WHERE id = $1;", trace_id
            )
        return _row_to_turn_trace(row) if row else None

    async def get_turn_trace_by_message_id(self, message_id: str) -> TurnTrace | None:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM turn_traces WHERE message_id = $1;", message_id
            )
        return _row_to_turn_trace(row) if row else None

    async def get_turn_traces_by_conversation_id(
        self, conversation_id: str
    ) -> list[TurnTrace]:
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT * FROM turn_traces
                WHERE  conversation_id = $1
                ORDER  BY turn_number ASC;
                """,
                conversation_id,
            )
        return [_row_to_turn_trace(r) for r in rows]

    async def get_turn_traces_by_agent_id(
        self,
        agent_id: str,
        limit:    int = 100,
        offset:   int = 0,
    ) -> list[TurnTrace]:
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT * FROM turn_traces
                WHERE  agent_id = $1
                ORDER  BY started_at_ms DESC
                LIMIT  $2 OFFSET $3;
                """,
                agent_id, limit, offset,
            )
        return [_row_to_turn_trace(r) for r in rows]