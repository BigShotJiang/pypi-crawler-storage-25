from __future__ import annotations

from typing import Any

from jazzmine.core.llm.utils import estimate_tokens


def estimate_llm_emissions(
    tokens: int,
    energy_per_1k_tokens_kwh: float = 0.001,
    co2_per_kwh_g: float = 500.0,
) -> dict[str, Any]:
    token_count = max(0, int(tokens))
    energy_kwh = (token_count * float(energy_per_1k_tokens_kwh)) / 1000.0
    co2_g = energy_kwh * float(co2_per_kwh_g)

    return {
        "tokens": token_count,
        "energy_kwh": max(0.0, float(energy_kwh)),
        "co2_g": max(0.0, float(co2_g)),
    }


def estimate_llm_emissions_for_text(
    text: str,
    model: str,
    energy_per_1k_tokens_kwh: float = 0.001,
    co2_per_kwh_g: float = 500.0,
) -> dict[str, Any]:
    return estimate_llm_emissions(
        tokens=estimate_tokens(text, model=model),
        energy_per_1k_tokens_kwh=energy_per_1k_tokens_kwh,
        co2_per_kwh_g=co2_per_kwh_g,
    )
