from dataclasses import dataclass
from typing import Optional, Any

@dataclass
class LLMUsage:
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cost: Optional[float] = None

@dataclass
class LLMResponse:
    text: str
    usage: LLMUsage
    model: str
    latency_ms: Optional[int] = None
    finish_reason: Optional[str] = None
    raw: Optional[Any] = None
    api_metrics: Optional[dict[str, Any]] = None

@dataclass
class MessagePart:
    role: str  # "system", "user", or "assistant"
    content: str