from __future__ import annotations

from functools import lru_cache

from jazzmine.core.llm.types import LLMUsage

try:
    import tiktoken
except Exception:  # pragma: no cover - optional dependency fallback
    tiktoken = None


@lru_cache(maxsize=128)
def _encoding_for_model(model: str):
    if tiktoken is None:
        return None

    model_name = (model or "").strip() or "gpt-4o-mini"
    try:
        return tiktoken.encoding_for_model(model_name)
    except Exception:
        try:
            return tiktoken.get_encoding("cl100k_base")
        except Exception:
            return None


def estimate_tokens(text: str, model: str = "") -> int:
    content = text or ""
    if not content:
        return 0

    encoding = _encoding_for_model(model)
    if encoding is not None:
        try:
            return max(1, len(encoding.encode(content)))
        except Exception:
            pass

    return max(1, len(content) // 4)

def normalize_usage(
    prompt: str,
    completion: str,
    provider_usage: dict | None,
    model: str = "",
) -> LLMUsage:
    if provider_usage:
        return LLMUsage(
            prompt_tokens=provider_usage.get("prompt_tokens", 0),
            completion_tokens=provider_usage.get("completion_tokens", 0),
            total_tokens=provider_usage.get("total_tokens", 0),
            cost=provider_usage.get("cost"),
        )

    prompt_tokens = estimate_tokens(prompt, model=model)
    completion_tokens = estimate_tokens(completion, model=model)

    return LLMUsage(
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        total_tokens=prompt_tokens + completion_tokens,
    )