import time
import json
from typing import Iterator, AsyncIterator, List

import boto3
import aioboto3
from botocore.exceptions import ClientError

from jazzmine.core.llm.base import BaseLLM
from jazzmine.core.llm.types import LLMResponse, MessagePart
from jazzmine.core.llm.utils import normalize_usage
from jazzmine.core.llm.errors import LLMRateLimitError, LLMInternalError

class BedrockLLM(BaseLLM):
    def __init__(self, model: str, region_name: str, **kwargs):
        super().__init__(model=model, **kwargs)
        self.region_name = region_name
        self.client = boto3.client("bedrock-runtime", region_name=region_name)
        self.session = aioboto3.Session(region_name=region_name)

    def _prepare_payload(self, messages: List[MessagePart]) -> dict:
        system_prompts =[{"text": m.content} for m in messages if m.role == "system"]
        chat_msgs =[
            {"role": m.role, "content": [{"text": m.content}]}
            for m in messages if m.role in ["user", "assistant"]
        ]
        
        config = {}
        if self.temperature is not None:
            config["temperature"] = self.temperature
        if self.max_tokens is not None:
            config["maxTokens"] = self.max_tokens

        payload = {
            "modelId": self.model,
            "messages": chat_msgs,
        }
        if system_prompts:
            payload["system"] = system_prompts
        if config:
            payload["inferenceConfig"] = config
            
        return payload

    @staticmethod
    def _payload_bytes(payload: dict) -> int:
        return len(json.dumps(payload, ensure_ascii=True).encode("utf-8"))

    def _parse_response(
        self,
        response: dict,
        start_time: float,
        request_bytes: int = 0,
        response_bytes: int = 0,
    ) -> LLMResponse:
        text = response.get("output", {}).get("MessagePart", {}).get("content", [{}])[0].get("text", "")
        usage_data = response.get("usage", {})
        usage = normalize_usage("", text, {
            "prompt_tokens": usage_data.get("inputTokens", 0),
            "completion_tokens": usage_data.get("outputTokens", 0)
        }, model=self.model)
        return LLMResponse(
            text=text, usage=usage, model=self.model,
            latency_ms=int((time.time() - start_time) * 1000),
            finish_reason=response.get("stopReason"), raw=response,
            api_metrics={
                "provider": "bedrock",
                "endpoint": "converse",
                "request_bytes": int(request_bytes),
                "response_bytes": int(response_bytes),
                "status_code": 200,
            },
        )

    def generate(self, messages: List[MessagePart], **kwargs) -> LLMResponse:
        start = time.time()
        payload = self._prepare_payload(messages)
        request_bytes = self._payload_bytes(payload)
        try:
            response = self.client.converse(**payload)
        except ClientError as e:
            err_code = e.response.get("Error", {}).get("Code")
            if err_code == "ThrottlingException": raise LLMRateLimitError(str(e))
            raise LLMInternalError(str(e))
        response_bytes = len(json.dumps(response, ensure_ascii=True).encode("utf-8"))
        return self._parse_response(
            response,
            start,
            request_bytes=request_bytes,
            response_bytes=response_bytes,
        )

    def stream(self, messages: List[MessagePart], **kwargs) -> Iterator[str]:
        try:
            response = self.client.converse_stream(**self._prepare_payload(messages))
            for event in response.get("stream", []):
                if "contentBlockDelta" in event:
                    yield event["contentBlockDelta"]["delta"]["text"]
        except ClientError as e:
            raise LLMInternalError(str(e))

    async def agenerate(self, messages: List[MessagePart], **kwargs) -> LLMResponse:
        start = time.time()
        payload = self._prepare_payload(messages)
        request_bytes = self._payload_bytes(payload)
        try:
            async with self.session.client("bedrock-runtime") as aclient:
                response = await aclient.converse(**payload)
        except ClientError as e:
            raise LLMInternalError(str(e))
        response_bytes = len(json.dumps(response, ensure_ascii=True).encode("utf-8"))
        return self._parse_response(
            response,
            start,
            request_bytes=request_bytes,
            response_bytes=response_bytes,
        )

    async def astream(self, messages: List[MessagePart], **kwargs) -> AsyncIterator[str]:
        try:
            async with self.session.client("bedrock-runtime") as aclient:
                response = await aclient.converse_stream(**self._prepare_payload(messages))
                async for event in response.get("stream",[]):
                    if "contentBlockDelta" in event:
                        yield event["contentBlockDelta"]["delta"]["text"]
        except ClientError as e:
            raise LLMInternalError(str(e))
            
    # AWS Bedrock uses boto connections, so we override the HTTPX closes
    def close(self):
        if hasattr(self, 'client') and hasattr(self.client, 'close'):
            self.client.close()
    
    async def aclose(self):
        pass # aioboto3 session clients are managed via context managers