import time
import httpx
import json
from typing import Iterator, AsyncIterator, List

from jazzmine.core.llm.base import BaseLLM
from jazzmine.core.llm.types import LLMResponse, MessagePart
from jazzmine.core.llm.utils import normalize_usage
from jazzmine.core.llm.errors import (
    LLMRateLimitError, LLMConnectionError,
    LLMInternalError, LLMInvalidRequestError, LLMTimeoutError
)

class AnthropicLLM(BaseLLM):
    def __init__(self, api_key: str, model: str, base_url: str = "https://api.anthropic.com", **kwargs):
        super().__init__(model=model, **kwargs)
        headers = {
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        self.client = httpx.Client(base_url=base_url, headers=headers, timeout=self.timeout)
        self.aclient = httpx.AsyncClient(base_url=base_url, headers=headers, timeout=self.timeout)

    def _prepare_payload(self, messages: List[MessagePart], stream: bool) -> dict:
        system_text = "\n".join([m.content for m in messages if m.role == "system"])
        api_msgs =[{"role": m.role, "content": m.content} for m in messages if m.role in ["user", "assistant"]]
        
        payload = {
            "model": self.model,
            "messages": api_msgs,
            "stream": stream,
        }
        if system_text:
            payload["system"] = system_text
        if self.max_tokens is not None:
            payload["max_tokens"] = self.max_tokens
        else:
            payload["max_tokens"] = 1024 # Anthropic requires this
        if self.temperature is not None:
            payload["temperature"] = self.temperature
            
        return payload

    @staticmethod
    def _payload_bytes(payload: dict) -> int:
        return len(json.dumps(payload, ensure_ascii=True).encode("utf-8"))

    def _handle_error(self, e: Exception):
        if isinstance(e, httpx.TimeoutException):
            raise LLMTimeoutError(str(e))
        raise LLMConnectionError(str(e))

    def _parse_response(
        self,
        data: dict,
        start_time: float,
        request_bytes: int = 0,
        response_bytes: int = 0,
        status_code: int | None = None,
    ) -> LLMResponse:
        text = "".join(block["text"] for block in data.get("content",[]) if block.get("type") == "text")
        usage_data = data.get("usage", {})
        usage = normalize_usage("", text, {
            "prompt_tokens": usage_data.get("input_tokens", 0),
            "completion_tokens": usage_data.get("output_tokens", 0)
        }, model=self.model)
        return LLMResponse(
            text=text, usage=usage, model=self.model,
            latency_ms=int((time.time() - start_time) * 1000), raw=data,
            finish_reason=data.get("stop_reason"),
            api_metrics={
                "provider": "anthropic",
                "endpoint": "/v1/messages",
                "request_bytes": int(request_bytes),
                "response_bytes": int(response_bytes),
                "status_code": status_code,
            },
        )

    def generate(self, messages: List[MessagePart], **kwargs) -> LLMResponse:
        start = time.time()
        payload = self._prepare_payload(messages, False)
        request_bytes = self._payload_bytes(payload)
        try:
            r = self.client.post("/v1/messages", json=payload)
            r.raise_for_status()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 429: raise LLMRateLimitError(e.response.text)
            if e.response.status_code == 400: raise LLMInvalidRequestError(e.response.text)
            raise LLMInternalError(e.response.text)
        except httpx.RequestError as e:
            self._handle_error(e)
        body = r.content or b""
        return self._parse_response(
            r.json(),
            start,
            request_bytes=request_bytes,
            response_bytes=len(body),
            status_code=r.status_code,
        )

    def stream(self, messages: List[MessagePart], **kwargs) -> Iterator[str]:
        try:
            with self.client.stream("POST", "/v1/messages", json=self._prepare_payload(messages, True)) as r:
                r.raise_for_status()
                for line in r.iter_lines():
                    if line.startswith("data: "):
                        payload = line[6:].strip()
                        if not payload: continue
                        try:
                            event = json.loads(payload)
                            if event.get("type") == "content_block_delta" and event.get("delta", {}).get("type") == "text_delta":
                                yield event["delta"]["text"]
                        except json.JSONDecodeError:
                            pass
        except httpx.RequestError as e:
            self._handle_error(e)

    async def agenerate(self, messages: List[MessagePart], **kwargs) -> LLMResponse:
        start = time.time()
        payload = self._prepare_payload(messages, False)
        request_bytes = self._payload_bytes(payload)
        try:
            r = await self.aclient.post("/v1/messages", json=payload)
            r.raise_for_status()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 429: raise LLMRateLimitError(e.response.text)
            if e.response.status_code == 400: raise LLMInvalidRequestError(e.response.text)
            raise LLMInternalError(e.response.text)
        except httpx.RequestError as e:
            self._handle_error(e)
        body = r.content or b""
        return self._parse_response(
            r.json(),
            start,
            request_bytes=request_bytes,
            response_bytes=len(body),
            status_code=r.status_code,
        )

    async def astream(self, messages: List[MessagePart], **kwargs) -> AsyncIterator[str]:
        try:
            async with self.aclient.stream("POST", "/v1/messages", json=self._prepare_payload(messages, True)) as r:
                r.raise_for_status()
                async for line in r.aiter_lines():
                    if line.startswith("data: "):
                        payload = line[6:].strip()
                        if not payload: continue
                        try:
                            event = json.loads(payload)
                            if event.get("type") == "content_block_delta" and event.get("delta", {}).get("type") == "text_delta":
                                yield event["delta"]["text"]
                        except json.JSONDecodeError:
                            pass
        except httpx.RequestError as e:
            self._handle_error(e)