import time
import subprocess
import asyncio
from typing import Iterator, AsyncIterator, List

from jazzmine.core.llm.base import BaseLLM
from jazzmine.core.llm.types import LLMResponse, MessagePart
from jazzmine.core.llm.utils import normalize_usage
from jazzmine.core.llm.errors import LLMInternalError

class LocalLLM(BaseLLM):
    def __init__(self, binary_path: str, **kwargs):
        super().__init__(**kwargs)
        self.binary_path = binary_path

    def _format_prompt(self, messages: List[MessagePart]) -> str:
        return "\n".join(f"{m.role.capitalize()}: {m.content}" for m in messages) + "\nAssistant: "

    def generate(self, messages: List[MessagePart], **kwargs) -> LLMResponse:
        start = time.time()
        prompt = self._format_prompt(messages)
        proc = subprocess.run([self.binary_path, "-p", prompt], capture_output=True, text=True)

        if proc.returncode != 0:
            raise LLMInternalError(proc.stderr)

        text = proc.stdout.strip()
        usage = normalize_usage(prompt, text, None, model=self.model)

        return LLMResponse(
            text=text, usage=usage, model=self.model,
            latency_ms=int((time.time() - start) * 1000), raw=proc.stdout,
            api_metrics={
                "provider": "local",
                "endpoint": "subprocess",
                "request_bytes": len(prompt.encode("utf-8")),
                "response_bytes": len(proc.stdout.encode("utf-8")),
                "status_code": 0,
            },
        )

    def stream(self, messages: List[MessagePart], **kwargs) -> Iterator[str]:
        prompt = self._format_prompt(messages)
        proc = subprocess.Popen([self.binary_path, "-p", prompt],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1
        )

        if not proc.stdout:
            raise LLMInternalError("No stdout available from binary.")

        for line in proc.stdout:
            yield line

    async def agenerate(self, messages: List[MessagePart], **kwargs) -> LLMResponse:
        start = time.time()
        prompt = self._format_prompt(messages)
        
        proc = await asyncio.create_subprocess_exec(
            self.binary_path, "-p", prompt,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await proc.communicate()

        if proc.returncode != 0:
            raise LLMInternalError(stderr.decode())

        text = stdout.decode().strip()
        usage = normalize_usage(prompt, text, None, model=self.model)

        return LLMResponse(
            text=text, usage=usage, model=self.model,
            latency_ms=int((time.time() - start) * 1000), raw=stdout.decode(),
            api_metrics={
                "provider": "local",
                "endpoint": "subprocess",
                "request_bytes": len(prompt.encode("utf-8")),
                "response_bytes": len(stdout),
                "status_code": 0,
            },
        )

    async def astream(self, messages: List[MessagePart], **kwargs) -> AsyncIterator[str]:
        prompt = self._format_prompt(messages)
        
        proc = await asyncio.create_subprocess_exec(
            self.binary_path, "-p", prompt,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )

        if not proc.stdout:
            raise LLMInternalError("No stdout available from binary.")

        async for line in proc.stdout:
            yield line.decode()
            
    def close(self): pass
    async def aclose(self): pass