import time
import httpx
import json
from typing import Iterator, AsyncIterator, List, Optional

from jazzmine.core.llm.base import BaseLLM
from jazzmine.core.llm.types import LLMResponse, MessagePart
from jazzmine.core.llm.utils import normalize_usage
from jazzmine.core.llm.errors import (
    LLMRateLimitError, LLMConnectionError,
    LLMInternalError, LLMTimeoutError,
)


class OpenAICompatibleLLM(BaseLLM):
    def __init__(
        self,
        api_key: str,
        base_url: str,
        chat_endpoint: str = "/v1/chat/completions",
        top_p: Optional[float] = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.chat_endpoint = chat_endpoint
        self.top_p = top_p
        headers = {"Authorization": f"Bearer {api_key}"}
        self.client  = httpx.Client(base_url=base_url, headers=headers, timeout=self.timeout)
        self.aclient = httpx.AsyncClient(base_url=base_url, headers=headers, timeout=self.timeout)

    def _prepare_payload(self, messages: List[MessagePart], stream: bool) -> dict:
        payload = {
            "model":    self.model,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "stream":   stream,
        }
        if self.temperature is not None:
            payload["temperature"] = self.temperature
        if self.max_tokens is not None:
            payload["max_tokens"] = self.max_tokens
        if self.top_p is not None:
            payload["top_p"] = self.top_p
        return payload

    @staticmethod
    def _payload_bytes(payload: dict) -> int:
        return len(json.dumps(payload, ensure_ascii=True).encode("utf-8"))

    def _handle_request_error(self, e: Exception):
        if isinstance(e, httpx.TimeoutException):
            raise LLMTimeoutError(str(e))
        raise LLMConnectionError(str(e))

    def _parse_response(
        self,
        data: dict,
        start_time: float,
        request_bytes: int = 0,
        response_bytes: int = 0,
        status_code: int | None = None,
    ) -> LLMResponse:
        # BUG FIX: was data["choices"][0]["MessagePart"]["content"]
        #          correct key is "message", not "MessagePart"
        text = data["choices"][0]["message"]["content"]
        usage = normalize_usage("", text, data.get("usage"), model=self.model)
        return LLMResponse(
            text=text,
            usage=usage,
            model=self.model,
            latency_ms=int((time.time() - start_time) * 1000),
            finish_reason=data["choices"][0].get("finish_reason"),
            raw=data,
            api_metrics={
                "provider": "openai_compatible",
                "endpoint": self.chat_endpoint,
                "request_bytes": int(request_bytes),
                "response_bytes": int(response_bytes),
                "status_code": status_code,
            },
        )

    def generate(self, messages: List[MessagePart], **kwargs) -> LLMResponse:
        start = time.time()
        payload = self._prepare_payload(messages, False)
        request_bytes = self._payload_bytes(payload)
        try:
            r = self.client.post(self.chat_endpoint, json=payload)
            r.raise_for_status()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 429:
                raise LLMRateLimitError(e.response.text)
            raise LLMInternalError(e.response.text)
        except httpx.RequestError as e:
            self._handle_request_error(e)
        body = r.content or b""
        return self._parse_response(
            r.json(),
            start,
            request_bytes=request_bytes,
            response_bytes=len(body),
            status_code=r.status_code,
        )

    def stream(self, messages: List[MessagePart], **kwargs) -> Iterator[str]:
        try:
            with self.client.stream("POST", self.chat_endpoint, json=self._prepare_payload(messages, True)) as r:
                r.raise_for_status()
                for line in r.iter_lines():
                    if not line.startswith("data: "):
                        continue
                    payload = line[6:].strip()
                    if payload == "[DONE]":
                        break
                    if not payload:
                        continue
                    data = json.loads(payload)
                    if data.get("choices") and "content" in data["choices"][0].get("delta", {}):
                        yield data["choices"][0]["delta"]["content"]
        except httpx.RequestError as e:
            self._handle_request_error(e)

    async def agenerate(self, messages: List[MessagePart], **kwargs) -> LLMResponse:
        start = time.time()
        payload = self._prepare_payload(messages, False)
        request_bytes = self._payload_bytes(payload)
        try:
            r = await self.aclient.post(self.chat_endpoint, json=payload)
            r.raise_for_status()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 429:
                raise LLMRateLimitError(e.response.text)
            raise LLMInternalError(e.response.text)
        except httpx.RequestError as e:
            self._handle_request_error(e)
        body = r.content or b""
        return self._parse_response(
            r.json(),
            start,
            request_bytes=request_bytes,
            response_bytes=len(body),
            status_code=r.status_code,
        )

    async def astream(self, messages: List[MessagePart], **kwargs) -> AsyncIterator[str]:
        try:
            async with self.aclient.stream("POST", self.chat_endpoint, json=self._prepare_payload(messages, True)) as r:
                r.raise_for_status()
                async for line in r.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    payload = line[6:].strip()
                    if payload == "[DONE]":
                        break
                    if not payload:
                        continue
                    data = json.loads(payload)
                    if data.get("choices") and "content" in data["choices"][0].get("delta", {}):
                        yield data["choices"][0]["delta"]["content"]
        except httpx.RequestError as e:
            self._handle_request_error(e)