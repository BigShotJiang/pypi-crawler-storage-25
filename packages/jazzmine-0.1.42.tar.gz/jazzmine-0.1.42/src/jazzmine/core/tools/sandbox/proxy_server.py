"""
proxy_server.py
───────────────
Lightweight async TCP proxy that enforces the network allowlist.
Runs as a sidecar container on the same Docker network as the tool container.

The tool container is started with:
  HTTP_PROXY=http://proxy:8888
  HTTPS_PROXY=http://proxy:8888
  NO_PROXY=localhost,127.0.0.1

All HTTP and HTTPS traffic is routed through this proxy.
DNS is resolved by the proxy — the tool container never resolves DNS directly,
preventing allowlist bypass via raw IP addresses.

Configuration (environment variables):
  PROXY_PORT       — port to listen on (default: 8888)
  PROXY_ALLOWLIST  — comma-separated "host:port" pairs
                     e.g. "api.stripe.com:443,1.2.3.4:8080"

Traffic to any host:port not in the allowlist receives HTTP 403.
"""

import asyncio
import ipaddress
import json
import logging
import os
import socket
import sys
import time
import uuid
from typing import Set, Tuple

logging.basicConfig(
    level   = logging.INFO,
    format  = "%(asctime)s [proxy] %(levelname)s %(message)s",
    stream  = __import__("sys").stderr,
)
log = logging.getLogger(__name__)

BUFFER_SIZE = 65_536


def _emit_proxy_event(event_type: str, **fields) -> None:
    payload = {
        "kind": "proxy_event",
        "event_type": event_type,
        "event_id": uuid.uuid4().hex,
        "ts_ms": int(time.time() * 1000),
    }
    payload.update(fields)
    try:
        print(json.dumps(payload, ensure_ascii=True), file=sys.stderr, flush=True)
    except Exception:
        pass


# ── Allowlist ──────────────────────────────────────────────────────────────────

def _load_allowlist() -> Set[Tuple[str, int]]:
    raw = os.environ.get("PROXY_ALLOWLIST", "").strip()
    if not raw:
        log.warning("PROXY_ALLOWLIST is empty — all traffic will be blocked")
        return set()

    allowed: Set[Tuple[str, int]] = set()
    for entry in raw.split(","):
        entry = entry.strip()
        if not entry:
            continue
        if ":" in entry:
            host, _, port_str = entry.rpartition(":")
            try:
                allowed.add((host.lower(), int(port_str)))
            except ValueError:
                log.warning(f"Ignoring malformed allowlist entry: {entry!r}")
        else:
            # No port specified — allow both 80 and 443
            allowed.add((entry.lower(), 80))
            allowed.add((entry.lower(), 443))

    log.info(f"Allowlist loaded: {len(allowed)} entries")
    for host, port in sorted(allowed):
        log.info(f"  ALLOW {host}:{port}")
    return allowed


ALLOWLIST: Set[Tuple[str, int]] = _load_allowlist()


def _is_allowed(host: str, port: int) -> bool:
    """
    Check the allowlist. 
    
    Supports both hostnames and IP addresses. 
    If the 'host' is an IP address, it is only allowed if that specific 
    IP:Port pair is explicitly present in the ALLOWLIST. This prevents 
    bypass attempts via unauthorized raw IPs.
    """
    if not ALLOWLIST:
        return False

    # Check if it's an IP address
    try:
        ipaddress.ip_address(host)
        # It is an IP. Check if it's explicitly allowed.
        if (host.lower(), port) in ALLOWLIST:
            return True
        else:
            log.warning(f"Blocked unauthorized raw IP address: {host}:{port}")
            return False
    except ValueError:
        # Not an IP, it's a hostname. Check the allowlist normally.
        return (host.lower(), port) in ALLOWLIST


# ── Pipe helper ────────────────────────────────────────────────────────────────

async def _pipe(
    reader:       asyncio.StreamReader,
    writer:       asyncio.StreamWriter,
    label:        str,
    byte_counter: list,  # mutable [int] for tracking total bytes piped
) -> None:
    """Bidirectional pipe between two asyncio streams."""
    try:
        while True:
            chunk = await reader.read(BUFFER_SIZE)
            if not chunk:
                break
            byte_counter[0] += len(chunk)
            writer.write(chunk)
            await writer.drain()
    except (ConnectionResetError, BrokenPipeError, asyncio.CancelledError):
        pass
    except Exception as exc:
        log.debug(f"Pipe {label} error: {exc}")
    finally:
        try:
            writer.close()
            await writer.wait_closed()
        except Exception:
            pass


# ── HTTPS CONNECT tunneling ────────────────────────────────────────────────────

async def _handle_connect(
    client_reader: asyncio.StreamReader,
    client_writer: asyncio.StreamWriter,
    source_ip:     str,
    host:          str,
    port:          int,
) -> None:
    """
    Establish a blind TCP tunnel for HTTPS CONNECT requests.
    We never decrypt HTTPS — we just forward encrypted bytes.
    """
    if not _is_allowed(host, port):
        log.warning(f"BLOCKED CONNECT {host}:{port}")
        _emit_proxy_event(
            "api_call",
            source_ip=source_ip,
            host=host,
            port=port,
            method="CONNECT",
            request_bytes=0,
            response_bytes=0,
            status_code=403,
            success=False,
            duration_ms=0,
        )
        client_writer.write(b"HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n")
        await client_writer.drain()
        client_writer.close()
        return

    try:
        target_reader, target_writer = await asyncio.open_connection(host, port)
    except (OSError, ConnectionRefusedError) as exc:
        log.error(f"Cannot connect to {host}:{port}: {exc}")
        _emit_proxy_event(
            "api_call",
            source_ip=source_ip,
            host=host,
            port=port,
            method="CONNECT",
            request_bytes=0,
            response_bytes=0,
            status_code=502,
            success=False,
            duration_ms=0,
            error=str(exc),
        )
        client_writer.write(b"HTTP/1.1 502 Bad Gateway\r\nContent-Length: 0\r\n\r\n")
        await client_writer.drain()
        client_writer.close()
        return

    started = time.monotonic()
    client_writer.write(b"HTTP/1.1 200 Connection Established\r\n\r\n")
    await client_writer.drain()

    request_counter = [0]
    response_counter = [0]
    await asyncio.gather(
        _pipe(client_reader, target_writer, f"client→{host}:{port}", request_counter),
        _pipe(target_reader, client_writer, f"{host}:{port}→client", response_counter),
    )
    duration_ms = int((time.monotonic() - started) * 1000)
    total_bytes = request_counter[0] + response_counter[0]
    log.info(f"CONNECT {host}:{port} closed — {total_bytes:,} bytes")
    _emit_proxy_event(
        "api_call",
        source_ip=source_ip,
        host=host,
        port=port,
        method="CONNECT",
        request_bytes=request_counter[0],
        response_bytes=response_counter[0],
        status_code=200,
        success=True,
        duration_ms=duration_ms,
    )


# ── Plain HTTP forwarding ──────────────────────────────────────────────────────

async def _handle_http(
    client_reader: asyncio.StreamReader,
    client_writer: asyncio.StreamWriter,
    source_ip:     str,
    method:        str,
    url:           str,
    headers:       dict,
    body:          bytes,
) -> None:
    """
    Forward a plain HTTP request. Rare in production (most APIs use HTTPS)
    but needed for internal services and some health-check endpoints.
    """
    # Determine host and port from Host header or URL
    host_header = headers.get("host", "")
    if ":" in host_header:
        host, _, port_str = host_header.rpartition(":")
        port = int(port_str)
    else:
        host = host_header
        port = 80

    if not _is_allowed(host, port):
        log.warning(f"BLOCKED {method} {url}")
        _emit_proxy_event(
            "api_call",
            source_ip=source_ip,
            host=host,
            port=port,
            method=method,
            request_bytes=len(body),
            response_bytes=0,
            status_code=403,
            success=False,
            duration_ms=0,
            path=url,
        )
        client_writer.write(b"HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n")
        await client_writer.drain()
        return

    try:
        target_reader, target_writer = await asyncio.open_connection(host, port)
    except (OSError, ConnectionRefusedError) as exc:
        log.error(f"Cannot connect to {host}:{port}: {exc}")
        _emit_proxy_event(
            "api_call",
            source_ip=source_ip,
            host=host,
            port=port,
            method=method,
            request_bytes=len(body),
            response_bytes=0,
            status_code=502,
            success=False,
            duration_ms=0,
            path=url,
            error=str(exc),
        )
        client_writer.write(b"HTTP/1.1 502 Bad Gateway\r\nContent-Length: 0\r\n\r\n")
        await client_writer.drain()
        return

    # Reconstruct the request without the full URL (proxy format → origin format)
    try:
        path = "/" + "/".join(url.split("/")[3:]) if "://" in url else url
    except Exception:
        path = "/"

    request_lines = [f"{method} {path} HTTP/1.1"]
    for k, v in headers.items():
        request_lines.append(f"{k}: {v}")
    request_lines.append("")
    request_lines.append("")
    raw_request = "\r\n".join(request_lines).encode() + body
    started = time.monotonic()

    target_writer.write(raw_request)
    await target_writer.drain()

    response_counter = [0]
    status_code = 0
    first_chunk = await target_reader.read(BUFFER_SIZE)
    if first_chunk:
        response_counter[0] += len(first_chunk)
        status_code = _parse_http_status(first_chunk)
        client_writer.write(first_chunk)
        await client_writer.drain()

    await _pipe(target_reader, client_writer, f"{host}:{port}→client", response_counter)
    duration_ms = int((time.monotonic() - started) * 1000)
    log.info(f"{method} {host}:{port}{path} — {response_counter[0]:,} bytes")
    _emit_proxy_event(
        "api_call",
        source_ip=source_ip,
        host=host,
        port=port,
        method=method,
        path=path,
        request_bytes=len(raw_request),
        response_bytes=response_counter[0],
        status_code=status_code,
        success=200 <= status_code < 400 if status_code else True,
        duration_ms=duration_ms,
    )


# ── Connection handler ─────────────────────────────────────────────────────────

async def _handle_client(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
) -> None:
    peer = writer.get_extra_info("peername", "unknown")
    source_ip = peer[0] if isinstance(peer, tuple) and peer else str(peer)
    try:
        # Read request line
        try:
            first_line = await asyncio.wait_for(reader.readline(), timeout=10.0)
        except asyncio.TimeoutError:
            log.debug(f"Timeout reading request line from {peer}")
            return

        if not first_line:
            return

        decoded = first_line.decode("utf-8", errors="replace").strip()
        parts   = decoded.split(" ")
        if len(parts) < 2:
            return

        method, target = parts[0], parts[1]

        # Read all headers
        headers: dict = {}
        while True:
            try:
                line = await asyncio.wait_for(reader.readline(), timeout=5.0)
            except asyncio.TimeoutError:
                break
            if line in (b"\r\n", b"\n", b""):
                break
            if b":" in line:
                key, _, value = line.decode("utf-8", errors="replace").partition(":")
                headers[key.strip().lower()] = value.strip()

        if method.upper() == "CONNECT":
            # HTTPS tunnel
            if ":" in target:
                host, _, port_str = target.rpartition(":")
                port = int(port_str) if port_str.isdigit() else 443
            else:
                host, port = target, 443
            await _handle_connect(reader, writer, source_ip, host, port)

        else:
            # Plain HTTP
            content_length = int(headers.get("content-length", 0))
            body = await reader.read(content_length) if content_length > 0 else b""
            await _handle_http(reader, writer, source_ip, method, target, headers, body)

    except Exception as exc:
        log.error(f"Handler error for {peer}: {exc}")
    finally:
        try:
            writer.close()
            await writer.wait_closed()
        except Exception:
            pass


# ── Main ───────────────────────────────────────────────────────────────────────

async def _main() -> None:
    port   = int(os.environ.get("PROXY_PORT", "8888"))
    server = await asyncio.start_server(_handle_client, "0.0.0.0", port)
    log.info(f"Proxy listening on 0.0.0.0:{port}")
    async with server:
        await server.serve_forever()


def _parse_http_status(chunk: bytes) -> int:
    try:
        line = chunk.split(b"\r\n", 1)[0].decode("utf-8", errors="replace")
        parts = line.split(" ")
        if len(parts) >= 2 and parts[1].isdigit():
            return int(parts[1])
    except Exception:
        return 0
    return 0


if __name__ == "__main__":
    asyncio.run(_main())