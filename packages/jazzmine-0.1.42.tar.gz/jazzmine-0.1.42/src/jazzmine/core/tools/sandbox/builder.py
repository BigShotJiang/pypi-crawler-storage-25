"""
sandbox_builder.py
──────────────────
Builds Docker images for sandbox environments and manages the proxy sidecar.

Responsibilities:
  - Generate a minimal, hardened Dockerfile from a SandboxConfig
  - Write tool source files into a build context
  - Build (or skip if up-to-date) the sandbox image via the Docker SDK
  - Start/stop the proxy sidecar container
  - Create isolated Docker networks per sandbox
  - Connect the proxy to each sandbox network so sandbox containers can reach it

Image rebuild is triggered only when the sandbox checksum changes
(any tool source or dependency changed). Unchanged images are reused,
making repeated agent restarts nearly instantaneous.

Image naming: jazzmine-sandbox-<sandbox_name>:<checksum>
              jazzmine-proxy:<checksum>

Proxy image:  python:3.11-slim with just the proxy_server.py copied in.

DooD note (Docker-out-of-Docker)
─────────────────────────────────
docker.from_env() and all Docker API calls work identically whether the agent
runs on the host or inside a container, AS LONG AS the Docker socket is
mounted into the agent container:

    docker run -v /var/run/docker.sock:/var/run/docker.sock \
               --group-add $(stat -c '%g' /var/run/docker.sock) \
               your-agent-image

SandboxBuilder.__init__ performs an early connectivity check and raises a
clear error with instructions if the socket is missing or unreadable.
"""

from __future__ import annotations

import asyncio
import hashlib
import io
import json
import logging
import os
import tarfile
import tempfile
import time
from collections import deque
from pathlib import Path
from typing import Any, Deque, Dict, Optional, Set

import docker  # docker-py
import docker.errors

from jazzmine.core.tools.sandbox.config import SandboxConfig
from jazzmine.core.tools.registry import ToolRegistry

log = logging.getLogger(__name__)

# Path to this directory (to locate container/ files for COPY)
_HERE = Path(__file__).parent

PROXY_IMAGE_NAME     = "jazzmine-proxy"
SANDBOX_IMAGE_PREFIX = "jazzmine-sandbox"
NETWORK_PREFIX       = "jazzmine-net"
_MAX_PROXY_EVENTS    = 5000
_MAX_PROXY_SEEN_IDS  = 20_000


# ── Dockerfile templates ───────────────────────────────────────────────────────

_SANDBOX_DOCKERFILE = """\
FROM python:{python_version}-slim

ENV PIP_DISABLE_PIP_VERSION_CHECK=1 \
    PIP_DEFAULT_TIMEOUT=100 \
    PIP_NO_CACHE_DIR=1

WORKDIR /build
COPY requirements.txt .

# Install deps into a dedicated target dir and remove large non-runtime files.
RUN python -m pip install --prefer-binary --only-binary=:all: --no-compile -r requirements.txt --target /opt/pydeps && \
    rm -rf /opt/pydeps/pandas/tests /opt/pydeps/numpy/tests /opt/pydeps/setuptools/tests && \
    find /opt/pydeps -type d -name "__pycache__" -prune -exec rm -rf {{}} + && \
    find /opt/pydeps -type f \\( -name "*.pyc" -o -name "*.pyo" \\) -delete

ENV PYTHONDONTWRITEBYTECODE=1 \
    PYTHONUNBUFFERED=1 \
    PIP_DISABLE_PIP_VERSION_CHECK=1 \
    PYTHONPATH=\"/opt/pydeps\"

# ── Security hardening ───────────────────────────────────────────────────────
# Run as non-root. All capabilities dropped at container run time via --cap-drop.
RUN groupadd --force --gid 1001 sandbox && \
    id -u sandbox >/dev/null 2>&1 || useradd --uid 1001 --gid sandbox --no-create-home --shell /bin/false sandbox

# Strip packaging/tooling bits not needed at runtime to keep image lean.
RUN rm -rf /usr/local/lib/python*/test /usr/local/lib/python*/idlelib /usr/local/lib/python*/tkinter /usr/local/lib/python*/ensurepip && \
    rm -rf /usr/local/lib/python*/site-packages/pip* /usr/local/lib/python*/site-packages/setuptools* /usr/local/lib/python*/site-packages/wheel* && \
    rm -f /usr/local/bin/pip /usr/local/bin/pip3 /usr/local/bin/pip3.*

# Avoid apt operations in sandbox image builds to reduce cold-start latency
# on Docker Desktop/Windows. Runtime restrictions still apply via network
# policy, read-only rootfs, dropped caps, and no-new-privileges.
RUN set -eux; \
    for bin in wget curl nc netcat nmap gcc g++ make; do \
        if command -v "$bin" >/dev/null 2>&1; then rm -f "$(command -v "$bin")"; fi; \
    done

# ── Copy tool source files ────────────────────────────────────────────────────
RUN mkdir -p /tools
COPY tools/ /tools/

# ── Copy executor harness ─────────────────────────────────────────────────────
COPY executor_harness.py /executor_harness.py

# ── Runtime directories ───────────────────────────────────────────────────────
# /workspace — writable tmpfs mounted at run time (scratch space)
# /data      — read-only bind mounts for declared file resources
RUN mkdir -p /workspace /data && \\
    chown sandbox:sandbox /workspace

USER sandbox
WORKDIR /workspace

# stdin → executor harness → stdout (event stream)
ENTRYPOINT ["python", "-u", "/executor_harness.py"]
"""

_PROXY_DOCKERFILE = """\
FROM python:3.11-slim

RUN groupadd --force --gid 1002 proxy && \
    id -u proxy >/dev/null 2>&1 || useradd --uid 1002 --gid proxy --no-create-home --shell /bin/false proxy
    
COPY proxy_server.py /proxy_server.py

USER proxy
EXPOSE 8888
ENTRYPOINT ["python", "-u", "/proxy_server.py"]
"""


# ── Build context helpers ──────────────────────────────────────────────────────

def _build_tar(files: Dict[str, bytes]) -> io.BytesIO:
    """
    Create an in-memory tar archive suitable for docker-py's build() method.
    files: mapping of archive path → file content bytes.
    """
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w") as tar:
        for arcname in sorted(files.keys()):
            content = files[arcname]
            info       = tarfile.TarInfo(name=arcname)
            info.size  = len(content)
            info.mtime = 0
            info.mode  = 0o644
            info.uid   = 0
            info.gid   = 0
            tar.addfile(info, io.BytesIO(content))
    buf.seek(0)
    return buf


# ── SandboxBuilder ─────────────────────────────────────────────────────────────

class SandboxBuilder:
    """
    Builds Docker images and manages network/proxy infrastructure for sandboxes.

    Usage:
        builder = SandboxBuilder(registry)
        await builder.ensure_sandbox("default")          # build image if stale
        await builder.ensure_proxy("jazzmine-net-default") # start proxy sidecar

    The builder is stateful — it tracks which images have already been built
    in this process lifetime to avoid redundant Docker API calls.

    DooD usage:
        Works without any changes to this class. Mount the Docker socket and
        match the group ID as described in the module docstring.
    """

    def __init__(self, registry: ToolRegistry) -> None:
        self._registry      = registry
        self._docker        = self._connect_docker()
        self._built_images: Dict[str, str]  = {}   # sandbox_name → image_tag
        self._proxy_cid:    Optional[str]   = None  # proxy container ID
        self._networks:     Dict[str, str]  = {}   # sandbox_name → network_id
        self._proxy_events: Deque[Dict[str, Any]] = deque(maxlen=_MAX_PROXY_EVENTS)
        self._proxy_seen_ids: Deque[str] = deque()
        self._proxy_seen_lookup: Set[str] = set()
        self._proxy_log_since_s: int = max(0, int(time.time()) - 1)

    # ── Docker client initialisation ───────────────────────────────────────────

    @staticmethod
    def _connect_docker() -> docker.DockerClient:
        """
        Connect to the Docker daemon via docker.from_env() and verify
        reachability with a ping.

        Raises a clear RuntimeError when the socket is missing (the most common
        DooD misconfiguration) so operators get an actionable message instead of
        a raw DockerException.
        """
        sock = "/var/run/docker.sock"
        try:
            client = docker.from_env()
            client.ping()
            return client
        except docker.errors.DockerException as exc:
            if not os.path.exists(sock):
                raise RuntimeError(
                    "Docker socket not found. If the agent is running inside a "
                    "container (DooD mode), mount the socket and match its group:\n\n"
                    "    docker run \\\n"
                    f"        -v {sock}:{sock} \\\n"
                    f"        --group-add $(stat -c '%g' {sock}) \\\n"
                    "        your-agent-image\n\n"
                    "Or bake the docker group into your agent Dockerfile:\n\n"
                    "    ARG DOCKER_GID=999\n"
                    "    RUN groupadd -g ${DOCKER_GID} docker \\\n"
                    "     && usermod -aG docker your_agent_user\n"
                ) from exc
            if os.path.exists(sock) and not os.access(sock, os.R_OK | os.W_OK):
                raise RuntimeError(
                    f"Docker socket exists at {sock} but is not readable/writable "
                    "by the current process. Add the socket's group to the agent "
                    "user or run with --group-add as shown above."
                ) from exc
            raise

    # ── Public API ─────────────────────────────────────────────────────────────

    async def ensure_sandbox(self, sandbox_name: str) -> str:
        """
        Build the sandbox image if it doesn't exist or is stale.
        Returns the image tag (used by SandboxPool to start containers).
        """
        config = self._registry.get_sandbox(sandbox_name)
        if config is None:
            raise ValueError(f"No sandbox registered with name '{sandbox_name}'")

        checksum = self._registry.sandbox_checksum(sandbox_name)
        recipe_hash = hashlib.sha256(_SANDBOX_DOCKERFILE.encode("utf-8")).hexdigest()[:8]
        image_tag = f"{SANDBOX_IMAGE_PREFIX}-{sandbox_name}:{checksum}-{recipe_hash}"

        # Already built this run
        if self._built_images.get(sandbox_name) == image_tag:
            return image_tag

        # Check if the image exists in Docker
        if await self._image_exists(image_tag):
            log.info(f"Sandbox image up-to-date: {image_tag}")
            self._built_images[sandbox_name] = image_tag
            return image_tag

        log.info(f"Building sandbox image: {image_tag}")
        await asyncio.get_event_loop().run_in_executor(
            None, self._build_sandbox_image, config, sandbox_name, image_tag
        )
        self._built_images[sandbox_name] = image_tag
        log.info(f"Sandbox image built: {image_tag}")
        return image_tag

    async def ensure_proxy(self, network_name: Optional[str] = None) -> str:
        """
        Ensure the proxy sidecar image exists and a proxy container is running.

        If network_name is provided the proxy container is connected to that
        network so sandbox containers on the same network can reach it.  The IP
        returned is always the one on network_name (if given), which is the only
        address reachable by sandbox containers.

        Without network_name the method falls back to returning any IP — useful
        for bare-host setups where cross-bridge routing is unrestricted.
        """
        proxy_tag = f"{PROXY_IMAGE_NAME}:latest"
        desired_allowlist = self._build_proxy_allowlist_env()

        if not await self._image_exists(proxy_tag):
            log.info("Building proxy image")
            await asyncio.get_event_loop().run_in_executor(
                None, self._build_proxy_image, proxy_tag
            )

        proxy_running = bool(self._proxy_cid and await self._container_running(self._proxy_cid))

        # If the proxy is running with stale configuration, restart it so
        # newly configured sandbox allowlists are actually enforced.
        if proxy_running and self._proxy_cid is not None:
            current_allowlist = await self._proxy_allowlist_from_container(self._proxy_cid)
            if current_allowlist != desired_allowlist:
                log.info(
                    "Restarting proxy due to allowlist change: current=%r desired=%r",
                    current_allowlist,
                    desired_allowlist,
                )
                await asyncio.get_event_loop().run_in_executor(
                    None, self._remove_container, self._proxy_cid
                )
                self._proxy_cid = None
                self._reset_proxy_event_cache()
                proxy_running = False

        if not proxy_running:
            cid = await asyncio.get_event_loop().run_in_executor(
                None, self._start_proxy_container, proxy_tag, desired_allowlist
            )
            self._proxy_cid = cid
            self._reset_proxy_event_cache()
            log.info(f"Proxy container started: {cid[:12]}")

        if network_name:
            await self._connect_to_network(self._proxy_cid, network_name)
            return await self._container_ip(self._proxy_cid, network_name)

        return await self._container_ip(self._proxy_cid)

    async def ensure_network(self, sandbox_name: str) -> str:
        """
        Create (or return existing) isolated Docker network for a sandbox.
        The tool container and proxy container both attach to this network.
        """
        net_name = f"{NETWORK_PREFIX}-{sandbox_name}"
        if sandbox_name in self._networks:
            return net_name

        existing = await asyncio.get_event_loop().run_in_executor(
            None, lambda: self._docker.networks.list(names=[net_name])
        )
        if existing:
            self._networks[sandbox_name] = existing[0].id
            return net_name

        net = await asyncio.get_event_loop().run_in_executor(
            None,
            lambda: self._docker.networks.create(
                net_name,
                driver  = "bridge",
                options = {"com.docker.network.bridge.enable_ip_masquerade": "false"},
            )
        )
        self._networks[sandbox_name] = net.id
        log.info(f"Created network: {net_name}")
        return net_name

    async def stop_proxy(self) -> None:
        if self._proxy_cid:
            await asyncio.get_event_loop().run_in_executor(
                None, self._remove_container, self._proxy_cid
            )
            self._proxy_cid = None
            self._reset_proxy_event_cache()

    async def get_proxy_api_events(self) -> list[dict[str, Any]]:
        """
        Return normalized proxy API-call events observed so far.

        Events are fetched incrementally from proxy stderr logs and deduplicated
        by event_id to keep per-attempt correlation overhead low.
        """
        if not self._proxy_cid:
            return []

        await self._refresh_proxy_events()
        return list(self._proxy_events)

    # ── Private: image build ───────────────────────────────────────────────────

    def _build_sandbox_image(
        self,
        config:       SandboxConfig,
        sandbox_name: str,
        image_tag:    str,
    ) -> None:
        deps  = self._registry.aggregate_dependencies(sandbox_name)
        tools = sorted(
            self._registry.tools_for_sandbox(sandbox_name),
            key=lambda t: t.tool.name,
        )

        files: Dict[str, bytes] = {}

        files["Dockerfile"] = _SANDBOX_DOCKERFILE.format(
            python_version=config.python_version
        ).encode()

        reqs = "\n".join(deps)
        files["requirements.txt"] = reqs.encode()

        for registered in tools:
            filename = f"tools/{registered.tool.name}.py"
            files[filename] = registered.source.encode()

        harness_path = _HERE / "executor_harness.py"
        files["executor_harness.py"] = harness_path.read_bytes()

        build_ctx = _build_tar(files)
        self._docker.images.build(
            fileobj        = build_ctx,
            custom_context = True,
            tag            = image_tag,
            rm             = True,
            forcerm        = True,
        )

    def _build_proxy_image(self, tag: str) -> None:
        proxy_src = (_HERE / "proxy_server.py").read_bytes()
        files: Dict[str, bytes] = {
            "Dockerfile":      _PROXY_DOCKERFILE.encode(),
            "proxy_server.py": proxy_src,
        }
        build_ctx = _build_tar(files)
        self._docker.images.build(
            fileobj        = build_ctx,
            custom_context = True,
            tag            = tag,
            rm             = True,
        )

    def _build_proxy_allowlist_env(self) -> str:
        """
        Build a deterministic, deduplicated host:port allowlist for the proxy
        by unioning every non-isolated sandbox network policy.
        """
        pairs: set[str] = set()

        for sandbox_name in self._registry.all_sandbox_names():
            cfg = self._registry.get_sandbox(sandbox_name)
            if cfg is None or cfg.network_policy.is_isolated:
                continue

            for host in cfg.network_policy.allowed_hosts:
                ports = cfg.network_policy.allowed_ports.get(
                    host,
                    [cfg.network_policy.default_port],
                )
                for port in ports:
                    pairs.add(f"{host}:{int(port)}")

        return ",".join(sorted(pairs))

    async def _proxy_allowlist_from_container(self, cid: str) -> str:
        """Read PROXY_ALLOWLIST from a running proxy container."""
        loop = asyncio.get_event_loop()
        try:
            container = await loop.run_in_executor(
                None,
                lambda: self._docker.containers.get(cid),
            )
            container.reload()
            env_list = container.attrs.get("Config", {}).get("Env", [])
            for entry in env_list:
                if entry.startswith("PROXY_ALLOWLIST="):
                    return entry.split("=", 1)[1]
        except docker.errors.NotFound:
            return ""
        except Exception as exc:
            log.warning("Could not read proxy env from %s: %s", cid[:12], exc)
            return ""
        return ""

    # ── Private: container management ─────────────────────────────────────────

    def _start_proxy_container(self, image_tag: str, allowlist_env: str) -> str:
        container = self._docker.containers.run(
            image  = image_tag,
            detach = True,
            remove = False,
            name   = f"{PROXY_IMAGE_NAME}-{os.getpid()}",
            environment = {"PROXY_ALLOWLIST": allowlist_env},
            # Proxy gets no resource limits — it's trusted infrastructure
        )
        return container.id

    def _remove_container(self, cid: str) -> None:
        try:
            c = self._docker.containers.get(cid)
            c.stop(timeout=5)
            c.remove()
        except docker.errors.NotFound:
            pass

    # ── Private: network helpers ───────────────────────────────────────────────

    async def _connect_to_network(self, container_id: str, network_name: str) -> None:
        """
        Connect the proxy container to a sandbox network if not already connected.

        This is what makes the proxy reachable from sandbox containers.  Docker's
        default iptables rules block traffic between user-defined bridge networks,
        so the proxy must be explicitly connected to each sandbox network rather
        than relying on cross-bridge routing.

        The call is idempotent — connecting an already-connected container raises
        an APIError with "already exists" in the message, which is silently ignored.
        """
        loop = asyncio.get_event_loop()
        try:
            network = await loop.run_in_executor(
                None, lambda: self._docker.networks.get(network_name)
            )
            await loop.run_in_executor(
                None, lambda: network.connect(container_id)
            )
            log.info(f"Connected proxy {container_id[:12]} to {network_name}")
        except docker.errors.APIError as exc:
            msg = str(exc).lower()
            if "already exists" in msg or "already" in msg or "endpoint with name" in msg:
                log.debug(f"Proxy already connected to {network_name} — skipping")
            else:
                log.warning(f"Could not connect proxy to {network_name}: {exc}")

    # ── Private: proxy event ingestion ───────────────────────────────────────

    def _reset_proxy_event_cache(self) -> None:
        self._proxy_events.clear()
        self._proxy_seen_ids.clear()
        self._proxy_seen_lookup.clear()
        self._proxy_log_since_s = max(0, int(time.time()) - 1)

    async def _refresh_proxy_events(self) -> None:
        """Pull new proxy events from stderr logs and append to local cache."""
        if not self._proxy_cid:
            return

        since_s = max(0, self._proxy_log_since_s - 1)
        lines = await asyncio.get_event_loop().run_in_executor(
            None,
            self._proxy_log_lines,
            self._proxy_cid,
            since_s,
        )

        newest_ts_ms = 0
        for line in lines:
            stripped = line.strip()
            if not stripped:
                continue
            try:
                payload = json.loads(stripped)
            except json.JSONDecodeError:
                continue

            event = self._normalise_proxy_event(payload)
            if event is None:
                continue

            newest_ts_ms = max(newest_ts_ms, int(event.get("ts_ms", 0) or 0))
            self._remember_proxy_event(event)

        if newest_ts_ms > 0:
            self._proxy_log_since_s = max(
                self._proxy_log_since_s,
                int(newest_ts_ms / 1000),
            )
        self._proxy_log_since_s = max(self._proxy_log_since_s, int(time.time()) - 1)

    def _proxy_log_lines(self, cid: str, since_s: int) -> list[str]:
        """Read proxy stderr lines since a unix timestamp (seconds)."""
        try:
            container = self._docker.containers.get(cid)
            blob = container.logs(
                stdout=False,
                stderr=True,
                since=since_s,
                tail="all",
            )
        except docker.errors.NotFound:
            return []
        except Exception as exc:
            log.debug("Could not read proxy logs from %s: %s", cid[:12], exc)
            return []

        if isinstance(blob, (bytes, bytearray)):
            text = bytes(blob).decode("utf-8", errors="replace")
        else:
            text = str(blob or "")
        return text.splitlines()

    def _normalise_proxy_event(self, payload: dict[str, Any]) -> Optional[dict[str, Any]]:
        if payload.get("kind") != "proxy_event":
            return None
        if payload.get("event_type") != "api_call":
            return None

        event_id = str(payload.get("event_id") or "").strip()
        ts_ms = _as_int(payload.get("ts_ms"), default=int(time.time() * 1000))
        host = str(payload.get("host") or "").strip()
        source_ip = str(payload.get("source_ip") or "").strip()
        method = str(payload.get("method") or "").upper().strip()
        port = _as_int(payload.get("port"), default=0)
        request_bytes = max(0, _as_int(payload.get("request_bytes"), default=0))
        response_bytes = max(0, _as_int(payload.get("response_bytes"), default=0))
        duration_ms = max(0, _as_int(payload.get("duration_ms"), default=0))

        status_code_raw = payload.get("status_code")
        status_code = _as_int(status_code_raw, default=0)
        if status_code <= 0:
            status_code = None

        if not event_id:
            event_id = (
                f"{ts_ms}:{source_ip}:{host}:{port}:{method}:"
                f"{request_bytes}:{response_bytes}:{status_code}"
            )

        event: dict[str, Any] = {
            "event_id": event_id,
            "ts_ms": ts_ms,
            "source_ip": source_ip,
            "host": host,
            "port": port,
            "method": method,
            "request_bytes": request_bytes,
            "response_bytes": response_bytes,
            "status_code": status_code,
            "success": _as_bool(payload.get("success")),
            "duration_ms": duration_ms,
        }

        path = payload.get("path")
        if path is not None:
            event["path"] = str(path)

        error = payload.get("error")
        if error is not None:
            event["error"] = str(error)

        return event

    def _remember_proxy_event(self, event: dict[str, Any]) -> None:
        event_id = str(event.get("event_id") or "").strip()
        if not event_id:
            return
        if event_id in self._proxy_seen_lookup:
            return

        self._proxy_events.append(event)
        self._proxy_seen_ids.append(event_id)
        self._proxy_seen_lookup.add(event_id)

        while len(self._proxy_seen_ids) > _MAX_PROXY_SEEN_IDS:
            evicted = self._proxy_seen_ids.popleft()
            self._proxy_seen_lookup.discard(evicted)

    # ── Private: query helpers ─────────────────────────────────────────────────

    async def _image_exists(self, tag: str) -> bool:
        try:
            await asyncio.get_event_loop().run_in_executor(
                None, lambda: self._docker.images.get(tag)
            )
            return True
        except docker.errors.ImageNotFound:
            return False

    async def _container_running(self, cid: str) -> bool:
        try:
            c = await asyncio.get_event_loop().run_in_executor(
                None, lambda: self._docker.containers.get(cid)
            )
            return c.status == "running"
        except docker.errors.NotFound:
            return False

    async def _container_ip(
        self,
        cid:          str,
        network_name: Optional[str] = None,
    ) -> str:
        """
        Return the container's IP address.

        When network_name is given, return the IP on THAT network.  This is
        required when the proxy is connected to multiple networks (its original
        default bridge plus each sandbox network): iterating NetworkSettings
        without a target name is non-deterministic and typically returns the
        default-bridge IP, which is unreachable from sandbox containers that are
        on an isolated user-defined bridge.

        Falls back to any available IP when network_name is not given or when the
        container hasn't yet received an address on the requested network.
        """
        loop = asyncio.get_event_loop()
        c = await loop.run_in_executor(
            None, lambda: self._docker.containers.get(cid)
        )
        c.reload()
        nets = c.attrs.get("NetworkSettings", {}).get("Networks", {})

        # Prefer the IP on the explicitly requested network
        if network_name and network_name in nets:
            ip = nets[network_name].get("IPAddress", "")
            if ip:
                return ip
            log.warning(
                f"Proxy {cid[:12]} has no IP on network '{network_name}' yet — "
                "falling back to first available IP"
            )

        # Fallback: any IP (bare-host usage or race condition)
        for net_info in nets.values():
            ip = net_info.get("IPAddress", "")
            if ip:
                return ip

        return "127.0.0.1"


def _as_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    return str(value or "").strip().lower() in {"1", "true", "yes", "y"}
