"""
ConversationSummarizer
======================
Segments a conversation into episodes using the is_continuation flag
produced by MessageEnhancer, summarizes each episode via LLM, and
stores the summaries in EpisodicMemory.

Trigger logic
-------------
Call `maybe_summarize()` after every message store. It fires-and-forgets
a background task when the number of unsummarized messages crosses the
configured threshold. Non-blocking.

Episode segmentation
--------------------
Walk unsummarized messages in chronological order.
A new episode starts when:
  - is_continuation=False on the current message, OR
  - the current episode has reached max_episode_size (hard cap).

Overlap
-------
The last `overlap` messages of episode N are re-included as the first
messages of episode N+1 for smooth LLM context at boundaries.
These overlap messages are NOT re-tagged — they already have their
episode_id from episode N. Only the new (non-overlap) messages in
episode N+1 get tagged and stored.
"""

import asyncio
import json
import logging
import re
import statistics
from dataclasses import dataclass, field

from jazzmine.core.llm import BaseLLM, MessagePart
from jazzmine.core.message_store import MessageStore
from jazzmine.core.message_store.models import Message

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# LLM prompt
# ---------------------------------------------------------------------------

SUMMARIZER_SYSTEM_PROMPT = """You are a conversation episode summarizer for an AI agent memory system.

Given a sequence of conversation turns belonging to a single episode, produce a JSON object with:

- short_summary : 1-2 sentences only. A compact title-like description of what this episode was about. Used for fast semantic search.
- long_summary  : 3-5 sentences only. A thorough summary covering the main topic, key facts established, decisions made, questions asked, and how the episode concluded.

Respond with ONLY a raw JSON object. No markdown, no explanation."""

_SENTENCE_RE = re.compile(r"[^.!?]+(?:[.!?]+|$)", re.DOTALL)
_JSON_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL | re.IGNORECASE)


def _normalize_whitespace(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def _extract_balanced_json_object(text: str) -> str:
    start = text.find("{")
    if start < 0:
        return text.strip()

    in_string = False
    escaped = False
    depth = 0

    for idx in range(start, len(text)):
        ch = text[idx]
        if in_string:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            continue

        if ch == '"':
            in_string = True
            continue
        if ch == "{":
            depth += 1
            continue
        if ch == "}":
            depth -= 1
            if depth == 0:
                return text[start:idx + 1].strip()

    # If braces are unbalanced, return from the first object opener onward.
    return text[start:].strip()


def _escape_control_chars_in_strings(text: str) -> str:
    out: list[str] = []
    in_string = False
    escaped = False

    for ch in text:
        if in_string:
            if escaped:
                out.append(ch)
                escaped = False
                continue

            if ch == "\\":
                out.append(ch)
                escaped = True
                continue

            if ch == '"':
                out.append(ch)
                in_string = False
                continue

            code = ord(ch)
            if code < 0x20:
                if ch == "\n":
                    out.append("\\n")
                elif ch == "\r":
                    out.append("\\r")
                elif ch == "\t":
                    out.append("\\t")
                elif ch == "\b":
                    out.append("\\b")
                elif ch == "\f":
                    out.append("\\f")
                else:
                    out.append(f"\\u{code:04x}")
                continue

            out.append(ch)
            continue

        out.append(ch)
        if ch == '"':
            in_string = True

    return "".join(out)


def _strip_trailing_commas(text: str) -> str:
    out: list[str] = []
    in_string = False
    escaped = False
    idx = 0

    while idx < len(text):
        ch = text[idx]

        if in_string:
            out.append(ch)
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            idx += 1
            continue

        if ch == '"':
            in_string = True
            out.append(ch)
            idx += 1
            continue

        if ch == ",":
            lookahead = idx + 1
            while lookahead < len(text) and text[lookahead].isspace():
                lookahead += 1
            if lookahead < len(text) and text[lookahead] in "]}":
                idx += 1
                continue

        out.append(ch)
        idx += 1

    return "".join(out)


def _clean_llm_json_payload(text: str) -> str:
    cleaned = (text or "").replace("\ufeff", "").strip()

    fence_match = _JSON_FENCE_RE.search(cleaned)
    if fence_match:
        cleaned = fence_match.group(1).strip()

    cleaned = re.sub(r"^\s*json\s*(?=\n|\{)", "", cleaned, flags=re.IGNORECASE).strip()
    cleaned = _extract_balanced_json_object(cleaned)
    cleaned = _escape_control_chars_in_strings(cleaned)
    cleaned = _strip_trailing_commas(cleaned)
    return cleaned.strip()


def _split_sentences(text: str) -> list[str]:
    cleaned = _normalize_whitespace(text)
    if not cleaned:
        return []

    parts = [segment.strip() for segment in _SENTENCE_RE.findall(cleaned) if segment.strip()]
    if not parts:
        return [cleaned]
    return parts


def _ensure_terminal_punctuation(sentence: str) -> str:
    sentence = sentence.strip()
    if not sentence:
        return sentence
    if sentence.endswith((".", "!", "?")):
        return sentence
    return sentence + "."


def _fit_sentence_window(text: str, min_sentences: int, max_sentences: int, pad_sentence: str) -> str:
    sentences = _split_sentences(text)

    # If punctuation is sparse, split long chunks by clause delimiters first.
    if len(sentences) < min_sentences:
        expanded: list[str] = []
        for sentence in sentences:
            chunks = [chunk.strip() for chunk in re.split(r"[;:]", sentence) if chunk.strip()]
            expanded.extend(chunks if len(chunks) > 1 else [sentence])
        sentences = expanded or sentences

    if len(sentences) < min_sentences:
        expanded = []
        for sentence in sentences:
            chunks = [chunk.strip() for chunk in re.split(r",", sentence) if chunk.strip()]
            expanded.extend(chunks if len(chunks) > 1 else [sentence])
        sentences = expanded or sentences

    if not sentences:
        sentences = [pad_sentence]

    while len(sentences) < min_sentences:
        sentences.append(pad_sentence)

    clipped = sentences[:max_sentences]
    return " ".join(_ensure_terminal_punctuation(s) for s in clipped if s.strip())


# ---------------------------------------------------------------------------
# Episode dataclass
# ---------------------------------------------------------------------------

@dataclass
class Episode:
    messages: list[Message] = field(default_factory=list)
    # How many leading messages are overlap from the previous episode
    overlap_count: int = 0

    @property
    def core_messages(self) -> list[Message]:
        """Messages that belong exclusively to this episode (no overlap)."""
        return self.messages[self.overlap_count:]

    @property
    def timestamp_begin(self) -> int:
        return self.core_messages[0].timestamp if self.core_messages else self.messages[0].timestamp

    @property
    def timestamp_end(self) -> int:
        return self.core_messages[-1].timestamp if self.core_messages else self.messages[-1].timestamp

    @property
    def flows_activated(self) -> list[str]:
        seen, result = set(), []
        for m in self.core_messages:
            for f in (m.invoked_flows or []):
                if f not in seen:
                    seen.add(f)
                    result.append(f)
        return result

    @property
    def tools_invoked(self) -> list[str]:
        seen, result = set(), []
        for m in self.core_messages:
            for t in (m.invoked_tools or []):
                if t not in seen:
                    seen.add(t)
                    result.append(t)
        return result

    @property
    def average_sentiment(self) -> float:
        scores = [m.sentiment_score for m in self.core_messages]
        return sum(scores) / len(scores) if scores else 0.0

    @property
    def sentiment_variance(self) -> float:
        scores = [m.sentiment_score for m in self.core_messages]
        return statistics.variance(scores) if len(scores) >= 2 else 0.0


# ---------------------------------------------------------------------------
# Summarizer
# ---------------------------------------------------------------------------

class ConversationSummarizer:

    def __init__(
        self,
        llm: BaseLLM,
        episodic_memory,
        message_store: MessageStore,
        trigger: int = 10,
        max_episode_size: int = 20,
        min_episode_size: int = 3,
        overlap: int = 2,
    ):
        if max_episode_size < 3:
            raise ValueError("max_episode_size must be at least 3")
        if overlap >= max_episode_size:
            raise ValueError("overlap must be less than max_episode_size")

        self.llm              = llm
        self.episodic_memory  = episodic_memory
        self.message_store    = message_store
        self.trigger          = trigger
        self.max_episode_size = max_episode_size
        self.min_episode_size = min_episode_size
        self.overlap          = overlap

        self._locks: dict[str, asyncio.Lock] = {}

    # ------------------------------------------------------------------ public

    async def maybe_summarize(
        self, conversation_id: str, user_id: str, agent_id: str
    ) -> None:
        """
        Summarise the conversation if the unsummarized message count meets the
        trigger threshold.

        This method is intentionally non-recursive: it runs `_safe_run` directly
        rather than wrapping it in another `asyncio.create_task`.  The caller
        (Agent._safe_summarize) is already a background task, so adding a second
        layer of create_task would break Agent.drain() — drain() tracks the outer
        task (A), which would return immediately after spawning the inner task (B),
        so drain() would finish before the actual LLM summarisation work in task B
        completes, causing ReadError when the LLM client is subsequently closed.

        Running _safe_run directly means:
          • Task A does the real work.
          • drain() correctly waits for A to finish before the LLM is closed.
          • The lock still prevents concurrent runs for the same conversation.
        """
        # Single fetch — reused both for the trigger check and the run itself,
        # eliminating the redundant second fetch that run() would otherwise make.
        messages = await self._get_unsummarized(conversation_id)
        if len(messages) < self.trigger:
            return

        lock = self._locks.setdefault(conversation_id, asyncio.Lock())
        if lock.locked():
            return

        await self._safe_run(conversation_id, user_id, agent_id, lock,
                             _prefetched=messages)

    async def run(
        self, conversation_id: str, user_id: str, agent_id: str,
        _prefetched: "list[Message] | None" = None,
    ) -> int:
        """Force a summarization run. Returns number of episodes created."""
        messages = _prefetched if _prefetched is not None \
            else await self._get_unsummarized(conversation_id)
        if not messages:
            return 0

        episodes = self._segment(messages)
        episode_counter = await self._current_episode_count(conversation_id)

        all_messages = await self.message_store.get_messages_by_conversation_id(conversation_id)
        id_to_index  = {m.id: i for i, m in enumerate(all_messages)}

        for episode in episodes:
            episode_counter += 1
            await self._process_episode(
                episode, episode_counter, user_id, agent_id, conversation_id, id_to_index
            )

        return len(episodes)

    # ------------------------------------------------------------------ private

    async def _safe_run(
        self,
        conversation_id: str,
        user_id: str,
        agent_id: str,
        lock: asyncio.Lock,
        _prefetched: list | None = None,
    ) -> None:
        async with lock:
            try:
                count = await self.run(conversation_id, user_id, agent_id,
                                       _prefetched=_prefetched)
                logger.info(
                    "Summarized conversation %s → %d new episode(s).",
                    conversation_id, count,
                )
            except Exception:
                logger.exception(
                    "Summarizer failed for conversation %s.", conversation_id
                )

    def _segment(self, messages: list[Message]) -> list[Episode]:
        """
        Split messages into episodes.

        For each message:
        - If current episode hits max_episode_size → close and start new one.
        - If is_continuation=False and episode is non-empty → close and start new one.
        - Otherwise → append to current episode.

        The first episode gets overlap_count=0 (no prior episode to overlap from).
        Subsequent episodes get the last `overlap` messages of the previous episode
        prepended, with overlap_count set accordingly.
        """
        episodes: list[Episode] = []
        current = Episode(overlap_count=0)

        for msg in messages:
            hard_cap   = len(current.messages) >= self.max_episode_size
            topic_shift = (
                    not msg.is_continuation
                    and len(current.core_messages) >= self.min_episode_size
            )

            if hard_cap or topic_shift:
                if current.messages:
                    episodes.append(current)
                    # Carry over tail of previous episode as overlap for next
                    overlap_msgs = current.core_messages[-self.overlap:] if self.overlap > 0 else []
                    current = Episode(
                        messages=list(overlap_msgs),
                        overlap_count=len(overlap_msgs),
                    )

            current.messages.append(msg)

        if current.messages:
            episodes.append(current)

        return episodes

    async def _process_episode(
        self,
        episode: Episode,
        episode_number: int,
        user_id: str,
        agent_id: str,
        conversation_id: str,
        id_to_index: dict[str, int],
    ) -> None:
        core = episode.core_messages
        if not core:
            logger.warning("Episode %d has no core messages — skipping.", episode_number)
            return

        short_summary, long_summary = await self._summarize(episode)

        start_index = id_to_index.get(core[0].id, 0)
        end_index   = id_to_index.get(core[-1].id, start_index)

        await self.episodic_memory.memorize(
            short_summary           = short_summary,
            long_summary            = long_summary,
            start_index             = start_index,
            end_index               = end_index,
            user_id                 = user_id,
            agent_id                = agent_id,
            conversation_id         = conversation_id,
            overlap                 = self.overlap,
            flows_activated         = episode.flows_activated,
            tools_invoked           = episode.tools_invoked,
            timestamp_begin         = episode.timestamp_begin,
            timestamp_end           = episode.timestamp_end,
            average_user_sentiment  = episode.average_sentiment,
            user_sentiment_variance = episode.sentiment_variance,
        )

        # Tag only core messages — overlap messages already have their episode_id
        for msg in core:
            msg.episode_id = episode_number
            await self.message_store.update_message(msg)

        logger.debug(
            "Episode %d: %d core messages, indices %d→%d, sentiment=%.2f",
            episode_number, len(core), start_index, end_index, episode.average_sentiment,
        )

    async def _summarize(self, episode: Episode) -> tuple[str, str]:
        turns = "\n".join(
            f"{m.role.value.upper()}: {m.enhanced_message or m.original_content}"
            for m in episode.messages   # include overlap for better LLM context
        )
        response = await self.llm.agenerate([
            MessagePart(role="system", content=SUMMARIZER_SYSTEM_PROMPT),
            MessagePart(role="user",   content=f"<episode>\n{turns}\n</episode>"),
        ])

        raw_text = response.text.strip()
        cleaned_text = _clean_llm_json_payload(raw_text)

        try:
            data = json.loads(cleaned_text)
            if not isinstance(data, dict):
                raise ValueError("Summarizer JSON must be an object.")
            short = str(data.get("short_summary", "")).strip()
            long  = str(data.get("long_summary",  "")).strip()
        except (json.JSONDecodeError, KeyError, ValueError) as exc:
            logger.warning(
                "Summarizer LLM returned bad JSON after cleaning (%s) — using fallback. "
                "Raw: %r | Cleaned: %r",
                exc,
                raw_text[:1200],
                cleaned_text[:1200],
            )
            short = f"Episode with {len(episode.core_messages)} messages."
            long  = turns[:1000]

        short = _fit_sentence_window(
            short,
            min_sentences=1,
            max_sentences=2,
            pad_sentence="Untitled episode",
        )
        long = _fit_sentence_window(
            long or short,
            min_sentences=3,
            max_sentences=5,
            pad_sentence="No further details were provided in this episode",
        )

        return short, long

    async def _get_unsummarized(self, conversation_id: str) -> list[Message]:
        all_messages = await self.message_store.get_messages_by_conversation_id(conversation_id)
        return [m for m in all_messages if m.episode_id == 0]

    async def _count_unsummarized(self, conversation_id: str) -> int:
        return len(await self._get_unsummarized(conversation_id))

    async def _current_episode_count(self, conversation_id: str) -> int:
        all_messages = await self.message_store.get_messages_by_conversation_id(conversation_id)
        ids = {m.episode_id for m in all_messages if m.episode_id > 0}
        return max(ids, default=0)