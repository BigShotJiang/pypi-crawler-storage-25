import bisect
import re
import os
from typing import List, Tuple, Dict, Optional
import logging

try:
    import boto3
except ImportError:  # pragma: no cover - optional cloud dependency
    boto3 = None

import chromadb
from chromadb.api.types import Documents, EmbeddingFunction
from sentence_transformers import SentenceTransformer


class CustomEmbeddingFunction(EmbeddingFunction):
    def __init__(self, model_path: str):
        self.model = SentenceTransformer(model_path)

    def __call__(self, input: Documents) -> List[List[float]]:
        """Generate embeddings for input texts using the local model."""
        return [self.model.encode(text, convert_to_numpy=True).tolist() for text in input]


class ChromaDatabaseManager:
    def __init__(self, chunk_size: int = 1000, chunk_overlap: int = 200, embedding_function_path: Optional[str] = None, persist_path="ChromaDatabase"):
        """Initialize the semantic search engine with customizable chunk parameters."""
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.logger = logging.getLogger(__name__)
        self.embedding_function_path = embedding_function_path or os.environ.get(
            "RMS_EMBEDDING_MODEL",
            "BAAI/bge-base-en-v1.5",
        )
        
        # S3 configuration
        self.s3_bucket = "research-manager-system-data"
        self.s3_client = boto3.client('s3') if boto3 is not None else None
        self.s3_persist_path = persist_path
        
        # Local temp directory for ChromaDB
        self.local_persist_path = os.path.join('/tmp', os.path.basename(persist_path))
        
        # Make local directory if it doesn't exist
        os.makedirs(self.local_persist_path, exist_ok=True)
        
        # Sync ChromaDB files from S3 if they exist
        if self.s3_client is not None:
            self._sync_chromadb_from_s3()
        
        # Initialize ChromaDB client with local path
        embedding_function = CustomEmbeddingFunction(self.embedding_function_path)
        self.chroma_client = chromadb.PersistentClient(path=self.local_persist_path)

        self.collection_name = self._build_collection_name(self.embedding_function_path)
        self.collection = self.chroma_client.get_or_create_collection(
            name=self.collection_name,
            embedding_function=embedding_function
        )
        print(f"{self.collection.name} initialized at {self.local_persist_path} for {self.collection_name}")

    def _build_collection_name(self, embedding_model: str) -> str:
        """Use an embedding-specific collection to avoid dimension mismatches across model upgrades."""
        normalized = re.sub(r"[^a-zA-Z0-9]+", "_", embedding_model).strip("_").lower()
        shortened = normalized[:40] if normalized else "default"
        return f"research_papers__{shortened}"

    def _sync_chromadb_from_s3(self):
        """Download ChromaDB files from S3 if they exist"""
        if self.s3_client is None:
            self.logger.info("boto3 not installed; skipping ChromaDB S3 sync.")
            return
        try:
            # List all objects with the ChromaDB prefix
            response = self.s3_client.list_objects_v2(
                Bucket=self.s3_bucket,
                Prefix=f"{self.s3_persist_path}/"
            )
            
            if 'Contents' in response:
                # Download each file
                for obj in response['Contents']:
                    key = obj['Key']
                    local_file_path = os.path.join('/tmp', key)
                    
                    # Create directories if they don't exist
                    os.makedirs(os.path.dirname(local_file_path), exist_ok=True)
                    
                    # Download the file
                    self.s3_client.download_file(
                        Bucket=self.s3_bucket,
                        Key=key,
                        Filename=local_file_path
                    )
                self.logger.info(f"Downloaded ChromaDB files from S3")
            else:
                self.logger.info("No existing ChromaDB files found in S3")
                
        except Exception as e:
            self.logger.error(f"Error syncing ChromaDB from S3: {str(e)}")

    def _sync_chromadb_to_s3(self):
        """Upload ChromaDB files to S3 after modifications"""
        if self.s3_client is None:
            self.logger.info("boto3 not installed; skipping ChromaDB S3 upload.")
            return
        try:
            # Walk through the local directory
            for root, dirs, files in os.walk(self.local_persist_path):
                for file in files:
                    local_path = os.path.join(root, file)
                    
                    # Calculate relative path
                    rel_path = os.path.relpath(local_path, '/tmp')
                    s3_key = rel_path
                    
                    # Upload file to S3
                    self.s3_client.upload_file(
                        Filename=local_path,
                        Bucket=self.s3_bucket,
                        Key=s3_key
                    )
            
            self.logger.info(f"Uploaded ChromaDB files to S3")
        except Exception as e:
            self.logger.error(f"Error uploading ChromaDB to S3: {str(e)}")

    def create_chunks(self, text: str, meta_data: Dict) -> Tuple[List[Dict], List[Dict]]:
        """
        Create overlapping chunks with accurate page assignments.
        """
        # Preprocess text to handle hyphens
        text = self._normalize_hyphens(text)
        # Extract page boundaries from metadata
        page_boundaries = sorted(
            [
                {
                    "start": page["char_start"],
                    "end": page["char_end"],
                    "page_num": page["page_number"]
                }
                for page in meta_data.get("page_data", [])
            ],
            key=lambda x: x["start"]
        )
        page_starts = [p["start"] for p in page_boundaries]
        page_ends = [p["end"] for p in page_boundaries]

        chunks = []
        metadata = []
        text_length = len(text)

        for i in range(0, len(text), self.chunk_size - self.chunk_overlap):
            start = i
            end = min(i + self.chunk_size, len(text))

            # Enhanced boundary detection with fallbacks
            if end < len(text):
                # Prioritize paragraph breaks
                para_break = text.rfind('\n\n', start, end)
                if para_break != -1:
                    end = para_break + 2
                else:
                    # Then sentence boundaries
                    sentence_break = max(
                        text.rfind('. ', start, end),
                        text.rfind('? ', start, end),
                        text.rfind('! ', start, end)
                    )
                    if sentence_break > start + 30:  # More flexible minimum
                        end = sentence_break + 2
                    else:
                        # Final fallback to word boundaries
                        last_space = text.rfind(' ', start, end)
                        if last_space > start + int(self.chunk_size * 0.75):
                            end = last_space

            chunk_text = text[start:end].strip()
            if not chunk_text:
                continue

            # Find overlapping pages using binary search
            chunk_pages = set()
            if page_boundaries:
                # Find leftmost page where page_end >= chunk_start
                left = bisect.bisect_left(page_ends, start)
                # Find rightmost page where page_start <= chunk_end
                right = bisect.bisect_right(page_starts, end)

                # Check overlap in narrowed range
                for idx in range(left, right):
                    page = page_boundaries[idx]
                    if (page["start"] <= end) and (page["end"] >= start):
                        chunk_pages.add(page["page_num"])

            # Store chunk and metadata
            chunks.append({
                "text": chunk_text,
                "char_start": start,
                "char_end": end
            })

            metadata.append({
                "source": meta_data.get("source"),
                "chunk_index": len(chunks) - 1,
                "page_numbers": sorted(chunk_pages),
                "start_char": start,
                "end_char": end,
                "total_pages": meta_data.get("total_pages"),
                "total_length": text_length
            })

        return chunks, metadata

    def _normalize_hyphens(self, text: str) -> str:
        """Handle various hyphenation cases"""
        # Merge hyphenated words across lines
        text = re.sub(r'(\w)-\s+(\w)', r'\1\2', text)  # Single-character hyphens
        text = re.sub(r'(\w+)-\s+(\w+)', r'\1\2', text)  # Multi-character hyphens

        # Remove soft hyphens (Unicode \xad)
        text = text.replace('\xad', '')

        # Normalize all whitespace
        return ' '.join(text.split())

    def _verify_text_alignment(self, doc_path: str, meta_data: Dict):
        """Debug tool to validate text extraction - modified for S3"""
        try:
            # Download file from S3
            response = self.s3_client.get_object(Bucket=self.s3_bucket, Key=doc_path)
            original_text = response['Body'].read().decode('utf-8', errors='replace')

            reconstructed = "".join(p["text"] for p in sorted(meta_data["page_data"], key=lambda x: x["page_number"]))

            assert len(original_text) == len(reconstructed), "Text length mismatch"
            assert original_text == reconstructed, "Text content mismatch"
            
        except self.s3_client.exceptions.ClientError as e:
            self.logger.error(f"Error accessing file in S3: {str(e)}")
            raise

    def _validate_chunks(self, chunks: List[Dict], meta_data: Dict):
        """Ensure chunk boundaries match page data"""
        # Create page boundary map using CORRECT keys from read()
        page_map = {
            p["page_number"]: (p["char_start"], p["char_end"])
            for p in meta_data["page_data"]
        }

        for chunk in chunks:
            # Handle both list and string formats for page numbers
            page_numbers = chunk.get("page_numbers", [])
            if isinstance(page_numbers, str):
                page_numbers = [int(p) for p in page_numbers.split(",") if p]

            if not page_numbers:
                continue

            # Validate against first and last page in chunk's page range
            first_page = page_numbers[0]
            last_page = page_numbers[-1]

            # Get page boundaries
            first_start, first_end = page_map[first_page]
            last_start, last_end = page_map[last_page]

            # Validate chunk start
            if chunk["start_char"] < first_start:
                raise ValueError(
                    f"Chunk starts before page {first_page}: "
                    f"{chunk['start_char']} < {first_start}"
                )

            # Validate chunk end
            if chunk["end_char"] > last_end:
                raise ValueError(
                    f"Chunk ends after page {last_page}: "
                    f"{chunk['end_char']} > {last_end}"
                )

    def save(self, text: str, meta_data: Dict) -> Dict[str, object]:
        """
        Process and save a PDF document's text into a ChromaDB collection.
        """
        try:
            if not text or not meta_data:
                self.logger.error("Failed to extract text from PDF")
                return {
                    "status": "failed",
                    "source": meta_data.get("source") if meta_data else None,
                    "total_chunks": 0,
                    "indexed_chunks": 0,
                    "duplicate_chunks": 0,
                }

            # Create chunks first
            chunks, metadata = self.create_chunks(text, meta_data)

            # Validate chunk-page alignment
            self._validate_chunks(chunks, meta_data)

            # Existing duplicate checking and saving logic
            existing_chunks = self.collection.get()
            existing_ids = set(existing_chunks["ids"]) if existing_chunks.get("ids") else set()

            new_chunks = []
            new_metadata = []
            new_ids = []
            duplicate_chunks = 0

            for i, (chunk, meta) in enumerate(zip(chunks, metadata)):
                first_page = meta["page_numbers"][0] if meta["page_numbers"] else 1
                chunk_id = f"{meta['source']}_page{first_page}_chunk_{i}"
                if chunk_id in existing_ids:
                    print(f"Skipping existing chunk: {chunk_id}")
                    duplicate_chunks += 1
                    continue

                chroma_metadata = {
                    "source": meta["source"],
                    "chunk_index": meta["chunk_index"],
                    "start_char": meta["start_char"],
                    "end_char": meta["end_char"],
                    "page_numbers": ",".join(map(str, meta["page_numbers"])),
                    "total_pages": meta["total_pages"],
                    "total_length": meta["total_length"]
                }
                new_chunks.append(chunk["text"])
                new_metadata.append(chroma_metadata)
                new_ids.append(chunk_id)

            if new_chunks:
                self.collection.add(
                    documents=new_chunks,
                    metadatas=new_metadata,
                    ids=new_ids
                )
                print(f"Added {len(new_chunks)} new chunks to collection")
                status = "indexed"
            else:
                print("No new chunks to add to collection")
                status = "already_indexed"
                
            # Sync database changes back to S3
            self._sync_chromadb_to_s3()

            return {
                "status": status,
                "source": meta_data.get("source"),
                "total_chunks": len(chunks),
                "indexed_chunks": len(new_chunks),
                "duplicate_chunks": duplicate_chunks,
            }

        except Exception as e:
            self.logger.error(f"Error processing PDF: {str(e)}")
            raise

    def search(self, query: str, pdf_name_list=None, top_k: int = 5) -> List[Dict]:
        """Perform semantic search and return relevant chunks with metadata."""
        # Fix 1: Use correct metadata field name ('source' instead of 'pdf_filename')
        filter_dict = {"source": {"$in": pdf_name_list}} if pdf_name_list else None

        results = self.collection.query(
            query_texts=[query],
            n_results=top_k,
            include=["documents", "metadatas", "distances"],
            where=filter_dict  # Fix 2: Use proper filtering syntax
        )

        formatted_results = []
        for doc, metadata, distance in zip(
                results['documents'][0],
                results['metadatas'][0],
                results['distances'][0]
        ):
            # Fix 3: Handle different page_number storage formats
            page_numbers = metadata.get('page_numbers', [])
            if isinstance(page_numbers, str):
                # Convert from "1,2,3" string format
                page_numbers = [int(p) for p in page_numbers.split(',') if p.strip()]
            elif isinstance(page_numbers, list):
                # Already in list format
                page_numbers = [int(p) for p in page_numbers]

            # Fix 4: Safely get metadata fields with defaults
            formatted_results.append({
                'chunk_text': doc,
                'source': metadata.get('source', 'unknown'),
                'relevance_score': 1 - distance,
                'chunk_index': metadata.get('chunk_index', -1),
                'page_numbers': page_numbers,
                'total_pages': metadata.get('total_pages', 0),
                'char_range': (
                    metadata.get('start_char', 0),
                    metadata.get('end_char', 0)
                )
            })

        return formatted_results

    def get_document_list(self):
        """
        Connect to ChromaDB, retrieve all document metadata, and return a list of unique PDF filenames.
        """
        # Retrieve all documents and include metadata.
        meta_information = self.collection.get(include=["metadatas"])

        # Use a set to collect unique PDF filenames.
        filenames = set()

        # The metadata is expected to be a list of dictionaries.
        for info in meta_information["metadatas"]:
            if 'source' in info:
                filenames.add(info["source"])

        return list(filenames)
