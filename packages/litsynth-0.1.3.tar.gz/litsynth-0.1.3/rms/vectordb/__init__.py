from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple
import numpy as np


@dataclass
class SearchResult:
    """Result from vector search."""
    document_id: str
    chunk_id: str
    text: str
    score: float
    metadata: Dict[str, Any]


class VectorDBBase(ABC):
    """Base class for vector database implementations."""

    @abstractmethod
    def upsert(
        self,
        vectors: np.ndarray,
        ids: List[str],
        metadata: List[Dict[str, Any]],
        collection_name: str = "default",
    ) -> None:
        """
        Add or update vectors.
        
        Args:
            vectors: np.ndarray of shape (N, embedding_dim)
            ids: List of N unique IDs
            metadata: List of N metadata dicts
            collection_name: Collection to upsert to
        """
        pass

    @abstractmethod
    def search(
        self,
        query_vector: np.ndarray,
        top_k: int = 5,
        collection_name: str = "default",
        filters: Dict[str, Any] = None,
    ) -> List[SearchResult]:
        """
        Search for similar vectors.
        
        Args:
            query_vector: Query embedding (1D array)
            top_k: Number of results
            collection_name: Collection to search
            filters: Optional metadata filters
            
        Returns:
            List of SearchResult objects
        """
        pass

    @abstractmethod
    def list_collections(self) -> List[str]:
        """List all collections."""
        pass

    @abstractmethod
    def delete_collection(self, collection_name: str) -> None:
        """Delete a collection."""
        pass

    @abstractmethod
    def collection_info(self, collection_name: str) -> Dict[str, Any]:
        """Get collection statistics."""
        pass
