"""Local Qdrant vector database for development and offline use."""

from typing import List, Dict, Any
import numpy as np
import os
from rms.vectordb import VectorDBBase, SearchResult


class QdrantLocalDB(VectorDBBase):
    """
    Qdrant vector database running locally.
    
    Perfect for:
    - Development and prototyping
    - Offline operation (no network required)
    - Single-machine deployments
    - Local backup of production data
    """

    def __init__(self, storage_path: str = "./data/qdrant"):
        """
        Initialize local Qdrant instance.
        
        Args:
            storage_path: Directory for Qdrant storage
        """
        try:
            from qdrant_client import QdrantClient
            from qdrant_client.models import Distance, VectorParams
        except ImportError:
            raise ImportError(
                "qdrant-client not installed. "
                "Install with: pip install qdrant-client"
            )

        self.QdrantClient = QdrantClient
        self.Distance = Distance
        self.VectorParams = VectorParams

        # Ensure storage path exists
        os.makedirs(storage_path, exist_ok=True)

        print(f"Initializing Qdrant local instance at {storage_path}...")
        self.client = QdrantClient(path=storage_path)
        print("Qdrant instance ready.")

    def upsert(
        self,
        vectors: np.ndarray,
        ids: List[str],
        metadata: List[Dict[str, Any]],
        collection_name: str = "documents",
    ) -> None:
        """Add or update vectors."""
        if len(vectors) != len(ids) or len(vectors) != len(metadata):
            raise ValueError("Vectors, IDs, and metadata must have same length")

        if len(vectors) == 0:
            return

        embedding_dim = vectors.shape[1]

        # Create collection if doesn't exist
        try:
            self.client.recreate_collection(
                collection_name=collection_name,
                vectors_config=self.VectorParams(
                    size=embedding_dim,
                    distance=self.Distance.COSINE,
                ),
            )
        except:
            pass  # Collection might already exist

        # Prepare points for upsert
        from qdrant_client.models import PointStruct

        points = [
            PointStruct(
                id=i,
                vector=vectors[i].tolist(),
                payload={"doc_id": ids[i], **metadata[i]},
            )
            for i in range(len(ids))
        ]

        self.client.upsert(
            collection_name=collection_name,
            points=points,
        )

    def search(
        self,
        query_vector: np.ndarray,
        top_k: int = 5,
        collection_name: str = "documents",
        filters: Dict[str, Any] = None,
    ) -> List[SearchResult]:
        """Search for similar vectors."""
        query_vector_list = query_vector.tolist() if isinstance(query_vector, np.ndarray) else query_vector

        results = self.client.search(
            collection_name=collection_name,
            query_vector=query_vector_list,
            limit=top_k,
            query_filter=filters,
        )

        search_results = []
        for result in results:
            payload = result.payload
            search_results.append(
                SearchResult(
                    document_id=payload.get("doc_id", "unknown"),
                    chunk_id=payload.get("chunk_id", "unknown"),
                    text=payload.get("text", ""),
                    score=result.score,
                    metadata=payload,
                )
            )

        return search_results

    def list_collections(self) -> List[str]:
        """List all collections."""
        collections = self.client.get_collections()
        return [col.name for col in collections.collections]

    def delete_collection(self, collection_name: str) -> None:
        """Delete a collection."""
        self.client.delete_collection(collection_name)

    def collection_info(self, collection_name: str) -> Dict[str, Any]:
        """Get collection statistics."""
        info = self.client.get_collection(collection_name)
        return {
            "name": collection_name,
            "vectors_count": info.points_count,
            "vector_size": info.config.params.vectors.size,
            "distance_metric": str(info.config.params.vectors.distance),
        }
