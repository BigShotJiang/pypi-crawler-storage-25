import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.util import ngrams
from collections import Counter
import numpy as np
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.tag import pos_tag
from collections import Counter
import numpy as np
from typing import List, Tuple, Dict, Set

class Utils:
    def __init__(self):
        self.nlp_initialized = None

    def extract_important_words(self, text: str):
        """
        Extract important keywords from text based on POS tagging and frequency.

        Args:
            text (str): Input text to extract keywords from
            num_keywords (int): Number of keywords to extract

        Returns:
            List[str]: List of extracted keywords
        """
        # Tokenize and POS tag
        tokens = word_tokenize(text.lower())
        pos_tags = pos_tag(tokens)

        # Keep only nouns, verbs, and adjectives
        important_words = [
            word for word, tag in pos_tags
            if tag.startswith(('NN', 'VB', 'JJ'))
               and word.isalnum()
               and word not in self.stop_words
               and len(word) > 2
        ]

        return important_words

    def find_relevant_chunk(self, chunks_text_list, answer_text):
        """
        Find the most relevant text chunk that corresponds to the LLM-generated answer.

        Args:
            chunks_text_list (list): List of text chunks from the document
            answer_text (str): LLM-generated answer text

        Returns:
            tuple: (most_relevant_chunk, similarity_score)
        """
        # Initialize NLTK if not already done
        self.initialize_nltk()

        def preprocess_text(text):
            # Tokenize and convert to lowercase
            tokens = word_tokenize(text.lower())
            # Remove stopwords and punctuation
            tokens = [token for token in tokens if token.isalnum() and token not in self.stop_words]
            return tokens

        def get_ngrams(tokens, n=2):
            # Generate n-grams from tokens
            return list(ngrams(tokens, n))

        def calculate_similarity(chunk_text, ans_text):
            # Preprocess both texts
            chunk_tokens = preprocess_text(chunk_text)
            answer_tokens = preprocess_text(ans_text)

            # Generate both unigrams and bigrams
            chunk_unigrams = Counter(chunk_tokens)
            answer_unigrams = Counter(answer_tokens)

            chunk_bigrams = Counter(get_ngrams(chunk_tokens))
            answer_bigrams = Counter(get_ngrams(answer_tokens))

            # Calculate Jaccard similarity for unigrams and bigrams
            def jaccard_similarity(counter1, counter2):
                intersection = sum((counter1 & counter2).values())
                union = sum((counter1 | counter2).values())
                return intersection / union if union > 0 else 0

            # Calculate similarities
            unigram_similarity = jaccard_similarity(chunk_unigrams, answer_unigrams)
            bigram_similarity = jaccard_similarity(chunk_bigrams, answer_bigrams)

            # Combine similarities with weights
            combined_similarity = (0.4 * unigram_similarity) + (0.6 * bigram_similarity)

            return combined_similarity

        # Calculate similarity scores for all chunks
        similarity_scores = []

        for chunk in chunks_text_list:
            score = calculate_similarity(chunk, answer_text)
            similarity_scores.append(score)


        # Find the chunk with highest similarity
        max_similarity_idx = np.argmax(similarity_scores)
        most_relevant_chunk = chunks_text_list[max_similarity_idx]
        highest_similarity = similarity_scores[max_similarity_idx]

        return most_relevant_chunk, highest_similarity, max_similarity_idx

    def initialize_nltk(self):
        """Initialize NLTK only if not already initialized."""
        if not self.nlp_initialized:
            try:
                nltk.data.path.append("./nltk_data")  # Add custom NLTK data directory
                self.stop_words = set(stopwords.words('english'))  # Load stop words
                self.nlp_initialized = True
            except LookupError as e:
                print(f"NLTK resource missing: {e}. Downloading...")
                nltk.download('stopwords', download_dir="./nltk_data")
                nltk.download('punkt', download_dir="./nltk_data")
                nltk.download('averaged_perceptron_tagger_eng', download_dir="./nltk_data")
                nltk.data.path.append("./nltk_data")  # Ensure custom path is used
                self.stop_words = set(stopwords.words('english'))
                self.nlp_initialized = True
            except Exception as e:
                raise RuntimeError(f"Failed to initialize NLTK: {e}")


def testing_lambda(string):
    return f"yes your function does work and see {string}"
