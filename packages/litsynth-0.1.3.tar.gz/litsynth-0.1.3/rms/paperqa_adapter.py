"""Optional PaperQA backend for scientific-paper RAG."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class PaperQAResponse:
    answer: str
    formatted_answer: str
    context: str
    references: List[Dict[str, Any]]
    backend: str = "paperqa"


class PaperQAAdapter:
    """Thin adapter around PaperQA for the hosted web and API path.

    This is intentionally optional and should not be required for the ASReview
    extension path.
    """

    def __init__(
        self,
        paper_directory: str,
        llm: Optional[str] = None,
        summary_llm: Optional[str] = None,
        embedding: Optional[str] = None,
    ) -> None:
        self.paper_directory = Path(paper_directory)
        if not self.paper_directory.exists():
            raise ValueError(f"Paper directory does not exist: {self.paper_directory}")

        self.llm = llm or os.environ.get("RMS_PAPERQA_LLM", "gemini/gemini-2.0-flash")
        self.summary_llm = summary_llm or os.environ.get(
            "RMS_PAPERQA_SUMMARY_LLM",
            self.llm,
        )
        self.embedding = embedding or os.environ.get("RMS_PAPERQA_EMBEDDING") or self._default_embedding_for_llm(self.llm)
        self.timeout_seconds = float(os.environ.get("RMS_PAPERQA_TIMEOUT_SECONDS", "600"))

    @staticmethod
    def _default_embedding_for_llm(llm: str) -> str:
        if llm.startswith("ollama/"):
            return "ollama/nomic-embed-text"
        if llm.startswith("openai/"):
            return "openai/text-embedding-3-small"
        return "gemini/text-embedding-004"

    def _litellm_config(self, model_name: str) -> Dict[str, Any]:
        return {
            "model_list": [
                {
                    "model_name": model_name,
                    "litellm_params": {
                        "model": model_name,
                    },
                }
            ],
            "router_kwargs": {
                "timeout": self.timeout_seconds,
                "num_retries": 1,
            },
        }

    def ask(self, query: str, evidence_k: int = 8, max_sources: int = 5) -> PaperQAResponse:
        try:
            from paperqa import Settings, ask
            from paperqa.settings import AgentSettings, AnswerSettings, IndexSettings, ParsingSettings
        except ImportError as exc:  # pragma: no cover - runtime dependency
            raise ImportError(
                "paper-qa is not installed. Install it with: pip install 'paper-qa>=5'"
            ) from exc

        if self.llm.startswith("gemini/") and not (
            os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
        ):
            raise ValueError(
                "Missing Gemini API key. Set GEMINI_API_KEY or GOOGLE_API_KEY for the PaperQA backend."
            )

        llm_config = self._litellm_config(self.llm)
        summary_llm_config = self._litellm_config(self.summary_llm)
        local_ollama_mode = self.llm.startswith("ollama/")

        settings = Settings(
            llm=self.llm,
            llm_config=llm_config,
            summary_llm=self.summary_llm,
            summary_llm_config=summary_llm_config,
            embedding=self.embedding,
            agent=AgentSettings(
                agent_llm=self.llm,
                agent_llm_config=llm_config,
                index=IndexSettings(paper_directory=str(self.paper_directory)),
            ),
            answer=AnswerSettings(
                evidence_k=evidence_k,
                answer_max_sources=max_sources,
            ),
            parsing=ParsingSettings(
                multimodal=False if local_ollama_mode else True,
            ),
        )

        response = ask(query, settings=settings)
        formatted_answer = getattr(response, "formatted_answer", None) or getattr(response, "answer", "")
        answer = getattr(response, "answer", formatted_answer)
        context = getattr(response, "context", "")
        references = self._extract_references(response)

        return PaperQAResponse(
            answer=answer,
            formatted_answer=formatted_answer,
            context=context,
            references=references,
        )

    @staticmethod
    def _extract_references(response: Any) -> List[Dict[str, Any]]:
        contexts = getattr(response, "contexts", None)
        if not contexts:
            return []

        extracted = []
        for item in contexts:
            extracted.append(
                {
                    "text": getattr(item, "context", None) or getattr(item, "text", ""),
                    "score": getattr(item, "score", None),
                    "citation": getattr(item, "citation", None),
                    "source": getattr(getattr(item, "text", None), "name", None),
                }
            )
        return extracted