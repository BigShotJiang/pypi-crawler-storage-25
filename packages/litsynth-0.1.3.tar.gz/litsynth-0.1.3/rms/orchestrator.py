import os
import tempfile
from typing import Dict, Tuple

try:
    import boto3
    from botocore.exceptions import ClientError
except ImportError:  # pragma: no cover - optional cloud dependency
    boto3 = None

    class ClientError(Exception):
        pass

from rms import database_manager, writor, llm_manager, utils, citation_store
from rms.pdf_handler import PDFHandler
from rms.utils import testing_lambda

class Orchestrator:
    def __init__(self, pdf_s3_key_or_path: str=None):
        self.initial_categories = {
            "Main Topic": "Extract and summarize the main topic of this paper, focusing on the broad area of research being addressed.",
            "Sub Topic": "Determine the sub topic by isolating the specific issue or domain that narrows down the broader subject of the paper.",
            "Article Name": "Retrieve and confirm the exact title of this research paper.",
            "Aim of the Study": "Provide a summary of the study's aim by extracting the stated research objectives or problems the paper intends to address.",
            "Industry Types": "List and describe the industry types mentioned in the paper, noting any specific sectors that are the focus of the study.",
            "Data Source": "Extract details about the data sources used in this study, including the origin (e.g., survey data, database, observational records) and any specific names or institutions involved.",
            "Data Timings": "Identify and summarize the data timings mentioned in the paper, noting the start and end dates or relevant periods for data collection.",
            "Input Variables": "Extract the input variables or factors that the study utilizes for its analysis or modeling. Provide a brief explanation of each if available.",
            "Methodology": "Outline the methodology of the study by summarizing the overall approach and research design as described in the paper.",
            "Machine Learning Algorithms": "List the machine learning algorithms mentioned in the study, including any details on model architecture or implementation specifics.",
            "Quantitative Techniques": "Extract and summarize the quantitative techniques used in the study, explaining how they contribute to data analysis and interpretation.",
            "Optimization Techniques": "Describe any optimization techniques used in the paper, including the methodology behind tuning or enhancing model performance.",
            "Comparison With": "Summarize the comparisons made in the study, highlighting how the current research stacks up against existing methods, models, or findings.",
            "Top Performer": "Determine which method or algorithm is reported as the top performer in the study, including relevant performance metrics if provided.",
            "Findings": "Extract and outline the major findings of the paper, including any quantitative or qualitative results highlighted by the authors.",
            "Research Gap/Limitations": "Summarize the research gaps and limitations discussed in the paper, noting areas that the authors have identified as requiring further investigation.",
            "Conclusions": "Extract and summarize the conclusions of the paper, emphasizing the implications of the research findings and any recommendations provided by the authors."
        }
        
        # Initialize S3 client
        self.s3_bucket = os.environ.get('S3_BUCKET_NAME', 'research-manager-system-data')
        self.s3_client = boto3.client('s3') if boto3 is not None else None
        
        self.database_manager = database_manager.DatabaseManager()
        self.pdf_s3_key_or_path = pdf_s3_key_or_path
        self.pdf_keys_list = []
        
        # Process S3 path or key
        if pdf_s3_key_or_path:
            if pdf_s3_key_or_path.startswith('s3://'):
                # Remove the s3:// prefix and bucket name if present
                parts = pdf_s3_key_or_path.replace('s3://', '').split('/', 1)
                if len(parts) > 1:
                    pdf_s3_key_or_path = parts[1]
            
            # Try to list all PDFs in the prefix if it's a directory
            try:
                if self.s3_client is None:
                    raise RuntimeError("boto3 not installed; S3-backed ingestion is unavailable.")
                response = self.s3_client.list_objects_v2(
                    Bucket=self.s3_bucket,
                    Prefix=pdf_s3_key_or_path if pdf_s3_key_or_path else ''
                )
                
                if 'Contents' in response:
                    for obj in response['Contents']:
                        key = obj['Key']
                        if key.endswith('.pdf'):
                            self.pdf_keys_list.append(key)
                            print(f"PDF found in S3: {key}")
                            
                            # Save to database if not already saved
                            if os.path.basename(key) not in self.database_manager.saved_documents:
                                self._save_s3_pdf_to_db(key)
            except ClientError as e:
                print(f"Error accessing S3: {e}")
                
            # If it's a single PDF, add it to the list
            if pdf_s3_key_or_path.endswith('.pdf'):
                self.pdf_keys_list.append(pdf_s3_key_or_path)
                if os.path.basename(pdf_s3_key_or_path) not in self.database_manager.saved_documents:
                    self._save_s3_pdf_to_db(pdf_s3_key_or_path)
        
        self.llm_manager = llm_manager.LLMManager()
        self.output_filename = "literature_review.xlsx"
        self.citation_store = citation_store.CitationStore()
        self.audit_log_path = os.environ.get("CITATION_AUDIT_LOG_PATH", "logs/citation_audit_log.csv")

    def _save_s3_pdf_to_db(self, s3_key):
        """Download PDF from S3 and save it to the database"""
        try:
            if self.s3_client is None:
                raise RuntimeError("boto3 not installed; cannot download PDF from S3.")
            # Create a temporary file
            with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as temp_file:
                temp_path = temp_file.name
            
            # Download the file from S3
            self.s3_client.download_file(self.s3_bucket, s3_key, temp_path)
            
            # Save to database using DatabaseManager's save method
            self.database_manager.save(temp_path)
            
            # Clean up temporary file
            os.remove(temp_path)
            print(f"Successfully saved {s3_key} to database")
            
        except Exception as e:
            print(f"Error saving {s3_key} from S3 to database: {e}")

    def get_default_literature_categories(self):
        document_writer = writor.DocumentWriter(self.output_filename)

        # Create initial Excel file
        document_writer.export_to_excel([])

        for pdf_key in self.pdf_keys_list:
            answers = {"Filename": os.path.basename(pdf_key)}
            print(f"Processing: {pdf_key}")
            
            for topic, category in self.initial_categories.items():
                # Semantic search using just the filename
                chunks = self.database_manager.semantic_search(category, [os.path.basename(pdf_key)])
                chunk_text_list = [i["chunk_text"] for i in chunks]

                answer = self.llm_manager.ask(category, chunk_text_list)
                answers[topic] = answer

                utilities = utils.Utils()
                relevant_chunk, highest_similarity, max_similarity_idx = utilities.find_relevant_chunk(chunk_text_list, answer)

                required_chunk = chunks[max_similarity_idx]

            document_writer.update_excel(answers)
            
            # Upload Excel file to S3
            try:
                self.s3_client.upload_file(self.output_filename, self.s3_bucket, f"reports/{self.output_filename}")
            except Exception as e:
                print(f"Error uploading Excel report to S3: {e}")

    def upload_pdf_to_s3(self, local_path, s3_key=None):
        """Upload a local PDF file to S3 and process it"""
        if not s3_key:
            s3_key = f"uploads/{os.path.basename(local_path)}"
            
        try:
            if self.s3_client is None:
                raise RuntimeError("boto3 not installed; cannot upload PDF to S3.")
            # Upload to S3
            self.s3_client.upload_file(local_path, self.s3_bucket, s3_key)
            print(f"Successfully uploaded {local_path} to S3 as {s3_key}")
            
            # Process the PDF and save to database if not already saved
            if os.path.basename(s3_key) not in self.database_manager.saved_documents:
                self._save_s3_pdf_to_db(s3_key)
            
            return s3_key
        except Exception as e:
            print(f"Error uploading {local_path} to S3: {e}")
            return None
        
    def upload_and_save_to_database(self, pdf_keys_list):
        """Upload and save multiple PDFs to the database"""
        results = []
        for key in pdf_keys_list:
            try:
                if self.s3_client is None:
                    raise RuntimeError("boto3 not installed; cannot hydrate PDFs from S3.")
                # Download the file from S3 to a temporary location
                with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as temp_file:
                    temp_path = temp_file.name
                
                self.s3_client.download_file(self.s3_bucket, key, temp_path)
                
                # Save the document using the database manager's save method
                self.database_manager.save(temp_path)
                
                # Clean up temporary file
                os.remove(temp_path)
                
                results.append({"key": key, "status": "success"})
            except Exception as e:
                results.append({"key": key, "status": "error", "message": str(e)})
        return results
    
    def full_text_search(self, search_query):
        """Perform full text search using the database manager"""
        return self.database_manager.boolean_search(search_query)
        
    def semantic_search(self, search_query, pdf_name_list=None, top_k=5):
        """Perform semantic search using the database manager"""
        return self.database_manager.semantic_search(search_query, pdf_name_list, top_k)
        
    def ask_llm(self, query):
        """Ask a question directly to the LLM"""
        return self.llm_manager.ask_chatgpt(query)
        
    def rag_with_llm(self, query, pdf_name_list=None, top_k=5):
        """Perform RAG (Retrieval Augmented Generation) with LLM"""
        chunks = self.database_manager.semantic_search(query, pdf_name_list, top_k)
        chunk_text_list = [i["chunk_text"] for i in chunks]
        combined_text = " ".join(chunk_text_list)
        prompt = f"Question: {query}\nContext: {combined_text}\nAnswer:"

        answer = self.llm_manager.ask_chatgpt(prompt)
        return answer

    def load_authoritative_citations(self, citation_file_path: str) -> Dict[str, int]:
        """Load citations from RIS/BibTeX only. LLM-generated citation text is disallowed."""
        return self.citation_store.load(citation_file_path)

    @staticmethod
    def _read_source_text(source_document: str) -> str:
        if source_document.lower().endswith(".pdf"):
            full_text, _ = PDFHandler(source_document).read()
            if not full_text:
                raise ValueError(f"Could not read PDF content from {source_document}")
            return full_text

        with open(source_document, "r", encoding="utf-8") as source_file:
            return source_file.read()

    def insert_citation_to_draft(
        self,
        citation_id: str,
        source_document: str,
        char_range: Tuple[int, int],
        draft_path: str,
        user_id: str = "system",
    ) -> Dict:
        """
        Deterministic citation insertion flow.
        - Citation comes only from RIS/BibTeX-derived authoritative records.
        - Evidence excerpt is reconstructed from exact character range.
        - Operation is logged to an audit file.
        """
        if char_range[0] < 0 or char_range[1] <= char_range[0]:
            raise ValueError("Invalid char_range. Expected (start, end) with end > start >= 0.")

        citation_record = self.citation_store.get(citation_id)
        full_text = self._read_source_text(source_document)

        if char_range[1] > len(full_text):
            raise ValueError("char_range exceeds source document length.")

        excerpt = full_text[char_range[0]:char_range[1]]
        timestamp_utc = self.citation_store.now_utc_iso()

        writor.DraftWriter.append_citation_evidence(
            draft_path=draft_path,
            citation={
                "authors": citation_record.authors,
                "year": citation_record.year,
                "title": citation_record.title,
                "doi": citation_record.doi,
                "url": citation_record.url,
                "publisher": citation_record.publisher,
            },
            source_document=source_document,
            char_range=char_range,
            excerpt_text=excerpt,
            user_id=user_id,
            timestamp_utc=timestamp_utc,
        )

        audit_event = {
            "timestamp_utc": timestamp_utc,
            "user_id": user_id,
            "citation_id": citation_id,
            "source_document": source_document,
            "char_start": char_range[0],
            "char_end": char_range[1],
            "draft_path": draft_path,
        }
        writor.DraftWriter.append_audit_log(self.audit_log_path, audit_event)

        return {
            "status": "ok",
            "citation_id": citation_id,
            "draft_path": draft_path,
            "char_range": [char_range[0], char_range[1]],
            "timestamp_utc": timestamp_utc,
        }


def lambda_handler(event, context):
    """
    AWS Lambda handler to process uploaded PDFs or perform semantic search
    
    Event structure:
    {
        "action": "upload" | "search" | "process",
        "s3_key": "path/to/file.pdf",  # For single file upload action
        "s3_keys": ["path/to/file1.pdf", "path/to/file2.pdf"],  # For multiple file upload
        "query": "search query",       # For search action
        "document_names": ["doc1.pdf", "doc2.pdf"] # For search/process actions with specific documents
    }
    """
    try:
        action = event.get("action")
        
        if action == "upload_and_save":
            # Handle single file upload
            s3_key = event.get("s3_key")
            # Handle multiple file upload
            s3_keys = event.get("s3_keys", [])
            
            if not s3_key and not s3_keys:
                return {
                    "statusCode": 400,
                    "body": "Missing s3_key or s3_keys parameter"
                }
            
            orchestrator = Orchestrator()
            
            # Process single file
            if s3_key:
                orchestrator._save_s3_pdf_to_db(s3_key)
                return {
                    "statusCode": 200,
                    "body": f"Successfully processed {s3_key}"
                }
            
            # Process multiple files
            results = orchestrator.upload_and_save_to_database(s3_keys)
            
            return {
                "statusCode": 200,
                "body": {
                    "message": f"Processed {len(results)} files",
                    "results": results
                }
            }
            
        elif action == "full_text_search":
            # For full text search with optional document filtering
            query = event.get("query")
            
            if not query:
                return {
                    "statusCode": 400,
                    "body": "Missing query parameter"
                }
                
            orchestrator = Orchestrator()
            results = orchestrator.full_text_search(query)
            
            return {
                "statusCode": 200,
                "body": results
            }
            
        elif action == "semantic_search":
            # For semantic search with optional document filtering
            query = event.get("query")
            document_names = event.get("document_names")  # Optional filter by documents
            top_k = event.get("top_k", 5)  # Default to 5 results
            
            if not query:
                return {
                    "statusCode": 400,
                    "body": "Missing query parameter"
                }
                
            orchestrator = Orchestrator()
            results = orchestrator.semantic_search(query, document_names, top_k)
            
            return {
                "statusCode": 200,
                "body": results
            }
            
        elif action == "ask_llm":
            # Direct question to LLM
            query = event.get("query")
            
            if not query:
                return {
                    "statusCode": 400,
                    "body": "Missing query parameter"
                }
                
            orchestrator = Orchestrator()
            result = orchestrator.ask_llm(query)
            
            return {
                "statusCode": 200,
                "body": result
            }
            
        elif action == "rag_with_llm":
            # RAG with LLM
            query = event.get("query")
            document_names = event.get("document_names")  # Optional filter by documents
            top_k = event.get("top_k", 5)  # Default to 5 results
            
            if not query:
                return {
                    "statusCode": 400,
                    "body": "Missing query parameter"
                }
                
            orchestrator = Orchestrator()
            result = orchestrator.rag_with_llm(query, document_names, top_k)
            
            return {
                "statusCode": 200,
                "body": result
            }
            
        elif action == "process_literature":
            # Process literature for categories
            s3_key_or_path = event.get("s3_key_or_path")
            
            if not s3_key_or_path:
                return {
                    "statusCode": 400,
                    "body": "Missing s3_key_or_path parameter"
                }
                
            orchestrator = Orchestrator(s3_key_or_path)
            orchestrator.get_default_literature_categories()
            
            return {
                "statusCode": 200,
                "body": f"Successfully processed literature categories from {s3_key_or_path} and generated report"
            }
                
        else:
            return {
                "statusCode": 400,
                "body": f"Unknown action: {action}"
            }
    
    except Exception as e:
        import traceback
        return {
            "statusCode": 500,
            "body": f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
        }
