"""Factory for instantiating RMS components."""

from rms.config import (
    PipelineConfig,
    IngestionType,
    EmbeddingType,
    VectorDBType,
    RankerType,
    GeneratorType,
)
from rms.ingestion import IngestorBase, DoclingIngestor
from rms.embeddings import EmbedderBase, BGELocalEmbedder
from rms.vectordb import VectorDBBase, QdrantLocalDB
from rms.ranking import RankerBase, BGEReranker
from rms.generation import GeneratorBase, QwenLocalGenerator
from typing import Dict, Type


class ComponentFactory:
    """Factory for creating pipeline components."""

    # Registries for all component types
    ingestors: Dict[IngestionType, Type[IngestorBase]] = {
        IngestionType.DOCLING: DoclingIngestor,
    }

    embedders: Dict[EmbeddingType, Type[EmbedderBase]] = {
        EmbeddingType.BGE_LOCAL: BGELocalEmbedder,
    }

    vectordbs: Dict[VectorDBType, Type[VectorDBBase]] = {
        VectorDBType.QDRANT_LOCAL: QdrantLocalDB,
    }

    rankers: Dict[RankerType, Type[RankerBase]] = {
        RankerType.BGE_RERANKER: BGEReranker,
    }

    generators: Dict[GeneratorType, Type[GeneratorBase]] = {
        GeneratorType.QWEN_LOCAL: QwenLocalGenerator,
    }

    @staticmethod
    def create_ingestor(config: PipelineConfig) -> IngestorBase:
        """Create ingestor instance."""
        ingestor_class = ComponentFactory.ingestors.get(config.ingestion.type)
        if not ingestor_class:
            raise ValueError(f"Unknown ingestor type: {config.ingestion.type}")
        
        return ingestor_class(**config.ingestion.options)

    @staticmethod
    def create_embedder(config: PipelineConfig) -> EmbedderBase:
        """Create embedder instance."""
        embedder_class = ComponentFactory.embedders.get(config.embedding.type)
        if not embedder_class:
            raise ValueError(f"Unknown embedding type: {config.embedding.type}")
        
        kwargs = {
            "model_name": config.embedding.model,
            "device": config.embedding.device,
            "batch_size": config.embedding.batch_size,
            **config.embedding.options,
        }
        return embedder_class(**kwargs)

    @staticmethod
    def create_vectordb(config: PipelineConfig) -> VectorDBBase:
        """Create vector database instance."""
        vectordb_class = ComponentFactory.vectordbs.get(config.vectordb.type)
        if not vectordb_class:
            raise ValueError(f"Unknown vector DB type: {config.vectordb.type}")
        
        kwargs = {
            "storage_path": config.vectordb.storage_path,
            **config.vectordb.options,
        }
        return vectordb_class(**kwargs)

    @staticmethod
    def create_ranker(config: PipelineConfig) -> RankerBase:
        """Create ranker instance."""
        if not config.ranker.enabled:
            return None
        
        ranker_class = ComponentFactory.rankers.get(config.ranker.type)
        if not ranker_class:
            raise ValueError(f"Unknown ranker type: {config.ranker.type}")
        
        kwargs = {
            "model_name": config.ranker.model,
            **config.ranker.options,
        }
        return ranker_class(**kwargs)

    @staticmethod
    def create_generator(config: PipelineConfig) -> GeneratorBase:
        """Create generator instance."""
        generator_class = ComponentFactory.generators.get(config.generator.type)
        if not generator_class:
            raise ValueError(f"Unknown generator type: {config.generator.type}")
        
        kwargs = {
            "model_name": config.generator.model,
            **config.generator.options,
        }
        return generator_class(**kwargs)

    @staticmethod
    def register_ingestor(ingestor_type: IngestionType, ingestor_class: Type[IngestorBase]):
        """Register custom ingestor."""
        ComponentFactory.ingestors[ingestor_type] = ingestor_class

    @staticmethod
    def register_embedder(embedding_type: EmbeddingType, embedder_class: Type[EmbedderBase]):
        """Register custom embedder."""
        ComponentFactory.embedders[embedding_type] = embedder_class

    @staticmethod
    def register_vectordb(vectordb_type: VectorDBType, vectordb_class: Type[VectorDBBase]):
        """Register custom vector DB."""
        ComponentFactory.vectordbs[vectordb_type] = vectordb_class

    @staticmethod
    def register_ranker(ranker_type: RankerType, ranker_class: Type[RankerBase]):
        """Register custom ranker."""
        ComponentFactory.rankers[ranker_type] = ranker_class

    @staticmethod
    def register_generator(generator_type: GeneratorType, generator_class: Type[GeneratorBase]):
        """Register custom generator."""
        ComponentFactory.generators[generator_type] = generator_class
