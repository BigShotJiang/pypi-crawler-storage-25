import sqlite3
import json
import logging
import hashlib
import os
import tempfile
from datetime import datetime
from contextlib import contextmanager
from typing import List, Dict, Optional
from pathlib import Path
from io import BytesIO

try:
    import boto3
except ImportError:  # pragma: no cover - optional cloud dependency
    boto3 = None

from rms.chroma_manager import ChromaDatabaseManager


class SQLiteDatabaseManager:
    def __init__(self, db_path: str = "sql_lite_database.db"):
        """Initialize database with the specified path"""
        self.db_path = db_path
        self.logger = logging.getLogger(__name__)
        
        # S3 configuration
        self.s3_bucket = "research-manager-system-data"
        self.s3_client = boto3.client('s3') if boto3 is not None else None
        
        # Local temp path for SQLite operations
        self.local_db_path = os.path.join('/tmp', os.path.basename(db_path))
        
        # Download DB if it exists in S3, otherwise create new
        if self.s3_client is not None:
            self._sync_db_from_s3()
        self.init_database()

    def _sync_db_from_s3(self):
        """Download database from S3 if it exists"""
        if self.s3_client is None:
            self.logger.info("boto3 not installed; using local SQLite database only.")
            return
        try:
            self.s3_client.download_file(
                Bucket=self.s3_bucket,
                Key=self.db_path,
                Filename=self.local_db_path
            )
            self.logger.info(f"Downloaded database from s3://{self.s3_bucket}/{self.db_path}")
        except self.s3_client.exceptions.ClientError as e:
            if e.response['Error']['Code'] == '404':
                self.logger.info("Database doesn't exist in S3 yet. Will create new local instance.")
            else:
                self.logger.error(f"Error downloading database: {str(e)}")

    def _sync_db_to_s3(self):
        """Upload database to S3 after modifications"""
        if self.s3_client is None:
            return
        try:
            self.s3_client.upload_file(
                Filename=self.local_db_path,
                Bucket=self.s3_bucket,
                Key=self.db_path
            )
            self.logger.info(f"Uploaded database to s3://{self.s3_bucket}/{self.db_path}")
        except Exception as e:
            self.logger.error(f"Error uploading database to S3: {str(e)}")

    @contextmanager
    def get_connection(self):
        """Context manager for database connections"""
        conn = sqlite3.connect(
            self.local_db_path,
            detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES
        )
        # Fix for datetime adapter deprecation warning
        sqlite3.register_adapter(datetime, lambda val: val.isoformat())
        sqlite3.register_converter("timestamp", lambda val: datetime.fromisoformat(val.decode()))

        conn.row_factory = sqlite3.Row
        try:
            yield conn
        finally:
            conn.close()
            # Upload DB to S3 after each connection closes
            self._sync_db_to_s3()

    def init_database(self) -> None:
        """Initialize database schema with proper indexing"""
        try:
            with self.get_connection() as conn:
                conn.executescript('''
                    -- PDFs table with metadata
                    CREATE TABLE IF NOT EXISTS pdfs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        title TEXT NOT NULL,
                        file_path TEXT UNIQUE NOT NULL,
                        file_hash TEXT UNIQUE NOT NULL,
                        page_count INTEGER NOT NULL,
                        created_at TEXT NOT NULL,  
                        metadata TEXT
                    );

                    -- Full-text search table for PDF content
                    CREATE VIRTUAL TABLE IF NOT EXISTS pdf_content USING fts5(
                        pdf_id UNINDEXED,
                        page_number,
                        content,
                        tokenize='porter unicode61'
                    );

                    -- Table for text chunks used in semantic search
                    CREATE TABLE IF NOT EXISTS text_chunks (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        pdf_id INTEGER NOT NULL,
                        chunk_index INTEGER NOT NULL,
                        chunk_text TEXT NOT NULL,
                        start_char INTEGER NOT NULL,
                        end_char INTEGER NOT NULL,
                        page_numbers TEXT NOT NULL,
                        FOREIGN KEY (pdf_id) REFERENCES pdfs (id) ON DELETE CASCADE
                    );

                    -- Indexes for better query performance
                    CREATE INDEX IF NOT EXISTS idx_pdfs_title ON pdfs(title);
                    CREATE INDEX IF NOT EXISTS idx_pdfs_created ON pdfs(created_at);
                    CREATE INDEX IF NOT EXISTS idx_chunks_pdf ON text_chunks(pdf_id);
                ''')
                self.logger.info("Database schema initialized successfully")
        except sqlite3.Error as e:
            self.logger.error(f"Database initialization error: {str(e)}")
            raise

    def calculate_file_hash(self, file_path: str) -> str:
        """Calculate SHA-256 hash of a file from S3 or local disk."""
        sha256_hash = hashlib.sha256()
        
        if self.s3_client is None:
            with open(file_path, "rb") as handle:
                sha256_hash.update(handle.read())
            return sha256_hash.hexdigest()

        try:
            response = self.s3_client.get_object(Bucket=self.s3_bucket, Key=file_path)
            file_content = response['Body'].read()
            sha256_hash.update(file_content)
            return sha256_hash.hexdigest()
        except self.s3_client.exceptions.ClientError as e:
            self.logger.error(f"Error calculating file hash for {file_path}: {str(e)}")
            raise

    def save(self, text, meta_data) -> Optional[int]:
        """
        Process and save a PDF document using PDFHandler.

        Args:
            text: Extracted text from the PDF
            meta_data: Metadata dictionary from the PDF

        Returns:
            Optional[int]: ID of saved document or None if failed
        """
        try:
            if not text or not meta_data:
                raise ValueError("Must provide text or meta_data")

            # Calculate file hash from S3
            file_hash = self.calculate_file_hash(meta_data["file_path"])

            # Check if file already exists
            with self.get_connection() as conn:
                existing = conn.execute(
                    "SELECT id FROM pdfs WHERE file_hash = ?",
                    (file_hash,)
                ).fetchone()

                if existing:
                    self.logger.info(f"Document already exists with ID: {existing['id']}")
                    return existing['id']

            # Create chunks using semantic engine
            chunks, chunk_metadata = ChromaDatabaseManager().create_chunks(text, meta_data)

            # Save to database
            with self.get_connection() as conn:
                cursor = conn.cursor()

                # Insert PDF metadata
                cursor.execute('''
                    INSERT INTO pdfs (
                        title, file_path, file_hash, page_count,
                        created_at, metadata
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (
                    Path(meta_data["file_path"]).stem,  # Use filename as title
                    meta_data["file_path"],
                    file_hash,
                    meta_data['total_pages'],
                    datetime.now().isoformat(),
                    json.dumps(meta_data)
                ))

                pdf_id = cursor.lastrowid

                # Insert page contents
                for page_data in meta_data['page_data']:
                    page_num = page_data['page_number']
                    page_text = page_data['text']
                    if page_text.strip():
                        cursor.execute('''
                            INSERT INTO pdf_content (pdf_id, page_number, content)
                            VALUES (?, ?, ?)
                        ''', (pdf_id, page_num, page_text))

                # Store text chunks
                for chunk, meta in zip(chunks, chunk_metadata):
                    cursor.execute('''
                        INSERT INTO text_chunks (
                            pdf_id, chunk_index, chunk_text,
                            start_char, end_char, page_numbers
                        )
                        VALUES (?, ?, ?, ?, ?, ?)
                    ''', (
                        pdf_id,
                        meta['chunk_index'],
                        chunk['text'],
                        meta['start_char'],
                        meta['end_char'],
                        ','.join(map(str, meta['page_numbers']))
                    ))

                conn.commit()
                self.logger.info(f"Successfully saved document: {meta_data}")
                return pdf_id

        except Exception as e:
            self.logger.error(f"Error processing PDF {meta_data}: {str(e)}")
            return None

    def boolean_search(self, query: str, limit: int = 10) -> List[Dict]:
        """
        Perform boolean search using SQLite FTS5.

        Args:
            query: Search query string
            limit: Maximum number of results to return

        Returns:
            List of search results with snippets
        """
        self.logger.info(f"Executing FTS5 query: {query}")

        try:
            with self.get_connection() as conn:
                results = conn.execute('''
                    SELECT DISTINCT
                        p.id,
                        p.title,
                        p.file_path,
                        c.page_number,
                        snippet(pdf_content, 2, '<mark>', '</mark>', '...', 50) as context
                    FROM pdf_content c
                    JOIN pdfs p ON c.pdf_id = p.id
                    WHERE c.content MATCH ?
                    ORDER BY rank
                    LIMIT ?
                ''', (query, limit)).fetchall()

                return [dict(row) for row in results]

        except sqlite3.Error as e:
            self.logger.error(f"Search error: {str(e)}")
            return []

    def advanced_search(self,
                        must_include: Optional[List[str]] = None,
                        must_exclude: Optional[List[str]] = None,
                        exact_phrases: Optional[List[str]] = None,
                        any_of: Optional[List[str]] = None) -> List[Dict]:
        """
        Perform advanced boolean search with multiple criteria.

        Args:
            must_include: Terms that must be present
            must_exclude: Terms that must not be present
            exact_phrases: Exact phrases to match
            any_of: At least one of these terms must be present

        Returns:
            List of search results
        """
        query_parts = []

        if must_include:
            query_parts.extend(term.replace('"', '""') for term in must_include)

        if exact_phrases:
            query_parts.extend(f'"{phrase.replace('"', '""')}"' for phrase in exact_phrases)

        if any_of:
            or_terms = ' OR '.join(term.replace('"', '""') for term in any_of)
            if or_terms:
                query_parts.append(f'{{{or_terms}}}')

        query = ' '.join(query_parts)

        if must_exclude:
            exclusions = ' '.join(f'-{term.replace('"', '""')}' for term in must_exclude)
            query = f'{query} {exclusions}' if query else exclusions

        self.logger.info(f"Generated query: {query}")
        return self.boolean_search(query)
