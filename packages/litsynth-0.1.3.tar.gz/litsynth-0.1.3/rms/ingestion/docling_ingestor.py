"""Docling-based PDF parser for robust document extraction."""

from typing import List
from rms.ingestion import IngestorBase, Document, DocumentFormat
import os


class DoclingIngestor(IngestorBase):
    """
    PDF ingestor using Docling library.
    
    Docling provides superior PDF parsing with:
    - Layout preservation
    - Table handling
    - Text + metadata extraction
    - Character-level offsets
    """

    def __init__(self, output_format: DocumentFormat = DocumentFormat.FULL):
        """
        Initialize Docling ingestor.
        
        Args:
            output_format: Desired output format (FULL, TEXT_ONLY, STRUCTURED)
        """
        try:
            from docling.document_converter import DocumentConverter
            from docling.dataclasses import ConversionStatus
            self.converter = DocumentConverter()
            self.ConversionStatus = ConversionStatus
        except ImportError:
            raise ImportError(
                "Docling not installed. Install with: pip install docling"
            )
        self.output_format = output_format

    def ingest(self, source_path: str, **kwargs) -> List[Document]:
        """Ingest single PDF."""
        return self.ingest_batch([source_path], **kwargs)

    def ingest_batch(self, source_paths: List[str], **kwargs) -> List[Document]:
        """Ingest multiple PDFs."""
        documents = []

        for source_path in source_paths:
            if not os.path.exists(source_path):
                raise FileNotFoundError(f"PDF not found: {source_path}")

            if not source_path.lower().endswith(".pdf"):
                raise ValueError(f"Not a PDF file: {source_path}")

            try:
                # Convert PDF to document
                result = self.converter.convert(source_path)

                if result.status != self.ConversionStatus.SUCCESS:
                    raise RuntimeError(f"Conversion failed for {source_path}: {result.status}")

                doc_content = result.document

                # Extract text and metadata
                text = doc_content.export_to_markdown()
                
                doc = Document(
                    id=os.path.basename(source_path).replace(".pdf", ""),
                    text=text,
                    source=source_path,
                    format=self.output_format,
                    metadata={
                        "filename": os.path.basename(source_path),
                        "file_size": os.path.getsize(source_path),
                        "num_pages": len(doc_content.pages),
                        "source_uri": source_path,
                    },
                )
                documents.append(doc)

            except Exception as e:
                raise RuntimeError(f"Error processing {source_path}: {str(e)}")

        return documents

    def supports_format(self, format: DocumentFormat) -> bool:
        """Docling supports all formats."""
        return True

    @property
    def model_name(self) -> str:
        return "docling"
