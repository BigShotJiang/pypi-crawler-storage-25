from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Dict, Any, Optional
from enum import Enum


class DocumentFormat(str, Enum):
    """Document format types."""
    FULL = "full"  # Full document with layout
    TEXT_ONLY = "text"  # Text extraction only
    STRUCTURED = "structured"  # Markdown structure


@dataclass
class Document:
    """Base document class."""
    id: str
    text: str
    source: str
    format: DocumentFormat = DocumentFormat.TEXT_ONLY
    metadata: Dict[str, Any] = None
    chunks: Optional[List['DocumentChunk']] = None


@dataclass
class DocumentChunk:
    """Document chunk with metadata."""
    chunk_id: str
    document_id: str
    text: str
    start_char: int
    end_char: int
    page_num: Optional[int] = None
    metadata: Dict[str, Any] = None


class IngestorBase(ABC):
    """Base class for all document ingestors."""

    @abstractmethod
    def ingest(self, source_path: str, **kwargs) -> List[Document]:
        """
        Ingest documents from source.
        
        Args:
            source_path: Path to document or API endpoint
            **kwargs: Ingestor-specific options
            
        Returns:
            List of Document objects
        """
        pass

    @abstractmethod
    def ingest_batch(self, source_paths: List[str], **kwargs) -> List[Document]:
        """Batch ingest multiple sources."""
        pass

    @abstractmethod
    def supports_format(self, format: DocumentFormat) -> bool:
        """Check if ingestor supports given format."""
        pass
