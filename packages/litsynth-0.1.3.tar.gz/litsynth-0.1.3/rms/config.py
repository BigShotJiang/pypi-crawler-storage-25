"""Configuration management for RMS."""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional
from enum import Enum
import json
import os


class ExecutionMode(str, Enum):
    """Execution mode."""
    LOCAL = "local"             # All local
    DOCKER = "docker"           # Docker containers
    AWS_HYBRID = "aws_hybrid"   # Local + AWS services
    AWS_FULL = "aws_full"       # Full AWS managed


class IngestionType(str, Enum):
    DOCLING = "docling"
    SCOPUS = "scopus"
    ARXIV = "arxiv"


class EmbeddingType(str, Enum):
    BGE_LOCAL = "bge_local"
    BGE_API = "bge_api"
    BEDROCK = "bedrock"


class VectorDBType(str, Enum):
    QDRANT_LOCAL = "qdrant_local"
    QDRANT_CLOUD = "qdrant_cloud"
    MILVUS = "milvus"


class RankerType(str, Enum):
    BGE_RERANKER = "bge_reranker"
    CROSS_ENCODER = "cross_encoder"
    NONE = "none"


class GeneratorType(str, Enum):
    QWEN_LOCAL = "qwen_local"
    OPENAI_API = "openai_api"
    CLAUDE_API = "claude_api"
    BEDROCK = "bedrock"


@dataclass
class IngestionConfig:
    type: IngestionType = IngestionType.DOCLING
    output_format: str = "full"  # "full", "text", "structured"
    options: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EmbeddingConfig:
    type: EmbeddingType = EmbeddingType.BGE_LOCAL
    model: str = "BAAI/bge-small-en-v1.5"
    device: str = "auto"
    batch_size: int = 32
    options: Dict[str, Any] = field(default_factory=dict)


@dataclass
class VectorDBConfig:
    type: VectorDBType = VectorDBType.QDRANT_LOCAL
    storage_path: str = "./data/qdrant"
    collection_name: str = "documents"
    options: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RankerConfig:
    type: RankerType = RankerType.BGE_RERANKER
    model: Optional[str] = "BAAI/bge-reranker-base"
    enabled: bool = True
    top_k: int = 10
    options: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GeneratorConfig:
    type: GeneratorType = GeneratorType.QWEN_LOCAL
    model: str = "Qwen/Qwen-7B-Chat"
    max_tokens: int = 500
    temperature: float = 0.7
    options: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PersistenceConfig:
    enabled: bool = True
    sync_enabled: bool = False
    sync_backend: str = "local"  # "local", "s3"
    s3_bucket: Optional[str] = None
    save_interval: int = 100  # Save every N operations


@dataclass
class PipelineConfig:
    """Main configuration for RMS pipeline."""
    execution_mode: ExecutionMode = ExecutionMode.LOCAL
    
    ingestion: IngestionConfig = field(default_factory=IngestionConfig)
    embedding: EmbeddingConfig = field(default_factory=EmbeddingConfig)
    vectordb: VectorDBConfig = field(default_factory=VectorDBConfig)
    ranker: RankerConfig = field(default_factory=RankerConfig)
    generator: GeneratorConfig = field(default_factory=GeneratorConfig)
    persistence: PersistenceConfig = field(default_factory=PersistenceConfig)
    
    # Logging and monitoring
    log_level: str = "INFO"
    log_file: Optional[str] = None
    
    @classmethod
    def from_file(cls, config_path: str) -> "PipelineConfig":
        """Load configuration from YAML/JSON file."""
        if config_path.endswith(".json"):
            with open(config_path) as f:
                data = json.load(f)
        else:
            try:
                import yaml
                with open(config_path) as f:
                    data = yaml.safe_load(f)
            except ImportError:
                raise ImportError("PyYAML required for YAML config. Install with: pip install pyyaml")
        
        return cls.from_dict(data)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PipelineConfig":
        """Create config from dictionary."""
        return cls(
            execution_mode=ExecutionMode(data.get("execution_mode", "local")),
            ingestion=IngestionConfig(
                type=IngestionType(data.get("ingestion", {}).get("type", "docling")),
                output_format=data.get("ingestion", {}).get("output_format", "full"),
            ),
            embedding=EmbeddingConfig(
                type=EmbeddingType(data.get("embedding", {}).get("type", "bge_local")),
                model=data.get("embedding", {}).get("model", "BAAI/bge-small-en-v1.5"),
                device=data.get("embedding", {}).get("device", "auto"),
            ),
            vectordb=VectorDBConfig(
                type=VectorDBType(data.get("vectordb", {}).get("type", "qdrant_local")),
                storage_path=data.get("vectordb", {}).get("storage_path", "./data/qdrant"),
            ),
            ranker=RankerConfig(
                type=RankerType(data.get("ranker", {}).get("type", "bge_reranker")),
                enabled=data.get("ranker", {}).get("enabled", True),
            ),
            generator=GeneratorConfig(
                type=GeneratorType(data.get("generator", {}).get("type", "qwen_local")),
                model=data.get("generator", {}).get("model", "Qwen/Qwen-7B-Chat"),
            ),
            persistence=PersistenceConfig(
                enabled=data.get("persistence", {}).get("enabled", True),
                sync_enabled=data.get("persistence", {}).get("sync_enabled", False),
                s3_bucket=data.get("persistence", {}).get("s3_bucket"),
            ),
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary."""
        return {
            "execution_mode": self.execution_mode.value,
            "ingestion": {
                "type": self.ingestion.type.value,
                "output_format": self.ingestion.output_format,
            },
            "embedding": {
                "type": self.embedding.type.value,
                "model": self.embedding.model,
                "device": self.embedding.device,
            },
            "vectordb": {
                "type": self.vectordb.type.value,
                "storage_path": self.vectordb.storage_path,
                "collection_name": self.vectordb.collection_name,
            },
            "ranker": {
                "type": self.ranker.type.value,
                "enabled": self.ranker.enabled,
            },
            "generator": {
                "type": self.generator.type.value,
                "model": self.generator.model,
            },
            "persistence": {
                "enabled": self.persistence.enabled,
                "sync_enabled": self.persistence.sync_enabled,
            },
        }
    
    def save(self, path: str) -> None:
        """Save configuration to file."""
        data = self.to_dict()
        if path.endswith(".json"):
            with open(path, "w") as f:
                json.dump(data, f, indent=2)
        else:
            try:
                import yaml
                with open(path, "w") as f:
                    yaml.dump(data, f)
            except ImportError:
                raise ImportError("PyYAML required for YAML config.")


def get_default_config(mode: ExecutionMode = ExecutionMode.LOCAL) -> PipelineConfig:
    """Get default configuration for execution mode."""
    config = PipelineConfig(execution_mode=mode)
    
    if mode == ExecutionMode.AWS_HYBRID:
        config.vectordb.type = VectorDBType.QDRANT_CLOUD
        config.vectordb.storage_path = "./data/qdrant_cache"
        config.persistence.sync_enabled = True
        config.persistence.sync_backend = "s3"
        config.embedding.type = EmbeddingType.BGE_API
    
    elif mode == ExecutionMode.AWS_FULL:
        config.vectordb.type = VectorDBType.QDRANT_CLOUD
        config.embedding.type = EmbeddingType.BEDROCK
        config.generator.type = GeneratorType.BEDROCK
        config.persistence.sync_enabled = True
        config.persistence.sync_backend = "s3"
    
    return config
