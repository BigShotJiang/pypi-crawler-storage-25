"""RMS CLI for simple local systematic-review workflows.

This command-line entrypoint is designed for non-technical users and wrappers
(Apple app packaging, Windows .exe packaging) where a basic command is preferred.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, List, Optional

from rms import citation, filter_sort, search_count
from rms.literature_review_pipeline import LLMSettings, run_literature_review_pipeline


def _normalize_keywords_input(text: str) -> Dict[str, str]:
    words = [w.strip() for w in text.split(",") if w.strip()]
    if not words:
        return {"keywords_default": "research review analysis"}
    return {"keywords_default": " ".join(words)}


def _resolve_limit(row_count: int, requested_limit: Optional[int]) -> int:
    if requested_limit is None or requested_limit <= 0:
        return row_count
    return min(requested_limit, row_count)


def run_basic_pipeline(
    ris_dir: str,
    output_dir: str,
    required_citations: int | None = 200,
    keywords_json: str | None = None,
    keywords_text: str | None = None,
) -> Dict[str, str]:
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    citations_df = citation.Citations(ris_dir).get_dataframe().fillna("")

    if keywords_json:
        search_words_obj = search_count.SearchWords(keywords_json, "convert_string_to_lowercase")
    else:
        grouped = _normalize_keywords_input(keywords_text or "")
        search_words_obj = search_count.SearchWords(grouped, "convert_string_to_lowercase")

    citation_count_df = search_count.SearchCount(
        citations_df,
        search_words_obj,
        "convert_string_to_lowercase",
    ).get_dataframe()

    filtered_df = filter_sort.FilterSort(
        citation_count_df,
        search_words_obj,
        _resolve_limit(len(citation_count_df), required_citations),
    ).get_dataframe()

    citations_csv = output_path / "citations.csv"
    count_csv = output_path / "citations_keywords_count_df.csv"
    filtered_csv = output_path / "filter_sorted_citations_df.csv"

    citations_df.to_csv(citations_csv, index=False)
    citation_count_df.to_csv(count_csv, index=False)
    filtered_df.to_csv(filtered_csv, index=False)

    result = {
        "citations_csv": str(citations_csv),
        "count_csv": str(count_csv),
        "filtered_csv": str(filtered_csv),
        "citations": str(len(citations_df)),
        "filtered": str(len(filtered_df)),
    }

    return result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="rms",
        description="RMS CLI for simple local systematic-review execution.",
    )

    sub = parser.add_subparsers(dest="command", required=True)

    run_cmd = sub.add_parser("run-basic", help="Run basic citation pipeline locally")
    run_cmd.add_argument("--ris-dir", required=True, help="Directory containing RIS files")
    run_cmd.add_argument("--output-dir", default="outputs", help="Directory for CSV outputs")
    run_cmd.add_argument("--required-citations", type=int, default=None, help="Optional top N citations to keep")
    run_cmd.add_argument("--keywords-json", default=None, help="Optional search words JSON file path")
    run_cmd.add_argument(
        "--keywords-text",
        default=None,
        help="Optional comma-separated keywords if JSON is not provided",
    )

    review_cmd = sub.add_parser(
        "run-review",
        aliases=["run-review-demo"],
        help="Generate literature review matrix, shortlist, and PRISMA outputs",
    )
    review_cmd.add_argument("--ris-dir", default="data", help="Directory containing RIS file(s)")
    review_cmd.add_argument("--pdf-dir", default="data/mdpi", help="Directory containing downloaded PDFs")
    review_cmd.add_argument("--output-dir", default="outputs/literature_review", help="Directory for review outputs")
    review_cmd.add_argument("--provider", default="ollama", choices=["ollama", "qwen_local", "openai", "claude", "gemini"])
    review_cmd.add_argument("--model", default="qwen3:8b", help="LLM model name for the selected provider")
    review_cmd.add_argument("--api-key", default=None, help="Optional API key for cloud providers")
    review_cmd.add_argument("--base-url", default=None, help="Optional custom provider base URL")
    review_cmd.add_argument("--device", default="auto", choices=["auto", "mps", "cpu", "cuda"], help="Device for qwen_local execution")
    review_cmd.add_argument("--top-n", type=int, default=12, help="How many best papers to keep in the final shortlist")
    review_cmd.add_argument("--max-papers", type=int, default=None, help="Optional limit for a faster dry run")
    review_cmd.add_argument(
        "--llm-enrichment-limit",
        type=int,
        default=None,
        help="Optional limit for how many top-ranked papers receive full LLM extraction",
    )

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "run-basic":
        result = run_basic_pipeline(
            ris_dir=args.ris_dir,
            output_dir=args.output_dir,
            required_citations=args.required_citations,
            keywords_json=args.keywords_json,
            keywords_text=args.keywords_text,
        )
        print(json.dumps(result, indent=2))
    elif args.command in {"run-review", "run-review-demo"}:
        outputs = run_literature_review_pipeline(
            ris_parent_dir=args.ris_dir,
            pdf_dir=args.pdf_dir,
            output_dir=args.output_dir,
            llm_settings=LLMSettings(
                provider=args.provider,
                model=args.model,
                api_key=args.api_key,
                base_url=args.base_url,
                device=args.device,
            ),
            top_n=args.top_n,
            max_papers=args.max_papers,
            llm_enrichment_limit=args.llm_enrichment_limit,
        )
        print(
            json.dumps(
                {
                    "review_excel": str(outputs.review_excel),
                    "screened_csv": str(outputs.screened_csv),
                    "included_csv": str(outputs.included_csv),
                    "prisma_png": str(outputs.prisma_png),
                    "prisma_pdf": str(outputs.prisma_pdf),
                    "counts_json": str(outputs.counts_json),
                },
                indent=2,
            )
        )


if __name__ == "__main__":
    main()
