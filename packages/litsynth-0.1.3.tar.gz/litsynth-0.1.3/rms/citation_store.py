from __future__ import annotations

import hashlib
import importlib
import os
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Dict, List, Optional

SUPPORTED_CITATION_SUFFIXES = {".ris", ".bib", ".bibtex"}


@dataclass
class CitationRecord:
    citation_id: str
    title: str
    authors: List[str]
    year: str
    doi: str
    url: str
    publisher: str
    source_file: str
    raw: Dict


class CitationStore:
    """Authoritative citation store loaded only from RIS/BibTeX files."""

    def __init__(self) -> None:
        self.records: Dict[str, CitationRecord] = {}

    @staticmethod
    def _safe_str(value: Optional[object]) -> str:
        if value is None:
            return ""
        return str(value).strip()

    @staticmethod
    def _normalize_authors(raw_authors: object) -> List[str]:
        if raw_authors is None:
            return []
        if isinstance(raw_authors, list):
            return [str(a).strip() for a in raw_authors if str(a).strip()]
        text = str(raw_authors).strip()
        if not text:
            return []
        return [item.strip() for item in text.split(" and ") if item.strip()]

    @staticmethod
    def _build_citation_id(record: Dict) -> str:
        seed = "|".join(
            [
                str(record.get("title", "")).lower(),
                str(record.get("year", "")).lower(),
                str(record.get("doi", "")).lower(),
                "|".join([str(a).lower() for a in record.get("authors", [])]),
            ]
        )
        return hashlib.sha1(seed.encode("utf-8")).hexdigest()[:16]

    @staticmethod
    def _parse_bibtex_text(raw_text: str) -> List[Dict]:
        """
        Minimal BibTeX parser for common article/inproceedings entries.
        The parser intentionally extracts stable canonical fields only.
        """
        entries = []
        entry_pattern = re.compile(r"@\w+\s*\{[^@]*?\n\}", re.DOTALL)
        field_pattern = re.compile(r"(\w+)\s*=\s*[\{\"](.*?)[\}\"],?\s*$", re.MULTILINE)

        for match in entry_pattern.finditer(raw_text):
            block = match.group(0)
            fields = {}
            for field_name, field_value in field_pattern.findall(block):
                fields[field_name.lower()] = field_value.strip()
            entries.append(fields)

        return entries

    def _dedupe_and_store(self, parsed_records: List[Dict], source_file: str) -> Dict[str, int]:
        loaded = 0
        duplicates = 0

        for raw in parsed_records:
            canonical = {
                "title": self._safe_str(raw.get("title") or raw.get("primary_title")),
                "authors": self._normalize_authors(raw.get("authors") or raw.get("author")),
                "year": self._safe_str(raw.get("year") or raw.get("publication_year")),
                "doi": self._safe_str(raw.get("doi")),
                "url": self._safe_str(raw.get("url")),
                "publisher": self._safe_str(raw.get("publisher") or raw.get("publication_name")),
            }

            citation_id = self._build_citation_id(canonical)
            if citation_id in self.records:
                duplicates += 1
                continue

            self.records[citation_id] = CitationRecord(
                citation_id=citation_id,
                title=canonical["title"],
                authors=canonical["authors"],
                year=canonical["year"],
                doi=canonical["doi"],
                url=canonical["url"],
                publisher=canonical["publisher"],
                source_file=source_file,
                raw=raw,
            )
            loaded += 1

        return {"loaded": loaded, "duplicates": duplicates, "total": len(self.records)}

    def load(self, citation_file_path: str) -> Dict[str, int]:
        suffix = os.path.splitext(citation_file_path)[1].lower()
        if suffix not in SUPPORTED_CITATION_SUFFIXES:
            raise ValueError(
                "Unsupported citation file format. Use only .ris, .bib, or .bibtex."
            )

        if suffix == ".ris":
            try:
                rispy = importlib.import_module("rispy")
            except ImportError as exc:
                raise ImportError(
                    "rispy is required to load RIS files. Install with: pip install rispy"
                ) from exc
            with open(citation_file_path, "r", encoding="utf-8") as handle:
                parsed_records = rispy.load(handle)
        else:
            with open(citation_file_path, "r", encoding="utf-8") as handle:
                parsed_records = self._parse_bibtex_text(handle.read())

        return self._dedupe_and_store(parsed_records, citation_file_path)

    def get(self, citation_id: str) -> CitationRecord:
        if citation_id not in self.records:
            raise KeyError(f"Unknown citation_id: {citation_id}")
        return self.records[citation_id]

    def list_records(self) -> List[Dict]:
        return [
            {
                "citation_id": rec.citation_id,
                "title": rec.title,
                "authors": rec.authors,
                "year": rec.year,
                "doi": rec.doi,
                "url": rec.url,
                "publisher": rec.publisher,
                "source_file": rec.source_file,
            }
            for rec in self.records.values()
        ]

    @staticmethod
    def now_utc_iso() -> str:
        return datetime.now(timezone.utc).isoformat()
