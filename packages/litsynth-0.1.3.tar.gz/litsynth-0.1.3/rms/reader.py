

import os
from io import BytesIO

try:
    import boto3
except ImportError:  # pragma: no cover - optional cloud dependency
    boto3 = None

from rms.pdf_handler import PDFHandler

class DocumentHandler:
    """Handles document reading operations from S3 or local disk."""
    def __init__(self, document_path):
        self.path = document_path
        self.s3_bucket = "research-manager-system-data"
        self.s3_client = boto3.client('s3') if boto3 is not None else None

    def read(self):
        if self.s3_client is None or os.path.exists(self.path):
            if not self.path.endswith(".pdf"):
                raise NotImplementedError("File is not a PDF")
            return PDFHandler(self.path).read()

        # Check if file exists in S3
        try:
            # Use head_object to check if file exists without downloading content
            self.s3_client.head_object(Bucket=self.s3_bucket, Key=self.path)
            print("Reading document from S3: {}".format(self.path))
            
            if self.path.endswith(".pdf"):
                # Download PDF from S3
                response = self.s3_client.get_object(Bucket=self.s3_bucket, Key=self.path)
                pdf_content = BytesIO(response['Body'].read())
                
                # Create a temporary file to work with PDFHandler
                temp_path = '/tmp/' + os.path.basename(self.path)
                with open(temp_path, 'wb') as temp_file:
                    temp_file.write(pdf_content.getvalue())
                
                # Process the PDF using existing PDFHandler
                text, meta_data = PDFHandler(temp_path).read()
                
                # Clean up temporary file
                os.remove(temp_path)
                
                return text, meta_data
            else:
                raise NotImplementedError("File is not a PDF")
        except self.s3_client.exceptions.ClientError as e:
            if e.response['Error']['Code'] == '404':
                print("File does not exist in S3 bucket")
            else:
                print(f"Error accessing S3: {e}")


