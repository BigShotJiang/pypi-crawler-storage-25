
import os
from openai import OpenAI


class LLMManager:
    """Manages LLM operations and chunk retrieval"""
    def __init__(self):
        self.model = None
        self.chatgpt = None

    def _get_local_model(self):
        if self.model is None:
            self.model = FlanT5Generator()
        return self.model

    def _get_chatgpt(self):
        if self.chatgpt is None:
            self.chatgpt = ChatGPTGenerator()
        return self.chatgpt

    def ask(self, query: str, chunks):
        """Find best chunk based on LLM response"""

        combined_text = " ".join(chunks)
        prompt = f"Question: {query}\nContext: {combined_text}\nAnswer:"

        answer = self._get_local_model().generate(prompt)
        return answer

    def chat(self, query: str):
        self._get_local_model().chat(query)

    def ask_chatgpt(self, query: str):
        answer = self._get_chatgpt().generate(query)
        return answer

class ChatGPTGenerator:
    def __init__(self):
        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY is required to use ChatGPTGenerator.")
        self.client = OpenAI(
            api_key=api_key
        )

    def generate(self, query):

        completion = self.client.chat.completions.create(
            model="gpt-4o-mini",
            store=True,
            messages=[
                {"role": "user", "content": f"{query}"},
            ]
        )

        return completion


class FlanT5Generator:
    chat_history = []
    def __init__(self, model_path="./models--google--flan-t5-base"):
        from transformers import T5Tokenizer, T5ForConditionalGeneration
        import torch
        self.model_name = "google/flan-t5-base"
        print(f"initializing {self.model_name}")
        # Set device to MPS if available, otherwise fall back to CPU
        self.device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")
        print(f"Initializing FlanT5 model on {self.device}...")

        # Load model and tokenizer
        self.model = T5ForConditionalGeneration.from_pretrained(
            model_path,
            local_files_only=True
        ).to(self.device)
        self.tokenizer = T5Tokenizer.from_pretrained(
            model_path,
            local_files_only=True
        )

        # Default generation parameters
        self.default_params = {
            "max_length": 200,
            "num_beams": 5,
            "do_sample":True,
            "no_repeat_ngram_size": 2,
            "temperature": 0.7,
            "top_k": 50,
            "top_p": 0.95,
        }
        print("Model initialized successfully!")

    def generate(self, query, **kwargs):
        try:
            # Merge default parameters with any provided kwargs
            generation_params = {**self.default_params, **kwargs}

            # Tokenize the input text
            inputs = self.tokenizer(
                query,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=512
            ).to(self.device)

            # Generate the output text
            outputs = self.model.generate(
                inputs["input_ids"],
                **generation_params
            )

            # Move outputs to CPU before decoding
            outputs = outputs.to("cpu")

            # Decode the generated tokens
            generated_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
            return generated_text

        except Exception as e:
            print(f"Error during generation: {str(e)}")
            return None

    def update_default_params(self, **kwargs):
        """Update default generation parameters"""
        self.default_params.update(kwargs)

    def save_model_locally(self, local_path = "./models--google--flan-t5-base"):
        # Define the model name and local path

        print(f"Downloading and saving model from {self.model_name}...")

        # Create directory if it doesn't exist
        os.makedirs(local_path, exist_ok=True)

        # Download and save model
        model = T5ForConditionalGeneration.from_pretrained(self.model_name)
        tokenizer = T5Tokenizer.from_pretrained(self.model_name)

        # Save model and tokenizer
        model.save_pretrained(local_path)
        tokenizer.save_pretrained(local_path)

        print(f"Model and tokenizer saved successfully to {local_path}")
        return local_path

    def chat(self, user_input):

        # Limit chat history to last 1024 tokens (half the model limit)
        chat_history = self.chat_history[-6:]  # Keep only the last 6 turns

        # Construct the formatted prompt
        conversation = "\n".join(chat_history + [f"User: {user_input}", "Assistant:"])

        # Generate a response with controlled token output
        response = self.generate(conversation,
            max_new_tokens=150,  # Generate up to 150 tokens
            temperature=0.7,  # Makes responses more natural and varied
            pad_token_id=50256  # Avoids weird padding issues
        )

        # Extract the model's response (remove repeated input)
        model_reply = response.split("Assistant:")[-1].strip()

        # Avoid repetition & junk text
        if model_reply.startswith("User:"):
            model_reply = model_reply.split("User:")[0].strip()

        # Update chat history
        chat_history.append(f"User: {user_input}")
        chat_history.append(f"Assistant: {model_reply}")

        return model_reply





