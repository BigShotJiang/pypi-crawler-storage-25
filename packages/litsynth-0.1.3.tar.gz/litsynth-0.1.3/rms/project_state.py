from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path


def _slugify(value: str) -> str:
    lowered = re.sub(r"[^a-zA-Z0-9]+", "-", value.strip().lower())
    return lowered.strip("-") or "research-project"


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class ProjectState:
    name: str
    project_root: str
    project_file: str
    citations_dir: str
    pdf_dir: str
    inaccessible_path: str
    search_words_json: str
    llm_output_dir: str
    draft_path: str
    notes_path: str
    created_at: str
    updated_at: str

    @classmethod
    def create_new(cls, base_dir: str, project_name: str) -> "ProjectState":
        slug = _slugify(project_name)
        root = Path(base_dir).expanduser().resolve() / slug
        citations_dir = root / "citations"
        pdf_dir = root / "papers"
        outputs_dir = root / "outputs"
        notes_dir = root / "notes"

        citations_dir.mkdir(parents=True, exist_ok=True)
        pdf_dir.mkdir(parents=True, exist_ok=True)
        outputs_dir.mkdir(parents=True, exist_ok=True)
        notes_dir.mkdir(parents=True, exist_ok=True)

        timestamp = _utc_now()
        state = cls(
            name=project_name.strip() or "Research Project",
            project_root=str(root),
            project_file=str(root / "project.json"),
            citations_dir=str(citations_dir),
            pdf_dir=str(pdf_dir),
            inaccessible_path=str(root / "not_accessible_articles.txt"),
            search_words_json=str(root / "search_words.json"),
            llm_output_dir=str(outputs_dir / "literature_review"),
            draft_path=str(notes_dir / "research_paper_draft.md"),
            notes_path=str(notes_dir / "copilot_notes.md"),
            created_at=timestamp,
            updated_at=timestamp,
        )
        state.save()
        return state

    @classmethod
    def load(cls, project_file: str) -> "ProjectState":
        path = Path(project_file).expanduser().resolve()
        payload = json.loads(path.read_text(encoding="utf-8"))
        return cls(**payload)

    def save(self) -> Path:
        self.updated_at = _utc_now()
        path = Path(self.project_file).expanduser().resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")
        return path