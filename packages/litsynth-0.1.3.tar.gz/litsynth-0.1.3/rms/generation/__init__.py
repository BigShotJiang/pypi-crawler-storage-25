from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional


@dataclass
class GenerationResponse:
    """Response from language model."""
    text: str
    model: str
    tokens_used: Optional[int] = None
    stop_reason: Optional[str] = None


class GeneratorBase(ABC):
    """Base class for text generation models."""

    @abstractmethod
    def generate(
        self,
        prompt: str,
        max_tokens: int = 500,
        temperature: float = 0.7,
        **kwargs,
    ) -> GenerationResponse:
        """
        Generate text from prompt.
        
        Args:
            prompt: Input prompt
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            **kwargs: Model-specific parameters
            
        Returns:
            GenerationResponse
        """
        pass

    @abstractmethod
    def stream_generate(
        self,
        prompt: str,
        max_tokens: int = 500,
        temperature: float = 0.7,
        **kwargs,
    ):
        """Stream generated text tokens."""
        pass

    @property
    @abstractmethod
    def model_name(self) -> str:
        """Return model identifier."""
        pass

    @property
    @abstractmethod
    def supports_streaming(self) -> bool:
        """Whether model supports streaming."""
        pass
