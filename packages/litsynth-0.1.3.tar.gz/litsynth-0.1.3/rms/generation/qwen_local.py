"""Qwen local language model for text generation."""

from typing import Optional
from rms.generation import GeneratorBase, GenerationResponse


class QwenLocalGenerator(GeneratorBase):
    """
    Qwen open-source model running locally.
    
    Supports multiple sizes:
    - Qwen-7B: Fast, good quality, ~14GB
    - Qwen-14B: Better quality, ~28GB
    - Qwen-72B: Best quality, ~150GB
    
    Privacy-preserving, zero API costs.
    """

    def __init__(
        self,
        model_name: str = "Qwen/Qwen-7B-Chat",
        device: str = "auto",
        load_in_4bit: bool = False,
    ):
        """
        Initialize Qwen generator.
        
        Args:
            model_name: HuggingFace model identifier
            device: "auto", "cuda", "cpu"
            load_in_4bit: Use 4-bit quantization for memory efficiency
        """
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer
            import torch
        except ImportError:
            raise ImportError(
                "transformers and torch not installed. "
                "Install with: pip install transformers torch"
            )

        self._model_name = model_name

        # Select device
        if device == "auto":
            if torch.cuda.is_available():
                self.device = "cuda"
            elif getattr(torch.backends, "mps", None) is not None and torch.backends.mps.is_available():
                self.device = "mps"
            else:
                self.device = "cpu"
        else:
            self.device = device

        print(f"Loading {model_name} on {self.device}...")

        # Determine if this is a chat model
        self.is_chat_model = "Chat" in model_name

        # Load tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(
            model_name,
            trust_remote_code=True,
        )

        # Load model
        model_kwargs = {
            "trust_remote_code": True,
        }

        if self.device == "cuda":
            model_kwargs["torch_dtype"] = torch.float16
        elif self.device == "mps":
            model_kwargs["torch_dtype"] = torch.float16
        else:
            model_kwargs["torch_dtype"] = torch.float32

        if load_in_4bit and self.device == "cuda":
            self.model = AutoModelForCausalLM.from_pretrained(
                model_name,
                device_map="auto",
                load_in_4bit=True,
                **model_kwargs,
            )
        else:
            self.model = AutoModelForCausalLM.from_pretrained(
                model_name,
                **model_kwargs,
            )
            self.model.to(self.device)

        self.model.eval()
        print(f"Model loaded successfully.")

    def generate(
        self,
        prompt: str,
        max_tokens: int = 500,
        temperature: float = 0.7,
        **kwargs,
    ) -> GenerationResponse:
        """Generate text from prompt."""
        try:
            import torch
        except ImportError:
            raise ImportError("torch is required")

        with torch.no_grad():
            if self.is_chat_model:
                # Use chat format
                messages = [{"role": "user", "content": prompt}]
                text = self.tokenizer.apply_chat_template(
                    messages,
                    tokenize=False,
                    add_generation_prompt=True,
                )
            else:
                text = prompt

            # Tokenize
            inputs = self.tokenizer(
                text,
                return_tensors="pt",
                truncation=True,
                max_length=2048,
            ).to(self.device)

            # Generate
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=max_tokens,
                temperature=temperature,
                top_p=0.9,
                do_sample=True,
            )

            # Decode
            generated_text = self.tokenizer.decode(
                outputs[0],
                skip_special_tokens=True,
            )

            return GenerationResponse(
                text=generated_text,
                model=self._model_name,
                tokens_used=outputs.shape[1],
            )

    def stream_generate(
        self,
        prompt: str,
        max_tokens: int = 500,
        temperature: float = 0.7,
        **kwargs,
    ):
        """Stream generated text (not implemented yet)."""
        raise NotImplementedError(
            "Streaming not yet supported for local Qwen model. "
            "Use standard generate() instead."
        )

    @property
    def model_name(self) -> str:
        """Return model name."""
        return self._model_name

    @property
    def supports_streaming(self) -> bool:
        """Local Qwen doesn't support streaming yet."""
        return False
