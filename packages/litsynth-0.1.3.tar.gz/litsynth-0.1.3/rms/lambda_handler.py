from rms.orchestrator import Backend

def handler(event, context):
    # Extract action and input data from event
    action = event.get("queryStringParameters", {}).get("action", "read")  # Default to 'read'
    input_data = event.get("queryStringParameters", {}).get("data", "default")

    # Initialize PDFHandler with input data
    pdf_handler = Backend(input_data)

    # Route based on action using if-else
    if action == "read":
        result = pdf_handler.read()
    elif action == "write":
        result = pdf_handler.write()
    elif action == "process":
        result = pdf_handler.process()
    else:
        result = f"Error: Unknown action '{action}'"

    # Return response
    return {
        "statusCode": 200,
        "body": result,
        "headers": {"Content-Type": "text/plain"}
    }
