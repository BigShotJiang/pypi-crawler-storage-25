"""End-to-end literature review extraction and PRISMA export pipeline."""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional

import pandas as pd
import requests

from rms import analysis
from rms.citation import Citations
from rms.pdf_handler import PDFHandler
from rms.string_manipulation import preprocess_string


REVIEW_COLUMNS = [
    "Main Topic",
    "Sub Topic",
    "Article Name",
    "Aim of the Study(objectives)",
    "Industry types",
    "Data Source",
    "Data Timings",
    "Input Variables",
    "method to write the paper",
    "machine learning algorithms, Quantitative techniques, optimization techniques",
    "Comparison with",
    "Top Performer",
    "Findings",
    "Research Gap/ Limitations",
    "Conclusions",
    "Performance Metrics",
    "Best Areas in Paper",
    "Region where Research is Conducted",
    "Publication Year",
    "Notes, Special Considerations\n",
    "Publication Source",
    "Email ID",
    "Citation",
]


EXTRA_COLUMNS = [
    "pdf_file",
    "pdf_matched",
    "title_match_score",
    "screening_score",
    "eligibility_status",
    "selection_rank",
]


DEFAULT_SCREENING_KEYWORDS = {
    "core_topic": [
        "stock",
        "market",
        "price",
        "forecast",
        "prediction",
        "trading",
        "portfolio",
        "volatility",
        "return",
        "financial",
        "cryptocurr",
        "fx",
    ],
    "method_signal": [
        "machine learning",
        "deep learning",
        "neural",
        "svm",
        "support vector",
        "random forest",
        "lstm",
        "transformer",
        "fuzzy",
        "optimization",
        "reinforcement learning",
        "time series",
        "sentiment",
    ],
    "evaluation_signal": [
        "accuracy",
        "rmse",
        "mae",
        "mape",
        "precision",
        "recall",
        "f1",
        "performance",
        "benchmark",
        "compare",
        "baseline",
    ],
}


FIELD_INSTRUCTIONS = {
    "Main Topic": "Primary research theme in 3-8 words.",
    "Sub Topic": "More specific niche or application in 3-10 words.",
    "Aim of the Study(objectives)": "Study objective(s) in 1-3 sentences.",
    "Industry types": "Industry or asset class studied.",
    "Data Source": "Named datasets, exchanges, APIs, reports, social sources, or stated source.",
    "Data Timings": "Time period, frequency, or years covered.",
    "Input Variables": "Key predictors, features, covariates, or signals.",
    "method to write the paper": "Research design or paper method such as empirical analysis, modeling, experiment, review.",
    "machine learning algorithms, Quantitative techniques, optimization techniques": "Algorithms, models, statistical methods, and optimizers mentioned.",
    "Comparison with": "Baselines or comparator methods.",
    "Top Performer": "Best performing method or model if explicitly stated.",
    "Findings": "Main findings in 1-3 sentences.",
    "Research Gap/ Limitations": "Stated limitations, open issues, or evidence gaps.",
    "Conclusions": "Conclusion summary in 1-2 sentences.",
    "Performance Metrics": "Metrics used such as RMSE, MAE, accuracy.",
    "Best Areas in Paper": "Strongest section or contribution area worth highlighting.",
    "Region where Research is Conducted": "Country, market, exchange, or geography if stated.",
    "Notes, Special Considerations\n": "Extra notes, caveats, or deployment relevance.",
}


PROMPT_FIELDS = [key for key in FIELD_INSTRUCTIONS.keys()]


@dataclass
class LLMSettings:
    provider: str = "ollama"
    model: str = "qwen3:8b"
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    device: str = "auto"
    temperature: float = 0.1
    max_tokens: int = 1200


@dataclass
class PipelineOutputs:
    review_excel: Path
    screened_csv: Path
    included_csv: Path
    prisma_png: Path
    prisma_pdf: Path
    counts_json: Path


@dataclass
class CandidatePaper:
    record: pd.Series
    pdf_context: Dict[str, str]
    row: Dict[str, Any]


class ReviewLLMClient:
    def __init__(self, settings: LLMSettings):
        self.settings = settings
        self._generator = None

    def generate_json(self, prompt: str) -> Dict[str, str]:
        provider = self.settings.provider.lower()
        if provider == "ollama":
            raw = self._call_ollama(prompt)
        elif provider == "qwen_local":
            raw = self._call_qwen_local(prompt)
        elif provider == "openai":
            raw = self._call_openai(prompt)
        elif provider == "claude":
            raw = self._call_claude(prompt)
        elif provider == "gemini":
            raw = self._call_gemini(prompt)
        else:
            raise ValueError(f"Unsupported provider: {self.settings.provider}")

        return self._coerce_json(raw)

    def _call_ollama(self, prompt: str) -> str:
        base_url = self.settings.base_url or os.environ.get("OLLAMA_BASE_URL", "http://127.0.0.1:11434")
        response = requests.post(
            f"{base_url.rstrip('/')}/api/generate",
            json={
                "model": self.settings.model,
                "prompt": prompt,
                "stream": False,
                "format": "json",
                "options": {
                    "temperature": self.settings.temperature,
                },
            },
            timeout=180,
        )
        response.raise_for_status()
        return response.json().get("response", "{}")

    def _call_qwen_local(self, prompt: str) -> str:
        if self._generator is None:
            from rms.generation.qwen_local import QwenLocalGenerator

            self._generator = QwenLocalGenerator(
                model_name=self.settings.model,
                device=self.settings.device,
            )

        response = self._generator.generate(
            prompt,
            max_tokens=self.settings.max_tokens,
            temperature=self.settings.temperature,
        )
        return response.text

    def _call_openai(self, prompt: str) -> str:
        api_key = self.settings.api_key or os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY is required for provider=openai")
        response = requests.post(
            (self.settings.base_url or "https://api.openai.com/v1") + "/chat/completions",
            headers={"Authorization": f"Bearer {api_key}"},
            json={
                "model": self.settings.model,
                "temperature": self.settings.temperature,
                "max_tokens": self.settings.max_tokens,
                "response_format": {"type": "json_object"},
                "messages": [
                    {"role": "system", "content": "Return only valid JSON."},
                    {"role": "user", "content": prompt},
                ],
            },
            timeout=180,
        )
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]

    def _call_claude(self, prompt: str) -> str:
        api_key = self.settings.api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            raise ValueError("ANTHROPIC_API_KEY is required for provider=claude")
        response = requests.post(
            self.settings.base_url or "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": self.settings.model,
                "max_tokens": self.settings.max_tokens,
                "temperature": self.settings.temperature,
                "system": "Return only valid JSON.",
                "messages": [{"role": "user", "content": prompt}],
            },
            timeout=180,
        )
        response.raise_for_status()
        content = response.json().get("content", [])
        return "".join(block.get("text", "") for block in content if block.get("type") == "text")

    def _call_gemini(self, prompt: str) -> str:
        api_key = self.settings.api_key or os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY or GOOGLE_API_KEY is required for provider=gemini")
        model = self.settings.model or "gemini-2.0-flash"
        endpoint = self.settings.base_url or (
            f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
        )
        response = requests.post(
            f"{endpoint}?key={api_key}",
            headers={"content-type": "application/json"},
            json={
                "generationConfig": {
                    "temperature": self.settings.temperature,
                    "responseMimeType": "application/json",
                    "maxOutputTokens": self.settings.max_tokens,
                },
                "contents": [{"parts": [{"text": prompt}]}],
            },
            timeout=180,
        )
        response.raise_for_status()
        candidates = response.json().get("candidates", [])
        parts = candidates[0].get("content", {}).get("parts", []) if candidates else []
        return "".join(part.get("text", "") for part in parts)

    @staticmethod
    def _coerce_json(raw: str) -> Dict[str, str]:
        text = raw.strip()
        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?", "", text).strip()
            text = re.sub(r"```$", "", text).strip()

        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1:
            text = text[start:end + 1]

        data = json.loads(text or "{}")
        return {str(key): _stringify_value(value) for key, value in data.items()}


def _stringify_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        return "; ".join(_stringify_value(item) for item in value if _stringify_value(item))
    if isinstance(value, dict):
        return "; ".join(f"{k}: {_stringify_value(v)}" for k, v in value.items() if _stringify_value(v))
    return str(value).strip()


def _first_non_empty(values: Iterable[Any]) -> str:
    for value in values:
        text = _stringify_value(value)
        if text:
            return text
    return ""


def _normalize_title(text: str) -> str:
    return preprocess_string(text or "")


def _email_from_text(text: str) -> str:
    emails = re.findall(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", text)
    unique = []
    for email in emails:
        if email not in unique:
            unique.append(email)
    return "; ".join(unique)


def _join_keywords(record: pd.Series) -> str:
    value = record.get("keywords")
    if isinstance(value, list):
        return "; ".join(str(item) for item in value if str(item).strip())
    return _stringify_value(value)


def _resolve_pdf_matches(citations_df: pd.DataFrame, pdf_dir: Path) -> pd.DataFrame:
    pdf_records = []
    for pdf_path in sorted(pdf_dir.glob("*.pdf")):
        normalized = _normalize_title(pdf_path.stem)
        pdf_records.append({"pdf_path": pdf_path, "pdf_title": normalized})

    pdf_index = {item["pdf_title"]: item["pdf_path"] for item in pdf_records}

    matched_paths = []
    matched_scores = []
    for cleaned_title in citations_df["cleaned_title"].fillna(""):
        if cleaned_title in pdf_index:
            matched_paths.append(str(pdf_index[cleaned_title]))
            matched_scores.append(1.0)
            continue

        best_path = None
        best_score = 0.0
        for item in pdf_records:
            score = SequenceMatcher(None, cleaned_title, item["pdf_title"]).ratio()
            if score > best_score:
                best_score = score
                best_path = item["pdf_path"]

        if best_path is not None and best_score >= 0.8:
            matched_paths.append(str(best_path))
            matched_scores.append(round(best_score, 4))
        else:
            matched_paths.append("")
            matched_scores.append(round(best_score, 4))

    output = citations_df.copy()
    output["pdf_file"] = matched_paths
    output["pdf_matched"] = output["pdf_file"].astype(bool)
    output["title_match_score"] = matched_scores
    return output


def _extract_pdf_context(pdf_path: Path, max_chars: int = 14000) -> Dict[str, str]:
    text, meta = PDFHandler(str(pdf_path)).read()
    cleaned = re.sub(r"\s+", " ", text).strip()
    return {
        "text": cleaned[:max_chars],
        "full_text_length": str(len(cleaned)),
        "pages": str(meta.get("total_pages", "")),
        "email": _email_from_text(cleaned[:20000]),
    }


def _screening_score(record: pd.Series, extracted_text: str) -> int:
    haystack = " ".join(
        [
            _stringify_value(record.get("title")),
            _stringify_value(record.get("abstract")),
            extracted_text,
            _join_keywords(record),
        ]
    ).lower()

    score = 0
    for keyword in DEFAULT_SCREENING_KEYWORDS["core_topic"]:
        if keyword in haystack:
            score += 3
    for keyword in DEFAULT_SCREENING_KEYWORDS["method_signal"]:
        if keyword in haystack:
            score += 2
    for keyword in DEFAULT_SCREENING_KEYWORDS["evaluation_signal"]:
        if keyword in haystack:
            score += 1

    if record.get("pdf_matched"):
        score += 5
    if _stringify_value(record.get("abstract")):
        score += 2
    return score


def _prompt_for_record(record: pd.Series, pdf_excerpt: str) -> str:
    schema = {field: FIELD_INSTRUCTIONS[field] for field in PROMPT_FIELDS}
    payload = {
        "title": _stringify_value(record.get("title")),
        "abstract": _stringify_value(record.get("abstract")),
        "keywords": _join_keywords(record),
        "publication_source": _first_non_empty([record.get("secondary_title"), record.get("source")]),
        "publication_year": _stringify_value(record.get("year")),
        "citation_text": _stringify_value(record.get("citation_text")),
        "pdf_excerpt": pdf_excerpt,
    }
    return (
        "You are extracting structured literature review fields from a finance research paper. "
        "Use only the supplied metadata and paper excerpt. If a field is not stated, return an empty string. "
        "Do not invent citations or facts. Return only a JSON object with exactly these keys and string values.\n\n"
        f"Field instructions:\n{json.dumps(schema, indent=2)}\n\n"
        f"Paper payload:\n{json.dumps(payload, indent=2)}"
    )


def _row_from_record(record: pd.Series, llm_data: Dict[str, str], pdf_context: Dict[str, str]) -> Dict[str, Any]:
    row = {column: "" for column in REVIEW_COLUMNS + EXTRA_COLUMNS}
    row["Article Name"] = _stringify_value(record.get("title"))
    row["Publication Year"] = _stringify_value(record.get("year"))
    row["Publication Source"] = _first_non_empty([record.get("secondary_title"), record.get("source")])
    row["Citation"] = _stringify_value(record.get("citation_text"))
    row["Email ID"] = pdf_context.get("email", "")

    for column in PROMPT_FIELDS:
        row[column] = llm_data.get(column, "")

    row["pdf_file"] = _stringify_value(record.get("pdf_file"))
    row["pdf_matched"] = bool(record.get("pdf_matched"))
    row["title_match_score"] = record.get("title_match_score", 0)
    return row


def _infer_main_topic(record: pd.Series) -> str:
    haystack = " ".join([
        _stringify_value(record.get("title")),
        _stringify_value(record.get("abstract")),
        _join_keywords(record),
    ]).lower()
    if "crypto" in haystack:
        return "Cryptocurrency Forecasting"
    if "volatility" in haystack:
        return "Volatility Forecasting"
    if "portfolio" in haystack or "trading" in haystack:
        return "Quantitative Trading"
    return "Stock Market Forecasting"


def _infer_sub_topic(record: pd.Series) -> str:
    title = _stringify_value(record.get("title")).lower()
    if "sentiment" in title:
        return "Sentiment-driven price prediction"
    if "lstm" in title or "neural" in title or "deep" in title:
        return "Deep learning prediction"
    if "fuzzy" in title:
        return "Fuzzy time-series modeling"
    if "random forest" in title:
        return "Tree-based forecasting"
    if "volatility" in title:
        return "Volatility estimation"
    return "Financial time-series modeling"


def _extract_methods_text(record: pd.Series) -> str:
    haystack = " ".join([
        _stringify_value(record.get("title")),
        _stringify_value(record.get("abstract")),
        _join_keywords(record),
    ]).lower()
    methods = []
    method_map = {
        "lstm": "LSTM",
        "deep neural": "Deep neural networks",
        "neural network": "Neural networks",
        "random forest": "Random Forest",
        "support vector": "Support Vector Machine",
        "svm": "Support Vector Machine",
        "extreme learning machine": "Extreme Learning Machine",
        "reinforcement learning": "Reinforcement Learning",
        "fuzzy": "Fuzzy logic / fuzzy time series",
        "particle swarm": "Particle Swarm Optimization",
        "wavelet": "Wavelet transform",
        "sentiment": "Sentiment analysis",
        "autoregressive moving average": "ARMA / ARIMA-family modeling",
    }
    for needle, label in method_map.items():
        if needle in haystack and label not in methods:
            methods.append(label)
    return "; ".join(methods)


def _apply_heuristic_defaults(row: Dict[str, Any], record: pd.Series, pdf_context: Dict[str, str]) -> Dict[str, Any]:
    row["Main Topic"] = row["Main Topic"] or _infer_main_topic(record)
    row["Sub Topic"] = row["Sub Topic"] or _infer_sub_topic(record)
    row["Industry types"] = row["Industry types"] or "Financial markets"
    row["method to write the paper"] = row["method to write the paper"] or "Empirical modeling study"
    row["machine learning algorithms, Quantitative techniques, optimization techniques"] = (
        row["machine learning algorithms, Quantitative techniques, optimization techniques"]
        or _extract_methods_text(record)
    )
    row["Data Source"] = row["Data Source"] or row["Publication Source"]
    if not row["Notes, Special Considerations\n"]:
        pages = pdf_context.get("pages", "")
        if pages:
            row["Notes, Special Considerations\n"] = f"Matched local PDF with {pages} pages for extraction."
    return row


def _review_dataframe_base(citations_df: pd.DataFrame) -> pd.DataFrame:
    base = analysis.creating_sample_review_file(citations_df.copy())
    for column in REVIEW_COLUMNS + EXTRA_COLUMNS:
        if column not in base.columns:
            base[column] = ""
    return base


def _build_prisma_outputs(
    citations_dir: Path,
    screened_df: pd.DataFrame,
    eligible_df: pd.DataFrame,
    included_df: pd.DataFrame,
    output_dir: Path,
) -> Dict[str, Any]:
    validated_df = screened_df[["pdf_file"]].copy()
    validated_df["downloaded"] = screened_df["pdf_matched"].map({True: "yes", False: "no"})

    info = analysis.SystematicReviewInfo(
        citations_files_parent_folder_path=str(citations_dir),
        filter_sorted_citations_df=screened_df,
        validated_research_papers_df=validated_df,
        selected_research_papers_df=eligible_df,
    )
    info.manually_excluded = f"Excluded after full-text review\n(n = {max(len(eligible_df) - len(included_df), 0)})"
    info.manually_excluded_reasons = "Reasons: low screening score or insufficient methodological detail"
    info.included = len(included_df)

    png_path = output_dir / "prisma_pipeline.png"
    pdf_path = output_dir / "prisma_pipeline.pdf"
    info.systematic_review_diagram(diagram_fname=str(png_path), dpi=300, bbox_inches="tight")
    info.systematic_review_diagram(diagram_fname=str(pdf_path), bbox_inches="tight")

    counts = {
        "identified_total": info.sources["total"],
        "duplicates_removed": info.duplicates,
        "screened": info.screened,
        "screened_out": info.screened_out,
        "full_text_sought": info.for_retrieval,
        "full_text_not_retrieved": info.not_retrieved,
        "eligible": info.eligible,
        "included": info.included,
    }
    return {"png": png_path, "pdf": pdf_path, "counts": counts}


def run_literature_review_pipeline(
    ris_parent_dir: str,
    pdf_dir: str,
    output_dir: str,
    llm_settings: Optional[LLMSettings] = None,
    top_n: int = 12,
    max_papers: Optional[int] = None,
    llm_enrichment_limit: Optional[int] = None,
    progress_callback: Optional[Callable[[str], None]] = None,
) -> PipelineOutputs:
    def log(message: str) -> None:
        if progress_callback is not None:
            progress_callback(message)

    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    log("Loading RIS citations...")
    citations_df = Citations(ris_parent_dir).get_dataframe()
    log(f"Loaded {len(citations_df)} citations. Resolving local PDF matches...")
    matched_df = _resolve_pdf_matches(citations_df, Path(pdf_dir))
    matched_df = matched_df.sort_values(["pdf_matched", "title_match_score"], ascending=[False, False]).reset_index(drop=True)
    matched_pdf_count = int(matched_df["pdf_matched"].sum())
    log(f"Matched {matched_pdf_count} citations to local PDFs.")

    candidate_df = matched_df.loc[matched_df["pdf_matched"]].copy()
    if candidate_df.empty:
        raise ValueError(
            f"No research paper PDFs matched the RIS citations in {pdf_dir}. Add at least one matching PDF before generating the matrix."
        )

    if max_papers:
        candidate_df = candidate_df.head(max_papers).copy()
        log(f"Limiting the run to the first {len(candidate_df)} matched papers.")

    llm_client = ReviewLLMClient(llm_settings or LLMSettings())
    prepared_candidates: List[CandidatePaper] = []
    log(f"Preparing {len(candidate_df)} candidate papers for review matrix generation...")

    for index, (_, record) in enumerate(candidate_df.iterrows(), start=1):
        pdf_context = {"text": "", "full_text_length": "0", "pages": "", "email": ""}
        if _stringify_value(record.get("pdf_file")):
            pdf_context = _extract_pdf_context(Path(str(record.get("pdf_file"))))
        row = _row_from_record(record, {field: "" for field in PROMPT_FIELDS}, pdf_context)
        row = _apply_heuristic_defaults(row, record, pdf_context)
        row["screening_score"] = _screening_score(record, pdf_context["text"])
        row["eligibility_status"] = "eligible" if row["pdf_matched"] and row["screening_score"] >= 12 else "excluded"
        prepared_candidates.append(CandidatePaper(record=record, pdf_context=pdf_context, row=row))
        if index == 1 or index == len(candidate_df) or index % 5 == 0:
            log(f"Prepared {index}/{len(candidate_df)} papers.")

    prepared_candidates.sort(key=lambda item: (item.row["screening_score"], item.row["title_match_score"]), reverse=True)

    enrichment_limit = llm_enrichment_limit if llm_enrichment_limit is not None else top_n
    enrichment_limit = max(0, min(enrichment_limit, len(prepared_candidates)))
    log(f"Running LLM enrichment for {enrichment_limit} shortlisted papers with {llm_client.settings.provider}/{llm_client.settings.model}...")

    for index, candidate in enumerate(prepared_candidates[:enrichment_limit], start=1):
        if candidate.pdf_context["text"] or _stringify_value(candidate.record.get("abstract")):
            try:
                llm_data = llm_client.generate_json(_prompt_for_record(candidate.record, candidate.pdf_context["text"]))
                for column in PROMPT_FIELDS:
                    candidate.row[column] = llm_data.get(column, candidate.row.get(column, ""))
                candidate.row = _apply_heuristic_defaults(candidate.row, candidate.record, candidate.pdf_context)
                if llm_data.get("Performance Metrics"):
                    candidate.row["screening_score"] += 3
                log(f"LLM-enriched {index}/{enrichment_limit}: {_stringify_value(candidate.record.get('title'))[:90]}")
            except Exception as exc:
                candidate.row["Notes, Special Considerations\n"] = (
                    candidate.row.get("Notes, Special Considerations\n", "")
                    + f" LLM extraction fallback: {exc}"
                ).strip()
                log(f"LLM fallback used for {_stringify_value(candidate.record.get('title'))[:90]}: {exc}")

    review_rows = [candidate.row for candidate in prepared_candidates]

    log("Writing review matrix spreadsheet and shortlist files...")
    review_df = pd.DataFrame(review_rows)
    review_df = review_df.reindex(columns=REVIEW_COLUMNS + EXTRA_COLUMNS)
    review_df = review_df.sort_values(["screening_score", "pdf_matched", "title_match_score"], ascending=[False, False, False])
    review_df["selection_rank"] = range(1, len(review_df) + 1)

    screened_df = candidate_df.copy()
    eligible_df = review_df.loc[review_df["eligibility_status"] == "eligible"].copy()
    included_df = eligible_df.head(top_n).copy()

    review_excel = output_path / "literature_review_matrix.xlsx"
    screened_csv = output_path / "screened_papers.csv"
    included_csv = output_path / "selected_best_papers.csv"
    counts_json = output_path / "prisma_counts.json"

    review_df.to_excel(review_excel, index=False)
    review_df.to_csv(screened_csv, index=False)
    included_df.to_csv(included_csv, index=False)

    log("Generating PRISMA flow outputs for the review matrix...")
    prisma = _build_prisma_outputs(Path(ris_parent_dir), screened_df, eligible_df, included_df, output_path)
    counts_json.write_text(json.dumps(prisma["counts"], indent=2), encoding="utf-8")
    log(f"Review matrix complete. Included {len(included_df)} papers in the shortlist.")

    return PipelineOutputs(
        review_excel=review_excel,
        screened_csv=screened_csv,
        included_csv=included_csv,
        prisma_png=prisma["png"],
        prisma_pdf=prisma["pdf"],
        counts_json=counts_json,
    )