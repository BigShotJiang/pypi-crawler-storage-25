import logging
import os
from typing import Tuple, Dict, Optional
import fitz
from io import BytesIO


class PDFHandler:
    def __init__(self, pdf_file_path: str, pdf_stream: Optional[BytesIO] = None):
        """Initialize PDFHandler with a PDF file path or stream.

        Args:
            pdf_file_path (str): Path to the PDF file or S3 key
            pdf_stream (Optional[BytesIO]): In-memory PDF content from S3
        """
        self.pdf_file_path = pdf_file_path
        self.pdf_stream = pdf_stream
        self.logger = logging.getLogger(__name__)

    def read(self) -> Tuple[str, Dict]:
        """Extract text and metadata from a PDF file using fitz (PyMuPDF).
        Works with both file paths and in-memory streams.

        Returns:
            Tuple[str, Dict]: (full text, metadata including page information)
        """
        try:
            # Choose between file path or memory stream
            if self.pdf_stream:
                doc = fitz.open(stream=self.pdf_stream, filetype="pdf")
            else:
                doc = fitz.open(self.pdf_file_path)
                
            full_text = []
            page_data = []
            char_offset = 0

            for page_num in range(len(doc)):
                page = doc.load_page(page_num)
                text = page.get_text("text", flags=fitz.TEXT_PRESERVE_LIGATURES | fitz.TEXT_MEDIABOX_CLIP)

                # Store exact page boundaries
                page_entry = {
                    "page_number": page_num + 1,
                    "char_start": char_offset,
                    "char_end": char_offset + len(text),
                    "text": text
                }
                page_data.append(page_entry)
                full_text.append(text)
                char_offset += len(text)

            full_text = "".join(full_text)

            meta_data = {
                'source': os.path.basename(self.pdf_file_path),
                'total_pages': len(doc),
                'total_length': char_offset,
                'page_data': page_data
            }

            doc.close()
            return full_text, meta_data

        except Exception as e:
            self.logger.error(f"Error extracting text from {self.pdf_file_path}: {str(e)}")
            return "", {}
