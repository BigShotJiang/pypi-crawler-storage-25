"""BGE reranker for ranking candidate documents by relevance."""

from typing import List, Tuple
from rms.ranking import RankerBase


class BGEReranker(RankerBase):
    """
    BGE reranker for improved relevance ranking.
    
    Reranking improves retrieval quality by:
    - Fine-tuning relevance scores
    - Filtering low-quality matches
    - Considering query-document semantic similarity more deeply
    """

    def __init__(
        self,
        model_name: str = "BAAI/bge-reranker-base",
        device: str = "auto",
    ):
        """
        Initialize BGE reranker.
        
        Args:
            model_name: HuggingFace reranker model
            device: "auto", "cuda", "cpu"
        """
        try:
            from sentence_transformers import CrossEncoder
            import torch
        except ImportError:
            raise ImportError(
                "sentence-transformers not installed. "
                "Install with: pip install sentence-transformers torch"
            )

        self._model_name = model_name

        # Select device
        if device == "auto":
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self.device = device

        print(f"Loading {model_name} on {self.device}...")
        self.model = CrossEncoder(model_name, device=self.device)
        print(f"Reranker loaded.")

    def rank(
        self,
        query: str,
        candidates: List[str],
    ) -> List[Tuple[int, float]]:
        """Rank candidates by relevance to query."""
        if not candidates:
            return []

        # Prepare input pairs
        pairs = [[query, candidate] for candidate in candidates]

        # Get scores
        scores = self.model.predict(pairs)

        # Return (index, score) sorted by score descending
        ranked = sorted(enumerate(scores), key=lambda x: x[1], reverse=True)
        return [(idx, float(score)) for idx, score in ranked]

    def batch_rank(
        self,
        queries: List[str],
        candidates_per_query: List[List[str]],
    ) -> List[List[Tuple[int, float]]]:
        """Rank multiple queries in batch."""
        results = []
        for query, candidates in zip(queries, candidates_per_query):
            results.append(self.rank(query, candidates))
        return results

    @property
    def model_name(self) -> str:
        """Return model name."""
        return self._model_name
