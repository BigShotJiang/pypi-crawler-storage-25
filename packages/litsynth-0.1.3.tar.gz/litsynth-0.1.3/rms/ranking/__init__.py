from abc import ABC, abstractmethod
from typing import List, Tuple


class RankerBase(ABC):
    """Base class for relevance ranking/reranking."""

    @abstractmethod
    def rank(
        self,
        query: str,
        candidates: List[str],
    ) -> List[Tuple[int, float]]:
        """
        Rank candidates by relevance to query.
        
        Args:
            query: Query string
            candidates: List of candidate texts
            
        Returns:
            List of (index, score) tuples, sorted by score descending
        """
        pass

    @abstractmethod
    def batch_rank(
        self,
        queries: List[str],
        candidates_per_query: List[List[str]],
    ) -> List[List[Tuple[int, float]]]:
        """Rank multiple queries in batch."""
        pass

    @property
    @abstractmethod
    def model_name(self) -> str:
        """Return model identifier."""
        pass
