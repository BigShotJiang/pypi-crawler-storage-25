"""Main RMS pipeline orchestrator."""

from typing import List, Dict, Any, Optional
import numpy as np
from pathlib import Path

from rms.config import PipelineConfig
from rms.factory import ComponentFactory
from rms.ingestion import Document, DocumentChunk


class RMSPipeline:
    """Main orchestration for RMS pipeline."""

    def __init__(self, config: PipelineConfig):
        """
        Initialize RMS pipeline.
        
        Args:
            config: PipelineConfig instance
        """
        self.config = config
        
        # Create components
        print("Initializing RMS pipeline components...")
        self.ingestor = ComponentFactory.create_ingestor(config)
        self.embedder = ComponentFactory.create_embedder(config)
        self.vectordb = ComponentFactory.create_vectordb(config)
        self.ranker = ComponentFactory.create_ranker(config)
        self.generator = ComponentFactory.create_generator(config)
        
        print(f"✓ Ingestor: {self.ingestor.model_name}")
        print(f"✓ Embedder: {self.embedder.model_name}")
        print(f"✓ Vector DB: {config.vectordb.type.value}")
        print(f"✓ Ranker: {self.ranker.model_name if self.ranker else 'disabled'}")
        print(f"✓ Generator: {self.generator.model_name}")
        print("RMS pipeline ready.\n")

    def ingest(self, source_path: str, **kwargs) -> List[Document]:
        """Ingest documents."""
        print(f"Ingesting from {source_path}...")
        documents = self.ingestor.ingest(source_path, **kwargs)
        print(f"✓ Ingested {len(documents)} document(s)")
        return documents

    def ingest_batch(self, source_paths: List[str], **kwargs) -> List[Document]:
        """Ingest multiple documents."""
        print(f"Ingesting {len(source_paths)} source(s)...")
        documents = self.ingestor.ingest_batch(source_paths, **kwargs)
        print(f"✓ Ingested {len(documents)} document(s)")
        return documents

    def chunk_document(
        self,
        document: Document,
        chunk_size: int = 500,
        chunk_overlap: int = 100,
    ) -> List[DocumentChunk]:
        """
        Chunk document into smaller pieces.
        
        Args:
            document: Document to chunk
            chunk_size: Approximate characters per chunk
            chunk_overlap: Overlap between chunks
            
        Returns:
            List of DocumentChunk objects
        """
        text = document.text
        chunks = []
        chunk_id = 0
        start = 0

        while start < len(text):
            end = min(start + chunk_size, len(text))
            
            # Try to split at sentence boundary if not at end
            if end < len(text):
                # Find last period/newline
                last_period = text.rfind('.', start, end)
                if last_period > start:
                    end = last_period + 1
            
            chunk_text = text[start:end].strip()
            if chunk_text:
                chunk = DocumentChunk(
                    chunk_id=f"{document.id}_{chunk_id}",
                    document_id=document.id,
                    text=chunk_text,
                    start_char=start,
                    end_char=end,
                    metadata={
                        "source": document.source,
                        **document.metadata,
                    },
                )
                chunks.append(chunk)
                chunk_id += 1
            
            start = end - chunk_overlap

        print(f"✓ Chunked into {len(chunks)} chunks")
        return chunks

    def index(self, chunks: List[DocumentChunk]) -> None:
        """Index chunks into vector database."""
        if not chunks:
            print("No chunks to index")
            return
        
        print(f"Embedding {len(chunks)} chunks...")
        
        # Extract texts
        texts = [chunk.text for chunk in chunks]
        
        # Embed
        embeddings = self.embedder.embed(texts)
        print(f"✓ Created {len(embeddings)} embeddings")
        
        # Prepare metadata
        ids = [chunk.chunk_id for chunk in chunks]
        metadata = [chunk.metadata or {} for chunk in chunks]
        
        # Upsert to vector DB
        print(f"Indexing into vector database...")
        self.vectordb.upsert(
            vectors=embeddings,
            ids=ids,
            metadata=metadata,
            collection_name=self.config.vectordb.collection_name,
        )
        print(f"✓ Indexed successfully")

    def search(
        self,
        query: str,
        top_k: int = 5,
        rerank: bool = True,
    ) -> List[Dict[str, Any]]:
        """
        Search for relevant chunks.
        
        Args:
            query: Query text
            top_k: Number of results
            rerank: Apply reranking if available
            
        Returns:
            List of results with scores
        """
        print(f"Searching for: {query}")
        
        # Embed query
        query_embedding = self.embedder.embed([query])[0]
        
        # Search
        results = self.vectordb.search(
            query_vector=query_embedding,
            top_k=top_k * 2 if rerank else top_k,  # Get more for reranking
            collection_name=self.config.vectordb.collection_name,
        )
        
        print(f"✓ Found {len(results)} candidates")
        
        # Rerank if enabled
        if rerank and self.ranker and len(results) > 0:
            print(f"Reranking with {self.ranker.model_name}...")
            
            candidate_texts = [r.text for r in results]
            ranked_indices = self.ranker.rank(query, candidate_texts)
            
            # Reorder results
            reranked_results = []
            for idx, score in ranked_indices[:top_k]:
                result = results[idx]
                result.score = score
                reranked_results.append(result)
            results = reranked_results
            
            print(f"✓ Reranked to top {len(results)}")
        else:
            results = results[:top_k]
        
        # Format output
        output = [
            {
                "document_id": r.document_id,
                "chunk_id": r.chunk_id,
                "text": r.text,
                "score": r.score,
                "metadata": r.metadata,
            }
            for r in results
        ]
        
        return output

    def rag(
        self,
        query: str,
        top_k: int = 5,
        rerank: bool = True,
    ) -> Dict[str, Any]:
        """
        Retrieve-Augmented Generation.
        
        Args:
            query: Query text
            top_k: Number of retrieval results
            rerank: Apply reranking
            
        Returns:
            Dict with answer and supporting info
        """
        print(f"\nRAG Query: {query}\n")
        
        # Search
        search_results = self.search(query, top_k=top_k, rerank=rerank)
        
        if not search_results:
            return {
                "query": query,
                "answer": "No relevant documents found.",
                "supporting_chunks": [],
            }
        
        # Build context
        context = "\n\n".join([
            f"[{r['document_id']}] {r['text']}"
            for r in search_results
        ])
        
        # Generate
        prompt = f"""Based on the following context, answer the question.

Context:
{context}

Question: {query}

Answer:"""
        
        print(f"Generating answer...")
        response = self.generator.generate(
            prompt,
            max_tokens=self.config.generator.max_tokens,
            temperature=self.config.generator.temperature,
        )
        print(f"✓ Generated response\n")
        
        return {
            "query": query,
            "answer": response.text,
            "model": response.model,
            "supporting_chunks": search_results,
        }

    def get_collection_info(self) -> Dict[str, Any]:
        """Get vector database collection information."""
        return self.vectordb.collection_info(
            self.config.vectordb.collection_name
        )

    def list_collections(self) -> List[str]:
        """List available collections."""
        return self.vectordb.list_collections()
