"""Single-command launcher for the local LitSynth experience."""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

import requests


def _repo_root() -> Path:
    return Path(__file__).resolve().parent.parent


def _with_pythonpath(env: dict[str, str], repo_root: Path) -> dict[str, str]:
    updated = env.copy()
    existing = updated.get("PYTHONPATH", "")
    updated["PYTHONPATH"] = str(repo_root) if not existing else f"{repo_root}{os.pathsep}{existing}"
    return updated


def _wait_for_healthcheck(url: str, timeout_seconds: float) -> None:
    deadline = time.time() + timeout_seconds
    last_error: Exception | None = None
    while time.time() < deadline:
        try:
            response = requests.get(url, timeout=2)
            if response.ok:
                return
        except Exception as exc:
            last_error = exc
        time.sleep(0.5)
    raise RuntimeError(f"Timed out waiting for API readiness at {url}: {last_error}")


def _wait_for_streamlit(url: str, timeout_seconds: float) -> None:
    deadline = time.time() + timeout_seconds
    last_error: Exception | None = None
    while time.time() < deadline:
        try:
            response = requests.get(f"{url}/_stcore/health", timeout=2)
            if response.ok:
                return
        except Exception as exc:
            last_error = exc
        time.sleep(0.5)
    raise RuntimeError(f"Timed out waiting for Streamlit readiness at {url}: {last_error}")


def _terminate_process(process: subprocess.Popen[bytes] | None) -> None:
    if process is None or process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="litsynth", description="LitSynth local launcher and utilities.")
    subcommands = parser.add_subparsers(dest="command", required=True)

    launch = subcommands.add_parser("launch", help="Start the API and Streamlit UI with one command")
    launch.add_argument("--api-host", default="127.0.0.1", help="Host for the FastAPI service")
    launch.add_argument("--api-port", type=int, default=8000, help="Port for the FastAPI service")
    launch.add_argument("--web-host", default="127.0.0.1", help="Host for the Streamlit UI")
    launch.add_argument("--web-port", type=int, default=8504, help="Port for the Streamlit UI")
    launch.add_argument("--no-browser", action="store_true", help="Do not open the Streamlit UI in the default browser")
    launch.add_argument(
        "--api-start-timeout",
        type=float,
        default=45.0,
        help="Seconds to wait for the API health check before failing",
    )
    launch.add_argument(
        "--web-start-timeout",
        type=float,
        default=45.0,
        help="Seconds to wait for the Streamlit UI before opening the browser",
    )
    return parser


def launch(args: argparse.Namespace) -> int:
    repo_root = _repo_root()
    python_executable = sys.executable

    api_env = _with_pythonpath(os.environ, repo_root)
    api_url = f"http://{args.api_host}:{args.api_port}"
    web_env = _with_pythonpath(os.environ, repo_root)
    web_env["RMS_API_URL"] = api_url

    api_process: subprocess.Popen[bytes] | None = None
    web_process: subprocess.Popen[bytes] | None = None

    try:
        api_process = subprocess.Popen(
            [
                python_executable,
                "-m",
                "uvicorn",
                "apps.api.main:app",
                "--host",
                args.api_host,
                "--port",
                str(args.api_port),
            ],
            cwd=repo_root,
            env=api_env,
        )
        _wait_for_healthcheck(f"{api_url}/health", args.api_start_timeout)

        web_process = subprocess.Popen(
            [
                python_executable,
                "-m",
                "streamlit",
                "run",
                "apps/webapp/app.py",
                "--server.address",
                args.web_host,
                "--server.port",
                str(args.web_port),
                "--server.headless",
                "true",
            ],
            cwd=repo_root,
            env=web_env,
        )

        web_url = f"http://{args.web_host}:{args.web_port}"
        _wait_for_streamlit(web_url, args.web_start_timeout)

        print(f"LitSynth API: {api_url}")
        print(f"LitSynth UI: {web_url}")
        print("Press Ctrl+C to stop both services.")

        if not args.no_browser:
            webbrowser.open(web_url)

        while True:
            if api_process.poll() is not None:
                raise RuntimeError(f"API process exited with code {api_process.returncode}")
            if web_process.poll() is not None:
                raise RuntimeError(f"Web process exited with code {web_process.returncode}")
            time.sleep(1)
    except KeyboardInterrupt:
        return 0
    finally:
        _terminate_process(web_process)
        _terminate_process(api_process)


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "launch":
        raise SystemExit(launch(args))

    parser.error(f"Unsupported command: {args.command}")


if __name__ == "__main__":
    main()