from abc import ABC, abstractmethod
from typing import List
import numpy as np


class EmbedderBase(ABC):
    """Base class for embedding models."""

    @abstractmethod
    def embed(self, texts: List[str]) -> np.ndarray:
        """
        Embed list of texts.
        
        Args:
            texts: List of text strings
            
        Returns:
            np.ndarray of shape (len(texts), embedding_dim)
        """
        pass

    @abstractmethod
    def embed_batch(self, texts: List[str], batch_size: int = 32) -> np.ndarray:
        """Embed texts in batches for memory efficiency."""
        pass

    @property
    @abstractmethod
    def embedding_dim(self) -> int:
        """Return dimension of embeddings."""
        pass

    @property
    @abstractmethod
    def model_name(self) -> str:
        """Return model identifier."""
        pass
