"""BGE local embeddings using HuggingFace Transformers."""

from typing import List
import numpy as np
from rms.embeddings import EmbedderBase


class BGELocalEmbedder(EmbedderBase):
    """
    Local BGE embeddings using HuggingFace.
    
    BGE (BAAI General Embedding) models provide:
    - State-of-the-art retrieval quality
    - Support for CPU and GPU
    - Multiple model sizes (small, base, large)
    - Cost-free operation
    """

    def __init__(
        self,
        model_name: str = "BAAI/bge-small-en-v1.5",
        device: str = "auto",
        batch_size: int = 32,
    ):
        """
        Initialize BGE embedder.
        
        Args:
            model_name: HuggingFace model identifier
            device: "auto", "cuda", "cpu"
            batch_size: Batch size for processing
        """
        try:
            from sentence_transformers import SentenceTransformer
            import torch
        except ImportError:
            raise ImportError(
                "sentence-transformers not installed. "
                "Install with: pip install sentence-transformers torch"
            )

        self._model_name = model_name
        self.batch_size = batch_size

        # Select device
        if device == "auto":
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self.device = device

        print(f"Loading {model_name} on {self.device}...")
        self.model = SentenceTransformer(model_name, device=self.device)
        print(f"Model loaded. Embedding dimension: {self.model.get_sentence_embedding_dimension()}")

    def embed(self, texts: List[str]) -> np.ndarray:
        """Embed texts (single batch)."""
        if not texts:
            return np.array([]).reshape(0, self.embedding_dim)

        embeddings = self.model.encode(
            texts,
            batch_size=self.batch_size,
            convert_to_numpy=True,
        )
        return embeddings

    def embed_batch(self, texts: List[str], batch_size: int = 32) -> np.ndarray:
        """Embed texts in specified batch size."""
        return self.embed(texts)  # SentenceTransformer handles batching internally

    @property
    def embedding_dim(self) -> int:
        """Return embedding dimension."""
        return self.model.get_sentence_embedding_dimension()

    @property
    def model_name(self) -> str:
        """Return model name."""
        return self._model_name
