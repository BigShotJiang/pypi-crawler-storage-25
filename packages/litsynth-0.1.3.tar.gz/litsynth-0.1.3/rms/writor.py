from collections import Counter
from typing import Tuple, Set
import fitz
from typing import Tuple, List, Dict, Optional
import re

import os
import pandas as pd
from io import BytesIO

try:
    import boto3
except ImportError:  # pragma: no cover - optional cloud dependency
    boto3 = None

class DocumentWriter:
    """Handles document export operations to S3 or local disk."""
    def __init__(self, document_path=None, debug: bool = False, output_folder="highlighted meta synthesis"):
        self.highlights = []
        self.document_path = document_path
        self.debug = debug
        
        # S3 configuration
        self.s3_bucket = "research-manager-system-data"
        self.s3_client = boto3.client('s3') if boto3 is not None else None
        
        # S3 paths don't need local directory creation, but we'll maintain the folder structure for S3 keys
        self.output_folder = output_folder
        
        # Create S3 key path
        if document_path:
            self.s3_key = f"{output_folder}/{os.path.basename(document_path)}"
        else:
            self.s3_key = None

    def export_to_excel(self, results):
        """Export results to Excel file in S3 or local disk."""
        df = pd.DataFrame.from_records([results] if isinstance(results, dict) else results)

        if self.s3_client is None:
            if not self.document_path:
                raise ValueError("document_path is required for local Excel export")
            os.makedirs(os.path.dirname(self.document_path) or ".", exist_ok=True)
            df.to_excel(self.document_path, index=False)
            return df
        
        # Create Excel in memory
        excel_buffer = BytesIO()
        df.to_excel(excel_buffer, index=False)
        excel_buffer.seek(0)
        
        # Upload to S3
        self.s3_client.put_object(
            Bucket=self.s3_bucket,
            Key=self.document_path,  # Using document_path as the S3 key
            Body=excel_buffer.getvalue()
        )
        
        if self.debug:
            print(f"Exported Excel to s3://{self.s3_bucket}/{self.document_path}")
            
        return df

    def update_excel(self, new_result):
        """Update existing Excel file in S3 or local disk with new results"""
        if not self.document_path:
            raise ValueError("No Excel file has been created yet. Call export_to_excel first.")

        if self.s3_client is None:
            if os.path.exists(self.document_path):
                existing_df = pd.read_excel(self.document_path)
            else:
                existing_df = pd.DataFrame()

            new_df = pd.DataFrame([new_result])
            updated_df = pd.concat([existing_df, new_df], ignore_index=True)
            updated_df.to_excel(self.document_path, index=False)
            return updated_df

        # Try to read existing Excel file from S3
        try:
            response = self.s3_client.get_object(
                Bucket=self.s3_bucket,
                Key=self.document_path
            )
            excel_content = BytesIO(response['Body'].read())
            existing_df = pd.read_excel(excel_content)
        except self.s3_client.exceptions.NoSuchKey:
            existing_df = pd.DataFrame()

        # Convert new result to DataFrame
        new_df = pd.DataFrame([new_result])

        # Concatenate existing data with new data
        updated_df = pd.concat([existing_df, new_df], ignore_index=True)

        # Save back to S3
        excel_buffer = BytesIO()
        updated_df.to_excel(excel_buffer, index=False)
        excel_buffer.seek(0)
        
        self.s3_client.put_object(
            Bucket=self.s3_bucket,
            Key=self.document_path,
            Body=excel_buffer.getvalue()
        )
        
        if self.debug:
            print(f"Updated Excel in s3://{self.s3_bucket}/{self.document_path}")
            
        return updated_df

    def highlight(self, char_range, page_numbers):
        print("----------highlighting-------------")
        print(f"Document: {self.document_path}")
        print(f"Target range: {char_range}, Pages: {page_numbers}")

        # Ensure output directory exists
        output_dir = "highlighted meta synthesis"
        os.makedirs(output_dir, exist_ok=True)

        doc = fitz.open(self.document_path)

        # Rebuild page boundaries with RAW text (no spaces)
        text = ""
        page_boundaries = []
        for page_num in range(len(doc)):
            page = doc.load_page(page_num)
            # FIX: Use valid text extraction option
            page_text = page.get_text("text", flags=fitz.TEXT_PRESERVE_LIGATURES | fitz.TEXT_MEDIABOX_CLIP)
            page_boundaries.append({
                "start": len(text),
                "end": len(text) + len(page_text),
                "page_num": page_num + 1,
                "page_obj": page,
                "page_text": page_text
            })
            text += page_text

        # Process pages with character-accurate matching
        for page_info in page_boundaries:
            if page_info["page_num"] not in page_numbers:
                continue

            page = page_info["page_obj"]
            raw_text = page_info["page_text"]

            # Calculate EXACT local offsets using raw text
            page_start = page_info["start"]
            local_start = max(0, char_range[0] - page_start)
            local_end = min(len(raw_text), char_range[1] - page_start)

            print(f"\nPage {page_info['page_num']}:")
            print(f"Raw text slice: {raw_text[local_start:local_end][:100]}...")

            if local_start >= local_end:
                print("No overlap - skipping")
                continue

            # Get text selection using CHARACTER POSITIONS (not word positions)
            text_selection = page.get_text_selection(
                local_start,
                local_end,
                False  # KEY CHANGE: disable word boundary adjustment
            )

            if text_selection and text_selection["rects"]:
                print(f"Found {len(text_selection['rects'])} highlight areas")
                for rect in text_selection["rects"]:
                    page.add_highlight_annot(rect)
            else:
                print("No text found - trying visual search...")
                # Fallback to text search
                text_to_find = raw_text[local_start:local_end].strip()
                if text_to_find:
                    areas = page.search_for(text_to_find)
                    for rect in areas:
                        page.add_highlight_annot(rect)
                    print(f"Found {len(areas)} areas via text search")

        # Save to new file
        output_path = os.path.join(output_dir, f"HL_{os.path.basename(self.document_path)}")
        doc.save(output_path)
        doc.close()
        print(f"\nSaved highlighted PDF to: {output_path}")


    def remove_highlights(self) -> bool:
        """
        Remove all highlights from the PDF file.

        Returns:
            bool: True if highlights were removed successfully, False otherwise
        """
        try:
            doc = fitz.open(self.document_path)

            # Track if we removed any highlights
            removed = False

            # Process each page
            for page in doc:
                # Get all annotations on the page
                annots = page.annots()
                if annots:
                    for annot in annots:
                        # Check if annotation is a highlight
                        if annot.type[0] == 8:  # 8 is highlight annotation
                            page.delete_annot(annot)
                            removed = True

            # Save the modified PDF if any highlights were removed
            if removed:
                output_path = self.document_path.replace('.pdf', '_clean.pdf')
                doc.save(output_path)

            doc.close()
            return removed

        except Exception as e:
            print(f"Error removing highlights: {str(e)}")
            return False


class DraftWriter:
    """Writes deterministic citation evidence blocks to markdown drafts."""

    @staticmethod
    def _format_authors(authors):
        if not authors:
            return "Unknown"
        return ", ".join(authors)

    @staticmethod
    def append_citation_evidence(
        draft_path: str,
        citation: dict,
        source_document: str,
        char_range: Tuple[int, int],
        excerpt_text: str,
        user_id: str,
        timestamp_utc: str,
    ) -> None:
        os.makedirs(os.path.dirname(draft_path) or ".", exist_ok=True)

        citation_line = (
            f"{DraftWriter._format_authors(citation.get('authors', []))} "
            f"({citation.get('year', 'n.d.')}). {citation.get('title', 'Untitled')}."
        )

        doi = citation.get("doi", "")
        url = citation.get("url", "")
        publisher = citation.get("publisher", "")

        with open(draft_path, "a", encoding="utf-8") as draft_file:
            draft_file.write("\n\n## Evidence-Backed Citation Insert\n")
            draft_file.write(f"- Timestamp (UTC): {timestamp_utc}\n")
            draft_file.write(f"- Requested by: {user_id}\n")
            draft_file.write(f"- Source document: {source_document}\n")
            draft_file.write(f"- Character range: {char_range}\n")
            draft_file.write("- Citation (authoritative):\n")
            draft_file.write(f"  {citation_line}\n")
            if publisher:
                draft_file.write(f"  Publisher: {publisher}\n")
            if doi:
                draft_file.write(f"  DOI: {doi}\n")
            if url:
                draft_file.write(f"  URL: {url}\n")

            draft_file.write("\n### Verbatim Evidence Excerpt\n")
            draft_file.write("> " + excerpt_text.replace("\n", "\n> ") + "\n")

    @staticmethod
    def append_audit_log(audit_log_path: str, event: dict) -> None:
        os.makedirs(os.path.dirname(audit_log_path) or ".", exist_ok=True)
        row = pd.DataFrame([event])

        if os.path.exists(audit_log_path):
            existing = pd.read_csv(audit_log_path)
            updated = pd.concat([existing, row], ignore_index=True)
            updated.to_csv(audit_log_path, index=False)
        else:
            row.to_csv(audit_log_path, index=False)

