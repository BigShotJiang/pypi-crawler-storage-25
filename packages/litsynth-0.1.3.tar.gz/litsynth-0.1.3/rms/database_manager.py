from typing import Optional, List

from rms.chroma_manager import ChromaDatabaseManager
from rms.reader import DocumentHandler
from rms.sql_lite_manager import SQLiteDatabaseManager


class DatabaseManager:
    """Manages both SQLite and ChromaDB databases"""
    def __init__(self):
        self.sql_database = SQLiteDatabaseManager()
        self.chroma_database = ChromaDatabaseManager()
        self.saved_documents = self.chroma_database.get_document_list()

    def save(self, pdf_path):
        # Read PDF and process document
        text, meta_data = DocumentHandler(pdf_path).read()
        self.sql_database.save(text, meta_data)
        return self.chroma_database.save(text, meta_data)

    def boolean_search(self, query: str, limit: int = 10):
        return self.sql_database.boolean_search(query, limit)

    def advanced_search(self,  must_include: Optional[List[str]] = None,
                        must_exclude: Optional[List[str]] = None,
                        exact_phrases: Optional[List[str]] = None,
                        any_of: Optional[List[str]] = None):
        return self.sql_database.advanced_search( must_include,
                        must_exclude,
                        exact_phrases,
                        any_of)

    def semantic_search(self, query: str, pdf_name_list = None, top_k: int = 5):
        return self.chroma_database.search(query, pdf_name_list, top_k)



