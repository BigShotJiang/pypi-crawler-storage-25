"""Classes to support the generation of quality metrics for the calibrated data."""

import logging
from collections import defaultdict
from datetime import datetime
from itertools import chain
from pathlib import Path
from typing import Generator
from typing import Iterable
from typing import Type

import numpy as np
from pydantic import FiniteFloat
from pydantic import model_validator

from dkist_processing_common.codecs.basemodel import basemodel_encoder
from dkist_processing_common.codecs.fits import fits_access_decoder
from dkist_processing_common.models.fits_access import FitsAccessBase
from dkist_processing_common.models.fried_parameter import r0_valid
from dkist_processing_common.models.metric_code import MetricCode
from dkist_processing_common.models.quality import QualityMetric
from dkist_processing_common.models.quality import QualityModel
from dkist_processing_common.models.quality import TableData
from dkist_processing_common.models.quality import TimeSeriesData
from dkist_processing_common.models.quality import XYData
from dkist_processing_common.models.tags import Tag
from dkist_processing_common.parsers.l0_fits_access import L0FitsAccess
from dkist_processing_common.parsers.quality import L1QualityFitsAccess
from dkist_processing_common.tasks.base import WorkflowTaskBase
from dkist_processing_common.tasks.mixin.quality import QualityMixin

__all__ = ["QualityL1Metrics", "QualityL0Metrics"]


logger = logging.getLogger(__name__)


class L0QualityData(QualityModel):
    """
    Intermediate L0 Quality Data.

    The relationship of this structure to task type and modstate is maintained outside of this structure.
    One usage is to combine all modstate for a single task type,
     resulting in one instance per task type.
    Another usage is to segregate by modstate and task type,
     resulting in many instances per task type.
    """

    # by default, a tuple accepts a list as input
    # the use of tuples is intentional because list mutations do not trigger validation
    # the impact is that L0QualityData should not be instantiated until
    # after the tuple input has been fully accumulated
    # when `mode="json"`, the output of a tuple results in a list
    # when `mode="python"`, the output of a tuple results in a tuple
    datetimes: tuple[datetime, ...]
    # NOTE:  FiniteFloat will fail fast for `nan` and `inf`
    average_values: tuple[FiniteFloat, ...]
    rms_values: tuple[FiniteFloat, ...]

    @property
    def has_values(self) -> bool:
        return bool(self.average_values)


class QualityL0Metrics(WorkflowTaskBase, QualityMixin):
    """
    Task class supporting the generation of quality metrics for the L0 data.

    Subclassing guide
    -----------------

    There are three important properties that an instrument subclass may want to change to make sure that the L0 metrics
    are computed for the correct files and organized in a meaningful way:

    `raw_frame_tag` (``str``)
        The top-level tag used to identify "raw" frames that will be considered when computing metrics. For visible
        instruments this can be left as the default `Tag.input()`, but IR cameras will probably want to set this to
        `Tag.linearized()` or similar.

    `~dkist_processing_common.tasks.mixin.quality.QualityMixin.quality_task_types` (`list[str]`)
        A list of IPTASK types. A separate set of L0 metrics will be reported for each task type listed here.
        See the definition of `~dkist_processing_common.tasks.mixin.quality.QualityMixin.quality_task_types` for the
        sensible defaults. If overloading, please use controlled `~dkist_processing_common.models.task_name.TaskName`
        values, if possible.

    `modstate_list` (`list[int] | None`)
        A list of modstates over which to separate each metric. Adding modstates does not create new metric entries, but
        does sub-divide each TASK's metric into modstate bins. If you want *all* files of a single TASK to be considered
        together return ``None`` here.

    **NOTE:** The `~dkist_processing_common.tasks.mixin.quality.QualityMixin.quality_task_types` on an instrument
    subclass of `~dkist_processing_common.tasks.l1_output_data.AssembleQualityData` should match whatever is set here
    (although in both cases the default is probably fine).
    """

    @property
    def modstate_list(self) -> Iterable[int] | None:
        """
        Define the list of modstates over which to compute quality metrics.

        If you want to compute metrics over *all* modstates at the same time return `None`.
        """
        return None

    @property
    def raw_frame_tag(self) -> str:
        """
        Define the tag that indicates L0 data.

        Usually this is `Tag.input()`, but for IR instruments it may be `Tag.linearized()`.
        """
        return Tag.input()

    @property
    def fits_access_class(self) -> Type[FitsAccessBase]:
        """Define the `FitsAccess`-type class used to parse the headers of L0 frames."""
        return L0FitsAccess

    def run(self) -> None:
        """
        Calculate L0 quality metrics for all TASK/MODSTATE combinations.

        Which (if any) modstates and task types to loop over can be set with the `modstate_list` and
        `quality_task_types` properties, respectively.
        """
        with self.telemetry_span("Collecting L0 Quality Data"):
            segmented_quality_data = self.collect_l0_quality_data()

        with self.telemetry_span("Writing L0 Quality Metrics to disk"):
            self.compute_and_write_l0_quality_metrics(segmented_quality_data)

    # TODO FUTURE - this method should ultimately go away
    def get_paths_for_modstate_and_task(
        self, modstate: int | None, task_type: str
    ) -> Generator[Path, None, None]:
        """
        Return Paths for all raw files that tagged with the given modstate and task type.

        The tag that defines "raw" can be changed in the `raw_frame_tag` property.
        """
        tags = [self.raw_frame_tag, Tag.task(task_type)]
        if modstate is not None:
            tags.append(Tag.modstate(modstate))

        return self.read(tags)

    def collect_l0_quality_data(self) -> dict[str, dict[str, L0QualityData]]:
        """Calculate L0 quality metrics for each task type and modstate combo."""
        intermediate_l0_quality_data_segmented_first_by_ip_task_and_then_by_modstate: dict[
            str, dict[str, L0QualityData]
        ] = defaultdict(dict)
        modstate_list = self.modstate_list if self.modstate_list is not None else [None]
        for task_type in self.quality_task_types:
            with self.telemetry_span(f"Collecting {task_type = }"):
                for modstate in modstate_list:
                    # TODO FUTURE - this should do something like this: self.read(decoder=l0_fits_access_decoder)
                    paths = self.get_paths_for_modstate_and_task(modstate, task_type)

                    # establish empty lists for this task type AND modstate
                    datetimes = []
                    average_values = []
                    rms_values = []

                    for path in paths:
                        frame = L0FitsAccess.from_path(path)
                        data = frame.data.astype(float)
                        exposure_time_sec = frame.fpa_exposure_time_ms / 1000

                        # Mean and RMS for Frame
                        normalized_mean = self.compute_normalized_mean(data, exposure_time_sec)
                        normalized_rms = self.compute_normalized_rms(data, exposure_time_sec)

                        # accumulate each value into its list
                        datetimes.append(datetime.fromisoformat(frame.time_obs))
                        average_values.append(normalized_mean)
                        rms_values.append(normalized_rms)

                    # now sort the lists by datetime
                    order = sorted(range(len(datetimes)), key=datetimes.__getitem__)
                    datetimes = [datetimes[i] for i in order]
                    average_values = [average_values[i] for i in order]
                    rms_values = [rms_values[i] for i in order]

                    # create the L0QualityData for this task type AND modstate
                    l0_quality_data = L0QualityData(
                        datetimes=tuple(datetimes),
                        average_values=tuple(average_values),
                        rms_values=tuple(rms_values),
                    )

                    # modstate is int or None
                    # eventually this will be the key of a json object - `null` cannot be a json object key
                    modstate_key = "" if modstate is None else str(modstate)
                    intermediate_l0_quality_data_segmented_first_by_ip_task_and_then_by_modstate[
                        task_type
                    ][modstate_key] = l0_quality_data

        return intermediate_l0_quality_data_segmented_first_by_ip_task_and_then_by_modstate

    @staticmethod
    def compute_normalized_rms(data: np.ndarray, exposure_time_sec: float) -> float:
        r"""
        Compute the normalized rms of a single frame.

        Defined as

        .. math::

            RMS = \frac{\sqrt{\left<D^2\right>}}{t}

        where :math:`D` is the data array, :math:`t` is the exposure time, in seconds, and :math:`\left< \right>`
        denotes the average.
        """
        squared_mean = np.nanmean(data**2)
        return np.sqrt(squared_mean) / exposure_time_sec

    @staticmethod
    def compute_normalized_mean(data: np.ndarray, exposure_time_sec: float) -> float:
        r"""
        Compute the normalized mean of a single frame.

        Defined as

        .. math::

            \mathrm{M} = \left<D\right>/t

        where :math:`D` is the data array, :math:`t` is the exposure time, in seconds, and :math:`\left< \right>`
        denotes the average.
        """
        return np.nanmean(data) / exposure_time_sec

    def compute_and_write_l0_quality_metrics(
        self, segmented_quality_data: dict[str, dict[str, L0QualityData]]
    ) -> None:
        """Compute and write L0 metrics to disk."""
        self.compute_and_write_dataset_average(segmented_quality_data)
        self.compute_and_write_dataset_rms(segmented_quality_data)
        self.compute_and_write_frame_average(segmented_quality_data)
        self.compute_and_write_frame_rms(segmented_quality_data)

    def compute_and_write_dataset_average(
        self, segmented_quality_data: dict[str, dict[str, L0QualityData]]
    ) -> None:
        """Compute and write DATASET_AVERAGE quality metric."""
        header = ("Task Type", "Dataset Average (adu / sec)")
        rows = [header]
        for task_type, l0_data_by_mod in segmented_quality_data.items():
            # combine all of the average value lists for each modstate into a single list for the task
            average_values = list(
                chain.from_iterable(l0_data.average_values for l0_data in l0_data_by_mod.values())
            )
            if average_values:
                row = (task_type, str(round(np.mean(average_values), 2)))
                rows.append(row)
        table_data = TableData(rows=tuple(rows))
        metric = QualityMetric(
            name="Average Across Dataset",
            description="This metric is the calculated mean intensity value across data from an "
            "instrument program task type used in the creation of an entire L1 "
            "dataset.",
            metric_code=MetricCode.dataset_average,
            table_data=[table_data],
        )
        self.write(metric, tags=Tag.quality("GENERIC"), encoder=basemodel_encoder)

    def compute_and_write_dataset_rms(
        self, segmented_quality_data: dict[str, dict[str, L0QualityData]]
    ) -> None:
        """Compute and write DATASET_RMS quality metric."""
        header = ("Task Type", "Dataset RMS (adu / sec)")
        rows = [header]
        for task_type, l0_data_by_mod in segmented_quality_data.items():
            # combine all of the rms value lists for each modstate into a single list for the task
            rms_values = list(
                chain.from_iterable(l0_data.rms_values for l0_data in l0_data_by_mod.values())
            )
            if rms_values:
                row = (task_type, str(round(np.mean(rms_values), 2)))
                rows.append(row)
        table_data = TableData(rows=tuple(rows))
        metric = QualityMetric(
            name="Dataset RMS",
            description="This metric is the calculated root mean square intensity value across data"
            " from an instrument program task type used in the creation of an entire "
            "L1 dataset.",
            metric_code=MetricCode.dataset_rms,
            table_data=[table_data],
        )
        self.write(metric, tags=Tag.quality("GENERIC"), encoder=basemodel_encoder)

    def compute_and_write_frame_average(
        self, segmented_quality_data: dict[str, dict[str, L0QualityData]]
    ) -> None:
        """Compute and write FRAME_AVERAGE quality metric."""
        for task_type, l0_data_by_mod in segmented_quality_data.items():
            warnings_computed = False
            warnings = None
            series_data = {}
            for modstate, l0_data in l0_data_by_mod.items():
                if l0_data.has_values:
                    # only compute warnings for the first modstate encountered
                    if not warnings_computed:
                        warnings = self._format_warnings(
                            self._find_iqr_outliers(
                                datetimes=l0_data.datetimes, values=l0_data.average_values
                            )
                        )
                        warnings_computed = True
                    time_series = TimeSeriesData(
                        x_values=l0_data.datetimes,
                        y_values=l0_data.average_values,
                    )
                    # for this task type AND modstate
                    series_data[modstate] = time_series

            # don't write anything if there is no data for the task type
            if not series_data:
                continue

            xy_data = XYData(
                xlabel="Time",
                ylabel="Average Value (adu / sec)",
                series_data=series_data,
                series_name="Modstate",
            )
            metric = QualityMetric(
                name=f"Average Across Frame - {task_type.upper()}",
                description=f"Average intensity value across frames of task type {task_type}. One measurement is taken per frame in each task type.",
                metric_code=MetricCode.frame_average,
                facet=task_type.upper(),
                plot_data=[xy_data],
                warnings=warnings,
            )
            self.write(metric, tags=Tag.quality("GENERIC"), encoder=basemodel_encoder)

    def compute_and_write_frame_rms(
        self, segmented_quality_data: dict[str, dict[str, L0QualityData]]
    ) -> None:
        """Compute and write FRAME_RMS quality metric."""
        for task_type, l0_data_by_mod in segmented_quality_data.items():
            warnings_computed = False
            warnings = None
            series_data = {}
            for modstate, l0_data in l0_data_by_mod.items():
                if l0_data.has_values:
                    # only compute warnings for the first modstate encountered
                    if not warnings_computed:
                        warnings = self._format_warnings(
                            self._find_iqr_outliers(
                                datetimes=l0_data.datetimes, values=l0_data.rms_values
                            )
                        )
                        warnings_computed = True
                    time_series = TimeSeriesData(
                        x_values=l0_data.datetimes,
                        y_values=l0_data.rms_values,
                    )
                    # for this task type AND modstate
                    series_data[modstate] = time_series

            # don't write anything if there is no data for the task type
            if not series_data:
                continue

            xy_data = XYData(
                xlabel="Time",
                ylabel="RMS (adu / sec)",
                series_data=series_data,
                series_name="Modstate",
            )
            metric = QualityMetric(
                name=f"Root Mean Square (RMS) Across Frame - {task_type.upper()}",
                description=f"RMS value across frames of task type {task_type}. One measurement is taken per frame in each task type.",
                metric_code=MetricCode.frame_rms,
                facet=task_type.upper(),
                plot_data=[xy_data],
                warnings=warnings,
            )
            self.write(metric, tags=Tag.quality("GENERIC"), encoder=basemodel_encoder)


class L1QualityData(QualityModel):
    """Intermediate L1 Quality Data gleaned from collection of L1QualityFitsAccess."""

    # by default, a tuple accepts a list as input
    # the use of tuples is intentional because list mutations do not trigger validation
    # the impact is that L1QualityData should not be instantiated until
    # after the tuple input has been fully accumulated
    # when `mode="json"`, the output of a tuple results in a list
    # when `mode="python"`, the output of a tuple results in a tuple
    datetimes: tuple[datetime, ...]
    # NOTE:  FiniteFloat will fail fast for `nan` and `inf`
    light_level_values: tuple[FiniteFloat, ...]
    health_status_values: tuple[str, ...]
    # NOTE:  FiniteFloat will fail fast for `nan` and `inf`
    fried_parameter_values: tuple[FiniteFloat, ...]
    ao_lock_values: tuple[bool | None, ...]
    ao_oob_values: tuple[int | None, ...]

    @model_validator(mode="after")
    def tuple_validation(self):
        """Validate tuple lengths."""
        error_message = [f"{len(self.datetimes)=}"]
        datetime_len = len(self.datetimes)
        if len(self.light_level_values) != datetime_len:
            error_message.append(f"{len(self.light_level_values)=}")
        if len(self.health_status_values) != datetime_len:
            error_message.append(f"{len(self.health_status_values)=}")
        if len(self.fried_parameter_values) != datetime_len:
            error_message.append(f"{len(self.fried_parameter_values)=}")
        if len(self.ao_lock_values) != datetime_len:
            error_message.append(f"{len(self.ao_lock_values)=}")
        if len(self.ao_oob_values) != datetime_len:
            error_message.append(f"{len(self.ao_oob_values)=}")
        if len(error_message) > 1:
            raise ValueError(
                f"One or more dimensions have wrong length: {', '.join(error_message)}. "
            )
        return self


class QualityL1Metrics(WorkflowTaskBase, QualityMixin):
    """Task class supporting the generation of quality metrics for the L1 data."""

    def run(self) -> None:
        """Run method for this task."""
        with self.telemetry_span("Reading L1 frames"):
            l1_quality_data = self.collect_l1_quality_data()

        with self.telemetry_span("Writing L1 quality data"):
            self.compute_and_write_l1_quality_metrics(l1_quality_data)

    def collect_l1_quality_data(self) -> L1QualityData:
        """Collect data used to compute L1 quality metrics."""
        frames = self.read(
            tags=[Tag.calibrated(), Tag.frame()],
            decoder=fits_access_decoder,
            fits_access_class=L1QualityFitsAccess,
        )

        # sort by datetime
        sorted_frames = sorted(frames, key=lambda f: datetime.fromisoformat(f.time_obs))

        return L1QualityData(
            # DATE-BEG
            datetimes=tuple(datetime.fromisoformat(f.time_obs) for f in sorted_frames),
            # LIGHTLVL
            light_level_values=tuple(f.light_level for f in sorted_frames),
            # DSHEALTH
            health_status_values=tuple(f.health_status for f in sorted_frames),
            # ATMOS_R0
            fried_parameter_values=tuple(f.fried_parameter for f in sorted_frames),
            # AO_LOCK
            ao_lock_values=tuple(f.ao_status for f in sorted_frames),
            # OOBSHIFT
            ao_oob_values=tuple(f.num_out_of_bounds_ao_values for f in sorted_frames),
        )

    def compute_and_write_l1_quality_metrics(self, l1_quality_data: L1QualityData) -> None:
        """Write L1 metrics to disk."""
        self.compute_and_write_ao_status(l1_quality_data)
        self.compute_and_write_fried_parameter(l1_quality_data)
        self.compute_and_write_health_status(l1_quality_data)
        self.compute_and_write_light_level(l1_quality_data)

    def compute_and_write_ao_status(self, l1_quality_data: L1QualityData) -> None:
        """Write AO_STATUS quality metric."""
        ao_not_none = [ao for ao in l1_quality_data.ao_lock_values if ao is not None]

        # don't write anything if there is no data
        if not ao_not_none:
            return

        percentage = round(100 * np.count_nonzero(ao_not_none) / len(ao_not_none), 1)

        metric = QualityMetric(
            name="Adaptive Optics Status",
            description="This metric shows the percentage of frames in which the adaptive optics "
            "system was running and locked",
            metric_code=MetricCode.ao_status,
            statement=[
                f"The adaptive optics system was running and locked for {percentage}% of the observed frames"
            ],
        )

        self.write(metric, tags=Tag.quality("GENERIC"), encoder=basemodel_encoder)

    def compute_and_write_fried_parameter(self, l1_quality_data: L1QualityData) -> None:
        """Write FRIED_PARAMETER quality metric."""
        datetimes = l1_quality_data.datetimes
        fried_parameter_values = l1_quality_data.fried_parameter_values
        ao_lock_values = l1_quality_data.ao_lock_values
        ao_oob_values = l1_quality_data.ao_oob_values

        fried_values_to_plot = []
        datetimes_to_plot = []
        # For each set of input data, check if the r0 is considered valid based on all data
        for i in range(len(fried_parameter_values)):
            if r0_valid(
                r0=fried_parameter_values[i],
                ao_lock=ao_lock_values[i],
                num_out_of_bounds_ao_values=ao_oob_values[i],
            ):
                datetimes_to_plot.append(datetimes[i])
                fried_values_to_plot.append(fried_parameter_values[i])

        if len(fried_values_to_plot) == 0:
            # don't write anything if there is no data
            return

        time_series = TimeSeriesData(
            x_values=tuple(datetimes_to_plot),
            y_values=tuple(fried_values_to_plot),
        )

        series_data = {"": time_series}

        xy_data = XYData(
            xlabel="Time",
            ylabel="Fried Parameter (m)",
            ylim=(0.0, 0.2),
            series_data=series_data,
        )

        statement = (
            f"Average valid Fried Parameter measurements for L1 dataset: "
            f"{round(np.mean(fried_values_to_plot), 2)} ± {round(np.std(fried_values_to_plot), 2)} m"
        )

        metric = QualityMetric(
            name="Fried Parameter",
            description="This metric quantifies the stability of the atmosphere during an "
            "observation and directly impacts the data quality through a phenomenon "
            "known as atmospheric seeing. One measurement is taken per L1 frame. "
            "Only measurements taken while the AO system is locked are valid.",
            metric_code=MetricCode.fried_parameter,
            plot_data=[xy_data],
            statement=[statement],
        )

        self.write(metric, tags=Tag.quality("GENERIC"), encoder=basemodel_encoder)

    def compute_and_write_health_status(self, l1_quality_data: L1QualityData) -> None:
        """Write HEALTH_STATUS quality metric."""
        # don't need to check for None -  l1_quality_data.health_status_values does not allow None
        health_status_values = l1_quality_data.health_status_values

        # don't write anything if there is no data
        if not health_status_values:
            return

        statuses, counts = np.unique(health_status_values, return_counts=True)
        # individual elements to lower case, with side effect of switch from numpy.ndarray to list
        statuses = [s.lower() for s in statuses]
        # individual elements from int to str, with side effect of switch from numpy.ndarray to list
        counts = [str(c) for c in counts]

        header = ("Status", "Count")
        rows = [header]
        rows.extend(tuple(z) for z in zip(statuses, counts))
        table_data = TableData(rows=tuple(rows))

        warnings = None
        if any(s in statuses for s in ["bad", "ill", "unknown"]):
            warnings = [
                "Data sourced from components with a health status of 'ill', 'bad', or 'unknown'."
            ]

        metric = QualityMetric(
            name="Data Source Health",
            description="This metric contains the worst health status of the data source during "
            "data acquisition. One reading is taken per L1 frame.",
            metric_code=MetricCode.health_status,
            table_data=[table_data],
            warnings=warnings,
        )

        self.write(metric, tags=Tag.quality("GENERIC"), encoder=basemodel_encoder)

    def compute_and_write_light_level(self, l1_quality_data: L1QualityData) -> None:
        """Write LIGHT_LEVEL quality metric."""
        # don't need to check for None -  l1_quality_data.light_level_values does not allow None
        datetimes = l1_quality_data.datetimes
        light_level_values = l1_quality_data.light_level_values

        # don't write anything if there is no data
        if not light_level_values:
            return

        time_series = TimeSeriesData(
            x_values=datetimes,
            y_values=light_level_values,
        )

        series_data = {"": time_series}

        xy_data = XYData(
            xlabel="Time",
            ylabel="Light Level (adu)",
            series_data=series_data,
        )

        statement = f"Average Light Level for L1 dataset: "
        f"{round(np.mean(light_level_values), 2)} ± {round(np.std(light_level_values), 2)} adu"

        metric = QualityMetric(
            name="Light Level",
            description="The telescope light level, as measured by the Telescope Acquisition Camera, "
            "at the start of data acquisition of each frame.",
            metric_code=MetricCode.light_level,
            plot_data=[xy_data],
            statement=[statement],
        )

        self.write(metric, tags=Tag.quality("GENERIC"), encoder=basemodel_encoder)
