"""Tests for the quality tasks."""

from datetime import datetime
from datetime import timedelta
from pathlib import Path
from typing import Sequence

import numpy as np
import pytest
from astropy.io import fits
from astropy.wcs import WCS
from dkist_data_simulator.spec122 import Spec122Dataset
from dkist_data_simulator.spec214 import Spec214Dataset

from dkist_processing_common._util.scratch import WorkflowFileSystem
from dkist_processing_common.codecs.basemodel import basemodel_decoder
from dkist_processing_common.codecs.fits import fits_hdulist_encoder
from dkist_processing_common.models.quality import QualityMetric
from dkist_processing_common.models.quality import TableData
from dkist_processing_common.models.quality import XYData
from dkist_processing_common.models.tags import Tag
from dkist_processing_common.models.task_name import TaskName
from dkist_processing_common.tasks.quality_metrics import L0QualityData
from dkist_processing_common.tasks.quality_metrics import L1QualityData
from dkist_processing_common.tasks.quality_metrics import QualityL0Metrics
from dkist_processing_common.tasks.quality_metrics import QualityL1Metrics


class BaseSpec214l0Dataset(Spec122Dataset):
    def __init__(self, instrument="vbi"):
        super().__init__(
            dataset_shape=(3, 10, 10),
            array_shape=(1, 10, 10),
            time_delta=1,
            instrument=instrument,
            file_schema="level0_spec214",
        )

    @property
    def data(self):
        return np.ones(shape=self.array_shape)


class BaseSpec214Dataset(Spec214Dataset):
    def __init__(self, instrument="vbi"):
        self.array_shape = (10, 10)
        super().__init__(
            dataset_shape=(2, 10, 10),
            array_shape=self.array_shape,
            time_delta=1,
            instrument=instrument,
        )

    @property
    def fits_wcs(self):
        w = WCS(naxis=2)
        w.wcs.crpix = self.array_shape[1] / 2, self.array_shape[0] / 2
        w.wcs.crval = 0, 0
        w.wcs.cdelt = 1, 1
        w.wcs.cunit = "arcsec", "arcsec"
        w.wcs.ctype = "HPLN-TAN", "HPLT-TAN"
        w.wcs.pc = np.identity(self.array_ndim)
        return w


@pytest.fixture(scope="session")
def task_type_options() -> list[str]:
    # note that the length of this list and the dataset size affect how many occurrences there are
    # also note that lamp_gain is not in the list, which limits the results to 3 quality task types
    return [
        TaskName.observe.value,
        TaskName.dark.value,
        TaskName.gain.value,
        TaskName.solar_gain.value,
    ]


@pytest.fixture(params=[TaskName.dark.value, TaskName.gain.value])
def excluded_task_type(request) -> str:
    # used to selectively exclude one task type from task_type_options
    return request.param


@pytest.fixture
def base_spec_214_l0_dataset_factory():
    def factory(task_types) -> list[fits.HDUList]:
        hduls = []
        for ds in BaseSpec214l0Dataset():
            hdu = ds.hdu()
            # overwritten here because you can't add an IPTASK @key_function to the dataset
            task_type_index = ds.index % len(task_types)
            hdu.header["IPTASK"] = task_types[task_type_index]
            hduls.append(fits.HDUList([hdu]))
        return hduls

    return factory


@pytest.fixture(
    params=[pytest.param(None, id="No_modstates"), pytest.param(range(1, 4), id="With_modstates")]
)
def modstate_option(request) -> Sequence[int] | None:
    return request.param


@pytest.fixture
def quality_l0_task_class(modstate_option) -> type[QualityL0Metrics]:
    class QualityL0Task(QualityL0Metrics):
        @property
        def modstate_list(self) -> Sequence[int] | None:
            return modstate_option

    return QualityL0Task


@pytest.fixture
def quality_l0_task(
    recipe_run_id: int,
    tmp_path: Path,
    quality_l0_task_class: type[QualityL0Metrics],
) -> QualityL0Metrics:
    with quality_l0_task_class(
        recipe_run_id=recipe_run_id,
        workflow_name="workflow_name",
        workflow_version="workflow_version",
    ) as task:
        task.scratch = WorkflowFileSystem(scratch_base_path=tmp_path, recipe_run_id=recipe_run_id)
        yield task
        task._purge()


@pytest.fixture
def quality_l0_task_with_three_task_types(
    quality_l0_task,
    task_type_options: list[str],
    modstate_option: Sequence[int] | None,
    base_spec_214_l0_dataset_factory,
):
    modstate_list = modstate_option if modstate_option is not None else [None]
    # task_type_options does not include LAMP_GAIN
    hduls = base_spec_214_l0_dataset_factory(task_type_options)
    for t in task_type_options:
        for m in modstate_list:
            tags = [Tag.input(), Tag.task(t)]
            if m is not None:
                tags.append(Tag.modstate(m))
            for hdul in hduls:
                quality_l0_task.write(data=hdul, tags=tags, encoder=fits_hdulist_encoder)

    return quality_l0_task


@pytest.fixture
def quality_l0_task_with_two_task_types(
    quality_l0_task,
    task_type_options: list[str],
    base_spec_214_l0_dataset_factory,
    excluded_task_type: str,
    modstate_option: Sequence[int] | None,
):
    task_types = [t for t in task_type_options if t != excluded_task_type]
    modstate_list = modstate_option if modstate_option is not None else [None]
    hduls = base_spec_214_l0_dataset_factory(task_types)
    for t in task_types:
        for m in modstate_list:
            tags = [Tag.input(), Tag.task(t)]
            if m is not None:
                tags.append(Tag.modstate(m))
            for hdul in hduls:
                quality_l0_task.write(data=hdul, tags=tags, encoder=fits_hdulist_encoder)
    return quality_l0_task


@pytest.fixture
def dataset_metric_codes() -> list[str]:
    return ["DATASET_AVERAGE", "DATASET_RMS"]


@pytest.fixture
def frame_metric_codes() -> list[str]:
    return ["FRAME_AVERAGE", "FRAME_RMS"]


def test_collect_l0_quality_data(
    quality_l0_task_with_three_task_types,
    task_type_options: list[str],
    modstate_option: Sequence[int] | None,
):
    """
    Given: input frames for OBSERVE, DARK, GAIN and SOLAR_GAIN IP task types (with and without modstates)
    When: intermediate L0 quality data is collected
    Then: all L0 quality data gets stored in a dict with L0QualityData
    """
    # Given
    task = quality_l0_task_with_three_task_types
    modstate_list = modstate_option if modstate_option is not None else [None]
    # When
    segmented_quality_data = task.collect_l0_quality_data()
    # Then
    assert segmented_quality_data
    assert isinstance(segmented_quality_data, dict)
    # task.quality_task_types includes LAMP_GAIN
    for task in task.quality_task_types:
        assert task in segmented_quality_data
        task_data_by_modstate = segmented_quality_data[task]
        if modstate_option is None:
            # single modstate entry for the task
            assert len(task_data_by_modstate) == 1
            # and the key is empty string
            assert "" in task_data_by_modstate
        else:
            # one entry for each modstate
            assert len(task_data_by_modstate) == len(modstate_option)
            for modstate in modstate_list:
                assert task_data_by_modstate[str(modstate)]
        for modstate, l0_quality_data in task_data_by_modstate.items():
            assert isinstance(l0_quality_data, L0QualityData)
            # one entry for each FITS file of task type and modstate
            if task in task_type_options:
                assert len(l0_quality_data.datetimes) == 3
                assert len(l0_quality_data.average_values) == 3
                assert len(l0_quality_data.rms_values) == 3
            else:
                assert len(l0_quality_data.datetimes) == 0
                assert len(l0_quality_data.average_values) == 0
                assert len(l0_quality_data.rms_values) == 0


def test_l0_quality_metrics(
    quality_l0_task_with_three_task_types,
    modstate_option: Sequence[int] | None,
    dataset_metric_codes: list[str],
    frame_metric_codes: list[str],
):
    """
    Given: input frames for OBSERVE, DARK, GAIN and SOLAR_GAIN IP task types (with and without modstates)
    When: QualityL0Metrics workflow task is run
    Then: all L0 metrics get created and each is encoded as a QualityMetric BaseModel
    """
    # call task and assert that things were created (tagged files on disk with quality metric info in them)
    # Given
    task = quality_l0_task_with_three_task_types
    # When
    task()
    # Then
    tags = [Tag.quality("GENERIC")]
    metrics: list[QualityMetric] = list(
        task.read(tags=tags, decoder=basemodel_decoder, model=QualityMetric)
    )
    dataset_metrics = [metric for metric in metrics if metric.metric_code in dataset_metric_codes]
    frame_metrics = [metric for metric in metrics if metric.metric_code in frame_metric_codes]
    # 2 metrics, no segregation by task
    assert len(dataset_metrics) == 2
    # 2 metrics, 3 task types (no LAMP_GAIN)
    assert len(frame_metrics) == 2 * 3
    for metric in metrics:
        assert isinstance(metric, QualityMetric)
        assert metric.metric_code
        assert metric.name
        assert metric.description
        if metric.metric_code in dataset_metric_codes:
            assert metric.facet is None
            all_table_data = metric.table_data
            assert isinstance(all_table_data, list)
            assert len(all_table_data) == 1
            for table_data in all_table_data:
                assert isinstance(table_data, TableData)
                rows = table_data.rows
                assert isinstance(rows, tuple)
                # header + 3 task types
                assert len(rows) == 4
                for row in rows:
                    assert isinstance(row, tuple)
                    for col in row:
                        assert isinstance(col, str)
        elif metric.metric_code in frame_metric_codes:
            assert metric.facet
            all_plot_data = metric.plot_data
            assert isinstance(all_plot_data, list)
            assert len(all_plot_data) == 1
            for plot_data in all_plot_data:
                assert isinstance(plot_data, XYData)
                assert plot_data.series_data
                assert isinstance(plot_data.series_data, dict)
                for modstate, time_series in plot_data.series_data.items():
                    assert modstate == "" or int(modstate) in modstate_option
                    assert time_series.x_values
                    assert time_series.y_values
                    assert all(isinstance(val, datetime) for val in time_series.x_values)
                    assert all(isinstance(val, float) for val in time_series.y_values)
                    assert len(time_series.x_values) == len(time_series.y_values)
        else:
            raise RuntimeError(f"Unexpected metric code: {metric.metric_code!r}")


def test_l0_quality_metrics_with_two_task_types(
    quality_l0_task_with_two_task_types,
    excluded_task_type: str,
    dataset_metric_codes: list[str],
    frame_metric_codes: list[str],
):
    """
    Given: input frames for various IP task types (with and without modstates)
    When: QualityL0Metrics workflow task is run
    Then: proper L0 metrics get created and each is encoded as a QualityMetric BaseModel
    """
    # Given
    task = quality_l0_task_with_two_task_types
    # When
    task()
    # Then
    tags = [Tag.quality("GENERIC")]
    metrics: list[QualityMetric] = list(
        task.read(tags=tags, decoder=basemodel_decoder, model=QualityMetric)
    )
    dataset_metrics = [metric for metric in metrics if metric.metric_code in dataset_metric_codes]
    frame_metrics = [metric for metric in metrics if metric.metric_code in frame_metric_codes]
    # 2 metrics, no segregation by task
    assert len(dataset_metrics) == 2
    # 2 metrics, 2 task types (no LAMP_GAIN or excluded task type)
    assert len(frame_metrics) == 2 * 2
    # no metrics for the excluded task type
    assert not any(metric.facet == excluded_task_type for metric in frame_metrics)
    # but produced a metric for at least one of the other task types
    assert any(metric.facet != excluded_task_type for metric in frame_metrics)


def test_compute_and_write_dataset_average(quality_l0_task: QualityL0Metrics):
    """
    Given: properly structured L0 quality data
    When: executing QualityL0Metrics.compute_and_write_dataset_average()
    Then: writes one DATASET_AVERAGE QualityMetric
    """
    # Given
    task = quality_l0_task
    start = datetime.now()
    datetimes = tuple([start + timedelta(milliseconds=i) for i in range(5)])
    rms_values = tuple(range(1, 6))
    segmented_quality_data: dict[str, dict[str, L0QualityData]] = {
        "DARK": {
            "1": L0QualityData(
                datetimes=datetimes,
                average_values=(1, 5, 3, 4, 6),
                rms_values=rms_values,
            ),
            "2": L0QualityData(
                datetimes=datetimes,
                average_values=(1, 9, 4, 7, 2),
                rms_values=rms_values,
            ),
        },
        "GAIN": {
            "1": L0QualityData(
                datetimes=datetimes,
                average_values=(5, 8, 3, 7, 8),
                rms_values=rms_values,
            ),
        },
    }
    # When
    task.compute_and_write_dataset_average(segmented_quality_data)
    # Then
    tags = [Tag.quality("GENERIC")]
    metrics: list[QualityMetric] = list(
        task.read(tags=tags, decoder=basemodel_decoder, model=QualityMetric)
    )
    assert len(metrics) == 1
    # basics
    assert metrics[0].metric_code == "DATASET_AVERAGE"
    assert metrics[0].facet is None
    assert metrics[0].name == "Average Across Dataset"
    assert metrics[0].description
    assert metrics[0].statement is None
    assert metrics[0].warnings is None
    # data
    all_table_data = metrics[0].table_data
    assert all_table_data
    assert isinstance(all_table_data, list)
    assert len(all_table_data) == 1
    table_data = all_table_data[0]
    assert isinstance(table_data, TableData)
    rows = table_data.rows
    assert isinstance(rows, tuple)
    # header, dark, gain
    assert len(rows) == 3
    header = rows[0]
    assert header[0] == "Task Type"
    assert header[1] == "Dataset Average (adu / sec)"
    assert any(t[0] == "DARK" for t in rows[1:])
    assert any(t[0] == "GAIN" for t in rows[1:])
    for row in rows[1:]:
        if row[0] == "DARK":
            assert row[1] == str(4.2)
        if row[0] == "GAIN":
            assert row[1] == str(6.2)


def test_compute_and_write_dataset_rms(quality_l0_task: QualityL0Metrics):
    """
    Given: properly structured L0 quality data
    When: executing QualityL0Metrics.compute_and_write_dataset_rms()
    Then: writes one DATASET_RMS QualityMetric
    """
    # Given
    task = quality_l0_task
    start = datetime.now()
    datetimes = tuple([start + timedelta(milliseconds=i) for i in range(5)])
    average_values = tuple(range(1, 6))
    segmented_quality_data: dict[str, dict[str, L0QualityData]] = {
        "DARK": {
            "1": L0QualityData(
                datetimes=datetimes,
                average_values=average_values,
                rms_values=(1, 5, 3, 4, 6),
            ),
            "2": L0QualityData(
                datetimes=datetimes,
                average_values=average_values,
                rms_values=(1, 9, 4, 7, 2),
            ),
        },
        "GAIN": {
            "1": L0QualityData(
                datetimes=datetimes,
                average_values=average_values,
                rms_values=(5, 8, 3, 7, 8),
            ),
        },
    }
    # When
    task.compute_and_write_dataset_rms(segmented_quality_data)
    # Then
    tags = [Tag.quality("GENERIC")]
    metrics: list[QualityMetric] = list(
        task.read(tags=tags, decoder=basemodel_decoder, model=QualityMetric)
    )
    assert len(metrics) == 1
    # basics
    assert metrics[0].metric_code == "DATASET_RMS"
    assert metrics[0].facet is None
    assert metrics[0].name == "Dataset RMS"
    assert metrics[0].description
    assert metrics[0].statement is None
    assert metrics[0].warnings is None
    # data
    all_table_data = metrics[0].table_data
    assert all_table_data
    assert isinstance(all_table_data, list)
    assert len(all_table_data) == 1
    table_data = all_table_data[0]
    assert isinstance(table_data, TableData)
    rows = table_data.rows
    assert isinstance(rows, tuple)
    # header, dark, gain
    assert len(rows) == 3
    header = rows[0]
    assert header[0] == "Task Type"
    assert header[1] == "Dataset RMS (adu / sec)"
    assert any(t[0] == "DARK" for t in rows[1:])
    assert any(t[0] == "GAIN" for t in rows[1:])
    for row in rows[1:]:
        if row[0] == "DARK":
            assert row[1] == str(4.2)
        if row[0] == "GAIN":
            assert row[1] == str(6.2)


def test_compute_and_write_frame_average(quality_l0_task: QualityL0Metrics):
    """
    Given: properly structured L0 quality data
    When: executing QualityL0Metrics.compute_and_write_frame_average()
    Then: writes one FRAME_AVERAGE QualityMetric for each task type
    """
    # Given
    task = quality_l0_task
    start = datetime.now()
    datetimes = tuple([start + timedelta(milliseconds=i) for i in range(5)])
    rms_values = tuple(range(1, 6))
    segmented_quality_data: dict[str, dict[str, L0QualityData]] = {
        "DARK": {
            "1": L0QualityData(
                datetimes=datetimes,
                # these values will trigger an IQR warning
                average_values=(1, 8, 9, 8, 9),
                rms_values=rms_values,
            ),
            "2": L0QualityData(
                datetimes=datetimes,
                average_values=(2, 2, 2, 2, 2),
                rms_values=rms_values,
            ),
        },
        "GAIN": {
            "1": L0QualityData(
                datetimes=datetimes,
                average_values=(5, 8, 3, 7, 8),
                rms_values=rms_values,
            ),
        },
    }
    # When
    task.compute_and_write_frame_average(segmented_quality_data)
    # Then
    tags = [Tag.quality("GENERIC")]
    metrics: list[QualityMetric] = list(
        task.read(tags=tags, decoder=basemodel_decoder, model=QualityMetric)
    )
    assert len(metrics) == 2
    for metric in metrics:
        # basics
        assert metric.metric_code == "FRAME_AVERAGE"
        assert metric.facet in ["DARK", "GAIN"]
        assert metric.name == f"Average Across Frame - {metric.facet.upper()}"
        assert metric.description
        assert metric.statement is None
        if metric.facet == "DARK":
            assert metric.warnings
            assert isinstance(metric.warnings, list)
            assert len(metric.warnings) == 1
            assert metric.warnings[0].startswith("File with datetime")
        else:
            assert metric.warnings is None
        # data
        all_plot_data = metric.plot_data
        assert all_plot_data
        assert isinstance(all_plot_data, list)
        assert len(all_plot_data) == 1
        plot_data = all_plot_data[0]
        assert isinstance(plot_data, XYData)
        assert plot_data.xlabel
        assert plot_data.ylabel
        assert plot_data.series_data
        assert isinstance(plot_data.series_data, dict)
        for modstate, xy_data in plot_data.series_data.items():
            assert xy_data.x_values == datetimes
            assert all(isinstance(x, datetime) for x in xy_data.x_values)
            assert xy_data.y_values == segmented_quality_data[metric.facet][modstate].average_values
            assert all(isinstance(y, float) for y in xy_data.y_values)
            assert len(xy_data.x_values) == len(xy_data.y_values)


def test_compute_and_write_frame_rms(quality_l0_task: QualityL0Metrics):
    """
    Given: properly structured L0 quality data
    When: executing QualityL0Metrics.compute_and_write_frame_rms()
    Then: writes one FRAME_RMS QualityMetric for each task type
    """
    # Given
    task = quality_l0_task
    start = datetime.now()
    datetimes = tuple([start + timedelta(milliseconds=i) for i in range(5)])
    average_values = tuple(range(1, 6))
    segmented_quality_data: dict[str, dict[str, L0QualityData]] = {
        "DARK": {
            "1": L0QualityData(
                datetimes=datetimes,
                average_values=average_values,
                # these values will trigger an IQR warning
                rms_values=(1, 8, 9, 8, 9),
            ),
            "2": L0QualityData(
                datetimes=datetimes,
                average_values=average_values,
                rms_values=(2, 2, 2, 2, 2),
            ),
        },
        "GAIN": {
            "": L0QualityData(
                datetimes=datetimes,
                average_values=average_values,
                rms_values=(5, 8, 3, 7, 8),
            ),
        },
    }
    # When
    task.compute_and_write_frame_rms(segmented_quality_data)
    # Then
    tags = [Tag.quality("GENERIC")]
    metrics: list[QualityMetric] = list(
        task.read(tags=tags, decoder=basemodel_decoder, model=QualityMetric)
    )
    assert len(metrics) == 2
    for metric in metrics:
        # basics
        assert metric.metric_code == "FRAME_RMS"
        assert metric.facet in ["DARK", "GAIN"]
        assert metric.name == f"Root Mean Square (RMS) Across Frame - {metric.facet.upper()}"
        assert metric.description
        assert metric.statement is None
        if metric.facet == "DARK":
            assert metric.warnings
            assert isinstance(metric.warnings, list)
            assert len(metric.warnings) == 1
            assert metric.warnings[0].startswith("File with datetime")
        else:
            assert metric.warnings is None
        # data
        all_plot_data = metric.plot_data
        assert all_plot_data
        assert isinstance(all_plot_data, list)
        assert len(all_plot_data) == 1
        plot_data = all_plot_data[0]
        assert isinstance(plot_data, XYData)
        assert plot_data.xlabel
        assert plot_data.ylabel
        assert plot_data.series_data
        assert isinstance(plot_data.series_data, dict)
        for modstate, xy_data in plot_data.series_data.items():
            assert xy_data.x_values == datetimes
            assert all(isinstance(x, datetime) for x in xy_data.x_values)
            assert xy_data.y_values == segmented_quality_data[metric.facet][modstate].rms_values
            assert all(isinstance(y, float) for y in xy_data.y_values)
            assert len(xy_data.x_values) == len(xy_data.y_values)


@pytest.fixture
def quality_l1_task_no_scratch_data(
    recipe_run_id: int,
    tmp_path: Path,
) -> QualityL1Metrics:
    with QualityL1Metrics(
        recipe_run_id=recipe_run_id,
        workflow_name="workflow_name",
        workflow_version="workflow_version",
    ) as task:
        task.scratch = WorkflowFileSystem(scratch_base_path=tmp_path, recipe_run_id=recipe_run_id)
        yield task
        task._purge()


@pytest.fixture
def calibrated_frame_count() -> int:
    return 10


@pytest.fixture
def quality_l1_task_with_calibrated_frames(
    quality_l1_task_no_scratch_data: QualityL1Metrics,
    calibrated_frame_count: int,
) -> QualityL1Metrics:
    task_with_calibrated_frames = quality_l1_task_no_scratch_data
    for i in range(calibrated_frame_count):
        header_dict = [
            d.header(required_only=False, expected_only=False) for d in BaseSpec214Dataset()
        ][0]
        data = np.ones(shape=BaseSpec214Dataset().array_shape)
        hdu = fits.PrimaryHDU(data=data, header=fits.Header(header_dict))
        hdul = fits.HDUList([hdu])
        task_with_calibrated_frames.write(
            data=hdul, tags=[Tag.calibrated(), Tag.frame()], encoder=fits_hdulist_encoder
        )
    return task_with_calibrated_frames


@pytest.fixture
def l1_quality_data() -> L1QualityData:
    """L1QualityData for the test cases"""
    start = datetime.now()
    datetimes = tuple([start + timedelta(milliseconds=i) for i in range(7)])
    light_level_values = tuple([0.15, 0.25, 0.35, 0.45, 0.55, 0.65, 0.75])
    health_status_values = tuple(["Good", "Unknown", "Bad", "Ill", "Good", "Good", "Good"])
    #  [4] gets excluded from FRIED_PARAMETER metric because > 0.3
    fried_parameter_values = tuple([0.3, 0.2, 0.1, 0.2, 0.31, 0.2, 0.2])
    #  [5] and [6] cause FRIED_PARAMETER metric exclusions because NOT True
    #  [6] gets excluded from AO_STATUS calculation because None
    ao_lock_values = tuple([True, True, True, True, True, False, None])
    #  [3] causes FRIED_PARAMETER metric exclusion because > 100
    ao_oob_values = tuple([100, 50, None, 101, 50, None, 100])
    return L1QualityData(
        datetimes=datetimes,
        light_level_values=light_level_values,
        health_status_values=health_status_values,
        fried_parameter_values=fried_parameter_values,
        ao_lock_values=ao_lock_values,
        ao_oob_values=ao_oob_values,
    )


def test_collect_l1_quality_data(
    quality_l1_task_with_calibrated_frames: QualityL1Metrics,
    calibrated_frame_count: int,
):
    """
    Given: spec 214 compliant calibrated frames
    When: intermediate L1 quality data is collected
    Then: everything gets stored as L1QualityData
    """
    # Given
    task = quality_l1_task_with_calibrated_frames
    # When
    l1_quality_data = task.collect_l1_quality_data()
    # Then
    assert l1_quality_data
    assert isinstance(l1_quality_data, L1QualityData)
    # datetimes
    datetimes = l1_quality_data.datetimes
    assert isinstance(datetimes, tuple)
    assert len(datetimes) == calibrated_frame_count
    assert all(isinstance(dt, datetime) for dt in datetimes)
    # light_level
    light_level_values = l1_quality_data.light_level_values
    assert isinstance(light_level_values, tuple)
    assert len(light_level_values) == calibrated_frame_count
    assert all(isinstance(v, float) for v in light_level_values)
    # health_status
    health_status_values = l1_quality_data.health_status_values
    assert isinstance(health_status_values, tuple)
    assert len(health_status_values) == calibrated_frame_count
    assert all(isinstance(v, str) for v in health_status_values)
    # fried_parameter
    fried_parameter_values = l1_quality_data.fried_parameter_values
    assert isinstance(fried_parameter_values, tuple)
    assert len(fried_parameter_values) == calibrated_frame_count
    assert all(isinstance(v, float) for v in fried_parameter_values)
    # ao_lock
    ao_lock_values = l1_quality_data.ao_lock_values
    assert isinstance(ao_lock_values, tuple)
    assert len(ao_lock_values) == calibrated_frame_count
    assert all(isinstance(v, bool | None) for v in ao_lock_values)
    # ao_oob
    ao_oob_values = l1_quality_data.ao_oob_values
    assert isinstance(ao_oob_values, tuple)
    assert len(ao_oob_values) == calibrated_frame_count
    assert all(isinstance(v, int | None) for v in ao_oob_values)


def test_ao_status(quality_l1_task_with_calibrated_frames: QualityL1Metrics):
    """
    Given: spec 214 compliant calibrated frames
    When: QualityL1Metrics workflow task is run
    Then: a single AO_STATUS metric gets created and is encoded as a QualityMetric BaseModel
    """
    # Given
    task = quality_l1_task_with_calibrated_frames
    # When
    task()
    # Then
    metric_code = "AO_STATUS"
    tags = [Tag.quality("GENERIC")]
    metrics: list[QualityMetric] = list(
        task.read(tags=tags, decoder=basemodel_decoder, model=QualityMetric)
    )
    assert len([metric for metric in metrics if metric.metric_code in metric_code]) == 1
    for metric in metrics:
        if metric.metric_code != metric_code:
            # only inspect AO_STATUS
            continue
        assert isinstance(metric, QualityMetric)
        assert metric.metric_code
        assert metric.facet is None
        assert metric.name
        assert metric.description
        all_statements = metric.statement
        assert all_statements
        assert isinstance(all_statements, list)
        assert len(all_statements) == 1
        assert metric.warnings is None


def test_fried_parameter(
    quality_l1_task_with_calibrated_frames: QualityL1Metrics, calibrated_frame_count: int
):
    """
    Given: spec 214 compliant calibrated frames
    When: QualityL1Metrics workflow task is run
    Then: a single FRIED_PARAMETER metric gets created and is encoded as a QualityMetric BaseModel
    """
    # Given
    task = quality_l1_task_with_calibrated_frames
    # When
    task()
    # Then
    metric_code = "FRIED_PARAMETER"
    tags = [Tag.quality("GENERIC")]
    metrics: list[QualityMetric] = list(
        task.read(tags=tags, decoder=basemodel_decoder, model=QualityMetric)
    )
    assert len([metric for metric in metrics if metric.metric_code in metric_code]) == 1
    for metric in metrics:
        if metric.metric_code != metric_code:
            # only inspect FRIED_PARAMETER
            continue
        assert isinstance(metric, QualityMetric)
        assert metric.metric_code
        assert metric.facet is None
        assert metric.name
        assert metric.description
        all_statements = metric.statement
        assert all_statements
        assert isinstance(all_statements, list)
        assert len(all_statements) == 1
        assert metric.warnings is None
        all_plot_data = metric.plot_data
        assert isinstance(all_plot_data, list)
        assert all_plot_data
        for plot_data in all_plot_data:
            assert isinstance(plot_data, XYData)
            assert plot_data.series_data
            assert isinstance(plot_data.series_data, dict)
            assert len(plot_data.series_data) == 1
            # single time series, with key of empty string
            assert "" in plot_data.series_data
            time_series = plot_data.series_data[""]
            assert time_series.x_values
            assert time_series.y_values
            assert all(isinstance(val, datetime) for val in time_series.x_values)
            assert all(isinstance(val, float) for val in time_series.y_values)
            assert len(time_series.x_values) == len(time_series.y_values)
            # one x-y coordinate for each calibrated frame
            assert len(time_series.x_values) == calibrated_frame_count


def test_health_status(quality_l1_task_with_calibrated_frames: QualityL1Metrics):
    """
    Given: spec 214 compliant calibrated frames
    When: QualityL1Metrics workflow task is run
    Then: a single HEALTH_STATUS metric gets created and is encoded as a QualityMetric BaseModel
    """
    # Given
    task = quality_l1_task_with_calibrated_frames
    # When
    task()
    # Then
    metric_code = "HEALTH_STATUS"
    tags = [Tag.quality("GENERIC")]
    metrics: list[QualityMetric] = list(
        task.read(tags=tags, decoder=basemodel_decoder, model=QualityMetric)
    )
    assert len([metric for metric in metrics if metric.metric_code in metric_code]) == 1
    for metric in metrics:
        if metric.metric_code != metric_code:
            # only inspect HEALTH_STATUS
            continue
        assert isinstance(metric, QualityMetric)
        assert metric.metric_code
        assert metric.facet is None
        assert metric.name
        assert metric.description
        assert metric.statement is None
        # for this test data
        assert metric.warnings is None
        all_table_data = metric.table_data
        assert isinstance(all_table_data, list)
        assert all_table_data
        for table_data in all_table_data:
            assert isinstance(table_data, TableData)
            rows = table_data.rows
            assert isinstance(rows, tuple)
            for row in rows:
                assert isinstance(row, tuple)
                for col in row:
                    assert isinstance(col, str)


def test_light_level(
    quality_l1_task_with_calibrated_frames: QualityL1Metrics, calibrated_frame_count: int
):
    """
    Given: spec 214 compliant calibrated frames
    When: QualityL1Metrics workflow task is run
    Then: a single LIGHT_LEVEL metric gets created and is encoded as a QualityMetric BaseModel
    """
    # Given
    task = quality_l1_task_with_calibrated_frames
    # When
    task()
    # Then
    metric_code = "LIGHT_LEVEL"
    tags = [Tag.quality("GENERIC")]
    metrics: list[QualityMetric] = list(
        task.read(tags=tags, decoder=basemodel_decoder, model=QualityMetric)
    )
    assert len([metric for metric in metrics if metric.metric_code in metric_code]) == 1
    for metric in metrics:
        if metric.metric_code != metric_code:
            # only inspect LIGHT_LEVEL
            continue
        assert isinstance(metric, QualityMetric)
        assert metric.metric_code
        assert metric.facet is None
        assert metric.name
        assert metric.description
        all_statements = metric.statement
        assert all_statements
        assert isinstance(all_statements, list)
        assert len(all_statements) == 1
        assert metric.warnings is None
        all_plot_data = metric.plot_data
        assert isinstance(all_plot_data, list)
        assert all_plot_data
        for plot_data in all_plot_data:
            assert isinstance(plot_data, XYData)
            assert plot_data.series_data
            assert isinstance(plot_data.series_data, dict)
            assert len(plot_data.series_data) == 1
            # single time series, with key of empty string
            assert "" in plot_data.series_data
            time_series = plot_data.series_data[""]
            assert time_series.x_values
            assert time_series.y_values
            assert all(isinstance(val, datetime) for val in time_series.x_values)
            assert all(isinstance(val, float) for val in time_series.y_values)
            assert len(time_series.x_values) == len(time_series.y_values)
            # one x-y coordinate for each calibrated frame
            assert len(time_series.x_values) == calibrated_frame_count


def test_compute_and_write_ao_status(
    quality_l1_task_no_scratch_data: QualityL1Metrics, l1_quality_data: L1QualityData
):
    """
    Given: properly structured L1 quality data
    When: executing QualityL1Metrics.compute_and_write_ao_status()
    Then: writes one AO_STATUS QualityMetric
    """
    # Given
    task = quality_l1_task_no_scratch_data
    # When
    task.compute_and_write_ao_status(l1_quality_data)
    # Then
    tags = [Tag.quality("GENERIC")]
    metrics: list[QualityMetric] = list(
        task.read(tags=tags, decoder=basemodel_decoder, model=QualityMetric)
    )
    assert len(metrics) == 1
    metric = metrics[0]
    # basics
    assert metric.metric_code == "AO_STATUS"
    assert metric.facet is None
    assert metric.name == "Adaptive Optics Status"
    assert metric.description.startswith(
        "This metric shows the percentage of frames in which the adaptive optics"
    )
    all_statements = metric.statement
    assert isinstance(all_statements, list)
    assert len(all_statements) == 1
    # 5/6 = 0.833
    assert all_statements[0].startswith(
        "The adaptive optics system was running and locked for 83.3%"
    )
    assert metric.warnings is None
    # no data for AO_STATUS metric


def test_compute_and_write_fried_parameter(
    quality_l1_task_no_scratch_data: QualityL1Metrics, l1_quality_data: L1QualityData
):
    """
    Given: properly structured L1 quality data
    When: executing QualityL1Metrics.compute_and_write_fried_parameter()
    Then: writes one FRIED_PARAMETER QualityMetric
    """
    # Given
    task = quality_l1_task_no_scratch_data
    # When
    task.compute_and_write_fried_parameter(l1_quality_data)
    # Then
    tags = [Tag.quality("GENERIC")]
    metrics: list[QualityMetric] = list(
        task.read(tags=tags, decoder=basemodel_decoder, model=QualityMetric)
    )
    assert len(metrics) == 1
    metric = metrics[0]
    # basics
    assert metric.metric_code == "FRIED_PARAMETER"
    assert metric.facet is None
    assert metric.name == "Fried Parameter"
    assert metric.description.startswith("This metric quantifies the stability of the atmosphere")
    all_statements = metric.statement
    assert isinstance(all_statements, list)
    assert len(all_statements) == 1
    assert all_statements[0].startswith("Average valid Fried Parameter measurements for L1 dataset")
    # mean precedes ±
    assert "0.2" in all_statements[0].split("±")[0]
    # standard deviation is after ±
    assert "0.08" in all_statements[0].split("±")[1]
    assert metric.warnings is None
    # data
    all_plot_data = metric.plot_data
    assert all_plot_data
    assert isinstance(all_plot_data, list)
    assert len(all_plot_data) == 1
    plot_data = all_plot_data[0]
    assert isinstance(plot_data, XYData)
    assert plot_data.xlabel == "Time"
    assert plot_data.ylabel == "Fried Parameter (m)"
    assert plot_data.series_data
    assert isinstance(plot_data.series_data, dict)
    assert len(plot_data.series_data) == 1
    # single time series, with key of empty string
    assert "" in plot_data.series_data
    time_series = plot_data.series_data[""]
    assert time_series.x_values
    assert time_series.y_values
    assert all(isinstance(val, datetime) for val in time_series.x_values)
    assert all(isinstance(val, float) for val in time_series.y_values)
    assert len(time_series.x_values) == len(time_series.y_values)
    # only the first 3 result in fried parameter values
    assert len(time_series.x_values) == 3


def test_compute_and_write_health_status(
    quality_l1_task_no_scratch_data: QualityL1Metrics, l1_quality_data: L1QualityData
):
    """
    Given: properly structured L1 quality data
    When: executing QualityL1Metrics.compute_and_write_health_status()
    Then: writes one HEALTH_STATUS QualityMetric
    """
    # Given
    task = quality_l1_task_no_scratch_data
    # When
    task.compute_and_write_health_status(l1_quality_data)
    # Then
    tags = [Tag.quality("GENERIC")]
    metrics: list[QualityMetric] = list(
        task.read(tags=tags, decoder=basemodel_decoder, model=QualityMetric)
    )
    assert len(metrics) == 1
    metric = metrics[0]
    # basics
    assert metric.metric_code == "HEALTH_STATUS"
    assert metric.facet is None
    assert metric.name == "Data Source Health"
    assert metric.description.startswith(
        "This metric contains the worst health status of the data source"
    )
    assert metric.statement is None
    all_warnings = metric.warnings
    assert isinstance(all_warnings, list)
    assert len(all_warnings) == 1
    assert all_warnings[0].startswith("Data sourced from components with a health status of")
    # data
    all_table_data = metric.table_data
    assert all_table_data
    assert isinstance(all_table_data, list)
    assert len(all_table_data) == 1
    table_data = all_table_data[0]
    assert isinstance(table_data, TableData)
    rows = table_data.rows
    assert isinstance(rows, tuple)
    # header, good, ill, bad, unknown
    assert len(rows) == 5
    header = rows[0]
    assert header[0] == "Status"
    assert header[1] == "Count"
    assert any(t[0] == "good" for t in rows[1:])
    assert any(t[0] == "ill" for t in rows[1:])
    assert any(t[0] == "bad" for t in rows[1:])
    assert any(t[0] == "unknown" for t in rows[1:])
    for row in rows[1:]:
        if row[0] == "good":
            assert row[1] == str(4)
        else:
            assert row[1] == str(1)


def test_compute_and_write_light_level(
    quality_l1_task_no_scratch_data: QualityL1Metrics, l1_quality_data: L1QualityData
):
    """
    Given: properly structured L1 quality data
    When: executing QualityL1Metrics.compute_and_write_light_level()
    Then: writes one LIGHT_LEVEL QualityMetric
    """
    # Given
    task = quality_l1_task_no_scratch_data
    # When
    task.compute_and_write_light_level(l1_quality_data)
    # Then
    tags = [Tag.quality("GENERIC")]
    metrics: list[QualityMetric] = list(
        task.read(tags=tags, decoder=basemodel_decoder, model=QualityMetric)
    )
    assert len(metrics) == 1
    metric = metrics[0]
    # basics
    assert metric.metric_code == "LIGHT_LEVEL"
    assert metric.facet is None
    assert metric.name == "Light Level"
    assert metric.description.startswith("The telescope light level, as measured by")
    all_statements = metric.statement
    assert isinstance(all_statements, list)
    assert len(all_statements) == 1
    assert all_statements[0].startswith("Average Light Level for L1 dataset")
    assert metric.warnings is None
    # data
    all_plot_data = metric.plot_data
    assert all_plot_data
    assert isinstance(all_plot_data, list)
    assert len(all_plot_data) == 1
    plot_data = all_plot_data[0]
    assert isinstance(plot_data, XYData)
    assert plot_data.xlabel == "Time"
    assert plot_data.ylabel == "Light Level (adu)"
    assert plot_data.series_data
    assert isinstance(plot_data.series_data, dict)
    assert len(plot_data.series_data) == 1
    # single time series, with key of empty string
    assert "" in plot_data.series_data
    time_series = plot_data.series_data[""]
    assert time_series.x_values
    assert time_series.y_values
    assert all(isinstance(val, datetime) for val in time_series.x_values)
    assert all(isinstance(val, float) for val in time_series.y_values)
    assert len(time_series.x_values) == len(time_series.y_values)
    # one x-y coordinate for each light level value
    assert len(time_series.x_values) == len(l1_quality_data.light_level_values)
    # all
    assert len(time_series.x_values) == 7


def test_no_calibration_frames_no_l1_metrics(quality_l1_task_no_scratch_data: QualityL1Metrics):
    """
    Given: No calibrated frames
    When: QualityL1Metrics workflow task is run
    Then: No L1 quality metrics get created
    """
    # Given
    task = quality_l1_task_no_scratch_data
    # When
    task()
    # Then
    tags = [Tag.quality("GENERIC")]
    metrics: list[QualityMetric] = list(
        task.read(tags=tags, decoder=basemodel_decoder, model=QualityMetric)
    )
    assert len(metrics) == 0
