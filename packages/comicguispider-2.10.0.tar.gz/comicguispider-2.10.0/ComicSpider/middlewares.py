# -*- coding: utf-8 -*-
import re
import random
import traceback
from urllib.parse import urlparse
# Define here the models for your spider middleware
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/spider-middleware.html

from scrapy import signals
from scrapy.downloadermiddlewares.httpproxy import HttpProxyMiddleware
from scrapy.http import HtmlResponse
from utils import conf
from utils.config.qc import cgs_cfg
from utils.network.extra import ensure_doh_connect_proxy_started


class ComicspiderDownloaderMiddleware(object):
    def __init__(self, USER_AGENTS, PROXIES):
        self.USER_AGENTS = USER_AGENTS
        self.PROXIES = PROXIES

    @classmethod
    def from_crawler(cls, crawler):
        USER_AGENTS, PROXIES = crawler.settings.get('UA'), conf.proxies
        s = cls(USER_AGENTS, PROXIES)
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_request(self, request, spider):
        return None

    def process_response(self, request, response, spider):
        return response

    def process_exception(self, request, exception, spider):
        if exception:
            spider.crawler.stats.inc_value('process_exception/count')
            spider.crawler.stats.set_value('process_exception/last_exception', 
                f"[{type(exception).__name__}]{str(exception).replace('<', '')}")
        return None

    def spider_opened(self, spider):
        spider.logger.info(f'Spider opened: 【{spider.name}】')


class GlobalErrorHandlerMiddleware:
    """全局错误处理中间件 - 基于scrapy信号机制"""

    @classmethod
    def from_crawler(cls, crawler):
        s = cls()
        # 连接spider_error信号
        crawler.signals.connect(s.spider_error, signal=signals.spider_error)
        return s

    def spider_error(self, failure, response, spider):
        error_msg = str(failure.value)
        spider.logger.error(f"Traceback: {failure.getTraceback()}")
        spider.crawler.engine.close_spider(spider, reason=f"[error]{error_msg}")

    def process_spider_exception(self, response, exception, spider):
        """处理spider回调函数中的异常"""
        error_msg = str(exception)
        spider.logger.error(f"Traceback: {traceback.format_exc()}")
        network_exceptions = ('ConnectionError', 'TimeoutError', 'ImageException')
        if any(ex_type in type(exception).__name__ for ex_type in network_exceptions):
            spider.crawler.stats.inc_value('process_exception/count')
            spider.crawler.stats.set_value('process_exception/last_exception', 
                f"[{type(exception).__name__}]{str(exception).replace('<', '')}")
            return []
        spider.crawler.engine.close_spider(spider, reason=f"[error]{error_msg}")
        return []


class UAMiddleware(ComicspiderDownloaderMiddleware):
    def process_request(self, request, spider):
        request.headers.update(getattr(spider, 'ua', {}))
        return None


class UAKaobeiMiddleware(ComicspiderDownloaderMiddleware):
    def process_request(self, request, spider):
        if request.url.find(spider.pc_domain) != -1:
            if request.url.endswith('/chapters'):
                headers = {**getattr(spider, 'ua', {})}
                headers['Referer'] = f'https://{spider.pc_domain}/comic/{request.url.split("/")[-2]}'
            else:
                headers = {**getattr(spider, 'page_headers', getattr(spider, 'headers', getattr(spider, 'ua', {})))}
                request.headers.clear()
            request.headers.update(headers)
        else:
            request.headers.update(getattr(spider, 'ua_mapi', {}))
        return None


class MangabzUAMiddleware(UAMiddleware):
    def process_request(self, request, spider):
        if request.method == "POST":
            request.headers.update({
                "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Mobile/15E148 Safari/604.1",
                "Accept": "application/json, text/javascript, */*; q=0.01",
                "Accept-Language": "zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2",
                "Accept-Encoding": "gzip, deflate, br",
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "X-Requested-With": "XMLHttpRequest",
                "Origin": "https://www.mangabz.com",
                "Connection": "keep-alive",
                "Sec-Fetch-Dest": "empty",
                "Sec-Fetch-Mode": "cors",
                "Sec-Fetch-Site": "same-origin",
                "Pragma": "no-cache",
                "Cache-Control": "no-cache",
                "TE": "trailers"
            })
        else:
            request.headers.update(getattr(spider, 'ua', {}))
        return None


class ComicDlAllProxyMiddleware(ComicspiderDownloaderMiddleware):
    def process_request(self, request, spider):
        if self.PROXIES:
            proxy = random.choice(self.PROXIES)
            request.meta['proxy'] = f"http://{proxy}"


class ComicDlProxyMiddleware(ComicspiderDownloaderMiddleware):
    """使用情况是"通常页需要over wall访问"，"图源cn就能访问"... 因此domain的都使用代理
    Spider 可定义 proxy_domains 列表指定需要代理的域名，未定义则回退到 domain
    """
    def process_request(self, request, spider):
        domains = [d for d in (getattr(spider, 'proxy_domains', None) or [getattr(spider, 'domain', '')]) if d]
        if domains and bool(re.compile('|'.join(re.escape(d) for d in domains)).search(request.url)) and self.PROXIES:
            proxy = random.choice(self.PROXIES)
            request.meta['proxy'] = f"http://{proxy}"


class DisableSystemProxyMiddleware(HttpProxyMiddleware):
    def _get_proxy(self, scheme, *args, **kwargs):
        return None, None


class ScrapyDoHProxyMiddleware:
    def __init__(self, doh_url: str):
        self._doh_url = doh_url
        self._proxy_endpoint = ""

    @classmethod
    def from_crawler(cls, crawler):
        middleware = cls(cgs_cfg.doh.get_url())
        crawler.signals.connect(middleware.spider_opened, signal=signals.spider_opened)
        return middleware

    def _ensure_proxy_endpoint(self, spider):
        if not self._proxy_endpoint:
            self._proxy_endpoint = ensure_doh_connect_proxy_started(self._doh_url)
            spider.logger.info(
                f"Scrapy DoH proxy enabled | doh={self._doh_url} | proxy={self._proxy_endpoint}"
            )
        return self._proxy_endpoint

    def spider_opened(self, spider):
        if not self._doh_url:
            return
        self._ensure_proxy_endpoint(spider)

    def process_request(self, request, spider):
        if not self._doh_url or request.meta.get('proxy'):
            return None
        parsed = urlparse(request.url)
        if parsed.scheme != "https" or parsed.hostname == "fakefakefa.com":
            return None
        request.meta['proxy'] = f"http://{self._ensure_proxy_endpoint(spider)}"
        return None


class RefererMiddleware(ComicspiderDownloaderMiddleware):
    def process_request(self, request, spider):
        if request.headers.get('Referer'):
            return None
        if referer := request.meta.get('referer'):
            request.headers['Referer'] = referer
            return None
        referer_resolver = getattr(spider, 'request_referer', None)
        if callable(referer_resolver):
            request.headers['Referer'] = referer_resolver()
        else:
            domain = getattr(spider, 'domain', '')
            request.headers['Referer'] = domain if str(domain).startswith('http') else f"https://{domain}"
        return None


class FakeMiddleware:
    def process_request(self, request, spider):
        if request.url.startswith('https://fakefakefa.com'):
            fake_resp = HtmlResponse(url=request.url, request=request, body=b'fake')
            return fake_resp
        return None
