# -*- coding: utf-8 -*-
from __future__ import annotations

import contextlib
from collections import deque
from copy import deepcopy
# from uuid import uuid4

from PySide6.QtCore import QObject, Signal

from ComicSpider.runtime import SpiderRuntimeThread
from GUI.thread import WorkThread
from utils import conf
from utils.protocol import SpiderDownloadJob
from variables import SPIDERS, Spider


class DownloadRuntimeManager(QObject):
    """Manage SpiderRuntime + WorkThread lifecycle and process stage state."""

    process_stage_changed = Signal(str)
    all_jobs_finished = Signal()

    def __init__(self, gui):
        super().__init__(gui)
        self.gui = gui
        self.spider_runtime = None
        self.b_thread: WorkThread | None = None
        self.process_stage: str = ""
        self.running_job_ids: set[str] = set()
        self.binding_generation = 0
        self.session_job_ids: set[str] = set()
        self.session_job_task_ids: set[str] = set()
        self.pending_job_ids: set[str] = set()
        self._job_task_ids: dict[str, set[str]] = {}
        self._submission_queue: deque[SpiderDownloadJob] = deque()
        self._submitted_task_infos: dict[str, tuple[int, object]] = {}
        self._batch_had_failures = False
        self._worker_signal_bindings: list[tuple[object, object]] = []

    def start_runtime(self, site_index: int):
        if self.spider_runtime and self.spider_runtime.is_alive():
            return
        self.spider_runtime = SpiderRuntimeThread()
        self.spider_runtime.daemon = True
        self.spider_runtime.start()
        self.spider_runtime.wait_ready()

    def submit_download(self, task_info, site_index: int | None = None):
        effective_site_index = self.gui.chooseBox.currentIndex() if site_index is None else site_index
        if not self.has_active_download():
            self._batch_had_failures = False
        if not self.spider_runtime:
            self.start_runtime(effective_site_index)

        tasks_obj = task_info.to_tasks_obj()
        job_id = tasks_obj.taskid
        if job_id in self.session_job_ids:
            raise ValueError(f"duplicate runtime submission detected for task {job_id}")

        job = SpiderDownloadJob(
            job_id=job_id,
            spider_name=SPIDERS[effective_site_index],
            site_index=effective_site_index,
            payload=task_info,
            options={},
            tasks_obj=tasks_obj,
        )

        self.session_job_ids.add(job_id)
        self._job_task_ids[job_id] = {tasks_obj.taskid}
        self.session_job_task_ids.add(tasks_obj.taskid)
        self._submitted_task_infos[job_id] = (effective_site_index, deepcopy(task_info))
        self.gui.task_mgr.handle(tasks_obj)
        self.ensure_work_thread()
        self._submission_queue.append(job)
        self._submit_queued_jobs()

    def resubmit_download(self, task_id: str):
        site_index, task_info = self._submitted_task_infos[task_id]
        self.submit_download(deepcopy(task_info), site_index=site_index)

    def ensure_work_thread(self) -> WorkThread:
        if self.b_thread and self.b_thread.isRunning():
            return self.b_thread
        self._disconnect_worker_signals()
        self.b_thread = WorkThread(self.gui, event_q=self.spider_runtime.event_q, authority=self)
        self.b_thread._bind_generation = self.binding_generation
        self._connect_worker_signals(self.b_thread)
        self.b_thread.start()
        if log := getattr(self.gui, "log", None):
            log.info("-*-*- Background thread & spider starting")
        return self.b_thread

    def stop_work_thread(self, wait_ms=800):
        worker = self.b_thread
        if worker is None:
            return
        worker.stop()
        worker.quit()
        worker.wait(wait_ms)
        self.b_thread = None

    def is_job_pending(self, job_id: str | None) -> bool:
        return bool(job_id) and job_id in self.pending_job_ids

    def accept_job(self, job_id: str | None):
        if not job_id or job_id not in self.pending_job_ids:
            return
        self.running_job_ids.add(job_id)
        self.pending_job_ids.discard(job_id)

    def reject_job(self, job_id: str | None):
        if not job_id or job_id not in self.pending_job_ids:
            return
        self.pending_job_ids.discard(job_id)
        self.session_job_ids.discard(job_id)
        if job_id in self._job_task_ids:
            del self._job_task_ids[job_id]
            self._rebuild_session_task_ids()
        self.gui.task_mgr.sync_toolbar_state()
        self._submit_queued_jobs()
        if not self.has_active_download():
            self.all_jobs_finished.emit()

    def track_task(self, job_id: str | None, task_obj):
        if not job_id:
            return
        expected_task_ids = self._job_task_ids.get(job_id)
        if expected_task_ids is None:
            self._job_task_ids[job_id] = {task_obj.taskid}
            self.session_job_task_ids.add(task_obj.taskid)
            return
        if task_obj.taskid not in expected_task_ids:
            raise ValueError(
                f"runtime emitted unexpected task {task_obj.taskid} for job {job_id}, "
                f"expected one of {sorted(expected_task_ids)}"
            )

    def finish_job(self, job_id: str | None):
        if not job_id:
            return
        self.running_job_ids.discard(job_id)
        self.pending_job_ids.discard(job_id)
        self.session_job_ids.discard(job_id)
        if job_id in self._job_task_ids:
            del self._job_task_ids[job_id]
            self._rebuild_session_task_ids()
        self.gui.task_mgr.sync_toolbar_state()
        self._submit_queued_jobs()
        if not self.has_active_download():
            self.all_jobs_finished.emit()

    def has_active_download(self) -> bool:
        return bool(self.running_job_ids or self.pending_job_ids or self._submission_queue)

    def get_running_task_ids(self) -> set[str]:
        return set(self.session_job_task_ids)

    def _disconnect_worker_signals(self):
        while self._worker_signal_bindings:
            signal, slot = self._worker_signal_bindings.pop()
            with contextlib.suppress(TypeError, RuntimeError):
                signal.disconnect(slot)

    def _connect_worker_signals(self, worker: WorkThread):
        def connect_filtered(signal, slot):
            def filtered(generation: int, *args):
                if generation != self.binding_generation:
                    return
                slot(*args)

            signal.connect(filtered)
            self._worker_signal_bindings.append((signal, filtered))

        connect_filtered(worker.print_signal, self.on_worker_log)
        connect_filtered(worker.tasks_signal, self.on_task_emitted)
        connect_filtered(worker.process_state_signal, self.on_process_stage_changed)
        connect_filtered(worker.worker_finished_signal, self.on_worker_finished)

    def on_worker_log(self, _job_id: str | None, message: str):
        if isinstance(message, str) and message.startswith("[PreviewBookInfoEnd]"):
            return
        self.gui.say(message)

    def on_task_emitted(self, _job_id: str | None, task_obj):
        self.gui.task_mgr.handle(task_obj)

    def on_process_stage_changed(self, _job_id: str | None, stage: str):
        self.process_stage = stage or ""
        self.process_stage_changed.emit(self.process_stage)

    def on_worker_finished(self, job_id: str | None, imgs_path: str, success: bool, error: str | None):
        if job_id:
            self.gui.task_mgr.handle_job_finished(job_id, success=success, error=error)
        if not success:
            self._batch_had_failures = True
            if error:
                self.gui.say(f"[DownloadFailed] {error}")
        self.finish_job(job_id)
        if success and not self._batch_had_failures and not self.has_active_download():
            self.gui.crawl_end(imgs_path)

    def rebind(self, gui):
        self.gui = gui
        self.binding_generation += 1
        if not self.has_active_download():
            self._reset_session_state()
        worker = self.b_thread
        if worker is None:
            return
        worker.authority = self
        worker.suspend_dispatch()
        self._disconnect_worker_signals()
        worker.rebind(gui)
        self._connect_worker_signals(worker)
        worker.resume_dispatch()

    def close_runtime(self, stop_mgr=True, really_close=True):
        self.gui.clean_preview()
        if really_close:
            self.binding_generation += 1
            self._disconnect_worker_signals()
            self.stop_work_thread()
            if self.spider_runtime:
                self.spider_runtime.shutdown()
                self.spider_runtime.join(timeout=3)
                self.spider_runtime = None
            self._reset_session_state(clear_submitted=True)
        if stop_mgr and getattr(self.gui, "mid_mgr", None):
            self.gui.mid_mgr.stop()

    def _reset_session_state(self, clear_submitted=False):
        self.running_job_ids.clear()
        self.process_stage = ""
        self.session_job_ids.clear()
        self.session_job_task_ids.clear()
        self.pending_job_ids.clear()
        self._job_task_ids.clear()
        self._submission_queue.clear()
        self._batch_had_failures = False
        if clear_submitted:
            self._submitted_task_infos.clear()

    def _rebuild_session_task_ids(self):
        merged = set()
        for task_ids in self._job_task_ids.values():
            merged.update(task_ids)
        self.session_job_task_ids = merged

    def _submit_queued_jobs(self): 
        def _has_active_kaobei_job() -> bool:
            return any(
                self._submitted_task_infos[job_id][0] == Spider.MANGA_COPY
                for job_id in self.running_job_ids | self.pending_job_ids
            )
        if not self.spider_runtime:
            return
        while self._submission_queue:
            if _has_active_kaobei_job():
                return
            active_job_count = len(self.running_job_ids) + len(self.pending_job_ids)
            next_job = self._submission_queue[0]
            concurrency_limit = 1 if next_job.site_index == Spider.MANGA_COPY else int(conf.concurr_num)
            if active_job_count >= concurrency_limit:
                return
            job = self._submission_queue.popleft()
            self.pending_job_ids.add(job.job_id)
            self.spider_runtime.submit_job(job)
