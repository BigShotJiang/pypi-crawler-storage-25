import gc
import typing as t
from pathlib import Path

from PySide6 import QtCore
from PySide6.QtCore import Qt, Signal, QSize
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QFrame, QHBoxLayout, QStackedWidget, QVBoxLayout, QWidget
from qfluentwidgets import (
    ComboBox, FluentIcon as FIF, InfoBar, InfoBarPosition, PrimaryToolButton,
    StrongBodyLabel, SubtitleLabel, TabBar, TabCloseButtonDisplayMode, ToolButton, TransparentToolButton
    )

from deploy import curr_os
from GUI.core.theme import theme_mgr
from GUI.manager.async_task import AsyncTaskManager, summarize_error_message
from GUI.uic.qfluent.components import CountBadge, CustomInfoBar
from utils.config.qc import danbooru_cfg
from utils.script.image.danbooru.constants import DANBOORU_SQL_TABLE
from utils.script.image.danbooru.models import DanbooruRuntimeConfig, DanbooruSearchQuery
from utils.sql import SqlRecorder

from .challenge import DanbooruChallengeController
from .core import DanbooruDownloadController, DanbooruSearchController, DanbooruTabState
from .detail_preview import DanbooruDetailPreviewController
from .favorites import DanbooruFavoriteManagerDialog
from .style import (
    CARD_ZOOM_METRICS, DEFAULT_CARD_ZOOM_INDEX, DEFAULT_TAB_STATUS_CLASS, DanbooruCardMetrics, DanbooruUiPalette, default_tab_status_text,
    build_interface_stylesheet, build_tip_line_stylesheet, build_title_label_stylesheet,
    format_tip_rich_text as _format_tip_rich_text, qcolor_from_css,
)
from .tab import DanbooruTabWidget
from .viewer import DanbooruImageViewer

class DanbooruInterface(QFrame):
    download_result_signal = Signal(str, bool)

    def __init__(self, parent=None):
        super().__init__(parent=parent)
        self.parent_window = parent
        self.gui = parent.gui
        self.setObjectName("DanbooruInterface")
        self.task_mgr = AsyncTaskManager(self.gui)
        self.tab_counter = 0
        self.tabs: dict[str, DanbooruTabWidget] = {}
        self.tab_states: dict[str, DanbooruTabState] = {}
        self._tab_tips: dict[str, tuple[str, str]] = {}
        self._tab_httpx_status: dict[str, str] = {}
        self.sql_recorder = SqlRecorder(table=DANBOORU_SQL_TABLE)
        self.image_viewer = DanbooruImageViewer(parent)
        self.detail_preview_controller = DanbooruDetailPreviewController(self, self.image_viewer)
        self.search_controller = DanbooruSearchController(self)
        self.download_controller = DanbooruDownloadController(self)
        self.challenge_controller = DanbooruChallengeController(self)
        self.zoom_mgr = self._ZoomMgr(self)
        self._runtime_config = DanbooruRuntimeConfig.from_conf()
        self.download_result_signal.connect(self.download_controller.on_download_result)
        self.image_viewer.tag_clicked.connect(self._open_tag_jump_tab)
        self.image_viewer.download_requested.connect(self.download_controller.submit_single)
        self.image_viewer.previous_requested.connect(lambda: self.detail_preview_controller.open_adjacent(-1))
        self.image_viewer.next_requested.connect(lambda: self.detail_preview_controller.open_adjacent(1))
        self.image_viewer.closed.connect(self.detail_preview_controller.clear_context)
        theme_mgr.subscribe(self._apply_theme)
        self.destroyed.connect(lambda *_args: self.task_mgr.cleanup())
        self.setupUi()
        self._apply_theme()
        self.create_tab()

    class _ZoomMgr:
        def __init__(self, interface: "DanbooruInterface"):
            self.interface = interface
            self.zoom_index = DEFAULT_CARD_ZOOM_INDEX
            self.generation = 0

        def current_metrics(self) -> DanbooruCardMetrics:
            return CARD_ZOOM_METRICS[self.zoom_index]

        def zoom_in(self):
            if self.zoom_index >= len(CARD_ZOOM_METRICS) - 1:
                return
            self.zoom_index += 1
            self.apply_current()
            self.sync_buttons()

        def zoom_out(self):
            if self.zoom_index <= 0:
                return
            self.zoom_index -= 1
            self.apply_current()
            self.sync_buttons()

        def sync_buttons(self):
            self.interface.zoomIn.setEnabled(self.zoom_index < len(CARD_ZOOM_METRICS) - 1)
            self.interface.zoomOut.setEnabled(self.zoom_index > 0)

        def apply_current(self, *, active_tab_id: t.Optional[str] = None):
            self.generation += 1
            metrics = self.current_metrics()
            active_tab_id = self.interface._active_tab_id() if active_tab_id is None else active_tab_id
            for tab_id, tab in self.interface.tabs.items():
                if tab_id == active_tab_id:
                    tab.zoom_mgr.apply_active(metrics=metrics)
                else:
                    tab.zoom_mgr.mark_hidden_target(metrics=metrics)

        def sync_tab(self, tab_id: str):
            tab = self.interface.tabs.get(tab_id)
            if tab is None:
                return
            tab.zoom_mgr.sync_to(metrics=self.current_metrics())

        def forget(self, tab_id: str):
            return

        def shutdown(self):
            return

    def setupUi(self):
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(14, 12, 14, 14)
        self.main_layout.setSpacing(12)

        title_row = QHBoxLayout()
        title_row.setContentsMargins(0, 0, 20, 0)
        title_row.setSpacing(4)
        self.title_block = QWidget(self)
        self.title_block.setObjectName("DanbooruTitleBlock")
        title_block_layout = QHBoxLayout(self.title_block)
        title_block_layout.setContentsMargins(16, 12, 16, 12)
        title_block_layout.setSpacing(16)
        self.title_label = SubtitleLabel("Danbooru", self)
        self.tip_line = StrongBodyLabel("", self)
        self.tip_line.setTextFormat(Qt.RichText)
        self.tip_line.setObjectName("DanbooruTipLine")
        title_block_layout.addWidget(self.title_label)
        title_block_layout.addWidget(self.tip_line, 1)
        zoomBtnGroup = QVBoxLayout()
        zoomBtnGroup.setContentsMargins(2,0,2,0)
        zoomBtnGroup.setSpacing(0)
        self.zoomIn = ToolButton(QIcon(':/script/zoomin.svg'))
        self.zoomIn.setMaximumHeight(22)
        self.zoomOut = ToolButton(QIcon(':/script/zoomout.svg'))
        self.zoomOut.setMaximumHeight(22)
        zoomBtnGroup.addWidget(self.zoomIn)
        zoomBtnGroup.addWidget(self.zoomOut)
        self.favMgrBtn = ToolButton(QIcon(':/script/favMgr.svg'), self)
        self.favMgrBtn.setObjectName("FavMgrBtn")
        self.favMgrBtn.setIconSize(QSize(20, 20))
        self.favMgrBtn.setMinimumHeight(50)
        self.openBtn = ToolButton(FIF.FOLDER)
        self.openBtn.setMinimumHeight(50)
        self.batch_download_btn = PrimaryToolButton(FIF.DOWNLOAD, self)
        self.batch_download_btn.setMinimumHeight(50)
        self.batch_download_btn.setMinimumWidth(80)
        self.batch_download_btn.setIconSize(QtCore.QSize(20, 20))
        self.batch_download_btn.setDisabled(True)
        self.batch_download_badge = CountBadge(parent=self, target=self.batch_download_btn)
        self.batch_download_badge.hide()
        title_row.addWidget(self.title_block, 1)
        title_row.addLayout(zoomBtnGroup)
        title_row.addWidget(self.favMgrBtn)
        title_row.addWidget(self.openBtn)
        title_row.addWidget(self.batch_download_btn)
        self.main_layout.addLayout(title_row)

        self.pivot_shell = QFrame(self)
        self.pivot_shell.setObjectName("DanbooruPivotShell")
        self.pivot_shell.setMinimumHeight(34)
        pivot_shell_layout = QHBoxLayout(self.pivot_shell)
        pivot_shell_layout.setContentsMargins(14, 2, 14, 2)
        pivot_shell_layout.setSpacing(8)
        self.pivot_back_btn = TransparentToolButton(FIF.LEFT_ARROW, self.pivot_shell)
        self.pivot_back_btn.setObjectName("DanbooruPivotScrollButton")
        self.pivot_back_btn.setFixedSize(18, 18)
        self.pivot_back_btn.setIconSize(QtCore.QSize(14, 14))
        pivot_shell_layout.addWidget(self.pivot_back_btn, 0, Qt.AlignVCenter)
        self.tab_bar = TabBar(self.pivot_shell)
        self.tab_bar.setObjectName("DanbooruPivotScrollArea")
        self.tab_bar.view.setObjectName("DanbooruPivotTabBarView")
        self.tab_bar.setAddButtonVisible(False)
        self.tab_bar.setCloseButtonDisplayMode(TabCloseButtonDisplayMode.ON_HOVER)
        self.tab_bar.setTabShadowEnabled(False)
        self.tab_bar.setTabMaximumWidth(148)
        self.tab_bar.setTabMinimumWidth(96)
        self.tab_bar.enableTransparentBackground()
        self.tab_bar.itemLayout.setContentsMargins(0, 5, 0, 5)
        self.tab_bar.itemLayout.setSpacing(6)
        self.pivot_scroll = self.tab_bar
        pivot_shell_layout.addWidget(self.tab_bar, 1)
        self.pivot_forward_btn = TransparentToolButton(FIF.RIGHT_ARROW, self.pivot_shell)
        self.pivot_forward_btn.setObjectName("DanbooruPivotScrollButton")
        self.pivot_forward_btn.setFixedSize(18, 18)
        self.pivot_forward_btn.setIconSize(QtCore.QSize(14, 14))
        pivot_shell_layout.addWidget(self.pivot_forward_btn, 0, Qt.AlignVCenter)
        pivot_scroll_bar = self.pivot_scroll.horizontalScrollBar()

        self.content_shell = QFrame(self)
        self.content_shell.setObjectName("DanbooruContentShell")
        content_shell_layout = QVBoxLayout(self.content_shell)
        content_shell_layout.setContentsMargins(12, 12, 12, 12)
        content_shell_layout.setSpacing(0)
        self.stacked_widget = QStackedWidget(self.content_shell)
        content_shell_layout.addWidget(self.stacked_widget)
        # binding
        self.zoomIn.clicked.connect(self.zoom_mgr.zoom_in)
        self.zoomOut.clicked.connect(self.zoom_mgr.zoom_out)
        self.favMgrBtn.clicked.connect(self._open_favorite_manager)
        self.openBtn.clicked.connect(self._open_save_path)
        self.batch_download_btn.clicked.connect(self.download_controller.submit_selected)
        self.tab_bar.currentChanged.connect(self._on_tabbar_index_changed)
        self.pivot_back_btn.clicked.connect(lambda: self._scroll_pivot_tabs(-1))
        self.pivot_forward_btn.clicked.connect(lambda: self._scroll_pivot_tabs(1))
        self.tab_bar.tabCloseRequested.connect(self._on_tab_close_requested)
        pivot_scroll_bar.rangeChanged.connect(lambda *_args: self._sync_pivot_scroll_controls())
        pivot_scroll_bar.valueChanged.connect(lambda *_args: self._sync_pivot_scroll_controls())
        self.stacked_widget.currentChanged.connect(self._on_current_tab_changed)
        
        self.main_layout.addWidget(self.pivot_shell)
        self.main_layout.addWidget(self.content_shell, 1)

    def _apply_theme(self, *_args):
        palette = DanbooruUiPalette.current()
        self.setStyleSheet(build_interface_stylesheet(palette))
        self.title_label.setStyleSheet(build_title_label_stylesheet(palette))
        self.tip_line.setStyleSheet(build_tip_line_stylesheet(palette))
        self.tab_bar.setTabShadowEnabled(False)
        selected_color = qcolor_from_css(palette.pivot_selected)
        self.tab_bar.setTabSelectedBackgroundColor(selected_color, selected_color)
        self.image_viewer.apply_theme()
        for tab in self.tabs.values():
            tab.apply_theme()
        self._update_tab_chrome()
        self._sync_tip_line()
        self.refresh_runtime_settings()
        self.zoom_mgr.sync_buttons()
        self._sync_tab_bar_width()

    def create_tab(self, initial_query: str = "", auto_search: bool = False):
        self.tab_counter += 1
        tab_id = f"danbooru-tab-{self.tab_counter}"
        state = DanbooruTabState(
            tab_id=tab_id,
            title=self._display_title_for_query(initial_query, self.tab_counter),
            query=DanbooruSearchQuery.normalize(initial_query),
        )
        tab = DanbooruTabWidget(state, self)
        tab.setObjectName(tab_id)
        tab.zoom_mgr.apply_immediate(metrics=self.zoom_mgr.current_metrics(), refresh_preview=True)
        tab.request_search.connect(lambda query, tid=tab_id: self.search_controller.start_search(tid, query))
        tab.request_conversion.connect(lambda tid=tab_id: self.search_controller.convert_term(tid))
        tab.request_single_download.connect(lambda post, tid=tab_id: self.download_controller.submit_single(post, tid))
        tab.request_tag_jump.connect(self._open_tag_jump_tab)
        tab.request_next_page.connect(lambda tid=tab_id: self.search_controller.load_next_page(tid))
        tab.request_close.connect(self.close_current_tab)
        tab.request_extra_search.connect(lambda term, tid=tab_id: self._on_extra_search(tid, term))
        tab.detail_opened.connect(lambda post, tid=tab_id: self.detail_preview_controller.open_viewer(tid, post))
        tab.selection_count_changed.connect(lambda _count, tid=tab_id: self._update_batch_button(tid))
        tab.favorite_btn.clicked.connect(lambda _=False, tid=tab_id: self._toggle_favorite(tid))
        self.tabs[tab_id] = tab
        self.tab_states[tab_id] = state
        self._tab_tips[tab_id] = (default_tab_status_text(), DEFAULT_TAB_STATUS_CLASS)
        self._tab_httpx_status[tab_id] = ""
        self.stacked_widget.addWidget(tab)
        self.tab_bar.addTab(routeKey=tab_id, text=state.title)
        self._sync_tab_bar_width()
        self._set_current_tab(tab_id)
        self._update_tab_chrome()
        self._refresh_completer(tab)
        if state.query:
            tab.search_edit.setText(state.query)
            if auto_search:
                self.search_controller.start_search(tab_id, state.query)
        if self._active_tab_id() == tab_id:
            self._sync_tip_line(tab_id)
        return tab_id

    def close_current_tab(self):
        self._close_tab_by_id(self._active_tab_id())

    def _close_tab_by_id(self, tab_id: t.Optional[str]):
        if len(self.tabs) <= 1:
            return
        if not tab_id:
            return
        tab = self.tabs.pop(tab_id, None)
        self.tab_states.pop(tab_id, None)
        self._tab_tips.pop(tab_id, None)
        self._tab_httpx_status.pop(tab_id, None)
        self.zoom_mgr.forget(tab_id)
        if tab is None:
            return
        if self.detail_preview_controller.current_tab_id == tab_id and self.image_viewer.isVisible():
            self.image_viewer.hide()
            self.detail_preview_controller.clear_context()
        self.tab_bar.removeTabByKey(tab_id)
        self.stacked_widget.removeWidget(tab)
        tab.deleteLater()
        gc.collect()
        if self.stacked_widget.count():
            self._set_current_tab(self.stacked_widget.widget(0).objectName())
        self._update_tab_chrome()
        self._sync_tab_bar_width()

    def _set_current_tab(self, tab_id: str):
        tab = self.tabs.get(tab_id)
        if tab is None:
            return
        previous_widget = self.stacked_widget.currentWidget()
        previous_tab_id = previous_widget.objectName() if previous_widget is not None else None
        if previous_tab_id and previous_tab_id != tab_id:
            previous_tab = self.tabs.get(previous_tab_id)
            if previous_tab is not None:
                previous_tab.zoom_mgr.suspend_hidden()
        self.stacked_widget.setCurrentWidget(tab)
        self.tab_bar.setCurrentTab(tab_id)
        self._update_batch_button(tab_id)

    def _on_current_tab_changed(self, _index: int):
        widget = self.stacked_widget.currentWidget()
        if widget is None:
            return
        tab_id = widget.objectName()
        self.tab_bar.setCurrentTab(tab_id)
        self._update_batch_button(tab_id)
        self._update_tab_chrome()
        self._sync_tip_line(tab_id)
        self.zoom_mgr.sync_tab(tab_id)

    def _on_tabbar_index_changed(self, index: int):
        tab_id = self._tab_id_at(index)
        if tab_id:
            self._set_current_tab(tab_id)

    def _on_tab_close_requested(self, index: int):
        self._close_tab_by_id(self._tab_id_at(index))

    def _tab_id_at(self, index: int) -> t.Optional[str]:
        if not 0 <= index < self.tab_bar.count():
            return None
        return self.tab_bar.tabItem(index).routeKey()

    def _tab_index(self, tab_id: str) -> int:
        item = self.tab_bar.tab(tab_id)
        return self.tab_bar.items.index(item) if item is not None else -1

    @staticmethod
    def _display_title_for_query(query: str, tab_index: int) -> str:
        canonical = DanbooruSearchQuery.normalize(query)
        if not canonical:
            return f"工作区 {tab_index}"
        if len(canonical) <= 18:
            return canonical
        return canonical[:16].rstrip() + ".."

    def _update_tab_title(self, tab_id: str, query: str):
        state = self.tab_states.get(tab_id)
        if state is None:
            return
        title = self._display_title_for_query(query, int(tab_id.rsplit("-", 1)[-1]))
        if title == state.title:
            return
        state.title = title
        index = self._tab_index(tab_id)
        if index >= 0:
            self.tab_bar.setTabText(index, state.title)
        self._update_tab_chrome()
        self._sync_tab_bar_width()

    def _update_tab_chrome(self):
        palette = DanbooruUiPalette.current()
        current_tab_id = self._active_tab_id()
        active_text_color = qcolor_from_css(palette.text)
        inactive_text_color = qcolor_from_css(palette.muted_text)
        self.tab_bar.setTabsClosable(len(self.tabs) > 1)
        for index in range(self.tab_bar.count()):
            item = self.tab_bar.tabItem(index)
            if item is None:
                continue
            tab_id = item.routeKey()
            item.setBorderRadius(12)
            self.tab_bar.setTabTextColor(index, active_text_color if tab_id == current_tab_id else inactive_text_color)

    def _active_tab_id(self) -> t.Optional[str]:
        widget = self.stacked_widget.currentWidget()
        return widget.objectName() if widget is not None else None

    def _set_tab_tip(self, tab_id: str, text: str, cls: str = DEFAULT_TAB_STATUS_CLASS):
        self._tab_tips[tab_id] = (text, cls or DEFAULT_TAB_STATUS_CLASS)
        if self._active_tab_id() == tab_id:
            self.tip_line.setText(_format_tip_rich_text(*self._tab_tips[tab_id]))

    def set_tab_httpx_status(self, tab_id: str, status: str, cls: str = DEFAULT_TAB_STATUS_CLASS):
        self._tab_httpx_status[tab_id] = str(status or "")
        self._set_tab_tip(tab_id, self._tab_httpx_status[tab_id], cls=cls)

    def tab_httpx_status(self, tab_id: str) -> str:
        return self._tab_httpx_status.get(tab_id, "")

    def _sync_tip_line(self, tab_id: t.Optional[str] = None):
        effective_tab_id = tab_id or self._active_tab_id()
        text, cls = self._tab_tips.get(effective_tab_id, (default_tab_status_text(), DEFAULT_TAB_STATUS_CLASS))
        self.tip_line.setText(_format_tip_rich_text(text, cls))

    def _scroll_pivot_tabs(self, direction: int):
        bar = self.pivot_scroll.horizontalScrollBar()
        if bar.maximum() <= bar.minimum():
            return
        step = max(72, int(self.pivot_scroll.viewport().width() * 0.72))
        bar.setValue(bar.value() + direction * step)

    def _sync_pivot_scroll_controls(self):
        if not hasattr(self, "pivot_scroll"):
            return
        bar = self.pivot_scroll.horizontalScrollBar()
        has_overflow = bar.maximum() > bar.minimum()
        self.pivot_back_btn.setEnabled(has_overflow and bar.value() > bar.minimum())
        self.pivot_forward_btn.setEnabled(has_overflow and bar.value() < bar.maximum())

    def _sync_tab_bar_width(self):
        if not hasattr(self, "tab_bar"):
            return
        self.tab_bar.view.adjustSize()
        self.tab_bar.updateGeometry()
        QtCore.QTimer.singleShot(0, self._sync_pivot_scroll_controls)

    def _open_save_path(self):
        curr_os.open_folder(Path(self._runtime_config.save_path))

    def _update_batch_button(self, tab_id: str):
        if self._active_tab_id() != tab_id:
            return
        state = self.tab_states.get(tab_id)
        count = len(state.selected_md5_set) if state else 0
        self.batch_download_btn.setDisabled(count == 0)
        if count <= 0:
            self.batch_download_badge.hide()
            return
        self.batch_download_badge.set_count(count)
        self.batch_download_badge.show()

    def apply_downloaded_post(self, md5_value: str):
        for tab in self.tabs.values():
            tab.apply_downloaded_state(md5_value)
        if self.detail_preview_controller.matches(md5=md5_value):
            self.image_viewer.set_download_state(True)
        self.detail_preview_controller.sync_navigation()

    def _show_task_error(self, error: str, duration: int = 6000):
        self.gui.log.error(error)
        summary = summarize_error_message(error)
        self._show_info(InfoBar.error, f"✕ {summary}", duration)

    def _log_search_request(self, tab_id: str, query: str, order: str, page: int, limit: int):
        params = DanbooruSearchQuery(query, order).params(page=page, limit=limit)
        stub_endpoint = self._runtime_config.stub_dns_endpoint() or "disabled"
        dns_summary = f"DoH={self._runtime_config.doh_url}" if self._runtime_config.is_doh_enabled() else "system"
        self.gui.log.info(f"[Danbooru] GET /posts.json tab={tab_id} params={params} dns={dns_summary} stub={stub_endpoint}")

    def refresh_runtime_settings(self):
        self._runtime_config = DanbooruRuntimeConfig.from_conf()

    def _refresh_completer(self, tab: DanbooruTabWidget):
        history = danbooru_cfg.get_history()
        favorites = sorted(danbooru_cfg.fav.get() - set(history))
        tab.update_completer(history + favorites)

    def _show_info(self, factory, content: str, duration: int = 3000):
        factory(
            title="", content=content, orient=Qt.Horizontal, isClosable=True, position=InfoBarPosition.TOP, duration=duration, parent=self,
        )

    def _on_extra_search(self, tab_id: str, extra_term: str):
        tab = self.tabs.get(tab_id)
        if tab is None:
            return
        current = DanbooruSearchQuery.normalize(tab.search_edit.text())
        combined = f"{current} {extra_term}".strip() if current else extra_term
        tab.search_edit.setText(combined)
        self.search_controller.start_search(tab_id, combined)

    def _toggle_favorite(self, tab_id: str):
        tab = self.tabs.get(tab_id)
        if tab is None:
            return
        term = DanbooruSearchQuery.normalize(tab.search_edit.text())
        if not term:
            return
        is_favorited = danbooru_cfg.fav.toggle(term)
        self._refresh_all_favorites_ui()
        content = f"★ {term}" if is_favorited else f"☆ {term}"
        if not is_favorited:
            return self._show_info(InfoBar.error, content)
        custom_groups = danbooru_cfg.fav.get_grouped()
        if not custom_groups:
            return self._show_info(InfoBar.success, content)
        tmpFavMgrBtn = PrimaryToolButton(QIcon(':/script/favMgr.svg'))
        first_ib = CustomInfoBar.show_custom(
            title="", content=content, parent=self, _type="SUCCESS",
            ib_pos=InfoBarPosition.TOP, duration=3000, widgets=[tmpFavMgrBtn],
        )
        def _open_group_picker():
            first_ib.close()
            combo = ComboBox()
            combo.addItems([name for name, _ in custom_groups])
            combo.setMinimumWidth(100)
            accept_btn = PrimaryToolButton(FIF.ACCEPT)
            picker_ib = CustomInfoBar.show_custom(
                title="", content="move to:", parent=self, _type="INFORMATION",
                ib_pos=InfoBarPosition.TOP, duration=-1, widgets=[combo, accept_btn],
            )
            def _move_tag():
                group_name = combo.currentText()
                danbooru_cfg.fav.move_to_group(term, group_name)
                self._refresh_all_favorites_ui()
                picker_ib.close()
                self._show_info(InfoBar.success, f"moved to「{group_name}」")
            accept_btn.clicked.connect(_move_tag)
        tmpFavMgrBtn.clicked.connect(_open_group_picker)

    def _refresh_all_favorites_ui(self):
        for tab in self.tabs.values():
            tab.set_search_menu()
            self._refresh_completer(tab)

    def _open_favorite_manager(self):
        dialog = DanbooruFavoriteManagerDialog(self)
        dialog.favorites_changed.connect(self._refresh_all_favorites_ui)
        dialog.exec()

    def _open_tag_jump_tab(self, tag: str):
        self.image_viewer.hide()
        self.detail_preview_controller.clear_context()
        canonical_tag = DanbooruSearchQuery.normalize(tag)
        if not canonical_tag:
            return
        for tab_id, state in self.tab_states.items():
            if DanbooruSearchQuery.normalize(state.query) == canonical_tag:
                self._set_current_tab(tab_id)
                tab = self.tabs.get(tab_id)
                if tab is not None and not state.result_list and not state.loading:
                    self.search_controller.start_search(tab_id, canonical_tag)
                return
        active_tab_id = self._active_tab_id()
        active_state = self.tab_states.get(active_tab_id) if active_tab_id else None
        if active_tab_id and active_state and not active_state.query and not active_state.result_list and not active_state.loading:
            active_state.query = canonical_tag
            self.tabs[active_tab_id].search_edit.setText(canonical_tag)
            self.search_controller.start_search(active_tab_id, canonical_tag)
            return
        self.create_tab(initial_query=canonical_tag, auto_search=True)

    def notify_download_result(self, md5_value: str, success: bool):
        self.download_result_signal.emit(md5_value, success)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._sync_tab_bar_width()

    def closeEvent(self, event):
        try:
            theme_mgr.unsubscribe(self._apply_theme)
            self.image_viewer.hide()
            self.sql_recorder.close()
            self.zoom_mgr.shutdown()
        finally:
            super().closeEvent(event)
