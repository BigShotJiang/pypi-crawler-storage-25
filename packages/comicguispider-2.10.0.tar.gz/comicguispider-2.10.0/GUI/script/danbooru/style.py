import html
import re
from dataclasses import dataclass

from PySide6 import QtGui

from utils import ori_path
from GUI.core.font import font_color
from GUI.core.theme import CustTheme, theme_mgr
from GUI.core.theme.qss_template import read_templated_qss_tokens, render_templated_qss_section

DEFAULT_TAB_STATUS_CLASS = "theme-tip"


def default_tab_status_text() -> str:
    return "空词搜索进入首页"

CARD_WIDTH_BASE = 228
CARD_PREVIEW_BASE_HEIGHT = 168
CARD_PREVIEW_MIN_HEIGHT = 156
CARD_PREVIEW_MAX_HEIGHT = 182
CARD_PREVIEW_WIDTH_PADDING = 20
CARD_ZOOM_WIDTHS = (148, 188, 228, 268, 308, 348, 388)
DEFAULT_CARD_ZOOM_INDEX = 2

_RGB_COLOR_RE = re.compile(
    r"(?P<fn>rgb|rgba)\(\s*(?P<r>\d{1,3})\s*,\s*(?P<g>\d{1,3})\s*,\s*(?P<b>\d{1,3})"
    r"(?:\s*,\s*(?P<a>[\d.]+))?\s*\)$",
    re.IGNORECASE,
)
_DANBOORU_QSS_PATH = ori_path.joinpath("GUI/core/theme/danbooru.qss")


@dataclass(frozen=True, slots=True)
class DanbooruCardMetrics:
    width: int
    preview_base_height: int
    preview_min_height: int
    preview_max_height: int

    @property
    def preview_content_width(self) -> int:
        return max(1, self.width - CARD_PREVIEW_WIDTH_PADDING)


def _build_card_metrics(width: int) -> DanbooruCardMetrics:
    scale = width / CARD_WIDTH_BASE
    return DanbooruCardMetrics(
        width=width,
        preview_base_height=max(1, int(round(CARD_PREVIEW_BASE_HEIGHT * scale))),
        preview_min_height=max(1, int(round(CARD_PREVIEW_MIN_HEIGHT * scale))),
        preview_max_height=max(1, int(round(CARD_PREVIEW_MAX_HEIGHT * scale))),
    )


CARD_ZOOM_METRICS = tuple(_build_card_metrics(width) for width in CARD_ZOOM_WIDTHS)
DEFAULT_CARD_METRICS = CARD_ZOOM_METRICS[DEFAULT_CARD_ZOOM_INDEX]


def _current_theme_name() -> str:
    return "dark" if theme_mgr.get_theme() == CustTheme.DARK else "light"


def get_danbooru_qss_tokens() -> dict[str, str]:
    return read_templated_qss_tokens(_DANBOORU_QSS_PATH, _current_theme_name())


def _render_qss_section(name: str, **overrides: str) -> str:
    return render_templated_qss_section(_DANBOORU_QSS_PATH, _current_theme_name(), name, **overrides)


@dataclass(frozen=True, slots=True)
class DanbooruUiPalette:
    canvas: str
    shell: str
    shell_border: str
    card: str
    card_hover: str
    downloaded_card: str
    downloaded_hover: str
    preview: str
    preview_hover: str
    section: str
    section_border: str
    text: str
    muted_text: str
    status_text: str
    viewer_frame: str
    viewer_border: str
    viewer_image: str
    viewer_tag: str
    viewer_tag_hover: str
    selection_border: str
    title_accent: str
    pivot_selected: str
    pivot_button_hover: str
    pivot_button_pressed: str

    @classmethod
    def current(cls) -> "DanbooruUiPalette":
        tokens = get_danbooru_qss_tokens()
        return cls(
            canvas=tokens["CANVAS"],
            shell=tokens["SHELL"],
            shell_border=tokens["SHELL_BORDER"],
            card=tokens["CARD_BACKGROUND_IDLE"],
            card_hover=tokens["CARD_HOVER_BORDER_IDLE"],
            downloaded_card=tokens["CARD_BACKGROUND_DOWNLOADED"],
            downloaded_hover=tokens["CARD_HOVER_BORDER_DOWNLOADED"],
            preview=tokens["CARD_PREVIEW_BACKGROUND"],
            preview_hover=tokens["CARD_PREVIEW_BACKGROUND_HOVER"],
            section=tokens["SECTION_BACKGROUND"],
            section_border=tokens["SECTION_BORDER"],
            text=tokens["TEXT"],
            muted_text=tokens["MUTED_TEXT"],
            status_text=tokens["STATUS_TEXT"],
            viewer_frame=tokens["VIEWER_FRAME"],
            viewer_border=tokens["VIEWER_BORDER"],
            viewer_image=tokens["VIEWER_IMAGE"],
            viewer_tag=tokens["VIEWER_TAG"],
            viewer_tag_hover=tokens["VIEWER_TAG_HOVER"],
            selection_border=tokens["SELECTION_BORDER"],
            title_accent=tokens["TITLE_ACCENT"],
            pivot_selected=tokens["PIVOT_SELECTED"],
            pivot_button_hover=tokens["PIVOT_BUTTON_HOVER"],
            pivot_button_pressed=tokens["PIVOT_BUTTON_PRESSED"],
        )


@dataclass(frozen=True, slots=True)
class DanbooruCardTheme:
    background: str
    border: str
    hover_border: str
    selection_border: str
    selection_fill_start: str
    selection_fill_mid: str
    selection_fill_end: str
    preview_background: str
    preview_background_hover: str
    preview_selected_border: str
    preview_selected_overlay_start: str
    preview_selected_overlay_end: str
    preview_unsupported_text: str
    preview_downloaded_grayscale: float
    preview_downloaded_opacity: float
    glow_color: str


def get_danbooru_card_theme(already_downloaded: bool) -> DanbooruCardTheme:
    tokens = get_danbooru_qss_tokens()
    return DanbooruCardTheme(
        background=tokens["CARD_BACKGROUND_DOWNLOADED"] if already_downloaded else tokens["CARD_BACKGROUND_IDLE"],
        border=tokens["CARD_BORDER_DOWNLOADED"] if already_downloaded else tokens["CARD_BORDER_IDLE"],
        hover_border=tokens["CARD_HOVER_BORDER_DOWNLOADED"] if already_downloaded else tokens["CARD_HOVER_BORDER_IDLE"],
        selection_border=tokens["CARD_SELECTION_BORDER"],
        selection_fill_start=tokens["CARD_SELECTION_FILL_START"],
        selection_fill_mid=tokens["CARD_SELECTION_FILL_MID"],
        selection_fill_end=tokens["CARD_SELECTION_FILL_END"],
        preview_background=tokens["CARD_PREVIEW_BACKGROUND"],
        preview_background_hover=tokens["CARD_PREVIEW_BACKGROUND_HOVER"],
        preview_selected_border=tokens["CARD_PREVIEW_SELECTED_BORDER"],
        preview_selected_overlay_start=tokens["CARD_PREVIEW_SELECTED_OVERLAY_START"],
        preview_selected_overlay_end=tokens["CARD_PREVIEW_SELECTED_OVERLAY_END"],
        preview_unsupported_text=tokens["CARD_PREVIEW_UNSUPPORTED_TEXT"],
        preview_downloaded_grayscale=max(0.0, min(1.0, float(tokens["CARD_PREVIEW_DOWNLOADED_GRAYSCALE"]))),
        preview_downloaded_opacity=max(0.0, min(1.0, float(tokens["CARD_PREVIEW_DOWNLOADED_OPACITY"]))),
        glow_color=tokens["CARD_GLOW_COLOR"],
    )


def qcolor_from_css(color: str) -> QtGui.QColor:
    qcolor = QtGui.QColor(color)
    if qcolor.isValid():
        return qcolor

    match = _RGB_COLOR_RE.fullmatch(color.strip())
    if match is None:
        raise ValueError(f"Unsupported color literal: {color}")

    red = min(255, int(match.group("r")))
    green = min(255, int(match.group("g")))
    blue = min(255, int(match.group("b")))
    alpha_group = match.group("a")
    if alpha_group is None:
        return QtGui.QColor(red, green, blue)

    alpha_value = float(alpha_group)
    if alpha_value <= 1:
        return QtGui.QColor.fromRgbF(red / 255, green / 255, blue / 255, alpha_value)
    return QtGui.QColor(red, green, blue, min(255, int(round(alpha_value))))


def format_tip_rich_text(text: str, cls: str = DEFAULT_TAB_STATUS_CLASS) -> str:
    color = theme_mgr.font_color
    css = (
        f"font.theme-tip {{ color: {color.tip}; }}"
        f"font.theme-success {{ color: {color.success}; }}"
        f"font.theme-err {{ color: {color.err}; }}"
    )
    safe_text = html.escape(text or "").replace("\n", "<br/>")
    fallback_color = {
        "theme-success": color.success,
        "theme-err": color.err,
    }.get(cls, color.tip)
    return f"<style>{css}</style>{font_color(safe_text, cls=cls or DEFAULT_TAB_STATUS_CLASS, color=fallback_color)}"


def build_card_stylesheet(palette: DanbooruUiPalette, already_downloaded: bool) -> str:
    _ = palette
    card_theme = get_danbooru_card_theme(already_downloaded)
    return _render_qss_section(
        "card",
        CARD_BACKGROUND=card_theme.background,
        CARD_BORDER=card_theme.border,
        CARD_HOVER_BORDER=card_theme.hover_border,
    )


def build_viewer_stylesheet(palette: DanbooruUiPalette) -> str:
    _ = palette
    return _render_qss_section("viewer")


def build_tab_stylesheet(palette: DanbooruUiPalette) -> str:
    _ = palette
    return _render_qss_section("tab")


def build_interface_stylesheet(palette: DanbooruUiPalette) -> str:
    _ = palette
    return _render_qss_section("interface")


def build_favorites_tree_item_stylesheet() -> str:
    return _render_qss_section("favorites_tree_item_inline")


def build_title_label_stylesheet(palette: DanbooruUiPalette) -> str:
    _ = palette
    return _render_qss_section("title_label_inline")


def build_tip_line_stylesheet(palette: DanbooruUiPalette) -> str:
    _ = palette
    return _render_qss_section("tip_line_inline")
