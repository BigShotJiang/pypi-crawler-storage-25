from copy import deepcopy

from GUI.core.timer import safe_single_shot
from PySide6.QtWidgets import QApplication

from assets import res
from utils import curr_os, ori_path


class CopyUnfinished:
    copy_delay = 150 if curr_os != "macOS" else 300
    copied = 0
    
    def __init__(self, tasks):
        self.tasks = deepcopy(tasks)
        self.length = len(self.tasks)

    def to_clip(self):
        def copy_to_clipboard(text):
            QApplication.clipboard().setText(text)
        for i, task in enumerate(self.tasks):
            safe_single_shot(self.copy_delay * (i + 1), 
                lambda t=task.title_url: copy_to_clipboard(t))


class TextUtils:
    @staticmethod
    def description():
        return r"""<style>* {margin: 1px;padding: 1px;}</style><div>
    <div>
        <p><font class="theme-tip">%s</font></p>
        <p><font class="theme-tip">%s</font></p>
        <hr><p></p>
    </div></div>
    """ % (res.GUI.DESC1 % rf'file:///{ori_path.joinpath("assets/config_icon.png")}', 
           res.GUI.DESC2)
