#!/usr/bin/env python3

import os
import re
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path

from .forwarder import PortForwarder
from .history_logger import HistoryLogger
from .logger import console, debug
from .network_watchdog import NetworkWatchdog
from .validators import (
    extract_kubectl_global_flags,
    extract_local_port,
    validate_context,
    validate_kubectl_command,
    validate_port_availability,
    validate_port_format,
    validate_service_and_endpoints,
)
from .watcher import EndpointWatcher

restart_event = threading.Event()
shutdown_event = threading.Event()

# Track Ctrl+C presses for force exit
_sigint_count = 0

# Initialize Rich console


def _signal_handler(signum, frame):
    """Handle SIGINT (Ctrl+C) with force exit on second press."""
    global _sigint_count
    _sigint_count += 1

    if _sigint_count == 1:
        console.print("\n[yellow]Ctrl+C detected. Shutting down gracefully...[/yellow]")
        console.print("[yellow]Press Ctrl+C again to force exit.[/yellow]")
        debug.print("First SIGINT received, initiating graceful shutdown")
        shutdown_event.set()
    else:
        console.print("\n[red]Force exit requested. Terminating immediately...[/red]")
        debug.print("Second SIGINT received, forcing exit")
        sys.exit(1)


def get_port_forward_args(args):
    """
    Parses command-line arguments to extract the port-forward arguments.
    """
    if not args:
        console.print("Usage: python kpf.py <kubectl port-forward args>")
        sys.exit(1)
    return args


def get_watcher_args(port_forward_args, kubectl_global_flags=None):
    """
    Parses port-forward arguments to determine the namespace and resource name
    for the endpoint watcher command.
    Example: `['svc/frontend', '9090:9090', '-n', 'kubecost']` -> namespace='kubecost', resource_name='frontend'
    """
    if kubectl_global_flags is None:
        kubectl_global_flags = []
    debug.print(f"Parsing port-forward args: {port_forward_args}")
    namespace = None
    resource_name = None

    # Find namespace
    try:
        n_index = port_forward_args.index("-n")
        if n_index + 1 < len(port_forward_args):
            namespace = port_forward_args[n_index + 1]
            debug.print(f"Found namespace in args: {namespace}")
    except ValueError:
        pass  # '-n' flag not found

    # If namespace not found or incomplete, use current context namespace
    if namespace is None:
        cmd = (
            ["kubectl"]
            + kubectl_global_flags
            + ["config", "view", "--minify", "-o", "jsonpath={..namespace}"]
        )
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, check=True, timeout=5)
            namespace = result.stdout.strip() or "default"
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
            namespace = "default"
        debug.print(f"No namespace specified, using current context namespace: '{namespace}'")

    # Find resource name (e.g., 'svc/frontend')
    for arg in port_forward_args:
        # Use regex to match patterns like 'svc/my-service' or 'pod/my-pod'
        # We accept any resource type (characters, numbers, dashes, dots)
        match = re.match(r"([a-z0-9.-]+)/(.+)", arg)
        if match:
            # The resource name is the second group in the regex match
            resource_name = match.group(2)
            debug.print(f"Found resource: {match.group(1)}/{resource_name}")
            break

    if not resource_name:
        debug.print("ERROR: Could not determine resource name from args")
        console.print("Could not determine resource name for endpoint watcher.")
        sys.exit(1)

    debug.print(f"Final parsed values - namespace: {namespace}, resource_name: {resource_name}")
    return namespace, resource_name


def run_port_forward(
    port_forward_args, debug_mode: bool = False, config=None, run_http_health_checks: bool = False
):
    """
    The main function to orchestrate the two threads.

    Args:
        port_forward_args: Arguments for kubectl port-forward
        debug_mode: Enable debug output
        config: KpfConfig instance (optional)
        run_http_health_checks: Enable HTTP connectivity health checks (optional, default: False)
    """
    global _sigint_count  # Keep existing sigint global but remove _debug_enabled global
    debug.enabled = debug_mode

    if debug_mode:
        debug.print("Debug mode enabled")

    # Initialize history
    history_logger = HistoryLogger(config)

    # Extract kubectl global flags (--context, --kubeconfig) early
    kubectl_global_flags = extract_kubectl_global_flags(port_forward_args)
    if kubectl_global_flags:
        debug.print(f"Kubectl global flags: {kubectl_global_flags}")

    # Validate context/kubeconfig before anything else
    if not validate_context(kubectl_global_flags):
        history_logger.finalize("context_error")
        sys.exit(1)

    # Validate port format first
    if not validate_port_format(port_forward_args):
        history_logger.finalize("validation_error")
        sys.exit(1)

    # Validate port availability (pass config for auto-select feature)
    if not validate_port_availability(port_forward_args, debug.print, config):
        history_logger.finalize("port_unavailable")
        sys.exit(1)

    # Validate kubectl command
    if not validate_kubectl_command(port_forward_args):
        history_logger.finalize("kubectl_error")
        sys.exit(1)

    # Validate service exists and has endpoints
    if not validate_service_and_endpoints(port_forward_args, debug.print, kubectl_global_flags):
        history_logger.finalize("service_error")
        sys.exit(1)

    # Get watcher arguments from the port-forwarding args
    namespace, resource_name = get_watcher_args(port_forward_args, kubectl_global_flags)
    debug.print(f"Parsed namespace: {namespace}, resource_name: {resource_name}")

    debug.print(f"Port-forward arguments: {port_forward_args}")
    debug.print(f"Endpoint watcher target: namespace={namespace}, resource_name={resource_name}")

    # Extract port and context information for history
    local_port = extract_local_port(port_forward_args)
    remote_port = None  # Will be extracted if available
    for arg in port_forward_args:
        if ":" in arg and not arg.startswith("-"):
            parts = arg.split(":", 1)
            if len(parts) == 2:
                try:
                    remote_port = int(parts[1])
                    break
                except ValueError:
                    pass

    # Get context from flags or current kubectl config
    context = ""
    for i, flag in enumerate(kubectl_global_flags):
        if flag == "--context" and i + 1 < len(kubectl_global_flags):
            context = kubectl_global_flags[i + 1]
            break
    if not context:
        try:
            from .kubernetes import KubernetesClient

            k8s = KubernetesClient()
            context = k8s.get_current_context()
        except Exception:
            pass

    # Detect listen_all from port_forward_args
    listen_all = False
    try:
        addr_idx = port_forward_args.index("--address")
        listen_all = port_forward_args[addr_idx + 1] == "0.0.0.0"
    except (ValueError, IndexError):
        pass

    # Resolve kubeconfig: explicit flag > KUBECONFIG env > default path
    kubeconfig = ""
    for i, flag in enumerate(kubectl_global_flags):
        if flag == "--kubeconfig" and i + 1 < len(kubectl_global_flags):
            kubeconfig = kubectl_global_flags[i + 1]
            break
    if not kubeconfig:
        env_kubeconfig = os.environ.get("KUBECONFIG", "")
        if env_kubeconfig:
            kubeconfig = env_kubeconfig.split(os.pathsep)[0]
    if not kubeconfig:
        kubeconfig = str(Path("~/.kube/config").expanduser())

    # Set session info in usage logger
    history_logger.set_session_info(
        resource_name, namespace, context, kubeconfig, listen_all, local_port, remote_port
    )

    # Create forwarder and watcher instances
    forwarder = PortForwarder(
        port_forward_args,
        shutdown_event,
        restart_event,
        debug_callback=debug.print,
        config=config,
        history_logger=history_logger,
        no_health_check=not run_http_health_checks,
    )

    # define delegate method for watcher to check if it should trigger restart on forwarder
    def should_restart_delegate():
        return forwarder.should_restart_port_forward()

    watcher = EndpointWatcher(
        namespace,
        resource_name,
        shutdown_event,
        restart_event,
        should_restart_delegate,
        debug_callback=debug.print,
        history_logger=history_logger,
        kubectl_global_flags=kubectl_global_flags,
    )

    # Create network watchdog if enabled
    watchdog = None
    watchdog_enabled = config.get("networkWatchdogEnabled", True) if config else True
    if watchdog_enabled:
        watchdog_interval = config.get("networkWatchdogInterval", 5) if config else 5
        watchdog_threshold = config.get("networkWatchdogFailureThreshold", 2) if config else 2
        watchdog = NetworkWatchdog(
            shutdown_event=shutdown_event,
            restart_event=restart_event,
            interval=watchdog_interval,
            failure_threshold=watchdog_threshold,
            debug_callback=debug.print,
            local_port=local_port,
            kubectl_global_flags=kubectl_global_flags,
        )
        debug.print(
            f"Network watchdog enabled (interval={watchdog_interval}s, threshold={watchdog_threshold}, port={local_port})"
        )

    debug.print("Starting threads")
    forwarder.start()
    watcher.start()
    if watchdog:
        watchdog.start()

    # Register signal handler for graceful shutdown
    signal.signal(signal.SIGINT, _signal_handler)

    try:
        # Keep the main thread alive while the other threads are running
        while forwarder.is_alive() and watcher.is_alive() and not shutdown_event.is_set():
            # Also check watchdog if enabled (daemon thread, so don't block on it)
            if watchdog and not watchdog.is_alive():
                debug.print("Network watchdog thread died unexpectedly")
            time.sleep(0.5)  # Check more frequently for shutdown

    except KeyboardInterrupt:
        # This should be handled by signal handler now, but keep as fallback
        debug.print("KeyboardInterrupt in main loop (fallback)")
        shutdown_event.set()
        history_logger.finalize("user_interrupt")

    finally:
        # Signal a graceful shutdown
        debug.print("Setting shutdown event")
        shutdown_event.set()

        # Wait for threads to finish with timeout
        debug.print("Waiting for threads to finish...")
        forwarder.join(timeout=3)  # Give a bit more time for graceful shutdown
        watcher.join(timeout=3)
        if watchdog:
            watchdog.join(timeout=1)  # Watchdog is daemon, short timeout

        threads_alive = []
        if forwarder.is_alive():
            threads_alive.append("port-forward")
        if watcher.is_alive():
            threads_alive.append("endpoint-watcher")
        if watchdog and watchdog.is_alive():
            threads_alive.append("network-watchdog")

        if threads_alive:
            debug.print(f"Threads still running: {', '.join(threads_alive)}")
            console.print(
                f"[yellow]Some threads did not shut down cleanly: {', '.join(threads_alive)}[/yellow]"
            )

            # Force terminate subprocesses directly since threads are stuck
            debug.print("Force terminating subprocesses...")
            if hasattr(forwarder, "terminate_process"):
                forwarder.terminate_process()
            if hasattr(watcher, "terminate_process"):
                watcher.terminate_process()

            console.print("[Main] Exiting.")
            history_logger.finalize("forced_exit")
            # Force exit immediately instead of hanging
            os._exit(1)
        else:
            debug.print("All threads have shut down cleanly")
            console.print("[Main] Exiting.")
            history_logger.finalize("normal_exit")


def main():
    """Legacy main function for backward compatibility."""
    port_forward_args = get_port_forward_args(sys.argv[1:])
    run_port_forward(port_forward_args)


if __name__ == "__main__":
    main()
