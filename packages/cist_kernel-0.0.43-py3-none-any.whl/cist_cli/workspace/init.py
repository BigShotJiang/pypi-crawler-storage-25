"""CIST workspace initialiser — creates the standard directory scaffold."""

from __future__ import annotations

from pathlib import Path

from .templates import BENCH_EXAMPLE, ENV_TEMPLATE, EXAMPLE_CONTRACT, cist_toml


def init_workspace(path: Path, contract_name: str = "example") -> dict[str, Path]:
    """Create the CIST workspace scaffold under *path*.

    Parameters
    ----------
    path:
        Target root directory.  Created if it does not exist.
    contract_name:
        Name of the starter contract sub-directory (default: ``"example"``).

    Returns
    -------
    dict
        A mapping of logical names to the :class:`~pathlib.Path` objects that
        were created (or that already existed), so callers can report them.

        Keys: ``root``, ``contracts_dir``, ``contract_dir``, ``contract_file``,
        ``bench_dir``, ``bench_file``, ``env_file``, ``toml_file``.
    """
    from cist_cli import __version__

    root = path.expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)

    # ── contracts/{name}/ ────────────────────────────────────────────────────
    contracts_dir = root / "contracts"
    contracts_dir.mkdir(exist_ok=True)

    contract_dir = contracts_dir / contract_name
    contract_dir.mkdir(exist_ok=True)

    contract_file = contract_dir / f"{contract_name}.cis"
    if not contract_file.exists():
        contract_file.write_text(EXAMPLE_CONTRACT, encoding="utf-8")

    # ── contracts/{name}/bench/ ──────────────────────────────────────────────
    bench_dir = contract_dir / "bench"
    bench_dir.mkdir(exist_ok=True)

    bench_file = bench_dir / "example.cis"
    if not bench_file.exists():
        bench_file.write_text(BENCH_EXAMPLE, encoding="utf-8")

    # ── .env ─────────────────────────────────────────────────────────────────
    env_file = root / ".env"
    if not env_file.exists():
        env_file.write_text(ENV_TEMPLATE, encoding="utf-8")

    # ── cist.toml ────────────────────────────────────────────────────────────
    toml_file = root / "cist.toml"
    if not toml_file.exists():
        toml_file.write_text(cist_toml(contract_name, __version__), encoding="utf-8")

    # ── .gitignore ───────────────────────────────────────────────────────────
    gitignore_file = root / ".gitignore"
    _ensure_gitignore_entries(gitignore_file)

    return {
        "root": root,
        "contracts_dir": contracts_dir,
        "contract_dir": contract_dir,
        "contract_file": contract_file,
        "bench_dir": bench_dir,
        "bench_file": bench_file,
        "env_file": env_file,
        "toml_file": toml_file,
    }


def _ensure_gitignore_entries(gitignore_file: Path) -> None:
    """Ensure ``*.mex`` and ``.env`` are listed in *gitignore_file*.

    Creates the file if absent; appends missing entries otherwise.
    """
    required = ["*.mex", ".env"]

    if not gitignore_file.exists():
        gitignore_file.write_text("\n".join(required) + "\n", encoding="utf-8")
        return

    existing = gitignore_file.read_text(encoding="utf-8")
    missing = [entry for entry in required if entry not in existing.splitlines()]
    if missing:
        separator = "" if existing.endswith("\n") else "\n"
        gitignore_file.write_text(
            existing + separator + "\n".join(missing) + "\n",
            encoding="utf-8",
        )
