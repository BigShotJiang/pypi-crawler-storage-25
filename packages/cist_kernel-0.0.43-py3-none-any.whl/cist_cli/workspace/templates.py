"""CIST workspace initialiser — content templates for generated files."""

from __future__ import annotations

EXAMPLE_CONTRACT = """\
# this contract uses the hyper nursery to deliver the price of oil over a period of 14 days to max at least $24,000 in pnl

use math
use hyper

# define a few utility functions to halp in the contract design
write fn get_oil_price():
    # the definition of the variables used in the function
    which defines:
        oil_price = hype.get_price("OIL")
        time_in_minutes=math.floor(compute.now()/60)
        current_time=compute.now()

    then:
        # the logic to fetch the price of oil every 3 minutes
        if time_in_minutes % 3 == 0:
            oil_price = hype.get_price("OIL")
        else:
            oil_price = hype.get_price("OIL")

    then:
        return oil_price

# parse the loop in as the execution intent for the contract to run indefinitely
contract OilPriceMonitor:
    which defines:
        while True:
            oil_price = get_oil_price()

            then:
                if oil_price > 80.0:
                    print("Oil price is high, consider selling.")
                elif oil_price < 40.0:
                    print("Oil price is low, consider buying.")
                else:
                    print("Oil price is stable, hold your position.")

            then:
                compute.sleep(180)  # sleep for 3 minutes (180 seconds)
                if compute.now() >= current_time + 14 * 24 * 60 * 60:
                    break
"""

BENCH_EXAMPLE = """\
# bench file for OilPriceMonitor — extend with your own test scenarios

use math
use hyper

# scenario: price above threshold triggers sell signal
contract BenchHighPrice:
    which defines:
        oil_price = 90.0  # simulated high price

        then:
            if oil_price > 80.0:
                print("bench: high price path OK")

# scenario: price below threshold triggers buy signal
contract BenchLowPrice:
    which defines:
        oil_price = 30.0  # simulated low price

        then:
            if oil_price < 40.0:
                print("bench: low price path OK")
"""

ENV_TEMPLATE = """\
# CIST Cloud API
CIST_CLOUD_API_KEY=
CIST_CLOUD_ENDPOINT=https://api.cist.io/v1
"""


def cist_toml(name: str, kernel_version: str) -> str:
    """Return the content for the ``cist.toml`` config file."""
    return f"""\
# CIST workspace configuration
# https://docs.cist.io/configuration

[project]
name = "{name}"
version = "0.1.0"
description = ""

[kernel]
# Kernel version this workspace was initialised with
version = "{kernel_version}"

[compiler]
# Set to true to treat all warnings as errors
strict = false
"""
