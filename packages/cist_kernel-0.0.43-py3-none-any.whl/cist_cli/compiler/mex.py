"""MEX (Model EXecutable) binary format.

A ``.mex`` file holds the compiled IR for a ``.cis`` contract.  The format is
intentionally non-human-readable: the IR JSON is zlib-compressed and wrapped
in a short binary envelope, making the file opaque to plain-text viewers while
staying fully reproducible from the same source.

Binary layout
-------------
Offset  Size   Content
------  -----  ----------------------------
0       4      Magic identifier: 0x4D455800  ("MEX\\x00")
4       2      Format version: big-endian uint16, currently 0x0001
6       4      CRC-32 of the compressed payload (big-endian uint32)
10      N      zlib-compressed UTF-8 JSON payload
"""

from __future__ import annotations

import json
import struct
import zlib
from pathlib import Path
from typing import Any

# ── format constants ─────────────────────────────────────────────────────────

_MAGIC = b"MEX\x00"
_FORMAT_VERSION = 1
_HEADER_STRUCT = struct.Struct(">4sHI")  # magic(4s) + version(H) + crc(I)
_HEADER_SIZE = _HEADER_STRUCT.size       # 10 bytes


class MexError(Exception):
    """Raised when a .mex file cannot be read or fails integrity checks."""


class MexWriter:
    """Serialise a compiled IR dict into the MEX binary format."""

    def write(self, ir: dict[str, Any], path: Path) -> None:
        """Write *ir* to *path* as a ``.mex`` binary.

        The ``content`` key (raw source text) is stripped before serialisation
        so the binary does not expose original source code.
        """
        safe_ir = {k: v for k, v in ir.items() if k != "content"}
        # Warnings hold SyntaxIssue dataclasses; serialise them as plain dicts
        safe_ir["warnings"] = [
            {"line": w.line, "message": w.message, "severity": w.severity}
            for w in safe_ir.get("warnings", [])
        ]

        payload = zlib.compress(
            json.dumps(safe_ir, separators=(",", ":")).encode("utf-8"),
            level=9,
        )
        crc = zlib.crc32(payload) & 0xFFFFFFFF
        header = _HEADER_STRUCT.pack(_MAGIC, _FORMAT_VERSION, crc)

        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(header + payload)


class MexReader:
    """Deserialise a ``.mex`` binary back into an IR dict."""

    def read(self, path: Path) -> dict[str, Any]:
        """Read and verify *path*, returning the IR dict.

        Raises :class:`MexError` on missing files, bad magic, version mismatches,
        or CRC failures.
        """
        try:
            raw = path.read_bytes()
        except OSError as exc:
            raise MexError(f"Cannot read .mex file: {exc}") from exc

        if len(raw) < _HEADER_SIZE:
            raise MexError("File is too short to be a valid .mex binary")

        magic, version, stored_crc = _HEADER_STRUCT.unpack(raw[:_HEADER_SIZE])

        if magic != _MAGIC:
            raise MexError(
                f"Bad magic bytes: expected {_MAGIC!r}, got {magic!r}"
            )
        if version != _FORMAT_VERSION:
            raise MexError(
                f"Unsupported .mex version {version} (expected {_FORMAT_VERSION})"
            )

        payload = raw[_HEADER_SIZE:]
        actual_crc = zlib.crc32(payload) & 0xFFFFFFFF
        if actual_crc != stored_crc:
            raise MexError(
                f"CRC mismatch: stored {stored_crc:#010x}, computed {actual_crc:#010x}"
            )

        try:
            decompressed = zlib.decompress(payload)
        except zlib.error as exc:
            raise MexError(f"Decompression failed: {exc}") from exc

        try:
            return json.loads(decompressed.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise MexError(f"Payload decoding failed: {exc}") from exc
