from __future__ import annotations

import json
import os
from typing import Any, Generator
from urllib.parse import urljoin

import requests


class CloudCourier:
    """Manage streaming requests to the CIST Cloud compilation API."""

    DEFAULT_ENDPOINT = "https://api.cist.io/v1"

    def __init__(
        self, api_key: str | None = None, endpoint: str | None = None
    ) -> None:
        self.api_key = api_key or os.getenv("CIST_CLOUD_API_KEY")
        self.endpoint = (
            endpoint or os.getenv("CIST_CLOUD_ENDPOINT", self.DEFAULT_ENDPOINT)
        ).rstrip("/")

        if not self.api_key:
            raise ValueError("CIST_CLOUD_API_KEY not set in environment")

    def stream_compile(
        self, ast: dict[str, Any], deploy: bool = False
    ) -> Generator[dict[str, Any], None, None]:
        """Stream compilation events from the cloud compiler via SSE."""
        url = urljoin(f"{self.endpoint}/", "compile")
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        }
        params = {"deploy": "true"} if deploy else {}
        payload = {
            "source": ast["content"],
            "modules": ast.get("modules", []),
            "metadata": {
                "lines": ast.get("line_count", 0),
                "data_streams": ast.get("data_streams", 0),
            },
        }

        try:
            response = requests.post(
                url,
                json=payload,
                headers=headers,
                params=params,
                stream=True,
                timeout=30,
            )
            response.raise_for_status()

            buffer = ""
            for chunk in response.iter_content(chunk_size=1024, decode_unicode=True):
                if not chunk:
                    continue
                if isinstance(chunk, bytes):
                    buffer += chunk.decode("utf-8", errors="replace")
                else:
                    buffer += chunk

                while "\n\n" in buffer:
                    message, buffer = buffer.split("\n\n", 1)
                    yield self._parse_sse(message)

            if buffer.strip():
                yield self._parse_sse(buffer)
        except requests.exceptions.HTTPError as exc:
            response = exc.response
            status_code = response.status_code if response is not None else None
            if status_code == 401:
                raise ConnectionError("Invalid API key (401)") from exc
            if status_code == 429:
                raise ConnectionError("Rate limit exceeded (429)") from exc
            if status_code is None:
                raise ConnectionError("HTTP error during compilation request") from exc
            raise ConnectionError(f"HTTP error {status_code}") from exc
        except requests.exceptions.RequestException as exc:
            raise ConnectionError(f"Network error: {exc}") from exc

    def _parse_sse(self, message: str) -> dict[str, Any]:
        """Parse a single Server-Sent Events message into a dictionary."""
        for line in message.strip().split("\n"):
            if line.startswith("data: "):
                payload = line[6:]
                try:
                    return json.loads(payload)
                except json.JSONDecodeError:
                    return {"type": "log", "message": payload}
        return {"type": "log", "message": message.strip()}