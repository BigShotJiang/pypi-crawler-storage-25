"""Allow `python -m cist_cli` as a fallback when the `cist` script is not on PATH.

Running with no arguments automatically runs `init`, so the full install flow is:
    pip install cist-kernel
    python -m cist_cli
"""
import sys
from pathlib import Path

from cist_cli.main import _init_workspace, app

if len(sys.argv) == 1:
    _init_workspace(path=Path("."))
else:
    app()
