from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Any

import typer
from dotenv import load_dotenv
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from . import __version__
from .compiler import CISTCompiler, MexWriter, ValidationError
from .network import CloudCourier
from .workspace import init_workspace

load_dotenv()

# On Windows, pip --user installs scripts to a folder not on PATH by default.
# Detect this and print a one-time actionable fix before the user hits a
# confusing "not recognized" error (they'd have to be running via python -m to
# even reach this point, so we can give them instructions to fix it properly).

def _warn_windows_path() -> None:
    if sys.platform != "win32":
        return
    scripts_dir = Path(os.environ.get("APPDATA", "")) / "Python" / f"Python{sys.version_info.major}{sys.version_info.minor}" / "Scripts"
    if not scripts_dir.exists():
        return
    path_dirs = [Path(p) for p in os.environ.get("PATH", "").split(os.pathsep)]
    if scripts_dir not in path_dirs:
        _console = Console(stderr=True)
        _console.print(
            f"\n[yellow bold]Windows PATH notice:[/yellow bold] "
            f"[cyan]{scripts_dir}[/cyan] is not on your PATH.\n"
            f"Run this once in PowerShell to fix it permanently, then reopen your terminal:\n\n"
            f'  [bold][Environment]::SetEnvironmentVariable("PATH", $env:PATH + ";{scripts_dir}", "User")[/bold]\n'
        )

_warn_windows_path()

# Target old versions and historical typos for deletion
_LEGACY_EXTENSION_IDS: list[str] = [
    "tooig research lab.cist",
    "tooig-research-lab.cist", 
]

def _extension_install_roots() -> list[Path]:
    """Generate a list of all possible extension directories."""
    configured_root = os.environ.get("VSCODE_EXTENSIONS", "").strip()
    user_home = Path(os.environ.get("USERPROFILE") or str(Path.home()))

    roots: list[Path] = []
    if configured_root:
        roots.append(Path(configured_root))

    roots.extend([
        user_home / ".antigravity" / "extensions",
        user_home / ".vscode" / "extensions",
        user_home / ".vscode-insiders" / "extensions"
    ])

    return list(set(roots))

def _read_vsix_package(vsix: Path) -> dict[str, str]:
    with zipfile.ZipFile(vsix) as archive:
        with archive.open("extension/package.json") as package_file:
            package = json.load(package_file)

    return {
        "publisher": str(package["publisher"]),
        "name": str(package["name"]),
        "version": str(package["version"]),
    }

def _retire_old_extension_dirs(root: Path, prefixes: list[str], exclude: Path) -> None:
    """Rename old extension directories to .vsctmp instead of deleting them.

    Renaming is atomic on Windows even when the editor holds file handles, so
    it avoids the file-lock errors that ``shutil.rmtree`` causes on that
    platform.  VS Code's own ``cleanUp()`` sweeps any ``*.vsctmp`` folders on
    the next startup, finishing the removal safely.
    """
    if not root.is_dir():
        return
    for entry in root.iterdir():
        if not entry.is_dir() or entry == exclude:
            continue
        name_lower = entry.name.lower()
        if any(name_lower.startswith(prefix.lower()) for prefix in prefixes):
            temp_path = root / f"{entry.name}.vsctmp"
            try:
                entry.rename(temp_path)
            except OSError:
                # Rename failed (e.g. cross-device); fall back to direct delete.
                try:
                    shutil.rmtree(entry)
                except OSError:
                    pass

def _extract_vsix_extension(vsix: Path, target_dir: Path) -> None:
    if target_dir.exists():
        shutil.rmtree(target_dir)
    target_dir.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(vsix) as archive:
        for member in archive.infolist():
            if member.is_dir() or not member.filename.startswith("extension/"):
                continue

            relative_name = member.filename[len("extension/") :]
            if not relative_name:
                continue

            destination = target_dir / relative_name
            destination.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(member) as source, destination.open("wb") as output:
                shutil.copyfileobj(source, output)

def _latest_bundled_vsix() -> Path | None:
    assets_dir = Path(__file__).parent / "assets"
    vsix_files = sorted(assets_dir.glob("*.vsix"))
    if not vsix_files:
        return None
    return vsix_files[-1]

def _install_vscode_extension(vsix: Path) -> tuple[bool, str, bool]:
    """Silently extract the VSIX.  Returns ``(ok, message, is_new_install)``.

    *is_new_install* is ``False`` when every target root already had the
    correct version installed, meaning no editor reload is required.
    """
    try:
        package = _read_vsix_package(vsix)
    except Exception as exc:
        return False, f"Could not read VSIX metadata: {exc}", False

    extension_id = f"{package['publisher']}.{package['name']}"
    version = package["version"]

    # Target old versions and historical names for retirement.
    prefixes_to_remove = [f"{ext_id.lower()}-" for ext_id in _LEGACY_EXTENSION_IDS]
    prefixes_to_remove.append(f"{extension_id.lower()}-")

    installed_paths: list[str] = []
    skipped_paths: list[str] = []
    install_error: str | None = None

    for root in _extension_install_roots():
        try:
            target_dir = root / f"{extension_id}-{version}"

            # Already at this exact version — nothing to do, no restart needed.
            if target_dir.exists():
                skipped_paths.append(str(root.parent.name))
                continue

            root.mkdir(parents=True, exist_ok=True)

            # 1. Retire old versions by renaming to .vsctmp (atomic on Windows,
            #    avoids file-lock errors when the editor is open). VS Code's
            #    own cleanUp() removes .vsctmp directories on the next startup.
            _retire_old_extension_dirs(root, prefixes_to_remove, exclude=target_dir)

            # 2. Extract the new version.
            _extract_vsix_extension(vsix, target_dir)

            # 3. Bust the manifest cache so VS Code rescans on next reload.
            cache_file = root / "extensions.json"
            if cache_file.exists():
                cache_file.unlink()

            installed_paths.append(str(root.parent.name))
        except Exception as exc:
            install_error = str(exc)

    is_new_install = bool(installed_paths)

    if installed_paths or skipped_paths:
        parts: list[str] = []
        if installed_paths:
            parts.append(f"Installed to: {', '.join(installed_paths)}")
        if skipped_paths:
            parts.append(f"already v{version} in: {', '.join(skipped_paths)}")
        return True, "; ".join(parts), is_new_install

    return False, install_error or "Unable to install to any extensions directory", False

def _sync_vscode_extension() -> tuple[bool, str]:
    if os.environ.get("CIST_SKIP_VSCODE_INSTALL") == "1":
        return False, "[dim]Extension install skipped (CIST_SKIP_VSCODE_INSTALL=1)[/dim]"

    vsix = _latest_bundled_vsix()
    
    if vsix is None:
        return False, "[yellow]![/yellow] Bundled extension not found in cist_cli/assets"

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task(description="Getting you all set...", total=None)
        ok, install_output, is_new_install = _install_vscode_extension(vsix)

    if ok:
        lines = [f"[green]✓[/green] Extension synced from [cyan]{vsix.name}[/cyan]"]
        if install_output:
            lines.append(f"  [dim]{install_output}[/dim]")
        if is_new_install:
            lines.append("  [dim]Reload window to activate: Ctrl+Shift+P → Developer: Reload Window[/dim]")
        return True, "\n".join(lines)

    detail = f"\n  [dim]{install_output}[/dim]" if install_output else ""
    return (
        False,
        "[yellow]![/yellow] Extension install failed."
        + detail
    )

app = typer.Typer(
    name="cist",
    help="Contract Instruction Set",
    no_args_is_help=True,
)
console = Console()


def _resolve_cis_path(filepath: Path) -> Path:
    resolved = filepath.expanduser().resolve()
    if resolved.suffix.lower() != ".cis":
        console.print(f"[red]Error:[/red] Expected .cis file, got {resolved.suffix}")
        raise typer.Exit(1)
    return resolved


def _print_warnings(result: dict[str, Any]) -> None:
    warnings = result.get("warnings", [])
    for warning in warnings:
        console.print(
            f"[yellow]! Line {warning.line}:[/yellow] {warning.message}"
        )


@app.callback()
def callback() -> None:
    """CIST - Contract Instruction Set Toolkit."""


def _init_workspace(path: Path) -> None:
    paths = init_workspace(path)

    # ── VS Code extension install ─────────────────────────────────────────────
    _, vscode_line = _sync_vscode_extension()

    # ── summary ──────────────────────────────────────────────────────────────
    console.print(
        Panel.fit(
            f"[bold green]CIST Ready[/bold green]\n\n"
            f"Workspace:  [cyan]{paths['root']}[/cyan]\n"
            f"Contracts:  [cyan]{paths['contracts_dir']}[/cyan]\n"
            f"Contract:   [cyan]{paths['contract_file']}[/cyan]\n"
            f"Bench:      [cyan]{paths['bench_dir']}[/cyan]\n"
            f"Config:     [cyan]{paths['toml_file']}[/cyan]\n"
            f"Env:        [cyan]{paths['env_file']}[/cyan]\n\n"
            f"{vscode_line}\n\n"
            f"Next steps:\n"
            f"  1. Add your API key to [bold].env[/bold]\n"
            f"  2. Open [bold]{paths['contract_file'].name}[/bold] and start writing\n"
            f"  3. Run [bold]cist compile <file.cis>[/bold] to build and deploy",
            title=f"cist-kernel v{__version__}",
        )
    )


@app.command()
def init(
    path: Path = typer.Option(
        Path("."),
        "--path",
        "-p",
        file_okay=False,
        help="Target directory",
    ),
) -> None:
    """Initialize a CIST workspace."""
    _init_workspace(path=path)


@app.command("sync-vscode-extension")
def sync_vscode_extension() -> None:
    """Install or update the bundled VS Code extension."""
    ok, message = _sync_vscode_extension()
    console.print(message)
    if not ok:
        raise typer.Exit(1)


@app.command()
def compile(
    filepath: Path = typer.Argument(
        ...,
        exists=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help="Path to .cis file",
    ),
    deploy: bool = typer.Option(
        False,
        "--deploy",
        "-d",
        help="Deploy to live execution",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose output"),
) -> None:
    """Compile locally, then stream the CIST source to the cloud compiler."""
    resolved = _resolve_cis_path(filepath)
    compiler = CISTCompiler()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task(description="Checking syntax...", total=None)
        try:
            ast = compiler.compile_file(resolved)
        except ValidationError as exc:
            console.print(f"[red]Syntax error:[/red] {exc}")
            raise typer.Exit(1) from exc

    _print_warnings(ast)
    modules_str = ", ".join(ast["modules"]) or "none"
    console.print(
        f"[green]✓[/green] [bold]{resolved.name}[/bold]  "
        f"[dim]{ast['line_count']} lines · modules: {modules_str} · "
        f"{ast['data_streams']} data stream(s)[/dim]"
    )
    if verbose:
        console.print(f"[dim]  modules  : {ast['modules']}[/dim]")
        console.print(f"[dim]  streams  : {ast['data_streams']}[/dim]")

    # ── emit program.mex binary ───────────────────────────────────────────────
    mex_path = resolved.parent / "program.mex"
    try:
        MexWriter().write(ast, mex_path)
        console.print(f"[green]✓[/green] Binary written → [cyan]{mex_path}[/cyan]")
    except OSError as exc:
        console.print(f"[yellow]![/yellow] Could not write .mex binary: {exc}")

    console.print("[cyan]Connecting to CIST Cloud...[/cyan]")
    try:
        courier = CloudCourier()
        for event in courier.stream_compile(ast, deploy=deploy):
            event_type = event.get("type")
            if event_type == "log":
                console.print(f"[dim][Cloud][/dim] {event.get('message', '')}")
            elif event_type == "artifact":
                console.print(
                    f"[bold green]ok Compiled:[/bold green] {event.get('artifact_id', 'unknown')}"
                )
            elif event_type == "error":
                console.print(
                    f"[bold red]x Build Error:[/bold red] {event.get('message', '')}"
                )
                raise typer.Exit(1)
            elif event_type == "complete":
                console.print("[green]Compilation complete[/green]")
    except ValueError as exc:
        console.print(f"[bold red]Configuration Error:[/bold red] {exc}")
        raise typer.Exit(1) from exc
    except ConnectionError as exc:
        console.print(f"[bold red]Connection Failed:[/bold red] {exc}")
        raise typer.Exit(1) from exc


if __name__ == "__main__":
    app()