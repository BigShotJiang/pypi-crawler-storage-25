"""Tests for the mzl-init CLI tool."""

from typer.testing import CliRunner
import pytest
from pathlib import Path

from mzl_init.cli import app
from mzl_init import __version__

runner = CliRunner()

def test_version():
    """Test the --version flag."""
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert __version__ in result.stdout

def test_doctor():
    """Test the doctor command executes without throwing exceptions."""
    result = runner.invoke(app, ["doctor"])
    assert result.exit_code == 0
    assert "mzl-init doctor" in result.stdout

def test_init_non_interactive(tmp_path: Path):
    """Test generating a project in non-interactive (CI) mode."""
    # Ensure tool runs in tmp_path to avoid creating project in current working dir
    # we can pass --output-dir argument (which we have added previously but let's check flag availability)
    
    project_name = "test_project_ci"
    out_dir = tmp_path / "output"
    out_dir.mkdir()
    
    result = runner.invoke(app, [
        "init", project_name, 
        "--output-dir", str(out_dir),
        "--type", "tabular",
        "--framework", "sklearn",
        "--no-fastapi",
        "--no-docker",
        "--no-mlflow",
        "--no-dvc",
        "--no-hydra"
    ])
    
    assert result.exit_code == 0
    assert "Project Ready" in result.stdout
    
    # Check if files are created properly
    project_dir = out_dir / project_name
    assert project_dir.exists()
    assert (project_dir / "pyproject.toml").exists()
    assert (project_dir / "src" / "models" / "model.py").exists()
    assert (project_dir / "src" / "training" / "train.py").exists()
