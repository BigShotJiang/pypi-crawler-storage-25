# 🚀 mzl-init

> A production-ready AI/ML project scaffolding CLI — like Vite, but for Machine Learning.

[![Python](https://img.shields.io/badge/python-3.9%2B-blue)](https://python.org)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

## Installation

```bash
pip install -e .
```

## Usage

### Interactive mode (recommended)

```bash
mzl-init my_project
```

Launches an arrow-key prompt to select:
- Project type (Tabular ML / Deep Learning / NLP / Computer Vision / LLM App)
- Framework (PyTorch / TensorFlow / Scikit-learn)
- Optional features: FastAPI, Docker, MLflow, DVC, Hydra

### Non-interactive mode (CI/CD)

```bash
mzl-init init my_project --type tabular --framework sklearn --docker --mlflow
```

### Check your environment

```bash
mzl-init doctor
```

### Version

```bash
mzl-init --version
```

## Generated Structure

```
my_project/
├── configs/            # YAML configuration files
├── data/raw|processed|external
├── docs/
├── models/             # Trained artifacts
├── notebooks/
├── reports/
├── scripts/
├── src/
│   ├── data/loader.py
│   ├── features/build_features.py
│   ├── models/model.py         ← framework-specific
│   ├── training/train.py       ← MLflow-aware
│   ├── evaluation/evaluate.py
│   ├── inference/predict.py
│   └── utils/logger.py
├── tests/
├── deployment/api|docker|cloud
├── .env
├── .gitignore
├── main.py
├── requirements.txt
└── pyproject.toml
```

## License

MIT
