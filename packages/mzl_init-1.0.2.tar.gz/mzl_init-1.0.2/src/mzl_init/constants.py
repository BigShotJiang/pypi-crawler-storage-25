"""Constants, enums, and compatibility matrices for mzl-init."""

from enum import Enum


class ProjectType(str, Enum):
    """Supported ML project types."""

    TABULAR = "tabular"
    DEEP_LEARNING = "deep_learning"
    NLP = "nlp"
    COMPUTER_VISION = "computer_vision"
    LLM_APP = "llm_app"


class Framework(str, Enum):
    """Supported ML frameworks."""

    PYTORCH = "pytorch"
    TENSORFLOW = "tensorflow"
    SKLEARN = "sklearn"


# Human-readable labels for prompts
PROJECT_TYPE_LABELS: dict[str, ProjectType] = {
    "📊  Tabular ML": ProjectType.TABULAR,
    "🧠  Deep Learning": ProjectType.DEEP_LEARNING,
    "💬  NLP (Natural Language Processing)": ProjectType.NLP,
    "👁️   Computer Vision": ProjectType.COMPUTER_VISION,
    "🤖  LLM App (RAG / Agents)": ProjectType.LLM_APP,
}

FRAMEWORK_LABELS: dict[str, Framework] = {
    "🔥  PyTorch": Framework.PYTORCH,
    "🌊  TensorFlow / Keras": Framework.TENSORFLOW,
    "⚙️   Scikit-learn": Framework.SKLEARN,
}

# Recommended framework per project type (used for display hint only)
RECOMMENDED_FRAMEWORKS: dict[ProjectType, Framework] = {
    ProjectType.TABULAR: Framework.SKLEARN,
    ProjectType.DEEP_LEARNING: Framework.PYTORCH,
    ProjectType.NLP: Framework.PYTORCH,
    ProjectType.COMPUTER_VISION: Framework.PYTORCH,
    ProjectType.LLM_APP: Framework.PYTORCH,
}

# All optional feature labels
FEATURE_QUESTIONS: list[tuple[str, str]] = [
    ("include_fastapi", "⚡  Include FastAPI serving endpoint?"),
    ("include_docker", "🐋  Include Docker + docker-compose?"),
    ("include_mlflow", "📈  Include MLflow experiment tracking?"),
    ("include_dvc", "🗄️   Include DVC data versioning?"),
    ("include_hydra", "🔧  Include Hydra config management?"),
]
