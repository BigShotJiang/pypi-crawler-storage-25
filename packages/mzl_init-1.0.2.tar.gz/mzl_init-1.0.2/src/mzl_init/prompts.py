"""Interactive prompt layer — gathers all user choices via questionary."""

import sys
import questionary
from questionary import Style
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from .config import ProjectConfig
from .constants import (
    FEATURE_QUESTIONS,
    FRAMEWORK_LABELS,
    PROJECT_TYPE_LABELS,
    RECOMMENDED_FRAMEWORKS,
    Framework,
    ProjectType,
)

console = Console()

# Custom questionary style that matches Rich's dark aesthetic
ML_STYLE = Style(
    [
        ("qmark", "fg:#7c3aed bold"),
        ("question", "bold"),
        ("answer", "fg:#10b981 bold"),
        ("pointer", "fg:#7c3aed bold"),
        ("highlighted", "fg:#7c3aed bold"),
        ("selected", "fg:#10b981"),
        ("separator", "fg:#555555"),
        ("instruction", "fg:#888888"),
    ]
)


def _safe_ask(question_func, *args, **kwargs):
    """Wrap questionary calls to handle Ctrl+C / None gracefully.

    Args:
        question_func: The questionary function to call.
        *args: Positional arguments.
        **kwargs: Keyword arguments.

    Returns:
        The user's answer.

    Raises:
        SystemExit: If the user cancels with Ctrl+C.
    """
    try:
        result = question_func(*args, **kwargs).ask()
        if result is None:
            console.print("\n[yellow]⚠  Aborted by user.[/yellow]")
            sys.exit(0)
        return result
    except KeyboardInterrupt:
        console.print("\n[yellow]⚠  Aborted by user.[/yellow]")
        sys.exit(0)


def _print_welcome(project_name: str) -> None:
    """Print a welcome banner with the project name."""
    title = Text()
    title.append("🚀  mzl-init", style="bold magenta")
    title.append(f"  ›  Creating ", style="dim white")
    title.append(project_name, style="bold cyan")

    console.print()
    console.print(
        Panel(
            title,
            subtitle="[dim]Answer a few questions to scaffold your AI/ML project[/dim]",
            border_style="bright_magenta",
            padding=(0, 2),
        )
    )
    console.print()


def gather_project_config(project_name: str) -> ProjectConfig:
    """Run the interactive prompt sequence and return a ProjectConfig.

    Args:
        project_name: The project name provided as CLI argument.

    Returns:
        A fully populated ProjectConfig instance.
    """
    _print_welcome(project_name)

    # ── Project type ────────────────────────────────────────────────────────
    project_type_label = _safe_ask(
        questionary.select,
        "What type of ML project?",
        choices=list(PROJECT_TYPE_LABELS.keys()),
        style=ML_STYLE,
        use_indicator=True,
    )
    project_type = PROJECT_TYPE_LABELS[project_type_label]

    # ── Framework ────────────────────────────────────────────────────────────
    recommended = RECOMMENDED_FRAMEWORKS[project_type]
    # Put recommended framework at top of list
    ordered_frameworks = sorted(
        FRAMEWORK_LABELS.keys(),
        key=lambda label: (0 if FRAMEWORK_LABELS[label] == recommended else 1),
    )

    framework_label = _safe_ask(
        questionary.select,
        "Which ML framework?",
        choices=ordered_frameworks,
        style=ML_STYLE,
        use_indicator=True,
    )
    framework = FRAMEWORK_LABELS[framework_label]

    console.print()
    console.print("[dim]  Optional features:[/dim]")

    # ── Optional features ─────────────────────────────────────────────────────
    feature_values: dict[str, bool] = {}
    for key, question in FEATURE_QUESTIONS:
        answer = _safe_ask(
            questionary.confirm,
            question,
            default=False,
            style=ML_STYLE,
        )
        feature_values[key] = answer

    return ProjectConfig(
        project_name=project_name,
        project_type=project_type,
        framework=framework,
        **feature_values,
    )
