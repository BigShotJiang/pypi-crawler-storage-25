"""Typer CLI entry-point for mzl-init."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import sys
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from . import __version__
from .config import ProjectConfig
from .doctor import run_doctor
from .generator import ProjectGenerator
from .prompts import gather_project_config

console = Console()

app = typer.Typer(
    name="mzl-init",
    help="🚀 Scaffold production-ready AI/ML projects interactively.",
    add_completion=False,
    rich_markup_mode="rich",
    no_args_is_help=True,
)


def _version_callback(value: bool) -> None:
    if value:
        console.print(
            f"[bold magenta]mzl-init[/bold magenta] version [bold cyan]{__version__}[/bold cyan]"
        )
        raise typer.Exit()


@app.callback(invoke_without_command=True)
def main(
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-v",
        help="Show version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
) -> None:
    """mzl-init — AI/ML Project Scaffolding CLI.

    Run [bold cyan]mzl-init <project_name>[/bold cyan] to create a new project,
    or [bold cyan]mzl-init doctor[/bold cyan] to check your environment.
    """


@app.command()
def init(
    project_name: str = typer.Argument(
        ...,
        help="Name of the project to create (used as the folder name).",
        metavar="PROJECT_NAME",
    ),
    output_dir: Path = typer.Option(
        Path("."),
        "--output-dir",
        "-o",
        help="Parent directory where the project folder will be created.",
        show_default=True,
    ),
    # Non-interactive flags (for CI/CD usage)
    project_type: Optional[str] = typer.Option(
        None, "--type", "-t",
        help="Project type: tabular | deep_learning | nlp | computer_vision | llm_app",
    ),
    framework: Optional[str] = typer.Option(
        None, "--framework", "-f",
        help="Framework: pytorch | tensorflow | sklearn",
    ),
    fastapi: bool = typer.Option(False, "--fastapi/--no-fastapi", help="Include FastAPI."),
    docker: bool = typer.Option(False, "--docker/--no-docker", help="Include Docker."),
    mlflow: bool = typer.Option(False, "--mlflow/--no-mlflow", help="Include MLflow."),
    dvc: bool = typer.Option(False, "--dvc/--no-dvc", help="Include DVC."),
    hydra: bool = typer.Option(False, "--hydra/--no-hydra", help="Include Hydra."),
) -> None:
    """Create a new AI/ML project scaffold interactively.

    When run without flags, launches an interactive prompt session.
    All options can also be passed as flags for non-interactive (CI) usage.

    Examples:

        [bold cyan]mzl-init my_project[/bold cyan]

        [bold cyan]mzl-init my_project --type tabular --framework sklearn --docker[/bold cyan]
    """
    # Validate project name
    if not project_name.replace("_", "").replace("-", "").isalnum():
        console.print(
            "[red]✗  Project name must contain only letters, numbers, hyphens, or underscores.[/red]"
        )
        raise typer.Exit(code=1)

    # Determine whether we are in non-interactive mode
    non_interactive = project_type is not None or framework is not None

    if non_interactive:
        config = _build_config_from_flags(
            project_name, project_type, framework,
            fastapi, docker, mlflow, dvc, hydra,
        )
    else:
        config = gather_project_config(project_name)

    # Generate project
    generator = ProjectGenerator()
    try:
        project_root = generator.generate(config, output_dir.resolve())
    except FileExistsError as exc:
        console.print(f"[red]✗  {exc}[/red]")
        raise typer.Exit(code=1) from exc

    # Success panel
    _print_success(project_root, config)
    generator.print_tree(project_root)
    _print_next_steps(config.project_name)


@app.command()
def doctor() -> None:
    """Check your environment for ML development readiness."""
    run_doctor()


# ── Helpers ────────────────────────────────────────────────────────────────────


def _build_config_from_flags(
    project_name: str,
    project_type_str: Optional[str],
    framework_str: Optional[str],
    include_fastapi: bool,
    include_docker: bool,
    include_mlflow: bool,
    include_dvc: bool,
    include_hydra: bool,
) -> ProjectConfig:
    """Build a ProjectConfig from CLI flags (non-interactive mode)."""
    from .constants import Framework, ProjectType, RECOMMENDED_FRAMEWORKS

    try:
        pt = ProjectType(project_type_str) if project_type_str else ProjectType.TABULAR
    except ValueError:
        valid = [e.value for e in ProjectType]
        console.print(f"[red]✗  Invalid project type '{project_type_str}'. Valid: {valid}[/red]")
        raise typer.Exit(code=1)

    if framework_str:
        try:
            fw = Framework(framework_str)
        except ValueError:
            valid = [e.value for e in Framework]
            console.print(f"[red]✗  Invalid framework '{framework_str}'. Valid: {valid}[/red]")
            raise typer.Exit(code=1)
    else:
        fw = RECOMMENDED_FRAMEWORKS[pt]

    return ProjectConfig(
        project_name=project_name,
        project_type=pt,
        framework=fw,
        include_fastapi=include_fastapi,
        include_docker=include_docker,
        include_mlflow=include_mlflow,
        include_dvc=include_dvc,
        include_hydra=include_hydra,
    )


def _print_success(project_root: Path, config: ProjectConfig) -> None:
    """Print the success banner after project generation."""
    lines = [
        f"[bold green]✅  Project created:[/bold green] [cyan]{project_root}[/cyan]",
        f"[dim]Type:[/dim]      {config.project_type.value}",
        f"[dim]Framework:[/dim] {config.framework.value}",
    ]
    features = [
        k for k, v in {
            "FastAPI": config.include_fastapi,
            "Docker": config.include_docker,
            "MLflow": config.include_mlflow,
            "DVC": config.include_dvc,
            "Hydra": config.include_hydra,
        }.items() if v
    ]
    if features:
        lines.append(f"[dim]Features:[/dim]  {', '.join(features)}")

    console.print()
    console.print(
        Panel(
            "\n".join(lines),
            title="[bold magenta]🎉 Project Ready[/bold magenta]",
            border_style="green",
            padding=(1, 2),
        )
    )


def _print_next_steps(project_name: str) -> None:
    """Print the next-steps instructions."""
    steps = (
        f"[bold]1.[/bold]  [cyan]cd {project_name}[/cyan]\n"
        "[bold]2.[/bold]  [cyan]python -m venv venv[/cyan]\n"
        "[bold]3.[/bold]  [cyan]source venv/bin/activate[/cyan]  [dim]# Windows: venv\\Scripts\\activate[/dim]\n"
        "[bold]4.[/bold]  [cyan]pip install -r requirements.txt[/cyan]\n"
        "[bold]5.[/bold]  [cyan]python main.py[/cyan]"
    )
    console.print(
        Panel(
            steps,
            title="[bold magenta]🚀 Next Steps[/bold magenta]",
            border_style="bright_magenta",
            padding=(1, 2),
        )
    )
    console.print()


def run() -> None:
    """CLI entrypoint router. Redirects implicit 'init' calls."""
    if len(sys.argv) >= 2:
        cmd = sys.argv[1]
        # If the argument doesn't start with '-' and isn't a known registered command,
        # we assume the user wanted to run 'init <project_name>'.
        if not cmd.startswith("-") and cmd not in ["init", "doctor"]:
            sys.argv.insert(1, "init")
            
    app()

