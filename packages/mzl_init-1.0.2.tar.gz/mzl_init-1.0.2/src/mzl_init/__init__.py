"""mzl-init — AI/ML Project Scaffolding CLI."""

__version__ = "1.0.0"
__author__ = "mzl-init contributors"
