"""Project generator — orchestrates directory creation and template rendering."""

from __future__ import annotations

from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn
from rich.tree import Tree

from .config import ProjectConfig
from .constants import Framework
from .renderer import TemplateRenderer

console = Console()


class ProjectGenerator:
    """Generates a full AI/ML project structure from a ProjectConfig.

    Args:
        renderer: Template renderer instance. A new one is created by default.
    """

    def __init__(self, renderer: TemplateRenderer | None = None) -> None:
        self._renderer = renderer or TemplateRenderer()

    # ── Public API ─────────────────────────────────────────────────────────────

    def generate(self, config: ProjectConfig, output_dir: Path) -> Path:
        """Generate the project at *output_dir / config.project_name*.

        Args:
            config: Fully populated project configuration.
            output_dir: Parent directory where the project folder is created.

        Returns:
            The absolute path of the generated project root.

        Raises:
            FileExistsError: If the project directory already exists.
        """
        project_root = output_dir / config.project_name
        if project_root.exists():
            raise FileExistsError(
                f"Directory '{project_root}' already exists. "
                "Choose a different project name or remove the existing directory."
            )

        ctx = config.as_template_context()

        with Progress(
            SpinnerColumn(spinner_name="dots", style="magenta"),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=30, style="magenta", complete_style="green"),
            TextColumn("[green]{task.completed}/{task.total}"),
            console=console,
            transient=True,
        ) as progress:
            steps = self._collect_steps(config)
            task = progress.add_task("Scaffolding project…", total=len(steps))

            for description, fn in steps:
                progress.update(task, description=description)
                fn(project_root, ctx)
                progress.advance(task)

        return project_root

    # ── Step collector ─────────────────────────────────────────────────────────

    def _collect_steps(
        self, config: ProjectConfig
    ) -> list[tuple[str, callable]]:
        """Build an ordered list of (label, callable) generation steps."""
        steps: list[tuple[str, callable]] = [
            ("Creating directory structure…", self._create_directories),
            ("Writing base files…", self._render_base_templates),
            ("Writing source modules…", self._render_source_templates),
            (f"Writing {config.framework.value} model…", self._render_framework_templates),
        ]

        if config.include_fastapi:
            steps.append(("Adding FastAPI endpoint…", self._render_fastapi))
        if config.include_docker:
            steps.append(("Adding Docker files…", self._render_docker))
        if config.include_mlflow:
            steps.append(("Adding MLflow tracking…", self._render_mlflow))
        if config.include_dvc:
            steps.append(("Adding DVC pipeline…", self._render_dvc))
        if config.include_hydra:
            steps.append(("Adding Hydra configs…", self._render_hydra))

        return steps

    # ── Directory structure ────────────────────────────────────────────────────

    def _create_directories(self, root: Path, ctx: dict) -> None:
        """Create the full project directory tree."""
        dirs = [
            "configs",
            "data/raw",
            "data/processed",
            "data/external",
            "docs",
            "models",
            "notebooks",
            "reports/figures",
            "scripts",
            "src/data",
            "src/features",
            "src/models",
            "src/training",
            "src/evaluation",
            "src/inference",
            "src/utils",
            "tests",
            "deployment/api",
            "deployment/docker",
            "deployment/cloud",
        ]
        for d in dirs:
            (root / d).mkdir(parents=True, exist_ok=True)
            # Add .gitkeep so empty dirs are tracked by git
            gitkeep = root / d / ".gitkeep"
            if not any((root / d).iterdir()):
                gitkeep.touch()

    # ── Base templates ─────────────────────────────────────────────────────────

    def _render_base_templates(self, root: Path, ctx: dict) -> None:
        """Render the always-included root-level files."""
        mappings = [
            ("base/README.md.j2", "README.md"),
            ("base/requirements.txt.j2", "requirements.txt"),
            ("base/pyproject.toml.j2", "pyproject.toml"),
            ("base/.gitignore.j2", ".gitignore"),
            ("base/.env.j2", ".env"),
            ("base/config.yaml.j2", "configs/config.yaml"),
            ("base/main.py.j2", "main.py"),
        ]
        for tpl, out in mappings:
            self._renderer.render_to_file(tpl, root / out, ctx)

    # ── Source module templates ────────────────────────────────────────────────

    def _render_source_templates(self, root: Path, ctx: dict) -> None:
        """Render Python source modules inside src/."""
        src = root / "src"
        mappings = [
            ("base/src/__init__.py.j2", src / "__init__.py"),
            ("base/src/utils/__init__.py.j2", src / "utils" / "__init__.py"),
            ("base/src/utils/logger.py.j2", src / "utils" / "logger.py"),
            ("base/src/data/__init__.py.j2", src / "data" / "__init__.py"),
            ("base/src/data/loader.py.j2", src / "data" / "loader.py"),
            ("base/src/features/__init__.py.j2", src / "features" / "__init__.py"),
            ("base/src/features/build_features.py.j2", src / "features" / "build_features.py"),
            ("base/src/models/__init__.py.j2", src / "models" / "__init__.py"),
            ("base/src/training/__init__.py.j2", src / "training" / "__init__.py"),
            ("base/src/training/train.py.j2", src / "training" / "train.py"),
            ("base/src/evaluation/__init__.py.j2", src / "evaluation" / "__init__.py"),
            ("base/src/evaluation/evaluate.py.j2", src / "evaluation" / "evaluate.py"),
            ("base/src/inference/__init__.py.j2", src / "inference" / "__init__.py"),
            ("base/src/inference/predict.py.j2", src / "inference" / "predict.py"),
        ]
        for tpl, out in mappings:
            self._renderer.render_to_file(tpl, out, ctx)

    # ── Framework-specific templates ───────────────────────────────────────────

    def _render_framework_templates(self, root: Path, ctx: dict) -> None:
        """Render the framework-specific model file."""
        framework = ctx["framework"]
        tpl = f"framework/{framework}/model.py.j2"
        out = root / "src" / "models" / "model.py"
        self._renderer.render_to_file(tpl, out, ctx)

    # ── Optional feature templates ─────────────────────────────────────────────

    def _render_fastapi(self, root: Path, ctx: dict) -> None:
        self._renderer.render_to_file(
            "features/fastapi/app.py.j2",
            root / "deployment" / "api" / "app.py",
            ctx,
        )

    def _render_docker(self, root: Path, ctx: dict) -> None:
        self._renderer.render_to_file(
            "features/docker/Dockerfile.j2",
            root / "deployment" / "docker" / "Dockerfile",
            ctx,
        )
        self._renderer.render_to_file(
            "features/docker/docker-compose.yml.j2",
            root / "docker-compose.yml",
            ctx,
        )

    def _render_mlflow(self, root: Path, ctx: dict) -> None:
        self._renderer.render_to_file(
            "features/mlflow/mlflow_tracking.py.j2",
            root / "src" / "training" / "mlflow_tracking.py",
            ctx,
        )

    def _render_dvc(self, root: Path, ctx: dict) -> None:
        self._renderer.render_to_file(
            "features/dvc/dvc.yaml.j2",
            root / "dvc.yaml",
            ctx,
        )
        self._renderer.render_to_file(
            "features/dvc/.dvcignore.j2",
            root / ".dvcignore",
            ctx,
        )

    def _render_hydra(self, root: Path, ctx: dict) -> None:
        self._renderer.render_to_file(
            "features/hydra/config.yaml.j2",
            root / "configs" / "hydra_config.yaml",
            ctx,
        )

    # ── Tree printer ───────────────────────────────────────────────────────────

    @staticmethod
    def print_tree(project_root: Path) -> None:
        """Print a Rich directory tree of the generated project."""
        tree = Tree(
            f"[bold magenta]{project_root.name}/[/bold magenta]",
            guide_style="bright_black",
        )
        _build_tree(tree, project_root)
        console.print(tree)


def _build_tree(tree: Tree, path: Path, depth: int = 0) -> None:
    """Recursively add nodes to a Rich Tree, skipping hidden dirs."""
    if depth > 4:
        return
    for child in sorted(path.iterdir()):
        if child.name == ".gitkeep":
            continue
        if child.is_dir():
            branch = tree.add(f"[bold blue]{child.name}/[/bold blue]")
            _build_tree(branch, child, depth + 1)
        else:
            # Colour-code by extension
            if child.suffix == ".py":
                icon, style = "🐍", "yellow"
            elif child.suffix in (".yaml", ".yml", ".toml", ".cfg"):
                icon, style = "⚙️ ", "cyan"
            elif child.suffix == ".md":
                icon, style = "📄", "white"
            elif child.name == "Dockerfile":
                icon, style = "🐋", "bright_blue"
            elif child.name == ".env":
                icon, style = "🔑", "red"
            elif child.suffix == ".txt":
                icon, style = "📋", "dim white"
            else:
                icon, style = "  ", "white"
            tree.add(f"{icon} [{style}]{child.name}[/{style}]")
