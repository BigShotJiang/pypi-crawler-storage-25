"""ProjectConfig dataclass — holds all user-selected choices."""

from dataclasses import dataclass, field
from .constants import Framework, ProjectType


@dataclass
class ProjectConfig:
    """Immutable configuration object built from interactive prompts.

    Attributes:
        project_name: Filesystem-safe name for the generated project directory.
        project_type: Selected ML project category.
        framework: Selected ML framework.
        include_fastapi: Whether to scaffold a FastAPI serving layer.
        include_docker: Whether to include Dockerfile and docker-compose.
        include_mlflow: Whether to include MLflow tracking setup.
        include_dvc: Whether to include DVC pipeline config.
        include_hydra: Whether to include Hydra configuration management.
    """

    project_name: str
    project_type: ProjectType
    framework: Framework
    include_fastapi: bool = field(default=False)
    include_docker: bool = field(default=False)
    include_mlflow: bool = field(default=False)
    include_dvc: bool = field(default=False)
    include_hydra: bool = field(default=False)

    def as_template_context(self) -> dict:
        """Return a flat dict suitable for Jinja2 template rendering.

        Returns:
            Dictionary with all config values plus convenience booleans.
        """
        return {
            "project_name": self.project_name,
            "project_type": self.project_type.value,
            "framework": self.framework.value,
            "include_fastapi": self.include_fastapi,
            "include_docker": self.include_docker,
            "include_mlflow": self.include_mlflow,
            "include_dvc": self.include_dvc,
            "include_hydra": self.include_hydra,
            # Convenience booleans for templates
            "is_pytorch": self.framework == Framework.PYTORCH,
            "is_tensorflow": self.framework == Framework.TENSORFLOW,
            "is_sklearn": self.framework == Framework.SKLEARN,
            "is_deep_learning": self.project_type in (
                ProjectType.DEEP_LEARNING,
                ProjectType.NLP,
                ProjectType.COMPUTER_VISION,
            ),
            "is_llm_app": self.project_type == ProjectType.LLM_APP,
            "is_nlp": self.project_type == ProjectType.NLP,
            "is_cv": self.project_type == ProjectType.COMPUTER_VISION,
        }
