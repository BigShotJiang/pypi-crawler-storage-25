"""Doctor command — checks the user's environment for ML development readiness."""

from __future__ import annotations

import shutil
import subprocess
import sys

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

console = Console()


def _check(label: str, status: bool, detail: str = "") -> tuple[str, str, str]:
    """Format a single check result as a table row tuple."""
    icon = "✅" if status else "❌"
    color = "green" if status else "red"
    return (icon, label, f"[{color}]{detail}[/{color}]")


def _run(cmd: list[str]) -> str | None:
    """Run a command and return stdout, or None on failure."""
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.stdout.strip() if result.returncode == 0 else None
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return None


def _check_python() -> tuple[str, str, str]:
    ver = sys.version.split()[0]
    major, minor = sys.version_info.major, sys.version_info.minor
    ok = (major, minor) >= (3, 9)
    detail = f"Python {ver}" if ok else f"Python {ver} — requires 3.9+"
    return _check("Python", ok, detail)


def _check_pip() -> tuple[str, str, str]:
    out = _run([sys.executable, "-m", "pip", "--version"])
    ok = out is not None
    detail = out.split()[0:2] if ok else "pip not found"
    return _check("pip", ok, " ".join(detail) if isinstance(detail, list) else detail)


def _check_git() -> tuple[str, str, str]:
    out = _run(["git", "--version"])
    ok = out is not None
    detail = out if ok else "git not found — install from https://git-scm.com"
    return _check("git", ok, detail)


def _check_torch() -> tuple[str, str, str]:
    try:
        import torch  # type: ignore

        cuda = torch.cuda.is_available()
        detail = f"PyTorch {torch.__version__} — CUDA {'✓' if cuda else '✗'}"
        return _check("PyTorch", True, detail)
    except ImportError:
        return _check("PyTorch", False, "not installed (pip install torch)")


def _check_tensorflow() -> tuple[str, str, str]:
    try:
        import tensorflow as tf  # type: ignore

        detail = f"TensorFlow {tf.__version__}"
        return _check("TensorFlow", True, detail)
    except ImportError:
        return _check("TensorFlow", False, "not installed (pip install tensorflow)")


def _check_sklearn() -> tuple[str, str, str]:
    try:
        import sklearn  # type: ignore

        detail = f"scikit-learn {sklearn.__version__}"
        return _check("scikit-learn", True, detail)
    except ImportError:
        return _check("scikit-learn", False, "not installed (pip install scikit-learn)")


def _check_docker() -> tuple[str, str, str]:
    out = _run(["docker", "--version"])
    ok = out is not None
    detail = out if ok else "docker not found"
    return _check("Docker", ok, detail)


def _check_dvc() -> tuple[str, str, str]:
    out = _run(["dvc", "--version"])
    ok = out is not None
    detail = f"DVC {out}" if ok else "not installed (pip install dvc)"
    return _check("DVC", ok, detail)


def run_doctor() -> None:
    """Run all environment checks and display a Rich formatted report."""
    console.print()
    console.print(
        Panel(
            Text("🩺  mzl-init doctor", style="bold magenta", justify="center"),
            subtitle="[dim]Environment Health Check[/dim]",
            border_style="bright_magenta",
            padding=(0, 2),
        )
    )
    console.print()

    checks = [
        _check_python(),
        _check_pip(),
        _check_git(),
        _check_torch(),
        _check_tensorflow(),
        _check_sklearn(),
        _check_docker(),
        _check_dvc(),
    ]

    table = Table(
        show_header=True,
        header_style="bold magenta",
        border_style="bright_black",
        show_lines=True,
        expand=True,
    )
    table.add_column("", width=3, no_wrap=True)
    table.add_column("Dependency", style="bold white")
    table.add_column("Status / Version")

    for row in checks:
        table.add_row(*row)

    console.print(table)
    console.print()

    passed = sum(1 for r in checks if r[0] == "✅")
    total = len(checks)
    color = "green" if passed == total else ("yellow" if passed >= total // 2 else "red")
    console.print(
        f"[{color}]  {passed}/{total} checks passed.[/{color}]"
        "  Run [bold]pip install[/bold] for any missing packages.\n"
    )
