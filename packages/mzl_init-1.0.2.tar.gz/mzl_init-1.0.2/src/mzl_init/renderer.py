"""Jinja2 template renderer — loads bundled templates and renders to files."""

from __future__ import annotations

import importlib.resources as importlib_resources
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, StrictUndefined


class TemplateRenderer:
    """Renders Jinja2 templates bundled inside the mzl_init package.

    Templates are loaded from the ``mzl_init/templates/`` package directory,
    which is included in the wheel via the ``package-data`` directive in
    ``pyproject.toml``.

    Args:
        templates_dir: Override the default bundled templates directory.
            Useful for testing.
    """

    def __init__(self, templates_dir: Path | None = None) -> None:
        if templates_dir is None:
            # Resolve bundled templates directory via importlib.resources
            package_ref = importlib_resources.files("mzl_init")
            templates_dir = Path(str(package_ref)) / "templates"

        self._env = Environment(
            loader=FileSystemLoader(str(templates_dir)),
            undefined=StrictUndefined,
            keep_trailing_newline=True,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        self._templates_dir = templates_dir

    def render(self, template_path: str, context: dict) -> str:
        """Render a template and return the result as a string.

        Args:
            template_path: Relative path inside the templates directory,
                e.g. ``"base/README.md.j2"``.
            context: Template variables.

        Returns:
            Rendered string content.
        """
        template = self._env.get_template(template_path)
        return template.render(**context)

    def render_to_file(
        self,
        template_path: str,
        output_path: Path,
        context: dict,
    ) -> None:
        """Render a template and write it to *output_path*.

        Parent directories are created automatically.

        Args:
            template_path: Relative path inside the templates directory.
            output_path: Absolute path of the file to create.
            context: Template variables.
        """
        content = self.render(template_path, context)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(content, encoding="utf-8")

    def template_exists(self, template_path: str) -> bool:
        """Return True if the given template file exists.

        Args:
            template_path: Relative path inside the templates directory.
        """
        return (self._templates_dir / template_path).exists()
