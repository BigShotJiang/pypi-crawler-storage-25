"""GANN MCP tool definitions."""
