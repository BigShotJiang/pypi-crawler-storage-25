"""SorcGCS Local Server — game preview, file management, and AI agent support."""

__version__ = "0.6.0"
