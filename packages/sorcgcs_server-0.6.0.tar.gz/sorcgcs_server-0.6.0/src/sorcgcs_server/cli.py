"""CLI entry point for sorcgcs-server."""

import argparse
import builtins
import os
import signal
import sys
import threading

_builtin_print = builtins.print
def print(*args, **kwargs):
    kwargs.setdefault("flush", True)
    _builtin_print(*args, **kwargs)

from . import __version__

CK_PORT = 8100
RESOLUTION_OPTIONS = {
    "1": 512,
    "2": 1024,
    "3": 1536,
    "4": 2048,
}


def _resolution_hotkey_listener():
    """Background thread: listens for single-key presses to change CK resolution."""
    import urllib.request
    import json
    try:
        if sys.platform == "win32":
            import msvcrt
            def get_key():
                if msvcrt.kbhit():
                    return msvcrt.getch().decode("utf-8", errors="ignore")
                return None
        else:
            import select, tty, termios
            old_settings = termios.tcgetattr(sys.stdin)
            tty.setcbreak(sys.stdin.fileno())
            def get_key():
                if select.select([sys.stdin], [], [], 0.1)[0]:
                    return sys.stdin.read(1)
                return None

        while True:
            try:
                key = get_key()
            except Exception:
                break
            if key is None:
                import time; time.sleep(0.15)
                continue
            if key in RESOLUTION_OPTIONS:
                new_size = RESOLUTION_OPTIONS[key]
                print(f"\n  Changing CorridorKey resolution to {new_size}px...")
                try:
                    data = json.dumps({"img_size": new_size}).encode("utf-8")
                    req = urllib.request.Request(
                        f"http://127.0.0.1:{CK_PORT}/set-resolution",
                        data=data,
                        headers={"Content-Type": "application/json"},
                        method="POST",
                    )
                    resp = urllib.request.urlopen(req, timeout=120)
                    result = json.loads(resp.read())
                    if result.get("message"):
                        print(f"  Already at {new_size}px")
                    else:
                        prev = result.get("previous", "?")
                        print(f"  Resolution changed: {prev}px -> {new_size}px")
                    _print_resolution_bar(new_size)
                except Exception as e:
                    print(f"  Failed to change resolution: {e}")
    except Exception:
        pass


def _print_resolution_bar(current_size=None):
    """Print the resolution hotkey bar."""
    parts = []
    for key, size in RESOLUTION_OPTIONS.items():
        if size == current_size:
            parts.append(f"[{key}] {size}px *")
        else:
            parts.append(f"[{key}] {size}px")
    print(f"  Resolution: {' | '.join(parts)}")
    print("")


def main():
    os.environ["PYTHONUNBUFFERED"] = "1"
    sys.stdout.reconfigure(line_buffering=True) if hasattr(sys.stdout, 'reconfigure') else None
    parser = argparse.ArgumentParser(
        prog="sorcgcs-server",
        description="SorcGCS Local Server — game preview, file management, AI agent support, and CorridorKey GPU server",
    )
    parser.add_argument("--port", type=int, default=8080, help="Port (default: 8080)")
    parser.add_argument("--host", type=str, default="0.0.0.0", help="Host (default: 0.0.0.0)")
    parser.add_argument("--dir", type=str, default=None, help="Games directory (default: cwd)")
    parser.add_argument("--no-corridorkey", action="store_true", help="Skip CorridorKey GPU server")
    parser.add_argument("--version", action="version", version=f"sorcgcs-server {__version__}")
    args = parser.parse_args()

    print("")
    print("  ================================================")
    print(f"   SORCGCS SERVER v{__version__}")
    print("  ================================================")

    ck_proc = None
    ck_info = {"status": "skipped", "gpu": None, "error": None}

    if not args.no_corridorkey:
        from .corridorkey import launch_corridorkey
        ck_info = launch_corridorkey()
        ck_proc = ck_info.get("proc")
    else:
        print("  CorridorKey: skipped (--no-corridorkey)")

    _print_dashboard(args, ck_info)

    ck_running = ck_info.get("status") == "running"
    if ck_running:
        from .corridorkey import CK_IMG_SIZE
        _print_resolution_bar(CK_IMG_SIZE)
        t = threading.Thread(target=_resolution_hotkey_listener, daemon=True)
        t.start()

    def cleanup(*_):
        print("")
        if ck_proc and ck_proc.poll() is None:
            print("  Stopping CorridorKey server...")
            ck_proc.terminate()
            try:
                ck_proc.wait(timeout=5)
            except Exception:
                ck_proc.kill()
        print("  All servers stopped.")
        sys.exit(0)

    signal.signal(signal.SIGINT, cleanup)
    signal.signal(signal.SIGTERM, cleanup)

    from .server import run_server

    try:
        run_server(port=args.port, host=args.host, games_dir=args.dir)
    except KeyboardInterrupt:
        cleanup()


def _print_dashboard(args, ck_info):
    import os
    games_dir = os.path.abspath(args.dir) if args.dir else os.getcwd()

    print("")
    print("  ------------------------------------------------")
    print("   STATUS")
    print("  ------------------------------------------------")
    print(f"   File Server:   http://localhost:{args.port}  [OK]")

    ck_status = ck_info.get("status", "skipped")
    if ck_status == "running":
        gpu = ck_info.get("gpu", "unknown")
        print(f"   CorridorKey:   http://localhost:8100  [OK]  GPU: {gpu}")
    elif ck_status == "skipped":
        print("   CorridorKey:   skipped")
    elif ck_status == "setup_failed":
        print("   CorridorKey:   [FAILED] setup error")
        err = ck_info.get("error", "")
        if err:
            for line in err.split("\n")[:3]:
                print(f"                  {line}")
    elif ck_status == "crashed":
        print("   CorridorKey:   [FAILED] process crashed")
        err = ck_info.get("error", "")
        if err:
            for line in err.split("\n")[:5]:
                print(f"                  {line}")
    elif ck_status == "timeout":
        print("   CorridorKey:   [WARNING] started but not healthy")
        err = ck_info.get("error", "")
        if err:
            print(f"                  {err}")
    else:
        print(f"   CorridorKey:   [{ck_status}]")

    print("  ------------------------------------------------")
    print(f"   Games folder:  {games_dir}")
    print("  ------------------------------------------------")
    print("")
    print("  Press Ctrl+C to stop all servers.")
    if ck_status == "running":
        print("  Press 1-4 to change CorridorKey resolution.")
    print("")


if __name__ == "__main__":
    main()
