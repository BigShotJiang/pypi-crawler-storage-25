"""OpenAI-compatible HTTP server for MCP Brain.

Serves POST /v1/chat/completions - proxies requests through the adaptive
cognitive pipeline and streams SSE responses back in OpenAI format.

Usage:
    mcp-brain-http                    # default 0.0.0.0:8080
    mcp-brain-http --port 9000       # custom port
    mcp-brain-http --help            # see all options
"""

import os
import sys
import json
import re
import time
import uuid
import asyncio
import argparse
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone

import fastapi
from fastapi import Request, Response
from fastapi.responses import StreamingResponse
import uvicorn

# Add src to path for editable installs
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from mcpbrain.mcp_core import MCP
from mcpbrain.tools import TOOL_REGISTRY
from mcpbrain.minimax_client import METRICS, MiniMaxClient, MiniMaxAPIError, MiniMaxRateLimitError
from mcpbrain.logging_config import new_correlation_id, configure_logging, log

# Configure structured logging at import time
configure_logging()

APP = fastapi.FastAPI(
    title="MCP Brain",
    description="OpenAI-compatible API for the adaptive multi-agent cognitive pipeline",
    version="0.8.5",
)

_START_TIME = time.monotonic()
_START_UTC = datetime.now(timezone.utc).isoformat()

# ── Shared MiniMaxClient (connection pool reuse) ─────────────────────────────
_shared_client: Optional[MiniMaxClient] = None
_shared_client_lock = asyncio.Lock()


async def get_shared_client(api_key: str) -> MiniMaxClient:
    """Get or create the shared MiniMax client for connection pooling."""
    global _shared_client
    async with _shared_client_lock:
        if _shared_client is None:
            _shared_client = MiniMaxClient(api_key=api_key)
        return _shared_client


# ── Correlation ID middleware ────────────────────────────────────────────────

@APP.middleware("http")
async def correlation_id_middleware(request: Request, call_next):
    """Extract or generate a correlation ID for request tracing."""
    cid = request.headers.get("x-correlation-id") or new_correlation_id()
    request.state.correlation_id = cid
    response = await call_next(request)
    response.headers["x-correlation-id"] = cid
    return response


# ── CORS ─────────────────────────────────────────────────────────────────────

@APP.options("/{full_path:path}")
async def cors_preflight(full_path: str):
    """Handle CORS preflight requests."""
    return Response(
        status_code=200,
        headers={
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
            "Access-Control-Allow-Headers": "Authorization, Content-Type, X-API-Key, X-Correlation-ID",
            "Access-Control-Max-Age": "86400",
        },
    )


# ── Helpers ──────────────────────────────────────────────────────────────────

def _resolve_model(model: str) -> str:
    """Map user-facing model names to MiniMax API model names."""
    if model in ("mcp-brain", "gpt-4o", "gpt-4-turbo", "gpt-3.5-turbo"):
        return "MiniMax-M2.7"
    return model


def _build_token_chunk(content: str) -> dict:
    """Build an OpenAI chat completion chunk for a text token."""
    return {
        "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
        "object": "chat.completion.chunk",
        "created": int(time.time()),
        "model": "mcp-brain",
        "choices": [{
            "index": 0,
            "delta": {"content": content},
            "finish_reason": None,
        }],
    }


def _build_done_chunk(usage: dict) -> dict:
    """Build the final [DONE] chunk with usage stats."""
    return {
        "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
        "object": "chat.completion.chunk",
        "created": int(time.time()),
        "model": "mcp-brain",
        "choices": [{
            "index": 0,
            "delta": {},
            "finish_reason": "stop",
        }],
        "usage": usage,
    }


# ── Think-tag / reasoning filter ─────────────────────────────────────────────
_THINK_OPEN = re.compile(r"<think>")
_THINK_CLOSE = re.compile(r"</think>")
_THINK_OPEN_ALT = re.compile(r"<thinking>")
_THINK_CLOSE_ALT = re.compile(r"</thinking>")

# MiniMax reasoning format — [COMPLEXITY: X], [REASON: ...], [TOOL_CALL], [OUTPUT], [NOTES], [NEXT_PLAN]
# The colon is optional — [TOOL_CALL] has no colon, while others do: [COMPLEXITY: X]
_MINIMAX_OPEN = re.compile(r"\[(COMPLEXITY|REASON|TOOL_CALL|OUTPUT|NOTES|NEXT_PLAN):?")
_MINIMAX_CLOSE = re.compile(r"\]")
_MINIMAX_SEP = re.compile(r"^\s*---\s*$", re.MULTILINE)  # Horizontal rule separators


def _make_think_filter():
    """Create a fresh state machine instance for filtering think/reasoning tags.

    Filters three formats:
    1. `` ... ``
    2. <thinking> ... </thinking>
    3. [COMPLEXITY: X] / [REASON: ...] / [TOOL_CALL] / [OUTPUT] / [NOTES] / [NEXT_PLAN] blocks
    4. --- separators between reasoning sections
    """
    in_think = False
    in_minimax = False

    def _process_token(content: str) -> Optional[str]:
        nonlocal in_think, in_minimax
        if not content:
            return None
        result_parts = []
        remaining = content

        while remaining:
            # Handle MiniMax [LABEL: ...] blocks
            if in_minimax:
                m = _MINIMAX_CLOSE.search(remaining)
                if m:
                    in_minimax = False
                    remaining = remaining[m.end():]
                else:
                    # No closing tag in this chunk — suppress output and
                    # preserve state so next chunk continues from here
                    return None
                continue

            if in_think:
                m = _THINK_CLOSE.search(remaining) or _THINK_CLOSE_ALT.search(remaining)
                if m:
                    in_think = False
                    remaining = remaining[m.end():]
                else:
                    # No closing tag in this chunk — suppress output and
                    # preserve state so next chunk continues from here
                    return None
                continue

            # Try standard think tags
            m = _THINK_OPEN.search(remaining) or _THINK_OPEN_ALT.search(remaining)
            if m:
                before = remaining[:m.start()]
                if before:
                    result_parts.append(before)
                in_think = True
                remaining = remaining[m.end():]
                continue

            # Try MiniMax reasoning tags
            m = _MINIMAX_OPEN.search(remaining)
            if m:
                before = remaining[:m.start()]
                if before:
                    result_parts.append(before)
                in_minimax = True
                remaining = remaining[m.end():]
                continue

            # Try --- separator (drop it)
            m = _MINIMAX_SEP.match(remaining)
            if m:
                remaining = remaining[m.end():]
                continue

            # No more tags — append rest and done
            result_parts.append(remaining)
            break

        out = "".join(result_parts)
        return out if out else None

    return _process_token


def _filter_think_tags(content: str) -> str:
    """Strip all think/reasoning tags from content.

    Processes the full string in one pass so state (in_think/in_minimax)
    persists across newlines — fixes multi-line `` blocks that would
    otherwise leak through with per-line processing.
    """
    if not content:
        return ""
    filter_fn = _make_think_filter()
    # Process whole content at once — state persists across newlines
    result = filter_fn(content)
    return (result or "").strip()


# ── Passthrough mode ─────────────────────────────────────────────────────────

async def _stream_passthrough(messages: List[dict], model: str, max_tokens: int, tools: Optional[List[dict]], api_key: str):
    """Forward messages + tools directly to MiniMax, bypassing the cognitive pipeline."""
    client = await get_shared_client(api_key)
    actual_model = _resolve_model(model)
    think_filter = _make_think_filter()

    try:
        async for event in client.generate_stream_from_messages(
            messages=messages,
            model=actual_model,
            max_tokens=max_tokens,
            tools=tools if tools else None,
        ):
            if isinstance(event, dict):
                if event.get("type") == "token":
                    filtered = think_filter(event.get("content", ""))
                    if filtered is not None:
                        chunk = _build_token_chunk(filtered)
                        yield f"data: {json.dumps(chunk)}\n\n"
                elif event.get("type") == "tool_call":
                    chunk = {
                        "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                        "object": "chat.completion.chunk",
                        "created": int(time.time()),
                        "model": model or "mcp-brain",
                        "choices": [{
                            "index": 0,
                            "delta": {
                                "content": None,
                                "tool_calls": [{
                                    "index": event.get("index", 0),
                                    "id": f"call_{uuid.uuid4().hex[:8]}",
                                    "type": "function",
                                    "function": {
                                        "name": event.get("name", ""),
                                        "arguments": event.get("arguments", ""),
                                    },
                                }],
                            },
                            "finish_reason": "tool_calls",
                        }],
                    }
                    yield f"data: {json.dumps(chunk)}\n\n"
                    yield "data: [DONE]\n\n"
                    return
            else:
                filtered = think_filter(event)
                if filtered is not None:
                    chunk = _build_token_chunk(filtered)
                    yield f"data: {json.dumps(chunk)}\n\n"
    except Exception as e:
        log.error("passthrough_stream_error", error=str(e))
        error_chunk = {
            "error": {
                "message": f"Stream interrupted: {str(e)}",
                "type": "internal_server_error",
                "code": "stream_error",
            }
        }
        yield f"data: {json.dumps(error_chunk)}\n\n"
        yield "data: [DONE]\n\n"
        return

    # Final done chunk
    done = _build_done_chunk({"prompt_tokens": -1, "completion_tokens": -1, "total_tokens": -1})
    yield f"data: {json.dumps(done)}\n\n"
    yield "data: [DONE]\n\n"


# ── Pipeline mode ─────────────────────────────────────────────────────────────

async def _stream_pipeline(mcp: MCP, task: str, model: Optional[str], functions: Optional[List[dict]]):
    """Drain the cognitive pipeline and yield OpenAI-compatible SSE tokens."""
    think_filter = _make_think_filter()

    try:
        async for event in mcp.process_task_stream_async(task, functions):
            etype = event.get("type")

            if etype == "function_call":
                chunk = {
                    "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                    "object": "chat.completion.chunk",
                    "created": int(time.time()),
                    "model": model or "mcp-brain",
                    "choices": [{
                        "index": 0,
                        "delta": {
                            "content": None,
                            "tool_calls": [{
                                "index": 0,
                                "id": f"call_{uuid.uuid4().hex[:8]}",
                                "type": "function",
                                "function": {
                                    "name": event["name"],
                                    "arguments": event["arguments"],
                                },
                            }],
                        },
                        "finish_reason": "tool_calls",
                    }],
                }
                yield f"data: {json.dumps(chunk)}\n\n"
                yield "data: [DONE]\n\n"
                return

            elif etype == "token":
                content = event.get("content", "")
                filtered = think_filter(content)
                if filtered is not None:
                    chunk = _build_token_chunk(filtered)
                    yield f"data: {json.dumps(chunk)}\n\n"

            elif etype == "done":
                usage = {"prompt_tokens": -1, "completion_tokens": -1, "total_tokens": -1}
                chunk = _build_done_chunk(usage)
                yield f"data: {json.dumps(chunk)}\n\n"
                yield "data: [DONE]\n\n"
    except Exception as e:
        log.error("stream_pipeline_error", error=str(e))
        error_chunk = {
            "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
            "object": "chat.completion.chunk",
            "created": int(time.time()),
            "model": model or "mcp-brain",
            "choices": [{
                "index": 0,
                "delta": {},
                "finish_reason": "error",
                "error": str(e),
            }],
        }
        yield f"data: {json.dumps(error_chunk)}\n\n"
        yield "data: [DONE]\n\n"


def _extract_user_message(messages: List[dict]) -> str:
    """Pull the last user message from the OpenAI messages array."""
    for msg in reversed(messages):
        if msg.get("role") == "user":
            return msg.get("content", "")
    return ""


# ── Main endpoint ─────────────────────────────────────────────────────────────

@APP.post("/v1/chat/completions")
async def chat_completions(request: Request):
    """OpenAI-compatible /v1/chat/completions endpoint."""
    body = await request.json()
    messages = body.get("messages", [])
    stream = body.get("stream", False)
    model = body.get("model", "mcp-brain")
    max_tokens = body.get("max_tokens", 4096)
    functions = body.get("functions") or body.get("tools")

    task = _extract_user_message(messages)
    if not task:
        return {"error": {"message": "No user message found", "type": "invalid_request_error"}}

    # Assign correlation ID for this request
    cid = new_correlation_id()
    log.info("chat_completions_request", model=model, stream=stream, has_tools=bool(functions), correlation_id=cid)

    try:
        mcp = MCP(skip_api_key_check=True)
        if not mcp.is_setup():
            return {"error": {"message": "MCP Brain not configured. Run: mcp setup", "type": "auth_error"}}
    except Exception as e:
        return {"error": {"message": f"MCP init failed: {e}", "type": "server_error"}}

    api_key = mcp.config.get("api_key") or os.environ.get("MINIMAX_API_KEY")

    # Route: tools present -> passthrough, no tools -> cognitive pipeline
    if functions:
        if stream:
            return StreamingResponse(
                _stream_passthrough(messages, model, max_tokens, functions, api_key),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no",
                },
            )
        else:
            # Non-streaming passthrough
            client = await get_shared_client(api_key)
            actual_model = _resolve_model(model)
            content_parts = []
            function_call = None
            async for event in client.generate_stream_from_messages(
                messages=messages,
                model=actual_model,
                max_tokens=max_tokens,
                tools=functions,
            ):
                if isinstance(event, dict):
                    if event["type"] == "token":
                        content_parts.append(event["content"])
                    elif event["type"] == "tool_call":
                        function_call = event
                else:
                    content_parts.append(event)

            if function_call:
                return {
                    "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                    "object": "chat.completion",
                    "created": int(time.time()),
                    "model": model,
                    "choices": [{
                        "index": 0,
                        "message": {
                            "role": "assistant",
                            "content": None,
                            "tool_calls": [{
                                "id": f"call_{uuid.uuid4().hex[:8]}",
                                "type": "function",
                                "function": {
                                    "name": function_call["name"],
                                    "arguments": function_call["arguments"],
                                },
                            }],
                        },
                        "finish_reason": "tool_calls",
                    }],
                    "usage": {"prompt_tokens": -1, "completion_tokens": -1, "total_tokens": -1},
                }

            full_content = "".join(content_parts)
            stripped = _filter_think_tags(full_content)

            return {
                "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                "object": "chat.completion",
                "created": int(time.time()),
                "model": model,
                "choices": [{
                    "index": 0,
                    "message": {"role": "assistant", "content": stripped},
                    "finish_reason": "stop",
                }],
                "usage": {"prompt_tokens": -1, "completion_tokens": -1, "total_tokens": -1},
            }

    # No tools -> cognitive pipeline
    if stream:
        return StreamingResponse(
            _stream_pipeline(mcp, task, model, functions),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )
    else:
        # Non-streaming pipeline
        function_call = None
        all_content = []
        done_result = None

        async for event in mcp.process_task_stream_async(task, functions):
            if event["type"] == "function_call":
                function_call = event
            elif event["type"] == "token":
                all_content.append(event.get("content", ""))
            elif event["type"] == "done":
                done_result = event

        if function_call:
            return {
                "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                "object": "chat.completion",
                "created": int(time.time()),
                "model": model,
                "choices": [{
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": None,
                        "tool_calls": [{
                            "id": f"call_{uuid.uuid4().hex[:8]}",
                            "type": "function",
                            "function": {
                                "name": function_call["name"],
                                "arguments": function_call["arguments"],
                            },
                        }],
                    },
                    "finish_reason": "tool_calls",
                }],
                "usage": {"prompt_tokens": -1, "completion_tokens": -1, "total_tokens": -1},
            }

        full_content = "".join(all_content)
        stripped = _filter_think_tags(full_content)

        return {
            "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": model,
            "choices": [{
                "index": 0,
                "message": {"role": "assistant", "content": stripped},
                "finish_reason": "stop",
            }],
            "usage": {"prompt_tokens": -1, "completion_tokens": -1, "total_tokens": -1},
        }


# ── Models endpoint ──────────────────────────────────────────────────────────

@APP.get("/v1/models")
async def list_models():
    """OpenAI-compatible models endpoint."""
    return {
        "object": "list",
        "data": [{
            "id": "mcp-brain",
            "object": "model",
            "created": 1700000000,
            "owned_by": "mcp-brain",
            "permission": [],
        }],
    }


# ── Health & metrics endpoints ───────────────────────────────────────────────

@APP.get("/health")
async def health():
    """Health check with detailed status."""
    uptime_s = round(time.monotonic() - _START_TIME, 1)
    api_key_configured = bool(os.environ.get("MINIMAX_API_KEY"))
    try:
        config_path = Path("~/.mcp/config.json").expanduser()
        if config_path.exists():
            config = json.loads(config_path.read_text())
            api_key_configured = api_key_configured or bool(config.get("api_key"))
    except Exception:
        pass

    return {
        "status": "ok",
        "version": "0.8.5",
        "uptime_seconds": uptime_s,
        "started_at": _START_UTC,
        "api_key_configured": api_key_configured,
    }


@APP.get("/ready")
async def readiness():
    """Readiness probe — checks if the service can handle requests."""
    api_key = os.environ.get("MINIMAX_API_KEY")
    try:
        config_path = Path("~/.mcp/config.json").expanduser()
        if config_path.exists():
            config = json.loads(config_path.read_text())
            api_key = api_key or config.get("api_key")
    except Exception:
        pass

    if not api_key:
        return {"status": "not_ready", "reason": "No API key configured"}

    return {"status": "ready"}


@APP.get("/metrics")
async def metrics():
    """Prometheus-compatible metrics (JSON format)."""
    m = METRICS.summary()
    uptime_s = round(time.monotonic() - _START_TIME, 1)
    return {
        "mcp_brain_version": "0.8.5",
        "uptime_seconds": uptime_s,
        "minimax_requests_total": m["requests"],
        "minimax_errors_total": m["errors"],
        "minimax_rate_limits_total": m["rate_limits"],
        "minimax_tokens_total": m["total_tokens"],
        "minimax_avg_latency_seconds": m["avg_latency_s"],
    }


@APP.get("/v1/tools")
async def list_tools():
    """Return the registry of locally-executable tools."""
    return {
        "object": "list",
        "data": TOOL_REGISTRY.list(),
    }


@APP.get("/sessions")
async def list_sessions():
    """List recent session logs (up to 20)."""
    log_dir = Path("~/.mcp/logs").expanduser()
    if not log_dir.exists():
        return {"sessions": []}
    files = sorted(log_dir.glob("session_*.json"), reverse=True)[:20]
    sessions = []
    for f in files:
        try:
            with open(f) as fh:
                data = json.load(fh)
            sessions.append({
                "session_id": data.get("session_id", f.stem),
                "timestamp": data.get("timestamp", ""),
                "task": data.get("task", "")[:100],
                "duration_s": data.get("result", {}).get("duration_seconds"),
                "complexity": data.get("result", {}).get("complexity"),
            })
        except Exception:
            pass
    return {"sessions": sessions}


# ── Startup / shutdown ───────────────────────────────────────────────────────

@APP.on_event("startup")
async def _startup():
    """Initialize structured logging on server start."""
    log.info("mcp_brain_http_start", version="0.8.5")


@APP.on_event("shutdown")
async def _shutdown():
    """Gracefully close the shared HTTP client on shutdown."""
    global _shared_client
    if _shared_client is not None:
        await _shared_client.aclose()
        _shared_client = None
        log.info("mcp_brain_http_shutdown", client_closed=True)


# ── Main entry point ─────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="MCP Brain HTTP Server (OpenAI-compatible)")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8080, help="Port to bind (default: 8080)")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload (dev mode)")
    args = parser.parse_args()

    log.info("mcp_brain_http_configured", host=args.host, port=args.port)

    uvicorn.run(
        "mcpbrain.http_server:APP",
        host=args.host,
        port=args.port,
        reload=args.reload,
        log_level="info",
    )


if __name__ == "__main__":
    main()
