![PyPI - Version](https://img.shields.io/pypi/v/pynjsla) ![Static Badge](https://img.shields.io/badge/python-3.10-blue) [![Run tests](https://github.com/Scipio94/pynjsla/actions/workflows/tests.yml/badge.svg)](https://github.com/Scipio94/pynjsla/actions/workflows/tests.yml)

# pynjsla

Python package that automates end-to-end district level New Jersey Student Learning Assessment (NJSLA) Individualized Score Reports (ISR) processing into student level files for SIS or database upload and distribution

## Free Version vs Enterprise Version

### Free Version (PyPi)
- Limited single NJSLA ISR splitting, up to 25 students.

### Enterprise Version
- Unlimited single NJSLA ISR splitting.
- Unlimited batch NJSLA ISR splitting.
- Directory and subfolder creation.
- Zip Archive creation

📩 Contact: info@gw-datasolutiions.com

## njsla_split

### Installation

```python
pip install pynjsla
```

#### Usage

```python
import pynjsla
from pynjsla.njsla import njsla_split

njsla_split('C:\Documents\Reports\NJSLA_ISR.pdf')
```

The output will be _x_ number of exported PDFs with the output label being the ID from the NJSLA ISRs.

#### Documentation

| Input      | Data Type | Documentation                  |
| ---------- | --------- | ------------------------------ |
| pdf_object | string    | The file path of the NJSLA ISR |
