import unittest
from unittest.mock import Mock, patch
from urllib.parse import parse_qs, urlparse
from pathlib import Path
import re
import os
from xml.etree import ElementTree as ET

from ezpanos.ezpanos import EzPanOS, build_xml_from_command

_PLACEHOLDER_RE = re.compile(r"<[^>]+>")


class TestSecurityRuleManagement(unittest.TestCase):
    def _client(self) -> EzPanOS:
        return EzPanOS(endpoint="10.0.0.1", api_key="test-key", connect_on_init=False)

    def test_execute_supports_cmd_element_and_extra_params(self):
        client = self._client()
        mocked_response = Mock()
        mocked_response.raise_for_status.return_value = None
        mocked_response.text = '<response status="success" code="20"><result/></response>'

        with patch("ezpanos.ezpanos.requests.post", return_value=mocked_response) as mocked_post:
            response = client.execute(
                api_type="config",
                api_action="set",
                api_xpath="/config/devices/entry",
                api_cmd="<set><foo>bar</foo></set>",
                api_element="<entry name='x'></entry>",
                api_params={"where": "before", "dst": "anchor-rule"},
            )

        self.assertIsInstance(response, dict)
        self.assertTrue(mocked_post.called)
        url = mocked_post.call_args.args[0]
        parsed = parse_qs(urlparse(url).query)
        self.assertEqual(parsed.get("type", [None])[0], "config")
        self.assertEqual(parsed.get("action", [None])[0], "set")
        self.assertEqual(parsed.get("xpath", [None])[0], "/config/devices/entry")
        self.assertEqual(parsed.get("where", [None])[0], "before")
        self.assertEqual(parsed.get("dst", [None])[0], "anchor-rule")
        self.assertEqual(parsed.get("cmd", [None])[0], "<set><foo>bar</foo></set>")
        self.assertEqual(parsed.get("element", [None])[0], "<entry name='x'></entry>")

    def test_execute_uses_instance_default_request_timeout(self):
        client = EzPanOS(
            endpoint="10.0.0.1",
            api_key="test-key",
            request_timeout_default=75,
            connect_on_init=False,
        )
        mocked_response = Mock()
        mocked_response.raise_for_status.return_value = None
        mocked_response.text = '<response status="success" code="20"><result/></response>'

        with patch("ezpanos.ezpanos.requests.post", return_value=mocked_response) as mocked_post:
            client.execute(command="show system info", api_type="op")

        self.assertEqual(mocked_post.call_args.kwargs.get("timeout"), 75.0)

    def test_execute_request_timeout_override_takes_precedence(self):
        client = EzPanOS(
            endpoint="10.0.0.1",
            api_key="test-key",
            request_timeout_default=75,
            connect_on_init=False,
        )
        mocked_response = Mock()
        mocked_response.raise_for_status.return_value = None
        mocked_response.text = '<response status="success" code="20"><result/></response>'

        with patch("ezpanos.ezpanos.requests.post", return_value=mocked_response) as mocked_post:
            client.execute(command="show system info", api_type="op", request_timeout=12)

        self.assertEqual(mocked_post.call_args.kwargs.get("timeout"), 12.0)

    def test_request_timeout_default_can_be_loaded_from_environment(self):
        with patch.dict(os.environ, {"EZPANOS_REQUEST_TIMEOUT": "45"}, clear=False):
            client = EzPanOS(endpoint="10.0.0.1", api_key="test-key", connect_on_init=False)
        self.assertEqual(client.request_timeout_default, 45.0)

    def test_request_api_key_uses_explicit_timeout(self):
        mocked_response = Mock()
        mocked_response.raise_for_status.return_value = None
        mocked_response.text = '<response status="success"><result><key>abc123</key></result></response>'

        with patch("ezpanos.ezpanos.requests.get", return_value=mocked_response) as mocked_get:
            key = EzPanOS.request_api_key(
                endpoint="10.0.0.1",
                username="admin",
                password="secret",
                request_timeout=17,
            )

        self.assertEqual(key, "abc123")
        self.assertEqual(mocked_get.call_args.kwargs.get("timeout"), 17.0)

    def test_extract_job_id_from_command_response(self):
        client = self._client()
        mocked_response = Mock()
        mocked_response.raise_for_status.return_value = None
        mocked_response.text = (
            '<response status="success" code="19"><result><msg><line>Commit job enqueued with jobid 88</line></msg>'
            "<job><id>88</id><status>PEND</status></job></result></response>"
        )

        with patch("ezpanos.ezpanos.requests.post", return_value=mocked_response):
            response = client.execute(command="show jobs all", api_type="op")

        self.assertEqual(client.extract_job_id(response), "88")

    def test_build_xml_from_command_handles_numeric_job_id_as_value(self):
        xml = build_xml_from_command("show jobs id 77")
        self.assertEqual(xml, "<show><jobs><id>77</id></jobs></show>")

    def test_build_xml_from_command_software_download_infers_version_key(self):
        xml = build_xml_from_command("request system software download 11.1.6-h23")
        self.assertEqual(
            xml,
            "<request><system><software><download><version>11.1.6-h23</version></download></software></system></request>",
        )

    def test_build_xml_from_command_supports_colon_parameter_syntax(self):
        xml = build_xml_from_command("request system software download version: 11.1.6-h23")
        self.assertEqual(
            xml,
            "<request><system><software><download><version>11.1.6-h23</version></download></software></system></request>",
        )

    def test_build_xml_from_command_request_system_software_check_stays_all_tags(self):
        xml = build_xml_from_command("request system software check")
        self.assertEqual(
            xml,
            "<request><system><software><check></check></software></system></request>",
        )

    def test_build_xml_from_command_target_set_uses_leaf_value_for_tag_like_input(self):
        xml = build_xml_from_command("target set leafvalue")
        self.assertEqual(xml, "<target><set>leafvalue</set></target>")

    def test_build_xml_from_command_show_interface_management_uses_leaf_value(self):
        xml = build_xml_from_command("show interface management")
        self.assertEqual(xml, "<show><interface>management</interface></show>")

    def test_build_xml_from_command_command_tree_templates_do_not_render_placeholder_tag(self):
        command_tree = Path(__file__).resolve().parents[1] / "src" / "command_tree" / "11.0" / "commands.txt"
        self.assertTrue(command_tree.exists(), f"missing command tree file at {command_tree}")

        failures = []
        for line_number, template in enumerate(command_tree.read_text(encoding="utf-8").splitlines(), start=1):
            command = self._materialize_template(template)
            if not command:
                continue

            xml = build_xml_from_command(command)
            try:
                ET.fromstring(xml)
            except ET.ParseError as exc:
                failures.append(f"line {line_number}: invalid XML for command '{command}': {exc}")
                continue

            if "<leafvalue>" in xml:
                failures.append(
                    f"line {line_number}: placeholder rendered as tag for command '{command}' -> {xml}"
                )

        self.assertFalse(failures, "\n".join(failures[:20]))

    def test_create_security_rule_with_move(self):
        client = self._client()
        with patch.object(client, "_default_vsys_name", return_value="vsys1"):
            with patch.object(
                client,
                "execute",
                side_effect=[
                    {"response": {"status": "success", "code": "20", "result": {}}},
                    {"response": {"status": "success", "code": "20", "result": {}}},
                ],
            ) as mocked_execute:
                result = client.create_security_rule(
                    rule_name="test-rule",
                    from_zones=["trust"],
                    to_zones=["untrust"],
                    sources=["any"],
                    destinations=["any"],
                    applications=["web-browsing"],
                    services=["application-default"],
                    action="allow",
                    position="before",
                    reference_rule="existing-rule",
                )

        self.assertTrue(result["created"])
        self.assertTrue(result["moved"])
        self.assertEqual(mocked_execute.call_count, 2)
        first_call = mocked_execute.call_args_list[0].kwargs
        second_call = mocked_execute.call_args_list[1].kwargs
        self.assertEqual(first_call["api_type"], "config")
        self.assertEqual(first_call["api_action"], "set")
        self.assertIn("<entry name=\"test-rule\">", first_call["api_element"])
        self.assertEqual(second_call["api_action"], "move")
        self.assertEqual(second_call["api_params"]["where"], "before")
        self.assertEqual(second_call["api_params"]["dst"], "existing-rule")

    def test_delete_security_rule_success(self):
        client = self._client()
        with patch.object(client, "_default_vsys_name", return_value="vsys1"):
            with patch.object(
                client,
                "execute",
                side_effect=[
                    {"response": {"status": "success", "result": {"entry": {"name": "deleteme"}}}},
                    {"response": {"status": "success", "code": "20", "result": {}}},
                    {"response": {"status": "error", "code": "7", "msg": {"line": "not found"}}},
                ],
            ):
                result = client.delete_security_rule("deleteme")

        self.assertTrue(result["exists_before"])
        self.assertFalse(result["exists_after"])
        self.assertTrue(result["deleted"])
        self.assertEqual(result["delete_status"], "success")

    def test_delete_security_rule_missing_ignore(self):
        client = self._client()
        with patch.object(client, "_default_vsys_name", return_value="vsys1"):
            with patch.object(
                client,
                "execute",
                return_value={"response": {"status": "error", "code": "7", "msg": {"line": "not found"}}},
            ):
                result = client.delete_security_rule("missing-rule", ignore_missing=True)

        self.assertFalse(result["deleted"])
        self.assertEqual(result["reason"], "rule_not_found")

    def test_commit_waits_for_job_until_fin(self):
        client = self._client()
        with patch.object(
            client,
            "execute",
            side_effect=[
                {"response": {"status": "success", "code": "19", "result": {"job": "77"}}},
                {"response": {"status": "success", "result": {"job": {"id": "77", "status": "ACT", "result": "PEND"}}}},
                {"response": {"status": "success", "result": {"job": {"id": "77", "status": "FIN", "result": "OK"}}}},
            ],
        ) as mocked_execute:
            result = client.commit(wait_for_job=True, timeout=5, poll_interval=0.01)

        self.assertEqual(mocked_execute.call_count, 3)
        self.assertEqual(result["job_id"], "77")
        self.assertTrue(result["job_complete"])
        self.assertEqual(result["job_status"], "FIN")
        self.assertEqual(result["job_result"], "OK")
        self.assertTrue(result["success"])

    def test_policy_defaults_merge_profile_and_endpoint(self):
        profile_block = {
            "policy_defaults": {
                "rule_create": {"services": ["application-default"], "log_end": True},
                "commit": {"enabled": False},
            },
            "endpoints": [
                {
                    "endpoint": "10.0.6.2",
                    "policy_defaults": {
                        "rule_create": {"services": ["svc-custom"], "log_end": False},
                        "commit": {"enabled": True},
                    },
                }
            ],
        }

        merged = EzPanOS._resolve_policy_defaults_for_endpoint(profile_block, "10.0.6.2")
        self.assertEqual(merged["rule_create"]["services"], ["svc-custom"])
        self.assertFalse(merged["rule_create"]["log_end"])
        self.assertTrue(merged["commit"]["enabled"])

    def test_create_security_rule_uses_policy_defaults_and_auto_commit(self):
        client = self._client()
        client.policy_defaults = {
            "rule_create": {
                "from_zones": ["trust"],
                "to_zones": ["untrust"],
                "applications": ["web-browsing"],
                "services": ["application-default"],
                "log_end": True,
                "description_prefix": "[auto]",
            },
            "commit": {
                "enabled": True,
                "wait_for_job": True,
                "timeout": 10,
                "poll_interval": 0.01,
            },
        }

        with patch.object(client, "_default_vsys_name", return_value="vsys1"):
            with patch.object(
                client,
                "execute",
                return_value={"response": {"status": "success", "code": "20", "result": {}}},
            ) as mocked_execute:
                with patch.object(client, "commit", return_value={"success": True, "job_id": "1"}) as mocked_commit:
                    result = client.create_security_rule(
                        rule_name="defaults-rule",
                        sources=["any"],
                        destinations=["any"],
                    )

        self.assertTrue(result["created"])
        self.assertTrue(result["committed"])
        self.assertEqual(result["request"]["from"], ["trust"])
        self.assertEqual(result["request"]["to"], ["untrust"])
        self.assertEqual(result["request"]["application"], ["web-browsing"])
        self.assertEqual(result["request"]["service"], ["application-default"])
        self.assertEqual(result["request"]["action"], "allow")
        self.assertIn("[auto]", mocked_execute.call_args.kwargs["api_element"])
        mocked_commit.assert_called_once()

    @staticmethod
    def _materialize_template(template_line: str) -> str:
        stripped = str(template_line or "").strip()
        if not stripped or stripped.startswith("#"):
            return ""

        tokens = stripped.split()
        rendered = []
        optional_depth = 0

        for token in tokens:
            if token == "[":
                optional_depth += 1
                continue
            if token == "]":
                optional_depth = max(0, optional_depth - 1)
                continue
            if optional_depth > 0:
                continue

            if _PLACEHOLDER_RE.search(token):
                rendered.append("leafvalue")
                continue

            if token.endswith(":") and len(token) > 1:
                rendered.append(token[:-1])
                continue

            rendered.append(token)

        return " ".join(rendered)


if __name__ == "__main__":
    unittest.main()
