"""
Basic import and structure tests — verify the monorepo is wired correctly.
Does NOT make live ADO calls or open a browser.
"""

import importlib

# ---------------------------------------------------------------------------
# Shared auth
# ---------------------------------------------------------------------------

def test_shared_auth_importable():
    auth = importlib.import_module("stlc_agents.shared.auth")
    assert hasattr(auth, "get_auth_headers")
    assert hasattr(auth, "get_signed_in_user")
    assert hasattr(auth, "_ADO_SCOPE")
    assert auth._ADO_SCOPE == "499b84ac-1321-427f-aa17-267ca6975798/.default"


# ---------------------------------------------------------------------------
# Agent 1 — Test Case Manager
# ---------------------------------------------------------------------------

def test_agent1_tools_importable():
    mod = importlib.import_module(
        "stlc_agents.agent_test_case_manager.tools.ado_workitem"
    )
    assert hasattr(mod, "fetch_work_item")
    assert hasattr(mod, "create_test_case")
    assert hasattr(mod, "link_test_cases_to_work_item")
    assert hasattr(mod, "get_linked_test_cases")


def test_agent1_server_importable():
    mod = importlib.import_module("stlc_agents.agent_test_case_manager.server")
    assert hasattr(mod, "main")
    assert hasattr(mod, "app")


# ---------------------------------------------------------------------------
# Agent 2 — Gherkin Generator
# ---------------------------------------------------------------------------

def test_agent2_tools_importable():
    mod = importlib.import_module(
        "stlc_agents.agent_gherkin_generator.tools.ado_gherkin"
    )
    assert hasattr(mod, "fetch_feature_hierarchy"), "fetch_feature_hierarchy must be importable"
    assert hasattr(mod, "fetch_epic_hierarchy"), (
        "fetch_epic_hierarchy must be importable — it was registered in server.py (Fix 1) "
        "and must remain importable after any refactor."
    )
    # Verify the signature accepts the three expected positional arguments
    import inspect
    sig = inspect.signature(mod.fetch_epic_hierarchy)
    params = list(sig.parameters.keys())
    assert params == ["org_url", "project", "epic_id"], (
        f"fetch_epic_hierarchy signature changed unexpectedly: {params}"
    )
    assert hasattr(mod, "attach_feature_file")
    assert hasattr(mod, "_GHERKIN_EXAMPLE")


def test_agent2_server_importable():
    mod = importlib.import_module("stlc_agents.agent_gherkin_generator.server")
    assert hasattr(mod, "main")
    assert hasattr(mod, "app")


# ---------------------------------------------------------------------------
# Agent 3 — Playwright Generator
# ---------------------------------------------------------------------------

def test_agent3_tools_importable():
    mod = importlib.import_module(
        "stlc_agents.agent_playwright_generator.tools.ado_attach"
    )
    assert hasattr(mod, "attach_file_to_work_item")


def test_agent3_server_importable():
    mod = importlib.import_module(
        "stlc_agents.agent_playwright_generator.server"
    )
    assert hasattr(mod, "main")
    assert hasattr(mod, "app")
    # Code-gen helpers
    assert hasattr(mod, "_generate_playwright_code")
    assert hasattr(mod, "_scaffold_locator_repository")
    assert hasattr(mod, "_parse_gherkin_steps")
    # inspect_live_page was removed — Playwright MCP handles browser interaction
    assert not hasattr(mod, "_inspect_live_page"), (
        "inspect_live_page was removed; browser interaction is now handled by "
        "the external Playwright MCP server (playwright:browser_snapshot etc.)"
    )


# ---------------------------------------------------------------------------
# Gherkin step parser
# ---------------------------------------------------------------------------

def test_gherkin_step_parser():
    """Parse steps from a simple feature — no auth needed."""
    mod = importlib.import_module(
        "stlc_agents.agent_playwright_generator.server"
    )
    feature = """
Feature: Login
  Scenario: User logs in successfully
    Given the user is on the login page
    When the user enters valid credentials
    Then the dashboard is displayed
    And a welcome message is shown
"""
    result = mod._parse_gherkin_steps(feature)
    assert result["total_unique_steps"] == 4
    assert "the user is on the login page" in result["by_keyword"]["Given"]
    assert "the user enters valid credentials" in result["by_keyword"]["When"]
    assert "the dashboard is displayed" in result["by_keyword"]["Then"]
    assert "a welcome message is shown" in result["by_keyword"]["And"]


# ---------------------------------------------------------------------------
# Playwright code generation (no auth, no browser)
# ---------------------------------------------------------------------------

def test_playwright_code_generation_no_auth():
    """Generate TypeScript code from Gherkin — no ADO calls, no auth."""
    mod = importlib.import_module(
        "stlc_agents.agent_playwright_generator.server"
    )
    feature = """
@login @regression
Feature: User Login
  As a user I want to log in

  Scenario: Successful login
    Given the user navigates to the Login section
    When the user submits the form
    Then a success toast notification should be displayed
"""
    result = mod._generate_playwright_code(
        gherkin=feature,
        page_class="Login",
        app_name="amplify",
        healing_strategy="role-label-text-ai",
        auth_hook="microsoft-sso",
        enable_visual_regression=True,
        enable_timing_healing=True,
    )
    assert result["file_count"] == 5
    assert "src/locators/login.locators.ts" in result["files"]
    assert "src/pages/login.page.ts" in result["files"]
    assert "src/test/steps/login.steps.ts" in result["files"]
    assert "src/test/features/login.feature" in result["files"]

    locators = result["files"]["src/locators/login.locators.ts"]
    assert "LoginLocators" in locators
    assert "selector" in locators
    assert "intent" in locators

    page = result["files"]["src/pages/login.page.ts"]
    assert "LocatorHealer" in page
    assert "clickWithHealing" in page

    # Verify no raw page.click() calls leak through
    import re
    raw_calls = [
        l for l in page.splitlines()
        if re.search(r'await\s+this\.page\.click\(', l)
        or re.search(r'await\s+page\.click\(', l)
    ]
    assert raw_calls == [], f"Raw page.click() calls found: {raw_calls}"


def test_playwright_code_generation_with_context_map():
    """Verify context_map (from Playwright MCP snapshot) is used when provided."""
    mod = importlib.import_module(
        "stlc_agents.agent_playwright_generator.server"
    )
    feature = """
Feature: Profile
  Scenario: Save photo
    Given the user navigates to the Profile section
    When the user clicks Save
    Then a success toast notification should be displayed
"""
    # Flat dict format — what the coding agent builds from browser_snapshot
    context_map = {
        "saveBtn": {
            "selector": "[data-testid='profile-save-btn']",
            "intent":   "save changes button",
            "stability": 100,
            "visualIntent": True,
        },
        "successToast": {
            "selector": "[role='alert']",
            "intent":   "success notification toast",
            "stability": 60,
            "visualIntent": True,
        },
    }
    result = mod._generate_playwright_code(
        gherkin=feature,
        page_class="Profile",
        app_name="amplify",
        healing_strategy="role-label-text-ai",
        auth_hook="none",
        enable_visual_regression=True,
        enable_timing_healing=True,
        context_map=context_map,
    )
    assert result["locator_source"] == "playwright-mcp-verified"
    locators = result["files"]["src/locators/profile.locators.ts"]
    assert "[data-testid='profile-save-btn']" in locators
    assert "[role='alert']" in locators
    assert "stability=100" in locators


def test_playwright_code_generation_without_context_map():
    """Without context_map, locator_source is gherkin-inferred."""
    mod = importlib.import_module(
        "stlc_agents.agent_playwright_generator.server"
    )
    feature = """
Feature: Settings
  Scenario: Save settings
    Given the user navigates to the Settings section
    When the user submits the form
    Then a success toast notification should be displayed
"""
    result = mod._generate_playwright_code(
        gherkin=feature,
        page_class="Settings",
        app_name="amplify",
        healing_strategy="role-label-text-ai",
        auth_hook="none",
        enable_visual_regression=True,
        enable_timing_healing=True,
        context_map=None,
    )
    assert result["locator_source"] == "gherkin-inferred"
    locators = result["files"]["src/locators/settings.locators.ts"]
    assert "GHERKIN-INFERRED" in locators


# ---------------------------------------------------------------------------
# Scaffold locator repository
# ---------------------------------------------------------------------------

def test_scaffold_locator_repository():
    mod = importlib.import_module(
        "stlc_agents.agent_playwright_generator.server"
    )
    result = mod._scaffold_locator_repository(
        output_dir="src/utils/locators",
        enable_ai_vision=True,
        repository_path="test-results/locator-repository.json",
        dashboard_port=7890,
        enable_timing_healing=True,
        enable_visual_regression=True,
    )

    # Five infrastructure files expected (DevToolsHealer removed — not in boilerplate)
    expected_files = [
        "src/utils/locators/LocatorHealer.ts",
        "src/utils/locators/LocatorRepository.ts",
        "src/utils/locators/TimingHealer.ts",
        "src/utils/locators/VisualIntentChecker.ts",
        "src/utils/locators/HealingDashboard.ts",
    ]
    for f in expected_files:
        assert f in result["files"], f"Missing expected file: {f}"

    healer = result["files"]["src/utils/locators/LocatorHealer.ts"]
    repo   = result["files"]["src/utils/locators/LocatorRepository.ts"]

    assert "playwright-cli snapshot" in healer
    assert "AI Vision" in healer
    # DevToolsHealer removed — no CDP strategy references in LocatorHealer
    assert "findByAxName" not in healer
    assert "DevToolsHealer" not in healer
    assert "localhost:9222" not in healer
    assert "remote-debugging-port" not in healer
    assert "healedSelector" in repo
    assert "intent" in repo
    assert "healingHistory" in repo

    # Strategy count: 5 base + AI(1) + timing(1) + visual(1) + dashboard(1) = 9
    assert len(result["healing_strategies"]) == 9, (
        f"Expected 9 strategies, got {len(result['healing_strategies'])}: "
        f"{result['healing_strategies']}"
    )


def test_scaffold_without_optional_layers():
    """Scaffold with everything disabled except core LocatorHealer."""
    mod = importlib.import_module(
        "stlc_agents.agent_playwright_generator.server"
    )
    result = mod._scaffold_locator_repository(
        output_dir="src/utils/locators",
        enable_ai_vision=False,
        repository_path="test-results/locator-repository.json",
        dashboard_port=7890,
        enable_timing_healing=False,
        enable_visual_regression=False,
    )
    assert "src/utils/locators/LocatorHealer.ts" in result["files"]
    assert "src/utils/locators/LocatorRepository.ts" in result["files"]
    assert "src/utils/locators/HealingDashboard.ts" in result["files"]
    # Optional files absent
    assert "src/utils/locators/TimingHealer.ts" not in result["files"]
    assert "src/utils/locators/VisualIntentChecker.ts" not in result["files"]
    assert "src/utils/locators/DevToolsHealer.ts" not in result["files"]
    # 5 base + dashboard = 6 strategies
    assert len(result["healing_strategies"]) == 6


def test_devtools_healer_not_generated():
    """DevToolsHealer.ts is not in the boilerplate and must not be generated."""
    mod = importlib.import_module(
        "stlc_agents.agent_playwright_generator.server"
    )
    result = mod._scaffold_locator_repository(
        output_dir="src/utils/locators",
        enable_ai_vision=True,
        repository_path="test-results/locator-repository.json",
        dashboard_port=7890,
        enable_timing_healing=False,
        enable_visual_regression=False,
    )
    assert "src/utils/locators/DevToolsHealer.ts" not in result["files"]
    healer = result["files"]["src/utils/locators/LocatorHealer.ts"]
    assert "DevToolsHealer" not in healer
    assert "newCDPSession" not in healer


# ---------------------------------------------------------------------------
# pre_validate_cucumber_steps — cross-file deduplication (check 6)
# ---------------------------------------------------------------------------

_EXISTING_LOGIN_STEPS = (
    "import { Given, When, Then } from '@cucumber/cucumber';\n"
    "When('the user logs in with username {string} and password {string}', "
    "async function(u: string, p: string) { await this.page.fill('#user', u); });\n"
    "Then('the dashboard is displayed', async function() { await this.page.waitForSelector('.dashboard'); });\n"
)


def test_pre_validate_cross_file_exact_duplicate_is_error():
    """Exact-match step pattern already in another file is reported as an error."""
    mod = importlib.import_module(
        "stlc_agents.agent_playwright_generator.server"
    )
    # Generated inventory steps reuse the login step verbatim
    new_steps = (
        "import { Given, When, Then } from '@cucumber/cucumber';\n"
        "When('the user logs in with username {string} and password {string}', "
        "async function(u: string, p: string) { await this.page.fill('#user', u); });\n"
        "Then('the inventory page is displayed', async function() { await this.page.waitForSelector('.inventory'); });\n"
    )
    result = mod._pre_validate_cucumber_steps(
        new_steps,
        None,
        {"src/test/steps/login.steps.ts": _EXISTING_LOGIN_STEPS},
    )
    assert result["valid"] is False
    assert any("login.steps.ts" in e for e in result["errors"])
    assert any("Cross-file duplicate" in e for e in result["errors"])


def test_pre_validate_cross_file_structural_duplicate_is_warning():
    """Same {param}-normalised form with different label text emits a warning."""
    mod = importlib.import_module(
        "stlc_agents.agent_playwright_generator.server"
    )
    # 'the user logs in with {string} and {string}' normalises the same as
    # 'the user logs in with username {string} and password {string}' — NO:
    # surrounding text differs, so these do NOT share the same normalised form.
    # Instead test a real structural match: same wording, one uses {string} one uses {word}.
    new_steps = (
        "import { Given, When, Then } from '@cucumber/cucumber';\n"
        "When('the user logs in with username {word} and password {word}', "
        "async function(u: string, p: string) { await this.page.fill('#user', u); });\n"
    )
    result = mod._pre_validate_cucumber_steps(
        new_steps,
        None,
        {"src/test/steps/login.steps.ts": _EXISTING_LOGIN_STEPS},
    )
    # Different text so no exact error, but normalised form matches → warning
    assert all("Cross-file duplicate" not in e for e in result["errors"])
    assert any("login.steps.ts" in w for w in result["warnings"])
    assert any("semantic duplicate" in w for w in result["warnings"])


def test_pre_validate_no_existing_steps_no_cross_check():
    """When existing_steps_ts_contents is omitted, check 6 is skipped silently."""
    mod = importlib.import_module(
        "stlc_agents.agent_playwright_generator.server"
    )
    new_steps = (
        "import { Given, When, Then } from '@cucumber/cucumber';\n"
        "When('the user logs in with username {string} and password {string}', "
        "async function(u: string, p: string) { await this.page.fill('#user', u); });\n"
    )
    result = mod._pre_validate_cucumber_steps(new_steps, None, None)
    assert result["valid"] is True
    assert not any("Cross-file" in e for e in result["errors"])
    assert not any("semantic duplicate" in w for w in result["warnings"])


# ---------------------------------------------------------------------------
# HTML strip and coverage hints (agent 1 helpers)
# ---------------------------------------------------------------------------

def test_html_strip():
    mod = importlib.import_module(
        "stlc_agents.agent_test_case_manager.tools.ado_workitem"
    )
    html = "<p>Accept <b>these</b> criteria:</p><ul><li>Item 1</li><li>Item 2</li></ul>"
    result = mod._strip_html(html)
    assert "<" not in result
    assert "Item 1" in result
    assert "Item 2" in result


def test_coverage_hints():
    mod = importlib.import_module(
        "stlc_agents.agent_test_case_manager.tools.ado_workitem"
    )
    wi = {
        "description": "User can upload JPG files up to 5 MB",
        "acceptance_criteria": "Success toast is shown after upload. Cancel button discards changes.",
    }
    hints = mod._extract_coverage_hints(wi)
    assert "toast_notifications" in hints
    assert "file_size_boundary" in hints
    assert "file_formats" in hints
    assert "cancel_flows" in hints


def test_steps_xml_builder():
    mod = importlib.import_module(
        "stlc_agents.agent_test_case_manager.tools.ado_workitem"
    )
    steps = [
        {"action": "Navigate to My Profile", "expected_result": "Profile section opens"},
        {"action": "Click Update Photo", "expected_result": "File picker opens"},
    ]
    xml = mod._build_steps_xml(steps)
    assert xml.startswith("<steps")
    assert 'type="ValidateStep"' in xml
    assert "Navigate to My Profile" in xml
    assert "File picker opens" in xml


# ---------------------------------------------------------------------------
# Gherkin best-practice example embedded in agent 2
# ---------------------------------------------------------------------------

def test_gherkin_example_present():
    mod = importlib.import_module(
        "stlc_agents.agent_gherkin_generator.tools.ado_gherkin"
    )
    example = mod._GHERKIN_EXAMPLE
    assert "@smoke" in example
    assert "Background:" in example
    assert "Scenario Outline" in example
    assert "Examples:" in example


# ---------------------------------------------------------------------------
# Agent 4 — Helix Writer
# ---------------------------------------------------------------------------

def test_agent4_tools_importable():
    mod = importlib.import_module(
        "stlc_agents.agent_helix_writer.tools.helix_write"
    )
    assert hasattr(mod, "write_files_to_helix")
    assert hasattr(mod, "read_helix_file")
    assert hasattr(mod, "list_helix_tree")


def test_agent4_server_importable():
    mod = importlib.import_module("stlc_agents.agent_helix_writer.server")
    assert hasattr(mod, "main")
    assert hasattr(mod, "app")


def test_helix_write_missing_root(tmp_path):
    """write_files_to_helix returns success=False when helix_root does not exist."""
    mod = importlib.import_module(
        "stlc_agents.agent_helix_writer.tools.helix_write"
    )
    result = mod.write_files_to_helix(
        str(tmp_path / "does-not-exist"),
        {"src/pages/login/locators.ts": "export const L = {}"},
    )
    assert result["success"] is False
    assert "does not exist" in result["error"]


def test_helix_write_locator_destination(tmp_path):
    """locators.ts is written to src/locators/<kebab>.locators.ts."""
    mod = importlib.import_module(
        "stlc_agents.agent_helix_writer.tools.helix_write"
    )
    # Create minimal Helix-QA structure
    (tmp_path / "src" / "locators").mkdir(parents=True)
    (tmp_path / "package.json").write_text("{}", encoding="utf-8")

    result = mod.write_files_to_helix(
        str(tmp_path),
        {"src/pages/login-page/locators.ts": "export const LoginLocators = {};"},
        mode="tests_only",
    )
    assert result["summary"]["written"] == 1
    assert result["summary"]["skipped"] == 0
    dest = tmp_path / "src" / "locators" / "login-page.locators.ts"
    assert dest.exists()
    assert "LoginLocators" in dest.read_text(encoding="utf-8")


def test_helix_write_page_object_destination(tmp_path):
    """<Page>.page.ts is written to src/pages/<Page>.page.ts."""
    mod = importlib.import_module(
        "stlc_agents.agent_helix_writer.tools.helix_write"
    )
    (tmp_path / "src" / "pages").mkdir(parents=True)

    result = mod.write_files_to_helix(
        str(tmp_path),
        {"src/pages/login-page/login-page.page.ts": "export default class LoginPage {}"},
        mode="tests_only",
    )
    assert result["summary"]["written"] == 1
    dest = tmp_path / "src" / "pages" / "login-page.page.ts"
    assert dest.exists()


def test_helix_write_steps_destination(tmp_path):
    """*.steps.ts is written to src/test/steps/<feature>.steps.ts."""
    mod = importlib.import_module(
        "stlc_agents.agent_helix_writer.tools.helix_write"
    )
    (tmp_path / "src" / "test" / "steps").mkdir(parents=True)

    result = mod.write_files_to_helix(
        str(tmp_path),
        {"src/test/steps/login-page.steps.ts": "import { Given } from '@cucumber/cucumber';"},
        mode="tests_only",
    )
    assert result["summary"]["written"] == 1
    dest = tmp_path / "src" / "test" / "steps" / "login-page.steps.ts"
    assert dest.exists()


def test_helix_write_feature_destination(tmp_path):
    """*.feature is written to src/test/features/<feature>.feature."""
    mod = importlib.import_module(
        "stlc_agents.agent_helix_writer.tools.helix_write"
    )
    (tmp_path / "src" / "test" / "features").mkdir(parents=True)

    result = mod.write_files_to_helix(
        str(tmp_path),
        {"src/test/features/login.feature": "Feature: Login\n  Scenario: Valid login\n"},
        mode="tests_only",
    )
    assert result["summary"]["written"] == 1
    dest = tmp_path / "src" / "test" / "features" / "login.feature"
    assert dest.exists()
    assert "Feature: Login" in dest.read_text(encoding="utf-8")


def test_helix_write_feature_new_scenario_appended(tmp_path):
    """A scenario with a new title is appended to the existing feature file."""
    mod = importlib.import_module(
        "stlc_agents.agent_helix_writer.tools.helix_write"
    )
    feat_dir = tmp_path / "src" / "test" / "features"
    feat_dir.mkdir(parents=True)
    existing = (
        "Feature: Login\n\n"
        "  Scenario: Valid login\n"
        '    Given user is logged with user name "username1" and password "password1"\n'
        "    Then dashboard is visible\n"
    )
    (feat_dir / "login.feature").write_text(existing, encoding="utf-8")

    generated = (
        "Feature: Login\n\n"
        "  @smoke\n"
        "  Scenario: Valid login\n"
        '    Given user is logged with "username1" and "password1"\n'
        "    Then dashboard is visible\n\n"
        "  @smoke\n"
        "  Scenario: Invalid login\n"
        '    Given user is logged with "wrong" and "creds"\n'
        "    Then error message is shown\n"
    )
    result = mod.write_files_to_helix(
        str(tmp_path),
        {"src/test/features/login.feature": generated},
        mode="tests_only",
    )
    assert result["summary"]["written"] == 1
    content = (feat_dir / "login.feature").read_text(encoding="utf-8")
    # New scenario appended
    assert "Scenario: Invalid login" in content
    assert "error message is shown" in content
    # New scenario's @smoke tag is preserved (not lost or dangling)
    lines = content.splitlines()
    for i, line in enumerate(lines):
        if "Scenario: Invalid login" in line:
            assert "@smoke" in lines[i - 1], "@smoke tag must immediately precede the new Scenario line"
            break
    # No dangling @tag lines — every @tag line must be followed by another @tag or a Scenario
    for i, line in enumerate(lines):
        if line.strip().startswith("@") and i + 1 < len(lines):
            next_stripped = lines[i + 1].strip()
            assert next_stripped.startswith("@") or next_stripped.startswith("Scenario"), \
                f"Dangling tag at line {i}: {line!r}"
    # Deduplication reported correctly
    dd = result["deduplication"][str((feat_dir / "login.feature").relative_to(tmp_path)).replace("\\", "/")]
    assert "Invalid login" in dd["added_scenarios"]
    assert "Valid login"   in dd["skipped_scenarios"]


def test_helix_write_feature_duplicate_title_keeps_existing_steps(tmp_path):
    """When scenario title already exists, existing step wording is preserved."""
    mod = importlib.import_module(
        "stlc_agents.agent_helix_writer.tools.helix_write"
    )
    feat_dir = tmp_path / "src" / "test" / "features"
    feat_dir.mkdir(parents=True)
    existing_step = 'Given user is logged with user name "username1" and password "password1"'
    existing = (
        "Feature: Login\n\n"
        f"  Scenario: Valid login\n"
        f"    {existing_step}\n"
        "    Then dashboard is visible\n"
    )
    (feat_dir / "login.feature").write_text(existing, encoding="utf-8")

    # Generator produces slightly different step wording for the same scenario title
    generated = (
        "Feature: Login\n\n"
        "  Scenario: Valid login\n"
        '    Given user is logged with "username1" and "password1"\n'
        "    Then dashboard is visible\n"
    )
    result = mod.write_files_to_helix(
        str(tmp_path),
        {"src/test/features/login.feature": generated},
        mode="tests_only",
    )
    content = (feat_dir / "login.feature").read_text(encoding="utf-8")
    # Existing step wording must be unchanged
    assert existing_step in content
    # Generated (shorter) step wording must NOT appear
    assert 'Given user is logged with "username1" and "password1"' not in content


def test_helix_write_feature_scenario_outline_deduplicated(tmp_path):
    """Scenario Outline titles are deduplicated the same way as Scenario."""
    mod = importlib.import_module(
        "stlc_agents.agent_helix_writer.tools.helix_write"
    )
    feat_dir = tmp_path / "src" / "test" / "features"
    feat_dir.mkdir(parents=True)
    existing = (
        "Feature: Login\n\n"
        "  Scenario Outline: Login with multiple users\n"
        "    Given user logs in with <username> and <password>\n"
        "    Examples:\n"
        "      | username | password |\n"
        "      | user1    | pass1    |\n"
    )
    (feat_dir / "login.feature").write_text(existing, encoding="utf-8")

    generated = (
        "Feature: Login\n\n"
        "  Scenario Outline: Login with multiple users\n"
        "    Given user logs in as <username>\n"
        "    Examples:\n"
        "      | username | password |\n"
        "      | user2    | pass2    |\n"
    )
    result = mod.write_files_to_helix(
        str(tmp_path),
        {"src/test/features/login.feature": generated},
        mode="tests_only",
    )
    content = (feat_dir / "login.feature").read_text(encoding="utf-8")
    # Original outline kept, generated duplicate not appended
    assert "user1" in content
    assert "user2" not in content


def test_helix_write_utils_locators_destination(tmp_path):
    """Infra files are sourced from boilerplate in scaffold_and_tests mode."""
    mod = importlib.import_module(
        "stlc_agents.agent_helix_writer.tools.helix_write"
    )
    (tmp_path / "src" / "utils" / "locators").mkdir(parents=True)

    # Explicitly passed infra files are ignored — boilerplate is the source of truth
    files = {
        "src/utils/locators/LocatorHealer.ts":     "export class LocatorHealer {}",
        "src/utils/locators/LocatorRepository.ts": "export class LocatorRepository {}",
        "src/utils/locators/TimingHealer.ts":      "export class TimingHealer {}",
    }
    result = mod.write_files_to_helix(str(tmp_path), files)
    # All 14 infra files should have been written from the boilerplate
    assert result["summary"]["scaffolded_from_boilerplate"] == 14
    # The 3 explicitly passed infra files were superseded by boilerplate
    boilerplate_skipped = [
        s for s in result["skipped"] if "boilerplate" in s.get("reason", "")
    ]
    assert len(boilerplate_skipped) == 3
    # Files exist on disk (written from boilerplate, not from dummy content)
    assert (tmp_path / "src" / "utils" / "locators" / "LocatorHealer.ts").exists()
    assert (tmp_path / "src" / "utils" / "locators" / "LocatorRepository.ts").exists()
    assert (tmp_path / "src" / "utils" / "locators" / "TimingHealer.ts").exists()
    # Boilerplate content was used (not the dummy strings)
    healer_content = (tmp_path / "src" / "utils" / "locators" / "LocatorHealer.ts").read_text()
    assert "export class LocatorHealer {}" not in healer_content


def test_helix_write_cucumber_profile_appended(tmp_path):
    """Cucumber profile block is appended to existing cucumber.config.ts."""
    mod = importlib.import_module(
        "stlc_agents.agent_helix_writer.tools.helix_write"
    )
    config_dir = tmp_path / "src" / "config"
    config_dir.mkdir(parents=True)
    config_file = config_dir / "cucumber.config.ts"
    config_file.write_text(
        "export default { requireModule: ['ts-node/register'] };\n",
        encoding="utf-8",
    )

    result = mod.write_files_to_helix(
        str(tmp_path),
        {"config/cucumber.js (add this profile)": "login_page: {\n  tags: '@login',\n},"},
        mode="tests_only",
    )
    assert result["summary"]["written"] == 1
    content = config_file.read_text(encoding="utf-8")
    assert "ts-node/register" in content   # original preserved
    assert "login_page" in content          # new profile appended


def test_helix_write_cucumber_duplicate_profile_skipped(tmp_path):
    """Appending a profile that already exists is skipped, not duplicated."""
    mod = importlib.import_module(
        "stlc_agents.agent_helix_writer.tools.helix_write"
    )
    config_dir = tmp_path / "src" / "config"
    config_dir.mkdir(parents=True)
    config_file = config_dir / "cucumber.config.ts"
    config_file.write_text(
        "login_page: { tags: '@login' };\n",
        encoding="utf-8",
    )

    result = mod.write_files_to_helix(
        str(tmp_path),
        {"config/cucumber.js (add this profile)": "login_page: {\n  tags: '@login',\n},"},
    )
    assert result["summary"]["skipped"] == 1
    assert "already exists" in result["skipped"][0]["reason"]


def test_helix_write_empty_content_skipped(tmp_path):
    """Files with empty content are skipped without error."""
    mod = importlib.import_module(
        "stlc_agents.agent_helix_writer.tools.helix_write"
    )
    result = mod.write_files_to_helix(
        str(tmp_path),
        {"src/test/steps/empty.steps.ts": "   "},
    )
    assert result["summary"]["skipped"] == 1
    assert result["skipped"][0]["reason"] == "empty content"


def test_read_helix_file_existing(tmp_path):
    """read_helix_file returns content for an existing file."""
    mod = importlib.import_module(
        "stlc_agents.agent_helix_writer.tools.helix_write"
    )
    target = tmp_path / "src" / "locators" / "login.locators.ts"
    target.parent.mkdir(parents=True)
    target.write_text("export const LoginLocators = {};", encoding="utf-8")

    result = mod.read_helix_file(str(tmp_path), "src/locators/login.locators.ts")
    assert result["success"] is True
    assert result["exists"] is True
    assert "LoginLocators" in result["content"]


def test_read_helix_file_missing(tmp_path):
    """read_helix_file returns exists=False for a file that does not exist."""
    mod = importlib.import_module(
        "stlc_agents.agent_helix_writer.tools.helix_write"
    )
    result = mod.read_helix_file(str(tmp_path), "src/locators/nonexistent.locators.ts")
    assert result["success"] is False
    assert result["exists"] is False


def test_read_helix_file_path_traversal(tmp_path):
    """read_helix_file rejects paths that escape helix_root."""
    mod = importlib.import_module(
        "stlc_agents.agent_helix_writer.tools.helix_write"
    )
    result = mod.read_helix_file(str(tmp_path), "../../etc/passwd")
    assert result["success"] is False
    assert "escapes" in result["error"]


def test_list_helix_tree(tmp_path):
    """list_helix_tree groups .ts and .feature files by category."""
    mod = importlib.import_module(
        "stlc_agents.agent_helix_writer.tools.helix_write"
    )
    # Create representative files
    (tmp_path / "src" / "test" / "features").mkdir(parents=True)
    (tmp_path / "src" / "test" / "steps").mkdir(parents=True)
    (tmp_path / "src" / "pages").mkdir(parents=True)
    (tmp_path / "src" / "locators").mkdir(parents=True)
    (tmp_path / "src" / "utils" / "locators").mkdir(parents=True)

    (tmp_path / "src" / "test" / "features" / "login.feature").write_text("Feature: Login\n")
    (tmp_path / "src" / "test" / "steps" / "login.steps.ts").write_text("import {};\n")
    (tmp_path / "src" / "pages" / "login-page.page.ts").write_text("export default class LoginPage {}\n")
    (tmp_path / "src" / "locators" / "login-page.locators.ts").write_text("export const L = {};\n")
    (tmp_path / "src" / "utils" / "locators" / "LocatorHealer.ts").write_text("export class LocatorHealer {}\n")

    result = mod.list_helix_tree(str(tmp_path))
    assert result["success"] is True
    assert any("login.feature" in f for f in result["tree"]["features"])
    assert any("login.steps.ts" in f for f in result["tree"]["steps"])
    assert any("login-page.page.ts" in f for f in result["tree"]["pages"])
    assert any("login-page.locators.ts" in f for f in result["tree"]["locators"])
    assert any("LocatorHealer.ts" in f for f in result["tree"]["utils_locators"])


def test_list_helix_tree_missing_root(tmp_path):
    """list_helix_tree returns success=False when root does not exist."""
    mod = importlib.import_module(
        "stlc_agents.agent_helix_writer.tools.helix_write"
    )
    result = mod.list_helix_tree(str(tmp_path / "no-such-dir"))
    assert result["success"] is False
    assert "does not exist" in result["error"]


# ---------------------------------------------------------------------------
# Gherkin validator — validate_gherkin_content (agent 2, ado_gherkin.py)
#
# Covers two implemented gaps:
#   Gap A: PBI/Bug-scoped Gherkin (work_item scope, min=3 max=9 scenarios)
#   Gap B: Structural tag + scenario-count enforcement before ADO attachment
# ---------------------------------------------------------------------------

def _gherkin_mod():
    return importlib.import_module(
        "stlc_agents.agent_gherkin_generator.tools.ado_gherkin"
    )


# ── importability ────────────────────────────────────────────────────────────

def test_validate_gherkin_content_importable():
    """validate_gherkin_content is exported from ado_gherkin."""
    mod = _gherkin_mod()
    assert hasattr(mod, "validate_gherkin_content"), (
        "validate_gherkin_content must be a public function in ado_gherkin.py"
    )


def test_fetch_work_item_for_gherkin_importable():
    """fetch_work_item_for_gherkin is exported (PBI/Bug-scoped Gherkin, Gap A)."""
    mod = _gherkin_mod()
    assert hasattr(mod, "fetch_work_item_for_gherkin"), (
        "fetch_work_item_for_gherkin must exist for PBI/Bug-scoped Gherkin generation"
    )


def test_attach_gherkin_to_work_item_importable():
    """attach_gherkin_to_work_item is exported (attaches to PBI/Bug, not Feature)."""
    mod = _gherkin_mod()
    assert hasattr(mod, "attach_gherkin_to_work_item"), (
        "attach_gherkin_to_work_item must exist so scoped feature files "
        "are attached to the PBI/Bug rather than a parent Feature"
    )


# ── feature scope (5–10 scenarios) ──────────────────────────────────────────

_VALID_FEATURE = """
@my_feature @regression
Feature: Login
  Background:
    Given I am on the login page

  @smoke
  Scenario: Happy path login
    When I enter valid credentials
    Then I am redirected to dashboard

  @regression
  Scenario: Login fails with wrong password
    When I enter wrong password
    Then I see an error message

  @regression
  Scenario: Login fails with empty username
    When I submit with empty username
    Then I see a validation error

  @regression
  Scenario: Account locked after 5 failures
    When I fail to login 5 times
    Then my account is locked

  @regression
  Scenario: Remember me keeps session
    When I check remember me and log in
    Then my session persists after closing the browser
"""


def test_valid_feature_scope_passes():
    """5 scenarios with @smoke and @regression passes feature-scope validation."""
    result = _gherkin_mod().validate_gherkin_content(_VALID_FEATURE, scope="feature")
    assert result["valid"] is True, f"Expected valid, got errors: {result['errors']}"
    assert result["stats"]["scenario_count"] == 5
    assert result["stats"]["has_smoke"] is True
    assert result["stats"]["has_regression"] is True


def test_missing_smoke_tag_is_error():
    """A feature file without @smoke fails validation."""
    content = _VALID_FEATURE.replace("  @smoke\n", "")
    result = _gherkin_mod().validate_gherkin_content(content, scope="feature")
    assert result["valid"] is False
    assert any("smoke" in e.lower() for e in result["errors"])


def test_missing_regression_tag_is_error():
    """A feature file without any @regression tag fails validation."""
    content = _VALID_FEATURE.replace("@regression", "@other")
    result = _gherkin_mod().validate_gherkin_content(content, scope="feature")
    assert result["valid"] is False
    assert any("regression" in e.lower() for e in result["errors"])


def test_feature_scope_too_few_scenarios():
    """Fewer than 5 scenarios fails feature-scope validation."""
    content = """
@regression
Feature: Minimal
  @smoke
  Scenario: Happy path
    When I do something
    Then it works

  @regression
  Scenario: Error case
    When I do something wrong
    Then I see an error
"""
    result = _gherkin_mod().validate_gherkin_content(content, scope="feature")
    assert result["valid"] is False
    assert any("few" in e.lower() or "min" in e.lower() for e in result["errors"])


def test_feature_scope_too_many_scenarios():
    """More than 10 scenarios fails feature-scope validation."""
    lines = "@regression\nFeature: Big\n"
    lines += "  @smoke\n  Scenario: Smoke\n    When I act\n    Then it works\n"
    for i in range(10):
        lines += (
            f"  @regression\n  Scenario: Scenario {i}\n"
            f"    When I do {i}\n    Then result {i}\n"
        )
    result = _gherkin_mod().validate_gherkin_content(lines, scope="feature")
    assert result["valid"] is False
    assert any("many" in e.lower() or "max" in e.lower() for e in result["errors"])


# ── work_item scope (3–9 scenarios, Gap A) ───────────────────────────────────

_VALID_WI_3 = """
@regression
Feature: Upload photo
  @smoke
  Scenario: Happy path upload
    When I upload a valid photo
    Then the photo is displayed

  @regression
  Scenario: Rejects oversized file
    When I upload a file larger than 5 MB
    Then I see a size error

  @regression
  Scenario: Cancel discards upload
    When I cancel the upload dialog
    Then no photo is saved
"""


def test_valid_work_item_scope_3_scenarios():
    """3 scenarios with @smoke and @regression passes work_item-scope validation."""
    result = _gherkin_mod().validate_gherkin_content(_VALID_WI_3, scope="work_item")
    assert result["valid"] is True, f"Expected valid, got errors: {result['errors']}"
    assert result["stats"]["scenario_count"] == 3


def test_work_item_scope_too_few_scenarios():
    """Fewer than 3 scenarios fails work_item-scope validation."""
    content = """
@regression
Feature: Tiny
  @smoke
  Scenario: Happy path
    When I act
    Then result

  @regression
  Scenario: Error
    When I err
    Then error shown
"""
    result = _gherkin_mod().validate_gherkin_content(content, scope="work_item")
    assert result["valid"] is False
    assert any("few" in e.lower() or "min" in e.lower() for e in result["errors"])


def test_work_item_scope_2_scenarios_fails():
    """2 scenarios is below the work_item min of 3 and must fail."""
    content = """
@regression
Feature: Two only
  @smoke
  Scenario: S1
    When I do S1
    Then S1 works

  @regression
  Scenario: S2
    When I do S2
    Then S2 works
"""
    result = _gherkin_mod().validate_gherkin_content(content, scope="work_item")
    assert result["valid"] is False


def test_work_item_scope_too_many_scenarios():
    """More than 9 scenarios fails work_item-scope validation."""
    lines = "@regression\nFeature: Overloaded WI\n"
    lines += "  @smoke\n  Scenario: Smoke\n    When I act\n    Then works\n"
    for i in range(9):
        lines += (
            f"  @regression\n  Scenario: Case {i}\n"
            f"    When I do {i}\n    Then {i} ok\n"
        )
    result = _gherkin_mod().validate_gherkin_content(lines, scope="work_item")
    assert result["valid"] is False
    assert any("many" in e.lower() or "max" in e.lower() for e in result["errors"])


def test_work_item_scope_9_scenarios_passes():
    """Exactly 9 scenarios is the work_item maximum and must pass."""
    lines = "@regression\nFeature: Max WI\n"
    lines += "  @smoke\n  Scenario: Smoke\n    When I act\n    Then works\n"
    for i in range(8):
        lines += (
            f"  @regression\n  Scenario: Case {i}\n"
            f"    When I do {i}\n    Then {i} ok\n"
        )
    result = _gherkin_mod().validate_gherkin_content(lines, scope="work_item")
    assert result["valid"] is True, f"Expected valid at 9 scenarios, got: {result['errors']}"


# ── structural rules applied in both scopes ──────────────────────────────────

def test_scenario_missing_when_step_is_error():
    """A scenario with no When step fails validation in both scopes."""
    content = """
@regression
Feature: No When
  @smoke
  Scenario: Has When
    When I do something
    Then it works

  @regression
  Scenario: Missing When
    Given I am on the page
    Then nothing happens

  @regression
  Scenario: Also fine
    When I act
    Then result

  @regression
  Scenario: Fine too
    When I act again
    Then result again

  @regression
  Scenario: Fifth
    When I do five
    Then five works
"""
    result = _gherkin_mod().validate_gherkin_content(content, scope="feature")
    assert result["valid"] is False
    assert any("when" in e.lower() for e in result["errors"])


def test_duplicate_scenario_titles_are_errors():
    """Two scenarios with identical titles fail validation."""
    content = """
@regression
Feature: Duplicates
  @smoke
  Scenario: Same title
    When I do something
    Then it works

  @regression
  Scenario: Same title
    When I do something else
    Then it also works

  @regression
  Scenario: Third
    When I act
    Then ok

  @regression
  Scenario: Fourth
    When I act again
    Then ok too

  @regression
  Scenario: Fifth
    When I do five
    Then five works
"""
    result = _gherkin_mod().validate_gherkin_content(content, scope="feature")
    assert result["valid"] is False
    assert any("duplicate" in e.lower() for e in result["errors"])


def test_multiple_errors_reported_together():
    """All violations are collected and returned together, not fail-fast."""
    content = """
Feature: Broken
  Scenario: Only one and no tags
    Given I exist
    Then nothing
"""
    result = _gherkin_mod().validate_gherkin_content(content, scope="feature")
    assert result["valid"] is False
    # Must surface smoke, regression, count, and missing When all at once
    joined = " ".join(result["errors"]).lower()
    assert "smoke" in joined
    assert "regression" in joined
    assert "few" in joined or "min" in joined
    assert "when" in joined


# ── stats dict shape ─────────────────────────────────────────────────────────

def test_validation_stats_keys_present():
    """validate_gherkin_content always returns a stats dict with required keys."""
    result = _gherkin_mod().validate_gherkin_content(_VALID_FEATURE, scope="feature")
    stats = result["stats"]
    for key in ("scenario_count", "has_smoke", "has_regression", "duplicate_titles"):
        assert key in stats, f"Missing stats key: {key}"


def test_validation_stats_duplicate_titles_empty_on_valid():
    """duplicate_titles list is empty when all titles are unique."""
    result = _gherkin_mod().validate_gherkin_content(_VALID_FEATURE, scope="feature")
    assert result["stats"]["duplicate_titles"] == []


# ── scoped filename convention (Gap A) ───────────────────────────────────────

def test_gherkin_work_item_filename_convention():
    """
    fetch_work_item_for_gherkin must return a suggested_filename following the
    convention  {wi_id}_{title_kebab}.feature  (no ADO call — check the helper).
    """
    mod = _gherkin_mod()
    assert hasattr(mod, "_gherkin_filename_for_work_item"), (
        "_gherkin_filename_for_work_item helper must exist to build scoped filenames"
    )
    fn = mod._gherkin_filename_for_work_item(42, "User can Upload a Profile Photo")
    assert fn == "42_user-can-upload-a-profile-photo.feature"


def test_gherkin_work_item_filename_strips_special_chars():
    """Filename helper strips non-alphanumeric characters and lowercases."""
    mod = _gherkin_mod()
    fn = mod._gherkin_filename_for_work_item(99, "Fix: Bug #123 — crash on login!")
    # Must be safe for a filesystem path
    assert fn.startswith("99_")
    assert fn.endswith(".feature")
    assert "#" not in fn
    assert "!" not in fn
    assert fn == fn.lower()