/**
 * cmd-init.js — `qa-stlc init`
 *
 * Full bootstrap: install Python agents + skills + MCP config.
 */
"use strict";

const { execSync, spawnSync } = require("child_process");
const path = require("path");
const fs   = require("fs");

const cmdSkills    = require("./cmd-skills");
const cmdMcpConfig = require("./cmd-mcp-config");

const C = {
  reset: "\x1b[0m", bold: "\x1b[1m",
  green: "\x1b[32m", cyan: "\x1b[36m",
  yellow: "\x1b[33m", red: "\x1b[31m", dim: "\x1b[2m",
};
const ok   = (m) => console.log(`${C.green}✓${C.reset}  ${m}`);
const info = (m) => console.log(`${C.cyan}→${C.reset}  ${m}`);
const warn = (m) => console.log(`${C.yellow}⚠${C.reset}  ${m}`);
const die  = (m) => { console.error(`${C.red}✗${C.reset}  ${m}`); process.exit(1); };

module.exports = async function init(opts) {
  console.log(`\n${C.bold}QA STLC Agents — init${C.reset}\n`);

  // ── 1. Check Python ──────────────────────────────────────────────────────
  const python = opts.python || "python3";
  info(`Checking Python (${python})…`);
  const pyCheck = spawnSync(python, ["--version"], { encoding: "utf8" });
  if (pyCheck.status !== 0) {
    die(`Python not found at '${python}'. Install Python 3.10+ or pass --python <path>.`);
  }
  const pyVersion = (pyCheck.stdout || pyCheck.stderr || "").trim();
  const match = pyVersion.match(/Python (\d+)\.(\d+)/);
  if (!match || parseInt(match[1]) < 3 || parseInt(match[2]) < 10) {
    die(`Python 3.10+ required, found: ${pyVersion}`);
  }
  ok(`${pyVersion} found.`);

  // ── 2. pip install qa-gentic-stlc-agents ────────────────────────────────────────
  info("Installing qa-gentic-stlc-agents (pip)…");
  const pip = spawnSync(python, ["-m", "pip", "install", "qa-gentic-stlc-agents>=1.0.1", "--quiet"], {
    stdio: "inherit",
    encoding: "utf8",
  });
  if (pip.status !== 0) {
    die("pip install failed. Run manually: pip install qa-gentic-stlc-agents");
  }
  ok("qa-gentic-stlc-agents installed.");

  // ── 3. Install skills ────────────────────────────────────────────────────
  info("Installing skills…");
  const skillTarget = opts.vscode ? "both" : "claude";
  await cmdSkills({ target: skillTarget });

  // ── 4. Write MCP config ──────────────────────────────────────────────────
  info("Writing MCP config…");
  await cmdMcpConfig({
    vscode: opts.vscode || false,
    print: false,
    python: python,
    playwrightPort: "8931",
  });

  // ── 5. Done ──────────────────────────────────────────────────────────────
  const mcpLocation   = opts.vscode ? ".vscode/mcp.json" : ".mcp.json";
  const skillsLocation = opts.vscode
    ? ".github/copilot-instructions/  (reload VS Code window to activate)"
    : ".claude/skills/";

  console.log(`
${C.bold}Setup complete.${C.reset}

  ${C.dim}MCP config :${C.reset} ${mcpLocation}
  ${C.dim}Skills     :${C.reset} ${skillsLocation}

${C.bold}Start Playwright MCP${C.reset} ${C.dim}(keep running in a separate terminal):${C.reset}

  ${C.cyan}npx @playwright/mcp@latest --port 8931${C.reset}

${C.bold}STLC Workflow${C.reset} ${C.dim}— use agents in this order:${C.reset}

  ${C.dim}1 →${C.reset} ${C.yellow}qa-test-case-manager${C.reset}     ${C.dim}ADO work item ID → create manual test cases in ADO${C.reset}
  ${C.dim}2 →${C.reset} ${C.yellow}qa-gherkin-generator${C.reset}     ${C.dim}Epic / Feature / PBI → BDD .feature file attached to ADO${C.reset}
  ${C.dim}3 →${C.reset} ${C.yellow}qa-playwright-generator${C.reset}  ${C.dim}Gherkin + live page snapshot → self-healing Playwright TypeScript${C.reset}
  ${C.dim}4 →${C.reset} ${C.yellow}qa-helix-writer${C.reset}          ${C.dim}Generated files → merged into Helix-QA project on disk${C.reset}

${C.dim}Skills reference all four steps — ask your agent: "@generate-playwright-code"${C.reset}
`);
};
