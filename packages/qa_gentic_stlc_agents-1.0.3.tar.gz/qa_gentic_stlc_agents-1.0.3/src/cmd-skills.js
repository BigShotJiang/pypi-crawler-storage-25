/**
 * cmd-skills.js — `qa-stlc skills`
 *
 * Copies skill markdown files into the correct directory for each coding agent:
 *
 *   claude    →  .claude/skills/  +  .claude/AGENT-BEHAVIOR.md
 *   vscode    →  .github/copilot-instructions/
 *   cursor    →  .cursor/rules/ (one file per skill)
 *   windsurf  →  .windsurf/rules/
 *   both      →  claude + vscode
 *   print     →  stdout only
 */
"use strict";

const path = require("path");
const fs   = require("fs");

const C = {
  reset: "\x1b[0m", bold: "\x1b[1m",
  green: "\x1b[32m", yellow: "\x1b[33m", dim: "\x1b[2m",
};
const ok   = (m) => console.log(`${C.green}✓${C.reset}  ${m}`);
const info = (m) => console.log(`   ${C.dim}${m}${C.reset}`);
const warn = (m) => console.log(`${C.yellow}⚠${C.reset}  ${m}`);

// Resolve the skills bundled with this npm package
const PKG_ROOT    = path.resolve(__dirname, "..");
const SKILLS_DIR  = path.join(PKG_ROOT, "skills", "qa-stlc");
const BEHAVIOR_MD = path.join(SKILLS_DIR, "AGENT-BEHAVIOR.md");

/** Copy a file, creating parent dirs as needed. */
function cp(src, dest) {
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.copyFileSync(src, dest);
}

/** List all .md files in SKILLS_DIR (flat). */
function skillFiles() {
  return fs.readdirSync(SKILLS_DIR)
    .filter((f) => f.endsWith(".md") && f !== "AGENT-BEHAVIOR.md")
    .map((f) => path.join(SKILLS_DIR, f));
}

const CWD = process.cwd();

function installClaude() {
  const dest = path.join(CWD, ".claude", "skills");
  for (const src of skillFiles()) {
    cp(src, path.join(dest, path.basename(src)));
  }
  cp(BEHAVIOR_MD, path.join(CWD, ".claude", "AGENT-BEHAVIOR.md"));
  ok(`Skills installed → .claude/skills/`);
  info("AGENT-BEHAVIOR.md → .claude/AGENT-BEHAVIOR.md");
  skillFiles().forEach((f) => info(path.basename(f)));
  printPlaywrightHint();
}

function installVscode() {
  const dest = path.join(CWD, ".github", "copilot-instructions");
  for (const src of skillFiles()) {
    cp(src, path.join(dest, path.basename(src)));
  }
  cp(BEHAVIOR_MD, path.join(dest, "AGENT-BEHAVIOR.md"));
  ok(`Skills installed → .github/copilot-instructions/`);
  info("Add to .github/copilot-instructions.md:");
  info("  @.github/copilot-instructions/AGENT-BEHAVIOR.md");
  printPlaywrightHint();
}

function installCursor() {
  const dest = path.join(CWD, ".cursor", "rules");
  for (const src of skillFiles()) {
    cp(src, path.join(dest, path.basename(src)));
  }
  cp(BEHAVIOR_MD, path.join(dest, "AGENT-BEHAVIOR.md"));
  ok(`Skills installed → .cursor/rules/`);
  printPlaywrightHint();
}

function installWindsurf() {
  const dest = path.join(CWD, ".windsurf", "rules");
  for (const src of skillFiles()) {
    cp(src, path.join(dest, path.basename(src)));
  }
  cp(BEHAVIOR_MD, path.join(dest, "AGENT-BEHAVIOR.md"));
  ok(`Skills installed → .windsurf/rules/`);
  printPlaywrightHint();
}

function printSkills() {
  console.log("\nAvailable skills:\n");
  skillFiles().forEach((f) => console.log(`  ${path.basename(f)}`));
  console.log(`  AGENT-BEHAVIOR.md`);
}

function printPlaywrightHint() {
  console.log(`
  ${C.dim}Start Playwright MCP before running generation workflows:${C.reset}
  npx @playwright/mcp@latest --port 8931
`);
}

module.exports = async function skills(opts) {
  const target = (opts.target || "claude").toLowerCase();

  if (!fs.existsSync(SKILLS_DIR)) {
    console.error(`Skills directory not found: ${SKILLS_DIR}`);
    console.error("Try reinstalling: npm install -g @qa-stlc/agents");
    process.exit(1);
  }

  switch (target) {
    case "claude":  installClaude();  break;
    case "vscode":  installVscode();  break;
    case "cursor":  installCursor();  break;
    case "windsurf": installWindsurf(); break;
    case "both":    installClaude(); installVscode(); break;
    case "print":   printSkills();   break;
    default:
      warn(`Unknown target: ${target}`);
      warn("Valid targets: claude, vscode, cursor, windsurf, both, print");
      process.exit(1);
  }
};
