# QA STLC Agents — Claude Code Guide

> **Before working on any task in this repo, read `AGENT-BEHAVIOR.md` first.**
> It defines the zero-inference contract that governs all agent decisions.
> The key rules below are a summary — `AGENT-BEHAVIOR.md` is the authoritative source.

## What this repo is

Three MCP servers for the QA Software Test Life Cycle. Each server is a Python package
in `src/stlc_agents/` sharing a single auth module. Browser interaction at
generation time is handled by the external **Playwright MCP** server — not this package.

## Architecture

```
src/stlc_agents/
├── shared/auth.py                              ← MSAL token cache (never modify)
├── agent_test_case_manager/server.py           ← qa-test-case-manager  (3 tools)
├── agent_gherkin_generator/server.py           ← qa-gherkin-generator  (2 tools)
└── agent_playwright_generator/server.py        ← qa-playwright-generator (4 tools + all code-gen logic)
└── agent_helix_writer/server.py                ← qa-helix-writer       (3 tools — writes files to Helix-QA)
```

## Development commands

```bash
make install      # create .venv + pip install -e .
make test         # run pytest tests/ -v
make skills       # install skill files to .claude/skills/
make verify       # check MSAL auth status without making ADO calls
make clean        # remove .venv, __pycache__, dist
```

Start Playwright MCP before running any generation workflow:
```bash
npx @playwright/mcp@latest --port 8931
# headless: npx @playwright/mcp@latest --headless --port 8931
```

## Key rules

### Coding rules (repo structure)

1. `shared/auth.py` — **do not change** the `_ADO_SCOPE`, `_DEFAULT_CLIENT_ID`, or
   `_CACHE_FILE` constants. They must match `microsoft/azure-devops-mcp` exactly.

2. Agent servers expose tools via `@app.list_tools()` and `@app.call_tool()`.
   No LLM calls inside the servers — reasoning lives in the skill files.

3. `agent_playwright_generator/server.py` contains all TypeScript code-generation
   logic as Python strings. When updating generated code patterns, update the
   corresponding `_generate_*` or `_gen_*` function.

4. `inspect_live_page` has been removed from agent 3. Browser interaction is now
   handled by the external Playwright MCP server (`playwright:browser_navigate`,
   `playwright:browser_snapshot`, etc.). The coding agent builds a `context_map`
   from Playwright MCP snapshots and passes it to `generate_playwright_code`.

5. `DevToolsHealer.ts` uses Playwright's built-in `CDPSession` at **test runtime** —
   this is separate from the Playwright MCP server used at generation time.

6. Tests in `tests/test_imports.py` must pass without live ADO connectivity or a
   browser. All tests that touch auth or ADO must be skipped or mocked.

### Agent behavior rules (read `AGENT-BEHAVIOR.md` for full detail)

7. **Work item type routing for Gherkin generation (strict — no inference):**
   - Epic ID   → `fetch_epic_hierarchy` — ALWAYS; never fall through
   - Feature ID → `fetch_feature_hierarchy`
   - PBI/Bug ID → `fetch_work_item_for_gherkin`
   - Unknown type → call fetch tool; read `work_item_type` from response; never guess

8. **Manual test cases must NEVER be created for an Epic.**
   Both `fetch_work_item` and `create_and_link_test_cases` return `epic_not_supported`.

9. **Feature-scoped test case creation requires explicit user confirmation.**
   Server returns `confirmation_required: true`. Surface to user; wait for "yes"; abort on "no".

10. **Each artifact delivery decision is independent — no carry-over.**
    - Gherkin ADO attachment: ask the user after generating
    - Playwright ADO attachment: ask the user separately — never inferred from Gherkin decision
    - Test case creation: ask the user separately — never inferred from any prior answer
    - Local file creation: only when user explicitly requests it
    - Helix disk write: only when user explicitly requests it

11. **Never invent test data, screen names, or acceptance criteria.**
    Stop and ask the user. Write `<!-- TODO: confirm screen name -->` placeholders for
    unknown navigation paths — do not guess.

12. **Never proceed past a gap.** Deduplication protocol Phase 1 is mandatory before
    creating any artifact. Gap check is mandatory before writing any Gherkin or navigating
    any live screen. Stop and wait for user answers when gaps are found.

13. **When updating instructions:** update `AGENT-BEHAVIOR.md` first, then the relevant
    `skills/*.md` file, then run `./scripts/install-skills.sh vscode` to sync
    `.github/copilot-instructions/`. Update the change log in `AGENT-BEHAVIOR.md`.

## Module paths (import these, not agent1/agent2/agent3)

```python
# Agent 1
from stlc_agents.agent_test_case_manager.server import main, app
from stlc_agents.agent_test_case_manager.tools.ado_workitem import fetch_work_item

# Agent 2
from stlc_agents.agent_gherkin_generator.server import main, app
from stlc_agents.agent_gherkin_generator.tools.ado_gherkin import fetch_feature_hierarchy

# Agent 3
from stlc_agents.agent_playwright_generator.server import (
    main, app, _generate_playwright_code, _scaffold_locator_repository, _parse_gherkin_steps
)
from stlc_agents.agent_playwright_generator.tools.ado_attach import attach_file_to_work_item

# Agent 4
from stlc_agents.agent_helix_writer.server import main, app
from stlc_agents.agent_helix_writer.tools.helix_write import (
    write_files_to_helix,
    read_helix_file,
    list_helix_tree,
)

# Shared
from stlc_agents.shared.auth import get_auth_headers, get_signed_in_user
```

## Adding a new tool

1. Add the tool definition to `@app.list_tools()` in the relevant `server.py`
2. Add the handler in `@app.call_tool()`
3. If it needs ADO REST calls, add the function to `tools/ado_*.py`
4. Update the corresponding skill file in `skills/`
5. Add a test to `tests/test_imports.py`

# Agent 4 — Helix Writer

`agent_helix_writer` has no ADO dependency and no LLM calls.
It only writes already-generated files to disk at the correct Helix-QA paths.

Tool routing:
  1. `list_helix_tree`  — always call first to see what already exists
  2. `read_helix_file`  — read a specific file for deduplication
  3. `write_helix_files` — pass the `files` dict from `generate_playwright_code`
                           or `scaffold_locator_repository` directly

Directory mapping (Helix-QA layout):
  locators.ts          → src/locators/<kebab>.locators.ts
  <Page>.page.ts       → src/pages/<Page>.page.ts
  <feature>.steps.ts   → src/test/steps/<feature>.steps.ts
  <feature>.feature    → src/test/features/<feature>.feature
  cucumber profile key → src/config/cucumber.config.ts  (appended, not replaced)
  utils/locators/*.ts  → src/utils/locators/<file>

## Skill files

Skills live in `skills/`. They are Markdown files that teach a coding agent the
step-by-step workflow for each STLC phase. They reference tool names directly.
Keep them accurate — they are the primary documentation for the agents.