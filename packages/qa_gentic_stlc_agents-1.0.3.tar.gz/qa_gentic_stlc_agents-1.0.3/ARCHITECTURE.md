# STLC Agents — Architecture

> Technical reference for the four-agent QA STLC automation system.

---

## System Overview

STLC Agents is a Python monorepo of four Model Context Protocol (MCP) servers that together automate the full Software Test Life Cycle on top of Azure DevOps. Each server is an independent Python process. A coding agent (Claude Code, GitHub Copilot, Cursor, Windsurf) installs all four with a single `npm install -g @qa-gentic/stlc-agents`, reads the skill files once, and can then drive the entire STLC pipeline — from work item to running self-healing Playwright tests — in a single prompt.

A fifth server, the external **Playwright MCP** (`http://localhost:8931/mcp`), drives a real browser during code generation to produce zero-hallucination selectors from the live accessibility tree.

---

## Repository Layout

```
stlc-agents/
├── pyproject.toml               single Python package, 4 entry-point scripts
├── package.json                 npm package: @qa-gentic/stlc-agents
├── Makefile                     install / skills / test / verify / clean
├── CLAUDE.md                    repo rules for Claude Code
├── .env.example                 ADO + AI healing configuration reference
├── .gitignore
│
├── bin/
│   ├── qa-stlc.js               CLI entry point (init / skills / mcp-config / verify)
│   └── postinstall.js           runs on npm install
│
├── src/
│   ├── cmd-init.js              qa-stlc init implementation
│   ├── cmd-skills.js            qa-stlc skills implementation
│   ├── cmd-mcp-config.js        qa-stlc mcp-config implementation
│   └── cmd-verify.js            qa-stlc verify implementation
│
├── docs/
│   ├── architecture.md
│   └── walkthrough.md
│
├── scripts/
│   ├── install-skills.sh        copy skill .md files to AI coding agent directories
│   └── generate-mcp-config.py  write .mcp.json with absolute binary paths
│
├── skills/qa-stlc/              one Markdown skill file per agent
│   ├── AGENT-BEHAVIOR.md        zero-inference contract (read first, always)
│   ├── generate-test-cases.md
│   ├── generate-gherkin.md
│   ├── generate-playwright-code.md
│   ├── write-helix-files.md
│   └── deduplication-protocol.md
│
├── tests/
│   └── test_imports.py          20 unit tests — no live ADO or browser required
│
└── src/stlc_agents/
    ├── shared/
    │   └── auth.py              MSAL silent token cache (shared by all agents)
    ├── agent_test_case_manager/
    │   ├── server.py            MCP server: qa-test-case-manager (3 tools)
    │   └── tools/ado_workitem.py  ADO REST — fetch WI, create TCs, link TCs
    ├── agent_gherkin_generator/
    │   ├── server.py            MCP server: qa-gherkin-generator (6 tools)
    │   └── tools/ado_gherkin.py  ADO REST — fetch hierarchies, attach .feature
    ├── agent_playwright_generator/
    │   ├── server.py            MCP server: qa-playwright-generator (4 tools + all code-gen)
    │   └── tools/ado_attach.py  ADO REST — attach files to work items
    └── agent_helix_writer/
        ├── server.py            MCP server: qa-helix-writer (4 tools)
        └── tools/helix_write.py  Helix-QA disk layout write logic
```

---

## The Four Agents

### Agent 1 — `qa-test-case-manager`

**Purpose:** Convert ADO work item acceptance criteria into structured manual test cases, linked back via `TestedBy-Forward` relation.

**Entry point:** `qa-test-case-manager` (installed by `pip install qa-gentic-stlc-agents`)

**Tools:**

| Tool | ADO API call | What it returns |
|---|---|---|
| `fetch_work_item` | `GET /wit/workitems/{id}?$expand=relations` | Title, AC, story points, coverage hints, existing TC count, parent feature |
| `get_linked_test_cases` | `GET /wit/workitems/{id}/relations` | Titles and IDs of TCs already linked |
| `create_and_link_test_cases` | `POST /wit/workitems/$Test Case` + `PATCH` | Created TC IDs and ADO URLs |

**Coverage hint extraction:** `_extract_coverage_hints()` scans acceptance criteria text for keywords and returns which of 11 categories need test cases:

```
toast_notifications  file_size_boundary  post_action_state  platform_specific
computed_values      data_persistence    accessibility       image_manipulation
file_formats         cancel_flows        validation_errors
```

**Complexity classification** (from story points):

| Story Points | Complexity | TC Range |
|---|---|---|
| 1–3 | Simple | 3–6 |
| 4–8 | Medium | 6–12 |
| 9+ | Complex | 12–18 |

**Work item type routing:**

- Epic → `epic_not_supported` — manual TCs are never created for Epics
- Feature → returns `confirmation_required: true` — user must confirm before creation
- PBI / Bug → normal deduplication + creation flow

---

### Agent 2 — `qa-gherkin-generator`

**Purpose:** Convert an ADO work item hierarchy into a validated Gherkin `.feature` file and attach it.

**Entry point:** `qa-gherkin-generator`

**Tools:**

| Tool | Description |
|---|---|
| `fetch_epic_hierarchy` | Fetch an Epic with all child Features, PBIs, Bugs, and existing TCs |
| `fetch_feature_hierarchy` | Fetch a Feature with all child PBIs/Bugs and linked test case steps |
| `fetch_work_item_for_gherkin` | Fetch a PBI or Bug with parent Feature context |
| `attach_gherkin_to_feature` | Validate and attach a `.feature` file to a Feature work item |
| `attach_gherkin_to_work_item` | Validate and attach a `.feature` file to a PBI or Bug |
| `validate_gherkin_content` | Structural validation — returns `valid: bool` + `errors` + `warnings` |

**Work item type routing (strict — no inference):**

```
Epic ID    → fetch_epic_hierarchy      (always; never fall through)
Feature ID → fetch_feature_hierarchy
PBI/Bug ID → fetch_work_item_for_gherkin
Unknown    → call fetch tool; read work_item_type from response
```

**File naming convention:** `{id}_{title-in-kebab-case}_regression.feature`

**Skill-enforced Gherkin rules:**
- 5–10 scenarios per feature
- `@smoke` on the primary happy path; `@regression` on all others
- `Scenario Outline` for data-driven boundary tests
- `Background` only when 2+ scenarios share identical preconditions

---

### Agent 3 — `qa-playwright-generator`

**Purpose:** Convert a validated Gherkin file into production-ready, three-layer self-healing Playwright TypeScript, with selectors derived from the live browser accessibility tree.

**Entry point:** `qa-playwright-generator`

**Tools:**

| Tool | Description |
|---|---|
| `generate_playwright_code` | Gherkin + `context_map` → 4 TypeScript files per feature |
| `scaffold_locator_repository` | Generate 6 shared healing infrastructure files |
| `validate_gherkin_steps` | Check for duplicate step strings and missing `When` steps |
| `attach_code_to_work_item` | Attach delta TypeScript files to an ADO work item |

**Generated files per feature:**

| File | Contents |
|---|---|
| `src/pages/{kebab}/locators.ts` | Selector + intent + cdpSignals + visualIntent per element |
| `src/pages/{kebab}/{kebab}.page.ts` | Page object with all healing layers |
| `src/test/steps/{kebab}.steps.ts` | Cucumber step definitions via PageFixture DI |
| `config/cucumber.js` | Cucumber profile entry |

**Generated shared infrastructure (once per project):**

| File | Purpose |
|---|---|
| `LocatorHealer.ts` | 8-strategy locator resolution chain |
| `LocatorRepository.ts` | Persistent state store |
| `TimingHealer.ts` | Network drift detection + auto-healing |
| `VisualIntentChecker.ts` | Element screenshot pixel diff |
| `DevToolsHealer.ts` | CDP AX tree + bounding-box healing |
| `HealingDashboard.ts` | HTTP approval UI at `localhost:7890` |

**Context map (zero-hallucination guarantee):** Agent 3 requires a `context_map` derived from Playwright MCP `browser_snapshot` calls. It hard-blocks generation if `context_map` is absent. Every selector in the context map is validated against the live DOM before being written to `locators.ts`.

---

### Agent 4 — `qa-helix-writer`

**Purpose:** Write already-generated files to disk at the correct Helix-QA directory layout. No ADO dependency; no LLM calls.

**Entry point:** `qa-helix-writer`

**Tools:**

| Tool | Description |
|---|---|
| `inspect_helix_project` | Returns `framework_state` (present / partial / absent) and `recommendation` |
| `list_helix_tree` | Full directory listing of the Helix-QA project |
| `read_helix_file` | Read an existing file for overlap detection |
| `write_helix_files` | Write generated files to the correct Helix-QA paths |

**Helix-QA directory mapping:**

| Generated file | Helix path |
|---|---|
| `locators.ts` | `src/locators/<kebab>.locators.ts` |
| `<Page>.page.ts` | `src/pages/<Page>.page.ts` |
| `<feature>.steps.ts` | `src/test/steps/<feature>.steps.ts` |
| `<feature>.feature` | `src/test/features/<feature>.feature` |
| Cucumber profile key | `src/config/cucumber.config.ts` (appended, not replaced) |
| `utils/locators/*.ts` | `src/utils/locators/<file>` |

**Tool call order (mandatory):**
1. `list_helix_tree` — always first, to see what exists
2. `read_helix_file` — for specific file deduplication
3. `write_helix_files` — pass the `files` dict from Agent 3 directly

---

## Authentication

All four agents share `shared/auth.py`. The module uses the same MSAL cache as `microsoft/azure-devops-mcp`, so signing into any Microsoft tool (VS Code, `az login`) also authenticates these agents.

**Token acquisition sequence:**

```
1. Load ~/.msal-cache/msal-cache.json
2. msal.acquire_token_silent()
   └─ token found and valid → Bearer token returned (zero UI)
3. msal.acquire_token_interactive()
   └─ browser opens once → user logs in → token cached for ~90 days
CI/CD: AZURE_CLIENT_ID + AZURE_CLIENT_SECRET + AZURE_TENANT_ID
       → service principal; browser never opens
```

**Constants (must match `microsoft/azure-devops-mcp` exactly — do not change):**

| Constant | Value |
|---|---|
| `_ADO_SCOPE` | `499b84ac-1321-427f-aa17-267ca6975798/.default` |
| `_DEFAULT_CLIENT_ID` | `04b07795-8ddb-461a-bbee-02f9e1bf7b46` (Azure CLI) |
| `_CACHE_FILE` | `~/.msal-cache/msal-cache.json` |

---

## Three-Layer Self-Healing Architecture

The healing system operates at test runtime across three independent layers. A fourth mechanism (AX tree validation) operates at generation time.

### Layer 1 — Locator Healing (`LocatorHealer.ts`)

When a primary selector fails, `LocatorHealer.resolve()` tries eight strategies in order:

| Strategy | Method | Timeout |
|---|---|---|
| 1 | `LocatorRepository.getHealed()` — cached result | instant |
| 2 | `page.locator(selector)` — primary CSS/XPath | 5s |
| 3 | `page.getByRole(role, name)` | 3s |
| 4 | `page.getByLabel(intent)` | 3s |
| 5 | `page.getByText(word)` | 3s |
| 6 | `DevToolsHealer.findByAxName()` — CDP AX tree | CDP, no AI cost |
| 7 | `DevToolsHealer.findByBoundingBox()` — last known coordinates | CDP |
| 8 | Claude AI Vision via playwright-cli | ~10s |

A healed selector is written to `LocatorRepository` and used immediately on the next call (Strategy 1), skipping all other strategies.

### Layer 2 — Timing Healing (`TimingHealer.ts`)

Measures actual network duration per named action, compares to stored baseline. When drift exceeds 20%, it auto-adjusts with 50% headroom for the current run and queues a suggestion to the HealingDashboard.

### Layer 3 — Visual Healing (`VisualIntentChecker.ts`)

At locators marked `visualIntent: true`, captures a scoped element screenshot and pixel-diffs against an approved baseline. A 0.5% threshold catches colour changes, truncated labels, or layout shifts that the locator layer would miss.

### Selector Stability Ranking (at generation time)

| Selector strategy | Score | Rationale |
|---|---|---|
| `data-testid` | 100 | Explicit test contract — never changes incidentally |
| `aria-role + aria-label` | 90 | Semantic; survives CSS and DOM restructuring |
| Non-generated `id` | 80 | Stable when `id` is not auto-generated |
| `aria-label` alone | 70 | Semantic but may be internationalised |
| `placeholder` | 60 | Input-only; survives minor refactors |
| Role + text (XPath) | 50 | Fallback; validated at runtime |

### HealingDashboard — human approval gate

All three healing layers write suggestions via `LocatorRepository.queueSuggestion()`. No suggestion is promoted to `healedSelector` until an engineer explicitly clicks Approve at `http://localhost:7890`.

Setting `HEALING_DASHBOARD_PORT=0` disables the HTTP server for fully automated pipelines. Suggestions are still written to `locator-repository.json`.

---

## Data Flow Diagram

```
ADO Work Item (PBI / Bug / Feature / Epic)
         │
         │  Agent 1: qa-test-case-manager
         ├─ fetch_work_item → coverage hints, complexity
         └─ create_and_link_test_cases → TC work items in ADO
                   │
                   ▼
         ADO Test Cases (TestedBy-Forward linked)
                   │
                   │  Agent 2: qa-gherkin-generator
                   ├─ fetch_feature_hierarchy → full child hierarchy
                   ├─ validate_gherkin_content → structural check
                   └─ attach_gherkin_to_feature → .feature file in ADO
                             │
                             ▼
                    Gherkin .feature file
                             │
                             │  Playwright MCP (external)
                             ├─ browser_navigate → live app page
                             └─ browser_snapshot → AX tree (context_map)
                                       │
                                       │  Agent 3: qa-playwright-generator
                                       ├─ generate_playwright_code → 4 TS files
                                       ├─ scaffold_locator_repository → 6 infra files
                                       ├─ validate_gherkin_steps
                                       └─ attach_code_to_work_item → files in ADO
                                                 │
                                                 │  Agent 4: qa-helix-writer (optional)
                                                 └─ write_helix_files → Helix-QA disk layout
                                                           │
                                                           ▼
                                              cucumber-js test run
                                                           │
                                              HealingDashboard :7890
                                              (human review of AI suggestions)
```

---

## MCP Transport

All four agents run over **stdio MCP** — the standard MCP transport for CLI tools. The coding agent spawns each server as a subprocess and communicates over stdin/stdout. The Playwright MCP uses HTTP (VS Code) or WebSocket (Claude Code).

**VS Code / GitHub Copilot (`.vscode/mcp.json`):**

```json
{
  "servers": {
    "qa-test-case-manager":    { "command": "/path/.venv/bin/qa-test-case-manager" },
    "qa-gherkin-generator":    { "command": "/path/.venv/bin/qa-gherkin-generator" },
    "qa-playwright-generator": { "command": "/path/.venv/bin/qa-playwright-generator" },
    "qa-helix-writer":         { "command": "/path/.venv/bin/qa-helix-writer" },
    "playwright": { "type": "http", "url": "http://localhost:8931/mcp" }
  }
}
```

**Claude Code (`.mcp.json`):**

```json
{
  "mcpServers": {
    "qa-test-case-manager":    { "command": "/path/.venv/bin/qa-test-case-manager" },
    "qa-gherkin-generator":    { "command": "/path/.venv/bin/qa-gherkin-generator" },
    "qa-playwright-generator": { "command": "/path/.venv/bin/qa-playwright-generator" },
    "qa-helix-writer":         { "command": "/path/.venv/bin/qa-helix-writer" },
    "playwright": { "type": "url", "url": "ws://localhost:8931" }
  }
}
```

Use `qa-stlc mcp-config [--vscode]` to generate this automatically with correct absolute binary paths.

---

## Skill Files

Each agent ships a Markdown skill file that encodes all domain rules. The coding agent reads the relevant skill before starting a task.

| Skill | Key rules encoded |
|---|---|
| `AGENT-BEHAVIOR.md` | Zero-inference contract — authoritative for all agent decisions |
| `generate-test-cases.md` | Complexity classification, 11 coverage categories, granularity merge rule |
| `generate-gherkin.md` | 5–10 scenarios, tag rules, Background conditions, Scenario Outline rules |
| `generate-playwright-code.md` | Step 0–5 workflow, 4-layer healing rules, page object constraints |
| `write-helix-files.md` | Helix-QA directory mapping, scaffold vs. merge decisions |
| `deduplication-protocol.md` | READ → DIFF → CREATE mandatory pre-flight gate |

---

## Design Decisions

**Why four separate MCP servers rather than one?** Each agent has a distinct concern and a distinct skill file. A team can use just Agent 1 (test case generation) without knowing anything about Playwright. Failures or updates in one server do not affect the others. All four share `shared/auth.py` to avoid duplication.

**Why Python for the MCP servers?** The MCP Python SDK maps cleanly to stdio transport. Python's `requests` covers all ADO REST needs. Code generation (TypeScript strings) is pure string manipulation — no TypeScript compiler is needed on the server side.

**Why not auto-commit healed selectors?** AI suggestions are probabilistic. A healed selector that works for one test run may not be semantically correct. The HealingDashboard makes every AI-generated change visible, attributable, and reversible before it enters version control.

**Why validate selectors at generation time?** AI-generated selectors frequently match zero or multiple elements in the real DOM. Validating against the live browser during the context map capture phase eliminates this class of error entirely — only selectors matching exactly one element reach `locators.ts`.

**Why persist bounding boxes?** An element that has been successfully clicked has a known, validated position in the DOM. If the CSS selector later breaks, the position is often stable. `DevToolsHealer.findByBoundingBox` uses this to find the element by where it was, not what it was called.# STLC Agents — Architecture

> Technical reference for the four-agent QA STLC automation system.

---

## System Overview

STLC Agents is a Python monorepo of four Model Context Protocol (MCP) servers that together automate the full Software Test Life Cycle on top of Azure DevOps. Each server is an independent Python process. A coding agent (Claude Code, GitHub Copilot, Cursor, Windsurf) installs all four with a single `npm install -g @qa-gentic/stlc-agents`, reads the skill files once, and can then drive the entire STLC pipeline — from work item to running self-healing Playwright tests — in a single prompt.

A fifth server, the external **Playwright MCP** (`http://localhost:8931/mcp`), drives a real browser during code generation to produce zero-hallucination selectors from the live accessibility tree.

---

## Repository Layout

```
stlc-agents/
├── pyproject.toml               single Python package, 4 entry-point scripts
├── package.json                 npm package: @qa-gentic/stlc-agents
├── Makefile                     install / skills / test / verify / clean
├── CLAUDE.md                    repo rules for Claude Code
├── .env.example                 ADO + AI healing configuration reference
├── .gitignore
│
├── bin/
│   ├── qa-stlc.js               CLI entry point (init / skills / mcp-config / verify)
│   └── postinstall.js           runs on npm install
│
├── src/
│   ├── cmd-init.js              qa-stlc init implementation
│   ├── cmd-skills.js            qa-stlc skills implementation
│   ├── cmd-mcp-config.js        qa-stlc mcp-config implementation
│   └── cmd-verify.js            qa-stlc verify implementation
│
├── docs/
│   ├── architecture.md
│   └── walkthrough.md
│
├── scripts/
│   ├── install-skills.sh        copy skill .md files to AI coding agent directories
│   └── generate-mcp-config.py  write .mcp.json with absolute binary paths
│
├── skills/qa-stlc/              one Markdown skill file per agent
│   ├── AGENT-BEHAVIOR.md        zero-inference contract (read first, always)
│   ├── generate-test-cases.md
│   ├── generate-gherkin.md
│   ├── generate-playwright-code.md
│   ├── write-helix-files.md
│   └── deduplication-protocol.md
│
├── tests/
│   └── test_imports.py          20 unit tests — no live ADO or browser required
│
└── src/stlc_agents/
    ├── shared/
    │   └── auth.py              MSAL silent token cache (shared by all agents)
    ├── agent_test_case_manager/
    │   ├── server.py            MCP server: qa-test-case-manager (3 tools)
    │   └── tools/ado_workitem.py  ADO REST — fetch WI, create TCs, link TCs
    ├── agent_gherkin_generator/
    │   ├── server.py            MCP server: qa-gherkin-generator (6 tools)
    │   └── tools/ado_gherkin.py  ADO REST — fetch hierarchies, attach .feature
    ├── agent_playwright_generator/
    │   ├── server.py            MCP server: qa-playwright-generator (4 tools + all code-gen)
    │   └── tools/ado_attach.py  ADO REST — attach files to work items
    └── agent_helix_writer/
        ├── server.py            MCP server: qa-helix-writer (4 tools)
        └── tools/helix_write.py  Helix-QA disk layout write logic
```

---

## The Four Agents

### Agent 1 — `qa-test-case-manager`

**Purpose:** Convert ADO work item acceptance criteria into structured manual test cases, linked back via `TestedBy-Forward` relation.

**Entry point:** `qa-test-case-manager` (installed by `pip install qa-gentic-stlc-agents`)

**Tools:**

| Tool | ADO API call | What it returns |
|---|---|---|
| `fetch_work_item` | `GET /wit/workitems/{id}?$expand=relations` | Title, AC, story points, coverage hints, existing TC count, parent feature |
| `get_linked_test_cases` | `GET /wit/workitems/{id}/relations` | Titles and IDs of TCs already linked |
| `create_and_link_test_cases` | `POST /wit/workitems/$Test Case` + `PATCH` | Created TC IDs and ADO URLs |

**Coverage hint extraction:** `_extract_coverage_hints()` scans acceptance criteria text for keywords and returns which of 11 categories need test cases:

```
toast_notifications  file_size_boundary  post_action_state  platform_specific
computed_values      data_persistence    accessibility       image_manipulation
file_formats         cancel_flows        validation_errors
```

**Complexity classification** (from story points):

| Story Points | Complexity | TC Range |
|---|---|---|
| 1–3 | Simple | 3–6 |
| 4–8 | Medium | 6–12 |
| 9+ | Complex | 12–18 |

**Work item type routing:**

- Epic → `epic_not_supported` — manual TCs are never created for Epics
- Feature → returns `confirmation_required: true` — user must confirm before creation
- PBI / Bug → normal deduplication + creation flow

---

### Agent 2 — `qa-gherkin-generator`

**Purpose:** Convert an ADO work item hierarchy into a validated Gherkin `.feature` file and attach it.

**Entry point:** `qa-gherkin-generator`

**Tools:**

| Tool | Description |
|---|---|
| `fetch_epic_hierarchy` | Fetch an Epic with all child Features, PBIs, Bugs, and existing TCs |
| `fetch_feature_hierarchy` | Fetch a Feature with all child PBIs/Bugs and linked test case steps |
| `fetch_work_item_for_gherkin` | Fetch a PBI or Bug with parent Feature context |
| `attach_gherkin_to_feature` | Validate and attach a `.feature` file to a Feature work item |
| `attach_gherkin_to_work_item` | Validate and attach a `.feature` file to a PBI or Bug |
| `validate_gherkin_content` | Structural validation — returns `valid: bool` + `errors` + `warnings` |

**Work item type routing (strict — no inference):**

```
Epic ID    → fetch_epic_hierarchy      (always; never fall through)
Feature ID → fetch_feature_hierarchy
PBI/Bug ID → fetch_work_item_for_gherkin
Unknown    → call fetch tool; read work_item_type from response
```

**File naming convention:** `{id}_{title-in-kebab-case}_regression.feature`

**Skill-enforced Gherkin rules:**
- 5–10 scenarios per feature
- `@smoke` on the primary happy path; `@regression` on all others
- `Scenario Outline` for data-driven boundary tests
- `Background` only when 2+ scenarios share identical preconditions

---

### Agent 3 — `qa-playwright-generator`

**Purpose:** Convert a validated Gherkin file into production-ready, three-layer self-healing Playwright TypeScript, with selectors derived from the live browser accessibility tree.

**Entry point:** `qa-playwright-generator`

**Tools:**

| Tool | Description |
|---|---|
| `generate_playwright_code` | Gherkin + `context_map` → 4 TypeScript files per feature |
| `scaffold_locator_repository` | Generate 6 shared healing infrastructure files |
| `validate_gherkin_steps` | Check for duplicate step strings and missing `When` steps |
| `attach_code_to_work_item` | Attach delta TypeScript files to an ADO work item |

**Generated files per feature:**

| File | Contents |
|---|---|
| `src/pages/{kebab}/locators.ts` | Selector + intent + cdpSignals + visualIntent per element |
| `src/pages/{kebab}/{kebab}.page.ts` | Page object with all healing layers |
| `src/test/steps/{kebab}.steps.ts` | Cucumber step definitions via PageFixture DI |
| `config/cucumber.js` | Cucumber profile entry |

**Generated shared infrastructure (once per project):**

| File | Purpose |
|---|---|
| `LocatorHealer.ts` | 8-strategy locator resolution chain |
| `LocatorRepository.ts` | Persistent state store |
| `TimingHealer.ts` | Network drift detection + auto-healing |
| `VisualIntentChecker.ts` | Element screenshot pixel diff |
| `DevToolsHealer.ts` | CDP AX tree + bounding-box healing |
| `HealingDashboard.ts` | HTTP approval UI at `localhost:7890` |

**Context map (zero-hallucination guarantee):** Agent 3 requires a `context_map` derived from Playwright MCP `browser_snapshot` calls. It hard-blocks generation if `context_map` is absent. Every selector in the context map is validated against the live DOM before being written to `locators.ts`.

---

### Agent 4 — `qa-helix-writer`

**Purpose:** Write already-generated files to disk at the correct Helix-QA directory layout. No ADO dependency; no LLM calls.

**Entry point:** `qa-helix-writer`

**Tools:**

| Tool | Description |
|---|---|
| `inspect_helix_project` | Returns `framework_state` (present / partial / absent) and `recommendation` |
| `list_helix_tree` | Full directory listing of the Helix-QA project |
| `read_helix_file` | Read an existing file for overlap detection |
| `write_helix_files` | Write generated files to the correct Helix-QA paths |

**Helix-QA directory mapping:**

| Generated file | Helix path |
|---|---|
| `locators.ts` | `src/locators/<kebab>.locators.ts` |
| `<Page>.page.ts` | `src/pages/<Page>.page.ts` |
| `<feature>.steps.ts` | `src/test/steps/<feature>.steps.ts` |
| `<feature>.feature` | `src/test/features/<feature>.feature` |
| Cucumber profile key | `src/config/cucumber.config.ts` (appended, not replaced) |
| `utils/locators/*.ts` | `src/utils/locators/<file>` |

**Tool call order (mandatory):**
1. `list_helix_tree` — always first, to see what exists
2. `read_helix_file` — for specific file deduplication
3. `write_helix_files` — pass the `files` dict from Agent 3 directly

---

## Authentication

All four agents share `shared/auth.py`. The module uses the same MSAL cache as `microsoft/azure-devops-mcp`, so signing into any Microsoft tool (VS Code, `az login`) also authenticates these agents.

**Token acquisition sequence:**

```
1. Load ~/.msal-cache/msal-cache.json
2. msal.acquire_token_silent()
   └─ token found and valid → Bearer token returned (zero UI)
3. msal.acquire_token_interactive()
   └─ browser opens once → user logs in → token cached for ~90 days
CI/CD: AZURE_CLIENT_ID + AZURE_CLIENT_SECRET + AZURE_TENANT_ID
       → service principal; browser never opens
```

**Constants (must match `microsoft/azure-devops-mcp` exactly — do not change):**

| Constant | Value |
|---|---|
| `_ADO_SCOPE` | `499b84ac-1321-427f-aa17-267ca6975798/.default` |
| `_DEFAULT_CLIENT_ID` | `04b07795-8ddb-461a-bbee-02f9e1bf7b46` (Azure CLI) |
| `_CACHE_FILE` | `~/.msal-cache/msal-cache.json` |

---

## Three-Layer Self-Healing Architecture

The healing system operates at test runtime across three independent layers. A fourth mechanism (AX tree validation) operates at generation time.

### Layer 1 — Locator Healing (`LocatorHealer.ts`)

When a primary selector fails, `LocatorHealer.resolve()` tries eight strategies in order:

| Strategy | Method | Timeout |
|---|---|---|
| 1 | `LocatorRepository.getHealed()` — cached result | instant |
| 2 | `page.locator(selector)` — primary CSS/XPath | 5s |
| 3 | `page.getByRole(role, name)` | 3s |
| 4 | `page.getByLabel(intent)` | 3s |
| 5 | `page.getByText(word)` | 3s |
| 6 | `DevToolsHealer.findByAxName()` — CDP AX tree | CDP, no AI cost |
| 7 | `DevToolsHealer.findByBoundingBox()` — last known coordinates | CDP |
| 8 | Claude AI Vision via playwright-cli | ~10s |

A healed selector is written to `LocatorRepository` and used immediately on the next call (Strategy 1), skipping all other strategies.

### Layer 2 — Timing Healing (`TimingHealer.ts`)

Measures actual network duration per named action, compares to stored baseline. When drift exceeds 20%, it auto-adjusts with 50% headroom for the current run and queues a suggestion to the HealingDashboard.

### Layer 3 — Visual Healing (`VisualIntentChecker.ts`)

At locators marked `visualIntent: true`, captures a scoped element screenshot and pixel-diffs against an approved baseline. A 0.5% threshold catches colour changes, truncated labels, or layout shifts that the locator layer would miss.

### Selector Stability Ranking (at generation time)

| Selector strategy | Score | Rationale |
|---|---|---|
| `data-testid` | 100 | Explicit test contract — never changes incidentally |
| `aria-role + aria-label` | 90 | Semantic; survives CSS and DOM restructuring |
| Non-generated `id` | 80 | Stable when `id` is not auto-generated |
| `aria-label` alone | 70 | Semantic but may be internationalised |
| `placeholder` | 60 | Input-only; survives minor refactors |
| Role + text (XPath) | 50 | Fallback; validated at runtime |

### HealingDashboard — human approval gate

All three healing layers write suggestions via `LocatorRepository.queueSuggestion()`. No suggestion is promoted to `healedSelector` until an engineer explicitly clicks Approve at `http://localhost:7890`.

Setting `HEALING_DASHBOARD_PORT=0` disables the HTTP server for fully automated pipelines. Suggestions are still written to `locator-repository.json`.

---

## Data Flow Diagram

```
ADO Work Item (PBI / Bug / Feature / Epic)
         │
         │  Agent 1: qa-test-case-manager
         ├─ fetch_work_item → coverage hints, complexity
         └─ create_and_link_test_cases → TC work items in ADO
                   │
                   ▼
         ADO Test Cases (TestedBy-Forward linked)
                   │
                   │  Agent 2: qa-gherkin-generator
                   ├─ fetch_feature_hierarchy → full child hierarchy
                   ├─ validate_gherkin_content → structural check
                   └─ attach_gherkin_to_feature → .feature file in ADO
                             │
                             ▼
                    Gherkin .feature file
                             │
                             │  Playwright MCP (external)
                             ├─ browser_navigate → live app page
                             └─ browser_snapshot → AX tree (context_map)
                                       │
                                       │  Agent 3: qa-playwright-generator
                                       ├─ generate_playwright_code → 4 TS files
                                       ├─ scaffold_locator_repository → 6 infra files
                                       ├─ validate_gherkin_steps
                                       └─ attach_code_to_work_item → files in ADO
                                                 │
                                                 │  Agent 4: qa-helix-writer (optional)
                                                 └─ write_helix_files → Helix-QA disk layout
                                                           │
                                                           ▼
                                              cucumber-js test run
                                                           │
                                              HealingDashboard :7890
                                              (human review of AI suggestions)
```

---

## MCP Transport

All four agents run over **stdio MCP** — the standard MCP transport for CLI tools. The coding agent spawns each server as a subprocess and communicates over stdin/stdout. The Playwright MCP uses HTTP (VS Code) or WebSocket (Claude Code).

**VS Code / GitHub Copilot (`.vscode/mcp.json`):**

```json
{
  "servers": {
    "qa-test-case-manager":    { "command": "/path/.venv/bin/qa-test-case-manager" },
    "qa-gherkin-generator":    { "command": "/path/.venv/bin/qa-gherkin-generator" },
    "qa-playwright-generator": { "command": "/path/.venv/bin/qa-playwright-generator" },
    "qa-helix-writer":         { "command": "/path/.venv/bin/qa-helix-writer" },
    "playwright": { "type": "http", "url": "http://localhost:8931/mcp" }
  }
}
```

**Claude Code (`.mcp.json`):**

```json
{
  "mcpServers": {
    "qa-test-case-manager":    { "command": "/path/.venv/bin/qa-test-case-manager" },
    "qa-gherkin-generator":    { "command": "/path/.venv/bin/qa-gherkin-generator" },
    "qa-playwright-generator": { "command": "/path/.venv/bin/qa-playwright-generator" },
    "qa-helix-writer":         { "command": "/path/.venv/bin/qa-helix-writer" },
    "playwright": { "type": "url", "url": "ws://localhost:8931" }
  }
}
```

Use `qa-stlc mcp-config [--vscode]` to generate this automatically with correct absolute binary paths.

---

## Skill Files

Each agent ships a Markdown skill file that encodes all domain rules. The coding agent reads the relevant skill before starting a task.

| Skill | Key rules encoded |
|---|---|
| `AGENT-BEHAVIOR.md` | Zero-inference contract — authoritative for all agent decisions |
| `generate-test-cases.md` | Complexity classification, 11 coverage categories, granularity merge rule |
| `generate-gherkin.md` | 5–10 scenarios, tag rules, Background conditions, Scenario Outline rules |
| `generate-playwright-code.md` | Step 0–5 workflow, 4-layer healing rules, page object constraints |
| `write-helix-files.md` | Helix-QA directory mapping, scaffold vs. merge decisions |
| `deduplication-protocol.md` | READ → DIFF → CREATE mandatory pre-flight gate |

---

## Design Decisions

**Why four separate MCP servers rather than one?** Each agent has a distinct concern and a distinct skill file. A team can use just Agent 1 (test case generation) without knowing anything about Playwright. Failures or updates in one server do not affect the others. All four share `shared/auth.py` to avoid duplication.

**Why Python for the MCP servers?** The MCP Python SDK maps cleanly to stdio transport. Python's `requests` covers all ADO REST needs. Code generation (TypeScript strings) is pure string manipulation — no TypeScript compiler is needed on the server side.

**Why not auto-commit healed selectors?** AI suggestions are probabilistic. A healed selector that works for one test run may not be semantically correct. The HealingDashboard makes every AI-generated change visible, attributable, and reversible before it enters version control.

**Why validate selectors at generation time?** AI-generated selectors frequently match zero or multiple elements in the real DOM. Validating against the live browser during the context map capture phase eliminates this class of error entirely — only selectors matching exactly one element reach `locators.ts`.

**Why persist bounding boxes?** An element that has been successfully clicked has a known, validated position in the DOM. If the CSS selector later breaks, the position is often stable. `DevToolsHealer.findByBoundingBox` uses this to find the element by where it was, not what it was called.