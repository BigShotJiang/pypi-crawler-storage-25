"""
gen_boilerplate.py — one-shot script to embed boilerplate/framework/ into boilerplate.py.
Run from the repo root: python3 scripts/gen_boilerplate.py
"""
from pathlib import Path

boilerplate_root = Path("boilerplate/framework")
output_path = Path("src/stlc_agents/agent_helix_writer/tools/boilerplate.py")

if not boilerplate_root.exists():
    raise SystemExit(f"boilerplate dir not found: {boilerplate_root}")

lines = []
lines.append('"""')
lines.append('boilerplate.py — Embedded Helix-QA framework template files.')
lines.append('')
lines.append('BOILERPLATE maps framework-relative paths to file content.')
lines.append('All files come from boilerplate/framework/ — embedded here so the')
lines.append('package has no runtime dependency on the boilerplate directory.')
lines.append('')
lines.append('INFRA_FILES is the subset written by write_files_to_helix scaffold_and_tests mode.')
lines.append('"""')
lines.append('from __future__ import annotations')
lines.append('')
lines.append('# fmt: off')
lines.append('BOILERPLATE: dict[str, str] = {')

# Collect all files, sorted for stable output
all_files = sorted(
    p for p in boilerplate_root.rglob("*")
    if p.is_file() and ".gitkeep" not in p.name and "__pycache__" not in str(p)
)

for f in all_files:
    rel = str(f.relative_to(boilerplate_root)).replace("\\", "/")
    try:
        content = f.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        continue  # skip binary files
    # Use repr() to get a safe Python string literal, then strip the outer quotes
    # and use it as raw string. Easier: just use json.dumps for the value.
    import json
    # ensure_ascii=False keeps emoji as real UTF-8 chars instead of \\ud83e surrogate pairs
    json_str = json.dumps(content, ensure_ascii=False)
    lines.append(f'    "{rel}": {json_str},')

lines.append("}")
lines.append("")
lines.append("# fmt: on")
lines.append("")
lines.append("# Subset used for infra scaffolding (src/utils/locators/)")
lines.append("INFRA_FILES = {")
lines.append('    k.removeprefix("src/utils/locators/"): v')
lines.append('    for k, v in BOILERPLATE.items()')
lines.append('    if k.startswith("src/utils/locators/")')
lines.append("}")
lines.append("")

output_path.write_text("\n".join(lines), encoding="utf-8")
print(f"Generated {output_path} with {len(all_files)} files embedded ({output_path.stat().st_size // 1024}KB)")
