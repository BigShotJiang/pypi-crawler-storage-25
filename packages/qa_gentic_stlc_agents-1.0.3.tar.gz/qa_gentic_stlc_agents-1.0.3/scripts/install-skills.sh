#!/usr/bin/env bash
# install-skills.sh — Install QA STLC Agent skills into a coding agent
#
# Usage:
#   ./scripts/install-skills.sh               # Claude Code (.claude/skills/)
#   ./scripts/install-skills.sh vscode        # VS Code (.github/copilot-instructions/)
#   ./scripts/install-skills.sh print         # Print skill paths only
#
# Equivalent to: npx skills add https://github.com/your-org/stlc-agents

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
SKILLS_DIR="$ROOT_DIR/skills"

TARGET="${1:-claude}"

case "$TARGET" in
  vscode)
    DEST="$PWD/.github/copilot-instructions"
    mkdir -p "$DEST"
    cp "$SKILLS_DIR"/qa-stlc/*.md "$DEST/"
    echo "✓ Skills installed to $DEST"
    echo "  Add to .github/copilot-instructions.md: @.github/copilot-instructions/generate-test-cases.md"
    ;;
  print)
    echo "Available skills:"
    ls "$SKILLS_DIR"/qa-stlc/*.md
    ;;
  *)
    # Default: Claude Code
    DEST="$PWD/.claude/skills"
    mkdir -p "$DEST"
    cp "$SKILLS_DIR/qa-stlc/generate-test-cases.md"      "$DEST/"
    cp "$SKILLS_DIR/qa-stlc/generate-gherkin.md"          "$DEST/"
    cp "$SKILLS_DIR/qa-stlc/generate-playwright-code.md"  "$DEST/"
    cp "$SKILLS_DIR/qa-stlc/write-helix-files.md"         "$DEST/"
    echo "✓ 3 skills installed to $DEST"
    echo ""
    echo "Skills available to Claude Code:"
    echo "  • generate-test-cases.md      → ADO work item → test cases"
    echo "  • generate-gherkin.md         → Feature → BDD .feature file"
    echo "  • generate-playwright-code.md → Gherkin → Playwright TypeScript"
    ;;
esac
