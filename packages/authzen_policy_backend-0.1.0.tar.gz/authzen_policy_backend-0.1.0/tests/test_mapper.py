"""Tests for the context-to-AuthZEN request mapper."""

from __future__ import annotations

from authzen_backend.mapper import FieldMapping, map_context_to_authzen


class TestMapContextToAuthzen:
    def test_minimal_context(self) -> None:
        req = map_context_to_authzen(
            {"tool_name": "file_read", "agent_id": "agent-1"},
            pdp_application="test-app",
        )
        assert req.subject.type == "ai_agent"
        assert req.subject.id == "auth:agent:agentmesh:agent-1"
        assert req.action.name == "file_read"
        assert req.action.properties["operation_ref_id"] == "op:tool:file_read"
        assert req.resource.type == "mcp_tool"
        assert req.resource.id == "file_read"
        assert req.context["pdp_application"] == "test-app"

    def test_defaults_for_missing_fields(self) -> None:
        req = map_context_to_authzen({}, pdp_application="app")
        assert req.subject.id == "auth:agent:agentmesh:anonymous"
        assert req.action.name == "unknown"
        assert req.resource.id == "unknown"

    def test_user_binding(self) -> None:
        req = map_context_to_authzen(
            {"tool_name": "t", "agent_id": "a1", "user_id": "alice"},
            pdp_application="app",
        )
        assert req.subject.properties["bound_to_user_id"] == "alice"

    def test_delegator_passthrough(self) -> None:
        req = map_context_to_authzen(
            {"tool_name": "t", "agent_id": "a1", "delegator": "bob"},
            pdp_application="app",
        )
        assert req.subject.properties["delegator"] == "bob"

    def test_pre_normalized_subject_id(self) -> None:
        req = map_context_to_authzen(
            {"tool_name": "t", "agent_id": "auth:agent:empowernow:x"},
            pdp_application="app",
        )
        assert req.subject.id == "auth:agent:empowernow:x"

    def test_extra_context_forwarded(self) -> None:
        req = map_context_to_authzen(
            {"tool_name": "t", "agent_id": "a1", "custom_key": "custom_val"},
            pdp_application="app",
        )
        assert req.context["custom_key"] == "custom_val"

    def test_consumed_keys_excluded_from_context(self) -> None:
        req = map_context_to_authzen(
            {"tool_name": "t", "agent_id": "a1", "user_id": "u"},
            pdp_application="app",
        )
        assert "tool_name" not in req.context
        assert "agent_id" not in req.context
        assert "user_id" not in req.context

    def test_custom_mapping(self) -> None:
        mapping = FieldMapping(
            agent_id_key="principal",
            tool_name_key="operation",
        )
        req = map_context_to_authzen(
            {"operation": "deploy", "principal": "bot-7"},
            pdp_application="app",
            mapping=mapping,
        )
        assert req.action.name == "deploy"
        assert req.subject.id == "auth:agent:agentmesh:bot-7"

    def test_explicit_action_overrides_tool_name(self) -> None:
        req = map_context_to_authzen(
            {"tool_name": "t", "action": "custom_action"},
            pdp_application="app",
        )
        assert req.action.name == "custom_action"

    def test_explicit_resource_type_and_id(self) -> None:
        req = map_context_to_authzen(
            {
                "tool_name": "t",
                "resource_type": "database",
                "resource_id": "db-prod",
            },
            pdp_application="app",
        )
        assert req.resource.type == "database"
        assert req.resource.id == "db-prod"
