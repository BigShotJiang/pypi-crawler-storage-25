"""Tests for ARIA-enhanced context extraction."""

from __future__ import annotations

from authzen_backend.aria import (
    extract_aria_context,
)
from authzen_backend.backend import BackendDecision


class TestExtractARIAContext:
    def test_full_aria_response(self) -> None:
        decision = BackendDecision(
            allowed=True,
            raw_result={
                "decision": True,
                "context": {
                    "id": "dec-123",
                    "decision_id": "dec-123",
                    "reason_admin": {"en": "allowed by policy"},
                    "reason_user": {"en": "you're good"},
                    "obligations": [
                        {"id": "log_access", "type": "audit", "attributes": {"level": "info"}}
                    ],
                    "constraints": [{"field": "max_rows", "operator": "lte", "value": 1000}],
                    "requires_approval": False,
                },
            },
        )

        ctx = extract_aria_context(decision)

        assert ctx.decision_id == "dec-123"
        assert ctx.reason_admin == "allowed by policy"
        assert ctx.reason_user == "you're good"
        assert len(ctx.obligations) == 1
        assert ctx.obligations[0].id == "log_access"
        assert ctx.obligations[0].type == "audit"
        assert ctx.obligations[0].attributes["level"] == "info"
        assert len(ctx.constraints) == 1
        assert ctx.constraints[0].field_name == "max_rows"
        assert ctx.constraints[0].operator == "lte"
        assert ctx.constraints[0].value == 1000
        assert ctx.requires_approval is False

    def test_denial_with_user_advice(self) -> None:
        decision = BackendDecision(
            allowed=False,
            raw_result={
                "decision": False,
                "context": {
                    "reason_admin": {"en": "budget exceeded"},
                    "user_advice": {
                        "message": "You've exceeded your daily budget.",
                        "severity": "high",
                        "remediation": "Request a budget increase from your manager.",
                        "action_code": "REQUEST_BUDGET_INCREASE",
                        "action_params": {"current_spend": 150.0, "limit": 100.0},
                    },
                },
            },
        )

        ctx = extract_aria_context(decision)

        assert len(ctx.advice) == 1
        assert ctx.advice[0].message == "You've exceeded your daily budget."
        assert ctx.advice[0].severity == "high"
        assert ctx.advice[0].action_code == "REQUEST_BUDGET_INCREASE"
        assert ctx.advice[0].action_params["current_spend"] == 150.0

    def test_denial_with_advice_array(self) -> None:
        decision = BackendDecision(
            allowed=False,
            raw_result={
                "decision": False,
                "context": {
                    "advice": [
                        {"id": "step_up_auth", "message": "MFA required"},
                        {"id": "contact_admin", "severity": "medium"},
                    ],
                },
            },
        )

        ctx = extract_aria_context(decision)

        assert len(ctx.advice) == 2
        assert ctx.advice[0].message == "MFA required"
        assert ctx.advice[1].message == "contact_admin"

    def test_requires_approval(self) -> None:
        decision = BackendDecision(
            allowed=False,
            raw_result={
                "decision": False,
                "context": {"requires_approval": True},
            },
        )

        ctx = extract_aria_context(decision)
        assert ctx.requires_approval is True

    def test_empty_raw_result(self) -> None:
        decision = BackendDecision(allowed=True, raw_result=None)
        ctx = extract_aria_context(decision)
        assert ctx.decision_id == ""
        assert ctx.obligations == []
        assert ctx.constraints == []
        assert ctx.advice == []

    def test_non_aria_pdp_response(self) -> None:
        decision = BackendDecision(
            allowed=True,
            raw_result={"decision": True, "context": {}},
        )
        ctx = extract_aria_context(decision)
        assert ctx.decision_id == ""
        assert ctx.obligations == []

    def test_fallback_to_id_when_no_decision_id(self) -> None:
        decision = BackendDecision(
            allowed=True,
            raw_result={"decision": True, "context": {"id": "fallback-id"}},
        )
        ctx = extract_aria_context(decision)
        assert ctx.decision_id == "fallback-id"

    def test_reason_admin_as_string(self) -> None:
        decision = BackendDecision(
            allowed=True,
            raw_result={
                "decision": True,
                "context": {"reason_admin": "plain string reason"},
            },
        )
        ctx = extract_aria_context(decision)
        assert ctx.reason_admin == "plain string reason"

    def test_raw_context_preserved(self) -> None:
        original_ctx = {"id": "x", "custom_field": "custom_value"}
        decision = BackendDecision(
            allowed=True,
            raw_result={"decision": True, "context": original_ctx},
        )
        ctx = extract_aria_context(decision)
        assert ctx.raw_context["custom_field"] == "custom_value"
