"""Tests for token acquisition strategies."""

from __future__ import annotations

import time

import httpx
import pytest

from authzen_backend.auth import (
    ClientCredentialsAuth,
    StaticTokenAuth,
    TokenCache,
    TokenProvider,
)


class TestTokenProvider:
    def test_static_token_satisfies_protocol(self) -> None:
        auth: TokenProvider = StaticTokenAuth(token="t")
        assert isinstance(auth, TokenProvider)

    def test_client_credentials_satisfies_protocol(self) -> None:
        auth: TokenProvider = ClientCredentialsAuth(
            token_endpoint="https://idp.test/token",
            client_id="c",
            client_secret="s",
        )
        assert isinstance(auth, TokenProvider)


class TestStaticTokenAuth:
    def test_returns_token(self) -> None:
        auth = StaticTokenAuth(token="my-token")
        client = httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(200)))
        assert auth.get_token(client) == "my-token"

    @pytest.mark.asyncio
    async def test_returns_token_async(self) -> None:
        auth = StaticTokenAuth(token="my-token")
        client = httpx.AsyncClient(transport=httpx.MockTransport(lambda r: httpx.Response(200)))
        assert await auth.get_token_async(client) == "my-token"

    def test_token_excluded_from_repr(self) -> None:
        auth = StaticTokenAuth(token="super-secret")
        assert "super-secret" not in repr(auth)


class TestTokenCache:
    def test_valid_when_not_expired(self) -> None:
        cache = TokenCache(access_token="tok", expires_at=time.time() + 300)
        assert cache.valid is True

    def test_invalid_when_expired(self) -> None:
        cache = TokenCache(access_token="tok", expires_at=time.time() - 1)
        assert cache.valid is False

    def test_invalid_when_empty(self) -> None:
        cache = TokenCache()
        assert cache.valid is False


class TestClientCredentialsAuth:
    def test_fetches_token(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            body = dict(x.split("=") for x in request.content.decode().split("&"))
            assert body["grant_type"] == "client_credentials"
            assert body["client_id"] == "my-client"
            assert body["client_secret"] == "my-secret"
            return httpx.Response(
                200,
                json={"access_token": "fresh-token", "expires_in": 3600},
            )

        auth = ClientCredentialsAuth(
            token_endpoint="https://idp.test/token",
            client_id="my-client",
            client_secret="my-secret",
        )
        client = httpx.Client(transport=httpx.MockTransport(handler))
        token = auth.get_token(client)
        assert token == "fresh-token"

    def test_caches_token(self) -> None:
        call_count = 0

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            return httpx.Response(
                200,
                json={"access_token": f"token-{call_count}", "expires_in": 3600},
            )

        auth = ClientCredentialsAuth(
            token_endpoint="https://idp.test/token",
            client_id="c",
            client_secret="s",
        )
        client = httpx.Client(transport=httpx.MockTransport(handler))
        t1 = auth.get_token(client)
        t2 = auth.get_token(client)
        assert t1 == t2
        assert call_count == 1

    def test_refreshes_token_on_expiry(self) -> None:
        call_count = 0

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            return httpx.Response(
                200,
                json={"access_token": f"token-{call_count}", "expires_in": 1},
            )

        auth = ClientCredentialsAuth(
            token_endpoint="https://idp.test/token",
            client_id="c",
            client_secret="s",
        )
        client = httpx.Client(transport=httpx.MockTransport(handler))
        t1 = auth.get_token(client)
        # expires_in=1 minus 30s safety margin means it's already expired
        t2 = auth.get_token(client)
        assert t1 != t2
        assert call_count == 2

    def test_includes_audience(self) -> None:
        captured_body: dict[str, str] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured_body.update(dict(x.split("=") for x in request.content.decode().split("&")))
            return httpx.Response(
                200,
                json={"access_token": "tok", "expires_in": 3600},
            )

        auth = ClientCredentialsAuth(
            token_endpoint="https://idp.test/token",
            client_id="c",
            client_secret="s",
            audience="pdp-audience",
        )
        client = httpx.Client(transport=httpx.MockTransport(handler))
        auth.get_token(client)
        assert captured_body["audience"] == "pdp-audience"

    def test_secret_excluded_from_repr(self) -> None:
        auth = ClientCredentialsAuth(
            token_endpoint="https://idp.test/token",
            client_id="my-client",
            client_secret="ultra-secret-value",
        )
        assert "ultra-secret-value" not in repr(auth)

    def test_extra_params_cannot_override_grant_type(self) -> None:
        auth = ClientCredentialsAuth(
            token_endpoint="https://idp.test/token",
            client_id="c",
            client_secret="s",
            extra_params={"grant_type": "authorization_code"},
        )
        client = httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(200)))
        with pytest.raises(ValueError, match="grant_type"):
            auth.get_token(client)

    def test_extra_params_cannot_override_client_secret(self) -> None:
        auth = ClientCredentialsAuth(
            token_endpoint="https://idp.test/token",
            client_id="c",
            client_secret="s",
            extra_params={"client_secret": "evil"},
        )
        client = httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(200)))
        with pytest.raises(ValueError, match="client_secret"):
            auth.get_token(client)

    @pytest.mark.asyncio
    async def test_fetches_token_async(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                json={"access_token": "async-token", "expires_in": 3600},
            )

        auth = ClientCredentialsAuth(
            token_endpoint="https://idp.test/token",
            client_id="c",
            client_secret="s",
        )
        client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
        token = await auth.get_token_async(client)
        assert token == "async-token"
