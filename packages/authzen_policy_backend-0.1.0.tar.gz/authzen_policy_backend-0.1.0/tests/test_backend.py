"""Tests for the sync and async AuthZEN backends."""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from authzen_backend import (
    AsyncAuthZENBackend,
    AuthZENBackend,
    BackendDecision,
    ClientCredentialsAuth,
)


def _pdp_response(decision: bool, context: dict[str, Any] | None = None) -> dict[str, Any]:
    return {"decision": decision, "context": context or {}}


def _mock_transport(response_body: dict[str, Any], status: int = 200) -> httpx.MockTransport:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(status, json=response_body)

    return httpx.MockTransport(handler)


def _make_backend(
    transport: httpx.MockTransport,
    *,
    pdp_application: str = "test",
    fail_closed: bool = True,
    token: str = "tok",
) -> AuthZENBackend:
    return AuthZENBackend(
        pdp_url="https://pdp.test/access/v1/evaluation",
        pdp_application=pdp_application,
        token=token,
        fail_closed=fail_closed,
        http_client=httpx.Client(transport=transport),
    )


def _make_async_backend(
    transport: httpx.MockTransport,
    *,
    fail_closed: bool = True,
    token: str = "tok",
) -> AsyncAuthZENBackend:
    return AsyncAuthZENBackend(
        pdp_url="https://pdp.test/access/v1/evaluation",
        pdp_application="test",
        token=token,
        fail_closed=fail_closed,
        http_client=httpx.AsyncClient(transport=transport),
    )


class TestAuthZENBackend:
    def test_allow_decision(self) -> None:
        transport = _mock_transport(_pdp_response(True, {"reason_admin": {"en": "ok"}}))
        backend = _make_backend(transport)

        result = backend.evaluate({"tool_name": "read", "agent_id": "a1"})

        assert isinstance(result, BackendDecision)
        assert result.allowed is True
        assert result.action == "allow"
        assert result.backend == "authzen"
        assert result.error is None
        assert result.reason == "ok"
        assert result.evaluation_ms >= 0

    def test_deny_decision(self) -> None:
        transport = _mock_transport(
            _pdp_response(False, {"reason_admin": {"en": "budget exceeded"}})
        )
        result = _make_backend(transport).evaluate({"tool_name": "deploy", "agent_id": "a1"})

        assert result.allowed is False
        assert result.action == "deny"
        assert result.reason == "budget exceeded"

    def test_raw_result_contains_full_authzen_response(self) -> None:
        ctx = {"reason_admin": {"en": "ok"}, "obligations": [{"id": "log"}]}
        transport = _mock_transport(_pdp_response(True, ctx))

        result = _make_backend(transport).evaluate({"tool_name": "t"})

        assert result.raw_result["decision"] is True
        assert result.raw_result["context"]["obligations"] == [{"id": "log"}]

    def test_fail_closed_returns_authoritative_deny(self) -> None:
        """fail_closed=True: error field is None so the toolkit treats it as final."""
        transport = _mock_transport({"error": "unauthorized"}, status=401)
        result = _make_backend(transport, fail_closed=True).evaluate({"tool_name": "t"})

        assert result.allowed is False
        assert result.action == "deny"
        assert result.error is None
        assert "HTTP 401" in result.reason

    def test_fail_open_signals_error_for_next_backend(self) -> None:
        """fail_closed=False: error field is set so the toolkit skips to next backend."""
        transport = _mock_transport({"error": "server down"}, status=503)
        result = _make_backend(transport, fail_closed=False).evaluate({"tool_name": "t"})

        assert result.allowed is False
        assert result.error is not None
        assert "HTTP 503" in result.error

    def test_protocol_name(self) -> None:
        backend = AuthZENBackend(
            pdp_url="https://pdp.test/access/v1/evaluation",
            pdp_application="test",
            token="tok",
        )
        assert backend.name == "authzen"
        backend.close()

    def test_requires_auth(self) -> None:
        with pytest.raises(ValueError, match="token"):
            AuthZENBackend(
                pdp_url="https://pdp.test/access/v1/evaluation",
                pdp_application="test",
            )

    def test_sends_bearer_token(self) -> None:
        captured_headers: dict[str, str] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured_headers.update(dict(request.headers))
            return httpx.Response(200, json=_pdp_response(True))

        backend = _make_backend(httpx.MockTransport(handler), token="my-secret-token")
        backend.evaluate({"tool_name": "t"})

        assert captured_headers["authorization"] == "Bearer my-secret-token"

    def test_sends_correct_authzen_body(self) -> None:
        captured_body: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured_body.update(json.loads(request.content))
            return httpx.Response(200, json=_pdp_response(True))

        backend = _make_backend(httpx.MockTransport(handler), pdp_application="my-app")
        backend.evaluate({"tool_name": "file_read", "agent_id": "bot-1"})

        assert captured_body["subject"]["type"] == "ai_agent"
        assert captured_body["subject"]["id"] == "auth:agent:agentmesh:bot-1"
        assert captured_body["action"]["name"] == "file_read"
        assert captured_body["action"]["properties"]["operation_ref_id"] == "op:tool:file_read"
        assert captured_body["resource"]["type"] == "mcp_tool"
        assert captured_body["context"]["pdp_application"] == "my-app"

    def test_context_manager(self) -> None:
        transport = _mock_transport(_pdp_response(True))
        with AuthZENBackend(
            pdp_url="https://pdp.test/access/v1/evaluation",
            pdp_application="test",
            token="tok",
            http_client=httpx.Client(transport=transport),
        ) as backend:
            assert backend.name == "authzen"

    def test_reason_fallback_when_no_reason_admin(self) -> None:
        transport = _mock_transport(_pdp_response(True, {}))
        result = _make_backend(transport).evaluate({"tool_name": "t"})
        assert "permitted" in result.reason.lower()

    def test_reason_from_reason_user_when_no_admin(self) -> None:
        transport = _mock_transport(_pdp_response(False, {"reason_user": {"en": "contact admin"}}))
        result = _make_backend(transport).evaluate({"tool_name": "t"})
        assert result.reason == "contact admin"

    def test_does_not_close_injected_client(self) -> None:
        """When http_client is injected, close() must not close it."""
        transport = _mock_transport(_pdp_response(True))
        client = httpx.Client(transport=transport)
        backend = AuthZENBackend(
            pdp_url="https://pdp.test/access/v1/evaluation",
            pdp_application="test",
            token="tok",
            http_client=client,
        )
        backend.close()
        # Client should still be usable after backend.close()
        resp = client.get("https://pdp.test/health")
        assert resp.status_code == 200

    def test_rejects_both_token_and_credentials(self) -> None:
        with pytest.raises(ValueError, match="not both"):
            AuthZENBackend(
                pdp_url="https://pdp.test/access/v1/evaluation",
                pdp_application="test",
                token="tok",
                client_credentials=ClientCredentialsAuth(
                    token_endpoint="https://idp.test/token",
                    client_id="c",
                    client_secret="s",
                ),
            )

    def test_rejects_plain_http_non_localhost(self) -> None:
        with pytest.raises(ValueError, match="HTTPS"):
            AuthZENBackend(
                pdp_url="http://pdp.production.com/access/v1/evaluation",
                pdp_application="test",
                token="tok",
            )

    def test_allows_http_localhost(self) -> None:
        backend = AuthZENBackend(
            pdp_url="http://localhost:8001/access/v1/evaluation",
            pdp_application="test",
            token="tok",
        )
        assert backend.name == "authzen"
        backend.close()

    def test_rejects_non_http_scheme(self) -> None:
        with pytest.raises(ValueError, match="https://"):
            AuthZENBackend(
                pdp_url="ftp://pdp.test/eval",
                pdp_application="test",
                token="tok",
            )

    def test_rejects_empty_pdp_url(self) -> None:
        with pytest.raises(ValueError, match="empty"):
            AuthZENBackend(
                pdp_url="",
                pdp_application="test",
                token="tok",
            )

    def test_error_reason_does_not_leak_url(self) -> None:
        """Sanitized error: should contain 'HTTP 500', not the full URL or response body."""
        transport = _mock_transport({"secret": "leaked-data"}, status=500)
        result = _make_backend(transport, fail_closed=False).evaluate({"tool_name": "t"})

        assert "pdp.test" not in result.reason
        assert "leaked-data" not in (result.error or "")
        assert "HTTP 500" in result.reason


class TestAsyncAuthZENBackend:
    @pytest.mark.asyncio
    async def test_allow_decision(self) -> None:
        transport = _mock_transport(_pdp_response(True, {"reason_admin": {"en": "ok"}}))
        result = await _make_async_backend(transport).evaluate(
            {"tool_name": "read", "agent_id": "a1"}
        )

        assert result.allowed is True
        assert result.action == "allow"
        assert result.reason == "ok"

    @pytest.mark.asyncio
    async def test_deny_decision(self) -> None:
        transport = _mock_transport(_pdp_response(False, {"reason_admin": {"en": "nope"}}))
        result = await _make_async_backend(transport).evaluate({"tool_name": "t"})

        assert result.allowed is False
        assert result.reason == "nope"

    @pytest.mark.asyncio
    async def test_fail_closed_on_error(self) -> None:
        transport = _mock_transport({"error": "boom"}, status=500)
        result = await _make_async_backend(transport, fail_closed=True).evaluate({"tool_name": "t"})

        assert result.allowed is False
        assert result.error is None

    @pytest.mark.asyncio
    async def test_fail_open_signals_error(self) -> None:
        transport = _mock_transport({"error": "boom"}, status=500)
        result = await _make_async_backend(transport, fail_closed=False).evaluate(
            {"tool_name": "t"}
        )

        assert result.allowed is False
        assert result.error is not None

    @pytest.mark.asyncio
    async def test_async_context_manager(self) -> None:
        transport = _mock_transport(_pdp_response(True))
        async with AsyncAuthZENBackend(
            pdp_url="https://pdp.test/access/v1/evaluation",
            pdp_application="test",
            token="tok",
            http_client=httpx.AsyncClient(transport=transport),
        ) as backend:
            assert backend.name == "authzen"
