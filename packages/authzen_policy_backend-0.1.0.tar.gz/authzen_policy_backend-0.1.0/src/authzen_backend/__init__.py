"""authzen-policy-backend — OpenID AuthZEN backend for AI agent governance.

Connect any AuthZEN-compliant Policy Decision Point (PDP) to the
Microsoft Agent Governance Toolkit as an ``ExternalPolicyBackend``.

Quick start::

    from agent_os.policies import PolicyEvaluator
    from authzen_backend import AuthZENBackend

    evaluator = PolicyEvaluator()
    evaluator.add_backend(AuthZENBackend(
        pdp_url="https://pdp.example.com/access/v1/evaluation",
        pdp_application="my-agent-platform",
        token="my-bearer-token",
    ))

    decision = evaluator.evaluate({"tool_name": "file_read", "agent_id": "a1"})

For ARIA-enhanced features (obligations, constraints, advice)::

    from authzen_backend.aria import extract_aria_context

    result = backend.evaluate(context)
    aria = extract_aria_context(result)
    print(aria.obligations, aria.constraints)
"""

from .auth import ClientCredentialsAuth, StaticTokenAuth, TokenProvider
from .backend import AsyncAuthZENBackend, AuthZENBackend, BackendDecision
from .mapper import DEFAULT_MAPPING, FieldMapping, map_context_to_authzen
from .models import (
    AuthZENAction,
    AuthZENRequest,
    AuthZENResource,
    AuthZENResponse,
    AuthZENSubject,
)

__all__ = [
    "DEFAULT_MAPPING",
    "AsyncAuthZENBackend",
    "AuthZENAction",
    "AuthZENBackend",
    "AuthZENRequest",
    "AuthZENResource",
    "AuthZENResponse",
    "AuthZENSubject",
    "BackendDecision",
    "ClientCredentialsAuth",
    "FieldMapping",
    "StaticTokenAuth",
    "TokenProvider",
    "map_context_to_authzen",
]

__version__ = "0.1.0"
