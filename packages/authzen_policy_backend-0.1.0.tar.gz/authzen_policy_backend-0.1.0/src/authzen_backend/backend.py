"""AuthZEN policy backend for the Microsoft Agent Governance Toolkit.

Implements the ``ExternalPolicyBackend`` protocol from ``agent_os.policies``
so that any AuthZEN-compliant PDP can serve as the policy engine for agents
built with the toolkit.

Usage::

    from agent_os.policies import PolicyEvaluator
    from authzen_backend import AuthZENBackend

    evaluator = PolicyEvaluator()
    evaluator.add_backend(AuthZENBackend(
        pdp_url="https://pdp.example.com/access/v1/evaluation",
        pdp_application="my-agent-platform",
        token="my-bearer-token",
    ))

    decision = evaluator.evaluate({"tool_name": "file_read", "agent_id": "a1"})
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any

import httpx

from .auth import ClientCredentialsAuth, StaticTokenAuth, TokenProvider
from .mapper import DEFAULT_MAPPING, FieldMapping, map_context_to_authzen
from .models import AuthZENResponse

logger = logging.getLogger(__name__)


@dataclass
class BackendDecision:
    """Mirrors ``agent_os.policies.backends.BackendDecision``.

    Defined locally so this package can be installed without
    ``agent-os-kernel`` as a hard dependency.  The toolkit's
    ``PolicyEvaluator`` uses structural typing (Protocol), so
    field-level compatibility is sufficient.
    """

    allowed: bool
    action: str = "allow"
    reason: str = ""
    backend: str = ""
    raw_result: Any = None
    evaluation_ms: float = 0.0
    error: str | None = None


def _validate_pdp_url(url: str) -> str:
    """Reject non-HTTPS URLs (HTTP allowed for localhost development)."""
    stripped = url.rstrip("/")
    if not stripped:
        raise ValueError("pdp_url must not be empty.")
    lower = stripped.lower()
    if lower.startswith("https://"):
        return stripped
    if lower.startswith("http://"):
        # Allow plain HTTP only for loopback addresses (development)
        authority = lower[len("http://") :].split("/", 1)[0].split(":")[0]
        if authority in ("localhost", "127.0.0.1", "[::1]"):
            return stripped
        raise ValueError(
            f"pdp_url must use HTTPS in production. "
            f"Plain HTTP is only allowed for localhost. Got: {url!r}"
        )
    raise ValueError(
        f"pdp_url must start with https:// (or http://localhost for dev). Got: {url!r}"
    )


def _resolve_auth(
    token: str | None,
    client_credentials: ClientCredentialsAuth | None,
) -> TokenProvider:
    if client_credentials is not None and token is not None:
        raise ValueError("Provide 'token' or 'client_credentials', not both.")
    if client_credentials is not None:
        return client_credentials
    if token is not None:
        return StaticTokenAuth(token=token)
    raise ValueError("Provide either 'token' or 'client_credentials'.")


def _parse_pdp_response(body: dict[str, Any]) -> AuthZENResponse:
    return AuthZENResponse(
        decision=bool(body.get("decision", False)),
        context=body.get("context", {}),
    )


def _to_backend_decision(response: AuthZENResponse, elapsed_ms: float) -> BackendDecision:
    action = "allow" if response.decision else "deny"
    return BackendDecision(
        allowed=response.decision,
        action=action,
        reason=_extract_reason(response),
        backend="authzen",
        raw_result=response.model_dump(),
        evaluation_ms=elapsed_ms,
    )


def _error_decision(exc: Exception, elapsed_ms: float, fail_closed: bool) -> BackendDecision:
    """Build a BackendDecision for a PDP communication failure.

    When ``fail_closed`` is True, the decision is a hard deny with no
    ``error`` field — the toolkit treats it as authoritative and stops.

    When ``fail_closed`` is False, the ``error`` field is set so the
    toolkit's ``PolicyEvaluator`` skips this backend and tries the next
    one (or falls back to its default action).
    """
    safe_error = _sanitize_error(exc)
    return BackendDecision(
        allowed=False,
        action="deny",
        reason=f"AuthZEN PDP error: {safe_error}",
        backend="authzen",
        evaluation_ms=elapsed_ms,
        error=None if fail_closed else safe_error,
    )


def _sanitize_error(exc: Exception) -> str:
    """Return a safe error description that won't leak URLs, tokens, or internals.

    httpx exceptions can embed full request URLs (which may carry tokens in
    query parameters) and response bodies.  We reduce these to their HTTP
    status code or exception class name.
    """
    if isinstance(exc, httpx.HTTPStatusError):
        return f"HTTP {exc.response.status_code}"
    if isinstance(exc, httpx.TimeoutException):
        return "PDP request timed out"
    if isinstance(exc, httpx.ConnectError):
        return "PDP connection failed"
    return type(exc).__name__


def _extract_reason(response: AuthZENResponse) -> str:
    """Pull a human-readable reason string from the PDP response context."""
    ctx = response.context

    reason_admin = ctx.get("reason_admin")
    if isinstance(reason_admin, dict):
        return str(reason_admin.get("en", next(iter(reason_admin.values()), "")))
    if isinstance(reason_admin, str):
        return reason_admin

    reason_user = ctx.get("reason_user")
    if isinstance(reason_user, dict):
        return str(reason_user.get("en", next(iter(reason_user.values()), "")))
    if isinstance(reason_user, str):
        return reason_user

    return "AuthZEN PDP: access permitted" if response.decision else "AuthZEN PDP: access denied"


class AuthZENBackend:
    """Synchronous AuthZEN policy backend.

    Satisfies the ``ExternalPolicyBackend`` structural protocol via
    ``name`` property and ``evaluate(context) -> BackendDecision``.

    Args:
        pdp_url: Full URL of the AuthZEN evaluation endpoint
            (e.g. ``https://pdp.example.com/access/v1/evaluation``).
        pdp_application: Application identifier for policy scoping.
        token: Static Bearer token for PDP authentication.
            Mutually exclusive with ``client_credentials``.
        client_credentials: A :class:`ClientCredentialsAuth` instance
            for dynamic token acquisition.  Mutually exclusive with ``token``.
        timeout: HTTP timeout in seconds.
        default_resource_type: Fallback ``resource.type`` when the toolkit
            context does not include one.
        default_subject_type: Fallback ``subject.type``.
        mapping: Custom field mapping overrides.
        fail_closed: If ``True`` (default), PDP errors result in an
            authoritative deny.  If ``False``, errors are signalled via
            the ``error`` field so the toolkit can try the next backend.
        http_client: Optional pre-configured ``httpx.Client``.
            When provided, the caller owns its lifecycle.
    """

    def __init__(
        self,
        pdp_url: str,
        pdp_application: str,
        *,
        token: str | None = None,
        client_credentials: ClientCredentialsAuth | None = None,
        timeout: float = 5.0,
        default_resource_type: str = "mcp_tool",
        default_subject_type: str = "ai_agent",
        mapping: FieldMapping = DEFAULT_MAPPING,
        fail_closed: bool = True,
        http_client: httpx.Client | None = None,
    ) -> None:
        self._pdp_url = _validate_pdp_url(pdp_url)
        self._pdp_application = pdp_application
        self._default_resource_type = default_resource_type
        self._default_subject_type = default_subject_type
        self._mapping = mapping
        self._fail_closed = fail_closed
        self._auth: TokenProvider = _resolve_auth(token, client_credentials)
        self._client = http_client or httpx.Client(timeout=timeout)
        self._owns_client = http_client is None

    @property
    def name(self) -> str:
        return "authzen"

    def evaluate(self, context: dict[str, Any]) -> BackendDecision:
        """Evaluate the context against an AuthZEN PDP."""
        start = time.monotonic()
        try:
            request = map_context_to_authzen(
                context,
                pdp_application=self._pdp_application,
                default_resource_type=self._default_resource_type,
                default_subject_type=self._default_subject_type,
                mapping=self._mapping,
            )
            bearer = self._auth.get_token(self._client)
            resp = self._client.post(
                self._pdp_url,
                json=request.model_dump(),
                headers={"Authorization": f"Bearer {bearer}"},
            )
            resp.raise_for_status()
            authzen_resp = _parse_pdp_response(resp.json())
            return _to_backend_decision(authzen_resp, _elapsed(start))
        except Exception as exc:
            logger.error("AuthZEN PDP evaluation failed: %s", exc)
            return _error_decision(exc, _elapsed(start), self._fail_closed)

    def close(self) -> None:
        """Release the underlying HTTP client if this backend owns it."""
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> AuthZENBackend:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class AsyncAuthZENBackend:
    """Asynchronous AuthZEN policy backend.

    Same interface as :class:`AuthZENBackend` but uses ``httpx.AsyncClient``
    for non-blocking PDP calls.  Suitable for ``AsyncPolicyEvaluator``.

    Args:
        See :class:`AuthZENBackend` — identical parameters except
        ``http_client`` accepts ``httpx.AsyncClient``.
    """

    def __init__(
        self,
        pdp_url: str,
        pdp_application: str,
        *,
        token: str | None = None,
        client_credentials: ClientCredentialsAuth | None = None,
        timeout: float = 5.0,
        default_resource_type: str = "mcp_tool",
        default_subject_type: str = "ai_agent",
        mapping: FieldMapping = DEFAULT_MAPPING,
        fail_closed: bool = True,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._pdp_url = _validate_pdp_url(pdp_url)
        self._pdp_application = pdp_application
        self._default_resource_type = default_resource_type
        self._default_subject_type = default_subject_type
        self._mapping = mapping
        self._fail_closed = fail_closed
        self._auth: TokenProvider = _resolve_auth(token, client_credentials)
        self._client = http_client or httpx.AsyncClient(timeout=timeout)
        self._owns_client = http_client is None

    @property
    def name(self) -> str:
        return "authzen"

    async def evaluate(self, context: dict[str, Any]) -> BackendDecision:
        """Evaluate the context against an AuthZEN PDP (async)."""
        start = time.monotonic()
        try:
            request = map_context_to_authzen(
                context,
                pdp_application=self._pdp_application,
                default_resource_type=self._default_resource_type,
                default_subject_type=self._default_subject_type,
                mapping=self._mapping,
            )
            bearer = await self._auth.get_token_async(self._client)
            resp = await self._client.post(
                self._pdp_url,
                json=request.model_dump(),
                headers={"Authorization": f"Bearer {bearer}"},
            )
            resp.raise_for_status()
            authzen_resp = _parse_pdp_response(resp.json())
            return _to_backend_decision(authzen_resp, _elapsed(start))
        except Exception as exc:
            logger.error("AuthZEN PDP evaluation failed: %s", exc)
            return _error_decision(exc, _elapsed(start), self._fail_closed)

    async def close(self) -> None:
        """Release the underlying HTTP client if this backend owns it."""
        if self._owns_client:
            await self._client.aclose()

    async def __aenter__(self) -> AsyncAuthZENBackend:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()


def _elapsed(start: float) -> float:
    return (time.monotonic() - start) * 1000
