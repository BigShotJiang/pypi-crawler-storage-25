"""Data models for AuthZEN request/response mapping.

These models follow the OpenID AuthZEN Authorization API 1.0 specification
for access evaluation requests and responses.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class AuthZENSubject(BaseModel):
    """AuthZEN subject — the entity requesting access."""

    model_config = ConfigDict(frozen=True)

    type: str
    id: str
    properties: dict[str, Any] = Field(default_factory=dict)


class AuthZENAction(BaseModel):
    """AuthZEN action — the operation being performed."""

    model_config = ConfigDict(frozen=True)

    name: str
    properties: dict[str, Any] = Field(default_factory=dict)


class AuthZENResource(BaseModel):
    """AuthZEN resource — the target of the action."""

    model_config = ConfigDict(frozen=True)

    type: str
    id: str
    properties: dict[str, Any] = Field(default_factory=dict)


class AuthZENRequest(BaseModel):
    """OpenID AuthZEN 1.0 access evaluation request."""

    model_config = ConfigDict(frozen=True)

    subject: AuthZENSubject
    action: AuthZENAction
    resource: AuthZENResource
    context: dict[str, Any] = Field(default_factory=dict)


class AuthZENResponse(BaseModel):
    """OpenID AuthZEN 1.0 access evaluation response.

    The ``context`` field carries PDP-specific detail: reasons, obligations,
    constraints, advice, and provider-specific extensions.
    """

    model_config = ConfigDict(frozen=True)

    decision: bool
    context: dict[str, Any] = Field(default_factory=dict)
