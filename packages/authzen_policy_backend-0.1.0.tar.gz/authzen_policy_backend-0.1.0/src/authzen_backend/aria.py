"""ARIA-enhanced AuthZEN backend extensions.

When connected to an EmpowerNow ARIA PDP, the standard AuthZEN response
carries rich governance context that generic AuthZEN backends ignore.
This module provides helpers to extract and work with ARIA-specific fields:

- **Obligations** — actions the caller must perform (step-up auth, logging, etc.)
- **Constraints** — parameter-level restrictions on tool invocation
- **Advice** — structured denial guidance with remediation suggestions
- **Delegation context** — user-bound agent and delegator information
- **Budget context** — remaining budget, spend attribution
- **Receipt correlation** — decision IDs for linking to signed receipts
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .backend import BackendDecision


@dataclass
class Obligation:
    """A governance obligation returned by the ARIA PDP."""

    id: str
    type: str = ""
    attributes: dict[str, Any] = field(default_factory=dict)


@dataclass
class Constraint:
    """A parameter-level constraint on tool invocation."""

    field_name: str = ""
    operator: str = ""
    value: Any = None
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class DenialAdvice:
    """Structured denial guidance from the ARIA PDP."""

    message: str = ""
    severity: str = ""
    remediation: str = ""
    action_code: str = ""
    action_params: dict[str, Any] = field(default_factory=dict)


@dataclass
class ARIADecisionContext:
    """Extracted ARIA-specific governance context from a PDP decision.

    This is the rich context that distinguishes an ARIA PDP from a
    generic AuthZEN PDP.  Access it via :func:`extract_aria_context`.
    """

    decision_id: str = ""
    obligations: list[Obligation] = field(default_factory=list)
    constraints: list[Constraint] = field(default_factory=list)
    advice: list[DenialAdvice] = field(default_factory=list)
    requires_approval: bool = False
    reason_admin: str = ""
    reason_user: str = ""
    raw_context: dict[str, Any] = field(default_factory=dict)


def extract_aria_context(decision: BackendDecision) -> ARIADecisionContext:
    """Extract ARIA-specific governance context from a BackendDecision.

    If the ``raw_result`` was produced by an :class:`AuthZENBackend` call
    to an ARIA PDP, the ``context`` field contains obligations, constraints,
    advice, and other ARIA extensions.  This function parses them into
    typed dataclasses.

    Works gracefully with non-ARIA PDPs: all fields default to empty.

    Args:
        decision: A ``BackendDecision`` returned by ``AuthZENBackend.evaluate``.

    Returns:
        Parsed ARIA governance context.
    """
    raw = decision.raw_result
    if not isinstance(raw, dict):
        return ARIADecisionContext()

    ctx: dict[str, Any] = raw.get("context", {})
    if not isinstance(ctx, dict):
        return ARIADecisionContext()

    obligations = [
        Obligation(
            id=str(o.get("id", "")),
            type=str(o.get("type", "")),
            attributes=dict(o.get("attributes", {})),
        )
        for o in ctx.get("obligations", [])
        if isinstance(o, dict)
    ]

    constraints = [
        Constraint(
            field_name=str(c.get("field", "")),
            operator=str(c.get("operator", "")),
            value=c.get("value"),
            raw=dict(c),
        )
        for c in ctx.get("constraints", [])
        if isinstance(c, dict)
    ]

    advice_items: list[DenialAdvice] = []
    user_advice = ctx.get("user_advice")
    if isinstance(user_advice, dict):
        advice_items.append(
            DenialAdvice(
                message=str(user_advice.get("message", "")),
                severity=str(user_advice.get("severity", "")),
                remediation=str(user_advice.get("remediation", "")),
                action_code=str(user_advice.get("action_code", "")),
                action_params=dict(user_advice.get("action_params", {})),
            )
        )
    for a in ctx.get("advice", []):
        if isinstance(a, dict):
            advice_items.append(
                DenialAdvice(
                    message=str(a.get("message", a.get("id", ""))),
                    severity=str(a.get("severity", "")),
                    remediation=str(a.get("remediation", "")),
                )
            )

    reason_admin = ""
    ra = ctx.get("reason_admin")
    if isinstance(ra, dict):
        reason_admin = str(ra.get("en", next(iter(ra.values()), "")))
    elif isinstance(ra, str):
        reason_admin = ra

    reason_user = ""
    ru = ctx.get("reason_user")
    if isinstance(ru, dict):
        reason_user = str(ru.get("en", next(iter(ru.values()), "")))
    elif isinstance(ru, str):
        reason_user = ru

    return ARIADecisionContext(
        decision_id=str(ctx.get("decision_id", ctx.get("id", ""))),
        obligations=obligations,
        constraints=constraints,
        advice=advice_items,
        requires_approval=bool(ctx.get("requires_approval", False)),
        reason_admin=reason_admin,
        reason_user=reason_user,
        raw_context=ctx,
    )
