"""Map Microsoft Agent Governance Toolkit execution contexts to AuthZEN requests.

The toolkit passes a flat ``dict[str, Any]`` context to policy backends.
This module transforms that flat context into a structured AuthZEN
evaluation request (subject / action / resource / context).

Field mapping is configurable so adopters can adapt to their own PDP
conventions without forking the package.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .models import AuthZENAction, AuthZENRequest, AuthZENResource, AuthZENSubject


@dataclass(frozen=True)
class FieldMapping:
    """Controls how toolkit context keys map to AuthZEN request fields.

    Override individual fields to match your PDP's expected vocabulary.
    Unmapped toolkit context keys are forwarded into ``AuthZENRequest.context``.
    """

    # -- subject --
    agent_id_key: str = "agent_id"
    user_id_key: str = "user_id"
    delegator_key: str = "delegator"

    # -- action --
    tool_name_key: str = "tool_name"
    action_key: str = "action"

    # -- resource --
    resource_type_key: str = "resource_type"
    resource_id_key: str = "resource_id"

    # -- context --
    pdp_application_key: str = "pdp_application"

    _consumed_keys: frozenset[str] = field(default=frozenset(), repr=False)

    def __post_init__(self) -> None:
        consumed = frozenset(
            {
                self.agent_id_key,
                self.user_id_key,
                self.delegator_key,
                self.tool_name_key,
                self.action_key,
                self.resource_type_key,
                self.resource_id_key,
                self.pdp_application_key,
            }
        )
        object.__setattr__(self, "_consumed_keys", consumed)

    @property
    def consumed_keys(self) -> frozenset[str]:
        """Context keys consumed by the mapper (excluded from forwarded context)."""
        return self._consumed_keys


DEFAULT_MAPPING = FieldMapping()


def map_context_to_authzen(
    context: dict[str, Any],
    *,
    pdp_application: str,
    default_resource_type: str = "mcp_tool",
    default_subject_type: str = "ai_agent",
    mapping: FieldMapping = DEFAULT_MAPPING,
) -> AuthZENRequest:
    """Convert a toolkit execution context to an AuthZEN evaluation request.

    Args:
        context: Flat context dict from the Agent Governance Toolkit.
        pdp_application: Application identifier for policy scoping.
        default_resource_type: Fallback ``resource.type`` when not in context.
        default_subject_type: Fallback ``subject.type`` when not in context.
        mapping: Field-name overrides.

    Returns:
        A fully-formed ``AuthZENRequest`` ready for PDP submission.
    """
    agent_id = context.get(mapping.agent_id_key, "anonymous")
    user_id = context.get(mapping.user_id_key)
    tool_name = context.get(mapping.tool_name_key, "unknown")
    action_name = context.get(mapping.action_key, tool_name)
    resource_type = context.get(mapping.resource_type_key, default_resource_type)
    resource_id = context.get(mapping.resource_id_key, tool_name)

    subject_id = _normalize_subject_id(agent_id, default_subject_type)
    subject_props: dict[str, Any] = {}
    if user_id:
        subject_props["bound_to_user_id"] = user_id
    delegator = context.get(mapping.delegator_key)
    if delegator:
        subject_props["delegator"] = delegator

    operation_ref_id = f"op:tool:{tool_name}"

    extra_context: dict[str, Any] = {
        k: v for k, v in context.items() if k not in mapping.consumed_keys
    }

    return AuthZENRequest(
        subject=AuthZENSubject(
            type=default_subject_type,
            id=subject_id,
            properties=subject_props,
        ),
        action=AuthZENAction(
            name=action_name,
            properties={
                "resource_type": resource_type,
                "operation_ref_id": operation_ref_id,
            },
        ),
        resource=AuthZENResource(
            type=resource_type,
            id=resource_id,
        ),
        context={
            "pdp_application": pdp_application,
            **extra_context,
        },
    )


def _normalize_subject_id(raw_id: str, subject_type: str) -> str:
    """Ensure subject IDs follow ARN-style ``auth:{type}:{provider}:{id}``."""
    if raw_id.startswith("auth:"):
        return raw_id
    entity_type = "agent" if subject_type == "ai_agent" else "account"
    return f"auth:{entity_type}:agentmesh:{raw_id}"
