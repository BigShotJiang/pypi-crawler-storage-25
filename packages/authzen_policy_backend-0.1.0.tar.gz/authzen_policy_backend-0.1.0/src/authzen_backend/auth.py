"""Token acquisition for PDP authentication.

Supports two strategies:

1. **Client credentials** — the backend itself is an OAuth client and
   obtains tokens from an IdP using the ``client_credentials`` grant.
2. **Static token** — a pre-provisioned Bearer token is used directly
   (useful for development, service accounts, or token-exchange flows
   handled outside this package).
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

import httpx


@runtime_checkable
class TokenProvider(Protocol):
    """Protocol for token acquisition strategies.

    Both sync and async methods must be implemented.  The ``client``
    argument is provided so the provider can reuse the caller's
    connection pool for token endpoint calls.
    """

    def get_token(self, client: httpx.Client) -> str: ...
    async def get_token_async(self, client: httpx.AsyncClient) -> str: ...


@dataclass
class TokenCache:
    """Holds a cached access token and its expiry."""

    access_token: str = ""
    expires_at: float = 0.0

    @property
    def valid(self) -> bool:
        return bool(self.access_token) and time.time() < self.expires_at


@dataclass
class ClientCredentialsAuth:
    """Acquire tokens via OAuth 2.0 client_credentials grant.

    Args:
        token_endpoint: Full URL of the IdP token endpoint.
        client_id: OAuth client identifier registered with the IdP.
        client_secret: Client secret.
        audience: Requested audience / resource (PDP audience string).
        extra_params: Additional form parameters for the token request.
    """

    token_endpoint: str
    client_id: str
    client_secret: str = field(repr=False)
    audience: str = ""
    extra_params: dict[str, str] = field(default_factory=dict)
    _cache: TokenCache = field(default_factory=TokenCache, repr=False)

    def get_token(self, client: httpx.Client) -> str:
        """Return a valid access token, refreshing if expired."""
        if self._cache.valid:
            return self._cache.access_token
        return self._refresh(client)

    async def get_token_async(self, client: httpx.AsyncClient) -> str:
        """Async variant of :meth:`get_token`."""
        if self._cache.valid:
            return self._cache.access_token
        return await self._refresh_async(client)

    def _refresh(self, client: httpx.Client) -> str:
        data = self._build_form()
        resp = client.post(self.token_endpoint, data=data)
        resp.raise_for_status()
        return self._parse_token_response(resp.json())

    async def _refresh_async(self, client: httpx.AsyncClient) -> str:
        data = self._build_form()
        resp = await client.post(self.token_endpoint, data=data)
        resp.raise_for_status()
        return self._parse_token_response(resp.json())

    _RESERVED_FORM_KEYS: frozenset[str] = frozenset({"grant_type", "client_id", "client_secret"})

    def _build_form(self) -> dict[str, str]:
        overrides = self.extra_params.keys() & self._RESERVED_FORM_KEYS
        if overrides:
            raise ValueError(
                f"extra_params must not override OAuth core fields: {sorted(overrides)}"
            )
        form: dict[str, str] = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        }
        if self.audience:
            form["audience"] = self.audience
        form.update(self.extra_params)
        return form

    def _parse_token_response(self, body: dict[str, Any]) -> str:
        token: str = body["access_token"]
        expires_in = int(body.get("expires_in", 3600))
        self._cache = TokenCache(
            access_token=token,
            expires_at=time.time() + expires_in - 30,
        )
        return token


@dataclass
class StaticTokenAuth:
    """Use a pre-provisioned Bearer token.

    Args:
        token: The Bearer token string.
    """

    token: str = field(repr=False)

    def get_token(self, client: httpx.Client) -> str:
        return self.token

    async def get_token_async(self, client: httpx.AsyncClient) -> str:
        return self.token
