"""LlamaIndex integration for ForceField AI security.

Re-exports the ForceField callback handler for use in LlamaIndex pipelines.

Usage::

    from llama_index.core import Settings
    from llama_index_forcefield import ForceFieldCallbackHandler

    handler = ForceFieldCallbackHandler(sensitivity="high")
    Settings.callback_manager.add_handler(handler)
"""

from forcefield.integrations.llamaindex import (
    ForceFieldCallbackHandler,
    PromptBlockedError,
)

__all__ = ["ForceFieldCallbackHandler", "PromptBlockedError"]
__version__ = "0.1.0"
