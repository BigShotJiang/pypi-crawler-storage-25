import socket
import ssl
import sys


def Get_ssl(host, port=443, timeout=2, protocol="HTTP/1.0"):
    try:
        sock = socket.create_connection((host, port), timeout)
        # Create Connection for host and port with use timeout
        context = ssl.create_default_context()
        # Create Context with using defaut setting
        ssock = context.wrap_socket(sock, server_hostname=host)
        # Wrap Socket to server host name
        ssock.sendall(f"GET / {protocol}\r\nHost:{host}\r\n\r\n".encode("utf-8"))
        data = ssock.recv(4096)
        print(data.decode(errors="replace"))
        ssock.close()
    except Exception as e:
        print(e)
