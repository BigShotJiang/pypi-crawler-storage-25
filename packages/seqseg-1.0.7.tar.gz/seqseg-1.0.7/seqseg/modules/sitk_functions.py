# Functions to bind SITK functionality

import os

import SimpleITK as sitk
import numpy as np


def read_image(file_dir_image):
    """
    Read image from file
    Args:
        file_dir_image: image directory
    Returns:
        SITK image reader
    """
    file_reader = sitk.ImageFileReader()
    file_reader.SetFileName(file_dir_image)
    file_reader.ReadImageInformation()
    return file_reader


def create_new(file_reader, PixelID=None):
    """
    Create new SITK image with same formating as another
    Args:
        file_reader: reader from another image, or image object
    Returns:
        SITK image
    """
    if PixelID:
        pix_id = PixelID
    else:
        pix_id = file_reader.GetPixelID()

    # check if reader or image object
    if isinstance(file_reader, sitk.ImageFileReader):
        result_img = sitk.Image(file_reader.GetSize(), pix_id,
                                file_reader.GetNumberOfComponents())
    else:
        result_img = sitk.Image(file_reader.GetSize(), pix_id)
    result_img.SetSpacing(file_reader.GetSpacing())
    result_img.SetOrigin(file_reader.GetOrigin())
    result_img.SetDirection(file_reader.GetDirection())

    return result_img


def copy_settings(img, ref_img):

    img.SetSpacing(ref_img.GetSpacing())
    img.SetOrigin(ref_img.GetOrigin())
    img.SetDirection(ref_img.GetDirection())

    return img


def resample_to_spacing(image, new_spacing, is_label=False):
    """
    Resample a SITK image to a target spacing while preserving physical extent.

    Args:
        image (sitk.Image): Input image.
        new_spacing (iterable): Target spacing [sx, sy, sz].
        is_label (bool): Use nearest-neighbor interpolation for labels.
    """
    orig_size = np.array(image.GetSize(), dtype=np.int64)
    orig_spacing = np.array(image.GetSpacing(), dtype=np.float64)
    target_spacing = np.array(new_spacing, dtype=np.float64)

    new_size = np.maximum(
        1,
        np.rint(orig_size * (orig_spacing / target_spacing)).astype(np.int64)
    ).tolist()

    resample = sitk.ResampleImageFilter()
    resample.SetOutputSpacing(target_spacing.tolist())
    resample.SetSize([int(s) for s in new_size])
    resample.SetOutputOrigin(image.GetOrigin())
    resample.SetOutputDirection(image.GetDirection())
    resample.SetTransform(sitk.Transform())
    resample.SetDefaultPixelValue(0)
    if is_label:
        resample.SetInterpolator(sitk.sitkNearestNeighbor)
    else:
        resample.SetInterpolator(sitk.sitkLinear)
    return resample.Execute(image)


def parse_resample_spacing_arg(spacing_arg):
    """
    Convert CLI ``--resample_spacing`` values to an (sx, sy, sz) tuple.

    Parameters
    ----------
    spacing_arg : list[float] | None
        From argparse ``nargs='+'``. None or empty means disabled.

    Returns
    -------
    tuple[float, float, float] | None
        SimpleITK spacing order, or None if resampling is disabled.
    """
    if not spacing_arg:
        return None
    if len(spacing_arg) == 1:
        s = float(spacing_arg[0])
        return (s, s, s)
    if len(spacing_arg) == 3:
        return tuple(float(x) for x in spacing_arg)
    raise ValueError(
        '--resample_spacing expects 1 value (isotropic) or 3 values '
        f'(sx, sy, sz in SimpleITK order); got {len(spacing_arg)} values.'
    )


def maybe_resample_volume_paths(
    dir_image,
    dir_seg,
    target_spacing,
    out_dir,
    stem,
    img_ext,
):
    """
    Optionally resample the case image (and truth seg) to ``target_spacing``.

    Writes under ``out_dir`` only; original dataset paths are not modified.

    Parameters
    ----------
    dir_image : str
        Path to the input image volume.
    dir_seg : str | None
        Optional path to a label/truth volume aligned with the image.
    target_spacing : tuple[float, float, float] | None
        If None, returns ``(dir_image, dir_seg)`` unchanged.
    out_dir : str
        Existing directory for resampled outputs.
    stem : str
        Case stem used in output filenames.
    img_ext : str
        File extension including dot (e.g. ``.nii.gz``).

    Returns
    -------
    tuple[str, str | None]
        ``(dir_image_out, dir_seg_out)`` paths to use for the pipeline.
    """
    if target_spacing is None:
        return dir_image, dir_seg

    if any(s <= 0 for s in target_spacing):
        raise ValueError(
            f'target_spacing must be positive in all dimensions; got {target_spacing}'
        )

    img_in = sitk.ReadImage(dir_image)
    orig_sp = img_in.GetSpacing()
    print(
        f'Resampling input image to spacing {target_spacing} '
        f'(original spacing {orig_sp})'
    )
    img_out = resample_to_spacing(img_in, target_spacing, is_label=False)
    out_image_path = os.path.join(out_dir, f'{stem}_resampled{img_ext}')
    write_image(img_out, out_image_path)

    out_seg_path = dir_seg
    if dir_seg and isinstance(dir_seg, str) and os.path.isfile(dir_seg):
        seg_in = sitk.ReadImage(dir_seg)
        print(
            f'Resampling truth segmentation to spacing {target_spacing} '
            f'(original spacing {seg_in.GetSpacing()})'
        )
        seg_out = resample_to_spacing(seg_in, target_spacing, is_label=True)
        out_seg_path = os.path.join(out_dir, f'{stem}_truth_resampled{img_ext}')
        write_image(seg_out, out_seg_path)

    return out_image_path, out_seg_path


def write_image(image, outputImageFileName):
    """
    Write image to file
    Args:
        SITK image, filename
    Returns:
        image file
    """
    writer = sitk.ImageFileWriter()
    writer.SetFileName(outputImageFileName)
    writer.Execute(image)


def validate_potential_branches_image_bounds(image, potential_branches,
                                             case=None, image_path=None):
    """
    Ensure all tracing seed points (old and initial) lie inside the image grid.

    Uses continuous index vs image size so physical points are rejected when
    they map outside [0, size[d]) in any dimension.

    Parameters
    ----------
    image : sitk.Image
        Reference volume (same geometry as the image used for tracing).
    potential_branches : list
        Initialization steps from seqseg.modules.initialization; each dict must
        contain 'old point' and 'point' (3D physical coordinates).
    case : str, optional
        Case name for error messages.
    image_path : str, optional
        Path to the image file for error messages.

    Raises
    ------
    ValueError
        If any seed is out of bounds or not 3D (for a 3D image).
    """
    if not potential_branches:
        return

    dim = image.GetDimension()
    size = image.GetSize()
    failures = []

    for bi, step in enumerate(potential_branches):
        for role, key in (("old point", "old point"), ("initial point", "point")):
            pt = step[key]
            arr = np.asarray(pt, dtype=float).ravel()
            if arr.size != dim:
                failures.append(
                    (bi, role, tuple(arr.tolist()),
                     f"expected {dim} coordinates, got length {arr.size}")
                )
                continue
            phys = tuple(arr.tolist())
            cix = image.TransformPhysicalPointToContinuousIndex(phys)
            if any(cix[d] < 0 or cix[d] >= size[d] for d in range(dim)):
                failures.append(
                    (bi, role, phys,
                     tuple(round(float(cix[i]), 4) for i in range(dim)))
                )

    if not failures:
        return

    lines = []
    for bi, role, phys, detail in failures:
        lines.append(f"  branch {bi} {role}: physical={phys!r} ({detail})")

    prefix_parts = []
    if case is not None:
        prefix_parts.append(f"case {case!r}")
    if image_path is not None:
        prefix_parts.append(f"image {image_path!r}")
    prefix = (" (" + ", ".join(prefix_parts) + ")") if prefix_parts else ""

    raise ValueError(
        f"Seed point(s) lie outside the image volume bounds{prefix}. "
        f"Image size={size!r}, spacing={image.GetSpacing()!r}, "
        f"origin={image.GetOrigin()!r}.\n" + "\n".join(lines)
    )


def keep_component_seeds(image, seeds):
    """
    Keep only the component containing the seed point
    Args:
        SITK image, seed point pointing to point in vessel of interest
        seed(s): location of seeds; list of np arrays (one or multiple points)
    """
    # create list of index values for each seed
    index_seeds = []
    for i in range(len(seeds)):
        index_seeds.append(image
                           .TransformPhysicalPointToIndex(seeds[i].tolist()))
    print(f"Index of seeds: {index_seeds}")

    # create a new image with only the labels of interest
    labelImage = remove_other_vessels(image, index_seeds)

    return labelImage


def remove_other_vessels(image, seed):
    """
    Remove all labelled vessels except the one of interest
    Args:
        SITK image, seed point pointing to point in vessel of interest
        seed(s): location of seed; either list (single point)
        or list of lists (multiple points)
    Returns:
        binary image file (either 0 or 1)
    """

    ccimage = sitk.ConnectedComponent(image)
    size = ccimage.GetSize()

    # Normalize input to a list of 3D tuple indices.
    if isinstance(seed, (tuple, list, np.ndarray)) and len(seed) == 3 and \
       all(isinstance(v, (int, np.integer)) for v in seed):
        seed_list = [tuple(int(v) for v in seed)]
    elif isinstance(seed, (tuple, list, np.ndarray)):
        seed_list = [tuple(int(v) for v in s) for s in seed]
    else:
        raise TypeError("seed must be a 3D index or a list of 3D indices")

    labels_seeds = []
    for s in seed_list:
        # Skip out-of-bounds seeds instead of crashing or mis-indexing.
        if any(s[d] < 0 or s[d] >= size[d] for d in range(3)):
            continue
        label = int(ccimage[s])
        # Ignore background labels for multi-seed union logic.
        if label > 0:
            labels_seeds.append(label)

    labels_seeds = sorted(set(labels_seeds))
    print(f"Labels at seed indices: {labels_seeds}")

    if not labels_seeds:
        # Fallback: keep largest connected component when no seed lands
        # in vessel foreground.
        relabeled = sitk.RelabelComponent(ccimage, sortByObjectSize=True)
        labelImage = sitk.BinaryThreshold(relabeled,
                                          lowerThreshold=1,
                                          upperThreshold=1)
    else:
        # Create a new image with union of all seed-connected labels.
        labelImage = sitk.BinaryThreshold(ccimage,
                                          lowerThreshold=labels_seeds[0],
                                          upperThreshold=labels_seeds[0])
        for label in labels_seeds[1:]:
            labelImage = labelImage + sitk.BinaryThreshold(
                ccimage,
                lowerThreshold=label,
                upperThreshold=label
            )

    return labelImage


def connected_comp_info(original_seg, print_condition=False):
    """
    Print info on the component being kept
    """
    removed_seg = sitk.ConnectedComponent(original_seg)
    stats = sitk.LabelIntensityStatisticsImageFilter()
    stats.Execute(removed_seg, original_seg)
    means = []
    sizes = []

    for label in stats.GetLabels():
        if print_condition:
            print("Label: {0} -> Mean: {1} Size: {2}"
                  .format(label, stats.GetMean(label),
                          stats.GetPhysicalSize(label)))
        means.append(stats.GetMean(label))
        sizes.append(stats.GetPhysicalSize(label))
    return stats.GetLabels(), means, sizes


def extract_volume(reader_im, index_extract, size_extract):
    """
    Function to extract a smaller volume from a larger one using sitk
    args:
        reader_im: sitk image reader
        index_extract: the index of the lower corner for extraction
        size_extract: number of voxels to extract in each direction
    return:
        new_img: sitk image volume
    """
    reader_im.SetExtractIndex(index_extract)
    reader_im.SetExtractSize(size_extract)
    new_img = reader_im.Execute()

    return new_img


def map_to_image(point, radius, size_volume, origin_im, spacing_im,
                 size_im, min_resolution_any_dim=5, direction_im=None):
    """
    Function to map a point and radius to volume metrics
    Also checks if sub-volume is within global

    Note: only corrects if less than (1/3) of the subvolume
    is outside the global volume. This can be changed
    -> less means it will fail sooner when approaching the
    global volume border

    args:
        point: point of volume center (physical coordinates)
        radius: radius at that point
        size_volume: multiple of radius equal the intended
            volume size
        origin_im: image origin
        spacing_im: image spacing
        size_im: image size in voxels (per dimension)
        min_resolution_any_dim: minimum voxel count required along any
            dimension; the radius is grown by 5% per iteration until met
        direction_im: image direction cosines as either a 3x3 array or a
            flat 9-element sequence (SimpleITK ``GetDirection()`` order).
            If ``None``, an identity direction is assumed (legacy
            behavior). Passing the actual direction is required for
            images whose direction matrix is not diagonal (e.g. oblique
            acquisitions); otherwise the extraction index will be wrong.
    return:
        size_extract: number of voxels to extract in each dim
        index_extract: index for sitk volume extraction
        border: boolean, if subvolume is on global border
    """
    point = np.asarray(point, dtype=float).ravel()
    origin_im = np.asarray(origin_im, dtype=float).ravel()
    spacing_im = np.asarray(spacing_im, dtype=float).ravel()
    dim = origin_im.size

    # Build the inverse of the physical-to-index transform. SimpleITK
    # convention: physical = origin + D @ diag(spacing) @ index, so
    # index = diag(1/spacing) @ D^{-1} @ (physical - origin). For an
    # orthonormal direction D^{-1} == D.T, but use the true inverse so
    # we remain robust to mild numerical noise.
    if direction_im is None:
        d_inv = np.eye(dim)
    else:
        d_mat = np.asarray(direction_im, dtype=float).reshape(dim, dim)
        d_inv = np.linalg.inv(d_mat)

    min_res = 0
    border = False

    while min_res < min_resolution_any_dim:
        # Voxel extent of the requested physical box, independent of the
        # image direction (extraction is always axis-aligned in index
        # space).
        size_extract = np.ceil(size_volume*radius/spacing_im).astype(int)
        # Continuous index of the box center via the proper inverse
        # direction transform, then step back the same physical
        # half-extent the original code used. For an identity direction
        # this collapses to round((point - origin - (size_volume/2)*r) /
        # spacing), i.e. it reproduces the legacy result exactly.
        center_cidx = (d_inv @ (point - origin_im)) / spacing_im
        half_extent_idx = (size_volume / 2.0) * radius / spacing_im
        index_extract = np.rint(center_cidx - half_extent_idx).astype(int)
        radius *= 1.05
        min_res = size_extract.min()
        print(f"Subvolume resolution: {size_extract}, Radius: {radius:.3f}")

    end_bounds = index_extract+size_extract

    for i, ind in enumerate(np.logical_and(end_bounds > size_im,
                                           (end_bounds - size_im)
                                           < 1/3 * size_extract)):
        if ind:
            print('\nsub-volume outside global volume, correcting\n')
            size_extract[i] = size_im[i] - index_extract[i]
            border = True

    for i, ind in enumerate(np.logical_and(index_extract < np.zeros(3),
                                           (np.zeros(3) - index_extract)
                                           < 1/3 * size_extract)):
        if ind:
            print('\nsub-volume outside global volume, correcting\n')
            index_extract[i] = 0
            border = True

    return size_extract.tolist(), index_extract.tolist(), border


def import_image(image_dir):
    """
    Function to import image via sitk
    args:
        file_dir_image: image directory
    return:
        reader_img: sitk image volume reader
        origin_im: image origin coordinates
        size_im: image size
        spacing_im: image spacing
    """
    reader_im = read_image(image_dir)
    origin_im = np.array(list(reader_im.GetOrigin()))
    size_im = np.array(list(reader_im.GetSize()))
    spacing_im = np.array(list(reader_im.GetSpacing()))

    return reader_im, origin_im, size_im, spacing_im


def sitk_to_numpy(Image):
    """
    Function to convert sitk image to numpy array
    args:
        Image: sitk image
    return:
        np_array: numpy array
    """
    np_array = sitk.GetArrayFromImage(Image)

    return np_array


def numpy_to_sitk(numpy, file_reader=None):
    """
    Function to convert numpy array to sitk image
    args:
        numpy: numpy array
        file_reader: sitk image reader
    return:
        Image: sitk image
    """

    Image = sitk.GetImageFromArray(numpy)

    if file_reader:

        Image.SetSpacing(file_reader.GetSpacing())
        Image.SetOrigin(file_reader.GetOrigin())
        Image.SetDirection(file_reader.GetDirection())

    return Image


def distance_map_from_seg(sitk_img):
    """
    Function to calculate distance map
    Inside is negative, outside is positive

    args:
        sitk_img: sitk image
    return:
        distance_map: sitk image
    """
    distance_map = sitk.SignedMaurerDistanceMap(sitk_img,
                                                squaredDistance=False,
                                                useImageSpacing=True)
    return distance_map


def check_seg_border(size_extract, index_extract,
                     predicted_vessel, size_im):
    """
    This function takes in the size and index of the extracted volume,
    its segmentation and the size of the global image

    This function is only called if the subvolume is on the global border
    This function returns true if there is at least one vessel voxel on the
    border of the global volume

    This function:

    1. Finds the face(s) of the subvolume that are on the border of
       the global volume
    2. Extracts the part of the subvolume segmentation that corresponds
       to those faces
    3. Checks if there is a vessel voxel in that part of the segmentation
    4. Returns true if there is a vessel voxel on the border
       of the global volume

    args:
        size_extract: list of ints, size of the extracted volume
        index_extract: list of ints, index of the lower corner for extraction
        predicted_vessel: sitk volume, segmentation of the extracted volume
        size_im: list of ints, size of the global volume
    return:
        border: boolean, if there exists a vessel voxel on the border
                of the global volume
    """

    # Find the faces of the subvolume that are on the border
    # of the global volume
    faces = []
    for i in range(3):
        if index_extract[i] == 0:
            faces.append(i)
        if index_extract[i] + size_extract[i] == size_im[i]:
            faces.append(i+3)

    # Extract the part of the subvolume segmentation that corresponds
    # to those faces
    seg_np = sitk_to_numpy(predicted_vessel).transpose(2, 1, 0)
    border = False
    for face in faces:
        if face == 0:
            border = np.any(seg_np[0, :, :])
        elif face == 1:
            border = np.any(seg_np[:, 0, :])
        elif face == 2:
            border = np.any(seg_np[:, :, 0])
        elif face == 3:
            border = np.any(seg_np[-1, :, :])
        elif face == 4:
            border = np.any(seg_np[:, -1, :])
        elif face == 5:
            border = np.any(seg_np[:, :, -1])

    return border


def is_point_in_image(assembly_image, location):

    index = assembly_image.TransformPhysicalPointToIndex(location.tolist())

    try:
        vessel_value = assembly_image[index]
        # print("Vessel value is: " + str(vessel_value))
        is_inside = vessel_value > 0.5
    except Exception as e:
        print(e)
        is_inside = False

    return is_inside
