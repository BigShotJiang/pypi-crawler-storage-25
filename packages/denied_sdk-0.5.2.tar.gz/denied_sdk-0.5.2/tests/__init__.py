"""Tests for denied-sdk."""
