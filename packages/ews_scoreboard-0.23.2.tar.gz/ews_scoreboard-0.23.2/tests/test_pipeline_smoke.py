"""Pipeline smoke test.

Her commit öncesi çalıştır: python -m pytest tests/test_pipeline_smoke.py -v
Herhangi biri FAIL ederse commit yapma.

Pipeline çalıştırmaya gerek yok — sadece yapısal kontroller.
"""

import json
import hashlib
from pathlib import Path
from collections import OrderedDict

import pytest

PKG_DIR = Path(__file__).parent.parent / "src" / "ews_scoreboard"
DATA_DIR = PKG_DIR / "data"


# ── Helpers ──

def _notebook_code_hash(nb_path):
    """Notebook sadece cell source hash'i."""
    nb = json.loads(Path(nb_path).read_text(encoding="utf-8"))
    h = hashlib.md5()
    for cell in nb.get("cells", []):
        src = "".join(cell.get("source", []))
        h.update(src.encode("utf-8"))
    return h.hexdigest()


def _get_notebook_params(nb_path):
    """Notebook parameters cell'indeki parametre adlarını döndür."""
    nb = json.loads(Path(nb_path).read_text(encoding="utf-8"))
    params = set()
    for cell in nb["cells"]:
        if "parameters" in cell.get("metadata", {}).get("tags", []):
            for line in "".join(cell.get("source", [])).split("\n"):
                line = line.strip()
                if "=" in line and not line.startswith("#"):
                    name = line.split("=")[0].strip()
                    if name.isidentifier():
                        params.add(name)
    return params


def _get_pipeline_header_adimlar():
    """Pipeline notebook header tablosundan adım kodlarını çıkar."""
    nb = json.loads((DATA_DIR / "ews_pipeline.ipynb").read_text(encoding="utf-8"))
    src = "".join(nb["cells"][0].get("source", []))
    import re
    return set(re.findall(r"`(\w+)`\s*\|", src))


# ── Tests ──

def test_motor_registry_notebook_var():
    """Motor registry'deki her notebook data/ altında olmalı."""
    from ews_scoreboard.motor import ADIM_REGISTRY
    for kod, info in ADIM_REGISTRY.items():
        nb = DATA_DIR / info["nb"]
        assert nb.exists(), f"{kod}: {info['nb']} bulunamadı → {nb}"


def test_ingest_notebook_source_dir_parametresi():
    """Her ingest notebook SOURCE_DIR veya SOURCE_DIRS parametresi kabul etmeli."""
    from ews_scoreboard.motor import ADIM_REGISTRY
    skip = {"ingest_ddl", "ingest_depo"}  # DDL parametre almaz, depo PARQUET_DIR kullanır
    for kod, info in ADIM_REGISTRY.items():
        if not kod.startswith("ingest_") or kod in skip:
            continue
        nb_path = DATA_DIR / info["nb"]
        params = _get_notebook_params(nb_path)
        has_source = "SOURCE_DIR" in params or "SOURCE_DIRS" in params
        assert has_source, f"{kod} ({info['nb']}): SOURCE_DIR parametresi yok — params: {params}"


def test_pipeline_header_tutarlilik():
    """Pipeline header tablosu Motor registry ile uyumlu olmalı."""
    from ews_scoreboard.motor import ADIM_REGISTRY
    header_codes = _get_pipeline_header_adimlar()
    registry_codes = set(ADIM_REGISTRY.keys())

    missing = registry_codes - header_codes
    extra = header_codes - registry_codes

    assert not missing, f"Registry'de var, header'da yok: {missing}"
    assert not extra, f"Header'da var, registry'de yok: {extra}"


def test_transform_fact_periodic_kolonlari():
    """fact_periodic DDL'deki kolonlar transform INSERT'teki kolonlarla eşleşmeli."""
    ddl = (PKG_DIR / "sql" / "ddl" / "create_tables.sql").read_text(encoding="utf-8")

    # DDL'den fact_periodic kolon adlarını çıkar
    import re
    m = re.search(r"CREATE TABLE IF NOT EXISTS fact_periodic\s*\((.*?)\)", ddl, re.DOTALL)
    assert m, "fact_periodic DDL bulunamadı"
    ddl_cols = []
    for line in m.group(1).split("\n"):
        line = line.strip().rstrip(",")
        if line and not line.startswith("PRIMARY") and not line.startswith("--"):
            col = line.split()[0]
            ddl_cols.append(col)

    # transform.py'den INSERT kolon listesini çıkar
    transform_src = (PKG_DIR / "pipeline" / "transform.py").read_text(encoding="utf-8")
    m2 = re.search(r"INSERT INTO fact_periodic\s*\((.*?)\)", transform_src, re.DOTALL)
    assert m2, "transform.py'de fact_periodic INSERT bulunamadı"
    insert_cols = [c.strip() for c in m2.group(1).replace("\n", " ").split(",")]

    assert set(ddl_cols) == set(insert_cols), (
        f"DDL vs INSERT farkı:\n"
        f"  DDL'de var, INSERT'te yok: {set(ddl_cols) - set(insert_cols)}\n"
        f"  INSERT'te var, DDL'de yok: {set(insert_cols) - set(ddl_cols)}"
    )


def test_notebook_code_hash_metadata_degismez():
    """Notebook metadata değişse bile code hash değişmemeli."""
    import tempfile

    nb1 = {"cells": [{"cell_type": "code", "source": ["x = 1"], "metadata": {},
                       "outputs": [], "execution_count": None}],
            "metadata": {"kernelspec": {"name": "python3"}}, "nbformat": 4, "nbformat_minor": 5}

    nb2 = {"cells": [{"cell_type": "code", "source": ["x = 1"], "metadata": {"tags": ["test"]},
                       "outputs": [{"text": "hello"}], "execution_count": 5}],
            "metadata": {"kernelspec": {"name": "python3", "display_name": "NEW"}},
            "nbformat": 4, "nbformat_minor": 5}

    with tempfile.NamedTemporaryFile(suffix=".ipynb", mode="w", delete=False) as f:
        json.dump(nb1, f)
        p1 = f.name
    with tempfile.NamedTemporaryFile(suffix=".ipynb", mode="w", delete=False) as f:
        json.dump(nb2, f)
        p2 = f.name

    h1 = _notebook_code_hash(p1)
    h2 = _notebook_code_hash(p2)

    Path(p1).unlink()
    Path(p2).unlink()

    assert h1 == h2, f"Aynı kod farklı hash: {h1} != {h2}"


def test_build_features_kolon_adlari():
    """build_features FEATURE_COLS ve DIAG_FEATURE_COLS tanımlı olmalı."""
    from ews_scoreboard.ml.features import FEATURE_COLS, DIAG_FEATURE_COLS

    assert len(FEATURE_COLS) > 20, f"FEATURE_COLS çok az: {len(FEATURE_COLS)}"
    assert "ews_score" in FEATURE_COLS
    assert "risk_current" in FEATURE_COLS
    assert "bolge_kodu" in FEATURE_COLS
    assert len(DIAG_FEATURE_COLS) > 5, f"DIAG_FEATURE_COLS çok az: {len(DIAG_FEATURE_COLS)}"


def test_diag_groups_yapisi():
    """DIAG_GROUPS 7 grup, her grupta icon/color/label olmalı."""
    from ews_scoreboard.diag_groups import DIAG_GROUPS

    assert len(DIAG_GROUPS) == 7, f"7 grup bekleniyor, {len(DIAG_GROUPS)} var"
    for grp, cfg in DIAG_GROUPS.items():
        assert "icon" in cfg, f"{grp}: icon yok"
        assert "color" in cfg, f"{grp}: color yok"
        assert "label" in cfg, f"{grp}: label yok"


def test_feature_info_fi_singleton():
    """FI singleton yüklenebilmeli, temel property'ler çalışmalı."""
    from ews_scoreboard.feature_info import FI

    # JSON yoksa bile fallback boş döner, hata vermez
    assert hasattr(FI, "kik_ciss_cols")
    assert hasattr(FI, "rkd_codes")
    assert hasattr(FI, "delta_exclude_cols")
