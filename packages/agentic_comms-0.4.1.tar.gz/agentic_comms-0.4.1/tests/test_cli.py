"""End-to-end tests: CLI against a real in-process server via a live uvicorn-less ASGI transport."""
import json
import os
import socket
import threading
import time
from pathlib import Path

import httpx
import pytest
import uvicorn
from typer.testing import CliRunner


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture
def env(tmp_path, monkeypatch):
    monkeypatch.setenv("AGENT_COMMS_CONFIG_DIR", str(tmp_path / "cfg"))
    monkeypatch.setenv("AGENT_COMMS_TOKEN", "test-token")

    port = _free_port()
    monkeypatch.setenv("AGENT_COMMS_SERVER", f"http://127.0.0.1:{port}")

    from agent_comms_server.main import create_app
    app = create_app(db_path=tmp_path / "t.db")

    cfg = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning")
    server = uvicorn.Server(cfg)
    t = threading.Thread(target=server.run, daemon=True)
    t.start()
    # wait for boot
    for _ in range(50):
        try:
            httpx.get(f"http://127.0.0.1:{port}/api/health", headers={"Authorization": "Bearer test-token"}, timeout=1)
            break
        except Exception:
            time.sleep(0.05)

    workdir = tmp_path / "work"
    workdir.mkdir()
    monkeypatch.chdir(workdir)
    try:
        yield tmp_path
    finally:
        server.should_exit = True
        t.join(timeout=3)


def run(args):
    from agent_comms.cli import app
    return CliRunner().invoke(app, args)


def test_ping(env):
    r = run(["ping"])
    assert r.exit_code == 0, r.output
    assert "ok" in r.output


def test_init_and_whoami(env):
    r = run(["init", "--handle", "alpha"])
    assert r.exit_code == 0, r.output
    assert "alpha" in r.output
    r = run(["whoami"])
    assert "alpha" in r.output


def test_post_and_inbox_and_thread(env):
    run(["init", "--handle", "alpha"])
    # Register bob too via API
    from agent_comms.api import Client
    c = Client()
    c.register_identity(handle="bob")

    r = run(["post", "-t", "Hi", "-s", "short summary", "-b", "full body", "--to", "bob", "--tags", "setup,fyi"])
    assert r.exit_code == 0, r.output

    r = run(["inbox", "--handle", "bob"])
    assert r.exit_code == 0
    assert "Hi" in r.output

    # get the id and read
    msgs = c.inbox("bob")
    mid = msgs[0]["id"]
    r = run(["read", mid])
    assert "full body" in r.output

    # Reply from bob requires claim
    run(["claim", "bob"])
    r = run(["post", "-t", "Re", "-s", "re", "-b", "reply body", "--to", "alpha", "--reply-to", mid])
    assert r.exit_code == 0

    r = run(["thread", mid])
    assert "Hi" in r.output and "Re" in r.output


def test_feed_broadcast(env):
    run(["init", "--handle", "alpha"])
    run(["post", "-t", "Announce", "-s", "hello all", "-b", "b"])
    r = run(["feed"])
    assert "Announce" in r.output


def test_claim_unknown(env):
    run(["init", "--handle", "alpha"])
    r = run(["claim", "nobody"])
    assert r.exit_code != 0


def test_forget(env, monkeypatch):
    # Simulate running outside a Claude session so auto-init doesn't re-create identity.
    from agent_comms import config as cfg
    monkeypatch.setattr(cfg, "find_claude_pid", lambda: None)
    run(["init", "--handle", "alpha"])
    run(["forget"])
    r = run(["whoami"])
    assert r.exit_code != 0


def test_read_with_prefix_id(env):
    run(["init", "--handle", "alpha"])
    r = run(["post", "-t", "T", "-s", "S", "-b", "B"])
    # extract id from "posted id=XXXXXXXXXXXX ..."
    mid = [w for w in r.output.split() if w.startswith("id=")][0].split("=")[1]
    r = run(["read", mid[:6]])
    assert r.exit_code == 0
    assert "title: T" in r.output


def test_read_missing_id_friendly_error(env):
    run(["init", "--handle", "alpha"])
    r = run(["read", "zzzzzzzz"])
    assert r.exit_code != 0
    assert "Traceback" not in r.output
    # CliRunner puts stderr into output unless mix_stderr=False; look in both
    combined = r.output + (r.stderr if hasattr(r, "stderr") else "")
    assert "error" in combined.lower() or "not found" in combined.lower()


def test_json_output_feed(env):
    run(["init", "--handle", "alpha"])
    run(["post", "-t", "T", "-s", "S", "-b", "B"])
    r = run(["feed", "--json"])
    assert r.exit_code == 0
    data = json.loads(r.output)
    assert len(data) == 1
    assert data[0]["title"] == "T"


def test_check_silent_when_empty(env):
    run(["init", "--handle", "alpha"])
    r = run(["check"])
    assert r.exit_code == 0
    assert r.output.strip() == ""


def test_check_prints_when_unread(env):
    run(["init", "--handle", "alpha"])
    from agent_comms.api import Client
    Client().register_identity(handle="bob")
    Client().post_message("bob", "hi", "sum", "full body text here", to_handle="alpha")
    r = run(["check"])
    assert r.exit_code == 0
    assert "1 unread" in r.output
    assert "hi" in r.output
    # body inlined by default — one command = full read
    assert "full body text here" in r.output


def test_inbox_shows_body_by_default(env):
    run(["init", "--handle", "alpha"])
    from agent_comms.api import Client
    Client().register_identity(handle="bob")
    Client().post_message("bob", "t", "s", "UNIQUE_BODY_MARKER", to_handle="alpha")
    r = run(["inbox"])
    assert "UNIQUE_BODY_MARKER" in r.output
    # --brief hides it
    r = run(["inbox", "--brief"])
    assert "UNIQUE_BODY_MARKER" not in r.output


def test_install_and_uninstall_hook(env, tmp_path, monkeypatch):
    claude_home = tmp_path / "claude-home"
    monkeypatch.setenv("CLAUDE_CONFIG_DIR", str(claude_home))
    r = run(["install-hook"])
    assert r.exit_code == 0
    settings = json.loads((claude_home / "settings.json").read_text())
    assert "PostToolUse" in settings["hooks"]
    assert "UserPromptSubmit" in settings["hooks"]
    # command must use python -m form, not bare `comms`
    for event in ("PostToolUse", "UserPromptSubmit"):
        groups = settings["hooks"][event]
        cmds = [h["command"] for g in groups for h in g.get("hooks", [])]
        assert any("-m agent_comms" in c for c in cmds)
    # idempotent — no duplicate entries
    r2 = run(["install-hook"])
    assert r2.exit_code == 0
    settings2 = json.loads((claude_home / "settings.json").read_text())
    for event in ("PostToolUse", "UserPromptSubmit"):
        assert len(settings2["hooks"][event]) == len(settings["hooks"][event])
    # uninstall removes both
    r3 = run(["uninstall-hook"])
    assert r3.exit_code == 0
    data = json.loads((claude_home / "settings.json").read_text())
    assert "hooks" not in data or all(e not in data.get("hooks", {}) for e in ("PostToolUse", "UserPromptSubmit"))


def test_hook_silent_when_no_dms(env, tmp_path, monkeypatch):
    monkeypatch.setenv("AGENT_COMMS_CACHE_DIR", str(tmp_path / "cache"))
    run(["init", "--handle", "alpha"])
    # Force poll conditions to be met by fabricating counter file to N-1 and old lastpoll
    # Simpler: just run the hook; counter=1 so no poll triggered -> silent
    from agent_comms import hook as h
    # First fire: counter=1, no poll
    import io, contextlib
    with contextlib.redirect_stdout(io.StringIO()) as buf:
        rc = h.main()
    assert rc == 0
    assert buf.getvalue() == ""


def test_hook_emits_json_on_new_dm(env, tmp_path, monkeypatch):
    monkeypatch.setenv("AGENT_COMMS_CACHE_DIR", str(tmp_path / "cache"))
    run(["init", "--handle", "alpha"])
    from agent_comms.api import Client
    Client().register_identity(handle="bob")
    Client().post_message("bob", "urgent", "sum", "BODY_MARKER", to_handle="alpha")

    from agent_comms import hook as h
    # Force poll by bumping counter to POLL_EVERY_N_CALLS-1 and ageing lastpoll
    cache = tmp_path / "cache"
    cache.mkdir(parents=True, exist_ok=True)
    import hashlib, time
    hk = hashlib.sha256(b"alpha").hexdigest()[:12]
    (cache / f"counter-{hk}").write_text(str(h.POLL_EVERY_N_CALLS - 1))
    (cache / f"lastpoll-{hk}").write_text("0")

    import io, contextlib
    with contextlib.redirect_stdout(io.StringIO()) as buf:
        rc = h.main()
    assert rc == 0
    out = buf.getvalue()
    assert out != ""
    envelope = json.loads(out)
    assert envelope["hookSpecificOutput"]["hookEventName"] == "PostToolUse"
    ctx = envelope["hookSpecificOutput"]["additionalContext"]
    assert "urgent" in ctx
    assert "BODY_MARKER" in ctx
    assert "<agent_comms_inbox" in ctx

    # Second fire — watermark advanced, no new DMs -> silent
    (cache / f"counter-{hk}").write_text(str(h.POLL_EVERY_N_CALLS - 1))
    (cache / f"lastpoll-{hk}").write_text("0")
    with contextlib.redirect_stdout(io.StringIO()) as buf2:
        h.main()
    assert buf2.getvalue() == ""


def test_hook_sanitizes_ansi_and_control(env, tmp_path, monkeypatch):
    from agent_comms.hook import _sanitize
    dirty = "hello\x1b[31mworld\x00\x07"
    assert _sanitize(dirty) == "helloworld"


def test_pid_walk_returns_none_when_no_claude(monkeypatch):
    from agent_comms import config as cfg
    monkeypatch.setattr(cfg, "_proc_name", lambda pid: "bash")
    assert cfg.find_claude_pid() is None


def test_pid_walk_finds_claude(monkeypatch):
    from agent_comms import config as cfg
    # Make the first PID look like claude
    seen = {"n": 0}
    def fake_name(pid):
        seen["n"] += 1
        return "claude" if seen["n"] == 1 else "init"
    monkeypatch.setattr(cfg, "_proc_name", fake_name)
    monkeypatch.setattr(cfg, "_proc_ppid", lambda pid: 1)
    assert cfg.find_claude_pid() == os.getppid()


def test_attach_and_fetch_round_trip(env, tmp_path, monkeypatch):
    run(["init", "--handle", "alpha"])
    src = tmp_path / "note.md"
    src.write_text("# hello\nattachment round-trip works")
    # upload
    r = run(["attach", str(src), "--json"])
    assert r.exit_code == 0, r.output
    data = json.loads(r.output)
    aid = data["id"]
    assert data["filename"] == "note.md"
    # fetch into a fresh location
    out = tmp_path / "pulled" / "note.md"
    r = run(["fetch", aid, "--out", str(out)])
    assert r.exit_code == 0, r.output
    assert out.read_text() == src.read_text()


def test_post_with_attachment(env, tmp_path):
    run(["init", "--handle", "alpha"])
    from agent_comms.api import Client
    Client().register_identity(handle="bob")
    src = tmp_path / "script.sh"
    src.write_text("#!/bin/bash\necho hi")
    r = run(["post", "-t", "look", "-s", "attached script", "-b", "body",
            "--to", "bob", "--attach", str(src)])
    assert r.exit_code == 0, r.output
    assert "attachments=" in r.output
    # Recipient sees attachment_ids on the message
    msgs = Client().inbox("bob")
    assert msgs[0]["attachment_ids"]


def test_mission_set_clear_via_cli(env):
    run(["init", "--handle", "alpha"])
    r = run(["mission", "refactoring auth"])
    assert r.exit_code == 0 and "refactoring auth" in r.output
    r = run(["mission", "--clear"])
    assert "(none)" in r.output


def test_mission_tailer_picks_latest_ai_title(env, tmp_path, monkeypatch):
    # Build a fake transcript with multiple ai-title entries
    tx = tmp_path / "session.jsonl"
    tx.write_text(
        '{"type":"user","message":{"content":"hi"}}\n'
        '{"type":"ai-title","aiTitle":"Old topic"}\n'
        '{"type":"assistant","message":{"content":[{"type":"text","text":"ok"}]}}\n'
        '{"type":"ai-title","aiTitle":"New fresher topic"}\n'
    )
    from agent_comms.hook import _latest_ai_title
    assert _latest_ai_title(str(tx)) == "New fresher topic"
    assert _latest_ai_title(None) is None
    assert _latest_ai_title("/nonexistent/file") is None


def test_post_json(env):
    run(["init", "--handle", "alpha"])
    payload = json.dumps({"title": "T", "summary": "S", "body": "B", "tags": ["x"]})
    from agent_comms.cli import app
    result = CliRunner().invoke(app, ["post-json"], input=payload)
    assert result.exit_code == 0, result.output
    assert '"title": "T"' in result.output
