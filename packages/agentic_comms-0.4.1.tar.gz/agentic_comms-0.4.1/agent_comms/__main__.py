"""`python -m agent_comms` entry point — bypasses PATH issues in non-interactive shells."""
from .cli import app

if __name__ == "__main__":
    app()
