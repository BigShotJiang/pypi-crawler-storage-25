from datetime import datetime
from typing import Any, Literal, Optional, TypedDict

from pydantic import BaseModel, model_validator


class Output(BaseModel):
    model_config = {"extra": "allow"}


class PredictedExample(BaseModel):
    id: Optional[str] = None
    alt_id: Optional[str] = None
    arbiter_repo: str
    arbiter_hash: str = ""
    input: Any = None
    ground_truth: Optional[str] = None
    ground_reasoning: str = ""
    messages: Optional[list[dict]] = None
    output: Optional[dict] = None
    serialized_output: Optional[str] = None
    reasoning: Optional[str] = None
    split: Literal["train", "test", "none"] = None
    version: Optional[int] = None
    prediction_timestamp: Optional[datetime] = None
    confidence: Optional[float] = None


class IngestExamplesResponse(BaseModel):
    queued: bool
    example_ids: list[str]


class ExamplesPage(BaseModel):
    items: list[PredictedExample]
    total: int
    page: int
    page_size: int
    total_pages: int


class PredictionAnnotation(TypedDict, total=False):
    arbiter_repo: str
    ground_truth: Optional[str]
    ground_reasoning: Optional[str]


class AnnotateExampleResponse(BaseModel):
    status: str


class FieldSchema(BaseModel):
    name: str
    type: Literal["string", "number", "boolean", "array", "object"]
    allowed_values: list[Any] | None = None
    object_schema: dict | None = None
    nullable: bool = False
    description: str | None = None

    @model_validator(mode="after")
    def validate_schema(self) -> "FieldSchema":
        if self.type == "object" and self.allowed_values is not None:
            raise ValueError("Allowed values must be None if type is 'object'")
        if self.object_schema is not None and self.type != "object":
            raise ValueError("object_schema must be None if type is not 'object'")
        return self


class InitArbiterRequest(BaseModel):
    repo: str
    inputs: list[FieldSchema]
    outputs: list[FieldSchema]
    instructions: str | None = None
    model: str = "qwen3-vl-32b-instruct"
    base_url: str | None = None


class ConfidenceStatusResponse(BaseModel):
    status: str
    prediction_id: str
    score: float | None = None
    error: str | None = None
