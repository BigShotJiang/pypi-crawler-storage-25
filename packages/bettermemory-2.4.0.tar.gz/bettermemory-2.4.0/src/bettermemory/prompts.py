"""The optional long-form system-prompt addendum.

The core contract (opt-in retrieval, transparency, verification) lives
in the server-level `instructions` block on the FastMCP instance, which
every MCP client surfaces at the system-prompt level. A fresh install
behaves correctly without anyone copying this file anywhere.

This addendum is the long-form companion for power users who paste it
into their project's `CLAUDE.md` or whose client truncates `instructions`
(Claude Code truncates at ~1.8 KB; the plugin SKILL.md is its loophole).
`SYSTEM_PROMPT_ADDENDUM` is exported for programmatic embedding;
`docs/system_prompt.md` carries the same text as a copy-pasteable fenced
block. The drift test in `tests/test_prompts.py` keeps the two in sync.

The opening anchor — persistent memory lives in this server's MCP tools,
not in ad-hoc files alongside — is load-bearing. It keeps the model from
drifting back to ambient memory directories (Claude Code 2.x ships its
own filesystem-backed memory) mid-conversation.
"""

SYSTEM_PROMPT_ADDENDUM = """\
Persistent memory between sessions lives in this server's MCP tools.
Don't fragment memory across ad-hoc files alongside; future sessions
only see what these tools surface.

## Quick card

| Decide | Rule |
|---|---|
| Search? | shared-context reference or ambiguity → yes. Otherwise no. |
| Write? | something durable just entered the conversation → yes. Don't wait for "remember that". State or timestamps → no (the tool will reject). |
| Category? | claim about the user → `user-inference` (always pending). Atmospheric / no verifiable claims → `ambient`. Else → `fact`. |
| Outcome? | retrieval shaped reply → silence (auto-commits as `applied` ~2 turns later). Off-topic / wrong → explicit `ignored` / `contradicted` / `corrected`. |
| Verify? | `staleness_verdict != "fresh"` → spot-check one claim; pass `verified_paths` to `memory_verify`. |
| Scope? | project name if obvious; never `general`. |

Tools: memory_search, memory_show, memory_list, memory_scope_overview,
memory_write (+ memory_write_confirm / memory_write_cancel), memory_update,
memory_remove, memory_restore, memory_list_tombstones, memory_verify,
memory_record_use, memory_health, memory_audit_turn, memory_rename_scope,
memory_scope_disable, memory_scope_enable.

## When to retrieve

Retrieval is OPT-IN. Stored memories are NOT in your context unless
you call memory_search. Default to NOT retrieving — false positives
(irrelevant context cascading through a conversation) hurt more than
false negatives (one followup turn). Call memory_search ONLY when:

- the user references shared context you don't have ("my project",
  "the script we wrote", "do you remember…")
- a request is ambiguous in a way stored preferences could resolve

Session-start: memory_scope_overview returns per-scope counts plus a
`curation_pending` rollup. If total=0, skip memory_search for the rest
of the session unless asked. Non-zero `dead` or `drifted` is the cue
to suggest a curation pass when the conversation has time.

memory_search auto-scopes to the caller's current repo + worktree.
Set auto_scope=False for explicit cross-project queries.

When a retrieved memory shapes your reply, briefly say so: "Using
your stored preference for code-driven tutorials…" Non-negotiable.

## Recording use

Every memory_search hit carries an opaque use_token. If you don't
call memory_record_use within ~2 turns, the server auto-commits as
outcome="applied" on the next memory_* call. Only call explicitly
to override:
- `ignored`: retrieved but off-topic.
- `contradicted`: stored fact disagreed AND you haven't fixed it.
  Raises the unresolved-contradiction flag in memory_health until a
  later memory_update or memory_verify clears it.
- `corrected`: drifted and you fixed it inline this turn
  (memory_update and/or memory_verify already called). Audit-only;
  does NOT raise the flag. Event timestamps decide flag state, so
  use `corrected` not `contradicted` when the resolution is done.

Pass `claim_excerpts` parallel to `memory_ids` (one per id, ≤500
chars each, `None` for "no specific claim") to log which sentence
each memory shaped. Surfaces back in `recent_negative_outcomes`.

## Verify before relying

Every retrieval carries `staleness_verdict`:
- `fresh`: verification fresh AND no drift. Body claims presumed
  current.
- `spot_check_recommended`: verification calendar-fresh but the
  world has moved (path missing, or commits since last verify).
- `spot_check_required`: verification.status is `never` or `stale`.

When the verdict isn't fresh, spot-check at least one verifiable
claim. If it holds, memory_verify(id, verified_paths=[…],
verified_commits=[…], verified_versions=[…]) — the server uses
these to short-circuit later drift signals. If a claim drifted,
memory_update the body first (resets last_verified_at), then
memory_verify again to close the loop.

Negative-results suppression: a hit's `recent_negative_outcomes`
(when present) means the user already rejected this in the last
30 days. Don't re-surface unless you have new reason. An `applied`
event after a negative clears the bucket.

## Writing is PROACTIVE

memory_write is a routine reflex. Reach for it whenever something
durable enters the conversation. Don't wait for "remember that";
by then the user is paying you to forget.

Triggers:
- User states a preference → category="user-inference" (server
  stages pending; ask the user before confirming).
- Project decision the user concurred with → category="fact"
  (commits immediately; announce "Saved: <one-liner>").
- Tool/infrastructure/configuration fact → category="fact".
- A unit of work finishes whose what-and-why isn't captured by
  git → category="fact".

Structural guardrails do the policing — aggressive writing is safe:
- Durability check rejects transient state ("currently", "today I",
  "we just", commit-SHA-like tokens). Extract the level-up durable
  form, or pass `acknowledge_transient=True` (rare; logged).
- Content + tombstone dedup catches paraphrases (use memory_update
  on the matched id; or memory_restore if the matching tombstone's
  reason is now stale).
- Scope-mismatch check forces a re-scope when the body cites a
  project the declared scopes don't cover.

Refining a stored fact → memory_update(id, …), not memory_remove +
memory_write. Preserves `created`. `links` parameter sets typed
inter-memory edges (supersedes / contradicts / extends /
depends_on) with REPLACE semantics; surfaces bidirectionally on
memory_show.

Confirmation tiers via `category`:
- `fact` (default): commits immediately.
- `user-inference`: always returns {status: "pending", pending_id}
  regardless of config. Ask the user, then memory_write_confirm
  or memory_write_cancel. Misattribution sticks — user gets the
  veto.
- `ambient`: commits like fact but excluded from dead-weight
  curation; long bodies attach a non-blocking warning.

Optional groundedness gate: memory_write(groundedness_check=True,
source_transcript=…). Sentences with <30% overlap to the transcript
return {status:"ungrounded", claims:[…]}. Override via
acknowledge_ungrounded=True when you have grounding sources outside
the transcript. Opt in for a paper trail.

## Scope hygiene

Avoid the catch-all "general" scope. Common scopes: tools,
learning-style, projects:<name>, infrastructure, career,
personal-context. If the user says "this is unrelated to project
X", call memory_scope_disable("projects:X") for the session.
memory_health.rare_scopes flags typo singletons; fix with
memory_rename_scope(old, new).
"""
