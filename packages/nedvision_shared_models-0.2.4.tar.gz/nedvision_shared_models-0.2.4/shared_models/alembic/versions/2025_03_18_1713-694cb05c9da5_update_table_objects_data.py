"""update table: objects_data

Revision ID: 694cb05c9da5
Revises: f3cd60071b88
Create Date: 2025-03-18 17:13:20.214381

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "694cb05c9da5"
down_revision: Union[str, None] = "f3cd60071b88"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("CREATE EXTENSION IF NOT EXISTS unaccent")

    op.add_column(
        "objects_data",
        sa.Column("search_vector", postgresql.TSVECTOR(), nullable=True),
        schema="webapp",
    )

    op.create_index(
        "idx_objects_data_search_vector",
        "objects_data",
        ["search_vector"],
        unique=False,
        schema="webapp",
        postgresql_using="gin",
    )

    op.execute(
        """
        UPDATE webapp.objects_data
        SET search_vector = to_tsvector('russian',
            coalesce(title, '') || ' ' ||
            coalesce(description, '') || ' ' ||
            coalesce(address, '')
        )
    """
    )

    op.execute(
        """
    CREATE OR REPLACE FUNCTION update_objects_data_search_vector() RETURNS trigger AS $$
    BEGIN
      NEW.search_vector := to_tsvector('russian',
        coalesce(NEW.title, '') || ' ' ||
        coalesce(NEW.description, '') || ' ' ||
        coalesce(NEW.address, '')
      );
      RETURN NEW;
    END
    $$ LANGUAGE plpgsql;
    """
    )

    op.execute(
        """
    CREATE TRIGGER update_objects_data_search_vector_trigger
    BEFORE INSERT OR UPDATE OF title, description, address
    ON webapp.objects_data
    FOR EACH ROW EXECUTE FUNCTION update_objects_data_search_vector();
    """
    )


def downgrade() -> None:
    op.execute(
        "DROP TRIGGER IF EXISTS update_objects_data_search_vector_trigger ON webapp.objects_data"
    )

    op.execute("DROP FUNCTION IF EXISTS update_objects_data_search_vector()")

    op.drop_index(
        "idx_objects_data_search_vector", table_name="objects_data", schema="webapp"
    )

    op.drop_column("objects_data", "search_vector", schema="webapp")
