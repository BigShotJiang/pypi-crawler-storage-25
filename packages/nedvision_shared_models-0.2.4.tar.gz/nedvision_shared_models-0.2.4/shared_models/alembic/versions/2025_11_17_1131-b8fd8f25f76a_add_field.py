"""add field

Revision ID: b8fd8f25f76a
Revises: 621c09cdec84
Create Date: 2025-11-17 11:31:13.710414

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "b8fd8f25f76a"
down_revision: Union[str, None] = "621c09cdec84"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "objects_data", sa.Column("city", sa.String(), nullable=True), schema="webapp"
    )
    op.execute(
        """
               UPDATE webapp.objects_data od
               SET city = a.city
                   FROM objects o
            JOIN advertisements a ON a.id = o.ad_id
               WHERE od.object_id = o.id
               """
    )

    op.create_index(
        "ix_webapp_objects_data_city", "objects_data", ["city"], schema="webapp"
    )


def downgrade() -> None:
    pass
