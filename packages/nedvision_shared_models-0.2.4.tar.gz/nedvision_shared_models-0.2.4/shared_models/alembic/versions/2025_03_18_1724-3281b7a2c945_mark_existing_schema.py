"""mark_existing_schema

Revision ID: 3281b7a2c945
Revises: 694cb05c9da5
Create Date: 2025-03-18 17:24:20.513089

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "3281b7a2c945"
down_revision: Union[str, None] = "694cb05c9da5"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
