"""update table: users

Revision ID: 919b0ff667b3
Revises: b89790267ee3
Create Date: 2025-03-20 16:20:30.874912

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "919b0ff667b3"
down_revision: Union[str, None] = "b89790267ee3"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "objects_data",
        sa.Column("readiness", sa.String(), nullable=True),
        schema="webapp",
    )


def downgrade() -> None:
    pass
