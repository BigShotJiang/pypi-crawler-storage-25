"""merge heads

Revision ID: 945d59f4d442
Revises: 0bde485b473a, c854283b32a5
Create Date: 2026-03-31 02:47:51.182901

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = "945d59f4d442"
down_revision: Union[str, None] = ("0bde485b473a", "c854283b32a5")
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
