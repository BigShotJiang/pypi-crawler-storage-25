"""update enum: reasin

Revision ID: 83303723e321
Revises: 5a03e813b083
Create Date: 2026-03-02 14:27:39.674282

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "83303723e321"
down_revision: Union[str, None] = "9ec93b716912"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("ALTER TYPE reason ADD VALUE IF NOT EXISTS 'scrapper_parse_fail'")


def downgrade() -> None:
    pass
