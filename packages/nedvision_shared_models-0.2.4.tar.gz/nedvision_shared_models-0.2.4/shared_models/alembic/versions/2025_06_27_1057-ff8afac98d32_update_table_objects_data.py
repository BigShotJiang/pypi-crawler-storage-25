"""update table: objects_data

Revision ID: ff8afac98d32
Revises: 1ebc7996032c
Create Date: 2025-06-27 10:57:05.953264

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "ff8afac98d32"
down_revision: Union[str, None] = "1ebc7996032c"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "objects_data",
        sa.Column(
            "created_at", sa.DateTime(), server_default=sa.text("now()"), nullable=False
        ),
        schema="webapp",
    )


def downgrade() -> None:
    op.drop_column("objects_data", "created_at", schema="webapp")
