from enum import Enum


class RegionType(str, Enum):
    MACRO = "макро-регион"
    MICRO = "микро-регион"
    NANO = "нано-регион"
