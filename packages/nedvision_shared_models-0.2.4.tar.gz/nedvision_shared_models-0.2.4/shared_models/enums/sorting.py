from enum import Enum


class SortField(str, Enum):
    created_at = "created_at"
    price = "price"
    price_m2 = "price_m2"
    area = "area"
    monthly_rental_flow = "monthly_rental_flow"
    payback_period = "payback_period"
    revenue = "revenue"


class SortDir(str, Enum):
    asc = "asc"
    desc = "desc"
