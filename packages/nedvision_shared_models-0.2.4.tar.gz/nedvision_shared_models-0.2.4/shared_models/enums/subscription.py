from enum import Enum


class SubscriptionCode(str, Enum):
    FREE = "FREE"
    PLUS = "PLUS"
    PRO = "PRO"
