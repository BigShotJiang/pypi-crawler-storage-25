from enum import Enum


class TransactionType(Enum):
    EARN = "EARN"
    SPEND = "SPEND"
    ADJUST = "ADJUST"
