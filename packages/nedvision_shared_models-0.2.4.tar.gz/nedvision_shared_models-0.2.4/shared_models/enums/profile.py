from enum import Enum


class Profile(Enum):
    SPECULATION = "SPECULATION"
    LIQUIDITY = "LIQUIDITY"
    PROFITABILITY = "PROFITABILITY"
    STRATEGY = "STRATEGY"
