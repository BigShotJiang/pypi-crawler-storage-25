from enum import Enum


class TransactionBatchType(Enum):
    DAILY_REWARD = "DAILY_REWARD"
    PROMO = "PROMO"
