from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin

from .base import Base


class ParamsMetadata(IdMixin, Base):
    __tablename__ = "params_metadata"

    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    description: Mapped[str] = mapped_column(nullable=True)
    algorithm: Mapped[str] = mapped_column(String(50), nullable=False)
    unit: Mapped[str] = mapped_column(String(50), nullable=True)
