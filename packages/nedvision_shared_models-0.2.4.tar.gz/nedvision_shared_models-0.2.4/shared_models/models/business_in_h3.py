from sqlalchemy import ARRAY, BIGINT, Index, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base


class BusinessInH3(IdMixin, TimestampMixin, Base):
    __tablename__ = "businesses_in_h3"

    h3: Mapped[str]
    yandex_id: Mapped[int] = mapped_column(BIGINT)
    name: Mapped[str] = mapped_column(nullable=True)
    categories: Mapped[list[str]] = mapped_column(ARRAY(String(100)), nullable=True)
    is_federal: Mapped[bool] = mapped_column(nullable=True)

    __table_args__ = (
        UniqueConstraint("yandex_id", name="uix_business_in_h3_yandex_id"),
        Index("idx_businesses_in_h3_h3", "h3"),
    )
