from __future__ import annotations

from uuid import UUID

from sqlalchemy import ARRAY
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import TimestampMixin, UUIDMixin

from .base import Base


class AssistantCollection(UUIDMixin, TimestampMixin, Base):
    cache_key: Mapped[str] = mapped_column(nullable=False, unique=True)
    obj_ids: Mapped[list[UUID]] = mapped_column(
        ARRAY(PG_UUID(as_uuid=True)),
        nullable=True,
    )
