from __future__ import annotations

from typing import TYPE_CHECKING
from uuid import UUID

from sqlalchemy import DECIMAL, ForeignKey, Index, Text, UniqueConstraint, text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.enums import (TransactionCurrency, TransactionStatus,
                                 TransactionType)
from shared_models.mixins import TimestampZoneMixin, UUIDMixin

from .base import Base

if TYPE_CHECKING:
    from . import TransactionBatch


class Transaction(UUIDMixin, TimestampZoneMixin, Base):
    __tablename__ = "transactions"

    user_id: Mapped[UUID] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    batch_id: Mapped[UUID] = mapped_column(
        ForeignKey("transaction_batches.id", ondelete="SET NULL"), nullable=True
    )
    type: Mapped[TransactionType]
    status: Mapped[TransactionStatus]
    amount: Mapped[float] = mapped_column(DECIMAL(precision=30, scale=18))
    currency: Mapped[TransactionCurrency]
    description: Mapped[str] = mapped_column(Text)
    meta: Mapped[dict] = mapped_column(JSONB, nullable=True)
    external_id: Mapped[str] = mapped_column(unique=True)

    batch: Mapped[TransactionBatch] = relationship(
        back_populates="transactions",
    )

    __table_args__ = (
        UniqueConstraint("external_id", name="uix_transaction_external_id"),
        Index(
            "idx_transactions_user_id_created_at", "user_id", text("created_at DESC")
        ),
    )
