from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

import sqlalchemy
from sqlalchemy import Index, String
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base


class HexagonConverted(Base):
    __tablename__ = "hexagons_converted"

    index: Mapped[str] = mapped_column(String(20), primary_key=True)

    created_at: Mapped[datetime] = mapped_column(
        server_default=sqlalchemy.text("CURRENT_TIMESTAMP"), nullable=True
    )
    updated_at: Mapped[datetime] = mapped_column(
        server_default=sqlalchemy.text("CURRENT_TIMESTAMP"),
        onupdate=sqlalchemy.text("CURRENT_TIMESTAMP"),
        nullable=True,
    )

    __table_args__ = (Index("idx_created_at", "created_at"),)
