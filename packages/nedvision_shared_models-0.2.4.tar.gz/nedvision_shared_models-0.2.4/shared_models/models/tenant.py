from __future__ import annotations

from typing import TYPE_CHECKING
from uuid import UUID

from sqlalchemy import ForeignKey, Index, UniqueConstraint, text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import UUIDMixin

from .base import Base

if TYPE_CHECKING:
    from . import ObjectData


class Tenant(UUIDMixin, Base):
    __tablename__ = "tenants"

    object_id: Mapped[UUID] = mapped_column(
        ForeignKey("webapp.objects_data.id", ondelete="CASCADE"),
        nullable=False,
    )
    name_raw: Mapped[str] = mapped_column(nullable=False)
    name_norm: Mapped[str] = mapped_column(nullable=False)
    name_canonical: Mapped[str] = mapped_column(nullable=False)

    object: Mapped[ObjectData] = relationship(
        back_populates="tenants_data",
    )

    __table_args__ = (
        Index("ix_object_tenants_object_id", "object_id"),
        UniqueConstraint(
            "object_id", "name_norm", name="uq_object_tenants_object_id_name_norm"
        ),
        Index("ix_object_tenants_name_norm", "name_norm"),
        Index(
            "ix_tenants_name_norm_trgm",
            text("lower(name_norm) gin_trgm_ops"),
            postgresql_using="gin",
        ),
        Index(
            "ix_tenants_name_canonical_trgm",
            text("lower(name_canonical) gin_trgm_ops"),
            postgresql_using="gin",
        ),
    )
