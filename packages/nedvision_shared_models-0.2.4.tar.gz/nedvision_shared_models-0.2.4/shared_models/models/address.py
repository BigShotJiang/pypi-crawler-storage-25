from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import Index, UniqueConstraint
from sqlalchemy.orm import Mapped, relationship

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base

if TYPE_CHECKING:
    from . import Business


class Address(IdMixin, TimestampMixin, Base):
    __tablename__ = "addresses"
    value: Mapped[str]
    latitude: Mapped[float]
    longitude: Mapped[float]

    businesses: Mapped[list[Business]] = relationship(
        back_populates="address",
    )

    __table_args__ = (
        UniqueConstraint("latitude", "longitude", name="uix_addresses_coordinates"),
        Index("idx_addresses_coords", "latitude", "longitude"),
        Index("idx_addresses_value", "value"),
    )
