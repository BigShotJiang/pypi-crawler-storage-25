from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import UUID, ForeignKey, sql
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import IdMixin

from .base import Base

if TYPE_CHECKING:
    from . import User


class Flag(IdMixin, Base):
    user_id: Mapped[UUID] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), unique=True
    )
    onboarding_success: Mapped[bool | None] = mapped_column(
        default=False,
        server_default=sql.false(),
        nullable=False,
    )
    privacy_policy_accepted: Mapped[bool] = mapped_column(
        default=False,
        server_default=sql.false(),
    )
    user_agreement_accepted: Mapped[bool] = mapped_column(
        default=False,
        server_default=sql.false(),
    )

    user: Mapped[User] = relationship(
        back_populates="flags",
    )
