from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Index, Numeric, String, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import UUIDMixin

from .base import Base


class SegmentStatistics(UUIDMixin, Base):
    __tablename__ = "segment_statistics"

    segment_code: Mapped[str] = mapped_column(String(20), nullable=False)
    segment_name: Mapped[str] = mapped_column(String(255), nullable=False)
    functional_group: Mapped[str] = mapped_column(String(100), nullable=False)
    area_range: Mapped[str | None] = mapped_column(String(20), nullable=True)
    object_format: Mapped[str] = mapped_column(String(50), nullable=False)
    floor: Mapped[str | None] = mapped_column(String(10), nullable=True)
    region: Mapped[str] = mapped_column(String(100), nullable=False)

    calculated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )
    method_version: Mapped[str] = mapped_column(String(20), nullable=False)
    quality_flag: Mapped[str] = mapped_column(String(20), nullable=False)
    raw_count: Mapped[int] = mapped_column(nullable=False)
    clean_count: Mapped[int] = mapped_column(nullable=False)

    metric_name: Mapped[str] = mapped_column(String(50), nullable=False)
    mean_value: Mapped[float | None] = mapped_column(Numeric(18, 4), nullable=True)
    median_value: Mapped[float | None] = mapped_column(Numeric(18, 4), nullable=True)
    min_value: Mapped[float | None] = mapped_column(Numeric(18, 4), nullable=True)
    max_value: Mapped[float | None] = mapped_column(Numeric(18, 4), nullable=True)
    quantile_low: Mapped[float | None] = mapped_column(Numeric(8, 4), nullable=True)
    quantile_high: Mapped[float | None] = mapped_column(Numeric(8, 4), nullable=True)

    __table_args__ = (
        UniqueConstraint(
            "segment_code",
            "metric_name",
            "calculated_at",
            name="uix_segment_code_metric_name_calculated_at",
        ),
        Index("idx_seg_stats_segment_code", "segment_code"),
        Index("idx_seg_stats_calculated_at", "calculated_at"),
        Index("idx_seg_stats_segment_code_time", "segment_code", "calculated_at"),
        Index("idx_seg_stats_metric_name", "metric_name"),
    )
