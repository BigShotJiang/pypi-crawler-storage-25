from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base

if TYPE_CHECKING:
    from . import RegionBase


class RegionAverages(IdMixin, TimestampMixin, Base):
    __tablename__ = "region_averages"

    region_base_id: Mapped[int] = mapped_column(
        ForeignKey("region_base.id", ondelete="CASCADE")
    )
    rent_m2: Mapped[float] = mapped_column(nullable=True)
    sale_m2: Mapped[float] = mapped_column(nullable=True)
    sale_density: Mapped[float] = mapped_column(nullable=True)
    rent_density: Mapped[float] = mapped_column(nullable=True)
    businesses_score: Mapped[float] = mapped_column(nullable=True)
    businesses_popularity: Mapped[float] = mapped_column(nullable=True)
    object_count: Mapped[float] = mapped_column(nullable=True)

    region_base: Mapped[RegionBase] = relationship(
        back_populates="averages",
    )
