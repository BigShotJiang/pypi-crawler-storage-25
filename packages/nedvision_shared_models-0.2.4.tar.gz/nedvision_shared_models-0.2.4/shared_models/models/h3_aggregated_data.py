from __future__ import annotations

from typing import Any

from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import TimestampMixin, UUIDMixin

from .base import Base


class H3AggregatedData(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "h3_aggregated_data"

    hexagon: Mapped[str] = mapped_column(unique=True)
    hexagon_size: Mapped[int]

    geo_analytics_data: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False)
    geo_checks_data: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False)
