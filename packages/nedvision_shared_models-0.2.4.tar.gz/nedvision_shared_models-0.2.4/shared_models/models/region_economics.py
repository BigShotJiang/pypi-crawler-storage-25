from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base

if TYPE_CHECKING:
    from . import RegionBase


class RegionEconomics(IdMixin, TimestampMixin, Base):
    __tablename__ = "region_economics"

    region_base_id: Mapped[int] = mapped_column(
        ForeignKey("region_base.id", ondelete="CASCADE"),
    )

    category: Mapped[str] = mapped_column(nullable=True)
    view: Mapped[str] = mapped_column(nullable=True)

    rental_rate: Mapped[float] = mapped_column(nullable=True)
    annual_rental_flow: Mapped[float] = mapped_column(nullable=True)
    monthly_rental_flow: Mapped[float] = mapped_column(nullable=True)
    first_floor_m2_revenue: Mapped[float] = mapped_column(nullable=True)
    other_floors_m2_revenue: Mapped[float] = mapped_column(nullable=True)
    payback_period: Mapped[float] = mapped_column(nullable=True)
    object_price: Mapped[float] = mapped_column(nullable=True)
    price_m2: Mapped[float] = mapped_column(nullable=True)
    avg_price_m2: Mapped[float] = mapped_column(nullable=True)
    m2_revenue_month: Mapped[float] = mapped_column(nullable=True)
    mrf_m2: Mapped[float] = mapped_column(nullable=True)
    roi: Mapped[float] = mapped_column(nullable=True)

    indexation: Mapped[float] = mapped_column(nullable=True)

    region_base: Mapped[RegionBase] = relationship(
        back_populates="region_economics",
    )
