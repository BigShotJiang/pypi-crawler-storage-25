from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

import sqlalchemy
from sqlalchemy import ARRAY, Float, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base

if TYPE_CHECKING:
    from .tenant_info import TenantInfo


class TenantTerm(Base):
    __tablename__ = "tenants_terms"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    tenant_id: Mapped[int] = mapped_column(
        ForeignKey("tenants_info.tenant_id", ondelete="CASCADE"), nullable=False
    )
    tenant_name: Mapped[str] = mapped_column(String(255), nullable=False)

    area_min: Mapped[float] = mapped_column(Float, nullable=False)
    area_max: Mapped[float] = mapped_column(Float, nullable=True)
    floor_location: Mapped[list[int]] = mapped_column(ARRAY(Integer), nullable=True)
    electrical_power: Mapped[float] = mapped_column(Float, nullable=True)
    communications: Mapped[bool] = mapped_column(nullable=True)
    separate_entrance: Mapped[bool] = mapped_column(nullable=True)
    ceiling_height: Mapped[float] = mapped_column(Float, nullable=True)

    map_verification: Mapped[bool] = mapped_column(
        nullable=True, default=False, server_default=sqlalchemy.text("false")
    )

    created_at: Mapped[datetime] = mapped_column(
        server_default=sqlalchemy.text("CURRENT_TIMESTAMP"), nullable=True
    )

    tenant_info: Mapped[TenantInfo] = relationship(
        back_populates="terms", foreign_keys=[tenant_id]
    )

    __table_args__ = (Index("idx_tenant_id", "tenant_id"),)
