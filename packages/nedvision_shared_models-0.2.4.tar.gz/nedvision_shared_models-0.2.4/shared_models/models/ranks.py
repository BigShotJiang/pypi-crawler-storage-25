from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import (DECIMAL, Boolean, CheckConstraint, Index, String, Text,
                        UniqueConstraint, sql)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import TimestampZoneMixin, UUIDMixin

from .base import Base

if TYPE_CHECKING:
    from . import UserRank


class Rank(UUIDMixin, TimestampZoneMixin, Base):
    __tablename__ = "ranks"

    code: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=True)
    min_xp_total: Mapped[float] = mapped_column(
        DECIMAL(precision=20, scale=2), nullable=False
    )
    is_manual: Mapped[bool] = mapped_column(
        Boolean, default=False, server_default=sql.false()
    )
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False)

    user_ranks: Mapped[list[UserRank]] = relationship(back_populates="rank")

    __table_args__ = (
        UniqueConstraint("code", name="uix_rank_code"),
        CheckConstraint("min_xp_total >= 0", name="check_min_xp_positive"),
        Index("idx_ranks_active_min_xp", "is_active", "min_xp_total"),
    )
