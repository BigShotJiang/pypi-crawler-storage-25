from datetime import datetime

from sqlalchemy import UUID, DateTime, ForeignKey, sql
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin

from .base import Base


class AnswerCollection(IdMixin, Base):
    __tablename__ = "answers_collections"

    user_id: Mapped[UUID] = mapped_column(
        ForeignKey(
            "users.id",
            ondelete="CASCADE",
        )
    )
    poll_code: Mapped[str] = mapped_column(
        ForeignKey(
            "polls.code",
            ondelete="CASCADE",
        )
    )
    is_active: Mapped[bool] = mapped_column(server_default=sql.true())
    last_checked_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
