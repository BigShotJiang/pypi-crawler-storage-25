from typing import Any

from sqlalchemy import JSON
from sqlalchemy.orm import DeclarativeBase, declared_attr

from shared_models.utils import CaseConverter


class Base(DeclarativeBase):
    __abstract__ = True

    @declared_attr.directive  # noqa
    @classmethod
    def __tablename__(cls) -> str:
        return f"{CaseConverter.camel_case_to_snake_case(cls.__name__)}s"

    type_annotation_map = {
        dict[str, Any]: JSON,
    }
