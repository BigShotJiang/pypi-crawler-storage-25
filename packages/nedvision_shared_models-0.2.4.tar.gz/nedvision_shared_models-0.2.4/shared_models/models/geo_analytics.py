from __future__ import annotations

from typing import Any

from sqlalchemy import ForeignKey
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import TimestampMixin, UUIDMixin

from .base import Base


class GeoAnalytics(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "geo_analytics"

    object_id: Mapped[int] = mapped_column(
        ForeignKey("objects.id", ondelete="SET NULL"),
        unique=True,
    )

    data: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False)
