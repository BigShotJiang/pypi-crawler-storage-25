from sqlalchemy import ForeignKey, Index, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base


class Mark(IdMixin, TimestampMixin, Base):
    object_id: Mapped[int] = mapped_column(ForeignKey("objects.id", ondelete="CASCADE"))

    name: Mapped[str] = mapped_column(String(100))
    current_value: Mapped[str]
    correct_value: Mapped[str]
    commentary: Mapped[str]

    __table_args__ = (
        UniqueConstraint(
            "name",
            "object_id",
            "current_value",
            name="uix_name_obj_id_current_value_questions",
        ),
        Index("idx_name_questions", "name"),
    )
