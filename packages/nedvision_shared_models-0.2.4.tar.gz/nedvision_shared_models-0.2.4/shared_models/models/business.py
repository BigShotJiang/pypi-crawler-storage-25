from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import BIGINT, ForeignKey, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base

if TYPE_CHECKING:
    from . import Address


class Business(IdMixin, TimestampMixin, Base):
    __tablename__ = "businesses"
    address_id: Mapped[int] = mapped_column(
        BIGINT, ForeignKey("addresses.id", ondelete="CASCADE")
    )
    yandex_id: Mapped[int] = mapped_column(BIGINT)
    name: Mapped[str]
    type: Mapped[str] = mapped_column(String(100))
    is_federal: Mapped[bool] = mapped_column(nullable=True)

    address: Mapped[Address] = relationship(
        back_populates="businesses",
    )

    __table_args__ = (UniqueConstraint("yandex_id", name="uix_businesses_yandex_id"),)
