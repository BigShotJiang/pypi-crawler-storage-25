from sqlalchemy import ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import TimestampZoneMixin, UUIDMixin

from .base import Base


class BadObject(Base, TimestampZoneMixin, UUIDMixin):
    object_id: Mapped[int] = mapped_column(ForeignKey("objects.id", ondelete="CASCADE"))
    real_price: Mapped[float | None] = mapped_column(nullable=True)
    on_auction: Mapped[bool | None] = mapped_column(nullable=True)
