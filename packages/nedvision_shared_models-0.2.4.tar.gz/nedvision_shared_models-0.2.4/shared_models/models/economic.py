from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import BIGINT, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base

if TYPE_CHECKING:
    from . import Object


class Economic(IdMixin, TimestampMixin, Base):
    object_id: Mapped[int] = mapped_column(
        ForeignKey("objects.id", ondelete="CASCADE"),
        unique=True,
    )

    h3: Mapped[str] = mapped_column(nullable=False, index=True)
    object_price: Mapped[int] = mapped_column(BIGINT, nullable=False)

    annual_rental_flow: Mapped[float] = mapped_column(nullable=True)
    monthly_rental_flow: Mapped[float] = mapped_column(nullable=True)
    mrf_m2: Mapped[float] = mapped_column(nullable=True)
    indexation: Mapped[float] = mapped_column(nullable=True)
    payback_period: Mapped[float] = mapped_column(nullable=True)

    first_floor_m2_revenue: Mapped[float] = mapped_column(nullable=True)
    other_floors_m2_revenue: Mapped[float] = mapped_column(nullable=True)
    m2_revenue_month: Mapped[float] = mapped_column(nullable=True)

    rental_rate: Mapped[float] = mapped_column(nullable=True)

    price_m2: Mapped[float] = mapped_column(nullable=False)
    avg_price_m2: Mapped[float] = mapped_column(nullable=True)

    roi: Mapped[float] = mapped_column(nullable=True)

    object: Mapped[Object] = relationship(
        back_populates="economic",
    )
