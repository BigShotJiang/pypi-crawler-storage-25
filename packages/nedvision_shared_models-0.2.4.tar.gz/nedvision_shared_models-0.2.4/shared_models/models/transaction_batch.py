from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import DECIMAL, Index, Integer
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql.sqltypes import DateTime

from shared_models.enums import TransactionBatchStatus, TransactionBatchType
from shared_models.mixins import TimestampZoneMixin, UUIDMixin

from .base import Base

if TYPE_CHECKING:
    from . import Transaction


class TransactionBatch(UUIDMixin, TimestampZoneMixin, Base):
    __tablename__ = "transaction_batches"

    batch_type: Mapped[TransactionBatchType]
    status: Mapped[TransactionBatchStatus]
    transaction_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    total_amount: Mapped[float] = mapped_column(
        DECIMAL(precision=30, scale=18), default=0, nullable=False
    )
    processed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    meta: Mapped[dict] = mapped_column(JSONB)

    transactions: Mapped[list[Transaction]] = relationship(
        back_populates="batch",
    )

    __table_args__ = (
        Index("idx_transaction_batches_type_status", "batch_type", "status"),
    )
