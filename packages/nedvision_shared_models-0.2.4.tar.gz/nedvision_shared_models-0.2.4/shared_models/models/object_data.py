from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

import sqlalchemy
from sqlalchemy import BIGINT, DateTime, ForeignKey, Index, String, func
from sqlalchemy.dialects.postgresql import JSONB, TSVECTOR
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import UUIDMixin

from .base import Base

if TYPE_CHECKING:
    from .. import ComparedObject, Object
    from . import Tenant


class ObjectData(UUIDMixin, Base):
    __tablename__ = "objects_data"

    url: Mapped[str]
    object_id: Mapped[int] = mapped_column(
        ForeignKey("objects.id", ondelete="CASCADE"),
        unique=True,
    )
    images: Mapped[list[dict[str, str]]] = mapped_column(
        JSONB,
        nullable=False,
    )
    title: Mapped[str] = mapped_column(nullable=False)
    description: Mapped[str] = mapped_column(nullable=False)
    description_potential_rental_flow: Mapped[str] = mapped_column(nullable=True)
    published_at: Mapped[datetime] = mapped_column(nullable=False)
    address: Mapped[str] = mapped_column(nullable=False)
    price: Mapped[int] = mapped_column(BIGINT, nullable=False)
    area: Mapped[float] = mapped_column(nullable=False)
    building_type: Mapped[str] = mapped_column(nullable=True)
    type: Mapped[str] = mapped_column(nullable=True)
    separate_entrance: Mapped[str] = mapped_column(nullable=True)
    main_entrance: Mapped[str] = mapped_column(nullable=True)
    city: Mapped[str] = mapped_column(nullable=True)
    region: Mapped[str] = mapped_column(nullable=True)

    floors_count: Mapped[int] = mapped_column(nullable=True)
    location_floor: Mapped[int] = mapped_column(nullable=True)
    ceiling_height: Mapped[float] = mapped_column(nullable=True)

    heating: Mapped[str] = mapped_column(nullable=False)
    power_capacity: Mapped[int] = mapped_column(nullable=True)

    regions: Mapped[dict[str, str]] = mapped_column(
        JSONB,
        nullable=False,
    )
    distance_ac: Mapped[float] = mapped_column(nullable=True)
    distance_c: Mapped[float] = mapped_column(nullable=True)
    distance_r: Mapped[float] = mapped_column(nullable=True)

    profile: Mapped[str] = mapped_column(nullable=False)
    rating: Mapped[float] = mapped_column(nullable=False)
    location_rating: Mapped[float] = mapped_column(nullable=False)
    economy_rating: Mapped[float] = mapped_column(nullable=False)
    potential_rating: Mapped[float] = mapped_column(nullable=False)
    investment_attractiveness: Mapped[float] = mapped_column(nullable=False)
    payback_period: Mapped[int] = mapped_column(nullable=True)
    annual_rental_flow: Mapped[int] = mapped_column(BIGINT, nullable=True)
    monthly_rental_flow: Mapped[int] = mapped_column(BIGINT, nullable=True)
    m2_revenue_month: Mapped[float] = mapped_column(nullable=True)
    price_m2: Mapped[float] = mapped_column(nullable=False)
    tenants: Mapped[str] = mapped_column(nullable=True)
    parking_info: Mapped[str] = mapped_column(nullable=True)
    total_vacancy_pct: Mapped[float] = mapped_column(nullable=True)
    rental_rate: Mapped[float] = mapped_column(nullable=True)

    is_corner: Mapped[bool] = mapped_column(nullable=True)
    is_facade: Mapped[bool] = mapped_column(nullable=True)

    age: Mapped[int] = mapped_column(nullable=True)
    rent_increase_ability: Mapped[bool] = mapped_column(
        nullable=False, default=False, server_default=sqlalchemy.sql.false()
    )
    readiness: Mapped[str] = mapped_column(nullable=True)

    region_rating: Mapped[dict[str, int]] = mapped_column(JSONB, nullable=True)
    category: Mapped[str] = mapped_column(String(length=50), nullable=True)
    actual: Mapped[bool] = mapped_column(nullable=True)
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())

    search_vector: Mapped[TSVECTOR] = mapped_column(
        TSVECTOR,
        nullable=True,
    )

    liq_rating: Mapped[float | None] = mapped_column(nullable=True)
    calculations: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    calculations_updated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    actuality_checked_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
    inactive_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    object: Mapped[Object] = relationship(
        back_populates="object_data",
    )

    tenants_data: Mapped[list[Tenant]] = relationship(
        back_populates="object",
    )

    compared_objects: Mapped[list[ComparedObject]] = relationship(
        back_populates="object_data",
    )

    __table_args__ = (
        Index(
            "idx_objects_data_search_vector",
            "search_vector",
            postgresql_using="gin",
        ),
        Index(
            "idx_objects_data_address_trgm",
            "address",
            postgresql_using="gin",
            postgresql_ops={"address": "gin_trgm_ops"},
        ),
        Index(
            "idx_objects_data_title_trgm",
            "title",
            postgresql_using="gin",
            postgresql_ops={"title": "gin_trgm_ops"},
        ),
        Index(
            "idx_objects_data_description_trgm",
            "description",
            postgresql_using="gin",
            postgresql_ops={"description": "gin_trgm_ops"},
        ),
        {"schema": "webapp"},
    )
