from datetime import date

from sqlalchemy import DATE
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base


class GoogleSpreadsheet(IdMixin, TimestampMixin, Base):
    __tablename__ = "google_spreadsheets"

    spreadsheet_id: Mapped[str] = mapped_column(unique=True)
    url: Mapped[str]
    start_date: Mapped[date] = mapped_column(DATE, nullable=False)
    end_date: Mapped[date] = mapped_column(DATE, nullable=False)
    is_actual: Mapped[bool] = mapped_column(default=False)
