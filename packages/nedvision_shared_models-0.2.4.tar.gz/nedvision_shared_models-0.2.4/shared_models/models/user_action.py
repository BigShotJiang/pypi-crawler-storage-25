from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

import sqlalchemy
from sqlalchemy import UUID, Boolean, ForeignKey, Index, String, func, text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql.sqltypes import DateTime

from shared_models.mixins import TimestampZoneMixin, UUIDMixin

from .base import Base

if TYPE_CHECKING:
    from . import Action, User


class UserAction(UUIDMixin, TimestampZoneMixin, Base):
    __tablename__ = "user_action"

    user_id: Mapped[UUID] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    action_id: Mapped[UUID] = mapped_column(
        ForeignKey("actions.id", ondelete="RESTRICT"), nullable=True
    )
    target_id: Mapped[str] = mapped_column(String, nullable=True)
    bucket_second: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.timezone("UTC", func.date_trunc("second", func.now())),
    )
    spam: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default=sqlalchemy.sql.false()
    )
    is_calculated: Mapped[bool] = mapped_column(Boolean, nullable=True)

    user: Mapped[User] = relationship(
        back_populates="user_actions",
    )
    action: Mapped[Action] = relationship(
        back_populates="user_actions",
    )

    __table_args__ = (
        Index("idx_user_action_spam", "user_id", "action_id", "bucket_second"),
        Index("idx_user_action_24h", "user_id", "action_id", text("created_at DESC")),
    )
