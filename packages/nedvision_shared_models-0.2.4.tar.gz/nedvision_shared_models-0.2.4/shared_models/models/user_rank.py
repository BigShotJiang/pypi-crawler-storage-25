from __future__ import annotations

from typing import TYPE_CHECKING
from uuid import UUID

from sqlalchemy import ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import TimestampMixin, UUIDMixin

from .base import Base

if TYPE_CHECKING:
    from . import Rank, User


class UserRank(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "user_ranks"
    user_id: Mapped[UUID] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
    )
    rank_id: Mapped[UUID] = mapped_column(
        ForeignKey("ranks.id", ondelete="CASCADE"), nullable=False
    )

    user: Mapped[User] = relationship(
        back_populates="user_rank",
    )
    rank: Mapped[Rank] = relationship(
        back_populates="user_ranks",
    )
