from uuid import UUID

from sqlalchemy import ForeignKey
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import TimestampMixin, UUIDMixin

from .base import Base


class PdfDataView(Base, TimestampMixin, UUIDMixin):
    __tablename__ = "pdf_data_view"

    object_data_id: Mapped[UUID] = mapped_column(
        ForeignKey("webapp.objects_data.id", ondelete="CASCADE"),
        unique=True,
    )
    pages_data: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
