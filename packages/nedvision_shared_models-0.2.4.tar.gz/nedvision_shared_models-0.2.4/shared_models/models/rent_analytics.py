from __future__ import annotations

from sqlalchemy import Index, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base


class RentAnalytics(IdMixin, TimestampMixin, Base):
    __tablename__ = "rent_analytics"

    h3: Mapped[str] = mapped_column(nullable=False)
    view: Mapped[str] = mapped_column(nullable=False)
    avg_rent_cell: Mapped[float] = mapped_column(nullable=False)
    avg_rent_m2: Mapped[float] = mapped_column(nullable=False)
    object_count_cell: Mapped[int] = mapped_column(nullable=False)
    density: Mapped[float] = mapped_column(nullable=False)

    __table_args__ = (
        UniqueConstraint("h3", "view", name="uix_h3_view"),
        Index("idx_rent_analytics_h3", "h3"),
    )
