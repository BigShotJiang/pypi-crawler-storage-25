from sqlalchemy import Boolean, Enum, UniqueConstraint, sql
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.enums.feature import FeatureCode
from shared_models.mixins import TimestampZoneMixin, UUIDMixin

from .base import Base


class Feature(UUIDMixin, Base, TimestampZoneMixin):
    code: Mapped[FeatureCode] = mapped_column(
        Enum(FeatureCode, name="feature_code", create_type=True),
        unique=True,
        nullable=False,
    )
    name_ru: Mapped[str] = mapped_column(nullable=False)
    name_eng: Mapped[str] = mapped_column(nullable=False)
    order: Mapped[int] = mapped_column(nullable=False)
    is_active: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        server_default=sql.true(),
    )

    __table_args__ = (
        UniqueConstraint(
            "code",
            "order",
            name="uq_feature_code_order",
        ),
    )
