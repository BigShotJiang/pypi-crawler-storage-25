from datetime import datetime
from uuid import UUID

from sqlalchemy import ForeignKey, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import UUIDMixin

from .base import Base


class CollectionCounterItem(UUIDMixin, Base):
    counter_id: Mapped[UUID] = mapped_column(
        ForeignKey("collection_counters.id", ondelete="CASCADE")
    )
    object_data_id: Mapped[UUID] = mapped_column(
        ForeignKey("webapp.objects_data.id", ondelete="CASCADE")
    )
    object_title: Mapped[str] = mapped_column(nullable=False)
    added_at: Mapped[datetime] = mapped_column(server_default=func.now())

    __table_args__ = (
        UniqueConstraint(
            "counter_id", "object_data_id", name="uix_counter_id_object_data_id"
        ),
    )
