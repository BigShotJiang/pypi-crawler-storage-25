from sqlalchemy.orm import Mapped, mapped_column

from .base import Base


class Collection(Base):
    code: Mapped[str] = mapped_column(primary_key=True)
