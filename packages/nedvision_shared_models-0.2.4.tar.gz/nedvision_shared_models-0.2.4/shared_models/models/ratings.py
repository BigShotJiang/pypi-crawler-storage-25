from __future__ import annotations

from uuid import UUID

from sqlalchemy import ForeignKey
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import TimestampZoneMixin, UUIDMixin

from .base import Base


class Rating(UUIDMixin, Base, TimestampZoneMixin):
    object_data_id: Mapped[UUID] = mapped_column(
        ForeignKey("webapp.objects_data.id", ondelete="CASCADE"), unique=True
    )

    object_rating_details: Mapped[dict | None] = mapped_column(
        JSONB,
        nullable=True,
    )

    regions_rating_details: Mapped[dict | None] = mapped_column(
        JSONB,
        nullable=True,
    )

    location_rating_details: Mapped[dict | None] = mapped_column(
        JSONB,
        nullable=True,
    )

    economy_rating_details: Mapped[dict | None] = mapped_column(
        JSONB,
        nullable=True,
    )

    potential_rating_details: Mapped[dict | None] = mapped_column(
        JSONB,
        nullable=True,
    )
