from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import BIGINT, JSON, ForeignKey, Index
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base

if TYPE_CHECKING:
    from . import Object


class SaleBase(IdMixin, TimestampMixin, Base):
    __tablename__ = "sale_base"

    object_id: Mapped[int] = mapped_column(
        BIGINT, ForeignKey("objects.id", ondelete="CASCADE"), unique=True
    )
    h3: Mapped[str] = mapped_column(nullable=False)
    coordinates: Mapped[dict[str, float]] = mapped_column(JSON, nullable=False)
    title: Mapped[str] = mapped_column(nullable=False)
    url: Mapped[str] = mapped_column(nullable=False)
    price: Mapped[int] = mapped_column(BIGINT, nullable=False)
    description: Mapped[str] = mapped_column(nullable=False)
    address: Mapped[str] = mapped_column(nullable=False)
    area: Mapped[int] = mapped_column(nullable=False)
    view: Mapped[str] = mapped_column(nullable=False)
    floor: Mapped[int] = mapped_column(nullable=False)
    ceiling_height: Mapped[str] = mapped_column(nullable=True)
    tenants: Mapped[str] = mapped_column(nullable=True)

    object: Mapped[Object] = relationship(
        back_populates="sale_base",
    )

    __table_args__ = (Index("idx_sale_base_h3", "h3"),)
