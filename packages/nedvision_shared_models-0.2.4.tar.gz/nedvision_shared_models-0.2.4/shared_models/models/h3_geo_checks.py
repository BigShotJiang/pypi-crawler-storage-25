from __future__ import annotations

from datetime import datetime
from typing import Optional

import sqlalchemy
from sqlalchemy import DateTime, Integer, String
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base


class H3GeoChecks(Base):
    __tablename__ = "h3_geo_checks"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)

    hexagon_id: Mapped[Optional[str]] = mapped_column(String(20), nullable=False)
    hexagon_resolution: Mapped[Optional[int]] = mapped_column(Integer, nullable=False)
    geo_checks_data: Mapped[Optional[dict]] = mapped_column(
        JSONB, nullable=True, default=None
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=sqlalchemy.text("CURRENT_TIMESTAMP"), nullable=False
    )
