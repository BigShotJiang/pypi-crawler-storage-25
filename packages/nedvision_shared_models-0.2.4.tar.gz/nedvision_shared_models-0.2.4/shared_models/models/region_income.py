from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import BIGINT, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base

if TYPE_CHECKING:
    from . import RegionBase


class RegionIncome(IdMixin, TimestampMixin, Base):
    __tablename__ = "region_income"

    region_base_id: Mapped[int] = mapped_column(
        ForeignKey("region_base.id", ondelete="CASCADE"), unique=True
    )
    income_0_20000: Mapped[int] = mapped_column(BIGINT, nullable=True)
    income_20000_30000: Mapped[int] = mapped_column(BIGINT, nullable=True)
    income_30000_40000: Mapped[int] = mapped_column(BIGINT, nullable=True)
    income_40000_50000: Mapped[int] = mapped_column(BIGINT, nullable=True)
    income_50000_60000: Mapped[int] = mapped_column(BIGINT, nullable=True)
    income_60000_70000: Mapped[int] = mapped_column(BIGINT, nullable=True)
    income_70000_80000: Mapped[int] = mapped_column(BIGINT, nullable=True)
    income_80000_90000: Mapped[int] = mapped_column(BIGINT, nullable=True)
    income_90000_100000: Mapped[int] = mapped_column(BIGINT, nullable=True)
    income_100000_110000: Mapped[int] = mapped_column(BIGINT, nullable=True)
    income_110000_120000: Mapped[int] = mapped_column(BIGINT, nullable=True)
    income_120000_130000: Mapped[int] = mapped_column(BIGINT, nullable=True)
    income_130000_140000: Mapped[int] = mapped_column(BIGINT, nullable=True)
    income_140000_150000: Mapped[int] = mapped_column(BIGINT, nullable=True)
    income_150000_200000: Mapped[int] = mapped_column(BIGINT, nullable=True)
    income_200000_250000: Mapped[int] = mapped_column(BIGINT, nullable=True)
    income_250000_300000: Mapped[int] = mapped_column(BIGINT, nullable=True)
    income_300000_400000: Mapped[int] = mapped_column(BIGINT, nullable=True)
    income_400000_500000: Mapped[int] = mapped_column(BIGINT, nullable=True)
    income_500000_plus: Mapped[int] = mapped_column(BIGINT, nullable=True)

    region_base: Mapped[RegionBase] = relationship(
        back_populates="region_income",
    )
