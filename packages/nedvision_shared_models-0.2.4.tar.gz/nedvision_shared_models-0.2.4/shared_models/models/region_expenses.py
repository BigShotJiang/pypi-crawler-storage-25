from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base

if TYPE_CHECKING:
    from . import RegionBase


class RegionExpenses(IdMixin, TimestampMixin, Base):
    __tablename__ = "region_expenses"

    region_base_id: Mapped[int] = mapped_column(
        ForeignKey("region_base.id", ondelete="CASCADE"), unique=True
    )

    flowers: Mapped[float] = mapped_column(nullable=False, default=0.0)
    financial_services: Mapped[float] = mapped_column(nullable=False, default=0.0)
    fast_food: Mapped[float] = mapped_column(nullable=False, default=0.0)
    travel_agencies: Mapped[float] = mapped_column(nullable=False, default=0.0)
    transport: Mapped[float] = mapped_column(nullable=False, default=0.0)
    fuel: Mapped[float] = mapped_column(nullable=False, default=0.0)
    taxi: Mapped[float] = mapped_column(nullable=False, default=0.0)
    supermarkets: Mapped[float] = mapped_column(nullable=False, default=0.0)
    sports_goods: Mapped[float] = mapped_column(nullable=False, default=0.0)
    services: Mapped[float] = mapped_column(nullable=False, default=0.0)
    telecom: Mapped[float] = mapped_column(nullable=False, default=0.0)
    restaurants: Mapped[float] = mapped_column(nullable=False, default=0.0)
    misc_goods: Mapped[float] = mapped_column(nullable=False, default=0.0)
    entertainment: Mapped[float] = mapped_column(nullable=False, default=0.0)
    budget_payments: Mapped[float] = mapped_column(nullable=False, default=0.0)
    hotels: Mapped[float] = mapped_column(nullable=False, default=0.0)
    clothing_shoes: Mapped[float] = mapped_column(nullable=False, default=0.0)
    nko: Mapped[float] = mapped_column(nullable=False, default=0.0)
    cash: Mapped[float] = mapped_column(nullable=False, default=0.0)
    medical_services: Mapped[float] = mapped_column(nullable=False, default=0.0)
    beauty: Mapped[float] = mapped_column(nullable=False, default=0.0)
    books: Mapped[float] = mapped_column(nullable=False, default=0.0)
    cinema: Mapped[float] = mapped_column(nullable=False, default=0.0)
    carsharing: Mapped[float] = mapped_column(nullable=False, default=0.0)
    utilities: Mapped[float] = mapped_column(nullable=False, default=0.0)
    pets: Mapped[float] = mapped_column(nullable=False, default=0.0)
    railway_tickets: Mapped[float] = mapped_column(nullable=False, default=0.0)
    home_repair: Mapped[float] = mapped_column(nullable=False, default=0.0)
    pharmacy: Mapped[float] = mapped_column(nullable=False, default=0.0)
    auto_services: Mapped[float] = mapped_column(nullable=False, default=0.0)
    plane_tickets: Mapped[float] = mapped_column(nullable=False, default=0.0)

    region_base: Mapped[RegionBase] = relationship(
        back_populates="region_expenses",
    )
