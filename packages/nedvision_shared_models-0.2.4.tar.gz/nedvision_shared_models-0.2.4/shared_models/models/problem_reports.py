from uuid import UUID

from sqlalchemy import ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin, TimestampZoneMixin

from .base import Base


class ProblemReport(Base, IdMixin, TimestampZoneMixin):
    __tablename__ = "problem_reports"

    user_id: Mapped[UUID] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    problem_type_id: Mapped[int] = mapped_column(
        ForeignKey("problem_types.id", ondelete="RESTRICT")
    )
    object_id: Mapped[int] = mapped_column(
        ForeignKey("objects.id", ondelete="SET NULL"), nullable=True
    )
