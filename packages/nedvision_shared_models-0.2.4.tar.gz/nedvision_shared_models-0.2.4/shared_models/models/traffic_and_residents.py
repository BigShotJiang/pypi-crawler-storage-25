from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base

if TYPE_CHECKING:
    from . import RegionBase


class TrafficAndResidents(IdMixin, TimestampMixin, Base):
    __tablename__ = "traffic_and_residents"

    region_base_id: Mapped[int] = mapped_column(
        ForeignKey("region_base.id", ondelete="CASCADE"), unique=True
    )
    avg_total_residents: Mapped[float] = mapped_column(nullable=True)
    avg_daily_traffic: Mapped[float] = mapped_column(nullable=True)
    avg_monthly_traffic: Mapped[float] = mapped_column(nullable=True)

    region_base: Mapped[RegionBase] = relationship(
        back_populates="traffic_and_residents",
    )
