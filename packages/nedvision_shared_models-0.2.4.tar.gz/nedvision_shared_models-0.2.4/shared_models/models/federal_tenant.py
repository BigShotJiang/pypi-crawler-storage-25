from sqlalchemy import VARCHAR
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin, TimestampMixin

from .base import Base


class FederalTenant(IdMixin, TimestampMixin, Base):
    __tablename__ = "federal_tenants"

    name: Mapped[str] = mapped_column(VARCHAR(100), nullable=False, unique=True)
    href: Mapped[str] = mapped_column(unique=True, nullable=False)
    description: Mapped[str]
