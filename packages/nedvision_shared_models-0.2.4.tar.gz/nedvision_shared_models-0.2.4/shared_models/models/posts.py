from datetime import datetime

from sqlalchemy import BIGINT, TEXT, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.mixins import IdMixin

from .base import Base


class Post(IdMixin, Base):
    channel_id: Mapped[int] = mapped_column(BIGINT, nullable=False)
    channel_name: Mapped[str] = mapped_column(TEXT, nullable=True)
    post_id: Mapped[int] = mapped_column(nullable=False)
    post_date: Mapped[datetime] = mapped_column(nullable=True)
    message_text: Mapped[str] = mapped_column(nullable=True)
    files: Mapped[dict] = mapped_column(JSONB, server_default="[]", nullable=False)
    saved_at: Mapped[datetime] = mapped_column(
        server_default=func.now(), nullable=False
    )

    table_args = (UniqueConstraint("channel_id", "post_id", name="uix_channel_post"),)
