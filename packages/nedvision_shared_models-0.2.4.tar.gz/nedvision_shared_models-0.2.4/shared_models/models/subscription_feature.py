from uuid import UUID

from sqlalchemy import (Boolean, Enum, ForeignKey, Integer, UniqueConstraint,
                        sql)
from sqlalchemy.orm import Mapped, mapped_column

from shared_models.enums.feature import LimitPeriod, LimitUnit
from shared_models.mixins import TimestampZoneMixin, UUIDMixin

from .base import Base


class SubscriptionFeature(UUIDMixin, Base, TimestampZoneMixin):
    __tablename__ = "subscription_features"

    subscription_id: Mapped[UUID] = mapped_column(
        ForeignKey("subscriptions.id", ondelete="CASCADE"),
        nullable=False,
    )
    feature_id: Mapped[UUID] = mapped_column(
        ForeignKey("features.id", ondelete="CASCADE"),
        nullable=False,
    )
    is_available: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        server_default=sql.false(),
    )
    limit_value: Mapped[int | None] = mapped_column(Integer, nullable=True)
    limit_period: Mapped[LimitPeriod | None] = mapped_column(
        Enum(LimitPeriod, name="limit_period", create_type=True),
        nullable=True,
    )
    limit_unit: Mapped[LimitUnit | None] = mapped_column(
        Enum(LimitUnit, name="limit_unit", create_type=True),
        nullable=True,
    )
    limit_description_ru: Mapped[str] = mapped_column(nullable=False)
    limit_description_eng: Mapped[str] = mapped_column(nullable=False)

    __table_args__ = (
        UniqueConstraint(
            "subscription_id",
            "feature_id",
            name="uq_subscription_feature",
        ),
    )
