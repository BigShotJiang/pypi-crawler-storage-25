from datetime import datetime

from sqlalchemy import func
from sqlalchemy.orm import Mapped, declarative_mixin, mapped_column
from sqlalchemy.sql.sqltypes import DateTime


@declarative_mixin
class TimestampZoneMixin:
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.timezone("UTC", func.now()),
        sort_order=20,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.timezone("UTC", func.now()),
        onupdate=func.timezone("UTC", func.now()),
        sort_order=21,
    )
