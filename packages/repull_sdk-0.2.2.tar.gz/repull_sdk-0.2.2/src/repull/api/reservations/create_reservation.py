from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_reservation_body import CreateReservationBody
from ...models.reservation import Reservation
from typing import cast



def _get_kwargs(
    *,
    body: CreateReservationBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/reservations",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Reservation | None:
    if response.status_code == 201:
        response_201 = Reservation.from_dict(response.json())



        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Reservation]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateReservationBody,

) -> Response[Reservation]:
    """ Create a reservation

     Create a reservation in the source PMS. Required fields depend on the connected provider (e.g.
    Airbnb requires guest email; Booking.com requires hotel id). Validation errors return 422 with the
    offending `field` populated.

    Args:
        body (CreateReservationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Reservation]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CreateReservationBody,

) -> Reservation | None:
    """ Create a reservation

     Create a reservation in the source PMS. Required fields depend on the connected provider (e.g.
    Airbnb requires guest email; Booking.com requires hotel id). Validation errors return 422 with the
    offending `field` populated.

    Args:
        body (CreateReservationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Reservation
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateReservationBody,

) -> Response[Reservation]:
    """ Create a reservation

     Create a reservation in the source PMS. Required fields depend on the connected provider (e.g.
    Airbnb requires guest email; Booking.com requires hotel id). Validation errors return 422 with the
    offending `field` populated.

    Args:
        body (CreateReservationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Reservation]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CreateReservationBody,

) -> Reservation | None:
    """ Create a reservation

     Create a reservation in the source PMS. Required fields depend on the connected provider (e.g.
    Airbnb requires guest email; Booking.com requires hotel id). Validation errors return 422 with the
    offending `field` populated.

    Args:
        body (CreateReservationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Reservation
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
