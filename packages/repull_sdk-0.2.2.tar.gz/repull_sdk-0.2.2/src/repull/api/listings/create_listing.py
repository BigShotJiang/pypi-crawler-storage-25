from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error import Error
from ...models.listing_create_request import ListingCreateRequest
from ...models.listing_create_response import ListingCreateResponse
from typing import cast



def _get_kwargs(
    *,
    body: ListingCreateRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/listings",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Error | ListingCreateResponse | None:
    if response.status_code == 201:
        response_201 = ListingCreateResponse.from_dict(response.json())



        return response_201

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())



        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Error | ListingCreateResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ListingCreateRequest,

) -> Response[Error | ListingCreateResponse]:
    """ Create a Repull listing

     Create a new vacation-rental listing under the authenticated workspace. The listing is stored in the
    canonical Vanio listings tables and can be published to multiple channels (Airbnb, Booking.com) via
    the publish endpoints.

    Args:
        body (ListingCreateRequest): Inputs for `POST /v1/listings`. Provide enough address detail
            (street + city + lat/lng) for downstream Airbnb publish to work.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | ListingCreateResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: ListingCreateRequest,

) -> Error | ListingCreateResponse | None:
    """ Create a Repull listing

     Create a new vacation-rental listing under the authenticated workspace. The listing is stored in the
    canonical Vanio listings tables and can be published to multiple channels (Airbnb, Booking.com) via
    the publish endpoints.

    Args:
        body (ListingCreateRequest): Inputs for `POST /v1/listings`. Provide enough address detail
            (street + city + lat/lng) for downstream Airbnb publish to work.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | ListingCreateResponse
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ListingCreateRequest,

) -> Response[Error | ListingCreateResponse]:
    """ Create a Repull listing

     Create a new vacation-rental listing under the authenticated workspace. The listing is stored in the
    canonical Vanio listings tables and can be published to multiple channels (Airbnb, Booking.com) via
    the publish endpoints.

    Args:
        body (ListingCreateRequest): Inputs for `POST /v1/listings`. Provide enough address detail
            (street + city + lat/lng) for downstream Airbnb publish to work.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | ListingCreateResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: ListingCreateRequest,

) -> Error | ListingCreateResponse | None:
    """ Create a Repull listing

     Create a new vacation-rental listing under the authenticated workspace. The listing is stored in the
    canonical Vanio listings tables and can be published to multiple channels (Airbnb, Booking.com) via
    the publish endpoints.

    Args:
        body (ListingCreateRequest): Inputs for `POST /v1/listings`. Provide enough address detail
            (street + city + lat/lng) for downstream Airbnb publish to work.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | ListingCreateResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
