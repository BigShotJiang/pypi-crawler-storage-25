from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.delete_studio_deployment_response_200 import DeleteStudioDeploymentResponse200
from ...models.studio_error import StudioError
from typing import cast
from uuid import UUID



def _get_kwargs(
    id: UUID,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/api/studio/deployments/{id}".format(id=quote(str(id), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> DeleteStudioDeploymentResponse200 | StudioError | None:
    if response.status_code == 200:
        response_200 = DeleteStudioDeploymentResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 401:
        response_401 = StudioError.from_dict(response.json())



        return response_401

    if response.status_code == 404:
        response_404 = StudioError.from_dict(response.json())



        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[DeleteStudioDeploymentResponse200 | StudioError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,

) -> Response[DeleteStudioDeploymentResponse200 | StudioError]:
    """ Delete a Studio deployment

     Tears down a deployment — releases the Fly.io machine, removes the DNS record, and marks the
    deployment as deleted. The underlying project is unaffected.

    Args:
        id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteStudioDeploymentResponse200 | StudioError]
     """


    kwargs = _get_kwargs(
        id=id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,

) -> DeleteStudioDeploymentResponse200 | StudioError | None:
    """ Delete a Studio deployment

     Tears down a deployment — releases the Fly.io machine, removes the DNS record, and marks the
    deployment as deleted. The underlying project is unaffected.

    Args:
        id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteStudioDeploymentResponse200 | StudioError
     """


    return sync_detailed(
        id=id,
client=client,

    ).parsed

async def asyncio_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,

) -> Response[DeleteStudioDeploymentResponse200 | StudioError]:
    """ Delete a Studio deployment

     Tears down a deployment — releases the Fly.io machine, removes the DNS record, and marks the
    deployment as deleted. The underlying project is unaffected.

    Args:
        id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteStudioDeploymentResponse200 | StudioError]
     """


    kwargs = _get_kwargs(
        id=id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,

) -> DeleteStudioDeploymentResponse200 | StudioError | None:
    """ Delete a Studio deployment

     Tears down a deployment — releases the Fly.io machine, removes the DNS record, and marks the
    deployment as deleted. The underlying project is unaffected.

    Args:
        id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteStudioDeploymentResponse200 | StudioError
     """


    return (await asyncio_detailed(
        id=id,
client=client,

    )).parsed
