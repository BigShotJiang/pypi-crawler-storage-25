from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.airbnb_listing import AirbnbListing
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    id: str,
    *,
    include: str | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["include"] = include


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/channels/airbnb/listings/{id}".format(id=quote(str(id), safe=""),),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> AirbnbListing | None:
    if response.status_code == 200:
        response_200 = AirbnbListing.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[AirbnbListing]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    include: str | Unset = UNSET,

) -> Response[AirbnbListing]:
    """ Get Airbnb listing

     Fetch all Airbnb connection rows for a single Vanio listing id. A property may be linked from
    multiple Airbnb hosts — every match is returned. Pass `?include=amenities` to enrich each row with
    its current Airbnb amenities.

    Args:
        id (str):
        include (str | Unset):  Example: amenities.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AirbnbListing]
     """


    kwargs = _get_kwargs(
        id=id,
include=include,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    include: str | Unset = UNSET,

) -> AirbnbListing | None:
    """ Get Airbnb listing

     Fetch all Airbnb connection rows for a single Vanio listing id. A property may be linked from
    multiple Airbnb hosts — every match is returned. Pass `?include=amenities` to enrich each row with
    its current Airbnb amenities.

    Args:
        id (str):
        include (str | Unset):  Example: amenities.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AirbnbListing
     """


    return sync_detailed(
        id=id,
client=client,
include=include,

    ).parsed

async def asyncio_detailed(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    include: str | Unset = UNSET,

) -> Response[AirbnbListing]:
    """ Get Airbnb listing

     Fetch all Airbnb connection rows for a single Vanio listing id. A property may be linked from
    multiple Airbnb hosts — every match is returned. Pass `?include=amenities` to enrich each row with
    its current Airbnb amenities.

    Args:
        id (str):
        include (str | Unset):  Example: amenities.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AirbnbListing]
     """


    kwargs = _get_kwargs(
        id=id,
include=include,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    include: str | Unset = UNSET,

) -> AirbnbListing | None:
    """ Get Airbnb listing

     Fetch all Airbnb connection rows for a single Vanio listing id. A property may be linked from
    multiple Airbnb hosts — every match is returned. Pass `?include=amenities` to enrich each row with
    its current Airbnb amenities.

    Args:
        id (str):
        include (str | Unset):  Example: amenities.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AirbnbListing
     """


    return (await asyncio_detailed(
        id=id,
client=client,
include=include,

    )).parsed
