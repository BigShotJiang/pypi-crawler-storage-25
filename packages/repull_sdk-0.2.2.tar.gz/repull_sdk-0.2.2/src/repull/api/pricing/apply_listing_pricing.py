from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error import Error
from ...models.listing_pricing_apply_request import ListingPricingApplyRequest
from ...models.listing_pricing_apply_response import ListingPricingApplyResponse
from typing import cast



def _get_kwargs(
    id: int,
    *,
    body: ListingPricingApplyRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/listings/{id}/pricing".format(id=quote(str(id), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Error | ListingPricingApplyResponse | None:
    if response.status_code == 200:
        response_200 = ListingPricingApplyResponse.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())



        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Error | ListingPricingApplyResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: int,
    *,
    client: AuthenticatedClient | Client,
    body: ListingPricingApplyRequest,

) -> Response[Error | ListingPricingApplyResponse]:
    """ Apply or decline pricing recommendations

     Apply: writes the recommended price to the listing's calendar for the given dates and triggers the
    platform fan-out (Airbnb / Booking.com / VRBO). Decline: marks the recommendation as `declined` so
    it stops surfacing — the model can re-recommend on the next training cycle.

    Args:
        id (int):
        body (ListingPricingApplyRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | ListingPricingApplyResponse]
     """


    kwargs = _get_kwargs(
        id=id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: int,
    *,
    client: AuthenticatedClient | Client,
    body: ListingPricingApplyRequest,

) -> Error | ListingPricingApplyResponse | None:
    """ Apply or decline pricing recommendations

     Apply: writes the recommended price to the listing's calendar for the given dates and triggers the
    platform fan-out (Airbnb / Booking.com / VRBO). Decline: marks the recommendation as `declined` so
    it stops surfacing — the model can re-recommend on the next training cycle.

    Args:
        id (int):
        body (ListingPricingApplyRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | ListingPricingApplyResponse
     """


    return sync_detailed(
        id=id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    id: int,
    *,
    client: AuthenticatedClient | Client,
    body: ListingPricingApplyRequest,

) -> Response[Error | ListingPricingApplyResponse]:
    """ Apply or decline pricing recommendations

     Apply: writes the recommended price to the listing's calendar for the given dates and triggers the
    platform fan-out (Airbnb / Booking.com / VRBO). Decline: marks the recommendation as `declined` so
    it stops surfacing — the model can re-recommend on the next training cycle.

    Args:
        id (int):
        body (ListingPricingApplyRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | ListingPricingApplyResponse]
     """


    kwargs = _get_kwargs(
        id=id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: int,
    *,
    client: AuthenticatedClient | Client,
    body: ListingPricingApplyRequest,

) -> Error | ListingPricingApplyResponse | None:
    """ Apply or decline pricing recommendations

     Apply: writes the recommended price to the listing's calendar for the given dates and triggers the
    platform fan-out (Airbnb / Booking.com / VRBO). Decline: marks the recommendation as `declined` so
    it stops surfacing — the model can re-recommend on the next training cycle.

    Args:
        id (int):
        body (ListingPricingApplyRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | ListingPricingApplyResponse
     """


    return (await asyncio_detailed(
        id=id,
client=client,
body=body,

    )).parsed
