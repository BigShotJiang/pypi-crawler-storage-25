"""WeChat OAuth data models.

Pydantic models for the WeChat anonymous OAuth flow
(login URL generation, scan status, and OpenID polling).
"""

from pydantic import BaseModel, Field


class WechatLoginUrlRequest(BaseModel):
    """Request body for ``POST /auth/wechat/login-url``."""

    redirect: str = Field(default="", description="微信 OAuth 登录完成后的重定向地址")


class WechatLoginUrlResponse(BaseModel):
    """Response body from ``POST /auth/wechat/login-url``."""

    url: str = Field(..., description="微信授权登录跳转 URL")
    key: str = Field(..., description="用于标识授权请求的 key")


class WechatScanStatusResponse(BaseModel):
    """Response body from ``GET /auth/wechat/scan-status``."""

    status: str = Field(
        ...,
        description="扫码状态：pending / scanned / expired / success",
    )
    code: str | None = Field(default=None, description="扫码成功后返回的授权码")
    key: str | None = Field(default=None, description="用于标识授权请求的 key")


class WechatPollOpenidResponse(BaseModel):
    """Response body from ``GET /auth/wechat/poll-openid``."""

    status: str = Field(
        ...,
        description="轮询状态：pending / scanned / success / expired / error",
    )
    openid: str | None = Field(default=None, description="微信 OpenID（仅 success 时）")
    message: str | None = Field(default=None, description="状态描述信息")
