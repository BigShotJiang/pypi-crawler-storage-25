"""Creation Webhook 模型。

包含 Creation 领域的 Webhook 模型：

- （已过期）``CreationWebhookRequest`` / ``CreationWebhookResponse``
- Action 专用 payload / response data 模型（generate_report_id、
  publish_creation_report、get_report_status）
- ``PublishCreationPayloadV2`` — 使用简化版 ``CreationGenerateResultV2``
"""

import warnings

from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel

from hezor_common.data_model.creations.core.creation_generate_result import (
    CreationGenerateResult,
    CreationGenerateResultV2,
)

# ---------------------------------------------------------------------------
# Legacy models
# ---------------------------------------------------------------------------


class CreationWebhookRequest(BaseModel):
    """Creation Webhook 请求（旧版，已过期）。

    .. deprecated:: 0.6.0
        请改用 ``WebhookRequest[PublishCreationPayload]``。
    """

    action: str = Field(..., description="操作类型", examples=["receive_creation"])
    payload: CreationGenerateResult = Field(..., description="生成结果负载")
    task_id: str = Field(
        ...,
        description="任务 ID（如 monthly_report，一般定义为执行什么任务，可以重复表明同一任务）",
    )
    execution_id: str = Field(
        ...,
        description="执行 ID（如 exec_2026_01_21_xxx，一般表示一次具体的执行实例，唯一）",
    )

    def model_post_init(self, __context: object) -> None:
        """发出过期警告。"""
        warnings.warn(
            DeprecationWarning(
                "CreationWebhookRequest 已过期，请改用 WebhookRequest[PublishCreationPayload]。"
            ),
            stacklevel=2,
        )


class CreationWebhookResponse(BaseModel):
    """Creation Webhook 响应（旧版，已过期）。

    .. deprecated:: 0.6.0
        请改用 ``WebhookResponse[PublishCreationResponseData]``。
    """

    status: str = Field(
        ...,
        description="处理状态",
        examples=["accepted", "processing"],
    )
    report_id: str = Field(..., description="报告 ID", examples=["rpt_xxx"])
    task_id: str = Field(..., description="任务 ID", examples=["task_monthly_report"])
    execution_id: str = Field(..., description="执行 ID", examples=["exec_2026_01_21_xxx"])
    message: str = Field(
        default="Processing in background",
        description="状态消息",
    )

    def model_post_init(self, __context: object) -> None:
        """发出过期警告。"""
        warnings.warn(
            DeprecationWarning(
                "CreationWebhookResponse 已过期，请改用 WebhookResponse[PublishCreationResponseData]。"
            ),
            stacklevel=2,
        )


# ---------------------------------------------------------------------------
# generate_report_id
# ---------------------------------------------------------------------------


class GenerateReportIdPayload(BaseModel):
    """``generate_report_id`` action 的 payload 结构。

    Parameters
    ----------
    count : int
        需要生成的 ID 数量（the default is 1）。

    Examples
    --------
    >>> payload = GenerateReportIdPayload(count=3)
    >>> payload.count
    3
    """

    count: int = Field(default=1, ge=1, le=100, description="生成 ID 数量")


class GenerateReportIdResponseData(BaseModel):
    """``generate_report_id`` 响应的 data 结构。

    Parameters
    ----------
    report_ids : list[str]
        生成的报告 ID 列表。

    Examples
    --------
    >>> data = GenerateReportIdResponseData(
    ...     report_ids=["rpt_001", "rpt_002"]
    ... )
    >>> len(data.report_ids)
    2
    """

    report_ids: list[str] = Field(..., description="生成的报告 ID 列表")


# ---------------------------------------------------------------------------
# publish_creation_report
# ---------------------------------------------------------------------------


class PublishCreationPayload(BaseModel):
    """``publish_creation_report`` action 的 payload 结构。

    Parameters
    ----------
    task_id : str or None
        任务 ID（如 ``"monthly_report"``）。为 None 时
        服务端自动生成，格式 ``task_<YYYYMMDD_HHMMSS>_<hex8>``。
    execution_id : str or None
        执行 ID（如 ``"exec_2026_01_21_xxx"``）。为 None 时
        服务端自动生成，格式 ``exec_<YYYYMMDD_HHMMSS>_<hex8>``。
    creation_result : CreationGenerateResult
        生成结果。

    Examples
    --------
    >>> from hezor_common.data_model.creations import (
    ...     CreationGenerateResult,
    ... )
    >>> payload = PublishCreationPayload(
    ...     creation_result=CreationGenerateResult(...),
    ...     task_id="monthly_report",
    ... )
    """

    task_id: str | None = Field(
        default=None,
        description="任务 ID，为空时自动生成",
    )
    execution_id: str | None = Field(
        default=None,
        description="执行 ID，为空时自动生成",
    )
    creation_result: CreationGenerateResult = Field(..., description="生成结果")


class PublishCreationResponseData(BaseModel):
    """``publish_creation_report`` 响应的 data 结构。

    兼容旧版 ``CreationWebhookResponse`` 的字段，
    ``status`` 和 ``message`` 可选，便于客户端统一访问。

    Parameters
    ----------
    report_id : str
        报告 ID。
    task_id : str
        任务 ID。
    execution_id : str
        执行 ID。
    status : str
        处理状态（the default is ``""``）。
    message : str
        状态消息（the default is ``""``）。

    Examples
    --------
    >>> data = PublishCreationResponseData(
    ...     report_id="rpt_001",
    ...     task_id="task_20260127",
    ...     execution_id="exec_20260127_001",
    ...     status="accepted",
    ...     message="Processing in background",
    ... )
    >>> data.report_id
    'rpt_001'
    """

    report_id: str = Field(..., description="报告 ID")
    task_id: str = Field(..., description="任务 ID")
    execution_id: str = Field(..., description="执行 ID")
    status: str = Field(default="", description="处理状态")
    message: str = Field(default="", description="状态消息")


class PublishCreationPayloadV2(BaseModel):
    """``publish_creation_report`` action 的 payload 结构（V2 简化版）。

    使用扁平化的 ``CreationGenerateResultV2`` 替代嵌套的
    ``CreationGenerateResult``，减少 HTTP 传输体积。

    Parameters
    ----------
    task_id : str or None
        任务 ID（如 ``"monthly_report"``）。为 None 时
        服务端自动生成。
    execution_id : str or None
        执行 ID（如 ``"exec_2026_01_21_xxx"``）。为 None 时
        服务端自动生成。
    creation_result : CreationGenerateResultV2
        简化版生成结果。

    Examples
    --------
    >>> payload = PublishCreationPayloadV2(
    ...     creation_result=CreationGenerateResultV2(
    ...         creation_id="rpt_xxx",
    ...         title="鮨大山 单店盈利模型 2025 年 12 月",
    ...         full_content="# 报告内容...",
    ...         summary="报告摘要...",
    ...         subject="鮨大山",
    ...         period="2025 年 12 月",
    ...         data_coverage="202512-202512",
    ...         creation_name="单店盈利模型",
    ...     ),
    ...     task_id="monthly_report",
    ... )
    """

    task_id: str | None = Field(
        default=None,
        description="任务 ID，为空时自动生成",
    )
    execution_id: str | None = Field(
        default=None,
        description="执行 ID，为空时自动生成",
    )
    creation_result: CreationGenerateResultV2 = Field(..., description="简化版生成结果")


# ---------------------------------------------------------------------------
# get_report_status
# ---------------------------------------------------------------------------


class GetReportStatusPayload(BaseModel):
    """``get_report_status`` action 的 payload 结构。

    Parameters
    ----------
    creation_id : str
        Creation ID。
    report_id : str
        Report ID。

    Examples
    --------
    >>> payload = GetReportStatusPayload(
    ...     creation_id="crt_xxx",
    ...     report_id="rpt_xxx",
    ... )
    """

    creation_id: str = Field(..., description="Creation ID")
    report_id: str = Field(..., description="Report ID")


class ReportMetadata(BaseModel):
    """报告元数据（简化版）。

    同时支持 snake_case 和 camelCase 字段名，
    便于在 REST API 和 Webhook 响应中通用。

    ``report_url`` 在模型初始化时自动根据 ``report_id`` 和
    ``verification_code`` 生成。构造时可通过 ``report_url``
    传入带 host 的完整前缀，否则默认生成相对路径。

    Parameters
    ----------
    report_id : str
        报告 ID。
    report_title : str
        报告标题。
    description : str
        报告描述。
    generated_at : str
        生成时间。
    verification_code : str
        校验码。
    status_message : str
        状态消息。
    summary : str
        报告摘要。
    report_url : str
        报告访问 URL，格式 ``{host}/creations/{report_id}``，
        如有校验码则附加 ``?code=xxx``。构造时可传入带 host
        的前缀（如 ``https://example.com/creations/rpt_001``），
        也可留空由 ``model_post_init`` 自动生成相对路径。

    Examples
    --------
    >>> meta = ReportMetadata(
    ...     report_id="rpt_001",
    ...     report_title="Monthly Report",
    ...     generated_at="2026-01-27T00:00:00Z",
    ... )
    >>> meta.report_url
    '/creations/rpt_001'

    >>> meta_with_code = ReportMetadata(
    ...     report_id="rpt_002",
    ...     report_title="Monthly Report",
    ...     generated_at="2026-01-27T00:00:00Z",
    ...     verification_code="abc123",
    ... )
    >>> meta_with_code.report_url
    '/creations/rpt_002?code=abc123'
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    report_id: str = Field(..., description="报告 ID")
    report_title: str = Field(..., description="报告标题")
    description: str = Field(default="", description="报告描述")
    generated_at: str = Field(..., description="生成时间")
    verification_code: str = Field(default="", description="校验码")
    status_message: str = Field(default="", description="状态消息")
    summary: str = Field(default="", description="报告摘要")
    report_url: str = Field(default="", description="报告访问 URL")

    def model_post_init(self, __context: object) -> None:
        """自动生成 report_url（当未显式传入时）。"""
        if not self.report_url:
            url = f"/creations/{self.report_id}"
            if self.verification_code:
                url += f"?code={self.verification_code}"
            self.report_url = url


# ---------------------------------------------------------------------------
# get_public_reports
# ---------------------------------------------------------------------------


class GetPublicReportsPayload(BaseModel):
    """``get_public_reports`` action 的 payload 结构。

    Parameters
    ----------
    top_n : int
        返回报告数量（the default is 5）。
    creation_id : str or None
        Creation ID。为 None 时获取所有公开 Creation 的报告，
        不为 None 时仅获取指定 Creation 的报告（要求该 Creation
        为公开状态）。

    Examples
    --------
    >>> payload = GetPublicReportsPayload(top_n=10)
    >>> payload.top_n
    10

    >>> payload = GetPublicReportsPayload(
    ...     top_n=3, creation_id="my_creation"
    ... )
    >>> payload.creation_id
    'my_creation'
    """

    top_n: int = Field(default=5, ge=1, le=100, description="返回报告数量")
    creation_id: str | None = Field(
        default=None,
        description="Creation ID，为 None 时获取所有公开 Creation 的报告",
    )


class PublicReportsResponseData(BaseModel):
    """``get_public_reports`` 响应的 data 结构。

    Parameters
    ----------
    items : list[ReportMetadata]
        报告列表。
    total : int
        返回的报告数量。

    Examples
    --------
    >>> data = PublicReportsResponseData(items=[], total=0)
    >>> data.total
    0
    """

    items: list[ReportMetadata] = Field(..., description="报告列表")
    total: int = Field(..., description="返回的报告数量")


__all__ = [
    # Legacy models
    "CreationWebhookRequest",
    "CreationWebhookResponse",
    # generate_report_id
    "GenerateReportIdPayload",
    "GenerateReportIdResponseData",
    # publish_creation_report
    "PublishCreationPayload",
    "PublishCreationPayloadV2",
    "PublishCreationResponseData",
    # get_report_status
    "GetReportStatusPayload",
    "ReportMetadata",
    # get_public_reports
    "GetPublicReportsPayload",
    "PublicReportsResponseData",
]
