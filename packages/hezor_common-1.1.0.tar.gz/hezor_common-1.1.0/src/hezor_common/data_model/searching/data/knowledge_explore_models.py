"""Knowledge exploration data models.

Defines data structures used by the knowledge exploration page:
ontology concepts, knowledge topics, gallery, document library,
and homepage aggregation.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from hezor_common.data_model.searching.data.knowledge_retrieval_models import (
    Chunk,
    Community,
    GalleryPicture,
    OntologyEntity,
)
from hezor_common.utilities.text_helpers import to_camel

__all__ = [
    "CategoryCount",
    "CategoryCountList",
    "ChunkList",
    "CommunityList",
    "DepthEntity",
    "GalleryPictureList",
    "HomeExploreData",
    "HotTopic",
    "OntologyEntityList",
    "RawDocument",
    "RawDocumentList",
    "StatItemModel",
    "TabItemModel",
    "TrendDataPoint",
]


# ─────────────────── 通用分类计数 ───────────────────


class CategoryCount(BaseModel):
    """分类计数项。

    Parameters
    ----------
    key : str
        分类键（如 entity_type 值或社区 level）。
    label : str
        分类显示名称。
    count : int
        该分类下的文档数量。
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    key: str = Field(..., description="分类键")
    label: str = Field(default="", description="分类显示名称")
    count: int = Field(default=0, description="文档数量")


class CategoryCountList(BaseModel):
    """分类计数列表。

    Parameters
    ----------
    items : list[CategoryCount]
        分类计数列表。
    total : int
        所有分类的文档总数。
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    items: list[CategoryCount] = Field(default_factory=list)
    total: int = Field(default=0, description="文档总数")


# ─────────────────── 本体概念 ───────────────────


class OntologyEntityList(BaseModel):
    """本体概念列表响应。

    Parameters
    ----------
    items : list[OntologyEntity]
        当前页的实体列表。
    total : int
        符合筛选条件的总数。
    page : int
        当前页码（从 1 开始）。
    page_size : int
        每页数量。
    total_pages : int
        总页数。
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    items: list[OntologyEntity] = Field(default_factory=list)
    total: int = Field(default=0)
    page: int = Field(default=1, description="当前页码")
    page_size: int = Field(default=20, description="每页数量")
    total_pages: int = Field(default=0, description="总页数")


# ─────────────────── 知识主题 ───────────────────


class CommunityList(BaseModel):
    """知识主题列表响应。

    Parameters
    ----------
    items : list[Community]
        当前页的主题列表。
    total : int
        符合筛选条件的总数。
    page : int
        当前页码（从 1 开始）。
    page_size : int
        每页数量。
    total_pages : int
        总页数。
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    items: list[Community] = Field(default_factory=list)
    total: int = Field(default=0)
    page: int = Field(default=1, description="当前页码")
    page_size: int = Field(default=20, description="每页数量")
    total_pages: int = Field(default=0, description="总页数")


# ─────────────────── 专业图库 ───────────────────


class GalleryPictureList(BaseModel):
    """专业图库列表响应。

    Parameters
    ----------
    items : list[GalleryPicture]
        当前页的图片列表。
    total : int
        符合筛选条件的总数。
    page : int
        当前页码（从 1 开始）。
    page_size : int
        每页数量。
    total_pages : int
        总页数。
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    items: list[GalleryPicture] = Field(default_factory=list)
    total: int = Field(default=0)
    page: int = Field(default=1, description="当前页码")
    page_size: int = Field(default=20, description="每页数量")
    total_pages: int = Field(default=0, description="总页数")


# ─────────────────── 领域文档库 ───────────────────


class RawDocument(BaseModel):
    """领域文档库文档。

    Parameters
    ----------
    doc_id : str
        文档 ID。
    doc_name : str
        文档名称。
    batch_id : str
        批次 ID。
    source_file : str
        来源文件路径。
    file_type : str
        文件类型。
    page_count : int
        总页数。
    chunk_count : int
        分块数量。
    picture_count : int
        图片数量。
    status : str
        状态。
    update_at : str
        更新时间。
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    doc_id: str = Field(..., description="文档 ID")
    doc_name: str = Field(default="", description="文档名称")
    batch_id: str = Field(default="", description="批次 ID")
    source_file: str = Field(default="", description="来源文件路径")
    file_type: str = Field(default="", description="文件类型")
    page_count: int = Field(default=0, description="总页数")
    chunk_count: int = Field(default=0, description="分块数量")
    picture_count: int = Field(default=0, description="图片数量")
    status: str = Field(default="ok", description="状态")
    update_at: str = Field(default="", description="更新时间")


class RawDocumentList(BaseModel):
    """领域文档库文档列表响应。

    Parameters
    ----------
    items : list[RawDocument]
        当前页的文档列表。
    total : int
        符合筛选条件的总数。
    page : int
        当前页码（从 1 开始）。
    page_size : int
        每页数量。
    total_pages : int
        总页数。
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    items: list[RawDocument] = Field(default_factory=list)
    total: int = Field(default=0)
    page: int = Field(default=1, description="当前页码")
    page_size: int = Field(default=20, description="每页数量")
    total_pages: int = Field(default=0, description="总页数")


class ChunkList(BaseModel):
    """分块列表响应。

    Parameters
    ----------
    items : list[Chunk]
        当前页的分块列表。
    total : int
        符合筛选条件的总数。
    page : int
        当前页码（从 1 开始）。
    page_size : int
        每页数量。
    total_pages : int
        总页数。
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    items: list[Chunk] = Field(default_factory=list)
    total: int = Field(default=0)
    page: int = Field(default=1, description="当前页码")
    page_size: int = Field(default=20, description="每页数量")
    total_pages: int = Field(default=0, description="总页数")


# ─────────────────── 首页探索 ───────────────────


class TabItemModel(BaseModel):
    """导航标签项。

    Parameters
    ----------
    key : str
        标签唯一标识。
    label : str
        标签显示名称。
    icon : str
        图标组件名称（如 CompassOutlined）。
    badge : str | None
        可选徽章文本。
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    key: str = Field(..., description="标签唯一标识")
    label: str = Field(..., description="标签显示名称")
    icon: str = Field(..., description="图标组件名称")
    badge: str | None = Field(default=None, description="可选徽章文本")


class HotTopic(BaseModel):
    """热门知识主题。

    Parameters
    ----------
    id : str
        主题 ID。
    title : str
        主题标题。
    category : str
        分类名称。
    concept_count : int
        涉及概念数量。
    heat : int
        热度值。
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    id: str = Field(..., description="主题 ID")
    title: str = Field(..., description="主题标题")
    category: str = Field(..., description="分类名称")
    concept_count: int = Field(default=0, description="涉及概念数量")
    heat: int = Field(default=0, description="热度值")


class DepthEntity(BaseModel):
    """关系深度实体。

    Parameters
    ----------
    id : str
        实体 ID。
    name : str
        实体名称。
    depth : int
        当前深度。
    max_depth : int
        最大深度。
    relations : list[str]
        关联实体名称列表。
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    id: str = Field(..., description="实体 ID")
    name: str = Field(..., description="实体名称")
    depth: int = Field(default=0, description="当前深度")
    max_depth: int = Field(default=10, description="最大深度")
    relations: list[str] = Field(default_factory=list, description="关联实体名称列表")


class StatItemModel(BaseModel):
    """统计指标项。

    Parameters
    ----------
    icon : str
        图标组件名称。
    value : str
        统计值（已格式化字符串）。
    label : str
        指标名称。
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    icon: str = Field(..., description="图标组件名称")
    value: str = Field(..., description="统计值")
    label: str = Field(..., description="指标名称")


class TrendDataPoint(BaseModel):
    """趋势数据点。

    Parameters
    ----------
    label : str
        时间标签。
    value : int
        数值。
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    label: str = Field(..., description="时间标签")
    value: int = Field(default=0, description="数值")


class HomeExploreData(BaseModel):
    """首页探索数据聚合响应。

    Parameters
    ----------
    tabs : list[TabItemModel]
        导航标签列表。
    quick_questions : list[str]
        快捷问题列表。
    hot_topics : list[HotTopic]
        热门主题列表。
    depth_entities : list[DepthEntity]
        关系深度实体列表。
    stats : list[StatItemModel]
        统计指标列表。
    trend_data : list[TrendDataPoint]
        趋势数据点列表。
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    tabs: list[TabItemModel] = Field(default_factory=list, description="导航标签列表")
    quick_questions: list[str] = Field(default_factory=list, description="快捷问题列表")
    hot_topics: list[HotTopic] = Field(default_factory=list, description="热门主题列表")
    depth_entities: list[DepthEntity] = Field(default_factory=list, description="关系深度实体列表")
    stats: list[StatItemModel] = Field(default_factory=list, description="统计指标列表")
    trend_data: list[TrendDataPoint] = Field(default_factory=list, description="趋势数据点列表")
