"""用户-应用绑定数据模型。

供 Hezor2 SDK 和 hezor2 后端共享使用的接口契约模型。

此模块定义用户与 Casdoor 应用绑定关系的公共数据模型，
包括绑定信息和应用凭证信息。管理侧的 CRUD 模型
（如数据库行映射）位于 hezor2 本地项目中。
"""

from pydantic import BaseModel, ConfigDict, Field

__all__ = [
    "AppCertInfo",
    "UserAppBindingInfo",
]


class AppCertInfo(BaseModel):
    """应用凭证信息。

    通过 ``GET /app-certs`` 端点返回，
    包含应用的客户端凭证和证书内容。

    Attributes
    ----------
    app_name : str
        应用名称。
    org_name : str
        组织名称。
    client_id : str
        OAuth2 客户端 ID。
    client_secret : str
        OAuth2 客户端密钥。
    cert_content : str
        证书私钥内容（PEM 格式）。

    Examples
    --------
    >>> info = AppCertInfo(
    ...     app_name="my_app",
    ...     org_name="my_org",
    ...     client_id="abc123",
    ...     client_secret="secret456",
    ...     cert_content="-----BEGIN RSA PRIVATE KEY-----\\n...",
    ... )
    >>> info.app_name
    'my_app'
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "app_name": "pestiot_v5",
                "org_name": "jinhetech",
                "client_id": "abc123def456",
                "client_secret": "secret_value",
                "cert_content": "-----BEGIN RSA PRIVATE KEY-----\nMIIE...\n-----END RSA PRIVATE KEY-----",
            }
        }
    )

    app_name: str = Field(..., description="应用名称")
    org_name: str = Field(..., description="组织名称")
    client_id: str = Field(..., description="OAuth2 客户端 ID")
    client_secret: str = Field(..., description="OAuth2 客户端密钥")
    cert_content: str = Field(..., description="证书私钥内容（PEM 格式）")


class UserAppBindingInfo(BaseModel):
    """用户可见的应用绑定信息（含凭证）。

    通过 ``GET /user/my-apps`` 端点返回，
    展示用户已绑定的应用列表及每个应用的凭证。

    Attributes
    ----------
    app_name : str
        应用名称。
    display_name : str
        应用显示名称。
    org_name : str
        组织名称。
    logo : str
        应用 Logo URL。
    description : str
        应用描述。
    is_default : bool
        是否为用户默认应用。
    enabled : bool
        是否启用。
    client_id : str
        OAuth2 客户端 ID。
    client_secret : str
        OAuth2 客户端密钥。
    cert_content : str
        证书私钥内容（PEM 格式）。

    Examples
    --------
    >>> binding = UserAppBindingInfo(
    ...     app_name="my_app",
    ...     display_name="My App",
    ...     org_name="my_org",
    ...     logo="",
    ...     description="",
    ...     is_default=True,
    ...     enabled=True,
    ...     client_id="abc123",
    ...     client_secret="secret456",
    ...     cert_content="-----BEGIN RSA PRIVATE KEY-----\\n...",
    ... )
    >>> binding.is_default
    True
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "app_name": "pestiot_v5",
                "display_name": "PestIoT V5",
                "org_name": "jinhetech",
                "logo": "https://example.com/logo.png",
                "description": "智慧农业物联网平台",
                "is_default": True,
                "enabled": True,
                "client_id": "abc123def456",
                "client_secret": "secret_value",
                "cert_content": "-----BEGIN RSA PRIVATE KEY-----\nMIIE...\n-----END RSA PRIVATE KEY-----",
            }
        }
    )

    app_name: str = Field(..., description="应用名称")
    display_name: str = Field(default="", description="应用显示名称")
    org_name: str = Field(..., description="组织名称")
    logo: str = Field(default="", description="应用 Logo URL")
    description: str = Field(default="", description="应用描述")
    is_default: bool = Field(..., description="是否为用户默认应用")
    enabled: bool = Field(..., description="是否启用")
    client_id: str = Field(..., description="OAuth2 客户端 ID")
    client_secret: str = Field(..., description="OAuth2 客户端密钥")
    cert_content: str = Field(..., description="证书私钥内容（PEM 格式）")
