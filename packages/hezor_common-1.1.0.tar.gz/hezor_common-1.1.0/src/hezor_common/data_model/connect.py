"""Connect login data models.

Pydantic models for the Connect third-party login flow.
"""

from pydantic import BaseModel, Field


class ConnectVerifyRequest(BaseModel):
    """Request body for ``POST /auth/connect/verify``."""

    app_name: str = Field(..., description="应用名称")
    meta_info: str = Field(..., description="MetaInfo JWT token")
    callback_url: str = Field(..., description="回调 URL")


class ConnectVerifyResponse(BaseModel):
    """Response body from ``POST /auth/connect/verify``."""

    valid: bool = Field(..., description="验证是否通过")
    app_name: str = Field(..., description="应用名称")
    meta_info: dict = Field(default_factory=dict, description="解码后的 MetaInfo 载荷")
    callback_url: str = Field(..., description="回调 URL")


class ConnectRefreshRequest(BaseModel):
    """Request body for ``POST /auth/connect/refresh``."""

    app_name: str = Field(..., description="应用名称")
    meta_info: str = Field(..., description="MetaInfo JWT token")
    refresh_token: str = Field(..., description="刷新令牌")


class ConnectUser(BaseModel):
    """User information returned in Connect token responses."""

    id: str
    name: str
    display_name: str


class ConnectRefreshResponse(BaseModel):
    """Response body from ``POST /auth/connect/refresh``."""

    access_token: str = Field(..., description="访问令牌")
    refresh_token: str | None = Field(default=None, description="新的刷新令牌")
    token_type: str = Field(..., description="令牌类型")
    expires_in: int = Field(..., description="过期时间（秒）")
    user: ConnectUser = Field(..., description="用户信息")
