"""Constants for Hezor transfer middlewares."""

from hezor_common.transfer.base_sdk.constants import (  # noqa: F401
    REQ_HEADER_APP_NAME_KEY,
    REQ_HEADER_META_INFO_KEY,
)


def ERR_RES_HEADER_META_INFO(realm: str = "Access to the protected resource") -> dict[str, str]:
    return {"WWW-Authenticate": f'{REQ_HEADER_META_INFO_KEY} realm="{realm}"'}


def ERR_RES_HEADER_API_KEY(realm: str = "Access to the protected resource") -> dict[str, str]:
    return {"WWW-Authenticate": f'Bearer realm="{realm}"'}


def ERR_RES_HEADER_BOTH(realm: str = "Access to the protected resource") -> dict[str, str]:
    return {
        "WWW-Authenticate": (f'Bearer realm="{realm}", {REQ_HEADER_META_INFO_KEY} realm="{realm}"')
    }


def ERR_RES_HEADER_APP_NAME(realm: str = "Access to the protected resource") -> dict[str, str]:
    return {"WWW-Authenticate": f'{REQ_HEADER_APP_NAME_KEY} realm="{realm}"'}
