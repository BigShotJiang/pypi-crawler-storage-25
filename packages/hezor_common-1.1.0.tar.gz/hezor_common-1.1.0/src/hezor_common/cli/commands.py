"""CLI 命令注册。

聚合所有功能子命令组，提供统一的命令注册入口。
"""

import typer

from hezor_common.cli.apps import app as apps_app
from hezor_common.cli.config import app as config_app
from hezor_common.cli.data import app as data_app
from hezor_common.cli.graph import app as graph_app
from hezor_common.cli.knowledge import app as knowledge_app
from hezor_common.cli.reports import app as reports_app
from hezor_common.cli.system import app as system_app

app = typer.Typer(no_args_is_help=True)

# 功能子命令组
app.add_typer(reports_app, name="reports")
app.add_typer(knowledge_app, name="knowledge")
app.add_typer(data_app, name="data")
app.add_typer(graph_app, name="graph")
app.add_typer(config_app, name="config")
app.add_typer(apps_app, name="apps")

# 顶层命令（health, webhook）直接注册
app.registered_commands += system_app.registered_commands

__all__ = ["app"]
