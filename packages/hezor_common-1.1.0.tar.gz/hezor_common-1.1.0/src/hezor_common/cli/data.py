"""CLI 数据检索命令。"""

from typing import Any

import typer

from hezor_common.cli._common import (
    console,
    create_sdk_from_profile,
    get_profile,
    print_json_output,
    run_async,
)

app = typer.Typer(name="data", help="数据检索。", no_args_is_help=True)


@app.command("retrieve")
def retrieve(
    query: str = typer.Argument(..., help="检索查询"),
    top_k: int = typer.Option(1, "--top-k", "-k", help="返回数量"),
    raw: bool = typer.Option(False, "--raw", help="输出原始 JSON"),
) -> None:
    """执行数据检索（data_retrieve webhook）。"""
    profile = get_profile()

    async def _run() -> Any:
        sdk = create_sdk_from_profile(profile)
        async with sdk:
            return await sdk.data_retrieve(query=query, top_k=top_k)

    result = run_async(_run())

    if raw:
        print_json_output(result, raw=True)
    else:
        console.print("[green]✓[/green] 数据检索完成\n")
        print_json_output(result)
