"""CLI 系统命令。

提供健康检查、webhook 帮助等系统级功能。
"""

from typing import Any

import typer

from hezor_common.cli._common import (
    console,
    create_sdk_from_profile,
    get_profile,
    print_json_output,
    run_async,
)

app = typer.Typer(no_args_is_help=True)


@app.command("health")
def health() -> None:
    """执行健康检查。"""
    profile = get_profile()

    async def _run() -> tuple[bool, dict]:
        sdk = create_sdk_from_profile(profile)
        async with sdk:
            return await sdk.health_check()

    is_healthy, data = run_async(_run())

    if is_healthy:
        console.print("[green]✓[/green] 服务正常")
    else:
        console.print("[red]✗[/red] 服务异常")

    if data:
        print_json_output(data)


@app.command("webhook")
def webhook_help(
    action: str = typer.Argument(
        ...,
        help="Webhook 动作名称，如 generate_report_id, publish_creation_report",
    ),
    raw: bool = typer.Option(False, "--raw", help="输出原始 JSON"),
) -> None:
    """查看 Webhook 动作帮助文档。"""
    profile = get_profile()

    async def _run() -> Any:
        sdk = create_sdk_from_profile(profile)
        async with sdk:
            return await sdk.webhook_help(action=action)

    result = run_async(_run())

    if raw:
        print_json_output(result, raw=True)
    else:
        console.print(f"[bold]Webhook: {action}[/bold]\n")
        print_json_output(result)
