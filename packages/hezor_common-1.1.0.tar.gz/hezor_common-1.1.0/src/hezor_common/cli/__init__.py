"""Hezor2 CLI — 命令行工具。

通过命令行访问 Hezor2 平台的所有 SDK 功能。

Usage
-----
    hezor2 login <host>          # 登录
    hezor2 logout                # 登出
    hezor2 status                # 查看登录状态
    hezor2 health                # 健康检查
    hezor2 reports list          # 查看公开报告
    ...
"""

import typer

from hezor_common.cli.auth import app as auth_app
from hezor_common.cli.commands import app as commands_app

app = typer.Typer(
    name="hezor2",
    help="Hezor2 CLI — 命令行工具，访问 Hezor2 平台全部功能。",
    no_args_is_help=True,
)

# 注册顶层命令（login, logout, status）和子组（sessions）
app.registered_commands += auth_app.registered_commands
app.registered_groups += auth_app.registered_groups

# 注册功能子命令组
app.registered_groups += commands_app.registered_groups
app.registered_commands += commands_app.registered_commands


def main() -> None:
    """CLI 入口点。"""
    app()


__all__ = ["app", "main"]
