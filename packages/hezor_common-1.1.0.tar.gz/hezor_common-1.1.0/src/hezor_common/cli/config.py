"""CLI 配置命令。"""

from typing import Any

import typer

from hezor_common.cli._common import (
    create_sdk_from_profile,
    get_profile,
    print_json_output,
    run_async,
)

app = typer.Typer(name="config", help="配置中心。", no_args_is_help=True)


@app.command("pull")
def pull(
    keys: list[str] | None = typer.Option(None, "--key", "-k", help="指定配置键（可多次使用）"),
    global_base_url: str | None = typer.Option(
        None, "--global-base-url", help="替换 ${GLOBAL_BASE_URL} 占位符"
    ),
    merged: bool = typer.Option(False, "--merged", help="输出合并后的配置"),
    raw: bool = typer.Option(False, "--raw", help="输出原始 JSON"),
) -> None:
    """拉取配置。"""
    profile = get_profile()

    async def _run() -> Any:
        sdk = create_sdk_from_profile(profile)
        async with sdk:
            result = await sdk.pull_configs(
                keys=keys,
                global_base_url=global_base_url,
            )
            if merged:
                return result.merged()
            return result

    result = run_async(_run())
    print_json_output(result, raw=raw)
