"""Text transformation helpers.

Provides common text conversion utilities used across the project,
such as case conversion for Pydantic alias generators.
"""

from __future__ import annotations

__all__ = ["to_camel"]


def to_camel(string: str) -> str:
    """Convert a snake_case string to camelCase.

    Parameters
    ----------
    string : str
        A snake_case identifier, e.g. ``"my_field_name"``.

    Returns
    -------
    str
        The camelCase equivalent, e.g. ``"myFieldName"``.

    Examples
    --------
    >>> to_camel("user_id")
    'userId'

    >>> to_camel("created_at")
    'createdAt'

    >>> to_camel("name")
    'name'
    """
    components = string.split("_")
    return components[0] + "".join(part.title() for part in components[1:])
