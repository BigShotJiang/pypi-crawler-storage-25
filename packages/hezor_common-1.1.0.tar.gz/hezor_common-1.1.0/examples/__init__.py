"""Examples for hezor_common package."""
