"""
MundiX CLI v2.0 - AI-Powered Cybersecurity Copilot

Refactored architecture with modular design:
- src/cli: Command-line interface and UI components
- src/core: Business logic engine and session management
- src/ai: AI provider interfaces and prompt templates
- src/agent: Agent orchestration and specialized agents
- src/skills: Skill system with validation and execution
- src/memory: Memory backends (local, vector)
- src/system: System integration and safety
- src/autopilot: Autonomy control and error recovery
- src/project: Project and workspace management
- src/reporting: Findings and report generation
"""

__version__ = "2.3.3"
__author__ = "MundiX Team"
__license__ = "MIT"
