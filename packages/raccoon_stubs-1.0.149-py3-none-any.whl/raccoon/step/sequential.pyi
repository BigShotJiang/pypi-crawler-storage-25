from __future__ import annotations
import _contextvars
import raccoon.step.annotation
from raccoon.step.annotation import dsl
import raccoon.step.base
from raccoon.step.base import Step
import raccoon.step.model
from raccoon.step.model import SimulationStep
from raccoon.step.model import SimulationStepDelta
from raccoon.step.model import StepProtocol
import typing
__all__: list[str] = ['Sequential', 'SimulationStep', 'SimulationStepDelta', 'Step', 'StepProtocol', 'dsl', 'seq']
class Sequential(raccoon.step.base.Step):
    """
    
    Composite step that runs child steps one after another.
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name=None, tags=())
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'Sequential'
    __dsl_tags__: typing.ClassVar[tuple] = tuple()
    _composite: typing.ClassVar[bool] = True
    def __init__(self, steps: typing.List[raccoon.step.base.Step]) -> None:
        """
        
        Initialize Sequential step executor.
        
        Args:
            steps: List of Step objects to execute sequentially.
            
        Raises:
            TypeError: If any element in steps is not a Step instance.
        """
    def _execute_step(self, robot) -> None:
        """
        
        Run each child step in order against the same robot instance.
        """
    def _generate_signature(self) -> str:
        ...
    def collected_resources(self) -> frozenset[str]:
        ...
    def to_simulation_step(self) -> raccoon.step.model.SimulationStep:
        ...
def seq(steps: typing.List[raccoon.step.base.Step]) -> Sequential:
    """
    Create a sequential composite from an explicit list of steps.
    """
_step_path: _contextvars.ContextVar  # value = <ContextVar name='step_path' default=[] at 0xeea2b3f76840>
