"""Local tool executors. These run on the user's machine with user's perms.

Sacred Artifact Protocol: WRITES outside user home require explicit --allow-outside-home.
"""
from __future__ import annotations
import os
import subprocess
import shutil
import zipfile
import tarfile
from pathlib import Path
from typing import Any


def _safe_path(path: str, allow_outside_home: bool = False) -> Path:
    p = Path(os.path.expandvars(os.path.expanduser(path))).resolve()
    home = Path.home().resolve()
    if not allow_outside_home:
        try:
            p.relative_to(home)
        except ValueError:
            raise PermissionError(f"Refusing to touch {p} — outside {home}. Re-run with --allow-outside-home to override.")
    return p


def file_write(path: str, content: str, mode: str = "w", allow_outside_home: bool = False) -> dict[str, Any]:
    p = _safe_path(path, allow_outside_home)
    p.parent.mkdir(parents=True, exist_ok=True)
    if mode == "wb":
        p.write_bytes(content.encode("utf-8") if isinstance(content, str) else content)
    else:
        p.write_text(content, encoding="utf-8")
    return {"ok": True, "path": str(p), "bytes": p.stat().st_size}


def file_read(path: str, allow_outside_home: bool = False, max_bytes: int = 10_000_000) -> dict[str, Any]:
    p = _safe_path(path, allow_outside_home)
    if not p.exists():
        return {"ok": False, "error": f"not found: {p}"}
    data = p.read_bytes()[:max_bytes]
    try:
        text = data.decode("utf-8")
        return {"ok": True, "path": str(p), "content": text, "bytes": len(data)}
    except UnicodeDecodeError:
        return {"ok": True, "path": str(p), "content_base64": True, "bytes": len(data)}


def file_find(root: str, pattern: str = "*", allow_outside_home: bool = False, max_results: int = 500) -> dict[str, Any]:
    r = _safe_path(root, allow_outside_home)
    matches = []
    for p in r.rglob(pattern):
        matches.append(str(p))
        if len(matches) >= max_results:
            break
    return {"ok": True, "root": str(r), "pattern": pattern, "matches": matches}


def archive_extract(archive: str, dest: str, allow_outside_home: bool = False) -> dict[str, Any]:
    a = _safe_path(archive, allow_outside_home)
    d = _safe_path(dest, allow_outside_home)
    d.mkdir(parents=True, exist_ok=True)
    if zipfile.is_zipfile(a):
        with zipfile.ZipFile(a) as z:
            z.extractall(d)
    elif tarfile.is_tarfile(a):
        with tarfile.open(a) as t:
            t.extractall(d)
    else:
        return {"ok": False, "error": f"unknown archive format: {a}"}
    return {"ok": True, "archive": str(a), "dest": str(d)}


def bash(cmd: str, cwd: str | None = None, timeout: int = 120) -> dict[str, Any]:
    """Run shell command on user's machine. Sacred: does NOT filter commands — user is sovereign on their box."""
    try:
        r = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True, timeout=timeout)
        return {
            "ok": r.returncode == 0,
            "returncode": r.returncode,
            "stdout": r.stdout[-50_000:],
            "stderr": r.stderr[-50_000:],
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"timeout after {timeout}s"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


TOOL_REGISTRY = {
    "file_write": file_write,
    "file_read": file_read,
    "file_find": file_find,
    "archive_extract": archive_extract,
    "bash": bash,
}
