"""Streaming client — receives tool_use from remote LLM, executes locally, streams tool_result back.

Transport: HTTP POST with SSE response. Endpoint: /api/cli/stream.
Protocol:
  Client POST { prompt, session_id, capabilities }
  Server SSE events:
    data: {"type":"text", "content":"..."}
    data: {"type":"tool_use", "id":"...", "name":"file_write", "input":{...}}
    data: {"type":"done"}
  Client POST /api/cli/tool_result { session_id, tool_use_id, result } for each tool_use
"""
from __future__ import annotations
import json
import uuid
from typing import Any, Callable, Iterator
import requests
from .config import load_config
from .auth import whoami
from .tools import TOOL_REGISTRY
from .browser import BROWSER_TOOLS
from .llm_discovery import LLM_TOOLS
from .builders import BUILDER_TOOLS


def _all_tools() -> dict[str, Callable[..., Any]]:
    d: dict[str, Callable[..., Any]] = {}
    d.update(TOOL_REGISTRY)
    d.update(BROWSER_TOOLS)
    d.update(LLM_TOOLS)
    d.update(BUILDER_TOOLS)
    return d


def _capabilities() -> list[str]:
    return list(_all_tools().keys())


def _iter_sse(resp: requests.Response) -> Iterator[dict[str, Any]]:
    for raw_line in resp.iter_lines(decode_unicode=True):
        if not raw_line or not raw_line.startswith("data:"):
            continue
        payload = raw_line[5:].strip()
        if not payload or payload == "[DONE]":
            continue
        try:
            yield json.loads(payload)
        except json.JSONDecodeError:
            continue


def run_session(prompt: str, on_text: Callable[[str], None] | None = None, allow_outside_home: bool = False) -> dict[str, Any]:
    cfg = load_config()
    creds = whoami()
    if not creds:
        return {"ok": False, "error": "not logged in. run: leviathan login"}
    headers = {
        "Authorization": f"Bearer {creds['token']}",
        "Content-Type": "application/json",
        "Accept": "text/event-stream",
    }
    session_id = str(uuid.uuid4())
    body = {
        "prompt": prompt,
        "session_id": session_id,
        "capabilities": _capabilities(),
        "allow_outside_home": allow_outside_home,
    }

    tools = _all_tools()
    final_text = []

    url = f"{cfg['api_base']}/api/cli/stream"
    try:
        with requests.post(url, json=body, headers=headers, stream=True, timeout=600) as r:
            if r.status_code != 200:
                # Try Hetzner fallback
                fb = f"{cfg['fallback_base']}/api/cli/stream"
                r = requests.post(fb, json=body, headers=headers, stream=True, timeout=600)
                if r.status_code != 200:
                    return {"ok": False, "status": r.status_code, "body": r.text[:2000]}

            for evt in _iter_sse(r):
                t = evt.get("type")
                if t == "text":
                    chunk = evt.get("content", "")
                    final_text.append(chunk)
                    if on_text:
                        on_text(chunk)
                elif t == "tool_use":
                    name = evt.get("name")
                    tool_input = evt.get("input", {}) or {}
                    tool_use_id = evt.get("id")
                    fn = tools.get(name)
                    if fn is None:
                        result = {"ok": False, "error": f"unknown tool: {name}"}
                    else:
                        try:
                            if "allow_outside_home" in fn.__code__.co_varnames:
                                tool_input.setdefault("allow_outside_home", allow_outside_home)
                            result = fn(**tool_input) if isinstance(tool_input, dict) else fn(tool_input)
                        except Exception as e:
                            result = {"ok": False, "error": f"{type(e).__name__}: {e}"}
                    # POST result back
                    try:
                        requests.post(
                            f"{cfg['api_base']}/api/cli/tool_result",
                            json={"session_id": session_id, "tool_use_id": tool_use_id, "result": result},
                            headers=headers,
                            timeout=30,
                        )
                    except Exception:
                        pass
                elif t == "done":
                    break
                elif t == "error":
                    return {"ok": False, "error": evt.get("message", "server error")}
    except requests.RequestException as e:
        return {"ok": False, "error": f"network: {e}"}

    return {"ok": True, "text": "".join(final_text), "session_id": session_id}
