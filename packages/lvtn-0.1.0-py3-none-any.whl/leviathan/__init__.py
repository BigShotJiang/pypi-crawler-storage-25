"""Leviathan — local agent CLI for the Leviathan of HaShem platform.

Sacred Artifact Protocol: ADD ONLY. Never delete, never overwrite existing user code.
"""

__version__ = "0.1.0"
__all__ = ["__version__"]
