"""Browser automation via Playwright. Lets the remote LLM drive a real browser on the user's machine.

Usage from tool_use:
  browser_open {url}
  browser_screenshot {path}
  browser_click {selector}
  browser_fill {selector, text}
  browser_eval {js}
  browser_read_text

Playwright is optional — if not installed, commands return {ok:false, error:"playwright not installed"}.
Install: `leviathan install-browser` (runs `playwright install chromium`).
"""
from __future__ import annotations
from typing import Any, Optional

_page = None
_browser = None
_playwright = None


def _ensure_browser(headless: bool = False) -> Optional[Any]:
    global _page, _browser, _playwright
    if _page is not None:
        return _page
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return None
    _playwright = sync_playwright().start()
    _browser = _playwright.chromium.launch(headless=headless)
    _page = _browser.new_page()
    return _page


def browser_open(url: str, headless: bool = False) -> dict[str, Any]:
    page = _ensure_browser(headless)
    if page is None:
        return {"ok": False, "error": "playwright not installed. run: leviathan install-browser"}
    page.goto(url, wait_until="domcontentloaded")
    return {"ok": True, "url": page.url, "title": page.title()}


def browser_screenshot(path: str) -> dict[str, Any]:
    if _page is None:
        return {"ok": False, "error": "no browser open. call browser_open first."}
    _page.screenshot(path=path, full_page=True)
    return {"ok": True, "path": path}


def browser_click(selector: str) -> dict[str, Any]:
    if _page is None:
        return {"ok": False, "error": "no browser open"}
    _page.click(selector)
    return {"ok": True, "selector": selector}


def browser_fill(selector: str, text: str) -> dict[str, Any]:
    if _page is None:
        return {"ok": False, "error": "no browser open"}
    _page.fill(selector, text)
    return {"ok": True, "selector": selector}


def browser_eval(js: str) -> dict[str, Any]:
    if _page is None:
        return {"ok": False, "error": "no browser open"}
    try:
        return {"ok": True, "result": _page.evaluate(js)}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def browser_read_text() -> dict[str, Any]:
    if _page is None:
        return {"ok": False, "error": "no browser open"}
    return {"ok": True, "url": _page.url, "title": _page.title(), "text": _page.inner_text("body")[:100_000]}


def browser_close() -> dict[str, Any]:
    global _page, _browser, _playwright
    if _browser:
        _browser.close()
    if _playwright:
        _playwright.stop()
    _page = _browser = _playwright = None
    return {"ok": True}


BROWSER_TOOLS = {
    "browser_open": browser_open,
    "browser_screenshot": browser_screenshot,
    "browser_click": browser_click,
    "browser_fill": browser_fill,
    "browser_eval": browser_eval,
    "browser_read_text": browser_read_text,
    "browser_close": browser_close,
}
