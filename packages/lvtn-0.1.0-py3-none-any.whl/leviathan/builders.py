"""Builders — delegate app/video/game/voice/image creation to the remote server.

These don't run locally; they POST to the corresponding LeviathanTalon server route
(already deployed on Hetzner) and stream back the result. The result is then saved
to the user's disk via tools.file_write.
"""
from __future__ import annotations
from typing import Any
import requests
from .config import load_config
from .auth import whoami

ROUTES = {
    "build_app":     "/api/builders/app",
    "build_game":    "/api/builders/game",
    "build_video":   "/api/builders/video",
    "build_voice":   "/api/builders/voice",
    "build_image":   "/api/builders/image",
    "build_mobile":  "/api/builders/mobile",
    "build_website": "/api/builders/website",
    "build_saas":    "/api/builders/saas",
}


def _authed_post(path: str, body: dict[str, Any], timeout: int = 600) -> dict[str, Any]:
    cfg = load_config()
    creds = whoami()
    if not creds:
        return {"ok": False, "error": "not logged in. run: leviathan login"}
    headers = {"Authorization": f"Bearer {creds['token']}", "Content-Type": "application/json"}
    url = f"{cfg['api_base']}{path}"
    try:
        r = requests.post(url, json=body, headers=headers, timeout=timeout)
        if r.status_code == 200:
            return {"ok": True, "data": r.json()}
        # Fallback to Hetzner direct
        fb = f"{cfg['fallback_base']}{path}"
        r2 = requests.post(fb, json=body, headers=headers, timeout=timeout)
        if r2.status_code == 200:
            return {"ok": True, "data": r2.json(), "via_fallback": True}
        return {"ok": False, "status": r.status_code, "body": r.text[:2000]}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def build(kind: str, spec: dict[str, Any]) -> dict[str, Any]:
    path = ROUTES.get(kind)
    if not path:
        return {"ok": False, "error": f"unknown builder kind: {kind}. available: {list(ROUTES)}"}
    return _authed_post(path, spec)


BUILDER_TOOLS = {f"build_{k}": (lambda s, _k=k: build(_k, s)) for k in ["app", "game", "video", "voice", "image", "mobile", "website", "saas"]}
