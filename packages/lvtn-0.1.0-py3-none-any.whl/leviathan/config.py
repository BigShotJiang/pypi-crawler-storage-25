"""Config paths and defaults. Cross-platform."""
from __future__ import annotations
import os
import json
from pathlib import Path
from typing import Any

DEFAULT_API_BASE = os.environ.get("LEVIATHAN_API_BASE", "https://api.metanoiaunlimited.com")
HETZNER_FALLBACK = os.environ.get("LEVIATHAN_API_FALLBACK", "http://5.78.196.49:3708")

CONFIG_DIR = Path(os.environ.get("LEVIATHAN_HOME", str(Path.home() / ".leviathan")))
CREDENTIALS_FILE = CONFIG_DIR / "credentials.json"
CONFIG_FILE = CONFIG_DIR / "config.json"
LOG_FILE = CONFIG_DIR / "leviathan.log"

DEFAULT_CONFIG: dict[str, Any] = {
    "api_base": DEFAULT_API_BASE,
    "fallback_base": HETZNER_FALLBACK,
    "allow_writes_outside_home": False,
    "browser_headless": False,
    "default_model": "claude-sonnet-4-5",
}


def ensure_dir() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_credentials() -> dict[str, Any]:
    ensure_dir()
    if not CREDENTIALS_FILE.exists():
        return {}
    try:
        return json.loads(CREDENTIALS_FILE.read_text("utf-8"))
    except Exception:
        return {}


def save_credentials(data: dict[str, Any]) -> None:
    ensure_dir()
    CREDENTIALS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
    try:
        os.chmod(CREDENTIALS_FILE, 0o600)
    except Exception:
        pass  # Windows doesn't honor chmod the same way


def load_config() -> dict[str, Any]:
    ensure_dir()
    if not CONFIG_FILE.exists():
        save_config(DEFAULT_CONFIG)
        return dict(DEFAULT_CONFIG)
    try:
        data = json.loads(CONFIG_FILE.read_text("utf-8"))
        merged = dict(DEFAULT_CONFIG)
        merged.update(data)
        return merged
    except Exception:
        return dict(DEFAULT_CONFIG)


def save_config(data: dict[str, Any]) -> None:
    ensure_dir()
    CONFIG_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
