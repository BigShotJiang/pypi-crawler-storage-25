"""Main CLI entry — `leviathan` and `lvtn` commands."""
from __future__ import annotations
import sys
import click
from rich.console import Console
from rich.markdown import Markdown
from . import __version__
from . import auth as auth_mod
from . import llm_discovery
from . import browser as browser_mod
from .client import run_session
from .tools import TOOL_REGISTRY

console = Console()


@click.group(invoke_without_command=True)
@click.option("--version", is_flag=True, help="Print version and exit")
@click.pass_context
def main(ctx: click.Context, version: bool) -> None:
    """Leviathan — local agent CLI. Runs on your box, executes tools for the remote LLM."""
    if version:
        click.echo(f"leviathan {__version__}")
        return
    if ctx.invoked_subcommand is None:
        # Default: interactive REPL
        interactive()


@main.command()
@click.option("--email", default=None)
@click.option("--token", default=None, help="Paste token directly (skip browser)")
def login(email: str | None, token: str | None) -> None:
    """Log in once. Token is stored in ~/.leviathan/credentials.json (chmod 600)."""
    try:
        c = auth_mod.login(email=email, token=token)
        console.print(f"[green]OK[/green] logged in as {c.get('email','?')}")
    except TimeoutError as e:
        console.print(f"[red]timeout[/red] {e}")
        sys.exit(1)


@main.command()
def logout() -> None:
    """Remove stored credentials."""
    auth_mod.logout()
    console.print("[green]OK[/green] logged out")


@main.command()
def whoami() -> None:
    """Show current credentials (token redacted)."""
    c = auth_mod.whoami()
    if not c:
        console.print("[yellow]not logged in[/yellow]")
        return
    tok = c.get("token", "")
    redacted = f"{tok[:6]}...{tok[-4:]}" if len(tok) > 12 else "***"
    console.print({"email": c.get("email"), "token": redacted, "api_base": c.get("api_base")})


@main.command(name="discover")
def discover_cmd() -> None:
    """Scan localhost + LAN for local LLM servers (Ollama, LM Studio, llama.cpp, vLLM, Jan, etc.)."""
    results = llm_discovery.discover()
    if not results:
        console.print("[yellow]no local LLM servers detected[/yellow]")
        return
    for r in results:
        status = "[green]up[/green]" if r.get("ok") else "[red]down[/red]"
        console.print(f"{status} {r['name']:<14} {r['base_url']}  models={len(r.get('models',[])) if isinstance(r.get('models'),list) else '?'}")


@main.command(name="install-browser")
def install_browser() -> None:
    """One-time: install Playwright Chromium binary."""
    import subprocess
    r = subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"], capture_output=False)
    sys.exit(r.returncode)


@main.command(name="tools")
def tools_list() -> None:
    """List all local tools the CLI can execute on behalf of the remote LLM."""
    from .client import _all_tools
    for name in sorted(_all_tools()):
        console.print(f"  {name}")


@main.command(name="run")
@click.argument("prompt", nargs=-1, required=True)
@click.option("--allow-outside-home", is_flag=True, help="Allow writes outside $HOME (use with care)")
def run_cmd(prompt: tuple[str, ...], allow_outside_home: bool) -> None:
    """One-shot: send prompt, stream result, execute any tool calls locally."""
    text_prompt = " ".join(prompt)
    def on_text(chunk: str) -> None:
        console.print(chunk, end="")
    result = run_session(text_prompt, on_text=on_text, allow_outside_home=allow_outside_home)
    console.print()
    if not result.get("ok"):
        console.print(f"[red]error[/red] {result.get('error') or result}")
        sys.exit(1)


@main.command(name="health")
def health_cmd() -> None:
    """Self-check: credentials, server reachability, local tools, browser, local LLMs."""
    import requests
    from .config import load_config
    cfg = load_config()

    c = auth_mod.whoami()
    console.print(f"[bold]credentials:[/bold] {'[green]OK[/green] '+c.get('email','?') if c else '[red]missing — run: leviathan login[/red]'}")

    for label, url in [("primary", cfg["api_base"]), ("fallback", cfg["fallback_base"])]:
        try:
            r = requests.get(url, timeout=5)
            console.print(f"[bold]{label}:[/bold] [green]{r.status_code}[/green] {url}")
        except Exception as e:
            console.print(f"[bold]{label}:[/bold] [red]{e}[/red] {url}")

    console.print(f"[bold]local tools:[/bold] [green]{len(TOOL_REGISTRY)} registered[/green]")

    try:
        import playwright  # noqa: F401
        console.print("[bold]playwright:[/bold] [green]installed[/green]")
    except ImportError:
        console.print("[bold]playwright:[/bold] [yellow]not installed — run: leviathan install-browser[/yellow]")

    servers = llm_discovery.discover()
    console.print(f"[bold]local LLMs:[/bold] {len(servers)} detected")
    for s in servers:
        console.print(f"  - {s['name']} {s['base_url']}")


def interactive() -> None:
    """Interactive REPL. Ctrl+D or 'exit' to leave."""
    console.print("[bold]Leviathan of HaShem[/bold] — local agent. Type prompt. Ctrl+D or 'exit' to quit.")
    c = auth_mod.whoami()
    if not c:
        console.print("[red]not logged in. run: leviathan login[/red]")
        return
    console.print(f"[dim]logged in as {c.get('email','?')}[/dim]")
    while True:
        try:
            prompt = console.input("[bold cyan]>[/bold cyan] ")
        except (EOFError, KeyboardInterrupt):
            console.print()
            break
        if not prompt.strip():
            continue
        if prompt.strip().lower() in ("exit", "quit"):
            break
        def on_text(chunk: str) -> None:
            console.print(chunk, end="")
        result = run_session(prompt)
        console.print()
        if not result.get("ok"):
            console.print(f"[red]error[/red] {result.get('error') or result}")


if __name__ == "__main__":
    main()
