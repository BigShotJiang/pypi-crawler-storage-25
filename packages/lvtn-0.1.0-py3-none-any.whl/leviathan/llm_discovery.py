"""Discover local LLM servers on the user's machine/LAN.

Scans known ports for: Ollama (11434), LM Studio (1234), llama.cpp server (8080),
oobabooga textgen (5000), vLLM (8000), Jan (1337), KoboldCpp (5001), SillyTavern (8000).

Returns alive endpoints with discovered model lists so the remote LLM can call them locally.
"""
from __future__ import annotations
import socket
from typing import Any
import requests

KNOWN_PROVIDERS = [
    # (name, host, port, probe_path, expected_field)
    ("ollama",      "127.0.0.1", 11434, "/api/tags",           "models"),
    ("lmstudio",    "127.0.0.1",  1234, "/v1/models",          "data"),
    ("llamacpp",    "127.0.0.1",  8080, "/v1/models",          "data"),
    ("oobabooga",   "127.0.0.1",  5000, "/v1/models",          "data"),
    ("vllm",        "127.0.0.1",  8000, "/v1/models",          "data"),
    ("jan",         "127.0.0.1",  1337, "/v1/models",          "data"),
    ("koboldcpp",   "127.0.0.1",  5001, "/api/v1/model",       "result"),
    ("textgen-web", "127.0.0.1",  7860, "/info",               None),
    # LAN default (user's known LM Studio)
    ("lmstudio-lan","10.0.0.79",  1234, "/v1/models",          "data"),
]


def _port_open(host: str, port: int, timeout: float = 0.5) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except (OSError, socket.timeout):
        return False


def discover() -> list[dict[str, Any]]:
    """Return list of alive local LLM endpoints with their model catalogs."""
    alive: list[dict[str, Any]] = []
    for name, host, port, path, field in KNOWN_PROVIDERS:
        if not _port_open(host, port):
            continue
        url = f"http://{host}:{port}"
        info: dict[str, Any] = {"name": name, "base_url": url, "port": port, "host": host}
        try:
            r = requests.get(f"{url}{path}", timeout=3)
            if r.status_code == 200:
                j = r.json()
                if field and field in j:
                    info["models"] = j[field]
                else:
                    info["response"] = j
                info["ok"] = True
            else:
                info["ok"] = False
                info["status"] = r.status_code
        except Exception as e:
            info["ok"] = False
            info["error"] = str(e)
        alive.append(info)
    return alive


def call_local_llm(base_url: str, model: str, prompt: str, max_tokens: int = 512) -> dict[str, Any]:
    """Call a local LLM via OpenAI-compatible /v1/chat/completions."""
    try:
        r = requests.post(
            f"{base_url}/v1/chat/completions",
            json={
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": max_tokens,
            },
            timeout=120,
        )
        if r.status_code == 200:
            j = r.json()
            text = j.get("choices", [{}])[0].get("message", {}).get("content", "")
            return {"ok": True, "text": text, "raw": j}
        return {"ok": False, "status": r.status_code, "body": r.text[:2000]}
    except Exception as e:
        return {"ok": False, "error": str(e)}


LLM_TOOLS = {
    "llm_discover": lambda: {"ok": True, "providers": discover()},
    "llm_call_local": call_local_llm,
}
