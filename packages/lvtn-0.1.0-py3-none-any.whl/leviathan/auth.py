"""Auth flow — browser-redirect OAuth or paste-token fallback."""
from __future__ import annotations
import secrets
import time
import webbrowser
from typing import Optional
import requests
from .config import load_config, save_credentials, load_credentials


def login(email: Optional[str] = None, token: Optional[str] = None) -> dict:
    """Interactive login. Returns saved credential dict.

    Three paths:
    1. --token supplied directly → store and done.
    2. Browser OAuth: open /cli-login?state=<nonce>, poll /api/cli/poll until paired.
    3. Paste-token fallback: prompt user to paste from https://api.metanoiaunlimited.com/settings/tokens.
    """
    cfg = load_config()
    base = cfg["api_base"]

    if token:
        creds = {"email": email or "unknown@leviathan", "token": token, "api_base": base, "created_at": time.time()}
        save_credentials(creds)
        return creds

    # Try browser OAuth
    state = secrets.token_urlsafe(24)
    login_url = f"{base}/cli-login?state={state}"
    print(f"Opening browser: {login_url}")
    try:
        webbrowser.open(login_url)
    except Exception:
        print(f"Open this URL manually: {login_url}")

    # Poll /api/cli/poll?state=<state> for up to 5 min
    deadline = time.time() + 300
    print("Waiting for browser login... (paste-token fallback: Ctrl+C then run `leviathan login --token <YOUR_TOKEN>`)")
    while time.time() < deadline:
        try:
            r = requests.get(f"{base}/api/cli/poll", params={"state": state}, timeout=10)
            if r.status_code == 200:
                j = r.json()
                if j.get("paired") and j.get("token"):
                    creds = {
                        "email": j.get("email", "unknown@leviathan"),
                        "token": j["token"],
                        "api_base": base,
                        "created_at": time.time(),
                    }
                    save_credentials(creds)
                    print(f"Logged in as {creds['email']}")
                    return creds
        except Exception:
            pass
        time.sleep(2)

    raise TimeoutError("Login timed out. Run `leviathan login --token <YOUR_TOKEN>` with a token from your account settings.")


def whoami() -> Optional[dict]:
    creds = load_credentials()
    if not creds.get("token"):
        return None
    return creds


def logout() -> None:
    from .config import CREDENTIALS_FILE
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()
