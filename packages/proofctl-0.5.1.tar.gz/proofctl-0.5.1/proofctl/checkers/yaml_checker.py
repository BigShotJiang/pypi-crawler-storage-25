"""YAML static analysis — PROOFCTL-YAML-* rules."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Iterator

import yaml

from ..models import Finding, Severity
from .base import YamlFileChecker

# ── secret detection ──────────────────────────────────────────────────────────

_SECRET_KEY_RE = re.compile(
    r"^(password|passwd|secret|api[_-]?key|auth[_-]?token|access[_-]?key|"
    r"private[_-]?key|credentials?|client[_-]?secret|db[_-]?pass(?:word)?|"
    r"database[_-]?pass(?:word)?|jwt[_-]?secret|encryption[_-]?key|"
    r"bearer[_-]?token|session[_-]?secret)$",
    re.IGNORECASE,
)

# Looks like a real secret value (not a placeholder like ${VAR} or <value>)
_ENV_VAR_RE = re.compile(r"^\$\{[^}]+\}$|^\$[A-Z_][A-Z0-9_]*$|^<[^>]+>$")

# Known secret value shapes
_SECRET_VALUE_RE = re.compile(
    r"(?:"
    r"(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{36}|"   # GitHub tokens
    r"sk-[A-Za-z0-9]{48,}|"                          # OpenAI
    r"AKIA[A-Z0-9]{16}|"                             # AWS access key
    r"xox[bpoa]-[0-9]+-[A-Za-z0-9-]+"               # Slack tokens
    r")"
)

# GitHub Actions SHA — 40 hex chars
_GH_SHA_RE = re.compile(r"^[0-9a-f]{40}$")

# Image tag patterns
_LATEST_TAG_RE = re.compile(r":latest$")
_NO_TAG_RE = re.compile(r"^[^:@]+$")  # no colon, no @


_NON_SECRET_SCALARS = frozenset({
    "none", "null", "true", "false", "yes", "no", "on", "off", "~", "",
})


def _is_real_secret_value(val: str) -> bool:
    if not val or val.lower() in _NON_SECRET_SCALARS or _ENV_VAR_RE.match(val):
        return False
    if _SECRET_VALUE_RE.search(val):
        return True
    # Any non-placeholder string value assigned to a secret-named key
    return len(val) >= 6 and not re.search(r"[<>{}$]", val)


# ── YAML loading with duplicate-key detection ─────────────────────────────────

class _DupKeyLoader(yaml.SafeLoader):
    pass


def _construct_mapping_detect_dups(loader: _DupKeyLoader, node: yaml.MappingNode) -> dict:
    loader.flatten_mapping(node)
    seen: dict[str, int] = {}  # key → first lineno
    for key_node, _ in node.value:
        key = loader.construct_object(key_node)
        str_key = str(key)
        if str_key in seen:
            lineno = key_node.start_mark.line + 1
            loader._dup_findings.append((str_key, lineno))  # type: ignore[attr-defined]
        else:
            seen[str_key] = key_node.start_mark.line + 1
    return super(_DupKeyLoader, loader).construct_mapping(node)  # type: ignore[misc]


_DupKeyLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
    _construct_mapping_detect_dups,
)


# ── node walking helpers ──────────────────────────────────────────────────────

def _iter_mapping(node: yaml.Node) -> Iterator[tuple[yaml.Node, yaml.Node]]:
    if isinstance(node, yaml.MappingNode):
        yield from node.value


def _scalar(node: yaml.Node | None) -> str | None:
    if isinstance(node, yaml.ScalarNode):
        return node.value
    return None


def _get_key(mapping: yaml.MappingNode, key: str) -> yaml.Node | None:
    for k, v in mapping.value:
        if _scalar(k) == key:
            return v
    return None


def _walk_nodes(node: yaml.Node) -> Iterator[yaml.Node]:
    yield node
    if isinstance(node, yaml.MappingNode):
        for k, v in node.value:
            yield from _walk_nodes(k)
            yield from _walk_nodes(v)
    elif isinstance(node, yaml.SequenceNode):
        for item in node.value:
            yield from _walk_nodes(item)


def _find_all(node: yaml.Node, key: str) -> Iterator[yaml.Node]:
    """Yield all values whose immediate key matches `key` in any nested mapping."""
    if isinstance(node, yaml.MappingNode):
        for k, v in node.value:
            if _scalar(k) == key:
                yield v
            yield from _find_all(v, key)
    elif isinstance(node, yaml.SequenceNode):
        for item in node.value:
            yield from _find_all(item, key)


# ── file-type detection ───────────────────────────────────────────────────────

def _is_k8s(root: yaml.Node | None) -> bool:
    if not isinstance(root, yaml.MappingNode):
        return False
    keys = {_scalar(k) for k, _ in root.value}
    return "apiVersion" in keys and "kind" in keys


def _is_compose(root: yaml.Node | None) -> bool:
    if not isinstance(root, yaml.MappingNode):
        return False
    return "services" in {_scalar(k) for k, _ in root.value}


def _is_gha(path: Path) -> bool:
    parts = path.parts
    return ".github" in parts and "workflows" in parts


def _is_gha_content(root: yaml.Node | None) -> bool:
    """Content-based GHA detection: must have both 'on' (trigger) and 'jobs' keys."""
    if not isinstance(root, yaml.MappingNode):
        return False
    keys = {_scalar(k) for k, _ in root.value}
    return "on" in keys and "jobs" in keys


# ── rule implementations ──────────────────────────────────────────────────────

def _yaml001(root: yaml.Node, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-001 — Hardcoded secret value in YAML."""
    findings: list[Finding] = []
    if not isinstance(root, yaml.MappingNode):
        return findings

    def _walk_mapping(node: yaml.Node) -> None:
        if isinstance(node, yaml.MappingNode):
            for k, v in node.value:
                key = _scalar(k) or ""
                val = _scalar(v)
                if val is not None and _SECRET_KEY_RE.match(key) and _is_real_secret_value(val):
                    findings.append(Finding(
                        file=str(path),
                        line=v.start_mark.line + 1,
                        col=v.start_mark.column,
                        rule_id="PROOFCTL-YAML-001",
                        rule_name="Hardcoded secret in YAML",
                        severity=Severity.ERROR,
                        message=f"Key '{key}' contains a hardcoded secret value",
                        hint="Reference via environment variable: password: ${DB_PASSWORD}",
                        authority="OWASP A02:2025 – Cryptographic Failures / 12-Factor III",
                        docs_url="https://owasp.org/Top10/A02_2021-Cryptographic_Failures/",
                    ))
                elif val is not None and _SECRET_VALUE_RE.search(val):
                    findings.append(Finding(
                        file=str(path),
                        line=v.start_mark.line + 1,
                        col=v.start_mark.column,
                        rule_id="PROOFCTL-YAML-001",
                        rule_name="Hardcoded secret in YAML",
                        severity=Severity.ERROR,
                        message=f"Value under '{key}' matches a known secret format",
                        hint="Remove the secret and reference it via a secret manager or env var.",
                        authority="OWASP A02:2025 – Cryptographic Failures",
                        docs_url="https://owasp.org/Top10/A02_2021-Cryptographic_Failures/",
                    ))
                _walk_mapping(v)
        elif isinstance(node, yaml.SequenceNode):
            for item in node.value:
                _walk_mapping(item)

    _walk_mapping(root)
    return findings


def _yaml002_findings(dup_findings: list[tuple[str, int]], path: Path) -> list[Finding]:
    """PROOFCTL-YAML-002 — Duplicate mapping keys."""
    return [
        Finding(
            file=str(path),
            line=lineno,
            col=0,
            rule_id="PROOFCTL-YAML-002",
            rule_name="Duplicate YAML key",
            severity=Severity.WARNING,
            message=f"Duplicate key '{key}' — later value silently overwrites earlier one",
            hint="Remove the duplicate key. YAML parsers take the last occurrence.",
            authority="YAML spec §3.2.1 – Mapping Keys must be unique",
            docs_url="https://yaml.org/spec/1.2.2/#321-nodes",
        )
        for key, lineno in dup_findings
    ]


def _yaml003_k8s(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-003 — privileged: true in K8s securityContext."""
    findings: list[Finding] = []
    for node in _find_all(root, "securityContext"):
        priv = _get_key(node, "privileged") if isinstance(node, yaml.MappingNode) else None
        if priv and _scalar(priv) in ("true", "True"):
            findings.append(Finding(
                file=str(path),
                line=priv.start_mark.line + 1,
                col=priv.start_mark.column,
                rule_id="PROOFCTL-YAML-003",
                rule_name="Privileged container",
                severity=Severity.ERROR,
                message="securityContext.privileged: true grants the container full host privileges",
                hint="Remove privileged: true. Use specific capabilities if required.",
                authority="CIS Kubernetes Benchmark 5.2.1 – Do not allow privileged containers",
                docs_url="https://www.cisecurity.org/benchmark/kubernetes",
            ))
    return findings


def _yaml004_k8s(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-004 — hostNetwork: true."""
    findings: list[Finding] = []
    for node in _find_all(root, "hostNetwork"):
        if _scalar(node) in ("true", "True"):
            findings.append(Finding(
                file=str(path),
                line=node.start_mark.line + 1,
                col=node.start_mark.column,
                rule_id="PROOFCTL-YAML-004",
                rule_name="Host network sharing",
                severity=Severity.WARNING,
                message="hostNetwork: true exposes the pod on the host's network namespace",
                hint="Remove hostNetwork unless strictly required (e.g., CNI plugins).",
                authority="CIS Kubernetes Benchmark 5.2.4 – Do not use host network namespace",
                docs_url="https://www.cisecurity.org/benchmark/kubernetes",
            ))
    return findings


_SENSITIVE_HOST_PATHS = (
    "/", "/etc", "/var", "/var/run", "/var/run/docker.sock", "/var/lib",
    "/proc", "/sys", "/root", "/home", "/usr", "/usr/lib", "/boot",
)


def _yaml019_k8s(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-019 — hostPath volume mounts host filesystem into the pod."""
    findings: list[Finding] = []
    for node in _find_all(root, "hostPath"):
        if not isinstance(node, yaml.MappingNode):
            continue
        host_path_node = _get_key(node, "path")
        host_path = (_scalar(host_path_node) or "").strip()
        sensitive = host_path in _SENSITIVE_HOST_PATHS or host_path.endswith("docker.sock")
        severity = Severity.ERROR if sensitive else Severity.WARNING
        msg = (
            f'hostPath mounts "{host_path}" — sensitive host directory exposed to container'
            if sensitive
            else f'hostPath mounts "{host_path}" — host filesystem is exposed to the container'
        )
        findings.append(Finding(
            file=str(path),
            line=node.start_mark.line + 1,
            col=node.start_mark.column,
            rule_id="PROOFCTL-YAML-019",
            rule_name="hostPath volume mount",
            severity=severity,
            message=msg,
            hint="Use emptyDir, configMap, or persistentVolumeClaim instead. Avoid hostPath unless required (e.g., CNI/CSI drivers).",
            authority="CIS Kubernetes Benchmark 5.2.9 – Minimize the admission of containers with hostPath volumes",
            docs_url="https://www.cisecurity.org/benchmark/kubernetes",
        ))
    return findings


def _yaml005_k8s(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-005 — K8s container missing resource limits."""
    findings: list[Finding] = []
    for containers_node in _find_all(root, "containers"):
        if not isinstance(containers_node, yaml.SequenceNode):
            continue
        for container in containers_node.value:
            if not isinstance(container, yaml.MappingNode):
                continue
            name_node = _get_key(container, "name")
            name = _scalar(name_node) or "unnamed"
            resources = _get_key(container, "resources")
            if resources is None:
                findings.append(Finding(
                    file=str(path),
                    line=container.start_mark.line + 1,
                    col=container.start_mark.column,
                    rule_id="PROOFCTL-YAML-005",
                    rule_name="Missing resource limits",
                    severity=Severity.WARNING,
                    message=f"Container '{name}' has no resources block — unlimited CPU/memory",
                    hint="Add resources.limits.cpu and resources.limits.memory.",
                    authority="K8s Best Practices – Resource Management for Pods and Containers",
                    docs_url="https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/",
                ))
            elif isinstance(resources, yaml.MappingNode):
                limits = _get_key(resources, "limits")
                if limits is None:
                    findings.append(Finding(
                        file=str(path),
                        line=resources.start_mark.line + 1,
                        col=resources.start_mark.column,
                        rule_id="PROOFCTL-YAML-005",
                        rule_name="Missing resource limits",
                        severity=Severity.WARNING,
                        message=f"Container '{name}' has resources.requests but no resources.limits",
                        hint="Add resources.limits.cpu and resources.limits.memory.",
                        authority="K8s Best Practices – Resource Management for Pods and Containers",
                    ))
    return findings


def _yaml006_image_latest(root: yaml.Node, path: Path, rule_id: str) -> list[Finding]:
    """Shared helper: flag image: latest or image with no tag."""
    findings: list[Finding] = []
    for node in _find_all(root, "image"):
        val = _scalar(node)
        if val is None or "@sha256:" in val:
            continue
        if _LATEST_TAG_RE.search(val) or _NO_TAG_RE.match(val.split("/")[-1]):
            sev = Severity.ERROR if ":latest" in val else Severity.WARNING
            findings.append(Finding(
                file=str(path),
                line=node.start_mark.line + 1,
                col=node.start_mark.column,
                rule_id=rule_id,
                rule_name="Unpinned image tag",
                severity=sev,
                message=f"image: '{val}' uses a mutable tag (deploy will differ across environments)",
                hint="Pin to a specific digest: image: nginx:1.27@sha256:<digest>",
                authority="SLSA Supply Chain – Image provenance",
                docs_url="https://slsa.dev/spec/v1.0/levels",
            ))
    return findings


def _yaml007_gha(root: yaml.Node, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-007 — GitHub Actions uses: not pinned to full SHA."""
    findings: list[Finding] = []
    for node in _find_all(root, "uses"):
        val = _scalar(node)
        if val is None or val.startswith("./.") or val.startswith("./"):
            continue  # local action
        # Format: owner/repo@ref
        if "@" not in val:
            continue
        _, ref = val.rsplit("@", 1)
        if _GH_SHA_RE.match(ref):
            continue  # pinned to SHA — clean
        # Tiered severity: branch/HEAD refs are higher risk than semver tags
        _HIGH_RISK_REFS = {"main", "master", "HEAD", "latest", "develop", "dev"}
        _SEMVER_RE = re.compile(r"^v?\d+(\.\d+)*$")
        if ref in _HIGH_RISK_REFS:
            sev = Severity.ERROR
        elif _SEMVER_RE.match(ref):
            sev = Severity.INFO  # semver tag is the GitHub-recommended form for major actions
        else:
            sev = Severity.WARNING  # unknown ref pattern — could be a branch
        findings.append(Finding(
            file=str(path),
            line=node.start_mark.line + 1,
            col=node.start_mark.column,
            rule_id="PROOFCTL-YAML-007",
            rule_name="GitHub Action not pinned to SHA",
            severity=sev,
            message=f"uses: '{val}' references a mutable ref '{ref}' — supply chain risk",
            hint=f"Pin to the action's full commit SHA: uses: {val.split('@')[0]}@<40-char-sha>",
            authority="SLSA Supply Chain L3 – GitHub Actions pinning",
            docs_url="https://slsa.dev/spec/v1.0/levels",
        ))
    return findings


def _yaml008_compose_privileged(root: yaml.Node, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-008 — privileged: true in Docker Compose service."""
    findings: list[Finding] = []
    for node in _find_all(root, "privileged"):
        if _scalar(node) in ("true", "True"):
            findings.append(Finding(
                file=str(path),
                line=node.start_mark.line + 1,
                col=node.start_mark.column,
                rule_id="PROOFCTL-YAML-008",
                rule_name="Privileged Docker Compose service",
                severity=Severity.ERROR,
                message="privileged: true grants the container full host privileges",
                hint="Remove privileged: true. Use specific capabilities if required.",
                authority="CIS Docker Benchmark 5.4 – Do not use privileged containers",
                docs_url="https://www.cisecurity.org/benchmark/docker",
            ))
    return findings


# ── K8s container iterator ────────────────────────────────────────────────────

def _iter_containers(root: yaml.MappingNode) -> Iterator[yaml.MappingNode]:
    """Yield each container MappingNode from spec.containers, spec.initContainers,
    and spec.template.spec.containers (covers Pods, Deployments, DaemonSets, etc.)."""
    spec = _get_key(root, "spec")
    if not isinstance(spec, yaml.MappingNode):
        return
    # Direct container lists (Pod, DaemonSet, etc.)
    for list_key in ("containers", "initContainers"):
        seq = _get_key(spec, list_key)
        if isinstance(seq, yaml.SequenceNode):
            for item in seq.value:
                if isinstance(item, yaml.MappingNode):
                    yield item
    # Deployment / StatefulSet: spec.template.spec.containers
    template = _get_key(spec, "template")
    if isinstance(template, yaml.MappingNode):
        tmpl_spec = _get_key(template, "spec")
        if isinstance(tmpl_spec, yaml.MappingNode):
            for list_key in ("containers", "initContainers"):
                seq = _get_key(tmpl_spec, list_key)
                if isinstance(seq, yaml.SequenceNode):
                    for item in seq.value:
                        if isinstance(item, yaml.MappingNode):
                            yield item


def _pod_security_context(root: yaml.MappingNode) -> yaml.MappingNode | None:
    """Return the pod-level securityContext (if any) for inheritance checks.

    K8s resolves seccompProfile, runAsNonRoot, runAsUser, fsGroup etc. by
    inheriting pod-level → container unless the container overrides. Rules
    that check container-level only produce false positives on workloads
    that legitimately set the policy at pod level.
    """
    spec = _get_key(root, "spec")
    if not isinstance(spec, yaml.MappingNode):
        return None
    # Pod-direct
    sc = _get_key(spec, "securityContext")
    if isinstance(sc, yaml.MappingNode):
        return sc
    # Deployment/StatefulSet → spec.template.spec.securityContext
    template = _get_key(spec, "template")
    if isinstance(template, yaml.MappingNode):
        tmpl_spec = _get_key(template, "spec")
        if isinstance(tmpl_spec, yaml.MappingNode):
            sc = _get_key(tmpl_spec, "securityContext")
            if isinstance(sc, yaml.MappingNode):
                return sc
    # CronJob/Job → spec.jobTemplate.spec.template.spec.securityContext
    job_tmpl = _get_key(spec, "jobTemplate")
    if isinstance(job_tmpl, yaml.MappingNode):
        job_spec = _get_key(job_tmpl, "spec")
        if isinstance(job_spec, yaml.MappingNode):
            inner_tmpl = _get_key(job_spec, "template")
            if isinstance(inner_tmpl, yaml.MappingNode):
                inner_spec = _get_key(inner_tmpl, "spec")
                if isinstance(inner_spec, yaml.MappingNode):
                    sc = _get_key(inner_spec, "securityContext")
                    if isinstance(sc, yaml.MappingNode):
                        return sc
    return None


# ── dangerous Linux capabilities ──────────────────────────────────────────────
_DANGEROUS_CAPS = frozenset({
    "SYS_ADMIN", "NET_ADMIN", "SYS_PTRACE", "SYS_MODULE",
    "DAC_OVERRIDE", "DAC_READ_SEARCH",
})


def _yaml009_k8s(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-009 — securityContext.runAsNonRoot absent or false."""
    findings: list[Finding] = []
    for container in _iter_containers(root):
        name_node = _get_key(container, "name")
        name = _scalar(name_node) or "unnamed"
        sc = _get_key(container, "securityContext")
        if not isinstance(sc, yaml.MappingNode):
            findings.append(Finding(
                file=str(path),
                line=container.start_mark.line + 1,
                col=container.start_mark.column,
                rule_id="PROOFCTL-YAML-009",
                rule_name="runAsNonRoot not enforced",
                severity=Severity.WARNING,
                message=f"Container '{name}' has no runAsNonRoot: true — process may run as UID 0",
                hint="Add securityContext: runAsNonRoot: true",
                authority="Kubernetes Pod Security Standards – Restricted / CIS K8s Benchmark 5.2.6",
                docs_url="https://kubernetes.io/docs/concepts/security/pod-security-standards/",
            ))
            continue
        val_node = _get_key(sc, "runAsNonRoot")
        if val_node is None:
            findings.append(Finding(
                file=str(path),
                line=sc.start_mark.line + 1,
                col=sc.start_mark.column,
                rule_id="PROOFCTL-YAML-009",
                rule_name="runAsNonRoot not enforced",
                severity=Severity.WARNING,
                message=f"Container '{name}' has no runAsNonRoot: true — process may run as UID 0",
                hint="Add securityContext: runAsNonRoot: true",
                authority="Kubernetes Pod Security Standards – Restricted / CIS K8s Benchmark 5.2.6",
                docs_url="https://kubernetes.io/docs/concepts/security/pod-security-standards/",
            ))
        elif _scalar(val_node) in ("false", "False"):
            findings.append(Finding(
                file=str(path),
                line=val_node.start_mark.line + 1,
                col=val_node.start_mark.column,
                rule_id="PROOFCTL-YAML-009",
                rule_name="runAsNonRoot not enforced",
                severity=Severity.ERROR,
                message=f"Container '{name}' has no runAsNonRoot: true — process may run as UID 0",
                hint="Add securityContext: runAsNonRoot: true",
                authority="Kubernetes Pod Security Standards – Restricted / CIS K8s Benchmark 5.2.6",
                docs_url="https://kubernetes.io/docs/concepts/security/pod-security-standards/",
            ))
    return findings


def _yaml010_k8s(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-010 — securityContext.allowPrivilegeEscalation absent or true."""
    findings: list[Finding] = []
    for container in _iter_containers(root):
        name_node = _get_key(container, "name")
        name = _scalar(name_node) or "unnamed"
        sc = _get_key(container, "securityContext")
        if not isinstance(sc, yaml.MappingNode):
            # securityContext entirely absent — flag
            findings.append(Finding(
                file=str(path),
                line=container.start_mark.line + 1,
                col=container.start_mark.column,
                rule_id="PROOFCTL-YAML-010",
                rule_name="allowPrivilegeEscalation not disabled",
                severity=Severity.ERROR,
                message=f"Container '{name}' allows privilege escalation via setuid/setgid binaries",
                hint="Add securityContext: allowPrivilegeEscalation: false",
                authority="Kubernetes PSS Restricted / CIS K8s Benchmark 5.2.5",
                docs_url="https://kubernetes.io/docs/concepts/security/pod-security-standards/",
            ))
            continue
        val_node = _get_key(sc, "allowPrivilegeEscalation")
        if val_node is None or _scalar(val_node) in ("true", "True"):
            line = val_node.start_mark.line + 1 if val_node else sc.start_mark.line + 1
            col = val_node.start_mark.column if val_node else sc.start_mark.column
            findings.append(Finding(
                file=str(path),
                line=line,
                col=col,
                rule_id="PROOFCTL-YAML-010",
                rule_name="allowPrivilegeEscalation not disabled",
                severity=Severity.ERROR,
                message=f"Container '{name}' allows privilege escalation via setuid/setgid binaries",
                hint="Add securityContext: allowPrivilegeEscalation: false",
                authority="Kubernetes PSS Restricted / CIS K8s Benchmark 5.2.5",
                docs_url="https://kubernetes.io/docs/concepts/security/pod-security-standards/",
            ))
    return findings


def _yaml011_k8s(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-011 — securityContext.readOnlyRootFilesystem absent or false."""
    findings: list[Finding] = []
    for container in _iter_containers(root):
        name_node = _get_key(container, "name")
        name = _scalar(name_node) or "unnamed"
        sc = _get_key(container, "securityContext")
        if not isinstance(sc, yaml.MappingNode):
            findings.append(Finding(
                file=str(path),
                line=container.start_mark.line + 1,
                col=container.start_mark.column,
                rule_id="PROOFCTL-YAML-011",
                rule_name="Writable root filesystem",
                severity=Severity.WARNING,
                message=f"Container '{name}' has a writable root filesystem — attackers can persist malware",
                hint="Add securityContext: readOnlyRootFilesystem: true. Mount writable paths as emptyDir volumes.",
                authority="Kubernetes PSS Restricted / CIS K8s Benchmark 5.2.3",
                docs_url="https://kubernetes.io/docs/concepts/security/pod-security-standards/",
            ))
            continue
        val_node = _get_key(sc, "readOnlyRootFilesystem")
        if val_node is None or _scalar(val_node) in ("false", "False"):
            line = val_node.start_mark.line + 1 if val_node else sc.start_mark.line + 1
            col = val_node.start_mark.column if val_node else sc.start_mark.column
            findings.append(Finding(
                file=str(path),
                line=line,
                col=col,
                rule_id="PROOFCTL-YAML-011",
                rule_name="Writable root filesystem",
                severity=Severity.WARNING,
                message=f"Container '{name}' has a writable root filesystem — attackers can persist malware",
                hint="Add securityContext: readOnlyRootFilesystem: true. Mount writable paths as emptyDir volumes.",
                authority="Kubernetes PSS Restricted / CIS K8s Benchmark 5.2.3",
                docs_url="https://kubernetes.io/docs/concepts/security/pod-security-standards/",
            ))
    return findings


def _yaml012_k8s(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-012 — capabilities: drop ALL missing, or dangerous caps added."""
    findings: list[Finding] = []
    for container in _iter_containers(root):
        name_node = _get_key(container, "name")
        name = _scalar(name_node) or "unnamed"
        sc = _get_key(container, "securityContext")
        caps_node = _get_key(sc, "capabilities") if isinstance(sc, yaml.MappingNode) else None

        # Check for dangerous caps in 'add'
        if isinstance(caps_node, yaml.MappingNode):
            add_node = _get_key(caps_node, "add")
            if isinstance(add_node, yaml.SequenceNode):
                for item in add_node.value:
                    cap = (_scalar(item) or "").upper()
                    if cap in _DANGEROUS_CAPS:
                        findings.append(Finding(
                            file=str(path),
                            line=item.start_mark.line + 1,
                            col=item.start_mark.column,
                            rule_id="PROOFCTL-YAML-012",
                            rule_name="Dangerous Linux capability added",
                            severity=Severity.ERROR,
                            message=f"Container '{name}' adds dangerous capability '{cap}'",
                            hint="Remove dangerous capabilities from securityContext.capabilities.add",
                            authority="Kubernetes PSS Restricted – Capabilities / CIS K8s Benchmark 5.2.8/9",
                            docs_url="https://kubernetes.io/docs/concepts/security/pod-security-standards/",
                        ))

        # Check that 'drop: [ALL]' is present
        drop_all = False
        if isinstance(caps_node, yaml.MappingNode):
            drop_node = _get_key(caps_node, "drop")
            if isinstance(drop_node, yaml.SequenceNode):
                for item in drop_node.value:
                    if (_scalar(item) or "").upper() == "ALL":
                        drop_all = True
                        break

        if not drop_all:
            line = caps_node.start_mark.line + 1 if caps_node else (
                sc.start_mark.line + 1 if isinstance(sc, yaml.MappingNode) else container.start_mark.line + 1
            )
            col = caps_node.start_mark.column if caps_node else (
                sc.start_mark.column if isinstance(sc, yaml.MappingNode) else container.start_mark.column
            )
            findings.append(Finding(
                file=str(path),
                line=line,
                col=col,
                rule_id="PROOFCTL-YAML-012",
                rule_name="Capabilities not fully dropped",
                severity=Severity.WARNING,
                message=f"Container '{name}' does not drop ALL capabilities",
                hint="Add securityContext: capabilities: drop: [ALL]",
                authority="Kubernetes PSS Restricted – Capabilities / CIS K8s Benchmark 5.2.8/9",
                docs_url="https://kubernetes.io/docs/concepts/security/pod-security-standards/",
            ))
    return findings


def _yaml013_k8s(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-013 — seccompProfile absent or type: Unconfined.

    Honors K8s inheritance: a pod-level seccompProfile applies to all
    containers unless they override. Only fires when neither pod-level
    nor container-level supplies a valid profile.
    """
    findings: list[Finding] = []
    pod_sc = _pod_security_context(root)
    pod_profile = _get_key(pod_sc, "seccompProfile") if pod_sc else None
    pod_profile_type = (
        _scalar(_get_key(pod_profile, "type"))
        if isinstance(pod_profile, yaml.MappingNode) else None
    )
    pod_inherits_ok = (
        pod_profile is not None and pod_profile_type and pod_profile_type != "Unconfined"
    )
    for container in _iter_containers(root):
        name_node = _get_key(container, "name")
        name = _scalar(name_node) or "unnamed"
        sc = _get_key(container, "securityContext")
        if not isinstance(sc, yaml.MappingNode):
            if pod_inherits_ok:
                continue  # pod-level seccomp applies
            findings.append(Finding(
                file=str(path),
                line=container.start_mark.line + 1,
                col=container.start_mark.column,
                rule_id="PROOFCTL-YAML-013",
                rule_name="No seccomp profile",
                severity=Severity.WARNING,
                message=f"Container '{name}' has no seccomp profile — all syscalls are allowed",
                hint="Add securityContext: seccompProfile: type: RuntimeDefault",
                authority="Kubernetes PSS Restricted / CIS K8s Benchmark 5.7.2",
                docs_url="https://kubernetes.io/docs/concepts/security/pod-security-standards/",
            ))
            continue
        profile_node = _get_key(sc, "seccompProfile")
        if profile_node is None and pod_inherits_ok:
            continue  # container has SC but no seccomp; pod-level inherits
        if profile_node is None:
            findings.append(Finding(
                file=str(path),
                line=sc.start_mark.line + 1,
                col=sc.start_mark.column,
                rule_id="PROOFCTL-YAML-013",
                rule_name="No seccomp profile",
                severity=Severity.WARNING,
                message=f"Container '{name}' has no seccomp profile — all syscalls are allowed",
                hint="Add securityContext: seccompProfile: type: RuntimeDefault",
                authority="Kubernetes PSS Restricted / CIS K8s Benchmark 5.7.2",
                docs_url="https://kubernetes.io/docs/concepts/security/pod-security-standards/",
            ))
        elif isinstance(profile_node, yaml.MappingNode):
            type_node = _get_key(profile_node, "type")
            if _scalar(type_node) == "Unconfined":
                findings.append(Finding(
                    file=str(path),
                    line=type_node.start_mark.line + 1,
                    col=type_node.start_mark.column,
                    rule_id="PROOFCTL-YAML-013",
                    rule_name="No seccomp profile",
                    severity=Severity.WARNING,
                    message=f"Container '{name}' has no seccomp profile — all syscalls are allowed",
                    hint="Add securityContext: seccompProfile: type: RuntimeDefault",
                    authority="Kubernetes PSS Restricted / CIS K8s Benchmark 5.7.2",
                ))
    return findings


def _yaml014_k8s(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-014 — automountServiceAccountToken absent or true."""
    _APPLICABLE_KINDS = frozenset({
        "Deployment", "DaemonSet", "StatefulSet", "ReplicaSet",
        "Job", "CronJob", "Pod",
    })
    findings: list[Finding] = []
    kind_node = _get_key(root, "kind")
    kind = _scalar(kind_node) or ""
    if kind not in _APPLICABLE_KINDS:
        return findings

    name_node = next(
        (v for k, v in root.value if _scalar(k) == "name"),
        None,
    )
    # Try metadata.name
    meta = _get_key(root, "metadata")
    if isinstance(meta, yaml.MappingNode):
        n = _get_key(meta, "name")
        if n:
            name_node = n
    resource_name = _scalar(name_node) or "unnamed"

    # Determine the spec to check (Pod vs Deployment/etc.)
    spec = _get_key(root, "spec")
    if not isinstance(spec, yaml.MappingNode):
        return findings

    if kind == "Pod":
        check_spec = spec
    else:
        template = _get_key(spec, "template")
        if not isinstance(template, yaml.MappingNode):
            return findings
        check_spec = _get_key(template, "spec")
        if not isinstance(check_spec, yaml.MappingNode):
            return findings

    amt_node = _get_key(check_spec, "automountServiceAccountToken")
    if amt_node is None or _scalar(amt_node) in ("true", "True"):
        line = amt_node.start_mark.line + 1 if amt_node else check_spec.start_mark.line + 1
        col = amt_node.start_mark.column if amt_node else check_spec.start_mark.column
        findings.append(Finding(
            file=str(path),
            line=line,
            col=col,
            rule_id="PROOFCTL-YAML-014",
            rule_name="Service account token auto-mounted",
            severity=Severity.WARNING,
            message=(
                f"'{kind}/{resource_name}' auto-mounts a service account token"
                " — provides API server access to any compromised container"
            ),
            hint="Add automountServiceAccountToken: false unless the pod actually calls the K8s API.",
            authority="CIS K8s Benchmark 5.1.6",
            docs_url="https://www.cisecurity.org/benchmark/kubernetes",
        ))
    return findings


def _yaml015_k8s(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-015 — ClusterRoleBinding with roleRef.name: cluster-admin."""
    findings: list[Finding] = []
    kind_node = _get_key(root, "kind")
    if _scalar(kind_node) != "ClusterRoleBinding":
        return findings

    meta = _get_key(root, "metadata")
    name = "unnamed"
    if isinstance(meta, yaml.MappingNode):
        n = _get_key(meta, "name")
        name = _scalar(n) or "unnamed"

    role_ref = _get_key(root, "roleRef")
    if not isinstance(role_ref, yaml.MappingNode):
        return findings
    ref_name_node = _get_key(role_ref, "name")
    if _scalar(ref_name_node) == "cluster-admin":
        findings.append(Finding(
            file=str(path),
            line=ref_name_node.start_mark.line + 1,
            col=ref_name_node.start_mark.column,
            rule_id="PROOFCTL-YAML-015",
            rule_name="cluster-admin ClusterRoleBinding",
            severity=Severity.ERROR,
            message=(
                f"ClusterRoleBinding '{name}' grants cluster-admin"
                " — unrestricted superuser access to all namespaces"
            ),
            hint="Grant the minimum RBAC role needed. Avoid cluster-admin for regular workloads.",
            authority="CIS K8s Benchmark 5.1.1 / OWASP K8s Top 10 – K02",
            docs_url="https://www.cisecurity.org/benchmark/kubernetes",
        ))
    return findings


def _yaml016_017_k8s(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-016/017 — RBAC wildcard and privilege-escalation verbs."""
    _ESCALATION_VERBS = frozenset({"escalate", "bind", "impersonate"})
    findings: list[Finding] = []
    kind_node = _get_key(root, "kind")
    kind = _scalar(kind_node) or ""
    if kind not in ("Role", "ClusterRole"):
        return findings

    meta = _get_key(root, "metadata")
    name = "unnamed"
    if isinstance(meta, yaml.MappingNode):
        n = _get_key(meta, "name")
        name = _scalar(n) or "unnamed"

    rules_node = _get_key(root, "rules")
    if not isinstance(rules_node, yaml.SequenceNode):
        return findings

    for rule in rules_node.value:
        if not isinstance(rule, yaml.MappingNode):
            continue
        # YAML-016 — wildcards
        for field in ("verbs", "resources"):
            field_node = _get_key(rule, field)
            if isinstance(field_node, yaml.SequenceNode):
                for item in field_node.value:
                    if _scalar(item) == "*":
                        findings.append(Finding(
                            file=str(path),
                            line=item.start_mark.line + 1,
                            col=item.start_mark.column,
                            rule_id="PROOFCTL-YAML-016",
                            rule_name="RBAC wildcard permission",
                            severity=Severity.ERROR,
                            message=(
                                f"RBAC rule in '{kind}/{name}' uses wildcard '*' for {field}"
                                " — overly broad permissions"
                            ),
                            hint="Replace '*' with the specific verbs/resources required.",
                            authority="CIS K8s Benchmark 5.1.3",
                            docs_url="https://www.cisecurity.org/benchmark/kubernetes",
                        ))
        # YAML-017 — privilege-escalation verbs
        verbs_node = _get_key(rule, "verbs")
        if isinstance(verbs_node, yaml.SequenceNode):
            for item in verbs_node.value:
                verb = _scalar(item) or ""
                if verb in _ESCALATION_VERBS:
                    findings.append(Finding(
                        file=str(path),
                        line=item.start_mark.line + 1,
                        col=item.start_mark.column,
                        rule_id="PROOFCTL-YAML-017",
                        rule_name="RBAC privilege-escalation verb",
                        severity=Severity.ERROR,
                        message=(
                            f"RBAC rule in '{kind}/{name}' grants '{verb}' verb"
                            " — enables privilege escalation"
                        ),
                        hint=f"Remove the '{verb}' verb unless explicitly required.",
                        authority="Kubernetes RBAC Good Practices – Privilege escalation risks",
                        docs_url="https://kubernetes.io/docs/concepts/security/rbac-good-practices/",
                    ))
    return findings


def _yaml018_k8s(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-018 — Container missing both livenessProbe and readinessProbe."""
    findings: list[Finding] = []
    for container in _iter_containers(root):
        name_node = _get_key(container, "name")
        name = _scalar(name_node) or "unnamed"
        liveness = _get_key(container, "livenessProbe")
        readiness = _get_key(container, "readinessProbe")
        if liveness is None and readiness is None:
            findings.append(Finding(
                file=str(path),
                line=container.start_mark.line + 1,
                col=container.start_mark.column,
                rule_id="PROOFCTL-YAML-018",
                rule_name="Missing health probes",
                severity=Severity.WARNING,
                message=(
                    f"Container '{name}' has no liveness or readiness probes"
                    " — orchestrator cannot detect failures"
                ),
                hint="Add livenessProbe and readinessProbe with httpGet or exec checks.",
                authority="K8s Best Practices – Configure Liveness, Readiness and Startup Probes",
                docs_url="https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/",
            ))
    return findings


def _yaml020_k8s(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-020 — Ingress with no TLS block."""
    findings: list[Finding] = []
    kind_node = _get_key(root, "kind")
    if _scalar(kind_node) != "Ingress":
        return findings

    meta = _get_key(root, "metadata")
    name = "unnamed"
    if isinstance(meta, yaml.MappingNode):
        n = _get_key(meta, "name")
        name = _scalar(n) or "unnamed"

    spec = _get_key(root, "spec")
    tls_absent = True
    if isinstance(spec, yaml.MappingNode):
        tls_node = _get_key(spec, "tls")
        if tls_node is not None:
            # Check for empty list
            if isinstance(tls_node, yaml.SequenceNode) and len(tls_node.value) == 0:
                tls_absent = True
            else:
                tls_absent = False

    if tls_absent:
        line = spec.start_mark.line + 1 if isinstance(spec, yaml.MappingNode) else root.start_mark.line + 1
        col = spec.start_mark.column if isinstance(spec, yaml.MappingNode) else root.start_mark.column
        findings.append(Finding(
            file=str(path),
            line=line,
            col=col,
            rule_id="PROOFCTL-YAML-020",
            rule_name="Ingress missing TLS",
            severity=Severity.WARNING,
            message=f"Ingress '{name}' has no TLS configuration — traffic served over plain HTTP",
            hint="Add spec.tls with secretName pointing to a TLS certificate.",
            authority="K8s Security – Ingress TLS",
            docs_url="https://kubernetes.io/docs/concepts/services-networking/ingress/#tls",
        ))
    return findings


def _yaml021_k8s(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-021 — Secret value in env[*].value (plaintext, not secretKeyRef)."""
    findings: list[Finding] = []
    for container in _iter_containers(root):
        container_name_node = _get_key(container, "name")
        container_name = _scalar(container_name_node) or "unnamed"
        env_node = _get_key(container, "env")
        if not isinstance(env_node, yaml.SequenceNode):
            continue
        for env_item in env_node.value:
            if not isinstance(env_item, yaml.MappingNode):
                continue
            env_name_node = _get_key(env_item, "name")
            env_name = _scalar(env_name_node) or ""
            if not _SECRET_KEY_RE.match(env_name):
                continue
            # Only flag if 'value' is present (not 'valueFrom')
            value_node = _get_key(env_item, "value")
            value_from_node = _get_key(env_item, "valueFrom")
            if value_node is not None and value_from_node is None:
                findings.append(Finding(
                    file=str(path),
                    line=value_node.start_mark.line + 1,
                    col=value_node.start_mark.column,
                    rule_id="PROOFCTL-YAML-021",
                    rule_name="Plaintext secret in env var",
                    severity=Severity.ERROR,
                    message=(
                        f"Env var '{env_name}' in container '{container_name}' has a plaintext value"
                        " — use secretKeyRef"
                    ),
                    hint="Use env: - name: FOO valueFrom: secretKeyRef: name: my-secret key: foo",
                    authority="OWASP A02:2021 – Cryptographic Failures",
                    docs_url="https://owasp.org/Top10/A02_2021-Cryptographic_Failures/",
                ))
    return findings


# ── data-exfiltration / hardening rules (YAML-022..YAML-026) ─────────────────

_WORKLOAD_KINDS = frozenset({
    "Deployment", "StatefulSet", "DaemonSet", "Pod",
    "Job", "CronJob", "ReplicaSet", "ReplicationController",
})


def _yaml022_default_namespace(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-022 — Workload uses the `default` namespace (or omits one)."""
    kind_node = _get_key(root, "kind")
    kind = _scalar(kind_node) or ""
    if kind not in _WORKLOAD_KINDS:
        return []
    meta = _get_key(root, "metadata")
    name = "unnamed"
    ns_value: str | None = None
    line = root.start_mark.line + 1
    col = root.start_mark.column
    if isinstance(meta, yaml.MappingNode):
        n_node = _get_key(meta, "name")
        name = _scalar(n_node) or "unnamed"
        ns_node = _get_key(meta, "namespace")
        if ns_node is not None:
            ns_value = _scalar(ns_node)
            line = ns_node.start_mark.line + 1
            col = ns_node.start_mark.column
        else:
            line = meta.start_mark.line + 1
            col = meta.start_mark.column
    if ns_value is None or ns_value == "default":
        return [Finding(
            file=str(path),
            line=line,
            col=col,
            rule_id="PROOFCTL-YAML-022",
            rule_name="Workload in default namespace",
            severity=Severity.WARNING,
            message=f"Workload '{name}' uses the default namespace — multi-tenant isolation is weakened",
            hint="Set metadata.namespace to a dedicated namespace per team/app.",
            authority="CIS Kubernetes Benchmark 5.7.4 – Do not use the default namespace",
            docs_url="https://www.cisecurity.org/benchmark/kubernetes",
        )]
    return []


def _yaml023_image_digest(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-023 — Container image not pinned to @sha256: digest.

    Avoids double-firing with YAML-006 (which covers :latest and untagged images)
    by skipping any image YAML-006 already flags.
    """
    findings: list[Finding] = []
    for node in _find_all(root, "image"):
        val = _scalar(node)
        if val is None:
            continue
        # Skip Dockerfile-style stage aliases (no slash, no colon) and localhost refs
        if ("/" not in val and ":" not in val) or val.startswith("localhost"):
            continue
        if "@sha256:" in val:
            continue
        # Defer to YAML-006 for :latest and entirely untagged images
        if _LATEST_TAG_RE.search(val):
            continue
        if _NO_TAG_RE.match(val.split("/")[-1]):
            continue
        findings.append(Finding(
            file=str(path),
            line=node.start_mark.line + 1,
            col=node.start_mark.column,
            rule_id="PROOFCTL-YAML-023",
            rule_name="Image not pinned to digest",
            severity=Severity.INFO,
            message=f"image: '{val}' is pinned by tag only — tags are mutable and can be re-pushed",
            hint=f"Pin to an immutable digest: image: {val}@sha256:<digest>",
            authority="SLSA Supply Chain L3 – Provenance / Image immutability",
            docs_url="https://slsa.dev/spec/v1.0/levels",
        ))
    return findings


def _yaml024_runasuser_low(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-024 — runAsUser explicitly set to root (0) or a low UID (<10000).

    Only fires when runAsUser is explicitly set; absence is covered by YAML-009.
    Does not double-fire with YAML-AI-003 (which only flags UID 0); YAML-024
    handles the 1..9999 range.
    """
    findings: list[Finding] = []
    for node in _find_all(root, "runAsUser"):
        raw = _scalar(node)
        if raw is None:
            continue
        try:
            uid = int(raw)
        except ValueError:
            continue
        if uid == 0:
            findings.append(Finding(
                file=str(path),
                line=node.start_mark.line + 1,
                col=node.start_mark.column,
                rule_id="PROOFCTL-YAML-024",
                rule_name="Container runAsUser is root or low UID",
                severity=Severity.ERROR,
                message="securityContext.runAsUser: 0 explicitly runs the container as root",
                hint="Set runAsUser to a high non-zero UID (e.g., 10001) and runAsNonRoot: true.",
                authority="CIS Kubernetes Benchmark 5.2.6 – Minimize root containers",
                docs_url="https://www.cisecurity.org/benchmark/kubernetes",
            ))
        elif 1 <= uid < 10000:
            findings.append(Finding(
                file=str(path),
                line=node.start_mark.line + 1,
                col=node.start_mark.column,
                rule_id="PROOFCTL-YAML-024",
                rule_name="Container runAsUser is root or low UID",
                severity=Severity.WARNING,
                message=(
                    f"securityContext.runAsUser: {uid} is a low UID"
                    " — likely to collide with a host user account"
                ),
                hint="Use a high UID (>=10000) to avoid collisions with host users.",
                authority="CIS Kubernetes Benchmark 5.2.6 – Minimize root containers",
                docs_url="https://www.cisecurity.org/benchmark/kubernetes",
            ))
    return findings


def _yaml025_rbac_wildcard_admin(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-025 — RBAC wildcard apiGroups or cluster-admin binding to subject.

    YAML-016 already handles wildcard verbs/resources at ERROR severity. YAML-025
    extends coverage to:
      • wildcard `apiGroups` (uncovered by YAML-016)
      • ClusterRoleBinding to `cluster-admin` referencing a User/Group/ServiceAccount
        subject (YAML-015 already flags the binding existence; YAML-025 emphasises
        the subject grant).
    """
    findings: list[Finding] = []
    kind_node = _get_key(root, "kind")
    kind = _scalar(kind_node) or ""
    meta = _get_key(root, "metadata")
    name = "unnamed"
    if isinstance(meta, yaml.MappingNode):
        n = _get_key(meta, "name")
        name = _scalar(n) or "unnamed"

    if kind in ("Role", "ClusterRole"):
        rules_node = _get_key(root, "rules")
        if isinstance(rules_node, yaml.SequenceNode):
            for rule in rules_node.value:
                if not isinstance(rule, yaml.MappingNode):
                    continue
                groups_node = _get_key(rule, "apiGroups")
                if isinstance(groups_node, yaml.SequenceNode):
                    for item in groups_node.value:
                        if _scalar(item) == "*":
                            findings.append(Finding(
                                file=str(path),
                                line=item.start_mark.line + 1,
                                col=item.start_mark.column,
                                rule_id="PROOFCTL-YAML-025",
                                rule_name="RBAC wildcard or cluster-admin grant",
                                severity=Severity.ERROR,
                                message=(
                                    f"RBAC rule in '{kind}/{name}' uses wildcard '*' for apiGroups"
                                    " — grants access to every API group"
                                ),
                                hint="List the specific apiGroups required (e.g., [\"\", \"apps\"]).",
                                authority="CIS Kubernetes Benchmark 5.1.1/5.1.2 – Minimize wildcard use in Roles and ClusterRoles",
                                docs_url="https://www.cisecurity.org/benchmark/kubernetes",
                            ))
        return findings

    if kind in ("ClusterRoleBinding", "RoleBinding"):
        role_ref = _get_key(root, "roleRef")
        if not isinstance(role_ref, yaml.MappingNode):
            return findings
        ref_name_node = _get_key(role_ref, "name")
        if _scalar(ref_name_node) != "cluster-admin":
            return findings
        subjects = _get_key(root, "subjects")
        if not isinstance(subjects, yaml.SequenceNode):
            return findings
        for subj in subjects.value:
            if not isinstance(subj, yaml.MappingNode):
                continue
            kind_s = _scalar(_get_key(subj, "kind")) or ""
            if kind_s in ("ServiceAccount", "User", "Group"):
                subj_name = _scalar(_get_key(subj, "name")) or "unnamed"
                findings.append(Finding(
                    file=str(path),
                    line=subj.start_mark.line + 1,
                    col=subj.start_mark.column,
                    rule_id="PROOFCTL-YAML-025",
                    rule_name="RBAC wildcard or cluster-admin grant",
                    severity=Severity.ERROR,
                    message=(
                        f"{kind} '{name}' grants cluster-admin to {kind_s} '{subj_name}'"
                        " — unrestricted superuser access"
                    ),
                    hint="Bind to a least-privilege Role instead of cluster-admin.",
                    authority="CIS Kubernetes Benchmark 5.1.1 – Ensure that the cluster-admin role is only used where required",
                    docs_url="https://www.cisecurity.org/benchmark/kubernetes",
                ))
    return findings


def _yaml026_net_raw(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-026 — Container drops capabilities but not NET_RAW (and not ALL).

    YAML-012 fires when `drop` does not contain ALL. YAML-026 specifically targets
    the case where `drop` is present, does not contain ALL, and also does not
    contain NET_RAW — i.e. partial hardening that still leaves raw-socket access.
    """
    findings: list[Finding] = []
    for container in _iter_containers(root):
        name_node = _get_key(container, "name")
        name = _scalar(name_node) or "unnamed"
        sc = _get_key(container, "securityContext")
        if not isinstance(sc, yaml.MappingNode):
            continue
        caps = _get_key(sc, "capabilities")
        if not isinstance(caps, yaml.MappingNode):
            continue
        drop_node = _get_key(caps, "drop")
        if not isinstance(drop_node, yaml.SequenceNode) or not drop_node.value:
            continue
        dropped = {(_scalar(item) or "").upper() for item in drop_node.value}
        if "ALL" in dropped or "NET_RAW" in dropped:
            continue
        findings.append(Finding(
            file=str(path),
            line=drop_node.start_mark.line + 1,
            col=drop_node.start_mark.column,
            rule_id="PROOFCTL-YAML-026",
            rule_name="NET_RAW capability not dropped",
            severity=Severity.WARNING,
            message=(
                f"Container '{name}' drops capabilities but neither ALL nor NET_RAW"
                " — raw-socket access enables ARP spoofing and packet crafting"
            ),
            hint="Add NET_RAW to drop, or drop: [ALL] and add back only what's needed.",
            authority="CIS Kubernetes Benchmark 5.2.7 – Minimize NET_RAW capability",
            docs_url="https://www.cisecurity.org/benchmark/kubernetes",
        ))
    return findings


# ── AI-slop detection constants ──────────────────────────────────────────────

# Removed K8s API group+versions that LLMs still emit from stale training data.
# Format: (deprecated_apiVersion, affected_kinds, removed_k8s_version, replacement)
_K8S_REMOVED_APIS: list[tuple[str, frozenset[str], str, str]] = [
    ("extensions/v1beta1",        frozenset({"Deployment", "ReplicaSet", "DaemonSet"}),           "1.16", "apps/v1"),
    ("extensions/v1beta1",        frozenset({"Ingress"}),                                          "1.22", "networking.k8s.io/v1"),
    ("apps/v1beta1",              frozenset({"Deployment", "StatefulSet"}),                        "1.16", "apps/v1"),
    ("apps/v1beta2",              frozenset({"Deployment", "ReplicaSet", "DaemonSet", "StatefulSet"}), "1.16", "apps/v1"),
    ("networking.k8s.io/v1beta1", frozenset({"Ingress", "IngressClass"}),                         "1.22", "networking.k8s.io/v1"),
    ("batch/v1beta1",             frozenset({"CronJob"}),                                          "1.25", "batch/v1"),
    ("policy/v1beta1",            frozenset({"PodDisruptionBudget", "PodSecurityPolicy"}),         "1.25", "policy/v1 (PDB) or Pod Security Admission (PSP)"),
    ("autoscaling/v2beta1",       frozenset({"HorizontalPodAutoscaler"}),                         "1.25", "autoscaling/v2"),
    ("autoscaling/v2beta2",       frozenset({"HorizontalPodAutoscaler"}),                         "1.26", "autoscaling/v2"),
]

# Deprecated GHA workflow commands that runners silently ignore (disabled 2020/2023).
_GHA_DEPRECATED_CMDS: dict[str, tuple[str, str]] = {
    "::set-output":  ("disabled 2023", "$GITHUB_OUTPUT   (echo 'KEY=VALUE' >> $GITHUB_OUTPUT)"),
    "::set-env":     ("disabled 2020", "$GITHUB_ENV      (echo 'KEY=VALUE' >> $GITHUB_ENV)"),
    "::add-path":    ("disabled 2020", "$GITHUB_PATH     (echo '/new/path' >> $GITHUB_PATH)"),
    "::save-state":  ("disabled 2023", "$GITHUB_STATE    (echo 'KEY=VALUE' >> $GITHUB_STATE)"),
}

# Old major versions of first-party GitHub Actions that AI still generates from stale data.
_OLD_ACTION_VERSION_RE = re.compile(
    r"(actions/(?:checkout|upload-artifact|download-artifact|cache|"
    r"setup-python|setup-node|setup-java|setup-go|setup-dotnet|"
    r"github-script|create-release|upload-release-asset))@(v[123])\b"
)


# ── GitHub Actions rules ──────────────────────────────────────────────────────

# User-controlled GitHub context expressions that enable script injection
_GHA_INJECT_PATTERNS = [
    "${{ github.event.issue.",
    "${{ github.event.comment.",
    "${{ github.event.pull_request.body",
    "${{ github.event.pull_request.title",
    "${{ github.head_ref",
    "${{ github.event.inputs.",
]


def _yaml_gha001(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-GHA-001 — Script injection via user-controlled GitHub context."""
    findings: list[Finding] = []
    jobs_node = _get_key(root, "jobs")
    if not isinstance(jobs_node, yaml.MappingNode):
        return findings
    for job_key, job_val in jobs_node.value:
        job_name = _scalar(job_key) or "unknown"
        if not isinstance(job_val, yaml.MappingNode):
            continue
        steps_node = _get_key(job_val, "steps")
        if not isinstance(steps_node, yaml.SequenceNode):
            continue
        for step in steps_node.value:
            if not isinstance(step, yaml.MappingNode):
                continue
            run_node = _get_key(step, "run")
            if run_node is None:
                continue
            run_val = _scalar(run_node) or ""
            for pattern in _GHA_INJECT_PATTERNS:
                if pattern in run_val:
                    findings.append(Finding(
                        file=str(path),
                        line=run_node.start_mark.line + 1,
                        col=run_node.start_mark.column,
                        rule_id="PROOFCTL-YAML-GHA-001",
                        rule_name="Script injection via GitHub context",
                        severity=Severity.ERROR,
                        message=(
                            f"run: step in job '{job_name}' interpolates user-controlled"
                            f" GitHub context '{pattern.strip()}' — script injection risk"
                        ),
                        hint=(
                            "Write the value to an env var first: "
                            "env: TITLE: ${{ github.event.issue.title }} then use $TITLE in run:"
                        ),
                        authority="GitHub Security Hardening – Script injection / OWASP CICD-SEC-4",
                        docs_url="https://docs.github.com/en/actions/security-guides/security-hardening-for-github-actions#understanding-the-risk-of-script-injections",
                    ))
                    break  # one finding per step
    return findings


def _yaml_gha002(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-GHA-002 — pull_request_target + unsafe checkout."""
    _PR_HEAD_PATTERNS = ("github.event.pull_request.head", "github.head_ref")

    # Check for pull_request_target trigger
    on_node = _get_key(root, "on")
    has_prt = False
    if on_node is not None:
        if _scalar(on_node) == "pull_request_target":
            has_prt = True
        elif isinstance(on_node, yaml.MappingNode):
            if _get_key(on_node, "pull_request_target") is not None:
                has_prt = True
        elif isinstance(on_node, yaml.SequenceNode):
            for item in on_node.value:
                if _scalar(item) == "pull_request_target":
                    has_prt = True
                    break
    if not has_prt:
        return []

    findings: list[Finding] = []
    jobs_node = _get_key(root, "jobs")
    if not isinstance(jobs_node, yaml.MappingNode):
        return findings
    for _, job_val in jobs_node.value:
        if not isinstance(job_val, yaml.MappingNode):
            continue
        steps_node = _get_key(job_val, "steps")
        if not isinstance(steps_node, yaml.SequenceNode):
            continue
        for step in steps_node.value:
            if not isinstance(step, yaml.MappingNode):
                continue
            uses_node = _get_key(step, "uses")
            uses_val = _scalar(uses_node) or ""
            if "actions/checkout" not in uses_val:
                continue
            with_node = _get_key(step, "with")
            if not isinstance(with_node, yaml.MappingNode):
                continue
            ref_node = _get_key(with_node, "ref")
            ref_val = _scalar(ref_node) or ""
            for pattern in _PR_HEAD_PATTERNS:
                if pattern in ref_val:
                    findings.append(Finding(
                        file=str(path),
                        line=ref_node.start_mark.line + 1,
                        col=ref_node.start_mark.column,
                        rule_id="PROOFCTL-YAML-GHA-002",
                        rule_name="pull_request_target unsafe checkout",
                        severity=Severity.ERROR,
                        message=(
                            "Workflow uses pull_request_target with a checkout of the PR branch"
                            " — untrusted code runs with secret access"
                        ),
                        hint=(
                            "Never check out PR head code in pull_request_target workflows."
                            " Use pull_request trigger instead."
                        ),
                        authority="GitHub Security Hardening – pull_request_target / OWASP CICD-SEC-4",
                        docs_url="https://docs.github.com/en/actions/security-guides/security-hardening-for-github-actions#understanding-the-risk-of-script-injections",
                    ))
                    break
    return findings


def _yaml_gha003(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-GHA-003 — Missing or write-all workflow permissions."""
    findings: list[Finding] = []
    perms_node = _get_key(root, "permissions")
    if perms_node is None:
        findings.append(Finding(
            file=str(path),
            line=root.start_mark.line + 1,
            col=root.start_mark.column,
            rule_id="PROOFCTL-YAML-GHA-003",
            rule_name="Missing workflow permissions",
            severity=Severity.WARNING,
            message="No top-level permissions block — GITHUB_TOKEN defaults to broad write access",
            hint="Declare minimal permissions: permissions: contents: read",
            authority="GitHub Security Hardening – Minimum token permissions",
            docs_url="https://docs.github.com/en/actions/security-guides/security-hardening-for-github-actions#considering-cross-repository-access",
        ))
    elif _scalar(perms_node) == "write-all":
        findings.append(Finding(
            file=str(path),
            line=perms_node.start_mark.line + 1,
            col=perms_node.start_mark.column,
            rule_id="PROOFCTL-YAML-GHA-003",
            rule_name="Overly broad workflow permissions",
            severity=Severity.WARNING,
            message="permissions: write-all grants GITHUB_TOKEN write access to all scopes",
            hint="Declare minimal permissions: permissions: contents: read",
            authority="GitHub Security Hardening – Minimum token permissions",
            docs_url="https://docs.github.com/en/actions/security-guides/security-hardening-for-github-actions#considering-cross-repository-access",
        ))
    return findings


def _yaml_gha004(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-GHA-004 — ${{ secrets.* }} in workflow or job-level env."""
    findings: list[Finding] = []

    def _check_env_mapping(env_node: yaml.Node, context: str) -> None:
        if not isinstance(env_node, yaml.MappingNode):
            return
        for k, v in env_node.value:
            env_name = _scalar(k) or ""
            env_val = _scalar(v) or ""
            if "${{ secrets." in env_val:
                findings.append(Finding(
                    file=str(path),
                    line=v.start_mark.line + 1,
                    col=v.start_mark.column,
                    rule_id="PROOFCTL-YAML-GHA-004",
                    rule_name="Secret in job-level env",
                    severity=Severity.WARNING,
                    message=(
                        f"Secret '{env_name}' exposed in {context} env"
                        " — visible to all steps including third-party actions"
                    ),
                    hint="Move secret references to the specific step env: that needs them.",
                    authority="GitHub Security Hardening – Using secrets / Least privilege",
                    docs_url="https://docs.github.com/en/actions/security-guides/security-hardening-for-github-actions#using-secrets",
                ))

    # Workflow-level env
    workflow_env = _get_key(root, "env")
    _check_env_mapping(workflow_env, "workflow-level")

    # Job-level env
    jobs_node = _get_key(root, "jobs")
    if isinstance(jobs_node, yaml.MappingNode):
        for _, job_val in jobs_node.value:
            if not isinstance(job_val, yaml.MappingNode):
                continue
            job_env = _get_key(job_val, "env")
            _check_env_mapping(job_env, "job-level")

    return findings


def _yaml_gha005(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-GHA-005 — ACTIONS_ALLOW_UNSECURE_COMMANDS: true."""
    findings: list[Finding] = []
    for node in _find_all(root, "ACTIONS_ALLOW_UNSECURE_COMMANDS"):
        val = _scalar(node)
        if val in ("true", "True"):
            findings.append(Finding(
                file=str(path),
                line=node.start_mark.line + 1,
                col=node.start_mark.column,
                rule_id="PROOFCTL-YAML-GHA-005",
                rule_name="Unsafe workflow commands enabled",
                severity=Severity.ERROR,
                message=(
                    "ACTIONS_ALLOW_UNSECURE_COMMANDS: true re-enables deprecated workflow commands"
                    " (set-env, add-path) — allows any step to inject environment variables"
                ),
                hint="Remove this setting. It was deprecated in 2020 due to security vulnerabilities.",
                authority="GitHub Advisory – GHSA-ph5p-4qmq-pq62",
                docs_url="https://github.com/advisories/GHSA-ph5p-4qmq-pq62",
            ))
    return findings


def _yaml_gha006(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-GHA-006 — Missing timeout-minutes on jobs."""
    findings: list[Finding] = []
    jobs_node = _get_key(root, "jobs")
    if not isinstance(jobs_node, yaml.MappingNode):
        return findings
    for job_key, job_val in jobs_node.value:
        job_name = _scalar(job_key) or "unknown"
        if not isinstance(job_val, yaml.MappingNode):
            continue
        timeout_node = _get_key(job_val, "timeout-minutes")
        if timeout_node is None:
            findings.append(Finding(
                file=str(path),
                line=job_val.start_mark.line + 1,
                col=job_val.start_mark.column,
                rule_id="PROOFCTL-YAML-GHA-006",
                rule_name="Missing job timeout",
                severity=Severity.INFO,
                message=(
                    f"Job '{job_name}' has no timeout-minutes"
                    " — a hanging step will consume runner minutes for up to 6 hours"
                ),
                hint="Add timeout-minutes: 30 (or appropriate value) to each job.",
                authority="GitHub Actions Best Practices – Workflow timeout",
                docs_url="https://docs.github.com/en/actions/writing-workflows/workflow-syntax-for-github-actions#jobsjob_idtimeout-minutes",
            ))
    return findings


# ── AI-slop rule implementations ─────────────────────────────────────────────

def _yaml_ai001_k8s_removed_api(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-AI-001 — Removed Kubernetes API version (LLM training data lag)."""
    api_node = _get_key(root, "apiVersion")
    kind_node = _get_key(root, "kind")
    api_version = _scalar(api_node) or ""
    kind = _scalar(kind_node) or ""
    if not api_version or not kind:
        return []
    for removed_api, affected_kinds, removed_ver, replacement in _K8S_REMOVED_APIS:
        if api_version == removed_api and kind in affected_kinds:
            return [Finding(
                file=str(path),
                line=api_node.start_mark.line + 1,
                col=api_node.start_mark.column,
                rule_id="PROOFCTL-YAML-AI-001",
                rule_name="Removed K8s apiVersion",
                severity=Severity.ERROR,
                message=(
                    f"'{kind}' uses apiVersion '{api_version}' which was removed in K8s {removed_ver}"
                    f" — this manifest will be rejected by any cluster ≥{removed_ver}"
                ),
                hint=f"Replace with apiVersion: {replacement}",
                authority="Kubernetes API Deprecation Guide",
                docs_url="https://kubernetes.io/docs/reference/using-api/deprecation-guide/",
            )]
    return []


def _yaml_ai002_pod_security_policy(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-AI-002 — PodSecurityPolicy kind (removed K8s 1.25)."""
    kind_node = _get_key(root, "kind")
    if _scalar(kind_node) != "PodSecurityPolicy":
        return []
    return [Finding(
        file=str(path),
        line=kind_node.start_mark.line + 1,
        col=kind_node.start_mark.column,
        rule_id="PROOFCTL-YAML-AI-002",
        rule_name="PodSecurityPolicy removed",
        severity=Severity.ERROR,
        message=(
            "PodSecurityPolicy was removed in Kubernetes 1.25"
            " — this manifest will fail on any cluster ≥1.25"
        ),
        hint="Migrate to Pod Security Admission (PSA) labels on namespaces, or use Kyverno/OPA policies.",
        authority="Kubernetes Deprecation Guide – PodSecurityPolicy v1.25",
        docs_url="https://kubernetes.io/docs/reference/using-api/deprecation-guide/#psp-v125",
    )]


def _yaml_ai003_run_as_user_root(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-AI-003 — securityContext.runAsUser: 0 (explicit root)."""
    findings: list[Finding] = []
    for node in _find_all(root, "runAsUser"):
        if _scalar(node) == "0":
            findings.append(Finding(
                file=str(path),
                line=node.start_mark.line + 1,
                col=node.start_mark.column,
                rule_id="PROOFCTL-YAML-AI-003",
                rule_name="Explicit root UID in container",
                severity=Severity.ERROR,
                message="securityContext.runAsUser: 0 explicitly runs the container as root (UID 0)",
                hint="Use a non-zero UID (e.g., 1000) and set runAsNonRoot: true.",
                authority="CIS Kubernetes Benchmark 5.2.6 – Do not admit root containers",
                docs_url="https://www.cisecurity.org/benchmark/kubernetes",
            ))
    return findings


def _yaml_ai004_gha_deprecated_commands(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-AI-004 — Deprecated GitHub Actions workflow commands in run: steps."""
    findings: list[Finding] = []
    jobs_node = _get_key(root, "jobs")
    if not isinstance(jobs_node, yaml.MappingNode):
        return findings
    for _, job_val in jobs_node.value:
        if not isinstance(job_val, yaml.MappingNode):
            continue
        steps_node = _get_key(job_val, "steps")
        if not isinstance(steps_node, yaml.SequenceNode):
            continue
        for step in steps_node.value:
            if not isinstance(step, yaml.MappingNode):
                continue
            run_node = _get_key(step, "run")
            if run_node is None:
                continue
            run_val = _scalar(run_node) or ""
            for cmd, (when_disabled, replacement) in _GHA_DEPRECATED_CMDS.items():
                if cmd in run_val:
                    # Approximate line: run: node line + offset within block scalar
                    offset = run_val.find(cmd)
                    cmd_line = run_node.start_mark.line + 1 + run_val[:offset].count("\n")
                    findings.append(Finding(
                        file=str(path),
                        line=cmd_line,
                        col=run_node.start_mark.column,
                        rule_id="PROOFCTL-YAML-AI-004",
                        rule_name="Deprecated GHA workflow command",
                        severity=Severity.ERROR,
                        message=(
                            f"'echo \"{cmd}\"' is a deprecated workflow command ({when_disabled})"
                            " — silently no-ops on current runners"
                        ),
                        hint=f"Use the env-file approach: {replacement}",
                        authority="GitHub Actions – Deprecated workflow commands (GHSA-ph5p-4qmq-pq62)",
                        docs_url="https://docs.github.com/en/actions/writing-workflows/choosing-what-your-workflow-does/workflow-commands-for-github-actions#setting-an-output-parameter",
                    ))
                    break  # one finding per step per deprecated command type is enough
    return findings


def _yaml_ai005_old_action_versions(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-AI-005 — Outdated first-party GitHub Action version (v1/v2/v3)."""
    findings: list[Finding] = []
    for node in _find_all(root, "uses"):
        val = _scalar(node)
        if val is None:
            continue
        m = _OLD_ACTION_VERSION_RE.search(val)
        if m:
            action, old_ver = m.group(1), m.group(2)
            findings.append(Finding(
                file=str(path),
                line=node.start_mark.line + 1,
                col=node.start_mark.column,
                rule_id="PROOFCTL-YAML-AI-005",
                rule_name="Outdated GitHub Action version",
                severity=Severity.WARNING,
                message=(
                    f"uses: '{val}' references {old_ver} — likely AI-generated from stale training data"
                    f"; v4+ is available"
                ),
                hint=f"Upgrade to {action}@v4 and pin to the full commit SHA.",
                authority="GitHub Actions – Using versioned actions",
                docs_url="https://docs.github.com/en/actions/writing-workflows/choosing-what-your-workflow-does/using-pre-written-building-blocks-in-your-workflow#using-versioned-actions",
            ))
    return findings


def _yaml_ai006_ingress_class_annotation(root: yaml.MappingNode, path: Path) -> list[Finding]:
    """PROOFCTL-YAML-AI-006 — Deprecated kubernetes.io/ingress.class annotation."""
    kind_node = _get_key(root, "kind")
    if _scalar(kind_node) != "Ingress":
        return []
    meta = _get_key(root, "metadata")
    if not isinstance(meta, yaml.MappingNode):
        return []
    annotations_node = _get_key(meta, "annotations")
    if not isinstance(annotations_node, yaml.MappingNode):
        return []
    for k, v in annotations_node.value:
        if _scalar(k) == "kubernetes.io/ingress.class":
            return [Finding(
                file=str(path),
                line=k.start_mark.line + 1,
                col=k.start_mark.column,
                rule_id="PROOFCTL-YAML-AI-006",
                rule_name="Deprecated ingress.class annotation",
                severity=Severity.WARNING,
                message=(
                    "kubernetes.io/ingress.class annotation is deprecated since K8s 1.18"
                    " — frequently emitted by LLMs from stale training examples"
                ),
                hint="Use spec.ingressClassName instead: spec: ingressClassName: nginx",
                authority="Kubernetes Deprecation Guide – Ingress (1.18)",
                docs_url="https://kubernetes.io/docs/reference/using-api/deprecation-guide/#ingress-v122",
            )]
    return []


# ── main checker ──────────────────────────────────────────────────────────────

class _YamlCheckerImpl(YamlFileChecker):
    def check(self, path: Path, source: str) -> list[Finding]:
        findings: list[Finding] = []

        # ── duplicate key detection (multi-doc aware) ─────────────────────────
        # Use a fresh loader per document so _dup_findings does not leak
        # from doc N into doc N+1 in a `---` separated stream.
        all_dup_findings: list[tuple[str, int]] = []
        try:
            loader = _DupKeyLoader(source)
            loader._dup_findings = []  # type: ignore[attr-defined]
            try:
                while loader.check_data():
                    loader.get_data()
                    all_dup_findings.extend(loader._dup_findings)  # type: ignore[attr-defined]
                    # Reset between documents — findings already harvested.
                    loader._dup_findings = []  # type: ignore[attr-defined]
            finally:
                loader.dispose()
        except yaml.YAMLError:
            pass
        findings.extend(_yaml002_findings(all_dup_findings, path))

        # ── node-based checks (multi-doc aware) ───────────────────────────────
        try:
            roots = list(yaml.compose_all(source, Loader=yaml.SafeLoader))
        except yaml.YAMLError:
            return findings  # unparseable — dup findings are still valid

        for root in roots:
            if root is None:
                continue

            findings.extend(_yaml001(root, path))

            if _is_k8s(root):
                assert isinstance(root, yaml.MappingNode)
                findings.extend(_yaml003_k8s(root, path))
                findings.extend(_yaml004_k8s(root, path))
                findings.extend(_yaml005_k8s(root, path))
                findings.extend(_yaml019_k8s(root, path))
                findings.extend(_yaml006_image_latest(root, path, "PROOFCTL-YAML-006"))
                findings.extend(_yaml009_k8s(root, path))
                findings.extend(_yaml010_k8s(root, path))
                findings.extend(_yaml011_k8s(root, path))
                findings.extend(_yaml012_k8s(root, path))
                findings.extend(_yaml013_k8s(root, path))
                findings.extend(_yaml014_k8s(root, path))
                findings.extend(_yaml015_k8s(root, path))
                findings.extend(_yaml016_017_k8s(root, path))
                findings.extend(_yaml018_k8s(root, path))
                findings.extend(_yaml020_k8s(root, path))
                findings.extend(_yaml021_k8s(root, path))
                findings.extend(_yaml022_default_namespace(root, path))
                findings.extend(_yaml023_image_digest(root, path))
                findings.extend(_yaml024_runasuser_low(root, path))
                findings.extend(_yaml025_rbac_wildcard_admin(root, path))
                findings.extend(_yaml026_net_raw(root, path))
                # AI-slop: removed apiVersions, PSP, explicit root, deprecated annotations
                findings.extend(_yaml_ai001_k8s_removed_api(root, path))
                findings.extend(_yaml_ai002_pod_security_policy(root, path))
                findings.extend(_yaml_ai003_run_as_user_root(root, path))
                findings.extend(_yaml_ai006_ingress_class_annotation(root, path))

            elif _is_compose(root):
                findings.extend(_yaml006_image_latest(root, path, "PROOFCTL-YAML-006"))
                findings.extend(_yaml008_compose_privileged(root, path))

            if _is_gha(path) or _is_gha_content(root):
                findings.extend(_yaml007_gha(root, path))
                if isinstance(root, yaml.MappingNode):
                    findings.extend(_yaml_gha001(root, path))
                    findings.extend(_yaml_gha002(root, path))
                    findings.extend(_yaml_gha003(root, path))
                    findings.extend(_yaml_gha004(root, path))
                    findings.extend(_yaml_gha005(root, path))
                    findings.extend(_yaml_gha006(root, path))
                    # AI-slop: deprecated workflow commands, stale action versions
                    findings.extend(_yaml_ai004_gha_deprecated_commands(root, path))
                    findings.extend(_yaml_ai005_old_action_versions(root, path))

        return findings


YamlRulesChecker = _YamlCheckerImpl
