"""Terraform / HCL checker — rules PROOFCTL-TF-* and PROOFCTL-TF-G* / PROOFCTL-TF-A*.

Rule groups
-----------
T-xxx  General Terraform antipatterns (AI slop)
G-xxx  GCP-specific security misconfigurations
A-xxx  AWS-specific security misconfigurations
M-xxx  Terraform mechanics / silent failure patterns
V-xxx  Lifecycle antipatterns
"""
from __future__ import annotations

import re
from pathlib import Path

from ..models import Finding, Severity
from .base import HclFileChecker, HclDirChecker
from .hcl_utils import HclBlock, parse_blocks

# ── Shared constants ──────────────────────────────────────────────────────────

_PROD_RE = re.compile(r'prod(?:uction)?', re.IGNORECASE)

_TEST_FIXTURE_DIRS = frozenset({"test", "tests", "fixtures", "_archived", "kitchen-tests"})


def _is_test_fixture_path(path: Path) -> bool:
    """True if this Terraform file is in a test/fixture/archived directory.

    Hygiene rules (T009/T012/T014) skip these paths because:
      - test fixtures legitimately use deep relative `source` paths,
      - submodules and test scaffolds inherit required_version from a parent,
      - throwaway outputs in tests don't need descriptions.
    """
    return any(part in _TEST_FIXTURE_DIRS for part in path.parts)

_STATEFUL_RESOURCES = frozenset({
    # AWS
    "aws_db_instance", "aws_rds_cluster", "aws_rds_cluster_instance",
    "aws_s3_bucket", "aws_dynamodb_table", "aws_elasticsearch_domain",
    "aws_opensearch_domain", "aws_elasticache_cluster", "aws_elasticache_replication_group",
    # GCP
    "google_sql_database_instance", "google_storage_bucket",
    "google_container_cluster", "google_spanner_instance",
    "google_bigtable_instance", "google_filestore_instance",
    "google_kms_crypto_key",
})

_FIREWALL_RESOURCES = frozenset({
    "aws_security_group", "aws_security_group_rule",
    "aws_network_acl", "aws_network_acl_rule",
    "google_compute_firewall",
})


def _aws_sg_open_ingress_lines(raw_lines: list[str]) -> list[str]:
    """Return the lines from every ``ingress { ... }`` sub-block in an
    ``aws_security_group`` body that contains 0.0.0.0/0.

    ``aws_security_group`` declares ``ingress`` and ``egress`` as inline
    sub-blocks. Open egress is normal (workloads need outbound), so T-004
    must ignore the egress block entirely — including its ``protocol``
    and port attributes. This helper returns only the lines from
    qualifying ingress sub-blocks; the caller scopes port / all-traffic
    checks to those lines.
    """
    sub_re = re.compile(r"^\s*(ingress|egress)\s*\{")
    in_kind: str | None = None
    block_depth = 0
    buffer: list[str] = []
    result: list[str] = []
    bare_root_lines: list[str] = []

    for line in raw_lines:
        if in_kind is None:
            m = sub_re.match(line)
            if m:
                in_kind = m.group(1)
                block_depth = line.count("{") - line.count("}")
                buffer = [line]
                continue
            # Bare 0.0.0.0/0 at resource level (rare) — collect separately.
            if re.search(r'"0\.0\.0\.0/0"', line):
                bare_root_lines.append(line)
            continue

        block_depth += line.count("{") - line.count("}")
        buffer.append(line)
        if block_depth <= 0:
            if in_kind == "ingress" and any(
                re.search(r'"0\.0\.0\.0/0"', ln) for ln in buffer
            ):
                result.extend(buffer)
            in_kind = None
            block_depth = 0
            buffer = []

    return result + bare_root_lines


def _aws_sg_has_open_ingress(raw_lines: list[str]) -> bool:
    """True iff 0.0.0.0/0 appears in any ingress sub-block of an aws_security_group."""
    return bool(_aws_sg_open_ingress_lines(raw_lines))

# Ports that should never accept 0.0.0.0/0
_SENSITIVE_PORTS = frozenset({22, 23, 25, 3306, 3389, 5432, 5439, 6379, 27017})

_SECRET_ATTR_PAT = re.compile(
    r'^\s*(?:password|secret|private_key|api_key|access_key|secret_key|'
    r'auth_token|token|service_account_key|credentials|passphrase|'
    r'client_secret|encryption_key|private_key_pem|certificate_body)\s*=\s*'
    r'"([^"$\{][^"]{5,})"',   # ≥6 chars, not starting with ${ (not a reference)
    re.IGNORECASE,
)

_BROAD_GCP_ROLES = frozenset({
    "roles/owner",
    "roles/editor",
    "roles/iam.securityAdmin",
    "roles/resourcemanager.projectIamAdmin",
    "roles/iam.serviceAccountAdmin",
})

_GCP_IAM_RESOURCES = frozenset({
    "google_project_iam_binding",
    "google_project_iam_member",
    "google_folder_iam_binding",
    "google_folder_iam_member",
    "google_organization_iam_binding",
    "google_organization_iam_member",
})

_GIT_SHA_RE = re.compile(r'^[0-9a-f]{40}$')
_SEMVER_TAG_RE = re.compile(r'^v?\d+\.\d+')

# ── AI-slop detection patterns ────────────────────────────────────────────────

_AI_PLACEHOLDER_VALUE_RE = re.compile(
    r'"(?:your[-_]?(?:project|bucket|region|cluster|account|key|domain|org|value|name|secret|password|token|id)|'
    r'YOUR[-_][A-Z_]+|CHANGEME|CHANGE_ME|REPLACE_ME|REPLACE_THIS|INSERT_YOUR|'
    r'my-project|my-cluster|my-bucket|my-org|my-company|my-domain|'
    r'example-project|example-bucket|example-cluster|'
    r'<[A-Z][A-Z0-9_\-]+>|placeholder|todo)"',
    re.IGNORECASE,
)
_AI_ANGLE_BRACKET_RE = re.compile(r'"[^"]*<[A-Za-z][A-Za-z0-9_\-]+>[^"]*"')

# AWS region format: us-east-1 (with trailing -digit). GCP uses us-east1, us-central1.
_AWS_REGION_RE = re.compile(
    r'"(us-east-[12]|us-west-[12]|eu-west-[1-3]|ap-southeast-[12]|ap-northeast-[12]|'
    r'ca-central-1|sa-east-1|me-south-1|af-south-1|eu-north-1|eu-south-1)"'
)
_GCP_RESOURCE_RE = re.compile(r'\bgoogle_\w+\b')

# Deprecated AWS S3 inline patterns (removed in aws provider v4)
_S3_INLINE_ACL_RE = re.compile(r'^\s*acl\s*=', re.MULTILINE)
_S3_INLINE_VERSIONING_RE = re.compile(r'^\s*versioning\s*\{', re.MULTILINE)
_S3_INLINE_LIFECYCLE_RE = re.compile(r'^\s*lifecycle_rule\s*\{', re.MULTILINE)

# Other deprecated resources
_AWS_S3_OBJECT_DEPRECATED_RE = re.compile(r'\baws_s3_bucket_object\b')
_AWS_ALB_ALIAS_RE = re.compile(r'\baws_alb(?:_listener|_target_group|_target_group_attachment|_listener_rule)?\b')
_AZURERM_HTTPS_OLD_RE = re.compile(r'^\s*enable_https_traffic_only\s*=', re.MULTILINE)

# GCP-specific AI mistakes
_GCP_PROJECT_ID_WRONG_RE = re.compile(r'google_project\.[a-z_]+\.id\b')
_GCP_ML_ENGINE_RE = re.compile(r'\bgoogle_ml_engine_(?:model|version)\b')
_GCP_IAM_BINDING_RE = re.compile(r'\bgoogle_project_iam_binding\b')

# Terraform mechanics AI mistakes
_NULL_RESOURCE_LOCAL_EXEC_RE = re.compile(
    r'resource\s+"null_resource"[^}]*local-exec', re.DOTALL
)
_HEREDOC_IAM_RE = re.compile(
    r'(?:assume_role_policy|policy)\s*=\s*<<[-\w]*(?:EOF|POLICY|JSON|EOT|HEREDOC)',
    re.IGNORECASE,
)
_COUNT_LENGTH_RE = re.compile(r'^\s*count\s*=\s*length\s*\(', re.MULTILINE)
_TODO_COMMENT_RE = re.compile(r'^\s*#\s*(?:TODO|FIXME|HACK|PLACEHOLDER)\b', re.IGNORECASE | re.MULTILINE)

# ── Terraform file checker ────────────────────────────────────────────────────


class TerraformChecker(HclFileChecker):
    extensions = (".tf", ".tfvars")

    def __init__(self, required_labels: list[str] | None = None) -> None:
        self._required_labels = required_labels or []

    def check(self, path: Path, source: str) -> list[Finding]:
        if path.suffix == ".tfvars":
            return self._scan_secrets_only(path, source.splitlines())

        blocks = parse_blocks(source)
        lines = source.splitlines()
        out: list[Finding] = []

        # Group T — general Terraform
        out += self._t001(path, blocks)
        out += self._t002(path, lines)
        out += self._t003(path, blocks)
        out += self._t004(path, blocks, lines)
        out += self._t005(path, lines)
        out += self._t006(path, lines)
        out += self._t009(path, blocks)
        out += self._t012(path, blocks)
        if self._required_labels:
            out += self._t013(path, blocks)

        # Group M — mechanics
        out += self._m002(path, lines)
        out += self._m003(path, lines)
        out += self._m004(path, blocks)
        out += self._m005(path, blocks)
        out += self._m006(path, blocks)
        out += self._m007(path, blocks)

        # Group V — lifecycle
        out += self._v001(path, blocks)
        out += self._v003(path, blocks)
        out += self._v004(path, blocks)

        # Group G — GCP
        out += self._g001(path, blocks)
        out += self._g002(path, blocks)
        out += self._g003(path, blocks)
        out += self._g004(path, blocks)
        out += self._g005(path, blocks)
        out += self._g006(path, blocks)
        out += self._g007(path, blocks)
        out += self._g008(path, blocks)
        out += self._g009(path, blocks)
        out += self._g010(path, blocks)
        out += self._g011(path, blocks)
        out += self._g012(path, blocks)
        out += self._g013(path, blocks)
        out += self._g014(path, blocks)
        out += self._g015(path, blocks)
        out += self._g016(path, blocks)
        out += self._g017(path, blocks)
        out += self._g018(path, blocks)
        out += self._g019(path, blocks)
        out += self._g020(path, blocks)
        out += self._g021(path, blocks)
        out += self._g023(path, blocks)
        out += self._g024(path, blocks)
        out += self._g025(path, blocks)

        # Group A — AWS
        out += self._a001(path, blocks)
        out += self._a003(path, blocks)
        out += self._a004(path, blocks)
        out += self._a005(path, blocks)
        out += self._a006(path, blocks)
        out += self._a007(path, blocks)
        out += self._a008(path, blocks)
        out += self._a009(path, blocks)
        out += self._a010(path, blocks)
        # A-011 moved to TerraformDirChecker._a011_scan_level (fires once per scan).
        out += self._a012(path, blocks)
        out += self._a013(path, blocks)
        out += self._a014(path, blocks)
        out += self._a015(path, blocks)
        out += self._a016(path, blocks)
        out += self._a017(path, blocks)
        out += self._a018(path, blocks)
        out += self._a019(path, blocks)
        out += self._a020(path, blocks)
        out += self._a021(path, blocks)
        out += self._a022(path, blocks)
        out += self._a023(path, blocks)
        out += self._a024(path, blocks)
        out += self._a025(path, blocks)
        out += self._a027(path, blocks)
        out += self._a029(path, blocks)
        out += self._a030(path, blocks)
        out += self._a031(path, blocks)
        out += self._a034(path, blocks)
        out += self._a035(path, blocks)
        out += self._a036(path, blocks)
        out += self._a037(path, blocks)
        out += self._a038(path, blocks)
        out += self._a039(path, blocks)
        out += self._a040(path, blocks)

        # Group G — GCP (extended)
        out += self._g026(path, blocks)
        out += self._g027(path, blocks)
        out += self._g028(path, blocks)
        out += self._g029(path, blocks)
        out += self._g030(path, blocks)
        out += self._g031(path, blocks)
        out += self._g032(path, blocks)
        out += self._g033(path, blocks)
        out += self._g034(path, blocks)
        out += self._g035(path, blocks)
        out += self._g036(path, blocks)
        out += self._g037(path, blocks)
        out += self._g038(path, blocks)
        out += self._g040(path, blocks)
        out += self._g041(path, blocks)
        out += self._g042(path, blocks)
        out += self._g043(path, blocks)
        out += self._g044(path, blocks)
        out += self._g045(path, blocks)
        out += self._g046(path, blocks)
        out += self._g047(path, blocks)

        # Group AZ — Azure
        out += self._az001(path, blocks)
        out += self._az002(path, blocks)
        out += self._az003(path, blocks)
        out += self._az004(path, blocks)
        out += self._az005(path, blocks)
        out += self._az006(path, blocks)
        out += self._az007(path, blocks)
        out += self._az008(path, blocks)
        out += self._az009(path, blocks)
        out += self._az010(path, blocks)
        out += self._az011(path, blocks)
        out += self._az012(path, blocks)
        out += self._az013(path, blocks)
        out += self._az014(path, blocks)

        # Group T — General (extended)
        out += self._t014(path, blocks)
        out += self._t015(path, blocks)

        # Group AI — AI-slop detection
        out += self._ai001(path, lines)
        out += self._ai002(path, lines, blocks)
        out += self._ai003(path, lines, blocks)
        out += self._ai004(path, lines, blocks)
        out += self._ai005(path, lines)
        out += self._ai006(path, lines)
        out += self._ai007(path, lines)
        out += self._ai008(path, lines)
        out += self._ai009(path, lines)
        out += self._ai010(path, lines)
        out += self._ai011(path, lines)
        out += self._ai012(path, blocks)
        out += self._ai013(path, blocks)

        return out

    # ── helpers ───────────────────────────────────────────────────────────────

    def _f(
        self,
        path: Path,
        line: int | None,
        rule_id: str,
        rule_name: str,
        severity: Severity,
        message: str,
        hint: str = "",
        authority: str = "",
        docs_url: str = "",
    ) -> Finding:
        return Finding(
            file=str(path), line=line, col=None,
            rule_id=rule_id, rule_name=rule_name,
            severity=severity, message=message,
            hint=hint, authority=authority,
            docs_url=docs_url,
        )

    def _scan_secrets_only(self, path: Path, lines: list[str]) -> list[Finding]:
        return self._t005(path, lines)

    @staticmethod
    def _has_lifecycle_attr(block: HclBlock, attr: str) -> bool:
        """True if the block contains lifecycle { <attr> = true }.

        Strips inline comments before counting braces so a comment containing
        `}` (e.g. ``# closing the lifecycle block }``) doesn't prematurely end
        the lifecycle scope. The same rule applies for `{`.
        """
        from .hcl_utils import _strip_comment
        lc_re = re.compile(r'lifecycle\s*\{')
        attr_re = re.compile(rf'{re.escape(attr)}\s*=\s*true')
        in_lifecycle = False
        depth = 0
        for line in block.raw_lines:
            stripped = _strip_comment(line)
            if not in_lifecycle and lc_re.search(stripped):
                in_lifecycle = True
                depth = 1
                if attr_re.search(stripped):
                    return True
                continue
            if in_lifecycle:
                depth += stripped.count('{') - stripped.count('}')
                if attr_re.search(stripped):
                    return True
                if depth <= 0:
                    in_lifecycle = False
        return False

    # ════════════════════════════════════════════════════════════════════════
    # Group T — General Terraform
    # ════════════════════════════════════════════════════════════════════════

    def _t001(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """T-001 — Empty resource block."""
        out = []
        for b in blocks:
            if b.kind != "resource":
                continue
            inner = b.raw_lines[1:-1] if len(b.raw_lines) > 2 else []
            content = [line for line in inner if line.strip() and not line.strip().startswith("#")]
            if not content:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-T001", "Empty resource block",
                    Severity.ERROR,
                    f'resource "{b.label1}" "{b.label2}" has no attributes',
                    hint="Configure the resource — an empty block silently creates it with provider defaults.",
                ))
        return out

    def _t002(self, path: Path, lines: list[str]) -> list[Finding]:
        """T-002 — Useless string interpolation: "${var.x}" → var.x (simple refs only)."""
        # Only flag pure attribute/variable paths — not expressions with operators/function calls.
        # Pattern: "= "${word.word[optional_index]…}"" with no operators inside.
        pat = re.compile(r'=\s*"\$\{([\w]+(?:\.[\w]+)+(?:\[[\w."]+\])?)\}"')
        out = []
        for i, line in enumerate(lines, start=1):
            if line.strip().startswith("#"):
                continue
            m = pat.search(line)
            if m:
                expr = m.group(1)
                out.append(self._f(
                    path, i,
                    "PROOFCTL-TF-T002", "Unnecessary string interpolation",
                    Severity.WARNING,
                    f'Wrap unnecessary: "${{{expr}}}" → {expr}',
                    hint=f'Use direct reference: = {expr} instead of = "${{{expr}}}".',
                ))
        return out

    def _t003(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """T-003 — required_providers block missing version constraints."""
        if _is_test_fixture_path(path):
            return []
        out = []
        for b in blocks:
            if b.kind != "terraform":
                continue
            rp_re = re.compile(r'required_providers\s*\{')
            in_rp = False
            depth = 0
            rp_start = None
            rp_lines: list[str] = []
            for i, line in enumerate(b.raw_lines):
                if not in_rp and rp_re.search(line):
                    in_rp = True
                    depth = 1
                    rp_start = b.start_line + i
                    rp_lines = [line]
                    continue
                if in_rp:
                    rp_lines.append(line)
                    depth += line.count('{') - line.count('}')
                    if depth <= 0:
                        break
            if not rp_lines:
                continue
            # Check each provider object within required_providers
            prov_obj_re = re.compile(r'^\s*\w+\s*=\s*\{')
            version_re = re.compile(r'version\s*=')
            # Walk rp_lines and find provider blocks, check each for version
            j = 0
            while j < len(rp_lines):
                if prov_obj_re.match(rp_lines[j]):
                    # find end of this provider object
                    pdepth = 1
                    pname = rp_lines[j].split('=')[0].strip()
                    has_ver = False
                    k = j + 1
                    while k < len(rp_lines) and pdepth > 0:
                        pdepth += rp_lines[k].count('{') - rp_lines[k].count('}')
                        if version_re.search(rp_lines[k]):
                            has_ver = True
                        k += 1
                    if not has_ver:
                        out.append(self._f(
                            path, rp_start + j if rp_start else b.start_line,
                            "PROOFCTL-TF-T003", "Missing provider version constraint",
                            Severity.ERROR,
                            f'Provider "{pname}" in required_providers has no version pin',
                            hint='Add version = "~> 5.0" to prevent silent provider upgrades.',
                        ))
                    j = k
                else:
                    j += 1
        return out

    def _t004(self, path: Path, blocks: list[HclBlock], lines: list[str]) -> list[Finding]:
        """T-004 — Open ingress on sensitive ports (0.0.0.0/0).

        Egress rules (outbound from your VPC to the internet) are NOT a
        security finding here — most workloads need outbound 0.0.0.0/0.
        Only flag ingress.
        """
        out = []
        port_re = re.compile(r'(?:from_port|to_port|port)\s*=\s*(\d+)')
        all_traffic_re = re.compile(r'(?:protocol|ip_protocol)\s*=\s*"-1"|all\s*=\s*true')

        for b in blocks:
            if b.kind != "resource" or b.label1 not in _FIREWALL_RESOURCES:
                continue
            if not b.contains(r'0\.0\.0\.0/0'):
                continue

            # Decide which lines define the open ingress for port/protocol
            # checks. For aws_security_group (which has inline ingress AND
            # egress sub-blocks) we MUST scope to the ingress sub-block — the
            # egress block's `protocol = "-1"` would otherwise spoof an
            # all-traffic verdict.
            scoped_lines: list[str]

            if b.label1 == "aws_security_group_rule":
                rule_type = (b.attr_value("type") or "").strip().strip('"').lower()
                if rule_type == "egress":
                    continue
                scoped_lines = list(b.raw_lines)
            elif b.label1 == "google_compute_firewall":
                direction = (b.attr_value("direction") or "").strip().strip('"').upper()
                if direction == "EGRESS":
                    continue
                scoped_lines = list(b.raw_lines)
            elif b.label1 == "aws_security_group":
                scoped_lines = _aws_sg_open_ingress_lines(b.raw_lines)
                if not scoped_lines:
                    continue
            else:
                scoped_lines = list(b.raw_lines)

            # Check if sensitive ports are involved (scoped to ingress only
            # for aws_security_group).
            ports: set[int] = set()
            for line in scoped_lines:
                pm = port_re.search(line)
                if pm:
                    try:
                        ports.add(int(pm.group(1)))
                    except ValueError:
                        pass

            if all_traffic_re.search('\n'.join(scoped_lines)):
                # -1 or all traffic — always sensitive
                flagged_ports = "all traffic"
            elif ports & _SENSITIVE_PORTS:
                flagged_ports = ', '.join(str(p) for p in sorted(ports & _SENSITIVE_PORTS))
            else:
                continue

            cidr_line = b.any_line_matches(r'0\.0\.0\.0/0')
            out.append(self._f(
                path, cidr_line or b.start_line,
                "PROOFCTL-TF-T004", "Open ingress to the world",
                Severity.ERROR,
                f'resource "{b.label1}" "{b.label2}" allows 0.0.0.0/0 on {flagged_ports}',
                hint="Restrict to known CIDR ranges. Never allow all ingress from the internet.",
                authority="CIS Benchmark / NIST SP 800-190",
                docs_url="https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-190.pdf",
            ))
        return out

    def _t005(self, path: Path, lines: list[str]) -> list[Finding]:
        """T-005 — Hardcoded secret literal in attribute value."""
        out = []
        for i, line in enumerate(lines, start=1):
            if line.strip().startswith("#"):
                continue
            m = _SECRET_ATTR_PAT.match(line)
            if m:
                attr = line.strip().split('=')[0].strip()
                out.append(self._f(
                    path, i,
                    "PROOFCTL-TF-T005", "Hardcoded secret value",
                    Severity.ERROR,
                    f'"{attr}" appears to contain a literal secret value',
                    hint="Use var.* references or a secrets manager. Never commit credentials.",
                    authority="OWASP A02:2021 Cryptographic Failures",
                    docs_url="https://owasp.org/Top10/A02_2021-Cryptographic_Failures/",
                ))
        return out

    def _t006(self, path: Path, lines: list[str]) -> list[Finding]:
        """T-006 — IAM wildcard in actions or resources.

        Matches both shapes:

        1. Terraform-native (``data "aws_iam_policy_document"``):
           ``actions = ["*"]`` / ``resources = ["*"]``
        2. AWS JSON policy embedded via ``jsonencode({ Statement = [...] })``:
           ``Action = "*"`` / ``Resource = "*"`` (bare string) and
           ``Action = ["*"]`` / ``Resource = ["foo", "*"]`` (list form).

        The capitalised keys + bare-string value were previously uncovered.
        """
        # Terraform-native form (lowercase, list-only).
        tf_pat = re.compile(
            r'(?:actions|not_actions|resources|not_resources)\s*=\s*\[[^\]]*"\*"'
        )
        # AWS JSON policy form (capitalised, accepts bare "*" or list).
        json_pat = re.compile(
            r'(?:Action|NotAction|Resource|NotResource)\s*=\s*'
            r'(?:"\*"|\[[^\]]*"\*"[^\]]*\])'
        )
        out = []
        for i, line in enumerate(lines, start=1):
            stripped = line.strip()
            if stripped.startswith("#") or stripped.startswith("//"):
                continue
            if tf_pat.search(line) or json_pat.search(line):
                out.append(self._f(
                    path, i,
                    "PROOFCTL-TF-T006", "IAM wildcard permission",
                    Severity.ERROR,
                    'Wildcard "*" in IAM actions or resources grants overly broad permissions',
                    hint="Enumerate only the specific actions/resources actually needed.",
                    authority="CIS AWS Benchmark 1.16 / AWS IAM least-privilege",
                    docs_url="https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html",
                ))
        return out

    def _t009(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """T-009 — variable / output block missing description."""
        if _is_test_fixture_path(path):
            return []
        out = []
        for b in blocks:
            if b.kind not in ("variable", "output"):
                continue
            if not b.has_attr("description"):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-T009", "Missing description",
                    Severity.INFO,
                    f'{b.kind} "{b.label1}" has no description',
                    hint='Add description = "…" to document the variable\'s purpose.',
                ))
        return out

    def _t012(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """T-012 — Deep local module path (≥3 levels of ../)."""
        if _is_test_fixture_path(path):
            return []
        out = []
        for b in blocks:
            if b.kind != "module":
                continue
            src = (b.attr_value("source") or "").strip('"')
            if src.startswith("git::") or src.startswith("registry.terraform.io"):
                continue
            depth = src.count("../")
            if depth >= 3:
                out.append(self._f(
                    path, b.attr_line("source") or b.start_line,
                    "PROOFCTL-TF-T012", "Deep relative module path",
                    Severity.WARNING,
                    f'Module "{b.label1}" source has {depth} levels of "../" — brittle coupling',
                    hint="Publish the module to a registry or use an absolute git source.",
                ))
        return out

    def _t013(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """T-013 — Resource missing required labels/tags."""
        out = []
        required = set(self._required_labels)
        for b in blocks:
            if b.kind != "resource":
                continue
            # Look for a tags or labels block/attribute
            tags_src = '\n'.join(b.raw_lines)
            for label in required:
                if not re.search(rf'"{re.escape(label)}"', tags_src):
                    out.append(self._f(
                        path, b.start_line,
                        "PROOFCTL-TF-T013", "Missing required label",
                        Severity.WARNING,
                        f'resource "{b.label1}" "{b.label2}" missing required label/tag "{label}"',
                        hint=f'Add "{label}" to the tags/labels block.',
                    ))
        return out

    # ════════════════════════════════════════════════════════════════════════
    # Group M — Terraform mechanics
    # ════════════════════════════════════════════════════════════════════════

    def _m002(self, path: Path, lines: list[str]) -> list[Finding]:
        """M-002 — ignore_changes = all silences all drift."""
        pat = re.compile(r'ignore_changes\s*=\s*all\b')
        out = []
        for i, line in enumerate(lines, start=1):
            if not line.strip().startswith("#") and pat.search(line):
                out.append(self._f(
                    path, i,
                    "PROOFCTL-TF-M002", "ignore_changes = all",
                    Severity.WARNING,
                    'ignore_changes = all suppresses ALL configuration drift forever',
                    hint='List only the specific attributes to ignore, e.g. ignore_changes = [tags].',
                ))
        return out

    def _m003(self, path: Path, lines: list[str]) -> list[Finding]:
        """M-003 — provisioner remote-exec / local-exec breaks idempotency."""
        pat = re.compile(r'provisioner\s+"(remote-exec|local-exec)"')
        out = []
        for i, line in enumerate(lines, start=1):
            if not line.strip().startswith("#"):
                m = pat.search(line)
                if m:
                    out.append(self._f(
                        path, i,
                        "PROOFCTL-TF-M003", "Imperative provisioner",
                        Severity.WARNING,
                        f'provisioner "{m.group(1)}" is not idempotent and complicates drift detection',
                        hint="Use a configuration-management tool (Ansible, cloud-init, Packer) instead.",
                    ))
        return out

    def _m004(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """M-004 — null_resource is deprecated; prefer terraform_data (TF ≥ 1.4)."""
        out = []
        for b in blocks:
            if b.kind == "resource" and b.label1 == "null_resource":
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-M004", "Deprecated null_resource",
                    Severity.INFO,
                    'null_resource is deprecated since Terraform 1.4',
                    hint="Replace with terraform_data which has the same semantics.",
                ))
        return out

    def _m005(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """M-005 — terraform_remote_state creates tight workspace coupling."""
        out = []
        for b in blocks:
            if b.kind == "data" and b.label1 == "terraform_remote_state":
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-M005", "terraform_remote_state coupling",
                    Severity.WARNING,
                    f'data "terraform_remote_state" "{b.label2}" tightly couples workspaces',
                    hint="Use outputs published via a service catalog or SSM parameters instead.",
                ))
        return out

    def _m006(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """M-006 — depends_on on a module forces full replacement on any change."""
        out = []
        for b in blocks:
            if b.kind == "module" and b.has_attr("depends_on"):
                out.append(self._f(
                    path, b.attr_line("depends_on") or b.start_line,
                    "PROOFCTL-TF-M006", "depends_on on module",
                    Severity.WARNING,
                    f'module "{b.label1}" uses depends_on — triggers full module replacement on any dependency change',
                    hint="Prefer passing values explicitly via module inputs to create fine-grained dependency edges.",
                ))
        return out

    def _m007(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """M-007 — Data source with no filter (returns all resources of the type)."""
        _filter_attrs = frozenset({
            "filter", "tags", "id", "name", "vpc_id", "cluster_name",
            "project", "region", "zone", "location", "function_name",
            "bucket", "cluster_identifier", "db_instance_identifier",
            "instance_id", "key_id", "secret_id", "policy_arn",
        })
        # Data sources that are inherently singleton or template-only (never need filters)
        _singleton_sources = frozenset({
            "terraform_remote_state", "http", "archive_file", "local_file",
            "aws_caller_identity", "aws_region", "aws_availability_zones",
            "aws_partition", "aws_billing_service_account", "aws_arn",
            "aws_iam_policy_document", "aws_iam_session_context",
            "google_client_config", "google_client_openid_userinfo",
            "google_project", "google_billing_account",
            "external", "template_file",
        })
        out = []
        for b in blocks:
            if b.kind != "data":
                continue
            if b.label1 in _singleton_sources:
                continue
            inner = '\n'.join(b.raw_lines[1:-1])
            has_filter = any(
                re.search(rf'\b{re.escape(a)}\b', inner)
                for a in _filter_attrs
            )
            if not has_filter:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-M007", "Unfiltered data source",
                    Severity.WARNING,
                    f'data "{b.label1}" "{b.label2}" has no filter — may match unintended resources',
                    hint="Add a filter, id, name, or tags block to scope the data source.",
                ))
        return out

    # ════════════════════════════════════════════════════════════════════════
    # Group V — Lifecycle antipatterns
    # ════════════════════════════════════════════════════════════════════════

    def _v001(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """V-001 — force_destroy / deletion_protection=false on prod-named resource."""
        out = []
        for b in blocks:
            if b.kind != "resource":
                continue
            if not _PROD_RE.search(b.label2):
                continue
            lineno = b.any_line_matches(r'force_destroy\s*=\s*true|deletion_protection\s*=\s*false')
            if lineno:
                out.append(self._f(
                    path, lineno,
                    "PROOFCTL-TF-V001", "force_destroy on prod resource",
                    Severity.ERROR,
                    f'resource "{b.label1}" "{b.label2}" disables deletion protection on a production resource',
                    hint="Remove force_destroy / set deletion_protection = true for prod resources.",
                ))
        return out

    def _v003(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """V-003 — Stateful resource without prevent_destroy in lifecycle."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in _STATEFUL_RESOURCES:
                continue
            if not self._has_lifecycle_attr(b, "prevent_destroy"):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-V003", "Missing prevent_destroy",
                    Severity.WARNING,
                    f'resource "{b.label1}" "{b.label2}" has no lifecycle {{ prevent_destroy = true }}',
                    hint="Add lifecycle { prevent_destroy = true } to guard stateful resources against accidental deletion.",
                ))
        return out

    def _v004(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """V-004 — Module source is git:: with no ref, or a mutable (non-SHA/non-semver) ref."""
        out = []
        for b in blocks:
            if b.kind != "module":
                continue
            src = (b.attr_value("source") or "").strip('"')
            if not src.startswith("git::"):
                continue
            if "?ref=" not in src:
                out.append(self._f(
                    path, b.attr_line("source") or b.start_line,
                    "PROOFCTL-TF-V004", "Module git source with no version pin",
                    Severity.ERROR,
                    f'module "{b.label1}" source lacks ?ref= — always pulls HEAD',
                    hint='Pin to a commit SHA or semver tag: source = "git::https://…?ref=v1.2.3"',
                ))
            else:
                # Extract the ref value (stop at & or end of query string).
                # URL-decode so percent-encoded chars (`v1%2E0` → `v1.0`,
                # `release%2Fv1` → `release/v1`) are evaluated as the user
                # intended; without this, `?ref=v1%2E0` failed both the SHA
                # and semver patterns and reported as a mutable ref.
                from urllib.parse import unquote
                ref_part = src.split("?ref=", 1)[1]
                ref_raw = re.split(r'[&?]', ref_part)[0]
                ref = unquote(ref_raw)
                if _GIT_SHA_RE.match(ref) or _SEMVER_TAG_RE.match(ref):
                    continue  # immutable SHA or semver tag — clean
                out.append(self._f(
                    path, b.attr_line("source") or b.start_line,
                    "PROOFCTL-TF-V004", "Module git source with mutable ref",
                    Severity.WARNING,
                    f'module "{b.label1}" source ref="{ref}" is a mutable branch/tag — use a commit SHA',
                    hint='Pin to a full 40-char commit SHA for a truly immutable reference.',
                ))
        return out

    # ════════════════════════════════════════════════════════════════════════
    # Group G — GCP specific
    # ════════════════════════════════════════════════════════════════════════

    def _g001(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-001 — Compute instance serial port enabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_compute_instance":
                continue
            lineno = b.any_line_matches(r'"enable-serial-port"\s*=\s*"true"', re.IGNORECASE)
            if lineno:
                out.append(self._f(
                    path, lineno,
                    "PROOFCTL-TF-G001", "Serial port enabled on compute instance",
                    Severity.ERROR,
                    f'"enable-serial-port" = "true" on instance "{b.label2}"',
                    hint='Remove or set "enable-serial-port" = "false". Serial port access bypasses SSH controls.',
                    authority="CIS GCP Benchmark 4.5",
                    docs_url="https://www.cisecurity.org/benchmark/google_cloud_computing_platform",
                ))
        return out

    def _g002(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-002 — OS Login explicitly disabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_compute_instance":
                continue
            lineno = b.any_line_matches(r'"enable-oslogin"\s*=\s*"(?:FALSE|false|0)"')
            if lineno:
                out.append(self._f(
                    path, lineno,
                    "PROOFCTL-TF-G002", "OS Login disabled on compute instance",
                    Severity.WARNING,
                    f'OS Login explicitly disabled on instance "{b.label2}"',
                    hint='Set "enable-oslogin" = "TRUE" or remove the key to inherit the project default.',
                    authority="CIS GCP Benchmark 4.4",
                    docs_url="https://www.cisecurity.org/benchmark/google_cloud_computing_platform",
                ))
        return out

    def _g003(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-003 — Shielded VM not enabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_compute_instance":
                continue
            # Flag if shielded_instance_config block is absent OR secure_boot = false
            if not b.has_nested("shielded_instance_config"):
                if not b.contains(r'shielded_instance_config'):
                    out.append(self._f(
                        path, b.start_line,
                        "PROOFCTL-TF-G003", "Shielded VM not configured",
                        Severity.WARNING,
                        f'Instance "{b.label2}" has no shielded_instance_config block',
                        hint='Add shielded_instance_config { enable_secure_boot = true enable_vtpm = true enable_integrity_monitoring = true }',
                        authority="CIS GCP Benchmark 4.8",
                        docs_url="https://www.cisecurity.org/benchmark/google_cloud_computing_platform",
                    ))
            else:
                lineno = b.any_line_matches(r'enable_secure_boot\s*=\s*false')
                if lineno:
                    out.append(self._f(
                        path, lineno,
                        "PROOFCTL-TF-G003", "Shielded VM secure boot disabled",
                        Severity.WARNING,
                        f'Instance "{b.label2}" has enable_secure_boot = false',
                        hint="Enable secure boot to prevent boot-time rootkits.",
                        authority="CIS GCP Benchmark 4.8",
                        docs_url="https://www.cisecurity.org/benchmark/google_cloud_computing_platform",
                    ))
        return out

    def _g004(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-004 — Default service account with cloud-platform scope.

        The real default Compute SA email format is
        ``<PROJECT_NUMBER>-compute@developer.gserviceaccount.com``. The
        previous regex looked for ``compute@developer`` which only matched
        the suffix in isolation; legitimate user-typed default-SA emails
        like ``123456-compute@developer.gserviceaccount.com`` were missed.
        Match the canonical suffix instead.
        """
        out = []
        # Canonical default-SA suffix (project-scoped Compute Engine default SA).
        default_sa_re = re.compile(
            r'email\s*=\s*"(?:"|[\d]+-compute@developer\.gserviceaccount\.com)',
        )
        empty_email_re = re.compile(r'email\s*=\s*""')
        any_email_re = re.compile(r'email\s*=')
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_compute_instance":
                continue
            block_src = "\n".join(b.raw_lines)
            if not (b.contains(r'service_account') and b.contains(r'cloud-platform')):
                continue
            uses_default_sa = (
                default_sa_re.search(block_src) is not None
                or empty_email_re.search(block_src) is not None
                or any_email_re.search(block_src) is None  # implicit default
            )
            if uses_default_sa:
                out.append(self._f(
                    path, b.any_line_matches(r'cloud-platform') or b.start_line,
                    "PROOFCTL-TF-G004", "Default SA with cloud-platform scope",
                    Severity.ERROR,
                    f'Instance "{b.label2}" uses the default service account with cloud-platform scope',
                    hint="Create a dedicated SA with only required roles and use granular scopes.",
                    authority="CIS GCP Benchmark 4.1",
                    docs_url="https://www.cisecurity.org/benchmark/google_cloud_computing_platform",
                ))
        return out

    def _g005(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-005 — SSH public keys in instance metadata."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in (
                "google_compute_instance", "google_compute_project_metadata",
                "google_compute_project_metadata_item",
            ):
                continue
            lineno = b.any_line_matches(r'"ssh-keys"\s*=')
            if lineno:
                out.append(self._f(
                    path, lineno,
                    "PROOFCTL-TF-G005", "SSH keys in instance metadata",
                    Severity.ERROR,
                    f'SSH keys stored in metadata on "{b.label2}"',
                    hint="Use OS Login (enable-oslogin = TRUE) for centralized SSH key management via IAM.",
                    authority="CIS GCP Benchmark 4.3",
                    docs_url="https://www.cisecurity.org/benchmark/google_cloud_computing_platform",
                ))
        return out

    def _g006(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-006 — Cloud SQL instance with public IP enabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_sql_database_instance":
                continue
            if b.contains(r'ipv4_enabled\s*=\s*true'):
                out.append(self._f(
                    path, b.any_line_matches(r'ipv4_enabled\s*=\s*true') or b.start_line,
                    "PROOFCTL-TF-G006", "Cloud SQL public IP enabled",
                    Severity.ERROR,
                    f'SQL instance "{b.label2}" has ipv4_enabled = true (public IP)',
                    hint="Set ipv4_enabled = false and use private_network or Cloud SQL Auth Proxy.",
                    authority="CIS GCP Benchmark 6.2",
                    docs_url="https://www.cisecurity.org/benchmark/google_cloud_computing_platform",
                ))
        return out

    def _g007(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-007 — AI hallucination: 'deletion_protection_enabled' is an API field, not a TF attribute."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_sql_database_instance":
                continue
            lineno = b.attr_line("deletion_protection_enabled")
            if lineno:
                out.append(self._f(
                    path, lineno,
                    "PROOFCTL-TF-G007", "Hallucinated SQL attribute",
                    Severity.ERROR,
                    '"deletion_protection_enabled" is the GCP API field name — silently ignored by Terraform',
                    hint='Use "deletion_protection = true" (Terraform attribute) instead.',
                    authority="Terraform google_sql_database_instance docs",
                    docs_url="https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/sql_database_instance",
                ))
        return out

    def _g008(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-008 — Cloud SQL automated backups disabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_sql_database_instance":
                continue
            if b.contains(r'backup_configuration') and b.contains(r'enabled\s*=\s*false'):
                out.append(self._f(
                    path, b.any_line_matches(r'enabled\s*=\s*false') or b.start_line,
                    "PROOFCTL-TF-G008", "Cloud SQL backups disabled",
                    Severity.WARNING,
                    f'SQL instance "{b.label2}" has backup_configuration.enabled = false',
                    hint="Enable automated backups: backup_configuration { enabled = true }",
                    authority="CIS GCP Benchmark 6.7",
                    docs_url="https://www.cisecurity.org/benchmark/google_cloud_computing_platform",
                ))
        return out

    def _g009(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-009 — Cloud SQL TLS explicitly disabled.

        Fires on either explicit-insecure shape:
          - Legacy:  ``require_ssl = false``
          - Modern (provider 5.x+):  ``ssl_mode = "ALLOW_UNENCRYPTED_AND_ENCRYPTED"``

        Does NOT fire on omission of both fields — that case is covered
        by G-043 (Cloud SQL not requiring SSL). Together the two rules
        provide orthogonal coverage of the Cloud SQL TLS posture.
        """
        out = []
        insecure_legacy_pat = r'require_ssl\s*=\s*false'
        insecure_modern_pat = r'ssl_mode\s*=\s*"ALLOW_UNENCRYPTED_AND_ENCRYPTED"'
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_sql_database_instance":
                continue
            legacy_line = b.any_line_matches(insecure_legacy_pat)
            modern_line = b.any_line_matches(insecure_modern_pat)
            if legacy_line is None and modern_line is None:
                continue
            line = legacy_line or modern_line
            detail = "require_ssl = false" if legacy_line else 'ssl_mode = "ALLOW_UNENCRYPTED_AND_ENCRYPTED"'
            out.append(self._f(
                path, line or b.start_line,
                "PROOFCTL-TF-G009", "Cloud SQL TLS explicitly disabled",
                Severity.ERROR,
                f'SQL instance "{b.label2}" has TLS explicitly disabled ({detail})',
                hint='Set ssl_mode = "ENCRYPTED_ONLY" (or "TRUSTED_CLIENT_CERTIFICATE_REQUIRED") to enforce TLS for all client connections.',
                authority="CIS GCP Benchmark 6.4",
                docs_url="https://cloud.google.com/sql/docs/mysql/configure-ssl-instance",
            ))
        return out

    def _g010(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-010 — GKE cluster not configured as private."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_container_cluster":
                continue
            # Flag if private_cluster_config is missing or enable_private_nodes=false
            if b.contains(r'enable_private_nodes\s*=\s*false'):
                out.append(self._f(
                    path, b.any_line_matches(r'enable_private_nodes\s*=\s*false') or b.start_line,
                    "PROOFCTL-TF-G010", "GKE cluster not private",
                    Severity.ERROR,
                    f'Cluster "{b.label2}" has enable_private_nodes = false',
                    hint="Enable private nodes to prevent direct internet access to cluster nodes.",
                    authority="CIS GKE Benchmark 6.6.1",
                    docs_url="https://www.cisecurity.org/benchmark/google_kubernetes_engine",
                ))
            elif not b.contains(r'private_cluster_config'):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G010", "GKE cluster not private",
                    Severity.WARNING,
                    f'Cluster "{b.label2}" has no private_cluster_config block',
                    hint="Add private_cluster_config { enable_private_nodes = true enable_private_endpoint = false master_ipv4_cidr_block = … }",
                    authority="CIS GKE Benchmark 6.6.1",
                    docs_url="https://www.cisecurity.org/benchmark/google_kubernetes_engine",
                ))
        return out

    def _g011(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-011 — Workload identity at cluster level but missing from node pool metadata config."""
        cluster_has_wi = any(
            b.kind == "resource"
            and b.label1 == "google_container_cluster"
            and b.contains(r'workload_identity_config')
            for b in blocks
        )
        if not cluster_has_wi:
            return []
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_container_node_pool":
                continue
            has_gke_metadata = (
                b.contains(r'workload_metadata_config')
                and b.contains(r'GKE_METADATA')
            )
            if not has_gke_metadata:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G011", "Workload identity node pool gap",
                    Severity.ERROR,
                    f'Node pool "{b.label2}" missing workload_metadata_config while cluster has workload_identity_config',
                    hint='Add to node_config: workload_metadata_config { mode = "GKE_METADATA" }',
                    authority="GKE Workload Identity docs / CIS GKE Benchmark 6.2.2",
                    docs_url="https://cloud.google.com/kubernetes-engine/docs/concepts/workload-identity",
                ))
        return out

    def _g012(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-012 — Legacy ABAC enabled on GKE cluster."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_container_cluster":
                continue
            if b.contains(r'enable_legacy_abac\s*=\s*true'):
                out.append(self._f(
                    path, b.any_line_matches(r'enable_legacy_abac\s*=\s*true') or b.start_line,
                    "PROOFCTL-TF-G012", "Legacy ABAC enabled",
                    Severity.ERROR,
                    f'Cluster "{b.label2}" has enable_legacy_abac = true',
                    hint="Remove enable_legacy_abac (defaults to false). Use RBAC instead.",
                    authority="CIS GKE Benchmark 6.8.4",
                    docs_url="https://www.cisecurity.org/benchmark/google_kubernetes_engine",
                ))
        return out

    def _g013(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-013 — Network policy disabled on GKE cluster."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_container_cluster":
                continue
            if b.contains(r'network_policy') and b.contains(r'enabled\s*=\s*false'):
                out.append(self._f(
                    path, b.any_line_matches(r'enabled\s*=\s*false') or b.start_line,
                    "PROOFCTL-TF-G013", "GKE network policy disabled",
                    Severity.WARNING,
                    f'Cluster "{b.label2}" has network_policy.enabled = false',
                    hint="Enable network policy to restrict pod-to-pod traffic: network_policy { enabled = true }",
                    authority="CIS GKE Benchmark 6.6.7",
                    docs_url="https://www.cisecurity.org/benchmark/google_kubernetes_engine",
                ))
        return out

    def _g014(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-014 — GKE cluster without master authorized networks."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_container_cluster":
                continue
            if not b.contains(r'master_authorized_networks_config'):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G014", "No master authorized networks",
                    Severity.WARNING,
                    f'Cluster "{b.label2}" has no master_authorized_networks_config',
                    hint="Restrict API server access: master_authorized_networks_config { cidr_blocks { cidr_block = … } }",
                    authority="CIS GKE Benchmark 6.6.2",
                    docs_url="https://www.cisecurity.org/benchmark/google_kubernetes_engine",
                ))
        return out

    def _g015(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-015 — Binary authorization not enforced on GKE cluster."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_container_cluster":
                continue
            if b.contains(r'binary_authorization'):
                if b.contains(r'evaluation_mode\s*=\s*"DISABLED"') or not b.contains(r'PROJECT_SINGLETON_POLICY_ENFORCE'):
                    out.append(self._f(
                        path, b.any_line_matches(r'binary_authorization') or b.start_line,
                        "PROOFCTL-TF-G015", "Binary authorization not enforced",
                        Severity.WARNING,
                        f'Cluster "{b.label2}" binary_authorization is not set to PROJECT_SINGLETON_POLICY_ENFORCE',
                        hint='Set evaluation_mode = "PROJECT_SINGLETON_POLICY_ENFORCE".',
                        authority="CIS GKE Benchmark 6.10.2",
                        docs_url="https://www.cisecurity.org/benchmark/google_kubernetes_engine",
                    ))
        return out

    def _g016(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-016 — GKE logging or monitoring disabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_container_cluster":
                continue
            for attr in ("logging_service", "monitoring_service"):
                if b.contains(rf'{attr}\s*=\s*"none"'):
                    out.append(self._f(
                        path, b.any_line_matches(rf'{attr}\s*=\s*"none"') or b.start_line,
                        "PROOFCTL-TF-G016", "GKE logging/monitoring disabled",
                        Severity.ERROR,
                        f'Cluster "{b.label2}" has {attr} = "none"',
                        hint=f'Remove {attr} or set to "logging.googleapis.com/kubernetes".',
                        authority="CIS GKE Benchmark 6.7.1",
                        docs_url="https://www.cisecurity.org/benchmark/google_kubernetes_engine",
                    ))
        return out

    def _g017(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-017 — GCS bucket public access prevention not enforced."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_storage_bucket":
                continue
            val = b.attr_value("public_access_prevention")
            if val is None or val.strip('"') != "enforced":
                out.append(self._f(
                    path, b.attr_line("public_access_prevention") or b.start_line,
                    "PROOFCTL-TF-G017", "GCS public access not prevented",
                    Severity.ERROR,
                    f'Bucket "{b.label2}" public_access_prevention is not "enforced"',
                    hint='Set public_access_prevention = "enforced".',
                    authority="CIS GCP Benchmark 5.1",
                    docs_url="https://www.cisecurity.org/benchmark/google_cloud_computing_platform",
                ))
        return out

    def _g018(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-018 — GCS uniform bucket-level access disabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_storage_bucket":
                continue
            if b.contains(r'uniform_bucket_level_access\s*=\s*false'):
                out.append(self._f(
                    path, b.any_line_matches(r'uniform_bucket_level_access\s*=\s*false') or b.start_line,
                    "PROOFCTL-TF-G018", "Uniform bucket-level access disabled",
                    Severity.WARNING,
                    f'Bucket "{b.label2}" has uniform_bucket_level_access = false',
                    hint="Enable uniform ACLs to avoid object-level permission surprises.",
                    authority="CIS GCP Benchmark 5.2",
                    docs_url="https://www.cisecurity.org/benchmark/google_cloud_computing_platform",
                ))
        return out

    def _g019(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-019 — GCS bucket versioning not enabled (absent or explicitly false)."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_storage_bucket":
                continue
            has_versioning_block = b.contains(r'versioning\s*\{')
            enabled_false = b.contains(r'enabled\s*=\s*false')
            if not has_versioning_block or enabled_false:
                line = (b.any_line_matches(r'enabled\s*=\s*false') or b.start_line) if enabled_false else b.start_line
                msg = (
                    f'Bucket "{b.label2}" has versioning.enabled = false'
                    if enabled_false
                    else f'Bucket "{b.label2}" has no versioning block — versioning is disabled by default'
                )
                out.append(self._f(
                    path, line,
                    "PROOFCTL-TF-G019", "GCS versioning not enabled",
                    Severity.WARNING,
                    msg,
                    hint="Enable versioning: versioning { enabled = true }",
                ))
        return out

    def _g020(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-020 — google_service_account_key resource (key stored in TF state)."""
        out = []
        for b in blocks:
            if b.kind == "resource" and b.label1 == "google_service_account_key":
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G020", "Service account key resource",
                    Severity.ERROR,
                    f'google_service_account_key "{b.label2}" stores a private key in Terraform state',
                    hint="Use Workload Identity instead of long-lived SA keys. If a key is essential, manage it outside Terraform.",
                    authority="CIS GCP Benchmark 1.4",
                    docs_url="https://www.cisecurity.org/benchmark/google_cloud_computing_platform",
                ))
        return out

    def _g021(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-021 — Broad GCP project IAM role (owner/editor)."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in _GCP_IAM_RESOURCES:
                continue
            role = (b.attr_value("role") or "").strip('"')
            if role in _BROAD_GCP_ROLES:
                out.append(self._f(
                    path, b.attr_line("role") or b.start_line,
                    "PROOFCTL-TF-G021", "Overly broad GCP IAM role",
                    Severity.ERROR,
                    f'"{b.label1}" grants "{role}" — violates least privilege',
                    hint="Use a predefined role scoped to the specific service (e.g. roles/storage.objectCreator).",
                    authority="CIS GCP Benchmark 1.2",
                    docs_url="https://www.cisecurity.org/benchmark/google_cloud_computing_platform",
                ))
        return out

    def _g023(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-023 — KMS key rotation not configured or > 90 days."""
        out = []
        _90_days_sec = 90 * 24 * 3600
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_kms_crypto_key":
                continue
            rp = (b.attr_value("rotation_period") or "").strip('"') or None
            if rp is None:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G023", "KMS key rotation not set",
                    Severity.WARNING,
                    f'KMS key "{b.label2}" has no rotation_period',
                    hint='Set rotation_period = "7776000s" (90 days) or less.',
                    authority="CIS GCP Benchmark 1.10",
                    docs_url="https://www.cisecurity.org/benchmark/google_cloud_computing_platform",
                ))
            else:
                sec_m = re.match(r'(\d+)s', rp.strip())
                if sec_m and int(sec_m.group(1)) > _90_days_sec:
                    out.append(self._f(
                        path, b.attr_line("rotation_period") or b.start_line,
                        "PROOFCTL-TF-G023", "KMS key rotation too infrequent",
                        Severity.WARNING,
                        f'KMS key "{b.label2}" rotation_period exceeds 90 days',
                        hint='Set rotation_period = "7776000s" (90 days) or less.',
                        authority="CIS GCP Benchmark 1.10",
                    ))
        return out

    def _g024(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-024 — KMS key missing prevent_destroy."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_kms_crypto_key":
                continue
            if not self._has_lifecycle_attr(b, "prevent_destroy"):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G024", "KMS key missing prevent_destroy",
                    Severity.WARNING,
                    f'KMS key "{b.label2}" has no lifecycle {{ prevent_destroy = true }}',
                    hint="Destroying a KMS key is irreversible — add prevent_destroy.",
                ))
        return out

    def _g025(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-025 — KMS key destroy_scheduled_duration absent (GCP default = 24h) or < 7 days."""
        _7_days_sec = 7 * 24 * 3600
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_kms_crypto_key":
                continue
            val = (b.attr_value("destroy_scheduled_duration") or "").strip('"') or None
            if val is None:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G025", "KMS key destroy window not set",
                    Severity.WARNING,
                    f'KMS key "{b.label2}" has no destroy_scheduled_duration — GCP defaults to 24h',
                    hint='Set destroy_scheduled_duration = "604800s" (7 days) or more.',
                ))
            else:
                sec_m = re.match(r'(\d+)s', val.strip())
                if sec_m and int(sec_m.group(1)) < _7_days_sec:
                    out.append(self._f(
                        path, b.attr_line("destroy_scheduled_duration") or b.start_line,
                        "PROOFCTL-TF-G025", "KMS key destroy window too short",
                        Severity.WARNING,
                        f'KMS key "{b.label2}" destroy_scheduled_duration is less than 7 days',
                        hint='Set destroy_scheduled_duration = "604800s" (7 days) or more.',
                    ))
        return out

    # ════════════════════════════════════════════════════════════════════════
    # Group G — GCP (extended rules TF-G026–TF-G031)
    # ════════════════════════════════════════════════════════════════════════

    def _g026(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-026 — IAM binding grants allUsers or allAuthenticatedUsers."""
        _public_members = frozenset({"allUsers", "allAuthenticatedUsers"})
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in (
                "google_project_iam_member", "google_project_iam_binding",
            ):
                continue
            # Check `member` or `members` attribute
            val = b.attr_value("member") or b.attr_value("members") or ""
            for pm in _public_members:
                if pm in val:
                    out.append(self._f(
                        path, b.attr_line("member") or b.attr_line("members") or b.start_line,
                        "PROOFCTL-TF-G026", "IAM binding grants public access",
                        Severity.ERROR,
                        f"IAM binding '{b.label2}' grants access to allUsers/allAuthenticatedUsers — public access to GCP resource",
                        hint="Remove allUsers/allAuthenticatedUsers. Grant access to specific service accounts or groups.",
                        authority="CIS GCP Benchmark 1.15",
                        docs_url="https://www.cisecurity.org/benchmark/google_cloud_computing_platform",
                    ))
                    break
        return out

    def _g027(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-027 — Cloud Function (Gen1 or Gen2) with ALLOW_ALL ingress."""
        out = []
        for b in blocks:
            if b.kind != "resource":
                continue
            if b.label1 == "google_cloudfunctions_function":
                val = (b.attr_value("ingress_settings") or "").strip('"')
                if val == "ALLOW_ALL":
                    out.append(self._f(
                        path, b.attr_line("ingress_settings") or b.start_line,
                        "PROOFCTL-TF-G027", "Cloud Function accepts all ingress",
                        Severity.WARNING,
                        f"Cloud Function '{b.label2}' accepts requests from all sources (ingress_settings = ALLOW_ALL)",
                        hint='Set ingress_settings = "ALLOW_INTERNAL_ONLY" or "ALLOW_INTERNAL_AND_GCLB" unless function must be public.',
                        authority="GCP Security Best Practices – Cloud Functions",
                        docs_url="https://cloud.google.com/functions/docs/securing",
                    ))
            elif b.label1 == "google_cloudfunctions2_function":
                # Gen2: ingress_settings lives inside service_config block
                if b.contains(r'ingress_settings\s*=\s*"ALLOW_ALL"'):
                    line = b.any_line_matches(r'ingress_settings\s*=\s*"ALLOW_ALL"') or b.start_line
                    out.append(self._f(
                        path, line,
                        "PROOFCTL-TF-G027", "Cloud Function (Gen2) accepts all ingress",
                        Severity.WARNING,
                        f"Cloud Function Gen2 '{b.label2}' accepts requests from all sources (ingress_settings = ALLOW_ALL)",
                        hint='In service_config, set ingress_settings = "ALLOW_INTERNAL_ONLY" or "ALLOW_INTERNAL_AND_GCLB".',
                        authority="GCP Security Best Practices – Cloud Functions",
                        docs_url="https://cloud.google.com/functions/docs/securing",
                    ))
        return out

    def _g028(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-028 — Cloud Run IAM binding with allUsers."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in (
                "google_cloud_run_service_iam_member",
                "google_cloud_run_service_iam_binding",
            ):
                continue
            val = b.attr_value("member") or b.attr_value("members") or ""
            if "allUsers" in val:
                out.append(self._f(
                    path, b.attr_line("member") or b.attr_line("members") or b.start_line,
                    "PROOFCTL-TF-G028", "Cloud Run service publicly accessible",
                    Severity.WARNING,
                    f"Cloud Run service '{b.label2}' is publicly accessible (allUsers) — unauthenticated invocation allowed",
                    hint="Remove allUsers IAM binding. Use IAM auth or a load balancer with Cloud Armor.",
                    authority="GCP Security Best Practices – Cloud Run authentication",
                    docs_url="https://cloud.google.com/run/docs/securing/ingress",
                ))
        return out

    def _g029(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-029 — Subnetwork without VPC Flow Logs (log_config block absent)."""
        _skip_purposes = frozenset({
            "INTERNAL_HTTPS_LOAD_BALANCER", "REGIONAL_MANAGED_PROXY",
            "GLOBAL_MANAGED_PROXY", "PRIVATE_SERVICE_CONNECT",
        })
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_compute_subnetwork":
                continue
            # Skip proxy/load-balancer subnets
            purpose = (b.attr_value("purpose") or "").strip('"').upper()
            if purpose in _skip_purposes:
                continue
            if not b.contains(r'log_config'):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G029", "Subnetwork missing VPC Flow Logs",
                    Severity.WARNING,
                    f"Subnetwork '{b.label2}' has no VPC Flow Logs — network traffic is not logged",
                    hint='Add log_config { aggregation_interval = "INTERVAL_5_SEC" flow_sampling = 0.5 metadata = "INCLUDE_ALL_METADATA" }',
                    authority="CIS GCP Benchmark 3.8",
                    docs_url="https://www.cisecurity.org/benchmark/google_cloud_computing_platform",
                ))
        return out

    def _g030(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-030 — BigQuery dataset with public access."""
        _public_pat = re.compile(
            r'special_group\s*=\s*"(?:allAuthenticatedUsers|allUsers)"'
        )
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_bigquery_dataset":
                continue
            body = "\n".join(b.raw_lines)
            m = _public_pat.search(body)
            if m:
                lineno = b.any_line_matches(
                    r'special_group\s*=\s*"(?:allAuthenticatedUsers|allUsers)"'
                )
                out.append(self._f(
                    path, lineno or b.start_line,
                    "PROOFCTL-TF-G030", "BigQuery dataset grants public access",
                    Severity.ERROR,
                    f"BigQuery dataset '{b.label2}' grants access to allAuthenticatedUsers — data is publicly readable",
                    hint="Remove allAuthenticatedUsers from dataset access. Grant specific users or service accounts.",
                    authority="CIS GCP Benchmark 7.1",
                    docs_url="https://www.cisecurity.org/benchmark/google_cloud_computing_platform",
                ))
        return out

    def _g031(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-031 — Pub/Sub topic without CMEK."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_pubsub_topic":
                continue
            if not b.has_attr("kms_key_name"):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G031", "Pub/Sub topic without CMEK",
                    Severity.WARNING,
                    f"Pub/Sub topic '{b.label2}' uses Google-managed encryption — no CMEK configured",
                    hint="Set kms_key_name to a Cloud KMS key for customer-managed encryption.",
                    authority="GCP Security Best Practices – Pub/Sub CMEK",
                    docs_url="https://cloud.google.com/pubsub/docs/encryption",
                ))
        return out

    def _g032(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-032 — GCS bucket access logging not configured."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_storage_bucket":
                continue
            if not b.contains(r'logging\s*\{'):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G032", "GCS bucket access logging not configured",
                    Severity.WARNING,
                    f'Bucket "{b.label2}" has no logging block — access requests are not logged',
                    hint='Add logging { log_bucket = "your-log-bucket" } to enable access logging.',
                    authority="CIS GCP Benchmark 5.3",
                    docs_url="https://www.cisecurity.org/benchmark/google_cloud_computing_platform",
                ))
        return out

    def _g033(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-033 — Subnetwork private_ip_google_access not enabled."""
        _skip_purposes = frozenset({
            "INTERNAL_HTTPS_LOAD_BALANCER", "REGIONAL_MANAGED_PROXY",
            "GLOBAL_MANAGED_PROXY", "PRIVATE_SERVICE_CONNECT",
        })
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_compute_subnetwork":
                continue
            purpose = (b.attr_value("purpose") or "").strip('"').upper()
            if purpose in _skip_purposes:
                continue
            val = (b.attr_value("private_ip_google_access") or "").strip('"').lower()
            if val != "true":
                out.append(self._f(
                    path, b.attr_line("private_ip_google_access") or b.start_line,
                    "PROOFCTL-TF-G033", "Subnetwork private_ip_google_access not enabled",
                    Severity.WARNING,
                    f"Subnetwork '{b.label2}' has private_ip_google_access disabled — VMs cannot reach Google APIs without a public IP",
                    hint="Set private_ip_google_access = true to allow VMs to access Google APIs via private networking.",
                    authority="CIS GCP Benchmark 3.9",
                    docs_url="https://www.cisecurity.org/benchmark/google_cloud_computing_platform",
                ))
        return out

    def _g034(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-034 — GKE cluster missing explicit enable_legacy_abac = false."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_container_cluster":
                continue
            val = b.attr_value("enable_legacy_abac")
            if val is None:
                # Absent — provider default is false now, but old default was true.
                # Flag absence as defence-in-depth.
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G034", "Legacy ABAC not explicitly disabled",
                    Severity.ERROR,
                    f'Cluster "{b.label2}" has no explicit enable_legacy_abac = false',
                    hint="Set enable_legacy_abac = false to ensure legacy ABAC stays disabled. Use RBAC instead.",
                    authority="CIS GKE Benchmark 6.8.4",
                    docs_url="https://www.cisecurity.org/benchmark/google_kubernetes_engine",
                ))
            # Note: explicit `true` is already covered by G-012.
        return out

    def _g035(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-035 — GKE cluster without private_cluster_config { enable_private_nodes = true }."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_container_cluster":
                continue
            has_pcc = b.contains(r'private_cluster_config\s*\{')
            has_priv_nodes_true = b.contains(r'enable_private_nodes\s*=\s*true')
            if not has_pcc or not has_priv_nodes_true:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G035", "GKE private nodes not enabled",
                    Severity.WARNING,
                    f'Cluster "{b.label2}" does not set private_cluster_config.enable_private_nodes = true',
                    hint="Add private_cluster_config { enable_private_nodes = true … } to keep nodes off the public internet.",
                    authority="CIS GKE Benchmark 6.6.5",
                    docs_url="https://cloud.google.com/kubernetes-engine/docs/concepts/private-cluster-concept",
                ))
        return out

    def _g036(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-036 — GKE node metadata server endpoints not disabled (legacy endpoints reachable)."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in ("google_container_cluster", "google_container_node_pool"):
                continue
            # Heuristic: require disable-legacy-endpoints = "true" anywhere in the block.
            if not b.contains(r'disable-legacy-endpoints\s*=\s*"true"'):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G036", "GKE legacy metadata endpoints reachable",
                    Severity.ERROR,
                    f'{b.label1} "{b.label2}" missing node_config.metadata."disable-legacy-endpoints" = "true"',
                    hint='Add node_config { metadata = { disable-legacy-endpoints = "true" } }.',
                    authority="CIS GKE Benchmark 6.4.1",
                    docs_url="https://cloud.google.com/kubernetes-engine/docs/how-to/protecting-cluster-metadata",
                ))
        return out

    def _g037(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-037 — GKE node pool / node_config without shielded_instance_config secure boot + integrity monitoring."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in ("google_container_cluster", "google_container_node_pool"):
                continue
            has_block = b.contains(r'shielded_instance_config\s*\{')
            has_secure = b.contains(r'enable_secure_boot\s*=\s*true')
            has_integrity = b.contains(r'enable_integrity_monitoring\s*=\s*true')
            if not (has_block and has_secure and has_integrity):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G037", "GKE node shielded config incomplete",
                    Severity.WARNING,
                    f'{b.label1} "{b.label2}" missing shielded_instance_config with enable_secure_boot = true and enable_integrity_monitoring = true',
                    hint="Add shielded_instance_config { enable_secure_boot = true enable_integrity_monitoring = true }.",
                    authority="CIS GKE Benchmark 6.5.5",
                    docs_url="https://cloud.google.com/kubernetes-engine/docs/how-to/shielded-gke-nodes",
                ))
        return out

    def _g038(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-038 — GKE cluster without release_channel pinned to STABLE/REGULAR/RAPID."""
        _channel_re = re.compile(r'channel\s*=\s*"(STABLE|REGULAR|RAPID)"')
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_container_cluster":
                continue
            body = "\n".join(b.raw_lines)
            has_block = bool(re.search(r'release_channel\s*\{', body))
            has_channel = bool(_channel_re.search(body))
            if not has_block or not has_channel:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G038", "GKE release_channel not pinned",
                    Severity.INFO,
                    f'Cluster "{b.label2}" has no release_channel pinned to STABLE/REGULAR/RAPID — auto-upgrade cadence unmanaged',
                    hint='Add release_channel { channel = "REGULAR" } to opt into managed upgrades.',
                    authority="CIS GKE Benchmark 6.5.3",
                    docs_url="https://cloud.google.com/kubernetes-engine/docs/concepts/release-channels",
                ))
        return out

    # G-039 intentionally not implemented: TF-G014 already fires on absence of
    # master_authorized_networks_config for google_container_cluster.

    def _g040(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-040 — GKE cluster without enable_shielded_nodes = true."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_container_cluster":
                continue
            val = (b.attr_value("enable_shielded_nodes") or "").strip().lower()
            if val != "true":
                out.append(self._f(
                    path, b.attr_line("enable_shielded_nodes") or b.start_line,
                    "PROOFCTL-TF-G040", "GKE shielded nodes not enabled",
                    Severity.WARNING,
                    f'Cluster "{b.label2}" has enable_shielded_nodes not set to true',
                    hint="Set enable_shielded_nodes = true on the cluster.",
                    authority="CIS GKE Benchmark 6.5.5",
                    docs_url="https://cloud.google.com/kubernetes-engine/docs/how-to/shielded-gke-nodes",
                ))
        return out

    def _g041(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-041 — GKE node_config using default Compute Engine service account."""
        _default_sa_re = re.compile(r'service_account\s*=\s*"(?:default|[\w\-]+-compute@developer\.gserviceaccount\.com)"')
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in ("google_container_cluster", "google_container_node_pool"):
                continue
            body = "\n".join(b.raw_lines)
            uses_default = bool(_default_sa_re.search(body))
            # Absence of any service_account inside node_config also implies default SA.
            has_sa_attr = bool(re.search(r'service_account\s*=', body))
            if uses_default or not has_sa_attr:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-G041", "GKE node uses default service account",
                    Severity.WARNING,
                    f'{b.label1} "{b.label2}" uses default Compute Engine service account — over-privileged',
                    hint="Create a dedicated service account with minimal roles and reference it via node_config.service_account.",
                    authority="CIS GKE Benchmark 6.2.1",
                    docs_url="https://cloud.google.com/kubernetes-engine/docs/how-to/hardening-your-cluster#use_least_privilege_sa",
                ))
        return out

    # ════════════════════════════════════════════════════════════════════════
    # Group A — AWS specific
    # ════════════════════════════════════════════════════════════════════════

    def _a001(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-001 — EC2 IMDSv2 not enforced."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in ("aws_instance", "aws_launch_template"):
                continue
            if b.contains(r'metadata_options'):
                if b.contains(r'http_tokens\s*=\s*"optional"'):
                    out.append(self._f(
                        path, b.any_line_matches(r'http_tokens\s*=\s*"optional"') or b.start_line,
                        "PROOFCTL-TF-A001", "IMDSv2 not required",
                        Severity.ERROR,
                        f'"{b.label2}" has http_tokens = "optional" — IMDSv1 still accessible',
                        hint='Set http_tokens = "required" to enforce IMDSv2 and block SSRF-based credential theft.',
                        authority="AWS Security Best Practices / CIS AWS Benchmark 5.6",
                    ))
            else:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-A001", "IMDSv2 not required",
                    Severity.WARNING,
                    f'"{b.label2}" has no metadata_options block — IMDSv1 defaults to enabled',
                    hint='Add metadata_options { http_tokens = "required" http_endpoint = "enabled" }',
                    authority="AWS Security Best Practices / CIS AWS Benchmark 5.6",
                    docs_url="https://docs.aws.amazon.com/security/latest/userguide/infrastructure-security.html",
                ))
        return out

    def _a003(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-003 — RDS skip_final_snapshot = true or deletion_protection = false."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in ("aws_db_instance", "aws_rds_cluster"):
                continue
            if b.contains(r'skip_final_snapshot\s*=\s*true'):
                out.append(self._f(
                    path, b.any_line_matches(r'skip_final_snapshot\s*=\s*true') or b.start_line,
                    "PROOFCTL-TF-A003", "RDS skip_final_snapshot enabled",
                    Severity.ERROR,
                    f'RDS "{b.label2}" will skip final snapshot on deletion',
                    hint="Set skip_final_snapshot = false and final_snapshot_identifier.",
                    authority="CIS AWS Benchmark 2.3",
                    docs_url="https://www.cisecurity.org/benchmark/amazon_web_services",
                ))
            if b.contains(r'deletion_protection\s*=\s*false'):
                out.append(self._f(
                    path, b.any_line_matches(r'deletion_protection\s*=\s*false') or b.start_line,
                    "PROOFCTL-TF-A003", "RDS deletion protection disabled",
                    Severity.ERROR,
                    f'RDS "{b.label2}" has deletion_protection = false',
                    hint="Set deletion_protection = true to prevent accidental deletion.",
                ))
        return out

    def _a004(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-004 — RDS backup retention = 0."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in ("aws_db_instance", "aws_rds_cluster"):
                continue
            if b.contains(r'backup_retention_period\s*=\s*0\b'):
                out.append(self._f(
                    path, b.any_line_matches(r'backup_retention_period\s*=\s*0') or b.start_line,
                    "PROOFCTL-TF-A004", "RDS backup retention disabled",
                    Severity.ERROR,
                    f'RDS "{b.label2}" has backup_retention_period = 0 (backups disabled)',
                    hint="Set backup_retention_period ≥ 7 for point-in-time recovery.",
                    authority="CIS AWS Benchmark 2.3",
                    docs_url="https://www.cisecurity.org/benchmark/amazon_web_services",
                ))
        return out

    def _a005(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-005 — EKS endpoint publicly accessible without CIDR restriction."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_eks_cluster":
                continue
            if b.contains(r'endpoint_public_access\s*=\s*true'):
                if not b.contains(r'public_access_cidrs'):
                    out.append(self._f(
                        path, b.any_line_matches(r'endpoint_public_access\s*=\s*true') or b.start_line,
                        "PROOFCTL-TF-A005", "EKS endpoint public without CIDR restriction",
                        Severity.WARNING,
                        f'EKS cluster "{b.label2}" has public endpoint without public_access_cidrs',
                        hint='Add public_access_cidrs = ["<your-office-cidr>"] or set endpoint_public_access = false.',
                        authority="CIS EKS Benchmark 2.1.1",
                        docs_url="https://www.cisecurity.org/benchmark/amazon_elastic_kubernetes_service",
                    ))
        return out

    def _a006(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-006 — EKS secrets not encrypted with KMS."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_eks_cluster":
                continue
            if not (b.contains(r'encryption_config') and b.contains(r'"secrets"')):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-A006", "EKS secrets not encrypted",
                    Severity.ERROR,
                    f'EKS cluster "{b.label2}" has no secrets encryption_config',
                    hint='Add encryption_config { resources = ["secrets"] provider { key_arn = … } }',
                    authority="CIS EKS Benchmark 2.1.2",
                    docs_url="https://www.cisecurity.org/benchmark/amazon_elastic_kubernetes_service",
                ))
        return out

    def _a007(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-007 — EBS volume or EC2 root volume not encrypted."""
        out = []
        for b in blocks:
            if b.kind != "resource":
                continue
            if b.label1 == "aws_ebs_volume":
                if not b.contains(r'encrypted\s*=\s*true'):
                    out.append(self._f(
                        path, b.start_line,
                        "PROOFCTL-TF-A007", "EBS volume not encrypted",
                        Severity.ERROR,
                        f'EBS volume "{b.label2}" is missing encrypted = true',
                        hint="Add encrypted = true and optionally kms_key_id.",
                        authority="CIS AWS Benchmark 2.2.1",
                        docs_url="https://www.cisecurity.org/benchmark/amazon_web_services",
                    ))
            elif b.label1 == "aws_instance":
                # Check root_block_device for encrypted
                if b.contains(r'root_block_device') and not b.contains(r'encrypted\s*=\s*true'):
                    out.append(self._f(
                        path, b.any_line_matches(r'root_block_device') or b.start_line,
                        "PROOFCTL-TF-A007", "EC2 root volume not encrypted",
                        Severity.WARNING,
                        f'EC2 instance "{b.label2}" root_block_device missing encrypted = true',
                        hint="Add encrypted = true to root_block_device.",
                    ))
        return out

    def _a008(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-008 — Lambda function with plaintext secret in environment variables."""
        secret_key_re = re.compile(
            r'"(?:SECRET|PASSWORD|TOKEN|KEY|CREDENTIAL|API_KEY|AUTH)[^"]*"\s*=\s*"[^"$\{][^"]{3,}"',
            re.IGNORECASE,
        )
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_lambda_function":
                continue
            if b.contains(r'environment') and b.contains(r'variables'):
                for i, line in enumerate(b.raw_lines):
                    if secret_key_re.search(line):
                        out.append(self._f(
                            path, b.start_line + i,
                            "PROOFCTL-TF-A008", "Lambda plaintext secret in env var",
                            Severity.ERROR,
                            f'Lambda "{b.label2}" environment variable appears to contain a literal secret',
                            hint="Use AWS Secrets Manager or SSM Parameter Store and retrieve at runtime.",
                            authority="OWASP A02:2021 Cryptographic Failures",
                        ))
                        break
        return out

    def _a009(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-009 — ElastiCache transit encryption disabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in (
                "aws_elasticache_replication_group", "aws_elasticache_cluster"
            ):
                continue
            if b.contains(r'transit_encryption_enabled\s*=\s*false'):
                out.append(self._f(
                    path, b.any_line_matches(r'transit_encryption_enabled\s*=\s*false') or b.start_line,
                    "PROOFCTL-TF-A009", "ElastiCache transit encryption disabled",
                    Severity.ERROR,
                    f'ElastiCache "{b.label2}" has transit_encryption_enabled = false',
                    hint="Set transit_encryption_enabled = true to encrypt data in transit.",
                    authority="CIS AWS Benchmark 3.7",
                    docs_url="https://www.cisecurity.org/benchmark/amazon_web_services",
                ))
        return out

    def _a010(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-010 — CloudTrail not integrated with CloudWatch Logs."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_cloudtrail":
                continue
            if not b.has_attr("cloud_watch_logs_group_arn"):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-A010", "CloudTrail missing CloudWatch integration",
                    Severity.WARNING,
                    f'CloudTrail "{b.label2}" has no cloud_watch_logs_group_arn',
                    hint="Add cloud_watch_logs_group_arn and cloud_watch_logs_role_arn for real-time alerting.",
                    authority="CIS AWS Benchmark 3.2",
                    docs_url="https://www.cisecurity.org/benchmark/amazon_web_services",
                ))
        return out

    def _a011(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-011 — No aws_cloudtrail resource found anywhere in scanned blocks."""
        has_aws = any(
            b.kind == "resource" and b.label1.startswith("aws_")
            for b in blocks
        )
        if not has_aws:
            return []
        has_trail = any(
            b.kind == "resource" and b.label1.startswith("aws_cloudtrail")
            for b in blocks
        )
        if not has_trail:
            return [self._f(
                path, None,
                "PROOFCTL-TF-A011", "No CloudTrail resource",
                Severity.WARNING,
                "No aws_cloudtrail resource found — API activity is not being audited",
                hint="Add an aws_cloudtrail resource with multi_region_trail = true and log validation enabled.",
                authority="CIS AWS Benchmark 3.1",
                docs_url="https://www.cisecurity.org/benchmark/amazon_web_services",
            )]
        return []

    def _a012(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-012 — aws_vpc present but no aws_flow_log resource."""
        has_vpc = any(
            b.kind == "resource" and b.label1 == "aws_vpc"
            for b in blocks
        )
        if not has_vpc:
            return []
        has_flow_log = any(
            b.kind == "resource" and b.label1 == "aws_flow_log"
            for b in blocks
        )
        if not has_flow_log:
            return [self._f(
                path, None,
                "PROOFCTL-TF-A012", "VPC missing flow logs",
                Severity.WARNING,
                "aws_vpc found but no aws_flow_log resource — VPC network traffic is not logged",
                hint="Add aws_flow_log with traffic_type = ALL pointing at your VPC.",
                authority="CIS AWS Benchmark 2.9",
                docs_url="https://www.cisecurity.org/benchmark/amazon_web_services",
            )]
        return []

    def _a013(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-013 — ECR repository with mutable tags or scan_on_push disabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_ecr_repository":
                continue
            mutability = (b.attr_value("image_tag_mutability") or "").strip('"')
            if mutability == "MUTABLE":
                out.append(self._f(
                    path, b.attr_line("image_tag_mutability") or b.start_line,
                    "PROOFCTL-TF-A013", "ECR mutable image tags",
                    Severity.WARNING,
                    f"ECR repository '{b.label2}' has mutable image tags — supply chain tampering possible",
                    hint='Set image_tag_mutability = "IMMUTABLE"',
                    authority="CIS AWS Benchmark – ECR",
                    docs_url="https://www.cisecurity.org/benchmark/amazon_web_services",
                ))
            # Check scan_on_push — look for explicit false or absence in body
            has_scan_block = b.contains(r'image_scanning_configuration')
            scan_disabled = b.contains(r'scan_on_push\s*=\s*false')
            if scan_disabled or not has_scan_block:
                out.append(self._f(
                    path, b.any_line_matches(r'scan_on_push\s*=\s*false') or b.start_line,
                    "PROOFCTL-TF-A013", "ECR scan_on_push disabled",
                    Severity.WARNING,
                    f"ECR repository '{b.label2}' has scan_on_push disabled — vulnerabilities not detected on push",
                    hint='Add image_scanning_configuration { scan_on_push = true }',
                    authority="CIS AWS Benchmark – ECR",
                    docs_url="https://www.cisecurity.org/benchmark/amazon_web_services",
                ))
        return out

    def _a014(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-014 — Lambda function with hardcoded secret in environment variables."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_lambda_function":
                continue
            if not (b.contains(r'environment') and b.contains(r'variables')):
                continue
            # Scan lines inside the block for secret key patterns
            in_env = False
            env_depth = 0
            for i, line in enumerate(b.raw_lines):
                if not in_env and re.search(r'\benvironment\s*\{', line):
                    in_env = True
                    env_depth = 1
                    continue
                if in_env:
                    env_depth += line.count('{') - line.count('}')
                    if _SECRET_ATTR_PAT.match(line):
                        out.append(self._f(
                            path, b.start_line + i,
                            "PROOFCTL-TF-A014", "Lambda hardcoded secret in env var",
                            Severity.ERROR,
                            f"Lambda function '{b.label2}' has a hardcoded secret in environment variables",
                            hint="Store secrets in AWS Secrets Manager or SSM Parameter Store and retrieve at runtime.",
                            authority="OWASP A02:2021 – Cryptographic Failures / CWE-312",
                            docs_url="https://owasp.org/Top10/A02_2021-Cryptographic_Failures/",
                        ))
                        break
                    if env_depth <= 0:
                        in_env = False
        return out

    def _a015(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-015 — AWS KMS key without enable_key_rotation = true."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_kms_key":
                continue
            val = (b.attr_value("enable_key_rotation") or "").strip().lower()
            if val != "true":
                out.append(self._f(
                    path, b.attr_line("enable_key_rotation") or b.start_line,
                    "PROOFCTL-TF-A015", "AWS KMS key rotation not enabled",
                    Severity.WARNING,
                    f'aws_kms_key "{b.label2}" has no enable_key_rotation = true — keys never rotate',
                    hint="Set enable_key_rotation = true to opt into yearly automatic rotation.",
                    authority="CIS AWS Benchmark 3.8",
                    docs_url="https://docs.aws.amazon.com/kms/latest/developerguide/rotate-keys.html",
                ))
        return out

    _AWS_IAM_POLICY_RESOURCES = frozenset({
        "aws_iam_policy", "aws_iam_user_policy", "aws_iam_role_policy",
        "aws_iam_group_policy",
    })
    _IAM_WILDCARD_RESOURCE = re.compile(r'"Resource"\s*:\s*"\*"')
    _IAM_WILDCARD_ACTION_LIST = re.compile(r'"Action"\s*:\s*\[\s*"\*"\s*\]')
    _IAM_WILDCARD_ACTION_STR = re.compile(r'"Action"\s*:\s*"\*"')
    _IAM_SERVICE_WILDCARD = re.compile(r'"\w+:\*"')

    def _a016(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-016 — AWS IAM policy with wildcard Resource or Action."""
        out = []
        for b in blocks:
            if b.kind == "resource" and b.label1 in self._AWS_IAM_POLICY_RESOURCES:
                body = "\n".join(b.raw_lines)
                wildcard_resource = bool(self._IAM_WILDCARD_RESOURCE.search(body))
                wildcard_action = bool(
                    self._IAM_WILDCARD_ACTION_LIST.search(body)
                    or self._IAM_WILDCARD_ACTION_STR.search(body)
                )
                if not (wildcard_resource or wildcard_action):
                    continue
                problems = []
                if wildcard_resource:
                    problems.append('Resource = "*"')
                if wildcard_action:
                    problems.append('Action = "*"')
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-A016", "IAM policy uses wildcard Action or Resource",
                    Severity.ERROR,
                    f'{b.label1} "{b.label2}" grants {" + ".join(problems)} — violates least privilege',
                    hint="Scope Action and Resource to specific ARNs and permissions actually needed.",
                    authority="AWS IAM least-privilege / CIS AWS Benchmark 1.16",
                    docs_url="https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html",
                ))
            elif b.kind == "data" and b.label1 == "aws_iam_policy_document":
                # Scan each nested statement for wildcard actions/resources with Allow
                for stmt in b.nested("statement"):
                    effect = (stmt.attr_value("effect") or '"Allow"').strip('"')
                    if effect.lower() == "deny":
                        continue
                    has_wc_action = stmt.contains(r'\bactions\s*=\s*\[\s*"\*"\s*\]')
                    has_wc_resource = stmt.contains(r'\bresources\s*=\s*\[\s*"\*"\s*\]')
                    if not (has_wc_action or has_wc_resource):
                        continue
                    problems = []
                    if has_wc_resource:
                        problems.append('resources = ["*"]')
                    if has_wc_action:
                        problems.append('actions = ["*"]')
                    out.append(self._f(
                        path, stmt.start_line,
                        "PROOFCTL-TF-A016", "IAM policy uses wildcard Action or Resource",
                        Severity.ERROR,
                        f'data aws_iam_policy_document "{b.label2}" statement grants {" + ".join(problems)} — violates least privilege',
                        hint="Scope actions and resources to specific ARNs and permissions actually needed.",
                        authority="AWS IAM least-privilege / CIS AWS Benchmark 1.16",
                        docs_url="https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html",
                    ))
        return out

    _RDS_RESOURCES = frozenset({"aws_db_instance", "aws_rds_cluster"})
    _RDS_RESOURCES_ALL = frozenset({"aws_db_instance", "aws_rds_cluster", "aws_rds_cluster_instance"})

    def _a017(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-017 — RDS/Aurora storage_encrypted not true."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in self._RDS_RESOURCES:
                continue
            val = (b.attr_value("storage_encrypted") or "").strip().lower()
            if val != "true":
                out.append(self._f(
                    path, b.attr_line("storage_encrypted") or b.start_line,
                    "PROOFCTL-TF-A017", "RDS storage not encrypted",
                    Severity.ERROR,
                    f'{b.label1} "{b.label2}" has storage_encrypted not set to true — data at rest is unencrypted',
                    hint="Set storage_encrypted = true.",
                    authority="CIS AWS Benchmark 2.3.1",
                    docs_url="https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/Overview.Encryption.html",
                ))
        return out

    def _a018(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-018 — RDS/Aurora using default KMS key (no kms_key_id)."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in self._RDS_RESOURCES:
                continue
            enc = (b.attr_value("storage_encrypted") or "").strip().lower()
            if enc == "false":
                continue  # A017 covers this — avoid duplicate
            if not b.has_attr("kms_key_id"):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-A018", "RDS using default KMS key",
                    Severity.WARNING,
                    f'{b.label1} "{b.label2}" has no kms_key_id — uses default RDS KMS key',
                    hint="Set kms_key_id to a customer-managed KMS key for tighter access control.",
                    authority="CIS AWS Benchmark 2.3.1",
                    docs_url="https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/Overview.Encryption.html",
                ))
        return out

    def _a019(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-019 — RDS instance without IAM database authentication."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_db_instance":
                continue
            val = (b.attr_value("iam_database_authentication_enabled") or "").strip().lower()
            if val != "true":
                out.append(self._f(
                    path, b.attr_line("iam_database_authentication_enabled") or b.start_line,
                    "PROOFCTL-TF-A019", "RDS IAM auth not enabled",
                    Severity.WARNING,
                    f'aws_db_instance "{b.label2}" has iam_database_authentication_enabled not set to true',
                    hint="Set iam_database_authentication_enabled = true to use IAM tokens instead of static passwords.",
                    authority="CIS AWS Benchmark 2.3.4",
                    docs_url="https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/UsingWithRDS.IAMDBAuth.html",
                ))
        return out

    def _a020(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-020 — RDS/Aurora deletion_protection not enabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in self._RDS_RESOURCES:
                continue
            val = (b.attr_value("deletion_protection") or "").strip().lower()
            if val != "true":
                out.append(self._f(
                    path, b.attr_line("deletion_protection") or b.start_line,
                    "PROOFCTL-TF-A020", "RDS deletion protection disabled",
                    Severity.WARNING,
                    f'{b.label1} "{b.label2}" has deletion_protection not set to true — accidental deletes possible',
                    hint="Set deletion_protection = true.",
                    authority="CIS AWS Benchmark 2.3.5",
                    docs_url="https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_DeleteInstance.html",
                ))
        return out

    def _a021(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-021 — RDS/Aurora backup_retention_period missing or zero."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in self._RDS_RESOURCES:
                continue
            val = b.attr_value("backup_retention_period")
            if val is None:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-A021", "RDS backup retention not set",
                    Severity.WARNING,
                    f'{b.label1} "{b.label2}" has no backup_retention_period — automated backups not retained',
                    hint="Set backup_retention_period to at least 7 (days).",
                    authority="CIS AWS Benchmark 2.3.2",
                    docs_url="https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_WorkingWithAutomatedBackups.html",
                ))
                continue
            stripped = val.strip().strip('"')
            if stripped == "0":
                out.append(self._f(
                    path, b.attr_line("backup_retention_period") or b.start_line,
                    "PROOFCTL-TF-A021", "RDS backup retention zero",
                    Severity.WARNING,
                    f'{b.label1} "{b.label2}" has backup_retention_period = 0 — automated backups disabled',
                    hint="Set backup_retention_period to at least 7 (days).",
                    authority="CIS AWS Benchmark 2.3.2",
                    docs_url="https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_WorkingWithAutomatedBackups.html",
                ))
        return out

    def _a022(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-022 — RDS instance publicly_accessible = true."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_db_instance":
                continue
            val = (b.attr_value("publicly_accessible") or "").strip().lower()
            if val == "true":
                out.append(self._f(
                    path, b.attr_line("publicly_accessible") or b.start_line,
                    "PROOFCTL-TF-A022", "RDS publicly accessible",
                    Severity.ERROR,
                    f'aws_db_instance "{b.label2}" has publicly_accessible = true — DB exposed to internet',
                    hint="Set publicly_accessible = false and use private subnets / VPC peering.",
                    authority="CIS AWS Benchmark 2.3.3",
                    docs_url="https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_VPC.WorkingWithRDSInstanceinaVPC.html",
                ))
        return out

    def _a023(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-023 — Aurora cluster without enabled_cloudwatch_logs_exports."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_rds_cluster":
                continue
            if not b.has_attr("enabled_cloudwatch_logs_exports"):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-A023", "Aurora cluster audit logs not exported",
                    Severity.INFO,
                    f'aws_rds_cluster "{b.label2}" has no enabled_cloudwatch_logs_exports — audit/error logs not shipped to CloudWatch',
                    hint='Set enabled_cloudwatch_logs_exports = ["audit", "error", "general", "slowquery"] (engine-dependent).',
                    authority="CIS AWS Benchmark 2.3.6",
                    docs_url="https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/USER_LogAccess.html",
                ))
        return out

    # ════════════════════════════════════════════════════════════════════════
    # ── Azure rules (TF-AZ-*) ────────────────────────────────────────────
    # ════════════════════════════════════════════════════════════════════════

    def _az001(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-001 — Storage account allows public blob access."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "azurerm_storage_account":
                continue
            val = b.attr_value("allow_blob_public_access")
            if val is not None and val.strip('"') == "true":
                out.append(self._f(
                    path, b.attr_line("allow_blob_public_access") or b.start_line,
                    "PROOFCTL-TF-AZ001", "Storage account allows public blob access",
                    Severity.ERROR,
                    f"Storage account '{b.label2}' allows public blob access — data exposure risk",
                    hint="Set allow_blob_public_access = false",
                    authority="CIS Azure Benchmark 3.5",
                    docs_url="https://www.cisecurity.org/benchmark/azure",
                ))
        return out

    def _az002(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-002 — Storage account missing network_rules with default_action = Deny."""
        _deny_pat = re.compile(r'default_action\s*=\s*"Deny"')
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "azurerm_storage_account":
                continue
            body = "\n".join(b.raw_lines)
            has_network_rules = bool(re.search(r'network_rules\s*\{', body))
            has_deny = bool(_deny_pat.search(body))
            if not has_network_rules or not has_deny:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-AZ002", "Storage account network rules not restrictive",
                    Severity.WARNING,
                    f'Storage account \'{b.label2}\' has no network_rules default_action = Deny — accessible from all networks',
                    hint='Add network_rules { default_action = "Deny" ip_rules = [...] }',
                    authority="CIS Azure Benchmark 3.7",
                    docs_url="https://www.cisecurity.org/benchmark/azure",
                ))
        return out

    def _az003(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-003 — SQL Server with public network access enabled."""
        _sql_types = frozenset({"azurerm_mssql_server", "azurerm_sql_server"})
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in _sql_types:
                continue
            val = b.attr_value("public_network_access_enabled")
            if val is not None and val.strip('"') == "true":
                out.append(self._f(
                    path, b.attr_line("public_network_access_enabled") or b.start_line,
                    "PROOFCTL-TF-AZ003", "SQL Server public network access enabled",
                    Severity.ERROR,
                    f"SQL Server '{b.label2}' has public network access enabled",
                    hint="Set public_network_access_enabled = false and use private endpoint.",
                    authority="CIS Azure Benchmark 4.3",
                    docs_url="https://www.cisecurity.org/benchmark/azure",
                ))
        return out

    def _az004(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-004 — PostgreSQL or MySQL server with SSL enforcement disabled."""
        _db_types = frozenset({"azurerm_postgresql_server", "azurerm_mysql_server"})
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in _db_types:
                continue
            val = b.attr_value("ssl_enforcement_enabled")
            if val is not None and val.strip('"') == "false":
                out.append(self._f(
                    path, b.attr_line("ssl_enforcement_enabled") or b.start_line,
                    "PROOFCTL-TF-AZ004", "Database SSL enforcement disabled",
                    Severity.ERROR,
                    f"{b.label1} '{b.label2}' has SSL enforcement disabled — connections are unencrypted",
                    hint="Set ssl_enforcement_enabled = true",
                    authority="CIS Azure Benchmark 4.3.1",
                    docs_url="https://www.cisecurity.org/benchmark/azure",
                ))
        return out

    def _az005(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-005 — AKS cluster missing API server authorized IP ranges."""
        _empty_vals = frozenset({"null", "[]", ""})
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "azurerm_kubernetes_cluster":
                continue
            val = b.attr_value("api_server_authorized_ip_ranges")
            if val is None or val.strip('"').strip() in _empty_vals:
                out.append(self._f(
                    path, b.attr_line("api_server_authorized_ip_ranges") or b.start_line,
                    "PROOFCTL-TF-AZ005", "AKS API server has no IP restrictions",
                    Severity.ERROR,
                    f"AKS cluster '{b.label2}' has no API server IP restrictions — control plane is internet-accessible",
                    hint="Set api_server_authorized_ip_ranges to your trusted CIDR ranges.",
                    authority="CIS Azure Benchmark 8.3",
                    docs_url="https://www.cisecurity.org/benchmark/azure",
                ))
        return out

    def _az006(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-006 — AKS cluster with RBAC disabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "azurerm_kubernetes_cluster":
                continue
            val = b.attr_value("role_based_access_control_enabled")
            if val is not None and val.strip('"') == "false":
                out.append(self._f(
                    path, b.attr_line("role_based_access_control_enabled") or b.start_line,
                    "PROOFCTL-TF-AZ006", "AKS RBAC disabled",
                    Severity.ERROR,
                    f"AKS cluster '{b.label2}' has RBAC disabled — no access control on cluster resources",
                    hint="Set role_based_access_control_enabled = true (default in newer provider versions)",
                    authority="CIS Azure Benchmark 8.5",
                    docs_url="https://www.cisecurity.org/benchmark/azure",
                ))
        return out

    def _az007(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-007 — Key Vault without purge protection enabled."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "azurerm_key_vault":
                continue
            val = b.attr_value("purge_protection_enabled")
            # Flag if absent or explicitly false
            if val is None or val.strip('"') == "false":
                out.append(self._f(
                    path, b.attr_line("purge_protection_enabled") or b.start_line,
                    "PROOFCTL-TF-AZ007", "Key Vault purge protection disabled",
                    Severity.ERROR,
                    f"Key Vault '{b.label2}' has purge protection disabled — secrets can be permanently deleted immediately",
                    hint="Set purge_protection_enabled = true and soft_delete_retention_days >= 7",
                    authority="CIS Azure Benchmark 8.6",
                    docs_url="https://www.cisecurity.org/benchmark/azure",
                ))
        return out

    def _az008(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-008 — Key Vault key missing expiration_date."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "azurerm_key_vault_key":
                continue
            if not b.has_attr("expiration_date"):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-AZ008", "Key Vault key has no expiration date",
                    Severity.WARNING,
                    f"Key Vault key '{b.label2}' has no expiration date — key never rotates automatically",
                    hint="Set expiration_date to enforce key rotation policy.",
                    authority="CIS Azure Benchmark 8.3 – Key rotation",
                    docs_url="https://www.cisecurity.org/benchmark/azure",
                ))
        return out

    def _az009(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-009 — Monitor log profile retains logs for less than 90 days."""
        _days_pat = re.compile(r'days\s*=\s*(\d+)')
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "azurerm_monitor_log_profile":
                continue
            body = "\n".join(b.raw_lines)
            m = _days_pat.search(body)
            if m:
                days = int(m.group(1))
                if days < 90:
                    lineno = b.any_line_matches(r'days\s*=\s*\d+')
                    out.append(self._f(
                        path, lineno or b.start_line,
                        "PROOFCTL-TF-AZ009", "Log profile retention too short",
                        Severity.WARNING,
                        f"Log profile '{b.label2}' retains logs for only {days} days — minimum 90 days recommended",
                        hint="Set retention_policy { enabled = true days = 365 }",
                        authority="CIS Azure Benchmark 5.1.2",
                        docs_url="https://www.cisecurity.org/benchmark/azure",
                    ))
        return out

    def _az010(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-010 — Overly broad Azure role assignment or wildcard role definition."""
        _broad_roles = frozenset({"Owner", "Contributor", "User Access Administrator"})
        out = []
        for b in blocks:
            if b.kind != "resource":
                continue
            if b.label1 == "azurerm_role_assignment":
                role = (b.attr_value("role_definition_name") or "").strip('"')
                scope = (b.attr_value("scope") or "").strip('"')
                # Subscription scope: contains /subscriptions/ but not /resourceGroups/
                is_sub_scope = (
                    "/subscriptions/" in scope
                    and "/resourceGroups/" not in scope
                    and "/resourcegroups/" not in scope.lower()
                )
                if role in _broad_roles and is_sub_scope:
                    out.append(self._f(
                        path, b.attr_line("role_definition_name") or b.start_line,
                        "PROOFCTL-TF-AZ010", "Overly broad Azure role assignment",
                        Severity.WARNING,
                        f"Role '{b.label2}' grants '{role}' at subscription scope — overly broad permissions",
                        hint="Scope role assignments to resource groups or individual resources.",
                        authority="CIS Azure Benchmark 1.23 – Limit role assignments",
                        docs_url="https://www.cisecurity.org/benchmark/azure",
                    ))
            elif b.label1 == "azurerm_role_definition":
                # Flag if actions contains "*"
                if b.contains(r'"[*]"') or b.contains(r'\[\s*"\*"\s*\]') or b.contains(r'actions\s*=\s*\[[^\]]*"\*"'):
                    out.append(self._f(
                        path, b.any_line_matches(r'actions\s*=') or b.start_line,
                        "PROOFCTL-TF-AZ010", "Azure role definition with wildcard actions",
                        Severity.ERROR,
                        f"Role definition '{b.label2}' uses wildcard '*' in actions — grants all permissions",
                        hint="Enumerate only the specific actions required instead of using '*'.",
                        authority="CIS Azure Benchmark 1.23 – Limit role assignments",
                        docs_url="https://www.cisecurity.org/benchmark/azure",
                    ))
        return out

    def _az011(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-011 — App Service allows HTTP (https_only not set to true)."""
        _app_types = frozenset({
            "azurerm_app_service",
            "azurerm_linux_web_app",
            "azurerm_windows_web_app",
        })
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in _app_types:
                continue
            val = b.attr_value("https_only")
            # Flag if absent (default false in older versions) or explicitly false
            if val is None or val.strip('"') == "false":
                out.append(self._f(
                    path, b.attr_line("https_only") or b.start_line,
                    "PROOFCTL-TF-AZ011", "App Service allows HTTP",
                    Severity.ERROR,
                    f"App Service '{b.label2}' allows HTTP — traffic is unencrypted",
                    hint="Set https_only = true",
                    authority="CIS Azure Benchmark 9.2",
                    docs_url="https://www.cisecurity.org/benchmark/azure",
                ))
        return out

    def _az012(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-012 — VM without encryption at host enabled."""
        _vm_types = frozenset({
            "azurerm_linux_virtual_machine",
            "azurerm_windows_virtual_machine",
        })
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in _vm_types:
                continue
            val = b.attr_value("encryption_at_host_enabled")
            if val is None or val.strip('"') == "false":
                out.append(self._f(
                    path, b.attr_line("encryption_at_host_enabled") or b.start_line,
                    "PROOFCTL-TF-AZ012", "VM missing encryption at host",
                    Severity.WARNING,
                    f"VM '{b.label2}' does not enforce encryption at host — host disk data may be unencrypted",
                    hint="Set encryption_at_host_enabled = true (requires subscription feature registration)",
                    authority="CIS Azure Benchmark 7.7",
                    docs_url="https://www.cisecurity.org/benchmark/azure",
                ))
        return out

    # ════════════════════════════════════════════════════════════════════════
    # Group A — AWS data-exfiltration rules (extended)
    # ════════════════════════════════════════════════════════════════════════

    _SENSITIVE_INGRESS_PORTS = frozenset({22, 23, 25, 1433, 3306, 3389, 5432, 5439, 6379, 9200, 27017})

    def _a024(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-024 — Security group ingress on sensitive ports from 0.0.0.0/0."""
        out = []
        port_re = re.compile(r'(?:from_port|to_port)\s*=\s*(\d+)')
        for b in blocks:
            if b.kind != "resource":
                continue
            if b.label1 == "aws_security_group_rule":
                if (b.attr_value("type") or "").strip('"') != "ingress":
                    continue
                if not b.contains(r'"0\.0\.0\.0/0"'):
                    continue
                fp = b.attr_value("from_port")
                tp = b.attr_value("to_port")
                try:
                    fp_i = int((fp or "").strip().strip('"'))
                    tp_i = int((tp or "").strip().strip('"'))
                except (ValueError, AttributeError):
                    fp_i = tp_i = -1
                if (fp_i == 0 and tp_i == 65535) or fp_i in self._SENSITIVE_INGRESS_PORTS:
                    out.append(self._f(
                        path, b.start_line,
                        "PROOFCTL-TF-A024", "Public ingress on sensitive port",
                        Severity.ERROR,
                        f'aws_security_group_rule "{b.label2}" allows 0.0.0.0/0 ingress on port {fp_i}',
                        hint="Restrict cidr_blocks to a known network or use a bastion / SSM Session Manager.",
                        authority="CIS AWS Benchmark 4.1/4.2",
                        docs_url="https://www.cisecurity.org/benchmark/amazon_web_services",
                    ))
            elif b.label1 == "aws_security_group":
                # Inline ingress blocks
                for ing in b.nested("ingress"):
                    if not ing.contains(r'"0\.0\.0\.0/0"'):
                        continue
                    fp = ing.attr_value("from_port")
                    tp = ing.attr_value("to_port")
                    try:
                        fp_i = int((fp or "").strip().strip('"'))
                        tp_i = int((tp or "").strip().strip('"'))
                    except (ValueError, AttributeError):
                        fp_i = tp_i = -1
                    if (fp_i == 0 and tp_i == 65535) or fp_i in self._SENSITIVE_INGRESS_PORTS:
                        out.append(self._f(
                            path, ing.start_line,
                            "PROOFCTL-TF-A024", "Public ingress on sensitive port",
                            Severity.ERROR,
                            f'aws_security_group "{b.label2}" inline ingress allows 0.0.0.0/0 on port {fp_i}',
                            hint="Restrict cidr_blocks to a known network.",
                            authority="CIS AWS Benchmark 4.1/4.2",
                            docs_url="https://www.cisecurity.org/benchmark/amazon_web_services",
                        ))
        return out

    def _a025(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-025 — EKS public endpoint with explicit 0.0.0.0/0 in public_access_cidrs."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_eks_cluster":
                continue
            if not b.contains(r'endpoint_public_access\s*=\s*true'):
                continue
            if b.contains(r'public_access_cidrs\s*=\s*\[[^\]]*"0\.0\.0\.0/0"'):
                out.append(self._f(
                    path, b.any_line_matches(r'public_access_cidrs') or b.start_line,
                    "PROOFCTL-TF-A025", "EKS public endpoint open to internet",
                    Severity.ERROR,
                    f'EKS cluster "{b.label2}" has public_access_cidrs = ["0.0.0.0/0"] — control plane open to internet',
                    hint='Restrict public_access_cidrs to your office/VPN CIDRs, or set endpoint_public_access = false.',
                    authority="CIS EKS Benchmark 5.4.2",
                    docs_url="https://www.cisecurity.org/benchmark/amazon_elastic_kubernetes_service",
                ))
        return out

    def _a027(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-027 — Neptune cluster without storage_encrypted = true."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_neptune_cluster":
                continue
            val = (b.attr_value("storage_encrypted") or "").strip().lower()
            if val != "true":
                out.append(self._f(
                    path, b.attr_line("storage_encrypted") or b.start_line,
                    "PROOFCTL-TF-A027", "Neptune storage not encrypted",
                    Severity.ERROR,
                    f'aws_neptune_cluster "{b.label2}" has storage_encrypted not set to true',
                    hint="Set storage_encrypted = true.",
                    authority="CIS AWS Benchmark 2.3.1",
                    docs_url="https://docs.aws.amazon.com/neptune/latest/userguide/encrypt.html",
                ))
        return out

    def _a029(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-029 — DynamoDB table without server_side_encryption."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_dynamodb_table":
                continue
            sse_blocks = b.nested("server_side_encryption")
            enabled = False
            for s in sse_blocks:
                if (s.attr_value("enabled") or "").strip().lower() == "true":
                    enabled = True
                    break
            if not enabled:
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-A029", "DynamoDB table without SSE",
                    Severity.WARNING,
                    f'aws_dynamodb_table "{b.label2}" has no server_side_encryption {{ enabled = true }}',
                    hint="Add server_side_encryption { enabled = true } (uses AWS-owned key by default).",
                    authority="AWS DynamoDB encryption at rest",
                    docs_url="https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/EncryptionAtRest.html",
                ))
        return out

    def _a030(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-030 — ElastiCache replication_group without at_rest_encryption_enabled = true."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_elasticache_replication_group":
                continue
            val = (b.attr_value("at_rest_encryption_enabled") or "").strip().lower()
            if val != "true":
                out.append(self._f(
                    path, b.attr_line("at_rest_encryption_enabled") or b.start_line,
                    "PROOFCTL-TF-A030", "ElastiCache at-rest encryption disabled",
                    Severity.ERROR,
                    f'aws_elasticache_replication_group "{b.label2}" has at_rest_encryption_enabled not true',
                    hint="Set at_rest_encryption_enabled = true.",
                    authority="CIS AWS Benchmark 3.7",
                    docs_url="https://docs.aws.amazon.com/AmazonElastiCache/latest/red-ug/at-rest-encryption.html",
                ))
        return out

    def _a031(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-031 — SQS queue / SNS topic without kms_master_key_id."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 not in ("aws_sqs_queue", "aws_sns_topic"):
                continue
            if not b.has_attr("kms_master_key_id"):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-A031", "SQS/SNS without KMS encryption",
                    Severity.WARNING,
                    f'{b.label1} "{b.label2}" has no kms_master_key_id — server-side encryption disabled',
                    hint='Set kms_master_key_id (e.g. "alias/aws/sqs" or a CMK ARN).',
                    authority="AWS SQS/SNS encryption at rest",
                    docs_url="https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/sqs-server-side-encryption.html",
                ))
        return out

    def _a034(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-034 — IAM policy attached directly to user (not group)."""
        out = []
        for b in blocks:
            if b.kind != "resource":
                continue
            if b.label1 in ("aws_iam_user_policy_attachment", "aws_iam_user_policy"):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-A034", "IAM policy attached directly to user",
                    Severity.WARNING,
                    f'{b.label1} "{b.label2}" attaches a policy directly to a user — prefer groups',
                    hint="Attach the policy to an IAM group and add the user to the group.",
                    authority="CIS AWS Benchmark 1.16",
                    docs_url="https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html",
                ))
        return out

    _IAM_PRINCIPAL_WILDCARD = re.compile(
        r'"Principal"\s*:\s*(?:"\*"|\{\s*"AWS"\s*:\s*"\*"\s*\})'
    )

    def _a035(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-035 — IAM role assume_role_policy with wildcard Principal."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_iam_role":
                continue
            body = "\n".join(b.raw_lines)
            if self._IAM_PRINCIPAL_WILDCARD.search(body):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-A035", "IAM role trusts wildcard Principal",
                    Severity.ERROR,
                    f'aws_iam_role "{b.label2}" assume_role_policy allows Principal "*" — any account can assume',
                    hint="Restrict Principal to a specific service or account ARN.",
                    authority="AWS IAM least-privilege",
                    docs_url="https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_elements_principal.html",
                ))
        return out

    def _a036(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-036 — CloudTrail without log file validation."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_cloudtrail":
                continue
            val = (b.attr_value("enable_log_file_validation") or "").strip().lower()
            if val != "true":
                out.append(self._f(
                    path, b.attr_line("enable_log_file_validation") or b.start_line,
                    "PROOFCTL-TF-A036", "CloudTrail log file validation disabled",
                    Severity.WARNING,
                    f'aws_cloudtrail "{b.label2}" has enable_log_file_validation not set to true',
                    hint="Set enable_log_file_validation = true to detect log tampering.",
                    authority="CIS AWS Benchmark 3.2",
                    docs_url="https://docs.aws.amazon.com/awscloudtrail/latest/userguide/cloudtrail-log-file-validation-intro.html",
                ))
        return out

    def _a037(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-037 — CloudTrail not multi-region."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_cloudtrail":
                continue
            val = (b.attr_value("is_multi_region_trail") or "").strip().lower()
            if val != "true":
                out.append(self._f(
                    path, b.attr_line("is_multi_region_trail") or b.start_line,
                    "PROOFCTL-TF-A037", "CloudTrail not multi-region",
                    Severity.WARNING,
                    f'aws_cloudtrail "{b.label2}" has is_multi_region_trail not set to true',
                    hint="Set is_multi_region_trail = true to capture events from all regions.",
                    authority="CIS AWS Benchmark 3.1",
                    docs_url="https://docs.aws.amazon.com/awscloudtrail/latest/userguide/receive-cloudtrail-log-files-from-multiple-regions.html",
                ))
        return out

    def _a039(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-039 — aws_subnet auto-assigns public IP to launched instances."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_subnet":
                continue
            val = (b.attr_value("map_public_ip_on_launch") or "").strip().lower()
            if val == "true":
                out.append(self._f(
                    path, b.attr_line("map_public_ip_on_launch") or b.start_line,
                    "PROOFCTL-TF-A039", "Subnet auto-assigns public IP",
                    Severity.WARNING,
                    f'aws_subnet "{b.label2}" has map_public_ip_on_launch = true — instances launched here get a public IP',
                    hint="Set map_public_ip_on_launch = false. Use NAT/VPC endpoints for outbound access.",
                    authority="CIS AWS Benchmark 5.5",
                    docs_url="https://docs.aws.amazon.com/vpc/latest/userguide/configure-subnets.html",
                ))
        return out

    def _a040(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-040 — aws_neptune_cluster missing kms_key_arn (CMK encryption)."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_neptune_cluster":
                continue
            encrypted = (b.attr_value("storage_encrypted") or "").strip().lower()
            if encrypted == "false":
                continue  # A027 covers unencrypted Neptune; don't dual-fire
            if not b.has_attr("kms_key_arn"):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-A040", "Neptune cluster without CMK",
                    Severity.WARNING,
                    f'aws_neptune_cluster "{b.label2}" uses default AWS-managed key (no kms_key_arn)',
                    hint='Set kms_key_arn = "arn:aws:kms:...:key/..." to use a customer-managed key.',
                    authority="CIS AWS Benchmark 2.3.2",
                ))
        return out

    def _a038(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """A-038 — Default security group with non-empty rules."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_default_security_group":
                continue
            if b.has_nested("ingress") or b.has_nested("egress"):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-A038", "Default security group with rules",
                    Severity.WARNING,
                    f'aws_default_security_group "{b.label2}" has ingress/egress rules — should be empty',
                    hint="Remove all rules from the default SG; create a separate SG for workloads.",
                    authority="CIS AWS Benchmark 4.3",
                    docs_url="https://www.cisecurity.org/benchmark/amazon_web_services",
                ))
        return out

    # ════════════════════════════════════════════════════════════════════════
    # Group G — GCP data-exfiltration rules (extended)
    # ════════════════════════════════════════════════════════════════════════

    def _g042(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-042 — google_compute_firewall allows from 0.0.0.0/0 with allow rule."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_compute_firewall":
                continue
            if not b.contains(r'source_ranges\s*=\s*\[[^\]]*"0\.0\.0\.0/0"'):
                continue
            if not b.has_nested("allow"):
                continue
            out.append(self._f(
                path, b.start_line,
                "PROOFCTL-TF-G042", "Firewall allows from public internet",
                Severity.ERROR,
                f'google_compute_firewall "{b.label2}" allows traffic from 0.0.0.0/0',
                hint="Restrict source_ranges to internal CIDRs or use IAP tunneling for admin access.",
                authority="CIS GCP Benchmark 3.6/3.7",
                docs_url="https://www.cisecurity.org/benchmark/google_cloud_computing_platform",
            ))
        return out

    def _g043(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-043 — Cloud SQL TLS not enforced (no enforcement attribute set).

        Fires when NONE of the safe enforcement attributes are present:
          - Legacy:  ``require_ssl = true``
          - Modern (provider 5.x+):  ``ssl_mode = "ENCRYPTED_ONLY"`` OR
                                     ``ssl_mode = "TRUSTED_CLIENT_CERTIFICATE_REQUIRED"``

        Without one of these, Cloud SQL accepts unencrypted connections
        by default. G-009 covers the *explicit* opt-out cases; this rule
        covers the *implicit* opt-out (omission).
        """
        out = []
        require_ssl_true = r'require_ssl\s*=\s*true'
        ssl_mode_enforced = (
            r'ssl_mode\s*=\s*"(?:ENCRYPTED_ONLY|TRUSTED_CLIENT_CERTIFICATE_REQUIRED)"'
        )
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_sql_database_instance":
                continue
            if b.contains(require_ssl_true) or b.contains(ssl_mode_enforced):
                continue
            out.append(self._f(
                path, b.start_line,
                "PROOFCTL-TF-G043", "Cloud SQL TLS not enforced",
                Severity.ERROR,
                f'google_sql_database_instance "{b.label2}" does not enforce TLS — no require_ssl = true or ssl_mode = ENCRYPTED_ONLY present',
                hint='Set settings.ip_configuration.ssl_mode = "ENCRYPTED_ONLY" (preferred; provider 5.x+) or settings.ip_configuration.require_ssl = true (legacy).',
                authority="CIS GCP Benchmark 6.4",
                docs_url="https://cloud.google.com/sql/docs/mysql/configure-ssl-instance",
            ))
        return out

    def _g044(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-044 — Cloud SQL authorized_networks contains 0.0.0.0/0."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_sql_database_instance":
                continue
            if b.contains(r'value\s*=\s*"0\.0\.0\.0/0"'):
                out.append(self._f(
                    path, b.any_line_matches(r'value\s*=\s*"0\.0\.0\.0/0"') or b.start_line,
                    "PROOFCTL-TF-G044", "Cloud SQL open to public internet",
                    Severity.ERROR,
                    f'google_sql_database_instance "{b.label2}" authorized_networks contains 0.0.0.0/0',
                    hint="Restrict authorized_networks to specific CIDRs or use private IP only.",
                    authority="CIS GCP Benchmark 6.5",
                    docs_url="https://cloud.google.com/sql/docs/mysql/configure-ip",
                ))
        return out

    def _g045(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-045 — Compute instance with can_ip_forward = true."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_compute_instance":
                continue
            if b.contains(r'can_ip_forward\s*=\s*true'):
                out.append(self._f(
                    path, b.any_line_matches(r'can_ip_forward\s*=\s*true') or b.start_line,
                    "PROOFCTL-TF-G045", "Compute instance with IP forwarding",
                    Severity.WARNING,
                    f'google_compute_instance "{b.label2}" has can_ip_forward = true — enables traffic spoofing',
                    hint="Set can_ip_forward = false unless this VM is an explicit network appliance.",
                    authority="CIS GCP Benchmark 4.6",
                    docs_url="https://cloud.google.com/vpc/docs/using-routes",
                ))
        return out

    def _g046(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-046 — Compute instance with public IP (access_config block present)."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_compute_instance":
                continue
            for ni in b.nested("network_interface"):
                if ni.has_nested("access_config"):
                    out.append(self._f(
                        path, ni.start_line,
                        "PROOFCTL-TF-G046", "Compute instance with public IP",
                        Severity.WARNING,
                        f'google_compute_instance "{b.label2}" has access_config — assigns a public IP',
                        hint="Remove access_config (or leave it empty) so the VM only gets a private IP; use IAP for SSH.",
                        authority="CIS GCP Benchmark 4.9",
                        docs_url="https://cloud.google.com/compute/docs/ip-addresses",
                    ))
                    break
        return out

    def _g047(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """G-047 — Compute instance with `cloud-platform` access scope.

        Access scopes are a coarse, IAM-bypassing layer on top of service-account
        permissions. `cloud-platform` grants the metadata server permission to
        mint tokens for every GCP API — so any role the SA ever acquires becomes
        immediately usable from the VM. Best practice: rely on IAM only, and
        narrow the scope to `cloud-platform.read-only` or use the default
        scopes set with explicit IAM roles.
        """
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_compute_instance":
                continue
            for sa in b.nested("service_account"):
                # Match "cloud-platform" exactly inside the scopes list — not
                # cloud-platform.read-only or other narrower scopes.
                if sa.contains(r'"cloud-platform"'):
                    out.append(self._f(
                        path, sa.attr_line("scopes") or sa.start_line,
                        "PROOFCTL-TF-G047", "Compute instance with cloud-platform scope",
                        Severity.WARNING,
                        f'google_compute_instance "{b.label2}" has access scope "cloud-platform" — broadest possible API access',
                        hint='Use narrower scopes (e.g. "cloud-platform.read-only") or omit and rely on IAM bindings on the service account.',
                        authority="GCP Compute Engine — Access scopes vs IAM",
                        docs_url="https://cloud.google.com/compute/docs/access/service-accounts#scopes_best_practice",
                    ))
                    break
        return out

    # ════════════════════════════════════════════════════════════════════════
    # Group AZ — Azure data-exfiltration rules (extended)
    # ════════════════════════════════════════════════════════════════════════

    _AZ_INTERNET_SOURCES = frozenset({"*", "0.0.0.0/0", "Internet"})
    _AZ_SENSITIVE_PORT_SET = frozenset({"22", "23", "1433", "3306", "3389", "5432", "5439", "6379", "9200", "27017"})

    def _az_port_matches_sensitive(self, port_range: str) -> bool:
        s = port_range.strip().strip('"')
        if s == "*":
            return True
        if s in self._AZ_SENSITIVE_PORT_SET:
            return True
        # Range like "20-25"
        if "-" in s:
            try:
                lo, hi = (int(p) for p in s.split("-", 1))
                for sp in self._AZ_SENSITIVE_PORT_SET:
                    spi = int(sp)
                    if lo <= spi <= hi:
                        return True
            except ValueError:
                return False
        return False

    def _az013_check_rule(self, b: HclBlock) -> bool:
        """True if NSG rule allows internet inbound on a sensitive port."""
        direction = (b.attr_value("direction") or "").strip().strip('"')
        access = (b.attr_value("access") or "").strip().strip('"')
        if direction != "Inbound" or access != "Allow":
            return False
        src = (b.attr_value("source_address_prefix") or "").strip().strip('"')
        srcs_raw = "\n".join(line for line in b.raw_lines if "source_address_prefixes" in line)
        src_match = src in self._AZ_INTERNET_SOURCES or any(
            s in srcs_raw for s in ('"*"', '"0.0.0.0/0"', '"Internet"')
        )
        if not src_match:
            return False
        port_range = (b.attr_value("destination_port_range") or "").strip().strip('"')
        if port_range and self._az_port_matches_sensitive(port_range):
            return True
        # destination_port_ranges = ["22", "3389"]
        for line in b.raw_lines:
            if "destination_port_ranges" in line:
                for p in self._AZ_SENSITIVE_PORT_SET:
                    if f'"{p}"' in line:
                        return True
                if '"*"' in line:
                    return True
        return False

    def _az013(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-013 — NSG rule allows SSH/RDP/sensitive ports from internet."""
        out = []
        for b in blocks:
            if b.kind != "resource":
                continue
            if b.label1 == "azurerm_network_security_rule":
                if self._az013_check_rule(b):
                    out.append(self._f(
                        path, b.start_line,
                        "PROOFCTL-TF-AZ013", "NSG rule allows internet on sensitive port",
                        Severity.ERROR,
                        f'azurerm_network_security_rule "{b.label2}" allows inbound from internet on sensitive port',
                        hint="Restrict source_address_prefix to a known CIDR; do not use '*' or 'Internet'.",
                        authority="CIS Azure Benchmark 6.1/6.2",
                        docs_url="https://www.cisecurity.org/benchmark/azure",
                    ))
            elif b.label1 == "azurerm_network_security_group":
                for sr in b.nested("security_rule"):
                    if self._az013_check_rule(sr):
                        out.append(self._f(
                            path, sr.start_line,
                            "PROOFCTL-TF-AZ013", "NSG rule allows internet on sensitive port",
                            Severity.ERROR,
                            f'azurerm_network_security_group "{b.label2}" inline rule allows inbound from internet on sensitive port',
                            hint="Restrict source_address_prefix to a known CIDR; do not use '*' or 'Internet'.",
                            authority="CIS Azure Benchmark 6.1/6.2",
                            docs_url="https://www.cisecurity.org/benchmark/azure",
                        ))
        return out

    def _az014(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AZ-014 — Managed disk without disk_encryption_set_id or encryption_settings."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "azurerm_managed_disk":
                continue
            if b.has_attr("disk_encryption_set_id"):
                continue
            has_enc_settings = False
            for es in b.nested("encryption_settings"):
                if (es.attr_value("enabled") or "").strip().lower() == "true":
                    has_enc_settings = True
                    break
            if has_enc_settings:
                continue
            out.append(self._f(
                path, b.start_line,
                "PROOFCTL-TF-AZ014", "Managed disk without CMK encryption",
                Severity.WARNING,
                f'azurerm_managed_disk "{b.label2}" has no disk_encryption_set_id or encryption_settings — uses platform key',
                hint="Set disk_encryption_set_id pointing at a customer-managed key.",
                authority="CIS Azure Benchmark 7.2",
                docs_url="https://learn.microsoft.com/en-us/azure/virtual-machines/disk-encryption",
            ))
        return out

    def _t014(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """T-014 has moved to TerraformDirChecker — required_version is a per-module property."""
        return []

    def _t015(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """T-015 — Output with sensitive-looking name but sensitive = true not set."""
        # "key" is excluded when followed by measurement/metadata suffixes
        # (e.g. max_key_age_days, key_count, key_rotation_period) — those are
        # not sensitive values, just numeric descriptors that happen to contain
        # the word "key".  Other terms (password, secret, token, credential)
        # are always sensitive regardless of suffix.
        _sensitive_name_pat = re.compile(
            r'(?:password|secret|token|credential'
            r'|key(?!_age|_days|_hours|_seconds|_count|_max|_min|_num'
            r'|_threshold|_expir|_rotation|_version|_size|_length))',
            re.IGNORECASE,
        )
        out = []
        for b in blocks:
            if b.kind != "output":
                continue
            if not _sensitive_name_pat.search(b.label1):
                continue
            val = b.attr_value("sensitive")
            if val is None or val.strip('"') == "false":
                out.append(self._f(
                    path, b.attr_line("sensitive") or b.start_line,
                    "PROOFCTL-TF-T015", "Sensitive output missing sensitive = true",
                    Severity.WARNING,
                    f"Output '{b.label1}' appears to contain sensitive data but sensitive = true is not set — value appears in plan output and state",
                    hint="Add sensitive = true to the output block.",
                    authority="Terraform Security – Sensitive Outputs",
                    docs_url="https://developer.hashicorp.com/terraform/language/values/outputs#sensitive-suppressing-values-in-cli-output",
                ))
        return out

    # ── AI-slop detection methods ─────────────────────────────────────────────

    def _ai001(self, path: Path, lines: list[str]) -> list[Finding]:
        """AI-001 — Placeholder string values in Terraform config.

        Skips matches that fall inside comments (`#` or `//`) so reference/test
        files documenting *what* slop looks like don't false-positive on their
        own meta-descriptions. Also skips ``description = "..."`` attribute
        values — these are documentation, not values that flow into Terraform
        plan/apply.
        """
        out = []
        source = "\n".join(lines)
        from .hcl_utils import _strip_comment
        _description_attr_re = re.compile(r'^\s*description\s*=\s*"')
        seen: set[int] = set()
        for pattern in (_AI_PLACEHOLDER_VALUE_RE, _AI_ANGLE_BRACKET_RE):
            for m in pattern.finditer(source):
                lineno = source[: m.start()].count("\n") + 1
                if lineno in seen:
                    continue
                full_line = lines[lineno - 1] if lineno <= len(lines) else ""
                line_start = source.rfind("\n", 0, m.start()) + 1
                col = m.start() - line_start
                if col >= len(_strip_comment(full_line)):
                    continue  # match is inside a comment portion
                if _description_attr_re.match(full_line):
                    continue  # match is inside a description = "..." doc field
                seen.add(lineno)
                snippet = lines[lineno - 1].strip()[:60]
                out.append(self._f(
                    path, lineno,
                    "PROOFCTL-TF-AI-001", "Placeholder value in Terraform config",
                    Severity.ERROR,
                    f"Unfilled AI-generated placeholder: {snippet}",
                    hint="Replace with a Terraform variable reference (var.x) or a data source lookup.",
                    authority="HashiCorp Terraform – Input Variables",
                    docs_url="https://developer.hashicorp.com/terraform/language/values/variables",
                ))
        return out

    def _ai002(self, path: Path, lines: list[str], blocks: list[HclBlock]) -> list[Finding]:
        """AI-002 — AWS region format in a GCP-context file.

        Ignores matches that fall on comment lines (``#`` or ``//``) so legitimate
        migration notes like ``# was us-east-1, now us-east1`` don't false-positive.
        """
        source = "\n".join(lines)
        if not _GCP_RESOURCE_RE.search(source):
            return []
        out = []
        from .hcl_utils import _strip_comment
        for m in _AWS_REGION_RE.finditer(source):
            lineno = source[: m.start()].count("\n") + 1
            full_line = lines[lineno - 1] if lineno <= len(lines) else ""
            # Compute the column where the match starts within the line.
            line_start = source.rfind("\n", 0, m.start()) + 1
            col = m.start() - line_start
            # If the match falls inside a comment portion of the line, skip it.
            non_comment = _strip_comment(full_line)
            if col >= len(non_comment):
                continue
            out.append(self._f(
                path, lineno,
                "PROOFCTL-TF-AI-002", "AWS region format in GCP context",
                Severity.ERROR,
                f"AWS region format '{m.group(1)}' used in a GCP Terraform file — AI cross-cloud confusion",
                hint="GCP regions use format: us-central1, europe-west1, asia-east1 (no trailing digit dash).",
                authority="Google Cloud – Regions and Zones",
                docs_url="https://cloud.google.com/compute/docs/regions-zones",
            ))
        return out

    def _ai003(self, path: Path, lines: list[str], blocks: list[HclBlock]) -> list[Finding]:
        """AI-003 — Deprecated inline attributes in aws_s3_bucket (removed aws provider v4)."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "aws_s3_bucket":
                continue
            block_src = "\n".join(b.raw_lines)
            if _S3_INLINE_ACL_RE.search(block_src):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-AI-003", "Deprecated inline S3 ACL",
                    Severity.ERROR,
                    f"aws_s3_bucket '{b.label2}' uses inline 'acl' argument — removed in AWS provider v4",
                    hint="Move to a separate aws_s3_bucket_acl resource.",
                    authority="AWS Provider v4 – S3 Resource Splitting",
                    docs_url="https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_acl",
                ))
            if _S3_INLINE_VERSIONING_RE.search(block_src):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-AI-003", "Deprecated inline S3 versioning",
                    Severity.ERROR,
                    f"aws_s3_bucket '{b.label2}' uses inline 'versioning' block — removed in AWS provider v4",
                    hint="Move to a separate aws_s3_bucket_versioning resource.",
                    authority="AWS Provider v4 – S3 Resource Splitting",
                    docs_url="https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_versioning",
                ))
            if _S3_INLINE_LIFECYCLE_RE.search(block_src):
                out.append(self._f(
                    path, b.start_line,
                    "PROOFCTL-TF-AI-003", "Deprecated inline S3 lifecycle_rule",
                    Severity.ERROR,
                    f"aws_s3_bucket '{b.label2}' uses inline 'lifecycle_rule' block — removed in AWS provider v4",
                    hint="Move to a separate aws_s3_bucket_lifecycle_configuration resource.",
                    authority="AWS Provider v4 – S3 Resource Splitting",
                    docs_url="https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_lifecycle_configuration",
                ))
        return out

    def _ai004(self, path: Path, lines: list[str], blocks: list[HclBlock]) -> list[Finding]:
        """AI-004 — Deprecated aws_s3_bucket_object resource (renamed to aws_s3_object)."""
        out = []
        source = "\n".join(lines)
        for m in _AWS_S3_OBJECT_DEPRECATED_RE.finditer(source):
            lineno = source[: m.start()].count("\n") + 1
            out.append(self._f(
                path, lineno,
                "PROOFCTL-TF-AI-004", "Deprecated aws_s3_bucket_object resource",
                Severity.WARNING,
                "aws_s3_bucket_object was renamed to aws_s3_object — AI trained on pre-rename docs",
                hint='Replace with resource "aws_s3_object".',
                authority="AWS Provider – aws_s3_object",
                docs_url="https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_object",
            ))
        return out

    def _ai005(self, path: Path, lines: list[str]) -> list[Finding]:
        """AI-005 — google_project.x.id should be .project_id for most GCP resources."""
        out = []
        source = "\n".join(lines)
        for m in _GCP_PROJECT_ID_WRONG_RE.finditer(source):
            lineno = source[: m.start()].count("\n") + 1
            out.append(self._f(
                path, lineno,
                "PROOFCTL-TF-AI-005", "google_project.id vs .project_id confusion",
                Severity.WARNING,
                f"'{m.group(0)}' returns 'projects/ID' (full path) — most GCP resources require bare project_id",
                hint="Use .project_id instead of .id for bare project ID string arguments.",
                authority="GCP Terraform Provider – Issue #11541",
                docs_url="https://github.com/hashicorp/terraform-provider-google/issues/11541",
            ))
        return out

    def _ai006(self, path: Path, lines: list[str]) -> list[Finding]:
        """AI-006 — Deprecated google_ml_engine_* resources (product shut down 2024)."""
        out = []
        source = "\n".join(lines)
        for m in _GCP_ML_ENGINE_RE.finditer(source):
            lineno = source[: m.start()].count("\n") + 1
            out.append(self._f(
                path, lineno,
                "PROOFCTL-TF-AI-006", "Deprecated google_ml_engine resource",
                Severity.ERROR,
                f"'{m.group(0)}' — ML Engine was shut down in 2024 and replaced by Vertex AI",
                hint="Migrate to google_vertex_ai_* resources.",
                authority="Google Cloud – Vertex AI Terraform",
                docs_url="https://cloud.google.com/vertex-ai/docs/start/use-terraform-vertex-ai",
            ))
        return out

    def _ai007(self, path: Path, lines: list[str]) -> list[Finding]:
        """AI-007 — null_resource with local-exec (deprecated, use terraform_data)."""
        out = []
        source = "\n".join(lines)
        for m in _NULL_RESOURCE_LOCAL_EXEC_RE.finditer(source):
            lineno = source[: m.start()].count("\n") + 1
            out.append(self._f(
                path, lineno,
                "PROOFCTL-TF-AI-007", "Deprecated null_resource with local-exec",
                Severity.WARNING,
                "null_resource is deprecated (Terraform 1.4+) and often signals AI using an escape hatch",
                hint="Replace with terraform_data for Terraform ≥1.4. Consider whether a proper provider resource exists.",
                authority="Terraform – terraform_data resource",
                docs_url="https://developer.hashicorp.com/terraform/language/resources/terraform-data",
            ))
        return out

    def _ai008(self, path: Path, lines: list[str]) -> list[Finding]:
        """AI-008 — Heredoc JSON IAM policy (use aws_iam_policy_document instead)."""
        out = []
        source = "\n".join(lines)
        for m in _HEREDOC_IAM_RE.finditer(source):
            lineno = source[: m.start()].count("\n") + 1
            out.append(self._f(
                path, lineno,
                "PROOFCTL-TF-AI-008", "Heredoc JSON IAM policy",
                Severity.WARNING,
                "IAM policy written as heredoc JSON — AI generates this; use aws_iam_policy_document for plan-time validation",
                hint="Replace with data \"aws_iam_policy_document\" or jsonencode() function.",
                authority="AWS Provider – aws_iam_policy_document",
                docs_url="https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document",
            ))
        return out

    def _ai009(self, path: Path, lines: list[str]) -> list[Finding]:
        """AI-009 — count = length() antipattern (use for_each)."""
        out = []
        source = "\n".join(lines)
        for m in _COUNT_LENGTH_RE.finditer(source):
            lineno = source[: m.start()].count("\n") + 1
            out.append(self._f(
                path, lineno,
                "PROOFCTL-TF-AI-009", "count = length() antipattern",
                Severity.INFO,
                "count = length(var.list) causes resource destruction on list reordering — AI default antipattern",
                hint="Use for_each = toset(var.list) to maintain stable resource identity.",
                authority="Terraform – for_each meta-argument",
                docs_url="https://developer.hashicorp.com/terraform/language/meta-arguments/for_each",
            ))
        return out

    def _ai010(self, path: Path, lines: list[str]) -> list[Finding]:
        """AI-010 — Deprecated azurerm enable_https_traffic_only attribute."""
        out = []
        source = "\n".join(lines)
        for m in _AZURERM_HTTPS_OLD_RE.finditer(source):
            lineno = source[: m.start()].count("\n") + 1
            out.append(self._f(
                path, lineno,
                "PROOFCTL-TF-AI-010", "Deprecated azurerm enable_https_traffic_only",
                Severity.WARNING,
                "enable_https_traffic_only was renamed to https_traffic_only_enabled in AzureRM v3.114",
                hint="Replace with https_traffic_only_enabled = true.",
                authority="AzureRM Provider – storage account deprecation",
                docs_url="https://github.com/hashicorp/terraform-provider-azurerm/issues/28188",
            ))
        return out

    def _ai011(self, path: Path, lines: list[str]) -> list[Finding]:
        """AI-011 — TODO/FIXME comment in Terraform HCL."""
        out = []
        source = "\n".join(lines)
        for m in _TODO_COMMENT_RE.finditer(source):
            lineno = source[: m.start()].count("\n") + 1
            snippet = lines[lineno - 1].strip()[:60]
            out.append(self._f(
                path, lineno,
                "PROOFCTL-TF-AI-011", "TODO sentinel in Terraform",
                Severity.WARNING,
                f"Unresolved TODO/FIXME in infrastructure config: {snippet}",
                hint="Resolve all TODO comments before committing — these indicate incomplete AI-generated config.",
                authority="The Pragmatic Programmer – No Broken Windows",
                docs_url="https://pragprog.com/titles/tpp20/the-pragmatic-programmer-20th-anniversary-edition/",
            ))
        return out

    # GCE boot disk that references an image *family* rather than a specific
    # image is the GCP equivalent of `:latest` — Google promotes new images
    # into a family on its own schedule. Any apply that triggers VM rebuild
    # picks up whatever's current that day. Sneaky drift / surprise OS upgrade
    # vector that AI tools default to because the canonical examples use it.
    _IMAGE_FAMILY_RE = re.compile(
        r'image\s*=\s*"[^"]*?/images/family/[^"]+"',
    )

    def _ai012(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AI-012 — GCE boot disk references an image *family* (mutable)."""
        out = []
        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_compute_instance":
                continue
            for bd in b.nested("boot_disk"):
                # `image` can live either directly on boot_disk or inside
                # the nested initialize_params block.
                targets = [bd] + bd.nested("initialize_params")
                for t in targets:
                    line = t.any_line_matches(self._IMAGE_FAMILY_RE.pattern)
                    if line is not None:
                        out.append(self._f(
                            path, line,
                            "PROOFCTL-TF-AI-012",
                            "GCE boot disk uses image family (mutable)",
                            Severity.WARNING,
                            f'google_compute_instance "{b.label2}" references an image family — Google promotes new images into the family at any time',
                            hint="Pin to a specific image name (e.g. ubuntu-2404-amd64-20251101) or set lifecycle { ignore_changes = [boot_disk[0].initialize_params[0].image] } to opt out of rebuilds.",
                            authority="GCP Compute Engine — Image families",
                            docs_url="https://cloud.google.com/compute/docs/images/image-families-best-practices",
                        ))
                        break  # one finding per boot_disk is enough
        return out

    # Variables likely to hold credential material — used by AI-013 to decide
    # which `var.X` references are dangerous to embed in compute metadata.
    # Aligns with the SECRET-007 name set so engineers don't have to learn
    # two parallel taxonomies.
    _SENSITIVE_VAR_NAME_RE = re.compile(
        r"\bvar\.((?:[a-zA-Z0-9_]*_)?"
        r"(?:password|passwd|pwd|secret|token|api[_-]?key|access[_-]?key|"
        r"private[_-]?key|client[_-]?secret|encryption[_-]?key|auth[_-]?token|"
        r"bearer[_-]?token|jwt|credential|tunnel[_-]?token)"
        r"[a-zA-Z0-9_]*)\b",
        re.IGNORECASE,
    )

    # Suffixes that mark a variable name as a reference identifier rather
    # than the secret value itself. ``var.db_password_secret_id`` is the
    # *name* of a Secret Manager secret (fetched at runtime via gcloud)
    # — not the password value — so embedding it in metadata is safe.
    # AI-013 must NOT fire on names matching these suffixes.
    _ID_SUFFIX_RE = re.compile(
        r"_(?:id|name|arn|uri|url|email|self_link|version|"
        r"key_id|key_name|secret_id|secret_name)$",
        re.IGNORECASE,
    )

    @classmethod
    def _sensitive_var_match(cls, line_text: str) -> "re.Match[str] | None":
        """Return a match on a secret-shaped var name, or None.

        Wraps ``_SENSITIVE_VAR_NAME_RE.search`` with a suffix filter:
        names ending in ``_id``, ``_name``, ``_arn``, ``_uri``, ``_email``,
        ``_self_link``, ``_version``, ``_secret_id``, ``_secret_name``,
        ``_key_id``, ``_key_name``, ``_url`` are reference identifiers
        (pointers to other resources) rather than secret values themselves.
        They are safe to embed in metadata because the actual secret is
        fetched at runtime by the consumer.
        """
        for m in cls._SENSITIVE_VAR_NAME_RE.finditer(line_text):
            name = m.group(1)
            if cls._ID_SUFFIX_RE.search(name):
                continue
            return m
        return None

    @staticmethod
    def _line_range_of_attr(
        block: HclBlock, attr_name: str
    ) -> tuple[int, int] | None:
        """Find (start_idx, end_idx) into block.raw_lines that span the attribute
        ``attr_name = <value>`` including any continuation lines opened by
        parentheses or brackets.

        Returns indices relative to ``block.raw_lines`` (0-based), inclusive of
        the closing bracket / paren line. Returns None if the attribute is not
        present.
        """
        head = re.compile(rf"^\s*{re.escape(attr_name)}\s*=\s*(.*)$")
        for i, line in enumerate(block.raw_lines):
            m = head.match(line)
            if not m:
                continue
            rest = m.group(1)
            depth = rest.count("(") + rest.count("[") + rest.count("{")
            depth -= rest.count(")") + rest.count("]") + rest.count("}")
            if depth <= 0:
                return (i, i)
            j = i + 1
            while j < len(block.raw_lines) and depth > 0:
                ln = block.raw_lines[j]
                depth += ln.count("(") + ln.count("[") + ln.count("{")
                depth -= ln.count(")") + ln.count("]") + ln.count("}")
                j += 1
            return (i, j - 1)
        return None

    def _ai013(self, path: Path, blocks: list[HclBlock]) -> list[Finding]:
        """AI-013 — Sensitive variable interpolated into compute metadata.

        Pattern: `var.<secret-shaped-name>` appears inside ``metadata_startup_script``
        or any nested ``metadata { ... }`` block on a ``google_compute_instance``
        resource.

        Risk: anything that ends up in VM metadata is readable by any caller
        with ``compute.instances.get`` and is written to plan / state. The
        Cloudflare-tunnel-in-startup-script pattern is the canonical AI-slop
        instance.
        """
        out = []
        seen: set[tuple[Path, int]] = set()

        def _emit(b: HclBlock, line: int, var_name: str, surface: str) -> None:
            key = (path, line)
            if key in seen:
                return
            seen.add(key)
            out.append(self._f(
                path, line,
                "PROOFCTL-TF-AI-013",
                "Sensitive variable in compute metadata",
                Severity.ERROR,
                f'google_compute_instance "{b.label2}" passes var.{var_name} into {surface} — secret will be readable from VM metadata and visible in plan/state',
                hint=(
                    "Mount the secret from Secret Manager inside the VM at runtime "
                    "(google_secret_manager_secret_iam_member + a startup script that "
                    "calls `gcloud secrets versions access`). Do not bake the value into metadata."
                ),
                authority="CIS GCP Benchmark 4.6 / OWASP A02 Cryptographic Failures",
                docs_url="https://cloud.google.com/compute/docs/metadata/overview#metadata_security_considerations",
            ))

        for b in blocks:
            if b.kind != "resource" or b.label1 != "google_compute_instance":
                continue
            # 1. Scan metadata_startup_script line range.
            rng = self._line_range_of_attr(b, "metadata_startup_script")
            if rng is not None:
                lo, hi = rng
                for offset in range(lo, hi + 1):
                    line_text = b.raw_lines[offset]
                    m = self._sensitive_var_match(line_text)
                    if m:
                        _emit(b, b.start_line + offset, m.group(1),
                              "metadata_startup_script")
            # 2. Scan nested metadata { ... } blocks (HCL block form).
            for md in b.nested("metadata"):
                for offset, line_text in enumerate(md.raw_lines):
                    m = self._sensitive_var_match(line_text)
                    if m:
                        _emit(b, md.start_line + offset, m.group(1),
                              "metadata block")
            # 3. Scan metadata = { ... } attribute (HCL object-attribute form).
            rng = self._line_range_of_attr(b, "metadata")
            if rng is not None:
                lo, hi = rng
                for offset in range(lo, hi + 1):
                    line_text = b.raw_lines[offset]
                    m = self._sensitive_var_match(line_text)
                    if m:
                        _emit(b, b.start_line + offset, m.group(1),
                              "metadata block")
        return out


# ── Directory-level checker (cross-file rules) ───────────────────────────────


class TerraformDirChecker(HclDirChecker):
    """Cross-file Terraform checks: M-001 SG mixing, A-002 S3 public access block,
    A-011 CloudTrail (scan-level), T-014 required_version (root-module-only).
    """

    def check(self, root: Path, hcl_files: list[Path]) -> list[Finding]:
        tf_files = [f for f in hcl_files if f.suffix == ".tf"]
        out: list[Finding] = []
        out += self._m001(tf_files)
        out += self._a002(tf_files)
        out += self._a011_scan_level(tf_files)
        out += self._t014(tf_files)
        out += self._t016(tf_files)
        out += self._g048(tf_files)
        return out

    def _a011_scan_level(self, tf_files: list[Path]) -> list[Finding]:
        """A-011 (scan-level) — fire once for the entire scan when any AWS
        resource is present but no aws_cloudtrail exists anywhere.

        Previously this fired once per file via the file-level dispatcher,
        which produced N-1 duplicate findings on real codebases (one per .tf
        file containing aws_* resources). CloudTrail is account-wide; a
        single finding is sufficient.
        """
        if not tf_files:
            return []
        has_aws = False
        has_trail = False
        first_aws_path: Path | None = None
        for path in sorted(tf_files):
            if _is_test_fixture_path(path):
                continue
            try:
                source = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            blocks = parse_blocks(source)
            for b in blocks:
                if b.kind != "resource":
                    continue
                if b.label1.startswith("aws_cloudtrail"):
                    has_trail = True
                elif b.label1.startswith("aws_") and not has_aws:
                    has_aws = True
                    first_aws_path = path
            if has_trail:
                return []
        if not has_aws or first_aws_path is None:
            return []
        return [self._f(
            first_aws_path, None,
            "PROOFCTL-TF-A011", "No CloudTrail resource",
            Severity.WARNING,
            "No aws_cloudtrail resource found anywhere in the scanned tree — AWS API activity is not being audited",
            hint="Add an aws_cloudtrail resource with multi_region_trail = true and log validation enabled.",
            authority="CIS AWS Benchmark 3.1",
            docs_url="https://www.cisecurity.org/benchmark/amazon_web_services",
        )]

    @staticmethod
    def _is_root_module(blocks: list[HclBlock]) -> bool:
        """A directory is a *root* Terraform module if it configures providers
        (`provider "X" { ... }`), persists state (`terraform { backend ... }`),
        or composes other modules (`module "X" { ... }`).

        Child modules in `modules/<name>/` typically have only resources +
        variables + outputs + a `required_providers` block, inheriting
        `required_version` from the caller. Pinning `required_version` in a
        child module is a style choice, not a correctness requirement.
        """
        has_provider = any(b.kind == "provider" for b in blocks)
        has_module_call = any(b.kind == "module" for b in blocks)
        has_backend = any(
            b.kind == "terraform" and b.has_nested("backend")
            for b in blocks
        )
        return has_provider or has_module_call or has_backend

    def _t014(self, tf_files: list[Path]) -> list[Finding]:
        """T-014 (root-module-level) — fire once per *root* module directory
        when no .tf file in that directory has a
        `terraform { required_version }` block.

        Child modules (in `modules/*/`) are intentionally skipped — they
        inherit the Terraform version constraint from the calling root
        module, and pinning a duplicate version in every child module is
        not a documented best practice.
        """
        from collections import defaultdict
        by_dir: dict[Path, list[Path]] = defaultdict(list)
        for path in tf_files:
            if _is_test_fixture_path(path):
                continue
            by_dir[path.parent].append(path)

        out: list[Finding] = []
        for d, paths in by_dir.items():
            has_resources = False
            has_required_version = False
            all_blocks: list[HclBlock] = []
            first_path: Path | None = None
            for path in sorted(paths):
                try:
                    source = path.read_text(encoding="utf-8", errors="replace")
                except OSError:
                    continue
                blocks = parse_blocks(source)
                all_blocks.extend(blocks)
                if first_path is None:
                    first_path = path
                if not has_resources:
                    has_resources = any(b.kind in ("resource", "module") for b in blocks)
                if not has_required_version:
                    has_required_version = any(
                        b.kind == "terraform" and b.has_attr("required_version")
                        for b in blocks
                    )
            if (
                has_resources
                and not has_required_version
                and first_path is not None
                and self._is_root_module(all_blocks)
            ):
                out.append(self._f(
                    first_path, None,
                    "PROOFCTL-TF-T014", "Missing required_version constraint",
                    Severity.WARNING,
                    "No terraform { required_version } constraint in this root module — Terraform version drift risk",
                    hint='Add terraform { required_version = ">= 1.5" } in versions.tf or main.tf.',
                    docs_url="https://developer.hashicorp.com/terraform/language/providers/requirements#best-practices-for-provider-versions",
                ))
        return out

    # ── helpers ───────────────────────────────────────────────────────────────


    # ── T-016 / G-048 added in the 0.4.x precision sprint ────────────────────

    _VAR_REF_RE = __import__("re").compile(r"\bvar\.([a-zA-Z_][a-zA-Z0-9_]*)")

    def _t016(self, tf_files: list[Path]) -> list[Finding]:
        """T-016 — variable declared in a module but never referenced.

        Walks every ``.tf`` in each module directory, collects:
          - declared variable names (from ``variable "X" { ... }`` blocks)
          - referenced names (from ``var.X`` occurrences across all files)

        A variable in the declared set that is absent from the referenced
        set is dead module surface area — confuses callers about whether
        the field is required and accumulates as a maintenance hazard.

        Fires once per unused variable, with the finding attached to the
        line where the variable was declared.

        Test fixtures are skipped. Reserved names that intentionally
        document inputs without being consumed (none today) would go on a
        suppress list — none yet known.
        """
        from collections import defaultdict
        by_dir: dict[Path, list[Path]] = defaultdict(list)
        for path in tf_files:
            if _is_test_fixture_path(path):
                continue
            by_dir[path.parent].append(path)

        out: list[Finding] = []
        for d, paths in by_dir.items():
            declared: dict[str, tuple[Path, int]] = {}
            joined_source = []
            for path in sorted(paths):
                try:
                    source = path.read_text(encoding="utf-8", errors="replace")
                except OSError:
                    continue
                joined_source.append(source)
                blocks = parse_blocks(source)
                for b in blocks:
                    if b.kind == "variable" and b.label1:
                        declared.setdefault(b.label1, (path, b.start_line))
            referenced = set()
            full_text = "\n".join(joined_source)
            for m in self._VAR_REF_RE.finditer(full_text):
                referenced.add(m.group(1))

            for name, (path, line) in declared.items():
                if name in referenced:
                    continue
                out.append(self._f(
                    path, line,
                    "PROOFCTL-TF-T016", "Variable declared but never used",
                    Severity.WARNING,
                    f'variable "{name}" is declared but never referenced via var.{name} anywhere in the module',
                    hint="Remove the unused variable, or wire it into the resource that should consume it.",
                    docs_url="https://developer.hashicorp.com/terraform/language/values/variables",
                ))
        return out

    # CMEK signals across resource types. If any of these attributes appear on a
    # resource in the module, we treat the module as "CMEK-using" — secrets
    # should then also use customer_managed_encryption.
    _CMEK_USE_PATTERNS = (
        r'\bkms_key_name\b',
        r'\bencryption_key_name\b',
        r'\bcustomer_managed_encryption\b',
        r'\bkms_key_self_link\b',
        r'\bkms_key_arn\b',
        r'\bdefault_kms_key_name\b',
    )

    def _g048(self, tf_files: list[Path]) -> list[Finding]:
        """G-048 — Secret Manager secret without CMEK in a CMEK-using module.

        Cross-resource consistency check. If the module already uses CMEK on
        any other resource (Cloud SQL, GCS, Compute disk, etc.) but the
        ``google_secret_manager_secret`` resource uses
        ``replication { auto {} }`` (Google-managed encryption), the CMEK
        posture is undermined — the most sensitive material (credentials)
        sits under a weaker key than the data it unlocks.

        Detection:
          1. Scan every .tf in the module directory.
          2. If any line matches one of _CMEK_USE_PATTERNS, the module is
             CMEK-using.
          3. For each google_secret_manager_secret with no
             customer_managed_encryption inside its replication block, fire.

        Skips test fixtures.
        """
        import re
        from collections import defaultdict
        by_dir: dict[Path, list[Path]] = defaultdict(list)
        for path in tf_files:
            if _is_test_fixture_path(path):
                continue
            by_dir[path.parent].append(path)

        cmek_re = re.compile("|".join(self._CMEK_USE_PATTERNS))
        out: list[Finding] = []

        for d, paths in by_dir.items():
            module_uses_cmek = False
            secret_blocks: list[tuple[Path, HclBlock]] = []

            for path in sorted(paths):
                try:
                    source = path.read_text(encoding="utf-8", errors="replace")
                except OSError:
                    continue
                if cmek_re.search(source):
                    module_uses_cmek = True
                for b in parse_blocks(source):
                    if b.kind == "resource" and b.label1 == "google_secret_manager_secret":
                        secret_blocks.append((path, b))

            if not module_uses_cmek or not secret_blocks:
                continue

            for path, b in secret_blocks:
                # The secret has CMEK iff customer_managed_encryption appears
                # inside its body (which lives in user_managed.replicas[*]).
                if b.contains(r"customer_managed_encryption"):
                    continue
                line = b.any_line_matches(r"replication\s*\{") or b.start_line
                out.append(self._f(
                    path, line,
                    "PROOFCTL-TF-G048",
                    "Secret Manager secret without CMEK in CMEK-using module",
                    Severity.WARNING,
                    f'google_secret_manager_secret "{b.label2}" uses Google-managed encryption while the rest of the module uses CMEK — credential is weaker-protected than the data it unlocks',
                    hint=(
                        'Switch to replication { user_managed { replicas { '
                        'location = ... customer_managed_encryption '
                        '{ kms_key_name = var.kms_key_id } } } } and grant '
                        'the Secret Manager service agent '
                        '(service-{project_number}@gcp-sa-secretmanager.iam.gserviceaccount.com) '
                        'cryptoKeyEncrypterDecrypter on the KMS key.'
                    ),
                    authority="CIS GCP Benchmark / Customer-Managed Encryption Keys",
                    docs_url="https://cloud.google.com/secret-manager/docs/cmek",
                ))
        return out

    @staticmethod
    def _f(
        path: Path,
        line: int | None,
        rule_id: str,
        rule_name: str,
        severity: Severity,
        message: str,
        hint: str = "",
        authority: str = "",
        docs_url: str = "",
    ) -> Finding:
        return Finding(
            file=str(path), line=line, col=None,
            rule_id=rule_id, rule_name=rule_name,
            severity=severity, message=message, hint=hint,
            authority=authority, docs_url=docs_url,
        )

    def _m001(self, tf_files: list[Path]) -> list[Finding]:
        """M-001 — aws_security_group with inline rules AND standalone aws_security_group_rule."""
        # Collect SG names that have inline ingress/egress, per directory.
        from collections import defaultdict
        sg_with_inline: dict[Path, dict[str, int]] = defaultdict(dict)  # dir → {sg_id: line}
        sg_rule_refs: dict[Path, list[tuple[str, int, Path]]] = defaultdict(list)  # dir → [(sg_id, line, file)]

        for path in tf_files:
            try:
                source = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            blocks = parse_blocks(source)
            d = path.parent
            for b in blocks:
                if b.kind == "resource" and b.label1 == "aws_security_group":
                    if b.contains(r'\b(?:ingress|egress)\s*\{'):
                        sg_with_inline[d][b.label2] = b.start_line
                elif b.kind == "resource" and b.label1 == "aws_security_group_rule":
                    sg_id_val = b.attr_value("security_group_id") or ""
                    # e.g. security_group_id = aws_security_group.web.id
                    ref_m = re.search(r'aws_security_group\.(\w+)\.id', sg_id_val)
                    if ref_m:
                        sg_rule_refs[d].append((ref_m.group(1), b.start_line, path))

        out: list[Finding] = []
        for d, sg_map in sg_with_inline.items():
            for sg_name, sg_ref_line, ref_path in sg_rule_refs.get(d, []):
                if sg_name in sg_map:
                    out.append(self._f(
                        ref_path, sg_ref_line,
                        "PROOFCTL-TF-M001", "Security group rule mixing",
                        Severity.ERROR,
                        f'aws_security_group_rule references "{sg_name}" which already has inline ingress/egress — causes permanent plan diff',
                        hint="Use EITHER inline ingress/egress blocks OR standalone aws_security_group_rule resources, not both.",
                    ))
        return out

    def _a002(self, tf_files: list[Path]) -> list[Finding]:
        """A-002 — S3 bucket without companion aws_s3_bucket_public_access_block."""
        from collections import defaultdict
        buckets: dict[Path, dict[str, tuple[int, Path]]] = defaultdict(dict)  # dir → {name: (line, path)}
        pab_refs: dict[Path, set[str]] = defaultdict(set)   # dir → {bucket_id}

        for path in tf_files:
            try:
                source = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            blocks = parse_blocks(source)
            d = path.parent
            for b in blocks:
                if b.kind == "resource" and b.label1 == "aws_s3_bucket":
                    buckets[d][b.label2] = (b.start_line, path)
                elif b.kind == "resource" and b.label1 == "aws_s3_bucket_public_access_block":
                    bucket_val = b.attr_value("bucket") or ""
                    # Match both `aws_s3_bucket.<name>.<attr>` and the
                    # count-conditional `aws_s3_bucket.<name>[0].<attr>` /
                    # for_each `aws_s3_bucket.<name>["k"].<attr>` shapes.
                    ref_m = re.search(
                        r'aws_s3_bucket\.(\w+)(?:\[[^\]]+\])?\.',
                        bucket_val,
                    )
                    if ref_m:
                        pab_refs[d].add(ref_m.group(1))

        out: list[Finding] = []
        for d, bkt_map in buckets.items():
            covered = pab_refs.get(d, set())
            for bkt_name, (lineno, bkt_path) in bkt_map.items():
                if bkt_name not in covered:
                    out.append(self._f(
                        bkt_path, lineno,
                        "PROOFCTL-TF-A002", "S3 bucket missing public access block",
                        Severity.ERROR,
                        f'aws_s3_bucket "{bkt_name}" has no companion aws_s3_bucket_public_access_block',
                        hint="Add aws_s3_bucket_public_access_block with all four settings = true.",
                    ))
        return out
