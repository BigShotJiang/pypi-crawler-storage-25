"""Secret detection — PROOFCTL-SECRET-* rules. Scans any text file."""
from __future__ import annotations

import ast
import math
import re
from pathlib import Path

from ..models import Finding, Severity
from .base import FileChecker

# ── allowlists ────────────────────────────────────────────────────────────────

_SKIP_SUFFIXES = (
    ".lock", ".min.js", ".bundle.js", ".map",
)
_SKIP_NAMES = frozenset({
    "package-lock.json", "yarn.lock", "Cargo.lock", "go.sum", "pnpm-lock.yaml",
    "composer.lock", "Pipfile.lock", "poetry.lock",
})

_PLACEHOLDER_VALUES = frozenset({
    "changeme", "change-me", "change_me", "your-password-here",
    "your_password_here", "yourpassword", "password", "passw0rd",
    "xxx", "xxxx", "xxxxx", "xxxxxx", "placeholder", "todo", "tbd",
    "example", "sample", "secret", "your-secret-here", "redacted",
    "default", "test", "testing", "dummy", "fake", "none", "null",
    "<password>", "<secret>", "<value>", "n/a", "na",
})

# ── patterns ──────────────────────────────────────────────────────────────────

_PAT_AWS_KEY = re.compile(r"AKIA[A-Z0-9]{16}")
_PAT_AWS_SECRET = re.compile(
    r"""aws_secret(_access)?_key\s*=\s*["']([A-Za-z0-9/+=]{40})["']""",
    re.IGNORECASE,
)
_PAT_GITHUB = re.compile(r"gh[pousr]_[A-Za-z0-9]{36,}")
_PAT_SLACK = re.compile(r"xox[bpoars]-[A-Za-z0-9-]+")
_PAT_PRIVKEY = re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")
_PAT_JWT = re.compile(r"eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{20,}")
_PAT_GENERIC = re.compile(
    r"""(?P<key>password|passwd|pwd|secret|api[_-]?key|access[_-]?token|auth[_-]?token)"""
    r"""\s*[:=]\s*["'](?P<val>[^"'$\{]{8,})["']""",
    re.IGNORECASE,
)
_PAT_GOOGLE = re.compile(r"AIza[0-9A-Za-z_-]{35}")
_PAT_STRIPE = re.compile(r"(?:sk|pk)_(?:test|live)_[0-9a-zA-Z]{24,}")
_PAT_TF_ADMIN = re.compile(
    r"""(?P<key>administrator_login_password|admin_password|root_password)"""
    r"""\s*=\s*"(?P<val>[^"$\{][^"]{4,})\"""",
)

_ENV_REF_RE = re.compile(r"^\s*[\$\{][^\s]+[\}]?\s*$|^\$[A-Z_][A-Z0-9_]*$|^\$\{[^}]+\}$")

# SECRET-011: kind: Secret YAML detection
_PAT_K8S_KIND_SECRET = re.compile(r'^\s*kind\s*:\s*["\']?Secret["\']?\s*(#.*)?$')
_PAT_YAML_DOC_SEP = re.compile(r'^---\s*(#.*)?$')
_PAT_K8S_NAME = re.compile(r'^\s{2,}name\s*:\s*["\']?([A-Za-z0-9._-]+)["\']?\s*(#.*)?$')
_PAT_K8S_DATA_KEY = re.compile(r'^(\s*)(data|stringData)\s*:\s*(#.*)?$')
# Match indented "key: value" lines under data:/stringData:
_PAT_K8S_DATA_ENTRY = re.compile(
    r'^(\s+)([A-Za-z0-9._-]+)\s*:\s*(.*?)\s*(?:#.*)?$'
)
_K8S_SKIP_PATH_TOKENS = ("/tests/", "/fixtures/", "/testdata/")

# SECRET-012: heredoc tracking + secret-shaped env assignment inside heredoc
_PAT_HEREDOC_OPEN = re.compile(r'<<[-~]?(\w+)\s*$')
_PAT_HEREDOC_SECRET = re.compile(
    r'(?:export\s+)?([A-Z][A-Z0-9_]*(?:_KEY|_TOKEN|_SECRET|_PASSWORD|_PASSWD))'
    r'\s*=\s*([^\s"\']+|"[^"]+"|\'[^\']+\')'
)


def _shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    freq: dict[str, int] = {}
    for ch in s:
        freq[ch] = freq.get(ch, 0) + 1
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in freq.values())


def _is_placeholder(val: str) -> bool:
    low = val.lower().strip()
    if low in _PLACEHOLDER_VALUES:
        return True
    # Entirely lowercase + dashes/underscores looks like placeholder text
    if re.fullmatch(r"[a-z][a-z0-9_\-]*", val) and any(
        tok in low for tok in ("change", "your", "placeholder", "example", "sample")
    ):
        return True
    return False


def _is_env_ref(val: str) -> bool:
    return bool(_ENV_REF_RE.match(val)) or "${" in val or val.startswith("$(")


def _is_binary(data: bytes) -> bool:
    if not data:
        return False
    if b"\x00" in data:
        return True
    text_chars = bytes(range(32, 127)) + b"\n\r\t\f\b"
    nonprint = sum(1 for b in data if b not in text_chars)
    return (nonprint / len(data)) > 0.30


def _should_skip(path: Path) -> bool:
    name = path.name
    if name in _SKIP_NAMES:
        return True
    for suf in _SKIP_SUFFIXES:
        if name.endswith(suf):
            return True
    # *.lock.json
    if name.endswith(".lock.json"):
        return True
    return False


# ── rule fns ──────────────────────────────────────────────────────────────────

def _mk(path: Path, line: int, rid: str, name: str, sev: Severity, msg: str) -> Finding:
    return Finding(
        file=str(path),
        line=line,
        col=0,
        rule_id=rid,
        rule_name=name,
        severity=sev,
        message=msg,
        hint="Move secret to env var, secret manager, or runtime injection. Never commit credentials.",
        authority="OWASP ASVS V2 / CWE-798 – Use of Hard-coded Credentials",
        docs_url="https://cwe.mitre.org/data/definitions/798.html",
    )


def _scan_line(path: Path, lineno: int, line: str) -> list[Finding]:
    out: list[Finding] = []
    # Track (rule_priority, secret_value) so most-specific rule wins per value.
    # Keyed by value text → (priority, Finding)
    by_value: dict[str, tuple[int, Finding]] = {}

    def _claim(value: str, priority: int, finding: Finding) -> None:
        existing = by_value.get(value)
        if existing is None or priority < existing[0]:
            by_value[value] = (priority, finding)

    # SECRET-001: AWS access key
    for m in _PAT_AWS_KEY.finditer(line):
        v = m.group(0)
        _claim(v, 1, _mk(path, lineno, "PROOFCTL-SECRET-001",
                         "AWS access key ID", Severity.ERROR,
                         f"Hardcoded AWS access key ID detected ({v[:8]}…)"))

    # SECRET-002: AWS secret key
    for m in _PAT_AWS_SECRET.finditer(line):
        v = m.group(2)
        _claim(v, 2, _mk(path, lineno, "PROOFCTL-SECRET-002",
                         "AWS secret access key", Severity.ERROR,
                         "Hardcoded AWS secret access key detected"))

    # SECRET-003: GitHub token
    for m in _PAT_GITHUB.finditer(line):
        v = m.group(0)
        _claim(v, 3, _mk(path, lineno, "PROOFCTL-SECRET-003",
                         "GitHub token", Severity.ERROR,
                         f"Hardcoded GitHub token detected ({v[:7]}…)"))

    # SECRET-004: Slack token
    for m in _PAT_SLACK.finditer(line):
        v = m.group(0)
        _claim(v, 4, _mk(path, lineno, "PROOFCTL-SECRET-004",
                         "Slack token", Severity.ERROR,
                         f"Hardcoded Slack token detected ({v[:6]}…)"))

    # SECRET-005: Private key marker
    for m in _PAT_PRIVKEY.finditer(line):
        v = m.group(0)
        _claim(v, 5, _mk(path, lineno, "PROOFCTL-SECRET-005",
                         "Private key", Severity.ERROR,
                         "Private key block detected"))

    # SECRET-006: JWT (warning — often in tests/docs)
    for m in _PAT_JWT.finditer(line):
        v = m.group(0)
        _claim(v, 6, _mk(path, lineno, "PROOFCTL-SECRET-006",
                         "JWT token", Severity.WARNING,
                         f"JWT token detected ({v[:12]}…) — confirm not a real credential"))

    # SECRET-008: Google API key
    for m in _PAT_GOOGLE.finditer(line):
        v = m.group(0)
        _claim(v, 8, _mk(path, lineno, "PROOFCTL-SECRET-008",
                         "Google API key", Severity.ERROR,
                         f"Hardcoded Google API key detected ({v[:8]}…)"))

    # SECRET-009: Stripe key
    for m in _PAT_STRIPE.finditer(line):
        v = m.group(0)
        _claim(v, 9, _mk(path, lineno, "PROOFCTL-SECRET-009",
                         "Stripe API key", Severity.ERROR,
                         f"Hardcoded Stripe key detected ({v[:8]}…)"))

    # SECRET-010: Terraform/HCL admin password
    for m in _PAT_TF_ADMIN.finditer(line):
        v = m.group("val")
        if _is_env_ref(v) or _is_placeholder(v):
            continue
        _claim(v, 10, _mk(path, lineno, "PROOFCTL-SECRET-010",
                          "Hardcoded admin password", Severity.ERROR,
                          f"Hardcoded admin password in '{m.group('key')}' assignment"))

    # SECRET-007: Generic high-entropy assignment (lowest priority — fires last)
    for m in _PAT_GENERIC.finditer(line):
        v = m.group("val")
        if _is_env_ref(v) or _is_placeholder(v):
            continue
        if v.islower() and len(v) <= 16 and re.fullmatch(r"[a-z0-9_\-]+", v):
            # Looks like a slug/placeholder — skip
            continue
        if _shannon_entropy(v) < 3.5:
            continue
        _claim(v, 7, _mk(path, lineno, "PROOFCTL-SECRET-007",
                         "Hardcoded credential assignment", Severity.ERROR,
                         f"Likely hardcoded {m.group('key')} assignment"))

    out.extend(f for _, f in by_value.values())
    return out


# ── SECRET-011: kind: Secret YAML ─────────────────────────────────────────────

def _scan_k8s_secrets(path: Path, source: str) -> list[Finding]:
    """Scan YAML for `kind: Secret` documents with plaintext data:/stringData:.

    Fires once per Secret document on the line of `kind: Secret`.
    Also fires on multi-doc YAML (--- separators) per document.
    """
    name_str = str(path).replace("\\", "/").lower()
    if any(tok in name_str for tok in _K8S_SKIP_PATH_TOKENS):
        return []
    # Restrict to plausible YAML files (cheap guard — main.yaml, *.yml, *.yaml).
    if not (path.name.endswith(".yaml") or path.name.endswith(".yml")):
        return []

    lines = source.splitlines()
    out: list[Finding] = []

    # Collect document slices (line ranges) using --- separators.
    doc_starts: list[int] = [0]
    for idx, line in enumerate(lines):
        if idx > 0 and _PAT_YAML_DOC_SEP.match(line):
            doc_starts.append(idx + 1)
    doc_starts.append(len(lines))

    for di in range(len(doc_starts) - 1):
        start, end = doc_starts[di], doc_starts[di + 1]
        kind_line = -1
        secret_name = "<unnamed>"
        # Find kind: Secret in this doc
        for i in range(start, end):
            if _PAT_K8S_KIND_SECRET.match(lines[i]):
                kind_line = i
                break
        if kind_line < 0:
            continue

        # Find metadata.name (best-effort; first 'name:' under metadata or any 'name:' line).
        for i in range(start, end):
            mn = _PAT_K8S_NAME.match(lines[i])
            if mn:
                secret_name = mn.group(1)
                break

        # Walk for data:/stringData: blocks and check for any non-empty entries.
        i = start
        leaked = False
        while i < end:
            line = lines[i]
            mkey = _PAT_K8S_DATA_KEY.match(line)
            if not mkey:
                i += 1
                continue
            base_indent = len(mkey.group(1))
            j = i + 1
            while j < end:
                child = lines[j]
                if not child.strip() or child.lstrip().startswith("#"):
                    j += 1
                    continue
                child_indent = len(child) - len(child.lstrip())
                if child_indent <= base_indent:
                    break
                me = _PAT_K8S_DATA_ENTRY.match(child)
                if me:
                    val = me.group(3).strip()
                    # Strip simple quoting
                    if (val.startswith('"') and val.endswith('"')) or (
                        val.startswith("'") and val.endswith("'")
                    ):
                        val = val[1:-1]
                    # Skip empty / null / valueFrom-style references / pipe-block markers
                    if not val or val in ("''", '""', "null", "~"):
                        j += 1
                        continue
                    if val in ("|", ">", "|-", ">-", "|+", ">+"):
                        # Block scalar follows — treat as a real value if any next
                        # non-empty indented line exists.
                        k = j + 1
                        has_content = False
                        while k < end:
                            nxt = lines[k]
                            if not nxt.strip():
                                k += 1
                                continue
                            nxt_indent = len(nxt) - len(nxt.lstrip())
                            if nxt_indent <= child_indent:
                                break
                            has_content = True
                            break
                        if has_content:
                            leaked = True
                            break
                        j += 1
                        continue
                    if val.startswith("valueFrom") or val.startswith("&") or val.startswith("*"):
                        j += 1
                        continue
                    # Otherwise: a real plaintext value (b64 or stringData).
                    leaked = True
                    break
                j += 1
            if leaked:
                break
            i = j

        if leaked:
            out.append(Finding(
                file=str(path),
                line=kind_line + 1,
                col=0,
                rule_id="PROOFCTL-SECRET-011",
                rule_name="Plaintext credentials in Kubernetes Secret manifest",
                severity=Severity.ERROR,
                message=(
                    f"Kubernetes Secret '{secret_name}' has plaintext credentials "
                    "in data:/stringData:"
                ),
                hint=(
                    "Use external secret store: ExternalSecrets, Sealed Secrets, "
                    "or valueFrom.secretKeyRef from a properly-managed Secret "
                    "outside the manifest."
                ),
                authority="OWASP ASVS V2 / CWE-798 – Use of Hard-coded Credentials",
                docs_url="https://cwe.mitre.org/data/definitions/798.html",
            ))
    return out


# ── SECRET-012: secret-shaped env assignment inside heredoc ───────────────────

def _scan_heredoc_secrets(
    path: Path, source: str, already_fired_lines: set[int]
) -> list[Finding]:
    """Detect FOO_KEY/_TOKEN/_SECRET/_PASSWORD=value inside <<EOF heredocs."""
    out: list[Finding] = []
    heredoc_end: str | None = None
    for i, line in enumerate(source.splitlines(), start=1):
        if heredoc_end is None:
            hm = _PAT_HEREDOC_OPEN.search(line)
            if hm:
                heredoc_end = hm.group(1)
            continue
        # Inside heredoc
        stripped = line.strip()
        if stripped == heredoc_end or stripped.rstrip("-~") == heredoc_end:
            heredoc_end = None
            continue
        if i in already_fired_lines:
            continue
        m = _PAT_HEREDOC_SECRET.search(line)
        if not m:
            continue
        key = m.group(1)
        val = m.group(2)
        if (val.startswith('"') and val.endswith('"')) or (
            val.startswith("'") and val.endswith("'")
        ):
            val = val[1:-1]
        if len(val) < 8:
            continue
        if _is_env_ref(val) or val.startswith("$"):
            continue
        if _is_placeholder(val):
            continue
        out.append(Finding(
            file=str(path),
            line=i,
            col=0,
            rule_id="PROOFCTL-SECRET-012",
            rule_name="Secret in heredoc body",
            severity=Severity.ERROR,
            message=f"Hardcoded secret-shaped assignment '{key}=...' inside heredoc",
            hint=(
                "Heredocs (e.g. user_data) are committed to state and version "
                "control. Inject via EC2 Instance Metadata, SSM Parameter Store, "
                "Secrets Manager, or a templated runtime variable."
            ),
            authority="OWASP ASVS V2 / CWE-798 – Use of Hard-coded Credentials",
            docs_url="https://cwe.mitre.org/data/definitions/798.html",
        ))
    return out


# ── SECRET-007/013: Python AST-aware credential detection ────────────────────

# Kwargs / attribute / target names that strongly indicate a credential.
# Matched as full-string regex (case-insensitive).
_PY_SECRET_KW_RE = re.compile(
    r"^("
    r"password|passwd|pwd"
    r"|secret"
    r"|api[_-]?key"
    r"|access[_-]?key|secret[_-]?key"
    r"|access[_-]?token|auth[_-]?token|bearer[_-]?token|client[_-]?secret"
    r"|private[_-]?key"
    r"|token"
    r")$",
    re.IGNORECASE,
)

# Module-level constant target names (broader — covers DB_PASS, JWT_SECRET, ENCRYPTION_KEY,
# X_TOKEN, X_CREDENTIAL, etc.).
_PY_SECRET_TARGET_RE = re.compile(
    r"^(?:"
    r"password|passwd|pwd"
    r"|secret"
    r"|api[_-]?key|access[_-]?key|secret[_-]?key|encryption[_-]?key"
    r"|jwt[_-]?secret|client[_-]?secret"
    r"|db[_-]?pass(?:word|wd)?"
    r"|.+_token|.+_credential|.+_secret|.+_key|.+_password|.+_passwd"
    r")$",
    re.IGNORECASE,
)

# Stricter placeholder check used only inside the Python AST path. Matches things like
# "<password>", "${PASSWORD}", "CHANGEME", "INSERT_HERE", "REPLACE_ME".
_PY_PLACEHOLDER_RE = re.compile(
    r"^<.*>$|^\$\{.+\}$|^(?:CHANGEME|INSERT_HERE|REPLACE_ME)$",
    re.IGNORECASE,
)

# Kwargs whose values are credentials in libraries that take *short* passwords
# (e.g. mysql/postgres root). For these we don't gate on length ≥ 6.
_PY_SHORT_OK_KW_RE = re.compile(
    r"^(password|passwd|pwd)$", re.IGNORECASE,
)

# Connection strings with embedded credentials — postgres://user:pass@host/db etc.
_PAT_CONN_STR_CRED = re.compile(
    r"(?P<scheme>postgres|postgresql|mysql|mysql\+pymysql|mariadb|redis|rediss|"
    r"mongodb|mongodb\+srv|amqp|amqps|sqlserver|mssql)://"
    r"(?P<user>[^:/@\s]+):(?P<pw>[^@\s]+)@(?P<host>[^/\s]+)"
)


def _short_ok_for_kw(kw: str) -> bool:
    return bool(_PY_SHORT_OK_KW_RE.match(kw))


def _py_value_is_placeholder(val: str) -> bool:
    """Stricter placeholder check used inside the Python AST path.

    We deliberately do NOT use the broad ``_is_placeholder`` set (which contains
    common dictionary words like 'password' / 'secret'): when a user writes
    ``password = "password"`` or ``connect(password='password')`` that IS the
    canonical CWE-798 / CWE-259 antipattern. We only filter obvious template
    markers like ``<password>``, ``${PASSWORD}``, ``CHANGEME``.
    """
    if _PY_PLACEHOLDER_RE.match(val):
        return True
    return False


def _py_value_real_credential(
    val: str, *, allow_short: bool, allow_slug: bool = False
) -> bool:
    """Return True if `val` looks like a real plaintext credential.

    ``allow_short``: accept any plaintext (≥2 chars). Used for explicit
    password-shaped kwargs like ``passwd="root"`` where context is decisive.
    ``allow_slug``: accept lowercase slug-style tokens like ``hunter2x``
    when the context is strong (e.g. inside a connection string or password kw).
    """
    if not val:
        return False
    if _is_env_ref(val):
        return False
    if _py_value_is_placeholder(val):
        return False
    if allow_short:
        # Any non-trivial plaintext literal in a password kwarg counts. We still
        # reject 1-char values to avoid catching accidental "x" values.
        return len(val) >= 2
    if len(val) < 6:
        return False
    # Avoid lower-case slug-style tokens (e.g. "user-name") for non-password keys
    if not allow_slug and (
        val.islower() and re.fullmatch(r"[a-z0-9_\-]+", val) and len(val) <= 16
    ):
        return False
    return True


def _ast_const_str(node: ast.AST) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


def _ast_kw_name(kw: ast.keyword) -> str | None:
    return kw.arg


def _is_module_level(parents: list[ast.AST]) -> bool:
    """True if `parents` is empty or the only parent is the Module."""
    if not parents:
        return True
    if len(parents) == 1 and isinstance(parents[0], ast.Module):
        return True
    return False


def _scan_python_ast(path: Path, source: str, fired_lines: set[int]) -> list[Finding]:
    """AST-aware detection: kwargs, tuple-auth, module-level constants, conn-strings.

    Skips lines that already triggered a SECRET-* finding via the line-scan path.
    """
    out: list[Finding] = []
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return out

    seen: set[tuple[int, str]] = set()  # (line, value) dedup

    def _emit(line: int, key_label: str, value: str) -> None:
        if (line, value) in seen:
            return
        if line in fired_lines:
            return
        seen.add((line, value))
        out.append(_mk(
            path, line, "PROOFCTL-SECRET-007",
            "Hardcoded credential assignment", Severity.ERROR,
            f"Likely hardcoded {key_label} assignment",
        ))

    def _emit_conn(line: int, scheme: str, value: str) -> None:
        if (line, value) in seen:
            return
        if line in fired_lines:
            return
        seen.add((line, value))
        out.append(_mk(
            path, line, "PROOFCTL-SECRET-013",
            "Hardcoded credential in connection string", Severity.ERROR,
            f"Hardcoded password embedded in {scheme}:// connection string",
        ))

    # Connection-string detector — string-literal walk anywhere in the AST.
    for node in ast.walk(tree):
        s = _ast_const_str(node)
        if s is None or "://" not in s:
            continue
        m = _PAT_CONN_STR_CRED.search(s)
        if not m:
            continue
        pw = m.group("pw")
        # Inside a real connection string the contextual signal is strong,
        # so we relax the lowercase-slug filter that suppresses things like
        # 'hunter2x' or 'secretpass'.
        if not _py_value_real_credential(pw, allow_short=False, allow_slug=True):
            continue
        line = getattr(node, "lineno", 1)
        _emit_conn(line, m.group("scheme"), pw)

    # Walk Calls for password-shaped kwargs.
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            for kw in node.keywords:
                kw_name = _ast_kw_name(kw)
                if not kw_name or not _PY_SECRET_KW_RE.match(kw_name):
                    continue
                v = _ast_const_str(kw.value)
                if v is None:
                    continue
                allow_short = _short_ok_for_kw(kw_name)
                if not _py_value_real_credential(v, allow_short=allow_short):
                    continue
                line = getattr(kw.value, "lineno", getattr(node, "lineno", 1))
                _emit(line, kw_name, v)

    # Walk Assigns for:
    #   - tuple-auth: foo.auth = ("user", "pass") / auth = ("u", "p")
    #   - module-level secret constants: PASSWORD = "..."
    for node in ast.walk(tree):
        if not isinstance(node, ast.Assign):
            continue
        # Tuple-auth pattern: any Assign whose targets contain a name/attr ending in 'auth'
        # and value is a 2-tuple of string constants.
        is_auth_target = False
        for tgt in node.targets:
            tgt_name: str | None = None
            if isinstance(tgt, ast.Name):
                tgt_name = tgt.id
            elif isinstance(tgt, ast.Attribute):
                tgt_name = tgt.attr
            if tgt_name and tgt_name.lower() in ("auth", "credentials", "creds", "basic_auth"):
                is_auth_target = True
                break
        if is_auth_target and isinstance(node.value, ast.Tuple) and len(node.value.elts) == 2:
            pw_node = node.value.elts[1]
            pw_val = _ast_const_str(pw_node)
            if pw_val is not None and _py_value_real_credential(pw_val, allow_short=False):
                line = getattr(pw_node, "lineno", getattr(node, "lineno", 1))
                _emit(line, "auth tuple", pw_val)

    # Module-level secret constants. Only fire for top-level Assigns directly under Module.
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for tgt in node.targets:
                if not isinstance(tgt, ast.Name):
                    continue
                if not _PY_SECRET_TARGET_RE.match(tgt.id):
                    continue
                v = _ast_const_str(node.value)
                if v is None:
                    continue
                # Allow short for password-named targets; require entropy/length otherwise.
                allow_short = bool(re.match(r"(?i)^(.*_)?(password|passwd|pwd)$", tgt.id))
                if not _py_value_real_credential(v, allow_short=allow_short):
                    continue
                line = getattr(node.value, "lineno", getattr(node, "lineno", 1))
                _emit(line, tgt.id, v)

    # Walk Calls for kwargs that pass tuple auth, e.g. requests.get(url, auth=("u","p"))
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            for kw in node.keywords:
                if kw.arg not in ("auth", "basic_auth"):
                    continue
                if isinstance(kw.value, ast.Tuple) and len(kw.value.elts) == 2:
                    pw_node = kw.value.elts[1]
                    pw_val = _ast_const_str(pw_node)
                    if pw_val is not None and _py_value_real_credential(pw_val, allow_short=False):
                        line = getattr(pw_node, "lineno", getattr(node, "lineno", 1))
                        _emit(line, f"{kw.arg} tuple", pw_val)

    return out


# ── main checker ──────────────────────────────────────────────────────────────

class SecretChecker(FileChecker):
    """Scans any text file for hardcoded secrets."""

    extensions: tuple[str, ...] = ()

    def check(self, path: Path, source: str, tree=None) -> list[Finding]:  # type: ignore[override]
        if _should_skip(path):
            return []
        # Binary sniff using the source's first 1024 chars encoded back.
        head_bytes = source[:1024].encode("utf-8", errors="replace")
        if _is_binary(head_bytes):
            return []

        findings: list[Finding] = []
        for i, line in enumerate(source.splitlines(), start=1):
            if not line:
                continue
            findings.extend(_scan_line(path, i, line))

        # SECRET-011: K8s Secret YAML
        findings.extend(_scan_k8s_secrets(path, source))

        # SECRET-012: heredoc secrets (skip lines where SECRET-001..010 already fired)
        already = {f.line for f in findings if f.rule_id != "PROOFCTL-SECRET-011"}
        findings.extend(_scan_heredoc_secrets(path, source, already))

        # SECRET-007/013: Python AST-aware detection (kwargs, tuple-auth,
        # module-level constants, connection strings). Skip lines that already
        # fired a SECRET-* via line-scan to avoid double-reporting.
        if path.suffix == ".py":
            already_lines = {f.line for f in findings if f.rule_id != "PROOFCTL-SECRET-011"}
            findings.extend(_scan_python_ast(path, source, already_lines))

        return findings
