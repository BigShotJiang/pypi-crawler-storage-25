from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import Iterator

from ..models import Finding, Severity
from .base import FileChecker, DirectoryChecker

_MUTABLE_TYPES = frozenset({"list", "dict", "set", "defaultdict", "OrderedDict", "Counter"})
_ANY_IGNORE_RE = re.compile(r"#\s*type:\s*ignore(?!\s*\[)(?!\s*#)")
_TEST_PATH_COMPONENTS = frozenset({"tests", "test"})
_TEST_FILE_RE = re.compile(r"^(test_.+|.+_test)\.py$")
_Q009_SKIP_PATH_COMPONENTS = frozenset({"examples", "scripts", "samples", "demo"})


def _is_test_file(path: Path) -> bool:
    return (
        any(p in _TEST_PATH_COMPONENTS for p in path.parts)
        or bool(_TEST_FILE_RE.match(path.name))
    )


def _is_mutable_default(node: ast.expr) -> bool:
    if isinstance(node, (ast.List, ast.Dict, ast.Set)):
        return True
    if isinstance(node, ast.Call):
        func = node.func
        name = func.id if isinstance(func, ast.Name) else (
            func.attr if isinstance(func, ast.Attribute) else None
        )
        if name in _MUTABLE_TYPES:
            return True
    return False


class _Q001Visitor(ast.NodeVisitor):
    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def _check(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        args = node.args
        # defaults align to the LAST N positional args; kw_defaults align to kwargs
        defaults = args.defaults
        kwdefaults = [d for d in (args.kw_defaults or []) if d is not None]

        all_defaults = list(defaults) + list(kwdefaults)
        for default in all_defaults:
            if _is_mutable_default(default):
                type_name = (
                    type(default).__name__
                    if isinstance(default, (ast.List, ast.Dict, ast.Set))
                    else (default.func.id if isinstance(default.func, ast.Name) else "mutable")
                )
                # Sync `fixable` with fixer.py capability: the auto-fixer can only
                # rewrite single-line default expressions. Multi-line literals
                # (e.g. nested dict/list spanning several lines) are skipped by
                # the fixer (see proofctl/fixer.py: `default_node.lineno ==
                # default_node.end_lineno`). Advertise this honestly to avoid
                # `--fix` reporting "fixable" findings it cannot resolve.
                end_lineno = getattr(default, "end_lineno", default.lineno)
                is_single_line = end_lineno is None or end_lineno == default.lineno
                self.findings.append(Finding(
                    file=str(self.path),
                    line=default.lineno,
                    col=default.col_offset,
                    rule_id="PROOFCTL-Q-001",
                    rule_name="Mutable default argument",
                    severity=Severity.ERROR,
                    message=(
                        f"'{node.name}' has a mutable {type_name} default argument — "
                        "shared across all calls"
                    ),
                    hint="Use None as default and initialize inside the function body.",
                    authority="Python Gotchas – Mutable Default Arguments",
                    docs_url="https://docs.python-guide.org/writing/gotchas/#mutable-default-arguments",
                    fixable=is_single_line,
                ))


class _Q002Visitor(ast.NodeVisitor):
    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_ExceptHandler(self, node: ast.ExceptHandler) -> None:
        bare = node.type is None
        broad = (
            node.type is not None
            and isinstance(node.type, ast.Name)
            and node.type.id in ("Exception", "BaseException")
        )
        if not (bare or broad):
            self.generic_visit(node)
            return

        # Check if body is just pass / just a log call
        body = node.body
        is_suppressed = (
            len(body) == 1
            and isinstance(body[0], ast.Pass)
        )
        is_log_only = (
            len(body) == 1
            and isinstance(body[0], ast.Expr)
            and isinstance(body[0].value, ast.Call)
        )
        # Re-raise within the handler scope (not nested function/class bodies)
        has_raise = self._handler_reraises(node)

        if has_raise:
            self.generic_visit(node)
            return

        if bare:
            rule_id = "PROOFCTL-Q-002"
            sev = Severity.ERROR
            msg = "Bare except: catches KeyboardInterrupt, SystemExit, and all exceptions silently"
            hint = "Catch specific exceptions: except (ValueError, KeyError) as e:"
        elif is_suppressed or is_log_only:
            # Tier 1 (WARNING): obvious swallow — body is `pass` or a single call (likely log).
            rule_id = "PROOFCTL-Q-002"
            sev = Severity.WARNING
            msg = "Broad except Exception with no re-raise swallows all errors"
            hint = "Catch specific exceptions or re-raise: except Exception as e: ... raise"
        else:
            # Tier 2 (INFO, H-16): any other broad-except that doesn't re-raise.
            # Catches the wider "swallows but does five lines of dummy recovery"
            # pattern that the WARNING tier misses.
            rule_id = "PROOFCTL-Q-002"
            sev = Severity.INFO
            msg = (
                "Broad except Exception without re-raise — recovery code may be "
                "hiding real failures"
            )
            hint = (
                "Catch specific exceptions, or re-raise after handling: "
                "except Exception: ... raise"
            )

        self.findings.append(Finding(
            file=str(self.path),
            line=node.lineno,
            col=node.col_offset,
            rule_id=rule_id,
            rule_name="Broad exception handler",
            severity=sev,
            message=msg,
            hint=hint,
            authority="OWASP A10:2025 – Mishandling of Exceptional Conditions",
            docs_url="https://owasp.org/www-community/vulnerabilities/Improper_Error_Handling",
        ))
        self.generic_visit(node)

    @staticmethod
    def _handler_reraises(handler: ast.ExceptHandler) -> bool:
        """Return True if the handler body re-raises (raise at handler scope).

        Walks the body excluding nested function/class definitions whose
        `raise` statements would not propagate out of the handler when reached.
        """
        for stmt in handler.body:
            for node in _walk_no_nested(stmt):
                if isinstance(node, ast.Raise):
                    return True
        return False


class _Q003Visitor(ast.NodeVisitor):
    def __init__(self, path: Path):
        self.path = path
        self.any_uses: list[ast.AST] = []

    def visit_Name(self, node: ast.Name) -> None:
        if node.id == "Any":
            self.any_uses.append(node)
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute) -> None:
        if node.attr == "Any":
            self.any_uses.append(node)
        self.generic_visit(node)


class _AbstractClassInfo:
    def __init__(self, node: ast.ClassDef, file: str):
        self.node = node
        self.file = file
        self.name = node.name
        self.bases: set[str] = set()
        for base in node.bases:
            if isinstance(base, ast.Name):
                self.bases.add(base.id)
            elif isinstance(base, ast.Attribute):
                self.bases.add(base.attr)
        self.has_abstract_method = any(
            "abstractmethod" in {
                d.id if isinstance(d, ast.Name) else
                d.attr if isinstance(d, ast.Attribute) else ""
                for d in n.decorator_list
            }
            for n in ast.walk(node)
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
        )
        self.is_abc = (
            "ABC" in self.bases
            or "Protocol" in self.bases
            or self.has_abstract_method
        )


# ── Q-005: cyclomatic complexity ──────────────────────────────────────────────

def _walk_no_nested(node: ast.AST) -> Iterator[ast.AST]:
    """Yield all descendant nodes, not descending into nested function/class defs."""
    yield node
    for child in ast.iter_child_nodes(node):
        if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue  # nested scope — counted separately
        yield from _walk_no_nested(child)


def _cyclomatic_complexity(func: ast.FunctionDef | ast.AsyncFunctionDef) -> int:
    complexity = 1
    # `ast.Match` / `ast.match_case` exist on Python 3.10+. Reference via
    # getattr so this module still imports cleanly on older interpreters.
    match_node = getattr(ast, "Match", None)
    match_case_node = getattr(ast, "match_case", None)
    for node in _walk_no_nested(func):
        if node is func:
            continue
        if isinstance(node, (ast.If, ast.While, ast.For, ast.AsyncFor)):
            complexity += 1
        elif isinstance(node, ast.ExceptHandler):
            complexity += 1
        elif isinstance(node, ast.BoolOp):
            complexity += len(node.values) - 1
        elif isinstance(node, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
            complexity += 1
        # H-17: count match/case statements toward complexity.
        # `match` itself adds 1 (the dispatch decision); each `case` arm adds 1
        # (each is a distinct execution path).
        elif match_node is not None and isinstance(node, match_node):
            complexity += 1
        elif match_case_node is not None and isinstance(node, match_case_node):
            complexity += 1
    return complexity


class _Q005Visitor(ast.NodeVisitor):
    def __init__(self, path: Path, warn_threshold: int, error_threshold: int):
        self.path = path
        self.warn = warn_threshold
        self.error = error_threshold
        self.findings: list[Finding] = []

    def _check(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        cc = _cyclomatic_complexity(node)
        if cc > self.warn:
            sev = Severity.ERROR if cc > self.error else Severity.WARNING
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-Q-005",
                rule_name="High cyclomatic complexity",
                severity=sev,
                message=f"'{node.name}' has cyclomatic complexity {cc} (threshold: {self.warn})",
                hint=(
                    "Break the function into smaller, single-purpose functions. "
                    "Each branch is a candidate for extraction."
                ),
                authority="Clean Code Ch. 3 – Functions / McCabe 1976",
                docs_url="https://www.oreilly.com/library/view/clean-code-a/9780136083238/",
            ))

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)


# ── Q-006: function too long ──────────────────────────────────────────────────

class _Q006Visitor(ast.NodeVisitor):
    def __init__(self, path: Path, warn_lines: int, error_lines: int):
        self.path = path
        self.warn = warn_lines
        self.error = error_lines
        self.findings: list[Finding] = []

    def _check(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        if node.end_lineno is None:
            return
        length = node.end_lineno - node.lineno
        if length > self.warn:
            sev = Severity.ERROR if length > self.error else Severity.WARNING
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-Q-006",
                rule_name="Function too long",
                severity=sev,
                message=f"'{node.name}' is {length} lines long (threshold: {self.warn})",
                hint="Extract logical sub-steps into well-named helper functions.",
                authority="Clean Code Ch. 3 – Functions should be small",
                docs_url="https://www.oreilly.com/library/view/clean-code-a/9780136083238/",
            ))

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)


# ── Q-007: too many function parameters ──────────────────────────────────────

class _Q007Visitor(ast.NodeVisitor):
    def __init__(self, path: Path, warn_params: int, error_params: int):
        self.path = path
        self.warn = warn_params
        self.error = error_params
        self.findings: list[Finding] = []

    def _check(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        args = node.args
        params = list(args.posonlyargs) + list(args.args)
        # Remove self / cls for methods
        if params and params[0].arg in ("self", "cls"):
            params = params[1:]
        # H-18: keyword-only arguments are real parameters too — `def f(*, a, b,
        # c, d, e, f, g, h)` is just as overloaded as a positional version.
        params += list(args.kwonlyargs)
        count = len(params)
        if count > self.warn:
            sev = Severity.ERROR if count > self.error else Severity.WARNING
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-Q-007",
                rule_name="Too many function parameters",
                severity=sev,
                message=f"'{node.name}' has {count} parameters (threshold: {self.warn})",
                hint=(
                    "Group related parameters into a dataclass or config object. "
                    "Clean Code: ideal is 0–2 args; >3 needs justification."
                ),
                authority="Clean Code Ch. 3 – Function Arguments",
                docs_url="https://www.oreilly.com/library/view/clean-code-a/9780136083238/",
            ))

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)


# ── Q-008: boolean flag argument ─────────────────────────────────────────────

def _collect_dataclass_names(tree: ast.Module) -> set[str]:
    """Return names of module-level classes decorated with @dataclass.

    Recognises both `@dataclass` (bare) and `@dataclasses.dataclass`, with or
    without arguments (e.g. `@dataclass(frozen=True)`).
    """
    names: set[str] = set()
    for node in tree.body:
        if not isinstance(node, ast.ClassDef):
            continue
        for dec in node.decorator_list:
            target = dec.func if isinstance(dec, ast.Call) else dec
            if isinstance(target, ast.Name) and target.id == "dataclass":
                names.add(node.name)
                break
            if (
                isinstance(target, ast.Attribute)
                and target.attr == "dataclass"
                and isinstance(target.value, ast.Name)
                and target.value.id == "dataclasses"
            ):
                names.add(node.name)
                break
    return names


class _Q008Visitor(ast.NodeVisitor):
    """Flag True/False passed as a *positional* argument — indicates a function does two things."""

    def __init__(self, path: Path, dataclass_names: frozenset[str] = frozenset()):
        self.path = path
        self.findings: list[Finding] = []
        self._dataclass_names = dataclass_names

    def visit_Call(self, node: ast.Call) -> None:
        # Skip common false positives: bool(), int(), str(), print(), assert*
        _SKIP = frozenset({"bool", "int", "str", "float", "print", "append", "assertEqual", "assertTrue", "assertFalse"})
        func_name = (
            node.func.id if isinstance(node.func, ast.Name)
            else node.func.attr if isinstance(node.func, ast.Attribute)
            else None
        )
        if func_name in _SKIP or (func_name and func_name.startswith("assert")):
            self.generic_visit(node)
            return

        # `setattr(obj, "flag", True)` — the third positional argument is the
        # value being assigned, not a behaviour-changing flag. The flag-arg
        # anti-pattern is about *function* boolean arguments, not data writes.
        if (
            isinstance(node.func, ast.Name)
            and node.func.id == "setattr"
            and len(node.args) == 3
        ):
            self.generic_visit(node)
            return

        # Constructor call to a module-level @dataclass class: positional bool
        # arguments here are field values, not flag-arguments. Dataclass init
        # signatures mirror the field declaration order, so the flag-arg
        # anti-pattern doesn't apply.
        if (
            isinstance(node.func, ast.Name)
            and node.func.id in self._dataclass_names
        ):
            self.generic_visit(node)
            return

        for arg in node.args:
            if isinstance(arg, ast.Constant) and isinstance(arg.value, bool):
                self.findings.append(Finding(
                    file=str(self.path),
                    line=arg.lineno,
                    col=arg.col_offset,
                    rule_id="PROOFCTL-Q-008",
                    rule_name="Boolean flag argument",
                    severity=Severity.WARNING,
                    message=(
                        f"Boolean literal passed as positional argument to "
                        f"'{func_name or 'function'}' — signals the function does two things"
                    ),
                    hint=(
                        "Split into two clearly named functions, or use a keyword argument: "
                        "func(reverse=True)."
                    ),
                    authority="Clean Code Ch. 3 – Flag Arguments",
                    docs_url="https://www.oreilly.com/library/view/clean-code-a/9780136083238/",
                ))
                break  # one finding per call site
        self.generic_visit(node)


# ── Q-009: print() in production code ────────────────────────────────────────

class _Q009Visitor(ast.NodeVisitor):
    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []
        # Track whether we're descending into an `if __name__ == "__main__":`
        # block — prints inside the script entry-point are conventionally fine.
        self._in_main_guard_depth = 0

    @staticmethod
    def _is_main_guard(node: ast.If) -> bool:
        test = node.test
        if not isinstance(test, ast.Compare):
            return False
        if len(test.ops) != 1 or not isinstance(test.ops[0], ast.Eq):
            return False
        left, right = test.left, test.comparators[0]
        # Match either side: `__name__ == "__main__"` or `"__main__" == __name__`.
        def _is_dunder(n: ast.expr) -> bool:
            return isinstance(n, ast.Name) and n.id == "__name__"

        def _is_main(n: ast.expr) -> bool:
            return isinstance(n, ast.Constant) and n.value == "__main__"

        return (_is_dunder(left) and _is_main(right)) or (_is_main(left) and _is_dunder(right))

    def visit_If(self, node: ast.If) -> None:
        if self._is_main_guard(node):
            self._in_main_guard_depth += 1
            try:
                self.generic_visit(node)
            finally:
                self._in_main_guard_depth -= 1
            return
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        if (
            self._in_main_guard_depth == 0
            and isinstance(node.func, ast.Name)
            and node.func.id == "print"
        ):
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-Q-009",
                rule_name="print() in production code",
                severity=Severity.INFO,
                message="print() used in production code — output goes to stdout unstructured",
                hint="Use logging.info() / logging.debug() so output is structured and level-filtered.",
                authority="12-Factor App XI – Logs / Google SRE Book",
                docs_url="https://12factor.net/logs",
            ))
        self.generic_visit(node)


def _q009_should_skip(path: Path, source: str) -> bool:
    """Return True if Q-009 should not run for this file.

    Skips: example/script/sample/demo directories, runnable scripts (shebang),
    and Jupyter notebooks (`.ipynb`).
    """
    if any(part in _Q009_SKIP_PATH_COMPONENTS for part in path.parts):
        return True
    if path.suffix == ".ipynb":
        return True
    if source.startswith("#!"):
        return True
    return False


# ── Main checker ──────────────────────────────────────────────────────────────

class QualityChecker(FileChecker):
    def __init__(
        self,
        any_threshold: int = 3,
        complexity_warn: int = 10,
        complexity_error: int = 20,
        func_len_warn: int = 50,
        func_len_error: int = 100,
        param_warn: int = 5,
        param_error: int = 7,
    ) -> None:
        self._any_threshold = any_threshold
        self._complexity_warn = complexity_warn
        self._complexity_error = complexity_error
        self._func_len_warn = func_len_warn
        self._func_len_error = func_len_error
        self._param_warn = param_warn
        self._param_error = param_error

    def check(self, path: Path, source: str, tree: ast.Module | None) -> list[Finding]:
        findings: list[Finding] = []
        if tree is not None:
            v1 = _Q001Visitor(path)
            v1.visit(tree)
            findings.extend(v1.findings)

            v2 = _Q002Visitor(path)
            v2.visit(tree)
            findings.extend(v2.findings)

            findings.extend(self._q003_ast(path, tree))

            v5 = _Q005Visitor(path, self._complexity_warn, self._complexity_error)
            v5.visit(tree)
            findings.extend(v5.findings)

            v6 = _Q006Visitor(path, self._func_len_warn, self._func_len_error)
            v6.visit(tree)
            findings.extend(v6.findings)

            v7 = _Q007Visitor(path, self._param_warn, self._param_error)
            v7.visit(tree)
            findings.extend(v7.findings)

            dataclass_names = frozenset(_collect_dataclass_names(tree))
            v8 = _Q008Visitor(path, dataclass_names=dataclass_names)
            v8.visit(tree)
            findings.extend(v8.findings)

            if not _is_test_file(path) and not _q009_should_skip(path, source):
                v9 = _Q009Visitor(path)
                v9.visit(tree)
                findings.extend(v9.findings)

            for AiVisitor in (_QAi001Visitor, _QAi002Visitor, _QAi003Visitor):
                v = AiVisitor(path)
                v.visit(tree)
                findings.extend(v.findings)

            for AiVisitor in (_QAi004Visitor, _QAi005Visitor, _QAi006Visitor, _QAi007Visitor, _QAi008Visitor):
                if AiVisitor is _QAi004Visitor and _is_test_file(path):
                    continue
                v = AiVisitor(path)
                v.visit(tree)
                findings.extend(v.findings)

        findings.extend(self._q003_type_ignore(path, source))
        return findings

    def _q003_ast(self, path: Path, tree: ast.Module) -> list[Finding]:
        v = _Q003Visitor(path)
        v.visit(tree)
        count = len(v.any_uses)
        if count > self._any_threshold:
            first = v.any_uses[0]
            return [Finding(
                file=str(path),
                line=getattr(first, "lineno", None),
                col=getattr(first, "col_offset", None),
                rule_id="PROOFCTL-Q-003",
                rule_name="Excessive Any type usage",
                severity=Severity.INFO,
                message=f"File uses Any {count} times (threshold: {self._any_threshold})",
                hint="Replace Any with specific types to maintain type safety.",
                authority="Effective Python Item 90 – Consider Static Analysis",
                docs_url="https://effectivepython.com/",
            )]
        return []

    def _q003_type_ignore(self, path: Path, source: str) -> list[Finding]:
        findings = []
        for lineno, line in enumerate(source.splitlines(), start=1):
            m = _ANY_IGNORE_RE.search(line)
            if m:
                findings.append(Finding(
                    file=str(path),
                    line=lineno,
                    col=m.start(),
                    rule_id="PROOFCTL-Q-003",
                    rule_name="Unexplained type: ignore",
                    severity=Severity.WARNING,
                    message="# type: ignore without a reason or error code",
                    hint="Add an error code: # type: ignore[import-untyped]",
                    authority="mypy docs – type: ignore comments",
                    docs_url="https://mypy.readthedocs.io/en/stable/inline_config.html#per-line-configuration",
                ))
        return findings


_ENUM_PHRASE_RE = re.compile(
    r"(?:must\s+be\s+(?:one\s+of)?|"
    r"valid\s+values?\s*(?:are|:)|"
    r"expected\s+one\s+of|"
    r"only\s+(?:supports?|allows?))",
    re.IGNORECASE,
)
_ENUM_LIST_RE = re.compile(
    r"[\[\(\{]([^\[\]\(\)\{\}]{2,200})[\]\)\}]"
)


def _phrase_implies_enum(s: str) -> bool:
    """Heuristic: this string is asserting membership in a fixed set."""
    return bool(_ENUM_PHRASE_RE.search(s)) and bool(_ENUM_LIST_RE.search(s))


def _format_str(node: ast.expr) -> str | None:
    """Best-effort recovery of a string literal or f-string template."""
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.JoinedStr):
        out: list[str] = []
        for v in node.values:
            if isinstance(v, ast.Constant) and isinstance(v.value, str):
                out.append(v.value)
            else:
                out.append("{}")
        return "".join(out)
    return None


class _QAi001Visitor(ast.NodeVisitor):
    """Q-AI-001 — Confabulated enum error message.

    `raise ValueError("x must be one of [a, b, c]")` where the surrounding
    block contains no membership check (`x in (...)`, `x not in (...)`,
    `match`/case against the same identifier). Strong AI-slop signature:
    model wrote the error before deciding the validation, then forgot to
    add the check.
    """

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def _has_membership_check(self, node_path: list[ast.AST]) -> bool:
        match_cls = getattr(ast, "Match", None)  # 3.10+ only
        for ancestor in reversed(node_path):
            for sub in ast.walk(ancestor):
                if isinstance(sub, ast.Compare):
                    for op in sub.ops:
                        if isinstance(op, (ast.In, ast.NotIn)):
                            return True
                if match_cls is not None and isinstance(sub, match_cls):
                    return True
        return False

    def visit(self, node: ast.AST) -> None:  # type: ignore[override]
        self._walk(node, [])

    def _walk(self, node: ast.AST, ancestors: list[ast.AST]) -> None:
        if isinstance(node, ast.Raise) and isinstance(node.exc, ast.Call):
            for arg in node.exc.args:
                msg = _format_str(arg)
                if msg and _phrase_implies_enum(msg):
                    if not self._has_membership_check(ancestors):
                        self.findings.append(Finding(
                            file=str(self.path),
                            line=node.lineno,
                            col=node.col_offset,
                            rule_id="PROOFCTL-Q-AI-001",
                            rule_name="Confabulated enum error message",
                            severity=Severity.WARNING,
                            message=(
                                f'raise with "{msg[:60]}" but no in/match check '
                                "for the value — likely AI-confabulated"
                            ),
                            hint="Add a membership check (`if x not in (...)` or `match x`) before the raise.",
                            authority="proofctl AI-slop heuristics",
                        ))
                        break
        for child in ast.iter_child_nodes(node):
            self._walk(child, ancestors + [node])


def _walk_skip_nested_functions(root: ast.AST) -> Iterator[ast.AST]:
    """ast.walk equivalent that does not descend into nested function/class defs.

    Required for rules that reason about a function's body — without this,
    a nested closure or method's return values pollute the outer function's
    analysis and produce false positives.
    """
    yield root
    for child in ast.iter_child_nodes(root):
        if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
            continue
        yield from _walk_skip_nested_functions(child)


_RETURN_TYPE_BUILTINS: dict[str, type] = {
    "int": int, "str": str, "bool": bool, "float": float, "bytes": bytes,
}


def _annotation_name(node: ast.expr) -> str | None:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    if isinstance(node, ast.Subscript):
        return _annotation_name(node.value)
    return None


def _expr_definitely_returns_type(node: ast.expr) -> str | None:
    """Heuristic: identify the literal type of `expr` when it's obvious.

    Returns one of "str", "int", "bool", "float", "bytes", "list", "dict",
    "tuple", "set", "generator" — or None when unknowable.
    """
    if isinstance(node, ast.Constant):
        v = node.value
        if isinstance(v, bool): return "bool"
        if isinstance(v, int): return "int"
        if isinstance(v, float): return "float"
        if isinstance(v, str): return "str"
        if isinstance(v, bytes): return "bytes"
        if v is None: return "None"
    if isinstance(node, ast.JoinedStr):
        return "str"
    if isinstance(node, ast.List):     return "list"
    if isinstance(node, ast.Dict):     return "dict"
    if isinstance(node, ast.Tuple):    return "tuple"
    if isinstance(node, ast.Set):      return "set"
    if isinstance(node, ast.GeneratorExp): return "generator"
    if isinstance(node, ast.ListComp): return "list"
    if isinstance(node, ast.DictComp): return "dict"
    if isinstance(node, ast.SetComp):  return "set"
    if isinstance(node, (ast.Compare, ast.UnaryOp)) and isinstance(getattr(node, "op", None), ast.Not):
        return "bool"
    if isinstance(node, ast.BinOp):
        if isinstance(node.op, ast.Mod) and isinstance(node.left, ast.Constant) and isinstance(node.left.value, str):
            return "str"
        if isinstance(node.op, ast.Add):
            lt = _expr_definitely_returns_type(node.left)
            rt = _expr_definitely_returns_type(node.right)
            if lt == rt and lt in ("str", "bytes", "list"):
                return lt
    return None


_COMPATIBLE: dict[str, frozenset[str]] = {
    "int": frozenset({"int", "bool"}),
    "float": frozenset({"int", "float", "bool"}),
    "bool": frozenset({"bool", "int"}),
    "str": frozenset({"str"}),
    "bytes": frozenset({"bytes"}),
    "list": frozenset({"list", "generator"}),
    "dict": frozenset({"dict"}),
    "tuple": frozenset({"tuple"}),
    "set": frozenset({"set"}),
}


class _QAi002Visitor(ast.NodeVisitor):
    """Q-AI-002 — Return type annotation contradicts the literal returned.

    `def f(x) -> int: return f"value: {x}"` — annotation says int, return is
    obviously a str. Common AI-slop pattern. Conservative: only fires when
    the annotation is a simple builtin AND the returned expression has an
    unambiguous literal type.
    """

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def _check_function(self, fn: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        if fn.returns is None:
            return
        ann = _annotation_name(fn.returns)
        if ann is None or ann not in _RETURN_TYPE_BUILTINS and ann not in {"list", "dict", "tuple", "set"}:
            return
        for node in _walk_skip_nested_functions(fn):
            if isinstance(node, ast.Return) and node.value is not None:
                actual = _expr_definitely_returns_type(node.value)
                if actual is None:
                    continue
                accepted = _COMPATIBLE.get(ann, frozenset({ann}))
                if actual not in accepted and actual != "None":
                    self.findings.append(Finding(
                        file=str(self.path),
                        line=node.lineno,
                        col=node.col_offset,
                        rule_id="PROOFCTL-Q-AI-002",
                        rule_name="Return annotation contradicts return value",
                        severity=Severity.ERROR,
                        message=(
                            f"function '{fn.name}' is annotated -> {ann} but "
                            f"returns a {actual} literal"
                        ),
                        hint=f"Either change the annotation to {actual} or fix the return.",
                        authority="proofctl AI-slop heuristics / PEP 484",
                    ))
                    return  # one finding per function

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check_function(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check_function(node)
        self.generic_visit(node)


class _QAi003Visitor(ast.NodeVisitor):
    """Q-AI-003 — Stale function parameter not plumbed through to inner call.

    `def f(*, timeout=30): self.client.get(url)` — `timeout` is exposed in
    the signature but never passed to the inner call that obviously accepts
    it. AI commonly wraps a library call but forgets to forward kwargs.
    """

    _SUSPECT_KWARGS = frozenset({
        "timeout", "verify", "cert", "auth", "headers", "params", "cookies",
        "proxies", "stream", "max_retries", "retries", "allow_redirects",
    })

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def _check_function(self, fn: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        # Collect kwargs in the signature that overlap _SUSPECT_KWARGS.
        kw_args: list[ast.arg] = list(fn.args.kwonlyargs)
        # Defaulted positional args also count as "exposed kwargs"
        positional = fn.args.args + fn.args.posonlyargs
        defaulted_positional = positional[len(positional) - len(fn.args.defaults):]
        kw_args.extend(defaulted_positional)

        suspect = {a.arg for a in kw_args if a.arg in self._SUSPECT_KWARGS}
        if not suspect:
            return

        # Walk the body looking for Call nodes and collect kwargs that ARE passed.
        passed: set[str] = set()
        ref_lines: dict[str, int] = {}
        for node in _walk_skip_nested_functions(fn):
            if isinstance(node, ast.Call):
                for kw in node.keywords:
                    if kw.arg in suspect:
                        passed.add(kw.arg)
                    # Also handle **kwargs spread — defensive: assume it forwards.
                    if kw.arg is None:
                        passed.update(suspect)
            if isinstance(node, ast.Name) and node.id in suspect:
                ref_lines.setdefault(node.id, node.lineno)

        unused = suspect - passed
        # Filter further: only fire if the param is referenced *nowhere* in body.
        truly_unused = {p for p in unused if p not in ref_lines}
        if truly_unused:
            for arg in kw_args:
                if arg.arg in truly_unused:
                    self.findings.append(Finding(
                        file=str(self.path),
                        line=arg.lineno,
                        col=arg.col_offset,
                        rule_id="PROOFCTL-Q-AI-003",
                        rule_name="Stale parameter not forwarded",
                        severity=Severity.WARNING,
                        message=(
                            f"function '{fn.name}' takes '{arg.arg}' but never "
                            "forwards it to any inner call"
                        ),
                        hint=f"Pass {arg.arg}={arg.arg} to the inner call, or remove the parameter.",
                        authority="proofctl AI-slop heuristics",
                    ))
                    break  # one finding per function

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check_function(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check_function(node)
        self.generic_visit(node)


_QAI004_SKIP_BASE_NAMES = frozenset({
    "ABC", "BaseModel", "Protocol", "Generic", "Enum", "IntEnum", "StrEnum",
    "Flag", "IntFlag", "Exception", "BaseException", "NamedTuple", "TypedDict",
})
_QAI004_SKIP_DECORATORS = frozenset({"dataclass", "attr", "attrs", "define", "frozen"})


def _qai004_base_name(b: ast.expr) -> str | None:
    if isinstance(b, ast.Name):
        return b.id
    if isinstance(b, ast.Attribute):
        return b.attr
    if isinstance(b, ast.Subscript):
        return _qai004_base_name(b.value)
    return None


def _qai004_decorator_name(d: ast.expr) -> str | None:
    if isinstance(d, ast.Name):
        return d.id
    if isinstance(d, ast.Attribute):
        return d.attr
    if isinstance(d, ast.Call):
        return _qai004_decorator_name(d.func)
    return None


def _stmt_count_skip_doc(body: list[ast.stmt]) -> int:
    if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) and isinstance(body[0].value.value, str):
        return len(body) - 1
    return len(body)


class _QAi004Visitor(ast.NodeVisitor):
    """Q-AI-004 — Single-method class is over-engineered abstraction."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def _check(self, node: ast.ClassDef) -> None:
        for base in node.bases:
            name = _qai004_base_name(base)
            if name in _QAI004_SKIP_BASE_NAMES:
                return
            if name and name.endswith("Error"):
                return
        for dec in node.decorator_list:
            if _qai004_decorator_name(dec) in _QAI004_SKIP_DECORATORS:
                return

        public_methods: list[ast.FunctionDef | ast.AsyncFunctionDef] = []
        dunder_methods: list[ast.FunctionDef | ast.AsyncFunctionDef] = []
        for stmt in node.body:
            if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if stmt.name.startswith("__") and stmt.name.endswith("__"):
                    dunder_methods.append(stmt)
                elif stmt.name.startswith("_"):
                    return  # private helper means class is more than just the public method
                else:
                    public_methods.append(stmt)
            elif isinstance(stmt, (ast.Assign, ast.AnnAssign)):
                return  # class-level attributes
            elif isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Constant) and isinstance(stmt.value.value, str):
                continue  # docstring
            elif isinstance(stmt, ast.Pass):
                continue
            else:
                return

        if len(public_methods) != 1:
            return
        if len(dunder_methods) > 1:
            return
        if dunder_methods and dunder_methods[0].name != "__init__":
            return

        method = public_methods[0]
        if _stmt_count_skip_doc(method.body) > 5:
            return
        # ast.NodeVisitor subclasses dispatch via visit_*/generic_visit hooks.
        # A single visit_* method is the polymorphic protocol, not over-abstraction.
        if method.name.startswith("visit_") or method.name == "generic_visit":
            return

        self.findings.append(Finding(
            file=str(self.path),
            line=node.lineno,
            col=node.col_offset,
            rule_id="PROOFCTL-Q-AI-004",
            rule_name="Single-method class",
            severity=Severity.INFO,
            message=(
                f"class '{node.name}' has only one method '{method.name}' — "
                "likely over-engineered, a function would suffice"
            ),
            hint="Replace with a module-level function unless polymorphism is planned.",
            authority="proofctl AI-slop heuristics",
        ))


def _expr_can_be_none(node: ast.expr) -> bool:
    if isinstance(node, ast.Constant) and node.value is None:
        return True
    if isinstance(node, ast.IfExp):
        return _expr_can_be_none(node.body) or _expr_can_be_none(node.orelse)
    return False


def _annotation_mentions_none(node: ast.expr) -> bool:
    if isinstance(node, ast.Constant) and node.value is None:
        return True
    if isinstance(node, ast.Name) and node.id == "None":
        return True
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.BitOr):
        return _annotation_mentions_none(node.left) or _annotation_mentions_none(node.right)
    if isinstance(node, ast.Subscript):
        v = node.value
        outer = v.id if isinstance(v, ast.Name) else (v.attr if isinstance(v, ast.Attribute) else None)
        if outer == "Optional":
            return True
        if outer in {"Union", "Tuple", "tuple"}:
            slc = node.slice
            if isinstance(slc, ast.Tuple):
                return any(_annotation_mentions_none(e) for e in slc.elts)
            return _annotation_mentions_none(slc)
    return False


class _QAi005Visitor(ast.NodeVisitor):
    """Q-AI-005 — Defensive guard for impossible state."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        init = None
        for stmt in node.body:
            if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef)) and stmt.name == "__init__":
                init = stmt
                break
        if init is not None:
            non_none_attrs = self._unconditional_non_none_attrs(init)
            for stmt in node.body:
                if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    self._check_method(stmt, non_none_attrs)
        self.generic_visit(node)

    def _unconditional_non_none_attrs(self, init: ast.FunctionDef | ast.AsyncFunctionDef) -> set[str]:
        # Only assignments at the top level of __init__'s body (not inside if/try/for).
        nullable_params = self._nullable_param_names(init)
        attrs: set[str] = set()
        for stmt in init.body:
            if isinstance(stmt, ast.Assign):
                for target in stmt.targets:
                    name = self._self_attr_name(target)
                    if name and not _expr_can_be_none(stmt.value) and not self._refs_nullable(stmt.value, nullable_params):
                        attrs.add(name)
            elif isinstance(stmt, ast.AnnAssign) and stmt.value is not None:
                name = self._self_attr_name(stmt.target)
                if name and not _expr_can_be_none(stmt.value) and not self._refs_nullable(stmt.value, nullable_params):
                    attrs.add(name)
        return attrs

    @staticmethod
    def _nullable_param_names(fn: ast.FunctionDef | ast.AsyncFunctionDef) -> set[str]:
        """Parameters whose default is None or annotation includes None/Optional."""
        names: set[str] = set()
        positional = list(fn.args.args) + list(fn.args.posonlyargs)
        defaults = fn.args.defaults
        defaulted = positional[len(positional) - len(defaults):] if defaults else []
        for arg, default in zip(defaulted, defaults):
            if isinstance(default, ast.Constant) and default.value is None:
                names.add(arg.arg)
        for arg, default in zip(fn.args.kwonlyargs, fn.args.kw_defaults or []):
            if isinstance(default, ast.Constant) and default.value is None:
                names.add(arg.arg)
        # Also include any param annotated with `... | None` or `Optional[...]`.
        for arg in positional + list(fn.args.kwonlyargs):
            if arg.annotation is not None and _annotation_mentions_none(arg.annotation):
                names.add(arg.arg)
        return names

    @staticmethod
    def _refs_nullable(expr: ast.expr, nullable: set[str]) -> bool:
        if isinstance(expr, ast.Name):
            return expr.id in nullable
        return False

    @staticmethod
    def _self_attr_name(node: ast.AST) -> str | None:
        if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name) and node.value.id == "self":
            return node.attr
        return None

    def _check_method(
        self,
        method: ast.FunctionDef | ast.AsyncFunctionDef,
        attrs: set[str],
    ) -> None:
        if not attrs:
            return
        for sub in _walk_skip_nested_functions(method):
            if isinstance(sub, ast.If):
                self._check_test(sub.test, attrs, method.name)

    def _check_test(self, test: ast.expr, attrs: set[str], method_name: str) -> None:
        # hasattr(self, 'x')
        if isinstance(test, ast.Call) and isinstance(test.func, ast.Name) and test.func.id == "hasattr":
            if len(test.args) >= 2 and isinstance(test.args[0], ast.Name) and test.args[0].id == "self":
                lit = test.args[1]
                if isinstance(lit, ast.Constant) and isinstance(lit.value, str) and lit.value in attrs:
                    self._fire(test, f"hasattr(self, '{lit.value}')", lit.value)
                    return
        # self.x is None / is not None
        if isinstance(test, ast.Compare) and len(test.ops) == 1 and len(test.comparators) == 1:
            op = test.ops[0]
            if isinstance(op, (ast.Is, ast.IsNot)):
                attr = self._self_attr(test.left)
                comp = test.comparators[0]
                if attr in attrs and isinstance(comp, ast.Constant) and comp.value is None:
                    word = "is None" if isinstance(op, ast.Is) else "is not None"
                    self._fire(test, f"self.{attr} {word}", attr)
        # combined boolean: walk subexpressions
        if isinstance(test, ast.BoolOp):
            for v in test.values:
                self._check_test(v, attrs, method_name)
        if isinstance(test, ast.UnaryOp) and isinstance(test.op, ast.Not):
            self._check_test(test.operand, attrs, method_name)

    @staticmethod
    def _self_attr(node: ast.AST) -> str | None:
        if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name) and node.value.id == "self":
            return node.attr
        return None

    def _fire(self, node: ast.AST, check: str, attr: str) -> None:
        self.findings.append(Finding(
            file=str(self.path),
            line=getattr(node, "lineno", 0),
            col=getattr(node, "col_offset", 0),
            rule_id="PROOFCTL-Q-AI-005",
            rule_name="Defensive guard for impossible state",
            severity=Severity.WARNING,
            message=(
                f"defensive check '{check}' — '{attr}' is unconditionally set in __init__"
            ),
            hint="Remove the redundant guard, or move the assignment under a condition.",
            authority="proofctl AI-slop heuristics",
        ))


def _handler_logs_or_reraises(handler: ast.ExceptHandler) -> bool:
    for stmt in handler.body:
        if isinstance(stmt, ast.Raise):
            return True
        if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call):
            func = stmt.value.func
            name = func.attr if isinstance(func, ast.Attribute) else (func.id if isinstance(func, ast.Name) else None)
            if name and any(t in name.lower() for t in ("log", "print", "warn", "error", "debug", "info", "exception")):
                return True
    return False


def _is_broad_exception(t: ast.expr | None) -> bool:
    if t is None:
        return True  # bare except
    if isinstance(t, ast.Name) and t.id in {"Exception", "BaseException"}:
        return True
    if isinstance(t, ast.Attribute) and t.attr in {"Exception", "BaseException"}:
        return True
    return False


class _QAi006Visitor(ast.NodeVisitor):
    """Q-AI-006 — Generic exception swallowed silently."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Try(self, node: ast.Try) -> None:
        for i, h in enumerate(node.handlers):
            if not _is_broad_exception(h.type):
                continue
            if not (len(h.body) == 1 and isinstance(h.body[0], ast.Pass)):
                continue
            if _handler_logs_or_reraises(h):
                continue
            is_bare = h.type is None
            has_specific_before = any(
                not _is_broad_exception(prev.type) for prev in node.handlers[:i]
            )
            if is_bare:
                severity = Severity.ERROR
                handler_repr = "bare except"
            elif has_specific_before:
                severity = Severity.INFO
                handler_repr = "except Exception"
            else:
                severity = Severity.WARNING
                handler_repr = "except Exception"
            self.findings.append(Finding(
                file=str(self.path),
                line=h.lineno,
                col=h.col_offset,
                rule_id="PROOFCTL-Q-AI-006",
                rule_name="Empty exception handler",
                severity=severity,
                message=f"empty {handler_repr} swallows all errors silently",
                hint="Catch a specific exception, or log the error before continuing.",
                authority="proofctl AI-slop heuristics",
            ))
        self.generic_visit(node)


_QAI007_SKIP_DECORATORS = frozenset({"override", "abstractmethod", "classmethod", "wraps"})


class _QAi007Visitor(ast.NodeVisitor):
    """Q-AI-007 — Sprawling unused kwargs."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def _check(self, fn: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        if fn.name.startswith("__") and fn.name.endswith("__"):
            return
        for dec in fn.decorator_list:
            name = _qai004_decorator_name(dec)
            if name in _QAI007_SKIP_DECORATORS:
                return

        # If the function declares **kwargs, defensively assume forwarding and skip.
        if fn.args.kwarg is not None:
            return

        kw_args: list[ast.arg] = list(fn.args.kwonlyargs)
        positional = list(fn.args.args) + list(fn.args.posonlyargs)
        defaulted_positional = positional[len(positional) - len(fn.args.defaults):] if fn.args.defaults else []
        kw_args.extend(defaulted_positional)

        if len(kw_args) < 4:
            return

        names = {a.arg for a in kw_args}
        used: set[str] = set()
        kwargs_spread = False
        for sub in _walk_skip_nested_functions(fn):
            if isinstance(sub, ast.Name) and sub.id in names:
                used.add(sub.id)
            if isinstance(sub, ast.Call):
                for kw in sub.keywords:
                    if kw.arg is None:
                        kwargs_spread = True
                    elif kw.arg in names:
                        used.add(kw.arg)

        if kwargs_spread:
            return

        unused = sorted(names - used)
        if len(unused) >= 2:
            self.findings.append(Finding(
                file=str(self.path),
                line=fn.lineno,
                col=fn.col_offset,
                rule_id="PROOFCTL-Q-AI-007",
                rule_name="Sprawling unused kwargs",
                severity=Severity.INFO,
                message=(
                    f"function '{fn.name}' has {len(unused)} unused kwargs "
                    f"({', '.join(unused)}) — configuration sprawl"
                ),
                hint="Drop unused kwargs from the signature.",
                authority="proofctl AI-slop heuristics",
            ))


_QAI008_DOC_PHRASES = ("returns the ", "returns ", "return the ", "return ", "get the ", "gets the ", "the ")


class _QAi008Visitor(ast.NodeVisitor):
    """Q-AI-008 — Trivial accessor with echo docstring."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        for stmt in node.body:
            if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self._check_method(stmt)
        self.generic_visit(node)

    def _check_method(self, fn: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        if len(fn.body) != 2:
            return
        doc = fn.body[0]
        ret = fn.body[1]
        if not (isinstance(doc, ast.Expr) and isinstance(doc.value, ast.Constant) and isinstance(doc.value.value, str)):
            return
        if not isinstance(ret, ast.Return) or ret.value is None:
            return
        if not isinstance(ret.value, ast.Attribute):
            return
        if not (isinstance(ret.value.value, ast.Name) and ret.value.value.id == "self"):
            return
        attr = ret.value.attr
        first_line = doc.value.value.strip().splitlines()[0].strip().lower() if doc.value.value.strip() else ""
        if attr.lower() not in first_line:
            return
        # Require a typical accessor phrasing to avoid catching genuinely useful docstrings.
        if not any(p in first_line for p in _QAI008_DOC_PHRASES):
            return
        self.findings.append(Finding(
            file=str(self.path),
            line=fn.lineno,
            col=fn.col_offset,
            rule_id="PROOFCTL-Q-AI-008",
            rule_name="Trivial accessor with echo docstring",
            severity=Severity.INFO,
            message=(
                f"method '{fn.name}' is a trivial accessor with echo docstring — "
                "remove or use @property"
            ),
            hint="Drop the boilerplate docstring, or expose the attribute directly.",
            authority="proofctl AI-slop heuristics",
        ))


class AbstractionChecker(DirectoryChecker):
    """PROOFCTL-Q-004: Abstract classes with only one concrete implementation."""

    def check(self, root: Path, py_files: list[Path]) -> list[Finding]:
        abstract_classes: dict[str, _AbstractClassInfo] = {}
        all_classes: dict[str, list[str]] = {}  # class_name -> list of base names

        # TODO(perf): re-parses every Python file from disk even though the
        # engine already parsed each tree once for FileChecker passes. Proper
        # fix requires extending the DirectoryChecker API to receive parsed
        # trees from the engine; deferred to a separate PR.
        # Audit reference: AUDIT_AND_ROADMAP.md §1.3 — AbstractionChecker re-parse.
        for path in py_files:
            try:
                source = path.read_text(encoding="utf-8", errors="replace")
                tree = ast.parse(source)
            except (OSError, SyntaxError):
                continue

            for node in ast.walk(tree):
                if not isinstance(node, ast.ClassDef):
                    continue
                info = _AbstractClassInfo(node, str(path))
                if info.is_abc:
                    abstract_classes[info.name] = info
                else:
                    base_names = list(info.bases)
                    all_classes[info.name] = base_names

        findings = []
        for abc_name, abc_info in abstract_classes.items():
            if "Protocol" in abc_info.bases:
                continue
            implementors = [
                name for name, bases in all_classes.items()
                if abc_name in bases
            ]
            if len(implementors) == 1:
                findings.append(Finding(
                    file=abc_info.file,
                    line=abc_info.node.lineno,
                    col=abc_info.node.col_offset,
                    rule_id="PROOFCTL-Q-004",
                    rule_name="Single-implementation abstraction",
                    severity=Severity.INFO,
                    message=(
                        f"Abstract class '{abc_name}' has exactly one concrete "
                        f"implementation ('{implementors[0]}')"
                    ),
                    hint=(
                        "If no second implementation is planned, simplify to a "
                        "concrete class. YAGNI."
                    ),
                    authority="A Philosophy of Software Design – Deep Modules",
                    docs_url="https://web.stanford.edu/~ouster/cgi-bin/book.php",
                ))
        return findings
