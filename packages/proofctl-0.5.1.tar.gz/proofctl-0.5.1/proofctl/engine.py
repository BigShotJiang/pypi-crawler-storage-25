"""Scan-and-dispatch engine.

This module is the orchestration layer. It is responsible for:

  - discovering files (full walk or `--changed-only` from git),
  - excluding files via gitignore-style patterns,
  - building per-format suppression maps from `# proofctl: ignore[…]` comments,
  - dispatching each file/format to the right checker,
  - normalising Finding objects (relative path, severity overrides, disabled
    rules) and deduplicating them,
  - converting checker exceptions into PROOFCTL-INTERNAL-001 findings so silent
    failures are visible (and `--strict` escalates them to ERROR).
"""
from __future__ import annotations

import ast
import dataclasses
import re
import subprocess
from pathlib import Path
from typing import Iterable

import rich.console

from ._globmatch import compile_globs
from .config import ProofctlConfig
from .models import Finding, Severity
from .checkers.placeholders import PlaceholderChecker
from .checkers.leakage import LeakageChecker
from .checkers.quality import QualityChecker, AbstractionChecker
from .checkers.imports import ImportChecker, MethodChecker, DependencyChecker
from .checkers.variants import VariantChecker
from .checkers.security import SecurityChecker
from .checkers.llm_integration import LLMChecker
from .checkers.terraform import TerraformChecker, TerraformDirChecker
from .checkers.terragrunt import TerragruntChecker
from .checkers.dockerfile import DockerfileRulesChecker
from .checkers.yaml_checker import YamlRulesChecker
from .checkers.shell_checker import ShellRulesChecker
from .checkers.secrets import SecretChecker

console = rich.console.Console(stderr=True)

# Inline suppression: works in any language whose comment starts with `#`.
_SUPPRESS_HASH_RE = re.compile(r"#\s*proofctl:\s*ignore\[([^\]]*)\]")
# Terraform / Terragrunt also accept `//` comments.
_SUPPRESS_DSLASH_RE = re.compile(r"//\s*proofctl:\s*ignore\[([^\]]*)\]")


def _load_suppressions(source: str, *, also_double_slash: bool = False) -> dict[int, set[str]]:
    """Returns {1-based lineno: {rule_id, ...}} for every inline-suppress comment.

    `also_double_slash` adds support for `//`-style comments used by HCL.
    """
    result: dict[int, set[str]] = {}
    patterns: list[re.Pattern[str]] = [_SUPPRESS_HASH_RE]
    if also_double_slash:
        patterns.append(_SUPPRESS_DSLASH_RE)
    for lineno, line in enumerate(source.splitlines(), start=1):
        for pat in patterns:
            m = pat.search(line)
            if not m:
                continue
            rule_ids = {r.strip() for r in m.group(1).split(",") if r.strip()}
            if rule_ids:
                result.setdefault(lineno, set()).update(rule_ids)
    return result


def _is_suppressed(f: Finding, suppressions: dict[str, dict[int, set[str]]]) -> bool:
    if f.line is None:
        return False
    file_supps = suppressions.get(f.file)
    if not file_supps:
        return False
    return f.rule_id in file_supps.get(f.line, set())


def _changed_files_all(root: Path) -> list[Path]:
    """Return every changed path according to git, of any extension.

    Tries `git diff --name-only HEAD` first, then falls back through common
    branch names. Returns [] if git is missing or no diff is available.
    """
    bases = ("HEAD", "main", "master", "origin/main", "origin/master")
    for base in bases:
        try:
            result = subprocess.run(
                ["git", "diff", "--name-only", base],
                capture_output=True, text=True, cwd=root,
            )
        except FileNotFoundError:
            return []  # git not installed — degrade gracefully
        if result.returncode == 0:
            return [
                p for f in result.stdout.splitlines()
                if (p := (root / f.strip())).is_file()
            ]
    return []


def _build_file_checkers(
    config: ProofctlConfig,
    families: set[str] | None,
    scan_root: Path | None = None,
) -> list:
    checkers = []

    def _include(family: str) -> bool:
        return families is None or family in families

    if _include("P"):
        checkers.append(PlaceholderChecker(
            todo_allowed_formats=config.todo_allowed_formats,
            todo_exclude_paths=config.todo_exclude_paths,
        ))
    if _include("L"):
        checkers.append(LeakageChecker(
            l001_strict_idioms=config.l001_strict_idioms,
        ))
    if _include("Q"):
        checkers.append(QualityChecker(any_threshold=config.any_threshold))
    if _include("I"):
        checkers.append(ImportChecker(
            local_namespaces=config.local_namespaces,
            extra_indexes=config.pypi_extra_indexes,
            check_pypi=config.check_pypi,
            scan_root=scan_root,
        ))
    if _include("S"):
        checkers.append(SecurityChecker())
    if _include("LLM"):
        checkers.append(LLMChecker())
    return checkers


def _build_dir_checkers(config: ProofctlConfig, families: set[str] | None) -> list:
    checkers = []

    def _include(family: str) -> bool:
        return families is None or family in families

    if _include("V"):
        checkers.append(VariantChecker(
            similarity_threshold=config.similarity_threshold,
            min_lines=config.similarity_min_lines,
        ))
    if _include("Q"):
        checkers.append(AbstractionChecker())
    if _include("I"):
        checkers.append(DependencyChecker(
            extra_high_risk=config.i002_extra_high_risk,
        ))
    if _include("M"):
        checkers.append(MethodChecker())

    return checkers


def _build_hcl_file_checkers(config: ProofctlConfig, families: set[str] | None) -> list:
    checkers = []

    def _include(family: str) -> bool:
        return families is None or family in families

    if _include("TF"):
        checkers.append(TerraformChecker(required_labels=config.tf_required_labels))
    if _include("TG"):
        checkers.append(TerragruntChecker())

    return checkers


def _build_hcl_dir_checkers(config: ProofctlConfig, families: set[str] | None) -> list:
    checkers = []

    def _include(family: str) -> bool:
        return families is None or family in families

    if _include("TF"):
        checkers.append(TerraformDirChecker())

    return checkers


def _build_dockerfile_checkers(config: ProofctlConfig, families: set[str] | None) -> list:
    checkers = []
    if families is None or "DF" in families:
        checkers.append(DockerfileRulesChecker())
    return checkers


def _build_yaml_checkers(config: ProofctlConfig, families: set[str] | None) -> list:
    checkers = []
    if families is None or "YAML" in families:
        checkers.append(YamlRulesChecker())
    return checkers


def _build_shell_checkers(config: ProofctlConfig, families: set[str] | None) -> list:
    checkers = []
    if families is None or "SH" in families:
        checkers.append(ShellRulesChecker())
    return checkers


def _build_secret_checkers(config: ProofctlConfig, families: set[str] | None) -> list:
    checkers = []
    if families is None or "SECRET" in families:
        checkers.append(SecretChecker())
    return checkers


_DOCKERFILE_RE = re.compile(r"^Dockerfile(\..*)?$")
_HCL_EXTS = (".tf", ".tfvars", ".hcl")
_YAML_EXTS = (".yml", ".yaml")
_SHELL_EXTS = (".sh", ".bash", ".zsh", ".ksh")
# Terraform template files. We classify by content: a .tftpl whose
# rendered output is a shell script (shebang #!/bin/bash, #!/bin/sh,
# /usr/bin/env bash, etc.) should be scanned by the SH rules so the
# template's shell content participates in lint / secret / pattern
# checks even though it's stored as a Terraform template.
_TFTPL_EXTS = (".tftpl",)
_SHELL_SHEBANG_RE = re.compile(
    rb'^\s*#!\s*(?:'
    rb'/(?:usr/local/|usr/)?bin/'                # /bin/, /usr/bin/, /usr/local/bin/
    rb'|/usr/bin/env\s+'                         # /usr/bin/env <name>
    rb')(?:ba|z|k|ash|d)?sh\b'                   # sh / bash / zsh / ksh / ash / dash
)


def _classify(path: Path) -> str | None:
    """Map a path to its scan kind, or None if unhandled."""
    if path.suffix == ".py":
        return "py"
    if path.suffix in _HCL_EXTS:
        return "hcl"
    if path.suffix in _YAML_EXTS:
        return "yaml"
    if path.suffix in _SHELL_EXTS:
        return "shell"
    if path.suffix in _TFTPL_EXTS and _is_shell_template(path):
        return "shell"
    if _DOCKERFILE_RE.match(path.name):
        return "dockerfile"
    return None


def _is_shell_template(path: Path) -> bool:
    """True iff a `.tftpl` file looks like a shell-script template.

    Cheapest possible check: read up to 128 bytes and match a shell
    shebang. We don't try to actually render the template — variables
    like ``${var.x}`` may sit between the shebang and the script body,
    but the shebang itself is on line 1 either way.
    """
    try:
        with path.open("rb") as f:
            head = f.read(128)
    except OSError:
        return False
    return bool(_SHELL_SHEBANG_RE.match(head))


def _internal_finding(
    *, scope: str, path: Path | None, exc: BaseException, strict: bool,
) -> Finding:
    """Convert a checker crash into a visible finding (PROOFCTL-INTERNAL-001).

    Without this, a broken checker is indistinguishable from a clean file. The
    finding is INFO by default; `--strict` escalates to ERROR so CI fails.
    """
    severity = Severity.ERROR if strict else Severity.INFO
    where = path.name if path is not None else "<directory checker>"
    short = f"{type(exc).__name__}: {exc}"
    return Finding(
        file=str(path) if path is not None else "<engine>",
        line=None,
        col=None,
        rule_id="PROOFCTL-INTERNAL-001",
        rule_name="Checker raised an exception",
        severity=severity,
        message=f"{scope} crashed on {where} — {short}",
        hint="File a bug report with the offending file. Use --strict to fail CI on internal errors.",
        authority="proofctl internal",
        docs_url="",
    )


def run_check(
    root: Path,
    config: ProofctlConfig,
    changed_only: bool = False,
    families: list[str] | None = None,
    min_severity: str | None = None,
    strict: bool = False,
) -> list[Finding]:
    fam_set = {f.upper() for f in families} if families else None
    excluded = compile_globs(config.exclude_paths)

    # ── 1. Discover candidates: walk-once or git-diff-once. ──────────────────
    if changed_only:
        candidates = _changed_files_all(root)
    else:
        candidates = [p for p in root.rglob("*") if p.is_file()]

    # ── 2. Apply excludes once with the gitignore matcher. ───────────────────
    def _rel_posix(p: Path) -> str:
        try:
            return p.relative_to(root).as_posix()
        except ValueError:
            return p.as_posix()

    candidates = [p for p in candidates if not excluded(_rel_posix(p))]

    # ── 3. Classify by kind. ─────────────────────────────────────────────────
    by_kind: dict[str, list[Path]] = {
        "py": [], "hcl": [], "yaml": [], "shell": [], "dockerfile": [],
    }
    for p in candidates:
        kind = _classify(p)
        if kind is not None:
            by_kind[kind].append(p)

    # ── 4. Build per-format checker lists. ───────────────────────────────────
    file_checkers = _build_file_checkers(config, fam_set, scan_root=root)
    dir_checkers = _build_dir_checkers(config, fam_set)
    hcl_file_checkers = _build_hcl_file_checkers(config, fam_set)
    hcl_dir_checkers = _build_hcl_dir_checkers(config, fam_set)
    dockerfile_checkers = _build_dockerfile_checkers(config, fam_set)
    yaml_checkers = _build_yaml_checkers(config, fam_set)
    shell_checkers = _build_shell_checkers(config, fam_set)
    secret_checkers = _build_secret_checkers(config, fam_set)

    # ── 5. Build suppression map for ALL formats up-front (H-4). ─────────────
    # Keys are POSIX-relative paths that match what `_normalise` produces, so
    # `_is_suppressed` can do a direct lookup regardless of OS path separator.
    suppressions: dict[str, dict[int, set[str]]] = {}
    sources: dict[Path, str] = {}  # cache to avoid re-reading each file

    def _read(path: Path) -> str | None:
        cached = sources.get(path)
        if cached is not None:
            return cached
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return None
        sources[path] = text
        return text

    for kind, paths in by_kind.items():
        # HCL accepts both `#` and `//` comments. Other formats only `#`.
        also_dslash = (kind == "hcl")
        for path in paths:
            text = _read(path)
            if text is None:
                continue
            supps = _load_suppressions(text, also_double_slash=also_dslash)
            if supps:
                suppressions[_rel_posix(path)] = supps

    # ── 6. Run all checkers, with shared exception-→-finding handling. ───────
    findings: list[Finding] = []
    seen: set[tuple] = set()

    def _ingest(raw: Iterable[Finding]) -> None:
        for f in raw:
            f = _normalise(f, root, config)
            if f is None:
                continue
            if _is_suppressed(f, suppressions):
                continue
            key = f.dedup_key()
            if key not in seen:
                seen.add(key)
                findings.append(f)

    def _safe_file_check(checker, path: Path, *args, scope: str) -> Iterable[Finding]:
        try:
            return checker.check(path, *args)
        except Exception as exc:
            console.print(
                f"[dim]{scope} error ({type(checker).__name__} on {path.name}): {exc}[/dim]"
            )
            return [_internal_finding(scope=scope, path=path, exc=exc, strict=strict)]

    def _safe_dir_check(checker, paths: list[Path], scope: str) -> Iterable[Finding]:
        try:
            return checker.check(root, paths)
        except Exception as exc:
            console.print(f"[dim]{scope} error ({type(checker).__name__}): {exc}[/dim]")
            return [_internal_finding(scope=scope, path=None, exc=exc, strict=strict)]

    # Python (file checkers + AST parsing)
    for path in by_kind["py"]:
        source = _read(path)
        if source is None:
            continue
        try:
            tree: ast.Module | None = ast.parse(source, filename=str(path))
        except SyntaxError:
            tree = None
        for checker in file_checkers:
            _ingest(_safe_file_check(checker, path, source, tree, scope="checker"))

    # Python directory-level checkers (variants, abstraction, deps, mypy)
    for checker in dir_checkers:
        _ingest(_safe_dir_check(checker, by_kind["py"], scope="dir-checker"))

    # HCL
    for path in by_kind["hcl"]:
        source = _read(path)
        if source is None:
            continue
        for checker in hcl_file_checkers:
            if checker.extensions and path.suffix not in checker.extensions:
                continue
            _ingest(_safe_file_check(checker, path, source, scope="HCL checker"))

    for checker in hcl_dir_checkers:
        _ingest(_safe_dir_check(checker, by_kind["hcl"], scope="HCL dir-checker"))

    # Dockerfile
    for path in by_kind["dockerfile"]:
        source = _read(path)
        if source is None:
            continue
        for checker in dockerfile_checkers:
            _ingest(_safe_file_check(checker, path, source, scope="Dockerfile checker"))

    # YAML
    for path in by_kind["yaml"]:
        source = _read(path)
        if source is None:
            continue
        for checker in yaml_checkers:
            _ingest(_safe_file_check(checker, path, source, scope="YAML checker"))

    # Shell
    for path in by_kind["shell"]:
        source = _read(path)
        if source is None:
            continue
        for checker in shell_checkers:
            _ingest(_safe_file_check(checker, path, source, scope="Shell checker"))

    # Secrets — run on every candidate file (not just classified kinds)
    if secret_checkers:
        for path in candidates:
            source = _read(path)
            if source is None:
                continue
            for checker in secret_checkers:
                _ingest(_safe_file_check(checker, path, source, None, scope="Secret checker"))

    # ── 7. Severity floor + final ordering. ──────────────────────────────────
    if min_severity:
        floor = Severity.from_str(min_severity)
        findings = [f for f in findings if f.severity >= floor]

    findings = _dedup_overlapping(findings)

    if config.internal_identifiers:
        sources_by_rel = {_rel_posix(p): text for p, text in sources.items()}
        findings = _filter_internal_identifiers(
            findings, sources_by_rel, config.internal_identifiers
        )

    sorted_findings = sorted(findings, key=lambda x: (-x.severity, x.file, x.line or 0))

    return sorted_findings


def _filter_internal_identifiers(
    findings: list[Finding],
    sources_by_rel: dict[str, str],
    identifiers: list[str],
) -> list[Finding]:
    """Drop name-shaped findings whose source line contains a known internal identifier.

    Real security rules (S-001 SQL injection, S-005 eval, etc.) are unaffected —
    only rules listed in INTERNAL_ID_AFFECTED_PREFIXES can be suppressed this way.
    """
    from .config import rule_id_affected_by_internal_identifiers
    if not identifiers:
        return findings

    line_cache: dict[tuple[str, int], str] = {}

    def _line_for(file: str, line: int | None) -> str:
        if line is None or line <= 0:
            return ""
        key = (file, line)
        cached = line_cache.get(key)
        if cached is not None:
            return cached
        text = sources_by_rel.get(file)
        if text is None:
            line_cache[key] = ""
            return ""
        lines = text.splitlines()
        result = lines[line - 1] if 0 <= line - 1 < len(lines) else ""
        line_cache[key] = result
        return result

    out: list[Finding] = []
    for f in findings:
        if rule_id_affected_by_internal_identifiers(f.rule_id):
            line_text = _line_for(f.file, f.line)
            if line_text and any(token in line_text for token in identifiers):
                continue
        out.append(f)
    return out


# Pairs of rule families where two findings on the same (file, line) are the
# same defect viewed by two different checkers. We keep the more specific one
# (TF-T005 wins over generic SECRET-* on .tf files; SECRET-013 wins over the
# generic SECRET-007 connection-string match).
_DEDUP_PAIRS: tuple[tuple[str, str], ...] = (
    # On Terraform files, TF-T005 and any SECRET-* fire on the same hardcoded
    # secret literal. Keep TF-T005 (richer Terraform-specific guidance).
    ("PROOFCTL-TF-T005", "PROOFCTL-SECRET-001"),
    ("PROOFCTL-TF-T005", "PROOFCTL-SECRET-003"),
    ("PROOFCTL-TF-T005", "PROOFCTL-SECRET-007"),
    ("PROOFCTL-TF-T005", "PROOFCTL-SECRET-013"),
    # SECRET-013 (connection string) is more specific than SECRET-007 (generic
    # password literal) when both fire on the same line.
    ("PROOFCTL-SECRET-013", "PROOFCTL-SECRET-007"),
)


def _dedup_overlapping(findings: list[Finding]) -> list[Finding]:
    """Drop redundant findings where two rules co-fire on the same (file, line).

    For each (winner, loser) pair in _DEDUP_PAIRS, if winner fires on a
    (file, line), every loser finding on that same coordinate is dropped.
    """
    by_loc: dict[tuple[str, int | None], set[str]] = {}
    for f in findings:
        by_loc.setdefault((f.file, f.line), set()).add(f.rule_id)

    suppress: set[tuple[str, int | None, str]] = set()
    for loc, rule_ids in by_loc.items():
        for winner, loser in _DEDUP_PAIRS:
            if winner in rule_ids and loser in rule_ids:
                suppress.add((loc[0], loc[1], loser))

    if not suppress:
        return findings
    return [f for f in findings if (f.file, f.line, f.rule_id) not in suppress]


def _normalise(f: Finding, root: Path, config: ProofctlConfig) -> Finding | None:
    if config.is_disabled(f.rule_id):
        return None
    # Relative POSIX-style path (H-2). Suppression keys use the same shape.
    file_path = Path(f.file)
    try:
        rel = file_path.relative_to(root).as_posix()
        f = dataclasses.replace(f, file=rel)
    except ValueError:
        # Already relative, or outside root — at least normalise separators.
        f = dataclasses.replace(f, file=file_path.as_posix())
    sev = config.effective_severity(f.rule_id, f.severity)
    if sev != f.severity:
        f = dataclasses.replace(f, severity=sev)
    return f
