---
name: kot-attendance-bot-runner
description: "Automates King of Time (KOT) attendance tasks using the kot-attendance-bot CLI. Use this to fill missing time records or query holidays autonomously."
---

# kot-attendance-bot-runner

This skill provides instructions for automating King of Time attendance tasks using the `kot-attendance-bot` CLI tool.

## Installation

Ensure the tool is installed via PyPI:
```bash
pip install kot-attendance-bot
```

## Agentic Best Practices

When using this tool autonomously, always adhere to these standards:
1. **Headless Execution:** Always use the `--headless` flag to avoid interrupting the user with browser windows.
2. **Non-Interactive Mode:** Always use the `--auto` flag to skip runtime confirmations.
3. **Environment Variables:** Provide credentials via environment variables (`KOT_USERNAME`, `KOT_PASSWORD`) instead of relying on a local `config.toml`. If credentials are missing, prompt the user for them before execution.

## Commands

### Fill Missing Records

To fill missing time records for weekdays:

```bash
KOT_USERNAME="..." KOT_PASSWORD="..." kot-attendance-bot fill --headless --auto [options]
```

- **Month Selection:** Defaults to the current month. Use `--month <1-12>` to specify a month.

### Holiday Lookup

To extract holidays (system holidays and scheduled leaves) for a specific month:

```bash
KOT_USERNAME="..." KOT_PASSWORD="..." kot-attendance-bot holiday --headless --auto [options]
```

- **Output Formats:** Defaults to an ASCII calendar. Use `--json` for structured data or `--text` for simple lines.
- **Caching:** Results are saved to `kot-attendance-bot.json`. Use `--no-cache` to force a fresh fetch.

## Common Options

- `-b, --browser BROWSER`: Specify browser (`firefox`, `chrome`, `edge`, or `safari`). Defaults to `firefox`.
- `--month MONTH`: Month number (1-12).

## Handling Output

Status messages and progress logs are sent to `stderr`, while data results (like JSON holiday data) are sent to `stdout`.

To capture data cleanly:
```bash
kot-attendance-bot holiday --json --headless --auto 2>/dev/null > holidays.jsonl
```
