from __future__ import annotations

import argparse
import os
import sys
from datetime import date
from pathlib import Path

from kot_bot.browser import build_browser
from kot_bot.cache import get_cached_holidays, set_cached_holidays
from kot_bot.config import AppConfig, WorkTimes, format_time, load_config
from kot_bot.eligibility import get_holiday_label, is_holiday
from kot_bot.kot import (
    FillTarget,
    LOGIN_URL,
    attempt_auto_login,
    collect_targets,
    displayed_month_value,
    fill_target,
    switch_to_month,
    wait_for_admin_page,
    wait_for_login,
    wait_for_page_loaded,
)
from kot_bot.month_policy import (
    TargetMonth,
    current_month_target,
    filter_targets_for_month,
    is_first_work_week,
    manual_target_month,
    parse_row_date,
    parse_target_month_override,
    previous_month_target,
)
from kot_bot.notify import notify
from kot_bot.output import render_ascii_calendar, render_jsonl, render_text_lines


def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)

    # Change current working directory to the config file's directory
    # so that cache and browser profiles are saved alongside the config.
    config_path = args.config.resolve()
    os.chdir(config_path.parent)
    args.config = Path(config_path.name)

    if args.command == "holiday":
        main_holiday(args)
    else:
        main_fill(args)


def main_fill(args: argparse.Namespace) -> None:
    config = load_config(args.config, browser_override=args.browser)

    # fill defaults to visible (headless=False) unless --headless is specified
    headless = args.headless if args.headless else False

    _print_startup_summary(config, file=sys.stderr if headless else sys.stdout)

    driver = build_browser(config.browser, config.proxy, headless=headless)
    try:
        driver.get(LOGIN_URL)
        wait_for_page_loaded(driver)
        if config.login.ready and attempt_auto_login(driver, config.login):
            masked_username = f"****{config.login.username[4:]}" if config.login.username and len(config.login.username) > 4 else "****"
            print(f"Auto-login submitted for {masked_username} with password [REDACTED].", file=sys.stderr if headless else sys.stdout)
        else:
            if config.login.auto_login:
                print("Auto-login is unavailable or failed; continuing with manual login.", file=sys.stderr if headless else sys.stdout)
            notify(f"Log in to King of Time in the {config.browser} browser.")
        wait_for_login(driver)

        notify(f"Navigate {config.browser} to the correct King of Time monthly attendance page.")
        wait_for_admin_page(driver)

        targets, target_month = _resolve_month_targets(driver, args.month, date.today(), auto=args.auto, headless=headless)
        if not targets:
            print(f"No eligible empty weekday rows found for {target_month.label}.", file=sys.stderr if headless else sys.stdout)
            return

        # Results and summaries should always go to stdout
        print(
            f"Selected month: {target_month.label} "
            f"({target_month.start_date.isoformat()} through {target_month.end_date.isoformat()})"
        )
        _print_targets(targets, config.work_times)
        if args.auto:
            print("Auto mode: submitting eligible rows after automatic checks.", file=sys.stderr if headless else sys.stdout)
        else:
            confirmed = input("Auto-submit these rows? [y/N]: ").strip().casefold()
            if confirmed not in {"y", "yes"}:
                print("Cancelled before editing any rows.", file=sys.stderr if headless else sys.stdout)
                return

        remaining = {_target_key(target) for target in targets}
        total = len(remaining)
        while remaining:
            current_targets = filter_targets_for_month(collect_targets(driver), target_month)
            target = _next_remaining_target(current_targets, remaining)
            if target is None:
                print("Could not find the remaining approved rows on the refreshed page.", file=sys.stderr if headless else sys.stdout)
                print("Remaining:", ", ".join(_format_target_key(key) for key in sorted(remaining)), file=sys.stderr if headless else sys.stdout)
                return

            position = total - len(remaining) + 1
            print(f"[{position}/{len(targets)}] Filling {target.row.date or f'row {target.row.index}'}", file=sys.stderr if headless else sys.stdout)
            fill_target(driver, target, config.work_times, input_func=input, auto=args.auto)
            remaining.remove(_target_key(target))

        notify("King of Time autofill is complete.")
    finally:
        if args.auto or _should_close_browser(config.browser):
            driver.quit()


def main_holiday(args: argparse.Namespace) -> None:
    today = date.today()
    if args.month:
        target_month = manual_target_month(args.month, today)
    else:
        target_month = current_month_target(today)

    if not args.no_cache:
        cached = get_cached_holidays(target_month.year, target_month.month)
        if cached is not None:
            _render_holidays(target_month, cached, args)
            return

    config = load_config(args.config, prompt=False, browser_override=args.browser)
    
    # holiday defaults to headless unless --visible is specified
    headless = False if args.visible else True
    file = sys.stderr if headless else sys.stdout
    
    _print_startup_summary(config, file=file)

    if headless and not config.login.ready:
        print("Warning: Running 'holiday' in headless mode without auto-login configured.", file=sys.stderr)
        print("This will likely fail unless you have an active session.", file=sys.stderr)

    driver = build_browser(config.browser, config.proxy, headless=headless)
    try:
        driver.get(LOGIN_URL)
        wait_for_page_loaded(driver)
        if config.login.ready and attempt_auto_login(driver, config.login):
            masked_username = f"****{config.login.username[4:]}" if config.login.username and len(config.login.username) > 4 else "****"
            print(f"Auto-login submitted for {masked_username} with password [REDACTED].", file=file)
        else:
            if config.login.auto_login:
                print("Auto-login is unavailable or failed; continuing with manual login.", file=file)
            notify(f"Log in to King of Time in the {config.browser} browser.")
        
        print("Waiting for login...", file=file)
        wait_for_login(driver)
        
        print("Navigating to monthly attendance page...", file=file)
        wait_for_admin_page(driver)

        print(f"Switching to {target_month.label}...", file=file)
        switch_to_month(driver, target_month.year, target_month.month)
        
        print(f"Collecting attendance data for {target_month.label}...", file=file)
        all_rows = [t.row for t in collect_targets(driver, filter_func=lambda _: True)]
        
        holidays = []
        for row in all_rows:
            if is_holiday(row):
                row_date = parse_row_date(row.date, target_month.year)
                if row_date:
                    holidays.append({
                        "date": row_date.isoformat(),
                        "weekday": row_date.strftime("%a"),
                        "label": get_holiday_label(row),
                    })
        
        set_cached_holidays(target_month.year, target_month.month, holidays)
        print("Rendering holiday results...", file=file)
        # Results must always go to stdout regardless of headless state
        _render_holidays(target_month, holidays, args)
    finally:
        driver.quit()


def _render_holidays(target_month: TargetMonth, holidays: list[dict[str, str]], args: argparse.Namespace) -> None:
    if args.json:
        render_jsonl(holidays)
    elif args.text:
        render_text_lines(holidays)
    else:
        render_ascii_calendar(target_month.year, target_month.month, holidays)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    if argv is None:
        argv = sys.argv[1:]
    else:
        # Copy to avoid mutating input list
        argv = list(argv)

    if not argv or (argv[0].startswith("-") and argv[0] not in {"-h", "--help"}):
        argv.insert(0, "fill")
    elif argv[0] not in {"fill", "holiday", "-h", "--help"}:
        argv.insert(0, "fill")

    parser = argparse.ArgumentParser(description="King of Time automation tools.")
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # Shared arguments helper
    def add_shared_args(p: argparse.ArgumentParser) -> None:
        p.add_argument(
            "-c",
            "--config",
            type=Path,
            default=Path("config.toml"),
            help="Path to config.toml. Defaults to ./config.toml.",
        )
        p.add_argument(
            "-b",
            "--browser",
            choices=["firefox", "chrome", "edge", "safari"],
            help="Browser to use.",
        )
        p.add_argument(
            "--month",
            type=_month_arg,
            help="Month number to query or fill. Example: --month 4 means April in the inferred year.",
        )
        p.add_argument(
            "-y",
            "--auto",
            action="store_true",
            help="Disable runtime confirmations and proceed using automatic checks.",
        )
        
        group = p.add_mutually_exclusive_group()
        group.add_argument(
            "--headless",
            action="store_true",
            help="Run browser in headless mode.",
        )
        group.add_argument(
            "--visible",
            action="store_true",
            help="Run browser in visible mode.",
        )

    # Fill command (legacy behavior, can also be explicit)
    fill_parser = subparsers.add_parser("fill", help="Fill missing time records (default)")
    add_shared_args(fill_parser)

    # Holiday command
    holiday_parser = subparsers.add_parser("holiday", help="Extract and display holidays")
    add_shared_args(holiday_parser)
    holiday_parser.add_argument(
        "--no-cache",
        action="store_true",
        help="Invalidate the cache and fetch fresh data from King of Time.",
    )
    holiday_parser.add_argument(
        "--text",
        action="store_true",
        help="Output as lines of text.",
    )
    holiday_parser.add_argument(
        "--json",
        action="store_true",
        help="Output as JSONL.",
    )

    return parser.parse_args(argv)


def _month_arg(value: str) -> int:
    try:
        month = int(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError("--month must be an integer from 1 to 12") from error
    if not 1 <= month <= 12:
        raise argparse.ArgumentTypeError("--month must be from 1 to 12")
    return month


def _resolve_month_targets(
    driver,
    requested_month: int | None,
    today: date,
    auto: bool = False,
    headless: bool = False,
) -> tuple[list[FillTarget], TargetMonth]:
    file = sys.stderr if headless else sys.stdout
    if requested_month is not None:
        target_month = manual_target_month(requested_month, today)
        return _collect_targets_for_month(driver, target_month, auto=auto, headless=headless), target_month

    if is_first_work_week(today):
        previous_target = previous_month_target(today)
        previous_targets = _collect_targets_for_month(driver, previous_target, auto=auto, headless=headless)
        if previous_targets:
            return previous_targets, previous_target
        print(f"No eligible rows found for {previous_target.label}; treating it as already fulfilled.", file=file)

    current_target = current_month_target(today)
    return _collect_targets_for_month(driver, current_target, auto=auto, headless=headless), current_target


def _collect_targets_for_month(driver, target_month: TargetMonth, auto: bool = False, headless: bool = False) -> list[FillTarget]:
    file = sys.stderr if headless else sys.stdout
    if auto:
        print(f"Auto mode: going to {target_month.label} due to {target_month.reason}.", file=file)
    else:
        target_month = _confirm_or_override_target_month(target_month, date.today())
    notify(f"Going to {target_month.label}.")
    try:
        switch_to_month(driver, target_month.year, target_month.month)
    except Exception as error:
        print(f"Automatic month switch failed: {error}", file=file)
        print(f"Please switch {config.browser} to {target_month.label} manually.", file=file)
    expected_value = f"{target_month.year:04d}/{target_month.month:02d}"
    actual_value = displayed_month_value(driver)
    if actual_value == expected_value:
        print(f"Browser is showing {target_month.label}.", file=file)
    else:
        print(f"Browser month check failed: expected {expected_value}, found {actual_value or 'unknown'}.", file=file)
    targets = filter_targets_for_month(collect_targets(driver), target_month)
    if not targets:
        print(f"No eligible rows matched {target_month.label} on the current page.", file=file)
    return targets


def _confirm_or_override_target_month(target_month: TargetMonth, today: date) -> TargetMonth:
    while True:
        entered = input(
            f"I will go to {target_month.label} due to {target_month.reason}. "
            "[Y/n/input YYYY-MM]: "
        ).strip()
        if entered.casefold() in {"n", "no"}:
            raise SystemExit("Cancelled before switching month.")
        try:
            override = parse_target_month_override(entered, today)
        except ValueError as error:
            print(error)
            continue
        return override or target_month


def _should_close_browser(browser_name: str, input_func=input) -> bool:
    answer = input_func(f"Close {browser_name}? [Y/n]: ").strip().casefold()
    return answer not in {"n", "no"}


def _print_startup_summary(config: AppConfig, file=sys.stdout) -> None:
    proxy_state = "enabled" if config.proxy.enabled else "disabled"
    auto_login_state = "enabled" if config.login.ready else "disabled"
    print("kot-attendance-bot configuration", file=file)
    print(f"- browser: {config.browser}", file=file)
    print(f"- config: {config.path}", file=file)
    print(f"- clock in: {format_time(config.work_times.clock_in)}", file=file)
    print(f"- start break: {format_time(config.work_times.start_break)}", file=file)
    print(f"- end break: {format_time(config.work_times.end_break)}", file=file)
    print(f"- clock out: {format_time(config.work_times.clock_out)}", file=file)
    print(f"- proxy: {proxy_state}", file=file)
    print(f"- auto-login: {auto_login_state}", file=file)


def _print_targets(targets, times: WorkTimes, file=sys.stdout) -> None:
    print(file=file)
    print("Eligible rows to fill:", file=file)
    print("Date | Workday type | Schedule | Clock in | Start break | End break | Clock out", file=file)
    print("-" * 86, file=file)
    for target in targets:
        row = target.row
        print(
            " | ".join(
                [
                    row.date or f"row {row.index}",
                    row.workday_type or "-",
                    row.schedule or "-",
                    format_time(times.clock_in),
                    format_time(times.start_break),
                    format_time(times.end_break),
                    format_time(times.clock_out),
                ]
            ),
            file=file
        )


def _target_key(target: FillTarget) -> tuple[str, int]:
    return (target.row.date, target.row.index)


def _next_remaining_target(targets: list[FillTarget], remaining: set[tuple[str, int]]) -> FillTarget | None:
    for target in targets:
        if _target_key(target) in remaining:
            return target
    return None


def _format_target_key(key: tuple[str, int]) -> str:
    date, index = key
    return date or f"row {index}"
