from __future__ import annotations

from dataclasses import dataclass


LEAVE_KEYWORDS = (
    "有休",
    "paid holiday",
    "paid leave",
    "公休",
    "休暇",
    "休み",
    "leave",
    "holiday",
)


@dataclass(frozen=True)
class AttendanceRow:
    index: int
    date: str
    workday_type: str
    schedule: str
    clock_in: str = ""
    clock_out: str = ""
    start_break: str = ""
    end_break: str = ""
    schedule_has_red: bool = False


def is_blank(value: str | None) -> bool:
    return not (value or "").strip()


def is_weekday(value: str) -> bool:
    return value.strip().casefold() == "weekday"


def is_leave_schedule(value: str) -> bool:
    lowered = value.casefold()
    return any(keyword.casefold() in lowered for keyword in LEAVE_KEYWORDS)


def is_holiday(row: AttendanceRow) -> bool:
    return not is_weekday(row.workday_type) or is_leave_schedule(row.schedule)


def get_holiday_label(row: AttendanceRow) -> str:
    if is_leave_schedule(row.schedule):
        return row.schedule.strip()
    if not is_weekday(row.workday_type):
        return row.workday_type.strip()
    return ""


def should_fill(row: AttendanceRow) -> bool:
    return (
        is_blank(row.clock_in)
        and is_blank(row.clock_out)
        and is_blank(row.start_break)
        and is_blank(row.end_break)
        and is_weekday(row.workday_type)
        and not is_leave_schedule(row.schedule)
        and not row.schedule_has_red
    )
