from __future__ import annotations

from dataclasses import dataclass
from datetime import time
import getpass
import os
from pathlib import Path
import tomllib
from typing import Callable


CONFIG_PATH = Path("config.toml")
DEFAULT_CLOCK_IN = "09:00"
DEFAULT_BREAK_START = "12:00"


@dataclass(frozen=True)
class ProxyConfig:
    http_proxy: str | None = None
    https_proxy: str | None = None

    @property
    def enabled(self) -> bool:
        return bool(self.http_proxy or self.https_proxy)


@dataclass(frozen=True)
class WorkTimes:
    clock_in: time
    start_break: time
    end_break: time
    clock_out: time


@dataclass(frozen=True)
class AppConfig:
    work_times: WorkTimes
    proxy: ProxyConfig
    login: LoginConfig
    path: Path
    browser: str


@dataclass(frozen=True)
class LoginConfig:
    auto_login: bool = False
    username: str | None = None
    password: str | None = None

    @property
    def ready(self) -> bool:
        return bool(self.auto_login and self.username and self.password)


def parse_time(value: str) -> time:
    parts = value.strip().split(":")
    if len(parts) != 2:
        raise ValueError(f"Invalid time {value!r}; expected HH:MM")
    hour, minute = (int(part) for part in parts)
    return time(hour=hour, minute=minute)


def format_time(value: time) -> str:
    return f"{value.hour:02d}:{value.minute:02d}"


def add_hours(value: time, hours: int) -> time:
    total_minutes = value.hour * 60 + value.minute + hours * 60
    if total_minutes >= 24 * 60:
        raise ValueError("Configured time range crosses midnight, which is not supported")
    return time(hour=total_minutes // 60, minute=total_minutes % 60)


def build_work_times(clock_in_value: str, break_start_value: str) -> WorkTimes:
    clock_in = parse_time(clock_in_value)
    start_break = parse_time(break_start_value)
    clock_out = add_hours(clock_in, 9)
    end_break = add_hours(start_break, 1)
    if not clock_in < start_break < end_break < clock_out:
        raise ValueError(
            "Expected clock_in < break_start < break_end < clock_out; "
            f"got {format_time(clock_in)}, {format_time(start_break)}, "
            f"{format_time(end_break)}, {format_time(clock_out)}"
        )
    return WorkTimes(
        clock_in=clock_in,
        start_break=start_break,
        end_break=end_break,
        clock_out=clock_out,
    )


def _read_toml(path: Path) -> dict:
    if not path.exists():
        return {}
    with path.open("rb") as file:
        return tomllib.load(file)


def _lookup(data: dict, *keys: str) -> str | None:
    for key in keys:
        value = data.get(key)
        if value is not None:
            return str(value)
    return None


def _lookup_bool(data: dict, key: str) -> bool | None:
    value = data.get(key)
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().casefold() in {"1", "true", "yes", "y", "on"}
    return bool(value)


def load_proxy(data: dict, environ: dict[str, str] | None = None) -> ProxyConfig:
    env = environ if environ is not None else os.environ
    return ProxyConfig(
        http_proxy=env.get("HTTP_PROXY")
        or env.get("http_proxy")
        or _lookup(data, "HTTP_PROXY", "http_proxy"),
        https_proxy=env.get("HTTPS_PROXY")
        or env.get("https_proxy")
        or _lookup(data, "HTTPS_PROXY", "https_proxy"),
    )


def load_login(data: dict) -> LoginConfig:
    username = os.environ.get("KOT_USERNAME") or _lookup(data, "username", "USERNAME")
    password = os.environ.get("KOT_PASSWORD") or _lookup(data, "password", "PASSWORD")
    
    # If credentials are provided via environment variables, enable auto-login
    if os.environ.get("KOT_USERNAME") and os.environ.get("KOT_PASSWORD"):
        auto_login = True
    else:
        auto_login = _lookup_bool(data, "auto_login") or False

    return LoginConfig(
        auto_login=auto_login,
        username=username,
        password=password,
    )


def prompt_time(label: str, default_value: str, input_func: Callable[[str], str] = input) -> str:
    entered = input_func(f"{label} [{default_value}]: ").strip()
    return entered or default_value


def prompt_yes_no(
    message: str,
    default: bool = False,
    input_func: Callable[[str], str] = input,
) -> bool:
    suffix = "[Y/n]" if default else "[y/N]"
    entered = input_func(f"{message} {suffix}: ").strip().casefold()
    if not entered:
        return default
    return entered in {"y", "yes"}


def prompt_choice(
    label: str,
    choices: list[str],
    default: str,
    input_func: Callable[[str], str] = input,
) -> str:
    choice_str = "/".join(choices)
    entered = input_func(f"{label} ({choice_str}) [{default}]: ").strip().casefold()
    if not entered:
        return default
    if entered in choices:
        return entered
    print(f"Invalid choice {entered!r}; using {default}")
    return default


def load_config(
    path: Path = CONFIG_PATH,
    prompt: bool = True,
    browser_override: str | None = None,
    input_func: Callable[[str], str] = input,
    password_func: Callable[[str], str] = getpass.getpass,
) -> AppConfig:
    data = _read_toml(path)
    if prompt:
        data = configure_data(path, data, input_func=input_func, password_func=password_func)

    clock_in_value = _lookup(data, "clock_in", "CLOCK_IN") or DEFAULT_CLOCK_IN
    break_start_value = _lookup(data, "break_start", "BREAK_START") or DEFAULT_BREAK_START
    
    # Priority: CLI param > config.toml > default (Firefox)
    # Note: user selection is handled in configure_data and stored in data/toml
    browser = browser_override or _lookup(data, "browser", "BROWSER") or "firefox"

    return AppConfig(
        work_times=build_work_times(clock_in_value, break_start_value),
        proxy=load_proxy(data),
        login=load_login(data),
        path=path,
        browser=browser,
    )


def configure_data(
    path: Path,
    data: dict,
    input_func: Callable[[str], str] = input,
    password_func: Callable[[str], str] = getpass.getpass,
) -> dict:
    if path.exists():
        return _configure_existing(path, data, input_func, password_func)
    return _configure_missing(path, input_func, password_func)


def _configure_missing(
    path: Path,
    input_func: Callable[[str], str],
    password_func: Callable[[str], str],
) -> dict:
    print(f"Config file not found: {path}")
    clock_in_value = prompt_time("Clock in", DEFAULT_CLOCK_IN, input_func)
    break_start_value = prompt_time("Start break", DEFAULT_BREAK_START, input_func)
    build_work_times(clock_in_value, break_start_value)
    
    browser = prompt_choice("Browser", ["firefox", "chrome", "edge", "safari"], "firefox", input_func)

    result: dict = {}
    if prompt_yes_no("Save these settings to config?", default=False, input_func=input_func):
        result["clock_in"] = clock_in_value
        result["break_start"] = break_start_value
        result["browser"] = browser
    else:
        result["_runtime_clock_in"] = clock_in_value
        result["_runtime_break_start"] = break_start_value
        result["_runtime_browser"] = browser

    if prompt_yes_no("Enable auto-login?", default=False, input_func=input_func):
        result["auto_login"] = True
        result["username"] = input_func("King of Time username: ").strip()
        result["password"] = password_func("King of Time password: ")

    if _has_persisted_values(result):
        write_config(path, result)
        print(f"Wrote config: {path}")

    return _runtime_to_config(result)


def _configure_existing(
    path: Path,
    data: dict,
    input_func: Callable[[str], str],
    password_func: Callable[[str], str],
) -> dict:
    result = dict(data)
    has_times = _lookup(data, "clock_in", "CLOCK_IN") is not None and _lookup(data, "break_start", "BREAK_START") is not None
    existing_clock_in = _lookup(data, "clock_in", "CLOCK_IN") or DEFAULT_CLOCK_IN
    existing_break_start = _lookup(data, "break_start", "BREAK_START") or DEFAULT_BREAK_START
    existing_browser = _lookup(data, "browser", "BROWSER")

    should_save = False
    if has_times and prompt_yes_no(
        f"Use configured times clock_in={existing_clock_in}, break_start={existing_break_start}?",
        default=True,
        input_func=input_func,
    ):
        build_work_times(existing_clock_in, existing_break_start)
    else:
        clock_in_value = prompt_time("Clock in", existing_clock_in, input_func)
        break_start_value = prompt_time("Start break", existing_break_start, input_func)
        build_work_times(clock_in_value, break_start_value)
        if prompt_yes_no("Save these times to config?", default=False, input_func=input_func):
            result["clock_in"] = clock_in_value
            result["break_start"] = break_start_value
            should_save = True
        else:
            result["_runtime_clock_in"] = clock_in_value
            result["_runtime_break_start"] = break_start_value

    if not existing_browser:
        browser = prompt_choice("Browser", ["firefox", "chrome", "edge", "safari"], "firefox", input_func)
        if prompt_yes_no("Save browser to config?", default=False, input_func=input_func):
            result["browser"] = browser
            should_save = True
        else:
            result["_runtime_browser"] = browser

    if "auto_login" not in result and prompt_yes_no("Enable auto-login?", default=False, input_func=input_func):
        result["auto_login"] = True
        result["username"] = input_func("King of Time username: ").strip()
        result["password"] = password_func("King of Time password: ")
        should_save = True

    if should_save:
        write_config(path, result)
        print(f"Updated config: {path}")

    return _runtime_to_config(result)


def _runtime_to_config(data: dict) -> dict:
    result = dict(data)
    if "_runtime_clock_in" in result:
        result["clock_in"] = result.pop("_runtime_clock_in")
    if "_runtime_break_start" in result:
        result["break_start"] = result.pop("_runtime_break_start")
    if "_runtime_browser" in result:
        result["browser"] = result.pop("_runtime_browser")
    return result


def _has_persisted_values(data: dict) -> bool:
    return any(not key.startswith("_runtime_") for key in data)


def write_config(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines: list[str] = []
    for key in ("browser", "clock_in", "break_start", "auto_login", "username", "password", "HTTP_PROXY", "HTTPS_PROXY"):
        if key not in data or data[key] is None:
            continue
        value = data[key]
        if isinstance(value, bool):
            rendered = "true" if value else "false"
        else:
            rendered = _toml_string(str(value))
        lines.append(f"{key} = {rendered}")
    path.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")


def _toml_string(value: str) -> str:
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'
