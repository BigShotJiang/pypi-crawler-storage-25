from __future__ import annotations

from dataclasses import dataclass
from datetime import time
import re
from typing import Iterable, Callable

from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait

from kot_bot.config import LoginConfig
from kot_bot.config import WorkTimes, format_time
from kot_bot.eligibility import AttendanceRow, should_fill
from kot_bot.notify import notify
from kot_bot.timing import random_sleep


LOGIN_URL = "https://s2.ta.kingoftime.jp/admin"
ADMIN_URL_PATTERN = re.compile(r"^https://s2\.ta\.kingoftime\.jp/admin/[A-Za-z0-9]+")
EDIT_TIME_RECORD_LABELS = (
    "Edit-time record",
    "Edit time-record",
    "Edit time record",
    "Time-record edit",
    "打刻編集",
    "打刻修正",
    "打刻データ編集",
    "打刻申請",
)
REGISTRATION_LABELS = ("Time-record registration", "登録", "申請", "Submit", "Registration")
USERNAME_HINTS = ("username", "user", "login", "login_id", "account", "mail", "email", "id", "ログイン", "社員", "コード")
SUBMIT_HINTS = ("login", "sign in", "submit", "ログイン", "認証")


@dataclass(frozen=True)
class FillTarget:
    row_element: WebElement
    row: AttendanceRow


@dataclass(frozen=True)
class ExpectedRecord:
    position: int
    labels: tuple[str, ...]
    time_value: str

    @property
    def label(self) -> str:
        return self.labels[0]


@dataclass(frozen=True)
class ActualRecord:
    position: int
    record_type: str
    time_value: str


def wait_for_page_loaded(driver: WebDriver, timeout: int = 60) -> None:
    WebDriverWait(driver, timeout).until(
        lambda active_driver: active_driver.execute_script("return document.readyState") == "complete"
    )


def wait_for_login(driver: WebDriver) -> None:
    WebDriverWait(driver, 900).until(
        lambda active_driver: "/login" not in active_driver.current_url and not _has_visible_password_input(active_driver)
    )
    wait_for_page_loaded(driver)


def attempt_auto_login(driver: WebDriver, login: LoginConfig) -> bool:
    if not login.ready:
        return False
    try:
        password_input = WebDriverWait(driver, 20).until(
            lambda active_driver: _first_visible_enabled(
                active_driver.find_elements(By.CSS_SELECTOR, "input[type='password']")
            )
        )
        username_input = _find_username_input(driver)
        if username_input is None or password_input is None:
            return False

        username_input.clear()
        username_input.send_keys(login.username or "")
        password_input.clear()
        password_input.send_keys(login.password or "")
        if not _click_login_submit(driver):
            password_input.send_keys(Keys.ENTER)
        return True
    except Exception:
        return False


def wait_for_admin_page(driver: WebDriver) -> None:
    WebDriverWait(driver, 900).until(lambda active_driver: bool(ADMIN_URL_PATTERN.match(active_driver.current_url)))
    wait_for_page_loaded(driver)
    WebDriverWait(driver, 60).until(EC.presence_of_element_located((By.TAG_NAME, "table")))


def switch_to_month(driver: WebDriver, year: int, month: int) -> None:
    value = f"{year:04d}/{month:02d}"
    WebDriverWait(driver, 60).until(EC.presence_of_element_located((By.ID, "select_year_month_picker")))
    driver.execute_script(
        """
        const value = arguments[0];
        const year = arguments[1];
        const month = arguments[2];
        const picker = document.querySelector('#select_year_month_picker');
        if (picker) {
            picker.value = value;
            picker.dispatchEvent(new Event('change', {bubbles: true}));
        }
        const yearInput = document.querySelector('#year');
        if (yearInput) yearInput.value = year;
        const monthInput = document.querySelector('#month');
        if (monthInput) monthInput.value = month;
        for (const element of document.querySelectorAll('#selected_year')) element.value = year;
        for (const element of document.querySelectorAll('#selected_month')) element.value = month;
        """,
        value,
        f"{year:04d}",
        f"{month:02d}",
    )
    _scroll_and_click(driver.find_element(By.ID, "display_button"))
    wait_for_page_loaded(driver)
    WebDriverWait(driver, 60).until(
        lambda active_driver: displayed_month_value(active_driver) == value
    )


def displayed_month_value(driver: WebDriver) -> str:
    elements = driver.find_elements(By.ID, "select_year_month_picker")
    if not elements:
        return ""
    return elements[0].get_attribute("value") or ""


def _find_username_input(driver: WebDriver) -> WebElement | None:
    inputs = [
        element
        for element in driver.find_elements(By.CSS_SELECTOR, "input")
        if _is_visible_enabled(element)
        and (element.get_attribute("type") or "text").lower() in {"text", "email", "tel", "number", ""}
    ]
    for element in inputs:
        haystack = " ".join(
            filter(
                None,
                [
                    element.get_attribute("name"),
                    element.get_attribute("id"),
                    element.get_attribute("placeholder"),
                    element.get_attribute("aria-label"),
                    _label_text_for(driver, element),
                ],
            )
        ).casefold()
        if any(hint.casefold() in haystack for hint in USERNAME_HINTS):
            return element
    return inputs[0] if inputs else None


def _label_text_for(driver: WebDriver, element: WebElement) -> str:
    element_id = element.get_attribute("id")
    if not element_id:
        return ""
    if "'" in element_id:
        return ""
    labels = driver.find_elements(By.CSS_SELECTOR, f"label[for='{element_id}']")
    return " ".join(label.text for label in labels)


def _click_login_submit(driver: WebDriver) -> bool:
    candidates = driver.find_elements(By.CSS_SELECTOR, "button, input[type='submit'], input[type='button']")
    for element in candidates:
        if not _is_visible_enabled(element):
            continue
        haystack = " ".join(
            filter(None, [element.text, element.get_attribute("value"), element.get_attribute("aria-label")])
        ).casefold()
        if any(hint.casefold() in haystack for hint in SUBMIT_HINTS):
            random_sleep(0.3, 1.0)
            _scroll_and_click(element)
            return True
    return False


def _first_visible_enabled(elements: list[WebElement]) -> WebElement | None:
    for element in elements:
        if _is_visible_enabled(element):
            return element
    return None


def _has_visible_password_input(driver: WebDriver) -> bool:
    return _first_visible_enabled(driver.find_elements(By.CSS_SELECTOR, "input[type='password']")) is not None


def _is_visible_enabled(element: WebElement) -> bool:
    return element.is_displayed() and element.is_enabled()


def collect_targets(driver: WebDriver, filter_func: Callable[[AttendanceRow], bool] = should_fill) -> list[FillTarget]:
    table = _find_attendance_table(driver)
    headers = _header_map(table)
    targets: list[FillTarget] = []
    for index, row_element in enumerate(_body_rows(table), start=1):
        row = _read_attendance_row(index, row_element, headers)
        if filter_func(row):
            targets.append(FillTarget(row_element=row_element, row=row))
    return targets


def fill_target(driver: WebDriver, target: FillTarget, times: WorkTimes, input_func=input, auto: bool = False) -> None:
    _open_edit_time_record(driver, target.row_element)
    wait_for_page_loaded(driver)
    _fill_time_records(driver, times)
    _verify_or_prompt_for_fix(driver, times, input_func=input_func, auto=auto)
    _click_by_labels(driver, REGISTRATION_LABELS)
    wait_for_page_loaded(driver)
    _click_return_to_monthly_page(driver)


def _find_attendance_table(driver: WebDriver) -> WebElement:
    tables = driver.find_elements(By.TAG_NAME, "table")
    for table in tables:
        text = table.text.casefold()
        if ("weekday" in text or "平日" in text) and ("schedule" in text or "スケジュール" in text):
            return table
    if not tables:
        raise RuntimeError("No table found on the current King of Time page")
    return tables[0]


def _header_map(table: WebElement) -> dict[str, int]:
    header_cells = table.find_elements(By.CSS_SELECTOR, "thead th")
    if not header_cells:
        header_cells = table.find_elements(By.CSS_SELECTOR, "tr:first-child th, tr:first-child td")
    return {_normalized_text(cell): index for index, cell in enumerate(header_cells)}


def _body_rows(table: WebElement) -> Iterable[WebElement]:
    rows = table.find_elements(By.CSS_SELECTOR, "tbody tr")
    if rows:
        return rows
    return table.find_elements(By.CSS_SELECTOR, "tr")[1:]


def _read_attendance_row(index: int, row: WebElement, headers: dict[str, int]) -> AttendanceRow:
    cells = row.find_elements(By.CSS_SELECTOR, "td, th")
    schedule_cell = _cell(cells, headers, ("schedule", "スケジュール", "予定"))
    return AttendanceRow(
        index=index,
        date=_cell_text(cells, headers, ("date", "day", "日付", "日")),
        workday_type=_cell_text(cells, headers, ("workday type", "勤務日種別", "勤務日")),
        schedule=_element_text(schedule_cell),
        clock_in=_cell_text(cells, headers, ("clock in", "出勤", "出社")),
        clock_out=_cell_text(cells, headers, ("clock out", "退勤", "退社")),
        start_break=_cell_text(cells, headers, ("start break", "break start", "休憩開始")),
        end_break=_cell_text(cells, headers, ("end break", "break end", "休憩終了")),
        schedule_has_red=_has_red_content(schedule_cell),
    )


def _cell_text(cells: list[WebElement], headers: dict[str, int], names: tuple[str, ...]) -> str:
    return _element_text(_cell(cells, headers, names))


def _cell(cells: list[WebElement], headers: dict[str, int], names: tuple[str, ...]) -> WebElement | None:
    index = _find_header_index(headers, names)
    if index is None or index >= len(cells):
        return None
    return cells[index]


def _find_header_index(headers: dict[str, int], names: tuple[str, ...]) -> int | None:
    normalized_names = tuple(name.casefold() for name in names)
    for header, index in headers.items():
        if any(name in header for name in normalized_names):
            return index
    return None


def _element_text(element: WebElement | None) -> str:
    if element is None:
        return ""
    return " ".join(element.text.split())


def _normalized_text(element: WebElement) -> str:
    return _element_text(element).casefold()


def _has_red_content(element: WebElement | None) -> bool:
    if element is None:
        return False
    candidates = [element, *element.find_elements(By.CSS_SELECTOR, "*")]
    for candidate in candidates:
        color = candidate.value_of_css_property("color")
        if color and _is_red_css_color(color):
            return True
    return False


def _is_red_css_color(color: str) -> bool:
    match = re.search(r"rgba?\((\d+),\s*(\d+),\s*(\d+)", color)
    if not match:
        return False
    red, green, blue = (int(part) for part in match.groups())
    return red >= 150 and green <= 90 and blue <= 90


def _open_edit_time_record(driver: WebDriver, row: WebElement) -> None:
    _click_edit_submit(row)
    _select_edit_time_record_action(driver, row)
    wait_for_page_loaded(driver)
    WebDriverWait(driver, 60).until(
        lambda active_driver: active_driver.find_elements(By.CSS_SELECTOR, "select[name^='recording_type_code_']")
    )


def _select_edit_time_record_action(driver: WebDriver, row: WebElement) -> None:
    select_element = _find_row_action_select(row)
    if select_element is None:
        select_element = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "td.htBlock-adjastableTableF_actionRow select"))
        )
    select = Select(select_element)
    for option in select.options:
        if _text_matches(option.text, EDIT_TIME_RECORD_LABELS):
            random_sleep(0.3, 1.0)
            select.select_by_visible_text(option.text)
            return
    raise RuntimeError("Could not find the Edit time-record action option")


def _find_row_action_select(row: WebElement) -> WebElement | None:
    selects = row.find_elements(By.CSS_SELECTOR, "td.htBlock-adjastableTableF_actionRow select")
    return selects[0] if selects else None


def _click_edit_submit(row: WebElement) -> None:
    labels = ("Edit Submit", "Edit", "申請", "編集")
    for element in _clickable_descendants(row):
        text = " ".join(filter(None, [element.text, element.get_attribute("value"), element.get_attribute("aria-label")]))
        if _text_matches(text, labels):
            _scroll_and_click(element)
            return

    cells = row.find_elements(By.CSS_SELECTOR, "td, th")
    if cells:
        edit_cell = cells[0]
        for element in _clickable_descendants(edit_cell):
            if _is_visible_enabled(element):
                _scroll_and_click(element)
                return
        _scroll_and_click(edit_cell)
        return

    raise RuntimeError("Could not find the row Edit Submit control")


def _click_by_labels(driver: WebDriver, labels: tuple[str, ...]) -> None:
    uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    lowercase = "abcdefghijklmnopqrstuvwxyz"
    xpath = " | ".join(
        [
            "//*[self::a or self::button or self::input or @role='button']"
            f"[contains(translate(normalize-space(.), '{uppercase}', '{lowercase}'), {_xpath_literal(label.casefold())})]"
            for label in labels
        ]
        + [
            f"//input[contains(translate(@value, '{uppercase}', '{lowercase}'), {_xpath_literal(label.casefold())})]"
            for label in labels
        ]
    )
    try:
        element = WebDriverWait(driver, 30).until(EC.element_to_be_clickable((By.XPATH, xpath)))
    except TimeoutException as error:
        raise RuntimeError(f"Could not find clickable control with labels: {', '.join(labels)}") from error
    _scroll_and_click(element)


def _verify_or_prompt_for_fix(driver: WebDriver, times: WorkTimes, input_func=input, auto: bool = False) -> None:
    while True:
        error = _verification_error(_expected_records(times), _read_actual_records(driver))
        if error is None:
            return
        if auto:
            notify(error, title="kot-attendance-bot error")
            raise RuntimeError(error)
        notify(error + "\nFix the record in Firefox, then confirm in terminal.", title="kot-attendance-bot error")
        answer = input_func("Fix the record in Firefox, then continue? [y/N]: ").strip().casefold()
        if answer not in {"y", "yes"}:
            raise RuntimeError(error)


def _expected_records(times: WorkTimes) -> list[ExpectedRecord]:
    return [
        ExpectedRecord(1, ("Clock-in", "Clock in", "出勤"), format_time(times.clock_in)),
        ExpectedRecord(2, ("Clock-out", "Clock out", "退勤"), format_time(times.clock_out)),
        ExpectedRecord(3, ("Start break", "休憩開始"), format_time(times.start_break)),
        ExpectedRecord(4, ("End break", "休憩終了"), format_time(times.end_break)),
    ]


def _read_actual_records(driver: WebDriver) -> list[ActualRecord]:
    records: list[ActualRecord] = []
    for position in range(1, 5):
        record_type = _selected_text(driver.find_element(By.NAME, f"recording_type_code_{position}"))
        time_value = driver.find_element(By.NAME, f"recording_timestamp_time_{position}").get_attribute("value") or ""
        records.append(ActualRecord(position, record_type, time_value))
    return records


def _verification_error(expected: list[ExpectedRecord], actual: list[ActualRecord]) -> str | None:
    actual_by_position = {record.position: record for record in actual}
    for expected_record in expected:
        actual_record = actual_by_position.get(expected_record.position)
        if actual_record is None:
            return f"Missing time-record row {expected_record.position} ({expected_record.label})."
        if not _text_matches(actual_record.record_type, expected_record.labels):
            return (
                f"Time-record row {expected_record.position} type mismatch: "
                f"expected {expected_record.label}, got {actual_record.record_type or '<blank>'}."
            )
        if actual_record.time_value != expected_record.time_value:
            return (
                f"Time-record row {expected_record.position} time mismatch for {expected_record.label}: "
                f"expected {expected_record.time_value}, got {actual_record.time_value or '<blank>'}."
            )
    return None


def _selected_text(select_element: WebElement) -> str:
    return Select(select_element).first_selected_option.text.strip()


def _click_return_to_monthly_page(driver: WebDriver) -> None:
    if _is_monthly_page(driver):
        return

    labels = ("Return", "戻る", "Back")
    try:
        _click_by_labels(driver, labels)
    except RuntimeError:
        driver.back()
    wait_for_page_loaded(driver)
    try:
        WebDriverWait(driver, 20).until(_is_monthly_page)
    except TimeoutException as error:
        message = "Could not return to the monthly page after registration."
        notify(message, title="kot-attendance-bot error")
        raise RuntimeError(message) from error


def _is_monthly_page(driver: WebDriver) -> bool:
    return bool(
        driver.find_elements(By.ID, "select_year_month_picker")
        and driver.find_elements(By.TAG_NAME, "table")
    )


def _clickable_descendants(element: WebElement) -> list[WebElement]:
    return element.find_elements(
        By.CSS_SELECTOR,
        "a, button, input[type='button'], input[type='submit'], [role='button'], [onclick]",
    )


def _scroll_and_click(element: WebElement) -> None:
    random_sleep(0.3, 1.0)
    element.parent.execute_script("arguments[0].scrollIntoView({block: 'center', inline: 'center'});", element)
    try:
        element.click()
    except Exception:
        element.parent.execute_script("arguments[0].click();", element)


def _xpath_literal(value: str) -> str:
    if "'" not in value:
        return f"'{value}'"
    if '"' not in value:
        return f'"{value}"'
    parts = value.split("'")
    return "concat(" + ', "\'", '.join(f"'{part}'" for part in parts) + ")"


def _text_matches(value: str, labels: tuple[str, ...]) -> bool:
    lowered = value.casefold()
    return any(label.casefold() in lowered for label in labels)


def _fill_time_records(driver: WebDriver, times: WorkTimes) -> None:
    desired = [
        ("Clock in", "Clock-in", "出勤", times.clock_in),
        ("Clock out", "Clock-out", "退勤", times.clock_out),
        ("Start break", "休憩開始", times.start_break),
        ("End break", "休憩終了", times.end_break),
    ]

    rows = driver.find_elements(By.CSS_SELECTOR, "table tr")
    editable_rows = [row for row in rows if row.find_elements(By.CSS_SELECTOR, "select, input")]
    if len(editable_rows) < len(desired):
        raise RuntimeError("Could not find enough editable time-record rows")

    for row, labels in zip(editable_rows[: len(desired)], desired, strict=True):
        *record_type_labels, record_time = labels
        _set_record_type(row, tuple(record_type_labels))
        _set_record_time(row, record_time)


def _set_record_type(row: WebElement, labels: tuple[str, ...]) -> None:
    selects = row.find_elements(By.TAG_NAME, "select")
    if not selects:
        return
    select = Select(selects[0])
    for label in labels:
        try:
            select.select_by_visible_text(label)
            return
        except NoSuchElementException:
            continue
    for option in select.options:
        if _text_matches(option.text, labels):
            select.select_by_visible_text(option.text)
            return
    raise RuntimeError(f"Could not select time-record type: {labels[0]}")


def _set_record_time(row: WebElement, value: time) -> None:
    text = format_time(value)
    inputs = [
        element
        for element in row.find_elements(By.CSS_SELECTOR, "input")
        if (element.get_attribute("type") or "text").lower() in {"text", "time", "tel", "number", "hidden"}
    ]
    visible_inputs = [element for element in inputs if element.is_displayed() and element.is_enabled()]
    if not visible_inputs:
        raise RuntimeError(f"Could not find time input for {text}")
    input_element = visible_inputs[-1]
    input_element.clear()
    input_element.send_keys(text)
