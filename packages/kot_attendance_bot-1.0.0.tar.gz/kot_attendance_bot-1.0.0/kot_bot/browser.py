from __future__ import annotations

from selenium import webdriver
from selenium.webdriver.common.proxy import Proxy, ProxyType
from kot_bot.config import ProxyConfig


def build_browser(browser_name: str, proxy_config: ProxyConfig, headless: bool = False) -> webdriver.Remote:
    name = browser_name.lower().strip()
    
    if name == "firefox":
        return _build_firefox(proxy_config, headless)
    elif name in {"chrome", "chromium"}:
        return _build_chrome(proxy_config, headless)
    elif name == "edge":
        return _build_edge(proxy_config, headless)
    elif name == "safari":
        return _build_safari(proxy_config)
    else:
        raise ValueError(f"Unsupported browser: {browser_name}")


def _build_firefox(proxy_config: ProxyConfig, headless: bool) -> webdriver.Firefox:
    from selenium.webdriver.firefox.options import Options
    options = Options()
    if headless:
        options.add_argument("-headless")
    if proxy_config.enabled:
        proxy = Proxy()
        proxy.proxy_type = ProxyType.MANUAL
        if proxy_config.http_proxy:
            proxy.http_proxy = _strip_scheme(proxy_config.http_proxy)
        if proxy_config.https_proxy:
            proxy.ssl_proxy = _strip_scheme(proxy_config.https_proxy)
        options.proxy = proxy
    return webdriver.Firefox(options=options)


def _build_chrome(proxy_config: ProxyConfig, headless: bool) -> webdriver.Chrome:
    from selenium.webdriver.chrome.options import Options
    options = Options()
    if headless:
        options.add_argument("--headless=new")
    if proxy_config.enabled:
        # Chrome prefers --proxy-server argument
        proxy_url = proxy_config.https_proxy or proxy_config.http_proxy
        if proxy_url:
            options.add_argument(f'--proxy-server={proxy_url}')
    return webdriver.Chrome(options=options)


def _build_edge(proxy_config: ProxyConfig, headless: bool) -> webdriver.Edge:
    from selenium.webdriver.edge.options import Options
    options = Options()
    if headless:
        options.add_argument("--headless=new")
    if proxy_config.enabled:
        proxy_url = proxy_config.https_proxy or proxy_config.http_proxy
        if proxy_url:
            options.add_argument(f'--proxy-server={proxy_url}')
    return webdriver.Edge(options=options)


def _build_safari(proxy_config: ProxyConfig) -> webdriver.Safari:
    from selenium.webdriver.safari.options import Options
    options = Options()
    # Safari typically uses system proxy settings and doesn't easily support per-session proxy via options
    return webdriver.Safari(options=options)


def _strip_scheme(value: str) -> str:
    for prefix in ("http://", "https://"):
        if value.startswith(prefix):
            return value.removeprefix(prefix)
    return value
