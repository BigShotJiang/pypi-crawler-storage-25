from __future__ import annotations

import json
from pathlib import Path
from typing import Any


CACHE_PATH = Path("kot-attendance-bot.json")


def load_cache() -> dict[str, Any]:
    if not CACHE_PATH.exists():
        return {}
    try:
        with CACHE_PATH.open("r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def save_cache(cache: dict[str, Any]) -> None:
    with CACHE_PATH.open("w", encoding="utf-8") as f:
        json.dump(cache, f, ensure_ascii=False, indent=2)


def get_cached_holidays(year: int, month: int) -> list[dict[str, str]] | None:
    cache = load_cache()
    key = f"{year:04d}-{month:02d}"
    return cache.get(key)


def set_cached_holidays(year: int, month: int, holidays: list[dict[str, str]]) -> None:
    cache = load_cache()
    key = f"{year:04d}-{month:02d}"
    cache[key] = holidays
    save_cache(cache)
