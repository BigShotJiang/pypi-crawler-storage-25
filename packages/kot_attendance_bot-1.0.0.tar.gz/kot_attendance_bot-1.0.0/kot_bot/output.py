from __future__ import annotations

import calendar
import json
from datetime import date


def render_ascii_calendar(year: int, month: int, holidays: list[dict[str, str]]) -> None:
    # Use calendar to get the structure
    cal = calendar.TextCalendar(calendar.SUNDAY)
    month_name = calendar.month_name[month]
    print(f"     {month_name} {year}")
    print("Su Mo Tu We Th Fr Sa")

    # Map dates to holiday labels for easier lookup
    holiday_map = {h["date"]: h["label"] for h in holidays}

    for week in cal.monthdayscalendar(year, month):
        line = ""
        for day in week:
            if day == 0:
                line += "   "
            else:
                d_str = f"{year:04d}-{month:02d}-{day:02d}"
                if d_str in holiday_map:
                    # Highlight holiday - using brackets or just a color if we had one, 
                    # but simple ASCII is better. Let's use *Day* or [Day]
                    line += f"{day:2}*" if day >= 10 else f" {day}*"
                else:
                    line += f"{day:2} " if day >= 10 else f" {day} "
        print(line.rstrip())
    
    print("\n* = Holiday/Leave")
    if holiday_map:
        print("\nHolidays:")
        for h in holidays:
            print(f"  {h['date']} ({h['weekday']}): {h['label']}")


def render_text_lines(holidays: list[dict[str, str]]) -> None:
    for h in holidays:
        print(f"{h['date']} ({h['weekday']}): {h['label']}")


def render_jsonl(holidays: list[dict[str, str]]) -> None:
    for h in holidays:
        print(json.dumps(h, ensure_ascii=False))
