"""King of Time autofill helper."""

