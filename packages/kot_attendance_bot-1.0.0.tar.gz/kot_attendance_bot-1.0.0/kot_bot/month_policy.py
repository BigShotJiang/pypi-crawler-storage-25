from __future__ import annotations

import calendar
from dataclasses import dataclass
from datetime import date, timedelta
import re

from kot_bot.kot import FillTarget


@dataclass(frozen=True)
class TargetMonth:
    year: int
    month: int
    start_date: date
    end_date: date
    reason: str

    @property
    def label(self) -> str:
        return f"{self.year:04d}-{self.month:02d}"


def manual_target_month(month: int, today: date) -> TargetMonth:
    year = today.year - 1 if month > today.month else today.year
    return build_target_month(year, month, today, "manual --month")


def current_month_target(today: date, reason: str = "current month through today") -> TargetMonth:
    return TargetMonth(
        year=today.year,
        month=today.month,
        start_date=date(today.year, today.month, 1),
        end_date=today,
        reason=reason,
    )


def previous_month_target(today: date, reason: str = "first work week previous month") -> TargetMonth:
    year = today.year
    month = today.month - 1
    if month == 0:
        year -= 1
        month = 12
    return build_target_month(year, month, today, reason)


def build_target_month(year: int, month: int, today: date, reason: str) -> TargetMonth:
    first_day = date(year, month, 1)
    if year == today.year and month == today.month:
        end_date = today
    else:
        end_date = date(year, month, calendar.monthrange(year, month)[1])
    return TargetMonth(
        year=year,
        month=month,
        start_date=first_day,
        end_date=end_date,
        reason=reason,
    )


def parse_target_month_override(value: str, today: date) -> TargetMonth | None:
    normalized = value.strip().casefold()
    if normalized in {"", "y", "yes"}:
        return None
    match = re.fullmatch(r"(\d{4})-(\d{1,2})", normalized)
    if not match:
        raise ValueError("Expected Enter, y, n, or YYYY-MM")
    year, month = (int(part) for part in match.groups())
    if not 1 <= month <= 12:
        raise ValueError("Month must be from 01 to 12")
    return build_target_month(year, month, today, "manual prompt override")


def is_first_work_week(value: date) -> bool:
    first_day = date(value.year, value.month, 1)
    first_workday = first_day
    while first_workday.weekday() >= 5:
        first_workday += timedelta(days=1)
    first_friday = first_workday + timedelta(days=4 - first_workday.weekday())
    return first_workday <= value <= first_friday


def filter_targets_for_month(targets: list[FillTarget], target_month: TargetMonth) -> list[FillTarget]:
    filtered: list[FillTarget] = []
    for target in targets:
        row_date = parse_row_date(target.row.date, target_month.year)
        if row_date is None:
            continue
        if target_month.start_date <= row_date <= target_month.end_date:
            filtered.append(target)
    return filtered


def parse_row_date(value: str, year: int) -> date | None:
    match = re.search(r"(\d{1,2})/(\d{1,2})", value)
    if not match:
        return None
    month, day = (int(part) for part in match.groups())
    try:
        return date(year, month, day)
    except ValueError:
        return None
