from __future__ import annotations

import platform
import shutil
import subprocess


def notify(message: str, title: str = "kot-attendance-bot") -> None:
    print()
    print(message)
    print("\a", end="", flush=True)
    _desktop_notify(title, message)


def _desktop_notify(title: str, message: str) -> None:
    system = platform.system()
    try:
        if system == "Darwin" and shutil.which("osascript"):
            script = (
                f'display notification "{_escape_osascript(message)}" '
                f'with title "{_escape_osascript(title)}"'
            )
            subprocess.run(["osascript", "-e", script], check=False, timeout=5)
        elif system == "Linux" and shutil.which("notify-send"):
            subprocess.run(["notify-send", title, message], check=False, timeout=5)
    except Exception:
        pass


def _escape_osascript(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')
