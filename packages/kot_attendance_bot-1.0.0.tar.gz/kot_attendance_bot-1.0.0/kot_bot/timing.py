from __future__ import annotations

import random
import time
from typing import Callable


def random_sleep(
    minimum_seconds: float,
    maximum_seconds: float,
    sleeper: Callable[[float], None] = time.sleep,
    randomizer: Callable[[float, float], float] = random.uniform,
) -> float:
    seconds = randomizer(minimum_seconds, maximum_seconds)
    sleeper(seconds)
    return seconds
