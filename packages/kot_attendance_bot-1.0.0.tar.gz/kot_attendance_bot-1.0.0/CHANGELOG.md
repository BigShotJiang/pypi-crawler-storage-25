# Changelog

All notable changes to this project will be documented in this file.

## [1.0.0] - 2026-05-02

### Added
- **Environment Variable Support**: Added `KOT_USERNAME` and `KOT_PASSWORD` support to bypass interactive login.
- **AI Agent Skill**: Created and packaged `kot-attendance-bot-runner` skill for autonomous task execution via Gemini CLI, Claude Code, and others.
- **Headless Mode**: Enhanced CLI support for headless browser execution, now recommended for agentic use.
- **Build System**: Switched to `hatchling` as the PEP 517 build backend for PyPI distribution.

### Changed
- **Config Directory Affinity**: The current working directory is now automatically changed to the directory containing `config.toml`. This ensures the holiday cache (`kot-attendance-bot.json`) and other local files are saved alongside the configuration.
- **Rebranding**: Renamed the project from `auto-kot` to `kot-attendance-bot`.
- **Package Renaming**: Renamed Python package from `auto_kot` to `kot_bot`.
- **CLI Rename**: The command-line tool is now invoked via `kot-attendance-bot`.
- **Project Structure**: Updated imports and module organization to reflect the new namespace.
- **Documentation**: Overhauled `README.md` and `AGENTS.md` for better clarity on installation (pip) and AI integration.
- **Cache Name**: Renamed local holiday cache from `auto-kot.json` to `kot-attendance-bot.json`.

### Fixed
- Fixed build issues by explicitly configuring package inclusion in `pyproject.toml`.
- Improved non-interactive behavior with the `--auto` flag.
