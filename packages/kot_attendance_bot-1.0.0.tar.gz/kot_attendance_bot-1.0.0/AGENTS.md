# Repository Guidelines

## Project Structure & Module Organization

- `main.py` is the thin application entry point; CLI logic lives in `kot_bot/cli.py`.
- `kot_bot/` contains the implementation:
    - `kot.py`: Selenium routines for King of Time.
    - `config.py`: TOML/env configuration and interactive setup.
    - `browser.py`: Multi-browser setup (Firefox, Chrome, Edge, Safari).
    - `geckodriver.py`: Driver discovery/download.
    - `month_policy.py`: Decision logic for target months and date parsing.
    - `eligibility.py`: Decision logic for fill eligibility and holiday identification.
    - `cache.py`: JSON caching for holiday data.
    - `output.py`: Formatting for calendars, text, and JSON results.
    - `notify.py`: System notifications.
    - `timing.py`: Randomized latency helpers.
- `tests/` contains `unittest` coverage for all core logic.
- `config.example.toml` documents local configuration. Real `config.toml`, `kot-attendance-bot.json`, `.drivers/`, `.venv/`, caches, cookies, and browser profiles must stay untracked.

## Build, Test, and Development Commands

- `uv sync`: create or update the virtual environment from `pyproject.toml` and `uv.lock`.
- `uv run python main.py fill`: run the visible browser automation to fill missing records.
- `uv run python main.py holiday`: run the headless holiday extractor (results cached).
- `uv run python main.py holiday --month 4 --json`: query April holidays and output as JSONL.
- `uv run python -m unittest discover -s tests`: run the test suite.

## Coding Style & Naming Conventions

Use standard Python style: 4-space indentation, descriptive `snake_case`, `PascalCase` for classes, and uppercase constants. Keep modules focused and prefer pure helper functions for parsing, filtering, and month decisions.

For Selenium work, use explicit waits and driver APIs. Keep King of Time DOM selectors and page-flow behavior centralized in `kot_bot/kot.py`. Use `kot_bot/timing.py` for randomized click latency instead of scattered sleeps.

## Testing Guidelines

Tests use the standard library `unittest` framework. Name files `test_*.py`. Favor unit tests for config parsing, eligibility rules (including holidays), month policy, and verification logic. Do not require live King of Time credentials, a browser session, or network access in routine tests; document manual Selenium checks in PR notes.

## Commit & Pull Request Guidelines

Use concise imperative commit messages such as `Add holiday lookup command` or `Implement headless browser mode`. Pull requests should include a behavior summary and verification notes.

## Security & Configuration Tips

Do not commit credentials, `config.toml`, `kot-attendance-bot.json`, or browser profiles. Auto-login stores passwords in plaintext TOML. Status output is redirected to `stderr` in headless mode to prevent leaking progress logs into data pipelines.
