import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

def main():
    print("Welcome to kot-attendance-bot installation!")
    
    # 1. Install via pip
    print("\nStep 1: Installing kot-attendance-bot via pip...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-e", "."])
    except subprocess.CalledProcessError as e:
        print(f"Error installing via pip: {e}")
        sys.exit(1)

    # 2. Choose browser
    print("\nStep 2: Choose your preferred browser")
    browsers = ["Firefox", "Google Chrome", "Microsoft Edge"]
    if platform.system() == "Darwin":
        browsers.append("Safari")

    print("Please select a browser:")
    for i, b in enumerate(browsers, 1):
        print(f"[{i}] {b}")
    
    choice = 0
    while choice < 1 or choice > len(browsers):
        try:
            val = input(f"Select browser [1-{len(browsers)}] (default: 1): ").strip()
            if not val:
                choice = 1
            else:
                choice = int(val)
        except ValueError:
            print("Invalid input. Please enter a number.")

    selected_browser = browsers[choice - 1].lower().split()[0] # e.g. "google chrome" -> "google" -> but we want "chrome"
    if "chrome" in browsers[choice - 1].lower():
        selected_browser = "chrome"
    elif "firefox" in browsers[choice - 1].lower():
        selected_browser = "firefox"
    elif "edge" in browsers[choice - 1].lower():
        selected_browser = "edge"
    elif "safari" in browsers[choice - 1].lower():
        selected_browser = "safari"

    print(f"Selected: {selected_browser}")

    # 3. Write to config.toml
    print("\nStep 3: Updating config.toml...")
    config_path = Path("config.toml")
    example_path = Path("config.example.toml")

    if not config_path.exists():
        if example_path.exists():
            print("Creating config.toml from config.example.toml")
            shutil.copy(example_path, config_path)
        else:
            print("Creating new config.toml")
            config_path.touch()

    update_config(config_path, selected_browser)
    print("Installation complete! You can now run 'kot-attendance-bot' or 'python main.py'.")

def update_config(path: Path, browser: str):
    lines = path.read_text(encoding="utf-8").splitlines()
    found = False
    new_lines = []
    
    for line in lines:
        if line.strip().startswith("browser =") or line.strip().startswith("# browser ="):
            new_lines.append(f'browser = "{browser}"')
            found = True
        else:
            new_lines.append(line)
    
    if not found:
        # Add to the beginning or after comments
        new_lines.insert(0, f'browser = "{browser}"')
    
    path.write_text("\n".join(new_lines) + "\n", encoding="utf-8")

if __name__ == "__main__":
    main()
