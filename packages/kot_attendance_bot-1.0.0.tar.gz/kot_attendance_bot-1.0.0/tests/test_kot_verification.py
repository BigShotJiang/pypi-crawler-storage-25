from __future__ import annotations

from datetime import time
import unittest

from kot_bot.config import WorkTimes
from kot_bot.kot import ActualRecord, _expected_records, _verification_error


class KotVerificationTests(unittest.TestCase):
    def test_verification_passes_when_values_match(self) -> None:
        expected = _expected_records(_times())
        actual = [
            ActualRecord(1, "Clock-in", "09:00"),
            ActualRecord(2, "Clock-out", "18:00"),
            ActualRecord(3, "Start break", "12:00"),
            ActualRecord(4, "End break", "13:00"),
        ]

        self.assertIsNone(_verification_error(expected, actual))

    def test_verification_reports_type_mismatch(self) -> None:
        expected = _expected_records(_times())
        actual = [
            ActualRecord(1, "Clock-out", "09:00"),
            ActualRecord(2, "Clock-out", "18:00"),
            ActualRecord(3, "Start break", "12:00"),
            ActualRecord(4, "End break", "13:00"),
        ]

        self.assertIn("type mismatch", _verification_error(expected, actual) or "")

    def test_verification_reports_time_mismatch(self) -> None:
        expected = _expected_records(_times())
        actual = [
            ActualRecord(1, "Clock-in", "09:30"),
            ActualRecord(2, "Clock-out", "18:00"),
            ActualRecord(3, "Start break", "12:00"),
            ActualRecord(4, "End break", "13:00"),
        ]

        self.assertIn("time mismatch", _verification_error(expected, actual) or "")

    def test_verification_reports_missing_row(self) -> None:
        expected = _expected_records(_times())
        actual = [
            ActualRecord(1, "Clock-in", "09:00"),
        ]

        self.assertIn("Missing time-record row 2", _verification_error(expected, actual) or "")


def _times() -> WorkTimes:
    return WorkTimes(
        clock_in=time(9, 0),
        clock_out=time(18, 0),
        start_break=time(12, 0),
        end_break=time(13, 0),
    )


if __name__ == "__main__":
    unittest.main()
