from __future__ import annotations

import unittest

from kot_bot.eligibility import AttendanceRow, is_leave_schedule, should_fill


class EligibilityTests(unittest.TestCase):
    def test_empty_weekday_without_leave_should_fill(self) -> None:
        row = AttendanceRow(
            index=1,
            date="2026-05-01",
            workday_type="Weekday",
            schedule="09:00-18:00",
        )

        self.assertTrue(should_fill(row))

    def test_existing_clock_record_should_not_fill(self) -> None:
        row = AttendanceRow(
            index=1,
            date="2026-05-01",
            workday_type="Weekday",
            schedule="09:00-18:00",
            clock_in="09:00",
        )

        self.assertFalse(should_fill(row))

    def test_leave_schedule_should_not_fill(self) -> None:
        self.assertTrue(is_leave_schedule("有休/Paid Holiday"))
        row = AttendanceRow(
            index=1,
            date="2026-05-01",
            workday_type="Weekday",
            schedule="有休/Paid Holiday",
        )

        self.assertFalse(should_fill(row))

    def test_red_schedule_should_not_fill(self) -> None:
        row = AttendanceRow(
            index=1,
            date="2026-05-01",
            workday_type="Weekday",
            schedule="09:00-18:00",
            schedule_has_red=True,
        )

        self.assertFalse(should_fill(row))

    def test_non_weekday_should_not_fill(self) -> None:
        row = AttendanceRow(
            index=1,
            date="2026-05-02",
            workday_type="Holiday",
            schedule="09:00-18:00",
        )

        self.assertFalse(should_fill(row))


if __name__ == "__main__":
    unittest.main()
