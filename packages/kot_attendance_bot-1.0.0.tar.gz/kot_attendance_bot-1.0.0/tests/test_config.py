from __future__ import annotations

from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from kot_bot.config import build_work_times, format_time, load_config, load_proxy


class ConfigTests(unittest.TestCase):
    def test_build_work_times_derives_clock_out_and_break_end(self) -> None:
        times = build_work_times("09:00", "12:00")

        self.assertEqual(format_time(times.clock_in), "09:00")
        self.assertEqual(format_time(times.clock_out), "18:00")
        self.assertEqual(format_time(times.start_break), "12:00")
        self.assertEqual(format_time(times.end_break), "13:00")

    def test_build_work_times_rejects_invalid_order(self) -> None:
        with self.assertRaises(ValueError):
            build_work_times("09:00", "18:00")

    def test_environment_proxy_overrides_config(self) -> None:
        proxy = load_proxy(
            {"HTTP_PROXY": "http://config-http:8080", "HTTPS_PROXY": "http://config-https:8080"},
            {
                "HTTP_PROXY": "http://env-http:8080",
                "HTTPS_PROXY": "http://env-https:8080",
            },
        )

        self.assertEqual(proxy.http_proxy, "http://env-http:8080")
        self.assertEqual(proxy.https_proxy, "http://env-https:8080")

    def test_config_proxy_used_when_environment_is_missing(self) -> None:
        proxy = load_proxy(
            {"HTTP_PROXY": "http://config-http:8080", "HTTPS_PROXY": "http://config-https:8080"},
            {},
        )

        self.assertEqual(proxy.http_proxy, "http://config-http:8080")
        self.assertEqual(proxy.https_proxy, "http://config-https:8080")

    def test_missing_config_can_continue_without_writing(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "config.toml"
            answers = iter(["08:30", "12:30", "firefox", "n", "n"])
            with patch("builtins.print"):
                config = load_config(path, input_func=lambda _prompt: next(answers))

        self.assertEqual(format_time(config.work_times.clock_in), "08:30")
        self.assertEqual(format_time(config.work_times.start_break), "12:30")
        self.assertFalse(path.exists())
        self.assertFalse(config.login.auto_login)

    def test_missing_config_can_write_times_and_auto_login(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "config.toml"
            # Sequence: Clock-in, Break-start, Browser, Save settings?, Enable auto-login?, Username
            answers = iter(["09:15", "12:15", "firefox", "y", "y", "alice"])
            with patch("builtins.print"):
                config = load_config(
                    path,
                    input_func=lambda _prompt: next(answers),
                    password_func=lambda _prompt: "secret",
                )
            text = path.read_text(encoding="utf-8")

        self.assertEqual(format_time(config.work_times.clock_in), "09:15")
        self.assertTrue(config.login.ready)
        self.assertIn('clock_in = "09:15"', text)
        self.assertIn("auto_login = true", text)
        self.assertIn('username = "alice"', text)
        self.assertIn('password = "secret"', text)
        self.assertIn('browser = "firefox"', text)

    def test_existing_config_can_reuse_times(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "config.toml"
            path.write_text('clock_in = "10:00"\nbreak_start = "13:00"\nbrowser = "firefox"\n', encoding="utf-8")
            # Sequence: Use configured times?, Enable auto-login?
            answers = iter(["y", "n"])
            with patch("builtins.print"):
                config = load_config(path, input_func=lambda _prompt: next(answers))

        self.assertEqual(format_time(config.work_times.clock_in), "10:00")
        self.assertEqual(format_time(config.work_times.start_break), "13:00")

    def test_existing_config_can_replace_and_save_times(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "config.toml"
            path.write_text('clock_in = "10:00"\nbreak_start = "13:00"\nbrowser = "firefox"\n', encoding="utf-8")
            # Sequence: Use configured?, Clock-in, Break-start, Save times?, Enable auto-login?
            answers = iter(["n", "08:45", "12:00", "y", "n"])
            with patch("builtins.print"):
                config = load_config(path, input_func=lambda _prompt: next(answers))
            text = path.read_text(encoding="utf-8")

        self.assertEqual(format_time(config.work_times.clock_in), "08:45")
        self.assertIn('clock_in = "08:45"', text)
        self.assertIn('break_start = "12:00"', text)

    def test_runtime_times_are_not_saved_when_only_auto_login_is_saved(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "config.toml"
            path.write_text('browser = "firefox"\n', encoding="utf-8")
            # Sequence: Clock-in, Break-start, Save times?, Enable auto-login?, Username
            answers = iter(["08:45", "12:00", "n", "y", "alice"])
            with patch("builtins.print"):
                config = load_config(
                    path,
                    input_func=lambda _prompt: next(answers),
                    password_func=lambda _prompt: "secret",
                )
            text = path.read_text(encoding="utf-8")

        self.assertEqual(format_time(config.work_times.clock_in), "08:45")
        self.assertIn("auto_login = true", text)
        self.assertNotIn("clock_in", text)
        self.assertNotIn("break_start", text)


if __name__ == "__main__":
    unittest.main()
