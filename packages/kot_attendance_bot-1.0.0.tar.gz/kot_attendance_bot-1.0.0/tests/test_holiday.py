from __future__ import annotations

import unittest
from kot_bot.eligibility import AttendanceRow, is_holiday, get_holiday_label


class HolidayEligibilityTests(unittest.TestCase):
    def test_weekday_is_not_holiday(self) -> None:
        row = AttendanceRow(index=1, date="2026-05-01", workday_type="Weekday", schedule="")
        self.assertFalse(is_holiday(row))

    def test_legal_holiday_is_holiday(self) -> None:
        row = AttendanceRow(index=1, date="2026-05-03", workday_type="Legal holiday", schedule="")
        self.assertTrue(is_holiday(row))
        self.assertEqual(get_holiday_label(row), "Legal holiday")

    def test_scheduled_leave_is_holiday(self) -> None:
        row = AttendanceRow(index=1, date="2026-05-01", workday_type="Weekday", schedule="Paid holiday")
        self.assertTrue(is_holiday(row))
        self.assertEqual(get_holiday_label(row), "Paid holiday")

    def test_public_holiday_schedule_is_holiday(self) -> None:
        row = AttendanceRow(index=1, date="2026-05-04", workday_type="Weekday", schedule="公休")
        self.assertTrue(is_holiday(row))
        self.assertEqual(get_holiday_label(row), "公休")

    def test_sick_leave_is_holiday(self) -> None:
        # Assuming sick leave is part of the keywords or matched
        row = AttendanceRow(index=1, date="2026-05-01", workday_type="Weekday", schedule="Sick leave")
        self.assertTrue(is_holiday(row))
        self.assertEqual(get_holiday_label(row), "Sick leave")


if __name__ == "__main__":
    unittest.main()
