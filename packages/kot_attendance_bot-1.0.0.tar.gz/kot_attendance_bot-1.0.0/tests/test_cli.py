from __future__ import annotations

from pathlib import Path
import sys
import unittest
from unittest.mock import patch

from kot_bot.cli import _should_close_browser, parse_args


class CliTests(unittest.TestCase):
    def test_parse_args_uses_default_config_path(self) -> None:
        args = parse_args([])

        self.assertEqual(args.config, Path("config.toml"))

    def test_parse_args_custom_config(self) -> None:
        args = parse_args(["-c", "/tmp/kot-attendance-bot.toml"])

        self.assertEqual(args.config, Path("/tmp/kot-attendance-bot.toml"))

    def test_parse_args_accepts_long_config_option(self) -> None:
        args = parse_args(["--config", "/tmp/another.toml"])

        self.assertEqual(args.config, Path("/tmp/another.toml"))

    def test_parse_args_accepts_month(self) -> None:
        args = parse_args(["--month", "4"])

        self.assertEqual(args.month, 4)

    def test_parse_args_rejects_invalid_month(self) -> None:
        with patch.object(sys, "stderr"):
            with self.assertRaises(SystemExit):
                parse_args(["--month", "13"])

    def test_parse_args_accepts_auto_short_flag(self) -> None:
        args = parse_args(["-y"])

        self.assertTrue(args.auto)

    def test_parse_args_accepts_auto_long_flag(self) -> None:
        args = parse_args(["--auto"])

        self.assertTrue(args.auto)

    def test_close_browser_defaults_to_yes(self) -> None:
        self.assertTrue(_should_close_browser("firefox", lambda _prompt: ""))
        self.assertTrue(_should_close_browser("firefox", lambda _prompt: "y"))

    def test_close_browser_can_keep_open(self) -> None:
        self.assertFalse(_should_close_browser("firefox", lambda _prompt: "n"))


if __name__ == "__main__":
    unittest.main()
