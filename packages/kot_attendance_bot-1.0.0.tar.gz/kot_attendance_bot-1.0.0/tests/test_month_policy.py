from __future__ import annotations

from datetime import date
from types import SimpleNamespace
import unittest

from kot_bot.eligibility import AttendanceRow
from kot_bot.month_policy import (
    current_month_target,
    filter_targets_for_month,
    is_first_work_week,
    manual_target_month,
    parse_target_month_override,
    parse_row_date,
    previous_month_target,
)


class MonthPolicyTests(unittest.TestCase):
    def test_manual_month_uses_current_year_for_prior_month(self) -> None:
        target = manual_target_month(4, date(2026, 5, 1))

        self.assertEqual(target.year, 2026)
        self.assertEqual(target.month, 4)
        self.assertEqual(target.start_date, date(2026, 4, 1))
        self.assertEqual(target.end_date, date(2026, 4, 30))

    def test_manual_month_uses_previous_year_for_future_month_number(self) -> None:
        target = manual_target_month(12, date(2026, 5, 1))

        self.assertEqual(target.year, 2025)
        self.assertEqual(target.month, 12)
        self.assertEqual(target.start_date, date(2025, 12, 1))
        self.assertEqual(target.end_date, date(2025, 12, 31))

    def test_manual_current_month_ends_today(self) -> None:
        target = manual_target_month(5, date(2026, 5, 12))

        self.assertEqual(target.start_date, date(2026, 5, 1))
        self.assertEqual(target.end_date, date(2026, 5, 12))

    def test_first_work_week_when_month_starts_on_weekday(self) -> None:
        self.assertTrue(is_first_work_week(date(2026, 5, 1)))
        self.assertFalse(is_first_work_week(date(2026, 5, 4)))

    def test_first_work_week_when_month_starts_on_weekend(self) -> None:
        self.assertTrue(is_first_work_week(date(2026, 8, 3)))
        self.assertTrue(is_first_work_week(date(2026, 8, 7)))
        self.assertFalse(is_first_work_week(date(2026, 8, 10)))

    def test_previous_month_target_rolls_year(self) -> None:
        target = previous_month_target(date(2026, 1, 5))

        self.assertEqual(target.year, 2025)
        self.assertEqual(target.month, 12)

    def test_current_month_target_ends_today(self) -> None:
        target = current_month_target(date(2026, 5, 20))

        self.assertEqual(target.start_date, date(2026, 5, 1))
        self.assertEqual(target.end_date, date(2026, 5, 20))

    def test_parse_row_date(self) -> None:
        self.assertEqual(parse_row_date("05/01(Fri)", 2026), date(2026, 5, 1))
        self.assertIsNone(parse_row_date("not a date", 2026))

    def test_parse_target_month_override_accepts_empty_or_yes(self) -> None:
        self.assertIsNone(parse_target_month_override("", date(2026, 5, 1)))
        self.assertIsNone(parse_target_month_override("y", date(2026, 5, 1)))

    def test_parse_target_month_override_accepts_year_month(self) -> None:
        target = parse_target_month_override("2026-04", date(2026, 5, 1))

        self.assertIsNotNone(target)
        assert target is not None
        self.assertEqual(target.year, 2026)
        self.assertEqual(target.month, 4)
        self.assertEqual(target.reason, "manual prompt override")

    def test_parse_target_month_override_rejects_bad_input(self) -> None:
        with self.assertRaises(ValueError):
            parse_target_month_override("4", date(2026, 5, 1))
        with self.assertRaises(ValueError):
            parse_target_month_override("2026-13", date(2026, 5, 1))

    def test_filter_targets_for_month_excludes_future_current_month_rows(self) -> None:
        target_month = current_month_target(date(2026, 5, 20))
        targets = [
            _target("05/01(Fri)"),
            _target("05/20(Wed)"),
            _target("05/21(Thu)"),
            _target("04/30(Thu)"),
        ]

        filtered = filter_targets_for_month(targets, target_month)

        self.assertEqual([target.row.date for target in filtered], ["05/01(Fri)", "05/20(Wed)"])


def _target(row_date: str):
    return SimpleNamespace(
        row=AttendanceRow(
            index=1,
            date=row_date,
            workday_type="Weekday",
            schedule="discretionary employee",
        )
    )


if __name__ == "__main__":
    unittest.main()
