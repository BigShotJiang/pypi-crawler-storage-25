from __future__ import annotations

import unittest

from kot_bot.timing import random_sleep


class TimingTests(unittest.TestCase):
    def test_random_sleep_uses_randomized_duration(self) -> None:
        slept: list[float] = []

        duration = random_sleep(
            0.3,
            1.0,
            sleeper=slept.append,
            randomizer=lambda minimum, maximum: (minimum + maximum) / 2,
        )

        self.assertEqual(duration, 0.65)
        self.assertEqual(slept, [0.65])


if __name__ == "__main__":
    unittest.main()
