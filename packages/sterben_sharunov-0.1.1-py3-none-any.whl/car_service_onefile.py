#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Всё в одном файле: db, manager, user, admin, reg, ent, main + .ui в строках.
Запуск из папки: python3 car_service_onefile.py
Исходные файлы проекта не меняются.
"""
import sys
from io import BytesIO

import pymysql
from pymysql.err import IntegrityError

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import *
from PyQt6.uic import loadUi

# =============================================================================
# SQL-схема (только комментарий; выполни вручную в клиенте MySQL)
# =============================================================================
# CREATE DATABASE test_car_service;
# USE test_car_service;
#
#
# CREATE TABLE users(
# 	id INT PRIMARY KEY AUTO_INCREMENT,
#     login VARCHAR(255),
#     password VARCHAR(255),
#     role VARCHAR(255)
# );
#
# CREATE TABLE cars (
#     id INT PRIMARY KEY AUTO_INCREMENT,
#     mark VARCHAR(255),
#     model VARCHAR(255),
#     manufacture_date DATE,
#     gos_number VARCHAR(255)
# );
#
# CREATE TABLE clients (
#     id INT PRIMARY KEY AUTO_INCREMENT,
#     full_name VARCHAR(255),
#     phone VARCHAR(255),
#     email VARCHAR(255)
# );
#
# CREATE TABLE mechanics (
#     id INT PRIMARY KEY AUTO_INCREMENT,
#     name VARCHAR(255),
#     specialisation VARCHAR(255),
#     phone_num VARCHAR(255)
# );
#
# CREATE TABLE services (
#     id INT PRIMARY KEY AUTO_INCREMENT,
#     name_of_service VARCHAR(255),
#     price_service DECIMAL(10, 2),
#     hours_amount INT
# );
#
# CREATE TABLE orders (
#     id INT PRIMARY KEY AUTO_INCREMENT,
#     car_id INT,
#     client_id INT,
#     mechanic_id INT,
#     admission_date DATE,
#     issue_date DATE,
#     status VARCHAR(255),
#     FOREIGN KEY (car_id) REFERENCES cars(id),
#     FOREIGN KEY (client_id) REFERENCES clients(id),
#     FOREIGN KEY (mechanic_id) REFERENCES mechanics(id)
# );
#
# CREATE TABLE order_structure (
#     id INT PRIMARY KEY AUTO_INCREMENT,
#     order_id INT,
#     service_id INT,
#     quantity INT,
#     FOREIGN KEY (order_id) REFERENCES orders(id),
#     FOREIGN KEY (service_id) REFERENCES services(id)
# );
#
# INSERT INTO clients (full_name, phone, email) VALUES
# ('Иван Петров', '+7-900-111-2233', 'ivan@mail.ru'),
# ('Мария Сидорова', '+7-900-222-3344', 'maria@mail.ru'),
# ('Алексей Смирнов', '+7-900-333-4455', 'alex@mail.ru');
#
# INSERT INTO mechanics (name, specialisation, phone_num) VALUES
# ('Дмитрий Козлов', 'двигатель', '+7-900-555-6677'),
# ('Сергей Новиков', 'электрика', '+7-900-666-7788'),
# ('Анна Морозова', 'ходовая часть', '+7-900-777-8899');
#
# INSERT INTO cars (mark, model, manufacture_date, gos_number) VALUES
# ('Toyota', 'Camry', '2020-05-15', 'А123ВВ777'),
# ('Hyundai', 'Solaris', '2018-11-20', 'В456ЕЕ777'),
# ('BMW', 'X5', '2021-02-10', 'С789КК777');
#
# INSERT INTO services (name_of_service, price_service, hours_amount) VALUES
# ('Замена масла', 2500.00, 1),
# ('Диагностика двигателя', 3500.00, 2),
# ('Замена тормозных колодок', 4000.00, 1.5),
# ('Ремонт генератора', 5000.00, 3),
# ('Регулировка фар', 1500.00, 1);
#
# INSERT INTO orders (car_id, client_id, mechanic_id, admission_date, issue_date, status) VALUES
# (1, 1, 1, '2025-04-01', '2025-04-02', 'завершен'),
# (2, 2, 2, '2025-04-05', NULL, 'в работе'),
# (3, 3, 3, '2025-04-07', NULL, 'принят');
#
# INSERT INTO order_structure (order_id, service_id, quantity) VALUES
# (1, 1, 1),
# (1, 2, 1),
# (2, 4, 1),
# (2, 5, 1),
# (3, 3, 2),
# (3, 2, 1);
#
#
# INSERT INTO users (login, password, role)
# VALUES("admin", "admin", "admin"),
# ("manager", "manager", "manager"),
# ("user", "user", "user");
#
#
# SELECT * FROM users;
#
#
# SELECT * FROM orders;

CATALOG2_UI = '<?xml version="1.0" encoding="UTF-8"?>\n<ui version="4.0">\n <class>CatalogForm</class>\n <widget class="QWidget" name="CatalogForm">\n  <property name="geometry">\n   <rect>\n    <x>0</x>\n    <y>0</y>\n    <width>628</width>\n    <height>320</height>\n   </rect>\n  </property>\n  <property name="windowTitle">\n   <string>Каталог (демо)</string>\n  </property>\n  <layout class="QVBoxLayout" name="verticalLayoutMain">\n   <item>\n    <layout class="QHBoxLayout" name="horizontalLayoutTop">\n     <item>\n      <widget class="QLabel" name="labelCategory">\n       <property name="text">\n        <string>Категория:</string>\n       </property>\n      </widget>\n     </item>\n     <item>\n      <widget class="QComboBox" name="comboBoxCategory"/>\n     </item>\n     <item>\n      <widget class="QLabel" name="labelSearch">\n       <property name="text">\n        <string>Поиск:</string>\n       </property>\n      </widget>\n     </item>\n     <item>\n      <widget class="QLineEdit" name="lineEditSearch">\n       <property name="placeholderText">\n        <string>Название услуги</string>\n       </property>\n      </widget>\n     </item>\n    </layout>\n   </item>\n   <item>\n    <widget class="QGroupBox" name="groupBoxSort">\n     <property name="title">\n      <string>Сортировка по цене</string>\n     </property>\n     <layout class="QHBoxLayout" name="horizontalLayoutSort">\n      <item>\n       <widget class="QRadioButton" name="radioButtonAsc">\n        <property name="text">\n         <string>По возрастанию</string>\n        </property>\n        <property name="checked">\n         <bool>true</bool>\n        </property>\n       </widget>\n      </item>\n      <item>\n       <widget class="QRadioButton" name="radioButtonDesc">\n        <property name="text">\n         <string>По убыванию</string>\n        </property>\n       </widget>\n      </item>\n     </layout>\n    </widget>\n   </item>\n   <item>\n    <widget class="QGroupBox" name="groupBoxProducts">\n     <property name="title">\n      <string>Товары категории (чекбоксы)</string>\n     </property>\n     <layout class="QVBoxLayout" name="verticalLayoutProductsBox">\n      <item>\n       <widget class="QScrollArea" name="scrollAreaProducts">\n        <property name="widgetResizable">\n         <bool>true</bool>\n        </property>\n        <widget class="QWidget" name="scrollAreaWidgetContents">\n         <property name="geometry">\n          <rect>\n           <x>0</x>\n           <y>0</y>\n           <width>572</width>\n           <height>75</height>\n          </rect>\n         </property>\n         <layout class="QVBoxLayout" name="verticalLayoutProducts"/>\n        </widget>\n       </widget>\n      </item>\n     </layout>\n    </widget>\n   </item>\n   <item>\n    <layout class="QHBoxLayout" name="horizontalLayoutBottom">\n     <item>\n      <widget class="QLabel" name="labelAddress">\n       <property name="text">\n        <string>Адрес:</string>\n       </property>\n      </widget>\n     </item>\n     <item>\n      <widget class="QLineEdit" name="lineEditAddress"/>\n     </item>\n     <item>\n      <widget class="QLabel" name="labelComment">\n       <property name="text">\n        <string>Комментарий:</string>\n       </property>\n      </widget>\n     </item>\n     <item>\n      <widget class="QLineEdit" name="lineEditComment"/>\n     </item>\n     <item>\n      <widget class="QPushButton" name="pushButtonOrder">\n       <property name="text">\n        <string>Создать заказ</string>\n       </property>\n      </widget>\n     </item>\n    </layout>\n   </item>\n   <item>\n    <widget class="QLabel" name="labelTotal">\n     <property name="text">\n      <string>Итого: 0 руб.</string>\n     </property>\n    </widget>\n   </item>\n  </layout>\n </widget>\n <resources/>\n <connections/>\n</ui>\n'

ADMIN_UI = '<?xml version="1.0" encoding="UTF-8"?>\n<ui version="4.0">\n <class>AdminDialog</class>\n <widget class="QDialog" name="AdminDialog">\n  <property name="geometry">\n   <rect>\n    <x>0</x>\n    <y>0</y>\n    <width>480</width>\n    <height>420</height>\n   </rect>\n  </property>\n  <property name="windowTitle">\n   <string>Админ: услуги</string>\n  </property>\n  <layout class="QVBoxLayout" name="verticalLayoutMain">\n   <item>\n    <layout class="QFormLayout" name="formLayoutServices">\n     <item row="0" column="0">\n      <widget class="QLabel" name="labelServiceName">\n       <property name="text">\n        <string>Название:</string>\n       </property>\n      </widget>\n     </item>\n     <item row="0" column="1">\n      <widget class="QLineEdit" name="lineEditServiceName"/>\n     </item>\n     <item row="1" column="0">\n      <widget class="QLabel" name="labelServicePrice">\n       <property name="text">\n        <string>Цена (руб.):</string>\n       </property>\n      </widget>\n     </item>\n     <item row="1" column="1">\n      <widget class="QLineEdit" name="lineEditServicePrice"/>\n     </item>\n     <item row="2" column="0">\n      <widget class="QLabel" name="labelServiceHours">\n       <property name="text">\n        <string>Часы:</string>\n       </property>\n      </widget>\n     </item>\n     <item row="2" column="1">\n      <widget class="QLineEdit" name="lineEditServiceHours"/>\n     </item>\n    </layout>\n   </item>\n   <item>\n    <widget class="QPushButton" name="pushButtonAddService">\n     <property name="text">\n      <string>Добавить услугу</string>\n     </property>\n    </widget>\n   </item>\n   <item>\n    <widget class="QLabel" name="labelServicesHint">\n     <property name="text">\n      <string>Список услуг (выбери строку для удаления):</string>\n     </property>\n    </widget>\n   </item>\n   <item>\n    <widget class="QListWidget" name="listWidgetServices">\n     <property name="sizePolicy">\n      <sizepolicy hsizetype="Preferred" vsizetype="Expanding">\n       <horstretch>0</horstretch>\n       <verstretch>1</verstretch>\n      </sizepolicy>\n     </property>\n     <property name="minimumSize">\n      <size>\n       <width>0</width>\n       <height>160</height>\n      </size>\n     </property>\n    </widget>\n   </item>\n   <item>\n    <widget class="QPushButton" name="pushButtonDeleteService">\n     <property name="text">\n      <string>Удалить выбранную</string>\n     </property>\n    </widget>\n   </item>\n  </layout>\n </widget>\n <resources/>\n <connections/>\n</ui>\n'

ENT_UI = '<?xml version="1.0" encoding="UTF-8"?>\n<ui version="4.0">\n <class>Dialog</class>\n <widget class="QDialog" name="Dialog">\n  <property name="geometry">\n   <rect>\n    <x>0</x>\n    <y>0</y>\n    <width>400</width>\n    <height>300</height>\n   </rect>\n  </property>\n  <property name="windowTitle">\n   <string>Dialog</string>\n  </property>\n  <widget class="QPushButton" name="pushButton_7">\n   <property name="geometry">\n    <rect>\n     <x>280</x>\n     <y>260</y>\n     <width>100</width>\n     <height>32</height>\n    </rect>\n   </property>\n   <property name="text">\n    <string>Зарегаться</string>\n   </property>\n  </widget>\n  <widget class="QLineEdit" name="lineEdit_3">\n   <property name="geometry">\n    <rect>\n     <x>140</x>\n     <y>30</y>\n     <width>113</width>\n     <height>21</height>\n    </rect>\n   </property>\n   <property name="placeholderText">\n    <string>Логин</string>\n   </property>\n  </widget>\n  <widget class="QLineEdit" name="lineEdit__4">\n   <property name="geometry">\n    <rect>\n     <x>140</x>\n     <y>60</y>\n     <width>113</width>\n     <height>21</height>\n    </rect>\n   </property>\n   <property name="placeholderText">\n    <string>Пароль</string>\n   </property>\n  </widget>\n  <widget class="QPushButton" name="pushButton_3">\n   <property name="geometry">\n    <rect>\n     <x>150</x>\n     <y>100</y>\n     <width>100</width>\n     <height>32</height>\n    </rect>\n   </property>\n   <property name="text">\n    <string>Войти</string>\n   </property>\n  </widget>\n </widget>\n <resources/>\n <connections/>\n</ui>\n'

REG_UI = '<?xml version="1.0" encoding="UTF-8"?>\n<ui version="4.0">\n <class>Dialog</class>\n <widget class="QDialog" name="Dialog">\n  <property name="geometry">\n   <rect>\n    <x>0</x>\n    <y>0</y>\n    <width>400</width>\n    <height>300</height>\n   </rect>\n  </property>\n  <property name="windowTitle">\n   <string>Dialog</string>\n  </property>\n  <widget class="QLineEdit" name="lineEdit">\n   <property name="geometry">\n    <rect>\n     <x>150</x>\n     <y>30</y>\n     <width>113</width>\n     <height>21</height>\n    </rect>\n   </property>\n   <property name="placeholderText">\n    <string>Логин</string>\n   </property>\n  </widget>\n  <widget class="QLineEdit" name="lineEdit_2">\n   <property name="geometry">\n    <rect>\n     <x>150</x>\n     <y>60</y>\n     <width>113</width>\n     <height>21</height>\n    </rect>\n   </property>\n   <property name="placeholderText">\n    <string>Пароль</string>\n   </property>\n  </widget>\n  <widget class="QPushButton" name="pushButton">\n   <property name="geometry">\n    <rect>\n     <x>160</x>\n     <y>100</y>\n     <width>100</width>\n     <height>32</height>\n    </rect>\n   </property>\n   <property name="text">\n    <string>Зарегаться</string>\n   </property>\n  </widget>\n  <widget class="QPushButton" name="pushButton_2">\n   <property name="geometry">\n    <rect>\n     <x>290</x>\n     <y>260</y>\n     <width>100</width>\n     <height>32</height>\n    </rect>\n   </property>\n   <property name="text">\n    <string>Войти</string>\n   </property>\n  </widget>\n </widget>\n <resources/>\n <connections/>\n</ui>\n'

def load_ui_embedded(xml: str, base_instance) -> None:
    loadUi(BytesIO(xml.encode("utf-8")), base_instance)


# ========== db.py ==========
import pymysql

DB_CONFIG = {
    "user": "root",
    "password": "anksoonamoon",
    "host": "localhost",
    "database": "test_car_service",
}

conn = pymysql.connect(**DB_CONFIG)



# ========== manager.py ==========
from PyQt6.QtWidgets import QDialog


class Manager(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Manager")
        self.setGeometry(400, 300, 400, 300)


# ========== user.py ==========
from PyQt6.QtWidgets import *
from PyQt6.uic import loadUi



class User(QWidget):
    def __init__(self):
        super().__init__()
        load_ui_embedded(CATALOG2_UI, self)
        self.services = []
        self.checkBoxes = []

        content = self.scrollAreaWidgetContents
        if content.layout() is None:
            self.verticalLayoutProducts = QVBoxLayout(content)
        else:
            self.verticalLayoutProducts = content.layout()

        self.comboBoxCategory.currentTextChanged.connect(self.drawChecks)
        self.lineEditSearch.textChanged.connect(self.drawChecks)
        self.radioButtonAsc.toggled.connect(self.drawChecks)
        self.radioButtonDesc.toggled.connect(self.drawChecks)
        self.pushButtonOrder.clicked.connect(self.createOrder)

        self.loadData()

    def categoryOf(self, hours):
        if hours <= 1.5:
            return "Быстрые"
        if hours <= 2.5:
            return "Стандарт"
        return "Сложные"

    def loadData(self):
        cur = conn.cursor()
        cur.execute(
            "SELECT id, name_of_service, price_service, hours_amount FROM services ORDER BY id"
        )
        self.services = []
        for sid, name, price, hours in cur.fetchall():
            self.services.append(
                {
                    "id": sid,
                    "name": name,
                    "price": float(price),
                    "hours": float(hours),
                    "category": self.categoryOf(float(hours)),
                }
            )
        self.fillCategories()
        self.drawChecks()

    def fillCategories(self):
        selected = self.comboBoxCategory.currentText()
        categories = sorted({s["category"] for s in self.services})
        self.comboBoxCategory.clear()
        self.comboBoxCategory.addItem("Все")
        self.comboBoxCategory.addItems(categories)
        i = self.comboBoxCategory.findText(selected)
        self.comboBoxCategory.setCurrentIndex(i if i >= 0 else 0)

    def drawChecks(self):
        while self.verticalLayoutProducts.count():
            item = self.verticalLayoutProducts.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
        self.checkBoxes = []

        cat = self.comboBoxCategory.currentText()
        search = self.lineEditSearch.text().strip().lower()
        data = self.services[:]
        data.sort(key=lambda x: x["price"], reverse=self.radioButtonDesc.isChecked())

        for s in data:
            if cat != "Все" and s["category"] != cat:
                continue
            if search and search not in s["name"].lower():
                continue
            cb = QCheckBox(f'{s["name"]} ({s["price"]} руб.)')
            cb.setProperty("price", s["price"])
            cb.toggled.connect(self.updateTotal)
            self.verticalLayoutProducts.addWidget(cb)
            self.checkBoxes.append(cb)

        self.verticalLayoutProducts.addStretch()
        self.updateTotal()

    def updateTotal(self):
        total = 0.0
        for cb in self.checkBoxes:
            if cb.isChecked():
                total += float(cb.property("price"))
        self.labelTotal.setText(f"Итого: {total:.2f} руб.")

    def createOrder(self):
        address = self.lineEditAddress.text().strip()
        comment = self.lineEditComment.text().strip()
        QMessageBox.information(
            self,
            "Демо заказ",
            f"Заказ создан (демо)\nАдрес: {address or '-'}\nКомментарий: {comment or '-'}\n{self.labelTotal.text()}",
        )

# ========== admin.py ==========
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QApplication, QDialog, QListWidgetItem, QMessageBox
from PyQt6.uic import loadUi
from pymysql.err import IntegrityError


class Admin(QDialog):
    def __init__(self):
        super().__init__()
        load_ui_embedded(ADMIN_UI, self)
        self.pushButtonAddService.clicked.connect(self.add_service)
        self.pushButtonDeleteService.clicked.connect(self.delete_service)
        self.reload_list()

    def reload_list(self):
        self.listWidgetServices.clear()
        c = conn.cursor()
        c.execute("SELECT id,name_of_service,price_service,hours_amount FROM services ORDER BY id")
        for i,n,p,h in c.fetchall():
            it = QListWidgetItem(f"{n} — {p} руб., {h} ч.")
            it.setData(Qt.ItemDataRole.UserRole, i)
            self.listWidgetServices.addItem(it)

    def add_service(self):
        n = self.lineEditServiceName.text().strip()
        p = float(self.lineEditServicePrice.text().replace(",", "."))
        h = float(self.lineEditServiceHours.text().replace(",", "."))
        conn.cursor().execute("INSERT INTO services(name_of_service,price_service,hours_amount)VALUES(%s,%s,%s)", (n,p,h))
        conn.commit()
        for f in (self.lineEditServiceName, self.lineEditServicePrice, self.lineEditServiceHours): f.clear()
        self.reload_list()

    def delete_service(self):
        it = self.listWidgetServices.currentItem()
        if not it:
            return
        sid = it.data(Qt.ItemDataRole.UserRole)
        try:
            c = conn.cursor()
            c.execute("DELETE FROM services WHERE id=%s", (sid,))
            conn.commit()
            self.reload_list()
        except IntegrityError:
            conn.rollback()
            QMessageBox.information(
                self,
                "Заглушка",
                "Удалено. (Демо: в БД запись не удалена — на услугу есть заказы.)",
            )


# ========== reg.py ==========
import os
import sys
from PyQt6.QtWidgets import *
from PyQt6.uic import *


class Registration(QDialog):
    def __init__(self):
        super().__init__()
        load_ui_embedded(REG_UI, self)
        self.setWindowTitle("Registration")
        self.setGeometry(500, 400, 500, 400)

        self.pushButton_2.clicked.connect(self.go_to_login)
        self.pushButton.clicked.connect(self.do_register)

    def go_to_login(self):
        self.login_window = Login()
        self.login_window.show()
        self.close()

    def do_register(self):
        login = self.lineEdit.text()
        password = self.lineEdit_2.text()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO users (login, password, role) VALUES (%s, %s, %s)", (login, password, "user"))
        conn.commit()
        cursor.close()
        self.go_to_login()



# ========== ent.py ==========
import os
import sys
from PyQt6.QtWidgets import *
from PyQt6.uic import *


class Login(QDialog):
    def __init__(self):
        super().__init__()
        load_ui_embedded(ENT_UI, self)
        self.setWindowTitle("Login")
        self.setGeometry(500, 400, 500, 400)

        self.pushButton_7.clicked.connect(self.go_to_register)
        self.pushButton_3.clicked.connect(self.check_login)

    def go_to_register(self):
        self.reg = Registration()
        self.reg.show()
        self.close()

    def check_login(self):
        login = self.lineEdit_3.text()
        password = self.lineEdit__4.text()

        cursor = conn.cursor()
        cursor.execute("SELECT role FROM users WHERE login = %s AND password = %s", (login, password))
        result = cursor.fetchone()
        if result:
            role = result[0]
            if role == "admin":
                self.new_window = Admin()
            if role == "user":
                self.new_window = User()
            if role == "manager":
                self.new_window = Manager()
            self.new_window.show()
            self.close()

# ========== main.py ==========
import os
import sys
from PyQt6.QtWidgets import *
from PyQt6.uic import *


def main():
    app = QApplication(sys.argv)
    window = Registration()
    window.show()
    sys.exit(app.exec())

if __name__ == '__main__':
    main()





