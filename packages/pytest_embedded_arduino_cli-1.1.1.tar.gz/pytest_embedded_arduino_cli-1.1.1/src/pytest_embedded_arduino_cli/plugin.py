from __future__ import annotations

from pathlib import Path
import shlex
from typing import Any

import pytest

from .ardutest import ArduTestSession
from .app import (
    ArduinoCliBuildConfig,
    SketchConfigError,
    UnsupportedProfileError,
    resolve_sketch_dir,
    resolve_test_path,
)
from .flasher import ArduinoCliUploadConfig
from .serial import (
    complete_host_arduino_socket_url,
    ensure_default_embedded_services,
    install_fast_socket_redirect_thread,
    is_socket_url,
    resolve_port,
    resolve_upload_port,
    socket_url_needs_port_completion,
    wait_for_socket_url,
)


def _should_build(run_mode: str) -> bool:
    return run_mode in ("all", "build")


def _should_upload(run_mode: str) -> bool:
    return run_mode in ("all", "test")


def pytest_addoption(parser: pytest.Parser) -> None:
    group = parser.getgroup("arduino-cli")
    group.addoption(
        "--run-mode",
        action="store",
        choices=("all", "build", "test"),
        default="all",
        help="Select whether to run build only, upload-and-test with existing artifacts, or build-upload-test.",
    )
    group.addoption(
        "--profile",
        action="store",
        help="Arduino CLI sketch profile name from sketch.yaml.",
    )
    group.addoption(
        "--arduino-test-timeout",
        action="store",
        type=float,
        default=30.0,
        help="Timeout in seconds while waiting for ArduTest serial output.",
    )
    group.addoption(
        "--clean",
        action="store_true",
        default=False,
        help="Pass --clean to arduino-cli compile.",
    )


def pytest_report_header(config: pytest.Config) -> list[str]:
    return [
        f"arduino-cli run-mode: {config.getoption('run_mode')}",
        f"arduino-cli profile: {config.getoption('profile') or 'default'}",
    ]


def pytest_configure(config: pytest.Config) -> None:
    install_fast_socket_redirect_thread()
    _remember_initial_ports(config)
    ensure_default_embedded_services(config)
    _set_optional_metadata(config)


def _remember_initial_ports(config: pytest.Config) -> None:
    config._arduino_cli_initial_port = getattr(config.option, "port", None)
    config._arduino_cli_initial_flash_port = getattr(config.option, "flash_port", None)


def _reset_runtime_ports(config: pytest.Config) -> None:
    config.option.port = getattr(config, "_arduino_cli_initial_port", None)
    config.option.flash_port = getattr(config, "_arduino_cli_initial_flash_port", None)


def _set_optional_metadata(config: pytest.Config) -> None:
    try:
        from pytest_metadata.plugin import metadata_key
    except ImportError:
        return

    config.stash[metadata_key]["Profile"] = config.getoption("profile") or "default"


def _request_path(request: pytest.FixtureRequest) -> Path:
    if hasattr(request, "path"):
        return Path(request.path)
    return Path(str(request.fspath))


def _request_has_sketch(request: pytest.FixtureRequest) -> bool:
    test_path = resolve_test_path(_request_path(request))
    return any(test_path.glob("*.ino"))


def _terminal_reporter(config: pytest.Config) -> Any | None:
    return config.pluginmanager.getplugin("terminalreporter")


def _verbose_level(config: pytest.Config) -> int:
    return int(getattr(config.option, "verbose", 0) or 0)


def _log_command(
    config: pytest.Config,
    *,
    action: str,
    command: list[str],
    details: dict[str, str | None],
) -> None:
    verbosity = _verbose_level(config)
    if verbosity < 1:
        return

    reporter = _terminal_reporter(config)
    if reporter is None:
        return

    reporter.write_line(f"[arduino-cli] {action}: {shlex.join(command)}")
    if verbosity < 2:
        return

    for key, value in details.items():
        if value is None:
            continue
        reporter.write_line(f"[arduino-cli] {action} {key}: {value}")


def _log_skip(config: pytest.Config, reason: str) -> None:
    if _verbose_level(config) < 1:
        return

    reporter = _terminal_reporter(config)
    if reporter is None:
        return

    reporter.write_line(f"[arduino-cli] skip: {reason}")


@pytest.fixture
def app_path(request: pytest.FixtureRequest) -> str:
    if not _request_has_sketch(request):
        return str(resolve_test_path(_request_path(request)))
    return str(resolve_sketch_dir(_request_path(request)))


@pytest.fixture
def build_dir(request: pytest.FixtureRequest) -> str:
    try:
        arduino_cli_app = _build_config_from_request(request, required=False)
    except UnsupportedProfileError:
        profile = request.config.getoption("profile") or "default"
        return str(resolve_test_path(_request_path(request)) / "build" / profile)
    if arduino_cli_app is None:
        return str(resolve_test_path(_request_path(request)) / "build" / "default")
    return str(arduino_cli_app.build_path)


@pytest.fixture
def skip_autoflash() -> bool:
    # Build/upload are handled explicitly by this plugin instead of pytest-embedded services.
    return True


def _build_config_from_request(
    request: pytest.FixtureRequest,
    *,
    required: bool = True,
) -> ArduinoCliBuildConfig | None:
    config = request.config
    should_require = required or _request_has_sketch(request)
    try:
        return ArduinoCliBuildConfig.from_test_path(
            _request_path(request),
            profile=config.getoption("profile"),
            clean=config.getoption("clean"),
        )
    except UnsupportedProfileError:
        raise
    except SketchConfigError:
        if should_require:
            raise
        return None


@pytest.fixture(scope="module")
def arduino_cli_app(request: pytest.FixtureRequest) -> ArduinoCliBuildConfig:
    try:
        return _build_config_from_request(request)
    except UnsupportedProfileError as e:
        _log_skip(request.config, str(e))
        pytest.skip(str(e))


@pytest.fixture(scope="module")
def arduino_cli_flasher(
    request: pytest.FixtureRequest,
    arduino_cli_app: ArduinoCliBuildConfig,
) -> ArduinoCliUploadConfig:
    return ArduinoCliUploadConfig.from_build_config(
        arduino_cli_app,
        port=resolve_upload_port(request.config, profile=arduino_cli_app.profile),
    )


@pytest.fixture
def arduino_test(request: pytest.FixtureRequest, dut: Any) -> ArduTestSession:
    return ArduTestSession(
        dut,
        timeout=request.config.getoption("arduino_test_timeout"),
    )


@pytest.fixture(scope="module", autouse=True)
def arduino_cli_resolved_port(request: pytest.FixtureRequest) -> None:
    try:
        arduino_cli_app = _build_config_from_request(request, required=False)
    except UnsupportedProfileError as e:
        _log_skip(request.config, str(e))
        pytest.skip(str(e))
    if arduino_cli_app is None:
        return

    _reset_runtime_ports(request.config)

    if getattr(request.config, "_arduino_cli_initial_flash_port", None):
        return
    if getattr(request.config, "_arduino_cli_initial_port", None):
        return

    resolved_port = resolve_port(request.config, profile=arduino_cli_app.profile)
    if not resolved_port and is_socket_url(arduino_cli_app.profile_port):
        resolved_port = arduino_cli_app.profile_port
    if resolved_port:
        request.config.option.port = resolved_port


@pytest.fixture(scope="module", autouse=True)
def arduino_cli_build(
    request: pytest.FixtureRequest,
    arduino_cli_resolved_port: None,
) -> None:
    try:
        arduino_cli_app = _build_config_from_request(request, required=False)
    except UnsupportedProfileError as e:
        _log_skip(request.config, str(e))
        pytest.skip(str(e))
    if arduino_cli_app is None:
        return
    if not _should_build(request.config.getoption("run_mode")):
        return

    _log_command(
        request.config,
        action="compile",
        command=arduino_cli_app.build_command(),
        details={
            "cwd": str(arduino_cli_app.sketch_dir),
            "sketch_dir": str(arduino_cli_app.sketch_dir),
            "build_path": str(arduino_cli_app.build_path),
            "profile": arduino_cli_app.profile,
        },
    )
    arduino_cli_app.compile()


@pytest.fixture(scope="module", autouse=True)
def arduino_cli_upload(
    request: pytest.FixtureRequest,
    arduino_cli_build: None,
    arduino_cli_resolved_port: None,
) -> None:
    run_mode = request.config.getoption("run_mode")
    if not _should_upload(run_mode):
        return
    try:
        arduino_cli_app = _build_config_from_request(request, required=False)
    except UnsupportedProfileError as e:
        _log_skip(request.config, str(e))
        pytest.skip(str(e))
    if arduino_cli_app is None:
        return
    if not arduino_cli_app.build_path.is_dir():
        raise FileNotFoundError(
            f"build output directory not found: {arduino_cli_app.build_path}. "
            "Run with --run-mode=all first, or build the sketch before --run-mode=test."
        )

    arduino_cli_flasher = ArduinoCliUploadConfig.from_build_config(
        arduino_cli_app,
        port=resolve_upload_port(request.config, profile=arduino_cli_app.profile),
    )

    _log_command(
        request.config,
        action="upload",
        command=arduino_cli_flasher.upload_command(),
        details={
            "cwd": str(arduino_cli_flasher.sketch_dir),
            "sketch_dir": str(arduino_cli_flasher.sketch_dir),
            "build_path": str(arduino_cli_flasher.build_path),
            "profile": arduino_cli_flasher.profile,
            "port": arduino_cli_flasher.port,
        },
    )
    arduino_cli_flasher.upload()

    runtime_port = resolve_port(request.config, profile=arduino_cli_app.profile)
    if socket_url_needs_port_completion(runtime_port):
        request.config.option.port = complete_host_arduino_socket_url(
            runtime_port,
            arduino_cli_app.build_path,
        )
        wait_for_socket_url(request.config.option.port)


@pytest.fixture(autouse=True)
def skip_test_execution_in_build_mode(
    request: pytest.FixtureRequest,
    arduino_cli_build: None,
) -> None:
    if request.config.getoption("run_mode") == "build":
        pytest.skip("skipped test execution in build-only mode")
