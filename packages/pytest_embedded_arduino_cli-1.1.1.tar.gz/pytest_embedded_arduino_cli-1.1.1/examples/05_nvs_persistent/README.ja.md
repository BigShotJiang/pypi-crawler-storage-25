# 05_nvs_persistent

このサンプルは、ESP32 の永続領域が default では消去されないことを示します。

- デフォルト profile は `esp32` です
- 将来ほかの ESP32 系 target を追加した場合は `--profile` を明示して使います
- このサンプルは ESP32 の `Preferences` と NVS を対象にしています
- `uno` のような非対応 profile は `sketch.yaml` に含めておらず、指定した場合は build 前に skip されます

`uno` では挙動が異なり、近い話題は EEPROM ですが、このサンプルは ESP32 の `Preferences` と NVS を対象にしています。

実行例:

```bash
uv run pytest -s examples/05_nvs_persistent --port=/dev/ttyUSB0
```

この sketch は `Preferences` に起動回数を保存します。
ESP32 では erase なしで同じテストを繰り返すと、保存された値が次回以降にも残り、起動回数が増えていきます。

テスト自体は `BOOT_COUNT <n>` が出力されることだけを確認します。
永続化の違いを見たい場合は、同じコマンドを複数回実行して表示値を比較してください。

同じ注意点は SPIFFS のような永続ストレージにも当てはまります。
初回書き込み直後や erase 後は未フォーマットの状態で起動することがあり、mount 時のフォーマットにはそれなりの時間がかかります。
そのため、毎回 full erase をしない方が実用的な場合もあります。

その場合は、テストが不要な状態を残さないように設計してください。
たとえばテスト中に生成したファイルを実行の最初または最後に削除し、容量不足や副作用が起きないようにしておくのが安全です。

実際の sketch は `nvs_persistent/` 配下にあります。
