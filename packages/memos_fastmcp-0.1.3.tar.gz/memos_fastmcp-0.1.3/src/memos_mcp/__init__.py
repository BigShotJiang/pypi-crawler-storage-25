"""Memos MCP Server - MCP server for Memos note-taking tool."""

__version__ = "0.1.3"