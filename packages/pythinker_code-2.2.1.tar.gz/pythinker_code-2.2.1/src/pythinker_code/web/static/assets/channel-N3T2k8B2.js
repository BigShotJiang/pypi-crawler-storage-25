import{U as a,C as n}from"./mermaid.core-DE-3B90d.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
