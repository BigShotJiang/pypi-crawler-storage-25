import{b as r}from"./graph-Cdru59AN.js";var e=4;function a(o){return r(o,e)}export{a as c};
