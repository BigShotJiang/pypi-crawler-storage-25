"""PithToken CLI — Manage your AI API gateway from the terminal."""
__version__ = "0.1.0"
