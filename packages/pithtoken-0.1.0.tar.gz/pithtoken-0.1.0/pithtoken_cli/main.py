#!/usr/bin/env python3
"""
PithToken CLI — One API key for 200+ AI models.
https://pithtoken.ai

Usage:
  pith signup          Create a new account
  pith login           Log into your account
  pith whoami          Show current user info & API key
  pith models          List available AI models
  pith test [model]    Send a test request
  pith config          Show saved config path
  pith logout          Clear saved credentials
"""

import sys
import getpass
import argparse
import webbrowser

from pithtoken_cli import __version__
from pithtoken_cli.api import PithAPI
from pithtoken_cli.config import save_config, load_config, get_token, get_api_key, get_email, clear_config


LOGO = r"""
    ____  _ __  __   ______      __
   / __ \(_) /_/ /_ /_  __/___  / /_____  ____
  / /_/ / / __/ __ \ / / / __ \/ //_/ _ \/ __ \
 / ____/ / /_/ / / // / / /_/ / ,< /  __/ / / /
/_/   /_/\__/_/ /_//_/  \____/_/|_|\___/_/ /_/

  One API key. 200+ AI models. Zero hassle.
"""


def print_success(msg):
    print(f"\033[92m✓\033[0m {msg}")


def print_error(msg):
    print(f"\033[91m✗\033[0m {msg}")


def print_info(msg):
    print(f"\033[94m→\033[0m {msg}")


def cmd_signup(api: PithAPI):
    """Create a new PithToken account."""
    print(LOGO)
    print("  Create your free PithToken account\n")

    email = input("  Email: ").strip()
    if not email:
        print_error("Email is required.")
        sys.exit(1)

    password = getpass.getpass("  Password: ")
    if len(password) < 6:
        print_error("Password must be at least 6 characters.")
        sys.exit(1)

    confirm = getpass.getpass("  Confirm password: ")
    if password != confirm:
        print_error("Passwords do not match.")
        sys.exit(1)

    try:
        print_info("Creating your account...")
        result = api.signup(email, password)

        save_config({
            "email": email,
            "access_token": result.get("access_token"),
            "api_key": result.get("api_key"),
        })

        print()
        print_success("Account created successfully!")
        print()
        print(f"  Email:    {email}")
        print(f"  API Key:  {result.get('api_key')}")
        print(f"  Credit:   ${result.get('credit_remaining', 0):.2f}")
        print()
        print_info("Your API key has been saved to ~/.pithtoken/config.json")
        print_info("Start using Pith:")
        print()
        print("    from openai import OpenAI")
        print(f'    client = OpenAI(api_key="{result.get("api_key")}", base_url="https://api.pithtoken.ai/v1")')
        print()

    except Exception as e:
        print_error(f"Signup failed: {e}")
        sys.exit(1)


def cmd_login(api: PithAPI):
    """Log into your PithToken account."""
    print(LOGO)
    print("  Log into your PithToken account\n")

    email = input("  Email: ").strip()
    password = getpass.getpass("  Password: ")

    try:
        print_info("Logging in...")
        result = api.login(email, password)

        save_config({
            "email": email,
            "access_token": result.get("access_token"),
            "api_key": result.get("api_key"),
        })

        print()
        print_success(f"Welcome back, {email}!")
        print(f"  API Key:  {result.get('api_key')}")
        print(f"  Plan:     {result.get('plan', 'free')}")
        print(f"  Credit:   ${result.get('credit_remaining', 0):.2f}")
        print()

    except Exception as e:
        print_error(f"Login failed: {e}")
        sys.exit(1)


def cmd_whoami(api: PithAPI):
    """Display current account info."""
    token = get_token()
    if not token:
        print_error("Not logged in. Run: pith login")
        sys.exit(1)

    try:
        info = api.whoami(token)
        print()
        print(f"  Email:         {info.get('email')}")
        print(f"  API Key:       {info.get('api_key')}")
        print(f"  Plan:          {info.get('plan', 'free')}")
        print(f"  Credit:        ${info.get('credit_remaining', 0):.2f}")
        print(f"  Total Requests:{info.get('total_requests', 0):,}")
        print(f"  Tokens Saved:  {info.get('total_saved_tokens', 0):,}")
        print(f"  Avg Savings:   {info.get('avg_savings_percent', 0):.1f}%")
        print()

    except Exception as e:
        print_error(f"Failed to fetch user info: {e}")
        print_info("Try logging in again: pith login")
        sys.exit(1)


def cmd_models(api: PithAPI):
    """List available AI models."""
    api_key = get_api_key()
    if not api_key:
        print_error("Not logged in. Run: pith login")
        sys.exit(1)

    try:
        result = api.models(api_key)
        models = result.get("data", [])

        print(f"\n  Available Models ({len(models)}):\n")
        for m in models:
            mid = m.get("id", "unknown")
            owner = m.get("owned_by", "")
            print(f"    {mid:<45} {owner}")
        print()

    except Exception as e:
        print_error(f"Failed to fetch models: {e}")
        sys.exit(1)


def cmd_test(api: PithAPI, model: str = "gpt-4o-mini"):
    """Send a test API request."""
    api_key = get_api_key()
    if not api_key:
        print_error("Not logged in. Run: pith login")
        sys.exit(1)

    try:
        print_info(f"Sending test request to {model}...")
        result = api.test_call(api_key, model)

        content = result["choices"][0]["message"]["content"]
        usage = result.get("usage", {})

        print()
        print_success("API call successful!")
        print(f"  Model:    {model}")
        print(f"  Response: {content}")
        print(f"  Tokens:   {usage.get('prompt_tokens', 0)} in / {usage.get('completion_tokens', 0)} out")
        print()

    except Exception as e:
        print_error(f"Test failed: {e}")
        sys.exit(1)


def cmd_config():
    """Show config info."""
    config = load_config()
    if config:
        print(f"\n  Config file: ~/.pithtoken/config.json")
        print(f"  Email:       {config.get('email', 'N/A')}")
        print(f"  API Key:     {config.get('api_key', 'N/A')}")
        print(f"  Logged in:   {'Yes' if config.get('access_token') else 'No'}")
        print()
    else:
        print_info("No config found. Run: pith signup")


def cmd_upgrade(api: PithAPI):
    """Open billing page to upgrade plan or add payment method."""
    token = get_token()
    email = get_email()
    if not token:
        print_error("Not logged in. Run: pith login")
        sys.exit(1)

    url = f"https://pithtoken.ai/dashboard/billing"
    print_info(f"Opening billing page for {email}...")
    print(f"  {url}")
    webbrowser.open(url)
    print()
    print_success("Billing page opened in your browser.")
    print_info("Add a payment method or upgrade your plan there.")


def cmd_dashboard():
    """Open the Pith dashboard in the browser."""
    url = "https://pithtoken.ai/dashboard"
    print_info("Opening dashboard...")
    webbrowser.open(url)
    print_success("Dashboard opened in your browser.")


def cmd_logout():
    """Clear saved credentials."""
    clear_config()
    print_success("Logged out. Credentials removed.")


def main():
    parser = argparse.ArgumentParser(
        prog="pith",
        description="PithToken CLI — One API key for 200+ AI models.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="  https://pithtoken.ai\n  Docs: https://pithtoken.ai/docs",
    )
    parser.add_argument("-v", "--version", action="version", version=f"pith {__version__}")
    parser.add_argument("--base-url", default="https://pithtoken.ai", help=argparse.SUPPRESS)

    sub = parser.add_subparsers(dest="command")
    sub.add_parser("signup", help="Create a new account")
    sub.add_parser("login", help="Log into your account")
    sub.add_parser("whoami", help="Show current user info & API key")
    sub.add_parser("models", help="List available AI models")

    test_parser = sub.add_parser("test", help="Send a test API request")
    test_parser.add_argument("model", nargs="?", default="gpt-4o-mini", help="Model to test (default: gpt-4o-mini)")

    sub.add_parser("upgrade", help="Open billing page to upgrade or add payment")
    sub.add_parser("dashboard", help="Open Pith dashboard in browser")
    sub.add_parser("config", help="Show saved config path")
    sub.add_parser("logout", help="Clear saved credentials")

    args = parser.parse_args()

    if not args.command:
        print(LOGO)
        parser.print_help()
        sys.exit(0)

    api = PithAPI(base_url=args.base_url)

    commands = {
        "signup": lambda: cmd_signup(api),
        "login": lambda: cmd_login(api),
        "whoami": lambda: cmd_whoami(api),
        "models": lambda: cmd_models(api),
        "test": lambda: cmd_test(api, args.model),
        "upgrade": lambda: cmd_upgrade(api),
        "dashboard": cmd_dashboard,
        "config": cmd_config,
        "logout": cmd_logout,
    }

    commands[args.command]()


if __name__ == "__main__":
    main()
