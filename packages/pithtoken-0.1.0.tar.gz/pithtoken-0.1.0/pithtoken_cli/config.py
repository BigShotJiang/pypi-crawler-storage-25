"""Local config management — stores credentials in ~/.pithtoken"""

import json
from pathlib import Path

CONFIG_DIR = Path.home() / ".pithtoken"
CONFIG_FILE = CONFIG_DIR / "config.json"


def _ensure_dir():
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def save_config(data: dict):
    _ensure_dir()
    existing = load_config()
    existing.update(data)
    CONFIG_FILE.write_text(json.dumps(existing, indent=2))


def load_config() -> dict:
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text())
    return {}


def get_token() -> str | None:
    return load_config().get("access_token")


def get_api_key() -> str | None:
    return load_config().get("api_key")


def get_email() -> str | None:
    return load_config().get("email")


def clear_config():
    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()
