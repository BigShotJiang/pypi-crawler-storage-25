"""API client for PithToken backend."""

import requests

BASE_URL = "https://pithtoken.ai"


class PithAPI:
    def __init__(self, base_url: str = BASE_URL):
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()

    def signup(self, email: str, password: str) -> dict:
        resp = self.session.post(
            f"{self.base_url}/auth/signup",
            json={"email": email, "password": password},
        )
        resp.raise_for_status()
        return resp.json()

    def login(self, email: str, password: str) -> dict:
        resp = self.session.post(
            f"{self.base_url}/auth/login",
            json={"email": email, "password": password},
        )
        resp.raise_for_status()
        return resp.json()

    def whoami(self, token: str) -> dict:
        resp = self.session.get(
            f"{self.base_url}/auth/me",
            headers={"Authorization": f"Bearer {token}"},
        )
        resp.raise_for_status()
        return resp.json()

    def models(self, api_key: str) -> dict:
        resp = self.session.get(
            f"{self.base_url}/v1/models",
            headers={"Authorization": f"Bearer {api_key}"},
        )
        resp.raise_for_status()
        return resp.json()

    def test_call(self, api_key: str, model: str = "gpt-4o-mini") -> dict:
        resp = self.session.post(
            f"{self.base_url}/v1/chat/completions",
            headers={"Authorization": f"Bearer {api_key}"},
            json={
                "model": model,
                "messages": [{"role": "user", "content": "Say 'Pith is working!' in one sentence."}],
                "max_tokens": 20,
            },
        )
        resp.raise_for_status()
        return resp.json()
