# PithToken CLI

One API key. 200+ AI models. Zero hassle.

## Install

```bash
pip install pithtoken
```

## Quick Start

```bash
# Create your free account
pith signup

# Or log in
pith login

# Check your account
pith whoami

# List available models
pith models

# Send a test request
pith test
pith test claude-sonnet-4-20250514
```

## Use with OpenAI SDK

```python
from openai import OpenAI

client = OpenAI(
    api_key="your-pith-api-key",  # from `pith whoami`
    base_url="https://api.pithtoken.ai/v1"
)

response = client.chat.completions.create(
    model="gpt-4o",  # or any of 200+ models
    messages=[{"role": "user", "content": "Hello!"}]
)
```

## Commands

| Command | Description |
|---------|-------------|
| `pith signup` | Create a new account |
| `pith login` | Log into your account |
| `pith whoami` | Show account info & API key |
| `pith models` | List available AI models |
| `pith test [model]` | Send a test API request |
| `pith config` | Show saved config path |
| `pith logout` | Clear saved credentials |

## Links

- Website: https://pithtoken.ai
- Docs: https://pithtoken.ai/docs
- Support: hello@pithtoken.ai
