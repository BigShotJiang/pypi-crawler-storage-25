# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.6.2 - 20260-04-30]
### ADDED
- ProfileRegistry - streams
- ReaderRegistry - streams
- copernicusmarine module (SDB)
- SYSU module (gravity based bathymetry)

### CHANGED
- Re-structure directories
-- 'macros' go in their parent directories
- Use click instead of argparse for CLI
- core.run_fetchez now returns the final list of entries for use in the api and elsewhere.
- Update run cli to allow for inherited options for modules.

## BUGFIX
- fix bug in earthdata.icesat2 for harmony fetching.

## [0.5.5 - 2026-04-24]
### ADDED
- BundleRegistry: bundle multiple modules + hooks in a yaml registry.

### CHANGED
- Update CDSE module to get B08 (IR)
- Change logging from name->module

## [0.5.5 - 2026-04-22]
### ADDED
- SYSU_topo dataset
- Add utility functions for dataset_id parsing

### CHANGED
- read_timeout in fetchez.core from None->120
- Descriptions in tqdm updated to be more useful
- Allow for POST in fetch_file

### BUGFIX
- fetchez_cache records empty results

## [0.5.4 - 2026-04-16]
### ADDED
- Added PresetRegistry into registry
- Add audit_full builtin preset
- Add GSHHG module (shorelines)
- Add CUSP module (shorelines (US))

### CHANGED
- Update recipe.py to use the new PresetRegistry
- Update nos_hydro for new API
- Update CLI for PresetRegistry
- Removed obsolete presets.py

## [0.5.3] - 2026-04-09
### ADDED
- Added parse_source_string and parse_hook_string in utils
- Added spatial.regions_intersect from cudem.regions

### CHANGED
- re-arranged cli help

### BUGFIX
- spatial region parsing of geojson files, returns all regions.

## [0.5.2] - 2026-04-02
### ADDED
- Add "lidarbc" fetchez modules (canada)
- Add .fetchez_cache to save module results for re-use
- Add RecipeRegistry to registry.py
- Add --list-recipes to cli

### CHANGED
- FetchModule is now in fetchez.modules
- fetchez.registry combines all registries (modules/hooks for now)
- Hooks are moved out of builtins to flat directory
- Now load extensions/plugins automatically
- Module metadata is prefixed with "meta_"
- Stage names: "pre" -> "manifest"; "post" -> "collection"
- Schema is now Schemas and uses global registry.
- Update to vdatum.geojson fred index of the vdatum module

### BUGFIX
- Update to fbt reading, accounting for heading; fix!

## [0.4.3] - 2026-03-02
- Breaks hooks into individual files, out of topical ones.
- Hooks are now auto-detected from 'builtins', so we don't have to maintain a registry.
- Adds 'focus' and 'datatype' builtin hooks.
- The 'unzip' hook now supports tar and gz.
- Post-hooks in fetchez.core was ignoring entry changes, this fixes that.
- We now use yaml files for config, including presets
- Fixed https (now url_fetcher) module bug.
- Add 'schemas' and 'recipe'.
- All builtin hooks in hooks.builtins.
- Add documentation.
- Some new modules.

## [0.4.2] - 2026-02-21
### Added
- Hook system for fetchez! (--list, --inventory, --pipe-path are now hooks)
- Users can add their own hooks in ~/.fetchez/hooks
- 'file' module to send local data through hooks
- --outdir option in CLI (global and per-module).
- Each entry now gets a 'history' key that keeps track of the hooks it passed through.

### Changed
- groupded parsers in argparse
- updated pyproject.toml for optional deps.

### BUGFIX
- pyproj/pyshp error msg in dav.py
- name conflict with cudem/coned/dav
- double path.join in core fixed. (this resulted in duplicated outdirs)
- unzip hook would send a bad entry record if the unzip files already existed

## [0.3.0] - 2026-02-01
### Added
- fetchez.spatial region_from_place centered on place
- Add TIGER
- Add arcticdem
- Add DAV
- fetchez.utils p_unzip from cudem.utils
- examples dir for examples, workflows, scripts using fetchez
- bing and tides examples
- sphinx auto-docs
- inventory option in the cli
- Most old fetches modules are now ported to fetchez

### Changed
- README updates
- CLI description (geospatial vs elevation)
- concurent.futures testing for threads
- STOP_EVENT in fetchez.core threads
- logger uses tqdm.write to not clobber progress bars
- spatial.parse_regions will now output all the regions found in a geojson

## [0.2.0] - 2026-01-27
### Added
- Initial standalone release of Fetchez.
- Decoupled from CUDEM project.
- New `fetchez.spatial` module for lightweight region parsing.
- New `fetchez.registry` for lazy module loading.
- Modernized CLI with logging support.
- FRED index now uses GeoJSON and Shapely directly (removed OGR dependency).
- csb module
- fetchez.spatial 'region_to_wkt' method
- fetchez.core fetch_req now supports 'method' arg
- fetchez.spatial 'region_center' method
- buouy module
- gmrt module
- fetchez.spatial 'region_to_bbox' method
- waterservices module
- etopo module
- fetchez.spatial 'region_to_geojson_geom'
- chs module
- bluetopo module
- user plugins
- add emodnet

### Changed
- Renamed project from `fetches` to `fetchez`.
- Refactored some old cudem.fetches modules to inherit from `fetchez	.core.FetchModule`.
- In fetchez.core, allow for transparent gzip (local size is larger than remote size)
