from __future__ import annotations

import json
import math
import os
import stat
import threading
import time
import typing as t
import webbrowser
from pathlib import Path
from queue import Empty

from authlib.common.security import generate_token
from authlib.integrations.requests_client import OAuth2Session
from query_cache_common.auth import Scope
from rich.console import Console
from rich.theme import Theme

from dbt_run_cache.auth.sso_server import LOCAL_OAUTH_PORT, SsoHttpServer
from dbt_run_cache.auth.utils import parse_jwt
from dbt_run_cache.config import CLIENT_ID_DEFAULT, DBT_RUN_CACHE_PATH, get_env
from dbt_run_cache.errors import AuthenticationError

ORGS_SCOPE = "runcache:scope:orgs"
"""The scope to request from the auth service"""

REDIRECT_URI = f"http://127.0.0.1:{LOCAL_OAUTH_PORT}/handler"
"""The local redirect_uri value to use"""

AUTH_URL = get_env("AUTH_URL", "https://auth.runcache.com")
"""The OAuth authorization endpoint to use"""

TOKEN_URL = get_env("TOKEN_URL", "https://auth.runcache.com/token")
"""The OAuth token endpoint to use"""


THEME = Theme(
    {
        "error": "red",
        "success": "green",
        "url": "bright_blue",
        "key": "magenta",
    }
)
"""The Rich console theme to use in the CLI"""


def sso_auth(
    auth_url: str = AUTH_URL,
    token_url: str = TOKEN_URL,
    client_id: str = CLIENT_ID_DEFAULT,
    client_secret: t.Optional[str] = None,
    org_id: t.Optional[str] = None,
    code_verifier: t.Optional[str] = None,
    auth_json_path: Path = DBT_RUN_CACHE_PATH,
    console: t.Optional[Console] = None,
) -> SsoAuth:
    sso_auth = SsoAuth(
        auth_url=auth_url,
        token_url=token_url,
        client_id=client_id,
        scope=ORGS_SCOPE,
        auth_json_path=auth_json_path,
        client_secret=client_secret,
        code_verifier=code_verifier,
        console=console,
        org_id=org_id,
    )
    sso_auth.init_from_cache()
    return sso_auth


class SsoAuth:
    """This class handles the OAuth flows and CLI process for getting an ID token to use with API calls that require it."""

    def __init__(
        self,
        auth_url: str,
        token_url: str,
        client_id: str,
        scope: str,
        auth_json_path: Path,
        client_secret: t.Optional[str] = None,
        console: t.Optional[Console] = None,
        code_verifier: t.Optional[str] = None,
        org_id: t.Optional[str] = None,
    ) -> None:
        self._auth_url = auth_url
        self._token_url = token_url
        self._client_id = client_id
        self._client_secret = client_secret
        self._scope = scope
        self._console = console or Console(theme=THEME)
        self._code_verifier = code_verifier or generate_token(48)
        self._configured_org_id = org_id

        if not auth_json_path.exists():
            auth_json_path.mkdir(parents=True, exist_ok=True)
        self._auth_json_path = auth_json_path

        self._session = OAuth2Session(
            self._client_id,
            self._client_secret,
            redirect_uri=REDIRECT_URI,
            scope=self._scope,
            code_challenge_method="S256",
        )
        self._token_info: t.Optional[t.Dict] = None
        self._token_scope: t.Optional[Scope] = None
        self._token_info_lock = threading.Lock()

    def init_from_cache(self) -> None:
        with self._token_info_lock:
            if not self._token_info:
                self._token_info = self._load_auth_json()
                self._token_scope = (
                    Scope.from_string(self._token_info.get("scope", ""))
                    if self._token_info
                    else None
                )

    def auth_info(self) -> t.Dict:
        token_info = self._load_auth_json()
        now = time.time()

        if token_info:
            if token_info.get("expires_at", 0.0) > now:
                _, body, _ = parse_jwt(token_info["id_token"])
                return {
                    "logged_in": True,
                    "expires_in": math.floor((token_info["expires_at"] - now) / 60),
                    "claims": body,
                }
            return {
                "logged_in": False,
                "expired": True,
            }

        return {"logged_in": False}

    def status(self) -> None:
        auth_info = self.auth_info()

        if not auth_info["logged_in"]:
            if auth_info.get("expired"):
                self._console.print("Current SSO session expired", style="error")
                return
            self._console.print("Not currently authenticated", style="error")
            return

        self._console.print(
            f"Current dbt State SSO session expires in [success]{auth_info['expires_in']}[/success] minutes"
        )
        claims = auth_info.get("claims", {})
        if claims and claims["sub"] == claims["aud"]:
            client_id = claims["sub"]
            self._console.print("[url]Service to Service Token[/url]")
            self._console.print(f"[key]Client ID:[/key] {client_id}")
        else:
            self._console.print("[url]User Token[/url]")

        if "email" in claims:
            email = claims["email"]
            self._console.print(f"[key]Email:[/key] {email}")
        if "name" in claims:
            name = claims["name"]
            self._console.print(f"[key]Name:[/key] {name}")
        if "scope" in claims:
            scope = claims["scope"]
            self._console.print(f"[key]Scope:[/key] {scope}")

    def is_logged_in(self) -> bool:
        with self._token_info_lock:
            try:
                self._get_or_refresh_token_info(login=False)
                return True
            except AuthenticationError:
                return False

    def org_id(self, login: bool = False) -> str:
        with self._token_info_lock:
            return self._get_or_refresh_token_info(login)["org_id"]

    def id_token(self, login: bool = False) -> str:
        """Returns the id_token needed for SSO.

        Will return the one saved on disk, unless it's expired. If the token on disk is expired,
        it will try to refresh it. If there is no token on disk, it will start the SSO process
        to get a new one if login is True.
        """
        with self._token_info_lock:
            return self._get_or_refresh_token_info(login)["id_token"]

    def logout(self) -> None:
        with self._token_info_lock:
            self._delete_auth_json()
            self._console.print("Logged out of dbt State")

    def login(self) -> t.Optional[str]:
        with self._token_info_lock:
            return self._login()["id_token"]

    def refresh_token(self) -> t.Optional[str]:
        with self._token_info_lock:
            return self._refresh_token()["id_token"]

    def _get_or_refresh_token_info(self, login: bool) -> t.Dict:
        if self._token_info and self._token_scope:
            # If we are within 5 minutes of expire time, run refresh
            is_fresh = self._token_info.get("expires_at", 0.0) > (time.time() + 300)

            org_id_in_scope = True
            if self._configured_org_id:
                org_id_in_scope = self._token_scope.is_org_id_in_scope(self._configured_org_id)
                if self._token_info.get("org_id") != self._configured_org_id:
                    is_fresh = False  # Force refresh if org_id in the token doesn't match configured org_id

            if is_fresh and org_id_in_scope:
                # We have a current token on disk with matching org_id, return it
                return self._token_info

            if not org_id_in_scope:
                # The token on disk doesn't have access to the requested org_id, logout
                self._delete_auth_json()
            elif not is_fresh:
                try:
                    return self._refresh_token()
                except Exception:
                    # We failed to refresh, logout
                    self._delete_auth_json()

        if login:
            # We should get a new token
            return self._login()

        raise AuthenticationError("Not currently authenticated")

    def _login(self) -> t.Dict:
        if self._client_secret:
            return self._login_with_client_credentials()

        with SsoHttpServer() as server:
            thread = threading.Thread(target=server.handle_request, daemon=True)
            thread.start()

            auth_url, _ = self._session.create_authorization_url(
                self._auth_url,
                code_verifier=self._code_verifier,
            )

            self._console.print("Logging into dbt State")
            self._open_browser_flow(auth_url)

            try:
                self._console.print()
                with self._console.status(
                    "Waiting... You can [key]Ctrl-C[/key] to cancel this request."
                ):
                    thread.join(timeout=server.timeout)

                # Try to get callback from queue with a short timeout to handle race conditions
                try:
                    callback_url = server.queue.get(timeout=1.0)
                except Empty:
                    raise AuthenticationError(
                        f"Authentication timed out after {server.timeout} seconds. "
                        "Please try again and complete the login in your browser."
                    )

                self._session.fetch_token(
                    self._token_url,
                    authorization_response=callback_url,
                    code_verifier=self._code_verifier,
                    include_client_id=True,
                )

                token_info = self._update_token_info(self._session.token)

                self._console.print("[success]Success![/success] :white_check_mark:")
                self._console.print()

                return token_info

            except KeyboardInterrupt:
                from rich.control import Control
                from rich.segment import ControlType

                self._console.control(Control(ControlType.CARRIAGE_RETURN))
                self._console.print("Canceling SSO request")
                self._console.print()

                raise

    def _login_with_client_credentials(self) -> t.Dict:
        try:
            self._session.fetch_token(
                self._token_url,
                grant_type="client_credentials",
            )
            return self._update_token_info(self._session.token)
        except AuthenticationError:
            raise
        except Exception:
            raise AuthenticationError(
                "Error logging in with client credentials. Please make sure that the RUN_CACHE_OAUTH_CLIENT_ID and RUN_CACHE_OAUTH_CLIENT_SECRET environment variables are set to the right values"
            )

    def _refresh_token(self) -> t.Dict:
        if self._client_secret:
            return self._login_with_client_credentials()

        if not self._token_info:
            raise AuthenticationError("Not currently authenticated")

        current_refresh_token = self._token_info["refresh_token"]
        if not current_refresh_token:
            raise AuthenticationError("Refresh token not available")

        self._session.refresh_token(
            self._token_url, refresh_token=current_refresh_token, scope=None
        )

        return self._update_token_info(self._session.token)

    def _open_browser_flow(self, auth_url: str) -> None:
        try:
            webbrowser.open(auth_url)
            self._console.print()
            self._console.print(
                "Opening your browser to the signin URL [success]:globe_with_meridians:[/success]"
            )
        except Exception:
            pass

        self._console.print()
        self._console.print(
            "If a browser doesn't open on your system please go to the following url:"
        )
        self._console.print(f"[url]{auth_url}[/url]")

        try:
            import pyperclip

            pyperclip.copy(auth_url)
            self._console.print()
            self._console.print(
                "This url has also been copied to your system clipboard :clipboard:"
            )
        except Exception:
            pass

    @property
    def _auth_json_file(self) -> Path:
        return self._auth_json_path / "auth.json"

    def _delete_auth_json(self) -> None:
        """Removes the auth.json file if it exists."""
        self._token_info = None
        self._token_scope = None
        auth_file = self._auth_json_file
        if auth_file.exists() and os.access(auth_file, os.W_OK):
            os.remove(auth_file)

    def _load_auth_json(self) -> t.Optional[t.Dict]:
        """Loads the full auth.json file that might exist in the CLI config folder."""
        auth_file = self._auth_json_file

        if auth_file.exists() and os.access(auth_file, os.R_OK):
            with auth_file.open("r", encoding="utf-8") as fd:
                data = json.load(fd)

            if SsoAuth._is_legacy_token(data):
                self._delete_auth_json()
                return None

            return data

        return None

    def _save_auth_json(self, data: t.Dict) -> None:
        """Saves the given dictionary to auth.json.

        Args:
            data: The dictionary to save
        """
        auth_file = self._auth_json_file

        with auth_file.open("w", encoding="utf-8") as fd:
            json.dump(data, fd)
        os.chmod(auth_file, stat.S_IWUSR | stat.S_IRUSR)

    def _update_token_info(self, token: t.Dict) -> t.Dict:
        id_token = token["id_token"]
        claims = parse_jwt(id_token)[1]
        token_scope = Scope.from_string(claims.get("scope", ""))

        try:
            org_id = self._determine_org_id(token_scope)
        except AuthenticationError:
            raise
        except Exception as e:
            raise AuthenticationError(f"Error determining organization ID: {e}") from e

        if not token_scope.is_org_id_in_scope(org_id):
            if token_scope.is_org_id_disabled(org_id):
                raise AuthenticationError(
                    f"User access to the requested organization (org_id: {org_id}) has been disabled."
                )

            raise AuthenticationError(
                f"User does not have access to the requested organization (org_id: {org_id}). Please make sure your user account has access to this organization or specify a different organization that you have access to in the project configuration."
            )

        new_token_info = {
            "scope": token["scope"],
            "token_type": token["token_type"],
            "id_token": id_token,
            "org_id": org_id,
        }

        if "expires_at" in token:
            new_token_info["expires_at"] = token["expires_at"]
        elif "expires_in" in token:
            new_token_info["expires_at"] = math.floor(time.time() + token["expires_in"])

        if "access_token" in token:
            new_token_info["access_token"] = token["access_token"]

        if "refresh_token" in token:
            new_token_info["refresh_token"] = token["refresh_token"]

        self._save_auth_json(new_token_info)
        self._token_info = new_token_info
        self._token_scope = token_scope
        return self._token_info

    def _determine_org_id(self, scope: Scope) -> str:
        """Determine the organization ID from configuration or token scope.

        Priority:
        1. Configured org_id (from constructor)
        2. Auto-detect from single org in scope (excluding wildcards)
        3. Error if ambiguous

        Args:
            scope: The scope from the token claims

        Returns:
            The determined organization ID

        Raises:
            AuthenticationError: If org ID cannot be determined
        """
        if self._configured_org_id:
            return self._configured_org_id

        org_ids = scope.org_ids
        if not org_ids:
            raise AuthenticationError(
                "Cannot determine organization ID from token. Please specify which organization to use by setting run_cache_org_id in the project configuration."
            )
        if len(org_ids) == 1 and org_ids[0] != "*":
            return org_ids[0]
        raise AuthenticationError(
            f"Token has access to multiple organizations: {', '.join(org_ids)}. "
            "Please specify which organization to use by setting run_cache_org_id in the project configuration."
        )

    @staticmethod
    def _is_legacy_token(token_info: t.Dict) -> bool:
        """Returns True if the cached token targets the old auth issuer or uses old scopes."""
        scope = token_info.get("scope", "")
        if "conway:scope" in scope:
            return True

        id_token = token_info.get("id_token")
        if id_token:
            try:
                _, claims, _ = parse_jwt(id_token)
                if "auth.conway.fivetran.com" in claims.get("iss", ""):
                    return True
            except Exception:
                pass

        return False
