#!/usr/bin/env python3
"""
nekowall  –  Random anime wallpaper changer powered by Nekosia API.
Cross-platform: Windows, macOS, Linux (GNOME, KDE, XFCE, MATE, Cinnamon, feh, sway, hyprland).
No external dependencies – pure Python 3.8+ stdlib.
Made by tommy437.
"""

from __future__ import annotations

import sys
import os
import re
import platform
import subprocess
import random
import json
import shutil
import tempfile
import argparse
import urllib.request
import urllib.error
import threading
import itertools
import time
from contextlib import contextmanager

# --------------------------------------------------------------------------- #
#  Platform
# --------------------------------------------------------------------------- #

SYSTEM = platform.system()  # "Windows" | "Darwin" | "Linux"


def _enable_ansi_windows() -> None:
    """Enable ANSI escape codes in Windows terminals (cmd, PowerShell)."""
    if SYSTEM == "Windows":
        import ctypes

        kernel = ctypes.windll.kernel32
        kernel.SetConsoleMode(kernel.GetStdHandle(-11), 7)


_enable_ansi_windows()


def _clear() -> None:
    os.system("cls" if SYSTEM == "Windows" else "clear")


# --------------------------------------------------------------------------- #
#  API
# --------------------------------------------------------------------------- #

API_BASE = "https://api.nekosia.cat/api/v1"
TAGS_URL = f"{API_BASE}/tags"
IMG_URL = f"{API_BASE}/images/{{cat}}"
VERSION = "2.1.2"
AUTHOR = "tommy437"

# --------------------------------------------------------------------------- #
#  Categories
# --------------------------------------------------------------------------- #

MAIN_CATEGORIES = [
    # Animal girls
    "catgirl",
    "foxgirl",
    "wolf-girl",
    "animal-ears",
    "tail",
    "tail-with-ribbon",
    "tail-from-under-skirt",
    # Styles & vibes
    "cute",
    "cuteness-is-justice",
    "blue-archive",
    "girl",
    "young-girl",
    "maid",
    "maid-uniform",
    "vtuber",
    "w-sitting",
    "lying-down",
    "hands-forming-a-heart",
    "wink",
    "valentine",
    "headphones",
    # Clothes & accessories
    "thigh-high-socks",
    "knee-high-socks",
    "white-tights",
    "black-tights",
    "uniform",
    "sailor-uniform",
    "hoodie",
    "ribbon",
    # Hair & eyes
    "heterochromia",
    "white-hair",
    "blue-hair",
    "long-hair",
    "blonde",
    "blue-eyes",
    "purple-eyes",
]

EXTRA_CATEGORIES = [
    "cat-ears",
    "fox-ears",
    "wolf-ears",
    "pink-hair",
    "red-eyes",
    "twintails",
    "short-hair",
    "green-eyes",
    "yellow-eyes",
    "pink-eyes",
    "white-thigh-high-socks",
    "black-thigh-high-socks",
    "blue-skirt",
    "school-uniform",
    "skirt",
    "thighs",
    "wolfgirl",
    "doggirl",
    "sailor-one-piece",
    "schoolgirl",
    "nail-polish",
    "blushing",
    "lying-on-one-side",
    "green-hair",
    "silver-hair",
    "purple-hair",
    "garter",
    "happy",
    "smile",
    "high-schoolgirl",
    "white-dress",
    "showgirl",
    "casual-wear",
    "sakura",
    "dress",
    "hololive",
    "sweater",
    "sleepy-face",
    "sea",
    "black-hair",
    "black-skirt",
    "socks",
    "barefoot",
    "kimono",
    "gym-uniform",
    "halloween",
    "winter",
    "summer",
    "dog-ears",
    "umbrella",
    "rawr",
]

_SKIP_TAGS = {"random", "nothing", "all", ""}
MIN_COUNT = 15

# --------------------------------------------------------------------------- #
#  ANSI colors
# --------------------------------------------------------------------------- #

R = "\033[0m"
B = "\033[1m"
CY = "\033[96m"
GR = "\033[92m"
YE = "\033[93m"
RE = "\033[91m"
MA = "\033[95m"
BL = "\033[94m"
DM = "\033[2m"
IT = "\033[3m"


def c(color: str, text: str) -> str:
    return f"{color}{text}{R}"


def _strip_ansi(text: str) -> str:
    return re.sub(r"\033\[[0-9;]*m", "", text)


# --------------------------------------------------------------------------- #
#  Spinner
# --------------------------------------------------------------------------- #


class Spinner:
    """Thread-based ASCII spinner shown during blocking I/O operations."""

    _FRAMES = ["|", "/", "-", "\\"]

    def __init__(self, message: str = ""):
        self.message = message
        self._running = False
        self._thread = None

    def __enter__(self):
        self._running = True
        self._thread = threading.Thread(target=self._spin, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *_):
        self._running = False
        if self._thread:
            self._thread.join()
        print(f"\r{' ' * (len(self.message) + 8)}\r", end="", flush=True)

    def _spin(self):
        for frame in itertools.cycle(self._FRAMES):
            if not self._running:
                break
            print(f"\r  {c(CY, frame)}  {self.message}", end="", flush=True)
            time.sleep(0.1)


# --------------------------------------------------------------------------- #
#  No-op context manager (used when verbose=False)
# --------------------------------------------------------------------------- #


@contextmanager
def _noop():
    yield


# --------------------------------------------------------------------------- #
#  Banner & footer
# --------------------------------------------------------------------------- #

_OS_LABEL = {
    "Windows": f"Windows {platform.release()}",
    "Darwin": f"macOS {platform.mac_ver()[0]}",
    "Linux": f"Linux  ({os.environ.get('XDG_CURRENT_DESKTOP', 'unknown DE')})",
}.get(SYSTEM, SYSTEM)


def banner() -> None:
    _clear()
    print(
        c(
            MA,
            B
            + r"""
  ███╗   ██╗███████╗██╗  ██╗ ██████╗ ██╗    ██╗ █████╗ ██╗     ██╗
  ████╗  ██║██╔════╝██║ ██╔╝██╔═══██╗██║    ██║██╔══██╗██║     ██║
  ██╔██╗ ██║█████╗  █████╔╝ ██║   ██║██║ █╗ ██║███████║██║     ██║
  ██║╚██╗██║██╔══╝  ██╔═██╗ ██║   ██║██║███╗██║██╔══██║██║     ██║
  ██║ ╚████║███████╗██║  ██╗╚██████╔╝╚███╔███╔╝██║  ██║███████╗███████╗
  ╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝ ╚═════╝  ╚══╝╚══╝ ╚═╝  ╚═╝╚══════╝╚══════╝
""",
        )
    )
    print(c(CY, f"  Random anime wallpaper  |  Nekosia API  |  v{VERSION}"))
    print(c(DM, f"  Platform  :  {_OS_LABEL}"))
    print(c(MA, f"  Made by   :  {AUTHOR}"))
    print(c(BL, "  " + "─" * 54))
    print()


def footer() -> None:
    print()
    print(c(BL, "  " + "─" * 54))
    print(
        c(DM + IT, f"  nekowall v{VERSION}  ·  made by ")
        + c(MA, AUTHOR)
        + c(DM + IT, "  ·  Nekosia API")
    )
    print()


# --------------------------------------------------------------------------- #
#  HTTP helpers
# --------------------------------------------------------------------------- #


def _request(url: str) -> urllib.request.Request:
    return urllib.request.Request(url, headers={"User-Agent": f"nekowall/{VERSION}"})


def get_json(url: str) -> dict:
    with urllib.request.urlopen(_request(url), timeout=10) as r:
        return json.loads(r.read().decode())


def download_file(url: str, dest: str) -> None:
    """Download a file to dest with a live progress bar."""
    with urllib.request.urlopen(_request(url), timeout=30) as r, open(dest, "wb") as f:
        total = int(r.headers.get("Content-Length", 0))
        received = 0
        width = 28
        while chunk := r.read(8192):
            f.write(chunk)
            received += len(chunk)
            if total:
                pct = received / total * 100
                filled = int(pct / 100 * width)
                bar = "#" * filled + "-" * (width - filled)
                kb = received // 1024
                print(
                    f"\r  [{c(CY, bar)}] {c(YE, f'{pct:5.1f}%')}  {kb} KB ",
                    end="",
                    flush=True,
                )
    print()


# --------------------------------------------------------------------------- #
#  Category pool
# --------------------------------------------------------------------------- #


def load_categories(verbose: bool = True) -> list[str]:
    """
    Merge hardcoded categories with live /tags from the API.
    Returns a deduplicated list (shuffled for random pick).
    """
    pool = set(MAIN_CATEGORIES) | set(EXTRA_CATEGORIES)

    with Spinner("Fetching live tags from Nekosia API…") if verbose else _noop():
        api_ok, added = False, 0
        try:
            data = get_json(TAGS_URL)
            live_raw = data.get("tags") or data.get("categories") or []
            for entry in live_raw:
                name = entry.get("name", "") if isinstance(entry, dict) else str(entry)
                count = (
                    entry.get("count", MIN_COUNT)
                    if isinstance(entry, dict)
                    else MIN_COUNT
                )
                name = name.strip().lower()
                if name not in _SKIP_TAGS and count >= MIN_COUNT and name not in pool:
                    pool.add(name)
                    added += 1
            api_ok = True
        except Exception:
            pass

    if verbose:
        if api_ok:
            print(c(GR, f"  [+] Live tags loaded   +{added} new  |  {len(pool)} total"))
        else:
            print(
                c(YE, f"  [!] API unreachable – using {len(pool)} hardcoded categories")
            )

    cats = list(pool)
    random.shuffle(cats)
    return cats


# --------------------------------------------------------------------------- #
#  Image fetching
# --------------------------------------------------------------------------- #


def fetch_image_info(category: str) -> tuple[str, str, int]:
    data = get_json(IMG_URL.format(cat=category))
    if not data.get("success"):
        raise RuntimeError(data.get("message", "unknown API error"))
    return data["image"]["original"]["url"], data.get("id", "?"), data.get("count", 0)


# --------------------------------------------------------------------------- #
#  Wallpaper setters  (platform-specific)
# --------------------------------------------------------------------------- #


def _set_windows(path: str) -> None:
    """
    Set wallpaper on Windows 7/10/11.
    Writes WallpaperStyle and TileWallpaper to the registry,
    then calls SystemParametersInfoW with SPIF_UPDATEINIFILE | SPIF_SENDWININICHANGE.
    On Windows 7 (NT 6.1), WallpaperStyle=2 (Stretch) is used because "10" (Fill) is not supported.
    """
    import ctypes
    import winreg

    is_win7 = platform.release() == "7" or platform.version().startswith("6.1")
    wallpaper_style = "2" if is_win7 else "10"

    try:
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Control Panel\Desktop",
            0,
            winreg.KEY_SET_VALUE,
        )
        winreg.SetValueEx(key, "WallpaperStyle", 0, winreg.REG_SZ, wallpaper_style)
        winreg.SetValueEx(key, "TileWallpaper", 0, winreg.REG_SZ, "0")
        winreg.CloseKey(key)
    except OSError:
        pass  # non-critical – worst case the image is centered

    SPI_SETDESKWALLPAPER = 0x0014
    flags = 0x0001 | 0x0002  # SPIF_UPDATEINIFILE | SPIF_SENDWININICHANGE

    path = os.path.normpath(os.path.abspath(path))
    ok = ctypes.windll.user32.SystemParametersInfoW(
        SPI_SETDESKWALLPAPER, 0, path, flags
    )
    if not ok:
        raise OSError("SystemParametersInfoW failed – try running as administrator.")


def _set_macos(path: str) -> None:
    """
    Set wallpaper on macOS via AppleScript (Finder).
    Fallback: System Events (older macOS / multi-display edge cases).
    """
    script_finder = (
        f'tell application "Finder" to set desktop picture to POSIX file "{path}"'
    )
    r = subprocess.run(
        ["osascript", "-e", script_finder], capture_output=True, text=True
    )
    if r.returncode == 0:
        return

    script_se = (
        f'tell application "System Events" to tell every desktop to '
        f'set picture to POSIX file "{path}"'
    )
    r2 = subprocess.run(["osascript", "-e", script_se], capture_output=True, text=True)
    if r2.returncode != 0:
        err = r2.stderr.strip() or r.stderr.strip()
        raise OSError(f"osascript error: {err}")


def _set_linux(path: str) -> None:
    """
    Set wallpaper on Linux – detects DE from environment variables and
    dispatches to the appropriate backend.

    Supported: GNOME/Unity/Budgie/Pop, KDE Plasma (5/6), XFCE, MATE,
               Cinnamon, LXDE/Openbox, Sway/Wayland (swww/swaybg),
               Hyprland.  Universal fallback: feh → nitrogen.
    """
    de = os.environ.get("XDG_CURRENT_DESKTOP", "").lower()
    session = os.environ.get("DESKTOP_SESSION", "").lower()
    wayland = bool(os.environ.get("WAYLAND_DISPLAY", ""))
    d = de or session
    uri = f"file://{path}"

    def run(*cmd) -> bool:
        """Run cmd, return True on success (returncode 0)."""
        return subprocess.run(cmd, capture_output=True).returncode == 0

    # ── GNOME / Unity / Budgie / Pop!_OS ────────────────────────────────────
    if any(k in d for k in ("gnome", "unity", "budgie", "pop")):
        ok = run("gsettings", "set", "org.gnome.desktop.background", "picture-uri", uri)
        # picture-uri-dark exists on GNOME 42+; failure is non-critical
        run(
            "gsettings",
            "set",
            "org.gnome.desktop.background",
            "picture-uri-dark",
            uri,
        )
        run(
            "gsettings",
            "set",
            "org.gnome.desktop.background",
            "picture-options",
            "zoom",
        )
        if not ok:
            raise OSError(
                "gsettings failed – is the GNOME desktop-background schema available?"
            )

    # ── KDE Plasma 5/6 ──────────────────────────────────────────────────────
    elif "kde" in d or "plasma" in d:
        if not run("plasma-apply-wallpaperimage", path):
            js = (
                "var all=desktops();"
                "for(var i=0;i<all.length;i++){"
                "var d=all[i];"
                "d.wallpaperPlugin='org.kde.image';"
                "d.currentConfigGroup=['Wallpaper','org.kde.image','General'];"
                f"d.writeConfig('Image','file://{path}');"
                "}"
            )
            if not run(
                "dbus-send",
                "--session",
                "--dest=org.kde.plasmashell",
                "--type=method_call",
                "/PlasmaShell",
                "org.kde.PlasmaShell.evaluateScript",
                f"string:{js}",
            ):
                run(
                    "qdbus",
                    "org.kde.plasmashell",
                    "/PlasmaShell",
                    "org.kde.PlasmaShell.evaluateScript",
                    js,
                )

    # ── XFCE ────────────────────────────────────────────────────────────────
    elif "xfce" in d:
        r = subprocess.run(
            ["xfconf-query", "-c", "xfce4-desktop", "-l"],
            capture_output=True,
            text=True,
        )
        applied = False
        for prop in r.stdout.splitlines():
            if "last-image" in prop:
                run(
                    "xfconf-query",
                    "-c",
                    "xfce4-desktop",
                    "-p",
                    prop.strip(),
                    "-s",
                    path,
                )
                applied = True
        if not applied:
            raise OSError(
                "xfconf-query found no 'last-image' properties – "
                "is xfce4-desktop running?"
            )

    # ── MATE ────────────────────────────────────────────────────────────────
    elif "mate" in d:
        if not run("gsettings", "set", "org.mate.background", "picture-filename", path):
            raise OSError("gsettings (MATE) failed.")

    # ── Cinnamon ────────────────────────────────────────────────────────────
    elif "cinnamon" in d:
        if not run(
            "gsettings",
            "set",
            "org.cinnamon.desktop.background",
            "picture-uri",
            uri,
        ):
            raise OSError("gsettings (Cinnamon) failed.")

    # ── LXDE / Openbox ──────────────────────────────────────────────────────
    elif "lxde" in d or "openbox" in d:
        if not run("pcmanfm", "--set-wallpaper", path):
            if not run("feh", "--bg-fill", path):
                raise OSError("pcmanfm and feh both failed.")

    # ── Sway / generic Wayland ──────────────────────────────────────────────
    elif "sway" in d or (wayland and "sway" in session):
        if shutil.which("swww"):
            run("swww", "img", path)
        elif shutil.which("swaybg"):
            # Kill any old swaybg to prevent process accumulation
            try:
                subprocess.run(["pkill", "-x", "swaybg"], capture_output=True)
            except FileNotFoundError:
                pass
            time.sleep(0.2)
            subprocess.Popen(
                ["swaybg", "-i", path, "-m", "fill"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
        else:
            raise OSError("Install swww or swaybg: sudo apt install swaybg")

    # ── Hyprland ────────────────────────────────────────────────────────────
    elif "hyprland" in d:
        if shutil.which("hyprctl"):
            run("hyprctl", "hyprpaper", "unload", "all")
            run("hyprctl", "hyprpaper", "preload", path)
            run("hyprctl", "hyprpaper", "wallpaper", f",{path}")
        elif shutil.which("swww"):
            run("swww", "img", path)
        else:
            raise OSError("hyprpaper (via hyprctl) or swww not found.")

    # ── Universal fallback ──────────────────────────────────────────────────
    else:
        if not run("feh", "--bg-fill", path):
            if not run("nitrogen", "--set-scaled", path):
                raise OSError(
                    "Could not detect desktop environment.\n"
                    "Install feh (sudo apt install feh) and retry."
                )


def set_wallpaper(path: str) -> None:
    abs_path = os.path.abspath(path)
    if SYSTEM == "Windows":
        _set_windows(abs_path)
    elif SYSTEM == "Darwin":
        _set_macos(abs_path)
    else:
        _set_linux(abs_path)


# --------------------------------------------------------------------------- #
#  CLI output helpers
# --------------------------------------------------------------------------- #

_W = 56


def _box_top() -> str:
    return c(BL, "  ┌" + "─" * _W + "┐")


def _box_mid() -> str:
    return c(BL, "  │" + " " * _W + "│")


def _box_bot() -> str:
    return c(BL, "  └" + "─" * _W + "┘")


def _box_row(label: str, value: str, vc: str = YE) -> None:
    max_val = _W - len(label) - 5
    if len(value) > max_val:
        value = "…" + value[-(max_val - 1) :]
    text = f" {c(DM, label)}: {c(vc, value)}"
    raw = _strip_ansi(text)
    pad = max(0, _W - len(raw) - 1)
    print(c(BL, "  │") + text + " " * pad + c(BL, "│"))


def print_result_box(
    category: str,
    img_id: str,
    dest: str,
    kept: bool,
    size_bytes: int = 0,
) -> None:
    if size_bytes:
        size_kb = size_bytes / 1024
    elif os.path.exists(dest):
        size_kb = os.path.getsize(dest) / 1024
    else:
        size_kb = 0.0
    print()
    print(_box_top())
    print(_box_mid())
    _box_row("Status  ", "Wallpaper set!", GR)
    _box_row("Category", category, MA)
    _box_row("Image ID", str(img_id), YE)
    _box_row("Size    ", f"{size_kb:.0f} KB", CY)
    _box_row("File    ", dest, DM)
    if kept:
        _box_row("Saved   ", "yes (--keep)", GR)
    else:
        _box_row("Saved   ", "no  (temp, cleaned on next run)", DM)
    _box_row("Author  ", AUTHOR, MA)
    print(_box_mid())
    print(_box_bot())


# --------------------------------------------------------------------------- #
#  --list output
# --------------------------------------------------------------------------- #


def print_categories(categories: list[str]) -> None:
    sorted_cats = sorted(categories)
    col_w = max(len(x) for x in sorted_cats) + 2

    print()
    print(c(B + CY, f"  {'CATEGORY':<{col_w}}  COMMAND"))
    print(c(BL, "  " + "─" * (col_w + 22)))
    for cat in sorted_cats:
        print(f"  {c(YE, f'{cat:<{col_w}}')}  {c(DM, f'nekowall -c {cat}')}")
    print(c(BL, "  " + "─" * (col_w + 22)))
    print(c(GR, f"  {len(sorted_cats)} categories available."))
    print()
    print(c(DM, "  Random pick:  ") + c(MA, "nekowall"))


# --------------------------------------------------------------------------- #
#  Argument parser
# --------------------------------------------------------------------------- #


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="nekowall",
        description=(
            f"nekowall – Random anime wallpaper changer powered by Nekosia API.\n"
            f"Cross-platform: Windows, macOS, Linux.  v{VERSION}  |  made by {AUTHOR}"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "examples:\n"
            "  nekowall                    random category, random image\n"
            "  nekowall -c catgirl         force a specific category\n"
            "  nekowall -c maid --keep     keep the downloaded image file\n"
            "  nekowall --list             show all available categories\n"
            "  nekowall --no-banner        skip the ASCII banner\n"
        ),
    )
    p.add_argument(
        "-c",
        "--category",
        metavar="CAT",
        default=None,
        help="use a specific category instead of a random one",
    )
    p.add_argument(
        "--list",
        action="store_true",
        help="print all categories with commands and exit",
    )
    p.add_argument(
        "--keep",
        action="store_true",
        help="save the downloaded image to ~/Pictures/nekowall/",
    )
    p.add_argument("--no-banner", action="store_true", help="skip the ASCII art banner")
    p.add_argument("--version", action="version", version=f"nekowall {VERSION}")
    return p


# --------------------------------------------------------------------------- #
#  Temp cleanup
# --------------------------------------------------------------------------- #


def _cleanup_old_temps() -> None:
    """Remove leftover nekowall_* files from the system temp directory."""
    tmp = tempfile.gettempdir()
    for name in os.listdir(tmp):
        if name.startswith("nekowall_"):
            try:
                os.remove(os.path.join(tmp, name))
            except OSError:
                pass


# --------------------------------------------------------------------------- #
#  Main
# --------------------------------------------------------------------------- #


def main() -> None:
    args = build_parser().parse_args()

    if not args.no_banner:
        banner()

    verbose = not args.no_banner
    cats = load_categories(verbose=verbose)

    if args.list:
        print_categories(cats)
        footer()
        return

    print()

    # ── Resolve category ─────────────────────────────────────────────────────
    if args.category:
        chosen = args.category.strip().lower()
        print(c(CY, "  >> Category  : ") + c(B + YE, chosen) + c(DM, "  (forced)"))
    else:
        chosen = random.choice(cats)
        print(c(CY, "  >> Category  : ") + c(B + MA, chosen) + c(DM, "  (random)"))

    # ── Fetch image ───────────────────────────────────────────────────────────
    max_attempts = 1 if args.category else 8
    img_url = img_id = img_count = None

    for attempt in range(1, max_attempts + 1):
        try:
            with Spinner("Fetching image…"):
                img_url, img_id, img_count = fetch_image_info(chosen)
            print(
                c(GR, "  >> Image ID   : ")
                + c(YE, str(img_id))
                + c(DM, f"  ({img_count} in category)")
            )
            print(c(GR, "  >> URL        : ") + c(IT + DM, img_url))
            break
        except Exception as exc:
            print(c(RE, f"  [x] Attempt {attempt}/{max_attempts}: {exc}"))
            if attempt == max_attempts:
                print(c(RE, "\n  [x] Could not fetch an image. Exiting."))
                sys.exit(1)
            chosen = random.choice(cats)
            print(c(CY, "  >> Retry with : ") + c(B + MA, chosen))

    # ── Determine file extension (robust parsing) ─────────────────────────────
    path_part = img_url.split("?")[0]
    ext = os.path.splitext(path_part)[1].lstrip(".") or "jpg"

    # ── Clean up old temp files from previous runs ────────────────────────────
    _cleanup_old_temps()

    # ── Download ──────────────────────────────────────────────────────────────
    tmp_dest = os.path.join(tempfile.gettempdir(), f"nekowall_{img_id}.{ext}")

    print()
    print(c(CY, "  >> Downloading…"))
    try:
        download_file(img_url, tmp_dest)
    except Exception as exc:
        print(c(RE, f"\n  [x] Download failed: {exc}"))
        sys.exit(1)

    # ── Record size while the file is guaranteed to exist ─────────────────────
    file_size = os.path.getsize(tmp_dest)

    # ── Determine final path  (move before set_wallpaper so the DE
    #    references a persistent path when --keep is used) ─────────────────────
    if args.keep:
        save_dir = os.path.join(os.path.expanduser("~"), "Pictures", "nekowall")
        os.makedirs(save_dir, exist_ok=True)
        final_dest = os.path.join(save_dir, f"nekowall_{img_id}.{ext}")
        try:
            shutil.move(tmp_dest, final_dest)
        except OSError:
            # cross-device move: fall back to copy + delete
            shutil.copy2(tmp_dest, final_dest)
            os.remove(tmp_dest)
        print(c(GR, "  >> Saved to   : ") + c(DM, final_dest))
    else:
        # Keep the temp file so DE backends that store the path (GNOME, KDE,
        # MATE, Cinnamon) can still read it.  Old temps are cleaned at the
        # start of the next run by _cleanup_old_temps().
        final_dest = tmp_dest

    # ── Set wallpaper (from the file's current location) ──────────────────────
    print(c(CY, "  >> Setting wallpaper…"), end=" ", flush=True)
    try:
        set_wallpaper(final_dest)
        print(c(GR, "done"))
    except OSError as exc:
        print(c(RE, f"\n  [x] {exc}"))
        sys.exit(1)

    # ── Result box ────────────────────────────────────────────────────────────
    print_result_box(chosen, img_id, final_dest, args.keep, file_size)
    footer()


if __name__ == "__main__":
    main()
