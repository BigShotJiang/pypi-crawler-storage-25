__version__ = "2.1.2"
__author__ = "tommy437"
__api_source__ = "https://nekosia.cat"
