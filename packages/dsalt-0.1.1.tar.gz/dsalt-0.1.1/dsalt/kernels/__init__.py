from .sparse_attn import dsalt_attention
from .hybrid_energy import compute_hybrid_energy_scores, select_landmarks