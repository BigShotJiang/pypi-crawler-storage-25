# Contributor Covenant Code of Conduct

## Our Pledge

We as members, contributors, and maintainers pledge to make participation in our
community a harassment-free experience for everyone, regardless of age, body
size, visible or invisible disability, ethnicity, sex characteristics, gender
identity and expression, level of experience, education, socio-economic status,
nationality, personal appearance, race, religion, or sexual identity
and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming,
diverse, inclusive, and healthy community.

## Our Standards

Examples of behavior that contributes to a positive environment:

- Demonstrating empathy and kindness
- Being respectful of differing opinions and experiences
- Giving and gracefully accepting constructive feedback
- Taking responsibility and learning from mistakes
- Focusing on what is best for the overall community

Examples of unacceptable behavior:

- Sexualized language or imagery and unwelcome sexual attention or advances
- Trolling, insulting or derogatory comments, and personal or political attacks
- Public or private harassment
- Publishing others' private information without explicit permission
- Other conduct that could reasonably be considered inappropriate

## Enforcement Responsibilities

Project maintainers are responsible for clarifying and enforcing standards and
will take fair corrective action in response to unacceptable behavior.

## Scope

This Code of Conduct applies within all project spaces and in public spaces when
an individual is officially representing the project.

## Enforcement

Report incidents to: **conduct@navig.run**

All complaints will be reviewed and investigated promptly and fairly.

## Attribution

This Code of Conduct is adapted from the Contributor Covenant, version 2.1:
https://www.contributor-covenant.org/version/2/1/code_of_conduct.html
