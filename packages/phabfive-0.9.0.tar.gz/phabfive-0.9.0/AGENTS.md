# AGENTS.md

This file provides guidance to AI coding agents when working with code in this repository.

## Project Overview

phabfive is a CLI for Phabricator and Phorge. It provides commands for interacting with Passphrase, Diffusion, Paste, User, and Maniphest applications.

## Common Commands

```bash
# Install dependencies
uv sync --group dev

# Run the CLI
uv run phabfive --help

# Run tests
uv run pytest                        # quick test with current Python
uv run pytest tests/test_foo.py      # run single test file
uv run pytest -k test_name           # run specific test
uv run tox                           # test all Python versions (3.10-3.14)

# Lint and format
uv run ruff check phabfive/ tests/
uv run ruff format phabfive/ tests/

# Local Phorge instance for testing
make up                              # start local Phorge
make down                            # stop containers

# Merge PRs (rebase only - merge and squash are disabled)
gh pr merge --rebase --delete-branch
```

## Pre-commit Checks

**Always run before committing:**

```bash
uv run ruff check phabfive/ tests/
uv run ruff format phabfive/ tests/
```

CI will fail if files are not properly formatted.

## Architecture

### CLI Layer (`cli/`)
- Uses `typer` for argument parsing with built-in shell completion
- Modular structure: `__init__.py` (main app), `maniphest.py`, `diffusion.py`, `paste.py`, `user.py`, `passphrase.py`, `repl.py`
- Monogram shortcuts via `preprocess_monograms()`: `phabfive T123` expands to `phabfive maniphest show T123`
- Entry point: `cli_entrypoint()`
- Shell completion: `phabfive --install-completion bash|zsh|fish`

### Core Layer (`core.py`)
- `Phabfive` class: central configuration and API client management
- Loads config from `.arcconfig`, `~/.arcrc`, `~/.config/phabfive.yaml`, and environment variables
- Uses the `phabricator` library for Conduit API calls
- Output formatting: supports `rich` (terminal), `yaml`, and `strict` (machine-readable) modes

### Feature Modules
Complex features use a consistent subpackage structure:
- `diffusion/` and `maniphest/` follow this pattern:
  - `core.py` - main class inheriting from `Phabfive`
  - `fetchers.py` - API data fetching
  - `resolvers.py` - ID/name resolution
  - `formatters.py` - output formatting
  - `validators.py` - input validation

### Simpler Modules
- `passphrase.py`, `paste.py`, `user.py` - single-file implementations
- `transitions/` - state machine for task status/priority/column changes

### Configuration

Required: `PHAB_TOKEN` and `PHAB_URL`

Config precedence (later overrides earlier):
1. Hard-coded defaults
2. `/etc/phabfive.yaml`
3. `/etc/phabfive.d/*.yaml`
4. `~/.config/phabfive.yaml` (PHAB_URL/PHAB_TOKEN deprecated here, use for PHAB_SPACE/PHAB_FALLBACK/PHABFIVE_DEBUG)
5. `~/.config/phabfive.d/*.yaml`
6. `.arcconfig` in git root (provides PHAB_URL from `phabricator.uri`)
7. `~/.arcrc` (provides PHAB_TOKEN for matched URL)
8. Environment variables

## AI Agent Usage

Use `--format=yaml` or `--format=json` for machine-readable output:

```bash
# Get task details as YAML
phabfive --format=yaml T123

# Get task details as JSON
phabfive --format=json T123

# Search tasks with structured output
phabfive --format=json maniphest search --tag=projectname

# Pipe JSON to jq
phabfive --format=json T123 | jq '.Task.Title'
```

## Version Management

Version is defined only in `pyproject.toml`. Access it via:
```python
from importlib.metadata import version
version("phabfive")
```

## Release Workflow

Releases are triggered by pushing a git tag matching `v*`:

```bash
git tag -a v0.7.0 -m "Release v0.7.0"
git push origin v0.7.0
```

**Artifacts produced:**
- Python wheel and sdist → PyPI
- Standalone executables for 6 platforms → GitHub Releases:
  - `phabfive-linux-amd64`, `phabfive-linux-arm64`
  - `phabfive-macos-amd64`, `phabfive-macos-arm64`
  - `phabfive-windows-amd64.exe`, `phabfive-windows-arm64.exe`
- Sigstore signatures (`.sigstore.json`) for all executables except Windows ARM64

**RC tags** (containing `-rc`) skip PyPI but still build executables and create GitHub releases.
