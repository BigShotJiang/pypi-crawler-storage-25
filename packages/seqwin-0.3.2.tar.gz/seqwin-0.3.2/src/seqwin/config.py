"""
Configurations
==============

Seqwin run configurations. Including user/dev configs and internal configs. 

Dependencies:
-------------
- pydantic
- .ncbi
- ._version

Classes:
--------
- Config
- RunState
- WorkingDir
- BlastConfig

Functions:
----------
- config_logger

Attributes:
-----------
- HAS_MASH (bool)
- HAS_BLAST (bool)
- HAS_DATASETS (bool)
- WORKINGDIR (WorkingDir)
- BLASTCONFIG (BlastConfig)
- EDGE_W (str)
- NODE_P (str)
- CONSEC_KMER_TH (int)
- LEN_TH_MUL (float)
- NO_BLAST_DIV (float)
"""

__author__ = 'Michael X. Wang'
__license__ = 'GPL 3.0'

import sys, logging, shutil

_LOG_FMT = '%(asctime)s | %(levelname)-8s | %(message)s'
_LOG_DATEFMT = '%Y-%m-%d %H:%M:%S'

# init root logger
logging.basicConfig(
    format=_LOG_FMT, 
    datefmt=_LOG_DATEFMT, 
    level=logging.INFO, 
    stream=sys.stdout, 
)

from pathlib import Path
from random import Random
from dataclasses import dataclass, field
from types import MappingProxyType
from collections.abc import Mapping
from functools import cached_property

from pydantic import BaseModel, ValidationInfo, Field, computed_field, field_validator, model_validator

from .ncbi import Level, Source, Task
from ._version import __version__

HAS_MASH = shutil.which("mash") is not None
HAS_BLAST = (shutil.which("makeblastdb") is not None) and (shutil.which("blastn") is not None)
HAS_DATASETS = shutil.which("datasets") is not None

_INPUT_FILES = ('tar_paths', 'neg_paths')
_INPUT_DIRS = ('tar_dir', 'neg_dir', 'prefix')


class Config(BaseModel):
    """Seqwin configurations. 

    Attributes:
        tar_taxa (list[str] | None): Target NCBI taxonomy name(s) / ID(s). Must be exact matches. [None]
        neg_taxa (list[str] | None): Non-target NCBI taxonomy name(s) / ID(s). Must be exact matches. [None]
        tar_paths (Path | None): Text file containing paths to target genome FASTA files, one path per line. Gzipped FASTA is supported. [None]
        neg_paths (Path | None): Text file containing paths to non-target genome FASTA files, one path per line. [None]
        tar_dir (Path | None): Directory containing target genome FASTA files. [None]
        neg_dir (Path | None): Directory containing non-target genome FASTA files. [None]
        
        prefix (Path): Parent path where the output directory will be created. Use the current working directory by default. [cwd]
        title (str): Name of the output directory created under `prefix`. ['seqwin-out']
        overwrite (bool): If True, overwrite existing output files. [False]
        
        kmerlen (int): K-mer length. [21]
        windowsize (int): Window size for minimizer sketch. [200]
        penalty_th (float | None): Node penalty threshold, from 0 to 1. If None, Seqwin computes it automatically (capped by `penalty_th_cap`). [None]
        run_mash (bool): If True, use MinHash sketches (Mash) to estimate `penalty_th`; else use minimizer sketches (faster but might be biased). [True]
        stringency (int): If `penalty_th` is None, multiply the computed penalty threshold with `(1 - x/10)`. [5]
        min_len (int): Minimum length of output signatures. [200]
        max_len (int | None): Estimated maximum length of output signatures. If None, no explicit limit is applied (capped by `max_nodes_cap`). [None]
        run_blast (bool): If True, evaluate signature sequences with BLAST. [True]
        blast_neg_only (bool): If True, only include non-target assemblies in the BLAST database. [False]
        
        no_filter (bool): If True, skip filtering k-mers (debug only). [False]
        penalty_th_cap (float): If `penalty_th` is None, penalty threshold cannot be higher than this value. [0.2]
        edge_w_th_mul (float): Multiplier for determining the threshold for low-weight edges. [0.3]
        min_nodes_floor (int): Lowest possible value for `min_nodes` (see `RunState`), regardless of `min_len`. [3]
        max_nodes_cap (int | None): If `max_len` is None, `max_nodes` (see `RunState`) cannot be higher than this value. None for no limit. [100]
        
        sketchsize (int): Sketch size for Mash (MinHash) sketch. [1000]
        get_dist (bool): If True, calculate assembly distance with minimizer sketches (slow). [False]
        
        level (Level): NCBI download option. Limit to genomes ≥ this assembly level ('contig' < 'scaffold' < 'chromosome' < 'complete'). ['contig']
        source (Source): NCBI download option. Genome source ('genbank' or 'refseq'). ['genbank']
        annotated (bool): NCBI download option. If True, limit to GenBank (submitter) or RefSeq annotated genomes, based on the selection of source. [False]
        exclude_mag (bool): NCBI download option. If True, exclude metagenome-assembled genomes (MAGs). [False]
        gzip (bool): NCBI download option. If True, download genome sequences in gzip format. [True]
        download_only (bool): If True, only download genome sequences without running Seqwin. [False]
        
        seed (int): Random seed for reproducibility. [42]
        n_cpu (int): Number of parallel processes or threads to use. [4]
        version (str): Seqwin version. 
    """
    # Inputs
    tar_taxa: list[str] | None = None
    neg_taxa: list[str] | None = None
    tar_paths: Path | None = None
    neg_paths: Path | None = None
    tar_dir: Path | None = None
    neg_dir: Path | None = None

    # Outputs
    prefix: Path = Field(default_factory=Path.cwd) # pass a func for dynamic default
    title: str = 'seqwin-out'
    overwrite: bool = False

    # Signature options
    kmerlen: int = 21
    windowsize: int = 200
    penalty_th: float | None = None
    run_mash: bool = True
    stringency: int = 5
    min_len: int = 200
    max_len: int | None = None
    run_blast: bool = True
    blast_neg_only: bool = False # NOTE: need to fix when this is turned on

    # Graph filtering options (not included in CLI)
    no_filter: bool = False
    penalty_th_cap: float = 0.2
    edge_w_th_mul: float = 0.3
    min_nodes_floor: int = 3
    max_nodes_cap: int | None = 100

    # Mash and assembly distance estimation (not included in CLI)
    sketchsize: int = 1000
    get_dist: bool = False

    # NCBI download options
    level: Level = Level.contig
    source: Source = Source.genbank
    annotated: bool = False
    exclude_mag: bool = False
    gzip: bool = True
    download_only: bool = False

    # Miscellaneous
    seed: int = 42
    n_cpu: int = 4

    @computed_field
    @cached_property
    def version(self) -> str:
        return __version__

    # resolve all input paths and make sure they exist
    @field_validator(*_INPUT_FILES, *_INPUT_DIRS, mode='before')
    @classmethod
    def _resolve_path(cls, v: Path | None, info: ValidationInfo) -> Path | None:
        if v is None:
            return v
        try:
            path = Path(v).expanduser().resolve(strict=True)
        except OSError:
            raise ValueError(f'Path does not exist or cannot be resolved: {v!r}')

        if info.field_name in _INPUT_FILES:
            if not path.is_file():
                raise ValueError(f'Not a file: {path}')
        elif info.field_name in _INPUT_DIRS:
            if not path.is_dir():
                raise ValueError(f'Not a directory: {path}')
        return path

    @model_validator(mode='after')
    def _check_inputs(self) -> 'Config':
        if (not HAS_DATASETS) and (self.tar_taxa or self.neg_taxa):
            raise FileNotFoundError(
                ('ncbi-datasets-cli is not installed. Genomes cannot be downloaded from the '
                'provided taxon names or IDs. Please provide local file paths instead.'))

        if not self.download_only:
            if (self.tar_paths is None) and (self.tar_taxa is None) and (self.tar_dir is None):
                raise ValueError('You must provide at least one target input: tar_paths, tar_taxa, or tar_dir')
            elif (self.neg_paths is None) and (self.neg_taxa is None) and (self.neg_dir is None):
                raise ValueError('You must provide at least one non-target input: neg_paths, neg_taxa, or neg_dir')

        if (self.penalty_th is not None) and (self.penalty_th < 0 or self.penalty_th > 1):
            raise ValueError('penalty_th must be between [0, 1]')

        if self.stringency < 0 or self.stringency > 10:
            raise ValueError('stringency must be between [0, 10]')

        if (self.max_len is not None) and (self.max_len <= self.min_len):
            raise ValueError('max_len must be greater than min_len')

        return self

    model_config = {
        # similar to @dataclass(slots=True, frozen=True)
        'frozen': True, 
        'slots': True, 
        'validate_default': True, 
        'hide_input_in_errors': True
    }


@dataclass(slots=True)
class RunState:
    """Runtime variables. 

    Attributes:
        working_dir (Path): Working directory, defined by prefix and title. 
        rng (random.Random): Built-in `random.Random` instance for reproducibility. 
        n_tar (int | None): Number of target assemblies. 
        n_neg (int | None): Number of non-target assemblies. 
        penalty_th (float | None): Node penalty threshold (user input or auto-computed). 
        edge_weight_th (float | None): Graph edge weight threshold. 
        min_nodes (int | None): Min number of nodes for a low-penalty subgraph. 
        max_nodes (int | None): Max number of nodes for a low-penalty subgraph. 
        blastdb (Path | None): Path to the BLAST database inside the working directory. 
    """
    working_dir: Path
    rng: Random
    n_tar: int | None = None
    n_neg: int | None = None
    penalty_th: float | None = None
    edge_weight_th: float | None = None
    min_nodes: int | None = None
    max_nodes: int | None = None
    blastdb: Path | None = None


@dataclass(slots=True, frozen=True)
class WorkingDir:
    """Files and directories under the working directory. 

    Attributes:
        log (str): Seqwin log file. ['seqwin.log']
        config (str): The `Config` instance saved as JSON. ['config.json']
        assemblies_dir (str): Directory for downloaded assemblies. ['assemblies']
        assemblies_csv (str): The `Assemblies` instance (`assemblies.py`) saved as CSV. ['assemblies.csv']
        mash (str): Mash sketch of all assemblies (.msh will be added by Mash). ['sketches']
        blast_dir (str): Directory for the BLAST database. ['blastdb']
        blast_log (str): Console output of the makeblastdb command, inside `blast_dir`. ['makeblastdb.log']
        markers_fasta (str): Sequences and coordinates of candidate signatures. ['signatures.fasta']
        markers_csv (str): Metrics of candidate signatures. ['signatures.csv']
        results (str): The `Seqwin` instance (`core.py`) saved as pickle. ['results.seqwin']
    """
    log: str = 'seqwin.log'
    config: str = 'config.json'
    assemblies_dir: str = 'assemblies'
    assemblies_csv: str = 'assemblies.csv'
    mash: str = 'sketches'
    blast_dir: str = 'blastdb'
    blast_log: str = 'makeblastdb.log'
    markers_fasta: str = 'signatures.fasta'
    markers_csv: str = 'signatures.csv'
    results: str = 'results.seqwin'


@dataclass(slots=True, frozen=True)
class BlastConfig:
    """Settings for the BLAST commands `makeblastdb` and `blastn`. 

    Attributes:
        title_neg_only (str): DB title when created from non-target assemblies only. ['neg-only']
        title_all (str): DB title when created from all assemblies. ['all']
        queue_size (int): Max queue size when streaming FASTA files to stdin of `makeblastdb`, to limit memory usage. [50]
        bool2str (Mapping[bool, str]): Mapping of bool to string. [True -> 'y', False -> 'n']
        str2bool (Mapping[str, bool]): Reversed mapping of bool2str for parsing BLAST outputs. ['y' -> True, 'n' -> False]
        header_sep (str): Separator used in FASTA headers. Should pick a rare char (cannot be '$', BLAST treats it as a special char). ['@']
        task (str): Presets for BLAST parameters ('blastn', 'blastn-short', 'megablast'). ['blastn']
        columns (tuple[str, ...]): Columns to be included in the BLAST TSV output. See `ncbi.py` for more information. 
        batch_size (int): # Number of query sequences in a single BLAST run. [1000]
    """
    title_neg_only: str = 'neg-only'
    title_all: str = 'all'
    queue_size: int = 50
    bool2str: Mapping[bool, str] = field( # a dict cannot be used as the default value in a dataclass
        # MappingProxyType is not hashable until python 3.12, so have to use default_factory for compatibility
        default_factory=lambda: MappingProxyType({True: 'y', False: 'n'})
    )
    str2bool: Mapping[str, bool] = field(
        default_factory=lambda: MappingProxyType({'y': True, 'n': False})
    )
    header_sep: str = '@'
    task: Task = Task.blastn
    columns = (
        'qseqid', 
        'sseqid', 
        'nident', 
        'mismatch', 
        'gaps', 
        'qstart', 
        'qend', 
        'sstart', 
        'send', 
        'evalue', 
        'bitscore', 
        'sseq'
    )
    batch_size: int = 1000


def config_logger(file: Path, level: int) -> None:
    """Add a file handler and set logging level for the root logger. 

    Args:
        file (Path): Path to the log file. 
        level (int): Logging level (e.g., `logging.INFO`). 
    """
    # use the same format
    logFormatter = logging.Formatter(
        fmt=_LOG_FMT, 
        datefmt=_LOG_DATEFMT, 
        style='%'
    )
    fileHandler = logging.FileHandler(file, mode='a')
    fileHandler.setFormatter(logFormatter)

    logger = logging.getLogger()
    logger.addHandler(fileHandler)
    logger.setLevel(level)


# freeze dataclasses
WORKINGDIR = WorkingDir()
BLASTCONFIG = BlastConfig()

EDGE_W: str = 'w' # Key for edge weight, used in networkx graphs. ['w']
NODE_P: str = 'p' # Key for node penalty, used in networkx graphs. ['p']
CONSEC_KMER_TH: int = 2 # Max index difference between consecutive k-mers. [2]
LEN_TH_MUL: float = 1.5 # Deprecated. Multiplier for candidate sequence length threshold. [1.5]
NO_BLAST_DIV: float = 0.5 # Deprecated. Assumed divergence when there is no BLAST hit. [0.5]
