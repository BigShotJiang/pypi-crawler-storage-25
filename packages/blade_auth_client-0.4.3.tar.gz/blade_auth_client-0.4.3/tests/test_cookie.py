from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from blade_auth_client.cookie.policy import clear_session_cookie, read_session_token, write_session_cookie


@dataclass
class FakeResponse:
    set_calls: list[dict[str, Any]] = field(default_factory=list)
    delete_calls: list[dict[str, Any]] = field(default_factory=list)

    def set_cookie(self, **kwargs: Any) -> None:
        self.set_calls.append(kwargs)

    def delete_cookie(self, **kwargs: Any) -> None:
        self.delete_calls.append(kwargs)


@dataclass
class FakeRequest:
    cookies: dict[str, str]


def test_write_session_cookie_uses_host_only_policy(auth_config) -> None:
    response = FakeResponse()

    write_session_cookie(response, "session-token", auth_config)

    assert response.set_calls == [
        {
            "key": "blade_token",
            "value": "session-token",
            "httponly": True,
            "path": "/",
            "samesite": "lax",
            "secure": False,
        }
    ]


def test_clear_session_cookie_uses_matching_attributes(auth_config) -> None:
    response = FakeResponse()

    clear_session_cookie(response, auth_config)

    assert response.delete_calls == [
        {
            "key": "blade_token",
            "httponly": True,
            "path": "/",
            "samesite": "lax",
            "secure": False,
        }
    ]


def test_read_session_token_uses_default_cookie_name() -> None:
    request = FakeRequest(cookies={"blade_token": "session-token"})

    assert read_session_token(request) == "session-token"
