from __future__ import annotations

import asyncio
from dataclasses import dataclass
from urllib.parse import parse_qs, urlparse

import httpx
import pytest
import respx
from fastapi import FastAPI, Request
from fastapi.testclient import TestClient

from blade_auth_client.casdoor.client import OidcClient
from blade_auth_client.config import AuthConfig
from blade_auth_client.fastapi.urls import build_callback_url
from blade_auth_client.fastapi.router import create_auth_router
from blade_auth_client.users.provisioner import CasdoorClaims
from blade_auth_client.verifier.jwks_cache import JwksCache
from blade_auth_client.verifier.token_verifier import TokenVerifier


@dataclass
class LocalUser:
    id: str
    username: str
    avatar_url: str | None = None


class RecordingProvisioner:
    def __init__(self) -> None:
        self.calls: list[CasdoorClaims] = []

    async def provision_user(self, claims: CasdoorClaims) -> LocalUser:
        self.calls.append(claims)
        return LocalUser(
            id=f"local-{claims.sub}",
            username=claims.preferred_username or claims.sub,
            avatar_url=claims.picture,
        )


@pytest.fixture
def fastapi_auth_config(auth_config: AuthConfig) -> AuthConfig:
    return auth_config.model_copy(
        update={
            "cookie_name": "blade_session",
        }
    )


@pytest.fixture
def router_runtime(fastapi_auth_config: AuthConfig):
    oidc_http_client = httpx.AsyncClient()
    jwks_http_client = httpx.AsyncClient()
    oidc_client = OidcClient(fastapi_auth_config, http_client=oidc_http_client)
    verifier = TokenVerifier(
        fastapi_auth_config,
        jwks_cache=JwksCache(fastapi_auth_config, http_client=jwks_http_client),
    )
    provisioner = RecordingProvisioner()

    app = FastAPI()
    app.include_router(
        create_auth_router(
            fastapi_auth_config,
            verifier=verifier,
            provisioner=provisioner,
            oidc_client=oidc_client,
        ),
        prefix="/api/auth",
    )

    with TestClient(app) as client:
        yield {
            "client": client,
            "config": fastapi_auth_config,
            "provisioner": provisioner,
        }

    asyncio.run(oidc_http_client.aclose())
    asyncio.run(jwks_http_client.aclose())


def test_login_redirects_to_casdoor_with_state(router_runtime) -> None:
    response = router_runtime["client"].get(
        "/api/auth/login",
        params={"next": "http://testserver/workbench"},
        follow_redirects=False,
    )

    assert response.status_code == 302
    parsed = urlparse(response.headers["location"])
    query = parse_qs(parsed.query)
    assert parsed.scheme == "http"
    assert parsed.netloc == "testserver:19000"
    assert query["scope"] == ["openid profile email"]
    assert query["redirect_uri"] == ["http://testserver/api/auth/oauth/casdoor/callback"]
    assert len(query["state"][0]) > 10


def test_login_uses_dynamic_host_for_public_redirect(router_runtime) -> None:
    # 动态 host：next 只需 hostname 匹配当前 request.host，端口/scheme 可异
    response = router_runtime["client"].get(
        "/api/auth/login",
        params={"next": "http://192.168.1.123:5927/workbench"},
        headers={"host": "192.168.1.123:8020"},
        follow_redirects=False,
    )

    assert response.status_code == 302
    parsed = urlparse(response.headers["location"])
    query = parse_qs(parsed.query)
    assert parsed.netloc == "192.168.1.123:19000"
    assert query["redirect_uri"] == ["http://192.168.1.123:8020/api/auth/oauth/casdoor/callback"]


def test_login_rejects_different_host(router_runtime) -> None:
    # next 的 hostname 跟 request.host 不同时必须拒绝，防 open-redirect
    response = router_runtime["client"].get(
        "/api/auth/login",
        params={"next": "http://evil.example/steal"},
        headers={"host": "testserver"},
        follow_redirects=False,
    )
    assert response.status_code == 400
    assert response.json()["detail"] == "next origin is not allowed"


def test_build_callback_url_uses_current_request_host() -> None:
    app = FastAPI()

    @app.get("/inspect")
    async def inspect_callback(request: Request):
        return {"callback_url": build_callback_url(request, "/api/auth")}

    with TestClient(app) as client:
        response = client.get("/inspect", headers={"host": "192.168.1.123:8020"})

    assert response.status_code == 200
    assert response.json() == {
        "callback_url": "http://192.168.1.123:8020/api/auth/oauth/casdoor/callback"
    }


def test_callback_exchanges_code_sets_cookie_and_redirects(
    router_runtime, oidc_discovery, rsa_keypair, issue_token
) -> None:
    client = router_runtime["client"]
    config = router_runtime["config"]
    token = issue_token(
        rsa_keypair["private_key"],
        kid=rsa_keypair["kid"],
        issuer=oidc_discovery["issuer"],
        audience=[config.casdoor_client_id],
        extra_claims={
            "sub": "user-123",
            "preferred_username": "blade",
            "picture": "https://cdn.example/avatar.png",
        },
    )

    with respx.mock(assert_all_called=True) as router:
        router.post("http://casdoor.internal:19000/api/login/oauth/access_token").mock(
            return_value=httpx.Response(200, json={"access_token": token})
        )
        router.get("http://casdoor.internal:19000/.well-known/jwks").mock(
            return_value=httpx.Response(200, json=rsa_keypair["jwks"])
        )

        login_response = client.get(
            "/api/auth/login",
            params={"next": "http://testserver/workbench"},
            follow_redirects=False,
        )
        state = parse_qs(urlparse(login_response.headers["location"]).query)["state"][0]
        response = client.get(
            "/api/auth/oauth/casdoor/callback",
            params={"code": "code-123", "state": state},
            follow_redirects=False,
        )

    assert response.status_code == 302
    assert response.headers["location"] == "http://testserver/workbench"
    assert client.cookies.get(config.cookie_name) == token
    assert f"{config.cookie_name}={token}" in response.headers["set-cookie"]


def test_callback_rejects_unknown_state(router_runtime) -> None:
    response = router_runtime["client"].get(
        "/api/auth/oauth/casdoor/callback",
        params={"code": "code-123", "state": "missing-state"},
        follow_redirects=False,
    )

    assert response.status_code == 400
    assert response.json()["detail"] == "Invalid state"


def test_callback_maps_casdoor_error_on_200_to_500(router_runtime) -> None:
    client = router_runtime["client"]

    with respx.mock(assert_all_called=True) as router:
        router.post("http://casdoor.internal:19000/api/login/oauth/access_token").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": "error",
                    "error": "invalid_grant",
                    "msg": "bad authorization code",
                },
            )
        )

        login_response = client.get(
            "/api/auth/login",
            params={"next": "http://testserver/workbench"},
            follow_redirects=False,
        )
        state = parse_qs(urlparse(login_response.headers["location"]).query)["state"][0]
        response = client.get(
            "/api/auth/oauth/casdoor/callback",
            params={"code": "bad-code", "state": state},
            follow_redirects=False,
        )

    assert response.status_code == 500
    assert response.json()["detail"] == "bad authorization code"


def test_me_returns_flattened_user_with_valid_cookie(
    router_runtime, oidc_discovery, rsa_keypair, issue_token
) -> None:
    client = router_runtime["client"]
    config = router_runtime["config"]
    token = issue_token(
        rsa_keypair["private_key"],
        kid=rsa_keypair["kid"],
        issuer=oidc_discovery["issuer"],
        audience=[config.casdoor_client_id],
        extra_claims={
            "sub": "user-123",
            "preferred_username": "blade",
            "picture": "https://cdn.example/avatar.png",
        },
    )
    client.cookies.set(config.cookie_name, token)

    with respx.mock(assert_all_called=True) as router:
        router.get("http://casdoor.internal:19000/.well-known/jwks").mock(
            return_value=httpx.Response(200, json=rsa_keypair["jwks"])
        )

        response = client.get("/api/auth/me")

    assert response.status_code == 200
    assert response.json() == {
        "id": "local-user-123",
        "username": "blade",
        "avatar_url": "https://cdn.example/avatar.png",
        "token": token,
        "auth_type": "casdoor",
    }


def test_me_uses_custom_serializer(router_runtime, oidc_discovery, rsa_keypair, issue_token) -> None:
    oidc_http_client = httpx.AsyncClient()
    jwks_http_client = httpx.AsyncClient()
    config = router_runtime["config"]
    token = issue_token(
        rsa_keypair["private_key"],
        kid=rsa_keypair["kid"],
        issuer=oidc_discovery["issuer"],
        audience=[config.casdoor_client_id],
        extra_claims={"sub": "custom-user", "preferred_username": "custom"},
    )
    provisioner = RecordingProvisioner()
    app = FastAPI()
    app.include_router(
        create_auth_router(
            config,
            verifier=TokenVerifier(config, jwks_cache=JwksCache(config, http_client=jwks_http_client)),
            provisioner=provisioner,
            oidc_client=OidcClient(config, http_client=oidc_http_client),
            me_serializer=lambda user, claims, request: {
                "user_id": user.id,
                "sub": claims.sub if claims else None,
                "token": getattr(request.state, "blade_auth_token", None),
            },
        ),
        prefix="/api/auth",
    )

    with TestClient(app) as client:
        client.cookies.set(config.cookie_name, token)
        with respx.mock(assert_all_called=True) as router:
            router.get("http://casdoor.internal:19000/.well-known/jwks").mock(
                return_value=httpx.Response(200, json=rsa_keypair["jwks"])
            )
            response = client.get("/api/auth/me")

    asyncio.run(oidc_http_client.aclose())
    asyncio.run(jwks_http_client.aclose())

    assert response.status_code == 200
    assert response.json() == {
        "user_id": "local-custom-user",
        "sub": "custom-user",
        "token": token,
    }


def test_logout_post_returns_json_and_clears_cookie(router_runtime) -> None:
    response = router_runtime["client"].post("/api/auth/logout")

    assert response.status_code == 200
    assert response.json()["logout_url"] == "http://testserver:19000/logout"
    assert "Max-Age=0" in response.headers["set-cookie"]


def test_logout_get_redirects_to_casdoor(router_runtime) -> None:
    response = router_runtime["client"].get("/api/auth/logout", follow_redirects=False)

    assert response.status_code == 302
    assert response.headers["location"] == "http://testserver:19000/logout"


def test_me_requires_authentication_without_cookie(router_runtime) -> None:
    response = router_runtime["client"].get("/api/auth/me")

    assert response.status_code == 401
    assert response.json()["detail"] == "Unauthorized"


def test_me_rejects_legacy_hs256_cookie(
    router_runtime, oidc_discovery, rsa_keypair, issue_token
) -> None:
    token = issue_token(
        rsa_keypair["private_key"],
        kid=rsa_keypair["kid"],
        issuer=oidc_discovery["issuer"],
        audience=[router_runtime["config"].casdoor_client_id],
        algorithm="HS256",
        secret="shared-secret-that-is-long-enough",
    )
    client = router_runtime["client"]
    client.cookies.set(router_runtime["config"].cookie_name, token)

    response = client.get("/api/auth/me")

    assert response.status_code == 401
    assert "Max-Age=0" in response.headers["set-cookie"]


def test_deploy_mode_server_skips_host_inference() -> None:
    from blade_auth_client.config import AuthConfig, OAuthConfig

    config = AuthConfig(
        oauth=OAuthConfig(
            client_id="srv-client",
            client_secret="srv-secret",
            internal_endpoint="http://casdoor.internal:19000",
            deploy_mode="server",
            public_endpoint="https://sso.company.com",
        )
    )
    oidc_http_client = httpx.AsyncClient()
    jwks_http_client = httpx.AsyncClient()
    oidc_client = OidcClient(config, http_client=oidc_http_client)
    verifier = TokenVerifier(
        config, jwks_cache=JwksCache(config, http_client=jwks_http_client)
    )

    app = FastAPI()
    app.include_router(
        create_auth_router(
            config,
            verifier=verifier,
            provisioner=RecordingProvisioner(),
            oidc_client=oidc_client,
        ),
        prefix="/api/auth",
    )

    try:
        with respx.mock(assert_all_called=False) as http_mock:
            http_mock.get("http://casdoor.internal:19000/.well-known/jwks").mock(
                return_value=httpx.Response(200, json={"keys": []})
            )
            with TestClient(app) as client:
                # next 的 hostname 必须跟 request host 匹配，否则 400
                response = client.get(
                    "/api/auth/login",
                    params={"next": "http://192.168.9.9:8020/workbench"},
                    headers={"host": "192.168.9.9:8020"},
                    follow_redirects=False,
                )

        assert response.status_code == 302
        parsed = urlparse(response.headers["location"])
        assert parsed.scheme == "https"
        assert parsed.netloc == "sso.company.com"
        assert parsed.path == "/login/oauth/authorize"
    finally:
        asyncio.run(oidc_http_client.aclose())
        asyncio.run(jwks_http_client.aclose())
