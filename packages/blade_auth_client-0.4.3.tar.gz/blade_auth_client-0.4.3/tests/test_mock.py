"""Mock 模式(0.4.1+)测试。

核心不变量 = 接入方业务代码 100% 感知不到 mock。这里覆盖:
- ``oauth.mock=true`` 起手,BladeAuth 构造不抛异常 + WARN log
- ``/login`` short-circuit:直接 302 到 next + 写 cookie + provisioner 被调
- cookie 里是真 RS256 JWT(pyjwt 能 decode,iss 是 mock://local-casdoor)
- 后续 ``auth.require()`` / ``auth.current()`` 能接住这个 cookie,handler 拿到 user
- ``/oauth/casdoor/callback?code=&state=`` 在 mock 下也能跑通(MockOidcClient 返真 JWT)
- ``oauth.mock=true`` 但未配 ``mock_user`` → AuthConfig 构造抛 ValueError
- ``/providers`` 响应不泄漏 mock 标志(§6.4 对接入方 100% 透明)
- mock=false 时真 TokenVerifier / OidcClient 生效(回归)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

import jwt
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from blade_auth_client import BladeAuth
from blade_auth_client.config import AuthConfig
from blade_auth_client.users.provisioner import CasdoorClaims


@dataclass
class LocalUser:
    id: str
    sub: str
    email: str | None
    name: str | None


class RecordingProvisioner:
    def __init__(self) -> None:
        self.calls: list[CasdoorClaims] = []

    async def provision_user(self, claims: CasdoorClaims) -> LocalUser:
        self.calls.append(claims)
        return LocalUser(
            id=f"local-{claims.sub}",
            sub=claims.sub,
            email=claims.email,
            name=claims.name,
        )


def _mock_config(**overrides) -> AuthConfig:
    data = {
        "oauth": {
            "client_id": "blade-client",
            "client_secret": "placeholder",
            "internal_endpoint": "http://localhost",
            "deploy_mode": "box",
            "public_port": 19000,
            "mock": True,
            "mock_user": {
                "sub": "mock-admin",
                "email": "admin@mock.local",
                "name": "Mock Admin",
                "preferred_username": "mockadmin",
            },
        },
        "cookie": {"name": "blade_token", "secure": False, "same_site": "lax"},
    }
    data["oauth"].update(overrides.pop("oauth_overrides", {}))
    return AuthConfig(**data)


def _make_app(auth: BladeAuth) -> FastAPI:
    app = FastAPI()
    app.include_router(auth.router, prefix="/api/v1/auth")

    @app.get("/protected")
    def protected(user: LocalUser = auth.require()) -> dict[str, str]:
        return {"sub": user.sub, "email": user.email or ""}

    @app.get("/maybe")
    def maybe(user: LocalUser | None = auth.current()) -> dict[str, object]:
        return {"sub": user.sub if user else None}

    return app


def test_config_rejects_mock_without_mock_user() -> None:
    with pytest.raises(ValueError, match="oauth.mock=true requires oauth.mock_user"):
        AuthConfig(
            oauth={
                "client_id": "x",
                "client_secret": "y",
                "internal_endpoint": "http://localhost",
                "deploy_mode": "box",
                "mock": True,
                # mock_user 故意不填
            }
        )


def test_bladeauth_mock_emits_warning(caplog: pytest.LogCaptureFixture) -> None:
    with caplog.at_level(logging.WARNING, logger="blade_auth_client.facade"):
        BladeAuth(_mock_config(), provisioner=RecordingProvisioner())
    warns = [r.message for r in caplog.records if "MOCK mode" in r.message]
    assert len(warns) == 1, warns
    assert "mock-admin" in warns[0]


def test_login_short_circuits_and_writes_cookie() -> None:
    provisioner = RecordingProvisioner()
    auth: BladeAuth[LocalUser] = BladeAuth(_mock_config(), provisioner=provisioner)
    client = TestClient(_make_app(auth))

    # /login 请求,不让 TestClient 自动跟 302
    resp = client.get(
        "/api/v1/auth/login",
        params={"next": "http://testserver/dashboard"},
        follow_redirects=False,
    )
    assert resp.status_code == 302
    assert resp.headers["location"] == "http://testserver/dashboard"
    assert "blade_token" in resp.cookies

    # provisioner 被调一次,claims 来自 mock_user
    assert len(provisioner.calls) == 1
    assert provisioner.calls[0].sub == "mock-admin"
    assert provisioner.calls[0].email == "admin@mock.local"


def test_login_cookie_is_real_rs256_jwt() -> None:
    auth: BladeAuth[LocalUser] = BladeAuth(_mock_config(), provisioner=RecordingProvisioner())
    client = TestClient(_make_app(auth))

    resp = client.get(
        "/api/v1/auth/login",
        params={"next": "http://testserver/"},
        follow_redirects=False,
    )
    token = resp.cookies["blade_token"]

    # 不验签名也能拿到 claims(shape 跟真 JWT 一致)
    unverified = jwt.decode(token, options={"verify_signature": False})
    assert unverified["sub"] == "mock-admin"
    assert unverified["iss"] == "mock://local-casdoor"
    assert unverified["aud"] == "blade-client"
    assert "exp" in unverified


def test_protected_route_accepts_mock_cookie() -> None:
    auth: BladeAuth[LocalUser] = BladeAuth(_mock_config(), provisioner=RecordingProvisioner())
    client = TestClient(_make_app(auth))

    client.get(
        "/api/v1/auth/login",
        params={"next": "http://testserver/"},
        follow_redirects=False,
    )
    # TestClient 自动带 cookie
    resp = client.get("/protected")
    assert resp.status_code == 200
    assert resp.json() == {"sub": "mock-admin", "email": "admin@mock.local"}


def test_callback_route_also_works_under_mock() -> None:
    """callback 路径 MockOidcClient.exchange_code 返真 JWT,callback handler
    按 prod 路径跑通。允许测试代码直接 GET /callback 验 callback handler。"""
    auth: BladeAuth[LocalUser] = BladeAuth(_mock_config(), provisioner=RecordingProvisioner())
    client = TestClient(_make_app(auth))

    # 先跑一把 /login 存 state(callback 需要 state 对)
    login = client.get(
        "/api/v1/auth/login",
        params={"next": "http://testserver/"},
        follow_redirects=False,
    )
    # mock 下 /login 直接 302 到 next,没有 state。要测 callback 路径需要手动存
    # state —— 但我们有设计目标 "mock 下不用跑 callback",这里只确认 callback
    # handler 在 mock 模式下不会 500(MockOidcClient.exchange_code 能返 token)。
    # 不伪造 state 直接访问会因为 "Invalid state" 400,验证这一步也算覆盖。
    del login
    bad = client.get(
        "/api/v1/auth/oauth/casdoor/callback",
        params={"code": "whatever", "state": "never-stored"},
        follow_redirects=False,
    )
    assert bad.status_code == 400  # invalid state,不是 500


def test_providers_response_does_not_leak_mock_flag() -> None:
    """§6.4 对接入方 100% 透明:/providers JSON 不应该含 mock 字段。"""
    auth: BladeAuth[LocalUser] = BladeAuth(_mock_config(), provisioner=RecordingProvisioner())
    client = TestClient(_make_app(auth))

    resp = client.get("/api/v1/auth/providers")
    assert resp.status_code == 200
    body = resp.json()
    assert "mock" not in body
    for p in body.get("providers", []):
        assert "mock" not in p


def test_mock_false_uses_real_clients() -> None:
    """mock=false(默认)→ BladeAuth 构造真 TokenVerifier / OidcClient。"""
    from blade_auth_client.casdoor.client import OidcClient as RealOidcClient
    from blade_auth_client.verifier.jwks_cache import JwksCache as RealJwksCache

    config = AuthConfig(
        oauth={
            "client_id": "x",
            "client_secret": "y",
            "internal_endpoint": "http://localhost",
            "deploy_mode": "box",
            # mock not set → default False
        }
    )
    auth: BladeAuth[LocalUser] = BladeAuth(config, provisioner=RecordingProvisioner())
    assert auth._local_casdoor is None
    assert isinstance(auth._oidc, RealOidcClient)
    # TokenVerifier 的内部 jwks cache 应该是真 JwksCache
    assert isinstance(auth._verifier._jwks_cache, RealJwksCache)


def test_bladeauth_has_no_is_mock_property() -> None:
    """§6.4 刻意不提供 is_mock 后门,防止接入方 branch mock 逻辑。"""
    auth: BladeAuth[LocalUser] = BladeAuth(_mock_config(), provisioner=RecordingProvisioner())
    assert not hasattr(auth, "is_mock"), "BladeAuth 不应暴露 is_mock(见设计文档 §6.4)"


# -----------------------------------------------------------------
# 0.4.2+:跨服务共享硬编码 keypair。多个 BladeAuth 进程都用同一份私钥，
# A 签的 JWT 在 B 验签必须通过 —— 多服务 SSO 在 mock 下默认成立。
# -----------------------------------------------------------------


def test_mock_keypair_is_shared_across_instances() -> None:
    """两个 BladeAuth 实例（模拟两个服务）拿到的 mock keypair 是同一份。"""
    auth_a: BladeAuth[LocalUser] = BladeAuth(_mock_config(), provisioner=RecordingProvisioner())
    auth_b: BladeAuth[LocalUser] = BladeAuth(
        _mock_config(oauth_overrides={"client_id": "another-service"}),
        provisioner=RecordingProvisioner(),
    )
    assert auth_a._local_casdoor is not None
    assert auth_b._local_casdoor is not None
    pem_a = auth_a._local_casdoor._private_pem
    pem_b = auth_b._local_casdoor._private_pem
    assert pem_a == pem_b, "0.4.2+ 起 mock keypair 必须是 SDK 常量,不能进程级生成"


# -----------------------------------------------------------------
# 0.4.3+:静态登录页 ``oauth.mock_login_page``。GET /login 返 HTML 表单,
# 用户输 username + password 命中 mock_user 才发 cookie。
# -----------------------------------------------------------------


def _mock_login_page_config(**oauth_overrides: Any) -> AuthConfig:
    cfg = _mock_config(
        oauth_overrides={
            "mock_login_page": True,
            "mock_user": {
                "sub": "mock-admin",
                "email": "admin@mock.local",
                "name": "Mock Admin",
                "preferred_username": "mockadmin",
                "password": "secret123",
            },
            **oauth_overrides,
        }
    )
    return cfg


def test_config_rejects_login_page_without_password() -> None:
    with pytest.raises(ValueError, match="mock_user.password"):
        AuthConfig(
            oauth={
                "client_id": "x",
                "client_secret": "y",
                "internal_endpoint": "http://localhost",
                "deploy_mode": "box",
                "mock": True,
                "mock_login_page": True,
                "mock_user": {"sub": "u", "preferred_username": "u"},
            }
        )


def test_config_rejects_login_page_without_mock() -> None:
    with pytest.raises(ValueError, match="oauth.mock_login_page=true requires oauth.mock=true"):
        AuthConfig(
            oauth={
                "client_id": "x",
                "client_secret": "y",
                "internal_endpoint": "http://localhost",
                "deploy_mode": "box",
                "mock_login_page": True,  # mock=False 默认
            }
        )


def test_get_login_returns_html_when_login_page_enabled() -> None:
    auth: BladeAuth[LocalUser] = BladeAuth(
        _mock_login_page_config(), provisioner=RecordingProvisioner()
    )
    client = TestClient(_make_app(auth))

    resp = client.get("/api/v1/auth/login", params={"next": "http://testserver/"}, follow_redirects=False)
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("text/html")
    body = resp.text
    assert 'name="state"' in body and 'name="username"' in body and 'name="password"' in body
    # 设计文档 §6.4：登录页不能泄漏 mock / dev / mock_user 信息
    assert "mock" not in body.lower()
    assert "Mock Admin" not in body
    assert "mockadmin" not in body


def test_post_login_with_correct_credentials_mints_cookie() -> None:
    auth: BladeAuth[LocalUser] = BladeAuth(
        _mock_login_page_config(), provisioner=RecordingProvisioner()
    )
    client = TestClient(_make_app(auth))

    # GET 拿 state
    resp = client.get("/api/v1/auth/login", params={"next": "http://testserver/dashboard"})
    body = resp.text
    state = body.split('name="state" value="', 1)[1].split('"', 1)[0]

    # POST 正确凭证
    submit = client.post(
        "/api/v1/auth/login",
        data={"state": state, "username": "mockadmin", "password": "secret123"},
        follow_redirects=False,
    )
    assert submit.status_code == 302
    assert submit.headers["location"] == "http://testserver/dashboard"
    assert "blade_token" in submit.cookies


def test_post_login_with_email_username_also_works() -> None:
    auth: BladeAuth[LocalUser] = BladeAuth(
        _mock_login_page_config(), provisioner=RecordingProvisioner()
    )
    client = TestClient(_make_app(auth))

    resp = client.get("/api/v1/auth/login", params={"next": "http://testserver/"})
    state = resp.text.split('name="state" value="', 1)[1].split('"', 1)[0]

    submit = client.post(
        "/api/v1/auth/login",
        data={"state": state, "username": "admin@mock.local", "password": "secret123"},
        follow_redirects=False,
    )
    assert submit.status_code == 302


def test_post_login_with_wrong_password_returns_form_with_error() -> None:
    auth: BladeAuth[LocalUser] = BladeAuth(
        _mock_login_page_config(), provisioner=RecordingProvisioner()
    )
    client = TestClient(_make_app(auth))

    resp = client.get("/api/v1/auth/login", params={"next": "http://testserver/"})
    state = resp.text.split('name="state" value="', 1)[1].split('"', 1)[0]

    submit = client.post(
        "/api/v1/auth/login",
        data={"state": state, "username": "mockadmin", "password": "WRONG"},
        follow_redirects=False,
    )
    assert submit.status_code == 401
    assert "blade_token" not in submit.cookies
    assert "用户名或密码错误" in submit.text
    # 重新发了一个 state 让用户能重试
    assert 'name="state" value=' in submit.text


def test_post_login_404_when_login_page_disabled() -> None:
    """login_page=false 时 POST /login 不存在。"""
    auth: BladeAuth[LocalUser] = BladeAuth(_mock_config(), provisioner=RecordingProvisioner())
    client = TestClient(_make_app(auth))

    submit = client.post(
        "/api/v1/auth/login",
        data={"state": "x", "username": "a", "password": "b"},
        follow_redirects=False,
    )
    assert submit.status_code == 404


def test_get_login_still_short_circuits_when_login_page_disabled() -> None:
    """0.4.1 老接入方升 0.4.3,不打开 login_page,行为完全不变。"""
    auth: BladeAuth[LocalUser] = BladeAuth(_mock_config(), provisioner=RecordingProvisioner())
    client = TestClient(_make_app(auth))

    resp = client.get("/api/v1/auth/login", params={"next": "http://testserver/"}, follow_redirects=False)
    assert resp.status_code == 302
    assert "blade_token" in resp.cookies


@pytest.mark.asyncio
async def test_mock_token_minted_by_one_verifies_in_another() -> None:
    """关键验证：service A 签的 JWT 在 service B 用自己的 BladeAuth 验签必须 OK。"""
    auth_signer: BladeAuth[LocalUser] = BladeAuth(
        _mock_config(), provisioner=RecordingProvisioner()
    )
    auth_verifier: BladeAuth[LocalUser] = BladeAuth(
        _mock_config(oauth_overrides={"client_id": "another-service"}),
        provisioner=RecordingProvisioner(),
    )

    assert auth_signer._local_casdoor is not None
    token = auth_signer._local_casdoor.mint_token()

    # 用 verifier 服务的 BladeAuth.verify 解析 + 验签;不抛异常 = 互认成立
    claims = await auth_verifier.verify(token)
    assert claims.sub == "mock-admin"
    assert claims.email == "admin@mock.local"
