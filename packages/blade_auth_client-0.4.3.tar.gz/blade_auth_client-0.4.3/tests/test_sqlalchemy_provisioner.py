from __future__ import annotations

from dataclasses import dataclass

import pytest
from sqlalchemy import String, create_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

from blade_auth_client.errors import UserProvisionError
from blade_auth_client.users import CasdoorClaims, SqlAlchemyProvisioner


class Base(DeclarativeBase):
    pass


class UserModel(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    casdoor_sub: Mapped[str] = mapped_column(String, unique=True)
    username: Mapped[str] = mapped_column(String)
    email: Mapped[str | None] = mapped_column(String, nullable=True)
    avatar_url: Mapped[str | None] = mapped_column(String, nullable=True)


@dataclass
class HookCall:
    username: str
    sub: str


@pytest.fixture
def db_sessionmaker():
    engine = create_engine("sqlite+pysqlite:///:memory:")
    Base.metadata.create_all(engine)
    return sessionmaker(engine)


@pytest.mark.asyncio
async def test_sqlalchemy_provisioner_creates_and_updates_user(db_sessionmaker) -> None:
    hook_calls: list[HookCall] = []

    def after_login(session, user, claims):  # noqa: ARG001
        hook_calls.append(HookCall(username=user.username, sub=claims.sub))

    provisioner = SqlAlchemyProvisioner(db_sessionmaker, UserModel, after_login=after_login)

    created = await provisioner.provision_user(
        CasdoorClaims(
            sub="casdoor-sub-1",
            preferred_username="alice",
            email="alice@example.com",
            picture="https://example.com/a.png",
        )
    )
    updated = await provisioner.provision_user(
        CasdoorClaims(
            sub="casdoor-sub-1",
            preferred_username="alice-renamed",
            email="alice@example.com",
            picture="https://example.com/b.png",
        )
    )

    assert created.id == updated.id
    assert updated.username == "alice-renamed"
    assert updated.avatar_url == "https://example.com/b.png"
    assert hook_calls == [
        HookCall(username="alice", sub="casdoor-sub-1"),
        HookCall(username="alice-renamed", sub="casdoor-sub-1"),
    ]


@pytest.mark.asyncio
async def test_sqlalchemy_provisioner_rejects_incompatible_model(db_sessionmaker) -> None:
    class BadUser(Base):
        __tablename__ = "bad_users"

        id: Mapped[int] = mapped_column(primary_key=True)
        username: Mapped[str] = mapped_column(String)

    with pytest.raises(ValueError, match="casdoor_sub"):
        SqlAlchemyProvisioner(db_sessionmaker, BadUser)


@pytest.mark.asyncio
async def test_sqlalchemy_provisioner_wraps_hook_errors(db_sessionmaker) -> None:
    provisioner = SqlAlchemyProvisioner(
        db_sessionmaker,
        UserModel,
        after_login=lambda session, user, claims: (_ for _ in ()).throw(RuntimeError("boom")),
    )

    with pytest.raises(UserProvisionError):
        await provisioner.provision_user(CasdoorClaims(sub="u-1"))
