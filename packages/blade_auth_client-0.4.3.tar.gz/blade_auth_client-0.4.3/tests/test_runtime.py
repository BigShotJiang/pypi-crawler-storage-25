from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pytest

from blade_auth_client.config import AuthConfig, OAuthConfig
from blade_auth_client.runtime import (
    clear_config,
    configure,
    get_config,
    get_cookie_name,
    get_cookie_secure,
    get_jwks_cache_ttl_seconds,
    get_oauth_client_id,
    get_oauth_client_secret,
    get_oauth_internal_endpoint,
    get_oauth_public_endpoint,
)


@dataclass
class _FakeURL:
    scheme: str = "https"
    netloc: str = "app.example.com"


@dataclass
class _FakeRequest:
    headers: dict[str, str]
    url: _FakeURL

    @classmethod
    def make(cls, host: str | None = "app.example.com", scheme: str = "https") -> "_FakeRequest":
        headers = {"host": host} if host else {}
        return cls(headers=headers, url=_FakeURL(scheme=scheme, netloc=host or ""))


@pytest.fixture(autouse=True)
def _reset_runtime() -> Any:
    clear_config()
    yield
    clear_config()


def test_get_config_raises_when_not_configured() -> None:
    with pytest.raises(RuntimeError, match="not configured"):
        get_config()


def test_get_accessors_return_values() -> None:
    config = AuthConfig(
        oauth=OAuthConfig(client_id="cid", client_secret="sec")
    )
    configure(config)

    assert get_oauth_client_id() == "cid"
    assert get_oauth_client_secret() == "sec"
    assert get_oauth_internal_endpoint() == "http://127.0.0.1:19000"
    assert get_cookie_name() == "blade_token"
    assert get_cookie_secure() is False
    assert get_jwks_cache_ttl_seconds() == 300


def test_get_oauth_public_endpoint_server_mode() -> None:
    config = AuthConfig(
        oauth=OAuthConfig(
            client_id="c",
            client_secret="s",
            deploy_mode="server",
            public_endpoint="https://sso.company.com/",
        )
    )
    configure(config)

    request = _FakeRequest.make(host="whatever.ignored")
    assert get_oauth_public_endpoint(request) == "https://sso.company.com"


def test_get_oauth_public_endpoint_box_mode_infers_from_host() -> None:
    config = AuthConfig(
        oauth=OAuthConfig(
            client_id="c",
            client_secret="s",
            deploy_mode="box",
            public_port=19000,
        )
    )
    configure(config)

    request = _FakeRequest.make(host="192.168.1.10:5000", scheme="http")
    assert get_oauth_public_endpoint(request) == "http://192.168.1.10:19000"


def test_get_oauth_public_endpoint_box_mode_falls_back_when_no_host() -> None:
    config = AuthConfig(
        oauth=OAuthConfig(
            client_id="c",
            client_secret="s",
            deploy_mode="box",
            public_port=19000,
            fallback_endpoint="http://fallback.local:19000/",
        )
    )
    configure(config)

    request = _FakeRequest(headers={}, url=_FakeURL(scheme="http", netloc=""))
    assert get_oauth_public_endpoint(request) == "http://fallback.local:19000"


def test_get_oauth_public_endpoint_box_mode_raises_when_no_host_no_fallback() -> None:
    config = AuthConfig(
        oauth=OAuthConfig(
            client_id="c",
            client_secret="s",
            deploy_mode="box",
        )
    )
    configure(config)

    request = _FakeRequest(headers={}, url=_FakeURL(scheme="http", netloc=""))
    with pytest.raises(RuntimeError, match="cannot infer public OAuth base"):
        get_oauth_public_endpoint(request)
