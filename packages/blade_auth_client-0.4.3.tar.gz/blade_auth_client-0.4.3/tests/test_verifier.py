from __future__ import annotations

from collections.abc import Awaitable, Callable
from datetime import timedelta

import httpx
import pytest

from blade_auth_client.errors import (
    ExpiredTokenError,
    InvalidTokenError,
    JwksUnavailableError,
)
from blade_auth_client.verifier.jwks_cache import JwksCache
from blade_auth_client.verifier.token_verifier import TokenVerifier


def build_http_client(
    *,
    jwks_responder: Callable[[httpx.Request, dict[str, int]], Awaitable[httpx.Response]],
) -> tuple[httpx.AsyncClient, dict[str, int]]:
    counts = {"jwks": 0}

    async def handler(request: httpx.Request) -> httpx.Response:
        url = str(request.url)
        if url == "http://casdoor.internal:19000/.well-known/jwks":
            counts["jwks"] += 1
            return await jwks_responder(request, counts)
        raise AssertionError(f"Unexpected request: {url}")

    return httpx.AsyncClient(transport=httpx.MockTransport(handler)), counts


@pytest.mark.asyncio
async def test_verify_accepts_valid_rs256_token(auth_config, oidc_discovery, rsa_keypair, issue_token) -> None:
    async def jwks_responder(_: httpx.Request, __: dict[str, int]) -> httpx.Response:
        return httpx.Response(200, json=rsa_keypair["jwks"])

    http_client, _ = build_http_client(jwks_responder=jwks_responder)
    verifier = TokenVerifier(auth_config, jwks_cache=JwksCache(auth_config, http_client=http_client))
    token = issue_token(
        rsa_keypair["private_key"],
        kid=rsa_keypair["kid"],
        issuer=oidc_discovery["issuer"],
        audience=[auth_config.casdoor_client_id],
    )

    claims = await verifier.verify(token)

    assert claims["sub"] == "user-123"
    assert claims["aud"] == [auth_config.casdoor_client_id]
    await http_client.aclose()


@pytest.mark.asyncio
async def test_verify_accepts_token_without_aud_claim(
    auth_config, oidc_discovery, rsa_keypair, issue_token
) -> None:
    async def jwks_responder(_: httpx.Request, __: dict[str, int]) -> httpx.Response:
        return httpx.Response(200, json=rsa_keypair["jwks"])

    http_client, _ = build_http_client(jwks_responder=jwks_responder)
    verifier = TokenVerifier(auth_config, jwks_cache=JwksCache(auth_config, http_client=http_client))
    token = issue_token(
        rsa_keypair["private_key"],
        kid=rsa_keypair["kid"],
        issuer=oidc_discovery["issuer"],
        audience=None,
    )

    claims = await verifier.verify(token)

    assert claims["sub"] == "user-123"
    assert "aud" not in claims

    await http_client.aclose()


@pytest.mark.asyncio
async def test_verify_rejects_expired_token(auth_config, oidc_discovery, rsa_keypair, issue_token) -> None:
    async def jwks_responder(_: httpx.Request, __: dict[str, int]) -> httpx.Response:
        return httpx.Response(200, json=rsa_keypair["jwks"])

    http_client, _ = build_http_client(jwks_responder=jwks_responder)
    verifier = TokenVerifier(auth_config, jwks_cache=JwksCache(auth_config, http_client=http_client))
    token = issue_token(
        rsa_keypair["private_key"],
        kid=rsa_keypair["kid"],
        issuer=oidc_discovery["issuer"],
        audience=[auth_config.casdoor_client_id],
        expires_in=timedelta(minutes=-5),
    )

    with pytest.raises(ExpiredTokenError):
        await verifier.verify(token)

    await http_client.aclose()


@pytest.mark.asyncio
async def test_verify_rejects_hs256_token(auth_config, oidc_discovery, rsa_keypair, issue_token) -> None:
    async def jwks_responder(_: httpx.Request, __: dict[str, int]) -> httpx.Response:
        return httpx.Response(200, json=rsa_keypair["jwks"])

    http_client, _ = build_http_client(jwks_responder=jwks_responder)
    verifier = TokenVerifier(auth_config, jwks_cache=JwksCache(auth_config, http_client=http_client))
    token = issue_token(
        rsa_keypair["private_key"],
        kid=rsa_keypair["kid"],
        issuer=oidc_discovery["issuer"],
        audience=[auth_config.casdoor_client_id],
        algorithm="HS256",
        secret="shared-secret-that-is-long-enough",
    )

    with pytest.raises(InvalidTokenError):
        await verifier.verify(token)

    await http_client.aclose()


@pytest.mark.asyncio
async def test_jwks_cache_respects_ttl(auth_config, oidc_discovery, rsa_keypair) -> None:
    now = {"value": 100.0}

    async def jwks_responder(_: httpx.Request, __: dict[str, int]) -> httpx.Response:
        return httpx.Response(200, json=rsa_keypair["jwks"])

    http_client, counts = build_http_client(jwks_responder=jwks_responder)
    cache = JwksCache(auth_config, http_client=http_client, clock=lambda: now["value"])

    first = await cache.get_jwks()
    second = await cache.get_jwks()
    now["value"] += auth_config.jwks_cache_ttl_seconds + 1
    third = await cache.get_jwks()

    assert first == second == third
    assert counts == {"jwks": 2}
    await http_client.aclose()


@pytest.mark.asyncio
async def test_jwks_refresh_failure_returns_stale_cache_and_logs_warning(
    auth_config, oidc_discovery, rsa_keypair, caplog
) -> None:
    now = {"value": 100.0}

    async def jwks_responder(_: httpx.Request, counts: dict[str, int]) -> httpx.Response:
        if counts["jwks"] == 1:
            return httpx.Response(200, json=rsa_keypair["jwks"])
        return httpx.Response(503, json={"message": "jwks unavailable"})

    http_client, _ = build_http_client(jwks_responder=jwks_responder)
    cache = JwksCache(auth_config, http_client=http_client, clock=lambda: now["value"])

    original = await cache.get_jwks()
    now["value"] += auth_config.jwks_cache_ttl_seconds + 1
    with caplog.at_level("WARNING"):
        fallback = await cache.get_jwks()

    assert fallback == original
    assert "Failed to refresh JWKS" in caplog.text
    await http_client.aclose()


@pytest.mark.asyncio
async def test_jwks_refresh_failure_without_cache_raises(auth_config, oidc_discovery) -> None:
    async def jwks_responder(_: httpx.Request, __: dict[str, int]) -> httpx.Response:
        return httpx.Response(503, json={"message": "jwks unavailable"})

    http_client, _ = build_http_client(jwks_responder=jwks_responder)
    cache = JwksCache(auth_config, http_client=http_client)

    with pytest.raises(JwksUnavailableError):
        await cache.get_jwks()

    await http_client.aclose()
