from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta
from typing import Any

import jwt
import pytest
from jwt.exceptions import (
    ExpiredSignatureError,
    InvalidAlgorithmError,
    InvalidTokenError as JwtInvalidTokenError,
    MissingRequiredClaimError,
    PyJWTError,
)

from blade_auth_client.errors import ExpiredTokenError, InvalidTokenError
from blade_auth_client.socketio import make_auth_middleware, socketio_auth
from blade_auth_client.users.provisioner import CasdoorClaims


@dataclass
class LocalUser:
    id: str
    username: str
    avatar_url: str | None = None


class RecordingProvisioner:
    def __init__(self) -> None:
        self.calls: list[CasdoorClaims] = []

    async def provision_user(self, claims: CasdoorClaims) -> LocalUser:
        self.calls.append(claims)
        return LocalUser(
            id=f"local-{claims.sub}",
            username=claims.preferred_username or claims.sub,
            avatar_url=claims.picture,
        )


class MockVerifier:
    def __init__(self, *, public_key: Any) -> None:
        self._public_key = public_key
        self.calls: list[str] = []

    async def verify(self, token: str) -> dict[str, Any]:
        self.calls.append(token)
        try:
            return jwt.decode(
                token,
                key=self._public_key,
                algorithms=["RS256"],
                options={"require": ["exp"], "verify_aud": False},
            )
        except ExpiredSignatureError as exc:
            raise ExpiredTokenError("Token has expired") from exc
        except MissingRequiredClaimError as exc:
            raise InvalidTokenError("Token claims are invalid") from exc
        except (InvalidAlgorithmError, JwtInvalidTokenError, PyJWTError) as exc:
            raise InvalidTokenError("Token is invalid") from exc


@pytest.mark.asyncio
async def test_socketio_auth_returns_user_for_valid_auth_token(
    auth_config, oidc_discovery, rsa_keypair, issue_token
) -> None:
    verifier = MockVerifier(
        public_key=rsa_keypair["public_key"],
    )
    provisioner = RecordingProvisioner()
    token = issue_token(
        rsa_keypair["private_key"],
        kid=rsa_keypair["kid"],
        issuer=oidc_discovery["issuer"],
        audience=[auth_config.casdoor_client_id],
        extra_claims={
            "sub": "user-from-auth",
            "preferred_username": "socket-auth-user",
            "picture": "https://example.com/avatar.png",
        },
    )

    user, resolved_token = await socketio_auth(
        verifier,
        provisioner,
        {},
        auth={"token": f"  {token}  "},
    )

    assert resolved_token == token
    assert user == LocalUser(
        id="local-user-from-auth",
        username="socket-auth-user",
        avatar_url="https://example.com/avatar.png",
    )
    assert provisioner.calls == [
        CasdoorClaims(
            sub="user-from-auth",
            preferred_username="socket-auth-user",
            picture="https://example.com/avatar.png",
        )
    ]
    assert verifier.calls == [token]


@pytest.mark.asyncio
async def test_auth_middleware_falls_back_to_cookie_token(
    auth_config, oidc_discovery, rsa_keypair, issue_token
) -> None:
    verifier = MockVerifier(
        public_key=rsa_keypair["public_key"],
    )
    provisioner = RecordingProvisioner()
    middleware = make_auth_middleware(verifier, provisioner)
    token = issue_token(
        rsa_keypair["private_key"],
        kid=rsa_keypair["kid"],
        issuer=oidc_discovery["issuer"],
        audience=[auth_config.casdoor_client_id],
        extra_claims={"sub": "cookie-user", "preferred_username": "from-cookie"},
    )

    user = await middleware(
        "sid-1",
        {"HTTP_COOKIE": f"{auth_config.cookie_name}={token}; another=value"},
        {},
    )

    assert user == LocalUser(
        id="local-cookie-user",
        username="from-cookie",
        avatar_url=None,
    )
    assert provisioner.calls == [
        CasdoorClaims(
            sub="cookie-user",
            preferred_username="from-cookie",
        )
    ]
    assert verifier.calls == [token]


@pytest.mark.asyncio
async def test_socketio_auth_returns_none_without_token(auth_config, oidc_discovery, rsa_keypair) -> None:
    verifier = MockVerifier(
        public_key=rsa_keypair["public_key"],
    )
    provisioner = RecordingProvisioner()
    middleware = make_auth_middleware(verifier, provisioner)

    user, token = await socketio_auth(verifier, provisioner, {}, auth=None)
    middleware_user = await middleware("sid-2", {}, None)

    assert (user, token) == (None, None)
    assert middleware_user is None
    assert provisioner.calls == []
    assert verifier.calls == []


@pytest.mark.asyncio
async def test_socketio_auth_rejects_expired_token(auth_config, oidc_discovery, rsa_keypair, issue_token) -> None:
    verifier = MockVerifier(
        public_key=rsa_keypair["public_key"],
    )
    provisioner = RecordingProvisioner()
    token = issue_token(
        rsa_keypair["private_key"],
        kid=rsa_keypair["kid"],
        issuer=oidc_discovery["issuer"],
        audience=[auth_config.casdoor_client_id],
        expires_in=timedelta(minutes=-5),
    )

    with pytest.raises(ExpiredTokenError):
        await socketio_auth(verifier, provisioner, {}, auth={"token": token})

    assert provisioner.calls == []


@pytest.mark.asyncio
async def test_socketio_auth_rejects_hs256_token(auth_config, oidc_discovery, rsa_keypair, issue_token) -> None:
    verifier = MockVerifier(
        public_key=rsa_keypair["public_key"],
    )
    provisioner = RecordingProvisioner()
    token = issue_token(
        rsa_keypair["private_key"],
        kid=rsa_keypair["kid"],
        issuer=oidc_discovery["issuer"],
        audience=[auth_config.casdoor_client_id],
        algorithm="HS256",
        secret="shared-secret-that-is-long-enough",
    )

    with pytest.raises(InvalidTokenError):
        await socketio_auth(verifier, provisioner, {}, auth={"token": token})

    assert provisioner.calls == []
