"""0.4.0 BladeAuth facade 测试。

覆盖:
- 构造 + router / require / current / socketio_handshake 基本可用
- provision_user / ensure_user 两种名字都跑(且 ensure_user 触发 warn 一次)
- cookie.domain 透传到 response Set-Cookie
- 顶层 import 老名字触发 DeprecationWarning,但值仍能正常取
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from blade_auth_client import BladeAuth
from blade_auth_client.config import AuthConfig
from blade_auth_client.users.provisioner import CasdoorClaims


@dataclass
class LocalUser:
    id: str
    username: str


class NewStyleProvisioner:
    """0.4.0 推荐写法:实现 provision_user。"""

    def __init__(self) -> None:
        self.calls: list[CasdoorClaims] = []

    async def provision_user(self, claims: CasdoorClaims) -> LocalUser:
        self.calls.append(claims)
        return LocalUser(id=f"local-{claims.sub}", username=claims.sub)


class LegacyProvisioner:
    """0.3.x 写法:只实现 ensure_user。0.4.0 仍兼容,但会 warn 一次。"""

    def __init__(self) -> None:
        self.calls: list[CasdoorClaims] = []

    async def ensure_user(self, claims: CasdoorClaims) -> LocalUser:
        self.calls.append(claims)
        return LocalUser(id=f"local-{claims.sub}", username=claims.sub)


@pytest.fixture
def config() -> AuthConfig:
    return AuthConfig(
        oauth={
            "client_id": "blade-client",
            "client_secret": "blade-secret",
            "internal_endpoint": "http://casdoor.internal:19000",
            "deploy_mode": "box",
            "public_port": 19000,
        }
    )


def test_bladeauth_basic_construction(config: AuthConfig) -> None:
    auth = BladeAuth(config, provisioner=NewStyleProvisioner())
    assert auth.config is config
    assert isinstance(auth.provisioner, NewStyleProvisioner)


def test_bladeauth_router_is_lazy_and_cached(config: AuthConfig) -> None:
    auth = BladeAuth(config, provisioner=NewStyleProvisioner())
    assert auth._router is None
    first = auth.router
    second = auth.router
    assert first is second  # lazy + cache
    # router 上确实挂了预期路由(/login, /logout, /me, /providers, /oauth/casdoor/callback)
    paths = {route.path for route in first.routes if hasattr(route, "path")}
    assert "/login" in paths
    assert "/logout" in paths
    assert "/me" in paths
    assert "/providers" in paths
    assert "/oauth/casdoor/callback" in paths


def test_bladeauth_require_and_current_are_cached(config: AuthConfig) -> None:
    auth = BladeAuth(config, provisioner=NewStyleProvisioner())
    r1 = auth.require()
    r2 = auth.require()
    assert r1 is r2

    c1 = auth.current()
    c2 = auth.current()
    assert c1 is c2
    assert r1 is not c1


def test_bladeauth_current_returns_none_for_anonymous_request(config: AuthConfig) -> None:
    auth = BladeAuth(config, provisioner=NewStyleProvisioner())
    app = FastAPI()

    @app.get("/maybe")
    def maybe(user: LocalUser | None = auth.current()) -> dict[str, object]:
        return {"user_id": user.id if user else None}

    client = TestClient(app)
    resp = client.get("/maybe")
    assert resp.status_code == 200
    assert resp.json() == {"user_id": None}


def test_bladeauth_require_returns_401_for_anonymous_request(config: AuthConfig) -> None:
    auth = BladeAuth(config, provisioner=NewStyleProvisioner())
    app = FastAPI()

    @app.get("/protected")
    def protected(user: LocalUser = auth.require()) -> dict[str, str]:
        return {"user_id": user.id}

    client = TestClient(app)
    resp = client.get("/protected")
    assert resp.status_code == 401


def test_legacy_ensure_user_still_called_and_warns(config: AuthConfig) -> None:
    """0.3.x 只定义 ensure_user 的 Provisioner 在 0.4.0 仍然工作,但触发 warn。"""
    import asyncio

    from blade_auth_client.users.provisioner import call_provision_user

    legacy = LegacyProvisioner()
    claims = CasdoorClaims(sub="test-sub-legacy-1", email="x@y")

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        user = asyncio.run(call_provision_user(legacy, claims))
        depr = [w for w in caught if issubclass(w.category, DeprecationWarning)]
        assert len(depr) == 1
        assert "ensure_user" in str(depr[0].message)

    assert user.id == "local-test-sub-legacy-1"
    assert legacy.calls == [claims]


def test_new_style_provision_user_no_warning(config: AuthConfig) -> None:
    """定义了 provision_user 的 Provisioner 不应该触发任何 deprecation。"""
    import asyncio

    from blade_auth_client.users.provisioner import call_provision_user

    pro = NewStyleProvisioner()
    claims = CasdoorClaims(sub="new-style-1", email="x@y")

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        user = asyncio.run(call_provision_user(pro, claims))
        depr = [w for w in caught if issubclass(w.category, DeprecationWarning)]
        assert depr == []

    assert user.id == "local-new-style-1"


def test_cookie_domain_is_passed_to_set_cookie() -> None:
    """cookie.domain 在 yaml 里配了的话,Set-Cookie 头必须带 Domain=..."""
    from fastapi import Response

    from blade_auth_client.cookie.policy import (
        clear_session_cookie,
        write_session_cookie,
    )

    config = AuthConfig(
        oauth={
            "client_id": "a",
            "client_secret": "b",
            "internal_endpoint": "http://x",
            "deploy_mode": "box",
        },
        cookie={
            "name": "blade_token",
            "domain": ".company.com",
        },
    )

    resp = Response()
    write_session_cookie(resp, "some-jwt", config)
    set_cookie = resp.headers.get("set-cookie", "")
    assert "blade_token=some-jwt" in set_cookie
    assert "Domain=.company.com" in set_cookie or "domain=.company.com" in set_cookie.lower()

    resp2 = Response()
    clear_session_cookie(resp2, config)
    set_cookie2 = resp2.headers.get("set-cookie", "")
    assert "Domain=.company.com" in set_cookie2 or "domain=.company.com" in set_cookie2.lower()


def test_deprecated_toplevel_import_warns_once_but_value_is_correct() -> None:
    """from blade_auth_client import create_auth_router 还能用,但要 warn。"""
    import blade_auth_client

    # 清掉前面测试里可能缓存过的 warn 记录
    blade_auth_client._warned.discard("create_auth_router")

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        value = blade_auth_client.create_auth_router
        depr = [w for w in caught if issubclass(w.category, DeprecationWarning)]
        assert len(depr) == 1
        assert "create_auth_router" in str(depr[0].message)
        assert "BladeAuth.router" in str(depr[0].message)

    # 再次访问不再 warn(每 process 每个名字只 warn 一次)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        _ = blade_auth_client.create_auth_router
        depr = [w for w in caught if issubclass(w.category, DeprecationWarning)]
        assert depr == []

    # 实际拿到的对象仍然是 fastapi.router 里的函数,能正常 call
    from blade_auth_client.fastapi.router import create_auth_router as real
    assert value is real


def test_bladeauth_in_public_namespace() -> None:
    """BladeAuth 是对外 6 个核心之一,必须在 __all__ 里。"""
    import blade_auth_client

    assert "BladeAuth" in blade_auth_client.__all__
    assert "AuthConfig" in blade_auth_client.__all__
    assert "LazyProvisioner" in blade_auth_client.__all__
    assert "CasdoorClaims" in blade_auth_client.__all__
    assert "SqlAlchemyProvisioner" in blade_auth_client.__all__


def test_version_is_04x() -> None:
    import blade_auth_client

    assert blade_auth_client.__version__.startswith("0.4.")
