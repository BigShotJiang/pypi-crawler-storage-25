from __future__ import annotations

import warnings
from pathlib import Path

import pytest
from pydantic import ValidationError
from pydantic_settings import SettingsConfigDict

from blade_auth_client.config import AuthConfig, OAuthConfig


def test_config_reads_env_without_prefix(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("CASDOOR_CLIENT_ID", "blade-client")
    monkeypatch.setenv("CASDOOR_CLIENT_SECRET", "blade-secret")
    monkeypatch.setenv("CASDOOR_ENDPOINT", "https://casdoor-public.example")
    monkeypatch.setenv("INTERNAL_CASDOOR_ENDPOINT", "http://casdoor.internal:19000")
    monkeypatch.setenv("PUBLIC_CASDOOR_PORT", "19000")
    monkeypatch.setenv("CALLBACK_BASE_URL", "https://blade.example/api/auth/callback")

    config = AuthConfig()

    assert config.oauth.client_id == "blade-client"
    assert config.oauth.fallback_endpoint == "https://casdoor-public.example"
    assert config.oauth.internal_endpoint == "http://casdoor.internal:19000"
    assert config.oauth.public_port == 19000
    assert config.cookie.name == "blade_token"
    assert config.cookie.same_site == "lax"
    assert config.cookie.secure is False
    assert config.jwks_cache_ttl_seconds == 300


def test_config_allows_prefixed_env(monkeypatch: pytest.MonkeyPatch) -> None:
    class PrefixedAuthConfig(AuthConfig):
        model_config = SettingsConfigDict(env_prefix="BLADE_AUTH_", extra="ignore")

    monkeypatch.setenv("BLADE_AUTH_CASDOOR_CLIENT_ID", "blade-client")
    monkeypatch.setenv("BLADE_AUTH_CASDOOR_CLIENT_SECRET", "blade-secret")
    monkeypatch.setenv("BLADE_AUTH_INTERNAL_CASDOOR_ENDPOINT", "http://127.0.0.1:19000")
    monkeypatch.setenv("BLADE_AUTH_PUBLIC_CASDOOR_PORT", "19000")

    config = PrefixedAuthConfig()

    assert config.oauth.client_id == "blade-client"
    assert config.oauth.internal_endpoint == "http://127.0.0.1:19000"
    assert config.cookie.name == "blade_token"


def test_config_requires_mandatory_fields(monkeypatch: pytest.MonkeyPatch) -> None:
    for name in (
        "CASDOOR_CLIENT_ID",
        "CASDOOR_CLIENT_SECRET",
        "CASDOOR_ENDPOINT",
        "INTERNAL_CASDOOR_ENDPOINT",
        "PUBLIC_CASDOOR_PORT",
        "CALLBACK_BASE_URL",
    ):
        monkeypatch.delenv(name, raising=False)
    with pytest.raises(ValidationError):
        AuthConfig()


def test_from_yaml_loads_nested(tmp_path: Path) -> None:
    yaml_text = """
oauth:
  client_id: yaml-client
  client_secret: yaml-secret
  internal_endpoint: http://yaml.internal:8000
  deploy_mode: box
  public_port: 19000
  fallback_endpoint: https://fallback.example
cookie:
  name: yaml_token
  secure: true
  same_site: none
jwks_cache_ttl_seconds: 600
callback_base_url: https://cb.example/callback
"""
    p = tmp_path / "oauth.yaml"
    p.write_text(yaml_text, encoding="utf-8")

    config = AuthConfig.from_yaml(p)

    assert config.oauth.client_id == "yaml-client"
    assert config.oauth.client_secret == "yaml-secret"
    assert config.oauth.internal_endpoint == "http://yaml.internal:8000"
    assert config.oauth.deploy_mode == "box"
    assert config.oauth.public_port == 19000
    assert config.oauth.fallback_endpoint == "https://fallback.example"
    assert config.cookie.name == "yaml_token"
    assert config.cookie.secure is True
    assert config.cookie.same_site == "none"
    assert config.jwks_cache_ttl_seconds == 600
    assert config.callback_base_url == "https://cb.example/callback"


def test_from_yaml_legacy_casdoor_top_key(tmp_path: Path) -> None:
    # 0.3.x 过渡：yaml 顶层 `casdoor:` 自动当 `oauth:` 处理，打一次 warn
    yaml_text = """
casdoor:
  client_id: legacy-client
  client_secret: legacy-secret
"""
    p = tmp_path / "oauth.yaml"
    p.write_text(yaml_text, encoding="utf-8")
    from blade_auth_client.config import _warned

    _warned.clear()
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        config = AuthConfig.from_yaml(p)
    assert config.oauth.client_id == "legacy-client"
    assert any(
        "yaml top-level key 'casdoor:' is deprecated" in str(w.message)
        for w in recorded
        if issubclass(w.category, DeprecationWarning)
    )


def test_from_yaml_server_mode_requires_public_endpoint(tmp_path: Path) -> None:
    yaml_text = """
oauth:
  client_id: c
  client_secret: s
  deploy_mode: server
"""
    p = tmp_path / "oauth.yaml"
    p.write_text(yaml_text, encoding="utf-8")

    with pytest.raises(ValidationError):
        AuthConfig.from_yaml(p)


def test_from_yaml_server_mode_ok(tmp_path: Path) -> None:
    yaml_text = """
oauth:
  client_id: c
  client_secret: s
  deploy_mode: server
  public_endpoint: https://sso.company.com
"""
    p = tmp_path / "oauth.yaml"
    p.write_text(yaml_text, encoding="utf-8")

    config = AuthConfig.from_yaml(p)
    assert config.oauth.deploy_mode == "server"
    assert config.oauth.public_endpoint == "https://sso.company.com"


def test_from_yaml_missing_file(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        AuthConfig.from_yaml(tmp_path / "nonexistent.yaml")


def test_legacy_flat_kwargs_still_work_with_warning(monkeypatch: pytest.MonkeyPatch) -> None:
    for name in list(
        {
            "CASDOOR_CLIENT_ID",
            "CASDOOR_CLIENT_SECRET",
            "CASDOOR_ENDPOINT",
            "INTERNAL_CASDOOR_ENDPOINT",
            "PUBLIC_CASDOOR_PORT",
            "CALLBACK_BASE_URL",
            "COOKIE_NAME",
            "COOKIE_SECURE",
            "COOKIE_SAME_SITE",
            "JWKS_CACHE_TTL_SECONDS",
        }
    ):
        monkeypatch.delenv(name, raising=False)

    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        config = AuthConfig(
            casdoor_client_id="flat-id",
            casdoor_client_secret="flat-secret",
            casdoor_endpoint="https://flat-endpoint",
            internal_casdoor_endpoint="http://flat-internal:19000",
            public_casdoor_port=8443,
            cookie_name="flat_cookie",
            cookie_secure=True,
            cookie_same_site="strict",
        )

    assert config.oauth.client_id == "flat-id"
    assert config.oauth.client_secret == "flat-secret"
    assert config.oauth.fallback_endpoint == "https://flat-endpoint"
    assert config.oauth.internal_endpoint == "http://flat-internal:19000"
    assert config.oauth.public_port == 8443
    assert config.cookie.name == "flat_cookie"
    assert config.cookie.secure is True
    assert config.cookie.same_site == "strict"
    dep = [w for w in recorded if issubclass(w.category, DeprecationWarning)]
    assert any("deprecated since blade-auth-client 0.3.0" in str(w.message) for w in dep)


def test_legacy_property_read_emits_warning(monkeypatch: pytest.MonkeyPatch) -> None:
    for name in list(
        {
            "CASDOOR_CLIENT_ID",
            "CASDOOR_CLIENT_SECRET",
            "CASDOOR_ENDPOINT",
            "INTERNAL_CASDOOR_ENDPOINT",
            "PUBLIC_CASDOOR_PORT",
            "CALLBACK_BASE_URL",
        }
    ):
        monkeypatch.delenv(name, raising=False)
    config = AuthConfig(
        oauth=OAuthConfig(client_id="a", client_secret="b")
    )
    from blade_auth_client.config import _warned

    _warned.clear()
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        _ = config.casdoor_client_id
    assert any(
        "AuthConfig.casdoor_client_id is deprecated" in str(w.message)
        for w in recorded
        if issubclass(w.category, DeprecationWarning)
    )


def test_legacy_casdoor_attr_alias(monkeypatch: pytest.MonkeyPatch) -> None:
    # config.casdoor 仍能读（代理到 config.oauth），带 warn
    for name in ("CASDOOR_CLIENT_ID", "CASDOOR_CLIENT_SECRET"):
        monkeypatch.delenv(name, raising=False)
    config = AuthConfig(oauth=OAuthConfig(client_id="a", client_secret="b"))
    from blade_auth_client.config import _warned

    _warned.clear()
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        assert config.casdoor is config.oauth
    assert any(
        "AuthConfig.casdoor is deprecated" in str(w.message)
        for w in recorded
        if issubclass(w.category, DeprecationWarning)
    )


def test_deploy_mode_defaults_to_box(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("CASDOOR_CLIENT_ID", "c")
    monkeypatch.setenv("CASDOOR_CLIENT_SECRET", "s")
    config = AuthConfig()
    assert config.oauth.deploy_mode == "box"
    assert config.oauth.public_port == 19000


def test_casdoor_config_alias_still_importable() -> None:
    # 0.3.x 仍能 import CasdoorConfig（等价 OAuthConfig），0.5.0 移除
    from blade_auth_client.config import CasdoorConfig

    assert CasdoorConfig is OAuthConfig
