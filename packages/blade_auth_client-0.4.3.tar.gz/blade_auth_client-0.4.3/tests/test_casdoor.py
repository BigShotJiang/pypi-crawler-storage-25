from __future__ import annotations

import httpx
import pytest
import respx

from blade_auth_client.casdoor.client import OidcClient
from blade_auth_client.errors import CasdoorError


@pytest.mark.asyncio
async def test_exchange_code_returns_access_token(auth_config, oidc_discovery) -> None:
    async with httpx.AsyncClient() as http_client:
        client = OidcClient(auth_config, http_client=http_client)
        with respx.mock(assert_all_called=True) as router:
            def _token_response(request: httpx.Request) -> httpx.Response:
                body = request.content.decode()
                assert "resource=" not in body
                assert "redirect_uri=https%3A%2F%2Fblade.example%2Fapi%2Fauth%2Foauth%2Fcasdoor%2Fcallback" in body
                return httpx.Response(200, json={"access_token": "access-token"})

            router.post(
                f"{auth_config.internal_casdoor_endpoint}/api/login/oauth/access_token"
            ).mock(side_effect=_token_response)

            token = await client.exchange_code("code-123", auth_config.callback_base_url)

    assert token == "access-token"


@pytest.mark.asyncio
async def test_exchange_code_detects_error_on_200(auth_config, oidc_discovery) -> None:
    async with httpx.AsyncClient() as http_client:
        client = OidcClient(auth_config, http_client=http_client)
        with respx.mock(assert_all_called=True) as router:
            router.post(
                f"{auth_config.internal_casdoor_endpoint}/api/login/oauth/access_token"
            ).mock(
                return_value=httpx.Response(
                    200,
                    json={"status": "error", "error": "invalid_grant", "msg": "bad authorization code"},
                )
            )

            with pytest.raises(CasdoorError, match="bad authorization code|invalid_grant"):
                await client.exchange_code("bad-code", auth_config.callback_base_url)
