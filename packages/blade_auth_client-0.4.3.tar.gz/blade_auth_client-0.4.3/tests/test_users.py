from __future__ import annotations

import warnings

import pytest

from blade_auth_client.users.provisioner import (
    CasdoorClaims,
    LazyProvisioner,
    call_provision_user,
)


class ExampleProvisioner:
    """0.4.0 推荐写法:实现 provision_user。"""

    async def provision_user(self, claims: CasdoorClaims) -> dict[str, str | None]:
        return {"sub": claims.sub, "email": claims.email}


class LegacyProvisioner:
    """0.3.x 写法:只实现 ensure_user。0.4.0 仍可被 SDK 调用,但 warn 一次。"""

    async def ensure_user(self, claims: CasdoorClaims) -> dict[str, str | None]:
        return {"sub": claims.sub, "email": claims.email}


@pytest.mark.asyncio
async def test_lazy_provisioner_protocol_is_structural() -> None:
    provisioner = ExampleProvisioner()
    claims = CasdoorClaims(sub="user-123", email="user@example.com")

    assert isinstance(provisioner, LazyProvisioner)
    assert await provisioner.provision_user(claims) == {
        "sub": "user-123",
        "email": "user@example.com",
    }


@pytest.mark.asyncio
async def test_legacy_ensure_user_works_via_call_provision_user() -> None:
    legacy = LegacyProvisioner()
    claims = CasdoorClaims(sub="legacy-1", email="x@y")

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        result = await call_provision_user(legacy, claims)
        depr = [w for w in caught if issubclass(w.category, DeprecationWarning)]
        assert len(depr) == 1

    assert result == {"sub": "legacy-1", "email": "x@y"}
