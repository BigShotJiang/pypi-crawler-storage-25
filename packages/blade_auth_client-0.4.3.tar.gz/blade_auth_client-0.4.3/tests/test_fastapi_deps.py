from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any

import httpx
import pytest
import respx
from fastapi import FastAPI, Request
from fastapi.testclient import TestClient

from blade_auth_client.config import AuthConfig
from blade_auth_client.fastapi.deps import authenticate_request, make_current_user_dep
from blade_auth_client.users.provisioner import CasdoorClaims
from blade_auth_client.verifier.jwks_cache import JwksCache
from blade_auth_client.verifier.token_verifier import TokenVerifier


@dataclass
class LocalUser:
    id: str
    username: str
    avatar_url: str | None = None


class RecordingProvisioner:
    def __init__(self) -> None:
        self.calls: list[CasdoorClaims] = []

    async def provision_user(self, claims: CasdoorClaims) -> LocalUser:
        self.calls.append(claims)
        return LocalUser(
            id=f"local-{claims.sub}",
            username=claims.preferred_username or claims.sub,
            avatar_url=claims.picture,
        )


@pytest.fixture
def fastapi_auth_config(auth_config: AuthConfig) -> AuthConfig:
    return auth_config.model_copy(update={"cookie_name": "blade_session"})


@pytest.fixture
def dependency_runtime(fastapi_auth_config: AuthConfig):
    jwks_http_client = httpx.AsyncClient()
    verifier = TokenVerifier(
        fastapi_auth_config,
        jwks_cache=JwksCache(fastapi_auth_config, http_client=jwks_http_client),
    )
    provisioner = RecordingProvisioner()
    current_user = make_current_user_dep(
        fastapi_auth_config,
        verifier=verifier,
        provisioner=provisioner,
    )

    app = FastAPI()

    @app.get("/current-user")
    async def current_user_endpoint(request: Request, user: Any = current_user) -> dict[str, Any]:
        if user is None:
            return {"id": None, "username": None, "token": None}

        return {
            "id": user.id,
            "username": user.username,
            "token": getattr(request.state, "blade_auth_token", None),
        }

    @app.get("/raw-auth")
    async def raw_auth_endpoint(request: Request) -> dict[str, Any]:
        result = await authenticate_request(
            request,
            fastapi_auth_config,
            verifier,
            provisioner,
            allow_query_token=True,
        )
        if result is None:
            return {"user": None}
        user, claims, token = result
        return {"user": user.id, "claims": claims.sub, "token": token}

    with TestClient(app) as client:
        yield {
            "client": client,
            "config": fastapi_auth_config,
            "provisioner": provisioner,
        }

    asyncio.run(jwks_http_client.aclose())


def test_current_user_returns_none_without_token(dependency_runtime) -> None:
    response = dependency_runtime["client"].get("/current-user")

    assert response.status_code == 200
    assert response.json() == {"id": None, "username": None, "token": None}


def test_current_user_prefers_bearer_token_over_cookie(
    dependency_runtime, oidc_discovery, rsa_keypair, issue_token
) -> None:
    config = dependency_runtime["config"]
    client = dependency_runtime["client"]
    bearer_token = issue_token(
        rsa_keypair["private_key"],
        kid=rsa_keypair["kid"],
        issuer=oidc_discovery["issuer"],
        audience=[config.casdoor_client_id],
        extra_claims={"sub": "bearer-user", "preferred_username": "from-bearer"},
    )
    cookie_token = issue_token(
        rsa_keypair["private_key"],
        kid=rsa_keypair["kid"],
        issuer=oidc_discovery["issuer"],
        audience=[config.casdoor_client_id],
        extra_claims={"sub": "cookie-user", "preferred_username": "from-cookie"},
    )
    client.cookies.set(config.cookie_name, cookie_token)

    with respx.mock(assert_all_called=True) as router:
        router.get("http://casdoor.internal:19000/.well-known/jwks").mock(
            return_value=httpx.Response(200, json=rsa_keypair["jwks"])
        )

        response = client.get(
            "/current-user",
            headers={"Authorization": f"Bearer {bearer_token}"},
        )

    assert response.status_code == 200
    assert response.json() == {
        "id": "local-bearer-user",
        "username": "from-bearer",
        "token": bearer_token,
    }


def test_authenticate_request_accepts_query_token(
    dependency_runtime, oidc_discovery, rsa_keypair, issue_token
) -> None:
    token = issue_token(
        rsa_keypair["private_key"],
        kid=rsa_keypair["kid"],
        issuer=oidc_discovery["issuer"],
        audience=[dependency_runtime["config"].casdoor_client_id],
        extra_claims={"sub": "query-user"},
    )

    with respx.mock(assert_all_called=True) as router:
        router.get("http://casdoor.internal:19000/.well-known/jwks").mock(
            return_value=httpx.Response(200, json=rsa_keypair["jwks"])
        )
        response = dependency_runtime["client"].get("/raw-auth", params={"token": token})

    assert response.status_code == 200
    assert response.json() == {
        "user": "local-query-user",
        "claims": "query-user",
        "token": token,
    }
