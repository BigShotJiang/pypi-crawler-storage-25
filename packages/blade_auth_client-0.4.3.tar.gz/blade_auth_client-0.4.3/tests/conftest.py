from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from typing import Any

import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa

from blade_auth_client.config import AuthConfig


def make_config(**overrides: Any) -> AuthConfig:
    data = {
        "casdoor_endpoint": "https://casdoor-public.example",
        "casdoor_client_id": "blade-client",
        "casdoor_client_secret": "blade-secret",
        "internal_casdoor_endpoint": "http://casdoor.internal:19000",
        "public_casdoor_port": 19000,
        "callback_base_url": "https://blade.example/api/auth/oauth/casdoor/callback",
    }
    data.update(overrides)
    return AuthConfig(**data)


@pytest.fixture
def auth_config() -> AuthConfig:
    return make_config()


@pytest.fixture
def oidc_discovery() -> dict[str, str]:
    return {
        "issuer": "https://issuer.example",
        "authorization_endpoint": "https://casdoor-public.example/login/oauth/authorize",
        "token_endpoint": "http://casdoor.internal:19000/api/login/oauth/access_token",
        "userinfo_endpoint": "https://casdoor-public.example/api/userinfo",
        "jwks_uri": "http://casdoor.internal:19000/.well-known/jwks",
    }


@pytest.fixture
def rsa_keypair() -> dict[str, Any]:
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    public_key = private_key.public_key()
    jwk = json.loads(jwt.algorithms.RSAAlgorithm.to_jwk(public_key))
    jwk["kid"] = "test-kid"
    jwk["use"] = "sig"
    jwk["alg"] = "RS256"
    return {
        "kid": "test-kid",
        "private_key": private_key,
        "public_key": public_key,
        "jwks": {"keys": [jwk]},
    }


@pytest.fixture
def issue_token():
    def _issue_token(
        private_key: Any,
        *,
        kid: str,
        issuer: str,
        audience: str | list[str] | None = None,
        expires_in: timedelta = timedelta(minutes=5),
        algorithm: str = "RS256",
        secret: str | None = None,
        extra_claims: dict[str, Any] | None = None,
    ) -> str:
        now = datetime.now(UTC)
        claims = {
            "sub": "user-123",
            "iss": issuer,
            "iat": now,
            "exp": now + expires_in,
        }
        if audience is not None:
            claims["aud"] = audience
        if extra_claims:
            claims.update(extra_claims)

        signing_key = secret if algorithm.startswith("HS") else private_key
        return jwt.encode(claims, signing_key, algorithm=algorithm, headers={"kid": kid})

    return _issue_token
