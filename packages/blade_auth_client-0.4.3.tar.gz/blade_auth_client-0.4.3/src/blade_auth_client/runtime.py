"""进程级 AuthConfig 单例 + 一组按字段名取值的访问器。

使用模式::

    from blade_auth_client import AuthConfig, configure
    from blade_auth_client.runtime import get_oauth_public_endpoint

    configure(AuthConfig.from_yaml("configs/oauth_config.yaml"))

    # 在业务代码任意处：
    endpoint = get_oauth_public_endpoint(request)

未 ``configure`` 就调用任何 ``get_*`` 会直接抛 RuntimeError。

命名说明：访问器统一用 ``get_oauth_*`` 前缀，而不是 ``get_casdoor_*``，
是为了让 SDK 对任意 OIDC provider 都保持通用命名。当前默认只对接
Casdoor，但字段语义（client_id / internal_endpoint / …）对任一
OIDC provider 都成立。
"""

from __future__ import annotations

from typing import Any

from .config import AuthConfig
from .fastapi.urls import hostname_from_host

_config: AuthConfig | None = None


def configure(config: AuthConfig) -> None:
    global _config
    _config = config


def get_config() -> AuthConfig:
    if _config is None:
        raise RuntimeError(
            "AuthConfig not configured. "
            "Call configure(AuthConfig.from_yaml(...)) during app startup."
        )
    return _config


def clear_config() -> None:
    """仅供测试使用。"""
    global _config
    _config = None


def get_oauth_client_id() -> str:
    return get_config().oauth.client_id


def get_oauth_client_secret() -> str:
    return get_config().oauth.client_secret


def get_oauth_internal_endpoint() -> str:
    return get_config().oauth.internal_endpoint


def get_oauth_public_endpoint(request: Any) -> str:
    """根据 deploy_mode 返回公开 OAuth provider base URL。

    - server：直接返回 public_endpoint（启动期 validator 保证非空）
    - box：从 request 推断 hostname + 拼 public_port
    """
    return _resolve_public_endpoint(request, get_config())


def get_cookie_name() -> str:
    return get_config().cookie.name


def get_cookie_secure() -> bool:
    return get_config().cookie.secure


def get_cookie_same_site() -> str:
    return get_config().cookie.same_site


def get_jwks_cache_ttl_seconds() -> int:
    return get_config().jwks_cache_ttl_seconds


def get_callback_base_url() -> str | None:
    return get_config().callback_base_url


def _resolve_public_endpoint(request: Any, config: AuthConfig) -> str:
    oauth = config.oauth
    if oauth.deploy_mode == "server":
        assert oauth.public_endpoint is not None  # validator 保证
        return oauth.public_endpoint.rstrip("/")

    # box 模式
    host: str | None = None
    headers = getattr(request, "headers", None)
    if headers is not None:
        host = headers.get("host")
    if not host:
        url = getattr(request, "url", None)
        host = getattr(url, "netloc", None) if url is not None else None

    if not host:
        if oauth.fallback_endpoint:
            return oauth.fallback_endpoint.rstrip("/")
        raise RuntimeError(
            "deploy_mode='box' cannot infer public OAuth base: "
            "no Host header and no oauth.fallback_endpoint configured"
        )

    scheme = "http"
    url = getattr(request, "url", None)
    if url is not None and getattr(url, "scheme", None):
        scheme = url.scheme

    hostname = hostname_from_host(host)
    if ":" in hostname and not hostname.startswith("["):
        netloc = f"[{hostname}]:{oauth.public_port}"
    else:
        netloc = f"{hostname}:{oauth.public_port}"
    return f"{scheme}://{netloc}"
