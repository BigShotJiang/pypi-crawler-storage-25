from __future__ import annotations

from typing import Any

from blade_auth_client.config import AuthConfig

DEFAULT_COOKIE_NAME = "blade_token"
COOKIE_PATH = "/"
COOKIE_HTTP_ONLY = True


def write_session_cookie(response: Any, token: str, config: AuthConfig) -> None:
    kwargs: dict[str, Any] = dict(
        key=config.cookie.name,
        value=token,
        httponly=COOKIE_HTTP_ONLY,
        path=COOKIE_PATH,
        samesite=config.cookie.same_site,
        secure=config.cookie.secure,
    )
    if config.cookie.domain:
        kwargs["domain"] = config.cookie.domain
    response.set_cookie(**kwargs)


def clear_session_cookie(response: Any, config: AuthConfig) -> None:
    kwargs: dict[str, Any] = dict(
        key=config.cookie.name,
        httponly=COOKIE_HTTP_ONLY,
        path=COOKIE_PATH,
        samesite=config.cookie.same_site,
        secure=config.cookie.secure,
    )
    if config.cookie.domain:
        kwargs["domain"] = config.cookie.domain
    response.delete_cookie(**kwargs)


def read_session_token(request: Any, config: AuthConfig | None = None) -> str | None:
    cookie_name = config.cookie.name if config is not None else DEFAULT_COOKIE_NAME
    cookies = getattr(request, "cookies", None) or {}
    return cookies.get(cookie_name)
