"""0.4.0 对外 facade:``BladeAuth``。

接入方只需构造一个 ``BladeAuth`` + 实现一个 ``LazyProvisioner``,
不再需要手动 new ``OidcClient`` / ``TokenVerifier`` / 调
``create_auth_router`` / ``make_require_auth_dep`` 等内部零件。
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from typing import Any, Generic, TypeVar

import httpx

from blade_auth_client.casdoor.client import OidcClient
from blade_auth_client.config import AuthConfig
from blade_auth_client.fastapi.deps import (
    _build_casdoor_claims,
    make_current_user_dep,
    make_require_auth_dep,
)
from blade_auth_client.fastapi.router import MeSerializer, create_auth_router
from blade_auth_client.mock import LocalCasdoor, MockJwksCache, MockOidcClient
from blade_auth_client.socketio.middleware import AuthMiddleware
from blade_auth_client.users.provisioner import (
    CasdoorClaims,
    LazyProvisioner,
    call_provision_user,
)
from blade_auth_client.verifier.token_verifier import TokenVerifier

LOGGER = logging.getLogger(__name__)
UserT = TypeVar("UserT")


class BladeAuth(Generic[UserT]):
    """SDK 对外 facade:一次构造,吐出 router / Depends / socketio 钩子。

    典型用法::

        auth = BladeAuth(
            AuthConfig.from_yaml("configs/oauth_config.yaml"),
            provisioner=MyProvisioner(),
        )

        app.include_router(auth.router, prefix="/api/v1/auth")

        @app.get("/me")
        def me(user = Depends(auth.require())):
            return user

    内部 lazy 构造:``router`` / ``require`` / ``current`` / socket
    middleware 第一次访问时才 build,避免 app 启动就强拉 JWKS。
    """

    def __init__(
        self,
        config: AuthConfig,
        *,
        provisioner: LazyProvisioner[UserT],
        me_serializer: MeSerializer | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._config = config
        self._provisioner = provisioner
        self._me_serializer = me_serializer

        # ---- mock 分流 ----------------------------------------------------
        # oauth.mock=true 时,在进程内内置一套"写死逻辑的 Casdoor"
        # (LocalCasdoor),把 HTTP 边界(JwksCache / OidcClient)替换成离线
        # 实现;TokenVerifier / deps / router 一律复用真代码路径,接入方
        # 业务代码 100% 感知不到。详见 docs/设计/设计-mock模式.md。
        if config.oauth.mock:
            self._local_casdoor: LocalCasdoor | None = LocalCasdoor(config)
            self._verifier = TokenVerifier(
                config, jwks_cache=MockJwksCache(self._local_casdoor)
            )
            self._oidc = MockOidcClient(self._local_casdoor)
            LOGGER.warning(
                "blade-auth-client running in MOCK mode (oauth.mock=true). "
                "In-process Casdoor will sign JWTs for mock_user.sub=%s. "
                "Do NOT use in production.",
                config.oauth.mock_user.sub if config.oauth.mock_user else "<?>",
            )
        else:
            self._local_casdoor = None
            self._verifier = TokenVerifier(config)
            self._oidc = OidcClient(config, http_client)

        # lazy 缓存
        self._router: Any | None = None
        self._require: Any | None = None
        self._current: Any | None = None
        self._socket_mw: AuthMiddleware[UserT] | None = None

    # -----------------------------------------------------------------
    # 属性
    # -----------------------------------------------------------------

    @property
    def config(self) -> AuthConfig:
        return self._config

    @property
    def provisioner(self) -> LazyProvisioner[UserT]:
        return self._provisioner

    @property
    def router(self) -> Any:
        """FastAPI ``APIRouter``,已注册 /login /callback /logout /me /providers。"""
        if self._router is None:
            self._router = create_auth_router(
                self._config,
                verifier=self._verifier,
                provisioner=self._provisioner,
                oidc_client=self._oidc,
                me_serializer=self._me_serializer,
                local_casdoor=self._local_casdoor,
            )
        return self._router

    # -----------------------------------------------------------------
    # FastAPI Depends 工厂(返回已 ``Depends()`` 包好的对象,handler 直接当默认值用)
    # -----------------------------------------------------------------

    def require(self) -> Any:
        """``Depends(...)``:没登录直接 401,handler 能拿到业务 user。"""
        if self._require is None:
            self._require = make_require_auth_dep(
                self._config,
                verifier=self._verifier,
                provisioner=self._provisioner,
            )
        return self._require

    def current(self) -> Any:
        """``Depends(...)``:可选登录,未登录返 ``None``。"""
        if self._current is None:
            self._current = make_current_user_dep(
                self._config,
                verifier=self._verifier,
                provisioner=self._provisioner,
            )
        return self._current

    # -----------------------------------------------------------------
    # Socket.IO 握手
    # -----------------------------------------------------------------

    def socketio_handshake(
        self,
    ) -> Callable[[str, dict[str, Any], Any], Awaitable[UserT | None]]:
        """返回可挂到 ``sio.on('connect', ...)`` 的 async callable。

        回调签名 ``(sid, environ, auth)`` → ``UserT | None``;未带合法 token
        时返回 ``None``,让业务层决定拒绝连接还是接匿名。
        """
        if self._socket_mw is None:
            self._socket_mw = AuthMiddleware(
                verifier=self._verifier,
                provisioner=self._provisioner,
                cookie_name=self._config.cookie.name,
            )
        return self._socket_mw

    # -----------------------------------------------------------------
    # 手动路径(少用,大多数场景走上面三个)
    # -----------------------------------------------------------------

    async def verify(self, token: str) -> CasdoorClaims:
        """只验 JWT 并拿 claims,不触发 ``provision_user``。"""
        payload = await self._verifier.verify(token)
        return _build_casdoor_claims(payload)

    async def provision(self, claims: CasdoorClaims) -> UserT:
        """直接调接入方的 ``provision_user`` / ``ensure_user``(兼容老名字)。"""
        return await call_provision_user(self._provisioner, claims)
