from __future__ import annotations

from typing import Any

import httpx

from blade_auth_client.config import AuthConfig
from blade_auth_client.errors import CasdoorError

TOKEN_PATH = "/api/login/oauth/access_token"


class OidcClient:
    def __init__(
        self,
        config: AuthConfig,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._config = config
        self._http_client = http_client or httpx.AsyncClient(timeout=10.0)

    async def exchange_code(
        self,
        code: str,
        redirect_uri: str,
    ) -> str:
        response = await self._http_client.post(
            f"{self._config.oauth.internal_endpoint.rstrip('/')}{TOKEN_PATH}",
            data={
                "grant_type": "authorization_code",
                "client_id": self._config.oauth.client_id,
                "client_secret": self._config.oauth.client_secret,
                "code": code,
                "redirect_uri": redirect_uri,
            },
        )
        payload = self._parse_casdoor_response(response)
        access_token = payload.get("access_token")
        if not isinstance(access_token, str) or not access_token:
            raise CasdoorError("Casdoor token response missing access_token")
        return access_token

    def _parse_casdoor_response(self, response: httpx.Response) -> dict[str, Any]:
        try:
            payload = response.json()
        except ValueError as exc:
            raise CasdoorError("Casdoor returned a non-JSON response") from exc

        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise CasdoorError(self._extract_error_message(payload)) from exc

        if not isinstance(payload, dict):
            raise CasdoorError("Casdoor returned an unexpected response payload")

        status = payload.get("status")
        error = payload.get("error")
        if status == "error" or error:
            raise CasdoorError(self._extract_error_message(payload))

        data = payload.get("data")
        if isinstance(data, dict):
            merged = dict(data)
            for key, value in payload.items():
                if key != "data" and key not in merged:
                    merged[key] = value
            return merged

        return payload

    @staticmethod
    def _extract_error_message(payload: Any) -> str:
        if not isinstance(payload, dict):
            return "Casdoor returned an error response"
        for key in ("error_description", "msg", "message", "error"):
            value = payload.get(key)
            if isinstance(value, str) and value:
                return value
        return "Casdoor returned an error response"
