from __future__ import annotations

from collections.abc import Mapping
from http.cookies import SimpleCookie
from typing import Any, Generic, TypeVar

from blade_auth_client.errors import InvalidTokenError
from blade_auth_client.users.provisioner import CasdoorClaims, LazyProvisioner, call_provision_user
from blade_auth_client.verifier.token_verifier import TokenVerifier

UserT = TypeVar("UserT")


class AuthMiddleware(Generic[UserT]):
    def __init__(
        self,
        verifier: TokenVerifier,
        provisioner: LazyProvisioner[UserT],
        cookie_name: str = "blade_token",
    ) -> None:
        self._verifier = verifier
        self._provisioner = provisioner
        self._cookie_name = cookie_name

    async def __call__(self, sid: str, environ: dict[str, Any], auth: Any | None) -> UserT | None:
        user, _ = await socketio_auth(
            self._verifier,
            self._provisioner,
            environ,
            auth=auth,
            cookie_name=self._cookie_name,
        )
        return user


async def socketio_auth(
    verifier: TokenVerifier,
    provisioner: LazyProvisioner[UserT],
    environ: Mapping[str, Any],
    *,
    auth: Any | None = None,
    cookie_name: str = "blade_token",
) -> tuple[UserT, str] | tuple[None, None]:
    token = _extract_socket_token(auth, environ, cookie_name=cookie_name)
    if token is None:
        return None, None

    claims = await verifier.verify(token)
    user = await call_provision_user(provisioner, _build_casdoor_claims(claims))
    return user, token


def make_auth_middleware(
    verifier: TokenVerifier,
    provisioner: LazyProvisioner[UserT],
    cookie_name: str = "blade_token",
) -> AuthMiddleware[UserT]:
    return AuthMiddleware(
        verifier=verifier,
        provisioner=provisioner,
        cookie_name=cookie_name,
    )


def _extract_socket_token(
    auth: Any | None,
    environ: Mapping[str, Any],
    *,
    cookie_name: str,
) -> str | None:
    if isinstance(auth, Mapping):
        raw_token = auth.get("token")
        if isinstance(raw_token, str):
            token = raw_token.strip()
            if token:
                return token

    raw_cookie = environ.get("HTTP_COOKIE")
    if not isinstance(raw_cookie, str) or not raw_cookie.strip():
        return None

    cookie = SimpleCookie()
    cookie.load(raw_cookie)
    morsel = cookie.get(cookie_name)
    if morsel is None:
        return None

    token = morsel.value.strip()
    return token or None


def _build_casdoor_claims(claims: Mapping[str, Any]) -> CasdoorClaims:
    sub = claims.get("sub")
    if not isinstance(sub, str) or not sub:
        raise InvalidTokenError("Token subject is invalid")

    return CasdoorClaims(
        sub=sub,
        email=_optional_string(claims.get("email")),
        preferred_username=_optional_string(claims.get("preferred_username")),
        name=_optional_string(claims.get("name") or claims.get("displayName")),
        picture=_optional_string(claims.get("picture") or claims.get("avatar")),
    )


def _optional_string(value: Any) -> str | None:
    if isinstance(value, str) and value:
        return value
    return None
