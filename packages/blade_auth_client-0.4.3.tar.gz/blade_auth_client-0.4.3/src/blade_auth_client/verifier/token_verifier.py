from __future__ import annotations

from typing import Any

import jwt
from jwt.exceptions import (
    ExpiredSignatureError,
    InvalidAlgorithmError,
    InvalidTokenError as JwtInvalidTokenError,
    MissingRequiredClaimError,
    PyJWTError,
)

from blade_auth_client.config import AuthConfig
from blade_auth_client.errors import ExpiredTokenError, InvalidTokenError
from blade_auth_client.verifier.jwks_cache import JwksCache


class TokenVerifier:
    def __init__(self, config: AuthConfig, jwks_cache: JwksCache | None = None) -> None:
        self._config = config
        self._jwks_cache = jwks_cache or JwksCache(config)

    async def prewarm(self) -> None:
        await self._jwks_cache.refresh()

    async def verify(self, token: str) -> dict[str, Any]:
        try:
            header = jwt.get_unverified_header(token)
            if header.get("alg") != "RS256":
                raise InvalidAlgorithmError("Token algorithm is invalid")
            signing_key = await self._jwks_cache.get_signing_key(token)
            return jwt.decode(
                token,
                key=signing_key,
                algorithms=["RS256"],
                options={"require": ["exp"], "verify_aud": False},
            )
        except ExpiredSignatureError as exc:
            raise ExpiredTokenError("Token has expired") from exc
        except MissingRequiredClaimError as exc:
            raise InvalidTokenError("Token claims are invalid") from exc
        except (InvalidAlgorithmError, JwtInvalidTokenError, PyJWTError) as exc:
            raise InvalidTokenError("Token is invalid") from exc


async def verify_token(token: str, *, verifier: TokenVerifier) -> dict[str, Any]:
    return await verifier.verify(token)
