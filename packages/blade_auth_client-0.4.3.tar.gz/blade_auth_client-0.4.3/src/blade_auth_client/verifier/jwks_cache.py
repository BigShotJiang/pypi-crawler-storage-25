from __future__ import annotations

import json
import logging
import time
from typing import Any, Callable

import httpx
import jwt

from blade_auth_client.config import AuthConfig
from blade_auth_client.errors import InvalidTokenError, JwksUnavailableError

LOGGER = logging.getLogger(__name__)
JWKS_PATH = "/.well-known/jwks"


class JwksCache:
    def __init__(
        self,
        config: AuthConfig,
        http_client: httpx.AsyncClient | None = None,
        *,
        clock: Callable[[], float] | None = None,
        logger: logging.Logger | None = None,
    ) -> None:
        self._config = config
        self._http_client = http_client or httpx.AsyncClient(timeout=10.0)
        self._clock = clock or time.monotonic
        self._logger = logger or LOGGER
        self._jwks: dict[str, Any] | None = None
        self._expires_at = 0.0

    async def get_jwks(self) -> dict[str, Any]:
        if self._jwks is not None and self._clock() < self._expires_at:
            return self._jwks

        return await self.refresh()

    async def get_signing_key(self, token: str) -> Any:
        try:
            header = jwt.get_unverified_header(token)
        except jwt.PyJWTError as exc:
            raise InvalidTokenError("Token header is invalid") from exc

        kid = header.get("kid")
        if not isinstance(kid, str) or not kid:
            raise InvalidTokenError("Token header missing kid")

        jwks = await self.get_jwks()
        key = self._find_key(jwks, kid)
        if key is not None:
            return key

        # Casdoor 可能在 TTL 窗口内轮换 kid；本地缓存未命中时强制刷新一次再查，避免
        # 在 jwks_cache_ttl_seconds 内登录全部失败
        jwks = await self.refresh()
        key = self._find_key(jwks, kid)
        if key is not None:
            return key

        raise InvalidTokenError("Unable to find signing key for token")

    @staticmethod
    def _find_key(jwks: dict[str, Any], kid: str) -> Any | None:
        for key_data in jwks.get("keys", []):
            if key_data.get("kid") == kid:
                return jwt.algorithms.RSAAlgorithm.from_jwk(json.dumps(key_data))
        return None

    async def refresh(self) -> dict[str, Any]:
        try:
            response = await self._http_client.get(
                f"{self._config.oauth.internal_endpoint.rstrip('/')}{JWKS_PATH}"
            )
            response.raise_for_status()
            payload = response.json()
            if not isinstance(payload, dict) or not isinstance(payload.get("keys"), list):
                raise ValueError("JWKS payload is missing keys")
        except Exception as exc:
            if self._jwks is not None:
                self._logger.warning("Failed to refresh JWKS, falling back to cached keys", exc_info=exc)
                return self._jwks
            raise JwksUnavailableError("Unable to fetch JWKS") from exc

        self._jwks = payload
        self._expires_at = self._clock() + self._config.jwks_cache_ttl_seconds
        return payload
