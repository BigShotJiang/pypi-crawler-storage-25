"""进程内的 "写死逻辑的 Casdoor"。

``LocalCasdoor`` 在 ``BladeAuth.__init__`` 里 new 一次，``mint_token()`` 用一份
**硬编码进 SDK 源码的 RSA keypair**（见下方 ``_MOCK_PRIVATE_PEM``）签真 RS256
JWT；``jwks()`` / ``public_key`` 把对应公钥喂给 ``MockJwksCache``。

**为什么硬编码 keypair？**
0.4.1 是每个进程独立生成 keypair，导致跨进程互相不认（blade-agent 进程发的
JWT 在 skill-registry 进程验签 401）。0.4.2 起改成同一份常量 keypair，所有
mock 模式服务默认互认 —— 多服务 SSO 在 mock 下也成立，零配置。

**安全语义**
mock 模式只用于本地开发 / CI / demo（生产禁用），私钥进 SDK 源码完全 OK：
任何能跑 mock 的服务都已经在签自己的 mock JWT 了，私钥泄露并不放大风险。
prod 走真 Casdoor，那条路径根本不会用到这个常量。
"""

from __future__ import annotations

import base64
from datetime import UTC, datetime
from typing import Any

import jwt
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

from blade_auth_client.config import AuthConfig

MOCK_ISSUER = "mock://local-casdoor"
MOCK_KID = "blade-auth-client-mock"

# -----------------------------------------------------------------
# 硬编码 mock keypair（0.4.2+）
# 这一份私钥仅供 mock 模式签 JWT；任何 mock 模式服务都用这同一份 keypair，
# 因此 service A 签的 JWT，service B 也能用 SDK 内置的 jwks 验签 —— 跨服务
# 互认在 mock 下默认成立。**永远不要在生产走 mock 路径**。
# -----------------------------------------------------------------
_MOCK_PRIVATE_PEM = b"""\
-----BEGIN PRIVATE KEY-----
MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCb6nW4wl662GDc
8fVgdbQp3iEaEXLlZKe/QFtwXRWjeZ3fCkV9uFOdPz2+oianuJkQJRr1FYv8qu30
bwrzV/q5m3WhumEFSQ4qH8T+53KCLpegv6z7VbZq5xqZKdord81qRUF9/Q5Z9UkE
DlApiFe22utYlfOTNrMf6QnDxVJqzP4EJOc2HDQAATfVS5h+CnEATD2fsR40hmmA
jpmlPihi/QUtREtslDB4lpGpkJrVXb7P9sCvI3RcDNKg8h2Y++jNY7kLGvfYAl5a
L+9VAiO7+u+w/5cbuu/I9bqcdThZ6xDLwBJfvDVFJ+gKWuU4lAzWlBIU+E9KdO0p
K//WEoenAgMBAAECggEAEtDfthVW40ubnO5iQ2rQ/EB/VCsI56AXEmCM6GmDZAAY
SkNuEXb+ODrak7fz3EfNyQIBV9Rq2WozX01LUAStEFsvff4FGWMwn2rIFk8OJaHD
0LVxBb/ZTNto/VTsrFQ/6PRErBSu97I/RosHp4t5smqG/mDSTVDLmy0/bW3RvWuh
XE6O4bRtWlHG1s9tR+4vc//ITz5sVJNwoQbxLWuFPOtfAeHFDg6H/tc311NvyZSl
/8gdIrinpf51OHZaS/+Fd0BkhMAtjPpcoLxst+UG/6Ag5ceIkv+kVwxopvRsReaN
XglFTCV7cWoNMEVYA+YopHhhUOfgBeWl4r8lZhqFkQKBgQDXcx4fNCNinBVSha+I
TfwfygtkMIosQKn05mXOM/sqhnzMGHL+3CTnbZ2+g7T5ojqH4S6HtP0IcStzJClg
h5aSwHH3BqiJ0Jk/pe6CaeR41dnZ8MVW3p3qjACWbGLMKtpl8L5oskRNzGq0k97v
T+wPMNgapZttQsK4qiH9/5QGfwKBgQC5Qtwlcjb+z6N7pGfZs1OCDK9YJ6CIqK1i
r/1JBO9lS7sJ0MlvhwdqA5XJ1zG5s7CcyBDsl/OoARTdJLEVz2cqhc/Po8XlyUQ7
o1uQcsd5e+SKHhTSZW/niL1ZKakfGs7rP8fHFjgOFxnBKQrTEqHSxYTh/33/dcp8
/PuQ9j/62QKBgA4enj+/Q/5nakJRPpK5Qae3rw1u3O9PgZPqMYvU/kXoMG+Tvp2T
Qdvk5CyjJw4hIqLbEBiWtOqDuCxAl3GbETQm5pEg35TAlfqE3l+vnuiIY1GUJOqv
hjvj1voEumjU+iEqKOBlpnJOzkNtWXPnkfng4pjEd64ubOJ7S+UAhevzAoGALnNF
H15zy4/kPawLHdqIpaLolAHbjmg8kPHvX8+M9qj2TI+88em5QiuD8wexwA39ylGf
bLLstMMQqCH7BKzsAQ1r/XPiuqqsIQfkfWNKAHu/4aGJNveYB0WRtDlt3g6qsvFa
9d/sThwcqQHRZPrW+DHuD3wv601tZ8lGiiI0CIECgYEAmOdM4OTjznbXBaO8qMhd
mfx3TPwCxLaz5KUqYOwfn/b0WQH8O1G/l4WTCgQfoavZ4drxoZxS5Vxn7RFPYAZd
JWmBO6ZCQD4xP/mmk0PhD7kFH13DPIpDL7qewa4C+k4QxZILlyIQJ42IyImJd7Ka
xBy2i3C5O4rv8v4twt0oLUw=
-----END PRIVATE KEY-----
"""


def _load_mock_private_key() -> rsa.RSAPrivateKey:
    key = serialization.load_pem_private_key(_MOCK_PRIVATE_PEM, password=None)
    if not isinstance(key, rsa.RSAPrivateKey):
        raise RuntimeError("embedded mock keypair must be RSA")
    return key


# 模块级缓存：进程内只 parse 一次 PEM
_MOCK_PRIVATE_KEY: rsa.RSAPrivateKey = _load_mock_private_key()
_MOCK_PRIVATE_PEM_STR: str = _MOCK_PRIVATE_PEM.decode("ascii")


class LocalCasdoor:
    def __init__(self, config: AuthConfig) -> None:
        self._config = config
        self._private_key: rsa.RSAPrivateKey = _MOCK_PRIVATE_KEY
        self._public_key: rsa.RSAPublicKey = self._private_key.public_key()
        self._private_pem: str = _MOCK_PRIVATE_PEM_STR

    @property
    def public_key(self) -> rsa.RSAPublicKey:
        """给 ``MockJwksCache.get_signing_key`` 直接返回的 ``cryptography`` key 对象。"""
        return self._public_key

    def mint_token(self, *, expires_in_seconds: int = 3600) -> str:
        """按 ``config.oauth.mock_user`` 签一个真 RS256 JWT，形状跟
        Casdoor 签的一模一样 —— ``TokenVerifier`` 拿到就验签/查 exp/正常跑。
        """
        user = self._config.oauth.mock_user
        if user is None:  # model_validator 应该拦住这种情况，这里双保险
            raise RuntimeError("LocalCasdoor requires oauth.mock_user")

        now = datetime.now(UTC)
        claims: dict[str, Any] = {
            "sub": user.sub,
            "iss": MOCK_ISSUER,
            "aud": self._config.oauth.client_id,
            "iat": int(now.timestamp()),
            "exp": int(now.timestamp()) + expires_in_seconds,
        }
        if user.email is not None:
            claims["email"] = user.email
        if user.name is not None:
            claims["name"] = user.name
        if user.preferred_username is not None:
            claims["preferred_username"] = user.preferred_username
        if user.picture is not None:
            claims["picture"] = user.picture

        return jwt.encode(
            claims,
            self._private_pem,
            algorithm="RS256",
            headers={"kid": MOCK_KID},
        )

    def jwks(self) -> dict[str, Any]:
        """返回 JWKS (JSON Web Key Set) 形态，给 ``MockJwksCache.refresh`` 用。"""
        numbers = self._public_key.public_numbers()
        return {
            "keys": [
                {
                    "kty": "RSA",
                    "kid": MOCK_KID,
                    "use": "sig",
                    "alg": "RS256",
                    "n": _b64url_uint(numbers.n),
                    "e": _b64url_uint(numbers.e),
                }
            ]
        }


def _b64url_uint(value: int) -> str:
    byte_length = (value.bit_length() + 7) // 8
    raw = value.to_bytes(byte_length, "big")
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")
