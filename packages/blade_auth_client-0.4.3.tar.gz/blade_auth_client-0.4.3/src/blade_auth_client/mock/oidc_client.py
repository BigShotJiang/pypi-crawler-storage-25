"""MockOidcClient: 替代真 ``OidcClient``,exchange_code 不发 HTTP,直接
委托 ``LocalCasdoor.mint_token``。

真实的 /oauth/casdoor/callback 路径如果被手动访问(比如测试里直接 GET),
这里也能原路跑通:回一个真 JWT,callback handler 的 verify / provisioner
调用全部按 prod 路径走。
"""

from __future__ import annotations

from .local_casdoor import LocalCasdoor


class MockOidcClient:
    def __init__(self, local: LocalCasdoor) -> None:
        self._local = local

    async def exchange_code(self, code: str, redirect_uri: str) -> str:  # noqa: ARG002
        return self._local.mint_token()
