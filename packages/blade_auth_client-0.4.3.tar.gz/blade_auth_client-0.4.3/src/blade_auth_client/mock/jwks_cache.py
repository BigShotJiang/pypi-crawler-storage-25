"""MockJwksCache: 替代真 ``JwksCache``,不打 HTTP,直接返回 ``LocalCasdoor``
的公钥。

对 ``TokenVerifier`` 完全透明 —— 它按真 JwksCache 接口调用,只是 refresh/
get_signing_key 不走网络。
"""

from __future__ import annotations

from typing import Any

from .local_casdoor import LocalCasdoor


class MockJwksCache:
    def __init__(self, local: LocalCasdoor) -> None:
        self._local = local

    async def refresh(self) -> dict[str, Any]:
        return self._local.jwks()

    async def get_jwks(self) -> dict[str, Any]:
        return self._local.jwks()

    async def get_signing_key(self, token: str) -> Any:  # noqa: ARG002
        return self._local.public_key
