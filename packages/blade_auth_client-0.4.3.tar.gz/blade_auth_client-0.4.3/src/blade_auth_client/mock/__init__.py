"""Mock 模式内部实现。

对外暴露的只有 ``AuthConfig.oauth.mock`` / ``AuthConfig.oauth.mock_user``
两个 yaml 字段 —— BladeAuth 在构造时读到 ``mock=True`` 就自己装配下面这
几个类,接入方业务代码 100% 感知不到。

详见 ``docs/设计/设计-mock模式.md``。
"""

from .local_casdoor import LocalCasdoor
from .oidc_client import MockOidcClient
from .jwks_cache import MockJwksCache

__all__ = ["LocalCasdoor", "MockOidcClient", "MockJwksCache"]
