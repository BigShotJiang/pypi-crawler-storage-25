from __future__ import annotations

import os
import warnings
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

_DEPRECATION_SINCE = "blade-auth-client 0.3.0"
_DEPRECATION_REMOVAL = "0.5.0"

_warned: set[str] = set()


def _warn_once(key: str, old: str, new: str) -> None:
    if key in _warned:
        return
    _warned.add(key)
    warnings.warn(
        f"{old} is deprecated since {_DEPRECATION_SINCE}, use {new} instead; "
        f"will be removed in {_DEPRECATION_REMOVAL}",
        DeprecationWarning,
        stacklevel=3,
    )


class MockUserConfig(BaseModel):
    """``oauth.mock=true`` 时，本地 "写死逻辑的 Casdoor" 会按这份 claims
    签发 JWT。``sub`` 是 OAuth provider 侧的稳定用户 id（provisioner 以这个
    做本地 user 绑定 key），其它字段对应 ``CasdoorClaims`` 的标准 OIDC 字段。
    """

    sub: str = Field(...)
    email: str | None = None
    name: str | None = None
    preferred_username: str | None = None
    picture: str | None = None
    # 0.4.3+：仅当 ``oauth.mock_login_page=true`` 时使用，登录页比对用户输入的密码
    password: str | None = None


class OAuthConfig(BaseModel):
    """通用 OAuth provider 配置。当前 SDK 只对接 Casdoor，但字段命名对任一 OIDC
    provider 都成立（client_id / secret / JWKS / token endpoint / …）。

    设了 ``extra="allow"``：接入方可以在 ``oauth:`` 下塞 SDK 用不到、但自己要用
    的 provider 专属字段（如 Casdoor 的 organization / application / builtin
    credentials），SDK 会保留并可通过 ``config.oauth.<field>`` 读。
    """

    model_config = ConfigDict(extra="allow")

    client_id: str = Field(...)
    client_secret: str = Field(...)

    # 服务端访问 provider 的地址（JWKS + token 交换）
    internal_endpoint: str = "http://127.0.0.1:19000"

    # 公开 URL 推断开关
    # - server: 直接用 public_endpoint，不做推断
    # - box:    从 request Host header 取 hostname，拼 public_port
    deploy_mode: Literal["server", "box"] = "box"
    public_endpoint: str | None = None
    public_port: int = 19000

    # box 模式下无 Host header 可用时的兜底 URL
    fallback_endpoint: str | None = None

    # ---------- mock 模式（0.4.1+）----------
    # mock=true 时，SDK 在进程内内置一套 "写死逻辑的 Casdoor"：用一份硬编码进
    # SDK 源码的 RSA keypair（见 mock/local_casdoor.py）签 mock_user 的 RS256
    # JWT。/login 短路直接 302 + 写 cookie，浏览器不会跳真 Casdoor。
    # 0.4.2+ 起 keypair 是常量 —— 多服务（blade-agent + skill-registry + …）
    # 用 mock 时默认互认，不用配共享文件路径。DO NOT use in production。
    mock: bool = False
    mock_user: MockUserConfig | None = None
    # 0.4.3+：mock 模式下是否展示一个静态登录页（表单输用户名 + 密码，命中
    # mock_user.preferred_username|email + mock_user.password 才发 cookie）。
    # 默认 false 维持 0.4.1 的"秒登"行为；启用时 mock_user.password 必填。
    mock_login_page: bool = False

    @model_validator(mode="after")
    def _check_server_mode(self) -> "OAuthConfig":
        if self.deploy_mode == "server" and not self.public_endpoint:
            raise ValueError(
                "oauth.deploy_mode='server' requires oauth.public_endpoint"
            )
        return self

    @model_validator(mode="after")
    def _check_mock_consistency(self) -> "OAuthConfig":
        if self.mock and self.mock_user is None:
            raise ValueError(
                "oauth.mock=true requires oauth.mock_user (at minimum: mock_user.sub)"
            )
        if self.mock_login_page:
            if not self.mock:
                raise ValueError(
                    "oauth.mock_login_page=true requires oauth.mock=true"
                )
            if self.mock_user is not None and not self.mock_user.password:
                raise ValueError(
                    "oauth.mock_login_page=true requires mock_user.password"
                )
        return self


# 向后兼容名字，旧代码 import CasdoorConfig 还能工作（内部其实就是 OAuthConfig）
CasdoorConfig = OAuthConfig


class CookieConfig(BaseModel):
    name: str = "blade_token"
    secure: bool = False
    same_site: Literal["lax", "strict", "none"] = "lax"
    # 父域 SSO 场景把 cookie 写到共享父域（如 ".company.com"），这样多个 app
    # 的子域会共享同一份 cookie,用户登一次全通。默认 None 即不写 Domain 属性,
    # 浏览器按 "当前 origin 精确匹配" 存 cookie,每个子域各自独立。
    domain: str | None = None


# 老的平铺 env 名 → 新嵌套路径
_LEGACY_ENV_MAP: dict[str, tuple[str, ...]] = {
    "CASDOOR_CLIENT_ID": ("oauth", "client_id"),
    "CASDOOR_CLIENT_SECRET": ("oauth", "client_secret"),
    "CASDOOR_ENDPOINT": ("oauth", "fallback_endpoint"),
    "INTERNAL_CASDOOR_ENDPOINT": ("oauth", "internal_endpoint"),
    "PUBLIC_CASDOOR_PORT": ("oauth", "public_port"),
    "COOKIE_NAME": ("cookie", "name"),
    "COOKIE_SECURE": ("cookie", "secure"),
    "COOKIE_SAME_SITE": ("cookie", "same_site"),
    "JWKS_CACHE_TTL_SECONDS": ("jwks_cache_ttl_seconds",),
    "CALLBACK_BASE_URL": ("callback_base_url",),
}

# 老的平铺 kwarg 名 → 新嵌套路径
_LEGACY_KWARG_MAP: dict[str, tuple[str, ...]] = {
    "casdoor_client_id": ("oauth", "client_id"),
    "casdoor_client_secret": ("oauth", "client_secret"),
    "casdoor_endpoint": ("oauth", "fallback_endpoint"),
    "internal_casdoor_endpoint": ("oauth", "internal_endpoint"),
    "public_casdoor_port": ("oauth", "public_port"),
    "cookie_name": ("cookie", "name"),
    "cookie_secure": ("cookie", "secure"),
    "cookie_same_site": ("cookie", "same_site"),
}

# 0.3.x 过渡：yaml 里写 `casdoor:` 当时也当 `oauth:` 处理，warn 一次。
# 0.5.0 移除。
_LEGACY_YAML_TOP_KEY = "casdoor"


def _set_nested(data: dict[str, Any], path: tuple[str, ...], value: Any) -> None:
    """Set data[path[0]][path[1]]... = value，只在最终叶子未被显式设置时写入。"""
    if len(path) == 1:
        if path[0] not in data:
            data[path[0]] = value
        return

    sub = data.get(path[0])
    if sub is None:
        data[path[0]] = {}
        sub = data[path[0]]
    elif isinstance(sub, BaseModel):
        return
    elif not isinstance(sub, dict):
        return

    if path[1] not in sub:
        sub[path[1]] = value


def _translate_legacy_kwargs(data: dict[str, Any]) -> dict[str, Any]:
    result = dict(data)

    # yaml 顶层 `casdoor:` → `oauth:`（0.3.x 兼容，0.5.0 删）
    if _LEGACY_YAML_TOP_KEY in result and "oauth" not in result:
        _warn_once(
            f"yaml-key:{_LEGACY_YAML_TOP_KEY}",
            f"yaml top-level key '{_LEGACY_YAML_TOP_KEY}:'",
            "yaml top-level key 'oauth:'",
        )
        result["oauth"] = result.pop(_LEGACY_YAML_TOP_KEY)

    for flat_key, path in _LEGACY_KWARG_MAP.items():
        if flat_key not in result:
            continue
        value = result.pop(flat_key)
        _warn_once(
            f"kwarg:{flat_key}",
            f"AuthConfig kwarg '{flat_key}'",
            ".".join(path),
        )
        _set_nested(result, path, value)
    return result


def _merge_legacy_env(data: dict[str, Any], env_prefix: str) -> dict[str, Any]:
    result = dict(data)
    for flat_env, path in _LEGACY_ENV_MAP.items():
        full_name = f"{env_prefix}{flat_env}"
        if full_name not in os.environ:
            continue
        value = os.environ[full_name]
        if _is_already_set(result, path):
            continue
        _warn_once(
            f"env:{full_name}",
            f"environment variable '{full_name}'",
            f"yaml field '{'.'.join(path)}' (via AuthConfig.from_yaml)",
        )
        _set_nested(result, path, value)
    return result


def _is_already_set(data: dict[str, Any], path: tuple[str, ...]) -> bool:
    cur: Any = data
    for key in path:
        if isinstance(cur, BaseModel):
            return True
        if not isinstance(cur, dict):
            return False
        if key not in cur:
            return False
        cur = cur[key]
    return True


class AuthConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="", extra="ignore")

    oauth: OAuthConfig
    cookie: CookieConfig = Field(default_factory=CookieConfig)
    jwks_cache_ttl_seconds: int = 300
    callback_base_url: str | None = None

    def __init__(self, **data: Any) -> None:
        data = _translate_legacy_kwargs(data)
        env_prefix = type(self).model_config.get("env_prefix", "") or ""
        data = _merge_legacy_env(data, env_prefix)
        super().__init__(**data)

    @classmethod
    def from_yaml(cls, path: str | Path) -> "AuthConfig":
        try:
            import yaml
        except ImportError as exc:
            raise RuntimeError(
                "AuthConfig.from_yaml requires pyyaml; install blade-auth-client with extras or `pip install pyyaml`"
            ) from exc

        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"oauth config yaml not found: {p}")

        raw = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        if not isinstance(raw, dict):
            raise ValueError(
                f"oauth config yaml must be a mapping at top level, got {type(raw).__name__}"
            )
        return cls(**raw)

    # ----- 向后兼容：.casdoor 当 .oauth 的别名，带 warn -----

    @property
    def casdoor(self) -> OAuthConfig:
        _warn_once(
            "attr:casdoor",
            "AuthConfig.casdoor",
            "AuthConfig.oauth",
        )
        return self.oauth

    # ----- 向后兼容：平铺字段作为 @property 代理 -----

    @property
    def casdoor_client_id(self) -> str:
        _warn_once(
            "attr:casdoor_client_id",
            "AuthConfig.casdoor_client_id",
            "AuthConfig.oauth.client_id",
        )
        return self.oauth.client_id

    @property
    def casdoor_client_secret(self) -> str:
        _warn_once(
            "attr:casdoor_client_secret",
            "AuthConfig.casdoor_client_secret",
            "AuthConfig.oauth.client_secret",
        )
        return self.oauth.client_secret

    @property
    def casdoor_endpoint(self) -> str | None:
        _warn_once(
            "attr:casdoor_endpoint",
            "AuthConfig.casdoor_endpoint",
            "AuthConfig.oauth.fallback_endpoint",
        )
        return self.oauth.fallback_endpoint

    @property
    def internal_casdoor_endpoint(self) -> str:
        _warn_once(
            "attr:internal_casdoor_endpoint",
            "AuthConfig.internal_casdoor_endpoint",
            "AuthConfig.oauth.internal_endpoint",
        )
        return self.oauth.internal_endpoint

    @property
    def public_casdoor_port(self) -> int:
        _warn_once(
            "attr:public_casdoor_port",
            "AuthConfig.public_casdoor_port",
            "AuthConfig.oauth.public_port",
        )
        return self.oauth.public_port

    @property
    def cookie_name(self) -> str:
        _warn_once(
            "attr:cookie_name",
            "AuthConfig.cookie_name",
            "AuthConfig.cookie.name",
        )
        return self.cookie.name

    @property
    def cookie_secure(self) -> bool:
        _warn_once(
            "attr:cookie_secure",
            "AuthConfig.cookie_secure",
            "AuthConfig.cookie.secure",
        )
        return self.cookie.secure

    @property
    def cookie_same_site(self) -> str:
        _warn_once(
            "attr:cookie_same_site",
            "AuthConfig.cookie_same_site",
            "AuthConfig.cookie.same_site",
        )
        return self.cookie.same_site
