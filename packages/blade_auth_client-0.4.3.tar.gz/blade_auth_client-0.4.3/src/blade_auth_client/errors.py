from __future__ import annotations


class AuthError(Exception):
    """Base exception for blade-auth-client."""


class InvalidTokenError(AuthError):
    """Raised when a token cannot be trusted."""


class InvalidAudienceError(InvalidTokenError):
    """Retained for backward compatibility; no longer raised."""


class ExpiredTokenError(InvalidTokenError):
    """Raised when a token is expired."""


class JwksUnavailableError(AuthError):
    """Raised when JWKS cannot be fetched and no cache is available."""


class CasdoorError(AuthError):
    """Raised when Casdoor returns an error response."""


class UserProvisionError(AuthError):
    """Raised when local user provisioning fails."""
