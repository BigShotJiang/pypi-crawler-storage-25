from __future__ import annotations

import warnings
from importlib import import_module
from typing import Any

__version__ = "0.4.3"

# -----------------------------------------------------------------------------
# 0.4.0 公开面:6 个核心 + 异常族 + 运行期配置访问器。
# 其它老名字(OidcClient / TokenVerifier / create_auth_router / …)继续可 import
# 但会触发 DeprecationWarning,0.5.0 移除。详见 docs/设计/设计-API暴露面收敛.md。
# -----------------------------------------------------------------------------

__all__ = [
    # 核心 6 个
    "BladeAuth",
    "AuthConfig",
    "LazyProvisioner",
    "CasdoorClaims",
    "SqlAlchemyProvisioner",
    # 异常族
    "AuthError",
    "ExpiredTokenError",
    "InvalidTokenError",
    "InvalidAudienceError",
    "JwksUnavailableError",
    "CasdoorError",
    "UserProvisionError",
    # 运行期配置(configure + get_*)仍公开,不被 BladeAuth 替代
    "configure",
    "get_config",
    "get_callback_base_url",
    "get_cookie_name",
    "get_cookie_same_site",
    "get_cookie_secure",
    "get_jwks_cache_ttl_seconds",
    "get_oauth_client_id",
    "get_oauth_client_secret",
    "get_oauth_internal_endpoint",
    "get_oauth_public_endpoint",
    # pydantic 模型(少数场景需要做类型声明/isinstance)
    "OAuthConfig",
    "CookieConfig",
]


# 名字 → (模块路径, 属性名)。_DEPRECATED 集合里的名字会在首次 import 时 warn。
_EXPORTS: dict[str, tuple[str, str]] = {
    # --- 核心 ---
    "BladeAuth": ("blade_auth_client.facade", "BladeAuth"),
    "AuthConfig": ("blade_auth_client.config", "AuthConfig"),
    "LazyProvisioner": ("blade_auth_client.users.provisioner", "LazyProvisioner"),
    "CasdoorClaims": ("blade_auth_client.users.provisioner", "CasdoorClaims"),
    "SqlAlchemyProvisioner": (
        "blade_auth_client.users.sqlalchemy_provisioner",
        "SqlAlchemyProvisioner",
    ),
    # --- 异常族 ---
    "AuthError": ("blade_auth_client.errors", "AuthError"),
    "ExpiredTokenError": ("blade_auth_client.errors", "ExpiredTokenError"),
    "InvalidTokenError": ("blade_auth_client.errors", "InvalidTokenError"),
    "InvalidAudienceError": ("blade_auth_client.errors", "InvalidAudienceError"),
    "JwksUnavailableError": ("blade_auth_client.errors", "JwksUnavailableError"),
    "CasdoorError": ("blade_auth_client.errors", "CasdoorError"),
    "UserProvisionError": ("blade_auth_client.errors", "UserProvisionError"),
    # --- 运行期配置 ---
    "configure": ("blade_auth_client.runtime", "configure"),
    "get_config": ("blade_auth_client.runtime", "get_config"),
    "get_callback_base_url": ("blade_auth_client.runtime", "get_callback_base_url"),
    "get_cookie_name": ("blade_auth_client.runtime", "get_cookie_name"),
    "get_cookie_same_site": ("blade_auth_client.runtime", "get_cookie_same_site"),
    "get_cookie_secure": ("blade_auth_client.runtime", "get_cookie_secure"),
    "get_jwks_cache_ttl_seconds": (
        "blade_auth_client.runtime",
        "get_jwks_cache_ttl_seconds",
    ),
    "get_oauth_client_id": ("blade_auth_client.runtime", "get_oauth_client_id"),
    "get_oauth_client_secret": ("blade_auth_client.runtime", "get_oauth_client_secret"),
    "get_oauth_internal_endpoint": (
        "blade_auth_client.runtime",
        "get_oauth_internal_endpoint",
    ),
    "get_oauth_public_endpoint": (
        "blade_auth_client.runtime",
        "get_oauth_public_endpoint",
    ),
    # --- pydantic 模型 ---
    "OAuthConfig": ("blade_auth_client.config", "OAuthConfig"),
    "CookieConfig": ("blade_auth_client.config", "CookieConfig"),
    # --- DEPRECATED:0.4.0 降级为内部,0.5.0 移除 ---
    "OidcClient": ("blade_auth_client.casdoor.client", "OidcClient"),
    "TokenVerifier": ("blade_auth_client.verifier.token_verifier", "TokenVerifier"),
    "verify_token": ("blade_auth_client.verifier.token_verifier", "verify_token"),
    "JwksCache": ("blade_auth_client.verifier.jwks_cache", "JwksCache"),
    "AuthMiddleware": ("blade_auth_client.socketio.middleware", "AuthMiddleware"),
    "make_auth_middleware": (
        "blade_auth_client.socketio.middleware",
        "make_auth_middleware",
    ),
    "socketio_auth": ("blade_auth_client.socketio.middleware", "socketio_auth"),
    "create_auth_router": (
        "blade_auth_client.fastapi.router",
        "create_auth_router",
    ),
    "make_require_auth_dep": (
        "blade_auth_client.fastapi.deps",
        "make_require_auth_dep",
    ),
    "make_current_user_dep": (
        "blade_auth_client.fastapi.deps",
        "make_current_user_dep",
    ),
    "authenticate_request": (
        "blade_auth_client.fastapi.deps",
        "authenticate_request",
    ),
    "build_callback_url": ("blade_auth_client.fastapi.urls", "build_callback_url"),
    "read_session_token": ("blade_auth_client.cookie.policy", "read_session_token"),
    "write_session_cookie": (
        "blade_auth_client.cookie.policy",
        "write_session_cookie",
    ),
    "clear_session_cookie": (
        "blade_auth_client.cookie.policy",
        "clear_session_cookie",
    ),
    # --- DEPRECATED:0.3.0 起就标注的老别名,0.5.0 一并清 ---
    "CasdoorConfig": ("blade_auth_client.config", "CasdoorConfig"),
}

_DEPRECATED: dict[str, str] = {
    # 0.4.0 降级:这些零件仍能 import,但推荐用 BladeAuth facade
    "OidcClient": "BladeAuth",
    "TokenVerifier": "BladeAuth",
    "verify_token": "BladeAuth.verify",
    "JwksCache": "BladeAuth (internal)",
    "AuthMiddleware": "BladeAuth.socketio_handshake",
    "make_auth_middleware": "BladeAuth.socketio_handshake",
    "socketio_auth": "BladeAuth.socketio_handshake",
    "create_auth_router": "BladeAuth.router",
    "make_require_auth_dep": "BladeAuth.require",
    "make_current_user_dep": "BladeAuth.current",
    "authenticate_request": "BladeAuth.require or BladeAuth.current",
    "build_callback_url": "BladeAuth (internal)",
    "read_session_token": "BladeAuth (internal)",
    "write_session_cookie": "BladeAuth (internal)",
    "clear_session_cookie": "BladeAuth (internal)",
    # 0.3.0 起的老 alias
    "CasdoorConfig": "OAuthConfig",
}

_warned: set[str] = set()


def __getattr__(name: str) -> Any:
    if name not in _EXPORTS:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    if name in _DEPRECATED and name not in _warned:
        _warned.add(name)
        warnings.warn(
            f"blade_auth_client.{name} is deprecated since 0.4.0, "
            f"use {_DEPRECATED[name]} instead; will be removed in 0.5.0",
            DeprecationWarning,
            stacklevel=2,
        )

    module_name, attribute_name = _EXPORTS[name]
    module = import_module(module_name)
    return getattr(module, attribute_name)
