from __future__ import annotations

import html
import logging
import time
from collections.abc import Callable
from secrets import token_urlsafe
from typing import Any
from urllib.parse import urlencode, urlparse

from fastapi import APIRouter, Form, HTTPException, Request, status
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from blade_auth_client.casdoor.client import OidcClient
from blade_auth_client.cookie.policy import clear_session_cookie, write_session_cookie
from blade_auth_client.config import AuthConfig
from blade_auth_client.errors import CasdoorError, InvalidTokenError, JwksUnavailableError, UserProvisionError
from blade_auth_client.fastapi.deps import _build_casdoor_claims, make_require_auth_dep
from blade_auth_client.fastapi.urls import build_callback_url, build_public_casdoor_base, hostname_from_host
from blade_auth_client.mock import LocalCasdoor
from blade_auth_client.users.provisioner import CasdoorClaims, LazyProvisioner, call_provision_user
from blade_auth_client.verifier.token_verifier import TokenVerifier

LOGGER = logging.getLogger(__name__)
AUTHORIZE_URL = "/api/auth/login"
STATE_TTL_SECONDS = 300
AUTHORIZE_PATH = "/login/oauth/authorize"

# 路由 path 常量（相对于消费方挂载的 prefix；single source of truth）
LOGIN_PATH = "/login"
CALLBACK_PATH = "/oauth/casdoor/callback"
LOGOUT_PATH = "/logout"
ME_PATH = "/me"
PROVIDERS_PATH = "/providers"

MeSerializer = Callable[[Any, CasdoorClaims | None, Request], dict[str, Any]]


def create_auth_router(
    config: AuthConfig,
    *,
    verifier: TokenVerifier,
    provisioner: LazyProvisioner[Any],
    oidc_client: OidcClient,
    me_serializer: MeSerializer | None = None,
    local_casdoor: LocalCasdoor | None = None,
) -> Any:
    router = APIRouter()
    require_auth = make_require_auth_dep(
        config,
        verifier=verifier,
        provisioner=provisioner,
    )
    serialize_me = me_serializer or _default_me_serializer
    state_store: dict[str, tuple[str, float]] = {}

    async def _warm_jwks() -> None:
        if not hasattr(verifier, "prewarm"):
            return
        try:
            await verifier.prewarm()
        except JwksUnavailableError:
            LOGGER.warning("Initial JWKS prewarm failed", exc_info=True)

    router.add_event_handler("startup", _warm_jwks)

    def _prune_states() -> None:
        now = time.monotonic()
        expired_states = [key for key, (_, expires_at) in state_store.items() if expires_at <= now]
        for key in expired_states:
            state_store.pop(key, None)

    def _store_state(next_url: str) -> str:
        _prune_states()
        state = token_urlsafe(32)
        state_store[state] = (next_url, time.monotonic() + STATE_TTL_SECONDS)
        return state

    def _consume_state(state: str) -> str | None:
        _prune_states()
        entry = state_store.pop(state, None)
        if entry is None:
            return None

        next_url, expires_at = entry
        if expires_at <= time.monotonic():
            return None
        return next_url

    async def _do_mock_mint(next_url: str) -> RedirectResponse:
        """mock 登录的最后一步：mint JWT、走真 verifier、调 provisioner、写 cookie。"""
        assert local_casdoor is not None
        try:
            token = local_casdoor.mint_token()
            payload = await verifier.verify(token)
            await call_provision_user(
                provisioner, _build_casdoor_claims(payload)
            )
        except (InvalidTokenError, JwksUnavailableError) as exc:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="mock login failed",
            ) from exc
        except (CasdoorError, UserProvisionError) as exc:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=str(exc),
            ) from exc
        response = RedirectResponse(next_url, status_code=status.HTTP_302_FOUND)
        write_session_cookie(response, token, config)
        return response

    @router.get(LOGIN_PATH)
    async def login(request: Request, next: str | None = None, error: str | None = None) -> Any:
        if next is None:
            # 默认 next 就是当前浏览器访问的 origin 根路径（动态 host）
            scheme = request.url.scheme
            host_header = request.headers.get("host") or request.url.netloc
            next = f"{scheme}://{host_header}/"
        _validate_next_url(next, request=request)

        # mock + login_page=true:返 HTML 表单。让用户输用户名+密码命中 mock_user
        # 才发 cookie,体验上跟真 Casdoor 一致(看得到登录页),但仍然不跳 Casdoor。
        if (
            config.oauth.mock
            and local_casdoor is not None
            and config.oauth.mock_login_page
            and config.oauth.mock_user is not None
        ):
            state = _store_state(next)
            return HTMLResponse(
                _render_mock_login_page(
                    state=state,
                    next_url=next,
                    mock_user=config.oauth.mock_user,
                    error=error,
                )
            )

        # mock 模式(login_page=false):short-circuit。本地 Casdoor 直接 mint 一个真
        # JWT → 走真 verifier 验签(保证 prod 代码路径跑一把)→ 调 provisioner →
        # 写 cookie → 302 到 next。浏览器全程不会跳 Casdoor。详见 docs/设计/设计-mock模式.md。
        if config.oauth.mock and local_casdoor is not None:
            return await _do_mock_mint(next)

        state = _store_state(next)
        callback_url = _resolve_callback_url(request, config, LOGIN_PATH)
        authorize_url = _build_authorize_url(
            request=request,
            config=config,
            state=state,
            redirect_uri=callback_url,
        )
        return RedirectResponse(authorize_url, status_code=status.HTTP_302_FOUND)

    @router.post(LOGIN_PATH)
    async def login_submit(
        request: Request,
        state: str = Form(...),
        username: str = Form(...),
        password: str = Form(...),
    ) -> Any:
        """mock 登录页提交。仅 ``mock + mock_login_page=true`` 时挂用。

        校验顺序：state → 用户名/密码命中 mock_user。命中走真 mint 路径。
        失败则重新拿 state 重渲染表单（让用户能重试，next 不丢）。
        """
        if (
            not config.oauth.mock
            or local_casdoor is None
            or not config.oauth.mock_login_page
            or config.oauth.mock_user is None
        ):
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)

        next_url = _consume_state(state)
        if next_url is None:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid state")

        mock_user = config.oauth.mock_user
        valid_usernames = {
            n for n in (mock_user.preferred_username, mock_user.email) if n
        }
        if (
            username.strip() not in valid_usernames
            or mock_user.password is None
            or password != mock_user.password
        ):
            new_state = _store_state(next_url)
            return HTMLResponse(
                _render_mock_login_page(
                    state=new_state,
                    next_url=next_url,
                    mock_user=mock_user,
                    error="用户名或密码错误",
                ),
                status_code=status.HTTP_401_UNAUTHORIZED,
            )

        return await _do_mock_mint(next_url)

    @router.get(CALLBACK_PATH)
    async def callback(request: Request, code: str, state: str) -> RedirectResponse:
        next_url = _consume_state(state)
        if next_url is None:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid state")

        try:
            access_token = await oidc_client.exchange_code(
                code,
                _resolve_callback_url(request, config, CALLBACK_PATH),
            )
            claims = await verifier.verify(access_token)
            await call_provision_user(provisioner, _build_casdoor_claims(claims))
        except InvalidTokenError as exc:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Unauthorized",
            ) from exc
        except JwksUnavailableError as exc:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="JWKS unavailable",
            ) from exc
        except (CasdoorError, UserProvisionError) as exc:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=str(exc),
            ) from exc

        response = RedirectResponse(next_url, status_code=status.HTTP_302_FOUND)
        write_session_cookie(response, access_token, config)
        return response

    @router.get(LOGOUT_PATH)
    async def logout_redirect(request: Request) -> RedirectResponse:
        response = RedirectResponse(_build_logout_url(request, config), status_code=status.HTTP_302_FOUND)
        clear_session_cookie(response, config)
        return response

    @router.post(LOGOUT_PATH)
    async def logout_json(request: Request) -> JSONResponse:
        response = JSONResponse({"logout_url": _build_logout_url(request, config)})
        clear_session_cookie(response, config)
        return response

    @router.get(PROVIDERS_PATH)
    async def providers(request: Request) -> dict[str, Any]:
        # 根据实际挂载的 router prefix 拼 login URL，避免硬编码 /api/auth/login
        # 在不同前缀下返回错误地址（blade-os 挂 /api/v1/auth、消费方可能不用前缀）
        path = request.url.path
        assert path.endswith(PROVIDERS_PATH)
        authorize_url = path[: -len(PROVIDERS_PATH)] + LOGIN_PATH
        return {
            "providers": [{"name": "casdoor", "authorize_url": authorize_url}],
            "password_enabled": False,
        }

    @router.get(ME_PATH)
    async def me(request: Request, user: Any = require_auth) -> dict[str, Any]:
        claims = getattr(request.state, "blade_auth_claims", None)
        return serialize_me(user, claims, request)

    return router


def _build_authorize_url(
    *,
    request: Request,
    config: AuthConfig,
    state: str,
    redirect_uri: str,
) -> str:
    public_base = build_public_casdoor_base(request, config=config)
    return f"{public_base}{AUTHORIZE_PATH}?{urlencode(_authorize_query(config, state, redirect_uri))}"


def _authorize_query(config: AuthConfig, state: str, redirect_uri: str) -> dict[str, str]:
    return {
        "client_id": config.oauth.client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": "openid profile email",
        "state": state,
    }


def _resolve_callback_url(request: Request, config: AuthConfig, current_route: str) -> str:
    if request.headers.get("host") or request.url.hostname:
        return build_callback_url(request, _route_prefix(request, current_route))
    if config.callback_base_url:
        return config.callback_base_url.rstrip("/")
    return build_callback_url(request, "")


def _build_logout_url(request: Request, config: AuthConfig) -> str:
    if config.oauth.deploy_mode == "server" or request.headers.get("host") or request.url.hostname:
        return f"{build_public_casdoor_base(request, config=config)}/logout"
    if config.oauth.fallback_endpoint:
        return f"{config.oauth.fallback_endpoint.rstrip('/')}/logout"
    return f"{config.oauth.internal_endpoint.rstrip('/')}/logout"


def _route_prefix(request: Request, route_path: str) -> str:
    path = request.url.path.rstrip("/")
    normalized_route = route_path.rstrip("/")
    if path.endswith(normalized_route):
        return path[: -len(normalized_route)]
    return ""


def _validate_next_url(
    next_url: str,
    *,
    request: Request | None = None,
) -> None:
    # 本 SDK 仅支持"浏览器当前 host"推断模式：next 的 hostname 必须等于当前
    # request 的 hostname。换 IP 场景下不用改任何配置（允许同一机器的任意 port）。
    parsed = urlparse(next_url)
    if not parsed.scheme or not parsed.netloc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="next must be an absolute URL",
        )

    if request is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="next origin is not allowed",
        )

    request_host = request.headers.get("host")
    request_hostname = hostname_from_host(request_host) if request_host else request.url.hostname
    if parsed.hostname != request_hostname:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="next origin is not allowed",
        )


def _default_me_serializer(
    user: Any,
    claims: CasdoorClaims | None,
    request: Request,
) -> dict[str, Any]:
    return {
        "id": _read_user_value(user, "id"),
        "username": _coalesce(
            _read_user_value(user, "username"),
            _read_user_value(user, "name"),
            getattr(claims, "preferred_username", None),
            getattr(claims, "name", None),
            getattr(claims, "email", None),
            getattr(claims, "sub", None),
        ),
        "avatar_url": _coalesce(
            _read_user_value(user, "avatar_url"),
            _read_user_value(user, "avatar"),
            getattr(claims, "picture", None),
        ),
        "token": getattr(request.state, "blade_auth_token", None),
        "auth_type": "casdoor",
    }


def _read_user_value(user: Any, key: str) -> Any:
    if isinstance(user, dict):
        return user.get(key)
    return getattr(user, key, None)


def _coalesce(*values: Any) -> Any:
    for value in values:
        if value is not None:
            return value
    return None


def _render_mock_login_page(
    *,
    state: str,
    next_url: str,
    mock_user: Any,
    error: str | None = None,
) -> str:
    """渲染登录页。inline HTML + CSS，不依赖任何外部资源。

    刻意不暴露 mock / dev 字样，跟真 Casdoor 登录页 UX 对齐 ——
    接入方业务和最终用户感受不到这是 mock 模式（设计文档 §6.4）。
    """
    del mock_user, next_url  # 不展示 mock_user 字段，不暴露 next_url
    error_html = (
        f'<div class="error" role="alert">{html.escape(error)}</div>' if error else ""
    )
    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>登录</title>
<style>
  *,*::before,*::after {{ box-sizing:border-box; }}
  body {{
    margin:0; min-height:100vh; padding:24px;
    display:flex; align-items:center; justify-content:center;
    background:
      radial-gradient(ellipse at top, rgba(37,99,235,.06), transparent 60%),
      linear-gradient(180deg,#f8fafc 0%,#ffffff 60%);
    color:#0f172a;
    font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Helvetica Neue",sans-serif;
    -webkit-font-smoothing:antialiased;
  }}
  .card {{
    width:100%; max-width:400px;
    padding:44px 40px 40px;
    background:#fff;
    border:1px solid rgba(15,23,42,.06);
    border-radius:14px;
    box-shadow:
      0 1px 2px rgba(15,23,42,.04),
      0 12px 36px rgba(15,23,42,.08);
  }}
  .logo {{
    width:56px; height:56px; margin:0 auto 22px;
    border-radius:14px;
    background:linear-gradient(135deg,#3b82f6 0%,#2563eb 100%);
    display:flex; align-items:center; justify-content:center;
    box-shadow:0 6px 16px rgba(37,99,235,.28);
  }}
  .logo svg {{ width:26px; height:26px; color:#fff; stroke:currentColor; fill:none; stroke-width:2; stroke-linecap:round; stroke-linejoin:round; }}
  h1 {{
    margin:0 0 6px; text-align:center;
    font-size:22px; font-weight:600; letter-spacing:-.01em;
  }}
  .sub {{
    margin:0 0 28px; text-align:center;
    color:#64748b; font-size:13px;
  }}
  .field {{ margin-bottom:16px; }}
  label {{
    display:block; font-size:13px; font-weight:500;
    color:#334155; margin-bottom:7px;
  }}
  input {{
    width:100%; height:42px; padding:0 13px;
    font-size:14.5px; color:#0f172a;
    border:1px solid #e2e8f0; border-radius:8px;
    background:#fff;
    transition:border-color .15s, box-shadow .15s, background .15s;
  }}
  input::placeholder {{ color:#94a3b8; }}
  input:hover {{ border-color:#cbd5e1; }}
  input:focus {{
    outline:none; border-color:#2563eb;
    box-shadow:0 0 0 3px rgba(37,99,235,.14);
  }}
  button {{
    width:100%; height:44px; margin-top:8px;
    font-size:14.5px; font-weight:500; color:#fff;
    background:#2563eb; border:none; border-radius:8px;
    cursor:pointer; letter-spacing:.04em;
    transition:background .15s, box-shadow .15s, transform .05s;
  }}
  button:hover {{ background:#1d4ed8; box-shadow:0 6px 16px rgba(37,99,235,.28); }}
  button:active {{ transform:translateY(1px); }}
  .error {{
    background:#fef2f2; color:#b91c1c;
    padding:10px 12px; border-radius:8px;
    font-size:13px; margin-bottom:16px;
    border:1px solid #fecaca;
  }}
</style>
</head>
<body>
  <form class="card" method="POST" action="" novalidate>
    <div class="logo" aria-hidden="true">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
        <rect x="4" y="11" width="16" height="10" rx="2"/>
        <path d="M8 11V7a4 4 0 0 1 8 0v4"/>
      </svg>
    </div>
    <h1>登录</h1>
    <p class="sub">请输入您的账号信息</p>
    {error_html}
    <input type="hidden" name="state" value="{html.escape(state)}">
    <div class="field">
      <label for="username">用户名</label>
      <input id="username" name="username" autocomplete="username" autofocus required>
    </div>
    <div class="field">
      <label for="password">密码</label>
      <input id="password" name="password" type="password" autocomplete="current-password" required>
    </div>
    <button type="submit">登 录</button>
  </form>
</body>
</html>
"""
