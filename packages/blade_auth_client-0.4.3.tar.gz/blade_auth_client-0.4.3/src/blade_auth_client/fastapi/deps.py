from __future__ import annotations

from typing import Any

from fastapi import Depends, HTTPException, Request, status
from starlette.responses import Response as StarletteResponse

from blade_auth_client.cookie.policy import clear_session_cookie, read_session_token
from blade_auth_client.config import AuthConfig
from blade_auth_client.errors import InvalidTokenError, JwksUnavailableError, UserProvisionError
from blade_auth_client.users.provisioner import CasdoorClaims, LazyProvisioner, call_provision_user
from blade_auth_client.verifier.token_verifier import TokenVerifier


async def authenticate_request(
    request: Request,
    config: AuthConfig,
    verifier: TokenVerifier,
    provisioner: LazyProvisioner[Any],
    *,
    allow_query_token: bool = False,
) -> tuple[Any, CasdoorClaims, str] | None:
    token, token_source = _extract_token(
        request,
        config,
        allow_query_token=allow_query_token,
    )
    if token is None:
        _set_request_state(request, token=None, claims=None, user=None)
        return None

    try:
        payload = await verifier.verify(token)
    except InvalidTokenError as exc:
        headers = None
        if token_source == "cookie":
            clear_cookie_response = StarletteResponse()
            clear_session_cookie(clear_cookie_response, config)
            set_cookie_header = clear_cookie_response.headers.get("set-cookie")
            if set_cookie_header is not None:
                headers = {"set-cookie": set_cookie_header}
        _set_request_state(request, token=None, claims=None, user=None)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Unauthorized",
            headers=headers,
        ) from exc
    except JwksUnavailableError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="JWKS unavailable",
        ) from exc

    try:
        claims = _build_casdoor_claims(payload)
        user = await call_provision_user(provisioner, claims)
    except UserProvisionError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to provision user",
        ) from exc

    _set_request_state(request, token=token, claims=claims, user=user)
    return user, claims, token


def make_current_user_dep(
    config: AuthConfig,
    *,
    verifier: TokenVerifier,
    provisioner: LazyProvisioner[Any],
) -> Any:
    async def _current_user(request: Request) -> Any | None:
        authenticated = await authenticate_request(
            request,
            config,
            verifier,
            provisioner,
        )
        if authenticated is None:
            return None
        user, _, _ = authenticated
        return user

    return Depends(_current_user)


def make_require_auth_dep(
    config: AuthConfig,
    *,
    verifier: TokenVerifier,
    provisioner: LazyProvisioner[Any],
) -> Any:
    current_user_dep = make_current_user_dep(
        config,
        verifier=verifier,
        provisioner=provisioner,
    )

    async def _require_auth(current_user: Any = current_user_dep) -> Any:
        if current_user is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Unauthorized",
            )
        return current_user

    return Depends(_require_auth)


def _extract_token(
    request: Request,
    config: AuthConfig,
    *,
    allow_query_token: bool = False,
) -> tuple[str | None, str | None]:
    authorization = request.headers.get("authorization", "")
    scheme, _, credentials = authorization.partition(" ")
    if scheme.lower() == "bearer" and credentials:
        return credentials, "bearer"

    if allow_query_token:
        query_token = request.query_params.get("token", "").strip()
        if query_token:
            return query_token, "query"

    cookie_token = read_session_token(request, config)
    if cookie_token:
        return cookie_token, "cookie"

    return None, None


def _build_casdoor_claims(claims: dict[str, Any]) -> CasdoorClaims:
    sub = claims.get("sub")
    if not isinstance(sub, str) or not sub:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Unauthorized",
        )

    return CasdoorClaims(
        sub=sub,
        email=_optional_string(claims.get("email")),
        preferred_username=_optional_string(claims.get("preferred_username")),
        name=_optional_string(claims.get("name") or claims.get("displayName")),
        picture=_optional_string(claims.get("picture") or claims.get("avatar")),
    )


def _set_request_state(
    request: Request,
    *,
    token: str | None,
    claims: CasdoorClaims | None,
    user: Any | None,
) -> None:
    request.state.blade_auth_token = token
    request.state.blade_auth_claims = claims
    request.state.blade_auth_user = user


def _optional_string(value: Any) -> str | None:
    if isinstance(value, str) and value:
        return value
    return None
