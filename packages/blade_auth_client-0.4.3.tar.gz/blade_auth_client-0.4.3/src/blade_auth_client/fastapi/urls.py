from __future__ import annotations

from typing import TYPE_CHECKING

from fastapi import Request

if TYPE_CHECKING:
    from blade_auth_client.config import AuthConfig

DEFAULT_PROVIDER = "casdoor"


def build_callback_url(request: Request, prefix: str, provider: str = DEFAULT_PROVIDER) -> str:
    scheme, host = request_origin(request)
    normalized_prefix = _normalize_prefix(prefix)
    return f"{scheme}://{host}{normalized_prefix}/oauth/{provider}/callback"


def build_public_casdoor_base(
    request: Request,
    *,
    config: "AuthConfig | None" = None,
    public_port: int | None = None,
) -> str:
    """根据 deploy_mode 返回浏览器可访问的 Casdoor base URL。

    新调用方式：传 ``config``，内部按 ``config.casdoor.deploy_mode`` 分支。
    老调用方式：传 ``public_port``（等价于 ``deploy_mode='box'`` 的行为），保留给外部调用方。
    """
    if config is not None:
        oauth = config.oauth
        if oauth.deploy_mode == "server":
            assert oauth.public_endpoint is not None  # validator 保证
            return oauth.public_endpoint.rstrip("/")
        port = oauth.public_port
    elif public_port is not None:
        port = public_port
    else:
        raise TypeError(
            "build_public_casdoor_base requires either `config` (preferred) or `public_port`"
        )

    scheme, host = request_origin(request)
    hostname = hostname_from_host(host)
    return f"{scheme}://{_format_netloc(hostname, port)}"


def request_origin(request: Request) -> tuple[str, str]:
    scheme = request.url.scheme or "http"
    host = request.headers.get("host") or request.url.netloc or "127.0.0.1"
    return scheme, host


def hostname_from_host(host: str) -> str:
    if host.startswith("["):
        return host.split("]", 1)[0][1:]
    if host.count(":") == 1:
        return host.rsplit(":", 1)[0]
    return host


def _format_netloc(hostname: str, port: int) -> str:
    if ":" in hostname and not hostname.startswith("["):
        return f"[{hostname}]:{port}"
    return f"{hostname}:{port}"


def _normalize_prefix(prefix: str) -> str:
    if not prefix:
        return ""
    if not prefix.startswith("/"):
        prefix = f"/{prefix}"
    return prefix.rstrip("/")
