from __future__ import annotations

import warnings
from dataclasses import dataclass
from typing import Any, Protocol, TypeVar, runtime_checkable

UserT = TypeVar("UserT")


@dataclass(slots=True)
class CasdoorClaims:
    sub: str
    email: str | None = None
    preferred_username: str | None = None
    name: str | None = None
    picture: str | None = None


@runtime_checkable
class LazyProvisioner(Protocol[UserT]):
    """接入方要实现的身份落地 Protocol。

    0.4.0 推荐形态:实现 ``provision_user``。

    兼容:0.3.x 的实现只有 ``ensure_user`` 也仍然能被 SDK 调用(SDK 内部走
    :func:`call_provision_user` 自动回落 + 一次 ``DeprecationWarning``),
    但这类实现**不再满足** ``isinstance(x, LazyProvisioner)`` 的结构性检查。
    type checker 友好 + 升级信号清晰 > 兼容 isinstance。0.5.0 移除老名字回落。
    """

    async def provision_user(self, claims: CasdoorClaims) -> UserT:
        """按 claims 建用户(首次)或更新可变字段后返回(非首次)。"""
        ...


_warned_classes: set[type] = set()


async def call_provision_user(
    provisioner: Any,
    claims: CasdoorClaims,
) -> Any:
    """SDK 内部统一的调用入口:优先 ``provision_user``,回落 ``ensure_user``
    并打一次 ``DeprecationWarning``。

    给接入方提供无痛升级路径:0.3.x 的实现只定义了 ``ensure_user``,
    切 0.4.0 不用改代码就能跑;真改名到 ``provision_user`` 后 warn 消失。
    """
    new_method = getattr(type(provisioner), "provision_user", None)
    old_method = getattr(type(provisioner), "ensure_user", None)

    # Protocol 默认实现不算"有";只认接入方自己定义的
    new_defined = new_method is not None and not _is_protocol_default(new_method)
    old_defined = old_method is not None and not _is_protocol_default(old_method)

    if new_defined:
        return await provisioner.provision_user(claims)

    if old_defined:
        cls = type(provisioner)
        if cls not in _warned_classes:
            _warned_classes.add(cls)
            warnings.warn(
                f"{cls.__name__}.ensure_user is deprecated since blade-auth-client 0.4.0, "
                "rename it to provision_user; will be removed in 0.5.0",
                DeprecationWarning,
                stacklevel=3,
            )
        return await provisioner.ensure_user(claims)

    raise TypeError(
        f"{type(provisioner).__name__} must implement provision_user(claims) "
        "(LazyProvisioner protocol)"
    )


def _is_protocol_default(method: Any) -> bool:
    """判断方法是否只是 Protocol 声明的占位(body 只有 ``...``,定义在本模块里)。"""
    return getattr(method, "__module__", "") == __name__
