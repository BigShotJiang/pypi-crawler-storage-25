from __future__ import annotations

import warnings
from collections.abc import Awaitable, Callable
from typing import Any

from sqlalchemy import inspect as sa_inspect
from sqlalchemy import select

from blade_auth_client.errors import UserProvisionError

from .provisioner import CasdoorClaims

AfterLoginHook = Callable[[Any, Any, CasdoorClaims], Any | Awaitable[Any]]


class SqlAlchemyProvisioner:
    def __init__(
        self,
        sessionmaker: Callable[[], Any],
        user_model: type[Any],
        after_login: AfterLoginHook | None = None,
        *,
        id_field: str = "id",
        subject_field: str = "casdoor_sub",
        username_field: str = "username",
        email_field: str = "email",
        avatar_url_field: str = "avatar_url",
    ) -> None:
        self._sessionmaker = sessionmaker
        self._user_model = user_model
        self._after_login = after_login
        self._id_field = id_field
        self._subject_field = subject_field
        self._username_field = username_field
        self._email_field = email_field
        self._avatar_url_field = avatar_url_field
        self._validate_model_fields()

    async def provision_user(self, claims: CasdoorClaims) -> Any:
        username = _resolve_username(claims)
        try:
            with self._sessionmaker() as session:
                user = session.scalar(
                    select(self._user_model).where(
                        getattr(self._user_model, self._subject_field) == claims.sub
                    )
                )
                created = False
                if user is None:
                    user = self._user_model(
                        **{
                            self._subject_field: claims.sub,
                            self._username_field: username,
                            self._email_field: claims.email,
                            self._avatar_url_field: claims.picture,
                        }
                    )
                    session.add(user)
                    session.flush()
                    created = True

                updated = self._sync_user(user, claims, username)
                if self._after_login is not None:
                    maybe_awaitable = self._after_login(session, user, claims)
                    if isinstance(maybe_awaitable, Awaitable):
                        await maybe_awaitable

                if created or updated:
                    session.flush()
                session.commit()
                session.refresh(user)
                return user
        except UserProvisionError:
            raise
        except Exception as exc:
            raise UserProvisionError("Failed to provision user") from exc

    async def ensure_user(self, claims: CasdoorClaims) -> Any:
        """Deprecated alias of :meth:`provision_user`。0.5.0 移除。"""
        warnings.warn(
            "SqlAlchemyProvisioner.ensure_user is deprecated since blade-auth-client 0.4.0, "
            "use provision_user instead; will be removed in 0.5.0",
            DeprecationWarning,
            stacklevel=2,
        )
        return await self.provision_user(claims)

    def _sync_user(self, user: Any, claims: CasdoorClaims, username: str) -> bool:
        changed = False
        if getattr(user, self._username_field, None) != username:
            setattr(user, self._username_field, username)
            changed = True
        if claims.email is not None and getattr(user, self._email_field, None) != claims.email:
            setattr(user, self._email_field, claims.email)
            changed = True
        if claims.picture is not None and getattr(user, self._avatar_url_field, None) != claims.picture:
            setattr(user, self._avatar_url_field, claims.picture)
            changed = True
        return changed

    def _validate_model_fields(self) -> None:
        mapper = sa_inspect(self._user_model)
        known_fields = set(mapper.attrs.keys())
        missing = [
            field_name
            for field_name in (
                self._id_field,
                self._subject_field,
                self._username_field,
                self._email_field,
                self._avatar_url_field,
            )
            if field_name not in known_fields
        ]
        if missing:
            raise ValueError(
                "user_model is missing required fields: " + ", ".join(sorted(missing))
            )


def _resolve_username(claims: CasdoorClaims) -> str:
    return claims.preferred_username or claims.name or claims.email or claims.sub
