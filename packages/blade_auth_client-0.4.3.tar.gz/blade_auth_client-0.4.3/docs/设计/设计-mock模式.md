# 设计文档:SDK Mock 模式

- 作者:yanbingzheng
- 日期:2026-04-24
- 目标版本:`blade-auth-client` 0.5.0(跟"移除 0.4.0 已标废弃名字"一起上)
- 前置:`设计-API暴露面收敛.md`(0.4.0 BladeAuth facade 已落地)

---

## 1. 问题

每次本地开发、CI 集成测试、演示 demo 都要先把 Casdoor 起好。新同学 onboard / 一键预览 / 离线 demo 场景下,"起一套 Casdoor 再跑 blade-os" 是最大摩擦。

blade-os 现在的规避方式:手动塞 `_TestOidcClient` + `_StaticJwksCache`,写在 `tests/backend/conftest.py` 里几十行胶水。换个项目又要抄一遍。

## 2. 目标

给 `BladeAuth` 加**官方的 mock 开关**。一行 yaml 切换,不需要:

- 起 Casdoor 容器
- 真跳转授权
- 生成 / 签 / 验 JWT

接入方仍然用**一模一样的 `BladeAuth` / `LazyProvisioner` / `auth.require()` / `auth.current()`** —— 业务代码零改动。

### 典型场景

| 场景 | mock 价值 |
| --- | --- |
| 新同学本地 onboard | 跳过 Casdoor 部署步骤,`./start.sh` 一键起 |
| 前端联调 | 后端不依赖 Casdoor,后端重启不丢登录态(mock cookie 常驻) |
| 端到端测试 / CI | 整条鉴权链路跑真路径(router / provisioner / depends / request.state),只是 Casdoor 被替换成离线实现 |
| Product demo | 无外部依赖,零配置拉起 |

## 3. 对外配置

沿用 `configs/oauth_config.yaml`,新增一段:

```yaml
oauth:
  client_id: blade-client              # 仍然要填(router 会读,但 mock 模式下不实际发请求)
  client_secret: placeholder           # 同上
  internal_endpoint: http://localhost  # 同上
  deploy_mode: box
  public_port: 19000

  # ---------- 新增 ----------
  mock: true                           # 默认 false;true 时下面 mock_user 生效
  mock_user:                           # mock: true 时必填(不填会 fail fast)
    sub: mock-admin                    # 本地 user 的 OAuth provider_account_id(做绑定 key)
    email: admin@mock.local
    name: Mock Admin
    preferred_username: mockadmin
    picture: null
```

### 3.1 pydantic 模型

```python
class MockUserConfig(BaseModel):
    sub: str
    email: str | None = None
    name: str | None = None
    preferred_username: str | None = None
    picture: str | None = None

class OAuthConfig(BaseModel):
    ...existing...
    mock: bool = False
    mock_user: MockUserConfig | None = None

    @model_validator(mode="after")
    def _check_mock_consistency(self) -> "OAuthConfig":
        if self.mock and self.mock_user is None:
            raise ValueError("oauth.mock=true requires oauth.mock_user")
        return self
```

## 4. 架构:mock = 本地内置的一套 Casdoor

**关键思路**(来自 review 反馈):mock 不是"SDK 里的第二套平行逻辑",而是**"把 Casdoor 本身搬到进程内,写死响应"**。产品代码路径 —— JWT 签名校验、JWKS cache、cookie 读写、provisioner 调用 —— **全部原封不动地跑真路径**,mock 只替换**最外层的 HTTP 边界**:

```
真实:
    浏览器 ──(Casdoor 跳)──▶ 真 Casdoor server ──(HTTP)──▶ backend 的 OidcClient / JwksCache

mock:
    浏览器 ─────────▶ (/login 本地 short-circuit) ─────▶ backend 的 OidcClient / JwksCache
                                                             │
                                                             ▼
                                            ┌──── "本地 Casdoor" 单例(进程内) ────┐
                                            │  - 启动期生成 RSA keypair               │
                                            │  - mint_token(claims) → 真 RS256 JWT    │
                                            │  - public_key → 喂给 JwksCache          │
                                            └──────────────────────────────────────────┘
```

**收益**:
- **Token 是真 JWT**,形状跟 prod 一模一样。`TokenVerifier` 拿到就验签、查 exp、一路正常跑
- 不用新增 `MockTokenVerifier`。真 `TokenVerifier` 完全复用,只是 `JwksCache` 不打 HTTP,内部直接返回本地公钥
- 测试覆盖最大化:prod 代码路径一次跑到底,只是 Casdoor 被替换成离线实现

### 4.1 新增内部类:`LocalCasdoor`

```python
# src/blade_auth_client/mock/local_casdoor.py
class LocalCasdoor:
    """进程内的"写死逻辑"Casdoor。启动期 new 一次,持有 RSA keypair + mock_user。"""

    def __init__(self, config: AuthConfig) -> None:
        self._config = config
        self._private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        self._public_key = self._private_key.public_key()
        self._kid = "mock-kid"

    def mint_token(self, *, expires_in: int = 3600) -> str:
        """按 mock_user 签一个真 RS256 JWT,形状跟 Casdoor 签的一模一样。"""
        user = self._config.oauth.mock_user
        now = datetime.now(UTC)
        claims = {
            "sub": user.sub,
            "email": user.email,
            "name": user.name,
            "preferred_username": user.preferred_username,
            "picture": user.picture,
            "iss": "mock://local-casdoor",
            "aud": self._config.oauth.client_id,
            "iat": int(now.timestamp()),
            "exp": int(now.timestamp()) + expires_in,
        }
        return jwt.encode(
            {k: v for k, v in claims.items() if v is not None},
            self._private_key_pem,
            algorithm="RS256",
            headers={"kid": self._kid},
        )

    def jwks(self) -> dict[str, Any]:
        """JWKS 格式的公钥,喂给 MockJwksCache 或 prewarm 真 JwksCache。"""
        return {"keys": [_rsa_public_to_jwk(self._public_key, self._kid)]}
```

### 4.2 `MockOidcClient` / `MockJwksCache`:两个薄壳,委托给 `LocalCasdoor`

```python
class MockOidcClient:
    def __init__(self, local: LocalCasdoor) -> None:
        self._local = local

    async def exchange_code(self, code: str, redirect_uri: str) -> str:
        # callback 路径如果真被访问到(见 §4.4),这里也能正确兑换出 token
        return self._local.mint_token()


class MockJwksCache:
    """替代真 JwksCache:不打 HTTP,直接返回 LocalCasdoor 的公钥。"""

    def __init__(self, local: LocalCasdoor) -> None:
        self._local = local
        self._public_key = local.public_key_object  # cryptography RSAPublicKey

    async def refresh(self) -> dict[str, Any]:
        return self._local.jwks()

    async def get_signing_key(self, token: str) -> Any:
        return self._public_key
```

### 4.3 `BladeAuth.__init__` 的分流

```python
class BladeAuth(Generic[UserT]):
    def __init__(self, config, *, provisioner, http_client=None):
        self._config = config
        self._provisioner = provisioner

        if config.oauth.mock:
            self._local_casdoor = LocalCasdoor(config)
            self._verifier = TokenVerifier(          # ← 真 TokenVerifier,不动
                config,
                jwks_cache=MockJwksCache(self._local_casdoor),
            )
            self._oidc = MockOidcClient(self._local_casdoor)
            logger.warning(
                "blade-auth-client running in MOCK mode. In-process Casdoor "
                "signed a stable RSA keypair; all /login will authenticate "
                "as mock_user.sub=%s. Do NOT use in production.",
                config.oauth.mock_user.sub,
            )
        else:
            self._verifier = TokenVerifier(config)
            self._oidc = OidcClient(config, http_client)
```

**注意:只替换了 `JwksCache` 和 `OidcClient` 两个 HTTP 边界的实现,`TokenVerifier` / 下游 deps / router 完全一致。**

### 4.4 router 的 `/login`:是否 short-circuit?

两个选项:

| 选项 | /login 行为 | 优点 | 缺点 |
| --- | --- | --- | --- |
| **A. Short-circuit** | mock 时直接 `mint_token` → 写 cookie → 302 到 `next`,跳过 authorize/callback | 最快,用户期望("直接登录成功") | callback 路径在测试里跑不到 |
| B. 全链模拟 | mock 时把 authorize 跳到一个本地 `/mock-casdoor/authorize`,它立刻 302 到 callback 带一个假 code,callback 再 exchange → mint_token | 端到端跑通 callback | 实现复杂;URL 层多一跳 |

**选 A**(与 user 要求 "直接登录成功" 一致)。如果接入方/测试想跑 callback 路径,他们可以在测试里**直接访问 `/api/v1/auth/oauth/casdoor/callback?code=x&state=y`**,`MockOidcClient.exchange_code` 会按 mint_token 返回真 JWT,callback handler 原路正常跑。

```python
@router.get(LOGIN_PATH)
async def login(request, next: str | None = None):
    ...parse next...
    if config.oauth.mock:
        token = bladeauth._local_casdoor.mint_token()
        claims = await verifier.verify(token)           # ← 即使 mock,仍然跑真签名验证
        await call_provision_user(provisioner, _build_casdoor_claims(claims))
        response = RedirectResponse(next, status_code=302)
        write_session_cookie(response, token, config)
        return response
    ...原有 authorize 跳 Casdoor 逻辑...
```

## 5. Token 形态:**真 RS256 JWT**

Cookie 里就是一个**标准的 RS256 JWT**,header/claims/signature 齐全,只是:
- 签名的私钥是 `LocalCasdoor` 启动期 `rsa.generate_private_key(...)` 在内存里生的
- `iss` 是 `mock://local-casdoor`(跟 prod 的 Casdoor issuer 区分)
- `aud` 是 `oauth.client_id`(正常)

**为什么不用 opaque 字符串 / 不签 JWT**(上一版的设计):
- Token 形状跟 prod 不一致,`TokenVerifier` 得分流成 "mock 路径 vs prod 路径",测试只能验到 mock 路径
- 现在用真 JWT,**`TokenVerifier` 完全不知道自己在 mock**,一直跑正常签名/过期校验。冷启动、JWKS cache 命中/miss、claims 解析路径都走真路

**"mock vs prod"的区分如何体现**?`iss` 字段 —— prod 是 Casdoor 颁发的 issuer,mock 是 `mock://local-casdoor`。但**接入方业务代码不应该区分**(详见 §6.4 "对接入方 100% 透明"),`CasdoorClaims` dataclass 也不暴露 `iss`,SDK 用户按标准 API 调用根本看不到。

## 6. 安全

### 6.1 启动期 WARN

`BladeAuth.__init__` 检测到 `config.oauth.mock=true` 时 `logger.warning` 一条显眼的:

```
blade-auth-client is running in MOCK mode (oauth.mock=true).
Do NOT use in production; all requests will authenticate as mock_user.sub={sub}.
```

### 6.2 RSA keypair 的生命周期

- `LocalCasdoor` 在 `BladeAuth.__init__` 里 `rsa.generate_private_key(...)` 生成,**只活在进程内存里**
- 私钥**不持久化、不写盘、不透过配置文件导入**
- 进程重启 → 新 keypair → 老 mock cookie 签名对不上 → 被 `TokenVerifier.verify` 拒掉 → 浏览器下次请求自动触发重新 mock 登录(相当于重启"注销所有人")

这跟真 Casdoor 的行为略有区别(真 Casdoor 重启不换签名密钥),但对开发 / 测试场景不是问题,反而省掉"如何管理 mock 密钥"的麻烦。

### 6.3 production 硬阻断

不做。运维对自己配的 yaml 负责,SDK 不做"猜环境"的启发式判断(容易误伤 / 漏判)。起动期 WARN 足够。

### 6.4 对接入方 100% 透明(核心不变量)

mock 的价值前提是"**接入方业务代码不需要任何 `if mock:` 分支**"。SDK 得主动守住这个不变量,而不是给接入方开"感知 mock"的后门。

**守住的是**:
- `provisioner.provision_user(claims)` 收到的 `CasdoorClaims` 和 prod 模式字段、shape 完全一致
- `auth.require()` / `auth.current()` / `Depends` 拿到的 user 类型一致
- `request.state.blade_auth_user / _claims / _token` 结构一致
- `/login` / `/me` / `/logout` / `/providers` / `/callback` 的 HTTP 响应 shape 一致
- Cookie name / httponly / samesite / path 都走 yaml 里 `cookie:` 段的配置

**刻意不提供的"后门"**(防止接入方 branch):

| 不做 | 为什么 |
| --- | --- |
| `BladeAuth.is_mock` property | 诱导 `if auth.is_mock: ...` 的业务代码,一旦有分支就不透明 |
| `/providers` 响应加 `mock: true` | 泄漏到前端和接入方的 JSON 消费层 |
| `CasdoorClaims.is_mock` 或类似字段 | 一旦暴露,provisioner 必然按 mock 走捷径(比如跳过验证),prod / mock 路径分歧 |
| JWT `iss` 或其它字段跟 prod 保持一致 | **`iss` 反而特意写成 `mock://local-casdoor`**:万一接入方真的在某个上下文下拿到原始 JWT 并读 iss,起码有明确信号 |

**没守住的是**(mock 本意的可见差异):
- 前端跳 `/login` 之后**不弹 Casdoor 密码框,直接进应用**。这是 mock 的语义本身 —— "直接登录成功",不应该伪装
- 后端 `logger.warning` 里会反复打 "MOCK mode" —— 运维 / 日志监控层必然感知,这也是刻意为之

### 6.5 cookie 安全

但**提供一个文档推荐**:把 `configs/oauth_config.yaml` 按环境准备两份,生产的那份彻底不写 mock 字段。

mock cookie 仍然 httponly + samesite 保留,`secure` 按 yaml 配(mock 本地开发一般 secure=false)。不特殊处理。

## 7. 接入方用法示例

### 7.1 本地开发启动

```yaml
# configs/oauth_config.yaml
oauth:
  client_id: blade-client             # 任意值,mock 不用
  client_secret: placeholder
  internal_endpoint: http://localhost
  deploy_mode: box
  public_port: 19000
  mock: true
  mock_user:
    sub: local-dev
    email: dev@local
    name: Local Dev
    preferred_username: dev
cookie:
  name: blade_token
  secure: false
  same_site: lax
```

```bash
./start.sh   # 不需要起 Casdoor,后端直接能登录
```

前端正常跳 `/api/v1/auth/login` → 立刻 302 到 `next`,cookie 已经写好。

### 7.2 blade-os conftest 测试瘦身

今天 blade-os 的 `tests/backend/conftest.py` 里 ~30 行胶水(`_StaticJwksCache`、`_TestOidcClient`、`_test_build_auth`)可以全删,改成:

```python
@pytest.fixture
def auth_yaml(tmp_path):
    path = tmp_path / "oauth_config.yaml"
    path.write_text("""oauth:
  client_id: test
  client_secret: test
  internal_endpoint: http://localhost
  deploy_mode: box
  mock: true
  mock_user:
    sub: test-admin
    email: admin@test.local
    name: Test Admin
    preferred_username: admin
cookie:
  name: blade_token
""")
    return path

@pytest.fixture
def client(auth_yaml, monkeypatch, ...):
    monkeypatch.setenv("OAUTH_CONFIG_YAML_PATH", str(auth_yaml))
    ...
    # 不再需要 monkeypatch _build_auth!
    yield TestClient(create_app())
```

`test_session_creates_local_user_from_casdoor_claims` 这类测试直接走 `client.get("/api/v1/auth/login")` 拿 cookie,也不需要手动 `issue_auth_token`。

## 8. `providers` 端点

**不动。**返回 shape 跟 prod 完全一致:

```json
{
  "providers": [
    {"name": "casdoor", "authorize_url": "/api/v1/auth/login"}
  ],
  "password_enabled": false
}
```

**不加 `mock: true` 字段** —— 参见 §6.4 "对接入方 100% 透明"。前端要挂 "MOCK MODE" 红色横幅,自己读 yaml 配置(或另起一个 `GET /api/v1/debug/mock-status` 调试专用接口,不在 SDK)。

## 9. 不做的事

- **不支持 mock 多用户切换**(如 `/login?as=admin`)。0.5.0 保持单 mock user;需要多用户可以在接入方的 provisioner 里按 host / env 切不同的 claims,或者未来加 `mock_users: {...}` map + 默认 pick。
- **不做 "mock=auto"**(根据环境自动决定)。显式 true/false,运维决定。
- **不持久化 mock RSA keypair**、**不支持把 mock 私钥写进 yaml**。每次进程启动都是新 keypair,这是 feature 不是 bug:省掉密钥管理 + 杜绝"把测试密钥误配到生产"。
- **不 mock blade-os 的 casdoor 管理 API**(`casdoor_adapter.py` 里的 `get_user` / `sync_access_state` 等)。那是 blade-os 自己的事,SDK 不管 —— mock 模式下接入方要么别调这些管理 API(本地 dev 常态),要么自己包一层 mock。
- **不改变 `LazyProvisioner` 契约**。`provision_user` 收 `CasdoorClaims`,跟 prod 模式完全一致,接入方 provisioner 零感知。
- **不新增 `MockTokenVerifier`**。mock 只替换 `JwksCache` 和 `OidcClient` 两个 HTTP 边界实现,`TokenVerifier` / deps / router / cookie 全部复用真代码路径。

## 10. 交付清单

- [ ] `src/blade_auth_client/config.py`:加 `MockUserConfig`,`OAuthConfig.mock` / `mock_user` 字段 + `model_validator` 保证 `mock=True ⇒ mock_user` 必填
- [ ] 新增 `src/blade_auth_client/mock/`:
  - [ ] `local_casdoor.py`:`LocalCasdoor`(RSA keypair 生成 + `mint_token` + `jwks`)
  - [ ] `oidc_client.py`:`MockOidcClient`(委托 `LocalCasdoor.mint_token`)
  - [ ] `jwks_cache.py`:`MockJwksCache`(委托 `LocalCasdoor.public_key`)
- [ ] `src/blade_auth_client/facade.py`:`BladeAuth.__init__` 按 `config.oauth.mock` 在 `JwksCache` / `OidcClient` 两个点分流 + WARN log。**不加 `is_mock` property**(见 §6.4:接入方不该 branch mock 逻辑)
- [ ] `src/blade_auth_client/fastapi/router.py`:`/login` 加 mock short-circuit 分支(调 `local_casdoor.mint_token` + 走真 verifier + provisioner)。**`/providers` 响应不动**(见 §6.4:不把 mock 标志泄漏到对外 JSON)
- [ ] 不改:`TokenVerifier` / `JwksCache` 抽象、`authenticate_request` / deps.py、cookie/policy.py、`LazyProvisioner` 协议
- [ ] `tests/test_mock.py`:
  - [ ] mock=true 的 BladeAuth 构造 + WARN log 命中
  - [ ] `/login` 在 mock 下 302 到 next + 写 cookie + provisioner 被调 + claims 是 mock_user
  - [ ] cookie 里的 token 是真 JWT(pyjwt decode 不带 signature verify 能拿到 claims)
  - [ ] 后续 `Depends(auth.require())` 能接住,provisioner 命中 "非首次" 分支
  - [ ] `/oauth/casdoor/callback` 手动 GET 带 code 也能跑通(测试 callback 路径仍被 mock 覆盖)
  - [ ] mock=true 但 mock_user 未填 → `AuthConfig.from_yaml` 抛 ValueError
  - [ ] `/providers` 响应带 `mock: true`
  - [ ] 切回 mock=false,`isinstance(auth._jwks_cache, JwksCache)` 真 JwksCache 恢复
- [ ] `docs/接入指南.md`:加一小节"本地开发 mock 模式"指向本文
- [ ] `docs/examples/oauth_config.example.yaml`:注释里展示 mock 用法
- [ ] blade-os 侧 follow-up(跨仓 PR):
  - [ ] `tests/backend/conftest.py` 里 `_TestOidcClient` / `_StaticJwksCache` / `_test_build_auth` 胶水 90% 删除,改走 mock:true yaml
  - [ ] `configs/oauth_config.example.yaml` 注释里说明 "本地 dev 可以直接 mock: true,不需要起 Casdoor"

## 11. 向后兼容

- `mock` 字段默认 `false`,老 yaml 不动 → 行为零变化
- 无 deprecation:这是纯增量新能力

## 12. 版本路线

| 版本 | 内容 |
| --- | --- |
| 0.4.0(当前) | BladeAuth facade 已落地,不含 mock |
| **0.5.0** | mock 模式 + 移除 0.4.0 标废的老名字(OidcClient/TokenVerifier/create_auth_router 等顶层 re-export) |
| 0.6.0 预留 | 多 mock 用户切换(按需) |
