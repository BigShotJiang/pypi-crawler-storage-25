# 实现文档：SDK 对外概念收敛

- 作者：yanbingzheng
- 日期：2026-04-23
- 目标版本：`blade-auth-client` 0.4.0
- 前置：`设计-TODO配置重构.md`（0.3.0 先落地 yaml + deploy_mode + 命名从 casdoor 泛化到 oauth）

## 1. 问题

现在 `blade_auth_client.__init__.py` 顶层 re-export **26 个名字**，其中只有 4 个是接入方真正要写的，其余 22 个都是 SDK 内部装配零件。接入方被迫亲手 `OidcClient(config)` / `TokenVerifier(config)`，再一堆穿针引线。

## 2. 目标

- 对外概念收敛到 **6 个**：`BladeAuth`、`AuthConfig`、`LazyProvisioner`、`CasdoorClaims`、`SqlAlchemyProvisioner`、`AuthError`（+ 子类）。
- 接入方代码只做两件事：**构造一个 `BladeAuth` + 实现一个 `LazyProvisioner`**。
- 其余 20 个导出降级为内部实现，文件保留、`__all__` 不导出。
- **顺便**：`LazyProvisioner` 的方法 `ensure_user` → **`provision_user`** 同步改名，与类名 `Provisioner` / 异常名 `UserProvisionError` 统一在 "provision" 这个身份圈术语上。老名字 `ensure_user` 0.4.0 保留为 alias 并打 `DeprecationWarning`，0.5.0 移除。现在只有 blade-os 一家用，改名窗口成本最低就是现在。

## 3. 对外 API

### 3.1 保留（public）

| 名字 | 用途 |
| --- | --- |
| `BladeAuth` | **新增的 facade**，封装 oidc / verifier / router / deps / socketio |
| `AuthConfig` | 配置对象，`AuthConfig.from_yaml(path)` |
| `LazyProvisioner` | 接入方要实现的 Protocol，方法改名 `ensure_user` → `provision_user`（见 §2、§3.3） |
| `CasdoorClaims` | 传给 provisioner 的 dataclass |
| `SqlAlchemyProvisioner` | 现成的 provisioner 实现 |
| `AuthError` + 子类 | `ExpiredTokenError` / `InvalidTokenError` / `InvalidAudienceError` / `JwksUnavailableError` / `CasdoorError` / `UserProvisionError` |

### 3.2 降级为内部（不再顶层 re-export）

```
OidcClient, TokenVerifier, JwksCache,
AuthMiddleware, make_auth_middleware, socketio_auth,
create_auth_router, make_current_user_dep, make_require_auth_dep,
authenticate_request,
build_callback_url,
read_session_token, write_session_cookie, clear_session_cookie,
verify_token
```

文件不动，只是从 `__init__.py` 的 `__all__` / `_EXPORTS` 移除。内部互 import 时走原路径 `blade_auth_client.casdoor.client.OidcClient` 等。

### 3.3 `LazyProvisioner` 方法改名

```python
class LazyProvisioner(Protocol[UserT]):
    async def provision_user(self, claims: CasdoorClaims) -> UserT:
        """按 claims 建用户（首次）或更新可变字段后返回（非首次）。"""
        ...

    # 0.4.0 兼容 alias；触发 DeprecationWarning；0.5.0 移除
    async def ensure_user(self, claims: CasdoorClaims) -> UserT: ...
```

改名理由：

- 与类名 `LazyProvisioner` / 异常名 `UserProvisionError` 统一在 "provision" 一词上
- `provision` 在身份圈（SCIM / SAML）是精确术语："在本地系统里为 provider 身份开户"
- 保留 `_user` 后缀（而非裸 `provision`），避免在 `async def provision(self, claims)` 这种带单参方法里被误读为动作名词

**向后兼容**：SDK 里 `Provisioner` 实现类同时检查两个方法名，老实现继续跑但打 `DeprecationWarning("ensure_user is deprecated since 0.4.0, use provision_user instead; will be removed in 0.5.0")`。

## 4. `BladeAuth` Facade

### 4.1 构造

```python
class BladeAuth(Generic[UserT]):
    def __init__(
        self,
        config: AuthConfig,
        *,
        provisioner: LazyProvisioner[UserT],
        me_serializer: MeSerializer | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._config = config
        self._provisioner = provisioner
        self._verifier = TokenVerifier(config)           # 内部 new
        self._oidc = OidcClient(config, http_client)     # 内部 new
        self._me_serializer = me_serializer
```

### 4.2 对外方法 / 属性

```python
@property
def config(self) -> AuthConfig: ...
@property
def router(self) -> APIRouter:                # 替代 create_auth_router
    ...
def require(self) -> Any:                     # 替代 make_require_auth_dep，返回 FastAPI Depends
    ...
def current(self) -> Any:                     # 替代 make_current_user_dep
    ...
async def socketio_handshake(                 # 替代 make_auth_middleware
    self, sid: str, environ: dict, auth: Any
) -> UserT | None: ...
async def verify(self, token: str) -> CasdoorClaims:   # 偶尔有人要手动校 token
    ...
```

`router` / `require` / `current` 做 lazy 构造 + 缓存（第一次访问才 build），避免 FastAPI app 启动时就强拉 JWKS。

## 5. 接入方改造示例

### 5.1 新接入方:从零到登录闭环(0.4.0 形态)

接入方只做 **两件事**:

1. 写一个 `LazyProvisioner.provision_user(claims) -> MyUser`,把 provider 用户落到自己的 DB
2. 构造 `BladeAuth` + 挂 router

```python
# app/auth.py
from blade_auth_client import AuthConfig, BladeAuth, CasdoorClaims, LazyProvisioner
from app.models import User, OAuthAccount
from app.db import session_factory

class MyProvisioner(LazyProvisioner[User]):
    async def provision_user(self, claims: CasdoorClaims) -> User:
        with session_factory() as db:
            binding = db.query(OAuthAccount).filter_by(
                provider="casdoor", provider_account_id=claims.sub,
            ).first()
            if binding is None:
                # 首次登录:建 User + 建 OAuth 绑定
                user = User(email=claims.email, display_name=claims.name, ...)
                db.add(user); db.flush()
                db.add(OAuthAccount(user_id=user.id, provider="casdoor",
                                    provider_account_id=claims.sub))
            else:
                user = db.get(User, binding.user_id)
                user.email = claims.email          # 刷可变字段
            db.commit()
            return user

auth = BladeAuth(
    AuthConfig.from_yaml("configs/oauth_config.yaml"),
    provisioner=MyProvisioner(),
)
```

```python
# app/main.py
from fastapi import FastAPI, Depends
from app.auth import auth

app = FastAPI()
app.include_router(auth.router, prefix="/api/v1/auth")

@app.get("/projects")
def list_projects(user = Depends(auth.require())):     # 没登 401,user = MyProvisioner 返回值
    return repo.for_user(user.id)

@app.get("/home")
def home(user = Depends(auth.current())):              # 没登返 None
    return {"hi": user.name if user else "anon"}
```

挂上 `auth.router` 后自动就有下面这些接口(下表假设 prefix=`/api/v1/auth`):

| 用途 | 方法 | 路径 | 做了什么 |
| --- | --- | --- | --- |
| **登录** | `GET` | `/api/v1/auth/login?next=/dashboard` | 302 跳 provider 登录页,登完回 `next` |
| **回调** | `GET` | `/api/v1/auth/oauth/casdoor/callback` | 换 token / 验 JWT / 调 `provision_user`(**首次自动建用户**)/ Set-Cookie / 302 回 `next` |
| **拿身份** | `GET` | `/api/v1/auth/me` | 要先登录,返回 `me_serializer(user, claims, request)`,没登 401 |
| **登出** | `GET` | `/api/v1/auth/logout` | 清 cookie,302 到 provider 登出 URL |
| 登出(异步) | `POST` | `/api/v1/auth/logout` | 清 cookie,返回 `{"logout_url": "..."}` |
| 列 provider | `GET` | `/api/v1/auth/providers` | 前端画登录按钮用 |

**登录回调"首次建用户"的语义**:`provision_user` **每次受保护请求和每次回调都会被调**。实现方自己区分首次 / 非首次,模板就是上面那段 `if binding is None: 建 else: 更新`。

**平时拿身份**:浏览器带着 `blade_token` cookie,`Depends(auth.require())` 读 cookie → 用 JWKS 验 JWT → 调你的 `provision_user` → 返回业务 user。也可以写 middleware / 另一个 dep 里读 `request.state.blade_auth_user` / `.blade_auth_claims` / `.blade_auth_token`(命中后 SDK 会填好)。

**登出**:前端 `POST /api/v1/auth/logout` 拿到 `{logout_url}` 再跳,或直接 `GET /api/v1/auth/logout` 让 SDK 帮你跳。SDK 会清本地 session cookie + 带你跳到 provider 侧的登出路径(由 provider 决定要不要干掉 provider 会话)。

### 5.2 blade-os `auth_setup.py` 瘦身

**现状**（`backend/app/services/auth_setup.py` 约 260 行）：

- 手动 `AuthConfig(...)` 拼 env → ~20 行
- new `TokenVerifier` / `OidcClient` → ~10 行
- 包一层 `authenticate_blade_token`（调 `sdk_authenticate_request`）→ ~30 行
- 维护 `BladeOsAuthRuntime` dataclass + 全局单例 → ~30 行

**改造后**：

```python
_auth: BladeAuth[ProvisionedUser] | None = None

def get_auth() -> BladeAuth[ProvisionedUser]:
    global _auth
    if _auth is None:
        _auth = BladeAuth(
            AuthConfig.from_yaml("configs/oauth_config.yaml"),
            provisioner=BladeOsProvisioner(),
        )
    return _auth
```

调用方把 `runtime.auth_router` → `get_auth().router`、`authenticate_blade_token` 依赖 → `get_auth().require()`。预计 `auth_setup.py` 从 260 行缩到 **80 行以内**，绝大部分是 `BladeOsProvisioner.provision_user` 本身。

### 5.3 多 app 共享一套鉴权

多个服务(blade-os / agentos / 后台管理 / 其它 Python 微服务)都对接同一个 Casdoor,做到 **"用户登一次,所有 app 都认"**。

#### 5.3.1 共享 vs 独占

| 维度 | 共享 | 独占 |
| --- | --- | --- |
| Casdoor 实例 + application + client_id/secret | ✅ | — |
| JWKS(验签名的公钥) | ✅ 各 app 自己 cache,源头是同一个 | — |
| Session Cookie(`blade_token`) | ✅ 靠浏览器 cookie domain(见下)一份打天下 | — |
| `BladeAuth` 实例 | — | ❌ 每 app 自己构造一个,内部有 httpx / JWKS cache / lock |
| User 表 | — | ❌ 默认每 app 自己一份,按 `claims.sub` 做外键关联 |
| `LazyProvisioner` 实现 | — | ❌ 每 app 自己写,知道怎么落自家 DB |

**关键点:JWT 自证**。Cookie 里放的是 Casdoor 签的 JWT,任何 app 只要拿到 JWKS 公钥都能独立验,不需要 app 间共享 session store。多 app 共享的本质就是"浏览器带着同一个 JWT 到每个 app,每个 app 独立验,独立建/查自己的 user"。

#### 5.3.2 部署拓扑

```
                         ┌───────────────────────┐
                         │   Casdoor (一套)      │
                         │   application=blade-* │
                         │   JWKS + token ep     │
                         └───────┬───────────────┘
                   JWKS / token  │
                   (server-side) │
                                 │
      ┌─────────────┬────────────┴────────────┬──────────────┐
      │             │                         │              │
┌─────▼─────┐  ┌────▼──────┐            ┌─────▼─────┐  ┌─────▼─────┐
│ blade-os  │  │ agentos   │    ...     │ admin-bo  │  │ foo-svc   │
│ BladeAuth │  │ BladeAuth │            │ BladeAuth │  │ BladeAuth │
│ Provr→DB1 │  │ Provr→DB2 │            │ Provr→DB3 │  │ Provr→DB4 │
└─────▲─────┘  └────▲──────┘            └─────▲─────┘  └─────▲─────┘
      │             │                         │              │
      └─────────────┴─ Cookie: blade_token ───┴──────────────┘
                    (浏览器,domain=.company.com,所有子域带过)
```

#### 5.3.3 让浏览器一份 cookie 通吃的三个开关

1. **同一个 Casdoor application**(同 `client_id` / `client_secret`) —— 否则 JWT 的 `aud` 不同,A 的 token 到 B 验不过去。
2. **`cookie.domain` 设成父域**(yaml): `cookie.domain: .company.com`,这样 app-A 写的 cookie,浏览器访问 `b.company.com` 时会自动带上。不设 domain 的话 cookie 绑当前子域,各 app 独占。
   > 0.4.0 需要 SDK 加这个字段(现在只有 `name` / `secure` / `same_site`),见本文 §8。
3. **所有 app 的 redirect_uri 都在 Casdoor application 的白名单里**。这个是运维活,用 blade-os 的 casdoor_adapter 批量 sync 就行。

#### 5.3.4 用户视角的三条剧本

- **首次进 app-A**: app-A 未登录 → `/api/v1/auth/login` → Casdoor 登 → 回调触发 **app-A 的 `provision_user`**(A 的 DB 里建一行 user + OAuthAccount binding,key = `claims.sub`)→ Set-Cookie `blade_token` / `Domain=.company.com` → 用户正常用 app-A。
- **接着访问 app-B**: 浏览器自动把 `blade_token` 带给 app-B → 首个受保护请求触发 **app-B 的 `provision_user`**(B 的 DB 里建第一行,key 还是同一个 `claims.sub`)→ 用户**感知不到二次登录**。
- **在 app-A 登出**: `GET /api/v1/auth/logout` → 清 `blade_token`(因为是父域 cookie,**浏览器在所有子域下的这个 cookie 都会被同时擦掉**)→ 跳 Casdoor 的 logout → Casdoor 侧会话也灭。之后访问 app-B / app-C 都是未登录状态。

#### 5.3.5 各 app 的 user 表怎么关联

默认每 app 一套 user / OAuthAccount,大家都拿 `claims.sub` 做 key —— 这是"每个 app 有自己的 profile,但都认同一个身份"的 OAuth 惯例。

跨 app 做联合查询时,用 `claims.sub`(=`OAuthAccount.provider_account_id`)做 JOIN key 即可。没有一个 app 自作主张维护"全局 user 表",降低耦合。

如果强要共享 user 表,就让多个 app 的 `LazyProvisioner` 指向同一个 DB schema,并选一个 app 做 owner(其它 app 的 `provision_user` 只读 / 不改)——但**这不是 SDK 鼓励的形态**,属于业务层决定。

## 6. 异常命名空间

当前异常散在 `blade_auth_client.errors`，保持这个模块不动。顶层 re-export：

```python
from blade_auth_client import (
    AuthError,
    ExpiredTokenError,
    InvalidTokenError,
    InvalidAudienceError,
    JwksUnavailableError,
    CasdoorError,
    UserProvisionError,
)
```

（这部分本来就是 public，只是从 "26 个中的 7 个" 显式标出来，方便 review。）

## 7. 向后兼容

0.4.0 加 `DeprecationWarning`，**不删**老名字——仍能从顶层 import `OidcClient` / `create_auth_router` / 等，打 warning："moved to internal, use BladeAuth instead"。

0.5.0 才从 `__init__.py` 真正删掉。给 blade-os 一个版本窗口迁移。

## 8. 交付清单

- [ ] `src/blade_auth_client/facade.py` 新增 `BladeAuth` 类
- [ ] `src/blade_auth_client/users/provisioner.py`：`LazyProvisioner.ensure_user` → `provision_user`，保留 `ensure_user` alias + `DeprecationWarning`；SDK 内部所有调用点改走 `provision_user`
- [ ] `src/blade_auth_client/__init__.py` 改写：
  - [ ] 顶层只导 6 类 public + 异常族
  - [ ] 老名字加 `DeprecationWarning` 代理（`__getattr__`）
- [ ] `tests/test_facade.py` 新增：router / require / current / socketio 四条路径
- [ ] 现有 `tests/test_fastapi_router.py` / `test_fastapi_deps.py` / `test_socketio.py` 不动（验证内部实现没 regression）
- [ ] **多 app 共享鉴权配套（§5.3）**：
  - [ ] `CookieConfig` 加 `domain: str | None = None` 字段，`write_session_cookie` / `clear_session_cookie` 透传 `Domain=` 属性；yaml / `cookie.domain` 走通
  - [ ] `oauth_config.example.yaml` 注释里讲清 `cookie.domain` 什么时候填（父域 SSO 场景）
  - [ ] `tests/test_cookie.py` 加一条带 `domain` 的用例
  - [ ] `docs/接入指南.md` 写一段"多 app 共享鉴权"的最小配置对照（指向本文 §5.3）
- [ ] `README.md` 快速上手改用 `BladeAuth` 写法
- [ ] `docs/配置文件.md` / `docs/工作原理.md` 的示例同步
- [ ] blade-os 侧：`backend/app/services/auth_setup.py` 瘦身 PR（跨仓）
- [ ] CHANGELOG 写 0.4.0 迁移指南

## 9. 不做的事

- 不改字段名 / 不改配置文件格式（那是 0.3.0 的事）。
- 不改 deploy_mode / URL 推断逻辑（同上）。
- 不改 provisioner 协议 **结构**（入参 `CasdoorClaims`、返回 `UserT` 不变；§3.3 只是方法名 rename + alias）。
- 不改异常类型。
- 不改内部实现文件的路径或类名，只是不从顶层 re-export。
