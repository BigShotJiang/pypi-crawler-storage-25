"""ZUGFeRD EN 16931 e-invoice generation.

Converts TrustRender invoice data to CII XML, renders the visual PDF via Typst,
and combines them into a ZUGFeRD-compliant PDF/A-3b document.

Supported scope (v1):
    - Profile: EN 16931 only
    - Country: Germany (DE)
    - Currency: EUR only
    - Tax: standard VAT — single or mixed rates per invoice (e.g., 7% + 19%)
    - Invoice types: standard invoice (380) and credit note (381)

Explicitly unsupported:
    - Reverse charge, intra-community, cross-border,
      non-EUR currencies, non-DE countries

Uses ``drafthorse`` for both XML generation and PDF attachment.
No ``factur-x`` dependency needed — drafthorse handles the full pipeline.
"""

from __future__ import annotations

import datetime
from decimal import Decimal
from pathlib import Path

try:
    from drafthorse.models.accounting import ApplicableTradeTax
    from drafthorse.models.document import Document
    from drafthorse.models.party import TaxRegistration
    from drafthorse.models.payment import PaymentMeans, PaymentTerms
    from drafthorse.models.tradelines import LineItem
    from drafthorse.pdf import attach_xml
except ImportError:
    raise ImportError(
        "ZUGFeRD support requires the 'drafthorse' package. "
        "Install with: pip install trustrender[zugferd]"
    )

from .contract import ContractError


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_PAYMENT_MEANS_CODES = {
    "credit_transfer": "58",  # SEPA credit transfer
    "direct_debit": "59",     # SEPA direct debit
}

_SUPPORTED_CURRENCIES = {"EUR"}
_SUPPORTED_COUNTRIES = {"DE"}
_SUPPORTED_TYPE_CODES = {"380", "381"}  # standard invoice, credit note


# ---------------------------------------------------------------------------
# Invoice data validation (EN 16931 specific)
# ---------------------------------------------------------------------------

def validate_zugferd_invoice_data(
    data: dict, *, profile: str = "en16931",
) -> list[ContractError]:
    """Validate that data satisfies EN 16931 requirements.

    This is stricter than generic template contract validation.  It checks
    fields needed for CII XML generation, not just template rendering.

    Fails loudly on unsupported invoice shapes.
    """
    errors: list[ContractError] = []

    # --- Required top-level fields ---
    for field in ("invoice_number", "invoice_date", "due_date", "currency"):
        if field not in data or not data[field]:
            errors.append(ContractError(
                path=field,
                message=f"required for EN 16931",
                expected="string",
                actual="missing",
            ))

    # --- Invoice type ---
    invoice_type = str(data.get("invoice_type", "380"))
    if invoice_type not in _SUPPORTED_TYPE_CODES:
        errors.append(ContractError(
            path="invoice_type",
            message=f"invoice_type '{invoice_type}' is not supported; supported types are 380 (invoice) and 381 (credit note)",
            expected=f"one of {sorted(_SUPPORTED_TYPE_CODES)}",
            actual=invoice_type,
        ))

    # Credit note requires referenced_invoice; standard invoice rejects it
    ref = data.get("referenced_invoice")
    if invoice_type == "381":
        if not isinstance(ref, str) or not ref.strip():
            errors.append(ContractError(
                path="referenced_invoice",
                message="referenced_invoice is required for credit notes (type 381)",
                expected="non-empty string (original invoice number)",
                actual="missing" if ref is None else repr(ref),
            ))
    elif ref is not None:
        errors.append(ContractError(
            path="referenced_invoice",
            message="referenced_invoice is not valid for invoice type 380; only credit notes (381) reference a prior invoice",
            expected="absent",
            actual=repr(ref),
        ))

    # --- Unsupported shapes: fail loudly ---
    currency = data.get("currency", "")
    if currency and currency not in _SUPPORTED_CURRENCIES:
        errors.append(ContractError(
            path="currency",
            message=f"only EUR is supported in v1, got '{currency}'",
            expected="EUR",
            actual=currency,
        ))

    # --- Seller ---
    seller = data.get("seller")
    if not isinstance(seller, dict):
        errors.append(ContractError(
            path="seller", message="required object", expected="object", actual="missing",
        ))
    else:
        for field in ("name", "address", "city", "postal_code", "country"):
            if not seller.get(field):
                errors.append(ContractError(
                    path=f"seller.{field}",
                    message=f"required for EN 16931",
                    expected="string",
                    actual="missing",
                ))
        if not seller.get("vat_id"):
            errors.append(ContractError(
                path="seller.vat_id",
                message="seller VAT ID required for EN 16931",
                expected="string (e.g. DE123456789)",
                actual="missing",
            ))
        country = seller.get("country", "")
        if country and country not in _SUPPORTED_COUNTRIES:
            errors.append(ContractError(
                path="seller.country",
                message=f"only DE is supported in v1, got '{country}'",
                expected="DE",
                actual=country,
            ))

    # --- Buyer ---
    buyer = data.get("buyer")
    if not isinstance(buyer, dict):
        errors.append(ContractError(
            path="buyer", message="required object", expected="object", actual="missing",
        ))
    else:
        if not buyer.get("name"):
            errors.append(ContractError(
                path="buyer.name", message="required for EN 16931",
                expected="string", actual="missing",
            ))

    # --- Items ---
    items = data.get("items")
    tax_rates = set()
    if not isinstance(items, list) or not items:
        errors.append(ContractError(
            path="items", message="at least one line item required",
            expected="list", actual="missing" if items is None else "empty",
        ))
    else:
        for i, item in enumerate(items):
            if not isinstance(item, dict):
                errors.append(ContractError(
                    path=f"items[{i}]", message="must be an object",
                    expected="object", actual=type(item).__name__,
                ))
                continue
            for field in ("description", "quantity", "unit_price", "tax_rate", "line_total"):
                if field not in item:
                    errors.append(ContractError(
                        path=f"items[{i}].{field}",
                        message=f"required for EN 16931",
                        expected="number" if field != "description" else "string",
                        actual="missing",
                    ))
            if "tax_rate" in item:
                rate = item["tax_rate"]
                if isinstance(rate, (int, float)) and rate <= 0:
                    errors.append(ContractError(
                        path=f"items[{i}].tax_rate",
                        message=(
                            f"tax_rate must be > 0 (got {rate}); "
                            "zero-rated, exempt, and reverse-charge categories "
                            "are not supported in v1"
                        ),
                        expected="positive number (e.g. 7 or 19)",
                        actual=str(rate),
                    ))
                tax_rates.add(rate)

    # --- Tax entries ---
    tax_entries = data.get("tax_entries")
    if not isinstance(tax_entries, list) or not tax_entries:
        errors.append(ContractError(
            path="tax_entries", message="at least one tax entry required",
            expected="list", actual="missing",
        ))
    else:
        # Reject zero/negative rates in tax_entries
        for j, entry in enumerate(tax_entries):
            if isinstance(entry, dict):
                erate = entry.get("rate")
                if isinstance(erate, (int, float)) and erate <= 0:
                    errors.append(ContractError(
                        path=f"tax_entries[{j}].rate",
                        message=(
                            f"tax_entries rate must be > 0 (got {erate}); "
                            "zero-rated, exempt, and reverse-charge categories "
                            "are not supported in v1"
                        ),
                        expected="positive number (e.g. 7 or 19)",
                        actual=str(erate),
                    ))

        # Bidirectional consistency: item rates ↔ tax_entries rates
        entry_rates = {e.get("rate") for e in tax_entries if isinstance(e, dict)}

        # Every item tax rate must have a matching tax_entries entry
        missing_from_entries = tax_rates - entry_rates
        if missing_from_entries:
            errors.append(ContractError(
                path="tax_entries",
                message=f"tax_entries missing for item rate(s): {sorted(missing_from_entries)}",
                expected=f"entry for each rate in items ({sorted(tax_rates)})",
                actual=f"entries for {sorted(entry_rates)}",
            ))

        # Every non-zero tax_entries rate must appear in items
        orphan_rates = entry_rates - tax_rates
        if orphan_rates:
            # Check if orphan entries have zero basis — allow if truly zero
            for entry in tax_entries:
                if not isinstance(entry, dict):
                    continue
                rate = entry.get("rate")
                if rate in orphan_rates:
                    basis = entry.get("basis", 0)
                    if isinstance(basis, (int, float)) and basis != 0:
                        errors.append(ContractError(
                            path="tax_entries",
                            message=f"tax_entries rate {rate}% has non-zero basis but no items use that rate",
                            expected="matching items or zero basis",
                            actual=f"basis={basis}",
                        ))

    # --- Totals ---
    totals_numeric = True
    for field in ("subtotal", "tax_total", "total"):
        val = data.get(field)
        if val is None or not isinstance(val, (int, float)):
            errors.append(ContractError(
                path=field,
                message=f"required numeric value for EN 16931",
                expected="number",
                actual="missing" if val is None else type(val).__name__,
            ))
            totals_numeric = False

    # --- Arithmetic consistency ---
    # Only check when all totals are numeric (otherwise we already reported above).
    if totals_numeric and isinstance(items, list) and items:
        subtotal = data.get("subtotal", 0)
        tax_total = data.get("tax_total", 0)
        total = data.get("total", 0)

        # sum(line_total) == subtotal
        line_totals = [
            item["line_total"]
            for item in items
            if isinstance(item, dict) and isinstance(item.get("line_total"), (int, float))
        ]
        if line_totals:
            expected_subtotal = round(sum(line_totals), 2)
            if round(abs(expected_subtotal - subtotal), 2) > 0.01:
                errors.append(ContractError(
                    path="subtotal",
                    message=f"subtotal ({subtotal}) does not match sum of line totals ({expected_subtotal})",
                    expected=str(expected_subtotal),
                    actual=str(subtotal),
                ))

        # sum(tax_entries.amount) == tax_total
        if isinstance(tax_entries, list) and tax_entries:
            entry_amounts = [
                e["amount"]
                for e in tax_entries
                if isinstance(e, dict) and isinstance(e.get("amount"), (int, float))
            ]
            if entry_amounts:
                expected_tax = round(sum(entry_amounts), 2)
                if round(abs(expected_tax - tax_total), 2) > 0.01:
                    errors.append(ContractError(
                        path="tax_total",
                        message=f"tax_total ({tax_total}) does not match sum of tax entry amounts ({expected_tax})",
                        expected=str(expected_tax),
                        actual=str(tax_total),
                    ))

        # subtotal + tax_total == total
        expected_total = round(subtotal + tax_total, 2)
        if round(abs(expected_total - total), 2) > 0.01:
            errors.append(ContractError(
                path="total",
                message=f"total ({total}) does not match subtotal + tax_total ({expected_total})",
                expected=str(expected_total),
                actual=str(total),
            ))

    # --- Payment ---
    payment = data.get("payment")
    if not isinstance(payment, dict):
        errors.append(ContractError(
            path="payment", message="payment details required for EN 16931",
            expected="object", actual="missing",
        ))
    else:
        means = payment.get("means", "")
        if means and means not in _PAYMENT_MEANS_CODES:
            errors.append(ContractError(
                path="payment.means",
                message=f"unsupported payment means: '{means}'",
                expected=f"one of {list(_PAYMENT_MEANS_CODES.keys())}",
                actual=means,
            ))
        if means == "credit_transfer" and not payment.get("iban"):
            errors.append(ContractError(
                path="payment.iban",
                message="IBAN required for credit transfer",
                expected="string",
                actual="missing",
            ))

    # --- Unsupported features: fail loudly ---
    # Allowances and charges are hardcoded to zero in XML generation.
    # If data contains these fields, the visual PDF could show them but the
    # embedded XML would disagree — a compliance failure.  Reject early.
    for field in ("allowances", "charges", "discounts"):
        if data.get(field):
            errors.append(ContractError(
                path=field,
                message=f"allowances/charges/discounts not supported in v1 (field '{field}' present)",
                expected="absent or empty",
                actual=f"{len(data[field])} entries" if isinstance(data[field], list) else "present",
            ))

    return errors


# ---------------------------------------------------------------------------
# XML generation
# ---------------------------------------------------------------------------

def _parse_date(date_str: str) -> datetime.date:
    """Parse an ISO date string (YYYY-MM-DD) to a date object."""
    return datetime.date.fromisoformat(date_str)


_GUIDELINE_IDS = {
    "en16931": "urn:cen.eu:en16931:2017",
}


def build_invoice_xml(data: dict, *, profile: str = "en16931") -> bytes:
    """Convert TrustRender invoice data dict to CII XML bytes.

    Uses ``drafthorse`` to build a UN/CEFACT Cross Industry Invoice
    document conforming to EN 16931.

    Args:
        data: Invoice data dict matching the einvoice_data.json schema.
        profile: ``"en16931"`` (default).

    Returns:
        UTF-8 encoded CII XML bytes.

    Raises:
        ValueError: If data is invalid or XML generation fails.
    """
    doc = Document()

    # --- Context: guideline ---
    doc.context.guideline_parameter.id = _GUIDELINE_IDS[profile]

    # --- Header ---
    doc.header.id = data["invoice_number"]
    doc.header.type_code = str(data.get("invoice_type", "380"))
    doc.header.issue_date_time = _parse_date(data["invoice_date"])

    # --- Seller ---
    seller_data = data["seller"]
    seller = doc.trade.agreement.seller
    seller.name = seller_data["name"]
    seller.address.line_one = seller_data["address"]
    seller.address.city_name = seller_data["city"]
    seller.address.postcode = seller_data["postal_code"]
    seller.address.country_id = seller_data["country"]
    seller.tax_registrations.add(
        TaxRegistration(id=("VA", seller_data["vat_id"]))
    )
    # Contact details (EXTENDED profile only — optional for EN 16931)
    if seller_data.get("email"):
        seller.contact.email.address = seller_data["email"]
    if seller_data.get("phone"):
        seller.contact.telephone.number = seller_data["phone"]

    # --- Buyer ---
    buyer_data = data["buyer"]
    buyer = doc.trade.agreement.buyer
    buyer.name = buyer_data["name"]
    if buyer_data.get("address"):
        buyer.address.line_one = buyer_data["address"]
    if buyer_data.get("city"):
        buyer.address.city_name = buyer_data["city"]
    if buyer_data.get("postal_code"):
        buyer.address.postcode = buyer_data["postal_code"]
    if buyer_data.get("country"):
        buyer.address.country_id = buyer_data["country"]

    # --- Line items ---
    for i, item in enumerate(data["items"]):
        li = LineItem()
        li.document.line_id = str(i + 1)
        li.product.name = item["description"]
        li.agreement.net.amount = Decimal(str(item["unit_price"]))
        li.agreement.net.basis_quantity = (Decimal("1.0000"), item.get("unit", "C62"))
        li.delivery.billed_quantity = (
            Decimal(str(item["quantity"])),
            item.get("unit", "C62"),
        )
        li.settlement.trade_tax.type_code = "VAT"
        li.settlement.trade_tax.category_code = "S"  # Standard rate
        li.settlement.trade_tax.rate_applicable_percent = Decimal(str(item["tax_rate"]))
        li.settlement.monetary_summation.total_amount = Decimal(str(item["line_total"]))
        doc.trade.items.add(li)

    # --- Delivery ---
    # BT-72 actual delivery date (required for EN 16931 unless invoicing period used)
    doc.trade.delivery.event.occurrence = _parse_date(data["invoice_date"])
    # BT-80 country of delivery
    doc.trade.delivery.ship_to.address.country_id = buyer_data.get("country", seller_data["country"])
    if buyer_data.get("city"):
        doc.trade.delivery.ship_to.address.city_name = buyer_data["city"]
    if buyer_data.get("postal_code"):
        doc.trade.delivery.ship_to.address.postcode = buyer_data["postal_code"]

    # --- Settlement ---
    settlement = doc.trade.settlement
    settlement.currency_code = data["currency"]

    # Payment means
    payment = data["payment"]
    pm = PaymentMeans()
    pm.type_code = _PAYMENT_MEANS_CODES.get(payment["means"], "58")
    if payment.get("iban"):
        pm.payee_account.iban = payment["iban"]
    if payment.get("bic"):
        pm.payee_institution.bic = payment["bic"]
    settlement.payment_means.add(pm)

    # Payment terms
    terms = PaymentTerms()
    if data.get("notes"):
        terms.description = data["notes"]
    terms.due = _parse_date(data["due_date"])
    settlement.terms.add(terms)

    # Tax summary
    for entry in data["tax_entries"]:
        tax = ApplicableTradeTax()
        tax.calculated_amount = Decimal(str(entry["amount"]))
        tax.type_code = "VAT"
        tax.basis_amount = Decimal(str(entry["basis"]))
        tax.category_code = "S"  # Standard rate
        tax.rate_applicable_percent = Decimal(str(entry["rate"]))
        settlement.trade_tax.add(tax)

    # Referenced invoice (BT-25) for credit notes
    if str(data.get("invoice_type", "380")) == "381" and data.get("referenced_invoice"):
        settlement.invoice_referenced_document.issuer_assigned_id = data["referenced_invoice"]

    # Monetary summation
    ms = settlement.monetary_summation
    ms.line_total = Decimal(str(data["subtotal"]))
    ms.charge_total = Decimal("0.00")
    ms.allowance_total = Decimal("0.00")
    ms.tax_basis_total = Decimal(str(data["subtotal"]))
    ms.tax_total = (Decimal(str(data["tax_total"])), data["currency"])
    ms.grand_total = Decimal(str(data["total"]))
    ms.due_amount = Decimal(str(data["total"]))

    return doc.serialize(schema="FACTUR-X_EN16931")


# ---------------------------------------------------------------------------
# XML validation (shared by render pipeline and readiness)
# ---------------------------------------------------------------------------


def validate_zugferd_xml(xml_bytes: bytes) -> list[str] | None:
    """Run XSD + Schematron validation on generated ZUGFeRD XML.

    Returns:
        None — facturx not installed, validation unavailable.
        []   — valid (both XSD and Schematron passed).
        [errors...] — list of validation error messages.
    """
    try:
        from facturx import xml_check_xsd
    except ImportError:
        return None

    errors: list[str] = []

    try:
        xml_check_xsd(xml_bytes)
    except Exception as exc:
        errors.append(f"XSD validation failed: {exc}")
        return errors  # Skip Schematron if XSD fails

    try:
        from facturx.facturx import xml_check_schematron
        xml_check_schematron(xml_bytes)
    except ImportError:
        pass  # Schematron not available in this facturx build
    except Exception as exc:
        errors.append(f"Schematron validation failed: {exc}")

    return errors


# ---------------------------------------------------------------------------
# PDF post-processing
# ---------------------------------------------------------------------------

def apply_zugferd(pdf_bytes: bytes, xml_bytes: bytes, *, lang: str = "de") -> bytes:
    """Combine a visual PDF with CII XML into a ZUGFeRD PDF/A-3b document.

    Uses ``drafthorse.pdf.attach_xml`` to:
    - Embed the XML as an Associated File
    - Set PDF/A-3b markers
    - Add ZUGFeRD XMP metadata (fx: namespace)
    - Set output intents

    Args:
        pdf_bytes: Visual PDF rendered by Typst.
        xml_bytes: CII XML from ``build_invoice_xml()``.
        lang: RFC 3066 language code (default: "de").

    Returns:
        ZUGFeRD-compliant PDF/A-3b bytes.
    """
    return attach_xml(pdf_bytes, xml_bytes, level="EN 16931", lang=lang)
