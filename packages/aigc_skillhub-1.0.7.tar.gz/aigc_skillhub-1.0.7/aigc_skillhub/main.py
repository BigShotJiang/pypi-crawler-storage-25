import argparse
import json
import os
import sys
from pathlib import Path

import requests


CLI_VERSION = "1.0.7"
CONFIG_PATH = Path.home() / ".aigc" / "config.json"
BASE_URL = os.environ.get("AIGC_API_URL", "https://api.registry.aigcpl.com").rstrip("/")
DEFAULT_REQUEST_TIMEOUT = int(os.environ.get("AIGC_REQUEST_TIMEOUT", "20"))
DEFAULT_USE_TIMEOUT = int(os.environ.get("AIGC_USE_TIMEOUT", "600"))
ONBOARDING_SKILL_URL = f"{BASE_URL}/api/v1/onboarding/skillhub/SKILL.md"
ONBOARDING_PACKAGE_URL = f"{BASE_URL}/api/v1/onboarding/skillhub/aigc-skillhub-cli.zip"


def get_config():
    if not CONFIG_PATH.exists():
        return {}
    return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))


def save_config(config):
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")


def get_license_key(required=True):
    key = get_config().get("license_key")
    if required and not key:
        print("未登录。请先执行：aigc-skillhub login <你的密钥>")
        sys.exit(1)
    return key


def auth_headers():
    return {"Authorization": f"Bearer {get_license_key()}"}


def request_json(method, path, timeout=None, **kwargs):
    try:
        response = requests.request(method, f"{BASE_URL}{path}", timeout=timeout or DEFAULT_REQUEST_TIMEOUT, **kwargs)
    except requests.RequestException as exc:
        print(f"请求失败：无法连接 SkillHub Runtime。当前 API：{BASE_URL}")
        print(f"错误详情：{exc}")
        sys.exit(1)
    return response


def fetch_authorized_skills():
    response = request_json("GET", "/api/v1/runtime/skills", headers=auth_headers())
    if response.status_code != 200:
        print(f"获取授权技能失败：{response.text}")
        sys.exit(1)
    return response.json()


def skill_type_label(skill_data):
    schema = skill_data.get("input_schema") or {}
    properties = schema.get("properties") or {}
    if properties:
        return "执行型技能"
    return "资产托管型或说明型技能"


def print_skill_usage_summary(skill_data):
    skill_code = skill_data.get("skill_code")
    display_name = skill_data.get("display_name", skill_code)
    description = skill_data.get("description") or "暂无描述"
    manifest = skill_data.get("manifest") or {}
    readable_assets = manifest.get("readable_assets") or []
    input_schema = skill_data.get("input_schema") or {}
    required = input_schema.get("required") or []

    print("\n使用说明摘要")
    print(f"- 技能：{display_name} ({skill_code})")
    print(f"- 类型：{skill_type_label(skill_data)}")
    print(f"- 作用：{description}")

    if input_schema.get("properties"):
        print("- 推荐调用：")
        print(f"  aigc-skillhub use {skill_code} --params '{{...}}'")
        if required:
            print(f"- 必填参数：{', '.join(required)}")

    if readable_assets:
        print("- 云端可读资产：")
        for asset in readable_assets[:8]:
            print(f"  - {asset.get('path')} ({asset.get('type', 'unknown')})")
        if len(readable_assets) > 8:
            print(f"  - 还有 {len(readable_assets) - 8} 个资产，可通过 inspect 查看")
        print(f"- 读取示例：aigc-skillhub read {skill_code} {readable_assets[0].get('path')}")

    print("- 给 Agent 的建议：安装后先阅读本地 SKILL.md，再按任务选择 use 或 read。")


def login(key):
    headers = {"Authorization": f"Bearer {key.strip()}"}
    response = request_json("GET", "/api/v1/runtime/license/verify", headers=headers)
    if response.status_code == 200:
        config = get_config()
        config["license_key"] = key.strip()
        save_config(config)
        data = response.json()
        print(f"登录成功：{data['license_name']} ({data['prefix']}...)")
        print("下一步：执行 aigc-skillhub list 查看当前可用技能。")
    else:
        print(f"登录失败：{response.text}")
        sys.exit(1)


def list_skills():
    skills = fetch_authorized_skills()
    print(f"当前密钥可用技能：{len(skills)} 个")
    for index, skill in enumerate(skills, 1):
        print(f"{index}. {skill['skill_code']}｜{skill['display_name']}｜{skill.get('description', '')}")
    if skills:
        print("\n安装全部技能：aigc-skillhub install --all")
        print("安装指定技能：aigc-skillhub install <skill_code>")
    return skills


def mcp_mode():
    print("MCP 模式启动中。当前版本仍以 CLI 命令桥接为主，后续会映射为标准 MCP Tools。")


def resolve_skills_root(target_dir=None):
    if target_dir:
        return Path(target_dir).expanduser().resolve()
    return CONFIG_PATH.parent / "skills"


def _skill_keywords(skill_data):
    tags = skill_data.get("tags") or []
    if isinstance(tags, str):
        tags = [tag.strip() for tag in tags.split(",") if tag.strip()]
    return tags


def _skill_trigger_text(skill_data):
    display_name = skill_data.get("display_name") or skill_data.get("skill_code")
    keywords = _skill_keywords(skill_data)
    keyword_text = "、".join(keywords[:8]) if keywords else display_name
    return f"当用户提到 {keyword_text} 或明确要求使用“{display_name}”时，优先考虑该技能。"


def sync_cli_skill_index(skills_root):
    config = get_config()
    installed_skills = config.get("installed_skills", {})
    installed_paths = config.get("installed_skill_paths", {})
    if not installed_skills:
        return

    cli_skill_dir = Path(skills_root) / "aigc-skillhub-cli"
    cli_skill_dir.mkdir(parents=True, exist_ok=True)

    lines = [
        "# 已安装 SkillHub 技能索引",
        "",
        "本文件由 `aigc-skillhub` 自动维护。用户选中 `aigc-skillhub-cli` 接入助手并提出任务时，先参考这里选择合适的已安装技能。",
        "",
    ]

    for skill_code, skill_data in sorted(installed_skills.items()):
        local_path = installed_paths.get(skill_code, str(Path(skills_root) / skill_code))
        keywords = _skill_keywords(skill_data)
        lines.extend([
            f"## {skill_data.get('display_name', skill_code)}",
            "",
            f"- 技能标识：`{skill_code}`",
            f"- 本地路径：`{local_path}`",
            f"- 简介：{skill_data.get('description') or '暂无简介'}",
            f"- 关键词：{', '.join(keywords) if keywords else '暂无'}",
            f"- 触发方式：{_skill_trigger_text(skill_data)}",
            f"- 技能说明：`{local_path}/SKILL.md`",
            "",
        ])

    index_path = cli_skill_dir / "installed-skills.md"
    index_path.write_text("\n".join(lines), encoding="utf-8")

    skill_md_path = cli_skill_dir / "SKILL.md"
    managed_block = (
        "<!-- AIGC_SKILLHUB_INSTALLED_SKILLS_START -->\n"
        "## 当前已安装技能\n\n"
        "已安装技能索引会自动写入 `installed-skills.md`。当用户通过本接入助手提出业务任务时，先读取该索引，再选择合适技能继续。\n\n"
        f"- 索引文件：`{index_path}`\n"
        "<!-- AIGC_SKILLHUB_INSTALLED_SKILLS_END -->"
    )

    if skill_md_path.exists():
        content = skill_md_path.read_text(encoding="utf-8")
        start = "<!-- AIGC_SKILLHUB_INSTALLED_SKILLS_START -->"
        end = "<!-- AIGC_SKILLHUB_INSTALLED_SKILLS_END -->"
        if start in content and end in content:
            before = content.split(start)[0].rstrip()
            after = content.split(end, 1)[1].lstrip()
            content = f"{before}\n\n{managed_block}\n\n{after}".rstrip() + "\n"
        else:
            content = content.rstrip() + "\n\n" + managed_block + "\n"
    else:
        content = f"""---
name: aigc-skillhub-cli
description: SkillHub CLI 接入助手。用于登录企业密钥、查看授权技能、安装技能并根据已安装技能索引帮助用户选择合适技能。
version: {CLI_VERSION}
homepage: {BASE_URL}/portal
metadata:
  clawdbot:
    category: SkillHub
    tokenUrl: {BASE_URL}/portal
    emoji: 🔑
  keywords:
    - SkillHub
    - aigc-skillhub
    - 技能安装
    - License Key
---

# SkillHub CLI 接入助手

当用户要求使用 SkillHub 技能时，先读取 `installed-skills.md`，再根据任务选择合适技能。

{managed_block}
"""

    skill_md_path.write_text(content, encoding="utf-8")
    print(f"- 接入助手索引：{index_path}")


def install_skill(skill_code, show_summary=True, target_dir=None):
    get_license_key()
    response = request_json("GET", f"/api/v1/runtime/skills/{skill_code}", headers=auth_headers())
    if response.status_code != 200:
        print(f"安装技能失败：{skill_code}")
        print(response.text)
        return False

    skill_data = response.json()
    config = get_config()
    skills_cache = config.get("installed_skills", {})
    skills_cache[skill_code] = skill_data
    config["installed_skills"] = skills_cache

    skills_root = resolve_skills_root(target_dir)
    local_skill_dir = skills_root / skill_code
    local_skill_dir.mkdir(parents=True, exist_ok=True)

    installed_paths = config.get("installed_skill_paths", {})
    installed_paths[skill_code] = str(local_skill_dir)
    config["installed_skill_paths"] = installed_paths
    save_config(config)

    skill_md_path = local_skill_dir / "SKILL.md"
    skill_md_content = skill_data.get("skill_md", "")
    if "aigc-skillhub use" not in skill_md_content and "aigc-skillhub read" not in skill_md_content:
        skill_md_content += (
            f"\n\n## SkillHub 调用指引\n"
            f"- 执行型调用：`aigc-skillhub use {skill_code} --params '{{...}}'`\n"
            f"- 资产型读取：`aigc-skillhub read {skill_code} <asset_path>`\n"
        )
    skill_md_path.write_text(skill_md_content, encoding="utf-8")

    manifest_path = local_skill_dir / "manifest.json"
    manifest_data = skill_data.get("manifest", {})
    manifest_path.write_text(json.dumps(manifest_data, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"技能安装成功：{skill_code}")
    print(f"- 本地目录：{local_skill_dir}")
    print(f"- 技能说明：{skill_md_path}")
    print(f"- 资产清单：{manifest_path}")
    sync_cli_skill_index(skills_root)
    if show_summary:
        print_skill_usage_summary(skill_data)
    return True


def install_all_skills(target_dir=None):
    skills = fetch_authorized_skills()
    if not skills:
        print("当前密钥没有可安装技能。")
        return

    skills_root = resolve_skills_root(target_dir)
    print(f"技能安装目录：{skills_root}")

    success_count = 0
    for skill in skills:
        print(f"\n正在安装：{skill['skill_code']}")
        if install_skill(skill["skill_code"], show_summary=False, target_dir=target_dir):
            success_count += 1

    print(f"\n批量安装完成：成功 {success_count}/{len(skills)} 个。")
    print("建议下一步：在你的 AI 工具技能面板刷新技能，或执行 aigc-skillhub inspect <skill_code> 查看某个技能的详细用法。")


def update_skills(skill_code=None, target_dir=None):
    get_license_key()
    if skill_code:
        print(f"正在更新指定技能：{skill_code}")
        if install_skill(skill_code, show_summary=False, target_dir=target_dir):
            print(f"技能已更新：{skill_code}")
            inspect_skill(skill_code)
        return

    print("正在刷新当前密钥授权的全部技能...")
    if target_dir:
        print(f"技能安装目录：{resolve_skills_root(target_dir)}")
    skills = fetch_authorized_skills()
    if not skills:
        print("当前密钥没有可更新技能。")
        return

    updated_count = 0
    for skill in skills:
        if install_skill(skill["skill_code"], show_summary=False, target_dir=target_dir):
            updated_count += 1

    print(f"\n技能更新完成：{updated_count}/{len(skills)} 个。")
    print("已刷新本地 SKILL.md 与 manifest.json。服务端执行逻辑实时生效，通常不需要升级 CLI。")


def read_asset(skill_code, asset_path):
    response = request_json(
        "GET",
        f"/api/v1/runtime/skills/{skill_code}/assets/{asset_path}",
        headers=auth_headers(),
    )
    if response.status_code == 200:
        print(response.json()["content"])
    else:
        print(f"读取资产失败：{response.text}")


def inspect_skill(skill_code):
    skill = get_config().get("installed_skills", {}).get(skill_code)
    if not skill:
        print(f"技能未安装：{skill_code}")
        print(f"请先执行：aigc-skillhub install {skill_code}")
        return

    print(f"技能名称：{skill.get('display_name', skill_code)}")
    print(f"技能标识：{skill_code}")
    print(f"技能版本：{skill.get('version', '-')}")
    print(f"技能类型：{skill_type_label(skill)}")
    print(f"适合场景：{skill.get('description') or '暂无描述'}")

    input_schema = skill.get("input_schema") or {}
    properties = input_schema.get("properties") or {}
    if properties:
        print("\n参数说明：")
        for name, schema in properties.items():
            required = "必填" if name in (input_schema.get("required") or []) else "可选"
            print(f"- {name}：{schema.get('type', 'any')}，{required}")
        print(f"\n调用示例：aigc-skillhub use {skill_code} --params '{{...}}'")

    manifest = skill.get("manifest") or {}
    readable_assets = manifest.get("readable_assets") or []
    if readable_assets:
        print("\n云端可读资产：")
        for asset in readable_assets:
            print(f"- {asset.get('path')} ({asset.get('type', 'unknown')})")
        print(f"\n读取示例：aigc-skillhub read {skill_code} {readable_assets[0].get('path')}")

    installed_paths = get_config().get("installed_skill_paths", {})
    skill_md_path = Path(installed_paths.get(skill_code, str(CONFIG_PATH.parent / "skills" / skill_code))) / "SKILL.md"
    print(f"\n本地 Skill 文档：{skill_md_path}")
    print("给 Agent 的建议：先阅读该 SKILL.md，再根据任务选择 use 或 read。")


def use_skill(skill_code, params_json_str, method=None, timeout=None):
    try:
        params = json.loads(params_json_str) if params_json_str else {}
    except json.JSONDecodeError:
        print("参数格式错误，请提供有效 JSON。示例：--params '{\"topic\":\"增长方案\"}'")
        sys.exit(1)

    headers = {**auth_headers(), "Content-Type": "application/json"}
    payload = {"params": params, "context": {"source": "cli_use_command", "method": method}}
    response = request_json(
        "POST",
        f"/api/v1/runtime/skills/{skill_code}/execute",
        headers=headers,
        json=payload,
        timeout=timeout or DEFAULT_USE_TIMEOUT,
    )
    if response.status_code == 200:
        result = response.json()
        print("执行结果：")
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"执行失败：{response.text}")


def doctor():
    print(f"SkillHub CLI 版本：{CLI_VERSION}")
    print(f"当前 API 地址：{BASE_URL}")
    print(f"配置文件：{CONFIG_PATH}")

    health = request_json("GET", "/health")
    if health.status_code == 200:
        data = health.json()
        print(f"Runtime 连通：正常，服务={data.get('service')}，技能数={data.get('skills')}")
    else:
        print(f"Runtime 连通：异常，{health.text}")
        return

    key = get_license_key(required=False)
    if not key:
        print("登录状态：未登录")
        print("下一步：aigc-skillhub login <你的密钥>")
        return

    verify = request_json("GET", "/api/v1/runtime/license/verify", headers={"Authorization": f"Bearer {key}"})
    if verify.status_code != 200:
        print(f"登录状态：密钥无效或已过期，{verify.text}")
        return

    skills = fetch_authorized_skills()
    print(f"登录状态：已登录，当前可用技能 {len(skills)} 个")


def bootstrap():
    print("SkillHub Agent 接入流程")
    print("0. 安装或升级 CLI：pip install -U aigc-skillhub 或 npm install -g aigc-skillhub@latest")
    print("1. 确认 CLI：aigc-skillhub doctor")
    print("2. 登录密钥：aigc-skillhub login <你的密钥>")
    print("3. 查看技能：aigc-skillhub list")
    print("4. 确认 AI 工具技能目录，例如 OpenClaw/Hermes/Workbuddy/悟空 的 skills 目录")
    print("5. 安装技能：aigc-skillhub install --all --target-dir <AI工具技能目录>")
    print("6. 更新技能：aigc-skillhub update --target-dir <AI工具技能目录>")
    print(f"7. 接入助手 Skill：{ONBOARDING_SKILL_URL}")
    print(f"8. 接入助手技能包：{ONBOARDING_PACKAGE_URL}")
    print("\n复制给 OpenClaw / Hermes / Workbuddy / 悟空 的提示词：")
    print("请读取 SkillHub 接入助手 Skill，并引导我完成密钥登录、查看可用技能、安装技能和使用技能。")

    key = get_license_key(required=False)
    if key:
        print("\n检测到本机已登录，当前授权技能如下：")
        list_skills()
    else:
        print("\n检测到本机尚未登录。拿到密钥后请执行：aigc-skillhub login <你的密钥>")


def main():
    parser = argparse.ArgumentParser(prog="aigc-skillhub")
    parser.add_argument("--version", action="version", version=f"%(prog)s {CLI_VERSION}")
    subparsers = parser.add_subparsers(dest="command")

    login_parser = subparsers.add_parser("login")
    login_parser.add_argument("key")

    subparsers.add_parser("list")
    subparsers.add_parser("mcp")
    subparsers.add_parser("doctor")
    subparsers.add_parser("bootstrap")

    update_parser = subparsers.add_parser("update")
    update_parser.add_argument("skill_code", nargs="?")
    update_parser.add_argument("--target-dir", help="指定 AI 工具技能根目录，技能将安装到该目录下的 <skill_code> 子目录")

    install_parser = subparsers.add_parser("install")
    install_parser.add_argument("skill_code", nargs="?")
    install_parser.add_argument("--all", action="store_true", dest="install_all")
    install_parser.add_argument("--target-dir", help="指定 AI 工具技能根目录，技能将安装到该目录下的 <skill_code> 子目录")

    read_parser = subparsers.add_parser("read")
    read_parser.add_argument("skill_code")
    read_parser.add_argument("asset_path")

    inspect_parser = subparsers.add_parser("inspect")
    inspect_parser.add_argument("skill_code")

    use_parser = subparsers.add_parser("use")
    use_parser.add_argument("skill_code")
    use_parser.add_argument("--params", default="{}", help="JSON 字符串参数")
    use_parser.add_argument("--method", help="兼容字段，Runtime 统一使用 invoke")
    use_parser.add_argument("--timeout", type=int, default=DEFAULT_USE_TIMEOUT, help="等待技能执行结果的秒数，生图/生视频建议 600 秒以上")

    args = parser.parse_args()

    if args.command == "login":
        login(args.key)
    elif args.command == "list":
        list_skills()
    elif args.command == "mcp":
        mcp_mode()
    elif args.command == "doctor":
        doctor()
    elif args.command == "bootstrap":
        bootstrap()
    elif args.command == "update":
        update_skills(args.skill_code, target_dir=args.target_dir)
    elif args.command == "install":
        if args.install_all:
            install_all_skills(target_dir=args.target_dir)
        elif args.skill_code:
            install_skill(args.skill_code, target_dir=args.target_dir)
        else:
            print("请指定技能标识，或使用：aigc-skillhub install --all")
            sys.exit(1)
    elif args.command == "read":
        read_asset(args.skill_code, args.asset_path)
    elif args.command == "inspect":
        inspect_skill(args.skill_code)
    elif args.command == "use":
        use_skill(args.skill_code, args.params, args.method, timeout=args.timeout)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
