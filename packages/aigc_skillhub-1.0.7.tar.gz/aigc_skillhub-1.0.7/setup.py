from setuptools import setup, find_packages

setup(
    name="aigc-skillhub",
    version="1.0.7",
    packages=find_packages(),
    install_requires=["requests"],
    entry_points={
        "console_scripts": [
            "aigc-skillhub=aigc_skillhub.main:main",
        ],
    },
)
