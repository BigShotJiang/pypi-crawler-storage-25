from setuptools import setup

setup(
    name="2D-Animation-lib",
    version="1.2.0",
    packages=["Animation"], 
    package_data={
        "Animation":[
            "examples/*.png"
        ]
    }, 
    include_package_data=True, 
    install_requires=["pygame"],
    author="WatermelonCode",
    description="A 2D simple animation module for pygame.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    entry_points={
        "console_scripts":[
            "run-Animation-example=Animation.__main__:main"
        ]
    }
)