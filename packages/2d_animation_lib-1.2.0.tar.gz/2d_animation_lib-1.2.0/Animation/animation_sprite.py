import pygame

class AnimationSprite:
    def __init__(self):
        if not isinstance(self, pygame.sprite.Sprite):
            raise TypeError("AnimationSprite must be used as a subclass of pygame.sprite.Sprite")

        self.animating = False
        self.target_x = 0
        self.target_y = 0
        self.total_time = 0
        self.dx = 0
        self.dy = 0

    def move_to_position_in(self, target_x: int, target_y: int, time: int):
        # 每次调用都强制重新开始动画
        self.animating = True
        self.total_time = time
        self.target_x = target_x
        self.target_y = target_y

        # 计算每帧移动距离
        self.dx = (target_x - self.rect.x) / time
        self.dy = (target_y - self.rect.y) / time

    def update_animation(self):
        if not self.animating:
            return

        
        # 移动
        self.rect.x += self.dx
        self.rect.y += self.dy
        self.total_time -= 1

        # 时间到就停止
        if self.total_time <= 0:
            self.animating = False
