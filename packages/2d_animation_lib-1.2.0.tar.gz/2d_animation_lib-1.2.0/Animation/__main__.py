"""
2D Animation Library Usage Example

2D-Animation-lib 使用示例
"""

import Animation
import pygame
from pathlib import Path

def _red(text):return f"\033[31m{text}\033[0m"

def get_examples_path(file_name : str):
    cureent_dir = Path(__file__).parent
    examples_path = cureent_dir / "examples" / file_name
    return str(examples_path)

def main():
    print("=" * 50)
    print("""
          2D-Animation-lib Usage Example
          2D-Animation-lib 使用示例
          """)
    print("=" * 50)

    examples_dir = Path(__file__).parent / "examples"
    if not examples_dir.exists():
        print(_red(f"""
        Error: Not found 'examples' folder, please ensure that '2D-Animation-lib' is installed correctly
        错误：未找到 'examples' 文件夹，请确认 '2D-Animation-lib' 是否安装正确
                   
        Path:
        {examples_dir}
        """))
        return
    
    png_files = list[examples_dir.glob("*.png")]
    if not png_files:
        print(_red(f"""
        Error: Not found any '.png' file in 'examples' folder
        错误：'examples' 文件夹下未找到任何 '.png' 文件
                   
        Path:
        {examples_dir}
        """))
        return
    
    print("starting example window...")
    print("=" * 50)

    pygame.init()

    FPS : int = 550

    screen = pygame.display.set_mode((800, 600))
    clock = pygame.time.Clock()

    Animation.add_file_path(examples_dir / "player_walk_1.png", "player_walk", 15)
    Animation.add_file_path(examples_dir / "player1.png", "player", 15)
    Animation.add_file_path(examples_dir / "player_hit_1.png", "player_hit", 15)

    print("\n")
    print(Animation.AnimationStatus("player_walk").get_settings())
    print("\n")
    print(Animation.AnimationStatus("player").get_settings())
    print("\n")
    print(Animation.AnimationStatus("player_hit").get_settings())
    print("\n")

    running : bool = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        screen.fill((255, 255, 255))

        Animation.image_show("player_walk", 100, 100, screen)
        Animation.image_show("player", 300, 100, screen)
        Animation.image_show("player_hit", 500, 100, screen)

        Animation.animation_start("player_walk", 4)
        Animation.animation_start("player", 2, _ = False)
        Animation.animation_start("player_hit", 5)

        pygame.display.flip()
        clock.tick(FPS)

if __name__ == "__main__":
    main()