import pygame

class AnimationSprite:
    """
    This class currently implements the function of "glide to x:(), y:() within () seconds" in the Scratch class.
    This class will be further improved subsequently to enable it to implement more functions.


    这个类目前是实现了类Scratch中“在（）秒内滑行到x:()，y:()”的功能。
    后续会继续完善这个类，使其能够实现更多的功能。
    """
    ...