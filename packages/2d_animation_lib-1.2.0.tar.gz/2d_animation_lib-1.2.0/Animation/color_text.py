# ========== 前景色（字体颜色） ==========
def black(text): return f"\033[30m{text}\033[0m"      # 黑色
def red(text): return f"\033[31m{text}\033[0m"        # 红色
def green(text): return f"\033[32m{text}\033[0m"      # 绿色
def yellow(text): return f"\033[33m{text}\033[0m"     # 黄色
def blue(text): return f"\033[34m{text}\033[0m"       # 蓝色
def magenta(text): return f"\033[35m{text}\033[0m"    # 品红/洋红
def cyan(text): return f"\033[36m{text}\033[0m"       # 青色
def white(text): return f"\033[37m{text}\033[0m"      # 白色

# 亮色 / 高亮前景 (90–97)
def bright_black(text): return f"\033[90m{text}\033[0m"   # 亮黑（灰）
def bright_red(text): return f"\033[91m{text}\033[0m"     # 亮红
def bright_green(text): return f"\033[92m{text}\033[0m"   # 亮绿
def bright_yellow(text): return f"\033[93m{text}\033[0m"  # 亮黄
def bright_blue(text): return f"\033[94m{text}\033[0m"    # 亮蓝
def bright_magenta(text): return f"\033[95m{text}\033[0m" # 亮品红
def bright_cyan(text): return f"\033[96m{text}\033[0m"    # 亮青
def bright_white(text): return f"\033[97m{text}\033[0m"   # 亮白

# ========== 背景色 ==========
def bg_black(text): return f"\033[40m{text}\033[0m"
def bg_red(text): return f"\033[41m{text}\033[0m"
def bg_green(text): return f"\033[42m{text}\033[0m"
def bg_yellow(text): return f"\033[43m{text}\033[0m"
def bg_blue(text): return f"\033[44m{text}\033[0m"
def bg_magenta(text): return f"\033[45m{text}\033[0m"
def bg_cyan(text): return f"\033[46m{text}\033[0m"
def bg_white(text): return f"\033[47m{text}\033[0m"

# 亮背景 (100–107)
def bg_bright_black(text): return f"\033[100m{text}\033[0m"
def bg_bright_red(text): return f"\033[101m{text}\033[0m"
def bg_bright_green(text): return f"\033[102m{text}\033[0m"
def bg_bright_yellow(text): return f"\033[103m{text}\033[0m"
def bg_bright_blue(text): return f"\033[104m{text}\033[0m"
def bg_bright_magenta(text): return f"\033[105m{text}\033[0m"
def bg_bright_cyan(text): return f"\033[106m{text}\033[0m"
def bg_bright_white(text): return f"\033[107m{text}\033[0m"

# ========== 样式 ==========
def bold(text): return f"\033[1m{text}\033[0m"       # 粗体
def dim(text): return f"\033[2m{text}\033[0m"        # 暗淡
def italic(text): return f"\033[3m{text}\033[0m"     # 斜体（部分终端支持）
def underline(text): return f"\033[4m{text}\033[0m"  # 下划线
def blink(text): return f"\033[5m{text}\033[0m"      # 闪烁（少用）
def reverse(text): return f"\033[7m{text}\033[0m"    # 反色（背景↔前景）
def hidden(text): return f"\033[8m{text}\033[0m"     # 隐藏（慎用）

# ========== 常用别名 ==========
def gray(text): return bright_black(text)   # 灰色就是亮黑
def purple(text): return magenta(text)      # 紫色常用品红替代
def pink(text): return bright_magenta(text) # 粉红 ≈ 亮品红
def orange(text): return f"\033[38;2;255;165;0m{text}\033[0m"  # 橙色


def rgb2hex(r, g, b): return f"#{r:02X}{g:02X}{b:02X}"
def hex2rgb(hex_str):
    hex_str = hex_str.lstrip('#')
    r, g, b = tuple(int(hex_str[i:i+2], 16) for i in (0, 2, 4))
    return r, g, b