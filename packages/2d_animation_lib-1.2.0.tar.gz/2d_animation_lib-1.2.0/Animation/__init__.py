"""
Animation Library
A simple 2D frame animation tool that supports loading images, automatic playback, and displaying animations.
And if you need help in the editor, use the animation_help() function to get assistance. Go ahead and try it out!

Usage Example:
    add_file_path("Path", "Animation Name")
    animation_start("Animation Name", Total Frames)
    image_show("Animation Name", x, y, Window)
Exceptions:
    NotFoundFileError - Raised when the file does not exist
    UnboundWindowError - Raised when the window is not bound
    ImageNotShowError - Raised when the image is not displayed
    NotFoundAliasError - Raised when the alias does not exist
    ValueError - Raised when the input data is inconsistent with the facts


Animation 动画库
简易 2D 帧动画工具，支持加载图片、自动播放、显示动画
以及拥有在编辑器中寻求帮助，使用 animation_help() 函数去寻求帮助，快去试试吧！

使用示例：
    add_file_path("路径", "动画名")
    animation_start("动画名", 总帧数)
    image_show("动画名", x, y, 窗口)

异常：
    NotFoundFileError  - 文件不存在时抛出
    UnboundWindowError - 窗口未绑定时抛出
    ImageNotShowError  - 图像未显示时抛出
    NotFoundAliasError - 别名不存在时抛出
    ValueError         - 填写的数据不符合事实时抛出
"""

from .Animation import *
from .animation_sprite import AnimationSprite
from .color_text import *