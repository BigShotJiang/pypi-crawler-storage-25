# yololite/__init__.py
from .main import YoloLite

__version__ = "1.1.3"
__all__ = ["YoloLite"]