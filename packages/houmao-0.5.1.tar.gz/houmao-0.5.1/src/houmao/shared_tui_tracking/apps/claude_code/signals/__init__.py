"""Claude Code signal helpers."""
