"""Packaged filesystem mailbox assets."""
