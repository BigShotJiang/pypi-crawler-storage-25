"""Strict models for the shared live-agent registry contract."""

from __future__ import annotations

from datetime import datetime
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator, model_validator

from houmao.agents.realm_controller.agent_identity import (
    normalize_managed_agent_id,
    normalize_managed_agent_name,
)
from houmao.agents.realm_controller.errors import SessionManifestError
from houmao.agents.realm_controller.gateway_models import GatewayHost, GatewayProtocolVersion
from houmao.agents.realm_controller.models import BackendKind

REGISTRY_SCHEMA_VERSION = 2
TERMINAL_KIND_TMUX: Literal["tmux"] = "tmux"


class _StrictRegistryModel(BaseModel):
    """Shared config for strict registry payloads."""

    model_config = ConfigDict(extra="forbid", strict=True)


class RegistryIdentityV1(_StrictRegistryModel):
    """Identity metadata for one live published agent."""

    backend: BackendKind
    tool: str

    @field_validator("tool")
    @classmethod
    def _tool_not_blank(cls, value: str) -> str:
        """Validate that the tool name is non-empty."""

        if not value.strip():
            raise ValueError("must not be empty")
        return value


class RegistryRuntimeV1(_StrictRegistryModel):
    """Pointers to runtime-owned state for one live session."""

    manifest_path: str
    session_root: str | None = None
    agent_def_dir: str | None = None

    @field_validator("manifest_path", "session_root", "agent_def_dir")
    @classmethod
    def _optional_not_blank(cls, value: str | None) -> str | None:
        """Validate optional runtime pointer strings."""

        if value is None:
            return None
        if not value.strip():
            raise ValueError("must not be empty")
        return value


class RegistryTerminalV1(_StrictRegistryModel):
    """Terminal-container hints for the live published session."""

    kind: Literal["tmux"] = Field(default=TERMINAL_KIND_TMUX)
    session_name: str

    @field_validator("session_name")
    @classmethod
    def _session_name_not_blank(cls, value: str) -> str:
        """Validate the terminal session name."""

        if not value.strip():
            raise ValueError("must not be empty")
        return value


class RegistryGatewayV1(_StrictRegistryModel):
    """Optional live gateway connect metadata published into the registry."""

    host: GatewayHost
    port: int
    state_path: str
    protocol_version: GatewayProtocolVersion

    @field_validator("state_path")
    @classmethod
    def _path_not_blank(cls, value: str) -> str:
        """Validate gateway state-path strings."""

        if not value.strip():
            raise ValueError("must not be empty")
        return value

    @field_validator("port")
    @classmethod
    def _port_range(cls, value: int) -> int:
        """Validate the live gateway port."""

        if value < 1 or value > 65535:
            raise ValueError("must be between 1 and 65535")
        return value


class RegistryMailboxFilesystemV1(_StrictRegistryModel):
    """Filesystem mailbox identity metadata for one live published session."""

    transport: Literal["filesystem"]
    principal_id: str
    address: str
    filesystem_root: str
    bindings_version: str

    @field_validator("principal_id", "address", "filesystem_root", "bindings_version")
    @classmethod
    def _not_blank(cls, value: str) -> str:
        """Validate non-empty mailbox metadata."""

        if not value.strip():
            raise ValueError("must not be empty")
        return value


class RegistryMailboxStalwartV1(_StrictRegistryModel):
    """Stalwart mailbox identity metadata for one live published session."""

    transport: Literal["stalwart"]
    principal_id: str
    address: str
    bindings_version: str
    jmap_url: str
    management_url: str
    login_identity: str
    credential_ref: str

    @field_validator(
        "principal_id",
        "address",
        "bindings_version",
        "jmap_url",
        "management_url",
        "login_identity",
        "credential_ref",
    )
    @classmethod
    def _not_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("must not be empty")
        return value


RegistryMailboxV1 = Annotated[
    RegistryMailboxFilesystemV1 | RegistryMailboxStalwartV1,
    Field(discriminator="transport"),
]


class LiveAgentRegistryRecordV2(_StrictRegistryModel):
    """Shared-registry ``record.json`` contract for one live published agent."""

    schema_version: int = Field(default=REGISTRY_SCHEMA_VERSION)
    agent_name: str
    agent_id: str
    generation_id: str
    published_at: str
    lease_expires_at: str
    identity: RegistryIdentityV1
    runtime: RegistryRuntimeV1
    terminal: RegistryTerminalV1
    gateway: RegistryGatewayV1 | None = None
    mailbox: RegistryMailboxV1 | None = None

    @field_validator(
        "agent_name",
        "agent_id",
        "generation_id",
        "published_at",
        "lease_expires_at",
    )
    @classmethod
    def _not_blank(cls, value: str) -> str:
        """Validate non-empty top-level registry strings."""

        if not value.strip():
            raise ValueError("must not be empty")
        return value

    @model_validator(mode="after")
    def _validate_schema_and_identity(self) -> "LiveAgentRegistryRecordV2":
        """Validate schema version, canonical name, and lease ordering."""

        if self.schema_version != REGISTRY_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {REGISTRY_SCHEMA_VERSION}")

        try:
            normalized_agent_name = normalize_managed_agent_name(self.agent_name)
            normalized_agent_id = normalize_managed_agent_id(self.agent_id)
        except SessionManifestError as exc:
            raise ValueError(str(exc)) from exc
        if normalized_agent_name != self.agent_name:
            raise ValueError("agent_name must not include leading or trailing whitespace")
        if normalized_agent_id != self.agent_id:
            raise ValueError("agent_id must not include leading or trailing whitespace")

        published_at = _parse_iso8601_timestamp(self.published_at, field_name="published_at")
        lease_expires_at = _parse_iso8601_timestamp(
            self.lease_expires_at,
            field_name="lease_expires_at",
        )
        if lease_expires_at <= published_at:
            raise ValueError("lease_expires_at must be later than published_at")
        return self


def canonicalize_registry_agent_name(value: str) -> str:
    """Validate and normalize registry-facing agent input."""

    return normalize_managed_agent_name(value)


def format_registry_validation_error(prefix: str, exc: ValidationError) -> str:
    """Return a short actionable Pydantic validation error string."""

    details: list[str] = []
    for issue in exc.errors(include_url=False):
        location = _format_error_location(issue.get("loc", ()))
        message = str(issue.get("msg", "validation failed"))
        details.append(f"{location}: {message}")
        if len(details) >= 3:
            break
    joined = "; ".join(details) if details else "validation failed"
    return f"{prefix}: {joined}"


def _format_error_location(location: object) -> str:
    """Format one Pydantic error location into a compact JSONPath-like string."""

    if not isinstance(location, tuple) or not location:
        return "$"

    path = "$"
    for item in location:
        if isinstance(item, int):
            path += f"[{item}]"
            continue
        path += f".{item}"
    return path


def _parse_iso8601_timestamp(value: str, *, field_name: str) -> datetime:
    """Parse one ISO-8601 timestamp and raise a consistent field error on failure."""

    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{field_name} must be a valid ISO-8601 timestamp") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(f"{field_name} must be a timezone-aware ISO-8601 timestamp")
    return parsed


LiveAgentRegistryRecordV2.model_rebuild()
