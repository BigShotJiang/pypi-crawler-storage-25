---
name: houmao-agent-loop-relay
description: Use Houmao's relay loop-planning and run-control skill when a user-controlled agent needs to formulate a master-owned relay loop plan or operate that run through start, status, and stop.
license: MIT
---

# Houmao Agent Loop Relay

Use this Houmao skill when a user-controlled agent needs to formulate or operate one relay loop run across named Houmao agents while keeping the user agent outside the execution loop.

`houmao-agent-loop-relay` is intentionally above the direct-operation skills and above the relay pattern page in `houmao-adv-usage-pattern`. This skill does not invent a new runtime loop engine. It turns user intent into one explicit plan, renders the final relay control graph, and routes start or follow-up control to the maintained Houmao-owned skills that already own messaging, reminders, mailbox follow-up, and relay execution guidance.

The trigger word `houmao` is intentional. Use the `houmao-agent-loop-relay` skill name directly when you intend to activate this Houmao-owned skill.

## Scope

This packaged skill covers two lanes:

- authoring a relay loop plan from user intent
- operating an accepted run through `start`, `status`, and `stop`

This packaged skill does not cover:

- making the user agent a participant in relay receipts, results, or acknowledgements
- inventing a free-forwarding policy when the plan is silent
- drawing arbitrary cyclic worker-to-worker execution as the default model
- replacing `houmao-agent-messaging`, `houmao-agent-gateway`, `houmao-agent-email-comms`, or `houmao-adv-usage-pattern`

## Workflow

1. Confirm that the user wants one relay loop plan or one run-control action rather than one ordinary direct-operation request.
2. Keep the two planes separate from the start:
   - control plane: user agent to designated master acting as loop origin
   - execution plane: origin and downstream agents using the existing relay-loop pattern
3. Treat the user agent as outside the execution loop. After the master accepts the run, the master owns liveness, supervision, downstream relay dispatch, completion evaluation, and stop handling.
4. If the user needs a new plan or a revised plan, load exactly one authoring page:
   - `authoring/formulate-loop-plan.md`
   - `authoring/revise-loop-plan.md`
   - `authoring/render-loop-graph.md`
5. If the user already has a plan and wants to operate it, load exactly one operating page:
   - `operating/start.md`
   - `operating/status.md`
   - `operating/stop.md`
6. Use the local references and templates only when they help normalize the plan or charter:
   - `references/run-charter.md`
   - `references/route-policy.md`
   - `references/result-contract.md`
   - `references/stop-modes.md`
   - `references/reporting-contract.md`
   - `references/plan-structure.md`
   - `templates/single-file-plan.md`
   - `templates/bundle-plan.md`
7. Route execution to the maintained Houmao-owned skills that own the lower-level surfaces.

## Authoring Pages

- Read [authoring/formulate-loop-plan.md](authoring/formulate-loop-plan.md) when the user has a goal but not yet one valid relay loop plan.
- Read [authoring/revise-loop-plan.md](authoring/revise-loop-plan.md) when an existing plan needs to be tightened, restricted, or re-rendered without changing the high-level objective.
- Read [authoring/render-loop-graph.md](authoring/render-loop-graph.md) when the plan needs the final Mermaid relay graph that shows who may hand off to whom, where the supervision loop lives, where the final result returns to the origin, and where completion and stop are evaluated.

## Operating Pages

- Read [operating/start.md](operating/start.md) when the user wants to send one normalized start charter to the designated master.
- Read [operating/status.md](operating/status.md) when the user wants a periodic read-only status update from the designated master for one `run_id`.
- Read [operating/stop.md](operating/stop.md) when the user wants to stop one active run, with `interrupt-first` as the default stop posture unless graceful stop was requested explicitly.

## References

- Read [references/run-charter.md](references/run-charter.md) for the normalized start charter fields that the user agent sends to the master or origin.
- Read [references/route-policy.md](references/route-policy.md) to normalize forwarding authority explicitly instead of leaving it implied.
- Read [references/result-contract.md](references/result-contract.md) for immediate receipt expectations, loop-egress responsibilities, and final-result return to the origin.
- Read [references/stop-modes.md](references/stop-modes.md) to choose between default interrupt-first stop and explicitly requested graceful stop.
- Read [references/reporting-contract.md](references/reporting-contract.md) for status, completion, and stop-summary expectations.
- Read [references/plan-structure.md](references/plan-structure.md) for the required single-file versus bundle-plan sections, script inventory fields, and canonical `plan.md` entrypoint rules.

## Templates

- Read [templates/single-file-plan.md](templates/single-file-plan.md) for the compact one-file plan form.
- Read [templates/bundle-plan.md](templates/bundle-plan.md) for the structured directory form with `plan.md` as the canonical entrypoint.

## Routing Guidance

- Route plan delivery, status requests, and stop requests to `houmao-agent-messaging`.
- Route origin reminder and live review-loop timing work to `houmao-agent-gateway`.
- Route mailbox receipt, final-result, and acknowledgement semantics referenced by the plan to `houmao-agent-email-comms`.
- Route downstream relay execution semantics to `houmao-adv-usage-pattern`, specifically the relay-loop pattern.
- Route project setup, specialist authoring, agent launch, or lifecycle management outside this loop-planning scope to their existing Houmao-owned skills.

## Guardrails

- Do not make the user agent the upstream driver of the execution loop.
- Do not allow free forwarding unless the plan says so explicitly.
- Do not treat `status` polling as a keepalive signal; the master owns liveness after accepting the run.
- Do not default to graceful stop. Default to `interrupt-first` unless the user explicitly requests graceful termination.
- Do not describe the final graph as an arbitrary agent-to-agent cycle when the real execution topology is forward relay routing plus a supervision loop.
- Do not replace the existing relay-loop pattern or restate its full mailbox and reminder protocol here; compose it through `houmao-adv-usage-pattern`.
