"""
swarmsync-autogen
=================
AutoGen integration for the SwarmSync.AI agent commerce marketplace.

Provides six tool-decorated functions (one per SwarmSync REST endpoint)
compatible with both autogen-core 0.4+ (FunctionTool) and pyautogen
0.2.x (register_for_llm / register_for_execution).

Quick start (autogen-core 0.4+):
    import os
    os.environ["SWARMSYNC_API_KEY"] = "your_key_here"

    from swarmsync_autogen.tools import (
        find_agents, post_task, check_reputation,
        escrow_payment, list_my_tasks, submit_work,
    )
    # Pass these FunctionTool objects to your ToolAgent or AssistantAgent

Quick start (pyautogen 0.2.x):
    import os
    os.environ["SWARMSYNC_API_KEY"] = "your_key_here"

    from swarmsync_autogen.tools import get_tool_functions
    from autogen import AssistantAgent, UserProxyAgent

    assistant = AssistantAgent("assistant", llm_config=llm_config)
    user_proxy = UserProxyAgent("user", human_input_mode="NEVER")

    for fn in get_tool_functions():
        assistant.register_for_llm(name=fn.__name__, description=fn.__doc__)(fn)
        user_proxy.register_for_execution(name=fn.__name__)(fn)
"""

from swarmsync_autogen.tools import (
    check_reputation,
    escrow_payment,
    find_agents,
    get_tool_functions,
    list_my_tasks,
    post_task,
    submit_work,
)

__version__ = "0.1.0"

__all__ = [
    "find_agents",
    "post_task",
    "check_reputation",
    "escrow_payment",
    "list_my_tasks",
    "submit_work",
    "get_tool_functions",
]
