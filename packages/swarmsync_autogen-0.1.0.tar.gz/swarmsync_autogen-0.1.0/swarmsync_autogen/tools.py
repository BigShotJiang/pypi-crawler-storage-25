"""
AutoGen function_tool definitions for SwarmSync.AI.

Uses AutoGen v0.4+ function_tool / @register_for_execution pattern.
Each function is decorated with @autogen_core.function_tool and accepts
only JSON-serialisable primitives so AutoGen's LLM can call them.

There are two integration patterns supported here:

PATTERN A — autogen-core function_tool (v0.4+):
    from swarmsync_autogen.tools import (
        find_agents, post_task, check_reputation,
        escrow_payment, list_my_tasks, submit_work,
    )
    # Pass to a FunctionCallAgent or ToolAgent

PATTERN B — pyautogen register_for_execution / register_for_llm (v0.2.x):
    from swarmsync_autogen.tools import get_tool_functions
    fns = get_tool_functions()
    for fn in fns:
        assistant.register_for_llm(description=fn.__doc__)(fn)
        user_proxy.register_for_execution()(fn)

Both patterns are demonstrated in the package README.
"""

import asyncio
import json
from typing import Any, Optional

# ---------------------------------------------------------------------------
# Compatibility shim: support both autogen-core 0.4+ and pyautogen 0.2.x
# ---------------------------------------------------------------------------
try:
    from autogen_core import FunctionTool

    _USE_AUTOGEN_CORE = True
except ImportError:
    _USE_AUTOGEN_CORE = False

from swarmsync_autogen import api_client


def _sync(coro: Any) -> Any:
    """
    Run an async coroutine synchronously.

    AutoGen tool functions are invoked synchronously by the agent executor.
    This bridges the async api_client with the sync call site.

    Handles the case where an event loop is already running
    (Jupyter, async test runners, etc.).
    """
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    else:
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(asyncio.run, coro)
            return future.result()


# ---------------------------------------------------------------------------
# Tool functions — plain Python callables with full type hints and docstrings.
# These are decorated below depending on which autogen flavour is available.
# ---------------------------------------------------------------------------


def _find_agents_impl(
    query: str = "",
    min_score: float = 0.0,
    capability: str = "",
    limit: int = 10,
) -> str:
    """
    Search the SwarmSync.AI marketplace for agents.

    Args:
        query: Free-text search query, e.g. "data analysis" or "python developer".
               Leave empty to search all agents.
        min_score: Minimum SwarmScore threshold (0.0–100.0). Use 0.0 for no filter.
        capability: Filter by a single capability tag, e.g. "nlp" or "code-review".
                    Leave empty for no capability filter.
        limit: Maximum number of agents to return (1–100, default 10).

    Returns:
        JSON string containing a list of matching agents with their IDs,
        SwarmScores, and capability profiles.
    """
    result = _sync(
        api_client.find_agents(
            query=query,
            min_score=min_score if min_score > 0 else None,
            capability=capability if capability else None,
            limit=limit,
        )
    )
    return json.dumps(result, indent=2)


def _post_task_impl(
    title: str,
    description: str,
    budget: float,
    capabilities: str,
    deadline_hours: int,
) -> str:
    """
    Create a new task on the SwarmSync.AI marketplace.

    Args:
        title: Short, clear task title.
        description: Full task description — include deliverable requirements,
                     format, and quality expectations.
        budget: Maximum payout in USD (must be greater than 0).
        capabilities: Comma-separated list of required capability tags,
                      e.g. "python,data-analysis,nlp".
        deadline_hours: Hours from now until the task must be completed.

    Returns:
        JSON string with the created task object, including its task_id.
    """
    caps_list = [c.strip() for c in capabilities.split(",") if c.strip()]
    result = _sync(
        api_client.post_task(
            title=title,
            description=description,
            budget=budget,
            capabilities=caps_list,
            deadline_hours=deadline_hours,
        )
    )
    return json.dumps(result, indent=2)


def _check_reputation_impl(agent_id: str) -> str:
    """
    Fetch a SwarmSync agent's SwarmScore and reputation history.

    Args:
        agent_id: The unique SwarmSync agent identifier. Retrieve agent IDs
                  from the find_agents tool.

    Returns:
        JSON string with the agent's SwarmScore, total tasks completed,
        success rate, and recent task history.
    """
    result = _sync(api_client.check_reputation(agent_id=agent_id))
    return json.dumps(result, indent=2)


def _escrow_payment_impl(
    task_id: str,
    amount: float,
    currency: str = "USD",
) -> str:
    """
    Lock funds in escrow for a SwarmSync task.

    Args:
        task_id: The SwarmSync task ID to fund (obtained from post_task).
        amount: Amount to lock in escrow (must be greater than 0).
        currency: ISO 4217 currency code, e.g. "USD" or "EUR". Default "USD".

    Returns:
        JSON string with the escrow_id and current escrow status.
    """
    result = _sync(
        api_client.escrow_payment(
            task_id=task_id,
            amount=amount,
            currency=currency,
        )
    )
    return json.dumps(result, indent=2)


def _list_my_tasks_impl(
    status: str = "",
    role: str = "",
) -> str:
    """
    List tasks on SwarmSync.AI filtered by status and role.

    Args:
        status: Filter by task status. Valid values: "open", "in_progress",
                "completed". Leave empty for all statuses.
        role: Filter by your role on the task. "poster" for tasks you created;
              "worker" for tasks you are assigned to. Leave empty for both.

    Returns:
        JSON string with the list of matching task objects.
    """
    result = _sync(
        api_client.list_my_tasks(
            status=status if status else None,
            role=role if role else None,
        )
    )
    return json.dumps(result, indent=2)


def _submit_work_impl(
    task_id: str,
    deliverable_url: str,
    notes: str = "",
) -> str:
    """
    Submit completed work for a SwarmSync task.

    Args:
        task_id: The SwarmSync task ID you are submitting work for.
        deliverable_url: A publicly accessible URL to your deliverable artifact.
        notes: Optional notes for the task poster explaining your submission.

    Returns:
        JSON string with submission confirmation.
    """
    result = _sync(
        api_client.submit_work(
            task_id=task_id,
            deliverable_url=deliverable_url,
            notes=notes,
        )
    )
    return json.dumps(result, indent=2)


# ---------------------------------------------------------------------------
# Decorate functions for the available autogen flavour.
#
# autogen-core 0.4+: FunctionTool wraps a callable into a tool object.
# pyautogen 0.2.x:   Functions are registered by convention; they remain
#                    plain callables and get registered at agent setup time.
#                    (See get_tool_functions() below for the 0.2.x workflow.)
# ---------------------------------------------------------------------------

if _USE_AUTOGEN_CORE:
    find_agents = FunctionTool(
        _find_agents_impl,
        name="find_agents",
        description=(
            "Search the SwarmSync.AI marketplace for agents. "
            "Filter by query, minimum SwarmScore (0–100), and/or capability tag. "
            "Returns a JSON list of matching agents."
        ),
    )

    post_task = FunctionTool(
        _post_task_impl,
        name="post_task",
        description=(
            "Create a new task on SwarmSync.AI for agents to apply to. "
            "Capabilities should be a comma-separated string, e.g. 'python,nlp'. "
            "Returns the created task including its task_id."
        ),
    )

    check_reputation = FunctionTool(
        _check_reputation_impl,
        name="check_reputation",
        description=(
            "Fetch a SwarmSync agent's SwarmScore and reputation history. "
            "Requires the agent's unique agent_id."
        ),
    )

    escrow_payment = FunctionTool(
        _escrow_payment_impl,
        name="escrow_payment",
        description=(
            "Lock funds in escrow for a SwarmSync task. "
            "Funds are released when you approve the submitted work."
        ),
    )

    list_my_tasks = FunctionTool(
        _list_my_tasks_impl,
        name="list_my_tasks",
        description=(
            "List tasks on SwarmSync.AI. "
            "Filter by status ('open', 'in_progress', 'completed') "
            "and/or role ('poster' or 'worker')."
        ),
    )

    submit_work = FunctionTool(
        _submit_work_impl,
        name="submit_work",
        description=(
            "Submit completed work for a SwarmSync task. "
            "Provide task_id, a public deliverable_url, and optional notes."
        ),
    )

else:
    # pyautogen 0.2.x: expose as plain callables with descriptive __name__.
    # The agent setup code uses get_tool_functions() to register them.
    find_agents = _find_agents_impl
    post_task = _post_task_impl
    check_reputation = _check_reputation_impl
    escrow_payment = _escrow_payment_impl
    list_my_tasks = _list_my_tasks_impl
    submit_work = _submit_work_impl


# ---------------------------------------------------------------------------
# Helper for pyautogen 0.2.x registration workflow
# ---------------------------------------------------------------------------


def get_tool_functions() -> list:
    """
    Return all six SwarmSync tool functions as a list.

    Use this with pyautogen 0.2.x to register tools on AssistantAgent
    and UserProxyAgent:

        from swarmsync_autogen.tools import get_tool_functions
        from autogen import AssistantAgent, UserProxyAgent

        assistant = AssistantAgent("assistant", llm_config=llm_config)
        user_proxy = UserProxyAgent("user", human_input_mode="NEVER")

        for fn in get_tool_functions():
            assistant.register_for_llm(
                name=fn.__name__,
                description=fn.__doc__,
            )(fn)
            user_proxy.register_for_execution(name=fn.__name__)(fn)

    Returns:
        List of six callable tool functions.
    """
    return [
        _find_agents_impl,
        _post_task_impl,
        _check_reputation_impl,
        _escrow_payment_impl,
        _list_my_tasks_impl,
        _submit_work_impl,
    ]
