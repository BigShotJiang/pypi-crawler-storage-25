from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml


_ACTION_SECTION_ALIASES = {
    "clean": ("clean",),
    "deduplicate": ("deduplicate",),
    "clean-deduplicate": ("clean-deduplicate", "clean_deduplicate"),
    "cluster": ("cluster",),
    "model-test": ("model-test", "model_test"),
    "split": ("split",),
    "convert-sft": ("convert-sft", "convert_sft"),
}
DEFAULT_CONFIG_FILE_NAME = "mysphinx-forge.yaml"
_PATH_LIKE_KEYS = {
    "input_file",
    "output",
    "embedding_model_path",
    "train_model_path",
    "test_model_path",
    "system_prompt_file",
}


class ConfigError(ValueError):
    """Raised when the CLI config file is invalid."""


def discover_config_path(explicit_path: str | None = None) -> Path | None:
    if explicit_path:
        path = Path(explicit_path)
        if not path.exists():
            raise ConfigError(f"未找到配置文件：{path}")
        return path.resolve()

    default_path = Path.cwd() / DEFAULT_CONFIG_FILE_NAME
    if default_path.exists():
        return default_path.resolve()
    return None


def load_cli_config(
    config_path: Path | None,
    *,
    action_hint: str | None = None,
) -> tuple[dict[str, object], set[str]]:
    if config_path is None:
        return {}, set()

    try:
        raw_config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise ConfigError(f"读取配置文件失败：{config_path}，{type(exc).__name__}: {exc}") from exc
    except yaml.YAMLError as exc:
        raise ConfigError(f"解析配置文件失败：{config_path}，{exc}") from exc

    if raw_config is None:
        return {}, set()
    if not isinstance(raw_config, dict):
        raise ConfigError("配置文件顶层必须是 YAML 对象。")

    config = dict(raw_config)
    defaults: dict[str, object] = {}
    configured_keys: set[str] = set()

    defaults_section = config.get("defaults", {})
    if defaults_section not in ({}, None):
        if not isinstance(defaults_section, dict):
            raise ConfigError("defaults 必须是对象。")
        _merge_config_section(
            defaults,
            configured_keys,
            defaults_section,
            config_dir=config_path.parent,
        )

    resolved_action = _resolve_action_hint(config, action_hint)

    for key, value in config.items():
        if key == "defaults" or key in _all_action_section_names():
            continue
        normalized_key = _normalize_option_key(key)
        defaults[normalized_key] = _resolve_config_value(
            normalized_key,
            value,
            config_dir=config_path.parent,
        )
        configured_keys.add(normalized_key)

    if resolved_action:
        for section_name in _ACTION_SECTION_ALIASES.get(resolved_action, (resolved_action,)):
            section = config.get(section_name)
            if section is None:
                continue
            if not isinstance(section, dict):
                raise ConfigError(f"{section_name} 配置节必须是对象。")
            _merge_config_section(
                defaults,
                configured_keys,
                section,
                config_dir=config_path.parent,
            )

    return defaults, configured_keys


def _resolve_action_hint(config: dict[str, Any], action_hint: str | None) -> str | None:
    if action_hint:
        return action_hint

    raw_action = config.get("action")
    if raw_action is None:
        return None
    return str(raw_action).strip() or None


def _merge_config_section(
    target: dict[str, object],
    configured_keys: set[str],
    section: dict[str, object],
    *,
    config_dir: Path,
) -> None:
    for key, value in section.items():
        normalized_key = _normalize_option_key(key)
        target[normalized_key] = _resolve_config_value(
            normalized_key,
            value,
            config_dir=config_dir,
        )
        configured_keys.add(normalized_key)


def _normalize_option_key(key: object) -> str:
    return str(key).strip().replace("-", "_")


def _resolve_config_value(option_key: str, value: object, *, config_dir: Path) -> object:
    if option_key in _PATH_LIKE_KEYS and isinstance(value, str) and value.strip():
        path = Path(value)
        if not path.is_absolute():
            return str((config_dir / path).resolve())
    return value


def _all_action_section_names() -> set[str]:
    names: set[str] = set()
    for aliases in _ACTION_SECTION_ALIASES.values():
        names.update(aliases)
    return names
