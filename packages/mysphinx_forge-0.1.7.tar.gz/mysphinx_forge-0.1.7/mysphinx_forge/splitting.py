from __future__ import annotations

from dataclasses import dataclass
import random

import pandas as pd


DEFAULT_SPLIT_RANDOM_SEED = 42
DEFAULT_STRATIFY_COLUMNS = ("category", "label", "intent")


@dataclass(slots=True)
class SplitStats:
    split_mode: str
    total_rows: int
    train_rows: int
    validation_rows: int
    test_rows: int
    validation_ratio: float
    test_ratio: float
    random_seed: int
    stratify_column: str | None = None
    group_column: str | None = None
    time_column: str | None = None
    time_ascending: bool = True
    increment_rows: int = 0
    increment_sheet_name: str | None = None


def split_dataframe(
    dataframe: pd.DataFrame,
    *,
    split_mode: str = "random",
    validation_ratio: float = 0.1,
    test_ratio: float = 0.1,
    random_seed: int = DEFAULT_SPLIT_RANDOM_SEED,
    stratify_column: str | None = None,
    group_column: str | None = None,
    time_column: str | None = None,
    time_ascending: bool = True,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, SplitStats]:
    _validate_split_ratios(validation_ratio, test_ratio)

    if split_mode == "random":
        train, validation, test = _split_random(
            dataframe,
            validation_ratio=validation_ratio,
            test_ratio=test_ratio,
            random_seed=random_seed,
        )
    elif split_mode == "stratified":
        if not stratify_column:
            raise ValueError("分层切分需要提供 stratify_column。")
        if stratify_column not in dataframe.columns:
            raise ValueError(f"未找到分层列：{stratify_column}")
        train, validation, test = _split_stratified(
            dataframe,
            stratify_column=stratify_column,
            validation_ratio=validation_ratio,
            test_ratio=test_ratio,
            random_seed=random_seed,
        )
    elif split_mode == "group":
        if not group_column:
            raise ValueError("分组切分需要提供 group_column。")
        if group_column not in dataframe.columns:
            raise ValueError(f"未找到分组列：{group_column}")
        train, validation, test = _split_group(
            dataframe,
            group_column=group_column,
            validation_ratio=validation_ratio,
            test_ratio=test_ratio,
            random_seed=random_seed,
        )
    elif split_mode == "time":
        if not time_column:
            raise ValueError("时间切分需要提供 time_column。")
        if time_column not in dataframe.columns:
            raise ValueError(f"未找到时间列：{time_column}")
        train, validation, test = _split_time(
            dataframe,
            time_column=time_column,
            validation_ratio=validation_ratio,
            test_ratio=test_ratio,
            time_ascending=time_ascending,
        )
    else:
        raise ValueError(f"不支持的切分模式：{split_mode}")

    stats = SplitStats(
        split_mode=split_mode,
        total_rows=len(dataframe),
        train_rows=len(train),
        validation_rows=len(validation),
        test_rows=len(test),
        validation_ratio=validation_ratio,
        test_ratio=test_ratio,
        random_seed=random_seed,
        stratify_column=stratify_column,
        group_column=group_column,
        time_column=time_column,
        time_ascending=time_ascending,
    )
    return train, validation, test, stats


def resolve_auto_split_mode(
    dataframe: pd.DataFrame,
    requested_mode: str,
    *,
    stratify_column: str | None = None,
) -> tuple[str, str | None]:
    if requested_mode != "auto":
        return requested_mode, stratify_column

    if stratify_column:
        if stratify_column not in dataframe.columns:
            raise ValueError(f"未找到分层列：{stratify_column}")
        return "stratified", stratify_column

    for candidate in DEFAULT_STRATIFY_COLUMNS:
        if candidate in dataframe.columns:
            return "stratified", candidate

    return "random", None


def _validate_split_ratios(validation_ratio: float, test_ratio: float) -> None:
    if not 0 <= validation_ratio < 1:
        raise ValueError("--validation-ratio 必须在 0 到 1 之间，且不能等于 1。")
    if not 0 <= test_ratio < 1:
        raise ValueError("--test-ratio 必须在 0 到 1 之间，且不能等于 1。")
    if validation_ratio + test_ratio >= 1:
        raise ValueError("--validation-ratio 与 --test-ratio 之和必须小于 1。")


def _split_random(
    dataframe: pd.DataFrame,
    *,
    validation_ratio: float,
    test_ratio: float,
    random_seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    shuffled_indices = list(dataframe.index)
    random.Random(random_seed).shuffle(shuffled_indices)
    return _split_from_indices(
        dataframe,
        shuffled_indices,
        validation_ratio=validation_ratio,
        test_ratio=test_ratio,
    )


def _split_stratified(
    dataframe: pd.DataFrame,
    *,
    stratify_column: str,
    validation_ratio: float,
    test_ratio: float,
    random_seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    train_parts: list[pd.DataFrame] = []
    validation_parts: list[pd.DataFrame] = []
    test_parts: list[pd.DataFrame] = []
    randomizer = random.Random(random_seed)

    grouped = dataframe.groupby(stratify_column, dropna=False, sort=False)
    for _, group in grouped:
        indices = list(group.index)
        randomizer.shuffle(indices)
        train_part, validation_part, test_part = _split_from_indices(
            dataframe,
            indices,
            validation_ratio=validation_ratio,
            test_ratio=test_ratio,
        )
        train_parts.append(train_part)
        validation_parts.append(validation_part)
        test_parts.append(test_part)

    return (
        _concat_frames(train_parts, template=dataframe),
        _concat_frames(validation_parts, template=dataframe),
        _concat_frames(test_parts, template=dataframe),
    )


def _split_group(
    dataframe: pd.DataFrame,
    *,
    group_column: str,
    validation_ratio: float,
    test_ratio: float,
    random_seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    group_frames = {
        group_value: group.copy()
        for group_value, group in dataframe.groupby(group_column, dropna=False, sort=False)
    }
    group_items = list(group_frames.items())
    random.Random(random_seed).shuffle(group_items)
    group_items.sort(key=lambda item: len(item[1]), reverse=True)

    train_target, validation_target, test_target = _compute_split_counts(
        len(dataframe),
        validation_ratio=validation_ratio,
        test_ratio=test_ratio,
    )
    remaining = {
        "train": train_target,
        "validation": validation_target,
        "test": test_target,
    }
    assigned = {
        "train": [],
        "validation": [],
        "test": [],
    }

    for _, group_frame in group_items:
        split_name = max(
            ("train", "validation", "test"),
            key=lambda name: (remaining[name], _split_priority(name)),
        )
        assigned[split_name].append(group_frame)
        remaining[split_name] -= len(group_frame)

    return (
        _concat_frames(assigned["train"], template=dataframe),
        _concat_frames(assigned["validation"], template=dataframe),
        _concat_frames(assigned["test"], template=dataframe),
    )


def _split_time(
    dataframe: pd.DataFrame,
    *,
    time_column: str,
    validation_ratio: float,
    test_ratio: float,
    time_ascending: bool,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    ordered = dataframe.copy()
    parsed = pd.to_datetime(ordered[time_column], errors="coerce")
    if parsed.isna().any():
        raise ValueError(f"时间列无法完整解析为日期时间：{time_column}")

    ordered["_split_time_sort_key"] = parsed
    ordered = ordered.sort_values("_split_time_sort_key", ascending=time_ascending, kind="mergesort")
    ordered = ordered.drop(columns="_split_time_sort_key")

    train_count, validation_count, test_count = _compute_split_counts(
        len(ordered),
        validation_ratio=validation_ratio,
        test_ratio=test_ratio,
    )
    train = ordered.iloc[:train_count].copy()
    validation = ordered.iloc[train_count : train_count + validation_count].copy()
    test = ordered.iloc[train_count + validation_count : train_count + validation_count + test_count].copy()
    return train, validation, test


def _split_from_indices(
    dataframe: pd.DataFrame,
    indices: list[int],
    *,
    validation_ratio: float,
    test_ratio: float,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    train_count, validation_count, test_count = _compute_split_counts(
        len(indices),
        validation_ratio=validation_ratio,
        test_ratio=test_ratio,
    )
    train_indices = indices[:train_count]
    validation_indices = indices[train_count : train_count + validation_count]
    test_indices = indices[train_count + validation_count : train_count + validation_count + test_count]
    return (
        dataframe.loc[train_indices].copy(),
        dataframe.loc[validation_indices].copy(),
        dataframe.loc[test_indices].copy(),
    )


def _compute_split_counts(
    total_rows: int,
    *,
    validation_ratio: float,
    test_ratio: float,
) -> tuple[int, int, int]:
    train_ratio = 1 - validation_ratio - test_ratio
    desired = {
        "train": total_rows * train_ratio,
        "validation": total_rows * validation_ratio,
        "test": total_rows * test_ratio,
    }
    counts = {name: int(value) for name, value in desired.items()}
    remainder = total_rows - sum(counts.values())

    for split_name, _ in sorted(
        desired.items(),
        key=lambda item: ((item[1] - counts[item[0]]), _split_priority(item[0])),
        reverse=True,
    ):
        if remainder <= 0:
            break
        counts[split_name] += 1
        remainder -= 1

    return counts["train"], counts["validation"], counts["test"]


def _split_priority(split_name: str) -> int:
    if split_name == "test":
        return 2
    if split_name == "validation":
        return 1
    return 0


def _concat_frames(frames: list[pd.DataFrame], *, template: pd.DataFrame) -> pd.DataFrame:
    if not frames:
        return template.head(0).copy()
    return pd.concat(frames, axis=0).reset_index(drop=True)
