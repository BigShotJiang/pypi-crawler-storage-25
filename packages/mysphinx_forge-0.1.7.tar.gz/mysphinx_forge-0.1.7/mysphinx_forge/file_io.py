from __future__ import annotations

import csv
import sys
from pathlib import Path
from time import perf_counter
from typing import TYPE_CHECKING, Any, Callable, Iterable, TextIO

import pandas as pd
from tqdm import tqdm

if TYPE_CHECKING:
    from mysphinx_forge.semantic_deduplication import SemanticDeduplicationMatch


SUPPORTED_EXTENSIONS = {".csv", ".xls", ".xlsx", ".xlsm"}
INCREMENT_SHEET_NAME = "increment"
DEFAULT_PROGRESS_COLOURS = [
    "red",
    "green",
    "yellow",
    "blue",
    "magenta",
    "cyan",
    "white",
]


def validate_tabular_file(file_path: str | Path) -> Path:
    path = Path(file_path)
    if not path.exists() or path.suffix.lower() not in SUPPORTED_EXTENSIONS:
        raise ValueError(
            "未检测到支持的输入文件，请提供 csv 或 Excel 文件（.csv/.xls/.xlsx/.xlsm）。"
        )
    return path


def load_dataframe(file_path: str | Path) -> pd.DataFrame:
    path = validate_tabular_file(file_path)
    if path.suffix.lower() == ".csv":
        return pd.read_csv(path, skip_blank_lines=False)
    return _concat_excel_frames(_load_excel_sheets(path).values())


def load_split_dataframes(
    file_path: str | Path,
    *,
    increment_sheet_name: str = INCREMENT_SHEET_NAME,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    path = validate_tabular_file(file_path)
    if path.suffix.lower() == ".csv":
        dataframe = pd.read_csv(path, skip_blank_lines=False)
        return dataframe, dataframe.head(0).copy()

    regular_frames: list[pd.DataFrame] = []
    increment_frames: list[pd.DataFrame] = []
    for sheet_name, dataframe in _load_excel_sheets(path).items():
        if sheet_name == increment_sheet_name:
            increment_frames.append(dataframe)
        else:
            regular_frames.append(dataframe)

    if not regular_frames:
        raise ValueError(
            f"除工作表 {increment_sheet_name!r} 外没有可切分的 Excel sheet。"
        )

    return _concat_excel_frames(regular_frames), _concat_excel_frames(increment_frames)


def iter_dataframes(file_path: str | Path, chunksize: int = 50_000) -> Iterable[pd.DataFrame]:
    path = validate_tabular_file(file_path)
    if path.suffix.lower() != ".csv":
        raise ValueError("仅 csv 文件支持分块流式处理。")
    return pd.read_csv(path, skip_blank_lines=False, chunksize=chunksize)


def count_csv_rows(file_path: str | Path) -> int:
    path = validate_tabular_file(file_path)
    if path.suffix.lower() != ".csv":
        raise ValueError("仅 csv 文件支持分块流式处理。")

    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        try:
            next(reader)
        except StopIteration:
            return 0
        return sum(1 for _ in reader)


def _load_excel_sheets(file_path: Path) -> dict[str, pd.DataFrame]:
    workbook = pd.read_excel(file_path, sheet_name=None)
    if not isinstance(workbook, dict):
        raise ValueError("Excel 工作簿读取失败。")
    return {
        str(sheet_name): dataframe.copy()
        for sheet_name, dataframe in workbook.items()
    }


def _concat_excel_frames(frames: Iterable[pd.DataFrame]) -> pd.DataFrame:
    frame_list = [frame.copy() for frame in frames]
    if not frame_list:
        return pd.DataFrame()
    return pd.concat(frame_list, axis=0, ignore_index=True)


def write_dataframe(dataframe: pd.DataFrame, output_path: str | Path) -> None:
    path = Path(output_path)
    if path.suffix.lower() == ".csv":
        dataframe.to_csv(path, index=False)
        return
    dataframe.to_excel(path, index=False)


def write_progress_message(message: str, *, stream: TextIO | None = None) -> None:
    output_stream = stream or sys.stderr
    with tqdm.external_write_mode(file=output_stream):
        print(message, file=output_stream, flush=True)


def split_dataframe_evenly(dataframe: pd.DataFrame, worker_count: int) -> list[pd.DataFrame]:
    if worker_count <= 0:
        raise ValueError("worker_count 必须大于 0。")

    total = len(dataframe)
    if total == 0:
        return []

    active_workers = min(worker_count, total)
    base_size, remainder = divmod(total, active_workers)
    chunks: list[pd.DataFrame] = []
    start = 0

    for worker_index in range(active_workers):
        extra = 1 if worker_index < remainder else 0
        end = start + base_size + extra
        chunks.append(dataframe.iloc[start:end].copy())
        start = end

    return chunks


def normalize_text_value(value: object) -> str:
    if pd.isna(value):
        return ""
    return str(value)


def process_dataframe_chunk(
    chunk: pd.DataFrame,
    worker_id: int,
    results: list[pd.DataFrame | None],
    *,
    processor: Callable[[str], Any],
    input_column: str,
    output_column: str,
    duration_column: str | None = None,
    progress_description: str | None = None,
    progress_position: int | None = None,
    progress_colours: list[str] | None = None,
) -> None:
    if input_column not in chunk.columns:
        raise ValueError(f"输入数据缺少列：{input_column}")
    if not 0 <= worker_id < len(results):
        raise ValueError("worker_id 超出 results 列表范围。")

    output_values: list[Any] = []
    durations: list[float] = []
    colour_palette = progress_colours or DEFAULT_PROGRESS_COLOURS
    progress = tqdm(
        total=len(chunk),
        desc=progress_description or f"worker-{worker_id + 1}",
        position=worker_id if progress_position is None else progress_position,
        leave=True,
        dynamic_ncols=True,
        colour=colour_palette[worker_id % len(colour_palette)] if colour_palette else None,
    )
    try:
        for text in chunk[input_column]:
            start = perf_counter()
            output_values.append(processor(normalize_text_value(text)))
            end = perf_counter()
            durations.append(end - start)
            progress.update(1)
    finally:
        progress.close()

    processed = chunk.copy()
    processed[output_column] = output_values
    if duration_column is not None:
        processed[duration_column] = durations
    results[worker_id] = processed


def append_dataframe_chunk(
    dataframe: pd.DataFrame,
    output_path: str | Path,
    *,
    wrote_header: bool,
) -> bool:
    path = Path(output_path)
    dataframe.to_csv(path, mode="a", index=False, header=not wrote_header)
    return True


def write_match_rows(
    match_rows: list["SemanticDeduplicationMatch"],
    output_path: str | Path,
    *,
    category_column: str = "category",
    append: bool = False,
) -> None:
    if not match_rows:
        return

    path = Path(output_path)
    build_match_frame(match_rows, category_column=category_column).to_csv(
        path,
        mode="a" if append else "w",
        index=False,
        header=not append or not path.exists(),
    )


def build_match_frame(
    match_rows: list["SemanticDeduplicationMatch"],
    *,
    category_column: str = "category",
) -> pd.DataFrame:
    include_category_columns = any(
        match.category is not None or match.matched_category is not None for match in match_rows
    )
    matched_category_column = f"matched_{category_column}"
    same_category_column = f"same_{category_column}"
    rows: list[dict[str, object]] = []
    for match in match_rows:
        row = {
            "row_index": match.row_index,
            "duplicate_of_row_index": match.duplicate_of_row_index,
            "text": match.text,
            "matched_text": match.matched_text,
        }
        if include_category_columns:
            row[category_column] = match.category
            row[matched_category_column] = match.matched_category
            row[same_category_column] = match.category == match.matched_category
        row["similarity"] = match.similarity
        rows.append(row)

    return pd.DataFrame(rows)
