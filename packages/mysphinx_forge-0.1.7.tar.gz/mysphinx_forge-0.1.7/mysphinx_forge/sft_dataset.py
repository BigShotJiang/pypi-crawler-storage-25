from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

from mysphinx_forge.cleaning import resolve_target_column

DEFAULT_SFT_FORMAT = "alpaca"
DEFAULT_SFT_OUTPUT_COLUMNS = (
    "category",
    "label",
    "intent",
    "output",
    "response",
    "answer",
    "target",
)


@dataclass(slots=True)
class SftConversionStats:
    format_name: str
    input_column: str
    output_column: str
    total_rows: int
    converted_rows: int
    skipped_blank_input_rows: int = 0
    skipped_blank_output_rows: int = 0

    @property
    def skipped_rows(self) -> int:
        return self.total_rows - self.converted_rows


def convert_dataframe_to_alpaca(
    dataframe: pd.DataFrame,
    *,
    target_column: str = "text",
    output_column: str = "",
    instruction: str = "",
    system_prompt: str = "",
    system_column: str = "",
) -> tuple[list[dict[str, str]], SftConversionStats]:
    resolved_input_column = resolve_target_column(dataframe, target_column)
    resolved_output_column = resolve_sft_output_column(dataframe, output_column)
    resolved_system_column = _resolve_optional_column(dataframe, system_column)

    final_instruction = instruction.strip() or _build_default_instruction(resolved_output_column)
    final_system_prompt = system_prompt.strip()
    records: list[dict[str, str]] = []
    skipped_blank_input_rows = 0
    skipped_blank_output_rows = 0

    for _, row in dataframe.iterrows():
        input_text = _cell_to_text(row[resolved_input_column])
        output_text = _cell_to_text(row[resolved_output_column])
        if not input_text:
            skipped_blank_input_rows += 1
            continue
        if not output_text:
            skipped_blank_output_rows += 1
            continue

        record = {
            "instruction": final_instruction,
            "input": input_text,
            "output": output_text,
        }
        system_text = final_system_prompt
        if resolved_system_column is not None:
            row_system = _cell_to_text(row[resolved_system_column])
            if row_system:
                system_text = row_system
        if system_text:
            record["system"] = system_text
        records.append(record)

    stats = SftConversionStats(
        format_name=DEFAULT_SFT_FORMAT,
        input_column=resolved_input_column,
        output_column=resolved_output_column,
        total_rows=len(dataframe),
        converted_rows=len(records),
        skipped_blank_input_rows=skipped_blank_input_rows,
        skipped_blank_output_rows=skipped_blank_output_rows,
    )
    return records, stats


def write_alpaca_dataset(records: list[dict[str, str]], output_path: str | Path) -> None:
    Path(output_path).write_text(
        json.dumps(records, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def resolve_sft_output_column(dataframe: pd.DataFrame, output_column: str) -> str:
    if output_column:
        if output_column in dataframe.columns:
            return output_column
        raise ValueError(f"未找到 SFT 输出列：{output_column}")

    for candidate in DEFAULT_SFT_OUTPUT_COLUMNS:
        if candidate in dataframe.columns:
            return candidate

    raise ValueError(
        "未找到 SFT 输出列。请显式传入 --sft-output-column，或确保输入表包含 "
        "category/label/intent/output/response/answer/target 之一。"
    )


def _resolve_optional_column(dataframe: pd.DataFrame, column_name: str) -> str | None:
    if not column_name:
        return None
    if column_name in dataframe.columns:
        return column_name
    raise ValueError(f"未找到列：{column_name}")


def _build_default_instruction(output_column: str) -> str:
    if output_column in {"category", "label", "intent", "target"}:
        return f"请根据用户输入判断其{output_column}，只输出{output_column}。"
    return "请根据用户输入生成合适的回复。"


def _cell_to_text(value: object) -> str:
    if pd.isna(value):
        return ""
    return str(value).strip()
