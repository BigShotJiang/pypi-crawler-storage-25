from __future__ import annotations

import copy
import multiprocessing as mp
import os
import queue
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable
from urllib.parse import urlparse

import pandas as pd

from mysphinx_forge.cleaning import resolve_target_column
from mysphinx_forge.deduplication import normalize_dedup_text
from mysphinx_forge.env_utils import load_project_env_files
from mysphinx_forge.http_client import HttpClientError, post_json
from mysphinx_forge.openai_responses import extract_chat_completion_text

SYSTEM_PROMPT = """
你是一个专业的金融客服，任务是对用户的问题进行归类。
# 输出格式（只能是以下类别中的一个）：
1. 股票
2. 基金

输出要求：
- 只能输出“股票”或“基金”
- 不要输出任何解释
- 不要输出思考过程
- 不要输出标点、换行、前后缀或其他文字
"""

MODEL_TEST_USER_INPUT = "请问退款怎么申请？"
MODEL_RESULT_COLUMN = "模型结果"
EXPECTED_RESULT_COLUMN = "预期结果"
MATCH_EXPECTED_COLUMN = "匹配预期"
MODEL_CALL_TIME_COLUMN = "模型调用时间"
DEFAULT_MODEL_TEST_MODE = "local"
DEFAULT_MODEL_TEST_API_BASE_URL = "https://api.openai.com/v1"
DEFAULT_HTTP_API_KEY_ENV_VAR = "HTTP_API_KEY"
DEFAULT_HTTP_API_KEY_HEADER = "api_key"
DEFAULT_HTTP_REQUEST_FIELD_MAP = {
    "model": "model",
    "system_prompt": "system_prompt",
    "user_input": "user_input",
    "max_new_tokens": "max_new_tokens",
    "do_sample": "do_sample",
    "temperature": "temperature",
    "top_p": "top_p",
    "top_k": "top_k",
    "repetition_penalty": "repetition_penalty",
}


@dataclass(slots=True)
class ModelTestResult:
    model_path: str
    user_input: str
    generated_text: str
    model_class: str
    tokenizer_class: str
    device: str


@dataclass(slots=True)
class BatchModelTestStats:
    total_rows: int
    target_column: str
    model_result_column: str = MODEL_RESULT_COLUMN
    model_call_time_column: str = MODEL_CALL_TIME_COLUMN
    expected_result_column: str = EXPECTED_RESULT_COLUMN
    match_expected_column: str = MATCH_EXPECTED_COLUMN
    has_expected_result: bool = False
    matched_expected_count: int = 0
    average_call_time_seconds: float = 0.0
    model_path: str = ""
    device: str = ""
    num_workers: int = 1
    batch_size: int = 1


@dataclass(slots=True)
class ModelTestRuntimeConfig:
    system_prompt: str = SYSTEM_PROMPT
    max_new_tokens: int = 64
    do_sample: bool = False
    temperature: float = 1.0
    top_p: float = 1.0
    top_k: int = 0
    repetition_penalty: float = 1.05
    batch_size: int = 8
    num_workers: int | str = "auto"
    mode: str = DEFAULT_MODEL_TEST_MODE
    api_base_url: str | None = None
    api_key: str | None = None
    api_key_header: str | None = None
    api_key_prefix: str = ""
    http_headers: dict[str, str] | None = None
    http_request_field_map: dict[str, str] | None = None
    http_extra_body: dict[str, object] | None = None


class OpenAICompatibleModelTester:
    def __init__(
        self,
        model_name: str,
        *,
        system_prompt: str = SYSTEM_PROMPT,
        do_sample: bool = False,
        temperature: float = 1.0,
        top_p: float = 1.0,
        repetition_penalty: float = 1.05,
        api_key: str | None = None,
        api_base_url: str | None = None,
        timeout_seconds: float = 60.0,
    ) -> None:
        load_project_env_files(include_project_root=False)
        self.model_name = str(model_name).strip()
        if not self.model_name:
            raise ValueError("OpenAI 接口模式需要提供模型名。")

        self.system_prompt = system_prompt.strip()
        self.do_sample = do_sample
        self.temperature = temperature
        self.top_p = top_p
        self.repetition_penalty = repetition_penalty
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY", "").strip()
        self.api_base_url = (
            api_base_url
            or os.environ.get("OPENAI_BASE_URL", "").strip()
            or DEFAULT_MODEL_TEST_API_BASE_URL
        ).rstrip("/")
        self.timeout_seconds = timeout_seconds
        self.model_class = "OpenAICompatibleChatCompletions"
        self.tokenizer_class = "remote"
        self.device = "openai-api"

        if not self.api_key:
            raise ValueError("OpenAI 接口模式需要设置 OPENAI_API_KEY 环境变量。")

    def generate_text(self, user_input: object, *, max_new_tokens: int = 64) -> str:
        return self.generate_texts([user_input], max_new_tokens=max_new_tokens)[0]

    def generate_texts(self, user_inputs: list[object], *, max_new_tokens: int = 64) -> list[str]:
        results: list[str] = []
        for user_input in user_inputs:
            prompt = "" if pd.isna(user_input) else str(user_input).strip()
            payload = {
                "model": self.model_name,
                "messages": _build_openai_messages(self.system_prompt, prompt),
                "max_tokens": max_new_tokens,
                "temperature": self.temperature if self.do_sample else 0,
                "top_p": self.top_p,
            }
            if self.repetition_penalty != 1.05:
                payload["frequency_penalty"] = max(min(1 - self.repetition_penalty, 2), -2)

            try:
                response_payload = post_json(
                    url=f"{self.api_base_url}/chat/completions",
                    payload=payload,
                    timeout_seconds=self.timeout_seconds,
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                    },
                )
            except HttpClientError as exc:
                raise ValueError(f"OpenAI 接口模型测试失败：{exc}") from exc

            generated_text = extract_chat_completion_text(
                response_payload,
                error_prefix="OpenAI 接口模型测试失败",
            ).strip()
            if not generated_text:
                raise ValueError("OpenAI 接口模型测试失败：模型未生成有效输出。")
            results.append(generated_text)
        return results


class HttpModelTester:
    def __init__(
        self,
        model_name: str | None = None,
        *,
        system_prompt: str = SYSTEM_PROMPT,
        do_sample: bool = False,
        temperature: float = 1.0,
        top_p: float = 1.0,
        top_k: int = 0,
        repetition_penalty: float = 1.05,
        api_key: str | None = None,
        api_key_header: str | None = None,
        api_key_prefix: str = "",
        api_base_url: str | None = None,
        request_field_map: dict[str, str] | None = None,
        extra_body: dict[str, object] | None = None,
        timeout_seconds: float = 60.0,
    ) -> None:
        load_project_env_files(include_project_root=False)
        self.model_name = None if model_name is None else str(model_name).strip() or None

        self.system_prompt = system_prompt.strip()
        self.do_sample = do_sample
        self.temperature = temperature
        self.top_p = top_p
        self.top_k = top_k
        self.repetition_penalty = repetition_penalty
        self.api_key = api_key or os.environ.get(DEFAULT_HTTP_API_KEY_ENV_VAR, "").strip()
        self.api_key_header = (
            api_key_header
            or os.environ.get("HTTP_API_KEY_HEADER", "").strip()
            or DEFAULT_HTTP_API_KEY_HEADER
        ).strip()
        self.api_key_prefix = _normalize_api_key_prefix(
            api_key_prefix or os.environ.get("HTTP_API_KEY_PREFIX", "")
        )
        self.api_base_url = (
            api_base_url
            or os.environ.get("HTTP_API_BASE_URL", "").strip()
        )
        self.request_field_map = _normalize_http_request_field_map(request_field_map)
        self.extra_body = dict(extra_body or {})
        self.timeout_seconds = timeout_seconds
        self.model_class = "HttpPostModelService"
        self.tokenizer_class = "remote"
        self.device = "http-api"

        if not self.api_base_url:
            raise ValueError("HTTP 接口模式需要设置请求地址，可通过 --model-test-api-base 或 HTTP_API_BASE_URL 提供。")
        if not self.api_key and not self.api_key_header:
            raise ValueError("HTTP 接口模式需要提供非空的 API Key 请求头名称。")

    def generate_text(
        self,
        user_input: object,
        *,
        max_new_tokens: int = 64,
        headers: dict[str, str] | None = None,
    ) -> str:
        return self.generate_texts(
            [user_input],
            max_new_tokens=max_new_tokens,
            headers=headers,
        )[0]

    def generate_texts(
        self,
        user_inputs: list[object],
        *,
        max_new_tokens: int = 64,
        headers: dict[str, str] | None = None,
    ) -> list[str]:
        results: list[str] = []
        request_headers = self._resolve_request_headers(headers)
        for user_input in user_inputs:
            prompt = "" if pd.isna(user_input) else str(user_input).strip()
            request_url, payload = _build_http_request(
                api_base_url=self.api_base_url,
                field_map=self.request_field_map,
                model_name=self.model_name,
                system_prompt=self.system_prompt,
                user_input=prompt,
                max_new_tokens=max_new_tokens,
                do_sample=self.do_sample,
                temperature=self.temperature,
                top_p=self.top_p,
                top_k=self.top_k,
                repetition_penalty=self.repetition_penalty,
                extra_body=self.extra_body,
            )
            try:
                response_payload = post_json(
                    url=request_url,
                    payload=payload,
                    timeout_seconds=self.timeout_seconds,
                    headers=request_headers,
                )
            except HttpClientError as exc:
                raise ValueError(f"HTTP 接口模型测试失败：{exc}") from exc

            generated_text = _extract_http_response_text(response_payload).strip()
            if not generated_text:
                raise ValueError("HTTP 接口模型测试失败：模型未生成有效输出。")
            results.append(generated_text)
        return results

    def _resolve_request_headers(
        self,
        headers: dict[str, str] | None,
    ) -> dict[str, str]:
        normalized_headers = _normalize_http_headers(headers)
        if normalized_headers is not None:
            return normalized_headers

        if not self.api_key:
            raise ValueError(
                f"HTTP 接口模式需要设置 {DEFAULT_HTTP_API_KEY_ENV_VAR} 环境变量，"
                "或在 generate_text()/generate_texts() 中传入 headers。"
            )
        if not self.api_key_header:
            raise ValueError("HTTP 接口模式需要提供非空的 API Key 请求头名称。")
        return {
            self.api_key_header: f"{self.api_key_prefix}{self.api_key}",
        }


class LocalModelTester:
    def __init__(
        self,
        model_path: str | Path,
        *,
        system_prompt: str = SYSTEM_PROMPT,
        do_sample: bool = False,
        temperature: float = 1.0,
        top_p: float = 1.0,
        top_k: int = 0,
        repetition_penalty: float = 1.05,
        device: str | None = None,
    ) -> None:
        resolved_model_path = Path(model_path)
        if not resolved_model_path.exists():
            raise ValueError(f"未找到测试模型：{resolved_model_path}")

        try:
            import torch
            from transformers import AutoModelForCausalLM, AutoModelForSeq2SeqLM, AutoTokenizer
        except ImportError as exc:
            raise ValueError("未安装模型测试所需依赖，请先执行 uv sync。") from exc

        self.model_path = resolved_model_path
        self.system_prompt = system_prompt.strip()
        self.do_sample = do_sample
        self.temperature = temperature
        self.top_p = top_p
        self.top_k = top_k
        self.repetition_penalty = repetition_penalty
        self._torch = torch
        self.device = device or _resolve_inference_device(torch)

        try:
            self.tokenizer = AutoTokenizer.from_pretrained(
                str(resolved_model_path),
                local_files_only=True,
                trust_remote_code=True,
            )
            self.model, self._is_causal = _load_generation_model(
                model_path=resolved_model_path,
                auto_causal_model=AutoModelForCausalLM,
                auto_seq2seq_model=AutoModelForSeq2SeqLM,
            )
        except Exception as exc:
            raise ValueError(f"加载测试模型失败：{type(exc).__name__}: {exc}") from exc

        self.model = self.model.to(self.device)
        if self.tokenizer.pad_token is None and self.tokenizer.eos_token is not None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        if self._is_causal:
            self.tokenizer.padding_side = "left"

        self.model_class = type(self.model).__name__
        self.tokenizer_class = type(self.tokenizer).__name__

    def generate_text(self, user_input: object, *, max_new_tokens: int = 64) -> str:
        return self.generate_texts([user_input], max_new_tokens=max_new_tokens)[0]

    def generate_texts(self, user_inputs: list[object], *, max_new_tokens: int = 64) -> list[str]:
        prompts = [
            self._build_prompt("" if pd.isna(value) else str(value).strip())
            for value in user_inputs
        ]
        encoded = self.tokenizer(prompts, return_tensors="pt", padding=True, truncation=True)
        input_ids = encoded["input_ids"].to(self.device)
        attention_mask = encoded.get("attention_mask")
        if attention_mask is not None:
            attention_mask = attention_mask.to(self.device)

        generation_config = _build_generation_config(
            model=self.model,
            max_new_tokens=max_new_tokens,
            do_sample=self.do_sample,
            temperature=self.temperature,
            top_p=self.top_p,
            top_k=self.top_k,
            repetition_penalty=self.repetition_penalty,
            pad_token_id=self.tokenizer.pad_token_id,
        )

        with self._torch.inference_mode():
            generated = self.model.generate(
                input_ids=input_ids,
                attention_mask=attention_mask,
                generation_config=generation_config,
            )

        prompt_lengths = (
            attention_mask.sum(dim=1).tolist()
            if attention_mask is not None
            else [input_ids.shape[1]] * len(prompts)
        )
        outputs: list[str] = []
        for index, generated_ids in enumerate(generated):
            if self._is_causal:
                response_ids = generated_ids[int(prompt_lengths[index]):]
            else:
                response_ids = generated_ids

            generated_text = self.tokenizer.decode(response_ids, skip_special_tokens=True).strip()
            if not generated_text:
                generated_text = self.tokenizer.decode(generated_ids, skip_special_tokens=True).strip()
            if not generated_text:
                raise ValueError("模型测试失败：模型未生成有效输出。")
            outputs.append(generated_text)
        return outputs

    def _build_prompt(self, user_input: str) -> str:
        if hasattr(self.tokenizer, "apply_chat_template"):
            messages = []
            if self.system_prompt:
                messages.append({"role": "system", "content": self.system_prompt})
            messages.append({"role": "user", "content": user_input})
            return self.tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
            )

        if self.system_prompt:
            return f"系统指令：{self.system_prompt}\n\n用户输入：{user_input}\n\n助手："
        return user_input


def run_model_test(
    model_path: str | Path,
    user_input: str = MODEL_TEST_USER_INPUT,
    system_prompt: str = SYSTEM_PROMPT,
    max_new_tokens: int = 64,
    do_sample: bool = False,
    temperature: float = 1.0,
    top_p: float = 1.0,
    top_k: int = 0,
    repetition_penalty: float = 1.05,
    mode: str = DEFAULT_MODEL_TEST_MODE,
    api_base_url: str | None = None,
    api_key: str | None = None,
    api_key_header: str | None = None,
    api_key_prefix: str = "",
    http_headers: dict[str, str] | None = None,
    http_request_field_map: dict[str, str] | None = None,
    http_extra_body: dict[str, object] | None = None,
) -> ModelTestResult:
    runtime_config = ModelTestRuntimeConfig(
        system_prompt=system_prompt,
        max_new_tokens=max_new_tokens,
        do_sample=do_sample,
        temperature=temperature,
        top_p=top_p,
        top_k=top_k,
        repetition_penalty=repetition_penalty,
        mode=mode,
        api_base_url=api_base_url,
        api_key=api_key,
        api_key_header=api_key_header,
        api_key_prefix=api_key_prefix,
        http_headers=http_headers,
        http_request_field_map=http_request_field_map,
        http_extra_body=http_extra_body,
    )
    tester = _build_model_tester(model_path=model_path, runtime_config=runtime_config)
    generate_kwargs: dict[str, object] = {"max_new_tokens": max_new_tokens}
    if runtime_config.mode == "http":
        generate_kwargs["headers"] = runtime_config.http_headers
    generated_text = tester.generate_text(user_input, **generate_kwargs)
    return ModelTestResult(
        model_path=str(model_path),
        user_input=user_input,
        generated_text=generated_text,
        model_class=tester.model_class,
        tokenizer_class=tester.tokenizer_class,
        device=tester.device,
    )


def model_test_dataframe(
    dataframe: pd.DataFrame,
    model_path: str | Path,
    *,
    runtime_config: ModelTestRuntimeConfig,
    target_column: str = "text",
    expected_result_column: str = EXPECTED_RESULT_COLUMN,
    progress_callback: Callable[[int], None] | None = None,
) -> tuple[pd.DataFrame, BatchModelTestStats]:
    resolved_target_column = resolve_target_column(dataframe, target_column)
    has_expected_result = expected_result_column in dataframe.columns
    prompts = dataframe[resolved_target_column].tolist()
    expected_results = (
        dataframe[expected_result_column].tolist() if has_expected_result else [None] * len(dataframe)
    )
    if runtime_config.mode in {"openai", "http"}:
        model_results, model_call_times, device_used = _run_openai_batches(
            prompts=prompts,
            model_path=model_path,
            runtime_config=runtime_config,
            progress_callback=progress_callback,
        )
        worker_count = 1
    else:
        devices = resolve_worker_devices(runtime_config.num_workers)
        worker_count = len(devices)

        if len(devices) == 1:
            model_results, model_call_times, device_used = _run_single_process_batches(
                prompts=prompts,
                model_path=model_path,
                runtime_config=runtime_config,
                device=devices[0],
                progress_callback=progress_callback,
            )
        else:
            model_results, model_call_times = _run_multi_worker_batches(
                prompts=prompts,
                model_path=model_path,
                runtime_config=runtime_config,
                devices=devices,
                progress_callback=progress_callback,
            )
            device_used = ",".join(devices)

    tested = dataframe.copy()
    tested[MODEL_RESULT_COLUMN] = model_results
    tested[MODEL_CALL_TIME_COLUMN] = model_call_times

    match_expected: list[bool] = []
    if has_expected_result:
        match_expected = [
            _is_expected_match(expected, model_result)
            for expected, model_result in zip(expected_results, model_results, strict=True)
        ]
        tested[MATCH_EXPECTED_COLUMN] = match_expected

    stats = BatchModelTestStats(
        total_rows=len(tested),
        target_column=resolved_target_column,
        has_expected_result=has_expected_result,
        matched_expected_count=sum(match_expected),
        average_call_time_seconds=round(sum(model_call_times) / len(model_call_times), 4)
        if model_call_times
        else 0.0,
        model_path=str(model_path),
        device=device_used,
        num_workers=worker_count,
        batch_size=runtime_config.batch_size,
    )
    return tested, stats


def resolve_worker_devices(num_workers: int | str = "auto") -> list[str]:
    gpu_count = get_visible_gpu_count()
    if gpu_count <= 0:
        return ["cpu"]

    if num_workers == "auto":
        worker_count = gpu_count
    else:
        worker_count = max(1, min(int(num_workers), gpu_count))
    return [f"cuda:{index}" for index in range(worker_count)]


def get_visible_gpu_count() -> int:
    try:
        import torch
    except ImportError:
        return 0
    return torch.cuda.device_count() if torch.cuda.is_available() else 0


def _run_openai_batches(
    prompts: list[object],
    model_path: str | Path,
    runtime_config: ModelTestRuntimeConfig,
    progress_callback: Callable[[int], None] | None = None,
) -> tuple[list[str], list[float], str]:
    tester = _build_model_tester(model_path=model_path, runtime_config=runtime_config)
    model_results: list[str] = []
    model_call_times: list[float] = []
    for prompt in prompts:
        started_at = time.perf_counter()
        generate_kwargs: dict[str, object] = {"max_new_tokens": runtime_config.max_new_tokens}
        if runtime_config.mode == "http":
            generate_kwargs["headers"] = runtime_config.http_headers
        generated_text = tester.generate_text(prompt, **generate_kwargs)
        elapsed_seconds = round(time.perf_counter() - started_at, 4)
        model_results.append(generated_text)
        model_call_times.append(elapsed_seconds)
        if progress_callback:
            progress_callback(1)
    return model_results, model_call_times, tester.device


def _build_model_tester(
    model_path: str | Path,
    runtime_config: ModelTestRuntimeConfig,
    device: str | None = None,
):
    if runtime_config.mode == "openai":
        return OpenAICompatibleModelTester(
            model_name=str(model_path),
            system_prompt=runtime_config.system_prompt,
            do_sample=runtime_config.do_sample,
            temperature=runtime_config.temperature,
            top_p=runtime_config.top_p,
            repetition_penalty=runtime_config.repetition_penalty,
            api_base_url=runtime_config.api_base_url,
        )
    if runtime_config.mode == "http":
        return HttpModelTester(
            model_name=str(model_path),
            system_prompt=runtime_config.system_prompt,
            do_sample=runtime_config.do_sample,
            temperature=runtime_config.temperature,
            top_p=runtime_config.top_p,
            top_k=runtime_config.top_k,
            repetition_penalty=runtime_config.repetition_penalty,
            api_key=runtime_config.api_key,
            api_key_header=runtime_config.api_key_header,
            api_key_prefix=runtime_config.api_key_prefix,
            api_base_url=runtime_config.api_base_url,
            request_field_map=runtime_config.http_request_field_map,
            extra_body=runtime_config.http_extra_body,
        )

    return LocalModelTester(
        model_path=model_path,
        system_prompt=runtime_config.system_prompt,
        do_sample=runtime_config.do_sample,
        temperature=runtime_config.temperature,
        top_p=runtime_config.top_p,
        top_k=runtime_config.top_k,
        repetition_penalty=runtime_config.repetition_penalty,
        device=device,
    )


def _run_single_process_batches(
    prompts: list[object],
    model_path: str | Path,
    runtime_config: ModelTestRuntimeConfig,
    device: str,
    progress_callback: Callable[[int], None] | None = None,
) -> tuple[list[str], list[float], str]:
    tester = _build_model_tester(
        model_path=model_path,
        runtime_config=runtime_config,
        device=device,
    )
    model_results: list[str] = []
    model_call_times: list[float] = []
    for batch_prompts in _chunk_list(prompts, runtime_config.batch_size):
        started_at = time.perf_counter()
        batch_results = tester.generate_texts(batch_prompts, max_new_tokens=runtime_config.max_new_tokens)
        elapsed_seconds = round(time.perf_counter() - started_at, 4)
        per_row_seconds = round(elapsed_seconds / len(batch_prompts), 4)
        model_results.extend(batch_results)
        model_call_times.extend([per_row_seconds] * len(batch_prompts))
        if progress_callback:
            progress_callback(len(batch_prompts))
    return model_results, model_call_times, tester.device


def _run_multi_worker_batches(
    prompts: list[object],
    model_path: str | Path,
    runtime_config: ModelTestRuntimeConfig,
    devices: list[str],
    progress_callback: Callable[[int], None] | None = None,
) -> tuple[list[str], list[float]]:
    ctx = mp.get_context("spawn")
    task_queue = ctx.Queue()
    result_queue = ctx.Queue()
    processes = [
        ctx.Process(
            target=_batch_model_test_worker,
            args=(
                task_queue,
                result_queue,
                {
                    "model_path": str(model_path),
                    "device": device,
                    "system_prompt": runtime_config.system_prompt,
                    "max_new_tokens": runtime_config.max_new_tokens,
                    "do_sample": runtime_config.do_sample,
                    "temperature": runtime_config.temperature,
                    "top_p": runtime_config.top_p,
                    "top_k": runtime_config.top_k,
                    "repetition_penalty": runtime_config.repetition_penalty,
                    "mode": runtime_config.mode,
                    "api_base_url": runtime_config.api_base_url,
                    "api_key": runtime_config.api_key,
                    "api_key_header": runtime_config.api_key_header,
                    "api_key_prefix": runtime_config.api_key_prefix,
                    "http_headers": runtime_config.http_headers,
                    "http_request_field_map": runtime_config.http_request_field_map,
                    "http_extra_body": runtime_config.http_extra_body,
                },
            ),
        )
        for device in devices
    ]

    batches = list(enumerate(_chunk_list(list(enumerate(prompts)), runtime_config.batch_size)))
    for batch_id, batch_items in batches:
        task_queue.put((batch_id, batch_items))
    for _ in processes:
        task_queue.put(None)

    for process in processes:
        process.start()

    model_results = [""] * len(prompts)
    model_call_times = [0.0] * len(prompts)
    remaining_batches = len(batches)
    try:
        while remaining_batches > 0:
            result = result_queue.get()
            if result["status"] == "error":
                raise ValueError(result["message"])

            for row_index, generated_text, call_time in result["rows"]:
                model_results[row_index] = generated_text
                model_call_times[row_index] = call_time
            if progress_callback:
                progress_callback(len(result["rows"]))
            remaining_batches -= 1
    finally:
        for process in processes:
            process.join(timeout=1)
            if process.is_alive():
                process.terminate()
                process.join()

    return model_results, model_call_times


def _batch_model_test_worker(task_queue, result_queue, worker_config: dict[str, object]) -> None:
    try:
        tester = _build_model_tester(
            model_path=worker_config["model_path"],
            runtime_config=ModelTestRuntimeConfig(
                system_prompt=str(worker_config["system_prompt"]),
                max_new_tokens=int(worker_config["max_new_tokens"]),
                do_sample=bool(worker_config["do_sample"]),
                temperature=float(worker_config["temperature"]),
                top_p=float(worker_config["top_p"]),
                top_k=int(worker_config["top_k"]),
                repetition_penalty=float(worker_config["repetition_penalty"]),
                mode=str(worker_config.get("mode", DEFAULT_MODEL_TEST_MODE)),
                api_base_url=worker_config.get("api_base_url"),
                api_key=worker_config.get("api_key"),
                api_key_header=worker_config.get("api_key_header"),
                api_key_prefix=str(worker_config.get("api_key_prefix", "")),
                http_headers=worker_config.get("http_headers"),
                http_request_field_map=worker_config.get("http_request_field_map"),
                http_extra_body=worker_config.get("http_extra_body"),
            ),
            device=str(worker_config["device"]),
        )
        max_new_tokens = int(worker_config["max_new_tokens"])
        while True:
            try:
                item = task_queue.get(timeout=1)
            except queue.Empty:
                continue
            if item is None:
                return

            _batch_id, batch_items = item
            row_indices = [row_index for row_index, _ in batch_items]
            prompts = [prompt for _, prompt in batch_items]
            started_at = time.perf_counter()
            batch_results = tester.generate_texts(prompts, max_new_tokens=max_new_tokens)
            elapsed_seconds = round(time.perf_counter() - started_at, 4)
            per_row_seconds = round(elapsed_seconds / len(batch_items), 4)
            result_queue.put(
                {
                    "status": "ok",
                    "rows": [
                        (row_index, generated_text, per_row_seconds)
                        for row_index, generated_text in zip(row_indices, batch_results, strict=True)
                    ],
                }
            )
    except Exception as exc:
        result_queue.put({"status": "error", "message": f"{type(exc).__name__}: {exc}"})


def _chunk_list(items: list[object], chunk_size: int) -> list[list[object]]:
    return [items[index: index + chunk_size] for index in range(0, len(items), chunk_size)]


def _is_expected_match(expected_result: object, model_result: str) -> bool:
    return normalize_dedup_text(expected_result) == normalize_dedup_text(model_result)


def _build_openai_messages(system_prompt: str, user_input: str) -> list[dict[str, str]]:
    messages: list[dict[str, str]] = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": user_input})
    return messages


def _normalize_api_key_prefix(prefix: str) -> str:
    normalized_prefix = str(prefix)
    if normalized_prefix.strip().lower() == "bearer":
        return "Bearer "
    return normalized_prefix


def _extract_http_response_text(payload: dict[str, object]) -> str:
    if isinstance(payload.get("choices"), list):
        return extract_chat_completion_text(
            payload,
            error_prefix="HTTP 接口模型测试失败",
        )

    direct_keys = ("generated_text", "text", "output_text", "output", "result", "content")
    for key in direct_keys:
        value = payload.get(key)
        if isinstance(value, str):
            return value

    data = payload.get("data")
    if isinstance(data, dict):
        for key in direct_keys:
            value = data.get(key)
            if isinstance(value, str):
                return value

    raise ValueError("HTTP 接口模型测试失败：响应中缺少可识别的文本字段。")


def _normalize_http_request_field_map(
    field_map: dict[str, str] | None,
) -> dict[str, str]:
    normalized_map = dict(DEFAULT_HTTP_REQUEST_FIELD_MAP)
    if field_map is None:
        return normalized_map

    for source_key, target_key in field_map.items():
        normalized_source_key = str(source_key).strip()
        if normalized_source_key not in DEFAULT_HTTP_REQUEST_FIELD_MAP:
            raise ValueError(f"HTTP 接口模型测试失败：不支持的请求字段映射键：{source_key}")
        normalized_target_key = str(target_key).strip()
        if not normalized_target_key:
            raise ValueError(f"HTTP 接口模型测试失败：请求字段映射值不能为空：{source_key}")
        normalized_map[normalized_source_key] = normalized_target_key
    return normalized_map


def _normalize_http_headers(
    headers: dict[str, str] | None,
) -> dict[str, str] | None:
    if headers is None:
        return None

    normalized_headers: dict[str, str] = {}
    for raw_key, raw_value in headers.items():
        normalized_key = str(raw_key).strip()
        if not normalized_key:
            raise ValueError("HTTP 请求头名称不能为空。")
        normalized_headers[normalized_key] = str(raw_value).strip()
    return normalized_headers


def _build_http_request_payload(
    *,
    field_map: dict[str, str],
    model_name: str | None,
    system_prompt: str,
    user_input: str,
    max_new_tokens: int,
    do_sample: bool,
    temperature: float,
    top_p: float,
    top_k: int,
    repetition_penalty: float,
    extra_body: dict[str, object] | None,
) -> dict[str, object]:
    payload = dict(extra_body or {})
    source_values: dict[str, object] = {
        "system_prompt": system_prompt,
        "user_input": user_input,
        "max_new_tokens": max_new_tokens,
        "do_sample": do_sample,
        "temperature": temperature,
        "top_p": top_p,
        "top_k": top_k,
        "repetition_penalty": repetition_penalty,
    }
    if model_name:
        source_values["model"] = model_name
    for source_key, source_value in source_values.items():
        payload[field_map[source_key]] = source_value
    return payload


def _build_http_request(
    *,
    api_base_url: str,
    field_map: dict[str, str],
    model_name: str | None,
    system_prompt: str,
    user_input: str,
    max_new_tokens: int,
    do_sample: bool,
    temperature: float,
    top_p: float,
    top_k: int,
    repetition_penalty: float,
    extra_body: dict[str, object] | None,
) -> tuple[str, dict[str, object]]:
    request_url = _resolve_http_request_url(api_base_url)
    if _should_use_chat_completions_http_payload(api_base_url=request_url):
        return request_url, _build_http_chat_completions_payload(
            model_name=model_name,
            system_prompt=system_prompt,
            user_input=user_input,
            max_new_tokens=max_new_tokens,
            do_sample=do_sample,
            temperature=temperature,
            top_p=top_p,
            extra_body=extra_body,
        )

    return request_url, _build_http_request_payload(
        field_map=field_map,
        model_name=model_name,
        system_prompt=system_prompt,
        user_input=user_input,
        max_new_tokens=max_new_tokens,
        do_sample=do_sample,
        temperature=temperature,
        top_p=top_p,
        top_k=top_k,
        repetition_penalty=repetition_penalty,
        extra_body=extra_body,
    )


def _resolve_http_request_url(api_base_url: str) -> str:
    normalized_url = api_base_url.rstrip("/")
    parsed_url = urlparse(normalized_url)
    if parsed_url.netloc == "api.deepseek.com" and parsed_url.path == "/v1":
        return f"{normalized_url}/chat/completions"
    return normalized_url


def _should_use_chat_completions_http_payload(*, api_base_url: str) -> bool:
    parsed_url = urlparse(api_base_url.rstrip("/"))
    return parsed_url.path.endswith("/chat/completions")


def _build_http_chat_completions_payload(
    *,
    model_name: str | None,
    system_prompt: str,
    user_input: str,
    max_new_tokens: int,
    do_sample: bool,
    temperature: float,
    top_p: float,
    extra_body: dict[str, object] | None,
) -> dict[str, object]:
    payload = dict(extra_body or {})
    if model_name:
        payload["model"] = model_name
    payload["messages"] = _build_openai_messages(system_prompt, user_input)
    payload["max_tokens"] = max_new_tokens
    payload["temperature"] = temperature if do_sample else 0
    payload["top_p"] = top_p
    return payload


def _load_generation_model(model_path: Path, auto_causal_model, auto_seq2seq_model):
    causal_error: Exception | None = None
    try:
        model = auto_causal_model.from_pretrained(
            str(model_path),
            local_files_only=True,
            trust_remote_code=True,
        )
        model.eval()
        return model, True
    except Exception as exc:
        causal_error = exc

    try:
        model = auto_seq2seq_model.from_pretrained(
            str(model_path),
            local_files_only=True,
            trust_remote_code=True,
        )
        model.eval()
        return model, False
    except Exception as exc:
        if causal_error is not None:
            raise ValueError(
                f"无法按生成模型加载：causal={type(causal_error).__name__}: {causal_error}; "
                f"seq2seq={type(exc).__name__}: {exc}"
            ) from exc
        raise


def _resolve_inference_device(torch) -> str:
    if torch.cuda.is_available():
        return "cuda"

    mps_backend = getattr(torch.backends, "mps", None)
    if mps_backend is not None and mps_backend.is_available():
        return "mps"

    return "cpu"


def _build_generation_config(
    model: object,
    max_new_tokens: int,
    do_sample: bool,
    temperature: float,
    top_p: float,
    top_k: int,
    repetition_penalty: float,
    pad_token_id: int | None,
):
    generation_config = copy.deepcopy(model.generation_config)
    generation_config.max_new_tokens = max_new_tokens
    generation_config.do_sample = do_sample
    generation_config.repetition_penalty = repetition_penalty
    generation_config.pad_token_id = pad_token_id

    if do_sample:
        generation_config.temperature = temperature
        generation_config.top_p = top_p
        generation_config.top_k = top_k
        return generation_config

    generation_config.temperature = 1.0
    generation_config.top_p = 1.0
    generation_config.top_k = 50
    return generation_config
