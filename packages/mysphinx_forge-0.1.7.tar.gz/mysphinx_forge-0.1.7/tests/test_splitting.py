from __future__ import annotations

import pandas as pd
import pytest

from mysphinx_forge.splitting import resolve_auto_split_mode, split_dataframe


def test_split_dataframe_random_preserves_total_rows() -> None:
    dataframe = pd.DataFrame({"text": [f"q{i}" for i in range(10)]})

    train, validation, test, stats = split_dataframe(
        dataframe,
        split_mode="random",
        validation_ratio=0.2,
        test_ratio=0.2,
        random_seed=7,
    )

    assert len(train) == 6
    assert len(validation) == 2
    assert len(test) == 2
    assert stats.total_rows == 10
    assert stats.train_rows + stats.validation_rows + stats.test_rows == 10


def test_split_dataframe_stratified_preserves_label_distribution() -> None:
    dataframe = pd.DataFrame(
        {
            "text": [f"q{i}" for i in range(12)],
            "category": ["基金"] * 6 + ["股票"] * 6,
        }
    )

    train, validation, test, stats = split_dataframe(
        dataframe,
        split_mode="stratified",
        stratify_column="category",
        validation_ratio=0.25,
        test_ratio=0.25,
        random_seed=42,
    )

    assert train["category"].value_counts().to_dict() == {"基金": 3, "股票": 3}
    assert validation["category"].value_counts().to_dict() == {"基金": 1, "股票": 1}
    assert test["category"].value_counts().to_dict() == {"基金": 2, "股票": 2}
    assert stats.stratify_column == "category"


def test_split_dataframe_group_keeps_group_intact() -> None:
    dataframe = pd.DataFrame(
        {
            "text": [f"q{i}" for i in range(8)],
            "session_id": ["a", "a", "b", "b", "c", "c", "d", "d"],
        }
    )

    train, validation, test, _ = split_dataframe(
        dataframe,
        split_mode="group",
        group_column="session_id",
        validation_ratio=0.25,
        test_ratio=0.25,
        random_seed=42,
    )

    train_groups = set(train["session_id"].tolist())
    validation_groups = set(validation["session_id"].tolist())
    test_groups = set(test["session_id"].tolist())
    assert train_groups.isdisjoint(validation_groups)
    assert train_groups.isdisjoint(test_groups)
    assert validation_groups.isdisjoint(test_groups)


def test_split_dataframe_time_uses_ordered_windows() -> None:
    dataframe = pd.DataFrame(
        {
            "text": [f"q{i}" for i in range(10)],
            "created_at": pd.date_range("2025-01-01", periods=10, freq="D"),
        }
    )

    train, validation, test, stats = split_dataframe(
        dataframe,
        split_mode="time",
        time_column="created_at",
        validation_ratio=0.2,
        test_ratio=0.2,
        random_seed=42,
    )

    assert train["created_at"].max() < validation["created_at"].min()
    assert validation["created_at"].max() < test["created_at"].min()
    assert stats.time_column == "created_at"
    assert stats.time_ascending is True


def test_resolve_auto_split_mode_prefers_category_column() -> None:
    dataframe = pd.DataFrame({"text": ["a"], "category": ["基金"]})

    resolved_mode, resolved_column = resolve_auto_split_mode(dataframe, "auto")

    assert resolved_mode == "stratified"
    assert resolved_column == "category"


def test_split_dataframe_rejects_invalid_ratio_sum() -> None:
    dataframe = pd.DataFrame({"text": ["a", "b"]})

    with pytest.raises(ValueError, match="之和必须小于 1"):
        split_dataframe(
            dataframe,
            split_mode="random",
            validation_ratio=0.5,
            test_ratio=0.5,
        )
