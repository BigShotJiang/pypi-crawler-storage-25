from __future__ import annotations

import pandas as pd
import pytest

from mysphinx_forge.sft_dataset import convert_dataframe_to_alpaca, resolve_sft_output_column


def test_convert_dataframe_to_alpaca_auto_detects_columns_and_skips_blank_rows() -> None:
    dataframe = pd.DataFrame(
        {
            "用户输入": ["怎么买基金", "", "港股通怎么开"],
            "category": ["基金", "股票", ""],
        }
    )

    records, stats = convert_dataframe_to_alpaca(dataframe)

    assert records == [
        {
            "instruction": "请根据用户输入判断其category，只输出category。",
            "input": "怎么买基金",
            "output": "基金",
        }
    ]
    assert stats.input_column == "用户输入"
    assert stats.output_column == "category"
    assert stats.total_rows == 3
    assert stats.converted_rows == 1
    assert stats.skipped_blank_input_rows == 1
    assert stats.skipped_blank_output_rows == 1


def test_convert_dataframe_to_alpaca_prefers_system_column_over_fixed_prompt() -> None:
    dataframe = pd.DataFrame(
        {
            "text": ["基金赎回多久到账"],
            "label": ["基金"],
            "system_text": ["你是证券分类助手，只输出标签。"],
        }
    )

    records, stats = convert_dataframe_to_alpaca(
        dataframe,
        output_column="label",
        system_prompt="固定 system",
        system_column="system_text",
        instruction="请分类。",
    )

    assert records == [
        {
            "instruction": "请分类。",
            "input": "基金赎回多久到账",
            "output": "基金",
            "system": "你是证券分类助手，只输出标签。",
        }
    ]
    assert stats.output_column == "label"


def test_resolve_sft_output_column_requires_supported_or_explicit_column() -> None:
    dataframe = pd.DataFrame({"text": ["a"], "other": ["b"]})

    with pytest.raises(ValueError, match="未找到 SFT 输出列"):
        resolve_sft_output_column(dataframe, "")
