from __future__ import annotations

import json
import sys

import pandas as pd

from mysphinx_forge.cli import main


def test_main_converts_excel_to_alpaca_json(tmp_path, monkeypatch, capsys) -> None:
    input_file = tmp_path / "input.xlsx"
    pd.DataFrame(
        {
            "text": ["怎么买基金", "", "港股通怎么开"],
            "category": ["基金", "股票", ""],
        }
    ).to_excel(input_file, index=False)

    monkeypatch.setattr(
        sys,
        "argv",
        ["main.py", "--action", "convert-sft", "--input-file", str(input_file)],
    )

    exit_code = main()
    captured = capsys.readouterr()

    output_file = tmp_path / "input_alpaca.json"
    assert exit_code == 0
    assert "SFT 数据转换完成" in captured.out
    assert output_file.exists()

    dataset = json.loads(output_file.read_text(encoding="utf-8"))
    assert dataset == [
        {
            "instruction": "请根据用户输入判断其category，只输出category。",
            "input": "怎么买基金",
            "output": "基金",
        }
    ]

    meta_file = tmp_path / "input_alpaca.meta.json"
    assert meta_file.exists()
    meta = json.loads(meta_file.read_text(encoding="utf-8"))
    assert meta["action"] == "convert-sft"
    assert meta["output_file"] == str(output_file)
    assert meta["sft_conversion_stats"]["input_column"] == "text"
    assert meta["sft_conversion_stats"]["output_column"] == "category"
    assert meta["sft_conversion_stats"]["converted_rows"] == 1
    assert meta["sft_conversion_stats"]["skipped_rows"] == 2


def test_main_converts_with_custom_output_column_and_system_prompt(
    tmp_path, monkeypatch, capsys
) -> None:
    input_file = tmp_path / "input.csv"
    pd.DataFrame(
        {
            "用户输入": ["ETF和LOF区别"],
            "label": ["基金"],
        }
    ).to_csv(input_file, index=False)

    monkeypatch.setattr(
        sys,
        "argv",
        [
            "main.py",
            "--action",
            "convert-sft",
            "--input-file",
            str(input_file),
            "--sft-output-column",
            "label",
            "--sft-system-prompt",
            "你是分类助手。",
        ],
    )

    exit_code = main()
    capsys.readouterr()

    output_file = tmp_path / "input_alpaca.json"
    assert exit_code == 0

    dataset = json.loads(output_file.read_text(encoding="utf-8"))
    assert dataset == [
        {
            "instruction": "请根据用户输入判断其label，只输出label。",
            "input": "ETF和LOF区别",
            "output": "基金",
            "system": "你是分类助手。",
        }
    ]
