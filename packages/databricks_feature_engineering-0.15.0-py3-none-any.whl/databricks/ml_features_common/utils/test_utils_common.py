"""
Test utilities shared between the lookup-client and the core client
"""

# TODO (ML-30526): Move this file to the tests module.

from databricks.ml_features_common.utils.utils_common import strip_kafka_column_prefix


def mock_context_manager(mock_context_mgr, resource):
    """
    Modify the mock context manager to return the given resource when it's __enter__() protocol method is invoked.
    """
    mock_context_mgr.__enter__.return_value = resource


class TestStripKafkaColumnPrefix:
    """Unit tests for strip_kafka_column_prefix, including legacy colon notation."""

    def test_strips_value_dot_prefix(self):
        assert strip_kafka_column_prefix("value.customer_id") == "customer_id"

    def test_strips_key_dot_prefix(self):
        assert strip_kafka_column_prefix("key.order_id") == "order_id"

    def test_strips_value_colon_prefix(self):
        # Legacy colon notation must still strip correctly.
        assert strip_kafka_column_prefix("value:customer_id") == "customer_id"

    def test_strips_key_colon_prefix(self):
        assert strip_kafka_column_prefix("key:order_id") == "order_id"

    def test_no_prefix_unchanged(self):
        assert strip_kafka_column_prefix("customer_id") == "customer_id"
