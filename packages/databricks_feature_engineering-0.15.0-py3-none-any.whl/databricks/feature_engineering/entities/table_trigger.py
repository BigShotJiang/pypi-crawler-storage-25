from databricks.ml_features.entities.table_trigger import TableTrigger

__all__ = ["TableTrigger"]
