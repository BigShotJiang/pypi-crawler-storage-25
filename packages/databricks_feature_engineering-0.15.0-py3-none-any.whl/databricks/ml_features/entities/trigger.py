import abc

from databricks.sdk.service.ml import MaterializedFeaturePipelineScheduleState


# TODO(FS-957): Add a standard _to_sdk method once the backend work is done.
class Trigger(abc.ABC):
    """
    Abstract base class for trigger configurations used in feature materialization.

    Subclasses define specific triggering strategies (e.g., cron-based scheduling).
    The pipeline schedule state (e.g. ``ACTIVE``) is orthogonal to the trigger type
    and is stored on this base class so that any trigger can be independently paused
    or activated.

    :param pipeline_schedule_state: The pipeline schedule state for this trigger.
    """

    def __init__(
        self, *, pipeline_schedule_state: MaterializedFeaturePipelineScheduleState
    ):
        self._pipeline_schedule_state = pipeline_schedule_state

    @property
    def pipeline_schedule_state(self) -> MaterializedFeaturePipelineScheduleState:
        """The pipeline schedule state for this trigger."""
        return self._pipeline_schedule_state
