import abc
import json
import logging
import re
from collections import defaultdict
from enum import Enum
from typing import Any, Dict, List, NamedTuple, Optional

from pyspark.sql import functions as F
from pyspark.sql.types import ArrayType, BooleanType
from pyspark.sql.types import DataType as SparkDataType
from pyspark.sql.types import (
    DateType,
    DoubleType,
    LongType,
    MapType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

from databricks.ml_features import flags
from databricks.ml_features._spark_client._spark_client import SparkClient
from databricks.ml_features.utils.deprecation_utils import (
    emit_deprecation_warning,
    suppress_deprecation_warnings,
)
from databricks.ml_features_common.entities._feature_store_object import (
    _FeatureStoreObject,
)
from databricks.sdk.service.ml import ColumnIdentifier
from databricks.sdk.service.ml import DataSource as SDKDataSource
from databricks.sdk.service.ml import DeltaTableSource as SDKDeltaTableSource
from databricks.sdk.service.ml import FieldDefinition as SDKFieldDefinition
from databricks.sdk.service.ml import FlatSchema as SDKFlatSchema
from databricks.sdk.service.ml import KafkaSource as SDKKafkaSource
from databricks.sdk.service.ml import RequestSource as SDKRequestSource
from databricks.sdk.service.ml import ScalarDataType as SDKScalarDataType

_logger = logging.getLogger(__name__)


class DataSourceTypes(Enum):
    """Enumeration of supported data source types."""

    DELTA = "delta"
    UNIFORM = "uniform"
    KAFKA = "kafka"
    VOLUME = "volume"
    DATAFRAME = "dataframe"
    REQUEST = "request"


class DataSource(_FeatureStoreObject, abc.ABC):
    """
    Abstract base class for data sources used in feature computation.

    :param source_type: The type of data source
    :param entity_columns: List of column names that serve as primary keys
    :param timeseries_column: Column name that contains timestamp data
    """

    # TODO[FS-871]: Remove `entity_columns` and `timeseries_column` from DataSource
    # when breaking backwards compatibility. These move to Feature.
    def __init__(
        self,
        *,
        source_type: DataSourceTypes,
        **kwargs,
    ):
        """Initialize a DataSource object. See class documentation.

        Keyword Args:
            entity_columns: (deprecated) List of column names that serve as primary keys.
                Use Feature(entity=...) instead.
            timeseries_column: (deprecated) Column name that contains timestamp data.
                Use Feature(timeseries_column=...) instead.
        """
        entity_columns = kwargs.pop("entity_columns", None)
        timeseries_column = kwargs.pop("timeseries_column", None)
        if kwargs:
            raise TypeError(
                f"DataSource.__init__() got unexpected keyword arguments: "
                f"{', '.join(repr(k) for k in kwargs)}"
            )
        self._validate_parameters(source_type, entity_columns, timeseries_column)

        self._source_type = source_type
        self._entity_columns = entity_columns
        self._timeseries_column = timeseries_column
        self._order_column = DataSource.timeseries_to_order_column(timeseries_column)

    @property
    def source_type(self) -> DataSourceTypes:
        """The type of data source."""
        return self._source_type

    @property
    def entity_columns(self) -> Optional[List[str]]:
        """List of column names that serve as primary keys."""
        return self._entity_columns

    @property
    def timeseries_column(self) -> Optional[str]:
        """Column name that contains timestamp data."""
        return self._timeseries_column

    @property
    def order_column(self) -> Optional[str]:
        """The column name for the order column."""
        return self._order_column

    @staticmethod
    def timeseries_to_order_column(timeseries_column: Optional[str]) -> Optional[str]:
        """Derive the order column name from a timeseries column name."""
        return (
            f"___{timeseries_column}_as_long" if timeseries_column is not None else None
        )

    @abc.abstractmethod
    def full_name(self) -> str:
        """Return the full name/identifier for this data source."""
        raise NotImplementedError()

    @abc.abstractmethod
    def load_df(
        self,
        spark_client,
    ):
        """Load the data source as a Spark DataFrame. Must be implemented by all derived classes.

        Args:
            spark_client: The Spark client for DataFrame operations
        """
        raise NotImplementedError()

    @abc.abstractmethod
    def __hash__(self):
        """Make DataSource hashable. Must be implemented by all derived classes."""
        raise NotImplementedError()

    def _validate_parameters(
        self,
        source_type: DataSourceTypes,
        entity_columns: Optional[List[str]],
        timeseries_column: Optional[str],
    ):
        """Validates the parameters provided to the DataSource class."""
        if not isinstance(source_type, DataSourceTypes):
            raise ValueError("The 'source_type' must be a DataSourceTypes enum value.")

        if entity_columns is not None:
            if not isinstance(entity_columns, list):
                raise ValueError("The 'entity_columns' must be a list.")
            if len(entity_columns) == 0:
                raise ValueError(
                    "The 'entity_columns' must contain at least one column name."
                )
            for i, column in enumerate(entity_columns):
                if not isinstance(column, str) or not column.strip():
                    raise ValueError(
                        f"All entity columns must be non-empty strings. "
                        f"Invalid column at index {i}: {column}"
                    )

        if timeseries_column is not None:
            if not isinstance(timeseries_column, str) or not timeseries_column.strip():
                raise ValueError("The 'timeseries_column' must be a non-empty string.")

    @classmethod
    def _from_yaml_dict(cls, data_source_dict: Dict[str, Any]) -> "DataSource":
        """Create a DataSource from a dictionary loaded from YAML."""
        if (
            DeltaTableSource.CATALOG_NAME_FIELD_NAME in data_source_dict
            and DeltaTableSource.SCHEMA_NAME_FIELD_NAME in data_source_dict
            and DeltaTableSource.TABLE_NAME_FIELD_NAME in data_source_dict
        ):
            return DeltaTableSource._from_yaml_dict(data_source_dict)
        elif KafkaSource.NAME_FIELD_NAME in data_source_dict:
            return KafkaSource._from_yaml_dict(data_source_dict)
        elif data_source_dict.get("type") == RequestSource.TYPE_VALUE:
            return RequestSource._from_yaml_dict(data_source_dict)
        else:
            raise ValueError(
                f"Unsupported data source type in dictionary: {data_source_dict}"
            )

    def _to_sdk_data_source(self) -> SDKDataSource:
        raise NotImplementedError

    @classmethod
    def _from_sdk_data_source(cls, sdk_source: SDKDataSource) -> "DataSource":
        if not isinstance(sdk_source, SDKDataSource):
            raise TypeError(
                "Expected databricks.sdk.service.ml.DataSource when converting from SDK"
            )

        # Check which source type is present
        if sdk_source.delta_table_source is not None:
            return DeltaTableSource._from_sdk_data_source(sdk_source.delta_table_source)
        elif sdk_source.kafka_source is not None:
            return KafkaSource._from_sdk_data_source(sdk_source.kafka_source)
        elif sdk_source.request_source is not None:
            return RequestSource._from_sdk_data_source(sdk_source.request_source)
        else:
            raise ValueError("Unknown or unsupported DataSource type in SDK object")


class BackfillSource(DataSource, abc.ABC):
    """
    Marker base class for DataSources that can be used as a backfill source for Kafka backed features.

    In a future milestone, this data will be used when creating a training set for kafka backed feature or for backfilling materialized features.
    """

    pass


class DeltaTableSource(BackfillSource):
    """
    Data source implementation for Delta Lake tables.

    :param catalog_name: The name of the Unity Catalog catalog
    :param schema_name: The name of the schema within the catalog
    :param table_name: The name of the table within the schema
    :param entity_columns: List of column names that serve as primary keys
    :param timeseries_column: Column name that contains timestamp data
    :param filter_condition: Optional SQL WHERE clause to filter the source table
    :param transformation_sql: Optional SQL SELECT expression applied after filtering.
        If not provided, all columns are selected from the source table (equivalent to ``*``).
    :param schema_json: Optional Spark StructType JSON schema of the transformed output
    """

    CATALOG_NAME_FIELD_NAME = "catalog"
    SCHEMA_NAME_FIELD_NAME = "schema"
    TABLE_NAME_FIELD_NAME = "table"
    ENTITY_COLUMNS_FIELD_NAME = "entity_columns"
    TIMESERIES_COLUMN_FIELD_NAME = "timeseries_column"
    FILTER_CONDITION_FIELD_NAME = "filter_condition"
    TRANSFORMATION_SQL_FIELD_NAME = "transformation_sql"
    SCHEMA_JSON_FIELD_NAME = "schema_json"

    # TODO[FS-871]: Remove `entity_columns` and `timeseries_column` params
    # when breaking backwards compatibility. These move to Feature.
    def __init__(
        self,
        *,
        catalog_name: str,
        schema_name: str,
        table_name: str,
        filter_condition: Optional[str] = None,
        transformation_sql: Optional[str] = None,
        schema_json: Optional[str] = None,
        **kwargs,
    ):
        """Initialize a DeltaTableSource object. See class documentation.

        Keyword Args:
            entity_columns: (deprecated) List of column names that serve as primary keys.
                Use Feature(entity=...) instead.
            timeseries_column: (deprecated) Column name that contains timestamp data.
                Use Feature(timeseries_column=...) instead.
        """
        entity_columns = kwargs.pop("entity_columns", None)
        timeseries_column = kwargs.pop("timeseries_column", None)
        if kwargs:
            raise TypeError(
                f"DeltaTableSource.__init__() got unexpected keyword arguments: "
                f"{', '.join(repr(k) for k in kwargs)}"
            )
        self._validate_delta_parameters(catalog_name, schema_name, table_name)
        self._validate_transformation_parameters(
            filter_condition, transformation_sql, schema_json
        )

        if flags.ENABLE_DECLARATIVE_FEATURE_API_DEPRECATION_WARNINGS:
            if entity_columns is not None:
                emit_deprecation_warning(
                    "entity_columns", "DeltaTableSource", "Feature(entity=...)"
                )
            if timeseries_column is not None:
                emit_deprecation_warning(
                    "timeseries_column",
                    "DeltaTableSource",
                    "Feature(timeseries_column=...)",
                )

        # Initialize the parent with DELTA type
        super().__init__(
            source_type=DataSourceTypes.DELTA,
            entity_columns=entity_columns,
            timeseries_column=timeseries_column,
        )

        self._catalog_name = catalog_name
        self._schema_name = schema_name
        self._table_name = table_name
        self._filter_condition = filter_condition
        self._transformation_sql = transformation_sql
        self._schema_json = schema_json

    @property
    def catalog_name(self) -> str:
        """The name of the Unity Catalog catalog."""
        return self._catalog_name

    @property
    def schema_name(self) -> str:
        """The name of the schema within the catalog."""
        return self._schema_name

    @property
    def table_name(self) -> str:
        """The name of the table within the schema."""
        return self._table_name

    @property
    def filter_condition(self) -> Optional[str]:
        """Optional SQL WHERE clause filter applied to the source table."""
        return self._filter_condition

    @property
    def transformation_sql(self) -> Optional[str]:
        """Optional SQL SELECT expression applied to the source table."""
        return self._transformation_sql

    @property
    def schema_json(self) -> Optional[str]:
        """Optional JSON schema of the transformed output."""
        return self._schema_json

    def full_name(self) -> str:
        """Return the full table name in catalog.schema.table format."""
        return f"{self._catalog_name}.{self._schema_name}.{self._table_name}"

    def _quoted_full_name(self) -> str:
        """Return the full table name with each part quoted with backticks for safe SQL usage."""
        return f"`{self._catalog_name}`.`{self._schema_name}`.`{self._table_name}`"

    def _to_sql(self) -> str:
        """Build a SQL query applying transformation_sql and filter_condition to the source table.

        Returns a query of the form:
            SELECT {transformation_sql or *} FROM {full_name} [WHERE {filter_condition}]
        """
        select_expr = self._transformation_sql if self._transformation_sql else "*"
        query = f"SELECT {select_expr} FROM {self._quoted_full_name()}"
        if self._filter_condition:
            query += f" WHERE {self._filter_condition}"
        return query

    def to_dataframe(self, spark_client):
        """Load the source table as a Spark DataFrame, applying any transformation_sql and filter_condition.

        Args:
            spark_client: The Spark client for DataFrame operations.

        Returns:
            A Spark DataFrame with transformations applied.
        """
        return spark_client._spark.sql(self._to_sql())

    def load_df(
        self,
        spark_client,
    ):
        """Load the Delta table as a Spark DataFrame.

        If transformation_sql or filter_condition is set, delegates to to_dataframe()
        which applies the transformations via spark.sql(). Otherwise, uses
        spark_client.read_table() for standard table reading.
        """
        if self._filter_condition or self._transformation_sql:
            return self.to_dataframe(spark_client)
        return spark_client.read_table(self.full_name())

    class ParsedSQL(NamedTuple):
        """Result of parsing a simple SQL SELECT statement."""

        table_name: str
        transformation_sql: str
        filter_condition: Optional[str]

    @staticmethod
    def _parse_sql(sql) -> "DeltaTableSource.ParsedSQL":
        """Parse a simple SELECT ... FROM ... [WHERE ...] SQL statement.

        This is a best-effort parser using naive string splitting. It only supports
        simple queries with one SELECT, one FROM, and an optional WHERE clause.
        Complex SQL (JOINs, subqueries, CTEs, UNIONs) is rejected.

        Args:
            sql: A SQL query string.

        Returns:
            A ParsedSQL with table_name, transformation_sql, and filter_condition.

        Raises:
            ValueError: If the SQL is too complex or cannot be parsed.
        """
        stripped = sql.strip().rstrip(";").strip()
        if not stripped:
            raise ValueError("SQL query cannot be empty.")

        upper = stripped.upper()

        # Reject non-SELECT statements
        if not upper.startswith("SELECT"):
            raise ValueError("Only SELECT statements are supported. ")

        _CONSTRUCT_DIRECTLY_HINT = (
            "For complex SQL, construct DeltaTableSource directly with "
            "filter_condition and transformation_sql parameters instead."
        )

        # Reject complex SQL keywords
        for forbidden in ["JOIN", "UNION", "WITH", "INTERSECT", "EXCEPT"]:
            if re.search(r"\b" + forbidden + r"\b", upper):
                raise ValueError(
                    f"SQL contains unsupported keyword '{forbidden}'. "
                    "Only simple SELECT ... FROM ... [WHERE ...] queries are supported. "
                    f"{_CONSTRUCT_DIRECTLY_HINT}"
                )

        # Find all occurrences of FROM keyword (case-insensitive, word boundary)
        from_matches = list(re.finditer(r"\bFROM\b", upper))
        if not from_matches:
            raise ValueError("Could not find FROM clause in SQL. ")
        if len(from_matches) > 1:
            raise ValueError(
                "SQL contains multiple FROM keywords. "
                "Only simple SELECT ... FROM ... [WHERE ...] queries are supported. "
                f"{_CONSTRUCT_DIRECTLY_HINT}"
            )
        from_match = from_matches[0]

        # Find all occurrences of SELECT keyword
        select_matches = list(re.finditer(r"\bSELECT\b", upper))
        if len(select_matches) > 1:
            raise ValueError(
                "SQL contains multiple SELECT keywords. "
                "Only simple SELECT ... FROM ... [WHERE ...] queries are supported. "
                f"{_CONSTRUCT_DIRECTLY_HINT}"
            )

        # Extract SELECT columns (between SELECT and FROM)
        select_part = stripped[len("SELECT") : from_match.start()].strip()
        after_from = stripped[from_match.end() :].strip()

        # Find all occurrences of WHERE keyword in the remainder
        where_matches = list(re.finditer(r"\bWHERE\b", after_from, re.IGNORECASE))
        if len(where_matches) > 1:
            raise ValueError(
                "SQL contains multiple WHERE keywords. "
                "Only simple SELECT ... FROM ... [WHERE ...] queries are supported. "
                f"{_CONSTRUCT_DIRECTLY_HINT}"
            )
        if where_matches:
            where_match = where_matches[0]
            table_name = after_from[: where_match.start()].strip()
            filter_condition = after_from[where_match.end() :].strip()
            if not filter_condition:
                raise ValueError("WHERE clause is empty.")
        else:
            table_name = after_from.strip()
            filter_condition = None

        if not table_name:
            raise ValueError("Could not extract table name from SQL. ")

        # Reject trailing content after the table name (e.g. GROUP BY, ORDER BY, LIMIT)
        if " " in table_name or "\t" in table_name:
            raise ValueError(
                f"Found unexpected content after the table name: '{table_name}'. "
                "Only simple SELECT ... FROM ... [WHERE ...] queries are supported. "
                f"{_CONSTRUCT_DIRECTLY_HINT}"
            )

        # Reject subqueries in FROM clause
        if "(" in table_name or ")" in table_name:
            raise ValueError(
                "Subqueries in the FROM clause are not supported. "
                f"{_CONSTRUCT_DIRECTLY_HINT}"
            )

        transformation_sql = select_part if select_part else "*"

        return DeltaTableSource.ParsedSQL(
            table_name=table_name,
            transformation_sql=transformation_sql,
            filter_condition=filter_condition,
        )

    @classmethod
    def from_sql(
        cls,
        *,
        sql: str,
        spark_client: SparkClient,
    ) -> "DeltaTableSource":
        """Create a DeltaTableSource from a SQL query string.

        Parses the SQL to extract table name, transformation_sql, and filter_condition.

        This is a best-effort convenience method that only supports simple queries
        (one SELECT, one FROM, optional WHERE). Not all simple queries will work.
        For complex SQL or unsupported queries, construct DeltaTableSource directly
        with fields passed individually.

        Args:
            sql: A SQL query string (e.g., "SELECT a, b FROM catalog.schema.table WHERE x > 1").
            spark_client: The Spark client for schema inference.

        Returns:
            A DeltaTableSource instance.

        Raises:
            ValueError: If the SQL cannot be parsed or the table name is not 3-part.
        """
        parsed = cls._parse_sql(sql)

        # Validate 3-part table name
        parts = parsed.table_name.split(".")
        if len(parts) != 3:
            raise ValueError(
                f"Table name '{parsed.table_name}' is not in 'catalog.schema.table' format. "
                "DeltaTableSource requires a 3-part name."
            )

        # Infer schema_json
        schema_json = None
        try:
            source = cls(
                catalog_name=parts[0],
                schema_name=parts[1],
                table_name=parts[2],
                filter_condition=parsed.filter_condition,
                transformation_sql=parsed.transformation_sql,
            )
            schema_query = source._to_sql() + " LIMIT 0"
            schema_json = spark_client._spark.sql(schema_query).schema.json()
        except Exception as e:
            # Only the first line matters; the rest is JVM stacktrace / query plan noise
            short_error = str(e).splitlines()[0] if str(e).strip() else "unknown error"
            _logger.warning(
                f"Could not infer schema from SQL query: {short_error}. "
                "schema_json will be None."
            )

        return cls(
            catalog_name=parts[0],
            schema_name=parts[1],
            table_name=parts[2],
            filter_condition=parsed.filter_condition,
            transformation_sql=parsed.transformation_sql,
            schema_json=schema_json,
        )

    def __hash__(self):
        """Make DeltaTableSource hashable by using immutable representations of its attributes."""
        entity_columns_hashable = (
            tuple(self._entity_columns) if self._entity_columns is not None else None
        )
        return hash(
            (
                self._source_type,
                entity_columns_hashable,
                self._timeseries_column,
                self._catalog_name,
                self._schema_name,
                self._table_name,
                self._filter_condition,
                self._transformation_sql,
                self._schema_json,
            )
        )

    @staticmethod
    def _truncate(text, max_length=100):
        """Truncate text to max_length characters, appending '...' if truncated."""
        if len(text) <= max_length:
            return text
        return text[:max_length] + "..."

    def __str__(self) -> str:
        """Return a concise string representation of the data source."""
        entities_str = (
            ", ".join(self._entity_columns)
            if self._entity_columns is not None
            else "None"
        )
        parts = [
            f"entity_columns=({entities_str})",
            f"timeseries_column={self._timeseries_column}",
        ]
        if self._filter_condition:
            parts.append(f"filter={self._truncate(self._filter_condition)}")
        if self._transformation_sql:
            parts.append(f"transformation={self._truncate(self._transformation_sql)}")
        return f"{self.full_name()}[{', '.join(parts)}]"

    def __repr__(self) -> str:
        """Return a detailed string representation of the data source."""
        return (
            f"DeltaTableSource(catalog_name={self._catalog_name!r}, "
            f"schema_name={self._schema_name!r}, table_name={self._table_name!r}, "
            f"entity_columns={self._entity_columns!r}, "
            f"timeseries_column={self._timeseries_column!r}, "
            f"filter_condition={self._filter_condition!r}, "
            f"transformation_sql={self._transformation_sql!r}, "
            f"schema_json={self._schema_json!r})"
        )

    def _validate_delta_parameters(
        self, catalog_name: str, schema_name: str, table_name: str
    ):
        """Validates Delta-specific parameters."""
        if not catalog_name or not isinstance(catalog_name, str):
            raise ValueError("The 'catalog_name' must be a non-empty string.")

        if not schema_name or not isinstance(schema_name, str):
            raise ValueError("The 'schema_name' must be a non-empty string.")

        if not table_name or not isinstance(table_name, str):
            raise ValueError("The 'table_name' must be a non-empty string.")

    @staticmethod
    def _validate_transformation_parameters(
        filter_condition: Optional[str],
        transformation_sql: Optional[str],
        schema_json: Optional[str],
    ):
        """Validates transformation-related parameters."""
        if filter_condition is not None:
            if not isinstance(filter_condition, str) or not filter_condition.strip():
                raise ValueError(
                    "The 'filter_condition' must be a non-empty string if provided."
                )
        if transformation_sql is not None:
            if (
                not isinstance(transformation_sql, str)
                or not transformation_sql.strip()
            ):
                raise ValueError(
                    "The 'transformation_sql' must be a non-empty string if provided."
                )
        if schema_json is not None:
            if not isinstance(schema_json, str) or not schema_json.strip():
                raise ValueError(
                    "The 'schema_json' must be a non-empty string if provided."
                )

    def _to_yaml_dict(self) -> Dict[str, Any]:
        """Convert the DeltaTableSource to a dictionary that can be used to generate a YAML file."""
        result: dict[str, list[str] | str] = {
            DeltaTableSource.CATALOG_NAME_FIELD_NAME: self._catalog_name,
            DeltaTableSource.SCHEMA_NAME_FIELD_NAME: self._schema_name,
            DeltaTableSource.TABLE_NAME_FIELD_NAME: self._table_name,
        }
        if self._entity_columns is not None:
            result[DeltaTableSource.ENTITY_COLUMNS_FIELD_NAME] = self._entity_columns
        if self._timeseries_column is not None:
            result[
                DeltaTableSource.TIMESERIES_COLUMN_FIELD_NAME
            ] = self._timeseries_column
        if self._filter_condition is not None:
            result[
                DeltaTableSource.FILTER_CONDITION_FIELD_NAME
            ] = self._filter_condition
        if self._transformation_sql is not None:
            result[
                DeltaTableSource.TRANSFORMATION_SQL_FIELD_NAME
            ] = self._transformation_sql
        if self._schema_json is not None:
            result[DeltaTableSource.SCHEMA_JSON_FIELD_NAME] = self._schema_json
        return result

    @classmethod
    def _from_yaml_dict(cls, data_source_dict: Dict[str, Any]) -> "DeltaTableSource":
        """Create a DeltaTableSource from a dictionary loaded from YAML."""
        with suppress_deprecation_warnings():
            return cls(
                catalog_name=data_source_dict[DeltaTableSource.CATALOG_NAME_FIELD_NAME],
                schema_name=data_source_dict[DeltaTableSource.SCHEMA_NAME_FIELD_NAME],
                table_name=data_source_dict[DeltaTableSource.TABLE_NAME_FIELD_NAME],
                entity_columns=data_source_dict.get(
                    DeltaTableSource.ENTITY_COLUMNS_FIELD_NAME
                ),
                timeseries_column=data_source_dict.get(
                    DeltaTableSource.TIMESERIES_COLUMN_FIELD_NAME
                ),
                filter_condition=data_source_dict.get(
                    DeltaTableSource.FILTER_CONDITION_FIELD_NAME
                ),
                transformation_sql=data_source_dict.get(
                    DeltaTableSource.TRANSFORMATION_SQL_FIELD_NAME
                ),
                schema_json=data_source_dict.get(
                    DeltaTableSource.SCHEMA_JSON_FIELD_NAME
                ),
            )

    def _to_sdk_data_source(self) -> SDKDataSource:
        sdk_delta = SDKDeltaTableSource(full_name=self.full_name())
        if self._entity_columns is not None:
            sdk_delta.entity_columns = list(self._entity_columns)
        if self._timeseries_column is not None:
            sdk_delta.timeseries_column = self._timeseries_column
        if self._filter_condition is not None:
            sdk_delta.filter_condition = self._filter_condition
        if self._transformation_sql is not None:
            sdk_delta.transformation_sql = self._transformation_sql
        if self._schema_json is not None:
            sdk_delta.dataframe_schema = self._schema_json
        return SDKDataSource(delta_table_source=sdk_delta)

    @classmethod
    def _from_sdk_data_source(
        cls, sdk_source: SDKDeltaTableSource
    ) -> "DeltaTableSource":
        if sdk_source.full_name is None:
            raise ValueError("SDK DeltaTableSource must include 'full_name'")

        parts = sdk_source.full_name.split(".")
        if len(parts) != 3:
            raise ValueError(
                f"The full_name of DeltaTableSource {sdk_source.full_name} is not in '<catalog>.<schema>.<table>' format"
            )

        entity_columns = getattr(sdk_source, "entity_columns", None)
        timeseries_column = getattr(sdk_source, "timeseries_column", None)
        filter_condition = getattr(sdk_source, "filter_condition", None)

        with suppress_deprecation_warnings():
            return DeltaTableSource(
                catalog_name=parts[0],
                schema_name=parts[1],
                table_name=parts[2],
                entity_columns=list(entity_columns)
                if entity_columns is not None
                else None,
                timeseries_column=timeseries_column,
                filter_condition=filter_condition,
                transformation_sql=getattr(sdk_source, "transformation_sql", None),
                schema_json=getattr(sdk_source, "dataframe_schema", None),
            )


class VolumeSource(DataSource):
    """
    Data source implementation for Unity Catalog Volumes.

    TODO: Implementation to be defined based on volume requirements.
    """

    def __init__(
        self,
        *,
        entity_columns: List[str],
        timeseries_column: str,
    ):
        """Initialize a VolumeSource object. See class documentation."""
        super().__init__(
            source_type=DataSourceTypes.VOLUME,
            entity_columns=entity_columns,
            timeseries_column=timeseries_column,
        )

    def full_name(self) -> str:
        """Return the full volume path identifier."""
        # TODO: Implement volume-specific naming convention
        raise NotImplementedError("VolumeSource.full_name() is not yet implemented.")

    def load_df(
        self,
        spark_client,
    ):
        """Load the volume data as a Spark DataFrame."""
        # TODO: Implement volume-specific DataFrame loading
        raise NotImplementedError("VolumeSource.load_df() is not yet implemented.")

    def __hash__(self):
        """Make VolumeSource hashable."""
        # TODO: Implement volume-specific hash when volume attributes are defined
        raise NotImplementedError("VolumeSource.__hash__() is not yet implemented.")


def _build_struct_schema_from_kafka_columns(
    columns: Dict[str, SparkDataType],
) -> StructType:
    """
    Build a StructType with top-level "key" and/or "value" STRUCT columns from
    the flat dot-prefixed column map returned by ``get_columns_from_kafka_config``.

    Input keys are dot-paths like ``"key.customer_id"``, ``"value.amount"``,
    ``"value.details.tip_amount"``.  The first segment is always ``"key"`` or
    ``"value"``; remaining segments are nested struct fields.

    Returns:
        StructType with one or two top-level StructField entries ("key", "value"),
        each containing a nested StructType that mirrors the Kafka JSON schemas.
    """

    def _insert(tree: dict, segments: List[str], spark_type: SparkDataType) -> None:
        """Recursively insert a leaf type into a nested dict-of-dicts tree."""
        if len(segments) == 1:
            tree[segments[0]] = spark_type
        else:
            subtree = tree.setdefault(segments[0], {})
            _insert(subtree, segments[1:], spark_type)

    def _to_struct_type(tree: dict) -> StructType:
        """Convert a nested dict tree into a StructType."""
        fields = []
        for name, value in tree.items():
            if isinstance(value, dict):
                fields.append(StructField(name, _to_struct_type(value), nullable=True))
            else:
                fields.append(StructField(name, value, nullable=True))
        return StructType(fields)

    # Group by top-level prefix ("key" / "value"), then build nested tree.
    tree: Dict[str, dict] = {}
    for dot_path, spark_type in columns.items():
        segments = dot_path.split(".")
        if len(segments) < 2:
            raise ValueError(
                f"Kafka column path '{dot_path}' must have at least a prefix and a field name "
                f"(e.g., 'key.id' or 'value.amount')."
            )
        prefix = segments[0]
        subtree = tree.setdefault(prefix, {})
        _insert(subtree, segments[1:], spark_type)

    # Build top-level schema with one StructField per prefix.
    top_fields = []
    for prefix in ("key", "value"):
        if prefix in tree:
            top_fields.append(
                StructField(prefix, _to_struct_type(tree[prefix]), nullable=True)
            )
    return StructType(top_fields)


class KafkaSource(DataSource):
    """
    Data source implementation for Kafka streams.

    KafkaSource references a KafkaConfig by name. The KafkaConfig contains connection details, authentication, and schemas for the Kafka topics.
    Column names must be prefixed with 'key.' or 'value.' to indicate which schema to use. Examples: 'key.customer_id' or 'value.trip_details.pickup_zip' for nested JSON fields.

    :param name: Name of the KafkaConfig to use (uniquely identifies the KafkaConfig in the metastore)
    :param entity_columns: List of column names with schema prefix (e.g., ['key.customer_id', 'value.trip_details.pickup_zip'])
    :param timeseries_column: Column name with schema prefix (e.g., 'value.event_timestamp')
    """

    class SchemaType:
        """Constants for Kafka schema types."""

        KEY = "key"
        VALUE = "value"

    NAME_FIELD_NAME = "name"
    ENTITY_COLUMNS_FIELD_NAME = "entity_columns"
    TIMESERIES_COLUMN_FIELD_NAME = "timeseries_column"
    FILTER_CONDITION_FIELD_NAME = "filter_condition"

    # TODO[FS-871]: Remove `entity_columns` and `timeseries_column` params
    # when breaking backwards compatibility. These move to Feature.
    def __init__(
        self,
        *,
        name: str,
        filter_condition: Optional[str] = None,
        **kwargs,
    ):
        """Initialize a KafkaSource object. See class documentation.

        Keyword Args:
            entity_columns: (deprecated) List of column names with schema prefix.
                Use Feature(entity=...) instead.
            timeseries_column: (deprecated) Column name with schema prefix.
                Use Feature(timeseries_column=...) instead.
        """
        entity_columns = kwargs.pop("entity_columns", None)
        timeseries_column = kwargs.pop("timeseries_column", None)
        if kwargs:
            raise TypeError(
                f"KafkaSource.__init__() got unexpected keyword arguments: "
                f"{', '.join(repr(k) for k in kwargs)}"
            )
        self._validate_kafka_parameters(name)

        if flags.ENABLE_DECLARATIVE_FEATURE_API_DEPRECATION_WARNINGS:
            if entity_columns is not None:
                emit_deprecation_warning(
                    "entity_columns", "KafkaSource", "Feature(entity=...)"
                )
            if timeseries_column is not None:
                emit_deprecation_warning(
                    "timeseries_column", "KafkaSource", "Feature(timeseries_column=...)"
                )

        super().__init__(
            source_type=DataSourceTypes.KAFKA,
            entity_columns=entity_columns,
            timeseries_column=timeseries_column,
        )

        self._name = name
        self._filter_condition = filter_condition

    @property
    def name(self) -> str:
        """The name of the KafkaConfig this source references."""
        return self._name

    def full_name(self) -> str:
        """Return the Kafka config name as the full identifier."""
        return self._name

    @property
    def filter_condition(self) -> Optional[str]:
        """Optional filter condition to apply when reading from this source."""
        return self._filter_condition

    def load_df(
        self,
        spark_client,
    ):
        """
        Return a DataFrame for Kafka sources.

        When backfill_source is configured on the KafkaConfig, reads the backfill
        Delta table directly. Otherwise, returns an empty DataFrame with key/value
        STRUCT columns matching the KafkaConfig schemas.

        Entity and timeseries extraction to leaf names happens in
        pit_computation_utils.py, not here.

        Args:
            spark_client: The Spark client for DataFrame operations
        """
        from databricks.sdk import WorkspaceClient

        spark = spark_client._spark
        workspace_client = WorkspaceClient()

        # Fetch KafkaConfig schema (let errors propagate for fail-fast behavior)
        kafka_config = workspace_client.feature_engineering.get_kafka_config(
            name=self._name
        )

        # Backfill path: read the Delta table directly and return the raw struct DF.
        # Filter is NOT applied here — PIT handles filtering via _effective_filter_condition.
        if kafka_config.backfill_source:
            table_name = kafka_config.backfill_source.delta_table_source.full_name
            _logger.debug(
                f"Reading backfill table '{table_name}' for KafkaConfig '{self._name}'"
            )
            return spark.read.table(table_name)

        # Empty path: build a 0-row struct DF from the KafkaConfig schemas.
        # The DF has top-level STRUCT columns ("key" and/or "value") with nested
        # fields matching the JSON schemas, so PIT can use native struct access
        # for entity/timeseries extraction — same code path as backfill DFs.
        kafka_schema_columns = KafkaSource.get_columns_from_kafka_config(kafka_config)
        _logger.debug(
            f"Retrieved {len(kafka_schema_columns)} columns from KafkaConfig '{self._name}'"
        )

        schema = _build_struct_schema_from_kafka_columns(kafka_schema_columns)
        return spark.createDataFrame([], schema)

    def __hash__(self):
        """Make KafkaSource hashable by using immutable representations of its attributes."""
        entity_columns_hashable = (
            tuple(self._entity_columns) if self._entity_columns is not None else None
        )
        return hash(
            (
                self._source_type,
                self._name,
                entity_columns_hashable,
                self._timeseries_column,
                self._filter_condition,
            )
        )

    def __str__(self) -> str:
        """Return a concise string representation of the data source."""
        entities_str = (
            ", ".join(self._entity_columns)
            if self._entity_columns is not None
            else "None"
        )
        filter_str = (
            f", filter_condition={self._filter_condition}"
            if self._filter_condition
            else ""
        )
        return (
            f"KafkaSource(name={self.full_name()}, "
            f"entity_columns=[{entities_str}], "
            f"timeseries_column={self._timeseries_column}"
            f"{filter_str})"
        )

    def __repr__(self) -> str:
        """Return a detailed string representation of the data source."""
        return (
            f"KafkaSource(name={self._name!r}, "
            f"entity_columns={self._entity_columns!r}, "
            f"timeseries_column={self._timeseries_column!r}, "
            f"filter_condition={self._filter_condition!r})"
        )

    def _validate_kafka_parameters(self, name: str):
        """Validates Kafka-specific parameters."""
        if not name or not isinstance(name, str):
            raise ValueError("The 'name' must be a non-empty string")

    @staticmethod
    def _json_type_to_spark_type(
        json_type: str, json_schema_node: dict
    ) -> SparkDataType:
        """
        Convert a JSON schema type to a Spark DataType.

        Args:
            json_type: The JSON schema type (string, integer, number, boolean, array, object)
            json_schema_node: The full JSON schema node (for complex types like array)

        Returns:
            The corresponding Spark DataType
        """
        type_mapping = {
            "string": StringType(),
            "integer": LongType(),
            "number": DoubleType(),
            "boolean": BooleanType(),
            "timestamp": TimestampType(),  # Non-standard but kept for common usage
        }

        if json_type == "string":
            format_value = json_schema_node.get("format", "")
            if format_value == "date-time":
                return TimestampType()
            if format_value == "date":
                return DateType()
            if format_value:
                raise ValueError(
                    f"Unsupported JSON schema string format '{format_value}'. "
                    f"Supported formats are: 'date-time', 'date'."
                )

        if json_type in type_mapping:
            return type_mapping[json_type]

        if json_type == "array":
            # For arrays, try to get the item type
            items = json_schema_node.get("items", {})
            item_type = items.get("type", "string")
            element_type = KafkaSource._json_type_to_spark_type(item_type, items)
            return ArrayType(element_type)

        if json_type == "object":
            # For nested objects, use StructType
            properties = json_schema_node.get("properties", {})
            fields = []
            for prop_name, prop_schema in properties.items():
                prop_type = prop_schema.get("type", "string")
                spark_type = KafkaSource._json_type_to_spark_type(
                    prop_type, prop_schema
                )
                fields.append(StructField(prop_name, spark_type, nullable=True))
            return StructType(fields) if fields else MapType(StringType(), StringType())

        raise ValueError(
            f"Unsupported JSON schema type '{json_type}'. "
            f"Supported types are: string, integer, number, boolean, array, object."
        )

    @staticmethod
    def _extract_columns_from_json_schema(
        json_schema_str: str, prefix: str
    ) -> Dict[str, SparkDataType]:
        """
        Extract all column paths and their Spark types from a JSON schema.

        Args:
            json_schema_str: The JSON schema string
            prefix: The prefix to add to column names ('key' or 'value')

        Returns:
            Dictionary mapping dot-prefixed column paths to Spark DataTypes
        """
        columns = {}

        try:
            schema = json.loads(json_schema_str)
        except json.JSONDecodeError as ex:
            raise ValueError(
                f"Invalid JSON schema provided. Unable to parse schema: {ex}. "
                f"Please verify the schema is valid JSON."
            ) from ex

        def extract_leaf_columns(node: dict, path_prefix: str):
            """Recursively extract leaf columns from a JSON schema node."""
            if not isinstance(node, dict):
                return

            properties = node.get("properties", {})
            for prop_name, prop_schema in properties.items():
                full_path = f"{path_prefix}.{prop_name}" if path_prefix else prop_name
                prop_type = prop_schema.get("type", "string")

                # For nested objects, extract leaf columns recursively
                if prop_type == "object" and "properties" in prop_schema:
                    extract_leaf_columns(prop_schema, full_path)
                else:
                    # This is a leaf column - add it with its Spark type
                    prefixed_path = f"{prefix}.{full_path}"
                    spark_type = KafkaSource._json_type_to_spark_type(
                        prop_type, prop_schema
                    )
                    columns[prefixed_path] = spark_type

        extract_leaf_columns(schema, "")
        return columns

    @staticmethod
    def get_columns_from_kafka_config(kafka_config) -> Dict[str, SparkDataType]:
        """
        Extract all columns and their Spark types from a KafkaConfig.

        This method parses the key_schema and value_schema from the KafkaConfig
        and returns a dictionary mapping column names (with key./value. prefixes)
        to their Spark DataTypes.

        Args:
            kafka_config: The KafkaConfig object containing schema information

        Returns:
            Dictionary mapping dot-prefixed column names to Spark DataTypes
        """
        columns = {}

        # Extract columns from key schema
        if kafka_config.key_schema and hasattr(kafka_config.key_schema, "json_schema"):
            key_schema_str = kafka_config.key_schema.json_schema
            if key_schema_str:
                key_columns = KafkaSource._extract_columns_from_json_schema(
                    key_schema_str, KafkaSource.SchemaType.KEY
                )
                columns.update(key_columns)

        # Extract columns from value schema
        if kafka_config.value_schema and hasattr(
            kafka_config.value_schema, "json_schema"
        ):
            value_schema_str = kafka_config.value_schema.json_schema
            if value_schema_str:
                value_columns = KafkaSource._extract_columns_from_json_schema(
                    value_schema_str, KafkaSource.SchemaType.VALUE
                )
                columns.update(value_columns)

        return columns

    def _to_yaml_dict(self) -> Dict[str, Any]:
        """Convert the KafkaSource to a dictionary that can be used to generate a YAML file."""
        result = {KafkaSource.NAME_FIELD_NAME: self._name}
        if self._entity_columns is not None:
            result[KafkaSource.ENTITY_COLUMNS_FIELD_NAME] = self._entity_columns
        if self._timeseries_column is not None:
            result[KafkaSource.TIMESERIES_COLUMN_FIELD_NAME] = self._timeseries_column
        if self._filter_condition is not None:
            result[KafkaSource.FILTER_CONDITION_FIELD_NAME] = self._filter_condition
        return result

    @classmethod
    def _from_yaml_dict(cls, data_source_dict: Dict[str, Any]) -> "KafkaSource":
        """Create a KafkaSource from a dictionary loaded from YAML."""
        with suppress_deprecation_warnings():
            return cls(
                name=data_source_dict[KafkaSource.NAME_FIELD_NAME],
                entity_columns=data_source_dict.get(
                    KafkaSource.ENTITY_COLUMNS_FIELD_NAME
                ),
                timeseries_column=data_source_dict.get(
                    KafkaSource.TIMESERIES_COLUMN_FIELD_NAME
                ),
                filter_condition=data_source_dict.get(
                    KafkaSource.FILTER_CONDITION_FIELD_NAME
                ),
            )

    def _to_sdk_data_source(self) -> SDKDataSource:
        """Convert to SDK DataSource format for proto serialization. Converts string columns to ColumnIdentifier objects as required by proto."""
        sdk_kafka_source = SDKKafkaSource(name=self.name)
        # Convert entity columns (strings) to ColumnIdentifier objects
        if self._entity_columns is not None:
            sdk_kafka_source.entity_column_identifiers = [
                ColumnIdentifier(variant_expr_path=col) for col in self._entity_columns
            ]
        # Convert timeseries column to ColumnIdentifier
        if self._timeseries_column is not None:
            sdk_kafka_source.timeseries_column_identifier = ColumnIdentifier(
                variant_expr_path=self._timeseries_column
            )
        if self._filter_condition is not None:
            sdk_kafka_source.filter_condition = self._filter_condition
        return SDKDataSource(kafka_source=sdk_kafka_source)

    @classmethod
    def _from_sdk_data_source(cls, sdk_source: SDKKafkaSource) -> "KafkaSource":
        """Create KafkaSource from SDK format. Converts ColumnIdentifier objects back to simple strings."""
        if sdk_source.name is None:
            raise ValueError("SDK KafkaSource must include 'name'")

        raw_entity_column_identifiers = getattr(
            sdk_source, "entity_column_identifiers", None
        )
        entity_columns = (
            [col_id.variant_expr_path for col_id in raw_entity_column_identifiers]
            if raw_entity_column_identifiers is not None
            else None
        )
        raw_timeseries_identifier = getattr(
            sdk_source, "timeseries_column_identifier", None
        )
        timeseries_column = (
            raw_timeseries_identifier.variant_expr_path
            if raw_timeseries_identifier is not None
            else None
        )
        filter_condition = getattr(sdk_source, "filter_condition", None)

        with suppress_deprecation_warnings():
            return KafkaSource(
                name=sdk_source.name,
                entity_columns=entity_columns,
                timeseries_column=timeseries_column,
                filter_condition=filter_condition,
            )


class DataFrameSource(DataSource):
    """
    Data source implementation for Spark DataFrames.

    This allows using an existing Spark DataFrame directly as a data source
    for feature computation, useful for in-memory data processing and testing.

    :param dataframe: The Spark DataFrame to use as the data source
    :param entity_columns: List of column names that serve as primary keys
    :param timeseries_column: Column name that contains timestamp data
    :param source_name: Optional name for the DataFrame source (for identification)
    """

    def __init__(
        self,
        *,
        dataframe,  # Will be validated as Spark DataFrame
        entity_columns: List[str],
        timeseries_column: str,
        source_name: Optional[str] = None,
    ):
        """Initialize a DataFrameSource object. See class documentation."""
        self._validate_dataframe_parameters(dataframe, source_name)

        # Initialize the parent with DATAFRAME type
        super().__init__(
            source_type=DataSourceTypes.DATAFRAME,
            entity_columns=entity_columns,
            timeseries_column=timeseries_column,
        )

        self._dataframe = dataframe
        self._source_name = source_name

    @property
    def dataframe(self):
        """The Spark DataFrame being used as the data source."""
        return self._dataframe

    @property
    def source_name(self) -> str:
        """The name identifier for this DataFrame source."""
        return self._source_name

    def full_name(self) -> str:
        """Return the source name identifier for this DataFrame."""
        return (
            self._source_name
            if self._source_name
            else f"DataFrameSource with schema : {self.dataframe.schema.simpleString()}"
        )

    def load_df(
        self,
        spark_client,
    ):
        """Return the existing Spark DataFrame."""
        return self._dataframe

    def __hash__(self):
        """Make DataFrameSource hashable by using immutable representations of its attributes."""
        # Get schema information from the DataFrame
        # Convert schema to a hashable representation (sorted tuple of field names and types)
        # Sort by field name to ensure consistent hashing regardless of field order
        schema_fields = tuple(
            sorted(
                (field.name, str(field.dataType))
                for field in self._dataframe.schema.fields
            )
        )

        # Note: We cannot hash the DataFrame itself as it's mutable
        # Use source_name and schema as the identifier for the DataFrame
        return hash(
            (
                self._source_type,
                tuple(self._entity_columns),
                self._timeseries_column,
                self._source_name,
                schema_fields,
            )
        )

    def __str__(self) -> str:
        """Return a concise string representation of the data source."""
        entities_str = ", ".join(self._entity_columns)
        name = self._source_name if self._source_name else "DataFrame"
        return f"{name}[entity_columns=({entities_str}), timeseries_column={self._timeseries_column}]"

    def __repr__(self) -> str:
        """Return a detailed string representation of the data source."""
        return (
            f"DataFrameSource(source_name={self._source_name!r}, "
            f"entity_columns={self._entity_columns!r}, "
            f"timeseries_column={self._timeseries_column!r})"
        )

    def _validate_dataframe_parameters(self, dataframe, source_name: str):
        """Validates DataFrame-specific parameters."""
        if dataframe is None:
            raise ValueError("The 'dataframe' cannot be None.")

        # Import DataFrame locally for isinstance check
        try:
            from pyspark.sql import DataFrame

            if not isinstance(dataframe, DataFrame):
                raise ValueError("The 'dataframe' must be a valid Spark DataFrame.")
        except ImportError:
            raise ImportError("PySpark is required to use DataFrameSource.")

        if source_name is not None and (
            not isinstance(source_name, str) or not source_name.strip()
        ):
            raise ValueError(
                "The 'source_name' must be a non-empty string if provided."
            )


class RequestSource(DataSource):
    """
    Data source implementation for request-time features.

    :param schema: List of ``FieldDefinition`` objects defining the request-time fields.
    """

    TYPE_VALUE = "RequestSource"
    YAML_SCHEMA_KEY = "schema"
    YAML_FLAT_SCHEMA_TYPE = "FlatSchema"
    YAML_FLAT_SCHEMA_KEY = "flat_schema"

    def __init__(
        self,
        *,
        schema: List[SDKFieldDefinition],
    ):
        """Initialize a RequestSource object. See class documentation."""
        self._validate_request_source_parameters(schema)
        super().__init__(source_type=DataSourceTypes.REQUEST)
        self._schema = list(schema)

    @property
    def schema(self) -> List[SDKFieldDefinition]:
        """The list of ``FieldDefinition`` objects defining the request-time fields."""
        return list(self._schema)

    def full_name(self) -> str:
        """Return a unique identifier for this RequestSource."""
        fields = sorted(f"{f.name}:{f.data_type.name}" for f in self._schema)
        return f"RequestSource[{','.join(fields)}]"

    def load_df(
        self,
        spark_client,
    ):
        """RequestSource does not load data — values come from the labeled dataframe at training time, or the request at inference time."""
        raise ValueError(
            "RequestSource does not load data. "
            "Values come from the labeled dataframe at training time, "
            "or the request at inference time."
        )

    def _to_yaml_dict(self) -> Dict[str, Any]:
        """Convert the RequestSource to a dictionary that can be used to generate a YAML file."""
        fields_list = [
            {"name": field.name, "data_type": field.data_type.name}
            for field in self._schema
        ]
        return {
            "type": self.TYPE_VALUE,
            self.YAML_SCHEMA_KEY: {
                "type": self.YAML_FLAT_SCHEMA_TYPE,
                self.YAML_FLAT_SCHEMA_KEY: fields_list,
            },
        }

    @classmethod
    def _from_yaml_dict(cls, data_source_dict: Dict[str, Any]) -> "RequestSource":
        """Create a RequestSource from a dictionary loaded from YAML."""
        schema_dict = data_source_dict.get(cls.YAML_SCHEMA_KEY, {})
        fields_list = schema_dict.get(cls.YAML_FLAT_SCHEMA_KEY, [])
        schema = [
            SDKFieldDefinition(
                name=field["name"],
                data_type=SDKScalarDataType[field["data_type"]],
            )
            for field in fields_list
        ]
        return cls(schema=schema)

    def _to_sdk_data_source(self) -> SDKDataSource:
        """Convert to SDK DataSource format."""
        sdk_request_source = SDKRequestSource(
            flat_schema=SDKFlatSchema(fields=self._schema)
        )
        return SDKDataSource(request_source=sdk_request_source)

    @classmethod
    def _from_sdk_data_source(cls, sdk_source) -> "RequestSource":
        """Create RequestSource from SDK format."""
        if sdk_source.flat_schema is None:
            raise ValueError("SDK RequestSource must include 'flat_schema'")
        return cls(schema=list(sdk_source.flat_schema.fields))

    @staticmethod
    def _validate_request_source_parameters(schema):
        """Validates RequestSource-specific parameters."""
        if not isinstance(schema, list):
            raise ValueError("The 'schema' must be a list of FieldDefinition objects.")
        if len(schema) == 0:
            raise ValueError("The 'schema' must contain at least one FieldDefinition.")
        for i, field in enumerate(schema):
            if not isinstance(field, SDKFieldDefinition):
                raise ValueError(
                    f"Each schema entry must be a FieldDefinition. "
                    f"Invalid entry at index {i}: {field!r}"
                )
            if not field.name or not field.name.strip():
                raise ValueError(
                    f"Each FieldDefinition must have a non-empty 'name'. "
                    f"Invalid field at index {i}: {field!r}"
                )
            if not isinstance(field.data_type, SDKScalarDataType):
                raise ValueError(
                    f"Each FieldDefinition must have a ScalarDataType 'data_type'. "
                    f"Invalid field at index {i}: {field!r}"
                )
        grouped_names = defaultdict(list)
        for field in schema:
            grouped_names[field.name.lower()].append(field.name)
        duplicates = {k: names for k, names in grouped_names.items() if len(names) > 1}
        if duplicates:
            conflicts = ", ".join(
                f"{{{', '.join(repr(n) for n in names)}}}"
                for names in duplicates.values()
            )
            raise ValueError(
                f"Duplicate field names in RequestSource schema (case-insensitive): "
                f"{conflicts}"
            )

    def __hash__(self):
        """Make RequestSource hashable by using immutable representations of its attributes."""
        return hash(
            (self._source_type, tuple((f.name, f.data_type) for f in self._schema))
        )

    def __str__(self) -> str:
        """Return a concise string representation of the data source."""
        fields_str = ", ".join(
            f"{field.name}:{field.data_type.name}" for field in self._schema
        )
        return f"RequestSource[{fields_str}]"

    def __repr__(self) -> str:
        """Return a detailed string representation of the data source."""
        return f"RequestSource(schema={self._schema!r})"
