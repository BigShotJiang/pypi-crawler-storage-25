from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

from pyspark.sql import Column
from pyspark.sql import functions as F

from databricks.ml_features import flags
from databricks.ml_features.entities.aggregation import TimeWindow
from databricks.ml_features.entities.aggregation_function import AggregationFunction
from databricks.ml_features.entities.column_selection import (
    COLUMN_SELECTION_TYPE,
    ColumnSelection,
)
from databricks.ml_features.entities.data_source import DataSource, RequestSource
from databricks.ml_features.entities.function import (
    ApproxCountDistinct,
    ApproxPercentile,
    Avg,
    Count,
    First,
    Function,
    Last,
    Max,
    Min,
    StddevPop,
    StddevSamp,
    Sum,
    VarPop,
    VarSamp,
)
from databricks.ml_features.utils.deprecation_utils import (
    emit_deprecation_warning,
    suppress_deprecation_warnings,
)
from databricks.ml_features_common.entities._feature_store_object import (
    _FeatureStoreObject,
)
from databricks.sdk.service.ml import AggregationFunction as SDKAggregationFunction
from databricks.sdk.service.ml import (
    ApproxCountDistinctFunction as SDKApproxCountDistinctFunction,
)
from databricks.sdk.service.ml import (
    ApproxPercentileFunction as SDKApproxPercentileFunction,
)
from databricks.sdk.service.ml import AvgFunction as SDKAvgFunction
from databricks.sdk.service.ml import CountFunction as SDKCountFunction
from databricks.sdk.service.ml import DataSource as SDKDataSource
from databricks.sdk.service.ml import EntityColumn as SDKEntityColumn
from databricks.sdk.service.ml import Feature as SDKFeature
from databricks.sdk.service.ml import FirstFunction as SDKFirstFunction
from databricks.sdk.service.ml import Function as SDKFunction
from databricks.sdk.service.ml import LastFunction as SDKLastFunction
from databricks.sdk.service.ml import MaxFunction as SDKMaxFunction
from databricks.sdk.service.ml import MinFunction as SDKMinFunction
from databricks.sdk.service.ml import StddevPopFunction as SDKStddevPopFunction
from databricks.sdk.service.ml import StddevSampFunction as SDKStddevSampFunction
from databricks.sdk.service.ml import SumFunction as SDKSumFunction
from databricks.sdk.service.ml import TimeseriesColumn as SDKTimeseriesColumn
from databricks.sdk.service.ml import TimeWindow as SDKTimeWindow
from databricks.sdk.service.ml import VarPopFunction as SDKVarPopFunction
from databricks.sdk.service.ml import VarSampFunction as SDKVarSampFunction


def _make_sdk_entity_column(name: str) -> SDKEntityColumn:
    return SDKEntityColumn(name=name)


def _make_sdk_timeseries_column(name: str) -> SDKTimeseriesColumn:
    return SDKTimeseriesColumn(name=name)


def _typed_function_to_sdk_aggregation_function(
    aggregation_function: AggregationFunction,
) -> SDKAggregationFunction:
    """Convert a canonical AggregationFunction to an SDK Aggregation object."""
    typed_function = aggregation_function.function
    sdk_agg = SDKAggregationFunction()
    if isinstance(typed_function, Avg):
        sdk_agg.avg = SDKAvgFunction(input=typed_function.input)
    elif isinstance(typed_function, Count):
        sdk_agg.count_function = SDKCountFunction(input=typed_function.input)
    elif isinstance(typed_function, Sum):
        sdk_agg.sum = SDKSumFunction(input=typed_function.input)
    elif isinstance(typed_function, Min):
        sdk_agg.min = SDKMinFunction(input=typed_function.input)
    elif isinstance(typed_function, Max):
        sdk_agg.max = SDKMaxFunction(input=typed_function.input)
    elif isinstance(typed_function, First):
        sdk_agg.first = SDKFirstFunction(input=typed_function.input)
    elif isinstance(typed_function, Last):
        sdk_agg.last = SDKLastFunction(input=typed_function.input)
    elif isinstance(typed_function, StddevPop):
        sdk_agg.stddev_pop = SDKStddevPopFunction(input=typed_function.input)
    elif isinstance(typed_function, StddevSamp):
        sdk_agg.stddev_samp = SDKStddevSampFunction(input=typed_function.input)
    elif isinstance(typed_function, VarPop):
        sdk_agg.var_pop = SDKVarPopFunction(input=typed_function.input)
    elif isinstance(typed_function, VarSamp):
        sdk_agg.var_samp = SDKVarSampFunction(input=typed_function.input)
    elif isinstance(typed_function, ApproxCountDistinct):
        sdk_agg.approx_count_distinct = SDKApproxCountDistinctFunction(
            input=typed_function.input,
            relative_sd=typed_function.relativeSD,
        )
    elif isinstance(typed_function, ApproxPercentile):
        sdk_agg.approx_percentile = SDKApproxPercentileFunction(
            input=typed_function.input,
            percentile=typed_function.percentile,
            accuracy=typed_function.accuracy,
        )
    else:
        raise ValueError(
            f"Unsupported function type for SDK conversion: {type(typed_function).__name__}"
        )
    if aggregation_function.time_window is not None:
        sdk_agg.time_window = aggregation_function.time_window._to_sdk_time_window()
    return sdk_agg


def _sdk_aggregation_function_to_typed(sdk_agg_function) -> AggregationFunction:
    """Convert an SDK AggregationFunction back to an AggregationFunction.

    Reads time_window from the SDK aggregation function if present.
    """
    time_window_field = getattr(sdk_agg_function, "time_window", None)
    time_window = (
        TimeWindow._from_sdk_time_window(time_window_field)
        if time_window_field is not None
        else None
    )
    typed_function = None
    if sdk_agg_function.avg is not None:
        typed_function = Avg(input=sdk_agg_function.avg.input)
    elif sdk_agg_function.count_function is not None:
        typed_function = Count(input=sdk_agg_function.count_function.input)
    elif sdk_agg_function.sum is not None:
        typed_function = Sum(input=sdk_agg_function.sum.input)
    elif sdk_agg_function.min is not None:
        typed_function = Min(input=sdk_agg_function.min.input)
    elif sdk_agg_function.max is not None:
        typed_function = Max(input=sdk_agg_function.max.input)
    elif sdk_agg_function.first is not None:
        typed_function = First(input=sdk_agg_function.first.input)
    elif sdk_agg_function.last is not None:
        typed_function = Last(input=sdk_agg_function.last.input)
    elif sdk_agg_function.stddev_pop is not None:
        typed_function = StddevPop(input=sdk_agg_function.stddev_pop.input)
    elif sdk_agg_function.stddev_samp is not None:
        typed_function = StddevSamp(input=sdk_agg_function.stddev_samp.input)
    elif sdk_agg_function.var_pop is not None:
        typed_function = VarPop(input=sdk_agg_function.var_pop.input)
    elif sdk_agg_function.var_samp is not None:
        typed_function = VarSamp(input=sdk_agg_function.var_samp.input)
    elif sdk_agg_function.approx_count_distinct is not None:
        acd = sdk_agg_function.approx_count_distinct
        relative_sd = acd.relative_sd
        if relative_sd is not None and isinstance(relative_sd, str):
            relative_sd = float(relative_sd)
        typed_function = ApproxCountDistinct(input=acd.input, relativeSD=relative_sd)
    elif sdk_agg_function.approx_percentile is not None:
        ap = sdk_agg_function.approx_percentile
        typed_function = ApproxPercentile(
            input=ap.input, percentile=ap.percentile, accuracy=ap.accuracy
        )
    if typed_function is None:
        raise ValueError(
            "SDK Aggregation does not have a recognized typed function field set"
        )
    return AggregationFunction(typed_function, time_window=time_window)


class Feature(_FeatureStoreObject):
    """
    Represents a feature definition that combines a data source with aggregation logic.

    :param catalog_name: The catalog name for the feature (optional, set during registration)
    :param schema_name: The schema name for the feature (optional, set during registration)
    :param name: The name of the feature. Leading and trailing whitespace will be stripped.
                 If not provided or empty after stripping, a name will be auto-generated
                 based on the input columns, function, and time window.
    :param source: The data source for this feature
    :param inputs: List of column names from the source to use as input (legacy, deprecated)
    :param function: The aggregation function to apply. Accepts AggregationFunction
                     or Function (legacy, deprecated in favor of AggregationFunction)
    :param time_window: The time window for the aggregation (legacy, deprecated in favor of AggregationFunction.time_window)
    :param description: Optional description of the feature
    :param filter_condition: Optional SQL filter condition to apply on the source data before aggregation (legacy, deprecated in favor of source-level filter_condition)
    :param entity: List of entity column names
    :param timeseries_column: The timeseries column name
    """

    INPUTS_FIELD_NAME = "inputs"
    DATA_SOURCE_FIELD_NAME = "data_source"
    FUNCTION_FIELD_NAME = "function"
    TIME_WINDOW_FIELD_NAME = "time_window"
    FILTER_CONDITION_FIELD_NAME = "filter_condition"

    # TODO[FS-871]: When breaking backwards compatibility:
    # - Make `entity` non-Optional (required)
    # - Make `timeseries_column` non-Optional (required)
    # - Make `function` non-Optional and accept only AggregationFunction
    # - Remove `inputs` (legacy, replaced by AggregationFunction.input)
    # - Remove `time_window` (legacy, replaced by AggregationFunction.time_window)
    # - Remove `filter_condition` (legacy, replaced by source-level filter_condition)
    def __init__(
        self,
        *,
        source: DataSource,
        function: Union[Function, AggregationFunction, ColumnSelection],
        catalog_name: Optional[str] = None,
        schema_name: Optional[str] = None,
        name: Optional[str] = None,
        description: Optional[str] = None,
        entity: Optional[List[str]] = None,
        timeseries_column: Optional[str] = None,
        **kwargs,
    ):
        """Initialize a Feature object. See class documentation.
        Should not be invoked directly, use `FeatureEngineeringClient.create_feature` instead.
        `create_feature` ensures the Feature is registered in Unity Catalog and properly validated.

        Keyword Args:
            inputs: (deprecated) List of column names from the source to use as input.
                Use AggregationFunction with inputs instead.
            time_window: (deprecated) The time window for the aggregation.
                Use AggregationFunction with time_window instead.
            filter_condition: (deprecated) Optional SQL filter condition.
                Use DeltaTableSource(filter_condition=...) or KafkaSource(filter_condition=...) instead.
        """
        inputs = kwargs.pop("inputs", None)
        time_window = kwargs.pop("time_window", None)
        filter_condition = kwargs.pop("filter_condition", None)
        if kwargs:
            raise TypeError(
                f"Feature.__init__() got unexpected keyword arguments: "
                f"{', '.join(repr(k) for k in kwargs)}"
            )
        # TODO[FS-871]: Block catalog_name/schema_name in constructor; require
        # create_feature() or register_feature() to set them.
        # Validate catalog_name/schema_name: both or neither
        if (catalog_name is None) != (schema_name is None):
            raise ValueError(
                "Both catalog_name and schema_name must be provided, or neither"
            )
        # Validate and store catalog and schema names
        if catalog_name is not None:
            if not isinstance(catalog_name, str) or not catalog_name.strip():
                raise ValueError(
                    "'catalog_name' must be a non-empty string when provided"
                )
            catalog_name = catalog_name.strip()
        if schema_name is not None:
            if not isinstance(schema_name, str) or not schema_name.strip():
                raise ValueError(
                    "'schema_name' must be a non-empty string when provided"
                )
            schema_name = schema_name.strip()
        self._catalog_name = catalog_name
        self._schema_name = schema_name
        self._is_registered = False
        # Strip whitespace from name if provided
        if name is not None and isinstance(name, str):
            name = name.strip()
        # Emit deprecation warnings for legacy params
        if flags.ENABLE_DECLARATIVE_FEATURE_API_DEPRECATION_WARNINGS:
            if inputs is not None:
                emit_deprecation_warning("inputs", "Feature", "AggregationFunction")
            if time_window is not None:
                emit_deprecation_warning(
                    "time_window", "Feature", "AggregationFunction with time_window"
                )
            if filter_condition is not None:
                emit_deprecation_warning(
                    "filter_condition",
                    "Feature",
                    "DeltaTableSource(filter_condition=...) or KafkaSource(filter_condition=...)",
                )
            if isinstance(function, Function):
                emit_deprecation_warning(
                    "function (legacy Function)", "Feature", "AggregationFunction"
                )

        # Validate required invariant regardless of deprecation warnings flag.
        if isinstance(function, AggregationFunction) and function.inputs is None:
            raise ValueError("If using AggregationFunction, it must contain its inputs")

        # ColumnSelection rejects aggregation-specific parameters
        if isinstance(function, ColumnSelection):
            if inputs is not None:
                raise ValueError(
                    "'inputs' cannot be used with ColumnSelection — "
                    "the column is specified inside ColumnSelection"
                )
            if time_window is not None:
                raise ValueError(
                    "'time_window' cannot be used with ColumnSelection — "
                    "ColumnSelection selects a column without a time window"
                )
            if filter_condition is not None:
                raise ValueError(
                    "'filter_condition' cannot be used with ColumnSelection — "
                    "ColumnSelection does not support filter conditions"
                )

        # RequestSource features must use a ColumnSelection function whose column
        # exists in the source schema. If a feature name is provided, it must
        # match the selected column name.
        if isinstance(source, RequestSource):
            if not isinstance(function, ColumnSelection):
                raise ValueError(
                    "RequestSource features must use a ColumnSelection function."
                )
            field_names = {f.name for f in source.schema}
            if function.column not in field_names:
                raise ValueError(
                    f"ColumnSelection column '{function.column}' does not exist in "
                    f"RequestSource schema. Available fields: {sorted(field_names)}"
                )
            if name is not None and name != function.column:
                raise ValueError(
                    f"For a RequestSource feature, the feature name must equal "
                    f"the ColumnSelection column name. Got feature name '{name}' "
                    f"but ColumnSelection column is '{function.column}'. "
                    f"Change the feature name to '{function.column}'."
                )

        # Handle name construction based on whether name is provided and qualified
        if name:
            if "." in name:
                if self._catalog_name is not None and self._schema_name is not None:
                    # If name is already qualified, validate it has the correct prefix and strip it
                    expected_prefix = f"{self._catalog_name}.{self._schema_name}."
                    if not name.startswith(expected_prefix):
                        raise ValueError(
                            f"Qualified name '{name}' must start with '{expected_prefix}'"
                        )
                    # Strip the catalog.schema prefix to get the base name
                    self._name = name[len(expected_prefix) :]
                else:
                    # Unregistered feature with qualified name: use last segment
                    self._name = name.rsplit(".", 1)[-1]
            else:
                # If name is unqualified, use it as is
                self._name = name
        else:
            # Generate base name
            self._name = self._generate_name(source, inputs, function, time_window)
        self._source = source
        self._entity = entity
        self._timeseries_column = timeseries_column
        self._order_column = DataSource.timeseries_to_order_column(timeseries_column)
        self._inputs = inputs
        self._function = function
        self._time_window = time_window
        self._description = description
        self._filter_condition = filter_condition

    @property
    def name(self) -> str:
        """The leaf name of the feature."""
        return self._name

    @property
    def full_name(self) -> str:
        """The fully qualified Unity Catalog name of the feature."""
        if not self.has_full_name:
            raise ValueError(
                "Feature does not have a catalog and schema. "
                "Provide catalog_name and schema_name, or call register_feature()."
            )
        return f"{self._catalog_name}.{self._schema_name}.{self._name}"

    @property
    def has_full_name(self) -> bool:
        """Whether this feature has catalog_name and schema_name set."""
        return self._catalog_name is not None and self._schema_name is not None

    @property
    def is_registered(self) -> bool:
        """Whether this feature is persisted to Unity Catalog."""
        return self._is_registered

    @property
    def catalog_name(self) -> Optional[str]:
        """The catalog name of the feature."""
        return self._catalog_name

    @property
    def schema_name(self) -> Optional[str]:
        """The schema name of the feature."""
        return self._schema_name

    @property
    def source(self) -> DataSource:
        """The data source for this feature."""
        return self._source

    @property
    def entity(self) -> Optional[List[str]]:
        """List of entity column names."""
        return self._entity

    @property
    def timeseries_column(self) -> Optional[str]:
        """The timeseries column name."""
        return self._timeseries_column

    @property
    def order_column(self) -> Optional[str]:
        """The order column name derived from timeseries_column."""
        return self._order_column

    # TODO[FS-871]: Remove _effective_entity_columns, _effective_timeseries_column, and
    # _effective_filter_condition when the legacy API is removed and
    # entity_columns/timeseries_column/filter_condition are always on Feature.
    @property
    def _effective_entity_columns(self) -> Optional[List[str]]:
        """Entity columns for this feature, resolving both API styles.

        Canonical API: set via Feature(entity=[...]) — returned directly.
        Legacy API: set via DeltaTableSource(entity_columns=[...]) — falls back to source.
        """
        return self._entity if self._entity is not None else self._source.entity_columns

    @property
    def _effective_timeseries_column(self) -> Optional[str]:
        """Timeseries column for this feature, resolving both API styles.

        Canonical API: set via Feature(timeseries_column=...) — returned directly.
        Legacy API: set via DeltaTableSource(timeseries_column=...) — falls back to source.
        """
        return (
            self._timeseries_column
            if self._timeseries_column is not None
            else self._source.timeseries_column
        )

    @property
    def _effective_filter_condition(self) -> Optional[str]:
        """Filter condition for this feature, resolving both API styles.

        Canonical API: set via DeltaTableSource(filter_condition=...) — falls back to source.
        Legacy API: set via Feature(filter_condition=...) — returned directly.
        """
        source_filter_condition = getattr(self._source, "filter_condition", None)
        if source_filter_condition is not None:
            return source_filter_condition
        return self._filter_condition

    @property
    def _effective_function(self) -> Function:
        """The aggregation Function operator, unwrapping AggregationFunction if needed.

        Canonical API: Feature.function is AggregationFunction — returns the inner Function.
        Legacy API: Feature.function is already a Function — returned directly.
        """
        if isinstance(self._function, AggregationFunction):
            return self._function.function
        return self._function

    @property
    def inputs(self) -> Optional[List[str]]:
        """Input columns for this feature.

        Canonical API: inputs live inside AggregationFunction — falls back to AggregationFunction.inputs.
        Legacy API: inputs are stored directly on Feature.
        """
        if self._inputs is not None:
            return self._inputs
        if isinstance(self._function, AggregationFunction):
            return self._function.inputs
        return None

    @property
    def function(self) -> Union[Function, AggregationFunction]:
        """The aggregation function to apply to the input columns."""
        return self._function

    @property
    def time_window(self) -> Optional[TimeWindow]:
        """Time window for this feature.

        Canonical API: time window lives inside AggregationFunction — falls back to AggregationFunction.time_window.
        Legacy API: time window is stored directly on Feature.
        """
        if self._time_window is not None:
            return self._time_window
        if isinstance(self._function, AggregationFunction):
            return self._function.time_window
        return None

    @property
    def description(self) -> Optional[str]:
        """Optional description of the feature."""
        return self._description

    @property
    def filter_condition(self) -> Optional[str]:
        """Optional SQL filter condition to apply on the source data before aggregation."""
        return self._filter_condition

    @staticmethod
    def _generate_name(
        source: DataSource,
        inputs: Optional[List[str]],
        function: Union[Function, AggregationFunction, ColumnSelection],
        time_window: Optional[TimeWindow],
    ) -> str:
        # ToDo: move this to backend as a part of CreateFeature API
        """Generate a feature name from the provided parameters."""
        if isinstance(function, ColumnSelection):
            return f"{function.column}_{COLUMN_SELECTION_TYPE}"
        # TODO[FS-871]: Remove Union[Function, AggregationFunction] and this isinstance check
        # when breaking backwards compatibility — accept only AggregationFunction.
        if isinstance(function, AggregationFunction):
            if function.inputs is None:
                raise ValueError(
                    "Cannot auto-generate a feature name: AggregationFunction has no inputs set. "
                    "Provide an explicit 'name'."
                )
            input_col = function.inputs[0]
            func_name = function.name
            return f"{input_col}_{func_name}_{str(function.time_window)}"
        if inputs is None:
            raise ValueError(
                "Cannot auto-generate a feature name: 'inputs' is not set. "
                "Provide an explicit 'name' or set 'inputs'."
            )
        return f"{inputs[0]}_{function.name}_{str(time_window)}"

    def computation_function(
        self, filter_condition: Optional[str] = None, output_alias: Optional[str] = None
    ) -> Column:
        # ColumnSelection: simple column reference, no aggregation or windowing.
        # Apply filter_condition as a WHERE predicate — rows not matching become NULL.
        if isinstance(self._function, ColumnSelection):
            col_ref = Function._escaped_col(self._function.column)
            if filter_condition:
                col_ref = F.when(F.expr(filter_condition), col_ref)
            return col_ref.alias(output_alias or self.name)
        # TODO[FS-871]: Remove Union[Function, AggregationFunction] and this isinstance check
        # when breaking backwards compatibility — accept only AggregationFunction.
        if isinstance(self._function, AggregationFunction):
            operation = self._function.function
            func = operation.spark_function_with_inputs(filter_condition)
            if self._effective_entity_columns is None:
                raise ValueError(
                    "entity columns must be set on the Feature or its DataSource when using a time window"
                )
            if self._effective_timeseries_column is None:
                raise ValueError(
                    "timeseries_column must be set on the Feature or its DataSource when using a time window"
                )
            effective_order_column = (
                self._order_column
                if self._order_column is not None
                else self._source.order_column
            )
            func = func.over(
                self._function.time_window.spark_window(
                    self._effective_entity_columns, effective_order_column
                )
            )
        else:
            func = self._function.spark_function(self._inputs, filter_condition)
            if self._time_window:
                func = func.over(
                    self._time_window.spark_window(
                        self._source.entity_columns, self._source.order_column
                    )
                )
        return func.alias(output_alias or self.name)

    def _to_yaml_dict(self) -> Dict[str, Any]:
        """Convert the feature to a dictionary that can be used to generate a YAML file."""
        if isinstance(self._function, ColumnSelection):
            yaml_dict = {
                self.DATA_SOURCE_FIELD_NAME: self.source.full_name(),
                self.FUNCTION_FIELD_NAME: self._function._to_yaml_dict(),
            }
            return yaml_dict
        # TODO[FS-871]: Remove the isinstance branch once Function is no longer supported.
        if isinstance(self._function, AggregationFunction):
            agg_dict = self._function._to_yaml_dict()
            yaml_dict = {
                self.INPUTS_FIELD_NAME: agg_dict["inputs"],
                self.DATA_SOURCE_FIELD_NAME: self.source.full_name(),
                self.FUNCTION_FIELD_NAME: agg_dict["function"],
                self.TIME_WINDOW_FIELD_NAME: agg_dict["time_window"],
            }
        else:
            yaml_dict = {
                self.INPUTS_FIELD_NAME: self.inputs,
                self.DATA_SOURCE_FIELD_NAME: self.source.full_name(),
                self.FUNCTION_FIELD_NAME: self.function._to_yaml_dict(),
                self.TIME_WINDOW_FIELD_NAME: self.time_window._to_yaml_dict(),
            }
        if self._filter_condition is not None:
            yaml_dict[self.FILTER_CONDITION_FIELD_NAME] = self._filter_condition
        return yaml_dict

    @staticmethod
    def _parse_yaml_feature_name(
        feature_name: str,
    ) -> tuple[Optional[str], Optional[str], str]:
        """Extract catalog, schema, and base name from a YAML feature name.

        Returns (catalog_name, schema_name, base_name).  Only 3-part qualified
        names populate catalog/schema; unqualified names leave them as None.
        """
        if "." not in feature_name:
            return None, None, feature_name
        parts = feature_name.split(".")
        if len(parts) == 3:
            return parts[0], parts[1], parts[2]
        raise ValueError(f"Invalid feature name format: {feature_name}")

    @classmethod
    def _from_yaml_dict(
        cls,
        feature_name: str,
        feature_dict: Dict[str, Any],
        data_source: DataSource,
    ) -> "Feature":
        """Create a Feature from a dictionary loaded from YAML."""
        func_dict = feature_dict[cls.FUNCTION_FIELD_NAME]
        catalog_name, schema_name, base_name = cls._parse_yaml_feature_name(
            feature_name
        )

        # Handle ColumnSelection type
        if func_dict.get("type") == COLUMN_SELECTION_TYPE:
            function = ColumnSelection._from_yaml_dict(func_dict["column"])
            with suppress_deprecation_warnings():
                return cls(
                    name=base_name,
                    catalog_name=catalog_name,
                    schema_name=schema_name,
                    source=data_source,
                    function=function,
                )

        function = Function._from_yaml_dict(
            func_dict["operator"], func_dict.get("extra_parameters")
        )
        time_window = TimeWindow._from_yaml_dict(
            feature_dict[cls.TIME_WINDOW_FIELD_NAME]
        )
        with suppress_deprecation_warnings():
            return cls(
                name=base_name,
                catalog_name=catalog_name,
                schema_name=schema_name,
                source=data_source,
                inputs=feature_dict[cls.INPUTS_FIELD_NAME],
                function=function,
                time_window=time_window,
                filter_condition=feature_dict.get(cls.FILTER_CONDITION_FIELD_NAME),
            )

    def _to_sdk_feature(self) -> SDKFeature:
        if not self.has_full_name:
            raise ValueError(
                "Feature does not have a catalog and schema. "
                "_to_sdk_feature can only be called during create_feature or register_feature "
                "where catalog and schema are known."
            )
        # SDKFeature.as_dict() skips None fields with falsy checks, so None values here
        # are safe and won't serialize nulls to the request body.
        sdk_feature = SDKFeature(
            full_name=self.full_name,
            source=self.source._to_sdk_data_source(),
            function=None,
            time_window=None,
            description=self._description,
            filter_condition=self._filter_condition,
        )
        if isinstance(self._function, (ColumnSelection, AggregationFunction)):
            # Shared entity/timeseries population for canonical function types
            if self._entity is not None:
                sdk_feature.entities = [
                    _make_sdk_entity_column(col) for col in self._entity
                ]
            if self._timeseries_column is not None:
                sdk_feature.timeseries_column = _make_sdk_timeseries_column(
                    self._timeseries_column
                )
            if isinstance(self._function, ColumnSelection):
                sdk_feature.function = self._function._to_sdk_function()
            else:
                sdk_agg_function = _typed_function_to_sdk_aggregation_function(
                    self._function
                )
                sdk_feature.function = SDKFunction(
                    aggregation_function=sdk_agg_function,
                )
        else:
            # TODO[FS-871]: Remove legacy path when breaking backwards compatibility.
            # Legacy path: send inputs, function, time_window
            if self._inputs is not None:
                sdk_feature.inputs = self._inputs
            if self._function is not None:
                sdk_feature.function = self._function._to_sdk_function()
            if self._time_window is not None:
                sdk_feature.time_window = self._time_window._to_sdk_time_window()
        return sdk_feature

    @classmethod
    def _from_sdk_feature(cls, sdk_feature: SDKFeature) -> "Feature":
        if not isinstance(sdk_feature, SDKFeature):
            raise TypeError(
                f"Expected databricks.sdk.service.ml.Feature, got {type(sdk_feature).__name__}"
            )
        if sdk_feature.full_name is None:
            raise ValueError("SDK Feature must include 'full_name'")
        catalog_name, schema_name, name = cls._parse_full_name(sdk_feature.full_name)
        # Parse shared fields
        source = cls._from_sdk_data_source(sdk_feature.source)
        description = sdk_feature.description
        filter_condition = getattr(sdk_feature, "filter_condition", None)
        inputs = list(sdk_feature.inputs) if sdk_feature.inputs else None
        # Read legacy fields (backend always dual-populates these)
        sdk_time_window = getattr(sdk_feature, "time_window", None)
        time_window = (
            cls._from_sdk_time_window(sdk_time_window)
            if sdk_time_window is not None
            else None
        )
        # Parse entity/timeseries (shared across ColumnSelection and AggregationFunction)
        sdk_entities = getattr(sdk_feature, "entities", None)
        entity = [e.name for e in sdk_entities] if sdk_entities is not None else None
        timeseries_column = (
            sdk_feature.timeseries_column.name
            if sdk_feature.timeseries_column is not None
            else None
        )
        # Check for canonical function fields on SDK response
        canonical_agg_function = (
            sdk_feature.function.aggregation_function
            if sdk_feature.function is not None
            else None
        )
        sdk_column_selection = (
            sdk_feature.function.column_selection
            if sdk_feature.function is not None
            else None
        )
        # Handle ColumnSelection
        if sdk_column_selection is not None:
            column_selection = ColumnSelection._from_sdk_column_selection(
                sdk_column_selection
            )
            with suppress_deprecation_warnings():
                feature = cls(
                    source=source,
                    entity=entity,
                    timeseries_column=timeseries_column,
                    function=column_selection,
                    catalog_name=catalog_name,
                    schema_name=schema_name,
                    name=name,
                    description=description,
                )
            feature._is_registered = True
            return feature
        # Handle AggregationFunction
        if canonical_agg_function is not None:
            aggregation_function = _sdk_aggregation_function_to_typed(
                canonical_agg_function
            )
            time_window = (
                cls._from_sdk_time_window(sdk_feature.time_window)
                if sdk_feature.time_window is not None
                else None
            )
            with suppress_deprecation_warnings():
                feature = cls(
                    source=source,
                    entity=entity,
                    timeseries_column=timeseries_column,
                    function=aggregation_function,
                    inputs=inputs,
                    time_window=time_window,
                    catalog_name=catalog_name,
                    schema_name=schema_name,
                    name=name,
                    description=description,
                    filter_condition=filter_condition,
                )
            feature._is_registered = True
            return feature
        # TODO[FS-871]: Remove legacy-only path when breaking backwards compatibility.
        # Legacy-only path
        if sdk_feature.function is None:
            raise ValueError("Legacy SDK feature must have a function field set")
        legacy_function = cls._from_sdk_function(sdk_feature.function)
        with suppress_deprecation_warnings():
            feature = cls(
                source=source,
                inputs=inputs,
                function=legacy_function,
                time_window=time_window,
                catalog_name=catalog_name,
                schema_name=schema_name,
                name=name,
                description=description,
                filter_condition=filter_condition,
            )
        feature._is_registered = True
        return feature

    @staticmethod
    def _parse_full_name(full_name: str) -> tuple[str, str, str]:
        parts = full_name.split(".")
        if len(parts) != 3:
            raise ValueError(
                f"Expected fully qualified feature name '<catalog>.<schema>.<name>', got '{full_name}'"
            )
        return parts[0], parts[1], parts[2]

    @staticmethod
    def _from_sdk_data_source(sdk_source: SDKDataSource) -> DataSource:
        return DataSource._from_sdk_data_source(sdk_source)

    @staticmethod
    def _from_sdk_function(sdk_function: SDKFunction) -> Function:
        return Function._from_sdk_function(sdk_function)

    @staticmethod
    def _from_sdk_time_window(sdk_time_window: SDKTimeWindow) -> TimeWindow:
        return TimeWindow._from_sdk_time_window(sdk_time_window)

    def __str__(self) -> str:
        """Return a concise string representation of the feature."""
        # TODO[FS-871]: Remove the isinstance branch once Function is no longer supported.
        filter_str = (
            f" [filter={self._filter_condition}]" if self._filter_condition else ""
        )
        if isinstance(self._function, ColumnSelection):
            return f"{self.name}: column_selection({self._function.column})"
        if isinstance(self._function, AggregationFunction):
            inputs_str = (
                ", ".join(self._function.inputs) if self._function.inputs else ""
            )
            return f"{self.name}: {self._function.name}({inputs_str}) OVER {self._function.time_window}{filter_str}"
        inputs_str = ", ".join(self._inputs) if self._inputs else ""
        return f"{self.name}: {self._function}({inputs_str}) OVER {self._time_window}{filter_str}"

    def __repr__(self) -> str:
        """Return a detailed string representation of the feature."""
        display_name = self.full_name if self.has_full_name else self.name
        return (
            f"Feature(name={display_name!r}, "
            f"source={self._source!r}, "
            f"inputs={self._inputs!r}, "
            f"function={self._function!r}, "
            f"time_window={self._time_window!r}, "
            f"filter_condition={self._filter_condition!r}, "
            f"entity={self._entity!r}, "
            f"timeseries_column={self._timeseries_column!r})"
        )
