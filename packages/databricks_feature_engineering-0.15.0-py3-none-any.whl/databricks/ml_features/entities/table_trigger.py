from databricks.ml_features.entities.trigger import Trigger
from databricks.ml_features_common.entities._feature_store_object import (
    _FeatureStoreObject,
)
from databricks.sdk.service.ml import MaterializedFeaturePipelineScheduleState


class TableTrigger(_FeatureStoreObject, Trigger):
    """
    Trigger feature materialization when the upstream Delta table receives a commit,
    rather than on a fixed schedule.

    Only supported for features that use :class:`ColumnSelection` over a
    :class:`DeltaTableSource`. Passing a :class:`TableTrigger` to
    :meth:`FeatureEngineeringClient.materialize_features` with any other feature
    shape (Kafka source, aggregation function, etc.) raises :class:`ValueError`.

    ``pipeline_schedule_state`` still gates whether the pipeline runs at all: a
    ``PAUSED`` state suppresses runs regardless of upstream commits.

    :param pipeline_schedule_state: Optional. Defaults to
        ``MaterializedFeaturePipelineScheduleState.ACTIVE``.

    .. seealso:: :class:`CronSchedule` for cron-based scheduling.
    """

    def __init__(
        self,
        *,
        pipeline_schedule_state: MaterializedFeaturePipelineScheduleState = (
            MaterializedFeaturePipelineScheduleState.ACTIVE
        ),
    ):
        super().__init__(pipeline_schedule_state=pipeline_schedule_state)
