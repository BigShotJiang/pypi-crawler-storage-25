from typing import Any, Dict, List, Optional

from databricks.ml_features.entities.function import (
    AGGREGATION_FUNCTION_BY_SHORTHAND,
    ApproxCountDistinct,
    ApproxPercentile,
    Avg,
    Count,
    First,
    Function,
    Last,
    Max,
    Min,
    PercentileApprox,
    StddevPop,
    StddevSamp,
    Sum,
    VarPop,
    VarSamp,
)
from databricks.ml_features.entities.time_window import TimeWindow


class AggregationFunction:
    """
    Combines a Function operator with input column(s) and a time window to aggregate data over a time window.

    The operator's input column names support struct field nesting via dot notation
    (e.g., ``Sum(input="value.amount")`` accesses the "amount" field in the "value" struct).
    Literal periods in column names are not supported.
    """

    def __init__(self, operator: Function, time_window: TimeWindow):
        if operator is None:
            raise ValueError("'operator' must not be None")
        if time_window is None:
            raise ValueError("'time_window' must not be None")
        self._operator = operator
        self._time_window = time_window

    @property
    def function(self) -> Function:
        """The aggregation function (operator)."""
        return self._operator

    # TODO[FS-871]: Make `inputs` non-Optional (required) when breaking backwards compatibility.
    @property
    def inputs(self) -> Optional[List[str]]:
        """
        Convenience accessor for the input columns of the Aggregation function. Currently inputs
        are optional for backwards compatibility reasons, but in a future release this will be required.
        """
        return self._operator.inputs

    @property
    def time_window(self) -> TimeWindow:
        return self._time_window

    @property
    def name(self) -> str:
        return self._operator.name

    def _to_yaml_dict(self) -> Dict[str, Any]:
        """Convert to the inputs/function/time_window structure used in Feature YAML."""
        result: Dict[str, Any] = {
            "function": self._operator._to_yaml_dict(),
            "time_window": self._time_window._to_yaml_dict(),
        }
        if self.inputs is not None:
            result["inputs"] = self.inputs
        return result

    def _to_sdk_function(self):
        """Convert the inner operator to an SDK Function."""
        return self._operator._to_sdk_function()

    def _to_sdk_time_window(self):
        """Convert the time window to an SDK TimeWindow."""
        return self._time_window._to_sdk_time_window()


# Re-export all classes and constants for backward compatibility
__all__ = [
    "AggregationFunction",
    "Function",
    "Avg",
    "Count",
    "ApproxCountDistinct",
    "ApproxPercentile",
    "PercentileApprox",
    "First",
    "Last",
    "Max",
    "Min",
    "StddevPop",
    "StddevSamp",
    "Sum",
    "VarPop",
    "VarSamp",
    "AGGREGATION_FUNCTION_BY_SHORTHAND",
]
