from typing import Any, Dict

from databricks.sdk.service.ml import ColumnSelection as SDKColumnSelection
from databricks.sdk.service.ml import Function as SDKFunction

#: Shared constant for the column_selection function type name.
COLUMN_SELECTION_TYPE = "column_selection"


class ColumnSelection:
    """
    Selects a column from the data source for the specified entity. Where there are
    multiple rows for the same entity over time, ColumnSelection uses the latest row's
    column value as of the provided timestamp in a training context or now in an inference
    context.

    Equivalent to LAST() for a single column from a data source for the
    specified entity over the data source's implicit lifetime window.

    :param column: The column name to select from the data source. Must be a non-empty string.
    """

    def __init__(self, column: str):
        if not isinstance(column, str) or not column.strip():
            raise ValueError("'column' must be a non-empty string")
        self._column = column.strip()

    @property
    def column(self) -> str:
        """The column name to select."""
        return self._column

    @property
    def name(self) -> str:
        """Return the name of this function type, i.e. "column_selection"."""
        return COLUMN_SELECTION_TYPE

    def _to_yaml_dict(self) -> Dict[str, Any]:
        """Convert to a dictionary for YAML serialization."""
        return {"type": COLUMN_SELECTION_TYPE, "column": self._column}

    def _to_sdk_function(self) -> SDKFunction:
        """Convert to an SDK Function with column_selection field."""
        return SDKFunction(column_selection=SDKColumnSelection(column=self._column))

    @classmethod
    def _from_yaml_dict(cls, column: str) -> "ColumnSelection":
        """Create a ColumnSelection from a YAML dictionary column value."""
        return cls(column=column)

    @classmethod
    def _from_sdk_column_selection(cls, sdk_column_selection) -> "ColumnSelection":
        """Create a ColumnSelection from an SDK ColumnSelection object."""
        return cls(column=sdk_column_selection.column)

    def __str__(self) -> str:
        return f"column_selection({self._column})"

    def __repr__(self) -> str:
        return f"ColumnSelection(column={self._column!r})"

    def __eq__(self, other) -> bool:
        if not isinstance(other, ColumnSelection):
            return NotImplemented
        return self._column == other._column

    def __hash__(self) -> int:
        return hash(("ColumnSelection", self._column))
