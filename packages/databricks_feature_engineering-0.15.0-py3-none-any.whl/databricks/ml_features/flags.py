ENABLE_EXPERIMENTAL_MATERIALIZATION_API = False

# TODO[FS-871]: Remove this flag once the declarative feature API migration is complete.
# When True, deprecation warnings are shown for legacy API patterns that are being
# replaced by the declarative feature API (e.g., entity_columns on DataSource).
ENABLE_DECLARATIVE_FEATURE_API_DEPRECATION_WARNINGS = True

# Feature flag to enable optimized aggregation query generation
# When True, generates a single CTE with conditional aggregations (1 table scan)
# When False, generates N separate CTEs with N table scans (legacy behavior)
ENABLE_OPTIMIZED_FEATURE_AGGREGATION_PIPELINES = False
