from typing import List, Optional, Sequence, Union

from pyspark.sql import DataFrame
from pyspark.sql.types import DateType, TimestampNTZType, TimestampType

from databricks.ml_features._spark_client._spark_client import SparkClient
from databricks.ml_features.entities.feature import Feature
from databricks.ml_features.entities.feature_function import FeatureFunction
from databricks.ml_features.entities.feature_lookup import FeatureLookup
from databricks.ml_features.utils.feature_lookup_utils import (
    get_feature_lookups_with_full_table_names,
)
from databricks.ml_features.utils.on_demand_utils import (
    get_feature_functions_with_full_udf_names,
)

# Temporal types not permitted as Declarative Feature entity (lookup key) columns.
_BLOCKED_ENTITY_COLUMN_TYPES = (DateType, TimestampType, TimestampNTZType)
_BLOCKED_ENTITY_COLUMN_TYPE_LABELS = {
    DateType: "DATE",
    TimestampType: "TIMESTAMP",
    TimestampNTZType: "TIMESTAMP_NTZ",
}


def validate_feature_spec_declarative_feature_constraints(
    features: List[Union[FeatureLookup, FeatureFunction, Feature]],
    exclude_columns: Optional[List[str]] = None,
):
    """Validate declarative Feature constraints: no mixing with traditional features, no exclude_columns."""
    has_declarative = any(isinstance(f, Feature) for f in features)
    has_traditional = any(
        isinstance(f, (FeatureLookup, FeatureFunction)) for f in features
    )

    if has_declarative and has_traditional:
        raise ValueError(
            "Declarative Feature objects cannot be mixed with FeatureLookup or FeatureFunction objects."
        )

    if has_declarative and exclude_columns:
        raise ValueError(
            "exclude_columns is not supported with declarative Feature objects."
        )

    return has_declarative


def format_feature_lookups_and_functions(
    _spark_client: SparkClient,
    features: List[Union[FeatureLookup, FeatureFunction, Feature]],
):
    fl_idx = []
    ff_idx = []
    feature_lookups = []
    feature_functions = []
    for idx, feature in enumerate(features):
        if isinstance(feature, FeatureLookup):
            fl_idx.append(idx)
            feature_lookups.append(feature)
        elif isinstance(feature, FeatureFunction):
            ff_idx.append(idx)
            feature_functions.append(feature)
        elif isinstance(feature, Feature):
            # Feature objects (declarative features) are passed through unchanged —
            # they use fully qualified UC names already and don't need resolution.
            pass
        else:
            raise ValueError(
                f"Expected a list of FeatureLookups for 'feature_lookups', but received type '{type(feature)}'."
            )

    # FeatureLookups and FeatureFunctions must have fully qualified table, UDF names
    feature_lookups = get_feature_lookups_with_full_table_names(
        feature_lookups,
        _spark_client.get_current_catalog(),
        _spark_client.get_current_database(),
    )
    feature_functions = get_feature_functions_with_full_udf_names(
        feature_functions,
        _spark_client.get_current_catalog(),
        _spark_client.get_current_database(),
    )

    # Restore original order of FeatureLookups, FeatureFunctions. Copy to avoid mutating original list.
    features = features.copy()
    for idx, feature in zip(fl_idx + ff_idx, feature_lookups + feature_functions):
        features[idx] = feature

    return features


def validate_entity_columns_not_temporal(
    entity_columns: Sequence[str], dataframe: DataFrame
) -> None:
    """Raise ValueError if any entity column has a temporal type.

    Checks the DataFrame schema for columns in _BLOCKED_ENTITY_COLUMN_TYPES
    and reports all violations in a single error.

    :param entity_columns: entity column names to validate
    :param dataframe: Spark DataFrame whose schema is used for type lookup
    """
    schema_field_map = {field.name: field.dataType for field in dataframe.schema.fields}
    violations = []
    for col_name in entity_columns:
        col_type = schema_field_map.get(col_name)
        if col_type is not None and isinstance(col_type, _BLOCKED_ENTITY_COLUMN_TYPES):
            type_label = _BLOCKED_ENTITY_COLUMN_TYPE_LABELS[type(col_type)]
            violations.append(f"'{col_name}' ({type_label})")
    if violations:
        raise ValueError(
            f"Entity column(s) {', '.join(violations)} have unsupported temporal types. "
            f"Entity columns are lookup keys and must be non-temporal identifiers "
            f"(e.g., STRING, LONG, INT). Use 'timeseries_column' for time-based columns. "
            f"To use a temporal value as an entity, floor it to a consistent window "
            f"(e.g., daily or hourly) and encode as STRING or LONG."
        )
