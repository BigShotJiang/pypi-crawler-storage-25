import contextlib
import threading
import warnings

# Thread-local storage for the suppression flag. Each thread gets its own
# independent `suppressed` attribute, so concurrent deserialization calls
# cannot interfere with each other. This avoids the thread-safety issue
# with warnings.catch_warnings(), which mutates the process-wide filter state.
_state = threading.local()


@contextlib.contextmanager
def suppress_deprecation_warnings():
    """Suppress deprecation warnings emitted by ``emit_deprecation_warning``.

    Use this in internal factory methods (_from_yaml_dict, _from_sdk_data_source,
    etc.) so that deprecation warnings only fire when users construct objects
    directly, not during internal deserialization.

    Thread-safe: uses ``threading.local()`` rather than the global warning
    filters, so concurrent threads can independently suppress or emit warnings.
    """
    previous = getattr(_state, "suppressed", False)
    _state.suppressed = True
    try:
        yield
    finally:
        _state.suppressed = previous


def emit_class_deprecation_warning(class_name: str, replacement: str):
    """Emit a standardized deprecation warning for a renamed or removed class.

    No-ops when called inside a ``suppress_deprecation_warnings()`` context
    (checked via the thread-local ``_state.suppressed`` flag).

    :param class_name: Name of the deprecated class (e.g., 'ContinuousWindow')
    :param replacement: Name of the replacement class (e.g., 'RollingWindow')
    """
    if getattr(_state, "suppressed", False):
        return
    warnings.warn(
        f"'{class_name}' is deprecated. Use '{replacement}' instead.",
        DeprecationWarning,
        stacklevel=3,
    )


def emit_deprecation_warning(parameter_name: str, class_name: str, replacement: str):
    """Emit a standardized deprecation warning for a legacy API parameter.

    No-ops when called inside a ``suppress_deprecation_warnings()`` context
    (checked via the thread-local ``_state.suppressed`` flag).

    :param parameter_name: Name of the deprecated parameter (e.g., 'entity_columns')
    :param class_name: Name of the class the parameter belongs to (e.g., 'DeltaTableSource')
    :param replacement: Description of the replacement (e.g., 'Feature(entity=...)')
    """
    if getattr(_state, "suppressed", False):
        return
    warnings.warn(
        f"Passing '{parameter_name}' to {class_name} is deprecated. "
        f"Use {replacement} instead.",
        DeprecationWarning,
        stacklevel=3,
    )
