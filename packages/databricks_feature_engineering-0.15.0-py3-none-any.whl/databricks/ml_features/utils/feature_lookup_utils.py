import copy
import datetime
import logging
import re
from collections import defaultdict
from functools import reduce
from typing import Dict, List, Optional, Tuple

from pyspark.sql import DataFrame, Window
from pyspark.sql import functions as F
from pyspark.sql.functions import sum, unix_timestamp

from databricks.ml_features._spark_client._spark_client import SparkClient
from databricks.ml_features.constants import _MAX_HINT_LOW_CARDINALITY_COUNT
from databricks.ml_features.entities.data_source import DataSource
from databricks.ml_features.entities.data_type import DataType
from databricks.ml_features.entities.feature_lookup import FeatureLookup
from databricks.ml_features.entities.feature_table import FeatureTable
from databricks.ml_features.environment_variables import BROADCAST_JOIN_THRESHOLD
from databricks.ml_features_common.entities.feature_column_info import FeatureColumnInfo
from databricks.ml_features_common.entities.feature_spec import FeatureSpec
from databricks.ml_features_common.utils import uc_utils

_logger = logging.getLogger(__name__)


def _spark_asof_join_features(
    df: DataFrame,
    df_lookup_keys: List[str],
    df_timestamp_lookup_key: str,
    feature_table_data: DataFrame,
    feature_table_keys: List[str],
    feature_table_timestamp_key: str,
    feature_to_output_name: Dict[str, str],
    lookback_window_seconds: Optional[float] = None,
    use_spark_native_join: Optional[bool] = False,
) -> DataFrame:
    """
    Performs a point-in-time (as-of) join between a training DataFrame and a feature table.

    For each row in ``df``, finds the latest row in ``feature_table_data`` whose entity keys
    match and whose timestamp is <= the training row's timestamp, preventing future data
    leakage. An optional lookback window limits how far back in time to search.

    Two implementations are available:

    - **Tempo** (default): Uses the Tempo library's ``TSDF.asofJoin``, which partitions by
      entity keys and performs a time-aware merge within each partition. See
      https://databrickslabs.github.io/tempo/references/tsdf.html#tempo.tsdf.TSDF.asofJoin
    - **Native Spark** (``use_spark_native_join=True``): Uses broadcast joins and window
      aggregations for environments where Tempo is unavailable or when the labels DataFrame
      is much smaller than the features DataFrame.

    Both approaches fold the ``source_ts <= train_ts`` condition into the join itself rather
    than applying it as a post-join filter, keeping the intermediate result set small.

    :param df: Training DataFrame with entity key and timestamp columns.
    :param df_lookup_keys: Entity key column names in ``df``.
    :param df_timestamp_lookup_key: Timestamp column name in ``df``.
    :param feature_table_data: Feature source DataFrame.
    :param feature_table_keys: Entity key column names in the feature table.
    :param feature_table_timestamp_key: Timestamp column name in the feature table.
    :param feature_to_output_name: Mapping from feature table column names to output names.
    :param lookback_window_seconds: Max age (in seconds) of a feature row relative to the
        training timestamp. ``None`` means no limit.
    :param use_spark_native_join: If True, use native Spark join instead of Tempo.
    :return: ``df`` augmented with the requested feature columns.
    """
    # Helper to handle column references with dots (nested fields)
    def _col_ref(col_name):
        # Use backticks with F.col() for nested field names containing dots
        if "." in col_name:
            return F.col(f"`{col_name}`")
        # Use direct reference for regular column names
        return feature_table_data[col_name]

    # Alias feature table's keys to DataFrame lookup keys
    ft_key_aliases = [
        _col_ref(ft_key).alias(df_key)
        for (ft_key, df_key) in zip(feature_table_keys, df_lookup_keys)
    ]
    # Alias features to corresponding output names
    ft_features = [
        (feature_name, output_name)
        for feature_name, output_name in feature_to_output_name.items()
        # Skip join if feature it is already in DataFrame and therefore overridden
        if output_name not in df.columns
    ]
    ft_feature_aliases = [
        _col_ref(feature_name).alias(output_name)
        for feature_name, output_name in ft_features
    ]
    # Alias feature table's timestamp key to DataFrame timestamp lookup keys
    ft_timestamp_key_aliases = [
        _col_ref(feature_table_timestamp_key).alias(df_timestamp_lookup_key)
    ]
    # Select key, timestamp key, and feature columns from feature table
    feature_and_keys = feature_table_data.select(
        ft_key_aliases + ft_timestamp_key_aliases + ft_feature_aliases
    )

    _logger.debug(
        "Using native spark for point in time join"
        if use_spark_native_join
        else "Using tempo for point in time join"
    )

    if use_spark_native_join:
        joined_df = _spark_asof_join_features_native(
            labels_df=df,
            features_df=feature_and_keys,
            primary_keys=df_lookup_keys,
            timestamp_key=df_timestamp_lookup_key,
            lookback_window_seconds=lookback_window_seconds,
        )
    else:
        joined_df = _spark_asof_join_features_tempo(
            df=df,
            df_lookup_keys=df_lookup_keys,
            df_timestamp_lookup_key=df_timestamp_lookup_key,
            feature_and_keys=feature_and_keys,
            ft_features=ft_features,
            lookback_window_seconds=lookback_window_seconds,
        )
    return joined_df


def _spark_asof_join_features_tempo(
    df: DataFrame,
    df_lookup_keys: List[str],
    df_timestamp_lookup_key: str,
    feature_and_keys: DataFrame,
    ft_features: List[Tuple[str, str]],
    lookback_window_seconds: Optional[float] = None,
) -> DataFrame:
    # [ML-19825] Import TSDF only at as-of join time to avoid DynamoDB publish issue
    from tempo.tsdf import TSDF

    # Convert DATE columns to TIMESTAMP for tempo compatibility
    # Tempo internally casts timestamps to numeric types for temporal arithmetic,
    # but Spark does not support CAST(DATE AS DOUBLE). Convert to TIMESTAMP first.
    df_ts_type = df.schema[df_timestamp_lookup_key].dataType.typeName()
    if df_ts_type == "date":
        df = df.withColumn(
            df_timestamp_lookup_key, F.col(df_timestamp_lookup_key).cast("timestamp")
        )

    ft_ts_type = feature_and_keys.schema[df_timestamp_lookup_key].dataType.typeName()
    if ft_ts_type == "date":
        feature_and_keys = feature_and_keys.withColumn(
            df_timestamp_lookup_key, F.col(df_timestamp_lookup_key).cast("timestamp")
        )

    # Initialize Tempo TSDFs for df and feature table.
    # Feature table timestamp keys and primary keys are aliased to
    # DataFrame's timestamp lookup keys and lookup keys respectively
    # because ts_col and partition_cols must match.
    df_tsdf = TSDF(df, ts_col=df_timestamp_lookup_key, partition_cols=df_lookup_keys)
    ft_tsdf = TSDF(
        feature_and_keys,
        ts_col=df_timestamp_lookup_key,
        partition_cols=df_lookup_keys,
    )
    # Perform as-of join
    joined_df = df_tsdf.asofJoin(
        ft_tsdf,
        left_prefix="left",
        right_prefix="right",
        skipNulls=False,
        tolerance=lookback_window_seconds
        if lookback_window_seconds is not None
        else None,
    ).df
    # Remove prefixes from joined df to restore column names
    left_aliases = [
        joined_df[f"left_{column_name}"].alias(column_name)
        for column_name in df.columns
        if column_name not in df_lookup_keys
    ]
    right_aliases = [
        joined_df[f"right_{output_name}"].alias(output_name)
        for (_, output_name) in ft_features
    ]
    return joined_df.select(df_lookup_keys + left_aliases + right_aliases)


def _spark_asof_join_features_native(
    labels_df: DataFrame,
    features_df: DataFrame,
    primary_keys: List[str],
    timestamp_key: str,
    lookback_window_seconds: Optional[float] = None,
):
    """
    Performs an as-of join operation between two dataframes using native Spark operations.
    Uses broadcast join for label dataset when within a size threshold to improve
    efficiency of join operation with the assumption that size(labels_df) << size(features_df).
    TODO(ML-40580): automatically switch labels_df and features_df based on size
    The join operation is performed as follows:
        1. Drop non-join key (primary and timestamp keys) columns from labels and features DataFrames
        2. Broadcast join labels onto features DataFrame if within broadcast threshold.
        3. Select maximum timestamp for each primary key
        4. Rejoin non-primary key columns from features DataFrame to get features data
        5. Rejoin non-primary key columns from labels DataFrame to get joint data

    Parameters:
    labels_df (DataFrame): The labels dataframe to join.
    features_df (DataFrame): The features dataframe to join.
    primary_keys (List[str]): The primary keys used for joining.
    timestamp_key (str): The timestamp key used for joining.
    lookback_window_seconds (Optional[float]): The lookback window in seconds.
        If provided, the join operation will only consider records within this window.

    Returns:
    DataFrame: The result of the as-of join operation.
    """
    labels_df_keys_only = labels_df.select(
        [F.col(key) for key in primary_keys] + [F.col(timestamp_key)]
    )

    # Broadcast labels DataFrame if within the broadcast threshold
    if _df_in_size_threshold(labels_df_keys_only, BROADCAST_JOIN_THRESHOLD.get()):
        labels_df_keys_only = F.broadcast(labels_df_keys_only)

    # Drop non-primary key columns from features DataFrame
    features_df_keys_only = features_df.select(
        [F.col(key).alias(f"__features_pk_{key}") for key in primary_keys]
        + [F.col(timestamp_key).alias("__features_tk")]
    )

    # Create join conditions
    join_conditions = [
        labels_df_keys_only[key] == features_df_keys_only[f"__features_pk_{key}"]
        for key in primary_keys
    ]
    join_conditions = reduce(lambda x, y: x & y, join_conditions)
    join_conditions &= (
        labels_df_keys_only[timestamp_key] >= features_df_keys_only["__features_tk"]
    )
    if lookback_window_seconds is not None:
        join_conditions &= (
            unix_timestamp(labels_df_keys_only[timestamp_key])
            - unix_timestamp(features_df_keys_only["__features_tk"])
        ) <= lookback_window_seconds

    # Join labels and features DataFrames
    labels_df_keys_with_features_keys = labels_df_keys_only.join(
        features_df_keys_only, on=join_conditions, how="left"
    )

    # Find the features max timestamps for each primary keys and timestamp key in labels
    labels_df_keys_with_features_keys = labels_df_keys_with_features_keys.groupBy(
        [labels_df_keys_only[key] for key in primary_keys] + [F.col(timestamp_key)]
    ).agg(F.max("__features_tk").alias("__max_ts"))

    if _df_in_size_threshold(
        labels_df_keys_with_features_keys, BROADCAST_JOIN_THRESHOLD.get()
    ):
        labels_df_keys_with_features_keys = F.broadcast(
            labels_df_keys_with_features_keys
        )

    # Rejoin features DataFrame to get the features data
    join_conditions = [
        features_df[key] == labels_df_keys_with_features_keys[key]
        for key in primary_keys
    ]
    join_conditions = reduce(lambda x, y: x & y, join_conditions)
    join_conditions &= (
        features_df[timestamp_key] == labels_df_keys_with_features_keys["__max_ts"]
    )

    features = features_df.join(
        labels_df_keys_with_features_keys,
        on=join_conditions,
        how="inner",
    )

    pk_columns_to_drop = [
        labels_df_keys_with_features_keys[key] for key in primary_keys
    ]
    features = features.drop(*pk_columns_to_drop).drop(
        features_df[timestamp_key], labels_df_keys_with_features_keys["__max_ts"]
    )
    features = features.dropDuplicates(primary_keys + [timestamp_key])
    # Rejoin labels DataFrame if columns were dropped
    joint_df = labels_df.join(features, on=primary_keys + [timestamp_key], how="left")
    return joint_df


def _df_in_size_threshold(df, threshold) -> float:
    # Default to within threshold if can not find
    try:
        num_bytes = _get_df_size_from_spark_plan(df)
    except Exception as e:
        num_bytes = 0
    return num_bytes <= threshold


def _get_df_size_from_spark_plan(df: DataFrame) -> float:
    spark_client = SparkClient()
    spark = spark_client._spark
    df.createOrReplaceTempView("view")

    plan = spark.sql("explain cost select * from view").collect()[0][0]
    search_result = re.search(r"sizeInBytes=.*(['\)])", plan, re.MULTILINE)
    if search_result is not None:
        result = search_result.group(0).replace(")", "")
    else:
        raise ValueError("Unable to obtain sizeInBytes from Spark plan")

    units_map = {"TiB": 1024**4, "GiB": 1024**3, "MiB": 1024**2, "KiB": 1024}
    size, units = result.split("=")[1].split()
    return float(size) * units_map.get(units.rstrip(","), 1)


def _spark_join_features(
    df: DataFrame,
    df_keys: List[str],
    feature_table_data: DataFrame,
    feature_table_keys: List[str],
    feature_to_output_name: Dict[str, str],
) -> DataFrame:
    """
    Helper to join `feature_name` from `feature_table_data` into `df`.

    This join uses a temporary table that contains only the keys and feature
    from the feature table. The temporary table aliases the keys to match
    the lookup keys and the feature to match the output_name.

    Aliasing the keys allows us to join on name instead of by column,
    which prevents duplicate column names after the join.
    (see: https://kb.databricks.com/data/join-two-dataframes-duplicated-columns.html)

    The joined-in feature is guaranteed to be unique because FeatureSpec
    columns must be unique and the join is skipped if the feature
    already exists in the DataFrame.
    """

    # Helper to handle column references with dots (nested fields)
    def _col_ref(col_name):
        # Use backticks with F.col() for nested field names containing dots
        if "." in col_name:
            return F.col(f"`{col_name}`")
        # Use direct reference for regular column names
        return feature_table_data[col_name]

    # Alias feature table's keys to DataFrame lookup keys
    ft_key_aliases = [
        _col_ref(ft_key).alias(df_key)
        for (ft_key, df_key) in zip(feature_table_keys, df_keys)
    ]
    # Alias features to corresponding output names
    ft_feature_aliases = [
        _col_ref(feature_name).alias(output_name)
        for feature_name, output_name in feature_to_output_name.items()
        # Skip join if feature it is already in DataFrame and therefore overridden
        if output_name not in df.columns
    ]
    # Select key and feature columns from feature table
    feature_and_keys = feature_table_data.select(ft_key_aliases + ft_feature_aliases)
    # Join feature to feature table
    return df.join(feature_and_keys, df_keys, how="left")


def _validate_join_keys(
    feature_column_info: FeatureColumnInfo,
    df: DataFrame,
    feature_table_metadata: FeatureTable,
    feature_table_data: DataFrame,
    is_timestamp_key: bool = False,
):
    join_error_phrase = (
        f"Unable to join feature table '{feature_column_info.table_name}'"
    )
    feature_column_info_keys = (
        feature_column_info.timestamp_lookup_key
        if is_timestamp_key
        else feature_column_info.lookup_key
    )
    feature_table_keys = (
        feature_table_metadata.timestamp_keys
        if is_timestamp_key
        else feature_table_metadata.primary_keys
    )

    lookup_key_kind = "timestamp lookup key" if is_timestamp_key else "lookup key"
    feature_table_key_kind = "timestamp key" if is_timestamp_key else "primary key"

    # Validate df has necessary keys
    missing_df_keys = list(
        filter(lambda df_key: df_key not in df.columns, feature_column_info_keys)
    )
    if missing_df_keys:
        missing_keys = ", ".join([f"'{key}'" for key in missing_df_keys])
        raise ValueError(
            f"{join_error_phrase} because {lookup_key_kind} {missing_keys} not found in DataFrame."
        )
    # Validate feature table has necessary keys
    missing_ft_keys = list(
        filter(
            lambda ft_key: ft_key not in feature_table_data.columns, feature_table_keys
        )
    )
    if missing_ft_keys:
        missing_keys = ", ".join([f"'{key}'" for key in missing_ft_keys])
        raise ValueError(
            f"{join_error_phrase} because {feature_table_key_kind} {missing_keys} not found in feature table."
        )

    # Validate number of feature table keys matches number of df lookup keys
    if len(feature_column_info_keys) != len(feature_table_keys):
        raise ValueError(
            f"{join_error_phrase} because "
            f"number of {feature_table_key_kind}s ({feature_table_keys}) "
            f"does not match "
            f"number of {lookup_key_kind}s ({feature_column_info_keys})."
        )

    # Validate feature table keys match types of df keys. The number of keys is expected to be the same.
    for (df_key, ft_key) in zip(feature_column_info_keys, feature_table_keys):
        df_key_type = DataType.from_spark_type(df.schema[df_key].dataType)
        ft_key_type = DataType.from_spark_type(
            feature_table_data.schema[ft_key].dataType
        )
        if df_key_type != ft_key_type:
            raise ValueError(
                f"{join_error_phrase} because {feature_table_key_kind} '{ft_key}' has type '{DataType.to_string(ft_key_type)}' "
                f"but corresponding {lookup_key_kind} '{df_key}' has type '{DataType.to_string(df_key_type)}' in DataFrame."
            )


def _validate_join_feature_data(
    df: DataFrame,
    features_to_join: List[FeatureColumnInfo],
    feature_table_metadata_map: Dict[str, FeatureTable],
    feature_table_data_map: Dict[str, DataFrame],
):
    for feature_info in features_to_join:
        feature_table_metadata = feature_table_metadata_map[feature_info.table_name]
        feature_table_data = feature_table_data_map[feature_info.table_name]
        # Validate feature table primary keys match length/type of df lookup keys
        _validate_join_keys(
            feature_info,
            df,
            feature_table_metadata,
            feature_table_data,
            is_timestamp_key=False,
        )
        # Validate feature table timestamp keys match length/type of df timestamp lookup keys
        _validate_join_keys(
            feature_info,
            df,
            feature_table_metadata,
            feature_table_data,
            is_timestamp_key=True,
        )


def _apply_timeseries_filter(
    feature_table_data: DataFrame,
    training_df: DataFrame,
    feature_timestamp_key: str,
    training_timestamp_key: str,
    lookback_window_seconds: Optional[float] = None,
) -> DataFrame:
    """
    Filter feature table to relevant timestamp range based on training data.

    This enables partition pruning on timeseries feature tables, dramatically
    reducing data scan when training data covers a narrow time range.

    Filtering logic:
    - Without lookback_window: feature.ts <= max(training.ts)
    - With lookback_window: min(training.ts) - lookback_window <= feature.ts <= max(training.ts)

    Example (without lookback_window):
    - Training data: single date (2024-06-15)
    - Feature table: 365 days (2024-01-01 to 2024-12-31)
    - Without filter: Scans all 365 days (full table scan)
    - With filter: Scans only up to 2024-06-15 (~165 days, 45% of table)

    Example (with lookback_window):
    - Training data: March 1-15, 2024 (15 days)
    - Lookback window: 30 days
    - Feature table: 365 days
    - Filter: (March 1 - 30 days) <= feature.ts <= March 15
    - Scans: Feb 1 to March 15 (~45 days, 12% of table instead of ~75 days)

    Args:
        feature_table_data: Feature table DataFrame (unfiltered)
        training_df: Training DataFrame with timestamp column
        feature_timestamp_key: Timestamp column name in feature table
        training_timestamp_key: Timestamp column name in training data
        lookback_window_seconds: Optional lookback window in seconds

    Returns:
        Filtered feature table DataFrame
    """
    # Compute min and max timestamps from training data
    # Use single-row aggregation to avoid materializing full training set
    agg_result = training_df.agg(
        F.min(training_timestamp_key).alias("min_ts"),
        F.max(training_timestamp_key).alias("max_ts"),
    ).collect()[0]

    min_training_ts = agg_result["min_ts"]
    max_training_ts = agg_result["max_ts"]

    if max_training_ts is None:
        # If training data has no timestamp values, skip filtering
        _logger.warning(
            "Training data has no timestamp values, skipping timeseries filtering"
        )
        return feature_table_data

    # Build filter condition
    filter_condition = F.col(feature_timestamp_key) <= F.lit(max_training_ts)

    # If lookback_window is specified, add lower bound filter
    if lookback_window_seconds is not None and min_training_ts is not None:
        # Convert min_training_ts to Unix timestamp, subtract lookback window, convert back
        min_bound_ts = F.from_unixtime(
            unix_timestamp(F.lit(min_training_ts)) - lookback_window_seconds
        )
        filter_condition = (
            F.col(feature_timestamp_key) >= min_bound_ts
        ) & filter_condition

        _logger.info(
            f"Applied timeseries filter with lookback window: "
            f"{min_bound_ts} <= {feature_timestamp_key} <= {max_training_ts} "
            f"(lookback_window={lookback_window_seconds}s)"
        )
    else:
        _logger.info(
            f"Applied timeseries filter: {feature_timestamp_key} <= {max_training_ts}"
        )

    filtered_df = feature_table_data.filter(filter_condition)

    return filtered_df


def _get_layout_optimization_columns(
    table_name: str,
    feature_table_metadata,
) -> List[str]:
    """
    Returns the columns that drive the table's physical layout.
    Check for partition columns first, then liquid clustering columns, then z-order columns.

    Returns [] if no layout optimization is detected.
    """
    if feature_table_metadata.partition_columns:
        return list(feature_table_metadata.partition_columns)

    optimize_columns = SparkClient().get_optimize_columns_for_delta_table(table_name)
    liquid_cols = optimize_columns.get("clusteringColumns", [])
    if liquid_cols:
        return list(liquid_cols)

    zorder_cols = optimize_columns.get("zOrderBy", [])
    if zorder_cols:
        return list(zorder_cols)

    return []


def _apply_pk_cardinality_filter(
    feature_table_data: DataFrame,
    training_df: DataFrame,
    table_name: str,
    feature_table_metadata,
) -> DataFrame:
    """
    Pre-filter feature_table_data to rows matching training_df's distinct layout-optimization-
    column combinations, enabling Spark to prune partitions/files before the PK join.

    Determines which columns to hint on from the table's physical layout (partition, liquid
    clustering, or z-order). If the full set of layout optimization columns exceeds
    _MAX_HINT_LOW_CARDINALITY_COUNT distinct values in training_df, trailing columns are dropped
    one at a time until cardinality fits. Returns feature_table_data unchanged if no layout
    optimization is detected or if cardinality exceeds the threshold for every prefix.
    """
    layout_cols = _get_layout_optimization_columns(table_name, feature_table_metadata)
    if not layout_cols:
        _logger.info(
            "hint_low_cardinality_columns optimization not applied for table '%s'",
            table_name,
        )
        return feature_table_data

    # Only hint on layout columns that are also primary keys — non-PK layout columns
    # (e.g. a partition column that isn't a lookup key) can't be used to filter feature
    # table rows that will be joined on PKs, so including them would be incorrect.
    pk_set = set(feature_table_metadata.primary_keys)
    layout_cols = [c for c in layout_cols if c in pk_set]

    # Only hint on columns that actually exist in training_df — layout columns that were
    # added after the training data was written wouldn't be selectable, and referencing a
    # missing column would raise an AnalysisException at runtime.
    training_col_set = set(training_df.columns)
    layout_cols = [c for c in layout_cols if c in training_col_set]

    if not layout_cols:
        _logger.info(
            "hint_low_cardinality_columns optimization not applied for table '%s': "
            "no layout columns overlap with primary keys and training_df columns",
            table_name,
        )
        return feature_table_data

    cols = list(layout_cols)
    while cols:
        # Use limit(threshold+1).collect() instead of distinct().count() + collect().
        # This lets Spark stop scanning as soon as threshold+1 distinct values are found,
        # making the cardinality check O(distinct values found) rather than O(training_size).
        collected = (
            training_df.select(cols)
            .distinct()
            .limit(_MAX_HINT_LOW_CARDINALITY_COUNT + 1)
            .collect()
        )
        if len(collected) <= _MAX_HINT_LOW_CARDINALITY_COUNT:
            # Build isin() filter predicates from the already-collected values.
            # isin() produces InSet predicates in Spark's logical plan that Delta can push
            # to the scan for partition/file pruning — the same mechanism that makes
            # use_timeseries_filtering effective.
            if len(cols) == 1:
                filter_expr = F.col(cols[0]).isin(list({row[0] for row in collected}))
            else:
                filter_expr = reduce(
                    lambda a, b: a & b,
                    [
                        F.col(c).isin(list({row[i] for row in collected}))
                        for i, c in enumerate(cols)
                    ],
                )
            _logger.info(
                "hint_low_cardinality_columns optimization applied for table '%s'",
                table_name,
            )
            return feature_table_data.filter(filter_expr)
        cols.pop()

    _logger.info(
        "hint_low_cardinality_columns optimization not applied for table '%s'",
        table_name,
    )
    return feature_table_data


def join_feature_data_if_not_overridden(
    feature_spec: FeatureSpec,
    df: DataFrame,
    features_to_join: List[FeatureColumnInfo],
    feature_table_metadata_map: Dict[str, FeatureTable],
    feature_table_data_map: Dict[str, DataFrame],
    use_spark_native_join: Optional[bool] = False,
    use_timeseries_filtering: bool = False,
    hint_low_cardinality_columns: bool = False,
) -> DataFrame:
    """
    Joins `df` with features specified by `feature_spec.feature_column_infos` if they do not already exist.

    Return column order is df.columns + newly joined features. The newly joined feature order is not guaranteed to
    match `feature_spec.feature_column_infos` as feature lookups are first grouped by table for efficiency.

    Before joining, it checks that:
    1. Feature table keys match length and types of `df` lookup keys specified by FeatureSpec
    2. `df` contains lookup keys specified by FeatureSpec
    3. Feature table timestamp lookup keys match length and types of `df` timestamp lookup keys if specified by FeatureSpec
    4. `df` contains timestamp lookup keys if specified by FeatureSpec
    """
    _validate_join_feature_data(
        df=df,
        features_to_join=features_to_join,
        feature_table_metadata_map=feature_table_metadata_map,
        feature_table_data_map=feature_table_data_map,
    )

    # Helper class to group all unique combinations of feature table names and lookup keys.
    # All features in each of these groups will be JOINed with the training df using a single JOIN.
    class JoinDataKey:
        def __init__(
            self,
            feature_table: str,
            lookup_key: List[str],
            timestamp_lookup_key: List[str],
            lookback_window: Optional[datetime.timedelta] = None,
        ):
            self.feature_table = feature_table
            self.lookup_key = lookup_key
            self.timestamp_lookup_key = timestamp_lookup_key
            self.lookback_window = lookback_window

        def __hash__(self):
            return (
                hash(self.feature_table)
                + hash(tuple(self.lookup_key))
                + hash(tuple(self.timestamp_lookup_key))
                + hash(self.lookback_window)
            )

        def __eq__(self, other):
            return (
                self.feature_table == other.feature_table
                and self.lookup_key == other.lookup_key
                and self.timestamp_lookup_key == other.timestamp_lookup_key
                and self.lookback_window == other.lookback_window
            )

    # Iterate through the list of FeatureColumnInfo and group features by name of the
    # feature table and lookup key(s) and timestamp lookup key(s)
    table_join_data = defaultdict(dict)
    lookback_windows = {
        t.table_name: t.lookback_window for t in feature_spec.table_infos
    }
    for feature_info in features_to_join:
        join_data_key = JoinDataKey(
            feature_info.table_name,
            feature_info.lookup_key,
            feature_info.timestamp_lookup_key,
            lookback_windows[feature_info.table_name],
        )
        table_join_data[join_data_key][
            feature_info.feature_name
        ] = feature_info.output_name

    for join_data_key, feature_to_output_name in table_join_data.items():

        feature_table_metadata = feature_table_metadata_map[join_data_key.feature_table]
        feature_table_data = feature_table_data_map[join_data_key.feature_table]

        # Apply timeseries filtering if enabled
        if use_timeseries_filtering and join_data_key.timestamp_lookup_key:
            feature_table_data = _apply_timeseries_filter(
                feature_table_data=feature_table_data,
                training_df=df,
                feature_timestamp_key=feature_table_metadata.timestamp_keys[0],
                training_timestamp_key=join_data_key.timestamp_lookup_key[0],
                lookback_window_seconds=join_data_key.lookback_window,
            )

        if join_data_key.timestamp_lookup_key:
            # If lookback window is set to 0, then perform exact join instead of asof join to get perf benefits.
            if (
                join_data_key.lookback_window is not None
                and join_data_key.lookback_window == 0
            ):
                df = _spark_join_features(
                    df=df,
                    df_keys=join_data_key.lookup_key
                    + join_data_key.timestamp_lookup_key,
                    feature_table_data=feature_table_data,
                    feature_table_keys=feature_table_metadata.primary_keys
                    + feature_table_metadata.timestamp_keys,
                    feature_to_output_name=feature_to_output_name,
                )
            else:
                df = _spark_asof_join_features(
                    df=df,
                    df_lookup_keys=join_data_key.lookup_key,
                    df_timestamp_lookup_key=join_data_key.timestamp_lookup_key[0],
                    feature_table_data=feature_table_data,
                    feature_table_keys=feature_table_metadata.primary_keys,
                    feature_table_timestamp_key=feature_table_metadata.timestamp_keys[
                        0
                    ],
                    feature_to_output_name=feature_to_output_name,
                    lookback_window_seconds=join_data_key.lookback_window,
                    use_spark_native_join=use_spark_native_join,
                )
        else:
            if hint_low_cardinality_columns:
                feature_table_data = _apply_pk_cardinality_filter(
                    feature_table_data=feature_table_data,
                    training_df=df,
                    table_name=join_data_key.feature_table,
                    feature_table_metadata=feature_table_metadata,
                )
            df = _spark_join_features(
                df=df,
                df_keys=join_data_key.lookup_key,
                feature_table_data=feature_table_data,
                feature_table_keys=feature_table_metadata.primary_keys,
                feature_to_output_name=feature_to_output_name,
            )
    return df


def get_feature_lookups_with_full_table_names(
    feature_lookups: List[FeatureLookup], current_catalog: str, current_schema: str
) -> List[FeatureLookup]:
    """
    Takes in a list of FeatureLookups, and returns copies with reformatted table names.
    """
    table_names = {fl.table_name for fl in feature_lookups}
    uc_utils._check_qualified_table_names(table_names)
    uc_utils._verify_all_tables_are_either_in_uc_or_in_hms(
        table_names, current_catalog, current_schema
    )
    standardized_feature_lookups = []
    for fl in feature_lookups:
        fl_copy = copy.deepcopy(fl)
        fl_copy._table_name = uc_utils.get_full_table_name(
            fl_copy.table_name, current_catalog, current_schema
        )
        standardized_feature_lookups.append(fl_copy)
    return standardized_feature_lookups


def augment_training_df_with_computed_features(
    df: DataFrame, computed_features_df: Dict[DataSource, DataFrame]
) -> DataFrame:
    """
    Annotate a training DataFrame with computed features using as-of joins.

    Args:
        df: The training DataFrame to annotate
        computed_features_df: Dictionary mapping DataSource to computed features DataFrame

    Returns:
        DataFrame: The annotated DataFrame with computed features joined
    """
    result_df = df
    for data_source, features_df in computed_features_df.items():
        result_df = _spark_asof_join_features_native(
            labels_df=result_df,
            features_df=features_df,
            primary_keys=data_source.entity_columns,
            timestamp_key=data_source.timeseries_column,
        )
    return result_df
