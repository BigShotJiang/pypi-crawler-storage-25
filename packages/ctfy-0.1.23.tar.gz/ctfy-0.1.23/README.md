# ctfy

Open-source CTF platform — run challenges, register teams, score submissions.
Ships with a REST API and MCP server for AI-agent evaluation harnesses.

![ctfy dashboard](docs/screenshots/dashboard.png)

## Quick start

```bash
echo "CTFY_ADMIN_TOKEN=$(openssl rand -hex 32)" > .env && docker compose up -d
```

Then open <http://localhost:8100>.

## Screens

### Challenges

![](docs/screenshots/challenges.png) 

### Scoreboard

![](docs/screenshots/scoreboard.png)

### Activity

![](docs/screenshots/activity.png)

### Achievements

![](docs/screenshots/achievements.png)
