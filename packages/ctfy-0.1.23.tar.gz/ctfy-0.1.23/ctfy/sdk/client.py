"""Platform HTTP client — single client for the ctfy platform.

This is the only HTTP client needed. Used by CLI, MCP server, and external users.

Usage::

    from ctfy.sdk import PlatformClient

    client = PlatformClient("http://localhost:8100", token="pt_xxx")
    challenges = client.list_challenges(category="web")
    surface = client.start_instance("WEB-001")
    result = client.submit_flag("WEB-001", "FLAG{...}")
    board = client.scoreboard()
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Generic, TypeVar

import httpx
from pydantic import BaseModel

from ctfy.core.constants import (
    DEFAULT_CLIENT_TIMEOUT,
    DEFAULT_INSTANCE_TTL,
    DEFAULT_POLL_TIMEOUT,
)
from ctfy.core.enums import InstanceStatus
from ctfy.core.state.models import SubmissionState
from ctfy.core.target import AttackSurface
from ctfy.sdk.base import BaseHttpClient
from ctfy.server.models import (
    Activity,
    ChallengeInfo,
    ChallengeStats,
    HealthResponse,
    InstanceInfo,
    InstanceStatusResponse,
    NodeInfo,
    RenewResponse,
    ScoreboardEntry,
    StartResponse,
    SubmissionResponse,
    TeamInfo,
    TeamResponse,
    VerifyFlagResponse,
)

T = TypeVar("T")


class PaginatedResponse(BaseModel, Generic[T]):
    """Lightweight paginated response model for parsing server responses."""

    items: list[T]
    total: int
    offset: int = 0
    limit: int = 50


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


@dataclass
class InstanceReadyResult:
    """Result of polling an instance until ready."""

    surface: AttackSurface
    sandbox_network: str = ""
    proxy_gateway: str = ""
    cert_volume: str = ""


def _poll_instance_ready(
    client: httpx.Client,
    instance_id: str,
    *,
    timeout: int = DEFAULT_POLL_TIMEOUT,
    poll_interval: float = 2.0,
) -> InstanceReadyResult:
    """Poll GET /instances/{id}/status until ready. Raises on error/timeout."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        resp = client.get(f"/instances/{instance_id}/status")
        if resp.status_code == 404:
            # Instance may not be registered yet (async start); keep polling
            time.sleep(poll_interval)
            continue
        resp.raise_for_status()
        status_resp = InstanceStatusResponse.model_validate(resp.json())

        if status_resp.status == InstanceStatus.READY and status_resp.attack_surface:
            return InstanceReadyResult(
                surface=status_resp.attack_surface,
                sandbox_network=status_resp.sandbox_network,
                proxy_gateway=status_resp.proxy_gateway,
                cert_volume=getattr(status_resp, "cert_volume", ""),
            )
        if status_resp.status == InstanceStatus.ERROR:
            raise RuntimeError(f"Instance {instance_id} failed: {status_resp.error}")
        time.sleep(poll_interval)

    raise TimeoutError(f"Instance {instance_id} not ready after {timeout}s")


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


class PlatformClient(BaseHttpClient):
    """HTTP client for the ctfy platform.

    Handles: teams, challenges, instances, flag submission/verification,
    scoreboard. Used by CLI, SDK, and MCP.
    """

    def __init__(
        self,
        server_url: str,
        token: str = "",
        max_retries: int = 3,
        timeout: int = DEFAULT_CLIENT_TIMEOUT,
    ):
        self._url = server_url.rstrip("/")
        super().__init__(f"{self._url}/api/v1", token, timeout=timeout, max_retries=max_retries)
        self.instance_id_cache: dict[str, str] = {}  # challenge_id -> instance_id

    # -- teams --------------------------------------------------------------

    def register_team(self, name: str, agent: str = "", description: str = "") -> TeamResponse:
        resp = self._request(
            "POST",
            "/teams",
            json={
                "name": name,
                "agent": agent,
                "description": description,
            },
        )
        resp.raise_for_status()
        return TeamResponse.model_validate(resp.json())

    def list_teams(self, offset: int = 0, limit: int = 50) -> list[TeamInfo]:
        resp = self._request("GET", "/teams", params={"offset": offset, "limit": limit})
        resp.raise_for_status()
        page = PaginatedResponse[TeamInfo].model_validate(resp.json())
        return page.items

    def get_team(self, team_id: str) -> TeamInfo:
        resp = self._request("GET", f"/teams/{team_id}")
        resp.raise_for_status()
        return TeamInfo.model_validate(resp.json())

    def get_me(self) -> TeamInfo:
        """Get current team info (requires team auth)."""
        resp = self._request("GET", "/me")
        resp.raise_for_status()
        return TeamInfo.model_validate(resp.json())

    # -- challenges ---------------------------------------------------------

    def list_challenges(
        self,
        difficulty: str | None = None,
        tag: str = "",
        q: str = "",
        offset: int = 0,
        limit: int = 50,
    ) -> list[ChallengeInfo]:
        params: dict = {"offset": offset, "limit": limit}
        if difficulty:
            params["difficulty"] = difficulty
        if tag:
            params["tag"] = tag
        if q:
            params["q"] = q
        resp = self._request("GET", "/challenges", params=params)
        resp.raise_for_status()
        page = PaginatedResponse[ChallengeInfo].model_validate(resp.json())
        return page.items

    def get_challenge(self, challenge_id: str) -> ChallengeInfo:
        resp = self._request("GET", f"/challenges/{challenge_id}")
        resp.raise_for_status()
        return ChallengeInfo.model_validate(resp.json())

    # -- instances ----------------------------------------------------------

    def start_instance(
        self,
        challenge_id: str,
        ttl: int = DEFAULT_INSTANCE_TTL,
        *,
        timeout: int = 300,
        poll_interval: float = 2.0,
        proxy_output_dir: str | None = None,
    ) -> InstanceReadyResult:
        """Start instance and wait until ready.

        Returns InstanceReadyResult with attack surface + sandbox network info.
        The .surface attribute provides backward compatibility.

        Args:
            challenge_id: Challenge ID (e.g., "XBOW-047").
            ttl: Time-to-live in seconds.
            timeout: Max seconds to wait for ready.
            poll_interval: Seconds between status polls.
            proxy_output_dir: Host path to store proxy traffic captures.
        """
        body: dict = {
            "challenge_id": challenge_id,
            "ttl": ttl,
        }
        if proxy_output_dir:
            body["proxy_output_dir"] = proxy_output_dir
        resp = self._request(
            "POST",
            "/instances",
            json=body,
        )
        if resp.status_code != 409:  # 409 = already running, just poll
            resp.raise_for_status()

        # 409 can mean "already running" (has instance_id) or "already solved" (no instance_id)
        data = resp.json()
        if resp.status_code == 409 and "instance_id" not in data:
            detail = data.get("detail", "Conflict")
            raise RuntimeError(f"Cannot start instance for {challenge_id}: {detail}")

        # Use the server-returned instance_id (random UUID)
        start = StartResponse.model_validate(data)
        self.instance_id_cache[challenge_id] = start.instance_id

        return _poll_instance_ready(
            self._client, start.instance_id, timeout=timeout, poll_interval=poll_interval
        )

    def resolve_instance_id(self, challenge_id: str) -> str:
        """Resolve challenge_id to instance_id via cache or server lookup."""
        if challenge_id in self.instance_id_cache:
            return self.instance_id_cache[challenge_id]
        resp = self._request("GET", "/instances/resolve", params={"challenge_id": challenge_id})
        resp.raise_for_status()
        instance_id = resp.json()["instance_id"]
        self.instance_id_cache[challenge_id] = instance_id
        return instance_id

    def get_instance_status(self, instance_id: str) -> InstanceStatusResponse:
        """Get instance status and attack surface."""
        resp = self._request("GET", f"/instances/{instance_id}/status")
        resp.raise_for_status()
        return InstanceStatusResponse.model_validate(resp.json())

    def stop_instance(self, challenge_id: str) -> None:
        try:
            instance_id = self.resolve_instance_id(challenge_id)
        except Exception:
            # Instance already destroyed (e.g. auto-stopped after solve)
            self.instance_id_cache.pop(challenge_id, None)
            return
        resp = self._request("DELETE", f"/instances/{instance_id}")
        if resp.status_code != 404:
            resp.raise_for_status()
        self.instance_id_cache.pop(challenge_id, None)

    def renew_instance(self, challenge_id: str, ttl: int = DEFAULT_INSTANCE_TTL) -> RenewResponse:
        """Extend the TTL of a running instance."""
        instance_id = self.resolve_instance_id(challenge_id)
        resp = self._request("POST", f"/instances/{instance_id}/renew", params={"ttl": ttl})
        resp.raise_for_status()
        return RenewResponse.model_validate(resp.json())

    # -- flag verification (low-level, used by CLI in local mode) -----------

    def verify_flag(self, challenge_id: str, claimed_flag: str) -> VerifyFlagResponse:
        """Server-side flag verification (without recording as submission).

        Returns VerifyFlagResponse with ``.correct`` and ``.flag_id``.
        On multi-flag challenges ``.flag_id`` identifies which declared
        flag the claim matched (``None`` on wrong claims).
        """
        instance_id = self.resolve_instance_id(challenge_id)
        resp = self._request(
            "POST",
            f"/instances/{instance_id}/verify-flag",
            json={"claimed_flag": claimed_flag},
        )
        if resp.status_code == 404:
            return VerifyFlagResponse(correct=False)
        resp.raise_for_status()
        return VerifyFlagResponse.model_validate(resp.json())

    # -- submissions (platform mode, records score) -------------------------

    def submit_flag(self, challenge_id: str, flag: str) -> SubmissionResponse:
        resp = self._request(
            "POST",
            "/submissions",
            json={"challenge_id": challenge_id, "flag": flag},
        )
        resp.raise_for_status()
        return SubmissionResponse.model_validate(resp.json())

    def list_submissions(
        self, challenge_id: str = "", offset: int = 0, limit: int = 50
    ) -> list[SubmissionState]:
        """List current team's submissions."""
        params: dict = {"offset": offset, "limit": limit}
        if challenge_id:
            params["challenge_id"] = challenge_id
        resp = self._request("GET", "/submissions", params=params)
        resp.raise_for_status()
        page = PaginatedResponse[SubmissionState].model_validate(resp.json())
        return page.items

    # -- scoreboard ---------------------------------------------------------

    def scoreboard(
        self, category: str = "", offset: int = 0, limit: int = 50
    ) -> list[ScoreboardEntry]:
        params: dict = {"offset": offset, "limit": limit}
        if category:
            params["category"] = category
        resp = self._request("GET", "/scoreboard", params=params)
        resp.raise_for_status()
        page = PaginatedResponse[ScoreboardEntry].model_validate(resp.json())
        return page.items

    def challenge_stats(self, offset: int = 0, limit: int = 50) -> list[ChallengeStats]:
        resp = self._request(
            "GET", "/scoreboard/challenges", params={"offset": offset, "limit": limit}
        )
        resp.raise_for_status()
        page = PaginatedResponse[ChallengeStats].model_validate(resp.json())
        return page.items

    # Aliases for naming consistency with MCP tools
    get_scoreboard = scoreboard
    get_challenge_stats = challenge_stats

    # -- health & status -----------------------------------------------------

    def health(self) -> HealthResponse:
        resp = self._request("GET", "/health")
        resp.raise_for_status()
        return HealthResponse.model_validate(resp.json())

    def list_instances(
        self,
        challenge_id: str = "",
        status: str = "",
        q: str = "",
        offset: int = 0,
        limit: int = 50,
    ) -> list[InstanceInfo]:
        """List all running instances."""
        params: dict = {"offset": offset, "limit": limit}
        if challenge_id:
            params["challenge_id"] = challenge_id
        if status:
            params["status"] = status
        if q:
            params["q"] = q
        resp = self._request("GET", "/instances", params=params)
        resp.raise_for_status()
        page = PaginatedResponse[InstanceInfo].model_validate(resp.json())
        return page.items

    # -- activities ---------------------------------------------------------

    def get_activities(
        self,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        offset: int = 0,
        limit: int = 100,
    ) -> list[Activity]:
        """Get platform activity log."""
        params: dict = {"offset": offset, "limit": limit}
        if team_id:
            params["team_id"] = team_id
        if challenge_id:
            params["challenge_id"] = challenge_id
        if event:
            params["event"] = event
        resp = self._request("GET", "/activities", params=params)
        resp.raise_for_status()
        return [Activity.model_validate(a) for a in resp.json()["items"]]

    # -- nodes --------------------------------------------------------------

    def list_nodes(self, offset: int = 0, limit: int = 50) -> list[NodeInfo]:
        resp = self._request("GET", "/nodes", params={"offset": offset, "limit": limit})
        resp.raise_for_status()
        page = PaginatedResponse[NodeInfo].model_validate(resp.json())
        return page.items

    def register_node(self, url: str, capacity: int = 10, labels: dict | None = None) -> NodeInfo:
        resp = self._request(
            "POST",
            "/nodes/register",
            json={
                "url": url,
                "capacity": capacity,
                "labels": labels or {},
            },
        )
        resp.raise_for_status()
        return NodeInfo.model_validate(resp.json())

    def remove_node(self, node_id: str) -> None:
        resp = self._request("DELETE", f"/nodes/{node_id}")
        resp.raise_for_status()
