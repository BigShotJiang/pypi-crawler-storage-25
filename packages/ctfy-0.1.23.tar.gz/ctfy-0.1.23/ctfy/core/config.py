"""Framework configuration as a plain pydantic model.

Every knob is declared with a default + description so the CLI can mirror the
schema (``ctfy server start --help``) and operators see the full surface in
one place. Validation runs at instantiation; filesystem existence is *not*
enforced so tests can build a config inside a tmpdir without scaffolding.

The class also exposes :meth:`CtfyConfig.from_env`, the single source of truth
for translating ``CTFY_*`` environment variables into a config — used by the
CLI (``ctfy server start`` / ``ctfy node join``) and by ``ctfy config show``.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field, SecretStr, model_validator

from ctfy.core.constants import (
    SCOREBOARD_RATE_LIMIT,
    SUBMISSION_RATE_LIMIT,
    SUBMISSION_RATE_WINDOW,
)
from ctfy.core.exceptions import ConfigError

_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent

_PORT_MAX = 65535


class CtfyConfig(BaseModel):
    """Single source of truth for runtime configuration.

    Constructed explicitly with keyword arguments — the CLI reads values from
    env / ``.env`` via typer's ``envvar=`` and hands them to this constructor.
    Field defaults double as the typer ``--xxx`` defaults, so changing a
    default here propagates to ``ctfy server start --help`` automatically.
    """

    # --- Paths ---
    project_root: Path = Field(
        default=_PROJECT_ROOT,
        description="Repository root. Derived from the package location; rarely overridden.",
    )
    challenges_dir: Path = Field(
        default=Path.home() / ".ctf-arena" / "challenges",
        description=(
            "Directory containing challenge metadata.yaml files. Default is a "
            "user-level shared cache so multiple ctfy checkouts reuse one clone. "
            "Populate via ``ctfy challenge sync``."
        ),
    )
    challenges_repo: str = Field(
        default="https://github.com/CTF-Arena/challenges.git",
        description=(
            "Git repository cloned into ``challenges_dir`` by ``ctfy challenge "
            "sync``. Empty string disables sync."
        ),
    )
    instances_dir: Path = Field(
        default=_PROJECT_ROOT / "data" / "instances",
        description="Working directory for per-instance artefacts (flags, proxy output).",
    )
    instance_archive_dir: Path = Field(
        default=_PROJECT_ROOT / "data" / "archive",
        description=(
            "Platform-side permanent archive for per-instance artifacts (manifest, "
            "event stream, flag-attempt log, container logs). One directory per "
            "instance_id; never auto-purged so the full benchmark history stays "
            "available for offline analysis."
        ),
    )

    # --- Host path translation (set when platform runs inside Docker) ---
    host_project_root: str = Field(
        default="",
        description=(
            "Host path that maps to the container's project root. Used to rewrite "
            "bind-mount sources when the node runs inside Docker. Leave empty on "
            "bare-metal deployments."
        ),
    )

    # --- Traefik (unified HTTP entrypoint for challenge instances) ---
    traefik_domain: str = Field(
        default="localtest.me",
        description=(
            "Wildcard domain Traefik routes under. Default ``localtest.me`` is "
            "public DNS that resolves ``*.localtest.me`` to 127.0.0.1, so "
            "instance URLs work from any browser on the host without extra "
            "DNS setup. Override to a deployment-specific wildcard for remote "
            "operators."
        ),
    )
    traefik_public_url: str = Field(
        default="",
        description=(
            "Base URL users see in instance attack surfaces (e.g. "
            "``http://localtest.me`` or ``http://ctf.example.com:8080``). "
            "The subdomain is prepended per instance. Leave empty to default "
            "to ``http://{traefik_domain}``."
        ),
    )
    traefik_network: str = Field(
        default="traefik_proxy",
        description=(
            "Name of the external Docker network shared between Traefik and "
            "challenge containers. Must be a pinned name — the top-level "
            "docker-compose declares it with ``name:`` so per-instance compose "
            "files can reference it as ``external: true``."
        ),
    )

    # --- Docker images ---
    image_mitmproxy: str = Field(
        default="ctfy-mitmproxy",
        description="Image tag used for the per-instance mitmproxy sidecar.",
    )
    node_image: str = Field(
        default="ghcr.io/wangyihang/ctfy:latest",
        description=(
            "Docker image advertised by ``ctfy server invite``. The same image "
            "powers platform + node — the ``command`` after the image name "
            "selects the role. Forks should override via ``--node-image`` / "
            "``CTFY_NODE_IMAGE`` to point at their own GHCR."
        ),
    )

    # --- Platform server ---
    platform_url: str = Field(
        default="",
        description=(
            "Platform base URL (e.g. http://server:8100) used by SDK/CLI/MCP "
            "clients and by nodes finding the platform."
        ),
    )
    server_host: str = Field(
        default="0.0.0.0",
        description="Bind address for ``ctfy server start``.",
    )
    server_port: int = Field(
        default=8100,
        ge=1,
        le=_PORT_MAX,
        description="Bind port for ``ctfy server start``.",
    )
    admin_token: SecretStr = Field(
        default=SecretStr(""),
        description=(
            "Admin bearer token. ``CTFY_SERVER_API_KEY`` is accepted as a backward-compatible alias."
        ),
    )
    team_token: SecretStr = Field(
        default=SecretStr(""),
        description=(
            "Single-team CLI/MCP convenience token. Teams created via "
            "``POST /teams`` each receive their own token stored in the state "
            "backend — this setting is only used by ``ctfy`` commands run as a "
            "team client."
        ),
    )

    # --- State backend ---
    db_path: str = Field(
        default="",
        description="SQLite file path (default: ``{project_root}/data/platform.sqlite3``).",
    )

    # --- Rate limiting (slowapi) ---
    rate_limiting_enabled: bool = Field(
        default=False,
        description=(
            "Master switch for slowapi rate limiting. When False (default), all "
            "@limiter.limit decorators become no-ops. Flip to True to enforce the "
            "per-endpoint caps defined below."
        ),
    )
    rate_limit_default: str = Field(
        default="600/minute",
        description=(
            "Global per-IP ceiling applied to every route in addition to any "
            "per-endpoint cap. slowapi rate string (e.g. '600/minute', '10/second'). "
            "Ignored when rate_limiting_enabled=False."
        ),
    )
    rate_limit_submission: str = Field(
        default=f"{SUBMISSION_RATE_LIMIT}/{int(SUBMISSION_RATE_WINDOW)} seconds",
        description="Per-IP cap on POST /submissions.",
    )
    rate_limit_scoreboard: str = Field(
        default=SCOREBOARD_RATE_LIMIT,
        description="Per-IP cap on /scoreboard and /scoreboard/challenges.",
    )
    rate_limit_instance_start: str = Field(
        default="30/minute",
        description="Per-IP cap on POST /instances (instance provisioning is expensive).",
    )
    rate_limit_team_create: str = Field(
        default="10/hour",
        description="Per-IP cap on POST /teams to curb sign-up abuse.",
    )

    @model_validator(mode="after")
    def _check_invariants(self) -> "CtfyConfig":
        if self.platform_url and not self.platform_url.startswith(("http://", "https://")):
            raise ConfigError(
                f"platform_url must start with http:// or https:// (got: {self.platform_url!r})"
            )
        return self

    @classmethod
    def from_env(
        cls,
        overrides: dict[str, Any] | None = None,
        *,
        env: dict[str, str] | None = None,
    ) -> "CtfyConfig":
        """Build a config from ``CTFY_*`` env vars + optional explicit overrides.

        ``overrides`` always wins over the environment so CLI flags can stay
        authoritative. ``CTFY_SERVER_API_KEY`` is honoured as a backward-compat
        alias for ``CTFY_ADMIN_TOKEN``.
        """
        env = env if env is not None else os.environ
        raw: dict[str, Any] = {}
        for name in cls.model_fields:
            value = env.get(f"CTFY_{name.upper()}")
            if value is None or value == "":
                continue
            raw[name] = value
        if "admin_token" not in raw and env.get("CTFY_SERVER_API_KEY"):
            raw["admin_token"] = env["CTFY_SERVER_API_KEY"]
        if overrides:
            for k, v in overrides.items():
                if v in (None, ""):
                    continue
                raw[k] = v
        return cls(**raw)
