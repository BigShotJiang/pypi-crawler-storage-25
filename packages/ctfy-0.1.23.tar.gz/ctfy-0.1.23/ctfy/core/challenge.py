"""Challenge manager — spec registry and provider dispatch.

ChallengeSpec is the in-memory form of an upstream ``metadata.yaml``.
The core schema is the slim v3 spec defined in
https://github.com/CTF-Arena/challenges/blob/main/CLAUDE.md — four
upstream fields (``name``, ``description``, ``difficulty``, ``tags``) with
``id`` injected from the directory name at parse time.

ctfy adds one optional extension: ``flags: list[str]`` declares a set of
platform-minted flag ids for multi-flag challenges (e.g. foothold / root).
Challenges that omit the field default to a single flag with id ``main``;
this is the only divergence from upstream slim v3. Every other concept
(category, provider, service topology, flag values) remains platform-fixed
and never appears in metadata.
"""

from __future__ import annotations

import atexit
import re
from pathlib import Path
from typing import ClassVar, Iterator

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator

from ctfy.core.config import CtfyConfig
from ctfy.core.enums import Difficulty
from ctfy.core.provider import ChallengeProvider, StartResult

_FLAG_ID_RE = re.compile(r"^[a-z][a-z0-9_]*$")
DEFAULT_FLAG_ID = "main"


class ChallengeSpec(BaseModel):
    """Parsed challenge metadata — slim v3 upstream schema + ctfy `flags` extension.

    Unknown keys raise ``ValidationError`` at parse time (enforces upstream
    rule META005, "no unknown top-level fields"). ``tags`` is required to be
    non-empty (META004). ``flags`` is a platform-level optional list of flag
    ids (defaults to ``["main"]`` so single-flag challenges need not declare
    it).
    """

    model_config = ConfigDict(extra="forbid")

    # Upstream-sourced (metadata.yaml)
    name: str
    description: str
    difficulty: Difficulty
    tags: list[str] = Field(min_length=1)

    # ctfy extension — optional list of flag ids. Snake-case identifiers only,
    # unique within the challenge. Defaults to a single flag named ``main``.
    flags: list[str] = Field(default_factory=lambda: [DEFAULT_FLAG_ID], min_length=1)

    # Platform-injected
    id: str
    instance_id: str = ""

    # Platform-fixed defaults (the only category/provider supported today)
    CATEGORY: ClassVar[str] = "web"
    PROVIDER: ClassVar[str] = "docker"

    @field_validator("flags")
    @classmethod
    def _validate_flags(cls, v: list[str]) -> list[str]:
        if len(set(v)) != len(v):
            raise ValueError("flag ids must be unique")
        for fid in v:
            if not isinstance(fid, str) or not _FLAG_ID_RE.fullmatch(fid):
                raise ValueError(
                    f"flag id {fid!r} must match ^[a-z][a-z0-9_]*$ (snake_case)"
                )
        return v

    @property
    def effective_id(self) -> str:
        """ID used for container/network naming (unique per team+challenge)."""
        return self.instance_id or self.id

    @classmethod
    def from_yaml(cls, path: Path) -> ChallengeSpec:
        """Parse ``metadata.yaml``; ``id`` comes from the parent directory name."""
        data = yaml.safe_load(path.read_text()) or {}
        if not isinstance(data, dict):
            raise ValueError(f"metadata.yaml must be a mapping at {path}")
        data["id"] = path.parent.name
        return cls(**data)


class ChallengeManager:
    """Scans metadata.yaml specs and dispatches lifecycle to the Docker provider.

    Historically this class ran a provider registry so multiple backends
    (``docker``, ``offline``, test shims) could coexist. The upstream SSOT
    now pins everything to ``docker compose``, so the registry was removed
    and a single :class:`DockerProvider` is instantiated lazily.
    """

    def __init__(self, config: CtfyConfig):
        self.config = config
        self.challenges_dir = config.challenges_dir
        self._provider: ChallengeProvider | None = None
        atexit.register(self.stop_all)

    @property
    def provider(self) -> ChallengeProvider:
        if self._provider is None:
            from ctfy.providers.docker_provider.provider import DockerProvider

            self._provider = DockerProvider(self.config)
        return self._provider

    # -- enumeration --------------------------------------------------------

    def iter_specs(
        self,
        *,
        challenge_id: str | None = None,
        difficulty: str | None = None,
        tag: str | None = None,
    ) -> Iterator[ChallengeSpec]:
        """Walk ``challenges_dir`` and yield parsed specs.

        Invalid metadata (parse / schema errors) is skipped with a warning —
        one malformed challenge doesn't block listing the rest. The CLI's
        ``ctfy challenge validate`` path surfaces those errors explicitly.
        """
        from pydantic import ValidationError

        from ctfy.core.log import log

        if not self.challenges_dir.exists():
            return
        for d in sorted(self.challenges_dir.iterdir()):
            yml = d / "metadata.yaml"
            if not d.is_dir() or not yml.exists():
                continue
            try:
                spec = ChallengeSpec.from_yaml(yml)
            except (ValidationError, yaml.YAMLError, OSError) as exc:
                log.warning("Skipping invalid challenge", challenge=d.name, error=str(exc))
                continue
            if challenge_id:
                patterns = [e.strip() for e in challenge_id.split(",")]
                if not any(spec.id == p or spec.id.startswith(p + "-") for p in patterns):
                    continue
            if difficulty is not None and spec.difficulty.value != difficulty:
                continue
            if tag and tag not in spec.tags:
                continue
            yield spec

    # -- lifecycle ----------------------------------------------------------

    def start(
        self,
        spec: ChallengeSpec,
        *,
        flags: dict[str, str],
        proxy_output_dir: Path | None = None,
    ) -> StartResult:
        """Start an instance. ``flags`` is minted on the platform (step 18).

        ``flags`` maps flag_id (declared in ``spec.flags``) to the raw flag
        value. Must be non-empty and cover every id in ``spec.flags`` with a
        non-empty value.
        """
        if not flags:
            raise ValueError("flags must be non-empty; generate them on the platform")
        expected = set(spec.flags)
        missing = expected - set(flags)
        if missing:
            raise ValueError(f"flags dict missing ids: {sorted(missing)}")
        extra = set(flags) - expected
        if extra:
            raise ValueError(f"flags dict has unknown ids: {sorted(extra)}")
        for fid, val in flags.items():
            if not val:
                raise ValueError(f"flag {fid!r} is empty; every flag value must be non-empty")
        return self.provider.start(spec, proxy_output_dir=proxy_output_dir, flags=flags)

    def verify_flag(self, spec: ChallengeSpec, claimed_flag: str) -> str | None:
        """Return the flag_id that matches *claimed_flag*, or None if no match."""
        return self.provider.verify_flag(spec.effective_id, claimed_flag)

    def stop(self, spec: ChallengeSpec) -> None:
        self.provider.stop(spec)

    def check_health(self, instance_id: str) -> bool:
        """Check if an instance's containers are all running."""
        return self.provider.check_health(instance_id)

    def get_sandbox_network(self, instance_id: str) -> tuple[str, str] | None:
        """Return (attacker_network_name, proxy_gateway_ip) for sandbox."""
        return self.provider.get_sandbox_network(instance_id)

    def get_cert_volume(self, instance_id: str) -> str:
        """Return the Docker volume name containing mitmproxy CA certs."""
        return self.provider.get_cert_volume(instance_id)

    def get_proxy_output(self, instance_id: str) -> Path | None:
        """Return path to mitmproxy traffic output directory, if available."""
        return self.provider.get_proxy_output(instance_id)

    def get_container_logs(self, instance_id: str) -> str:
        """Return combined stdout+stderr for the instance's containers."""
        return self.provider.get_container_logs(instance_id)

    def stop_all(self) -> None:
        if self._provider is not None:
            self._provider.stop_all()
