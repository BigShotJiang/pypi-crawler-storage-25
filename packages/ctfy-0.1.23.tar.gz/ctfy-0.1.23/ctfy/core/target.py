"""Standardized target description for AI pentest agents."""

from __future__ import annotations

from enum import Enum

from pydantic import Field

from ctfy.core.models import CtfyModel


class ServiceType(str, Enum):
    SSH = "ssh"
    HTTP = "http"
    HTTPS = "https"
    TCP = "tcp"


class Credential(CtfyModel):
    username: str
    password: str | None = None
    key_file: str | None = None


class ServiceEndpoint(CtfyModel):
    """One reachable service on the target."""

    service_type: ServiceType
    host: str
    port: int
    credentials: Credential | None = None
    path: str = "/"
    label: str = ""

    @property
    def url(self) -> str:
        if self.service_type == ServiceType.TCP:
            return f"{self.host}:{self.port}"
        base = f"{self.service_type.value}://{self.host}:{self.port}"
        if self.path and self.path != "/":
            return f"{base}{self.path}"
        return base


class AttackSurface(CtfyModel):
    """Agent-agnostic description of what can be attacked.

    Every agent receives this; each agent picks the services it needs.
    """

    services: list[ServiceEndpoint] = Field(default_factory=list)
    provided_files: list[str] = Field(default_factory=list)
    flag_path: str | None = None

    def get_service(self, stype: ServiceType, label: str = "") -> ServiceEndpoint | None:
        for s in self.services:
            if s.service_type == stype and (not label or s.label == label):
                return s
        return None

    def get_ssh(self) -> ServiceEndpoint | None:
        return self.get_service(ServiceType.SSH)

    def get_http(self) -> ServiceEndpoint | None:
        return self.get_service(ServiceType.HTTP) or self.get_service(ServiceType.HTTPS)

    @classmethod
    def from_dict(cls, raw: dict) -> "AttackSurface":
        """Parse an attack_surface dict (e.g. from JSON API response)."""
        services = [ServiceEndpoint(**s) for s in raw.get("services", [])]
        return cls(
            services=services,
            provided_files=raw.get("provided_files", []),
            flag_path=raw.get("flag_path"),
        )
