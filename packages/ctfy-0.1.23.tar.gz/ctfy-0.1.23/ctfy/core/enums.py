"""Shared enums — single source of truth for status values, event types, and constants."""

from __future__ import annotations

from enum import Enum


class InstanceStatus(str, Enum):
    """Lifecycle status of a challenge instance."""

    STARTING = "starting"
    READY = "ready"
    ERROR = "error"
    STOPPED = "stopped"


class PlatformEvent(str, Enum):
    """Events emitted by the platform (SSE broadcast + activity log)."""

    INSTANCE_STARTED = "instance_started"
    INSTANCE_READY = "instance_ready"
    INSTANCE_ERROR = "instance_error"
    INSTANCE_STOPPED = "instance_stopped"
    FLAG_CORRECT = "flag_correct"
    FLAG_PART_CORRECT = "flag_part_correct"
    FLAG_WRONG = "flag_wrong"
    TEAM_REGISTERED = "team_registered"
    INSTANCE_RENEWED = "instance_renewed"
    NODE_REGISTERED = "node_registered"
    NODE_UNHEALTHY = "node_unhealthy"
    NODE_REMOVED = "node_removed"
    NODE_UPDATED = "node_updated"
    ACHIEVEMENT_UNLOCKED = "achievement_unlocked"


class Difficulty(str, Enum):
    """Upstream challenges slim v3 schema — difficulty is a 3-valued enum."""

    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"


# Sort rank: easy < medium < hard. Used for stable ordering in listings.
DIFFICULTY_RANK: dict[str, int] = {
    Difficulty.EASY: 1,
    Difficulty.MEDIUM: 2,
    Difficulty.HARD: 3,
}
