"""Flag generation and verification — single source of truth.

The platform is the canonical holder of every instance's flags (step 18 of
the architecture). Generation and constant-time comparison both live here
so routes that touch flags import from one place and the node never sees
the plaintext flag values.

A challenge can declare multiple named flags (e.g. ``foothold`` / ``root``);
the platform mints one independent random value per declared id.
"""

from __future__ import annotations

import hmac
import re
import secrets
from collections.abc import Iterable

from ctfy.core.exceptions import FlagNotFoundError, InstanceNotFoundError
from ctfy.core.state import StateBackend

__all__ = ["generate_flag", "generate_flags", "verify_flag"]

_FLAG_WRAPPER_RE = re.compile(r"FLAG\{(.+)\}")


def generate_flag() -> str:
    """Generate a random platform flag in the canonical ``FLAG{...}`` format."""
    return f"FLAG{{{secrets.token_hex(32)}}}"


def generate_flags(flag_ids: Iterable[str]) -> dict[str, str]:
    """Mint one independent random flag per declared id.

    Each value is a fresh ``FLAG{...}`` token — values are never reused
    across ids so leaking one flag does not expose the others.
    """
    return {fid: generate_flag() for fid in flag_ids}


def verify_flag(
    state_backend: StateBackend,
    instance_id: str,
    claimed_flag: str,
) -> str | None:
    """Return the flag_id whose stored value matches *claimed_flag*, else None.

    Uses :func:`hmac.compare_digest` for timing safety. Tolerates an
    ``FLAG{...}`` wrapper on the claimed side so a user pasting the full
    token still matches. Compares against every stored flag so any flag id
    can be submitted in any order.
    """
    inst = state_backend.get_instance(instance_id)
    if not inst:
        raise InstanceNotFoundError(instance_id)
    if not inst.flags:
        raise FlagNotFoundError(instance_id)
    m = _FLAG_WRAPPER_RE.fullmatch(claimed_flag)
    unwrapped = m.group(1) if m else None
    for fid, actual in inst.flags.items():
        if hmac.compare_digest(actual, claimed_flag):
            return fid
        if unwrapped is not None and hmac.compare_digest(actual, unwrapped):
            return fid
    return None
