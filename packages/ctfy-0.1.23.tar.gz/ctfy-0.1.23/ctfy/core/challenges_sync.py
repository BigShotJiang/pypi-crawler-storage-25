"""Keep ``challenges_dir`` in sync with a remote challenges git repo.

The challenge library is large (thousands of directories) and lives in its
own repository. On first startup the server / node clones it into
``challenges_dir``; on subsequent runs we attempt a fast-forward pull so
nodes stay current without manual intervention. Failures are logged and
downgraded to warnings — we never block server boot because a mirror is
slow or offline.
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from ctfy.core.log import log


def ensure_challenges(challenges_dir: Path, repo_url: str) -> None:
    """Clone ``repo_url`` into ``challenges_dir`` on first run, else ff-pull.

    * Empty ``repo_url`` → no-op (operator opted out).
    * ``challenges_dir`` missing → ``git clone``.
    * ``challenges_dir`` exists but is not a git worktree → treat as a
      pinned / manually-managed copy and leave alone.
    * ``challenges_dir`` is a clean git worktree → ``git pull --ff-only``.
    * Worktree is dirty (uncommitted changes) → log + skip. Never clobber
      operator edits.
    """
    if not repo_url:
        return
    if shutil.which("git") is None:
        log.warning(
            "git executable not found; skipping challenges auto-sync",
            repo=repo_url,
            path=str(challenges_dir),
        )
        return

    if not challenges_dir.exists():
        _clone(repo_url, challenges_dir)
        return

    if not (challenges_dir / ".git").exists():
        log.info(
            "Challenges directory is not a git worktree; leaving it untouched",
            path=str(challenges_dir),
        )
        return

    if _is_dirty(challenges_dir):
        log.warning(
            "Challenges worktree has uncommitted changes; skipping pull",
            path=str(challenges_dir),
        )
        return

    _pull(challenges_dir)


def _clone(repo_url: str, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    log.info("Cloning challenges", repo=repo_url, path=str(dest))
    result = subprocess.run(
        ["git", "clone", "--depth", "1", repo_url, str(dest)],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        log.error(
            "git clone failed; start will continue but challenges list will be empty",
            repo=repo_url,
            path=str(dest),
            stderr=result.stderr.strip()[-500:],
        )


def _is_dirty(worktree: Path) -> bool:
    result = subprocess.run(
        ["git", "-C", str(worktree), "status", "--porcelain"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        return True
    return bool(result.stdout.strip())


def _pull(worktree: Path) -> None:
    log.info("Fast-forward pulling challenges", path=str(worktree))
    result = subprocess.run(
        ["git", "-C", str(worktree), "pull", "--ff-only"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        log.warning(
            "git pull --ff-only failed; continuing with on-disk state",
            path=str(worktree),
            stderr=result.stderr.strip()[-500:],
        )
