"""StateBackend Protocol — contract for instance / node / placement state storage."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from ctfy.core.state.models import (
    AchievementRecord,
    ActivityState,
    InstanceRecord,
    InstanceState,
    NodeHealthSample,
    NodeInviteState,
    NodeState,
    ScoreboardSnapshotState,
    SolveState,
    SubmissionState,
    TeamState,
)


@runtime_checkable
class StateBackend(Protocol):
    """Contract for instance / node / placement state storage."""

    # -- instance state -----------------------------------------------------

    def put_instance(self, instance_id: str, data: InstanceState, ttl: int = 0) -> None: ...
    def get_instance(self, instance_id: str) -> InstanceState | None: ...
    def remove_instance(self, instance_id: str) -> InstanceState | None: ...
    def list_instances(self) -> list[InstanceState]: ...
    def count_instances(self) -> int: ...
    def renew_instance(self, instance_id: str, ttl: int) -> float: ...
    def get_instance_by_team_challenge(
        self, team_id: str, challenge_id: str
    ) -> InstanceState | None: ...

    # -- expired instance iteration (for reaper) ---------------------------

    def pop_expired_instances(self) -> list[InstanceState]: ...

    # -- archived instance records (permanent history) ----------------------

    def archive_instance(self, record: InstanceRecord) -> None: ...
    def get_instance_record(self, instance_id: str) -> InstanceRecord | None: ...
    def list_instance_records(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        node_id: str = "",
        status: str = "",
        since_ts: float = 0.0,
        offset: int = 0,
        limit: int = 100,
    ) -> list[InstanceRecord]: ...
    def count_instance_records(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        node_id: str = "",
        status: str = "",
        since_ts: float = 0.0,
    ) -> int: ...

    # -- config (key-value) --------------------------------------------------

    def get_config(self, key: str) -> str | None: ...
    def set_config(self, key: str, value: str) -> None: ...

    # -- nodes (worker registration + heartbeat) -----------------------------

    def put_node(self, node_id: str, data: NodeState) -> None: ...
    def get_node(self, node_id: str) -> NodeState | None: ...
    def get_node_by_token(self, token: str) -> NodeState | None: ...
    def list_nodes(self) -> list[NodeState]: ...
    def remove_node(self, node_id: str) -> None: ...

    # -- node health history (bounded ring per node) ------------------------

    def append_health_sample(self, sample: NodeHealthSample) -> None: ...
    def list_health_samples(self, node_id: str, limit: int = 200) -> list[NodeHealthSample]: ...

    # -- node invites (one-time registration credentials) --------------------

    def put_invite(self, invite: NodeInviteState) -> None: ...
    def get_invite(self, invite_id: str) -> NodeInviteState | None: ...
    def get_invite_by_hash(self, token_hash: str) -> NodeInviteState | None: ...
    def list_invites(self) -> list[NodeInviteState]: ...
    def consume_invite(self, token_hash: str, node_id: str) -> NodeInviteState | None: ...
    def remove_invite(self, invite_id: str) -> None: ...

    # -- teams ---------------------------------------------------------------

    def put_team(self, team_id: str, data: TeamState) -> None: ...
    def get_team(self, team_id: str) -> TeamState | None: ...
    def get_team_by_token(self, token: str) -> TeamState | None: ...
    def list_teams(self) -> list[TeamState]: ...

    # -- submissions ---------------------------------------------------------

    def add_submission(self, data: SubmissionState) -> None: ...
    def list_submissions(
        self, team_id: str = "", challenge_id: str = ""
    ) -> list[SubmissionState]: ...

    # -- solves --------------------------------------------------------------
    #
    # Solves are tracked per (team, challenge, flag_id). Single-flag
    # challenges use flag_id="main". ``count_solves_for_challenge`` returns
    # the number of *teams* that have fully solved the challenge (captured
    # every declared flag); ``count_solves_for_flag`` returns teams who
    # captured a specific flag. For a single-flag challenge both functions
    # return the same value.

    def add_solve(
        self, team_id: str, challenge_id: str, flag_id: str, data: SolveState
    ) -> None: ...
    def get_solve(
        self, team_id: str, challenge_id: str, flag_id: str
    ) -> SolveState | None: ...
    def list_solves(self, team_id: str = "") -> list[SolveState]: ...
    def count_solves_for_flag(self, challenge_id: str, flag_id: str) -> int: ...
    def count_solves_for_challenge(
        self, challenge_id: str, flag_ids: tuple[str, ...] = ()
    ) -> int: ...

    # -- activity log --------------------------------------------------------

    def add_activity(self, data: ActivityState) -> None: ...
    def list_activities(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        events: tuple[str, ...] = (),
        actor_id: str = "",
        offset: int = 0,
        limit: int = 100,
    ) -> list[ActivityState]: ...
    def count_activities(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        events: tuple[str, ...] = (),
        actor_id: str = "",
    ) -> int: ...

    # -- scoreboard snapshots ------------------------------------------------
    #
    # Snapshots are append-only and kept permanently so post-competition
    # reviews always have the full rank-over-time curve. No prune.

    def append_snapshot_batch(self, snapshots: list[ScoreboardSnapshotState]) -> None: ...
    def list_snapshots(
        self,
        *,
        team_id: str = "",
        since_ts: float = 0.0,
        limit: int = 0,
    ) -> list[ScoreboardSnapshotState]: ...

    # -- achievements --------------------------------------------------------
    #
    # Grant is idempotent on (team_id, achievement_id); a second call returns
    # None so evaluators can use the return value to tell "true unlock" from
    # "already had it" and only emit the ACHIEVEMENT_UNLOCKED event once.
    # Counters are a cheap aggregate store for predicates that don't want to
    # replay the submissions table (e.g. Sisyphus: wrong-attempts-on-same-
    # challenge-before-solve).

    def list_achievements(self, team_id: str) -> list[AchievementRecord]: ...
    def has_achievement(self, team_id: str, achievement_id: str) -> bool: ...
    def grant_achievement(
        self,
        team_id: str,
        achievement_id: str,
        context: dict | None = None,
    ) -> AchievementRecord | None: ...
    def revoke_achievement(self, team_id: str, achievement_id: str) -> bool: ...
    def bump_counter(self, team_id: str, key: str, delta: int = 1) -> int: ...
    def get_counter(self, team_id: str, key: str) -> int: ...
    def reset_counter(self, team_id: str, key: str) -> None: ...
