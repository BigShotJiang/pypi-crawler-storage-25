"""InMemoryBackend — thread-safe in-memory state backend."""

from __future__ import annotations

import threading
import time
from datetime import datetime, timezone

from ctfy.core.enums import InstanceStatus
from ctfy.core.state.filters import match_activity, match_submission
from ctfy.core.state.models import (
    AchievementRecord,
    ActivityState,
    InstanceRecord,
    InstanceState,
    NodeHealthSample,
    NodeInviteState,
    NodeState,
    ScoreboardSnapshotState,
    SolveState,
    SubmissionState,
    TeamState,
)

# Upper bound on samples kept per node. Matches the SQLite backend so
# both implementations behave identically and the frontend's strip
# length is stable. Bumping → widen both.
HEALTH_SAMPLE_RING_SIZE = 200


class InMemoryBackend:
    """Thread-safe in-memory backend. Suitable for single-process use."""

    def __init__(self) -> None:
        self._instances: dict[str, InstanceState] = {}
        self._nodes: dict[str, NodeState] = {}
        self._invites: dict[str, NodeInviteState] = {}
        # Bounded deque per node — O(1) append + head-trim.
        self._health_samples: dict[str, list[NodeHealthSample]] = {}
        self._teams: dict[str, TeamState] = {}
        self._team_tokens: dict[str, str] = {}
        self._submissions: list[SubmissionState] = []
        self._solves: dict[tuple[str, str, str], SolveState] = {}
        self._activities: list[ActivityState] = []
        self._instance_records: dict[str, InstanceRecord] = {}
        self._snapshots: list[ScoreboardSnapshotState] = []
        self._config: dict[str, str] = {}
        # Achievements: (team_id, achievement_id) -> record.
        self._achievements: dict[tuple[str, str], AchievementRecord] = {}
        # Cheap running counters for rule predicates (e.g. wrong-streaks).
        self._counters: dict[tuple[str, str], int] = {}
        self._lock = threading.Lock()

    # -- instance -----------------------------------------------------------

    def put_instance(self, instance_id: str, data: InstanceState, ttl: int = 0) -> None:
        now = time.time()
        status = data.status
        if status == InstanceStatus.READY:
            started_at = now
            expires_at = (now + ttl) if ttl > 0 else 0.0
        elif status == InstanceStatus.STARTING:
            started_at = 0.0
            expires_at = 0.0
        else:
            started_at = data.started_at
            expires_at = data.expires_at
        data = data.model_copy(
            update={"started_at": started_at, "ttl": ttl, "expires_at": expires_at}
        )
        with self._lock:
            self._instances[instance_id] = data

    def get_instance(self, instance_id: str) -> InstanceState | None:
        with self._lock:
            inst = self._instances.get(instance_id)
            return inst.model_copy() if inst is not None else None

    def remove_instance(self, instance_id: str) -> InstanceState | None:
        with self._lock:
            return self._instances.pop(instance_id, None)

    def list_instances(self) -> list[InstanceState]:
        with self._lock:
            return [v.model_copy(update={"instance_id": k}) for k, v in self._instances.items()]

    def count_instances(self) -> int:
        with self._lock:
            return len(self._instances)

    def renew_instance(self, instance_id: str, ttl: int) -> float:
        now = time.time()
        expires_at = (now + ttl) if ttl > 0 else 0.0
        with self._lock:
            inst = self._instances.get(instance_id)
            if inst is None:
                raise KeyError(instance_id)
            self._instances[instance_id] = inst.model_copy(
                update={"ttl": ttl, "expires_at": expires_at}
            )
        return expires_at

    def pop_expired_instances(self) -> list[InstanceState]:
        now = time.time()
        expired = []
        with self._lock:
            for sid in list(self._instances):
                inst = self._instances[sid]
                if inst.expires_at and now >= inst.expires_at:
                    expired.append(self._instances.pop(sid).model_copy(update={"instance_id": sid}))
        return expired

    def get_instance_by_team_challenge(
        self, team_id: str, challenge_id: str
    ) -> InstanceState | None:
        with self._lock:
            for instance_id, inst in self._instances.items():
                if inst.team_id == team_id and inst.challenge_id == challenge_id:
                    return inst.model_copy(update={"instance_id": instance_id})
        return None

    # -- archived instance records ------------------------------------------

    def archive_instance(self, record: InstanceRecord) -> None:
        with self._lock:
            # INSERT OR REPLACE semantics — mirror the SQLite backend.
            self._instance_records[record.instance_id] = record.model_copy()

    def get_instance_record(self, instance_id: str) -> InstanceRecord | None:
        with self._lock:
            rec = self._instance_records.get(instance_id)
            return rec.model_copy() if rec is not None else None

    def _filter_records(
        self,
        *,
        team_id: str,
        challenge_id: str,
        node_id: str,
        status: str,
        since_ts: float,
    ) -> list[InstanceRecord]:
        rows = sorted(
            self._instance_records.values(),
            key=lambda r: r.started_at,
            reverse=True,
        )
        return [
            r
            for r in rows
            if (not team_id or r.team_id == team_id)
            and (not challenge_id or r.challenge_id == challenge_id)
            and (not node_id or r.node_id == node_id)
            and (not status or r.status == status)
            and (since_ts <= 0 or r.started_at >= since_ts)
        ]

    def list_instance_records(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        node_id: str = "",
        status: str = "",
        since_ts: float = 0.0,
        offset: int = 0,
        limit: int = 100,
    ) -> list[InstanceRecord]:
        with self._lock:
            filtered = self._filter_records(
                team_id=team_id,
                challenge_id=challenge_id,
                node_id=node_id,
                status=status,
                since_ts=since_ts,
            )
            return [r.model_copy() for r in filtered[offset : offset + limit]]

    def count_instance_records(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        node_id: str = "",
        status: str = "",
        since_ts: float = 0.0,
    ) -> int:
        with self._lock:
            return len(
                self._filter_records(
                    team_id=team_id,
                    challenge_id=challenge_id,
                    node_id=node_id,
                    status=status,
                    since_ts=since_ts,
                )
            )

    # -- config --------------------------------------------------------------

    def get_config(self, key: str) -> str | None:
        with self._lock:
            return self._config.get(key)

    def set_config(self, key: str, value: str) -> None:
        with self._lock:
            self._config[key] = value

    # -- nodes ---------------------------------------------------------------

    def put_node(self, node_id: str, data: NodeState) -> None:
        with self._lock:
            self._nodes[node_id] = data.model_copy(update={"node_id": node_id})

    def get_node(self, node_id: str) -> NodeState | None:
        with self._lock:
            node = self._nodes.get(node_id)
            return node.model_copy() if node is not None else None

    def get_node_by_token(self, token: str) -> NodeState | None:
        if not token:
            return None
        import hmac as _hmac

        with self._lock:
            for node in self._nodes.values():
                if node.token and _hmac.compare_digest(token, node.token):
                    return node.model_copy()
            return None

    def list_nodes(self) -> list[NodeState]:
        with self._lock:
            return [v.model_copy() for v in self._nodes.values()]

    def remove_node(self, node_id: str) -> None:
        with self._lock:
            self._nodes.pop(node_id, None)
            self._health_samples.pop(node_id, None)

    # -- node health history ------------------------------------------------

    def append_health_sample(self, sample: NodeHealthSample) -> None:
        with self._lock:
            ring = self._health_samples.setdefault(sample.node_id, [])
            ring.append(sample.model_copy())
            if len(ring) > HEALTH_SAMPLE_RING_SIZE:
                # Drop the oldest entries in bulk so we don't repeatedly
                # slice on every append in steady state.
                del ring[: len(ring) - HEALTH_SAMPLE_RING_SIZE]

    def list_health_samples(
        self, node_id: str, limit: int = HEALTH_SAMPLE_RING_SIZE
    ) -> list[NodeHealthSample]:
        with self._lock:
            ring = self._health_samples.get(node_id, [])
            # Return a copy so callers can't mutate our ring.
            return [s.model_copy() for s in ring[-limit:]]

    # -- node invites --------------------------------------------------------

    def put_invite(self, invite: NodeInviteState) -> None:
        with self._lock:
            self._invites[invite.invite_id] = invite.model_copy()

    def get_invite(self, invite_id: str) -> NodeInviteState | None:
        with self._lock:
            inv = self._invites.get(invite_id)
            return inv.model_copy() if inv is not None else None

    def get_invite_by_hash(self, token_hash: str) -> NodeInviteState | None:
        if not token_hash:
            return None
        with self._lock:
            for inv in self._invites.values():
                if inv.token_hash == token_hash:
                    return inv.model_copy()
            return None

    def list_invites(self) -> list[NodeInviteState]:
        with self._lock:
            return [inv.model_copy() for inv in self._invites.values()]

    def consume_invite(self, token_hash: str, node_id: str) -> NodeInviteState | None:
        if not token_hash:
            return None
        with self._lock:
            for invite_id, inv in self._invites.items():
                if inv.token_hash != token_hash:
                    continue
                if inv.consumed_at_ts > 0:
                    return None
                updated = inv.model_copy(
                    update={
                        "consumed_at_ts": time.time(),
                        "consumed_by_node_id": node_id,
                    }
                )
                self._invites[invite_id] = updated
                return updated.model_copy()
            return None

    def remove_invite(self, invite_id: str) -> None:
        with self._lock:
            self._invites.pop(invite_id, None)

    # -- teams ---------------------------------------------------------------

    def put_team(self, team_id: str, data: TeamState) -> None:
        with self._lock:
            data = data.model_copy(update={"team_id": team_id})
            self._teams[team_id] = data
            if data.token:
                self._team_tokens[data.token] = team_id

    def get_team(self, team_id: str) -> TeamState | None:
        with self._lock:
            team = self._teams.get(team_id)
            return team.model_copy() if team is not None else None

    def get_team_by_token(self, token: str) -> TeamState | None:
        with self._lock:
            team_id = self._team_tokens.get(token)
            if team_id:
                team = self._teams.get(team_id)
                return team.model_copy() if team is not None else None
            return None

    def list_teams(self) -> list[TeamState]:
        with self._lock:
            return [v.model_copy() for v in self._teams.values()]

    # -- submissions ---------------------------------------------------------

    def add_submission(self, data: SubmissionState) -> None:
        with self._lock:
            self._submissions.append(data)

    def list_submissions(self, team_id: str = "", challenge_id: str = "") -> list[SubmissionState]:
        with self._lock:
            return [
                s.model_copy()
                for s in self._submissions
                if match_submission(s, team_id=team_id, challenge_id=challenge_id)
            ]

    # -- solves --------------------------------------------------------------

    def add_solve(
        self, team_id: str, challenge_id: str, flag_id: str, data: SolveState
    ) -> None:
        key = (team_id, challenge_id, flag_id)
        with self._lock:
            if key not in self._solves:
                self._solves[key] = data.model_copy(
                    update={
                        "team_id": team_id,
                        "challenge_id": challenge_id,
                        "flag_id": flag_id,
                    }
                )

    def get_solve(
        self, team_id: str, challenge_id: str, flag_id: str
    ) -> SolveState | None:
        with self._lock:
            solve = self._solves.get((team_id, challenge_id, flag_id))
            return solve.model_copy() if solve is not None else None

    def list_solves(self, team_id: str = "") -> list[SolveState]:
        with self._lock:
            if team_id:
                return [v.model_copy() for k, v in self._solves.items() if k[0] == team_id]
            return [v.model_copy() for v in self._solves.values()]

    def count_solves_for_flag(self, challenge_id: str, flag_id: str) -> int:
        with self._lock:
            return sum(
                1 for k in self._solves if k[1] == challenge_id and k[2] == flag_id
            )

    def count_solves_for_challenge(
        self, challenge_id: str, flag_ids: tuple[str, ...] = ()
    ) -> int:
        """Teams who have captured *every* declared flag on the challenge.

        ``flag_ids`` is the challenge's full flag id set. If empty the count
        is zero (caller didn't pass the challenge spec, so "fully solved"
        is undefined). Single-flag challenges pass ``("main",)`` and this
        matches the old single-flag semantics.
        """
        if not flag_ids:
            return 0
        required = set(flag_ids)
        with self._lock:
            by_team: dict[str, set[str]] = {}
            for (team_id, cid, fid) in self._solves:
                if cid != challenge_id:
                    continue
                by_team.setdefault(team_id, set()).add(fid)
        return sum(1 for solved in by_team.values() if required <= solved)

    # -- activity log -------------------------------------------------------

    def add_activity(self, data: ActivityState) -> None:
        with self._lock:
            self._activities.append(data)

    def _filter_activities(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        events: tuple[str, ...] = (),
        actor_id: str = "",
    ) -> list[ActivityState]:
        return [
            a
            for a in reversed(self._activities)
            if match_activity(
                a,
                team_id=team_id,
                challenge_id=challenge_id,
                event=event,
                events=events,
                actor_id=actor_id,
            )
        ]

    def list_activities(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        events: tuple[str, ...] = (),
        actor_id: str = "",
        offset: int = 0,
        limit: int = 100,
    ) -> list[ActivityState]:
        with self._lock:
            filtered = self._filter_activities(
                team_id=team_id,
                challenge_id=challenge_id,
                event=event,
                events=events,
                actor_id=actor_id,
            )
            return filtered[offset : offset + limit]

    def count_activities(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        events: tuple[str, ...] = (),
        actor_id: str = "",
    ) -> int:
        with self._lock:
            return len(
                self._filter_activities(
                    team_id=team_id,
                    challenge_id=challenge_id,
                    event=event,
                    events=events,
                    actor_id=actor_id,
                )
            )

    # -- scoreboard snapshots -----------------------------------------------

    def append_snapshot_batch(self, snapshots: list[ScoreboardSnapshotState]) -> None:
        if not snapshots:
            return
        with self._lock:
            self._snapshots.extend(snapshots)

    def list_snapshots(
        self,
        *,
        team_id: str = "",
        since_ts: float = 0.0,
        limit: int = 0,
    ) -> list[ScoreboardSnapshotState]:
        with self._lock:
            # Ascending by timestamp so charts can render left-to-right.
            rows = sorted(self._snapshots, key=lambda s: s.snapshot_at_ts)
        filtered = [
            s
            for s in rows
            if (not team_id or s.team_id == team_id) and s.snapshot_at_ts >= since_ts
        ]
        if limit > 0:
            return filtered[-limit:]
        return filtered

    # -- achievements --------------------------------------------------------

    def list_achievements(self, team_id: str) -> list[AchievementRecord]:
        with self._lock:
            return [r.model_copy() for (tid, _), r in self._achievements.items() if tid == team_id]

    def has_achievement(self, team_id: str, achievement_id: str) -> bool:
        with self._lock:
            return (team_id, achievement_id) in self._achievements

    def grant_achievement(
        self,
        team_id: str,
        achievement_id: str,
        context: dict | None = None,
    ) -> AchievementRecord | None:
        key = (team_id, achievement_id)
        with self._lock:
            if key in self._achievements:
                return None
            record = AchievementRecord(
                team_id=team_id,
                achievement_id=achievement_id,
                unlocked_at=datetime.now(timezone.utc).isoformat(),
                context=dict(context or {}),
            )
            self._achievements[key] = record
            return record.model_copy()

    def revoke_achievement(self, team_id: str, achievement_id: str) -> bool:
        with self._lock:
            return self._achievements.pop((team_id, achievement_id), None) is not None

    def bump_counter(self, team_id: str, key: str, delta: int = 1) -> int:
        with self._lock:
            new_value = self._counters.get((team_id, key), 0) + delta
            self._counters[(team_id, key)] = new_value
            return new_value

    def get_counter(self, team_id: str, key: str) -> int:
        with self._lock:
            return self._counters.get((team_id, key), 0)

    def reset_counter(self, team_id: str, key: str) -> None:
        with self._lock:
            self._counters.pop((team_id, key), None)
