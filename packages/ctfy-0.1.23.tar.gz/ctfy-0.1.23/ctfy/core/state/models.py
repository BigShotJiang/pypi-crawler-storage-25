"""Typed state models — replace raw dicts in state backends."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import Field

from ctfy.core.activity import ActivityDetail
from ctfy.core.enums import InstanceStatus
from ctfy.core.models import CtfyModel
from ctfy.core.target import AttackSurface

# Who triggered an activity event. "team" / "node" cover authenticated
# caller identities; "admin" covers admin-token-authenticated writes;
# "system" covers background loops (reaper / reconciler / health check).
ActorType = Literal["team", "node", "admin", "system"]


class TeamState(CtfyModel):
    team_id: str
    name: str = ""
    agent: str = ""
    description: str = ""
    token: str = ""  # SHA-256 hash of the plaintext bearer token
    created_at: str = ""


class SolveState(CtfyModel):
    team_id: str = ""
    challenge_id: str = ""
    # Which flag on the challenge was solved. For challenges with a single
    # flag this is ``"main"``. Composite uniqueness on
    # (team_id, challenge_id, flag_id).
    flag_id: str = ""
    solved_at: str = ""
    solve_time_s: float = 0.0
    attempts: int = 0


class ActivityState(CtfyModel):
    id: str = ""
    timestamp: str = ""
    event: str = ""
    team_id: str = ""
    team_name: str = ""
    challenge_id: str = ""
    # Who triggered this event — non-optional since every emit site has to
    # supply actor context. Auditors + admin filter on actor_id.
    actor_id: str
    actor_name: str
    actor_type: ActorType
    detail: ActivityDetail = Field(default_factory=ActivityDetail)


class NodeState(CtfyModel):
    node_id: str = ""
    url: str = ""
    # Human-readable label used in admin UI. Operators set it on register
    # or via PATCH — existing nodes get a one-time backfill to node_id in
    # the sqlite migration path.
    display_name: str = ""
    capacity: int = 0
    running: int = 0
    healthy: bool = True
    last_heartbeat: str = ""
    last_heartbeat_ts: float = 0.0
    labels: dict[str, str] = Field(default_factory=dict)
    # Resource utilisation, 0–100. Updated on every heartbeat; the node
    # samples via psutil before posting. "Disk" is the filesystem that
    # holds the node's data dir.
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    disk_percent: float = 0.0
    # Per-node bearer token, plaintext. Used both ways:
    #  * node→platform (heartbeat, deregister) — node sets it as Bearer,
    #    platform looks the row up by comparing plaintexts.
    #  * platform→node (start/stop/status) — platform presents this plaintext
    #    on every outbound call, node verifies against its in-memory copy.
    # Minted fresh on every register; rotation = re-register. The column
    # is never returned by ``GET /nodes`` or any other read path.
    token: str = ""


class NodeHealthSample(CtfyModel):
    """One heartbeat-tick worth of node health + utilisation.

    The state backend keeps a bounded ring of the most recent samples per
    node so the admin UI can render uptime-kuma-style strips without
    storing unbounded time series. Appended on every heartbeat and
    whenever the health-check loop marks a node unhealthy; no separate
    reaper needed.
    """

    node_id: str = ""
    ts: float = 0.0  # Unix seconds, platform's wall clock when the sample landed
    healthy: bool = True
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    disk_percent: float = 0.0


class ScoreboardSnapshotState(CtfyModel):
    """One row of a periodic scoreboard snapshot.

    Taken every few minutes by a background loop so the scoreboard
    history chart can render "rank over time" without replaying the
    full activity log. Stored in a dedicated table (sqlite) or list
    (in-memory); pruned on a rolling window to keep the set bounded.
    """

    snapshot_at: str = ""  # ISO timestamp for display
    snapshot_at_ts: float = 0.0  # Unix seconds, used for filters + indexing
    team_id: str = ""
    team_name: str = ""
    rank: int = 0
    solved: int = 0
    attempts: int = 0


class NodeInviteState(CtfyModel):
    """One-time registration credential issued by an admin.

    Mirrors the GitHub Actions runner / Cloudflare Tunnel model: admin
    creates an invite → gets a plaintext token once → node presents it
    to ``POST /nodes/register`` → platform consumes it atomically and
    mints long-lived per-node credentials.
    """

    invite_id: str = ""  # short random id; used in GET/DELETE paths
    token_hash: str = ""  # SHA-256 of the plaintext; plaintext is never stored
    created_at: str = ""
    created_at_ts: float = 0.0
    expires_at_ts: float = 0.0
    # 0.0 while active; set to the consume wall clock once spent.
    consumed_at_ts: float = 0.0
    # Set alongside consumed_at_ts for audit: which node_id spent this invite.
    consumed_by_node_id: str = ""


class SubmissionState(CtfyModel):
    submission_id: str = ""
    team_id: str = ""
    challenge_id: str = ""
    claimed_flag: str = ""
    correct: bool = False
    # Which flag_id the submission matched, if any. Empty string on wrong
    # submissions. On multi-flag challenges this disambiguates which flag
    # was hit.
    flag_id: str = ""
    submitted_at: str = ""
    solve_time_s: float = 0.0


class AchievementRecord(CtfyModel):
    """One unlocked achievement for a team.

    Rows are idempotent on ``(team_id, achievement_id)`` — calling
    ``grant_achievement`` twice is a no-op. The ``context`` blob captures
    whatever the rule thought worth remembering (challenge_id that
    triggered it, solve_time_s, etc.) — it's free-form because rule
    authors know best.
    """

    team_id: str = ""
    achievement_id: str = ""
    unlocked_at: str = ""
    context: dict[str, Any] = Field(default_factory=dict)


class InstanceState(CtfyModel):
    instance_id: str = ""
    spec: dict[str, Any] = Field(default_factory=dict)
    challenge_id: str = ""
    status: str = InstanceStatus.STARTING
    team_id: str = ""
    node_id: str = ""
    surface: AttackSurface | None = None
    # Flags are generated by the platform on POST /instances and injected
    # into the node's container as $FLAG_<UPPER_ID> env vars (one per
    # declared flag_id; single-flag challenges get ``$FLAG_MAIN``). The
    # node does not persist them; the platform keeps the canonical copies
    # here for constant-time verification on /submissions (step 18).
    flags: dict[str, str] = Field(default_factory=dict)
    error: str = ""
    name: str = ""
    category: str = ""
    difficulty: str = ""
    started_at: float = 0.0
    ttl: int = 0
    expires_at: float = 0.0


class InstanceRecord(CtfyModel):
    """Archival row for a completed or failed instance.

    Written at every terminal path (user-initiated DELETE, TTL reaper,
    admin stop-all, health-check failure, reconcile error, auto-stop after
    a successful solve) so the benchmark retains a permanent, queryable
    record of every instance that has ever run — even after the live
    ``InstanceState`` is evicted from the in-memory dict.
    """

    instance_id: str = ""
    challenge_id: str = ""
    team_id: str = ""
    node_id: str = ""
    name: str = ""
    category: str = ""
    difficulty: str = ""
    # Final status (e.g. STOPPED / ERROR) — the value the instance held when
    # it left the live path. Not a time series; event history lives in the
    # per-instance ``events.jsonl`` file.
    status: str = ""
    # Why the instance ended: "user", "auto_stop_after_solve",
    # "admin_stop_all", "ttl_expired", "node_unhealthy", "error".
    stop_reason: str = ""
    surface: AttackSurface | None = None
    spec: dict[str, Any] = Field(default_factory=dict)
    error: str = ""
    started_at: float = 0.0
    stopped_at: float = 0.0
    duration_s: float = 0.0
    ttl: int = 0
    # Denormalized solve outcome for fast filtering — avoids a join to the
    # solves table. Populated when the archive hook runs; best-effort.
    # ``solved`` here means "every flag on the challenge was captured" so
    # archival "fully solved" queries remain a simple boolean filter.
    solved: bool = False
    # Per-flag solve record — which flag ids this team had captured at
    # archive time. Empty for unsolved instances. Preserved so historical
    # instance records show partial progress even after the live
    # InstanceState is evicted.
    solved_flags: list[str] = Field(default_factory=list)
    attempts: int = 0
    # Absolute path to the per-instance artifact directory. Empty when the
    # archive sink was disabled (e.g. tests).
    artifact_dir: str = ""
