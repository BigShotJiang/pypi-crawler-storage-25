"""SQLiteBackend — SQLite-backed state backend."""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from datetime import datetime, timezone

from ctfy.core.state.models import (
    AchievementRecord,
    ActivityState,
    InstanceRecord,
    InstanceState,
    NodeHealthSample,
    NodeInviteState,
    NodeState,
    ScoreboardSnapshotState,
    SolveState,
    SubmissionState,
    TeamState,
)

# Upper bound on health samples kept per node. Shared with the in-memory
# backend via ``HEALTH_SAMPLE_RING_SIZE`` in memory.py — bump both.
HEALTH_SAMPLE_RING_SIZE = 200


class SQLiteBackend:
    """SQLite-backed state. Persistent across restarts.

    Instances (ephemeral) are kept in memory. Everything else
    (teams, submissions, solves, activities) is stored in SQLite.
    """

    def __init__(self, db_path: str) -> None:
        self._db_path = db_path
        # sqlite3.Connection is not thread-safe for concurrent cursor use.
        # Give each thread its own connection (WAL lets readers run in
        # parallel; the SQLite file itself serializes writers).
        self._local = threading.local()
        self._instance_lock = threading.Lock()
        self._instances: dict[str, InstanceState] = {}
        self._init_tables()
        self._migrate()

    @property
    def _conn(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self._db_path)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA foreign_keys=ON")
            conn.execute("PRAGMA busy_timeout=5000")
            self._local.conn = conn
        return conn

    def _init_tables(self) -> None:
        with self._conn:
            self._conn.executescript("""
                CREATE TABLE IF NOT EXISTS config (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS nodes (
                    node_id TEXT PRIMARY KEY,
                    data TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS node_invites (
                    invite_id TEXT PRIMARY KEY,
                    token_hash TEXT NOT NULL,
                    data TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_invite_hash
                    ON node_invites(token_hash);
                CREATE TABLE IF NOT EXISTS node_health_samples (
                    node_id TEXT NOT NULL,
                    ts REAL NOT NULL,
                    data TEXT NOT NULL,
                    PRIMARY KEY (node_id, ts)
                );
                CREATE INDEX IF NOT EXISTS idx_health_node_ts
                    ON node_health_samples(node_id, ts DESC);
                CREATE TABLE IF NOT EXISTS teams (
                    team_id TEXT PRIMARY KEY,
                    token TEXT NOT NULL DEFAULT '',
                    data TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS submissions (
                    submission_id TEXT PRIMARY KEY,
                    team_id TEXT NOT NULL,
                    challenge_id TEXT NOT NULL,
                    data TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_sub_team
                    ON submissions(team_id);
                CREATE INDEX IF NOT EXISTS idx_sub_challenge
                    ON submissions(challenge_id);
                CREATE TABLE IF NOT EXISTS solves (
                    team_id TEXT NOT NULL,
                    challenge_id TEXT NOT NULL,
                    flag_id TEXT NOT NULL DEFAULT 'main',
                    data TEXT NOT NULL,
                    PRIMARY KEY (team_id, challenge_id, flag_id)
                );
                CREATE INDEX IF NOT EXISTS idx_solves_challenge_flag
                    ON solves(challenge_id, flag_id);
                CREATE TABLE IF NOT EXISTS activities (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    event TEXT NOT NULL,
                    team_id TEXT NOT NULL DEFAULT '',
                    challenge_id TEXT NOT NULL DEFAULT '',
                    actor_id TEXT NOT NULL DEFAULT '',
                    actor_name TEXT NOT NULL DEFAULT '',
                    actor_type TEXT NOT NULL DEFAULT '',
                    data TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_act_team
                    ON activities(team_id);
                CREATE INDEX IF NOT EXISTS idx_act_event
                    ON activities(event);
                CREATE INDEX IF NOT EXISTS idx_act_actor
                    ON activities(actor_id);
                CREATE TABLE IF NOT EXISTS instance_records (
                    instance_id TEXT PRIMARY KEY,
                    team_id TEXT NOT NULL DEFAULT '',
                    challenge_id TEXT NOT NULL DEFAULT '',
                    node_id TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT '',
                    started_at REAL NOT NULL DEFAULT 0,
                    stopped_at REAL NOT NULL DEFAULT 0,
                    data TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_ir_team
                    ON instance_records(team_id);
                CREATE INDEX IF NOT EXISTS idx_ir_challenge
                    ON instance_records(challenge_id);
                CREATE INDEX IF NOT EXISTS idx_ir_node
                    ON instance_records(node_id);
                CREATE INDEX IF NOT EXISTS idx_ir_started
                    ON instance_records(started_at DESC);
                CREATE TABLE IF NOT EXISTS scoreboard_snapshots (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    snapshot_at TEXT NOT NULL,
                    snapshot_at_ts REAL NOT NULL,
                    team_id TEXT NOT NULL,
                    team_name TEXT NOT NULL,
                    rank INTEGER NOT NULL,
                    solved INTEGER NOT NULL,
                    attempts INTEGER NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_snap_team_ts
                    ON scoreboard_snapshots(team_id, snapshot_at_ts DESC);
                CREATE INDEX IF NOT EXISTS idx_snap_ts
                    ON scoreboard_snapshots(snapshot_at_ts DESC);
                CREATE TABLE IF NOT EXISTS team_achievements (
                    team_id TEXT NOT NULL,
                    achievement_id TEXT NOT NULL,
                    unlocked_at TEXT NOT NULL,
                    context_json TEXT NOT NULL DEFAULT '{}',
                    PRIMARY KEY (team_id, achievement_id)
                );
                CREATE INDEX IF NOT EXISTS idx_ach_team
                    ON team_achievements(team_id);
                CREATE INDEX IF NOT EXISTS idx_ach_id
                    ON team_achievements(achievement_id);
                CREATE TABLE IF NOT EXISTS achievement_counters (
                    team_id TEXT NOT NULL,
                    key TEXT NOT NULL,
                    value INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (team_id, key)
                );
            """)

    def _migrate(self) -> None:
        """Apply in-place schema migrations for older DB files."""
        cols = {r[1] for r in self._conn.execute("PRAGMA table_info(teams)")}
        # Old DBs may have an `api_key` column with no `token` — rename.
        if "api_key" in cols and "token" not in cols:
            with self._conn:
                self._conn.execute("ALTER TABLE teams RENAME COLUMN api_key TO token")
            cols = {r[1] for r in self._conn.execute("PRAGMA table_info(teams)")}
        # Very old DBs may have neither — add token, backfill from JSON data.
        if "token" not in cols:
            with self._conn:
                self._conn.execute("ALTER TABLE teams ADD COLUMN token TEXT NOT NULL DEFAULT ''")
                for row in self._conn.execute("SELECT team_id, data FROM teams"):
                    if row[1]:
                        team = json.loads(row[1])
                        tok = team.get("token") or team.get("api_key") or ""
                        if tok:
                            self._conn.execute(
                                "UPDATE teams SET token = ? WHERE team_id = ?", (tok, row[0])
                            )
        # Drop any legacy index; create the canonical one.
        with self._conn:
            self._conn.execute("DROP INDEX IF EXISTS idx_team_api_key")
            self._conn.execute("CREATE INDEX IF NOT EXISTS idx_team_token ON teams(token)")

        # Activity schema — actor_* columns were added with the audit-
        # tracking work. Old rows carry no actor context and would fail
        # pydantic validation (actor_* are required on ActivityState),
        # so drop + recreate rather than ALTER + backfill. The activity
        # log is strictly a display/audit surface; losing history on
        # upgrade is an acceptable tradeoff for a strict schema.
        act_cols = {r[1] for r in self._conn.execute("PRAGMA table_info(activities)")}
        if act_cols and "actor_id" not in act_cols:
            with self._conn:
                self._conn.execute("DROP TABLE activities")
                self._conn.execute(
                    """
                    CREATE TABLE activities (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp TEXT NOT NULL,
                        event TEXT NOT NULL,
                        team_id TEXT NOT NULL DEFAULT '',
                        challenge_id TEXT NOT NULL DEFAULT '',
                        actor_id TEXT NOT NULL DEFAULT '',
                        actor_name TEXT NOT NULL DEFAULT '',
                        actor_type TEXT NOT NULL DEFAULT '',
                        data TEXT NOT NULL
                    )
                    """
                )
                self._conn.execute("CREATE INDEX idx_act_team ON activities(team_id)")
                self._conn.execute("CREATE INDEX idx_act_event ON activities(event)")
                self._conn.execute("CREATE INDEX idx_act_actor ON activities(actor_id)")

        # NodeState grew a display_name field. Old node JSON blobs don't
        # carry it; reserialize them with display_name seeded to node_id
        # so subsequent reads validate cleanly without any fallback in
        # the request path.
        with self._conn:
            for row in self._conn.execute("SELECT node_id, data FROM nodes"):
                if not row[1]:
                    continue
                try:
                    blob = json.loads(row[1])
                except Exception:
                    continue
                if blob.get("display_name"):
                    continue
                blob["display_name"] = blob.get("node_id") or row[0]
                self._conn.execute(
                    "UPDATE nodes SET data = ? WHERE node_id = ?",
                    (json.dumps(blob), row[0]),
                )

        # Solves grew a flag_id column for multi-flag support. Old DBs have
        # only (team_id, challenge_id) PK; add flag_id with default "main",
        # rewrite the JSON blob to include flag_id="main", then rebuild the
        # composite PK + index. Single-flag challenges keep the same solve
        # behavior after migration.
        solve_cols = {r[1] for r in self._conn.execute("PRAGMA table_info(solves)")}
        if solve_cols and "flag_id" not in solve_cols:
            with self._conn:
                self._conn.execute(
                    "ALTER TABLE solves ADD COLUMN flag_id TEXT NOT NULL DEFAULT 'main'"
                )
                for row in self._conn.execute(
                    "SELECT team_id, challenge_id, data FROM solves"
                ):
                    if not row[2]:
                        continue
                    try:
                        blob = json.loads(row[2])
                    except Exception:
                        continue
                    if not blob.get("flag_id"):
                        blob["flag_id"] = "main"
                        self._conn.execute(
                            "UPDATE solves SET data = ? "
                            "WHERE team_id = ? AND challenge_id = ?",
                            (json.dumps(blob), row[0], row[1]),
                        )
                # Rebuild with composite PK on (team, chal, flag_id).
                self._conn.execute("ALTER TABLE solves RENAME TO solves_old")
                self._conn.execute(
                    """
                    CREATE TABLE solves (
                        team_id TEXT NOT NULL,
                        challenge_id TEXT NOT NULL,
                        flag_id TEXT NOT NULL DEFAULT 'main',
                        data TEXT NOT NULL,
                        PRIMARY KEY (team_id, challenge_id, flag_id)
                    )
                    """
                )
                self._conn.execute(
                    "INSERT INTO solves (team_id, challenge_id, flag_id, data) "
                    "SELECT team_id, challenge_id, flag_id, data FROM solves_old"
                )
                self._conn.execute("DROP TABLE solves_old")
                self._conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_solves_challenge_flag "
                    "ON solves(challenge_id, flag_id)"
                )

    # -- instance (in-memory, ephemeral) ------------------------------------

    def put_instance(self, instance_id: str, data: InstanceState, ttl: int = 0) -> None:
        now = time.time()
        data = data.model_copy(
            update={
                "started_at": data.started_at or now,
                "ttl": ttl,
                "expires_at": (now + ttl) if ttl > 0 else 0.0,
            }
        )
        with self._instance_lock:
            self._instances[instance_id] = data

    def get_instance(self, instance_id: str) -> InstanceState | None:
        with self._instance_lock:
            return self._instances.get(instance_id)

    def remove_instance(self, instance_id: str) -> InstanceState | None:
        with self._instance_lock:
            return self._instances.pop(instance_id, None)

    def list_instances(self) -> list[InstanceState]:
        with self._instance_lock:
            return [v.model_copy(update={"instance_id": k}) for k, v in self._instances.items()]

    def count_instances(self) -> int:
        with self._instance_lock:
            return len(self._instances)

    def renew_instance(self, instance_id: str, ttl: int) -> float:
        now = time.time()
        expires_at = (now + ttl) if ttl > 0 else 0.0
        with self._instance_lock:
            inst = self._instances.get(instance_id)
            if inst is None:
                raise KeyError(instance_id)
            self._instances[instance_id] = inst.model_copy(
                update={"ttl": ttl, "expires_at": expires_at}
            )
        return expires_at

    def pop_expired_instances(self) -> list[InstanceState]:
        now = time.time()
        expired = []
        with self._instance_lock:
            for sid in list(self._instances):
                inst = self._instances[sid]
                if inst.expires_at and now >= inst.expires_at:
                    expired.append(self._instances.pop(sid).model_copy(update={"instance_id": sid}))
        return expired

    def get_instance_by_team_challenge(
        self, team_id: str, challenge_id: str
    ) -> InstanceState | None:
        with self._instance_lock:
            for instance_id, inst in self._instances.items():
                if inst.team_id == team_id and inst.challenge_id == challenge_id:
                    return inst.model_copy(update={"instance_id": instance_id})
        return None

    # -- archived instance records (permanent, survives TTL / restart) ------

    def archive_instance(self, record: InstanceRecord) -> None:
        """Persist a completed instance record.

        ``INSERT OR REPLACE`` — terminal hooks can fire more than once for
        the same instance (e.g. reconcile_error racing a user DELETE); the
        latest write wins, which is the right outcome because the later
        call has the freshest stop_reason / error context.
        """
        with self._conn:
            self._conn.execute(
                """
                INSERT OR REPLACE INTO instance_records
                    (instance_id, team_id, challenge_id, node_id, status,
                     started_at, stopped_at, data)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    record.instance_id,
                    record.team_id,
                    record.challenge_id,
                    record.node_id,
                    record.status,
                    record.started_at,
                    record.stopped_at,
                    record.model_dump_json(),
                ),
            )

    def get_instance_record(self, instance_id: str) -> InstanceRecord | None:
        row = self._conn.execute(
            "SELECT data FROM instance_records WHERE instance_id = ?",
            (instance_id,),
        ).fetchone()
        return InstanceRecord.model_validate_json(row[0]) if row else None

    @staticmethod
    def _instance_record_where(
        *,
        team_id: str,
        challenge_id: str,
        node_id: str,
        status: str,
        since_ts: float,
    ) -> tuple[str, list]:
        clauses: list[str] = []
        params: list = []
        if team_id:
            clauses.append("team_id = ?")
            params.append(team_id)
        if challenge_id:
            clauses.append("challenge_id = ?")
            params.append(challenge_id)
        if node_id:
            clauses.append("node_id = ?")
            params.append(node_id)
        if status:
            clauses.append("status = ?")
            params.append(status)
        if since_ts > 0:
            clauses.append("started_at >= ?")
            params.append(since_ts)
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        return where, params

    def list_instance_records(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        node_id: str = "",
        status: str = "",
        since_ts: float = 0.0,
        offset: int = 0,
        limit: int = 100,
    ) -> list[InstanceRecord]:
        where, params = self._instance_record_where(
            team_id=team_id,
            challenge_id=challenge_id,
            node_id=node_id,
            status=status,
            since_ts=since_ts,
        )
        sql = (
            "SELECT data FROM instance_records"
            + where
            + " ORDER BY started_at DESC LIMIT ? OFFSET ?"
        )
        rows = self._conn.execute(sql, (*params, limit, offset)).fetchall()
        return [InstanceRecord.model_validate_json(r[0]) for r in rows]

    def count_instance_records(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        node_id: str = "",
        status: str = "",
        since_ts: float = 0.0,
    ) -> int:
        where, params = self._instance_record_where(
            team_id=team_id,
            challenge_id=challenge_id,
            node_id=node_id,
            status=status,
            since_ts=since_ts,
        )
        row = self._conn.execute(
            "SELECT COUNT(*) FROM instance_records" + where,
            params,
        ).fetchone()
        return int(row[0] or 0)

    # -- config (SQLite) ----------------------------------------------------

    def get_config(self, key: str) -> str | None:
        row = self._conn.execute("SELECT value FROM config WHERE key = ?", (key,)).fetchone()
        return row[0] if row else None

    def set_config(self, key: str, value: str) -> None:
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)", (key, value)
            )

    # -- nodes (SQLite) -----------------------------------------------------

    def put_node(self, node_id: str, data: NodeState) -> None:
        data = data.model_copy(update={"node_id": node_id})
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO nodes (node_id, data) VALUES (?, ?)",
                (node_id, data.model_dump_json()),
            )

    def get_node(self, node_id: str) -> NodeState | None:
        row = self._conn.execute("SELECT data FROM nodes WHERE node_id = ?", (node_id,)).fetchone()
        return NodeState.model_validate_json(row[0]) if row else None

    def get_node_by_token(self, token: str) -> NodeState | None:
        if not token:
            return None
        # Node counts are small (tens, not millions); a scan is fine and
        # avoids a second index we'd have to maintain for token rotation.
        import hmac as _hmac

        for row in self._conn.execute("SELECT data FROM nodes"):
            node = NodeState.model_validate_json(row[0])
            if node.token and _hmac.compare_digest(token, node.token):
                return node
        return None

    def list_nodes(self) -> list[NodeState]:
        return [
            NodeState.model_validate_json(row[0])
            for row in self._conn.execute("SELECT data FROM nodes")
        ]

    def remove_node(self, node_id: str) -> None:
        with self._conn:
            self._conn.execute("DELETE FROM nodes WHERE node_id = ?", (node_id,))
            self._conn.execute("DELETE FROM node_health_samples WHERE node_id = ?", (node_id,))

    # -- node health history (SQLite) --------------------------------------

    def append_health_sample(self, sample: NodeHealthSample) -> None:
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO node_health_samples (node_id, ts, data) VALUES (?, ?, ?)",
                (sample.node_id, sample.ts, sample.model_dump_json()),
            )
            # Bound the ring: delete rows older than the N most-recent per
            # node. Same transaction so readers never see the untrimmed state.
            self._conn.execute(
                "DELETE FROM node_health_samples "
                "WHERE node_id = ? AND ts NOT IN ("
                "  SELECT ts FROM node_health_samples "
                "  WHERE node_id = ? ORDER BY ts DESC LIMIT ?"
                ")",
                (sample.node_id, sample.node_id, HEALTH_SAMPLE_RING_SIZE),
            )

    def list_health_samples(
        self, node_id: str, limit: int = HEALTH_SAMPLE_RING_SIZE
    ) -> list[NodeHealthSample]:
        # Oldest-first so the frontend can render left-to-right.
        rows = self._conn.execute(
            "SELECT data FROM ("
            "  SELECT ts, data FROM node_health_samples "
            "  WHERE node_id = ? ORDER BY ts DESC LIMIT ?"
            ") ORDER BY ts ASC",
            (node_id, limit),
        )
        return [NodeHealthSample.model_validate_json(row[0]) for row in rows]

    # -- node invites (SQLite) ---------------------------------------------

    def put_invite(self, invite: NodeInviteState) -> None:
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO node_invites "
                "(invite_id, token_hash, data) VALUES (?, ?, ?)",
                (invite.invite_id, invite.token_hash, invite.model_dump_json()),
            )

    def get_invite(self, invite_id: str) -> NodeInviteState | None:
        row = self._conn.execute(
            "SELECT data FROM node_invites WHERE invite_id = ?", (invite_id,)
        ).fetchone()
        return NodeInviteState.model_validate_json(row[0]) if row else None

    def get_invite_by_hash(self, token_hash: str) -> NodeInviteState | None:
        if not token_hash:
            return None
        row = self._conn.execute(
            "SELECT data FROM node_invites WHERE token_hash = ?", (token_hash,)
        ).fetchone()
        return NodeInviteState.model_validate_json(row[0]) if row else None

    def list_invites(self) -> list[NodeInviteState]:
        return [
            NodeInviteState.model_validate_json(row[0])
            for row in self._conn.execute("SELECT data FROM node_invites")
        ]

    def consume_invite(self, token_hash: str, node_id: str) -> NodeInviteState | None:
        if not token_hash:
            return None
        # CAS: single-row UPDATE that only takes effect if the invite is
        # still active, avoiding a read-then-write race under concurrent
        # registrations.
        with self._conn:
            cur = self._conn.execute(
                "UPDATE node_invites "
                "SET data = json_set(data, '$.consumed_at_ts', ?, "
                "                    '$.consumed_by_node_id', ?) "
                "WHERE token_hash = ? "
                "  AND json_extract(data, '$.consumed_at_ts') = 0",
                (time.time(), node_id, token_hash),
            )
            if cur.rowcount == 0:
                return None
        row = self._conn.execute(
            "SELECT data FROM node_invites WHERE token_hash = ?", (token_hash,)
        ).fetchone()
        return NodeInviteState.model_validate_json(row[0]) if row else None

    def remove_invite(self, invite_id: str) -> None:
        with self._conn:
            self._conn.execute("DELETE FROM node_invites WHERE invite_id = ?", (invite_id,))

    # -- teams (SQLite) -----------------------------------------------------

    def put_team(self, team_id: str, data: TeamState) -> None:
        data = data.model_copy(update={"team_id": team_id})
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO teams (team_id, token, data) VALUES (?, ?, ?)",
                (team_id, data.token, data.model_dump_json()),
            )

    def get_team(self, team_id: str) -> TeamState | None:
        row = self._conn.execute("SELECT data FROM teams WHERE team_id = ?", (team_id,)).fetchone()
        return TeamState.model_validate_json(row[0]) if row else None

    def get_team_by_token(self, token: str) -> TeamState | None:
        row = self._conn.execute("SELECT data FROM teams WHERE token = ?", (token,)).fetchone()
        return TeamState.model_validate_json(row[0]) if row and row[0] else None

    def list_teams(self) -> list[TeamState]:
        return [
            TeamState.model_validate_json(row[0])
            for row in self._conn.execute("SELECT data FROM teams")
        ]

    # -- submissions (SQLite) -----------------------------------------------

    def add_submission(self, data: SubmissionState) -> None:
        with self._conn:
            self._conn.execute(
                "INSERT INTO submissions (submission_id, team_id, challenge_id, data) "
                "VALUES (?, ?, ?, ?)",
                (data.submission_id, data.team_id, data.challenge_id, data.model_dump_json()),
            )

    def list_submissions(self, team_id: str = "", challenge_id: str = "") -> list[SubmissionState]:
        sql = "SELECT data FROM submissions WHERE 1=1"
        params: list = []
        if team_id:
            sql += " AND team_id = ?"
            params.append(team_id)
        if challenge_id:
            sql += " AND challenge_id = ?"
            params.append(challenge_id)
        return [
            SubmissionState.model_validate_json(row[0]) for row in self._conn.execute(sql, params)
        ]

    # -- solves (SQLite) ----------------------------------------------------

    def add_solve(
        self, team_id: str, challenge_id: str, flag_id: str, data: SolveState
    ) -> None:
        data = data.model_copy(
            update={
                "team_id": team_id,
                "challenge_id": challenge_id,
                "flag_id": flag_id,
            }
        )
        with self._conn:
            self._conn.execute(
                "INSERT OR IGNORE INTO solves "
                "(team_id, challenge_id, flag_id, data) VALUES (?, ?, ?, ?)",
                (team_id, challenge_id, flag_id, data.model_dump_json()),
            )

    def get_solve(
        self, team_id: str, challenge_id: str, flag_id: str
    ) -> SolveState | None:
        row = self._conn.execute(
            "SELECT data FROM solves "
            "WHERE team_id = ? AND challenge_id = ? AND flag_id = ?",
            (team_id, challenge_id, flag_id),
        ).fetchone()
        return SolveState.model_validate_json(row[0]) if row else None

    def list_solves(self, team_id: str = "") -> list[SolveState]:
        if team_id:
            rows = self._conn.execute("SELECT data FROM solves WHERE team_id = ?", (team_id,))
        else:
            rows = self._conn.execute("SELECT data FROM solves")
        return [SolveState.model_validate_json(row[0]) for row in rows]

    def count_solves_for_flag(self, challenge_id: str, flag_id: str) -> int:
        row = self._conn.execute(
            "SELECT COUNT(*) FROM solves WHERE challenge_id = ? AND flag_id = ?",
            (challenge_id, flag_id),
        ).fetchone()
        return row[0] if row else 0

    def count_solves_for_challenge(
        self, challenge_id: str, flag_ids: tuple[str, ...] = ()
    ) -> int:
        """Teams who have captured every declared flag on the challenge."""
        if not flag_ids:
            return 0
        placeholders = ",".join("?" * len(flag_ids))
        row = self._conn.execute(
            f"SELECT COUNT(*) FROM ("
            f"  SELECT team_id FROM solves"
            f"  WHERE challenge_id = ? AND flag_id IN ({placeholders})"
            f"  GROUP BY team_id"
            f"  HAVING COUNT(DISTINCT flag_id) = ?"
            f")",
            (challenge_id, *flag_ids, len(set(flag_ids))),
        ).fetchone()
        return row[0] if row else 0

    # -- activity log (SQLite) ----------------------------------------------

    def add_activity(self, data: ActivityState) -> None:
        with self._conn:
            self._conn.execute(
                "INSERT INTO activities "
                "(timestamp, event, team_id, challenge_id, actor_id, actor_name, actor_type, data) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    data.timestamp,
                    data.event,
                    data.team_id,
                    data.challenge_id,
                    data.actor_id,
                    data.actor_name,
                    data.actor_type,
                    data.model_dump_json(),
                ),
            )

    def _activity_where(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        events: tuple[str, ...] = (),
        actor_id: str = "",
    ) -> tuple[str, list]:
        clauses = "WHERE 1=1"
        params: list = []
        if team_id:
            clauses += " AND team_id = ?"
            params.append(team_id)
        if challenge_id:
            clauses += " AND challenge_id = ?"
            params.append(challenge_id)
        if event:
            clauses += " AND event = ?"
            params.append(event)
        if events:
            placeholders = ",".join("?" * len(events))
            clauses += f" AND event IN ({placeholders})"
            params.extend(events)
        if actor_id:
            clauses += " AND actor_id = ?"
            params.append(actor_id)
        return clauses, params

    def list_activities(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        events: tuple[str, ...] = (),
        actor_id: str = "",
        offset: int = 0,
        limit: int = 100,
    ) -> list[ActivityState]:
        where, params = self._activity_where(
            team_id=team_id,
            challenge_id=challenge_id,
            event=event,
            events=events,
            actor_id=actor_id,
        )
        sql = f"SELECT data FROM activities {where} ORDER BY id DESC LIMIT ? OFFSET ?"
        params += [limit, offset]
        return [
            ActivityState.model_validate_json(row[0]) for row in self._conn.execute(sql, params)
        ]

    def count_activities(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        events: tuple[str, ...] = (),
        actor_id: str = "",
    ) -> int:
        where, params = self._activity_where(
            team_id=team_id,
            challenge_id=challenge_id,
            event=event,
            events=events,
            actor_id=actor_id,
        )
        sql = f"SELECT COUNT(*) FROM activities {where}"
        return self._conn.execute(sql, params).fetchone()[0]

    # -- scoreboard snapshots -----------------------------------------------

    def append_snapshot_batch(self, snapshots: list[ScoreboardSnapshotState]) -> None:
        if not snapshots:
            return
        rows = [
            (
                s.snapshot_at,
                s.snapshot_at_ts,
                s.team_id,
                s.team_name,
                s.rank,
                s.solved,
                s.attempts,
            )
            for s in snapshots
        ]
        with self._conn:
            self._conn.executemany(
                "INSERT INTO scoreboard_snapshots "
                "(snapshot_at, snapshot_at_ts, team_id, team_name, rank, solved, attempts) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                rows,
            )

    def list_snapshots(
        self,
        *,
        team_id: str = "",
        since_ts: float = 0.0,
        limit: int = 0,
    ) -> list[ScoreboardSnapshotState]:
        clauses = "WHERE snapshot_at_ts >= ?"
        params: list = [since_ts]
        if team_id:
            clauses += " AND team_id = ?"
            params.append(team_id)
        sql = (
            "SELECT snapshot_at, snapshot_at_ts, team_id, team_name, rank, solved, attempts "
            f"FROM scoreboard_snapshots {clauses} ORDER BY snapshot_at_ts ASC"
        )
        if limit > 0:
            # Fetch newest *limit* by ts-desc then flip so callers still
            # get ascending output — saves a second pass in Python.
            sql = (
                "SELECT snapshot_at, snapshot_at_ts, team_id, team_name, rank, solved, attempts "
                f"FROM scoreboard_snapshots {clauses} ORDER BY snapshot_at_ts DESC LIMIT ?"
            )
            params.append(limit)
            rows = list(self._conn.execute(sql, params))
            rows.reverse()
        else:
            rows = list(self._conn.execute(sql, params))
        return [
            ScoreboardSnapshotState(
                snapshot_at=r[0],
                snapshot_at_ts=r[1],
                team_id=r[2],
                team_name=r[3],
                rank=r[4],
                solved=r[5],
                attempts=r[6],
            )
            for r in rows
        ]

    # -- achievements --------------------------------------------------------

    def list_achievements(self, team_id: str) -> list[AchievementRecord]:
        rows = self._conn.execute(
            "SELECT team_id, achievement_id, unlocked_at, context_json "
            "FROM team_achievements WHERE team_id = ? ORDER BY unlocked_at ASC",
            (team_id,),
        ).fetchall()
        return [
            AchievementRecord(
                team_id=r[0],
                achievement_id=r[1],
                unlocked_at=r[2],
                context=json.loads(r[3] or "{}"),
            )
            for r in rows
        ]

    def has_achievement(self, team_id: str, achievement_id: str) -> bool:
        row = self._conn.execute(
            "SELECT 1 FROM team_achievements WHERE team_id = ? AND achievement_id = ?",
            (team_id, achievement_id),
        ).fetchone()
        return row is not None

    def grant_achievement(
        self,
        team_id: str,
        achievement_id: str,
        context: dict | None = None,
    ) -> AchievementRecord | None:
        # INSERT OR IGNORE gives us an atomic "grant iff absent" — rowcount
        # distinguishes a true unlock (1) from a no-op (0), so the evaluator
        # can gate event emission off a single round-trip.
        unlocked_at = datetime.now(timezone.utc).isoformat()
        ctx_json = json.dumps(context or {})
        with self._conn:
            cur = self._conn.execute(
                "INSERT OR IGNORE INTO team_achievements "
                "(team_id, achievement_id, unlocked_at, context_json) "
                "VALUES (?, ?, ?, ?)",
                (team_id, achievement_id, unlocked_at, ctx_json),
            )
            if cur.rowcount == 0:
                return None
        return AchievementRecord(
            team_id=team_id,
            achievement_id=achievement_id,
            unlocked_at=unlocked_at,
            context=context or {},
        )

    def revoke_achievement(self, team_id: str, achievement_id: str) -> bool:
        with self._conn:
            cur = self._conn.execute(
                "DELETE FROM team_achievements WHERE team_id = ? AND achievement_id = ?",
                (team_id, achievement_id),
            )
            return cur.rowcount > 0

    def bump_counter(self, team_id: str, key: str, delta: int = 1) -> int:
        updated_at = datetime.now(timezone.utc).isoformat()
        with self._conn:
            self._conn.execute(
                "INSERT INTO achievement_counters (team_id, key, value, updated_at) "
                "VALUES (?, ?, ?, ?) "
                "ON CONFLICT(team_id, key) DO UPDATE SET "
                "  value = value + excluded.value, updated_at = excluded.updated_at",
                (team_id, key, delta, updated_at),
            )
        row = self._conn.execute(
            "SELECT value FROM achievement_counters WHERE team_id = ? AND key = ?",
            (team_id, key),
        ).fetchone()
        return int(row[0]) if row else 0

    def get_counter(self, team_id: str, key: str) -> int:
        row = self._conn.execute(
            "SELECT value FROM achievement_counters WHERE team_id = ? AND key = ?",
            (team_id, key),
        ).fetchone()
        return int(row[0]) if row else 0

    def reset_counter(self, team_id: str, key: str) -> None:
        with self._conn:
            self._conn.execute(
                "DELETE FROM achievement_counters WHERE team_id = ? AND key = ?",
                (team_id, key),
            )
