"""Challenge metadata validation — delegates to the upstream audit.

The source of truth is the audit script shipped with CTF-Arena/challenges
(``<challenges_dir>/scripts/audit.py``). It defines META/STRUCT/COMPOSE/
HEALTH/EXPLOIT/SOURCE rule IDs; reimplementing any of those rules here
would just drift. So when the upstream audit is present we shell to it;
otherwise we fall back to a pydantic-only parse check via ChallengeSpec.

``ctfy challenge validate`` and the ``challenges.yml`` CI workflow both
dispatch through :func:`validate_dir`.
"""

from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass
from pathlib import Path

import yaml
from pydantic import ValidationError

from ctfy.core.challenge import ChallengeSpec
from ctfy.core.log import log


@dataclass(frozen=True)
class Finding:
    """One validation result."""

    challenge: str
    ok: bool
    reason: str = ""

    @property
    def status(self) -> str:
        return "OK" if self.ok else "FAIL"


def validate_dir(
    challenges_dir: Path,
    *,
    challenge_id: str | None = None,
    strict: bool = False,
) -> list[Finding]:
    """Validate one or every challenge in ``challenges_dir``.

    Prefers the upstream ``scripts/audit.py`` when available — that's the
    SSOT for the metadata + compose + source-code-hygiene rule set. Falls
    back to a schema-only pydantic check when the audit isn't shipped
    alongside the challenges. ``strict`` is passed through to the audit
    unchanged (upstream decides what strict means for each rule).
    """
    if not challenges_dir.exists():
        return []

    audit_script = challenges_dir / "scripts" / "audit.py"
    if audit_script.is_file():
        return _run_upstream_audit(
            challenges_dir,
            audit_script,
            challenge_id=challenge_id,
            strict=strict,
        )

    return _fallback_parse_check(challenges_dir, challenge_id=challenge_id)


def _run_upstream_audit(
    challenges_dir: Path,
    audit_script: Path,
    *,
    challenge_id: str | None,
    strict: bool,
) -> list[Finding]:
    """Shell to ``scripts/audit.py`` and map its JSON output to Findings."""
    out_path = challenges_dir / ".audit-findings.json"
    cmd = ["uv", "run", "--project", str(challenges_dir), "python", str(audit_script)]
    if challenge_id:
        cmd.extend(["--only", challenge_id])
    cmd.extend(["--json", str(out_path)])
    log.info("Running upstream audit", cmd=cmd)
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=False, timeout=180)
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        log.warning("Upstream audit unavailable; falling back to parse-only check", error=str(e))
        return _fallback_parse_check(challenges_dir, challenge_id=challenge_id)

    if not out_path.exists():
        log.warning(
            "Upstream audit produced no report",
            stdout=result.stdout.strip()[-500:],
            stderr=result.stderr.strip()[-500:],
        )
        return _fallback_parse_check(challenges_dir, challenge_id=challenge_id)

    try:
        report = json.loads(out_path.read_text())
    finally:
        try:
            out_path.unlink()
        except OSError:
            pass

    # Group issues by challenge; an entry with no errors becomes an OK.
    findings: dict[str, list[str]] = {}
    for issue in report.get("issues", []):
        if issue.get("severity") != "error" and not strict:
            continue
        name = issue.get("benchmark") or "?"
        findings.setdefault(name, []).append(
            f"{issue.get('rule', '???')}: {issue.get('message', '').strip()}"
        )

    # Every benchmark the audit visited deserves a row; infer the full set
    # from the report.
    visited: set[str] = {i.get("benchmark", "") for i in report.get("issues", [])}
    visited |= {
        d.name
        for d in challenges_dir.iterdir()
        if d.is_dir()
        and (d / "metadata.yaml").is_file()
        and (challenge_id is None or d.name == challenge_id)
    }
    visited.discard("")

    out: list[Finding] = []
    for name in sorted(visited):
        errs = findings.get(name, [])
        if errs:
            out.append(Finding(name, False, " | ".join(errs)))
        else:
            out.append(Finding(name, True))
    return out


def _fallback_parse_check(
    challenges_dir: Path,
    *,
    challenge_id: str | None,
) -> list[Finding]:
    """Minimal schema check — only verifies that ``ChallengeSpec.from_yaml``
    parses. Use this when the upstream audit script isn't available."""
    out: list[Finding] = []
    for d in sorted(challenges_dir.iterdir()):
        if not d.is_dir():
            continue
        if challenge_id and d.name != challenge_id:
            continue
        yml = d / "metadata.yaml"
        if not yml.is_file():
            continue
        try:
            ChallengeSpec.from_yaml(yml)
        except (ValidationError, yaml.YAMLError, OSError) as e:
            msg = str(e).splitlines()[0]
            out.append(Finding(d.name, False, msg))
            continue
        out.append(Finding(d.name, True))
    return out
