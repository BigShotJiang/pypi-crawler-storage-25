"""Unit tests for the achievement engine + individual rule predicates.

Each test drives the engine directly (bypassing the HTTP layer) so the
assertions focus on rule logic — the routes get their own coverage in
``test_achievements_routes.py``.
"""

from __future__ import annotations

import time
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest

# Make sure rule modules are imported so @register decorators run.
import ctfy.server.achievements.rules  # noqa: F401
from ctfy.core.enums import InstanceStatus, PlatformEvent
from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import InstanceState, SolveState, SubmissionState, TeamState
from ctfy.server.achievements.engine import evaluate
from ctfy.server.event_payloads import (
    FlagCorrectPayload,
    FlagWrongPayload,
    TeamRegisteredPayload,
)


@pytest.fixture
def app():
    """Lightweight app-like mock good enough for the engine.

    The engine only touches ``state_backend`` and (for completionist)
    ``spec_reader.iter_specs``; every other attribute stays a Mock so
    the emit_event recursion path works without a real FastAPI app.
    """
    app = MagicMock()
    app.state_backend = InMemoryBackend()
    app.spec_reader.iter_specs = lambda **_kw: iter(())  # empty catalog by default
    app.instance_archive = None
    return app


def _register_team(app, *, team_id="t1", name="Team 1") -> TeamState:
    team = TeamState(team_id=team_id, name=name, created_at="2025-01-01T00:00:00+00:00")
    app.state_backend.put_team(team_id, team)
    return team


class TestTeamRegistered:
    def test_welcome_aboard_unlocks(self, app):
        team = _register_team(app)
        evaluate(
            app,
            PlatformEvent.TEAM_REGISTERED,
            TeamRegisteredPayload(team_id=team.team_id, team_name=team.name),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        unlocked = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "welcome_aboard" in unlocked


class TestFirstBlood:
    def _solve(self, app, team_id, challenge_id, **overrides):
        data = {
            "team_id": team_id,
            "challenge_id": challenge_id,
            "solved_at": datetime.now(timezone.utc).isoformat(),
            "solve_time_s": 120.0,
            "attempts": 2,
        }
        data.update(overrides)
        app.state_backend.add_solve(team_id, challenge_id, data.get("flag_id", "main"), SolveState(**data))

    def test_first_solve_unlocks(self, app):
        team = _register_team(app)
        self._solve(app, team.team_id, "CHAL-A")
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "first_blood_team" in ids

    def test_second_solve_does_not_unlock(self, app):
        team = _register_team(app)
        self._solve(app, team.team_id, "CHAL-A")
        # First solve would have unlocked it; simulate by pre-granting.
        app.state_backend.grant_achievement(team.team_id, "first_blood_team", {})
        self._solve(app, team.team_id, "CHAL-B")
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="CHAL-B"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        records = app.state_backend.list_achievements(team.team_id)
        # Exactly one first_blood_team record.
        assert sum(1 for r in records if r.achievement_id == "first_blood_team") == 1


class TestFastestMan:
    def test_first_global_solver_gets_it(self, app):
        team = _register_team(app)
        app.state_backend.add_solve(
            team.team_id,
            "CHAL-A",
            "main",
            SolveState(
                team_id=team.team_id,
                challenge_id="CHAL-A",
                solved_at=datetime.now(timezone.utc).isoformat(),
            ),
        )
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "fastest_man" in ids

    def test_second_solver_does_not(self, app):
        # Team A solved first.
        team_a = _register_team(app, team_id="ta", name="A")
        app.state_backend.add_solve(
            team_a.team_id,
            "CHAL-A",
            "main",
            SolveState(team_id=team_a.team_id, challenge_id="CHAL-A"),
        )
        team_b = _register_team(app, team_id="tb", name="B")
        app.state_backend.add_solve(
            team_b.team_id,
            "CHAL-A",
            "main",
            SolveState(team_id=team_b.team_id, challenge_id="CHAL-A"),
        )
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team_b.team_id, team_name="B", challenge_id="CHAL-A"),
            actor_type="team",
            actor_team_id=team_b.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team_b.team_id)}
        assert "fastest_man" not in ids


class TestTimeOfDay:
    def test_night_owl_in_hours(self, app):
        team = _register_team(app)
        # Force "now" to 3 AM UTC.
        fake_now = datetime(2025, 3, 1, 3, 0, tzinfo=timezone.utc)
        with patch("ctfy.server.achievements.rules.flag_correct_rules.datetime") as mock_dt:
            mock_dt.now.return_value = fake_now
            mock_dt.side_effect = lambda *a, **kw: datetime(*a, **kw)
            evaluate(
                app,
                PlatformEvent.FLAG_CORRECT,
                FlagCorrectPayload(
                    team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"
                ),
                actor_type="team",
                actor_team_id=team.team_id,
            )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "night_owl" in ids

    def test_night_owl_out_of_hours(self, app):
        team = _register_team(app)
        fake_now = datetime(2025, 3, 1, 15, 0, tzinfo=timezone.utc)  # 3 PM
        with patch("ctfy.server.achievements.rules.flag_correct_rules.datetime") as mock_dt:
            mock_dt.now.return_value = fake_now
            mock_dt.side_effect = lambda *a, **kw: datetime(*a, **kw)
            evaluate(
                app,
                PlatformEvent.FLAG_CORRECT,
                FlagCorrectPayload(
                    team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"
                ),
                actor_type="team",
                actor_team_id=team.team_id,
            )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "night_owl" not in ids


class TestSpeed:
    def test_flash_solver_under_60s(self, app):
        team = _register_team(app)
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(
                team_id=team.team_id,
                team_name=team.name,
                challenge_id="CHAL-A",
                solve_time_s=42.0,
            ),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "flash_solver" in ids

    def test_flash_solver_not_granted_slow(self, app):
        team = _register_team(app)
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(
                team_id=team.team_id,
                team_name=team.name,
                challenge_id="CHAL-A",
                solve_time_s=120.0,
            ),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "flash_solver" not in ids

    def test_kamikaze_on_correct(self, app):
        team = _register_team(app)
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(
                team_id=team.team_id,
                team_name=team.name,
                challenge_id="CHAL-A",
                solve_time_s=3.0,
            ),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "kamikaze" in ids


class TestLuckyGuesser:
    def test_first_attempt_solve(self, app):
        team = _register_team(app)
        app.state_backend.add_solve(
            team.team_id,
            "CHAL-A",
            "main",
            SolveState(
                team_id=team.team_id,
                challenge_id="CHAL-A",
                attempts=1,
            ),
        )
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "lucky_guesser" in ids

    def test_multiple_attempts_no_unlock(self, app):
        team = _register_team(app)
        app.state_backend.add_solve(
            team.team_id,
            "CHAL-A",
            "main",
            SolveState(team_id=team.team_id, challenge_id="CHAL-A", attempts=5),
        )
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "lucky_guesser" not in ids


class TestSisyphus:
    def test_fifty_wrongs_then_solve_unlocks(self, app):
        team = _register_team(app)
        # Pretend they already wrong-flagged 50 times — the wrong-rule
        # would have bumped this counter in production.
        app.state_backend.bump_counter(team.team_id, "wrong_on:CHAL-A", 50)
        app.state_backend.add_solve(
            team.team_id,
            "CHAL-A",
            "main",
            SolveState(team_id=team.team_id, challenge_id="CHAL-A", attempts=51),
        )
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "sisyphus" in ids

    def test_fewer_wrongs_no_unlock(self, app):
        team = _register_team(app)
        app.state_backend.bump_counter(team.team_id, "wrong_on:CHAL-A", 10)
        app.state_backend.add_solve(
            team.team_id,
            "CHAL-A",
            "main",
            SolveState(team_id=team.team_id, challenge_id="CHAL-A", attempts=11),
        )
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "sisyphus" not in ids


class TestWrongFlagRules:
    def test_wrong_counter_bumps(self, app):
        team = _register_team(app)
        evaluate(
            app,
            PlatformEvent.FLAG_WRONG,
            FlagWrongPayload(team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        assert app.state_backend.get_counter(team.team_id, "wrong_on:CHAL-A") == 1

    def test_secret_handshake_flag(self, app):
        team = _register_team(app)
        app.state_backend.add_submission(
            SubmissionState(
                submission_id="s1",
                team_id=team.team_id,
                challenge_id="CHAL-A",
                claimed_flag="flag{hello_world}",
                correct=False,
            )
        )
        evaluate(
            app,
            PlatformEvent.FLAG_WRONG,
            FlagWrongPayload(team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "secret_handshake" in ids

    def test_kamikaze_wrong_within_window(self, app):
        team = _register_team(app)
        app.state_backend.put_instance(
            "inst-1",
            InstanceState(
                instance_id="inst-1",
                team_id=team.team_id,
                challenge_id="CHAL-A",
                status=InstanceStatus.READY,
                started_at=time.time() - 2.0,  # 2 seconds ago → inside 5s window
            ),
        )
        evaluate(
            app,
            PlatformEvent.FLAG_WRONG,
            FlagWrongPayload(
                team_id=team.team_id,
                team_name=team.name,
                challenge_id="CHAL-A",
                instance_id="inst-1",
            ),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "kamikaze" in ids


class TestGlobalBehavior:
    def test_non_team_actor_skipped(self, app):
        _register_team(app)
        evaluate(
            app,
            PlatformEvent.TEAM_REGISTERED,
            TeamRegisteredPayload(team_id="t1", team_name="T"),
            actor_type="system",
            actor_team_id="t1",
        )
        assert app.state_backend.list_achievements("t1") == []

    def test_rule_crash_does_not_break_others(self, app):
        """A rule that raises must not stop subsequent rules from running."""
        from ctfy.server.achievements import engine as _engine

        team = _register_team(app)
        app.state_backend.add_solve(
            team.team_id,
            "CHAL-A",
            "main",
            SolveState(team_id=team.team_id, challenge_id="CHAL-A"),
        )

        def _boom(*_args, **_kw):
            raise RuntimeError("boom")

        existing = list(_engine._RULES.get(PlatformEvent.FLAG_CORRECT, []))
        # Prepend the crasher so it's evaluated before the real rules —
        # exercises the "skip to next rule on exception" path.
        _engine._RULES[PlatformEvent.FLAG_CORRECT] = [_boom, *existing]
        try:
            evaluate(
                app,
                PlatformEvent.FLAG_CORRECT,
                FlagCorrectPayload(
                    team_id=team.team_id, team_name=team.name, challenge_id="CHAL-A"
                ),
                actor_type="team",
                actor_team_id=team.team_id,
            )
        finally:
            _engine._RULES[PlatformEvent.FLAG_CORRECT] = existing
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "first_blood_team" in ids

    def test_grant_is_idempotent(self, app):
        team = _register_team(app)
        for _ in range(3):
            evaluate(
                app,
                PlatformEvent.TEAM_REGISTERED,
                TeamRegisteredPayload(team_id=team.team_id, team_name=team.name),
                actor_type="team",
                actor_team_id=team.team_id,
            )
        records = [
            r
            for r in app.state_backend.list_achievements(team.team_id)
            if r.achievement_id == "welcome_aboard"
        ]
        assert len(records) == 1


class TestAgentAchievements:
    def _register(self, app, *, agent: str):
        return _register_team(app, team_id=f"t-{agent or 'none'}", name=f"T {agent or 'none'}")

    def _solved_state(self, tid, cid, *, solved_at: str = ""):
        return SolveState(
            team_id=tid,
            challenge_id=cid,
            solved_at=solved_at or datetime.now(timezone.utc).isoformat(),
        )

    def test_agent_online_requires_agent_field(self, app):
        team = _register_team(app, team_id="t-ai", name="AI")
        # Simulate registration with agent set — override the stored team.
        team = team.model_copy(update={"agent": "claude-code"})
        app.state_backend.put_team(team.team_id, team)
        evaluate(
            app,
            PlatformEvent.TEAM_REGISTERED,
            TeamRegisteredPayload(team_id=team.team_id, team_name=team.name, agent=team.agent),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "agent_online" in ids

    def test_agent_online_skipped_without_agent(self, app):
        team = _register_team(app, team_id="t-human", name="Human")
        evaluate(
            app,
            PlatformEvent.TEAM_REGISTERED,
            TeamRegisteredPayload(team_id=team.team_id, team_name=team.name, agent=""),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "agent_online" not in ids

    def test_autonomous_operator_after_five_solves(self, app):
        team = _register_team(app, team_id="t-ai", name="AI").model_copy(
            update={"agent": "claude-code"}
        )
        app.state_backend.put_team(team.team_id, team)
        for i in range(5):
            app.state_backend.add_solve(
                team.team_id, f"C{i}", "main", self._solved_state(team.team_id, f"C{i}"),
                )
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="C4"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "autonomous_operator" in ids

    def test_autonomous_operator_skipped_without_agent(self, app):
        team = _register_team(app)
        for i in range(5):
            app.state_backend.add_solve(
                team.team_id, f"C{i}", "main", self._solved_state(team.team_id, f"C{i}"),
                )
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="C4"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "autonomous_operator" not in ids

    def test_claude_apprentice_matches_prefix_case_insensitive(self, app):
        team = _register_team(app).model_copy(update={"agent": "Claude-Code"})
        app.state_backend.put_team(team.team_id, team)
        app.state_backend.add_solve(team.team_id, "C1", "main", self._solved_state(team.team_id, "C1"))
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="C1"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "claude_apprentice" in ids

    def test_claude_apprentice_skipped_for_other_agent(self, app):
        team = _register_team(app).model_copy(update={"agent": "cai"})
        app.state_backend.put_team(team.team_id, team)
        app.state_backend.add_solve(team.team_id, "C1", "main", self._solved_state(team.team_id, "C1"))
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="C1"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "claude_apprentice" not in ids

    def test_rapid_fire_three_solves_in_window(self, app):
        team = _register_team(app).model_copy(update={"agent": "claude-code"})
        app.state_backend.put_team(team.team_id, team)
        # Three solves spaced 2 minutes apart → well inside 10-minute window.
        base = datetime(2025, 5, 1, 12, 0, tzinfo=timezone.utc)
        for i in range(3):
            ts = base.replace(minute=i * 2).isoformat()
            app.state_backend.add_solve(
                team.team_id, f"C{i}", "main", self._solved_state(team.team_id, f"C{i}", solved_at=ts),
                )
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="C2"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "rapid_fire" in ids

    def test_rapid_fire_skipped_when_spread_out(self, app):
        team = _register_team(app)
        base = datetime(2025, 5, 1, 12, 0, tzinfo=timezone.utc)
        # 20 minutes between solves — outside the window.
        for i in range(3):
            ts = base.replace(hour=12 + i).isoformat()
            app.state_backend.add_solve(
                team.team_id, f"C{i}", "main", self._solved_state(team.team_id, f"C{i}", solved_at=ts),
                )
        evaluate(
            app,
            PlatformEvent.FLAG_CORRECT,
            FlagCorrectPayload(team_id=team.team_id, team_name=team.name, challenge_id="C2"),
            actor_type="team",
            actor_team_id=team.team_id,
        )
        ids = {r.achievement_id for r in app.state_backend.list_achievements(team.team_id)}
        assert "rapid_fire" not in ids
