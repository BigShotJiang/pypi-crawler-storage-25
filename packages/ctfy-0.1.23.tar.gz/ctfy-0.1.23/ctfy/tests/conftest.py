"""Shared fixtures for tests."""

from __future__ import annotations

import time
from contextlib import ExitStack, contextmanager
from unittest.mock import MagicMock, patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.challenge import ChallengeSpec
from ctfy.core.enums import Difficulty, InstanceStatus
from ctfy.core.provider import StartResult
from ctfy.core.state import InMemoryBackend, StateBackend
from ctfy.core.state.models import NodeState
from ctfy.core.target import AttackSurface, ServiceEndpoint, ServiceType


def build_spec(
    id: str,
    *,
    name: str | None = None,
    description: str = "Test challenge.",
    difficulty: Difficulty | str = Difficulty.EASY,
    tags: list[str] | None = None,
    flags: list[str] | None = None,
) -> ChallengeSpec:
    """Construct a ChallengeSpec with sensible defaults for tests.

    The upstream slim v3 schema requires name/description/difficulty/tags;
    callers usually only care about ``id`` and occasionally ``difficulty``,
    so this wraps the pydantic ceremony. ``flags`` defaults to a single
    flag id ``main`` (matches the platform's implicit default).
    """
    return ChallengeSpec(
        id=id,
        name=name or id,
        description=description,
        difficulty=Difficulty(difficulty) if isinstance(difficulty, str) else difficulty,
        tags=tags or ["test"],
        flags=flags or ["main"],
    )


def start_instance_and_wait(
    client,
    challenge_id,
    *,
    max_wait=5,
    headers=None,
    ttl=300,
):
    """POST /api/v1/instances then poll status until READY.

    Returns the instance_id. On 409 (instance already exists for this
    team + challenge) the existing instance is looked up and waited on.
    Works with any TestClient-shaped client.
    """
    hdrs = headers or {}
    resp = client.post(
        "/api/v1/instances",
        json={"challenge_id": challenge_id, "ttl": ttl},
        headers=hdrs,
    )
    instance_id = ""
    if resp.status_code < 400:
        instance_id = resp.json().get("instance_id", "")
    if not instance_id:
        # 409 duplicate or similar — find the existing instance.
        items = client.get("/api/v1/instances", headers=hdrs).json()["items"]
        for item in items:
            if item.get("challenge_id") == challenge_id:
                instance_id = item["instance_id"]
                break
    if not instance_id:
        raise RuntimeError(f"Could not resolve instance_id for {challenge_id}")

    deadline = time.monotonic() + max_wait
    while time.monotonic() < deadline:
        s = client.get(f"/api/v1/instances/{instance_id}/status", headers=hdrs)
        if s.status_code == 200:
            status = s.json().get("status")
            if status == "ready":
                return instance_id
            if status == "error":
                raise RuntimeError(s.json().get("error") or "instance error")
        time.sleep(0.1)
    raise TimeoutError(f"{challenge_id} not ready after {max_wait}s")


def make_mock_challenge_manager(
    *,
    challenge_specs: list[ChallengeSpec] | None = None,
    flag: str = "FLAG{testflag_0123456789abcdef01234567}",
    host: str = "127.0.0.1",
    port: int = 8080,
    service_type: ServiceType = ServiceType.HTTP,
    auto_generate_specs: bool = True,
) -> MagicMock:
    """Create a mock ChallengeManager with consistent behavior.

    - ``start()`` returns a StartResult with the given flag and service
    - ``iter_specs()`` returns the given specs, filtered by challenge_id if provided.
      If ``auto_generate_specs=True`` (default), unknown challenge_ids get a
      dynamic spec so ``POST /instances`` works with arbitrary test IDs.
    - ``stop()``, ``stop_all()``, ``check_health()`` are no-ops
    """
    mgr = MagicMock()

    mgr.start.return_value = StartResult(
        surface=AttackSurface(
            services=[
                ServiceEndpoint(
                    service_type=service_type,
                    host=host,
                    port=port,
                    label="target",
                ),
            ],
            flag_path="/flag.txt",
        ),
        flags={"main": flag},
    )
    mgr.stop.return_value = None
    mgr.stop_all.return_value = None
    mgr.check_health.return_value = True
    mgr.get_sandbox_network.return_value = None
    mgr.get_cert_volume.return_value = ""

    specs = challenge_specs or []

    def _iter_specs(
        challenge_id: str | None = None,
        difficulty: str | None = None,
        tag: str | None = None,
        **_kw,
    ):
        if challenge_id:
            patterns = [p.strip() for p in challenge_id.split(",")]
            found = False
            for s in specs:
                if any(s.id == p or s.id.startswith(p + "-") for p in patterns):
                    yield s
                    found = True
            if not found and auto_generate_specs:
                for p in patterns:
                    yield build_spec(p)
        else:
            for s in specs:
                if difficulty is not None and s.difficulty.value != difficulty:
                    continue
                if tag and tag not in s.tags:
                    continue
                yield s

    mgr.iter_specs = _iter_specs
    return mgr


# ---------------------------------------------------------------------------
# Fake node fixture — platform-side testing through the NodeClient seam.
# ---------------------------------------------------------------------------

FAKE_NODE_ID = "node-fake"
FAKE_NODE_URL = "http://fake-node:8101"
FAKE_CLUSTER_TOKEN = "test-cluster"


def make_fake_node_client(
    *,
    flag: str = "FLAG{testflag_0123456789abcdef01234567}",
    host: str = "127.0.0.1",
    port: int = 8080,
    service_type: ServiceType = ServiceType.HTTP,
    healthy: bool = True,
) -> MagicMock:
    """Build a MagicMock shaped like ``sdk.NodeClient``.

    Response payloads match the real node endpoints so platform code
    treats it as a live worker.
    """
    surface = AttackSurface(
        services=[
            ServiceEndpoint(
                service_type=service_type,
                host=host,
                port=port,
                label="target",
            ),
        ],
        flag_path="/flag.txt",
    )

    nc = MagicMock()
    nc.__enter__ = lambda self=None: nc
    nc.__exit__ = lambda *args, **kw: None

    nc.start_instance.return_value = {
        "instance_id": "placeholder",  # platform passes its own id in the request
        "status": InstanceStatus.READY,
    }
    nc.get_status.return_value = {
        "instance_id": "placeholder",
        "status": InstanceStatus.READY,
        "attack_surface": surface.model_dump(mode="json"),
        "error": None,
    }

    # verify_flag lives entirely on the platform post-step-18 — the node
    # never sees a submission. The mock keeps a no-op stub so legacy
    # callers don't AttributeError.
    nc.verify_flag.return_value = False
    nc.stop_instance.return_value = None
    nc.stop_all.return_value = None
    nc.check_health.return_value = healthy
    nc.get_agent_runtime.return_value = {
        "kind": "docker",
        "network": "",
        "proxy_gateway_ip": "",
        "ca_volume": "",
        "proxy_url": "",
        "ca_cert_pem": "",
        "target_hosts": [host],
    }
    nc.get_traffic.return_value = []
    nc.get_container_logs.return_value = ""
    nc.node_health.return_value = {"status": "ok", "running": 0, "capacity": 10}
    return nc


@contextmanager
def fake_node_context(
    backend: StateBackend,
    *,
    flag: str = "FLAG{testflag_0123456789abcdef01234567}",
    host: str = "127.0.0.1",
    port: int = 8080,
    service_type: ServiceType = ServiceType.HTTP,
    healthy: bool = True,
):
    """Register a fake node in ``backend`` and patch the NodeClient seam.

    Use in place of the legacy ``patch("...app.ChallengeManager", ...)``
    block to exercise platform routes through the remote (node) path.
    The caller still provides a mocked ``ChallengeManager`` for
    ``iter_specs`` spec lookup; this helper only covers the provider
    lifecycle calls that now travel over the NodeClient.
    """
    backend.put_node(
        FAKE_NODE_ID,
        NodeState(
            node_id=FAKE_NODE_ID,
            url=FAKE_NODE_URL,
            capacity=100,
            running=0,
            healthy=healthy,
            last_heartbeat=str(time.time()),
            last_heartbeat_ts=time.time(),
        ),
    )
    backend.set_config("cluster_key", FAKE_CLUSTER_TOKEN)

    fake_nc = make_fake_node_client(
        flag=flag,
        host=host,
        port=port,
        service_type=service_type,
        healthy=healthy,
    )

    # ``get_node_client`` lives in node_ops.py and imports NodeClient
    # there; patching at that module level covers every call site.
    with ExitStack() as stack:
        stack.enter_context(
            patch(
                "ctfy.server.node_ops.NodeClient",
                return_value=fake_nc,
            )
        )
        # Platform now generates flags locally (step 18). Pin them to a
        # deterministic mapping so submission assertions line up. All
        # declared flag ids get the same test value — tests that need
        # distinct per-flag values should override this patch.
        stack.enter_context(
            patch(
                "ctfy.server.routes.instances.generate_flags",
                side_effect=lambda flag_ids: {fid: flag for fid in flag_ids},
            )
        )
        yield fake_nc


# ---------------------------------------------------------------------------
# Shared TestClient fixtures — used by test_platform.py and test_team_isolation.py.
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_env_manager():
    return make_mock_challenge_manager(
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        auto_generate_specs=False,
        challenge_specs=[
            build_spec("WEB-001", name="SSTI Challenge", description="Flask SSTI"),
            build_spec(
                "WEB-002",
                name="SQLi Challenge",
                difficulty=Difficulty.MEDIUM,
                description="SQL injection",
            ),
            # Test IDs used by capacity/auth/lifecycle tests
            build_spec("E1"),
            build_spec("E2"),
            build_spec("RATE-001", name="Rate Test"),
            build_spec("AS-001", name="Auto-stop Test"),
        ],
    )


@pytest.fixture
def backend():
    return InMemoryBackend()


@pytest.fixture
def client(mock_env_manager, backend):
    from ctfy.server.app import create_app

    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend,
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        host="10.0.1.5",
    ):
        yield TestClient(app)
