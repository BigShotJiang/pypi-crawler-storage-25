"""Tests for ``ctfy.core.challenges_sync.ensure_challenges``.

Uses a bare git repo on the local filesystem as the "remote" to avoid
network calls while still exercising the real ``git clone`` / ``git pull``
paths end-to-end.
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest

from ctfy.core.challenges_sync import ensure_challenges

pytestmark = pytest.mark.skipif(shutil.which("git") is None, reason="git not available")


def _run(*args, cwd=None):
    result = subprocess.run(args, cwd=cwd, capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stderr
    return result


def _make_remote(tmp_path: Path) -> Path:
    """Build a bare repo with one commit so clone has something to fetch."""
    source = tmp_path / "source"
    source.mkdir()
    (source / "README.md").write_text("challenge library v1\n")
    _run("git", "init", "-q", "-b", "main", cwd=source)
    _run("git", "-c", "user.email=t@t", "-c", "user.name=t", "add", "-A", cwd=source)
    _run(
        "git",
        "-c",
        "user.email=t@t",
        "-c",
        "user.name=t",
        "-c",
        "commit.gpgsign=false",
        "commit",
        "--no-gpg-sign",
        "-q",
        "-m",
        "init",
        cwd=source,
    )

    bare = tmp_path / "remote.git"
    _run("git", "clone", "-q", "--bare", str(source), str(bare))
    return bare


def test_clone_when_missing(tmp_path):
    remote = _make_remote(tmp_path)
    dest = tmp_path / "challenges"

    ensure_challenges(dest, f"file://{remote}")

    assert (dest / ".git").exists()
    assert (dest / "README.md").read_text() == "challenge library v1\n"


def test_noop_when_repo_url_empty(tmp_path):
    dest = tmp_path / "challenges"
    ensure_challenges(dest, "")
    assert not dest.exists()


def test_skips_existing_non_git_directory(tmp_path):
    remote = _make_remote(tmp_path)
    dest = tmp_path / "challenges"
    dest.mkdir()
    (dest / "vendored.yaml").write_text("pinned: true\n")

    ensure_challenges(dest, f"file://{remote}")

    # Nothing was touched — existing non-git copy wins.
    assert (dest / "vendored.yaml").exists()
    assert not (dest / ".git").exists()
    assert not (dest / "README.md").exists()


def test_pulls_fast_forward(tmp_path):
    remote = _make_remote(tmp_path)
    dest = tmp_path / "challenges"
    ensure_challenges(dest, f"file://{remote}")

    # Add a second commit to remote via its source clone.
    source = tmp_path / "push-source"
    _run("git", "clone", "-q", str(remote), str(source))
    (source / "new.txt").write_text("v2\n")
    _run("git", "-c", "user.email=t@t", "-c", "user.name=t", "add", "-A", cwd=source)
    _run(
        "git",
        "-c",
        "user.email=t@t",
        "-c",
        "user.name=t",
        "-c",
        "commit.gpgsign=false",
        "commit",
        "--no-gpg-sign",
        "-q",
        "-m",
        "second",
        cwd=source,
    )
    _run("git", "push", "-q", "origin", "HEAD", cwd=source)

    ensure_challenges(dest, f"file://{remote}")

    assert (dest / "new.txt").read_text() == "v2\n"


def test_skips_pull_when_dirty(tmp_path):
    remote = _make_remote(tmp_path)
    dest = tmp_path / "challenges"
    ensure_challenges(dest, f"file://{remote}")

    # Make a dirty modification.
    dirty_file = dest / "README.md"
    dirty_file.write_text("LOCAL EDIT — do not clobber\n")

    # Advance remote.
    source = tmp_path / "push-source"
    _run("git", "clone", "-q", str(remote), str(source))
    (source / "extra.txt").write_text("v2\n")
    _run("git", "-c", "user.email=t@t", "-c", "user.name=t", "add", "-A", cwd=source)
    _run(
        "git",
        "-c",
        "user.email=t@t",
        "-c",
        "user.name=t",
        "-c",
        "commit.gpgsign=false",
        "commit",
        "--no-gpg-sign",
        "-q",
        "-m",
        "third",
        cwd=source,
    )
    _run("git", "push", "-q", "origin", "HEAD", cwd=source)

    ensure_challenges(dest, f"file://{remote}")

    # Local edit survived, no new file pulled.
    assert dirty_file.read_text() == "LOCAL EDIT — do not clobber\n"
    assert not (dest / "extra.txt").exists()


def test_config_field_default_populated():
    """Regression: the config field should exist and default to a real URL."""
    from ctfy.core.config import CtfyConfig

    cfg = CtfyConfig()
    assert cfg.challenges_repo.endswith(".git")
    assert cfg.challenges_repo.startswith(("http://", "https://"))
