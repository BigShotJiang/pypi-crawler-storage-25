"""Node-side ``POST /instances`` is idempotent on replay.

Platform's NodeClient retries on network errors; a retry that reaches the
node after the original request already succeeded used to fail with 409.
Now the same ``instance_id`` with the same ``challenge_id`` returns the
current status instead — the second provider start is skipped.
"""

from __future__ import annotations

from unittest.mock import MagicMock

from fastapi import FastAPI
from fastapi.testclient import TestClient

from ctfy.core.provider import StartResult
from ctfy.core.target import AttackSurface, ServiceEndpoint, ServiceType
from ctfy.server.node_app import NodeAppState, make_require_node_token
from ctfy.server.node_state import NodeInstanceStore
from ctfy.server.routes.node_instances import create_router
from ctfy.tests.conftest import build_spec

NODE_TOKEN = "test-node-token"
AUTH = {"Authorization": f"Bearer {NODE_TOKEN}"}


def _build_client(tmp_path):
    store = NodeInstanceStore(tmp_path / "node.db")
    mgr = MagicMock()
    mgr.iter_specs = lambda challenge_id=None, **kw: iter([build_spec(challenge_id or "X")])
    mgr.start.return_value = StartResult(
        surface=AttackSurface(
            services=[
                ServiceEndpoint(
                    service_type=ServiceType.HTTP,
                    host="127.0.0.1",
                    port=5000,
                    label="target",
                ),
            ],
        ),
        flags={"main": "FLAG{irrelevant}"},
    )
    mgr.stop.return_value = None
    # Simulate a post-registration node: the platform has handed us a
    # per-node token, so the node API gate will accept incoming Bearers.
    state = NodeAppState(
        registration_token="",
        public_url="http://node:8101",
        capacity=10,
        store=store,
        challenge_manager=mgr,
        node_token=NODE_TOKEN,
    )
    state.require_node_token = make_require_node_token(state)
    app = FastAPI()
    app.include_router(create_router(state), prefix="/api/v1")
    return TestClient(app), mgr


class TestNodeInstanceIdempotency:
    def test_duplicate_post_same_challenge_returns_200(self, tmp_path):
        client, mgr = _build_client(tmp_path)
        body = {
            "challenge_id": "WEB-001",
            "instance_id": "id-1",
            "ttl": 300,
            "flags": {"main": "FLAG{a}"},
        }
        r1 = client.post("/api/v1/instances", json=body, headers=AUTH)
        assert r1.status_code == 200, r1.text
        status1 = r1.json()["status"]

        r2 = client.post("/api/v1/instances", json=body, headers=AUTH)
        assert r2.status_code == 200, r2.text
        assert r2.json() == {"instance_id": "id-1", "status": status1}
        # Provider is NOT re-invoked on retry — that would spawn a second container.
        assert mgr.start.call_count == 1

    def test_duplicate_post_different_challenge_returns_409(self, tmp_path):
        client, mgr = _build_client(tmp_path)
        body1 = {
            "challenge_id": "WEB-001",
            "instance_id": "id-1",
            "ttl": 300,
            "flags": {"main": "FLAG{a}"},
        }
        body2 = {**body1, "challenge_id": "WEB-002"}
        assert client.post("/api/v1/instances", json=body1, headers=AUTH).status_code == 200
        r = client.post("/api/v1/instances", json=body2, headers=AUTH)
        assert r.status_code == 409
        assert "different challenge" in r.json()["detail"].lower()
        # Only the first start was executed.
        assert mgr.start.call_count == 1
