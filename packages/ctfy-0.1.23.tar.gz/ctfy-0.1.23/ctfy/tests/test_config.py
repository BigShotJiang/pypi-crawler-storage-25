"""Tests for ``ctfy.core.config.CtfyConfig`` field constraints and invariants."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from ctfy.core.config import CtfyConfig
from ctfy.core.exceptions import ConfigError


class TestFieldConstraints:
    def test_server_port_below_min_rejected(self):
        with pytest.raises(ValidationError):
            CtfyConfig(server_port=0)

    def test_server_port_above_max_rejected(self):
        with pytest.raises(ValidationError):
            CtfyConfig(server_port=70000)


class TestInvariants:
    def test_platform_url_must_have_scheme(self):
        with pytest.raises(ConfigError, match="http://"):
            CtfyConfig(platform_url="server:8100")

    def test_platform_url_https_ok(self):
        c = CtfyConfig(platform_url="https://server:8100")
        assert c.platform_url == "https://server:8100"


class TestDefaults:
    def test_defaults_construct(self):
        """A bare ``CtfyConfig()`` must succeed and satisfy all invariants."""
        c = CtfyConfig()
        assert c.server_port == 8100
