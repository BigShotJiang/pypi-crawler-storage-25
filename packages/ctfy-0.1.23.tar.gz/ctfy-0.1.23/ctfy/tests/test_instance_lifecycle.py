"""Unit tests for ``ctfy.server.instance_lifecycle`` helpers."""

from __future__ import annotations

from ctfy.core.target import AttackSurface, ServiceEndpoint, ServiceType
from ctfy.server.instance_lifecycle import _rewrite_surface_hosts


def _surface(host: str) -> AttackSurface:
    return AttackSurface(
        services=[ServiceEndpoint(service_type=ServiceType.HTTP, host=host, port=39815)]
    )


class TestRewriteSurfaceHosts:
    def test_loopback_replaced_with_node_public_host(self):
        rewritten = _rewrite_surface_hosts(_surface("127.0.0.1"), "http://10.0.0.5:8101")
        assert rewritten.services[0].host == "10.0.0.5"
        assert rewritten.services[0].port == 39815

    def test_localhost_and_zero_bind_also_rewritten(self):
        for loopback in ("localhost", "0.0.0.0", "::1"):
            out = _rewrite_surface_hosts(_surface(loopback), "http://node-1.example:8101")
            assert out.services[0].host == "node-1.example", loopback

    def test_non_loopback_host_left_alone(self):
        """A provider that already knows the reachable host must not be
        clobbered by the rewrite."""
        out = _rewrite_surface_hosts(_surface("target.svc.local"), "http://10.0.0.5:8101")
        assert out.services[0].host == "target.svc.local"

    def test_unparseable_node_url_is_noop(self):
        """If the node URL has no hostname (shouldn't happen in practice,
        but defensive), leave the surface untouched rather than erasing
        the host."""
        out = _rewrite_surface_hosts(_surface("127.0.0.1"), "")
        assert out.services[0].host == "127.0.0.1"

    def test_loopback_node_url_is_noop(self):
        """A same-host dev setup where the node registers as 127.0.0.1 has
        nothing useful to rewrite to — leave the loopback in place so local
        ``curl`` from the same box keeps working."""
        out = _rewrite_surface_hosts(_surface("127.0.0.1"), "http://127.0.0.1:8101")
        assert out.services[0].host == "127.0.0.1"
