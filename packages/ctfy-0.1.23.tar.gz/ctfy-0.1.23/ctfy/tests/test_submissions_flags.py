"""End-to-end coverage for multi-flag challenges.

Covers a 2-flag challenge (foothold / root) driven through the real
FastAPI stack: ``start_instance`` → submit first flag → instance is
still running → submit second flag → auto-stop fires + archive row
gets ``solved=True`` with both flag ids recorded.
"""

from __future__ import annotations

import time
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.tests.conftest import (
    build_spec,
    fake_node_context,
    make_mock_challenge_manager,
    start_instance_and_wait,
)

FLAGS = {
    "foothold": "FLAG{foothold_0123456789abcdef0123456789abcdef0123}",
    "root":     "FLAG{root_0123456789abcdef0123456789abcdef01234567}",
}


@pytest.fixture
def multi_flag_client():
    """TestClient wired up with a single 2-flag challenge ``KIOSK-01``."""
    backend = InMemoryBackend()
    spec = build_spec(
        "KIOSK-01",
        name="Intranet Kiosk",
        description="Two-stage challenge",
        flags=["foothold", "root"],
    )
    mgr = make_mock_challenge_manager(
        challenge_specs=[spec],
        auto_generate_specs=False,
    )

    from ctfy.server.app import create_app

    with patch("ctfy.server.app.ChallengeManager", return_value=mgr):
        app = create_app(external_host="10.0.1.5", backend=backend)

    # Pin the flag dict the platform hands to the fake node so tests can
    # submit deterministic values.
    with fake_node_context(backend, flag="__unused__") as _:
        # Override the generate_flags patch so it yields per-flag values.
        with patch(
            "ctfy.server.routes.instances.generate_flags",
            side_effect=lambda ids: {fid: FLAGS[fid] for fid in ids},
        ):
            yield TestClient(app), backend


def _register_team(client: TestClient, name: str = "RedTeam") -> dict:
    r = client.post("/api/v1/teams", json={"name": name, "agent": "claude-code"})
    r.raise_for_status()
    return r.json()


def _submit(client: TestClient, token: str, flag: str) -> dict:
    r = client.post(
        "/api/v1/submissions",
        json={"challenge_id": "KIOSK-01", "flag": flag},
        headers={"Authorization": f"Bearer {token}"},
    )
    return r.json()


class TestMultiFlagSubmission:
    def test_partial_solve_keeps_instance_running(self, multi_flag_client):
        client, backend = multi_flag_client
        team = _register_team(client)
        auth = {"Authorization": f"Bearer {team['token']}"}
        start_instance_and_wait(client, "KIOSK-01", headers=auth)

        data = _submit(client, team["token"], FLAGS["foothold"])
        assert data["correct"] is True
        assert data["flag_id"] == "foothold"
        assert data["challenge_fully_solved"] is False
        # Still running — auto-stop only fires after the final flag.
        resolve = client.get(
            "/api/v1/instances/resolve",
            params={"challenge_id": "KIOSK-01"},
            headers=auth,
        )
        assert resolve.status_code == 200

    def test_second_flag_triggers_full_solve_and_autostop(self, multi_flag_client):
        client, backend = multi_flag_client
        team = _register_team(client)
        auth = {"Authorization": f"Bearer {team['token']}"}
        start_instance_and_wait(client, "KIOSK-01", headers=auth)

        first = _submit(client, team["token"], FLAGS["foothold"])
        assert first["challenge_fully_solved"] is False

        second = _submit(client, team["token"], FLAGS["root"])
        assert second["correct"] is True
        assert second["flag_id"] == "root"
        assert second["challenge_fully_solved"] is True

        # Instance is auto-stopped asynchronously; poll briefly.
        for _ in range(30):
            resolve = client.get(
                "/api/v1/instances/resolve",
                params={"challenge_id": "KIOSK-01"},
                headers=auth,
            )
            if resolve.status_code == 404:
                break
            time.sleep(0.1)
        else:
            pytest.fail("instance should have been auto-stopped")

    def test_wrong_flag_returns_null_flag_id(self, multi_flag_client):
        client, _ = multi_flag_client
        team = _register_team(client)
        auth = {"Authorization": f"Bearer {team['token']}"}
        start_instance_and_wait(client, "KIOSK-01", headers=auth)

        data = _submit(client, team["token"], "FLAG{nope}")
        assert data["correct"] is False
        assert data["flag_id"] is None
        assert data["challenge_fully_solved"] is False

    def test_reverse_order_still_fully_solves(self, multi_flag_client):
        """Flags are independent; order doesn't matter."""
        client, _ = multi_flag_client
        team = _register_team(client)
        auth = {"Authorization": f"Bearer {team['token']}"}
        start_instance_and_wait(client, "KIOSK-01", headers=auth)

        a = _submit(client, team["token"], FLAGS["root"])
        assert a["flag_id"] == "root"
        assert a["challenge_fully_solved"] is False

        b = _submit(client, team["token"], FLAGS["foothold"])
        assert b["flag_id"] == "foothold"
        assert b["challenge_fully_solved"] is True

    def test_duplicate_correct_flag_does_not_double_solve(self, multi_flag_client):
        client, backend = multi_flag_client
        team = _register_team(client)
        auth = {"Authorization": f"Bearer {team['token']}"}
        start_instance_and_wait(client, "KIOSK-01", headers=auth)

        a = _submit(client, team["token"], FLAGS["foothold"])
        assert a["solve_rank"] == 1

        b = _submit(client, team["token"], FLAGS["foothold"])
        assert b["correct"] is True
        assert b["flag_id"] == "foothold"
        # Second hit does NOT register a new Solve → solve_rank stays 0.
        assert b["solve_rank"] == 0

    def test_scoreboard_counts_flags_solved(self, multi_flag_client):
        client, _ = multi_flag_client
        team = _register_team(client)
        auth = {"Authorization": f"Bearer {team['token']}"}
        start_instance_and_wait(client, "KIOSK-01", headers=auth)

        _submit(client, team["token"], FLAGS["foothold"])
        # Partial solve: 1 flag, 0 fully-solved challenges.
        sb = client.get("/api/v1/scoreboard").json()["items"]
        row = next(r for r in sb if r["team_id"] == team["team_id"])
        assert row["flags_solved"] == 1
        assert row["solved"] == 0

        _submit(client, team["token"], FLAGS["root"])
        sb = client.get("/api/v1/scoreboard").json()["items"]
        row = next(r for r in sb if r["team_id"] == team["team_id"])
        assert row["flags_solved"] == 2
        assert row["solved"] == 1

    def test_challenge_info_exposes_flag_ids(self, multi_flag_client):
        client, _ = multi_flag_client
        _register_team(client)  # needs auth? challenges endpoint is public
        info = client.get("/api/v1/challenges/KIOSK-01").json()
        assert info["flag_ids"] == ["foothold", "root"]
        assert info["flag_solves"] == {"foothold": 0, "root": 0}
