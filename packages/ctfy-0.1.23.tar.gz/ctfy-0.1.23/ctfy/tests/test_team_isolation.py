"""Cross-team authorization tests.

Each test asserts that one team cannot read or mutate another team's
resources, and that anonymous callers cannot operate on team-owned state.
The ``client`` / ``backend`` / ``mock_env_manager`` fixtures live in
``conftest.py`` and wire a mocked ChallengeManager + fake worker node.
"""

from __future__ import annotations

import pytest

from ctfy.tests.conftest import start_instance_and_wait

FLAG = "FLAG{deadbeef0123456789abcdef01234567}"


def _register_team(client, name):
    r = client.post("/api/v1/teams", json={"name": name, "agent": "test"})
    assert r.status_code == 200, r.text
    body = r.json()
    return body, {"Authorization": f"Bearer {body['token']}"}


# -- GET /instances --------------------------------------------------------


class TestInstancesListing:
    def test_anonymous_does_not_see_owned_instances(self, client):
        """Anonymous callers used to enumerate every team's instances; that's the bug we fixed."""
        _, auth_a = _register_team(client, "Alpha")
        a_id = start_instance_and_wait(client, "WEB-001", headers=auth_a)

        items = client.get("/api/v1/instances").json()["items"]
        ids = {item["instance_id"] for item in items}
        assert a_id not in ids
        # Whatever an anonymous caller does see, none of it is owned by a team.
        for item in items:
            assert not item["team_id"]

    def test_team_only_sees_own_instances(self, client):
        team_a, auth_a = _register_team(client, "Alpha")
        team_b, auth_b = _register_team(client, "Bravo")

        a_id = start_instance_and_wait(client, "WEB-001", headers=auth_a)
        b_id = start_instance_and_wait(client, "WEB-002", headers=auth_b)

        a_items = client.get("/api/v1/instances", headers=auth_a).json()["items"]
        a_ids = {item["instance_id"] for item in a_items}
        assert a_id in a_ids
        assert b_id not in a_ids
        for item in a_items:
            assert item["team_id"] == team_a["team_id"]

        b_items = client.get("/api/v1/instances", headers=auth_b).json()["items"]
        b_ids = {item["instance_id"] for item in b_items}
        assert b_id in b_ids
        assert a_id not in b_ids


# -- per-instance operations -----------------------------------------------


class TestInstanceOperations:
    @pytest.fixture
    def setup(self, client):
        team_a, auth_a = _register_team(client, "Alpha")
        team_b, auth_b = _register_team(client, "Bravo")
        a_id = start_instance_and_wait(client, "WEB-001", headers=auth_a)
        return team_a, auth_a, team_b, auth_b, a_id

    def test_anonymous_cannot_read_status(self, client, setup):
        _, _, _, _, a_id = setup
        r = client.get(f"/api/v1/instances/{a_id}/status")
        assert r.status_code in (401, 403)

    def test_other_team_cannot_read_status(self, client, setup):
        _, _, _, auth_b, a_id = setup
        r = client.get(f"/api/v1/instances/{a_id}/status", headers=auth_b)
        assert r.status_code == 403

    def test_other_team_cannot_verify_flag(self, client, setup):
        """The flag-verify endpoint must not echo the canonical flag to outsiders."""
        _, _, _, auth_b, a_id = setup
        r = client.post(
            f"/api/v1/instances/{a_id}/verify-flag",
            json={"claimed_flag": FLAG},
            headers=auth_b,
        )
        assert r.status_code == 403

    def test_other_team_cannot_renew(self, client, setup):
        _, _, _, auth_b, a_id = setup
        r = client.post(f"/api/v1/instances/{a_id}/renew?ttl=600", headers=auth_b)
        assert r.status_code == 403

    def test_other_team_cannot_stop(self, client, setup):
        _, auth_a, _, auth_b, a_id = setup
        r = client.delete(f"/api/v1/instances/{a_id}", headers=auth_b)
        assert r.status_code == 403
        # And the instance is still alive for the owner.
        r = client.get(f"/api/v1/instances/{a_id}/status", headers=auth_a)
        assert r.status_code == 200

    def test_anonymous_cannot_stop(self, client, setup):
        _, auth_a, _, _, a_id = setup
        r = client.delete(f"/api/v1/instances/{a_id}")
        assert r.status_code in (401, 403)
        r = client.get(f"/api/v1/instances/{a_id}/status", headers=auth_a)
        assert r.status_code == 200

    def test_other_team_cannot_read_traffic(self, client, setup):
        _, _, _, auth_b, a_id = setup
        r = client.get(f"/api/v1/instances/{a_id}/traffic", headers=auth_b)
        assert r.status_code == 403


# -- /instances/resolve ----------------------------------------------------


class TestResolveScopedToTeam:
    def test_resolve_only_finds_own_instance(self, client):
        team_a, auth_a = _register_team(client, "Alpha")
        _, auth_b = _register_team(client, "Bravo")
        start_instance_and_wait(client, "WEB-001", headers=auth_a)

        # Owner can resolve.
        r = client.get("/api/v1/instances/resolve?challenge_id=WEB-001", headers=auth_a)
        assert r.status_code == 200

        # Bravo started no WEB-001 instance — must 404, not see Alpha's.
        r = client.get("/api/v1/instances/resolve?challenge_id=WEB-001", headers=auth_b)
        assert r.status_code == 404


# -- /submissions ----------------------------------------------------------


class TestSubmissionsListing:
    def test_each_team_only_sees_own_submissions(self, client):
        team_a, auth_a = _register_team(client, "Alpha")
        team_b, auth_b = _register_team(client, "Bravo")
        start_instance_and_wait(client, "WEB-001", headers=auth_a)
        start_instance_and_wait(client, "WEB-001", headers=auth_b)

        client.post(
            "/api/v1/submissions",
            json={"challenge_id": "WEB-001", "flag": "FLAG{wrong-from-a}"},
            headers=auth_a,
        )
        client.post(
            "/api/v1/submissions",
            json={"challenge_id": "WEB-001", "flag": "FLAG{wrong-from-b}"},
            headers=auth_b,
        )

        a_subs = client.get("/api/v1/submissions", headers=auth_a).json()["items"]
        assert len(a_subs) == 1
        assert all(s["team_id"] == team_a["team_id"] for s in a_subs)

        b_subs = client.get("/api/v1/submissions", headers=auth_b).json()["items"]
        assert len(b_subs) == 1
        assert all(s["team_id"] == team_b["team_id"] for s in b_subs)


# -- /activities -----------------------------------------------------------


class TestActivitiesIsolation:
    def _make_two_teams_with_history(self, client):
        team_a, auth_a = _register_team(client, "Alpha")
        team_b, auth_b = _register_team(client, "Bravo")
        start_instance_and_wait(client, "WEB-001", headers=auth_a)
        start_instance_and_wait(client, "WEB-001", headers=auth_b)

        # Alpha solves; Bravo also has a wrong attempt that must not leak.
        client.post(
            "/api/v1/submissions",
            json={"challenge_id": "WEB-001", "flag": FLAG},
            headers=auth_a,
        )
        client.post(
            "/api/v1/submissions",
            json={"challenge_id": "WEB-001", "flag": "FLAG{secret-strategy}"},
            headers=auth_b,
        )
        return (team_a, auth_a), (team_b, auth_b)

    def test_authenticated_team_sees_own_full_history(self, client):
        (team_a, auth_a), _ = self._make_two_teams_with_history(client)
        r = client.get("/api/v1/activities", headers=auth_a)
        assert r.status_code == 200
        items = r.json()["items"]
        assert items, "owner should see their own activity"
        for a in items:
            assert a["team_id"] == team_a["team_id"]

    def test_cross_team_id_query_param_is_ignored(self, client):
        """``?team_id=<other>`` must not be honoured — the caller only ever
        sees their own team's activity, regardless of what they ask for."""
        (team_a, auth_a), (team_b, _) = self._make_two_teams_with_history(client)
        r = client.get(
            f"/api/v1/activities?team_id={team_b['team_id']}",
            headers=auth_a,
        )
        assert r.status_code == 200
        team_ids = {a["team_id"] for a in r.json()["items"]}
        assert team_ids == {team_a["team_id"]}

    def test_anonymous_caller_is_rejected(self, client):
        """Activities are now a strictly authenticated resource."""
        self._make_two_teams_with_history(client)
        r = client.get("/api/v1/activities")
        # 401 when the bearer header is missing entirely (HTTPBearer
        # rejects at the security layer); 403 when a bogus token is sent.
        assert r.status_code in (401, 403)

    def test_bogus_token_is_rejected(self, client):
        r = client.get(
            "/api/v1/activities",
            headers={"Authorization": "Bearer not-a-real-token"},
        )
        assert r.status_code == 403

    def test_node_lifecycle_events_not_exposed_to_team(self, client):
        """Node events carry an empty team_id and must not surface in any
        team's feed — they're operational signals, not team-scoped."""
        (_, auth_a), _ = self._make_two_teams_with_history(client)
        # Register a node so at least one node_registered event exists.
        client.post(
            "/api/v1/nodes/register",
            json={"url": "http://n-isolation:8100", "display_name": "n-iso"},
        )
        r = client.get("/api/v1/activities", headers=auth_a)
        assert r.status_code == 200
        events = {a["event"] for a in r.json()["items"]}
        assert "node_registered" not in events
        assert "node_unhealthy" not in events
        assert "node_removed" not in events


# -- check_ownership semantics --------------------------------------------


class TestCheckOwnership:
    """Direct unit tests for the helper that gates per-instance routes."""

    def test_anonymous_cannot_touch_owned_resource(self):
        from ctfy.core.exceptions import ForbiddenError
        from ctfy.core.state.models import InstanceState
        from ctfy.server.auth import check_ownership

        owned = InstanceState(instance_id="i1", team_id="team-a")
        with pytest.raises(ForbiddenError):
            check_ownership(owned, None, "instance")

    def test_other_team_cannot_touch_owned_resource(self):
        from ctfy.core.exceptions import ForbiddenError
        from ctfy.core.state.models import InstanceState, TeamState
        from ctfy.server.auth import check_ownership

        owned = InstanceState(instance_id="i1", team_id="team-a")
        other = TeamState(team_id="team-b", name="B")
        with pytest.raises(ForbiddenError):
            check_ownership(owned, other, "instance")

    def test_owner_passes(self):
        from ctfy.core.state.models import InstanceState, TeamState
        from ctfy.server.auth import check_ownership

        owned = InstanceState(instance_id="i1", team_id="team-a")
        owner = TeamState(team_id="team-a", name="A")
        check_ownership(owned, owner, "instance")  # no raise

    def test_unowned_resource_is_open(self):
        """Unowned (anonymous) resources stay reachable — there is nothing to gate."""
        from ctfy.core.state.models import InstanceState
        from ctfy.server.auth import check_ownership

        unowned = InstanceState(instance_id="i1", team_id="")
        check_ownership(unowned, None, "instance")  # no raise
