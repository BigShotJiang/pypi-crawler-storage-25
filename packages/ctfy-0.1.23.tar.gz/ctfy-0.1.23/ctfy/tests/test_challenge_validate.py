"""Tests for ``ctfy.core.challenge_validate.validate_dir``.

The validator delegates to the upstream ``scripts/audit.py`` when present
and otherwise falls back to a pydantic-only schema check. These tests
exercise the fallback path (no audit script in the temp dir), which is
equivalent to what ``ctfy challenge ls`` uses when surfacing parse
warnings.
"""

from __future__ import annotations

from pathlib import Path

import yaml

from ctfy.core.challenge_validate import validate_dir


def _write_metadata(base: Path, challenge_id: str, body: dict | str) -> Path:
    d = base / challenge_id
    d.mkdir(parents=True, exist_ok=True)
    content = body if isinstance(body, str) else yaml.safe_dump(body, sort_keys=False)
    (d / "metadata.yaml").write_text(content)
    return d


def _valid_body(challenge_id: str = "CTFARENA-001") -> dict:
    return {
        "name": f"Spec {challenge_id}",
        "description": "A challenge.",
        "difficulty": "easy",
        "tags": ["idor", "web"],
    }


class TestHappyPath:
    def test_valid_spec_passes(self, tmp_path):
        _write_metadata(tmp_path, "CTFARENA-001", _valid_body())
        findings = validate_dir(tmp_path, challenge_id="CTFARENA-001")
        assert len(findings) == 1
        assert findings[0].ok, findings[0].reason

    def test_scan_ignores_non_directories(self, tmp_path):
        (tmp_path / "not-a-challenge.txt").write_text("x")
        _write_metadata(tmp_path, "CTFARENA-001", _valid_body())
        findings = validate_dir(tmp_path)
        assert len(findings) == 1


class TestSchemaFailures:
    def test_missing_metadata_not_reported(self, tmp_path):
        """Empty directories are silently skipped — the validator only speaks
        about things that look like challenges."""
        (tmp_path / "CTFARENA-001").mkdir()
        findings = validate_dir(tmp_path, challenge_id="CTFARENA-001")
        assert findings == []

    def test_yaml_parse_error(self, tmp_path):
        _write_metadata(tmp_path, "CTFARENA-001", "not: valid: yaml: [")
        findings = validate_dir(tmp_path, challenge_id="CTFARENA-001")
        assert len(findings) == 1
        assert not findings[0].ok

    def test_unknown_top_level_field_rejected(self, tmp_path):
        body = _valid_body()
        body["origin"] = "legacy"  # forbidden (META005 equivalent)
        _write_metadata(tmp_path, "CTFARENA-001", body)
        findings = validate_dir(tmp_path, challenge_id="CTFARENA-001")
        assert not findings[0].ok

    def test_bad_difficulty_rejected(self, tmp_path):
        body = _valid_body()
        body["difficulty"] = "expert"
        _write_metadata(tmp_path, "CTFARENA-001", body)
        findings = validate_dir(tmp_path, challenge_id="CTFARENA-001")
        assert not findings[0].ok

    def test_empty_tags_rejected(self, tmp_path):
        body = _valid_body()
        body["tags"] = []
        _write_metadata(tmp_path, "CTFARENA-001", body)
        findings = validate_dir(tmp_path, challenge_id="CTFARENA-001")
        assert not findings[0].ok
