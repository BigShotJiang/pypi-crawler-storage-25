"""End-to-end test with a REAL Docker instance (not mocked).

Requires Docker daemon running. Skipped if Docker is unavailable.

Validates the full post-decoupling pipeline:

  Platform uvicorn  →  per-node inbound-token HTTP  →  Node uvicorn
       ↓                                                   ↓
   InstanceState DB                              DockerProvider → real container
       ↓                                                   ↓
   /submissions (local verify)                    Host port forwarding
"""

from __future__ import annotations

import os
import secrets as _secrets
import threading
import time

import httpx
import pytest


# Skip if Docker unavailable or custom images not built
def _docker_ready():
    try:
        import docker

        client = docker.from_env()
        client.ping()
        # Check that required custom images exist
        client.images.get("ctfy-mitmproxy")
        return True
    except Exception:
        return False


HAS_DOCKER = _docker_ready()

pytestmark = pytest.mark.skipif(
    not HAS_DOCKER, reason="Docker not available or pentest images not built"
)

PLATFORM_PORT = 18100
NODE_PORT = 18101
ADMIN_TOKEN = f"e2e-admin-{_secrets.token_hex(8)}"
PLATFORM_URL = f"http://127.0.0.1:{PLATFORM_PORT}"
NODE_URL = f"http://127.0.0.1:{NODE_PORT}"


def _start_uvicorn(app, port: int) -> threading.Thread:
    import uvicorn

    t = threading.Thread(
        target=lambda: uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning"),
        daemon=True,
    )
    t.start()
    return t


@pytest.fixture(scope="module")
def cluster():
    """Bring up an in-process platform + node pair against the real Docker.

    The platform owns the flag + verify path (step 18); the node owns
    docker.sock. Admin token authenticates invite minting + operator
    endpoints; the platform then issues a one-time registration token
    for the node and per-node bearer tokens at register time.
    """
    from ctfy.core.config import CtfyConfig
    from ctfy.core.state import InMemoryBackend
    from ctfy.server.app import create_app
    from ctfy.server.node_app import create_node_app
    from ctfy.server.node_state import NodeInstanceStore

    config = CtfyConfig()

    backend = InMemoryBackend()
    backend.set_config("admin_key", ADMIN_TOKEN)
    platform = create_app(config, external_host="127.0.0.1", backend=backend)
    _start_uvicorn(platform, PLATFORM_PORT)

    # Wait for platform
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        try:
            httpx.get(f"{PLATFORM_URL}/api/v1/health", timeout=2).raise_for_status()
            break
        except Exception:
            time.sleep(0.3)
    else:
        pytest.fail("Platform failed to start")

    # Mint a one-time invite for the node.
    admin_hdr = {"Authorization": f"Bearer {ADMIN_TOKEN}"}
    inv_resp = httpx.post(
        f"{PLATFORM_URL}/api/v1/nodes/invites",
        headers=admin_hdr,
        json={"ttl_seconds": 600},
        timeout=5,
    )
    inv_resp.raise_for_status()
    registration_token = inv_resp.json()["registration_token"]

    # Isolated per-test node SQLite so a prior run can't pollute us.
    import tempfile

    tmp = tempfile.mkdtemp(prefix="ctfy-e2e-node-")
    store = NodeInstanceStore(os.path.join(tmp, "node.db"))
    os.environ["CTFY_PLATFORM_URL"] = PLATFORM_URL
    os.environ["CTFY_NODE_PUBLIC_URL"] = NODE_URL
    node = create_node_app(
        config,
        registration_token=registration_token,
        public_url=NODE_URL,
        platform_url=PLATFORM_URL,
        capacity=4,
        store=store,
    )
    _start_uvicorn(node, NODE_PORT)

    # Wait for the node to self-register.
    deadline = time.monotonic() + 20
    headers = admin_hdr
    while time.monotonic() < deadline:
        try:
            r = httpx.get(f"{PLATFORM_URL}/api/v1/nodes", headers=headers, timeout=2)
            if r.status_code == 200 and len(r.json().get("items", [])) >= 1:
                break
        except Exception:
            pass
        time.sleep(0.3)
    else:
        pytest.fail("Node did not self-register with platform")

    yield PLATFORM_URL


@pytest.fixture
def team(cluster):
    """Register a team and return (url, token, team_id)."""
    resp = httpx.post(
        f"{cluster}/api/v1/teams",
        json={"name": "Docker E2E Team", "agent": "test"},
        timeout=5,
    )
    data = resp.json()
    return cluster, data["token"], data["team_id"]


class TestRealDockerE2E:
    """Tests with real Docker containers. Slow but validates the full stack."""

    def test_start_instance_and_access(self, team):
        """Start XBOW-001, verify HTTP endpoint is accessible."""
        url, token, _team_id = team
        headers = {"Authorization": f"Bearer {token}"}

        # Start instance (async)
        resp = httpx.post(
            f"{url}/api/v1/instances",
            json={"challenge_id": "XBOW-001", "ttl": 300},
            headers=headers,
            timeout=30,
        )
        assert resp.status_code == 202, f"Start failed: {resp.text}"
        instance_id = resp.json()["instance_id"]

        # Poll until ready (Docker build + startup can take a while)
        deadline = time.monotonic() + 180  # 3 minute timeout
        surface = None
        last_data: dict = {}
        while time.monotonic() < deadline:
            s = httpx.get(
                f"{url}/api/v1/instances/{instance_id}/status",
                headers=headers,
                timeout=10,
            )
            last_data = s.json()
            if last_data.get("status") == "ready":
                surface = last_data.get("attack_surface")
                break
            if last_data.get("status") == "error":
                pytest.fail(f"Instance failed: {last_data.get('error')}")
            time.sleep(3)
        else:
            httpx.delete(f"{url}/api/v1/instances/{instance_id}", headers=headers, timeout=30)
            pytest.fail(f"Instance not ready after 180s; last status: {last_data}")

        assert surface is not None
        assert len(surface["services"]) > 0

        # Access the HTTP service
        svc = surface["services"][0]
        host = svc["host"]
        if host in ("0.0.0.0",):
            host = "127.0.0.1"
        target_url = f"http://{host}:{svc['port']}"
        try:
            r = httpx.get(target_url, timeout=10, follow_redirects=True)
            assert r.status_code < 500, f"Target returned {r.status_code}"
        finally:
            # Always clean up
            httpx.delete(f"{url}/api/v1/instances/{instance_id}", headers=headers, timeout=30)

    def test_node_registered(self, cluster):
        """Sanity-check that the fixture truly registered the node."""
        # /nodes is public; no auth needed.
        r = httpx.get(f"{cluster}/api/v1/nodes", timeout=5)
        assert r.status_code == 200
        items = r.json()["items"]
        assert len(items) >= 1
        assert any(n["url"] == NODE_URL for n in items)

    def test_activity_logged(self, team):
        """Verify that team registration creates an activity event."""
        url, token, _team_id = team
        headers = {"Authorization": f"Bearer {token}"}
        resp = httpx.get(
            f"{url}/api/v1/activities?event=team_registered",
            headers=headers,
            timeout=5,
        )
        assert resp.status_code == 200
        acts = resp.json()["items"]
        assert any(a["event"] == "team_registered" for a in acts)
