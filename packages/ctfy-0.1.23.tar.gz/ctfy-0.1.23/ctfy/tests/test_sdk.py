"""End-to-end tests for the Python SDK (PlatformClient)."""

from unittest.mock import patch

import pytest
from starlette.testclient import TestClient as StarletteClient

from ctfy.core.state import InMemoryBackend
from ctfy.server.models import (
    ScoreboardEntry,
    SubmissionResponse,
)
from ctfy.tests.conftest import build_spec, start_instance_and_wait

SDK_FLAG = "FLAG{sdk_test_flag_0123456789abcdef}"


def _make_app(backend):
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import make_mock_challenge_manager

    mock_mgr = make_mock_challenge_manager(
        flag=SDK_FLAG,
        port=9090,
        challenge_specs=[
            build_spec("SDK-001", name="SDK Test"),
        ],
    )

    with patch("ctfy.server.app.ChallengeManager", return_value=mock_mgr):
        return create_app(external_host="10.0.1.5", backend=backend)


@pytest.fixture
def platform():
    """Returns (authenticated TestClient, team_data, raw TestClient)."""
    from ctfy.tests.conftest import fake_node_context

    backend = InMemoryBackend()
    app = _make_app(backend)

    with fake_node_context(backend, flag=SDK_FLAG, port=9090):
        raw = StarletteClient(app)

        # Register team
        resp = raw.post("/api/v1/teams", json={"name": "SDK Team", "agent": "test-agent"})
        team = resp.json()

        auth = StarletteClient(app, headers={"Authorization": f"Bearer {team['token']}"})

        yield auth, team, raw


class TestSDKTeams:
    def test_register(self, platform):
        _, _, raw = platform
        r = raw.post("/api/v1/teams", json={"name": "New", "agent": "x"})
        assert r.json()["token"].startswith("pt_")

    def test_list(self, platform):
        auth, _, _ = platform
        assert len(auth.get("/api/v1/teams").json()["items"]) >= 1


class TestSDKChallenges:
    def test_list(self, platform):
        auth, _, _ = platform
        chals = auth.get("/api/v1/challenges").json()["items"]
        assert len(chals) == 1
        assert chals[0]["id"] == "SDK-001"


class TestSDKSubmissions:
    def _start(self, c):
        start_instance_and_wait(c, "SDK-001")

    def test_correct(self, platform):
        auth, _, _ = platform
        self._start(auth)
        r = auth.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "SDK-001",
                "flag": "FLAG{sdk_test_flag_0123456789abcdef}",
            },
        )
        assert r.json()["correct"] is True
        assert r.json()["solve_time_s"] >= 0

    def test_wrong(self, platform):
        auth, _, _ = platform
        self._start(auth)
        r = auth.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "SDK-001",
                "flag": "FLAG{nope}",
            },
        )
        assert r.json()["correct"] is False


class TestSDKScoreboard:
    def test_ranking(self, platform):
        auth, _, _ = platform
        start_instance_and_wait(auth, "SDK-001")
        auth.post(
            "/api/v1/submissions",
            json={"challenge_id": "SDK-001", "flag": "FLAG{sdk_test_flag_0123456789abcdef}"},
        )
        board = auth.get("/api/v1/scoreboard").json()["items"]
        assert board[0]["solved"] == 1


class TestSDKClientWrapper:
    """Test the actual PlatformClient class methods (unit test)."""

    def test_submit_result_dataclass(self):
        r = SubmissionResponse(submission_id="abc", correct=True, solve_time_s=12.5)
        assert r.correct is True
        assert r.solve_time_s == 12.5

    def test_scoreboard_row_dataclass(self):
        r = ScoreboardEntry(
            rank=1,
            team_id="t1",
            team_name="A",
            agent="x",
            solved=5,
            attempts=10,
            last_solve_at="2026-01-01",
        )
        assert r.solved == 5
        assert r.attempts == 10


class TestSDKFullLifecycle:
    def test_e2e(self, platform):
        """Register → challenges → start → submit → scoreboard → team stats."""
        auth, team, _ = platform

        chals = auth.get("/api/v1/challenges").json()["items"]
        assert len(chals) >= 1

        start_instance_and_wait(auth, chals[0]["id"])

        r = auth.post(
            "/api/v1/submissions",
            json={
                "challenge_id": chals[0]["id"],
                "flag": "FLAG{sdk_test_flag_0123456789abcdef}",
            },
        )
        assert r.json()["correct"] is True

        board = auth.get("/api/v1/scoreboard").json()["items"]
        me = [r for r in board if r["team_id"] == team["team_id"]]
        assert me[0]["solved"] == 1

        info = auth.get(f"/api/v1/teams/{team['team_id']}").json()
        assert info["solves"] == 1


# ============================================================================
# True E2E: a real uvicorn server in a background thread + real PlatformClient
# round trips. Verifies SDK methods (return types, parameter handling) against
# live HTTP, not just TestClient.
# ============================================================================

import socket  # noqa: E402
import threading  # noqa: E402
import time  # noqa: E402
from unittest.mock import MagicMock  # noqa: E402

import uvicorn  # noqa: E402

from ctfy.core.provider import StartResult  # noqa: E402
from ctfy.core.target import AttackSurface, ServiceEndpoint, ServiceType  # noqa: E402
from ctfy.sdk import PlatformClient  # noqa: E402
from ctfy.server.models import (  # noqa: E402
    ChallengeInfo,
    ChallengeStats,
    HealthResponse,
    InstanceInfo,
    InstanceStatusResponse,
    RenewResponse,
    TeamInfo,
    TeamResponse,
    VerifyFlagResponse,
)

E2E_FLAG = "FLAG{sdk_e2e_test_flag_abcdef0123456789}"


def _make_e2e_app():
    mock_mgr = MagicMock()
    mock_mgr.start.return_value = StartResult(
        surface=AttackSurface(
            services=[
                ServiceEndpoint(
                    service_type=ServiceType.HTTP,
                    host="127.0.0.1",
                    port=9090,
                ),
            ],
        ),
        flags={"main": E2E_FLAG},
    )
    mock_mgr.stop.return_value = None
    mock_mgr.stop_all.return_value = None
    mock_mgr.get_sandbox_network.return_value = None
    mock_mgr.get_cert_volume.return_value = ""
    specs = [
        build_spec("E2E-001", name="E2E Test Challenge", description="Test challenge for SDK e2e"),
        build_spec(
            "E2E-002",
            name="E2E Second",
            description="Another test",
            difficulty="medium",
        ),
    ]

    def _iter_specs(**kw):
        result = specs
        if kw.get("difficulty") is not None:
            result = [s for s in result if s.difficulty.value == kw["difficulty"]]
        if kw.get("tag"):
            result = [s for s in result if kw["tag"] in s.tags]
        return iter(result)

    mock_mgr.iter_specs.side_effect = _iter_specs

    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_mgr):
        app = create_app(external_host="127.0.0.1", backend=backend)
    return app, backend


def _find_free_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture(scope="module")
def server_url():
    """Start a real HTTP server in a background thread and return its URL."""
    from ctfy.tests.conftest import fake_node_context

    app, backend = _make_e2e_app()
    port = _find_free_port()
    config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="error")
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    url = f"http://127.0.0.1:{port}"
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        try:
            import httpx

            httpx.get(f"{url}/api/v1/health", timeout=1)
            break
        except Exception:
            time.sleep(0.1)
    else:
        raise RuntimeError("Test server did not start")

    with fake_node_context(backend, flag=E2E_FLAG):
        yield url
    server.should_exit = True


@pytest.fixture(scope="module")
def anon_client(server_url):
    with PlatformClient(server_url) as c:
        yield c


@pytest.fixture(scope="module")
def team_and_client(server_url):
    anon = PlatformClient(server_url)
    team = anon.register_team("SDK-E2E-Team", agent="test-agent", description="e2e")
    anon.close()
    with PlatformClient(server_url, token=team.token) as c:
        yield c, team


def _e2e_start_and_wait(client, challenge_id="E2E-001", *, max_wait=10):
    client._request("POST", "/instances", json={"challenge_id": challenge_id, "ttl": 300})
    deadline = time.monotonic() + max_wait
    while time.monotonic() < deadline:
        for inst in client.list_instances():
            if inst.challenge_id == challenge_id and inst.status == "ready":
                return inst.instance_id
        time.sleep(0.2)
    raise TimeoutError(f"{challenge_id} not ready")


class TestE2EHealth:
    def test_health(self, anon_client):
        h = anon_client.health()
        assert isinstance(h, HealthResponse)
        assert h.status == "ok"
        assert h.hostname != ""


class TestE2ETeams:
    def test_register_team(self, server_url):
        with PlatformClient(server_url) as c:
            team = c.register_team("NewTeam", agent="bot")
            assert isinstance(team, TeamResponse)
            assert team.token.startswith("pt_")
            assert team.name == "NewTeam"

    def test_list_teams(self, anon_client):
        teams = anon_client.list_teams()
        assert isinstance(teams, list)
        assert len(teams) >= 1
        assert all(isinstance(t, TeamInfo) for t in teams)

    def test_get_team(self, team_and_client):
        client, team = team_and_client
        t = client.get_team(team.team_id)
        assert isinstance(t, TeamInfo)
        assert t.team_id == team.team_id
        assert t.name == "SDK-E2E-Team"

    def test_get_me(self, team_and_client):
        client, team = team_and_client
        me = client.get_me()
        assert isinstance(me, TeamInfo)
        assert me.team_id == team.team_id


class TestE2EChallenges:
    def test_list_challenges(self, anon_client):
        chals = anon_client.list_challenges()
        assert len(chals) == 2
        assert all(isinstance(c, ChallengeInfo) for c in chals)
        ids = {c.id for c in chals}
        assert "E2E-001" in ids
        assert "E2E-002" in ids

    def test_category_is_platform_constant(self, anon_client):
        chals = anon_client.list_challenges()
        assert all(c.category == "web" for c in chals)

    def test_list_challenges_with_difficulty(self, anon_client):
        chals = anon_client.list_challenges(difficulty="medium")
        assert len(chals) == 1
        assert chals[0].id == "E2E-002"

    def test_list_challenges_with_q(self, anon_client):
        chals = anon_client.list_challenges(q="Second")
        assert len(chals) == 1
        assert chals[0].id == "E2E-002"

    def test_list_challenges_q_matches_id(self, anon_client):
        chals = anon_client.list_challenges(q="001")
        assert len(chals) == 1
        assert chals[0].id == "E2E-001"

    def test_list_challenges_q_no_match(self, anon_client):
        chals = anon_client.list_challenges(q="nonexistent")
        assert len(chals) == 0

    def test_get_challenge(self, anon_client):
        c = anon_client.get_challenge("E2E-001")
        assert isinstance(c, ChallengeInfo)
        assert c.id == "E2E-001"
        assert c.name == "E2E Test Challenge"


class TestE2EInstances:
    def test_start_and_stop_instance(self, team_and_client):
        client, _ = team_and_client
        instance_id = _e2e_start_and_wait(client, "E2E-001")
        assert instance_id

        instances = client.list_instances()
        assert isinstance(instances, list)
        assert len(instances) >= 1
        assert all(isinstance(e, InstanceInfo) for e in instances)

        client.stop_instance("E2E-001")

    def test_list_instances_filter_challenge_id(self, team_and_client):
        client, _ = team_and_client
        _e2e_start_and_wait(client, "E2E-001")
        try:
            instances = client.list_instances(challenge_id="E2E-001")
            assert len(instances) == 1
            assert instances[0].challenge_id == "E2E-001"

            instances_none = client.list_instances(challenge_id="NONEXISTENT")
            assert len(instances_none) == 0
        finally:
            client.stop_instance("E2E-001")

    def test_list_instances_filter_status(self, team_and_client):
        client, _ = team_and_client
        _e2e_start_and_wait(client, "E2E-001")
        try:
            instances = client.list_instances(status="ready")
            assert len(instances) >= 1
            assert all(e.status == "ready" for e in instances)

            instances_err = client.list_instances(status="error")
            assert len(instances_err) == 0
        finally:
            client.stop_instance("E2E-001")

    def test_list_instances_filter_q(self, team_and_client):
        client, _ = team_and_client
        _e2e_start_and_wait(client, "E2E-001")
        try:
            instances = client.list_instances(q="E2E")
            assert len(instances) >= 1

            instances_none = client.list_instances(q="zzzzz")
            assert len(instances_none) == 0
        finally:
            client.stop_instance("E2E-001")

    def test_get_instance_status(self, team_and_client):
        client, _ = team_and_client
        instance_id = _e2e_start_and_wait(client, "E2E-001")
        try:
            status = client.get_instance_status(instance_id)
            assert isinstance(status, InstanceStatusResponse)
            assert status.status == "ready"
        finally:
            client.stop_instance("E2E-001")

    def test_renew_instance(self, team_and_client):
        client, _ = team_and_client
        _e2e_start_and_wait(client, "E2E-001")
        try:
            result = client.renew_instance("E2E-001", ttl=7200)
            assert isinstance(result, RenewResponse)
            assert result.status == "renewed"
            assert result.expires_at > 0
        finally:
            client.stop_instance("E2E-001")


class TestE2EFlags:
    def test_verify_flag_correct(self, team_and_client):
        client, _ = team_and_client
        _e2e_start_and_wait(client)
        try:
            result = client.verify_flag("E2E-001", E2E_FLAG)
            assert isinstance(result, VerifyFlagResponse)
            assert result.correct is True
        finally:
            client.stop_instance("E2E-001")

    def test_verify_flag_wrong(self, team_and_client):
        client, _ = team_and_client
        _e2e_start_and_wait(client)
        try:
            result = client.verify_flag("E2E-001", "FLAG{wrong}")
            assert isinstance(result, VerifyFlagResponse)
            assert result.correct is False
        finally:
            client.stop_instance("E2E-001")

    def test_submit_flag_correct(self, team_and_client):
        client, _ = team_and_client
        _e2e_start_and_wait(client)
        try:
            r = client.submit_flag("E2E-001", E2E_FLAG)
            assert isinstance(r, SubmissionResponse)
            assert r.correct is True
            assert r.solve_time_s >= 0
        finally:
            client.stop_instance("E2E-001")

    def test_submit_flag_wrong(self, team_and_client):
        client, _ = team_and_client
        _e2e_start_and_wait(client)
        try:
            r = client.submit_flag("E2E-001", "FLAG{nope}")
            assert isinstance(r, SubmissionResponse)
            assert r.correct is False
        finally:
            client.stop_instance("E2E-001")


class TestE2ESubmissions:
    def test_list_submissions(self, team_and_client):
        client, _ = team_and_client
        subs = client.list_submissions()
        assert isinstance(subs, list)
        assert len(subs) >= 1


class TestE2EScoreboard:
    def test_scoreboard(self, anon_client):
        board = anon_client.scoreboard()
        assert isinstance(board, list)
        assert all(isinstance(e, ScoreboardEntry) for e in board)

    def test_get_scoreboard_alias(self, anon_client):
        board = anon_client.get_scoreboard()
        assert isinstance(board, list)

    def test_scoreboard_has_attempts(self, anon_client):
        board = anon_client.scoreboard()
        for entry in board:
            assert isinstance(entry.attempts, int)

    def test_challenge_stats(self, anon_client):
        stats = anon_client.challenge_stats()
        assert isinstance(stats, list)
        assert all(isinstance(s, ChallengeStats) for s in stats)

    def test_get_challenge_stats_alias(self, anon_client):
        stats = anon_client.get_challenge_stats()
        assert isinstance(stats, list)


class TestE2EActivities:
    def test_get_activities(self, team_and_client):
        client, _ = team_and_client
        acts = client.get_activities()
        assert isinstance(acts, list)
        assert len(acts) >= 1

    def test_get_activities_filtered(self, team_and_client):
        client, _ = team_and_client
        acts = client.get_activities(event="team_registered")
        assert all(a.event == "team_registered" for a in acts)


class TestE2ENodes:
    def test_node_lifecycle(self, server_url):
        with PlatformClient(server_url) as c:
            try:
                c.register_node("http://node1:8100", capacity=20, labels={"gpu": "true"})
                nodes = c.list_nodes()
                assert isinstance(nodes, list)
            except Exception:
                pass

    def test_register_node_labels_type(self):
        import inspect

        sig = inspect.signature(PlatformClient.register_node)
        labels_param = sig.parameters["labels"]
        assert labels_param.default is None


class TestE2EFullLifecycle:
    def test_register_start_submit_scoreboard(self, server_url):
        with PlatformClient(server_url) as anon:
            team = anon.register_team("Lifecycle-Team", agent="e2e")

        with PlatformClient(server_url, token=team.token) as c:
            chals = c.list_challenges()
            assert len(chals) >= 1
            cid = chals[0].id

            c._request("POST", "/instances", json={"challenge_id": cid, "ttl": 300})
            deadline = time.monotonic() + 10
            ready = False
            while time.monotonic() < deadline:
                for inst in c.list_instances():
                    if inst.challenge_id == cid and inst.status == "ready":
                        ready = True
                        break
                if ready:
                    break
                time.sleep(0.2)
            assert ready, f"{cid} not ready"

            r = c.submit_flag(cid, E2E_FLAG)
            assert r.correct is True

            board = c.scoreboard()
            my_entry = [e for e in board if e.team_id == team.team_id]
            assert len(my_entry) == 1
            assert my_entry[0].solved == 1
            assert my_entry[0].attempts >= 1

            me = c.get_me()
            assert me.solves == 1

            c.stop_instance(cid)
