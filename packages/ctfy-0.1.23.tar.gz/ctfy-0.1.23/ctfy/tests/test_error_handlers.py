"""Tests for the unified ``ErrorResponse`` envelope on platform errors."""

from __future__ import annotations

from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.exceptions import (
    CapacityExceededError,
    ChallengeNotFoundError,
    ForbiddenError,
    InstanceAlreadyRunningError,
    InstanceNotFoundError,
)
from ctfy.core.state import InMemoryBackend
from ctfy.server.error_handlers import exception_code
from ctfy.tests.conftest import make_mock_challenge_manager


class TestExceptionCode:
    def test_instance_not_found_strips_error_suffix(self):
        assert exception_code(InstanceNotFoundError("i1")) == "instance_not_found"

    def test_capacity_exceeded_has_two_components(self):
        assert exception_code(CapacityExceededError("x")) == "capacity_exceeded"

    def test_challenge_not_found(self):
        assert exception_code(ChallengeNotFoundError("c1")) == "challenge_not_found"

    def test_forbidden(self):
        assert exception_code(ForbiddenError()) == "forbidden"

    def test_instance_already_running(self):
        assert exception_code(InstanceAlreadyRunningError("c1")) == "instance_already_running"

    def test_unknown_exception_still_snake_cases(self):
        """The helper is defensive: any future subclass passes through.

        Uses an ``Exception`` subclass whose name does *not* end in ``Error``
        so the ``removesuffix("_error")`` in ``exception_code`` doesn't hide
        what we're testing (snake-casing of arbitrary CamelCase names).
        """

        class MysteriousHiccup(Exception):
            pass

        assert exception_code(MysteriousHiccup()) == "mysterious_hiccup"


@pytest.fixture
def client():
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    mock_mgr = make_mock_challenge_manager(flag="FLAG{x}")
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_mgr):
        app = create_app(external_host="127.0.0.1", backend=backend)
    return TestClient(app)


class TestErrorResponseEnvelope:
    def test_404_body_shape(self, client):
        """``GET`` a nonexistent instance_id triggers ``InstanceNotFoundError``."""
        r = client.get("/api/v1/instances/does-not-exist/status")
        assert r.status_code == 404
        body = r.json()
        # Preserved — SDK/CLI/frontend read this today
        assert "Instance does-not-exist not found" in body["detail"]
        # New — machine-readable code + server-side timestamp
        assert body["code"] == "instance_not_found"
        assert body["timestamp"]
        # Timestamp is ISO 8601 UTC
        assert "T" in body["timestamp"]
