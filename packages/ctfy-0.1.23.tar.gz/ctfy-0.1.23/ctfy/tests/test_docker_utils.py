"""Tests for ``ctfy.providers.docker_provider.utils`` — orphan cleanup and
related Docker helpers. The focus here is the bare-metal (``uv run``)
transition where leftover files owned by a previous docker-run (uid 0)
process would otherwise block cleanup forever.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import docker.errors
import pytest

from ctfy.providers.docker_provider.utils import _force_rmtree, cleanup_orphans


def _make_instance_dir(base: Path, name: str = "abc123") -> Path:
    d = base / name
    d.mkdir(parents=True)
    (d / "flag").write_text("FLAG{x}")
    return d


def _wipe_instance_dir(d: Path) -> None:
    """Hand-deletion that doesn't use ``shutil.rmtree`` — safe to call from a
    ``side_effect`` in tests that have monkey-patched the real rmtree."""
    for child in d.iterdir():
        child.unlink()
    d.rmdir()


class TestForceRmtree:
    def test_ordinary_dir_removed_directly(self, tmp_path):
        """When `shutil.rmtree` succeeds, no Docker escalation happens."""
        d = _make_instance_dir(tmp_path)
        client = MagicMock()
        assert _force_rmtree(d, client) is True
        assert not d.exists()
        client.containers.run.assert_not_called()

    def test_missing_dir_is_idempotent(self, tmp_path):
        client = MagicMock()
        assert _force_rmtree(tmp_path / "does-not-exist", client) is True

    def test_permission_error_triggers_busybox_escalation(self, tmp_path, monkeypatch):
        """On PermissionError, fall back to a root-in-container ``rm -rf``.

        We simulate the failure by monkeypatching `shutil.rmtree` and let
        the mock container's side_effect actually delete the tree — unit
        tests can't produce a genuinely root-owned file without root, so
        this is the closest faithful simulation.
        """
        d = _make_instance_dir(tmp_path)
        import ctfy.providers.docker_provider.utils as utils_mod

        def _raise(_path):
            raise PermissionError(13, "Permission denied", "flag")

        monkeypatch.setattr(utils_mod.shutil, "rmtree", _raise)

        client = MagicMock()
        client.images.get.return_value = object()
        client.containers.run.side_effect = lambda *a, **kw: _wipe_instance_dir(d)

        assert _force_rmtree(d, client) is True
        assert not d.exists()
        client.containers.run.assert_called_once()
        _, kwargs = client.containers.run.call_args
        assert kwargs["command"] == ["rm", "-rf", f"/parent/{d.name}"]
        assert kwargs["volumes"] == {str(d.parent): {"bind": "/parent", "mode": "rw"}}
        assert kwargs["remove"] is True

    def test_busybox_pulled_when_missing(self, tmp_path, monkeypatch):
        d = _make_instance_dir(tmp_path)
        import ctfy.providers.docker_provider.utils as utils_mod

        monkeypatch.setattr(
            utils_mod.shutil,
            "rmtree",
            lambda _p: (_ for _ in ()).throw(PermissionError(13, "denied", "flag")),
        )

        client = MagicMock()
        client.images.get.side_effect = docker.errors.ImageNotFound("busybox")
        client.containers.run.side_effect = lambda *a, **kw: _wipe_instance_dir(d)

        assert _force_rmtree(d, client) is True
        client.images.pull.assert_called_once_with("busybox:latest")

    def test_busybox_pull_failure_reported_as_false(self, tmp_path, monkeypatch):
        d = _make_instance_dir(tmp_path)
        import ctfy.providers.docker_provider.utils as utils_mod

        monkeypatch.setattr(
            utils_mod.shutil,
            "rmtree",
            lambda _p: (_ for _ in ()).throw(PermissionError(13, "denied", "flag")),
        )
        client = MagicMock()
        client.images.get.side_effect = docker.errors.ImageNotFound("busybox")
        client.images.pull.side_effect = RuntimeError("registry offline")
        assert _force_rmtree(d, client) is False


class TestCleanupOrphansUsesForceRmtree:
    def test_instance_dir_cleaned_via_force_rmtree(self, tmp_path, monkeypatch):
        """End-to-end: `cleanup_orphans` walks the instances dir and delegates
        deletion to `_force_rmtree`, so a PermissionError on a normal
        `shutil.rmtree` still results in the orphan being counted as cleaned.
        """
        instances_dir = tmp_path / "instances"
        instances_dir.mkdir()
        _make_instance_dir(instances_dir, "ghost-1")

        client = MagicMock()
        client.containers.list.return_value = []
        client.networks.list.return_value = []
        client.volumes.list.return_value = []

        cleaned = cleanup_orphans(instances_dir=instances_dir, client=client)
        assert cleaned == 1
        assert not (instances_dir / "ghost-1").exists()

    def test_no_docker_client_available_returns_zero(self, tmp_path, monkeypatch):
        """If docker is unreachable, cleanup is a no-op rather than crashing
        the node's startup."""
        import ctfy.providers.docker_provider.utils as utils_mod

        monkeypatch.setattr(
            utils_mod.docker,
            "from_env",
            lambda: (_ for _ in ()).throw(RuntimeError("no docker")),
        )
        # No client arg → internal docker.from_env() path.
        assert cleanup_orphans(instances_dir=tmp_path) == 0


@pytest.fixture
def _quiet_docker_cleanup(monkeypatch):
    """Reusable fixture: neuter docker calls so tests can run without a daemon."""
    import ctfy.providers.docker_provider.utils as utils_mod

    monkeypatch.setattr(utils_mod.docker, "from_env", lambda: MagicMock())
    return utils_mod
