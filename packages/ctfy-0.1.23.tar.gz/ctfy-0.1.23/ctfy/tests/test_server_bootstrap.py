"""Tests for first-run bootstrap in ``ctfy server start``."""

from __future__ import annotations

import os

import pytest

from ctfy.cli.server import (
    _bootstrap_env_if_missing,
    _render_compose_service,
    _render_docker_run,
    _render_uv_run,
)


class TestRenderSnippets:
    def test_docker_run_contains_required_env(self):
        snippet = _render_docker_run(platform_url="http://p:8100", registration_token="REG_TOKEN")
        assert "CTFY_PLATFORM_URL=http://p:8100" in snippet
        # Registration token is piped in via the node-side CTFY_NODE_TOKEN env
        # var; the name stays for continuity, the value is now single-use.
        assert "CTFY_NODE_TOKEN=REG_TOKEN" in snippet
        assert "/var/run/docker.sock" in snippet

    def test_compose_service_contains_required_env(self):
        snippet = _render_compose_service(
            platform_url="http://p:8100", registration_token="REG_TOKEN"
        )
        assert "CTFY_PLATFORM_URL=http://p:8100" in snippet
        assert "CTFY_NODE_TOKEN=REG_TOKEN" in snippet

    def test_uv_run_contains_required_env_and_cli(self):
        snippet = _render_uv_run(platform_url="http://p:8100", registration_token="REG_TOKEN")
        assert "CTFY_PLATFORM_URL=http://p:8100" in snippet
        assert "CTFY_NODE_TOKEN=REG_TOKEN" in snippet
        assert "uv run ctfy node join" in snippet
        assert "git clone" in snippet


class TestBootstrap:
    @pytest.fixture(autouse=True)
    def _clean_env(self, monkeypatch):
        for var in (
            "CTFY_ADMIN_TOKEN",
            "CTFY_NODE_TOKEN",
            "CTFY_PLATFORM_URL",
            "CTFY_NODE_PUBLIC_URL",
            "CTFY_SERVER_API_KEY",
        ):
            monkeypatch.delenv(var, raising=False)
        try:
            yield
        finally:
            for var in (
                "CTFY_ADMIN_TOKEN",
                "CTFY_NODE_TOKEN",
                "CTFY_PLATFORM_URL",
                "CTFY_NODE_PUBLIC_URL",
            ):
                os.environ.pop(var, None)

    def test_generates_when_env_missing(self, tmp_path):
        env_path = tmp_path / ".env"
        result = _bootstrap_env_if_missing(env_path, admin="")

        assert result is not None
        assert env_path.exists()
        assert env_path.stat().st_mode & 0o777 == 0o600

        content = env_path.read_text()
        assert f"CTFY_ADMIN_TOKEN={result['admin_token']}" in content
        # Node registration tokens live off-disk now — minted on demand via
        # `ctfy server invite` rather than persisted in .env.
        assert "CTFY_NODE_TOKEN" not in content
        # CTFY_NODE_PUBLIC_URL is intentionally not bootstrapped: a bare-metal
        # value here would leak into docker-compose (which auto-loads .env)
        # and break platform→node routing in the compose network.
        assert "CTFY_NODE_PUBLIC_URL" not in content

        # Propagated into os.environ for the current process.
        assert os.environ["CTFY_ADMIN_TOKEN"] == result["admin_token"]
        assert os.environ["CTFY_PLATFORM_URL"] == result["platform_url"]
        assert "CTFY_NODE_TOKEN" not in os.environ
        assert "CTFY_NODE_PUBLIC_URL" not in os.environ

    def test_noop_when_env_file_exists(self, tmp_path):
        env_path = tmp_path / ".env"
        env_path.write_text("CTFY_ADMIN_TOKEN=existing\n")

        result = _bootstrap_env_if_missing(env_path, admin="")

        assert result is None
        assert env_path.read_text() == "CTFY_ADMIN_TOKEN=existing\n"

    def test_noop_when_admin_token_already_provided(self, tmp_path):
        env_path = tmp_path / ".env"

        result = _bootstrap_env_if_missing(env_path, admin="from-cli")

        assert result is None
        assert not env_path.exists()

    def test_generates_fresh_random_values(self, tmp_path):
        a = _bootstrap_env_if_missing(tmp_path / "a.env", admin="")
        for var in ("CTFY_ADMIN_TOKEN", "CTFY_PLATFORM_URL"):
            os.environ.pop(var, None)
        b = _bootstrap_env_if_missing(tmp_path / "b.env", admin="")

        assert a["admin_token"] != b["admin_token"]
        assert len(a["admin_token"]) == 64  # secrets.token_hex(32)
