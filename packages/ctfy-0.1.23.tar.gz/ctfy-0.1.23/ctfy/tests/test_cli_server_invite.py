"""`ctfy server invite` calls POST /nodes/invites and renders the token.

Smoke-level coverage: we stub the two HTTP calls (mint-invite and
cluster-info) and exercise the Typer command through its Click runner so
the end-to-end wiring — admin header, ttl flag, output formats — is
exercised without a live platform.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import typer
from typer.testing import CliRunner

from ctfy.cli.server import server_app


def _fake_response(status=200, body=None):
    r = MagicMock()
    r.status_code = status
    r.raise_for_status = MagicMock()
    r.json = MagicMock(return_value=body or {})
    return r


def _setup_ctx():
    # The invite command calls resolve_platform_url(ctx) and admin_headers(ctx),
    # both of which read ctx.obj. Stub them to fixed values via patch.
    return {
        "platform_url": "http://platform:8100",
        "admin_headers": {"Authorization": "Bearer admin-key"},
    }


class TestInviteCommand:
    @patch("ctfy.cli.server.httpx.get")
    @patch("ctfy.cli.server.httpx.post")
    @patch("ctfy.cli.server.admin_headers")
    @patch("ctfy.cli.server.resolve_platform_url")
    def test_uv_output_injects_registration_token(self, url_stub, hdr_stub, post_stub, get_stub):
        url_stub.return_value = "http://platform:8100"
        hdr_stub.return_value = {"Authorization": "Bearer admin-key"}
        post_stub.return_value = _fake_response(
            body={
                "invite_id": "abc123",
                "registration_token": "reg_SECRET_TOKEN_xxxxx",
                "expires_at": "2026-04-20T00:00:00+00:00",
            }
        )
        get_stub.return_value = _fake_response(
            body={
                "platform_url": "http://platform:8100",
                "node_image": "ghcr.io/wangyihang/ctfy:latest",
            }
        )

        runner = CliRunner()
        result = runner.invoke(server_app, ["invite", "-o", "uv"])
        assert result.exit_code == 0, result.output

        # Platform got the mint call.
        post_stub.assert_called_once()
        (url_arg,), kwargs = post_stub.call_args
        assert url_arg.endswith("/api/v1/nodes/invites")
        assert kwargs["json"] == {"ttl_seconds": 3600}

        # Rendered snippet contains the minted token in the env var line.
        assert "CTFY_NODE_TOKEN=reg_SECRET_TOKEN_xxxxx" in result.output
        assert "uv run ctfy node join" in result.output
        assert "expires at" in result.output.lower()

    @patch("ctfy.cli.server.httpx.get")
    @patch("ctfy.cli.server.httpx.post")
    @patch("ctfy.cli.server.admin_headers")
    @patch("ctfy.cli.server.resolve_platform_url")
    def test_json_output_exposes_invite_metadata(self, url_stub, hdr_stub, post_stub, get_stub):
        url_stub.return_value = "http://platform:8100"
        hdr_stub.return_value = {"Authorization": "Bearer admin-key"}
        post_stub.return_value = _fake_response(
            body={
                "invite_id": "abc123",
                "registration_token": "reg_abc",
                "expires_at": "2026-04-20T00:00:00+00:00",
            }
        )
        get_stub.return_value = _fake_response(
            body={
                "platform_url": "http://platform:8100",
                "node_image": "ghcr.io/wangyihang/ctfy:latest",
            }
        )

        runner = CliRunner()
        result = runner.invoke(server_app, ["invite", "-o", "json", "--ttl", "1800"])
        assert result.exit_code == 0, result.output
        # ttl override forwarded to POST body.
        assert post_stub.call_args.kwargs["json"] == {"ttl_seconds": 1800}
        # JSON output carries invite_id and the token.
        assert '"invite_id": "abc123"' in result.output
        assert '"registration_token": "reg_abc"' in result.output

    @patch("ctfy.cli.server.admin_headers")
    @patch("ctfy.cli.server.resolve_platform_url")
    def test_missing_admin_token_aborts(self, url_stub, hdr_stub):
        url_stub.return_value = "http://platform:8100"
        hdr_stub.return_value = None  # no admin configured

        runner = CliRunner()
        result = runner.invoke(server_app, ["invite"])
        assert isinstance(result.exception, typer.Exit) or result.exit_code != 0
        assert "admin" in result.output.lower()
