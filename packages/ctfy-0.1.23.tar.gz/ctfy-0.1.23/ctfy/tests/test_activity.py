"""Tests for the typed ``Activity.detail`` schema and ``emit_event`` wiring."""

from __future__ import annotations

from ctfy.core.activity import ActivityDetail
from ctfy.core.config import CtfyConfig
from ctfy.core.state import InMemoryBackend
from ctfy.server.app_state import AppState
from ctfy.server.event_payloads import (
    FlagCorrectPayload,
    InstanceReadyPayload,
    InstanceStoppedPayload,
    NodeRegisteredPayload,
    TeamRegisteredPayload,
)
from ctfy.server.events import emit_event
from ctfy.server.sse import SSEHub


def _make_app() -> AppState:
    return AppState(
        config=CtfyConfig(),
        state_backend=InMemoryBackend(),
        spec_reader=None,  # not used
        sse_hub=SSEHub(),
        host="127.0.0.1",
        max_instances=10,
    )


class TestActivityDetailShape:
    def test_all_fields_default_none(self):
        d = ActivityDetail()
        assert d.instance_id is None
        assert d.node_id is None
        assert d.error is None
        assert d.solve_time_s is None

    def test_accepts_known_fields(self):
        d = ActivityDetail(instance_id="i1", node_id="n1", ttl=60)
        assert d.instance_id == "i1"
        assert d.node_id == "n1"
        assert d.ttl == 60

    def test_unknown_fields_silently_dropped(self):
        """``model_validate`` with default ``extra=ignore`` mirrors the old
        dict behaviour for forward-compat — callers in future versions can
        add keys without breaking older readers."""
        d = ActivityDetail.model_validate({"instance_id": "i", "future_field": "x"})
        assert d.instance_id == "i"
        assert not hasattr(d, "future_field")


_ACTOR = {"actor_id": "t1", "actor_name": "t1", "actor_type": "team"}


class TestEmitEventWiring:
    def test_instance_ready_payload_round_trips(self):
        app = _make_app()
        emit_event(
            app,
            InstanceReadyPayload(
                team_id="t1",
                challenge_id="c1",
                instance_id="i1",
                node_id="n1",
            ),
            **_ACTOR,
        )
        activities = app.state_backend.list_activities(limit=10)
        assert len(activities) == 1
        act = activities[0]
        assert act.event == "instance_ready"
        assert act.detail.instance_id == "i1"
        assert act.detail.node_id == "n1"
        # Fields not set stay None (they're the discriminating absence)
        assert act.detail.error is None
        # Actor captured from the emit call
        assert act.actor_id == "t1"
        assert act.actor_type == "team"

    def test_flag_correct_payload(self):
        app = _make_app()
        emit_event(
            app,
            FlagCorrectPayload(
                team_id="t1",
                team_name="Team One",
                challenge_id="c1",
                instance_id="i1",
                solve_time_s=42.5,
            ),
            **_ACTOR,
        )
        act = app.state_backend.list_activities(limit=10)[0]
        assert act.event == "flag_correct"
        assert act.team_name == "Team One"
        assert act.detail.solve_time_s == 42.5

    def test_node_registered_payload(self):
        app = _make_app()
        emit_event(
            app,
            NodeRegisteredPayload(node_id="n1", url="http://node1:8101"),
            actor_id="admin",
            actor_name="admin",
            actor_type="admin",
        )
        act = app.state_backend.list_activities(limit=10)[0]
        assert act.event == "node_registered"
        assert act.detail.node_id == "n1"
        assert act.detail.url == "http://node1:8101"
        assert act.actor_type == "admin"

    def test_instance_stopped_with_reason(self):
        app = _make_app()
        emit_event(
            app,
            InstanceStoppedPayload(
                team_id="t1",
                challenge_id="c1",
                instance_id="i1",
                reason="auto_stop_after_solve",
            ),
            actor_id="system",
            actor_name="auto-stop",
            actor_type="system",
        )
        act = app.state_backend.list_activities(limit=10)[0]
        assert act.detail.reason == "auto_stop_after_solve"
        assert act.actor_type == "system"

    def test_enum_event_serialized_as_string(self):
        app = _make_app()
        emit_event(
            app,
            TeamRegisteredPayload(team_id="t1", team_name="X", agent="a"),
            **_ACTOR,
        )
        act = app.state_backend.list_activities(limit=10)[0]
        assert isinstance(act.event, str)
        assert act.event == "team_registered"

    def test_actor_missing_raises(self):
        """emit_event refuses to run without actor context — the whole
        point of B10 is that every event carries who did it."""
        import pytest

        app = _make_app()
        with pytest.raises(TypeError):
            emit_event(  # type: ignore[call-arg]
                app,
                TeamRegisteredPayload(team_id="t1", team_name="X", agent="a"),
            )

    def test_actor_filter_narrows(self):
        app = _make_app()
        emit_event(
            app,
            TeamRegisteredPayload(team_id="t1", team_name="one", agent=""),
            actor_id="t1",
            actor_name="one",
            actor_type="team",
        )
        emit_event(
            app,
            TeamRegisteredPayload(team_id="t2", team_name="two", agent=""),
            actor_id="t2",
            actor_name="two",
            actor_type="team",
        )
        only_t1 = app.state_backend.list_activities(actor_id="t1", limit=10)
        assert len(only_t1) == 1
        assert only_t1[0].team_id == "t1"


class TestPayloadTypeSafety:
    def test_required_field_missing_raises(self):
        """Each payload enforces its per-event required fields. An
        InstanceReadyPayload without ``instance_id`` should blow up at
        construction, not silently ship a malformed event."""
        import pydantic

        with pytest.raises(pydantic.ValidationError):
            InstanceReadyPayload(team_id="t1", challenge_id="c1", node_id="n1")

    def test_unknown_field_rejected(self):
        """Forbidding stray kwargs is the whole point — a typo at a
        call site should be loud, not silently ignored."""
        import pydantic

        with pytest.raises(pydantic.ValidationError):
            InstanceReadyPayload(
                team_id="t1",
                challenge_id="c1",
                instance_id="i1",
                node_id="n1",
                ips="1.2.3.4",  # typo: ``ip`` vs ``ips`` — and ip isn't on this class
            )


# pytest import deferred to keep top-of-file imports minimal for the
# read-only tests that don't need it.
import pytest  # noqa: E402
