"""Unit tests for ``ctfy.server.scheduling.pick_node``.

The algorithm lives in its own module (extracted from ``routes/instances.py``)
so it can be exercised without the FastAPI layer. Each case constructs an
``AppState`` against an ``InMemoryBackend`` seeded with the node shape under
test and asserts the placement outcome.
"""

from __future__ import annotations

import time

from ctfy.core.config import CtfyConfig
from ctfy.core.constants import HEARTBEAT_TIMEOUT
from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import NodeState
from ctfy.server.app_state import AppState
from ctfy.server.scheduling import pick_node
from ctfy.server.sse import SSEHub


def _make_app(nodes: list[NodeState]) -> AppState:
    backend = InMemoryBackend()
    for n in nodes:
        backend.put_node(n.node_id, n)
    return AppState(
        config=CtfyConfig(),
        state_backend=backend,
        spec_reader=None,  # unused by pick_node
        sse_hub=SSEHub(),
        host="127.0.0.1",
        max_instances=100,
    )


def _healthy(node_id: str, *, capacity: int = 10, running: int = 0) -> NodeState:
    return NodeState(
        node_id=node_id,
        url=f"http://{node_id}:8101",
        capacity=capacity,
        running=running,
        healthy=True,
        last_heartbeat_ts=time.time(),
    )


class TestRejections:
    def test_no_nodes_returns_none(self):
        assert pick_node(_make_app([])) is None

    def test_all_unhealthy_returns_none(self):
        app = _make_app(
            [
                NodeState(node_id="n1", url="x", capacity=10, healthy=False),
                NodeState(node_id="n2", url="y", capacity=10, healthy=False),
            ]
        )
        assert pick_node(app) is None

    def test_stale_heartbeat_skipped(self):
        stale = NodeState(
            node_id="n1",
            url="x",
            capacity=10,
            running=0,
            healthy=True,
            last_heartbeat_ts=time.time() - HEARTBEAT_TIMEOUT - 1,
        )
        assert pick_node(_make_app([stale])) is None

    def test_all_at_capacity_returns_none(self):
        full = _healthy("full", capacity=10, running=10)
        assert pick_node(_make_app([full])) is None

    def test_running_exceeds_capacity_returns_none(self):
        """Guards against stale accounting where running accidentally exceeds capacity."""
        oversubscribed = _healthy("over", capacity=5, running=7)
        assert pick_node(_make_app([oversubscribed])) is None


class TestSelection:
    def test_single_healthy_node_picked(self):
        n = _healthy("only", capacity=10, running=3)
        picked = pick_node(_make_app([n]))
        assert picked is not None
        assert picked.node_id == "only"

    def test_least_loaded_wins(self):
        busy = _healthy("busy", capacity=10, running=8)  # 2 available
        idle = _healthy("idle", capacity=10, running=1)  # 9 available
        picked = pick_node(_make_app([busy, idle]))
        assert picked.node_id == "idle"

    def test_larger_capacity_preferred_when_running_equal(self):
        small = _healthy("small", capacity=5, running=0)  # 5 available
        large = _healthy("large", capacity=20, running=0)  # 20 available
        picked = pick_node(_make_app([small, large]))
        assert picked.node_id == "large"

    def test_unhealthy_ignored_in_mix(self):
        bad = NodeState(node_id="bad", url="x", capacity=100, running=0, healthy=False)
        good = _healthy("good", capacity=5, running=0)
        picked = pick_node(_make_app([bad, good]))
        assert picked.node_id == "good"

    def test_no_heartbeat_ts_still_eligible(self):
        """Newly-registered node without a heartbeat_ts must still be pickable —
        otherwise first-ever placement would always fail."""
        fresh = NodeState(
            node_id="fresh", url="x", capacity=10, running=0, healthy=True
        )  # last_heartbeat_ts default 0.0 → falsy → stale check skipped
        picked = pick_node(_make_app([fresh]))
        assert picked is not None
        assert picked.node_id == "fresh"
