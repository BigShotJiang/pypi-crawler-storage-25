"""Tests for the CTF platform.

Covers teams, submissions, scoreboard, instance lifecycle, flag verification,
TTL renew, auth, and the async start+poll path. Uses FastAPI TestClient with
a mocked ChallengeManager and a fake worker node.
"""

import time
import uuid
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient
from pydantic import SecretStr

from ctfy.core.config import CtfyConfig
from ctfy.core.state import InMemoryBackend
from ctfy.tests.conftest import (
    fake_node_context,
    make_mock_challenge_manager,
    start_instance_and_wait,
)

ADMIN_KEY = "test-admin-secret"


# -- Team registration ------------------------------------------------------


class TestTeams:
    def test_register_team(self, client):
        resp = client.post(
            "/api/v1/teams",
            json={
                "name": "Team Alpha",
                "agent": "claude-code",
                "description": "Test team",
            },
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "Team Alpha"
        assert data["team_id"]
        assert data["token"].startswith("pt_")

    def test_list_teams(self, client):
        client.post("/api/v1/teams", json={"name": "A", "agent": "cai"})
        client.post("/api/v1/teams", json={"name": "B", "agent": "claude-code"})
        resp = client.get("/api/v1/teams")
        assert resp.status_code == 200
        assert len(resp.json()["items"]) == 2

    def test_get_team(self, client):
        r = client.post("/api/v1/teams", json={"name": "Solo", "agent": "x"})
        tid = r.json()["team_id"]
        resp = client.get(f"/api/v1/teams/{tid}")
        assert resp.status_code == 200
        assert resp.json()["name"] == "Solo"

    def test_get_team_404(self, client):
        assert client.get("/api/v1/teams/nonexistent").status_code == 404


# -- Challenges --------------------------------------------------------------


class TestChallenges:
    def test_list_challenges(self, client):
        resp = client.get("/api/v1/challenges")
        assert resp.status_code == 200
        challenges = resp.json()["items"]
        assert len(challenges) == 6
        assert challenges[0]["id"] == "WEB-001"


# -- Submissions & flag verification ----------------------------------------


class TestSubmissions:
    def _setup(self, client):
        """Register team and start instance with auth."""
        r = client.post("/api/v1/teams", json={"name": "Hackers", "agent": "test"})
        team = r.json()
        auth = {"Authorization": f"Bearer {team['token']}"}
        start_instance_and_wait(client, "WEB-001", headers=auth)
        return team

    def test_correct_flag(self, client):
        team = self._setup(client)
        resp = client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "WEB-001",
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers={"Authorization": f"Bearer {team['token']}"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["correct"] is True
        assert data["solve_time_s"] >= 0

    def test_wrong_flag(self, client):
        team = self._setup(client)
        resp = client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "WEB-001",
                "flag": "FLAG{wrong}",
            },
            headers={"Authorization": f"Bearer {team['token']}"},
        )
        assert resp.json()["correct"] is False

    def test_no_auth_401(self, client):
        resp = client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "WEB-001",
                "flag": "x",
            },
        )
        assert resp.status_code == 401

    def test_bad_key_403(self, client):
        resp = client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "WEB-001",
                "flag": "x",
            },
            headers={"Authorization": "Bearer invalid_key"},
        )
        assert resp.status_code == 403

    def test_second_team_solve(self, client):
        team1 = self._setup(client)
        r2 = client.post("/api/v1/teams", json={"name": "Team2", "agent": "b"})
        team2 = r2.json()
        auth2 = {"Authorization": f"Bearer {team2['token']}"}
        start_instance_and_wait(client, "WEB-001", headers=auth2)

        # Team 1 solves first
        r = client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "WEB-001",
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers={"Authorization": f"Bearer {team1['token']}"},
        )
        assert r.json()["correct"] is True

        # Team 2 solves second
        r = client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "WEB-001",
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers=auth2,
        )
        assert r.json()["correct"] is True
        assert r.json()["solve_time_s"] >= 0


# -- Scoreboard -------------------------------------------------------------


class TestScoreboard:
    def _setup_two_teams(self, client):
        r1 = client.post("/api/v1/teams", json={"name": "Alpha", "agent": "a"})
        r2 = client.post("/api/v1/teams", json={"name": "Beta", "agent": "b"})
        team1, team2 = r1.json(), r2.json()

        auth1 = {"Authorization": f"Bearer {team1['token']}"}
        auth2 = {"Authorization": f"Bearer {team2['token']}"}
        start_instance_and_wait(client, "WEB-001", headers=auth1)
        start_instance_and_wait(client, "WEB-001", headers=auth2)
        return team1, team2

    def test_scoreboard_ranking(self, client):
        team1, team2 = self._setup_two_teams(client)

        # Team1 solves WEB-001
        client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "WEB-001",
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers={"Authorization": f"Bearer {team1['token']}"},
        )

        # Team2 fails
        client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "WEB-001",
                "flag": "FLAG{wrong}",
            },
            headers={"Authorization": f"Bearer {team2['token']}"},
        )

        resp = client.get("/api/v1/scoreboard")
        assert resp.status_code == 200
        board = resp.json()["items"]
        assert board[0]["team_name"] == "Alpha"
        assert board[0]["solved"] == 1
        assert board[0]["rank"] == 1


# -- Full lifecycle E2E ------------------------------------------------------


class TestFullLifecycle:
    def test_register_start_solve_scoreboard(self, client):
        """Complete flow: register → start instance → submit flag → check scoreboard."""
        # 1. Register
        r = client.post("/api/v1/teams", json={"name": "Champion", "agent": "claude-code"})
        team = r.json()
        auth = {"Authorization": f"Bearer {team['token']}"}

        # 2. Start instance (async) with auth
        r = client.post(
            "/api/v1/instances",
            json={
                "challenge_id": "WEB-001",
                "ttl": 300,
            },
            headers=auth,
        )
        assert r.status_code == 202
        assert "flag" not in r.json()  # flag not exposed
        start_instance_and_wait(client, "WEB-001", headers=auth)  # wait until ready

        # 3. Submit flag
        r = client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "WEB-001",
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers=auth,
        )
        assert r.json()["correct"] is True

        # 4. Scoreboard
        r = client.get("/api/v1/scoreboard")
        board = r.json()["items"]
        assert board[0]["team_name"] == "Champion"
        assert board[0]["solved"] == 1

        # 5. Team stats
        r = client.get(f"/api/v1/teams/{team['team_id']}")
        assert r.json()["solves"] == 1


# -- Challenge stats (GET /scoreboard/challenges) ----------------------------


class TestChallengeStats:
    def _setup(self, client):
        r = client.post("/api/v1/teams", json={"name": "Stats", "agent": "a"})
        team = r.json()
        auth = {"Authorization": f"Bearer {team['token']}"}
        start_instance_and_wait(client, "WEB-001", headers=auth)
        return team

    def test_challenge_stats_endpoint(self, client):
        """GET /scoreboard/challenges returns per-challenge data."""
        team = self._setup(client)
        # Submit a correct + a wrong flag
        auth = {"Authorization": f"Bearer {team['token']}"}
        client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "WEB-001",
                "flag": "FLAG{wrong}",
            },
            headers=auth,
        )
        client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "WEB-001",
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers=auth,
        )

        r = client.get("/api/v1/scoreboard/challenges")
        assert r.status_code == 200
        stats = r.json()["items"]
        assert len(stats) == 6
        web001 = next(s for s in stats if s["challenge_id"] == "WEB-001")
        assert web001["solves_count"] == 1
        assert web001["total_attempts"] == 2

    def test_challenge_stats_no_submissions(self, client):
        r = client.get("/api/v1/scoreboard/challenges")
        assert r.status_code == 200
        for s in r.json()["items"]:
            assert s["solves_count"] == 0


# -- Scoreboard edge cases ---------------------------------------------------


class TestScoreboardEdgeCases:
    def test_empty_scoreboard(self, client):
        r = client.get("/api/v1/scoreboard")
        assert r.status_code == 200
        assert r.json()["items"] == []

    def test_rate_limit_returns_429(self, mock_env_manager, backend):
        """Scoreboard is expensive to compute; hammering it should 429 eventually.

        Rate limiting is off by default — this test explicitly opts in via
        ``CtfyConfig(rate_limiting_enabled=True)`` so the global switch stays
        disabled for every other test.
        """
        from ctfy.server.app import create_app

        config = CtfyConfig(rate_limiting_enabled=True)
        with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
            app = create_app(config=config, external_host="10.0.1.5", backend=backend)
        with fake_node_context(
            backend,
            flag="FLAG{deadbeef0123456789abcdef01234567}",
            host="10.0.1.5",
        ):
            rl_client = TestClient(app)
            # 30/minute is the per-endpoint cap; request #31 must be rejected.
            statuses = [rl_client.get("/api/v1/scoreboard").status_code for _ in range(31)]
        assert 200 in statuses
        assert 429 in statuses

    def test_team_with_zero_solves(self, client):
        client.post("/api/v1/teams", json={"name": "Noob", "agent": "x"})
        r = client.get("/api/v1/scoreboard")
        board = r.json()["items"]
        assert len(board) == 1
        assert board[0]["solved"] == 0

    def test_tiebreak_by_last_solve(self, client):
        """Same solve count → earlier last_solve wins."""
        r1 = client.post("/api/v1/teams", json={"name": "Fast", "agent": "a"})
        r2 = client.post("/api/v1/teams", json={"name": "Slow", "agent": "b"})
        team1, team2 = r1.json(), r2.json()
        auth1 = {"Authorization": f"Bearer {team1['token']}"}
        auth2 = {"Authorization": f"Bearer {team2['token']}"}
        start_instance_and_wait(client, "WEB-001", headers=auth1)
        start_instance_and_wait(client, "WEB-001", headers=auth2)

        # Both solve WEB-001, team1 first
        client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "WEB-001",
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers={"Authorization": f"Bearer {team1['token']}"},
        )

        client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "WEB-001",
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers={"Authorization": f"Bearer {team2['token']}"},
        )

        r = client.get("/api/v1/scoreboard")
        board = r.json()["items"]
        # Both have 1 solve; first solver should rank higher (earlier last_solve_at)
        assert board[0]["team_name"] == "Fast"
        assert board[1]["team_name"] == "Slow"


# -- Submission edge cases ---------------------------------------------------


class TestSubmissionEdgeCases:
    def _setup(self, client):
        r = client.post("/api/v1/teams", json={"name": "Hacker", "agent": "x"})
        team = r.json()
        auth = {"Authorization": f"Bearer {team['token']}"}
        start_instance_and_wait(client, "WEB-001", headers=auth)
        return team

    def test_duplicate_solve_no_double_count(self, client):
        """Solving same challenge twice should only count as 1 solve.
        After first correct submission, instance is auto-destroyed, so the
        second submission returns 404."""
        team = self._setup(client)
        auth = {"Authorization": f"Bearer {team['token']}"}
        flag = "FLAG{deadbeef0123456789abcdef01234567}"

        r1 = client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "WEB-001",
                "flag": flag,
            },
            headers=auth,
        )
        assert r1.json()["correct"] is True

        # Instance is auto-destroyed after first solve; allow
        # the background auto-stop thread to complete.

        time.sleep(0.1)

        r2 = client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "WEB-001",
                "flag": flag,
            },
            headers=auth,
        )
        # Instance was auto-destroyed, so second submission gets 404
        assert r2.status_code == 404

        # Should still be 1 solve
        info = client.get(f"/api/v1/teams/{team['team_id']}").json()
        assert info["solves"] == 1

    def test_submit_no_instance_404(self, client):
        """Submitting flag when no instance is running should 404."""
        r = client.post("/api/v1/teams", json={"name": "NoEnv", "agent": "x"})
        team = r.json()
        r = client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "NONEXISTENT",
                "flag": "FLAG{x}",
            },
            headers={"Authorization": f"Bearer {team['token']}"},
        )
        assert r.status_code == 404

    def test_solve_time_positive(self, client):
        """Solve time should be > 0 for correct submissions."""
        team = self._setup(client)
        auth = {"Authorization": f"Bearer {team['token']}"}
        r = client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "WEB-001",
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers=auth,
        )
        assert r.json()["correct"] is True
        assert r.json()["solve_time_s"] >= 0

    def test_restart_after_solve_allowed(self, client):
        """Starting a new instance for an already-solved challenge should succeed."""
        team = self._setup(client)
        auth = {"Authorization": f"Bearer {team['token']}"}

        # Solve the challenge
        r = client.post(
            "/api/v1/submissions",
            json={"challenge_id": "WEB-001", "flag": "FLAG{deadbeef0123456789abcdef01234567}"},
            headers=auth,
        )
        assert r.json()["correct"] is True

        time.sleep(0.1)  # allow auto-stop thread to finish

        # Restart after solve — should be allowed for re-evaluation
        r2 = client.post(
            "/api/v1/instances",
            json={"challenge_id": "WEB-001"},
            headers=auth,
        )
        assert r2.status_code in (200, 201, 202)


# -- Capacity limit -----------------------------------------------------------


class TestCapacityLimit:
    def test_503_when_full(self, mock_env_manager, backend):
        """Server should return 503 when at capacity."""
        from ctfy.server.app import create_app

        with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
            app = create_app(external_host="10.0.1.5", backend=backend, max_instances=1)
        with fake_node_context(
            backend,
            flag="FLAG{deadbeef0123456789abcdef01234567}",
            host="10.0.1.5",
        ):
            c = TestClient(app)
            team = c.post("/api/v1/teams", json={"name": "cap", "agent": "x"}).json()
            auth = {"Authorization": f"Bearer {team['token']}"}

            # Start first instance (succeeds)
            r = c.post(
                "/api/v1/instances",
                json={
                    "challenge_id": "E1",
                    "ttl": 300,
                },
                headers=auth,
            )
            assert r.status_code == 202

            # Wait for it to be recorded
            import time

            time.sleep(0.5)

            # Start second instance (should fail with 503)
            r = c.post(
                "/api/v1/instances",
                json={
                    "challenge_id": "E2",
                    "ttl": 300,
                },
                headers=auth,
            )
            assert r.status_code == 503


# -- Challenge filtering -----------------------------------------------------


class TestChallengeFiltering:
    def test_filter_by_category(self, client):
        r = client.get("/api/v1/challenges?category=web")
        assert r.status_code == 200
        for c in r.json()["items"]:
            assert c["category"] == "web"

    def test_get_challenge_404(self, client):
        r = client.get("/api/v1/challenges/NONEXISTENT")
        assert r.status_code == 404


# -- Activity log ------------------------------------------------------------


class TestActivityLog:
    def test_activities_recorded_on_team_register(self, client):
        team = client.post("/api/v1/teams", json={"name": "Logger", "agent": "x"}).json()
        auth = {"Authorization": f"Bearer {team['token']}"}
        r = client.get("/api/v1/activities?event=team_registered", headers=auth)
        assert r.status_code == 200
        acts = r.json()["items"]
        assert len(acts) >= 1
        assert acts[0]["event"] == "team_registered"
        # Metadata enrichment: IP + agent ride along on the activity row
        # so the audit log tells the full story without joining tables.
        detail = acts[0]["detail"]
        assert detail.get("agent") == "x"
        # TestClient reports a synthetic peer; the exact value isn't
        # portable but the field must be present and non-None.
        assert detail.get("ip") is not None

    def test_activities_recorded_on_flag_submit(self, client):
        team = client.post("/api/v1/teams", json={"name": "A", "agent": "x"}).json()
        auth = {"Authorization": f"Bearer {team['token']}"}
        start_instance_and_wait(client, "WEB-001", headers=auth)
        client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "WEB-001",
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers=auth,
        )
        r = client.get("/api/v1/activities?event=flag_correct", headers=auth)
        assert len(r.json()["items"]) >= 1

    def test_activities_filter(self, client):
        """Activity log supports filtering by event type."""
        team = client.post("/api/v1/teams", json={"name": "X", "agent": "x"}).json()
        auth = {"Authorization": f"Bearer {team['token']}"}
        all_acts = client.get("/api/v1/activities", headers=auth).json()["items"]
        team_acts = client.get(
            "/api/v1/activities?event=team_registered", headers=auth
        ).json()["items"]
        assert len(team_acts) <= len(all_acts)

    def test_instance_lifecycle_events(self, client):
        team = client.post("/api/v1/teams", json={"name": "evt", "agent": "x"}).json()
        auth = {"Authorization": f"Bearer {team['token']}"}
        instance_id = start_instance_and_wait(client, "WEB-001", headers=auth)
        client.delete(f"/api/v1/instances/{instance_id}", headers=auth)
        acts = client.get("/api/v1/activities", headers=auth).json()["items"]
        events = [a["event"] for a in acts]
        assert "instance_started" in events
        assert "instance_stopped" in events


# ============================================================================
# HTTP API surface — health, instance lifecycle, verify-flag, renew, auth.
# Uses an auto-spec-generating mock so tests can pick arbitrary challenge IDs.
# ============================================================================


@pytest.fixture
def auto_mock_env_manager():
    return make_mock_challenge_manager(
        flag="FLAG{deadbeef0123456789abcdef01234567}",
    )


@pytest.fixture
def auto_client(auto_mock_env_manager):
    """Authenticated TestClient: auto-registers a default team and pins its
    bearer token as a session-wide header so POST /instances (now
    auth-only) works without every test re-registering."""
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    with patch("ctfy.server.app.ChallengeManager", return_value=auto_mock_env_manager):
        app = create_app(external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend,
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        host="10.0.1.5",
    ):
        c = TestClient(app)
        r = c.post("/api/v1/teams", json={"name": "auto", "agent": "test"})
        c.headers["Authorization"] = f"Bearer {r.json()['token']}"
        yield c


@pytest.fixture
def auto_client_anon(auto_mock_env_manager):
    """Unauthenticated TestClient for tests that need to exercise the
    anonymous rejection path."""
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    with patch("ctfy.server.app.ChallengeManager", return_value=auto_mock_env_manager):
        app = create_app(external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend,
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        host="10.0.1.5",
    ):
        yield TestClient(app)


def _start_and_wait(c, challenge_id="TEST-001", *, max_wait=5, headers=None):
    """POST /instances + poll /status until ready. Returns (status_resp, id)."""
    resp = c.post(
        "/api/v1/instances",
        json={"challenge_id": challenge_id, "ttl": 300},
        headers=headers or {},
    )
    if resp.status_code == 409:
        return resp, None
    assert resp.status_code == 202
    instance_id = resp.json()["instance_id"]
    deadline = time.monotonic() + max_wait
    while time.monotonic() < deadline:
        s = c.get(f"/api/v1/instances/{instance_id}/status", headers=headers or {})
        if s.json().get("status") == "ready":
            return s, instance_id
        if s.json().get("status") == "error":
            raise RuntimeError(s.json().get("error"))
        time.sleep(0.1)
    raise TimeoutError(f"{instance_id} not ready after {max_wait}s")


class TestHealth:
    def test_health(self, auto_client):
        resp = auto_client.get("/api/v1/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert data["running_instances"] == 0
        assert data["capacity"] > 0


class TestMeta:
    def test_meta_public(self, client):
        # No auth header — ``/meta`` feeds the status bar for guests too.
        resp = client.get("/api/v1/meta")
        assert resp.status_code == 200
        data = resp.json()
        expected_keys = {
            "version",
            "started_at_ts",
            "server_time_ts",
            "challenges_total",
            "teams_total",
            "nodes_total",
            "nodes_healthy",
            "running_instances",
            "solves_total",
        }
        assert expected_keys <= set(data)
        assert isinstance(data["version"], str) and data["version"]
        assert data["server_time_ts"] >= data["started_at_ts"] > 0
        assert data["challenges_total"] >= 1  # TEST-001 fixture
        assert data["nodes_healthy"] <= data["nodes_total"]


class TestLifecycle:
    def test_start_returns_202(self, auto_client):
        resp = auto_client.post(
            "/api/v1/instances",
            json={"challenge_id": "TEST-001", "ttl": 300},
        )
        assert resp.status_code == 202
        data = resp.json()
        uuid.UUID(data["instance_id"])
        assert data["status"] == "starting"

    def test_status_becomes_ready(self, auto_client):
        s, _ = _start_and_wait(auto_client)
        data = s.json()
        assert data["status"] == "ready"
        assert data["attack_surface"] is not None
        assert data["attack_surface"]["services"][0]["host"] == "10.0.1.5"

    def test_flag_not_in_response(self, auto_client):
        resp = auto_client.post(
            "/api/v1/instances",
            json={"challenge_id": "TEST-002", "ttl": 300},
        )
        assert "flag" not in resp.json()

    def test_start_duplicate_409(self, auto_client):
        _start_and_wait(auto_client, "DUP-001")
        resp = auto_client.post(
            "/api/v1/instances",
            json={"challenge_id": "DUP-001", "ttl": 300},
        )
        assert resp.status_code == 409

    def test_start_anonymous_forbidden(self, auto_client_anon):
        resp = auto_client_anon.post(
            "/api/v1/instances",
            json={"challenge_id": "TEST-001", "ttl": 300},
        )
        # HTTPBearer(auto_error=True) returns 403 via HTTPException, but
        # FastAPI's default maps no-credential Bearer to 401.
        assert resp.status_code in (401, 403)

    def test_concurrent_same_challenge_different_teams(self, auto_mock_env_manager):
        """Two authenticated teams may launch the same challenge concurrently."""
        from ctfy.server.app import create_app

        backend = InMemoryBackend()
        with patch("ctfy.server.app.ChallengeManager", return_value=auto_mock_env_manager):
            app = create_app(external_host="10.0.1.5", backend=backend)
        with fake_node_context(
            backend,
            flag="FLAG{deadbeef0123456789abcdef01234567}",
            host="10.0.1.5",
        ):
            c = TestClient(app)
            t1 = c.post("/api/v1/teams", json={"name": "A", "agent": "x"}).json()
            t2 = c.post("/api/v1/teams", json={"name": "B", "agent": "x"}).json()
            h1 = {"Authorization": f"Bearer {t1['token']}"}
            h2 = {"Authorization": f"Bearer {t2['token']}"}

            r1 = c.post(
                "/api/v1/instances",
                json={"challenge_id": "CONC-001", "ttl": 300},
                headers=h1,
            )
            r2 = c.post(
                "/api/v1/instances",
                json={"challenge_id": "CONC-001", "ttl": 300},
                headers=h2,
            )
            assert r1.status_code == 202
            assert r2.status_code == 202
            assert r1.json()["instance_id"] != r2.json()["instance_id"]

    def test_list_instances(self, auto_client):
        _start_and_wait(auto_client)
        resp = auto_client.get("/api/v1/instances")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["items"]) >= 1
        assert data["total"] >= 1

    def test_list_instances_filter_challenge_id(self, auto_client):
        _start_and_wait(auto_client, "FILTER-001")
        resp = auto_client.get("/api/v1/instances?challenge_id=FILTER-001")
        assert resp.status_code == 200
        items = resp.json()["items"]
        assert len(items) == 1
        assert items[0]["challenge_id"] == "FILTER-001"

    def test_list_instances_filter_status(self, auto_client):
        _start_and_wait(auto_client, "STATUS-001")
        resp = auto_client.get("/api/v1/instances?status=ready")
        assert len(resp.json()["items"]) >= 1
        resp = auto_client.get("/api/v1/instances?status=error")
        assert all(e["status"] == "error" for e in resp.json()["items"])

    def test_list_instances_filter_q(self, auto_client):
        _start_and_wait(auto_client, "SEARCH-001")
        resp = auto_client.get("/api/v1/instances?q=SEARCH")
        assert len(resp.json()["items"]) >= 1
        resp = auto_client.get("/api/v1/instances?q=zzzzz")
        assert len(resp.json()["items"]) == 0

    def test_stop(self, auto_client):
        _, instance_id = _start_and_wait(auto_client)
        resp = auto_client.delete(f"/api/v1/instances/{instance_id}")
        assert resp.status_code == 200
        assert resp.json()["instance_id"] == instance_id
        assert auto_client.get("/api/v1/instances").json()["items"] == []

    def test_stop_missing_404(self, auto_client):
        resp = auto_client.delete("/api/v1/instances/NONEXISTENT")
        assert resp.status_code == 404

    def test_bulk_stop(self, auto_client):
        _start_and_wait(auto_client)
        resp = auto_client.delete("/api/v1/instances")
        assert resp.status_code == 403

    def test_bulk_stop_with_admin(self, auto_mock_env_manager):
        from ctfy.server.app import create_app

        backend = InMemoryBackend()
        backend.set_config("admin_key", ADMIN_KEY)
        with patch("ctfy.server.app.ChallengeManager", return_value=auto_mock_env_manager):
            app = create_app(external_host="10.0.1.5", backend=backend)
        with fake_node_context(
            backend,
            flag="FLAG{deadbeef0123456789abcdef01234567}",
            host="10.0.1.5",
        ):
            c = TestClient(app)
            # Start an instance as a regular team (starts require team auth now).
            team = c.post("/api/v1/teams", json={"name": "bulk", "agent": "x"}).json()
            team_headers = {"Authorization": f"Bearer {team['token']}"}
            _start_and_wait(c, headers=team_headers)
            # Bulk stop still requires admin.
            admin_headers = {"Authorization": f"Bearer {ADMIN_KEY}"}
            resp = c.delete("/api/v1/instances", headers=admin_headers)
            assert resp.status_code == 200
            assert len(resp.json()) >= 1


class TestAdminListInstances:
    """``GET /admin/instances`` returns cross-team instances for the admin
    dashboard — filterable by node_id so the nodes table can expand into
    "which instances run here"."""

    def _bootstrap(self, auto_mock_env_manager):
        from ctfy.server.app import create_app

        backend = InMemoryBackend()
        backend.set_config("admin_key", ADMIN_KEY)
        with patch("ctfy.server.app.ChallengeManager", return_value=auto_mock_env_manager):
            app = create_app(external_host="10.0.1.5", backend=backend)
        return app, backend

    def test_requires_admin(self, auto_mock_env_manager):
        app, _ = self._bootstrap(auto_mock_env_manager)
        c = TestClient(app)
        r = c.get("/api/v1/admin/instances")
        assert r.status_code in (401, 403)

    def test_returns_all_instances_and_exposes_node_id(self, auto_mock_env_manager):
        app, backend = self._bootstrap(auto_mock_env_manager)
        with fake_node_context(
            backend,
            flag="FLAG{deadbeef0123456789abcdef01234567}",
            host="10.0.1.5",
        ):
            c = TestClient(app)
            team = c.post("/api/v1/teams", json={"name": "adm-list", "agent": "x"}).json()
            _start_and_wait(c, headers={"Authorization": f"Bearer {team['token']}"})

            admin_hdr = {"Authorization": f"Bearer {ADMIN_KEY}"}
            r = c.get("/api/v1/admin/instances", headers=admin_hdr)
            assert r.status_code == 200
            items = r.json()["items"]
            assert len(items) >= 1
            # The fake node backend registers under this id; the payload
            # surfaces it so the dashboard can render / filter.
            assert items[0]["node_id"]

    def test_filters_by_node_id(self, auto_mock_env_manager):
        app, backend = self._bootstrap(auto_mock_env_manager)
        with fake_node_context(
            backend,
            flag="FLAG{deadbeef0123456789abcdef01234567}",
            host="10.0.1.5",
        ):
            c = TestClient(app)
            team = c.post("/api/v1/teams", json={"name": "adm-fltr", "agent": "x"}).json()
            _start_and_wait(c, headers={"Authorization": f"Bearer {team['token']}"})

            admin_hdr = {"Authorization": f"Bearer {ADMIN_KEY}"}
            all_items = c.get("/api/v1/admin/instances", headers=admin_hdr).json()["items"]
            real_node = all_items[0]["node_id"]

            matched = c.get(
                f"/api/v1/admin/instances?node_id={real_node}", headers=admin_hdr
            ).json()["items"]
            assert len(matched) == len(all_items)

            empty = c.get(
                "/api/v1/admin/instances?node_id=does-not-exist", headers=admin_hdr
            ).json()["items"]
            assert empty == []


class TestAdminStats:
    """/admin/overview + /admin/solve-matrix feed the admin dashboard's
    single-request landing page + the team × challenge grid."""

    def _bootstrap(self, auto_mock_env_manager):
        from ctfy.server.app import create_app

        backend = InMemoryBackend()
        backend.set_config("admin_key", ADMIN_KEY)
        with patch("ctfy.server.app.ChallengeManager", return_value=auto_mock_env_manager):
            app = create_app(external_host="10.0.1.5", backend=backend)
        return app, backend

    def test_overview_requires_admin(self, auto_mock_env_manager):
        app, _ = self._bootstrap(auto_mock_env_manager)
        c = TestClient(app)
        assert c.get("/api/v1/admin/overview").status_code in (401, 403)

    def test_overview_counts(self, auto_mock_env_manager):
        app, backend = self._bootstrap(auto_mock_env_manager)
        with fake_node_context(backend, flag="FLAG{deadbeef0123456789abcdef01234567}"):
            c = TestClient(app)
            team = c.post("/api/v1/teams", json={"name": "ov-t", "agent": "x"}).json()
            _start_and_wait(c, headers={"Authorization": f"Bearer {team['token']}"})

            admin_hdr = {"Authorization": f"Bearer {ADMIN_KEY}"}
            r = c.get("/api/v1/admin/overview", headers=admin_hdr)
            assert r.status_code == 200, r.text
            body = r.json()
            assert body["nodes"]["total"] == 1
            assert body["nodes"]["healthy"] == 1
            assert body["teams_total"] == 1
            # running_instances is driven by node heartbeats; the fake node
            # doesn't heartbeat, so just sanity-check the key shape.
            assert "running_instances" in body
            assert isinstance(body["solves_today"], int)

    def test_solve_matrix_requires_admin(self, auto_mock_env_manager):
        app, _ = self._bootstrap(auto_mock_env_manager)
        c = TestClient(app)
        assert c.get("/api/v1/admin/solve-matrix").status_code in (401, 403)

    def test_solve_matrix_records_first_blood(self, mock_env_manager):
        # Use the fixture that pre-defines WEB-001 as a spec so the matrix
        # column appears. auto_mock_env_manager auto-generates specs only
        # during iter_specs(challenge_id=...) lookups, not bulk iter_specs().
        app, backend = self._bootstrap(mock_env_manager)
        with fake_node_context(backend, flag="FLAG{deadbeef0123456789abcdef01234567}"):
            c = TestClient(app)
            team = c.post("/api/v1/teams", json={"name": "fb", "agent": "x"}).json()
            auth = {"Authorization": f"Bearer {team['token']}"}
            _start_and_wait(c, challenge_id="WEB-001", headers=auth)
            c.post(
                "/api/v1/submissions",
                json={
                    "challenge_id": "WEB-001",
                    "flag": "FLAG{deadbeef0123456789abcdef01234567}",
                },
                headers=auth,
            )

            admin_hdr = {"Authorization": f"Bearer {ADMIN_KEY}"}
            r = c.get("/api/v1/admin/solve-matrix", headers=admin_hdr)
            assert r.status_code == 200, r.text
            body = r.json()
            teams = body["teams"]
            cells = body["cells"]
            assert any(t["name"] == "fb" and t["solved"] == 1 for t in teams)
            solved = [cell for cell in cells if cell["solved"]]
            assert solved
            assert any(cell["first_blood"] for cell in solved)
            # Columns include the challenge we solved.
            assert any(col["challenge_id"] == "WEB-001" for col in body["challenges"])


class TestVerifyFlag:
    def test_correct_flag(self, auto_client):
        _, instance_id = _start_and_wait(auto_client, "FLAG-TEST")
        resp = auto_client.post(
            f"/api/v1/instances/{instance_id}/verify-flag",
            json={"claimed_flag": "FLAG{deadbeef0123456789abcdef01234567}"},
        )
        assert resp.status_code == 200
        assert resp.json()["correct"] is True

    def test_wrong_flag(self, auto_client):
        _, instance_id = _start_and_wait(auto_client, "FLAG-TEST2")
        resp = auto_client.post(
            f"/api/v1/instances/{instance_id}/verify-flag",
            json={"claimed_flag": "FLAG{wrong}"},
        )
        assert resp.status_code == 200
        assert resp.json()["correct"] is False

    def test_verify_missing_instance_404(self, auto_client):
        resp = auto_client.post(
            "/api/v1/instances/NONEXISTENT/verify-flag",
            json={"claimed_flag": "FLAG{x}"},
        )
        assert resp.status_code == 404


class TestRenew:
    def test_renew(self, auto_client):
        _, instance_id = _start_and_wait(auto_client, "TTL-TEST")
        resp = auto_client.post(f"/api/v1/instances/{instance_id}/renew?ttl=3600")
        assert resp.status_code == 200
        assert resp.json()["instance_id"] == instance_id

    def test_renew_missing_404(self, auto_client):
        resp = auto_client.post("/api/v1/instances/NONEXISTENT/renew?ttl=60")
        assert resp.status_code == 404


class TestAuth:
    def test_no_auth_required_by_default(self, auto_client):
        resp = auto_client.get("/api/v1/health")
        assert resp.status_code == 200

    def test_public_routes_accessible_when_admin_configured(self, auto_mock_env_manager):
        from ctfy.server.app import create_app

        config = CtfyConfig(admin_token=SecretStr("secret123"))
        with patch("ctfy.server.app.ChallengeManager", return_value=auto_mock_env_manager):
            app = create_app(config, external_host="127.0.0.1", backend=InMemoryBackend())
        c = TestClient(app)
        assert c.get("/api/v1/health").status_code == 200

    def test_admin_only_routes_require_admin_token(self, auto_mock_env_manager):
        from ctfy.server.app import create_app

        config = CtfyConfig(admin_token=SecretStr("secret123"))
        with patch("ctfy.server.app.ChallengeManager", return_value=auto_mock_env_manager):
            app = create_app(config, external_host="127.0.0.1", backend=InMemoryBackend())
        c = TestClient(app)
        assert c.get("/api/v1/cluster-info").status_code == 401
        assert (
            c.get("/api/v1/cluster-info", headers={"Authorization": "Bearer wrong"}).status_code
            == 403
        )
        assert (
            c.get("/api/v1/cluster-info", headers={"Authorization": "Bearer secret123"}).status_code
            == 200
        )


# ============================================================================
# Async startup happy-path — exercises the post → poll → verify-flag → stop
# loop with a separate port (verifies port plumbing).
# ============================================================================


@pytest.fixture
def async_client():
    from ctfy.server.app import create_app

    mock_mgr = make_mock_challenge_manager(
        flag="FLAG{testflag123456789abcdef01234567}",
        port=9090,
    )
    backend = InMemoryBackend()
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_mgr):
        app = create_app(external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend,
        flag="FLAG{testflag123456789abcdef01234567}",
        host="10.0.1.5",
        port=9090,
    ):
        with TestClient(app) as c:
            r = c.post("/api/v1/teams", json={"name": "async", "agent": "test"})
            c.headers["Authorization"] = f"Bearer {r.json()['token']}"
            yield c


def _async_start(c, challenge_id="E2E-001"):
    resp = c.post(
        "/api/v1/instances",
        json={"challenge_id": challenge_id, "ttl": 300},
    )
    instance_id = resp.json()["instance_id"]
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        s = c.get(f"/api/v1/instances/{instance_id}/status")
        if s.json().get("status") == "ready":
            return instance_id
        time.sleep(0.1)
    raise TimeoutError(f"{instance_id} not ready")


class TestAsyncStartup:
    def test_post_returns_202(self, async_client):
        resp = async_client.post(
            "/api/v1/instances",
            json={"challenge_id": "T1", "ttl": 300},
        )
        assert resp.status_code == 202
        assert resp.json()["status"] == "starting"

    def test_status_becomes_ready(self, async_client):
        instance_id = _async_start(async_client, "T2")
        s = async_client.get(f"/api/v1/instances/{instance_id}/status")
        assert s.json()["status"] == "ready"
        assert s.json()["attack_surface"]["services"][0]["host"] == "10.0.1.5"

    def test_verify_flag_after_ready(self, async_client):
        instance_id = _async_start(async_client, "T3")
        r = async_client.post(
            f"/api/v1/instances/{instance_id}/verify-flag",
            json={"claimed_flag": "FLAG{testflag123456789abcdef01234567}"},
        )
        assert r.json()["correct"] is True

    def test_full_lifecycle(self, async_client):
        instance_id = _async_start(async_client, "T4")
        r = async_client.post(
            f"/api/v1/instances/{instance_id}/verify-flag",
            json={"claimed_flag": "FLAG{wrong}"},
        )
        assert r.json()["correct"] is False
        async_client.delete(f"/api/v1/instances/{instance_id}")
        assert async_client.get(f"/api/v1/instances/{instance_id}/status").status_code == 404
