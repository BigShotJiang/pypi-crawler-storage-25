"""Unit tests for StateBackend (InMemoryBackend)."""

import threading
import time

import pytest

from ctfy.core.state import (
    ActivityState,
    InMemoryBackend,
    InstanceState,
    ScoreboardSnapshotState,
    SolveState,
    SubmissionState,
    TeamState,
    create_backend,
)


@pytest.fixture
def be():
    return InMemoryBackend()


# -- instance CRUD ----------------------------------------------------------


class TestInstanceCRUD:
    def test_put_get(self, be):
        be.put_instance(
            "env-1",
            InstanceState(flags={"main": "FLAG{abc}"}, status="ready"),
            ttl=60,
        )
        inst = be.get_instance("env-1")
        assert inst is not None
        assert inst.flags == {"main": "FLAG{abc}"}
        assert inst.ttl == 60
        assert inst.expires_at > 0
        assert inst.started_at > 0

    def test_get_missing(self, be):
        assert be.get_instance("nonexistent") is None

    def test_remove(self, be):
        be.put_instance("env-1", InstanceState(flags={"main": "x"}))
        removed = be.remove_instance("env-1")
        assert removed is not None
        assert removed.flags == {"main": "x"}
        assert be.get_instance("env-1") is None

    def test_remove_missing(self, be):
        assert be.remove_instance("nonexistent") is None

    def test_list_instances(self, be):
        be.put_instance("a", InstanceState(flags={"main": "1"}))
        be.put_instance("b", InstanceState(flags={"main": "2"}))
        instances = be.list_instances()
        ids = {e.instance_id for e in instances}
        assert ids == {"a", "b"}

    def test_count(self, be):
        assert be.count_instances() == 0
        be.put_instance("a", InstanceState())
        assert be.count_instances() == 1

    def test_no_ttl(self, be):
        be.put_instance("env-1", InstanceState(flags={"main": "x"}), ttl=0)
        inst = be.get_instance("env-1")
        assert inst.expires_at == 0.0


# -- TTL & renew -------------------------------------------------------------


class TestTTL:
    def test_renew(self, be):
        be.put_instance("env-1", InstanceState(), ttl=10)
        new_exp = be.renew_instance("env-1", ttl=3600)
        assert new_exp > time.time() + 3500

    def test_renew_missing(self, be):
        with pytest.raises(KeyError):
            be.renew_instance("nonexistent", 60)

    def test_pop_expired(self, be):
        be.put_instance("old", InstanceState(), ttl=1)
        be.put_instance("new", InstanceState(), ttl=9999)
        # Force expiry
        be._instances["old"] = be._instances["old"].model_copy(
            update={"expires_at": time.time() - 1}
        )
        expired = be.pop_expired_instances()
        assert len(expired) == 1
        assert expired[0].instance_id == "old"
        assert be.get_instance("old") is None
        assert be.get_instance("new") is not None

    def test_pop_no_expired(self, be):
        be.put_instance("fresh", InstanceState(), ttl=9999)
        assert be.pop_expired_instances() == []


# -- teams -------------------------------------------------------------------


class TestTeams:
    def test_put_get(self, be):
        be.put_team("t1", TeamState(team_id="t1", name="Alpha", token="k1"))
        t = be.get_team("t1")
        assert t.name == "Alpha"

    def test_get_missing(self, be):
        assert be.get_team("nope") is None

    def test_get_by_token(self, be):
        be.put_team("t1", TeamState(team_id="t1", name="A", token="secret"))
        t = be.get_team_by_token("secret")
        assert t.team_id == "t1"

    def test_get_by_invalid_key(self, be):
        assert be.get_team_by_token("invalid") is None

    def test_list(self, be):
        be.put_team("t1", TeamState(team_id="t1", name="A", token="k1"))
        be.put_team("t2", TeamState(team_id="t2", name="B", token="k2"))
        assert len(be.list_teams()) == 2


# -- submissions -------------------------------------------------------------


class TestSubmissions:
    def test_add_and_list(self, be):
        be.add_submission(
            SubmissionState(submission_id="s1", team_id="t1", challenge_id="c1", correct=True)
        )
        be.add_submission(
            SubmissionState(submission_id="s2", team_id="t1", challenge_id="c2", correct=False)
        )
        assert len(be.list_submissions()) == 2

    def test_filter_by_team(self, be):
        be.add_submission(
            SubmissionState(submission_id="s1", team_id="t1", challenge_id="c1", correct=True)
        )
        be.add_submission(
            SubmissionState(submission_id="s2", team_id="t2", challenge_id="c1", correct=False)
        )
        assert len(be.list_submissions(team_id="t1")) == 1

    def test_filter_by_challenge(self, be):
        be.add_submission(
            SubmissionState(submission_id="s1", team_id="t1", challenge_id="c1", correct=True)
        )
        be.add_submission(
            SubmissionState(submission_id="s2", team_id="t1", challenge_id="c2", correct=False)
        )
        assert len(be.list_submissions(challenge_id="c1")) == 1


# -- solves ------------------------------------------------------------------


class TestSolves:
    def test_add_and_get(self, be):
        be.add_solve("t1", "c1", "main", SolveState(solved_at="2026-01-01"))
        s = be.get_solve("t1", "c1", "main")
        assert s.solved_at == "2026-01-01"
        assert s.flag_id == "main"

    def test_get_missing(self, be):
        assert be.get_solve("t1", "c99", "main") is None

    def test_dedup(self, be):
        be.add_solve("t1", "c1", "main", SolveState(solved_at="first"))
        be.add_solve("t1", "c1", "main", SolveState(solved_at="second"))  # ignored
        assert be.get_solve("t1", "c1", "main").solved_at == "first"

    def test_list_by_team(self, be):
        be.add_solve("t1", "c1", "main", SolveState())
        be.add_solve("t1", "c2", "main", SolveState())
        be.add_solve("t2", "c1", "main", SolveState())
        assert len(be.list_solves("t1")) == 2
        assert len(be.list_solves("t2")) == 1

    def test_multi_flag_per_challenge(self, be):
        """Same challenge, different flag ids — two distinct SolveStates."""
        be.add_solve("t1", "c1", "foothold", SolveState(solved_at="a"))
        be.add_solve("t1", "c1", "root", SolveState(solved_at="b"))
        assert be.get_solve("t1", "c1", "foothold").solved_at == "a"
        assert be.get_solve("t1", "c1", "root").solved_at == "b"
        assert len(be.list_solves("t1")) == 2

    def test_count_for_flag(self, be):
        be.add_solve("t1", "c1", "foothold", SolveState())
        be.add_solve("t2", "c1", "foothold", SolveState())
        be.add_solve("t1", "c1", "root", SolveState())
        assert be.count_solves_for_flag("c1", "foothold") == 2
        assert be.count_solves_for_flag("c1", "root") == 1
        assert be.count_solves_for_flag("c1", "missing") == 0

    def test_count_for_challenge_requires_all_flags(self, be):
        # t1 captures both flags → fully solved.
        be.add_solve("t1", "c1", "foothold", SolveState())
        be.add_solve("t1", "c1", "root", SolveState())
        # t2 only captures one → not fully solved.
        be.add_solve("t2", "c1", "foothold", SolveState())
        assert be.count_solves_for_challenge("c1", ("foothold", "root")) == 1
        # Single-flag flavor.
        be.add_solve("t1", "c2", "main", SolveState())
        be.add_solve("t2", "c2", "main", SolveState())
        assert be.count_solves_for_challenge("c2", ("main",)) == 2
        assert be.count_solves_for_challenge("c99", ("main",)) == 0
        # Empty flag tuple → undefined, returns 0 (caller forgot to pass the spec).
        assert be.count_solves_for_challenge("c1", ()) == 0


# -- activity log ------------------------------------------------------------


def _act(**kw) -> ActivityState:
    """Build an ActivityState for tests with sensible actor defaults.

    The schema now requires actor_id/actor_name/actor_type; spelling the
    defaults out in every test would be noise, so centralise here.
    """
    defaults = {"actor_id": kw.get("team_id", ""), "actor_name": "", "actor_type": "team"}
    defaults.update(kw)
    return ActivityState(**defaults)


class TestActivityLog:
    def test_add_and_list(self, be):
        be.add_activity(
            _act(timestamp="t1", event="instance_started", team_id="t1", challenge_id="c1")
        )
        be.add_activity(_act(timestamp="t2", event="flag_correct", team_id="t1", challenge_id="c1"))
        acts = be.list_activities()
        assert len(acts) == 2
        # Most recent first
        assert acts[0].event == "flag_correct"

    def test_filter_by_event(self, be):
        be.add_activity(_act(timestamp="t1", event="instance_started"))
        be.add_activity(_act(timestamp="t2", event="flag_correct"))
        acts = be.list_activities(event="flag_correct")
        assert len(acts) == 1

    def test_filter_by_team(self, be):
        be.add_activity(_act(timestamp="t1", event="x", team_id="t1"))
        be.add_activity(_act(timestamp="t2", event="x", team_id="t2"))
        assert len(be.list_activities(team_id="t1")) == 1

    def test_filter_by_actor(self, be):
        be.add_activity(_act(timestamp="t1", event="x", actor_id="admin", actor_type="admin"))
        be.add_activity(_act(timestamp="t2", event="x", actor_id="system", actor_type="system"))
        be.add_activity(_act(timestamp="t3", event="x", actor_id="admin", actor_type="admin"))
        assert len(be.list_activities(actor_id="admin")) == 2
        assert len(be.list_activities(actor_id="system")) == 1

    def test_limit(self, be):
        for i in range(10):
            be.add_activity(_act(timestamp=f"t{i}", event="x"))
        assert len(be.list_activities(limit=3)) == 3

    def test_offset(self, be):
        for i in range(10):
            be.add_activity(_act(timestamp=f"t{i}", event="x"))
        page1 = be.list_activities(offset=0, limit=3)
        page2 = be.list_activities(offset=3, limit=3)
        assert len(page1) == 3
        assert len(page2) == 3
        assert page1 != page2  # different items

    def test_count_activities(self, be):
        be.add_activity(
            _act(timestamp="t1", event="instance_started", team_id="t1", challenge_id="c1")
        )
        be.add_activity(_act(timestamp="t2", event="flag_correct", team_id="t1", challenge_id="c1"))
        be.add_activity(
            _act(timestamp="t3", event="instance_started", team_id="t2", challenge_id="c2")
        )
        assert be.count_activities() == 3
        assert be.count_activities(team_id="t1") == 2
        assert be.count_activities(event="flag_correct") == 1


def _snap(**kw) -> ScoreboardSnapshotState:
    defaults = {
        "snapshot_at": "t",
        "snapshot_at_ts": 0.0,
        "team_id": "t1",
        "team_name": "t1",
        "rank": 1,
        "solved": 0,
        "attempts": 0,
    }
    defaults.update(kw)
    return ScoreboardSnapshotState(**defaults)


class TestScoreboardSnapshots:
    def test_append_and_list_ascending(self, be):
        be.append_snapshot_batch(
            [
                _snap(team_id="t1", snapshot_at_ts=100.0, rank=2),
                _snap(team_id="t2", snapshot_at_ts=100.0, rank=1),
                _snap(team_id="t1", snapshot_at_ts=200.0, rank=1),
            ]
        )
        rows = be.list_snapshots()
        assert [r.snapshot_at_ts for r in rows] == [100.0, 100.0, 200.0]

    def test_filter_by_team(self, be):
        be.append_snapshot_batch(
            [
                _snap(team_id="t1", snapshot_at_ts=100.0),
                _snap(team_id="t2", snapshot_at_ts=100.0),
                _snap(team_id="t1", snapshot_at_ts=200.0),
            ]
        )
        t1 = be.list_snapshots(team_id="t1")
        assert len(t1) == 2
        assert all(r.team_id == "t1" for r in t1)

    def test_filter_by_since(self, be):
        be.append_snapshot_batch(
            [
                _snap(snapshot_at_ts=100.0),
                _snap(snapshot_at_ts=200.0),
                _snap(snapshot_at_ts=300.0),
            ]
        )
        rows = be.list_snapshots(since_ts=200.0)
        assert [r.snapshot_at_ts for r in rows] == [200.0, 300.0]

    def test_limit_keeps_newest(self, be):
        be.append_snapshot_batch([_snap(snapshot_at_ts=float(i)) for i in range(10)])
        rows = be.list_snapshots(limit=3)
        # Ascending output, last 3 by timestamp
        assert [r.snapshot_at_ts for r in rows] == [7.0, 8.0, 9.0]

    def test_empty_batch_no_op(self, be):
        be.append_snapshot_batch([])
        assert be.list_snapshots() == []


# -- thread safety -----------------------------------------------------------


class TestThreadSafety:
    def test_concurrent_put_get(self, be):
        errors = []

        def worker(instance_id):
            try:
                for _ in range(100):
                    be.put_instance(
                        instance_id,
                        InstanceState(flags={"main": instance_id}),
                        ttl=60,
                    )
                    inst = be.get_instance(instance_id)
                    assert inst is not None
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=worker, args=(f"env-{i}",)) for i in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        assert not errors


# -- factory ------------------------------------------------------------------


class TestFactory:
    def test_default_sqlite(self, tmp_path):
        be = create_backend(project_root=tmp_path)
        from ctfy.core.state import SQLiteBackend

        assert isinstance(be, SQLiteBackend)

    def test_in_memory_when_no_inputs(self):
        """No db_path, no project_root → InMemoryBackend."""
        from ctfy.core.state import InMemoryBackend

        assert isinstance(create_backend(), InMemoryBackend)

    def test_sqlite_persistence(self):
        """Data survives backend reopen (simulates server restart)."""
        import os
        import tempfile

        from ctfy.core.state import SQLiteBackend

        db = tempfile.mktemp(suffix=".db")
        try:
            be1 = SQLiteBackend(db)
            be1.put_team("t1", TeamState(team_id="t1", name="Persistent"))
            be1.add_solve("t1", "c1", "main", SolveState(solved_at="now"))
            del be1

            be2 = SQLiteBackend(db)
            assert be2.get_team("t1").name == "Persistent"
            assert be2.count_solves_for_challenge("c1", ("main",)) == 1
            # Instances are ephemeral — lost after restart
            assert be2.get_instance("any") is None
        finally:
            os.unlink(db)
