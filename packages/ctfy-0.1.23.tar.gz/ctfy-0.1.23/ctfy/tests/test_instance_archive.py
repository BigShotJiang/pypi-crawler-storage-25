"""Tests for instance archival (SQLite + InMemory + filesystem + hooks)."""

from __future__ import annotations

import time
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.enums import InstanceStatus
from ctfy.core.state import InMemoryBackend, SQLiteBackend
from ctfy.core.state.models import InstanceRecord
from ctfy.server.instance_archive import InstanceArchive

# ---------------------------------------------------------------------------
# DB archive — parity between in-memory + sqlite backends
# ---------------------------------------------------------------------------


def _seed(backend, instance_id: str, **overrides) -> InstanceRecord:
    rec = InstanceRecord(
        instance_id=instance_id,
        challenge_id=overrides.pop("challenge_id", "ch1"),
        team_id=overrides.pop("team_id", "team-a"),
        node_id=overrides.pop("node_id", "node-1"),
        status=overrides.pop("status", InstanceStatus.STOPPED),
        stop_reason=overrides.pop("stop_reason", "user"),
        started_at=overrides.pop("started_at", time.time() - 60),
        stopped_at=overrides.pop("stopped_at", time.time()),
        duration_s=overrides.pop("duration_s", 60.0),
        **overrides,
    )
    backend.archive_instance(rec)
    return rec


@pytest.mark.parametrize(
    "make_backend",
    [
        lambda tmp: InMemoryBackend(),
        lambda tmp: SQLiteBackend(str(tmp / "state.sqlite3")),
    ],
    ids=["memory", "sqlite"],
)
def test_archive_roundtrip(tmp_path, make_backend):
    be = make_backend(tmp_path)
    _seed(be, "inst-1", team_id="t1", challenge_id="c1")
    got = be.get_instance_record("inst-1")
    assert got is not None and got.instance_id == "inst-1"
    assert got.team_id == "t1"
    assert got.duration_s == 60.0


@pytest.mark.parametrize(
    "make_backend",
    [
        lambda tmp: InMemoryBackend(),
        lambda tmp: SQLiteBackend(str(tmp / "state.sqlite3")),
    ],
    ids=["memory", "sqlite"],
)
def test_archive_filters(tmp_path, make_backend):
    be = make_backend(tmp_path)
    _seed(be, "i1", team_id="t1", challenge_id="c1", node_id="n1")
    _seed(be, "i2", team_id="t2", challenge_id="c1", node_id="n2")
    _seed(be, "i3", team_id="t1", challenge_id="c2", node_id="n1")

    assert be.count_instance_records() == 3
    assert be.count_instance_records(team_id="t1") == 2
    assert be.count_instance_records(challenge_id="c1") == 2
    assert be.count_instance_records(node_id="n2") == 1
    assert be.count_instance_records(team_id="t1", challenge_id="c2") == 1
    assert be.count_instance_records(team_id="nope") == 0

    page1 = be.list_instance_records(team_id="t1", offset=0, limit=1)
    assert len(page1) == 1
    page2 = be.list_instance_records(team_id="t1", offset=1, limit=1)
    assert len(page2) == 1
    assert page1[0].instance_id != page2[0].instance_id


@pytest.mark.parametrize(
    "make_backend",
    [
        lambda tmp: InMemoryBackend(),
        lambda tmp: SQLiteBackend(str(tmp / "state.sqlite3")),
    ],
    ids=["memory", "sqlite"],
)
def test_archive_replace_is_idempotent(tmp_path, make_backend):
    be = make_backend(tmp_path)
    _seed(be, "inst-1", stop_reason="user")
    _seed(be, "inst-1", stop_reason="ttl_expired")  # second archive wins
    assert be.count_instance_records() == 1
    assert be.get_instance_record("inst-1").stop_reason == "ttl_expired"


def test_sqlite_archive_survives_restart(tmp_path):
    db = str(tmp_path / "state.sqlite3")
    be = SQLiteBackend(db)
    _seed(be, "inst-r", team_id="t1")
    # Simulate a process restart.
    be2 = SQLiteBackend(db)
    got = be2.get_instance_record("inst-r")
    assert got is not None
    assert got.instance_id == "inst-r"
    assert got.team_id == "t1"


# ---------------------------------------------------------------------------
# InstanceArchive filesystem sink
# ---------------------------------------------------------------------------


def test_filesystem_archive_roundtrip(tmp_path):
    arch = InstanceArchive(tmp_path / "archive")
    rec = InstanceRecord(instance_id="inst-1", status="STOPPED", stop_reason="user")
    arch.write_manifest(rec, {"id": "c1", "name": "C1"})
    arch.append_event("inst-1", {"event": "INSTANCE_STARTED", "ts": 1})
    arch.append_event("inst-1", {"event": "INSTANCE_READY", "ts": 2})
    arch.append_submission("inst-1", {"correct": False})
    arch.append_submission("inst-1", {"correct": True})
    arch.write_container_logs("inst-1", "stdout line\nstderr line\n")

    root = tmp_path / "archive" / "inst-1"
    assert (root / "instance.json").is_file()
    assert (root / "events.jsonl").is_file()
    assert (root / "submissions.jsonl").is_file()
    assert (root / "container.log").is_file()

    events = arch.read_events("inst-1")
    assert [e["event"] for e in events] == ["INSTANCE_STARTED", "INSTANCE_READY"]
    subs = arch.read_submissions("inst-1")
    assert [s["correct"] for s in subs] == [False, True]
    assert "stdout line" in arch.read_container_log("inst-1")


def test_filesystem_archive_missing_instance_reads_return_empty(tmp_path):
    arch = InstanceArchive(tmp_path / "archive")
    assert arch.read_events("nonexistent") == []
    assert arch.read_submissions("nonexistent") == []
    assert arch.read_container_log("nonexistent") == ""
    assert not arch.has_artifact("nonexistent", "anything")


def test_filesystem_archive_corrupt_jsonl_line_is_skipped(tmp_path):
    arch = InstanceArchive(tmp_path / "archive")
    arch.append_event("inst-1", {"event": "ok"})
    (tmp_path / "archive" / "inst-1" / "events.jsonl").open("a").write(
        'not-json\n{"event": "also-ok"}\n'
    )
    events = arch.read_events("inst-1")
    assert [e["event"] for e in events] == ["ok", "also-ok"]


# ---------------------------------------------------------------------------
# End-to-end: lifecycle hooks produce DB row + filesystem artifacts
# ---------------------------------------------------------------------------


def test_stop_instance_archives_record_and_events(tmp_path, mock_env_manager, backend, monkeypatch):
    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import fake_node_context, start_instance_and_wait

    archive_dir = tmp_path / "archive"
    cfg = CtfyConfig(instance_archive_dir=archive_dir)

    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend,
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        host="10.0.1.5",
    ):
        client = TestClient(app)
        # Create a team so POST /instances has an authenticated caller.
        team_resp = client.post(
            "/api/v1/teams",
            json={"name": "tester", "agent": "a", "description": "d"},
        )
        token = team_resp.json()["token"]
        hdr = {"Authorization": f"Bearer {token}"}

        iid = start_instance_and_wait(client, "E1", headers=hdr)
        # DELETE the instance — this should archive it.
        del_resp = client.delete(f"/api/v1/instances/{iid}", headers=hdr)
        assert del_resp.status_code == 200

    # DB row exists
    rec = backend.get_instance_record(iid)
    assert rec is not None
    assert rec.stop_reason == "user"
    assert rec.status == "stopped"
    # Filesystem artifacts
    assert (archive_dir / iid / "instance.json").is_file()
    events = (archive_dir / iid / "events.jsonl").read_text().strip().splitlines()
    # Expect at least STARTED + READY + STOPPED events mirrored into the stream
    assert any("instance_started" in ln or "INSTANCE_STARTED" in ln for ln in events)
    assert any("instance_stopped" in ln or "INSTANCE_STOPPED" in ln for ln in events)


def test_admin_list_and_detail_endpoints(tmp_path, mock_env_manager, backend, monkeypatch):
    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app
    from ctfy.tests.conftest import fake_node_context, start_instance_and_wait

    archive_dir = tmp_path / "archive"
    monkeypatch.setenv("CTFY_ADMIN_TOKEN", "adm-secret-123")
    cfg = CtfyConfig.from_env(overrides={"instance_archive_dir": archive_dir})

    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    with fake_node_context(
        backend,
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        host="10.0.1.5",
    ):
        client = TestClient(app)
        team_resp = client.post(
            "/api/v1/teams",
            json={"name": "tester", "agent": "a", "description": "d"},
        )
        token = team_resp.json()["token"]
        hdr = {"Authorization": f"Bearer {token}"}
        iid = start_instance_and_wait(client, "E1", headers=hdr)
        client.delete(f"/api/v1/instances/{iid}", headers=hdr)

        admin_hdr = {"Authorization": "Bearer adm-secret-123"}
        # List
        r = client.get("/api/v1/admin/instance-records", headers=admin_hdr)
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["total"] >= 1
        assert any(item["instance_id"] == iid for item in body["items"])

        # Filtered list
        r2 = client.get(
            "/api/v1/admin/instance-records",
            headers=admin_hdr,
            params={"team_id": "nonexistent"},
        )
        assert r2.json()["total"] == 0

        # Detail
        r3 = client.get(f"/api/v1/admin/instance-records/{iid}", headers=admin_hdr)
        assert r3.status_code == 200, r3.text
        detail = r3.json()
        assert detail["record"]["instance_id"] == iid
        assert detail["artifacts"]["has_manifest"] is True

        # Events + submissions
        evs = client.get(f"/api/v1/admin/instance-records/{iid}/events", headers=admin_hdr).json()
        assert isinstance(evs, list) and len(evs) >= 1

        subs = client.get(
            f"/api/v1/admin/instance-records/{iid}/submissions", headers=admin_hdr
        ).json()
        assert isinstance(subs, list)


def test_non_admin_cannot_list_instance_records(tmp_path, mock_env_manager, backend):
    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app

    cfg = CtfyConfig(instance_archive_dir=tmp_path / "archive")
    with patch("ctfy.server.app.ChallengeManager", return_value=mock_env_manager):
        app = create_app(config=cfg, external_host="10.0.1.5", backend=backend)
    client = TestClient(app)
    r = client.get("/api/v1/admin/instance-records")
    assert r.status_code in (401, 403)
