"""Unit tests for ``ctfy.core.flag`` — generation and verification."""

from __future__ import annotations

import pytest

from ctfy.core.exceptions import FlagNotFoundError, InstanceNotFoundError
from ctfy.core.flag import generate_flag, generate_flags, verify_flag
from ctfy.core.state import InMemoryBackend
from ctfy.core.state.models import InstanceState


@pytest.fixture
def be():
    return InMemoryBackend()


class TestGenerate:
    def test_generate_flag_format(self):
        flag = generate_flag()
        assert flag.startswith("FLAG{")
        assert flag.endswith("}")
        # 32 bytes -> 64 hex chars between braces.
        assert len(flag) == 5 + 64 + 1

    def test_generate_flag_unique(self):
        seen = {generate_flag() for _ in range(100)}
        assert len(seen) == 100

    def test_generate_flags_per_id(self):
        flags = generate_flags(["foothold", "root"])
        assert set(flags) == {"foothold", "root"}
        # Every value is a fresh, distinct FLAG{...} token.
        assert flags["foothold"] != flags["root"]
        for v in flags.values():
            assert v.startswith("FLAG{") and v.endswith("}")

    def test_generate_flags_empty_ids(self):
        assert generate_flags([]) == {}

    def test_generate_flags_single(self):
        flags = generate_flags(["main"])
        assert list(flags) == ["main"]


class TestVerifyFlag:
    def _seed(self, be: InMemoryBackend, flags: dict[str, str]) -> str:
        be.put_instance("inst-1", InstanceState(flags=flags))
        return "inst-1"

    def test_exact_match_returns_flag_id(self, be):
        flag = "FLAG{deadbeef0123456789abcdef01234567}"
        self._seed(be, {"main": flag})
        assert verify_flag(be, "inst-1", flag) == "main"

    def test_wrong_flag_returns_none(self, be):
        self._seed(be, {"main": "FLAG{correct}"})
        assert verify_flag(be, "inst-1", "FLAG{wrong}") is None

    def test_wrapper_tolerated(self, be):
        """Submitting the wrapped form works even if stored value is wrapped too."""
        self._seed(be, {"main": "FLAG{abc}"})
        # Exact match on wrapped form.
        assert verify_flag(be, "inst-1", "FLAG{abc}") == "main"
        # Inner-only claim does NOT match a wrapped stored value (current
        # behavior is symmetric — wrapper regex strips the claim side).
        assert verify_flag(be, "inst-1", "abc") is None

    def test_multi_flag_matches_hit_id(self, be):
        self._seed(
            be,
            {"foothold": "FLAG{a}", "root": "FLAG{b}"},
        )
        assert verify_flag(be, "inst-1", "FLAG{a}") == "foothold"
        assert verify_flag(be, "inst-1", "FLAG{b}") == "root"
        assert verify_flag(be, "inst-1", "FLAG{nope}") is None

    def test_instance_missing(self, be):
        with pytest.raises(InstanceNotFoundError):
            verify_flag(be, "ghost", "FLAG{x}")

    def test_instance_without_flags(self, be):
        be.put_instance("empty", InstanceState())
        with pytest.raises(FlagNotFoundError):
            verify_flag(be, "empty", "FLAG{x}")
