"""Schema tests for :class:`ctfy.core.challenge.ChallengeSpec`.

The upstream challenges repo enforces a slim v3 metadata contract — four
required fields, no unknown keys, difficulty restricted to {easy, medium,
hard}, tags non-empty. These tests pin the pydantic model to that contract
so we can't silently accept drift.
"""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml
from pydantic import ValidationError

from ctfy.core.challenge import ChallengeSpec
from ctfy.core.enums import Difficulty


def _write_metadata(tmp_path, challenge_id: str, body: dict) -> Path:
    d = tmp_path / challenge_id
    d.mkdir()
    yml = d / "metadata.yaml"
    yml.write_text(yaml.safe_dump(body, sort_keys=False))
    return yml


def test_from_yaml_injects_id_from_dirname(tmp_path):
    yml = _write_metadata(
        tmp_path,
        "CTFARENA-XX",
        {
            "name": "SampleCTF",
            "description": "desc",
            "difficulty": "easy",
            "tags": ["idor"],
        },
    )
    spec = ChallengeSpec.from_yaml(yml)
    assert spec.id == "CTFARENA-XX"
    assert spec.difficulty is Difficulty.EASY
    assert spec.tags == ["idor"]


def test_rejects_unknown_fields(tmp_path):
    """META005: any key beyond the four allowed ones must fail."""
    yml = _write_metadata(
        tmp_path,
        "CTFARENA-01",
        {
            "name": "X",
            "description": "x",
            "difficulty": "easy",
            "tags": ["t"],
            "origin": "legacy",  # forbidden
        },
    )
    with pytest.raises(ValidationError):
        ChallengeSpec.from_yaml(yml)


def test_rejects_empty_tags(tmp_path):
    """META004: tags must be a non-empty list."""
    yml = _write_metadata(
        tmp_path,
        "CTFARENA-02",
        {
            "name": "X",
            "description": "x",
            "difficulty": "easy",
            "tags": [],
        },
    )
    with pytest.raises(ValidationError):
        ChallengeSpec.from_yaml(yml)


def test_rejects_bad_difficulty(tmp_path):
    """META003: difficulty must be easy|medium|hard."""
    yml = _write_metadata(
        tmp_path,
        "CTFARENA-03",
        {
            "name": "X",
            "description": "x",
            "difficulty": "expert",  # bad
            "tags": ["t"],
        },
    )
    with pytest.raises(ValidationError):
        ChallengeSpec.from_yaml(yml)


def test_category_and_provider_are_platform_constants():
    assert ChallengeSpec.CATEGORY == "web"
    assert ChallengeSpec.PROVIDER == "docker"


def test_effective_id_falls_back_to_id():
    spec = ChallengeSpec(
        id="X",
        name="X",
        description="x",
        difficulty=Difficulty.EASY,
        tags=["t"],
    )
    assert spec.effective_id == "X"
    forked = spec.model_copy(update={"instance_id": "inst-42"})
    assert forked.effective_id == "inst-42"


class TestFlagsField:
    """Multi-flag extension: optional ``flags: list[str]`` in metadata.yaml."""

    def test_omitted_defaults_to_main(self, tmp_path):
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-F1",
            {
                "name": "X",
                "description": "x",
                "difficulty": "easy",
                "tags": ["t"],
            },
        )
        spec = ChallengeSpec.from_yaml(yml)
        assert spec.flags == ["main"]

    def test_multi_flag_ids(self, tmp_path):
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-F2",
            {
                "name": "X",
                "description": "x",
                "difficulty": "medium",
                "tags": ["t"],
                "flags": ["foothold", "root"],
            },
        )
        spec = ChallengeSpec.from_yaml(yml)
        assert spec.flags == ["foothold", "root"]

    def test_rejects_non_snake_case_id(self, tmp_path):
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-F3",
            {
                "name": "X",
                "description": "x",
                "difficulty": "easy",
                "tags": ["t"],
                "flags": ["Foot-hold"],
            },
        )
        with pytest.raises(ValidationError):
            ChallengeSpec.from_yaml(yml)

    def test_rejects_duplicate_ids(self, tmp_path):
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-F4",
            {
                "name": "X",
                "description": "x",
                "difficulty": "easy",
                "tags": ["t"],
                "flags": ["foothold", "foothold"],
            },
        )
        with pytest.raises(ValidationError):
            ChallengeSpec.from_yaml(yml)

    def test_rejects_empty_list(self, tmp_path):
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-F5",
            {
                "name": "X",
                "description": "x",
                "difficulty": "easy",
                "tags": ["t"],
                "flags": [],
            },
        )
        with pytest.raises(ValidationError):
            ChallengeSpec.from_yaml(yml)

    def test_rejects_id_starting_with_digit(self, tmp_path):
        yml = _write_metadata(
            tmp_path,
            "CTFARENA-F6",
            {
                "name": "X",
                "description": "x",
                "difficulty": "easy",
                "tags": ["t"],
                "flags": ["1st"],
            },
        )
        with pytest.raises(ValidationError):
            ChallengeSpec.from_yaml(yml)
