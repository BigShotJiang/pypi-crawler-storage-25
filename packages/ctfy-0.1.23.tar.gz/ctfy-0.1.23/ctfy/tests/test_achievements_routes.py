"""HTTP-level tests for the achievement routes.

End-to-end tests that exercise the full dispatch path: a real flag
submission triggers the event, the event runs through emit_event, the
engine unlocks the badge, and the GET routes return it.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from ctfy.core.state import InMemoryBackend
from ctfy.tests.conftest import (
    fake_node_context,
    make_mock_challenge_manager,
    start_instance_and_wait,
)

ADMIN_KEY = "test-admin-key"


# -- End-to-end fixtures -----------------------------------------------------


@pytest.fixture
def app_client():
    """Build an app with admin auth configured — needed for the grant tests."""
    from pydantic import SecretStr

    from ctfy.core.config import CtfyConfig
    from ctfy.server.app import create_app

    backend = InMemoryBackend()
    mgr = make_mock_challenge_manager(
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        auto_generate_specs=True,
    )
    cfg = CtfyConfig(admin_token=SecretStr(ADMIN_KEY))
    with patch("ctfy.server.app.ChallengeManager", return_value=mgr):
        app = create_app(config=cfg, external_host="10.0.0.1", backend=backend)
    with fake_node_context(
        backend,
        flag="FLAG{deadbeef0123456789abcdef01234567}",
        host="10.0.0.1",
    ):
        yield TestClient(app), backend


def _make_team(client, *, name="T") -> tuple[str, dict]:
    r = client.post("/api/v1/teams", json={"name": name, "agent": "test"})
    assert r.status_code == 200
    data = r.json()
    return data["team_id"], {"Authorization": f"Bearer {data['token']}"}


# -- Catalog -----------------------------------------------------------------


class TestCatalog:
    def test_catalog_hides_secrets_for_anonymous(self, app_client):
        client, _ = app_client
        r = client.get("/api/v1/achievements/catalog")
        assert r.status_code == 200
        ids = {a["id"] for a in r.json()}
        assert "welcome_aboard" in ids
        assert "secret_handshake" not in ids  # hidden until earned

    def test_catalog_hides_secrets_for_team_without_unlock(self, app_client):
        client, _ = app_client
        _, auth = _make_team(client)
        r = client.get("/api/v1/achievements/catalog", headers=auth)
        ids = {a["id"] for a in r.json()}
        assert "secret_handshake" not in ids

    def test_catalog_reveals_earned_secret(self, app_client):
        client, backend = app_client
        tid, auth = _make_team(client)
        backend.grant_achievement(tid, "secret_handshake", {})
        r = client.get("/api/v1/achievements/catalog", headers=auth)
        ids = {a["id"] for a in r.json()}
        assert "secret_handshake" in ids


# -- Self view: /me/achievements --------------------------------------------


class TestMyAchievements:
    def test_welcome_aboard_after_registration(self, app_client):
        client, _ = app_client
        _, auth = _make_team(client)
        r = client.get("/api/v1/me/achievements", headers=auth)
        assert r.status_code == 200
        unlocked = {a["achievement_id"] for a in r.json()["unlocked"]}
        assert "welcome_aboard" in unlocked

    def test_requires_auth(self, app_client):
        client, _ = app_client
        r = client.get("/api/v1/me/achievements")
        assert r.status_code in (401, 403)

    def test_locked_list_excludes_secret(self, app_client):
        client, _ = app_client
        _, auth = _make_team(client)
        r = client.get("/api/v1/me/achievements", headers=auth)
        locked_ids = {a["id"] for a in r.json()["locked"]}
        assert "secret_handshake" not in locked_ids
        assert "night_owl" in locked_ids  # regular locked badges still show


# -- Public team view --------------------------------------------------------


class TestTeamAchievements:
    def test_shows_other_teams_public_badges(self, app_client):
        client, _ = app_client
        tid, _ = _make_team(client, name="Target")
        r = client.get(f"/api/v1/teams/{tid}/achievements")
        assert r.status_code == 200
        ids = {a["achievement_id"] for a in r.json()}
        assert "welcome_aboard" in ids

    def test_hides_secret_badges_from_other_viewers(self, app_client):
        client, backend = app_client
        tid, _ = _make_team(client)
        backend.grant_achievement(tid, "secret_handshake", {})
        r = client.get(f"/api/v1/teams/{tid}/achievements")
        ids = {a["achievement_id"] for a in r.json()}
        assert "secret_handshake" not in ids

    def test_unknown_team_returns_404(self, app_client):
        client, _ = app_client
        r = client.get("/api/v1/teams/does-not-exist/achievements")
        assert r.status_code == 404


# -- Admin grant + revoke ----------------------------------------------------


class TestAdminGrantRevoke:
    def test_grant_and_revoke(self, app_client):
        client, _ = app_client
        tid, auth = _make_team(client)
        admin = {"Authorization": f"Bearer {ADMIN_KEY}"}

        r = client.post(f"/api/v1/admin/teams/{tid}/achievements/bug_hunter", headers=admin)
        assert r.status_code == 200
        data = r.json()
        assert data["achievement_id"] == "bug_hunter"

        r = client.get("/api/v1/me/achievements", headers=auth)
        ids = {a["achievement_id"] for a in r.json()["unlocked"]}
        assert "bug_hunter" in ids

        r = client.delete(f"/api/v1/admin/teams/{tid}/achievements/bug_hunter", headers=admin)
        assert r.status_code == 204

        r = client.get("/api/v1/me/achievements", headers=auth)
        ids = {a["achievement_id"] for a in r.json()["unlocked"]}
        assert "bug_hunter" not in ids

    def test_grant_is_idempotent(self, app_client):
        client, _ = app_client
        tid, _ = _make_team(client)
        admin = {"Authorization": f"Bearer {ADMIN_KEY}"}
        for _ in range(3):
            r = client.post(f"/api/v1/admin/teams/{tid}/achievements/bug_hunter", headers=admin)
            assert r.status_code == 200

        r = client.get(f"/api/v1/teams/{tid}/achievements")
        bug_hunts = [a for a in r.json() if a["achievement_id"] == "bug_hunter"]
        assert len(bug_hunts) == 1

    def test_grant_requires_admin(self, app_client):
        client, _ = app_client
        tid, auth = _make_team(client)
        r = client.post(f"/api/v1/admin/teams/{tid}/achievements/bug_hunter", headers=auth)
        assert r.status_code in (401, 403)

    def test_unknown_achievement_404(self, app_client):
        client, _ = app_client
        tid, _ = _make_team(client)
        admin = {"Authorization": f"Bearer {ADMIN_KEY}"}
        r = client.post(f"/api/v1/admin/teams/{tid}/achievements/no_such_id", headers=admin)
        assert r.status_code == 404


# -- End-to-end: solve triggers achievement -----------------------------------


class TestEndToEndSolve:
    def test_solve_unlocks_first_blood_and_fastest_man(self, app_client):
        client, _ = app_client
        tid, auth = _make_team(client)
        start_instance_and_wait(client, "E1", headers=auth)
        r = client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "E1",
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers=auth,
        )
        assert r.status_code == 200
        assert r.json()["correct"] is True

        r = client.get("/api/v1/me/achievements", headers=auth)
        unlocked = {a["achievement_id"] for a in r.json()["unlocked"]}
        assert "first_blood_team" in unlocked
        assert "fastest_man" in unlocked

    def test_secret_handshake_flag_unlocks_it(self, app_client):
        client, _ = app_client
        tid, auth = _make_team(client)
        start_instance_and_wait(client, "E1", headers=auth)
        r = client.post(
            "/api/v1/submissions",
            json={"challenge_id": "E1", "flag": "flag{hello_world}"},
            headers=auth,
        )
        assert r.status_code == 200
        assert r.json()["correct"] is False

        r = client.get("/api/v1/me/achievements", headers=auth)
        unlocked = {a["achievement_id"] for a in r.json()["unlocked"]}
        assert "secret_handshake" in unlocked

    def test_achievement_event_lands_in_activity_log(self, app_client):
        """Unlocks create ACHIEVEMENT_UNLOCKED activity rows (visible to the team)."""
        client, _ = app_client
        tid, auth = _make_team(client)
        start_instance_and_wait(client, "E1", headers=auth)
        client.post(
            "/api/v1/submissions",
            json={
                "challenge_id": "E1",
                "flag": "FLAG{deadbeef0123456789abcdef01234567}",
            },
            headers=auth,
        )
        r = client.get("/api/v1/activities?event=achievement_unlocked", headers=auth)
        assert r.status_code == 200
        items = r.json()["items"]
        assert items, "expected at least one achievement_unlocked event"
        # The payload carries the badge id in detail.
        badges = {item["detail"].get("achievement_id") for item in items}
        assert "first_blood_team" in badges
