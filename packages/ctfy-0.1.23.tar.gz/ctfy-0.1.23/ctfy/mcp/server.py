"""MCP Server for the ctfy platform.

Exposes CTF challenge operations as MCP tools so Claude Code (or any MCP client)
can participate in CTF challenges directly.

Only exposes agent-relevant operations: challenges, instances, flags, scoreboard.
Administrative tools (nodes, activities) are intentionally excluded.

Usage::

    export CTFY_PLATFORM_URL=http://localhost:8100
    export CTFY_TEAM_TOKEN=pt_xxx      # or pass --team-key to ``ctfy mcp``
    python -m ctfy.mcp.server
"""

from __future__ import annotations

from fastmcp import FastMCP

from ctfy.core.constants import DEFAULT_INSTANCE_TTL
from ctfy.core.target import AttackSurface
from ctfy.sdk import PlatformClient
from ctfy.server.models import (
    ChallengeInfo,
    ChallengeStats,
    HealthResponse,
    InstanceInfo,
    ScoreboardEntry,
    SubmissionResponse,
    TeamInfo,
    TeamResponse,
)

mcp = FastMCP(
    name="ctfy",
    instructions=(
        "ctfy platform. Use these tools to participate in "
        "CTF challenges: list challenges, start target instances, "
        "submit captured flags, and check the scoreboard."
    ),
)

# Active tenant — populated by :func:`main` before ``mcp.run()`` and read by
# every tool. Module-scoped because ``fastmcp`` runs tool functions without a
# way to thread context through.
_platform_url: str = "http://localhost:8100"
_team_key: str = ""


def _client() -> PlatformClient:
    """Build a PlatformClient using the values supplied to :func:`main`."""
    return PlatformClient(_platform_url, token=_team_key)


# ---------------------------------------------------------------------------
# Challenge discovery
# ---------------------------------------------------------------------------


@mcp.tool()
def search_challenges(
    q: str,
    difficulty: str | None = None,
    limit: int = 20,
) -> list[ChallengeInfo]:
    """Search for challenges by keyword. Use this FIRST before listing all.

    Examples: search_challenges("idor"), search_challenges("injection"),
    search_challenges("sso"), search_challenges("CTFARENA").

    Args:
        q: Search keyword (matches id, name, description). Required.
        difficulty: Filter by difficulty ("easy" | "medium" | "hard"). None = all.
        limit: Max results to return.
    """
    return _client().list_challenges(q=q, difficulty=difficulty, limit=limit)


@mcp.tool()
def list_challenges(
    difficulty: str | None = None,
    tag: str = "",
    offset: int = 0,
    limit: int = 50,
) -> list[ChallengeInfo]:
    """List all available CTF challenges. Prefer search_challenges() when
    looking for a specific challenge to avoid large result sets.

    Args:
        difficulty: Filter by difficulty ("easy" | "medium" | "hard"). None = all.
        tag: Filter by tag. Empty = all.
        offset: Pagination offset.
        limit: Max results to return.
    """
    return _client().list_challenges(difficulty=difficulty, tag=tag, offset=offset, limit=limit)


@mcp.tool()
def get_challenge(challenge_id: str) -> ChallengeInfo:
    """Get details of a specific challenge.

    The response's ``flag_ids`` lists every flag declared on the
    challenge (``["main"]`` for single-flag ones; multi-flag challenges
    list each id, e.g. ``["foothold", "root"]``). Each id corresponds to
    a ``$FLAG_<UPPER_ID>`` environment variable inside the instance.

    Args:
        challenge_id: The challenge ID (e.g. "WEB-001").
    """
    return _client().get_challenge(challenge_id)


# ---------------------------------------------------------------------------
# Instance lifecycle
# ---------------------------------------------------------------------------


@mcp.tool()
def start_instance(challenge_id: str, ttl: int = DEFAULT_INSTANCE_TTL) -> AttackSurface:
    """Start a target instance for a challenge. Waits until ready.

    Returns connection info (host, port, credentials) to attack the target.

    Args:
        challenge_id: The challenge to start.
        ttl: Time-to-live in seconds (default 3600).
    """
    return _client().start_instance(challenge_id, ttl=ttl).surface


@mcp.tool()
def stop_instance(challenge_id: str) -> str:
    """Stop a running target instance.

    Args:
        challenge_id: The instance to stop.
    """
    _client().stop_instance(challenge_id)
    return f"Instance for {challenge_id} stopped."


@mcp.tool()
def renew_instance(challenge_id: str, ttl: int = DEFAULT_INSTANCE_TTL) -> str:
    """Extend the TTL of a running instance.

    Args:
        challenge_id: The challenge whose instance to renew.
        ttl: New TTL in seconds.
    """
    _client().renew_instance(challenge_id, ttl=ttl)
    return f"Instance for {challenge_id} renewed for {ttl}s."


@mcp.tool()
def list_instances(
    challenge_id: str = "", status: str = "", q: str = "", offset: int = 0, limit: int = 50
) -> list[InstanceInfo]:
    """List all running target instances.

    Args:
        challenge_id: Filter by challenge ID. Empty = all.
        status: Filter by status (starting, ready, error). Empty = all.
        q: Search keyword (matches challenge_id, name). Empty = all.
        offset: Pagination offset.
        limit: Max results to return.
    """
    return _client().list_instances(
        challenge_id=challenge_id, status=status, q=q, offset=offset, limit=limit
    )


# ---------------------------------------------------------------------------
# Flag operations
# ---------------------------------------------------------------------------


@mcp.tool()
def verify_flag(challenge_id: str, flag: str) -> bool:
    """Verify a flag without recording a submission. Useful for debugging.

    Args:
        challenge_id: The challenge this flag belongs to.
        flag: The flag string to verify.

    Returns:
        True if the flag is correct, False otherwise.
    """
    return _client().verify_flag(challenge_id, flag).correct


@mcp.tool()
def submit_flag(challenge_id: str, flag: str) -> SubmissionResponse:
    """Submit a captured flag for verification and recording.

    The flag format is typically FLAG{hex_string}.

    A challenge may declare multiple flags (see ``get_challenge`` —
    ``flag_ids`` lists them; container env vars are ``$FLAG_<UPPER_ID>``).
    Each submission matches at most one flag: the response's
    ``flag_id`` identifies which one (``None`` when wrong). The instance
    auto-stops only after every declared flag is captured
    (``challenge_fully_solved=True``).

    Args:
        challenge_id: The challenge this flag belongs to.
        flag: The flag string (e.g. "FLAG{abc123...}").
    """
    return _client().submit_flag(challenge_id, flag)


# ---------------------------------------------------------------------------
# Scoreboard & stats
# ---------------------------------------------------------------------------


@mcp.tool()
def get_scoreboard(category: str = "", offset: int = 0, limit: int = 50) -> list[ScoreboardEntry]:
    """Get the current scoreboard (team rankings).

    Args:
        category: Filter by challenge category. Empty = all.
        offset: Pagination offset.
        limit: Max results to return.
    """
    return _client().scoreboard(category=category, offset=offset, limit=limit)


@mcp.tool()
def get_challenge_stats(offset: int = 0, limit: int = 50) -> list[ChallengeStats]:
    """Get per-challenge statistics (solves, attempts, success rate).

    Args:
        offset: Pagination offset.
        limit: Max results to return.
    """
    return _client().challenge_stats(offset=offset, limit=limit)


# ---------------------------------------------------------------------------
# Team & health
# ---------------------------------------------------------------------------


@mcp.tool()
def get_me() -> TeamInfo:
    """Get current team info (team_id, name, agent, solves, attempts, etc.).

    Requires a valid CTFY_TEAM_TOKEN to be configured (or --team-key on the CLI).
    """
    return _client().get_me()


@mcp.tool()
def register_team(name: str, agent: str = "", description: str = "") -> TeamResponse:
    """Register a new team on the platform.

    Args:
        name: Team display name.
        agent: Agent framework name (e.g. "claude-code").
        description: Optional description.

    Returns:
        Team info including team_id, api_key, name, etc.
    """
    return _client().register_team(name, agent, description)


@mcp.tool()
def health() -> HealthResponse:
    """Check platform server health and capacity."""
    return _client().health()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main(platform_url: str = "", team_key: str = ""):
    global _platform_url, _team_key
    _platform_url = platform_url or "http://localhost:8100"
    _team_key = team_key
    mcp.run()


if __name__ == "__main__":
    main()
