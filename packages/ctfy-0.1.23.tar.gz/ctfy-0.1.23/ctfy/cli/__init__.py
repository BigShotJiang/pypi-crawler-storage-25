"""ctfy — unified CLI entrypoint.

Command groups:
  ctfy server …       platform server lifecycle + invitations
  ctfy node …         worker-node cluster membership
  ctfy instance …     running challenge instances
  ctfy challenge …    static challenge assets (sync, ls, show, validate)
  ctfy mcp            start the MCP server
  ctfy config …       inspect active configuration
"""

from __future__ import annotations

from importlib import metadata

import typer
from dotenv import load_dotenv

from ctfy.cli.challenge import challenge_app
from ctfy.cli.config import config_app
from ctfy.cli.instance import instance_app
from ctfy.cli.node import node_app
from ctfy.cli.server import server_app

app = typer.Typer(help="ctfy — open-source CTF platform", no_args_is_help=True)
app.add_typer(server_app, name="server")
app.add_typer(node_app, name="node")
app.add_typer(instance_app, name="instance")
app.add_typer(challenge_app, name="challenge")
app.add_typer(config_app, name="config")


def _version_callback(value: bool) -> None:
    if not value:
        return
    try:
        version = metadata.version("ctfy")
    except metadata.PackageNotFoundError:
        version = "0.0.0+unknown"
    typer.echo(f"ctfy {version}")
    raise typer.Exit()


@app.callback()
def root(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        "-V",
        callback=_version_callback,
        is_eager=True,
        help="Show the ctfy version and exit.",
    ),
    platform_url: str = typer.Option(
        "http://localhost:8100",
        "--platform-url",
        envvar="CTFY_PLATFORM_URL",
        help="Platform URL used by client subcommands (instance/challenge/mcp).",
    ),
    team_token: str = typer.Option(
        "",
        "--team-token",
        envvar="CTFY_TEAM_TOKEN",
        help="Team bearer token for subcommands that authenticate as a team.",
    ),
    admin_token: str = typer.Option(
        "",
        "--admin-token",
        envvar="CTFY_ADMIN_TOKEN",
        help="Admin bearer token for admin-only subcommands.",
    ),
):
    """Populate ctx.obj with shared client settings for every subcommand."""
    ctx.ensure_object(dict)
    ctx.obj["platform_url"] = platform_url.rstrip("/")
    ctx.obj["team_token"] = team_token
    ctx.obj["admin_token"] = admin_token


@app.command()
def mcp(
    ctx: typer.Context,
):
    """Start the MCP server."""
    from ctfy.mcp.server import main as mcp_main

    mcp_main(platform_url=ctx.obj["platform_url"], team_key=ctx.obj["team_token"])


def main() -> None:
    # Load .env before typer parses args so envvar= options pick up .env values.
    load_dotenv(override=False)
    app()


if __name__ == "__main__":
    main()
