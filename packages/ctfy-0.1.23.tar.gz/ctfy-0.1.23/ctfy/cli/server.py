"""`ctfy server …` — platform server lifecycle + invitations."""

from __future__ import annotations

import os
import secrets
from pathlib import Path

import httpx
import typer
import uvicorn

from ctfy.cli.runtime import admin_headers, console, err_console
from ctfy.cli.runtime import platform_url as resolve_platform_url
from ctfy.core.config import CtfyConfig
from ctfy.core.log import setup_logging

server_app = typer.Typer(help="Platform server lifecycle + invitations", no_args_is_help=True)


# ---------------------------------------------------------------------------
# Snippet renderers — kept for `ctfy server invite`.
#
# The ``registration_token`` argument is the plaintext minted by POST
# /nodes/invites (or an admin token). It's injected as the node's
# ``CTFY_NODE_TOKEN`` env var and lives only until the first successful
# register; after that the platform hands back long-lived per-node
# credentials.
# ---------------------------------------------------------------------------


def _node_env(
    *,
    platform_url: str,
    registration_token: str,
    public_url: str,
    capacity: int,
    labels_csv: str,
    display_name: str = "",
) -> dict[str, str]:
    return {
        "CTFY_PLATFORM_URL": platform_url,
        "CTFY_NODE_PUBLIC_URL": public_url,
        "CTFY_NODE_TOKEN": registration_token,
        # display_name defaults to the public URL if the operator didn't
        # pick one — `ctfy admin node rename <id>` later, any time.
        "CTFY_NODE_DISPLAY_NAME": display_name or public_url,
        "CTFY_NODE_CAPACITY": str(capacity),
        "CTFY_NODE_LABELS": labels_csv,
    }


def _render_uv_run(
    *,
    platform_url: str,
    registration_token: str,
    capacity: int = 10,
    labels_csv: str = "",
) -> str:
    """Bare-metal ``uv run ctfy node join`` snippet — the default join path."""
    env = _node_env(
        platform_url=platform_url,
        registration_token=registration_token,
        public_url="\"http://$(hostname -I | awk '{print $1}'):8101\"",
        capacity=capacity,
        labels_csv=labels_csv,
    )
    env_lines = "".join(f"  {k}={v} \\\n" for k, v in env.items())
    return (
        "# Requires: uv, git, docker CLI, python>=3.11\n"
        "git clone https://github.com/wangyihang/ctfy.git \\\n"
        "  && cd ctfy \\\n"
        "  && uv sync\n"
        "\n"
        "env \\\n"
        f"{env_lines}"
        "  uv run ctfy node join --host 0.0.0.0 --port 8101\n"
    )


def _render_docker_run(
    *,
    platform_url: str,
    registration_token: str,
    capacity: int = 10,
    labels_csv: str = "",
    node_image: str = "ghcr.io/wangyihang/ctfy:latest",
) -> str:
    env = _node_env(
        platform_url=platform_url,
        registration_token=registration_token,
        public_url="\"http://$(hostname -I | awk '{print $1}'):8101\"",
        capacity=capacity,
        labels_csv=labels_csv,
    )
    env_lines = "".join(f"  -e {k}={v} \\\n" for k, v in env.items())
    return (
        f"docker run -d --name ctfy-node \\\n"
        f"{env_lines}"
        f"  -e CTFY_CHALLENGES_DIR=/app/challenges \\\n"
        f"  -v /var/run/docker.sock:/var/run/docker.sock \\\n"
        f"  -v ~/.ctf-arena/challenges:/app/challenges:ro \\\n"
        f"  -v ctfy-node-data:/app/data \\\n"
        f"  -p 8101:8101 \\\n"
        f"  {node_image} \\\n"
        f"  node join --host 0.0.0.0 --port 8101\n"
    )


def _render_compose_service(
    *,
    platform_url: str,
    registration_token: str,
    capacity: int = 10,
    labels_csv: str = "",
    node_image: str = "ghcr.io/wangyihang/ctfy:latest",
) -> str:
    env = _node_env(
        platform_url=platform_url,
        registration_token=registration_token,
        public_url="http://node2:8101",
        capacity=capacity,
        labels_csv=labels_csv,
    )
    env_lines = "".join(f"      - {k}={v}\n" for k, v in env.items())
    return (
        "# Append this service to your docker-compose.yml\n"
        "  node2:\n"
        f"    image: {node_image}\n"
        '    command: ["node", "join", "--host", "0.0.0.0", "--port", "8101"]\n'
        "    volumes:\n"
        "      - /var/run/docker.sock:/var/run/docker.sock\n"
        "      - ${HOME}/.ctf-arena/challenges:/app/challenges:ro\n"
        "      - ./data/node2:/app/data\n"
        "    environment:\n"
        f"{env_lines}"
        "      - CTFY_CHALLENGES_DIR=/app/challenges\n"
        '    ports:\n      - "8102:8101"\n'
    )


# ---------------------------------------------------------------------------
# First-run bootstrap
# ---------------------------------------------------------------------------


def _bootstrap_env_if_missing(env_path: Path, admin: str) -> dict[str, str] | None:
    """Auto-generate ``.env`` with the admin token + URLs on first run.

    File is written mode 0600. Values are also exported into ``os.environ``
    so the current process picks them up without re-reading. Node
    registration tokens are intentionally *not* in ``.env`` — they are
    short-lived and minted on demand via ``ctfy server invite``.
    """
    if env_path.exists() or admin:
        return None

    admin = secrets.token_hex(32)
    url = "http://127.0.0.1:8100"
    # CTFY_NODE_PUBLIC_URL deliberately not written: `ctfy node join`'s
    # --public-url flag defaults appropriately, and writing a bare-metal
    # value here would leak into docker-compose (which auto-loads .env)
    # and break platform→node routing inside the compose network.
    env_path.write_text(
        "# Auto-generated on first `ctfy server start`. Edit as needed.\n"
        f"CTFY_ADMIN_TOKEN={admin}\n"
        f"CTFY_PLATFORM_URL={url}\n"
    )
    env_path.chmod(0o600)

    os.environ["CTFY_ADMIN_TOKEN"] = admin
    os.environ["CTFY_PLATFORM_URL"] = url

    return {
        "admin_token": admin,
        "platform_url": url,
        "path": str(env_path),
    }


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


@server_app.command("start")
def server_start(
    host: str = typer.Option("0.0.0.0", "--host", envvar="CTFY_SERVER_HOST"),
    port: int = typer.Option(8100, "--port", envvar="CTFY_SERVER_PORT"),
    external_host: str = typer.Option(
        "", "--external-host", help="External hostname/IP (auto-detected if empty)"
    ),
    admin_token: str = typer.Option(
        "",
        "--admin-token",
        envvar=["CTFY_ADMIN_TOKEN", "CTFY_SERVER_API_KEY"],
        help="Admin bearer token. Generated on first run if empty.",
    ),
    platform_url: str = typer.Option(
        "",
        "--platform-url",
        envvar="CTFY_PLATFORM_URL",
        help="URL the platform advertises to nodes (e.g. http://platform:8100).",
    ),
):
    """Start the platform server in the foreground.

    On first run (no ``.env`` and no admin token set), auto-generates a
    fresh admin secret into ``./.env`` (mode 0600) and prints it.
    Subsequent runs respect the existing configuration.

    Lower-level knobs (paths, ports, image tags, db path) are read from
    ``CTFY_*`` env vars — see ``ctfy config show`` for the full surface.
    """
    setup_logging()
    project_root = CtfyConfig.model_fields["project_root"].default
    generated = _bootstrap_env_if_missing(project_root / ".env", admin_token)
    if generated:
        console.print(
            f"[green]✓ Generated [bold]{generated['path']}[/bold] with fresh secrets "
            "(mode 0600).[/green]"
        )
        console.print("  [dim]These apply to this process and are persisted for later runs.[/dim]")
        console.print(f"    CTFY_ADMIN_TOKEN  = [bold]{generated['admin_token']}[/bold]")
        console.print(f"    CTFY_PLATFORM_URL = {generated['platform_url']}")
        console.print()
        admin_token = generated["admin_token"]
        platform_url = generated["platform_url"]

    config = CtfyConfig.from_env(
        overrides={
            "server_host": host,
            "server_port": port,
            "admin_token": admin_token,
            "platform_url": platform_url,
        }
    )

    if not any(config.challenges_dir.glob("*/metadata.yaml")):
        console.print(
            f"[yellow]No challenges found at {config.challenges_dir}. "
            f"Run [bold]ctfy challenge sync[/bold] to clone "
            f"{config.challenges_repo}.[/yellow]"
        )

    from ctfy.server.app import create_app

    app_ = create_app(config, external_host=external_host or None)
    console.print(f"Starting platform on [bold]{host}:{port}[/bold]")

    try:
        from ctfy.core.state import create_backend

        backend = create_backend(config.db_path, project_root=config.project_root)
        if not backend.list_nodes():
            console.print(
                "[yellow]No worker nodes registered yet. POST /instances will 503 "
                "until one joins. On the platform host, mint an invite and share "
                "the printed command with the node operator:[/yellow]"
            )
            console.print()
            console.print("    uv run ctfy server invite")
            console.print()
    except Exception:
        # Non-fatal: the hint is best-effort.
        pass
    uvicorn.run(app_, host=host, port=port)


@server_app.command("status")
def server_status(
    ctx: typer.Context,
    json_output: bool = typer.Option(False, "--json", help="Emit JSON instead of a table"),
):
    """Probe the platform's /health endpoint."""
    url = resolve_platform_url(ctx)
    try:
        resp = httpx.get(f"{url}/api/v1/health", timeout=5)
        resp.raise_for_status()
    except httpx.HTTPError as e:
        err_console.print(f"[red]No platform at {url}: {e}[/red]")
        raise typer.Exit(2)
    data = resp.json()
    if json_output:
        console.print_json(data=data)
        return
    console.print(f"[bold]{url}[/bold]")
    for k, v in data.items():
        console.print(f"  {k}: {v}")


@server_app.command("stop")
def server_stop():
    """Stop a platform server managed by your process supervisor."""
    err_console.print(
        "[yellow]`ctfy server start` runs in the foreground; stop it with Ctrl-C "
        "or your process supervisor (systemd, docker compose, tmux).[/yellow]"
    )
    raise typer.Exit(2)


@server_app.command("invite")
def server_invite(
    ctx: typer.Context,
    role: str = typer.Option("node", "--role", help="Role for the credential: node"),
    capacity: int = typer.Option(10, "--capacity", help="Max concurrent instances on the new node"),
    label: list[str] = typer.Option([], "--label", help="Node label (k=v), repeatable"),
    ttl_seconds: int = typer.Option(
        3600,
        "--ttl",
        help="Invite token validity in seconds (default 1h; min 60, max 7d).",
    ),
    output: str = typer.Option(
        "uv", "--output", "-o", help="Output format: uv | docker | compose | json"
    ),
):
    """Mint a one-time registration token and print a copy-paste join command.

    Each call mints a fresh token via ``POST /api/v1/nodes/invites``.
    The token is consumed on the first successful ``POST /nodes/register``
    from the target machine and becomes invalid afterwards — so each
    invocation produces credentials for exactly one node.
    """
    setup_logging()
    if role != "node":
        err_console.print(f"[red]Unknown role: {role} (only 'node' is supported today)[/red]")
        raise typer.Exit(2)

    url = resolve_platform_url(ctx)
    headers = admin_headers(ctx)
    if not headers:
        err_console.print(
            "[red]No admin token configured.[/red]\n"
            "  Pass --admin-token or set CTFY_ADMIN_TOKEN and retry."
        )
        raise typer.Exit(2)

    # Mint the one-time registration token.
    try:
        resp = httpx.post(
            f"{url}/api/v1/nodes/invites",
            headers=headers,
            json={"ttl_seconds": ttl_seconds},
            timeout=10,
        )
        resp.raise_for_status()
        invite = resp.json()
    except httpx.HTTPError as e:
        err_console.print(f"[red]Failed to mint invite: {e}[/red]")
        raise typer.Exit(1)

    # Pull platform_url / node_image from cluster-info (no secrets here).
    try:
        ci = httpx.get(f"{url}/api/v1/cluster-info", headers=headers, timeout=10)
        ci.raise_for_status()
        info = ci.json()
    except httpx.HTTPError as e:
        err_console.print(f"[red]cluster-info failed: {e}[/red]")
        raise typer.Exit(1)

    registration_token = invite["registration_token"]
    node_image = info.get("node_image") or "ghcr.io/wangyihang/ctfy:latest"
    platform_url = info.get("platform_url") or url
    labels_csv = ",".join(label) if label else ""

    if output == "json":
        console.print_json(
            data={
                "platform_url": platform_url,
                "registration_token": registration_token,
                "invite_id": invite["invite_id"],
                "expires_at": invite["expires_at"],
                "node_image": node_image,
                "capacity": capacity,
                "labels": labels_csv,
            }
        )
        return

    kwargs = {
        "platform_url": platform_url,
        "registration_token": registration_token,
        "capacity": capacity,
        "labels_csv": labels_csv,
    }
    if output == "compose":
        console.print(_render_compose_service(node_image=node_image, **kwargs))
    elif output == "docker":
        console.print(_render_docker_run(node_image=node_image, **kwargs))
    else:
        console.print(_render_uv_run(**kwargs))

    # A short footer so operators know how long they have.
    console.print(
        f"\n[dim]Registration token expires at {invite['expires_at']}. "
        "It is single-use — run this command on the target host before expiry.[/dim]"
    )
