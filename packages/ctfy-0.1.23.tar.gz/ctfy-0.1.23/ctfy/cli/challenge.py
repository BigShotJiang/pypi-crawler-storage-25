"""`ctfy challenge …` — static challenge assets in challenges_dir."""

from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path

import typer
import yaml
from pydantic import ValidationError
from rich.table import Table

from ctfy.cli.runtime import console, err_console
from ctfy.core.challenge import ChallengeSpec
from ctfy.core.challenge_validate import validate_dir
from ctfy.core.config import CtfyConfig
from ctfy.core.enums import Difficulty
from ctfy.core.log import log, setup_logging

challenge_app = typer.Typer(help="Static challenge assets in challenges_dir", no_args_is_help=True)


def _default_challenges_dir() -> Path:
    return CtfyConfig.model_fields["challenges_dir"].default


CHALLENGES_DIR_OPTION = typer.Option(
    _default_challenges_dir(),
    "--challenges-dir",
    envvar="CTFY_CHALLENGES_DIR",
    help="Directory containing challenge metadata.yaml files.",
)


def _iter_specs(
    challenges_dir: Path,
    *,
    challenge_id: str | None = None,
    difficulty: Difficulty | None = None,
    tag: str | None = None,
) -> Iterable[ChallengeSpec]:
    if not challenges_dir.exists():
        return
    for d in sorted(challenges_dir.iterdir()):
        yml = d / "metadata.yaml"
        if not d.is_dir() or not yml.exists():
            continue
        try:
            spec = ChallengeSpec.from_yaml(yml)
        except (ValidationError, yaml.YAMLError) as e:
            log.warning("Skipping invalid challenge spec", path=str(yml), error=str(e))
            continue
        if challenge_id:
            patterns = [p.strip() for p in challenge_id.split(",")]
            if not any(spec.id == p or spec.id.startswith(p + "-") for p in patterns):
                continue
        if difficulty is not None and spec.difficulty != difficulty:
            continue
        if tag and tag not in spec.tags:
            continue
        yield spec


@challenge_app.command("sync")
def challenge_sync(
    repo: str = typer.Option(
        "",
        "--repo",
        envvar="CTFY_CHALLENGES_REPO",
        help="Git repo URL (default: from config).",
    ),
    challenges_dir: Path = CHALLENGES_DIR_OPTION,
):
    """Clone or fast-forward-pull the challenges repo locally.

    Run once after install, then whenever you want to pick up upstream
    changes. Server / node startup no longer pulls automatically.
    """
    setup_logging()
    config = CtfyConfig.from_env(
        overrides={
            "challenges_repo": repo,
            "challenges_dir": challenges_dir,
        }
    )
    from ctfy.core.challenges_sync import ensure_challenges

    ensure_challenges(config.challenges_dir, config.challenges_repo)
    console.print(f"[green]✓ Synced {config.challenges_repo} → {config.challenges_dir}[/green]")


@challenge_app.command("ls")
def challenge_ls(
    challenge: str | None = typer.Option(
        None, "--challenge", help="Filter by challenge ID (comma-separated, prefix-match)"
    ),
    difficulty: Difficulty | None = typer.Option(
        None, "--difficulty", help="Filter by difficulty (easy | medium | hard)"
    ),
    tag: str | None = typer.Option(None, "--tag", help="Filter by a single tag"),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON instead of a table"),
    challenges_dir: Path = CHALLENGES_DIR_OPTION,
):
    """List challenge definitions in challenges_dir."""
    setup_logging()
    specs = list(
        _iter_specs(challenges_dir, challenge_id=challenge, difficulty=difficulty, tag=tag)
    )

    if json_output:
        console.print_json(data=[s.model_dump(mode="json") for s in specs])
        return

    table = Table(title="Challenge Definitions")
    table.add_column("ID", style="cyan")
    table.add_column("Name")
    table.add_column("Difficulty", style="magenta")
    table.add_column("Tags", style="dim")
    for spec in specs:
        table.add_row(spec.id, spec.name, spec.difficulty.value, ", ".join(spec.tags))
    console.print(table)
    console.print(f"\n[bold]{len(specs)}[/bold] challenge(s)")


@challenge_app.command("show")
def challenge_show(
    challenge_id: str = typer.Argument(help="Challenge ID"),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON instead of a summary"),
    challenges_dir: Path = CHALLENGES_DIR_OPTION,
):
    """Show full metadata for a single challenge."""
    setup_logging()
    for spec in _iter_specs(challenges_dir, challenge_id=challenge_id):
        if spec.id == challenge_id:
            if json_output:
                console.print_json(data=spec.model_dump(mode="json"))
            else:
                console.print(spec.model_dump(mode="json"))
            return
    err_console.print(f"[red]Challenge not found: {challenge_id}[/red]")
    raise typer.Exit(1)


@challenge_app.command("validate")
def challenge_validate(
    challenge_id: str | None = typer.Argument(
        None, help="Challenge ID to validate (omit with --all to scan every challenge)"
    ),
    all_: bool = typer.Option(
        False, "--all", help="Validate every metadata.yaml in challenges_dir"
    ),
    strict: bool = typer.Option(
        False, "--strict", help="Passed through to the upstream audit (warnings become errors)."
    ),
    json_output: bool = typer.Option(False, "--json", help="Emit one JSON object per finding"),
    challenges_dir: Path = CHALLENGES_DIR_OPTION,
):
    """Validate metadata + compose + source-code hygiene via the upstream audit."""
    setup_logging()
    if not all_ and not challenge_id:
        err_console.print("[red]Pass a challenge ID or --all.[/red]")
        raise typer.Exit(2)

    findings = validate_dir(
        challenges_dir,
        challenge_id=None if all_ else challenge_id,
        strict=strict,
    )

    if not findings:
        err_console.print("[red]No challenges matched.[/red]")
        raise typer.Exit(2)

    failed = [f for f in findings if not f.ok]

    if json_output:
        import json

        for f in findings:
            console.print(
                json.dumps(
                    {"challenge": f.challenge, "status": f.status, "reason": f.reason},
                    ensure_ascii=False,
                )
            )
    else:
        for f in findings:
            if f.ok:
                console.print(f"[green]OK[/green]    {f.challenge}")
            else:
                console.print(f"[red]FAIL[/red]  {f.challenge}: {f.reason}")
        console.print(
            f"\n[bold]{len(findings) - len(failed)}[/bold] ok, [bold]{len(failed)}[/bold] failed"
        )

    if failed:
        raise typer.Exit(1)
