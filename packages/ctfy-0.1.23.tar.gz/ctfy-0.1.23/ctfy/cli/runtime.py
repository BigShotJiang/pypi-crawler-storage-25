"""Shared CLI runtime helpers: client settings pulled from ``ctx.obj``, Rich
consoles, and the fail-fast ``PlatformClient`` factory used by every
subcommand. All values originate in the top-level typer callback; this
module never reads the environment or the filesystem directly."""

from __future__ import annotations

import httpx
import typer
from rich.console import Console

from ctfy.sdk import PlatformClient

__all__ = [
    "console",
    "err_console",
    "platform_url",
    "team_token",
    "admin_token",
    "get_client",
    "admin_headers",
]

console = Console()
err_console = Console(stderr=True)


def platform_url(ctx: typer.Context) -> str:
    """Return the platform URL chosen at the top-level callback."""
    return ctx.obj["platform_url"]


def team_token(ctx: typer.Context) -> str:
    return ctx.obj["team_token"]


def admin_token(ctx: typer.Context) -> str:
    return ctx.obj["admin_token"]


def get_client(ctx: typer.Context, *, require_auth: bool = True) -> PlatformClient:
    """Return a PlatformClient cached on ``ctx.obj``.

    Fails fast with an actionable error when the platform is unreachable;
    never auto-starts anything. ``require_auth`` controls whether a team
    token is required (some commands like team registration run anon).
    """
    if ctx.obj is None:
        ctx.obj = {}
    if "client" in ctx.obj:
        return ctx.obj["client"]

    url = platform_url(ctx)
    token = team_token(ctx)
    if require_auth and not token:
        err_console.print(
            "[red]No team token configured.[/red]\n"
            "  Pass --team-token or set CTFY_TEAM_TOKEN (see ctfy --help).\n"
            f'  Example: curl -X POST {url}/api/v1/teams -d \'{{"name":"me"}}\''
        )
        raise typer.Exit(2)

    client = PlatformClient(url, token=token)
    # Probe so we fail fast instead of at the first API call.
    try:
        client.health()
    except (httpx.ConnectError, httpx.TimeoutException) as e:
        err_console.print(
            f"[red]No platform at {url}.[/red]\n"
            "  Start one in another terminal with [bold]ctfy server start[/bold],\n"
            "  or pass --platform-url / CTFY_PLATFORM_URL pointing at a running platform.\n"
            f"  ({e.__class__.__name__}: {e})"
        )
        raise typer.Exit(2)
    ctx.obj["client"] = client
    return client


def admin_headers(ctx: typer.Context) -> dict[str, str]:
    """Build an ``Authorization`` header dict for admin/server endpoints."""
    token = admin_token(ctx)
    return {"Authorization": f"Bearer {token}"} if token else {}
