"""`ctfy config …` — inspect active configuration.

Re-uses :meth:`CtfyConfig.from_env` so what you see here is exactly what
``ctfy server start`` / ``ctfy node join`` would resolve from the same
environment at this moment.
"""

from __future__ import annotations

import typer
from pydantic import SecretStr

from ctfy.cli.runtime import console
from ctfy.core.config import CtfyConfig

config_app = typer.Typer(help="Inspect active configuration", no_args_is_help=True)


def _redact(value) -> str:
    if isinstance(value, SecretStr):
        return "<set>" if value.get_secret_value() else "<unset>"
    return str(value)


@config_app.command("show")
def config_show(
    json_output: bool = typer.Option(False, "--json", help="Emit JSON instead of a table"),
):
    """Print the effective settings (secrets redacted)."""
    cfg = CtfyConfig.from_env()
    data = {k: _redact(getattr(cfg, k)) for k in cfg.model_fields}

    if json_output:
        console.print_json(data=data)
        return

    from rich.table import Table

    table = Table(title="ctfy configuration")
    table.add_column("Setting", style="cyan")
    table.add_column("Value")
    for k in sorted(data):
        table.add_row(k, data[k])
    console.print(table)
