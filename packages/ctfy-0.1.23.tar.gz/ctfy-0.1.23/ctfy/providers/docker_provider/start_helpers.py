"""Helpers shared by :mod:`ctfy.providers.docker_provider.provider`."""

from __future__ import annotations

import shutil
from pathlib import Path


def copy_challenge_dir(src: Path, dst: Path) -> None:
    """Duplicate a challenge source tree to a per-instance directory.

    Compose runs its build and mounts from *dst* so two instances of the
    same challenge never share host files. Symlinks are dereferenced during
    the copy to prevent volume escape via relative links that point outside
    the per-instance tree.
    """
    if not src.exists():
        raise FileNotFoundError(f"challenge dir not found: {src}")
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst, symlinks=False)
