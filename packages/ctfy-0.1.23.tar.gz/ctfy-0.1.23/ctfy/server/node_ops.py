"""Node-side RPC helpers used by route modules.

Wraps :class:`ctfy.sdk.node_client.NodeClient` with the per-node bearer
token stored on each ``NodeState`` at registration time, and exposes
high-level convenience calls (``stop_instance_on_node``,
``stop_all_instances_on_node``) so route handlers don't repeat the
context-manager boilerplate.
"""

from __future__ import annotations

from ctfy.core.state.models import NodeState
from ctfy.sdk.node_client import NodeClient
from ctfy.server.app_state import AppState

__all__ = [
    "get_node_client",
    "stop_instance_on_node",
    "stop_all_instances_on_node",
]


def get_node_client(app: AppState, node: NodeState) -> NodeClient:
    """Build a ``NodeClient`` authenticated with *node*'s bearer token."""
    # AppState carries config but the per-node token lives on NodeState —
    # look it up fresh so a re-registered node (which rotates the token)
    # is reached with the current value without a cache invalidation.
    fresh = app.state_backend.get_node(node.node_id) or node
    return NodeClient(fresh.url, fresh.token)


def stop_instance_on_node(app: AppState, node: NodeState, instance_id: str) -> None:
    """Synchronous helper for ``run_in_executor``: stop a single instance on *node*."""
    with get_node_client(app, node) as nc:
        nc.stop_instance(instance_id)


def stop_all_instances_on_node(app: AppState, node: NodeState) -> None:
    """Synchronous helper for ``run_in_executor``: stop all instances on *node*."""
    with get_node_client(app, node) as nc:
        nc.stop_all()
