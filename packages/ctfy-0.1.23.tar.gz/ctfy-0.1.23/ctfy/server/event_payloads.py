"""Typed payloads for every :class:`PlatformEvent`.

Replaces the old ``emit_event(..., **detail_kwargs)`` signature. Each
event has its own pydantic model declaring exactly the fields it
carries — a typo at a call site (``ips`` instead of ``ip``) is now a
static error, a wrong payload class for a given event is caught by
mypy, and new event types can't ship without someone writing a model.

The model classes also advertise their :class:`PlatformEvent` via the
``EVENT`` class attribute so :func:`ctfy.server.events.emit_event` can
derive the broadcast name from the payload itself — callers only pass
the payload, never a separate ``event=`` arg.

Storage: these payloads are serialized into the existing
:class:`ctfy.core.activity.ActivityDetail` shape for the activity log
and straight to JSON for the SSE frame. ActivityDetail's free-form
``Optional[...]`` fields remain the on-disk schema so already-recorded
activities stay readable.
"""

from __future__ import annotations

from typing import ClassVar

from pydantic import ConfigDict

from ctfy.core.enums import PlatformEvent
from ctfy.core.models import CtfyModel

__all__ = [
    "EventPayload",
    "TeamRegisteredPayload",
    "InstanceStartedPayload",
    "InstanceReadyPayload",
    "InstanceErrorPayload",
    "InstanceStoppedPayload",
    "InstanceRenewedPayload",
    "FlagCorrectPayload",
    "FlagWrongPayload",
    "NodeRegisteredPayload",
    "NodeUnhealthyPayload",
    "NodeRemovedPayload",
    "NodeUpdatedPayload",
    "AchievementUnlockedPayload",
]


class EventPayload(CtfyModel):
    """Envelope common to every event.

    ``team_id`` / ``team_name`` / ``challenge_id`` form the top-level
    columns on :class:`ActivityState`; per-event detail fields live on
    the concrete subclasses and are serialized into
    :class:`ActivityDetail`.

    ``extra="forbid"`` is the whole point — a typo at a call site
    (``ips`` instead of ``ip``, ``solve_time`` instead of
    ``solve_time_s``) raises :class:`pydantic.ValidationError` instead
    of being silently dropped on the floor.
    """

    model_config = ConfigDict(extra="forbid")

    #: Concrete subclass overrides with its own PlatformEvent member.
    EVENT: ClassVar[PlatformEvent]

    team_id: str = ""
    team_name: str = ""
    challenge_id: str = ""


# ---------------------------------------------------------------------------
# Team events
# ---------------------------------------------------------------------------


class TeamRegisteredPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.TEAM_REGISTERED

    agent: str = ""
    ip: str = ""


# ---------------------------------------------------------------------------
# Instance events
# ---------------------------------------------------------------------------


class InstanceStartedPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.INSTANCE_STARTED

    instance_id: str
    node_id: str
    ip: str = ""


class InstanceReadyPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.INSTANCE_READY

    instance_id: str
    node_id: str


class InstanceErrorPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.INSTANCE_ERROR

    instance_id: str
    node_id: str = ""
    error: str = ""


class InstanceStoppedPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.INSTANCE_STOPPED

    instance_id: str
    node_id: str = ""
    reason: str = ""
    ip: str = ""


class InstanceRenewedPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.INSTANCE_RENEWED

    instance_id: str
    ttl: int


# ---------------------------------------------------------------------------
# Flag submission events
# ---------------------------------------------------------------------------


class FlagCorrectPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.FLAG_CORRECT

    instance_id: str = ""
    solve_time_s: float = 0.0
    ip: str = ""
    # Which flag on the challenge was captured. On single-flag challenges
    # this is ``"main"``; on multi-flag challenges it identifies the hit
    # (e.g. ``"foothold"`` / ``"root"``). Achievement rules can key off
    # this to tell per-flag vs per-challenge events apart.
    flag_id: str = ""
    # True when this correct claim also made the team fully solve the
    # challenge (every declared flag captured). Equivalent to ``correct``
    # on single-flag challenges; distinguishes partial vs full solves on
    # multi-flag ones.
    challenge_fully_solved: bool = False


class FlagWrongPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.FLAG_WRONG

    instance_id: str = ""
    solve_time_s: float = 0.0
    ip: str = ""


# ---------------------------------------------------------------------------
# Node events — global scope, no team_id / challenge_id
# ---------------------------------------------------------------------------


class NodeRegisteredPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.NODE_REGISTERED

    node_id: str
    url: str


class NodeUnhealthyPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.NODE_UNHEALTHY

    node_id: str
    url: str = ""


class NodeRemovedPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.NODE_REMOVED

    node_id: str


class NodeUpdatedPayload(EventPayload):
    """Admin edited a node's display_name and/or labels.

    ``labels_changed`` is the list of label keys that differ from the
    previous state (added / removed / re-valued). Keeps the event
    compact while still being searchable — the new values live on the
    node row itself, fetched separately if needed.
    """

    EVENT: ClassVar[PlatformEvent] = PlatformEvent.NODE_UPDATED

    node_id: str
    display_name: str = ""
    labels_changed: list[str] = []


# ---------------------------------------------------------------------------
# Achievement events
# ---------------------------------------------------------------------------


class AchievementUnlockedPayload(EventPayload):
    EVENT: ClassVar[PlatformEvent] = PlatformEvent.ACHIEVEMENT_UNLOCKED

    achievement_id: str
    achievement_name: str = ""
    tier: str = "bronze"
    secret: bool = False
