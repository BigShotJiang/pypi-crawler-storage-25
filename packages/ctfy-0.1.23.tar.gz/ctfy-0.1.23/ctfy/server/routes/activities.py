"""Activity log endpoint."""

from __future__ import annotations

from fastapi import APIRouter, Depends

from ctfy.core.state.models import TeamState
from ctfy.server.app_state import AppState
from ctfy.server.models import Activity, BigLimitOffsetPage


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/activities", response_model=BigLimitOffsetPage[Activity])
    def list_activities(
        team: TeamState = Depends(app.get_current_team),
        challenge_id: str = "",
        event: str = "",
        actor_id: str = "",
        offset: int = 0,
        limit: int = 100,
    ):
        """Get the authenticated team's activity log (most recent first).

        Scope is always the caller's own team — anonymous requests are
        rejected at the auth layer, and the caller cannot query another
        team's events. Node-lifecycle events (empty team_id) are
        operational signals and are not surfaced on this endpoint.
        """
        total = app.state_backend.count_activities(
            team_id=team.team_id,
            challenge_id=challenge_id,
            event=event,
            actor_id=actor_id,
        )
        rows = app.state_backend.list_activities(
            team_id=team.team_id,
            challenge_id=challenge_id,
            event=event,
            actor_id=actor_id,
            offset=offset,
            limit=limit,
        )
        items = [Activity(**a.model_dump()) for a in rows]
        return {"items": items, "total": total, "offset": offset, "limit": limit}

    return router
