"""Achievement catalog + per-team unlock endpoints.

Public routes:
- ``GET  /achievements/catalog`` — every badge the platform can grant.
  Secret badges are filtered out unless the requesting team has
  unlocked them, preserving the easter-egg surprise.
- ``GET  /teams/{team_id}/achievements`` — a team's public unlocks
  (secret badges hidden for other viewers).
- ``GET  /me/achievements`` — current team's unlocks; returns secret
  badges they have unlocked, too.

Admin routes (used by the Bug Hunter workflow + one-off awards):
- ``POST   /admin/teams/{team_id}/achievements/{achievement_id}``
- ``DELETE /admin/teams/{team_id}/achievements/{achievement_id}``
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException

from ctfy.core.exceptions import TeamNotFoundError
from ctfy.core.models import CtfyModel
from ctfy.core.state.models import TeamState
from ctfy.server.achievements.catalog import CATALOG
from ctfy.server.achievements.catalog import get as get_catalog_entry
from ctfy.server.app_state import AppState
from ctfy.server.event_payloads import AchievementUnlockedPayload
from ctfy.server.events import emit_event


class AchievementCatalogEntry(CtfyModel):
    """One badge as advertised to the frontend."""

    id: str
    name: str
    description: str
    icon: str
    tier: str
    secret: bool = False


class TeamAchievement(CtfyModel):
    """A badge that a team has unlocked."""

    achievement_id: str
    name: str
    description: str
    icon: str
    tier: str
    secret: bool = False
    unlocked_at: str
    context: dict[str, Any] = {}


class MyAchievementsResponse(CtfyModel):
    """The self-view: unlocked + locked (with secret-hiding)."""

    unlocked: list[TeamAchievement] = []
    locked: list[AchievementCatalogEntry] = []


def _catalog_entry(ach_id: str) -> AchievementCatalogEntry | None:
    ach = get_catalog_entry(ach_id)
    if ach is None:
        return None
    return AchievementCatalogEntry(
        id=ach.id,
        name=ach.name,
        description=ach.description,
        icon=ach.icon,
        tier=ach.tier,
        secret=ach.secret,
    )


def _render_unlocks(app: AppState, team_id: str, *, include_secret: bool) -> list[TeamAchievement]:
    """Join stored unlocks with catalog metadata for display."""
    out: list[TeamAchievement] = []
    for row in app.state_backend.list_achievements(team_id):
        ach = get_catalog_entry(row.achievement_id)
        if ach is None:
            # Stored an id that's no longer in the catalog — skip rather
            # than make the page crash. Admin can revoke it manually.
            continue
        if ach.secret and not include_secret:
            continue
        out.append(
            TeamAchievement(
                achievement_id=row.achievement_id,
                name=ach.name,
                description=ach.description,
                icon=ach.icon,
                tier=ach.tier,
                secret=ach.secret,
                unlocked_at=row.unlocked_at,
                context=row.context,
            )
        )
    # Sort newest-first — matches how the UI wants to show "recent wins".
    out.sort(key=lambda a: a.unlocked_at, reverse=True)
    return out


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/achievements/catalog", response_model=list[AchievementCatalogEntry])
    def get_catalog(
        team: TeamState | None = Depends(app.get_current_team_or_none),
    ):
        """List every catalog entry, hiding secrets the caller hasn't earned."""
        unlocked_ids: set[str] = set()
        if team is not None:
            unlocked_ids = {
                r.achievement_id for r in app.state_backend.list_achievements(team.team_id)
            }
        items: list[AchievementCatalogEntry] = []
        for ach in CATALOG:
            if ach.secret and ach.id not in unlocked_ids:
                continue
            items.append(
                AchievementCatalogEntry(
                    id=ach.id,
                    name=ach.name,
                    description=ach.description,
                    icon=ach.icon,
                    tier=ach.tier,
                    secret=ach.secret,
                )
            )
        return items

    @router.get("/teams/{team_id}/achievements", response_model=list[TeamAchievement])
    def list_team_achievements(team_id: str):
        """Public badges for a team — secret badges are hidden from others."""
        if not app.state_backend.get_team(team_id):
            raise TeamNotFoundError(team_id)
        return _render_unlocks(app, team_id, include_secret=False)

    @router.get("/me/achievements", response_model=MyAchievementsResponse)
    def get_my_achievements(team: TeamState = Depends(app.get_current_team)):
        """Own unlocks + catalog entries still locked.

        Secret badges show up here once unlocked but stay out of the
        locked list so the discovery remains fun.
        """
        unlocked = _render_unlocks(app, team.team_id, include_secret=True)
        unlocked_ids = {u.achievement_id for u in unlocked}
        locked: list[AchievementCatalogEntry] = []
        for ach in CATALOG:
            if ach.id in unlocked_ids:
                continue
            if ach.secret:
                continue
            locked.append(
                AchievementCatalogEntry(
                    id=ach.id,
                    name=ach.name,
                    description=ach.description,
                    icon=ach.icon,
                    tier=ach.tier,
                    secret=ach.secret,
                )
            )
        return MyAchievementsResponse(unlocked=unlocked, locked=locked)

    @router.post(
        "/admin/teams/{team_id}/achievements/{achievement_id}",
        response_model=TeamAchievement,
    )
    def admin_grant(
        team_id: str,
        achievement_id: str,
        _: None = Depends(app.require_admin),
    ):
        """Admin manual grant — the Bug Hunter path + one-off awards.

        Idempotent on (team_id, achievement_id). A second POST for the
        same pair returns the existing record instead of 409; this keeps
        the admin console simple — the button is always safe to click.
        """
        if not app.state_backend.get_team(team_id):
            raise TeamNotFoundError(team_id)
        ach = get_catalog_entry(achievement_id)
        if ach is None:
            raise HTTPException(404, f"Unknown achievement: {achievement_id}")

        record = app.state_backend.grant_achievement(
            team_id,
            achievement_id,
            context={"granted_by": "admin", "at": datetime.now(timezone.utc).isoformat()},
        )
        if record is not None:
            team = app.state_backend.get_team(team_id)
            # team is not None — we checked above; reassure the type checker.
            assert team is not None
            emit_event(
                app,
                AchievementUnlockedPayload(
                    team_id=team_id,
                    team_name=team.name,
                    achievement_id=ach.id,
                    achievement_name=ach.name,
                    tier=ach.tier,
                    secret=ach.secret,
                ),
                actor_id="admin",
                actor_name="admin",
                actor_type="admin",
            )
        # Re-read to return the canonical record (whether just-created
        # or pre-existing). A list scan is fine — per-team lists are tiny.
        for row in app.state_backend.list_achievements(team_id):
            if row.achievement_id == achievement_id:
                return TeamAchievement(
                    achievement_id=row.achievement_id,
                    name=ach.name,
                    description=ach.description,
                    icon=ach.icon,
                    tier=ach.tier,
                    secret=ach.secret,
                    unlocked_at=row.unlocked_at,
                    context=row.context,
                )
        # Should not reach here (we just granted or it already existed).
        raise HTTPException(500, "Grant succeeded but record not found")

    @router.delete(
        "/admin/teams/{team_id}/achievements/{achievement_id}",
        status_code=204,
    )
    def admin_revoke(
        team_id: str,
        achievement_id: str,
        _: None = Depends(app.require_admin),
    ):
        """Admin revoke — also idempotent; returns 204 whether or not it existed."""
        app.state_backend.revoke_achievement(team_id, achievement_id)
        return None

    return router
