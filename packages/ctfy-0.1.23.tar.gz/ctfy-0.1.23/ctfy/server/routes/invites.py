"""Node invite endpoints — one-time registration credentials.

Mirrors the GitHub Actions runner / Cloudflare Tunnel model: an operator
mints an invite, hands the plaintext token to whoever is standing up a
new node, and the invite is consumed on the first successful
``POST /nodes/register``. Plaintext is returned **exactly once** (on
creation) and never persisted — only the SHA-256 hash lives in the DB.
"""

from __future__ import annotations

import secrets
import time
from datetime import datetime, timezone
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException
from fastapi_pagination import paginate as list_paginate

from ctfy.core.log import log
from ctfy.core.state.models import NodeInviteState
from ctfy.server.app_state import AppState, now_iso
from ctfy.server.auth import hash_token
from ctfy.server.models import (
    BigLimitOffsetPage,
    CreateInviteRequest,
    CreateInviteResponse,
    NodeInviteInfo,
)


def _invite_status(inv: NodeInviteState, now: float) -> str:
    if inv.consumed_at_ts > 0:
        return "consumed"
    if inv.expires_at_ts and now >= inv.expires_at_ts:
        return "expired"
    return "active"


def _to_info(inv: NodeInviteState, now: float) -> NodeInviteInfo:
    return NodeInviteInfo(
        invite_id=inv.invite_id,
        created_at=inv.created_at,
        expires_at=datetime.fromtimestamp(inv.expires_at_ts, tz=timezone.utc).isoformat(),
        status=_invite_status(inv, now),
        consumed_by_node_id=inv.consumed_by_node_id,
    )


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.post(
        "/nodes/invites",
        response_model=CreateInviteResponse,
        dependencies=[Depends(app.require_admin)],
    )
    def create_invite(req: CreateInviteRequest):
        """Mint a one-time registration token.

        The plaintext is only returned on this call. A fresh POST mints a
        fresh token; there is no "regenerate" — old invites stay valid
        until they expire or are revoked.
        """
        plaintext = f"reg_{secrets.token_urlsafe(32)}"
        now = time.time()
        invite = NodeInviteState(
            invite_id=uuid4().hex[:16],
            token_hash=hash_token(plaintext),
            created_at=now_iso(),
            created_at_ts=now,
            expires_at_ts=now + req.ttl_seconds,
        )
        app.state_backend.put_invite(invite)
        log.info(
            "Node invite created",
            invite_id=invite.invite_id,
            ttl_seconds=req.ttl_seconds,
        )
        return CreateInviteResponse(
            invite_id=invite.invite_id,
            registration_token=plaintext,
            expires_at=datetime.fromtimestamp(invite.expires_at_ts, tz=timezone.utc).isoformat(),
        )

    @router.get(
        "/nodes/invites",
        response_model=BigLimitOffsetPage[NodeInviteInfo],
        dependencies=[Depends(app.require_admin)],
    )
    def list_invites():
        """List all invites — active, consumed, and expired."""
        now = time.time()
        items = [_to_info(inv, now) for inv in app.state_backend.list_invites()]
        # Recent first — makes the admin UI predictable without an extra sort.
        items.sort(key=lambda i: i.created_at, reverse=True)
        return list_paginate(items)

    @router.delete(
        "/nodes/invites/{invite_id}",
        dependencies=[Depends(app.require_admin)],
    )
    def revoke_invite(invite_id: str):
        """Revoke an invite. Already-consumed invites behave as 404 — the
        node they minted is unaffected."""
        existing = app.state_backend.get_invite(invite_id)
        if not existing:
            raise HTTPException(404, f"Invite not found: {invite_id}")
        app.state_backend.remove_invite(invite_id)
        log.info("Node invite revoked", invite_id=invite_id)
        return {"status": "revoked", "invite_id": invite_id}

    return router
