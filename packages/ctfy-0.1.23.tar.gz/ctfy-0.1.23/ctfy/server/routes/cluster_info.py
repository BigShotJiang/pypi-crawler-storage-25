"""Cluster info endpoint — non-sensitive cluster metadata.

Exposes the platform URL and recommended node image for the admin UI's
onboarding wizard. The *registration token* that a new node needs is
minted separately via ``POST /nodes/invites`` — kept off this payload
so the wizard only pulls a credential when the operator explicitly
asks for one.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request

from ctfy.server.app_state import AppState
from ctfy.server.models import ClusterInfo


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get(
        "/cluster-info",
        response_model=ClusterInfo,
        dependencies=[Depends(app.require_admin)],
    )
    def cluster_info(request: Request) -> ClusterInfo:
        return ClusterInfo(
            platform_url=str(request.base_url).rstrip("/"),
            node_image=app.config.node_image,
        )

    return router
