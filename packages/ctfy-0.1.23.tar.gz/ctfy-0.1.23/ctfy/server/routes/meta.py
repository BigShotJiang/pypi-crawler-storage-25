"""Aggregate server snapshot for the UI status bar.

A single public endpoint so the bar fires one request instead of four
against ``/challenges``, ``/teams``, ``/nodes``, and ``/scoreboard``.
Only exposes numbers those endpoints already disclose to anonymous
callers; admin-only details (capacity, solves-today) stay on
``/admin/overview``.
"""

from __future__ import annotations

import time
from importlib import metadata

from fastapi import APIRouter

from ctfy.core.constants import HEARTBEAT_TIMEOUT
from ctfy.server.app_state import AppState
from ctfy.server.models import MetaResponse


def _package_version() -> str:
    try:
        return metadata.version("ctfy")
    except metadata.PackageNotFoundError:
        return "0.0.0+unknown"


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/meta", response_model=MetaResponse)
    def meta() -> MetaResponse:
        now = time.time()
        nodes = app.state_backend.list_nodes()
        healthy = sum(
            1
            for n in nodes
            if n.last_heartbeat_ts and (now - n.last_heartbeat_ts) < HEARTBEAT_TIMEOUT
        )
        return MetaResponse(
            version=_package_version(),
            started_at_ts=app.started_at_ts,
            server_time_ts=now,
            challenges_total=sum(1 for _ in app.spec_reader.iter_specs()),
            teams_total=len(app.state_backend.list_teams()),
            nodes_total=len(nodes),
            nodes_healthy=healthy,
            running_instances=app.state_backend.count_instances(),
            solves_total=len(app.state_backend.list_solves()),
        )

    return router
