"""Admin dashboard aggregates — overview counters + solve matrix.

These endpoints answer "what's the whole system doing right now?" in a
single request each, saving the admin UI from orchestrating four
separate calls (nodes / teams / scoreboard / solves) just to render a
landing page.
"""

from __future__ import annotations

import time
from datetime import datetime, timezone

from fastapi import APIRouter, Depends

from ctfy.core.challenge import ChallengeSpec
from ctfy.core.constants import HEARTBEAT_TIMEOUT
from ctfy.core.enums import DIFFICULTY_RANK
from ctfy.core.state.models import NodeHealthSample
from ctfy.server.app_state import AppState
from ctfy.server.models import (
    AdminOverview,
    AdminOverviewCounts,
    AdminSolveCell,
    AdminSolveMatrix,
    AdminSolveMatrixChallenge,
    AdminSolveMatrixTeam,
)


def _start_of_day_utc_ts() -> float:
    """Unix ts at 00:00:00 UTC today — used to count 'solves today'."""
    now = datetime.now(timezone.utc)
    return datetime(now.year, now.month, now.day, tzinfo=timezone.utc).timestamp()


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get(
        "/admin/overview",
        response_model=AdminOverview,
        dependencies=[Depends(app.require_admin)],
    )
    def admin_overview() -> AdminOverview:
        now = time.time()
        nodes = app.state_backend.list_nodes()
        healthy = sum(
            1
            for n in nodes
            if n.last_heartbeat_ts and (now - n.last_heartbeat_ts) < HEARTBEAT_TIMEOUT
        )
        capacity = sum(n.capacity for n in nodes)
        running = sum(n.running for n in nodes)

        teams = app.state_backend.list_teams()
        all_solves = app.state_backend.list_solves()
        day_start = _start_of_day_utc_ts()

        solves_today = 0
        for s in all_solves:
            # ``solved_at`` is an ISO string; fall through on parse failure
            # rather than crashing the endpoint.
            try:
                ts = datetime.fromisoformat(s.solved_at).timestamp()
                if ts >= day_start:
                    solves_today += 1
            except Exception:
                continue

        return AdminOverview(
            nodes=AdminOverviewCounts(total=len(nodes), healthy=healthy),
            capacity=capacity,
            running_instances=running,
            teams_total=len(teams),
            solves_total=len(all_solves),
            solves_today=solves_today,
        )

    @router.get(
        "/admin/solve-matrix",
        response_model=AdminSolveMatrix,
        dependencies=[Depends(app.require_admin)],
    )
    def admin_solve_matrix() -> AdminSolveMatrix:
        """Full team × challenge grid.

        Rows: teams with at least one submission OR one solve (no point
        in a blank row for teams that never tried). Columns: every spec
        in ``challenges_dir`` so the matrix shows overall coverage, not
        just challenges somebody happened to touch. Cells: sparse — only
        (team, challenge) pairs with either attempts or a solve are
        emitted.
        """
        teams = {t.team_id: t for t in app.state_backend.list_teams()}
        all_solves = app.state_backend.list_solves()
        all_submissions = app.state_backend.list_submissions()

        # Build the challenge catalog first so we know how many flags each
        # challenge declares; that gates "fully solved" below.
        flag_ids_by_challenge: dict[str, set[str]] = {}
        for spec in app.spec_reader.iter_specs():
            flag_ids_by_challenge[spec.id] = set(spec.flags)

        # Group solves per (team, challenge) so each cell can check whether
        # every declared flag was captured before marking it as solved.
        solves_by_pair: dict[tuple[str, str], list] = {}
        for s in all_solves:
            solves_by_pair.setdefault((s.team_id, s.challenge_id), []).append(s)
        attempts_by_pair: dict[tuple[str, str], int] = {}
        for s in all_submissions:
            key = (s.team_id, s.challenge_id)
            attempts_by_pair[key] = attempts_by_pair.get(key, 0) + 1

        # Fully-solved pairs + per-challenge full-solve counts.
        fully_solved_pairs: dict[tuple[str, str], list] = {}
        for key, lst in solves_by_pair.items():
            required = flag_ids_by_challenge.get(key[1])
            if required and {s.flag_id for s in lst} >= required:
                fully_solved_pairs[key] = sorted(lst, key=lambda x: x.solved_at)

        full_solves_by_cid: dict[str, list[tuple[str, str]]] = {}
        for (tid, cid) in fully_solved_pairs:
            full_solves_by_cid.setdefault(cid, []).append((tid, cid))

        # First-blood per challenge: earliest final solve wins. "Final" = the
        # latest solved_at among a team's captures; first to reach that wins.
        first_blood: dict[str, str] = {}
        for cid, pairs in full_solves_by_cid.items():
            best_team = ""
            best_ts = ""
            for (tid, _) in pairs:
                # Final-flag timestamp = latest solved_at within this pair.
                final_ts = max(s.solved_at for s in fully_solved_pairs[(tid, cid)])
                if not best_ts or final_ts < best_ts:
                    best_ts = final_ts
                    best_team = tid
            if best_team:
                first_blood[cid] = best_team

        challenge_rows = []
        for spec in app.spec_reader.iter_specs():
            challenge_rows.append(
                AdminSolveMatrixChallenge(
                    challenge_id=spec.id,
                    name=spec.name,
                    category=ChallengeSpec.CATEGORY,
                    difficulty=spec.difficulty.value,
                    solves_count=len(full_solves_by_cid.get(spec.id, [])),
                )
            )
        challenge_rows.sort(key=lambda c: (DIFFICULTY_RANK.get(c.difficulty, 99), c.challenge_id))

        # Teams that have touched anything (submitted or solved).
        active_team_ids = {tid for tid, _ in solves_by_pair.keys()} | {
            tid for tid, _ in attempts_by_pair.keys()
        }
        team_rows: list[AdminSolveMatrixTeam] = []
        for tid in active_team_ids:
            t = teams.get(tid)
            team_rows.append(
                AdminSolveMatrixTeam(
                    team_id=tid,
                    name=t.name if t else tid[:8],
                    solved=sum(1 for (x, _) in fully_solved_pairs if x == tid),
                )
            )
        team_rows.sort(key=lambda t: (-t.solved, t.name))

        cells: list[AdminSolveCell] = []
        seen_pairs: set[tuple[str, str]] = set()
        for (tid, cid), solves in fully_solved_pairs.items():
            # Report the final-flag time as the challenge solve time so
            # the grid reflects when the team finished the full challenge.
            final = max(solves, key=lambda x: x.solved_at)
            cells.append(
                AdminSolveCell(
                    team_id=tid,
                    challenge_id=cid,
                    solved=True,
                    solved_at=final.solved_at,
                    solve_time_s=final.solve_time_s,
                    attempts=attempts_by_pair.get((tid, cid), final.attempts),
                    first_blood=first_blood.get(cid) == tid,
                )
            )
            seen_pairs.add((tid, cid))

        for (tid, cid), n in attempts_by_pair.items():
            if (tid, cid) in seen_pairs:
                continue
            cells.append(
                AdminSolveCell(
                    team_id=tid,
                    challenge_id=cid,
                    solved=False,
                    attempts=n,
                )
            )

        return AdminSolveMatrix(teams=team_rows, challenges=challenge_rows, cells=cells)

    @router.get(
        "/admin/nodes/{node_id}/health-history",
        response_model=list[NodeHealthSample],
        dependencies=[Depends(app.require_admin)],
    )
    def node_health_history(node_id: str, limit: int = 60) -> list[NodeHealthSample]:
        """Uptime-kuma-style history for a single node.

        Returns at most *limit* samples (default 60 ≈ 30 minutes at the
        30s heartbeat cadence), oldest-first. Callers render the series
        left-to-right so the newest sample sits at the right edge.
        """
        # Defensive lower bound so a ``?limit=0`` doesn't look like a
        # server bug returning nothing.
        limit = max(1, min(limit, 200))
        return app.state_backend.list_health_samples(node_id, limit=limit)

    return router
