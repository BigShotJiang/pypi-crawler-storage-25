"""Instance lifecycle endpoints."""

from __future__ import annotations

import asyncio
import uuid

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse
from fastapi_pagination import paginate as list_paginate

from ctfy.core.challenge import ChallengeSpec
from ctfy.core.constants import MAX_INSTANCES_PER_TEAM
from ctfy.core.enums import InstanceStatus
from ctfy.core.exceptions import (
    CapacityExceededError,
    ChallengeNotFoundError,
    InstanceNotFoundError,
)
from ctfy.core.flag import generate_flags, verify_flag
from ctfy.core.log import log
from ctfy.core.state.models import InstanceState, NodeState, TeamState
from ctfy.server.app_state import AppState
from ctfy.server.auth import get_team_id
from ctfy.server.event_payloads import (
    InstanceRenewedPayload,
    InstanceStartedPayload,
    InstanceStoppedPayload,
)
from ctfy.server.events import emit_event
from ctfy.server.instance_lifecycle import archive_instance_record, start_instance_async
from ctfy.server.models import (
    BigLimitOffsetPage,
    InstanceInfo,
    InstanceRecordArtifacts,
    InstanceRecordDetail,
    InstanceRecordInfo,
    InstanceRecordInfoDetail,
    InstanceStatusResponse,
    RenewResponse,
    StartRequest,
    StartResponse,
    StopResponse,
    VerifyFlagRequest,
    VerifyFlagResponse,
)
from ctfy.server.node_ops import (
    get_node_client,
    stop_all_instances_on_node,
    stop_instance_on_node,
)
from ctfy.server.request_meta import client_ip
from ctfy.server.scheduling import pick_node


def _matches_instance(
    inst: InstanceState, *, team_id: str, challenge_id: str, status: str, q: str
) -> bool:
    """Filter predicate for ``GET /instances``.

    Strict per-team scoping: only instances owned by *team_id* are returned.
    Anonymous (unowned) instances are never exposed to a team token.
    """
    if inst.team_id != team_id:
        return False
    if challenge_id and inst.challenge_id != challenge_id:
        return False
    if status and inst.status != status:
        return False
    if q and q.lower() not in (inst.challenge_id + inst.name).lower():
        return False
    return True


def _to_info(inst: InstanceState) -> InstanceInfo:
    return InstanceInfo(
        instance_id=inst.instance_id,
        challenge_id=inst.challenge_id or inst.instance_id,
        team_id=inst.team_id,
        node_id=inst.node_id,
        name=inst.name,
        category=inst.category,
        difficulty=inst.difficulty,
        status=inst.status or InstanceStatus.READY,
        started_at=inst.started_at,
        ttl=inst.ttl,
        expires_at=inst.expires_at,
        services=list(inst.surface.services) if inst.surface else [],
    )


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/instances", response_model=BigLimitOffsetPage[InstanceInfo])
    def list_instances(
        team: TeamState | None = Depends(app.get_current_team_or_none),
        challenge_id: str = "",
        status: str = "",
        q: str = "",
    ):
        # Strict per-team scope: anonymous callers see only anonymous
        # instances; team tokens see only their own. Cross-team peeking is
        # impossible because the filter requires inst.team_id == team_id.
        team_id = get_team_id(team)
        return list_paginate(
            [
                _to_info(inst)
                for inst in app.state_backend.list_instances()
                if _matches_instance(
                    inst, team_id=team_id, challenge_id=challenge_id, status=status, q=q
                )
            ]
        )

    @router.post("/instances", response_model=StartResponse, status_code=202)
    @app.limiter.limit(app.config.rate_limit_instance_start)
    def start_instance(
        request: Request,
        req: StartRequest,
        team: TeamState = Depends(app.get_current_team),
    ):
        challenge_id = req.challenge_id

        # Authenticated teams only — anonymous callers may browse challenges
        # via GET endpoints but cannot launch instances. Different teams are
        # free to concurrently launch the same challenge; the duplicate check
        # below is scoped to (team_id, challenge_id).
        team_id = get_team_id(team)

        # Serialize capacity/duplicate checks and state write to prevent TOCTOU races
        with app.instance_start_lock:
            team_envs = sum(1 for e in app.state_backend.list_instances() if e.team_id == team_id)
            if team_envs >= MAX_INSTANCES_PER_TEAM:
                raise CapacityExceededError(
                    f"Max {MAX_INSTANCES_PER_TEAM} concurrent instances per team"
                )

            # Generate random instance_id
            instance_id = str(uuid.uuid4())

            if app.state_backend.count_instances() >= app.max_instances:
                raise CapacityExceededError("Node at capacity")

            existing = app.state_backend.get_instance_by_team_challenge(team_id, challenge_id)
            if existing:
                return JSONResponse(
                    status_code=409,
                    content=StartResponse(
                        instance_id=existing.instance_id,
                        status=existing.status or InstanceStatus.READY,
                    ).model_dump(),
                )

            # Look up the full challenge spec from metadata.yaml
            spec = None
            for canonical in app.spec_reader.iter_specs(challenge_id=challenge_id):
                if canonical.id == challenge_id:
                    spec = canonical.model_copy(update={"instance_id": instance_id})
                    break
            if spec is None:
                raise ChallengeNotFoundError(challenge_id)

            # Pick a healthy worker node. No node = no challenge.
            target_node = pick_node(app)
            if target_node is None:
                raise CapacityExceededError(
                    "No healthy node available. Register a node first: "
                    "`ctfy node join` or `ctfy server invite`."
                )

            # Mint flags here, on the platform. The node only gets copies
            # to inject as $FLAG_<UPPER_ID>; it never persists or verifies
            # (step 18). Constant-time comparison happens later in
            # verify_flag. Single-flag challenges yield {"main": ...}.
            flags = generate_flags(spec.flags)

            # Write initial state (starting), return immediately
            app.state_backend.put_instance(
                instance_id,
                InstanceState(
                    instance_id=instance_id,
                    spec=spec.model_dump(),
                    challenge_id=challenge_id,
                    status=InstanceStatus.STARTING,
                    team_id=team_id,
                    node_id=target_node.node_id,
                    surface=None,
                    flags=flags,
                    error="",
                    name=spec.name,
                    category=ChallengeSpec.CATEGORY,
                    difficulty=spec.difficulty.value,
                ),
                ttl=req.ttl,
            )

        app.bg_executor.submit(
            start_instance_async,
            app,
            instance_id,
            proxy_output_dir=req.proxy_output_dir,
        )

        log.info("Instance starting (async)", instance=instance_id, ttl=req.ttl)
        emit_event(
            app,
            InstanceStartedPayload(
                team_id=team_id,
                challenge_id=challenge_id,
                instance_id=instance_id,
                node_id=target_node.node_id,
                ip=client_ip(request),
            ),
            actor_id=team_id,
            actor_name=team.name or team_id,
            actor_type="team",
        )
        return StartResponse(instance_id=instance_id, status=InstanceStatus.STARTING)

    # -- resolve endpoint (must be before {instance_id:path} routes) ---------------

    @router.get("/instances/resolve")
    def resolve_instance(challenge_id: str, team: TeamState = Depends(app.get_current_team)):
        """Resolve a challenge_id to its instance_id for the current team."""
        inst_data = app.state_backend.get_instance_by_team_challenge(team.team_id, challenge_id)
        if not inst_data:
            raise InstanceNotFoundError(challenge_id)
        return {"instance_id": inst_data.instance_id}

    # -- instance operation endpoints (with ownership via require_instance) -----

    @router.get("/instances/{instance_id:path}/status", response_model=InstanceStatusResponse)
    def get_instance_status(inst: InstanceState = Depends(app.require_instance)):
        instance_id = inst.instance_id
        status = inst.status or InstanceStatus.READY
        surface = inst.surface if status == InstanceStatus.READY else None

        sandbox_net = ""
        proxy_gw = ""
        cert_vol = ""
        if status == InstanceStatus.READY and inst.node_id:
            node = app.state_backend.get_node(inst.node_id)
            if node:
                try:
                    with get_node_client(app, node) as nc:
                        rt = nc.get_agent_runtime(instance_id)
                    sandbox_net = rt.get("network", "") or ""
                    proxy_gw = rt.get("proxy_gateway_ip", "") or ""
                    cert_vol = rt.get("ca_volume", "") or ""
                except Exception as exc:
                    log.debug(
                        "agent-runtime lookup failed",
                        instance=instance_id,
                        error=str(exc),
                    )

        return InstanceStatusResponse(
            instance_id=instance_id,
            status=status,
            attack_surface=surface,
            error=inst.error or None,
            sandbox_network=sandbox_net,
            proxy_gateway=proxy_gw,
            cert_volume=cert_vol,
        )

    @router.post("/instances/{instance_id:path}/verify-flag", response_model=VerifyFlagResponse)
    def verify_flag_route(
        req: VerifyFlagRequest, inst: InstanceState = Depends(app.require_instance)
    ):
        instance_id = inst.instance_id
        flag_id = verify_flag(app.state_backend, instance_id, req.claimed_flag)
        return VerifyFlagResponse(
            correct=flag_id is not None,
            flag_id=flag_id,
        )

    @router.post("/instances/{instance_id:path}/renew", response_model=RenewResponse)
    def renew_instance(ttl: int = 3600, inst: InstanceState = Depends(app.require_instance)):
        instance_id = inst.instance_id
        try:
            expires_at = app.state_backend.renew_instance(instance_id, ttl)
        except KeyError:
            raise InstanceNotFoundError(instance_id)
        team_id = inst.team_id
        challenge_id = inst.challenge_id or instance_id
        log.info("TTL renewed", instance=instance_id, ttl=ttl)
        emit_event(
            app,
            InstanceRenewedPayload(
                team_id=team_id,
                challenge_id=challenge_id,
                instance_id=instance_id,
                ttl=ttl,
            ),
            actor_id=team_id,
            actor_name=team_id,
            actor_type="team",
        )
        return RenewResponse(instance_id=instance_id, expires_at=expires_at)

    @router.delete("/instances/{instance_id:path}", response_model=StopResponse)
    async def stop_instance(
        request: Request,
        inst: InstanceState = Depends(app.require_instance),
    ):
        instance_id = inst.instance_id
        node_id = inst.node_id
        # Capture container stdout/stderr BEFORE removing the instance — the
        # provider tears down the container on stop and the logs would be
        # lost afterwards.
        archive_instance_record(
            app,
            inst,
            status=InstanceStatus.STOPPED,
            stop_reason="user",
        )
        app.state_backend.remove_instance(instance_id)
        if node_id:
            node = app.state_backend.get_node(node_id)
            if node:
                loop = asyncio.get_running_loop()
                try:
                    await loop.run_in_executor(
                        None,
                        lambda: stop_instance_on_node(app, node, instance_id),
                    )
                except Exception as e:
                    log.error(
                        "Remote stop failed", instance=instance_id, node=node_id, error=str(e)
                    )
                    # Fall through: the platform record is already gone; the
                    # node will eventually reap or it has already.
        challenge_id = inst.challenge_id or instance_id
        stop_team_id = inst.team_id
        log.info("Instance stopped", instance=instance_id)
        emit_event(
            app,
            InstanceStoppedPayload(
                team_id=stop_team_id,
                challenge_id=challenge_id,
                instance_id=instance_id,
                node_id=node_id or "",
                ip=client_ip(request),
            ),
            actor_id=stop_team_id,
            actor_name=stop_team_id,
            actor_type="team",
        )
        return StopResponse(instance_id=instance_id)

    @router.get(
        "/admin/instances",
        response_model=BigLimitOffsetPage[InstanceInfo],
        dependencies=[Depends(app.require_admin)],
    )
    def admin_list_instances(node_id: str = "", status: str = ""):
        """List every instance across all teams / nodes (admin only).

        Complements the team-scoped ``GET /instances``. ``node_id``
        filters to one worker — used by the admin dashboard's
        per-node instance drawer.
        """
        items = []
        for inst in app.state_backend.list_instances():
            if node_id and inst.node_id != node_id:
                continue
            if status and inst.status != status:
                continue
            items.append(_to_info(inst))
        return list_paginate(items)

    @router.delete(
        "/instances",
        response_model=list[StopResponse],
        dependencies=[Depends(app.require_admin)],
    )
    async def stop_all_instances():
        """Stop all running instances across every node (admin only)."""
        loop = asyncio.get_running_loop()
        results = []
        nodes_to_wipe: dict[str, NodeState] = {}
        for inst in app.state_backend.list_instances():
            instance_id = inst.instance_id
            archive_instance_record(
                app,
                inst,
                status=InstanceStatus.STOPPED,
                stop_reason="admin_stop_all",
            )
            app.state_backend.remove_instance(instance_id)
            if inst.node_id:
                node = app.state_backend.get_node(inst.node_id)
                if node:
                    nodes_to_wipe.setdefault(inst.node_id, node)
            # Triggered by `DELETE /instances` which is admin-token guarded;
            # the admin is the effective actor, not the instance's owner team.
            emit_event(
                app,
                InstanceStoppedPayload(
                    team_id=inst.team_id,
                    challenge_id=inst.challenge_id,
                    instance_id=instance_id,
                ),
                actor_id="admin",
                actor_name="admin (stop-all)",
                actor_type="admin",
            )
            results.append(StopResponse(instance_id=instance_id))

        for node in nodes_to_wipe.values():
            try:
                await loop.run_in_executor(None, lambda n=node: stop_all_instances_on_node(app, n))
            except Exception as e:
                log.error("stop-all on node failed", node=node.node_id, error=str(e))

        return results

    # -- instance traffic ------------------------------------------------

    @router.get("/instances/{instance_id:path}/traffic")
    def get_instance_traffic(inst: InstanceState = Depends(app.require_instance)):
        """Parsed mitmproxy traffic — the flow file lives on the node."""
        instance_id = inst.instance_id
        if not inst.node_id:
            return []
        node = app.state_backend.get_node(inst.node_id)
        if not node:
            return []
        try:
            with get_node_client(app, node) as nc:
                return nc.get_traffic(instance_id)
        except Exception as e:
            log.warning(
                "Remote traffic fetch failed",
                instance=instance_id,
                node=inst.node_id,
                error=str(e),
            )
            return []

    # -- admin: archived instance history ------------------------------------

    def _record_to_info(rec) -> InstanceRecordInfo:
        return InstanceRecordInfo(
            instance_id=rec.instance_id,
            team_id=rec.team_id,
            challenge_id=rec.challenge_id,
            node_id=rec.node_id,
            name=rec.name,
            category=rec.category,
            difficulty=rec.difficulty,
            status=rec.status,
            stop_reason=rec.stop_reason,
            error=rec.error,
            started_at=rec.started_at,
            stopped_at=rec.stopped_at,
            duration_s=rec.duration_s,
            ttl=rec.ttl,
            solved=rec.solved,
            attempts=rec.attempts,
        )

    @router.get(
        "/admin/instance-records",
        response_model=BigLimitOffsetPage[InstanceRecordInfo],
        dependencies=[Depends(app.require_admin)],
    )
    def admin_list_instance_records(
        team_id: str = "",
        challenge_id: str = "",
        node_id: str = "",
        status: str = "",
        since_ts: float = 0.0,
        offset: int = 0,
        limit: int = 100,
    ):
        """List every archived instance across all teams / nodes (admin only).

        Complements the in-memory ``GET /admin/instances`` — that endpoint
        shows only the live fast-path; this one surfaces the permanent
        record of everything that ever ran.
        """
        total = app.state_backend.count_instance_records(
            team_id=team_id,
            challenge_id=challenge_id,
            node_id=node_id,
            status=status,
            since_ts=since_ts,
        )
        items = [
            _record_to_info(rec)
            for rec in app.state_backend.list_instance_records(
                team_id=team_id,
                challenge_id=challenge_id,
                node_id=node_id,
                status=status,
                since_ts=since_ts,
                offset=offset,
                limit=limit,
            )
        ]
        # fastapi-pagination's LimitOffsetPage doesn't support manual
        # construction easily, so use the shared `list_paginate` helper on
        # an over-selected slice. Our list_instance_records already applies
        # the limit — pass items through and let pagination echo them.
        from fastapi_pagination import LimitOffsetParams
        from fastapi_pagination.bases import AbstractPage

        # Build a hand-rolled page to pass limit/offset + total faithfully.
        page_cls: type[AbstractPage] = BigLimitOffsetPage
        params = LimitOffsetParams(limit=limit, offset=offset)
        return page_cls.create(items=items, total=total, params=params)

    @router.get(
        "/admin/instance-records/{instance_id}",
        response_model=InstanceRecordDetail,
        dependencies=[Depends(app.require_admin)],
    )
    def admin_get_instance_record(instance_id: str):
        rec = app.state_backend.get_instance_record(instance_id)
        if rec is None:
            raise InstanceNotFoundError(instance_id)
        detail = InstanceRecordInfoDetail(
            **_record_to_info(rec).model_dump(),
            spec=rec.spec or {},
            surface=rec.surface,
            artifact_dir=rec.artifact_dir,
        )
        artifacts = InstanceRecordArtifacts()
        archive = app.instance_archive
        if archive is not None:
            artifacts = InstanceRecordArtifacts(
                has_manifest=archive.has_artifact(instance_id, "instance.json"),
                has_container_log=archive.has_artifact(instance_id, "container.log"),
                events_count=len(archive.read_events(instance_id)),
                submissions_count=len(archive.read_submissions(instance_id)),
            )
        return InstanceRecordDetail(record=detail, artifacts=artifacts)

    @router.get(
        "/admin/instance-records/{instance_id}/events",
        dependencies=[Depends(app.require_admin)],
    )
    def admin_instance_record_events(instance_id: str, limit: int = 0):
        if app.instance_archive is None:
            return []
        return app.instance_archive.read_events(instance_id, limit=limit)

    @router.get(
        "/admin/instance-records/{instance_id}/submissions",
        dependencies=[Depends(app.require_admin)],
    )
    def admin_instance_record_submissions(instance_id: str, limit: int = 0):
        if app.instance_archive is None:
            return []
        return app.instance_archive.read_submissions(instance_id, limit=limit)

    @router.get(
        "/admin/instance-records/{instance_id}/container-log",
        dependencies=[Depends(app.require_admin)],
    )
    def admin_instance_record_container_log(instance_id: str):
        logs = ""
        if app.instance_archive is not None:
            logs = app.instance_archive.read_container_log(instance_id)
        return {"instance_id": instance_id, "logs": logs}

    return router
