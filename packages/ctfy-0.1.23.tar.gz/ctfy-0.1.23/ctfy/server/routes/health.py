"""Health check endpoint."""

from __future__ import annotations

import socket

from fastapi import APIRouter

from ctfy.server.app_state import AppState
from ctfy.server.models import HealthResponse


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/health", response_model=HealthResponse)
    def health():
        count = app.state_backend.count_instances()
        return HealthResponse(
            hostname=socket.gethostname(),
            running_instances=count,
            capacity=max(0, app.max_instances - count),
        )

    return router
