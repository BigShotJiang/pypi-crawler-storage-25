"""Flag submission endpoints."""

from __future__ import annotations

import json
import time
import uuid

from fastapi import APIRouter, Depends, Request
from fastapi_pagination import paginate as list_paginate

from ctfy.core.enums import InstanceStatus
from ctfy.core.exceptions import InstanceNotFoundError
from ctfy.core.flag import verify_flag
from ctfy.core.log import log
from ctfy.core.state.models import SolveState, SubmissionState, TeamState
from ctfy.server.app_state import AppState, now_iso
from ctfy.server.event_payloads import (
    FlagCorrectPayload,
    FlagWrongPayload,
    InstanceStoppedPayload,
)
from ctfy.server.events import emit_event
from ctfy.server.instance_lifecycle import archive_instance_record
from ctfy.server.models import (
    BigLimitOffsetPage,
    SubmissionCreate,
    SubmissionResponse,
)
from ctfy.server.node_ops import get_node_client
from ctfy.server.request_meta import client_ip


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.post("/submissions", response_model=SubmissionResponse)
    @app.limiter.limit(app.config.rate_limit_submission)
    def submit_flag(
        request: Request,
        req: SubmissionCreate,
        team: TeamState = Depends(app.get_current_team),
    ):
        team_id = team.team_id
        challenge_id = req.challenge_id

        # Look up the team's instance for this challenge
        inst_data = app.state_backend.get_instance_by_team_challenge(team_id, challenge_id)
        if not inst_data:
            raise InstanceNotFoundError(challenge_id)
        instance_id = inst_data.instance_id
        flag_id = verify_flag(app.state_backend, instance_id, req.flag)
        correct = flag_id is not None

        # Compute solve time (from instance start to now)
        solve_time_s = 0.0
        if correct:
            inst = app.state_backend.get_instance(instance_id)
            started_at = inst.started_at if inst else 0
            if started_at:
                solve_time_s = round(time.time() - float(started_at), 1)

        # Record submission (flag_id = "" on wrong claims).
        sub_id = str(uuid.uuid4())
        ts = now_iso()
        submission = SubmissionState(
            submission_id=sub_id,
            team_id=team_id,
            challenge_id=challenge_id,
            claimed_flag=req.flag,
            correct=correct,
            flag_id=flag_id or "",
            submitted_at=ts,
            solve_time_s=solve_time_s,
        )
        app.state_backend.add_submission(submission)
        # Mirror into the per-instance archive so offline analysis can read
        # every flag attempt against one instance without replaying the
        # global submissions table. Best-effort — a filesystem failure must
        # not break the submission API.
        if app.instance_archive is not None:
            app.instance_archive.append_submission(
                instance_id,
                json.loads(submission.model_dump_json()),
            )

        # Per-flag solve: record on first hit of this flag_id. A repeat
        # submission of an already-captured flag is counted in submissions
        # (for attempt stats) but not in solves.
        all_flag_ids = list((inst_data.flags or {}).keys())
        newly_solved = False
        solve_rank = 0
        fully_solved = False
        if correct and flag_id:
            existing = app.state_backend.get_solve(team_id, challenge_id, flag_id)
            if not existing:
                attempts = len(
                    app.state_backend.list_submissions(team_id=team_id, challenge_id=challenge_id)
                )
                app.state_backend.add_solve(
                    team_id,
                    challenge_id,
                    flag_id,
                    SolveState(
                        team_id=team_id,
                        challenge_id=challenge_id,
                        flag_id=flag_id,
                        solved_at=ts,
                        solve_time_s=solve_time_s,
                        attempts=attempts,
                    ),
                )
                newly_solved = True
                # Post-insert count equals this team's 1-indexed solve rank
                # for *this flag*. Drives tiered "first/second/third blood"
                # celebration effects on the client.
                solve_rank = app.state_backend.count_solves_for_flag(
                    challenge_id, flag_id
                )
                log.info(
                    "Flag solved",
                    team=team_id,
                    challenge=challenge_id,
                    flag_id=flag_id,
                    solve_time=f"{solve_time_s}s",
                    solve_rank=solve_rank,
                )

            # Fully solved = team now has a SolveState for every declared
            # flag. Checked after the add_solve above so the freshly-hit
            # flag is counted without a re-read race.
            captured = {
                fid
                for fid in all_flag_ids
                if app.state_backend.get_solve(team_id, challenge_id, fid) is not None
            }
            fully_solved = bool(all_flag_ids) and captured == set(all_flag_ids)

        if correct:
            emit_event(
                app,
                FlagCorrectPayload(
                    team_id=team_id,
                    team_name=team.name,
                    challenge_id=challenge_id,
                    instance_id=instance_id,
                    solve_time_s=solve_time_s,
                    ip=client_ip(request),
                    flag_id=flag_id or "",
                    challenge_fully_solved=fully_solved,
                ),
                actor_id=team_id,
                actor_name=team.name or team_id,
                actor_type="team",
            )
        else:
            emit_event(
                app,
                FlagWrongPayload(
                    team_id=team_id,
                    team_name=team.name,
                    challenge_id=challenge_id,
                    instance_id=instance_id,
                    solve_time_s=0,
                    ip=client_ip(request),
                ),
                actor_id=team_id,
                actor_name=team.name or team_id,
                actor_type="team",
            )

        # Auto-destroy instance only after *every* declared flag is captured.
        if fully_solved and newly_solved:
            node_id = inst_data.node_id

            if node_id:

                def _auto_stop():
                    try:
                        # Capture container logs + archive row BEFORE
                        # stopping: the provider tears the container down
                        # on stop_instance and the logs would be lost.
                        archive_instance_record(
                            app,
                            inst_data,
                            status=InstanceStatus.STOPPED,
                            stop_reason="auto_stop_after_solve",
                        )
                        app.state_backend.remove_instance(instance_id)
                        node = app.state_backend.get_node(node_id)
                        if node:
                            with get_node_client(app, node) as nc:
                                nc.stop_instance(instance_id)
                        log.info(
                            "Auto-stopped instance after full solve",
                            instance=instance_id,
                            challenge=challenge_id,
                        )
                        emit_event(
                            app,
                            InstanceStoppedPayload(
                                team_id=team_id,
                                challenge_id=challenge_id,
                                instance_id=instance_id,
                                reason="auto_stop_after_solve",
                            ),
                            actor_id="system",
                            actor_name="auto-stop",
                            actor_type="system",
                        )
                    except Exception as e:
                        log.error(
                            "Auto-stop failed after solve", instance=instance_id, error=str(e)
                        )

                app.bg_executor.submit(_auto_stop)

        return SubmissionResponse(
            submission_id=sub_id,
            correct=correct,
            solve_time_s=solve_time_s,
            solve_rank=solve_rank,
            flag_id=flag_id,
            challenge_fully_solved=fully_solved,
        )

    @router.get("/submissions", response_model=BigLimitOffsetPage[SubmissionState])
    def list_my_submissions(
        team: TeamState = Depends(app.get_current_team),
        challenge_id: str = "",
    ):
        """List current team's submissions."""
        all_subs = app.state_backend.list_submissions(
            team_id=team.team_id, challenge_id=challenge_id
        )
        return list_paginate(all_subs)

    return router
