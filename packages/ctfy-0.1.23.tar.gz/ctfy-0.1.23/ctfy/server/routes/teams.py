"""Team management endpoints."""

from __future__ import annotations

import secrets
import uuid

from fastapi import APIRouter, Depends, Request
from fastapi_pagination import paginate as list_paginate

from ctfy.core.exceptions import TeamNotFoundError
from ctfy.core.log import log
from ctfy.core.state.models import TeamState
from ctfy.server.app_state import AppState, now_iso
from ctfy.server.auth import hash_token
from ctfy.server.event_payloads import TeamRegisteredPayload
from ctfy.server.events import emit_event
from ctfy.server.models import (
    BigLimitOffsetPage,
    TeamCreate,
    TeamInfo,
    TeamResponse,
)
from ctfy.server.request_meta import client_ip


def _last_active_at(app: AppState, team_id: str) -> str:
    """Newest activity timestamp for a team, or empty if none recorded."""
    recent = app.state_backend.list_activities(team_id=team_id, offset=0, limit=1)
    return recent[0].timestamp if recent else ""


def _team_info(app: AppState, t: TeamState) -> TeamInfo:
    tid = t.team_id
    return TeamInfo(
        team_id=tid,
        name=t.name,
        agent=t.agent,
        description=t.description,
        created_at=t.created_at,
        solves=len(app.state_backend.list_solves(tid)),
        attempts=len(app.state_backend.list_submissions(team_id=tid)),
        last_active_at=_last_active_at(app, tid),
    )


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.post("/teams", response_model=TeamResponse)
    @app.limiter.limit(app.config.rate_limit_team_create)
    def create_team(request: Request, req: TeamCreate):
        team_id = str(uuid.uuid4())
        token = f"pt_{secrets.token_urlsafe(32)}"
        token_hash = hash_token(token)
        now = now_iso()
        data = TeamState(
            team_id=team_id,
            name=req.name,
            agent=req.agent,
            description=req.description,
            token=token_hash,  # store hash, not plaintext
            created_at=now,
        )
        app.state_backend.put_team(team_id, data)
        log.info("Team registered", team_id=team_id, name=req.name)
        emit_event(
            app,
            TeamRegisteredPayload(
                team_id=team_id,
                team_name=req.name,
                agent=req.agent,
                ip=client_ip(request),
            ),
            actor_id=team_id,
            actor_name=req.name or team_id,
            actor_type="team",
        )
        # Return plaintext token ONCE (never stored)
        return TeamResponse(**{**data.model_dump(), "token": token})

    @router.get("/teams", response_model=BigLimitOffsetPage[TeamInfo])
    def list_teams():
        all_teams = [_team_info(app, t) for t in app.state_backend.list_teams()]
        return list_paginate(all_teams)

    @router.get("/teams/{team_id}", response_model=TeamInfo)
    def get_team(team_id: str):
        t = app.state_backend.get_team(team_id)
        if not t:
            raise TeamNotFoundError(team_id)
        return _team_info(app, t)

    @router.get("/me", response_model=TeamInfo)
    def get_me(team: TeamState = Depends(app.get_current_team)):
        """Get current team info (requires team auth)."""
        return _team_info(app, team)

    return router
