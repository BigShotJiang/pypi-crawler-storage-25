"""Scoreboard endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Request
from fastapi_pagination import paginate as list_paginate

from ctfy.core.challenge import ChallengeSpec
from ctfy.core.state.models import ScoreboardSnapshotState
from ctfy.server.app_state import AppState
from ctfy.server.models import (
    BigLimitOffsetPage,
    ChallengeFlagStats,
    ChallengeStats,
    ScoreboardEntry,
)


def _spec_flag_ids(app: AppState) -> dict[str, list[str]]:
    """Map challenge_id → declared flag ids. Cached per-call."""
    return {spec.id: list(spec.flags) for spec in app.spec_reader.iter_specs()}


def compute_scoreboard(app: AppState) -> list[ScoreboardEntry]:
    """Compute the current ranked scoreboard.

    Factored out of the route handler so the snapshot background loop
    can call the same logic without going through FastAPI. Primary sort
    is ``flags_solved`` desc (rewards partial progress across multi-flag
    challenges); tiebreakers: more fully-solved challenges, then earlier
    ``last_solve_at``.
    """
    entries: list[ScoreboardEntry] = []
    flag_ids_by_challenge = _spec_flag_ids(app)
    teams = app.state_backend.list_teams()
    for t in teams:
        tid = t.team_id
        solves = app.state_backend.list_solves(tid)
        last_active = ""
        recent = app.state_backend.list_activities(team_id=tid, offset=0, limit=1)
        if recent:
            last_active = recent[0].timestamp
        if not solves:
            entries.append(
                ScoreboardEntry(
                    team_id=tid,
                    team_name=t.name,
                    agent=t.agent,
                    solved=0,
                    flags_solved=0,
                    attempts=0,
                    last_active_at=last_active,
                )
            )
            continue
        last = max(s.solved_at for s in solves)
        all_subs = app.state_backend.list_submissions(team_id=tid)
        attempts = len(all_subs)
        flags_solved = len(solves)
        # Fully-solved challenges = every declared flag captured.
        per_chal: dict[str, set[str]] = {}
        for s in solves:
            per_chal.setdefault(s.challenge_id, set()).add(s.flag_id)
        fully_solved_count = sum(
            1
            for cid, captured in per_chal.items()
            if cid in flag_ids_by_challenge
            and set(flag_ids_by_challenge[cid]) <= captured
        )
        entries.append(
            ScoreboardEntry(
                team_id=tid,
                team_name=t.name,
                agent=t.agent,
                solved=fully_solved_count,
                flags_solved=flags_solved,
                attempts=attempts,
                last_solve_at=last,
                last_active_at=last_active,
            )
        )
    entries.sort(key=lambda e: (-e.flags_solved, -e.solved, e.last_solve_at))
    for i, e in enumerate(entries):
        e.rank = i + 1
    return entries


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/scoreboard", response_model=BigLimitOffsetPage[ScoreboardEntry])
    @app.limiter.limit(app.config.rate_limit_scoreboard)
    def get_scoreboard(request: Request):
        return list_paginate(compute_scoreboard(app))

    @router.get("/scoreboard/history", response_model=list[ScoreboardSnapshotState])
    @app.limiter.limit(app.config.rate_limit_scoreboard)
    def get_scoreboard_history(
        request: Request,
        team_id: str = "",
        days: int = 7,
    ) -> list[ScoreboardSnapshotState]:
        """Point-in-time scoreboard snapshots for chart rendering.

        Samples are captured every SCOREBOARD_SNAPSHOT_INTERVAL seconds
        by a background loop and kept permanently. Callers pass
        ``team_id`` to get one team's trend, or leave it empty for
        every team in the window.

        ``days`` defaults to 7 (the usual chart window). ``days=0``
        means "no lower bound, return everything" — useful for
        post-competition exports. Anything above 365 is clamped as an
        API-level sanity guard against an accidental multi-year scan.
        """
        import time

        if days < 0:
            days = 0
        elif days > 365:
            days = 365
        since_ts = 0.0 if days == 0 else time.time() - days * 86400.0
        return app.state_backend.list_snapshots(
            team_id=team_id,
            since_ts=since_ts,
        )

    @router.get("/scoreboard/challenges", response_model=BigLimitOffsetPage[ChallengeStats])
    @app.limiter.limit(app.config.rate_limit_scoreboard)
    def get_challenge_stats(request: Request):
        result = []
        for spec in app.spec_reader.iter_specs():
            cid = spec.id
            flag_ids = tuple(spec.flags)
            solves = [s for s in app.state_backend.list_solves() if s.challenge_id == cid]
            all_subs = app.state_backend.list_submissions(challenge_id=cid)
            correct_subs = [s for s in all_subs if s.correct]
            success_rate = len(correct_subs) / len(all_subs) * 100 if all_subs else 0
            # Full-challenge solves = teams that captured every flag.
            fully_solved = app.state_backend.count_solves_for_challenge(cid, flag_ids)
            # Per-flag breakdown for the detail page.
            per_flag_counts: dict[str, int] = {fid: 0 for fid in flag_ids}
            for s in solves:
                if s.flag_id in per_flag_counts:
                    per_flag_counts[s.flag_id] += 1
            flag_stats = [
                ChallengeFlagStats(flag_id=fid, solves_count=per_flag_counts[fid])
                for fid in flag_ids
            ]
            result.append(
                ChallengeStats(
                    challenge_id=cid,
                    name=spec.name,
                    category=ChallengeSpec.CATEGORY,
                    difficulty=spec.difficulty.value,
                    solves_count=fully_solved,
                    total_attempts=len(all_subs),
                    success_rate=round(success_rate, 1),
                    flag_stats=flag_stats,
                )
            )
        return list_paginate(result)

    return router
