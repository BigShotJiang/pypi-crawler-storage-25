"""Challenge listing endpoints."""

from __future__ import annotations

from fastapi import APIRouter
from fastapi_pagination import paginate as list_paginate

from ctfy.core.challenge import ChallengeSpec
from ctfy.core.exceptions import ChallengeNotFoundError
from ctfy.server.app_state import AppState
from ctfy.server.models import BigLimitOffsetPage, ChallengeInfo


def _challenge_info(app: AppState, spec: ChallengeSpec) -> ChallengeInfo:
    flag_ids = tuple(spec.flags)
    per_flag = {
        fid: app.state_backend.count_solves_for_flag(spec.id, fid) for fid in flag_ids
    }
    return ChallengeInfo(
        id=spec.id,
        name=spec.name,
        category=ChallengeSpec.CATEGORY,
        difficulty=spec.difficulty.value,
        description=spec.description,
        solves_count=app.state_backend.count_solves_for_challenge(spec.id, flag_ids),
        tags=spec.tags,
        flag_ids=list(flag_ids),
        flag_solves=per_flag,
    )


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/challenges", response_model=BigLimitOffsetPage[ChallengeInfo])
    def list_challenges(
        difficulty: str = "",
        tag: str = "",
        q: str = "",
    ):
        specs = app.spec_reader.iter_specs(
            difficulty=difficulty or None,
            tag=tag or None,
        )
        if q:
            ql = q.lower()
            specs = (s for s in specs if ql in (s.id + s.name + s.description).lower())
        all_challenges = [_challenge_info(app, s) for s in specs]
        return list_paginate(all_challenges)

    @router.get("/challenges/{challenge_id}", response_model=ChallengeInfo)
    def get_challenge(challenge_id: str):
        for spec in app.spec_reader.iter_specs(challenge_id=challenge_id):
            if spec.id == challenge_id:
                return _challenge_info(app, spec)
        raise ChallengeNotFoundError(challenge_id)

    return router
