"""Node placement scheduling: pick a healthy worker node for a new instance.

Extracted from ``routes/instances.py`` so the algorithm can be tested
independently from the HTTP layer (see TODO in the main plan about unit
tests for capacity/heartbeat edge cases).
"""

from __future__ import annotations

import time

from ctfy.core.constants import HEARTBEAT_TIMEOUT
from ctfy.core.state.models import NodeState
from ctfy.server.app_state import AppState

__all__ = ["pick_node"]


def pick_node(app: AppState) -> NodeState | None:
    """Select the healthiest node with the most available capacity (least-loaded).

    Returns ``None`` when no node passes the health + heartbeat + capacity
    gates.
    """
    now = time.time()
    best: NodeState | None = None
    for n in app.state_backend.list_nodes():
        if not n.healthy:
            continue
        lb = n.last_heartbeat_ts
        if lb and (now - lb) > HEARTBEAT_TIMEOUT:
            continue  # stale heartbeat
        avail = n.capacity - n.running
        if avail <= 0:
            continue
        if best is None or avail > (best.capacity - best.running):
            best = n
    return best
