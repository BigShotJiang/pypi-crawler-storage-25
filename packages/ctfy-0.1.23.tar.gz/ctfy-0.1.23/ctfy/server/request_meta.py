"""Small helpers for pulling request metadata into activity events.

Kept deliberately minimal so route handlers can stay readable. The one
rule: **no ``X-Forwarded-For`` parsing**. The platform records the
direct peer only; trusting forwarded headers without a verified proxy
allowlist would let clients spoof their source IP in audit logs.
"""

from __future__ import annotations

from fastapi import Request

__all__ = ["client_ip"]


def client_ip(request: Request) -> str:
    """Return the peer's IP, or the empty string if the resolver can't
    produce one (e.g. ASGI test clients)."""
    return request.client.host if request.client else ""
