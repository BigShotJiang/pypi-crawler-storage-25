"""Authentication and ownership dependencies for the platform server.

Four token identities are supported:

- **admin** (DB key ``admin_key``, env ``CTFY_ADMIN_TOKEN``): human operator;
  manage teams, mint invites, list/remove nodes, stop-all.
- **invite** (``NodeInviteState``, minted by ``POST /nodes/invites``): one-time
  registration credential. Only valid on ``POST /nodes/register``; burned
  atomically on use.
- **per-node** (``NodeState.token``, minted on register): the node's
  identity. Used in both directions — node→platform (heartbeat,
  deregister) and platform→node (start/stop/status). One symmetric
  bearer per node.
- **team** (stored per-team in ``teams`` table): end users calling the platform
  for their own resources.

Ownership helpers (:func:`get_team_id`, :func:`check_ownership`,
:func:`check_node_identity`) live here because "who is this caller and what
may they touch" is one concern.
"""

from __future__ import annotations

import hashlib
import hmac
import time

from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from ctfy.core.exceptions import ForbiddenError
from ctfy.core.state import StateBackend
from ctfy.core.state.models import InstanceState, NodeInviteState, NodeState, TeamState

# Shared security schemes — HTTPBearer handles "Bearer " parsing automatically
bearer_required = HTTPBearer()  # no token → 403
bearer_optional = HTTPBearer(auto_error=False)  # no token → None


def hash_token(token: str) -> str:
    """SHA-256 hash of a plaintext bearer token. Used for storage and lookup."""
    return hashlib.sha256(token.encode()).hexdigest()


def _resolve_team(
    state_backend: StateBackend, credentials: HTTPAuthorizationCredentials
) -> TeamState:
    """Shared: resolve credentials to team model, or raise 403."""
    team = state_backend.get_team_by_token(hash_token(credentials.credentials))
    if not team:
        raise HTTPException(403, "Invalid team token")
    return team


def _admin_configured(state_backend: StateBackend) -> str | None:
    return state_backend.get_config("admin_key")


def _matches_admin(state_backend: StateBackend, token: str) -> bool:
    expected = _admin_configured(state_backend)
    return bool(expected and hmac.compare_digest(token, expected))


def make_require_admin(state_backend: StateBackend):
    """Strict admin auth: rejects if no admin_key is configured."""

    async def dep(
        credentials: HTTPAuthorizationCredentials | None = Depends(bearer_optional),
    ) -> None:
        expected = _admin_configured(state_backend)
        if not expected:
            raise HTTPException(403, "Admin key not configured; admin endpoints disabled")
        if not credentials:
            raise HTTPException(401, "Missing bearer token")
        if not hmac.compare_digest(credentials.credentials, expected):
            raise HTTPException(403, "Invalid admin API key")

    return dep


def make_require_invite_or_admin(state_backend: StateBackend):
    """Node-registration auth: accept a one-time invite token or the
    admin token.

    Returns the :class:`NodeInviteState` when an invite path is taken,
    otherwise ``None`` for admin. The register handler reads this return
    value and, if it's an invite, atomically consumes it on success —
    unused invites stay active so a failed registration can be retried
    with the same token.
    """

    async def dep(
        credentials: HTTPAuthorizationCredentials | None = Depends(bearer_optional),
    ) -> NodeInviteState | None:
        if not credentials:
            raise HTTPException(401, "Missing bearer token")
        token = credentials.credentials
        # Invite path first — identity-bearing and the recommended flow.
        invite = state_backend.get_invite_by_hash(hash_token(token))
        if invite:
            if invite.consumed_at_ts > 0:
                raise HTTPException(403, "Invite has already been used")
            if invite.expires_at_ts and time.time() >= invite.expires_at_ts:
                raise HTTPException(403, "Invite has expired")
            return invite
        # Admin fallback — operator escape hatch.
        if _matches_admin(state_backend, token):
            return None
        raise HTTPException(403, "Invalid invite or admin token")

    return dep


def make_require_node_or_admin(state_backend: StateBackend):
    """Accept a per-node outbound token (preferred) or the admin token.

    Per-node tokens are issued by ``POST /nodes/register`` and identify a
    specific node; routes that mutate per-node state should call
    :func:`check_node_identity` with this dependency's return value so a
    node cannot impersonate another node.

    Return value is the authenticated :class:`NodeState` when a per-node
    token was used, or ``None`` when the admin path was taken.
    """

    async def dep(
        credentials: HTTPAuthorizationCredentials | None = Depends(bearer_optional),
    ) -> NodeState | None:
        if not credentials:
            raise HTTPException(401, "Missing bearer token")
        token = credentials.credentials
        node = state_backend.get_node_by_token(token)
        if node:
            return node
        if _matches_admin(state_backend, token):
            return None
        raise HTTPException(403, "Invalid node or admin token")

    return dep


def check_node_identity(authenticated: NodeState | None, node_id: str) -> None:
    """Guard per-node routes: reject if a node-token caller targets another node.

    ``authenticated`` is what :func:`make_require_node_or_admin` returned —
    the :class:`NodeState` when the caller used a per-node token, or ``None``
    when they used the admin token. Admin is trusted with any ``node_id``; a
    per-node token must match the path/param node.
    """
    if authenticated is None:
        return
    if authenticated.node_id != node_id:
        raise HTTPException(403, "Node token does not match target node")


def make_get_current_team(state_backend: StateBackend):
    """Strict team auth: resolves Bearer token -> team model. 403 if missing."""

    async def get_current_team(
        credentials: HTTPAuthorizationCredentials = Depends(bearer_required),
    ) -> TeamState:
        return _resolve_team(state_backend, credentials)

    return get_current_team


def make_get_current_team_or_none(state_backend: StateBackend):
    """Optional team auth: returns team model if token provided and valid, None otherwise."""

    async def get_current_team_or_none(
        credentials: HTTPAuthorizationCredentials | None = Depends(bearer_optional),
    ) -> TeamState | None:
        if not credentials:
            return None
        team = state_backend.get_team_by_token(hash_token(credentials.credentials))
        return team  # None if token doesn't match any team (e.g. admin key)

    return get_current_team_or_none


# ---------------------------------------------------------------------------
# Ownership helpers — used by routes to guard per-team resource access.
# ---------------------------------------------------------------------------


def get_team_id(team: TeamState | None) -> str:
    """Extract ``team_id`` from an optional team model (empty when anonymous)."""
    return team.team_id if team else ""


def check_ownership(
    resource: TeamState | InstanceState,
    team: TeamState | None,
    resource_name: str = "resource",
) -> None:
    """Raise :class:`ForbiddenError` if the authenticated team doesn't own *resource*.

    Unowned resources (``resource.team_id == ""``) are reachable by everyone — they
    pre-date team scoping and are not security-sensitive. For owned resources the
    caller MUST be authenticated and the team_id MUST match; an anonymous caller
    or a token belonging to a different team is rejected.
    """
    if not resource.team_id:
        return
    if team is None or resource.team_id != team.team_id:
        raise ForbiddenError(f"Not your {resource_name}")
