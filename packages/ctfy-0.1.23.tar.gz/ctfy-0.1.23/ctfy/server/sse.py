"""Server-Sent Events hub for broadcasting platform events to connected clients.

The hub's queue carries **fully-formatted SSE frame strings** rather than
dicts. Encoding the wire format at broadcast time (instead of deferring
it to the per-client generator) means every consumer sees the same
immutable string — no dict-sharing, no ``pop()`` mutation, no accidental
state leakage between clients. The wire format lives in one place
(:meth:`SSEHub._encode`) and the route handler is a thin passthrough.
"""

from __future__ import annotations

import asyncio
import json
from uuid import uuid4

from ctfy.core.log import log


class SSEHub:
    """In-process pub/sub hub for SSE connections.

    Each connected client gets an asyncio.Queue. When ``broadcast()`` is called
    (potentially from a non-asyncio thread), frames are enqueued to all
    matching clients via ``loop.call_soon_threadsafe``.
    """

    def __init__(self) -> None:
        # client_id -> (queue of pre-formatted SSE frames, team_id)
        self._clients: dict[str, tuple[asyncio.Queue[str], str]] = {}
        self._loop: asyncio.AbstractEventLoop | None = None

    def set_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        """Capture the running event loop (call once during lifespan startup)."""
        self._loop = loop

    def connect(self, team_id: str = "") -> tuple[str, asyncio.Queue[str]]:
        """Register a new SSE client. Returns (client_id, queue)."""
        client_id = uuid4().hex
        q: asyncio.Queue[str] = asyncio.Queue(maxsize=64)
        self._clients[client_id] = (q, team_id)
        log.info(
            "SSE client connected",
            client_id=client_id[:8],
            team_id=team_id or "<anon>",
            total_clients=len(self._clients),
        )
        return client_id, q

    def disconnect(self, client_id: str) -> None:
        """Remove a client on disconnect."""
        self._clients.pop(client_id, None)
        log.info(
            "SSE client disconnected",
            client_id=client_id[:8],
            total_clients=len(self._clients),
        )

    @staticmethod
    def _encode(event: str, data: dict | None) -> str:
        """Produce the canonical SSE wire frame for *event* / *data*.

        Format: ``event: <name>\\ndata: <json>\\n\\n`` — see
        https://html.spec.whatwg.org/multipage/server-sent-events.html
        ``separators=(",", ":")`` keeps frames compact so small events
        fit inside one chunked-transfer chunk.
        """
        return f"event: {event}\ndata: {json.dumps(data or {}, separators=(',', ':'))}\n\n"

    def broadcast(self, event: str, *, team_id: str = "", data: dict | None = None) -> None:
        """Send *event* to all matching clients. Thread-safe.

        The frame is encoded **once** here and the resulting string is
        queued verbatim to every eligible client. Strings are immutable
        so consumers cannot corrupt each other's payload — no matter
        what the route handler does with the value it pulls off the
        queue, the next consumer sees the bytes unchanged.
        """
        frame = self._encode(event, data)
        delivered = 0
        skipped = 0
        for cid, (q, client_team) in list(self._clients.items()):
            # Team-scoped client only sees its own team's events (or global)
            if client_team and team_id and client_team != team_id:
                skipped += 1
                continue
            if self._loop and self._loop.is_running():
                self._loop.call_soon_threadsafe(self._put_nowait, q, cid, frame)
            else:
                self._put_nowait(q, cid, frame)
            delivered += 1
        log.info(
            "SSE broadcast",
            event_name=event,
            team_id=team_id or "<global>",
            delivered=delivered,
            skipped=skipped,
        )

    def _put_nowait(self, q: asyncio.Queue[str], cid: str, frame: str) -> None:
        try:
            q.put_nowait(frame)
        except asyncio.QueueFull:
            # Drop oldest message for slow clients
            try:
                q.get_nowait()
            except asyncio.QueueEmpty:
                pass
            try:
                q.put_nowait(frame)
            except asyncio.QueueFull:
                pass
