"""Data models for the CTF platform API surface."""

from __future__ import annotations

from fastapi import Query
from fastapi_pagination import LimitOffsetPage
from fastapi_pagination.customization import CustomizedPage, UseParamsFields
from fastapi_pagination.utils import disable_installed_extensions_check
from pydantic import Field

from ctfy.core.activity import ActivityDetail
from ctfy.core.constants import DEFAULT_INSTANCE_TTL, DEFAULT_NODE_CAPACITY
from ctfy.core.enums import InstanceStatus
from ctfy.core.models import CtfyModel
from ctfy.core.target import AttackSurface, ServiceEndpoint

# fastapi-pagination logs a warning when SQLAlchemy etc. aren't installed;
# we don't use those integrations, so silence the notice.
disable_installed_extensions_check()

# Custom pagination page with a higher max limit (default 50, up to 10000).
# Used by endpoints that may legitimately page through large result sets
# (scoreboard, submissions, challenges).
BigLimitOffsetPage = CustomizedPage[
    LimitOffsetPage,
    UseParamsFields(limit=Query(50, ge=1, le=10000)),
]

# ---------------------------------------------------------------------------
# Team
# ---------------------------------------------------------------------------


class TeamCreate(CtfyModel):
    name: str
    agent: str = ""
    description: str = ""


class TeamResponse(CtfyModel):
    team_id: str
    name: str
    agent: str
    description: str = ""
    token: str
    created_at: str


class TeamInfo(CtfyModel):
    team_id: str
    name: str
    agent: str
    description: str = ""
    created_at: str
    solves: int = 0
    attempts: int = 0
    # ISO timestamp of the team's most recent activity-log entry
    # (registration, submission, instance start, etc.). Empty when the
    # team has no activity yet beyond registration itself — callers can
    # fall back to ``created_at`` in that case.
    last_active_at: str = ""


# ---------------------------------------------------------------------------
# Challenge
# ---------------------------------------------------------------------------


class ChallengeInfo(CtfyModel):
    id: str
    name: str
    category: str = "web"
    difficulty: str = ""
    description: str = ""
    # Full-challenge solves: teams that captured every declared flag.
    solves_count: int = 0
    tags: list[str] = Field(default_factory=list)
    # Declared flag ids. Single-flag challenges expose ``["main"]``;
    # multi-flag challenges list each id in declaration order.
    flag_ids: list[str] = Field(default_factory=lambda: ["main"])
    # Per-flag solve counts (how many teams captured each flag). Keyed by
    # flag id. Useful for the challenge detail page's progress breakdown.
    flag_solves: dict[str, int] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Submission
# ---------------------------------------------------------------------------


class SubmissionCreate(CtfyModel):
    challenge_id: str
    flag: str


class SubmissionResponse(CtfyModel):
    submission_id: str
    correct: bool
    solve_time_s: float = 0  # seconds from instance start to correct submission
    # 1 = first blood, 2 = second, 3 = third, 4+ = regular solve.
    # 0 when incorrect or when the team already had a prior correct solve.
    # On multi-flag challenges this ranks solves of the specific flag that
    # was just captured (not the full-challenge rank).
    solve_rank: int = 0
    # Which flag id this submission matched, if any. ``None`` on a wrong
    # claim. On single-flag challenges this is ``"main"`` on success.
    flag_id: str | None = None
    # True iff this team has now captured every flag declared on the
    # challenge. Single-flag challenges: always equals ``correct``.
    challenge_fully_solved: bool = False


# ---------------------------------------------------------------------------
# Scoreboard
# ---------------------------------------------------------------------------


class ScoreboardEntry(CtfyModel):
    rank: int = 0
    team_id: str
    team_name: str
    agent: str = ""
    # Challenges where the team captured every declared flag. Preserved
    # for parity with the legacy single-flag scoreboard.
    solved: int = 0
    # Total individual flags captured across all challenges. Primary
    # scoreboard metric now that multi-flag challenges exist — rewards
    # partial progress (e.g. foothold without root).
    flags_solved: int = 0
    attempts: int = 0
    last_solve_at: str = ""
    # Most recent activity of any kind. Distinct from ``last_solve_at`` —
    # a team may be actively attempting without a solve, and the UI
    # wants to show that they're not idle.
    last_active_at: str = ""


class ChallengeFlagStats(CtfyModel):
    """Per-flag aggregate for one challenge (for the detail page)."""

    flag_id: str
    solves_count: int = 0


class ChallengeStats(CtfyModel):
    challenge_id: str
    name: str = ""
    category: str = ""
    difficulty: str = ""
    # Teams that captured every declared flag on this challenge.
    solves_count: int = 0
    total_attempts: int = 0
    success_rate: float = 0.0
    # Per-flag breakdown. Single-flag challenges have a single entry with
    # ``flag_id == "main"`` and ``solves_count == solves_count`` above.
    flag_stats: list[ChallengeFlagStats] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Admin dashboard aggregates
# ---------------------------------------------------------------------------


class AdminSolveCell(CtfyModel):
    """One cell in the team × challenge solve matrix.

    Unsolved cells are emitted when the team has at least one submission
    against the challenge (``attempts > 0``) so the UI can distinguish
    "tried and failed" from "never attempted".
    """

    team_id: str
    challenge_id: str
    solved: bool = False
    solved_at: str = ""
    solve_time_s: float = 0.0
    attempts: int = 0
    # True when this team is the first (fastest) solver of the challenge.
    first_blood: bool = False


class AdminSolveMatrixTeam(CtfyModel):
    team_id: str
    name: str = ""
    solved: int = 0


class AdminSolveMatrixChallenge(CtfyModel):
    challenge_id: str
    name: str = ""
    category: str = ""
    difficulty: str = ""
    solves_count: int = 0


class AdminSolveMatrix(CtfyModel):
    """Team × challenge solve matrix for the admin dashboard.

    Rows (teams) and columns (challenges) pre-sorted — teams by solve count
    desc, challenges by category → difficulty — so the frontend can render
    the grid verbatim without re-sorting. Cells are sparse: only teams that
    have at least attempted a challenge contribute a row there.
    """

    teams: list[AdminSolveMatrixTeam] = Field(default_factory=list)
    challenges: list[AdminSolveMatrixChallenge] = Field(default_factory=list)
    cells: list[AdminSolveCell] = Field(default_factory=list)


class AdminOverviewCounts(CtfyModel):
    total: int = 0
    healthy: int = 0


class AdminOverview(CtfyModel):
    """Single aggregate payload for the admin landing page."""

    nodes: AdminOverviewCounts = Field(default_factory=AdminOverviewCounts)
    capacity: int = 0
    running_instances: int = 0
    teams_total: int = 0
    solves_total: int = 0
    solves_today: int = 0


# ---------------------------------------------------------------------------
# Activity Log
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Nodes (multi-node cluster)
# ---------------------------------------------------------------------------


class NodeRegister(CtfyModel):
    url: str  # e.g. "http://node1:8100"
    display_name: str  # required; operators pick a human-readable label
    capacity: int = DEFAULT_NODE_CAPACITY
    labels: dict[str, str] = Field(default_factory=dict)  # optional metadata


class NodeInfo(CtfyModel):
    node_id: str
    url: str
    display_name: str = ""
    capacity: int = 0
    running: int = 0
    healthy: bool = True
    last_heartbeat: str = ""
    labels: dict[str, str] = Field(default_factory=dict)
    # Latest resource sample reported on heartbeat (0–100).
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    disk_percent: float = 0.0


class NodePatch(CtfyModel):
    """Body for ``PATCH /admin/nodes/{node_id}``.

    Fields are optional — absent fields keep their current value.
    display_name is the common case; labels allow adding/replacing the
    full dict (partial label edits need a second round-trip).
    """

    display_name: str | None = None
    labels: dict[str, str] | None = None


class NodeHeartbeat(CtfyModel):
    """Body for ``POST /nodes/heartbeat``.

    Node reports its live counts + resource utilisation on every beat.
    All metrics are 0–100; 0 is a safe default for the first beat where
    psutil hasn't had a prior sample to diff against.
    """

    node_id: str
    running: int = 0
    capacity: int = 50
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    disk_percent: float = 0.0


class NodeRegisterResponse(NodeInfo):
    """Registration response carries the node's bearer token (plaintext).

    Returned exactly once, at registration. The same token is used in
    both directions:

    * **node→platform** (heartbeat, deregister) — node presents it as
      the Bearer; platform looks the row up by comparing plaintexts.
    * **platform→node** (start/stop/status) — platform presents the
      same plaintext on every call; node verifies against its in-memory
      copy.

    Re-registration rotates the token. The node never persists it on
    disk; "restart = re-register = fresh credential".
    """

    node_token: str = ""


class CreateInviteRequest(CtfyModel):
    """Body for ``POST /api/v1/nodes/invites``.

    ``ttl_seconds`` controls how long the minted registration token stays
    valid — it cannot be renewed, only re-created.
    """

    ttl_seconds: int = Field(default=3600, ge=60, le=7 * 24 * 3600)


class CreateInviteResponse(CtfyModel):
    """Plaintext registration token is returned **exactly once** here.

    Subsequent ``GET /nodes/invites`` lookups only expose metadata; the
    plaintext is never persisted — only ``token_hash`` is stored.
    """

    invite_id: str
    registration_token: str
    expires_at: str


class NodeInviteInfo(CtfyModel):
    """Admin-facing summary (``GET /nodes/invites``). No token fields."""

    invite_id: str
    created_at: str
    expires_at: str
    status: str  # "active" | "consumed" | "expired"
    consumed_by_node_id: str = ""


class ClusterInfo(CtfyModel):
    """Returned by ``GET /cluster-info``.

    Provides the bits the ``ctfy server invite`` CLI and admin UI wizard
    need to build a runnable join command. The *registration token* is
    minted separately via ``POST /nodes/invites`` — it isn't on this
    payload because cluster info is queried speculatively by the UI on
    every admin dashboard load, and we never want to hand an invite
    token to a page that didn't explicitly ask for one.
    """

    platform_url: str
    node_image: str


# ---------------------------------------------------------------------------
# Activity Log
# ---------------------------------------------------------------------------


class Activity(CtfyModel):
    """A single activity event in the platform log."""

    id: str = ""
    timestamp: str = ""
    event: str  # See PlatformEvent enum for valid values
    team_id: str = ""
    team_name: str = ""
    challenge_id: str = ""
    # Who triggered this event — surfaced on the public feed so admins
    # can filter by actor and auditors can trace back. Values mirror
    # the ActivityState fields in core.state.models.
    actor_id: str = ""
    actor_name: str = ""
    actor_type: str = ""
    detail: ActivityDetail = Field(default_factory=ActivityDetail)


# ---------------------------------------------------------------------------
# Instance
# ---------------------------------------------------------------------------


class InstanceInfo(CtfyModel):
    instance_id: str
    challenge_id: str = ""
    team_id: str = ""
    # Worker node currently hosting this instance. Empty only for
    # records created before nodes were tracked (legacy).
    node_id: str = ""
    name: str = ""
    category: str = ""
    difficulty: str = ""
    status: str = InstanceStatus.STARTING
    started_at: float = 0.0
    ttl: int = 0
    expires_at: float = 0.0
    services: list[ServiceEndpoint] = Field(default_factory=list)


class InstanceRecordInfo(CtfyModel):
    """Archived-instance summary for the admin history list.

    Mirrors :class:`ctfy.core.state.models.InstanceRecord` minus the heavy
    fields (``spec``, ``surface``). Used by ``GET /admin/instance-records``.
    """

    instance_id: str
    team_id: str = ""
    challenge_id: str = ""
    node_id: str = ""
    name: str = ""
    category: str = ""
    difficulty: str = ""
    status: str = ""
    stop_reason: str = ""
    error: str = ""
    started_at: float = 0.0
    stopped_at: float = 0.0
    duration_s: float = 0.0
    ttl: int = 0
    solved: bool = False
    attempts: int = 0


class InstanceRecordInfoDetail(InstanceRecordInfo):
    """Full record — includes spec + surface, returned by detail endpoint."""

    spec: dict = Field(default_factory=dict)
    surface: AttackSurface | None = None
    artifact_dir: str = ""


class InstanceRecordArtifacts(CtfyModel):
    """Per-artifact presence flags + counts for an archived instance.

    Returned alongside the full :class:`InstanceRecord` from
    ``GET /admin/instance-records/{id}`` so the admin UI can show
    ``Manifest / Events / Submissions / Container log`` tabs at a glance
    without a round-trip per tab.
    """

    has_manifest: bool = False
    has_container_log: bool = False
    events_count: int = 0
    submissions_count: int = 0


class InstanceRecordDetail(CtfyModel):
    record: InstanceRecordInfoDetail
    artifacts: InstanceRecordArtifacts = Field(default_factory=InstanceRecordArtifacts)


class InstanceStatusResponse(CtfyModel):
    instance_id: str
    status: str = InstanceStatus.STARTING
    attack_surface: AttackSurface | None = None
    error: str | None = None
    sandbox_network: str = ""
    proxy_gateway: str = ""
    cert_volume: str = ""


class StartResponse(CtfyModel):
    instance_id: str
    status: str = InstanceStatus.STARTING


class StopResponse(CtfyModel):
    status: str = InstanceStatus.STOPPED
    instance_id: str


class RenewResponse(CtfyModel):
    status: str = "renewed"
    instance_id: str
    expires_at: float


class VerifyFlagRequest(CtfyModel):
    claimed_flag: str


class VerifyFlagResponse(CtfyModel):
    correct: bool
    # Which flag on the challenge the claim matched. ``None`` on a wrong
    # claim or legacy single-flag deployments where the client doesn't
    # care which id hit. Populated only on correct claims.
    flag_id: str | None = None


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------


class HealthResponse(CtfyModel):
    status: str = "ok"
    hostname: str = ""
    running_instances: int = 0
    capacity: int = 0


# ---------------------------------------------------------------------------
# Meta — server-wide snapshot consumed by the bottom status bar. Public,
# so the numbers must stay within what the individual public endpoints
# (``/challenges``, ``/teams``, ``/nodes``, ``/scoreboard``) already expose.
# ---------------------------------------------------------------------------


class MetaResponse(CtfyModel):
    version: str = ""
    started_at_ts: float = 0.0
    server_time_ts: float = 0.0
    challenges_total: int = 0
    teams_total: int = 0
    nodes_total: int = 0
    nodes_healthy: int = 0
    running_instances: int = 0
    solves_total: int = 0


# ---------------------------------------------------------------------------
# Error envelope
# ---------------------------------------------------------------------------


class ErrorResponse(CtfyModel):
    """Unified shape for every HTTP 4xx/5xx body produced by platform routes.

    ``detail`` mirrors the pre-existing field (so SDK / CLI / frontend code
    that reads ``data.detail`` keeps working); ``code`` adds a stable
    machine-readable identifier derived from the raising exception class,
    and ``timestamp`` is server-side UTC in ISO 8601 — useful when
    correlating client-side and server-side logs.
    """

    code: str
    detail: str
    timestamp: str


# ---------------------------------------------------------------------------
# Start Request
# ---------------------------------------------------------------------------


class StartRequest(CtfyModel):
    challenge_id: str
    proxy_output_dir: str | None = None
    ttl: int = DEFAULT_INSTANCE_TTL
