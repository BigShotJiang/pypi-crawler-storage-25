"""Background instance lifecycle — platform-side polling after a node-side start.

Extracted from ``routes/instances.py`` so the route layer stays thin (route
declaration + validation) while the multi-step "dispatch, poll, reconcile,
emit" flow lives in one focused module.

Invariant expected by :func:`start_instance_async`: the caller must have
already written an :class:`InstanceState` with ``status=STARTING`` and a
non-empty ``node_id``. All other inputs (challenge, team, flags, ttl, spec)
are read back from state.
"""

from __future__ import annotations

import time
from urllib.parse import urlparse

from ctfy.core.constants import REMOTE_INSTANCE_POLL_MAX
from ctfy.core.enums import InstanceStatus
from ctfy.core.log import log
from ctfy.core.state.models import InstanceRecord, InstanceState
from ctfy.core.target import AttackSurface
from ctfy.server.app_state import AppState
from ctfy.server.event_payloads import (
    InstanceErrorPayload,
    InstanceReadyPayload,
)
from ctfy.server.events import emit_event
from ctfy.server.node_ops import get_node_client

_LOOPBACK_HOSTS = frozenset({"127.0.0.1", "localhost", "0.0.0.0", "::1"})


def _rewrite_surface_hosts(surface: AttackSurface, node_url: str) -> AttackSurface:
    """Replace loopback hosts in *surface* with the node's public hostname.

    Docker binds container ports on ``0.0.0.0`` of the node, but the provider
    reports ``host="127.0.0.1"`` because it has no idea which interface the
    platform (or an end user) will reach it on. The platform knows: it
    registered the node with a ``public_url``. Rewrite here so the surface
    returned to SDK/CLI/frontend is directly dialable.
    """
    public_host = urlparse(node_url).hostname or ""
    if not public_host or public_host in _LOOPBACK_HOSTS:
        return surface
    rewritten = [
        s.model_copy(update={"host": public_host}) if s.host in _LOOPBACK_HOSTS else s
        for s in surface.services
    ]
    return surface.model_copy(update={"services": rewritten})


def start_instance_async(
    app: AppState,
    instance_id: str,
    *,
    proxy_output_dir: str | None = None,
) -> None:
    """Dispatch start to the assigned node and poll until READY / ERROR.

    Run on ``app.bg_executor``. Catches every exception and reconciles state
    so the HTTP client always sees an eventually-consistent record.
    """
    inst = app.state_backend.get_instance(instance_id)
    if inst is None or not inst.node_id:
        log.error("start_instance_async: missing instance or node", instance=instance_id)
        return
    node = app.state_backend.get_node(inst.node_id)
    if node is None:
        _reconcile_error(app, inst, RuntimeError(f"node {inst.node_id} gone"))
        return

    try:
        _dispatch_and_poll(app, inst, node, proxy_output_dir=proxy_output_dir)
    except Exception as e:
        log.error("Instance start failed", instance=instance_id, error=str(e))
        _reconcile_error(app, inst, e)


def _dispatch_and_poll(app: AppState, inst, node, *, proxy_output_dir: str | None) -> None:
    instance_id = inst.instance_id
    with get_node_client(app, node) as nc:
        nc.start_instance(
            challenge_id=inst.challenge_id,
            instance_id=instance_id,
            ttl=inst.ttl,
            flags=inst.flags,
            proxy_output_dir=proxy_output_dir,
        )
        for _ in range(REMOTE_INSTANCE_POLL_MAX):
            sd = nc.get_status(instance_id)
            status = sd.get("status")
            if status == InstanceStatus.READY:
                raw = sd.get("attack_surface") or None
                surface = AttackSurface.model_validate(raw) if raw else None
                if surface is not None:
                    surface = _rewrite_surface_hosts(surface, node.url)
                _reconcile_ready(app, inst, node, surface)
                return
            if status == InstanceStatus.ERROR:
                raise RuntimeError(sd.get("error", "unknown"))
            time.sleep(2)
    raise TimeoutError("Remote instance not ready after poll timeout")


def _reconcile_ready(app: AppState, inst, node, surface: AttackSurface | None) -> None:
    """Flip state to READY and emit event."""
    instance_id = inst.instance_id
    current = app.state_backend.get_instance(instance_id)
    if current:
        updated = current.model_copy(update={"status": InstanceStatus.READY, "surface": surface})
        app.state_backend.put_instance(instance_id, updated, ttl=current.ttl)

    # Reconciliation happens from the async worker after the team's POST
    # /instances initiated the lifecycle. The event is still an outcome
    # of the team's request, so attribute it back to that team.
    emit_event(
        app,
        InstanceReadyPayload(
            team_id=inst.team_id,
            challenge_id=inst.challenge_id,
            instance_id=instance_id,
            node_id=node.node_id,
        ),
        actor_id=inst.team_id,
        actor_name=inst.team_id,
        actor_type="team",
    )


def _reconcile_error(app: AppState, inst, exc: Exception) -> None:
    """Persist ERROR status and emit event. Tolerates disappearing instance rows."""
    instance_id = inst.instance_id
    current = app.state_backend.get_instance(instance_id)
    if current:
        updated = current.model_copy(update={"status": InstanceStatus.ERROR, "error": str(exc)})
        app.state_backend.put_instance(instance_id, updated, ttl=current.ttl)
    emit_event(
        app,
        InstanceErrorPayload(
            team_id=inst.team_id,
            challenge_id=inst.challenge_id,
            instance_id=instance_id,
            node_id=inst.node_id or "",
            error=str(exc),
        ),
        actor_id=inst.team_id,
        actor_name=inst.team_id,
        actor_type="team",
    )
    archive_instance_record(
        app,
        current or inst,
        status=InstanceStatus.ERROR,
        stop_reason="error",
        error=str(exc),
    )


def archive_instance_record(
    app: AppState,
    inst: InstanceState,
    *,
    status: str,
    stop_reason: str,
    error: str = "",
    fetch_container_logs: bool = True,
) -> InstanceRecord:
    """Persist a terminal instance snapshot to the archive.

    Called from every terminal path (DELETE, admin stop-all, reaper,
    health-check fail, reconcile_error, auto-stop-after-solve). Captures:

      * a row in the ``instance_records`` table (survives TTL + restart),
      * ``{archive}/{id}/instance.json`` with the full record + spec,
      * ``{archive}/{id}/container.log`` (fetched from the node while the
        container still exists — skipped if *fetch_container_logs* is False
        or the node call fails).

    Swallows exceptions: a failing archive must never prevent the caller
    from completing its lifecycle transition.
    """
    try:
        now = time.time()
        # Per-flag solves: "solved" = team captured every flag on the
        # challenge. ``solved_flags`` preserves partial progress in the
        # archive so the history UI can show "2/3 flags" even after the
        # live InstanceState is gone.
        solved_flags: list[str] = []
        challenge_flag_ids = list((inst.flags or {}).keys())
        if inst.team_id and inst.challenge_id and challenge_flag_ids:
            for fid in challenge_flag_ids:
                try:
                    if app.state_backend.get_solve(
                        inst.team_id, inst.challenge_id, fid
                    ):
                        solved_flags.append(fid)
                except Exception:
                    continue
        fully_solved = bool(challenge_flag_ids) and len(solved_flags) == len(
            challenge_flag_ids
        )
        attempts = 0
        if inst.team_id and inst.challenge_id:
            try:
                attempts = len(
                    app.state_backend.list_submissions(
                        team_id=inst.team_id, challenge_id=inst.challenge_id
                    )
                )
            except Exception:
                attempts = 0

        archive_dir = ""
        archive = app.instance_archive
        if archive is not None and inst.instance_id:
            try:
                archive_dir = str(archive.dir_for(inst.instance_id))
            except OSError as exc:
                log.warning(
                    "Failed to create archive dir",
                    instance=inst.instance_id,
                    error=str(exc),
                )

        record = InstanceRecord(
            instance_id=inst.instance_id,
            challenge_id=inst.challenge_id,
            team_id=inst.team_id,
            node_id=inst.node_id,
            name=inst.name,
            category=inst.category,
            difficulty=inst.difficulty,
            status=status or inst.status,
            stop_reason=stop_reason,
            surface=inst.surface,
            spec=inst.spec or {},
            error=error or inst.error,
            started_at=inst.started_at,
            stopped_at=now,
            duration_s=round(max(0.0, now - inst.started_at), 3) if inst.started_at else 0.0,
            ttl=inst.ttl,
            solved=fully_solved,
            solved_flags=solved_flags,
            attempts=attempts,
            artifact_dir=archive_dir,
        )

        try:
            app.state_backend.archive_instance(record)
        except Exception as exc:
            log.error(
                "Failed to archive instance record to DB",
                instance=inst.instance_id,
                error=str(exc),
            )

        if archive is not None and inst.instance_id:
            archive.write_manifest(record, inst.spec or {})

        if fetch_container_logs and inst.node_id and archive is not None and inst.instance_id:
            _fetch_and_write_container_logs(app, inst.instance_id, inst.node_id)

        return record
    except Exception as exc:
        log.error(
            "archive_instance_record unexpected failure",
            instance=getattr(inst, "instance_id", ""),
            error=str(exc),
        )
        return InstanceRecord(instance_id=getattr(inst, "instance_id", ""))


def _fetch_and_write_container_logs(app: AppState, instance_id: str, node_id: str) -> None:
    archive = app.instance_archive
    if archive is None:
        return
    node = app.state_backend.get_node(node_id)
    if node is None:
        return
    try:
        with get_node_client(app, node) as nc:
            logs = nc.get_container_logs(instance_id)
    except Exception as exc:
        log.warning(
            "Container log fetch failed",
            instance=instance_id,
            node=node_id,
            error=str(exc),
        )
        return
    if logs:
        archive.write_container_logs(instance_id, logs)
