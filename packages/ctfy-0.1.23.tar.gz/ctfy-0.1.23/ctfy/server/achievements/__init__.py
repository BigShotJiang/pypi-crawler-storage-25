"""Achievement / badge system.

Teams earn badges for fun behaviors (time-of-day, speed, persistence,
platform contributions). The system is event-driven — evaluators hook
into :func:`ctfy.server.events.emit_event` and check whether the current
event qualifies the acting team for one or more badges.

Modules:

- :mod:`catalog` — static list of every ``Achievement`` the platform
  knows about. Frontend reads this via ``GET /achievements/catalog``.
- :mod:`engine` — evaluator registry + ``evaluate()`` dispatcher that
  runs when an event is emitted.
- :mod:`rules` — one file per achievement rule; each registers its
  predicate against one or more ``PlatformEvent`` values.

Importing :mod:`rules` at app startup is enough to register every rule —
do not call the evaluator before ``ctfy.server.achievements.rules`` has
been imported.
"""
