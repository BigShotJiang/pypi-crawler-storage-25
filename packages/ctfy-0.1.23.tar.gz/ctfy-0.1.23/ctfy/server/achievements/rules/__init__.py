"""Rule modules — importing this package registers every predicate.

Add a new rule by creating a module here and using the
``@register(PlatformEvent.X)`` decorator from
:mod:`ctfy.server.achievements.engine`. Then import the module in the
list below so it runs at app startup.
"""

from __future__ import annotations

# Import each rule module so their @register(...) decorators fire.
from ctfy.server.achievements.rules import (  # noqa: F401
    agent_rules,
    flag_correct_rules,
    flag_wrong_rules,
    team_registered_rules,
)
