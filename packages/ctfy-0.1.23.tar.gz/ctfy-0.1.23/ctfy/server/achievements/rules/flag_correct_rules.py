"""Rules keyed on FLAG_CORRECT.

A single FLAG_CORRECT event can unlock multiple badges — each rule is
evaluated independently and the engine grants each one idempotently.

FLAG_CORRECT fires on every correct flag claim (including partial hits on
multi-flag challenges). Rules that only make sense once the challenge is
fully solved gate on ``payload.challenge_fully_solved``.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import TYPE_CHECKING

from ctfy.core.enums import PlatformEvent
from ctfy.core.state.models import TeamState
from ctfy.server.achievements.engine import RuleResult, register

if TYPE_CHECKING:
    from ctfy.server.app_state import AppState
    from ctfy.server.event_payloads import EventPayload


# Thresholds — changing these is how you'd tweak the badge difficulty
# without touching predicate logic.
FLASH_SOLVER_SECONDS = 60.0
DECATHLETE_UNIQUE_SOLVES = 10
CENTURION_TOTAL_SUBMISSIONS = 100
UNICORN_FIRST_BLOODS = 3
NIGHT_OWL_HOURS = range(0, 6)  # [00:00, 06:00)
EARLY_BIRD_HOURS = range(5, 7)  # [05:00, 07:00)
LUCKY_GUESSER_ATTEMPTS = 1
SISYPHUS_WRONG_COUNT = 50


def _ctx(payload: "EventPayload") -> dict:
    """Common context fields rules attach to an unlock record."""
    return {
        "challenge_id": payload.challenge_id,
        "solve_time_s": getattr(payload, "solve_time_s", 0.0),
    }


@register(PlatformEvent.FLAG_CORRECT)
def first_blood_team(
    app: "AppState", payload: "EventPayload", team: TeamState
) -> RuleResult | None:
    """Unlocked on the team's first-ever correct solve.

    We read ``list_solves`` rather than relying on a counter because the
    submissions route writes the Solve row before emit_event fires, so
    len == 1 for the very first solve.
    """
    solves = app.state_backend.list_solves(team_id=team.team_id)
    if len(solves) == 1:
        return RuleResult(achievement_id="first_blood_team", context=_ctx(payload))
    return None


@register(PlatformEvent.FLAG_CORRECT)
def fastest_man(app: "AppState", payload: "EventPayload", team: TeamState) -> RuleResult | None:
    """First team globally to capture the flag that just landed.

    ``count_solves_for_flag`` already includes this team's solve when
    we're called (add_solve happens before the event), so the first
    capturer sees count == 1. On single-flag challenges this is
    equivalent to "first team to solve the challenge".
    """
    if not payload.challenge_id:
        return None
    flag_id = getattr(payload, "flag_id", "") or "main"
    count = app.state_backend.count_solves_for_flag(payload.challenge_id, flag_id)
    if count == 1:
        return RuleResult(achievement_id="fastest_man", context=_ctx(payload))
    return None


@register(PlatformEvent.FLAG_CORRECT)
def night_owl(app: "AppState", payload: "EventPayload", team: TeamState) -> RuleResult | None:
    if datetime.now(timezone.utc).hour in NIGHT_OWL_HOURS:
        return RuleResult(achievement_id="night_owl", context=_ctx(payload))
    return None


@register(PlatformEvent.FLAG_CORRECT)
def early_bird(app: "AppState", payload: "EventPayload", team: TeamState) -> RuleResult | None:
    if datetime.now(timezone.utc).hour in EARLY_BIRD_HOURS:
        return RuleResult(achievement_id="early_bird", context=_ctx(payload))
    return None


@register(PlatformEvent.FLAG_CORRECT)
def weekend_warrior(app: "AppState", payload: "EventPayload", team: TeamState) -> RuleResult | None:
    """Solves on both Saturday AND Sunday of the same ISO week.

    We maintain two per-ISO-week counters — "solved_sat:{year}-{week}"
    and "solved_sun:{year}-{week}" — incrementing once per day-of-week
    via dedup keys. When both are non-zero for the current week the
    team has bagged the weekend.
    """
    now = datetime.now(timezone.utc)
    weekday = now.weekday()  # Mon=0 .. Sun=6
    if weekday not in (5, 6):
        return None
    year, week, _ = now.isocalendar()
    day_key = f"weekend_solve:{year}-{week}:{weekday}"
    week_sat = f"weekend_solve:{year}-{week}:5"
    week_sun = f"weekend_solve:{year}-{week}:6"
    # Dedup: mark this day once. A second solve on the same day is a
    # no-op from the counter's perspective.
    if app.state_backend.get_counter(team.team_id, day_key) == 0:
        app.state_backend.bump_counter(team.team_id, day_key, 1)
    if (
        app.state_backend.get_counter(team.team_id, week_sat) > 0
        and app.state_backend.get_counter(team.team_id, week_sun) > 0
    ):
        return RuleResult(achievement_id="weekend_warrior", context=_ctx(payload))
    return None


@register(PlatformEvent.FLAG_CORRECT)
def flash_solver(app: "AppState", payload: "EventPayload", team: TeamState) -> RuleResult | None:
    solve_time = getattr(payload, "solve_time_s", 0.0) or 0.0
    if 0 < solve_time < FLASH_SOLVER_SECONDS:
        return RuleResult(achievement_id="flash_solver", context=_ctx(payload))
    return None


@register(PlatformEvent.FLAG_CORRECT)
def decathlete(app: "AppState", payload: "EventPayload", team: TeamState) -> RuleResult | None:
    if len(app.state_backend.list_solves(team_id=team.team_id)) >= DECATHLETE_UNIQUE_SOLVES:
        return RuleResult(achievement_id="decathlete")
    return None


@register(PlatformEvent.FLAG_CORRECT)
def centurion(app: "AppState", payload: "EventPayload", team: TeamState) -> RuleResult | None:
    total = len(app.state_backend.list_submissions(team_id=team.team_id))
    if total >= CENTURION_TOTAL_SUBMISSIONS:
        return RuleResult(achievement_id="centurion")
    return None


@register(PlatformEvent.FLAG_CORRECT)
def completionist(app: "AppState", payload: "EventPayload", team: TeamState) -> RuleResult | None:
    """Fully solved every challenge the platform currently knows about.

    "Fully solved" = every declared flag on every challenge captured.
    Count using ``iter_specs`` so we compare against the live catalog
    (not a frozen number). Empty catalogs don't qualify.
    """
    specs = list(app.spec_reader.iter_specs())
    if not specs:
        return None
    solves = app.state_backend.list_solves(team_id=team.team_id)
    captured: dict[str, set[str]] = {}
    for s in solves:
        captured.setdefault(s.challenge_id, set()).add(s.flag_id)
    for spec in specs:
        required = set(spec.flags)
        if not required <= captured.get(spec.id, set()):
            return None
    return RuleResult(achievement_id="completionist")


@register(PlatformEvent.FLAG_CORRECT)
def unicorn(app: "AppState", payload: "EventPayload", team: TeamState) -> RuleResult | None:
    """Claim first-blood on 3 distinct flags across the catalog.

    We re-check globally: for each of this team's solves, ask whether
    this team was the first to capture that specific flag. Under
    multi-flag challenges each flag has its own first-blood, so a team
    fastest on several flags of the same challenge can earn this.
    """
    solves = app.state_backend.list_solves(team_id=team.team_id)
    firsts = 0
    for s in solves:
        if app.state_backend.count_solves_for_flag(s.challenge_id, s.flag_id) == 1:
            firsts += 1
            if firsts >= UNICORN_FIRST_BLOODS:
                return RuleResult(achievement_id="unicorn")
    return None


@register(PlatformEvent.FLAG_CORRECT)
def lucky_guesser(app: "AppState", payload: "EventPayload", team: TeamState) -> RuleResult | None:
    """Solved on a single submission — the Solve row stores attempts=N
    where N includes the winning submission itself, so a clean first-
    try solve lands as attempts == 1. On multi-flag challenges the
    check applies to the just-captured flag.
    """
    flag_id = getattr(payload, "flag_id", "") or "main"
    solve = app.state_backend.get_solve(team.team_id, payload.challenge_id, flag_id)
    if solve and solve.attempts == LUCKY_GUESSER_ATTEMPTS:
        return RuleResult(achievement_id="lucky_guesser", context=_ctx(payload))
    return None


@register(PlatformEvent.FLAG_CORRECT)
def sisyphus(app: "AppState", payload: "EventPayload", team: TeamState) -> RuleResult | None:
    """≥50 wrong flags on this challenge before the eventual solve.

    The wrong-rules module maintains per-(team, challenge) counters on
    every FLAG_WRONG. At solve time we read the counter: if it's ≥50
    the team earned it. We intentionally don't reset it — if they go
    back and fail+solve another challenge the same way, that still
    counts.
    """
    if not payload.challenge_id:
        return None
    wrongs = app.state_backend.get_counter(team.team_id, f"wrong_on:{payload.challenge_id}")
    if wrongs >= SISYPHUS_WRONG_COUNT:
        return RuleResult(
            achievement_id="sisyphus",
            context={**_ctx(payload), "wrong_count": wrongs},
        )
    return None


@register(PlatformEvent.FLAG_CORRECT)
def kamikaze_correct(
    app: "AppState", payload: "EventPayload", team: TeamState
) -> RuleResult | None:
    """Flag submitted within 5 seconds of instance start."""
    solve_time = getattr(payload, "solve_time_s", 0.0) or 0.0
    if 0 < solve_time <= 5.0:
        return RuleResult(achievement_id="kamikaze", context=_ctx(payload))
    return None
