"""Rules keyed on TEAM_REGISTERED — welcome badges."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ctfy.core.enums import PlatformEvent
from ctfy.core.state.models import TeamState
from ctfy.server.achievements.engine import RuleResult, register

if TYPE_CHECKING:
    from ctfy.server.app_state import AppState
    from ctfy.server.event_payloads import EventPayload


@register(PlatformEvent.TEAM_REGISTERED)
def welcome_aboard(app: "AppState", payload: "EventPayload", team: TeamState) -> RuleResult | None:
    return RuleResult(achievement_id="welcome_aboard")
