"""Rules keyed on FLAG_WRONG — the "you messed up" badges.

Also maintains the ``wrong_on:{challenge_id}`` counter that the
Sisyphus rule in :mod:`flag_correct_rules` reads at solve time.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ctfy.core.enums import PlatformEvent
from ctfy.core.state.models import TeamState
from ctfy.server.achievements.engine import RuleResult, register

if TYPE_CHECKING:
    from ctfy.server.app_state import AppState
    from ctfy.server.event_payloads import EventPayload


# The literal-flag easter egg that unlocks ``secret_handshake``.
SECRET_FLAG = "flag{hello_world}"

KAMIKAZE_WINDOW_S = 5.0


@register(PlatformEvent.FLAG_WRONG)
def _bump_wrong_counter(
    app: "AppState", payload: "EventPayload", team: TeamState
) -> RuleResult | None:
    """Side-effect only — bumps the per-challenge wrong-streak counter.

    Returns None so the engine never grants anything off this rule; it
    exists purely to feed the Sisyphus predicate at solve time.
    """
    if payload.challenge_id:
        app.state_backend.bump_counter(team.team_id, f"wrong_on:{payload.challenge_id}", 1)
    return None


@register(PlatformEvent.FLAG_WRONG)
def kamikaze_wrong(app: "AppState", payload: "EventPayload", team: TeamState) -> RuleResult | None:
    """Submitting (even wrongly!) within 5s of instance start earns it.

    FlagWrongPayload carries solve_time_s as "elapsed since start" on
    every wrong submission — the submissions route computes it on the
    correct path, but for wrong flags the SubmissionState row stores
    0.0. We recover the elapsed time off the live instance.
    """
    instance_id = getattr(payload, "instance_id", "") or ""
    if not instance_id:
        return None
    instance = app.state_backend.get_instance(instance_id)
    if not instance or not instance.started_at:
        return None
    import time as _time

    elapsed = _time.time() - float(instance.started_at)
    if 0 < elapsed <= KAMIKAZE_WINDOW_S:
        return RuleResult(
            achievement_id="kamikaze",
            context={"challenge_id": payload.challenge_id, "elapsed_s": round(elapsed, 2)},
        )
    return None


@register(PlatformEvent.FLAG_WRONG)
def secret_handshake(
    app: "AppState", payload: "EventPayload", team: TeamState
) -> RuleResult | None:
    """Easter egg — submit the literal secret string to unlock it.

    Read the last submission from the team's log so we don't have to
    put the claimed flag on the event payload (where it might leak via
    SSE). Submissions are appended in order so -1 is this event.
    """
    subs = app.state_backend.list_submissions(
        team_id=team.team_id, challenge_id=payload.challenge_id
    )
    if not subs:
        return None
    latest = subs[-1]
    if latest.claimed_flag.strip().lower() == SECRET_FLAG:
        return RuleResult(achievement_id="secret_handshake")
    return None
