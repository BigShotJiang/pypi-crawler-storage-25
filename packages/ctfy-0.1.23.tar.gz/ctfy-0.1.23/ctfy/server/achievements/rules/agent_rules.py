"""Rules that encourage users to connect an AI agent.

``TeamState.agent`` is a free-text identifier users set at registration
(examples seen in tests: ``claude-code``, ``cai``). These rules grant
badges when that field is populated, so there's a visible reward for
actually advertising which agent (if any) is playing.
"""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

from ctfy.core.enums import PlatformEvent
from ctfy.core.state.models import TeamState
from ctfy.server.achievements.engine import RuleResult, register

if TYPE_CHECKING:
    from ctfy.server.app_state import AppState
    from ctfy.server.event_payloads import EventPayload


AUTONOMOUS_OPERATOR_SOLVES = 5
AGENT_MARATHON_SOLVES = 25
RAPID_FIRE_COUNT = 3
RAPID_FIRE_WINDOW_S = 10 * 60  # 10 minutes — tight enough to imply automation

# A small allowlist so the Claude badge only fires on Claude-ish
# identifiers. Kept case-insensitive so teams that type "Claude-Code"
# or "claude" still qualify.
_CLAUDE_AGENT_PREFIXES = ("claude",)


@register(PlatformEvent.TEAM_REGISTERED)
def agent_online(app: "AppState", payload: "EventPayload", team: TeamState) -> RuleResult | None:
    """Instant reward for registering with a non-empty agent identifier."""
    if team.agent:
        return RuleResult(achievement_id="agent_online", context={"agent": team.agent})
    return None


@register(PlatformEvent.FLAG_CORRECT)
def autonomous_operator(
    app: "AppState", payload: "EventPayload", team: TeamState
) -> RuleResult | None:
    if not team.agent:
        return None
    if len(app.state_backend.list_solves(team_id=team.team_id)) >= AUTONOMOUS_OPERATOR_SOLVES:
        return RuleResult(
            achievement_id="autonomous_operator",
            context={"agent": team.agent},
        )
    return None


@register(PlatformEvent.FLAG_CORRECT)
def agent_marathon(app: "AppState", payload: "EventPayload", team: TeamState) -> RuleResult | None:
    if not team.agent:
        return None
    if len(app.state_backend.list_solves(team_id=team.team_id)) >= AGENT_MARATHON_SOLVES:
        return RuleResult(
            achievement_id="agent_marathon",
            context={"agent": team.agent},
        )
    return None


@register(PlatformEvent.FLAG_CORRECT)
def claude_apprentice(
    app: "AppState", payload: "EventPayload", team: TeamState
) -> RuleResult | None:
    agent = (team.agent or "").strip().lower()
    if any(agent.startswith(p) for p in _CLAUDE_AGENT_PREFIXES):
        return RuleResult(achievement_id="claude_apprentice", context={"agent": team.agent})
    return None


@register(PlatformEvent.FLAG_CORRECT)
def rapid_fire(app: "AppState", payload: "EventPayload", team: TeamState) -> RuleResult | None:
    """3 or more solves inside a 10-minute sliding window.

    SolveState.solved_at is an ISO 8601 string written by the
    submissions route. We sort newest-first and check whether the
    third-most-recent solve is still inside the window relative to
    the freshest.
    """
    solves = app.state_backend.list_solves(team_id=team.team_id)
    if len(solves) < RAPID_FIRE_COUNT:
        return None
    recent = sorted(solves, key=lambda s: s.solved_at, reverse=True)[:RAPID_FIRE_COUNT]
    try:
        stamps = [datetime.fromisoformat(s.solved_at) for s in recent if s.solved_at]
    except ValueError:
        return None
    if len(stamps) < RAPID_FIRE_COUNT:
        return None
    span = (stamps[0] - stamps[-1]).total_seconds()
    if 0 <= span <= RAPID_FIRE_WINDOW_S:
        return RuleResult(achievement_id="rapid_fire", context={"span_s": round(span, 1)})
    return None
