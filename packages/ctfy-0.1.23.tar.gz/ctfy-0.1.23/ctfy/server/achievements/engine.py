"""Evaluator registry + dispatcher.

Flow:

1. Rules self-register via :func:`register(event)` at import time.
2. :func:`evaluate` is called from inside :func:`ctfy.server.events.emit_event`
   (on the background thread pool so SQLite I/O here can't slow a
   submission response).
3. Each registered predicate inspects the payload + team state and
   returns either ``None`` (not qualifying) or a
   ``RuleResult(achievement_id, context)``.
4. :func:`grant_achievement` is idempotent — a second identical event
   is a no-op — so the downstream SSE + activity emit only fires on
   true unlocks.

Rule errors are logged and swallowed. An individual predicate must
never be able to break flag submission.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from ctfy.core.enums import PlatformEvent
from ctfy.core.log import log
from ctfy.core.state.models import TeamState

if TYPE_CHECKING:
    from ctfy.server.app_state import AppState
    from ctfy.server.event_payloads import EventPayload


@dataclass(frozen=True)
class RuleResult:
    """Returned by a rule predicate when a team qualifies for a badge."""

    achievement_id: str
    context: dict[str, Any] | None = None


# A rule takes (app, payload, team) and returns either a RuleResult or None.
Rule = Callable[["AppState", "EventPayload", TeamState], "RuleResult | None"]


_RULES: dict[PlatformEvent, list[Rule]] = {}


def register(event: PlatformEvent) -> Callable[[Rule], Rule]:
    """Register a predicate against one ``PlatformEvent``.

    Multiple rules may listen to the same event. A rule may also be
    registered on several events by stacking decorators.
    """

    def decorator(fn: Rule) -> Rule:
        _RULES.setdefault(event, []).append(fn)
        return fn

    return decorator


def _emit_unlocked(app: "AppState", team: TeamState, achievement_id: str) -> None:
    """Broadcast the ACHIEVEMENT_UNLOCKED event through the normal pipeline."""
    # Local import — events.py imports from this module's sibling (rules),
    # so keep this import inside the function to break the cycle.
    from ctfy.server.achievements.catalog import get as get_achievement
    from ctfy.server.event_payloads import AchievementUnlockedPayload
    from ctfy.server.events import emit_event

    ach = get_achievement(achievement_id)
    if ach is None:
        log.warning(
            "Unknown achievement id granted; not broadcasting",
            achievement_id=achievement_id,
            team_id=team.team_id,
        )
        return

    emit_event(
        app,
        AchievementUnlockedPayload(
            team_id=team.team_id,
            team_name=team.name,
            achievement_id=ach.id,
            achievement_name=ach.name,
            tier=ach.tier,
            secret=ach.secret,
        ),
        actor_id=team.team_id,
        actor_name=team.name or team.team_id,
        actor_type="team",
    )


def evaluate(
    app: "AppState",
    event: PlatformEvent,
    payload: "EventPayload",
    *,
    actor_type: str,
    actor_team_id: str,
) -> None:
    """Run every rule registered for ``event``; grant + broadcast unlocks.

    Only team-driven events are evaluated — system / admin / node events
    don't have a team to credit. Admin-granted badges go through the
    dedicated admin route, not this dispatcher.
    """
    if actor_type != "team" or not actor_team_id:
        return
    team = app.state_backend.get_team(actor_team_id)
    if not team:
        return

    for rule in _RULES.get(event, ()):
        try:
            result = rule(app, payload, team)
        except Exception:  # noqa: BLE001
            log.exception(
                "Achievement rule raised",
                trigger_event=event.value,
                rule=getattr(rule, "__qualname__", repr(rule)),
                team_id=team.team_id,
            )
            continue
        if result is None:
            continue
        record = app.state_backend.grant_achievement(
            team.team_id, result.achievement_id, result.context
        )
        if record is None:
            # Already unlocked — silently skip to stay idempotent.
            continue
        _emit_unlocked(app, team, result.achievement_id)


def evaluator_count(event: PlatformEvent) -> int:
    """Test helper — how many predicates are listening to ``event``."""
    return len(_RULES.get(event, ()))
