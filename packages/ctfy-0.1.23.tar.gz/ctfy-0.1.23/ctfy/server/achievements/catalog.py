"""Static catalog of every achievement the platform can grant.

The catalog is code, not DB — it's versioned with the app and fits in
one screen. Adding a badge = add an entry here + (for auto-unlock
badges) drop a rule module under :mod:`ctfy.server.achievements.rules`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

AchievementTier = Literal["bronze", "silver", "gold", "secret"]


@dataclass(frozen=True)
class Achievement:
    """One badge definition.

    ``id`` is the stable key stored in ``team_achievements.achievement_id``.
    ``icon`` is a lucide-react icon name; the frontend maps unknown names
    to a generic trophy fallback, so you can reference any icon the
    library ships without a code change on the client.

    ``secret=True`` badges are hidden in the public catalog until the
    requesting team has actually unlocked them — used for easter-egg
    badges where half the fun is the discovery.
    """

    id: str
    name: str
    description: str
    icon: str
    tier: AchievementTier = "bronze"
    secret: bool = False


# ---------------------------------------------------------------------------
# v1 catalog — order here is the order the frontend displays them in.
# ---------------------------------------------------------------------------

CATALOG: tuple[Achievement, ...] = (
    Achievement(
        id="welcome_aboard",
        name="Welcome Aboard",
        description="Register a team on the platform.",
        icon="Ship",
        tier="bronze",
    ),
    Achievement(
        id="first_blood_team",
        name="First Blood",
        description="Solve your team's very first challenge.",
        icon="Droplet",
        tier="bronze",
    ),
    Achievement(
        id="fastest_man",
        name="Fastest Man Alive",
        description="Be the first team globally to solve a challenge.",
        icon="Zap",
        tier="gold",
    ),
    Achievement(
        id="night_owl",
        name="Night Owl",
        description="Solve a challenge between midnight and 6 AM (UTC).",
        icon="Moon",
        tier="silver",
    ),
    Achievement(
        id="early_bird",
        name="Early Bird",
        description="Solve a challenge between 5 AM and 7 AM (UTC).",
        icon="Sunrise",
        tier="silver",
    ),
    Achievement(
        id="weekend_warrior",
        name="Weekend Warrior",
        description="Solve challenges on both Saturday and Sunday of the same week.",
        icon="CalendarDays",
        tier="silver",
    ),
    Achievement(
        id="flash_solver",
        name="Flash Solver",
        description="Solve a challenge in under 60 seconds from instance start.",
        icon="Timer",
        tier="gold",
    ),
    Achievement(
        id="decathlete",
        name="Decathlete",
        description="Solve 10 different challenges.",
        icon="Medal",
        tier="silver",
    ),
    Achievement(
        id="centurion",
        name="Centurion",
        description="Rack up 100 flag submissions (right or wrong).",
        icon="Swords",
        tier="silver",
    ),
    Achievement(
        id="completionist",
        name="Completionist",
        description="Solve every challenge in the catalog.",
        icon="Trophy",
        tier="gold",
    ),
    Achievement(
        id="unicorn",
        name="Unicorn",
        description="Claim first-blood on 3 different challenges.",
        icon="Sparkles",
        tier="gold",
    ),
    Achievement(
        id="lucky_guesser",
        name="Lucky Guesser",
        description="Solve a challenge on your very first submission.",
        icon="Dices",
        tier="bronze",
    ),
    Achievement(
        id="sisyphus",
        name="Sisyphus",
        description="Submit 50 wrong flags to one challenge, then finally solve it.",
        icon="Mountain",
        tier="silver",
    ),
    Achievement(
        id="kamikaze",
        name="Kamikaze",
        description="Submit a flag within 5 seconds of the instance becoming ready.",
        icon="Plane",
        tier="bronze",
    ),
    Achievement(
        id="agent_online",
        name="Agent Online",
        description="Register your team with an AI agent identifier.",
        icon="Bot",
        tier="bronze",
    ),
    Achievement(
        id="autonomous_operator",
        name="Autonomous Operator",
        description="Solve 5 challenges as an AI agent team.",
        icon="Cpu",
        tier="silver",
    ),
    Achievement(
        id="agent_marathon",
        name="Agent Marathon",
        description="Solve 25 challenges as an AI agent team.",
        icon="BatteryCharging",
        tier="gold",
    ),
    Achievement(
        id="claude_apprentice",
        name="Claude's Apprentice",
        description="Solve a challenge with Claude Code as your agent.",
        icon="Brain",
        tier="silver",
    ),
    Achievement(
        id="rapid_fire",
        name="Rapid Fire",
        description="Solve 3 challenges within 10 minutes — classic AI pace.",
        icon="Rocket",
        tier="gold",
    ),
    Achievement(
        id="bug_hunter",
        name="Bug Hunter",
        description="Reported a platform bug that was accepted.",
        icon="Bug",
        tier="gold",
    ),
    Achievement(
        id="secret_handshake",
        name="Secret Handshake",
        description="You found the hidden flag. ",
        icon="Handshake",
        tier="secret",
        secret=True,
    ),
)


_BY_ID: dict[str, Achievement] = {a.id: a for a in CATALOG}


def get(achievement_id: str) -> Achievement | None:
    return _BY_ID.get(achievement_id)


def all_achievements() -> tuple[Achievement, ...]:
    return CATALOG
