"""Background tasks: reaper, health checker, reconciler, snapshotter."""

from __future__ import annotations

import asyncio
import time

from ctfy.core.constants import HEALTH_CHECK_INTERVAL, HEARTBEAT_TIMEOUT
from ctfy.core.enums import InstanceStatus
from ctfy.core.log import log
from ctfy.core.state.models import NodeHealthSample, ScoreboardSnapshotState
from ctfy.server.app_state import AppState, now_iso
from ctfy.server.event_payloads import (
    InstanceErrorPayload,
    InstanceStoppedPayload,
    NodeUnhealthyPayload,
)
from ctfy.server.events import emit_event
from ctfy.server.instance_lifecycle import archive_instance_record
from ctfy.server.node_ops import get_node_client, stop_instance_on_node

# Every N seconds the snapshot loop captures current scoreboard state.
# 5min balances resolution (useful for 'my rank in the last hour')
# against storage (100 teams × 5 min × 1 year ≈ 10M rows — well within
# sqlite comfort, and we keep the full history forever for post-mortem).
SCOREBOARD_SNAPSHOT_INTERVAL = 300


def make_reaper_loop(app: AppState):
    """Create the TTL reaper coroutine (InMemoryBackend only)."""

    async def _reaper_loop():
        while True:
            await asyncio.sleep(HEALTH_CHECK_INTERVAL)
            expired = app.state_backend.pop_expired_instances()
            loop = asyncio.get_running_loop()
            for inst_data in expired:
                instance_id = inst_data.instance_id
                log.info("TTL expired, stopping instance", instance=instance_id)
                try:
                    archive_instance_record(
                        app,
                        inst_data,
                        status=InstanceStatus.STOPPED,
                        stop_reason="ttl_expired",
                    )
                    if inst_data.node_id:
                        node = app.state_backend.get_node(inst_data.node_id)
                        if node:
                            await loop.run_in_executor(
                                None, stop_instance_on_node, app, node, instance_id
                            )
                    emit_event(
                        app,
                        InstanceStoppedPayload(
                            team_id=inst_data.team_id,
                            challenge_id=inst_data.challenge_id,
                            instance_id=instance_id,
                            reason="ttl_expired",
                        ),
                        actor_id="system",
                        actor_name="reaper",
                        actor_type="system",
                    )
                except Exception as e:
                    log.error("Failed to stop expired instance", instance=instance_id, error=str(e))

    return _reaper_loop


def make_health_check_loop(app: AppState):
    """Create the health checker coroutine."""

    async def _health_check_loop():
        while True:
            await asyncio.sleep(HEALTH_CHECK_INTERVAL)
            loop = asyncio.get_running_loop()
            for inst_data in app.state_backend.list_instances():
                if inst_data.status != InstanceStatus.READY:
                    continue
                if not inst_data.node_id:
                    continue  # without a node there is no container to check
                instance_id = inst_data.instance_id
                node = app.state_backend.get_node(inst_data.node_id)
                if not node:
                    continue
                try:

                    def _chk(n=node, i=instance_id) -> bool:
                        with get_node_client(app, n) as nc:
                            return nc.check_health(i)

                    healthy = await loop.run_in_executor(None, _chk)
                except Exception as e:
                    log.warning("Health check error", instance=instance_id, error=str(e))
                    continue
                if not healthy:
                    inst = app.state_backend.get_instance(instance_id)
                    if inst and inst.status == InstanceStatus.READY:
                        inst = inst.model_copy(
                            update={
                                "status": InstanceStatus.ERROR,
                                "error": "Container(s) no longer running",
                            }
                        )
                        app.state_backend.put_instance(instance_id, inst)
                        log.warning("Instance marked unhealthy", instance=instance_id)
                        emit_event(
                            app,
                            InstanceErrorPayload(
                                team_id=inst.team_id,
                                challenge_id=inst.challenge_id,
                                instance_id=instance_id,
                                error="Container health check failed",
                            ),
                            actor_id="system",
                            actor_name="health-check",
                            actor_type="system",
                        )
                        archive_instance_record(
                            app,
                            inst,
                            status=InstanceStatus.ERROR,
                            stop_reason="health_check_failed",
                            error="Container health check failed",
                        )

    return _health_check_loop


def make_scoreboard_snapshot_loop(app: AppState):
    """Periodically sample the scoreboard into the history table.

    Runs on its own interval (minutes, not the seconds-scale of the
    health/reaper loops) so it never contends with user-facing polls.
    Each tick:

      1. Recompute the ranked scoreboard via the same ``compute_scoreboard``
         used by ``GET /scoreboard`` — one logical model, never drifts.
      2. Append every ranked team to ``scoreboard_snapshots`` as a
         single batch insert.
      3. Prune anything older than the retention window.

    Errors are logged and swallowed — a transient DB hiccup shouldn't
    crash the loop.
    """
    # Deferred import: scoreboard.py imports from app_state indirectly,
    # and importing it at module load time here would create a cycle.
    from ctfy.server.routes.scoreboard import compute_scoreboard

    async def _snapshot_loop():
        while True:
            await asyncio.sleep(SCOREBOARD_SNAPSHOT_INTERVAL)
            try:
                entries = compute_scoreboard(app)
                now = time.time()
                iso = now_iso()
                batch = [
                    ScoreboardSnapshotState(
                        snapshot_at=iso,
                        snapshot_at_ts=now,
                        team_id=e.team_id,
                        team_name=e.team_name,
                        rank=e.rank,
                        solved=e.solved,
                        attempts=e.attempts,
                    )
                    for e in entries
                ]
                app.state_backend.append_snapshot_batch(batch)
                # Append-only: snapshots are kept permanently so
                # post-mortems after a competition still have the full
                # rank-over-time curve. Operators who need to reclaim
                # space can drop the `scoreboard_snapshots` table
                # offline.
            except Exception as e:
                log.error("Scoreboard snapshot loop error", error=str(e))

    return _snapshot_loop


def make_reconciler_loop(app: AppState):
    """Create the reconciler coroutine."""

    async def _reconciler_loop():
        while True:
            await asyncio.sleep(HEALTH_CHECK_INTERVAL)
            try:
                now = time.time()
                for node in app.state_backend.list_nodes():
                    lb = node.last_heartbeat_ts
                    was_healthy = node.healthy
                    is_healthy = bool(lb and (now - lb) < HEARTBEAT_TIMEOUT)
                    if was_healthy and not is_healthy:
                        node = node.model_copy(update={"healthy": False})
                        app.state_backend.put_node(node.node_id, node)
                        # Record the timeout in the uptime history so a
                        # red slot shows up on the strip instead of a gap
                        # that's indistinguishable from "no data".
                        app.state_backend.append_health_sample(
                            NodeHealthSample(
                                node_id=node.node_id,
                                ts=now,
                                healthy=False,
                                cpu_percent=node.cpu_percent,
                                memory_percent=node.memory_percent,
                                disk_percent=node.disk_percent,
                            )
                        )
                        emit_event(
                            app,
                            NodeUnhealthyPayload(
                                node_id=node.node_id,
                                url=node.url,
                            ),
                            actor_id="system",
                            actor_name="reconciler",
                            actor_type="system",
                        )
                        log.warning("Node unhealthy (heartbeat timeout)", node=node.node_id)

                for inst in app.state_backend.list_instances():
                    node_id = inst.node_id
                    if not node_id:
                        continue
                    node = app.state_backend.get_node(node_id)
                    if node and not node.healthy:
                        if inst.status in (
                            InstanceStatus.STARTING,
                            InstanceStatus.READY,
                        ):
                            inst = inst.model_copy(
                                update={
                                    "status": InstanceStatus.ERROR,
                                    "error": f"Node {node_id} unhealthy",
                                }
                            )
                            app.state_backend.put_instance(inst.instance_id, inst)
                            emit_event(
                                app,
                                InstanceErrorPayload(
                                    team_id=inst.team_id,
                                    challenge_id=inst.challenge_id,
                                    instance_id=inst.instance_id,
                                    error=f"Node {node_id} unhealthy",
                                ),
                                actor_id="system",
                                actor_name="reconciler",
                                actor_type="system",
                            )
                            # Node is unhealthy → skip container-log fetch
                            # (the node isn't responding anyway). We still
                            # archive the metadata so the event is queryable.
                            archive_instance_record(
                                app,
                                inst,
                                status=InstanceStatus.ERROR,
                                stop_reason="node_unhealthy",
                                error=f"Node {node_id} unhealthy",
                                fetch_container_logs=False,
                            )
                            log.warning(
                                "Instance marked error (node unhealthy)",
                                instance=inst.instance_id,
                                node=node_id,
                            )
            except Exception as e:
                log.error("Reconciler error", error=str(e))

    return _reconciler_loop
