"""Dump the platform server's OpenAPI schema to a JSON file.

Used by ``frontend``'s ``generate:types`` pnpm script to regenerate the
TypeScript type definitions from the canonical backend schemas. Run:

    uv run python ctfy/scripts/export_openapi.py frontend/openapi.json
"""

from __future__ import annotations

import json
import sys
from pathlib import Path


def main(out_path: str) -> None:
    from ctfy.server.app import create_app

    app = create_app()
    schema = app.openapi()
    dest = Path(out_path)
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(schema, indent=2, sort_keys=True))
    print(f"Wrote OpenAPI schema → {dest}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("usage: export_openapi.py <output.json>", file=sys.stderr)
        sys.exit(2)
    main(sys.argv[1])
