"""Capture the README screenshots.

Boots ctfy in a throwaway tmpdir with a small set of demo challenges and
pre-seeded state (teams, submissions, solves, activities, achievements),
then uses Playwright to render each main page and write PNGs to
``docs/screenshots/``.

Usage:

    uv sync --extra screenshots
    uv run playwright install chromium
    uv run python -m ctfy.scripts.capture_screenshots

The generated PNGs are committed — they are project assets, not build
artifacts. Re-run whenever the UI changes enough to need fresh shots.
"""

from __future__ import annotations

import hashlib
import os
import secrets
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from ctfy.core.enums import PlatformEvent
from ctfy.core.state.models import (
    ActivityState,
    SolveState,
    SubmissionState,
    TeamState,
)
from ctfy.core.state.sqlite import SQLiteBackend

REPO_ROOT = Path(__file__).resolve().parents[2]
OUT_DIR = REPO_ROOT / "docs" / "screenshots"

PAGES: list[tuple[str, str]] = [
    ("/", "dashboard.png"),
    ("/challenges", "challenges.png"),
    ("/scoreboard", "scoreboard.png"),
    ("/activity", "activity.png"),
    ("/achievements", "achievements.png"),
]


def _now() -> tuple[str, float]:
    ts = time.time()
    iso = datetime.fromtimestamp(ts, tz=timezone.utc).isoformat(timespec="seconds")
    return iso, ts


def _pick_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _write_demo_challenges(challenges_dir: Path) -> list[dict]:
    """Lay down a handful of slim v3 challenge metadata.yaml files."""
    demo = [
        {
            "id": "WEB-001",
            "name": "SSTI in Profile Page",
            "description": "A Flask app renders user bios via Jinja2 without escaping.",
            "difficulty": "easy",
            "tags": ["web", "ssti"],
        },
        {
            "id": "PWN-004",
            "name": "Stack Smash",
            "description": "A vulnerable C binary with no stack canary. Pop a shell.",
            "difficulty": "medium",
            "tags": ["pwn", "binary"],
        },
        {
            "id": "CRYPTO-002",
            "name": "RSA with Small e",
            "description": "e=3 with a tiny message. Recover the plaintext.",
            "difficulty": "easy",
            "tags": ["crypto", "rsa"],
        },
        {
            "id": "WEB-007",
            "name": "JWT None Algorithm",
            "description": "An API trusts the alg header. Forge an admin token.",
            "difficulty": "medium",
            "tags": ["web", "jwt", "auth"],
        },
        {
            "id": "REV-003",
            "name": "Obfuscated Key Check",
            "description": "Reverse the license-key validator in the stripped binary.",
            "difficulty": "hard",
            "tags": ["rev"],
        },
    ]
    challenges_dir.mkdir(parents=True, exist_ok=True)
    for spec in demo:
        d = challenges_dir / spec["id"]
        d.mkdir(exist_ok=True)
        tags_yaml = "\n".join(f"  - {t}" for t in spec["tags"])
        (d / "metadata.yaml").write_text(
            f"name: {spec['name']}\n"
            f"description: {spec['description']}\n"
            f"difficulty: {spec['difficulty']}\n"
            f"tags:\n{tags_yaml}\n"
        )
    return demo


def _hash_token(tok: str) -> str:
    return hashlib.sha256(tok.encode()).hexdigest()


def _seed_state(db_path: Path, demo_specs: list[dict]) -> str:
    """Write demo teams/submissions/solves/activities directly to SQLite.

    Returns the plaintext team token for the `demo` team so Playwright can
    preload it into localStorage.
    """
    backend = SQLiteBackend(str(db_path))
    iso, ts = _now()

    teams = [
        ("demo", "claude-code", "t_demo"),
        ("nemo-agents", "gpt-5", "t_nemo"),
        ("recon-bot", "gemini-2.5", "t_recon"),
        ("lucky13", "human", "t_lucky"),
    ]
    team_ids: dict[str, str] = {}
    team_tokens: dict[str, str] = {}
    for name, agent, key in teams:
        tid = str(uuid.uuid4())
        token = f"pt_{secrets.token_urlsafe(32)}"
        team_ids[key] = tid
        team_tokens[key] = token
        backend.put_team(
            tid,
            TeamState(
                team_id=tid,
                name=name,
                agent=agent,
                description=f"{agent} agent" if agent != "human" else "Solo human",
                token=_hash_token(token),
                created_at=iso,
            ),
        )

    # Submissions: mix of correct + wrong across teams. Drives scoreboard
    # ranks and activity feed.
    submissions: list[tuple[str, str, bool, float]] = [
        ("t_demo", "WEB-001", True, 412.0),
        ("t_demo", "PWN-004", True, 1823.0),
        ("t_demo", "CRYPTO-002", True, 205.0),
        ("t_demo", "WEB-007", False, 0.0),
        ("t_nemo", "WEB-001", True, 631.0),
        ("t_nemo", "CRYPTO-002", True, 300.0),
        ("t_nemo", "PWN-004", False, 0.0),
        ("t_recon", "WEB-001", True, 901.0),
        ("t_recon", "REV-003", False, 0.0),
        ("t_lucky", "CRYPTO-002", True, 488.0),
        ("t_lucky", "CRYPTO-002", False, 0.0),  # earlier wrong attempt
    ]
    for i, (tkey, cid, correct, solve_s) in enumerate(submissions):
        sub_iso = datetime.fromtimestamp(
            ts - 60 * (len(submissions) - i), tz=timezone.utc
        ).isoformat(timespec="seconds")
        backend.add_submission(
            SubmissionState(
                submission_id=str(uuid.uuid4()),
                team_id=team_ids[tkey],
                challenge_id=cid,
                claimed_flag="ctfy{correct}" if correct else "ctfy{wrong}",
                correct=correct,
                flag_id="main" if correct else "",
                submitted_at=sub_iso,
                solve_time_s=solve_s,
            ),
        )
        if correct:
            backend.add_solve(
                team_ids[tkey],
                cid,
                "main",
                SolveState(
                    team_id=team_ids[tkey],
                    challenge_id=cid,
                    flag_id="main",
                    solved_at=sub_iso,
                    solve_time_s=solve_s,
                    attempts=1,
                ),
            )
        backend.add_activity(
            ActivityState(
                id=str(uuid.uuid4()),
                timestamp=sub_iso,
                event=PlatformEvent.FLAG_CORRECT.value
                if correct
                else PlatformEvent.FLAG_WRONG.value,
                team_id=team_ids[tkey],
                team_name=dict((k, n) for n, _a, k in teams)[tkey],
                challenge_id=cid,
                actor_id=team_ids[tkey],
                actor_name=dict((k, n) for n, _a, k in teams)[tkey],
                actor_type="team",
            ),
        )

    for name, _agent, key in teams:
        reg_iso = datetime.fromtimestamp(ts - 3600, tz=timezone.utc).isoformat(
            timespec="seconds"
        )
        backend.add_activity(
            ActivityState(
                id=str(uuid.uuid4()),
                timestamp=reg_iso,
                event=PlatformEvent.TEAM_REGISTERED.value,
                team_id=team_ids[key],
                team_name=name,
                actor_id=team_ids[key],
                actor_name=name,
                actor_type="team",
            ),
        )

    # Unlock a handful of achievements for the demo team so the badge page
    # renders non-empty. Pick IDs that match the catalog
    # (ctfy/server/achievements/catalog.py).
    for ach_id in (
        "welcome_aboard",
        "first_blood_team",
        "early_bird",
        "agent_online",
        "rapid_fire",
    ):
        backend.grant_achievement(team_ids["t_demo"], ach_id, context={})

    return team_tokens["t_demo"]


def _wait_for_health(url: str, timeout: float = 30.0) -> None:
    import urllib.request

    deadline = time.time() + timeout
    last_err: Exception | None = None
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=1.5) as r:
                if r.status == 200:
                    return
        except Exception as e:  # noqa: BLE001
            last_err = e
        time.sleep(0.3)
    raise RuntimeError(f"server never came up at {url}: {last_err}")


def _start_server(env: dict[str, str], port: int, log_path: Path) -> subprocess.Popen:
    ctfy_bin = shutil.which("ctfy") or str(Path(sys.executable).parent / "ctfy")
    return subprocess.Popen(
        [ctfy_bin, "server", "start", "--port", str(port)],
        env=env,
        stdout=log_path.open("wb"),
        stderr=subprocess.STDOUT,
        cwd=str(REPO_ROOT),
        preexec_fn=os.setsid,
    )


def _capture(base_url: str, team_token: str) -> None:
    from playwright.sync_api import sync_playwright

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        browser = p.chromium.launch()
        ctx = browser.new_context(viewport={"width": 1440, "height": 900})
        ctx.add_init_script(
            f"window.localStorage.setItem('teamKey', {team_token!r});"
        )
        page = ctx.new_page()
        for path, filename in PAGES:
            # The app keeps an SSE stream open, so `networkidle` never
            # settles. `domcontentloaded` + a short render delay is
            # enough for the React tree to paint.
            page.goto(f"{base_url}{path}", wait_until="domcontentloaded")
            page.wait_for_load_state("load")
            page.wait_for_timeout(1200)
            out = OUT_DIR / filename
            page.screenshot(path=str(out), full_page=False)
            size_kb = out.stat().st_size // 1024
            print(f"  {filename}: {size_kb} KB")
        browser.close()


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="ctfy-shots-"))
    challenges_dir = work / "challenges"
    db_path = work / "platform.sqlite3"
    archive_dir = work / "archive"
    archive_dir.mkdir()

    print(f"workdir: {work}")
    try:
        demo_specs = _write_demo_challenges(challenges_dir)
        team_token = _seed_state(db_path, demo_specs)

        port = _pick_port()
        env = {
            **os.environ,
            "CTFY_DB_PATH": str(db_path),
            "CTFY_CHALLENGES_DIR": str(challenges_dir),
            "CTFY_INSTANCE_ARCHIVE_DIR": str(archive_dir),
            "CTFY_ADMIN_TOKEN": secrets.token_hex(16),
            "CTFY_SERVER_HOST": "127.0.0.1",
            "CTFY_SERVER_PORT": str(port),
            # Disable auto-generated .env writes.
            "CTFY_HOST_PROJECT_ROOT": str(work),
        }
        base = f"http://127.0.0.1:{port}"
        log_path = work / "server.log"
        proc = _start_server(env, port, log_path)
        try:
            try:
                _wait_for_health(f"{base}/api/v1/health")
            except Exception:
                print("---- server.log ----", file=sys.stderr)
                try:
                    print(log_path.read_text(), file=sys.stderr)
                except OSError:
                    pass
                raise
            print(f"server up at {base}; capturing...")
            _capture(base, team_token)
        finally:
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
    finally:
        shutil.rmtree(work, ignore_errors=True)

    print(f"done — {len(PAGES)} screenshots in {OUT_DIR}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
