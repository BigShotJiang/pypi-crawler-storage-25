一、CTF 类 Benchmark（评测智能体解题能力）
1. NYU CTF Bench

论文：NeurIPS 2024
GitHub：NYU-LLM-CTF/NYU_CTF_Bench
包含 200 道来自 CSAW CTF 竞赛的挑战，涵盖 6 个类别：Web、Pwn、Forensics、Rev、Crypto、Misc，全部 Docker 化部署。 GitHub
提供了配套的自动化解题框架，支持 LLM 工具调用。 arXiv
有公开排行榜，适合横向对比不同智能体。

2. Cybench

论文：ICLR 2025（斯坦福团队）
GitHub：andyzorigin/cybench
包含来自 4 个真实 CTF 比赛的 40 个任务，并为每个任务引入了子任务分解，支持更细粒度的评估。 arXiv评测了 8 个主流模型。
最难的任务人类团队需要 24 小时 54 分钟才能完成。 arXiv
特色：有人类基线对比数据，引入了 Reflection/Planning/Thought 结构化评估。

3. XBOW Validation Benchmarks

104 个 CTF 风格的 Docker 挑战，已成为业界评测 AI 渗透测试智能体的事实标准。 GitHub
Shannon Lite 在 XBOW 上得分 96.15%（100/104） GitHub，PentestGPT 得分 86.5%（90/104） GitHub，方便直接对比。


二、真实 CVE / 漏洞利用类 Benchmark（评测真实世界攻击能力）
4. CVE-Bench

论文：ICML 2025（UIUC + US AI Safety Institute）
GitHub：uiuc-kang-lab/cve-bench
基于真实的高危 CVE，在沙箱中让智能体攻击存在漏洞的 Web 应用，模拟真实条件。 OpenReview
SOTA 智能体的成功率约 13% OpenReview，说明难度很高，区分度好。
支持 Docker 和 Kubernetes 沙箱。

5. BountyBench

论文：NeurIPS 2025（斯坦福团队）
官网：bountybench.github.io
包含 25 个复杂的真实代码库系统和 40 个 Bug Bounty 任务，覆盖 OWASP Top 10 中的 9 项。 Bountybench
分为 Detect（发现）、Exploit（利用）、Patch（修补）三个任务维度，用美元赏金金额量化结果。 Bountybench
智能体在 Kali Linux 容器中运行，可连接服务器和数据库。

6. CyberGym

论文：arXiv 2025（Dawn Song 团队）
官网：cybergym.io
目前规模最大，包含 1,507 个真实漏洞实例，来自 188 个开源软件项目，比其他 benchmark 大 7 倍以上。 arXiv
主要任务是根据漏洞描述和代码库生成 PoC 测试来复现漏洞。 arXiv


三、渗透测试全流程 Benchmark（评测端到端渗透能力）
7. AutoPenBench

论文：arXiv 2024
GitHub：lucagioacchini/auto-pen-bench
包含 33 个渗透测试任务，分为 in-vitro（简单）和 real-world（复杂）两个难度级别。 arXiv
基于 Docker 虚拟化，每个任务分解为里程碑（命令里程碑 + 阶段里程碑），可细粒度追踪智能体在信息收集、渗透入侵、漏洞发现、提权、夺旗各阶段的表现。 GitHub
全自主智能体的成功率仅 21%，人工辅助模式为 64%。 ADS

8. AI-Pentest-Benchmark

GitHub：isamu-isozaki/AI-Pentest-Benchmark
基于 VulnHub 虚拟机的渗透测试 benchmark，提供标准化的攻击步骤 Google Sheet 用于评估。 GitHub
相对简单，适合入门级评测。


四、综合元 Benchmark（集成多种评测维度）
9. CAIBench（Cybersecurity AI Benchmark）

论文：arXiv 2025（Alias Robotics）
一个"元 benchmark"框架，集成了 5 个评测类别、覆盖 10,000+ 测试实例：Jeopardy-style CTF、攻防 CTF、Cyber Range 演练、知识 benchmark 和隐私评估。 arXiv
实验发现：LLM 在知识题上约 70% 成功率，但在多步对抗场景中降至 20-40%。 arXiv
评测了 CAI、Claude Code、OpenAI Codex、Gemini CLI、Qwen Coder 等主流框架。


五、知识 / 静态评估类（补充参考）
10. SecBench — 44,823 道选择题 + 3,087 道简答题，覆盖中英双语，评估 LLM 的安全知识储备。 GitHub
11. AutoAdvExBench — 评估 LLM 能否自主突破 75 个对抗样本防御，介于 CTF 和真实安全研究之间。 arXiv
