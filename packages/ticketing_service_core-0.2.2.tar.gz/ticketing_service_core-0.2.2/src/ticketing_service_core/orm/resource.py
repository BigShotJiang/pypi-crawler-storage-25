"""
Declarative Base for all service models
"""

from sqlalchemy import Integer, BigInteger
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, declared_attr

class Resource(DeclarativeBase):
    """
    Definition of declarative base class
    """

    @declared_attr.directive
    def id(cls) -> Mapped[int]: # pylint: disable=no-self-argument
        return mapped_column(BigInteger, primary_key=True, autoincrement=False)

    @declared_attr.directive
    def created(cls) -> Mapped[int]: # pylint: disable=no-self-argument
        return mapped_column(Integer, nullable=False)

    @declared_attr.directive
    def modified(cls) -> Mapped[int]: # pylint: disable=no-self-argument
        return mapped_column(Integer, nullable=False)
