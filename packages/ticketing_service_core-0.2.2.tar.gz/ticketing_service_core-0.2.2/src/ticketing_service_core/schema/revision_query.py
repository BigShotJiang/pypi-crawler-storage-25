"""
RevisionQuery Message Schema
"""
from .query_fields import query_fields

RevisionQuery = {
	"type": "object",
	"allOf": [
		{"$ref": "#/definitions/query_fields"}
	],
	"properties": {
		"criteria": {
			"type": "object",
			"properties": {
				"id": {"type": "string", "pattern": "^([=!]|->)([0-9]{14},?)+$"},
				"resource": {"type": "string", "pattern": "^([=!]|->)([0-9]{14},?)+$"},
				"type": {"type": "string", "pattern": "^([=!]|->)([A-Za-z]+,?)+$"},
				"status": {"type": "string", "pattern": "^([=!]|->)([A-Za-z]+,?)+$"},
				"current": {"type": "string", "pattern": "^=(true|false)$"}
			},
    		"unevaluatedProperties": False
		}
	},
	"required": ["criteria"],
    "unevaluatedProperties": False,
    "definitions": {
        "query_fields": query_fields
    }
}
