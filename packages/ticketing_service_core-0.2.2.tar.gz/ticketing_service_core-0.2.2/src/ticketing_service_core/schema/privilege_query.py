"""
PrivilegeQuery Message Schema
"""
from .query_fields import query_fields

PrivilegeQuery = {
	"type": "object",
	"allOf": [
		{"$ref": "#/definitions/query_fields"}
	],
	"properties": {
		"criteria": {
			"type": "object",
			"properties": {
				"id": {"type": "string", "pattern": "^([=!]|->)([0-9]{14},?)+$"},
				"user": {"type": "string", "pattern": "^[=!(\\->)](.+,?)+$"},
				"type": {"type": "string", "pattern": "^[=!](host|event)$"},
				"resource": {"type": "string", "pattern": "^([=!]|->)([0-9]{14},?)+$"},
				"role": {"type": "string", "pattern": "^[=!(\\->)](\\w+,?)+$"},
				"permissions": {"type": "string", "pattern": "^<\\-\\w+$"}
			},
    		"unevaluatedProperties": False
		}
	},
	"required": ["criteria"],
    "unevaluatedProperties": False,
    "definitions": {
        "query_fields": query_fields
    }
}
