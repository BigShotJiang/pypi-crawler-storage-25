"""
Category Message Schema
"""

Region = {
	"type": "object",
	"properties": {
		"id": {"type": "number"},
		"name": {"type": "string"},
		"country": {"type": "string"},
		"city": {"type": "string"},
		"district": {"type": "string"}
	},
    "unevaluatedProperties": False,
  	"required": ["name", "country"]
}
