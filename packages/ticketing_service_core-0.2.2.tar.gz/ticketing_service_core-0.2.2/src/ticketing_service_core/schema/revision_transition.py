"""
RevisionTransition Message Schema
"""

RevisionTransition = {
	"type": "object",
	"properties": {
		"revision": {"type": "number"},
		"transition": {"type": "string", "enum": ["submit", "approve", "reject", "schedule"]},
		"note": {"type": "string"},
		"user": {"type": "string"}
	},
    "unevaluatedProperties": False,
  	"required": ["revision", "transition", "note", "user"]
}
