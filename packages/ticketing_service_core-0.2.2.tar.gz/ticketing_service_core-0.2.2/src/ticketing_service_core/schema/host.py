"""
Venue Message Schema
"""

Host = {
	"type": "object",
	"properties": {
		"id": {"type": "number"},
		"name": {"type": "string"},
		"bio": {"type": "string"},
		"contact": {"type": "string"},
		"email": {"type": "string", "format": "email"},
		"phone": {"type": "string"},
		"website": {"type": "string", "format": "uri"},
		"country": {"type": "string"},
		"firstAddressLine": {"type": "string"},
		"secondAddressLine": {"type": "string"},
		"city": {"type": "string"},
		"district": {"type": "string"},
		"businessNo": {"type": "string"}
	},
    "unevaluatedProperties": False,
  	"required": ["name", "contact", "email"]
}
