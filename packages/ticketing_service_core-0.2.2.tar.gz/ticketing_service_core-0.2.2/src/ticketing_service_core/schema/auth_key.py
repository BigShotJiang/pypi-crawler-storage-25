"""
Authentication Key Message Schema
"""

AuthKey = {
	"type": "object",
	"properties": {
		"key": {"type": "string"},
		"token": {"type": "boolean"}
	},
    "unevaluatedProperties": False,
  	"required": ["key"]
}
