"""
HostQuery Message Schema
"""
from .query_fields import query_fields

EventQuery = {
	"type": "object",
	"allOf": [
		{"$ref": "#/definitions/query_fields"}
	],
	"properties": {
		"criteria": {
			"type": "object",
			"properties": {
				"id": {"type": "string", "pattern": "^([=!]|->)([0-9]{14},?)+$"},
				"title": {"type": "string", "pattern": "^[=!].+"},
				"host": {"type": "string", "pattern": "^([=!]|->)([0-9]{14},?)+$"},
				"venue": {"type": "string", "pattern": "^([=!]|->)([0-9]{14},?)+$"},
				"category": {"type": "string", "pattern": "^([=!]|->)([0-9]{14},?)+$"},
				"subcategory": {"type": "string", "pattern": "^([=!]|->)([0-9]{14},?)+$"},
				"start": {"type": "string", "pattern": "^[><]\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}$"},
				"end": {"type": "string", "pattern": "^[><]\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}$"},
				"before": {"type": "string", "pattern": "^[=]\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}$"},
				"after": {"type": "string", "pattern": "^[=]\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}$"},
				"public": {"type": "string", "pattern": "^=(true|false)$"}
			},
    		"unevaluatedProperties": False
		}
	},
	"required": ["criteria"],
    "unevaluatedProperties": False,
    "definitions": {
        "query_fields": query_fields
    }
}
