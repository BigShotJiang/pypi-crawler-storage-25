"""
Empty Message Schema
"""

Empty = {
	"type": "object",
    "unevaluatedProperties": False
}
