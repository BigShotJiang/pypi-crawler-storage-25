"""
Category Message Schema
"""

File = {
	"type": "object",
	"properties": {
		"name": {"type": "string"},
		"data": {"type": "string", format: "base64"}
	},
    "unevaluatedProperties": False,
  	"required": ["name"]
}
