"""
Category Message Schema
"""

Identifier = {
	"type": "object",
	"properties": {
		"id": {"type": "string"}
	},
    "unevaluatedProperties": False,
  	"required": ["id"]
}
