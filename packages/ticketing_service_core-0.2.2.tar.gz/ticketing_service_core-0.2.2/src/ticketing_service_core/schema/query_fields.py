"""
Schema for shared query fields
"""
query_fields = {
	"properties": {
		"sort": {
			"type": "object",
			"properties": {
				"field": {"type": "string"},
				"order": {"type": "string", "enum": ["asc", "desc"]}
			}
		},
		"pagination": {
			"type": "object",
			"properties": {
				"page": {"type": "integer"},
				"results": {"type": "integer"}
			}
		}
	}
}
