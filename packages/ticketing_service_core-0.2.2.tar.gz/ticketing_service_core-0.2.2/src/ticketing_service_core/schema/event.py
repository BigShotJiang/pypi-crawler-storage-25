"""
Venue Message Schema
"""
from .category import Category

Event = {
	"type": "object",
	"properties": {
		"id": {"type": "number"},
		"title": {"type": "string"},
		"description": {"type": "string"},
		"type": {"type": "string", "enum": ['Standard', 'Registration']},
		"public": {"type": "boolean"},
		"start": {"type": "string", "format": "date-time"},
		"end": {"type": "string", "format": "date-time"},
		"host": {"type": "string", "pattern": "^[0-9]{14}$"},
		"venue": {"type": "string", "pattern": "^[0-9]{14}$"},
		"category": {
			"type": ["string", "object"],
			"anyOf": [
				{"type": "string", "pattern": "^[0-9]{14}$"},
				{"$ref": "#/definitions/Category"}
			]
		},
		"subcategory": {
			"type": ["string", "object"],
			"anyOf": [
				{"type": "string", "pattern": "^[0-9]{14}$"},
				{"$ref": "#/definitions/Category"}
			]
		},
		"disclaimer": {"type": "string"},
		"tags": {"type": "array", "items": {"type": "string"}},
		"published": {"type": "string", "format": "date-time"},
		"popularity": {"type": "number"},
		"banner": {"type": "string", "format": "base64"},
		"thumbnail": {"type": "string", "format": "base64"}
	},
    "unevaluatedProperties": False,
  	"required": [
  		"title", "description", "type", "public", "start", "end",
  		"venue", "category", "subcategory"
  	],
    "definitions": {
        "Category": Category
    }
}
