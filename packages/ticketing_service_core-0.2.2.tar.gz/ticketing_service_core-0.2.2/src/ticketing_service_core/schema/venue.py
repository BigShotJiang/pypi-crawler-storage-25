"""
Venue Message Schema
"""
Venue = {
	"type": "object",
	"properties": {
		"id": {"type": "number"},
		"name": {"type": "string"},
		"region": {"type": "string", "pattern": "^[0-9]{14}$"},
		"latitude": {"type": "number"},
		"longitude": {"type": "number"},
		"address": {"type": "string"}
	},
    "unevaluatedProperties": False,
  	"required": ["name", "region", "latitude", "longitude", "address"]
}
