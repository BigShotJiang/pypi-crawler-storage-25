"""
Category Message Schema
"""

Category = {
  "type": "object",
  "properties": {
    "id": { "type": "number" },
    "name": { "type": "string" },
    "subcategories": {
      "type": "array",
      "items": {
        "anyOf": [
          {"type": "string"},
          {
            "type": "object",
            "properties": {
              "id": { "type": "number" },
              "name": { "type": "string" },
              "subcategories": {
                "type": "array",
                "items": {"type": "string"}
              }
            },
            "unevaluatedProperties": False,
            "required": ["name"]
          }
        ]
      }
    }
  },
  "unevaluatedProperties": False,
  "required": ["name"]
}