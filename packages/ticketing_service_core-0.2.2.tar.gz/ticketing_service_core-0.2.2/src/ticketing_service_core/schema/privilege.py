"""
Privilege Message Schema
"""

Privilege = {
	"type": "object",
	"properties": {
		"id": {"type": "number"},
		"user": {"type": "string", "format": "email"},
		"type": {"type": "string", "enum": ['host','event']},
		"resource": {"type": "string", "pattern": "^[0-9]{14}$"},
		"role": {"type": "string"}
	},
    "unevaluatedProperties": False,
  	"required": ["role"]
}
