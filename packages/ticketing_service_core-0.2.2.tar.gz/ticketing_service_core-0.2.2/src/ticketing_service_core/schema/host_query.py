"""
HostQuery Message Schema
"""
from .query_fields import query_fields

HostQuery = {
	"type": "object",
	"allOf": [
		{"$ref": "#/definitions/query_fields"}
	],
	"properties": {
		"criteria": {
			"type": "object",
			"properties": {
				"id": {"type": "string", "pattern": "^([=!]|->)([0-9]{14},?)+$"},
				"name": {"type": "string", "pattern": "^[=!].+"},
				"country": {"type": "string", "pattern": "^[=!].+"}
			},
    		"unevaluatedProperties": False
		}
	},
	"required": ["criteria"],
    "unevaluatedProperties": False,
    "definitions": {
        "query_fields": query_fields
    }
}
