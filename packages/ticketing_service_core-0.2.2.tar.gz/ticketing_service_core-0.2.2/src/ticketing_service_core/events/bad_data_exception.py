"""
consumer_exception Module
"""

from .consumer_exception import ConsumerException

class BadDataException(ConsumerException):
    """
    A BadDataException should be raised by any consumers that encounter an invalid
    value in the received message body.
    """
