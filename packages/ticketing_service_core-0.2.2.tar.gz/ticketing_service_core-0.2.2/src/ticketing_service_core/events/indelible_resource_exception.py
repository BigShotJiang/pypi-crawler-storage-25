"""
resource_indelible_exception Module
"""

from .consumer_exception import ConsumerException

class IndelibleResourceException(ConsumerException):
    """
    A IndelibleResourceException should be raised by any consumers that are unable
    to delete a resource due to foreign key constraints.
    """
