"""
resource_immutable_exception Module
"""

from .consumer_exception import ConsumerException

class ImmutableResourceException(ConsumerException):
    """
    A ImmutableResourceException should be raised by any consumers that are unable
    to change or delete a resource because it is immutable.
    """
