"""
consumer_exception Module
"""

from .consumer_exception import ConsumerException

class DuplicateResourceException(ConsumerException):
    """
    A DuplicateResourceException should be raised by any consumers that encounter a
    uniqueness violation when attempting to create or update a model. 
    """
