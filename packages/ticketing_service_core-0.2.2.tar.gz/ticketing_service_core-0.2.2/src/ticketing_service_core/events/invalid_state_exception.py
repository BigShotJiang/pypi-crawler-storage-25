"""
InvalidStateException Module
"""

from .consumer_exception import ConsumerException

class InvalidStateException(ConsumerException):
    """
    A InvalidStateException should be raised by any consumers that are unable
    to perform an operation on a resource due to its current state.
    """
