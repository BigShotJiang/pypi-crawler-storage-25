from __future__ import annotations

from mycel_sdk import Client

from mycel_cli.config import config_client_kwargs, load_owner_config
from mycel_cli.identity_store import IdentityStore


def ensure_role_chat_member(group_id: str, local_id: str) -> None:
    identity = IdentityStore.from_env().get_identity(local_id)
    user_id = str(identity.get("user_id") or "").strip()
    if not user_id:
        raise RuntimeError(f"identity {local_id!r} has no user_id")

    owner = load_owner_config()
    Client(**config_client_kwargs(owner)).chats.add_member(group_id, user_id)
