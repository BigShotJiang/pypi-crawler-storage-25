"""Per-group task store backed by Mycel chat tasks."""

from __future__ import annotations

from typing import Any

from mycel_cli.config import config_client_kwargs, load_owner_config
from mycel_sdk import Client

_DIRECT_PATCH_KEYS = {
    "status",
    "subject",
    "description",
    "active_form",
    "owner",
    "blocks",
    "blocked_by",
}
_GROUP_METADATA_KEYS: tuple[str, ...] = ()


def _client() -> Client:
    cfg = load_owner_config()
    return Client(**config_client_kwargs(cfg))


def _task_from_backend(payload: dict[str, Any]) -> dict[str, Any]:
    metadata = dict(payload.get("metadata") or {})
    task = {
        "id": str(payload["id"]),
        "subject": str(payload.get("subject") or ""),
        "description": str(payload.get("description") or ""),
        "status": str(payload.get("status") or "pending"),
        "owner": str(payload.get("owner") or ""),
        "blocks": list(payload.get("blocks") or []),
        "blockedBy": list(payload.get("blockedBy") or []),
    }
    for key in _GROUP_METADATA_KEYS:
        if key in metadata:
            task[key] = metadata[key]
    return task


def _metadata_from_task(task: dict[str, Any]) -> dict[str, Any]:
    return {key: task[key] for key in _GROUP_METADATA_KEYS if key in task}


def create_task(
    group_id: str,
    *,
    subject: str,
    description: str = "",
    status: str = "proposed",
    owner: str = "",
    blocks: list[str] | None = None,
    blocked_by: list[str] | None = None,
) -> dict[str, Any]:
    task = _client().chats.create_task(
        group_id,
        subject=subject,
        description=description,
        status=status,
        owner=owner or None,
        blocks=blocks,
        blocked_by=blocked_by,
        metadata={},
    )
    if not isinstance(task, dict):
        raise RuntimeError("backend did not return a task payload")
    return _task_from_backend(task)


def get_task(group_id: str, task_id: str) -> dict[str, Any] | None:
    task = _client().chats.get_task(group_id, task_id)
    if task is None:
        return None
    if not isinstance(task, dict):
        raise RuntimeError("backend did not return a task payload")
    return _task_from_backend(task)


def list_tasks(group_id: str) -> list[dict[str, Any]]:
    tasks = _client().chats.list_tasks(group_id)
    if tasks is None:
        return []
    return [_task_from_backend(task) for task in tasks]


def update_task(group_id: str, task_id: str, patch: dict[str, Any]) -> dict[str, Any]:
    current = get_task(group_id, task_id)
    if current is None:
        raise ValueError(f"Task '{task_id}' 不存在")

    metadata = _metadata_from_task(current)
    metadata_changed = False
    direct: dict[str, Any] = {}
    for key, value in patch.items():
        if key == "blockedBy":
            direct["blocked_by"] = value
        elif key in _DIRECT_PATCH_KEYS:
            direct[key] = value
        elif key in _GROUP_METADATA_KEYS:
            metadata[key] = value
            metadata_changed = True

    kwargs = dict(direct)
    if metadata_changed:
        kwargs["metadata"] = metadata
    task = _client().chats.update_task(
        group_id,
        task_id,
        **kwargs,
    )
    if not isinstance(task, dict):
        raise RuntimeError("backend did not return an updated task payload")
    return _task_from_backend(task)


def update_tasks(
    group_id: str,
    task_ids: list[str],
    patch: dict[str, Any],
) -> list[dict[str, Any]]:
    return [update_task(group_id, task_id, patch) for task_id in task_ids]


def remove_task(group_id: str, task_id: str) -> bool:
    _client().chats.delete_task(group_id, task_id)
    return True
