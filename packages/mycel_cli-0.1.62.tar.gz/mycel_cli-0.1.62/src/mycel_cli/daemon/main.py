from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from collections.abc import Callable
from typing import Any

from mycel_sdk import Client

from mycel_cli.config import client_kwargs, effective_proxy
from mycel_cli.identity_store import IdentityStore
from mycel_cli.daemon.ipc import serve as serve_ipc
from mycel_cli.daemon.subscriber import run_loop as run_subscriber_loop
from mycel_cli.daemon.task_status import write_task_status


SubscriberLoop = Callable[..., None]
ClientFactory = Callable[..., Any]
GroupLoop = Callable[[], None]
IpcServer = Callable[..., None]


@dataclass
class SubscriberHandle:
    thread: threading.Thread
    stop_event: threading.Event


def run_daemon(
    *,
    client_factory: ClientFactory = Client,
    subscriber_loop: SubscriberLoop = run_subscriber_loop,
    ipc_server: IpcServer = serve_ipc,
    group_loop: GroupLoop | None = None,
    identity_reconcile_interval: float = 1.0,
) -> None:
    stop_event = threading.Event()
    _start_ipc_thread(stop_event=stop_event, ipc_server=ipc_server)
    subscribers: dict[str, SubscriberHandle] = {}
    _reconcile_subscriber_threads(
        client_factory=client_factory,
        subscriber_loop=subscriber_loop,
        subscribers=subscribers,
    )
    if group_loop is None:
        from mycel_cli.group._workflow.loop import run_group_workflow_loop as group_loop

    group_failed = threading.Event()
    group_task = _start_group_thread(group_loop=group_loop, failed_event=group_failed)
    next_identity_reconcile_at = time.time() + identity_reconcile_interval
    try:
        while not stop_event.is_set():
            now = time.time()
            if now >= next_identity_reconcile_at:
                _reconcile_subscriber_threads(
                    client_factory=client_factory,
                    subscriber_loop=subscriber_loop,
                    subscribers=subscribers,
                )
                next_identity_reconcile_at = now + identity_reconcile_interval
            group_task.join(timeout=0.25)
            if group_task.is_alive():
                continue
            if group_failed.is_set():
                # @@@daemon-owner - keep IPC/subscribers alive so status can expose the failed sibling task.
                stop_event.wait(0.25)
                continue
            break
    finally:
        stop_event.set()
        _stop_subscriber_threads(subscribers, set())


def _reconcile_subscriber_threads(
    *,
    client_factory: ClientFactory,
    subscriber_loop: SubscriberLoop,
    subscribers: dict[str, SubscriberHandle],
) -> list[threading.Thread]:
    identities = IdentityStore.from_env().identities()
    live_local_ids = set(identities)
    _stop_subscriber_threads(subscribers, live_local_ids)
    return _start_missing_subscriber_threads(
        client_factory=client_factory,
        subscriber_loop=subscriber_loop,
        subscribers=subscribers,
        identities=identities,
    )


def _start_missing_subscriber_threads(
    *,
    client_factory: ClientFactory,
    subscriber_loop: SubscriberLoop,
    subscribers: dict[str, SubscriberHandle],
    identities: dict[str, dict[str, Any]],
) -> list[threading.Thread]:
    threads: list[threading.Thread] = []
    for local_id, identity in sorted(identities.items()):
        if local_id in subscribers:
            continue
        base_url = str(identity["base_url"])
        proxy = effective_proxy()["proxy"]
        client = client_factory(
            **client_kwargs(
                auth_token=str(identity["auth_token"]),
                base_url=base_url,
                proxy=str(proxy) if proxy else None,
            )
        )
        stop_event = threading.Event()
        thread = threading.Thread(
            target=subscriber_loop,
            kwargs={
                "client": client,
                "local_id": local_id,
                "backend_base_url": base_url,
                "stop_event": stop_event,
            },
            name=f"mycel-subscriber-{local_id}",
            daemon=True,
        )
        thread.start()
        subscribers[local_id] = SubscriberHandle(thread=thread, stop_event=stop_event)
        threads.append(thread)
    return threads


def _stop_subscriber_threads(
    subscribers: dict[str, SubscriberHandle],
    live_local_ids: set[str],
) -> None:
    for local_id, handle in list(subscribers.items()):
        if local_id in live_local_ids:
            continue
        handle.stop_event.set()
        handle.thread.join(timeout=1)
        if not handle.thread.is_alive():
            subscribers.pop(local_id, None)


def _start_ipc_thread(
    *, stop_event: threading.Event, ipc_server: IpcServer
) -> threading.Thread:
    ready_event = threading.Event()
    thread = threading.Thread(
        target=ipc_server,
        kwargs={"stop_event": stop_event, "ready_event": ready_event},
        name="mycel-daemon-ipc",
        daemon=True,
    )
    thread.start()
    if not ready_event.wait(1.0):
        raise RuntimeError("daemon IPC server did not start")
    return thread


def _start_group_thread(
    *, group_loop: GroupLoop, failed_event: threading.Event
) -> threading.Thread:
    thread = threading.Thread(
        target=_run_group_loop,
        kwargs={"group_loop": group_loop, "failed_event": failed_event},
        name="mycel-group-loop",
        daemon=True,
    )
    thread.start()
    return thread


def _run_group_loop(*, group_loop: GroupLoop, failed_event: threading.Event) -> None:
    try:
        group_loop()
    except Exception as exc:
        failed_event.set()
        write_task_status(
            "group-loop",
            {
                "state": "fatal",
                "group": "main",
                "last_tick_at": time.time(),
                "error_type": exc.__class__.__name__,
                "last_error": str(exc),
            },
        )


if __name__ == "__main__":
    run_daemon()
