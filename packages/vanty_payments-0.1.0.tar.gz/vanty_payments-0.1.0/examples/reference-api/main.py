from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from scalar_fastapi import DocumentDownloadType, Layout, Theme, get_scalar_api_reference

from vanty_payments import PaymentsKitSettings, mount_payments_router

LOCAL_DATA_DIR = Path(__file__).resolve().parents[2] / ".local"
LOCAL_DATA_DIR.mkdir(exist_ok=True)

settings = PaymentsKitSettings(
    database_url=f"sqlite://{LOCAL_DATA_DIR / 'reference-api.db'}",
    stripe_test_secret_key="sk_test_example",
    stripe_webhook_secret="whsec_example",
)
app = FastAPI(
    title="Vanty Payments Reference API",
    summary="Reference API for the vanty-payments package",
    description="Stripe-backed billing API with local model sync.",
    docs_url=None,
    redoc_url=None,
)
kit = mount_payments_router(app, settings=settings)


@asynccontextmanager
async def lifespan(_: FastAPI):
    await kit.init_orm(generate_schemas=True)
    try:
        yield
    finally:
        await kit.close_orm()


app.router.lifespan_context = lifespan

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5173", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    return {
        "name": "vanty-payments reference api",
        "docs_url": "/docs",
        "health_url": "/health",
    }


@app.get("/docs", include_in_schema=False)
async def scalar_docs():
    return get_scalar_api_reference(
        title="Vanty Payments Reference",
        openapi_url=app.openapi_url,
        theme=Theme.DEEP_SPACE,
        layout=Layout.MODERN,
        hide_models=False,
        dark_mode=True,
        hide_dark_mode_toggle=True,
        document_download_type=DocumentDownloadType.BOTH,
    )


@app.get("/health")
async def health():
    return {"status": "ok"}
