from __future__ import annotations

from typing import Any, Literal
from uuid import UUID

from pydantic import AliasPath, BaseModel, ConfigDict, Field


class CheckoutLineItem(BaseModel):
    price_id: str
    quantity: int = 1


class CreateCheckoutSessionRequest(BaseModel):
    email: str | None = None
    name: str | None = None
    stripe_customer_id: str | None = None
    user_reference: str | None = None
    organization_reference: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    mode: Literal["subscription", "payment"] = "subscription"
    line_items: list[CheckoutLineItem] = Field(default_factory=list)
    success_url: str | None = None
    cancel_url: str | None = None
    client_reference_id: str | None = None


class CreateBillingPortalSessionRequest(BaseModel):
    stripe_customer_id: str | None = None
    user_reference: str | None = None
    organization_reference: str | None = None
    return_url: str | None = None


class CheckoutSessionResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    stripe_id: str
    url: str | None = None
    mode: str
    status: str | None = None
    payment_status: str | None = None
    customer_stripe_id: str | None = Field(default=None, validation_alias=AliasPath("customer", "stripe_id"))


class BillingPortalSessionResponse(BaseModel):
    url: str


class CheckoutSessionsResponse(BaseModel):
    sessions: list[CheckoutSessionResponse]
