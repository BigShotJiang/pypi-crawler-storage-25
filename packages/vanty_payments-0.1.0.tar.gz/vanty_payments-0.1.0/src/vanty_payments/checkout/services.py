from __future__ import annotations

from fastapi import HTTPException, status

from vanty_payments.core.context import ServiceContext
from vanty_payments.customers.services import CustomerService
from vanty_payments.db.models import StripeCheckoutSession
from vanty_payments.sync.services import SyncService


class CheckoutService:
    def __init__(
        self,
        context: ServiceContext,
        customer_service: CustomerService,
        sync_service: SyncService,
    ) -> None:
        self.context = context
        self.customer_service = customer_service
        self.sync_service = sync_service

    async def create_checkout_session(
        self,
        *,
        email: str | None,
        name: str | None,
        stripe_customer_id: str | None,
        user_reference: str | None,
        organization_reference: str | None,
        metadata: dict[str, str],
        mode: str,
        line_items: list[dict[str, int | str]],
        success_url: str | None,
        cancel_url: str | None,
        client_reference_id: str | None,
    ) -> StripeCheckoutSession:
        if not line_items:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                detail="At least one line item is required",
            )
        if mode not in {"payment", "subscription"}:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                detail="mode must be 'subscription' or 'payment'",
            )

        customer = await self.customer_service.resolve_customer(
            stripe_customer_id=stripe_customer_id,
            user_reference=user_reference,
            organization_reference=organization_reference,
        )
        if customer is None:
            if not email:
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                    detail="email is required when no customer exists",
                )
            customer = await self.customer_service.bootstrap_customer(
                email=email,
                name=name,
                user_reference=user_reference,
                organization_reference=organization_reference,
                metadata=metadata,
            )

        session_data = self.context.stripe_client.create_checkout_session(
            mode=mode,
            customer=customer.stripe_id,
            line_items=line_items,
            success_url=success_url or self.context.settings.checkout_success_url,
            cancel_url=cancel_url or self.context.settings.checkout_cancel_url,
            client_reference_id=client_reference_id,
            metadata=metadata,
        )
        session = await self.sync_service.sync_checkout_session(session_data)
        self.context.events.record(
            "payments.checkout_session.created",
            {
                "checkout_session_stripe_id": session.stripe_id,
                "customer_stripe_id": customer.stripe_id,
                "mode": session.mode,
            },
        )
        return session

    async def create_billing_portal_session(
        self,
        *,
        stripe_customer_id: str | None,
        user_reference: str | None,
        organization_reference: str | None,
        return_url: str | None,
    ) -> str:
        customer = await self.customer_service.require_customer(
            stripe_customer_id=stripe_customer_id,
            user_reference=user_reference,
            organization_reference=organization_reference,
        )
        session = self.context.stripe_client.create_billing_portal_session(
            customer=customer.stripe_id,
            return_url=return_url or self.context.settings.billing_portal_return_url,
        )
        self.context.events.record(
            "payments.billing_portal_session.created",
            {
                "customer_stripe_id": customer.stripe_id,
                "url": session["url"],
            },
        )
        return session["url"]

    async def list_sessions(self) -> list[StripeCheckoutSession]:
        return await StripeCheckoutSession.all().prefetch_related("customer").order_by("-created_at")
