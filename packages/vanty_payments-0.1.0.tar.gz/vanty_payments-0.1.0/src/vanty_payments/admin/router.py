from __future__ import annotations

from typing import TYPE_CHECKING
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel

from vanty_payments.admin.schemas import (
    AdminCreditGrantRequest,
    IntegrationStatusResponse,
    MeterCreateRequest,
    MeterResponse,
    MeterUpdateRequest,
    ProductConfigResponse,
    ProductConfigUpdateRequest,
)
from vanty_payments.billing.schemas import CreditLedgerEntryResponse
from vanty_payments.core.schemas import MessageResponse
from vanty_payments.fastapi.dependencies import get_payments_kit


class ProductSyncResponse(BaseModel):
    created: int = 0
    updated: int = 0
    total: int = 0

if TYPE_CHECKING:
    from vanty_payments.kit import PaymentsKit

admin_router = APIRouter(tags=["admin"])


# ---------------------------------------------------------------------------
# Products
# ---------------------------------------------------------------------------


@admin_router.get("/products", response_model=list[ProductConfigResponse])
async def list_product_configs(
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> list[ProductConfigResponse]:
    configs = await payments_kit.admin_service.list_product_configs()
    return [ProductConfigResponse.model_validate(c) for c in configs]


@admin_router.post("/products/sync-from-stripe", response_model=ProductSyncResponse)
async def sync_products_from_stripe(
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> dict:
    result = await payments_kit.admin_service.sync_products_from_stripe()
    return result


@admin_router.get("/products/{config_id}", response_model=ProductConfigResponse)
async def get_product_config(
    config_id: UUID,
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> ProductConfigResponse:
    config = await payments_kit.admin_service.get_product_config(config_id)
    if config is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product config not found")
    return ProductConfigResponse.model_validate(config)


@admin_router.post("/products/{config_id}", response_model=ProductConfigResponse)
async def update_product_config(
    config_id: UUID,
    payload: ProductConfigUpdateRequest,
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> ProductConfigResponse:
    config = await payments_kit.admin_service.update_product_config(
        config_id,
        payload.model_dump(exclude_none=True),
    )
    if config is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product config not found")
    return ProductConfigResponse.model_validate(config)


# ---------------------------------------------------------------------------
# Meters
# ---------------------------------------------------------------------------


@admin_router.get("/meters", response_model=list[MeterResponse])
async def list_meters(
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> list[MeterResponse]:
    meters = await payments_kit.admin_service.list_meters()
    return [MeterResponse.model_validate(m) for m in meters]


@admin_router.post("/meters", response_model=MeterResponse)
async def create_meter(
    payload: MeterCreateRequest,
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> MeterResponse:
    meter = await payments_kit.admin_service.create_meter(payload.model_dump())
    return MeterResponse.model_validate(meter)


@admin_router.post("/meters/load-defaults", response_model=MessageResponse)
async def load_default_meters(
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> MessageResponse:
    return MessageResponse(message="Use kit.load_default_meters() from code to load meter defaults")


@admin_router.get("/meters/{meter_id}", response_model=MeterResponse)
async def get_meter(
    meter_id: UUID,
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> MeterResponse:
    meter = await payments_kit.admin_service.get_meter(meter_id)
    if meter is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Meter not found")
    return MeterResponse.model_validate(meter)


@admin_router.patch("/meters/{meter_id}", response_model=MeterResponse)
async def update_meter(
    meter_id: UUID,
    payload: MeterUpdateRequest,
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> MeterResponse:
    meter = await payments_kit.admin_service.update_meter(
        meter_id,
        payload.model_dump(exclude_none=True),
    )
    if meter is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Meter not found")
    return MeterResponse.model_validate(meter)


@admin_router.delete("/meters/{meter_id}", response_model=MessageResponse)
async def delete_meter(
    meter_id: UUID,
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> MessageResponse:
    deleted = await payments_kit.admin_service.delete_meter(meter_id)
    if not deleted:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Meter not found")
    return MessageResponse(message="Meter deleted")


# ---------------------------------------------------------------------------
# Credits
# ---------------------------------------------------------------------------


@admin_router.post("/credits/grant", response_model=CreditLedgerEntryResponse)
async def grant_credits(
    payload: AdminCreditGrantRequest,
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> CreditLedgerEntryResponse:
    entry = await payments_kit.admin_service.grant_credits(
        payload.billing_account_id,
        amount=payload.amount,
        description=payload.description,
        reference_id=payload.reference_id,
        expires_at=payload.expires_at,
    )
    return CreditLedgerEntryResponse.model_validate(entry)


# ---------------------------------------------------------------------------
# Integration status
# ---------------------------------------------------------------------------


@admin_router.get("/integration-status", response_model=IntegrationStatusResponse)
async def get_integration_status(
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> IntegrationStatusResponse:
    status_data = await payments_kit.admin_service.get_integration_status()
    return IntegrationStatusResponse(**status_data)
