from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class ProductConfigResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    product_id: UUID | None = None
    show_in_ui: bool
    show_in_price_table: bool
    weight: int
    marketing_features: list
    pricing_page_price_ids: list


class ProductConfigUpdateRequest(BaseModel):
    show_in_ui: bool | None = None
    show_in_price_table: bool | None = None
    weight: int | None = None
    min_quantity: int | None = None
    max_quantity: int | None = None
    editable_quantity: bool | None = None
    unit_of_measure: str | None = None
    marketing_features: list | None = None
    pricing_page_price_ids: list | None = None


class MeterResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    event_name: str
    display_name: str
    description: str
    is_active: bool
    pricing_strategy: str
    margin_multiplier: Decimal
    fixed_amount: Decimal
    unit_price: Decimal
    cost_dimension_key: str


class MeterCreateRequest(BaseModel):
    event_name: str
    display_name: str
    description: str = ""
    pricing_strategy: str = "margin"
    margin_multiplier: Decimal = Decimal("1.5")
    fixed_amount: Decimal = Decimal("0")
    unit_price: Decimal = Decimal("0")
    cost_dimension_key: str = "total_cost"


class MeterUpdateRequest(BaseModel):
    display_name: str | None = None
    description: str | None = None
    is_active: bool | None = None
    pricing_strategy: str | None = None
    margin_multiplier: Decimal | None = None
    fixed_amount: Decimal | None = None
    unit_price: Decimal | None = None
    cost_dimension_key: str | None = None


class MeterDefault(BaseModel):
    event_name: str
    display_name: str
    description: str = ""
    pricing_strategy: str = "margin"
    margin_multiplier: Decimal = Decimal("1.5")
    fixed_amount: Decimal = Decimal("0")
    unit_price: Decimal = Decimal("0")
    cost_dimension_key: str = "total_cost"


class AdminCreditGrantRequest(BaseModel):
    billing_account_id: UUID
    amount: Decimal
    description: str = "Admin credit grant"
    reference_id: str | None = None
    expires_at: datetime | None = None


class IntegrationStatusResponse(BaseModel):
    stripe_configured: bool
    stripe_mode: str
    webhook_secret_set: bool
    products_synced: int
    meters_configured: int
    billing_accounts: int
