from __future__ import annotations

from decimal import Decimal
from typing import Any
from uuid import UUID

from vanty_payments.admin.schemas import MeterDefault
from vanty_payments.billing.services import BillingService
from vanty_payments.core.context import ServiceContext
from vanty_payments.db.models import (
    BillingAccount,
    CreditLedgerEntry,
    Meter,
    ProductConfig,
    StripeProduct,
)
from vanty_payments.sync.services import SyncService


class AdminService:
    def __init__(
        self,
        context: ServiceContext,
        sync_service: SyncService,
        billing_service: BillingService,
    ) -> None:
        self.context = context
        self.sync_service = sync_service
        self.billing_service = billing_service

    # ------------------------------------------------------------------
    # Product config
    # ------------------------------------------------------------------

    async def list_product_configs(self) -> list[ProductConfig]:
        return await ProductConfig.all().prefetch_related("product")

    async def get_product_config(self, config_id: UUID) -> ProductConfig | None:
        return await ProductConfig.get_or_none(pk=config_id).prefetch_related("product")

    async def update_product_config(
        self,
        config_id: UUID,
        updates: dict[str, Any],
    ) -> ProductConfig | None:
        config = await ProductConfig.get_or_none(pk=config_id)
        if config is None:
            return None
        for key, val in updates.items():
            if val is not None:
                setattr(config, key, val)
        await config.save()
        return config

    async def sync_products_from_stripe(self) -> dict[str, int]:
        products = self.context.stripe_client.list_objects("product")
        created = 0
        updated = 0
        for product_data in products:
            await self.sync_service.sync_product(product_data)
            stripe_product = await StripeProduct.filter(stripe_id=product_data["id"]).first()
            if stripe_product:
                existing = await ProductConfig.filter(product=stripe_product).first()
                if existing:
                    updated += 1
                else:
                    await ProductConfig.create(product=stripe_product)
                    created += 1
        return {"created": created, "updated": updated, "total": created + updated}

    # ------------------------------------------------------------------
    # Meter CRUD
    # ------------------------------------------------------------------

    async def list_meters(self) -> list[Meter]:
        return await Meter.all().order_by("event_name")

    async def create_meter(self, data: dict[str, Any]) -> Meter:
        return await Meter.create(**data)

    async def get_meter(self, meter_id: UUID) -> Meter | None:
        return await Meter.get_or_none(pk=meter_id)

    async def update_meter(self, meter_id: UUID, updates: dict[str, Any]) -> Meter | None:
        meter = await Meter.get_or_none(pk=meter_id)
        if meter is None:
            return None
        for key, val in updates.items():
            if val is not None:
                setattr(meter, key, val)
        await meter.save()
        return meter

    async def delete_meter(self, meter_id: UUID) -> bool:
        meter = await Meter.get_or_none(pk=meter_id)
        if meter is None:
            return False
        await meter.delete()
        return True

    async def load_default_meters(self, defaults: list[MeterDefault]) -> int:
        loaded = 0
        for d in defaults:
            existing = await Meter.filter(event_name=d.event_name).first()
            if existing:
                continue
            await Meter.create(
                event_name=d.event_name,
                display_name=d.display_name,
                description=d.description,
                pricing_strategy=d.pricing_strategy,
                margin_multiplier=d.margin_multiplier,
                fixed_amount=d.fixed_amount,
                unit_price=d.unit_price,
                cost_dimension_key=d.cost_dimension_key,
            )
            loaded += 1
        return loaded

    # ------------------------------------------------------------------
    # Admin credit grants
    # ------------------------------------------------------------------

    async def grant_credits(
        self,
        billing_account_id: UUID,
        *,
        amount: Decimal,
        description: str = "Admin credit grant",
        reference_id: str | None = None,
        expires_at: Any = None,
    ) -> CreditLedgerEntry:
        account = await BillingAccount.get(pk=billing_account_id)
        return await self.billing_service.grant_credits(
            account,
            amount=amount,
            entry_type="admin_grant",
            description=description,
            reference_id=reference_id,
            expires_at=expires_at,
        )

    # ------------------------------------------------------------------
    # Integration status
    # ------------------------------------------------------------------

    async def get_integration_status(self) -> dict[str, Any]:
        s = self.context.settings
        return {
            "stripe_configured": bool(s.stripe_secret_key),
            "stripe_mode": s.stripe_mode,
            "webhook_secret_set": bool(s.stripe_webhook_secret),
            "products_synced": await ProductConfig.all().count(),
            "meters_configured": await Meter.all().count(),
            "billing_accounts": await BillingAccount.all().count(),
        }
