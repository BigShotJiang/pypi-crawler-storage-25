from __future__ import annotations

import logging
from typing import Any

from vanty_payments.billing.constants import SubscriptionLifecycleState
from vanty_payments.billing.services import BillingService
from vanty_payments.db.models import BillingAccount, StripeCustomer
from vanty_payments.sync.services import SyncService

logger = logging.getLogger(__name__)


class WebhookHandlerRegistry:
    def __init__(
        self,
        sync_service: SyncService,
        billing_service: BillingService | None = None,
    ) -> None:
        self.sync_service = sync_service
        self.billing_service = billing_service

    async def handle_event(self, event: dict[str, Any]) -> object | None:
        payload = event.get("data", {}).get("object", {})
        if not isinstance(payload, dict) or not payload.get("object"):
            return None

        synced = await self.sync_service.sync_stripe_object(payload)

        event_type = event.get("type", "")
        if self.billing_service is not None:
            await self._dispatch_billing_event(event_type, payload)

        return synced

    async def _dispatch_billing_event(self, event_type: str, payload: dict[str, Any]) -> None:
        handlers: dict[str, Any] = {
            "checkout.session.completed": self._handle_checkout_completed,
            "checkout.session.async_payment_succeeded": self._handle_checkout_completed,
            "checkout.session.async_payment_failed": self._handle_checkout_payment_failed,
            "invoice.paid": self._handle_invoice_paid,
            "customer.subscription.deleted": self._handle_subscription_deleted,
            "setup_intent.succeeded": self._handle_setup_intent_succeeded,
        }
        handler = handlers.get(event_type)
        if handler:
            try:
                await handler(payload)
            except Exception:  # noqa: BLE001
                logger.exception("Error handling billing event %s", event_type)

    async def _resolve_billing_account(self, payload: dict[str, Any]) -> BillingAccount | None:
        if self.billing_service is None:
            return None

        customer_id = payload.get("customer")
        if isinstance(customer_id, dict):
            customer_id = customer_id.get("id")
        if not customer_id:
            return None

        customer = await StripeCustomer.filter(stripe_id=customer_id).first()
        if customer is None:
            return None

        return await self.billing_service.resolve_billing_account(
            user_reference=customer.user_reference,
            organization_reference=customer.organization_reference,
            customer=customer,
        )

    async def _handle_checkout_completed(self, payload: dict[str, Any]) -> None:
        account = await self._resolve_billing_account(payload)
        if account is None:
            return

        subscription_id = payload.get("subscription")
        account.state = SubscriptionLifecycleState.ACTIVE.value
        if subscription_id:
            account.current_plan = subscription_id
        await account.save()

        if self.billing_service and self.billing_service.context.settings.billing_credits_enabled:
            await self.billing_service._grant_credits_for_checkout(account, payload)

    async def _handle_checkout_payment_failed(self, payload: dict[str, Any]) -> None:
        account = await self._resolve_billing_account(payload)
        if account is None:
            return
        account.state = SubscriptionLifecycleState.PAYMENT_FAILED.value
        await account.save()

    async def _handle_invoice_paid(self, payload: dict[str, Any]) -> None:
        if self.billing_service is None:
            return
        billing_reason = payload.get("billing_reason", "")
        if billing_reason not in ("subscription_cycle", "subscription_create"):
            return

        account = await self._resolve_billing_account(payload)
        if account is None:
            return

        if not self.billing_service.context.settings.billing_credits_enabled:
            return

        ref = f"invoice_{payload.get('id', '')}"
        amount_paid = payload.get("amount_paid", 0)
        from decimal import Decimal

        credits = Decimal(amount_paid) / Decimal(self.billing_service.context.settings.credit_factor)
        if credits > 0:
            await self.billing_service.grant_credits(
                account,
                amount=credits,
                entry_type="subscription_grant",
                description=f"Renewal credits for invoice {payload.get('id', '')}",
                reference_id=ref,
            )

    async def _handle_subscription_deleted(self, payload: dict[str, Any]) -> None:
        account = await self._resolve_billing_account(payload)
        if account is None:
            return
        account.state = SubscriptionLifecycleState.CANCELED.value
        account.current_plan = None
        await account.save()

    async def _handle_setup_intent_succeeded(self, payload: dict[str, Any]) -> None:
        customer_id = payload.get("customer")
        if isinstance(customer_id, dict):
            customer_id = customer_id.get("id")
        if not customer_id:
            return

        payment_method = payload.get("payment_method")
        if isinstance(payment_method, dict):
            payment_method = payment_method.get("id")
        if not payment_method:
            return

        customer = await StripeCustomer.filter(stripe_id=customer_id).first()
        if customer:
            customer.default_payment_method_id = payment_method
            await customer.save()
