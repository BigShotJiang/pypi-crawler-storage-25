from __future__ import annotations

import traceback
from typing import Any
from uuid import UUID

from fastapi import HTTPException, status

from vanty_payments.billing.services import BillingService
from vanty_payments.core.context import ServiceContext
from vanty_payments.db.models import StripeWebhookDelivery
from vanty_payments.sync.services import SyncService
from vanty_payments.webhooks.handlers import WebhookHandlerRegistry


class WebhookService:
    def __init__(
        self,
        context: ServiceContext,
        sync_service: SyncService,
        billing_service: BillingService | None = None,
    ) -> None:
        self.context = context
        self.sync_service = sync_service
        self.handler_registry = WebhookHandlerRegistry(sync_service, billing_service)

    async def ingest(
        self,
        *,
        payload: bytes,
        signature: str | None,
        headers: dict[str, Any],
        remote_ip: str | None,
    ) -> StripeWebhookDelivery:
        delivery = await StripeWebhookDelivery.create(
            signature=signature,
            remote_ip=remote_ip,
            headers=headers,
            body=payload.decode("utf-8", errors="replace"),
        )
        if not signature:
            delivery.exception = "Missing stripe-signature header"
            await delivery.save()
            self.context.events.record(
                "payments.webhook.received",
                {
                    "delivery_id": str(delivery.id),
                    "valid": False,
                    "processed": False,
                    "event_type": None,
                },
            )
            return delivery

        try:
            event = self.context.stripe_client.construct_event(payload=payload, sig_header=signature)
            delivery.valid = True
            webhook_event = await self.sync_service.sync_event(event)
            await self.handler_registry.handle_event(event)
            delivery.webhook_event = webhook_event
            delivery.processed = webhook_event.processed
        except Exception as exc:  # noqa: BLE001
            delivery.valid = False
            delivery.processed = False
            delivery.exception = str(exc)
            delivery.traceback = traceback.format_exc()
        await delivery.save()
        self.context.events.record(
            "payments.webhook.received",
            {
                "delivery_id": str(delivery.id),
                "valid": delivery.valid,
                "processed": delivery.processed,
                "event_type": delivery.webhook_event.type if delivery.webhook_event_id else None,
            },
        )
        return delivery

    async def replay(self, delivery_id: UUID) -> StripeWebhookDelivery:
        delivery = await StripeWebhookDelivery.get_or_none(id=delivery_id).prefetch_related("webhook_event")
        if delivery is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Webhook delivery not found")
        if delivery.webhook_event is None:
            if not delivery.signature:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail="No stored webhook event or signature to replay",
                )
            event = self.context.stripe_client.construct_event(
                payload=delivery.body.encode("utf-8"),
                sig_header=delivery.signature,
            )
        else:
            event = delivery.webhook_event.stripe_data_json
        webhook_event = await self.sync_service.sync_event(event)
        await self.handler_registry.handle_event(event)
        delivery.webhook_event = webhook_event
        delivery.valid = True
        delivery.processed = webhook_event.processed
        delivery.exception = webhook_event.processing_error
        await delivery.save()
        self.context.events.record(
            "payments.webhook.replayed",
            {
                "delivery_id": str(delivery.id),
                "valid": delivery.valid,
                "processed": delivery.processed,
                "event_type": webhook_event.type,
            },
        )
        return delivery
