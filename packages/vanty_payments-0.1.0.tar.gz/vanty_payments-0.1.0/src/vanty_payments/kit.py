from __future__ import annotations

import asyncio
from decimal import Decimal
from typing import Any
from uuid import UUID

from fastapi import APIRouter, FastAPI
from tortoise import Tortoise

from vanty_payments.admin.router import admin_router
from vanty_payments.admin.schemas import MeterDefault
from vanty_payments.admin.services import AdminService
from vanty_payments.billing import BillingService
from vanty_payments.catalog import CatalogService
from vanty_payments.checkout import CheckoutService
from vanty_payments.checkout.schemas import CheckoutLineItem
from vanty_payments.core.context import ServiceContext
from vanty_payments.core.events import EventRecorder
from vanty_payments.core.stripe_client import StripeClient
from vanty_payments.customers import CustomerService
from vanty_payments.db.models import (
    CreditLedgerEntry,
    InternalMeterEvent,
    StripeCheckoutSession,
    StripeCustomer,
    StripeInvoice,
    StripePaymentMethod,
    StripePrice,
    StripeProduct,
    StripeSubscription,
    StripeSyncRun,
    StripeWebhookDelivery,
)
from vanty_payments.fastapi.router import router as payments_router
from vanty_payments.settings import PaymentsKitSettings
from vanty_payments.sync import SyncService
from vanty_payments.webhooks import WebhookService


class PaymentsKit:
    def __init__(self, settings: PaymentsKitSettings | None = None) -> None:
        self.settings = settings or PaymentsKitSettings()
        self.context = ServiceContext(
            settings=self.settings,
            stripe_client=StripeClient(self.settings),
            events=EventRecorder(),
        )
        self.sync_service = SyncService(self.context)
        self.customer_service = CustomerService(self.context, self.sync_service)
        self.catalog_service = CatalogService(self.sync_service)
        self.checkout_service = CheckoutService(self.context, self.customer_service, self.sync_service)
        self.billing_service = BillingService(self.context, self.customer_service)
        self.admin_service = AdminService(self.context, self.sync_service, self.billing_service)
        self.webhook_service = WebhookService(self.context, self.sync_service, self.billing_service)
        self.router: APIRouter = payments_router
        self._admin_router: APIRouter = admin_router
        self._orm_lock = asyncio.Lock()
        self._orm_initialized = False

    @property
    def admin_router(self) -> APIRouter:
        return self._admin_router

    @property
    def events(self) -> EventRecorder:
        return self.context.events

    async def init_orm(self, *, generate_schemas: bool = False) -> None:
        async with self._orm_lock:
            if self._orm_initialized:
                return
            await Tortoise.init(
                db_url=self.settings.database_url,
                modules={"models": ["vanty_payments.db.models"]},
                _enable_global_fallback=True,
            )
            if generate_schemas:
                await Tortoise.generate_schemas(safe=True)

            if "postgresql" in self.settings.database_url:
                from vanty_payments.db.views import create_pg_views
                await create_pg_views()

            self._orm_initialized = True

    async def close_orm(self) -> None:
        if self._orm_initialized:
            await Tortoise.close_connections()
            self._orm_initialized = False

    # ------------------------------------------------------------------
    # Customer facade
    # ------------------------------------------------------------------

    async def bootstrap_customer(
        self,
        *,
        email: str,
        name: str | None = None,
        user_reference: str | None = None,
        organization_reference: str | None = None,
        stripe_customer_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> StripeCustomer:
        return await self.customer_service.bootstrap_customer(
            email=email,
            name=name,
            user_reference=user_reference,
            organization_reference=organization_reference,
            stripe_customer_id=stripe_customer_id,
            metadata=metadata,
        )

    async def get_customer(
        self,
        *,
        stripe_customer_id: str | None = None,
        user_reference: str | None = None,
        organization_reference: str | None = None,
    ) -> StripeCustomer | None:
        return await self.customer_service.resolve_customer(
            stripe_customer_id=stripe_customer_id,
            user_reference=user_reference,
            organization_reference=organization_reference,
        )

    async def list_customers(self) -> list[StripeCustomer]:
        return await self.customer_service.list_customers()

    # ------------------------------------------------------------------
    # Catalog facade
    # ------------------------------------------------------------------

    async def catalog(self) -> tuple[list[StripeProduct], list[StripePrice]]:
        return await self.catalog_service.list_products(), await self.catalog_service.list_prices()

    # ------------------------------------------------------------------
    # Checkout facade
    # ------------------------------------------------------------------

    async def create_checkout_session(
        self,
        *,
        email: str | None = None,
        name: str | None = None,
        stripe_customer_id: str | None = None,
        user_reference: str | None = None,
        organization_reference: str | None = None,
        metadata: dict[str, Any] | None = None,
        mode: str = "subscription",
        line_items: list[CheckoutLineItem] | None = None,
        success_url: str | None = None,
        cancel_url: str | None = None,
        client_reference_id: str | None = None,
    ) -> StripeCheckoutSession:
        stripe_line_items = [
            {"price": item.price_id, "quantity": item.quantity} for item in (line_items or [])
        ]
        return await self.checkout_service.create_checkout_session(
            email=email,
            name=name,
            stripe_customer_id=stripe_customer_id,
            user_reference=user_reference,
            organization_reference=organization_reference,
            metadata=metadata or {},
            mode=mode,
            line_items=stripe_line_items,
            success_url=success_url,
            cancel_url=cancel_url,
            client_reference_id=client_reference_id,
        )

    async def create_billing_portal_session(
        self,
        *,
        stripe_customer_id: str | None = None,
        user_reference: str | None = None,
        organization_reference: str | None = None,
        return_url: str | None = None,
    ) -> str:
        return await self.checkout_service.create_billing_portal_session(
            stripe_customer_id=stripe_customer_id,
            user_reference=user_reference,
            organization_reference=organization_reference,
            return_url=return_url,
        )

    # ------------------------------------------------------------------
    # Billing facade (legacy reads)
    # ------------------------------------------------------------------

    async def get_subscription(
        self,
        *,
        stripe_customer_id: str | None = None,
        user_reference: str | None = None,
        organization_reference: str | None = None,
    ) -> StripeSubscription | None:
        return await self.billing_service.get_subscription(
            stripe_customer_id=stripe_customer_id,
            user_reference=user_reference,
            organization_reference=organization_reference,
        )

    async def list_invoices(
        self,
        *,
        stripe_customer_id: str | None = None,
        user_reference: str | None = None,
        organization_reference: str | None = None,
    ) -> list[StripeInvoice]:
        return await self.billing_service.list_invoices(
            stripe_customer_id=stripe_customer_id,
            user_reference=user_reference,
            organization_reference=organization_reference,
        )

    async def list_payment_methods(
        self,
        *,
        stripe_customer_id: str | None = None,
        user_reference: str | None = None,
        organization_reference: str | None = None,
    ) -> list[StripePaymentMethod]:
        return await self.billing_service.list_payment_methods(
            stripe_customer_id=stripe_customer_id,
            user_reference=user_reference,
            organization_reference=organization_reference,
        )

    # ------------------------------------------------------------------
    # Billing facade (new)
    # ------------------------------------------------------------------

    async def confirm_checkout(
        self,
        session_id: str,
        *,
        user_reference: str | None = None,
        organization_reference: str | None = None,
    ) -> dict[str, Any]:
        account = await self.billing_service.resolve_billing_account(
            user_reference=user_reference,
            organization_reference=organization_reference,
        )
        return await self.billing_service.confirm_checkout_session(session_id, account)

    async def record_usage(
        self,
        *,
        user_reference: str | None = None,
        organization_reference: str | None = None,
        event_name: str,
        value: int = 1,
        dimensions: dict[str, str] | None = None,
    ) -> InternalMeterEvent:
        account = await self.billing_service.resolve_billing_account(
            user_reference=user_reference,
            organization_reference=organization_reference,
        )
        return await self.billing_service.record_usage(
            account,
            event_name=event_name,
            value=value,
            dimensions=dimensions,
        )

    async def grant_credits(
        self,
        *,
        user_reference: str | None = None,
        organization_reference: str | None = None,
        amount: Decimal,
        description: str = "",
        reference_id: str | None = None,
    ) -> CreditLedgerEntry:
        account = await self.billing_service.resolve_billing_account(
            user_reference=user_reference,
            organization_reference=organization_reference,
        )
        return await self.billing_service.grant_credits(
            account,
            amount=amount,
            description=description,
            reference_id=reference_id,
        )

    async def load_default_meters(self, defaults: list[MeterDefault]) -> int:
        return await self.admin_service.load_default_meters(defaults)

    # ------------------------------------------------------------------
    # Webhooks facade
    # ------------------------------------------------------------------

    async def process_webhook(
        self,
        *,
        payload: bytes,
        signature: str | None,
        headers: dict[str, object],
        remote_ip: str | None,
    ) -> StripeWebhookDelivery:
        return await self.webhook_service.ingest(
            payload=payload,
            signature=signature,
            headers=headers,
            remote_ip=remote_ip,
        )

    async def replay_webhook(self, delivery_id: UUID) -> StripeWebhookDelivery:
        return await self.webhook_service.replay(delivery_id)

    # ------------------------------------------------------------------
    # Sync facade
    # ------------------------------------------------------------------

    async def bootstrap_sync(self, object_types: list[str], *, limit: int = 100) -> StripeSyncRun:
        return await self.sync_service.bootstrap(object_types, limit=limit)

    async def sync_object(self, object_type: str, stripe_id: str) -> object | None:
        return await self.sync_service.sync_by_type_and_id(object_type, stripe_id)

    def set_identity_resolver(self, resolver: object) -> None:
        self.identity_resolver = resolver


def mount_payments_router(app: FastAPI, settings: PaymentsKitSettings | None = None) -> PaymentsKit:
    kit = PaymentsKit(settings=settings)
    app.include_router(kit.router)
    app.state.payments_kit = kit
    if not hasattr(app.state, "payments_identity_resolver"):
        app.state.payments_identity_resolver = None
    return kit
