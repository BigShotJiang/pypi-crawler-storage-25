from __future__ import annotations

from typing import TYPE_CHECKING

from fastapi import Request

from vanty_payments.core.identity import IdentityContext, resolve_request_identity

if TYPE_CHECKING:
    from vanty_payments.kit import PaymentsKit


def get_payments_kit(request: Request) -> PaymentsKit:
    return request.app.state.payments_kit


async def get_identity_context(request: Request) -> IdentityContext:
    return await resolve_request_identity(request)
