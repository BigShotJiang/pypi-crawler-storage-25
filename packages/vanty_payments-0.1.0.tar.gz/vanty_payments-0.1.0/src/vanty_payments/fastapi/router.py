from __future__ import annotations

from typing import TYPE_CHECKING

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status

from vanty_payments.billing.schemas import (
    BillingConfigResponse,
    BillingSummaryResponse,
    CancelSubscriptionResponse,
    ChangePlanRequest,
    ChangePlanResponse,
    CheckoutConfirmResponse,
    CreditBalanceResponse,
    CreditLedgerEntryResponse,
    InvoiceResponse,
    InvoicesResponse,
    PaymentMethodResponse,
    PaymentMethodsResponse,
    RecordUsageRequest,
    SetupIntentResponse,
    SubscriptionResponse,
    UsageRecordResponse,
    UsageSummaryResponse,
)
from vanty_payments.catalog.schemas import CatalogResponse, PriceResponse, ProductResponse
from vanty_payments.checkout.schemas import (
    BillingPortalSessionResponse,
    CheckoutSessionResponse,
    CreateBillingPortalSessionRequest,
    CreateCheckoutSessionRequest,
)
from vanty_payments.core.identity import IdentityContext, resolve_identity_refs
from vanty_payments.core.schemas import MessageResponse
from vanty_payments.customers.schemas import (
    CustomerBootstrapRequest,
    CustomerResponse,
    CustomersResponse,
)
from vanty_payments.fastapi.dependencies import get_identity_context, get_payments_kit
from vanty_payments.sync.schemas import BootstrapSyncRequest, SyncObjectRequest, SyncRunResponse
from vanty_payments.webhooks.schemas import ReplayWebhookRequest, WebhookProcessResponse

if TYPE_CHECKING:
    from vanty_payments.kit import PaymentsKit


router = APIRouter(prefix="/payments", tags=["payments"])


# ---------------------------------------------------------------------------
# Customers
# ---------------------------------------------------------------------------


@router.post("/customer/bootstrap", response_model=CustomerResponse)
async def bootstrap_customer(
    payload: CustomerBootstrapRequest,
    identity: IdentityContext = Depends(get_identity_context),
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> CustomerResponse:
    user_ref, org_ref = resolve_identity_refs(payload.user_reference, payload.organization_reference, identity)
    customer = await payments_kit.bootstrap_customer(
        email=payload.email,
        name=payload.name,
        user_reference=user_ref,
        organization_reference=org_ref,
        stripe_customer_id=payload.stripe_customer_id,
        metadata=payload.metadata,
    )
    return CustomerResponse.model_validate(customer)


@router.get("/customer", response_model=CustomerResponse)
async def get_customer(
    stripe_customer_id: str | None = Query(default=None),
    user_reference: str | None = Query(default=None),
    organization_reference: str | None = Query(default=None),
    identity: IdentityContext = Depends(get_identity_context),
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> CustomerResponse:
    user_ref, org_ref = resolve_identity_refs(user_reference, organization_reference, identity)
    customer = await payments_kit.get_customer(
        stripe_customer_id=stripe_customer_id,
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    if customer is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Customer not found")
    return CustomerResponse.model_validate(customer)


@router.get("/customers", response_model=CustomersResponse)
async def list_customers(
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> CustomersResponse:
    customers = await payments_kit.list_customers()
    return CustomersResponse(customers=[CustomerResponse.model_validate(c) for c in customers])


# ---------------------------------------------------------------------------
# Catalog
# ---------------------------------------------------------------------------


@router.get("/catalog", response_model=CatalogResponse)
async def catalog(
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> CatalogResponse:
    products, prices = await payments_kit.catalog()
    return CatalogResponse(
        products=[ProductResponse.model_validate(p) for p in products],
        prices=[PriceResponse.model_validate(p) for p in prices],
    )


# ---------------------------------------------------------------------------
# Checkout
# ---------------------------------------------------------------------------


@router.post("/checkout/sessions", response_model=CheckoutSessionResponse)
async def create_checkout_session(
    payload: CreateCheckoutSessionRequest,
    identity: IdentityContext = Depends(get_identity_context),
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> CheckoutSessionResponse:
    user_ref, org_ref = resolve_identity_refs(payload.user_reference, payload.organization_reference, identity)
    session = await payments_kit.create_checkout_session(
        email=payload.email,
        name=payload.name,
        stripe_customer_id=payload.stripe_customer_id,
        user_reference=user_ref,
        organization_reference=org_ref,
        metadata=payload.metadata,
        mode=payload.mode,
        line_items=payload.line_items,
        success_url=payload.success_url,
        cancel_url=payload.cancel_url,
        client_reference_id=payload.client_reference_id,
    )
    return CheckoutSessionResponse.model_validate(session)


@router.get("/checkout/sessions/{session_id}/confirm", response_model=CheckoutConfirmResponse)
async def confirm_checkout_session(
    session_id: str,
    identity: IdentityContext = Depends(get_identity_context),
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> CheckoutConfirmResponse:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_kit.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    result = await payments_kit.billing_service.confirm_checkout_session(session_id, account)
    return CheckoutConfirmResponse(**result)


# ---------------------------------------------------------------------------
# Billing portal
# ---------------------------------------------------------------------------


@router.post("/billing-portal/sessions", response_model=BillingPortalSessionResponse)
async def create_billing_portal_session(
    payload: CreateBillingPortalSessionRequest,
    identity: IdentityContext = Depends(get_identity_context),
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> BillingPortalSessionResponse:
    user_ref, org_ref = resolve_identity_refs(payload.user_reference, payload.organization_reference, identity)
    url = await payments_kit.create_billing_portal_session(
        stripe_customer_id=payload.stripe_customer_id,
        user_reference=user_ref,
        organization_reference=org_ref,
        return_url=payload.return_url,
    )
    return BillingPortalSessionResponse(url=url)


# ---------------------------------------------------------------------------
# Billing reads
# ---------------------------------------------------------------------------


@router.get("/billing/config", response_model=BillingConfigResponse)
async def get_billing_config(
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> BillingConfigResponse:
    return BillingConfigResponse(**payments_kit.billing_service.get_billing_config())


@router.get("/billing/summary", response_model=BillingSummaryResponse)
async def get_billing_summary(
    identity: IdentityContext = Depends(get_identity_context),
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> BillingSummaryResponse:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_kit.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    summary = await payments_kit.billing_service.get_billing_summary(account)
    sub = summary.pop("subscription", None)
    if sub:
        summary["subscription"] = SubscriptionResponse.model_validate(sub)
    return BillingSummaryResponse(**summary)


@router.get("/subscription", response_model=SubscriptionResponse | None)
async def get_subscription(
    stripe_customer_id: str | None = Query(default=None),
    user_reference: str | None = Query(default=None),
    organization_reference: str | None = Query(default=None),
    identity: IdentityContext = Depends(get_identity_context),
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> SubscriptionResponse | None:
    user_ref, org_ref = resolve_identity_refs(user_reference, organization_reference, identity)
    subscription = await payments_kit.get_subscription(
        stripe_customer_id=stripe_customer_id,
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    if subscription is None:
        return None
    return SubscriptionResponse.model_validate(subscription)


@router.get("/invoices", response_model=InvoicesResponse)
async def list_invoices(
    stripe_customer_id: str | None = Query(default=None),
    user_reference: str | None = Query(default=None),
    organization_reference: str | None = Query(default=None),
    identity: IdentityContext = Depends(get_identity_context),
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> InvoicesResponse:
    user_ref, org_ref = resolve_identity_refs(user_reference, organization_reference, identity)
    invoices = await payments_kit.list_invoices(
        stripe_customer_id=stripe_customer_id,
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    return InvoicesResponse(invoices=[InvoiceResponse.model_validate(inv) for inv in invoices])


@router.get("/payment-methods", response_model=PaymentMethodsResponse)
async def list_payment_methods(
    stripe_customer_id: str | None = Query(default=None),
    user_reference: str | None = Query(default=None),
    organization_reference: str | None = Query(default=None),
    identity: IdentityContext = Depends(get_identity_context),
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> PaymentMethodsResponse:
    user_ref, org_ref = resolve_identity_refs(user_reference, organization_reference, identity)
    payment_methods = await payments_kit.list_payment_methods(
        stripe_customer_id=stripe_customer_id,
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    return PaymentMethodsResponse(
        payment_methods=[PaymentMethodResponse.model_validate(pm) for pm in payment_methods]
    )


# ---------------------------------------------------------------------------
# Subscription lifecycle
# ---------------------------------------------------------------------------


@router.post("/billing/change-plan", response_model=ChangePlanResponse)
async def change_plan(
    payload: ChangePlanRequest,
    identity: IdentityContext = Depends(get_identity_context),
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> ChangePlanResponse:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_kit.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    result = await payments_kit.billing_service.change_subscription_price(account, payload.new_price_id)
    return ChangePlanResponse(**result)


@router.post("/billing/cancel-subscription", response_model=CancelSubscriptionResponse)
async def cancel_subscription(
    identity: IdentityContext = Depends(get_identity_context),
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> CancelSubscriptionResponse:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_kit.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    result = await payments_kit.billing_service.cancel_subscription(account)
    return CancelSubscriptionResponse(**result)


@router.post("/billing/reactivate-subscription", response_model=CancelSubscriptionResponse)
async def reactivate_subscription(
    identity: IdentityContext = Depends(get_identity_context),
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> CancelSubscriptionResponse:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_kit.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    result = await payments_kit.billing_service.reactivate_subscription(account)
    return CancelSubscriptionResponse(**result)


@router.post("/billing/setup-payment-method", response_model=SetupIntentResponse)
async def setup_payment_method(
    identity: IdentityContext = Depends(get_identity_context),
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> SetupIntentResponse:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_kit.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    result = await payments_kit.billing_service.create_setup_intent(account)
    return SetupIntentResponse(**result)


# ---------------------------------------------------------------------------
# Usage metering
# ---------------------------------------------------------------------------


@router.post("/billing/usage/record", response_model=UsageRecordResponse)
async def record_usage(
    payload: RecordUsageRequest,
    identity: IdentityContext = Depends(get_identity_context),
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> UsageRecordResponse:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_kit.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    event = await payments_kit.billing_service.record_usage(
        account,
        event_name=payload.event_name,
        value=payload.value,
        dimensions=payload.dimensions,
    )
    return UsageRecordResponse.model_validate(event)


@router.get("/billing/usage/summary", response_model=UsageSummaryResponse)
async def get_usage_summary(
    identity: IdentityContext = Depends(get_identity_context),
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> UsageSummaryResponse:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_kit.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    summary = await payments_kit.billing_service.get_usage_summary(account)
    return UsageSummaryResponse(**summary)


@router.get("/billing/usage/records", response_model=list[UsageRecordResponse])
async def list_usage_records(
    identity: IdentityContext = Depends(get_identity_context),
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> list[UsageRecordResponse]:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_kit.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    records = await payments_kit.billing_service.list_usage_records(account)
    return [UsageRecordResponse.model_validate(r) for r in records]


# ---------------------------------------------------------------------------
# Credits
# ---------------------------------------------------------------------------


@router.get("/billing/credits/balance", response_model=CreditBalanceResponse)
async def get_credit_balance(
    identity: IdentityContext = Depends(get_identity_context),
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> CreditBalanceResponse:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_kit.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    balance = await payments_kit.billing_service.get_credit_balance(account)
    return CreditBalanceResponse(**balance)


@router.get("/billing/credits/ledger", response_model=list[CreditLedgerEntryResponse])
async def list_credit_ledger(
    identity: IdentityContext = Depends(get_identity_context),
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> list[CreditLedgerEntryResponse]:
    user_ref, org_ref = resolve_identity_refs(None, None, identity)
    account = await payments_kit.billing_service.resolve_billing_account(
        user_reference=user_ref,
        organization_reference=org_ref,
    )
    entries = await payments_kit.billing_service.list_credit_ledger(account)
    return [CreditLedgerEntryResponse.model_validate(e) for e in entries]


# ---------------------------------------------------------------------------
# Webhooks
# ---------------------------------------------------------------------------


@router.post("/webhooks/stripe", response_model=WebhookProcessResponse)
async def process_webhook(
    request: Request,
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> WebhookProcessResponse:
    payload = await request.body()
    signature = request.headers.get("stripe-signature")
    delivery = await payments_kit.process_webhook(
        payload=payload,
        signature=signature,
        headers=dict(request.headers),
        remote_ip=request.client.host if request.client else None,
    )
    if not delivery.valid:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=delivery.exception or "Invalid webhook")
    return WebhookProcessResponse.model_validate(delivery)


@router.post("/webhooks/reprocess", response_model=WebhookProcessResponse)
async def replay_webhook(
    payload: ReplayWebhookRequest,
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> WebhookProcessResponse:
    delivery = await payments_kit.replay_webhook(payload.delivery_id)
    return WebhookProcessResponse.model_validate(delivery)


# ---------------------------------------------------------------------------
# Sync
# ---------------------------------------------------------------------------


@router.post("/sync/bootstrap", response_model=SyncRunResponse)
async def bootstrap_sync(
    payload: BootstrapSyncRequest,
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> SyncRunResponse:
    sync_run = await payments_kit.bootstrap_sync(payload.object_types, limit=payload.limit)
    return SyncRunResponse.model_validate(sync_run)


@router.post("/sync/object", response_model=MessageResponse)
async def sync_object(
    payload: SyncObjectRequest,
    payments_kit: PaymentsKit = Depends(get_payments_kit),
) -> MessageResponse:
    instance = await payments_kit.sync_object(payload.object_type, payload.stripe_id)
    if instance is None:
        return MessageResponse(
            message="No-op",
            debug={"object_type": payload.object_type, "stripe_id": payload.stripe_id},
        )
    return MessageResponse(
        message="Object synced",
        debug={"object_type": payload.object_type, "stripe_id": payload.stripe_id},
    )
