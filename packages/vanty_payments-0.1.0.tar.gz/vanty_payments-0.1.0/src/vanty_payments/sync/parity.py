from __future__ import annotations

from collections.abc import Callable
from typing import Any

from vanty_payments.core.utils import stripe_id_from, ts_to_datetime
from vanty_payments.db.models import (
    StripeAccount,
    StripeActiveEntitlement,
    StripeApplicationFee,
    StripeApplicationFeeRefund,
    StripeBalanceTransaction,
    StripeBankAccount,
    StripeCard,
    StripeCharge,
    StripeCountrySpec,
    StripeCoupon,
    StripeDiscount,
    StripeDispute,
    StripeDjstripePaymentMethod,
    StripeEarlyFraudWarning,
    StripeEvent,
    StripeFeature,
    StripeFile,
    StripeFileLink,
    StripeFileUpload,
    StripeInvoiceItem,
    StripeIssuingAuthorization,
    StripeIssuingCard,
    StripeIssuingCardholder,
    StripeIssuingDispute,
    StripeIssuingTransaction,
    StripeLineItem,
    StripeMandate,
    StripePayout,
    StripePlan,
    StripePricingTable,
    StripeProductFeature,
    StripePromotionCode,
    StripeRefund,
    StripeReview,
    StripeScheduledQueryRun,
    StripeSetupIntent,
    StripeShippingRate,
    StripeSource,
    StripeSourceTransaction,
    StripeSubscriptionSchedule,
    StripeTaxCode,
    StripeTaxId,
    StripeTaxRate,
    StripeTransfer,
    StripeTransferReversal,
    StripeUpcomingInvoice,
    StripeVerificationReport,
    StripeVerificationSession,
)

Normalizer = Callable[[dict[str, Any]], dict[str, Any]]


def _request_ids(data: dict[str, Any]) -> tuple[str | None, str | None]:
    request = data.get('request') or {}
    if not isinstance(request, dict):
        return request, None
    return request.get('id'), request.get('idempotency_key')


def _pricing_price_id(data: dict[str, Any]) -> str | None:
    pricing = data.get('pricing') or {}
    price_details = pricing.get('price_details') or {}
    return stripe_id_from(price_details.get('price')) or stripe_id_from(data.get('price'))


def _account(data: dict[str, Any]) -> dict[str, Any]:
    business_profile = data.get('business_profile') or {}
    return {
        'email': data.get('email'),
        'country': data.get('country'),
        'default_currency': data.get('default_currency'),
        'business_type': data.get('business_type'),
        'charges_enabled': bool(data.get('charges_enabled', False)),
        'payouts_enabled': bool(data.get('payouts_enabled', False)),
        'details_submitted': bool(data.get('details_submitted', False)),
        'metadata_json': business_profile or dict(data.get('metadata') or {}),
    }


def _coupon(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'name': data.get('name'),
        'duration': data.get('duration'),
        'currency': data.get('currency'),
        'amount_off': data.get('amount_off'),
        'percent_off': data.get('percent_off'),
        'valid': bool(data.get('valid', True)),
    }


def _promotion_code(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'coupon_stripe_id': stripe_id_from(data.get('coupon')),
        'code': data.get('code') or data.get('id'),
        'active': bool(data.get('active', True)),
        'customer_stripe_id': stripe_id_from(data.get('customer')),
    }


def _discount(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'coupon_stripe_id': stripe_id_from(data.get('coupon')),
        'customer_stripe_id': stripe_id_from(data.get('customer')),
        'subscription_stripe_id': stripe_id_from(data.get('subscription')),
        'invoice_stripe_id': stripe_id_from(data.get('invoice')),
        'start_at': ts_to_datetime(data.get('start')),
        'end_at': ts_to_datetime(data.get('end')),
    }


def _invoice_item(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'customer_stripe_id': stripe_id_from(data.get('customer')),
        'invoice_stripe_id': stripe_id_from(data.get('invoice')),
        'price_stripe_id': stripe_id_from(data.get('price')),
        'currency': data.get('currency'),
        'amount': data.get('amount'),
        'quantity': data.get('quantity'),
        'description': data.get('description'),
    }


def _line_item(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'invoice_stripe_id': stripe_id_from(data.get('invoice')),
        'checkout_session_stripe_id': stripe_id_from(data.get('checkout_session')),
        'price_stripe_id': _pricing_price_id(data),
        'currency': data.get('currency'),
        'amount': data.get('amount_subtotal') or data.get('amount_total') or data.get('amount'),
        'quantity': data.get('quantity'),
        'description': data.get('description'),
    }


def _plan(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'product_stripe_id': stripe_id_from(data.get('product')),
        'nickname': data.get('nickname'),
        'currency': data.get('currency'),
        'amount': data.get('amount'),
        'interval': (data.get('recurring') or {}).get('interval') or data.get('interval'),
        'interval_count': (data.get('recurring') or {}).get('interval_count') or data.get('interval_count'),
        'active': bool(data.get('active', True)),
    }


def _subscription_schedule(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'customer_stripe_id': stripe_id_from(data.get('customer')),
        'subscription_stripe_id': stripe_id_from(data.get('subscription')),
        'status': data.get('status'),
        'released_subscription_stripe_id': stripe_id_from(data.get('released_subscription')),
        'current_phase_json': data.get('current_phase') or {},
    }


def _shipping_rate(data: dict[str, Any]) -> dict[str, Any]:
    fixed = data.get('fixed_amount') or {}
    return {
        'display_name': data.get('display_name'),
        'currency': fixed.get('currency'),
        'fixed_amount': fixed.get('amount'),
        'active': bool(data.get('active', True)),
        'delivery_estimate_json': data.get('delivery_estimate') or {},
    }


def _tax_code(data: dict[str, Any]) -> dict[str, Any]:
    return {'name': data.get('name'), 'description': data.get('description')}


def _tax_id(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'customer_stripe_id': stripe_id_from(data.get('customer')),
        'country': data.get('country'),
        'type': data.get('type'),
        'value': data.get('value'),
        'verification_json': data.get('verification') or {},
    }


def _tax_rate(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'display_name': data.get('display_name'),
        'jurisdiction': data.get('jurisdiction'),
        'country': data.get('country'),
        'state': data.get('state'),
        'percentage': data.get('percentage'),
        'inclusive': bool(data.get('inclusive', False)),
        'active': bool(data.get('active', True)),
    }


def _upcoming_invoice(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'customer_stripe_id': stripe_id_from(data.get('customer')),
        'subscription_stripe_id': stripe_id_from(data.get('subscription')),
        'currency': data.get('currency'),
        'total': data.get('total'),
        'amount_due': data.get('amount_due'),
        'status': data.get('status'),
    }


def _balance_transaction(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'source_stripe_id': stripe_id_from(data.get('source')),
        'currency': data.get('currency'),
        'amount': data.get('amount'),
        'fee': data.get('fee'),
        'net': data.get('net'),
        'type': data.get('type'),
        'reporting_category': data.get('reporting_category'),
    }


def _charge(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'customer_stripe_id': stripe_id_from(data.get('customer')),
        'payment_intent_stripe_id': stripe_id_from(data.get('payment_intent')),
        'dispute_stripe_id': stripe_id_from(data.get('dispute')),
        'currency': data.get('currency'),
        'amount': data.get('amount'),
        'amount_refunded': data.get('amount_refunded'),
        'status': data.get('status'),
        'paid': bool(data.get('paid', False)),
        'refunded': bool(data.get('refunded', False)),
    }


def _dispute(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'charge_stripe_id': stripe_id_from(data.get('charge')),
        'currency': data.get('currency'),
        'amount': data.get('amount'),
        'reason': data.get('reason'),
        'status': data.get('status'),
    }


def _event(data: dict[str, Any]) -> dict[str, Any]:
    request_id, idempotency_key = _request_ids(data)
    return {
        'event_type': data.get('type') or 'unknown',
        'api_version': data.get('api_version'),
        'request_id': request_id,
        'idempotency_key': idempotency_key,
        'pending_webhooks': data.get('pending_webhooks'),
    }


def _file(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'filename': data.get('filename'),
        'purpose': data.get('purpose'),
        'file_type': data.get('type'),
        'size': data.get('size'),
        'url': data.get('url'),
    }


def _file_link(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'file_stripe_id': stripe_id_from(data.get('file')),
        'url': data.get('url'),
        'expired': bool(data.get('expired', False)),
        'expires_at': ts_to_datetime(data.get('expires_at')),
    }


def _mandate(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'customer_acceptance_json': data.get('customer_acceptance') or {},
        'payment_method_stripe_id': stripe_id_from(data.get('payment_method')),
        'mandate_type': data.get('type'),
        'status': data.get('status'),
    }


def _refund(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'charge_stripe_id': stripe_id_from(data.get('charge')),
        'payment_intent_stripe_id': stripe_id_from(data.get('payment_intent')),
        'currency': data.get('currency'),
        'amount': data.get('amount'),
        'reason': data.get('reason'),
        'status': data.get('status'),
    }


def _setup_intent(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'customer_stripe_id': stripe_id_from(data.get('customer')),
        'payment_method_stripe_id': stripe_id_from(data.get('payment_method')),
        'status': data.get('status'),
        'usage': data.get('usage'),
        'client_secret': data.get('client_secret'),
    }


def _payout(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'currency': data.get('currency'),
        'amount': data.get('amount'),
        'arrival_date': ts_to_datetime(data.get('arrival_date')),
        'payout_type': data.get('type'),
        'status': data.get('status'),
    }


def _payment_method_base(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'customer_stripe_id': stripe_id_from(data.get('customer')),
        'method_type': data.get('type'),
        'billing_details_json': data.get('billing_details') or {},
    }


def _bank_account(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'customer_stripe_id': stripe_id_from(data.get('customer')),
        'bank_name': data.get('bank_name'),
        'country': data.get('country'),
        'currency': data.get('currency'),
        'last4': data.get('last4'),
        'status': data.get('status'),
    }


def _card(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'customer_stripe_id': stripe_id_from(data.get('customer')),
        'brand': data.get('brand'),
        'country': data.get('country'),
        'exp_month': data.get('exp_month'),
        'exp_year': data.get('exp_year'),
        'funding': data.get('funding'),
        'last4': data.get('last4'),
    }


def _source(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'customer_stripe_id': stripe_id_from(data.get('customer')),
        'source_type': data.get('type'),
        'status': data.get('status'),
        'currency': data.get('currency'),
        'amount': data.get('amount'),
    }


def _source_transaction(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'source_stripe_id': stripe_id_from(data.get('source')),
        'source_transaction_type': data.get('type'),
        'status': data.get('status'),
        'currency': data.get('currency'),
        'amount': data.get('amount'),
    }


def _application_fee(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'account_stripe_id': stripe_id_from(data.get('account')),
        'charge_stripe_id': stripe_id_from(data.get('charge')),
        'balance_transaction_stripe_id': stripe_id_from(data.get('balance_transaction')),
        'currency': data.get('currency'),
        'amount': data.get('amount'),
        'amount_refunded': data.get('amount_refunded'),
    }


def _application_fee_refund(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'application_fee_stripe_id': stripe_id_from(data.get('fee') or data.get('application_fee')),
        'balance_transaction_stripe_id': stripe_id_from(data.get('balance_transaction')),
        'currency': data.get('currency'),
        'amount': data.get('amount'),
    }


def _country_spec(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'default_currency': data.get('default_currency'),
        'supported_bank_account_currencies_json': data.get('supported_bank_account_currencies') or {},
        'supported_payment_currencies_json': data.get('supported_payment_currencies') or [],
        'supported_payment_methods_json': data.get('supported_payment_methods') or [],
    }


def _transfer(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'destination_account_stripe_id': stripe_id_from(data.get('destination')),
        'destination_payment_stripe_id': stripe_id_from(data.get('destination_payment')),
        'balance_transaction_stripe_id': stripe_id_from(data.get('balance_transaction')),
        'currency': data.get('currency'),
        'amount': data.get('amount'),
        'reversed': bool(data.get('reversed', False)),
    }


def _transfer_reversal(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'transfer_stripe_id': stripe_id_from(data.get('transfer')),
        'balance_transaction_stripe_id': stripe_id_from(data.get('balance_transaction')),
        'currency': data.get('currency'),
        'amount': data.get('amount'),
    }


def _feature(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'feature_name': data.get('name'),
        'lookup_key': data.get('lookup_key'),
        'active': bool(data.get('active', True)),
    }


def _product_feature(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'product_stripe_id': stripe_id_from(data.get('product')),
        'feature_stripe_id': stripe_id_from(data.get('feature')),
    }


def _active_entitlement(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'customer_stripe_id': stripe_id_from(data.get('customer')),
        'lookup_key': data.get('lookup_key'),
        'feature_stripe_id': stripe_id_from(data.get('feature')),
    }


def _verification_session(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'client_secret': data.get('client_secret'),
        'status': data.get('status'),
        'verification_type': data.get('type'),
        'url': data.get('url'),
    }


def _verification_report(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'verification_session_stripe_id': stripe_id_from(data.get('verification_session')),
        'report_type': data.get('type'),
        'document_json': data.get('document') or {},
        'selfie_json': data.get('selfie') or {},
    }


def _issuing_authorization(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'card_stripe_id': stripe_id_from(data.get('card')),
        'cardholder_stripe_id': stripe_id_from(data.get('cardholder')),
        'currency': data.get('currency'),
        'amount': data.get('amount'),
        'approved': bool(data.get('approved', False)),
        'status': data.get('status'),
    }


def _issuing_cardholder(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'email': data.get('email'),
        'name': data.get('name'),
        'status': data.get('status'),
        'cardholder_type': data.get('type'),
    }


def _issuing_card(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'brand': data.get('brand'),
        'currency': data.get('currency'),
        'exp_month': data.get('exp_month'),
        'exp_year': data.get('exp_year'),
        'last4': data.get('last4'),
        'status': data.get('status'),
        'cardholder_stripe_id': stripe_id_from(data.get('cardholder')),
    }


def _issuing_dispute(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'transaction_stripe_id': stripe_id_from(data.get('transaction')),
        'currency': data.get('currency'),
        'amount': data.get('amount'),
        'status': data.get('status'),
    }


def _issuing_transaction(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'card_stripe_id': stripe_id_from(data.get('card')),
        'cardholder_stripe_id': stripe_id_from(data.get('cardholder')),
        'currency': data.get('currency'),
        'amount': data.get('amount'),
        'transaction_type': data.get('type'),
    }


def _early_fraud_warning(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'charge_stripe_id': stripe_id_from(data.get('charge')),
        'actionable': bool(data.get('actionable', False)),
        'fraud_type': data.get('fraud_type'),
    }


def _review(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'charge_stripe_id': stripe_id_from(data.get('charge')),
        'open': bool(data.get('open', False)),
        'reason': data.get('reason'),
        'closed_reason': data.get('closed_reason'),
    }


def _scheduled_query_run(data: dict[str, Any]) -> dict[str, Any]:
    return {
        'file_stripe_id': stripe_id_from(data.get('file')),
        'status': data.get('status'),
        'title': data.get('title'),
    }


def _pricing_table(data: dict[str, Any]) -> dict[str, Any]:
    return {'active': bool(data.get('active', True)), 'pricing_table_json': data}


PARITY_MODEL_SPECS: dict[str, tuple[type, Normalizer]] = {
    'account': (StripeAccount, _account),
    'coupon': (StripeCoupon, _coupon),
    'promotion_code': (StripePromotionCode, _promotion_code),
    'discount': (StripeDiscount, _discount),
    'invoiceitem': (StripeInvoiceItem, _invoice_item),
    'line_item': (StripeLineItem, _line_item),
    'plan': (StripePlan, _plan),
    'subscription_schedule': (StripeSubscriptionSchedule, _subscription_schedule),
    'shipping_rate': (StripeShippingRate, _shipping_rate),
    'tax_code': (StripeTaxCode, _tax_code),
    'tax_id': (StripeTaxId, _tax_id),
    'tax_rate': (StripeTaxRate, _tax_rate),
    'upcoming_invoice': (StripeUpcomingInvoice, _upcoming_invoice),
    'balance_transaction': (StripeBalanceTransaction, _balance_transaction),
    'charge': (StripeCharge, _charge),
    'dispute': (StripeDispute, _dispute),
    'stripe_event': (StripeEvent, _event),
    'file': (StripeFile, _file),
    'file_link': (StripeFileLink, _file_link),
    'file_upload': (StripeFileUpload, _file),
    'mandate': (StripeMandate, _mandate),
    'refund': (StripeRefund, _refund),
    'setup_intent': (StripeSetupIntent, _setup_intent),
    'payout': (StripePayout, _payout),
    'djstripe_payment_method': (StripeDjstripePaymentMethod, _payment_method_base),
    'bank_account': (StripeBankAccount, _bank_account),
    'card': (StripeCard, _card),
    'source': (StripeSource, _source),
    'source_transaction': (StripeSourceTransaction, _source_transaction),
    'application_fee': (StripeApplicationFee, _application_fee),
    'fee_refund': (StripeApplicationFeeRefund, _application_fee_refund),
    'country_spec': (StripeCountrySpec, _country_spec),
    'transfer': (StripeTransfer, _transfer),
    'transfer_reversal': (StripeTransferReversal, _transfer_reversal),
    'entitlements.feature': (StripeFeature, _feature),
    'product_feature': (StripeProductFeature, _product_feature),
    'entitlements.active_entitlement': (StripeActiveEntitlement, _active_entitlement),
    'identity.verification_session': (StripeVerificationSession, _verification_session),
    'identity.verification_report': (StripeVerificationReport, _verification_report),
    'issuing.authorization': (StripeIssuingAuthorization, _issuing_authorization),
    'issuing.cardholder': (StripeIssuingCardholder, _issuing_cardholder),
    'issuing.card': (StripeIssuingCard, _issuing_card),
    'issuing.dispute': (StripeIssuingDispute, _issuing_dispute),
    'issuing.transaction': (StripeIssuingTransaction, _issuing_transaction),
    'radar.early_fraud_warning': (StripeEarlyFraudWarning, _early_fraud_warning),
    'review': (StripeReview, _review),
    'scheduled_query_run': (StripeScheduledQueryRun, _scheduled_query_run),
    'pricing_table': (StripePricingTable, _pricing_table),
}

PARITY_SYNC_OBJECT_TYPES = set(PARITY_MODEL_SPECS)
PARITY_BOOTSTRAP_OBJECT_TYPES = {
    'account',
    'application_fee',
    'balance_transaction',
    'charge',
    'coupon',
    'country_spec',
    'dispute',
    'file',
    'file_link',
    'mandate',
    'payout',
    'plan',
    'price',
    'product',
    'promotion_code',
    'refund',
    'setup_intent',
    'shipping_rate',
    'source',
    'subscription',
    'subscription_schedule',
    'tax_code',
    'tax_rate',
    'transfer',
}
