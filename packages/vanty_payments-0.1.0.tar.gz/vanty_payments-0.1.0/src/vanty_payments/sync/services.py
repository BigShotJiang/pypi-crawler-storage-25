from __future__ import annotations

from typing import Any

from vanty_payments.core.context import ServiceContext
from vanty_payments.core.utils import as_dict, stripe_id_from, ts_to_datetime, utcnow
from vanty_payments.db.models import (
    StripeCheckoutSession,
    StripeCustomer,
    StripeEvent,
    StripeInvoice,
    StripeInvoiceLine,
    StripePaymentIntent,
    StripePaymentMethod,
    StripePrice,
    StripeProduct,
    StripeSubscription,
    StripeSubscriptionItem,
    StripeSyncRun,
    StripeWebhookEvent,
)
from vanty_payments.sync.parity import PARITY_MODEL_SPECS


class SyncService:
    def __init__(self, context: ServiceContext) -> None:
        self.context = context

    async def sync_by_type_and_id(self, object_type: str, stripe_id: str):
        data = self.context.stripe_client.retrieve_object(object_type, stripe_id)
        return await self.sync_stripe_object(data)

    async def bootstrap(self, object_types: list[str], *, limit: int = 100) -> StripeSyncRun:
        sync_run = await StripeSyncRun.create(
            mode="bootstrap",
            object_types_json=list(object_types),
            counts_json={},
            failures_json=[],
        )
        counts: dict[str, int] = {}
        failures: list[dict[str, Any]] = []
        for object_type in object_types:
            counts[object_type] = 0
            try:
                for item in self.context.stripe_client.list_objects(object_type, limit=limit):
                    await self.sync_stripe_object(item)
                    counts[object_type] += 1
            except Exception as exc:  # noqa: BLE001
                failures.append({"object_type": object_type, "error": str(exc)})
        sync_run.counts_json = counts
        sync_run.failures_json = failures
        sync_run.finished_at = utcnow()
        sync_run.succeeded = not failures
        await sync_run.save()
        self.context.events.record(
            "payments.sync.bootstrap.completed",
            {
                "sync_run_id": str(sync_run.id),
                "object_types": list(sync_run.object_types_json),
                "counts": dict(sync_run.counts_json),
                "succeeded": sync_run.succeeded,
            },
        )
        return sync_run

    async def sync_event(self, event: dict[str, Any]) -> StripeWebhookEvent:
        request = event.get("request") or {}
        if not isinstance(request, dict):
            request = {"id": request}
        webhook_event = await self._upsert(
            StripeWebhookEvent,
            event["id"],
            {
                **self._base_defaults(event),
                "type": event.get("type", "unknown"),
                "api_version": event.get("api_version"),
                "data_json": event.get("data", {}),
                "request_id": request.get("id"),
                "idempotency_key": request.get("idempotency_key"),
                "processed": False,
                "processing_error": None,
            },
        )
        await self._upsert(
            StripeEvent,
            event["id"],
            {
                **self._base_defaults(event),
                **PARITY_MODEL_SPECS["stripe_event"][1](event),
            },
        )
        try:
            await self.sync_stripe_object(event.get("data", {}).get("object", {}))
            webhook_event.processed = True
            webhook_event.processing_error = None
        except Exception as exc:  # noqa: BLE001
            webhook_event.processing_error = str(exc)
            webhook_event.processed = False
            webhook_event.sync_status = "failed"
        await webhook_event.save()
        return webhook_event

    async def sync_stripe_object(self, data: dict[str, Any] | Any):
        payload = as_dict(data)
        object_type = payload.get("object")
        if object_type == "customer":
            return await self.sync_customer(payload)
        if object_type == "product":
            return await self.sync_product(payload)
        if object_type == "price":
            return await self.sync_price(payload)
        if object_type == "payment_method":
            return await self.sync_payment_method(payload)
        if object_type == "payment_intent":
            return await self.sync_payment_intent(payload)
        if object_type == "subscription":
            return await self.sync_subscription(payload)
        if object_type == "invoice":
            return await self.sync_invoice(payload)
        if object_type == "checkout.session":
            return await self.sync_checkout_session(payload)
        if object_type == "event":
            return await self.sync_event(payload)
        spec = PARITY_MODEL_SPECS.get(object_type)
        if spec is None:
            return None
        model, normalizer = spec
        return await self._upsert(
            model,
            payload["id"],
            {
                **self._base_defaults(payload),
                **normalizer(payload),
            },
        )

    async def sync_customer(
        self,
        data: dict[str, Any],
        *,
        user_reference: str | None = None,
        organization_reference: str | None = None,
    ) -> StripeCustomer:
        metadata = data.get("metadata") or {}
        existing = await StripeCustomer.get_or_none(stripe_id=data["id"])
        customer = await self._upsert(
            StripeCustomer,
            data["id"],
            {
                **self._base_defaults(data),
                "user_reference": (
                    user_reference
                    or (existing.user_reference if existing else None)
                    or metadata.get(self.context.settings.customer_metadata_user_key)
                ),
                "organization_reference": (
                    organization_reference
                    or (existing.organization_reference if existing else None)
                    or metadata.get(self.context.settings.customer_metadata_org_key)
                ),
                "email": data.get("email"),
                "name": data.get("name"),
                "default_payment_method_id": stripe_id_from(
                    (data.get("invoice_settings") or {}).get("default_payment_method")
                ),
                "currency": data.get("currency"),
                "delinquent": bool(data.get("delinquent", False)),
            },
        )
        return customer

    async def sync_product(self, data: dict[str, Any]) -> StripeProduct:
        return await self._upsert(
            StripeProduct,
            data["id"],
            {
                **self._base_defaults(data),
                "name": data.get("name") or data["id"],
                "active": bool(data.get("active", True)),
                "description": data.get("description"),
                "default_price_id": stripe_id_from(data.get("default_price")),
                "product_type": data.get("type"),
            },
        )

    async def sync_price(self, data: dict[str, Any]) -> StripePrice:
        product = await self._maybe_sync_product(data.get("product"))
        recurring = data.get("recurring") or {}
        return await self._upsert(
            StripePrice,
            data["id"],
            {
                **self._base_defaults(data),
                "product": product,
                "currency": data.get("currency") or self.context.settings.default_currency,
                "unit_amount": data.get("unit_amount"),
                "active": bool(data.get("active", True)),
                "price_type": data.get("type") or "one_time",
                "recurring_interval": recurring.get("interval"),
                "recurring_interval_count": recurring.get("interval_count"),
                "nickname": data.get("nickname"),
            },
        )

    async def sync_payment_method(self, data: dict[str, Any]) -> StripePaymentMethod:
        customer = await self._maybe_sync_customer(data.get("customer"))
        card = data.get("card") or {}
        return await self._upsert(
            StripePaymentMethod,
            data["id"],
            {
                **self._base_defaults(data),
                "customer": customer,
                "type": data.get("type"),
                "brand": card.get("brand"),
                "last4": card.get("last4"),
                "exp_month": card.get("exp_month"),
                "exp_year": card.get("exp_year"),
                "fingerprint": card.get("fingerprint"),
            },
        )

    async def sync_payment_intent(self, data: dict[str, Any]) -> StripePaymentIntent:
        customer = await self._maybe_sync_customer(data.get("customer"))
        payment_method = await self._maybe_sync_payment_method(data.get("payment_method"))
        return await self._upsert(
            StripePaymentIntent,
            data["id"],
            {
                **self._base_defaults(data),
                "customer": customer,
                "payment_method": payment_method,
                "amount": int(data.get("amount") or 0),
                "amount_received": int(data.get("amount_received") or 0),
                "currency": data.get("currency"),
                "status": data.get("status"),
                "invoice_stripe_id": stripe_id_from(data.get("invoice")),
                "subscription_stripe_id": stripe_id_from(data.get("subscription")),
                "client_secret": data.get("client_secret"),
            },
        )

    async def sync_subscription(self, data: dict[str, Any]) -> StripeSubscription:
        customer = await self._maybe_sync_customer(data.get("customer"))
        default_payment_method = await self._maybe_sync_payment_method(data.get("default_payment_method"))
        items = ((data.get("items") or {}).get("data")) or []
        subscription = await self._upsert(
            StripeSubscription,
            data["id"],
            {
                **self._base_defaults(data),
                "customer": customer,
                "default_payment_method": default_payment_method,
                "status": data.get("status"),
                "currency": data.get("currency"),
                "current_period_start": ts_to_datetime(data.get("current_period_start")),
                "current_period_end": ts_to_datetime(data.get("current_period_end")),
                "cancel_at_period_end": bool(data.get("cancel_at_period_end", False)),
                "cancel_at": ts_to_datetime(data.get("cancel_at")),
                "canceled_at": ts_to_datetime(data.get("canceled_at")),
                "price_ids_json": [
                    stripe_id_from((item or {}).get("price")) for item in items if item
                ],
            },
        )
        for item in items:
            item_data = as_dict(item)
            if not item_data:
                continue
            price = await self._maybe_sync_price(item_data.get("price"))
            await self._upsert(
                StripeSubscriptionItem,
                item_data["id"],
                {
                    **self._base_defaults(item_data),
                    "subscription": subscription,
                    "price": price,
                    "quantity": int(item_data.get("quantity") or 1),
                },
            )
        return subscription

    async def sync_invoice(self, data: dict[str, Any]) -> StripeInvoice:
        customer = await self._maybe_sync_customer(data.get("customer"))
        subscription = await self._maybe_sync_subscription_ref(data.get("subscription"))
        payment_intent = await self._maybe_sync_payment_intent(data.get("payment_intent"))
        status_transitions = data.get("status_transitions") or {}
        invoice = await self._upsert(
            StripeInvoice,
            data["id"],
            {
                **self._base_defaults(data),
                "customer": customer,
                "subscription": subscription,
                "payment_intent": payment_intent,
                "number": data.get("number"),
                "status": data.get("status"),
                "currency": data.get("currency"),
                "subtotal": int(data.get("subtotal") or 0),
                "total": int(data.get("total") or 0),
                "amount_due": int(data.get("amount_due") or 0),
                "amount_paid": int(data.get("amount_paid") or 0),
                "hosted_invoice_url": data.get("hosted_invoice_url"),
                "invoice_pdf": data.get("invoice_pdf"),
                "period_start": ts_to_datetime(data.get("period_start")),
                "period_end": ts_to_datetime(data.get("period_end")),
                "paid_at": ts_to_datetime(status_transitions.get("paid_at")),
            },
        )
        lines = ((data.get("lines") or {}).get("data")) or []
        for line in lines:
            line_data = as_dict(line)
            if not line_data or "id" not in line_data:
                continue
            period = line_data.get("period") or {}
            await self._upsert(
                StripeInvoiceLine,
                line_data["id"],
                {
                    **self._base_defaults(line_data),
                    "invoice": invoice,
                    "stripe_price_id": (
                        stripe_id_from(
                            (line_data.get("pricing") or {})
                            .get("price_details", {})
                            .get("price")
                        )
                        or stripe_id_from(line_data.get("price"))
                    ),
                    "description": line_data.get("description"),
                    "quantity": int(line_data.get("quantity") or 1),
                    "amount": int(line_data.get("amount") or 0),
                    "currency": line_data.get("currency") or data.get("currency"),
                    "period_start": ts_to_datetime(period.get("start")),
                    "period_end": ts_to_datetime(period.get("end")),
                    "subscription_item_stripe_id": stripe_id_from(line_data.get("subscription_item")),
                },
            )
        return invoice

    async def sync_checkout_session(self, data: dict[str, Any]) -> StripeCheckoutSession:
        customer = await self._maybe_sync_customer(data.get("customer"))
        return await self._upsert(
            StripeCheckoutSession,
            data["id"],
            {
                **self._base_record_defaults(data),
                "customer": customer,
                "mode": data.get("mode") or "subscription",
                "status": data.get("status"),
                "payment_status": data.get("payment_status"),
                "url": data.get("url"),
                "success_url": data.get("success_url"),
                "cancel_url": data.get("cancel_url"),
                "client_reference_id": data.get("client_reference_id"),
                "line_items_json": list(data.get("line_items") or []),
                "completed_at": ts_to_datetime(data.get("expires_at")) if data.get("status") == "complete" else None,
                "subscription_stripe_id": stripe_id_from(data.get("subscription")),
                "payment_intent_stripe_id": stripe_id_from(data.get("payment_intent")),
                "workflow_state": data.get("status") or "created",
            },
        )

    def _base_record_defaults(self, data: dict[str, Any]) -> dict[str, Any]:
        return {
            "livemode": bool(data.get("livemode", False)),
            "stripe_created_at": ts_to_datetime(data.get("created")),
            "last_synced_at": utcnow(),
            "metadata_json": dict(data.get("metadata") or {}),
            "stripe_data_json": data,
        }

    def _base_defaults(self, data: dict[str, Any]) -> dict[str, Any]:
        return {
            **self._base_record_defaults(data),
            "sync_status": "synced",
        }

    async def _upsert(self, model, stripe_id: str, defaults: dict[str, Any]):
        instance = await model.get_or_none(stripe_id=stripe_id)
        if instance is None:
            return await model.create(stripe_id=stripe_id, **defaults)
        for key, value in defaults.items():
            setattr(instance, key, value)
        await instance.save()
        return instance

    async def _maybe_sync_customer(self, reference: Any) -> StripeCustomer | None:
        stripe_id = stripe_id_from(reference)
        if stripe_id is None:
            return None
        if isinstance(reference, dict):
            return await self.sync_customer(as_dict(reference))
        customer = await StripeCustomer.get_or_none(stripe_id=stripe_id)
        if customer is not None:
            return customer
        return await self._safe_fetch("customer", stripe_id)

    async def _maybe_sync_product(self, reference: Any) -> StripeProduct | None:
        stripe_id = stripe_id_from(reference)
        if stripe_id is None:
            return None
        if isinstance(reference, dict):
            return await self.sync_product(as_dict(reference))
        product = await StripeProduct.get_or_none(stripe_id=stripe_id)
        if product is not None:
            return product
        return await self._safe_fetch("product", stripe_id)

    async def _maybe_sync_price(self, reference: Any) -> StripePrice | None:
        stripe_id = stripe_id_from(reference)
        if stripe_id is None:
            return None
        if isinstance(reference, dict):
            return await self.sync_price(as_dict(reference))
        price = await StripePrice.get_or_none(stripe_id=stripe_id)
        if price is not None:
            return price
        return await self._safe_fetch("price", stripe_id)

    async def _maybe_sync_payment_method(self, reference: Any) -> StripePaymentMethod | None:
        stripe_id = stripe_id_from(reference)
        if stripe_id is None:
            return None
        if isinstance(reference, dict):
            return await self.sync_payment_method(as_dict(reference))
        payment_method = await StripePaymentMethod.get_or_none(stripe_id=stripe_id)
        if payment_method is not None:
            return payment_method
        return await self._safe_fetch("payment_method", stripe_id)

    async def _maybe_sync_payment_intent(self, reference: Any) -> StripePaymentIntent | None:
        stripe_id = stripe_id_from(reference)
        if stripe_id is None:
            return None
        if isinstance(reference, dict):
            return await self.sync_payment_intent(as_dict(reference))
        payment_intent = await StripePaymentIntent.get_or_none(stripe_id=stripe_id)
        if payment_intent is not None:
            return payment_intent
        return await self._safe_fetch("payment_intent", stripe_id)

    async def _maybe_sync_subscription_ref(self, reference: Any) -> StripeSubscription | None:
        stripe_id = stripe_id_from(reference)
        if stripe_id is None:
            return None
        if isinstance(reference, dict):
            return await self.sync_subscription(as_dict(reference))
        subscription = await StripeSubscription.get_or_none(stripe_id=stripe_id)
        if subscription is not None:
            return subscription
        return await self._safe_fetch("subscription", stripe_id)

    async def _safe_fetch(self, object_type: str, stripe_id: str):
        try:
            return await self.sync_by_type_and_id(object_type, stripe_id)
        except Exception:  # noqa: BLE001
            return None
