from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any

from tortoise.functions import Count, Sum

from vanty_payments.billing.constants import (
    BillingUsageMode,
    EmissionStatus,
    SubscriptionLifecycleState,
)
from vanty_payments.core.context import ServiceContext
from vanty_payments.customers.services import CustomerService
from vanty_payments.db.models import (
    BillingAccount,
    CreditLedgerEntry,
    InternalMeterEvent,
    Meter,
    StripeCustomer,
    StripeInvoice,
    StripePaymentMethod,
    StripeSubscription,
)

_ACTIVE_STATES = frozenset({
    SubscriptionLifecycleState.ACTIVE.value,
    SubscriptionLifecycleState.TRIALING.value,
})


class BillingService:
    def __init__(self, context: ServiceContext, customer_service: CustomerService) -> None:
        self.context = context
        self.customer_service = customer_service

    # ------------------------------------------------------------------
    # Legacy read methods (preserved for backward compat)
    # ------------------------------------------------------------------

    async def get_subscription(
        self,
        *,
        stripe_customer_id: str | None,
        user_reference: str | None,
        organization_reference: str | None,
    ) -> StripeSubscription | None:
        customer = await self.customer_service.resolve_customer(
            stripe_customer_id=stripe_customer_id,
            user_reference=user_reference,
            organization_reference=organization_reference,
        )
        if customer is None:
            return None
        return await (
            StripeSubscription.filter(customer=customer)
            .prefetch_related("customer")
            .order_by("-created_at")
            .first()
        )

    async def list_invoices(
        self,
        *,
        stripe_customer_id: str | None,
        user_reference: str | None,
        organization_reference: str | None,
    ) -> list[StripeInvoice]:
        customer = await self.customer_service.resolve_customer(
            stripe_customer_id=stripe_customer_id,
            user_reference=user_reference,
            organization_reference=organization_reference,
        )
        query = StripeInvoice.all().prefetch_related("customer", "subscription")
        if customer is not None:
            query = query.filter(customer=customer)
        return await query.order_by("-created_at")

    async def list_payment_methods(
        self,
        *,
        stripe_customer_id: str | None,
        user_reference: str | None,
        organization_reference: str | None,
    ) -> list[StripePaymentMethod]:
        customer = await self.customer_service.resolve_customer(
            stripe_customer_id=stripe_customer_id,
            user_reference=user_reference,
            organization_reference=organization_reference,
        )
        query = StripePaymentMethod.all().prefetch_related("customer")
        if customer is not None:
            query = query.filter(customer=customer)
        return await query.order_by("brand", "last4")

    # ------------------------------------------------------------------
    # Config
    # ------------------------------------------------------------------

    def get_billing_config(self) -> dict[str, Any]:
        s = self.context.settings
        return {
            "billing_usage_mode": s.billing_usage_mode,
            "billing_credits_enabled": s.billing_credits_enabled,
            "credit_factor": s.credit_factor,
            "stripe_trial_period_days": s.stripe_trial_period_days,
            "stripe_automatic_tax_enabled": s.stripe_automatic_tax_enabled,
            "stripe_cancel_at_period_end": s.stripe_cancel_at_period_end,
        }

    # ------------------------------------------------------------------
    # Billing account resolution
    # ------------------------------------------------------------------

    async def resolve_billing_account(
        self,
        *,
        user_reference: str | None = None,
        organization_reference: str | None = None,
        customer: StripeCustomer | None = None,
    ) -> BillingAccount:
        filters: dict[str, Any] = {}
        if organization_reference:
            filters["organization_reference"] = organization_reference
        elif user_reference:
            filters["user_reference"] = user_reference
        elif customer:
            filters["customer_id"] = customer.pk

        if filters:
            account = await BillingAccount.filter(**filters).first()
            if account:
                return account

        return await BillingAccount.create(
            customer=customer,
            user_reference=user_reference,
            organization_reference=organization_reference,
        )

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------

    async def get_billing_summary(self, billing_account: BillingAccount) -> dict[str, Any]:
        subscription: StripeSubscription | None = None
        if billing_account.customer_id:
            subscription = await (
                StripeSubscription.filter(customer_id=billing_account.customer_id)
                .prefetch_related("customer")
                .order_by("-created_at")
                .first()
            )

        credit_balance: Decimal | None = None
        if self.context.settings.billing_credits_enabled:
            bal = await self.get_credit_balance(billing_account)
            credit_balance = bal["net_balance"]

        is_active = billing_account.state in _ACTIVE_STATES

        return {
            "billing_account_id": billing_account.pk,
            "state": billing_account.state,
            "current_plan": billing_account.current_plan,
            "is_active": is_active,
            "has_subscription": subscription is not None,
            "subscription": subscription,
            "credit_balance": credit_balance,
        }

    # ------------------------------------------------------------------
    # Checkout confirm
    # ------------------------------------------------------------------

    async def confirm_checkout_session(
        self,
        session_id: str,
        billing_account: BillingAccount,
    ) -> dict[str, Any]:
        session_data = self.context.stripe_client.retrieve_checkout_session(session_id)
        subscription_id = session_data.get("subscription")

        billing_account.state = SubscriptionLifecycleState.ACTIVE.value
        if subscription_id:
            billing_account.current_plan = subscription_id
        await billing_account.save()

        if self.context.settings.billing_credits_enabled:
            await self._grant_credits_for_checkout(billing_account, session_data)

        return {
            "billing_account_id": billing_account.pk,
            "state": billing_account.state,
            "session_stripe_id": session_id,
            "subscription_stripe_id": subscription_id,
        }

    async def _grant_credits_for_checkout(
        self,
        billing_account: BillingAccount,
        session_data: dict[str, Any],
    ) -> None:
        ref = f"checkout_{session_data.get('id', '')}"
        existing = await CreditLedgerEntry.filter(
            billing_account=billing_account,
            reference_id=ref,
        ).first()
        if existing:
            return
        amount_total = session_data.get("amount_total", 0)
        credits = Decimal(amount_total) / Decimal(self.context.settings.credit_factor)
        if credits > 0:
            await CreditLedgerEntry.create(
                billing_account=billing_account,
                entry_type="subscription_grant",
                amount=credits,
                description="Credits from checkout",
                reference_id=ref,
            )

    # ------------------------------------------------------------------
    # Mutations
    # ------------------------------------------------------------------

    async def change_subscription_price(
        self,
        billing_account: BillingAccount,
        new_price_id: str,
    ) -> dict[str, Any]:
        sub = await self._require_subscription(billing_account)
        items_data = sub.stripe_data_json.get("items", {}).get("data", [])
        previous_price_id: str | None = None
        if items_data:
            previous_price_id = items_data[0].get("price", {}).get("id")
            item_id = items_data[0].get("id")
            result = self.context.stripe_client.modify_subscription(
                sub.stripe_id,
                items=[{"id": item_id, "price": new_price_id}],
            )
        else:
            result = self.context.stripe_client.modify_subscription(
                sub.stripe_id,
                items=[{"price": new_price_id}],
            )
        return {
            "subscription_stripe_id": sub.stripe_id,
            "previous_price_id": previous_price_id,
            "new_price_id": new_price_id,
            "status": result.get("status", "unknown"),
        }

    async def cancel_subscription(self, billing_account: BillingAccount) -> dict[str, Any]:
        sub = await self._require_subscription(billing_account)
        at_period_end = self.context.settings.stripe_cancel_at_period_end
        result = self.context.stripe_client.cancel_subscription(sub.stripe_id, at_period_end=at_period_end)

        if not at_period_end:
            billing_account.state = SubscriptionLifecycleState.CANCELED.value
            await billing_account.save()

        return {
            "subscription_stripe_id": sub.stripe_id,
            "status": result.get("status", "unknown"),
            "cancel_at_period_end": result.get("cancel_at_period_end", at_period_end),
        }

    async def reactivate_subscription(self, billing_account: BillingAccount) -> dict[str, Any]:
        sub = await self._require_subscription(billing_account)
        result = self.context.stripe_client.modify_subscription(
            sub.stripe_id,
            cancel_at_period_end=False,
        )
        billing_account.state = SubscriptionLifecycleState.ACTIVE.value
        await billing_account.save()
        return {
            "subscription_stripe_id": sub.stripe_id,
            "status": result.get("status", "unknown"),
            "cancel_at_period_end": False,
        }

    async def create_setup_intent(self, billing_account: BillingAccount) -> dict[str, Any]:
        customer = await self._require_customer(billing_account)
        result = self.context.stripe_client.create_setup_intent(
            customer=customer.stripe_id,
            usage="off_session",
        )
        return {
            "client_secret": result["client_secret"],
            "setup_intent_id": result["id"],
        }

    # ------------------------------------------------------------------
    # Usage metering
    # ------------------------------------------------------------------

    async def record_usage(
        self,
        billing_account: BillingAccount,
        *,
        event_name: str,
        value: int = 1,
        dimensions: dict[str, str] | None = None,
    ) -> InternalMeterEvent:
        meter = await Meter.filter(event_name=event_name, is_active=True).first()
        credit_cost = self._compute_credit_cost(meter, value, dimensions or {})

        customer = None
        if billing_account.customer_id:
            customer = await StripeCustomer.get(pk=billing_account.customer_id)

        event = await InternalMeterEvent.create(
            billing_account=billing_account,
            meter=meter,
            event_name=event_name,
            value=value,
            credit_cost=credit_cost,
            dimensions=dimensions or {},
            stripe_customer_id=customer.stripe_id if customer else None,
        )

        if self.context.settings.billing_credits_enabled and credit_cost > 0:
            await CreditLedgerEntry.create(
                billing_account=billing_account,
                entry_type="adjustment",
                amount=-credit_cost,
                description=f"Usage: {event_name} x{value}",
                reference_id=f"usage_{event.pk}",
            )

        usage_mode = self.context.settings.billing_usage_mode
        if usage_mode != BillingUsageMode.INTERNAL.value and customer:
            await self._emit_to_stripe(event, customer)

        return event

    def _compute_credit_cost(
        self,
        meter: Meter | None,
        value: int,
        dimensions: dict[str, str],
    ) -> Decimal:
        if meter is None:
            return Decimal(0)

        strategy = meter.pricing_strategy
        if strategy == "margin":
            raw_cost = Decimal(str(dimensions.get(meter.cost_dimension_key, "0")))
            return raw_cost * meter.margin_multiplier
        if strategy == "fixed_per_event":
            return meter.fixed_amount * value
        if strategy == "per_unit":
            return meter.unit_price * value
        return Decimal(0)

    async def _emit_to_stripe(
        self,
        event: InternalMeterEvent,
        customer: StripeCustomer,
    ) -> None:
        try:
            self.context.stripe_client.create_stripe_meter_event(
                event_name=event.event_name,
                payload={
                    "stripe_customer_id": customer.stripe_id,
                    "value": str(event.value),
                },
            )
            event.emission_status = EmissionStatus.SENT.value
        except Exception as exc:  # noqa: BLE001
            event.emission_status = EmissionStatus.FAILED.value
            event.stripe_sync_error = str(exc)
            event.stripe_sync_attempts += 1
        await event.save()

    async def get_usage_summary(
        self,
        billing_account: BillingAccount,
        *,
        since: datetime | None = None,
        until: datetime | None = None,
    ) -> dict[str, Any]:
        query = InternalMeterEvent.filter(billing_account=billing_account)
        if since:
            query = query.filter(occurred_at__gte=since)
        if until:
            query = query.filter(occurred_at__lte=until)
        result = await query.annotate(
            total_events=Count("id"),
            total_credit_cost=Sum("credit_cost"),
        ).values("total_events", "total_credit_cost")
        row = result[0] if result else {}
        return {
            "total_events": row.get("total_events", 0),
            "total_credit_cost": Decimal(str(row.get("total_credit_cost") or 0)),
            "period_start": since,
            "period_end": until,
        }

    async def list_usage_records(
        self,
        billing_account: BillingAccount,
        *,
        limit: int = 100,
    ) -> list[InternalMeterEvent]:
        return await (
            InternalMeterEvent.filter(billing_account=billing_account)
            .order_by("-occurred_at")
            .limit(limit)
        )

    # ------------------------------------------------------------------
    # Credits
    # ------------------------------------------------------------------

    async def get_credit_balance(self, billing_account: BillingAccount) -> dict[str, Decimal]:
        entries = await CreditLedgerEntry.filter(billing_account=billing_account).all()
        granted = sum((e.amount for e in entries if e.amount > 0), Decimal(0))
        consumed = sum((abs(e.amount) for e in entries if e.amount < 0), Decimal(0))
        return {
            "total_granted": granted,
            "total_consumed": consumed,
            "net_balance": granted - consumed,
        }

    async def list_credit_ledger(
        self,
        billing_account: BillingAccount,
        *,
        limit: int = 100,
    ) -> list[CreditLedgerEntry]:
        return await (
            CreditLedgerEntry.filter(billing_account=billing_account)
            .order_by("-effective_at")
            .limit(limit)
        )

    async def grant_credits(
        self,
        billing_account: BillingAccount,
        *,
        amount: Decimal,
        entry_type: str = "admin_grant",
        description: str = "",
        reference_id: str | None = None,
        expires_at: datetime | None = None,
    ) -> CreditLedgerEntry:
        if reference_id:
            existing = await CreditLedgerEntry.filter(
                billing_account=billing_account,
                reference_id=reference_id,
            ).first()
            if existing:
                return existing

        return await CreditLedgerEntry.create(
            billing_account=billing_account,
            entry_type=entry_type,
            amount=amount,
            description=description,
            reference_id=reference_id,
            expires_at=expires_at,
        )

    # ------------------------------------------------------------------
    # Entitlement
    # ------------------------------------------------------------------

    async def resolve_entitlement(self, billing_account: BillingAccount) -> dict[str, Any]:
        return {
            "is_active": billing_account.state in _ACTIVE_STATES,
            "has_subscription": billing_account.current_plan is not None,
            "plan": billing_account.current_plan,
            "state": billing_account.state,
        }

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    async def _require_subscription(self, billing_account: BillingAccount) -> StripeSubscription:
        if not billing_account.customer_id:
            raise ValueError("Billing account has no linked customer")
        sub = await (
            StripeSubscription.filter(customer_id=billing_account.customer_id)
            .order_by("-created_at")
            .first()
        )
        if sub is None:
            raise ValueError("No subscription found")
        return sub

    async def _require_customer(self, billing_account: BillingAccount) -> StripeCustomer:
        if not billing_account.customer_id:
            raise ValueError("Billing account has no linked customer")
        return await StripeCustomer.get(pk=billing_account.customer_id)
