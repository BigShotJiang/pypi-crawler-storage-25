from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from uuid import UUID

from pydantic import AliasPath, BaseModel, ConfigDict, Field


class PaymentMethodResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    stripe_id: str
    type: str | None = None
    brand: str | None = None
    last4: str | None = None
    exp_month: int | None = None
    exp_year: int | None = None
    customer_stripe_id: str | None = Field(default=None, validation_alias=AliasPath("customer", "stripe_id"))


class PaymentMethodsResponse(BaseModel):
    payment_methods: list[PaymentMethodResponse]


class SubscriptionResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    stripe_id: str
    status: str | None = None
    currency: str | None = None
    customer_stripe_id: str | None = Field(default=None, validation_alias=AliasPath("customer", "stripe_id"))
    current_period_start: datetime | None = None
    current_period_end: datetime | None = None
    cancel_at_period_end: bool


class InvoiceResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    stripe_id: str
    status: str | None = None
    currency: str | None = None
    total: int
    amount_due: int
    amount_paid: int
    customer_stripe_id: str | None = Field(default=None, validation_alias=AliasPath("customer", "stripe_id"))
    subscription_stripe_id: str | None = Field(default=None, validation_alias=AliasPath("subscription", "stripe_id"))
    hosted_invoice_url: str | None = None


class InvoicesResponse(BaseModel):
    invoices: list[InvoiceResponse]


# ---------------------------------------------------------------------------
# New schemas for billing parity
# ---------------------------------------------------------------------------


class BillingConfigResponse(BaseModel):
    billing_usage_mode: str
    billing_credits_enabled: bool
    credit_factor: int
    stripe_trial_period_days: int
    stripe_automatic_tax_enabled: bool
    stripe_cancel_at_period_end: bool


class BillingSummaryResponse(BaseModel):
    billing_account_id: UUID
    state: str
    current_plan: str | None = None
    is_active: bool
    has_subscription: bool
    subscription: SubscriptionResponse | None = None
    credit_balance: Decimal | None = None


class CheckoutConfirmResponse(BaseModel):
    billing_account_id: UUID
    state: str
    session_stripe_id: str
    subscription_stripe_id: str | None = None


class ChangePlanRequest(BaseModel):
    new_price_id: str


class ChangePlanResponse(BaseModel):
    subscription_stripe_id: str
    previous_price_id: str | None = None
    new_price_id: str
    status: str


class CancelSubscriptionResponse(BaseModel):
    subscription_stripe_id: str
    status: str
    cancel_at_period_end: bool


class SetupIntentResponse(BaseModel):
    client_secret: str
    setup_intent_id: str


class RecordUsageRequest(BaseModel):
    event_name: str
    value: int = 1
    dimensions: dict[str, str] = {}


class UsageRecordResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    event_name: str
    value: int
    credit_cost: Decimal
    emission_status: str
    occurred_at: datetime


class UsageSummaryResponse(BaseModel):
    total_events: int
    total_credit_cost: Decimal
    period_start: datetime | None = None
    period_end: datetime | None = None


class CreditBalanceResponse(BaseModel):
    total_granted: Decimal
    total_consumed: Decimal
    net_balance: Decimal


class CreditLedgerEntryResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    entry_type: str
    amount: Decimal
    description: str
    effective_at: datetime
    expires_at: datetime | None = None
    reference_id: str | None = None


class EntitlementResponse(BaseModel):
    is_active: bool
    has_subscription: bool
    plan: str | None = None
    state: str
