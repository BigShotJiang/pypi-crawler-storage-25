from __future__ import annotations

from uuid import UUID

from pydantic import AliasPath, BaseModel, ConfigDict, Field


class ProductResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    stripe_id: str
    name: str
    active: bool
    description: str | None = None
    default_price_id: str | None = None


class PriceResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    stripe_id: str
    product_stripe_id: str | None = Field(default=None, validation_alias=AliasPath("product", "stripe_id"))
    currency: str
    unit_amount: int | None = None
    active: bool
    price_type: str
    recurring_interval: str | None = None
    recurring_interval_count: int | None = None


class CatalogResponse(BaseModel):
    products: list[ProductResponse]
    prices: list[PriceResponse]
