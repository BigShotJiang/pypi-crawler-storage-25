from importlib.metadata import PackageNotFoundError, version

from vanty_payments.core.identity import IdentityContext
from vanty_payments.kit import PaymentsKit, mount_payments_router
from vanty_payments.settings import PaymentsKitSettings

try:
    __version__ = version("vanty-payments")
except PackageNotFoundError:
    __version__ = "0.1.0"

__all__ = [
    "IdentityContext",
    "PaymentsKit",
    "PaymentsKitSettings",
    "__version__",
    "mount_payments_router",
]
