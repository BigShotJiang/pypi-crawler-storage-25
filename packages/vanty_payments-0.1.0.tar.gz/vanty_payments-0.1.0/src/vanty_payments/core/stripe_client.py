from __future__ import annotations

from typing import Any

from vanty_payments.core.utils import as_dict
from vanty_payments.settings import PaymentsKitSettings

try:  # pragma: no cover - exercised indirectly when stripe is installed
    import stripe  # type: ignore
except ModuleNotFoundError:  # pragma: no cover - test fallback
    class _MissingStripeObject:
        def __getattr__(self, name: str):
            raise RuntimeError("The 'stripe' package is required to use vanty-payments runtime Stripe calls")

    class _MissingStripeModule:
        Customer = _MissingStripeObject()
        Product = _MissingStripeObject()
        Price = _MissingStripeObject()
        PaymentMethod = _MissingStripeObject()
        PaymentIntent = _MissingStripeObject()
        Subscription = _MissingStripeObject()
        Invoice = _MissingStripeObject()
        Event = _MissingStripeObject()
        Webhook = _MissingStripeObject()
        checkout = type("checkout", (), {"Session": _MissingStripeObject()})
        billing_portal = type("billing_portal", (), {"Session": _MissingStripeObject()})
        billing = type("billing", (), {
            "MeterEvent": _MissingStripeObject(),
            "CreditBalanceSummary": _MissingStripeObject(),
        })
        SetupIntent = _MissingStripeObject()

    stripe = _MissingStripeModule()


class StripeClient:
    def __init__(self, settings: PaymentsKitSettings) -> None:
        self.settings = settings

    def _request_kwargs(self, *, livemode: bool | None = None) -> dict[str, Any]:
        api_key = self.settings.stripe_secret_key
        if livemode is True and self.settings.stripe_live_secret_key:
            api_key = self.settings.stripe_live_secret_key
        elif livemode is False and self.settings.stripe_test_secret_key:
            api_key = self.settings.stripe_test_secret_key

        kwargs: dict[str, Any] = {"api_key": api_key}
        if self.settings.stripe_api_version:
            kwargs["stripe_version"] = self.settings.stripe_api_version
        return kwargs

    def _iter_list(self, result: Any):
        if hasattr(result, "auto_paging_iter"):
            yield from result.auto_paging_iter()
            return
        if isinstance(result, dict) and "data" in result:
            yield from result["data"]
            return
        if isinstance(result, list):
            yield from result
            return
        if result is None:
            return
        yield from result

    def create_customer(self, **kwargs: Any) -> dict[str, Any]:
        return as_dict(stripe.Customer.create(**kwargs, **self._request_kwargs()))

    def create_checkout_session(self, **kwargs: Any) -> dict[str, Any]:
        return as_dict(stripe.checkout.Session.create(**kwargs, **self._request_kwargs()))

    def create_billing_portal_session(self, **kwargs: Any) -> dict[str, Any]:
        return as_dict(stripe.billing_portal.Session.create(**kwargs, **self._request_kwargs()))

    def retrieve_checkout_session(self, session_id: str) -> dict[str, Any]:
        return as_dict(stripe.checkout.Session.retrieve(session_id, **self._request_kwargs()))

    def modify_subscription(self, subscription_id: str, **kwargs: Any) -> dict[str, Any]:
        return as_dict(stripe.Subscription.modify(subscription_id, **kwargs, **self._request_kwargs()))

    def cancel_subscription(self, subscription_id: str, *, at_period_end: bool = True) -> dict[str, Any]:
        if at_period_end:
            return self.modify_subscription(subscription_id, cancel_at_period_end=True)
        return as_dict(stripe.Subscription.cancel(subscription_id, **self._request_kwargs()))

    def create_setup_intent(self, **kwargs: Any) -> dict[str, Any]:
        return as_dict(stripe.SetupIntent.create(**kwargs, **self._request_kwargs()))

    def create_stripe_meter_event(self, **kwargs: Any) -> dict[str, Any]:
        return as_dict(stripe.billing.MeterEvent.create(**kwargs, **self._request_kwargs()))

    def retrieve_credit_balance_summary(self, customer: str) -> dict[str, Any]:
        return as_dict(stripe.billing.CreditBalanceSummary.retrieve(customer=customer, **self._request_kwargs()))

    def construct_event(self, *, payload: bytes, sig_header: str) -> dict[str, Any]:
        event = stripe.Webhook.construct_event(
            payload=payload,
            sig_header=sig_header,
            secret=self.settings.stripe_webhook_secret,
            tolerance=self.settings.webhook_tolerance_seconds,
        )
        return as_dict(event)

    def retrieve_object(self, object_type: str, stripe_id: str) -> dict[str, Any]:
        api_object = self._api_object_for(object_type)
        return as_dict(api_object.retrieve(stripe_id, **self._request_kwargs()))

    def list_objects(self, object_type: str, *, limit: int = 100):
        api_object = self._api_object_for(object_type)
        if not hasattr(api_object, "list"):
            raise ValueError(f"Object type '{object_type}' does not support list()")
        return [as_dict(item) for item in self._iter_list(api_object.list(limit=limit, **self._request_kwargs()))]

    @staticmethod
    def _api_object_for(object_type: str):
        mapping = {
            "account": "Account",
            "application_fee": "ApplicationFee",
            "bank_account": "BankAccount",
            "balance_transaction": "BalanceTransaction",
            "card": "Card",
            "charge": "Charge",
            "checkout.session": "checkout.Session",
            "country_spec": "CountrySpec",
            "coupon": "Coupon",
            "customer": "Customer",
            "discount": "Discount",
            "dispute": "Dispute",
            "entitlements.active_entitlement": "entitlements.ActiveEntitlement",
            "entitlements.feature": "entitlements.Feature",
            "event": "Event",
            "fee_refund": "FeeRefund",
            "file": "File",
            "file_link": "FileLink",
            "file_upload": "File",
            "identity.verification_report": "identity.VerificationReport",
            "identity.verification_session": "identity.VerificationSession",
            "invoice": "Invoice",
            "invoiceitem": "InvoiceItem",
            "issuing.authorization": "issuing.Authorization",
            "issuing.card": "issuing.Card",
            "issuing.cardholder": "issuing.Cardholder",
            "issuing.dispute": "issuing.Dispute",
            "issuing.transaction": "issuing.Transaction",
            "mandate": "Mandate",
            "payment_intent": "PaymentIntent",
            "payment_method": "PaymentMethod",
            "payout": "Payout",
            "plan": "Plan",
            "price": "Price",
            "pricing_table": "PricingTable",
            "product": "Product",
            "product_feature": "ProductFeature",
            "promotion_code": "PromotionCode",
            "radar.early_fraud_warning": "radar.EarlyFraudWarning",
            "refund": "Refund",
            "review": "Review",
            "scheduled_query_run": "sigma.ScheduledQueryRun",
            "setup_intent": "SetupIntent",
            "shipping_rate": "ShippingRate",
            "source": "Source",
            "source_transaction": "SourceTransaction",
            "subscription": "Subscription",
            "subscription_schedule": "SubscriptionSchedule",
            "tax_code": "TaxCode",
            "tax_id": "TaxId",
            "tax_rate": "TaxRate",
            "transfer": "Transfer",
            "transfer_reversal": "TransferReversal",
            "upcoming_invoice": "Invoice",
        }
        try:
            path = mapping[object_type]
        except KeyError as exc:
            raise ValueError(f"Unsupported Stripe object type: {object_type}") from exc
        obj: Any = stripe
        for part in path.split("."):
            obj = getattr(obj, part)
        return obj
