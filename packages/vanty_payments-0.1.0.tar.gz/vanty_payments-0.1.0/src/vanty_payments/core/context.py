from __future__ import annotations

from dataclasses import dataclass

from vanty_payments.core.events import EventRecorder
from vanty_payments.core.stripe_client import StripeClient
from vanty_payments.settings import PaymentsKitSettings


@dataclass(slots=True)
class ServiceContext:
    settings: PaymentsKitSettings
    stripe_client: StripeClient
    events: EventRecorder
