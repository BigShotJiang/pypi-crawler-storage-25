# ruff: noqa: E402, I001
from __future__ import annotations

import uuid

from tortoise import fields
from tortoise.models import Model


class TimestampedModel(Model):
    id = fields.UUIDField(primary_key=True, default=uuid.uuid4)
    created_at = fields.DatetimeField(auto_now_add=True)
    updated_at = fields.DatetimeField(auto_now=True)

    class Meta:
        abstract = True


class StripeRecordModel(TimestampedModel):
    stripe_id = fields.CharField(max_length=255, unique=True)
    livemode = fields.BooleanField(default=False)
    stripe_created_at = fields.DatetimeField(null=True)
    last_synced_at = fields.DatetimeField(null=True)
    metadata_json = fields.JSONField(default=dict)
    stripe_data_json = fields.JSONField(default=dict)

    class Meta:
        abstract = True


class StripeSyncModel(StripeRecordModel):
    sync_status = fields.CharField(max_length=32, default="synced")

    class Meta:
        abstract = True


class StripeWorkflowModel(StripeRecordModel):
    workflow_origin = fields.CharField(max_length=32, default="app")
    workflow_state = fields.CharField(max_length=32, default="created")

    class Meta:
        abstract = True


class StripeCustomer(StripeSyncModel):
    user_reference = fields.CharField(max_length=255, null=True, db_index=True)
    organization_reference = fields.CharField(max_length=255, null=True, db_index=True)
    email = fields.CharField(max_length=320, null=True)
    name = fields.CharField(max_length=255, null=True)
    default_payment_method_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    delinquent = fields.BooleanField(default=False)


class StripeProduct(StripeSyncModel):
    name = fields.CharField(max_length=255)
    active = fields.BooleanField(default=True)
    description = fields.TextField(null=True)
    default_price_id = fields.CharField(max_length=255, null=True)
    product_type = fields.CharField(max_length=64, null=True)


class StripePrice(StripeSyncModel):
    product = fields.ForeignKeyField(
        "models.StripeProduct",
        related_name="prices",
        null=True,
        on_delete=fields.SET_NULL,
    )
    currency = fields.CharField(max_length=12)
    unit_amount = fields.BigIntField(null=True)
    active = fields.BooleanField(default=True)
    price_type = fields.CharField(max_length=32, default="one_time")
    recurring_interval = fields.CharField(max_length=32, null=True)
    recurring_interval_count = fields.IntField(null=True)
    nickname = fields.CharField(max_length=255, null=True)


class StripePaymentMethod(StripeSyncModel):
    customer = fields.ForeignKeyField(
        "models.StripeCustomer",
        related_name="payment_methods",
        null=True,
        on_delete=fields.SET_NULL,
    )
    type = fields.CharField(max_length=64, null=True)
    brand = fields.CharField(max_length=64, null=True)
    last4 = fields.CharField(max_length=8, null=True)
    exp_month = fields.IntField(null=True)
    exp_year = fields.IntField(null=True)
    fingerprint = fields.CharField(max_length=255, null=True)


class StripePaymentIntent(StripeSyncModel):
    customer = fields.ForeignKeyField(
        "models.StripeCustomer",
        related_name="payment_intents",
        null=True,
        on_delete=fields.SET_NULL,
    )
    payment_method = fields.ForeignKeyField(
        "models.StripePaymentMethod",
        related_name="payment_intents",
        null=True,
        on_delete=fields.SET_NULL,
    )
    amount = fields.BigIntField(default=0)
    amount_received = fields.BigIntField(default=0)
    currency = fields.CharField(max_length=12, null=True)
    status = fields.CharField(max_length=64, null=True)
    invoice_stripe_id = fields.CharField(max_length=255, null=True)
    subscription_stripe_id = fields.CharField(max_length=255, null=True)
    client_secret = fields.CharField(max_length=255, null=True)


class StripeSubscription(StripeSyncModel):
    customer = fields.ForeignKeyField(
        "models.StripeCustomer",
        related_name="subscriptions",
        null=True,
        on_delete=fields.SET_NULL,
    )
    default_payment_method = fields.ForeignKeyField(
        "models.StripePaymentMethod",
        related_name="subscriptions",
        null=True,
        on_delete=fields.SET_NULL,
    )
    status = fields.CharField(max_length=64, null=True)
    currency = fields.CharField(max_length=12, null=True)
    current_period_start = fields.DatetimeField(null=True)
    current_period_end = fields.DatetimeField(null=True)
    cancel_at_period_end = fields.BooleanField(default=False)
    cancel_at = fields.DatetimeField(null=True)
    canceled_at = fields.DatetimeField(null=True)
    price_ids_json = fields.JSONField(default=list)


class StripeSubscriptionItem(StripeSyncModel):
    subscription = fields.ForeignKeyField(
        "models.StripeSubscription",
        related_name="items",
        on_delete=fields.CASCADE,
    )
    price = fields.ForeignKeyField(
        "models.StripePrice",
        related_name="subscription_items",
        null=True,
        on_delete=fields.SET_NULL,
    )
    quantity = fields.IntField(default=1)


class StripeInvoice(StripeSyncModel):
    customer = fields.ForeignKeyField(
        "models.StripeCustomer",
        related_name="invoices",
        null=True,
        on_delete=fields.SET_NULL,
    )
    subscription = fields.ForeignKeyField(
        "models.StripeSubscription",
        related_name="invoices",
        null=True,
        on_delete=fields.SET_NULL,
    )
    payment_intent = fields.ForeignKeyField(
        "models.StripePaymentIntent",
        related_name="invoices",
        null=True,
        on_delete=fields.SET_NULL,
    )
    number = fields.CharField(max_length=128, null=True)
    status = fields.CharField(max_length=64, null=True)
    currency = fields.CharField(max_length=12, null=True)
    subtotal = fields.BigIntField(default=0)
    total = fields.BigIntField(default=0)
    amount_due = fields.BigIntField(default=0)
    amount_paid = fields.BigIntField(default=0)
    hosted_invoice_url = fields.TextField(null=True)
    invoice_pdf = fields.TextField(null=True)
    period_start = fields.DatetimeField(null=True)
    period_end = fields.DatetimeField(null=True)
    paid_at = fields.DatetimeField(null=True)


class StripeInvoiceLine(StripeSyncModel):
    invoice = fields.ForeignKeyField(
        "models.StripeInvoice",
        related_name="lines",
        on_delete=fields.CASCADE,
    )
    stripe_price_id = fields.CharField(max_length=255, null=True)
    description = fields.TextField(null=True)
    quantity = fields.IntField(default=1)
    amount = fields.BigIntField(default=0)
    currency = fields.CharField(max_length=12, null=True)
    period_start = fields.DatetimeField(null=True)
    period_end = fields.DatetimeField(null=True)
    subscription_item_stripe_id = fields.CharField(max_length=255, null=True)


class StripeCheckoutSession(StripeWorkflowModel):
    customer = fields.ForeignKeyField(
        "models.StripeCustomer",
        related_name="checkout_sessions",
        null=True,
        on_delete=fields.SET_NULL,
    )
    mode = fields.CharField(max_length=32, default="subscription")
    status = fields.CharField(max_length=64, null=True)
    payment_status = fields.CharField(max_length=64, null=True)
    url = fields.TextField(null=True)
    success_url = fields.TextField(null=True)
    cancel_url = fields.TextField(null=True)
    client_reference_id = fields.CharField(max_length=255, null=True)
    line_items_json = fields.JSONField(default=list)
    completed_at = fields.DatetimeField(null=True)
    subscription_stripe_id = fields.CharField(max_length=255, null=True)
    payment_intent_stripe_id = fields.CharField(max_length=255, null=True)


class StripeWebhookEndpoint(TimestampedModel):
    stripe_id = fields.CharField(max_length=255, unique=True, null=True)
    livemode = fields.BooleanField(default=False)
    url = fields.TextField()
    secret = fields.CharField(max_length=255)
    enabled_events = fields.JSONField(default=list)
    api_version = fields.CharField(max_length=64, null=True)
    active = fields.BooleanField(default=True)


class StripeWebhookEvent(StripeSyncModel):
    type = fields.CharField(max_length=255)
    api_version = fields.CharField(max_length=64, null=True)
    data_json = fields.JSONField(default=dict)
    request_id = fields.CharField(max_length=255, null=True)
    idempotency_key = fields.CharField(max_length=255, null=True)
    processed = fields.BooleanField(default=False)
    processing_error = fields.TextField(null=True)


class StripeWebhookDelivery(TimestampedModel):
    signature = fields.TextField(null=True)
    remote_ip = fields.CharField(max_length=64, null=True)
    headers = fields.JSONField(default=dict)
    body = fields.TextField()
    valid = fields.BooleanField(default=False)
    processed = fields.BooleanField(default=False)
    exception = fields.CharField(max_length=255, null=True)
    traceback = fields.TextField(null=True)
    webhook_event = fields.ForeignKeyField(
        "models.StripeWebhookEvent",
        related_name="deliveries",
        null=True,
        on_delete=fields.SET_NULL,
    )


class StripeSyncRun(TimestampedModel):
    mode = fields.CharField(max_length=32, default="bootstrap")
    object_types_json = fields.JSONField(default=list)
    counts_json = fields.JSONField(default=dict)
    failures_json = fields.JSONField(default=list)
    started_at = fields.DatetimeField(auto_now_add=True)
    finished_at = fields.DatetimeField(null=True)
    succeeded = fields.BooleanField(default=False)


class BillingAccount(TimestampedModel):
    customer = fields.ForeignKeyField(
        "models.StripeCustomer",
        related_name="billing_accounts",
        null=True,
        on_delete=fields.SET_NULL,
    )
    user_reference = fields.CharField(max_length=255, null=True, db_index=True)
    organization_reference = fields.CharField(max_length=255, null=True, db_index=True)
    state = fields.CharField(max_length=64, default="not_subscribed")
    current_plan = fields.CharField(max_length=255, null=True)
    admin_approved = fields.BooleanField(default=False)


class ProductConfig(TimestampedModel):
    product = fields.ForeignKeyField(
        "models.StripeProduct",
        related_name="config",
        null=True,
        on_delete=fields.SET_NULL,
    )
    show_in_ui = fields.BooleanField(default=False)
    show_in_price_table = fields.BooleanField(default=False)
    weight = fields.IntField(default=1)
    min_quantity = fields.IntField(default=1)
    max_quantity = fields.IntField(default=1)
    editable_quantity = fields.BooleanField(default=False)
    unit_of_measure = fields.CharField(max_length=64, null=True)
    marketing_features = fields.JSONField(default=list)
    pricing_page_price_ids = fields.JSONField(default=list)


class Meter(TimestampedModel):
    event_name = fields.CharField(max_length=255, unique=True, db_index=True)
    display_name = fields.CharField(max_length=255)
    description = fields.TextField(default="")
    is_active = fields.BooleanField(default=True)
    pricing_strategy = fields.CharField(max_length=32, default="margin")
    margin_multiplier = fields.DecimalField(max_digits=6, decimal_places=3, default=1.5)
    fixed_amount = fields.DecimalField(max_digits=12, decimal_places=6, default=0)
    unit_price = fields.DecimalField(max_digits=12, decimal_places=8, default=0)
    cost_dimension_key = fields.CharField(max_length=100, default="total_cost")


class InternalMeterEvent(TimestampedModel):
    billing_account = fields.ForeignKeyField(
        "models.BillingAccount",
        related_name="meter_events",
        on_delete=fields.CASCADE,
    )
    meter = fields.ForeignKeyField(
        "models.Meter",
        related_name="events",
        null=True,
        on_delete=fields.SET_NULL,
    )
    event_name = fields.CharField(max_length=255, db_index=True)
    value = fields.IntField()
    credit_cost = fields.DecimalField(max_digits=12, decimal_places=6, default=0)
    dimensions = fields.JSONField(default=dict)
    occurred_at = fields.DatetimeField(auto_now_add=True)
    emission_status = fields.CharField(max_length=32, default="pending")
    stripe_customer_id = fields.CharField(max_length=255, null=True)
    stripe_identifier = fields.CharField(max_length=255, null=True, unique=True)
    stripe_synced_at = fields.DatetimeField(null=True)
    stripe_sync_error = fields.TextField(null=True)
    stripe_sync_attempts = fields.IntField(default=0)


class CreditLedgerEntry(TimestampedModel):
    billing_account = fields.ForeignKeyField(
        "models.BillingAccount",
        related_name="credit_entries",
        on_delete=fields.CASCADE,
    )
    entry_type = fields.CharField(max_length=32, db_index=True)
    amount = fields.DecimalField(max_digits=12, decimal_places=6)
    description = fields.TextField(default="")
    effective_at = fields.DatetimeField(auto_now_add=True)
    expires_at = fields.DatetimeField(null=True)
    reference_id = fields.CharField(max_length=255, null=True)


from vanty_payments.db.parity_models import (
    StripeAccount,
    StripeApiKey,
    StripeIdempotencyKey,
    StripeCoupon,
    StripePromotionCode,
    StripeDiscount,
    StripeInvoiceItem,
    StripeLineItem,
    StripePlan,
    StripeSubscriptionSchedule,
    StripeShippingRate,
    StripeTaxCode,
    StripeTaxId,
    StripeTaxRate,
    StripeUpcomingInvoice,
    StripeBalanceTransaction,
    StripeCharge,
    StripeDispute,
    StripeEvent,
    StripeFile,
    StripeFileLink,
    StripeFileUpload,
    StripeMandate,
    StripeRefund,
    StripeSetupIntent,
    StripePayout,
    StripeDjstripePaymentMethod,
    StripeBankAccount,
    StripeCard,
    StripeSource,
    StripeSourceTransaction,
    StripeApplicationFee,
    StripeApplicationFeeRefund,
    StripeCountrySpec,
    StripeTransfer,
    StripeTransferReversal,
    StripeFeature,
    StripeProductFeature,
    StripeActiveEntitlement,
    StripeVerificationSession,
    StripeVerificationReport,
    StripeIssuingAuthorization,
    StripeIssuingCard,
    StripeIssuingCardholder,
    StripeIssuingDispute,
    StripeIssuingTransaction,
    StripeEarlyFraudWarning,
    StripeReview,
    StripeScheduledQueryRun,
    StripePricingTable,
)


__models__ = [
    StripeCustomer,
    StripeProduct,
    StripePrice,
    StripePaymentMethod,
    StripePaymentIntent,
    StripeSubscription,
    StripeSubscriptionItem,
    StripeInvoice,
    StripeInvoiceLine,
    StripeCheckoutSession,
    StripeWebhookEndpoint,
    StripeWebhookEvent,
    StripeWebhookDelivery,
    StripeSyncRun,
    BillingAccount,
    ProductConfig,
    Meter,
    InternalMeterEvent,
    CreditLedgerEntry,
    StripeAccount,
    StripeApiKey,
    StripeIdempotencyKey,
    StripeCoupon,
    StripePromotionCode,
    StripeDiscount,
    StripeInvoiceItem,
    StripeLineItem,
    StripePlan,
    StripeSubscriptionSchedule,
    StripeShippingRate,
    StripeTaxCode,
    StripeTaxId,
    StripeTaxRate,
    StripeUpcomingInvoice,
    StripeBalanceTransaction,
    StripeCharge,
    StripeDispute,
    StripeEvent,
    StripeFile,
    StripeFileLink,
    StripeFileUpload,
    StripeMandate,
    StripeRefund,
    StripeSetupIntent,
    StripePayout,
    StripeDjstripePaymentMethod,
    StripeBankAccount,
    StripeCard,
    StripeSource,
    StripeSourceTransaction,
    StripeApplicationFee,
    StripeApplicationFeeRefund,
    StripeCountrySpec,
    StripeTransfer,
    StripeTransferReversal,
    StripeFeature,
    StripeProductFeature,
    StripeActiveEntitlement,
    StripeVerificationSession,
    StripeVerificationReport,
    StripeIssuingAuthorization,
    StripeIssuingCard,
    StripeIssuingCardholder,
    StripeIssuingDispute,
    StripeIssuingTransaction,
    StripeEarlyFraudWarning,
    StripeReview,
    StripeScheduledQueryRun,
    StripePricingTable,
]
