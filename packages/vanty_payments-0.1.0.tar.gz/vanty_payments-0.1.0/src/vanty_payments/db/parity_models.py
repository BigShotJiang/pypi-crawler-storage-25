from __future__ import annotations

from tortoise import fields

from vanty_payments.db.models import StripeRecordModel, StripeSyncModel, TimestampedModel


class StripeAccount(StripeSyncModel):
    email = fields.CharField(max_length=320, null=True)
    country = fields.CharField(max_length=8, null=True)
    default_currency = fields.CharField(max_length=12, null=True)
    business_type = fields.CharField(max_length=64, null=True)
    charges_enabled = fields.BooleanField(default=False)
    payouts_enabled = fields.BooleanField(default=False)
    details_submitted = fields.BooleanField(default=False)


class StripeApiKey(StripeRecordModel):
    key_type = fields.CharField(max_length=32)
    name = fields.CharField(max_length=255, null=True)
    secret_redacted = fields.CharField(max_length=255)
    owner_account_stripe_id = fields.CharField(max_length=255, null=True)


class StripeIdempotencyKey(TimestampedModel):
    key = fields.CharField(max_length=255, unique=True)
    action = fields.CharField(max_length=255)
    livemode = fields.BooleanField(default=False)


class StripeCoupon(StripeSyncModel):
    name = fields.CharField(max_length=255, null=True)
    duration = fields.CharField(max_length=32, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount_off = fields.BigIntField(null=True)
    percent_off = fields.FloatField(null=True)
    valid = fields.BooleanField(default=True)


class StripePromotionCode(StripeSyncModel):
    coupon_stripe_id = fields.CharField(max_length=255, null=True)
    code = fields.CharField(max_length=255)
    active = fields.BooleanField(default=True)
    customer_stripe_id = fields.CharField(max_length=255, null=True)


class StripeDiscount(StripeSyncModel):
    coupon_stripe_id = fields.CharField(max_length=255, null=True)
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    subscription_stripe_id = fields.CharField(max_length=255, null=True)
    invoice_stripe_id = fields.CharField(max_length=255, null=True)
    start_at = fields.DatetimeField(null=True)
    end_at = fields.DatetimeField(null=True)


class StripeInvoiceItem(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    invoice_stripe_id = fields.CharField(max_length=255, null=True)
    price_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    quantity = fields.IntField(null=True)
    description = fields.TextField(null=True)


class StripeLineItem(StripeSyncModel):
    invoice_stripe_id = fields.CharField(max_length=255, null=True)
    checkout_session_stripe_id = fields.CharField(max_length=255, null=True)
    price_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    quantity = fields.IntField(null=True)
    description = fields.TextField(null=True)


class StripePlan(StripeSyncModel):
    product_stripe_id = fields.CharField(max_length=255, null=True)
    nickname = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    interval = fields.CharField(max_length=32, null=True)
    interval_count = fields.IntField(null=True)
    active = fields.BooleanField(default=True)


class StripeSubscriptionSchedule(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    subscription_stripe_id = fields.CharField(max_length=255, null=True)
    status = fields.CharField(max_length=64, null=True)
    released_subscription_stripe_id = fields.CharField(max_length=255, null=True)
    current_phase_json = fields.JSONField(default=dict)


class StripeShippingRate(StripeSyncModel):
    display_name = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    fixed_amount = fields.BigIntField(null=True)
    active = fields.BooleanField(default=True)
    delivery_estimate_json = fields.JSONField(default=dict)


class StripeTaxCode(StripeSyncModel):
    name = fields.CharField(max_length=255, null=True)
    description = fields.TextField(null=True)


class StripeTaxId(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    country = fields.CharField(max_length=8, null=True)
    type = fields.CharField(max_length=64, null=True)
    value = fields.CharField(max_length=255, null=True)
    verification_json = fields.JSONField(default=dict)


class StripeTaxRate(StripeSyncModel):
    display_name = fields.CharField(max_length=255, null=True)
    jurisdiction = fields.CharField(max_length=255, null=True)
    country = fields.CharField(max_length=8, null=True)
    state = fields.CharField(max_length=64, null=True)
    percentage = fields.FloatField(null=True)
    inclusive = fields.BooleanField(default=False)
    active = fields.BooleanField(default=True)


class StripeUpcomingInvoice(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    subscription_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    total = fields.BigIntField(null=True)
    amount_due = fields.BigIntField(null=True)
    status = fields.CharField(max_length=64, null=True)


class StripeBalanceTransaction(StripeSyncModel):
    source_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    fee = fields.BigIntField(null=True)
    net = fields.BigIntField(null=True)
    type = fields.CharField(max_length=64, null=True)
    reporting_category = fields.CharField(max_length=64, null=True)


class StripeCharge(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    payment_intent_stripe_id = fields.CharField(max_length=255, null=True)
    dispute_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    amount_refunded = fields.BigIntField(null=True)
    status = fields.CharField(max_length=64, null=True)
    paid = fields.BooleanField(default=False)
    refunded = fields.BooleanField(default=False)


class StripeDispute(StripeSyncModel):
    charge_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    reason = fields.CharField(max_length=255, null=True)
    status = fields.CharField(max_length=64, null=True)


class StripeEvent(StripeSyncModel):
    event_type = fields.CharField(max_length=255)
    api_version = fields.CharField(max_length=64, null=True)
    request_id = fields.CharField(max_length=255, null=True)
    idempotency_key = fields.CharField(max_length=255, null=True)
    pending_webhooks = fields.IntField(null=True)


class StripeFile(StripeSyncModel):
    filename = fields.CharField(max_length=255, null=True)
    purpose = fields.CharField(max_length=128, null=True)
    file_type = fields.CharField(max_length=128, null=True)
    size = fields.BigIntField(null=True)
    url = fields.TextField(null=True)


class StripeFileLink(StripeSyncModel):
    file_stripe_id = fields.CharField(max_length=255, null=True)
    url = fields.TextField(null=True)
    expired = fields.BooleanField(default=False)
    expires_at = fields.DatetimeField(null=True)


class StripeFileUpload(StripeSyncModel):
    filename = fields.CharField(max_length=255, null=True)
    purpose = fields.CharField(max_length=128, null=True)
    file_type = fields.CharField(max_length=128, null=True)
    size = fields.BigIntField(null=True)
    url = fields.TextField(null=True)


class StripeMandate(StripeSyncModel):
    customer_acceptance_json = fields.JSONField(default=dict)
    payment_method_stripe_id = fields.CharField(max_length=255, null=True)
    mandate_type = fields.CharField(max_length=64, null=True)
    status = fields.CharField(max_length=64, null=True)


class StripeRefund(StripeSyncModel):
    charge_stripe_id = fields.CharField(max_length=255, null=True)
    payment_intent_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    reason = fields.CharField(max_length=255, null=True)
    status = fields.CharField(max_length=64, null=True)


class StripeSetupIntent(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    payment_method_stripe_id = fields.CharField(max_length=255, null=True)
    status = fields.CharField(max_length=64, null=True)
    usage = fields.CharField(max_length=64, null=True)
    client_secret = fields.CharField(max_length=255, null=True)


class StripePayout(StripeSyncModel):
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    arrival_date = fields.DatetimeField(null=True)
    payout_type = fields.CharField(max_length=64, null=True)
    status = fields.CharField(max_length=64, null=True)


class StripeDjstripePaymentMethod(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    method_type = fields.CharField(max_length=64, null=True)
    billing_details_json = fields.JSONField(default=dict)


class StripeBankAccount(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    bank_name = fields.CharField(max_length=255, null=True)
    country = fields.CharField(max_length=8, null=True)
    currency = fields.CharField(max_length=12, null=True)
    last4 = fields.CharField(max_length=8, null=True)
    status = fields.CharField(max_length=64, null=True)


class StripeCard(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    brand = fields.CharField(max_length=64, null=True)
    country = fields.CharField(max_length=8, null=True)
    exp_month = fields.IntField(null=True)
    exp_year = fields.IntField(null=True)
    funding = fields.CharField(max_length=64, null=True)
    last4 = fields.CharField(max_length=8, null=True)


class StripeSource(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    source_type = fields.CharField(max_length=64, null=True)
    status = fields.CharField(max_length=64, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)


class StripeSourceTransaction(StripeSyncModel):
    source_stripe_id = fields.CharField(max_length=255, null=True)
    source_transaction_type = fields.CharField(max_length=64, null=True)
    status = fields.CharField(max_length=64, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)


class StripeApplicationFee(StripeSyncModel):
    account_stripe_id = fields.CharField(max_length=255, null=True)
    charge_stripe_id = fields.CharField(max_length=255, null=True)
    balance_transaction_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    amount_refunded = fields.BigIntField(null=True)


class StripeApplicationFeeRefund(StripeSyncModel):
    application_fee_stripe_id = fields.CharField(max_length=255, null=True)
    balance_transaction_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)


class StripeCountrySpec(StripeSyncModel):
    default_currency = fields.CharField(max_length=12, null=True)
    supported_bank_account_currencies_json = fields.JSONField(default=dict)
    supported_payment_currencies_json = fields.JSONField(default=list)
    supported_payment_methods_json = fields.JSONField(default=list)


class StripeTransfer(StripeSyncModel):
    destination_account_stripe_id = fields.CharField(max_length=255, null=True)
    destination_payment_stripe_id = fields.CharField(max_length=255, null=True)
    balance_transaction_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    reversed = fields.BooleanField(default=False)


class StripeTransferReversal(StripeSyncModel):
    transfer_stripe_id = fields.CharField(max_length=255, null=True)
    balance_transaction_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)


class StripeFeature(StripeSyncModel):
    feature_name = fields.CharField(max_length=255, null=True)
    lookup_key = fields.CharField(max_length=255, null=True)
    active = fields.BooleanField(default=True)


class StripeProductFeature(StripeSyncModel):
    product_stripe_id = fields.CharField(max_length=255, null=True)
    feature_stripe_id = fields.CharField(max_length=255, null=True)


class StripeActiveEntitlement(StripeSyncModel):
    customer_stripe_id = fields.CharField(max_length=255, null=True)
    lookup_key = fields.CharField(max_length=255, null=True)
    feature_stripe_id = fields.CharField(max_length=255, null=True)


class StripeVerificationSession(StripeSyncModel):
    client_secret = fields.CharField(max_length=255, null=True)
    status = fields.CharField(max_length=64, null=True)
    verification_type = fields.CharField(max_length=64, null=True)
    url = fields.TextField(null=True)


class StripeVerificationReport(StripeSyncModel):
    verification_session_stripe_id = fields.CharField(max_length=255, null=True)
    report_type = fields.CharField(max_length=64, null=True)
    document_json = fields.JSONField(default=dict)
    selfie_json = fields.JSONField(default=dict)


class StripeIssuingAuthorization(StripeSyncModel):
    card_stripe_id = fields.CharField(max_length=255, null=True)
    cardholder_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    approved = fields.BooleanField(default=False)
    status = fields.CharField(max_length=64, null=True)


class StripeIssuingCardholder(StripeSyncModel):
    email = fields.CharField(max_length=320, null=True)
    name = fields.CharField(max_length=255, null=True)
    status = fields.CharField(max_length=64, null=True)
    cardholder_type = fields.CharField(max_length=64, null=True)


class StripeIssuingCard(StripeSyncModel):
    brand = fields.CharField(max_length=64, null=True)
    currency = fields.CharField(max_length=12, null=True)
    exp_month = fields.IntField(null=True)
    exp_year = fields.IntField(null=True)
    last4 = fields.CharField(max_length=8, null=True)
    status = fields.CharField(max_length=64, null=True)
    cardholder_stripe_id = fields.CharField(max_length=255, null=True)


class StripeIssuingDispute(StripeSyncModel):
    transaction_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    status = fields.CharField(max_length=64, null=True)


class StripeIssuingTransaction(StripeSyncModel):
    card_stripe_id = fields.CharField(max_length=255, null=True)
    cardholder_stripe_id = fields.CharField(max_length=255, null=True)
    currency = fields.CharField(max_length=12, null=True)
    amount = fields.BigIntField(null=True)
    transaction_type = fields.CharField(max_length=64, null=True)


class StripeEarlyFraudWarning(StripeSyncModel):
    charge_stripe_id = fields.CharField(max_length=255, null=True)
    actionable = fields.BooleanField(default=False)
    fraud_type = fields.CharField(max_length=64, null=True)


class StripeReview(StripeSyncModel):
    charge_stripe_id = fields.CharField(max_length=255, null=True)
    open = fields.BooleanField(default=False)
    reason = fields.CharField(max_length=255, null=True)
    closed_reason = fields.CharField(max_length=255, null=True)


class StripeScheduledQueryRun(StripeSyncModel):
    file_stripe_id = fields.CharField(max_length=255, null=True)
    status = fields.CharField(max_length=64, null=True)
    title = fields.CharField(max_length=255, null=True)


class StripePricingTable(StripeSyncModel):
    active = fields.BooleanField(default=True)
    pricing_table_json = fields.JSONField(default=dict)
