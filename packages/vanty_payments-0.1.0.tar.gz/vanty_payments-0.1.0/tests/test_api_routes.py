from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient, Response

pytestmark = pytest.mark.integration


IdentityResolver = Callable[[Any], dict[str, str] | None]


def build_app(payments_kit, resolver: IdentityResolver | None = None) -> FastAPI:
    app = FastAPI()
    app.include_router(payments_kit.router)
    app.state.payments_kit = payments_kit
    app.state.payments_identity_resolver = resolver
    return app


async def api_request(app: FastAPI, method: str, path: str, **kwargs: Any) -> Response:
    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://testserver",
    ) as client:
        return await client.request(method, path, **kwargs)


async def seed_customer(payments_kit, *, stripe_id: str, user_reference: str, organization_reference: str):
    return await payments_kit.sync_service.sync_customer(
        {
            "id": stripe_id,
            "object": "customer",
            "email": f"{stripe_id}@example.com",
            "name": stripe_id,
            "livemode": False,
            "created": 1_700_000_100,
            "metadata": {},
            "invoice_settings": {"default_payment_method": None},
        },
        user_reference=user_reference,
        organization_reference=organization_reference,
    )


async def seed_catalog(payments_kit) -> None:
    await payments_kit.sync_service.sync_product(
        {
            "id": "prod_api_basic",
            "object": "product",
            "name": "Basic",
            "active": True,
            "description": "Basic plan",
            "default_price": "price_api_basic",
            "livemode": False,
            "created": 1_700_000_101,
            "metadata": {},
        }
    )
    await payments_kit.sync_service.sync_price(
        {
            "id": "price_api_basic",
            "object": "price",
            "product": "prod_api_basic",
            "currency": "usd",
            "unit_amount": 2900,
            "type": "recurring",
            "recurring": {"interval": "month", "interval_count": 1},
            "active": True,
            "livemode": False,
            "created": 1_700_000_102,
            "metadata": {},
        }
    )


async def test_bootstrap_customer_uses_identity_when_payload_missing(payments_kit, monkeypatch):
    app = build_app(
        payments_kit,
        resolver=lambda _request: {
            "user_reference": "user_from_identity",
            "organization_reference": "org_from_identity",
        },
    )

    monkeypatch.setattr(
        payments_kit.context.stripe_client,
        "create_customer",
        lambda **kwargs: {
            "id": "cus_api_bootstrap",
            "object": "customer",
            "email": kwargs["email"],
            "name": kwargs.get("name"),
            "livemode": False,
            "created": 1_700_000_103,
            "metadata": kwargs.get("metadata", {}),
            "invoice_settings": {"default_payment_method": None},
        },
    )

    response = await api_request(
        app,
        "POST",
        "/payments/customer/bootstrap",
        json={"email": "ada@example.com", "name": "Ada", "metadata": {"plan": "pro"}},
    )

    assert response.status_code == 200
    assert response.json()["user_reference"] == "user_from_identity"
    assert response.json()["organization_reference"] == "org_from_identity"


async def test_get_customer_returns_404_when_missing(payments_kit):
    app = build_app(payments_kit)

    response = await api_request(app, "GET", "/payments/customer")

    assert response.status_code == 404
    assert response.json()["detail"] == "Customer not found"


async def test_list_customers_route_returns_persisted_customers(payments_kit):
    app = build_app(payments_kit)
    await seed_customer(
        payments_kit,
        stripe_id="cus_list_1",
        user_reference="user_list_1",
        organization_reference="org_list",
    )
    await seed_customer(
        payments_kit,
        stripe_id="cus_list_2",
        user_reference="user_list_2",
        organization_reference="org_list",
    )

    response = await api_request(app, "GET", "/payments/customers")

    assert response.status_code == 200
    assert len(response.json()["customers"]) == 2


async def test_catalog_route_returns_products_and_prices(payments_kit):
    app = build_app(payments_kit)
    await seed_catalog(payments_kit)

    response = await api_request(app, "GET", "/payments/catalog")

    assert response.status_code == 200
    assert response.json()["products"][0]["stripe_id"] == "prod_api_basic"
    assert response.json()["prices"][0]["stripe_id"] == "price_api_basic"


async def test_checkout_session_route_uses_identity_defaults(payments_kit, monkeypatch):
    app = build_app(
        payments_kit,
        resolver=lambda _request: {
            "user_reference": "user_checkout",
            "organization_reference": "org_checkout",
        },
    )

    monkeypatch.setattr(
        payments_kit.context.stripe_client,
        "create_customer",
        lambda **kwargs: {
            "id": "cus_route_checkout",
            "object": "customer",
            "email": kwargs["email"],
            "name": kwargs.get("name"),
            "livemode": False,
            "created": 1_700_000_104,
            "metadata": kwargs.get("metadata", {}),
            "invoice_settings": {"default_payment_method": None},
        },
    )
    monkeypatch.setattr(
        payments_kit.context.stripe_client,
        "create_checkout_session",
        lambda **kwargs: {
            "id": "cs_route_checkout",
            "object": "checkout.session",
            "customer": kwargs["customer"],
            "mode": kwargs["mode"],
            "status": "open",
            "payment_status": "unpaid",
            "url": "https://checkout.stripe.test/session",
            "success_url": kwargs["success_url"],
            "cancel_url": kwargs["cancel_url"],
            "client_reference_id": kwargs.get("client_reference_id"),
            "subscription": None,
            "payment_intent": None,
            "livemode": False,
            "created": 1_700_000_105,
            "metadata": kwargs.get("metadata", {}),
        },
    )

    response = await api_request(
        app,
        "POST",
        "/payments/checkout/sessions",
        json={
            "email": "checkout@example.com",
            "name": "Checkout User",
            "line_items": [{"price_id": "price_api_basic", "quantity": 1}],
            "success_url": "https://example.com/success",
            "cancel_url": "https://example.com/cancel",
        },
    )

    assert response.status_code == 200
    assert response.json()["stripe_id"] == "cs_route_checkout"
    assert response.json()["customer_stripe_id"] == "cus_route_checkout"


async def test_billing_portal_route_returns_url(payments_kit, monkeypatch):
    app = build_app(
        payments_kit,
        resolver=lambda _request: {
            "user_reference": "user_portal",
            "organization_reference": "org_portal",
        },
    )
    await seed_customer(
        payments_kit,
        stripe_id="cus_portal",
        user_reference="user_portal",
        organization_reference="org_portal",
    )
    monkeypatch.setattr(
        payments_kit.context.stripe_client,
        "create_billing_portal_session",
        lambda **kwargs: {"url": "https://billing.stripe.test/session", "customer": kwargs["customer"]},
    )

    response = await api_request(app, "POST", "/payments/billing-portal/sessions", json={})

    assert response.status_code == 200
    assert response.json() == {"url": "https://billing.stripe.test/session"}


async def test_subscription_route_returns_subscription_for_identity_customer(payments_kit):
    app = build_app(
        payments_kit,
        resolver=lambda _request: {
            "user_reference": "user_subscription",
            "organization_reference": "org_subscription",
        },
    )
    customer = await seed_customer(
        payments_kit,
        stripe_id="cus_subscription",
        user_reference="user_subscription",
        organization_reference="org_subscription",
    )
    await payments_kit.sync_service.sync_subscription(
        {
            "id": "sub_route",
            "object": "subscription",
            "customer": customer.stripe_id,
            "status": "active",
            "currency": "usd",
            "items": {"data": []},
            "livemode": False,
            "created": 1_700_000_107,
            "metadata": {},
        }
    )

    response = await api_request(app, "GET", "/payments/subscription")

    assert response.status_code == 200
    assert response.json()["stripe_id"] == "sub_route"


async def test_invoices_and_payment_methods_routes_filter_by_identity_customer(payments_kit):
    app = build_app(
        payments_kit,
        resolver=lambda _request: {
            "user_reference": "user_billing_routes",
            "organization_reference": "org_billing_routes",
        },
    )
    customer = await seed_customer(
        payments_kit,
        stripe_id="cus_billing_routes",
        user_reference="user_billing_routes",
        organization_reference="org_billing_routes",
    )
    await payments_kit.sync_service.sync_payment_method(
        {
            "id": "pm_route",
            "object": "payment_method",
            "customer": customer.stripe_id,
            "type": "card",
            "card": {
                "brand": "visa",
                "last4": "4242",
                "exp_month": 12,
                "exp_year": 2030,
                "fingerprint": "fp_route",
            },
            "livemode": False,
            "created": 1_700_000_108,
            "metadata": {},
        }
    )
    await payments_kit.sync_service.sync_subscription(
        {
            "id": "sub_billing_routes",
            "object": "subscription",
            "customer": customer.stripe_id,
            "status": "active",
            "currency": "usd",
            "items": {"data": []},
            "livemode": False,
            "created": 1_700_000_109,
            "metadata": {},
        }
    )
    await payments_kit.sync_service.sync_invoice(
        {
            "id": "in_route",
            "object": "invoice",
            "customer": customer.stripe_id,
            "subscription": "sub_billing_routes",
            "status": "paid",
            "currency": "usd",
            "subtotal": 2900,
            "total": 2900,
            "amount_due": 0,
            "amount_paid": 2900,
            "lines": {"data": []},
            "status_transitions": {"paid_at": 1_700_000_111},
            "livemode": False,
            "created": 1_700_000_110,
            "metadata": {},
        }
    )

    invoices_response = await api_request(app, "GET", "/payments/invoices")
    payment_methods_response = await api_request(app, "GET", "/payments/payment-methods")

    assert invoices_response.status_code == 200
    assert invoices_response.json()["invoices"][0]["stripe_id"] == "in_route"
    assert payment_methods_response.status_code == 200
    assert payment_methods_response.json()["payment_methods"][0]["stripe_id"] == "pm_route"


async def test_webhook_route_returns_400_for_invalid_delivery(payments_kit):
    app = build_app(payments_kit)

    response = await api_request(app, "POST", "/payments/webhooks/stripe", content=b"{}")

    assert response.status_code == 400
    assert response.json()["detail"] == "Missing stripe-signature header"


async def test_sync_object_route_returns_noop_message_when_sync_returns_none(payments_kit, monkeypatch):
    app = build_app(payments_kit)

    async def fake_sync_object(object_type: str, stripe_id: str):
        assert object_type == "product"
        assert stripe_id == "prod_missing"
        return None

    monkeypatch.setattr(payments_kit, "sync_object", fake_sync_object)

    response = await api_request(
        app,
        "POST",
        "/payments/sync/object",
        json={"object_type": "product", "stripe_id": "prod_missing"},
    )

    assert response.status_code == 200
    assert response.json()["message"] == "No-op"
    assert response.json()["debug"]["stripe_id"] == "prod_missing"


async def test_bootstrap_sync_route_rejects_unsupported_object_types(payments_kit):
    app = build_app(payments_kit)

    response = await api_request(
        app,
        "POST",
        "/payments/sync/bootstrap",
        json={"object_types": ["api_key"], "limit": 10},
    )

    assert response.status_code == 422
    assert "Unsupported sync object types: api_key" in response.text


async def test_bootstrap_sync_route_returns_counts(payments_kit, monkeypatch):
    app = build_app(payments_kit)

    def fake_list_objects(object_type: str, *, limit: int = 100):
        assert limit == 10
        if object_type == "product":
            return [
                {
                    "id": "prod_sync_route",
                    "object": "product",
                    "name": "Route Product",
                    "active": True,
                    "description": None,
                    "default_price": None,
                    "livemode": False,
                    "created": 1_700_000_106,
                    "metadata": {},
                }
            ]
        return []

    monkeypatch.setattr(payments_kit.context.stripe_client, "list_objects", fake_list_objects)

    response = await api_request(
        app,
        "POST",
        "/payments/sync/bootstrap",
        json={"object_types": ["product"], "limit": 10},
    )

    assert response.status_code == 200
    assert response.json()["counts"]["product"] == 1
    assert response.json()["succeeded"] is True
