from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


async def test_customer_bootstrap_creates_local_record(payments_kit, monkeypatch):
    monkeypatch.setattr(
        payments_kit.context.stripe_client,
        "create_customer",
        lambda **kwargs: {
            "id": "cus_123",
            "object": "customer",
            "email": kwargs["email"],
            "name": kwargs.get("name"),
            "livemode": False,
            "created": 1_700_000_000,
            "metadata": kwargs.get("metadata", {}),
            "invoice_settings": {"default_payment_method": None},
        },
    )

    customer = await payments_kit.bootstrap_customer(
        email="ada@example.com",
        name="Ada Lovelace",
        user_reference="user_1",
        organization_reference="org_1",
        metadata={"plan": "pro"},
    )

    assert customer.stripe_id == "cus_123"
    assert customer.user_reference == "user_1"
    assert customer.organization_reference == "org_1"
    assert customer.email == "ada@example.com"
