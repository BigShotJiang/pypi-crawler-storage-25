from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


async def seed_customer(payments_kit, *, stripe_id: str, user_reference: str, organization_reference: str):
    return await payments_kit.sync_service.sync_customer(
        {
            "id": stripe_id,
            "object": "customer",
            "email": f"{stripe_id}@example.com",
            "name": stripe_id,
            "livemode": False,
            "created": 1_700_000_200,
            "metadata": {},
            "invoice_settings": {"default_payment_method": None},
        },
        user_reference=user_reference,
        organization_reference=organization_reference,
    )


async def test_create_billing_portal_session_returns_url(payments_kit, monkeypatch):
    await seed_customer(
        payments_kit,
        stripe_id="cus_billing_portal",
        user_reference="user_billing",
        organization_reference="org_billing",
    )
    monkeypatch.setattr(
        payments_kit.context.stripe_client,
        "create_billing_portal_session",
        lambda **kwargs: {
            "url": "https://billing.stripe.test/session",
            "customer": kwargs["customer"],
            "return_url": kwargs["return_url"],
        },
    )

    url = await payments_kit.create_billing_portal_session(
        stripe_customer_id=None,
        user_reference="user_billing",
        organization_reference="org_billing",
        return_url="https://example.com/account",
    )

    assert url == "https://billing.stripe.test/session"


async def test_get_subscription_returns_none_when_customer_missing(payments_kit):
    subscription = await payments_kit.get_subscription(
        stripe_customer_id=None,
        user_reference="missing_user",
        organization_reference="missing_org",
    )

    assert subscription is None


async def test_list_invoices_returns_customer_invoices(payments_kit):
    customer = await seed_customer(
        payments_kit,
        stripe_id="cus_invoice_owner",
        user_reference="user_invoice",
        organization_reference="org_invoice",
    )
    await payments_kit.sync_service.sync_subscription(
        {
            "id": "sub_invoice_owner",
            "object": "subscription",
            "customer": customer.stripe_id,
            "status": "active",
            "currency": "usd",
            "items": {"data": []},
            "livemode": False,
            "created": 1_700_000_201,
            "metadata": {},
        }
    )
    await payments_kit.sync_service.sync_invoice(
        {
            "id": "in_invoice_owner",
            "object": "invoice",
            "customer": customer.stripe_id,
            "subscription": "sub_invoice_owner",
            "status": "paid",
            "currency": "usd",
            "subtotal": 2900,
            "total": 2900,
            "amount_due": 0,
            "amount_paid": 2900,
            "hosted_invoice_url": "https://stripe.test/invoice",
            "lines": {"data": []},
            "status_transitions": {"paid_at": 1_700_000_203},
            "livemode": False,
            "created": 1_700_000_202,
            "metadata": {},
        }
    )

    invoices = await payments_kit.list_invoices(
        stripe_customer_id=None,
        user_reference="user_invoice",
        organization_reference="org_invoice",
    )

    assert len(invoices) == 1
    assert invoices[0].stripe_id == "in_invoice_owner"


async def test_list_payment_methods_returns_methods_for_customer(payments_kit):
    customer = await seed_customer(
        payments_kit,
        stripe_id="cus_payment_method_owner",
        user_reference="user_payment_method",
        organization_reference="org_payment_method",
    )
    await payments_kit.sync_service.sync_payment_method(
        {
            "id": "pm_card_1",
            "object": "payment_method",
            "customer": customer.stripe_id,
            "type": "card",
            "card": {
                "brand": "visa",
                "last4": "4242",
                "exp_month": 12,
                "exp_year": 2030,
                "fingerprint": "fp_1",
            },
            "livemode": False,
            "created": 1_700_000_204,
            "metadata": {},
        }
    )
    await payments_kit.sync_service.sync_payment_method(
        {
            "id": "pm_card_2",
            "object": "payment_method",
            "customer": customer.stripe_id,
            "type": "card",
            "card": {
                "brand": "mastercard",
                "last4": "5454",
                "exp_month": 11,
                "exp_year": 2031,
                "fingerprint": "fp_2",
            },
            "livemode": False,
            "created": 1_700_000_205,
            "metadata": {},
        }
    )

    payment_methods = await payments_kit.list_payment_methods(
        stripe_customer_id=None,
        user_reference="user_payment_method",
        organization_reference="org_payment_method",
    )

    assert [method.stripe_id for method in payment_methods] == ["pm_card_2", "pm_card_1"]
