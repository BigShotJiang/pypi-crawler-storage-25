from __future__ import annotations

from decimal import Decimal

import pytest

from vanty_payments.admin.schemas import MeterDefault
from vanty_payments.db.models import BillingAccount, ProductConfig, StripeProduct

pytestmark = pytest.mark.integration


async def seed_product(payments_kit, stripe_id: str = "prod_admin_1"):
    await payments_kit.sync_service.sync_product(
        {
            "id": stripe_id,
            "object": "product",
            "name": "Admin Product",
            "active": True,
            "description": "Test product",
            "default_price": None,
            "livemode": False,
            "created": 1_700_000_400,
            "metadata": {},
        }
    )
    return await StripeProduct.filter(stripe_id=stripe_id).first()


# ------------------------------------------------------------------
# Product config
# ------------------------------------------------------------------


async def test_list_product_configs_empty(payments_kit):
    configs = await payments_kit.admin_service.list_product_configs()
    assert configs == []


async def test_create_and_list_product_configs(payments_kit):
    product = await seed_product(payments_kit)
    config = await ProductConfig.create(product=product, show_in_ui=True, weight=5)
    configs = await payments_kit.admin_service.list_product_configs()
    assert len(configs) == 1
    assert configs[0].pk == config.pk


async def test_update_product_config(payments_kit):
    product = await seed_product(payments_kit, stripe_id="prod_admin_update")
    config = await ProductConfig.create(product=product, show_in_ui=False)

    updated = await payments_kit.admin_service.update_product_config(
        config.pk,
        {"show_in_ui": True, "weight": 10},
    )
    assert updated is not None
    assert updated.show_in_ui is True
    assert updated.weight == 10


async def test_update_product_config_not_found(payments_kit):
    import uuid

    result = await payments_kit.admin_service.update_product_config(
        uuid.uuid4(), {"show_in_ui": True}
    )
    assert result is None


# ------------------------------------------------------------------
# Meter CRUD
# ------------------------------------------------------------------


async def test_meter_crud(payments_kit):
    meter = await payments_kit.admin_service.create_meter({
        "event_name": "test_meter_crud",
        "display_name": "Test Meter",
        "pricing_strategy": "fixed_per_event",
        "fixed_amount": Decimal("0.01"),
    })
    assert meter.event_name == "test_meter_crud"

    fetched = await payments_kit.admin_service.get_meter(meter.pk)
    assert fetched is not None
    assert fetched.event_name == "test_meter_crud"

    updated = await payments_kit.admin_service.update_meter(
        meter.pk,
        {"display_name": "Updated Meter"},
    )
    assert updated.display_name == "Updated Meter"

    deleted = await payments_kit.admin_service.delete_meter(meter.pk)
    assert deleted is True

    deleted_again = await payments_kit.admin_service.delete_meter(meter.pk)
    assert deleted_again is False


async def test_load_default_meters(payments_kit):
    defaults = [
        MeterDefault(
            event_name="llm_inference",
            display_name="LLM Inference",
            pricing_strategy="margin",
            margin_multiplier=Decimal("1.5"),
        ),
        MeterDefault(
            event_name="image_generation",
            display_name="Image Generation",
            pricing_strategy="fixed_per_event",
            fixed_amount=Decimal("0.10"),
        ),
    ]
    loaded = await payments_kit.load_default_meters(defaults)
    assert loaded == 2

    loaded_again = await payments_kit.load_default_meters(defaults)
    assert loaded_again == 0

    meters = await payments_kit.admin_service.list_meters()
    event_names = {m.event_name for m in meters}
    assert "llm_inference" in event_names
    assert "image_generation" in event_names


# ------------------------------------------------------------------
# Admin credit grants
# ------------------------------------------------------------------


async def test_admin_grant_credits(payments_kit):
    account = await BillingAccount.create(
        user_reference="user_admin_credits",
        organization_reference="org_admin_credits",
    )
    entry = await payments_kit.admin_service.grant_credits(
        account.pk,
        amount=Decimal("500"),
        description="Admin bonus",
        reference_id="admin_bonus_1",
    )
    assert entry.amount == Decimal("500")
    assert entry.entry_type == "admin_grant"


# ------------------------------------------------------------------
# Integration status
# ------------------------------------------------------------------


async def test_integration_status(payments_kit):
    status = await payments_kit.admin_service.get_integration_status()
    assert status["stripe_configured"] is True
    assert status["stripe_mode"] == "test"
    assert status["webhook_secret_set"] is True
    assert isinstance(status["products_synced"], int)
    assert isinstance(status["meters_configured"], int)
    assert isinstance(status["billing_accounts"], int)


# ------------------------------------------------------------------
# Sync products from Stripe
# ------------------------------------------------------------------


async def test_sync_products_from_stripe(payments_kit, monkeypatch):
    monkeypatch.setattr(
        payments_kit.context.stripe_client,
        "list_objects",
        lambda object_type, **kw: [
            {
                "id": "prod_sync_stripe_1",
                "object": "product",
                "name": "Synced Product",
                "active": True,
                "description": "From stripe",
                "default_price": None,
                "livemode": False,
                "created": 1_700_000_500,
                "metadata": {},
            }
        ],
    )

    result = await payments_kit.admin_service.sync_products_from_stripe()
    assert result["created"] == 1
    assert result["total"] == 1

    result2 = await payments_kit.admin_service.sync_products_from_stripe()
    assert result2["created"] == 0
    assert result2["updated"] == 1
