from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


async def test_webhook_ingest_persists_delivery_and_event(payments_kit, monkeypatch):
    event = {
        "id": "evt_123",
        "object": "event",
        "type": "customer.created",
        "api_version": "2020-08-27",
        "livemode": False,
        "created": 1_700_000_200,
        "request": {"id": "req_123", "idempotency_key": "idem_123"},
        "data": {
            "object": {
                "id": "cus_webhook",
                "object": "customer",
                "email": "grace@example.com",
                "name": "Grace",
                "livemode": False,
                "created": 1_700_000_201,
                "metadata": {"vanty_user_reference": "user_grace"},
                "invoice_settings": {"default_payment_method": None},
            }
        },
        "metadata": {},
    }

    monkeypatch.setattr(
        payments_kit.context.stripe_client,
        "construct_event",
        lambda **kwargs: event,
    )

    delivery = await payments_kit.process_webhook(
        payload=b"{}",
        signature="t=1,v1=fake",
        headers={"stripe-signature": "t=1,v1=fake"},
        remote_ip="127.0.0.1",
    )

    customer = await payments_kit.get_customer(stripe_customer_id="cus_webhook")

    assert delivery.valid is True
    assert delivery.processed is True
    assert delivery.webhook_event_id is not None
    assert customer is not None
    assert customer.user_reference == "user_grace"
    assert payments_kit.events.list()[-1].name == "payments.webhook.received"


async def test_webhook_ingest_without_signature_records_invalid_delivery(payments_kit):
    delivery = await payments_kit.process_webhook(
        payload=b"{}",
        signature=None,
        headers={},
        remote_ip="127.0.0.1",
    )

    assert delivery.valid is False
    assert delivery.processed is False
    assert delivery.exception == "Missing stripe-signature header"
    assert payments_kit.events.list()[-1].payload["valid"] is False


async def test_webhook_ingest_records_construct_failures(payments_kit, monkeypatch):
    def raise_signature_error(**_kwargs):
        raise ValueError("Invalid signature")

    monkeypatch.setattr(payments_kit.context.stripe_client, "construct_event", raise_signature_error)

    delivery = await payments_kit.process_webhook(
        payload=b"{}",
        signature="t=1,v1=bad",
        headers={"stripe-signature": "t=1,v1=bad"},
        remote_ip="127.0.0.1",
    )

    assert delivery.valid is False
    assert delivery.processed is False
    assert delivery.exception == "Invalid signature"
    assert "ValueError: Invalid signature" in delivery.traceback
