from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


async def test_catalog_bootstrap_syncs_products_and_prices(payments_kit, monkeypatch):
    def fake_list_objects(object_type: str, *, limit: int = 100):
        if object_type == "product":
            return [
                {
                    "id": "prod_basic",
                    "object": "product",
                    "name": "Basic",
                    "active": True,
                    "description": "Basic plan",
                    "default_price": "price_basic_monthly",
                    "livemode": False,
                    "created": 1_700_000_001,
                    "metadata": {},
                }
            ]
        if object_type == "price":
            return [
                {
                    "id": "price_basic_monthly",
                    "object": "price",
                    "product": "prod_basic",
                    "currency": "usd",
                    "unit_amount": 2900,
                    "type": "recurring",
                    "recurring": {"interval": "month", "interval_count": 1},
                    "active": True,
                    "livemode": False,
                    "created": 1_700_000_002,
                    "metadata": {},
                }
            ]
        return []

    monkeypatch.setattr(payments_kit.context.stripe_client, "list_objects", fake_list_objects)

    sync_run = await payments_kit.bootstrap_sync(["product", "price"])
    products, prices = await payments_kit.catalog()

    assert sync_run.succeeded is True
    assert len(products) == 1
    assert len(prices) == 1
    assert prices[0].product_id == products[0].id


async def test_catalog_service_bootstrap_catalog_delegates_to_sync(payments_kit, monkeypatch):
    def fake_list_objects(object_type: str, *, limit: int = 100):
        assert limit == 5
        return []

    monkeypatch.setattr(payments_kit.context.stripe_client, "list_objects", fake_list_objects)

    sync_run = await payments_kit.catalog_service.bootstrap_catalog(limit=5)

    assert sync_run.mode == "bootstrap"
    assert sync_run.counts_json == {"product": 0, "price": 0}
