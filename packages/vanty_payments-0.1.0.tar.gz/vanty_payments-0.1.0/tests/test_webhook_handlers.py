from __future__ import annotations

from decimal import Decimal

import pytest

from vanty_payments.billing.constants import SubscriptionLifecycleState
from vanty_payments.db.models import BillingAccount, CreditLedgerEntry, StripeCustomer

pytestmark = pytest.mark.integration


async def seed_customer_and_account(payments_kit, *, stripe_id: str, org_ref: str):
    customer = await payments_kit.sync_service.sync_customer(
        {
            "id": stripe_id,
            "object": "customer",
            "email": f"{stripe_id}@example.com",
            "name": stripe_id,
            "livemode": False,
            "created": 1_700_000_600,
            "metadata": {},
            "invoice_settings": {"default_payment_method": None},
        },
        user_reference=f"user_{org_ref}",
        organization_reference=org_ref,
    )
    account = await payments_kit.billing_service.resolve_billing_account(
        organization_reference=org_ref,
        customer=customer,
    )
    return customer, account


async def test_checkout_completed_sets_state_active(payments_kit):
    customer, account = await seed_customer_and_account(
        payments_kit, stripe_id="cus_wh_checkout", org_ref="org_wh_checkout"
    )
    event = {
        "type": "checkout.session.completed",
        "data": {
            "object": {
                "id": "cs_wh_1",
                "object": "checkout.session",
                "customer": customer.stripe_id,
                "subscription": "sub_wh_1",
                "status": "complete",
                "payment_status": "paid",
                "livemode": False,
                "created": 1_700_000_601,
                "metadata": {},
            }
        },
    }
    await payments_kit.webhook_service.handler_registry.handle_event(event)

    refreshed = await BillingAccount.get(pk=account.pk)
    assert refreshed.state == SubscriptionLifecycleState.ACTIVE.value
    assert refreshed.current_plan == "sub_wh_1"


async def test_checkout_payment_failed_sets_state(payments_kit):
    customer, account = await seed_customer_and_account(
        payments_kit, stripe_id="cus_wh_fail", org_ref="org_wh_fail"
    )
    event = {
        "type": "checkout.session.async_payment_failed",
        "data": {
            "object": {
                "id": "cs_wh_fail",
                "object": "checkout.session",
                "customer": customer.stripe_id,
                "subscription": None,
                "status": "open",
                "payment_status": "unpaid",
                "livemode": False,
                "created": 1_700_000_602,
                "metadata": {},
            }
        },
    }
    await payments_kit.webhook_service.handler_registry.handle_event(event)

    refreshed = await BillingAccount.get(pk=account.pk)
    assert refreshed.state == SubscriptionLifecycleState.PAYMENT_FAILED.value


async def test_subscription_deleted_sets_state_canceled(payments_kit):
    customer, account = await seed_customer_and_account(
        payments_kit, stripe_id="cus_wh_del", org_ref="org_wh_del"
    )
    account.state = SubscriptionLifecycleState.ACTIVE.value
    account.current_plan = "sub_wh_del"
    await account.save()

    event = {
        "type": "customer.subscription.deleted",
        "data": {
            "object": {
                "id": "sub_wh_del",
                "object": "subscription",
                "customer": customer.stripe_id,
                "status": "canceled",
                "currency": "usd",
                "items": {"data": []},
                "livemode": False,
                "created": 1_700_000_603,
                "metadata": {},
            }
        },
    }
    await payments_kit.webhook_service.handler_registry.handle_event(event)

    refreshed = await BillingAccount.get(pk=account.pk)
    assert refreshed.state == SubscriptionLifecycleState.CANCELED.value
    assert refreshed.current_plan is None


async def test_setup_intent_succeeded_updates_payment_method(payments_kit):
    customer, _ = await seed_customer_and_account(
        payments_kit, stripe_id="cus_wh_setup", org_ref="org_wh_setup"
    )
    event = {
        "type": "setup_intent.succeeded",
        "data": {
            "object": {
                "id": "seti_wh_1",
                "object": "setup_intent",
                "customer": customer.stripe_id,
                "payment_method": "pm_new_card",
                "status": "succeeded",
                "usage": "off_session",
                "livemode": False,
                "created": 1_700_000_604,
                "metadata": {},
            }
        },
    }
    await payments_kit.webhook_service.handler_registry.handle_event(event)

    refreshed = await StripeCustomer.get(pk=customer.pk)
    assert refreshed.default_payment_method_id == "pm_new_card"


async def test_invoice_paid_non_cycle_skipped(payments_kit):
    """Invoice events with non-cycle billing_reason should not grant credits."""
    payments_kit.settings.billing_credits_enabled = True
    try:
        customer, account = await seed_customer_and_account(
            payments_kit, stripe_id="cus_wh_inv_skip", org_ref="org_wh_inv_skip"
        )
        event = {
            "type": "invoice.paid",
            "data": {
                "object": {
                    "id": "in_wh_manual",
                    "object": "invoice",
                    "customer": customer.stripe_id,
                    "subscription": None,
                    "status": "paid",
                    "billing_reason": "manual",
                    "amount_paid": 5000,
                    "currency": "usd",
                    "lines": {"data": []},
                    "livemode": False,
                    "created": 1_700_000_610,
                    "metadata": {},
                }
            },
        }
        await payments_kit.webhook_service.handler_registry.handle_event(event)
        entries = await CreditLedgerEntry.filter(billing_account=account).all()
        assert len(entries) == 0
    finally:
        payments_kit.settings.billing_credits_enabled = False


async def test_webhook_event_missing_object_key(payments_kit):
    """Events without a data.object.object key should be skipped."""
    event = {
        "type": "unknown.event",
        "data": {"object": {"id": "x"}},
    }
    result = await payments_kit.webhook_service.handler_registry.handle_event(event)
    assert result is None


async def test_webhook_checkout_no_customer(payments_kit):
    """Checkout event with no customer should not crash."""
    event = {
        "type": "checkout.session.completed",
        "data": {
            "object": {
                "id": "cs_no_cust",
                "object": "checkout.session",
                "customer": None,
                "subscription": None,
                "status": "complete",
                "payment_status": "paid",
                "livemode": False,
                "created": 1_700_000_611,
                "metadata": {},
            }
        },
    }
    await payments_kit.webhook_service.handler_registry.handle_event(event)


async def test_invoice_paid_grants_renewal_credits(payments_kit):
    payments_kit.settings.billing_credits_enabled = True
    payments_kit.settings.credit_factor = 100
    try:
        customer, account = await seed_customer_and_account(
            payments_kit, stripe_id="cus_wh_inv", org_ref="org_wh_inv"
        )
        event = {
            "type": "invoice.paid",
            "data": {
                "object": {
                    "id": "in_wh_renewal",
                    "object": "invoice",
                    "customer": customer.stripe_id,
                    "subscription": "sub_wh_inv",
                    "status": "paid",
                    "billing_reason": "subscription_cycle",
                    "amount_paid": 5000,
                    "currency": "usd",
                    "lines": {"data": []},
                    "livemode": False,
                    "created": 1_700_000_605,
                    "metadata": {},
                }
            },
        }
        await payments_kit.webhook_service.handler_registry.handle_event(event)

        entries = await CreditLedgerEntry.filter(
            billing_account=account,
            reference_id="invoice_in_wh_renewal",
        ).all()
        assert len(entries) == 1
        assert entries[0].amount == Decimal("50")
    finally:
        payments_kit.settings.billing_credits_enabled = False
