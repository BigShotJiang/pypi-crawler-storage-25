from __future__ import annotations

from types import SimpleNamespace

import pytest

import vanty_payments.core.stripe_client as stripe_client_module
from vanty_payments.core.stripe_client import StripeClient
from vanty_payments.settings import PaymentsKitSettings

pytestmark = pytest.mark.unit


class AutoPagingResult:
    def auto_paging_iter(self):
        yield {"id": "item_1"}
        yield {"id": "item_2"}


class FakeResource:
    def __init__(self, prefix: str) -> None:
        self.prefix = prefix
        self.calls: list[tuple[str, tuple, dict]] = []

    def create(self, **kwargs):
        self.calls.append(("create", (), kwargs))
        return {"id": f"{self.prefix}_created", **kwargs}

    def retrieve(self, stripe_id: str, **kwargs):
        self.calls.append(("retrieve", (stripe_id,), kwargs))
        return {"id": stripe_id, "object": self.prefix}

    def list(self, **kwargs):
        self.calls.append(("list", (), kwargs))
        return {"data": [{"id": f"{self.prefix}_listed", "object": self.prefix}]}


def make_fake_stripe():
    customer = FakeResource("customer")
    checkout_session = FakeResource("checkout.session")
    billing_portal_session = FakeResource("billing_portal.session")
    webhook_calls: list[dict] = []

    def construct_event(**kwargs):
        webhook_calls.append(kwargs)
        return {"id": "evt_123", "object": "event", "type": "customer.created"}

    fake_stripe = SimpleNamespace(
        Customer=customer,
        FeeRefund=SimpleNamespace(),
        Webhook=SimpleNamespace(construct_event=construct_event),
        checkout=SimpleNamespace(Session=checkout_session),
        billing_portal=SimpleNamespace(Session=billing_portal_session),
    )
    return fake_stripe, customer, checkout_session, billing_portal_session, webhook_calls


def test_request_kwargs_selects_key_and_version():
    settings = PaymentsKitSettings(
        stripe_mode="live",
        stripe_api_version="2020-08-27",
        stripe_test_secret_key="sk_test_example",
        stripe_live_secret_key="sk_live_example",
    )
    client = StripeClient(settings)

    assert client._request_kwargs(livemode=False) == {
        "api_key": "sk_test_example",
        "stripe_version": "2020-08-27",
    }
    assert client._request_kwargs(livemode=True) == {
        "api_key": "sk_live_example",
        "stripe_version": "2020-08-27",
    }


def test_iter_list_handles_supported_shapes():
    client = StripeClient(PaymentsKitSettings())

    assert list(client._iter_list(AutoPagingResult())) == [{"id": "item_1"}, {"id": "item_2"}]
    assert list(client._iter_list({"data": [{"id": "dict_item"}]})) == [{"id": "dict_item"}]
    assert list(client._iter_list([{"id": "list_item"}])) == [{"id": "list_item"}]
    assert list(client._iter_list(None)) == []
    assert list(client._iter_list(({"id": "tuple_item"},))) == [{"id": "tuple_item"}]


def test_create_helpers_call_stripe_api(monkeypatch):
    fake_stripe, customer, checkout_session, billing_portal_session, _ = make_fake_stripe()
    monkeypatch.setattr(stripe_client_module, "stripe", fake_stripe)
    client = StripeClient(PaymentsKitSettings(stripe_test_secret_key="sk_test_example"))

    created_customer = client.create_customer(email="ada@example.com")
    created_checkout = client.create_checkout_session(mode="subscription")
    created_portal = client.create_billing_portal_session(customer="cus_123")

    assert created_customer["id"] == "customer_created"
    assert created_checkout["id"] == "checkout.session_created"
    assert created_portal["id"] == "billing_portal.session_created"
    assert customer.calls[0][2]["api_key"] == "sk_test_example"
    assert checkout_session.calls[0][2]["mode"] == "subscription"
    assert billing_portal_session.calls[0][2]["customer"] == "cus_123"


def test_construct_event_returns_dict(monkeypatch):
    fake_stripe, _, _, _, webhook_calls = make_fake_stripe()
    monkeypatch.setattr(stripe_client_module, "stripe", fake_stripe)
    client = StripeClient(PaymentsKitSettings(stripe_webhook_secret="whsec_example"))

    event = client.construct_event(payload=b"{}", sig_header="t=1,v1=test")

    assert event["id"] == "evt_123"
    assert webhook_calls[0]["secret"] == "whsec_example"


def test_retrieve_and_list_objects_use_api_mapping(monkeypatch):
    fake_stripe, customer, _, _, _ = make_fake_stripe()
    monkeypatch.setattr(stripe_client_module, "stripe", fake_stripe)
    client = StripeClient(PaymentsKitSettings(stripe_test_secret_key="sk_test_example"))

    retrieved = client.retrieve_object("customer", "cus_123")
    listed = client.list_objects("customer", limit=5)

    assert retrieved == {"id": "cus_123", "object": "customer"}
    assert listed == [{"id": "customer_listed", "object": "customer"}]
    assert customer.calls[0][0] == "retrieve"
    assert customer.calls[1][0] == "list"


def test_list_objects_rejects_non_listable_resources(monkeypatch):
    fake_stripe, _, _, _, _ = make_fake_stripe()
    monkeypatch.setattr(stripe_client_module, "stripe", fake_stripe)
    client = StripeClient(PaymentsKitSettings())

    with pytest.raises(ValueError, match="does not support list"):
        client.list_objects("fee_refund")


def test_api_object_for_unsupported_type_raises():
    with pytest.raises(ValueError, match="Unsupported Stripe object type: unknown"):
        StripeClient._api_object_for("unknown")
