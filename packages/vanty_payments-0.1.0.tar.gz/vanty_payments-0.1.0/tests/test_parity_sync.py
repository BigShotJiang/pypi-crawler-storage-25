from __future__ import annotations

# ruff: noqa: E501
import pytest

from vanty_payments.db.models import StripeApiKey, StripeIdempotencyKey
from vanty_payments.sync.parity import PARITY_MODEL_SPECS

pytestmark = pytest.mark.integration

BASE_TS = 1_700_000_000



def make_payload(object_type: str, stripe_id: str, **kwargs):
    payload = {
        "id": stripe_id,
        "object": object_type,
        "livemode": False,
        "created": BASE_TS,
        "metadata": {},
    }
    payload.update(kwargs)
    return payload


PARITY_CASES = [
    ("account", make_payload("account", "acct_123", email="acct@example.com", country="NL"), "StripeAccount", "email", "acct@example.com"),
    ("coupon", make_payload("coupon", "coupon_123", name="WELCOME", duration="once", percent_off=25.0), "StripeCoupon", "name", "WELCOME"),
    ("promotion_code", make_payload("promotion_code", "promo_123", code="HELLO", active=True, coupon="coupon_123"), "StripePromotionCode", "code", "HELLO"),
    ("discount", make_payload("discount", "disc_123", coupon="coupon_123", customer="cus_123", start=BASE_TS), "StripeDiscount", "customer_stripe_id", "cus_123"),
    ("invoiceitem", make_payload("invoiceitem", "ii_123", customer="cus_123", invoice="in_123", amount=500, currency="usd", description="Setup"), "StripeInvoiceItem", "description", "Setup"),
    ("line_item", make_payload("line_item", "li_123", invoice="in_123", amount=700, currency="usd", description="Line"), "StripeLineItem", "description", "Line"),
    ("plan", make_payload("plan", "plan_123", product="prod_123", amount=999, currency="usd", interval="month", interval_count=1), "StripePlan", "interval", "month"),
    ("subscription_schedule", make_payload("subscription_schedule", "subsched_123", customer="cus_123", subscription="sub_123", status="active", current_phase={"start_date": BASE_TS}), "StripeSubscriptionSchedule", "status", "active"),
    ("shipping_rate", make_payload("shipping_rate", "shr_123", display_name="Express", active=True, fixed_amount={"amount": 1200, "currency": "usd"}), "StripeShippingRate", "display_name", "Express"),
    ("tax_code", make_payload("tax_code", "txcd_123", name="Digital", description="Digital goods"), "StripeTaxCode", "name", "Digital"),
    ("tax_id", make_payload("tax_id", "txi_123", customer="cus_123", country="NL", type="eu_vat", value="NL123"), "StripeTaxId", "value", "NL123"),
    ("tax_rate", make_payload("tax_rate", "txr_123", display_name="VAT", inclusive=False, percentage=21.0, country="NL"), "StripeTaxRate", "display_name", "VAT"),
    ("upcoming_invoice", make_payload("upcoming_invoice", "uin_123", customer="cus_123", total=5000, amount_due=5000, currency="usd"), "StripeUpcomingInvoice", "amount_due", 5000),
    ("balance_transaction", make_payload("balance_transaction", "bt_123", source="ch_123", amount=1000, fee=59, net=941, currency="usd", type="charge"), "StripeBalanceTransaction", "net", 941),
    ("charge", make_payload("charge", "ch_123", customer="cus_123", payment_intent="pi_123", amount=1000, amount_refunded=0, currency="usd", status="succeeded", paid=True), "StripeCharge", "status", "succeeded"),
    ("dispute", make_payload("dispute", "dp_123", charge="ch_123", amount=1000, currency="usd", reason="fraudulent", status="warning_needs_response"), "StripeDispute", "reason", "fraudulent"),
    ("event", make_payload("event", "evt_123", type="charge.succeeded", api_version="2020-08-27", request={"id": "req_123", "idempotency_key": "idem_123"}, data={"object": {"id": "ch_123", "object": "charge", "amount": 1000, "currency": "usd", "status": "succeeded", "livemode": False, "created": BASE_TS, "metadata": {}}}), "StripeEvent", "event_type", "charge.succeeded"),
    ("file", make_payload("file", "file_123", filename="report.csv", purpose="dispute_evidence", size=1024, type="csv", url="https://files.example/report.csv"), "StripeFile", "filename", "report.csv"),
    ("file_link", make_payload("file_link", "fl_123", file="file_123", url="https://files.example/link", expired=False), "StripeFileLink", "url", "https://files.example/link"),
    ("file_upload", make_payload("file_upload", "fu_123", filename="upload.pdf", purpose="identity_document", size=2048, type="pdf", url="https://files.example/upload.pdf"), "StripeFileUpload", "filename", "upload.pdf"),
    ("mandate", make_payload("mandate", "mand_123", payment_method="pm_123", type="multi_use", status="active"), "StripeMandate", "status", "active"),
    ("refund", make_payload("refund", "re_123", charge="ch_123", amount=500, currency="usd", reason="requested_by_customer", status="succeeded"), "StripeRefund", "reason", "requested_by_customer"),
    ("setup_intent", make_payload("setup_intent", "seti_123", customer="cus_123", payment_method="pm_123", status="succeeded", usage="off_session", client_secret="seti_secret"), "StripeSetupIntent", "usage", "off_session"),
    ("payout", make_payload("payout", "po_123", amount=10000, currency="usd", type="bank_account", status="paid", arrival_date=BASE_TS), "StripePayout", "payout_type", "bank_account"),
    ("djstripe_payment_method", make_payload("djstripe_payment_method", "dpm_123", customer="cus_123", type="card", billing_details={"name": "Ada"}), "StripeDjstripePaymentMethod", "method_type", "card"),
    ("bank_account", make_payload("bank_account", "ba_123", customer="cus_123", bank_name="ACME Bank", country="NL", currency="eur", last4="6789", status="verified"), "StripeBankAccount", "bank_name", "ACME Bank"),
    ("card", make_payload("card", "card_123", customer="cus_123", brand="visa", country="NL", exp_month=12, exp_year=2030, funding="credit", last4="4242"), "StripeCard", "brand", "visa"),
    ("source", make_payload("source", "src_123", customer="cus_123", type="three_d_secure", status="chargeable", currency="usd", amount=1000), "StripeSource", "source_type", "three_d_secure"),
    ("source_transaction", make_payload("source_transaction", "strx_123", source="src_123", type="charge", status="succeeded", currency="usd", amount=1000), "StripeSourceTransaction", "source_transaction_type", "charge"),
    ("application_fee", make_payload("application_fee", "fee_123", account="acct_123", charge="ch_123", amount=100, amount_refunded=0, currency="usd"), "StripeApplicationFee", "amount", 100),
    ("fee_refund", make_payload("fee_refund", "fr_123", fee="fee_123", amount=20, currency="usd"), "StripeApplicationFeeRefund", "amount", 20),
    ("country_spec", make_payload("country_spec", "NL", default_currency="eur", supported_payment_methods=["card", "ideal"]), "StripeCountrySpec", "default_currency", "eur"),
    ("transfer", make_payload("transfer", "tr_123", destination="acct_dest", amount=7000, currency="usd", reversed=False), "StripeTransfer", "destination_account_stripe_id", "acct_dest"),
    ("transfer_reversal", make_payload("transfer_reversal", "trr_123", transfer="tr_123", amount=1000, currency="usd"), "StripeTransferReversal", "transfer_stripe_id", "tr_123"),
    ("entitlements.feature", make_payload("entitlements.feature", "feat_123", name="priority_support", lookup_key="priority_support", active=True), "StripeFeature", "lookup_key", "priority_support"),
    ("product_feature", make_payload("product_feature", "pf_123", product="prod_123", feature="feat_123"), "StripeProductFeature", "feature_stripe_id", "feat_123"),
    ("entitlements.active_entitlement", make_payload("entitlements.active_entitlement", "ae_123", customer="cus_123", feature="feat_123", lookup_key="priority_support"), "StripeActiveEntitlement", "lookup_key", "priority_support"),
    ("identity.verification_session", make_payload("identity.verification_session", "vs_123", type="document", status="verified", client_secret="vs_secret", url="https://verify.example"), "StripeVerificationSession", "status", "verified"),
    ("identity.verification_report", make_payload("identity.verification_report", "vr_123", verification_session="vs_123", type="document", document={"status": "verified"}), "StripeVerificationReport", "report_type", "document"),
    ("issuing.authorization", make_payload("issuing.authorization", "ia_123", card="ic_123", cardholder="ich_123", amount=1200, currency="usd", approved=True, status="closed"), "StripeIssuingAuthorization", "approved", True),
    ("issuing.cardholder", make_payload("issuing.cardholder", "ich_123", name="Ada Holder", email="ada@example.com", status="active", type="individual"), "StripeIssuingCardholder", "name", "Ada Holder"),
    ("issuing.card", make_payload("issuing.card", "ic_123", cardholder="ich_123", brand="visa", currency="usd", exp_month=12, exp_year=2031, last4="1111", status="active"), "StripeIssuingCard", "last4", "1111"),
    ("issuing.dispute", make_payload("issuing.dispute", "idp_123", transaction="itx_123", amount=1500, currency="usd", status="won"), "StripeIssuingDispute", "status", "won"),
    ("issuing.transaction", make_payload("issuing.transaction", "itx_123", card="ic_123", cardholder="ich_123", amount=1500, currency="usd", type="capture"), "StripeIssuingTransaction", "transaction_type", "capture"),
    ("radar.early_fraud_warning", make_payload("radar.early_fraud_warning", "efw_123", charge="ch_123", actionable=True, fraud_type="card_never_received"), "StripeEarlyFraudWarning", "fraud_type", "card_never_received"),
    ("review", make_payload("review", "rev_123", charge="ch_123", open=True, reason="rule", closed_reason=None), "StripeReview", "open", True),
    ("scheduled_query_run", make_payload("scheduled_query_run", "sqr_123", file="file_123", status="completed", title="Finance export"), "StripeScheduledQueryRun", "title", "Finance export"),
    ("pricing_table", make_payload("pricing_table", "pt_123", active=True, default_view="tabs", locale="en"), "StripePricingTable", "active", True),
]


@pytest.mark.parametrize(("object_type", "payload", "model_name", "field_name", "expected"), PARITY_CASES)
async def test_parity_sync_object_creates_extended_models(
    payments_kit,
    monkeypatch,
    object_type,
    payload,
    model_name,
    field_name,
    expected,
):
    def fake_retrieve_object(requested_object_type: str, stripe_id: str):
        assert requested_object_type == object_type
        assert stripe_id == payload["id"]
        return payload

    monkeypatch.setattr(payments_kit.context.stripe_client, "retrieve_object", fake_retrieve_object)

    await payments_kit.sync_object(object_type, payload["id"])

    model = PARITY_MODEL_SPECS["stripe_event"][0] if object_type == "event" else PARITY_MODEL_SPECS[object_type][0]
    record = await model.get(stripe_id=payload["id"])
    assert getattr(record, field_name) == expected


async def test_internal_parity_models_can_be_persisted(payments_kit):
    api_key = await StripeApiKey.create(
        stripe_id="ak_local_123",
        key_type="secret",
        secret_redacted="sk_test_...1234",
        owner_account_stripe_id="acct_123",
    )
    idempotency_key = await StripeIdempotencyKey.create(
        key="idem_local_123",
        action="customer:create",
        livemode=False,
    )

    assert api_key.owner_account_stripe_id == "acct_123"
    assert idempotency_key.action == "customer:create"


async def test_bootstrap_sync_supports_extended_types(payments_kit, monkeypatch):
    payloads = {
        "coupon": [make_payload("coupon", "coupon_bootstrap", name="BOOT", duration="forever")],
        "charge": [make_payload("charge", "charge_bootstrap", amount=1200, currency="usd", status="succeeded")],
    }

    def fake_list_objects(object_type: str, *, limit: int = 100):
        return payloads.get(object_type, [])

    monkeypatch.setattr(payments_kit.context.stripe_client, "list_objects", fake_list_objects)

    sync_run = await payments_kit.bootstrap_sync(["coupon", "charge"])

    assert sync_run.succeeded is True
    assert sync_run.counts_json["coupon"] == 1
    assert sync_run.counts_json["charge"] == 1
    assert await PARITY_MODEL_SPECS["coupon"][0].get(stripe_id="coupon_bootstrap")
    assert await PARITY_MODEL_SPECS["charge"][0].get(stripe_id="charge_bootstrap")


@pytest.mark.parametrize(
    ("object_type", "payload", "field_name", "expected"),
    [
        (
            "account",
            make_payload("account", "acct_bootstrap", email="acct@example.com", country="NL"),
            "email",
            "acct@example.com",
        ),
        (
            "tax_rate",
            make_payload(
                "tax_rate",
                "txr_bootstrap",
                display_name="VAT",
                inclusive=False,
                percentage=21.0,
                country="NL",
            ),
            "display_name",
            "VAT",
        ),
        (
            "transfer",
            make_payload("transfer", "tr_bootstrap", destination="acct_dest", amount=7000, currency="usd", reversed=False),
            "destination_account_stripe_id",
            "acct_dest",
        ),
    ],
)
async def test_bootstrap_sync_supports_representative_parity_object_types(
    payments_kit,
    monkeypatch,
    object_type,
    payload,
    field_name,
    expected,
):
    def fake_list_objects(requested_object_type: str, *, limit: int = 100):
        assert requested_object_type == object_type
        assert limit == 5
        return [payload]

    monkeypatch.setattr(payments_kit.context.stripe_client, "list_objects", fake_list_objects)

    sync_run = await payments_kit.bootstrap_sync([object_type], limit=5)
    record = await PARITY_MODEL_SPECS[object_type][0].get(stripe_id=payload["id"])

    assert sync_run.succeeded is True
    assert sync_run.counts_json[object_type] == 1
    assert getattr(record, field_name) == expected
    assert payments_kit.events.list()[-1].name == "payments.sync.bootstrap.completed"


async def test_bootstrap_sync_records_failures_when_stripe_listing_raises(payments_kit, monkeypatch):
    def fake_list_objects(object_type: str, *, limit: int = 100):
        assert limit == 2
        raise ValueError(f"boom:{object_type}")

    monkeypatch.setattr(payments_kit.context.stripe_client, "list_objects", fake_list_objects)

    sync_run = await payments_kit.bootstrap_sync(["transfer"], limit=2)

    assert sync_run.succeeded is False
    assert sync_run.counts_json["transfer"] == 0
    assert sync_run.failures_json == [{"object_type": "transfer", "error": "boom:transfer"}]
