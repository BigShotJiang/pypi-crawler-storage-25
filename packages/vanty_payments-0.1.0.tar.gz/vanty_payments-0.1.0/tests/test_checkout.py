from __future__ import annotations

import pytest
from fastapi import HTTPException

from vanty_payments.checkout.schemas import CheckoutLineItem

pytestmark = pytest.mark.integration


async def test_checkout_session_creation_persists_session(payments_kit, monkeypatch):
    async def fake_bootstrap_customer(**kwargs):
        return await payments_kit.sync_service.sync_customer(
            {
                "id": "cus_checkout",
                "object": "customer",
                "email": kwargs["email"],
                "name": kwargs.get("name"),
                "livemode": False,
                "created": 1_700_000_100,
                "metadata": {},
                "invoice_settings": {"default_payment_method": None},
            },
            user_reference=kwargs.get("user_reference"),
            organization_reference=kwargs.get("organization_reference"),
        )

    monkeypatch.setattr(payments_kit.customer_service, "bootstrap_customer", fake_bootstrap_customer)
    monkeypatch.setattr(
        payments_kit.context.stripe_client,
        "create_checkout_session",
        lambda **kwargs: {
            "id": "cs_test_123",
            "object": "checkout.session",
            "customer": kwargs["customer"],
            "mode": kwargs["mode"],
            "status": "open",
            "payment_status": "unpaid",
            "url": "https://checkout.stripe.test/session",
            "success_url": kwargs["success_url"],
            "cancel_url": kwargs["cancel_url"],
            "client_reference_id": kwargs.get("client_reference_id"),
            "subscription": None,
            "payment_intent": None,
            "livemode": False,
            "created": 1_700_000_101,
            "metadata": kwargs.get("metadata", {}),
        },
    )

    session = await payments_kit.create_checkout_session(
        email="ada@example.com",
        name="Ada",
        stripe_customer_id=None,
        user_reference="user_checkout",
        organization_reference="org_checkout",
        metadata={},
        mode="subscription",
        line_items=[CheckoutLineItem(price_id="price_basic_monthly", quantity=1)],
        success_url="https://example.com/success",
        cancel_url="https://example.com/cancel",
        client_reference_id="user_checkout",
    )

    sessions = await payments_kit.checkout_service.list_sessions()

    assert session.stripe_id == "cs_test_123"
    assert session.mode == "subscription"
    assert session.customer_id is not None
    assert sessions[0].stripe_id == "cs_test_123"


async def test_checkout_session_requires_line_items(payments_kit):
    with pytest.raises(HTTPException, match="At least one line item is required") as exc_info:
        await payments_kit.create_checkout_session(
            email="ada@example.com",
            name="Ada",
            stripe_customer_id=None,
            user_reference="user_checkout",
            organization_reference="org_checkout",
            metadata={},
            mode="subscription",
            line_items=[],
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            client_reference_id="user_checkout",
        )

    assert exc_info.value.status_code == 422


async def test_checkout_session_rejects_invalid_mode(payments_kit):
    with pytest.raises(HTTPException, match="mode must be 'subscription' or 'payment'") as exc_info:
        await payments_kit.create_checkout_session(
            email="ada@example.com",
            name="Ada",
            stripe_customer_id=None,
            user_reference="user_checkout",
            organization_reference="org_checkout",
            metadata={},
            mode="invalid",
            line_items=[CheckoutLineItem(price_id="price_basic_monthly", quantity=1)],
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            client_reference_id="user_checkout",
        )

    assert exc_info.value.status_code == 422


async def test_checkout_session_requires_email_when_customer_missing(payments_kit):
    with pytest.raises(HTTPException, match="email is required when no customer exists") as exc_info:
        await payments_kit.create_checkout_session(
            email=None,
            name="Ada",
            stripe_customer_id=None,
            user_reference="user_checkout",
            organization_reference="org_checkout",
            metadata={},
            mode="subscription",
            line_items=[CheckoutLineItem(price_id="price_basic_monthly", quantity=1)],
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            client_reference_id="user_checkout",
        )

    assert exc_info.value.status_code == 422
