from __future__ import annotations

import pytest

from vanty_payments.checkout.schemas import CheckoutLineItem
from vanty_payments.core.events import EventRecorder

pytestmark = pytest.mark.integration


def test_event_recorder_list_returns_copy():
    recorder = EventRecorder()
    recorder.record("payments.example", {"ok": True})

    snapshot = recorder.list()
    snapshot.append(snapshot[0])

    assert len(recorder.list()) == 1
    assert recorder.list()[0].name == "payments.example"


async def test_checkout_or_webhook_flow_records_expected_events(payments_kit, monkeypatch):
    monkeypatch.setattr(
        payments_kit.context.stripe_client,
        "create_customer",
        lambda **kwargs: {
            "id": "cus_events",
            "object": "customer",
            "email": kwargs["email"],
            "name": kwargs.get("name"),
            "livemode": False,
            "created": 1_700_000_300,
            "metadata": kwargs.get("metadata", {}),
            "invoice_settings": {"default_payment_method": None},
        },
    )
    monkeypatch.setattr(
        payments_kit.context.stripe_client,
        "create_checkout_session",
        lambda **kwargs: {
            "id": "cs_events",
            "object": "checkout.session",
            "customer": kwargs["customer"],
            "mode": kwargs["mode"],
            "status": "open",
            "payment_status": "unpaid",
            "url": "https://checkout.stripe.test/events",
            "success_url": kwargs["success_url"],
            "cancel_url": kwargs["cancel_url"],
            "client_reference_id": kwargs.get("client_reference_id"),
            "subscription": None,
            "payment_intent": None,
            "livemode": False,
            "created": 1_700_000_301,
            "metadata": kwargs.get("metadata", {}),
        },
    )

    await payments_kit.create_checkout_session(
        email="events@example.com",
        name="Events User",
        stripe_customer_id=None,
        user_reference="user_events",
        organization_reference="org_events",
        metadata={},
        mode="subscription",
        line_items=[CheckoutLineItem(price_id="price_events", quantity=1)],
        success_url="https://example.com/success",
        cancel_url="https://example.com/cancel",
        client_reference_id="user_events",
    )

    recorded_events = payments_kit.events.list()

    assert [event.name for event in recorded_events] == [
        "payments.customer.bootstrapped",
        "payments.checkout_session.created",
    ]
    assert recorded_events[-1].payload["checkout_session_stripe_id"] == "cs_events"
