from __future__ import annotations

from pathlib import Path

import pytest_asyncio

from vanty_payments.kit import PaymentsKit
from vanty_payments.settings import PaymentsKitSettings


@pytest_asyncio.fixture
async def payments_kit(tmp_path: Path):
    settings = PaymentsKitSettings(
        database_url=f"sqlite://{tmp_path / 'payments.db'}",
        stripe_test_secret_key="sk_test_example",
        stripe_webhook_secret="whsec_example",
    )
    kit = PaymentsKit(settings=settings)
    await kit.init_orm(generate_schemas=True)
    try:
        yield kit
    finally:
        await kit.close_orm()
