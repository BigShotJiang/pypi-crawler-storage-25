class InvalidTextError(Exception):
    pass


class WeakPasswordError(Exception):
    pass