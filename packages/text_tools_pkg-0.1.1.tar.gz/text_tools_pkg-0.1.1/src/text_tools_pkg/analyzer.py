from collections import Counter
from ..utils.validators import validate_text


class TextAnalyzer:

    def __init__(self, text: str):
        validate_text(text)
        self.text = text

    def word_count(self) -> int:
        return len(self.text.split())

    def char_count(self) -> int:
        return len(self.text)

    def frequency(self) -> dict:
        return dict(Counter(self.text))