from .logger import logger


def validate_text(text: str) -> None:
    logger.info("Validating text input")

    if text is None:
        logger.error("Text is None")
        raise InvalidTextError("Text is None")

    if not isinstance(text, str):
        logger.error("Text is not a string")
        raise InvalidTextError("Text must be string")