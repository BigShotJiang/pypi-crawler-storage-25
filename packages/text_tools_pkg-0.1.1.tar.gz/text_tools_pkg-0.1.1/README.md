# text_tools-pkg

Библиотека для базовой текстовой аналитики.

## Возможности

- подсчёт слов;
- частотный анализ символов;
- очистка текста
- генерация slug;
- проверка сложности пароля;
- нормализация пробелов.

## Установка

```bash
pip install text-tools-pkg
```

## Структура

text_tools_pkg/
analyzer.py
processing.py
logger.py
validators.py
exceptions.py

## Использование

```python
from text_tools_pkg.analyzer import TextAnalyzer
from text_tools_pkg.processing import clean_text, slugify, is_strong

# Анализ текста
analyzer = TextAnalyzer("Hello world hello")
print(analyzer.word_count())   # 3
print(analyzer.char_count())   # 17
print(analyzer.frequency())    # {'H': 1, 'e': 2, ...}

# Очистка текста
print(clean_text("Hello   world"))  # "Hello world"

# Генерация slug
print(slugify("Hello World!"))  # "hello-world"

# Проверка пароля
print(is_strong("MyPass123"))  # True
```