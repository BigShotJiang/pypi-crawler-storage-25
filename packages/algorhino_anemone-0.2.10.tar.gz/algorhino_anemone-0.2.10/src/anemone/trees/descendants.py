"""Define the Descendants and RangedDescendants classes.

Descendants:
- Represents a collection of descendants of a tree node at different depths.
- Provides methods to add, remove, and access descendants.
- Keeps track of the number of descendants and the number of descendants at each depth.

RangedDescendants:
- Inherits from Descendants and adds the ability to track a range of depths.
- Provides methods to check if a depth is within the current range or acceptable range.
- Allows adding and removing descendants within the range.
- Provides a method to get the range of depths.

Note: The Descendants and RangedDescendants classes are used in the chipiron project for branch selection in a game.
"""

# pyright: reportUnknownMemberType=false, reportUnknownVariableType=false, reportUnknownArgumentType=false

from collections.abc import Iterator, KeysView
from typing import Any, Self

from sortedcollections import ValueSortedDict
from valanga import StateTag

from anemone.basics import TreeDepth
from anemone.nodes import ITreeNode


class Descendants[NodeT: ITreeNode[Any]]:
    """Represents a collection of descendants for a specific depth in a tree.

    Attributes:
        descendants_at_tree_depth (dict[TreeDepth, dict[str, NodeT]]): A dictionary that maps a depth to a dictionary of descendants.
        number_of_descendants (int): The total number of descendants in the collection.
        number_of_descendants_at_tree_depth (dict[TreeDepth, int]): A dictionary that maps a depth to the number of descendants at that depth.
        min_tree_depth (int | None): The minimum depth in the collection, or None if the collection is empty.
        max_tree_depth (int | None): The maximum depth in the collection, or None if the collection is empty.

    """

    descendants_at_tree_depth: dict[TreeDepth, dict[StateTag, NodeT]]
    number_of_descendants: int
    number_of_descendants_at_tree_depth: dict[TreeDepth, int]
    min_tree_depth: TreeDepth | None
    max_tree_depth: TreeDepth | None

    def __init__(self) -> None:
        """Initialize a Descendants object.

        This method initializes the Descendants object by setting up the necessary attributes.

        Attributes:
        - descendants_at_tree_depth (dict): A dictionary to store the descendants at each depth.
        - number_of_descendants (int): The total number of descendants.
        - number_of_descendants_at_tree_depth (dict): A dictionary to store the number of descendants at each depth.
        - min_tree_depth (int or None): The minimum depth.
        - max_tree_depth (int or None): The maximum depth.

        """
        self.descendants_at_tree_depth = {}
        self.number_of_descendants = 0
        self.number_of_descendants_at_tree_depth = {}
        self.min_tree_depth = None
        self.max_tree_depth = None

    def iter_on_all_nodes(
        self,
    ) -> Iterator[tuple[TreeDepth, StateTag, NodeT]]:
        """Iterate over all stored nodes with their depth and tag."""
        return (
            (hm, node_tag, node)
            for hm, nodes_at_hm in self.descendants_at_tree_depth.items()
            for node_tag, node in nodes_at_hm.items()
        )

    def keys(self) -> KeysView[TreeDepth]:
        """Return a view of the keys in the descendants_at_tree_depth dictionary.

        Returns:
            KeysView[TreeDepth]: A view of the keys in the descendants_at_tree_depth dictionary.

        """
        return self.descendants_at_tree_depth.keys()

    def __setitem__(self, tree_depth: TreeDepth, value: dict[StateTag, NodeT]) -> None:
        """Set the descendants at a specific depth.

        Args:
            tree_depth (TreeDepth): The depth at which to set the descendants.
            value (dict[str, NodeT]): The descendants to set.

        Returns:
            None

        """
        self.descendants_at_tree_depth[tree_depth] = value

    def __getitem__(self, tree_depth: TreeDepth) -> dict[StateTag, NodeT]:
        """Retrieve the descendants at a specific depth.

        Args:
            tree_depth (TreeDepth): The depth to retrieve the descendants for.

        Returns:
            dict[str, NodeT]: A dictionary of descendants at the specified depth.

        """
        return self.descendants_at_tree_depth[tree_depth]

    def __iter__(self) -> Iterator[TreeDepth]:
        """Return an iterator over the descendants at each depth.

        Returns:
            An iterator over the descendants at each depth.

        """
        return iter(self.descendants_at_tree_depth)

    def get_count(self) -> int:
        """Return the number of descendants for the current node.

        Returns:
            int: The number of descendants.

        """
        return self.number_of_descendants

    def contains_node(self, node: NodeT) -> bool:
        """Check if the descendants contain a specific node.

        Args:
            node (NodeT): The node to check for.

        Returns:
            bool: True if the descendants contain the node, False otherwise.

        """
        return (
            node.tree_depth in self.descendants_at_tree_depth
            and node.tag in self[node.tree_depth]
        )

    def has_tree_depth(self, tree_depth: TreeDepth) -> bool:
        """Return whether this registry currently stores nodes at ``tree_depth``."""
        return tree_depth in self.descendants_at_tree_depth

    def contains_tag_at_depth(
        self,
        *,
        tree_depth: TreeDepth,
        state_tag: StateTag,
    ) -> bool:
        """Return whether a node with ``state_tag`` is stored at ``tree_depth``."""
        return self.has_tree_depth(tree_depth) and state_tag in self[tree_depth]

    def node_at(self, *, tree_depth: TreeDepth, state_tag: StateTag) -> NodeT:
        """Return the node stored at one depth/tag pair."""
        return self[tree_depth][state_tag]

    def register_descendant(self, node: NodeT) -> None:
        """Register one node in the descendants bookkeeping."""
        self.add_descendant(node)

    def unregister_descendant(self, node: NodeT) -> None:
        """Remove one node from the descendants bookkeeping."""
        self.remove_descendant(node)

    def remove_descendant(self, node: NodeT) -> None:
        """Remove a descendant node from the tree.

        Args:
            node (NodeT): The node to be removed.

        Returns:
            None

        """
        tree_depth = node.tree_depth
        fen = node.tag

        self.number_of_descendants -= 1
        self[tree_depth].pop(fen)
        self.number_of_descendants_at_tree_depth[tree_depth] -= 1
        if self.number_of_descendants_at_tree_depth[tree_depth] == 0:
            self.number_of_descendants_at_tree_depth.pop(tree_depth)
            self.descendants_at_tree_depth.pop(tree_depth)

    def empty(self) -> bool:
        """Check if the descendants are empty.

        Returns:
            bool: True if the number of descendants is 0, False otherwise.

        """
        return self.number_of_descendants == 0

    def add_descendant(self, node: NodeT) -> None:
        """Add a descendant node to the tree.

        Args:
            node (NodeT): The descendant node to be added.

        Returns:
            None

        """
        tree_depth: TreeDepth = node.tree_depth
        node_tag: StateTag = node.tag

        if tree_depth in self.descendants_at_tree_depth:
            assert node_tag not in self.descendants_at_tree_depth[tree_depth]
            self.descendants_at_tree_depth[tree_depth][node_tag] = node
            self.number_of_descendants_at_tree_depth[tree_depth] += 1
        else:
            self.descendants_at_tree_depth[tree_depth] = {node_tag: node}
            self.number_of_descendants_at_tree_depth[tree_depth] = 1
        self.number_of_descendants += 1

    def __len__(self) -> int:
        """Return the number of descendants at the current depth.

        :return: The number of descendants at the current depth.
        :rtype: int
        """
        return len(self.descendants_at_tree_depth)

    def print_info(self) -> None:
        """Print information about the descendants.

        This method prints the number of descendants and their corresponding depths.
        It also prints the ID and fast representation of each descendant.

        Returns:
            None

        """
        print("---here are the ", self.get_count(), " descendants.")
        for tree_depth in self:
            print(
                "tree_depth: ",
                tree_depth,
                "| (",
                self.number_of_descendants_at_tree_depth[tree_depth],
                "descendants)",
            )  # ,                  end='| ')
            for descendant in self[tree_depth].values():
                print(descendant.id, descendant.tag, end=" ")
            print("")

    def print_stats(self) -> None:
        """Print the statistics of the descendants.

        This method prints the number of descendants at each depth.

        Returns:
            None

        """
        print("---here are the ", self.get_count(), " descendants")
        for tree_depth in self:
            print(
                "tree_depth: ",
                tree_depth,
                "| (",
                self.number_of_descendants_at_tree_depth[tree_depth],
                "descendants)",
            )

    def test(self) -> None:
        """Perform a series of assertions to validate the descendants data structure.

        It checks if the number of descendants at each depth matches the number of descendants stored.
        It also checks if the sum of the lengths of all descendants at each depth matches the total number of descendants.
        """
        assert set(self.descendants_at_tree_depth.keys()) == set(
            self.number_of_descendants_at_tree_depth
        )
        sum_ = 0
        for tree_depth in self:
            sum_ += len(self[tree_depth])
        assert self.number_of_descendants == sum_

        for tree_depth in self:
            assert self.number_of_descendants_at_tree_depth[tree_depth] == len(
                self[tree_depth]
            )


class RangedDescendants[NodeT: ITreeNode[Any]](Descendants[NodeT]):
    """Represent a collection of descendants with a range of depths.

    Attributes:
        min_tree_depth (int | None): The minimum depth in the range.
        max_tree_depth (int | None): The maximum depth in the range.

    """

    min_tree_depth: int | None
    max_tree_depth: int | None

    def __init__(self) -> None:
        """Initialize a Descendants object."""
        super().__init__()
        self.min_tree_depth = None
        self.max_tree_depth = None

    def __str__(self) -> str:
        """Return a string representation of the Descendants object.

        The string includes information about each depth and its descendants.

        Returns:
            str: A string representation of the Descendants object.

        """
        string: str = ""
        for tree_depth in self:
            string += f"tree_depth: {tree_depth} | ({self.number_of_descendants_at_tree_depth[tree_depth]} descendants)\n"
            for descendant in self[tree_depth].values():
                string += f"{descendant.id} "
            string += "\n"
        return string

    def is_new_generation(self, tree_depth: TreeDepth) -> bool:
        """Check if the given depth is a new generation.

        Args:
            tree_depth (TreeDepth): The depth to check.

        Returns:
            bool: True if the depth is a new generation, False otherwise.

        """
        if self.min_tree_depth is not None:
            assert self.max_tree_depth is not None
            return tree_depth == self.max_tree_depth + 1
        return True

    def is_in_the_current_range(self, tree_depth: int) -> bool:
        """Check if the given tree_depth is within the current range.

        Args:
            tree_depth (int): The tree_depth to check.

        Returns:
            bool: True if the tree_depth is within the range, False otherwise.

        """
        if self.min_tree_depth is not None and self.max_tree_depth is not None:
            return self.max_tree_depth >= tree_depth >= self.min_tree_depth
        return False

    def is_in_the_acceptable_range(self, tree_depth: int) -> bool:
        """Check if the given tree_depth is within the acceptable range.

        Args:
            tree_depth (int): The tree_depth to check.

        Returns:
            bool: True if the tree_depth is within the acceptable range, False otherwise.

        """
        if self.min_tree_depth is not None and self.max_tree_depth is not None:
            return self.max_tree_depth + 1 >= tree_depth >= self.min_tree_depth
        return True

    def add_descendant(self, node: NodeT) -> None:
        """Add a descendant node to the tree.

        Args:
            node (NodeT): The descendant node to be added.

        Returns:
            None

        """
        tree_depth: int = node.tree_depth
        node_tag: StateTag = node.tag

        assert self.is_in_the_acceptable_range(tree_depth)
        if self.is_in_the_current_range(tree_depth):
            if tree_depth in self.descendants_at_tree_depth:
                assert node_tag not in self.descendants_at_tree_depth[tree_depth]
            self.descendants_at_tree_depth[tree_depth][node_tag] = node
            self.number_of_descendants_at_tree_depth[tree_depth] += 1
        else:  # tree_depth == len(self.descendants_at_tree_depth)
            assert self.is_new_generation(tree_depth)
            self.descendants_at_tree_depth[tree_depth] = {node_tag: node}
            self.number_of_descendants_at_tree_depth[tree_depth] = 1
            if self.max_tree_depth is not None:
                self.max_tree_depth += 1
            else:
                self.min_tree_depth = tree_depth
                self.max_tree_depth = tree_depth
        self.number_of_descendants += 1

    def remove_descendant(self, node: NodeT) -> None:
        """Remove a descendant node from the tree.

        Args:
            node (NodeT): The node to be removed.

        Returns:
            None

        """
        tree_depth: int = node.tree_depth
        fen = node.tag

        self.number_of_descendants -= 1
        self[tree_depth].pop(fen)
        self.number_of_descendants_at_tree_depth[tree_depth] -= 1
        if self.number_of_descendants_at_tree_depth[tree_depth] == 0:
            self.number_of_descendants_at_tree_depth.pop(tree_depth)
            self.descendants_at_tree_depth.pop(tree_depth)
            if tree_depth == self.max_tree_depth:
                assert self.max_tree_depth is not None
                self.max_tree_depth -= 1
            if tree_depth == self.min_tree_depth:
                assert self.min_tree_depth is not None
                self.min_tree_depth += 1
            assert self.max_tree_depth is not None
            assert self.min_tree_depth is not None
            if self.max_tree_depth < self.min_tree_depth:
                self.max_tree_depth = None
                self.min_tree_depth = None
                assert self.number_of_descendants == 0

    def range(self) -> range:
        """Return a range object representing the depth range.

        The range starts from the minimum depth and ends at the maximum depth.

        Returns:
            range: A range object representing the depth range.

        """
        assert self.max_tree_depth is not None
        assert self.min_tree_depth is not None
        return range(self.min_tree_depth, self.max_tree_depth + 1)

    def merge(self, descendant_1: Self, descendant_2: Self) -> None:
        """Merge the descendants of two nodes into the current node.

        Args:
            descendant_1 (Self): The first descendant node.
            descendant_2 (Self): The second descendant node.

        Returns:
            None

        """
        tree_depths_range = set(descendant_1.keys()) | set(descendant_2.keys())
        assert len(tree_depths_range) > 0
        self.min_tree_depth = min(tree_depths_range)
        self.max_tree_depth = max(tree_depths_range)
        for tree_depth in tree_depths_range:
            if descendant_1.is_in_the_current_range(tree_depth):
                if descendant_2.is_in_the_current_range(tree_depth):
                    self.descendants_at_tree_depth[tree_depth] = {
                        **descendant_1[tree_depth],
                        **descendant_2[tree_depth],
                    }
                    self.number_of_descendants_at_tree_depth[tree_depth] = len(
                        self[tree_depth]
                    )
                    assert self.number_of_descendants_at_tree_depth[tree_depth] == len(
                        {**descendant_1[tree_depth], **descendant_2[tree_depth]}
                    )
                else:
                    self.descendants_at_tree_depth[tree_depth] = descendant_1[
                        tree_depth
                    ]
                    self.number_of_descendants_at_tree_depth[tree_depth] = (
                        descendant_1.number_of_descendants_at_tree_depth[tree_depth]
                    )
            else:
                self.descendants_at_tree_depth[tree_depth] = descendant_2[tree_depth]
                self.number_of_descendants_at_tree_depth[tree_depth] = (
                    descendant_2.number_of_descendants_at_tree_depth[tree_depth]
                )
            self.number_of_descendants += self.number_of_descendants_at_tree_depth[
                tree_depth
            ]

    def test(self) -> None:
        """Perform a test on the descendants object.

        This method checks the validity of the descendants object by asserting various conditions.
        If the `min_tree_depth` attribute is None, it asserts that `max_tree_depth` is also None and
        `number_of_descendants` is 0.
        Otherwise, it asserts that `max_tree_depth` and `min_tree_depth` are not None, and checks if all depths
        between `min_tree_depth` and `max_tree_depth` are present in `descendants_at_tree_depth` dictionary.
        Finally, it iterates over all depths in the descendants object and asserts that each depth
        is within the current range.

        Returns:
            None

        """
        super().test()
        if self.min_tree_depth is None:
            assert self.max_tree_depth is None
            assert self.number_of_descendants == 0
        else:
            assert self.max_tree_depth is not None
            assert self.min_tree_depth is not None
            for i in range(self.min_tree_depth, self.max_tree_depth + 1):
                assert i in self.descendants_at_tree_depth
        for tree_depth in self:
            assert self.is_in_the_current_range(tree_depth)

    def print_info(self) -> None:
        """Print information about the descendants.

        This method calls the `print_info` method of the parent class and then prints the count of descendants,
        the minimum depth, and the maximum depth.

        Returns:
            None

        """
        super().print_info()
        print(
            "---here are the ",
            self.get_count(),
            " descendants. min:",
            self.min_tree_depth,
            ". max:",
            self.max_tree_depth,
        )


class SortedDescendants[NodeT: ITreeNode[Any]](Descendants[NodeT]):
    # TODO: is there a difference between sorted descendant nd sorted value descendant? below?
    """Represent a class that stores sorted descendants of a tree node at different depths.

    Inherits from the Descendants class.
    """

    sorted_descendants_at_tree_depth: dict[int, dict[NodeT, float]]

    def __init__(self) -> None:
        """Initialize sorted descendants storage."""
        super().__init__()
        self.sorted_descendants_at_tree_depth = {}

    def update_value(self, node: NodeT, value: float) -> None:
        """Update the value of a descendant node.

        Args:
            node (NodeT): The descendant node.
            value (float): The new value for the descendant node.

        """
        self.sorted_descendants_at_tree_depth[node.tree_depth][node] = value

    def add_descendant_with_val(self, node: NodeT, value: float) -> None:
        """Add a descendant node with its corresponding value.

        Args:
            node (NodeT): The descendant node to add.
            value (float): The value of the descendant node.

        """
        super().add_descendant(node)
        tree_depth = node.tree_depth

        if tree_depth in self.sorted_descendants_at_tree_depth:
            assert node not in self.sorted_descendants_at_tree_depth[tree_depth]
            self.sorted_descendants_at_tree_depth[tree_depth][node] = value
        else:  # tree_depth == len(self.descendants_at_tree_depth)
            self.sorted_descendants_at_tree_depth[tree_depth] = {node: value}

        assert self.contains_node(node)

    def test(self) -> None:
        """Performs a test to ensure the integrity of the data structure."""
        super().test()
        assert len(self.sorted_descendants_at_tree_depth) == len(
            self.descendants_at_tree_depth
        )
        assert (
            self.sorted_descendants_at_tree_depth.keys()
            == self.descendants_at_tree_depth.keys()
        )
        for (
            tree_depth,
            sorted_descendants,
        ) in self.sorted_descendants_at_tree_depth.items():
            assert len(sorted_descendants) == len(
                self.descendants_at_tree_depth[tree_depth]
            )

    def print_info(self) -> None:
        """Print information about the sorted descendants."""
        super().print_info()
        print("sorted")
        for tree_depth in self:
            print(
                "tree_depth: ",
                tree_depth,
                "| (",
                self.number_of_descendants_at_tree_depth[tree_depth],
                "descendants)",
            )  # ,                  end='| ')
            for descendant, value in self.sorted_descendants_at_tree_depth[
                tree_depth
            ].items():
                print(descendant.id, descendant.tag, "(" + str(value) + ")", end=" ")
            print("")

    def remove_descendant(self, node: NodeT) -> None:
        """Remove a descendant node from the data structure.

        Args:
            node (NodeT): The descendant node to remove.

        """
        super().remove_descendant(node)
        tree_depth = node.tree_depth
        self.sorted_descendants_at_tree_depth[tree_depth].pop(node)
        if tree_depth not in self.number_of_descendants_at_tree_depth:
            self.sorted_descendants_at_tree_depth.pop(tree_depth)
        assert not self.contains_node(node)

    def contains_node(self, node: NodeT) -> bool:
        """Check if a descendant node is present in the data structure.

        Args:
            node (NodeT): The descendant node to check.

        Returns:
            bool: True if the descendant node is present, False otherwise.

        """
        reply_base = super().contains_node(node)
        rep = (
            node.tree_depth in self.descendants_at_tree_depth
            and node in self.sorted_descendants_at_tree_depth[node.tree_depth]
        )
        assert reply_base == rep
        return rep


class SortedValueDescendants[NodeT: ITreeNode[Any]](Descendants[NodeT]):
    """Represent a class for managing sorted descendants with associated values.

    Inherits from the `Descendants` class.
    """

    sorted_descendants_at_tree_depth: dict[TreeDepth, ValueSortedDict]

    def __init__(self) -> None:
        """Initialize a Sorted Value Descendants object."""
        super().__init__()
        self.sorted_descendants_at_tree_depth = {}

    def update_value(self, node: NodeT, value: float) -> None:
        """Update the value associated with a given node.

        Args:
            node (NodeT): The node to update the value for.
            value (float): The new value to associate with the node.

        Returns:
            None

        """
        self.sorted_descendants_at_tree_depth[node.tree_depth][node] = value

    def add_descendant_val(self, node: NodeT, value: float) -> None:
        """Add a descendant node with an associated value.

        Args:
            node (NodeT): The descendant node to add.
            value (float): The value associated with the descendant node.

        Returns:
            None

        """
        super().add_descendant(node)
        tree_depth = node.tree_depth

        if tree_depth in self.sorted_descendants_at_tree_depth:
            assert node not in self.sorted_descendants_at_tree_depth[tree_depth]
            self.sorted_descendants_at_tree_depth[tree_depth][node] = value
        else:
            self.sorted_descendants_at_tree_depth[tree_depth] = ValueSortedDict(
                {node: value}
            )

    def test(self) -> None:
        """Performs a test to ensure the integrity of the sorted descendants.

        Returns:
            None

        """
        super().test()
        assert len(self.sorted_descendants_at_tree_depth) == len(
            self.descendants_at_tree_depth
        )
        assert (
            self.sorted_descendants_at_tree_depth.keys()
            == self.descendants_at_tree_depth.keys()
        )
        for (
            tree_depth,
            sorted_descendants,
        ) in self.sorted_descendants_at_tree_depth.items():
            assert len(sorted_descendants) == len(
                self.descendants_at_tree_depth[tree_depth]
            )

    def print_info(self) -> None:
        """Print information about the sorted descendants.

        Returns:
            None

        """
        super().print_info()
        print("sorted")
        for tree_depth in self:
            print(
                "tree_depth: ",
                tree_depth,
                "| (",
                self.number_of_descendants_at_tree_depth[tree_depth],
                "descendants)",
            )
            for descendant, value in self.sorted_descendants_at_tree_depth[
                tree_depth
            ].items():
                print(str(descendant.id) + "(" + str(value) + ")", end=" ")
            print("")

    def remove_descendant(self, node: NodeT) -> None:
        """Remove a descendant node.

        Args:
            node (NodeT): The descendant node to remove.

        Returns:
            None

        """
        super().remove_descendant(node)
        tree_depth = node.tree_depth

        self.sorted_descendants_at_tree_depth[tree_depth].pop(node)
        if tree_depth not in self.number_of_descendants_at_tree_depth:
            self.sorted_descendants_at_tree_depth.pop(tree_depth)
