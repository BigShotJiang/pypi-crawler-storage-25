"""Adversarial tree-evaluation family."""
