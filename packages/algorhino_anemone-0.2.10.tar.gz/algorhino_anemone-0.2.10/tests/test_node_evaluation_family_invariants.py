"""Focused cross-family invariants for node-evaluation families."""

from dataclasses import dataclass, field
from enum import Enum
from types import SimpleNamespace
from typing import Any

from valanga import Color
from valanga.evaluations import Certainty, Value

from anemone.backup_policies import ExplicitMaxBackupPolicy, ExplicitMinimaxBackupPolicy
from anemone.node_evaluation.common.branch_ordering import DecisionOrderedEvaluation
from anemone.node_evaluation.tree.adversarial.node_minmax_evaluation import (
    NodeMinmaxEvaluation,
)
from anemone.node_evaluation.tree.decision_ordering import BranchOrderingKey
from anemone.node_evaluation.tree.factory import (
    NodeTreeMinmaxEvaluationFactory,
)
from anemone.node_evaluation.tree.node_tree_evaluation import (
    BestBranchEquivalenceMode,
    NodeTreeEvaluation,
    NodeTreeEvaluationState,
)
from anemone.node_evaluation.tree.single_agent.factory import NodeMaxEvaluationFactory
from anemone.node_evaluation.tree.single_agent.node_max_evaluation import (
    NodeMaxEvaluation,
)
from anemone.objectives import AdversarialZeroSumObjective, SingleAgentMaxObjective


class _SoloRole(Enum):
    SOLO = "solo"


class _FakeOverEvent:
    def is_over(self) -> bool:
        return True

    def is_draw(self) -> bool:
        return False

    def is_win_for(self, role: object) -> bool:
        del role
        return False

    def is_loss_for(self, role: object) -> bool:
        del role
        return False


@dataclass(slots=True)
class _HookDrivenEvaluation(NodeTreeEvaluationState[Any, Any]):
    ordered_branches: tuple[int, ...] = ()
    best_branch_key: int | None = None
    ordering_keys: dict[int, BranchOrderingKey] = field(default_factory=dict)
    branch_values: dict[int, Value | None] = field(default_factory=dict)
    tactical_quality_keys: dict[int, object] = field(default_factory=dict)
    logistic_scores: dict[int, float] = field(default_factory=dict)
    considered_equal_branches: tuple[int, ...] = ()

    def _ordered_candidate_branches_for_frontier(self) -> tuple[int, ...]:
        return self.ordered_branches

    def best_branch(self) -> int | None:
        return self.best_branch_key

    def _ordered_candidate_branches_for_best_equivalence(self) -> tuple[int, ...]:
        return self.ordered_branches

    def _branch_ordering_key(self, branch: int) -> BranchOrderingKey:
        return self.ordering_keys[branch]

    def child_value_candidate(self, branch_key: int) -> Value | None:
        return self.branch_values.get(branch_key)

    def _branch_tactical_quality_key(self, branch: int) -> object:
        return self.tactical_quality_keys[branch]

    def _branch_values_are_considered_equal(
        self,
        *,
        branch: int,
        best_branch: int,
    ) -> bool:
        assert best_branch == self.best_branch_key
        return branch in self.considered_equal_branches

    def _branch_logistic_equivalence_score(self, branch: int) -> float:
        return self.logistic_scores[branch]


def _adversarial_tree_node() -> Any:
    return SimpleNamespace(
        id=1,
        state=SimpleNamespace(turn=Color.WHITE),
        branches_children={},
        all_branches_generated=True,
    )


def _single_agent_tree_node() -> Any:
    return SimpleNamespace(
        id=2,
        state=SimpleNamespace(turn=_SoloRole.SOLO, phase="single-agent"),
        branches_children={},
        all_branches_generated=True,
    )


def _best_branch(eval_like: NodeTreeEvaluation[Any]) -> Any:
    return eval_like.best_branch()


def test_canonical_value_semantics_align_across_families() -> None:
    adversarial = NodeMinmaxEvaluation(tree_node=_adversarial_tree_node())
    single_agent = NodeMaxEvaluation(tree_node=_single_agent_tree_node())

    direct = Value(score=0.2, certainty=Certainty.ESTIMATE)
    backed_up = Value(score=0.9, certainty=Certainty.ESTIMATE)

    adversarial.direct_value = direct
    adversarial.backed_up_value = backed_up
    single_agent.direct_value = direct
    single_agent.backed_up_value = backed_up

    assert adversarial.get_value() == backed_up
    assert single_agent.get_value() == backed_up

    adversarial.backed_up_value = None
    single_agent.backed_up_value = None

    assert adversarial.get_value() == direct
    assert single_agent.get_value() == direct


def test_exact_value_and_terminality_semantics_align_across_families() -> None:
    terminal_value = Value(
        score=1.0,
        certainty=Certainty.FORCED,
        over_event=_FakeOverEvent(),
    )
    adversarial = NodeMinmaxEvaluation(tree_node=_adversarial_tree_node())
    single_agent = NodeMaxEvaluation(tree_node=_single_agent_tree_node())
    adversarial.direct_value = terminal_value
    single_agent.direct_value = terminal_value

    assert adversarial.has_exact_value()
    assert single_agent.has_exact_value()
    assert not adversarial.is_terminal()
    assert not single_agent.is_terminal()
    assert adversarial.over_event is not None
    assert single_agent.over_event is not None


def test_default_construction_is_intentional_in_both_families() -> None:
    adversarial_factory = NodeTreeMinmaxEvaluationFactory()
    single_agent_factory = NodeMaxEvaluationFactory()

    adversarial_eval = adversarial_factory.create(_adversarial_tree_node())
    single_agent_eval = single_agent_factory.create(_single_agent_tree_node())

    assert isinstance(adversarial_eval.objective, AdversarialZeroSumObjective)
    assert isinstance(adversarial_eval.backup_policy, ExplicitMinimaxBackupPolicy)
    assert isinstance(single_agent_eval.objective, SingleAgentMaxObjective)
    assert isinstance(single_agent_eval.backup_policy, ExplicitMaxBackupPolicy)


def test_family_specific_objective_semantics_remain_distinct() -> None:
    adversarial_objective = AdversarialZeroSumObjective()
    single_agent_objective = SingleAgentMaxObjective()
    left = Value(score=0.2, certainty=Certainty.ESTIMATE)
    right = Value(score=0.8, certainty=Certainty.ESTIMATE)

    assert (
        adversarial_objective.semantic_compare(
            left,
            right,
            SimpleNamespace(turn=Color.BLACK),
        )
        > 0
    )
    assert (
        single_agent_objective.semantic_compare(
            left,
            right,
            SimpleNamespace(turn=_SoloRole.SOLO, phase="single-agent"),
        )
        < 0
    )


def test_branch_ordering_key_preserves_legacy_field_ordering() -> None:
    lower_primary = BranchOrderingKey(
        primary_score=0.4,
        tactical_tiebreak=99,
        stable_tiebreak_id=99,
    )
    lower_tactical = BranchOrderingKey(
        primary_score=0.5,
        tactical_tiebreak=0,
        stable_tiebreak_id=20,
    )
    lower_stable_id = BranchOrderingKey(
        primary_score=0.5,
        tactical_tiebreak=0,
        stable_tiebreak_id=30,
    )

    assert sorted(
        [
            lower_stable_id,
            lower_primary,
            BranchOrderingKey(
                primary_score=0.5,
                tactical_tiebreak=1,
                stable_tiebreak_id=10,
            ),
            lower_tactical,
        ]
    ) == [
        lower_primary,
        lower_tactical,
        lower_stable_id,
        BranchOrderingKey(
            primary_score=0.5,
            tactical_tiebreak=1,
            stable_tiebreak_id=10,
        ),
    ]


def test_generic_tree_evaluation_protocol_aligns_across_families() -> None:
    adversarial = NodeMinmaxEvaluation(tree_node=_adversarial_tree_node())
    single_agent = NodeMaxEvaluation(tree_node=_single_agent_tree_node())

    assert _best_branch(adversarial) is None
    assert _best_branch(single_agent) is None
    assert adversarial.best_branch_sequence == []
    assert single_agent.best_branch_sequence == []
    assert adversarial.best_equivalent_branches(BestBranchEquivalenceMode.EQUAL) == []
    assert single_agent.best_equivalent_branches(BestBranchEquivalenceMode.EQUAL) == []


def test_families_share_concrete_tree_evaluation_state_base() -> None:
    adversarial = NodeMinmaxEvaluation(tree_node=_adversarial_tree_node())
    single_agent = NodeMaxEvaluation(tree_node=_single_agent_tree_node())

    assert isinstance(adversarial, NodeTreeEvaluationState)
    assert isinstance(single_agent, NodeTreeEvaluationState)


def test_families_inherit_shared_exact_outcome_polarity() -> None:
    adversarial = NodeMinmaxEvaluation(tree_node=_adversarial_tree_node())
    single_agent = NodeMaxEvaluation(tree_node=_single_agent_tree_node())
    favorable_value = Value(score=0.0, certainty=Certainty.FORCED)
    unfavorable_value = Value(score=0.0, certainty=Certainty.FORCED)

    @dataclass(frozen=True)
    class _RoleRelativeOverEvent:
        winner: object | None = None
        loser: object | None = None

        def is_draw(self) -> bool:
            return False

        def is_win_for(self, role: object) -> bool:
            return self.winner == role

        def is_loss_for(self, role: object) -> bool:
            if self.loser is not None:
                return self.loser == role
            return self.winner is not None and self.winner != role

    assert (
        NodeMaxEvaluation._exact_outcome_polarity
        is NodeTreeEvaluationState._exact_outcome_polarity
    )
    assert (
        NodeMinmaxEvaluation._exact_outcome_polarity
        is NodeTreeEvaluationState._exact_outcome_polarity
    )
    assert (
        single_agent._exact_outcome_polarity(
            over_event=_RoleRelativeOverEvent(winner=_SoloRole.SOLO),
            child_value=favorable_value,
        )
        == 1
    )
    assert (
        single_agent._exact_outcome_polarity(
            over_event=_RoleRelativeOverEvent(loser=_SoloRole.SOLO),
            child_value=unfavorable_value,
        )
        == -1
    )
    assert (
        adversarial._exact_outcome_polarity(
            over_event=_RoleRelativeOverEvent(winner=Color.WHITE),
            child_value=favorable_value,
        )
        == 1
    )
    assert (
        adversarial._exact_outcome_polarity(
            over_event=_RoleRelativeOverEvent(loser=Color.WHITE),
            child_value=unfavorable_value,
        )
        == -1
    )


def test_shared_tree_evaluation_base_owns_generic_best_equivalence_dispatch() -> None:
    generic_eval = _HookDrivenEvaluation(
        tree_node=SimpleNamespace(
            id=3,
            state=SimpleNamespace(),
            branches_children={0: object(), 1: object(), 2: object()},
            all_branches_generated=True,
        ),
        ordered_branches=(0, 1, 2),
        best_branch_key=0,
        ordering_keys={
            0: BranchOrderingKey(
                primary_score=0.50,
                tactical_tiebreak=0,
                stable_tiebreak_id=10,
            ),
            1: BranchOrderingKey(
                primary_score=0.52,
                tactical_tiebreak=1,
                stable_tiebreak_id=11,
            ),
            2: BranchOrderingKey(
                primary_score=0.50,
                tactical_tiebreak=0,
                stable_tiebreak_id=12,
            ),
        },
        branch_values={
            0: Value(score=0.50, certainty=Certainty.ESTIMATE),
            1: Value(score=0.52, certainty=Certainty.ESTIMATE),
            2: Value(score=0.50, certainty=Certainty.ESTIMATE),
        },
        tactical_quality_keys={0: 0, 1: 1, 2: 2},
        logistic_scores={0: 1.000, 1: 1.005, 2: 1.500},
        considered_equal_branches=(0, 2),
    )

    assert generic_eval.best_equivalent_branches(BestBranchEquivalenceMode.EQUAL) == [0]
    assert generic_eval.best_equivalent_branches(
        BestBranchEquivalenceMode.CONSIDERED_EQUAL
    ) == [0, 2]
    assert generic_eval.best_equivalent_branches(
        BestBranchEquivalenceMode.ALMOST_EQUAL
    ) == [0, 2]
    assert generic_eval.best_equivalent_branches(
        BestBranchEquivalenceMode.ALMOST_EQUAL_LOGISTIC
    ) == [0, 1]


def test_shared_frontier_candidate_helper_preserves_order_and_appends_children() -> (
    None
):
    generic_eval = _HookDrivenEvaluation(
        tree_node=SimpleNamespace(
            id=4,
            state=SimpleNamespace(),
            branches_children={2: object(), 0: object(), 1: object(), 3: object()},
            all_branches_generated=True,
        ),
    )

    assert generic_eval._ordered_candidate_branches_with_child_fallback(
        (0, 2, 0, 99)
    ) == (0, 2, 1, 3)


def test_decision_ordered_capability_aligns_across_families() -> None:
    adversarial = NodeMinmaxEvaluation(tree_node=_adversarial_tree_node())
    single_agent = NodeMaxEvaluation(tree_node=_single_agent_tree_node())

    assert isinstance(adversarial, DecisionOrderedEvaluation)
    assert isinstance(single_agent, DecisionOrderedEvaluation)
    assert adversarial.decision_ordered_branches() == []
    assert single_agent.decision_ordered_branches() == []
