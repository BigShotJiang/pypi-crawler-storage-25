"""Focused tests for Value-object flow during direct evaluation and backup."""

from collections.abc import Sequence
from types import SimpleNamespace
from typing import Any

from valanga import Color, Outcome, OverEvent
from valanga.evaluations import Certainty, Value

from anemone.node_evaluation.common.node_value_evaluation import NodeValueEvaluation
from anemone.node_evaluation.direct.node_direct_evaluator import (
    DirectValueInvariantError,
    EvaluationQueries,
    NodeDirectEvaluator,
)
from anemone.node_evaluation.tree.adversarial.node_minmax_evaluation import (
    NodeMinmaxEvaluation,
)
from anemone.objectives import Objective


class _OverDetector:
    def check_obvious_over_events(
        self, state: SimpleNamespace
    ) -> tuple[Any | None, float | None]:
        if state.is_terminal:
            over = OverEvent(
                outcome=Outcome.WIN,
                winner=Color.WHITE,
                termination="terminal",
            )
            return (
                over,
                1.0,
            )
        return None, None


class _OverDetectorWithoutEvaluation:
    def check_obvious_over_events(
        self, state: SimpleNamespace
    ) -> tuple[Any | None, float | None]:
        if state.is_terminal:
            over = OverEvent(
                outcome=Outcome.WIN,
                winner=Color.WHITE,
                termination="terminal",
            )
            return over, None
        return None, None


class _BatchValueEvaluator:
    over = _OverDetector()

    def evaluate(self, state: Any) -> Value:
        return Value(
            score=state.base_score,
            certainty=Certainty.ESTIMATE,
            over_event=None,
        )

    def evaluate_batch_items(self, items: Sequence[Any]) -> list[Value]:
        return [
            Value(
                score=node.state.base_score,
                certainty=Certainty.ESTIMATE,
                over_event=None,
            )
            for node in items
        ]


class _InvalidEstimateWithOverBatchValueEvaluator(_BatchValueEvaluator):
    def evaluate_batch_items(self, items: Sequence[Any]) -> list[Value]:
        return [
            Value(
                score=node.state.base_score,
                certainty=Certainty.ESTIMATE,
                over_event=OverEvent(outcome=Outcome.UNKNOWN),
            )
            for node in items
        ]


class _InvalidTerminalBatchValueEvaluator(_BatchValueEvaluator):
    def evaluate_batch_items(self, items: Sequence[Any]) -> list[Value]:
        terminal = OverEvent(
            outcome=Outcome.WIN,
            winner=Color.WHITE,
            termination="invalid-direct-terminal",
        )
        return [
            Value(
                score=node.state.base_score,
                certainty=Certainty.TERMINAL,
                over_event=terminal,
            )
            for node in items
        ]


class _TerminalScoreObjective(Objective[Any]):
    def evaluate_value(self, value: Value, state: Any) -> float:
        del state
        return value.score

    def semantic_compare(self, left: Value, right: Value, state: Any) -> int:
        del state
        if left.score > right.score:
            return 1
        if left.score < right.score:
            return -1
        return 0

    def terminal_score(self, over_event: OverEvent, state: Any) -> float:
        del over_event, state
        return 42.0


def _make_node(
    *, node_id: int, turn: Color, base_score: float, is_terminal: bool
) -> Any:
    state = SimpleNamespace(turn=turn, base_score=base_score, is_terminal=is_terminal)
    tree_node = SimpleNamespace(
        id=node_id,
        state=state,
        branches_children={},
        all_branches_generated=False,
    )
    tree_evaluation = NodeMinmaxEvaluation(tree_node=tree_node)
    return SimpleNamespace(
        id=node_id,
        state=state,
        tree_node=tree_node,
        tree_evaluation=tree_evaluation,
        tree_depth=0,
        is_over=tree_evaluation.is_terminal,
    )


def test_non_terminal_evaluation_sets_direct_value() -> None:
    """Non-terminal direct evaluation stores a non-terminal Value object."""
    evaluator = NodeDirectEvaluator(master_state_evaluator=_BatchValueEvaluator())
    node = _make_node(node_id=1, turn=Color.WHITE, base_score=0.3, is_terminal=False)
    queries = EvaluationQueries()

    evaluator.add_evaluation_query(node, queries)
    evaluator.evaluate_all_queried_nodes(queries)

    assert node.tree_evaluation.direct_value is not None
    assert node.tree_evaluation.direct_value.certainty is Certainty.ESTIMATE
    assert node.tree_evaluation.direct_value.over_event is None


def test_non_terminal_batch_evaluation_rejects_estimate_with_over_event() -> None:
    evaluator = NodeDirectEvaluator(
        master_state_evaluator=_InvalidEstimateWithOverBatchValueEvaluator()
    )
    node = _make_node(node_id=6, turn=Color.WHITE, base_score=0.3, is_terminal=False)
    queries = EvaluationQueries()

    evaluator.add_evaluation_query(node, queries)

    try:
        evaluator.evaluate_all_queried_nodes(queries)
    except DirectValueInvariantError as exc:
        assert "ESTIMATE" in str(exc)
    else:
        raise AssertionError


def test_non_terminal_batch_evaluation_rejects_terminal_certainty() -> None:
    evaluator = NodeDirectEvaluator(
        master_state_evaluator=_InvalidTerminalBatchValueEvaluator()
    )
    node = _make_node(node_id=7, turn=Color.WHITE, base_score=0.3, is_terminal=False)
    queries = EvaluationQueries()

    evaluator.add_evaluation_query(node, queries)

    try:
        evaluator.evaluate_all_queried_nodes(queries)
    except DirectValueInvariantError as exc:
        assert "TERMINAL" in str(exc)
    else:
        raise AssertionError


def test_terminal_detection_sets_terminal_direct_value() -> None:
    """Terminal detection stores a terminal Value with over-event metadata."""
    evaluator = NodeDirectEvaluator(master_state_evaluator=_BatchValueEvaluator())
    node = _make_node(node_id=2, turn=Color.WHITE, base_score=0.0, is_terminal=True)
    queries = EvaluationQueries()

    evaluator.add_evaluation_query(node, queries)
    evaluator.evaluate_all_queried_nodes(queries)

    assert node.tree_evaluation.direct_value is not None
    assert node.tree_evaluation.direct_value.certainty is Certainty.TERMINAL
    assert node.tree_evaluation.direct_value.over_event is not None


def test_terminal_detection_uses_objective_terminal_score_when_needed() -> None:
    """Terminal direct evaluation should source fallback terminal scores from Objective."""
    evaluator = NodeDirectEvaluator(master_state_evaluator=_BatchValueEvaluator())
    node = _make_node(node_id=21, turn=Color.WHITE, base_score=0.0, is_terminal=True)
    node.tree_evaluation.objective = _TerminalScoreObjective()
    evaluator.master_state_value_evaluator.over = _OverDetectorWithoutEvaluation()

    evaluator.check_obvious_over_events(node)

    assert node.tree_evaluation.direct_value is not None
    assert node.tree_evaluation.direct_value.score == 42.0


def test_terminal_query_routes_to_over_nodes_immediately() -> None:
    """Terminal detection routes node to over_nodes and skips not_over queue."""
    evaluator = NodeDirectEvaluator(master_state_evaluator=_BatchValueEvaluator())
    node = _make_node(node_id=3, turn=Color.WHITE, base_score=0.0, is_terminal=True)
    queries = EvaluationQueries()

    evaluator.add_evaluation_query(node, queries)

    assert queries.over_nodes == [node]
    assert queries.not_over_nodes == []
    assert node.tree_evaluation.direct_value is not None
    assert node.tree_evaluation.direct_value.certainty is Certainty.TERMINAL


def test_add_query_does_not_require_algorithm_node_is_over() -> None:
    """Queue routing uses node-local terminal Value semantics, not AlgorithmNode.is_over()."""
    evaluator = NodeDirectEvaluator(master_state_evaluator=_BatchValueEvaluator())
    node = _make_node(node_id=4, turn=Color.WHITE, base_score=0.0, is_terminal=True)

    def _legacy_is_over_should_not_be_called() -> bool:
        raise AssertionError("add_evaluation_query should use is_terminal()")

    node.is_over = _legacy_is_over_should_not_be_called
    queries = EvaluationQueries()

    evaluator.add_evaluation_query(node, queries)

    assert queries.over_nodes == [node]
    assert queries.not_over_nodes == []


def test_minmax_value_is_populated_after_child_backup_and_bridge_holds() -> None:
    """Backup populates minmax Value and keeps float-score bridge aligned."""
    parent = _make_node(node_id=10, turn=Color.WHITE, base_score=0.1, is_terminal=False)
    child = _make_node(node_id=11, turn=Color.BLACK, base_score=0.8, is_terminal=False)

    parent.tree_node.branches_children = {0: child}
    parent.tree_node.all_branches_generated = True

    child.tree_evaluation.direct_value = Value(
        score=0.8, certainty=Certainty.ESTIMATE, over_event=None
    )

    parent.tree_evaluation.direct_value = Value(
        score=0.1, certainty=Certainty.ESTIMATE, over_event=None
    )
    parent.tree_evaluation.backup_from_children(
        branches_with_updated_value={0},
        branches_with_updated_best_branch_seq=set(),
    )

    assert parent.tree_evaluation.minmax_value is not None
    assert (
        parent.tree_evaluation.get_score() == parent.tree_evaluation.minmax_value.score
    )


def test_get_value_prefers_minmax_else_direct() -> None:
    """Canonical Value getter returns minmax when present, else direct."""
    node = _make_node(node_id=20, turn=Color.WHITE, base_score=0.2, is_terminal=False)

    direct = Value(score=0.2, certainty=Certainty.ESTIMATE, over_event=None)
    node.tree_evaluation.direct_value = direct

    assert node.tree_evaluation.get_value() == direct

    minmax = Value(score=0.6, certainty=Certainty.FORCED)
    node.tree_evaluation.minmax_value = minmax

    assert node.tree_evaluation.get_value() == minmax


def _protocol_score(eval_like: NodeValueEvaluation) -> float:
    return eval_like.get_score()


def test_node_tree_evaluation_protocol_exposes_value_api() -> None:
    node = _make_node(node_id=99, turn=Color.WHITE, base_score=0.4, is_terminal=False)
    node.tree_evaluation.direct_value = Value(
        score=0.4, certainty=Certainty.ESTIMATE, over_event=None
    )

    assert _protocol_score(node.tree_evaluation) == 0.4
    assert node.tree_evaluation.get_value_candidate() is not None
    assert node.tree_evaluation.get_value().score == 0.4
