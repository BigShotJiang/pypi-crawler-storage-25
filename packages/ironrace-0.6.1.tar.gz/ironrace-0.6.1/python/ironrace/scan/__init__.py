"""IronRace Scan Engine — semantic code search over local repositories.

Chunks code using tree-sitter AST (Python, TypeScript, JavaScript, Rust, Go)
or sliding window fallback, embeds with sentence-transformers, and searches
with HNSW approximate nearest neighbors.

Features:
- Git-aware caching with incremental re-indexing
- ONNX backend for faster inference (with PyTorch fallback)
- File-context mode returning full files instead of function snippets
- Batch query support (model loads once)
- Parallel git cache validation

Usage:
    from ironrace.scan import scan_repo, search_with_file_context, batch_scan

    # Single query
    result = scan_repo("/path/to/repo", query="auth middleware")

    # Full-file context (imports, class hierarchy included)
    result = search_with_file_context("/path/to/repo", query="auth middleware")

    # Batch queries (model loads once)
    result = batch_scan("/path/to/repo", ["auth", "database", "API endpoints"])
"""

from .cache import (
    CacheManifest,
    ensure_indexed,
    get_stale_files,
    is_indexed,
    load_chunks,
    load_embeddings,
    load_manifest,
)
from .chunker import LANG_MAP, Chunk, chunk_file, chunk_repo, discover_files
from .scanner import (
    batch_scan,
    generate_overview,
    scan_repo,
    search_with_file_context,
)

__all__ = [
    "batch_scan",
    "generate_overview",
    "scan_repo",
    "search_with_file_context",
    "Chunk",
    "chunk_file",
    "chunk_repo",
    "discover_files",
    "LANG_MAP",
    "CacheManifest",
    "ensure_indexed",
    "get_stale_files",
    "is_indexed",
    "load_chunks",
    "load_embeddings",
    "load_manifest",
]
