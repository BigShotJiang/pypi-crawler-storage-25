"""Hybrid AST-aware + sliding window code chunker.

Uses tree-sitter for Python, TypeScript, JavaScript, Rust, Go to extract
function/class-level chunks. Falls back to sliding window for unsupported
languages and non-code files.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

# Tree-sitter language mappings
_TS_LANGUAGES: dict[str, tuple[str, str]] = {}  # ext -> (module_name, language_name)
_TS_LOADED: dict[str, object] = {}  # cache loaded languages

# File extension -> language mapping
LANG_MAP = {
    ".py": "python",
    ".ts": "typescript",
    ".tsx": "tsx",
    ".js": "javascript",
    ".jsx": "javascript",
    ".rs": "rust",
    ".go": "go",
    ".swift": "swift",
    ".java": "java",
    ".rb": "ruby",
    ".md": "markdown",
    ".json": "json",
    ".yaml": "yaml",
    ".yml": "yaml",
    ".toml": "toml",
    ".html": "html",
    ".css": "css",
    ".sql": "sql",
}

# Tree-sitter supported languages and their node types for extraction
TS_CONFIG = {
    "python": {
        "module": "tree_sitter_python",
        "node_types": ["function_definition", "class_definition", "decorated_definition"],
    },
    "typescript": {
        "module": "tree_sitter_typescript",
        "lang_func": "language_typescript",
        "node_types": [
            "function_declaration",
            "class_declaration",
            "method_definition",
            "arrow_function",
            "export_statement",
        ],
    },
    "tsx": {
        "module": "tree_sitter_typescript",
        "lang_func": "language_tsx",
        "node_types": [
            "function_declaration",
            "class_declaration",
            "method_definition",
            "arrow_function",
            "export_statement",
        ],
    },
    "javascript": {
        "module": "tree_sitter_javascript",
        "node_types": [
            "function_declaration",
            "class_declaration",
            "method_definition",
            "arrow_function",
            "export_statement",
        ],
    },
    "rust": {
        "module": "tree_sitter_rust",
        "node_types": [
            "function_item",
            "impl_item",
            "struct_item",
            "enum_item",
            "trait_item",
        ],
    },
    "go": {
        "module": "tree_sitter_go",
        "node_types": [
            "function_declaration",
            "method_declaration",
            "type_declaration",
        ],
    },
}

# Directories and files to always skip
SKIP_DIRS = frozenset({
    ".git", ".svn", ".hg", "node_modules", "__pycache__", ".venv", "venv",
    "env", ".env", ".tox", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    "dist", "build", "target", ".next", ".nuxt", "coverage",
    ".claude", ".idea", ".vscode",
})

SKIP_FILES = frozenset({
    "package-lock.json", "yarn.lock", "pnpm-lock.yaml", "Cargo.lock",
    "poetry.lock", "Pipfile.lock", ".DS_Store",
})

MAX_FILE_SIZE = 512 * 1024  # 512KB - skip very large files

# Sliding window defaults
WINDOW_TOKENS = 512
OVERLAP_TOKENS = 64
APPROX_CHARS_PER_TOKEN = 4


@dataclass(frozen=True)
class Chunk:
    file_path: str
    content: str
    language: str
    symbol_name: str | None = None
    symbol_type: str | None = None
    line_start: int = 0
    line_end: int = 0


def _get_ts_parser(language: str):
    """Get or create a tree-sitter parser for the given language."""
    try:
        import tree_sitter
    except ImportError:
        return None

    if language not in TS_CONFIG:
        return None

    config = TS_CONFIG[language]

    if language not in _TS_LOADED:
        try:
            import importlib
            mod = importlib.import_module(config["module"])
            lang_func = config.get("lang_func", "language")
            raw_lang = getattr(mod, lang_func)()
            # tree-sitter >=0.25 returns PyCapsule; wrap with Language()
            if not isinstance(raw_lang, tree_sitter.Language):
                raw_lang = tree_sitter.Language(raw_lang)
            _TS_LOADED[language] = raw_lang
        except (ImportError, AttributeError, TypeError):
            _TS_LOADED[language] = None

    lang_obj = _TS_LOADED.get(language)
    if lang_obj is None:
        return None

    parser = tree_sitter.Parser(lang_obj)
    return parser


def _extract_symbol_name(node, source_bytes: bytes) -> str | None:
    """Extract the name of a function/class from its AST node."""
    for child in node.children:
        if child.type in ("identifier", "name", "property_identifier"):
            return source_bytes[child.start_byte:child.end_byte].decode("utf-8", errors="replace")
        # For decorated definitions, look deeper
        if child.type in ("function_definition", "class_definition"):
            return _extract_symbol_name(child, source_bytes)
    return None


def _chunk_with_treesitter(file_path: str, content: str, language: str) -> list[Chunk]:
    """Extract function/class-level chunks using tree-sitter."""
    parser = _get_ts_parser(language)
    if parser is None:
        return []

    config = TS_CONFIG[language]
    target_types = set(config["node_types"])

    source_bytes = content.encode("utf-8")
    tree = parser.parse(source_bytes)

    chunks = []
    lines = content.split("\n")

    def visit(node):
        if node.type in target_types:
            start_line = node.start_point[0]
            end_line = node.end_point[0]
            chunk_content = "\n".join(lines[start_line:end_line + 1])

            # Skip tiny chunks (< 2 lines)
            if end_line - start_line < 2:
                return

            symbol_name = _extract_symbol_name(node, source_bytes)
            symbol_type = node.type

            chunks.append(Chunk(
                file_path=file_path,
                content=chunk_content,
                language=language,
                symbol_name=symbol_name,
                symbol_type=symbol_type,
                line_start=start_line + 1,
                line_end=end_line + 1,
            ))
        else:
            for child in node.children:
                visit(child)

    visit(tree.root_node)
    return chunks


def _chunk_sliding_window(file_path: str, content: str, language: str) -> list[Chunk]:
    """Fallback: sliding window chunking at paragraph/section boundaries."""
    window_chars = WINDOW_TOKENS * APPROX_CHARS_PER_TOKEN
    overlap_chars = OVERLAP_TOKENS * APPROX_CHARS_PER_TOKEN

    if len(content) <= window_chars:
        return [Chunk(
            file_path=file_path,
            content=content,
            language=language,
            line_start=1,
            line_end=content.count("\n") + 1,
        )]

    chunks = []
    pos = 0
    while pos < len(content):
        end = min(pos + window_chars, len(content))

        # Try to break at a newline
        if end < len(content):
            newline_pos = content.rfind("\n", pos + window_chars // 2, end)
            if newline_pos > pos:
                end = newline_pos + 1

        chunk_text = content[pos:end]
        line_start = content[:pos].count("\n") + 1
        line_end = line_start + chunk_text.count("\n")

        chunks.append(Chunk(
            file_path=file_path,
            content=chunk_text,
            language=language,
            line_start=line_start,
            line_end=line_end,
        ))

        if end >= len(content):
            break

        pos = end - overlap_chars

    return chunks


def chunk_file(file_path: str, content: str) -> list[Chunk]:
    """Chunk a single file using AST parsing or sliding window fallback."""
    ext = os.path.splitext(file_path)[1].lower()
    language = LANG_MAP.get(ext, "unknown")

    # Try tree-sitter first for supported languages
    if language in TS_CONFIG:
        chunks = _chunk_with_treesitter(file_path, content, language)
        if chunks:
            return chunks

    # Fallback to sliding window
    return _chunk_sliding_window(file_path, content, language)


def discover_files(repo_root: str, extensions: set[str] | None = None) -> list[str]:
    """Walk repo and return list of indexable file paths (relative to repo_root)."""
    files = []
    for dirpath, dirnames, filenames in os.walk(repo_root):
        # Prune skipped directories in-place
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]

        for fname in filenames:
            if fname in SKIP_FILES:
                continue
            if fname.startswith("."):
                continue

            ext = os.path.splitext(fname)[1].lower()
            if extensions and ext not in extensions:
                continue
            if ext not in LANG_MAP:
                continue

            full_path = os.path.join(dirpath, fname)

            # Skip large files
            try:
                if os.path.getsize(full_path) > MAX_FILE_SIZE:
                    continue
            except OSError:
                continue

            rel_path = os.path.relpath(full_path, repo_root)
            files.append(rel_path)

    return sorted(files)


def chunk_repo(repo_root: str, extensions: set[str] | None = None) -> list[Chunk]:
    """Chunk an entire repository into indexable chunks."""
    files = discover_files(repo_root, extensions)
    all_chunks = []

    for rel_path in files:
        full_path = os.path.join(repo_root, rel_path)
        try:
            with open(full_path, encoding="utf-8", errors="replace") as f:
                content = f.read()
        except (OSError, UnicodeDecodeError):
            continue

        if not content.strip():
            continue

        chunks = chunk_file(rel_path, content)
        all_chunks.extend(chunks)

    return all_chunks
