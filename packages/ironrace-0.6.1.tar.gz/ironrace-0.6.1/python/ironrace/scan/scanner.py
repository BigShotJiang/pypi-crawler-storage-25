#!/usr/bin/env python3
"""IronRace Codebase Context Engine for Claude Code.

Scans a repo into function-level chunks, embeds locally using
sentence-transformers, builds an ironrace VectorIndex, and returns
semantically relevant code for a given query within a token budget.

Usage:
    python3 ironrace_scan.py --repo /path/to/repo --query "auth middleware" --budget 8000
    python3 ironrace_scan.py --repo /path/to/repo --overview-only --budget 3000
    python3 ironrace_scan.py --repos /path/repo1,/path/repo2 --query "shared auth"
"""

from __future__ import annotations

import argparse
import os
import sys
import time
from collections import Counter
from datetime import datetime
from pathlib import Path

import numpy as np

from .cache import (
    CacheManifest,
    get_stale_files,
    incremental_update,
    load_chunks,
    load_embeddings,
    load_manifest,
    save_chunks,
    save_embeddings,
    save_manifest,
)
from .chunker import LANG_MAP, Chunk, chunk_file, chunk_repo, discover_files

# Lazy-loaded globals
_embedder = None
_ironrace_available = None


def _get_embedder():
    """Lazy-load sentence-transformers model. Prefers ONNX backend for faster inference."""
    global _embedder
    if _embedder is None:
        from sentence_transformers import SentenceTransformer
        try:
            _embedder = SentenceTransformer("all-MiniLM-L6-v2", backend="onnx")
            print("IronRace: using ONNX backend", file=sys.stderr)
        except Exception:
            _embedder = SentenceTransformer("all-MiniLM-L6-v2")
            print("IronRace: using PyTorch backend (ONNX unavailable)", file=sys.stderr)
    return _embedder


def _check_ironrace():
    """Check if ironrace is available."""
    global _ironrace_available
    if _ironrace_available is None:
        try:
            import ironrace  # noqa: F401
            _ironrace_available = True
        except ImportError:
            _ironrace_available = False
    return _ironrace_available


def embed_texts(texts: list[str]) -> np.ndarray:
    """Embed a list of texts using sentence-transformers."""
    model = _get_embedder()
    embeddings = model.encode(texts, show_progress_bar=False, convert_to_numpy=True)
    return embeddings.astype(np.float32)


def chunk_to_embed_text(chunk: Chunk) -> str:
    """Create the text to embed for a chunk (includes metadata for context)."""
    parts = [chunk.file_path]
    if chunk.symbol_name:
        parts.append(f"{chunk.symbol_type}: {chunk.symbol_name}")
    parts.append(chunk.content[:2000])  # Cap content for embedding
    return "\n".join(parts)


def chunk_to_meta(chunk: Chunk) -> dict:
    """Convert a Chunk to serializable metadata dict."""
    return {
        "file_path": chunk.file_path,
        "content": chunk.content,
        "language": chunk.language,
        "symbol_name": chunk.symbol_name,
        "symbol_type": chunk.symbol_type,
        "line_start": chunk.line_start,
        "line_end": chunk.line_end,
    }


def build_index(embeddings: np.ndarray):
    """Build ironrace VectorIndex or fall back to numpy cosine similarity."""
    if _check_ironrace():
        from ironrace import VectorIndex
        vectors = [emb.tolist() for emb in embeddings]
        return VectorIndex(vectors)
    return None


def numpy_search(query_emb: np.ndarray, embeddings: np.ndarray, top_k: int) -> list[tuple[int, float]]:
    """Fallback: cosine similarity search using numpy."""
    # Normalize
    query_norm = query_emb / (np.linalg.norm(query_emb) + 1e-8)
    emb_norms = embeddings / (np.linalg.norm(embeddings, axis=1, keepdims=True) + 1e-8)
    scores = emb_norms @ query_norm
    top_indices = np.argsort(scores)[::-1][:top_k]
    return [(int(idx), float(scores[idx])) for idx in top_indices]


def search_index(index, query_embedding: np.ndarray, embeddings: np.ndarray, top_k: int) -> list[tuple[int, float]]:
    """Search the vector index, falling back to numpy if ironrace unavailable."""
    if index is not None:
        return index.search(query_embedding.tolist(), top_k=top_k)
    return numpy_search(query_embedding, embeddings, top_k)


def assemble_output(
    results: list[tuple[int, float]],
    chunks: list[dict],
    budget: int,
    query: str | None,
    repo_name: str,
    stats: dict,
) -> str:
    """Assemble the final output with token budgeting."""
    lines = []

    # Header
    lines.append(f"## Repository: {repo_name} ({stats['file_count']} files, {stats['lang_count']} languages)")

    cache_status = "hit" if stats.get("cache_hit") else "miss (full scan)"
    rebuild_time = f"{stats.get('rebuild_time', 0):.1f}s"
    stale_count = stats.get("stale_count", 0)
    lines.append(f"## Index: {stats['chunk_count']} chunks | Cache: {cache_status} ({rebuild_time}) | {stale_count} files re-indexed")

    if query:
        lines.append(f'## Query: "{query}"')

    lines.append("")

    # Results
    approx_chars_per_token = 4
    used_chars = sum(len(line) for line in lines)
    budget_chars = budget * approx_chars_per_token

    result_count = 0
    for idx, score in results:
        if idx >= len(chunks):
            continue

        chunk = chunks[idx]
        content = chunk["content"]

        # Build result block
        symbol_info = ""
        if chunk.get("symbol_name"):
            symbol_info = f":{chunk['symbol_name']}"

        header = f"### [{result_count + 1}] {chunk['file_path']}{symbol_info} (score: {score:.2f})"
        lang = chunk.get("language", "")
        block = f"{header}\n```{lang}\n{content}\n```\n"

        # Check budget
        if used_chars + len(block) > budget_chars:
            remaining = budget_chars - used_chars
            if remaining > 200:
                # Truncate this block to fit
                truncated_content = content[:remaining - len(header) - 20]
                last_newline = truncated_content.rfind("\n")
                if last_newline > 0:
                    truncated_content = truncated_content[:last_newline]
                block = f"{header}\n```{lang}\n{truncated_content}\n... (truncated)\n```\n"
                lines.append(block)
                result_count += 1
            break

        lines.append(block)
        used_chars += len(block)
        result_count += 1

    # Insert result count into header
    total_tokens = used_chars // approx_chars_per_token
    if query:
        lines.insert(3, f"## Results: {result_count} chunks, ~{total_tokens} tokens (budget: {budget})\n")

    return "\n".join(lines)


def generate_overview(repo_root: str, chunks: list[dict], budget: int) -> str:
    """Generate a structural overview of the repo."""
    repo_name = os.path.basename(os.path.abspath(repo_root))
    files = discover_files(repo_root)

    # Language breakdown
    lang_counts = Counter()
    for f in files:
        ext = os.path.splitext(f)[1].lower()
        lang = LANG_MAP.get(ext, "other")
        lang_counts[lang] += 1

    # Directory structure (top 3 levels)
    dirs = set()
    for f in files:
        parts = Path(f).parts
        for depth in range(1, min(4, len(parts))):
            dirs.add("/".join(parts[:depth]))

    # Entry points
    entry_points = []
    entry_names = {"main.py", "app.py", "index.ts", "index.js", "main.rs", "lib.rs", "main.go"}
    for f in files:
        if os.path.basename(f) in entry_names:
            entry_points.append(f)

    # Key patterns
    patterns = {
        "API routes": [],
        "Models": [],
        "Tests": [],
        "Config": [],
    }
    for chunk in chunks:
        fp = chunk["file_path"]
        sym = chunk.get("symbol_name", "")
        if "router" in fp or "routes" in fp or "api" in fp:
            if sym:
                patterns["API routes"].append(f"{fp}:{sym}")
        elif "model" in fp:
            if sym and chunk.get("symbol_type", "").endswith("definition"):
                patterns["Models"].append(f"{fp}:{sym}")
        elif "test" in fp:
            patterns["Tests"].append(fp)
        elif "config" in fp or "settings" in fp:
            patterns["Config"].append(fp)

    lines = [
        f"## Repository: {repo_name}",
        f"## Files: {len(files)} | Chunks: {len(chunks)} | Languages: {len(lang_counts)}",
        "",
        "### Language Breakdown",
    ]
    for lang, count in lang_counts.most_common():
        lines.append(f"- {lang}: {count} files")

    lines.extend(["", "### Directory Structure"])
    for d in sorted(dirs):
        depth = d.count("/")
        indent = "  " * depth
        lines.append(f"{indent}- {d.split('/')[-1]}/")

    if entry_points:
        lines.extend(["", "### Entry Points"])
        for ep in entry_points:
            lines.append(f"- {ep}")

    for category, items in patterns.items():
        if items:
            lines.extend(["", f"### {category}"])
            for item in items[:15]:  # Cap at 15 per category
                lines.append(f"- {item}")
            if len(items) > 15:
                lines.append(f"- ... and {len(items) - 15} more")

    return "\n".join(lines)


def scan_repo(
    repo_root: str,
    query: str | None = None,
    budget: int = 8000,
    top_k: int = 15,
    overview_only: bool = False,
    extensions: set[str] | None = None,
) -> str:
    """Main entry point: scan a repo and return context."""
    repo_root = os.path.abspath(repo_root)
    repo_name = os.path.basename(repo_root)
    start = time.monotonic()

    stats = {
        "cache_hit": False,
        "stale_count": 0,
        "rebuild_time": 0,
        "file_count": 0,
        "lang_count": 0,
        "chunk_count": 0,
    }

    # Discover current files
    current_files = discover_files(repo_root, extensions)
    stats["file_count"] = len(current_files)

    lang_set = set()
    for f in current_files:
        ext = os.path.splitext(f)[1].lower()
        lang_set.add(LANG_MAP.get(ext, "other"))
    stats["lang_count"] = len(lang_set)

    # Try loading cache
    manifest = load_manifest(repo_root)
    cached_embeddings = load_embeddings(repo_root) if manifest else None
    cached_chunks = load_chunks(repo_root) if manifest else None

    if manifest and cached_embeddings is not None and cached_chunks is not None:
        # Determine stale files
        stale = get_stale_files(repo_root, manifest, current_files)
        stats["stale_count"] = len(stale)

        if not stale:
            # Cache is fully fresh
            stats["cache_hit"] = True
            embeddings = cached_embeddings
            chunk_metas = cached_chunks
        else:
            # Incremental update
            stats["cache_hit"] = True  # partial hit

            # Re-chunk and re-embed stale files
            new_chunks_by_file = {}
            new_embed_texts_by_file = {}
            for rel_path in stale:
                full_path = os.path.join(repo_root, rel_path)
                if not os.path.exists(full_path):
                    continue
                try:
                    with open(full_path, encoding="utf-8", errors="replace") as f:
                        content = f.read()
                except OSError:
                    continue
                if not content.strip():
                    continue

                file_chunks = chunk_file(rel_path, content)
                new_chunks_by_file[rel_path] = [chunk_to_meta(c) for c in file_chunks]
                new_embed_texts_by_file[rel_path] = [chunk_to_embed_text(c) for c in file_chunks]

            # Embed new chunks
            new_embeddings_by_file = {}
            for rel_path, texts in new_embed_texts_by_file.items():
                if texts:
                    new_embeddings_by_file[rel_path] = embed_texts(texts)

            embeddings, chunk_metas, updated_files = incremental_update(
                repo_root, manifest, cached_embeddings, cached_chunks,
                stale, new_chunks_by_file, new_embeddings_by_file,
            )

            # Save updated cache
            import subprocess
            head_sha_result = subprocess.run(
                ["git", "rev-parse", "HEAD"], cwd=repo_root,
                capture_output=True, text=True, timeout=5,
            )
            head_sha = head_sha_result.stdout.strip() if head_sha_result.returncode == 0 else ""

            new_manifest = CacheManifest(
                repo_root=repo_root,
                head_sha=head_sha,
                indexed_at=datetime.now(datetime.UTC).isoformat(),
                embedding_dim=embeddings.shape[1] if len(embeddings) > 0 else 384,
                total_chunks=len(chunk_metas),
                files=updated_files,
            )
            save_manifest(new_manifest)
            save_embeddings(repo_root, embeddings)
            save_chunks(repo_root, chunk_metas)
    else:
        # Full scan from scratch
        print("Building index from scratch...", file=sys.stderr)
        all_chunks = chunk_repo(repo_root, extensions)
        chunk_metas = [chunk_to_meta(c) for c in all_chunks]

        if not chunk_metas:
            return f"## Repository: {repo_name}\n## No indexable files found.\n"

        # Embed all chunks
        embed_texts_list = [chunk_to_embed_text(c) for c in all_chunks]
        embeddings = embed_texts(embed_texts_list)

        # Save cache
        import subprocess
        head_sha_result = subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=repo_root,
            capture_output=True, text=True, timeout=5,
        )
        head_sha = head_sha_result.stdout.strip() if head_sha_result.returncode == 0 else ""

        # Build files dict
        files_dict = {}
        file_chunk_groups: dict[str, list[int]] = {}
        for i, meta in enumerate(chunk_metas):
            fp = meta["file_path"]
            if fp not in file_chunk_groups:
                file_chunk_groups[fp] = []
            file_chunk_groups[fp].append(i)

        for fp, indices in file_chunk_groups.items():
            full_path = os.path.join(repo_root, fp)
            try:
                mtime = os.path.getmtime(full_path)
            except OSError:
                mtime = 0
            files_dict[fp] = {"mtime": mtime, "chunk_indices": indices}

        new_manifest = CacheManifest(
            repo_root=repo_root,
            head_sha=head_sha,
            indexed_at=datetime.now(datetime.UTC).isoformat(),
            embedding_dim=int(embeddings.shape[1]),
            total_chunks=len(chunk_metas),
            files=files_dict,
        )
        save_manifest(new_manifest)
        save_embeddings(repo_root, embeddings)
        save_chunks(repo_root, chunk_metas)
        stats["stale_count"] = len(current_files)

    stats["chunk_count"] = len(chunk_metas)
    stats["rebuild_time"] = time.monotonic() - start

    # Overview mode
    if overview_only or query is None:
        return generate_overview(repo_root, chunk_metas, budget)

    # Query mode: build index and search
    if len(embeddings) == 0:
        return f"## Repository: {repo_name}\n## No chunks to search.\n"

    index = build_index(embeddings)
    query_embedding = embed_texts([query])[0]
    results = search_index(index, query_embedding, embeddings, top_k)

    return assemble_output(results, chunk_metas, budget, query, repo_name, stats)


def scan_multi_repo(
    repo_paths: list[str],
    query: str,
    budget: int = 8000,
    top_k: int = 15,
) -> str:
    """Search across multiple repos and merge results."""
    all_results = []  # (score, chunk_meta, repo_name)

    for repo_path in repo_paths:
        repo_path = os.path.abspath(repo_path)
        repo_name = os.path.basename(repo_path)

        cached_embeddings = load_embeddings(repo_path)
        cached_chunks = load_chunks(repo_path)

        if cached_embeddings is None or cached_chunks is None:
            # Need full scan
            scan_repo(repo_path, query=None)  # Build cache
            cached_embeddings = load_embeddings(repo_path)
            cached_chunks = load_chunks(repo_path)

        if cached_embeddings is None or not cached_chunks:
            continue

        index = build_index(cached_embeddings)
        query_embedding = embed_texts([query])[0]
        results = search_index(index, query_embedding, cached_embeddings, top_k)

        for idx, score in results:
            if idx < len(cached_chunks):
                chunk = dict(cached_chunks[idx])
                chunk["file_path"] = f"[{repo_name}] {chunk['file_path']}"
                all_results.append((score, chunk))

    # Sort by score, take top_k
    all_results.sort(key=lambda x: x[0], reverse=True)
    top_results = all_results[:top_k]

    # Build output
    lines = [
        f"## Multi-Repo Search: {len(repo_paths)} repositories",
        f'## Query: "{query}"',
        f"## Results: {len(top_results)} chunks (budget: {budget})",
        "",
    ]

    approx_chars_per_token = 4
    used_chars = sum(len(line) for line in lines)
    budget_chars = budget * approx_chars_per_token

    for i, (score, chunk) in enumerate(top_results):
        symbol_info = f":{chunk.get('symbol_name', '')}" if chunk.get("symbol_name") else ""
        header = f"### [{i + 1}] {chunk['file_path']}{symbol_info} (score: {score:.2f})"
        lang = chunk.get("language", "")
        block = f"{header}\n```{lang}\n{chunk['content']}\n```\n"

        if used_chars + len(block) > budget_chars:
            break

        lines.append(block)
        used_chars += len(block)

    return "\n".join(lines)


def search_with_file_context(
    repo_root: str,
    query: str,
    budget: int = 12000,
    top_k: int = 8,
    max_lines_per_file: int = 500,
    extensions: set[str] | None = None,
) -> str:
    """Semantic search returning FULL FILE contents, not just function snippets.

    Groups chunk matches by file, ranks files by best match score,
    and returns full file contents with matched functions annotated.
    Agents get imports, class hierarchy, and surrounding code in one call.
    """
    repo_root = os.path.abspath(repo_root)
    repo_name = os.path.basename(repo_root)

    # Run normal scan to get index + chunks
    manifest = load_manifest(repo_root)
    cached_embeddings = load_embeddings(repo_root) if manifest else None
    cached_chunks = load_chunks(repo_root) if manifest else None

    if cached_embeddings is None or cached_chunks is None:
        # Build cache first
        scan_repo(repo_root, query=None, overview_only=True, extensions=extensions)
        cached_embeddings = load_embeddings(repo_root)
        cached_chunks = load_chunks(repo_root)
        if cached_embeddings is None or not cached_chunks:
            return f"## Repository: {repo_name}\n## No indexable files found.\n"

    # Search
    index = build_index(cached_embeddings)
    query_embedding = embed_texts([query])[0]
    results = search_index(index, query_embedding, cached_embeddings, top_k)

    # Group matches by file, track best score and matched symbols per file
    file_matches: dict[str, list[tuple[float, str | None]]] = {}
    for idx, score in results:
        if idx >= len(cached_chunks):
            continue
        chunk = cached_chunks[idx]
        fp = chunk["file_path"]
        sym = chunk.get("symbol_name")
        if fp not in file_matches:
            file_matches[fp] = []
        file_matches[fp].append((score, sym))

    # Rank files by best chunk score
    ranked_files = sorted(
        file_matches.items(),
        key=lambda x: max(s for s, _ in x[1]),
        reverse=True,
    )

    # Build output with full file contents
    lines = [
        f"## Repository: {repo_name}",
        f'## Query: "{query}" (file-context mode)',
        f"## Files: {len(ranked_files)} matched",
        "",
    ]

    approx_chars_per_token = 4
    used_chars = sum(len(line) for line in lines)
    budget_chars = budget * approx_chars_per_token
    files_included = 0

    for file_path, matches in ranked_files:
        full_path = os.path.join(repo_root, file_path)
        if not os.path.exists(full_path):
            continue

        try:
            with open(full_path, encoding="utf-8", errors="replace") as f:
                file_content = f.read()
        except OSError:
            continue

        file_lines = file_content.split("\n")
        best_score = max(s for s, _ in matches)
        match_symbols = [f"{sym}@{s:.2f}" for s, sym in matches if sym]
        match_info = ", ".join(match_symbols) if match_symbols else f"score: {best_score:.2f}"

        # For large files, extract relevant sections
        if len(file_lines) > max_lines_per_file:
            # Always include imports (top of file until first non-import/non-comment)
            import_end = 0
            for i, line in enumerate(file_lines):
                stripped = line.strip()
                if stripped and not stripped.startswith(("#", "import ", "from ", "//", "/*", " *", "*/", "\"\"\"", "'''", "export ", "const ", "type ")):
                    if i > 5:  # Only break after we've seen some content
                        import_end = i
                        break
            import_end = max(import_end, 20)  # At least first 20 lines

            # Find lines around matched functions
            matched_ranges = []
            for _, sym in matches:
                if sym:
                    for i, line in enumerate(file_lines):
                        if sym in line and ("def " in line or "function " in line or "class " in line or "const " in line or "async " in line):
                            start = max(0, i - 5)
                            end = min(len(file_lines), i + 50)
                            matched_ranges.append((start, end))
                            break

            # Build truncated content: imports + matched sections
            included_lines = set(range(0, import_end))
            for start, end in matched_ranges:
                included_lines.update(range(start, end))

            numbered = []
            prev_i = -1
            for i in sorted(included_lines):
                if i >= len(file_lines):
                    continue
                if prev_i >= 0 and i > prev_i + 1:
                    numbered.append("    ...")
                numbered.append(f"{i + 1:4d}: {file_lines[i]}")
                prev_i = i

            content_block = "\n".join(numbered)
        else:
            # Include full file with line numbers
            content_block = "\n".join(
                f"{i + 1:4d}: {line}" for i, line in enumerate(file_lines)
            )

        # Detect language from extension
        ext = os.path.splitext(file_path)[1].lower()
        lang_map = {".py": "python", ".ts": "typescript", ".tsx": "tsx",
                    ".js": "javascript", ".rs": "rust", ".go": "go"}
        lang = lang_map.get(ext, "")

        header = f"### [{files_included + 1}] {file_path} ({len(matches)} match{'es' if len(matches) > 1 else ''}: {match_info})"
        block = f"{header}\n```{lang}\n{content_block}\n```\n"

        # Check budget
        if used_chars + len(block) > budget_chars:
            remaining = budget_chars - used_chars
            if remaining > 500 and files_included == 0:
                # Truncate to fit at least one file
                block = block[:remaining - 10] + "\n... (truncated)\n```\n"
                lines.append(block)
                files_included += 1
            break

        lines.append(block)
        used_chars += len(block)
        files_included += 1

    total_tokens = sum(len(line) for line in lines) // approx_chars_per_token
    lines.insert(3, f"## Showing {files_included} files, ~{total_tokens} tokens (budget: {budget})\n")

    return "\n".join(lines)


def batch_scan(
    repo_root: str,
    queries: list[str],
    budget: int = 6000,
    top_k: int = 12,
    include_overview: bool = True,
    output_dir: str | None = None,
    extensions: set[str] | None = None,
) -> str:
    """Run multiple queries in a single process (model loads once).

    Returns all results concatenated. Optionally writes individual results
    to output_dir for agent consumption.
    """
    repo_root = os.path.abspath(repo_root)
    all_output = []

    # First call builds/loads the index and warms the model
    if include_overview:
        overview = scan_repo(repo_root, query=None, budget=3000,
                             overview_only=True, extensions=extensions)
        all_output.append(overview)
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
            with open(os.path.join(output_dir, "overview.txt"), "w") as f:
                f.write(overview)

    # Subsequent calls reuse cached index + warm model
    for i, query in enumerate(queries):
        result = scan_repo(repo_root, query=query, budget=budget,
                           top_k=top_k, extensions=extensions)
        all_output.append(f"\n{'='*60}\n")
        all_output.append(result)
        if output_dir:
            with open(os.path.join(output_dir, f"query_{i:02d}.txt"), "w") as f:
                f.write(result)

    combined = "\n".join(all_output)

    # Also write combined output to cache dir for agent access
    if output_dir:
        with open(os.path.join(output_dir, "combined.txt"), "w") as f:
            f.write(combined)
        print(f"Results written to {output_dir}/", file=sys.stderr)

    return combined


def main():
    parser = argparse.ArgumentParser(description="IronRace Codebase Context Engine")
    parser.add_argument("--repo", type=str, help="Path to repository root")
    parser.add_argument("--repos", type=str, help="Comma-separated paths for multi-repo search")
    parser.add_argument("--query", "-q", type=str, help="Semantic search query")
    parser.add_argument("--queries", type=str,
                        help="Multiple queries separated by '|' — runs all in one process (model loads once)")
    parser.add_argument("--budget", type=int, default=8000, help="Token budget for output")
    parser.add_argument("--top-k", type=int, default=15, help="Number of results to return")
    parser.add_argument("--overview-only", action="store_true", help="Return repo overview instead of search")
    parser.add_argument("--extensions", type=str, help="Comma-separated file extensions to include (e.g., .py,.ts)")
    parser.add_argument("--output-dir", type=str,
                        help="Write results to this directory (default: .claude/ironrace/results/ in repo)")

    args = parser.parse_args()

    extensions = None
    if args.extensions:
        extensions = {ext.strip() if ext.startswith(".") else f".{ext.strip()}" for ext in args.extensions.split(",")}

    if args.repos:
        repo_paths = [p.strip() for p in args.repos.split(",")]
        if not args.query:
            print("Error: --query is required for multi-repo search", file=sys.stderr)
            sys.exit(1)
        output = scan_multi_repo(repo_paths, args.query, args.budget, args.top_k)
    elif args.queries:
        # Batch mode: multiple queries, single process
        repo = args.repo or os.getcwd()
        query_list = [q.strip() for q in args.queries.split("|") if q.strip()]
        output_dir = args.output_dir or os.path.join(
            os.path.abspath(repo), ".claude", "ironrace", "results"
        )
        output = batch_scan(
            repo, query_list,
            budget=args.budget, top_k=args.top_k,
            include_overview=True, output_dir=output_dir,
            extensions=extensions,
        )
    else:
        repo = args.repo or os.getcwd()
        output = scan_repo(
            repo,
            query=args.query,
            budget=args.budget,
            top_k=args.top_k,
            overview_only=args.overview_only,
            extensions=extensions,
        )

    print(output)


if __name__ == "__main__":
    main()
