"""Git-aware caching layer for ironrace scan embeddings.

Stores embeddings and chunk metadata in .claude/ironrace/ per repo.
Uses git state + file mtimes for incremental updates.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import tempfile
from dataclasses import dataclass

import numpy as np

CACHE_DIR_NAME = ".claude/ironrace"


FORMAT_VERSION = 1


@dataclass
class CacheManifest:
    repo_root: str
    head_sha: str
    indexed_at: str
    embedding_dim: int
    total_chunks: int
    files: dict  # {rel_path: {"mtime": float, "chunk_indices": [int, ...]}}
    format_version: int = 0


def _get_git_head(repo_root: str) -> str | None:
    """Get current HEAD SHA."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_root,
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.stdout.strip() if result.returncode == 0 else None
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return None


_SHA_HEX_RE = re.compile(r"[0-9a-f]{40}")


def _get_changed_files(repo_root: str, since_sha: str) -> set[str]:
    """Get files changed since a given commit SHA. Runs git commands in parallel."""
    # Validate SHA to prevent injection of arbitrary git refspecs
    if not _SHA_HEX_RE.fullmatch(since_sha):
        return set()

    from concurrent.futures import ThreadPoolExecutor, as_completed

    def _run_git(args: list[str]) -> set[str]:
        try:
            result = subprocess.run(
                args, cwd=repo_root,
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                return {f for f in result.stdout.strip().split("\n") if f}
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass
        return set()

    # Run both git commands in parallel
    # Combined diff covers both committed and uncommitted changes vs cached SHA
    with ThreadPoolExecutor(max_workers=2) as pool:
        future_diff = pool.submit(_run_git, ["git", "diff", "--name-only", since_sha])
        future_untracked = pool.submit(_run_git, ["git", "ls-files", "--others", "--exclude-standard"])

        changed = set()
        for fut in as_completed([future_diff, future_untracked]):
            changed.update(fut.result())

    return changed


def get_cache_dir(repo_root: str) -> str:
    return os.path.join(repo_root, CACHE_DIR_NAME)


def load_manifest(repo_root: str) -> CacheManifest | None:
    """Load cache manifest, migrating old caches that lack format_version.

    Old caches (pre-v0.6.0) have no format_version field. Instead of
    invalidating them and forcing a full rebuild, we migrate in-place.
    """
    cache_dir = get_cache_dir(repo_root)
    manifest_path = os.path.join(cache_dir, "manifest.json")

    if not os.path.exists(manifest_path):
        return None

    try:
        with open(manifest_path) as f:
            data = json.load(f)
        manifest = CacheManifest(**data)
    except (json.JSONDecodeError, KeyError, TypeError):
        return None

    if manifest.format_version == 0:
        # Legacy cache — migrate in-place
        manifest.format_version = FORMAT_VERSION
        try:
            save_manifest(manifest)
        except OSError:
            pass  # non-fatal: will retry next load
    elif manifest.format_version != FORMAT_VERSION:
        # Genuinely incompatible future format
        return None

    return manifest


def _atomic_write(target_path: str, data: bytes) -> None:
    """Write data to a file atomically via tmp-then-rename."""
    target_dir = os.path.dirname(target_path)
    fd, tmp_path = tempfile.mkstemp(dir=target_dir, suffix=".tmp")
    closed = False
    try:
        os.write(fd, data)
        os.close(fd)
        closed = True
        os.chmod(tmp_path, 0o600)
        os.replace(tmp_path, target_path)
    except BaseException:
        if not closed:
            os.close(fd)
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)
        raise


def save_manifest(manifest: CacheManifest) -> None:
    """Save cache manifest atomically."""
    cache_dir = get_cache_dir(manifest.repo_root)
    os.makedirs(cache_dir, exist_ok=True)

    manifest_path = os.path.join(cache_dir, "manifest.json")
    data = json.dumps({
        "repo_root": manifest.repo_root,
        "head_sha": manifest.head_sha,
        "indexed_at": manifest.indexed_at,
        "embedding_dim": manifest.embedding_dim,
        "total_chunks": manifest.total_chunks,
        "files": manifest.files,
    }, indent=2).encode()
    _atomic_write(manifest_path, data)


def load_embeddings(repo_root: str) -> np.ndarray | None:
    """Load cached embeddings array."""
    cache_dir = get_cache_dir(repo_root)
    emb_path = os.path.join(cache_dir, "embeddings.npz")

    if not os.path.exists(emb_path):
        return None

    try:
        data = np.load(emb_path)
        return data["embeddings"]
    except (ValueError, KeyError):
        return None


def save_embeddings(repo_root: str, embeddings: np.ndarray) -> None:
    """Save embeddings array atomically."""
    cache_dir = get_cache_dir(repo_root)
    os.makedirs(cache_dir, exist_ok=True)

    emb_path = os.path.join(cache_dir, "embeddings.npz")
    fd, tmp_path = tempfile.mkstemp(dir=cache_dir, suffix=".tmp")
    try:
        os.close(fd)
        np.savez_compressed(tmp_path, embeddings=embeddings)
        os.chmod(tmp_path, 0o600)
        os.replace(tmp_path, emb_path)
    except BaseException:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)
        raise


def load_chunks(repo_root: str) -> list[dict] | None:
    """Load cached chunk metadata."""
    cache_dir = get_cache_dir(repo_root)
    chunks_path = os.path.join(cache_dir, "chunks.jsonl")

    if not os.path.exists(chunks_path):
        return None

    try:
        chunks = []
        with open(chunks_path) as f:
            for line in f:
                line = line.strip()
                if line:
                    chunks.append(json.loads(line))
        return chunks
    except (json.JSONDecodeError, OSError):
        return None


def save_chunks(repo_root: str, chunks: list[dict]) -> None:
    """Save chunk metadata as JSONL atomically."""
    cache_dir = get_cache_dir(repo_root)
    os.makedirs(cache_dir, exist_ok=True)

    chunks_path = os.path.join(cache_dir, "chunks.jsonl")
    lines = [json.dumps(chunk) + "\n" for chunk in chunks]
    _atomic_write(chunks_path, "".join(lines).encode())


def get_stale_files(repo_root: str, manifest: CacheManifest, current_files: list[str]) -> set[str]:
    """Determine which files need re-indexing."""
    stale = set()

    # Git-based changes — short-circuit if HEAD matches
    if manifest.head_sha:
        current_head = _get_git_head(repo_root)
        if current_head and current_head == manifest.head_sha:
            # HEAD unchanged — only check mtimes (skip expensive git diff)
            pass
        elif current_head:
            git_changed = _get_changed_files(repo_root, manifest.head_sha)
            stale.update(git_changed)

    # mtime-based changes for files in the manifest
    for rel_path in current_files:
        full_path = os.path.join(repo_root, rel_path)
        try:
            current_mtime = os.path.getmtime(full_path)
        except OSError:
            continue

        cached_info = manifest.files.get(rel_path)
        if cached_info is None:
            # New file not in cache
            stale.add(rel_path)
        elif current_mtime > cached_info.get("mtime", 0):
            stale.add(rel_path)

    # Deleted files (in manifest but not in current_files)
    current_set = set(current_files)
    for cached_path in manifest.files:
        if cached_path not in current_set:
            stale.add(cached_path)

    return stale


def incremental_update(
    repo_root: str,
    manifest: CacheManifest,
    cached_embeddings: np.ndarray,
    cached_chunks: list[dict],
    stale_files: set[str],
    new_chunks_by_file: dict[str, list],
    new_embeddings_by_file: dict[str, np.ndarray],
) -> tuple[np.ndarray, list[dict], dict]:
    """Apply incremental updates to cached data.

    Returns (updated_embeddings, updated_chunks, updated_files_dict).
    """
    # Build index of chunks to keep (not in stale files)
    keep_indices = []
    kept_chunks = []
    for i, chunk_meta in enumerate(cached_chunks):
        if chunk_meta["file_path"] not in stale_files:
            keep_indices.append(i)
            kept_chunks.append(chunk_meta)

    # Keep embeddings for non-stale chunks
    if keep_indices:
        kept_embeddings = cached_embeddings[keep_indices]
    else:
        kept_embeddings = np.empty((0, cached_embeddings.shape[1]), dtype=np.float32)

    # Append new chunks and embeddings
    all_new_chunks = []
    all_new_embeddings = []
    for file_path in sorted(new_chunks_by_file.keys()):
        file_chunks = new_chunks_by_file[file_path]
        file_embeddings = new_embeddings_by_file[file_path]
        all_new_chunks.extend(file_chunks)
        all_new_embeddings.append(file_embeddings)

    if all_new_embeddings:
        new_emb_array = np.vstack(all_new_embeddings)
        updated_embeddings = np.vstack([kept_embeddings, new_emb_array]) if len(kept_embeddings) > 0 else new_emb_array
    else:
        updated_embeddings = kept_embeddings

    updated_chunks = kept_chunks + all_new_chunks

    # Build updated files dict
    # Start with non-stale files from manifest
    updated_files = {}
    for rel_path, info in manifest.files.items():
        if rel_path not in stale_files:
            updated_files[rel_path] = info

    # Add new files with their chunk indices
    chunk_offset = len(kept_chunks)
    for file_path in sorted(new_chunks_by_file.keys()):
        n_chunks = len(new_chunks_by_file[file_path])
        full_path = os.path.join(repo_root, file_path)
        try:
            mtime = os.path.getmtime(full_path)
        except OSError:
            mtime = 0
        updated_files[file_path] = {
            "mtime": mtime,
            "chunk_indices": list(range(chunk_offset, chunk_offset + n_chunks)),
        }
        chunk_offset += n_chunks

    return updated_embeddings, updated_chunks, updated_files


def is_indexed(repo_root: str) -> bool:
    """Check whether a valid, non-stale scan cache exists for the repo."""
    manifest = load_manifest(repo_root)
    if manifest is None:
        return False
    current_head = _get_git_head(repo_root)
    if current_head and current_head != manifest.head_sha:
        return False
    return True


def ensure_indexed(repo_root: str, background: bool = True) -> bool:
    """Ensure the repo has a scan cache, triggering indexing if needed.

    Returns True if the index is ready, False if indexing was started
    in the background (or skipped because the binary is missing).
    """
    if is_indexed(repo_root):
        return True

    import shutil
    import threading

    binary = os.path.expanduser("~/.ironrace/bin/ironrace")
    if not os.path.isfile(binary):
        binary = shutil.which("ironrace")
    if not binary:
        return False

    cmd = [binary, "scan", "--repo", repo_root, "--overview-only"]

    if background:
        def _run() -> None:
            try:
                subprocess.run(cmd, capture_output=True, timeout=300)
            except (subprocess.TimeoutExpired, OSError):
                pass
        threading.Thread(target=_run, daemon=True).start()
        return False

    try:
        subprocess.run(cmd, capture_output=True, timeout=300, check=True)
        return True
    except (subprocess.TimeoutExpired, subprocess.CalledProcessError, OSError):
        return False
