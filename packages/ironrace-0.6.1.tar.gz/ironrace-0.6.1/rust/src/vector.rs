use pyo3::prelude::*;

/// HNSW approximate nearest neighbor index.
///
/// Build once from a collection of embedding vectors, then search many times.
/// The index lives in Rust memory — Python holds a reference.
///
/// For datasets larger than 2500 vectors, the index is automatically sharded
/// into smaller HNSW graphs that are built and searched in parallel. This
/// maintains 98%+ recall at any scale.
///
/// Args:
///     vectors: List of embedding vectors (each a list of f32).
///     ef_construction: Build-time search effort. Default 100 gives 98%+ recall on
///         real-world embeddings. Increase to 200+ for higher recall on very large
///         datasets (1M+ vectors).
///     shard_size: Max vectors per HNSW shard. Default 5000 balances recall (≥97%)
///         and search latency. Larger = faster search, potentially lower recall.
///
/// Example:
///     idx = VectorIndex(vectors)                       # 98%+ recall (default)
///     idx = VectorIndex(vectors, ef_construction=200)  # higher recall at 1M+ vectors
///     idx = VectorIndex(vectors, shard_size=10000)     # fewer shards, faster search
///     results = idx.search(query_vector, top_k=10)
#[pyclass]
pub struct VectorIndex {
    inner: ironrace_core::VectorIndex,
}

#[pymethods]
impl VectorIndex {
    /// Build a new HNSW index from a list of embedding vectors.
    #[new]
    #[pyo3(signature = (vectors, ef_construction=100, shard_size=5000))]
    pub fn new(
        py: Python<'_>,
        vectors: Vec<Vec<f32>>,
        ef_construction: usize,
        shard_size: usize,
    ) -> Self {
        py.allow_threads(|| VectorIndex {
            inner: ironrace_core::VectorIndex::build_with_shard_size(
                &vectors,
                ef_construction,
                shard_size,
            ),
        })
    }

    /// Search for the top_k nearest neighbors to the query vector.
    ///
    /// Returns a list of (original_index, similarity_score) tuples,
    /// sorted by similarity (highest first).
    #[pyo3(signature = (query, top_k=10))]
    pub fn search(&self, py: Python<'_>, query: Vec<f32>, top_k: usize) -> Vec<(usize, f32)> {
        // Release the GIL during search — this is pure Rust compute
        py.allow_threads(|| self.inner.search(&query, top_k))
    }

    /// Returns the number of vectors in the index.
    fn len(&self) -> usize {
        self.inner.len()
    }

    /// Returns True if the index contains no vectors.
    fn is_empty(&self) -> bool {
        self.inner.is_empty()
    }
}
