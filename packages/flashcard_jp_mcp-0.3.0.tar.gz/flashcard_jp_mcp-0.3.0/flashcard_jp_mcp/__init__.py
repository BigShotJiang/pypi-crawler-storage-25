"""MCP server bridging Claude clients to a flashcard-jp deployment."""
__version__ = "0.3.0"
