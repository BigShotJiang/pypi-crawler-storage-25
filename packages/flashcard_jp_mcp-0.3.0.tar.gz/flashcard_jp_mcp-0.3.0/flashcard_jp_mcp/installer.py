"""One-shot installer that registers `flashcard-jp` in Claude Desktop's
config file.

Cross-platform — detects macOS / Windows / Linux and writes to the right
JSON path. Idempotent: running it twice is a no-op.

Entry point:
    uvx --from flashcard-jp-mcp flashcard-jp-mcp-install-desktop
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

SERVER_NAME = "flashcard-jp"
SERVER_CONFIG: dict[str, Any] = {
    "command": "uvx",
    "args": ["flashcard-jp-mcp"],
}

API_BASE_DEFAULT = "https://flashcard-jp-production.up.railway.app"


def _config_path() -> Path:
    """Resolve the OS-specific Claude Desktop config path."""
    home = Path.home()
    if sys.platform == "darwin":
        return home / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"
    if sys.platform.startswith("win"):
        appdata = os.environ.get("APPDATA")
        base = Path(appdata) if appdata else home / "AppData" / "Roaming"
        return base / "Claude" / "claude_desktop_config.json"
    # Linux / WSL — Claude Desktop isn't officially supported but use the
    # common XDG-style path so power users can still drop the entry.
    return home / ".config" / "Claude" / "claude_desktop_config.json"


def _load(p: Path) -> dict[str, Any]:
    if not p.exists():
        return {}
    try:
        text = p.read_text(encoding="utf-8").strip()
    except OSError as e:
        print(f"  ✗ Impossibile leggere {p}: {e}", file=sys.stderr)
        sys.exit(1)
    if not text:
        return {}
    try:
        return json.loads(text)
    except json.JSONDecodeError as e:
        print(
            f"  ✗ {p} non è JSON valido: {e}\n"
            "    Apri il file a mano e correggilo prima di rilanciare l'installer.",
            file=sys.stderr,
        )
        sys.exit(1)


def install_desktop() -> None:
    """Add (or refresh) the `flashcard-jp` MCP entry in Claude Desktop."""
    path = _config_path()
    print(f"Claude Desktop config: {path}")

    if not path.parent.exists():
        # On Linux, the directory often doesn't exist when Claude Desktop
        # isn't installed at all — warn but proceed (creating the dir).
        print(f"  ! La cartella {path.parent} non esiste; la creo.")
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            print(f"  ✗ Non posso creare la cartella: {e}", file=sys.stderr)
            sys.exit(1)

    cfg = _load(path)
    servers = cfg.setdefault("mcpServers", {})
    existing = servers.get(SERVER_NAME)

    if existing == SERVER_CONFIG:
        print(f"  ✓ '{SERVER_NAME}' già configurato — nulla da cambiare.")
    else:
        if existing:
            print(f"  ! '{SERVER_NAME}' aveva config diversa, la sostituisco:")
            print(f"      vecchia: {existing}")
        servers[SERVER_NAME] = dict(SERVER_CONFIG)
        path.write_text(
            json.dumps(cfg, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        print(f"  ✓ '{SERVER_NAME}' aggiunto a mcpServers.")

    print()
    print("Prossimi passi:")
    print("  1. Chiudi completamente Claude Desktop e riavvialo.")
    print("  2. Inizia una chat e prova: «elenca i miei mazzi flashcard-jp».")
    print("  3. Al primo tool call Claude ti chiederà il token API")
    print(f"     (mintalo dal tasto 🔑 su {API_BASE_DEFAULT}).")
    print()
    print("Per disinstallare: rimuovi la chiave 'flashcard-jp' da mcpServers in")
    print(f"  {path}")


if __name__ == "__main__":
    install_desktop()
