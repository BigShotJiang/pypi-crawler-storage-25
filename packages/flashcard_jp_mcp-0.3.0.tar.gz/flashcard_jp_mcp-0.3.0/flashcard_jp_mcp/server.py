"""MCP server that exposes flashcard-jp's REST API as tools.

Run as a stdio MCP server:
    flashcard-jp-mcp     # console script
    python -m flashcard_jp_mcp

Setup the API token interactively (one-shot, terminal-based):
    flashcard-jp-mcp-setup

Or simply add the server to Claude with no env var — the first tool call
will prompt you for the token via MCP `elicitation` (if your client
supports it; Claude Desktop and recent Claude Code do):

    claude mcp add flashcard-jp -- uvx flashcard-jp-mcp

Token resolution order:
    1. FLASHCARD_API_TOKEN env var (per-deploy override)
    2. ~/.config/flashcard-jp-mcp/config.json (saved by elicit/setup)
    3. MCP elicitation prompt to the chat user
    4. Friendly error pointing at the setup recipe
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Optional

import httpx
from mcp.server.fastmcp import FastMCP, Context

DEFAULT_API_BASE = "https://flashcard-jp-production.up.railway.app"
API_BASE = os.environ.get("FLASHCARD_API_BASE", DEFAULT_API_BASE).rstrip("/")
API_TOKEN_ENV = os.environ.get("FLASHCARD_API_TOKEN", "").strip()

CONFIG_DIR = Path.home() / ".config" / "flashcard-jp-mcp"
CONFIG_FILE = CONFIG_DIR / "config.json"

mcp = FastMCP("flashcard-jp")


# ---------------------------------------------------------------------------
# Token persistence + resolution
# ---------------------------------------------------------------------------

def _load_saved_config() -> dict[str, Any]:
    if not CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(CONFIG_FILE.read_text())
    except Exception:
        return {}


def _save_token(token: str, api_base: str) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps({"token": token, "api_base": api_base}, indent=2))
    try:
        CONFIG_FILE.chmod(0o600)
    except Exception:
        pass


def _setup_help_text() -> str:
    return (
        f"Apri {API_BASE} nel browser, fai login con Google, clicca 🔑 nel "
        "navbar in alto e crea un token (formato `fjp_...`). Poi:\n\n"
        "  • Imposta FLASHCARD_API_TOKEN come env var, oppure\n"
        "  • Esegui `uvx flashcard-jp-mcp-setup` in un terminale, oppure\n"
        f"  • Salva manualmente {{\"token\": \"fjp_...\"}} in {CONFIG_FILE}"
    )


async def _resolve_token(ctx: Optional[Context] = None) -> str:
    """Token in priority: env > saved file > MCP elicit > error."""
    if API_TOKEN_ENV:
        return API_TOKEN_ENV
    saved = _load_saved_config().get("token", "").strip()
    if saved.startswith("fjp_"):
        return saved
    if ctx is not None:
        try:
            res = await ctx.elicit(
                message=(
                    "flashcard-jp-mcp non ha ancora un token API.\n\n"
                    f"1. Apri {API_BASE} (login con Google)\n"
                    "2. Click sul tasto 🔑 in alto a destra\n"
                    "3. Crea un token (es. nome 'claude') e copialo\n"
                    "4. Incollalo qui sotto\n\n"
                    f"Verrà salvato in {CONFIG_FILE} (perm 600)."
                ),
                requested_schema={
                    "type": "object",
                    "properties": {
                        "token": {
                            "type": "string",
                            "description": "Il token che inizia con fjp_",
                        }
                    },
                    "required": ["token"],
                },
            )
            action = getattr(res, "action", None)
            if action == "accept":
                content = getattr(res, "content", None) or {}
                token = (content.get("token") or "").strip()
                if not token.startswith("fjp_"):
                    raise RuntimeError(
                        "Il token deve iniziare con `fjp_`. Riapri 🔑 nell'app web "
                        "e copia il valore intero."
                    )
                _save_token(token, API_BASE)
                return token
            if action in ("decline", "cancel"):
                raise RuntimeError("Setup annullato dall'utente.")
        except RuntimeError:
            raise
        except Exception:
            # Client doesn't support elicitation — fall through to the error.
            pass
    raise RuntimeError(
        "Nessun token API per flashcard-jp configurato. " + _setup_help_text()
    )


# ---------------------------------------------------------------------------
# HTTP client
# ---------------------------------------------------------------------------

def _client(token: str) -> httpx.Client:
    return httpx.Client(
        base_url=API_BASE,
        headers={
            "Authorization": f"Bearer {token}",
            "User-Agent": "flashcard-jp-mcp/0.2.0",
        },
        timeout=30.0,
    )


def _raise_for_status(r: httpx.Response) -> None:
    if r.is_success:
        return
    detail: Any
    try:
        body = r.json()
        detail = body.get("detail") if isinstance(body, dict) else body
    except Exception:
        detail = r.text[:300]
    if r.status_code == 401:
        # Likely a stale/revoked saved token — invalidate it so the next
        # tool call re-prompts via elicitation.
        if CONFIG_FILE.exists():
            try:
                CONFIG_FILE.unlink()
            except Exception:
                pass
        raise RuntimeError(
            "Token API rifiutato (401). " + _setup_help_text()
        )
    raise RuntimeError(f"flashcard-jp API {r.status_code}: {detail}")


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@mcp.tool()
async def whoami(ctx: Context) -> dict[str, Any]:
    """Return the authenticated user's email and the deck id of the last
    deck they studied (`last_deck_id`, may be null). Useful as a sanity
    check that the API token is wired up correctly."""
    token = await _resolve_token(ctx)
    with _client(token) as c:
        r = c.get("/api/auth/me")
        _raise_for_status(r)
        return r.json()


@mcp.tool()
async def list_decks(ctx: Context) -> list[dict[str, Any]]:
    """List every deck the user can see (private decks they own + shared
    starting decks). Each entry carries:
      - id, name, is_starting, is_owned
      - word_count: number of words in the deck
      - cards_total: word_count * 2 (forward + reverse cards)
      - cards_done: cards already learned or suspended for this user
      - cards_left: cards_total - cards_done (long-term remaining)
      - cards_available_today: cards the next study session would surface
      - completed: True if cards_left == 0
    """
    token = await _resolve_token(ctx)
    with _client(token) as c:
        r = c.get("/api/decks")
        _raise_for_status(r)
        return r.json()


@mcp.tool()
async def get_deck(ctx: Context, deck_id: int) -> dict[str, Any]:
    """Return a deck's metadata + its full word list. Useful for
    deduplicating before adding new cards: each word entry has `id`,
    `romajii`, `kana`, `italiano`, `mnemonic`, `emoji`."""
    token = await _resolve_token(ctx)
    with _client(token) as c:
        r = c.get(f"/api/decks/{deck_id}")
        _raise_for_status(r)
        return r.json()


@mcp.tool()
async def create_deck(ctx: Context, name: str) -> dict[str, Any]:
    """Create a new private deck owned by the current user. Starting decks
    cannot be created via the API — they're seeded server-side."""
    token = await _resolve_token(ctx)
    with _client(token) as c:
        r = c.post("/api/decks", json={"name": name})
        _raise_for_status(r)
        return r.json()


@mcp.tool()
async def add_card_to_deck(
    ctx: Context,
    deck_id: int,
    romajii: str,
    kana: str,
    italiano: str,
    mnemonic: Optional[str] = None,
    emoji: Optional[str] = None,
) -> dict[str, Any]:
    """Add a single Japanese word to a deck the user owns. Creates one
    Word + two Cards (forward JP→IT and reverse IT→JP) automatically.
    Fields:
      - romajii: Hepburn, lowercase, ASCII (e.g. "ohayoo", "tabemashita")
      - kana: hiragana or katakana reading (no kanji)
      - italiano: Italian translation (short, single sense)
      - mnemonic: optional Italian mnemonic phrase
      - emoji: optional override; otherwise auto-picked server-side
    Returns the created word, or {skipped: true, reason: "already_in_deck"}
    if a word with that romajii is already in the deck.
    Cannot add to starting decks (they're read-only templates) — 403."""
    token = await _resolve_token(ctx)
    body: dict[str, Any] = {"romajii": romajii, "kana": kana, "italiano": italiano}
    if mnemonic:
        body["mnemonic"] = mnemonic
    if emoji:
        body["emoji"] = emoji
    with _client(token) as c:
        r = c.post(f"/api/decks/{deck_id}/cards", json=body)
    if r.status_code == 409:
        return {"skipped": True, "reason": "already_in_deck", "romajii": romajii}
    _raise_for_status(r)
    return {"added": True, **r.json()}


@mcp.tool()
async def add_cards_bulk(
    ctx: Context,
    deck_id: int,
    cards: list[dict[str, Any]],
) -> dict[str, Any]:
    """Add several cards to a deck in one go. Each entry is the same shape
    as `add_card_to_deck` (romajii, kana, italiano, mnemonic?, emoji?).
    Returns:
      - added: list of successfully created word entries (from the server)
      - skipped: list of entries that didn't apply, with `reason` ∈
        {"already_in_deck", "missing_fields", "http_<code>"}.
    Iterates the per-card endpoint server-side (one HTTP request per card)
    so you only pay one MCP round-trip for the whole batch."""
    token = await _resolve_token(ctx)
    added: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []
    with _client(token) as c:
        for raw in cards:
            if not all(raw.get(k) for k in ("romajii", "kana", "italiano")):
                skipped.append({"reason": "missing_fields", "input": raw})
                continue
            body = {k: raw[k] for k in ("romajii", "kana", "italiano")}
            for opt in ("mnemonic", "emoji"):
                if raw.get(opt):
                    body[opt] = raw[opt]
            r = c.post(f"/api/decks/{deck_id}/cards", json=body)
            if r.status_code == 409:
                skipped.append({"reason": "already_in_deck", "romajii": raw.get("romajii")})
                continue
            if not r.is_success:
                try:
                    detail = r.json().get("detail") if r.headers.get("content-type", "").startswith("application/json") else r.text[:200]
                except Exception:
                    detail = r.text[:200]
                skipped.append({
                    "reason": f"http_{r.status_code}",
                    "romajii": raw.get("romajii"),
                    "detail": detail,
                })
                continue
            added.append(r.json())
    return {"added": added, "skipped": skipped}


# ---------------------------------------------------------------------------
# Entry points
# ---------------------------------------------------------------------------

def main() -> None:
    """Start the stdio MCP server (the `flashcard-jp-mcp` console script)."""
    mcp.run()


def setup_cli() -> None:
    """Standalone, terminal-based token provisioning.

    Run once after install (`uvx flashcard-jp-mcp-setup` works too):
    prints the token-creation URL, reads the token from stdin, validates
    it against the API, and saves to the config file.
    """
    print(f"flashcard-jp-mcp setup — API base: {API_BASE}")
    print()
    print(f"1. Apri {API_BASE} nel browser e fai login con Google.")
    print("2. Click sul tasto 🔑 nel navbar in alto a destra.")
    print("3. Crea un token (es. 'claude-desktop') e copia il valore.")
    print()
    try:
        token = input("Token (fjp_...): ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\nAnnullato.", file=sys.stderr)
        sys.exit(1)
    if not token.startswith("fjp_"):
        print("Token non valido — deve iniziare con `fjp_`.", file=sys.stderr)
        sys.exit(1)
    print("Verifico il token contro il server…")
    try:
        with _client(token) as c:
            r = c.get("/api/auth/me")
    except Exception as e:
        print(f"Impossibile contattare il server: {e}", file=sys.stderr)
        sys.exit(1)
    if not r.is_success:
        print(f"Token rifiutato dal server (HTTP {r.status_code}).", file=sys.stderr)
        sys.exit(1)
    me = r.json()
    _save_token(token, API_BASE)
    print(f"✓ Token salvato in {CONFIG_FILE} per {me.get('email')}.")
    print("Adesso puoi usare flashcard-jp-mcp dentro Claude — niente env var richiesta.")


if __name__ == "__main__":
    main()
