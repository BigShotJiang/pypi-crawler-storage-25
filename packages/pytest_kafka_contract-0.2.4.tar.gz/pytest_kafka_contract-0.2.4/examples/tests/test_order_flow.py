"""Example flow tests for the order filtering system.

Run these against a real Kafka broker with the order_filter_app running.
"""

from __future__ import annotations


def test_paid_order_reaches_dest_topic(kafka_contract):
    result = kafka_contract.run_json_flow(
        source_topic="src.rds.orders",
        destination_topic="dest.filtered.orders",
        payload={
            "order_id": "ord_123",
            "status": "PAID",
            "amount": 49.99,
        },
        correlation_field="correlation_id",
        expect={
            "order_id": "ord_123",
            "status": "PAID",
            "amount": 49.99,
        },
        contract_path="examples/contracts/filtered-order.yaml",
        bootstrap_servers="localhost:9092",
        timeout_ms=30000,
    )

    assert result.passed, result.issues


def test_cancelled_order_does_not_reach_dest_topic(kafka_contract):
    result = kafka_contract.expect_no_json_flow(
        source_topic="src.rds.orders",
        destination_topic="dest.filtered.orders",
        payload={
            "order_id": "ord_456",
            "status": "CANCELLED",
            "amount": 19.99,
        },
        correlation_field="correlation_id",
        bootstrap_servers="localhost:9092",
        timeout_ms=10000,
    )

    assert result.passed, result.issues
