def test_order_created_payload_sample(kafka_contract):
    result = kafka_contract.validate_payload(
        payload={
            "event_id": "evt_123",
            "event_type": "OrderCreated",
            "order": {
                "order_id": "ord_123",
                "total": 19.99,
            },
        },
        contract_path="examples/contracts/order-created.yaml",
    )

    assert result.passed, result.issues
