def test_order_created_avro_contract(kafka_contract):
    result = kafka_contract.validate_avro_record(
        record={
            "event_id": "evt_1",
            "order_id": "ord_1",
            "total": 20.0,
            "currency": "USD",
        },
        schema_path="examples/schemas/order-created.avsc",
    )

    assert result.passed, result.issues
