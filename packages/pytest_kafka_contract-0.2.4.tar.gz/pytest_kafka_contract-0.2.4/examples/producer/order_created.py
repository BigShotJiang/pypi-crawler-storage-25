from __future__ import annotations

import json

from confluent_kafka import Producer


def main() -> None:
    producer = Producer({"bootstrap.servers": "localhost:9092"})
    producer.produce(
        "orders.created",
        json.dumps(
            {
                "event_id": "evt_123",
                "event_type": "OrderCreated",
                "order": {"order_id": "ord_123", "total": 19.99},
            }
        ).encode("utf-8"),
    )
    producer.flush()


if __name__ == "__main__":
    main()
