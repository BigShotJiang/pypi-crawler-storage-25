"""Example order filter app.

Consumes from src.rds.orders.
Forwards PAID orders to dest.filtered.orders.
Drops all other orders.

This is example / reference code.  Not production code.
"""

from __future__ import annotations

import json
import threading

from confluent_kafka import Consumer, Producer


class OrderFilterApp:
    def __init__(
        self,
        bootstrap_servers: str,
        source_topic: str = "src.rds.orders",
        destination_topic: str = "dest.filtered.orders",
    ) -> None:
        self.bootstrap_servers = bootstrap_servers
        self.source_topic = source_topic
        self.destination_topic = destination_topic
        self.running = False
        self.thread: threading.Thread | None = None

    def start(self) -> None:
        self.running = True
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def stop(self) -> None:
        self.running = False
        if self.thread:
            self.thread.join(timeout=5)

    def _run(self) -> None:
        consumer = Consumer(
            {
                "bootstrap.servers": self.bootstrap_servers,
                "group.id": "order-filter-app",
                "auto.offset.reset": "latest",
                "enable.auto.commit": False,
            }
        )
        producer = Producer({"bootstrap.servers": self.bootstrap_servers})
        consumer.subscribe([self.source_topic])

        try:
            while self.running:
                msg = consumer.poll(0.2)
                if msg is None or msg.error():
                    continue

                event = json.loads(msg.value().decode("utf-8"))

                if event.get("status") == "PAID":
                    producer.produce(
                        self.destination_topic,
                        key=msg.key(),
                        value=json.dumps(event).encode("utf-8"),
                    )
                    producer.flush()
        finally:
            consumer.close()


if __name__ == "__main__":
    app = OrderFilterApp(bootstrap_servers="localhost:9092")
    print("Order filter app running. Press Ctrl+C to stop.")
    app.start()
    try:
        import time

        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        app.stop()
