# Release Checklist

## Prepare

```bash
python -m pip install -e ".[dev]"
pytest
ruff check .
mypy src
rm -rf dist build *.egg-info
python -m build
python -m twine check dist/*
```

## TestPyPI

```bash
python -m twine upload --repository testpypi dist/*
python -m venv /tmp/kafka-contract-test
source /tmp/kafka-contract-test/bin/activate
python -m pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple pytest-kafka-contract
kafka-contract examples
```

## PyPI

```bash
python -m twine upload dist/*
```

## Tag

```bash
git tag v0.1.0
git push origin v0.1.0
```
