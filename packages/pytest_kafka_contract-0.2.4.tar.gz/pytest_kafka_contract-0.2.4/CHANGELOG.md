# Changelog

## 0.2.0 - 2026-05-10

### Added

- Kafka JSON flow testing with `run_json_flow` — produce to source topic, poll destination topic, assert expected fields.
- Negative Kafka flow testing with `expect_no_json_flow` — verify a message is NOT forwarded to the destination topic.
- `FlowResult` object with `passed`, `source_topic`, `destination_topic`, `correlation_id`, `produced_message`, `consumed_message`, `issues`, and `metadata`.
- `FlowMessage` object capturing topic, partition, offset, key, value, headers, raw_value, and schema_id.
- `FlowSpec` dataclass and `load_flow_spec()` for loading YAML-defined flow test specs.
- `flow_assertions.assert_expected_subset()` — recursive subset matching with readable `$.field.path` error messages.
- `flow_serializers` — JSON encode/decode helpers with `FLOW_DESERIALIZATION_FAILED` issue code.
- `KafkaMessageProducer` and `KafkaMessageConsumer` flow-level wrappers in `kafka_client.py`.
- `KafkaFlowRunner` orchestration class in new `flow_runner.py`.
- `run_json_flow`, `expect_no_json_flow`, and `run_avro_flow` methods added to `KafkaContractRunner`.
- `flow-run` CLI command for running YAML-defined Kafka flow tests (`kafka-contract flow-run flows/my-flow.yaml`).
- Flow result reporting added to `reports.py`: `render_flow_markdown_report`, `write_flow_markdown_report`, `write_flow_json_report`, `build_flow_report`.
- Avro flow helpers `_encode_confluent_avro` and `_decode_confluent_avro` in `avro.py`.
- `_get_latest_schema` helper in `schema_registry.py`.
- Unit tests for flow models, assertions, serializers, Kafka client wrappers, JSON flow runner, runner fixture API, and CLI flow-run command.
- Integration test app `OrderFilterApp` for real-Kafka flow testing.
- Integration test `tests/integration/test_kafka_json_flow.py` (requires `PKCT_RUN_INTEGRATION=1`).
- Example flow YAML files in `examples/flows/`.
- Example test file `examples/tests/test_order_flow.py`.
- Example app `examples/apps/order_filter_app.py`.

- Confluent Avro wire format schema ID extraction.
- Confluent Avro message decoding.
- Schema Registry client.
- Schema Registry subject validation.
- Schema compatibility checks.
- Real Kafka JSON message validation.
- Real Kafka Avro message validation.
- New CLI commands for Avro, Registry, and Kafka checks.
- Markdown and JSON report metadata for Avro/Kafka.
- E2E temp user project tests.
- E2E CLI workflow tests.
- Wheel install prepublish test flow.
- Publish-worthy README structure.

## 0.1.0

Initial alpha release.

### Added

- Pytest plugin entry point.
- `kafka_contract` fixture.
- YAML contract loading.
- JSON payload validation.
- Required field validation.
- Type validation.
- Const and enum validation.
- Strict extra field validation.
- Helper CLI.
- PyPI packaging metadata.
