---
name: python-pypi-release-testing
description: Release gate for Python packages published to PyPI, including tests, integration checks, clean wheel smoke, and TestPyPI-first publishing.
---

# Python PyPI Release Testing

Use this skill before publishing a Python package or changing release automation.

## Rules

- Clean `dist`, `build`, root `*.egg-info`, and `src/*.egg-info` before every build.
- Never upload old files from a previous `dist/`.
- Never hardcode the package version in two places; prefer package metadata at runtime.
- Do not skip failing tests to make a release green.
- Publish to TestPyPI first when validating a release workflow.
- Publish to real PyPI only after the same artifacts pass local checks.

## Local Gate

Run fast tests first:

```bash
pytest tests/unit tests/plugin tests/e2e -q
ruff check .
mypy src
```

Run real-service tests when the project has integration coverage:

```bash
docker compose -f docker-compose.integration.yml up -d
PKCT_RUN_INTEGRATION=1 pytest tests/integration -q
docker compose -f docker-compose.integration.yml down -v
```

Build from a clean tree:

```bash
rm -rf dist build *.egg-info src/*.egg-info
python -m build
python -m twine check dist/*
```

Smoke-test the wheel in a clean virtualenv, not an editable install:

```bash
python3 -m venv /tmp/pypi-wheel-smoke
source /tmp/pypi-wheel-smoke/bin/activate
python -m pip install --upgrade pip
WHEEL="$(ls dist/*.whl)"
python -m pip install "${WHEEL}[all]"
python -c "import pytest_kafka_contract; print('import ok')"
kafka-contract --help
pytest --help | grep kafka
deactivate
```

Check README commands after public examples change:

```bash
pytest tests/e2e/test_readme_commands.py -q
```

## Publish Order

Upload to TestPyPI first:

```bash
python -m twine upload --repository testpypi dist/*
```

Upload the same checked artifacts to PyPI:

```bash
python -m twine upload dist/*
```
