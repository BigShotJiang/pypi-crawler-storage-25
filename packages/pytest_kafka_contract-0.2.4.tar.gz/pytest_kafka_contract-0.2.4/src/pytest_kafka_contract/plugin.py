from __future__ import annotations

import glob
from pathlib import Path
from typing import Any

import pytest

from pytest_kafka_contract.config import RuntimeConfig
from pytest_kafka_contract.contracts import load_contract
from pytest_kafka_contract.kafka_validation import validate_latest_json
from pytest_kafka_contract.result import ContractResult
from pytest_kafka_contract.reports import write_json_report, write_markdown_report
from pytest_kafka_contract.runner import KafkaContractRunner


def pytest_load_initial_conftests(args: list[str]) -> None:
    contract_paths = _contract_paths_from_args(args)
    for contract_path in _expand_contract_paths(contract_paths):
        path_arg = contract_path.as_posix()
        if path_arg not in args:
            args.append(path_arg)


def pytest_addoption(parser: pytest.Parser) -> None:
    group = parser.getgroup("kafka-contract")
    group.addoption(
        "--kafka-contract",
        action="append",
        default=[],
        help="Path or glob to Kafka contract YAML file. Can be passed multiple times.",
    )
    group.addoption(
        "--kafka-bootstrap-servers",
        action="store",
        default="localhost:9092",
        help="Kafka bootstrap servers.",
    )
    group.addoption(
        "--kafka-timeout-ms",
        action="store",
        type=int,
        default=10000,
        help="Kafka consume timeout in milliseconds.",
    )
    group.addoption(
        "--kafka-strict",
        action="store_true",
        default=False,
        help="Disallow extra fields in payloads.",
    )
    group.addoption(
        "--kafka-contract-report",
        action="store",
        default=None,
        help="Path to write Markdown contract report.",
    )
    group.addoption(
        "--kafka-contract-json-report",
        action="store",
        default=None,
        help="Path to write JSON contract report.",
    )
    group.addoption(
        "--schema-registry-url",
        action="store",
        default=None,
        help="Schema Registry URL for Avro validation.",
    )
    group.addoption(
        "--kafka-avro-subject",
        action="store",
        default=None,
        help="Schema Registry subject for Avro Kafka validation.",
    )
    group.addoption(
        "--kafka-format",
        action="store",
        choices=("json", "avro"),
        default="json",
        help="Kafka message format for generated contract checks.",
    )


def pytest_configure(config: pytest.Config) -> None:
    config.addinivalue_line(
        "markers",
        "kafka_contract(contract_path): validate Kafka message against a contract file",
    )
    config.addinivalue_line("markers", "avro_contract(schema_path): validate Avro record against schema")
    config.addinivalue_line("markers", "integration: tests requiring Kafka/Schema Registry")
    config._kafka_contract_results = []  # type: ignore[attr-defined]


def pytest_collect_file(file_path: Path, parent: pytest.Collector) -> pytest.File | None:
    if file_path.suffix not in {".yaml", ".yml"}:
        return None
    config = parent.config
    runtime_config = RuntimeConfig.from_pytest_config(config)
    contract_paths = {path.resolve() for path in _expand_contract_paths(runtime_config.contract_paths)}
    if file_path.resolve() not in contract_paths:
        return None
    return KafkaContractFile.from_parent(parent, path=file_path)


@pytest.fixture
def kafka_contract(request: pytest.FixtureRequest) -> KafkaContractRunner:
    return KafkaContractRunner(RuntimeConfig.from_pytest_config(request.config))


def pytest_terminal_summary(terminalreporter: Any) -> None:
    config = terminalreporter.config
    results = getattr(config, "_kafka_contract_results", [])
    if not results:
        return
    passed = sum(1 for result in results if result.passed)
    failed = len(results) - passed
    terminalreporter.write_sep("-", f"kafka contracts: {passed} passed, {failed} failed")

    runtime_config = RuntimeConfig.from_pytest_config(config)
    if runtime_config.markdown_report_path is not None:
        write_markdown_report(results, runtime_config.markdown_report_path)
    if runtime_config.json_report_path is not None:
        write_json_report(results, runtime_config.json_report_path)


class KafkaContractFile(pytest.File):
    def collect(self) -> list[pytest.Item]:
        return [KafkaContractItem.from_parent(self, contract_path=self.path)]


class KafkaContractItem(pytest.Item):
    def __init__(self, *, contract_path: Path, **kwargs: Any) -> None:
        super().__init__(
            name=f"kafka_contract[{contract_path.name}]",
            **kwargs,
        )
        self.contract_path = contract_path

    def runtest(self) -> None:
        runtime_config = RuntimeConfig.from_pytest_config(self.config)
        contract = load_contract(self.contract_path)
        result = validate_latest_json(
            topic=contract.topic,
            contract_path=self.contract_path,
            bootstrap_servers=runtime_config.bootstrap_servers,
            timeout_ms=runtime_config.timeout_ms,
        )
        results = getattr(self.config, "_kafka_contract_results", None)
        if isinstance(results, list):
            results.append(result)
        if not result.passed:
            raise AssertionError(_format_failure(result))

    def reportinfo(self) -> tuple[Path, int | None, str]:
        return self.contract_path, 0, f"kafka contract: {self.contract_path}"


def _expand_contract_paths(patterns: list[str]) -> list[Path]:
    paths: list[Path] = []
    for pattern in patterns:
        matches = sorted(glob.glob(pattern))
        if matches:
            paths.extend(Path(match) for match in matches)
        else:
            paths.append(Path(pattern))
    return paths


def _contract_paths_from_args(args: list[str]) -> list[str]:
    contract_paths: list[str] = []
    index = 0
    while index < len(args):
        arg = args[index]
        if arg == "--kafka-contract" and index + 1 < len(args):
            contract_paths.append(args[index + 1])
            index += 2
            continue
        if arg.startswith("--kafka-contract="):
            contract_paths.append(arg.split("=", 1)[1])
        index += 1
    return contract_paths


def _format_failure(result: ContractResult) -> str:
    lines = [
        f"Kafka contract failed: {result.metadata.get('topic', 'unknown')}",
        f"Topic: {result.metadata.get('topic', 'unknown')}",
        "",
    ]
    for issue in result.issues:
        lines.extend(
            [
                f"{issue.code} {issue.path}",
                f"  Expected: {issue.expected}",
                f"  Actual: {issue.actual}",
                f"  Message: {issue.message}",
            ]
        )
    return "\n".join(lines)
