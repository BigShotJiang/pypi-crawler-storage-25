from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class ContractIssue:
    code: str
    path: str
    message: str
    expected: Any | None = None
    actual: Any | None = None


@dataclass(frozen=True)
class ContractResult:
    passed: bool
    issues: list[ContractIssue] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def pass_result(cls, **metadata: Any) -> ContractResult:
        return cls(passed=True, issues=[], metadata=metadata)

    @classmethod
    def fail_result(cls, issues: list[ContractIssue], **metadata: Any) -> ContractResult:
        return cls(passed=False, issues=issues, metadata=metadata)
