from __future__ import annotations

from pathlib import Path
from typing import Any


def read_text(path: str | Path) -> str:
    return Path(path).read_text(encoding="utf-8")


def require_fastavro() -> Any:
    try:
        import fastavro
    except ImportError as exc:
        raise RuntimeError('Install Avro support: pip install "pytest-kafka-contract[avro]"') from exc
    return fastavro


def require_httpx() -> Any:
    try:
        import httpx
    except ImportError as exc:
        raise RuntimeError('Install Registry support: pip install "pytest-kafka-contract[registry]"') from exc
    return httpx


def require_confluent_kafka() -> Any:
    try:
        import confluent_kafka
    except ImportError as exc:
        raise RuntimeError('Install Kafka support: pip install "pytest-kafka-contract[kafka]"') from exc
    return confluent_kafka
