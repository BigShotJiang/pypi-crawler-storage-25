"""pytest-kafka-contract public package."""

from importlib.metadata import PackageNotFoundError, version

from pytest_kafka_contract.contracts import load_contract
from pytest_kafka_contract.avro import validate_avro_record
from pytest_kafka_contract.flow import FlowMessage, FlowResult, FlowSpec, load_flow_spec
from pytest_kafka_contract.kafka_validation import validate_latest_avro, validate_latest_json
from pytest_kafka_contract.models import (
    Contract,
    ContractRules,
    FieldRule,
    KafkaMessage,
    ValidationIssue,
    ValidationResult,
)
from pytest_kafka_contract.result import ContractIssue, ContractResult
from pytest_kafka_contract.validator import validate_payload

__all__ = [
    "Contract",
    "ContractRules",
    "FieldRule",
    "FlowMessage",
    "FlowResult",
    "FlowSpec",
    "KafkaMessage",
    "ContractIssue",
    "ContractResult",
    "ValidationIssue",
    "ValidationResult",
    "load_contract",
    "load_flow_spec",
    "validate_avro_record",
    "validate_latest_avro",
    "validate_latest_json",
    "validate_payload",
]

try:
    __version__ = version("pytest-kafka-contract")
except PackageNotFoundError:
    __version__ = "0.0.0+local"
