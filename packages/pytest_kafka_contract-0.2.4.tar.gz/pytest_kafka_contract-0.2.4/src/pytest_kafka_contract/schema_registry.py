from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from pytest_kafka_contract.avro import load_avro_schema
from pytest_kafka_contract.result import ContractIssue, ContractResult
from pytest_kafka_contract.utils import require_httpx


@dataclass
class SchemaRegistryClient:
    registry_url: str
    timeout_seconds: float = 10.0
    transport: Any | None = None

    def get_latest_schema(self, subject: str) -> dict[str, Any]:
        response = self._client().get(f"{self._base_url()}/subjects/{subject}/versions/latest")
        if response.status_code == 404:
            raise LookupError(f"Schema Registry subject not found: {subject}")
        response.raise_for_status()
        return _parse_schema_response(response.json())

    def get_schema_by_id(self, schema_id: int) -> dict[str, Any]:
        response = self._client().get(f"{self._base_url()}/schemas/ids/{schema_id}")
        if response.status_code == 404:
            raise LookupError(f"Schema Registry schema id not found: {schema_id}")
        response.raise_for_status()
        payload = response.json()
        return _schema_json_to_dict(payload["schema"])

    def subject_exists(self, subject: str) -> bool:
        try:
            self.get_latest_schema(subject)
        except LookupError:
            return False
        return True

    def check_compatibility(
        self,
        subject: str,
        schema: dict[str, Any],
        version: str = "latest",
    ) -> bool:
        response = self._client().post(
            f"{self._base_url()}/compatibility/subjects/{subject}/versions/{version}",
            json={"schemaType": "AVRO", "schema": json.dumps(schema)},
        )
        response.raise_for_status()
        return bool(response.json().get("is_compatible", False))

    def _client(self) -> Any:
        httpx = require_httpx()
        return httpx.Client(timeout=self.timeout_seconds, transport=self.transport)

    def _base_url(self) -> str:
        return self.registry_url.rstrip("/")


def validate_schema_registry_subject(
    registry_url: str,
    subject: str,
    schema_path: str | Path,
    compatibility: str | None = None,
    client: SchemaRegistryClient | None = None,
) -> ContractResult:
    registry_client = client or SchemaRegistryClient(registry_url=registry_url)
    try:
        latest = registry_client.get_latest_schema(subject)
    except LookupError:
        return _registry_failure(
            "REGISTRY_SUBJECT_NOT_FOUND",
            f"Schema Registry subject '{subject}' was not found.",
            registry_url,
            subject,
        )
    except Exception as exc:
        return _registry_failure(
            "REGISTRY_UNREACHABLE",
            "Schema Registry could not be reached.",
            registry_url,
            subject,
            actual=str(exc),
        )

    local_schema = load_avro_schema(schema_path)
    if latest["schema"] != local_schema:
        return _registry_failure(
            "REGISTRY_SCHEMA_MISMATCH",
            "Local schema does not match latest registry schema.",
            registry_url,
            subject,
            schema_id=latest.get("id"),
            version=latest.get("version"),
        )

    if compatibility is not None:
        try:
            compatible = registry_client.check_compatibility(subject, local_schema, version="latest")
        except Exception as exc:
            return _registry_failure(
                "REGISTRY_UNREACHABLE",
                "Schema Registry compatibility check failed to run.",
                registry_url,
                subject,
                actual=str(exc),
            )
        if not compatible:
            return _registry_failure(
                "REGISTRY_COMPATIBILITY_FAILED",
                f"Schema is not {compatibility} compatible.",
                registry_url,
                subject,
                schema_id=latest.get("id"),
                version=latest.get("version"),
            )

    return ContractResult.pass_result(
        registry_url=registry_url,
        subject=subject,
        schema_id=latest.get("id"),
        version=latest.get("version"),
        compatibility=compatibility,
        format="avro",
    )


def _parse_schema_response(payload: dict[str, Any]) -> dict[str, Any]:
    parsed = dict(payload)
    parsed["schema"] = _schema_json_to_dict(payload["schema"])
    return parsed


def _schema_json_to_dict(schema_json: str) -> dict[str, Any]:
    parsed = json.loads(schema_json)
    if not isinstance(parsed, dict):
        raise ValueError("Schema Registry schema must be a JSON object")
    return parsed


def _registry_failure(
    code: str,
    message: str,
    registry_url: str,
    subject: str,
    *,
    actual: Any | None = None,
    schema_id: Any | None = None,
    version: Any | None = None,
) -> ContractResult:
    return ContractResult.fail_result(
        [ContractIssue(code=code, path="$", message=message, actual=actual)],
        registry_url=registry_url,
        subject=subject,
        schema_id=schema_id,
        version=version,
        format="avro",
    )


def _get_latest_schema(registry_url: str, subject: str) -> dict[str, Any]:
    """Fetch the latest schema for *subject* from the registry.

    Returns a dict with keys ``id``, ``version``, and ``schema`` (parsed dict).
    """
    client = SchemaRegistryClient(registry_url=registry_url)
    return client.get_latest_schema(subject)
