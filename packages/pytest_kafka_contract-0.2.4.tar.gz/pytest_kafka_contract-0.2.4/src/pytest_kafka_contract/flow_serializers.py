from __future__ import annotations

import json
from typing import Any

from pytest_kafka_contract.result import ContractIssue


def encode_json(payload: dict[str, Any]) -> bytes:
    """Encode a dict to UTF-8 JSON bytes."""
    return json.dumps(payload).encode("utf-8")


def decode_json(raw: bytes) -> tuple[dict[str, Any] | None, ContractIssue | None]:
    """Decode UTF-8 JSON bytes to a dict.

    Returns ``(dict, None)`` on success or ``(None, issue)`` on failure.
    """
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        issue = ContractIssue(
            code="FLOW_DESERIALIZATION_FAILED",
            path="$",
            message=f"Failed to decode JSON message: {exc}",
        )
        return None, issue

    if not isinstance(value, dict):
        issue = ContractIssue(
            code="FLOW_DESERIALIZATION_FAILED",
            path="$",
            message=f"Expected JSON object but got {type(value).__name__}",
        )
        return None, issue

    return value, None


def normalize_headers(
    headers: dict[str, str] | None,
) -> list[tuple[str, bytes]]:
    """Convert a string-to-string header dict to confluent_kafka header list."""
    if not headers:
        return []
    return [(k, v.encode("utf-8")) for k, v in headers.items()]
