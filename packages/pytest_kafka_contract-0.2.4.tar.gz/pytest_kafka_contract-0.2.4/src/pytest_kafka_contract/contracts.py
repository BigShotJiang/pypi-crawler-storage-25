from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from pytest_kafka_contract.errors import ContractLoadError
from pytest_kafka_contract.models import Contract, ContractRules, FieldRule

ROOT_FIELDS = {"version", "name", "topic", "message", "rules"}
FIELD_TYPES = {"string", "number", "integer", "boolean", "object", "array", "null"}


def load_contract(path: str | Path) -> Contract:
    contract_path = Path(path)
    try:
        raw = yaml.safe_load(contract_path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise ContractLoadError(f"Could not read contract file '{contract_path}': {exc}") from exc
    except yaml.YAMLError as exc:
        raise ContractLoadError(f"Could not parse YAML contract '{contract_path}': {exc}") from exc

    if not isinstance(raw, dict):
        raise ContractLoadError("Contract root must be a mapping.")

    unknown = set(raw) - ROOT_FIELDS
    if unknown:
        fields = ", ".join(sorted(unknown))
        raise ContractLoadError(f"Unknown root field(s): {fields}.")

    for required in ("version", "name", "topic", "message"):
        if required not in raw:
            raise ContractLoadError(f"Missing required root field: {required}.")

    if not isinstance(raw["version"], int):
        raise ContractLoadError("Contract field 'version' must be an integer.")
    if not isinstance(raw["name"], str) or not raw["name"]:
        raise ContractLoadError("Contract field 'name' must be a non-empty string.")
    if not isinstance(raw["topic"], str) or not raw["topic"]:
        raise ContractLoadError("Contract field 'topic' must be a non-empty string.")

    return Contract(
        version=raw["version"],
        name=raw["name"],
        topic=raw["topic"],
        message=_parse_field_rule(raw["message"], "message"),
        rules=_parse_rules(raw.get("rules", {})),
    )


def _parse_rules(raw: Any) -> ContractRules:
    if raw is None:
        raw = {}
    if not isinstance(raw, dict):
        raise ContractLoadError("Contract field 'rules' must be a mapping.")
    allowed = {
        "allow_extra_fields",
        "fail_on_missing_required",
        "fail_on_type_mismatch",
        "fail_on_null_required",
    }
    unknown = set(raw) - allowed
    if unknown:
        fields = ", ".join(sorted(unknown))
        raise ContractLoadError(f"Unknown rule field(s): {fields}.")
    return ContractRules(
        allow_extra_fields=bool(raw.get("allow_extra_fields", True)),
        fail_on_missing_required=bool(raw.get("fail_on_missing_required", True)),
        fail_on_type_mismatch=bool(raw.get("fail_on_type_mismatch", True)),
        fail_on_null_required=bool(raw.get("fail_on_null_required", True)),
    )


def _parse_field_rule(raw: Any, path: str) -> FieldRule:
    if not isinstance(raw, dict):
        raise ContractLoadError(f"Field rule '{path}' must be a mapping.")
    if "type" not in raw:
        raise ContractLoadError(f"Field rule '{path}' is missing required field 'type'.")
    field_type = raw["type"]
    if field_type not in FIELD_TYPES:
        raise ContractLoadError(f"Field rule '{path}' has unsupported type '{field_type}'.")

    required = raw.get("required", [])
    if required is None:
        required = []
    if not isinstance(required, list) or not all(isinstance(item, str) for item in required):
        raise ContractLoadError(f"Field rule '{path}.required' must be a list of strings.")

    properties_raw = raw.get("properties", {})
    if properties_raw is None:
        properties_raw = {}
    if not isinstance(properties_raw, dict):
        raise ContractLoadError(f"Field rule '{path}.properties' must be a mapping.")
    properties = {
        name: _parse_field_rule(value, f"{path}.properties.{name}")
        for name, value in properties_raw.items()
    }

    items_raw = raw.get("items")
    items = _parse_field_rule(items_raw, f"{path}.items") if items_raw is not None else None

    enum = raw.get("enum")
    if enum is not None and not isinstance(enum, list):
        raise ContractLoadError(f"Field rule '{path}.enum' must be a list.")

    return FieldRule(
        type=field_type,
        nullable=bool(raw.get("nullable", True)),
        required=required,
        properties=properties,
        items=items,
        const=raw.get("const"),
        enum=enum,
        format=raw.get("format"),
    )
