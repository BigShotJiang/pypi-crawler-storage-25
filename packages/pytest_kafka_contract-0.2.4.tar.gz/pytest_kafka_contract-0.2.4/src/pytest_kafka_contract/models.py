from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class FieldRule:
    type: str
    nullable: bool = True
    required: list[str] = field(default_factory=list)
    properties: dict[str, FieldRule] = field(default_factory=dict)
    items: FieldRule | None = None
    const: Any | None = None
    enum: list[Any] | None = None
    format: str | None = None


@dataclass
class ContractRules:
    allow_extra_fields: bool = True
    fail_on_missing_required: bool = True
    fail_on_type_mismatch: bool = True
    fail_on_null_required: bool = True


@dataclass
class Contract:
    version: int
    name: str
    topic: str
    message: FieldRule
    rules: ContractRules


@dataclass
class ValidationIssue:
    code: str
    path: str
    expected: str | None
    actual: str | None
    message: str


@dataclass
class ValidationResult:
    contract_name: str
    topic: str
    passed: bool
    issues: list[ValidationIssue]


@dataclass
class KafkaMessage:
    topic: str
    partition: int
    offset: int
    key: bytes | None
    value: bytes | None
    timestamp: int | None
    headers: dict[str, str]
