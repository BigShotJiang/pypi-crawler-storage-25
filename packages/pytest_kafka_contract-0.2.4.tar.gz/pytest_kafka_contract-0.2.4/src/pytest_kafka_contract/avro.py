from __future__ import annotations

import json
from io import BytesIO
from pathlib import Path
from typing import Any

from pytest_kafka_contract.result import ContractIssue, ContractResult
from pytest_kafka_contract.utils import require_fastavro


def load_avro_schema(schema_path: str | Path) -> dict[str, Any]:
    raw = json.loads(Path(schema_path).read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError("Avro schema file must contain a JSON object")
    return raw


def validate_avro_record(
    record: dict[str, Any],
    schema_path: str | Path | None = None,
    schema: dict[str, Any] | None = None,
) -> ContractResult:
    if schema_path is None and schema is None:
        raise ValueError("schema_path or schema is required")
    avro_schema = load_avro_schema(schema_path) if schema is None and schema_path is not None else schema
    assert avro_schema is not None

    fastavro = require_fastavro()
    try:
        parsed_schema = fastavro.parse_schema(avro_schema)
    except Exception as exc:
        return ContractResult.fail_result(
            [
                ContractIssue(
                    code="AVRO_SCHEMA_INVALID",
                    path="$",
                    message="Avro schema is invalid",
                    actual=str(exc),
                )
            ],
            format="avro",
        )

    try:
        valid = bool(fastavro.validation.validate(record, parsed_schema, raise_errors=False))
    except Exception as exc:
        return _avro_record_invalid(str(exc), avro_schema)

    if valid:
        return ContractResult.pass_result(format="avro", schema_name=avro_schema.get("name"))

    details = _find_basic_avro_issue(record, avro_schema)
    return _avro_record_invalid(details, avro_schema)


def extract_confluent_schema_id(message_bytes: bytes) -> int:
    if len(message_bytes) < 5:
        raise ValueError("Confluent Avro message must be at least 5 bytes")
    if message_bytes[0] != 0:
        raise ValueError("Invalid Confluent Avro magic byte")
    return int.from_bytes(message_bytes[1:5], byteorder="big", signed=False)


def decode_confluent_avro_message(
    message_bytes: bytes,
    schema: dict[str, Any],
) -> ContractResult:
    fastavro = require_fastavro()
    try:
        schema_id = extract_confluent_schema_id(message_bytes)
        payload = message_bytes[5:]
        record = fastavro.schemaless_reader(BytesIO(payload), fastavro.parse_schema(schema))
    except Exception as exc:
        return ContractResult.fail_result(
            [
                ContractIssue(
                    code="KAFKA_DESERIALIZATION_FAILED",
                    path="$",
                    message="Could not decode Confluent Avro message",
                    actual=str(exc),
                )
            ],
            format="avro",
        )
    return ContractResult.pass_result(schema_id=schema_id, record=record, format="avro")


def _avro_record_invalid(details: str, schema: dict[str, Any]) -> ContractResult:
    return ContractResult.fail_result(
        [
            ContractIssue(
                code="AVRO_RECORD_INVALID",
                path="$",
                message="Avro record does not match schema",
                actual=details,
            )
        ],
        format="avro",
        schema_name=schema.get("name"),
    )


def _find_basic_avro_issue(record: dict[str, Any], schema: dict[str, Any]) -> str:
    for field in schema.get("fields", []):
        if not isinstance(field, dict):
            continue
        name = field.get("name")
        if not isinstance(name, str):
            continue
        has_default = "default" in field
        nullable = _is_nullable(field.get("type"))
        if name not in record and not has_default:
            return f"Missing required field: {name}"
        if name in record and record[name] is None and not nullable:
            return f"Field is not nullable: {name}"
    return "Record failed Avro validation"


def _is_nullable(field_type: Any) -> bool:
    return field_type == "null" or (isinstance(field_type, list) and "null" in field_type)


# ---------------------------------------------------------------------------
# Confluent wire-format encode/decode helpers (used by flow tests)
# ---------------------------------------------------------------------------


def _encode_confluent_avro(record: dict[str, Any], schema_id: int, schema: dict[str, Any]) -> bytes:
    """Encode a record using the Confluent Avro wire format (magic byte + 4-byte schema id + payload)."""
    fastavro = require_fastavro()
    parsed = fastavro.parse_schema(dict(schema))
    buf = BytesIO()
    buf.write(b"\x00")
    buf.write(schema_id.to_bytes(4, byteorder="big"))
    fastavro.schemaless_writer(buf, parsed, record)
    return buf.getvalue()


def _decode_confluent_avro(
    message_bytes: bytes,
    registry_url: str,
) -> tuple[dict[str, Any], int]:
    """Decode a Confluent Avro wire-format message.

    Returns ``(record, schema_id)``.  Fetches the schema from the registry by id.
    """
    from pytest_kafka_contract.schema_registry import SchemaRegistryClient

    schema_id = extract_confluent_schema_id(message_bytes)
    client = SchemaRegistryClient(registry_url=registry_url)
    schema = client.get_schema_by_id(schema_id)

    fastavro = require_fastavro()
    parsed = fastavro.parse_schema(schema)
    payload = message_bytes[5:]
    record = fastavro.schemaless_reader(BytesIO(payload), parsed)
    return record, schema_id
