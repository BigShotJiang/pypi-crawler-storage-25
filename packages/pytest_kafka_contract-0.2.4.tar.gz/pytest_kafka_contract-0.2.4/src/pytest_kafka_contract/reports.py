from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
from typing import Any

from pytest_kafka_contract.flow import FlowResult
from pytest_kafka_contract.models import ValidationResult
from pytest_kafka_contract.result import ContractResult


ReportableResult = ValidationResult | ContractResult


def build_report(results: list[ReportableResult]) -> dict[str, object]:
    passed = sum(1 for result in results if result.passed)
    failed = len(results) - passed
    return {
        "summary": {"total": len(results), "passed": passed, "failed": failed},
        "results": [_result_to_dict(result) for result in results],
    }


def write_json_report(results: list[ReportableResult], path: str | Path) -> None:
    report_path = Path(path)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(build_report(results), indent=2) + "\n", encoding="utf-8")


def write_markdown_report(results: list[ReportableResult], path: str | Path) -> None:
    report_path = Path(path)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(render_markdown_report(results), encoding="utf-8")


def render_markdown_report(results: list[ReportableResult]) -> str:
    report = build_report(results)
    summary = report["summary"]
    assert isinstance(summary, dict)

    lines = [
        "# Kafka Contract Report",
        "",
        "## Summary",
        "",
        "| Total | Passed | Failed |",
        "|---:|---:|---:|",
        f"| {summary['total']} | {summary['passed']} | {summary['failed']} |",
    ]

    failed_results = [result for result in results if not result.passed]
    if failed_results:
        lines.extend(["", "## Failed Checks"])
        for result in failed_results:
            metadata = _metadata(result)
            title = _title(result)
            lines.extend(
                [
                    "",
                    f"### {_escape_markdown_cell(title)}",
                    "",
                    f"- Format: {_display(metadata.get('format'))}",
                    f"- Topic: {_display(metadata.get('topic'))}",
                    f"- Subject: {_display(metadata.get('subject'))}",
                    f"- Schema ID: {_display(metadata.get('schema_id'))}",
                    "",
                    "| Code | Path | Expected | Actual | Message |",
                    "|---|---|---|---|---|",
                ]
            )
            for issue in result.issues:
                lines.append(
                    "| "
                    + " | ".join(
                        [
                            _escape_markdown_cell(issue.code),
                            _escape_markdown_cell(issue.path),
                            _escape_markdown_cell(_display(issue.expected)),
                            _escape_markdown_cell(_display(issue.actual)),
                            _escape_markdown_cell(issue.message),
                        ]
                    )
                    + " |"
                )

    return "\n".join(lines) + "\n"


def _result_to_dict(result: ReportableResult) -> dict[str, Any]:
    return asdict(result)


def _metadata(result: ReportableResult) -> dict[str, Any]:
    return result.metadata if isinstance(result, ContractResult) else {"topic": result.topic}


def _title(result: ReportableResult) -> str:
    if isinstance(result, ContractResult):
        return str(result.metadata.get("topic") or result.metadata.get("subject") or "contract check")
    return result.contract_name


def _display(value: object | None) -> str:
    return "null" if value is None else str(value)


def _escape_markdown_cell(value: str) -> str:
    return value.replace("|", "\\|")


# ---------------------------------------------------------------------------
# Flow result reporting
# ---------------------------------------------------------------------------


def build_flow_report(results: list[FlowResult]) -> dict[str, object]:
    passed = sum(1 for r in results if r.passed)
    failed = len(results) - passed
    return {
        "summary": {"total": len(results), "passed": passed, "failed": failed},
        "flows": [_flow_result_to_dict(r) for r in results],
    }


def write_flow_json_report(results: list[FlowResult], path: str | Path) -> None:
    report_path = Path(path)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(build_flow_report(results), indent=2) + "\n", encoding="utf-8")


def write_flow_markdown_report(results: list[FlowResult], path: str | Path) -> None:
    report_path = Path(path)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(render_flow_markdown_report(results), encoding="utf-8")


def render_flow_markdown_report(results: list[FlowResult]) -> str:
    lines = [
        "## Kafka Flow Results",
        "",
        "| Flow | Source | Destination | Correlation ID | Status |",
        "|---|---|---|---|---|",
    ]
    for r in results:
        status = "PASS" if r.passed else "FAIL"
        lines.append(
            "| "
            + " | ".join(
                [
                    _escape_markdown_cell(r.flow_name or ""),
                    _escape_markdown_cell(r.source_topic or ""),
                    _escape_markdown_cell(r.destination_topic or ""),
                    _escape_markdown_cell(r.correlation_id or ""),
                    status,
                ]
            )
            + " |"
        )

    failed = [r for r in results if not r.passed]
    if failed:
        lines.append("")
        for r in failed:
            lines.extend(
                [
                    f"### {_escape_markdown_cell(r.flow_name or 'flow')}",
                    "",
                    "Status: FAIL",
                    f"Source: {r.source_topic}",
                    f"Destination: {r.destination_topic}",
                    f"Correlation ID: {r.correlation_id}",
                    "",
                    "Issues:",
                ]
            )
            for issue in r.issues:
                lines.append(
                    f"- {issue.code} at {issue.path}: {issue.message}"
                )
            lines.append("")

    return "\n".join(lines) + "\n"


def _flow_result_to_dict(r: FlowResult) -> dict[str, Any]:
    d: dict[str, Any] = {
        "name": r.flow_name,
        "passed": r.passed,
        "source_topic": r.source_topic,
        "destination_topic": r.destination_topic,
        "correlation_id": r.correlation_id,
        "issues": [asdict(i) for i in r.issues],
    }
    if r.produced_message:
        d["produced"] = {"topic": r.produced_message.topic}
    if r.consumed_message:
        d["consumed"] = {
            "topic": r.consumed_message.topic,
            "partition": r.consumed_message.partition,
            "offset": r.consumed_message.offset,
        }
    return d
