from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class RuntimeConfig:
    contract_paths: list[str]
    bootstrap_servers: str = "localhost:9092"
    timeout_ms: int = 10000
    strict: bool = False
    markdown_report_path: Path | None = None
    json_report_path: Path | None = None
    schema_registry_url: str | None = None
    avro_subject: str | None = None
    kafka_format: str = "json"

    @classmethod
    def from_pytest_config(cls, config: Any) -> RuntimeConfig:
        return cls(
            contract_paths=list(config.getoption("--kafka-contract") or []),
            bootstrap_servers=str(config.getoption("--kafka-bootstrap-servers")),
            timeout_ms=int(config.getoption("--kafka-timeout-ms")),
            strict=bool(config.getoption("--kafka-strict")),
            markdown_report_path=_optional_path(config.getoption("--kafka-contract-report")),
            json_report_path=_optional_path(config.getoption("--kafka-contract-json-report")),
            schema_registry_url=config.getoption("--schema-registry-url"),
            avro_subject=config.getoption("--kafka-avro-subject"),
            kafka_format=str(config.getoption("--kafka-format")),
        )


def _optional_path(value: str | None) -> Path | None:
    return Path(value) if value else None
