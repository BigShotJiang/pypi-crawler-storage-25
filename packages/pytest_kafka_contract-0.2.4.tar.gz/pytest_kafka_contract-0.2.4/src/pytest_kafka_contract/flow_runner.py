from __future__ import annotations

import uuid
from pathlib import Path
from typing import Any

from pytest_kafka_contract.config import RuntimeConfig
from pytest_kafka_contract.flow import FlowMessage, FlowResult
from pytest_kafka_contract.flow_assertions import assert_expected_subset
from pytest_kafka_contract.flow_serializers import decode_json, encode_json, normalize_headers
from pytest_kafka_contract.kafka_client import KafkaMessageConsumer, KafkaMessageProducer
from pytest_kafka_contract.result import ContractIssue


class KafkaFlowRunner:
    def __init__(self, runtime_config: RuntimeConfig) -> None:
        self.runtime_config = runtime_config

    # ------------------------------------------------------------------
    # JSON flow
    # ------------------------------------------------------------------

    def run_json_flow(
        self,
        source_topic: str,
        destination_topic: str,
        payload: dict[str, Any],
        *,
        expect: dict[str, Any] | None = None,
        contract_path: str | None = None,
        correlation_field: str = "correlation_id",
        correlation_id: str | None = None,
        key: str | bytes | None = None,
        bootstrap_servers: str | None = None,
        timeout_ms: int | None = None,
        group_id: str | None = None,
        headers: dict[str, str] | None = None,
        poll_interval_ms: int = 500,
    ) -> FlowResult:
        bootstrap = bootstrap_servers or self.runtime_config.bootstrap_servers
        timeout = timeout_ms if timeout_ms is not None else self.runtime_config.timeout_ms
        corr_id = correlation_id or str(uuid.uuid4())
        gid = group_id or f"qa-flow-{uuid.uuid4()}"

        payload_to_send = dict(payload)
        if correlation_field not in payload_to_send:
            payload_to_send[correlation_field] = corr_id

        key_to_send: str | bytes | None = key if key is not None else corr_id
        encoded_headers = normalize_headers(headers)


        consumer = KafkaMessageConsumer(bootstrap, gid, auto_offset_reset="earliest")
        try:
            consumer.subscribe([destination_topic])

            producer = KafkaMessageProducer(bootstrap)
            try:
                value_bytes = encode_json(payload_to_send)
                producer.produce(
                    source_topic,
                    key_to_send,
                    value_bytes,
                    headers=encoded_headers or None,
                )
                producer.flush()
            finally:
                producer.close()

            produced = FlowMessage(
                topic=source_topic,
                key=key_to_send,
                value=payload_to_send,
                raw_value=encode_json(payload_to_send),
                headers=headers or {},
            )

            consumed_raw = consumer.poll_until(
                matcher=lambda v: v.get(correlation_field) == corr_id,
                decoder=decode_json,
                timeout_ms=timeout,
                poll_interval_ms=poll_interval_ms,
            )
        finally:
            consumer.close()

        if consumed_raw is None:
            return FlowResult(
                passed=False,
                source_topic=source_topic,
                destination_topic=destination_topic,
                correlation_id=corr_id,
                produced_message=produced,
                issues=[
                    ContractIssue(
                        code="FLOW_TIMEOUT",
                        path="$",
                        message=(
                            f"No message with {correlation_field}={corr_id} found on "
                            f"{destination_topic} within {timeout}ms"
                        ),
                    )
                ],
            )

        consumed_value, deser_issue = decode_json(consumed_raw.value)  # type: ignore[arg-type]
        if deser_issue or consumed_value is None:
            return FlowResult(
                passed=False,
                source_topic=source_topic,
                destination_topic=destination_topic,
                correlation_id=corr_id,
                produced_message=produced,
                issues=[deser_issue] if deser_issue else [],
            )

        consumed_msg = FlowMessage(
            topic=consumed_raw.topic,
            partition=consumed_raw.partition,
            offset=consumed_raw.offset,
            key=consumed_raw.key,
            value=consumed_value,
            raw_value=consumed_raw.value,
        )

        issues: list[ContractIssue] = []

        if expect:
            issues.extend(assert_expected_subset(consumed_value, expect))

        if contract_path:
            issues.extend(_validate_contract(consumed_value, contract_path))

        return FlowResult(
            passed=len(issues) == 0,
            source_topic=source_topic,
            destination_topic=destination_topic,
            correlation_id=corr_id,
            produced_message=produced,
            consumed_message=consumed_msg,
            issues=issues,
            metadata={
                "partition": consumed_raw.partition,
                "offset": consumed_raw.offset,
            },
        )

    # ------------------------------------------------------------------
    # Negative JSON flow
    # ------------------------------------------------------------------

    def expect_no_json_flow(
        self,
        source_topic: str,
        destination_topic: str,
        payload: dict[str, Any],
        *,
        correlation_field: str = "correlation_id",
        correlation_id: str | None = None,
        key: str | bytes | None = None,
        bootstrap_servers: str | None = None,
        timeout_ms: int | None = None,
        group_id: str | None = None,
        headers: dict[str, str] | None = None,
        poll_interval_ms: int = 500,
    ) -> FlowResult:
        bootstrap = bootstrap_servers or self.runtime_config.bootstrap_servers
        timeout = timeout_ms if timeout_ms is not None else self.runtime_config.timeout_ms
        corr_id = correlation_id or str(uuid.uuid4())
        gid = group_id or f"qa-flow-{uuid.uuid4()}"

        payload_to_send = dict(payload)
        if correlation_field not in payload_to_send:
            payload_to_send[correlation_field] = corr_id

        key_to_send: str | bytes | None = key if key is not None else corr_id
        encoded_headers = normalize_headers(headers)


        consumer = KafkaMessageConsumer(bootstrap, gid, auto_offset_reset="earliest")
        try:
            consumer.subscribe([destination_topic])

            producer = KafkaMessageProducer(bootstrap)
            try:
                value_bytes = encode_json(payload_to_send)
                producer.produce(
                    source_topic,
                    key_to_send,
                    value_bytes,
                    headers=encoded_headers or None,
                )
                producer.flush()
            finally:
                producer.close()

            produced = FlowMessage(
                topic=source_topic,
                key=key_to_send,
                value=payload_to_send,
                raw_value=encode_json(payload_to_send),
                headers=headers or {},
            )

            consumed_raw = consumer.poll_until(
                matcher=lambda v: v.get(correlation_field) == corr_id,
                decoder=decode_json,
                timeout_ms=timeout,
                poll_interval_ms=poll_interval_ms,
            )
        finally:
            consumer.close()

        if consumed_raw is None:
            return FlowResult(
                passed=True,
                source_topic=source_topic,
                destination_topic=destination_topic,
                correlation_id=corr_id,
                produced_message=produced,
            )

        consumed_value, _ = decode_json(consumed_raw.value)  # type: ignore[arg-type]
        consumed_msg = FlowMessage(
            topic=consumed_raw.topic,
            partition=consumed_raw.partition,
            offset=consumed_raw.offset,
            key=consumed_raw.key,
            value=consumed_value,
            raw_value=consumed_raw.value,
        )

        return FlowResult(
            passed=False,
            source_topic=source_topic,
            destination_topic=destination_topic,
            correlation_id=corr_id,
            produced_message=produced,
            consumed_message=consumed_msg,
            issues=[
                ContractIssue(
                    code="FLOW_UNEXPECTED_MESSAGE",
                    path="$",
                    message=(
                        f"Expected no destination message but found one on "
                        f"{destination_topic} "
                        f"offset={consumed_raw.offset} "
                        f"{correlation_field}={corr_id}"
                    ),
                )
            ],
        )

    # ------------------------------------------------------------------
    # Avro flow (v1 – JSON source, Avro-encoded destination via Schema Registry)
    # ------------------------------------------------------------------

    def run_avro_flow(
        self,
        source_topic: str,
        destination_topic: str,
        payload: dict[str, Any],
        *,
        registry_url: str,
        source_subject: str,
        destination_subject: str,
        expect: dict[str, Any] | None = None,
        correlation_field: str = "correlation_id",
        correlation_id: str | None = None,
        key: str | bytes | None = None,
        bootstrap_servers: str | None = None,
        timeout_ms: int | None = None,
        group_id: str | None = None,
        expected_destination_schema_id: int | None = None,
        headers: dict[str, str] | None = None,
        poll_interval_ms: int = 500,
    ) -> FlowResult:
        from pytest_kafka_contract.avro import _encode_confluent_avro, _decode_confluent_avro
        from pytest_kafka_contract.schema_registry import _get_latest_schema
        from pytest_kafka_contract.avro import validate_avro_record

        bootstrap = bootstrap_servers or self.runtime_config.bootstrap_servers
        timeout = timeout_ms if timeout_ms is not None else self.runtime_config.timeout_ms
        corr_id = correlation_id or str(uuid.uuid4())
        gid = group_id or f"qa-flow-{uuid.uuid4()}"

        payload_to_send = dict(payload)
        if correlation_field not in payload_to_send:
            payload_to_send[correlation_field] = corr_id

        key_to_send: str | bytes | None = key if key is not None else corr_id

        try:
            source_schema_info = _get_latest_schema(registry_url, source_subject)
            destination_schema_info = _get_latest_schema(registry_url, destination_subject)
        except LookupError as exc:
            return _flow_failure(
                code="REGISTRY_SUBJECT_NOT_FOUND",
                message=str(exc),
                source_topic=source_topic,
                destination_topic=destination_topic,
                correlation_id=corr_id,
            )
        except Exception as exc:
            return _flow_failure(
                code="REGISTRY_UNREACHABLE",
                message=f"Schema Registry could not be reached: {exc}",
                source_topic=source_topic,
                destination_topic=destination_topic,
                correlation_id=corr_id,
            )

        try:
            source_bytes = _encode_confluent_avro(
                payload_to_send, source_schema_info["id"], source_schema_info["schema"]
            )
        except Exception as exc:
            return _flow_failure(
                code="AVRO_RECORD_INVALID",
                message=f"Source Avro payload does not match {source_subject}: {exc}",
                source_topic=source_topic,
                destination_topic=destination_topic,
                correlation_id=corr_id,
            )

        encoded_headers = normalize_headers(headers)

        def avro_decoder(raw: bytes) -> tuple[dict[str, Any] | None, Any]:
            try:
                value, schema_id = _decode_confluent_avro(raw, registry_url)
                return value, None
            except Exception as exc:
                issue = ContractIssue(
                    code="FLOW_DESERIALIZATION_FAILED",
                    path="$",
                    message=f"Failed to decode Avro message: {exc}",
                )
                return None, issue

        consumer = KafkaMessageConsumer(bootstrap, gid, auto_offset_reset="earliest")
        try:
            consumer.subscribe([destination_topic])

            producer = KafkaMessageProducer(bootstrap)
            try:
                producer.produce(
                    source_topic,
                    key_to_send,
                    source_bytes,
                    headers=encoded_headers or None,
                )
                producer.flush()
            finally:
                producer.close()

            produced = FlowMessage(
                topic=source_topic,
                key=key_to_send,
                value=payload_to_send,
                raw_value=source_bytes,
                headers=headers or {},
            )

            consumed_raw = consumer.poll_until(
                matcher=lambda v: v.get(correlation_field) == corr_id,
                decoder=avro_decoder,
                timeout_ms=timeout,
                poll_interval_ms=poll_interval_ms,
            )
        finally:
            consumer.close()

        if consumed_raw is None:
            return FlowResult(
                passed=False,
                source_topic=source_topic,
                destination_topic=destination_topic,
                correlation_id=corr_id,
                produced_message=produced,
                issues=[
                    ContractIssue(
                        code="FLOW_TIMEOUT",
                        path="$",
                        message=(
                            f"No Avro message with {correlation_field}={corr_id} found on "
                            f"{destination_topic} within {timeout}ms"
                        ),
                    )
                ],
            )

        try:
            consumed_value, dest_schema_id = _decode_confluent_avro(
                consumed_raw.value, registry_url  # type: ignore[arg-type]
            )
        except Exception as exc:
            return FlowResult(
                passed=False,
                source_topic=source_topic,
                destination_topic=destination_topic,
                correlation_id=corr_id,
                produced_message=produced,
                issues=[
                    ContractIssue(
                        code="FLOW_DESERIALIZATION_FAILED",
                        path="$",
                        message=f"Failed to decode Avro message: {exc}",
                    )
                ],
            )

        consumed_msg = FlowMessage(
            topic=consumed_raw.topic,
            partition=consumed_raw.partition,
            offset=consumed_raw.offset,
            key=consumed_raw.key,
            value=consumed_value,
            raw_value=consumed_raw.value,
            schema_id=dest_schema_id,
        )

        issues: list[ContractIssue] = []

        if expect:
            issues.extend(assert_expected_subset(consumed_value, expect))

        destination_validation = validate_avro_record(
            consumed_value, schema=destination_schema_info["schema"]
        )
        if not destination_validation.passed:
            issues.extend(
                ContractIssue(
                    code="FLOW_CONTRACT_FAILED",
                    path=issue.path,
                    message=issue.message,
                    expected=issue.expected,
                    actual=issue.actual,
                )
                for issue in destination_validation.issues
            )

        if expected_destination_schema_id is not None and dest_schema_id != expected_destination_schema_id:
            issues.append(
                ContractIssue(
                    code="FLOW_SCHEMA_ID_MISMATCH",
                    path="$",
                    message=(
                        f"Expected destination schema_id={expected_destination_schema_id} "
                        f"but got {dest_schema_id}"
                    ),
                    expected=expected_destination_schema_id,
                    actual=dest_schema_id,
                )
            )

        return FlowResult(
            passed=len(issues) == 0,
            source_topic=source_topic,
            destination_topic=destination_topic,
            correlation_id=corr_id,
            produced_message=produced,
            consumed_message=consumed_msg,
            issues=issues,
            metadata={
                "partition": consumed_raw.partition,
                "offset": consumed_raw.offset,
                "destination_schema_id": dest_schema_id,
                "destination_subject": destination_subject,
            },
        )


# ---------------------------------------------------------------------------
# Internal helper
# ---------------------------------------------------------------------------


def _validate_contract(payload: dict[str, Any], contract_path: str) -> list[ContractIssue]:
    from pytest_kafka_contract.contracts import load_contract
    from pytest_kafka_contract.validator import validate_payload

    contract = load_contract(Path(contract_path))
    result = validate_payload(payload, contract)
    return [
        ContractIssue(
            code="FLOW_CONTRACT_FAILED",
            path=issue.path,
            message=issue.message,
            expected=issue.expected,
            actual=issue.actual,
        )
        for issue in result.issues
    ]


def _flow_failure(
    *,
    code: str,
    message: str,
    source_topic: str,
    destination_topic: str,
    correlation_id: str,
) -> FlowResult:
    return FlowResult(
        passed=False,
        source_topic=source_topic,
        destination_topic=destination_topic,
        correlation_id=correlation_id,
        issues=[ContractIssue(code=code, path="$", message=message)],
    )
