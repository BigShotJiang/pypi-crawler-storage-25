from __future__ import annotations

import uuid
from pathlib import Path
from typing import Any

from pytest_kafka_contract.avro import validate_avro_record
from pytest_kafka_contract.config import RuntimeConfig
from pytest_kafka_contract.contracts import load_contract
from pytest_kafka_contract.flow import FlowResult
from pytest_kafka_contract.flow_runner import KafkaFlowRunner
from pytest_kafka_contract.kafka_validation import validate_latest_avro, validate_latest_json
from pytest_kafka_contract.models import Contract
from pytest_kafka_contract.result import ContractResult
from pytest_kafka_contract.schema_registry import validate_schema_registry_subject
from pytest_kafka_contract.validator import validate_payload


class KafkaContractRunner:
    def __init__(self, runtime_config: RuntimeConfig) -> None:
        self.runtime_config = runtime_config
        self.config = runtime_config
        self._flow_runner = KafkaFlowRunner(runtime_config)

    def new_correlation_id(self) -> str:
        return str(uuid.uuid4())

    def load_contract(self, contract_path: str | Path) -> Contract:
        return load_contract(contract_path)

    def validate_payload(self, payload: object, contract_path: str | Path) -> ContractResult:
        contract = load_contract(contract_path)
        if self.runtime_config.strict:
            contract.rules.allow_extra_fields = False
        return validate_payload(payload, contract)

    def validate_avro_record(self, record: dict[str, Any], schema_path: str | Path) -> ContractResult:
        return validate_avro_record(record=record, schema_path=schema_path)

    def validate_schema_registry_subject(
        self,
        registry_url: str,
        subject: str,
        schema_path: str | Path,
        compatibility: str | None = None,
    ) -> ContractResult:
        return validate_schema_registry_subject(
            registry_url=registry_url,
            subject=subject,
            schema_path=schema_path,
            compatibility=compatibility,
        )

    def validate_latest_json(
        self,
        topic: str,
        contract_path: str | Path,
        bootstrap_servers: str | None = None,
        timeout_ms: int | None = None,
        group_id: str | None = None,
        auto_offset_reset: str = "latest",
    ) -> ContractResult:
        return validate_latest_json(
            topic=topic,
            contract_path=contract_path,
            bootstrap_servers=bootstrap_servers or self.runtime_config.bootstrap_servers,
            timeout_ms=timeout_ms or self.runtime_config.timeout_ms,
            group_id=group_id,
            auto_offset_reset=auto_offset_reset,
        )

    def validate_latest_avro(
        self,
        topic: str,
        registry_url: str,
        subject: str,
        bootstrap_servers: str | None = None,
        timeout_ms: int | None = None,
        group_id: str | None = None,
        expected_schema_id: int | None = None,
        auto_offset_reset: str = "latest",
    ) -> ContractResult:
        return validate_latest_avro(
            topic=topic,
            registry_url=registry_url,
            subject=subject,
            bootstrap_servers=bootstrap_servers or self.runtime_config.bootstrap_servers,
            timeout_ms=timeout_ms or self.runtime_config.timeout_ms,
            group_id=group_id,
            expected_schema_id=expected_schema_id,
            auto_offset_reset=auto_offset_reset,
        )

    def validate_latest(
        self,
        topic: str | None = None,
        contract_path: str | Path | None = None,
    ) -> ContractResult:
        if contract_path is None:
            raise ValueError("contract_path is required.")
        contract = load_contract(contract_path)
        return self.validate_latest_json(topic or contract.topic, contract_path)

    # ------------------------------------------------------------------
    # Flow testing methods
    # ------------------------------------------------------------------

    def run_json_flow(
        self,
        source_topic: str,
        destination_topic: str,
        payload: dict[str, Any],
        *,
        expect: dict[str, Any] | None = None,
        contract_path: str | None = None,
        correlation_field: str = "correlation_id",
        correlation_id: str | None = None,
        key: str | bytes | None = None,
        bootstrap_servers: str | None = None,
        timeout_ms: int | None = None,
        group_id: str | None = None,
        headers: dict[str, str] | None = None,
        poll_interval_ms: int = 500,
    ) -> FlowResult:
        return self._flow_runner.run_json_flow(
            source_topic=source_topic,
            destination_topic=destination_topic,
            payload=payload,
            expect=expect,
            contract_path=contract_path,
            correlation_field=correlation_field,
            correlation_id=correlation_id,
            key=key,
            bootstrap_servers=bootstrap_servers,
            timeout_ms=timeout_ms,
            group_id=group_id,
            headers=headers,
            poll_interval_ms=poll_interval_ms,
        )

    def expect_no_json_flow(
        self,
        source_topic: str,
        destination_topic: str,
        payload: dict[str, Any],
        *,
        correlation_field: str = "correlation_id",
        correlation_id: str | None = None,
        key: str | bytes | None = None,
        bootstrap_servers: str | None = None,
        timeout_ms: int | None = None,
        group_id: str | None = None,
        headers: dict[str, str] | None = None,
        poll_interval_ms: int = 500,
    ) -> FlowResult:
        return self._flow_runner.expect_no_json_flow(
            source_topic=source_topic,
            destination_topic=destination_topic,
            payload=payload,
            correlation_field=correlation_field,
            correlation_id=correlation_id,
            key=key,
            bootstrap_servers=bootstrap_servers,
            timeout_ms=timeout_ms,
            group_id=group_id,
            headers=headers,
            poll_interval_ms=poll_interval_ms,
        )

    def run_avro_flow(
        self,
        source_topic: str,
        destination_topic: str,
        payload: dict[str, Any],
        *,
        registry_url: str,
        source_subject: str,
        destination_subject: str,
        expect: dict[str, Any] | None = None,
        correlation_field: str = "correlation_id",
        correlation_id: str | None = None,
        key: str | bytes | None = None,
        bootstrap_servers: str | None = None,
        timeout_ms: int | None = None,
        group_id: str | None = None,
        expected_destination_schema_id: int | None = None,
        headers: dict[str, str] | None = None,
        poll_interval_ms: int = 500,
    ) -> FlowResult:
        return self._flow_runner.run_avro_flow(
            source_topic=source_topic,
            destination_topic=destination_topic,
            payload=payload,
            registry_url=registry_url,
            source_subject=source_subject,
            destination_subject=destination_subject,
            expect=expect,
            correlation_field=correlation_field,
            correlation_id=correlation_id,
            key=key,
            bootstrap_servers=bootstrap_servers,
            timeout_ms=timeout_ms,
            group_id=group_id,
            expected_destination_schema_id=expected_destination_schema_id,
            headers=headers,
            poll_interval_ms=poll_interval_ms,
        )
