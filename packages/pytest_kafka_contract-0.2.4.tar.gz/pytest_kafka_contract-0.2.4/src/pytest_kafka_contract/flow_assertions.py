from __future__ import annotations

from typing import Any

from pytest_kafka_contract.result import ContractIssue


def assert_expected_subset(actual: dict[str, Any], expected: dict[str, Any]) -> list[ContractIssue]:
    """Return issues for every expected field that is absent or mismatched in actual.

    Only the fields present in *expected* are checked.  Extra fields in *actual*
    are silently ignored.  Nested dicts are checked recursively.
    """
    issues: list[ContractIssue] = []
    _check_subset(actual, expected, "$", issues)
    return issues


def _check_subset(
    actual: Any,
    expected: Any,
    path: str,
    issues: list[ContractIssue],
) -> None:
    if isinstance(expected, dict):
        if not isinstance(actual, dict):
            issues.append(
                ContractIssue(
                    code="FLOW_EXPECTATION_FAILED",
                    path=path,
                    message=f"expected object but got {type(actual).__name__}",
                    expected=expected,
                    actual=actual,
                )
            )
            return
        for key, exp_val in expected.items():
            child_path = f"{path}.{key}"
            if key not in actual:
                issues.append(
                    ContractIssue(
                        code="FLOW_EXPECTATION_FAILED",
                        path=child_path,
                        message=f"field '{key}' missing from destination message",
                        expected=exp_val,
                        actual=None,
                    )
                )
            else:
                _check_subset(actual[key], exp_val, child_path, issues)
    else:
        if actual != expected:
            issues.append(
                ContractIssue(
                    code="FLOW_EXPECTATION_FAILED",
                    path=path,
                    message=f"expected {expected!r} but got {actual!r}",
                    expected=expected,
                    actual=actual,
                )
            )
