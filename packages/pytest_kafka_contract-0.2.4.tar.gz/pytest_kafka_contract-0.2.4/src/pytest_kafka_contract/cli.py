from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import typer

from pytest_kafka_contract.avro import validate_avro_record
from pytest_kafka_contract.contracts import load_contract
from pytest_kafka_contract.flow_runner import KafkaFlowRunner
from pytest_kafka_contract.kafka_validation import validate_latest_avro, validate_latest_json
from pytest_kafka_contract.result import ContractResult
from pytest_kafka_contract.schema_registry import validate_schema_registry_subject
from pytest_kafka_contract.validator import validate_payload

app = typer.Typer(help="Validate Kafka JSON and Avro contracts.")

EXAMPLE_CONTRACT = """version: 1
name: order-created-v1
topic: orders.created
message:
  type: object
  required:
    - event_id
    - event_type
    - order
  properties:
    event_id:
      type: string
      nullable: false
    event_type:
      type: string
      const: OrderCreated
      nullable: false
    order:
      type: object
      nullable: false
      required:
        - order_id
        - total
      properties:
        order_id:
          type: string
          nullable: false
        total:
          type: number
          nullable: false
rules:
  allow_extra_fields: false
"""

EXAMPLE_SAMPLE = """{
  "event_id": "evt_123",
  "event_type": "OrderCreated",
  "order": {
    "order_id": "ord_123",
    "total": 19.99
  }
}
"""

EXAMPLE_AVRO_SCHEMA = """{
  "type": "record",
  "name": "OrderCreated",
  "namespace": "com.example.orders",
  "fields": [
    { "name": "event_id", "type": "string" },
    { "name": "order_id", "type": "string" },
    { "name": "total", "type": "double" },
    {
      "name": "currency",
      "type": {
        "type": "enum",
        "name": "Currency",
        "symbols": ["USD", "CAD", "EUR"]
      },
      "default": "USD"
    }
  ]
}
"""

EXAMPLE_AVRO_SAMPLE = """{
  "event_id": "evt_1",
  "order_id": "ord_1",
  "total": 20.0,
  "currency": "USD"
}
"""


@app.command()
def init() -> None:
    """Create example contract, schema, and sample payload files."""
    _write("contracts/order-created.yaml", EXAMPLE_CONTRACT)
    _write("samples/order-created.json", EXAMPLE_SAMPLE)
    _write("schemas/order-created.avsc", EXAMPLE_AVRO_SCHEMA)
    _write("samples/order-created-avro.json", EXAMPLE_AVRO_SAMPLE)


@app.command("validate-file")
def validate_file(contract_path: Path, sample_path: Path) -> None:
    """Validate a JSON file against a YAML contract."""
    contract = load_contract(contract_path)
    payload = json.loads(sample_path.read_text(encoding="utf-8"))
    result = validate_payload(payload, contract)
    _print_result(
        result,
        pass_message="PASS: payload matches contract",
        fail_message="FAIL: payload does not match contract",
    )


@app.command("avro-validate-file")
def avro_validate_file(schema_path: Path, sample_path: Path) -> None:
    """Validate a JSON record file against an Avro .avsc schema."""
    record = json.loads(sample_path.read_text(encoding="utf-8"))
    result = validate_avro_record(record=record, schema_path=schema_path)
    _print_result(
        result,
        pass_message="PASS: record matches Avro schema",
        fail_message="FAIL: record does not match Avro schema",
    )


@app.command("registry-check")
def registry_check(
    registry_url: str = typer.Option(..., "--registry-url"),
    subject: str = typer.Option(..., "--subject"),
    schema_path: Path = typer.Option(..., "--schema"),
    compatibility: str | None = typer.Option(None, "--compatibility"),
) -> None:
    """Validate a Schema Registry subject and optional compatibility."""
    result = validate_schema_registry_subject(registry_url, subject, schema_path, compatibility)
    _print_result(result)


@app.command("kafka-validate-json")
def kafka_validate_json(
    bootstrap_servers: str = typer.Option("localhost:9092", "--bootstrap-servers"),
    topic: str = typer.Option(..., "--topic"),
    contract_path: Path = typer.Option(..., "--contract"),
    timeout_ms: int = typer.Option(10000, "--timeout-ms"),
    auto_offset_reset: str = typer.Option("latest", "--auto-offset-reset"),
) -> None:
    """Consume and validate the latest Kafka JSON message."""
    result = validate_latest_json(
        topic,
        contract_path,
        bootstrap_servers,
        timeout_ms,
        auto_offset_reset=auto_offset_reset,
    )
    _print_result(result)


@app.command("kafka-validate-avro")
def kafka_validate_avro(
    bootstrap_servers: str = typer.Option("localhost:9092", "--bootstrap-servers"),
    registry_url: str = typer.Option(..., "--registry-url"),
    topic: str = typer.Option(..., "--topic"),
    subject: str = typer.Option(..., "--subject"),
    timeout_ms: int = typer.Option(10000, "--timeout-ms"),
    auto_offset_reset: str = typer.Option("latest", "--auto-offset-reset"),
) -> None:
    """Consume and validate the latest Kafka Confluent Avro message."""
    result = validate_latest_avro(
        topic,
        registry_url,
        subject,
        bootstrap_servers,
        timeout_ms,
        auto_offset_reset=auto_offset_reset,
    )
    _print_result(result)


@app.command()
def examples() -> None:
    """Print example pytest usage."""
    typer.echo(
        "def test_order_created(kafka_contract):\n"
        "    result = kafka_contract.validate_payload(\n"
        "        {'event_id': 'evt_1', 'event_type': 'OrderCreated'},\n"
        "        contract_path='contracts/order-created.yaml',\n"
        "    )\n"
        "    assert result.passed, result.issues\n"
    )


@app.command("flow-run")
def flow_run(flow_path: Path) -> None:
    """Run a Kafka flow test defined in a YAML spec file."""
    from pytest_kafka_contract.config import RuntimeConfig
    from pytest_kafka_contract.flow import load_flow_spec

    spec = load_flow_spec(flow_path)

    bootstrap = spec.bootstrap_servers or "localhost:9092"
    timeout = spec.timeout_ms or 10000

    config = RuntimeConfig(
        contract_paths=[],
        bootstrap_servers=bootstrap,
        timeout_ms=timeout,
    )
    runner = KafkaFlowRunner(config)

    if spec.format == "json" and spec.mode == "expect_no_message":
        result = runner.expect_no_json_flow(
            source_topic=spec.source_topic,
            destination_topic=spec.destination_topic,
            payload=spec.payload,
            correlation_field=spec.correlation_field,
            correlation_id=spec.correlation_id,
            bootstrap_servers=bootstrap,
            timeout_ms=timeout,
        )
    elif spec.format == "json":
        result = runner.run_json_flow(
            source_topic=spec.source_topic,
            destination_topic=spec.destination_topic,
            payload=spec.payload,
            expect=spec.expect,
            contract_path=spec.contract_path,
            correlation_field=spec.correlation_field,
            correlation_id=spec.correlation_id,
            bootstrap_servers=bootstrap,
            timeout_ms=timeout,
        )
    elif spec.format == "avro":
        if spec.mode == "expect_no_message":
            raise typer.BadParameter("Avro flow-run does not support mode=expect_no_message yet.")
        if not spec.registry_url:
            raise typer.BadParameter("Avro flow specs require registry_url or schema_registry_url.")
        if not spec.source_subject:
            raise typer.BadParameter("Avro flow specs require source_subject.")
        if not spec.destination_subject:
            raise typer.BadParameter("Avro flow specs require destination_subject.")
        result = runner.run_avro_flow(
            source_topic=spec.source_topic,
            destination_topic=spec.destination_topic,
            payload=spec.payload,
            registry_url=spec.registry_url,
            source_subject=spec.source_subject,
            destination_subject=spec.destination_subject,
            expect=spec.expect,
            correlation_field=spec.correlation_field,
            correlation_id=spec.correlation_id,
            bootstrap_servers=bootstrap,
            timeout_ms=timeout,
        )
    else:
        raise typer.BadParameter(f"Unsupported flow format: {spec.format}. Expected json or avro.")

    _print_flow_result(result, spec.name)


def main(argv: list[str] | None = None) -> int:
    args = sys.argv[1:] if argv is None else argv
    try:
        app(args=args, prog_name="pytest-kafka-contract", standalone_mode=True)
    except SystemExit as exc:
        if exc.code is None:
            return 0
        try:
            return int(exc.code)
        except (TypeError, ValueError):
            return 1
    return 0


def _write(path: str, content: str) -> None:
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(content, encoding="utf-8")
    typer.echo(f"Created {output_path}")


def _print_result(
    result: ContractResult,
    *,
    pass_message: str = "PASS: message matches contract",
    fail_message: str = "FAIL: message does not match contract",
) -> None:
    if result.passed:
        typer.echo(pass_message)
        raise typer.Exit(0)
    typer.echo(fail_message)
    for issue in result.issues:
        typer.echo(f"{issue.code} {issue.path} {issue.message}")
        if issue.expected is not None:
            typer.echo(f"  Expected: {issue.expected}")
        if issue.actual is not None:
            typer.echo(f"  Actual: {issue.actual}")
    raise typer.Exit(1)


def _print_flow_result(result: Any, flow_name: str) -> None:
    from pytest_kafka_contract.flow import FlowResult

    assert isinstance(result, FlowResult)
    status = "PASS" if result.passed else "FAIL"
    typer.echo(f"{status}: {flow_name}")
    typer.echo(f"  source_topic={result.source_topic}")
    typer.echo(f"  destination_topic={result.destination_topic}")
    typer.echo(f"  correlation_id={result.correlation_id}")
    if result.consumed_message:
        typer.echo(
            f"  consumed offset={result.consumed_message.offset} "
            f"partition={result.consumed_message.partition}"
        )
    if result.issues:
        typer.echo("  Issues:")
        for issue in result.issues:
            typer.echo(f"    {issue.code} at {issue.path}: {issue.message}")
            if issue.expected is not None:
                typer.echo(f"      Expected: {issue.expected}")
            if issue.actual is not None:
                typer.echo(f"      Actual:   {issue.actual}")
    if result.passed:
        raise typer.Exit(0)
    raise typer.Exit(1)


if __name__ == "__main__":
    raise SystemExit(main())
