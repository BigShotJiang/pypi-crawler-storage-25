from __future__ import annotations

import json
from pathlib import Path

from pytest_kafka_contract.avro import (
    decode_confluent_avro_message,
    extract_confluent_schema_id,
    validate_avro_record,
)
from pytest_kafka_contract.contracts import load_contract
from pytest_kafka_contract.kafka_client import KafkaConsumerConfig, KafkaContractConsumer, KafkaMessage
from pytest_kafka_contract.result import ContractIssue, ContractResult
from pytest_kafka_contract.schema_registry import SchemaRegistryClient
from pytest_kafka_contract.validator import validate_payload


def validate_latest_json(
    topic: str,
    contract_path: str | Path,
    bootstrap_servers: str = "localhost:9092",
    timeout_ms: int = 10000,
    group_id: str | None = None,
    auto_offset_reset: str = "latest",
) -> ContractResult:
    message = _consume_latest(topic, bootstrap_servers, timeout_ms, group_id, auto_offset_reset)
    if message is None:
        return _kafka_failure("KAFKA_NO_MESSAGE", "No Kafka message was received.", topic=topic, format="json")
    metadata = _message_metadata(message, "json")
    if message.value is None:
        return _kafka_failure(
            "KAFKA_MESSAGE_INVALID",
            "Kafka message value is empty.",
            **metadata,
        )
    try:
        payload = json.loads(message.value.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        return _kafka_failure(
            "KAFKA_DESERIALIZATION_FAILED",
            "Could not decode Kafka message as JSON.",
            actual=str(exc),
            **metadata,
        )
    contract = load_contract(contract_path)
    result = validate_payload(payload, contract)
    if result.issues:
        return ContractResult.fail_result(result.issues, **metadata)
    return ContractResult.pass_result(**metadata)


def validate_latest_avro(
    topic: str,
    registry_url: str,
    subject: str,
    bootstrap_servers: str = "localhost:9092",
    timeout_ms: int = 10000,
    group_id: str | None = None,
    expected_schema_id: int | None = None,
    auto_offset_reset: str = "latest",
) -> ContractResult:
    message = _consume_latest(topic, bootstrap_servers, timeout_ms, group_id, auto_offset_reset)
    if message is None:
        return _kafka_failure("KAFKA_NO_MESSAGE", "No Kafka message was received.", topic=topic, format="avro")
    metadata = _message_metadata(message, "avro", subject=subject, registry_url=registry_url)
    if message.value is None:
        return _kafka_failure("KAFKA_MESSAGE_INVALID", "Kafka message value is empty.", **metadata)

    try:
        schema_id = extract_confluent_schema_id(message.value)
    except ValueError as exc:
        return _kafka_failure(
            "KAFKA_SCHEMA_ID_MISSING",
            "Could not extract Confluent Avro schema id.",
            actual=str(exc),
            **metadata,
        )
    metadata["schema_id"] = schema_id
    if expected_schema_id is not None and schema_id != expected_schema_id:
        return _kafka_failure(
            "KAFKA_SCHEMA_ID_MISMATCH",
            "Kafka message schema id did not match expected schema id.",
            expected=expected_schema_id,
            actual=schema_id,
            **metadata,
        )

    try:
        schema = SchemaRegistryClient(registry_url).get_schema_by_id(schema_id)
    except LookupError as exc:
        return _kafka_failure(
            "REGISTRY_SCHEMA_ID_NOT_FOUND",
            "Schema id was not found in Schema Registry.",
            actual=str(exc),
            **metadata,
        )
    except Exception as exc:
        return _kafka_failure(
            "REGISTRY_UNREACHABLE",
            "Schema Registry could not be reached.",
            actual=str(exc),
            **metadata,
        )

    decode_result = decode_confluent_avro_message(message.value, schema)
    if not decode_result.passed:
        return ContractResult.fail_result(decode_result.issues, **metadata)
    record = decode_result.metadata["record"]
    metadata["record"] = record
    validation_result = validate_avro_record(record, schema=schema)
    if not validation_result.passed:
        return ContractResult.fail_result(validation_result.issues, **metadata)
    return ContractResult.pass_result(**metadata)


def _consume_latest(
    topic: str,
    bootstrap_servers: str,
    timeout_ms: int,
    group_id: str | None,
    auto_offset_reset: str,
) -> KafkaMessage | None:
    consumer = KafkaContractConsumer(
        KafkaConsumerConfig(
            bootstrap_servers=bootstrap_servers,
            group_id=group_id,
            auto_offset_reset=auto_offset_reset,
            timeout_ms=timeout_ms,
        )
    )
    try:
        return consumer.consume_latest(topic)
    finally:
        consumer.close()


def _message_metadata(message: KafkaMessage, format_name: str, **extra: object) -> dict[str, object]:
    return {
        "topic": message.topic,
        "partition": message.partition,
        "offset": message.offset,
        "format": format_name,
        **extra,
    }


def _kafka_failure(
    code: str,
    message: str,
    *,
    expected: object | None = None,
    actual: object | None = None,
    **metadata: object,
) -> ContractResult:
    return ContractResult.fail_result(
        [ContractIssue(code=code, path="$", message=message, expected=expected, actual=actual)],
        **metadata,
    )
