class KafkaContractError(Exception):
    """Base error for pytest-kafka-contract."""


class ContractLoadError(KafkaContractError):
    """Raised when a contract file cannot be loaded or parsed."""


class ContractValidationError(KafkaContractError):
    """Raised when validation cannot be attempted."""


class KafkaConnectionError(KafkaContractError):
    """Raised when Kafka cannot be reached."""


class KafkaMessageTimeoutError(KafkaContractError):
    """Raised when no Kafka message is received before timeout."""
