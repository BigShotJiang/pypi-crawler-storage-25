from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from pytest_kafka_contract.result import ContractIssue


@dataclass
class FlowMessage:
    topic: str
    partition: int | None = None
    offset: int | None = None
    key: str | bytes | None = None
    value: dict[str, Any] | None = None
    headers: dict[str, str] = field(default_factory=dict)
    raw_value: bytes | None = None
    schema_id: int | None = None


@dataclass
class FlowResult:
    passed: bool
    flow_name: str | None = None
    source_topic: str | None = None
    destination_topic: str | None = None
    correlation_id: str | None = None
    produced_message: FlowMessage | None = None
    consumed_message: FlowMessage | None = None
    issues: list[ContractIssue] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def __bool__(self) -> bool:
        return self.passed


@dataclass
class FlowSpec:
    name: str
    format: str
    source_topic: str
    destination_topic: str
    payload: dict[str, Any]
    expect: dict[str, Any] | None = None
    contract_path: str | None = None
    bootstrap_servers: str | None = None
    timeout_ms: int | None = None
    correlation_field: str = "correlation_id"
    correlation_id: str | None = None
    mode: str = "expect_message"
    registry_url: str | None = None
    source_subject: str | None = None
    destination_subject: str | None = None
    source_schema_path: str | None = None
    destination_schema_path: str | None = None


def load_flow_spec(path: str | Path) -> FlowSpec:
    raw = Path(path).read_text(encoding="utf-8")
    loaded = yaml.safe_load(raw)
    if not isinstance(loaded, dict):
        raise ValueError(f"FLOW_INVALID_CONFIG at $: flow spec must be a mapping (file: {path})")
    data: dict[str, Any] = loaded

    _require_field(data, "name", path)
    _require_field(data, "format", path)
    _require_field(data, "source_topic", path)
    _require_field(data, "destination_topic", path)
    _require_field(data, "payload", path)

    return FlowSpec(
        name=data["name"],
        format=data["format"],
        source_topic=data["source_topic"],
        destination_topic=data["destination_topic"],
        payload=data["payload"],
        expect=data.get("expect"),
        contract_path=data.get("contract_path"),
        bootstrap_servers=data.get("bootstrap_servers"),
        timeout_ms=data.get("timeout_ms"),
        correlation_field=data.get("correlation_field", "correlation_id"),
        correlation_id=data.get("correlation_id"),
        mode=data.get("mode", "expect_message"),
        registry_url=data.get("registry_url") or data.get("schema_registry_url"),
        source_subject=data.get("source_subject"),
        destination_subject=data.get("destination_subject"),
        source_schema_path=data.get("source_schema_path"),
        destination_schema_path=data.get("destination_schema_path"),
    )


def _require_field(data: dict[str, Any], field_name: str, path: str | Path) -> None:
    if field_name not in data or data[field_name] is None:
        raise ValueError(
            f"FLOW_INVALID_CONFIG at $.{field_name}: {field_name} is required (file: {path})"
        )
