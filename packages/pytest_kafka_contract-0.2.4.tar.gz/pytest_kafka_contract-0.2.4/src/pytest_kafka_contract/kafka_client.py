from __future__ import annotations

import json
import uuid
from dataclasses import dataclass
from typing import Any

from pytest_kafka_contract.config import RuntimeConfig
from pytest_kafka_contract.errors import ContractValidationError, KafkaConnectionError, KafkaMessageTimeoutError
from pytest_kafka_contract.utils import require_confluent_kafka


@dataclass
class KafkaMessage:
    topic: str
    partition: int
    offset: int
    key: bytes | None
    value: bytes | None
    headers: list[tuple[str, bytes | None]] | None


@dataclass
class KafkaConsumerConfig:
    bootstrap_servers: str
    group_id: str | None = None
    auto_offset_reset: str = "latest"
    timeout_ms: int = 10000
    max_messages: int = 10


class KafkaContractConsumer:
    def __init__(self, config: KafkaConsumerConfig) -> None:
        self.config = config
        confluent_kafka = require_confluent_kafka()
        self._consumer = confluent_kafka.Consumer(
            {
                "bootstrap.servers": config.bootstrap_servers,
                "group.id": config.group_id or f"pytest-kafka-contract-{uuid.uuid4()}",
                "auto.offset.reset": config.auto_offset_reset,
                "enable.auto.commit": False,
            }
        )

    def consume_latest(self, topic: str) -> KafkaMessage | None:
        messages = self.consume_many(topic, max_messages=self.config.max_messages)
        return messages[-1] if messages else None

    def consume_many(self, topic: str, max_messages: int = 10) -> list[KafkaMessage]:
        self._consumer.subscribe([topic])
        messages: list[KafkaMessage] = []
        deadline_polls = max(1, max_messages)
        for _ in range(deadline_polls):
            message = self._consumer.poll(self.config.timeout_ms / 1000)
            if message is None:
                break
            if message.error():
                raise KafkaConnectionError(str(message.error()))
            messages.append(
                KafkaMessage(
                    topic=message.topic(),
                    partition=message.partition(),
                    offset=message.offset(),
                    key=message.key(),
                    value=message.value(),
                    headers=message.headers(),
                )
            )
            if len(messages) >= max_messages:
                break
        return messages

    def close(self) -> None:
        self._consumer.close()


def consume_latest_json(topic: str, config: RuntimeConfig) -> dict[str, Any]:
    consumer = KafkaContractConsumer(
        KafkaConsumerConfig(
            bootstrap_servers=config.bootstrap_servers,
            timeout_ms=config.timeout_ms,
        )
    )
    try:
        message = consumer.consume_latest(topic)
    finally:
        consumer.close()

    if message is None:
        raise KafkaMessageTimeoutError(
            f"No Kafka message received for topic '{topic}' within {config.timeout_ms} ms."
        )
    if message.value is None:
        raise ContractValidationError(f"Kafka message on topic '{topic}' has no value.")
    try:
        payload = json.loads(message.value.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ContractValidationError(f"Kafka message on topic '{topic}' is not valid JSON.") from exc
    if not isinstance(payload, dict):
        raise ContractValidationError(f"Kafka message on topic '{topic}' must be a JSON object.")
    return payload


# ---------------------------------------------------------------------------
# Flow-level producer / consumer abstractions
# ---------------------------------------------------------------------------


@dataclass
class KafkaProducedMetadata:
    topic: str
    key: str | bytes | None


class KafkaMessageProducer:
    """Thin wrapper around confluent_kafka.Producer for flow tests."""

    def __init__(self, bootstrap_servers: str) -> None:
        confluent_kafka = require_confluent_kafka()
        self._producer = confluent_kafka.Producer(
            {"bootstrap.servers": bootstrap_servers}
        )

    def produce(
        self,
        topic: str,
        key: bytes | str | None,
        value: bytes,
        headers: list[tuple[str, bytes]] | None = None,
    ) -> None:
        kwargs: dict[str, Any] = {"topic": topic, "key": key, "value": value}
        if headers:
            kwargs["headers"] = headers
        self._producer.produce(**kwargs)

    def flush(self, timeout_seconds: float = 10.0) -> None:
        self._producer.flush(timeout_seconds)

    def close(self) -> None:
        self.flush()


class KafkaMessageConsumer:
    """Thin wrapper around confluent_kafka.Consumer for flow tests."""

    def __init__(
        self,
        bootstrap_servers: str,
        group_id: str,
        auto_offset_reset: str = "latest",
    ) -> None:
        confluent_kafka = require_confluent_kafka()
        self._consumer = confluent_kafka.Consumer(
            {
                "bootstrap.servers": bootstrap_servers,
                "group.id": group_id,
                "auto.offset.reset": auto_offset_reset,
                "enable.auto.commit": False,
            }
        )

    def subscribe(self, topics: list[str]) -> None:
        self._consumer.subscribe(topics)

    def poll_until(
        self,
        matcher: Any,
        decoder: Any,
        timeout_ms: int,
        poll_interval_ms: int = 500,
    ) -> KafkaMessage | None:
        """Poll until *matcher(decoded_value)* returns True or *timeout_ms* elapses.

        *decoder* receives raw ``bytes`` and returns ``(value, issue_or_None)``.
        Non-matching messages are skipped silently.
        Kafka errors raise ``KafkaConnectionError``.
        Returns the matching ``KafkaMessage`` or ``None`` on timeout.
        """
        import time

        deadline = time.monotonic() + timeout_ms / 1000.0
        poll_seconds = poll_interval_ms / 1000.0

        while time.monotonic() < deadline:
            msg = self._consumer.poll(poll_seconds)
            if msg is None:
                continue
            if msg.error():
                raise KafkaConnectionError(str(msg.error()))
            raw = msg.value()
            if raw is None:
                continue
            value, _issue = decoder(raw)
            if value is None:
                continue
            if matcher(value):
                return KafkaMessage(
                    topic=msg.topic(),
                    partition=msg.partition(),
                    offset=msg.offset(),
                    key=msg.key(),
                    value=raw,
                    headers=msg.headers(),
                )
        return None

    def close(self) -> None:
        self._consumer.close()
