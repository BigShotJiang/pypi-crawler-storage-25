from __future__ import annotations

from datetime import datetime
from typing import Any

from pytest_kafka_contract.models import Contract, ContractRules, FieldRule
from pytest_kafka_contract.result import ContractIssue, ContractResult


def validate_payload(payload: object, contract: Contract) -> ContractResult:
    issues: list[ContractIssue] = []
    _validate_value(payload, contract.message, "$", contract.rules, issues)
    if issues:
        return ContractResult.fail_result(
            issues,
            contract_name=contract.name,
            topic=contract.topic,
            format="json",
        )
    return ContractResult.pass_result(
        contract_name=contract.name,
        topic=contract.topic,
        format="json",
    )


def _validate_value(
    value: Any,
    rule: FieldRule,
    path: str,
    contract_rules: ContractRules,
    issues: list[ContractIssue],
) -> None:
    if value is None:
        if not rule.nullable and contract_rules.fail_on_null_required:
            issues.append(
                ContractIssue(
                    code="NULL_NOT_ALLOWED",
                    path=path,
                    message=f"Field '{path}' cannot be null.",
                    expected=rule.type,
                    actual="null",
                )
            )
        return

    if contract_rules.fail_on_type_mismatch and not _matches_type(value, rule.type):
        issues.append(
            ContractIssue(
                code="TYPE_MISMATCH",
                path=path,
                message=f"Field '{path}' expected type '{rule.type}' but got '{_type_name(value)}'.",
                expected=rule.type,
                actual=_type_name(value),
            )
        )
        return

    if rule.const is not None and value != rule.const:
        issues.append(
            ContractIssue(
                code="CONST_MISMATCH",
                path=path,
                message=f"Field '{path}' expected constant {rule.const!r}.",
                expected=repr(rule.const),
                actual=repr(value),
            )
        )

    if rule.enum is not None and value not in rule.enum:
        issues.append(
            ContractIssue(
                code="ENUM_MISMATCH",
                path=path,
                message=f"Field '{path}' must be one of {rule.enum!r}.",
                expected=", ".join(repr(item) for item in rule.enum),
                actual=repr(value),
            )
        )

    if rule.format == "datetime" and isinstance(value, str) and not _is_datetime(value):
        issues.append(
            ContractIssue(
                code="INVALID_DATETIME",
                path=path,
                message=f"Field '{path}' must be a valid datetime string.",
                expected="datetime",
                actual=value,
            )
        )

    if isinstance(value, dict) and rule.type == "object":
        _validate_object(value, rule, path, contract_rules, issues)
    if isinstance(value, list) and rule.type == "array" and rule.items is not None:
        for index, item in enumerate(value):
            _validate_value(item, rule.items, f"{path}[{index}]", contract_rules, issues)


def _validate_object(
    value: dict[str, Any],
    rule: FieldRule,
    path: str,
    contract_rules: ContractRules,
    issues: list[ContractIssue],
) -> None:
    if contract_rules.fail_on_missing_required:
        for field_name in rule.required:
            if field_name not in value:
                field_rule = rule.properties.get(field_name)
                expected = field_rule.type if field_rule is not None else None
                missing_path = _join_path(path, field_name)
                issues.append(
                    ContractIssue(
                        code="MISSING_REQUIRED_FIELD",
                        path=missing_path,
                        message=f"Required field '{missing_path}' is missing.",
                        expected=expected,
                        actual="missing",
                    )
                )

    if not contract_rules.allow_extra_fields:
        for field_name in value:
            if field_name not in rule.properties:
                extra_path = _join_path(path, field_name)
                issues.append(
                    ContractIssue(
                        code="EXTRA_FIELD",
                        path=extra_path,
                        message=f"Field '{extra_path}' is not defined in the contract.",
                        expected=None,
                        actual=_type_name(value[field_name]),
                    )
                )

    for field_name, field_rule in rule.properties.items():
        if field_name in value:
            _validate_value(value[field_name], field_rule, _join_path(path, field_name), contract_rules, issues)


def _matches_type(value: Any, expected_type: str) -> bool:
    if expected_type == "string":
        return isinstance(value, str)
    if expected_type == "number":
        return (isinstance(value, int) or isinstance(value, float)) and not isinstance(value, bool)
    if expected_type == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected_type == "boolean":
        return isinstance(value, bool)
    if expected_type == "object":
        return isinstance(value, dict)
    if expected_type == "array":
        return isinstance(value, list)
    if expected_type == "null":
        return value is None
    return False


def _type_name(value: Any) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, str):
        return "string"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "number"
    if isinstance(value, dict):
        return "object"
    if isinstance(value, list):
        return "array"
    return type(value).__name__


def _join_path(path: str, field_name: str) -> str:
    return f"{path}.{field_name}" if path != "$" else f"$.{field_name}"


def _is_datetime(value: str) -> bool:
    try:
        datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    return True
