# pytest-kafka-contract — Developer README

This file is for contributors and maintainers. It covers local setup, running tests, the integration test harness, quality gates, and release workflow.

The **user-facing README** for PyPI is `README.md`. Do not add developer setup, internal test counts, or roadmap items to `README.md`.

---

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
```

---

## Running Tests

### Unit and plugin tests (no Kafka required)

```bash
pytest tests/unit tests/plugin -q
```

### Full local suite (skips integration)

```bash
pytest -q
```

Integration tests are automatically skipped unless `PKCT_RUN_INTEGRATION=1` is set.

### Integration tests (real Kafka required)

Start the integration stack (Redpanda + Schema Registry):

```bash
docker compose -f docker-compose.integration.yml up -d
```

Run integration tests:

```bash
PKCT_RUN_INTEGRATION=1 \
PKCT_BOOTSTRAP_SERVERS=localhost:19092 \
PKCT_SCHEMA_REGISTRY_URL=http://localhost:8081 \
pytest tests/integration -q -s
```

Or use the convenience script:

```bash
./scripts/run-integration.sh
```

Stop services:

```bash
docker compose -f docker-compose.integration.yml down -v
```

---

## Test Coverage by Area

| Area | Location | Notes |
|---|---|---|
| Flow models (`FlowResult`, `FlowMessage`, `FlowSpec`, `load_flow_spec`) | `tests/unit/test_flow_models.py` | No Kafka |
| Subset assertions | `tests/unit/test_flow_assertions.py` | No Kafka |
| JSON serializers | `tests/unit/test_flow_serializers.py` | No Kafka |
| Kafka client wrappers (`KafkaMessageProducer`, `KafkaMessageConsumer`) | `tests/unit/test_kafka_flow_client.py` | Mocked |
| JSON flow runner (`run_json_flow`, `expect_no_json_flow`) | `tests/unit/test_json_flow_runner.py` | Mocked |
| Fixture API surface | `tests/plugin/test_kafka_contract_flow_fixture.py` | Mocked |
| CLI `flow-run` command | `tests/unit/test_cli_flow_run.py` | Mocked |
| Real Kafka JSON flow | `tests/integration/test_kafka_json_flow.py` | Requires Kafka |
| Contract validation (JSON) | `tests/unit/test_json_validator.py` | No Kafka |
| Contract validation (Avro) | `tests/unit/test_avro_validator.py` | No Kafka |
| Schema Registry client | `tests/unit/test_schema_registry_client.py` | Mocked |
| Kafka validation logic | `tests/unit/test_kafka_validation.py` | Mocked |
| CLI contract commands | `tests/unit/test_cli.py` | Mocked |
| Reports | `tests/unit/test_reports.py` | No Kafka |
| Plugin discovery | `tests/plugin/test_plugin_discovery.py` | No Kafka |
| Pytest options | `tests/plugin/test_pytest_options.py` | No Kafka |
| e2e CLI workflow | `tests/e2e/test_cli_workflow.py` | No Kafka |
| Wheel install workflow | `tests/e2e/test_wheel_install_workflow.py` | No Kafka |
| Real Kafka JSON validation | `tests/integration/test_kafka_json_validation.py` | Requires Kafka |
| Real Kafka Avro validation | `tests/integration/test_kafka_avro_validation.py` | Requires Kafka |
| Schema Registry integration | `tests/integration/test_schema_registry_integration.py` | Requires Kafka |

---

## Known Coverage Gaps (intentional)

The following paths are not unit-tested because they require a real Schema Registry and real Avro wire-format messages:

- `run_avro_flow` — Avro flow integration (covered conceptually, no unit tests for the full round-trip)
- `_encode_confluent_avro` / `_decode_confluent_avro` — tested only in integration suite

---

## Quality Checks

```bash
ruff check .
mypy src
```

---

## Build and Publish

Build the distribution:

```bash
python -m build
python -m twine check dist/*
```

Publish to PyPI (maintainers only):

```bash
python -m twine upload dist/*
```

See `RELEASE.md` and `PATCH-RELEASE.md` for the full release checklist.

---

## Project Structure

```txt
src/pytest_kafka_contract/
    __init__.py          – public exports
    plugin.py            – pytest plugin entry point
    runner.py            – KafkaContractRunner fixture API
    flow_runner.py       – KafkaFlowRunner (flow orchestration)
    flow.py              – FlowMessage, FlowResult, FlowSpec, load_flow_spec
    flow_assertions.py   – assert_expected_subset
    flow_serializers.py  – encode_json, decode_json, normalize_headers
    contracts.py         – load_contract
    validator.py         – JSON payload validator
    avro.py              – Avro validation + Confluent wire-format helpers
    schema_registry.py   – Schema Registry client
    kafka_client.py      – KafkaConsumer, KafkaMessageProducer, KafkaMessageConsumer
    kafka_validation.py  – validate_latest_json / validate_latest_avro
    cli.py               – Typer CLI (kafka-contract)
    config.py            – RuntimeConfig
    models.py            – Pydantic contract models
    result.py            – ContractResult, ContractIssue
    reports.py           – Markdown + JSON report generation
    errors.py            – KafkaConnectionError
    utils.py             – require_confluent_kafka, require_fastavro, etc.
```

---

## Roadmap

Planned improvements:

- Protobuf support
- Avro flow unit test coverage (mock Schema Registry)
- Kafka header validation
- Kafka key validation
- JSON Schema export
- GitHub Actions workflow examples
- More built-in contract examples

---

## Release History

See `CHANGELOG.md`.
