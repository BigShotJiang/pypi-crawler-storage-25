from pytest_kafka_contract.models import Contract, ContractRules, FieldRule
from pytest_kafka_contract.validator import validate_payload


def array_contract() -> Contract:
    return Contract(
        version=1,
        name="c",
        topic="t",
        message=FieldRule(
            type="object",
            properties={
                "items": FieldRule(
                    type="array",
                    items=FieldRule(
                        type="object",
                        required=["sku"],
                        properties={"sku": FieldRule(type="string")},
                    ),
                )
            },
        ),
        rules=ContractRules(),
    )


def test_validates_array_item_type():
    result = validate_payload({"items": ["bad"]}, array_contract())

    assert result.issues[0].code == "TYPE_MISMATCH"
    assert result.issues[0].path == "$.items[0]"


def test_validates_object_inside_array():
    result = validate_payload({"items": [{"sku": "ABC"}]}, array_contract())

    assert result.passed is True


def test_reports_path_inside_array_object():
    result = validate_payload({"items": [{}]}, array_contract())

    assert result.issues[0].code == "MISSING_REQUIRED_FIELD"
    assert result.issues[0].path == "$.items[0].sku"


def test_handles_empty_arrays():
    assert validate_payload({"items": []}, array_contract()).passed
