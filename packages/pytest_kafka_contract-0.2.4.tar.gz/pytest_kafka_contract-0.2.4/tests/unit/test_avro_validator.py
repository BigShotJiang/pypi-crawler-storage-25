import pytest

from pytest_kafka_contract.avro import validate_avro_record


def write_schema(tmp_path, text: str):
    path = tmp_path / "order.avsc"
    path.write_text(text, encoding="utf-8")
    return path


def basic_schema() -> str:
    return """
{
  "type": "record",
  "name": "OrderCreated",
  "fields": [
    {"name": "event_id", "type": "string"},
    {"name": "total", "type": "double"},
    {"name": "currency", "type": {"type": "enum", "name": "Currency", "symbols": ["USD", "CAD"]}, "default": "USD"}
  ]
}
"""


def test_valid_avro_record_passes(tmp_path):
    result = validate_avro_record(
        record={"event_id": "evt_1", "total": 20.0, "currency": "USD"},
        schema_path=write_schema(tmp_path, basic_schema()),
    )

    assert result.passed
    assert result.issues == []


def test_missing_required_field_fails(tmp_path):
    result = validate_avro_record({"total": 20.0}, schema_path=write_schema(tmp_path, basic_schema()))

    assert not result.passed
    assert result.issues[0].code == "AVRO_RECORD_INVALID"
    assert "Missing required field" in str(result.issues[0].actual)


def test_wrong_type_fails(tmp_path):
    result = validate_avro_record(
        {"event_id": "evt_1", "total": "20.0"},
        schema_path=write_schema(tmp_path, basic_schema()),
    )

    assert not result.passed
    assert result.issues[0].code == "AVRO_RECORD_INVALID"


def test_bad_enum_fails(tmp_path):
    result = validate_avro_record(
        {"event_id": "evt_1", "total": 20.0, "currency": "EUR"},
        schema_path=write_schema(tmp_path, basic_schema()),
    )

    assert not result.passed
    assert result.issues[0].code == "AVRO_RECORD_INVALID"


def test_nullable_union_passes_with_none_and_value(tmp_path):
    schema = """
{
  "type": "record",
  "name": "Customer",
  "fields": [{"name": "customer_id", "type": ["null", "string"], "default": null}]
}
"""
    path = write_schema(tmp_path, schema)

    assert validate_avro_record({"customer_id": None}, schema_path=path).passed
    assert validate_avro_record({"customer_id": "cust_1"}, schema_path=path).passed


def test_non_nullable_field_fails_with_none(tmp_path):
    result = validate_avro_record(
        {"event_id": None, "total": 20.0},
        schema_path=write_schema(tmp_path, basic_schema()),
    )

    assert not result.passed
    assert result.issues[0].code == "AVRO_RECORD_INVALID"


def test_field_default_works(tmp_path):
    result = validate_avro_record(
        {"event_id": "evt_1", "total": 20.0},
        schema_path=write_schema(tmp_path, basic_schema()),
    )

    assert result.passed


def test_invalid_schema_fails(tmp_path):
    result = validate_avro_record({"x": "y"}, schema={"type": "not-real"})

    assert not result.passed
    assert result.issues[0].code == "AVRO_SCHEMA_INVALID"


def test_missing_schema_file_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        validate_avro_record({"x": "y"}, schema_path=tmp_path / "missing.avsc")


def test_missing_schema_args_raise():
    with pytest.raises(ValueError):
        validate_avro_record({"x": "y"})
