from pytest_kafka_contract.models import Contract, ContractRules, FieldRule
from pytest_kafka_contract.validator import validate_payload


def test_nested_object_type_mismatch_uses_nested_path():
    contract = Contract(
        version=1,
        name="c",
        topic="t",
        message=FieldRule(
            type="object",
            properties={
                "order": FieldRule(
                    type="object",
                    properties={"total": FieldRule(type="number")},
                )
            },
        ),
        rules=ContractRules(),
    )

    result = validate_payload({"order": {"total": "19.99"}}, contract)

    assert result.issues[0].code == "TYPE_MISMATCH"
    assert result.issues[0].path == "$.order.total"
