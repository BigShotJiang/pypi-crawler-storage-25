import json

from pytest_kafka_contract.schema_registry import (
    SchemaRegistryClient,
    validate_schema_registry_subject,
)
from pytest_kafka_contract.utils import require_httpx


SCHEMA = {"type": "record", "name": "OrderCreated", "fields": []}


def make_client(handler):
    httpx = require_httpx()
    return SchemaRegistryClient(
        "http://registry",
        transport=httpx.MockTransport(handler),
    )


def latest_response(schema=SCHEMA):
    return {
        "subject": "orders.created-value",
        "id": 1,
        "version": 1,
        "schema": json.dumps(schema),
    }


def test_get_latest_schema_success():
    httpx = require_httpx()
    client = make_client(lambda request: httpx.Response(200, json=latest_response()))

    result = client.get_latest_schema("orders.created-value")

    assert result["id"] == 1
    assert result["schema"] == SCHEMA


def test_subject_exists_true_and_false():
    httpx = require_httpx()
    ok_client = make_client(lambda request: httpx.Response(200, json=latest_response()))
    missing_client = make_client(lambda request: httpx.Response(404, json={"error_code": 40401}))

    assert ok_client.subject_exists("orders.created-value") is True
    assert missing_client.subject_exists("orders.created-value") is False


def test_get_schema_by_id_success():
    httpx = require_httpx()
    client = make_client(lambda request: httpx.Response(200, json={"schema": json.dumps(SCHEMA)}))

    assert client.get_schema_by_id(1) == SCHEMA


def test_get_schema_by_id_not_found():
    httpx = require_httpx()
    client = make_client(lambda request: httpx.Response(404, json={"error_code": 40403}))

    try:
        client.get_schema_by_id(404)
    except LookupError as exc:
        assert "schema id" in str(exc)
    else:
        raise AssertionError("expected LookupError")


def test_compatibility_true_and_false():
    httpx = require_httpx()
    compatible = make_client(lambda request: httpx.Response(200, json={"is_compatible": True}))
    incompatible = make_client(lambda request: httpx.Response(200, json={"is_compatible": False}))

    assert compatible.check_compatibility("subject", SCHEMA) is True
    assert incompatible.check_compatibility("subject", SCHEMA) is False


def test_high_level_registry_validation_passes(tmp_path):
    schema_path = tmp_path / "schema.avsc"
    schema_path.write_text(json.dumps(SCHEMA), encoding="utf-8")
    httpx = require_httpx()

    def handler(request):
        if "compatibility" in str(request.url):
            return httpx.Response(200, json={"is_compatible": True})
        return httpx.Response(200, json=latest_response())

    result = validate_schema_registry_subject(
        "http://registry",
        "orders.created-value",
        schema_path,
        compatibility="BACKWARD",
        client=make_client(handler),
    )

    assert result.passed
    assert result.metadata["schema_id"] == 1


def test_high_level_registry_unreachable_returns_issue(tmp_path):
    schema_path = tmp_path / "schema.avsc"
    schema_path.write_text(json.dumps(SCHEMA), encoding="utf-8")

    def handler(request):
        raise OSError("down")

    result = validate_schema_registry_subject(
        "http://registry",
        "orders.created-value",
        schema_path,
        client=make_client(handler),
    )

    assert not result.passed
    assert result.issues[0].code == "REGISTRY_UNREACHABLE"


def test_high_level_missing_subject_returns_issue(tmp_path):
    schema_path = tmp_path / "schema.avsc"
    schema_path.write_text(json.dumps(SCHEMA), encoding="utf-8")
    httpx = require_httpx()

    result = validate_schema_registry_subject(
        "http://registry",
        "orders.created-value",
        schema_path,
        client=make_client(lambda request: httpx.Response(404)),
    )

    assert not result.passed
    assert result.issues[0].code == "REGISTRY_SUBJECT_NOT_FOUND"


def test_high_level_schema_mismatch_returns_issue(tmp_path):
    schema_path = tmp_path / "schema.avsc"
    schema_path.write_text(json.dumps(SCHEMA), encoding="utf-8")
    httpx = require_httpx()
    registry_schema = {"type": "record", "name": "Other", "fields": []}

    result = validate_schema_registry_subject(
        "http://registry",
        "orders.created-value",
        schema_path,
        client=make_client(lambda request: httpx.Response(200, json=latest_response(registry_schema))),
    )

    assert not result.passed
    assert result.issues[0].code == "REGISTRY_SCHEMA_MISMATCH"


def test_high_level_compatibility_failed_returns_issue(tmp_path):
    schema_path = tmp_path / "schema.avsc"
    schema_path.write_text(json.dumps(SCHEMA), encoding="utf-8")
    httpx = require_httpx()

    def handler(request):
        if "compatibility" in str(request.url):
            return httpx.Response(200, json={"is_compatible": False})
        return httpx.Response(200, json=latest_response())

    result = validate_schema_registry_subject(
        "http://registry",
        "orders.created-value",
        schema_path,
        compatibility="BACKWARD",
        client=make_client(handler),
    )

    assert not result.passed
    assert result.issues[0].code == "REGISTRY_COMPATIBILITY_FAILED"
