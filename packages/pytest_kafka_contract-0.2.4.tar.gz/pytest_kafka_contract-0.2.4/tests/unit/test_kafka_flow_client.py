from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from pytest_kafka_contract.flow_serializers import decode_json


# ---------------------------------------------------------------------------
# Helpers / fakes
# ---------------------------------------------------------------------------


def _make_msg(value: bytes, topic: str = "dest.topic", partition: int = 0, offset: int = 1) -> MagicMock:
    msg = MagicMock()
    msg.error.return_value = None
    msg.value.return_value = value
    msg.key.return_value = b"key"
    msg.topic.return_value = topic
    msg.partition.return_value = partition
    msg.offset.return_value = offset
    msg.headers.return_value = []
    return msg


def _json_bytes(d: dict) -> bytes:
    return json.dumps(d).encode("utf-8")


# ---------------------------------------------------------------------------
# KafkaMessageProducer
# ---------------------------------------------------------------------------


class TestKafkaMessageProducer:
    @patch("pytest_kafka_contract.kafka_client.require_confluent_kafka")
    def test_produce_calls_underlying_producer(self, mock_require):
        fake_ck = MagicMock()
        fake_producer = MagicMock()
        fake_ck.Producer.return_value = fake_producer
        mock_require.return_value = fake_ck

        from pytest_kafka_contract.kafka_client import KafkaMessageProducer

        producer = KafkaMessageProducer("localhost:9092")
        producer.produce("my.topic", "key-1", b"value-bytes")

        fake_producer.produce.assert_called_once_with(
            topic="my.topic", key="key-1", value=b"value-bytes"
        )

    @patch("pytest_kafka_contract.kafka_client.require_confluent_kafka")
    def test_flush_is_called_on_close(self, mock_require):
        fake_ck = MagicMock()
        fake_producer = MagicMock()
        fake_ck.Producer.return_value = fake_producer
        mock_require.return_value = fake_ck

        from pytest_kafka_contract.kafka_client import KafkaMessageProducer

        producer = KafkaMessageProducer("localhost:9092")
        producer.close()
        fake_producer.flush.assert_called()

    @patch("pytest_kafka_contract.kafka_client.require_confluent_kafka")
    def test_produce_passes_headers_when_provided(self, mock_require):
        fake_ck = MagicMock()
        fake_producer = MagicMock()
        fake_ck.Producer.return_value = fake_producer
        mock_require.return_value = fake_ck

        from pytest_kafka_contract.kafka_client import KafkaMessageProducer

        producer = KafkaMessageProducer("localhost:9092")
        headers = [("X-Trace", b"trace-1")]
        producer.produce("my.topic", "key", b"val", headers=headers)
        fake_producer.produce.assert_called_once_with(
            topic="my.topic", key="key", value=b"val", headers=headers
        )


# ---------------------------------------------------------------------------
# KafkaMessageConsumer
# ---------------------------------------------------------------------------


class TestKafkaMessageConsumer:
    @patch("pytest_kafka_contract.kafka_client.require_confluent_kafka")
    def test_consumer_closes_after_poll_until(self, mock_require):
        fake_ck = MagicMock()
        fake_consumer = MagicMock()
        fake_ck.Consumer.return_value = fake_consumer
        mock_require.return_value = fake_ck

        matching_msg = _make_msg(_json_bytes({"correlation_id": "abc"}))
        fake_consumer.poll.side_effect = [matching_msg]

        from pytest_kafka_contract.kafka_client import KafkaMessageConsumer

        consumer = KafkaMessageConsumer("localhost:9092", "test-group")
        consumer.subscribe(["dest.topic"])
        result = consumer.poll_until(
            matcher=lambda v: v.get("correlation_id") == "abc",
            decoder=decode_json,
            timeout_ms=5000,
        )
        consumer.close()
        assert result is not None
        fake_consumer.close.assert_called_once()

    @patch("pytest_kafka_contract.kafka_client.require_confluent_kafka")
    def test_poll_until_returns_matching_message(self, mock_require):
        fake_ck = MagicMock()
        fake_consumer = MagicMock()
        fake_ck.Consumer.return_value = fake_consumer
        mock_require.return_value = fake_ck

        non_match = _make_msg(_json_bytes({"correlation_id": "other"}))
        match = _make_msg(_json_bytes({"correlation_id": "abc"}), partition=0, offset=5)
        fake_consumer.poll.side_effect = [non_match, match]

        from pytest_kafka_contract.kafka_client import KafkaMessageConsumer

        consumer = KafkaMessageConsumer("localhost:9092", "test-group")
        consumer.subscribe(["dest.topic"])
        result = consumer.poll_until(
            matcher=lambda v: v.get("correlation_id") == "abc",
            decoder=decode_json,
            timeout_ms=5000,
        )
        assert result is not None
        assert result.offset == 5

    @patch("pytest_kafka_contract.kafka_client.require_confluent_kafka")
    def test_poll_until_ignores_non_matching_messages(self, mock_require):
        fake_ck = MagicMock()
        fake_consumer = MagicMock()
        fake_ck.Consumer.return_value = fake_consumer
        mock_require.return_value = fake_ck

        # First non-matching, then matching
        non_match = _make_msg(_json_bytes({"correlation_id": "other"}))
        match = _make_msg(_json_bytes({"correlation_id": "target"}))
        fake_consumer.poll.side_effect = [non_match, match]

        from pytest_kafka_contract.kafka_client import KafkaMessageConsumer

        consumer = KafkaMessageConsumer("localhost:9092", "test-group")
        consumer.subscribe(["dest.topic"])
        result = consumer.poll_until(
            matcher=lambda v: v.get("correlation_id") == "target",
            decoder=decode_json,
            timeout_ms=5000,
        )
        assert result is not None

    @patch("pytest_kafka_contract.kafka_client.require_confluent_kafka")
    def test_poll_until_returns_none_on_timeout(self, mock_require):
        fake_ck = MagicMock()
        fake_consumer = MagicMock()
        fake_ck.Consumer.return_value = fake_consumer
        mock_require.return_value = fake_ck

        # Only None polls – simulate timeout quickly with very short timeout
        fake_consumer.poll.return_value = None

        from pytest_kafka_contract.kafka_client import KafkaMessageConsumer

        consumer = KafkaMessageConsumer("localhost:9092", "test-group")
        consumer.subscribe(["dest.topic"])
        result = consumer.poll_until(
            matcher=lambda v: False,
            decoder=decode_json,
            timeout_ms=100,  # very short
            poll_interval_ms=50,
        )
        assert result is None

    @patch("pytest_kafka_contract.kafka_client.require_confluent_kafka")
    def test_kafka_error_raises_connection_error(self, mock_require):
        fake_ck = MagicMock()
        fake_consumer = MagicMock()
        fake_ck.Consumer.return_value = fake_consumer
        mock_require.return_value = fake_ck

        error_msg = MagicMock()
        error_msg.error.return_value = "broker disconnected"

        fake_consumer.poll.return_value = error_msg

        from pytest_kafka_contract.errors import KafkaConnectionError
        from pytest_kafka_contract.kafka_client import KafkaMessageConsumer

        consumer = KafkaMessageConsumer("localhost:9092", "test-group")
        consumer.subscribe(["dest.topic"])
        with pytest.raises(KafkaConnectionError):
            consumer.poll_until(
                matcher=lambda v: True,
                decoder=decode_json,
                timeout_ms=5000,
            )
