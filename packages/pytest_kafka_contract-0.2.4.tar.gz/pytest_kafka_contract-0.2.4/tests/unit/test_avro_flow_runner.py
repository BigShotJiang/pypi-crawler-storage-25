from __future__ import annotations

from unittest.mock import patch

from pytest_kafka_contract.config import RuntimeConfig
from pytest_kafka_contract.flow_runner import KafkaFlowRunner


def _runner() -> KafkaFlowRunner:
    return KafkaFlowRunner(
        RuntimeConfig(contract_paths=[], bootstrap_servers="localhost:9092", timeout_ms=5000)
    )


def test_run_avro_flow_returns_clean_failure_for_missing_source_subject() -> None:
    with patch(
        "pytest_kafka_contract.schema_registry._get_latest_schema",
        side_effect=LookupError("Schema Registry subject not found: missing-value"),
    ):
        result = _runner().run_avro_flow(
            source_topic="src.orders",
            destination_topic="dest.orders",
            payload={"correlation_id": "cid-1", "order_id": "ord_1", "status": "PAID"},
            registry_url="http://registry",
            source_subject="missing-value",
            destination_subject="dest.orders-value",
            correlation_id="cid-1",
            timeout_ms=100,
        )

    assert not result.passed
    assert result.issues[0].code == "REGISTRY_SUBJECT_NOT_FOUND"
    assert "missing-value" in result.issues[0].message


def test_run_avro_flow_returns_clean_failure_for_invalid_source_payload() -> None:
    source_schema = {
        "id": 1,
        "schema": {
            "type": "record",
            "name": "OrderEvent",
            "fields": [{"name": "order_id", "type": "string"}],
        },
    }
    destination_schema = {
        "id": 2,
        "schema": {
            "type": "record",
            "name": "OrderEvent",
            "fields": [{"name": "order_id", "type": "string"}],
        },
    }

    with patch(
        "pytest_kafka_contract.schema_registry._get_latest_schema",
        side_effect=[source_schema, destination_schema],
    ):
        result = _runner().run_avro_flow(
            source_topic="src.orders",
            destination_topic="dest.orders",
            payload={"correlation_id": "cid-1"},
            registry_url="http://registry",
            source_subject="src.orders-value",
            destination_subject="dest.orders-value",
            correlation_id="cid-1",
            timeout_ms=100,
        )

    assert not result.passed
    assert result.issues[0].code == "AVRO_RECORD_INVALID"
