from __future__ import annotations

import json

from pytest_kafka_contract.flow_serializers import decode_json, encode_json, normalize_headers


class TestEncodeJson:
    def test_encodes_dict_to_bytes(self):
        result = encode_json({"status": "PAID"})
        assert isinstance(result, bytes)

    def test_encoded_bytes_are_valid_json(self):
        result = encode_json({"order_id": "ord_1", "amount": 49.99})
        parsed = json.loads(result.decode("utf-8"))
        assert parsed == {"order_id": "ord_1", "amount": 49.99}


class TestDecodeJson:
    def test_decodes_valid_json_bytes(self):
        raw = json.dumps({"status": "PAID"}).encode("utf-8")
        value, issue = decode_json(raw)
        assert issue is None
        assert value == {"status": "PAID"}

    def test_returns_issue_for_invalid_json(self):
        raw = b"not-json"
        value, issue = decode_json(raw)
        assert value is None
        assert issue is not None
        assert issue.code == "FLOW_DESERIALIZATION_FAILED"

    def test_returns_issue_for_non_object_json(self):
        raw = json.dumps([1, 2, 3]).encode("utf-8")
        value, issue = decode_json(raw)
        assert value is None
        assert issue is not None
        assert issue.code == "FLOW_DESERIALIZATION_FAILED"

    def test_returns_issue_for_bad_utf8(self):
        raw = b"\xff\xfe"
        value, issue = decode_json(raw)
        assert value is None
        assert issue is not None
        assert issue.code == "FLOW_DESERIALIZATION_FAILED"

    def test_roundtrip(self):
        original = {"order_id": "ord_1", "status": "PAID", "nested": {"amount": 9.99}}
        encoded = encode_json(original)
        decoded, issue = decode_json(encoded)
        assert issue is None
        assert decoded == original


class TestNormalizeHeaders:
    def test_returns_empty_list_for_none(self):
        assert normalize_headers(None) == []

    def test_returns_empty_list_for_empty_dict(self):
        assert normalize_headers({}) == []

    def test_encodes_header_values_to_bytes(self):
        result = normalize_headers({"X-Source": "test"})
        assert result == [("X-Source", b"test")]

    def test_handles_multiple_headers(self):
        result = normalize_headers({"a": "1", "b": "2"})
        assert len(result) == 2
        assert ("a", b"1") in result
        assert ("b", b"2") in result
