from pytest_kafka_contract.models import Contract, ContractRules, FieldRule
from pytest_kafka_contract.validator import validate_payload


def contract_for(rule: FieldRule) -> Contract:
    return Contract(version=1, name="c", topic="t", message=rule, rules=ContractRules())


def test_const_passes_exact_match():
    assert validate_payload("OrderCreated", contract_for(FieldRule(type="string", const="OrderCreated"))).passed


def test_const_fails_wrong_value():
    result = validate_payload("OrderUpdated", contract_for(FieldRule(type="string", const="OrderCreated")))

    assert result.issues[0].code == "CONST_MISMATCH"


def test_enum_passes_allowed_value():
    assert validate_payload("USD", contract_for(FieldRule(type="string", enum=["USD", "CAD"]))).passed


def test_enum_fails_disallowed_value():
    result = validate_payload("EUR", contract_for(FieldRule(type="string", enum=["USD", "CAD"])))

    assert result.issues[0].code == "ENUM_MISMATCH"


def test_datetime_format_fails_invalid_value():
    result = validate_payload("not-a-date", contract_for(FieldRule(type="string", format="datetime")))

    assert result.issues[0].code == "INVALID_DATETIME"
