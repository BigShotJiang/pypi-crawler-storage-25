from __future__ import annotations

import textwrap
from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from pytest_kafka_contract.cli import app
from pytest_kafka_contract.flow import FlowResult


runner = CliRunner()


def _write_spec(tmp_path: Path, content: str) -> Path:
    path = tmp_path / "flow.yaml"
    path.write_text(textwrap.dedent(content), encoding="utf-8")
    return path


def _passing_result() -> FlowResult:
    return FlowResult(
        passed=True,
        source_topic="src.orders",
        destination_topic="dest.orders",
        correlation_id="cid-1",
    )


def test_flow_spec_format_json_calls_run_json_flow(tmp_path: Path) -> None:
    spec_path = _write_spec(
        tmp_path,
        """\
        name: json-flow
        format: json
        source_topic: src.orders
        destination_topic: dest.orders
        payload:
          status: PAID
        """,
    )

    with patch("pytest_kafka_contract.cli.KafkaFlowRunner") as runner_cls:
        fake_runner = MagicMock()
        fake_runner.run_json_flow.return_value = _passing_result()
        runner_cls.return_value = fake_runner

        result = runner.invoke(app, ["flow-run", str(spec_path)])

    assert result.exit_code == 0
    fake_runner.run_json_flow.assert_called_once()
    fake_runner.run_avro_flow.assert_not_called()


def test_flow_spec_format_avro_calls_run_avro_flow(tmp_path: Path) -> None:
    spec_path = _write_spec(
        tmp_path,
        """\
        name: avro-flow
        format: avro
        schema_registry_url: http://localhost:8081
        source_topic: src.orders
        destination_topic: dest.orders
        source_subject: src.orders-value
        destination_subject: dest.orders-value
        payload:
          status: PAID
        expect:
          status: PAID
        """,
    )

    with patch("pytest_kafka_contract.cli.KafkaFlowRunner") as runner_cls:
        fake_runner = MagicMock()
        fake_runner.run_avro_flow.return_value = _passing_result()
        runner_cls.return_value = fake_runner

        result = runner.invoke(app, ["flow-run", str(spec_path)])

    assert result.exit_code == 0
    fake_runner.run_avro_flow.assert_called_once()
    fake_runner.run_json_flow.assert_not_called()
    assert fake_runner.run_avro_flow.call_args.kwargs["registry_url"] == "http://localhost:8081"


def test_flow_spec_bad_format_gives_clear_error(tmp_path: Path) -> None:
    spec_path = _write_spec(
        tmp_path,
        """\
        name: bad-flow
        format: protobuf
        source_topic: src.orders
        destination_topic: dest.orders
        payload:
          status: PAID
        """,
    )

    result = runner.invoke(app, ["flow-run", str(spec_path)])

    assert result.exit_code != 0
    assert "Unsupported flow format: protobuf" in result.output


def test_flow_spec_avro_requires_registry_url(tmp_path: Path) -> None:
    spec_path = _write_spec(
        tmp_path,
        """\
        name: avro-flow
        format: avro
        source_topic: src.orders
        destination_topic: dest.orders
        source_subject: src.orders-value
        destination_subject: dest.orders-value
        payload:
          status: PAID
        """,
    )

    result = runner.invoke(app, ["flow-run", str(spec_path)])

    assert result.exit_code != 0
    assert "Avro flow specs require registry_url or schema_registry_url" in result.output


def test_flow_spec_avro_requires_subjects(tmp_path: Path) -> None:
    spec_path = _write_spec(
        tmp_path,
        """\
        name: avro-flow
        format: avro
        registry_url: http://localhost:8081
        source_topic: src.orders
        destination_topic: dest.orders
        payload:
          status: PAID
        """,
    )

    result = runner.invoke(app, ["flow-run", str(spec_path)])

    assert result.exit_code != 0
    assert "Avro flow specs require source_subject" in result.output
