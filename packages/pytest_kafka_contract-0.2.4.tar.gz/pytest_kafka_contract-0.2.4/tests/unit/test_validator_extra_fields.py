from pytest_kafka_contract.models import Contract, ContractRules, FieldRule
from pytest_kafka_contract.validator import validate_payload


def contract(allow_extra_fields: bool) -> Contract:
    return Contract(
        version=1,
        name="c",
        topic="t",
        message=FieldRule(
            type="object",
            properties={
                "known": FieldRule(type="string"),
                "child": FieldRule(
                    type="object",
                    properties={"name": FieldRule(type="string")},
                ),
            },
        ),
        rules=ContractRules(allow_extra_fields=allow_extra_fields),
    )


def test_allows_extra_fields_by_default():
    assert validate_payload({"unknown": True}, contract(True)).passed


def test_fails_extra_field_when_disallowed():
    result = validate_payload({"known": "x", "unknown": True}, contract(False))

    assert result.passed is False
    assert result.issues[0].code == "EXTRA_FIELD"
    assert result.issues[0].path == "$.unknown"


def test_fails_nested_extra_field_when_disallowed():
    result = validate_payload({"child": {"name": "x", "debug": True}}, contract(False))

    assert result.issues[0].code == "EXTRA_FIELD"
    assert result.issues[0].path == "$.child.debug"
