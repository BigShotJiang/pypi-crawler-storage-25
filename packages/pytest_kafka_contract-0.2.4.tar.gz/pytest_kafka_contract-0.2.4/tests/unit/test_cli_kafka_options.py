"""Unit tests proving CLI kafka commands expose expected parameters."""
from __future__ import annotations

import inspect

from typer.testing import CliRunner

from pytest_kafka_contract.cli import (
    app,
    flow_run,
    kafka_validate_avro,
    kafka_validate_json,
)

runner = CliRunner()


class TestKafkaValidateJsonCommand:
    def test_help_exit_code_zero(self):
        result = runner.invoke(app, ["kafka-validate-json", "--help"])
        assert result.exit_code == 0, result.output

    def test_expected_parameters_exist(self):
        params = inspect.signature(kafka_validate_json).parameters
        assert "bootstrap_servers" in params
        assert "topic" in params
        assert "contract_path" in params
        assert "timeout_ms" in params
        assert "auto_offset_reset" in params


class TestKafkaValidateAvroCommand:
    def test_help_exit_code_zero(self):
        result = runner.invoke(app, ["kafka-validate-avro", "--help"])
        assert result.exit_code == 0, result.output

    def test_expected_parameters_exist(self):
        params = inspect.signature(kafka_validate_avro).parameters
        assert "bootstrap_servers" in params
        assert "registry_url" in params
        assert "topic" in params
        assert "subject" in params
        assert "timeout_ms" in params
        assert "auto_offset_reset" in params


class TestFlowRunCommand:
    def test_help_exit_code_zero(self):
        result = runner.invoke(app, ["flow-run", "--help"])
        assert result.exit_code == 0, result.output

    def test_flow_path_parameter_exists(self):
        params = inspect.signature(flow_run).parameters
        assert "flow_path" in params


class TestRootHelp:
    def test_root_help_exit_zero(self):
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0, result.output

