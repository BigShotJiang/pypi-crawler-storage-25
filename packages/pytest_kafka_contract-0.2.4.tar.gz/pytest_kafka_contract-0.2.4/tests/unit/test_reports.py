import json

from pytest_kafka_contract.models import ValidationIssue, ValidationResult
from pytest_kafka_contract.reports import build_report, render_markdown_report, write_json_report


def failed_result() -> ValidationResult:
    return ValidationResult(
        contract_name="order|created",
        topic="orders.created",
        passed=False,
        issues=[
            ValidationIssue(
                code="MISSING_REQUIRED_FIELD",
                path="$.order.customer_id",
                expected="string",
                actual="missing",
                message="Required field missing | details",
            )
        ],
    )


def test_json_report_serializes_summary(tmp_path):
    path = tmp_path / "report.json"

    write_json_report([failed_result()], path)

    report = json.loads(path.read_text(encoding="utf-8"))
    assert report["summary"] == {"total": 1, "passed": 0, "failed": 1}


def test_markdown_report_contains_failed_contract_section():
    markdown = render_markdown_report([failed_result()])

    assert "## Failed Checks" in markdown
    assert "MISSING_REQUIRED_FIELD" in markdown


def test_markdown_escapes_pipe_characters():
    markdown = render_markdown_report([failed_result()])

    assert "order\\|created" in markdown
    assert "Required field missing \\| details" in markdown


def test_empty_results_create_valid_summary():
    assert build_report([])["summary"] == {"total": 0, "passed": 0, "failed": 0}
