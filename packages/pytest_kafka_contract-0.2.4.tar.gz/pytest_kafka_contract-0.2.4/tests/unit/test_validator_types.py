import pytest

from pytest_kafka_contract.models import Contract, ContractRules, FieldRule
from pytest_kafka_contract.validator import validate_payload


def contract_for(rule: FieldRule) -> Contract:
    return Contract(version=1, name="c", topic="t", message=rule, rules=ContractRules())


@pytest.mark.parametrize(
    ("field_type", "value"),
    [
        ("string", "x"),
        ("number", 1),
        ("number", 1.2),
        ("integer", 1),
        ("boolean", True),
        ("object", {}),
        ("array", []),
        ("null", None),
    ],
)
def test_type_passes(field_type, value):
    assert validate_payload(value, contract_for(FieldRule(type=field_type))).passed is True


@pytest.mark.parametrize(
    ("field_type", "value"),
    [
        ("number", True),
        ("integer", False),
        ("string", 1),
        ("boolean", 1),
        ("object", []),
        ("array", {}),
    ],
)
def test_type_mismatch(field_type, value):
    result = validate_payload(value, contract_for(FieldRule(type=field_type)))

    assert result.passed is False
    assert result.issues[0].code == "TYPE_MISMATCH"


def test_nullable_false_rejects_null():
    result = validate_payload(None, contract_for(FieldRule(type="string", nullable=False)))

    assert result.passed is False
    assert result.issues[0].code == "NULL_NOT_ALLOWED"
