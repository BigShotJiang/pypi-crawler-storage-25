from pytest_kafka_contract.result import ContractIssue, ContractResult


def test_pass_result_has_no_issues_and_metadata():
    result = ContractResult.pass_result(format="json")

    assert result.passed is True
    assert result.issues == []
    assert result.metadata == {"format": "json"}


def test_fail_result_stores_issues_and_metadata():
    issue = ContractIssue(code="TYPE_MISMATCH", path="$.total", message="wrong type")

    result = ContractResult.fail_result([issue], topic="orders.created")

    assert result.passed is False
    assert result.issues == [issue]
    assert result.metadata == {"topic": "orders.created"}
