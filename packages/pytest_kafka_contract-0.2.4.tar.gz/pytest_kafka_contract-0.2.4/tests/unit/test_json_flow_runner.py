from __future__ import annotations

import json
from unittest.mock import MagicMock, patch


from pytest_kafka_contract.config import RuntimeConfig
from pytest_kafka_contract.kafka_client import KafkaMessage


def _make_runtime() -> RuntimeConfig:
    return RuntimeConfig(
        contract_paths=[],
        bootstrap_servers="localhost:9092",
        timeout_ms=5000,
    )


def _json_msg(
    d: dict,
    partition: int = 0,
    offset: int = 1,
    topic: str = "dest.topic",
) -> KafkaMessage:
    return KafkaMessage(
        topic=topic,
        partition=partition,
        offset=offset,
        key=b"key",
        value=json.dumps(d).encode("utf-8"),
        headers=[],
    )


# ---------------------------------------------------------------------------
# Helpers to patch producer/consumer in flow_runner
# ---------------------------------------------------------------------------


def _make_fake_producer():
    producer = MagicMock()
    producer.produce = MagicMock()
    producer.flush = MagicMock()
    producer.close = MagicMock()
    return producer


def _make_fake_consumer(poll_return=None):
    consumer = MagicMock()
    consumer.subscribe = MagicMock()
    consumer.poll_until = MagicMock(return_value=poll_return)
    consumer.close = MagicMock()
    return consumer


class TestRunJsonFlow:
    def _run(
        self,
        fake_producer,
        fake_consumer,
        *,
        correlation_id="fixed-id",
        payload=None,
        expect=None,
        contract_path=None,
        timeout_ms=5000,
    ):
        from pytest_kafka_contract.flow_runner import KafkaFlowRunner

        runner = KafkaFlowRunner(_make_runtime())

        with (
            patch(
                "pytest_kafka_contract.flow_runner.KafkaMessageProducer",
                return_value=fake_producer,
            ),
            patch(
                "pytest_kafka_contract.flow_runner.KafkaMessageConsumer",
                return_value=fake_consumer,
            ),
        ):
            return runner.run_json_flow(
                source_topic="src.topic",
                destination_topic="dest.topic",
                payload=payload or {"status": "PAID"},
                correlation_id=correlation_id,
                expect=expect,
                contract_path=contract_path,
                timeout_ms=timeout_ms,
            )

    # ------------------------------------------------------------------

    def test_generates_correlation_id_when_not_provided(self):
        from pytest_kafka_contract.flow_runner import KafkaFlowRunner

        runner = KafkaFlowRunner(_make_runtime())
        captured_payloads = []

        fake_producer = _make_fake_producer()
        fake_consumer = _make_fake_consumer(poll_return=None)

        def capturing_produce(topic, key, value, headers=None):
            captured_payloads.append(json.loads(value.decode("utf-8")))

        fake_producer.produce.side_effect = capturing_produce

        with (
            patch("pytest_kafka_contract.flow_runner.KafkaMessageProducer", return_value=fake_producer),
            patch("pytest_kafka_contract.flow_runner.KafkaMessageConsumer", return_value=fake_consumer),
        ):
            runner.run_json_flow(
                source_topic="src.topic",
                destination_topic="dest.topic",
                payload={"status": "PAID"},
                timeout_ms=100,
            )

        assert len(captured_payloads) == 1
        assert "correlation_id" in captured_payloads[0]

    def test_injects_correlation_id_into_payload(self):
        captured = []
        fake_producer = _make_fake_producer()
        fake_consumer = _make_fake_consumer(poll_return=None)

        def capturing_produce(topic, key, value, headers=None):
            captured.append(json.loads(value.decode("utf-8")))

        fake_producer.produce.side_effect = capturing_produce

        self._run(fake_producer, fake_consumer, correlation_id="my-corr-id")

        assert captured[0].get("correlation_id") == "my-corr-id"

    def test_uses_correlation_id_as_key(self):
        keys = []
        fake_producer = _make_fake_producer()
        fake_consumer = _make_fake_consumer(poll_return=None)

        def capturing_produce(topic, key, value, headers=None):
            keys.append(key)

        fake_producer.produce.side_effect = capturing_produce

        self._run(fake_producer, fake_consumer, correlation_id="my-key")
        assert keys[0] == "my-key"

    def test_subscribes_before_produce(self):
        call_order = []
        fake_producer = _make_fake_producer()
        fake_consumer = _make_fake_consumer(poll_return=None)

        fake_consumer.subscribe.side_effect = lambda *a, **kw: call_order.append("subscribe")
        fake_producer.produce.side_effect = lambda *a, **kw: call_order.append("produce")

        self._run(fake_producer, fake_consumer)

        assert call_order.index("subscribe") < call_order.index("produce")

    def test_produces_to_source_topic(self):
        topics = []
        fake_producer = _make_fake_producer()
        fake_consumer = _make_fake_consumer(poll_return=None)

        def capturing_produce(topic, key, value, headers=None):
            topics.append(topic)

        fake_producer.produce.side_effect = capturing_produce

        self._run(fake_producer, fake_consumer)
        assert topics[0] == "src.topic"

    def test_passes_when_expected_subset_matches(self):
        matched_msg = _json_msg(
            {"status": "PAID", "order_id": "ord_1", "correlation_id": "fixed-id"}
        )
        fake_producer = _make_fake_producer()
        fake_consumer = _make_fake_consumer(poll_return=matched_msg)

        result = self._run(
            fake_producer,
            fake_consumer,
            expect={"status": "PAID"},
        )
        assert result.passed is True
        assert result.issues == []

    def test_fails_flow_timeout_when_no_message_found(self):
        fake_producer = _make_fake_producer()
        fake_consumer = _make_fake_consumer(poll_return=None)

        result = self._run(fake_producer, fake_consumer, timeout_ms=100)
        assert result.passed is False
        assert any(i.code == "FLOW_TIMEOUT" for i in result.issues)

    def test_fails_expectation_when_field_mismatch(self):
        matched_msg = _json_msg(
            {"status": "PENDING", "correlation_id": "fixed-id"}
        )
        fake_producer = _make_fake_producer()
        fake_consumer = _make_fake_consumer(poll_return=matched_msg)

        result = self._run(
            fake_producer,
            fake_consumer,
            expect={"status": "PAID"},
        )
        assert result.passed is False
        assert any(i.code == "FLOW_EXPECTATION_FAILED" for i in result.issues)

    def test_runs_contract_validation_when_contract_path_provided(self, tmp_path):
        contract_path = tmp_path / "test.yaml"
        contract_path.write_text(
            "version: 1\n"
            "name: test-contract\n"
            "topic: dest.topic\n"
            "message:\n"
            "  type: object\n"
            "  required:\n"
            "    - required_field\n"
            "  properties:\n"
            "    required_field:\n"
            "      type: string\n",
            encoding="utf-8",
        )

        matched_msg = _json_msg({"correlation_id": "fixed-id"})  # missing required_field
        fake_producer = _make_fake_producer()
        fake_consumer = _make_fake_consumer(poll_return=matched_msg)

        result = self._run(
            fake_producer,
            fake_consumer,
            contract_path=str(contract_path),
        )
        assert result.passed is False
        assert any(i.code == "FLOW_CONTRACT_FAILED" for i in result.issues)

    def test_skips_contract_validation_when_not_provided(self):
        matched_msg = _json_msg({"status": "PAID", "correlation_id": "fixed-id"})
        fake_producer = _make_fake_producer()
        fake_consumer = _make_fake_consumer(poll_return=matched_msg)

        result = self._run(fake_producer, fake_consumer, expect={"status": "PAID"})
        assert result.passed is True

    def test_consumer_always_closed(self):
        fake_producer = _make_fake_producer()
        fake_consumer = _make_fake_consumer(poll_return=None)

        self._run(fake_producer, fake_consumer)
        fake_consumer.close.assert_called_once()


class TestExpectNoJsonFlow:
    def _run_no_flow(self, fake_producer, fake_consumer, *, correlation_id="fixed-id"):
        from pytest_kafka_contract.flow_runner import KafkaFlowRunner

        runner = KafkaFlowRunner(_make_runtime())

        with (
            patch(
                "pytest_kafka_contract.flow_runner.KafkaMessageProducer",
                return_value=fake_producer,
            ),
            patch(
                "pytest_kafka_contract.flow_runner.KafkaMessageConsumer",
                return_value=fake_consumer,
            ),
        ):
            return runner.expect_no_json_flow(
                source_topic="src.topic",
                destination_topic="dest.topic",
                payload={"status": "CANCELLED"},
                correlation_id=correlation_id,
                timeout_ms=100,
            )

    def test_passes_when_no_message_appears(self):
        fake_producer = _make_fake_producer()
        fake_consumer = _make_fake_consumer(poll_return=None)

        result = self._run_no_flow(fake_producer, fake_consumer)
        assert result.passed is True

    def test_fails_when_unexpected_message_arrives(self):
        matched_msg = _json_msg({"status": "CANCELLED", "correlation_id": "fixed-id"})
        fake_producer = _make_fake_producer()
        fake_consumer = _make_fake_consumer(poll_return=matched_msg)

        result = self._run_no_flow(fake_producer, fake_consumer)
        assert result.passed is False
        assert any(i.code == "FLOW_UNEXPECTED_MESSAGE" for i in result.issues)

    def test_consumer_always_closed(self):
        fake_producer = _make_fake_producer()
        fake_consumer = _make_fake_consumer(poll_return=None)

        self._run_no_flow(fake_producer, fake_consumer)
        fake_consumer.close.assert_called_once()
