from pytest_kafka_contract.cli import main


def test_cli_init_creates_example_files(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)

    assert main(["init"]) == 0

    assert (tmp_path / "contracts/order-created.yaml").exists()
    assert (tmp_path / "samples/order-created.json").exists()
    assert (tmp_path / "schemas/order-created.avsc").exists()
    assert (tmp_path / "samples/order-created-avro.json").exists()


def test_cli_main_uses_sys_argv_when_called_from_console_script(monkeypatch, capsys):
    monkeypatch.setattr("sys.argv", ["pytest-kafka-contract", "examples"])

    assert main() == 0
    assert "def test_order_created" in capsys.readouterr().out


def test_cli_main_treats_none_system_exit_code_as_success(monkeypatch):
    def fake_app(**kwargs):
        raise SystemExit(None)

    monkeypatch.setattr("pytest_kafka_contract.cli.app", fake_app)

    assert main(["examples"]) == 0


def test_cli_main_treats_numeric_string_system_exit_code_as_success(monkeypatch):
    def fake_app(**kwargs):
        raise SystemExit("0")

    monkeypatch.setattr("pytest_kafka_contract.cli.app", fake_app)

    assert main(["examples"]) == 0


def test_cli_validate_file_passes(tmp_path):
    contract_path = tmp_path / "contract.yaml"
    sample_path = tmp_path / "sample.json"
    contract_path.write_text(
        """
version: 1
name: c
topic: t
message:
  type: object
  required: [id]
  properties:
    id:
      type: string
""",
        encoding="utf-8",
    )
    sample_path.write_text('{"id": "evt_1"}', encoding="utf-8")

    assert main(["validate-file", str(contract_path), str(sample_path)]) == 0


def test_cli_validate_file_fails(tmp_path):
    contract_path = tmp_path / "contract.yaml"
    sample_path = tmp_path / "sample.json"
    contract_path.write_text(
        """
version: 1
name: c
topic: t
message:
  type: object
  required: [id]
  properties:
    id:
      type: string
""",
        encoding="utf-8",
    )
    sample_path.write_text("{}", encoding="utf-8")

    assert main(["validate-file", str(contract_path), str(sample_path)]) == 1


def test_cli_avro_validate_file_passes(tmp_path):
    schema_path = tmp_path / "schema.avsc"
    sample_path = tmp_path / "sample.json"
    schema_path.write_text(
        """
{
  "type": "record",
  "name": "OrderCreated",
  "fields": [{"name": "event_id", "type": "string"}]
}
""",
        encoding="utf-8",
    )
    sample_path.write_text('{"event_id": "evt_1"}', encoding="utf-8")

    assert main(["avro-validate-file", str(schema_path), str(sample_path)]) == 0


def test_cli_avro_validate_file_fails(tmp_path):
    schema_path = tmp_path / "schema.avsc"
    sample_path = tmp_path / "sample.json"
    schema_path.write_text(
        """
{
  "type": "record",
  "name": "OrderCreated",
  "fields": [{"name": "event_id", "type": "string"}]
}
""",
        encoding="utf-8",
    )
    sample_path.write_text("{}", encoding="utf-8")

    assert main(["avro-validate-file", str(schema_path), str(sample_path)]) == 1
