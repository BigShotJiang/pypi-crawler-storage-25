from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from pytest_kafka_contract.flow import FlowMessage, FlowResult, load_flow_spec


class TestFlowResult:
    def test_bool_true_when_passed(self):
        result = FlowResult(passed=True)
        assert bool(result) is True

    def test_bool_false_when_not_passed(self):
        result = FlowResult(passed=False)
        assert bool(result) is False

    def test_stores_source_destination_correlation(self):
        result = FlowResult(
            passed=True,
            source_topic="src.topic",
            destination_topic="dest.topic",
            correlation_id="abc-123",
        )
        assert result.source_topic == "src.topic"
        assert result.destination_topic == "dest.topic"
        assert result.correlation_id == "abc-123"

    def test_issues_default_empty(self):
        result = FlowResult(passed=True)
        assert result.issues == []

    def test_metadata_default_empty(self):
        result = FlowResult(passed=True)
        assert result.metadata == {}

    def test_produced_and_consumed_default_none(self):
        result = FlowResult(passed=True)
        assert result.produced_message is None
        assert result.consumed_message is None

    def test_exposes_fields_used_by_custom_assertions(self):
        produced = FlowMessage(topic="src.topic", value={"order_id": "ord_1"})
        consumed = FlowMessage(topic="dest.topic", value={"total": 108.25})
        result = FlowResult(
            passed=True,
            issues=[],
            correlation_id="cid-1",
            produced_message=produced,
            consumed_message=consumed,
            metadata={"partition": 0, "offset": 3},
        )

        assert result.passed is True
        assert result.issues == []
        assert result.correlation_id == "cid-1"
        assert result.produced_message is produced
        assert result.consumed_message is consumed
        assert result.metadata == {"partition": 0, "offset": 3}

    def test_consumed_payload_is_accessible_for_custom_assertions(self):
        result = FlowResult(
            passed=True,
            correlation_id="cid-1",
            consumed_message=FlowMessage(topic="dest.topic", value={"total": 108.25}),
        )

        assert result.consumed_message is not None
        assert result.consumed_message.value is not None
        assert result.consumed_message.value["total"] == 108.25


class TestFlowMessage:
    def test_stores_topic(self):
        msg = FlowMessage(topic="my.topic")
        assert msg.topic == "my.topic"

    def test_stores_partition_and_offset(self):
        msg = FlowMessage(topic="t", partition=2, offset=42)
        assert msg.partition == 2
        assert msg.offset == 42

    def test_stores_value(self):
        msg = FlowMessage(topic="t", value={"status": "PAID"})
        assert msg.value == {"status": "PAID"}

    def test_headers_default_empty(self):
        msg = FlowMessage(topic="t")
        assert msg.headers == {}

    def test_schema_id_default_none(self):
        msg = FlowMessage(topic="t")
        assert msg.schema_id is None


class TestLoadFlowSpec:
    def _write_spec(self, tmp_path: Path, content: str) -> Path:
        p = tmp_path / "flow.yaml"
        p.write_text(textwrap.dedent(content), encoding="utf-8")
        return p

    def test_loads_required_fields(self, tmp_path):
        path = self._write_spec(
            tmp_path,
            """\
            name: test-flow
            format: json
            source_topic: src.orders
            destination_topic: dest.orders
            payload:
              status: PAID
            """,
        )
        spec = load_flow_spec(path)
        assert spec.name == "test-flow"
        assert spec.format == "json"
        assert spec.source_topic == "src.orders"
        assert spec.destination_topic == "dest.orders"
        assert spec.payload == {"status": "PAID"}

    def test_loads_optional_fields(self, tmp_path):
        path = self._write_spec(
            tmp_path,
            """\
            name: test-flow
            format: json
            source_topic: src.orders
            destination_topic: dest.orders
            payload:
              status: PAID
            expect:
              status: PAID
            contract_path: contracts/order.yaml
            bootstrap_servers: broker:9092
            timeout_ms: 5000
            correlation_field: trace_id
            mode: expect_message
            """,
        )
        spec = load_flow_spec(path)
        assert spec.expect == {"status": "PAID"}
        assert spec.contract_path == "contracts/order.yaml"
        assert spec.bootstrap_servers == "broker:9092"
        assert spec.timeout_ms == 5000
        assert spec.correlation_field == "trace_id"
        assert spec.mode == "expect_message"

    def test_supports_json_format(self, tmp_path):
        path = self._write_spec(
            tmp_path,
            """\
            name: json-flow
            format: json
            source_topic: src.orders
            destination_topic: dest.orders
            payload:
              status: PAID
            """,
        )
        spec = load_flow_spec(path)
        assert spec.format == "json"

    def test_supports_avro_format_fields(self, tmp_path):
        path = self._write_spec(
            tmp_path,
            """\
            name: avro-flow
            format: avro
            schema_registry_url: http://localhost:8081
            source_topic: src.orders
            destination_topic: dest.orders
            source_subject: src.orders-value
            destination_subject: dest.orders-value
            payload:
              status: PAID
            expect:
              status: PAID
            """,
        )
        spec = load_flow_spec(path)
        assert spec.format == "avro"
        assert spec.registry_url == "http://localhost:8081"
        assert spec.source_subject == "src.orders-value"
        assert spec.destination_subject == "dest.orders-value"
        assert spec.expect == {"status": "PAID"}

    def test_defaults_correlation_field(self, tmp_path):
        path = self._write_spec(
            tmp_path,
            """\
            name: test-flow
            format: json
            source_topic: src.orders
            destination_topic: dest.orders
            payload:
              status: PAID
            """,
        )
        spec = load_flow_spec(path)
        assert spec.correlation_field == "correlation_id"

    def test_defaults_mode_to_expect_message(self, tmp_path):
        path = self._write_spec(
            tmp_path,
            """\
            name: test-flow
            format: json
            source_topic: src.orders
            destination_topic: dest.orders
            payload:
              status: PAID
            """,
        )
        spec = load_flow_spec(path)
        assert spec.mode == "expect_message"

    def test_fails_readable_when_source_topic_missing(self, tmp_path):
        path = self._write_spec(
            tmp_path,
            """\
            name: test-flow
            format: json
            destination_topic: dest.orders
            payload:
              status: PAID
            """,
        )
        with pytest.raises(ValueError, match="FLOW_INVALID_CONFIG.*source_topic"):
            load_flow_spec(path)

    def test_fails_readable_when_name_missing(self, tmp_path):
        path = self._write_spec(
            tmp_path,
            """\
            format: json
            source_topic: src.orders
            destination_topic: dest.orders
            payload:
              status: PAID
            """,
        )
        with pytest.raises(ValueError, match="FLOW_INVALID_CONFIG.*name"):
            load_flow_spec(path)

    def test_fails_readable_when_payload_missing(self, tmp_path):
        path = self._write_spec(
            tmp_path,
            """\
            name: test-flow
            format: json
            source_topic: src.orders
            destination_topic: dest.orders
            """,
        )
        with pytest.raises(ValueError, match="FLOW_INVALID_CONFIG.*payload"):
            load_flow_spec(path)
