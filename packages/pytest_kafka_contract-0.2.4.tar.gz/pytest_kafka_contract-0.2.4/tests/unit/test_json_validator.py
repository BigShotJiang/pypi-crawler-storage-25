from pytest_kafka_contract.models import Contract, ContractRules, FieldRule
from pytest_kafka_contract.result import ContractResult
from pytest_kafka_contract.validator import validate_payload


def contract() -> Contract:
    return Contract(
        version=1,
        name="order-created-v1",
        topic="orders.created",
        message=FieldRule(
            type="object",
            nullable=False,
            required=["event_id", "event_type", "order"],
            properties={
                "event_id": FieldRule(type="string", nullable=False),
                "event_type": FieldRule(type="string", const="OrderCreated", nullable=False),
                "order": FieldRule(
                    type="object",
                    nullable=False,
                    required=["order_id", "total", "currency"],
                    properties={
                        "order_id": FieldRule(type="string", nullable=False),
                        "total": FieldRule(type="number", nullable=False),
                        "currency": FieldRule(type="string", enum=["USD", "CAD"], nullable=False),
                    },
                ),
            },
        ),
        rules=ContractRules(allow_extra_fields=False),
    )


def test_valid_payload_passes() -> None:
    result = validate_payload(
        {
            "event_id": "evt_1",
            "event_type": "OrderCreated",
            "order": {"order_id": "ord_1", "total": 20.0, "currency": "USD"},
        },
        contract(),
    )

    assert isinstance(result, ContractResult)
    assert result.passed
    assert result.issues == []
    assert result.metadata["topic"] == "orders.created"


def test_multiple_json_issues_are_collected() -> None:
    result = validate_payload(
        {
            "event_type": "OrderUpdated",
            "debug": True,
            "order": {"order_id": None, "total": "20.0", "currency": "EUR", "extra": "x"},
        },
        contract(),
    )

    assert not result.passed
    assert {issue.code for issue in result.issues} >= {
        "MISSING_REQUIRED_FIELD",
        "CONST_MISMATCH",
        "EXTRA_FIELD",
        "NULL_NOT_ALLOWED",
        "TYPE_MISMATCH",
        "ENUM_MISMATCH",
    }
    assert any(issue.path == "$.order.total" for issue in result.issues)
