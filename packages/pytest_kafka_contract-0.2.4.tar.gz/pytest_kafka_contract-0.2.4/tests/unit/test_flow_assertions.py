from __future__ import annotations

from pytest_kafka_contract.flow_assertions import assert_expected_subset


class TestAssertExpectedSubset:
    def test_passes_when_exact_match(self):
        issues = assert_expected_subset({"status": "PAID"}, {"status": "PAID"})
        assert issues == []

    def test_passes_with_extra_actual_fields(self):
        actual = {"order_id": "ord_1", "status": "PAID", "internal": "ok"}
        expected = {"status": "PAID"}
        issues = assert_expected_subset(actual, expected)
        assert issues == []

    def test_fails_when_field_value_differs(self):
        actual = {"status": "PENDING"}
        expected = {"status": "PAID"}
        issues = assert_expected_subset(actual, expected)
        assert len(issues) == 1
        assert issues[0].code == "FLOW_EXPECTATION_FAILED"
        assert "$.status" in issues[0].path
        assert "PAID" in issues[0].message
        assert "PENDING" in issues[0].message

    def test_fails_when_field_missing(self):
        actual = {"order_id": "ord_1"}
        expected = {"status": "PAID"}
        issues = assert_expected_subset(actual, expected)
        assert len(issues) == 1
        assert issues[0].code == "FLOW_EXPECTATION_FAILED"
        assert "$.status" in issues[0].path
        assert "missing" in issues[0].message.lower()

    def test_supports_nested_dict_path(self):
        actual = {"order": {"id": "ord_1", "amount": 10.0}}
        expected = {"order": {"id": "ord_1"}}
        issues = assert_expected_subset(actual, expected)
        assert issues == []

    def test_fails_nested_dict_mismatch(self):
        actual = {"order": {"id": "ord_2"}}
        expected = {"order": {"id": "ord_1"}}
        issues = assert_expected_subset(actual, expected)
        assert len(issues) == 1
        assert "$.order.id" in issues[0].path

    def test_reports_readable_path_for_nested(self):
        actual = {"a": {"b": {"c": "wrong"}}}
        expected = {"a": {"b": {"c": "right"}}}
        issues = assert_expected_subset(actual, expected)
        assert issues[0].path == "$.a.b.c"

    def test_fails_when_expected_object_actual_is_not(self):
        actual = {"field": "not-a-dict"}
        expected = {"field": {"nested": "val"}}
        issues = assert_expected_subset(actual, expected)
        assert len(issues) == 1
        assert issues[0].code == "FLOW_EXPECTATION_FAILED"

    def test_multiple_failures_reported(self):
        actual = {"a": "wrong_a", "b": "right_b"}
        expected = {"a": "right_a", "b": "right_b", "c": "right_c"}
        issues = assert_expected_subset(actual, expected)
        codes = [i.code for i in issues]
        assert codes.count("FLOW_EXPECTATION_FAILED") == 2

    def test_empty_expected_always_passes(self):
        issues = assert_expected_subset({"anything": True}, {})
        assert issues == []
