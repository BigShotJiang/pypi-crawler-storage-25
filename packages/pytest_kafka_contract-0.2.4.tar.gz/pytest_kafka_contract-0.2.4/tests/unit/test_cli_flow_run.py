from __future__ import annotations

import textwrap
from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from pytest_kafka_contract.cli import app
from pytest_kafka_contract.flow import FlowResult
from pytest_kafka_contract.result import ContractIssue


runner = CliRunner()


def _write_spec(tmp_path: Path, content: str) -> Path:
    p = tmp_path / "flow.yaml"
    p.write_text(textwrap.dedent(content), encoding="utf-8")
    return p


def _pass_result(**kwargs) -> FlowResult:
    defaults = dict(
        passed=True,
        flow_name="test-flow",
        source_topic="src.orders",
        destination_topic="dest.orders",
        correlation_id="abc-123",
    )
    defaults.update(kwargs)
    return FlowResult(**defaults)


def _fail_result(**kwargs) -> FlowResult:
    defaults = dict(
        passed=False,
        flow_name="test-flow",
        source_topic="src.orders",
        destination_topic="dest.orders",
        correlation_id="abc-123",
        issues=[
            ContractIssue(
                code="FLOW_TIMEOUT",
                path="$",
                message="No message found within 5000ms",
            )
        ],
    )
    defaults.update(kwargs)
    return FlowResult(**defaults)


class TestFlowRunCommand:
    def test_flow_run_loads_yaml_and_calls_runner(self, tmp_path):
        spec_path = _write_spec(
            tmp_path,
            """\
            name: test-flow
            format: json
            source_topic: src.orders
            destination_topic: dest.orders
            bootstrap_servers: localhost:9092
            timeout_ms: 5000
            payload:
              status: PAID
            """,
        )

        with patch("pytest_kafka_contract.cli.KafkaFlowRunner") as mock_runner_cls:
            fake_runner = MagicMock()
            fake_runner.run_json_flow.return_value = _pass_result()
            mock_runner_cls.return_value = fake_runner

            result = runner.invoke(app, ["flow-run", str(spec_path)])

        assert result.exit_code == 0
        fake_runner.run_json_flow.assert_called_once()

    def test_flow_run_prints_pass_on_success(self, tmp_path):
        spec_path = _write_spec(
            tmp_path,
            """\
            name: test-flow
            format: json
            source_topic: src.orders
            destination_topic: dest.orders
            payload:
              status: PAID
            """,
        )

        with patch("pytest_kafka_contract.cli.KafkaFlowRunner") as mock_runner_cls:
            fake_runner = MagicMock()
            fake_runner.run_json_flow.return_value = _pass_result()
            mock_runner_cls.return_value = fake_runner

            result = runner.invoke(app, ["flow-run", str(spec_path)])

        assert "PASS" in result.output

    def test_flow_run_prints_fail_and_issues_on_failure(self, tmp_path):
        spec_path = _write_spec(
            tmp_path,
            """\
            name: test-flow
            format: json
            source_topic: src.orders
            destination_topic: dest.orders
            payload:
              status: PAID
            """,
        )

        with patch("pytest_kafka_contract.cli.KafkaFlowRunner") as mock_runner_cls:
            fake_runner = MagicMock()
            fake_runner.run_json_flow.return_value = _fail_result()
            mock_runner_cls.return_value = fake_runner

            result = runner.invoke(app, ["flow-run", str(spec_path)])

        assert "FAIL" in result.output
        assert "FLOW_TIMEOUT" in result.output

    def test_flow_run_exits_0_on_pass(self, tmp_path):
        spec_path = _write_spec(
            tmp_path,
            """\
            name: test-flow
            format: json
            source_topic: src.orders
            destination_topic: dest.orders
            payload:
              status: PAID
            """,
        )

        with patch("pytest_kafka_contract.cli.KafkaFlowRunner") as mock_runner_cls:
            fake_runner = MagicMock()
            fake_runner.run_json_flow.return_value = _pass_result()
            mock_runner_cls.return_value = fake_runner

            result = runner.invoke(app, ["flow-run", str(spec_path)])

        assert result.exit_code == 0

    def test_flow_run_exits_1_on_fail(self, tmp_path):
        spec_path = _write_spec(
            tmp_path,
            """\
            name: test-flow
            format: json
            source_topic: src.orders
            destination_topic: dest.orders
            payload:
              status: PAID
            """,
        )

        with patch("pytest_kafka_contract.cli.KafkaFlowRunner") as mock_runner_cls:
            fake_runner = MagicMock()
            fake_runner.run_json_flow.return_value = _fail_result()
            mock_runner_cls.return_value = fake_runner

            result = runner.invoke(app, ["flow-run", str(spec_path)])

        assert result.exit_code == 1

    def test_flow_run_uses_expect_no_message_mode(self, tmp_path):
        spec_path = _write_spec(
            tmp_path,
            """\
            name: negative-flow
            format: json
            mode: expect_no_message
            source_topic: src.orders
            destination_topic: dest.orders
            payload:
              status: CANCELLED
            """,
        )

        with patch("pytest_kafka_contract.cli.KafkaFlowRunner") as mock_runner_cls:
            fake_runner = MagicMock()
            fake_runner.expect_no_json_flow.return_value = _pass_result()
            mock_runner_cls.return_value = fake_runner

            result = runner.invoke(app, ["flow-run", str(spec_path)])

        assert result.exit_code == 0
        fake_runner.expect_no_json_flow.assert_called_once()

    def test_flow_run_rejects_invalid_config(self, tmp_path):
        spec_path = _write_spec(
            tmp_path,
            """\
            format: json
            destination_topic: dest.orders
            payload:
              status: PAID
            """,
        )
        result = runner.invoke(app, ["flow-run", str(spec_path)])
        assert result.exit_code != 0
