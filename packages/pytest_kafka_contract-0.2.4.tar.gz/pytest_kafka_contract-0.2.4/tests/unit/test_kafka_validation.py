from io import BytesIO

import pytest

import pytest_kafka_contract.kafka_validation as kafka_validation
from pytest_kafka_contract.kafka_client import KafkaMessage
from pytest_kafka_contract.utils import require_fastavro


SCHEMA = {
    "type": "record",
    "name": "OrderCreated",
    "fields": [{"name": "event_id", "type": "string"}],
}


class FakeConsumer:
    message = None
    instances = []

    def __init__(self, config):
        self.config = config
        self.instances.append(self)

    def consume_latest(self, topic):
        return self.message

    def close(self):
        pass


class FakeRegistryClient:
    schema = SCHEMA
    error = None

    def __init__(self, registry_url):
        self.registry_url = registry_url

    def get_schema_by_id(self, schema_id):
        if self.error is not None:
            raise self.error
        return self.schema


def kafka_message(value: bytes | None) -> KafkaMessage:
    return KafkaMessage("orders.created", 0, 12, None, value, None)


def write_contract(tmp_path):
    path = tmp_path / "contract.yaml"
    path.write_text(
        """
version: 1
name: c
topic: orders.created
message:
  type: object
  required: [event_id]
  properties:
    event_id:
      type: string
""",
        encoding="utf-8",
    )
    return path


@pytest.fixture(autouse=True)
def fake_dependencies(monkeypatch):
    FakeConsumer.message = None
    FakeConsumer.instances = []
    FakeRegistryClient.schema = SCHEMA
    FakeRegistryClient.error = None
    monkeypatch.setattr(kafka_validation, "KafkaContractConsumer", FakeConsumer)
    monkeypatch.setattr(kafka_validation, "SchemaRegistryClient", FakeRegistryClient)


def test_no_json_message_returns_kafka_no_message(tmp_path):
    result = kafka_validation.validate_latest_json("orders.created", write_contract(tmp_path))

    assert not result.passed
    assert result.issues[0].code == "KAFKA_NO_MESSAGE"


def test_json_message_value_none_returns_invalid(tmp_path):
    FakeConsumer.message = kafka_message(None)

    result = kafka_validation.validate_latest_json("orders.created", write_contract(tmp_path))

    assert not result.passed
    assert result.issues[0].code == "KAFKA_MESSAGE_INVALID"


def test_invalid_json_returns_deserialization_failed(tmp_path):
    FakeConsumer.message = kafka_message(b"not-json")

    result = kafka_validation.validate_latest_json("orders.created", write_contract(tmp_path))

    assert not result.passed
    assert result.issues[0].code == "KAFKA_DESERIALIZATION_FAILED"


def test_valid_json_validates_successfully(tmp_path):
    FakeConsumer.message = kafka_message(b'{"event_id": "evt_1"}')

    result = kafka_validation.validate_latest_json("orders.created", write_contract(tmp_path))

    assert result.passed
    assert result.metadata["topic"] == "orders.created"
    assert result.metadata["format"] == "json"


def test_json_validation_passes_auto_offset_reset_to_consumer(tmp_path):
    FakeConsumer.message = kafka_message(b'{"event_id": "evt_1"}')

    result = kafka_validation.validate_latest_json(
        "orders.created",
        write_contract(tmp_path),
        auto_offset_reset="earliest",
    )

    assert result.passed
    assert FakeConsumer.instances[0].config.auto_offset_reset == "earliest"


def test_invalid_json_returns_contract_issues(tmp_path):
    FakeConsumer.message = kafka_message(b"{}")

    result = kafka_validation.validate_latest_json("orders.created", write_contract(tmp_path))

    assert not result.passed
    assert result.issues[0].code == "MISSING_REQUIRED_FIELD"


def test_no_avro_message_returns_kafka_no_message():
    result = kafka_validation.validate_latest_avro(
        "orders.created",
        "http://registry",
        "orders.created-value",
    )

    assert not result.passed
    assert result.issues[0].code == "KAFKA_NO_MESSAGE"


def avro_message(schema_id: int, record: dict[str, object]) -> bytes:
    fastavro = require_fastavro()
    buf = BytesIO()
    fastavro.schemaless_writer(buf, fastavro.parse_schema(SCHEMA), record)
    return b"\x00" + schema_id.to_bytes(4, "big") + buf.getvalue()


def test_avro_schema_id_mismatch_returns_issue():
    FakeConsumer.message = kafka_message(avro_message(3, {"event_id": "evt_1"}))

    result = kafka_validation.validate_latest_avro(
        "orders.created",
        "http://registry",
        "orders.created-value",
        expected_schema_id=4,
    )

    assert not result.passed
    assert result.issues[0].code == "KAFKA_SCHEMA_ID_MISMATCH"


def test_avro_schema_id_fetches_schema_and_validates():
    FakeConsumer.message = kafka_message(avro_message(3, {"event_id": "evt_1"}))

    result = kafka_validation.validate_latest_avro(
        "orders.created",
        "http://registry",
        "orders.created-value",
    )

    assert result.passed
    assert result.metadata["schema_id"] == 3
    assert result.metadata["record"] == {"event_id": "evt_1"}


def test_avro_validation_passes_auto_offset_reset_to_consumer():
    FakeConsumer.message = kafka_message(avro_message(3, {"event_id": "evt_1"}))

    result = kafka_validation.validate_latest_avro(
        "orders.created",
        "http://registry",
        "orders.created-value",
        auto_offset_reset="earliest",
    )

    assert result.passed
    assert FakeConsumer.instances[0].config.auto_offset_reset == "earliest"


def test_bad_avro_bytes_returns_deserialization_failed():
    FakeConsumer.message = kafka_message(b"\x00\x00\x00\x00\x03bad")

    result = kafka_validation.validate_latest_avro(
        "orders.created",
        "http://registry",
        "orders.created-value",
    )

    assert not result.passed
    assert result.issues[0].code == "KAFKA_DESERIALIZATION_FAILED"
