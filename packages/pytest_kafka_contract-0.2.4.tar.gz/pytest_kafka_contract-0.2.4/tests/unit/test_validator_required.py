from pytest_kafka_contract.models import Contract, ContractRules, FieldRule
from pytest_kafka_contract.validator import validate_payload


def contract() -> Contract:
    return Contract(
        version=1,
        name="order-created-v1",
        topic="orders.created",
        message=FieldRule(
            type="object",
            required=["event_id", "order"],
            properties={
                "event_id": FieldRule(type="string", nullable=False),
                "order": FieldRule(
                    type="object",
                    required=["order_id"],
                    properties={"order_id": FieldRule(type="string")},
                ),
            },
        ),
        rules=ContractRules(),
    )


def test_passes_when_required_field_exists():
    result = validate_payload({"event_id": "evt_1", "order": {"order_id": "ord_1"}}, contract())

    assert result.passed is True
    assert result.issues == []


def test_fails_when_required_field_missing():
    result = validate_payload({"order": {"order_id": "ord_1"}}, contract())

    assert result.passed is False
    assert result.issues[0].code == "MISSING_REQUIRED_FIELD"
    assert result.issues[0].path == "$.event_id"


def test_checks_nested_required_field():
    result = validate_payload({"event_id": "evt_1", "order": {}}, contract())

    assert result.passed is False
    assert result.issues[0].code == "MISSING_REQUIRED_FIELD"
    assert result.issues[0].path == "$.order.order_id"
