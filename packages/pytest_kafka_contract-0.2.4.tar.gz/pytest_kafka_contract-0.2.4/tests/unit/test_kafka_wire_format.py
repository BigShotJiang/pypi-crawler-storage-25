from io import BytesIO

import pytest

from pytest_kafka_contract.avro import (
    decode_confluent_avro_message,
    extract_confluent_schema_id,
)
from pytest_kafka_contract.utils import require_fastavro


def build_confluent_avro_message(schema_id: int, payload_bytes: bytes) -> bytes:
    return b"\x00" + schema_id.to_bytes(4, byteorder="big") + payload_bytes


def test_schema_id_extracted_from_bytes():
    assert extract_confluent_schema_id(build_confluent_avro_message(42, b"abc")) == 42


def test_short_bytes_raise_value_error():
    with pytest.raises(ValueError, match="at least 5 bytes"):
        extract_confluent_schema_id(b"\x00\x00")


def test_bad_magic_byte_raises_value_error():
    with pytest.raises(ValueError, match="magic byte"):
        extract_confluent_schema_id(b"\x01\x00\x00\x00\x01")


def test_valid_avro_bytes_decode():
    schema = {
        "type": "record",
        "name": "OrderCreated",
        "fields": [{"name": "event_id", "type": "string"}],
    }
    fastavro = require_fastavro()
    buf = BytesIO()
    fastavro.schemaless_writer(buf, fastavro.parse_schema(schema), {"event_id": "evt_1"})
    result = decode_confluent_avro_message(build_confluent_avro_message(7, buf.getvalue()), schema)

    assert result.passed
    assert result.metadata["schema_id"] == 7
    assert result.metadata["record"] == {"event_id": "evt_1"}


def test_bad_avro_payload_returns_failed_result():
    schema = {
        "type": "record",
        "name": "OrderCreated",
        "fields": [{"name": "event_id", "type": "string"}],
    }

    result = decode_confluent_avro_message(build_confluent_avro_message(7, b"\xff"), schema)

    assert not result.passed
    assert result.issues[0].code == "KAFKA_DESERIALIZATION_FAILED"
