from pathlib import Path

import pytest
import yaml

from pytest_kafka_contract.contracts import load_contract
from pytest_kafka_contract.errors import ContractLoadError


def write_contract(tmp_path: Path, text: str) -> Path:
    path = tmp_path / "order-created.yaml"
    path.write_text(text, encoding="utf-8")
    return path


def valid_contract_text() -> str:
    return """
version: 1
name: order-created-v1
topic: orders.created
message:
  type: object
  required: [event_id, order]
  properties:
    event_id:
      type: string
      nullable: false
    order:
      type: object
      required: [order_id]
      properties:
        order_id:
          type: string
rules:
  allow_extra_fields: false
"""


def test_loads_valid_contract(tmp_path):
    contract = load_contract(write_contract(tmp_path, valid_contract_text()))

    assert contract.name == "order-created-v1"
    assert contract.topic == "orders.created"
    assert contract.message.properties["event_id"].type == "string"
    assert contract.message.properties["order"].properties["order_id"].type == "string"
    assert contract.rules.allow_extra_fields is False


@pytest.mark.parametrize("field", ["version", "name", "topic", "message"])
def test_rejects_missing_required_root_fields(tmp_path, field):
    raw = yaml.safe_load(valid_contract_text())
    raw.pop(field)
    path = write_contract(tmp_path, yaml.safe_dump(raw))

    with pytest.raises(ContractLoadError, match=f"Missing required root field: {field}"):
        load_contract(path)


def test_rejects_unknown_root_field(tmp_path):
    path = write_contract(tmp_path, valid_contract_text() + "\nunknown: true\n")

    with pytest.raises(ContractLoadError, match="Unknown root field"):
        load_contract(path)


def test_parses_rules_defaults(tmp_path):
    text = """
version: 1
name: minimal
topic: topic
message:
  type: object
"""

    contract = load_contract(write_contract(tmp_path, text))

    assert contract.rules.allow_extra_fields is True
    assert contract.rules.fail_on_missing_required is True
