from __future__ import annotations

import importlib.metadata


def test_installed_package_exposes_pytest11_entry_point() -> None:
    entry_points = importlib.metadata.entry_points(group="pytest11")

    assert any(
        entry_point.name == "pytest_kafka_contract"
        and entry_point.value == "pytest_kafka_contract.plugin"
        for entry_point in entry_points
    )


def test_pytest_trace_config_can_load_plugin(pytester) -> None:
    result = pytester.runpytest("--trace-config")

    assert "pytest_kafka_contract.plugin" in result.stdout.str()
