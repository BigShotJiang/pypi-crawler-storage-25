def test_help_includes_new_kafka_options(pytester):
    result = pytester.runpytest("--help")

    stdout = result.stdout.str()
    assert "--schema-registry-url" in stdout
    assert "--kafka-avro-subject" in stdout
    assert "--kafka-format" in stdout


def test_fixture_exposes_new_runner_methods(pytester):
    pytester.makepyfile(
        """
        def test_runner_methods(kafka_contract):
            assert hasattr(kafka_contract, "validate_avro_record")
            assert hasattr(kafka_contract, "validate_schema_registry_subject")
            assert hasattr(kafka_contract, "validate_latest_json")
            assert hasattr(kafka_contract, "validate_latest_avro")
        """
    )

    result = pytester.runpytest()

    result.assert_outcomes(passed=1)
