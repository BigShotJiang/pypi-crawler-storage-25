from __future__ import annotations

import json
from unittest.mock import MagicMock, patch


from pytest_kafka_contract.config import RuntimeConfig
from pytest_kafka_contract.kafka_client import KafkaMessage
from pytest_kafka_contract.runner import KafkaContractRunner


def _make_runtime(**kwargs) -> RuntimeConfig:
    defaults = dict(contract_paths=[], bootstrap_servers="localhost:9092", timeout_ms=5000)
    defaults.update(kwargs)
    return RuntimeConfig(**defaults)


def _json_msg(d: dict, partition: int = 0, offset: int = 1) -> KafkaMessage:
    return KafkaMessage(
        topic="dest.topic",
        partition=partition,
        offset=offset,
        key=b"key",
        value=json.dumps(d).encode("utf-8"),
        headers=[],
    )


class TestKafkaContractRunnerFlowMethods:
    def test_has_run_json_flow(self):
        runner = KafkaContractRunner(_make_runtime())
        assert callable(runner.run_json_flow)

    def test_has_expect_no_json_flow(self):
        runner = KafkaContractRunner(_make_runtime())
        assert callable(runner.expect_no_json_flow)

    def test_has_run_avro_flow(self):
        runner = KafkaContractRunner(_make_runtime())
        assert callable(runner.run_avro_flow)

    def test_old_validate_payload_still_works(self, tmp_path):
        contract_path = tmp_path / "c.yaml"
        contract_path.write_text(
            "version: 1\nname: t\ntopic: t\nmessage:\n  type: object\n  properties:\n    x:\n      type: string\n",
            encoding="utf-8",
        )
        runner = KafkaContractRunner(_make_runtime())
        result = runner.validate_payload({"x": "hello"}, contract_path)
        assert result.passed

    def test_old_validate_latest_json_still_accessible(self):
        runner = KafkaContractRunner(_make_runtime())
        assert callable(runner.validate_latest_json)

    def test_runtime_config_defaults_used_for_bootstrap(self):
        runner = KafkaContractRunner(
            _make_runtime(bootstrap_servers="broker:9093", timeout_ms=20000)
        )
        captured_bootstraps = []
        fake_producer = MagicMock()
        fake_producer.produce = MagicMock()
        fake_producer.flush = MagicMock()
        fake_producer.close = MagicMock()
        fake_consumer = MagicMock()
        fake_consumer.subscribe = MagicMock()
        fake_consumer.poll_until = MagicMock(return_value=None)
        fake_consumer.close = MagicMock()

        with (
            patch(
                "pytest_kafka_contract.flow_runner.KafkaMessageProducer",
                side_effect=lambda bs: captured_bootstraps.append(bs) or fake_producer,
            ),
            patch(
                "pytest_kafka_contract.flow_runner.KafkaMessageConsumer",
                return_value=fake_consumer,
            ),
        ):
            runner.run_json_flow(
                source_topic="s",
                destination_topic="d",
                payload={"x": "y"},
                timeout_ms=100,
            )

        assert captured_bootstraps[0] == "broker:9093"

    def test_method_args_override_runtime_config(self):
        runner = KafkaContractRunner(
            _make_runtime(bootstrap_servers="default:9092", timeout_ms=20000)
        )
        captured_bootstraps = []
        fake_producer = MagicMock()
        fake_producer.produce = MagicMock()
        fake_producer.flush = MagicMock()
        fake_producer.close = MagicMock()
        fake_consumer = MagicMock()
        fake_consumer.subscribe = MagicMock()
        fake_consumer.poll_until = MagicMock(return_value=None)
        fake_consumer.close = MagicMock()

        with (
            patch(
                "pytest_kafka_contract.flow_runner.KafkaMessageProducer",
                side_effect=lambda bs: captured_bootstraps.append(bs) or fake_producer,
            ),
            patch(
                "pytest_kafka_contract.flow_runner.KafkaMessageConsumer",
                return_value=fake_consumer,
            ),
        ):
            runner.run_json_flow(
                source_topic="s",
                destination_topic="d",
                payload={"x": "y"},
                bootstrap_servers="override:9095",
                timeout_ms=100,
            )

        assert captured_bootstraps[0] == "override:9095"
