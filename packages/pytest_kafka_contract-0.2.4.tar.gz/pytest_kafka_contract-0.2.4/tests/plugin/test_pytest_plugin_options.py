def test_help_contains_kafka_contract_option(pytester):
    result = pytester.runpytest("--help")

    result.stdout.fnmatch_lines(["*--kafka-contract=KAFKA_CONTRACT*"])


def test_default_bootstrap_server(pytester):
    pytester.makepyfile(
        """
        def test_default_bootstrap(kafka_contract):
            assert kafka_contract.config.bootstrap_servers == "localhost:9092"
        """
    )

    result = pytester.runpytest()

    result.assert_outcomes(passed=1)


def test_options_can_be_passed_multiple_times(pytester):
    pytester.makefile(
        ".yaml",
        a="""
version: 1
name: a
topic: a
message:
  type: object
""",
        b="""
version: 1
name: b
topic: b
message:
  type: object
""",
    )
    result = pytester.runpytest("--collect-only", "--kafka-contract", "a.yaml", "--kafka-contract", "b.yaml")

    stdout = result.stdout.str()
    assert "kafka_contract[a.yaml]" in stdout
    assert "kafka_contract[b.yaml]" in stdout


def test_option_values_are_available_to_fixture(pytester):
    pytester.makepyfile(
        """
        def test_contract_paths(kafka_contract):
            assert kafka_contract.config.contract_paths == []
        """
    )

    result = pytester.runpytest()

    result.assert_outcomes(passed=1)


def test_kafka_contract_option_collects_generated_item(pytester):
    pytester.makefile(
        ".yaml",
        contract="""
version: 1
name: order-created-v1
topic: orders.created
message:
  type: object
""",
    )

    result = pytester.runpytest("--collect-only", "--kafka-contract", "contract.yaml")

    assert "kafka_contract[contract.yaml]" in result.stdout.str()
    result.assert_outcomes()
