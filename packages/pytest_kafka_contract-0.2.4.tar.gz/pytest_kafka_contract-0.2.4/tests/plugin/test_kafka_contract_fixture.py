def test_kafka_contract_fixture_exposes_all_public_methods(pytester):
    pytester.makepyfile(
        """
        def test_fixture_methods(kafka_contract):
            assert hasattr(kafka_contract, "validate_payload")
            assert hasattr(kafka_contract, "validate_avro_record")
            assert hasattr(kafka_contract, "validate_schema_registry_subject")
            assert hasattr(kafka_contract, "validate_latest_json")
            assert hasattr(kafka_contract, "validate_latest_avro")
            assert hasattr(kafka_contract, "new_correlation_id")
        """
    )

    result = pytester.runpytest()

    result.assert_outcomes(passed=1)
