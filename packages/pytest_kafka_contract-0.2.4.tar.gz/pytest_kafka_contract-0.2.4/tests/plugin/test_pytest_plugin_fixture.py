def test_fixture_exists(pytester):
    pytester.makepyfile(
        """
        def test_fixture_exists(kafka_contract):
            assert kafka_contract is not None
        """
    )

    result = pytester.runpytest()

    result.assert_outcomes(passed=1)


def test_fixture_validates_payload(pytester):
    pytester.makefile(
        ".yaml",
        contract="""
version: 1
name: order-created-v1
topic: orders.created
message:
  type: object
  required: [event_id]
  properties:
    event_id:
      type: string
      nullable: false
""",
    )
    pytester.makepyfile(
        """
        def test_payload_validation(kafka_contract):
            result = kafka_contract.validate_payload(
                {"event_id": "evt_1"},
                contract_path="contract.yaml",
            )
            assert result.passed is True
        """
    )

    result = pytester.runpytest()

    result.assert_outcomes(passed=1)
