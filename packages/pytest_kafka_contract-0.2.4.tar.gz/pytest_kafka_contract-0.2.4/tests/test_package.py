def test_package_imports():
    from importlib.metadata import version

    import pytest_kafka_contract

    assert pytest_kafka_contract.__version__ == version("pytest-kafka-contract")
