from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

import pytest

pytestmark = pytest.mark.e2e


def test_temp_user_project_uses_pytest_fixture_for_json_and_avro(tmp_path: Path) -> None:
    cli = shutil.which("pytest-kafka-contract")
    assert cli is not None

    init = _run([cli, "init"], cwd=tmp_path)
    assert init.returncode == 0, init.stderr

    tests_dir = tmp_path / "tests"
    tests_dir.mkdir()
    (tests_dir / "test_contracts.py").write_text(
        """
def test_json_contract(kafka_contract):
    result = kafka_contract.validate_payload(
        payload={
            "event_id": "evt_1",
            "event_type": "OrderCreated",
            "order": {"order_id": "ord_1", "total": 20.0},
        },
        contract_path="contracts/order-created.yaml",
    )
    assert result.passed, result.issues


def test_avro_contract(kafka_contract):
    result = kafka_contract.validate_avro_record(
        record={
            "event_id": "evt_1",
            "order_id": "ord_1",
            "total": 20.0,
            "currency": "USD",
        },
        schema_path="schemas/order-created.avsc",
    )
    assert result.passed, result.issues


def test_user_can_write_custom_assertions(kafka_contract):
    payload = {
        "event_id": "evt_1",
        "event_type": "OrderCreated",
        "order": {"order_id": "ord_1", "total": 108.25},
    }
    result = kafka_contract.validate_payload(
        payload=payload,
        contract_path="contracts/order-created.yaml",
    )

    assert result.passed, result.issues
    assert payload["order"]["total"] == 108.25
    assert payload["order"]["total"] > 100
""",
        encoding="utf-8",
    )

    result = _run([sys.executable, "-m", "pytest", "-q"], cwd=tmp_path)

    assert result.returncode == 0, result.stdout + result.stderr
    assert "3 passed" in result.stdout


def _run(args: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(args, cwd=cwd, text=True, capture_output=True, check=False)
