from __future__ import annotations

import textwrap
from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from pytest_kafka_contract.cli import app
from pytest_kafka_contract.flow import FlowResult
from pytest_kafka_contract.result import ContractIssue


runner = CliRunner()


def _write_spec(tmp_path: Path, content: str) -> Path:
    path = tmp_path / "flow.yaml"
    path.write_text(textwrap.dedent(content), encoding="utf-8")
    return path


def test_flow_run_json_spec_exits_zero_when_runner_succeeds(tmp_path: Path) -> None:
    spec_path = _write_spec(
        tmp_path,
        """\
        name: json-flow
        format: json
        source_topic: src.orders
        destination_topic: dest.orders
        payload:
          status: PAID
        """,
    )

    with patch("pytest_kafka_contract.cli.KafkaFlowRunner") as runner_cls:
        fake_runner = MagicMock()
        fake_runner.run_json_flow.return_value = FlowResult(passed=True)
        runner_cls.return_value = fake_runner

        result = runner.invoke(app, ["flow-run", str(spec_path)])

    assert result.exit_code == 0
    assert "PASS" in result.output


def test_flow_run_json_spec_exits_nonzero_on_failure(tmp_path: Path) -> None:
    spec_path = _write_spec(
        tmp_path,
        """\
        name: json-flow
        format: json
        source_topic: src.orders
        destination_topic: dest.orders
        payload:
          status: PAID
        """,
    )

    with patch("pytest_kafka_contract.cli.KafkaFlowRunner") as runner_cls:
        fake_runner = MagicMock()
        fake_runner.run_json_flow.return_value = FlowResult(
            passed=False,
            issues=[ContractIssue(code="FLOW_TIMEOUT", path="$", message="no message")],
        )
        runner_cls.return_value = fake_runner

        result = runner.invoke(app, ["flow-run", str(spec_path)])

    assert result.exit_code == 1
    assert "FLOW_TIMEOUT" in result.output


def test_flow_run_avro_spec_routes_to_avro_runner(tmp_path: Path) -> None:
    spec_path = _write_spec(
        tmp_path,
        """\
        name: avro-flow
        format: avro
        registry_url: http://localhost:8081
        source_topic: src.orders
        destination_topic: dest.orders
        source_subject: src.orders-value
        destination_subject: dest.orders-value
        payload:
          status: PAID
        """,
    )

    with patch("pytest_kafka_contract.cli.KafkaFlowRunner") as runner_cls:
        fake_runner = MagicMock()
        fake_runner.run_avro_flow.return_value = FlowResult(passed=True)
        runner_cls.return_value = fake_runner

        result = runner.invoke(app, ["flow-run", str(spec_path)])

    assert result.exit_code == 0
    fake_runner.run_avro_flow.assert_called_once()
