from __future__ import annotations

import inspect
import shutil
import subprocess
from pathlib import Path

import pytest
from pytest_kafka_contract.cli import kafka_validate_avro, kafka_validate_json

pytestmark = pytest.mark.e2e


def test_console_scripts_are_installed() -> None:
    """Both CLI aliases must be present after install."""
    assert shutil.which("pytest-kafka-contract") is not None, (
        "pytest-kafka-contract not found on PATH. Run: pip install -e '.[dev,all]'"
    )
    assert shutil.which("kafka-contract") is not None, (
        "kafka-contract not found on PATH. Run: pip install -e '.[dev,all]'"
    )


def test_readme_safe_cli_commands_work_in_temp_project(tmp_path: Path) -> None:
    cli = shutil.which("pytest-kafka-contract")
    assert cli is not None, (
        "pytest-kafka-contract not found on PATH. Run: pip install -e '.[dev,all]'"
    )

    commands = [
        [cli, "--help"],
        [cli, "init"],
        [cli, "validate-file", "contracts/order-created.yaml", "samples/order-created.json"],
        [cli, "avro-validate-file", "schemas/order-created.avsc", "samples/order-created-avro.json"],
    ]

    for command in commands:
        result = subprocess.run(
            command,
            cwd=tmp_path,
            text=True,
            capture_output=True,
            check=False,
        )
        assert result.returncode == 0, result.stdout + result.stderr

    help_result = subprocess.run(
        [cli, "kafka-validate-json", "--help"],
        cwd=tmp_path,
        text=True,
        capture_output=True,
        check=False,
    )
    assert help_result.returncode == 0, help_result.stdout + help_result.stderr
    assert "auto_offset_reset" in inspect.signature(kafka_validate_json).parameters

    avro_help = subprocess.run(
        [cli, "kafka-validate-avro", "--help"],
        cwd=tmp_path,
        text=True,
        capture_output=True,
        check=False,
    )
    assert avro_help.returncode == 0, avro_help.stdout + avro_help.stderr
    assert "auto_offset_reset" in inspect.signature(kafka_validate_avro).parameters
