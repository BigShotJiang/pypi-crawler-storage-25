from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest

pytestmark = pytest.mark.e2e


def test_built_wheel_installs_and_loads_pytest_plugin(tmp_path: Path) -> None:
    repo_root = Path(__file__).resolve().parents[2]
    dist_dir = tmp_path / "dist"
    venv_dir = tmp_path / "venv"

    build = _run([sys.executable, "-m", "build", "--wheel", "--outdir", str(dist_dir)], cwd=repo_root)
    assert build.returncode == 0, build.stdout + build.stderr
    wheel = next(dist_dir.glob("pytest_kafka_contract-*.whl"))

    venv = _run([sys.executable, "-m", "venv", str(venv_dir)], cwd=tmp_path)
    assert venv.returncode == 0, venv.stderr
    python = _venv_python(venv_dir)

    install = _run([str(python), "-m", "pip", "install", f"{wheel}[all]"], cwd=tmp_path)
    assert install.returncode == 0, install.stdout + install.stderr

    imported = _run(
        [str(python), "-c", "import pytest_kafka_contract; print('import ok')"],
        cwd=tmp_path,
    )
    assert imported.returncode == 0, imported.stderr
    assert "import ok" in imported.stdout

    help_result = _run([str(python), "-m", "pytest", "--help"], cwd=tmp_path)
    assert help_result.returncode == 0, help_result.stderr
    assert "--kafka-contract" in help_result.stdout

    user_project = tmp_path / "user-project"
    user_project.mkdir()
    init = _run([str(_venv_script(venv_dir, "pytest-kafka-contract")), "init"], cwd=user_project)
    assert init.returncode == 0, init.stdout + init.stderr
    tests_dir = user_project / "tests"
    tests_dir.mkdir()
    (tests_dir / "test_order_created_contract.py").write_text(
        """
def test_order_created_contract(kafka_contract):
    result = kafka_contract.validate_payload(
        payload={
            "event_id": "evt_1",
            "event_type": "OrderCreated",
            "order": {"order_id": "ord_1", "total": 20.0},
        },
        contract_path="contracts/order-created.yaml",
    )
    assert result.passed, result.issues
""",
        encoding="utf-8",
    )
    pytest_result = _run([str(python), "-m", "pytest", "-q"], cwd=user_project)
    assert pytest_result.returncode == 0, pytest_result.stdout + pytest_result.stderr
    assert "1 passed" in pytest_result.stdout


def _run(args: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    env.pop("PYTHONPATH", None)
    return subprocess.run(args, cwd=cwd, text=True, capture_output=True, check=False, env=env)


def _venv_python(venv_dir: Path) -> Path:
    if os.name == "nt":
        return venv_dir / "Scripts" / "python.exe"
    return venv_dir / "bin" / "python"


def _venv_script(venv_dir: Path, name: str) -> Path:
    if os.name == "nt":
        return venv_dir / "Scripts" / f"{name}.exe"
    return venv_dir / "bin" / name
