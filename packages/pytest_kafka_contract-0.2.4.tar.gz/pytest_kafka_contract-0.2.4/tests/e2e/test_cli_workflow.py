from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import pytest

pytestmark = pytest.mark.e2e


def test_cli_init_validate_and_failure_workflow(tmp_path: Path) -> None:
    cli = _cli()

    init = _run([cli, "init"], cwd=tmp_path)
    assert init.returncode == 0, init.stderr
    assert (tmp_path / "contracts/order-created.yaml").exists()
    assert (tmp_path / "schemas/order-created.avsc").exists()
    assert (tmp_path / "samples/order-created.json").exists()
    assert (tmp_path / "samples/order-created-avro.json").exists()

    json_pass = _run(
        [cli, "validate-file", "contracts/order-created.yaml", "samples/order-created.json"],
        cwd=tmp_path,
    )
    assert json_pass.returncode == 0, json_pass.stderr
    assert "PASS: payload matches contract" in json_pass.stdout

    avro_pass = _run(
        [cli, "avro-validate-file", "schemas/order-created.avsc", "samples/order-created-avro.json"],
        cwd=tmp_path,
    )
    assert avro_pass.returncode == 0, avro_pass.stderr
    assert "PASS: record matches Avro schema" in avro_pass.stdout

    _write_json(
        tmp_path / "samples/order-created.json",
        {
            "event_id": "evt_1",
            "event_type": "OrderCreated",
            "order": {"order_id": "ord_1", "total": "20.0"},
        },
    )
    json_fail = _run(
        [cli, "validate-file", "contracts/order-created.yaml", "samples/order-created.json"],
        cwd=tmp_path,
    )
    assert json_fail.returncode == 1
    assert "TYPE_MISMATCH" in json_fail.stdout

    _write_json(
        tmp_path / "samples/order-created-avro.json",
        {"event_id": "evt_1", "order_id": "ord_1", "total": "20.0", "currency": "USD"},
    )
    avro_fail = _run(
        [cli, "avro-validate-file", "schemas/order-created.avsc", "samples/order-created-avro.json"],
        cwd=tmp_path,
    )
    assert avro_fail.returncode == 1
    assert "AVRO_RECORD_INVALID" in avro_fail.stdout


def _cli() -> str:
    path = shutil.which("pytest-kafka-contract")
    assert path is not None
    return path


def _run(args: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(args, cwd=cwd, text=True, capture_output=True, check=False)


def _write_json(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload), encoding="utf-8")
