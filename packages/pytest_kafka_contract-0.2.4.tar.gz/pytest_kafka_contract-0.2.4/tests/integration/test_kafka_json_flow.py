from __future__ import annotations

import os
import time

import pytest

from tests.integration.apps import OrderFilterApp
from tests.integration.conftest import create_kafka_topics


pytestmark = pytest.mark.integration


def _skip_unless_integration():
    if os.getenv("PKCT_RUN_INTEGRATION") != "1":
        pytest.skip("set PKCT_RUN_INTEGRATION=1 to run Kafka integration tests")


@pytest.fixture
def flow_topics(unique_topic):
    return f"{unique_topic}.source", f"{unique_topic}.destination"


@pytest.fixture
def order_filter_app(bootstrap_servers, flow_topics):
    _skip_unless_integration()
    source_topic, destination_topic = flow_topics
    create_kafka_topics(bootstrap_servers, [source_topic, destination_topic])
    app = OrderFilterApp(
        bootstrap_servers=bootstrap_servers,
        source_topic=source_topic,
        destination_topic=destination_topic,
    )
    app.start()
    time.sleep(1)
    yield app
    app.stop()


def test_paid_order_reaches_destination(kafka_contract, order_filter_app, bootstrap_servers, flow_topics):
    source_topic, destination_topic = flow_topics

    result = kafka_contract.run_json_flow(
        source_topic=source_topic,
        destination_topic=destination_topic,
        payload={
            "order_id": "ord_123",
            "status": "PAID",
            "amount": 49.99,
        },
        correlation_field="correlation_id",
        expect={
            "order_id": "ord_123",
            "status": "PAID",
            "amount": 49.99,
        },
        bootstrap_servers=bootstrap_servers,
        timeout_ms=30000,
    )

    assert result.passed, result.issues


def test_cancelled_order_is_filtered_out(kafka_contract, order_filter_app, bootstrap_servers, flow_topics):
    source_topic, destination_topic = flow_topics

    result = kafka_contract.expect_no_json_flow(
        source_topic=source_topic,
        destination_topic=destination_topic,
        payload={
            "order_id": "ord_456",
            "status": "CANCELLED",
            "amount": 19.99,
        },
        correlation_field="correlation_id",
        bootstrap_servers=bootstrap_servers,
        timeout_ms=10000,
    )

    assert result.passed, result.issues
