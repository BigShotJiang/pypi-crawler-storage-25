from __future__ import annotations

import json
import os
import time
import uuid
from io import BytesIO
from pathlib import Path
from typing import Any

import httpx
import pytest
from confluent_kafka import Producer
from confluent_kafka.admin import AdminClient, NewTopic
from fastavro import parse_schema, schemaless_writer

BOOTSTRAP_SERVERS = os.getenv("PKCT_BOOTSTRAP_SERVERS", "localhost:19092")
SCHEMA_REGISTRY_URL = os.getenv("PKCT_SCHEMA_REGISTRY_URL", "http://localhost:8081")


def integration_enabled() -> bool:
    return os.getenv("PKCT_RUN_INTEGRATION") == "1"


def pytest_collection_modifyitems(items: list[pytest.Item]) -> None:
    if integration_enabled():
        return
    skip = pytest.mark.skip(reason="integration tests require Kafka/Schema Registry")
    integration_dir = Path(__file__).parent.resolve()
    for item in items:
        if integration_dir in Path(str(item.path)).resolve().parents:
            item.add_marker(skip)


@pytest.fixture
def unique_topic() -> str:
    return f"pkct-test-{uuid.uuid4().hex}"


@pytest.fixture
def bootstrap_servers() -> str:
    return BOOTSTRAP_SERVERS


@pytest.fixture
def schema_registry_url() -> str:
    return SCHEMA_REGISTRY_URL


def wait_for_schema_registry(registry_url: str, timeout_seconds: int = 30) -> None:
    deadline = time.time() + timeout_seconds
    last_error: Exception | None = None

    while time.time() < deadline:
        try:
            response = httpx.get(f"{registry_url}/subjects", timeout=2)
            if response.status_code == 200:
                return
        except Exception as exc:
            last_error = exc

        time.sleep(1)

    raise RuntimeError(f"Schema Registry not ready at {registry_url}: {last_error}")


def produce_json_message(
    bootstrap_servers: str,
    topic: str,
    payload: dict[str, Any],
) -> None:
    producer = Producer({"bootstrap.servers": bootstrap_servers})
    producer.produce(topic, json.dumps(payload).encode("utf-8"))
    producer.flush(10)


def create_kafka_topics(
    bootstrap_servers: str,
    topics: list[str],
    timeout_seconds: int = 30,
) -> None:
    admin = AdminClient({"bootstrap.servers": bootstrap_servers})
    futures = admin.create_topics(
        [NewTopic(topic, num_partitions=1, replication_factor=1) for topic in topics]
    )

    for topic, future in futures.items():
        try:
            future.result(timeout=timeout_seconds)
        except Exception as exc:
            if "TOPIC_ALREADY_EXISTS" not in str(exc):
                raise RuntimeError(f"Could not create Kafka topic {topic}") from exc


def register_avro_schema(
    registry_url: str,
    subject: str,
    schema: dict[str, Any],
) -> int:
    response = httpx.post(
        f"{registry_url}/subjects/{subject}/versions",
        json={
            "schemaType": "AVRO",
            "schema": json.dumps(schema),
        },
        timeout=10,
    )

    response.raise_for_status()
    return int(response.json()["id"])


def build_confluent_avro_message(
    schema_id: int,
    schema: dict[str, Any],
    record: dict[str, Any],
) -> bytes:
    buffer = BytesIO()
    schemaless_writer(buffer, parse_schema(schema), record)

    return b"\x00" + schema_id.to_bytes(4, byteorder="big") + buffer.getvalue()


def produce_avro_message(
    bootstrap_servers: str,
    topic: str,
    schema_id: int,
    schema: dict[str, Any],
    record: dict[str, Any],
) -> None:
    value = build_confluent_avro_message(schema_id, schema, record)

    producer = Producer({"bootstrap.servers": bootstrap_servers})
    producer.produce(topic, value=value)
    producer.flush(10)
