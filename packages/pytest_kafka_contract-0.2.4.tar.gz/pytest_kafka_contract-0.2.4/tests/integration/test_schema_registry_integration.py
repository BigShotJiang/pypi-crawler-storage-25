import json

import httpx

from pytest_kafka_contract.schema_registry import validate_schema_registry_subject
from tests.integration.conftest import register_avro_schema, wait_for_schema_registry


def test_real_schema_registry_connection(schema_registry_url):
    wait_for_schema_registry(schema_registry_url)

    response = httpx.get(f"{schema_registry_url}/subjects", timeout=10)

    assert response.status_code == 200
    assert isinstance(response.json(), list)


def test_real_schema_registry_register_and_fetch(schema_registry_url):
    wait_for_schema_registry(schema_registry_url)

    subject = "orders.created-value"
    schema = {
        "type": "record",
        "name": "OrderCreated",
        "namespace": "com.example.orders",
        "fields": [
            {"name": "event_id", "type": "string"},
            {"name": "order_id", "type": "string"},
            {"name": "total", "type": "double"},
        ],
    }

    schema_id = register_avro_schema(
        registry_url=schema_registry_url,
        subject=subject,
        schema=schema,
    )
    latest_response = httpx.get(
        f"{schema_registry_url}/subjects/{subject}/versions/latest",
        timeout=10,
    )

    assert latest_response.status_code == 200

    latest = latest_response.json()

    assert latest["subject"] == subject
    assert latest["id"] == schema_id
    assert "version" in latest
    assert json.loads(latest["schema"])["name"] == "OrderCreated"


def test_schema_registry_subject_validation_passes_for_registered_schema(
    tmp_path,
    unique_topic,
    schema_registry_url,
):
    wait_for_schema_registry(schema_registry_url)
    subject = f"{unique_topic}-value"
    schema = {
        "type": "record",
        "name": "OrderCreated",
        "namespace": "com.example.orders",
        "fields": [
            {"name": "event_id", "type": "string"},
            {"name": "order_id", "type": "string"},
            {"name": "total", "type": "double"},
        ],
    }
    schema_path = tmp_path / "order-created.avsc"
    schema_path.write_text(json.dumps(schema), encoding="utf-8")
    schema_id = register_avro_schema(
        registry_url=schema_registry_url,
        subject=subject,
        schema=schema,
    )

    result = validate_schema_registry_subject(
        registry_url=schema_registry_url,
        subject=subject,
        schema_path=schema_path,
        compatibility="BACKWARD",
    )

    assert result.passed, result.issues
    assert result.metadata["schema_id"] == schema_id


def test_schema_registry_subject_validation_fails_for_missing_subject(
    tmp_path,
    unique_topic,
    schema_registry_url,
):
    wait_for_schema_registry(schema_registry_url)
    schema_path = tmp_path / "order-created.avsc"
    schema_path.write_text(
        json.dumps(
            {
                "type": "record",
                "name": "OrderCreated",
                "fields": [{"name": "event_id", "type": "string"}],
            }
        ),
        encoding="utf-8",
    )

    result = validate_schema_registry_subject(
        registry_url=schema_registry_url,
        subject=f"{unique_topic}-missing-value",
        schema_path=schema_path,
    )

    assert not result.passed
    assert result.issues[0].code == "REGISTRY_SUBJECT_NOT_FOUND"
