from __future__ import annotations

import os
import time

import pytest

from tests.integration.apps import OrderFilterApp
from tests.integration.conftest import create_kafka_topics


pytestmark = pytest.mark.integration


def _skip_unless_integration() -> None:
    if os.getenv("PKCT_RUN_INTEGRATION") != "1":
        pytest.skip("set PKCT_RUN_INTEGRATION=1 to run Kafka integration tests")


@pytest.fixture
def flow_topics(unique_topic: str) -> tuple[str, str]:
    return f"{unique_topic}.source", f"{unique_topic}.destination"


@pytest.fixture
def order_filter_app(bootstrap_servers: str, flow_topics: tuple[str, str]) -> OrderFilterApp:
    _skip_unless_integration()
    source_topic, destination_topic = flow_topics
    create_kafka_topics(bootstrap_servers, [source_topic, destination_topic])
    app = OrderFilterApp(
        bootstrap_servers=bootstrap_servers,
        source_topic=source_topic,
        destination_topic=destination_topic,
    )
    app.start()
    time.sleep(1)
    yield app
    app.stop()


def test_real_json_flow_positive_with_contract(
    kafka_contract,
    order_filter_app: OrderFilterApp,
    bootstrap_servers: str,
    flow_topics: tuple[str, str],
    tmp_path,
) -> None:
    source_topic, destination_topic = flow_topics
    contract_path = tmp_path / "paid-order.yaml"
    contract_path.write_text(
        """
version: 1
name: paid-order
topic: dest.orders
message:
  type: object
  required: [correlation_id, order_id, status, amount]
  properties:
    correlation_id:
      type: string
    order_id:
      type: string
    status:
      type: string
      const: PAID
    amount:
      type: number
rules:
  allow_extra_fields: true
""",
        encoding="utf-8",
    )

    result = kafka_contract.run_json_flow(
        source_topic=source_topic,
        destination_topic=destination_topic,
        payload={"order_id": "ord_123", "status": "PAID", "amount": 49.99},
        expect={"status": "PAID", "amount": 49.99},
        contract_path=str(contract_path),
        bootstrap_servers=bootstrap_servers,
        timeout_ms=30000,
    )

    assert result.passed, result.issues


def test_real_json_flow_negative_no_message(
    kafka_contract,
    order_filter_app: OrderFilterApp,
    bootstrap_servers: str,
    flow_topics: tuple[str, str],
) -> None:
    source_topic, destination_topic = flow_topics

    result = kafka_contract.expect_no_json_flow(
        source_topic=source_topic,
        destination_topic=destination_topic,
        payload={"order_id": "ord_456", "status": "CANCELLED", "amount": 19.99},
        bootstrap_servers=bootstrap_servers,
        timeout_ms=10000,
    )

    assert result.passed, result.issues


def test_real_json_flow_contract_failure(
    kafka_contract,
    order_filter_app: OrderFilterApp,
    bootstrap_servers: str,
    flow_topics: tuple[str, str],
    tmp_path,
) -> None:
    source_topic, destination_topic = flow_topics
    contract_path = tmp_path / "paid-order.yaml"
    contract_path.write_text(
        """
version: 1
name: paid-order
topic: dest.orders
message:
  type: object
  required: [amount]
  properties:
    amount:
      type: number
rules:
  allow_extra_fields: true
""",
        encoding="utf-8",
    )

    result = kafka_contract.run_json_flow(
        source_topic=source_topic,
        destination_topic=destination_topic,
        payload={"order_id": "ord_bad", "status": "PAID", "amount": "49.99"},
        contract_path=str(contract_path),
        bootstrap_servers=bootstrap_servers,
        timeout_ms=30000,
    )

    assert not result.passed
    assert any(issue.code == "FLOW_CONTRACT_FAILED" for issue in result.issues)
