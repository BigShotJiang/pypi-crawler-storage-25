from __future__ import annotations

import os
import threading
import time
from typing import Any

import pytest

from pytest_kafka_contract.avro import _decode_confluent_avro, _encode_confluent_avro
from pytest_kafka_contract.config import RuntimeConfig
from pytest_kafka_contract.flow_runner import KafkaFlowRunner
from pytest_kafka_contract.utils import require_confluent_kafka
from tests.integration.conftest import (
    create_kafka_topics,
    register_avro_schema,
    wait_for_schema_registry,
)


pytestmark = pytest.mark.integration


def _skip_unless_integration() -> None:
    if os.getenv("PKCT_RUN_INTEGRATION") != "1":
        pytest.skip("set PKCT_RUN_INTEGRATION=1 to run Kafka integration tests")


@pytest.fixture
def flow_topics(unique_topic: str) -> tuple[str, str]:
    return f"{unique_topic}.source", f"{unique_topic}.destination"


def _order_schema(name: str = "OrderEvent") -> dict[str, Any]:
    return {
        "type": "record",
        "name": name,
        "namespace": "com.example.orders",
        "fields": [
            {"name": "correlation_id", "type": "string"},
            {"name": "order_id", "type": "string"},
            {"name": "status", "type": "string"},
        ],
    }


def _order_schema_with_amount() -> dict[str, Any]:
    schema = _order_schema("OrderEventWithAmount")
    schema["fields"] = [*schema["fields"], {"name": "amount", "type": "double"}]
    return schema


class AvroForwarder:
    def __init__(
        self,
        *,
        bootstrap_servers: str,
        registry_url: str,
        source_topic: str,
        destination_topic: str,
        destination_schema_id: int,
        destination_schema: dict[str, Any],
    ) -> None:
        self.bootstrap_servers = bootstrap_servers
        self.registry_url = registry_url
        self.source_topic = source_topic
        self.destination_topic = destination_topic
        self.destination_schema_id = destination_schema_id
        self.destination_schema = destination_schema
        self.running = False
        self.thread: threading.Thread | None = None

    def start(self) -> None:
        self.running = True
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def stop(self) -> None:
        self.running = False
        if self.thread:
            self.thread.join(timeout=5)

    def _run(self) -> None:
        confluent_kafka = require_confluent_kafka()
        consumer = confluent_kafka.Consumer(
            {
                "bootstrap.servers": self.bootstrap_servers,
                "group.id": f"avro-forwarder-{self.source_topic}",
                "auto.offset.reset": "earliest",
                "enable.auto.commit": False,
            }
        )
        producer = confluent_kafka.Producer({"bootstrap.servers": self.bootstrap_servers})
        consumer.subscribe([self.source_topic])

        try:
            while self.running:
                msg = consumer.poll(0.2)
                if msg is None or msg.error():
                    continue
                record, _schema_id = _decode_confluent_avro(msg.value(), self.registry_url)
                if record.get("status") == "PAID":
                    producer.produce(
                        self.destination_topic,
                        key=msg.key(),
                        value=_encode_confluent_avro(
                            record,
                            self.destination_schema_id,
                            self.destination_schema,
                        ),
                    )
                    producer.flush(10)
        finally:
            consumer.close()


def test_real_avro_flow_positive(
    bootstrap_servers: str,
    schema_registry_url: str,
    flow_topics: tuple[str, str],
    unique_topic: str,
) -> None:
    _skip_unless_integration()
    wait_for_schema_registry(schema_registry_url)
    source_topic, destination_topic = flow_topics
    create_kafka_topics(bootstrap_servers, [source_topic, destination_topic])
    schema = _order_schema()
    source_subject = f"{unique_topic}.source-value"
    destination_subject = f"{unique_topic}.destination-value"
    source_schema_id = register_avro_schema(schema_registry_url, source_subject, schema)
    destination_schema_id = register_avro_schema(schema_registry_url, destination_subject, schema)
    assert source_schema_id > 0

    forwarder = AvroForwarder(
        bootstrap_servers=bootstrap_servers,
        registry_url=schema_registry_url,
        source_topic=source_topic,
        destination_topic=destination_topic,
        destination_schema_id=destination_schema_id,
        destination_schema=schema,
    )
    forwarder.start()
    time.sleep(1)
    try:
        result = KafkaFlowRunner(
            RuntimeConfig(contract_paths=[], bootstrap_servers=bootstrap_servers, timeout_ms=30000)
        ).run_avro_flow(
            source_topic=source_topic,
            destination_topic=destination_topic,
            payload={"correlation_id": "cid-avro-1", "order_id": "ord_1", "status": "PAID"},
            registry_url=schema_registry_url,
            source_subject=source_subject,
            destination_subject=destination_subject,
            expect={"correlation_id": "cid-avro-1", "status": "PAID"},
            correlation_id="cid-avro-1",
            bootstrap_servers=bootstrap_servers,
            timeout_ms=30000,
        )
    finally:
        forwarder.stop()

    assert result.passed, result.issues
    assert result.metadata["destination_schema_id"] == destination_schema_id


def test_real_avro_flow_destination_schema_failure(
    bootstrap_servers: str,
    schema_registry_url: str,
    flow_topics: tuple[str, str],
    unique_topic: str,
) -> None:
    _skip_unless_integration()
    wait_for_schema_registry(schema_registry_url)
    source_topic, destination_topic = flow_topics
    create_kafka_topics(bootstrap_servers, [source_topic, destination_topic])
    source_schema = _order_schema()
    destination_schema = _order_schema_with_amount()
    source_subject = f"{unique_topic}.source-value"
    destination_subject = f"{unique_topic}.destination-value"
    source_schema_id = register_avro_schema(schema_registry_url, source_subject, source_schema)
    register_avro_schema(schema_registry_url, destination_subject, destination_schema)

    forwarder = AvroForwarder(
        bootstrap_servers=bootstrap_servers,
        registry_url=schema_registry_url,
        source_topic=source_topic,
        destination_topic=destination_topic,
        destination_schema_id=source_schema_id,
        destination_schema=source_schema,
    )
    forwarder.start()
    time.sleep(1)
    try:
        result = KafkaFlowRunner(
            RuntimeConfig(contract_paths=[], bootstrap_servers=bootstrap_servers, timeout_ms=30000)
        ).run_avro_flow(
            source_topic=source_topic,
            destination_topic=destination_topic,
            payload={"correlation_id": "cid-avro-2", "order_id": "ord_2", "status": "PAID"},
            registry_url=schema_registry_url,
            source_subject=source_subject,
            destination_subject=destination_subject,
            correlation_id="cid-avro-2",
            bootstrap_servers=bootstrap_servers,
            timeout_ms=30000,
        )
    finally:
        forwarder.stop()

    assert not result.passed
    assert any(issue.code == "FLOW_CONTRACT_FAILED" for issue in result.issues)


def test_real_avro_flow_missing_subject_returns_clean_failure(
    bootstrap_servers: str,
    schema_registry_url: str,
    flow_topics: tuple[str, str],
    unique_topic: str,
) -> None:
    _skip_unless_integration()
    wait_for_schema_registry(schema_registry_url)
    source_topic, destination_topic = flow_topics

    result = KafkaFlowRunner(
        RuntimeConfig(contract_paths=[], bootstrap_servers=bootstrap_servers, timeout_ms=1000)
    ).run_avro_flow(
        source_topic=source_topic,
        destination_topic=destination_topic,
        payload={"correlation_id": "cid-avro-missing", "order_id": "ord_3", "status": "PAID"},
        registry_url=schema_registry_url,
        source_subject=f"{unique_topic}.missing-source-value",
        destination_subject=f"{unique_topic}.missing-destination-value",
        correlation_id="cid-avro-missing",
        bootstrap_servers=bootstrap_servers,
        timeout_ms=1000,
    )

    assert not result.passed
    assert result.issues[0].code == "REGISTRY_SUBJECT_NOT_FOUND"
