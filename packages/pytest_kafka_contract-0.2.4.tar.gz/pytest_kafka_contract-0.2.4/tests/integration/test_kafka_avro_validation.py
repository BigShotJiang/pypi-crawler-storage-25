from pytest_kafka_contract.kafka_validation import validate_latest_avro
from tests.integration.conftest import (
    produce_avro_message,
    register_avro_schema,
    wait_for_schema_registry,
)


def test_real_kafka_avro_message_validation(
    unique_topic,
    bootstrap_servers,
    schema_registry_url,
):
    wait_for_schema_registry(schema_registry_url)
    subject = f"{unique_topic}-value"
    schema = {
        "type": "record",
        "name": "OrderCreated",
        "namespace": "com.example.orders",
        "fields": [
            {"name": "event_id", "type": "string"},
            {"name": "order_id", "type": "string"},
            {"name": "total", "type": "double"},
            {
                "name": "currency",
                "type": {
                    "type": "enum",
                    "name": "Currency",
                    "symbols": ["USD", "CAD", "EUR"],
                },
                "default": "USD",
            },
        ],
    }
    record = {
        "event_id": "evt_1",
        "order_id": "ord_1",
        "total": 20.0,
        "currency": "USD",
    }
    schema_id = register_avro_schema(
        registry_url=schema_registry_url,
        subject=subject,
        schema=schema,
    )
    produce_avro_message(
        bootstrap_servers=bootstrap_servers,
        topic=unique_topic,
        schema_id=schema_id,
        schema=schema,
        record=record,
    )

    result = validate_latest_avro(
        topic=unique_topic,
        registry_url=schema_registry_url,
        subject=subject,
        bootstrap_servers=bootstrap_servers,
        timeout_ms=10000,
        expected_schema_id=schema_id,
        auto_offset_reset="earliest",
    )

    assert result.passed, result.issues
    assert result.metadata["topic"] == unique_topic
    assert result.metadata["format"] == "avro"
    assert result.metadata["schema_id"] == schema_id
    assert result.metadata["record"]["event_id"] == "evt_1"
