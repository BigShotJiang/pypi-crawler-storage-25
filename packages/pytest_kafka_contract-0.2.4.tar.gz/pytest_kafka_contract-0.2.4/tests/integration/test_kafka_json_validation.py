from pytest_kafka_contract.kafka_validation import validate_latest_json
from tests.integration.conftest import produce_json_message, wait_for_schema_registry


def test_real_kafka_json_message_validation(
    tmp_path,
    unique_topic,
    bootstrap_servers,
    schema_registry_url,
):
    wait_for_schema_registry(schema_registry_url)
    contract_path = tmp_path / "order-created.yaml"
    contract_path.write_text(
        """
version: 1
name: order-created-v1
topic: orders.created
message:
  type: object
  required:
    - event_id
    - event_type
    - order
  properties:
    event_id:
      type: string
    event_type:
      type: string
      const: OrderCreated
    order:
      type: object
      required:
        - order_id
        - total
      properties:
        order_id:
          type: string
        total:
          type: number
rules:
  allow_extra_fields: true
""",
        encoding="utf-8",
    )

    payload = {
        "event_id": "evt_1",
        "event_type": "OrderCreated",
        "order": {
            "order_id": "ord_1",
            "total": 20.0,
        },
    }

    produce_json_message(
        bootstrap_servers=bootstrap_servers,
        topic=unique_topic,
        payload=payload,
    )

    result = validate_latest_json(
        topic=unique_topic,
        contract_path=contract_path,
        bootstrap_servers=bootstrap_servers,
        timeout_ms=10000,
        auto_offset_reset="earliest",
    )

    assert result.passed, result.issues
    assert result.metadata["topic"] == unique_topic
    assert result.metadata["format"] == "json"


def test_real_kafka_json_message_validation_returns_contract_issue(
    tmp_path,
    unique_topic,
    bootstrap_servers,
    schema_registry_url,
):
    wait_for_schema_registry(schema_registry_url)
    contract_path = tmp_path / "order-created.yaml"
    contract_path.write_text(
        """
version: 1
name: order-created-v1
topic: orders.created
message:
  type: object
  required:
    - order
  properties:
    order:
      type: object
      required:
        - total
      properties:
        total:
          type: number
rules:
  allow_extra_fields: true
""",
        encoding="utf-8",
    )

    produce_json_message(
        bootstrap_servers=bootstrap_servers,
        topic=unique_topic,
        payload={"order": {"total": "20.0"}},
    )

    result = validate_latest_json(
        topic=unique_topic,
        contract_path=contract_path,
        bootstrap_servers=bootstrap_servers,
        timeout_ms=10000,
        auto_offset_reset="earliest",
    )

    assert not result.passed
    assert any(issue.code == "TYPE_MISMATCH" for issue in result.issues)
