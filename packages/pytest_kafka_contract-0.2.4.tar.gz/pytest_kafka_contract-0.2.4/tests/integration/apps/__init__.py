from __future__ import annotations

import json
import threading

from pytest_kafka_contract.utils import require_confluent_kafka


class OrderFilterApp:
    """Minimal test app: consumes src topic, forwards PAID orders to dest topic.

    Only used in integration tests to prove flow testing works.
    Not product code.
    """

    def __init__(
        self,
        bootstrap_servers: str,
        source_topic: str,
        destination_topic: str,
    ) -> None:
        self.bootstrap_servers = bootstrap_servers
        self.source_topic = source_topic
        self.destination_topic = destination_topic
        self.running = False
        self.thread: threading.Thread | None = None

    def start(self) -> None:
        self.running = True
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def stop(self) -> None:
        self.running = False
        if self.thread:
            self.thread.join(timeout=5)

    def _run(self) -> None:
        confluent_kafka = require_confluent_kafka()
        consumer = confluent_kafka.Consumer(
            {
                "bootstrap.servers": self.bootstrap_servers,
                "group.id": "order-filter-app-test",
                "auto.offset.reset": "earliest",
                "enable.auto.commit": False,
            }
        )
        producer = confluent_kafka.Producer({"bootstrap.servers": self.bootstrap_servers})
        consumer.subscribe([self.source_topic])

        try:
            while self.running:
                msg = consumer.poll(0.2)
                if msg is None or msg.error():
                    continue

                event = json.loads(msg.value().decode("utf-8"))

                if event.get("status") == "PAID":
                    producer.produce(
                        self.destination_topic,
                        key=msg.key(),
                        value=json.dumps(event).encode("utf-8"),
                    )
                    producer.flush()
        finally:
            consumer.close()
