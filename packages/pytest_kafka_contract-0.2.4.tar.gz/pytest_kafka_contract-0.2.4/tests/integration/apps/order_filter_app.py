"""Order filter app for integration tests."""

from tests.integration.apps import OrderFilterApp

__all__ = ["OrderFilterApp"]
