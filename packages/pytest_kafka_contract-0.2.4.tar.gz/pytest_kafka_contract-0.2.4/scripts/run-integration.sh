#!/usr/bin/env bash
set -euo pipefail

export PKCT_BOOTSTRAP_SERVERS="${PKCT_BOOTSTRAP_SERVERS:-localhost:19092}"
export PKCT_SCHEMA_REGISTRY_URL="${PKCT_SCHEMA_REGISTRY_URL:-http://localhost:8081}"

cleanup() {
  docker compose -f docker-compose.integration.yml down -v
}
trap cleanup EXIT

docker compose -f docker-compose.integration.yml up -d
sleep 10
PKCT_RUN_INTEGRATION=1 pytest tests/integration -q -s
