#!/usr/bin/env bash
set -euo pipefail

rm -rf dist build *.egg-info src/*.egg-info .pytest_cache

python -m pip install --upgrade build twine

pytest -q

docker compose -f docker-compose.integration.yml up -d
trap 'docker compose -f docker-compose.integration.yml down -v' EXIT
PKCT_RUN_INTEGRATION=1 pytest -q

ruff check .
mypy src

python -m build
python -m twine check dist/*

python3 -m venv /tmp/pkct-prepublish-wheel
source /tmp/pkct-prepublish-wheel/bin/activate
python -m pip install --upgrade pip
WHEEL="$(ls dist/*.whl)"
python -m pip install "${WHEEL}[all]"
python -c "import pytest_kafka_contract; print('import ok')"
kafka-contract --help
pytest --help | grep kafka
deactivate

echo "prepublish ok"
