#!/usr/bin/env bash
set -euo pipefail

rm -rf .venv
python3 -m venv .venv
source .venv/bin/activate

python3 -m pip install --upgrade pip
python3 -m pip install -e ".[dev]"

pytest
pytest --cov=pytest_kafka_contract --cov-report=term-missing
ruff check .
mypy src

pytest --help | grep kafka
pytest --trace-config | grep -E "pytest_kafka_contract|kafka_contract"
pytest-kafka-contract --help

rm -rf dist build *.egg-info src/*.egg-info
python3 -m build
python3 -m twine check dist/*

rm -rf /tmp/pkct-wheel-test
python3 -m venv /tmp/pkct-wheel-test
source /tmp/pkct-wheel-test/bin/activate
python3 -m pip install --upgrade pip
WHEEL="$(find "$(pwd)/dist" -name '*.whl' -print -quit)"
python3 -m pip install "${WHEEL}[all]"
python3 -c "import pytest_kafka_contract; print('wheel import ok')"
pytest-kafka-contract --help
rm -rf /tmp/pkct-trace
mkdir -p /tmp/pkct-trace
printf 'def test_empty():\n    pass\n' > /tmp/pkct-trace/test_empty.py
(cd /tmp/pkct-trace && pytest --help | grep kafka)
(cd /tmp/pkct-trace && pytest --trace-config | grep -E "pytest_kafka_contract|kafka_contract")

rm -rf /tmp/pkct-user-project
mkdir -p /tmp/pkct-user-project
cd /tmp/pkct-user-project
pytest-kafka-contract init
mkdir -p tests
cat > tests/test_order_created_contract.py <<'PY'
def test_order_created_contract(kafka_contract):
    result = kafka_contract.validate_payload(
        payload={
            "event_id": "evt_1",
            "event_type": "OrderCreated",
            "order": {"order_id": "ord_1", "total": 20.0},
        },
        contract_path="contracts/order-created.yaml",
    )
    assert result.passed, result.issues


def test_order_created_avro_contract(kafka_contract):
    result = kafka_contract.validate_avro_record(
        record={
            "event_id": "evt_1",
            "order_id": "ord_1",
            "total": 20.0,
            "currency": "USD",
        },
        schema_path="schemas/order-created.avsc",
    )
    assert result.passed, result.issues
PY
pytest -q

echo "LOCAL PREPUBLISH PASSED"
