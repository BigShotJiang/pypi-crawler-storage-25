# pytest-kafka-contract Patch Release + Publish Commands

Use this when releasing a patch version like:

```txt
0.1.0 -> 0.1.1
```

This file includes:

```txt
version bump
tests
integration tests
build
local wheel smoke test
TestPyPI publish
TestPyPI install test
real PyPI publish
real PyPI install test
git commit
git tag
```

---

## 0. Start from repo root

```bash
cd /Users/dharsanguruparan/Projects/python/kafka-pytest
git status
git pull origin main
```

---

## 1. Make sure publish env files exist

### TestPyPI env file

Create this only once:

```bash
cat > .env.testpypi <<'EOF'
TWINE_USERNAME=__token__
TWINE_PASSWORD=pypi-YOUR_TESTPYPI_TOKEN_HERE
TWINE_REPOSITORY=testpypi
EOF

chmod 600 .env.testpypi
```

### Real PyPI env file

Create this only once:

```bash
cat > .env.pypi <<'EOF'
TWINE_USERNAME=__token__
TWINE_PASSWORD=pypi-YOUR_REAL_PYPI_TOKEN_HERE
EOF

chmod 600 .env.pypi
```

### Make sure env files are ignored

```bash
grep -qxF ".env" .gitignore || echo ".env" >> .gitignore
grep -qxF ".env.*" .gitignore || echo ".env.*" >> .gitignore
```

Never commit `.env.testpypi` or `.env.pypi`.

---

## 2. Bump patch version by command

This updates `pyproject.toml` and writes the new version to `.release_version`.

```bash
python - <<'PY'
from pathlib import Path
import re

path = Path("pyproject.toml")
text = path.read_text()

match = re.search(r'(?m)^version\s*=\s*"(\d+)\.(\d+)\.(\d+)"', text)
if not match:
    raise SystemExit('Could not find version = "x.y.z" in pyproject.toml')

major, minor, patch = map(int, match.groups())
old_version = f"{major}.{minor}.{patch}"
new_version = f"{major}.{minor}.{patch + 1}"

text = re.sub(
    r'(?m)^version\s*=\s*"\d+\.\d+\.\d+"',
    f'version = "{new_version}"',
    text,
    count=1,
)

path.write_text(text)
Path(".release_version").write_text(new_version)

print(f"Bumped version: {old_version} -> {new_version}")
PY
```

Load version into shell:

```bash
VERSION="$(cat .release_version)"
echo "$VERSION"
grep 'version = ' pyproject.toml
```

---

## 3. Update changelog manually

```bash
code CHANGELOG.md
```

Add something like:

```md
## v0.1.1

### Fixed

- Patch release updates.

### Changed

- Documentation and release process updates.
```

---

## 4. Clean old build files

```bash
rm -rf dist build *.egg-info src/*.egg-info .pytest_cache
```

---

## 5. Run normal tests

```bash
pytest -q
```

Expected:

```txt
all passed
```

---

## 6. Run real Kafka integration tests

```bash
docker compose -f docker-compose.integration.yml up -d
PKCT_RUN_INTEGRATION=1 pytest -q
docker compose -f docker-compose.integration.yml down -v
```

Expected:

```txt
all passed
0 skipped
```

If Docker stays running after failure:

```bash
docker compose -f docker-compose.integration.yml down -v
```

---

## 7. Run quality checks

```bash
ruff check .
mypy src
```

---

## 8. Build package

```bash
python -m pip install --upgrade build twine
python -m build
```

Verify files:

```bash
ls -lah dist
```

Expected:

```txt
dist/pytest_kafka_contract-${VERSION}-py3-none-any.whl
dist/pytest_kafka_contract-${VERSION}.tar.gz
```

---

## 9. Check package metadata

```bash
python -m twine check dist/*
```

Expected:

```txt
PASSED
```

---

## 10. Local wheel smoke test

```bash
python3 -m venv /tmp/pkct-patch-wheel
source /tmp/pkct-patch-wheel/bin/activate

python -m pip install --upgrade pip
python -m pip install "$(pwd)"/dist/*.whl

python -c "import pytest_kafka_contract; print('import ok')"
kafka-contract --help
pytest --help | grep kafka

deactivate
```

If your CLI command is `pytest-kafka-contract` instead of `kafka-contract`, run:

```bash
pytest-kafka-contract --help
```

---

# PUBLISH STEP

This is the actual release flow:

```txt
TestPyPI first
install from TestPyPI
then real PyPI
install from real PyPI
```

---

## 11. Publish to TestPyPI

Load TestPyPI token from `.env.testpypi`:

```bash
set -a
source .env.testpypi
set +a
```

Upload:

```bash
python -m twine upload --repository testpypi dist/*
```

Clear token from shell:

```bash
unset TWINE_USERNAME TWINE_PASSWORD TWINE_REPOSITORY
```

If this fails with `File already exists`, you cannot reuse that version. Bump again and rebuild.

---

## 12. Test install from TestPyPI

Use a clean environment:

```bash
cd /tmp
rm -rf pkct-testpypi-patch
python3 -m venv pkct-testpypi-patch
source pkct-testpypi-patch/bin/activate

python -m pip install --upgrade pip
```

Install from TestPyPI:

```bash
python -m pip install \
  --index-url https://test.pypi.org/simple/ \
  --extra-index-url https://pypi.org/simple/ \
  "pytest-kafka-contract[all]==${VERSION}"
```

Smoke test:

```bash
python -c "import pytest_kafka_contract; print('testpypi import ok')"
kafka-contract --help
pytest --help | grep kafka
```

Fixture test:

```bash
mkdir -p /tmp/pkct-testpypi-user
cd /tmp/pkct-testpypi-user

cat > test_plugin_loads.py <<'EOF'
def test_plugin_loads(kafka_contract):
    assert kafka_contract is not None
EOF

pytest -q
```

Expected:

```txt
1 passed
```

Exit clean env:

```bash
deactivate
```

Go back to repo:

```bash
cd /Users/dharsanguruparan/Projects/python/kafka-pytest
VERSION="$(cat .release_version)"
echo "$VERSION"
```

---

## 13. Publish to real PyPI

Load real PyPI token from `.env.pypi`:

```bash
set -a
source .env.pypi
set +a
```

Upload:

```bash
python -m twine upload dist/*
```

Clear token from shell:

```bash
unset TWINE_USERNAME TWINE_PASSWORD
```

This publishes to real PyPI.

After this, users can install with:

```bash
pip install pytest-kafka-contract
```

---

## 14. Test install from real PyPI

Use a clean environment:

```bash
cd /tmp
rm -rf pkct-pypi-patch
python3 -m venv pkct-pypi-patch
source pkct-pypi-patch/bin/activate

python -m pip install --upgrade pip
python -m pip install "pytest-kafka-contract[all]==${VERSION}"
```

Smoke test:

```bash
python -c "import pytest_kafka_contract; print('real pypi import ok')"
kafka-contract --help
pytest --help | grep kafka
```

Fixture test:

```bash
mkdir -p /tmp/pkct-pypi-user
cd /tmp/pkct-pypi-user

cat > test_plugin_loads.py <<'EOF'
def test_plugin_loads(kafka_contract):
    assert kafka_contract is not None
EOF

pytest -q
```

Expected:

```txt
1 passed
```

Exit clean env:

```bash
deactivate
```

Go back to repo:

```bash
cd /Users/dharsanguruparan/Projects/python/kafka-pytest
VERSION="$(cat .release_version)"
echo "$VERSION"
```

---

## 15. Commit release changes

```bash
git status
git add pyproject.toml CHANGELOG.md README.md .gitignore
git commit -m "chore: release v${VERSION}"
```

If README did not change, this is okay:

```bash
git add pyproject.toml CHANGELOG.md .gitignore
git commit -m "chore: release v${VERSION}"
```

---

## 16. Tag release

```bash
git tag "v${VERSION}"
git push origin main
git push origin "v${VERSION}"
```

---

## 17. Final verify

```bash
python -m pip index versions pytest-kafka-contract
```

Or open the PyPI project page in browser.

---

## Emergency notes

### If TestPyPI upload fails because version exists

Bump again:

```bash
python - <<'PY'
from pathlib import Path
import re

path = Path("pyproject.toml")
text = path.read_text()

match = re.search(r'(?m)^version\s*=\s*"(\d+)\.(\d+)\.(\d+)"', text)
if not match:
    raise SystemExit('Could not find version = "x.y.z" in pyproject.toml')

major, minor, patch = map(int, match.groups())
old_version = f"{major}.{minor}.{patch}"
new_version = f"{major}.{minor}.{patch + 1}"

text = re.sub(
    r'(?m)^version\s*=\s*"\d+\.\d+\.\d+"',
    f'version = "{new_version}"',
    text,
    count=1,
)

path.write_text(text)
Path(".release_version").write_text(new_version)

print(f"Bumped version: {old_version} -> {new_version}")
PY

VERSION="$(cat .release_version)"
rm -rf dist build *.egg-info src/*.egg-info
python -m build
python -m twine check dist/*
```

Then retry TestPyPI publish.

### If real PyPI upload succeeds but package is broken

You cannot overwrite the same version.

Fix code.

Bump patch again.

Release new version.

### If token leaks

Immediately revoke token in PyPI/TestPyPI account settings.

Then create a new token.

---

## Full compact command flow

Use this after env files already exist:

```bash
cd /Users/dharsanguruparan/Projects/python/kafka-pytest
git status
git pull origin main

python - <<'PY'
from pathlib import Path
import re

path = Path("pyproject.toml")
text = path.read_text()
match = re.search(r'(?m)^version\s*=\s*"(\d+)\.(\d+)\.(\d+)"', text)
if not match:
    raise SystemExit('Could not find version = "x.y.z" in pyproject.toml')
major, minor, patch = map(int, match.groups())
old_version = f"{major}.{minor}.{patch}"
new_version = f"{major}.{minor}.{patch + 1}"
text = re.sub(r'(?m)^version\s*=\s*"\d+\.\d+\.\d+"', f'version = "{new_version}"', text, count=1)
path.write_text(text)
Path(".release_version").write_text(new_version)
print(f"Bumped version: {old_version} -> {new_version}")
PY

VERSION="$(cat .release_version)"
echo "Releasing $VERSION"

code CHANGELOG.md

rm -rf dist build *.egg-info src/*.egg-info .pytest_cache

pytest -q

docker compose -f docker-compose.integration.yml up -d
PKCT_RUN_INTEGRATION=1 pytest -q
docker compose -f docker-compose.integration.yml down -v

ruff check .
mypy src

python -m pip install --upgrade build twine
python -m build
python -m twine check dist/*

python3 -m venv /tmp/pkct-patch-wheel
source /tmp/pkct-patch-wheel/bin/activate
python -m pip install --upgrade pip
python -m pip install "$(pwd)"/dist/*.whl
python -c "import pytest_kafka_contract; print('import ok')"
kafka-contract --help
pytest --help | grep kafka
deactivate

set -a
source .env.testpypi
set +a
python -m twine upload --repository testpypi dist/*
unset TWINE_USERNAME TWINE_PASSWORD TWINE_REPOSITORY

cd /tmp
rm -rf pkct-testpypi-patch
python3 -m venv pkct-testpypi-patch
source pkct-testpypi-patch/bin/activate
python -m pip install --upgrade pip
python -m pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ "pytest-kafka-contract[all]==${VERSION}"
python -c "import pytest_kafka_contract; print('testpypi import ok')"
kafka-contract --help
pytest --help | grep kafka
deactivate

cd /Users/dharsanguruparan/Projects/python/kafka-pytest
VERSION="$(cat .release_version)"

set -a
source .env.pypi
set +a
python -m twine upload dist/*
unset TWINE_USERNAME TWINE_PASSWORD

cd /tmp
rm -rf pkct-pypi-patch
python3 -m venv pkct-pypi-patch
source pkct-pypi-patch/bin/activate
python -m pip install --upgrade pip
python -m pip install "pytest-kafka-contract[all]==${VERSION}"
python -c "import pytest_kafka_contract; print('real pypi import ok')"
kafka-contract --help
pytest --help | grep kafka
deactivate

cd /Users/dharsanguruparan/Projects/python/kafka-pytest
VERSION="$(cat .release_version)"

git status
git add pyproject.toml CHANGELOG.md README.md .gitignore
git commit -m "chore: release v${VERSION}"
git tag "v${VERSION}"
git push origin main
git push origin "v${VERSION}"
```
