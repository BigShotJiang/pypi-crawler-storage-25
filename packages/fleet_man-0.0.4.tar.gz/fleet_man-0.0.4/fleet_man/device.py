"""
process_manager.py
──────────────────
FastAPI-based script control panel with WebSocket log streaming.
Each Pi runs one instance; browser connects directly.

Set COORDINATOR_URL to auto-register with a fleet coordinator on startup.
If unset, the Pi runs fully standalone — no coordinator needed.

Usage:
    from process_manager import ProcessManager, ScriptSpec
    from pathlib import Path

    manager = ProcessManager(
        name="pi-kitchen",
        log_dir=Path("/var/log/jobs"),
        coordinator_url="http://192.168.1.10:9000",  # optional
        port=5001,
        scripts={
            "pipeline": ScriptSpec("data_pipeline", ["python3", "jobs/pipeline.py"]),
            "server":   ScriptSpec("api_server",    ["python3", "jobs/server.py"]),
            "backup":   ScriptSpec("backup",        ["bash",    "jobs/backup.sh"]),
        }
    )

    app = manager.create_app()

    if __name__ == "__main__":
        import uvicorn
        uvicorn.run(app, host="0.0.0.0", port=5001)

Parameters:
    name             Node name shown in the UI and reported to the coordinator
    log_dir          Directory where .log files are written
    coordinator_url  Optional URL of a fleet coordinator — omit for standalone mode
    host             LAN IP to advertise to the coordinator (auto-detected if omitted)
    port             Port this Pi is listening on (used for coordinator registration)
"""

from __future__ import annotations

import asyncio
import collections
import json
import socket
from datetime import datetime
from pathlib import Path
from typing import Callable, Deque, Dict, List, Optional, Sequence, Set, Union

import httpx
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, PlainTextResponse

CommandType = Union[Sequence[str], Callable[[], Sequence[str]]]

LOG_BUFFER_LINES    = 500   # lines kept in memory per script
HEARTBEAT_INTERVAL  = 30.0  # seconds between coordinator re-registrations
REGISTER_TIMEOUT    = 5.0   # http timeout for registration calls


def _local_ip() -> str:
    """Best-effort LAN IP detection."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        try:
            s.close()
        except Exception:
            pass


# ─────────────────────────────────────────────
# ScriptSpec
# ─────────────────────────────────────────────

class ScriptSpec:
    """Describes a runnable script."""

    def __init__(self, label: str, cmd: CommandType):
        self.label = label
        self.cmd = cmd

    def resolve_cmd(self) -> List[str]:
        return list(self.cmd() if callable(self.cmd) else self.cmd)


# ─────────────────────────────────────────────
# ScriptRunner  (per-script state)
# ─────────────────────────────────────────────

class ScriptRunner:
    def __init__(self, key: str, spec: ScriptSpec, log_dir: Path):
        self.key = key
        self.spec = spec
        self.log_dir = log_dir
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.log_path = log_dir / f"{key}.log"

        self._proc: Optional[asyncio.subprocess.Process] = None
        self._task: Optional[asyncio.Task] = None
        self._buffer: Deque[dict] = collections.deque(maxlen=LOG_BUFFER_LINES)
        self._subscribers: Set[WebSocket] = set()
        self._lock = asyncio.Lock()

    # ── status ──────────────────────────────

    @property
    def running(self) -> bool:
        return self._proc is not None and self._proc.returncode is None

    @property
    def pid(self) -> Optional[int]:
        return self._proc.pid if self.running else None

    def status_dict(self) -> dict:
        return {
            "key": self.key,
            "label": self.spec.label,
            "status": "running" if self.running else "stopped",
            "pid": self.pid,
        }

    # ── log helpers ──────────────────────────

    def _make_entry(self, text: str, stream: str = "stdout") -> dict:
        return {
            "ts": datetime.now().strftime("%H:%M:%S"),
            "stream": stream,
            "text": text,
        }

    async def _append(self, entry: dict) -> None:
        self._buffer.append(entry)
        try:
            with open(self.log_path, "a", errors="replace") as f:
                f.write(f"[{entry['ts']}] {entry['text']}\n")
        except OSError:
            pass
        msg = json.dumps({"type": "log", "key": self.key, **entry})
        dead = set()
        for ws in self._subscribers:
            try:
                await ws.send_text(msg)
            except Exception:
                dead.add(ws)
        self._subscribers -= dead

    def subscribe(self, ws: WebSocket) -> None:
        self._subscribers.add(ws)

    def unsubscribe(self, ws: WebSocket) -> None:
        self._subscribers.discard(ws)

    def buffered_log(self) -> List[dict]:
        return list(self._buffer)

    # ── lifecycle ────────────────────────────

    async def start(self) -> str:
        async with self._lock:
            if self.running:
                return "already running"
            try:
                cmd = self.spec.resolve_cmd()
                self._proc = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                self._task = asyncio.create_task(self._read_output())
                await self._append(self._make_entry(f"started: {' '.join(cmd)}", "system"))
                return "started"
            except Exception as e:
                return f"error: {e}"

    async def stop(self) -> str:
        async with self._lock:
            if not self.running:
                return "not running"
            try:
                self._proc.terminate()
                try:
                    await asyncio.wait_for(self._proc.wait(), timeout=5.0)
                except asyncio.TimeoutError:
                    self._proc.kill()
                    await self._proc.wait()
                await self._append(self._make_entry("stopped", "system"))
                return "stopped"
            except Exception as e:
                return f"error: {e}"
            finally:
                self._proc = None
                if self._task:
                    self._task.cancel()
                    self._task = None

    async def _read_output(self) -> None:
        async def drain(stream, stream_name):
            try:
                async for raw in stream:
                    line = raw.decode(errors="replace").rstrip()
                    if line:
                        await self._append(self._make_entry(line, stream_name))
            except Exception:
                pass

        if self._proc:
            await asyncio.gather(
                drain(self._proc.stdout, "stdout"),
                drain(self._proc.stderr, "stderr"),
            )
            rc = self._proc.returncode if self._proc else None
            await self._append(self._make_entry(f"exited with code {rc}", "system"))
            self._proc = None


# ─────────────────────────────────────────────
# ProcessManager
# ─────────────────────────────────────────────

class ProcessManager:
    def __init__(
        self,
        scripts: Dict[str, ScriptSpec],
        name: str = "pi",
        log_dir: Path = Path("/tmp/process_manager_logs"),
        coordinator_url: Optional[str] = None,
        host: Optional[str] = None,
        port: int = 8000,
    ):
        self.name = name
        self.log_dir = log_dir
        self.coordinator_url = coordinator_url.rstrip("/") if coordinator_url else None
        self.host = host or _local_ip()
        self.port = port
        self.runners: Dict[str, ScriptRunner] = {
            key: ScriptRunner(key, spec, log_dir)
            for key, spec in scripts.items()
        }

    def create_app(self) -> FastAPI:
        app = FastAPI(title=f"process manager — {self.name}")

        # ── coordinator registration ─────────

        coordinator_url = self.coordinator_url
        pi_host = self.host
        pi_port = self.port

        async def _register_once(client: httpx.AsyncClient) -> bool:
            try:
                r = await client.post(
                    f"{coordinator_url}/register",
                    json={"name": self.name, "host": pi_host, "port": pi_port},
                    timeout=REGISTER_TIMEOUT,
                )
                return r.is_success
            except Exception:
                return False

        async def _heartbeat_loop() -> None:
            async with httpx.AsyncClient() as client:
                while True:
                    await _register_once(client)
                    await asyncio.sleep(HEARTBEAT_INTERVAL)

        @app.on_event("startup")
        async def _startup() -> None:
            if not coordinator_url:
                return
            # attempt immediate registration, then keep re-registering
            async with httpx.AsyncClient() as client:
                ok = await _register_once(client)
                if ok:
                    print(f"[pm] registered with coordinator at {coordinator_url}")
                else:
                    print(f"[pm] coordinator unreachable at {coordinator_url} — will retry")
            asyncio.create_task(_heartbeat_loop())

        @app.get("/", response_class=HTMLResponse)
        async def dashboard():
            return HTMLResponse(DASHBOARD_HTML.replace("{{NODE_NAME}}", self.name))

        @app.get("/api/status")
        async def api_status():
            return {key: r.status_dict() for key, r in self.runners.items()}

        @app.post("/api/start/{key}")
        async def api_start(key: str):
            r = self.runners.get(key)
            if not r:
                return {"error": "unknown key"}
            result = await r.start()
            return {**r.status_dict(), "result": result}

        @app.post("/api/stop/{key}")
        async def api_stop(key: str):
            r = self.runners.get(key)
            if not r:
                return {"error": "unknown key"}
            result = await r.stop()
            return {**r.status_dict(), "result": result}

        @app.get("/api/log/{key}", response_class=PlainTextResponse)
        async def api_log(key: str):
            r = self.runners.get(key)
            if not r:
                return PlainTextResponse("unknown key", status_code=404)
            lines = [f"[{e['ts']}] {e['text']}" for e in r.buffered_log()]
            return "\n".join(lines)

        @app.websocket("/ws/{key}")
        async def ws_log(websocket: WebSocket, key: str):
            r = self.runners.get(key)
            if not r:
                await websocket.close(code=4004)
                return

            await websocket.accept()
            r.subscribe(websocket)

            for entry in r.buffered_log():
                await websocket.send_text(json.dumps({"type": "log", "key": key, **entry}))

            try:
                while True:
                    data = await websocket.receive_text()
                    if data == "ping":
                        await websocket.send_text(json.dumps({"type": "pong"}))
            except WebSocketDisconnect:
                pass
            finally:
                r.unsubscribe(websocket)

        @app.websocket("/ws")
        async def ws_status(websocket: WebSocket):
            await websocket.accept()
            push_task = None
            try:
                async def push_loop():
                    while True:
                        payload = {
                            "type": "status",
                            "scripts": {k: r.status_dict() for k, r in self.runners.items()},
                        }
                        await websocket.send_text(json.dumps(payload))
                        await asyncio.sleep(2)

                push_task = asyncio.create_task(push_loop())

                while True:
                    raw = await websocket.receive_text()
                    try:
                        msg = json.loads(raw)
                        action = msg.get("action")
                        key = msg.get("key")
                        r = self.runners.get(key)
                        if r and action == "start":
                            await r.start()
                        elif r and action == "stop":
                            await r.stop()
                    except Exception:
                        pass

            except WebSocketDisconnect:
                pass
            finally:
                if push_task:
                    push_task.cancel()

        return app


# ─────────────────────────────────────────────
# Dashboard HTML
# ─────────────────────────────────────────────

DASHBOARD_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>pm // {{NODE_NAME}}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@300;400;500&family=IBM+Plex+Sans:wght@400;500&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --bg:        #f7f6f3;
  --surface:   #ffffff;
  --surface2:  #f0ede8;
  --border:    #e0dbd2;
  --border2:   #ccc8be;
  --text:      #1c1a16;
  --muted:     #7a7568;
  --dim:       #b0aa9f;
  --accent:    #1a1a1a;

  --run-fg:    #1a5c2e;
  --run-bg:    #edf7f0;
  --run-bd:    #a8d5b5;
  --stop-fg:   #6b6560;
  --stop-bg:   #f4f2ee;
  --stop-bd:   #ddd9d0;

  --log-bg:    #1d1c18;
  --log-text:  #c8c4b8;
  --log-dim:   #5a5750;
  --log-err:   #e05c5c;
  --log-warn:  #d49b3a;
  --log-info:  #5b9bd5;
  --log-sys:   #7a9e7e;
  --log-ts:    #4a4840;

  --radius: 8px;
  --mono: 'IBM Plex Mono', ui-monospace, monospace;
  --sans: 'IBM Plex Sans', system-ui, sans-serif;
}

body {
  background: var(--bg);
  color: var(--text);
  font-family: var(--mono);
  font-size: 13px;
  min-height: 100vh;
}

.shell {
  max-width: 860px;
  margin: 0 auto;
  padding: 2rem 1.5rem;
}

/* header */
.hd {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 2rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid var(--border);
}
.hd-prefix { color: var(--dim); font-size: 12px; }
.hd-name   { font-size: 15px; font-weight: 500; }
.hd-meta   { font-size: 11px; color: var(--dim); margin-left: auto; display: flex; align-items: center; gap: 8px; }
.live-dot  { width: 6px; height: 6px; border-radius: 50%; background: var(--run-fg); animation: blink 2.4s ease-in-out infinite; }
@keyframes blink { 0%,100%{opacity:1} 50%{opacity:.2} }

/* cards */
.cards { display: flex; flex-direction: column; gap: 8px; }

.card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  overflow: hidden;
  transition: border-color .2s;
}
.card.running { border-color: var(--run-bd); }

.card-top {
  display: grid;
  grid-template-columns: 8px 1fr auto auto;
  align-items: center;
  gap: 12px;
  padding: 12px 14px;
}

.dot {
  width: 8px; height: 8px; border-radius: 50%;
  background: var(--stop-bd);
  transition: background .3s;
}
.dot.running { background: var(--run-fg); }

.script-label { font-size: 13px; font-weight: 500; display: flex; align-items: center; gap: 8px; }
.script-key   { font-size: 10px; color: var(--dim); font-weight: 400; }

.badge {
  font-size: 10px; font-weight: 500; letter-spacing: .06em; text-transform: uppercase;
  padding: 2px 9px; border-radius: 99px;
  border: 1px solid var(--stop-bd); color: var(--stop-fg); background: var(--stop-bg);
  transition: all .2s;
}
.badge.running { color: var(--run-fg); background: var(--run-bg); border-color: var(--run-bd); }

.pid-tag { font-size: 10px; color: var(--dim); min-width: 72px; text-align: right; }

.card-actions { display: flex; border-top: 1px solid var(--border); }
.btn {
  flex: 1; padding: 7px 0;
  background: none; border: none; border-right: 1px solid var(--border);
  font-family: var(--mono); font-size: 11px; letter-spacing: .05em;
  color: var(--muted); cursor: pointer;
  transition: background .12s, color .12s;
}
.btn:last-child { border-right: none; }
.btn:hover { background: var(--surface2); }
.btn.btn-start:hover { color: var(--run-fg); }
.btn.btn-stop:hover  { color: #b03030; }
.btn.btn-log:hover   { color: var(--accent); }
.btn:active { opacity: .65; }

/* log panel */
.log-wrap { display: none; border-top: 1px solid var(--border); }
.log-wrap.open { display: block; }

.log-terminal { background: var(--log-bg); }

.log-bar {
  display: flex; align-items: center; gap: 10px;
  padding: 8px 14px;
  border-bottom: 1px solid rgba(255,255,255,.05);
}
.log-bar-dots { display: flex; gap: 5px; }
.log-bar-dot  { width: 10px; height: 10px; border-radius: 50%; }
.d1 { background: #e05c5c; } .d2 { background: #d4a03a; } .d3 { background: #5aa05a; }
.log-bar-title { font-size: 10px; color: var(--log-dim); letter-spacing: .1em; text-transform: uppercase; flex: 1; text-align: center; }
.log-bar-clear { font-size: 10px; color: var(--log-dim); background: none; border: none; cursor: pointer; font-family: var(--mono); }
.log-bar-clear:hover { color: var(--log-text); }

.log-body {
  padding: 10px 0;
  max-height: 300px;
  overflow-y: auto;
  font-size: 11.5px;
  line-height: 1.7;
}

.log-line {
  display: grid;
  grid-template-columns: 62px 1fr;
  padding: 1px 14px;
}
.log-line:hover { background: rgba(255,255,255,.03); }

.log-ts   { color: var(--log-ts); font-size: 10px; padding-top: 2px; user-select: none; }
.log-text { color: var(--log-text); white-space: pre-wrap; word-break: break-all; }

.log-line.err  .log-text { color: var(--log-err); }
.log-line.warn .log-text { color: var(--log-warn); }
.log-line.info .log-text { color: var(--log-info); }
.log-line.sys  .log-text { color: var(--log-sys); font-style: italic; }

.log-body::-webkit-scrollbar { width: 3px; }
.log-body::-webkit-scrollbar-thumb { background: rgba(255,255,255,.1); border-radius: 2px; }

/* toast */
.toast {
  position: fixed; bottom: 1.5rem; right: 1.5rem;
  background: var(--accent); color: #f0ede8;
  border-radius: var(--radius);
  padding: 8px 16px; font-size: 12px; letter-spacing: .04em;
  opacity: 0; transform: translateY(6px);
  transition: opacity .2s, transform .2s;
  pointer-events: none; z-index: 100;
}
.toast.show { opacity: 1; transform: translateY(0); }

.conn     { font-size: 10px; }
.conn.ok  { color: var(--run-fg); }
.conn.err { color: #b03030; }
</style>
</head>
<body>
<div class="shell">
  <header class="hd">
    <span class="hd-prefix">pm //</span>
    <span class="hd-name">{{NODE_NAME}}</span>
    <div class="hd-meta">
      <span class="conn" id="conn">connecting…</span>
      <span style="color:var(--border2)">·</span>
      <div class="live-dot"></div>
    </div>
  </header>
  <div class="cards" id="cards"></div>
</div>
<div class="toast" id="toast"></div>

<script>
const cardState = {};
let statusWs = null, reconnectT = null;

function toast(msg) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove("show"), 2200);
}

function escHtml(s) {
  return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}

function classify(text, stream) {
  if (stream === "system") return "sys";
  const l = text.toLowerCase();
  if (l.match(/error|traceback|exception|fatal/)) return "err";
  if (l.includes("warn")) return "warn";
  if (l.match(/\binfo\b/)) return "info";
  return "";
}

function appendLogLine(key, entry) {
  const body = document.getElementById("log-body-" + key);
  if (!body) return;
  const cls = classify(entry.text, entry.stream);
  const row = document.createElement("div");
  row.className = "log-line" + (cls ? " " + cls : "");
  row.innerHTML = '<span class="log-ts">' + escHtml(entry.ts) + '</span>'
                + '<span class="log-text">' + escHtml(entry.text) + '</span>';
  body.appendChild(row);
  body.scrollTop = body.scrollHeight;
}

function openLogWs(key) {
  if (cardState[key]?.ws) return;
  const ws = new WebSocket("ws://" + location.host + "/ws/" + key);
  cardState[key].ws = ws;
  ws.onmessage = e => {
    const msg = JSON.parse(e.data);
    if (msg.type === "log") appendLogLine(key, msg);
  };
  ws.onclose = () => { if (cardState[key]) cardState[key].ws = null; };
  const hb = setInterval(() => {
    if (ws.readyState === WebSocket.OPEN) ws.send("ping");
    else clearInterval(hb);
  }, 20000);
}

function closeLogWs(key) {
  const ws = cardState[key]?.ws;
  if (ws) { ws.close(); cardState[key].ws = null; }
}

function toggleLog(key) {
  const st = cardState[key];
  st.logOpen = !st.logOpen;
  document.getElementById("log-wrap-" + key).classList.toggle("open", st.logOpen);
  document.getElementById("log-btn-" + key).textContent = st.logOpen ? "log ▲" : "log ▼";
  if (st.logOpen) openLogWs(key);
  else closeLogWs(key);
}

function clearLog(key) {
  const body = document.getElementById("log-body-" + key);
  if (body) body.innerHTML = "";
}

function sendAction(action, key) {
  if (statusWs?.readyState === WebSocket.OPEN) {
    statusWs.send(JSON.stringify({ action, key }));
    toast(action + " \u2192 " + key);
  }
}

function updateCard(key, info) {
  const running = info.status === "running";
  const card = document.getElementById("card-" + key);
  if (!card) return;
  card.classList.toggle("running", running);
  document.getElementById("dot-" + key).classList.toggle("running", running);
  const badge = document.getElementById("badge-" + key);
  badge.textContent = info.status;
  badge.className = "badge" + (running ? " running" : "");
  document.getElementById("pid-" + key).textContent = info.pid ? "pid " + info.pid : "";
}

function renderCards(scripts) {
  const container = document.getElementById("cards");
  Object.entries(scripts).forEach(([key, info]) => {
    if (cardState[key]) { updateCard(key, info); return; }
    cardState[key] = { logOpen: false, ws: null };
    const running = info.status === "running";
    const el = document.createElement("div");
    el.className = "card" + (running ? " running" : "");
    el.id = "card-" + key;
    el.innerHTML =
      '<div class="card-top">'
      + '<div class="dot ' + (running ? "running" : "") + '" id="dot-' + key + '"></div>'
      + '<span class="script-label">' + escHtml(info.label) + '<span class="script-key">' + escHtml(key) + '</span></span>'
      + '<span class="badge ' + (running ? "running" : "") + '" id="badge-' + key + '">' + info.status + '</span>'
      + '<span class="pid-tag" id="pid-' + key + '">' + (info.pid ? "pid " + info.pid : "") + '</span>'
      + '</div>'
      + '<div class="card-actions">'
      + '<button class="btn btn-start" onclick="sendAction(\'start\',\'' + key + '\')">start</button>'
      + '<button class="btn btn-stop"  onclick="sendAction(\'stop\',\''  + key + '\')">stop</button>'
      + '<button class="btn btn-log" id="log-btn-' + key + '" onclick="toggleLog(\'' + key + '\')">log \u25be</button>'
      + '</div>'
      + '<div class="log-wrap" id="log-wrap-' + key + '">'
      + '<div class="log-terminal">'
      + '<div class="log-bar">'
      + '<div class="log-bar-dots"><div class="log-bar-dot d1"></div><div class="log-bar-dot d2"></div><div class="log-bar-dot d3"></div></div>'
      + '<span class="log-bar-title">' + escHtml(key) + ' \u2014 stdout / stderr</span>'
      + '<button class="log-bar-clear" onclick="clearLog(\'' + key + '\')">clear</button>'
      + '</div>'
      + '<div class="log-body" id="log-body-' + key + '"></div>'
      + '</div></div>';
    container.appendChild(el);
  });
}

function connectStatus() {
  statusWs = new WebSocket("ws://" + location.host + "/ws");
  statusWs.onopen = () => {
    const el = document.getElementById("conn");
    el.textContent = "connected"; el.className = "conn ok";
    clearTimeout(reconnectT);
  };
  statusWs.onmessage = e => {
    const msg = JSON.parse(e.data);
    if (msg.type === "status") renderCards(msg.scripts);
  };
  statusWs.onclose = () => {
    const el = document.getElementById("conn");
    el.textContent = "reconnecting\u2026"; el.className = "conn err";
    reconnectT = setTimeout(connectStatus, 3000);
  };
}

connectStatus();
</script>
</body>
</html>
"""