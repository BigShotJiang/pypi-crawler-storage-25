"""
coordinator.py
──────────────
Central fleet coordinator for process_manager Pi nodes.

Pi nodes self-register and send heartbeats automatically when
COORDINATOR_URL is set — no manual curl or code needed on the Pi.

Usage on coordinator machine:
    python coordinator.py --name home-lab --port 9000
    # open http://<coordinator-ip>:9000

On each Pi, just set the environment variable before starting:
    COORDINATOR_URL=http://192.168.1.10:9000 python app.py

The coordinator is optional — if it goes down, each Pi keeps
running and its own local dashboard remains fully functional.
Pis re-register automatically every 30s so the fleet view
recovers on its own when the coordinator comes back up.
"""

from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set

import httpx
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse
import uvicorn


# ─────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────

POLL_INTERVAL   = 3.0   # seconds between status polls per node
OFFLINE_AFTER   = 10.0  # seconds of silence before marking offline
REQUEST_TIMEOUT = 3.0   # http request timeout


# ─────────────────────────────────────────────
# Data models
# ─────────────────────────────────────────────

@dataclass
class NodeInfo:
    name: str
    host: str
    port: int
    registered_at: float = field(default_factory=time.time)
    last_seen: Optional[float] = None
    scripts: Dict[str, dict] = field(default_factory=dict)
    error: Optional[str] = None

    @property
    def base_url(self) -> str:
        return f"http://{self.host}:{self.port}"

    @property
    def online(self) -> bool:
        if self.last_seen is None:
            return False
        return (time.time() - self.last_seen) < OFFLINE_AFTER

    @property
    def age(self) -> str:
        """Human-readable time since last seen."""
        if self.last_seen is None:
            return "never"
        secs = int(time.time() - self.last_seen)
        if secs < 60:
            return f"{secs}s ago"
        if secs < 3600:
            return f"{secs // 60}m ago"
        return f"{secs // 3600}h ago"

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "host": self.host,
            "port": self.port,
            "online": self.online,
            "last_seen": self.age,
            "base_url": self.base_url,
            "scripts": self.scripts,
            "error": self.error,
        }


# ─────────────────────────────────────────────
# Node registry
# ─────────────────────────────────────────────

class NodeRegistry:
    def __init__(self):
        self._nodes: Dict[str, NodeInfo] = {}
        self._lock = asyncio.Lock()
        self._poll_tasks: Dict[str, asyncio.Task] = {}
        self._subscribers: Set[WebSocket] = set()

    # ── registration ────────────────────────

    async def register(self, name: str, host: str, port: int) -> NodeInfo:
        async with self._lock:
            node = self._nodes.get(name)
            if node:
                node.host = host
                node.port = port
            else:
                node = NodeInfo(name=name, host=host, port=port)
                self._nodes[name] = node

        # start polling if not already running
        if name not in self._poll_tasks or self._poll_tasks[name].done():
            self._poll_tasks[name] = asyncio.create_task(self._poll_loop(name))

        return node

    def get(self, name: str) -> Optional[NodeInfo]:
        return self._nodes.get(name)

    def all_nodes(self) -> List[NodeInfo]:
        return list(self._nodes.values())

    def fleet_dict(self) -> dict:
        nodes = self.all_nodes()
        return {
            "nodes": {n.name: n.to_dict() for n in nodes},
            "summary": {
                "total": len(nodes),
                "online": sum(1 for n in nodes if n.online),
                "running": sum(
                    sum(1 for s in n.scripts.values() if s.get("status") == "running")
                    for n in nodes
                ),
            },
        }

    # ── polling ─────────────────────────────

    async def _poll_loop(self, name: str) -> None:
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as client:
            while True:
                node = self._nodes.get(name)
                if not node:
                    break
                try:
                    resp = await client.get(f"{node.base_url}/api/status")
                    resp.raise_for_status()
                    node.scripts = resp.json()
                    node.last_seen = time.time()
                    node.error = None
                except Exception as e:
                    node.error = str(e)

                await self._broadcast()
                await asyncio.sleep(POLL_INTERVAL)

    # ── websocket broadcast ──────────────────

    def subscribe(self, ws: WebSocket) -> None:
        self._subscribers.add(ws)

    def unsubscribe(self, ws: WebSocket) -> None:
        self._subscribers.discard(ws)

    async def _broadcast(self) -> None:
        if not self._subscribers:
            return
        msg = json.dumps({"type": "fleet", **self.fleet_dict()})
        dead = set()
        for ws in self._subscribers:
            try:
                await ws.send_text(msg)
            except Exception:
                dead.add(ws)
        self._subscribers -= dead

    # ── node actions ────────────────────────

    async def start_script(self, node_name: str, key: str) -> dict:
        return await self._node_action(node_name, "start", key)

    async def stop_script(self, node_name: str, key: str) -> dict:
        return await self._node_action(node_name, "stop", key)

    async def _node_action(self, node_name: str, action: str, key: str) -> dict:
        node = self._nodes.get(node_name)
        if not node:
            return {"error": f"unknown node: {node_name}"}
        if not node.online:
            return {"error": f"node offline: {node_name}"}
        try:
            async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as client:
                resp = await client.post(f"{node.base_url}/api/{action}/{key}")
                resp.raise_for_status()
                return resp.json()
        except Exception as e:
            return {"error": str(e)}


# ─────────────────────────────────────────────
# App factory
# ─────────────────────────────────────────────

def create_coordinator_app(fleet_name: str = "home-lab") -> FastAPI:
    app = FastAPI(title=f"coordinator — {fleet_name}")
    registry = NodeRegistry()

    # ── REST ────────────────────────────────

    @app.get("/", response_class=HTMLResponse)
    async def dashboard():
        return HTMLResponse(FLEET_HTML.replace("{{FLEET_NAME}}", fleet_name))

    @app.post("/register")
    async def register(body: dict):
        name = body.get("name", "").strip()
        host = body.get("host", "").strip()
        port = int(body.get("port", 8000))
        if not name or not host:
            return JSONResponse({"error": "name and host required"}, status_code=400)
        node = await registry.register(name, host, port)
        return {"registered": name, "base_url": node.base_url}

    @app.get("/api/fleet")
    async def api_fleet():
        return registry.fleet_dict()

    @app.get("/api/nodes")
    async def api_nodes():
        return {n.name: n.to_dict() for n in registry.all_nodes()}

    @app.post("/api/{node_name}/start/{key}")
    async def api_start(node_name: str, key: str):
        return await registry.start_script(node_name, key)

    @app.post("/api/{node_name}/stop/{key}")
    async def api_stop(node_name: str, key: str):
        return await registry.stop_script(node_name, key)

    # ── WebSocket ────────────────────────────

    @app.websocket("/ws")
    async def ws_fleet(websocket: WebSocket):
        await websocket.accept()
        registry.subscribe(websocket)

        # send current state immediately on connect
        await websocket.send_text(json.dumps({"type": "fleet", **registry.fleet_dict()}))

        try:
            while True:
                raw = await websocket.receive_text()
                try:
                    msg = json.loads(raw)
                    action    = msg.get("action")
                    node_name = msg.get("node")
                    key       = msg.get("key")
                    if action in ("start", "stop") and node_name and key:
                        if action == "start":
                            await registry.start_script(node_name, key)
                        else:
                            await registry.stop_script(node_name, key)
                except Exception:
                    pass
        except WebSocketDisconnect:
            pass
        finally:
            registry.unsubscribe(websocket)

    return app


# ─────────────────────────────────────────────
# Fleet dashboard HTML
# ─────────────────────────────────────────────

FLEET_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>fleet // {{FLEET_NAME}}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@300;400;500&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}

:root{
  --bg:       #f7f6f3;
  --surface:  #ffffff;
  --surface2: #f0ede8;
  --border:   #e0dbd2;
  --border2:  #ccc8be;
  --text:     #1c1a16;
  --muted:    #7a7568;
  --dim:      #b0aa9f;

  --on-fg:    #1a5c2e;
  --on-bg:    #edf7f0;
  --on-bd:    #a8d5b5;

  --off-fg:   #6b6560;
  --off-bg:   #f4f2ee;
  --off-bd:   #ddd9d0;

  --run-fg:   #1a5c2e;
  --run-bg:   #edf7f0;
  --run-bd:   #a8d5b5;

  --err-fg:   #7a1a1a;
  --err-bg:   #fdf0f0;
  --err-bd:   #e8b4b4;

  --radius:   8px;
  --mono:     'IBM Plex Mono', ui-monospace, monospace;
}

body{
  background: var(--bg);
  color: var(--text);
  font-family: var(--mono);
  font-size: 13px;
  min-height: 100vh;
}

.shell{
  max-width: 1000px;
  margin: 0 auto;
  padding: 2rem 1.5rem;
}

/* ── header ── */
.hd{
  display: flex;
  align-items: baseline;
  gap: 10px;
  margin-bottom: 0.5rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid var(--border);
}
.hd-prefix{ color: var(--dim); font-size: 12px; }
.hd-name  { font-size: 15px; font-weight: 500; }
.hd-right { margin-left: auto; display: flex; align-items: center; gap: 12px; }
.conn     { font-size: 10px; }
.conn.ok  { color: var(--on-fg); }
.conn.err { color: #b03030; }
.live-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--on-fg); animation: blink 2.4s ease-in-out infinite; }
@keyframes blink{0%,100%{opacity:1}50%{opacity:.2}}

/* ── summary bar ── */
.summary{
  display: flex;
  gap: 2rem;
  padding: 0.75rem 0 1.25rem;
  border-bottom: 1px solid var(--border);
  margin-bottom: 1.5rem;
}
.stat{ display: flex; flex-direction: column; gap: 2px; }
.stat-val{ font-size: 20px; font-weight: 500; color: var(--text); }
.stat-lbl{ font-size: 10px; letter-spacing: .08em; text-transform: uppercase; color: var(--dim); }

/* ── empty state ── */
.empty{
  text-align: center;
  padding: 4rem 2rem;
  color: var(--dim);
  font-size: 12px;
  line-height: 2;
}
.empty code{
  display: inline-block;
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: 4px;
  padding: 0.75rem 1.25rem;
  font-size: 11px;
  text-align: left;
  margin-top: 1rem;
  color: var(--muted);
}

/* ── node cards ── */
.nodes{ display: flex; flex-direction: column; gap: 12px; }

.node-card{
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  overflow: hidden;
  transition: border-color .2s;
}
.node-card.online { border-color: var(--on-bd); }
.node-card.offline{ border-color: var(--off-bd); }
.node-card.error  { border-color: var(--err-bd); }

/* node header */
.node-hd{
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 16px;
  border-bottom: 1px solid var(--border);
  background: var(--surface2);
  cursor: pointer;
  user-select: none;
}
.node-hd:hover{ background: #e8e4de; }

.node-dot{
  width: 8px; height: 8px; border-radius: 50%;
  background: var(--off-bd); flex-shrink: 0;
  transition: background .3s;
}
.node-dot.online { background: var(--on-fg); }
.node-dot.error  { background: #c05050; }

.node-name{ font-size: 13px; font-weight: 500; flex: 1; }
.node-host{ font-size: 11px; color: var(--dim); }

.node-badge{
  font-size: 10px; font-weight: 500; letter-spacing: .06em; text-transform: uppercase;
  padding: 2px 9px; border-radius: 99px; border: 1px solid;
}
.node-badge.online { color: var(--on-fg);  background: var(--on-bg);  border-color: var(--on-bd); }
.node-badge.offline{ color: var(--off-fg); background: var(--off-bg); border-color: var(--off-bd); }
.node-badge.error  { color: var(--err-fg); background: var(--err-bg); border-color: var(--err-bd); }

.node-age{ font-size: 10px; color: var(--dim); min-width: 70px; text-align: right; }
.node-chevron{ font-size: 10px; color: var(--dim); transition: transform .2s; }
.node-chevron.open{ transform: rotate(180deg); }

/* node body */
.node-body{ display: none; }
.node-body.open{ display: block; }

/* scripts table */
.scripts-table{
  width: 100%;
  border-collapse: collapse;
}
.scripts-table tr{
  border-bottom: 1px solid var(--border);
}
.scripts-table tr:last-child{ border-bottom: none; }
.scripts-table td{
  padding: 9px 16px;
  vertical-align: middle;
}

.s-dot{
  width: 7px; height: 7px; border-radius: 50%;
  background: var(--off-bd);
  display: inline-block;
  transition: background .3s;
}
.s-dot.running{ background: var(--run-fg); }

.s-label{ font-size: 13px; font-weight: 500; }
.s-key  { font-size: 10px; color: var(--dim); margin-left: 6px; }
.s-status{
  font-size: 10px; font-weight: 500; letter-spacing: .06em; text-transform: uppercase;
  padding: 2px 8px; border-radius: 99px; border: 1px solid var(--off-bd);
  color: var(--off-fg); background: var(--off-bg);
}
.s-status.running{ color: var(--run-fg); background: var(--run-bg); border-color: var(--run-bd); }

.s-pid{ font-size: 10px; color: var(--dim); }

.s-actions{ display: flex; gap: 6px; justify-content: flex-end; }
.s-btn{
  padding: 4px 12px;
  font-family: var(--mono); font-size: 11px; letter-spacing: .04em;
  background: none; border: 1px solid var(--border);
  border-radius: 4px; color: var(--muted); cursor: pointer;
  transition: background .12s, color .12s, border-color .12s;
}
.s-btn:hover{ background: var(--surface2); }
.s-btn.start:hover{ color: var(--on-fg);  border-color: var(--on-bd); }
.s-btn.stop:hover { color: #b03030; border-color: #e8b4b4; }
.s-btn:active{ opacity: .65; }

.offline-msg{
  padding: 14px 16px;
  font-size: 12px;
  color: var(--dim);
  font-style: italic;
}

/* ── node link ── */
.node-link{
  font-size: 10px; color: var(--dim); text-decoration: none;
  border: 1px solid var(--border); border-radius: 4px;
  padding: 2px 8px; letter-spacing: .04em;
}
.node-link:hover{ color: var(--muted); background: var(--surface2); }

/* ── toast ── */
.toast{
  position: fixed; bottom: 1.5rem; right: 1.5rem;
  background: #1a1a1a; color: #f0ede8;
  border-radius: var(--radius); padding: 8px 16px;
  font-size: 12px; letter-spacing: .04em;
  opacity: 0; transform: translateY(6px);
  transition: opacity .2s, transform .2s;
  pointer-events: none; z-index: 100;
}
.toast.show{ opacity: 1; transform: translateY(0); }
</style>
</head>
<body>
<div class="shell">

  <header class="hd">
    <span class="hd-prefix">fleet //</span>
    <span class="hd-name">{{FLEET_NAME}}</span>
    <div class="hd-right">
      <span class="conn" id="conn">connecting…</span>
      <div class="live-dot"></div>
    </div>
  </header>

  <div class="summary">
    <div class="stat"><span class="stat-val" id="s-total">—</span><span class="stat-lbl">nodes</span></div>
    <div class="stat"><span class="stat-val" id="s-online">—</span><span class="stat-lbl">online</span></div>
    <div class="stat"><span class="stat-val" id="s-running">—</span><span class="stat-lbl">running</span></div>
  </div>

  <div class="nodes" id="nodes">
    <div class="empty" id="empty">
      no nodes registered yet<br>
      <code>curl -X POST http://this-machine:9000/register \
  -H "Content-Type: application/json" \
  -d '{"name":"my-pi","host":"192.168.1.x","port":5001}'</code>
    </div>
  </div>
</div>

<div class="toast" id="toast"></div>

<script>
let ws = null, reconnT = null;
const expanded = {};

function toast(msg) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove("show"), 2500);
}

function esc(s) {
  return String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}

function sendAction(action, node, key) {
  if (ws?.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ action, node, key }));
    toast(`${action} → ${node} / ${key}`);
  }
}

function toggleNode(name) {
  expanded[name] = !expanded[name];
  const body = document.getElementById("body-" + name);
  const chev = document.getElementById("chev-" + name);
  if (body) body.classList.toggle("open", expanded[name]);
  if (chev) chev.classList.toggle("open", expanded[name]);
}

function updateSummary(summary) {
  document.getElementById("s-total").textContent   = summary.total;
  document.getElementById("s-online").textContent  = summary.online;
  document.getElementById("s-running").textContent = summary.running;
}

function renderScripts(node, scripts) {
  if (!node.online) {
    return `<div class="offline-msg">last seen ${esc(node.last_seen)} — scripts unavailable</div>`;
  }
  if (!scripts || Object.keys(scripts).length === 0) {
    return `<div class="offline-msg">no scripts registered on this node</div>`;
  }
  const rows = Object.entries(scripts).map(([key, info]) => {
    const running = info.status === "running";
    return `<tr>
      <td style="width:12px"><span class="s-dot ${running?"running":""}"></span></td>
      <td><span class="s-label">${esc(info.label)}</span><span class="s-key">${esc(key)}</span></td>
      <td><span class="s-status ${running?"running":""}">${esc(info.status)}</span></td>
      <td class="s-pid">${info.pid ? "pid "+info.pid : ""}</td>
      <td>
        <div class="s-actions">
          <button class="s-btn start" onclick="sendAction('start','${esc(node.name)}','${esc(key)}')">start</button>
          <button class="s-btn stop"  onclick="sendAction('stop','${esc(node.name)}','${esc(key)}')">stop</button>
        </div>
      </td>
    </tr>`;
  }).join("");
  return `<table class="scripts-table">${rows}</table>`;
}

function renderNodes(nodes) {
  const container = document.getElementById("nodes");
  const empty = document.getElementById("empty");
  const keys = Object.keys(nodes);

  if (keys.length === 0) {
    empty.style.display = "";
    // remove any existing node cards
    container.querySelectorAll(".node-card").forEach(el => el.remove());
    return;
  }
  empty.style.display = "none";

  keys.forEach(name => {
    const node = nodes[name];
    const statusCls = node.online ? "online" : (node.error ? "error" : "offline");
    let card = document.getElementById("node-" + name);

    if (!card) {
      expanded[name] = true; // expand by default
      card = document.createElement("div");
      card.id = "node-" + name;
      container.appendChild(card);
    }

    card.className = "node-card " + statusCls;
    card.innerHTML = `
      <div class="node-hd" onclick="toggleNode('${esc(name)}')">
        <div class="node-dot ${statusCls}" ></div>
        <span class="node-name">${esc(name)}</span>
        <span class="node-host">${esc(node.host)}:${esc(node.port)}</span>
        <span class="node-badge ${statusCls}">${statusCls}</span>
        <span class="node-age">${esc(node.last_seen)}</span>
        <a class="node-link" href="${esc(node.base_url)}" target="_blank" onclick="event.stopPropagation()">open ↗</a>
        <span class="node-chevron ${expanded[name]?"open":""}" id="chev-${esc(name)}">▾</span>
      </div>
      <div class="node-body ${expanded[name]?"open":""}" id="body-${esc(name)}">
        ${renderScripts(node, node.scripts)}
      </div>
    `;
  });

  // remove cards for nodes that no longer exist
  container.querySelectorAll(".node-card").forEach(el => {
    const name = el.id.replace("node-", "");
    if (!nodes[name]) el.remove();
  });
}

function connect() {
  ws = new WebSocket("ws://" + location.host + "/ws");

  ws.onopen = () => {
    const el = document.getElementById("conn");
    el.textContent = "connected";
    el.className = "conn ok";
    clearTimeout(reconnT);
  };

  ws.onmessage = e => {
    const msg = JSON.parse(e.data);
    if (msg.type === "fleet") {
      updateSummary(msg.summary);
      renderNodes(msg.nodes);
    }
  };

  ws.onclose = () => {
    const el = document.getElementById("conn");
    el.textContent = "reconnecting…";
    el.className = "conn err";
    reconnT = setTimeout(connect, 3000);
  };
}

connect();
</script>
</body>
</html>
"""


# ─────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Process manager fleet coordinator")
    parser.add_argument("--host",  default="0.0.0.0",   help="bind host")
    parser.add_argument("--port",  default=9000, type=int, help="bind port")
    parser.add_argument("--name",  default="home-lab",   help="fleet name shown in UI")
    args = parser.parse_args()

    app = create_coordinator_app(fleet_name=args.name)
    uvicorn.run(app, host=args.host, port=args.port)