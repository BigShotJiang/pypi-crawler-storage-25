"""Build-injected official licensing configuration."""

OFFICIAL_LICENSE_ENDPOINT = 'https://slrsoft.ca'
OFFICIAL_SIGNING_PUBLIC_KEY_PEM = '-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAjY/lRvFw6SFsmerr8q6So+B8mWoMvHXjgYIzI7zeU7E=\n-----END PUBLIC KEY-----'
