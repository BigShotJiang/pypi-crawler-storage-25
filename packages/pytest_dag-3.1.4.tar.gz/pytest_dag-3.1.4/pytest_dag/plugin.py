"""
pytest-dag: main plugin module.

Registers all pytest hooks required to:
  - declare the ``dag`` marker,
  - add CLI / ini options,
  - build and validate the DAG after collection,
  - reorder items in topological order,
  - skip blocked tests at setup time,
  - record outcomes after each test call.

All license enforcement and DAG logic is handled by
``pytest_dag._pytest_dag_core``.  This file is intentionally a thin
orchestration shell.
"""
from __future__ import annotations

import os
import textwrap
import warnings
from pathlib import Path
from typing import Optional

import pytest

# ---------------------------------------------------------------------------
# Import the internal core module.
# Every runtime DAG/license operation in this file calls through this API.
# ---------------------------------------------------------------------------
from . import _pytest_dag_core as _core


# ---------------------------------------------------------------------------
# xdist compatibility guard (pure orchestration — no security relevance)
# ---------------------------------------------------------------------------

def _maybe_disable_xdist(config: pytest.Config) -> None:
    """Auto-disable pytest-xdist when it would break DAG dependency tracking.

    xdist distributes tests across isolated worker *processes*.  Each worker
    gets its own copy of state, so workers never see each other's pass/fail
    results.  This silently breaks dependency blocking, topological order,
    and fail/skip cascade.

    We only auto-disable when xdist is *active* (``-n`` flag was passed).
    """
    xdist_plugin = config.pluginmanager.get_plugin("xdist")
    if xdist_plugin is None:
        return

    numprocesses = getattr(config.option, "numprocesses", None)
    if numprocesses is None:
        return

    config.pluginmanager.unregister(xdist_plugin)
    dsession = config.pluginmanager.get_plugin("dsession")
    if dsession is not None:
        config.pluginmanager.unregister(dsession)

    if hasattr(config.option, "numprocesses"):
        config.option.numprocesses = 0
    if hasattr(config.option, "dist"):
        config.option.dist = "no"

    for name in ("workermanage", "xdist-scheduler"):
        leftover = config.pluginmanager.get_plugin(name)
        if leftover is not None:
            config.pluginmanager.unregister(leftover)

    warnings.warn(
        "\n\n"
        "┌─────────────────────────────────────────────────────────────┐\n"
        "│  pytest-dag: pytest-xdist automatically disabled            │\n"
        "├─────────────────────────────────────────────────────────────┤\n"
        "│  pytest-xdist runs tests in parallel across worker          │\n"
        "│  processes.  Each worker has isolated state, so DAG         │\n"
        "│  dependency tracking silently breaks:                       │\n"
        "│                                                             │\n"
        "│    • blocked tests run anyway (workers can't see results)   │\n"
        "│    • topological order is ignored by xdist scheduler        │\n"
        "│    • fail/skip cascade never fires                          │\n"
        "│                                                             │\n"
        "│  Your tests will now run sequentially with full DAG         │\n"
        "│  enforcement. To suppress this warning, drop the -n flag    │\n"
        "│  or explicitly disable xdist when invoking pytest:          │\n"
        "│                                                             │\n"
        "│      pytest -p no:xdist <your other args>                   │\n"
        "└─────────────────────────────────────────────────────────────┘\n",
        UserWarning,
        stacklevel=2,
    )


# ---------------------------------------------------------------------------
# Hook: add CLI / ini options
# ---------------------------------------------------------------------------

def pytest_addoption(parser: pytest.Parser) -> None:
    group = parser.getgroup("dag", "pytest-dag: dependency-based test ordering")

    # ---- Migration options -----------------------------------------------
    group.addoption(
        "--migrate-from-pytest-dependency",
        action="store_true",
        default=False,
        dest="migrate_from_pytest_dependency",
        help=(
            "Scan the test suite for pytest.mark.dependency(...) markers, "
            "run preflight validation, then emit a pytest-dag-compatible "
            "dag.yaml and remove the markers from source files. Exits "
            "after migration without "
            "running any tests."
        ),
    )
    group.addoption(
        "--dag-file-out",
        default=None,
        metavar="PATH",
        dest="dag_file_out",
        help=(
            "Path for the generated YAML file when using "
            "--migrate-from-pytest-dependency. "
            "Defaults to the dag_file ini option, or 'tests/dag.yaml'."
        ),
    )
    group.addoption(
        "--migrate-dry-run",
        action="store_true",
        default=False,
        dest="migrate_dry_run",
        help=(
            "With --migrate-from-pytest-dependency: print a diff/YAML preview "
            "without writing any files."
        ),
    )
    # ---- Regular DAG options ---------------------------------------------
    group.addoption(
        "--dag-block-on-outcomes",
        default="fail",
        metavar="OUTCOMES",
        help=(
            "Comma-separated list of outcomes that block dependents. "
            "Recognised values: fail, skip, xfail, error. "
            "Example: --dag-block-on-outcomes fail,skip (default: fail)"
        ),
    )
    group.addoption(
        "--dag-print-graph",
        action="store_true",
        default=False,
        help="Print the computed DAG order and edges to stdout after collection.",
    )

    # ini option for external YAML DAG file
    parser.addini(
        "dag_file",
        default="",
        help="Path to a YAML file describing the test dependency graph.",
    )

    # ---- License key injection ----
    group.addoption(
        "--pytest-dag-license-key",
        default=None,
        metavar="KEY",
        help=(
            "pytest-dag license key (pd-XXXX-XXXX-XXXX-XXXX). "
            "Also readable from the PYTEST_DAG_LICENSE_KEY environment variable."
        ),
    )
    group.addoption(
        "--pytest-dag-license-key-file",
        default=None,
        metavar="PATH",
        help="Path to a file containing the pytest-dag license key.",
    )


# ---------------------------------------------------------------------------
# Hook: configure — license enforcement + marker registration
# ---------------------------------------------------------------------------

@pytest.hookimpl(tryfirst=True)
def pytest_configure(config: pytest.Config) -> None:
    # tryfirst=True ensures we run BEFORE xdist's pytest_configure.
    _maybe_disable_xdist(config)

    try:
        migrate_mode = config.getoption(
            "--migrate-from-pytest-dependency", default=False
        )
    except (AttributeError, ValueError):
        migrate_mode = False

    if not migrate_mode:
        # Resolve license key from env / CLI / file (pure Python option reading).
        license_key = _get_license_key(config)

        # enforce_and_init() runs in the core module. On failure it raises RuntimeError
        # with a human-readable message; we call pytest.exit() here so the
        # error is presented cleanly and the process exits with rc=1.
        #
        # There is NO try/except that would silently swallow a failure.
        # Removing this call leaves config._dag_session as None, which causes
        # every subsequent core call to raise TypeError — the plugin does not
        # degrade silently.
        try:
            dag_session = _core.enforce_and_init(license_key)
        except RuntimeError as exc:
            msg = str(exc)
            if (
                "License server unreachable" in msg
                and "support@slrsoft.ca" not in msg
            ):
                msg = f"{msg}\nIf this persists, email support@slrsoft.ca"
            # Surface the core error message through pytest's exit mechanism.
            _fatal_box(msg)
            return

        config._dag_session = dag_session  # type: ignore[attr-defined]

    config.addinivalue_line(
        "markers",
        "dag(depends): declare test dependencies for pytest-dag. "
        "`depends` is a string or list of test nodeids / short names.",
    )


# ---------------------------------------------------------------------------
# Hook: build DAG + reorder after collection
# ---------------------------------------------------------------------------

def pytest_collection_modifyitems(
    config: pytest.Config,
    items: list,
) -> None:
    # Migration mode
    migrate_mode = getattr(config.option, "migrate_from_pytest_dependency", False)
    if migrate_mode:
        from .migrate import run_migration
        run_migration(items, config)
        pytest.exit(
            "pytest-dag: migration complete.  "
            "Re-run without --migrate-from-pytest-dependency to execute tests.",
            returncode=0,
        )
        return

    if not items:
        return

    dag_session = getattr(config, "_dag_session", None)
    if dag_session is None:
        return  # plugin not configured (e.g. collection-only run)

    # Build item descriptor list for core.
    item_descs = []
    for item in items:
        marker = item.get_closest_marker("dag")
        raw_deps: list[str] = []
        if marker is not None:
            depends = marker.kwargs.get(
                "depends", marker.args[0] if marker.args else []
            )
            if isinstance(depends, str):
                depends = [depends]
            raw_deps = list(depends)
        item_descs.append({"nodeid": item.nodeid, "raw_deps": raw_deps})

    # Resolve dag_file and rootdir.
    dag_file: str = config.getini("dag_file") or ""
    rootdir: str = str(
        config.rootpath if hasattr(config, "rootpath") else config.rootdir
    )
    strict = True

    # Build the DAG in core. Raises RuntimeError on cycle or missing dep (strict).
    try:
        _core.build_dag(dag_session, item_descs, dag_file or None, rootdir, strict)
    except RuntimeError as exc:
        raise pytest.UsageError(str(exc)) from None

    # Topological sort → list of ordered nodeids.
    try:
        ordered_nodeids = _core.topo_sort(dag_session, item_descs)
    except RuntimeError as exc:
        raise pytest.UsageError(str(exc)) from None

    # Store ordered list in session for dump / debug.
    _core.set_ordered(dag_session, ordered_nodeids)

    # Reorder items in place.
    nodeid_to_item = {it.nodeid: it for it in items}
    items[:] = [nodeid_to_item[nid] for nid in ordered_nodeids]

    # Optionally dump the computed graph.
    if config.getoption("--dag-print-graph", default=False):
        _dump_dag(dag_session, ordered_nodeids)


# ---------------------------------------------------------------------------
# Hook: skip blocked tests at setup
# ---------------------------------------------------------------------------

def pytest_runtest_setup(item: pytest.Item) -> None:
    dag_session = getattr(item.config, "_dag_session", None)
    if dag_session is None:
        return

    # Resolve block_on string (e.g. "FAILED,ERROR") from CLI option.
    block_on = _resolve_block_on(item.config)

    # All blocking logic runs in core.
    is_blocked, reason = _core.check_block(dag_session, item.nodeid, block_on)
    if is_blocked:
        pytest.skip(reason)


# ---------------------------------------------------------------------------
# Hook: record test outcomes
# ---------------------------------------------------------------------------

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item: pytest.Item, call: pytest.CallInfo):
    """Record the outcome of each test phase into DagSession."""
    outcome = yield
    dag_session = getattr(item.config, "_dag_session", None)
    if dag_session is None:
        return

    report = outcome.get_result()
    nodeid = item.nodeid

    if report.when == "setup":
        if report.skipped:
            longrepr = report.longrepr
            skip_msg = (
                str(longrepr[2])
                if isinstance(longrepr, tuple) and len(longrepr) == 3
                else str(longrepr)
            )
            outcome_str = (
                "DAG_SKIPPED"
                if "pytest-dag: blocked by" in skip_msg
                else "SKIPPED"
            )
            _core.record_outcome(dag_session, nodeid, outcome_str, overwrite=False)
        elif report.failed:
            _core.record_outcome(dag_session, nodeid, "ERROR", overwrite=True)

    elif report.when == "call":
        if report.passed:
            o = "XPASSED" if hasattr(report, "wasxfail") else "PASSED"
            _core.record_outcome(dag_session, nodeid, o, overwrite=True)
        elif report.failed:
            o = "XPASSED" if hasattr(report, "wasxfail") else "FAILED"
            _core.record_outcome(dag_session, nodeid, o, overwrite=True)
        elif report.skipped:
            o = "XFAILED" if hasattr(report, "wasxfail") else "SKIPPED"
            _core.record_outcome(dag_session, nodeid, o, overwrite=True)

    elif report.when == "teardown":
        if report.failed:
            # Escalate to ERROR only if the test previously passed (or has no
            # recorded outcome yet).  A FAILED or SKIPPED result takes priority.
            existing = _core.get_outcome(dag_session, nodeid)
            if existing in ("PASSED", "XPASSED", None):
                _core.record_outcome(dag_session, nodeid, "ERROR", overwrite=True)


def pytest_sessionfinish(session: pytest.Session, exitstatus: int) -> None:
    dag_session = getattr(session.config, "_dag_session", None)
    if dag_session is None:
        return
    _core.finalize_session(dag_session)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_license_key(config: pytest.Config) -> Optional[str]:
    """Read license key from env, CLI option, or key file."""
    key = os.environ.get("PYTEST_DAG_LICENSE_KEY", "").strip()
    if key:
        return key

    try:
        key = (config.getoption("--pytest-dag-license-key", default=None) or "").strip()
        if key:
            return key
    except (ValueError, AttributeError):
        pass

    try:
        key_file = config.getoption("--pytest-dag-license-key-file", default=None)
        if key_file:
            key = Path(key_file).read_text(encoding="utf-8").strip()
            if key:
                return key
    except (ValueError, AttributeError, OSError):
        pass

    return None


def _resolve_block_on(config: pytest.Config) -> str:
    """Convert --dag-block-on-outcomes to uppercase outcome tokens."""
    _ALIASES = {
        "fail":    "FAILED",
        "failed":  "FAILED",
        "skip":    "SKIPPED",
        "skipped": "SKIPPED",
        "xfail":   "XFAILED",
        "xfailed": "XFAILED",
        "error":   "ERROR",
    }
    raw: str = config.getoption("--dag-block-on-outcomes", default="fail")
    outcomes = []
    for token in raw.split(","):
        token = token.strip().lower()
        if not token:
            continue
        mapped = _ALIASES.get(token)
        if mapped is None:
            raise pytest.UsageError(
                f"pytest-dag: unknown --dag-block-on-outcomes value {token!r}. "
                f"Allowed: {', '.join(sorted(_ALIASES))}"
            )
        outcomes.append(mapped)
    return ",".join(outcomes) if outcomes else "FAILED"


def _fatal_box(message: str) -> None:
    """Print a bordered error box and call pytest.exit(rc=1)."""
    width = 62
    top    = "╔" + "═" * width + "╗"
    bottom = "╚" + "═" * width + "╝"
    content_width = width - 4
    wrapped: list[str] = []
    for raw_line in message.splitlines() or [""]:
        if raw_line == "":
            wrapped.append("")
            continue
        chunks = textwrap.wrap(
            raw_line,
            width=content_width,
            replace_whitespace=False,
            drop_whitespace=False,
            break_long_words=True,
            break_on_hyphens=False,
        )
        wrapped.extend(chunks or [""])
    padded = [f"║  {line:<{content_width}}  ║" for line in wrapped]
    box    = "\n".join([top, *padded, bottom])
    pytest.exit(f"\n{box}\n", returncode=1)


def _dump_dag(dag_session, ordered_nodeids: list[str]) -> None:
    deps = _core.get_deps(dag_session)
    sep = "-" * 60
    lines = [
        "",
        sep,
        "pytest-dag: computed execution order",
        sep,
    ]
    for i, nid in enumerate(ordered_nodeids, 1):
        dep_list = sorted(deps.get(nid, []))
        dep_str  = " <- [" + ", ".join(dep_list) + "]" if dep_list else ""
        lines.append(f"  {i:3d}. {nid}{dep_str}")
    lines.append(sep)
    print("\n".join(lines))
