# torrent-search

> **Disclaimer:** This project is for educational purposes only. Use it only to search for content you have the legal right to access. The authors are not responsible for any misuse.

[![Docker image](https://img.shields.io/badge/ghcr.io-torrent--search--web-blue?logo=docker&logoColor=white)](https://github.com/gmolveau/torrent-search/pkgs/container/torrent-search-web)

A command-line tool to search torrents across multiple engines and instantly grab [magnet links](https://nordvpn.com/cybersecurity/glossary/magnet-link/).

Built on top of the [qBittorrent search plugin ecosystem](https://github.com/qbittorrent/search-plugins) — the same plugins that power qBittorrent's built-in search, repurposed into an interactive terminal tool.

## Getting started

### Requirements

- Python 3.13+
- [uv](https://docs.astral.sh/uv/)

### Run

```bash
uvx --from git+https://github.com/gmolveau/torrensearch torrensearch "ubuntu 22.04"
```

### Usage

```bash
torrensearch "search query"
```

Results are displayed in a table sorted by seeders. Enter a result number to print its magnet link and copy it to the clipboard (macOS and Linux supported).

### Options

| Flag             | Short | Default | Description                            |
| ---------------- | ----- | ------- | -------------------------------------- |
| `--engines`      | `-e`  | all     | Comma-separated list of engines to use |
| `--category`     | `-c`  | `all`   | Category filter                        |
| `--limit`        | `-n`  | `40`    | Maximum results to display             |
| `--list-engines` |       |         | Print available engines and exit       |

### Categories

`all`, `anime`, `books`, `games`, `movies`, `music`, `software`, `tv`

Not every engine supports every category. When an engine does not support the requested category it falls back to `all` automatically.

### Examples

```bash
# Search everything, all engines
torrensearch "ubuntu 22.04"

# TV show, specific engines
torrensearch "breaking bad s01" --category tv --engines piratebay,eztv

# Software, cap results
torrensearch "arch linux" --category software --limit 10

# See which engines are available
torrensearch --list-engines
```

### Interactive session

```console
$ torrensearch "ubuntu 22.04"

  #  Name                                  Size      Seeds  Leech  Engine
  1  ubuntu-22.04.3-desktop-amd64.iso      4.6 GB      312     18  piratebay
  2  Ubuntu 22.04.3 LTS Server             1.8 GB      241      9  torrentscsv
  3  Ubuntu 22.04 LTS Jammy x86_64         3.9 GB       98      4  limetorrents
  ...

Showing 40 of 87 result(s). Enter # to get the magnet link, q to quit.

> 1

ubuntu-22.04.3-desktop-amd64.iso
magnet:?xt=urn:btih:...

✓ Copied to clipboard.
Info page: https://thepiratebay.org/description.php?id=...

> q
```

## Engines

| Engine           | Site                | Categories                              |
| ---------------- | ------------------- | --------------------------------------- |
| `eztv`           | eztv.re             | tv                                      |
| `jackett`        | self-hosted         | all (requires config)                   |
| `limetorrents`   | limetorrents.lol    | all                                     |
| `piratebay`      | thepiratebay.org    | all, movies, tv, music, games, software |
| `solidtorrents`  | solidtorrents.to    | all                                     |
| `torlock`        | torlock.com         | all                                     |
| `torrentproject` | torrentproject2.com | all                                     |
| `torrentscsv`    | torrents-csv.com    | all                                     |

### Jackett

Jackett is a self-hosted proxy that aggregates search results from dozens of public and private trackers through a single API. Once configured, the `jackett` engine searches all your configured indexers in parallel.

#### 1. Install Jackett

**macOS (Homebrew):**

```bash
brew install jackett
brew services start jackett
```

**Linux:**

```bash
# Download the latest release
curl -sL https://github.com/Jackett/Jackett/releases/latest/download/Jackett.Binaries.LinuxAMDx64.tar.gz | tar xz
cd Jackett
./jackett
```

**Docker:**

```bash
docker run -d \
  --name jackett \
  -p 9117:9117 \
  -v ~/.config/jackett:/config \
  lscr.io/linuxserver/jackett
```

Jackett's web UI will be available at `http://127.0.0.1:9117`.

#### 2. Add indexers

1. Open `http://127.0.0.1:9117` in your browser
2. Click **+ Add Indexer**
3. Search for and add any public trackers you want (e.g. *The Pirate Bay*, *EZTV*, *1337x*)
4. Click the **Test** button next to each indexer to confirm it works

#### 3. Retrieve the API key

On the Jackett web UI main page, the **API Key** is displayed in the top-right corner under the header. Copy it.

#### 4. Configure torrensearch

On first run, `torrensearch` automatically creates a configuration file at:

```console
~/.config/torrent-search/jackett.json   # Linux / macOS
%APPDATA%\torrent-search\jackett.json   # Windows (if XDG_CONFIG_HOME is set)
```

Open the file and paste your API key:

```json
{
    "api_key": "your_api_key_here",
    "url": "http://127.0.0.1:9117",
    "tracker_first": false,
    "thread_count": 20
}
```

| Field           | Description                                                           |
| --------------- | --------------------------------------------------------------------- |
| `api_key`       | Your Jackett API key (required)                                       |
| `url`           | URL where Jackett is running (default: `http://127.0.0.1:9117`)       |
| `tracker_first` | If `true`, prefixes results with `[TrackerName]` instead of suffixing |
| `thread_count`  | Number of parallel indexer requests (default: `20`)                   |

#### 5. Search

```bash
torrensearch "the matrix" --engines jackett
torrensearch "breaking bad" --engines jackett --category tv
```

---

## How it works

### The tool

```console
query
  │
  ▼
┌─────────────────────────────────────────────────┐
│  torrensearch                                        │
│                                                 │
│  spawns one thread per engine                   │
│    ├── eztv        ──► scrapes eztv.re          │
│    ├── piratebay   ──► queries TPB JSON API     │
│    ├── torrentscsv ──► queries torrents-csv.com │
│    └── …                                        │
│                                                 │
│  collects results, sorts by seeders             │
│  displays table, prompts for selection          │
│  copies chosen magnet link to clipboard         │
└─────────────────────────────────────────────────┘
```

Each engine is a standalone Python module that fetches and parses its own source site. They share a common interface: a `search(query, category)` method that returns a list of result dicts. HTTP requests are handled by a shared `_http.py` utility in the engines directory.

### Magnet links

A magnet link is a self-contained pointer to a torrent. Instead of downloading a `.torrent` file from a server, your client resolves everything from the link itself.

```console
magnet:?xt=urn:btih:f0a9598a...df8
       &dn=My.Movie.1080p
       &tr=udp://tracker.opentrackr.org:1337/announce
       &tr=udp://open.stealth.si:80/announce
       &tr=…
```

| Parameter | Name         | Purpose                                                                                                     |
| --------- | ------------ | ----------------------------------------------------------------------------------------------------------- |
| `xt`      | exact topic  | The infohash — a SHA-1 (or SHA-256) fingerprint of the torrent's metadata. Uniquely identifies the content. |
| `dn`      | display name | Human-readable name shown in the client while the metadata is being fetched.                                |
| `tr`      | tracker      | Announce URL of a tracker the client should contact to find peers. Multiple `tr` params are allowed.        |

**How a download starts:**

1. Your client extracts the infohash from `xt`.
2. It contacts the listed trackers (`tr`), which return a list of peers currently sharing that infohash.
3. In parallel, it queries the **DHT** (Distributed Hash Table) network — a decentralised peer registry that needs no trackers at all.
4. Once at least one peer is reached, the client downloads the torrent **metadata** (file list, piece hashes) directly from that peer (*magnet extension protocol*, BEP-9).
5. With the metadata in hand, the actual file download begins piece by piece, verified against the piece hashes.

Trackers speed up the initial peer discovery step. Once DHT kicks in or enough peers are known, trackers become optional — the swarm is self-sustaining.

## Private trackers

Private trackers are invite-only torrent communities. Unlike public trackers (open to anyone), they gate access behind an account and enforce a **seeding ratio** — the ratio of data uploaded to data downloaded.

### How access works

Each registered user gets a personalised **passkey** embedded directly in their announce URL:

```console
https://tracker.example.com/announce?passkey=a1b2c3d4e5f6...
```

That URL is secret. The tracker uses it to attribute all upload and download activity to your account. Sharing it lets someone else leech under your identity — most private trackers will ban the account if a passkey is used from multiple IPs.

### Ratio system

| Term          | Meaning                                                   |
| ------------- | --------------------------------------------------------- |
| **Upload**    | Data you have sent to other peers                         |
| **Download**  | Data you have received                                    |
| **Ratio**     | Upload ÷ Download — must stay above a minimum (often 1.0) |
| **Hit & Run** | Downloading and removing a torrent before seeding it back |

Falling below the minimum ratio leads to warnings, download throttling, or a ban. Most trackers offer a grace period for new members and grant **freeleech** tokens for certain releases (downloads that do not count against your ratio).

### How peer discovery differs

Public torrents rely on open DHT and public trackers. Private trackers **disable DHT** for their torrents so peers can only be found through the tracker itself. This keeps the swarm closed to non-members and lets the tracker accurately count every byte transferred.

A private torrent's `.torrent` file contains the flag:

```console
private = 1
```

BitTorrent clients that respect this flag will not announce to DHT or use peer exchange (PEX) for that torrent, routing all peer discovery exclusively through the tracker URL.

### Jackett and private trackers

Jackett supports many private trackers. After adding a private tracker indexer in the Jackett UI and entering your credentials, the `jackett` engine can search it like any other — the passkey handling happens inside Jackett's indexer plugin, not in torrensearch.

---

## Adding a new engine

Engines live in `src/torrensearch/engines/`. Each engine is a single `.py` file whose filename and class name must match exactly — it is picked up automatically with no registration needed.

### Minimal template

```python
# src/torrensearch/engines/myengine.py
# VERSION: 1.0
# AUTHORS: you

import json
from typing import Any

from _http import fetch


class myengine:
    url = 'https://myengine.example'
    name = 'My Engine'
    supported_categories = {
        'all': '',
        'movies': 'movies',
        'tv': 'tv',
    }

    def search(self, what: str, cat: str = 'all') -> list[dict[str, Any]]:
        page = fetch(f"{self.url}/search?q={what}")
        # parse page and build result list …
        return [{
            'link':       'magnet:?xt=urn:btih:…',
            'name':       'Torrent Title',
            'size':       '1234567890 B',   # bytes, or "1.2 GB"
            'seeds':      42,
            'leech':      3,
            'engine_url': self.url,
            'desc_link':  'https://myengine.example/details/123',
            'pub_date':   1700000000,        # unix timestamp, or -1
        }]
```

`fetch(url)` handles gzip decompression, User-Agent headers, and timeouts. Use `-1` for any field you cannot determine (`size`, `seeds`, `leech`, `pub_date`).

## Adding trackers

Two engines — **piratebay** and **torrentscsv** — construct magnet links from raw infohashes returned by their APIs. These engines embed a hardcoded tracker list so the torrent client can start discovering peers before DHT kicks in.

The other engines (`eztv`, `limetorrents`, `solidtorrents`, `torlock`, `torrentproject`) return magnet links that already include the trackers chosen by the site, so there is nothing to change there.

### Where the tracker lists live

Both `src/torrensearch/engines/piratebay.py` and `src/torrensearch/engines/torrentscsv.py` have the same structure:

```python
trackers_list = [
    'udp://tracker.internetwarriors.net:1337/announce',
    'udp://tracker.opentrackr.org:1337/announce',
    # …
]
trackers = '&'.join(urlencode({'tr': t}) for t in trackers_list)
```

### How to add a tracker

Open the engine file and append a URL to `trackers_list`:

```python
trackers_list = [
    # … existing entries …
    'udp://tracker.opentrackr.org:1337/announce',   # existing
    'udp://new-tracker.example.com:6969/announce',  # add here
]
```

The `trackers` class attribute is computed from `trackers_list` at class definition time, so the change takes effect immediately with no other modifications.

### Tracker URL formats

| Protocol               | Example                                   |
| ---------------------- | ----------------------------------------- |
| UDP                    | `udp://tracker.example.com:6969/announce` |
| HTTP                   | `http://tracker.example.com/announce`     |
| HTTPS                  | `https://tracker.example.com/announce`    |
| WebSocket (WebTorrent) | `wss://tracker.example.com`               |

UDP trackers are the most common and have the lowest overhead. A curated list of public trackers is maintained at [github.com/ngosang/trackerslist](https://github.com/ngosang/trackerslist).

### If you write a new engine that builds magnet links from infohashes

Follow the same pattern used by `piratebay` and `torrentscsv`:

```python
from urllib.parse import urlencode

class myengine:
    trackers_list = [
        'udp://tracker.opentrackr.org:1337/announce',
        'udp://open.stealth.si:80/announce',
        # … add more …
    ]
    trackers = '&'.join(urlencode({'tr': t}) for t in trackers_list)

    def _magnet(self, infohash: str, name: str) -> str:
        dn = urlencode({'dn': name})
        return f"magnet:?xt=urn:btih:{infohash}&{dn}&{self.trackers}"
```

## Project structure

```console
torrent-search/
├── pyproject.toml                     # project config & dependencies
└── src/
    └── torrensearch/
        ├── cli.py                     # everything: engine loader, search, display, CLI
        └── engines/                   # one .py file per search engine
            ├── _http.py               # shared fetch() / download_file() utility
            ├── eztv.py
            ├── piratebay.py
            ├── torrentscsv.py
            └── …
```

Each engine exposes a single `search(query, category) -> list[dict]` method. `cli.py` imports engines dynamically at search time, runs them in parallel threads, and merges the results.
