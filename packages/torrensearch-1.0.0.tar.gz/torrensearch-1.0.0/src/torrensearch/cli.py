"""
torrensearch — interactive torrent search CLI.

Usage:
  torrensearch "ubuntu 22.04"
  torrensearch "breaking bad" --category tv --engines piratebay,eztv
  torrensearch "arch linux" --limit 20 --list-engines
"""

import argparse
import importlib
import os
import subprocess
import sys
import threading
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.table import Table
from rich.text import Text

console = Console()

# ─── config dir (XDG Base Directory Specification) ────────────────────────────


def _config_dir() -> Path:
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = Path(xdg) if xdg else Path.home() / ".config"
    return base / "torrent-search"


_JACKETT_DEFAULTS: dict[str, Any] = {
    "api_key": "YOUR_API_KEY_HERE",
    "url": "http://127.0.0.1:9117",
    "tracker_first": False,
    "thread_count": 20,
}


def init_config() -> None:
    import json

    d = _config_dir()
    d.mkdir(parents=True, exist_ok=True)
    jackett_cfg = d / "jackett.json"
    if not jackett_cfg.exists():
        jackett_cfg.write_text(
            json.dumps(_JACKETT_DEFAULTS, indent=4) + "\n", encoding="utf-8"
        )
    os.environ["torrensearch_CONFIG_DIR"] = str(d)


# ─── engines ──────────────────────────────────────────────────────────────────

_ENGINES_DIR = str(Path(__file__).parent / "engines")
if _ENGINES_DIR not in sys.path:
    sys.path.insert(0, _ENGINES_DIR)

CATEGORIES = {"all", "anime", "books", "games", "movies", "music", "software", "tv"}


def list_engines() -> list[str]:
    return sorted(
        p.stem for p in Path(_ENGINES_DIR).glob("*.py") if not p.name.startswith("_")
    )


# ─── search ───────────────────────────────────────────────────────────────────


def _run_one(
    name: str,
    query: str,
    category: str,
    results: list[dict[str, Any]],
    lock: threading.Lock,
    errors: list[str],
) -> None:
    try:
        mod = importlib.import_module(name)
        engine = getattr(mod, name)()
        cat = (
            category
            if category in getattr(engine, "supported_categories", {"all"})
            else "all"
        )
        found = engine.search(query, cat) or []
        for r in found:
            r["_engine"] = name
        with lock:
            results.extend(found)
    except Exception as exc:
        with lock:
            errors.append(f"{name}: {exc}")


def search(
    query: str, engines: list[str] | None, category: str
) -> tuple[list[dict[str, Any]], list[str]]:
    results: list[dict[str, Any]] = []
    errors: list[str] = []
    lock = threading.Lock()
    threads = [
        threading.Thread(
            target=_run_one,
            args=(name, query.replace(" ", "+"), category, results, lock, errors),
            daemon=True,
        )
        for name in (engines or list_engines())
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=30)
    results.sort(
        key=lambda r: -(
            int(r["seeds"])
            if str(r.get("seeds", -1)).lstrip("-").isdigit() and int(r["seeds"]) >= 0
            else 0
        )
    )
    return results, errors


# ─── display ──────────────────────────────────────────────────────────────────


def _fmt_size(raw: Any) -> str:
    s = str(raw).strip()
    if s in ("-1", "", "None"):
        return "?"
    if s.endswith(" B"):
        try:
            b = float(s[:-2].strip())
            for unit in ("B", "KB", "MB", "GB", "TB"):
                if b < 1024:
                    return f"{b:.1f} {unit}"
                b /= 1024
            return f"{b:.1f} PB"
        except ValueError:
            pass
    return s


def _fmt_seeds(raw: Any) -> Text:
    try:
        n = int(raw)
    except (ValueError, TypeError):
        return Text("?", style="dim")
    if n < 0:
        return Text("?", style="dim")
    if n >= 100:
        return Text(str(n), style="bold green")
    if n >= 10:
        return Text(str(n), style="yellow")
    return Text(str(n), style="red")


def _build_table(results: list[dict[str, Any]]) -> Table:
    table = Table(
        show_header=True, header_style="bold cyan", border_style="dim", show_lines=False
    )
    table.add_column("#", width=4, justify="right")
    table.add_column("Name", min_width=30, no_wrap=True)
    table.add_column("Size", justify="right", min_width=9, no_wrap=True)
    table.add_column("Seeds", justify="right", width=6)
    table.add_column("Leech", justify="right", width=6)
    table.add_column("Engine", width=16)
    for i, r in enumerate(results, start=1):
        name = str(r.get("name", "?"))
        leech = str(r.get("leech", -1))
        table.add_row(
            str(i),
            name,
            _fmt_size(r.get("size")),
            _fmt_seeds(r.get("seeds", -1)),
            "?" if leech in ("-1", "") else leech,
            str(r.get("_engine", "?")),
        )
    return table


# ─── clipboard ────────────────────────────────────────────────────────────────


def _copy(text: str) -> bool:
    for cmd in (["pbcopy"], ["xclip", "-selection", "clipboard"]):
        try:
            subprocess.run(cmd, input=text.encode(), check=True, capture_output=True)
            return True
        except (FileNotFoundError, subprocess.CalledProcessError):
            pass
    return False


# ─── entry point ──────────────────────────────────────────────────────────────


def main() -> None:
    init_config()
    parser = argparse.ArgumentParser(
        prog="torrensearch", description="Search torrents and grab magnet links."
    )
    parser.add_argument("query", nargs="?", help="Search query")
    parser.add_argument(
        "--engines", "-e", default="", help="Comma-separated engines (default: all)"
    )
    parser.add_argument("--category", "-c", default="all", choices=sorted(CATEGORIES))
    parser.add_argument("--limit", "-n", type=int, default=40, metavar="N")
    parser.add_argument("--list-engines", action="store_true")
    args = parser.parse_args()

    if args.list_engines:
        for e in list_engines():
            console.print(f"  {e}")
        return

    if not args.query:
        parser.print_help()
        sys.exit(1)

    engines = [e.strip() for e in args.engines.split(",") if e.strip()] or None

    with console.status(f"[cyan]Searching for [bold]{args.query}[/bold]…"):
        results, errors = search(args.query, engines, args.category)

    for err in errors:
        console.print(f"[dim red]⚠ {err}[/dim red]")

    sliced = results[: args.limit]
    if not sliced:
        console.print("[yellow]No results found.[/yellow]")
        return

    console.print(_build_table(sliced))
    console.print(
        f"\n[dim]Showing {len(sliced)} of {len(results)} result(s). Enter [bold]#[/bold] for magnet, [bold]q[/bold] to quit.[/dim]"
    )

    while True:
        try:
            choice = input("\n> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if choice.lower() in ("q", "quit", "exit", ""):
            break
        if not choice.isdigit() or not 1 <= int(choice) <= len(sliced):
            console.print(
                f"[red]Enter a number between 1 and {len(sliced)}, or q.[/red]"
            )
            continue
        r = sliced[int(choice) - 1]
        link = str(r.get("link", ""))
        console.print(f"\n[bold]{r.get('name')}[/bold]")
        console.print(f"[green]{link}[/green]\n")
        if _copy(link):
            console.print("[dim]✓ Copied to clipboard.[/dim]")
        desc = str(r.get("desc_link", ""))
        if desc and desc != "-1":
            console.print(f"[dim]Info page: {desc}[/dim]")


if __name__ == "__main__":
    main()
