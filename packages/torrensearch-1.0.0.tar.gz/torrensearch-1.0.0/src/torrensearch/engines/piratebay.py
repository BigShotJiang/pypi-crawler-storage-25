# VERSION: 3.9
# AUTHORS: Fabien Devaux, Christophe Dumez, Arthur, Diego de las Heras

import datetime
import gzip
import html
import http.client
import io
import json
import urllib.error
import urllib.request
from typing import Any
from urllib.parse import unquote, urlencode


class piratebay:
    url = 'https://thepiratebay.org'
    name = 'The Pirate Bay'
    supported_categories = {
        'all': '0',
        'music': '100',
        'movies': '200',
        'games': '400',
        'software': '300',
    }

    trackers_list = [
        'udp://tracker.internetwarriors.net:1337/announce',
        'udp://tracker.opentrackr.org:1337/announce',
        'udp://p4p.arenabg.ch:1337/announce',
        'udp://tracker.openbittorrent.com:6969/announce',
        'udp://www.torrent.eu.org:451/announce',
        'udp://tracker.torrent.eu.org:451/announce',
        'udp://retracker.lanta-net.ru:2710/announce',
        'udp://open.stealth.si:80/announce',
        'udp://exodus.desync.com:6969/announce',
        'udp://tracker.tiny-vps.com:6969/announce',
    ]
    trackers = '&'.join(urlencode({'tr': t}) for t in trackers_list)

    def search(self, what: str, cat: str = 'all') -> list[dict[str, Any]]:
        category = self.supported_categories[cat]
        params: dict[str, str] = {'q': unquote(what)}
        if category != '0':
            params['cat'] = category

        data = self._fetch("https://apibay.org/q.php?%s" % urlencode(params))
        if not data:
            return []

        results = []
        for r in json.loads(data):
            if r['info_hash'] == '0000000000000000000000000000000000000000':
                continue
            dn = urlencode({'dn': r['name']})
            results.append({
                'link': f"magnet:?xt=urn:btih:{r['info_hash']}&{dn}&{self.trackers}",
                'name': r['name'],
                'size': str(r['size']) + ' B',
                'seeds': r['seeders'],
                'leech': r['leechers'],
                'engine_url': self.url,
                'desc_link': f"{self.url}/description.php?id={r['id']}",
                'pub_date': r['added'],
            })
        return results

    def _fetch(self, url: str) -> str:
        base = datetime.date(2024, 4, 16)
        version = 125 + (datetime.date.today() - base).days // 30
        ua = f"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:{version}.0) Gecko/20100101 Firefox/{version}.0"
        req = urllib.request.Request(url, headers={'User-Agent': ua})
        try:
            resp: http.client.HTTPResponse = urllib.request.urlopen(req)  # pylint: disable=consider-using-with
        except urllib.error.HTTPError:
            return ""
        raw = resp.read()
        if raw[:2] == b'\x1f\x8b':
            with io.BytesIO(raw) as s, gzip.GzipFile(fileobj=s) as gz:
                raw = gz.read()
        charset = 'utf-8'
        try:
            charset = resp.getheader('Content-Type', '').split('charset=', 1)[1]
        except IndexError:
            pass
        return html.unescape(raw.decode(charset, 'replace').replace('&quot;', '\\"'))
