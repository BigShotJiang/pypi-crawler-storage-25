# VERSION: 4.9
# AUTHORS: Diego de las Heras (ngosang@hotmail.es)
# CONTRIBUTORS: ukharley
#               hannsen (github.com/hannsen)
#               Alexander Georgievskiy <galeksandrp@gmail.com>

import json
import os
import urllib.request
import xml.etree.ElementTree
from datetime import datetime
from http.cookiejar import CookieJar
from multiprocessing.dummy import Pool
from threading import Lock
from typing import Any
from urllib.parse import unquote, urlencode

from _http import download_file


###############################################################################
class ProxyManager:
    HTTP_PROXY_KEY = "http_proxy"
    HTTPS_PROXY_KEY = "https_proxy"

    def __init__(self) -> None:
        self.http_proxy = os.environ.get(self.HTTP_PROXY_KEY, "")
        self.https_proxy = os.environ.get(self.HTTPS_PROXY_KEY, "")

    def enable_proxy(self, enable: bool) -> None:
        if enable:
            os.environ[self.HTTP_PROXY_KEY] = self.http_proxy
            os.environ[self.HTTPS_PROXY_KEY] = self.https_proxy
        else:
            os.environ.pop(self.HTTP_PROXY_KEY, None)
            os.environ.pop(self.HTTPS_PROXY_KEY, None)


# initialize early to ensure env vars were not tampered
proxy_manager = ProxyManager()
proxy_manager.enable_proxy(False)


###############################################################################
# load configuration from file
CONFIG_FILE = "jackett.json"
_config_dir = os.environ.get("torrensearch_CONFIG_DIR") or os.path.dirname(
    os.path.realpath(__file__)
)
CONFIG_PATH = os.path.join(_config_dir, CONFIG_FILE)
CONFIG_DATA: dict[str, Any] = {
    "api_key": "YOUR_API_KEY_HERE",
    "url": "http://127.0.0.1:9117",
    "tracker_first": False,
    "thread_count": 20,
}


def load_configuration() -> None:
    global CONFIG_DATA
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            CONFIG_DATA = json.load(f)
    except ValueError:
        CONFIG_DATA["malformed"] = True
    except Exception:
        save_configuration()

    if any(item not in CONFIG_DATA for item in ["api_key", "tracker_first", "url"]):
        CONFIG_DATA["malformed"] = True

    if "thread_count" not in CONFIG_DATA:
        CONFIG_DATA["thread_count"] = 20
        save_configuration()


def save_configuration() -> None:
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        f.write(json.dumps(CONFIG_DATA, indent=4, sort_keys=True))


load_configuration()
###############################################################################


class jackett:
    name = "Jackett"
    url = CONFIG_DATA["url"].rstrip("/")
    api_key = CONFIG_DATA["api_key"]
    thread_count = CONFIG_DATA["thread_count"]
    supported_categories = {
        "all": None,
        "anime": ["5070"],
        "books": ["8000"],
        "games": ["1000", "4000"],
        "movies": ["2000"],
        "music": ["3000"],
        "software": ["4000"],
        "tv": ["5000"],
    }

    def download_torrent(self, download_url: str) -> None:
        if download_url.startswith("magnet:?"):
            print(download_url + " " + download_url)
            return
        proxy_manager.enable_proxy(True)
        response = self._get(download_url)
        proxy_manager.enable_proxy(False)
        if response is not None and response.startswith("magnet:?"):
            print(response + " " + download_url)
        else:
            print(download_file(download_url))

    def search(self, what: str, cat: str = "all") -> list[dict[str, Any]]:
        what = unquote(what)
        category = self.supported_categories[cat.lower()]

        if "malformed" in CONFIG_DATA:
            raise RuntimeError("malformed configuration file — edit " + CONFIG_PATH)
        if self.api_key == "YOUR_API_KEY_HERE":
            raise RuntimeError("Jackett API key not configured — edit " + CONFIG_PATH)

        results: list[dict[str, Any]] = []
        lock = Lock()

        if self.thread_count > 1:
            indexers = self._get_indexers()
            if not indexers:
                raise RuntimeError(
                    "no indexers configured in Jackett — add some at " + self.url
                )
            args = [(what, category, idx, results, lock) for idx in indexers]
            with Pool(min(len(indexers), self.thread_count)) as pool:
                pool.starmap(self._search_indexer, args)
        else:
            self._search_indexer(what, category, "all", results, lock)

        return results

    def _get_indexers(self) -> list[str]:
        params = urlencode(
            [("apikey", self.api_key), ("t", "indexers"), ("configured", "true")]
        )
        response = self._get(
            f"{self.url}/api/v2.0/indexers/all/results/torznab/api?{params}"
        )
        if response is None:
            raise RuntimeError("connection error getting Jackett indexer list")
        root = xml.etree.ElementTree.fromstring(response)
        return [el.attrib["id"] for el in root.findall("indexer")]

    def _search_indexer(
        self,
        what: str,
        category: list[str] | None,
        indexer_id: str,
        results: list[dict[str, Any]],
        lock: Lock,
    ) -> None:  # type: ignore[type-arg]
        def text(e: xml.etree.ElementTree.Element | None) -> str:
            return (e.text or "") if e is not None else ""

        params: list[tuple[str, str]] = [("apikey", self.api_key), ("q", what)]
        if category is not None:
            params.append(("cat", ",".join(category)))
        url = f"{self.url}/api/v2.0/indexers/{indexer_id}/results/torznab/api?{urlencode(params)}"

        response = self._get(url)
        if response is None:
            return

        channel = xml.etree.ElementTree.fromstring(response).find("channel")
        if channel is None:
            return

        for item in channel.findall("item"):
            title_el = item.find("title")
            if title_el is None:
                continue
            title = title_el.text or ""
            tracker = text(item.find("jackettindexer"))
            name = (
                f"[{tracker}] {title}"
                if CONFIG_DATA["tracker_first"]
                else f"{title} [{tracker}]"
            )

            mag_el = item.find(self._xpath("magneturl"))
            if mag_el is not None:
                link: str = mag_el.attrib["value"]
            else:
                link_el = item.find("link")
                if link_el is None:
                    continue
                link = text(link_el)

            size_el = item.find("size")
            size: int | str = -1 if size_el is None else (text(size_el) + " B")

            seeds_el = item.find(self._xpath("seeders"))
            seeds = -1 if seeds_el is None else int(seeds_el.attrib["value"])

            peers_el = item.find(self._xpath("peers"))
            leech = -1 if peers_el is None else int(peers_el.attrib["value"])
            if seeds != -1 and leech != -1:
                leech -= seeds

            desc_el = item.find("comments") or item.find("guid")
            desc = text(desc_el)

            try:
                pub_date = int(
                    datetime.strptime(
                        text(item.find("pubDate")), "%a, %d %b %Y %H:%M:%S %z"
                    ).timestamp()
                )
            except Exception:
                pub_date = -1

            res: dict[str, Any] = {
                "link": link.replace("|", "%7C"),
                "name": name.replace("|", "%7C"),
                "size": size,
                "seeds": seeds,
                "leech": leech,
                "engine_url": self.url,
                "desc_link": desc.replace("|", "%7C"),
                "pub_date": pub_date,
            }
            with lock:
                results.append(res)

    def _xpath(self, tag: str) -> str:
        return f'./{{http://torznab.com/schemas/2015/feed}}attr[@name="{tag}"]'

    def _get(self, url: str) -> str | None:
        try:
            opener = urllib.request.build_opener(
                urllib.request.HTTPCookieProcessor(CookieJar())
            )
            return opener.open(url).read().decode("utf-8")
        except urllib.request.HTTPError as e:
            if e.code == 302:
                return e.url  # type: ignore[return-value]
        except Exception:
            pass
        return None
