# VERSION: 1.23
# AUTHORS: nindogo
# CONTRIBUTORS: Diego de las Heras (ngosang@hotmail.es)

import re
from datetime import datetime, timedelta
from html.parser import HTMLParser
from typing import Any, Callable, Mapping, Match

from _http import fetch


class eztv:
    url = 'https://eztvx.to/'
    name = 'EZTV'
    supported_categories = {'all': 'all', 'tv': 'tv'}

    class _Parser(HTMLParser):
        def __init__(self, url: str) -> None:
            super().__init__()
            self.url = url
            self.results: list[dict[str, Any]] = []
            self._item: dict[str, Any] = {}
            self._in_row = False

            now = datetime.now()
            self._date_parsers: Mapping[str, Callable[[Match[str]], datetime]] = {
                r"(\d+)h\s+(\d+)m":  lambda m: now - timedelta(hours=int(m[1]), minutes=int(m[2])),
                r"(\d+)d\s+(\d+)h":  lambda m: now - timedelta(days=int(m[1]), hours=int(m[2])),
                r"(\d+)\s+weeks?":   lambda m: now - timedelta(weeks=int(m[1])),
                r"(\d+)\s+mo":       lambda m: now - timedelta(days=int(m[1]) * 30),
                r"(\d+)\s+years?":   lambda m: now - timedelta(days=int(m[1]) * 365),
            }

        def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
            p = dict(attrs)
            if p.get('class') == 'forum_header_border' and p.get('name') == 'hover':
                self._in_row = True
                self._item = {'seeds': -1, 'leech': -1, 'size': -1, 'engine_url': self.url, 'pub_date': -1}
            if not self._in_row:
                return
            if tag == 'a' and p.get('class') == 'magnet':
                self._item['link'] = p.get('href')
            if tag == 'a' and p.get('class') == 'epinfo':
                self._item['desc_link'] = self.url + (p.get('href') or '')
                self._item['name'] = (p.get('title') or '').split(' (')[0]

        def handle_data(self, data: str) -> None:
            if not self._in_row:
                return
            data = data.replace(',', '')
            if data.endswith((' KB', ' MB', ' GB')):
                self._item['size'] = data
            elif data.isnumeric():
                self._item['seeds'] = int(data)
            else:
                for pattern, calc in self._date_parsers.items():
                    m = re.match(pattern, data)
                    if m:
                        self._item['pub_date'] = int(calc(m).timestamp())
                        break

        def handle_endtag(self, tag: str) -> None:
            if self._in_row and tag == 'tr':
                self.results.append(dict(self._item))
                self._in_row = False

    def search(self, what: str, cat: str = 'all') -> list[dict[str, Any]]:
        url = f"{self.url}/search/{what.replace('%20', '-')}"
        html = fetch(url, data=b"layout=def_wlinks")
        parser = self._Parser(self.url)
        parser.feed(html)
        parser.close()
        return parser.results
