# VERSION: 2.8
# AUTHORS: nKlido

from datetime import datetime
from html.parser import HTMLParser
from typing import Any

from _http import fetch


class solidtorrents:
    url = 'https://solidtorrents.to'
    name = 'Solid Torrents'
    supported_categories = {'all': 'all', 'music': 'Audio', 'books': 'eBook'}

    class _Parser(HTMLParser):
        _MONTHS = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec']

        def __init__(self, url: str) -> None:
            super().__init__()
            self.url = url
            self.results: list[dict[str, Any]] = []
            self._item = self._empty()
            self._in_result = False
            self._in_title = False
            self._parse_title = False
            self._in_stats = False
            self._parse_seeds = False
            self._parse_leech = False
            self._parse_size = False
            self._parse_date = False
            self._col = 0
            self._ready = False

        def _empty(self) -> dict[str, Any]:
            return {'link': '', 'name': '', 'size': '-1', 'seeds': '-1', 'leech': '-1',
                    'engine_url': self.url, 'desc_link': '', 'pub_date': -1}

        def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
            p = dict(attrs)
            cls = p.get('class') or ''

            if 'search-result' in cls:
                self._in_result = True
                return
            if not self._in_result:
                return

            if 'title' in cls and tag == 'h5':
                self._in_title = True
            if self._in_title and tag == 'a':
                self._item['desc_link'] = self.url + (p.get('href') or '')
                self._parse_title = True

            if 'stats' in cls:
                self._in_stats = True
                self._col = -1
            if self._in_stats and tag == 'div':
                self._col += 1
                if self._col == 2:
                    self._parse_size = True
            if self._in_stats and tag == 'font' and self._col == 3:
                self._parse_seeds = True
            if self._in_stats and tag == 'font' and self._col == 4:
                self._parse_leech = True
            if self._in_stats and tag == 'div' and self._col == 5:
                self._parse_date = True

            if 'dl-magnet' in cls and tag == 'a':
                self._item['link'] = p.get('href')
                self._in_result = False
                self._ready = True

        def handle_endtag(self, tag: str) -> None:
            if self._ready:
                self.results.append(dict(self._item))
                self._ready = False
                self._item = self._empty()

        def handle_data(self, data: str) -> None:
            if self._parse_title and data.strip() and data != '\n':
                self._item['name'] = data
                self._parse_title = False
                self._in_title = False
            if self._parse_size:
                self._item['size'] = data
                self._parse_size = False
            if self._parse_seeds:
                self._item['seeds'] = data
                self._parse_seeds = False
            if self._parse_leech:
                self._item['leech'] = data
                self._parse_leech = False
            if self._parse_date:
                try:
                    parts = data.replace(',', '').lower().split()
                    month, day, year = parts
                    self._item['pub_date'] = int(datetime(int(year), self._MONTHS.index(month) + 1, int(day)).timestamp())
                except Exception:
                    self._item['pub_date'] = -1
                self._parse_date = False
                self._in_stats = False

    def search(self, what: str, cat: str = 'all') -> list[dict[str, Any]]:
        category = self.supported_categories[cat]
        results: list[dict[str, Any]] = []
        for page in range(1, 5):
            parser = self._Parser(self.url)
            parser.feed(fetch(f"{self.url}/search?q={what}&category={category}&sort=seeders&sort=desc&page={page}"))
            parser.close()
            results.extend(parser.results)
            if len(parser.results) < 15:
                break
        return results
