# VERSION: 1.91
# AUTHORS: mauricci

import re
from datetime import datetime
from html.parser import HTMLParser
from typing import Any
from urllib.parse import unquote

from _http import fetch


class torrentproject:
    url = 'https://torrentproject.com.se'
    name = 'TorrentProject'
    supported_categories = {'all': '0'}

    class _Parser(HTMLParser):
        _INFO_MAP = {"name": 0, "torrLink": 0, "seeds": 2, "leech": 3, "pub_date": 4, "size": 5}

        def __init__(self, url: str) -> None:
            super().__init__()
            self.url = url
            self.results: list[dict[str, Any]] = []
            self._page_results: list[dict[str, Any]] = []
            self._item = self._empty()
            self._in_results = False
            self._in_div = False
            self._done = False
            self._span = -1

        def _empty(self) -> dict[str, Any]:
            return {'name': '-1', 'seeds': '-1', 'leech': '-1', 'size': '-1',
                    'link': '-1', 'desc_link': '-1', 'engine_url': self.url, 'pub_date': '-1'}

        def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
            p = dict(attrs)
            if tag == 'div' and 'nav' in (p.get('id') or ''):
                self._done = True
            if tag == 'div' and p.get('id') == 'similarfiles':
                self._in_results = True
            if tag == 'div' and self._in_results and 'gac_bb' not in (p.get('class') or ''):
                self._in_div = True
            elif tag == 'span' and self._in_div and p.get('title') != 'verified':
                self._span += 1
            if self._in_div and tag == 'a' and p.get('href'):
                href = p['href'] or ''
                if self._INFO_MAP['torrLink'] == self._span:
                    self._item['link'] = self.url + href
                if self._INFO_MAP['name'] == self._span:
                    self._item['desc_link'] = self.url + href

        def handle_endtag(self, tag: str) -> None:
            if self._done:
                return
            if tag == 'div':
                self._in_div = False
                self._span = -1
                name = self._item.get('name', '-1')
                size = self._item.get('size', '-1')
                if (name not in ('-1', '') and size != '-1' and name.lower() != 'nome'
                        and (self._item['desc_link'] != '-1' or self._item['link'] != '-1')):
                    try:
                        self._item['pub_date'] = int(datetime.strptime(str(self._item['pub_date']), '%Y-%m-%d %H:%M:%S').timestamp())
                    except Exception:
                        pass
                    self.results.append(dict(self._item))
                    self._page_results.append(self._item)
                self._item = self._empty()

        def handle_data(self, data: str) -> None:
            if not self._in_div:
                return
            for key, span in self._INFO_MAP.items():
                if self._span == span and data.strip() and key in self._item:
                    if self._item.get(key) == '-1':
                        self._item[key] = data.strip()
                    elif key != 'name':
                        self._item[key] += data.strip()

    def search(self, what: str, cat: str = 'all') -> list[dict[str, Any]]:
        what = what.replace('%20', '+')
        results: list[dict[str, Any]] = []
        for page in range(0, 5):
            parser = self._Parser(self.url)
            parser.feed(fetch(f"{self.url}/browse?t={what}&p={page}"))
            parser.close()
            results.extend(parser.results)
            if len(parser._page_results) < 20:
                break
        return results

    def download_torrent(self, info: str) -> None:
        page = fetch(info)
        m = re.search(r"href=['\"].*?(magnet.+?)['\"]", page)
        if m:
            print(unquote(m.group(1)) + ' ' + info)
