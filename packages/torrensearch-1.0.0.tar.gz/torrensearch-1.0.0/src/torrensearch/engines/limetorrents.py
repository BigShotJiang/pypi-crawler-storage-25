# VERSION: 4.14
# AUTHORS: Lima66
# CONTRIBUTORS: Diego de las Heras (ngosang@hotmail.es)

import re
from datetime import datetime, timedelta
from html.parser import HTMLParser
from typing import Any, Callable, Mapping, Match
from urllib.parse import quote

from _http import fetch


class limetorrents:
    url = "https://www.limetorrents.lol"
    name = "LimeTorrents"
    supported_categories = {
        'all': 'all',
        'anime': 'anime',
        'software': 'applications',
        'games': 'games',
        'movies': 'movies',
        'music': 'music',
        'tv': 'tv',
    }

    class _Parser(HTMLParser):
        _COLUMNS = ["name", "pub_date", "size", "seeds", "leech"]

        def __init__(self, url: str) -> None:
            super().__init__()
            self.url = url
            self.results: list[dict[str, Any]] = []
            self._item: dict[str, Any] = {}
            self._in_table = False
            self._in_row = False
            self._col_idx = -1
            self._col_name: str | None = None

            now = datetime.now()
            self._date_parsers: Mapping[str, Callable[[Match[str]], datetime]] = {
                r"yesterday":        lambda m: now - timedelta(days=1),
                r"last\s+month":     lambda m: now - timedelta(days=30),
                r"(\d+)\s+years?":   lambda m: now - timedelta(days=int(m[1]) * 365),
                r"(\d+)\s+months?":  lambda m: now - timedelta(days=int(m[1]) * 30),
                r"(\d+)\s+days?":    lambda m: now - timedelta(days=int(m[1])),
                r"(\d+)\s+hours?":   lambda m: now - timedelta(hours=int(m[1])),
                r"(\d+)\s+minutes?": lambda m: now - timedelta(minutes=int(m[1])),
            }

        def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
            p = dict(attrs)
            if p.get('class') == 'table2':
                self._in_table = True
            if not self._in_table:
                return
            if tag == 'tr' and p.get('bgcolor') in ('#F4F4F4', '#FFFFFF'):
                self._in_row = True
                self._col_idx = -1
                self._item = {'engine_url': self.url}
            if not self._in_row:
                return
            if tag == 'td':
                self._col_idx += 1
                self._col_name = self._COLUMNS[self._col_idx] if self._col_idx < len(self._COLUMNS) else None
            if self._col_name == 'name' and tag == 'a' and p.get('href', '').endswith('.html'):
                link = p['href']
                try:
                    safe = quote(self.url + link, safe='/:')
                except KeyError:
                    safe = self.url + link
                self._item['link'] = safe
                self._item['desc_link'] = safe

        def handle_data(self, data: str) -> None:
            if not self._col_name:
                return
            if self._col_name in ('size', 'seeds', 'leech'):
                data = data.replace(',', '')
            elif self._col_name == 'pub_date':
                ts = -1
                for pattern, calc in self._date_parsers.items():
                    m = re.match(pattern, data, re.IGNORECASE)
                    if m:
                        ts = int(calc(m).timestamp())
                        break
                data = str(ts)
            self._item[self._col_name] = data.strip()
            self._col_name = None

        def handle_endtag(self, tag: str) -> None:
            if tag == 'table':
                self._in_table = False
            if self._in_row and tag == 'tr':
                self._in_row = False
                self._col_name = None
                if 'link' in self._item:
                    self.results.append(dict(self._item))

    def search(self, what: str, cat: str = 'all') -> list[dict[str, Any]]:
        query = what.replace('%20', '-')
        category = self.supported_categories[cat]
        results: list[dict[str, Any]] = []
        for page in range(1, 5):
            parser = self._Parser(self.url)
            parser.feed(fetch(f"{self.url}/search/{category}/{query}/seeds/{page}/"))
            parser.close()
            results.extend(parser.results)
            if len(parser.results) < 20:
                break
        return results

    def download_torrent(self, info: str) -> None:
        page = fetch(info)
        m = re.search(r'href\s*=\s*"(magnet[^"]+)"', page)
        if m:
            print(m.group(1) + ' ' + info)
