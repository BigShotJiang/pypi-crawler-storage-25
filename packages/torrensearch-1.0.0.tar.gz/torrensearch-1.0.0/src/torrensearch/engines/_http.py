import gzip
import tempfile
import urllib.error
import urllib.request

_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0",
    "Accept-Encoding": "gzip, deflate",
}


def fetch(url: str, data: bytes | None = None) -> str:
    try:
        req = urllib.request.Request(url, data=data, headers=_HEADERS)
        with urllib.request.urlopen(req, timeout=20) as r:
            raw = r.read()
            if r.headers.get("Content-Encoding") == "gzip":
                raw = gzip.decompress(raw)
            return raw.decode(r.headers.get_content_charset() or "utf-8", errors="replace")
    except (urllib.error.HTTPError, urllib.error.URLError):
        return ""


def download_file(url: str) -> str:
    with urllib.request.urlopen(urllib.request.Request(url, headers=_HEADERS), timeout=20) as r:
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".torrent")
        tmp.write(r.read())
        tmp.close()
        return tmp.name
