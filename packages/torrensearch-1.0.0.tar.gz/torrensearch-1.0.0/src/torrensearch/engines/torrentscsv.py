# VERSION: 1.8
# AUTHORS: Dessalines

import json
from typing import Any
from urllib.parse import urlencode

from _http import fetch


class torrentscsv:
    url = 'https://torrents-csv.com'
    name = 'torrents-csv'
    supported_categories = {'all': ''}

    trackers_list = [
        'udp://tracker.internetwarriors.net:1337/announce',
        'udp://tracker.opentrackr.org:1337/announce',
        'udp://p4p.arenabg.ch:1337/announce',
        'udp://tracker.openbittorrent.com:6969/announce',
        'udp://www.torrent.eu.org:451/announce',
        'udp://tracker.torrent.eu.org:451/announce',
        'udp://retracker.lanta-net.ru:2710/announce',
        'udp://open.stealth.si:80/announce',
        'udp://exodus.desync.com:6969/announce',
        'udp://tracker.tiny-vps.com:6969/announce',
    ]
    trackers = '&'.join(urlencode({'tr': t}) for t in trackers_list)

    def search(self, what: str, cat: str = 'all') -> list[dict[str, Any]]:
        response = fetch(f"{self.url}/service/search?size=100&q={what}")
        if not response:
            return []
        results = []
        for r in json.loads(response).get("torrents", []):
            dn = urlencode({'dn': r['name']})
            results.append({
                'link': f"magnet:?xt=urn:btih:{r['infohash']}&{dn}&{self.trackers}",
                'name': r['name'],
                'size': str(r['size_bytes']) + ' B',
                'seeds': r['seeders'],
                'leech': r['leechers'],
                'engine_url': self.url,
                'desc_link': f"{self.url}/#/search/torrent/{what}/1",
                'pub_date': r['created_unix'],
            })
        return results
