# VERSION: 2.28
# AUTHORS: Douman (custparasite@gmx.se)
# CONTRIBUTORS: Diego de las Heras (ngosang@hotmail.es)

from datetime import datetime, timedelta
from html.parser import HTMLParser
from typing import Any

from _http import download_file, fetch


class torlock:
    url = "https://www.torlock.com"
    name = "TorLock"
    supported_categories = {
        'all': 'all',
        'anime': 'anime',
        'software': 'software',
        'games': 'game',
        'movies': 'movie',
        'music': 'music',
        'tv': 'television',
        'books': 'ebooks',
    }

    class _Parser(HTMLParser):
        _CLASS_MAP = {"td": "pub_date", "ts": "size", "tul": "seeds", "tdl": "leech"}

        def __init__(self, url: str) -> None:
            super().__init__()
            self.url = url
            self.results: list[dict[str, Any]] = []
            self._item: dict[str, Any] = {}
            self._in_article = False
            self._in_item = False
            self._bad = False
            self._field: str | None = None

        def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
            p = dict(attrs)
            if tag == 'article':
                self._in_article = True
                self._item = {}
            if self._in_item:
                if tag == 'td':
                    self._field = self._CLASS_MAP.get(p.get('class') or '')
                    if self._field:
                        self._item[self._field] = ''
            elif self._in_article and tag == 'a':
                href = p.get('href') or ''
                if href.startswith('/torrent'):
                    self._item = {
                        'desc_link': self.url + href,
                        'link': f"{self.url}/tor/{href.split('/')[2]}.torrent",
                        'engine_url': self.url,
                        'name': '',
                    }
                    self._in_item = True
                    self._field = 'name'
                    self._bad = p.get('rel') == 'nofollow'

        def handle_data(self, data: str) -> None:
            if self._field:
                self._item[self._field] += data

        def handle_endtag(self, tag: str) -> None:
            if tag == 'article':
                self._in_article = False
            elif self._field and tag in ('a', 'td'):
                self._field = None
            elif self._in_item and tag == 'tr':
                self._in_item = False
                if not self._bad:
                    try:
                        d = self._item.get('pub_date', '')
                        if d == 'Today':
                            date = datetime.now()
                        elif d == 'Yesterday':
                            date = datetime.now() - timedelta(days=1)
                        else:
                            date = datetime.strptime(d, '%m/%d/%Y')
                        self._item['pub_date'] = int(date.replace(hour=0, minute=0, second=0, microsecond=0).timestamp())
                    except Exception:
                        self._item['pub_date'] = -1
                    self.results.append(dict(self._item))
                self._item = {}

    def search(self, what: str, cat: str = 'all') -> list[dict[str, Any]]:
        query = what.replace('%20', '-')
        category = self.supported_categories[cat]
        results: list[dict[str, Any]] = []
        for page in range(1, 5):
            parser = self._Parser(self.url)
            parser.feed(fetch(f"{self.url}/{category}/torrents/{query}.html?sort=seeds&page={page}"))
            parser.close()
            results.extend(parser.results)
            if len(parser.results) < 20:
                break
        return results

    def download_torrent(self, info: str) -> None:
        print(download_file(info))
