"""SKILL.md YAML frontmatter parsing."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .errors import AgentskillError, ErrorCode
from .models import SkillMeta


def parseFrontmatter(path: Path) -> SkillMeta:
    """Parse SKILL.md YAML frontmatter into SkillMeta."""
    meta, _ = readSkillMarkdown(path)
    return meta


def readSkillMarkdown(path: Path) -> tuple[SkillMeta, str]:
    """Parse SKILL.md, return (metadata, body_markdown)."""
    if not path.exists():
        raise AgentskillError(ErrorCode.SKILL_MD_MISSING, path=str(path))

    text = path.read_text(encoding="utf-8")
    data, body = _splitFrontmatter(text, path)

    # normalize allowed-tools: space/comma-delimited string → list
    raw_tools = data.pop("allowed-tools", None)
    if isinstance(raw_tools, str):
        tokens = raw_tools.replace(",", " ").split()
        data["allowed_tools"] = [t.strip() for t in tokens if t.strip()]
    elif isinstance(raw_tools, list):
        data["allowed_tools"] = raw_tools

    try:
        meta = SkillMeta(**data)
    except Exception as e:
        raise AgentskillError(ErrorCode.SKILL_MD_INVALID, path=str(path), detail=str(e)) from e

    return meta, body


def _splitFrontmatter(text: str, path: Path) -> tuple[dict[str, Any], str]:
    """Split YAML frontmatter from markdown body."""
    stripped = text.lstrip()
    if not stripped.startswith("---"):
        raise AgentskillError(
            ErrorCode.SKILL_MD_INVALID, path=str(path), detail="missing YAML frontmatter"
        )

    # find closing ---
    rest = stripped[3:]
    end = rest.find("\n---")
    if end == -1:
        raise AgentskillError(
            ErrorCode.SKILL_MD_INVALID, path=str(path), detail="unclosed YAML frontmatter"
        )

    yaml_str = rest[:end]
    body = rest[end + 4 :].lstrip("\n")

    try:
        data = yaml.safe_load(yaml_str)
    except yaml.YAMLError as e:
        raise AgentskillError(
            ErrorCode.SKILL_MD_INVALID, path=str(path), detail=str(e)
        ) from e

    if not isinstance(data, dict):
        raise AgentskillError(
            ErrorCode.SKILL_MD_INVALID, path=str(path), detail="frontmatter must be a mapping"
        )

    return data, body
