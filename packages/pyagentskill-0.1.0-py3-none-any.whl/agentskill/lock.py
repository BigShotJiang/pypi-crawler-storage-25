"""Lock file (.skill-lock.json) CRUD — Vercel-compatible v3."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

from .models import LockEntry, LockFile, Scope

LOCK_FILENAME = ".skill-lock.json"
LOCK_VERSION = 3


def getLockPath(scope: Scope, cwd: Path | None = None) -> Path:
    """Get lock file path for the given scope."""
    if scope == Scope.GLOBAL:
        return Path.home() / ".agents" / LOCK_FILENAME
    return (cwd or Path.cwd()) / ".agents" / LOCK_FILENAME


def readLock(scope: Scope, cwd: Path | None = None) -> LockFile:
    """Read and parse lock file. Returns empty lock if missing/invalid."""
    path = getLockPath(scope, cwd)
    if not path.exists():
        return LockFile()

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return LockFile.model_validate(data)
    except Exception:
        return LockFile()


def writeLock(lock: LockFile, scope: Scope, cwd: Path | None = None) -> None:
    """Write lock file as formatted JSON. Atomic write via temp file + rename."""
    path = getLockPath(scope, cwd)
    path.parent.mkdir(parents=True, exist_ok=True)

    # sort skills alphabetically
    sorted_skills = dict(sorted(lock.skills.items()))
    data = lock.model_copy(update={"skills": sorted_skills})

    content = json.dumps(
        data.model_dump(mode="json"),
        indent=2,
        default=str,
    )

    # atomic write
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        os.write(fd, content.encode())
        os.close(fd)
        os.replace(tmp, path)
    except Exception:
        os.close(fd)
        os.unlink(tmp)
        raise


def addToLock(
    name: str, entry: LockEntry, scope: Scope, cwd: Path | None = None
) -> None:
    """Add/update a skill in the lock file. Preserves installedAt on update."""
    lock = readLock(scope, cwd)
    existing = lock.skills.get(name)

    if existing:
        # preserve original installedAt
        entry = entry.model_copy(update={"installedAt": existing.installedAt})

    new_skills = {**lock.skills, name: entry}
    updated = lock.model_copy(update={"skills": new_skills})
    writeLock(updated, scope, cwd)


def removeFromLock(name: str, scope: Scope, cwd: Path | None = None) -> bool:
    """Remove a skill from lock file. Returns True if found."""
    lock = readLock(scope, cwd)
    if name not in lock.skills:
        return False

    new_skills = {k: v for k, v in lock.skills.items() if k != name}
    updated = lock.model_copy(update={"skills": new_skills})
    writeLock(updated, scope, cwd)
    return True


def getFromLock(name: str, scope: Scope, cwd: Path | None = None) -> LockEntry | None:
    """Get a single skill's lock entry."""
    lock = readLock(scope, cwd)
    return lock.skills.get(name)
