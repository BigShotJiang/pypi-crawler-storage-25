"""Source resolution: parse source strings, clone/copy to tempdir."""

from __future__ import annotations

import re
import shutil
import subprocess
import tempfile
from pathlib import Path

from .errors import AgentskillError, ErrorCode
from .models import ParsedSource, SourceType

# matches owner/repo or owner/repo/sub/path
_GITHUB_SHORT_RE = re.compile(r"^([a-zA-Z0-9_.-]+)/([a-zA-Z0-9_.-]+)(/.*)?$")
_GITHUB_URL_RE = re.compile(
    r"^https?://github\.com/([a-zA-Z0-9_.-]+)/([a-zA-Z0-9_.-]+)(?:\.git)?(/tree/[^/]+/(.+))?/?$"
)
_GIT_URL_RE = re.compile(r"^(https?://|git@|ssh://)")


def parseSource(source: str) -> ParsedSource:
    """Parse a source string into structured form.

    Handles:
    - "/absolute/path" or "./relative" or "~/path" -> local
    - "https://github.com/owner/repo" -> GitHub
    - "git@..." or "ssh://..." -> Git URL
    - "owner/repo" or "owner/repo/sub/path" -> GitHub shorthand
    """
    # local path
    if source.startswith(("/", "./", "../", "~")):
        expanded = Path(source).expanduser().resolve()
        return ParsedSource(
            source_type=SourceType.LOCAL,
            local_path=str(expanded),
            url=str(expanded),
        )

    # GitHub URL
    m = _GITHUB_URL_RE.match(source)
    if m:
        owner, repo = m.group(1), m.group(2)
        subpath = m.group(4)  # after /tree/branch/
        return ParsedSource(
            source_type=SourceType.GITHUB,
            owner=owner,
            repo=repo,
            subpath=subpath,
            url=f"https://github.com/{owner}/{repo}.git",
        )

    # generic git URL
    if _GIT_URL_RE.match(source):
        # extract owner/repo from git URL
        parts = source.rstrip("/").rstrip(".git").split("/")
        owner = parts[-2] if len(parts) >= 2 else None
        repo = parts[-1] if len(parts) >= 1 else None
        return ParsedSource(
            source_type=SourceType.GIT,
            owner=owner,
            repo=repo,
            url=source,
        )

    # GitHub shorthand: owner/repo or owner/repo/sub/path
    m = _GITHUB_SHORT_RE.match(source)
    if m:
        owner, repo = m.group(1), m.group(2)
        subpath = m.group(3)
        if subpath:
            subpath = subpath.lstrip("/")
        return ParsedSource(
            source_type=SourceType.GITHUB,
            owner=owner,
            repo=repo,
            subpath=subpath or None,
            url=f"https://github.com/{owner}/{repo}.git",
        )

    raise AgentskillError(ErrorCode.SOURCE_INVALID, source=source)


def cloneSource(parsed: ParsedSource) -> Path:
    """Clone/copy source to a temporary directory. Returns path to skill dir.

    Caller is responsible for cleaning up the returned temp directory.
    """
    if parsed.source_type == SourceType.LOCAL:
        return _resolveLocal(parsed)
    return _cloneGit(parsed)


def _resolveLocal(parsed: ParsedSource) -> Path:
    """Resolve a local source path."""
    assert parsed.local_path
    path = Path(parsed.local_path)

    if not path.exists():
        raise AgentskillError(ErrorCode.SOURCE_NOT_FOUND, source=str(path))

    # if it's a directory with SKILL.md, return it directly
    if path.is_dir() and (path / "SKILL.md").exists():
        return path

    # check if it's a parent dir containing skill subdirs
    if path.is_dir():
        # look for SKILL.md one level down
        for child in path.iterdir():
            if child.is_dir() and (child / "SKILL.md").exists():
                return child

    raise AgentskillError(ErrorCode.SKILL_MD_MISSING, path=str(path))


def _cloneGit(parsed: ParsedSource) -> Path:
    """Clone a git repo to tempdir and return skill directory path."""
    tmpdir = tempfile.mkdtemp(prefix="agentskill-")

    try:
        result = subprocess.run(
            ["git", "clone", "--depth", "1", parsed.url, tmpdir],
            capture_output=True,
            text=True,
            timeout=120,
        )
    except subprocess.TimeoutExpired as e:
        shutil.rmtree(tmpdir, ignore_errors=True)
        raise AgentskillError(ErrorCode.SOURCE_CLONE_TIMEOUT, source=parsed.url) from e

    if result.returncode != 0:
        shutil.rmtree(tmpdir, ignore_errors=True)
        raise AgentskillError(
            ErrorCode.SOURCE_CLONE_FAILED, source=parsed.url, detail=result.stderr.strip()
        )

    repo_path = Path(tmpdir)

    skill_dir = repo_path / parsed.subpath if parsed.subpath else repo_path

    # verify SKILL.md exists
    if (skill_dir / "SKILL.md").exists():
        return skill_dir

    # if no SKILL.md at root/subpath, check one level down
    if skill_dir.is_dir():
        for child in skill_dir.iterdir():
            if child.is_dir() and (child / "SKILL.md").exists():
                return child

    shutil.rmtree(tmpdir, ignore_errors=True)
    raise AgentskillError(ErrorCode.SKILL_MD_MISSING, path=str(skill_dir))
