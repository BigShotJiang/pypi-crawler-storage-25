"""Typer CLI for agentskill."""

from __future__ import annotations

import json
from typing import Annotated

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from . import __version__
from .agents import AGENTS, detectInstalledAgents, listAgents
from .errors import AgentskillError
from .models import Scope
from .skills import (
    getSkill,
    installSkill,
    listSkills,
    removeSkill,
    updateSkill,
)

app = typer.Typer(
    name="agentskill",
    help="Agent skill manager for the Agent Skills standard (agentskills.io)",
    invoke_without_command=True,
)
console = Console()
_json_mode = False


def _error(msg: str) -> None:
    if _json_mode:
        console.print_json(json.dumps({"ok": False, "error": msg}))
    else:
        console.print(f"[red]Error:[/red] {msg}")
    raise typer.Exit(1)


@app.callback(invoke_without_command=True)
def main_callback(
    ctx: typer.Context,
    json_output: Annotated[
        bool, typer.Option("--json", help="Output as JSON")
    ] = False,
    version: Annotated[
        bool, typer.Option("--version", "-V", help="Show version", is_eager=True)
    ] = False,
) -> None:
    global _json_mode
    _json_mode = json_output
    if version:
        if _json_mode:
            console.print_json(json.dumps({"version": __version__}))
        else:
            console.print(f"agentskill {__version__}")
        raise typer.Exit()
    if ctx.invoked_subcommand is None:
        console.print(ctx.get_help())
        raise typer.Exit()


@app.command()
def install(
    source: Annotated[str, typer.Argument(help="GitHub owner/repo[/path], local path, or git URL")],
    name: Annotated[str | None, typer.Option("--name", "-n", help="Override skill name")] = None,
    scope: Annotated[str, typer.Option("--scope", "-s", help="global or project")] = "global",
    agent: Annotated[list[str] | None, typer.Option("--agent", "-a", help="Target agents")] = None,
) -> None:
    """Install a skill from source."""
    try:
        result = installSkill(
            source,
            scope=Scope(scope),
            agents=agent,
            name=name,
        )
    except AgentskillError as e:
        _error(e.message)
        return

    if _json_mode:
        console.print_json(json.dumps(result.model_dump(mode="json"), default=str))
    else:
        console.print(f"[green]Installed[/green] {result.name} → {result.path}")
        if result.symlinks:
            agents_str = ", ".join(result.symlinks)
            console.print(f"  Symlinked for: {agents_str}")


@app.command()
def update(
    name: Annotated[
        str | None, typer.Argument(help="Skill name (omit for all)")
    ] = None,
    scope: Annotated[str, typer.Option("--scope", "-s", help="global or project")] = "global",
) -> None:
    """Update one or all skills."""
    s = Scope(scope)
    try:
        if name:
            result = updateSkill(name, scope=s)
            if _json_mode:
                if result:
                    console.print_json(json.dumps(result.model_dump(mode="json"), default=str))
                else:
                    console.print_json(json.dumps({"ok": True, "updated": False}))
            elif result:
                console.print(f"[green]Updated[/green] {result.name}")
            else:
                console.print(f"{name} is up-to-date")
        else:
            # update all
            skills = listSkills(scope=s)
            updated = 0
            for skill in skills:
                try:
                    result = updateSkill(skill.name, scope=s)
                    if result:
                        updated += 1
                        if not _json_mode:
                            console.print(f"[green]Updated[/green] {result.name}")
                except AgentskillError:
                    if not _json_mode:
                        console.print(f"[yellow]Skipped[/yellow] {skill.name}")

            if _json_mode:
                console.print_json(json.dumps({"ok": True, "updated": updated}))
            else:
                console.print(f"{updated} skill(s) updated")
    except AgentskillError as e:
        _error(e.message)


@app.command()
def remove(
    name: Annotated[str, typer.Argument(help="Skill name to remove")],
    scope: Annotated[str, typer.Option("--scope", "-s", help="global or project")] = "global",
) -> None:
    """Remove a skill and its symlinks."""
    s = Scope(scope)
    removed = removeSkill(name, scope=s)

    if _json_mode:
        console.print_json(json.dumps({"ok": True, "removed": removed}))
    elif removed:
        console.print(f"[green]Removed[/green] {name}")
    else:
        console.print(f"Skill '{name}' not found")


@app.command(name="list")
def list_cmd(
    scope: Annotated[
        str | None, typer.Option("--scope", "-s", help="global, project, or all")
    ] = None,
) -> None:
    """List installed skills."""
    s = Scope(scope) if scope and scope != "all" else None
    skills = listSkills(scope=s)

    if _json_mode:
        console.print_json(
            json.dumps([sk.model_dump(mode="json") for sk in skills], default=str)
        )
        return

    if not skills:
        console.print("No skills installed")
        return

    table = Table(title="Installed Skills")
    table.add_column("Name", style="cyan")
    table.add_column("Source")
    table.add_column("Scope")
    table.add_column("Updated")

    for sk in skills:
        source = sk.lock.source if sk.lock else "—"
        updated = str(sk.lock.updatedAt.date()) if sk.lock else "—"
        table.add_row(sk.name, source, sk.scope.value, updated)

    console.print(table)


@app.command()
def info(
    name: Annotated[str, typer.Argument(help="Skill name")],
    scope: Annotated[str, typer.Option("--scope", "-s", help="global or project")] = "global",
) -> None:
    """Show skill details and metadata."""
    s = Scope(scope)
    skill = getSkill(name, scope=s)

    if not skill:
        _error(f"Skill '{name}' not found")
        return

    if _json_mode:
        console.print_json(json.dumps(skill.model_dump(mode="json"), default=str))
        return

    lines = [
        f"[bold]Name:[/bold] {skill.meta.name}",
        f"[bold]Description:[/bold] {skill.meta.description}",
        f"[bold]Path:[/bold] {skill.path}",
        f"[bold]Scope:[/bold] {skill.scope.value}",
    ]

    if skill.meta.license:
        lines.append(f"[bold]License:[/bold] {skill.meta.license}")
    if skill.meta.compatibility:
        lines.append(f"[bold]Compatibility:[/bold] {skill.meta.compatibility}")
    if skill.meta.allowed_tools:
        lines.append(f"[bold]Allowed Tools:[/bold] {', '.join(skill.meta.allowed_tools)}")
    if skill.lock:
        lines.append(f"[bold]Source:[/bold] {skill.lock.source}")
        lines.append(f"[bold]Hash:[/bold] {skill.lock.skillFolderHash or '—'}")
        lines.append(f"[bold]Installed:[/bold] {skill.lock.installedAt}")
        lines.append(f"[bold]Updated:[/bold] {skill.lock.updatedAt}")

    console.print(Panel("\n".join(lines), title=name))


@app.command()
def agents(
    detect: Annotated[
        bool, typer.Option("--detect", "-d", help="Only show detected/installed agents")
    ] = False,
) -> None:
    """List known agents and their skills directories."""
    if detect:
        installed = detectInstalledAgents()
        agent_list = [AGENTS[a] for a in installed]
    else:
        agent_list = listAgents()

    if _json_mode:
        console.print_json(
            json.dumps([a.model_dump() for a in agent_list], default=str)
        )
        return

    table = Table(title="Agents")
    table.add_column("ID", style="cyan")
    table.add_column("Name")
    table.add_column("Global Skills Dir")
    table.add_column("Universal", justify="center")

    for a in agent_list:
        universal = "[green]yes[/green]" if a.reads_universal else "no"
        table.add_row(a.id, a.name, a.global_skills_dir, universal)

    console.print(table)


def main() -> None:
    app()
