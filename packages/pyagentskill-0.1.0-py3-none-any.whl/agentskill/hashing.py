"""Directory hashing and GitHub tree SHA fetching."""

from __future__ import annotations

import hashlib
import subprocess
from pathlib import Path

import httpx

EXCLUDE_DIRS = {".git", "__pycache__", "node_modules", ".DS_Store"}


def computeDirHash(path: Path) -> str:
    """Compute sha256 hash of a directory's contents.

    Sorts files by relative path, hashes each (path + content).
    """
    hasher = hashlib.sha256()
    files: list[Path] = []

    for item in sorted(path.rglob("*")):
        if any(part in EXCLUDE_DIRS for part in item.parts):
            continue
        if item.is_file():
            files.append(item)

    for f in files:
        rel = str(f.relative_to(path))
        hasher.update(rel.encode())
        hasher.update(f.read_bytes())

    return hasher.hexdigest()


def fetchGithubTreeSha(
    owner: str,
    repo: str,
    subpath: str | None = None,
    ref: str | None = None,
    token: str | None = None,
) -> str | None:
    """Fetch GitHub tree SHA for a folder using the Git Trees API."""
    token = token or getGithubToken()
    headers: dict[str, str] = {"Accept": "application/vnd.github+json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    # try provided ref, then main, then master
    refs = [ref] if ref else ["main", "master"]

    for branch in refs:
        url = f"https://api.github.com/repos/{owner}/{repo}/git/trees/{branch}?recursive=1"
        try:
            resp = httpx.get(url, headers=headers, timeout=15)
        except httpx.HTTPError:
            continue

        if resp.status_code == 403:
            return None  # rate limited
        if resp.status_code != 200:
            continue

        tree = resp.json()
        if not subpath:
            return tree.get("sha")

        # find the subtree entry matching subpath
        for entry in tree.get("tree", []):
            if entry.get("path") == subpath and entry.get("type") == "tree":
                return entry.get("sha")

    return None


def getGithubToken() -> str | None:
    """Get GitHub token from env or gh CLI."""
    import os

    for var in ("GITHUB_TOKEN", "GH_TOKEN"):
        val = os.environ.get(var)
        if val:
            return val

    try:
        result = subprocess.run(
            ["gh", "auth", "token"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    return None
