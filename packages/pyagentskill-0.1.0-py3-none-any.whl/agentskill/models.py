"""Pydantic models for agentskill."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict


class Scope(StrEnum):
    """Installation scope."""

    GLOBAL = "global"
    PROJECT = "project"


class SourceType(StrEnum):
    """Skill source type."""

    GITHUB = "github"
    LOCAL = "local"
    GIT = "git"


class SkillMeta(BaseModel):
    """SKILL.md frontmatter parsed into a model."""

    model_config = ConfigDict(frozen=True)

    name: str
    description: str = ""
    license: str | None = None
    compatibility: str | None = None
    allowed_tools: list[str] = []
    metadata: dict[str, Any] = {}


class AgentDef(BaseModel):
    """Agent definition — how to find its skills directory."""

    model_config = ConfigDict(frozen=True)

    id: str
    name: str
    skills_dir: str
    global_skills_dir: str
    detect_path: str
    reads_universal: bool = False


class LockEntry(BaseModel):
    """Single skill entry in the lock file. Compatible with Vercel's .skill-lock.json."""

    model_config = ConfigDict(frozen=True)

    source: str
    sourceType: SourceType
    sourceUrl: str
    skillPath: str
    skillFolderHash: str | None = None
    installedAt: datetime
    updatedAt: datetime


class LockFile(BaseModel):
    """Lock file schema. Compatible with Vercel's .skill-lock.json v3."""

    model_config = ConfigDict(frozen=True)

    version: int = 3
    skills: dict[str, LockEntry] = {}
    dismissed: dict[str, bool] = {}
    lastSelectedAgents: list[str] = []


class ParsedSource(BaseModel):
    """Resolved source information."""

    model_config = ConfigDict(frozen=True)

    source_type: SourceType
    owner: str | None = None
    repo: str | None = None
    subpath: str | None = None
    ref: str | None = None
    local_path: str | None = None
    url: str


class SkillInfo(BaseModel):
    """Full skill info returned by getSkill/listSkills."""

    model_config = ConfigDict(frozen=True)

    name: str
    meta: SkillMeta
    lock: LockEntry | None = None
    path: str
    scope: Scope
    symlinks: list[str] = []
