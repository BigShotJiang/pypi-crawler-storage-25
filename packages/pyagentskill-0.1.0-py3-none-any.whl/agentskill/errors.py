"""Centralized error codes, messages, and exception for agentskill."""

from __future__ import annotations

from enum import StrEnum


class ErrorCode(StrEnum):
    """All agentskill error codes."""

    # Source errors (E1xx)
    SOURCE_INVALID = "E100"
    SOURCE_NOT_FOUND = "E101"
    SOURCE_CLONE_FAILED = "E102"
    SOURCE_CLONE_TIMEOUT = "E103"

    # Skill errors (E2xx)
    SKILL_NOT_FOUND = "E200"
    SKILL_ALREADY_INSTALLED = "E201"
    SKILL_MD_MISSING = "E202"
    SKILL_MD_INVALID = "E203"
    SKILL_NAME_INVALID = "E204"

    # Lock errors (E3xx)
    LOCK_READ_ERROR = "E300"
    LOCK_WRITE_ERROR = "E301"

    # Agent errors (E4xx)
    AGENT_NOT_FOUND = "E400"
    SYMLINK_FAILED = "E401"

    # GitHub API errors (E5xx)
    GITHUB_API_ERROR = "E500"
    GITHUB_RATE_LIMITED = "E501"

    # General (E9xx)
    INTERNAL = "E900"


MESSAGES: dict[ErrorCode, str] = {
    ErrorCode.SOURCE_INVALID: "Invalid source: {source}",
    ErrorCode.SOURCE_NOT_FOUND: "Source not found: {source}",
    ErrorCode.SOURCE_CLONE_FAILED: "Failed to clone: {source} — {detail}",
    ErrorCode.SOURCE_CLONE_TIMEOUT: "Clone timed out: {source}",
    ErrorCode.SKILL_NOT_FOUND: "Skill '{name}' not found",
    ErrorCode.SKILL_ALREADY_INSTALLED: "Skill '{name}' already installed",
    ErrorCode.SKILL_MD_MISSING: "SKILL.md not found in {path}",
    ErrorCode.SKILL_MD_INVALID: "Invalid SKILL.md in {path}: {detail}",
    ErrorCode.SKILL_NAME_INVALID: "Invalid skill name: '{name}'",
    ErrorCode.LOCK_READ_ERROR: "Failed to read lock file: {path}",
    ErrorCode.LOCK_WRITE_ERROR: "Failed to write lock file: {path}",
    ErrorCode.AGENT_NOT_FOUND: "Agent '{agent}' not found in registry",
    ErrorCode.SYMLINK_FAILED: "Failed to create symlink: {target} -> {link}",
    ErrorCode.GITHUB_API_ERROR: "GitHub API error: {detail}",
    ErrorCode.GITHUB_RATE_LIMITED: (
        "GitHub API rate limit exceeded. Set GITHUB_TOKEN for higher limits."
    ),
    ErrorCode.INTERNAL: "Internal error: {detail}",
}


class AgentskillError(Exception):
    """Structured error with code, message, and optional details."""

    def __init__(self, code: ErrorCode, **kwargs: str | int | list[str]) -> None:
        self.code = code
        self.details = kwargs
        template = MESSAGES.get(code, str(code))
        try:
            self.message = template.format(**kwargs)
        except KeyError:
            self.message = template
        super().__init__(self.message)

    def toDict(self) -> dict:
        """Serialize for JSON output."""
        d: dict = {"ok": False, "error": self.code.value, "message": self.message}
        if self.details:
            d["details"] = {k: v for k, v in self.details.items()}
        return d
