"""Core skill operations: install, update, remove, list, get."""

from __future__ import annotations

import shutil
from datetime import UTC, datetime
from pathlib import Path

from .agents import (
    createSymlinks,
    detectInstalledAgents,
    getCanonicalDir,
    removeSymlinks,
)
from .errors import AgentskillError, ErrorCode
from .frontmatter import parseFrontmatter
from .hashing import computeDirHash, fetchGithubTreeSha
from .lock import addToLock, getFromLock, readLock, removeFromLock
from .models import LockEntry, Scope, SkillInfo, SourceType
from .sources import ParsedSource, cloneSource, parseSource


def installSkill(
    source: str,
    *,
    scope: Scope = Scope.GLOBAL,
    agents: list[str] | None = None,
    name: str | None = None,
    cwd: Path | None = None,
) -> SkillInfo:
    """Install a skill from source.

    1. Parse source → clone/copy to tempdir
    2. Parse SKILL.md frontmatter
    3. Copy to canonical path
    4. Create symlinks for detected agents
    5. Update lock file
    """
    parsed = parseSource(source)
    is_local = parsed.source_type == SourceType.LOCAL
    skill_dir = cloneSource(parsed)

    try:
        meta = parseFrontmatter(skill_dir / "SKILL.md")
        skill_name = name or meta.name

        if not skill_name:
            raise AgentskillError(ErrorCode.SKILL_NAME_INVALID, name="(empty)")

        # copy to canonical path
        canonical = getCanonicalDir(skill_name, scope, cwd)
        if canonical.exists():
            shutil.rmtree(canonical)
        canonical.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(skill_dir, canonical)

        # compute hash
        folder_hash = _computeHash(parsed, canonical)

        # create symlinks
        target_agents = agents or detectInstalledAgents()
        symlink_results = createSymlinks(skill_name, target_agents, scope, cwd)

        # build lock entry
        now = datetime.now(UTC)
        entry = LockEntry(
            source=_buildSourceId(parsed),
            sourceType=parsed.source_type,
            sourceUrl=parsed.url,
            skillPath=_buildSkillPath(parsed, skill_name),
            skillFolderHash=folder_hash,
            installedAt=now,
            updatedAt=now,
        )
        addToLock(skill_name, entry, scope, cwd)

        return SkillInfo(
            name=skill_name,
            meta=meta,
            lock=entry,
            path=str(canonical),
            scope=scope,
            symlinks=[aid for aid, ok in symlink_results if ok],
        )
    finally:
        # clean up cloned tempdir for remote sources
        if not is_local:
            _cleanupTempdir(skill_dir)


def updateSkill(
    name: str,
    *,
    scope: Scope = Scope.GLOBAL,
    cwd: Path | None = None,
) -> SkillInfo | None:
    """Check for updates and reinstall if changed. Returns None if up-to-date."""
    entry = getFromLock(name, scope, cwd)
    if not entry:
        raise AgentskillError(ErrorCode.SKILL_NOT_FOUND, name=name)

    canonical = getCanonicalDir(name, scope, cwd)
    if not canonical.exists():
        raise AgentskillError(ErrorCode.SKILL_NOT_FOUND, name=name)

    # check for changes
    new_hash: str | None = None
    if entry.sourceType == SourceType.GITHUB:
        parsed = parseSource(entry.source)
        new_hash = fetchGithubTreeSha(
            parsed.owner or "",
            parsed.repo or "",
            parsed.subpath,
        )
    elif entry.sourceType == SourceType.LOCAL:
        local_path = Path(entry.sourceUrl)
        if local_path.exists():
            new_hash = computeDirHash(local_path)
    elif entry.sourceType == SourceType.GIT:
        # for generic git, always re-clone to check
        new_hash = None  # force reinstall

    if new_hash and new_hash == entry.skillFolderHash:
        return None  # up-to-date

    # reinstall from original source
    return installSkill(entry.source, scope=scope, name=name, cwd=cwd)


def removeSkill(
    name: str,
    *,
    scope: Scope = Scope.GLOBAL,
    cwd: Path | None = None,
) -> bool:
    """Remove skill and all symlinks."""
    canonical = getCanonicalDir(name, scope, cwd)

    # remove symlinks first
    removeSymlinks(name, scope, cwd)

    # remove canonical dir
    if canonical.exists():
        shutil.rmtree(canonical)

    # remove from lock
    return removeFromLock(name, scope, cwd)


def listSkills(
    scope: Scope | None = None,
    cwd: Path | None = None,
) -> list[SkillInfo]:
    """List installed skills with metadata."""
    results: list[SkillInfo] = []
    scopes = [Scope.GLOBAL, Scope.PROJECT] if scope is None else [scope]

    for s in scopes:
        lock = readLock(s, cwd)
        for skill_name, entry in lock.skills.items():
            canonical = getCanonicalDir(skill_name, s, cwd)
            skill_md = canonical / "SKILL.md"

            if not skill_md.exists():
                continue

            try:
                meta = parseFrontmatter(skill_md)
            except AgentskillError:
                continue

            results.append(
                SkillInfo(
                    name=skill_name,
                    meta=meta,
                    lock=entry,
                    path=str(canonical),
                    scope=s,
                )
            )

    return results


def getSkill(
    name: str,
    *,
    scope: Scope = Scope.GLOBAL,
    cwd: Path | None = None,
) -> SkillInfo | None:
    """Get full skill details."""
    entry = getFromLock(name, scope, cwd)
    canonical = getCanonicalDir(name, scope, cwd)
    skill_md = canonical / "SKILL.md"

    if not skill_md.exists():
        return None

    try:
        meta = parseFrontmatter(skill_md)
    except AgentskillError:
        return None

    return SkillInfo(
        name=name,
        meta=meta,
        lock=entry,
        path=str(canonical),
        scope=scope,
    )


def _computeHash(parsed: ParsedSource, canonical: Path) -> str | None:
    """Compute hash depending on source type."""
    if parsed.source_type == SourceType.GITHUB:
        return fetchGithubTreeSha(
            parsed.owner or "",
            parsed.repo or "",
            parsed.subpath,
        )
    return computeDirHash(canonical)


def _buildSourceId(parsed: ParsedSource) -> str:
    """Build a lock-file source identifier."""
    if parsed.source_type == SourceType.GITHUB and parsed.owner and parsed.repo:
        return f"{parsed.owner}/{parsed.repo}"
    if parsed.source_type == SourceType.LOCAL and parsed.local_path:
        return parsed.local_path
    return parsed.url


def _buildSkillPath(parsed: ParsedSource, name: str) -> str:
    """Build skillPath for lock entry."""
    if parsed.subpath:
        return f"{parsed.subpath}/SKILL.md"
    return f"{name}/SKILL.md"


def _cleanupTempdir(skill_dir: Path) -> None:
    """Find and remove the agentskill- tempdir root."""
    parts = skill_dir.parts
    for i, part in enumerate(parts):
        if part.startswith("agentskill-"):
            root = Path(*parts[: i + 1]) if i > 0 else Path(parts[0])
            shutil.rmtree(root, ignore_errors=True)
            return
