"""agentskill - Agent skill manager for the Agent Skills standard."""

__version__ = "0.1.0"
__author__ = "Nik Cubrilovic"

from .errors import AgentskillError, ErrorCode
from .models import AgentDef, LockEntry, LockFile, Scope, SkillInfo, SkillMeta, SourceType
from .skills import getSkill, installSkill, listSkills, removeSkill, updateSkill

__all__ = [
    "AgentDef",
    "AgentskillError",
    "ErrorCode",
    "LockEntry",
    "LockFile",
    "Scope",
    "SkillInfo",
    "SkillMeta",
    "SourceType",
    "getSkill",
    "installSkill",
    "listSkills",
    "removeSkill",
    "updateSkill",
]
