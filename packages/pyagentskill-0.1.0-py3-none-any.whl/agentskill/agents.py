"""Agent registry, detection, and symlink management."""

from __future__ import annotations

import os
from pathlib import Path

from .models import AgentDef, Scope

# Agent definitions — concrete config entries referenced by id
AGENTS: dict[str, AgentDef] = {
    "claude": AgentDef(
        id="claude",
        name="Claude Code",
        skills_dir=".claude/skills",
        global_skills_dir="~/.claude/skills",
        detect_path="~/.claude",
        reads_universal=False,
    ),
    "cursor": AgentDef(
        id="cursor",
        name="Cursor",
        skills_dir=".cursor/skills",
        global_skills_dir="~/.cursor/skills",
        detect_path="~/.cursor",
        reads_universal=False,
    ),
    "codex": AgentDef(
        id="codex",
        name="Codex",
        skills_dir=".codex/skills",
        global_skills_dir="~/.codex/skills",
        detect_path="~/.codex",
        reads_universal=False,
    ),
    "windsurf": AgentDef(
        id="windsurf",
        name="Windsurf",
        skills_dir=".codeium/windsurf/skills",
        global_skills_dir="~/.codeium/windsurf/skills",
        detect_path="~/.codeium",
        reads_universal=False,
    ),
    "kiro": AgentDef(
        id="kiro",
        name="Kiro",
        skills_dir=".kiro/skills",
        global_skills_dir="~/.kiro/skills",
        detect_path="~/.kiro",
        reads_universal=False,
    ),
    "copilot": AgentDef(
        id="copilot",
        name="GitHub Copilot",
        skills_dir=".github/skills",
        global_skills_dir="~/.github/skills",
        detect_path="~/.github",
        reads_universal=False,
    ),
    "cline": AgentDef(
        id="cline",
        name="Cline",
        skills_dir=".cline/skills",
        global_skills_dir="~/.cline/skills",
        detect_path="~/.cline",
        reads_universal=False,
    ),
    "opencode": AgentDef(
        id="opencode",
        name="OpenCode",
        skills_dir=".config/opencode/skills",
        global_skills_dir="~/.config/opencode/skills",
        detect_path="~/.config/opencode",
        reads_universal=True,
    ),
    "gemini": AgentDef(
        id="gemini",
        name="Gemini CLI",
        skills_dir=".gemini/skills",
        global_skills_dir="~/.gemini/skills",
        detect_path="~/.gemini",
        reads_universal=True,
    ),
    "amp": AgentDef(
        id="amp",
        name="Amp",
        skills_dir=".amp/skills",
        global_skills_dir="~/.amp/skills",
        detect_path="~/.amp",
        reads_universal=True,
    ),
}


def getAgent(agent_id: str) -> AgentDef | None:
    """Get agent definition by id."""
    return AGENTS.get(agent_id)


def listAgents() -> list[AgentDef]:
    """List all known agents."""
    return list(AGENTS.values())


def detectInstalledAgents() -> list[str]:
    """Detect which agents are installed by checking for their config dirs."""
    installed: list[str] = []
    for agent_id, agent in AGENTS.items():
        detect = Path(os.path.expanduser(agent.detect_path))
        if detect.exists():
            installed.append(agent_id)
    return installed


def getCanonicalDir(name: str, scope: Scope, cwd: Path | None = None) -> Path:
    """Get canonical skill install path: ~/.agents/skills/<name>/ or .agents/skills/<name>/"""
    if scope == Scope.GLOBAL:
        return Path.home() / ".agents" / "skills" / name
    return (cwd or Path.cwd()) / ".agents" / "skills" / name


def getAgentSkillDir(agent_id: str, name: str, scope: Scope, cwd: Path | None = None) -> Path:
    """Get the skill path within a specific agent's skills directory."""
    agent = AGENTS[agent_id]
    if scope == Scope.GLOBAL:
        base = Path(os.path.expanduser(agent.global_skills_dir))
    else:
        base = (cwd or Path.cwd()) / agent.skills_dir
    return base / name


def createSymlinks(
    name: str,
    agents: list[str],
    scope: Scope,
    cwd: Path | None = None,
) -> list[tuple[str, bool]]:
    """Create symlinks from each agent's skills dir to canonical dir.

    Returns list of (agent_id, success) tuples.
    Skips agents that read from ~/.agents/skills/ natively.
    """
    canonical = getCanonicalDir(name, scope, cwd)
    results: list[tuple[str, bool]] = []

    for agent_id in agents:
        agent = AGENTS.get(agent_id)
        if not agent:
            results.append((agent_id, False))
            continue

        # skip agents that natively read from ~/.agents/skills/
        if agent.reads_universal:
            results.append((agent_id, True))
            continue

        link_path = getAgentSkillDir(agent_id, name, scope, cwd)

        try:
            link_path.parent.mkdir(parents=True, exist_ok=True)

            # remove existing symlink or dir
            if link_path.is_symlink():
                link_path.unlink()
            elif link_path.exists():
                # already a real directory — skip
                results.append((agent_id, True))
                continue

            # create relative symlink
            rel = os.path.relpath(canonical, link_path.parent)
            link_path.symlink_to(rel)
            results.append((agent_id, True))
        except OSError:
            results.append((agent_id, False))

    return results


def removeSymlinks(
    name: str,
    scope: Scope,
    cwd: Path | None = None,
) -> list[str]:
    """Remove all symlinks for a skill across all agent dirs. Returns removed paths."""
    canonical = getCanonicalDir(name, scope, cwd)
    removed: list[str] = []

    for agent_id, agent in AGENTS.items():
        if agent.reads_universal:
            continue

        link_path = getAgentSkillDir(agent_id, name, scope, cwd)
        if link_path.is_symlink():
            try:
                target = link_path.resolve()
                if target == canonical.resolve() or not target.exists():
                    link_path.unlink()
                    removed.append(str(link_path))
            except OSError:
                pass

    return removed
