import logging
import re
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, TypeVar, Union

if TYPE_CHECKING:
    from neutronapi.base import API


T = TypeVar('T')

from neutronapi.base import API, Response
from neutronapi.api import exceptions
from neutronapi.event_bus import events
from neutronapi.middleware.cors import CorsMiddleware
from neutronapi.middleware.routing import RoutingMiddleware
from neutronapi.middleware.allowed_hosts import AllowedHostsMiddleware, is_host_allowed
from neutronapi.middleware.request_logging import RequestLoggingMiddleware

logger = logging.getLogger(__name__)


class Application:
    """ASGI application that composes APIs + middleware + optional background tasks.

    Example:
        from neutronapi.application import Application
        from neutronapi.base import API

        class HelloAPI(API):
            resource = "/v1/hello"

            @API.endpoint("/", methods=["GET"])
            async def get(self, scope, receive, send, **kwargs):
                return await self.response({"message": "Hello World"})

        class UsersAPI(API):
            resource = "/v1/users"

            @API.endpoint("/", methods=["GET"])
            async def list_users(self, scope, receive, send, **kwargs):
                return await self.response({"users": []})

        # Clean array-based syntax - no redundancy.
        from neutronapi.middleware.compression import CompressionMiddleware
        from neutronapi.middleware.allowed_hosts import AllowedHostsMiddleware

        app = Application(
            apis=[
                HelloAPI(),
                UsersAPI(),
            ],
            middlewares=[
                AllowedHostsMiddleware(allowed_hosts=["example.com", "*.example.com"]),
                CompressionMiddleware(minimum_size=512),
            ],
            registry={
                "services:event_bus": EventBus(),
                "services:email": EmailService(),
            },
        )
    """

    def __init__(
        self,
        apis: Optional[Union[Dict[str, API], List[API]]] = None,
        *,
        middlewares: Optional[List[Any]] = None,
        registry: Optional[Dict[str, Any]] = None,
        tasks: Optional[Dict[str, Any]] = None,
        version: str = "1.0.0",
        allowed_hosts: Optional[List[str]] = None,
        static_hosts: Optional[List[str]] = None,
        static_resolver: Optional[Callable] = None,
        cors_allow_all: bool = False,
    ) -> None:
        """
        Create a new ASGI application with dependency injection support.

        Args:
            apis: List or dict of API instances. Each API must have a 'resource' attribute
                  that defines its base path (e.g., "/v1/users"). APIs are registered
                  in the order they appear in the list.
            middlewares: List of middleware instances to apply to requests
            registry: Dict of items for universal dependency injection. Keys must
                     follow 'namespace:name' format (e.g., 'utils:logger', 'services:email')
            tasks: Optional background tasks configuration
            version: Application version string
            allowed_hosts: List of allowed host names for security
            static_hosts: Static file hosting configuration
            static_resolver: Custom static file resolver
            cors_allow_all: Whether to allow all CORS origins (default: False).
                           Explicit allowlist CORS should be configured by passing
                           a CorsMiddleware instance in middlewares.

        Example:
            >>> app = Application(
            ...     apis=[
            ...         UsersAPI(),      # resource = "/v1/users"
            ...         ProductsAPI(),   # resource = "/v1/products"
            ...     ],
            ...     registry={
            ...         'utils:logger': Logger(),
            ...         'utils:cache': RedisCache(),
            ...         'services:email': EmailService(),
            ...     },
            ... )
            >>> 
            >>> # In your API methods:
            >>> logger = self.registry.get('utils:logger')
            >>> email = self.registry.get('services:email')
        """
        # Convert provided APIs into name-based lookups and an ordered routing list
        from neutronapi.base import API
        self.apis: Dict[str, 'API'] = {}  # name -> api (for reverse lookups)
        self._routing_apis: List['API'] = []  # APIs in registration order (for routing)
        
        if apis:
            if isinstance(apis, dict):
                # Use the provided names from the dict
                for name, api in apis.items():
                    resource = api.resource
                    if resource is None:
                        raise ValueError(f"API {api.__class__.__name__} must define a non-null 'resource'")
                    self.apis[name] = api
                    self._routing_apis.append(api)
            else:
                # For list[API], use the API name as the key for reverse lookups
                for api in apis:
                    resource = api.resource
                    if resource is None:
                        raise ValueError(f"API {api.__class__.__name__} must define a non-null 'resource'")
                    
                    # Require explicit 'name' attribute for reverse lookups
                    if not api.name:
                        raise ValueError(f"API {api.__class__.__name__} must have a 'name' attribute for reverse lookups")
                    
                    self.apis[api.name] = api
                    self._routing_apis.append(api)
        
        # Validate no duplicate route names across all APIs
        self._validate_unique_route_names()

        self.version = version
        self.events = events

        # Initialize registry for universal dependency injection
        self.registry: Dict[str, Any] = {}
        
        # Handle registry parameter - validate namespace:name format
        if registry:
            for key, value in registry.items():
                self._validate_registry_key(key)
                if key in self.registry:
                    raise ValueError(f"Duplicate registry key: '{key}'")
                self.registry[key] = value
        
        # Assign registry to APIs
        for api in self.apis.values():
            setattr(api, 'registry', self.registry)

        def select_api(path: str, host: str) -> Optional["API"]:
            host_surface_apis = [
                api
                for api in self._routing_apis
                if api.hosts and host and is_host_allowed(host, api.hosts)
            ]
            base_candidates = (
                host_surface_apis
                if host_surface_apis
                else [api for api in self._routing_apis if not api.hosts]
            )
            candidate_apis = [
                api
                for api in base_candidates
                if not self._is_path_excluded(api, path)
            ]

            for api in candidate_apis:
                if self._path_equals_resource(path, api.resource):
                    return api

            for api in candidate_apis:
                if self._path_matches_resource(path, api.resource):
                    return api

            return None

        # Simple handler that routes to APIs
        async def app(scope, receive, send):
            if scope["type"] == "http":
                path = scope.get("path", "/")
                host = self._extract_host(scope)
                api = select_api(path, host)
                if api is not None:
                    await api.handle(scope, receive, send)
                    return

                # Default 404 for unmatched paths - return consistent JSON error
                err = exceptions.NotFound().to_dict()
                resp = Response(body=err, status_code=404)
                await resp(scope, receive, send)

            elif scope["type"] == "websocket":
                path = scope.get("path", "/")
                host = self._extract_host(scope)
                logger.debug("Routing websocket for path=%s", path)
                api = select_api(path, host)
                if api is not None:
                    logger.debug("Matched websocket API=%s", api.name)
                    await api.handle(scope, receive, send)
                    return

                # No matching API for websocket - close connection
                logger.debug("No websocket API match for path=%s", path)
                await send({"type": "websocket.close", "code": 4004})

        # Set lifecycle hooks on app function so RoutingMiddleware can find them
        app.on_startup = []
        app.on_shutdown = []

        # Build base router app
        base_router = RoutingMiddleware(
            default_app=app,
            static_hosts=static_hosts,
            static_resolver=static_resolver,
        )

        # Compose middleware stack. AllowedHosts is always enforced when configured.
        # cors_allow_all wraps the final user/application stack with a single
        # allow-all CorsMiddleware; explicit allowlist CORS remains middleware-driven.
        composed = base_router

        if middlewares:
            if cors_allow_all and any(isinstance(mw, CorsMiddleware) for mw in middlewares):
                raise ValueError(
                    "Ambiguous CORS configuration: cors_allow_all=True cannot be used "
                    "together with a user-supplied CorsMiddleware."
                )
            # User-provided middlewares are declared outermost-first; apply in reverse to wrap
            for mw in reversed(middlewares):
                mw.app = composed
                mw.registry = self.registry
                composed = mw

        if cors_allow_all:
            composed = CorsMiddleware(composed, allow_all_origins=True)

        # Always apply AllowedHosts when configured — wraps outside user middleware
        # and outside CORS so host validation cannot be accidentally bypassed
        if allowed_hosts:
            composed = AllowedHostsMiddleware(composed, allowed_hosts=allowed_hosts)

        self.app = RequestLoggingMiddleware(composed)

        # Expose lifecycle hooks on Application instance for compatibility
        # (handlers are already set on the app function above)
        self.on_startup = app.on_startup
        self.on_shutdown = app.on_shutdown

        # Handle tasks dict - clean API-like pattern
        if tasks:
            from neutronapi.background import Background
            self.background = Background()

            # Register all tasks
            for name, task in tasks.items():
                self.background.register_task(task)

            async def _start_background():
                await self.background.start()

            async def _stop_background():
                await self.background.stop()

            app.on_startup.append(_start_background)
            app.on_shutdown.append(_stop_background)

    @staticmethod
    def _extract_host(scope: Dict[str, Any]) -> str:
        headers = dict(scope.get("headers", []))
        return headers.get(b"host", b"").decode("utf-8", "ignore")

    @staticmethod
    def _path_matches_prefix(path: str, prefix: str) -> bool:
        if not prefix:
            return False

        if prefix == "/":
            return path.startswith("/")

        if prefix.endswith("/"):
            return path.startswith(prefix)

        normalized = prefix.rstrip("/")
        return path == normalized or path.startswith(f"{normalized}/")

    @classmethod
    def _is_path_excluded(cls, api: "API", path: str) -> bool:
        return any(
            cls._path_matches_prefix(path, prefix)
            for prefix in (api.excluded_path_prefixes or [])
        )

    @staticmethod
    def _path_equals_resource(path: str, resource: str) -> bool:
        normalized = (resource or "").rstrip("/")
        if not normalized:
            return path in ("", "/")
        return path == normalized

    @staticmethod
    def _path_matches_resource(path: str, resource: str) -> bool:
        normalized = (resource or "").rstrip("/")
        if not normalized:
            return True
        return path == normalized or path.startswith(f"{normalized}/")

    def _validate_registry_key(self, key: str) -> None:
        """Validate registry key follows namespace:name format.
        
        Args:
            key: Registry key to validate
            
        Raises:
            ValueError: If key format is invalid
            
        Example:
            Valid: 'services:email', 'utils:logger', 'modules:auth'
            Invalid: 'email', 'services:', ':logger', 'utils:my-logger'
        """
        if not isinstance(key, str):
            raise ValueError(f"Registry key must be string, got {type(key).__name__}")
        
        if ':' not in key:
            raise ValueError(
                f"Registry key '{key}' must follow 'namespace:name' format. "
                f"Example: 'services:email', 'utils:logger'"
            )
        
        namespace, name = key.split(':', 1)
        if not namespace or not name:
            raise ValueError(
                f"Registry key '{key}' must have both namespace and name. "
                f"Got namespace='{namespace}', name='{name}'"
            )
        
        # Validate format - alphanumeric + underscore only
        if not re.match(r'^[a-zA-Z0-9_]+:[a-zA-Z0-9_]+$', key):
            raise ValueError(
                f"Registry key '{key}' contains invalid characters. "
                f"Use only letters, numbers, underscores. Example: 'utils:my_logger'"
            )
    
    def register(self, key: str, item: Any) -> None:
        """Register an item in the registry for dependency injection.
        
        Args:
            key: Registry key in 'namespace:name' format (e.g., 'utils:logger')
            item: The item to register. Can be any object.
            
        Raises:
            ValueError: If key format is invalid or key already exists
            
        Example:
            >>> app = Application()
            >>> logger = Logger()
            >>> app.register('utils:logger', logger)
            >>> # Later in your API:
            >>> logger = self.registry.get('utils:logger')
        """
        self._validate_registry_key(key)
        
        if key in self.registry:
            raise ValueError(
                f"Registry key '{key}' already exists. "
                f"Use a different key or remove the existing registration first."
            )
        
        self.registry[key] = item
        
        # Re-inject registry into existing APIs
        for api in self.apis.values():
            setattr(api, 'registry', self.registry)
    
    def get_registry_item(self, key: str, default: Optional[T] = None) -> Optional[T]:
        """Get an item from the registry with type preservation.
        
        Args:
            key: Registry key in 'namespace:name' format
            default: Default value if key not found
            
        Returns:
            The registered item or default value
            
        Example:
            >>> logger = app.get_registry_item('utils:logger')
            >>> cache = app.get_registry_item('utils:cache', default=DummyCache())
        """
        return self.registry.get(key, default)
    
    def has_registry_item(self, key: str) -> bool:
        """Check if an item exists in the registry.
        
        Args:
            key: Registry key to check
            
        Returns:
            True if key exists in registry, False otherwise
        """
        return key in self.registry
    
    def list_registry_keys(self, namespace: Optional[str] = None) -> List[str]:
        """List all registry keys, optionally filtered by namespace.
        
        Args:
            namespace: Optional namespace to filter by (e.g., 'utils', 'services')
            
        Returns:
            List of registry keys
            
        Example:
            >>> app.list_registry_keys()  # ['services:email', 'utils:logger']
            >>> app.list_registry_keys('utils')  # ['utils:logger']
        """
        if namespace is None:
            return list(self.registry.keys())
        
        prefix = f"{namespace}:"
        return [key for key in self.registry.keys() if key.startswith(prefix)]

    def _validate_unique_route_names(self) -> None:
        """Validate that there are no duplicate route names across all APIs.
        
        Route names are in the format "api_name:endpoint_name".
        
        Raises:
            ValueError: If duplicate route names are found
        """
        seen_routes = {}  # route_name -> api_name
        
        for api_name, api in self.apis.items():
            # Get all route names from this API
            for route_tuple in api.routes:
                # Route tuple structure: (pattern, handler, methods, permissions, throttles, route_name, original_path, ...)
                if len(route_tuple) >= 6:
                    route_name = route_tuple[5]  # route_name is at index 5
                    if route_name:  # Only check named routes
                        full_route_name = f"{api_name}:{route_name}"
                        
                        if full_route_name in seen_routes:
                            raise ValueError(
                                f"Duplicate route name '{full_route_name}' found. "
                                f"Route names must be unique across all APIs. "
                                f"Previously defined in API '{seen_routes[full_route_name]}', "
                                f"now found again in API '{api_name}'."
                            )
                        
                        seen_routes[full_route_name] = api_name

    def reverse(self, name: str, **kwargs) -> str:
        """Reverse URL lookup for a named route across all registered APIs.
        
        Args:
            name: Route name in format "api_name:endpoint_name"
            **kwargs: Parameters to substitute in the URL
            
        Returns:
            The reversed URL string
            
        Raises:
            ValueError: If API not found or invalid name format
            
        Example:
            >>> app = Application(apis={"users": users_api})
            >>> url = app.reverse("users:detail", user_id=123)
            >>> # Returns: "/users/123"
        """
        if ":" not in name:
            raise ValueError(
                f"Route name '{name}' must be in format 'api_name:endpoint_name'. "
                f"Example: 'users:detail'"
            )
        
        api_name, endpoint_name = name.split(":", 1)
        if api_name not in self.apis:
            raise ValueError(f"API '{api_name}' not found.")
        
        return self.apis[api_name].reverse(endpoint_name, **kwargs)

    async def __call__(self, scope, receive, send, **kwargs):
        return await self.app(scope, receive, send, **kwargs)
