"""Settings configuration for NeutronAPI."""
from __future__ import annotations

import importlib
import logging
import os
import sys
from typing import Any, Optional

from neutronapi.exceptions import ImproperlyConfigured


DEFAULT_SETTINGS_MODULE = "apps.settings"
logger = logging.getLogger(__name__)


def is_neutronapi_development(cwd: Optional[str] = None) -> bool:
    """Check if we're in the NeutronAPI source repository."""
    cwd = cwd or os.getcwd()
    neutronapi_pkg = os.path.join(cwd, "neutronapi")
    pyproject_toml = os.path.join(cwd, "pyproject.toml")
    setup_py = os.path.join(cwd, "setup.py")
    neutronapi_tests = os.path.join(cwd, "neutronapi", "tests")
    return (
        os.path.isdir(neutronapi_pkg)
        and (os.path.isfile(setup_py) or os.path.isfile(pyproject_toml))
        and os.path.isdir(neutronapi_tests)
    )


def _settings_module_name() -> str:
    return os.environ.get("NEUTRONAPI_SETTINGS_MODULE", DEFAULT_SETTINGS_MODULE)


def _clear_module_cache(module_name: str) -> None:
    importlib.invalidate_caches()
    parents = []
    parts = module_name.split(".")
    while parts:
        parents.append(".".join(parts))
        parts.pop()

    for name in parents:
        sys.modules.pop(name, None)


class Settings:
    """
    Settings object that loads configuration from a settings module.
    Provides a centralized configuration management system.
    """

    # Required settings that must be defined
    REQUIRED_SETTINGS = ['ENTRY']

    def __init__(self):
        self._settings_module = None
        self._settings = None
        self._setup()

    def _setup(self):
        """Setup settings by loading the specified settings module."""
        settings_module = os.environ.get(
            "NEUTRONAPI_SETTINGS_MODULE",
            DEFAULT_SETTINGS_MODULE,
        )

        try:
            cwd = os.getcwd()
            if cwd not in sys.path:
                sys.path.insert(0, cwd)

            _clear_module_cache(settings_module)
            self._settings_module = importlib.import_module(settings_module)
            self._settings = {
                name: getattr(self._settings_module, name)
                for name in dir(self._settings_module)
                if not name.startswith("_")
            }
        except ImportError as e:
            if settings_module == DEFAULT_SETTINGS_MODULE and is_neutronapi_development():
                logger.info(
                    "No settings module found. Using default test configuration for the NeutronAPI source tree."
                )
                self._use_default_test_settings()
            else:
                raise ImportError(
                    f"Could not import settings module '{settings_module}'. "
                    f"Make sure it exists and is importable. "
                    f"You can also set NEUTRONAPI_SETTINGS_MODULE environment variable. "
                    f"Error: {e}"
                )
        self._validate_required_settings()

    def _use_default_test_settings(self):
        """Use default test settings for NeutronAPI core library testing."""
        requested = os.getenv("NEUTRONAPI_TEST_DATABASE", "sqlite").lower().strip()
        engine = "aiosqlite"
        db_config = {
            "ENGINE": "aiosqlite",
            "NAME": ":memory:",
        }

        if requested in {"postgres", "postgresql", "asyncpg"}:
            engine = "asyncpg"
            db_config = {
                "ENGINE": "asyncpg",
                "HOST": os.getenv("PGHOST", "127.0.0.1"),
                "PORT": int(os.getenv("PGPORT", "5432")),
                "NAME": os.getenv("PGDATABASE", "neutronapi_test"),
                "USER": os.getenv("PGUSER", "postgres"),
                "PASSWORD": os.getenv("PGPASSWORD", "postgres"),
            }

        self._settings = {
            "ENTRY": "neutronapi.tests.entry:app",
            "DATABASES": {"default": db_config},
        }
        logger.info("Using default test configuration with %s", engine)

    def _validate_required_settings(self):
        """Validate that all required settings are present."""
        missing_settings = []

        for setting_name in self.REQUIRED_SETTINGS:
            if setting_name not in self._settings:
                missing_settings.append(setting_name)

        if missing_settings:
            raise ImproperlyConfigured(
                f"Missing required settings: {', '.join(missing_settings)}. "
                f"Please add them to your settings module."
            )

        # Validate DATABASES structure if present
        if 'DATABASES' in self._settings:
            databases = self._settings['DATABASES']
            if not isinstance(databases, dict):
                raise ImproperlyConfigured("DATABASES setting must be a dictionary.")

            if 'default' not in databases:
                raise ImproperlyConfigured("DATABASES must contain a 'default' database configuration.")

            default_db = databases['default']
            if not isinstance(default_db, dict):
                raise ImproperlyConfigured("Database configuration must be a dictionary.")

            required_db_keys = ['ENGINE', 'NAME']
            missing_db_keys = [key for key in required_db_keys if key not in default_db]
            if missing_db_keys:
                raise ImproperlyConfigured(
                    f"Default database configuration missing required keys: {', '.join(missing_db_keys)}"
                )

    def __getattr__(self, name: str) -> Any:
        if self._settings is None:
            self._setup()
        if name in self._settings:
            return self._settings[name]
        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")

    def get(self, name: str, default: Any = None) -> Any:
        try:
            return getattr(self, name)
        except AttributeError:
            return default


class LazySettings:
    """Lazily load project settings and reload when the cwd changes."""

    def __init__(self) -> None:
        self._wrapped: Optional[Settings] = None
        self._signature: Optional[tuple[str, str]] = None

    def _current_signature(self) -> tuple[str, str]:
        try:
            cwd = os.getcwd()
        except FileNotFoundError:
            # The process's cwd was removed out from under us. This happens
            # on deploy: systemd starts the service with
            # WorkingDirectory=/opt/<app>/current (a symlink), chdir resolves
            # to the real release dir, and a subsequent deploy that rewrites
            # that release path (e.g. `rm -rf <release> && mkdir <release>
            # && tar -xzf`) leaves the still-running worker pointing at a
            # deleted inode until systemd swaps it out. Every request after
            # that used to 500 because settings re-resolved on each call.
            # Fall back to the last known signature; settings don't depend
            # on cwd being valid at request time.
            if self._signature is not None:
                return self._signature
            cwd = "<cwd-unavailable>"
        return (cwd, _settings_module_name())

    def _setup(self, *, force: bool = False) -> Settings:
        signature = self._current_signature()
        if force or self._wrapped is None or self._signature != signature:
            self._wrapped = Settings()
            self._signature = signature
        return self._wrapped

    def reset(self) -> None:
        self._wrapped = None
        self._signature = None

    @property
    def configured(self) -> bool:
        return self._wrapped is not None

    def __getattr__(self, name: str) -> Any:
        return getattr(self._setup(), name)

    def get(self, name: str, default: Any = None) -> Any:
        try:
            return getattr(self._setup(), name)
        except AttributeError:
            return default


def get_app_from_entry(entry_point: Optional[str] = None):
    """
    Load the ASGI application from the entry point.

    Args:
        entry_point: Entry point in format "module:variable"
                    (e.g., "apps.entry:app"). If None, uses settings.ENTRY
    """
    if entry_point is None:
        settings = Settings()
        entry_point = getattr(settings, "ENTRY", "apps.entry:app")

    if ":" not in entry_point:
        raise ValueError(
            f"Invalid entry point format '{entry_point}'. "
            f"Expected format: 'module:variable' (e.g., 'apps.entry:app')"
        )

    module_path, app_name = entry_point.split(":", 1)

    try:
        cwd = os.getcwd()
        if cwd not in sys.path:
            sys.path.insert(0, cwd)

        _clear_module_cache(module_path)
        module = importlib.import_module(module_path)
        app = getattr(module, app_name)
        return app
    except ImportError as e:
        raise ImportError(
            f"Could not import module '{module_path}' from entry point '{entry_point}'. "
            f"Make sure the module exists and is importable. Error: {e}"
        )
    except AttributeError as e:
        raise AttributeError(
            f"Module '{module_path}' has no attribute '{app_name}'. "
            f"Make sure '{app_name}' is defined in {module_path}. Error: {e}"
        )

settings = LazySettings()
