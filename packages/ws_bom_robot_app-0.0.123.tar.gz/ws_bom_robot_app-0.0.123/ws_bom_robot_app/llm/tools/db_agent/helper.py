import re
import sqlite3
from sqlalchemy import create_engine, inspect, text
from ws_bom_robot_app.llm.models.api import LlmAppTool
from ws_bom_robot_app.llm.providers.llm_manager import LlmInterface


async def query_database(query: str, app_tool: LlmAppTool, llm: LlmInterface):
    """
    Direct LLM → SQL approach:
    1. Reads DB schema dynamically
    2. One LLM call to generate SQL + metadata (structured output)
    3. Executes SQL directly
    4. Post-processes: aggregations without LIMIT, lists with pagination
    """
    import json
    import logging

    from langchain_core.prompts import ChatPromptTemplate
    from sqlalchemy import create_engine, text

    db_uri = app_tool.db_settings.connection_string
    additional_prompt = app_tool.db_settings.additionalPrompt or ""
    limit = app_tool.db_settings.limit or 20
    if not db_uri:
        raise ValueError("Database URI not found in tool secrets")

    db_uri = await download_sqlite_file(db_uri)

    # 1. Read schema
    schema = get_db_schema(db_uri)

    # 2. Generate SQL via structured output
    sql_gen_prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                """You are a SQL expert. Given a database schema and a user question, generate the appropriate SQL query.

  DATABASE SCHEMA:
  {schema}

  RULES:
  - Generate ONLY valid SQL for the database dialect used.
  - For aggregation queries (SUM, COUNT, AVG, MIN, MAX, GROUP BY), NEVER add a LIMIT clause.
  - For list queries, add LIMIT {limit} unless the user explicitly says they want ALL results.
  - If the user asks for "all" results, first wrap your query to count total rows, and if > {limit}, use LIMIT {limit} and note the total count.
  - Use LIKE with % for text searches (case-insensitive).
  - When filtering, match values exactly as they appear in the FILTERABLE VALUES section.
  - Always use column names exactly as they appear in the schema.
  - For columns containing comma-separated values (like localizzazione_province), use LIKE '%value%' for filtering.
  {additional_prompt}

  RESPOND ONLY WITH A VALID JSON OBJECT (no markdown, no backticks) in this exact format:
  {{
    "sql": "SELECT ...",
    "count_sql": "SELECT COUNT(*) FROM ... (same WHERE clause, omit if aggregation)",
    "is_aggregation": true/false,
    "result_type": "single_value" | "list" | "aggregation",
    "explanation": "Brief explanation of what the query does"
  }}""",
            ),
            ("human", "{question}"),
        ]
    )

    llm = llm.get_llm()

    chain = sql_gen_prompt | llm
    response = await chain.ainvoke(
        {
            "schema": schema,
            "limit": limit,
            "additional_prompt": f"\nADDITIONAL CONTEXT:\n{additional_prompt}"
            if additional_prompt
            else "",
            "question": query,
        },
        config={"callbacks": []},
    )

    # Parse LLM response
    response_text = response.content if hasattr(response, "content") else str(response)
    # Clean markdown fences if present
    response_text = re.sub(r"^```(?:json)?\s*\n?", "", response_text.strip())
    response_text = re.sub(r"\n?```\s*$", "", response_text)

    try:
        sql_result = json.loads(response_text)
    except json.JSONDecodeError as e:
        logging.error(f"[DB Tool] Failed to parse LLM SQL response: {response_text}")
        raise ValueError(f"Failed to generate SQL query: {str(e)}")

    sql_query = sql_result.get("sql", "")
    count_sql = sql_result.get("count_sql", "")
    is_aggregation = sql_result.get("is_aggregation", False)
    result_type = sql_result.get("result_type", "list")
    explanation = sql_result.get("explanation", "")

    if not sql_query:
        raise ValueError("LLM did not generate a SQL query")

    # 3. Execute SQL directly
    engine = create_engine(db_uri)
    max_retries = 1
    last_error = None

    for attempt in range(max_retries + 1):
        try:
            with engine.connect() as conn:
                result = conn.execute(text(sql_query))
                columns = list(result.keys())
                rows = result.fetchall()

                # Get total count for list queries
                total_count = len(rows)
                if count_sql and not is_aggregation:
                    try:
                        total_count = conn.execute(text(count_sql)).scalar() or len(
                            rows
                        )
                    except Exception:
                        total_count = len(rows)

            break  # success
        except Exception as e:
            last_error = str(e)
            logging.warning(
                f"[DB Tool] SQL execution failed (attempt {attempt + 1}): {last_error}"
            )
            if attempt < max_retries:
                # Retry: ask LLM to fix the SQL
                retry_prompt = ChatPromptTemplate.from_messages(
                    [
                        (
                            "system",
                            """The following SQL query failed with an error. Fix the query.

DATABASE SCHEMA:
{schema}

FAILED SQL: {failed_sql}
ERROR: {error}

RESPOND ONLY WITH A VALID JSON OBJECT (no markdown, no backticks) in this exact format:
{{
  "sql": "SELECT ...",
  "count_sql": "SELECT COUNT(*) FROM ... (same WHERE, omit if aggregation)",
  "is_aggregation": true/false,
  "result_type": "single_value" | "list" | "aggregation",
  "explanation": "Brief explanation"
}}""",
                        ),
                        ("human", "{question}"),
                    ]
                )
                retry_response = await (retry_prompt | llm).ainvoke(
                    {
                        "schema": schema,
                        "failed_sql": sql_query,
                        "error": last_error,
                        "question": query,
                    },
                    config={"callbacks": []},
                )
                retry_text = (
                    retry_response.content
                    if hasattr(retry_response, "content")
                    else str(retry_response)
                )
                retry_text = re.sub(r"^```(?:json)?\s*\n?", "", retry_text.strip())
                retry_text = re.sub(r"\n?```\s*$", "", retry_text)
                try:
                    retry_result = json.loads(retry_text)
                    sql_query = retry_result.get("sql", sql_query)
                    count_sql = retry_result.get("count_sql", "")
                    is_aggregation = retry_result.get("is_aggregation", is_aggregation)
                    result_type = retry_result.get("result_type", result_type)
                except json.JSONDecodeError:
                    pass
            else:
                engine.dispose()
                raise ValueError(
                    f"SQL query failed after {max_retries + 1} attempts: {last_error}"
                )

    engine.dispose()

    # 4. Post-processing
    if result_type == "single_value" or result_type == "aggregation" or is_aggregation:
        # Single value or aggregation — return directly
        if len(rows) == 1 and len(columns) == 1:
            return f"{explanation}\n\nRisultato: {rows[0][0]}"
        elif len(rows) == 1:
            row_data = {col: val for col, val in zip(columns, rows[0])}
            formatted = "\n".join([f"- **{k}**: {v}" for k, v in row_data.items()])
            return f"{explanation}\n\n{formatted}"
        else:
            # Multiple aggregation rows (e.g. GROUP BY)
            lines = []
            for row in rows:
                row_items = [f"{col}: {val}" for col, val in zip(columns, row)]
                lines.append(" | ".join(row_items))
            return f"{explanation}\n\n" + "\n".join(lines)
    else:
        # List results
        if len(rows) == 0:
            return f"{explanation}\n\nNessun risultato trovato."

        # Format rows
        result_lines = []
        for row in rows:
            # Filter out None/empty values for cleaner output
            row_items = []
            for col, val in zip(columns, row):
                if val is not None and str(val).strip() != "":
                    row_items.append(f"**{col}**: {val}")
            result_lines.append(" | ".join(row_items))

        output = f"{explanation}\n\n"
        if total_count > len(rows):
            output += f"📊 Trovati **{total_count}** risultati totali. Mostro i primi **{len(rows)}**:\n\n"
        else:
            output += f"📊 Trovati **{len(rows)}** risultati:\n\n"

        output += "\n\n".join(result_lines)
        return output


def get_db_schema(db_uri: str) -> str:
    """
    Reads the database schema dynamically.
    Returns a formatted string with table names, columns, types, and
    distinct values for low-cardinality columns.
    """

    engine = create_engine(db_uri)
    inspector = inspect(engine)
    schema_parts = []

    for table_name in inspector.get_table_names():
        columns = inspector.get_columns(table_name)
        col_lines = []
        for col in columns:
            col_lines.append(f"  - {col['name']} ({col['type']})")
        schema_parts.append(f"TABLE: {table_name}\nCOLUMNS:\n" + "\n".join(col_lines))

        # Get distinct values for low-cardinality columns
        distinct_parts = []
        with engine.connect() as conn:
            row_count = conn.execute(
                text(f"SELECT COUNT(*) FROM [{table_name}]")
            ).scalar()
            schema_parts.append(f"  ROW COUNT: {row_count}")

            for col in columns:
                col_name = col["name"]
                try:
                    distinct_count = conn.execute(
                        text(f"SELECT COUNT(DISTINCT [{col_name}]) FROM [{table_name}]")
                    ).scalar()
                    if distinct_count and distinct_count <= 30:
                        result = conn.execute(
                            text(
                                f"SELECT DISTINCT [{col_name}] FROM [{table_name}] ORDER BY [{col_name}] LIMIT 30"
                            )
                        )
                        vals = [str(r[0]) for r in result if r[0] is not None]
                        if vals:
                            distinct_parts.append(f"  {col_name}: {', '.join(vals)}")
                except Exception:
                    pass
        if distinct_parts:
            schema_parts.append("FILTERABLE VALUES:\n" + "\n".join(distinct_parts))

    engine.dispose()
    return "\n\n".join(schema_parts)


async def download_sqlite_file(db_uri: str) -> str:
    """
    Scarica il file SQLite dalla CMS se necessario e restituisce il percorso locale.
    Usa la stessa logica dell'integrazione Sitemap.

    Args:
        db_uri: URI del database o nome del file SQLite

    Returns:
        str: URI del database locale (sqlite:///path/to/file.db)
    """
    import os

    from ws_bom_robot_app.config import config
    from ws_bom_robot_app.llm.utils.download import download_file

    if (
        not db_uri.endswith(".db")
        and not db_uri.endswith(".sqlite")
        and not db_uri.endswith(".sqlite3")
    ):
        return db_uri

    if db_uri.startswith("sqlite:///"):
        file_path = db_uri.replace("sqlite:///", "")
        if os.path.isabs(file_path) and os.path.exists(file_path):
            return db_uri
        filename = os.path.basename(file_path)
    else:
        filename = db_uri

    db_folder = os.path.join(config.robot_data_folder, "db")
    os.makedirs(db_folder, exist_ok=True)

    local_db_path = os.path.join(db_folder, filename)

    if os.path.exists(local_db_path):
        return f"sqlite:///{local_db_path}"

    cms_file_url = f"{config.robot_cms_host}/{config.robot_cms_kb_folder}/{filename}"
    auth = config.robot_cms_auth

    try:
        result = await download_file(cms_file_url, local_db_path, authorization=auth)
        if result:
            return f"sqlite:///{local_db_path}"
        else:
            raise ValueError(f"File SQLite {filename} non trovato nella CMS")
    except Exception as e:
        raise ValueError(
            f"Errore durante il download del file SQLite {filename}: {str(e)}"
        )
