from ws_bom_robot_app.llm.vector_store.integration.base import IntegrationStrategy
from ws_bom_robot_app.llm.vector_store.loader.base import Loader
from langchain_core.documents import Document
from pydantic import BaseModel, Field, AliasChoices
from typing import Union
import asyncio, os, json, requests, logging

class SharepointParams(BaseModel):
  """
  SharepointParams is a Pydantic model that defines the parameters required to connect to a SharePoint site.

  Attributes:
    client_id (str): The client ID for SharePoint authentication.
    client_secret (str): The client secret for SharePoint authentication.
    tenant_id (str, optional): The tenant ID for SharePoint authentication. Defaults to None.
    site_id (str): The SharePoint site ID.
    drive_id (str): The SharePoint drive ID.
    folder_id (str, optional): The SharePoint folder ID to start from. Defaults to None.
    tags_to_include (list[dict], optional): Tags to include files. Defaults to empty list.
    tags_to_exclude (list[dict], optional): Tags to exclude files. Defaults to empty list.
  """
  client_id : str = Field(validation_alias=AliasChoices("clientId","client_id"))
  client_secret : str = Field(validation_alias=AliasChoices("clientSecret","client_secret"))
  site_id: str = Field(validation_alias=AliasChoices("siteId","site_id"))
  drive_id: str = Field(validation_alias=AliasChoices("driveId","drive_id"))
  folder_id: str = Field(default=None, validation_alias=AliasChoices("folderId","folder_id"))
  tenant_id: str = Field(default=None, validation_alias=AliasChoices("tenantId","tenant_id"))
  tags_to_include: list[dict] = Field(default=[], validation_alias=AliasChoices("tagsToInclude","tags_to_include"))
  tags_to_exclude: list[dict] = Field(default=[], validation_alias=AliasChoices("tagsToExclude","tags_to_exclude"))

class SharepointCustom(IntegrationStrategy):
    def __init__(self, knowledgebase_path: str, data: dict[str, Union[str, int, list]]):
        super().__init__(knowledgebase_path, data)
        self.__data = SharepointParams.model_validate(self.data)
        self.__sharepoint_api = SharepointApi(
            self.working_directory,
            self.__data.client_id,
            self.__data.client_secret,
            self.__data.tenant_id,
            self.__data.site_id,
            self.__data.drive_id,
            self.__data.folder_id,
            self.__data.tags_to_include,
            self.__data.tags_to_exclude
        )
    def working_subdirectory(self) -> str:
        return "sharepoint_custom"
    def run(self) -> None:
        loaders = Loader(self.working_directory)
        self.download_files(loaders.managed_file_extensions())
        self.download_pages()
        del loaders
    async def load(self) -> list[Document]:
        await asyncio.to_thread(self.run)
        await asyncio.sleep(1)
        return await Loader(self.working_directory).load()

    def download_files(self, filter_file_extensions:list[str]) -> bool:
      return self.__sharepoint_api.process_folder(self.__data.site_id, self.__data.drive_id, self.__data.folder_id, filter_file_extensions)

    def download_pages(self) -> bool:
      return self.__sharepoint_api.get_pages(self.__data.site_id)

class SharepointApi():
  def __init__(self, knowledgebase_path, client_id, client_secret, tenant_id, site_id, drive_id, folder_id=None, tags_to_incude: list[dict] = [], tags_to_exclude: list[dict] = []):
      self.__knowledgebase_path = knowledgebase_path
      self.__client_id = client_id
      self.__client_secret = client_secret
      self.__tenant_id = tenant_id
      self.__tags_to_incude = tags_to_incude
      self.__tags_to_exclude = tags_to_exclude
      self.__token = self.get_access_token(self.__client_id, self.__client_secret, self.__tenant_id)

  def get_access_token(self, client_id, client_secret, tenant_id):
      url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
      data = {
          'grant_type': 'client_credentials',
          'client_id': client_id,
          'client_secret': client_secret,
          'scope': 'https://graph.microsoft.com/.default'
      }

      response = requests.post(url, data=data)

      if response.status_code == 200:
          return response.json().get('access_token')
      else:
          logging.warning(f"[{type(SharepointApi).__name__}]: auth error for tenant {tenant_id} {response.status_code}, {response.text}")
          return None

  def process_folder(self, site_id, drive_id, folder_id=None, filter_file_extensions:list[str]=None) -> bool:
      if self.__token is None:
          return False
      children = self.__get_children(site_id, drive_id, folder_id)
      for item in children:
          if 'folder' in item:  # È una cartella
              self.process_folder(site_id, drive_id, item['id'],filter_file_extensions)
          elif 'file' in item:  # È un file
              if any(item.get('name', '').lower().endswith(ext.lower()) for ext in filter_file_extensions):
                 self.__download_file(site_id, drive_id, item['id'])
      return True

  def __get_children(self, site_id, drive_id, item_id=None):
    headers = {
        'Authorization': f'Bearer {self.__token}'
    }

    if item_id is None:
        # Radice della document library
        url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root/children"
    else:
        # Elementi all'interno di una cartella
        url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/items/{item_id}/children"

    all_items = []

    while url:  # Continua finché c'è una URL da seguire (per la paginazione)
        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            json_data = response.json()
            all_items.extend(json_data.get('value', []))  # Aggiungo gli elementi recuperati
            url = json_data.get('@odata.nextLink')  # Recupero il nextLink se presente
        else:
            break

    return all_items

  def __download_file(self, site_id, drive_id, item_id) -> bool :
      headers = {
          'Authorization': f'Bearer {self.__token}'
      }

      # Ottenere i metadati del file per estrarre il nome
      url_metadata = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drives/{drive_id}/items/{item_id}/listItem"
      response_metadata = requests.get(url_metadata, headers=headers)

      if response_metadata.status_code == 200:
          data = response_metadata.json()

          # Ottieni il nome del file dai metadati
          file_name = data.get("fields").get("FileLeafRef", "EmptyName")
          # Ottieni i tag del file dai metadati
          file_tags:dict = data.get("fields", {})
          # Get the file extension
          file_extension = file_tags.get("DocIcon", "")

          keys_to_include = {item.get("columnName"): item.get("columnValues") for item in self.__tags_to_incude}
          keys_to_exclude = {item.get("columnName"): item.get("columnValues") for item in self.__tags_to_exclude}

          for key in keys_to_include.keys():
            if key not in file_tags or file_tags[key] not in keys_to_include[key]:
              return False

          for key in keys_to_exclude.keys():
            if key in file_tags and file_tags[key] in keys_to_exclude[key]:
              return False

          # URL per scaricare il contenuto del file
          url_content = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drives/{drive_id}/items/{item_id}/content"
          response_content = requests.get(url_content, headers=headers)

          if response_content.status_code == 200:
              try:
                with open(os.path.join(self.__knowledgebase_path,file_name), "wb") as f:
                    f.write(response_content.content)
              except Exception as e:
                raise e
              return True
          else:
              return False
      else:
          return False


  def get_pages(self, site_id) -> bool:
      if self.__token is None:
          return []
      headers = {
          'Authorization': f'Bearer {self.__token}'
      }
      url_metadata = f"https://graph.microsoft.com/v1.0/sites/{site_id}/pages"
      request = requests.get(url_metadata, headers=headers)
      if request.status_code == 200:
          sites = json.loads(request.content)
          for site in sites["value"]:
              page_url = site['webUrl']
              if not self.__download_page_contents(site_id, site['id'], page_url):
                  return False
          return True
      else:
          logging.warning(f"[{type(SharepointApi).__name__}]: find page {site_id} error {request.status_code}: {request.text}")
          return False

  def __download_page_contents(self, site_id, page_id, page_url) -> bool:
      headers = {
          'Authorization': f'Bearer {self.__token}'
      }
      url_metadata = f"https://graph.microsoft.com/v1.0/sites/{site_id}/pages/{page_id}/microsoft.graph.sitepage/webparts"
      request = requests.get(url_metadata, headers=headers)
      if request.status_code == 200:
          html_items = []
          site_content: dict = json.loads(request.content)
          for item in site_content.get("value", []):
              html_items.append(f"{item.get('innerHtml', '')}")
          if len(html_items) > 0 :
              _content = '\n\n'.join(html_items)
              if _content.strip() != "":
                with open(os.path.join(self.__knowledgebase_path, f"{page_id}.html"), "w", encoding="utf-8") as f:
                    f.write(_content)
          return True
      else:
          logging.warning(f"[{type(SharepointApi).__name__}]: find content page {site_id}/{page_id} error {request.status_code}: {request.text}")
          return False

