import asyncio
import httpx
from typing import Union, Literal
from pydantic import BaseModel, Field, AliasChoices
from langchain_core.documents import Document
from bs4 import BeautifulSoup
import logging

from ws_bom_robot_app.llm.vector_store.integration.base import IntegrationStrategy

logger = logging.getLogger(__name__)

class ZendeskParams(BaseModel):
    """
    ZendeskParams is a data model for storing Zendesk integration parameters.

    Attributes:
        subdomain (str): The subdomain of the Zendesk instance, e.g., 'company' for 'company.zendesk.com'.
        email (str): The email address associated with the Zendesk account.
        api_token (str): The API token for authenticating with the Zendesk API.
        item_type (Literal["tickets", "articles", "all"]): Type of item from Zendesk to parse. Defaults to "tickets".
        extension (list[str], optional): A list of file extensions to filter by. Defaults to None.
    """
    subdomain: str
    email: str
    api_token: str = Field(validation_alias=AliasChoices("apiToken", "api_token", "token"))
    item_type: Literal["tickets", "articles", "all"] = Field(
        default="tickets", validation_alias=AliasChoices("itemType", "item_type")
    )
    extension: list[str] = Field(default=None)

class Zendesk(IntegrationStrategy):
    def __init__(self, knowledgebase_path: str, data: dict[str, Union[str, int, list]]):
        super().__init__(knowledgebase_path, data)
        self.__data = ZendeskParams.model_validate(self.data)

    def working_subdirectory(self) -> str:
        return 'zendesk'

    async def _fetch_paginated_data(self, client: httpx.AsyncClient, url: str) -> list[dict]:
        results = []
        while url:
            logger.debug(f"Fetching Zendesk API: {url}")
            response = await client.get(url)
            response.raise_for_status()
            data = response.json()
            
            if "articles" in data:
                results.extend(data["articles"])
            elif "tickets" in data:
                results.extend(data["tickets"])
                
            url = data.get("next_page")
        return results

    async def _get_articles(self, client: httpx.AsyncClient) -> list[Document]:
        url = f"https://{self.__data.subdomain}.zendesk.com/api/v2/help_center/articles.json"
        articles = await self._fetch_paginated_data(client, url)
        
        docs = []
        for article in articles:
            body_html = article.pop("body", "") or ""
            soup = BeautifulSoup(body_html, "html.parser")
            text = soup.get_text(separator=" ", strip=True)
            
            if not text:
                continue

            metadata = {"type": "article", "source": article.get("html_url") or url}
            for key, value in article.items():
                if value is None:
                    continue
                if isinstance(value, (dict, list)):
                    metadata[key] = str(value)
                else:
                    metadata[key] = value
                
            docs.append(Document(page_content=text, metadata=metadata))
        return docs

    async def _get_tickets(self, client: httpx.AsyncClient) -> list[Document]:
        url = f"https://{self.__data.subdomain}.zendesk.com/api/v2/tickets.json"
        tickets = await self._fetch_paginated_data(client, url)
        
        docs = []
        for ticket in tickets:
            text = ticket.pop("description", "") or ""
            if not text:
                continue
                
            metadata = {"type": "ticket", "source": f"https://{self.__data.subdomain}.zendesk.com/agent/tickets/{ticket.get('id')}"}
            for key, value in ticket.items():
                if value is None:
                    continue
                if isinstance(value, (dict, list)):
                    metadata[key] = str(value)
                else:
                    metadata[key] = value
                
            docs.append(Document(page_content=text, metadata=metadata))
        return docs

    async def load(self) -> list[Document]:
        auth = (f"{self.__data.email}/token", self.__data.api_token)
        docs = []
        
        # Initialize httpx client with authentication specific to Zendesk API
        async with httpx.AsyncClient(auth=auth, timeout=30.0) as client:
            if self.__data.item_type in ["articles", "all"]:
                try:
                    docs.extend(await self._get_articles(client))
                except Exception as e:
                    logger.error(f"Error fetching Zendesk articles: {e}")
            
            if self.__data.item_type in ["tickets", "all"]:
                try:
                    docs.extend(await self._get_tickets(client))
                except Exception as e:
                    logger.error(f"Error fetching Zendesk tickets: {e}")
                    
        return docs
