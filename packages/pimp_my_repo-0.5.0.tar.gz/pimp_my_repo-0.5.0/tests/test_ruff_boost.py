"""Tests for Ruff boost implementation."""

import json
from dataclasses import dataclass
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import pytest

from pimp_my_repo.core.boosts.base import BoostSkipped
from pimp_my_repo.core.boosts.ruff import _MAX_RUFF_ITERATIONS, RuffBoost, ViolationLocation

if TYPE_CHECKING:
    from collections.abc import Generator

    from pimp_my_repo.core.tools.boost_tools import BoostTools
    from pimp_my_repo.core.tools.repo import RepositoryController
    from tests.conftest import SubprocessResultFactory


@pytest.fixture
def ruff_boost(boost_tools: BoostTools) -> RuffBoost:
    return RuffBoost(boost_tools)


@pytest.fixture
def ruff_boost_with_pyproject(boost_tools: BoostTools, repo_controller: RepositoryController) -> RuffBoost:
    repo_controller.write_file("pyproject.toml", "[project]\nname = 'test'\nversion = '0.1.0'\n")
    return RuffBoost(boost_tools)


@dataclass
class PatchedRuffApply:
    """Pre-patched RuffBoost with all subprocess mocks wired for apply()."""

    boost: RuffBoost
    mock_uv: MagicMock
    mock_git: MagicMock
    mock_format: MagicMock
    mock_check: MagicMock


@pytest.fixture
def patched_ruff_apply(
    ruff_boost_with_pyproject: RuffBoost,
    ok_result: SubprocessResultFactory,
) -> Generator[PatchedRuffApply]:
    """Yield a RuffBoost with all subprocess calls pre-mocked to succeed."""
    with (
        patch.object(ruff_boost_with_pyproject.tools.uv, "exec", return_value=ok_result()) as mock_uv,
        patch.object(ruff_boost_with_pyproject.tools.git, "commit") as mock_git,
        patch.object(ruff_boost_with_pyproject, "_run_ruff_format", return_value=ok_result()) as mock_fmt,
        patch.object(ruff_boost_with_pyproject, "_run_ruff_check", return_value=ok_result()) as mock_check,
        patch.object(ruff_boost_with_pyproject, "_migrate_deprecated_ruff_config", side_effect=lambda data: data),
    ):
        yield PatchedRuffApply(
            boost=ruff_boost_with_pyproject,
            mock_uv=mock_uv,
            mock_git=mock_git,
            mock_format=mock_fmt,
            mock_check=mock_check,
        )


@dataclass
class PatchedRuffApplyWithAddPackage:
    """Pre-patched RuffBoost with subprocess and add_package mocks wired for apply()."""

    boost: RuffBoost
    mock_uv: MagicMock
    mock_git: MagicMock
    mock_format: MagicMock
    mock_check: MagicMock
    mock_add_package: MagicMock


@pytest.fixture
def patched_ruff_apply_with_add_package(
    ruff_boost_with_pyproject: RuffBoost,
    ok_result: SubprocessResultFactory,
) -> Generator[PatchedRuffApplyWithAddPackage]:
    """Yield a RuffBoost with all subprocess and add_package calls pre-mocked."""
    with (
        patch.object(ruff_boost_with_pyproject.tools.uv, "exec", return_value=ok_result()) as mock_uv,
        patch.object(ruff_boost_with_pyproject.tools.git, "commit") as mock_git,
        patch.object(ruff_boost_with_pyproject, "_run_ruff_format", return_value=ok_result()) as mock_fmt,
        patch.object(ruff_boost_with_pyproject, "_run_ruff_check", return_value=ok_result()) as mock_check,
        patch.object(ruff_boost_with_pyproject.tools.uv, "add_package") as mock_add_package,
        patch.object(ruff_boost_with_pyproject, "_migrate_deprecated_ruff_config", side_effect=lambda data: data),
    ):
        yield PatchedRuffApplyWithAddPackage(
            boost=ruff_boost_with_pyproject,
            mock_uv=mock_uv,
            mock_git=mock_git,
            mock_format=mock_fmt,
            mock_check=mock_check,
            mock_add_package=mock_add_package,
        )


@pytest.fixture
def ruff_boost_uv_failing(
    ruff_boost_with_pyproject: RuffBoost,
    fail_result: SubprocessResultFactory,
) -> Generator[RuffBoost]:
    """Yield a RuffBoost where uv.run returns a non-zero result."""
    with patch.object(ruff_boost_with_pyproject.tools.uv, "exec", return_value=fail_result()):
        yield ruff_boost_with_pyproject


@pytest.fixture
def ruff_boost_uv_file_not_found(ruff_boost_with_pyproject: RuffBoost) -> Generator[RuffBoost]:
    """Yield a RuffBoost where uv.run raises FileNotFoundError."""
    with patch.object(ruff_boost_with_pyproject.tools.uv, "exec", side_effect=FileNotFoundError):
        yield ruff_boost_with_pyproject


@pytest.fixture
def ruff_boost_uv_oserror(ruff_boost_with_pyproject: RuffBoost) -> Generator[RuffBoost]:
    """Yield a RuffBoost where uv.run raises OSError."""
    with patch.object(ruff_boost_with_pyproject.tools.uv, "exec", side_effect=OSError):
        yield ruff_boost_with_pyproject


@pytest.fixture
def ruff_boost_uv_ok(
    ruff_boost: RuffBoost,
    ok_result: SubprocessResultFactory,
) -> Generator[RuffBoost]:
    """Yield a RuffBoost (no pyproject) where uv.run returns ok."""
    with patch.object(ruff_boost.tools.uv, "exec", return_value=ok_result()):
        yield ruff_boost


# =============================================================================
# PRECONDITIONS
# =============================================================================


def test_raises_skip_when_uv_nonzero(ruff_boost_uv_failing: RuffBoost) -> None:
    with pytest.raises(BoostSkipped, match="uv is not available"):
        ruff_boost_uv_failing.apply()


def test_raises_skip_when_uv_raises_file_not_found(ruff_boost_uv_file_not_found: RuffBoost) -> None:
    with pytest.raises(BoostSkipped, match="uv is not installed"):
        ruff_boost_uv_file_not_found.apply()


def test_raises_skip_when_uv_raises_oserror(ruff_boost_uv_oserror: RuffBoost) -> None:
    with pytest.raises(BoostSkipped, match="uv is not installed"):
        ruff_boost_uv_oserror.apply()


@pytest.mark.smoke
def test_raises_skip_when_no_pyproject(ruff_boost_uv_ok: RuffBoost) -> None:
    with pytest.raises(BoostSkipped, match=r"No pyproject\.toml found"):
        ruff_boost_uv_ok.apply()


# =============================================================================
# PARSE VIOLATIONS
# =============================================================================


@pytest.mark.smoke
def test_parses_single_violation(ruff_boost: RuffBoost) -> None:
    output = json.dumps([{"filename": "src/foo.py", "code": "E501", "noqa_row": 10}])
    assert ruff_boost._parse_violations(output) == {ViolationLocation("src/foo.py", 10): {"E501"}}  # noqa: SLF001


def test_parses_violations_on_different_lines(ruff_boost: RuffBoost) -> None:
    output = json.dumps(
        [
            {"filename": "src/foo.py", "code": "E501", "noqa_row": 10},
            {"filename": "src/foo.py", "code": "F401", "noqa_row": 20},
        ]
    )
    result = ruff_boost._parse_violations(output)  # noqa: SLF001
    assert result == {
        ViolationLocation("src/foo.py", 10): {"E501"},
        ViolationLocation("src/foo.py", 20): {"F401"},
    }


def test_accumulates_multiple_codes_on_same_line(ruff_boost: RuffBoost) -> None:
    output = json.dumps(
        [
            {"filename": "src/foo.py", "code": "E501", "noqa_row": 5},
            {"filename": "src/foo.py", "code": "F401", "noqa_row": 5},
        ]
    )
    result = ruff_boost._parse_violations(output)  # noqa: SLF001
    assert result == {ViolationLocation("src/foo.py", 5): {"E501", "F401"}}


def test_parses_violations_across_multiple_files(ruff_boost: RuffBoost) -> None:
    output = json.dumps(
        [
            {"filename": "src/foo.py", "code": "F401", "noqa_row": 1},
            {"filename": "src/bar.py", "code": "E501", "noqa_row": 2},
        ]
    )
    result = ruff_boost._parse_violations(output)  # noqa: SLF001
    assert ViolationLocation("src/foo.py", 1) in result
    assert ViolationLocation("src/bar.py", 2) in result


def test_ignores_violations_with_no_noqa_row(ruff_boost: RuffBoost) -> None:
    output = json.dumps(
        [
            {"filename": "src/foo.py", "code": "E501", "noqa_row": 10},
            {"filename": "src/foo.py", "code": "F401", "noqa_row": None},
        ]
    )
    result = ruff_boost._parse_violations(output)  # noqa: SLF001
    assert len(result) == 1


def test_skips_unsuppressible_codes(ruff_boost: RuffBoost) -> None:
    output = json.dumps(
        [
            {"filename": "src/foo.py", "code": "ERA001", "noqa_row": 5},
            {"filename": "src/foo.py", "code": "E501", "noqa_row": 5},
        ]
    )
    result = ruff_boost._parse_violations(output)  # noqa: SLF001
    assert result == {ViolationLocation("src/foo.py", 5): {"E501"}}


def test_ruf100_is_unsuppressible(ruff_boost: RuffBoost) -> None:
    """RUF100 on file-level `# ruff: noqa:` lines causes oscillation if suppressed inline.

    Adding `# noqa: RUF100` to `# ruff: noqa: E501` doesn't actually suppress RUF100
    because the file-level directive remains unused — ruff keeps reporting it each iteration.
    RUF100 must be treated as unsuppressible (added to ignore list instead).
    """
    output = json.dumps(
        [
            {"filename": "src/foo.py", "code": "RUF100", "noqa_row": 1},
            {"filename": "src/foo.py", "code": "E501", "noqa_row": 2},
        ]
    )
    result = ruff_boost._parse_violations(output)  # noqa: SLF001
    assert result == {ViolationLocation("src/foo.py", 2): {"E501"}}


def test_migrate_deprecated_ruff_config_moves_keys_reported_by_ruff(
    mock_repo: RepositoryController, ruff_boost: RuffBoost
) -> None:
    """Keys reported as deprecated by ruff are moved; unreported keys stay at the top level."""
    mock_repo.write_file(
        "pyproject.toml",
        (
            "[tool.ruff]\n"
            "line-length = 120\n"
            "fix = true\n"
            'output-format = "full"\n'
            'exclude = ["local"]\n'
            'select = ["B", "C"]\n'
            "ignore = []\n"
        ),
    )
    # Simulate ruff warning about select and ignore only (not fix/output-format/exclude)
    warning_result = MagicMock()
    warning_result.stderr = "  - 'select' -> 'lint.select'\n  - 'ignore' -> 'lint.ignore'\n"
    with patch.object(ruff_boost, "_run_ruff_check", return_value=warning_result):
        data = ruff_boost.tools.pyproject.read()
        data = ruff_boost._migrate_deprecated_ruff_config(data)  # noqa: SLF001
        ruff_boost.tools.pyproject.write(data)

    content = (mock_repo.path / "pyproject.toml").read_text()
    lint_pos = content.index("[tool.ruff.lint]")
    ruff_pos = content.index("[tool.ruff]")

    # Reported lint-level keys moved under [tool.ruff.lint]
    assert content.index('select = ["B", "C"]') > lint_pos
    assert content.index("ignore = []") > lint_pos

    # Unreported keys stay in [tool.ruff]
    assert content.index("line-length = 120") < lint_pos
    assert content.index("fix = true") < lint_pos
    assert content.index('output-format = "full"') < lint_pos
    assert content.index('exclude = ["local"]') < lint_pos

    # Lint keys must not appear before [tool.ruff.lint]
    assert 'select = ["B", "C"]' not in content[ruff_pos:lint_pos]
    assert "ignore = []" not in content[ruff_pos:lint_pos]


def test_migrate_deprecated_ruff_config_preserves_existing_lint_section(
    mock_repo: RepositoryController, ruff_boost: RuffBoost
) -> None:
    """Existing [tool.ruff.lint] values are not overwritten during migration."""
    mock_repo.write_file(
        "pyproject.toml",
        '[tool.ruff]\nselect = ["B"]\n\n[tool.ruff.lint]\nselect = ["ALL"]\n',
    )
    warning_result = MagicMock()
    warning_result.stderr = "  - 'select' -> 'lint.select'\n"
    with patch.object(ruff_boost, "_run_ruff_check", return_value=warning_result):
        data = ruff_boost.tools.pyproject.read()
        data = ruff_boost._migrate_deprecated_ruff_config(data)  # noqa: SLF001
        ruff_boost.tools.pyproject.write(data)

    content = (mock_repo.path / "pyproject.toml").read_text()
    # Existing lint value wins
    assert 'select = ["ALL"]' in content
    # Deprecated top-level value is dropped entirely
    assert 'select = ["B"]' not in content


def test_migrate_deprecated_ruff_config_no_op_when_ruff_reports_nothing(
    mock_repo: RepositoryController, ruff_boost: RuffBoost
) -> None:
    """Migration does nothing when ruff reports no deprecated settings."""
    original = '[tool.ruff]\nline-length = 100\n\n[tool.ruff.lint]\nselect = ["ALL"]\n'
    mock_repo.write_file("pyproject.toml", original)
    no_warning_result = MagicMock()
    no_warning_result.stderr = ""
    with patch.object(ruff_boost, "_run_ruff_check", return_value=no_warning_result):
        data = ruff_boost.tools.pyproject.read()
        data = ruff_boost._migrate_deprecated_ruff_config(data)  # noqa: SLF001
        ruff_boost.tools.pyproject.write(data)

    content = (mock_repo.path / "pyproject.toml").read_text()
    assert "line-length = 100" in content
    assert 'select = ["ALL"]' in content
    assert content.count("[tool.ruff.lint]") == 1


def test_deprecated_key_regex_parses_ruff_warning() -> None:
    """_RUFF_DEPRECATED_KEY_RE extracts key names from ruff's deprecation warning lines."""
    from pimp_my_repo.core.boosts.ruff import _RUFF_DEPRECATED_KEY_RE  # noqa: PLC0415

    warning_stderr = (
        "warning: The top-level linter settings are deprecated...\n"
        "  - 'ignore' -> 'lint.ignore'\n"
        "  - 'select' -> 'lint.select'\n"
    )
    assert set(_RUFF_DEPRECATED_KEY_RE.findall(warning_stderr)) == {"ignore", "select"}


def test_ruff_config_ignores_ruf100(mock_repo: RepositoryController, ruff_boost: RuffBoost) -> None:
    """RUF100 must be in the ignore list to prevent oscillation on file-level noqa directives."""
    mock_repo.write_file("pyproject.toml", "[project]\nname = 'test'\n")
    data = ruff_boost.tools.pyproject.read()
    data = ruff_boost._ensure_ruff_config(data)  # noqa: SLF001
    ruff_boost.tools.pyproject.write(data)
    content = (mock_repo.path / "pyproject.toml").read_text()
    assert "RUF100" in content


def test_empty_output(ruff_boost: RuffBoost) -> None:
    with pytest.raises(RuntimeError, match="non-JSON"):
        ruff_boost._parse_violations("")  # noqa: SLF001


def test_all_checks_passed_output(ruff_boost: RuffBoost) -> None:
    with pytest.raises(RuntimeError, match="non-JSON"):
        ruff_boost._parse_violations("All checks passed!\n")  # noqa: SLF001


# =============================================================================
# APPLY NOQA
# =============================================================================


def test_adds_noqa_comment_to_clean_line(mock_repo: RepositoryController, ruff_boost: RuffBoost) -> None:
    mock_repo.write_file("src/foo.py", "import os\n")
    ruff_boost._apply_noqa({ViolationLocation("src/foo.py", 1): {"F401"}})  # noqa: SLF001
    assert "# noqa: F401" in (mock_repo.path / "src/foo.py").read_text()


def test_merges_new_code_with_existing_noqa(mock_repo: RepositoryController, ruff_boost: RuffBoost) -> None:
    mock_repo.write_file("src/foo.py", "import os  # noqa: F401\n")
    ruff_boost._apply_noqa({ViolationLocation("src/foo.py", 1): {"E501"}})  # noqa: SLF001
    content = (mock_repo.path / "src/foo.py").read_text()
    assert "F401" in content
    assert "E501" in content
    assert content.count("# noqa") == 1


def test_merges_multiple_codes_on_same_line(mock_repo: RepositoryController, ruff_boost: RuffBoost) -> None:
    mock_repo.write_file("src/foo.py", "import os\n")
    ruff_boost._apply_noqa({ViolationLocation("src/foo.py", 1): {"F401", "E501"}})  # noqa: SLF001
    content = (mock_repo.path / "src/foo.py").read_text()
    assert "# noqa: " in content
    assert "F401" in content
    assert "E501" in content


def test_handles_multiple_lines_in_same_file(mock_repo: RepositoryController, ruff_boost: RuffBoost) -> None:
    mock_repo.write_file("src/foo.py", "import os\nimport sys\n")
    ruff_boost._apply_noqa(  # noqa: SLF001
        {
            ViolationLocation("src/foo.py", 1): {"F401"},
            ViolationLocation("src/foo.py", 2): {"F401"},
        }
    )
    lines = (mock_repo.path / "src/foo.py").read_text().splitlines()
    assert "# noqa: F401" in lines[0]
    assert "# noqa: F401" in lines[1]


def test_handles_multiple_files(mock_repo: RepositoryController, ruff_boost: RuffBoost) -> None:
    mock_repo.write_file("src/foo.py", "import os\n")
    mock_repo.write_file("src/bar.py", "import sys\n")
    ruff_boost._apply_noqa(  # noqa: SLF001
        {
            ViolationLocation("src/foo.py", 1): {"F401"},
            ViolationLocation("src/bar.py", 1): {"F401"},
        }
    )
    assert "# noqa" in (mock_repo.path / "src/foo.py").read_text()
    assert "# noqa" in (mock_repo.path / "src/bar.py").read_text()


def test_skips_missing_file_without_raising(ruff_boost: RuffBoost) -> None:
    ruff_boost._apply_noqa({ViolationLocation("nonexistent.py", 1): {"F401"}})  # noqa: SLF001


def test_noqa_codes_sorted_alphabetically(mock_repo: RepositoryController, ruff_boost: RuffBoost) -> None:
    mock_repo.write_file("src/foo.py", "import os\n")
    ruff_boost._apply_noqa({ViolationLocation("src/foo.py", 1): {"F401", "E501", "ANN201"}})  # noqa: SLF001
    content = (mock_repo.path / "src/foo.py").read_text()
    ann_pos = content.index("ANN201")
    e501_pos = content.index("E501")
    f401_pos = content.index("F401")
    assert ann_pos < e501_pos < f401_pos


def test_noqa_preserves_existing_line_content(mock_repo: RepositoryController, ruff_boost: RuffBoost) -> None:
    mock_repo.write_file("src/foo.py", "result = some_func(arg1, arg2)\n")
    ruff_boost._apply_noqa({ViolationLocation("src/foo.py", 1): {"E501"}})  # noqa: SLF001
    content = (mock_repo.path / "src/foo.py").read_text()
    assert "result = some_func(arg1, arg2)" in content
    assert "# noqa: E501" in content


def test_handles_uppercase_noqa_isort_skip(mock_repo: RepositoryController, ruff_boost: RuffBoost) -> None:
    """Lines with # NOQA isort:skip should have isort:skip preserved and ruff codes merged."""
    mock_repo.write_file("src/foo.py", "from base import *  # NOQA isort:skip\n")
    ruff_boost._apply_noqa({ViolationLocation("src/foo.py", 1): {"PGH004"}})  # noqa: SLF001
    content = (mock_repo.path / "src/foo.py").read_text()
    assert "isort:skip" in content
    assert "# noqa: PGH004" in content
    assert content.count("# noqa") == 1


def test_merges_two_noqa_on_same_line(mock_repo: RepositoryController, ruff_boost: RuffBoost) -> None:
    """All noqa directives on a line are merged into one."""
    mock_repo.write_file("src/foo.py", "from base import *  # NOQA isort:skip  # noqa: F403\n")
    ruff_boost._apply_noqa({ViolationLocation("src/foo.py", 1): {"PGH004"}})  # noqa: SLF001
    content = (mock_repo.path / "src/foo.py").read_text()
    assert "isort:skip" in content
    assert "F403" in content
    assert "PGH004" in content
    assert content.count("# noqa") == 1


def test_adds_noqa_to_empty_file(mock_repo: RepositoryController, ruff_boost: RuffBoost) -> None:
    """For an empty file, a noqa comment is prepended rather than skipped."""
    mock_repo.write_file("src/__init__.py", "")
    ruff_boost._apply_noqa({ViolationLocation("src/__init__.py", 1): {"D104"}})  # noqa: SLF001
    content = (mock_repo.path / "src/__init__.py").read_text()
    assert "# noqa: D104" in content


# =============================================================================
# ENSURE RUFF CONFIG
# =============================================================================


def test_adds_ruff_section_when_missing(mock_repo: RepositoryController, ruff_boost: RuffBoost) -> None:
    mock_repo.write_file("pyproject.toml", "[project]\nname = 'test'\n")
    data = ruff_boost.tools.pyproject.read()
    data = ruff_boost._ensure_ruff_config(data)  # noqa: SLF001
    ruff_boost.tools.pyproject.write(data)
    content = (mock_repo.path / "pyproject.toml").read_text()
    assert "[tool.ruff" in content
    assert 'select = ["ALL"]' in content


def test_ruff_config_ignores_era001(mock_repo: RepositoryController, ruff_boost: RuffBoost) -> None:
    mock_repo.write_file("pyproject.toml", "[project]\nname = 'test'\n")
    data = ruff_boost.tools.pyproject.read()
    data = ruff_boost._ensure_ruff_config(data)  # noqa: SLF001
    ruff_boost.tools.pyproject.write(data)
    content = (mock_repo.path / "pyproject.toml").read_text()
    assert "ERA001" in content


def test_ruff_config_sets_line_length(mock_repo: RepositoryController, ruff_boost: RuffBoost) -> None:
    mock_repo.write_file("pyproject.toml", "[project]\nname = 'test'\n")
    data = ruff_boost.tools.pyproject.read()
    data = ruff_boost._ensure_ruff_config(data)  # noqa: SLF001
    ruff_boost.tools.pyproject.write(data)
    content = (mock_repo.path / "pyproject.toml").read_text()
    assert "line-length = 120" in content


def test_ruff_config_preserves_existing_content(mock_repo: RepositoryController, ruff_boost: RuffBoost) -> None:
    mock_repo.write_file("pyproject.toml", "[project]\nname = 'test'\n\n[tool.mypy]\nstrict = true\n")
    data = ruff_boost.tools.pyproject.read()
    data = ruff_boost._ensure_ruff_config(data)  # noqa: SLF001
    ruff_boost.tools.pyproject.write(data)
    content = (mock_repo.path / "pyproject.toml").read_text()
    assert "[tool.mypy]" in content
    assert "strict = true" in content


# =============================================================================
# APPLY
# =============================================================================


@pytest.mark.smoke
def test_apply_calls_uv_add_ruff(patched_ruff_apply_with_add_package: PatchedRuffApplyWithAddPackage) -> None:
    patched_ruff_apply_with_add_package.boost.apply()
    patched_ruff_apply_with_add_package.mock_add_package.assert_called_once_with("ruff>=0.1.0,<0.16", group="lint")


def test_apply_writes_ruff_config_to_pyproject(
    mock_repo: RepositoryController, patched_ruff_apply: PatchedRuffApply
) -> None:
    patched_ruff_apply.boost.apply()
    content = (mock_repo.path / "pyproject.toml").read_text()
    assert 'select = ["ALL"]' in content


def test_apply_makes_configure_ruff_commit(patched_ruff_apply: PatchedRuffApply) -> None:
    patched_ruff_apply.boost.apply()
    messages = [c.args[0] for c in patched_ruff_apply.mock_git.call_args_list]
    assert any("Configure ruff" in m for m in messages)


def test_apply_runs_format(patched_ruff_apply: PatchedRuffApply) -> None:
    patched_ruff_apply.boost.apply()
    assert patched_ruff_apply.mock_format.call_count >= 1


def test_apply_stops_when_check_passes(patched_ruff_apply: PatchedRuffApply) -> None:
    patched_ruff_apply.boost.apply()
    patched_ruff_apply.mock_check.assert_called_once()


@pytest.mark.smoke
def test_apply_inserts_noqa_on_violation(
    mock_repo: RepositoryController,
    patched_ruff_apply: PatchedRuffApply,
    fail_result: SubprocessResultFactory,
    ok_result: SubprocessResultFactory,
) -> None:
    mock_repo.write_file("src/foo.py", "import os\n")
    patched_ruff_apply.mock_check.side_effect = [
        fail_result(json.dumps([{"filename": "src/foo.py", "code": "F401", "noqa_row": 1}])),
        ok_result(),
    ]
    patched_ruff_apply.boost.apply()
    assert "# noqa: F401" in (mock_repo.path / "src/foo.py").read_text()


def test_apply_iterates_until_check_passes(
    mock_repo: RepositoryController,
    patched_ruff_apply: PatchedRuffApply,
    fail_result: SubprocessResultFactory,
    ok_result: SubprocessResultFactory,
) -> None:
    mock_repo.write_file("src/foo.py", "import os\n")
    patched_ruff_apply.mock_check.side_effect = [
        fail_result(json.dumps([{"filename": "src/foo.py", "code": "F401", "noqa_row": 1}])),
        fail_result(json.dumps([{"filename": "src/foo.py", "code": "E501", "noqa_row": 1}])),
        ok_result(),
    ]
    patched_ruff_apply.boost.apply()
    assert patched_ruff_apply.mock_check.call_count == 3  # noqa: PLR2004


def test_apply_stops_after_max_iterations(
    mock_repo: RepositoryController,
    patched_ruff_apply: PatchedRuffApply,
    fail_result: SubprocessResultFactory,
) -> None:
    mock_repo.write_file("src/foo.py", "import os\n")
    patched_ruff_apply.mock_check.return_value = fail_result(
        json.dumps([{"filename": "src/foo.py", "code": "F401", "noqa_row": 1}])
    )
    patched_ruff_apply.boost.apply()
    assert patched_ruff_apply.mock_check.call_count == _MAX_RUFF_ITERATIONS


def test_apply_fails_when_ruff_check_produces_non_json_output(
    patched_ruff_apply: PatchedRuffApply,
    fail_result: SubprocessResultFactory,
) -> None:
    patched_ruff_apply.mock_check.return_value = fail_result("some unparseable output\n")
    with pytest.raises(RuntimeError, match="non-JSON"):
        patched_ruff_apply.boost.apply()
    patched_ruff_apply.mock_check.assert_called_once()


def test_excludes_syntax_error_file_in_pyproject(
    mock_repo: RepositoryController,
    patched_ruff_apply: PatchedRuffApply,
    fail_result: SubprocessResultFactory,
    ok_result: SubprocessResultFactory,
) -> None:
    patched_ruff_apply.mock_check.side_effect = [
        fail_result(json.dumps([{"filename": "src/bad.py", "code": "invalid-syntax", "noqa_row": None}])),
        ok_result(),
    ]
    patched_ruff_apply.boost.apply()
    content = (mock_repo.path / "pyproject.toml").read_text()
    assert "src/bad.py" in content


# =============================================================================
# MISC
# =============================================================================


def test_commit_message(ruff_boost: RuffBoost) -> None:
    assert ruff_boost.commit_message() == "✅ Silence ruff violations"


def test_get_name() -> None:
    assert RuffBoost.get_name() == "ruff"
