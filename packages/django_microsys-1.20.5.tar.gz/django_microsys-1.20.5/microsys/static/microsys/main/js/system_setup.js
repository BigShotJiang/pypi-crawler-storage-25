(function () {
    'use strict';

    const SETUP_STATE_KEY = `microsys.systemSetupState:${window.location.pathname}`;
    const ICON_SUGGESTIONS = [
        // ── Home & Dashboard ──
        'bi-house',
        'bi-house-fill',
        'bi-house-door',
        'bi-house-door-fill',
        'bi-house-heart',
        'bi-house-heart-fill',
        'bi-house-gear',
        'bi-house-gear-fill',
        'bi-house-lock',
        'bi-houses',
        'bi-speedometer2',
        'bi-speedometer',

        // ── Grid & Layout ──
        'bi-grid',
        'bi-grid-3x2',
        'bi-grid-3x2-gap',
        'bi-grid-3x3-gap',
        'bi-grid-fill',
        'bi-grid-1x2',
        'bi-layout-sidebar',
        'bi-layout-text-sidebar',
        'bi-layout-sidebar-inset',
        'bi-layout-three-columns',
        'bi-columns',
        'bi-columns-gap',
        'bi-window',
        'bi-window-sidebar',
        'bi-window-stack',
        'bi-window-fullscreen',
        'bi-window-split',

        // ── Boxes & Containers ──
        'bi-box',
        'bi-box-fill',
        'bi-box-seam',
        'bi-box-seam-fill',
        'bi-box2',
        'bi-boxes',
        'bi-inbox',
        'bi-inbox-fill',
        'bi-inboxes',
        'bi-inboxes-fill',
        'bi-archive',
        'bi-archive-fill',
        'bi-collection',
        'bi-collection-fill',

        // ── Folders ──
        'bi-folder',
        'bi-folder-fill',
        'bi-folder-plus',
        'bi-folder-check',
        'bi-folder-minus',
        'bi-folder-x',
        'bi-folder-symlink',
        'bi-folder-symlink-fill',
        'bi-folder2',
        'bi-folder2-open',

        // ── Files (Generic) ──
        'bi-file',
        'bi-file-fill',
        'bi-file-text',
        'bi-file-text-fill',
        'bi-file-richtext',
        'bi-file-richtext-fill',
        'bi-file-code',
        'bi-file-code-fill',
        'bi-file-binary',
        'bi-file-binary-fill',
        'bi-file-diff',
        'bi-file-diff-fill',
        'bi-file-ruled',
        'bi-file-ruled-fill',
        'bi-file-check',
        'bi-file-check-fill',
        'bi-file-x',
        'bi-file-x-fill',
        'bi-file-plus',
        'bi-file-plus-fill',
        'bi-file-minus',
        'bi-file-minus-fill',
        'bi-file-lock',
        'bi-file-lock-fill',
        'bi-file-lock2',
        'bi-file-lock2-fill',
        'bi-file-break',
        'bi-file-break-fill',
        'bi-file-bar-graph',
        'bi-file-bar-graph-fill',
        'bi-file-post',
        'bi-file-post-fill',
        'bi-file-medical',
        'bi-file-medical-fill',
        'bi-file-person',
        'bi-file-person-fill',

        // ── Files (Earmark Variants) ──
        'bi-file-earmark',
        'bi-file-earmark-fill',
        'bi-file-earmark-text',
        'bi-file-earmark-text-fill',
        'bi-file-earmark-richtext',
        'bi-file-earmark-richtext-fill',
        'bi-file-earmark-code',
        'bi-file-earmark-code-fill',
        'bi-file-earmark-binary',
        'bi-file-earmark-binary-fill',
        'bi-file-earmark-diff',
        'bi-file-earmark-diff-fill',
        'bi-file-earmark-ruled',
        'bi-file-earmark-ruled-fill',
        'bi-file-earmark-check',
        'bi-file-earmark-check-fill',
        'bi-file-earmark-x',
        'bi-file-earmark-x-fill',
        'bi-file-earmark-plus',
        'bi-file-earmark-plus-fill',
        'bi-file-earmark-minus',
        'bi-file-earmark-minus-fill',
        'bi-file-earmark-lock',
        'bi-file-earmark-lock-fill',
        'bi-file-earmark-lock2',
        'bi-file-earmark-lock2-fill',
        'bi-file-earmark-break',
        'bi-file-earmark-break-fill',
        'bi-file-earmark-bar-graph',
        'bi-file-earmark-bar-graph-fill',
        'bi-file-earmark-spreadsheet',
        'bi-file-earmark-spreadsheet-fill',
        'bi-file-earmark-person',
        'bi-file-earmark-person-fill',
        'bi-file-earmark-medical',
        'bi-file-earmark-medical-fill',
        'bi-file-earmark-post',
        'bi-file-earmark-post-fill',
        'bi-file-earmark-arrow-up',
        'bi-file-earmark-arrow-up-fill',
        'bi-file-earmark-arrow-down',
        'bi-file-earmark-arrow-down-fill',
        'bi-file-earmark-image',
        'bi-file-earmark-image-fill',
        'bi-file-earmark-music',
        'bi-file-earmark-music-fill',
        'bi-file-earmark-play',
        'bi-file-earmark-play-fill',
        'bi-file-earmark-slides',
        'bi-file-earmark-slides-fill',
        'bi-file-earmark-font',
        'bi-file-earmark-font-fill',
        'bi-file-earmark-zip',
        'bi-file-earmark-zip-fill',
        'bi-file-earmark-pdf',
        'bi-file-earmark-pdf-fill',
        'bi-file-earmark-word',
        'bi-file-earmark-word-fill',
        'bi-file-earmark-excel',
        'bi-file-earmark-excel-fill',
        'bi-file-earmark-ppt',
        'bi-file-earmark-ppt-fill',

        // ── File Stacks ──
        'bi-files',
        'bi-files-alt',
        'bi-file-zip',
        'bi-file-zip-fill',
        'bi-file-pdf',
        'bi-file-pdf-fill',
        'bi-file-word',
        'bi-file-word-fill',
        'bi-file-excel',
        'bi-file-excel-fill',
        'bi-file-ppt',
        'bi-file-ppt-fill',
        'bi-file-image',
        'bi-file-image-fill',
        'bi-file-music',
        'bi-file-music-fill',
        'bi-file-play',
        'bi-file-play-fill',
        'bi-file-slides',
        'bi-file-slides-fill',
        'bi-file-font',
        'bi-file-font-fill',
        'bi-file-spreadsheet',
        'bi-file-spreadsheet-fill',
        'bi-file-arrow-up',
        'bi-file-arrow-up-fill',
        'bi-file-arrow-down',
        'bi-file-arrow-down-fill',

        // ── Clipboard & Journals ──
        'bi-clipboard',
        'bi-clipboard-fill',
        'bi-clipboard-data',
        'bi-clipboard-data-fill',
        'bi-clipboard-check',
        'bi-clipboard-check-fill',
        'bi-clipboard-plus',
        'bi-clipboard-plus-fill',
        'bi-clipboard-minus',
        'bi-clipboard-minus-fill',
        'bi-clipboard-x',
        'bi-clipboard-x-fill',
        'bi-clipboard-heart',
        'bi-clipboard-heart-fill',
        'bi-clipboard-pulse',
        'bi-clipboard2',
        'bi-clipboard2-data',
        'bi-clipboard2-check',
        'bi-clipboard2-plus',
        'bi-journal',
        'bi-journal-text',
        'bi-journal-check',
        'bi-journal-richtext',
        'bi-journal-album',
        'bi-journal-bookmark',
        'bi-journal-bookmark-fill',
        'bi-journal-medical',
        'bi-journals',

        // ── Books & Reading ──
        'bi-book',
        'bi-book-fill',
        'bi-book-half',
        'bi-bookmark',
        'bi-bookmark-fill',
        'bi-bookmark-star',
        'bi-bookmark-star-fill',
        'bi-bookmark-check',
        'bi-bookmark-check-fill',
        'bi-bookmark-heart',
        'bi-bookmark-heart-fill',
        'bi-bookmarks',
        'bi-bookmarks-fill',
        'bi-bookshelf',

        // ── Finance & Commerce ──
        'bi-wallet',
        'bi-wallet-fill',
        'bi-wallet2',
        'bi-cash',
        'bi-cash-coin',
        'bi-cash-stack',
        'bi-currency-dollar',
        'bi-currency-euro',
        'bi-currency-exchange',
        'bi-bank',
        'bi-bank2',
        'bi-piggy-bank',
        'bi-piggy-bank-fill',
        'bi-credit-card',
        'bi-credit-card-fill',
        'bi-credit-card-2-front',
        'bi-credit-card-2-front-fill',
        'bi-receipt',
        'bi-receipt-cutoff',
        'bi-safe',
        'bi-safe-fill',
        'bi-safe2',
        'bi-safe2-fill',
        'bi-coin',
        'bi-tags',
        'bi-tags-fill',
        'bi-tag',
        'bi-tag-fill',

        // ── Security & Privacy ──
        'bi-shield',
        'bi-shield-check',
        'bi-shield-lock',
        'bi-shield-lock-fill',
        'bi-shield-fill-check',
        'bi-shield-exclamation',
        'bi-shield-fill-exclamation',
        'bi-shield-slash',
        'bi-lock',
        'bi-lock-fill',
        'bi-unlock',
        'bi-unlock-fill',
        'bi-key',
        'bi-key-fill',
        'bi-fingerprint',
        'bi-incognito',
        'bi-eye',
        'bi-eye-fill',
        'bi-eye-slash',
        'bi-eye-slash-fill',

        // ── People & Users ──
        'bi-person',
        'bi-person-fill',
        'bi-person-circle',
        'bi-person-badge',
        'bi-person-badge-fill',
        'bi-person-lines-fill',
        'bi-person-vcard',
        'bi-person-vcard-fill',
        'bi-person-gear',
        'bi-person-check',
        'bi-person-check-fill',
        'bi-person-dash',
        'bi-person-plus',
        'bi-person-plus-fill',
        'bi-person-lock',
        'bi-person-workspace',
        'bi-people',
        'bi-people-fill',
        'bi-person-rolodex',

        // ── Settings & Tools ──
        'bi-gear',
        'bi-gear-fill',
        'bi-gear-wide',
        'bi-gear-wide-connected',
        'bi-sliders',
        'bi-sliders2',
        'bi-sliders2-vertical',
        'bi-wrench',
        'bi-wrench-adjustable',
        'bi-wrench-adjustable-circle',
        'bi-tools',
        'bi-hammer',
        'bi-nut',
        'bi-nut-fill',
        'bi-screwdriver',
        'bi-funnel',
        'bi-funnel-fill',
        'bi-filter',
        'bi-toggles',
        'bi-toggles2',

        // ── Business & Buildings ──
        'bi-briefcase',
        'bi-briefcase-fill',
        'bi-building',
        'bi-building-fill',
        'bi-building-gear',
        'bi-buildings',
        'bi-buildings-fill',
        'bi-shop',
        'bi-shop-window',
        'bi-hospital',
        'bi-hospital-fill',

        // ── Tables, Lists & Data ──
        'bi-table',
        'bi-list-ul',
        'bi-list-ol',
        'bi-list-check',
        'bi-list-task',
        'bi-list-nested',
        'bi-list-stars',
        'bi-kanban',
        'bi-kanban-fill',
        'bi-view-list',
        'bi-view-stacked',
        'bi-ui-checks',
        'bi-ui-checks-grid',
        'bi-ui-radios',

        // ── Charts & Analytics ──
        'bi-pie-chart',
        'bi-pie-chart-fill',
        'bi-bar-chart',
        'bi-bar-chart-fill',
        'bi-bar-chart-line',
        'bi-bar-chart-line-fill',
        'bi-bar-chart-steps',
        'bi-graph-up',
        'bi-graph-up-arrow',
        'bi-graph-down',
        'bi-graph-down-arrow',
        'bi-activity',
        'bi-diagram-3',
        'bi-diagram-3-fill',
        'bi-diagram-2',
        'bi-diagram-2-fill',

        // ── Shipping & Commerce ──
        'bi-truck',
        'bi-truck-front',
        'bi-truck-front-fill',
        'bi-truck-flatbed',
        'bi-cart',
        'bi-cart-fill',
        'bi-cart-check',
        'bi-cart-check-fill',
        'bi-cart-plus',
        'bi-cart-plus-fill',
        'bi-cart3',
        'bi-bag',
        'bi-bag-fill',
        'bi-bag-check',
        'bi-bag-check-fill',
        'bi-bag-heart',
        'bi-bag-heart-fill',
        'bi-basket',
        'bi-basket-fill',
        'bi-basket2',
        'bi-basket2-fill',
        'bi-basket3',
        'bi-basket3-fill',

        // ── Communication ──
        'bi-envelope',
        'bi-envelope-fill',
        'bi-envelope-open',
        'bi-envelope-open-fill',
        'bi-envelope-paper',
        'bi-envelope-paper-fill',
        'bi-chat-square-text',
        'bi-chat-square-text-fill',
        'bi-chat-left-text',
        'bi-chat-left-text-fill',
        'bi-chat-dots',
        'bi-chat-dots-fill',
        'bi-chat-quote',
        'bi-chat-quote-fill',
        'bi-send',
        'bi-send-fill',
        'bi-send-check',
        'bi-send-check-fill',
        'bi-mailbox',
        'bi-mailbox2',
        'bi-megaphone',
        'bi-megaphone-fill',
        'bi-telephone',
        'bi-telephone-fill',
        'bi-telephone-inbound',
        'bi-telephone-inbound-fill',
        'bi-telephone-outbound',
        'bi-telephone-outbound-fill',
        'bi-telephone-forward',
        'bi-telephone-forward-fill',
        'bi-headset',

        // ── Globe & Web ──
        'bi-globe',
        'bi-globe2',
        'bi-globe-americas',
        'bi-globe-europe-africa',
        'bi-translate',
        'bi-link',
        'bi-link-45deg',
        'bi-share',
        'bi-share-fill',
        'bi-rss',
        'bi-rss-fill',
        'bi-wifi',
        'bi-broadcast',

        // ── Time & Calendar ──
        'bi-calendar',
        'bi-calendar-fill',
        'bi-calendar-event',
        'bi-calendar-event-fill',
        'bi-calendar-check',
        'bi-calendar-check-fill',
        'bi-calendar-plus',
        'bi-calendar-plus-fill',
        'bi-calendar-minus',
        'bi-calendar-minus-fill',
        'bi-calendar-week',
        'bi-calendar-week-fill',
        'bi-calendar-range',
        'bi-calendar-range-fill',
        'bi-calendar-date',
        'bi-calendar-date-fill',
        'bi-clock',
        'bi-clock-fill',
        'bi-clock-history',
        'bi-hourglass',
        'bi-hourglass-split',
        'bi-stopwatch',
        'bi-stopwatch-fill',
        'bi-alarm',
        'bi-alarm-fill',

        // ── Notifications & Status ──
        'bi-bell',
        'bi-bell-fill',
        'bi-bell-slash',
        'bi-bell-slash-fill',
        'bi-star',
        'bi-star-fill',
        'bi-star-half',
        'bi-heart',
        'bi-heart-fill',
        'bi-check-circle',
        'bi-check-circle-fill',
        'bi-check-square',
        'bi-check-square-fill',
        'bi-x-circle',
        'bi-x-circle-fill',
        'bi-exclamation-triangle',
        'bi-exclamation-triangle-fill',
        'bi-exclamation-circle',
        'bi-exclamation-circle-fill',
        'bi-info-circle',
        'bi-info-circle-fill',
        'bi-question-circle',
        'bi-question-circle-fill',
        'bi-flag',
        'bi-flag-fill',
        'bi-patch-check',
        'bi-patch-check-fill',

        // ── Arrows & Navigation ──
        'bi-arrow-left-right',
        'bi-arrow-repeat',
        'bi-arrow-clockwise',
        'bi-arrow-counterclockwise',
        'bi-arrow-up-right-square',
        'bi-box-arrow-up-right',
        'bi-box-arrow-in-right',
        'bi-signpost',
        'bi-signpost-fill',
        'bi-signpost-split',
        'bi-signpost-split-fill',
        'bi-sign-turn-right',
        'bi-compass',
        'bi-compass-fill',

        // ── Database & Server ──
        'bi-database',
        'bi-database-fill',
        'bi-database-gear',
        'bi-database-check',
        'bi-database-add',
        'bi-database-lock',
        'bi-database-up',
        'bi-database-down',
        'bi-server',
        'bi-hdd',
        'bi-hdd-fill',
        'bi-hdd-stack',
        'bi-hdd-stack-fill',
        'bi-hdd-network',
        'bi-hdd-network-fill',

        // ── Devices ──
        'bi-pc-display',
        'bi-pc-display-horizontal',
        'bi-laptop',
        'bi-laptop-fill',
        'bi-phone',
        'bi-phone-fill',
        'bi-tablet',
        'bi-tablet-fill',
        'bi-printer',
        'bi-printer-fill',
        'bi-projector',
        'bi-projector-fill',
        'bi-cpu',
        'bi-cpu-fill',
        'bi-gpu-card',
        'bi-motherboard',
        'bi-motherboard-fill',
        'bi-usb-drive',
        'bi-usb-drive-fill',
        'bi-disc',
        'bi-disc-fill',

        // ── Media & Images ──
        'bi-image',
        'bi-image-fill',
        'bi-images',
        'bi-camera',
        'bi-camera-fill',
        'bi-camera-video',
        'bi-camera-video-fill',
        'bi-film',
        'bi-play-circle',
        'bi-play-circle-fill',
        'bi-music-note',
        'bi-music-note-beamed',
        'bi-music-note-list',
        'bi-mic',
        'bi-mic-fill',
        'bi-volume-up',
        'bi-volume-up-fill',
        'bi-easel',
        'bi-easel-fill',
        'bi-palette',
        'bi-palette-fill',
        'bi-brush',
        'bi-brush-fill',
        'bi-pen',
        'bi-pen-fill',
        'bi-pencil-square',
        'bi-vector-pen',

        // ── Map & Location ──
        'bi-geo',
        'bi-geo-alt',
        'bi-geo-alt-fill',
        'bi-geo-fill',
        'bi-pin',
        'bi-pin-fill',
        'bi-pin-map',
        'bi-pin-map-fill',
        'bi-map',
        'bi-map-fill',

        // ── Weather & Nature ──
        'bi-sun',
        'bi-sun-fill',
        'bi-moon',
        'bi-moon-fill',
        'bi-cloud',
        'bi-cloud-fill',
        'bi-cloud-sun',
        'bi-cloud-sun-fill',
        'bi-tree',
        'bi-tree-fill',
        'bi-flower1',
        'bi-flower2',
        'bi-water',
        'bi-droplet',
        'bi-droplet-fill',

        // ── Health & Science ──
        'bi-heart-pulse',
        'bi-heart-pulse-fill',
        'bi-bandaid',
        'bi-bandaid-fill',
        'bi-capsule',
        'bi-prescription2',
        'bi-virus',
        'bi-virus2',
        'bi-lungs',
        'bi-lungs-fill',
        'bi-radioactive',
        'bi-binoculars',
        'bi-binoculars-fill',
        'bi-search',
        'bi-search-heart',
        'bi-zoom-in',
        'bi-zoom-out',

        // ── Misc & Math ──
        'bi-calculator',
        'bi-calculator-fill',
        'bi-percent',
        'bi-hash',
        'bi-puzzle',
        'bi-puzzle-fill',
        'bi-trophy',
        'bi-trophy-fill',
        'bi-award',
        'bi-award-fill',
        'bi-lightning',
        'bi-lightning-fill',
        'bi-lightning-charge',
        'bi-lightning-charge-fill',
        'bi-magic',
        'bi-rocket',
        'bi-rocket-fill',
        'bi-rocket-takeoff',
        'bi-rocket-takeoff-fill',
        'bi-hand-thumbs-up',
        'bi-hand-thumbs-up-fill',
        'bi-emoji-smile',
        'bi-emoji-smile-fill',
        'bi-cup-hot',
        'bi-cup-hot-fill',
        'bi-bullseye',
        'bi-clipboard2-pulse',
        'bi-clipboard2-pulse-fill',
        'bi-qr-code',
        'bi-qr-code-scan',
        'bi-upc-scan',
        'bi-bug',
        'bi-bug-fill',
        'bi-code-slash',
        'bi-braces',
        'bi-terminal',
        'bi-terminal-fill',
        'bi-plugin',
        'bi-plug',
        'bi-plug-fill',
        'bi-power',
        'bi-recycle',
        'bi-trash',
        'bi-trash3',
        'bi-trash3-fill',
    ];

    function t(key, fallback) {
        if (window.__MS_TRANS && typeof window.__MS_TRANS[key] === 'string' && window.__MS_TRANS[key]) {
            return window.__MS_TRANS[key];
        }
        return fallback;
    }

    function parseJson(text, fallback) {
        try {
            return JSON.parse(text || '');
        } catch (err) {
            return fallback;
        }
    }

    function readSetupState() {
        try {
            return parseJson(sessionStorage.getItem(SETUP_STATE_KEY), null);
        } catch (err) {
            return null;
        }
    }

    function persistSetupFormState(form) {
        if (!form || !form.classList.contains('ms-system-setup-form')) {
            return;
        }

        const state = {
            path: window.location.pathname,
            values: {},
            currentStep: 0,
        };

        const steps = Array.from(form.querySelectorAll('.wizard-step'));
        const visibleStepIndex = steps.findIndex((step) => window.getComputedStyle(step).display !== 'none');
        if (visibleStepIndex >= 0) {
            state.currentStep = visibleStepIndex;
        }

        form.querySelectorAll('input[name], select[name], textarea[name]').forEach((field) => {
            if (!field.name || field.name === 'csrfmiddlewaretoken' || field.disabled || field.type === 'file') {
                return;
            }

            if (field.type === 'radio') {
                if (field.checked) {
                    state.values[field.name] = field.value;
                }
                return;
            }

            if (field.type === 'checkbox') {
                state.values[field.name] = Boolean(field.checked);
                return;
            }

            state.values[field.name] = field.value;
        });

        sessionStorage.setItem(SETUP_STATE_KEY, JSON.stringify(state));
    }

    function restoreSetupFormState(root) {
        root.querySelectorAll('form.ms-system-setup-form').forEach((form) => {
            if (form.dataset.setupStateRestored === 'true') {
                return;
            }
            form.dataset.setupStateRestored = 'true';

            const state = readSetupState();
            if (!state || state.path !== window.location.pathname || !state.values || typeof state.values !== 'object') {
                return;
            }

            Object.entries(state.values).forEach(([name, value]) => {
                const safeName = String(name).replace(/"/g, '\\"');
                const fields = Array.from(form.querySelectorAll(`[name="${safeName}"]`));
                if (!fields.length) {
                    return;
                }

                if (fields[0].type === 'radio') {
                    fields.forEach((field) => {
                        field.checked = field.value === value;
                    });
                    return;
                }

                fields.forEach((field) => {
                    if (field.type === 'checkbox') {
                        field.checked = Boolean(value);
                    } else if (field.type !== 'file') {
                        field.value = value;
                    }
                });
            });

            if (Number.isInteger(state.currentStep) && state.currentStep >= 0) {
                form.dataset.msWizardInitialStep = String(state.currentStep);
            }

            sessionStorage.removeItem(SETUP_STATE_KEY);
        });
    }

    window.__msGetWizardInitialStep = function (container) {
        const form = container && (container.matches && container.matches('form') ? container : container.closest && container.closest('form'));
        if (!form || !form.classList.contains('ms-system-setup-form')) {
            return null;
        }
        const state = readSetupState();
        if (!state || state.path !== window.location.pathname) {
            return null;
        }
        return Number.isInteger(state.currentStep) ? state.currentStep : null;
    };

    function humanizeKey(value) {
        return String(value || '')
            .split(':')
            .pop()
            .replace(/[_-]+/g, ' ')
            .replace(/\b\w/g, (char) => char.toUpperCase())
            .trim();
    }

    function availableItemDisplayLabel(item) {
        const label = String(item && item.label ? item.label : '').trim();
        const groupLabel = String(item && item.group_label ? item.group_label : '').trim();
        const urlName = String(item && item.url_name ? item.url_name : item && item.id ? item.id : '').trim();
        const leaf = urlName.split(':').pop();

        if (label && label !== groupLabel) {
            return label;
        }
        if (leaf === 'dashboard' && groupLabel) {
            return `${groupLabel} Dashboard`;
        }
        return humanizeKey(urlName) || groupLabel || t('sidebar_group_label', 'Item');
    }

    function normalizeCatalog(catalog) {
        if (!Array.isArray(catalog)) {
            return [];
        }
        return catalog
            .filter(entry => entry && entry.id && entry.url_name)
            .map(entry => ({
                kind: 'item',
                id: entry.id,
                url_name: entry.url_name,
                label: entry.label || entry.id,
                icon: entry.icon || 'bi-link-45deg',
                permissions: Array.isArray(entry.permissions) ? entry.permissions : [],
                group_key: entry.group_key || 'general',
                group_label: entry.group_label || entry.group_key || 'General',
                group_icon: entry.group_icon || 'bi-folder2-open',
                is_system: Boolean(entry.is_system),
            }));
    }

    function buildCatalogLookup(catalog) {
        const lookup = new Map();
        (catalog || []).forEach((entry) => {
            if (!entry || typeof entry !== 'object') {
                return;
            }
            const id = String(entry.id || '').trim();
            const urlName = String(entry.url_name || '').trim();
            if (id) {
                lookup.set(id, entry);
            }
            if (urlName) {
                lookup.set(urlName, entry);
            }
        });
        return lookup;
    }

    function findCatalogEntry(entry, catalogLookup) {
        if (!entry || typeof entry !== 'object' || !catalogLookup) {
            return null;
        }
        const id = String(entry.id || '').trim();
        const urlName = String(entry.url_name || '').trim();
        return catalogLookup.get(id) || catalogLookup.get(urlName) || null;
    }

    function frameworkDefaultLabels(entry, discovered) {
        const labels = new Set();
        const candidates = [
            entry && entry.id,
            entry && entry.url_name,
            discovered && discovered.label,
            discovered && discovered.group_label,
            discovered && discovered.id,
            discovered && discovered.url_name,
        ];

        candidates.forEach((candidate) => {
            const value = String(candidate || '').trim();
            if (value) {
                labels.add(value);
            }
        });

        const humanized = humanizeKey((entry && (entry.url_name || entry.id)) || (discovered && (discovered.url_name || discovered.id)) || '');
        if (humanized) {
            labels.add(humanized);
        }

        if (discovered) {
            const displayLabel = availableItemDisplayLabel(discovered);
            if (displayLabel) {
                labels.add(displayLabel);
            }
        }

        return labels;
    }

    function resolveBuilderItemLabel(entry, currentDiscovered, fallbackDiscovered) {
        const savedLabel = String(entry && entry.label ? entry.label : '').trim();
        const localizedLabel = currentDiscovered ? availableItemDisplayLabel(currentDiscovered) : '';
        const defaultLabels = new Set([
            ...frameworkDefaultLabels(entry, currentDiscovered),
            ...frameworkDefaultLabels(entry, fallbackDiscovered),
        ]);

        if (!savedLabel || defaultLabels.has(savedLabel)) {
            return localizedLabel || savedLabel || String(entry && (entry.url_name || entry.id) ? (entry.url_name || entry.id) : '').trim();
        }

        return savedLabel;
    }

    function resolveBuilderGroupLabel(entry, items, fallbackCatalogLookup) {
        const savedLabel = String(entry && entry.label ? entry.label : '').trim();
        const localizedLabel = String(
            (items || []).find((item) => String(item && item.group_label ? item.group_label : '').trim())?.group_label || ''
        ).trim();
        const fallbackReference = findCatalogEntry(((entry && entry.items) || []).find((item) => item && (item.id || item.url_name)), fallbackCatalogLookup);
        const fallbackGroupLabel = String(fallbackReference && fallbackReference.group_label ? fallbackReference.group_label : '').trim();
        const defaultLabels = new Set([
            fallbackGroupLabel,
            t('sidebar_group_label', 'Group'),
            'Group',
        ]);

        if (!savedLabel || (localizedLabel && defaultLabels.has(savedLabel))) {
            return localizedLabel || savedLabel || t('sidebar_group_label', 'Group');
        }

        return savedLabel;
    }

    function normalizeSidebarConfig(config, catalogLookup, fallbackCatalogLookup) {
        if (!config || typeof config !== 'object') {
            return { home_url_name: null, entries: [] };
        }

        const entries = Array.isArray(config.entries) ? config.entries : [];
        return {
            home_url_name: config.home_url_name || null,
            entries: entries.map(entry => normalizeEntry(entry, catalogLookup, fallbackCatalogLookup)).filter(Boolean),
        };
    }

    function normalizeEntry(entry, catalogLookup, fallbackCatalogLookup) {
        if (!entry || typeof entry !== 'object') {
            return null;
        }
        if ((entry.kind || 'item') === 'group') {
            const items = Array.isArray(entry.items)
                ? entry.items.map(item => normalizeEntry(item, catalogLookup, fallbackCatalogLookup)).filter(Boolean)
                : [];
            return {
                kind: 'group',
                id: entry.id || `group-${Date.now()}`,
                label: resolveBuilderGroupLabel(entry, items, fallbackCatalogLookup),
                icon: entry.icon || 'bi-folder2-open',
                items,
            };
        }
        if (!entry.id && !entry.url_name) {
            return null;
        }
        const currentDiscovered = findCatalogEntry(entry, catalogLookup);
        const fallbackDiscovered = findCatalogEntry(entry, fallbackCatalogLookup);
        return {
            kind: 'item',
            id: entry.id || entry.url_name,
            url_name: entry.url_name || entry.id,
            label: resolveBuilderItemLabel(entry, currentDiscovered, fallbackDiscovered),
            icon: entry.icon || (currentDiscovered && currentDiscovered.icon) || 'bi-link-45deg',
            permissions: Array.isArray(entry.permissions) ? entry.permissions : ((currentDiscovered && currentDiscovered.permissions) || []),
            group_key: entry.group_key || (currentDiscovered && currentDiscovered.group_key) || '',
            group_label: entry.group_label || (currentDiscovered && currentDiscovered.group_label) || '',
        };
    }

    function cloneEntry(entry) {
        return JSON.parse(JSON.stringify(entry));
    }

    function cloneGroupEntry(group) {
        const items = Array.isArray(group && group.items) ? group.items.map(cloneEntry) : [];
        const label = String(group && group.label ? group.label : '').trim() || t('sidebar_group_label', 'Group');
        return {
            kind: 'group',
            id: makeGroupId(group && (group.id || group.group_key || label || 'group')),
            label,
            icon: group && group.icon ? group.icon : 'bi-folder2-open',
            items,
        };
    }

    function makeGroupId(label) {
        const safeLabel = (label || 'group').toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]+/g, '').replace(/-+/g, '-');
        return `${safeLabel || 'group'}-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    }

    function collectSelectedItemIds(entries, acc) {
        acc = acc || new Set();
        (entries || []).forEach(entry => {
            if (entry.kind === 'group') {
                collectSelectedItemIds(entry.items || [], acc);
                return;
            }
            if (entry.id) {
                acc.add(entry.id);
            }
        });
        return acc;
    }

    function availableItems(state) {
        const selectedIds = collectSelectedItemIds(state.config.entries);
        return state.catalog.filter(item => !selectedIds.has(item.id) && (state.showSystemItems || !item.is_system));
    }

    function groupedAvailableItems(state) {
        const grouped = {};
        availableItems(state)
            .filter(item => {
                if (!state.search) return true;
                const haystack = `${item.label} ${item.group_label} ${item.url_name}`.toLowerCase();
                return haystack.includes(state.search.toLowerCase());
            })
            .forEach(item => {
                const key = item.group_key || item.group_label || 'general';
                if (!grouped[key]) {
                    grouped[key] = {
                        kind: 'group',
                        id: key,
                        label: item.group_label || key,
                        icon: item.group_icon || 'bi-folder2-open',
                        items: [],
                    };
                }
                grouped[key].items.push(item);
            });

        return Object.values(grouped).sort((left, right) => left.label.localeCompare(right.label));
    }

    function findEntryLocation(entries, id, kind) {
        for (let index = 0; index < entries.length; index += 1) {
            const entry = entries[index];
            if (entry.kind === kind && entry.id === id) {
                return { parent: entries, index, entry, container: 'root' };
            }
            if (entry.kind === 'group') {
                if (kind === 'group' && entry.id === id) {
                    return { parent: entries, index, entry, container: 'root' };
                }
                const childIndex = (entry.items || []).findIndex(item => item.id === id && item.kind === kind);
                if (childIndex !== -1) {
                    return { parent: entry.items, index: childIndex, entry: entry.items[childIndex], container: 'group', group: entry };
                }
            }
        }
        return null;
    }

    function insertEntryIntoConfig(configEntries, entry, target) {
        if (target.type === 'root-container') {
            configEntries.push(entry);
            return;
        }

        if (target.type === 'group-container') {
            const groupLocation = findEntryLocation(configEntries, target.groupId, 'group');
            if (groupLocation && groupLocation.entry.kind === 'group') {
                groupLocation.entry.items.push(entry);
            } else {
                configEntries.push(entry);
            }
            return;
        }

        if (target.type === 'root-node') {
            const targetLocation = findEntryLocation(configEntries, target.targetId, target.targetKind);
            if (!targetLocation) {
                configEntries.push(entry);
            } else {
                const insertIndex = target.before ? targetLocation.index : targetLocation.index + 1;
                configEntries.splice(insertIndex, 0, entry);
            }
            return;
        }

        if (target.type === 'group-node') {
            const groupLocation = findEntryLocation(configEntries, target.parentGroupId, 'group');
            if (!groupLocation || groupLocation.entry.kind !== 'group') {
                configEntries.push(entry);
                return;
            }
            const targetLocation = findEntryLocation(groupLocation.entry.items, target.targetId, target.targetKind);
            if (!targetLocation) {
                groupLocation.entry.items.push(entry);
            } else {
                const insertIndex = target.before ? targetLocation.index : targetLocation.index + 1;
                groupLocation.entry.items.splice(insertIndex, 0, entry);
            }
        }
    }

    function topLevelItems(entries) {
        return (entries || []).filter(entry => entry.kind === 'item' && entry.url_name);
    }

    function initBuilder(builder) {
        if (!builder || builder.dataset.builderBound === 'true') {
            return;
        }
        builder.dataset.builderBound = 'true';

        const form = builder.closest('form');
        const hiddenInput = form ? form.querySelector('input[name="sidebar_config"]') : null;
        if (!hiddenInput) {
            return;
        }

        const catalogData = builder.querySelector('.ms-sidebar-catalog-data');
        const fallbackCatalogData = builder.querySelector('.ms-sidebar-catalog-fallback-data');
        const configData = builder.querySelector('.ms-sidebar-config-data');
        const catalog = normalizeCatalog(parseJson(catalogData ? catalogData.value : '[]', []));
        const fallbackCatalog = normalizeCatalog(parseJson(fallbackCatalogData ? fallbackCatalogData.value : '[]', []));
        const catalogLookup = buildCatalogLookup(catalog);
        const fallbackCatalogLookup = buildCatalogLookup(fallbackCatalog);
        const state = {
            catalog,
            config: normalizeSidebarConfig(
                parseJson(hiddenInput.value || (configData ? configData.value : '{}'), {}),
                catalogLookup,
                fallbackCatalogLookup
            ),
            selected: null,
            selectedTargetGroup: null,
            search: '',
            dragging: null,
            showSystemItems: false,
            iconSearch: '',
        };

        const refs = {
            selectedTree: builder.querySelector('[data-builder-selected-tree]'),
            availableList: builder.querySelector('[data-builder-available-list]'),
            search: builder.querySelector('[data-builder-search]'),
            systemToggle: builder.querySelector('[data-builder-system-toggle]'),
            inspector: builder.querySelector('[data-builder-inspector]'),
            inspectorEmpty: builder.querySelector('[data-builder-empty-inspector]'),
            labelInput: builder.querySelector('[data-builder-label-input]'),
            iconInput: builder.querySelector('[data-builder-icon-input]'),
            iconPreview: builder.querySelector('[data-builder-icon-preview]'),
            iconSuggestions: builder.querySelector('[data-builder-icon-suggestions]'),
            iconSearch: builder.querySelector('[data-builder-icon-search]'),
        };

        function clearDragFeedback() {
            builder.querySelectorAll('.ms-builder-drop-target').forEach(el => el.classList.remove('ms-builder-drop-target'));
            builder.querySelectorAll('.ms-builder-drop-before').forEach(el => el.classList.remove('ms-builder-drop-before'));
            builder.querySelectorAll('.ms-builder-drop-after').forEach(el => el.classList.remove('ms-builder-drop-after'));
            builder.querySelectorAll('.is-dragging').forEach(el => el.classList.remove('is-dragging'));
        }

        function serialize() {
            hiddenInput.value = JSON.stringify(state.config);
        }

        function renderAvailable() {
            refs.availableList.innerHTML = '';

            groupedAvailableItems(state).forEach(group => {
                const section = document.createElement('div');
                section.className = 'ms-builder-available-group';
                const groupButton = document.createElement('button');
                groupButton.type = 'button';
                groupButton.className = 'ms-builder-item available-item fw-semibold';
                groupButton.dataset.pane = 'available';
                groupButton.dataset.entryId = group.id;
                groupButton.dataset.entryKind = 'group';
                if (state.selected && state.selected.pane === 'available' && state.selected.kind === 'group' && state.selected.id === group.id) {
                    groupButton.classList.add('is-active');
                }
                groupButton.innerHTML = `
                    <span class="ms-builder-item-main">
                        <i class="bi ${group.icon}"></i>
                        <span>${group.label}</span>
                    </span>
                    <span class="badge text-bg-light">${group.items.length}</span>
                `;
                groupButton.addEventListener('click', () => {
                    state.selected = { pane: 'available', id: group.id, kind: 'group' };
                    state.selectedTargetGroup = null;
                    renderAll();
                });
                groupButton.addEventListener('dblclick', () => {
                    addSelectedAvailableItem();
                });
                groupButton.draggable = true;
                groupButton.addEventListener('dragstart', () => {
                    state.dragging = { pane: 'available', id: group.id, kind: 'group' };
                    groupButton.classList.add('is-dragging');
                });
                groupButton.addEventListener('dragend', () => {
                    state.dragging = null;
                    clearDragFeedback();
                });
                section.appendChild(groupButton);

                const children = document.createElement('div');
                children.className = 'ms-builder-available-items';

                group.items.forEach(item => {
                    const button = document.createElement('button');
                    button.type = 'button';
                    button.className = 'ms-builder-item available-item is-child';
                    button.dataset.pane = 'available';
                    button.dataset.entryId = item.id;
                    button.dataset.entryKind = 'item';
                    if (state.selected && state.selected.pane === 'available' && state.selected.kind === 'item' && state.selected.id === item.id) {
                        button.classList.add('is-active');
                    }
                    button.innerHTML = `
                        <span class="ms-builder-item-main">
                            <i class="bi ${item.icon}"></i>
                            <span class="ms-builder-item-copy">
                                <span class="ms-builder-item-label">${availableItemDisplayLabel(item)}</span>
                                <span class="ms-builder-item-meta">${item.url_name || item.id}</span>
                            </span>
                        </span>
                    `;
                    button.addEventListener('click', () => {
                        state.selected = { pane: 'available', id: item.id, kind: 'item' };
                        state.selectedTargetGroup = null;
                        renderAll();
                    });
                    button.addEventListener('dblclick', () => {
                        addSelectedAvailableItem();
                    });
                    button.draggable = true;
                    button.addEventListener('dragstart', () => {
                        state.dragging = { pane: 'available', id: item.id, kind: 'item' };
                        button.classList.add('is-dragging');
                    });
                    button.addEventListener('dragend', () => {
                        state.dragging = null;
                        clearDragFeedback();
                    });
                    children.appendChild(button);
                });

                section.appendChild(children);

                refs.availableList.appendChild(section);
            });

            if (!refs.availableList.children.length) {
                refs.availableList.innerHTML = `<div class="text-muted small">${t('sidebar_no_available', 'No available entries match the current selection.')}</div>`;
            }
        }

        function makeNode(entry, parentGroupId) {
            const wrapper = document.createElement('div');
            wrapper.className = `ms-builder-node ${entry.kind === 'group' ? 'is-group' : 'is-item'}`;
            wrapper.dataset.entryId = entry.id;
            wrapper.dataset.entryKind = entry.kind;
            wrapper.draggable = true;

            if (state.selected && state.selected.pane === 'selected' && state.selected.id === entry.id && state.selected.kind === entry.kind) {
                wrapper.classList.add('is-active');
            }

            wrapper.addEventListener('click', (event) => {
                event.stopPropagation();
                state.selected = { pane: 'selected', id: entry.id, kind: entry.kind };
                state.selectedTargetGroup = entry.kind === 'group' ? entry.id : (parentGroupId || null);
                renderAll();
            });

            wrapper.addEventListener('dragstart', () => {
                state.dragging = { pane: 'selected', id: entry.id, kind: entry.kind };
                wrapper.classList.add('is-dragging');
            });

            wrapper.addEventListener('dragend', () => {
                state.dragging = null;
                clearDragFeedback();
            });

            wrapper.addEventListener('dragover', (event) => {
                if (!state.dragging) return;
                event.preventDefault();
                const rect = wrapper.getBoundingClientRect();
                const before = event.clientY < rect.top + rect.height / 2;
                wrapper.classList.toggle('ms-builder-drop-before', before);
                wrapper.classList.toggle('ms-builder-drop-after', !before);
            });

            wrapper.addEventListener('dragleave', () => {
                wrapper.classList.remove('ms-builder-drop-before', 'ms-builder-drop-after');
            });

            wrapper.addEventListener('drop', (event) => {
                if (!state.dragging) return;
                event.preventDefault();
                event.stopPropagation();
                const rect = wrapper.getBoundingClientRect();
                const before = event.clientY < rect.top + rect.height / 2;
                moveDraggedEntry({
                    type: parentGroupId ? 'group-node' : 'root-node',
                    targetId: entry.id,
                    targetKind: entry.kind,
                    before,
                    parentGroupId,
                });
            });

            if (entry.kind === 'group') {
                wrapper.innerHTML = `
                    <div class="ms-builder-group-header">
                        <span class="ms-builder-item-main">
                            <i class="bi ${entry.icon}"></i>
                            <span>${entry.label}</span>
                        </span>
                        <span class="badge text-bg-light">${(entry.items || []).length}</span>
                    </div>
                    <div class="ms-builder-group-items" data-group-dropzone="${entry.id}"></div>
                `;

                const itemsContainer = wrapper.querySelector('[data-group-dropzone]');
                itemsContainer.addEventListener('dragover', (event) => {
                    if (!state.dragging || state.dragging.kind !== 'item') return;
                    event.preventDefault();
                    itemsContainer.classList.add('ms-builder-drop-target');
                });
                itemsContainer.addEventListener('dragleave', () => {
                    itemsContainer.classList.remove('ms-builder-drop-target');
                });
                itemsContainer.addEventListener('drop', (event) => {
                    if (!state.dragging || state.dragging.kind !== 'item') return;
                    event.preventDefault();
                    event.stopPropagation();
                    moveDraggedEntry({ type: 'group-container', groupId: entry.id });
                });

                (entry.items || []).forEach(item => {
                    itemsContainer.appendChild(makeNode(item, entry.id));
                });
            } else {
                wrapper.innerHTML = `
                    <span class="ms-builder-item-main">
                        <i class="bi ${entry.icon}"></i>
                        <span>${entry.label}</span>
                    </span>
                    <span class="badge text-bg-light">${entry.url_name}</span>
                `;
            }

            return wrapper;
        }

        function renderSelected() {
            refs.selectedTree.innerHTML = '';

            state.config.entries.forEach(entry => {
                refs.selectedTree.appendChild(makeNode(entry, null));
            });

            if (!refs.selectedTree.children.length) {
                refs.selectedTree.innerHTML = `<div class="text-muted small">${t('sidebar_no_selected', 'No entries selected yet.')}</div>`;
            }
        }

        function renderInspector() {
            if (!state.selected || state.selected.pane !== 'selected') {
                refs.inspector.classList.add('d-none');
                refs.inspectorEmpty.classList.remove('d-none');
                return;
            }

            const location = findEntryLocation(state.config.entries, state.selected.id, state.selected.kind);
            if (!location) {
                refs.inspector.classList.add('d-none');
                refs.inspectorEmpty.classList.remove('d-none');
                return;
            }

            refs.inspector.classList.remove('d-none');
            refs.inspectorEmpty.classList.add('d-none');
            refs.labelInput.value = location.entry.label || '';
            refs.iconInput.value = location.entry.icon || '';
            refs.iconPreview.className = `bi ${location.entry.icon || 'bi-link-45deg'}`;
            refs.iconSuggestions.innerHTML = '';

            const iconFilter = (state.iconSearch || '').toLowerCase().replace(/\s+/g, '-');
            const filtered = iconFilter
                ? ICON_SUGGESTIONS.filter(icon => icon.includes(iconFilter))
                : ICON_SUGGESTIONS;

            if (refs.iconSearch && refs.iconSearch.value !== (state.iconSearch || '')) {
                refs.iconSearch.value = state.iconSearch || '';
            }

            filtered.forEach(icon => {
                const button = document.createElement('button');
                button.type = 'button';
                button.className = `btn btn-sm ms-builder-icon-choice ${location.entry.icon === icon ? 'is-active' : ''}`;
                button.setAttribute('title', icon);
                button.setAttribute('aria-label', icon);
                button.innerHTML = `<i class="bi ${icon}"></i>`;
                button.addEventListener('click', () => {
                    refs.iconInput.value = icon;
                    location.entry.icon = icon;
                    refs.iconPreview.className = `bi ${icon}`;
                    renderAll();
                });
                refs.iconSuggestions.appendChild(button);
            });

            if (!filtered.length) {
                refs.iconSuggestions.innerHTML = `<div class="text-muted small p-2">${t('sidebar_no_icons_found', 'No icons match your search.')}</div>`;
            }
        }

        function renderAll() {
            serialize();
            renderSelected();
            renderAvailable();
            renderInspector();
        }

        function addSelectedAvailableItem() {
            if (!state.selected || state.selected.pane !== 'available') return;
            if (state.selected.kind === 'group') {
                const sourceGroup = groupedAvailableItems(state).find(group => group.id === state.selected.id);
                if (!sourceGroup || !sourceGroup.items.length) return;
                const nextGroup = cloneGroupEntry(sourceGroup);
                nextGroup.items = nextGroup.items.map((item) => ({
                    ...item,
                    label: resolveBuilderItemLabel(item, findCatalogEntry(item, catalogLookup), findCatalogEntry(item, fallbackCatalogLookup)),
                }));
                nextGroup.label = resolveBuilderGroupLabel(nextGroup, nextGroup.items, fallbackCatalogLookup);
                state.config.entries.push(nextGroup);
                state.selected = { pane: 'selected', id: nextGroup.id, kind: 'group' };
                renderAll();
                return;
            }

            const source = state.catalog.find(item => item.id === state.selected.id);
            if (!source) return;
            const nextItem = cloneEntry(source);
            nextItem.label = resolveBuilderItemLabel(nextItem, source, findCatalogEntry(source, fallbackCatalogLookup));
            state.config.entries.push(nextItem);

            state.selected = { pane: 'selected', id: nextItem.id, kind: 'item' };
            renderAll();
        }

        function addAllAvailableItems() {
            const groups = groupedAvailableItems(state)
                .map((group) => {
                    const nextGroup = cloneGroupEntry(group);
                    nextGroup.items = nextGroup.items.map((item) => ({
                        ...item,
                        label: resolveBuilderItemLabel(item, findCatalogEntry(item, catalogLookup), findCatalogEntry(item, fallbackCatalogLookup)),
                    }));
                    nextGroup.label = resolveBuilderGroupLabel(nextGroup, nextGroup.items, fallbackCatalogLookup);
                    return nextGroup;
                })
                .filter(group => group.items.length);
            if (!groups.length) return;
            state.config.entries = state.config.entries.concat(groups);
            state.selected = null;
            state.selectedTargetGroup = null;
            renderAll();
        }

        function removeSelectedEntry() {
            if (!state.selected || state.selected.pane !== 'selected') return;
            const location = findEntryLocation(state.config.entries, state.selected.id, state.selected.kind);
            if (!location) return;
            location.parent.splice(location.index, 1);
            state.selected = null;
            renderAll();
        }

        function removeAllSelectedEntries() {
            state.config.entries = [];
            state.selected = null;
            state.selectedTargetGroup = null;
            renderAll();
        }

        function moveSelectedToRoot() {
            if (!state.selected || state.selected.pane !== 'selected' || state.selected.kind !== 'item') return;
            const location = findEntryLocation(state.config.entries, state.selected.id, 'item');
            if (!location || location.container !== 'group') return;
            const [entry] = location.parent.splice(location.index, 1);
            state.config.entries.push(entry);
            renderAll();
        }

        function addGroup() {
            const group = {
                kind: 'group',
                id: makeGroupId('group'),
                label: t('sidebar_new_group', 'New Group'),
                icon: 'bi-folder2-open',
                items: [],
            };
            state.config.entries.push(group);
            state.selected = { pane: 'selected', id: group.id, kind: 'group' };
            renderAll();
        }

        function duplicateSelectedEntry() {
            if (!state.selected || state.selected.pane !== 'selected' || state.selected.kind !== 'group') return;
            const location = findEntryLocation(state.config.entries, state.selected.id, 'group');
            if (!location) return;
            const duplicate = {
                kind: 'group',
                id: makeGroupId(location.entry.label),
                label: `${location.entry.label} ${t('sidebar_copy_suffix', 'Copy')}`,
                icon: location.entry.icon,
                items: [],
            };
            location.parent.splice(location.index + 1, 0, duplicate);
            state.selected = { pane: 'selected', id: duplicate.id, kind: 'group' };
            renderAll();
        }

        function moveDraggedEntry(target) {
            const dragging = state.dragging;
            if (!dragging) return;

            if (dragging.pane === 'available') {
                addDraggedAvailableEntry(target);
                return;
            }

            const source = findEntryLocation(state.config.entries, dragging.id, dragging.kind);
            if (!source) return;
            if (dragging.kind === 'group' && target.type !== 'root-container' && target.type !== 'root-node') {
                return;
            }

            const [entry] = source.parent.splice(source.index, 1);
            insertEntryIntoConfig(state.config.entries, entry, target);

            state.selected = { pane: 'selected', id: entry.id, kind: entry.kind };
            state.dragging = null;
            renderAll();
        }

        function addDraggedAvailableEntry(target) {
            const dragging = state.dragging;
            if (!dragging || dragging.pane !== 'available') return;

            if (dragging.kind === 'group') {
                if (target.type !== 'root-container' && target.type !== 'root-node') {
                    return;
                }
                const sourceGroup = groupedAvailableItems(state).find(group => group.id === dragging.id);
                if (!sourceGroup || !sourceGroup.items.length) return;
                const nextGroup = cloneGroupEntry(sourceGroup);
                nextGroup.items = nextGroup.items.map((item) => ({
                    ...item,
                    label: resolveBuilderItemLabel(item, findCatalogEntry(item, catalogLookup), findCatalogEntry(item, fallbackCatalogLookup)),
                }));
                nextGroup.label = resolveBuilderGroupLabel(nextGroup, nextGroup.items, fallbackCatalogLookup);
                insertEntryIntoConfig(state.config.entries, nextGroup, target);
                state.selected = { pane: 'selected', id: nextGroup.id, kind: 'group' };
            } else {
                const source = state.catalog.find(item => item.id === dragging.id);
                if (!source) return;
                const nextItem = cloneEntry(source);
                nextItem.label = resolveBuilderItemLabel(nextItem, source, findCatalogEntry(source, fallbackCatalogLookup));
                insertEntryIntoConfig(state.config.entries, nextItem, target);
                state.selected = { pane: 'selected', id: nextItem.id, kind: 'item' };
            }

            state.dragging = null;
            renderAll();
        }

        function removeDraggedSelectedEntry() {
            const dragging = state.dragging;
            if (!dragging || dragging.pane !== 'selected') return;
            const location = findEntryLocation(state.config.entries, dragging.id, dragging.kind);
            if (!location) return;
            location.parent.splice(location.index, 1);
            state.selected = null;
            state.selectedTargetGroup = null;
            state.dragging = null;
            renderAll();
        }

        refs.search.addEventListener('input', () => {
            state.search = refs.search.value || '';
            renderAvailable();
        });

        if (refs.iconSearch) {
            refs.iconSearch.addEventListener('input', () => {
                state.iconSearch = refs.iconSearch.value || '';
                renderInspector();
            });
        }

        if (refs.systemToggle) {
            refs.systemToggle.addEventListener('change', () => {
                state.showSystemItems = Boolean(refs.systemToggle.checked);
                if (!state.showSystemItems && state.selected && state.selected.pane === 'available') {
                    const selectedAvailableItem = state.catalog.find(item => item.id === state.selected.id);
                    if (
                        (state.selected.kind === 'group' && state.selected.id === 'microsys') ||
                        (selectedAvailableItem && selectedAvailableItem.is_system)
                    ) {
                        state.selected = null;
                    }
                }
                renderAvailable();
            });
        }

        refs.labelInput.addEventListener('input', () => {
            if (!state.selected || state.selected.pane !== 'selected') return;
            const location = findEntryLocation(state.config.entries, state.selected.id, state.selected.kind);
            if (!location) return;
            location.entry.label = refs.labelInput.value || '';
            serialize();
            renderSelected();
            renderAvailable();
        });

        refs.iconInput.addEventListener('input', () => {
            if (!state.selected || state.selected.pane !== 'selected') return;
            const location = findEntryLocation(state.config.entries, state.selected.id, state.selected.kind);
            if (!location) return;
            location.entry.icon = refs.iconInput.value || 'bi-link-45deg';
            refs.iconPreview.className = `bi ${location.entry.icon}`;
            serialize();
            renderSelected();
            renderAvailable();
            renderInspector();
        });

        refs.selectedTree.addEventListener('dragover', (event) => {
            if (!state.dragging) return;
            event.preventDefault();
            refs.selectedTree.classList.add('ms-builder-drop-target');
        });
        refs.selectedTree.addEventListener('dragleave', () => {
            refs.selectedTree.classList.remove('ms-builder-drop-target');
        });
        refs.selectedTree.addEventListener('drop', (event) => {
            if (!state.dragging) return;
            event.preventDefault();
            event.stopPropagation();
            moveDraggedEntry({ type: 'root-container' });
        });

        refs.availableList.addEventListener('dragover', (event) => {
            if (!state.dragging || state.dragging.pane !== 'selected') return;
            event.preventDefault();
            refs.availableList.classList.add('ms-builder-drop-target');
        });
        refs.availableList.addEventListener('dragleave', () => {
            refs.availableList.classList.remove('ms-builder-drop-target');
        });
        refs.availableList.addEventListener('drop', (event) => {
            if (!state.dragging || state.dragging.pane !== 'selected') return;
            event.preventDefault();
            event.stopPropagation();
            removeDraggedSelectedEntry();
        });

        builder.querySelectorAll('[data-builder-action]').forEach(button => {
            button.addEventListener('click', () => {
                const action = button.getAttribute('data-builder-action');
                if (action === 'add-selected') addSelectedAvailableItem();
                if (action === 'add-all') addAllAvailableItems();
                if (action === 'remove-selected') removeSelectedEntry();
                if (action === 'remove-all') removeAllSelectedEntries();
                if (action === 'move-root') moveSelectedToRoot();
                if (action === 'add-group') addGroup();
                if (action === 'duplicate-entry') duplicateSelectedEntry();
                if (action === 'delete-entry') removeSelectedEntry();
            });
        });

        renderAll();
    }

    function initSetupHomeFields(root) {
        root.querySelectorAll('form').forEach((form) => {
            if (form.dataset.setupHomeFieldsBound === 'true') {
                return;
            }

            const routeSelect = form.querySelector('[name="home_url_discovered"]');
            const urlInput = form.querySelector('[name="home_url"]');
            if (!routeSelect || !urlInput) {
                return;
            }

            form.dataset.setupHomeFieldsBound = 'true';

            const selectableValues = new Set(
                Array.from(routeSelect.options || [])
                    .map((option) => option.value)
                    .filter(Boolean)
            );

            function syncSelectFromInput() {
                const currentValue = (urlInput.value || '').trim();
                routeSelect.value = selectableValues.has(currentValue) ? currentValue : '';
            }

            routeSelect.addEventListener('change', () => {
                if (!routeSelect.value) {
                    return;
                }
                urlInput.value = routeSelect.value;
                urlInput.dispatchEvent(new Event('input', { bubbles: true }));
                urlInput.dispatchEvent(new Event('change', { bubbles: true }));
            });

            urlInput.addEventListener('input', syncSelectFromInput);
            urlInput.addEventListener('change', syncSelectFromInput);
            syncSelectFromInput();
        });
    }

    function initSetupLanguagePicker(root) {
        root.querySelectorAll('[data-setup-language-picker]').forEach((picker) => {
            if (picker.dataset.bound === 'true') return;
            picker.dataset.bound = 'true';

            const inputId = picker.getAttribute('data-language-input');
            const input = inputId ? document.getElementById(inputId) : null;
            const form = picker.closest('form');
            if (!input) return;

            const options = Array.from(picker.querySelectorAll('[data-setup-language-choice]'));

            function syncActive() {
                const activeLanguage = input.value || 'en';
                options.forEach((option) => {
                    option.classList.toggle('lang-active', option.getAttribute('data-setup-language-choice') === activeLanguage);
                });
            }

            options.forEach((option) => {
                option.addEventListener('click', () => {
                    const language = option.getAttribute('data-setup-language-choice') || 'en';
                    const currentLanguage = (window.USER_PREFS && window.USER_PREFS._lang) || 'en';
                    input.value = language;
                    input.dispatchEvent(new Event('change', { bubbles: true }));
                    syncActive();
                    if (language === currentLanguage) {
                        return;
                    }
                    persistSetupFormState(form);
                    if (window.setLanguage) {
                        window.setLanguage(language);
                    }
                });
            });

            syncActive();
        });
    }

    function initSetupThemePicker(root) {
        root.querySelectorAll('[data-setup-theme-picker]').forEach((picker) => {
            if (picker.dataset.bound === 'true') return;
            picker.dataset.bound = 'true';

            const inputId = picker.getAttribute('data-theme-input');
            const input = inputId ? document.getElementById(inputId) : null;
            if (!input) return;

            const options = Array.from(picker.querySelectorAll('.theme-preview[data-theme]'));

            function syncActive() {
                const activeTheme = input.value || 'light';
                options.forEach((option) => {
                    option.classList.toggle('active', option.getAttribute('data-theme') === activeTheme);
                });
            }

            options.forEach((option) => {
                option.addEventListener('click', () => {
                    const theme = option.getAttribute('data-theme') || 'light';
                    input.value = theme;
                    syncActive();
                    if (window.setTheme) {
                        window.setTheme(theme);
                    }
                });
            });

            syncActive();
        });
    }

    function initSetupTableDensityPicker(root) {
        root.querySelectorAll('[data-setup-table-density-picker]').forEach((picker) => {
            if (picker.dataset.bound === 'true') return;
            picker.dataset.bound = 'true';

            const inputId = picker.getAttribute('data-table-density-input');
            const input = inputId ? document.getElementById(inputId) : null;
            if (!input) return;

            const options = Array.from(picker.querySelectorAll('[data-setup-table-density-choice]'));

            function syncActive() {
                const activeDensity = input.value || 'balanced';
                options.forEach((option) => {
                    option.classList.toggle('is-active', option.getAttribute('data-setup-table-density-choice') === activeDensity);
                });
            }

            options.forEach((option) => {
                option.addEventListener('click', () => {
                    const density = option.getAttribute('data-setup-table-density-choice') || 'balanced';
                    input.value = density;
                    input.dispatchEvent(new Event('change', { bubbles: true }));
                    syncActive();
                });
            });

            syncActive();
        });
    }

    function initSidebarBehaviorOptions(root) {
        root.querySelectorAll('form.ms-system-setup-form').forEach((form) => {
            if (form.dataset.sidebarBehaviorBound === 'true') {
                return;
            }

            const toolbarToggle = form.querySelector('#id_sidebar_enable_toolbar');
            const toolbarNote = form.querySelector('[data-sidebar-toolbar-note]');
            if (!toolbarToggle || !toolbarNote) {
                return;
            }

            form.dataset.sidebarBehaviorBound = 'true';

            function syncToolbarNote() {
                toolbarNote.classList.toggle('d-none', Boolean(toolbarToggle.checked));
            }

            toolbarToggle.addEventListener('change', syncToolbarNote);
            syncToolbarNote();
        });
    }

    function scan(root) {
        restoreSetupFormState(root);
        initSetupHomeFields(root);
        root.querySelectorAll('.ms-setup-builder').forEach(initBuilder);
        initSetupLanguagePicker(root);
        initSetupThemePicker(root);
        initSetupTableDensityPicker(root);
        initSidebarBehaviorOptions(root);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => scan(document));
    } else {
        scan(document);
    }

    const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            for (const node of mutation.addedNodes) {
                if (node.nodeType !== 1) continue;
                if (
                    node.matches && (
                        node.matches('.ms-setup-builder') ||
                        node.querySelector('.ms-setup-builder') ||
                        node.querySelector('[data-setup-language-picker]') ||
                        node.querySelector('[data-setup-table-density-picker]')
                    )
                ) {
                    scan(node);
                    return;
                }
            }
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });
})();
