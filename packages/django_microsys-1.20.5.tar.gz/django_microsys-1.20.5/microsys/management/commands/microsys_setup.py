# microsys/management/commands/microsys_setup.py
"""
Management command for initial microsys package setup.
Runs migrations and performs initial configuration.
"""
import importlib
from pathlib import Path

from django.conf import settings
from django.core.management.base import BaseCommand
from django.core.management import call_command


MICROSYS_SETTINGS_BLOCK = """
# MicroSys integration
from microsys.utils import microsys_settings
microsys_settings(globals())
""".strip()


class Command(BaseCommand):
    help = 'Initial setup for microsys package - runs migrations and validates configuration'

    def add_arguments(self, parser):
        parser.add_argument(
            '--skip-check',
            action='store_true',
            help='Skip configuration validation after setup',
        )
        parser.add_argument(
            '--no-migrate',
            action='store_true',
            help='Skip running migrations',
        )
        parser.add_argument(
            '--skip-configure',
            action='store_true',
            help='Skip appending the recommended microsys settings helper to the active project settings file',
        )

    def _get_settings_file(self):
        module_name = getattr(settings, "SETTINGS_MODULE", None)
        if not module_name:
            return None
        module = importlib.import_module(module_name)
        module_file = getattr(module, "__file__", None)
        return Path(module_file).resolve() if module_file else None

    def _ensure_settings_block(self):
        settings_file = self._get_settings_file()
        if not settings_file or not settings_file.exists():
            raise RuntimeError("Could not resolve the active Django settings.py file")

        contents = settings_file.read_text(encoding="utf-8")
        if (
            "from microsys.utils import microsys_settings" in contents
            and "microsys_settings(globals())" in contents
        ):
            return settings_file, False

        suffix = "" if contents.endswith("\n") else "\n"
        settings_file.write_text(
            f"{contents}{suffix}\n{MICROSYS_SETTINGS_BLOCK}\n",
            encoding="utf-8",
        )
        return settings_file, True

    def handle(self, *args, **options):
        self.stdout.write(self.style.MIGRATE_HEADING('\n📦 MicroSys Setup\n'))
        self.stdout.write('=' * 40 + '\n')

        if not options['skip_configure']:
            self.stdout.write('\n🛠 Ensuring settings.py includes the MicroSys helper...\n')
            try:
                settings_file, changed = self._ensure_settings_block()
                status = 'appended' if changed else 'already present'
                self.stdout.write(
                    self.style.SUCCESS(f'   ✓ Settings helper {status}: {settings_file}\n')
                )
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'   ✗ Settings configuration failed: {e}\n'))
                return

        # Step 1: Create migrations if needed
        if not options['no_migrate']:
            self.stdout.write('\n🔄 Creating migrations for microsys...\n')
            try:
                call_command('makemigrations', 'microsys', verbosity=1)
                self.stdout.write(self.style.SUCCESS('   ✓ Migrations created\n'))
            except Exception as e:
                self.stdout.write(self.style.WARNING(f'   ⚠ Migration creation: {e}\n'))

            # Step 2: Run migrations
            self.stdout.write('\n🔄 Running migrations...\n')
            try:
                call_command('migrate', 'microsys', verbosity=1)
                self.stdout.write(self.style.SUCCESS('   ✓ Migrations applied\n'))
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'   ✗ Migration failed: {e}\n'))
                return

        # Step 3: Run configuration check
        if not options['skip_check']:
            self.stdout.write('\n')
            call_command('microsys_check')

        self.stdout.write('\n' + '=' * 40)
        self.stdout.write(self.style.SUCCESS('\n✅ MicroSys setup complete!\n'))
