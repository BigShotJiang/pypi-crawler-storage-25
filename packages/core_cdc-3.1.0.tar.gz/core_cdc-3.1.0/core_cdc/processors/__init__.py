# -*- coding: utf-8 -*-

"""CDC processor interface."""

from core_cdc.processors.base import IProcessor


__all__ = [
    "IProcessor",
]
