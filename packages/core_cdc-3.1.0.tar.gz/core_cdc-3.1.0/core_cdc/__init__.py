# -*- coding: utf-8 -*-

"""
Core CDC (Change Data Capture) library.

This library provides the core mechanism and required resources to
implement Change Data Capture services for various database engines
including MySQL and MongoDB.
"""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version

from core_cdc.base import EventType
from core_cdc.base import Record
from core_cdc.processors.base import IProcessor
from core_cdc.targets.base import ITarget


try:
    __version__ = version("core-cdc")

except PackageNotFoundError:
    __version__ = "unknown"


__all__ = [
    "__version__",
    "EventType",
    "IProcessor",
    "ITarget",
    "Record",
]
