# -*- coding: utf-8 -*-

"""CDC target interface."""

from core_cdc.targets.base import ITarget


__all__ = [
    "ITarget",
]
