"""
qubestack-cudaq: QuREKA backend plugin for CUDA-Q.

This package provides the QuREKA server helper and executor for CUDA-Q,
enabling quantum job execution via the QuREKA platform.

Usage:
    import cudaq
    cudaq.set_target("qureka", backend="amazon.sv1", api_key="your-api-key")

The plugin is automatically discovered by CUDA-Q when installed.
No additional import or configuration is required.
"""

__version__ = "1.0.27"
