"""Configuration schema using Pydantic."""

from pathlib import Path
from typing import Literal
from pydantic import BaseModel, Field, field_validator
from pydantic_settings import BaseSettings


class MemoryFlushConfig(BaseModel):
    """Pre-compaction memory flush configuration."""
    enabled: bool = True
    soft_threshold_tokens: int = 4000
    prompt: str = (
        "Pre-compaction memory flush. "
        "Store durable memories now (use memory/YYYY-MM-DD.md). "
        "If nothing to store, reply with NO_REPLY."
    )
    system_prompt: str = (
        "Pre-compaction memory flush turn. "
        "The session is near auto-compaction; capture durable memories to disk."
    )


class CompactionConfig(BaseModel):
    """Context compaction configuration."""
    mode: Literal["default", "safeguard"] = "safeguard"
    reserve_tokens_floor: int = 20000
    max_history_share: float = 0.5  # 0.1-0.9
    context_window: int = 128000
    memory_flush: MemoryFlushConfig = Field(default_factory=MemoryFlushConfig)


class WhatsAppConfig(BaseModel):
    """WhatsApp channel configuration."""
    enabled: bool = False
    bridge_url: str = "ws://localhost:3001"
    allow_from: list[str] = Field(default_factory=list)  # Allowed phone numbers


class TelegramConfig(BaseModel):
    """Telegram channel configuration."""
    enabled: bool = False
    token: str = ""  # Bot token from @BotFather
    allow_from: list[str] = Field(default_factory=list)  # Allowed user IDs or usernames
    dm_policy: Literal["open", "pairing", "allowlist"] = "pairing"  # DM access policy


class DiscordConfig(BaseModel):
    """Discord channel configuration."""
    enabled: bool = False
    token: str = ""  # Bot token from Discord Developer Portal
    allow_from: list[str] = Field(default_factory=list)  # Allowed user IDs
    gateway_url: str = "wss://gateway.discord.gg/?v=10&encoding=json"
    intents: int = 37377  # GUILDS + GUILD_MESSAGES + DIRECT_MESSAGES + MESSAGE_CONTENT


class SlackDMConfig(BaseModel):
    """Slack DM policy configuration."""
    enabled: bool = True
    policy: str = "open"  # "open" or "allowlist"
    allow_from: list[str] = Field(default_factory=list)  # Allowed Slack user IDs


class SlackConfig(BaseModel):
    """Slack channel configuration."""
    enabled: bool = False
    mode: str = "socket"  # "socket" supported
    bot_token: str = ""  # xoxb-...
    app_token: str = ""  # xapp-...
    group_policy: str = "mention"  # "mention", "open", "allowlist"
    group_allow_from: list[str] = Field(default_factory=list)  # Allowed channel IDs if allowlist
    dm: SlackDMConfig = Field(default_factory=SlackDMConfig)


class WebChannelConfig(BaseModel):
    """Web chat channel configuration (relay mode — no SSH needed)."""
    enabled: bool = False
    relay_url: str = "wss://relay.useflowlyapp.com/relay"
    server_id: str = ""    # Flowly server ID (from deployment)
    auth_token: str = ""   # gatewayAuthToken (from deployment)
    jwt_secret: str = ""   # JWT signing secret (for relay authentication)


class EmailConfig(BaseModel):
    """Email/Gmail channel configuration (OAuth-based)."""
    enabled: bool = False
    poll_interval_seconds: int = 30  # Check for new emails every N seconds
    allow_from: list[str] = Field(default_factory=list)  # Allowed sender emails


class ChannelsConfig(BaseModel):
    """Configuration for chat channels."""
    whatsapp: WhatsAppConfig = Field(default_factory=WhatsAppConfig)
    telegram: TelegramConfig = Field(default_factory=TelegramConfig)
    discord: DiscordConfig = Field(default_factory=DiscordConfig)
    slack: SlackConfig = Field(default_factory=SlackConfig)
    web: WebChannelConfig = Field(default_factory=WebChannelConfig)
    email: EmailConfig = Field(default_factory=EmailConfig)


class HeartbeatActiveHours(BaseModel):
    """Active hours window for heartbeat — outside this window heartbeat is skipped."""
    start: str = "09:00"  # HH:MM (24h)
    end: str = "23:00"    # HH:MM (24h)
    timezone: str = ""    # IANA timezone, e.g. "Europe/Istanbul". Empty = system local.


class HeartbeatConfig(BaseModel):
    """Periodic heartbeat configuration — wakes the agent to check for tasks."""
    enabled: bool = True
    every_minutes: int = 30
    active_hours: HeartbeatActiveHours | None = None
    # Where to deliver non-OK heartbeat responses:
    # "none" = don't deliver, "message_tool" = agent uses message tool (needs channel config)
    deliver: str = "none"


class MemorySearchConfig(BaseModel):
    """Memory search / indexing configuration."""
    enabled: bool = True
    # Embedding provider: "auto", "openai", "gemini", "none"
    # "auto" tries openai then gemini from providers config; "none" = FTS5 keyword only
    provider: str = "auto"
    model: str = ""           # Override embedding model (default: provider's default)
    api_key: str = ""         # Override API key for embeddings (defaults to provider config)
    api_base: str = ""        # Override API base URL
    chunk_tokens: int = 400   # Target tokens per chunk
    overlap_tokens: int = 80  # Overlap between consecutive chunks
    max_results: int = 6      # Max search results returned
    min_score: float = 0.35   # Minimum relevance score (0-1)
    vector_weight: float = 0.7   # Weight for vector similarity in hybrid score
    text_weight: float = 0.3     # Weight for BM25 keyword score in hybrid score


class AgentDefaults(BaseModel):
    """Default agent configuration."""
    workspace: str = "~/.flowly/workspace"
    model: str = "moonshotai/kimi-k2.5"
    max_tokens: int = 8192
    temperature: float = 0.7
    action_temperature: float = 0.1
    action_tool_retries: int = 2
    max_tool_iterations: int = 10
    context_messages: int = 100  # Max messages to include in context
    persona: str = "default"  # Bot persona (default, jarvis, pirate, etc.)
    save_trajectories: bool = False  # Save conversation turns as ShareGPT JSONL
    memory_nudge_interval: int = 10   # Background memory review every N user turns (0=disabled)
    skill_nudge_interval: int = 15    # Background skill review every N tool iterations (0=disabled)
    compaction: CompactionConfig = Field(default_factory=CompactionConfig)
    heartbeat: HeartbeatConfig = Field(default_factory=HeartbeatConfig)
    memory_search: MemorySearchConfig = Field(default_factory=MemorySearchConfig)


class MultiAgentConfig(BaseModel):
    """Single agent configuration for multi-agent orchestration."""
    name: str = ""
    provider: str = "anthropic"  # "anthropic", "openai", "flowly"
    model: str = ""  # Short name ("sonnet", "opus") or full model ID
    working_directory: str = ""  # Default: ~/.flowly/agents/{id}/
    persona: str = ""


class MultiAgentTeamConfig(BaseModel):
    """Team of agents for chain collaboration."""
    name: str = ""
    agents: list[str] = Field(default_factory=list)
    leader_agent: str = ""


class AgentsConfig(BaseModel):
    """Agent configuration."""
    defaults: AgentDefaults = Field(default_factory=AgentDefaults)
    agents: dict[str, MultiAgentConfig] = Field(default_factory=dict)
    teams: dict[str, MultiAgentTeamConfig] = Field(default_factory=dict)


class ProviderConfig(BaseModel):
    """LLM provider configuration."""
    api_key: str = ""
    api_base: str | None = None
    # Additional API keys to rotate through when the primary key fails.
    # Keys are tried in order; failed keys enter a 60-second cooldown.
    fallback_keys: list[str] = Field(default_factory=list)


class ProvidersConfig(BaseModel):
    """Configuration for LLM providers."""
    anthropic: ProviderConfig = Field(default_factory=ProviderConfig)
    openai: ProviderConfig = Field(default_factory=ProviderConfig)
    openrouter: ProviderConfig = Field(default_factory=ProviderConfig)
    zhipu: ProviderConfig = Field(default_factory=ProviderConfig)
    vllm: ProviderConfig = Field(default_factory=ProviderConfig)
    gemini: ProviderConfig = Field(default_factory=ProviderConfig)
    groq: ProviderConfig = Field(default_factory=ProviderConfig)  # For voice transcription
    xai: ProviderConfig = Field(default_factory=ProviderConfig)  # xAI Grok models


class GatewayConfig(BaseModel):
    """Gateway/server configuration."""
    host: str = "127.0.0.1"
    port: int = 18790

    @field_validator("port")
    @classmethod
    def _validate_port(cls, v: int) -> int:
        if not 1 <= v <= 65535:
            raise ValueError(f"port must be between 1 and 65535, got {v}")
        return v


class WebSearchConfig(BaseModel):
    """Web search tool configuration."""
    api_key: str = ""  # Brave Search API key
    max_results: int = 5


class WebToolsConfig(BaseModel):
    """Web tools configuration."""
    search: WebSearchConfig = Field(default_factory=WebSearchConfig)


class ExecToolConfig(BaseModel):
    """Command execution tool configuration."""
    enabled: bool = True
    security: Literal["deny", "allowlist", "full"] = "full"
    ask: Literal["off", "on-miss", "always"] = "off"
    timeout_seconds: int = 300  # 5 minutes default
    max_output_chars: int = 200000  # 200KB
    approval_timeout_seconds: int = 120  # 2 minutes to approve

    @field_validator("timeout_seconds")
    @classmethod
    def _validate_timeout(cls, v: int) -> int:
        if not 1 <= v <= 3600:
            raise ValueError(f"timeout_seconds must be between 1 and 3600, got {v}")
        return v


class TrelloConfig(BaseModel):
    """Trello integration configuration."""
    api_key: str = ""  # Get at https://trello.com/app-key
    token: str = ""  # Generate from the same page


class XConfig(BaseModel):
    """X (Twitter) API configuration."""
    bearer_token: str = ""  # App-only Bearer Token (read operations)
    api_key: str = ""  # OAuth 1.0a Consumer Key (write operations)
    api_secret: str = ""  # OAuth 1.0a Consumer Secret
    access_token: str = ""  # OAuth 1.0a Access Token
    access_token_secret: str = ""  # OAuth 1.0a Access Token Secret


class VoiceWebhookSecurityConfig(BaseModel):
    """Voice webhook security configuration."""
    allowed_hosts: list[str] = Field(default_factory=list)
    trust_forwarding_headers: bool = False
    trusted_proxy_ips: list[str] = Field(default_factory=list)


class VoiceLiveCallConfig(BaseModel):
    """Live-call tool sandbox policy."""
    strict_tool_sandbox: bool = True
    allow_tools: list[str] = Field(
        default_factory=lambda: ["voice_call", "message", "screenshot", "system"]
    )


class VoiceBridgeConfig(BaseModel):
    """Integrated voice plugin configuration for Twilio calls."""
    enabled: bool = False
    # Legacy bridge fallback API URL (optional, disabled by default)
    bridge_url: str = "http://localhost:8765"
    legacy_bridge_enabled: bool = False

    # Twilio settings
    twilio_account_sid: str = ""
    twilio_auth_token: str = ""
    twilio_phone_number: str = ""

    # Webhook URL (static public URL for Twilio callbacks)
    webhook_base_url: str = ""
    skip_signature_verification: bool = False
    webhook_security: VoiceWebhookSecurityConfig = Field(default_factory=VoiceWebhookSecurityConfig)
    live_call: VoiceLiveCallConfig = Field(default_factory=VoiceLiveCallConfig)

    # Link voice calls to Telegram session (for screenshots, messages etc.)
    telegram_chat_id: str = ""  # Your Telegram chat ID - voice calls will use this session
    default_to_number: str = ""  # Optional default target phone for "beni ara" requests

    # STT/TTS settings
    stt_provider: str = "groq"  # groq, deepgram, openai, or elevenlabs
    tts_provider: str = "elevenlabs"  # openai, deepgram, or elevenlabs
    groq_api_key: str = ""  # For Groq Whisper STT
    deepgram_api_key: str = ""  # For Deepgram STT/TTS
    elevenlabs_api_key: str = ""  # For ElevenLabs STT/TTS
    tts_voice: str = "21m00Tcm4TlvDq8ikWAM"  # TTS voice (provider-specific, default: rachel)
    language: str = "en-US"

    # Ngrok auto-tunnel (alternative to manual webhook_base_url)
    ngrok_authtoken: str = ""  # ngrok authtoken from https://dashboard.ngrok.com


class GoogleWorkspaceConfig(BaseModel):
    """Google Workspace integration configuration."""
    enabled: bool = False
    email: str = ""  # Connected Google account email


class IntegrationsConfig(BaseModel):
    """External integrations configuration."""
    trello: TrelloConfig = Field(default_factory=TrelloConfig)
    voice: VoiceBridgeConfig = Field(default_factory=VoiceBridgeConfig)
    x: XConfig = Field(default_factory=XConfig)
    google_workspace: GoogleWorkspaceConfig = Field(default_factory=GoogleWorkspaceConfig)


class ArtifactConfig(BaseModel):
    """Artifact persistence configuration."""
    enabled: bool = True
    max_content_length: int = 500000  # 500KB


class BrowserTabConfig(BaseModel):
    """Browser tab tool configuration (requires Flowly Chrome extension)."""
    enabled: bool = False


class ComputerConfig(BaseModel):
    """Computer use (desktop automation) configuration."""
    enabled: bool = False
    action_delay_ms: int = 100
    failsafe: bool = True


class ToolsConfig(BaseModel):
    """Tools configuration."""
    web: WebToolsConfig = Field(default_factory=WebToolsConfig)
    exec: ExecToolConfig = Field(default_factory=ExecToolConfig)
    artifact: ArtifactConfig = Field(default_factory=ArtifactConfig)
    browser_tab: BrowserTabConfig = Field(default_factory=BrowserTabConfig)
    computer: ComputerConfig = Field(default_factory=ComputerConfig)


class Config(BaseSettings):
    """Root configuration for flowly."""
    agents: AgentsConfig = Field(default_factory=AgentsConfig)
    channels: ChannelsConfig = Field(default_factory=ChannelsConfig)
    providers: ProvidersConfig = Field(default_factory=ProvidersConfig)
    gateway: GatewayConfig = Field(default_factory=GatewayConfig)
    tools: ToolsConfig = Field(default_factory=ToolsConfig)
    integrations: IntegrationsConfig = Field(default_factory=IntegrationsConfig)
    background_mode: bool = Field(default=False, alias="backgroundMode")
    
    @property
    def workspace_path(self) -> Path:
        """Get expanded workspace path."""
        return Path(self.agents.defaults.workspace).expanduser()
    
    def get_api_key(self) -> str | None:
        """Get API key in priority order: OpenRouter > Anthropic > OpenAI > xAI > Gemini > Zhipu > vLLM."""
        return (
            self.providers.openrouter.api_key or
            self.providers.anthropic.api_key or
            self.providers.openai.api_key or
            self.providers.xai.api_key or
            self.providers.gemini.api_key or
            self.providers.zhipu.api_key or
            self.providers.vllm.api_key or
            None
        )

    def get_active_provider_name(self) -> str:
        """Return the name of the active provider (highest-priority configured key)."""
        if self.providers.openrouter.api_key:
            return "openrouter"
        if self.providers.anthropic.api_key:
            return "anthropic"
        if self.providers.openai.api_key:
            return "openai"
        if self.providers.xai.api_key:
            return "xai"
        if self.providers.gemini.api_key:
            return "gemini"
        if self.providers.zhipu.api_key:
            return "zhipu"
        if self.providers.vllm.api_key:
            return "vllm"
        return "unknown"

    def get_fallback_keys(self) -> list[str]:
        """Return fallback_keys for the active provider."""
        name = self.get_active_provider_name()
        provider_cfg = getattr(self.providers, name, None)
        if provider_cfg is None:
            return []
        return provider_cfg.fallback_keys
    
    def get_api_base(self) -> str | None:
        """Get API base URL if using OpenRouter, xAI, Zhipu or vLLM."""
        if self.providers.openrouter.api_key:
            return self.providers.openrouter.api_base or "https://openrouter.ai/api/v1"
        if self.providers.xai.api_key:
            return self.providers.xai.api_base or "https://api.x.ai/v1"
        if self.providers.zhipu.api_key:
            return self.providers.zhipu.api_base
        if self.providers.vllm.api_base:
            return self.providers.vllm.api_base
        return None
    
    class Config:
        env_prefix = "FLOWLY_"
        env_nested_delimiter = "__"
        populate_by_name = True
