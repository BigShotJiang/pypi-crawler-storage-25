"""LS-DYNA 仿真计算工具.

自动调用 lsdyna.exe 进行有限元仿真计算,
智能解析输入文件并自动配置计算资源.
"""

from __future__ import annotations

import argparse
import os
import platform
import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Pattern

from bitool.cmd import CommandScheduler
from bitool.core import logger
from bitool.skills._base import BaseSkill


class LsCalcConfig:
    """lscalc 工具配置类."""

    NAME: str = "lscalc"
    LS_DYNA_EXE_NAMES: list[str] = ["lsdyna.exe", "ls-dyna.exe", "lsdyna"]
    DEFAULT_MEMORY_PER_CPU_MB: int = 2048
    MIN_MEMORY_MB: int = 512
    MAX_MEMORY_PERCENT: float = 0.85
    WINDOWS_SUGGESTED_MEMORY_PERCENT: float = 0.75
    LS_DYNA_PATTERN: Pattern[str] = re.compile(
        r"^\s*\$"
        r"|TIME\s*="
        r"|MAT_"
        r"|ELEMENT_"
        r"|NODE"
        r"|CONTACT"
        r"|BOUNDARY"
        r"|DATABASE"
        r"|\*KEYWORD"
        r"|\*END",
        re.IGNORECASE | re.MULTILINE,
    )
    MEMORY_PATTERN: Pattern[str] = re.compile(
        r"(?:MEMORY|DATABASE_(?:BINARY|HISTORY|GLOBAL))"
        r"\s*=\s*(\d+)",
        re.IGNORECASE,
    )
    CPU_PATTERN: Pattern[str] = re.compile(r"(?:NPROC|CPU)\s*=\s*(\d+)", re.IGNORECASE)


conf = LsCalcConfig()


@dataclass
class SystemInfo:
    """系统资源信息."""

    cpu_count: int = field(default=0)
    total_memory_mb: int = field(default=0)
    available_memory_mb: int = field(default=0)
    platform: str = field(default="")

    @classmethod
    def detect(cls) -> SystemInfo:
        """自动检测系统资源."""
        info = cls()
        info.platform = platform.system().lower()

        info.cpu_count = os.cpu_count() or 1

        if info.platform == "windows":
            try:
                import ctypes

                kernel32 = ctypes.windll.kernel32
                c_ulong = ctypes.c_ulong

                class MEMORYSTATUSEX(ctypes.Structure):
                    _fields_ = [
                        ("dwLength", c_ulong),
                        ("dwMemoryLoad", c_ulong),
                        ("ullTotalPhys", c_ulong),
                        ("ullAvailPhys", c_ulong),
                        ("ullTotalPageFile", c_ulong),
                        ("ullAvailPageFile", c_ulong),
                        ("ullTotalVirtual", c_ulong),
                        ("ullAvailVirtual", c_ulong),
                        ("ullAvailExtendedVirtual", c_ulong),
                    ]

                mem_status = MEMORYSTATUSEX()
                mem_status.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
                kernel32.GlobalMemoryStatusEx(ctypes.byref(mem_status))

                info.total_memory_mb = int(mem_status.ullTotalPhys / 1024 / 1024)
                info.available_memory_mb = int(mem_status.ullAvailPhys / 1024 / 1024)
            except (OSError, ValueError):
                info.total_memory_mb = 8192
                info.available_memory_mb = int(info.total_memory_mb * 0.5)
        else:
            try:
                with open("/proc/meminfo", encoding="utf-8") as f:
                    for line in f:
                        if line.startswith("MemTotal:"):
                            info.total_memory_mb = int(line.split()[1]) // 1024
                        elif line.startswith("MemAvailable:"):
                            info.available_memory_mb = int(line.split()[1]) // 1024
                            break
            except (OSError, ValueError):
                info.total_memory_mb = 8192
                info.available_memory_mb = int(info.total_memory_mb * 0.5)

        return info

    def get_suggested_memory_mb(self, cpu_count: int) -> int:
        """获取建议的内存大小.

        Parameters
        ----------
        cpu_count : int
            使用的 CPU 核心数

        Returns
        -------
        int
            建议的内存大小 (MB)
        """
        if self.platform == "windows":
            max_memory = int(
                self.available_memory_mb * conf.WINDOWS_SUGGESTED_MEMORY_PERCENT,
            )
        else:
            max_memory = int(self.available_memory_mb * conf.MAX_MEMORY_PERCENT)

        memory_per_cpu = conf.DEFAULT_MEMORY_PER_CPU_MB * cpu_count
        suggested = min(max_memory, memory_per_cpu)
        return max(suggested, conf.MIN_MEMORY_MB)

    def get_max_suggested_cpus(self) -> int:
        """获取最大建议 CPU 核心数.

        Returns
        -------
        int
            建议的最大 CPU 核心数
        """
        if self.available_memory_mb > 0:
            max_by_memory = int(
                self.available_memory_mb
                / conf.DEFAULT_MEMORY_PER_CPU_MB
                / conf.MAX_MEMORY_PERCENT,
            )
            return min(self.cpu_count, max_by_memory)
        return self.cpu_count


@dataclass
class InputFileAnalysis:
    """输入文件分析结果."""

    file_path: Path | None = field(default=None)
    is_keyword_format: bool = field(default=False)
    detected_memory_mb: int | None = field(default=None)
    detected_cpus: int | None = field(default=None)
    has_contact: bool = field(default=False)
    has_database: bool = field(default=False)
    analysis_type: str = field(default="unknown")

    def suggest_memory_mb(self, system: SystemInfo, requested_cpus: int | None) -> int:
        """建议内存大小.

        Parameters
        ----------
        system : SystemInfo
            系统信息
        requested_cpus : int | None
            请求的 CPU 核心数

        Returns
        -------
        int
            建议的内存大小
        """
        if self.detected_memory_mb:
            return self.detected_memory_mb

        cpu_count = (
            requested_cpus if requested_cpus else system.get_max_suggested_cpus()
        )
        return system.get_suggested_memory_mb(cpu_count)

    def suggest_cpus(self, system: SystemInfo) -> int:
        """建议 CPU 核心数.

        Parameters
        ----------
        system : SystemInfo
            系统信息

        Returns
        -------
        int
            建议的 CPU 核心数
        """
        if self.detected_cpus:
            return self.detected_cpus

        return system.get_max_suggested_cpus()


class InputFileParser:
    """输入文件解析器."""

    @staticmethod
    def parse(file_path: Path) -> InputFileAnalysis:
        """解析 LS-DYNA 输入文件.

        Parameters
        ----------
        file_path : Path
            输入文件路径

        Returns
        -------
        InputFileAnalysis
            分析结果
        """
        analysis = InputFileAnalysis(file_path=file_path)

        try:
            with open(file_path, encoding="utf-8", errors="ignore") as f:
                content = f.read()

            analysis.is_keyword_format = bool(conf.LS_DYNA_PATTERN.search(content))

            memory_match = conf.MEMORY_PATTERN.search(content)
            if memory_match:
                analysis.detected_memory_mb = int(memory_match.group(1))

            cpu_match = conf.CPU_PATTERN.search(content)
            if cpu_match:
                analysis.detected_cpus = int(cpu_match.group(1))

            analysis.has_contact = bool(re.search(r"CONTACT_", content, re.IGNORECASE))
            analysis.has_database = bool(
                re.search(r"DATABASE_", content, re.IGNORECASE),
            )

            if "SMP" in content.upper() and "MPP" not in content.upper():
                analysis.analysis_type = "smp"
            elif "MPP" in content.upper():
                analysis.analysis_type = "mpp"
            else:
                analysis.analysis_type = "auto"

        except (OSError, ValueError) as e:
            logger.warning(f"解析文件 {file_path} 时出错: {e}")

        return analysis


class LsDynaLocator:
    """LS-DYNA 可执行文件定位器."""

    @staticmethod
    def find(explicit_path: str | None = None) -> Path | None:
        """查找 LS-DYNA 可执行文件.

        Parameters
        ----------
        explicit_path : str | None
            显式指定的路径

        Returns
        -------
        Path | None
            找到的路径, 未找到则返回 None
        """
        if explicit_path:
            path = Path(explicit_path)
            if path.exists() and path.is_file():
                return path
            logger.warning(f"指定的 lsdyna 路径不存在: {explicit_path}")
            return None

        for exe_name in conf.LS_DYNA_EXE_NAMES:
            path = shutil.which(exe_name)
            if path:
                logger.info(f"找到 lsdyna: {path}")
                return Path(path)

        common_paths_windows = [
            Path("C:/Program Files/LSTC/LSDYNA/lsdyna.exe"),
            Path("C:/Program Files (x86)/LSTC/LSDYNA/lsdyna.exe"),
            Path("C:/LSTC/LSDYNA/lsdyna.exe"),
        ]

        for path in common_paths_windows:
            if path.exists():
                logger.info(f"找到 lsdyna: {path}")
                return path

        common_paths_linux = [
            Path("/opt/lsdyna/lsdyna"),
            Path("/usr/local/lsdyna/lsdyna"),
            Path.home() / "lsdyna/lsdyna",
        ]

        for path in common_paths_linux:
            if path.exists():
                logger.info(f"找到 lsdyna: {path}")
                return path

        return None


@dataclass
class LsDynaCommand:
    """LS-DYNA 命令构建器."""

    executable: Path | None = field(default=None)
    input_file: Path | None = field(default=None)
    memory_mb: int = field(default=0)
    cpus: int = field(default=0)
    extra_args: list[str] = field(default_factory=list)
    analysis_type: str = field(default="auto")

    def build(self) -> list[str]:
        """构建命令参数列表.

        Returns
        -------
        list[str]
            命令参数列表
        """
        cmd: list[str] = [str(self.executable)]

        if not self.input_file:
            logger.warning("输入文件路径不能为空")
            return []

        if self.analysis_type == "smp":
            cmd.extend([f"i={self.input_file.name}"])
            cmd.extend([f"memory={self.memory_mb}"])
            cmd.extend([f"ncpu={self.cpus}"])
        elif self.analysis_type == "mpp":
            cmd.extend([f"i={self.input_file.name}"])
            cmd.extend([f"memory={self.memory_mb}"])
            cmd.extend([f"npart={self.cpus}"])
        else:
            cmd.extend([f"i={self.input_file.name}"])
            cmd.extend([f"memory={self.memory_mb}"])

        cmd.extend(self.extra_args)

        return cmd

    def get_full_command(self) -> str:
        """获取完整命令字符串.

        Returns
        -------
        str
            命令字符串
        """
        return " ".join(self.build())


class LsCalcSkill(BaseSkill):
    """LS-DYNA 计算技能."""

    name = "lscalc"
    description = "自动调用 lsdyna.exe 进行仿真计算"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "input_file",
            type=str,
            nargs="?",
            default=None,
            help="LS-DYNA 输入文件 (.k, .key, .dyn)",
        )
        parser.add_argument(
            "-e",
            "--exe",
            type=str,
            default=None,
            help="lsdyna.exe 路径",
        )
        parser.add_argument(
            "-m",
            "--memory",
            type=int,
            default=None,
            help="内存大小 (MB)",
        )
        parser.add_argument("-n", "--nproc", type=int, default=None, help="CPU 核心数")
        parser.add_argument(
            "-t",
            "--type",
            type=str,
            choices=["smp", "mpp", "auto"],
            default="auto",
            help="分析类型 (smp/mpp/auto)",
        )
        parser.add_argument("-o", "--output", type=str, default=None, help="输出目录")
        parser.add_argument("--dry-run", action="store_true", help="仅显示命令,不执行")
        parser.add_argument(
            "--sys-info",
            action="store_true",
            help="显示系统信息并退出",
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler | None:
        """创建 LS-DYNA 计算调度器."""
        system = SystemInfo.detect()

        if args.sys_info:
            self._print_system_info(system)
            return None

        if args.input_file is None:
            logger.error("请指定输入文件")
            return None

        input_path = Path(args.input_file)
        if not input_path.exists():
            logger.error(f"输入文件不存在: {input_path}")
            return None

        lsdyna = LsDynaLocator.find(args.exe)
        if lsdyna is None:
            logger.error("未找到 lsdyna.exe, 请使用 -e 参数指定路径")
            return None

        analysis = InputFileParser.parse(input_path)

        if analysis.is_keyword_format:
            logger.info(f"检测到 LS-DYNA 关键词格式: {input_path.name}")
        else:
            logger.warning(
                f"文件格式可能不是标准 LS-DYNA 关键词格式: {input_path.name}",
            )

        cpu_count = args.nproc if args.nproc else analysis.suggest_cpus(system)
        cpu_count = min(cpu_count, system.get_max_suggested_cpus())

        memory_mb = (
            args.memory
            if args.memory
            else analysis.suggest_memory_mb(system, args.nproc)
        )

        analysis_type = args.type
        if analysis_type == "auto":
            analysis_type = analysis.analysis_type

        output_dir = Path(args.output) if args.output else input_path.parent
        if not output_dir.exists():
            output_dir.mkdir(parents=True)

        original_dir = Path.cwd()
        os.chdir(output_dir)

        cmd = LsDynaCommand(
            executable=lsdyna,
            input_file=input_path,
            memory_mb=memory_mb,
            cpus=cpu_count,
            analysis_type=analysis_type,
        )

        logger.info("=" * 60)
        logger.info("LS-DYNA 仿真计算配置")
        logger.info("=" * 60)
        logger.info(f"输入文件: {input_path.name}")
        logger.info(f"工作目录: {output_dir}")
        logger.info(f"lsdyna: {lsdyna}")
        logger.info(f"分析类型: {analysis_type}")
        logger.info(f"CPU 核心数: {cpu_count} (系统: {system.cpu_count})")
        logger.info(f"内存大小: {memory_mb} MB")
        logger.info(f"系统可用内存: {system.available_memory_mb} MB")
        logger.info(f"命令: {cmd.get_full_command()}")
        logger.info("=" * 60)

        if args.dry_run:
            logger.info("[DRY RUN] 命令不会执行")
            os.chdir(original_dir)
            return None

        try:
            full_cmd = cmd.build()
            logger.info(f"开始执行: {' '.join(full_cmd)}")

            from bitool.cmd import execute

            result = execute(full_cmd)
            return_code = result.returncode

            if return_code == 0:
                logger.info("计算完成")
            else:
                logger.error(f"计算失败, 退出码: {return_code}")

        except KeyboardInterrupt:
            logger.warning("计算被用户中断")
            return None
        except Exception as e:  # noqa: BLE001
            logger.error(f"执行失败: {e}")
            return None
        finally:
            os.chdir(original_dir)

        return CommandScheduler(commands=[])

    @staticmethod
    def _print_system_info(system: SystemInfo) -> None:
        """打印系统信息."""


def main() -> None:
    """主函数入口."""
    LsCalcSkill().run_cli()


if __name__ == "__main__":
    main()
