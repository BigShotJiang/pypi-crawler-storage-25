"""
功能: Backup files and folders as zip file in destination folder, automatic remove
dump files when reached max count.
命令: folderback.exe -f [FILES ...] -d [DESTINATION] -c [CONFIG] -n [COUNT]
"""

from __future__ import annotations

import argparse
import time
import zipfile
from pathlib import Path

from bitool.cmd import RunCommand
from bitool.core import logger
from bitool.skills._base import BaseSkill, CommandScheduler


def remove_dump(src: Path, dst: Path, max_zip: int) -> None:
    """Recursively remove dump zip files in folder dst, archived from src."""
    zip_paths = [
        filepath for filepath in dst.rglob("*.zip") if src.stem in str(filepath)
    ]
    zip_files = sorted(zip_paths, key=lambda fn: str(fn)[-19:-4])
    if len(zip_files) > max_zip:
        zip_files[0].unlink()
        remove_dump(src, dst, max_zip)


def zip_target(src: Path, dst: Path, max_zip: int) -> None:
    """Zip single file or files in folder from src into dst folder."""
    files = [str(_) for _ in src.rglob("*")]
    timestamp = time.strftime("_%Y%m%d_%H%M%S")
    target_path = dst / (src.stem + timestamp + ".zip")
    zip_file = zipfile.ZipFile(target_path, "w")

    for file in files:
        zip_file.write(file, arcname=file.replace(str(src.parent), ""))
    remove_dump(src, dst, max_zip)


class FolderBackupSkill(BaseSkill):
    """Folder backup skill."""

    name = "folderback"
    description = "Backup files and folders as zip file in destination folder, automatic remove dump files when reached max count."

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """Add arguments to parser."""
        parser.add_argument(
            "src",
            type=str,
            help="source folder",
        )
        parser.add_argument(
            "dst",
            type=str,
            help="destination folder",
        )
        parser.add_argument(
            "-n",
            dest="count",
            type=int,
            nargs="?",
            default=5,
            help="max backup count",
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler | None:
        """Create command scheduler."""
        count = args.count
        src = Path(args.src)
        dst = Path(args.dst)

        logger.info(f"Source folder: {src}")
        logger.info(f"Destination folder: {dst}")

        if not src.exists():
            logger.error(f"Source folder {src} does not exist.")
            return None

        if not dst.exists():
            logger.info(f"Destination folder {dst} does not exist, creating it.")
            dst.mkdir(parents=True, exist_ok=True)

        if not count:
            logger.error("Max backup count must be greater than 0.")
            return None

        return CommandScheduler(
            commands=[
                RunCommand(cmd=lambda: zip_target(src=src, dst=dst, max_zip=count))
            ]
        )


def main() -> None:
    """Main function."""
    FolderBackupSkill().run_cli()
