"""PDF技能增强工具模块.

提供PDF技能的通用增强功能:
- 输出目录支持
- 递归搜索子目录
- 静默/详细模式
- 跳过已存在文件
- 进度显示

该模块避免了短选项冲突，只使用长选项
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import ClassVar

from bitool.core import JsonConfig, logger


class PdfSkillConfig(JsonConfig):
    """PDF技能配置类."""

    OUTPUT_SUFFIX: str = ".processed.pdf"
    DEFAULT_OUTPUT_DIR: str = ""


class PdfSkillEnhancer:
    """PDF技能增强工具.

    提供以下增强功能（只使用长选项避免冲突):
    --output-dir: 输出目录
    --recursive: 递归搜索子目录
    --quiet: 静默模式
    --skip-existing: 跳过已存在文件
    """

    config: ClassVar[PdfSkillConfig] = PdfSkillConfig()
    _total_files: int = 0
    _processed_files: int = 0
    _quiet_mode: bool = False

    @classmethod
    def add_arguments(cls, parser: argparse.ArgumentParser) -> None:
        """添加增强的命令行参数（只使用长选项）."""
        parser.add_argument(
            "--output-dir",
            type=str,
            default=cls.config.DEFAULT_OUTPUT_DIR,
            help="输出目录 (默认: 与输入文件同目录)",
        )
        parser.add_argument(
            "--recursive",
            action="store_true",
            help="递归搜索子目录中的PDF文件",
        )
        parser.add_argument(
            "--quiet",
            action="store_true",
            help="静默模式,只输出错误信息",
        )
        parser.add_argument(
            "--skip-existing",
            action="store_true",
            help="跳过已存在的输出文件",
        )

    @classmethod
    def resolve_input_paths(
        cls,
        input_paths: list[str] | None,
        *,
        recursive: bool = False,
    ) -> list[Path]:
        """解析输入路径,支持递归搜索."""
        paths: list[Path] = []

        if input_paths and len(input_paths) > 0:
            for path_str in input_paths:
                path = Path(path_str)
                if path.exists():
                    if path.is_file() and path.suffix.lower() == ".pdf":
                        paths.append(path)
                    elif path.is_dir():
                        paths.extend(cls._find_pdfs_in_dir(path, recursive=recursive))
        else:
            paths.extend(cls._find_pdfs_in_dir(Path.cwd(), recursive=recursive))

        if not paths:
            logger.error("未找到PDF文件")
            sys.exit(1)

        return sorted(paths)

    @classmethod
    def _find_pdfs_in_dir(cls, directory: Path, *, recursive: bool) -> list[Path]:
        """在目录中查找PDF文件."""
        pattern = "**/*.pdf" if recursive else "*.pdf"
        return list(directory.glob(pattern)) + list(directory.glob(pattern.upper()))

    @classmethod
    def resolve_output_path(
        cls,
        input_path: Path,
        output_dir: str | None,
        suffix: str,
    ) -> Path:
        """解析输出路径."""
        if output_dir:
            output_path = Path(output_dir) / input_path.name
            output_path = output_path.with_stem(input_path.stem)
            return output_path.with_suffix(suffix)
        return input_path.with_suffix(suffix)

    @classmethod
    def set_quiet_mode(cls, *, quiet: bool) -> None:
        """设置静默模式."""
        cls._quiet_mode = quiet

    @classmethod
    def log_progress(cls, input_path: Path, output_path: Path) -> None:
        """显示处理进度."""
        if not cls._quiet_mode:
            cls._processed_files += 1
            progress = f"[{cls._processed_files}/{cls._total_files}]"
            logger.info(f"{progress} 处理: {input_path} -> {output_path}")

    @classmethod
    def should_skip(cls, output_path: Path, *, skip_existing: bool) -> bool:
        """判断是否应该跳过此文件."""
        if skip_existing and output_path.exists():
            if not cls._quiet_mode:
                logger.info(f"  跳过(已存在): {output_path}")
            return True
        return False

    @classmethod
    def init_progress(cls, total: int) -> None:
        """初始化进度计数器."""
        cls._total_files = total
        cls._processed_files = 0
        if not cls._quiet_mode:
            logger.info(f"找到 {total} 个PDF文件")

    @classmethod
    def log_info(cls, message: str) -> None:
        """输出信息（考虑静默模式）."""
        if not cls._quiet_mode:
            logger.info(message)
