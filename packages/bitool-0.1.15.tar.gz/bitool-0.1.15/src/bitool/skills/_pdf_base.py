"""PDF技能基础模块.

提供增强的PDF处理技能基类,包含:
- 输入路径解析(支持递归搜索)
- 输出路径处理
- 进度跟踪
- 静默模式支持
- 跳过已存在文件
"""

import argparse
import sys
from pathlib import Path
from typing import ClassVar, List, Optional

from bitool.cmd import CommandScheduler
from bitool.core import JsonConfig, logger


class PdfSkillConfig(JsonConfig):
    """PDF技能配置类."""

    OUTPUT_SUFFIX: str = ".processed.pdf"
    DEFAULT_OUTPUT_DIR: str = ""


class EnhancedPdfSkill:
    """PDF技能增强基类.

    提供以下增强功能:
    - 输入路径解析(支持递归搜索子目录)
    - 输出路径处理
    - 进度跟踪
    - 静默/详细模式
    - 跳过已存在文件

    子类应该:
    1. 继承此类
    2. 定义自己的 config 类属性
    3. 实现 add_arguments() 方法添加专属参数
    4. 实现 create_scheduler() 方法创建命令调度器
    """

    config: ClassVar[PdfSkillConfig] = PdfSkillConfig()

    _total_files: int = 0
    _processed_files: int = 0
    _quiet_mode: bool = False

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加增强的命令行参数(只使用长选项避免冲突).

        Parameters
        ----------
        parser : argparse.ArgumentParser
            参数解析器实例
        """
        parser.add_argument(
            "--output-dir",
            type=str,
            default=self.config.DEFAULT_OUTPUT_DIR,
            help="输出目录 (默认: 与输入文件同目录)",
        )
        parser.add_argument(
            "--recursive",
            action="store_true",
            help="递归搜索子目录中的PDF文件",
        )
        parser.add_argument(
            "--quiet",
            action="store_true",
            help="静默模式,只输出错误信息",
        )
        parser.add_argument(
            "--skip-existing",
            action="store_true",
            help="跳过已存在的输出文件",
        )

    def _resolve_input_paths(
        self,
        input_paths: Optional[List[str]],
        *,
        recursive: bool = False,
    ) -> List[Path]:
        """解析输入路径,支持递归搜索.

        Parameters
        ----------
        input_paths : Optional[List[str]]
            输入路径列表
        recursive : bool, optional
            是否递归搜索子目录, 默认 False

        Returns
        -------
        List[Path]
            解析后的PDF文件路径列表
        """
        paths: List[Path] = []

        if input_paths and len(input_paths) > 0:
            for path_str in input_paths:
                path = Path(path_str)
                if path.exists():
                    if path.is_file() and path.suffix.lower() == ".pdf":
                        paths.append(path)
                    elif path.is_dir():
                        paths.extend(self._find_pdfs_in_dir(path, recursive=recursive))
        else:
            paths.extend(self._find_pdfs_in_dir(Path.cwd(), recursive=recursive))

        if not paths:
            logger.error("未找到PDF文件")
            sys.exit(1)

        return sorted(paths)

    def _find_pdfs_in_dir(self, directory: Path, *, recursive: bool) -> List[Path]:
        """在目录中查找PDF文件.

        Parameters
        ----------
        directory : Path
            要搜索的目录
        recursive : bool
            是否递归搜索

        Returns
        -------
        List[Path]
            找到的PDF文件路径列表
        """
        pattern = "**/*.pdf" if recursive else "*.pdf"
        return list(directory.glob(pattern)) + list(directory.glob(pattern.upper()))

    def _resolve_output_path(
        self,
        input_path: Path,
        output_dir: Optional[str],
        suffix: str,
    ) -> Path:
        """解析输出路径.

        Parameters
        ----------
        input_path : Path
            输入文件路径
        output_dir : Optional[str]
            输出目录路径
        suffix : str
            输出文件后缀

        Returns
        -------
        Path
            解析后的输出文件路径
        """
        if output_dir:
            output_path = Path(output_dir) / input_path.name
            output_path = output_path.with_stem(input_path.stem)
            return output_path.with_suffix(suffix)
        return input_path.with_suffix(suffix)

    def _should_skip(self, output_path: Path, *, skip_existing: bool) -> bool:
        """判断是否应该跳过此文件.

        Parameters
        ----------
        output_path : Path
            输出文件路径
        skip_existing : bool
            是否跳过已存在文件

        Returns
        -------
        bool
            如果应该跳过则返回 True
        """
        if skip_existing and output_path.exists():
            if not self._quiet_mode:
                logger.info(f"  跳过(已存在): {output_path}")
            return True
        return False

    def _log_progress(self, input_path: Path, output_path: Path) -> None:
        """显示处理进度.

        Parameters
        ----------
        input_path : Path
            输入文件路径
        output_path : Path
            输出文件路径
        """
        if not self._quiet_mode:
            self._processed_files += 1
            progress = f"[{self._processed_files}/{self._total_files}]"
            logger.info(f"{progress} 处理: {input_path} -> {output_path}")

    def _init_progress(self, total: int) -> None:
        """初始化进度计数器.

        Parameters
        ----------
        total : int
            要处理的文件总数
        """
        self._total_files = total
        self._processed_files = 0
        if not self._quiet_mode:
            logger.info(f"找到 {total} 个PDF文件")

    def create_scheduler(self, args: argparse.Namespace) -> Optional[CommandScheduler]:
        """创建命令调度器.

        子类必须实现此方法.

        Parameters
        ----------
        args : argparse.Namespace
            解析后的命令行参数

        Returns
        -------
        CommandScheduler
            配置好的命令调度器
        """
        raise NotImplementedError("子类必须实现 create_scheduler 方法")
