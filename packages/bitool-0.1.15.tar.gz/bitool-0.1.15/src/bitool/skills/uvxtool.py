"""uvx 工具检查和 bitool 调用 skill.

提供检查 uv 安装状态，并通过 uvx 调用 bitool 所有工具的功能."""

from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

from bitool.cmd import CommandScheduler, RunCommand
from bitool.compat import tomllib
from bitool.core import JsonConfig, logger
from bitool.skills._base import BaseSkill


def get_pyproject_scripts() -> list[str]:
    """从 pyproject.toml 中解析 scripts 命令列表.

    Returns
    -------
    list[str]
        所有可用的 bitool 命令列表.
    """

    # 找到项目根目录的 pyproject.toml
    current_dir = Path(__file__).resolve().parent
    # 向上查找直到找到 pyproject.toml
    for parent in [current_dir, *list(current_dir.parents)]:
        pyproject_path = parent / "pyproject.toml"
        if pyproject_path.exists():
            try:
                with open(pyproject_path, "rb") as f:
                    pyproject = tomllib.load(f)
                    scripts = pyproject.get("project", {}).get("scripts", {})
                    # 返回所有脚本名称，排除 bitool 主命令和 uvxtool 本身
                    exclude = {"bitool", "uvxtool"}
                    return sorted([name for name in scripts if name not in exclude])
            except OSError as e:
                logger.warning(f"读取 pyproject.toml 失败: {e}")
                break

    # 如果无法读取，回退到静态注册表
    from bitool.commands_registry import get_all_commands

    return get_all_commands()


class UvToolConfig(JsonConfig):
    """uvx 工具调用配置类."""

    # 默认的 bitool 包名或路径
    DEFAULT_BITOOL_PACKAGE: str = "bitool"

    # 从 pyproject.toml 动态解析的命令列表
    _bitool_commands: list[str] = []

    @property
    def BITOOL_COMMANDS(self) -> list[str]:
        """获取所有可用的 bitool 命令列表."""
        if not self._bitool_commands:
            self._bitool_commands = get_pyproject_scripts()
        return self._bitool_commands


conf = UvToolConfig()


def check_uv_installed() -> bool:
    """检查 uv 是否安装.

    Returns
    -------
    bool
        如果 uv 安装了返回 True，否则返回 False.
    """
    return shutil.which("uv") is not None


def get_uv_version() -> str | None:
    """获取 uv 版本.

    Returns
    -------
    str | None
        uv 版本字符串，如果无法获取则返回 None.
    """
    from bitool.cmd import execute

    try:
        result = execute(
            ["uv", "--version"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (OSError, RuntimeError):
        logger.error("获取 uv 版本失败")
        return None
    else:
        return None


class UvxToolSkill(BaseSkill):
    """uvx 工具调用 skill 实现."""

    name = "uvxtool"
    description = "检查 uv 安装并通过 uvx 调用 bitool 工具"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数.

        Parameters
        ----------
        parser : argparse.ArgumentParser
            参数解析器.
        """
        parser.add_argument(
            "command",
            type=str,
            nargs="?",
            default=None,
            help="要调用的 bitool 命令，留空则列出所有可用命令",
        )
        parser.add_argument(
            "args",
            type=str,
            nargs="*",
            default=[],
            help="传递给 bitool 命令的参数",
        )
        parser.add_argument(
            "--check",
            action="store_true",
            default=False,
            help="仅检查 uv 是否安装",
        )
        parser.add_argument(
            "--package",
            type=str,
            default=conf.DEFAULT_BITOOL_PACKAGE,
            help=f"指定 bitool 包名或路径（默认：{conf.DEFAULT_BITOOL_PACKAGE}）",
        )
        parser.add_argument(
            "--list",
            action="store_true",
            default=False,
            help="列出所有可用的 bitool 命令",
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建命令调度器.

        Parameters
        ----------
        args : argparse.Namespace
            解析后的命令行参数.

        Returns
        -------
        CommandScheduler
            配置好的命令调度器.
        """
        commands = []

        # 检查 uv 是否安装
        def check_uv() -> None:
            logger.info("正在检查 uv 安装状态...")
            if check_uv_installed():
                version = get_uv_version()
                if version:
                    logger.info(f"✓ uv 已安装: {version}")
                else:
                    logger.info("✓ uv 已安装")
            else:
                logger.error("✗ uv 未安装！")
                logger.info("  请访问 https://astral.sh/uv 安装 uv")
                sys.exit(1)

        commands.append(RunCommand(cmd=check_uv))

        # 如果是 --check 模式，只检查不继续执行
        if args.check:
            return CommandScheduler(commands=commands)

        # 如果是 --list 模式，列出所有可用命令
        if args.list:

            def list_commands() -> None:
                logger.info("可用的 bitool 命令:")
                logger.info("-" * 60)
                for cmd in conf.BITOOL_COMMANDS:
                    logger.info(f"  - {cmd}")
                logger.info("-" * 60)
                logger.info(f"共 {len(conf.BITOOL_COMMANDS)} 个命令")

            commands.append(RunCommand(cmd=list_commands))
            return CommandScheduler(commands=commands)

        # 如果没有指定命令，显示帮助
        if args.command is None:

            def show_help() -> None:
                logger.info("使用方式:")
                logger.info("  uvxtool [命令] [参数]")
                logger.info("")
                logger.info("示例:")
                logger.info("  uvxtool --check          # 仅检查 uv 安装")
                logger.info("  uvxtool --list           # 列出所有命令")
                logger.info("  uvxtool pymake help      # 通过 uvx 调用 pymake help")
                logger.info(
                    "  uvxtool wch python       # 通过 uvx 调用 which 查找 python",
                )

            commands.append(RunCommand(cmd=show_help))
            return CommandScheduler(commands=commands)

        # 验证命令是否有效
        if args.command not in conf.BITOOL_COMMANDS:
            logger.error(f"无效的命令: {args.command}")
            logger.info("使用 --list 查看所有可用命令")
            sys.exit(1)

        # 通过 uvx 调用 bitool 命令
        def run_with_uvx() -> None:
            from bitool.cmd import execute

            package = args.package
            bitool_cmd = args.command
            bitool_args = args.args

            # 构建 uvx 命令
            uvx_cmd = ["uvx", package, bitool_cmd, *bitool_args]

            logger.info(f"执行: {' '.join(uvx_cmd)}")
            logger.info("-" * 60)

            try:
                # 使用 execute 执行命令
                result = execute(
                    uvx_cmd,
                    check=False,
                )

                logger.info("-" * 60)
                if result.returncode == 0:
                    logger.info("✓ 命令执行成功")
                else:
                    logger.warning(f"⚠ 命令执行完成，返回码: {result.returncode}")

            except Exception as e:  # noqa: BLE001
                logger.error(f"✗ 执行失败: {e}")
                sys.exit(1)

        commands.append(RunCommand(cmd=run_with_uvx))
        return CommandScheduler(commands=commands)


def main() -> None:
    """主函数入口."""
    skill = UvxToolSkill()
    skill.run_cli()


if __name__ == "__main__":
    main()
