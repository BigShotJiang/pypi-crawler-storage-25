"""设置 Rust 国内镜像环境变量.

配置 Rustup 和 Cargo 的国内镜像源,
加速 Rust 工具链和依赖包的下载.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from bitool.cmd import (
    BuiltinConditions,
    CommandScheduler,
    RunCommand,
    SetEnvCommand,
    WriteFileCommand,
)
from bitool.core import JsonConfig
from bitool.skills._base import BaseSkill


class EnvRsConfig(JsonConfig):
    """EnvRs 配置类."""

    DEFAULT_INSTALL_VERSION: str = "nightly"
    DEFAULT_MIRROR: str = "aliyun"

    RUSTUP_MIRRORS: dict[str, dict[str, str]] = {
        "aliyun": {
            "RUSTUP_DIST_SERVER": "https://mirrors.aliyun.com/rustup",
            "RUSTUP_UPDATE_ROOT": "https://mirrors.aliyun.com/rustup/rustup",
            "TOML_REGISTRY": "https://mirrors.aliyun.com/crates.io-index/",
        },
        "ustc": {
            "RUSTUP_DIST_SERVER": "https://mirrors.ustc.edu.cn/rust-static",
            "RUSTUP_UPDATE_ROOT": "https://mirrors.ustc.edu.cn/rust-static/rustup",
            "TOML_REGISTRY": "https://mirrors.ustc.edu.cn/crates.io-index/",
        },
        "tsinghua": {
            "RUSTUP_DIST_SERVER": "https://mirrors.tuna.tsinghua.edu.cn/rustup",
            "RUSTUP_UPDATE_ROOT": "https://mirrors.tuna.tsinghua.edu.cn/rustup/rustup",
            "TOML_REGISTRY": "https://mirrors.tuna.tsinghua.edu.cn/crates.io-index/",
        },
    }

    RUSTUP_DOWNLOAD_URL: str = "https://static.rust-lang.org/rustup/dist/x86_64-pc-windows-msvc/rustup-init.exe"


conf = EnvRsConfig()


class EnvRsSkill(BaseSkill):
    """Rust 环境配置技能."""

    name = "envrs"
    description = "设置 Rust 国内镜像环境变量"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加版本参数."""
        parser.add_argument(
            "version",
            type=str,
            nargs="?",
            default=conf.DEFAULT_INSTALL_VERSION,
            help="Rust 版本",
        )
        parser.add_argument(
            "--mirror",
            "-m",
            type=str,
            nargs="?",
            choices=conf.RUSTUP_MIRRORS.keys(),
            default=conf.DEFAULT_MIRROR,
            help="Rust 镜像源",
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建 Rust 环境配置调度器."""
        mirror_dict = conf.RUSTUP_MIRRORS.get(args.mirror, {})
        server = mirror_dict.get("RUSTUP_DIST_SERVER", "")
        update_root = mirror_dict.get("RUSTUP_UPDATE_ROOT", "")
        toml_registry = mirror_dict.get("TOML_REGISTRY", "")
        toml_content = f"""\
[source.crates-io]
replace-with = '{args.mirror}'

[source.{args.mirror}]
registry = "sparse+{toml_registry}"

[registries.{args.mirror}]
index = "sparse+{toml_registry}"
        """

        return CommandScheduler(
            commands=[
                SetEnvCommand(
                    envs=[
                        ("RUSTUP_DIST_SERVER", server),
                        ("RUSTUP_UPDATE_ROOT", update_root),
                    ],
                ),
                RunCommand(
                    cmd=[
                        "powershell",
                        "-Command",
                        "Invoke-WebRequest",
                        "-Uri",
                        conf.RUSTUP_DOWNLOAD_URL,
                        "-OutFile",
                        "rustup-init.exe",
                    ],
                    allow_conditions=[
                        BuiltinConditions.IS_WINDOWS,
                        BuiltinConditions.HAS_APP_INSTALLED("rustup"),
                    ],
                    forbid_conditions=[
                        BuiltinConditions.HAS_ENTRY_IN_DIR(
                            "rustup-init.exe",
                            Path.cwd(),
                        ),
                    ],
                    timeout=240,
                ),
                RunCommand(
                    cmd=[
                        "curl",
                        "-fsSL",
                        "https://mirrors.aliyun.com/repo/rust/rustup-init.sh",
                        "-o",
                        "rustup-init.sh",
                    ],
                    cwd=Path.cwd(),
                    forbid_conditions=[BuiltinConditions.IS_WINDOWS],
                    timeout=300,
                    check=True,
                ),
                RunCommand(
                    cmd=["test", "-f", "rustup-init.sh"],
                    cwd=Path.cwd(),
                    forbid_conditions=[BuiltinConditions.IS_WINDOWS],
                    timeout=10,
                    check=True,
                ),
                RunCommand(
                    cmd=["sh", "rustup-init.sh"],
                    cwd=Path.cwd(),
                    forbid_conditions=[BuiltinConditions.IS_WINDOWS],
                    timeout=300,
                    check=True,
                ),
                WriteFileCommand(
                    filepath=Path.home() / ".cargo" / "config.toml",
                    content=toml_content,
                ),
                RunCommand(cmd=["rustup", "toolchain", "install", args.version]),
            ],
        )


def main() -> None:
    """主函数入口."""
    skill = EnvRsSkill()
    skill.run_cli()


if __name__ == "__main__":
    main()
