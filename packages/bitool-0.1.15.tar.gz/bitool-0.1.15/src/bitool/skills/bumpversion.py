"""版本号自动管理工具.

使用 CommandScheduler 模式实现, 支持语义化版本管理和多文件格式的版本号更新.
"""

from __future__ import annotations

import argparse
from functools import partial
from typing import ClassVar

from bitool.cmd import CommandScheduler
from bitool.cmd.version import BumpVersionCommand
from bitool.core import JsonConfig
from bitool.skills._base import BaseSkill


class BumpversionConfig(JsonConfig):
    """Bumpversion 配置类."""

    # 排除的目录
    EXCLUDED_DIRS: set[str] = {
        "__pycache__",
        ".venv",
        "venv",
        "env",
        ".git",
        "dist",
        "build",
        ".tox",
        ".pytest_cache",
        "node_modules",
    }


class BumpVersionSkill(BaseSkill):
    """版本号管理技能."""

    name = "bumpversion"
    description = "版本号自动管理工具 (支持语义化版本和多文件格式)"
    epilog = """示例:
  bumpversion patch          # 递增补丁号 (1.0.0 -> 1.0.1)
  bumpversion minor          # 递增次版本号 (1.0.0 -> 1.1.0)
  bumpversion major          # 递增主版本号 (1.0.0 -> 2.0.0)
  bumpversion patch-alpha    # 递增补丁号并添加 alpha 预发布标识
  bumpversion patch -t       # 递增补丁号并创建 Git 标签
  bumpversion minor -c -t    # 递增次版本号、提交并打标签"""
    config = BumpversionConfig()

    # 支持的操作选项
    options: ClassVar[list[str]] = ["patch", "minor", "major", "patch-alpha"]

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "action",
            nargs="?",
            default="patch",
            choices=self.options,
            type=str,
            help="要执行的操作, 可选值: " + ", ".join(self.options),
        )
        parser.add_argument(
            "-t",
            "--tag",
            action="store_true",
            default=False,
            help="递增版本号后创建 Git 标签",
        )
        parser.add_argument(
            "-c",
            "--commit",
            action="store_true",
            default=False,
            help="递增版本号后提交更改到 Git",
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建命令调度器.

        Parameters
        ----------
        args : argparse.Namespace
            解析后的命令行参数

        Returns
        -------
        CommandScheduler
            配置好的命令调度器
        """
        func = partial(
            BumpVersionCommand,
            tag=args.tag,
            commit=args.commit,
        )

        scheduler_map = {
            # === 版本号递增命令 ===
            # 递增补丁号 (1.0.0 -> 1.0.1)
            "patch": CommandScheduler(commands=[func(part="patch")]),
            # 递增次版本号 (1.0.0 -> 1.1.0)
            "minor": CommandScheduler(commands=[func(part="minor")]),
            # 递增主版本号 (1.0.0 -> 2.0.0)
            "major": CommandScheduler(commands=[func(part="major")]),
            # 递增补丁号并设置预发布标识 (1.0.0 -> 1.0.1-alpha)
            "patch-alpha": CommandScheduler(
                commands=[func(part="patch", prerelease="alpha")],
            ),
        }
        return scheduler_map.get(args.action, CommandScheduler())


def main() -> None:
    """主函数入口."""
    skill = BumpVersionSkill()
    skill.run_cli()
