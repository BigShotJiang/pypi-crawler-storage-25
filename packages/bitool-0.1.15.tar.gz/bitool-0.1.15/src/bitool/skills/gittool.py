"""Git 工具模块.

提供 Git 仓库管理的常用操作封装,
支持初始化、提交、清理、推送等功能.
"""

from __future__ import annotations

import os
from pathlib import Path

from bitool.cmd import CommandScheduler, RunCommand
from bitool.core import JsonConfig
from bitool.skills._base import MapSkill
from bitool.utils import execute


class GitToolConfig(JsonConfig):
    """Git工具配置类."""

    # 待清理缓存目录
    CACHE_DIRS: list[str] = [
        ".coverage",
        ".benchmarks",
        ".ruff_cache",
        ".pytest_cache",
        ".mypy_cache",
        "__pycache__",
        ".hypothesis",
        "htmlcov",
    ]

    # 编辑器配置目录
    EDITOR_CONFIG_DIRS: list[str] = [
        ".vscode",
        ".idea",
        ".editorconfig",
        ".trae",
        ".qoder",
    ]

    # 排除的待清理目录
    EXCLUDE_DIRS: list[str] = [
        ".venv",
        ".tox",
        "node_modules",
        ".git",
        *EDITOR_CONFIG_DIRS,
    ]


class GitToolSkill(MapSkill):
    """Git 工具技能."""

    name = "gittool"
    description = "Git仓库管理的常用操作"
    config = GitToolConfig

    def create_scheduler_map(self) -> dict[str, CommandScheduler] | None:
        """创建命令调度器映射."""
        exclude_dir_cmds = [arg for d in self.config.EXCLUDE_DIRS for arg in ["-e", d]]

        def init_subdirs() -> None:
            """初始化子目录的Git仓库."""
            origin = Path.cwd()
            subdirs = [d for d in Path.cwd().iterdir() if d.is_dir()]
            for subdir in subdirs:
                os.chdir(str(subdir))
                execute(
                    [
                        ["git", "init"],
                        ["git", "add", "."],
                        ["git", "commit", "-m", "init commit"],
                    ],
                )
            os.chdir(str(origin))

        return {
            # 添加并提交
            "a": CommandScheduler(
                commands=[
                    RunCommand(
                        name="add",
                        cmd=["git", "add", "."],
                        description="将所有更改添加到暂存区",
                    ),
                    RunCommand(
                        name="commit",
                        cmd=["git", "commit", "-m", "chore: update"],
                        description="提交所有更改",
                        dependencies=["add"],
                    ),
                ],
            ),
            # 清理工作区并显示状态
            "c": CommandScheduler(
                commands=[
                    RunCommand(
                        name="clean",
                        cmd=["git", "clean", "-xfd", *exclude_dir_cmds],
                        description=f"清理工作区, 排除清理目录: `{exclude_dir_cmds}`",
                    ),
                    RunCommand(
                        name="status",
                        cmd=["git", "status", "--porcelain"],
                        description="显示状态",
                    ),
                ],
            ),
            # 初始化、添加并提交
            "i": CommandScheduler(
                commands=[
                    RunCommand(
                        name="init",
                        cmd=["git", "init"],
                        description="初始化Git仓库",
                        forbid_conditions=[
                            (
                                lambda: ".git" in [d.name for d in Path.cwd().iterdir() if d.is_dir()],
                                "Git仓库已初始化",
                            ),
                        ],
                    ),
                    RunCommand(
                        name="add",
                        cmd=["git", "add", "."],
                        description="将所有更改添加到暂存区",
                        forbid_conditions=[
                            (lambda: not Path.cwd().glob("*"), "没有文件可添加"),
                        ],
                        dependencies=["init"],
                    ),
                    RunCommand(
                        name="commit",
                        cmd=["git", "commit", "-m", "chore: update"],
                        description="提交所有更改",
                        forbid_conditions=[
                            (lambda: not Path.cwd().glob("*"), "没有文件可提交"),
                        ],
                        dependencies=["add"],
                    ),
                ],
            ),
            # 初始化子目录
            "isub": CommandScheduler(
                commands=[
                    RunCommand(
                        name="init_subdirs",
                        cmd=init_subdirs,
                        description="初始化子目录的Git仓库",
                    ),
                ],
            ),
            # 推送更改到远程仓库
            "p": CommandScheduler(
                commands=[
                    RunCommand(
                        name="push",
                        cmd=["git", "push"],
                        description="推送更改到远程仓库",
                    ),
                ],
            ),
            # 从远程仓库拉取最新更改
            "pl": CommandScheduler(
                commands=[
                    RunCommand(
                        name="pull",
                        cmd=["git", "pull"],
                        description="从远程仓库拉取最新更改",
                    ),
                ],
            ),
            # 重启tgitcache服务
            "r": CommandScheduler(
                commands=[
                    RunCommand(
                        name="重启tgitcache",
                        cmd=["taskkill", "/f", "/t", "/im", "tgitcache.exe"],
                        description="重启tgitcache服务(如果正在运行)",
                    ),
                ],
            ),
        }


def main() -> None:
    """Git工具主函数."""
    GitToolSkill().run_cli()
