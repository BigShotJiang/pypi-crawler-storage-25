"""测试 Skill 基础类模块."""

from __future__ import annotations

import argparse
from unittest.mock import MagicMock, patch

from bitool.cmd import CommandScheduler
from bitool.core import JsonConfig
from bitool.skills._base import BaseSkill
from bitool.skills._registry import MultiCommandSkill


class ConcreteSkill(BaseSkill):
    """用于测试的具体 Skill 实现."""

    name = "test-skill"
    description = "测试技能"
    config = JsonConfig()

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument("value", nargs="?", default="default")
        parser.add_argument("--flag", action="store_true", default=False)

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建命令调度器."""
        return CommandScheduler(commands=[])


class TestBaseSkill:
    """测试 BaseSkill 基类."""

    def test_skill_name(self) -> None:
        """测试技能名称."""
        skill = ConcreteSkill()
        assert skill.name == "test-skill"

    def test_skill_description(self) -> None:
        """测试技能描述."""
        skill = ConcreteSkill()
        assert skill.description == "测试技能"

    def test_run_success(self) -> None:
        """测试成功运行."""
        skill = ConcreteSkill()
        exit_code = skill._run([])
        # 空命令列表返回 1 (见 CommandScheduler.run)
        assert exit_code == 1

    def test_run_with_custom_args(self) -> None:
        """测试使用自定义参数运行."""
        skill = ConcreteSkill()
        exit_code = skill._run(["test_value"])
        # 空命令列表返回 1
        assert exit_code == 1

    @patch.object(ConcreteSkill, "create_scheduler")
    def test_run_scheduler_failure(self, mock_create: MagicMock) -> None:
        """测试调度器执行失败."""
        mock_scheduler = MagicMock()
        mock_scheduler.run.return_value = False
        mock_create.return_value = mock_scheduler

        skill = ConcreteSkill()
        exit_code = skill._run([])
        assert exit_code == 1

    @patch("sys.exit")
    def test_run_cli(self, mock_exit: MagicMock) -> None:
        """测试 CLI 运行."""
        skill = ConcreteSkill()
        skill.run_cli([])
        # 空命令列表返回 1
        mock_exit.assert_called_once_with(1)


class TestMultiCommandSkill:
    """测试 MultiCommandSkill 多命令技能."""

    def test_register_command(self) -> None:
        """测试注册子命令."""

        class MultiSkill(MultiCommandSkill):
            name = "multi"
            description = "多命令技能"

            def __init__(self) -> None:
                super().__init__()
                self.register("cmd1", lambda: CommandScheduler(commands=[]), "命令1")
                self.register("cmd2", lambda: CommandScheduler(commands=[]), "命令2")

        skill = MultiSkill()
        assert "cmd1" in skill.list_commands()
        assert "cmd2" in skill.list_commands()

    def test_get_scheduler(self) -> None:
        """测试获取子命令调度器."""

        class MultiSkill(MultiCommandSkill):
            name = "multi"
            description = "多命令技能"

            def __init__(self) -> None:
                super().__init__()
                self.register("cmd1", lambda: CommandScheduler(commands=[]), "命令1")

        skill = MultiSkill()
        scheduler = skill.get_scheduler("cmd1")
        assert scheduler is not None
        assert isinstance(scheduler, CommandScheduler)

    def test_get_scheduler_not_found(self) -> None:
        """测试获取不存在的子命令."""

        class MultiSkill(MultiCommandSkill):
            name = "multi"
            description = "多命令技能"

            def __init__(self) -> None:
                super().__init__()

        skill = MultiSkill()
        scheduler = skill.get_scheduler("nonexistent")
        assert scheduler is None

    def test_list_commands(self) -> None:
        """测试列出所有子命令."""

        class MultiSkill(MultiCommandSkill):
            name = "multi"
            description = "多命令技能"

            def __init__(self) -> None:
                super().__init__()
                self.register("a", lambda: CommandScheduler(commands=[]))
                self.register("b", lambda: CommandScheduler(commands=[]))
                self.register("c", lambda: CommandScheduler(commands=[]))

        skill = MultiSkill()
        commands = skill.list_commands()
        assert len(commands) == 3
        assert "a" in commands
        assert "b" in commands
        assert "c" in commands

    def test_get_command_description(self) -> None:
        """测试获取子命令描述."""

        class MultiSkill(MultiCommandSkill):
            name = "multi"
            description = "多命令技能"

            def __init__(self) -> None:
                super().__init__()
                self.register("cmd1", lambda: CommandScheduler(commands=[]), "测试命令")

        skill = MultiSkill()
        desc = skill.get_command_description("cmd1")
        assert desc == "测试命令"

    def test_get_command_description_not_found(self) -> None:
        """测试获取不存在的子命令描述."""

        class MultiSkill(MultiCommandSkill):
            name = "multi"
            description = "多命令技能"

            def __init__(self) -> None:
                super().__init__()

        skill = MultiSkill()
        desc = skill.get_command_description("nonexistent")
        assert desc == ""
