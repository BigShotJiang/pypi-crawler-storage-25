"""PDF处理技能综合测试.

测试所有新增的PDF处理技能: reorder, crop, ocr, compare, attach, layout, repair.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Generator
from unittest.mock import patch

import pytest

try:
    import fitz

    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False

try:
    import importlib.util

    HAS_OCR = importlib.util.find_spec("pytesseract") is not None
except ImportError:
    HAS_OCR = False


@pytest.fixture
def temp_workspace(tmp_path: Path) -> Generator[Path, None, None]:
    """创建临时工作目录并切换."""
    original_cwd = Path.cwd()
    os.chdir(tmp_path)
    yield tmp_path
    os.chdir(original_cwd)


def _create_test_pdf(pdf_path: Path, pages: int = 3, text: str = "Test Page") -> None:
    """创建测试PDF的辅助函数."""
    if not HAS_PYMUPDF:
        return

    doc = fitz.open()
    for i in range(pages):
        blank = fitz.open()
        blank.new_page(width=595, height=842)
        doc.insert_pdf(blank)
        page = doc[-1]
        page.insert_textbox((100, 100, 500, 700), f"{text} {i + 1}")
        blank.close()
    doc.save(str(pdf_path))
    doc.close()


@pytest.fixture(scope="session")
def session_sample_pdf(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """创建会话级示例PDF."""
    if not HAS_PYMUPDF:
        pytest.skip("PyMuPDF未安装")

    tmp_path = Path(tmp_path_factory.mktemp("sample_pdf"))
    pdf_path = tmp_path / "sample.pdf"
    _create_test_pdf(pdf_path, pages=3, text="Sample Page")
    return pdf_path


@pytest.fixture(scope="session")
def session_multi_page_pdf(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """创建会话级多页PDF."""
    if not HAS_PYMUPDF:
        pytest.skip("PyMuPDF未安装")

    tmp_path = Path(tmp_path_factory.mktemp("multi_page_pdf"))
    pdf_path = tmp_path / "multi_page.pdf"
    _create_test_pdf(pdf_path, pages=5, text="Page")
    return pdf_path


@pytest.fixture
def sample_pdf(session_sample_pdf: Path, tmp_path: Path) -> Path:
    """创建示例PDF的拷贝."""
    import shutil

    dest = tmp_path / session_sample_pdf.name
    shutil.copy2(session_sample_pdf, dest)
    return dest


@pytest.fixture
def multi_page_pdf(session_multi_page_pdf: Path, tmp_path: Path) -> Path:
    """创建多页PDF的拷贝."""
    import shutil

    dest = tmp_path / session_multi_page_pdf.name
    shutil.copy2(session_multi_page_pdf, dest)
    return dest


@pytest.mark.skipif(not HAS_PYMUPDF, reason="需要PyMuPDF库")
class TestPdfReorder:
    """测试PdfReorderSkill."""

    def test_create_scheduler(self, sample_pdf: Path, tmp_path: Path) -> None:
        """测试创建调度器."""
        import argparse

        from bitool.skills.pdfutils.pdfreorder import PdfReorderSkill

        args = argparse.Namespace(
            input_path=str(sample_pdf),
            output=str(tmp_path / "reordered.pdf"),
            reorder="",
            delete="1",
            insert="",
        )
        scheduler = PdfReorderSkill().create_scheduler(args)
        assert scheduler is not None
        assert len(scheduler.commands) == 1

    def test_delete_pages(self, sample_pdf: Path, tmp_path: Path) -> None:
        """测试删除页面."""
        from bitool.skills.pdfutils.pdfreorder import PdfReorderCommand

        cmd = PdfReorderCommand(
            input_path=sample_pdf,
            output_path=tmp_path / "deleted.pdf",
            page_order="",
            delete_pages="1",
            insert_pages="",
        )
        result = cmd.run()
        assert result is True

    def test_insert_blank_pages(self, sample_pdf: Path, tmp_path: Path) -> None:
        """测试插入空白页."""
        from bitool.skills.pdfutils.pdfreorder import PdfReorderCommand

        cmd = PdfReorderCommand(
            input_path=sample_pdf,
            output_path=tmp_path / "inserted.pdf",
            page_order="",
            delete_pages="",
            insert_pages="1:2",
        )
        result = cmd.run()
        assert result is True

    def test_parse_page_range(self, sample_pdf: Path) -> None:
        """测试页面范围解析."""
        from bitool.skills.pdfutils.pdfreorder import PdfReorderCommand

        cmd = PdfReorderCommand(
            input_path=sample_pdf,
            output_path=Path(),
            page_order="",
            delete_pages="",
            insert_pages="",
        )
        pages = cmd._parse_page_range("1,2-4,7", 10)
        assert 0 in pages
        assert 1 in pages
        assert 2 in pages
        assert 3 in pages
        assert 6 in pages

    def test_pymupdf_not_installed(self, tmp_path: Path) -> None:
        """测试PyMuPDF未安装时的错误处理."""
        with patch("bitool.skills.pdfutils.pdfreorder.HAS_PYMUPDF", new=False):
            from bitool.skills.pdfutils.pdfreorder import PdfReorderCommand

            cmd = PdfReorderCommand(
                input_path=tmp_path / "test.pdf",
                output_path=tmp_path / "output.pdf",
                page_order="",
                delete_pages="",
                insert_pages="",
            )
            result = cmd.run()
            assert result is False

    def test_file_not_exists(self, tmp_path: Path) -> None:
        """测试文件不存在."""
        from bitool.skills.pdfutils.pdfreorder import PdfReorderCommand

        cmd = PdfReorderCommand(
            input_path=tmp_path / "nonexistent.pdf",
            output_path=tmp_path / "output.pdf",
            page_order="",
            delete_pages="",
            insert_pages="",
        )
        result = cmd.run()
        assert result is False


@pytest.mark.skipif(not HAS_PYMUPDF, reason="需要PyMuPDF库")
class TestPdfCrop:
    """测试PdfCropSkill."""

    def test_create_scheduler(self, sample_pdf: Path, tmp_path: Path) -> None:
        """测试创建调度器."""
        import argparse

        from bitool.skills.pdfutils.pdfcrop import PdfCropSkill

        args = argparse.Namespace(
            input_paths=[str(sample_pdf)],
            output=str(tmp_path / "cropped.pdf"),
            output_dir=None,
            recursive=False,
            quiet=False,
            skip_existing=False,
            auto=False,
            margin=0,
            left=50,
            right=50,
            top=50,
            bottom=50,
        )
        scheduler = PdfCropSkill().create_scheduler(args)
        assert scheduler is not None

    def test_crop_with_margins(self, sample_pdf: Path, tmp_path: Path) -> None:
        """测试手动裁剪."""
        from bitool.skills.pdfutils.pdfcrop import PdfCropCommand

        cmd = PdfCropCommand(
            input_path=sample_pdf,
            output_path=tmp_path / "cropped.pdf",
            left=50,
            right=50,
            top=50,
            bottom=50,
            auto=False,
            margin=0,
        )
        result = cmd.run()
        assert result is True
        assert (tmp_path / "cropped.pdf").exists()

    def test_pymupdf_not_installed(self, tmp_path: Path) -> None:
        """测试PyMuPDF未安装时的错误处理."""
        with patch("bitool.skills.pdfutils.pdfcrop.HAS_PYMUPDF", new=False):
            from bitool.skills.pdfutils.pdfcrop import PdfCropCommand

            cmd = PdfCropCommand(
                input_path=tmp_path / "test.pdf",
                output_path=tmp_path / "output.pdf",
                left=0,
                right=0,
                top=0,
                bottom=0,
                auto=False,
                margin=0,
            )
            result = cmd.run()
            assert result is False

    def test_file_not_exists(self, tmp_path: Path) -> None:
        """测试文件不存在."""
        from bitool.skills.pdfutils.pdfcrop import PdfCropCommand

        cmd = PdfCropCommand(
            input_path=tmp_path / "nonexistent.pdf",
            output_path=tmp_path / "output.pdf",
            left=0,
            right=0,
            top=0,
            bottom=0,
            auto=False,
            margin=0,
        )
        result = cmd.run()
        assert result is False


@pytest.mark.skipif(not HAS_OCR, reason="需要OCR库(tesseract)")
class TestPdfOcr:
    """测试PdfOcrSkill."""

    def test_create_scheduler(self, sample_pdf: Path, tmp_path: Path) -> None:
        """测试创建调度器."""
        import argparse

        from bitool.skills.pdfutils.pdfocr import PdfOcrSkill

        args = argparse.Namespace(
            input_path=str(sample_pdf),
            output=str(tmp_path / "ocr.pdf"),
            lang="eng",
        )
        scheduler = PdfOcrSkill().create_scheduler(args)
        assert scheduler is not None


@pytest.mark.skipif(not HAS_PYMUPDF, reason="需要PyMuPDF库")
class TestPdfCompare:
    """测试PdfCompareSkill."""

    def test_create_scheduler(
        self,
        sample_pdf: Path,
        multi_page_pdf: Path,
        tmp_path: Path,
    ) -> None:
        """测试创建调度器."""
        import argparse

        from bitool.skills.pdfutils.pdfcompare import PdfCompareSkill

        args = argparse.Namespace(
            input_path1=str(sample_pdf),
            input_path2=str(multi_page_pdf),
            output=str(tmp_path / "diff.pdf"),
        )
        scheduler = PdfCompareSkill().create_scheduler(args)
        assert scheduler is not None

    def test_pymupdf_not_installed(self, tmp_path: Path) -> None:
        """测试PyMuPDF未安装时的错误处理."""
        with patch("bitool.skills.pdfutils.pdfcompare.HAS_PYMUPDF", new=False):
            from bitool.skills.pdfutils.pdfcompare import PdfCompareCommand

            cmd = PdfCompareCommand(
                input_path1=tmp_path / "test1.pdf",
                input_path2=tmp_path / "test2.pdf",
                output_path=tmp_path / "output.pdf",
            )
            result = cmd.run()
            assert result is False


@pytest.mark.skipif(not HAS_PYMUPDF, reason="需要PyMuPDF库")
class TestPdfAttach:
    """测试PdfAttachSkill."""

    def test_create_scheduler_add(self, sample_pdf: Path, tmp_path: Path) -> None:
        """测试创建添加附件的调度器."""
        import argparse

        from bitool.skills.pdfutils.pdfattach import PdfAttachSkill

        test_file = tmp_path / "attachment.txt"
        test_file.write_text("test content")

        args = argparse.Namespace(
            action="add",
            input_path=str(sample_pdf),
            output=str(tmp_path / "attached.pdf"),
            files=[str(test_file)],
            dir="attachments",
        )
        scheduler = PdfAttachSkill().create_scheduler(args)
        assert scheduler is not None

    def test_create_scheduler_extract(self, sample_pdf: Path, tmp_path: Path) -> None:
        """测试创建提取附件的调度器."""
        import argparse

        from bitool.skills.pdfutils.pdfattach import PdfAttachSkill

        args = argparse.Namespace(
            action="extract",
            input_path=str(sample_pdf),
            output=None,
            files=[],
            dir=str(tmp_path / "attachments"),
        )
        scheduler = PdfAttachSkill().create_scheduler(args)
        assert scheduler is not None

    def test_extract_attachment(self, sample_pdf: Path, tmp_path: Path) -> None:
        """测试提取附件."""
        from bitool.skills.pdfutils.pdfattach import PdfAttachCommand

        cmd = PdfAttachCommand(
            input_path=sample_pdf,
            output_path=Path(),
            action="extract",
            extract_dir=str(tmp_path / "attachments"),
        )
        result = cmd.run()
        assert result is True

    def test_pymupdf_not_installed(self, tmp_path: Path) -> None:
        """测试PyMuPDF未安装时的错误处理."""
        with patch("bitool.skills.pdfutils.pdfattach.HAS_PYMUPDF", new=False):
            from bitool.skills.pdfutils.pdfattach import PdfAttachCommand

            cmd = PdfAttachCommand(
                input_path=tmp_path / "test.pdf",
                output_path=tmp_path / "output.pdf",
                action="add",
                attach_files=[],
                extract_dir="",
            )
            result = cmd.run()
            assert result is False


@pytest.mark.skipif(not HAS_PYMUPDF, reason="需要PyMuPDF库")
class TestPdfLayout:
    """测试PdfLayoutSkill."""

    def test_create_scheduler(self, sample_pdf: Path, tmp_path: Path) -> None:
        """测试创建调度器."""
        import argparse

        from bitool.skills.pdfutils.pdflayout import PdfLayoutSkill

        args = argparse.Namespace(
            input_path=str(sample_pdf),
            output=str(tmp_path / "layout.pdf"),
            pagesize="a4",
            orientation="landscape",
            margin_left=20,
            margin_right=20,
            margin_top=20,
            margin_bottom=20,
        )
        scheduler = PdfLayoutSkill().create_scheduler(args)
        assert scheduler is not None

    def test_change_orientation(self, sample_pdf: Path, tmp_path: Path) -> None:
        """测试修改页面方向."""
        from bitool.skills.pdfutils.pdflayout import PdfLayoutCommand

        cmd = PdfLayoutCommand(
            input_path=sample_pdf,
            output_path=tmp_path / "landscape.pdf",
            pagesize="",
            margin_left=0,
            margin_right=0,
            margin_top=0,
            margin_bottom=0,
            orientation="landscape",
        )
        result = cmd.run()
        assert result is True

    def test_add_margins(self, sample_pdf: Path, tmp_path: Path) -> None:
        """测试添加边距."""
        from bitool.skills.pdfutils.pdflayout import PdfLayoutCommand

        cmd = PdfLayoutCommand(
            input_path=sample_pdf,
            output_path=tmp_path / "margins.pdf",
            pagesize="",
            margin_left=50,
            margin_right=50,
            margin_top=50,
            margin_bottom=50,
            orientation="",
        )
        result = cmd.run()
        assert result is True

    def test_pymupdf_not_installed(self, tmp_path: Path) -> None:
        """测试PyMuPDF未安装时的错误处理."""
        with patch("bitool.skills.pdfutils.pdflayout.HAS_PYMUPDF", new=False):
            from bitool.skills.pdfutils.pdflayout import PdfLayoutCommand

            cmd = PdfLayoutCommand(
                input_path=tmp_path / "test.pdf",
                output_path=tmp_path / "output.pdf",
                pagesize="a4",
                margin_left=0,
                margin_right=0,
                margin_top=0,
                margin_bottom=0,
                orientation="",
            )
            result = cmd.run()
            assert result is False

    def test_file_not_exists(self, tmp_path: Path) -> None:
        """测试文件不存在."""
        from bitool.skills.pdfutils.pdflayout import PdfLayoutCommand

        cmd = PdfLayoutCommand(
            input_path=tmp_path / "nonexistent.pdf",
            output_path=tmp_path / "output.pdf",
            pagesize="a4",
            margin_left=0,
            margin_right=0,
            margin_top=0,
            margin_bottom=0,
            orientation="",
        )
        result = cmd.run()
        assert result is False


@pytest.mark.skipif(not HAS_PYMUPDF, reason="需要PyMuPDF库")
class TestPdfRepair:
    """测试PdfRepairSkill."""

    def test_create_scheduler(self, sample_pdf: Path, tmp_path: Path) -> None:
        """测试创建调度器."""
        import argparse

        from bitool.skills.pdfutils.pdfrepair import PdfRepairSkill

        args = argparse.Namespace(
            input_path=str(sample_pdf),
            output=str(tmp_path / "repaired.pdf"),
        )
        scheduler = PdfRepairSkill().create_scheduler(args)
        assert scheduler is not None

    def test_pymupdf_not_installed(self, tmp_path: Path) -> None:
        """测试PyMuPDF未安装时的错误处理."""
        with patch("bitool.skills.pdfutils.pdfrepair.HAS_PYMUPDF", new=False):
            from bitool.skills.pdfutils.pdfrepair import PdfRepairCommand

            cmd = PdfRepairCommand(
                input_path=tmp_path / "test.pdf",
                output_path=tmp_path / "output.pdf",
            )
            result = cmd.run()
            assert result is False

    def test_file_not_exists(self, tmp_path: Path) -> None:
        """测试文件不存在."""
        from bitool.skills.pdfutils.pdfrepair import PdfRepairCommand

        cmd = PdfRepairCommand(
            input_path=tmp_path / "nonexistent.pdf",
            output_path=tmp_path / "output.pdf",
        )
        result = cmd.run()
        assert result is False


class TestPdfSkillsConfig:
    """测试各个技能的配置文件."""

    def test_pdfreorder_config(self) -> None:
        """测试PdfReorderConfig."""
        from bitool.skills.pdfutils.pdfreorder import PdfReorderConfig

        config = PdfReorderConfig()
        assert config.OUTPUT_SUFFIX == ".reordered.pdf"

    def test_pdfcrop_config(self) -> None:
        """测试PdfCropConfig."""
        from bitool.skills.pdfutils.pdfcrop import PdfCropConfig

        config = PdfCropConfig()
        assert config.OUTPUT_SUFFIX == ".cropped.pdf"
        assert config.DEFAULT_MARGIN == 0

    def test_pdfocr_config(self) -> None:
        """测试PdfOcrConfig."""
        from bitool.skills.pdfutils.pdfocr import PdfOcrConfig

        config = PdfOcrConfig()
        assert config.OUTPUT_SUFFIX == ".ocr.pdf"
        assert config.DEFAULT_LANG == "chi_sim+eng"

    def test_pdfcompare_config(self) -> None:
        """测试PdfCompareConfig."""
        from bitool.skills.pdfutils.pdfcompare import PdfCompareConfig

        config = PdfCompareConfig()
        assert config.OUTPUT_SUFFIX == ".diff.pdf"

    def test_pdfattach_config(self) -> None:
        """测试PdfAttachConfig."""
        from bitool.skills.pdfutils.pdfattach import PdfAttachConfig

        config = PdfAttachConfig()
        assert config.OUTPUT_SUFFIX == ".attached.pdf"

    def test_pdflayout_config(self) -> None:
        """测试PdfLayoutConfig."""
        from bitool.skills.pdfutils.pdflayout import PdfLayoutConfig

        config = PdfLayoutConfig()
        assert config.OUTPUT_SUFFIX == ".layout.pdf"

    def test_pdfrepair_config(self) -> None:
        """测试PdfRepairConfig."""
        from bitool.skills.pdfutils.pdfrepair import PdfRepairConfig

        config = PdfRepairConfig()
        assert config.OUTPUT_SUFFIX == ".repaired.pdf"
