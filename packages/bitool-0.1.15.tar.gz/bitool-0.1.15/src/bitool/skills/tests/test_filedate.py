from __future__ import annotations

from pathlib import Path
from typing import Any, Callable

import pytest
from pytest_mock import MockerFixture

from bitool.skills.filedate import FileDateRenamer


@pytest.fixture
def patch_time_mark(mocker: MockerFixture) -> None:
    """2023年0101日"""
    mocker.patch("bitool.skills.filedate.FileDateRenamer.time_mark", "20230101")


@pytest.fixture
def patch_path_rename(mocker: MockerFixture) -> Callable[[Exception], None]:
    """模拟 Path.rename 方法抛出异常，用于测试异常处理逻辑."""

    def patch_func(side_effect: Exception) -> None:
        mocker.patch.object(Path, "rename", side_effect=side_effect)

    return patch_func


class TestFileDateRenamer:
    """测试 SingleFileRenamer 属性方法."""

    @pytest.mark.parametrize(
        ("filename", "expected_filename"),
        [
            ("test.txt", "20230101_test.txt"),
            ("test.tar.gz", "20230101_test.tar.gz"),
            ("test.abc.def.gz", "20230101_test.abc.def.gz"),
            ("noextension", "20230101_noextension"),
            (".hidden", ".hidden"),
            ("20240101_test.txt", "20230101_test.txt"),
            ("20240101#test.txt", "20230101_test.txt"),
            ("2023-04-07-test.txt", "20230101_test.txt"),
            ("20230407.test.txt", "20230101_test.txt"),
            ("20230407~document.txt", "20230101_document.txt"),
            ("file20230101.txt", "20230101_file.txt"),
            ("prefix_20230407_suffix.txt", "20230101_prefix_suffix.txt"),
            ("20230101_20231231_data.txt", "20230101_data.txt"),
            ("19991231_document.txt", "20230101_document.txt"),
            ("20230230_document.txt", "20230101_document.txt"),
            ("12345.txt", "20230101_12345.txt"),
        ],
    )
    def test_files(
        self,
        filename: str,
        expected_filename: str,
        tmp_path: Path,
        patch_time_mark: None,
    ) -> None:
        """测试获取带扩展名的文件后缀."""
        filepath = tmp_path / filename
        filepath.touch()

        renamer = FileDateRenamer(filepath)
        assert renamer.dest_filepath == filepath.with_name(expected_filename)
        assert renamer.dest_filename == expected_filename

        renamer.rename()
        assert renamer.dest_filepath.exists() is True

    @pytest.mark.parametrize(
        ("dirname", "expected_dirname"),
        [
            ("test", "20230101_test"),
            (".git", ".git"),
        ],
    )
    def test_dirs(
        self,
        dirname: str,
        expected_dirname: str,
        tmp_path: Path,
        patch_time_mark: None,
    ) -> None:
        """测试获取带扩展名的文件后缀."""
        dirpath = tmp_path / dirname
        dirpath.mkdir(parents=True, exist_ok=True)

        renamer = FileDateRenamer(dirpath)
        assert renamer.dest_filename == expected_dirname

    @pytest.mark.parametrize(
        ("exception", "expected_exc", "msg"),
        [
            (OSError("源文件不存在或路径无效"), OSError, "源文件不存在或路径无效"),
            (
                PermissionError("没有权限访问该文件"),
                PermissionError,
                "没有权限访问该文件",
            ),
            (OSError("文件被占用"), OSError, "文件被占用"),
            (
                FileNotFoundError("系统找不到指定的文件: 'nonexistent.txt'"),
                FileNotFoundError,
                "系统找不到指定的文件: 'nonexistent.txt'",
            ),
            (
                OSError("跨设备链接: 无法将 'test.txt' 移动到不同设备"),
                OSError,
                "跨设备链接: 无法将 'test.txt' 移动到不同设备",
            ),
        ],
    )
    def test_rename_exception(
        self,
        exception: Exception,
        expected_exc: type[Exception],
        msg: str,
        tmp_path: Path,
        patch_time_mark: None,
        patch_path_rename: Callable[[Any], None],
        mocker: MockerFixture,
    ) -> None:
        """测试 rename 方法抛出指定异常，覆盖异常处理逻辑."""
        filepath = tmp_path / "test.txt"
        filepath.touch()

        patch_path_rename(exception)
        mock_logger = mocker.patch("bitool.skills.filedate.logger")

        with pytest.raises(expected_exc) as exc_info:
            FileDateRenamer(filepath).rename()

        assert msg in str(exc_info.value)
        mock_logger.exception.assert_called_once()
        assert "重命名失败" in str(mock_logger.exception.call_args[0][0])

    def test_dest_filepath_with_existing_file(
        self,
        tmp_path: Path,
        patch_time_mark: None,
        mocker: MockerFixture,
    ) -> None:
        """测试目标文件已存在时添加序号后缀."""
        # 创建源文件
        src_file = tmp_path / "test.txt"
        src_file.touch()

        # 创建与源文件目标名相同的现有文件
        existing_file = tmp_path / "20230101_test.txt"
        existing_file.touch()

        mock_logger = mocker.patch("bitool.skills.filedate.logger")

        renamer = FileDateRenamer(src_file)
        assert "(1)" in str(renamer.dest_filepath)
        mock_logger.warning.assert_called_once()

    @pytest.mark.parametrize(
        ("filestem", "expected_filestem"),
        [
            ("test.txt", "20230101_test"),
            ("test.tar.gz", "20230101_test.tar"),
            ("noextension", "20230101_noextension"),
        ],
    )
    def test_dest_filestem(
        self,
        filestem: str,
        expected_filestem: str,
        tmp_path: Path,
        patch_time_mark: None,
    ) -> None:
        """测试获取重命名后的文件名主干."""
        filepath = tmp_path / filestem
        filepath.touch()

        renamer = FileDateRenamer(filepath)
        assert renamer.dest_filestem == expected_filestem

    @pytest.mark.parametrize(
        ("filename", "expected_filestem"),
        [
            (".gitkeep", ""),
            (".DS_Store", ""),
        ],
    )
    def test_filestem_without_date_hidden(
        self,
        filename: str,
        expected_filestem: str,
        tmp_path: Path,
    ) -> None:
        """测试隐藏文件的 filestem_without_date."""
        filepath = tmp_path / filename
        filepath.touch()

        renamer = FileDateRenamer(filepath)
        assert renamer.filestem_without_date == expected_filestem

    @pytest.mark.parametrize(
        ("filename", "expected_filestem"),
        [
            ("nodate.txt", "nodate"),
            ("20230101file.txt", "file"),
            ("file20230101", "file"),
            ("2023-01-01file.txt", "file"),
            ("file2023-01-01.txt", "file"),
        ],
    )
    def test_filestem_without_date_patterns(
        self,
        filename: str,
        expected_filestem: str,
        tmp_path: Path,
        mocker: MockerFixture,
    ) -> None:
        """测试各种日期模式的 filestem_without_date."""
        filepath = tmp_path / filename
        filepath.touch()

        mocker.patch("bitool.skills.filedate.logger")

        renamer = FileDateRenamer(filepath)
        assert renamer.filestem_without_date == expected_filestem

    def test_file_properties(
        self,
        tmp_path: Path,
    ) -> None:
        """测试文件属性: filestat, modified_time, created_time, time_mark."""
        filepath = tmp_path / "test.txt"
        filepath.touch()

        renamer = FileDateRenamer(filepath)

        assert renamer.filestat is not None
        assert isinstance(renamer.modified_time, float)
        assert isinstance(renamer.created_time, float)
        assert isinstance(renamer.time_mark, str)
        assert len(renamer.time_mark) == 8  # YYYYMMDD

    def test_dest_filepath_max_retry(
        self,
        tmp_path: Path,
        patch_time_mark: None,
        mocker: MockerFixture,
    ) -> None:
        """测试达到最大重试次数时使用UUID后缀."""
        # 创建源文件
        src_file = tmp_path / "test.txt"
        src_file.touch()

        # 设置较小的MAX_RETRY值
        mocker.patch("bitool.skills.filedate.conf.MAX_RETRY", 2)

        # 创建多个已存在的目标文件 (格式: 20230101_test.txt, 20230101_test(1).txt, 20230101_test(2).txt)
        (tmp_path / "20230101_test.txt").touch()
        (tmp_path / "20230101_test(1).txt").touch()
        (tmp_path / "20230101_test(2).txt").touch()

        mock_logger = mocker.patch("bitool.skills.filedate.logger")

        renamer = FileDateRenamer(src_file)
        result = renamer.dest_filepath

        # 验证使用了UUID后缀
        assert "_" in result.stem
        mock_logger.error.assert_called_once_with(
            "已达到最大重试次数, 使用uuid作为后缀."
        )
