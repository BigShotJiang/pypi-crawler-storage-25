"""envpy 工具的功能测试。

测试 EnvPySkill 类的 Python 环境配置功能。
"""

from __future__ import annotations

import argparse
import contextlib

import pytest

from bitool.skills.envs.envpy import EnvPyConfig, EnvPySkill


@pytest.fixture
def skill() -> EnvPySkill:
    """EnvPySkill 测试."""
    return EnvPySkill()


class TestEnvPySkill:
    """EnvPySkill 测试."""

    def test_skill_name(self, skill: EnvPySkill) -> None:
        """测试技能名称。"""
        assert skill.name == "envpy"

    def test_skill_description(self, skill: EnvPySkill) -> None:
        """测试技能描述。"""
        assert skill.description == "设置Python包的pip镜像源"

    def test_config(self) -> None:
        """测试配置类。"""
        assert EnvPyConfig.PIP_DEFAULT_INDEX_URL == "https://pypi.org/simple"
        assert "tsinghua" in EnvPyConfig.PIP_INDEX_URLS
        assert "aliyun" in EnvPyConfig.PIP_INDEX_URLS

    def test_create_scheduler_default(self, skill: EnvPySkill) -> None:
        """测试默认调度器创建。"""
        args = argparse.Namespace(mirror="tsinghua", token=None)
        scheduler = skill.create_scheduler(args)

        assert scheduler is not None
        assert len(scheduler.commands) == 4  # SetEnv + 3个 WriteFile

    @pytest.mark.parametrize("mirror", ["tsinghua", "aliyun"])
    def test_create_scheduler_with_mirror(self, mirror: str, skill: EnvPySkill) -> None:
        """测试不同镜像源的调度器创建。"""
        args = argparse.Namespace(mirror=mirror, token=None)
        scheduler = skill.create_scheduler(args)

        assert scheduler is not None
        assert len(scheduler.commands) == 4

    def test_create_scheduler_with_token(self, skill: EnvPySkill) -> None:
        """测试带 token 的调度器创建。"""
        args = argparse.Namespace(mirror="tsinghua", token="test-token-123")
        scheduler = skill.create_scheduler(args)

        assert scheduler is not None
        # 有 token 时应该有 4 个命令（包括 .pypirc）
        assert len(scheduler.commands) == 4

    def test_run_method(self, skill: EnvPySkill) -> None:
        """测试 run 方法（不实际执行命令）。"""
        # 由于会写入配置文件，这里只测试方法能正常调用
        # 不实际执行，避免权限问题
        with contextlib.suppress(Exception, SystemExit):
            exit_code = skill._run(["tsinghua"])
            # 如果不抛出异常，应该返回 0
            assert exit_code == 0
