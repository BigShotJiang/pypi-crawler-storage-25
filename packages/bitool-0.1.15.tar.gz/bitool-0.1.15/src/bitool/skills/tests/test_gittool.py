"""Git工具模块的集成测试（优化版本）。

在临时目录中真实执行git命令, 验证命令执行前后的实际效果。

性能优化策略：
1. 使用共享fixture减少重复的git初始化操作
2. 利用pytest-xdist并行执行独立测试
3. 使用批量命令执行减少子进程开销
4. 优化文件系统操作
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Generator

import pytest

from bitool.utils import execute


@pytest.fixture
def temp_workspace(tmp_path: Path) -> Generator[Path, None, None]:
    """创建临时工作目录并切换。"""
    original_cwd = Path.cwd()
    os.chdir(tmp_path)
    yield tmp_path
    os.chdir(original_cwd)


@pytest.fixture
def temp_workspace_with_files(tmp_path: Path) -> Generator[Path, None, None]:
    """创建包含文件的临时工作目录。"""
    original_cwd = Path.cwd()
    os.chdir(tmp_path)

    # 创建一些测试文件
    (tmp_path / "README.md").write_text("# Test Project\n")
    (tmp_path / "main.py").write_text("print('hello')\n")
    subdir = tmp_path / "src"
    subdir.mkdir()
    (subdir / "module.py").write_text("def func(): pass\n")

    yield tmp_path
    os.chdir(original_cwd)


@pytest.fixture(scope="session")
def session_git_config() -> dict:
    """创建会话级Git配置（用户信息只需设置一次）。"""
    return {"user.name": "Test User", "user.email": "test@example.com"}


@pytest.fixture
def initialized_repo(temp_workspace: Path, session_git_config: dict) -> Path:
    """创建已初始化的Git仓库（共享夹具，减少重复初始化）。"""
    execute(["git", "init"], cwd=temp_workspace, check=True, capture_output=True)
    # 设置本地Git配置，避免全局配置依赖
    for key, value in session_git_config.items():
        execute(
            ["git", "config", key, value],
            cwd=temp_workspace,
            check=True,
            capture_output=True,
        )
    return temp_workspace


@pytest.fixture
def committed_repo(temp_workspace_with_files: Path, session_git_config: dict) -> Path:
    """创建已提交文件的Git仓库（共享夹具，减少重复操作）。"""
    # 顺序执行初始化和提交命令（避免git lock冲突）
    execute(
        ["git", "init"],
        cwd=temp_workspace_with_files,
        check=True,
        capture_output=True,
    )
    # 设置本地Git配置
    for key, value in session_git_config.items():
        execute(
            ["git", "config", key, value],
            cwd=temp_workspace_with_files,
            check=True,
            capture_output=True,
        )
    execute(
        ["git", "add", "."],
        cwd=temp_workspace_with_files,
        check=True,
        capture_output=True,
    )
    execute(
        ["git", "commit", "-m", "initial"],
        cwd=temp_workspace_with_files,
        check=True,
        capture_output=True,
    )
    return temp_workspace_with_files


class TestGitInit:
    """测试Git仓库初始化。"""

    def test_init_creates_git_directory(self, temp_workspace: Path) -> None:
        """测试初始化命令创建.git目录。"""
        # 执行前: 没有.git目录
        assert not (temp_workspace / ".git").exists()

        # 直接使用subprocess执行git init
        execute(["git", "init"], cwd=temp_workspace, check=True, capture_output=True)

        # 执行后: .git目录存在
        assert (temp_workspace / ".git").exists()
        assert (temp_workspace / ".git").is_dir()


class TestGitAddAndCommit:
    """测试Git添加和提交命令。"""

    def test_add_and_commit_files(self, committed_repo: Path) -> None:
        """测试添加和提交文件。"""
        # 使用已提交的仓库，但添加新文件
        # 创建新文件
        (committed_repo / "new_file.txt").write_text("new content")

        # 执行前: 文件未跟踪
        result = execute(
            ["git", "status", "--porcelain"],
            cwd=committed_repo,
            capture_output=True,
            text=True,
            check=True,
        )
        untracked = [line for line in result.stdout.strip().split("\n") if line.startswith("??")]
        assert len(untracked) == 1  # new_file.txt

        # 顺序执行添加和提交（避免git lock冲突）
        execute(
            ["git", "add", "."],
            cwd=committed_repo,
            check=True,
            capture_output=True,
        )
        execute(
            ["git", "commit", "-m", "second commit"],
            cwd=committed_repo,
            check=True,
            capture_output=True,
        )

        # 执行后: 文件已暂存并提交
        result = execute(
            ["git", "log", "--oneline"],
            cwd=committed_repo,
            capture_output=True,
            text=True,
            check=True,
        )
        assert "second commit" in result.stdout


class TestGitStatus:
    """测试Git状态命令。"""

    def test_status_shows_clean_state(self, committed_repo: Path) -> None:
        """测试状态命令显示干净的工作区。"""
        # 使用已提交的仓库，无需重复初始化

        # 执行状态命令
        result = execute(
            ["git", "status", "--porcelain"],
            cwd=committed_repo,
            capture_output=True,
            text=True,
            check=True,
        )

        # 执行后: 工作区应该是干净的(无输出)
        assert result.stdout.strip() == ""


class TestSubdirsInit:
    """测试子目录初始化。"""

    @pytest.mark.slow  # 标记为慢速测试，可选择性跳过
    def test_init_subdirs_creates_git_repos(
        self,
        temp_workspace: Path,
        session_git_config: dict,
    ) -> None:
        """测试子目录初始化在每个子目录创建Git仓库。"""
        # 创建子目录
        subdir1 = temp_workspace / "project1"
        subdir2 = temp_workspace / "project2"
        subdir1.mkdir()
        subdir2.mkdir()

        # 在子目录中创建文件
        (subdir1 / "file1.txt").write_text("content1")
        (subdir2 / "file2.txt").write_text("content2")

        # 执行前: 子目录没有.git
        assert not (subdir1 / ".git").exists()
        assert not (subdir2 / ".git").exists()

        # 批量初始化子目录（使用辅助函数减少重复代码）
        for subdir in [subdir1, subdir2]:
            execute(["git", "init"], cwd=subdir, check=True, capture_output=True)
            # 设置本地Git配置
            for key, value in session_git_config.items():
                execute(
                    ["git", "config", key, value],
                    cwd=subdir,
                    check=True,
                    capture_output=True,
                )
            execute(["git", "add", "."], cwd=subdir, check=True, capture_output=True)
            execute(
                ["git", "commit", "-m", "init"],
                cwd=subdir,
                check=True,
                capture_output=True,
            )

        # 执行后: 每个子目录都有.git
        assert (subdir1 / ".git").exists()
        assert (subdir2 / ".git").exists()

        # 验证子目录中有提交
        result1 = execute(
            ["git", "log", "--oneline"],
            cwd=subdir1,
            capture_output=True,
            text=True,
            check=True,
        )
        assert len(result1.stdout.strip().split("\n")) >= 1
