"""PyPack 源码打包 Skill."""

from __future__ import annotations

import argparse
import fnmatch
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path

from bitool.cmd import CommandScheduler, FileTreeCopyCommand
from bitool.compat import tomllib
from bitool.core import logger
from bitool.utils.format import format_file_size

from ._base import PyPackBaseCommand, PyPackBaseSkill, PyPackProjectError
from .models import conf


@dataclass
class PyPackProjectCommand(PyPackBaseCommand):
    """打包单个项目命令."""

    name: str = "pack_project"
    description: str = "打包项目源代码"

    project_dir: Path = field(default_factory=Path)
    build_dir: Path = field(default_factory=Path)
    total_size: int = field(default=0)

    def _run(self) -> bool:
        """执行项目打包."""
        pyproject_file = self.project_dir / "pyproject.toml"
        project_name = self.project_dir.name or "root"

        if pyproject_file.exists():
            try:
                content = pyproject_file.read_text(encoding="utf-8")
                data = tomllib.loads(content)
                project_name = data.get("project", {}).get("name", project_name)
            except (OSError, ValueError, tomllib.TOMLDecodeError):
                logger.warning(f"读取 {pyproject_file} 失败，使用目录名")

        source_dir = self.build_dir / "src" / project_name
        source_dir.mkdir(parents=True, exist_ok=True)

        logger.info(f"正在打包: `{project_name}`")

        src_subdir = self.project_dir / "src"
        if src_subdir.exists() and src_subdir.is_dir():
            logger.info("检测到 src layout，复制 src/ 目录")
            target_dir = source_dir / "src"
            target_dir.mkdir(parents=True, exist_ok=True)
            copy_cmd = FileTreeCopyCommand(
                name=f"copy_src_{project_name}",
                description=f"复制 {project_name} 的 src 目录",
                source=src_subdir,
                destination=target_dir,
                ignore_patterns=conf.IGNORE_PATTERNS,
            )
            copy_cmd.run()
        else:
            logger.info("检测到 flat layout，复制项目文件")
            for item in self.project_dir.iterdir():
                if item.name == ".pypack":
                    logger.info(f"跳过构建目录: {item.name}")
                    continue

                if any(
                    fnmatch.fnmatch(item.name, pattern)
                    for pattern in conf.IGNORE_PATTERNS
                ):
                    continue

                dst_item = source_dir / item.name
                if item.is_dir():
                    shutil.copytree(
                        item,
                        dst_item,
                        ignore=shutil.ignore_patterns(*conf.IGNORE_PATTERNS),
                        dirs_exist_ok=True,
                    )
                else:
                    shutil.copy2(item, dst_item)

        self.total_size = sum(
            f.stat().st_size for f in source_dir.rglob("*") if f.is_file()
        )
        logger.info(f"已打包: `{project_name}` ({format_file_size(self.total_size)})")

        return True


@dataclass
class PySourcePackCommand(PyPackBaseCommand):
    """源码打包总控命令."""

    name: str = field(default="pack_all_projects")
    description: str = field(default="PyPack 源码打包")

    def _run(self) -> bool:
        """执行源码打包."""
        logger.info("正在打包源代码...")
        start_time = time.perf_counter()

        try:
            projects = list(self.required_solution.projects.values())

            if not projects:
                logger.info("没有找到项目，跳过源码打包")
                return True

            total_size = 0
            for project in projects:
                pack_cmd = PyPackProjectCommand(
                    name=f"pack_{project.name}",
                    description=f"打包项目 `{project.name}`",
                    project_dir=project.project_dir,
                    build_dir=self.required_solution.dist_dir,
                )

                if not pack_cmd.run():
                    logger.warning(f"项目 `{project.name}` 打包失败")
                    continue

                total_size += pack_cmd.total_size

            elapsed = time.perf_counter() - start_time
            logger.info(f"源代码打包完成，耗时 {elapsed:.2f}秒")
            logger.info(f"总打包体积: {format_file_size(total_size)}")
        except PyPackProjectError:
            raise
        except Exception:  # noqa: BLE001
            logger.exception("源代码打包失败")
            return False
        else:
            return True


class PySourcePackerSkill(PyPackBaseSkill):
    """源码打包 Skill."""

    name = "pypack-sourcepack"
    description = "PyPack 源码打包工具"

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        super().add_arguments(parser)

    def _create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建源码打包调度器."""
        build_dir = args.rootdir / ".pypack"
        build_dir.mkdir(parents=True, exist_ok=True)

        pack_cmd = self._create_command(PySourcePackCommand, args)

        return CommandScheduler(commands=[pack_cmd], timeout=conf.TIMEOUT)


def main() -> None:
    """主函数入口."""
    PySourcePackerSkill().run_cli()
