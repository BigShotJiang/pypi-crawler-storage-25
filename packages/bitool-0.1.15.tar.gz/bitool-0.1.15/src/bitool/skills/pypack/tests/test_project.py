"""Project 模型测试."""

from __future__ import annotations

from pathlib import Path

import pytest

from ..models import PyProject


class TestProjectCreation:
    """Project 创建测试."""

    def test_create_project_minimal(self, tmp_path: Path) -> None:
        """测试创建最小化项目."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nname = "test-project"\n')

        project = PyProject(
            name="test-project",
            version="0.0.0",
            description="",
            pyproject_file=pyproject,
        )
        assert project.name == "test-project"
        assert project.version == "0.0.0"
        assert project.description == ""
        assert project.dependencies == []

    def test_create_project_full(self, tmp_path: Path) -> None:
        """测试创建完整项目."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(
            "[project]\n"
            'name = "my-project"\n'
            'version = "1.2.3"\n'
            'description = "A test project"\n'
            'dependencies = ["requests>=2.28.0", "click"]\n',
        )

        project = PyProject(
            name="my-project",
            version="1.2.3",
            description="A test project",
            pyproject_file=pyproject,
            dependencies=["requests>=2.28.0", "click"],
        )
        assert project.name == "my-project"
        assert project.version == "1.2.3"
        assert project.description == "A test project"
        assert len(project.dependencies) == 2


class TestProjectFromString:
    """Project 字符串表示测试."""

    def test_project_repr(self, tmp_path: Path) -> None:
        """测试 Project 的 repr 表示."""
        pyproject = tmp_path / "pyproject.toml"
        project = PyProject(
            name="test",
            version="1.0.0",
            description="",
            pyproject_file=pyproject,
            dependencies=["requests", "click"],
        )
        assert repr(project) == "<Project(test, v1.0.0, ['requests', 'click'])>"

    def test_project_str_with_description(self, tmp_path: Path) -> None:
        """测试 Project 的 str 表示（有描述）."""
        pyproject = tmp_path / "pyproject.toml"
        project = PyProject(
            name="test",
            version="1.0.0",
            description="A test project",
            pyproject_file=pyproject,
        )
        assert str(project) == "test==1.0.0 - A test project"

    def test_project_str_without_description(self, tmp_path: Path) -> None:
        """测试 Project 的 str 表示（无描述）."""
        pyproject = tmp_path / "pyproject.toml"
        project = PyProject(
            name="test",
            version="1.0.0",
            description="",
            pyproject_file=pyproject,
        )
        assert str(project) == "test==1.0.0 - No description"


class TestProjectFromPyproject:
    """Project.from_pyproject 测试."""

    def test_from_pyproject_valid(self, tmp_path: Path) -> None:
        """测试从有效的 pyproject.toml 解析."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(
            "[project]\n"
            'name = "my-app"\n'
            'version = "2.0.0"\n'
            'description = "My application"\n'
            'dependencies = ["flask", "gunicorn"]\n',
        )

        project = PyProject.from_pyproject(pyproject)
        assert project is not None
        assert project.name == "my-app"
        assert project.version == "2.0.0"
        assert project.description == "My application"
        assert project.dependencies == ["flask", "gunicorn"]
        assert project.project_dir == tmp_path
        assert project.pyproject_file == pyproject

    def test_from_pyproject_minimal(self, tmp_path: Path) -> None:
        """测试从最小化的 pyproject.toml 解析."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nname = "minimal"\n')

        project = PyProject.from_pyproject(pyproject)
        assert project is not None
        assert project.name == "minimal"
        assert project.version == "0.0.0"
        assert project.description == ""
        assert project.dependencies == []

    def test_from_pyproject_no_name(self, tmp_path: Path) -> None:
        """测试从没有 name 的 pyproject.toml 解析."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nversion = "1.0.0"\n')

        project = PyProject.from_pyproject(pyproject)
        assert project is None

    def test_from_pyproject_file_not_found(self, tmp_path: Path) -> None:
        """测试从不存在的文件解析."""
        nonexistent = tmp_path / "nonexistent.toml"
        project = PyProject.from_pyproject(nonexistent)
        assert project is None

    def test_from_pyproject_invalid_toml(self, tmp_path: Path) -> None:
        """测试从无效的 TOML 文件解析."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text("invalid toml content [[[")

        project = PyProject.from_pyproject(pyproject)
        assert project is None

    def test_from_pyproject_no_project_section(self, tmp_path: Path) -> None:
        """测试从没有 project 部分的 TOML 解析."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[build-system]\nrequires = ["setuptools"]\n')

        project = PyProject.from_pyproject(pyproject)
        assert project is None


class TestProjectDetectName:
    """Project.detect_project_name 测试."""

    def test_detect_name_success(self, tmp_path: Path) -> None:
        """测试成功检测项目名称."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nname = "detected-project"\n')

        name = PyProject.detect_project_name(tmp_path)
        assert name == "detected-project"

    def test_detect_name_no_pyproject(self, tmp_path: Path) -> None:
        """测试没有 pyproject.toml 时返回 None."""
        name = PyProject.detect_project_name(tmp_path)
        assert name is None

    def test_detect_name_no_name_field(self, tmp_path: Path) -> None:
        """测试 pyproject.toml 中没有 name 字段时返回 None."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nversion = "1.0.0"\n')

        name = PyProject.detect_project_name(tmp_path)
        assert name is None


class TestProjectIsGui:
    """Project.is_gui_project 测试."""

    @pytest.mark.parametrize(
        "dependencies",
        [
            ["PySide6", "requests"],
            ["PyQt5", "click"],
            ["qt", "flask"],
            ["desktop-utils"],
            ["gui-framework"],
        ],
    )
    def test_is_gui_project_true(self, tmp_path: Path, dependencies: list[str]) -> None:
        """测试识别 GUI 项目."""
        pyproject = tmp_path / "pyproject.toml"
        project = PyProject(
            name="gui-app",
            version="1.0.0",
            description="",
            pyproject_file=pyproject,
            dependencies=dependencies,
        )
        assert project.is_gui_project is True

    @pytest.mark.parametrize(
        "dependencies",
        [["requests", "click"], ["flask", "gunicorn"], ["numpy", "pandas"], []],
    )
    def test_is_gui_project_false(
        self,
        tmp_path: Path,
        dependencies: list[str],
    ) -> None:
        """测试识别非 GUI 项目."""
        pyproject = tmp_path / "pyproject.toml"
        project = PyProject(
            name="cli-app",
            version="1.0.0",
            description="",
            pyproject_file=pyproject,
            dependencies=dependencies,
        )
        assert project.is_gui_project is False
