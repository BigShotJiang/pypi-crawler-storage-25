"""PyPack 数据模型模块.

提供项目结构解析和配置管理功能。
"""

from __future__ import annotations

import datetime
import re
import time
from dataclasses import dataclass, field
from functools import cached_property
from pathlib import Path
from typing import Any

from bitool import Constants
from bitool.compat import tomllib
from bitool.core import JsonConfig, logger


class PypackConfig(JsonConfig):
    """Pypack 配置类.

    集中管理所有 pypack 相关的配置常量。
    """

    DEFAULT_PYTHON_VERSION: str = "3.8.10"
    DEFAULT_DIST_DIR: str = ".pypack"
    DEFAULT_EMBED_DIR: str = "pyruntime"
    DEFAULT_EMBED_CACHE_DIR: str = str(
        Path.home() / ".bitool" / "pypack" / "embed_cache",
    )
    DEFAULT_LIB_CACHE_DIR: str = str(Path.home() / ".bitool" / "pypack" / "lib_cache")

    EXCLUDE_DIR_PATTERNS: frozenset[str] = frozenset(
        (
            "dist",
            ".pypack",
            "build",
            "__pycache__",
            ".git",
            ".pytest_cache",
            ".benchmarks",
            "node_modules",
            ".vscode",
            ".idea",
        ),
    )

    IGNORE_PATTERNS: frozenset[str] = frozenset(
        [
            "__pycache__",
            "*.pyc",
            "*.pyo",
            ".git",
            ".pytest_cache",
            ".coverage",
            "*.egg-info",
            "build",
            "*.log",
            ".ruff_cache",
            ".benchmarks",
            ".pypack",
        ],
    )

    PYTHON_VERSION_MAP: dict[str, str] = {
        "3.8": "3.8.10",
        "3.9": "3.9.13",
        "3.10": "3.10.11",
        "3.11": "3.11.9",
        "3.12": "3.12.6",
        "3.13": "3.13.11",
        "3.14": "3.14.4",
    }

    EMBED_PYTHON_MIRRORS: tuple[str, ...] = (
        "https://mirrors.huaweicloud.com/python/",
        "https://mirrors.tuna.tsinghua.edu.cn/python/",
        "https://mirrors.ustc.edu.cn/python/",
        "https://mirrors.aliyun.com/python/",
        "https://www.python.org/ftp/python/",
    )

    LIB_MIRROR_URLS: dict[str, str] = {
        "aliyun": "https://mirrors.aliyun.com/pypi/simple/",
        "tsinghua": "https://pypi.tuna.tsinghua.edu.cn/simple/",
        "pypi": "https://pypi.org/simple/",
    }

    DEFAULT_LIB_MIRROR: str = "aliyun"
    ARCHIVE_FORMATS: set[str] = {"zip", "tar", "gztar", "bztar", "xztar", "7z", "nsis"}
    DEFAULT_MAX_WORKERS: int = 4
    TIMEOUT: int = 300

    @classmethod
    def get_supported_python_versions(cls) -> list[str]:
        """获取支持的 Python 版本列表."""
        return list(cls.PYTHON_VERSION_MAP.keys())

    @classmethod
    def resolve_python_version(cls, version: str) -> str:
        """解析并规范化 Python 版本号."""
        if version in cls.PYTHON_VERSION_MAP:
            return cls.PYTHON_VERSION_MAP[version]
        if re.match(r"^\d+\.\d+\.\d+$", version):
            return version
        return version


conf = PypackConfig()


@dataclass(frozen=True)
class PySolution:
    """表示目录中的一组 Python 项目.

    根据根目录进行扫描，自动发现所有 pyproject.toml 文件。

    Attributes
    ----------
    root_dir : Path
        根目录
    projects : dict[str, PyProject]
        项目字典（项目名称 -> 项目对象）
    python_version : str
        Python 版本
    offline : bool
        是否离线模式
    start_time : float
        创建时间戳
    """

    root_dir: Path = field(default_factory=Path.cwd)
    python_version: str = field(default=conf.DEFAULT_PYTHON_VERSION)
    projects: dict[str, PyProject] = field(default_factory=dict)
    offline: bool = field(default=False)
    start_time: float = field(default_factory=time.perf_counter)
    time_stamp: datetime.datetime = field(default_factory=datetime.datetime.now)

    def __repr__(self) -> str:
        """返回解决方案的字符串表示."""
        return (
            f"<Solution(\n"
            f"  root_dir={self.root_dir!r},\n"
            f"  python_version={self.python_version!r},\n"
            f"  projects:\n\t - "
            + "\n\t - ".join(repr(project) for project in self.projects.values())
            + "\n"
            f"  time_used={self.elapsed_time:.4f}s\n"
            f")>"
        )

    @cached_property
    def dist_dir(self) -> Path:
        """获取构建输出目录."""
        return self.root_dir / conf.DEFAULT_DIST_DIR

    @cached_property
    def dist_embed_dir(self) -> Path:
        """获取嵌入式 Python 安装目录."""
        return self.dist_dir / conf.DEFAULT_EMBED_DIR

    @cached_property
    def dist_libs_dir(self) -> Path:
        """获取依赖库安装目录."""
        return self.dist_dir / "libs"

    @cached_property
    def dist_python_exe_path(self) -> Path:
        """获取嵌入式 Python 可执行文件路径."""
        return (
            self.dist_embed_dir / "python.exe"
            if Constants.IS_WINDOWS
            else self.dist_embed_dir / "python"
        )

    @cached_property
    def dist_python_exe_relpath(self) -> Path:
        """获取嵌入式 Python 可执行文件相对路径."""
        return self.dist_python_exe_path.relative_to(self.dist_dir)

    @cached_property
    def dist_loader_dir(self) -> Path:
        """获取加载器输出目录."""
        return self.dist_dir

    @cached_property
    def dist_src_dir(self) -> Path:
        """获取源代码打包目录."""
        return self.dist_dir / "src"

    @cached_property
    def elapsed_time(self) -> float:
        """计算耗时."""
        return time.perf_counter() - self.start_time

    @cached_property
    def dependencies(self) -> set[str]:
        """获取所有项目的依赖项（去重）."""
        return {
            dep for project in self.projects.values() for dep in project.dependencies
        }

    @classmethod
    def from_directory(
        cls,
        root_dir: Path,
        python_version: str = conf.DEFAULT_PYTHON_VERSION,
        *,
        offline: bool = False,
    ) -> PySolution:
        """从目录扫描创建 Solution.

        Parameters
        ----------
        root_dir : Path
            根目录
        python_version : str, optional
            Python 版本，默认使用配置中的默认版本
        offline : bool, optional
            是否离线模式，默认为 False

        Returns
        -------
        PySolution
            Solution 实例
        """
        projects: dict[str, PyProject] = cls._scan_projects(root_dir)
        return cls(
            root_dir=root_dir,
            projects=projects,
            python_version=python_version,
            offline=offline,
        )

    @classmethod
    def _scan_projects(cls, root_dir: Path) -> dict[str, PyProject]:
        """扫描目录中的项目."""
        projects: dict[str, PyProject] = {}

        for pyproject_file in root_dir.rglob("pyproject.toml"):
            if any(part in conf.EXCLUDE_DIR_PATTERNS for part in pyproject_file.parts):
                continue

            try:
                project = cls._parse_pyproject(pyproject_file)
                if project:
                    projects[project.name] = project
            except (OSError, UnicodeDecodeError, tomllib.TOMLDecodeError) as e:
                logger.warning(f"解析 {pyproject_file} 失败: {e}")

        return projects

    @classmethod
    def _parse_pyproject(cls, pyproject_file: Path) -> PyProject | None:
        """解析 pyproject.toml 文件."""
        try:
            content = pyproject_file.read_text(encoding="utf-8")
            data = tomllib.loads(content)
        except (OSError, UnicodeDecodeError, tomllib.TOMLDecodeError) as e:
            logger.warning(f"读取 {pyproject_file} 失败: {e}")
            return None

        project_data = data.get("project", {})
        name = project_data.get("name")
        version = project_data.get("version", "0.0.0")
        description = project_data.get("description", "")
        dependencies = project_data.get("dependencies", [])

        if not name:
            return None

        return PyProject(
            name=name,
            version=version,
            description=description,
            pyproject_file=pyproject_file,
            dependencies=dependencies,
        )

    def find_matching_projects(self, pattern: str) -> list[str]:
        """查找匹配的项目."""
        if not pattern:
            return []

        lower_pattern = pattern.lower()
        return [name for name in self.projects if lower_pattern in name.lower()]

    def resolve_project_name(self, project_name: str | None) -> str | None:
        """解析项目名称.

        支持精确匹配和模糊匹配，如果只有一个项目则自动选择。

        Parameters
        ----------
        project_name : str | None
            项目名称

        Returns
        -------
        str | None
            解析后的项目名称，如果无法解析则返回 None
        """
        if not project_name:
            if len(self.projects) == 1:
                return next(iter(self.projects))
            return None

        if project_name in self.projects:
            return project_name

        matches = self.find_matching_projects(project_name)
        if len(matches) == 1:
            return matches[0]

        return None


@dataclass(frozen=True)
class PyProject:
    """表示一个 Python 项目.

    从 pyproject.toml 解析项目信息。

    Attributes
    ----------
    name : str
        项目名称
    version : str
        项目版本
    description : str
        项目描述
    pyproject_file : Path
        pyproject.toml 文件路径
    dependencies : list[str]
        依赖项列表
    """

    name: str
    version: str
    description: str
    pyproject_file: Path
    dependencies: list[str] = field(default_factory=list)

    @cached_property
    def project_dir(self) -> Path:
        """获取项目目录."""
        if not self.pyproject_file.exists():
            raise FileNotFoundError(f"pyproject.toml 文件不存在: {self.pyproject_file}")
        return self.pyproject_file.parent

    @cached_property
    def resolved_name(self) -> str:
        """获取解析后的项目名称（连字符转下划线）."""
        return self.name.replace("-", "_")

    @cached_property
    def entry_file(self) -> PyEntryFile | None:
        """获取项目的入口文件."""
        entry_files = PyEntryFile.detect_entry_files(
            self.project_dir,
            self.name,
            self.project_dir,
        )
        return entry_files[0] if entry_files else None

    @cached_property
    def entry_file_stem(self) -> str:
        """获取入口文件名（不含扩展名）."""
        if self.entry_file:
            return self.entry_file.source_file.stem
        return "main"

    @classmethod
    def from_pyproject(cls, pyproject_file: Path) -> PyProject | None:
        """从 pyproject.toml 文件解析项目信息."""
        try:
            content = pyproject_file.read_text(encoding="utf-8")
            data = tomllib.loads(content)
        except (OSError, UnicodeDecodeError, tomllib.TOMLDecodeError) as exc:
            logger.warning(f"读取 {pyproject_file} 失败: {exc}")
            return None

        project_data = data.get("project", {})
        name = project_data.get("name")
        if not name:
            return None

        version = project_data.get("version", "0.0.0")
        description = project_data.get("description", "")
        dependencies = project_data.get("dependencies", [])

        return cls(
            name=name,
            version=version,
            description=description,
            pyproject_file=pyproject_file,
            dependencies=dependencies,
        )

    @staticmethod
    def detect_project_name(project_dir: Path) -> str | None:
        """从项目目录中自动检测项目名称."""
        pyproject_file = project_dir / "pyproject.toml"
        if not pyproject_file.exists():
            logger.warning(f"未找到 {pyproject_file}，无法自动解析项目名称")
            return None

        project = PyProject.from_pyproject(pyproject_file)
        if project:
            logger.info(f"自动检测到项目名称: {project.name}")
            return project.name

        logger.warning(f"{pyproject_file} 中未找到 project.name 字段")
        return None

    def __repr__(self) -> str:
        """返回项目的字符串表示."""
        return f"<Project({self.name}, v{self.version}, {self.dependencies!r})>"

    def __str__(self) -> str:
        """返回项目的简洁字符串表示."""
        return f"{self.name}=={self.version} - {self.description or 'No description'}"

    @cached_property
    def is_gui_project(self) -> bool:
        """判断是否为 GUI 项目."""
        gui_keywords = {"gui", "desktop", "qt", "pyside", "pyqt"}
        deps_lower = [d.lower() for d in self.dependencies]
        return any(kw in " ".join(deps_lower) for kw in gui_keywords)

    def get_project_info(self) -> dict[str, Any]:
        """获取项目详细信息."""
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "project_dir": str(self.project_dir),
            "dependencies": self.dependencies,
            "is_gui": self.is_gui_project,
        }


@dataclass(frozen=True)
class PyEntryFile:
    """表示一个 Python 入口文件.

    Attributes
    ----------
    project_name : str
        项目名称
    source_file : Path
        源文件路径
    project_root : Path | None
        项目根目录
    """

    project_name: str
    source_file: Path
    project_root: Path | None = None

    @property
    def is_entry_source(self) -> bool:
        """判断是否为有效的入口文件."""
        if not self.source_file.is_file() or self.source_file.suffix != ".py":
            return False

        try:
            content = self.source_file.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            return False
        else:
            return (
                "def main(" in content
                or "if __name__ == '__main__':" in content
                or 'if __name__ == "__main__":' in content
            )

    @property
    def relative_path(self) -> Path | str:
        """获取相对于项目根目录的路径."""
        if self.project_root:
            return self.source_file.relative_to(self.project_root)
        return self.source_file.name

    @property
    def output_stem(self) -> str:
        """获取输出文件名（不含扩展名）."""
        return self.source_file.stem

    def to_dict(self) -> dict[str, Any]:
        """转换为字典."""
        return {
            "project_name": self.project_name,
            "source_file": str(self.source_file),
            "output_stem": self.output_stem,
        }

    def __str__(self) -> str:
        """返回入口文件的字符串表示."""
        return f"{self.project_name}:{self.source_file.name}"

    @staticmethod
    def detect_entry_files(
        project_dir: Path,
        project_name: str,
        project_root: Path | None = None,
    ) -> list[PyEntryFile]:
        """检测项目目录中的所有入口文件."""
        entry_files: list[PyEntryFile] = []
        normalized_name = project_name.lower().replace("-", "_")

        for py_file in project_dir.glob("*.py"):
            entry = PyEntryFile(
                project_name=normalized_name,
                source_file=py_file,
                project_root=project_root,
            )
            if entry.is_entry_source:
                entry_files.append(entry)
                logger.info(f"找到入口文件: {entry}")

        return entry_files


@dataclass(frozen=True)
class PyDependency:
    """表示一个项目依赖项.

    Attributes
    ----------
    name : str
        依赖项名称
    version : str | None
        版本号约束
    extras : list[str]
        可选的额外依赖
    """

    name: str
    version: str | None = None
    extras: list[str] | None = None

    def __post_init__(self) -> None:
        """初始化后处理."""
        if self.extras is None:
            object.__setattr__(self, "extras", [])

    def __str__(self) -> str:
        """返回依赖项的字符串表示."""
        if self.version:
            return f"{self.name}{self.version}"
        return self.name

    def to_dict(self) -> dict[str, Any]:
        """转换为字典."""
        return {"name": self.name, "version": self.version, "extras": self.extras}

    @classmethod
    def from_string(cls, dep_str: str) -> PyDependency:
        """从字符串创建依赖项.

        Parameters
        ----------
        dep_str : str
            依赖项字符串，如 "requests>=2.28.0"

        Returns
        -------
        PyDependency
            依赖项实例
        """
        match = re.match(r"^([a-zA-Z0-9_.-]+)\s*(.*)?$", dep_str.strip())
        if not match:
            return cls(name=dep_str.strip())

        name = match.group(1)
        version = match.group(2).strip() if match.group(2) else None
        return cls(name=name, version=version)
