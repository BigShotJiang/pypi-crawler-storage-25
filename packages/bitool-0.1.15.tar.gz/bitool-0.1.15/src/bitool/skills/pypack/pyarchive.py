"""PyPack 归档 Skill."""

from __future__ import annotations

import argparse
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Final

from bitool.cmd import CommandScheduler
from bitool.core import logger
from bitool.utils import execute

from ._base import PyPackBaseCommand, PyPackBaseSkill, PyPackBuildError


@dataclass
class PyArchiveCommand(PyPackBaseCommand):
    """归档命令."""

    name: str = field(default="pypack-archive")
    description: str = field(default="PyPack 归档工具")

    archive_format: str = field(default="zip")
    ARCHIVE_FORMATS: Final[tuple[str, ...]] = (
        "zip",
        "tar",
        "gztar",
        "bztar",
        "xztar",
        "7z",
    )

    def _run(self) -> bool:
        """执行归档."""
        archiver = PyArchiver(root_dir=self.root_dir)
        return archiver.run(self.archive_format)


class PyArchiverSkill(PyPackBaseSkill):
    """归档 Skill."""

    name = "pypack-archive"
    description = "PyPack 归档工具 - 支持多种归档格式"

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        super().add_arguments(parser)
        parser.add_argument(
            "--format",
            "-f",
            type=str,
            choices=("zip", "tar", "gztar", "bztar", "xztar", "7z"),
            default="zip",
            help="归档格式 (默认: zip)",
        )

    def _create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建归档调度器."""
        cmd = self._create_command(PyArchiveCommand, args)
        cmd.archive_format = args.format

        return CommandScheduler(commands=[cmd], timeout=300)


class PyArchiver:
    """归档器.

    支持多种归档格式：ZIP、tar.gz、7z 等.
    """

    def __init__(self, root_dir: Path) -> None:
        """初始化归档器."""
        self.root_dir = root_dir
        self.build_dir = root_dir / ".pypack"

    def run(self, archive_format: str = "zip") -> bool:
        """执行归档."""
        try:
            if not self.build_dir.exists():
                logger.error(f"构建目录不存在: {self.build_dir}")
                logger.info("请先运行构建命令生成构建产物")
                return False

            if archive_format == "7z":
                return self._archive_7z(self.build_dir)
            elif archive_format in {"zip", "tar", "gztar", "bztar", "xztar"}:
                return self._archive_shutil(archive_format, self.build_dir)
            else:
                logger.error(f"不支持的归档格式: {archive_format}")
                logger.info(
                    f"支持的格式: {', '.join(('zip', 'tar', 'gztar', 'bztar', 'xztar', '7z'))}",
                )
                return False

        except Exception as exc:  # noqa: BLE001
            logger.error(f"归档失败: {exc}")
            return False

    def _archive_shutil(self, archive_format: str, build_dir: Path) -> bool:
        """使用 shutil 进行归档."""
        try:
            output_name = self.root_dir / f"{self.root_dir.name}_package"

            logger.info(f"正在创建 {archive_format} 归档...")

            archive_path = shutil.make_archive(
                base_name=str(output_name),
                format=archive_format,
                root_dir=str(build_dir),
            )
        except Exception as exc:  # noqa: BLE001
            logger.error(f"shutil 归档失败: {exc}")
            return False
        else:
            logger.info(f"归档完成: {archive_path}")
            return True

    def _archive_7z(self, build_dir: Path) -> bool:
        """使用 7-Zip 进行归档."""

        def _run_7z() -> None:
            """执行 7z 归档命令，失败时抛出 PyPackBuildError."""
            if not self._check_7z():
                logger.warning("未找到 7z 命令，回退到 ZIP 格式")
                return

            output_file = self.root_dir / f"{self.root_dir.name}_package.7z"

            logger.info("正在创建 7z 归档...")

            source_pattern = str(build_dir / "*")

            cmd = ["7z", "a", "-t7z", "-mx=9", str(output_file), source_pattern]

            result = execute(cmd, capture_output=True, text=True, timeout=300)

            if result.returncode == 0:
                logger.info(f"7z 归档完成: {output_file}")
            else:
                raise PyPackBuildError("7z 归档失败", details=result.stderr)

        try:
            _run_7z()
        except PyPackBuildError:
            raise
        except Exception as exc:  # noqa: BLE001
            logger.error(f"7z 归档失败: {exc}")
            return False

        # 如果 _run_7z 回退到了 ZIP 格式
        if not (self.root_dir / f"{self.root_dir.name}_package.7z").exists():
            return self._archive_shutil("zip", build_dir)
        return True

    def _check_7z(self) -> bool:
        """检查 7z 命令是否可用."""
        try:
            result = execute(
                ["7z", "--help"],
                capture_output=True,
                text=True,
                timeout=5,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False
        else:
            return result.returncode == 0


def main() -> None:
    """主函数入口."""
    PyArchiverSkill().run_cli()
