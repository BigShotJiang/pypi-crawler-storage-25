"""PyPack 加载器生成 Skill."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from string import Template

from bitool import Constants
from bitool.cmd import BaseCommand, CommandScheduler, CompileCommand, WriteFileCommand

from ._base import PyPackBaseSkill, PyPackProjectError
from .models import conf

_TEMPLATES_DIR = Path(__file__).parent / "templates"
_SCRIPT_TEMPLATE = _TEMPLATES_DIR / "loader_script.ent"
_C_TEMPLATE = (
    _TEMPLATES_DIR / "loader_windows.c"
    if Constants.IS_WINDOWS
    else _TEMPLATES_DIR / "loader_unix.c"
)


@dataclass
class PyLoaderGenSkill(PyPackBaseSkill):
    """加载器生成 Skill."""

    name = "pyloadergen"
    description = "PyLoaderGen Skill，用于生成 PyLoader 加载器"

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        super().add_arguments(parser)
        parser.add_argument(
            "--loader-type",
            choices=["console", "gui"],
            default="console",
            help="加载器类型: console(控制台) 或 gui(图形界面)",
        )

    def _create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建加载器生成调度器."""
        solution = self._ensure_solution(args)

        if not solution.projects:
            raise PyPackProjectError(
                "项目中没有找到有效的 Python 项目",
                suggestion="请确保项目目录包含 pyproject.toml 文件",
            )

        all_commands: list[BaseCommand] = []

        for p in solution.projects.values():
            resolved_name = p.resolved_name

            write_script_cmd = WriteFileCommand(
                name=f"write_script_{resolved_name}",
                description=f"写入 {resolved_name} 的启动脚本",
                filepath=solution.dist_loader_dir / f"{resolved_name}.ent",
                content=Template(
                    _SCRIPT_TEMPLATE.read_text(encoding="utf-8"),
                ).substitute(
                    PROJECT_NAME=resolved_name,
                    ENTRY_FILE=f"{p.entry_file_stem}",
                    QT_CONFIG="",
                ),
            )

            write_c_source_cmd = WriteFileCommand(
                name=f"write_c_source_{resolved_name}",
                description=f"写入 {resolved_name} 的 C 源代码",
                filepath=solution.dist_loader_dir / f"{resolved_name}.c",
                content=Template(_C_TEMPLATE.read_text(encoding="utf-8")).substitute(
                    PYTHON_EXE=solution.dist_python_exe_relpath.as_posix(),
                    PROJECT_NAME=resolved_name,
                    SCRIPT_NAME=f"{resolved_name}.ent",
                    SUBSYSTEM="windows" if args.loader_type == "gui" else "console",
                ),
            )

            compile_cmd = CompileCommand(
                name=f"compile_{resolved_name}",
                description=f"编译 {resolved_name} 的加载器",
                source_file=solution.dist_loader_dir / f"{resolved_name}.c",
                output_file=solution.dist_loader_dir / f"{resolved_name}.exe"
                if Constants.IS_WINDOWS
                else solution.dist_loader_dir / f"{resolved_name}",
                loader_type=args.loader_type,
                dependencies=[f"write_c_source_{resolved_name}"],
            )

            all_commands.extend([write_script_cmd, write_c_source_cmd, compile_cmd])

        return CommandScheduler(commands=all_commands, timeout=conf.TIMEOUT)


def main() -> None:
    """主函数入口."""
    PyLoaderGenSkill().run_cli()
