"""PyPack 依赖库打包 Skill.

本模块提供自动下载和打包项目依赖库的功能。
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from functools import cached_property
from pathlib import Path

from bitool.cmd import CommandScheduler, RunCommand
from bitool.core import logger

from ._base import (
    PyPackBaseCommand,
    PyPackBaseSkill,
    PyPackNetworkError,
    validate_mirror,
)
from .models import conf


@dataclass
class DownloadDependenciesCommand(PyPackBaseCommand):
    """下载依赖命令."""

    name: str = field(default="download_dependencies")
    description: str = field(default="下载依赖到指定目录")

    mirror: str = field(default=conf.DEFAULT_LIB_MIRROR)
    dependencies: list[str] = field(default_factory=list)

    @cached_property
    def lib_dir(self) -> Path:
        """获取目标库目录."""
        return self.required_solution.dist_libs_dir

    @cached_property
    def cache_dir(self) -> Path:
        """获取全局 wheel 缓存目录."""
        return Path(conf.DEFAULT_LIB_CACHE_DIR)

    def _get_python_exe(self) -> Path:
        """获取 Python 可执行文件路径."""
        python_exe = self.required_solution.dist_python_exe_path
        if python_exe.exists():
            return python_exe
        return Path("python")

    def _run(self) -> bool:
        """执行依赖下载和安装."""
        self.dependencies = list(self.required_solution.dependencies)

        if self.dependencies:
            logger.info(
                f"找到 {len(self.dependencies)} 个依赖: {', '.join(self.dependencies)}",
            )
        else:
            logger.info("未找到任何依赖")
            return True

        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.lib_dir.mkdir(parents=True, exist_ok=True)

        validate_mirror(self.mirror)

        if not self._download_wheels(self.dependencies):
            return False

        if not self._install_from_cache(self.dependencies):
            logger.warning("尝试回退到在线安装模式...")
            return self._install_online(self.dependencies)

        logger.info(f"依赖已准备完成: {self.lib_dir}")
        return True

    def _download_wheels(self, dependencies: list[str]) -> bool:
        """下载 wheel 文件到缓存目录."""
        missing_deps = self._get_missing_wheels(dependencies)
        if not missing_deps:
            logger.info("所有依赖已缓存，跳过下载")
            return True

        if self._solution_offline:
            raise PyPackNetworkError(
                "离线模式：缺少部分依赖的缓存",
                details=f"缺少 {len(missing_deps)} 个依赖: {', '.join(missing_deps)}",
                suggestion="请先在线下载所有依赖",
            )

        python_exe = self._get_python_exe()
        cmd = [
            str(python_exe),
            "-m",
            "pip",
            "download",
            "--dest",
            str(self.cache_dir),
            "--only-binary=:all:",
            "--no-deps",
        ]

        if self.mirror in conf.LIB_MIRROR_URLS:
            cmd.extend(["-i", conf.LIB_MIRROR_URLS[self.mirror]])
        else:
            logger.warning(f"无效的镜像源: {self.mirror}")

        for dep in missing_deps:
            cmd.extend(["--python-version", self._solution_python_version])
            cmd.append(dep)

        logger.info(
            f"正在下载 {len(missing_deps)} 个依赖到缓存目录 {self.cache_dir}...",
        )

        run_cmd = RunCommand(cmd=cmd, timeout=conf.TIMEOUT)
        if not run_cmd.run():
            logger.error("下载 wheel 文件失败")
            return False

        logger.info(f"wheel 文件已缓存到: {self.cache_dir}")
        return True

    def _get_missing_wheels(self, dependencies: list[str]) -> list[str]:
        """获取缺失的 wheel 文件对应的依赖."""
        if not self.cache_dir.exists():
            return dependencies

        missing = []
        cached_files = set(self.cache_dir.glob("*.whl"))

        for dep in dependencies:
            pkg_name = (
                dep.split(">=")[0].split("<=")[0].split("==")[0].split("!")[0].strip()
            )
            pkg_name_normalized = pkg_name.lower().replace("-", "_")

            found = False
            for whl_file in cached_files:
                whl_pkg_name = whl_file.name.split("-")[0].lower()
                if whl_pkg_name == pkg_name_normalized:
                    found = True
                    break

            if not found:
                missing.append(dep)

        return missing

    def _install_from_cache(self, dependencies: list[str]) -> bool:
        """从缓存的 wheel 文件安装依赖到目标目录."""
        logger.info(f"正在从缓存安装依赖到: {self.lib_dir}")

        unique_deps = list(dict.fromkeys(dependencies))

        python_exe = self._get_python_exe()
        cmd = [
            str(python_exe),
            "-m",
            "pip",
            "install",
            "--target",
            str(self.lib_dir),
            "--no-index",
            "--find-links",
            str(self.cache_dir),
        ]

        cmd.extend(unique_deps)

        logger.info(f"正在从缓存安装 {len(unique_deps)} 个依赖...")

        run_cmd = RunCommand(cmd=cmd, timeout=conf.TIMEOUT)
        if not run_cmd.run():
            logger.error("从缓存安装依赖失败")
            return False

        logger.info(f"依赖已从缓存安装到: {self.lib_dir}")
        return True

    def _install_online(self, dependencies: list[str]) -> bool:
        """在线安装依赖（缓存失败时的回退方案）."""
        logger.info(f"正在在线安装依赖到: {self.lib_dir}")

        unique_deps = list(dict.fromkeys(dependencies))

        cmd = [
            "pip",
            "install",
            "--target",
            str(self.lib_dir),
            "--no-compile",
            "--no-warn-script-location",
        ]

        if self.mirror in conf.LIB_MIRROR_URLS:
            cmd.extend(["-i", conf.LIB_MIRROR_URLS[self.mirror]])
        else:
            logger.warning(f"无效的镜像源: {self.mirror}")

        cmd.extend(unique_deps)

        logger.info(f"正在在线安装 {len(unique_deps)} 个依赖...")

        run_cmd = RunCommand(cmd=cmd, timeout=conf.TIMEOUT)
        if not run_cmd.run():
            logger.error("在线安装依赖失败")
            return False

        logger.info(f"依赖已在线安装到: {self.lib_dir}")
        return True


class PyLibPackerSkill(PyPackBaseSkill):
    """依赖库打包 Skill."""

    name = "pylibpack"
    description = "PyLibPack 依赖库打包工具"

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        super().add_arguments(parser)
        parser.add_argument(
            "--mirror",
            type=str,
            choices=list(conf.LIB_MIRROR_URLS.keys()),
            default=conf.DEFAULT_LIB_MIRROR,
            help=f"PyPI 镜像源 (默认: {conf.DEFAULT_LIB_MIRROR})",
        )

    def _create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建依赖打包调度器."""
        cmd = self._create_command(DownloadDependenciesCommand, args)
        cmd.mirror = args.mirror

        return CommandScheduler(commands=[cmd], timeout=conf.TIMEOUT)


def main() -> None:
    """主函数入口."""
    PyLibPackerSkill().run_cli()
