"""PyPack 基础模块.

提供统一的基类和错误处理机制，提高代码复用率和一致性。
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar, TypeVar

from bitool.cmd import BaseCommand, CommandScheduler
from bitool.core import logger
from bitool.skills._base import BaseSkill

from .models import PySolution, conf

if TYPE_CHECKING:
    pass


class PyPackError(Exception):
    """PyPack 统一异常类.

    提供友好的错误提示和分类，便于用户理解和排查问题。

    Attributes
    ----------
    code : str
        错误代码，用于程序化处理
    message : str
        用户友好的错误消息
    details : str | None
        详细的错误信息（可选）
    suggestion : str | None
        解决建议（可选）
    """

    def __init__(
        self,
        code: str,
        message: str,
        details: str | None = None,
        suggestion: str | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details
        self.suggestion = suggestion

    def __str__(self) -> str:
        """返回格式化的错误消息."""
        parts = [f"[{self.code}] {self.message}"]
        if self.details:
            parts.append(f"  详情: {self.details}")
        if self.suggestion:
            parts.append(f"  建议: {self.suggestion}")
        return "\n".join(parts)


class PyPackProjectError(PyPackError):
    """项目相关错误."""

    def __init__(
        self,
        message: str,
        details: str | None = None,
        suggestion: str | None = None,
    ) -> None:
        super().__init__("PROJECT_ERROR", message, details, suggestion)


class PyPackBuildError(PyPackError):
    """构建相关错误."""

    def __init__(
        self,
        message: str,
        details: str | None = None,
        suggestion: str | None = None,
    ) -> None:
        super().__init__("BUILD_ERROR", message, details, suggestion)


class PyPackNetworkError(PyPackError):
    """网络相关错误."""

    def __init__(
        self,
        message: str,
        details: str | None = None,
        suggestion: str | None = None,
    ) -> None:
        super().__init__("NETWORK_ERROR", message, details, suggestion)


class PyPackConfigError(PyPackError):
    """配置相关错误."""

    def __init__(
        self,
        message: str,
        details: str | None = None,
        suggestion: str | None = None,
    ) -> None:
        super().__init__("CONFIG_ERROR", message, details, suggestion)


T = TypeVar("T", bound="PyPackBaseCommand")


@dataclass
class PyPackBaseCommand(BaseCommand):
    """PyPack 命令基类.

    提供统一的错误处理和日志记录机制。

    Attributes
    ----------
    root_dir : Path
        项目根目录
    solution : PySolution | None
        PySolution 实例（懒加载）
    """

    name: str = field(default="pypack-base")
    description: str = field(default="PyPack 基础命令")
    root_dir: Path = field(default_factory=Path.cwd)
    python_version: str = field(default=conf.DEFAULT_PYTHON_VERSION)
    offline: bool = field(default=False)
    solution: PySolution | None = field(default=None, init=False)

    @property
    def _solution_python_version(self) -> str:
        return self.python_version

    @property
    def _solution_offline(self) -> bool:
        return self.offline

    def _ensure_solution(self) -> PySolution:
        """确保 solution 已初始化."""
        if self.solution is None:
            self.solution = PySolution.from_directory(
                self.root_dir,
                python_version=self._solution_python_version,
                offline=self._solution_offline,
            )
        return self.solution

    @property
    def required_solution(self) -> PySolution:
        """获取必需的 solution 实例."""
        return self._ensure_solution()

    def run(self) -> bool:
        """执行命令（带统一错误处理）."""
        try:
            return self._run()
        except PyPackError as e:
            logger.error(str(e))
            return False
        except Exception as e:  # noqa: BLE001
            logger.exception(f"命令执行失败: {e}")
            return False

    def _run(self) -> bool:
        """子类实现的实际执行逻辑."""
        raise NotImplementedError("子类必须实现 _run 方法")


@dataclass
class PyPackBaseSkill(BaseSkill):
    """PyPack Skill 基类.

    提取公共逻辑，提高代码复用率：
    - 统一的参数解析
    - 统一的错误处理
    - 统一的日志记录
    - 统一的 solution 管理

    Attributes
    ----------
    name : str
        Skill 名称
    description : str
        Skill 描述
    root_dir : Path
        项目根目录
    solution : PySolution | None
        PySolution 实例
    """

    DEFAULT_PYTHON_VERSION: ClassVar[str] = conf.DEFAULT_PYTHON_VERSION
    DEFAULT_MIRROR: ClassVar[str] = conf.DEFAULT_LIB_MIRROR

    root_dir: Path = field(default_factory=Path.cwd)
    solution: PySolution | None = field(default=None, init=False)

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加公共命令行参数."""
        parser.add_argument(
            "rootdir",
            type=Path,
            nargs="?",
            default=Path.cwd(),
            help="项目根目录（默认：当前目录）",
        )
        parser.add_argument(
            "--python-version",
            type=str,
            default=self.DEFAULT_PYTHON_VERSION,
            help=f"Python 版本（默认：{self.DEFAULT_PYTHON_VERSION}）",
        )
        parser.add_argument(
            "--mirror",
            type=str,
            choices=list(conf.LIB_MIRROR_URLS.keys()),
            default=self.DEFAULT_MIRROR,
            help=f"PyPI 镜像源（默认：{self.DEFAULT_MIRROR}）",
        )
        parser.add_argument("--offline", "-o", action="store_true", help="离线模式")
        parser.add_argument("--debug", "-d", action="store_true", help="调试模式")

    def _ensure_solution(self, args: argparse.Namespace) -> PySolution:
        """确保 solution 已初始化."""
        if self.solution is None:
            self.root_dir = args.rootdir
            self.solution = PySolution.from_directory(
                self.root_dir,
                python_version=getattr(
                    args,
                    "python_version",
                    self.DEFAULT_PYTHON_VERSION,
                ),
                offline=getattr(args, "offline", False),
            )
        return self.solution

    def _create_command(
        self,
        cmd_class: type[T],
        args: argparse.Namespace,
        **kwargs: Any,
    ) -> T:
        """创建命令实例并设置公共属性."""
        init_kwargs: dict[str, Any] = {
            "root_dir": args.rootdir,
            "python_version": getattr(
                args,
                "python_version",
                self.DEFAULT_PYTHON_VERSION,
            ),
            "offline": getattr(args, "offline", False),
        }
        init_kwargs.update(kwargs)
        cmd = cmd_class(**init_kwargs)
        return cmd

    def _check_projects(self, solution: PySolution) -> bool:
        """检查项目是否存在."""
        if not solution.projects:
            logger.error("未找到任何 Python 项目")
            logger.info("请确保当前目录包含 pyproject.toml 文件")
            return False
        return True

    def _handle_error(self, error: Exception) -> CommandScheduler:
        """统一错误处理."""
        if isinstance(error, PyPackError):
            logger.error(str(error))
        else:
            logger.exception(f"发生未知错误: {error}")
        return CommandScheduler(commands=[], timeout=30)

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建命令调度器（模板方法）."""
        try:
            return self._create_scheduler(args)
        except PyPackError as e:
            return self._handle_error(e)
        except Exception as e:  # noqa: BLE001
            return self._handle_error(e)

    def _create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """子类实现的调度器创建逻辑."""
        raise NotImplementedError("子类必须实现 _create_scheduler 方法")


def validate_python_version(version: str) -> str:
    """验证并规范化 Python 版本号."""
    import re

    if re.match(r"^\d+\.\d+$", version):
        full_version = conf.PYTHON_VERSION_MAP.get(version)
        if full_version:
            logger.info(f"版本号 {version} 已解析为完整版本 {full_version}")
            return full_version
        raise PyPackConfigError(
            f"不支持的 Python 版本: {version}",
            suggestion=f"支持的版本: {', '.join(conf.PYTHON_VERSION_MAP.keys())}",
        )
    if re.match(r"^\d+\.\d+\.\d+$", version):
        return version
    raise PyPackConfigError(
        f"无效的 Python 版本格式: {version}",
        suggestion="请使用格式: X.Y 或 X.Y.Z",
    )


def validate_mirror(mirror: str) -> str:
    """验证镜像源是否有效."""
    if mirror not in conf.LIB_MIRROR_URLS:
        raise PyPackConfigError(
            f"无效的镜像源: {mirror}",
            suggestion=f"支持的镜像源: {', '.join(conf.LIB_MIRROR_URLS.keys())}",
        )
    return mirror
