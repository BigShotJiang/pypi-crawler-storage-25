"""图片转PDF脚本.

将多张图片合并成一个PDF文件, 支持多种图片格式和页面设置.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from bitool.cmd import CommandScheduler, ImagesToPdfCommand
from bitool.core import JsonConfig, logger
from bitool.skills._base import BaseSkill


class ImageToPdfConfig(JsonConfig):
    """图片转PDF配置类."""

    FORMAT: str = "pdf"
    PAGE_SIZE: str = "auto"
    VALID_IMAGE_FORMATS: set[str] = {"png", "jpg", "jpeg", "bmp", "gif", "tiff", "tif"}
    VALID_OUTPUT_FORMATS: set[str] = {"pdf"}


conf = ImageToPdfConfig()


class Img2PdfSkill(BaseSkill):
    """图片转PDF技能."""

    name = "img2pdf"
    description = "将图片转换为PDF"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "input_paths",
            type=str,
            nargs="*",
            default=None,
            help="输入图片文件路径(可选, 默认搜索当前目录)",
        )
        parser.add_argument(
            "output_path",
            type=str,
            nargs="?",
            default=None,
            help="输出PDF文件路径",
        )
        parser.add_argument(
            "--page-size",
            type=str,
            default=conf.PAGE_SIZE,
            help="页面大小 (auto, A4, letter等)",
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建图片转PDF调度器."""
        # 验证输入路径
        if args.input_paths:
            input_paths = [Path(p) for p in args.input_paths]
        else:
            # 自动搜索当前目录下的图片文件
            current_dir = Path.cwd()
            input_paths = []
            for ext in conf.VALID_IMAGE_FORMATS:
                input_paths.extend(current_dir.glob(f"*.{ext}"))
                input_paths.extend(current_dir.glob(f"*.{ext.upper()}"))

            if not input_paths:
                logger.error(f"在当前目录 {current_dir} 中未找到图片文件")
                sys.exit(1)

            # 去重并排序
            input_paths = sorted(set(input_paths))
            logger.info(
                f"在当前目录 {current_dir} 中找到 {len(input_paths)} 个图片文件",
            )
            logger.info(f"将处理: {', '.join([str(p.name) for p in input_paths])}")

        for input_path in input_paths:
            if not input_path.exists():
                logger.error(f"未找到输入文件: {input_path}")
                sys.exit(1)
            # 验证图片格式
            if input_path.suffix.lower().lstrip(".") not in conf.VALID_IMAGE_FORMATS:
                logger.error(
                    f"不支持的图片格式: {input_path.suffix}, 请选择 {conf.VALID_IMAGE_FORMATS}",
                )
                sys.exit(1)

        # 确定输出路径
        output_path = Path(args.output_path) if args.output_path else None
        if output_path is None:
            # 默认输出到第一个图片所在目录, 命名为 output.pdf
            output_path = input_paths[0].parent / "output.pdf"

        # 确保输出目录存在
        if not output_path.parent.exists():
            output_path.parent.mkdir(parents=True)
            logger.info(f"创建输出目录: {output_path.parent}")

        # 验证输出格式
        if output_path.suffix.lower().lstrip(".") not in conf.VALID_OUTPUT_FORMATS:
            logger.error(
                f"不支持的输出格式: {output_path.suffix}, 请选择 {conf.VALID_OUTPUT_FORMATS}",
            )
            sys.exit(1)

        logger.info(
            f"开始转换: {len(input_paths)} 张图片 -> {output_path} (页面大小={args.page_size})",
        )

        return CommandScheduler(
            commands=[
                ImagesToPdfCommand(
                    image_paths=input_paths,
                    output_path=output_path,
                    page_size=args.page_size,
                ),
            ],
        )


def main() -> None:
    """图片转PDF主函数."""
    Img2PdfSkill().run_cli()
