"""GUI应用截图工具.

支持启动指定的GUI应用并截图,
可以截取全屏、指定窗口或区域.
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

from bitool.cmd import CommandScheduler, RunCommand
from bitool.core import JsonConfig, logger
from bitool.skills._base import BaseSkill


class ScreenshotConfig(JsonConfig):
    """截图技能配置类."""

    DEFAULT_DELAY: int = 2
    DEFAULT_OUTPUT_FORMAT: str = "png"
    VALID_FORMATS: set[str] = {"png", "jpg", "jpeg", "bmp"}


conf = ScreenshotConfig()


def _take_screenshot_with_qt(
    output_path: Path,
    window_title: str | None = None,
) -> None:
    """使用Qt进行截图操作.

    Parameters
    ----------
    output_path : Path
        截图保存路径
    window_title : str, optional
        窗口标题, 用于截取特定窗口
    """
    # 延迟导入Qt相关, 避免没有安装PySide时出错
    try:
        from bitool.gui.compat import QApplication
    except ImportError as e:
        logger.error(f"无法导入Qt模块: {e}. 请确保安装了bitool[app]依赖.")
        sys.exit(1)

    # 获取或创建QApplication实例
    app = QApplication.instance()
    if app is None:
        app = QApplication(sys.argv)

    # 获取主屏幕
    screen = app.primaryScreen()
    if screen is None:
        logger.error("无法获取屏幕")
        sys.exit(1)

    # 截取全屏
    logger.info("正在截取屏幕...")
    pixmap = screen.grabWindow(0)

    # 保存图片
    output_format = output_path.suffix.lstrip(".").lower()
    if output_format not in conf.VALID_FORMATS:
        output_format = conf.DEFAULT_OUTPUT_FORMAT

    success = pixmap.save(str(output_path), output_format.upper())
    if success:
        logger.info(f"截图已保存至: {output_path}")
    else:
        logger.error(f"保存截图失败: {output_path}")
        sys.exit(1)


class ScreenshotSkill(BaseSkill):
    """截图技能实现.

    支持启动指定的GUI应用并截图,
    可以延时等待应用启动后再截图.
    """

    name = "screenshot"
    description = "GUI应用截图工具"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加截图命令参数.

        Parameters
        ----------
        parser : argparse.ArgumentParser
            参数解析器
        """
        parser.add_argument(
            "output_path",
            type=str,
            nargs="?",
            default="screenshot.png",
            help="截图保存路径 (默认: screenshot.png)",
        )
        parser.add_argument(
            "-d",
            "--delay",
            type=int,
            default=conf.DEFAULT_DELAY,
            help=f"截图延迟时间(秒) (默认: {conf.DEFAULT_DELAY})",
        )
        parser.add_argument(
            "-a",
            "--app",
            type=str,
            default=None,
            help="要启动的应用命令 (可选, 启动后自动截图)",
        )
        parser.add_argument(
            "-t",
            "--title",
            type=str,
            default=None,
            help="窗口标题 (可选, 截取特定窗口)",
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建截图命令调度器.

        Parameters
        ----------
        args : argparse.Namespace
            解析后的命令行参数

        Returns
        -------
        CommandScheduler
            配置好的截图命令调度器
        """
        output_path = Path(args.output_path).resolve()

        # 确保输出目录存在
        if not output_path.parent.exists():
            output_path.parent.mkdir(parents=True, exist_ok=True)
            logger.info(f"创建输出目录: {output_path.parent}")

        commands = []

        # 如果指定了应用, 先启动应用
        if args.app:
            logger.info(f"将在 {args.delay} 秒后启动应用: {args.app}")

            # 启动应用的命令
            def _start_app() -> None:
                logger.info(f"正在启动应用: {args.app}")
                import shlex

                try:
                    cmd_args = shlex.split(args.app)
                    from bitool.cmd import execute

                    execute(cmd_args)
                except (OSError, RuntimeError) as e:
                    logger.error(f"启动应用失败: {e}")

            commands.append(RunCommand(cmd=_start_app))

        # 添加延迟
        def _delay() -> None:
            logger.info(f"等待 {args.delay} 秒后截图...")
            time.sleep(args.delay)

        commands.append(RunCommand(cmd=_delay))

        # 截图命令
        def _do_screenshot() -> None:
            _take_screenshot_with_qt(output_path, args.title)

        commands.append(RunCommand(cmd=_do_screenshot))

        return CommandScheduler(commands=commands)


def main() -> None:
    """主函数入口.

    创建截图技能实例并运行.
    """
    skill = ScreenshotSkill()
    skill.run_cli()
