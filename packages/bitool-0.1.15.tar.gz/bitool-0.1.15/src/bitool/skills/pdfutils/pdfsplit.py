"""PDF拆分脚本.

将PDF文件按页数、文件数或指定范围拆分成多个小文件.

增强功能:
- 输出目录支持
- 递归搜索子目录
- 静默模式
- 跳过已存在文件
"""

from __future__ import annotations

import argparse
from pathlib import Path

from bitool.cmd import CommandScheduler, SplitPdfCommand
from bitool.core import logger
from bitool.skills._pdf_base import EnhancedPdfSkill, PdfSkillConfig


class PdfSplitConfig(PdfSkillConfig):
    """PDF拆分配置类."""

    DEFAULT_PAGES_PER_FILE: int = 1
    OUTPUT_PREFIX: str = "part_"


conf = PdfSplitConfig()


class PdfSplitSkill(EnhancedPdfSkill):
    """PDF拆分技能."""

    name = "pdfsplit"
    description = "拆分PDF文件"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "input_path",
            type=str,
            nargs="?",
            default=None,
            help="输入PDF文件路径(可选, 默认搜索当前目录)",
        )
        parser.add_argument(
            "-o",
            "--output",
            type=str,
            default=None,
            help="输出目录(可选, 默认输出到输入文件所在目录的split子目录)",
        )
        parser.add_argument(
            "-s",
            "--size",
            type=int,
            default=conf.DEFAULT_PAGES_PER_FILE,
            help=f"每个输出文件的页数 (默认: {conf.DEFAULT_PAGES_PER_FILE})",
        )
        super().add_arguments(parser)

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建PDF拆分调度器."""
        self._quiet_mode = args.quiet
        input_paths = self._resolve_input_paths(
            [args.input_path] if args.input_path else None,
            recursive=args.recursive,
        )
        self._validate_size(args.size)
        self._init_progress(len(input_paths))

        commands = []

        for input_path in input_paths:
            output_dir = self._resolve_output_dir(args.output, input_path)
            if not self._quiet_mode:
                logger.info(f"处理: {input_path} -> {output_dir}")
            commands.append(
                SplitPdfCommand(
                    input_path=input_path,
                    output_dir=output_dir,
                    pages_per_file=args.size,
                ),
            )

        if not self._quiet_mode:
            logger.info(f"开始拆分 {len(commands)} 个PDF文件 (每页 {args.size} 页)")

        return CommandScheduler(commands=commands)

    def _resolve_output_dir(self, output_dir: str | None, input_path: Path) -> Path:
        """解析输出目录."""
        if output_dir:
            return Path(output_dir)
        return input_path.parent / "split"

    def _validate_size(self, size: int) -> None:
        """验证页数参数."""
        if size <= 0:
            logger.error("每页文件页数必须大于0")
            raise ValueError("Invalid size")


def main() -> None:
    """PDF拆分主函数."""
    PdfSplitSkill().run_cli()
