"""PDF布局调整脚本.

批量调整页面方向、尺寸、边距等.
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass, field
from pathlib import Path

from bitool.cmd import CommandScheduler
from bitool.cmd._base import BaseCommand
from bitool.core import JsonConfig, logger
from bitool.skills._base import BaseSkill

try:
    import fitz

    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False


class PdfLayoutConfig(JsonConfig):
    """PDF布局配置类."""

    OUTPUT_SUFFIX: str = ".layout.pdf"


conf = PdfLayoutConfig()


@dataclass
class PdfLayoutCommand(BaseCommand):
    """PDF布局调整命令."""

    name = "pdf_layout"
    description = "调整PDF布局"

    input_path: Path = field(default_factory=Path)
    output_path: Path = field(default_factory=Path)
    pagesize: str = ""
    margin_left: int = 0
    margin_right: int = 0
    margin_top: int = 0
    margin_bottom: int = 0
    orientation: str = ""

    def run(self) -> bool:
        """执行PDF布局调整."""
        if not HAS_PYMUPDF:
            logger.error("未安装PyMuPDF库, 请安装: pip install PyMuPDF")
            return False

        if not self.input_path.exists():
            logger.error(f"文件不存在: {self.input_path}")
            return False

        try:
            doc = fitz.open(str(self.input_path))
            new_doc = fitz.open()

            page_sizes = {
                "a4": (595, 842),
                "letter": (612, 792),
                "legal": (612, 1008),
                "a3": (842, 1190),
                "a5": (420, 595),
            }

            for page in doc:
                if self.pagesize and self.pagesize.lower() in page_sizes:
                    width, height = page_sizes[self.pagesize.lower()]
                else:
                    width, height = page.rect.width, page.rect.height

                if self.orientation == "landscape":
                    width, height = height, width

                new_page = new_doc.new_page(width=width, height=height)

                dst_rect = fitz.Rect(
                    self.margin_left,
                    self.margin_top,
                    width - self.margin_right,
                    height - self.margin_bottom,
                )

                new_page.show_pdf_page(dst_rect, doc, page.number)

            self.output_path.parent.mkdir(parents=True, exist_ok=True)
            new_doc.save(str(self.output_path))
            new_doc.close()
            doc.close()

            logger.info(f"布局调整完成: {self.output_path}")

        except Exception as e:  # noqa: BLE001
            logger.error(f"布局调整失败: {e}")
            return False
        else:
            return True


class PdfLayoutSkill(BaseSkill):
    """PDF布局调整技能."""

    name = "pdflayout"
    description = "调整PDF页面布局"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "input_path",
            type=str,
            nargs="?",
            default=None,
            help="输入PDF文件路径(可选, 默认搜索当前目录)",
        )
        parser.add_argument(
            "-o",
            "--output",
            type=str,
            default=None,
            help="输出文件路径",
        )
        parser.add_argument(
            "-p",
            "--pagesize",
            type=str,
            choices=["a4", "letter", "legal", "a3", "a5"],
            default="",
            help="页面尺寸: a4, letter, legal, a3, a5",
        )
        parser.add_argument(
            "-r",
            "--orientation",
            type=str,
            choices=["portrait", "landscape"],
            default="",
            help="页面方向: portrait(纵向), landscape(横向)",
        )
        parser.add_argument("-ml", "--margin-left", type=int, default=0, help="左边距")
        parser.add_argument("-mr", "--margin-right", type=int, default=0, help="右边距")
        parser.add_argument("-mt", "--margin-top", type=int, default=0, help="顶部边距")
        parser.add_argument(
            "-mb",
            "--margin-bottom",
            type=int,
            default=0,
            help="底部边距",
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建PDF布局调度器."""
        input_path = self._resolve_input_path(args.input_path)
        output_path = self._resolve_output_path(args.output, input_path)

        logger.info(f"开始布局调整: {input_path}")
        if args.pagesize:
            logger.info(f"  - 页面尺寸: {args.pagesize}")
        if args.orientation:
            logger.info(f"  - 页面方向: {args.orientation}")
        if any(
            [args.margin_left, args.margin_right, args.margin_top, args.margin_bottom],
        ):
            logger.info(
                f"  - 边距: 左={args.margin_left}, 右={args.margin_right}, 上={args.margin_top}, 下={args.margin_bottom}",
            )

        return CommandScheduler(
            commands=[
                PdfLayoutCommand(
                    input_path=input_path,
                    output_path=output_path,
                    pagesize=args.pagesize,
                    margin_left=args.margin_left,
                    margin_right=args.margin_right,
                    margin_top=args.margin_top,
                    margin_bottom=args.margin_bottom,
                    orientation=args.orientation,
                ),
            ],
        )

    def _resolve_input_path(self, input_path: str | None) -> Path:
        """解析输入路径."""
        if input_path:
            path = Path(input_path)
        else:
            current_dir = Path.cwd()
            pdf_files = list(current_dir.glob("*.pdf")) + list(
                current_dir.glob("*.PDF"),
            )

            if not pdf_files:
                logger.error(f"在当前目录 {current_dir} 中未找到PDF文件")
                sys.exit(1)

            if len(pdf_files) > 1:
                logger.info(f"找到多个PDF文件, 将处理第一个: {pdf_files[0]}")

            path = pdf_files[0]

        if not path.exists():
            logger.error(f"未找到输入文件: {path}")
            sys.exit(1)

        if path.suffix.lower() != ".pdf":
            logger.error(f"不支持的文件格式: {path.suffix}, 请选择PDF文件")
            sys.exit(1)

        return path

    def _resolve_output_path(self, output: str | None, input_path: Path) -> Path:
        """解析输出路径."""
        if output:
            return Path(output)
        return input_path.with_suffix(conf.OUTPUT_SUFFIX)


def main() -> None:
    """PDF布局调整主函数."""
    PdfLayoutSkill().run_cli()
