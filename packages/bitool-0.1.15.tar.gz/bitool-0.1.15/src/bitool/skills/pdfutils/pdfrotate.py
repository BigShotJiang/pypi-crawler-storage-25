"""PDF页面旋转脚本.

旋转PDF文件的页面, 支持指定角度和页面范围.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from bitool.cmd import CommandScheduler
from bitool.cmd._base import BaseCommand
from bitool.core import JsonConfig, logger
from bitool.skills._base import BaseSkill

try:
    import fitz

    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False


class PdfRotateConfig(JsonConfig):
    """PDF旋转配置类."""

    DEFAULT_ANGLE: int = 90
    ALLOWED_ANGLES: tuple[int, ...] = (90, 180, 270)
    OUTPUT_SUFFIX: str = ".rotated.pdf"


conf = PdfRotateConfig()


class PdfRotateCommand(BaseCommand):
    """PDF页面旋转命令."""

    name = "pdf_rotate"
    description = "旋转PDF页面"

    input_path: Path = Path()
    output_path: Path = Path()
    angle: int = 90
    page_range: str = ""

    def run(self) -> bool:
        """执行PDF页面旋转."""
        if not HAS_PYMUPDF:
            logger.error("未安装PyMuPDF库, 请安装: pip install PyMuPDF")
            return False

        if not self.input_path.exists():
            logger.error(f"文件不存在: {self.input_path}")
            return False

        try:
            doc = fitz.open(str(self.input_path))
            total_pages = doc.page_count

            if self.page_range:
                pages = self._parse_page_range(self.page_range, total_pages)
            else:
                pages = list(range(total_pages))

            if not pages:
                logger.error("未指定有效的页面范围")
                doc.close()
                return False

            for page_num in pages:
                page = doc[page_num]
                page.set_rotation((page.rotation + self.angle) % 360)

            self.output_path.parent.mkdir(parents=True, exist_ok=True)
            doc.save(str(self.output_path))
            doc.close()

            logger.info(f"旋转完成: {self.output_path}")
            logger.info(f"旋转页面: {[p + 1 for p in pages]}")

        except Exception as e:  # noqa: BLE001
            logger.error(f"旋转失败: {e}")
            return False
        else:
            return True

    def _parse_page_range(self, range_str: str, total_pages: int) -> list[int]:
        """解析页面范围字符串."""
        pages = []
        for part in range_str.split(","):
            part = part.strip()
            if not part:
                continue
            if "-" in part:
                start_end = part.split("-")
                start = int(start_end[0]) if start_end[0] else 1
                end = int(start_end[1]) if start_end[1] else total_pages
                start = max(1, start)
                end = min(total_pages, end)
                pages.extend(range(start - 1, end))
            else:
                page = int(part)
                if 1 <= page <= total_pages:
                    pages.append(page - 1)
        return sorted(set(pages))


class PdfRotateSkill(BaseSkill):
    """PDF页面旋转技能."""

    name = "pdfrotate"
    description = "旋转PDF页面"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "input_path",
            type=str,
            nargs="?",
            default=None,
            help="输入PDF文件路径(可选, 默认搜索当前目录)",
        )
        parser.add_argument(
            "-o",
            "--output",
            type=str,
            default=None,
            help="输出文件路径",
        )
        parser.add_argument(
            "-a",
            "--angle",
            type=int,
            default=conf.DEFAULT_ANGLE,
            choices=conf.ALLOWED_ANGLES,
            help=f"旋转角度 (默认: {conf.DEFAULT_ANGLE})",
        )
        parser.add_argument(
            "-r",
            "--range",
            type=str,
            default="",
            help="页面范围, 如: 1-5,7,10-",
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建PDF旋转调度器."""
        input_path = self._resolve_input_path(args.input_path)
        output_path = self._resolve_output_path(args.output, input_path)

        logger.info(f"开始旋转PDF: {input_path}")
        logger.info(f"旋转角度: {args.angle}度")
        if args.range:
            logger.info(f"页面范围: {args.range}")

        return CommandScheduler(
            commands=[
                PdfRotateCommand(
                    input_path=input_path,
                    output_path=output_path,
                    angle=args.angle,
                    page_range=args.range,
                ),
            ],
        )

    def _resolve_input_path(self, input_path: str | None) -> Path:
        """解析输入路径."""
        if input_path:
            path = Path(input_path)
        else:
            current_dir = Path.cwd()
            pdf_files = list(current_dir.glob("*.pdf")) + list(
                current_dir.glob("*.PDF"),
            )

            if not pdf_files:
                logger.error(f"在当前目录 {current_dir} 中未找到PDF文件")
                sys.exit(1)

            if len(pdf_files) > 1:
                logger.info(f"找到多个PDF文件, 将处理第一个: {pdf_files[0]}")

            path = pdf_files[0]

        if not path.exists():
            logger.error(f"未找到输入文件: {path}")
            sys.exit(1)

        if path.suffix.lower() != ".pdf":
            logger.error(f"不支持的文件格式: {path.suffix}, 请选择PDF文件")
            sys.exit(1)

        return path

    def _resolve_output_path(self, output: str | None, input_path: Path) -> Path:
        """解析输出路径."""
        if output:
            return Path(output)
        return input_path.with_suffix(conf.OUTPUT_SUFFIX)


def main() -> None:
    """PDF页面旋转主函数."""
    PdfRotateSkill().run_cli()
