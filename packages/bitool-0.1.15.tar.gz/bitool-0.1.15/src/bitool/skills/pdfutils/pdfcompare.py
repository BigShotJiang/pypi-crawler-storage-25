"""PDF比较脚本.

比较两个PDF文件的内容差异并高亮显示.
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass, field
from pathlib import Path

from bitool.cmd import CommandScheduler
from bitool.cmd._base import BaseCommand
from bitool.core import JsonConfig, logger
from bitool.skills._base import BaseSkill

try:
    import fitz

    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False


class PdfCompareConfig(JsonConfig):
    """PDF比较配置类."""

    OUTPUT_SUFFIX: str = ".diff.pdf"
    HIGHLIGHT_COLOR: tuple = (1, 0.8, 0.8)


conf = PdfCompareConfig()


@dataclass
class PdfCompareCommand(BaseCommand):
    """PDF比较命令."""

    name = "pdf_compare"
    description = "比较两个PDF文件"

    input_path1: Path = field(default_factory=Path)
    input_path2: Path = field(default_factory=Path)
    output_path: Path = field(default_factory=Path)

    def run(self) -> bool:
        """执行PDF比较."""
        if not HAS_PYMUPDF:
            logger.error("未安装PyMuPDF库, 请安装: pip install PyMuPDF")
            return False

        if not self.input_path1.exists():
            logger.error(f"文件不存在: {self.input_path1}")
            return False

        if not self.input_path2.exists():
            logger.error(f"文件不存在: {self.input_path2}")
            return False

        try:
            doc1 = fitz.open(str(self.input_path1))
            doc2 = fitz.open(str(self.input_path2))

            max_pages = max(doc1.page_count, doc2.page_count)
            new_doc = fitz.open()

            for i in range(max_pages):
                page1 = doc1[i] if i < doc1.page_count else None
                page2 = doc2[i] if i < doc2.page_count else None

                if page1 and page2:
                    text1 = page1.get_text()
                    text2 = page2.get_text()

                    if text1 != text2:
                        new_page = new_doc.new_page(
                            width=page1.rect.width,
                            height=page1.rect.height,
                        )
                        new_page.insert_pdf(doc2, from_page=i, to_page=i)

                        words1 = page1.get_text("words")
                        words2 = page2.get_text("words")

                        words1_set = {(w[4], w[0], w[1], w[2], w[3]) for w in words1}
                        words2_set = {(w[4], w[0], w[1], w[2], w[3]) for w in words2}

                        added_words = words2_set - words1_set

                        for word in added_words:
                            rect = fitz.Rect(word[1], word[2], word[3], word[4])
                            new_page.add_highlight_annot(rect)

                    else:
                        new_doc.insert_pdf(doc2, from_page=i, to_page=i)

                elif page2:
                    new_doc.insert_pdf(doc2, from_page=i, to_page=i)

            self.output_path.parent.mkdir(parents=True, exist_ok=True)
            new_doc.save(str(self.output_path))
            new_doc.close()
            doc1.close()
            doc2.close()

            logger.info(f"PDF比较完成: {self.output_path}")

        except Exception as e:  # noqa: BLE001
            logger.error(f"PDF比较失败: {e}")
            return False
        else:
            return True


class PdfCompareSkill(BaseSkill):
    """PDF比较技能."""

    name = "pdfcompare"
    description = "比较两个PDF文件的差异"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument("input_path1", type=str, help="第一个PDF文件路径")
        parser.add_argument("input_path2", type=str, help="第二个PDF文件路径")
        parser.add_argument(
            "-o",
            "--output",
            type=str,
            default=None,
            help="输出文件路径",
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建PDF比较调度器."""
        input_path1 = Path(args.input_path1)
        input_path2 = Path(args.input_path2)

        if not input_path1.exists():
            logger.error(f"未找到文件: {input_path1}")
            sys.exit(1)

        if not input_path2.exists():
            logger.error(f"未找到文件: {input_path2}")
            sys.exit(1)

        if input_path1.suffix.lower() != ".pdf":
            logger.error(f"不支持的文件格式: {input_path1.suffix}")
            sys.exit(1)

        if input_path2.suffix.lower() != ".pdf":
            logger.error(f"不支持的文件格式: {input_path2.suffix}")
            sys.exit(1)

        if args.output:
            output_path = Path(args.output)
        else:
            output_path = input_path1.with_suffix(conf.OUTPUT_SUFFIX)

        logger.info("比较PDF文件:")
        logger.info(f"  - 基准文件: {input_path1}")
        logger.info(f"  - 比较文件: {input_path2}")

        return CommandScheduler(
            commands=[
                PdfCompareCommand(
                    input_path1=input_path1,
                    input_path2=input_path2,
                    output_path=output_path,
                ),
            ],
        )


def main() -> None:
    """PDF比较主函数."""
    PdfCompareSkill().run_cli()
