"""PDF合并脚本.

将多个PDF文件合并成一个PDF文件, 支持指定路径或自动搜索当前目录.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from bitool.cmd import CommandScheduler, MergePdfsCommand
from bitool.core import JsonConfig, logger
from bitool.skills._base import BaseSkill


class PdfMergeConfig(JsonConfig):
    """PDF合并配置类."""

    OUTPUT_FILENAME: str = "merged.pdf"


conf = PdfMergeConfig()


class PdfMergeSkill(BaseSkill):
    """PDF合并技能."""

    name = "pdfmerge"
    description = "合并多个PDF文件"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "input_paths",
            type=str,
            nargs="*",
            default=None,
            help="输入PDF文件路径(可选, 默认搜索当前目录)",
        )
        parser.add_argument(
            "-o",
            "--output",
            type=str,
            default=None,
            help=f"输出PDF文件路径(默认: {conf.OUTPUT_FILENAME})",
        )
        parser.add_argument(
            "-s",
            "--sort",
            type=str,
            choices=["name", "date", "size"],
            default="name",
            help="文件排序方式: name(文件名), date(修改时间), size(文件大小)",
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建PDF合并调度器."""
        input_paths = self._resolve_input_paths(args.input_paths)
        output_path = self._resolve_output_path(args.output, input_paths)
        sorted_paths = self._sort_paths(input_paths, args.sort)

        logger.info(f"开始合并 {len(sorted_paths)} 个PDF文件 -> {output_path}")
        logger.info(f"文件列表: {', '.join([str(p.name) for p in sorted_paths])}")

        return CommandScheduler(
            commands=[
                MergePdfsCommand(input_paths=sorted_paths, output_path=output_path),
            ],
        )

    def _resolve_input_paths(self, input_paths: list[str] | None) -> list[Path]:
        """解析输入路径."""
        if input_paths:
            paths = [Path(p) for p in input_paths]
        else:
            current_dir = Path.cwd()
            paths = list(current_dir.glob("*.pdf")) + list(current_dir.glob("*.PDF"))

            if not paths:
                logger.error(f"在当前目录 {current_dir} 中未找到PDF文件")
                sys.exit(1)

            logger.info(f"在当前目录 {current_dir} 中找到 {len(paths)} 个PDF文件")

        paths = sorted(set(paths))

        for path in paths:
            if not path.exists():
                logger.error(f"未找到输入文件: {path}")
                sys.exit(1)
            if path.suffix.lower() != ".pdf":
                logger.error(f"不支持的文件格式: {path.suffix}, 请选择PDF文件")
                sys.exit(1)

        return paths

    def _resolve_output_path(self, output: str | None, input_paths: list[Path]) -> Path:
        """解析输出路径."""
        if output:
            output_path = Path(output)
        else:
            output_path = input_paths[0].parent / conf.OUTPUT_FILENAME

        if output_path.suffix.lower() != ".pdf":
            output_path = output_path.with_suffix(".pdf")

        if not output_path.parent.exists():
            output_path.parent.mkdir(parents=True)
            logger.info(f"创建输出目录: {output_path.parent}")

        return output_path

    def _sort_paths(self, paths: list[Path], sort_by: str) -> list[Path]:
        """根据指定方式排序文件路径."""
        if sort_by == "name":
            return sorted(paths, key=lambda p: p.name.lower())
        if sort_by == "date":
            return sorted(paths, key=lambda p: p.stat().st_mtime)
        if sort_by == "size":
            return sorted(paths, key=lambda p: p.stat().st_size)
        return paths


def main() -> None:
    """PDF合并主函数."""
    PdfMergeSkill().run_cli()
