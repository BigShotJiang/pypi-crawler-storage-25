""" Base module for pdfutils."""
