"""PDF信息提取脚本.

提取PDF文件的元数据信息, 包括页数、作者、标题、创建日期等.
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime
from pathlib import Path

from bitool.cmd import CommandScheduler
from bitool.cmd._base import BaseCommand
from bitool.core import JsonConfig, logger
from bitool.skills._base import BaseSkill

try:
    import fitz

    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False


class PdfInfoConfig(JsonConfig):
    """PDF信息提取配置类."""

    pass


conf = PdfInfoConfig()


class PdfInfoCommand(BaseCommand):
    """提取PDF信息命令."""

    name = "pdf_info"
    description = "提取PDF文件信息"

    input_path: Path = Path()
    verbose: bool = False

    def run(self) -> bool:
        """执行PDF信息提取."""
        if not HAS_PYMUPDF:
            logger.error("未安装PyMuPDF库, 请安装: pip install PyMuPDF")
            return False

        if not self.input_path.exists():
            logger.error(f"文件不存在: {self.input_path}")
            return False

        try:
            doc = fitz.open(str(self.input_path))
            info = doc.metadata

            file_size = self.input_path.stat().st_size
            file_size_str = self._format_size(file_size)

            logger.info(f"\n{'=' * 60}")
            logger.info(f"文件: {self.input_path.name}")
            logger.info(f"路径: {self.input_path.resolve()}")
            logger.info(f"大小: {file_size_str}")
            logger.info(f"页数: {doc.page_count}")
            logger.info(f"{'=' * 60}")

            if info:
                logger.info("元数据:")
                metadata_fields = [
                    ("标题", "title"),
                    ("作者", "author"),
                    ("主题", "subject"),
                    ("关键词", "keywords"),
                    ("创建者", "creator"),
                    ("生产者", "producer"),
                    ("创建日期", "creationDate"),
                    ("修改日期", "modDate"),
                ]

                for label, key in metadata_fields:
                    value = info.get(key, "")
                    if value:
                        # 尝试解析日期格式
                        if key.endswith("Date") and value:
                            value = self._parse_pdf_date(value)
                        logger.info(f"  {label}: {value}")

            if self.verbose:
                logger.info("\n文档统计:")
                logger.info(f"  加密状态: {'是' if doc.is_encrypted else '否'}")
                logger.info(f"  PDF版本: {doc.pdf_version}")
                logger.info(f"  是否线性化: {'是' if doc.is_linearized else '否'}")

            doc.close()

        except Exception as e:  # noqa: BLE001
            logger.error(f"读取PDF信息失败: {e}")
            return False
        else:
            return True

    def _format_size(self, size: int) -> str:
        """格式化文件大小."""
        if size < 1024:
            return f"{size} 字节"
        elif size < 1024 * 1024:
            return f"{size / 1024:.2f} KB"
        elif size < 1024 * 1024 * 1024:
            return f"{size / (1024 * 1024):.2f} MB"
        else:
            return f"{size / (1024 * 1024 * 1024):.2f} GB"

    def _parse_pdf_date(self, date_str: str) -> str:
        """解析PDF日期格式."""
        if not date_str:
            return date_str
        if date_str.startswith("D:"):
            date_str = date_str[2:]
        formats = ["%Y%m%d%H%M%S", "%Y%m%d"]
        for fmt in formats:
            if len(date_str) >= len(fmt):
                try:
                    parsed_date = datetime.strptime(date_str[: len(fmt)], fmt)  # noqa: DTZ007
                    return parsed_date.strftime("%Y-%m-%d %H:%M:%S")
                except ValueError:
                    continue
        return date_str


class PdfInfoSkill(BaseSkill):
    """PDF信息提取技能."""

    name = "pdfinfo"
    description = "提取PDF文件信息"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "input_path",
            type=str,
            nargs="?",
            default=None,
            help="输入PDF文件路径(可选, 默认搜索当前目录)",
        )
        parser.add_argument("-v", "--verbose", action="store_true", help="显示详细信息")

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建PDF信息提取调度器."""
        input_path = self._resolve_input_path(args.input_path)

        return CommandScheduler(
            commands=[PdfInfoCommand(input_path=input_path, verbose=args.verbose)],
        )

    def _resolve_input_path(self, input_path: str | None) -> Path:
        """解析输入路径."""
        if input_path:
            path = Path(input_path)
        else:
            current_dir = Path.cwd()
            pdf_files = list(current_dir.glob("*.pdf")) + list(
                current_dir.glob("*.PDF"),
            )

            if not pdf_files:
                logger.error(f"在当前目录 {current_dir} 中未找到PDF文件")
                sys.exit(1)

            if len(pdf_files) > 1:
                logger.info("找到多个PDF文件:")
                for i, pdf in enumerate(pdf_files, 1):
                    logger.info(f"  {i}. {pdf.name}")
                logger.info(f"将显示第一个文件的信息: {pdf_files[0]}")

            path = pdf_files[0]

        if not path.exists():
            logger.error(f"未找到输入文件: {path}")
            sys.exit(1)

        if path.suffix.lower() != ".pdf":
            logger.error(f"不支持的文件格式: {path.suffix}, 请选择PDF文件")
            sys.exit(1)

        return path


def main() -> None:
    """PDF信息提取主函数."""
    PdfInfoSkill().run_cli()
