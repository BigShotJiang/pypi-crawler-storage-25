"""PDF水印脚本.

为PDF文件添加文本水印或图片水印.

增强功能:
- 输出目录支持
- 递归搜索子目录
- 静默模式
- 跳过已存在文件
- 图片水印支持
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path

from bitool.cmd import CommandScheduler
from bitool.cmd._base import BaseCommand
from bitool.core import logger
from bitool.skills import BaseSkill
from bitool.skills.pdf_utils import PdfSkillConfig

try:
    import fitz

    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False


class PdfWatermarkConfig(PdfSkillConfig):
    """PDF水印配置类."""

    DEFAULT_TEXT: str = "CONFIDENTIAL"
    DEFAULT_FONT_SIZE: int = 48
    DEFAULT_OPACITY: float = 0.3
    DEFAULT_ROTATION: int = 45
    OUTPUT_SUFFIX: str = ".watermarked.pdf"


conf = PdfWatermarkConfig()


@dataclass
class PdfWatermarkCommand(BaseCommand):
    """PDF水印命令."""

    name = "pdf_watermark"
    description = "为PDF添加水印"

    input_path: Path = field(default_factory=Path)
    output_path: Path = field(default_factory=Path)
    text: str = ""
    image_path: Path = field(default_factory=Path)
    font_size: int = 48
    opacity: float = 0.3
    rotation: int = 45
    position: str = "center"
    scale: float = 1.0

    def run(self) -> bool:
        """执行PDF水印添加."""
        if not HAS_PYMUPDF:
            logger.error("未安装PyMuPDF库, 请安装: pip install PyMuPDF")
            return False

        if not self.input_path.exists():
            logger.error(f"文件不存在: {self.input_path}")
            return False

        try:
            doc = fitz.open(str(self.input_path))

            for page in doc:
                if self.image_path and self.image_path.exists():
                    self._add_image_watermark(page)
                else:
                    self._add_text_watermark(page)

            self.output_path.parent.mkdir(parents=True, exist_ok=True)
            doc.save(str(self.output_path))
            doc.close()

            logger.info(f"水印添加完成: {self.output_path}")

        except Exception as e:  # noqa: BLE001
            logger.error(f"添加水印失败: {e}")
            return False
        else:
            return True

    def _add_text_watermark(self, page: fitz.Page) -> None:
        """添加文本水印."""
        rect = page.rect
        text_width = fitz.get_text_length(self.text, fontsize=self.font_size)

        x = (rect.width - text_width) / 2
        y = rect.height / 2

        page.insert_text(
            (x, y),
            self.text,
            fontsize=self.font_size,
            rotate=self.rotation,
            opacity=self.opacity,
            color=(0, 0, 0),
        )

    def _add_image_watermark(self, page: fitz.Page) -> None:
        """添加图片水印."""
        rect = page.rect
        img_rect = self._calculate_image_position(rect)

        page.insert_image(
            img_rect,
            filename=str(self.image_path),
            opacity=self.opacity,
            rotate=self.rotation,
        )

    def _calculate_image_position(self, rect: fitz.Rect) -> fitz.Rect:
        """计算图片位置."""
        img_width = rect.width * self.scale
        img_height = rect.height * self.scale

        x = (rect.width - img_width) / 2
        y = (rect.height - img_height) / 2

        return fitz.Rect(x, y, x + img_width, y + img_height)


class PdfWatermarkSkill(BaseSkill):
    """PDF水印技能."""

    name = "pdfwatermark"
    description = "为PDF添加文本或图片水印"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "input_paths",
            type=str,
            nargs="*",
            default=None,
            help="输入PDF文件路径(可选, 默认搜索当前目录)",
        )
        parser.add_argument(
            "-o",
            "--output",
            type=str,
            default=None,
            help="输出文件路径(单文件模式)",
        )
        parser.add_argument(
            "-t",
            "--text",
            type=str,
            default=conf.DEFAULT_TEXT,
            help=f"水印文本 (默认: {conf.DEFAULT_TEXT})",
        )
        parser.add_argument(
            "-i",
            "--image",
            type=str,
            default=None,
            help="水印图片路径 (优先于文本)",
        )
        parser.add_argument(
            "-s",
            "--font-size",
            type=int,
            default=conf.DEFAULT_FONT_SIZE,
            help=f"字体大小 (默认: {conf.DEFAULT_FONT_SIZE})",
        )
        parser.add_argument(
            "--opacity",
            type=float,
            default=conf.DEFAULT_OPACITY,
            help=f"透明度 (0.0-1.0, 默认: {conf.DEFAULT_OPACITY})",
        )
        parser.add_argument(
            "-r",
            "--rotation",
            type=int,
            default=conf.DEFAULT_ROTATION,
            help=f"旋转角度 (默认: {conf.DEFAULT_ROTATION})",
        )
        parser.add_argument(
            "--scale",
            type=float,
            default=1.0,
            help="图片缩放比例 (默认: 1.0)",
        )
        super().add_arguments(parser)

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建PDF水印调度器."""
        self._quiet_mode = args.quiet
        input_paths = self._resolve_input_paths(
            args.input_paths,
            recursive=args.recursive,
        )
        self._init_progress(len(input_paths))

        commands = []
        image_path = Path(args.image) if args.image else Path()

        if len(input_paths) == 1 and args.output:
            output_path = Path(args.output)
            if not self._should_skip(output_path, skip_existing=args.skip_existing):
                commands.append(
                    PdfWatermarkCommand(
                        input_path=input_paths[0],
                        output_path=output_path,
                        text=args.text,
                        image_path=image_path,
                        font_size=args.font_size,
                        opacity=args.opacity,
                        rotation=args.rotation,
                        scale=args.scale,
                    ),
                )
                self._log_progress(input_paths[0], output_path)
        else:
            for input_path in input_paths:
                output_path = self._resolve_output_path(
                    input_path,
                    args.output_dir,
                    conf.OUTPUT_SUFFIX,
                )
                if not self._should_skip(output_path, skip_existing=args.skip_existing):
                    commands.append(
                        PdfWatermarkCommand(
                            input_path=input_path,
                            output_path=output_path,
                            text=args.text,
                            image_path=image_path,
                            font_size=args.font_size,
                            opacity=args.opacity,
                            rotation=args.rotation,
                            scale=args.scale,
                        ),
                    )
                    self._log_progress(input_path, output_path)

        if not commands:
            if not self._quiet_mode:
                logger.info("没有需要处理的文件")
            return CommandScheduler(commands=[])

        if not self._quiet_mode:
            logger.info(f"开始为 {len(commands)} 个PDF添加水印")
            if args.image:
                logger.info(f"  - 使用图片水印: {args.image}")
            else:
                logger.info(f"  - 使用文本水印: {args.text}")

        return CommandScheduler(commands=commands)


def main() -> None:
    """PDF水印主函数."""
    PdfWatermarkSkill().run_cli()
