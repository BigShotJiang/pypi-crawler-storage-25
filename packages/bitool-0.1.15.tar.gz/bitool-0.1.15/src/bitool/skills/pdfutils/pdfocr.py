"""PDF OCR识别脚本.

对扫描版PDF进行文字识别,生成可搜索的文本层.
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass, field
from pathlib import Path

from bitool.cmd import CommandScheduler
from bitool.cmd._base import BaseCommand
from bitool.core import JsonConfig, logger
from bitool.skills._base import BaseSkill

try:
    import fitz

    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False

try:
    import pytesseract
    from PIL import Image

    HAS_OCR = True
except ImportError:
    HAS_OCR = False


class PdfOcrConfig(JsonConfig):
    """PDF OCR配置类."""

    OUTPUT_SUFFIX: str = ".ocr.pdf"
    DEFAULT_LANG: str = "chi_sim+eng"


conf = PdfOcrConfig()


@dataclass
class PdfOcrCommand(BaseCommand):
    """PDF OCR识别命令."""

    name = "pdf_ocr"
    description = "对PDF进行OCR识别"

    input_path: Path = field(default_factory=Path)
    output_path: Path = field(default_factory=Path)
    lang: str = ""

    def run(self) -> bool:
        """执行PDF OCR识别."""
        if not HAS_PYMUPDF:
            logger.error("未安装PyMuPDF库, 请安装: pip install PyMuPDF")
            return False

        if not HAS_OCR:
            logger.error("未安装OCR相关库, 请安装: pip install pytesseract pillow")
            return False

        if not self.input_path.exists():
            logger.error(f"文件不存在: {self.input_path}")
            return False

        try:
            doc = fitz.open(str(self.input_path))
            new_doc = fitz.open()

            for page in doc:
                pix = page.get_pixmap()
                img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)

                ocr_text = pytesseract.image_to_string(img, lang=self.lang)

                new_page = new_doc.new_page(
                    width=page.rect.width,
                    height=page.rect.height,
                )

                new_page.insert_image(new_page.rect, pixmap=pix)

                text_rect = fitz.Rect(0, 0, page.rect.width, page.rect.height)
                new_page.insert_textbox(text_rect, ocr_text)

            self.output_path.parent.mkdir(parents=True, exist_ok=True)
            new_doc.save(str(self.output_path))
            new_doc.close()
            doc.close()

            logger.info(f"OCR识别完成: {self.output_path}")

        except Exception as e:  # noqa: BLE001
            logger.error(f"OCR识别失败: {e}")
            return False
        else:
            return True


class PdfOcrSkill(BaseSkill):
    """PDF OCR识别技能."""

    name = "pdfocr"
    description = "对PDF进行OCR文字识别"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "input_path",
            type=str,
            nargs="?",
            default=None,
            help="输入PDF文件路径(可选, 默认搜索当前目录)",
        )
        parser.add_argument(
            "-o",
            "--output",
            type=str,
            default=None,
            help="输出文件路径",
        )
        parser.add_argument(
            "-l",
            "--lang",
            type=str,
            default=conf.DEFAULT_LANG,
            help=f"OCR语言(默认: {conf.DEFAULT_LANG}, 支持: chi_sim, eng, chi_tra等)",
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建PDF OCR调度器."""
        input_path = self._resolve_input_path(args.input_path)
        output_path = self._resolve_output_path(args.output, input_path)

        logger.info(f"开始OCR识别: {input_path}")
        logger.info(f"  - 语言: {args.lang}")

        return CommandScheduler(
            commands=[
                PdfOcrCommand(
                    input_path=input_path,
                    output_path=output_path,
                    lang=args.lang,
                ),
            ],
        )

    def _resolve_input_path(self, input_path: str | None) -> Path:
        """解析输入路径."""
        if input_path:
            path = Path(input_path)
        else:
            current_dir = Path.cwd()
            pdf_files = list(current_dir.glob("*.pdf")) + list(
                current_dir.glob("*.PDF"),
            )

            if not pdf_files:
                logger.error(f"在当前目录 {current_dir} 中未找到PDF文件")
                sys.exit(1)

            if len(pdf_files) > 1:
                logger.info(f"找到多个PDF文件, 将处理第一个: {pdf_files[0]}")

            path = pdf_files[0]

        if not path.exists():
            logger.error(f"未找到输入文件: {path}")
            sys.exit(1)

        if path.suffix.lower() != ".pdf":
            logger.error(f"不支持的文件格式: {path.suffix}, 请选择PDF文件")
            sys.exit(1)

        return path

    def _resolve_output_path(self, output: str | None, input_path: Path) -> Path:
        """解析输出路径."""
        if output:
            return Path(output)
        return input_path.with_suffix(conf.OUTPUT_SUFFIX)


def main() -> None:
    """PDF OCR识别主函数."""
    PdfOcrSkill().run_cli()
