"""PDF加密解密脚本.

对PDF文件进行加密和解密操作, 支持批量处理.

增强功能:
- 输出目录支持
- 递归搜索子目录
- 静默模式
- 跳过已存在文件
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path

from bitool.cmd import CommandScheduler
from bitool.cmd._base import BaseCommand
from bitool.core import logger
from bitool.skills._pdf_base import EnhancedPdfSkill, PdfSkillConfig

try:
    import pypdf

    HAS_PYPDF = True
except ImportError:
    HAS_PYPDF = False


class PdfEncryptConfig(PdfSkillConfig):
    """PDF加密解密配置类."""

    OUTPUT_SUFFIX_ENCRYPTED: str = ".enc.pdf"
    OUTPUT_SUFFIX_DECRYPTED: str = ".dec.pdf"


conf = PdfEncryptConfig()


@dataclass
class PdfEncryptCommand(BaseCommand):
    """PDF加密命令."""

    name = "pdf_encrypt"
    description = "加密PDF文件"

    input_path: Path = field(default_factory=Path)
    output_path: Path = field(default_factory=Path)
    password: str = ""

    def run(self) -> bool:
        """执行PDF加密."""
        if not HAS_PYPDF:
            logger.error("未安装pypdf库, 请安装: pip install pypdf")
            return False

        if not self.input_path.exists():
            logger.error(f"文件不存在: {self.input_path}")
            return False

        try:
            reader = pypdf.PdfReader(str(self.input_path))
            writer = pypdf.PdfWriter()

            for page in reader.pages:
                writer.add_page(page)

            writer.encrypt(
                user_password=self.password,
                owner_password=self.password,
                use_128bit=True,
            )

            self.output_path.parent.mkdir(parents=True, exist_ok=True)

            with open(self.output_path, "wb") as f:
                writer.write(f)

            logger.info(f"加密完成: {self.output_path}")

        except Exception as e:  # noqa: BLE001
            logger.error(f"加密失败: {e}")
            return False
        else:
            return True


@dataclass
class PdfDecryptCommand(BaseCommand):
    """PDF解密命令."""

    name = "pdf_decrypt"
    description = "解密PDF文件"

    input_path: Path = field(default_factory=Path)
    output_path: Path = field(default_factory=Path)
    password: str = ""

    def run(self) -> bool:
        """执行PDF解密."""
        if not HAS_PYPDF:
            logger.error("未安装pypdf库, 请安装: pip install pypdf")
            return False

        if not self.input_path.exists():
            logger.error(f"文件不存在: {self.input_path}")
            return False

        try:
            reader = pypdf.PdfReader(str(self.input_path))

            if reader.is_encrypted:
                reader.decrypt(self.password)

            writer = pypdf.PdfWriter()

            for page in reader.pages:
                writer.add_page(page)

            self.output_path.parent.mkdir(parents=True, exist_ok=True)

            with open(self.output_path, "wb") as f:
                writer.write(f)

            logger.info(f"解密完成: {self.output_path}")

        except Exception as e:  # noqa: BLE001
            logger.error(f"解密失败: {e}")
            return False
        else:
            return True


class PdfEncryptSkill(EnhancedPdfSkill):
    """PDF加密解密技能."""

    name = "pdfencrypt"
    description = "加密/解密PDF文件"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "action",
            type=str,
            choices=["encrypt", "decrypt"],
            help="操作类型: encrypt(加密), decrypt(解密)",
        )
        parser.add_argument("password", type=str, help="密码")
        parser.add_argument(
            "input_paths",
            type=str,
            nargs="*",
            default=None,
            help="输入PDF文件路径(可选, 默认搜索当前目录)",
        )
        parser.add_argument(
            "-d",
            "--output-dir",
            type=str,
            default=None,
            help="输出目录",
        )
        super().add_arguments(parser)

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建PDF加密解密调度器."""
        self._quiet_mode = args.quiet
        input_paths = self._resolve_input_paths(
            args.input_paths,
            recursive=args.recursive,
        )
        self._init_progress(len(input_paths))

        commands = []
        suffix = (
            conf.OUTPUT_SUFFIX_ENCRYPTED
            if args.action == "encrypt"
            else conf.OUTPUT_SUFFIX_DECRYPTED
        )

        for input_path in input_paths:
            output_path = self._resolve_output_path(input_path, args.output_dir, suffix)
            if not self._should_skip(output_path, skip_existing=args.skip_existing):
                if args.action == "encrypt":
                    cmd = PdfEncryptCommand(
                        input_path=input_path,
                        output_path=output_path,
                        password=args.password,
                    )
                else:
                    cmd = PdfDecryptCommand(
                        input_path=input_path,
                        output_path=output_path,
                        password=args.password,
                    )
                commands.append(cmd)
                self._log_progress(input_path, output_path)

        if not commands:
            if not self._quiet_mode:
                logger.info("没有需要处理的文件")
            return CommandScheduler(commands=[])

        if not self._quiet_mode:
            logger.info(f"开始{args.action} {len(commands)} 个PDF文件")

        return CommandScheduler(commands=commands)


def main() -> None:
    """PDF加密解密主函数."""
    PdfEncryptSkill().run_cli()
