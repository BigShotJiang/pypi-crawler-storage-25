"""PDF页面裁剪脚本.

裁剪PDF页面边缘空白区域,支持自定义边距或自动检测内容边界.

增强功能:
- 输出目录支持 (--output-dir)
- 递归搜索子目录 (--recursive)
- 静默模式 (--quiet)
- 跳过已存在文件 (--skip-existing)
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path

from bitool.cmd import CommandScheduler
from bitool.cmd._base import BaseCommand
from bitool.core import logger
from bitool.skills._base import BaseSkill
from bitool.skills.pdf_utils import PdfSkillConfig, PdfSkillEnhancer

try:
    import fitz

    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False


class PdfCropConfig(PdfSkillConfig):
    """PDF裁剪配置类."""

    OUTPUT_SUFFIX: str = ".cropped.pdf"
    DEFAULT_MARGIN: int = 0


conf = PdfCropConfig()


@dataclass
class PdfCropCommand(BaseCommand):
    """PDF页面裁剪命令."""

    name = "pdf_crop"
    description = "裁剪PDF页面"

    input_path: Path = field(default_factory=Path)
    output_path: Path = field(default_factory=Path)
    left: int = 0
    right: int = 0
    top: int = 0
    bottom: int = 0
    auto: bool = False
    margin: int = 0

    def run(self) -> bool:
        """执行PDF页面裁剪."""
        if not HAS_PYMUPDF:
            logger.error("未安装PyMuPDF库, 请安装: pip install PyMuPDF")
            return False

        if not self.input_path.exists():
            logger.error(f"文件不存在: {self.input_path}")
            return False

        try:
            doc = fitz.open(str(self.input_path))
            new_doc = fitz.open()

            for page in doc:
                rect = page.rect
                if self.auto:
                    clip_rect = self._auto_detect_content(page)
                else:
                    clip_rect = fitz.Rect(
                        rect.x0 + self.left,
                        rect.y0 + self.top,
                        rect.x1 - self.right,
                        rect.y1 - self.bottom,
                    )

                page.set_cropbox(clip_rect)
                new_doc.insert_pdf(doc, from_page=page.number, to_page=page.number)

            self.output_path.parent.mkdir(parents=True, exist_ok=True)
            new_doc.save(str(self.output_path))
            new_doc.close()
            doc.close()

            logger.info(f"页面裁剪完成: {self.output_path}")

        except Exception as e:  # noqa: BLE001
            logger.error(f"页面裁剪失败: {e}")
            return False
        else:
            return True

    def _auto_detect_content(self, page: fitz.Page) -> fitz.Rect:
        """自动检测内容边界."""
        rect = page.rect
        text_boxes = page.get_text("boxes")
        if not text_boxes:
            return rect

        min_x = rect.x1
        min_y = rect.y1
        max_x = rect.x0
        max_y = rect.y0

        for box in text_boxes:
            min_x = min(min_x, box[0])
            min_y = min(min_y, box[1])
            max_x = max(max_x, box[2])
            max_y = max(max_y, box[3])

        min_x = max(rect.x0, min_x - self.margin)
        min_y = max(rect.y0, min_y - self.margin)
        max_x = min(rect.x1, max_x + self.margin)
        max_y = min(rect.y1, max_y + self.margin)

        return fitz.Rect(min_x, min_y, max_x, max_y)


class PdfCropSkill(BaseSkill):
    """PDF页面裁剪技能."""

    name = "pdfcrop"
    description = "裁剪PDF页面边缘空白"

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "input_paths",
            type=str,
            nargs="*",
            default=None,
            help="输入PDF文件路径(可选, 默认搜索当前目录)",
        )
        parser.add_argument(
            "-o",
            "--output",
            type=str,
            default=None,
            help="输出文件路径(单文件模式)",
        )
        parser.add_argument(
            "-a",
            "--auto",
            action="store_true",
            help="自动检测内容边界并裁剪",
        )
        parser.add_argument(
            "-m",
            "--margin",
            type=int,
            default=conf.DEFAULT_MARGIN,
            help=f"自动裁剪时的边距(默认: {conf.DEFAULT_MARGIN})",
        )
        parser.add_argument("-l", "--left", type=int, default=0, help="左边裁剪距离")
        parser.add_argument("-r", "--right", type=int, default=0, help="右边裁剪距离")
        parser.add_argument("-t", "--top", type=int, default=0, help="顶部裁剪距离")
        parser.add_argument("-b", "--bottom", type=int, default=0, help="底部裁剪距离")
        PdfSkillEnhancer.add_arguments(parser)

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建PDF裁剪调度器."""
        PdfSkillEnhancer.set_quiet_mode(quiet=args.quiet)
        input_paths = PdfSkillEnhancer.resolve_input_paths(
            args.input_paths,
            recursive=args.recursive,
        )
        PdfSkillEnhancer.init_progress(len(input_paths))

        commands = []

        if len(input_paths) == 1 and args.output:
            output_path = Path(args.output)
            if not PdfSkillEnhancer.should_skip(
                output_path,
                skip_existing=args.skip_existing,
            ):
                commands.append(
                    PdfCropCommand(
                        input_path=input_paths[0],
                        output_path=output_path,
                        left=args.left,
                        right=args.right,
                        top=args.top,
                        bottom=args.bottom,
                        auto=args.auto,
                        margin=args.margin,
                    ),
                )
                PdfSkillEnhancer.log_progress(input_paths[0], output_path)
        else:
            for input_path in input_paths:
                output_path = PdfSkillEnhancer.resolve_output_path(
                    input_path,
                    args.output_dir,
                    conf.OUTPUT_SUFFIX,
                )
                if not PdfSkillEnhancer.should_skip(
                    output_path,
                    skip_existing=args.skip_existing,
                ):
                    commands.append(
                        PdfCropCommand(
                            input_path=input_path,
                            output_path=output_path,
                            left=args.left,
                            right=args.right,
                            top=args.top,
                            bottom=args.bottom,
                            auto=args.auto,
                            margin=args.margin,
                        ),
                    )
                    PdfSkillEnhancer.log_progress(input_path, output_path)

        if not commands:
            PdfSkillEnhancer.log_info("没有需要处理的文件")
            return CommandScheduler(commands=[])

        PdfSkillEnhancer.log_info(f"开始裁剪 {len(commands)} 个PDF文件")
        if args.auto:
            PdfSkillEnhancer.log_info(f"  - 自动模式, 边距: {args.margin}")
        else:
            PdfSkillEnhancer.log_info(
                f"  - 手动模式: 左={args.left}, 右={args.right}, 上={args.top}, 下={args.bottom}",
            )

        return CommandScheduler(commands=commands)


def main() -> None:
    """PDF页面裁剪主函数."""
    PdfCropSkill().run_cli()
