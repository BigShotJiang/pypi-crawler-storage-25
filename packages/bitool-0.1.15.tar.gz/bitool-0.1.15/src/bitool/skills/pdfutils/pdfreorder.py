"""PDF页面重排序脚本.

调整PDF文件的页面顺序、删除指定页面或插入空白页.
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass, field
from pathlib import Path

from bitool.cmd import CommandScheduler
from bitool.cmd._base import BaseCommand
from bitool.core import JsonConfig, logger
from bitool.skills._base import BaseSkill

try:
    import fitz

    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False


class PdfReorderConfig(JsonConfig):
    """PDF重排序配置类."""

    OUTPUT_SUFFIX: str = ".reordered.pdf"


conf = PdfReorderConfig()


@dataclass
class PdfReorderCommand(BaseCommand):
    """PDF页面重排序命令."""

    name = "pdf_reorder"
    description = "重排序PDF页面"

    input_path: Path = field(default_factory=Path)
    output_path: Path = field(default_factory=Path)
    page_order: str = ""
    delete_pages: str = ""
    insert_pages: str = ""

    def run(self) -> bool:
        """执行PDF页面重排序."""
        if not HAS_PYMUPDF:
            logger.error("未安装PyMuPDF库, 请安装: pip install PyMuPDF")
            return False

        if not self.input_path.exists():
            logger.error(f"文件不存在: {self.input_path}")
            return False

        try:
            doc = fitz.open(str(self.input_path))
            total_pages = doc.page_count

            if self.page_order:
                order = self._parse_page_range(self.page_order, total_pages)
                if len(order) != total_pages:
                    logger.error("页面顺序列表长度与总页数不匹配")
                    doc.close()
                    return False
                new_doc = fitz.open()
                for idx in order:
                    new_doc.insert_pdf(doc, from_page=idx, to_page=idx)
            else:
                new_doc = fitz.open()
                new_doc.insert_pdf(doc)

            if self.delete_pages:
                delete_indices = sorted(
                    self._parse_page_range(self.delete_pages, total_pages),
                    reverse=True,
                )
                for idx in delete_indices:
                    if idx < len(new_doc):
                        new_doc.delete_page(idx)

            if self.insert_pages:
                insert_specs = self.insert_pages.split(",")
                for spec in insert_specs:
                    parts = spec.split(":")
                    if len(parts) == 2:
                        pos = int(parts[0]) - 1
                        count = int(parts[1])
                        for _ in range(count):
                            new_doc.new_page(pno=pos)
                            pos += 1

            self.output_path.parent.mkdir(parents=True, exist_ok=True)
            new_doc.save(str(self.output_path))
            new_doc.close()
            doc.close()

            logger.info(f"页面重排序完成: {self.output_path}")

        except Exception as e:  # noqa: BLE001
            logger.error(f"页面重排序失败: {e}")
            return False
        else:
            return True

    def _parse_page_range(self, range_str: str, total_pages: int) -> list[int]:
        """解析页面范围字符串,返回0-indexed的页面索引列表."""
        pages = []
        for part in range_str.split(","):
            part = part.strip()
            if not part:
                continue
            if "-" in part:
                start_end = part.split("-")
                start = int(start_end[0]) if start_end[0] else 1
                end = int(start_end[1]) if start_end[1] else total_pages
                start = max(1, start)
                end = min(total_pages, end)
                pages.extend(range(start - 1, end))
            else:
                page = int(part)
                if 1 <= page <= total_pages:
                    pages.append(page - 1)
        return sorted(set(pages))


class PdfReorderSkill(BaseSkill):
    """PDF页面重排序技能."""

    name = "pdfreorder"
    description = "重排序PDF页面"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "input_path",
            type=str,
            nargs="?",
            default=None,
            help="输入PDF文件路径(可选, 默认搜索当前目录)",
        )
        parser.add_argument(
            "-o",
            "--output",
            type=str,
            default=None,
            help="输出文件路径",
        )
        parser.add_argument(
            "-r",
            "--reorder",
            type=str,
            default="",
            help="新的页面顺序,如: 2,1,3-5,7",
        )
        parser.add_argument(
            "-d",
            "--delete",
            type=str,
            default="",
            help="要删除的页面,如: 1,3-5",
        )
        parser.add_argument(
            "-i",
            "--insert",
            type=str,
            default="",
            help="插入空白页,格式: 位置:数量,如: 1:2 表示在第1页前插入2页",
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建PDF重排序调度器."""
        input_path = self._resolve_input_path(args.input_path)
        output_path = self._resolve_output_path(args.output, input_path)

        logger.info(f"开始页面重排序: {input_path}")
        if args.reorder:
            logger.info(f"  - 重排序: {args.reorder}")
        if args.delete:
            logger.info(f"  - 删除页面: {args.delete}")
        if args.insert:
            logger.info(f"  - 插入空白页: {args.insert}")

        return CommandScheduler(
            commands=[
                PdfReorderCommand(
                    input_path=input_path,
                    output_path=output_path,
                    page_order=args.reorder,
                    delete_pages=args.delete,
                    insert_pages=args.insert,
                ),
            ],
        )

    def _resolve_input_path(self, input_path: str | None) -> Path:
        """解析输入路径."""
        if input_path:
            path = Path(input_path)
        else:
            current_dir = Path.cwd()
            pdf_files = list(current_dir.glob("*.pdf")) + list(
                current_dir.glob("*.PDF"),
            )

            if not pdf_files:
                logger.error(f"在当前目录 {current_dir} 中未找到PDF文件")
                sys.exit(1)

            if len(pdf_files) > 1:
                logger.info(f"找到多个PDF文件, 将处理第一个: {pdf_files[0]}")

            path = pdf_files[0]

        if not path.exists():
            logger.error(f"未找到输入文件: {path}")
            sys.exit(1)

        if path.suffix.lower() != ".pdf":
            logger.error(f"不支持的文件格式: {path.suffix}, 请选择PDF文件")
            sys.exit(1)

        return path

    def _resolve_output_path(self, output: str | None, input_path: Path) -> Path:
        """解析输出路径."""
        if output:
            return Path(output)
        return input_path.with_suffix(conf.OUTPUT_SUFFIX)


def main() -> None:
    """PDF页面重排序主函数."""
    PdfReorderSkill().run_cli()
