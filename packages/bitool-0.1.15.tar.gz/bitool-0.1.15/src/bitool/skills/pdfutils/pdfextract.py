"""PDF内容提取脚本.

提取PDF文件中的文本内容或图片.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from bitool.cmd import CommandScheduler
from bitool.cmd._base import BaseCommand
from bitool.core import JsonConfig, logger
from bitool.skills._base import BaseSkill

try:
    import fitz

    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False


class PdfExtractConfig(JsonConfig):
    """PDF提取配置类."""

    OUTPUT_TEXT_SUFFIX: str = ".txt"
    OUTPUT_IMAGES_DIR: str = "images"


conf = PdfExtractConfig()


class PdfExtractTextCommand(BaseCommand):
    """提取PDF文本命令."""

    name = "pdf_extract_text"
    description = "提取PDF文本内容"

    input_path: Path = Path()
    output_path: Path = Path()

    def run(self) -> bool:
        """执行PDF文本提取."""
        if not HAS_PYMUPDF:
            logger.error("未安装PyMuPDF库, 请安装: pip install PyMuPDF")
            return False

        if not self.input_path.exists():
            logger.error(f"文件不存在: {self.input_path}")
            return False

        try:
            doc = fitz.open(str(self.input_path))
            text = ""

            for page in doc:
                text += page.get_text()
                text += "\n\n"

            doc.close()

            self.output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.output_path, "w", encoding="utf-8") as f:
                f.write(text)

            logger.info(f"文本提取完成: {self.output_path}")
            logger.info(f"提取字符数: {len(text)}")

        except Exception as e:  # noqa: BLE001
            logger.error(f"提取文本失败: {e}")
            return False
        else:
            return True


class PdfExtractImagesCommand(BaseCommand):
    """提取PDF图片命令."""

    name = "pdf_extract_images"
    description = "提取PDF中的图片"

    input_path: Path = Path()
    output_dir: Path = Path()

    def run(self) -> bool:
        """执行PDF图片提取."""
        if not HAS_PYMUPDF:
            logger.error("未安装PyMuPDF库, 请安装: pip install PyMuPDF")
            return False

        if not self.input_path.exists():
            logger.error(f"文件不存在: {self.input_path}")
            return False

        try:
            doc = fitz.open(str(self.input_path))
            image_count = 0

            self.output_dir.mkdir(parents=True, exist_ok=True)

            for page_num, page in enumerate(doc):
                images = page.get_images(full=True)
                for img_idx, img in enumerate(images):
                    xref = img[0]
                    base_image = doc.extract_image(xref)
                    image_data = base_image["image"]
                    image_ext = base_image["ext"]

                    image_path = (
                        self.output_dir
                        / f"page_{page_num + 1}_img_{img_idx + 1}.{image_ext}"
                    )
                    with open(image_path, "wb") as f:
                        f.write(image_data)
                    image_count += 1

            doc.close()

            logger.info(f"图片提取完成: {self.output_dir}")
            logger.info(f"提取图片数: {image_count}")

        except Exception as e:  # noqa: BLE001
            logger.error(f"提取图片失败: {e}")
            return False
        else:
            return True


class PdfExtractSkill(BaseSkill):
    """PDF内容提取技能."""

    name = "pdfextract"
    description = "提取PDF中的文本或图片"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "input_path",
            type=str,
            nargs="?",
            default=None,
            help="输入PDF文件路径(可选, 默认搜索当前目录)",
        )
        parser.add_argument("-t", "--text", action="store_true", help="提取文本内容")
        parser.add_argument("-i", "--images", action="store_true", help="提取图片")
        parser.add_argument(
            "-o",
            "--output",
            type=str,
            default=None,
            help="输出路径(文本模式为文件, 图片模式为目录)",
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建PDF提取调度器."""
        input_path = self._resolve_input_path(args.input_path)

        if not args.text and not args.images:
            args.text = True
            args.images = True

        commands = []

        if args.text:
            if args.output:
                text_output = Path(args.output)
            else:
                text_output = input_path.with_suffix(conf.OUTPUT_TEXT_SUFFIX)
            commands.append(
                PdfExtractTextCommand(input_path=input_path, output_path=text_output),
            )

        if args.images:
            if args.output and not args.text:
                img_output = Path(args.output)
            else:
                img_output = input_path.parent / conf.OUTPUT_IMAGES_DIR
            commands.append(
                PdfExtractImagesCommand(input_path=input_path, output_dir=img_output),
            )

        logger.info(f"开始提取PDF内容: {input_path}")
        if args.text:
            logger.info(
                f"  - 提取文本: {text_output if 'text_output' in vars() else input_path.with_suffix(conf.OUTPUT_TEXT_SUFFIX)}",
            )
        if args.images:
            logger.info(
                f"  - 提取图片: {img_output if 'img_output' in vars() else input_path.parent / conf.OUTPUT_IMAGES_DIR}",
            )

        return CommandScheduler(commands=commands)

    def _resolve_input_path(self, input_path: str | None) -> Path:
        """解析输入路径."""
        if input_path:
            path = Path(input_path)
        else:
            current_dir = Path.cwd()
            pdf_files = list(current_dir.glob("*.pdf")) + list(
                current_dir.glob("*.PDF"),
            )

            if not pdf_files:
                logger.error(f"在当前目录 {current_dir} 中未找到PDF文件")
                sys.exit(1)

            if len(pdf_files) > 1:
                logger.info(f"找到多个PDF文件, 将处理第一个: {pdf_files[0]}")

            path = pdf_files[0]

        if not path.exists():
            logger.error(f"未找到输入文件: {path}")
            sys.exit(1)

        if path.suffix.lower() != ".pdf":
            logger.error(f"不支持的文件格式: {path.suffix}, 请选择PDF文件")
            sys.exit(1)

        return path


def main() -> None:
    """PDF内容提取主函数."""
    PdfExtractSkill().run_cli()
