"""PDF压缩脚本.

对PDF文件进行压缩以减小文件大小,支持批量处理和自定义压缩质量.

增强功能:
- 输出目录支持 (--output-dir)
- 递归搜索子目录 (--recursive)
- 静默模式 (--quiet)
- 跳过已存在文件 (--skip-existing)
- 压缩级别支持
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path
from typing import ClassVar

from bitool.cmd import CommandScheduler
from bitool.cmd._base import BaseCommand
from bitool.core import logger
from bitool.skills._base import BaseSkill
from bitool.skills.pdf_utils import PdfSkillConfig, PdfSkillEnhancer

try:
    import fitz

    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False


class PdfCompressConfig(PdfSkillConfig):
    """PDF压缩配置类."""

    DEFAULT_QUALITY: int = 75
    QUALITY_RANGE: tuple[int, int] = (1, 100)
    OUTPUT_SUFFIX: str = ".compressed.pdf"
    QUALITY_LEVELS: ClassVar[dict[str, int]] = {
        "low": 30,
        "medium": 50,
        "high": 75,
        "best": 95,
    }


conf = PdfCompressConfig()


@dataclass
class PdfCompressCommand(BaseCommand):
    """PDF压缩命令."""

    name = "pdf_compress"
    description = "压缩PDF文件"

    input_path: Path = field(default_factory=Path)
    output_path: Path = field(default_factory=Path)
    quality: int = 75

    def run(self) -> bool:
        """执行PDF压缩."""
        if not HAS_PYMUPDF:
            logger.error("未安装PyMuPDF库, 请安装: pip install PyMuPDF")
            return False

        if not self.input_path.exists():
            logger.error(f"文件不存在: {self.input_path}")
            return False

        try:
            doc = fitz.open(str(self.input_path))
            original_size = self.input_path.stat().st_size

            self.output_path.parent.mkdir(parents=True, exist_ok=True)

            # 使用完整的压缩选项
            doc.save(
                str(self.output_path),
                garbage=4,  # 删除未使用的对象
                deflate=True,  # 压缩流
                clean=True,  # 清理内容
            )
            doc.close()

            new_size = self.output_path.stat().st_size
            ratio = (1 - new_size / original_size) * 100

            if ratio > 0:
                logger.info(f"压缩完成: {self.output_path} (缩小 {ratio:.1f}%)")
            else:
                logger.info(f"压缩完成: {self.output_path} (无法进一步压缩)")

        except Exception as e:  # noqa: BLE001
            logger.error(f"压缩失败: {e}")
            return False
        else:
            return True


class PdfCompressSkill(BaseSkill):
    """PDF压缩技能."""

    name = "pdfcompress"
    description = "压缩PDF文件以减小文件大小"

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "input_paths",
            type=str,
            nargs="*",
            default=None,
            help="输入PDF文件路径(可选, 默认搜索当前目录)",
        )
        parser.add_argument(
            "-o",
            "--output",
            type=str,
            default=None,
            help="输出文件路径(单文件模式)",
        )
        quality_group = parser.add_mutually_exclusive_group()
        quality_group.add_argument(
            "-q",
            "--quality",
            type=int,
            default=conf.DEFAULT_QUALITY,
            help=f"压缩质量 (1-100, 默认: {conf.DEFAULT_QUALITY})",
        )
        quality_group.add_argument(
            "-l",
            "--level",
            type=str,
            choices=["low", "medium", "high", "best"],
            default=None,
            help="压缩级别 (low/medium/high/best)",
        )
        parser.add_argument(
            "-s",
            "--suffix",
            type=str,
            default=conf.OUTPUT_SUFFIX,
            help=f"批量模式输出后缀 (默认: {conf.OUTPUT_SUFFIX})",
        )
        PdfSkillEnhancer.add_arguments(parser)

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建PDF压缩调度器."""
        PdfSkillEnhancer.set_quiet_mode(quiet=args.quiet)
        input_paths = PdfSkillEnhancer.resolve_input_paths(
            args.input_paths,
            recursive=args.recursive,
        )
        PdfSkillEnhancer.init_progress(len(input_paths))

        quality = self._resolve_quality(args.quality, args.level)

        commands = []

        if len(input_paths) == 1 and args.output:
            output_path = Path(args.output)
            if not PdfSkillEnhancer.should_skip(
                output_path,
                skip_existing=args.skip_existing,
            ):
                commands.append(
                    PdfCompressCommand(
                        input_path=input_paths[0],
                        output_path=output_path,
                        quality=quality,
                    ),
                )
                PdfSkillEnhancer.log_progress(input_paths[0], output_path)
        else:
            for input_path in input_paths:
                output_path = PdfSkillEnhancer.resolve_output_path(
                    input_path,
                    args.output_dir,
                    args.suffix,
                )
                if not PdfSkillEnhancer.should_skip(
                    output_path,
                    skip_existing=args.skip_existing,
                ):
                    commands.append(
                        PdfCompressCommand(
                            input_path=input_path,
                            output_path=output_path,
                            quality=quality,
                        ),
                    )
                    PdfSkillEnhancer.log_progress(input_path, output_path)

        if not commands:
            PdfSkillEnhancer.log_info("没有需要处理的文件")
            return CommandScheduler(commands=[])

        PdfSkillEnhancer.log_info(f"开始压缩 {len(commands)} 个PDF文件")
        if args.level:
            PdfSkillEnhancer.log_info(f"  - 使用级别: {args.level} (质量={quality})")
        else:
            PdfSkillEnhancer.log_info(f"  - 使用质量: {quality}")

        return CommandScheduler(commands=commands)

    def _resolve_quality(self, quality: int, level: str | None) -> int:
        """解析质量参数."""
        if level:
            return conf.QUALITY_LEVELS[level]
        if not conf.QUALITY_RANGE[0] <= quality <= conf.QUALITY_RANGE[1]:
            logger.error(
                f"压缩质量必须在 {conf.QUALITY_RANGE[0]} 到 {conf.QUALITY_RANGE[1]} 之间",
            )
            raise ValueError("Invalid quality")
        return quality


def main() -> None:
    """PDF压缩主函数."""
    PdfCompressSkill().run_cli()
