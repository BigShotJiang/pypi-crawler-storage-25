"""PDF附件管理脚本.

向PDF添加附件或提取已有附件.
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass, field
from pathlib import Path

from bitool.cmd import CommandScheduler
from bitool.cmd._base import BaseCommand
from bitool.core import JsonConfig, logger
from bitool.skills._base import BaseSkill

try:
    import fitz

    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False


class PdfAttachConfig(JsonConfig):
    """PDF附件配置类."""

    OUTPUT_SUFFIX: str = ".attached.pdf"


conf = PdfAttachConfig()


@dataclass
class PdfAttachCommand(BaseCommand):
    """PDF附件管理命令."""

    name = "pdf_attach"
    description = "管理PDF附件"

    input_path: Path = field(default_factory=Path)
    output_path: Path = field(default_factory=Path)
    action: str = ""
    attach_files: list[str] = field(default_factory=list)
    extract_dir: str = ""

    def run(self) -> bool:
        """执行PDF附件操作."""
        if not HAS_PYMUPDF:
            logger.error("未安装PyMuPDF库, 请安装: pip install PyMuPDF")
            return False

        if not self.input_path.exists():
            logger.error(f"文件不存在: {self.input_path}")
            return False

        try:
            if self.action == "add":
                return self._add_attachments()
            elif self.action == "extract":
                return self._extract_attachments()
            else:
                logger.error(f"未知操作: {self.action}")
                return False

        except Exception as e:  # noqa: BLE001
            logger.error(f"附件操作失败: {e}")
            return False

    def _add_attachments(self) -> bool:
        """添加附件到PDF."""
        doc = fitz.open(str(self.input_path))

        files = self.attach_files or []
        for file_path in files:
            attach_path = Path(file_path)
            if not attach_path.exists():
                logger.warning(f"附件文件不存在, 跳过: {attach_path}")
                continue

            with open(attach_path, "rb") as f:
                content = f.read()

            doc.embfile_add(
                name=attach_path.name,
                filealias=attach_path.name,
                content=content,
                filename=attach_path.name,
            )
            logger.info(f"添加附件: {attach_path.name}")

        self.output_path.parent.mkdir(parents=True, exist_ok=True)
        doc.save(str(self.output_path))
        doc.close()

        logger.info(f"附件添加完成: {self.output_path}")
        return True

    def _extract_attachments(self) -> bool:
        """从PDF提取附件."""
        doc = fitz.open(str(self.input_path))
        attachments = doc.embfile_names()

        if not attachments:
            logger.info("PDF中没有附件")
            doc.close()
            return True

        extract_path = Path(self.extract_dir)
        extract_path.mkdir(parents=True, exist_ok=True)

        for name in attachments:
            content = doc.embfile_get(name)
            if content:
                output_file = extract_path / name
                with open(output_file, "wb") as f:
                    f.write(content)
                logger.info(f"提取附件: {name}")

        doc.close()
        logger.info(f"附件提取完成, 共提取 {len(attachments)} 个文件")
        return True


class PdfAttachSkill(BaseSkill):
    """PDF附件管理技能."""

    name = "pdfattach"
    description = "管理PDF附件"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "action",
            type=str,
            choices=["add", "extract"],
            help="操作类型: add(添加附件), extract(提取附件)",
        )
        parser.add_argument("input_path", type=str, help="输入PDF文件路径")
        parser.add_argument(
            "-o",
            "--output",
            type=str,
            default=None,
            help="输出文件路径(添加附件时)",
        )
        parser.add_argument(
            "-f",
            "--files",
            type=str,
            nargs="+",
            default=[],
            help="要添加的附件文件列表",
        )
        parser.add_argument(
            "-d",
            "--dir",
            type=str,
            default="attachments",
            help="提取附件的目标目录(默认: attachments)",
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建PDF附件调度器."""
        input_path = Path(args.input_path)

        if not input_path.exists():
            logger.error(f"未找到文件: {input_path}")
            sys.exit(1)

        if input_path.suffix.lower() != ".pdf":
            logger.error(f"不支持的文件格式: {input_path.suffix}")
            sys.exit(1)

        if args.action == "add":
            if not args.files:
                logger.error("添加附件时需要指定文件列表")
                sys.exit(1)

            if args.output:
                output_path = Path(args.output)
            else:
                output_path = input_path.with_suffix(conf.OUTPUT_SUFFIX)

            logger.info(f"添加附件到PDF: {input_path}")
            for f in args.files:
                logger.info(f"  - {f}")

            return CommandScheduler(
                commands=[
                    PdfAttachCommand(
                        input_path=input_path,
                        output_path=output_path,
                        action="add",
                        attach_files=args.files,
                    ),
                ],
            )

        elif args.action == "extract":
            logger.info(f"从PDF提取附件: {input_path}")
            logger.info(f"  - 目标目录: {args.dir}")

            return CommandScheduler(
                commands=[
                    PdfAttachCommand(
                        input_path=input_path,
                        output_path=Path(),
                        action="extract",
                        extract_dir=args.dir,
                    ),
                ],
            )

        return CommandScheduler(commands=[])


def main() -> None:
    """PDF附件管理主函数."""
    PdfAttachSkill().run_cli()
