"""移除文件日期前缀并替换为创建/修改时间.

自动检测文件名的日期前缀,
并根据文件的实际创建或修改时间重命名文件.
"""

from __future__ import annotations

import argparse
import os
import re
import time
import uuid
from dataclasses import dataclass
from functools import cached_property, lru_cache
from pathlib import Path
from re import Pattern
from typing import Final

from bitool.cmd import CommandScheduler, RunCommand
from bitool.core import logger
from bitool.skills._base import BaseSkill


class FileDateConfig:
    """filedate 工具配置类."""

    NAME: str = "filedate"  # 工具名称
    DETECT_SEPARATORS: str = "-_#.~"  # 日期前缀分隔符, 用于检测日期前缀是否存在
    SEP: str = "_"  # 日期前缀分隔符
    MAX_RETRY: int = 100  # 最大重试次数


conf = FileDateConfig()


# 日期检测模式
DATE_PATTERN: Final[Pattern[str]] = re.compile(
    r"(20|19)\d{2}[-_#.~]?((0[1-9])|(1[012]))[-_#.~]?((0[1-9])|([12]\d)|(3[01]))",
)


@dataclass(frozen=True)
class FileDateRenamer:
    """单个文件重命名器."""

    path: Path

    def rename(self) -> None:
        """将带日期前缀的文件重命名为创建/修改时间."""
        if self.is_system_reserved:
            logger.info(f"文件名以点开头, 不重命名: {self.path.name}")
            return

        try:
            self.path.rename(self.dest_filepath)
        except (OSError, PermissionError):
            logger.exception("重命名失败: %s -> %s", self.path, self.dest_filepath)
            raise
        else:
            logger.info("重命名: %s -> %s", self.path, self.dest_filepath)

    @cached_property
    def dest_filepath(self) -> Path:
        """获取重命名后的文件路径."""
        if self.is_system_reserved:
            return self.path

        filepath = self.path.with_name(self.dest_filename)
        if filepath == self.path:
            logger.warning(f"文件名已符合要求, 不重命名: `{self.path.name}`")
            return self.path

        sequence = 1
        while filepath.exists() and sequence <= conf.MAX_RETRY:
            logger.warning(f"{filepath} 已存在, 添加唯一后缀.")
            filepath = filepath.with_name(
                f"{self.dest_filestem}({sequence}){self.path.suffix}",
            )
            sequence += 1

        if filepath.exists() and sequence > conf.MAX_RETRY:
            logger.error("已达到最大重试次数, 使用uuid作为后缀.")
            filepath = filepath.with_name(
                f"{self.dest_filestem}_{uuid.uuid4().hex[:8]}{self.path.suffix}",
            )

        return filepath

    @cached_property
    def dest_filename(self) -> str:
        """获取重命名后的文件名."""
        if self.is_system_reserved:
            return self.path.name

        return (
            f"{self.time_mark}{conf.SEP}{self.filestem_without_date}{self.path.suffix}"
        )

    @cached_property
    def dest_filestem(self) -> str:
        """获取重命名后的文件名主干."""
        suffix = self.path.suffix

        return (
            self.dest_filename[: -len(suffix)]
            if suffix and self.dest_filename.endswith(suffix)
            else self.dest_filename
        )

    @cached_property
    def is_system_reserved(self) -> bool:
        """判断文件是否为系统保留文件(以点开头)."""
        return self.path.name.startswith(".")

    @cached_property
    def filestem_without_date(self) -> str:
        """获取去除日期前缀的文件名主干."""

        @lru_cache(maxsize=1024)
        def remove_date_prefix(filestem: str) -> str:
            """从文件名中移除日期前缀.

            Returns
            -------
                str: 移除了日期前缀的文件名.
            """
            if (
                filestem.startswith(".")
                and not filestem[1:].isdigit()
                and len(filestem) > 1
            ) and not re.search(DATE_PATTERN, filestem):
                return ""

            match = re.search(DATE_PATTERN, filestem)
            if not match:
                logger.debug("未检测到日期前缀: %s", filestem)
                return filestem
            b, e = match.start(), match.end()
            if b >= 1 and filestem[b - 1] in conf.DETECT_SEPARATORS:
                filestem = filestem[: b - 1] + filestem[e:]
            elif e < len(filestem) and filestem[e] in conf.DETECT_SEPARATORS:
                filestem = filestem[:b] + filestem[e + 1 :]
            else:
                # 日期前后都没有分隔符，直接移除日期部分
                filestem = filestem[:b] + filestem[e:]
            return remove_date_prefix(filestem)

        return remove_date_prefix(self.path.stem)

    @cached_property
    def filestat(self) -> os.stat_result:
        """获取文件 stat 信息."""
        return self.path.stat()

    @cached_property
    def modified_time(self) -> float:
        """获取修改时间."""
        return self.filestat.st_mtime

    @cached_property
    def created_time(self) -> float:
        """获取创建时间."""
        return self.filestat.st_ctime

    @cached_property
    def time_mark(self) -> str:
        """获取时间标记."""
        return time.strftime(
            "%Y%m%d",
            time.localtime(max((self.modified_time, self.created_time))),
        )


class FileDateSkill(BaseSkill):
    """文件日期重命名技能."""

    name = "filedate"
    description = "移除文件日期前缀并替换为创建/修改时间"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument("targets", type=str, nargs="+", help="输入文件列表")

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建文件日期处理调度器."""
        entries = [Path.cwd() / p for p in args.targets]

        return CommandScheduler(
            commands=[
                RunCommand(
                    name=f"rename_{p}",
                    description=f"重命名文件 {p}",
                    cmd=FileDateRenamer(p).rename,
                )
                for p in entries
            ],
        )


def main() -> None:
    """主函数入口."""
    FileDateSkill().run_cli()
