"""测试 CommandScheduler 模块."""

from __future__ import annotations

from dataclasses import dataclass
from unittest.mock import MagicMock

import pytest

from bitool.cmd._base import BaseCommand
from bitool.cmd._scheduler import (
    CommandResult,
    CommandScheduler,
    ExecutionMode,
    SchedulerMetrics,
)


@dataclass
class MockCommand(BaseCommand):
    """模拟命令用于测试."""

    name: str = "mock_cmd"
    should_succeed: bool = True
    dependencies: list[str] | None = None
    raise_exception: bool = False

    def __post_init__(self) -> None:
        self.dependencies = self.dependencies or []

    def run(self) -> bool:
        """运行命令."""
        if self.raise_exception:
            msg = "命令执行异常"
            raise RuntimeError(msg)
        return self.should_succeed


class TestCommandResult:
    """测试 CommandResult 类."""

    def test_default_values(self) -> None:
        """测试默认值."""
        result = CommandResult(name="test", success=True)
        assert result.name == "test"
        assert result.success is True
        assert result.duration == 0.0
        assert result.error is None
        assert result.output is None
        assert result.retry_count == 0

    def test_custom_values(self) -> None:
        """测试自定义值."""
        result = CommandResult(
            name="test",
            success=False,
            duration=1.5,
            error="错误信息",
            output="输出",
            retry_count=2,
        )
        assert result.name == "test"
        assert result.success is False
        assert result.duration == 1.5
        assert result.error == "错误信息"
        assert result.output == "输出"
        assert result.retry_count == 2


class TestSchedulerMetrics:
    """测试 SchedulerMetrics 类."""

    def test_default_values(self) -> None:
        """测试默认值."""
        metrics = SchedulerMetrics()
        assert metrics.total_commands == 0
        assert metrics.successful == 0
        assert metrics.failed == 0
        assert metrics.skipped == 0
        assert metrics.total_duration == 0.0
        assert metrics.mode_used == ""
        assert metrics.command_results == []


class TestCommandScheduler:
    """测试 CommandScheduler 类."""

    def test_init_empty(self) -> None:
        """测试空初始化."""
        scheduler = CommandScheduler()
        assert scheduler.commands == []
        assert scheduler.max_workers is None
        assert scheduler.timeout is None
        assert scheduler.max_retries == 0
        assert scheduler.retry_delay == 1.0
        assert scheduler.context == {}
        assert scheduler.progress_callback is None

    def test_init_with_commands(self) -> None:
        """测试带命令初始化."""
        commands: list[BaseCommand] = [MockCommand("cmd1"), MockCommand("cmd2")]
        scheduler = CommandScheduler(commands=commands)
        assert len(scheduler.commands) == 2

    def test_init_with_custom_params(self) -> None:
        """测试自定义参数初始化."""
        callback = MagicMock()
        scheduler = CommandScheduler(
            max_workers=4,
            timeout=30.0,
            max_retries=3,
            retry_delay=2.0,
            context={"key": "value"},
            progress_callback=callback,
        )
        assert scheduler.max_workers == 4
        assert scheduler.timeout == 30.0
        assert scheduler.max_retries == 3
        assert scheduler.retry_delay == 2.0
        assert scheduler.context == {"key": "value"}
        assert scheduler.progress_callback is callback

    def test_run_empty_commands(self) -> None:
        """测试空命令列表."""
        scheduler = CommandScheduler()
        result = scheduler.run()
        assert result == {}

    def test_run_sequential_single_command(self) -> None:
        """测试顺序执行单个命令."""
        cmd = MockCommand("cmd1", should_succeed=True)
        scheduler = CommandScheduler(commands=[cmd])
        result = scheduler.run_sequential()
        assert result == {"cmd1": True}

    def test_run_sequential_multiple_commands(self) -> None:
        """测试顺序执行多个命令."""
        commands: list[BaseCommand] = [
            MockCommand("cmd1", should_succeed=True),
            MockCommand("cmd2", should_succeed=True),
            MockCommand("cmd3", should_succeed=False),
        ]
        scheduler = CommandScheduler(commands=commands)
        result = scheduler.run_sequential()
        assert result == {"cmd1": True, "cmd2": True, "cmd3": False}

    def test_run_sequential_stop_on_failure(self) -> None:
        """测试顺序执行失败时停止."""
        commands: list[BaseCommand] = [
            MockCommand("cmd1", should_succeed=True),
            MockCommand("cmd2", should_succeed=False),
            MockCommand("cmd3", should_succeed=True),
        ]
        scheduler = CommandScheduler(commands=commands)
        result = scheduler.run_sequential(stop_on_failure=True)
        assert result == {"cmd1": True, "cmd2": False}
        assert "cmd3" not in result

    def test_run_parallel(self) -> None:
        """测试并行执行."""
        commands: list[BaseCommand] = [
            MockCommand("cmd1", should_succeed=True),
            MockCommand("cmd2", should_succeed=True),
            MockCommand("cmd3", should_succeed=True),
        ]
        scheduler = CommandScheduler(commands=commands)
        result = scheduler.run_parallel()
        assert all(result.values())

    def test_run_parallel_empty(self) -> None:
        """测试并行执行空列表."""
        scheduler = CommandScheduler()
        result = scheduler.run_parallel()
        assert result == {}

    def test_run_dag_no_dependencies(self) -> None:
        """测试 DAG 执行无依赖."""
        commands: list[BaseCommand] = [
            MockCommand("cmd1", should_succeed=True),
            MockCommand("cmd2", should_succeed=True),
        ]
        scheduler = CommandScheduler(commands=commands)
        result = scheduler.run_dag()
        assert result == {"cmd1": True, "cmd2": True}

    def test_run_dag_with_dependencies(self) -> None:
        """测试 DAG 执行有依赖."""
        cmd1 = MockCommand("cmd1", should_succeed=True)
        cmd2 = MockCommand("cmd2", should_succeed=True, dependencies=["cmd1"])
        scheduler = CommandScheduler(commands=[cmd1, cmd2])
        result = scheduler.run_dag()
        assert result == {"cmd1": True, "cmd2": True}

    def test_run_dag_dependency_failed(self) -> None:
        """测试 DAG 执行依赖失败."""
        cmd1 = MockCommand("cmd1", should_succeed=False)
        cmd2 = MockCommand("cmd2", should_succeed=True, dependencies=["cmd1"])
        scheduler = CommandScheduler(commands=[cmd1, cmd2])
        result = scheduler.run_dag()
        assert result == {"cmd1": False, "cmd2": False}

    def test_run_dag_circular_dependency(self) -> None:
        """测试 DAG 循环依赖."""
        cmd1 = MockCommand("cmd1", should_succeed=True, dependencies=["cmd2"])
        cmd2 = MockCommand("cmd2", should_succeed=True, dependencies=["cmd1"])
        scheduler = CommandScheduler(commands=[cmd1, cmd2])
        with pytest.raises(ValueError, match="循环依赖"):
            scheduler.run_dag()

    def test_run_dag_empty(self) -> None:
        """测试 DAG 执行空列表."""
        scheduler = CommandScheduler()
        result = scheduler.run_dag()
        assert result == {}

    def test_detect_execution_mode_sequential(self) -> None:
        """测试检测顺序执行模式."""
        cmd = MockCommand("cmd1")
        scheduler = CommandScheduler(commands=[cmd])
        mode = scheduler._detect_execution_mode()
        assert mode == ExecutionMode.SEQUENTIAL

    def test_detect_execution_mode_parallel(self) -> None:
        """测试检测并行执行模式."""
        commands: list[BaseCommand] = [MockCommand("cmd1"), MockCommand("cmd2")]
        scheduler = CommandScheduler(commands=commands)
        mode = scheduler._detect_execution_mode()
        assert mode == ExecutionMode.PARALLEL

    def test_detect_execution_mode_dag(self) -> None:
        """测试检测 DAG 执行模式."""
        cmd1 = MockCommand("cmd1")
        cmd2 = MockCommand("cmd2", dependencies=["cmd1"])
        scheduler = CommandScheduler(commands=[cmd1, cmd2])
        mode = scheduler._detect_execution_mode()
        assert mode == ExecutionMode.DAG

    def test_run_auto_detect_sequential(self) -> None:
        """测试自动检测顺序执行."""
        cmd = MockCommand("cmd1", should_succeed=True)
        scheduler = CommandScheduler(commands=[cmd])
        result = scheduler.run()
        assert result == {"cmd1": True}

    def test_run_auto_detect_parallel(self) -> None:
        """测试自动检测并行执行."""
        commands: list[BaseCommand] = [
            MockCommand("cmd1", should_succeed=True),
            MockCommand("cmd2", should_succeed=True),
        ]
        scheduler = CommandScheduler(commands=commands)
        result = scheduler.run()
        assert result == {"cmd1": True, "cmd2": True}

    def test_run_auto_detect_dag(self) -> None:
        """测试自动检测 DAG 执行."""
        cmd1 = MockCommand("cmd1", should_succeed=True)
        cmd2 = MockCommand("cmd2", should_succeed=True, dependencies=["cmd1"])
        scheduler = CommandScheduler(commands=[cmd1, cmd2])
        result = scheduler.run()
        assert result == {"cmd1": True, "cmd2": True}

    def test_execute_command_with_exception(self) -> None:
        """测试命令执行异常."""
        cmd = MockCommand("cmd1", raise_exception=True)
        scheduler = CommandScheduler(commands=[cmd])
        result = scheduler._execute_command(cmd)
        assert result is False

    def test_execute_command_with_retry(self) -> None:
        """测试命令重试机制."""
        cmd = MockCommand("cmd1", should_succeed=False)
        scheduler = CommandScheduler(commands=[cmd], max_retries=2, retry_delay=0.01)
        result = scheduler._execute_command(cmd)
        assert result is False
        detailed = scheduler.get_detailed_results()
        assert detailed["cmd1"].retry_count == 2

    def test_get_results(self) -> None:
        """测试获取结果."""
        cmd = MockCommand("cmd1", should_succeed=True)
        scheduler = CommandScheduler(commands=[cmd])
        scheduler.run_sequential()
        results = scheduler.get_results()
        assert results == {"cmd1": True}

    def test_get_detailed_results(self) -> None:
        """测试获取详细结果."""
        cmd = MockCommand("cmd1", should_succeed=True)
        scheduler = CommandScheduler(commands=[cmd])
        scheduler.run_sequential()
        detailed = scheduler.get_detailed_results()
        assert "cmd1" in detailed
        assert detailed["cmd1"].success is True

    def test_get_metrics(self) -> None:
        """测试获取指标."""
        commands: list[BaseCommand] = [
            MockCommand("cmd1", should_succeed=True),
            MockCommand("cmd2", should_succeed=False),
        ]
        scheduler = CommandScheduler(commands=commands)
        scheduler.run_sequential()
        metrics = scheduler.get_metrics()
        assert metrics.total_commands == 2
        assert metrics.successful == 1
        assert metrics.failed == 1

    def test_get_success_count(self) -> None:
        """测试获取成功计数."""
        commands: list[BaseCommand] = [
            MockCommand("cmd1", should_succeed=True),
            MockCommand("cmd2", should_succeed=True),
            MockCommand("cmd3", should_succeed=False),
        ]
        scheduler = CommandScheduler(commands=commands)
        scheduler.run_sequential()
        assert scheduler.get_success_count() == 2

    def test_get_failure_count(self) -> None:
        """测试获取失败计数."""
        commands: list[BaseCommand] = [
            MockCommand("cmd1", should_succeed=True),
            MockCommand("cmd2", should_succeed=False),
            MockCommand("cmd3", should_succeed=False),
        ]
        scheduler = CommandScheduler(commands=commands)
        scheduler.run_sequential()
        assert scheduler.get_failure_count() == 2

    def test_context_manager(self) -> None:
        """测试上下文管理器."""
        with CommandScheduler() as scheduler:
            assert isinstance(scheduler, CommandScheduler)

    def test_validate_dependencies_missing(self) -> None:
        """测试验证依赖缺失."""
        cmd = MockCommand("cmd1", dependencies=["nonexistent"])
        with pytest.raises(ValueError, match="不存在"):
            CommandScheduler(commands=[cmd])

    def test_progress_callback(self) -> None:
        """测试进度回调."""
        callback = MagicMock()
        cmd = MockCommand("cmd1", should_succeed=True)
        scheduler = CommandScheduler(commands=[cmd], progress_callback=callback)
        scheduler.run_sequential()
        assert callback.called

    @pytest.mark.parametrize(
        ("should_succeed", "expected"),
        [(True, True), (False, False)],
    )
    def test_execute_command_parameterized(
        self,
        should_succeed: bool,
        expected: bool,
    ) -> None:
        """参数化测试命令执行."""
        cmd = MockCommand("cmd1", should_succeed=should_succeed)
        scheduler = CommandScheduler(commands=[cmd])
        result = scheduler._execute_command(cmd)
        assert result == expected

    def test_run_sequential_empty(self) -> None:
        """测试顺序执行空命令列表."""
        scheduler = CommandScheduler()
        result = scheduler.run_sequential()
        assert result == {}

    def test_run_sequential_stop_on_failure_with_exception(self) -> None:
        """测试顺序执行异常时停止."""
        cmd1 = MockCommand("cmd1", raise_exception=True)
        cmd2 = MockCommand("cmd2", should_succeed=True)
        scheduler = CommandScheduler(commands=[cmd1, cmd2], max_retries=0)
        result = scheduler.run_sequential(stop_on_failure=True)
        assert result == {"cmd1": False}
        assert scheduler.metrics.skipped == 1

    def test_run_sequential_exception_without_stop(self) -> None:
        """测试顺序执行异常但不停止."""
        cmd1 = MockCommand("cmd1", raise_exception=True)
        cmd2 = MockCommand("cmd2", should_succeed=True)
        scheduler = CommandScheduler(commands=[cmd1, cmd2], max_retries=0)
        result = scheduler.run_sequential(stop_on_failure=False)
        assert result == {"cmd1": False, "cmd2": True}

    def test_run_parallel_with_failure(self) -> None:
        """测试并行执行命令失败."""
        commands: list[BaseCommand] = [
            MockCommand("cmd1", should_succeed=True),
            MockCommand("cmd2", should_succeed=False),
        ]
        scheduler = CommandScheduler(commands=commands)
        result = scheduler.run_parallel()
        assert result == {"cmd1": True, "cmd2": False}

    def test_run_parallel_with_exception(self) -> None:
        """测试并行执行命令异常."""
        commands: list[BaseCommand] = [
            MockCommand("cmd1", should_succeed=True),
            MockCommand("cmd2", raise_exception=True),
        ]
        scheduler = CommandScheduler(commands=commands)
        result = scheduler.run_parallel()
        assert result["cmd1"] is True
        assert result["cmd2"] is False

    def test_run_parallel_failure_logged(self) -> None:
        """测试并行执行失败时记录日志."""
        commands: list[BaseCommand] = [MockCommand("cmd1", should_succeed=False)]
        scheduler = CommandScheduler(commands=commands)
        result = scheduler.run_parallel()
        assert result["cmd1"] is False

    def test_run_dag_with_failure_stop(self) -> None:
        """测试 DAG 执行失败时停止."""
        cmd1 = MockCommand("cmd1", should_succeed=False)
        cmd2 = MockCommand("cmd2", should_succeed=True, dependencies=["cmd1"])
        scheduler = CommandScheduler(commands=[cmd1, cmd2])
        result = scheduler.run_dag(stop_on_failure=True)
        # cmd1 失败后会停止,cmd2 不会被执行,因此只包含 cmd1 的结果
        assert result["cmd1"] is False
        # cmd2 由于依赖失败而不会被执行, 不在结果中

    def test_run_dag_with_exception_stop(self) -> None:
        """测试 DAG 执行异常时停止."""
        cmd1 = MockCommand("cmd1", raise_exception=True)
        cmd2 = MockCommand("cmd2", should_succeed=True, dependencies=["cmd1"])
        scheduler = CommandScheduler(commands=[cmd1, cmd2])
        result = scheduler.run_dag(stop_on_failure=True)
        # cmd1 异常后会停止,cmd2 不会被执行,因此只包含 cmd1 的结果
        assert result["cmd1"] is False
        # cmd2 由于依赖失败而不会被执行, 不在结果中

    def test_run_dag_empty_tasks(self) -> None:
        """测试 DAG 执行空任务列表."""
        scheduler = CommandScheduler()
        result = scheduler.run_dag(tasks=[])
        assert result == {}

    def test_detect_execution_mode_empty(self) -> None:
        """测试空命令列表检测模式."""
        scheduler = CommandScheduler()
        mode = scheduler._detect_execution_mode()
        assert mode == ExecutionMode.SEQUENTIAL

    def test_execute_command_timeout_error(self) -> None:
        """测试命令执行超时."""

        class TimeoutCommand(BaseCommand):
            """模拟超时命令."""

            name = "timeout_cmd"
            description = "超时命令"

            def run(self) -> bool:
                """运行命令."""
                msg = "执行超时"
                raise TimeoutError(msg)

        cmd = TimeoutCommand()
        scheduler = CommandScheduler(commands=[cmd], max_retries=0)
        result = scheduler._execute_command(cmd)
        assert result is False

    def test_progress_callback_exception(self) -> None:
        """测试进度回调抛出异常."""

        def failing_callback(cmd_name: str, result: CommandResult) -> None:
            """会失败的回调."""
            msg = "回调失败"
            raise RuntimeError(msg)

        cmd = MockCommand("cmd1", should_succeed=True)
        scheduler = CommandScheduler(commands=[cmd], progress_callback=failing_callback)
        # 不应抛出异常, 应该被捕获并记录警告
        result = scheduler.run_sequential()
        assert result == {"cmd1": True}
