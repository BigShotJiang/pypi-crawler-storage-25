"""版本号管理命令测试.

测试 version.py 中的所有命令类, 包括:
- ReadTextVersionCommand: 从文本文件读取版本号
- UpdateTextVersionCommand: 更新文本文件版本号
- BumpFileVersionCommand: 递增文件版本号
- BumpProjectVersionCommand: 递增项目版本号
"""

from __future__ import annotations

from pathlib import Path

import pytest

from bitool.cmd.version import (
    BumpFileVersionCommand,
    BumpProjectVersionCommand,
    ReadTextVersionCommand,
    UpdateTextVersionCommand,
)

# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
def sample_init_py(tmp_path: Path) -> Path:
    """创建测试用的 __init__.py 文件."""
    init_file = tmp_path / "__init__.py"
    init_file.write_text(
        '"""Test package."""\n\n__version__ = "1.2.3"\n',
        encoding="utf-8",
    )
    return init_file


@pytest.fixture
def sample_setup_py(tmp_path: Path) -> Path:
    """创建测试用的 setup.py 文件."""
    setup_file = tmp_path / "setup.py"
    setup_file.write_text(
        'from setuptools import setup\n\nsetup(\n    name="test",\n    version="1.2.3",\n)\n',
        encoding="utf-8",
    )
    return setup_file


@pytest.fixture
def sample_package_json(tmp_path: Path) -> Path:
    """创建测试用的 package.json 文件."""
    pkg_file = tmp_path / "package.json"
    pkg_file.write_text(
        '{\n  "name": "test-package",\n  "version": "1.2.3",\n  "description": "Test"\n}\n',
        encoding="utf-8",
    )
    return pkg_file


@pytest.fixture
def sample_cargo_toml(tmp_path: Path) -> Path:
    """创建测试用的 Cargo.toml 文件."""
    cargo_file = tmp_path / "Cargo.toml"
    cargo_file.write_text(
        '[package]\nname = "test-crate"\nversion = "1.2.3"\nedition = "2021"\n',
        encoding="utf-8",
    )
    return cargo_file


@pytest.fixture
def sample_pyproject_toml(tmp_path: Path) -> Path:
    """创建测试用的 pyproject.toml 文件."""
    pyproject = tmp_path / "pyproject.toml"
    pyproject.write_text(
        '[project]\nname = "test-project"\nversion = "1.2.3"\n',
        encoding="utf-8",
    )
    return pyproject


# ============================================================================
# TestReadTextVersionCommand
# ============================================================================


class TestReadTextVersionCommand:
    """测试 ReadTextVersionCommand."""

    def test_read_version_from_init_py(self, sample_init_py: Path) -> None:
        """测试从 __init__.py 读取版本号."""
        cmd = ReadTextVersionCommand(
            filepath=sample_init_py,
            pattern=r'__version__\s*=\s*["\']([^"\']+)["\']',
        )
        assert cmd.run() is True
        assert cmd.version == "1.2.3"

    def test_read_version_from_setup_py(self, sample_setup_py: Path) -> None:
        """测试从 setup.py 读取版本号."""
        cmd = ReadTextVersionCommand(
            filepath=sample_setup_py,
            pattern=r'version\s*=\s*["\']([^"\']+)["\']',
        )
        assert cmd.run() is True
        assert cmd.version == "1.2.3"

    def test_read_version_file_not_exists(self, tmp_path: Path) -> None:
        """测试读取不存在的文件."""
        cmd = ReadTextVersionCommand(
            filepath=tmp_path / "nonexistent.py",
            pattern=r'__version__\s*=\s*["\']([^"\']+)["\']',
        )
        assert cmd.run() is False

    def test_read_version_empty_pattern(self, sample_init_py: Path) -> None:
        """测试空正则表达式模式."""
        cmd = ReadTextVersionCommand(filepath=sample_init_py, pattern="")
        assert cmd.run() is False

    def test_read_version_no_match(self, tmp_path: Path) -> None:
        """测试文件中没有匹配的版本号."""
        test_file = tmp_path / "test.py"
        test_file.write_text("# No version here\n", encoding="utf-8")
        cmd = ReadTextVersionCommand(
            filepath=test_file,
            pattern=r'__version__\s*=\s*["\']([^"\']+)["\']',
        )
        assert cmd.run() is False


# ============================================================================
# TestUpdateTextVersionCommand
# ============================================================================


class TestUpdateTextVersionCommand:
    """测试 UpdateTextVersionCommand."""

    def test_update_version_in_init_py(self, sample_init_py: Path) -> None:
        """测试更新 __init__.py 中的版本号."""
        cmd = UpdateTextVersionCommand(
            filepath=sample_init_py,
            pattern=r'__version__\s*=\s*["\']([^"\']+)["\']',
            template='__version__ = "{}"',
            version="2.0.0",
        )
        assert cmd.run() is True

        content = sample_init_py.read_text(encoding="utf-8")
        assert '__version__ = "2.0.0"' in content

    def test_update_version_in_setup_py(self, sample_setup_py: Path) -> None:
        """测试更新 setup.py 中的版本号."""
        cmd = UpdateTextVersionCommand(
            filepath=sample_setup_py,
            pattern=r'version\s*=\s*["\']([^"\']+)["\']',
            template='version = "{}"',
            version="3.0.0",
        )
        assert cmd.run() is True

        content = sample_setup_py.read_text(encoding="utf-8")
        assert 'version = "3.0.0"' in content

    def test_update_version_parent_not_exists(self, tmp_path: Path) -> None:
        """测试父目录不存在的情况."""
        cmd = UpdateTextVersionCommand(
            filepath=tmp_path / "nonexistent" / "test.py",
            pattern=r'__version__\s*=\s*["\']([^"\']+)["\']',
            template='__version__ = "{}"',
            version="1.0.0",
        )
        assert cmd.run() is False

    def test_update_version_empty_pattern(self, sample_init_py: Path) -> None:
        """测试空正则表达式模式."""
        cmd = UpdateTextVersionCommand(
            filepath=sample_init_py,
            pattern="",
            template='__version__ = "{}"',
            version="1.0.0",
        )
        assert cmd.run() is False

    def test_update_version_empty_template(self, sample_init_py: Path) -> None:
        """测试空替换模板."""
        cmd = UpdateTextVersionCommand(
            filepath=sample_init_py,
            pattern=r'__version__\s*=\s*["\']([^"\']+)["\']',
            template="",
            version="1.0.0",
        )
        assert cmd.run() is False


# ============================================================================
# TestBumpFileVersionCommand
# ============================================================================


class TestBumpFileVersionCommand:
    """测试 BumpFileVersionCommand."""

    def test_bump_pyproject_patch(self, sample_pyproject_toml: Path) -> None:
        """测试递增 pyproject.toml 的补丁号."""
        cmd = BumpFileVersionCommand(
            filepath=sample_pyproject_toml,
            version_part="patch",
        )
        assert cmd.run() is True
        assert cmd.old_version == "1.2.3"
        assert cmd.new_version == "1.2.4"

        content = sample_pyproject_toml.read_text(encoding="utf-8")
        assert 'version = "1.2.4"' in content

    def test_bump_pyproject_minor(self, sample_pyproject_toml: Path) -> None:
        """测试递增 pyproject.toml 的次版本号."""
        cmd = BumpFileVersionCommand(
            filepath=sample_pyproject_toml,
            version_part="minor",
        )
        assert cmd.run() is True
        assert cmd.new_version == "1.3.0"

    def test_bump_pyproject_major(self, sample_pyproject_toml: Path) -> None:
        """测试递增 pyproject.toml 的主版本号."""
        cmd = BumpFileVersionCommand(
            filepath=sample_pyproject_toml,
            version_part="major",
        )
        assert cmd.run() is True
        assert cmd.new_version == "2.0.0"

    def test_bump_pyproject_with_prerelease(self, sample_pyproject_toml: Path) -> None:
        """测试递增并设置预发布标识."""
        cmd = BumpFileVersionCommand(
            filepath=sample_pyproject_toml,
            version_part="patch",
            prerelease="alpha",
        )
        assert cmd.run() is True
        assert cmd.new_version == "1.2.4-alpha"

    def test_bump_init_py(self, sample_init_py: Path) -> None:
        """测试递增 __init__.py 的版本号."""
        cmd = BumpFileVersionCommand(
            filepath=sample_init_py,
            version_part="patch",
            read_pattern=r'__version__\s*=\s*["\']([^"\']+)["\']',
            update_template='__version__ = "{}"',
        )
        assert cmd.run() is True
        assert cmd.new_version == "1.2.4"

        content = sample_init_py.read_text(encoding="utf-8")
        assert '__version__ = "1.2.4"' in content

    def test_bump_setup_py(self, sample_setup_py: Path) -> None:
        """测试递增 setup.py 的版本号."""
        cmd = BumpFileVersionCommand(
            filepath=sample_setup_py,
            version_part="minor",
            read_pattern=r'version\s*=\s*["\']([^"\']+)["\']',
            update_template='version = "{}"',
        )
        assert cmd.run() is True
        assert cmd.new_version == "1.3.0"

    def test_bump_package_json(self, sample_package_json: Path) -> None:
        """测试递增 package.json 的版本号."""
        cmd = BumpFileVersionCommand(
            filepath=sample_package_json,
            version_part="patch",
            read_pattern=r'"version"\s*:\s*"([^"]+)"',
            update_template='"version": "{}"',
        )
        assert cmd.run() is True
        assert cmd.new_version == "1.2.4"

    def test_bump_cargo_toml(self, sample_cargo_toml: Path) -> None:
        """测试递增 Cargo.toml 的版本号."""
        cmd = BumpFileVersionCommand(
            filepath=sample_cargo_toml,
            version_part="major",
            read_pattern=r'^version\s*=\s*"([^"]+)"',
            update_template='version = "{}"',
        )
        assert cmd.run() is True
        assert cmd.new_version == "2.0.0"

    def test_bump_file_not_exists(self, tmp_path: Path) -> None:
        """测试递增不存在的文件."""
        cmd = BumpFileVersionCommand(
            filepath=tmp_path / "nonexistent.toml",
            version_part="patch",
        )
        assert cmd.run() is False

    def test_bump_invalid_version(self, tmp_path: Path) -> None:
        """测试无效版本号格式."""
        test_file = tmp_path / "test.toml"
        test_file.write_text('[project]\nversion = "invalid"\n', encoding="utf-8")
        cmd = BumpFileVersionCommand(filepath=test_file, version_part="patch")
        assert cmd.run() is False

    def test_bump_invalid_part(self, sample_pyproject_toml: Path) -> None:
        """测试不支持的版本号部分."""
        cmd = BumpFileVersionCommand(
            filepath=sample_pyproject_toml,
            version_part="invalid",
        )
        assert cmd.run() is False

    @pytest.mark.parametrize(
        "part,expected",
        [("patch", "1.2.4"), ("minor", "1.3.0"), ("major", "2.0.0")],
    )
    def test_bump_version_parts(
        self,
        sample_pyproject_toml: Path,
        part: str,
        expected: str,
    ) -> None:
        """参数化测试不同版本号部分的递增."""
        cmd = BumpFileVersionCommand(filepath=sample_pyproject_toml, version_part=part)
        assert cmd.run() is True
        assert cmd.new_version == expected


# ============================================================================
# TestBumpProjectVersionCommand
# ============================================================================


class TestBumpProjectVersionCommand:
    """测试 BumpProjectVersionCommand."""

    def test_bump_single_pyproject(self, tmp_path: Path) -> None:
        """测试递增单个 pyproject.toml."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(
            '[project]\nname = "test"\nversion = "1.0.0"\n',
            encoding="utf-8",
        )

        cmd = BumpProjectVersionCommand(root_path=tmp_path, part="patch")
        assert cmd.run() is True
        assert len(cmd.updated_files) == 1

        content = pyproject.read_text(encoding="utf-8")
        assert 'version = "1.0.1"' in content

    def test_bump_multiple_files(self, tmp_path: Path) -> None:
        """测试递增多个文件."""
        # 创建 pyproject.toml
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(
            '[project]\nname = "test"\nversion = "1.0.0"\n',
            encoding="utf-8",
        )

        # 创建 __init__.py
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        init_file = src_dir / "__init__.py"
        init_file.write_text('__version__ = "1.0.0"\n', encoding="utf-8")

        cmd = BumpProjectVersionCommand(root_path=tmp_path, part="minor")
        assert cmd.run() is True
        assert len(cmd.updated_files) == 2

        # 验证两个文件都被更新
        content = pyproject.read_text(encoding="utf-8")
        assert 'version = "1.1.0"' in content

        content = init_file.read_text(encoding="utf-8")
        assert '__version__ = "1.1.0"' in content

    def test_exclude_root_pyproject(self, tmp_path: Path) -> None:
        """测试排除根目录的 pyproject.toml."""
        # 创建根目录 pyproject.toml
        root_pyproject = tmp_path / "pyproject.toml"
        root_pyproject.write_text(
            '[project]\nname = "root"\nversion = "1.0.0"\n',
            encoding="utf-8",
        )

        # 创建子项目
        sub_dir = tmp_path / "sub-project"
        sub_dir.mkdir()
        sub_pyproject = sub_dir / "pyproject.toml"
        sub_pyproject.write_text(
            '[project]\nname = "sub"\nversion = "2.0.0"\n',
            encoding="utf-8",
        )

        cmd = BumpProjectVersionCommand(
            root_path=tmp_path,
            part="patch",
            exclude_root=True,
        )
        assert cmd.run() is True

        # 根目录不应被更新
        content = root_pyproject.read_text(encoding="utf-8")
        assert 'version = "1.0.0"' in content

        # 子项目应该被更新
        content = sub_pyproject.read_text(encoding="utf-8")
        assert 'version = "2.0.1"' in content

    def test_excluded_dirs(self, tmp_path: Path) -> None:
        """测试排除目录."""
        # 创建 .venv 目录
        venv_dir = tmp_path / ".venv"
        venv_dir.mkdir()
        venv_pyproject = venv_dir / "pyproject.toml"
        venv_pyproject.write_text(
            '[project]\nname = "venv"\nversion = "1.0.0"\n',
            encoding="utf-8",
        )

        # 创建正常目录
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        src_pyproject = src_dir / "pyproject.toml"
        src_pyproject.write_text(
            '[project]\nname = "src"\nversion = "1.0.0"\n',
            encoding="utf-8",
        )

        cmd = BumpProjectVersionCommand(root_path=tmp_path, part="patch")
        assert cmd.run() is True

        # .venv 中的文件不应被更新
        content = venv_pyproject.read_text(encoding="utf-8")
        assert 'version = "1.0.0"' in content

        # src 中的文件应该被更新
        content = src_pyproject.read_text(encoding="utf-8")
        assert 'version = "1.0.1"' in content

    def test_exclude_node_modules(self, tmp_path: Path) -> None:
        """测试排除 node_modules 目录."""
        # 创建 node_modules 目录
        node_modules_dir = tmp_path / "node_modules"
        node_modules_dir.mkdir()

        # 在 node_modules 中创建多个包
        pkg1_dir = node_modules_dir / "@element-plus"
        pkg1_dir.mkdir()
        pkg1_json = pkg1_dir / "package.json"
        pkg1_json.write_text(
            '{\n  "name": "@element-plus/icons-vue",\n  "version": "2.3.4"\n}\n',
            encoding="utf-8",
        )

        pkg2_dir = node_modules_dir / "@esbuild"
        pkg2_dir.mkdir()
        pkg2_json = pkg2_dir / "package.json"
        pkg2_json.write_text(
            '{\n  "name": "@esbuild/win32-x64",\n  "version": "0.27.4"\n}\n',
            encoding="utf-8",
        )

        pkg3_dir = node_modules_dir / "@eslint"
        pkg3_dir.mkdir()
        pkg3_json = pkg3_dir / "package.json"
        pkg3_json.write_text(
            '{\n  "name": "@eslint/config-array",\n  "version": "0.21.3"\n}\n',
            encoding="utf-8",
        )

        # 创建正常的项目文件
        src_dir = tmp_path / "frontend"
        src_dir.mkdir()
        src_package_json = src_dir / "package.json"
        src_package_json.write_text(
            '{\n  "name": "my-frontend",\n  "version": "1.0.0"\n}\n',
            encoding="utf-8",
        )

        cmd = BumpProjectVersionCommand(root_path=tmp_path, part="patch")
        assert cmd.run() is True

        # node_modules 中的文件不应被更新
        content1 = pkg1_json.read_text(encoding="utf-8")
        assert '"version": "2.3.4"' in content1

        content2 = pkg2_json.read_text(encoding="utf-8")
        assert '"version": "0.27.4"' in content2

        content3 = pkg3_json.read_text(encoding="utf-8")
        assert '"version": "0.21.3"' in content3

        # frontend 中的文件应该被更新
        content_src = src_package_json.read_text(encoding="utf-8")
        assert '"version": "1.0.1"' in content_src

        # 验证更新的文件列表不包含 node_modules 中的文件

        updated_files = cmd.updated_files
        assert len(updated_files) == 1
        assert src_package_json in updated_files
        # 检查路径中是否包含 node_modules 目录（作为路径组件）
        for f in updated_files:
            assert "node_modules" not in f.parts, f"File {f} should not be in node_modules"

    def test_no_version_files(self, tmp_path: Path) -> None:
        """测试没有版本文件的情况."""
        # 创建空文件
        (tmp_path / "readme.txt").write_text("empty", encoding="utf-8")

        cmd = BumpProjectVersionCommand(root_path=tmp_path, part="patch")
        assert cmd.run() is False

    def test_nonexistent_path(self, tmp_path: Path) -> None:
        """测试不存在的目录."""
        cmd = BumpProjectVersionCommand(
            root_path=tmp_path / "nonexistent",
            part="patch",
        )
        assert cmd.run() is False

    def test_bump_with_prerelease(self, tmp_path: Path) -> None:
        """测试递增并设置预发布标识."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(
            '[project]\nname = "test"\nversion = "1.0.0"\n',
            encoding="utf-8",
        )

        cmd = BumpProjectVersionCommand(
            root_path=tmp_path,
            part="patch",
            prerelease="beta",
        )
        assert cmd.run() is True

        content = pyproject.read_text(encoding="utf-8")
        assert 'version = "1.0.1-beta"' in content

    @pytest.mark.parametrize(
        "part,initial,expected",
        [
            ("patch", "1.0.0", "1.0.1"),
            ("minor", "1.0.0", "1.1.0"),
            ("major", "1.0.0", "2.0.0"),
            ("patch", "1.2.3", "1.2.4"),
            ("minor", "1.2.3", "1.3.0"),
            ("major", "1.2.3", "2.0.0"),
        ],
    )
    def test_bump_all_parts(
        self,
        tmp_path: Path,
        part: str,
        initial: str,
        expected: str,
    ) -> None:
        """参数化测试所有版本号部分的递增."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(
            f'[project]\nname = "test"\nversion = "{initial}"\n',
            encoding="utf-8",
        )

        cmd = BumpProjectVersionCommand(root_path=tmp_path, part=part)
        assert cmd.run() is True

        content = pyproject.read_text(encoding="utf-8")
        assert f'version = "{expected}"' in content


# ============================================================================
# TestTomlFormatPreservation
# ============================================================================


class TestTomlFormatPreservation:
    """测试 TOML 文件格式保持功能."""

    def test_update_toml_preserves_format(self, tmp_path: Path) -> None:
        """测试更新 TOML 版本号时保持其他内容格式不变."""
        toml_file = tmp_path / "pyproject.toml"
        original_content = """[project]
name = "test-project"
version = "1.0.0"
description = "A test project"

[project.dependencies]
python = ">=3.8"
requests = "^2.28.0"

[tool.bitool]
debug = true
verbose = false
"""
        toml_file.write_text(original_content, encoding="utf-8")

        cmd = BumpFileVersionCommand(filepath=toml_file, version_part="patch")
        assert cmd.run() is True
        assert cmd.old_version == "1.0.0"
        assert cmd.new_version == "1.0.1"

        # 验证更新后的内容
        updated_content = toml_file.read_text(encoding="utf-8")

        # 版本号应该被更新
        assert 'version = "1.0.1"' in updated_content

        # 其他内容应该保持不变（包括格式、空格、注释等）
        assert "[project]" in updated_content
        assert 'name = "test-project"' in updated_content
        assert 'description = "A test project"' in updated_content
        assert "[project.dependencies]" in updated_content
        assert 'python = ">=3.8"' in updated_content
        assert 'requests = "^2.28.0"' in updated_content
        assert "[tool.bitool]" in updated_content
        assert "debug = true" in updated_content
        assert "verbose = false" in updated_content

        # 验证整个文件内容除了版本号外完全一致
        expected_content = original_content.replace(
            'version = "1.0.0"',
            'version = "1.0.1"',
        )
        assert updated_content == expected_content

    def test_update_toml_preserves_comments(self, tmp_path: Path) -> None:
        """测试更新 TOML 时保留注释."""
        toml_file = tmp_path / "pyproject.toml"
        original_content = """[project]
# Project name
name = "my-project"
# Current version
version = "2.0.0"
# Project description
description = "My awesome project"
"""
        toml_file.write_text(original_content, encoding="utf-8")

        cmd = BumpFileVersionCommand(filepath=toml_file, version_part="minor")
        assert cmd.run() is True

        updated_content = toml_file.read_text(encoding="utf-8")

        # 版本号应该被更新
        assert 'version = "2.1.0"' in updated_content

        # 注释和其他内容应该保留（文本替换方式会保留）
        assert "# Project name" in updated_content
        assert "# Current version" in updated_content
        assert "# Project description" in updated_content
        assert 'name = "my-project"' in updated_content
        assert 'description = "My awesome project"' in updated_content

    def test_update_toml_different_quote_styles(self, tmp_path: Path) -> None:
        """测试不同引号风格的版本号都能正确更新."""
        # 测试双引号
        toml_double = tmp_path / "double.toml"
        toml_double.write_text('[project]\nversion = "1.0.0"\n', encoding="utf-8")

        cmd = BumpFileVersionCommand(filepath=toml_double, version_part="patch")
        assert cmd.run() is True

        content = toml_double.read_text(encoding="utf-8")
        assert 'version = "1.0.1"' in content

        # 测试单引号
        toml_single = tmp_path / "single.toml"
        toml_single.write_text("[project]\nversion = '1.0.0'\n", encoding="utf-8")

        cmd = BumpFileVersionCommand(filepath=toml_single, version_part="patch")
        assert cmd.run() is True

        content = toml_single.read_text(encoding="utf-8")
        assert "version = '1.0.1'" in content

    def test_update_toml_different_spacing(self, tmp_path: Path) -> None:
        """测试不同空格格式的版本号行都能正确更新."""
        test_cases = [
            ('version = "1.0.0"', 'version = "1.0.1"'),
            ('version="1.0.0"', 'version="1.0.1"'),
            ('version  =  "1.0.0"', 'version  =  "1.0.1"'),
            ('version   =   "1.0.0"', 'version   =   "1.0.1"'),
        ]

        for i, (original_line, expected_line) in enumerate(test_cases):
            toml_file = tmp_path / f"spacing_{i}.toml"
            content = f"[project]\n{original_line}\n"
            toml_file.write_text(content, encoding="utf-8")

            cmd = BumpFileVersionCommand(filepath=toml_file, version_part="patch")
            assert cmd.run() is True, f"Failed for: {original_line}"

            updated = toml_file.read_text(encoding="utf-8")
            assert expected_line in updated, f"Expected {expected_line} in {updated}"
            # 确保空格格式保持不变
            assert original_line.replace("1.0.0", "1.0.1") == expected_line

    def test_update_toml_nested_version_path(self, tmp_path: Path) -> None:
        """测试嵌套路径的版本号更新."""
        toml_file = tmp_path / "nested.toml"
        original_content = """[project]
name = "test"

[tool.bitool.settings]
version = "1.0.0"
debug = true
"""
        toml_file.write_text(original_content, encoding="utf-8")

        cmd = BumpFileVersionCommand(
            filepath=toml_file,
            version_part="patch",
            version_path=["tool", "bitool", "settings", "version"],
        )
        assert cmd.run() is True

        updated_content = toml_file.read_text(encoding="utf-8")

        # 版本号应该被更新
        assert 'version = "1.0.1"' in updated_content

        # 其他内容保持不变
        assert "[project]" in updated_content
        assert 'name = "test"' in updated_content
        assert "[tool.bitool.settings]" in updated_content
        assert "debug = true" in updated_content

    def test_update_toml_version_not_found(self, tmp_path: Path) -> None:
        """测试版本号不存在时的处理."""
        toml_file = tmp_path / "no_version.toml"
        toml_file.write_text('[project]\nname = "test"\n', encoding="utf-8")

        cmd = BumpFileVersionCommand(filepath=toml_file, version_part="patch")
        assert cmd.run() is False


class TestTomlAlignmentPreservation:
    """测试各种 TOML 文件的等号对齐保持功能."""

    @pytest.mark.parametrize(
        "filename,content,expected_version_line",
        [
            # pyproject.toml - 标准格式
            (
                "pyproject.toml",
                '[project]\nname        = "test-project"\nversion     = "1.0.0"\ndescription = "A test"\n',
                'version     = "1.0.1"',
            ),
            # pyproject.toml - 不同空格对齐
            (
                "pyproject.toml",
                '[project]\nname    = "test"\nversion = "1.0.0"\ndesc  = "Test"\n',
                'version = "1.0.1"',
            ),
            # Cargo.toml - 等号对齐格式
            (
                "Cargo.toml",
                '[package]\nname        = "test"\nversion     = "1.0.0"\nedition     = "2021"\n',
                'version     = "1.0.1"',
            ),
            # Cargo.toml - 无对齐格式
            (
                "Cargo.toml",
                '[package]\nname = "test"\nversion = "1.0.0"\nedition = "2021"\n',
                'version = "1.0.1"',
            ),
            # 自定义 TOML - 多级嵌套带对齐（使用 BumpFileVersionCommand）
            # 注意：自定义 TOML 文件不在 FILE_PATTERNS 中，需要手动指定版本路径
        ],
    )
    def test_various_toml_alignment_preserved(
        self,
        tmp_path: Path,
        filename: str,
        content: str,
        expected_version_line: str,
    ) -> None:
        """测试各种 TOML 文件格式的等号对齐保持."""
        toml_file = tmp_path / filename
        toml_file.write_text(content, encoding="utf-8")

        # 使用 BumpProjectVersionCommand 自动识别文件类型并更新
        cmd = BumpProjectVersionCommand(root_path=tmp_path, part="patch")
        assert cmd.run() is True
        assert len(cmd.updated_files) == 1

        updated_content = toml_file.read_text(encoding="utf-8")

        # 验证版本号已更新且保持对齐格式
        assert expected_version_line in updated_content

        # 验证版本号确实递增了
        assert '"1.0.1"' in updated_content
        assert '"1.0.0"' not in updated_content

    def test_custom_toml_alignment(self, tmp_path: Path) -> None:
        """测试自定义 TOML 文件的等号对齐保持（使用 BumpFileVersionCommand）."""
        original_content = '[tool.settings]\nname    = "mytool"\nversion = "1.0.0"\ndebug   = true\n'
        toml_file = tmp_path / "config.toml"
        toml_file.write_text(original_content, encoding="utf-8")

        # 使用 BumpFileVersionCommand 手动指定版本路径
        cmd = BumpFileVersionCommand(
            filepath=toml_file,
            version_part="patch",
            version_path=["tool", "settings", "version"],
        )
        assert cmd.run() is True

        updated_content = toml_file.read_text(encoding="utf-8")

        # 验证版本号已更新（自定义 TOML 使用 _update_toml_version，保持对齐）
        assert 'version = "1.0.1"' in updated_content
        assert 'name    = "mytool"' in updated_content
        assert "debug   = true" in updated_content

    def test_pyproject_toml_complex_alignment(self, tmp_path: Path) -> None:
        """测试 pyproject.toml 复杂场景的等号对齐保持."""
        original_content = """[project]
name        = "my-awesome-project"
version     = "2.0.0"
description = "An awesome project"
authors     = [{name = "Test", email = "test@example.com"}]

[project.optional-dependencies]
dev = ["pytest", "ruff"]

[tool.bitool]
enabled     = true
log_level   = "info"
max_workers = 4
"""
        toml_file = tmp_path / "pyproject.toml"
        toml_file.write_text(original_content, encoding="utf-8")

        cmd = BumpProjectVersionCommand(root_path=tmp_path, part="minor")
        assert cmd.run() is True

        updated_content = toml_file.read_text(encoding="utf-8")

        # 版本号应该更新且保持对齐（11个空格）
        assert 'version     = "2.1.0"' in updated_content

        # 其他字段的对齐应该保持不变
        assert 'name        = "my-awesome-project"' in updated_content
        assert 'description = "An awesome project"' in updated_content
        assert "enabled     = true" in updated_content
        assert 'log_level   = "info"' in updated_content
        assert "max_workers = 4" in updated_content

        # 其他内容应该完全不变
        assert "[project.optional-dependencies]" in updated_content
        assert 'dev = ["pytest", "ruff"]' in updated_content
        assert "[tool.bitool]" in updated_content

    def test_cargo_toml_complex_alignment(self, tmp_path: Path) -> None:
        """测试 Cargo.toml 复杂场景的等号对齐保持."""
        original_content = """[package]
name        = "bitool-core"
version     = "0.1.0"
edition     = "2021"
authors     = ["Test Author"]
license     = "MIT"
description = "Bitool Core"

[dependencies]
pyo3    = "0.20.0"
serde   = {version = "1.0", features = ["derive"]}
tokio   = {version = "1.0", features = ["full"]}
"""
        cargo_file = tmp_path / "Cargo.toml"
        cargo_file.write_text(original_content, encoding="utf-8")

        cmd = BumpProjectVersionCommand(root_path=tmp_path, part="patch")
        assert cmd.run() is True

        updated_content = cargo_file.read_text(encoding="utf-8")

        # 版本号应该更新且保持对齐（5个空格）
        assert 'version     = "0.1.1"' in updated_content

        # 其他字段的对齐应该保持不变
        assert 'name        = "bitool-core"' in updated_content
        assert 'edition     = "2021"' in updated_content
        assert 'authors     = ["Test Author"]' in updated_content
        assert 'license     = "MIT"' in updated_content
        assert 'description = "Bitool Core"' in updated_content

        # 依赖部分的对齐也应该保持（注意这里的字段没有对齐）
        assert 'pyo3    = "0.20.0"' in updated_content
        assert 'serde   = {version = "1.0", features = ["derive"]}' in updated_content
        assert 'tokio   = {version = "1.0", features = ["full"]}' in updated_content

    def test_toml_single_quotes_alignment(self, tmp_path: Path) -> None:
        """测试 TOML 文件使用单引号时的等号对齐保持."""
        original_content = "[project]\nname    = 'my-project'\nversion = '1.0.0'\ndesc    = 'Test'\n"
        toml_file = tmp_path / "pyproject.toml"
        toml_file.write_text(original_content, encoding="utf-8")

        cmd = BumpProjectVersionCommand(root_path=tmp_path, part="major")
        assert cmd.run() is True

        updated_content = toml_file.read_text(encoding="utf-8")

        # 版本号应该更新且保持单引号和对齐
        assert "version = '2.0.0'" in updated_content
        assert "name    = 'my-project'" in updated_content
        assert "desc    = 'Test'" in updated_content
        # 不应该出现双引号
        assert '"' not in updated_content.split("[")[0]

    def test_multiple_toml_files_in_project(self, tmp_path: Path) -> None:
        """测试项目中多个 TOML 文件的等号对齐保持."""
        # 创建 pyproject.toml
        pyproject_content = """[project]
name    = "my-project"
version = "1.0.0"
"""
        pyproject_file = tmp_path / "pyproject.toml"
        pyproject_file.write_text(pyproject_content, encoding="utf-8")

        # 创建子目录的 Cargo.toml
        subdir = tmp_path / "core"
        subdir.mkdir()
        cargo_content = """[package]
name        = "my-project-core"
version     = "1.0.0"
edition     = "2021"
"""
        cargo_file = subdir / "Cargo.toml"
        cargo_file.write_text(cargo_content, encoding="utf-8")

        # 执行项目版本号递增
        cmd = BumpProjectVersionCommand(root_path=tmp_path, part="minor")
        assert cmd.run() is True
        assert len(cmd.updated_files) == 2

        # 验证 pyproject.toml 的对齐保持（4个空格）
        updated_pyproject = pyproject_file.read_text(encoding="utf-8")
        assert 'name    = "my-project"' in updated_pyproject
        assert 'version = "1.1.0"' in updated_pyproject

        # 验证 Cargo.toml 的对齐保持（5个空格）
        updated_cargo = cargo_file.read_text(encoding="utf-8")
        assert 'name        = "my-project-core"' in updated_cargo
        assert 'version     = "1.1.0"' in updated_cargo
        assert 'edition     = "2021"' in updated_cargo
