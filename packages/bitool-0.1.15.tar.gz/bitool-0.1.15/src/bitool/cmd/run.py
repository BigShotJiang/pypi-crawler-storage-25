"""命令执行模块.

提供命令执行的核心函数: run_command, run_command_async 等.
注意: RunSequentialCommands/RunParallelCommands/RunDAGCommands 已移除,
推荐使用 utils/task_group.py 中的 TaskGroup 直接操作.
"""

from __future__ import annotations

import shlex
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, List, cast

from bitool.cmd import BaseCommand
from bitool.core import logger
from bitool.utils.executor import RunResult, execute


def _parse_shell_command(command: str) -> tuple[list[str], str | None, bool, bool]:
    """安全地解析包含重定向的 shell 命令。

    手动解析常见的 shell 操作符（>, >>, |），避免使用 shell=True。

    Args:
        command: shell 命令字符串。

    Returns:
        元组 (cmd_args, stdout_redirect, append_mode, has_pipe)
        - cmd_args: 命令及其参数列表
        - stdout_redirect: 标准输出重定向文件路径（如果有）
        - append_mode: 是否为追加模式（>>）
        - has_pipe: 是否包含管道（暂不支持）

    Raises:
        ValueError: 当命令包含不支持的操作符时。
    """
    # 检查管道操作符（暂不支持）
    if "|" in command:
        msg = "不支持管道操作符, 请使用多个命令分别执行"
        raise ValueError(msg)

    # 解析重定向操作符
    stdout_redirect: str | None = None
    append_mode = False

    # 处理 >> (追加)
    if ">>" in command:
        parts_redirect: list[str] = command.split(">>", 1)
        cmd_main: str = parts_redirect[0].strip()
        stdout_redirect = parts_redirect[1].strip()
        append_mode = True
    # 处理 > (覆盖)
    elif ">" in command:
        parts_redirect = command.split(">", 1)
        cmd_main = parts_redirect[0].strip()
        stdout_redirect = parts_redirect[1].strip()
    else:
        cmd_main = command

    # 使用 shlex 安全地分割命令
    cmd_args: list[str] = shlex.split(cmd_main)

    return cmd_args, stdout_redirect, append_mode, False


__all__ = ["RunCommand", "RunResult", "RunShellCommand"]


@dataclass
class BaseRunCommand(BaseCommand):
    cmd: list[str] | Callable[[], None] = field(default_factory=list)
    cwd: Path | None = None
    env: dict[str, str] | None = None
    timeout: int | None = None
    check: bool = False


@dataclass
class RunCommand(BaseRunCommand):
    """执行单个命令"""

    name = "run"
    description = "执行单个命令"

    def run(self) -> bool:
        """执行单个命令"""
        if isinstance(self.cmd, list):
            cmd_list = cast(List[str], self.cmd)
            cmd_str = " ".join(str(arg) for arg in cmd_list)
            try:
                result = execute(
                    cmd_list,
                    cwd=self.cwd,
                    env=self.env,
                    timeout=self.timeout,
                    check=self.check,
                )
                # 检查实际返回码, 而非仅依赖异常
                if result.returncode == 0:
                    logger.info(f"命令执行成功: `{cmd_str}`")
                    return True
                else:
                    # 返回码非零, 但 check=False 时不会抛异常, 需要手动判断为失败
                    logger.warning(
                        f"命令执行完成但返回码非零: `{cmd_str}`, 返回码: {result.returncode}",
                    )
                    return False
            except subprocess.CalledProcessError as e:
                logger.error(f"命令执行失败: `{cmd_str}`, 返回码: {e.returncode}")
                return False
            except subprocess.TimeoutExpired as e:
                logger.error(f"命令执行超时: `{cmd_str}`, 超时: {e.timeout}秒")
                return False
            except OSError as e:
                logger.error(f"命令执行失败: `{cmd_str}`, 错误: {e}")
                return False
            except Exception as e:  # noqa: BLE001
                logger.error(f"命令执行失败: `{cmd_str}`, 错误: {e}")
                return False
        else:
            # 命令是 Callable[[], None] 类型，直接调用
            self.cmd()
        return True


@dataclass
class RunShellCommand(BaseRunCommand):
    """执行shell命令字符串"""

    name = "run_shell"
    description = "执行shell命令字符串"
    shell_cmd: str = ""

    def run(self) -> bool:
        """执行shell命令字符串（安全版本，支持重定向）。"""
        try:
            # 安全解析命令（避免使用 shell=True）
            cmd_args, stdout_redirect, append_mode, _ = _parse_shell_command(
                self.shell_cmd,
            )

            if not cmd_args:
                logger.error(f"Shell命令为空: `{self.shell_cmd}`")
                return False

            # 执行命令并处理重定向
            if stdout_redirect:
                # 确保输出目录存在
                redirect_path = Path(stdout_redirect)
                if redirect_path.parent != Path("."):
                    redirect_path.parent.mkdir(parents=True, exist_ok=True)

                # 以追加或覆盖模式打开文件
                mode = "a" if append_mode else "w"

                # 使用 execute 执行命令，然后将输出写入文件
                result = execute(
                    cmd_args,
                    cwd=self.cwd,
                    timeout=self.timeout,
                    capture_output=True,
                    text=True,
                )

                # 写入输出到文件
                with redirect_path.open(mode, encoding="utf-8") as outfile:
                    outfile.write(result.stdout)

                if result.returncode == 0:
                    logger.info(f"Shell命令执行成功: `{self.shell_cmd}`")
                    return True
                else:
                    error_output = result.stderr.strip()
                    logger.error(
                        f"Shell命令执行失败: `{self.shell_cmd}`, 返回码: {result.returncode}, 错误: {error_output}",
                    )
                    return False
            else:
                # 无重定向，正常执行
                result = execute(
                    cmd_args,
                    cwd=self.cwd,
                    timeout=self.timeout,
                    capture_output=True,
                    text=True,
                )

                if result.returncode == 0:
                    logger.info(f"Shell命令执行成功: `{self.shell_cmd}`")
                    if result.stdout.strip():
                        for line in result.stdout.strip().split("\n"):
                            if line.strip():
                                logger.info(f"  输出: `{line.strip()}`")
                    return True
                else:
                    error_output = result.stderr.strip()
                    logger.error(
                        f"Shell命令执行失败: `{self.shell_cmd}`, 返回码: {result.returncode}, 错误: {error_output}",
                    )
                    return False

        except Exception as e:  # noqa: BLE001
            logger.error(f"Shell命令执行异常: `{self.shell_cmd}`, 错误: {e}")
            return False


@dataclass
class BaseRunMultipleCommands(BaseCommand):
    commands: list[list[str]] = field(default_factory=list)
    stop_on_failure: bool = False
    max_workers: int | None = None
    results: list[RunResult] = field(default_factory=list)
