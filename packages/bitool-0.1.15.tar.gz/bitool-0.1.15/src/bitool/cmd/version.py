"""版本号管理相关命令.

提供文件和 TOML 文档的版本号读取、更新和递增功能.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import ClassVar

try:
    import tomli
    import tomli_w
except ImportError:
    try:
        import tomli_w
        import tomllib as tomli  # ty: ignore[unresolved-import]
    except ImportError:
        tomli = None  # ty: ignore
        tomli_w = None  # ty: ignore

from bitool.cmd._base import BaseCommand
from bitool.cmd.git import GitCommitCommand, GitTagCommand
from bitool.core import logger

_VERSION_PATTERN = re.compile(
    r"(?P<major>0|[1-9]\d*)\.(?P<minor>0|[1-9]\d*)\.(?P<patch>0|[1-9]\d*)"
    r"(?:-(?P<prerelease>(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?"
    r"(?:\+(?P<buildmetadata>[0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?",
)


@dataclass
class ReadTextVersionCommand(BaseCommand):
    """从文本文件读取版本号命令.

    使用正则表达式从文本文件中提取版本号.

    Attributes:
        filepath: 文件路径
        pattern: 正则表达式模式
        version: 读取到的版本号
    """

    name: str = "read-text-version"
    description: str = "从文本文件读取版本号"
    filepath: Path = Path()
    pattern: str = ""
    version: str = ""

    def run(self) -> bool:
        """执行文本文件版本号读取.

        Returns
        -------
        bool
            读取成功返回True, 否则返回False
        """
        if not self.filepath.exists():
            logger.warning(f"文件不存在: {self.filepath}")
            return False

        if not self.pattern:
            logger.error("未提供正则表达式模式")
            return False

        try:
            content = self.filepath.read_text(encoding="utf-8")
            match = re.search(self.pattern, content, re.MULTILINE)
            if not match:
                logger.warning(f"在 {self.filepath} 中未找到版本号")
                return False

            self.version = match.group(1)
            logger.info(f"读取到版本号: {self.filepath} -> {self.version}")
        except re.error as e:
            logger.error(f"正则表达式错误: {e}")
            return False
        except OSError as e:
            logger.error(f"读取文本版本号失败: {e}")
            return False
        except UnicodeDecodeError as e:
            logger.error(f"文件编码错误: {e}")
            return False
        else:
            return True


@dataclass
class UpdateTextVersionCommand(BaseCommand):
    """更新文本文件版本号命令.

    使用正则表达式替换文本文件中的版本号.

    Attributes:
        filepath: 文件路径
        pattern: 查找正则表达式模式
        template: 替换模板字符串 (使用 {} 占位新版本号)
        version: 新版本号
    """

    name: str = "update-text-version"
    description: str = "更新文本文件中的版本号"
    filepath: Path = Path()
    pattern: str = ""
    template: str = ""
    version: str = ""

    def run(self) -> bool:
        """执行文本文件版本号更新.

        Returns
        -------
        bool
            更新成功返回True, 否则返回False
        """
        if not self.filepath.parent.exists():
            logger.warning(f"目录不存在: {self.filepath.parent}")
            return False

        if not self.pattern or not self.template:
            logger.error("未提供正则表达式模式或替换模板")
            return False

        try:
            content = self.filepath.read_text(encoding="utf-8")
            new_content = re.sub(
                self.pattern,
                self.template.format(self.version),
                content,
                flags=re.MULTILINE,
            )
            self.filepath.write_text(new_content, encoding="utf-8")
            logger.info(f"已更新版本号: {self.filepath} -> {self.version}")
        except re.error as e:
            logger.error(f"正则表达式错误: {e}")
            return False
        except OSError as e:
            logger.error(f"更新文本版本号失败: {e}")
            return False
        except UnicodeDecodeError as e:
            logger.error(f"文件编码错误: {e}")
            return False
        else:
            return True


@dataclass
class BumpFileVersionCommand(BaseCommand):
    """文件版本号递增命令.

    读取文件当前版本号, 递增指定部分, 然后更新文件.

    Attributes:
        filepath: 文件路径
        version_part: 版本号部分 (major, minor, patch)
        prerelease: 可选的预发布标识
        read_pattern: 读取版本号的正则表达式 (文本文件用)
        update_template: 更新版本号的模板 (文本文件用)
        version_path: 版本号在TOML中的路径 (TOML文件用)
        old_version: 原版本号
        new_version: 新版本号
    """

    name: str = "bump-file-version"
    description: str = "递增文件中的版本号"
    filepath: Path = Path()
    version_part: str = "patch"
    prerelease: str | None = None
    read_pattern: str = ""
    update_template: str = ""
    version_path: list[str] = field(default_factory=lambda: ["project", "version"])
    old_version: str = ""
    new_version: str = ""

    def run(self) -> bool:
        """执行文件版本号递增.

        Returns
        -------
        bool
            递增成功返回True, 否则返回False
        """
        if not self.filepath.exists():
            logger.warning(f"文件不存在: {self.filepath}")
            return False

        try:
            # 读取当前版本号
            current_version = self._read_version()
            if not current_version:
                return False

            self.old_version = current_version

            # 递增版本号
            bumped_version = self._bump_version(current_version)
            if not bumped_version:
                return False

            self.new_version = bumped_version

            # 更新文件
            if not self._update_version(bumped_version):
                return False

            logger.info(
                f"已更新版本号: {self.filepath} ({self.old_version} -> {self.new_version})",
            )
        except OSError as e:
            logger.error(f"文件操作失败: {e}")
            return False
        except ValueError as e:
            logger.error(f"版本号解析失败: {e}")
            return False
        except Exception as e:  # noqa: BLE001
            logger.error(f"递增文件版本号失败: {e}")
            return False
        else:
            return True

    def _read_version(self) -> str | None:
        """读取当前版本号.

        Returns
        -------
        str | None
            当前版本号, 失败时返回None
        """
        # 判断文件类型 (Cargo.toml 使用文本方式处理)
        if self.filepath.suffix == ".toml" and self.filepath.name != "Cargo.toml":
            return self._read_toml_version()
        else:
            return self._read_text_version()

    def _read_toml_version(self) -> str | None:
        """从TOML文件读取版本号.

        Returns
        -------
        str | None
            版本号, 失败时返回None
        """
        if tomli is None:
            logger.error("未安装tomli或tomllib库")
            return None

        try:
            with self.filepath.open("rb") as f:
                data = tomli.load(f)

            current = data
            for key in self.version_path:
                if key not in current:
                    logger.warning(
                        f"在 {self.filepath} 中未找到版本号路径: {'.'.join(self.version_path)}",
                    )
                    return None
                current = current[key]

            return str(current)
        except OSError as e:
            logger.error(f"读取TOML版本号失败: {e}")
            return None
        except Exception as e:  # noqa: BLE001
            logger.error(f"解析TOML文件失败: {e}")
            return None

    def _read_text_version(self) -> str | None:
        """从文本文件读取版本号.

        Returns
        -------
        str | None
            版本号, 失败时返回None
        """
        if not self.read_pattern:
            logger.error("未提供读取版本号的正则表达式")
            return None

        try:
            content = self.filepath.read_text(encoding="utf-8")
            match = re.search(self.read_pattern, content, re.MULTILINE)
            if not match:
                logger.warning(f"在 {self.filepath} 中未找到版本号")
                return None

            return match.group(1)
        except re.error as e:
            logger.error(f"正则表达式错误: {e}")
            return None
        except OSError as e:
            logger.error(f"读取文本版本号失败: {e}")
            return None
        except UnicodeDecodeError as e:
            logger.error(f"文件编码错误: {e}")
            return None

    def _bump_version(self, version_str: str) -> str | None:
        """递增版本号.

        Parameters
        ----------
        version_str : str
            当前版本号字符串

        Returns
        -------
        str | None
            递增后的版本号, 失败时返回None
        """
        try:
            match = _VERSION_PATTERN.match(version_str)
            if not match:
                logger.error(f"无效的版本号格式: {version_str}")
                return None

            major = int(match.group("major"))
            minor = int(match.group("minor"))
            patch = int(match.group("patch"))

            # 递增指定部分
            if self.version_part == "major":
                major += 1
                minor = 0
                patch = 0
                prerelease = None
            elif self.version_part == "minor":
                minor += 1
                patch = 0
                prerelease = None
            elif self.version_part == "patch":
                patch += 1
                prerelease = None
            else:
                logger.error(f"不支持的版本号部分: {self.version_part}")
                return None

            # 设置预发布标识
            if self.prerelease:
                prerelease: str = self.prerelease

            # 构建新版本号
            new_version = f"{major}.{minor}.{patch}"
            if prerelease:
                new_version += f"-{prerelease}"
        except re.error as e:
            logger.error(f"正则表达式错误: {e}")
            return None
        except ValueError as e:
            logger.error(f"版本号解析失败: {e}")
            return None
        else:
            return new_version

    def _update_version(self, new_version: str) -> bool:
        """更新文件中的版本号.

        Parameters
        ----------
        new_version : str
            新版本号

        Returns
        -------
        bool
            更新成功返回True, 否则返回False
        """
        # 判断文件类型 (Cargo.toml 使用文本方式处理)
        if self.filepath.suffix == ".toml" and self.filepath.name != "Cargo.toml":
            return self._update_toml_version(new_version)
        else:
            return self._update_text_version(new_version)

    def _update_toml_version(self, new_version: str) -> bool:
        """更新TOML文件中的版本号.

        使用文本替换方式, 只更新版本号所在行, 保持其他内容格式不变.

        Parameters
        ----------
        new_version : str
            新版本号

        Returns
        -------
        bool
            更新成功返回True, 否则返回False
        """
        if tomli is None:
            logger.error("未安装tomli或tomllib库")
            return False

        try:
            # 先读取并验证版本号路径
            with self.filepath.open("rb") as f:
                data = tomli.load(f)

            current = data
            for key in self.version_path:
                if key not in current:
                    logger.warning(
                        f"在 {self.filepath} 中未找到版本号路径: {'.'.join(self.version_path)}",
                    )
                    return False
                current = current[key]

            # 使用文本替换方式更新版本号, 保持其他格式不变
            content = self.filepath.read_text(encoding="utf-8")

            # 构建版本号键名 (例如: project.version -> version)
            version_key = self.version_path[-1]

            # 匹配版本号行: version = "1.0.0" 或 version = '1.0.0'
            # 支持行首缩进、等号对齐、不同的引号格式
            # (\s*) 捕获行首缩进
            # ({version_key}) 捕获键名
            # (\s*=\s*) 捕获等号及其前后的空格（保持对齐）
            pattern = rf'^(\s*)({version_key})(\s*=\s*)(["\'])([^"\']+)(\4)'

            def replace_version(match: re.Match) -> str:
                indent = match.group(1)  # 行首缩进
                key = match.group(2)  # 键名 (version)
                equals_spacing = match.group(3)  # 等号及前后空格 (     = )
                quote = match.group(4)  # " 或 '
                return f"{indent}{key}{equals_spacing}{quote}{new_version}{quote}"

            new_content = re.sub(pattern, replace_version, content, flags=re.MULTILINE)

            if new_content == content:
                logger.warning(f"在 {self.filepath} 中未找到版本号行")
                return False

            self.filepath.write_text(new_content, encoding="utf-8")
        except re.error as e:
            logger.error(f"正则表达式错误: {e}")
            return False
        except OSError as e:
            logger.error(f"更新TOML版本号失败: {e}")
            return False
        except UnicodeDecodeError as e:
            logger.error(f"文件编码错误: {e}")
            return False
        else:
            return True

    def _update_text_version(self, new_version: str) -> bool:
        """更新文本文件中的版本号.

        Parameters
        ----------
        new_version : str
            新版本号

        Returns
        -------
        bool
            更新成功返回True, 否则返回False
        """
        if not self.read_pattern:
            logger.error("未提供读取模式")
            return False

        try:
            content = self.filepath.read_text(encoding="utf-8")

            # 如果提供了 update_template, 使用原有逻辑（向后兼容）
            if self.update_template:
                new_content = re.sub(
                    self.read_pattern,
                    self.update_template.format(new_version),
                    content,
                    flags=re.MULTILINE,
                )
            else:
                # 如果没有提供 update_template, 智能替换以保持格式对齐
                # 从 read_pattern 中提取键名（假设是 version）
                # 使用与 _update_toml_version 相同的逻辑保持空格对齐
                # read_pattern 应该是像 ^version\s*=\s*"([^"]+)" 这样的格式
                # 我们需要提取键名
                key_match = re.match(r"^\^?\s*(\w+)", self.read_pattern)
                if not key_match:
                    logger.error("无法从读取模式中提取键名")
                    return False

                version_key = key_match.group(1)
                pattern = rf'^(\s*)({version_key})(\s*=\s*)(["\'])([^"\']+)(\4)'

                def replace_version(match: re.Match) -> str:
                    indent = match.group(1)  # 行首缩进
                    key = match.group(2)  # 键名 (version)
                    equals_spacing = match.group(3)  # 等号及前后空格 (     = )
                    quote = match.group(4)  # " 或 '
                    return f"{indent}{key}{equals_spacing}{quote}{new_version}{quote}"

                new_content = re.sub(
                    pattern,
                    replace_version,
                    content,
                    flags=re.MULTILINE,
                )

            self.filepath.write_text(new_content, encoding="utf-8")
        except re.error as e:
            logger.error(f"正则表达式错误: {e}")
            return False
        except OSError as e:
            logger.error(f"更新文本版本号失败: {e}")
            return False
        except UnicodeDecodeError as e:
            logger.error(f"文件编码错误: {e}")
            return False
        else:
            return True


@dataclass
class BumpProjectVersionCommand(BaseCommand):
    """递增项目版本号命令.

    查找项目中的所有版本文件 (pyproject.toml, __init__.py 等),
    并递增它们的版本号.

    Attributes:
        root_path: 项目根目录路径
        part: 版本号部分 (major, minor, patch)
        prerelease: 可选的预发布标识
        excluded_dirs: 排除的目录名称集合
        exclude_root: 是否排除根目录的 pyproject.toml
        updated_files: 已更新的文件列表
    """

    name: str = "bump-project-version"
    description: str = "递增项目中所有文件的版本号"
    root_path: Path = field(default_factory=Path.cwd)
    part: str = "patch"
    prerelease: str | None = None
    excluded_dirs: set[str] = field(
        default_factory=lambda: {
            "__pycache__",
            ".venv",
            "venv",
            "env",
            ".git",
            "dist",
            "build",
            ".tox",
            ".pytest_cache",
            "node_modules",
        },
    )
    exclude_root: bool = False
    updated_files: list[Path] = field(default_factory=list)

    # 文件类型配置: (文件名, 读取正则, 更新模板)
    FILE_PATTERNS: ClassVar[dict[str, tuple[str, str | None]]] = {
        "__init__.py": (
            r'__version__\s*=\s*["\']([^"\']+)["\']',
            r'__version__ = "{}"',
        ),
        "setup.py": (r'version\s*=\s*["\']([^"\']+)["\']', r'version = "{}"'),
        "package.json": (r'"version"\s*:\s*"([^"]+)"', r'"version": "{}"'),
        # Cargo.toml 不提供 update_template, 使用智能替换保持等号对齐
        "Cargo.toml": (r'^version\s*=\s*"([^"]+)"', None),
    }

    def run(self) -> bool:
        """执行项目版本号递增.

        Returns
        -------
        bool
            递增成功返回True, 否则返回False
        """
        if not self.root_path.exists():
            logger.warning(f"项目目录不存在: {self.root_path}")
            return False

        try:
            # 查找所有需要更新的版本文件
            version_files = self._find_version_files()

            if not version_files:
                logger.warning("未找到任何包含版本号的文件")
                return False

            logger.info(f"找到 {len(version_files)} 个版本文件")

            # 对每个文件执行版本号递增
            success_count = 0
            for filepath in version_files:
                cmd = self._create_bump_command(filepath)
                if cmd.run():
                    self.updated_files.append(filepath)
                    success_count += 1

            logger.info(f"成功更新 {success_count}/{len(version_files)} 个文件")
        except OSError as e:
            logger.error(f"遍历项目目录失败: {e}")
            return False
        except Exception as e:  # noqa: BLE001
            logger.error(f"递增项目版本号失败: {e}")
            return False
        else:
            return success_count > 0

    def _find_version_files(self) -> list[Path]:
        """查找项目中所有包含版本号的文件.

        Returns
        -------
        list[Path]
            版本文件路径列表
        """
        version_files: list[Path] = []

        # 递归遍历目录
        for filepath in self.root_path.rglob("*"):
            # 跳过排除的目录
            if any(excluded in filepath.parts for excluded in self.excluded_dirs):
                continue

            # 跳过非文件
            if not filepath.is_file():
                continue

            # 检查是否是 pyproject.toml
            if filepath.name == "pyproject.toml":
                # 如果排除根目录, 跳过根目录的 pyproject.toml
                if self.exclude_root and filepath.parent == self.root_path:
                    continue
                version_files.append(filepath)

            # 检查其他文件类型
            elif filepath.name in self.FILE_PATTERNS:
                version_files.append(filepath)

        return version_files

    def _create_bump_command(self, filepath: Path) -> BumpFileVersionCommand:
        """为指定文件创建版本号递增命令.

        Parameters
        ----------
        filepath : Path
            文件路径

        Returns
        -------
        BumpFileVersionCommand
            配置好的版本号递增命令对象
        """
        # TOML 文件使用 version_path (Cargo.toml 除外)
        if filepath.suffix == ".toml" and filepath.name != "Cargo.toml":
            return BumpFileVersionCommand(
                filepath=filepath,
                version_part=self.part,
                prerelease=self.prerelease,
                version_path=["project", "version"],
            )

        # 文本文件使用正则表达式
        read_pattern = ""
        update_template: str | None = ""

        for filename, (pattern, template) in self.FILE_PATTERNS.items():
            if filepath.name == filename:
                read_pattern = pattern
                update_template = template
                break

        return BumpFileVersionCommand(
            filepath=filepath,
            version_part=self.part,
            prerelease=self.prerelease,
            read_pattern=read_pattern,
            update_template=update_template or "",
        )


@dataclass
class BumpVersionCommand(BaseCommand):
    """版本号管理命令.

    执行版本号递增并可选地创建 Git 标签和提交.

    Attributes:
        action: 要执行的操作 (patch, minor, major, patch-alpha)
        tag: 是否创建 Git 标签
        commit: 是否提交更改到 Git
        part: 版本号部分 (major, minor, patch)
        prerelease: 可选的预发布标识
        root_path: 项目根目录路径
    """

    name: str = "bumpversion"
    description: str = "版本号自动管理工具 (支持语义化版本和多文件格式)"
    action: str = "patch"
    tag: bool = False
    commit: bool = False
    part: str = "patch"
    prerelease: str | None = None
    root_path: Path = field(default_factory=Path.cwd)

    def run(self) -> bool:
        """执行版本号管理命令.

        Returns
        -------
        bool
            执行成功返回True, 否则返回False
        """
        try:
            # 创建版本号递增命令
            bump_cmd = BumpProjectVersionCommand(
                root_path=self.root_path,
                part=self.part,
                prerelease=self.prerelease,
            )

            # 执行版本号递增
            success = bump_cmd.run()
            if not success:
                logger.error("版本号递增失败")
                return False

            # 如果指定了 tag 或 commit，执行 Git 操作
            if self.tag or self.commit:
                # 从第一个更新的文件中读取新版本号
                if not bump_cmd.updated_files:
                    logger.warning("未找到更新的版本文件，跳过 Git 操作")
                    return True

                first_file = bump_cmd.updated_files[0]
                new_version = self._read_version_from_file(first_file)
                if not new_version:
                    logger.warning("未能读取到新版本号，跳过 Git 操作")
                    return True

                logger.info(f"检测到新版本号: {new_version}")

                # 创建 git tag（如果指定）
                if self.tag:
                    tag_cmd = GitTagCommand(
                        tag_name=f"v{new_version}",
                        message=f"Release {new_version}",
                    )
                    tag_cmd.validate_and_run()

                # 提交更改（如果指定）
                if self.commit:
                    commit_cmd = GitCommitCommand(
                        message=f"chore: bump version to {new_version}",
                    )
                    commit_cmd.validate_and_run()

        except KeyboardInterrupt:
            logger.info("操作已取消")
            return False
        except OSError as e:
            logger.error(f"文件操作失败: {e}")
            return False
        except Exception as e:  # noqa: BLE001
            logger.error(f"{self.name} 执行失败: {e}")
            return False
        else:
            return True

    def _read_version_from_file(self, filepath: Path) -> str | None:
        """从版本文件中读取当前版本号.

        Parameters
        ----------
        filepath : Path
            版本文件路径

        Returns
        -------
        str | None
            版本号，读取失败时返回 None
        """
        from .version import BumpFileVersionCommand

        # 创建临时命令来读取版本号（不执行递增）
        temp_bump_cmd = BumpFileVersionCommand(filepath=filepath)
        return temp_bump_cmd._read_version()
