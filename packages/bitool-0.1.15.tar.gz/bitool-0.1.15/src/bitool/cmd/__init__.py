"""  Init  .Py src tools."""

from bitool.utils import RunResult, execute

from ._base import BaseCommand
from ._condition import BuiltinConditions, Condition
from ._scheduler import CommandResult, CommandScheduler, SchedulerMetrics
from .compile import CompileCommand
from .env import SetEnvCommand
from .git import GitAddCommand, GitCommitCommand, GitTagCommand
from .io import (
    BackupFileCommand,
    CopyFileCommand,
    DeleteFileCommand,
    FileTreeCopyCommand,
    MoveFileCommand,
    ReadFileCommand,
    WriteFileCommand,
    backup_file,
    ensure_dir_exists,
    read_file_content,
    write_file_content,
)
from .pdf import (
    CompressPdfCommand,
    ImagesToPdfCommand,
    MergePdfsCommand,
    PdfToImagesCommand,
    SplitPdfCommand,
)
from .run import RunCommand, RunShellCommand
from .toml import ReadTomlCommand, WriteTomlCommand
from .version import (
    BumpFileVersionCommand,
    BumpProjectVersionCommand,
    BumpVersionCommand,
    ReadTextVersionCommand,
    UpdateTextVersionCommand,
)

__all__ = [
    # 文件操作命令和工具函数
    "BackupFileCommand",
    # 基础类
    "BaseCommand",
    "BuiltinConditions",
    # 版本命令(推荐使用)
    "BumpFileVersionCommand",
    "BumpProjectVersionCommand",
    "BumpVersionCommand",
    # 调度器
    "CommandResult",
    "CommandScheduler",
    # 编译命令
    "CompileCommand",
    # PDF命令
    "CompressPdfCommand",
    "Condition",
    "CopyFileCommand",
    "DeleteFileCommand",
    "FileTreeCopyCommand",
    # Git命令
    "GitAddCommand",
    "GitCommitCommand",
    "GitTagCommand",
    "ImagesToPdfCommand",
    "MergePdfsCommand",
    "MoveFileCommand",
    "PdfToImagesCommand",
    "ReadFileCommand",
    "ReadTextVersionCommand",
    # TOML命令
    "ReadTomlCommand",
    # 运行命令
    "RunCommand",
    "RunResult",
    "RunShellCommand",
    "SchedulerMetrics",
    # 环境命令
    "SetEnvCommand",
    "SplitPdfCommand",
    "UpdateTextVersionCommand",
    "WriteFileCommand",
    "WriteTomlCommand",
    "backup_file",
    "ensure_dir_exists",
    "execute",
    "read_file_content",
    "write_file_content",
]