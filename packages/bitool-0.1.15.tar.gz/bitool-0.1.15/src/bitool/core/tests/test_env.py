"""测试环境变量管理器模块."""

from __future__ import annotations

import os

import pytest

from bitool.core.env import EnvironmentManager, EnvironVar


class TestEnvironVar:
    """测试 EnvironVar 数据类."""

    def test_create_valid_env_var(self) -> None:
        """测试创建有效的环境变量."""
        var = EnvironVar(name="TEST_VAR", value="test_value")
        assert var.name == "TEST_VAR"
        assert var.value == "test_value"
        assert var.description == ""
        assert var.is_persistent is False

    def test_create_env_var_with_description(self) -> None:
        """测试创建带描述的环境变量."""
        var = EnvironVar(
            name="TEST_VAR",
            value="test_value",
            description="A test variable",
            is_persistent=True,
        )
        assert var.description == "A test variable"
        assert var.is_persistent is True

    def test_invalid_env_var_name_empty(self) -> None:
        """测试空名称抛出异常."""
        with pytest.raises(ValueError, match="环境变量名称不能为空"):
            EnvironVar(name="", value="test_value")

    def test_invalid_env_var_name_format(self) -> None:
        """测试无效格式名称抛出异常."""
        with pytest.raises(ValueError, match="环境变量名称格式无效"):
            EnvironVar(name="123INVALID", value="test_value")

        with pytest.raises(ValueError, match="环境变量名称格式无效"):
            EnvironVar(name="INVALID-NAME", value="test_value")

    def test_valid_env_var_names(self) -> None:
        """测试有效的环境变量名称."""
        valid_names = ["VAR", "_VAR", "VAR123", "MY_VAR_NAME"]
        for name in valid_names:
            var = EnvironVar(name=name, value="test")
            assert var.name == name


class TestEnvironmentManager:
    """测试 EnvironmentManager 类."""

    def setup_method(self) -> None:
        """每个测试方法前清理测试环境变量."""
        # 清理可能存在的环境变量
        for var_name in ["TEST_VAR_1", "TEST_VAR_2", "TEST_PERSISTENT", "TEST_TEMP"]:
            if var_name in os.environ:
                del os.environ[var_name]

    def test_set_and_get_env_var(self) -> None:
        """测试设置和获取环境变量."""
        manager = EnvironmentManager()
        manager.set("TEST_VAR_1", "value1")

        assert manager.get("TEST_VAR_1") == "value1"
        assert os.environ.get("TEST_VAR_1") == "value1"

    def test_get_nonexistent_env_var(self) -> None:
        """测试获取不存在的环境变量."""
        manager = EnvironmentManager()
        result = manager.get("NONEXISTENT_VAR")
        assert result is None

    def test_get_with_default(self) -> None:
        """测试获取环境变量带默认值."""
        manager = EnvironmentManager()
        result = manager.get("NONEXISTENT_VAR", "default_value")
        assert result == "default_value"

    def test_set_persistent_env_var(self) -> None:
        """测试设置持久化环境变量."""
        manager = EnvironmentManager()
        manager.set("TEST_PERSISTENT", "persistent_value", persistent=True)

        assert manager.get("TEST_PERSISTENT") == "persistent_value"
        assert "TEST_PERSISTENT" in manager.list_persistent()
        assert "TEST_PERSISTENT" not in manager.list_temp()

    def test_set_temp_env_var(self) -> None:
        """测试设置临时环境变量."""
        manager = EnvironmentManager()
        manager.set("TEST_TEMP", "temp_value", persistent=False)

        assert manager.get("TEST_TEMP") == "temp_value"
        assert "TEST_TEMP" in manager.list_temp()
        assert "TEST_TEMP" not in manager.list_persistent()

    def test_unset_env_var(self) -> None:
        """测试删除环境变量."""
        manager = EnvironmentManager()
        manager.set("TEST_VAR_1", "value1")
        assert manager.has_var("TEST_VAR_1")

        result = manager.unset("TEST_VAR_1")
        assert result is True
        assert not manager.has_var("TEST_VAR_1")

    def test_unset_nonexistent_env_var(self) -> None:
        """测试删除不存在的环境变量."""
        manager = EnvironmentManager()
        result = manager.unset("NONEXISTENT_VAR")
        assert result is False

    def test_unset_persistent_env_var(self) -> None:
        """测试删除持久化环境变量."""
        manager = EnvironmentManager()
        manager.set("TEST_PERSISTENT", "value", persistent=True)
        assert "TEST_PERSISTENT" in manager.list_persistent()

        # 删除但不移除持久化存储
        manager.unset("TEST_PERSISTENT", remove_persistent=False)
        assert not manager.has_var("TEST_PERSISTENT")  # 从系统环境变量中删除
        assert "TEST_PERSISTENT" in manager.list_persistent()  # 仍在持久化存储中

        # 删除并移除持久化存储
        manager.unset("TEST_PERSISTENT", remove_persistent=True)
        assert "TEST_PERSISTENT" not in manager.list_persistent()

    def test_list_vars(self) -> None:
        """测试列出环境变量."""
        manager = EnvironmentManager()
        manager.set("TEST_VAR_1", "value1")
        manager.set("TEST_VAR_2", "value2")

        all_vars = manager.list_vars()
        assert "TEST_VAR_1" in all_vars
        assert "TEST_VAR_2" in all_vars

    def test_list_vars_with_pattern(self) -> None:
        """测试按模式列出环境变量."""
        manager = EnvironmentManager()
        manager.set("TEST_VAR_1", "value1")
        manager.set("OTHER_VAR", "other_value")

        test_vars = manager.list_vars(pattern="TEST")
        assert "TEST_VAR_1" in test_vars
        assert "OTHER_VAR" not in test_vars

    def test_has_var(self) -> None:
        """测试检查环境变量是否存在."""
        manager = EnvironmentManager()
        manager.set("TEST_VAR_1", "value1")

        assert manager.has_var("TEST_VAR_1") is True
        assert manager.has_var("NONEXISTENT") is False

    def test_contains_magic_method(self) -> None:
        """测试 __contains__ 魔术方法."""
        manager = EnvironmentManager()
        manager.set("TEST_VAR_1", "value1")

        assert "TEST_VAR_1" in manager
        assert "NONEXISTENT" not in manager

    def test_getitem_magic_method(self) -> None:
        """测试 __getitem__ 魔术方法."""
        manager = EnvironmentManager()
        manager.set("TEST_VAR_1", "value1")

        assert manager["TEST_VAR_1"] == "value1"

        with pytest.raises(KeyError, match="环境变量 NONEXISTENT 不存在"):
            _ = manager["NONEXISTENT"]

    def test_setitem_magic_method(self) -> None:
        """测试 __setitem__ 魔术方法."""
        manager = EnvironmentManager()
        manager["TEST_VAR_1"] = "value1"

        assert manager.get("TEST_VAR_1") == "value1"

    def test_delitem_magic_method(self) -> None:
        """测试 __delitem__ 魔术方法."""
        manager = EnvironmentManager()
        manager.set("TEST_VAR_1", "value1")

        del manager["TEST_VAR_1"]
        assert not manager.has_var("TEST_VAR_1")

        with pytest.raises(KeyError, match="环境变量 NONEXISTENT 不存在"):
            del manager["NONEXISTENT"]

    def test_clear_temp(self) -> None:
        """测试清除临时环境变量."""
        manager = EnvironmentManager()
        manager.set("TEST_TEMP", "temp_value", persistent=False)
        manager.set("TEST_PERSISTENT", "persistent_value", persistent=True)

        manager.clear_temp()

        assert not manager.has_var("TEST_TEMP")
        assert manager.has_var("TEST_PERSISTENT")  # 持久化变量不受影响

    def test_clear_all(self) -> None:
        """测试清除所有环境变量."""
        manager = EnvironmentManager()
        manager.set("TEST_TEMP", "temp_value", persistent=False)
        manager.set("TEST_PERSISTENT", "persistent_value", persistent=True)

        manager.clear_all()

        assert not manager.has_var("TEST_TEMP")
        assert not manager.has_var("TEST_PERSISTENT")
        assert len(manager.list_temp()) == 0
        assert len(manager.list_persistent()) == 0

    def test_expand_vars_braced_format(self) -> None:
        """测试展开 ${VAR} 格式的环境变量."""
        manager = EnvironmentManager()
        manager.set("TEST_VAR", "replaced_value")

        text = "Hello ${TEST_VAR}!"
        result = manager.expand_vars(text)
        assert result == "Hello replaced_value!"

    def test_expand_vars_simple_format(self) -> None:
        """测试展开 $VAR 格式的环境变量."""
        manager = EnvironmentManager()
        manager.set("TEST_VAR", "replaced_value")

        text = "Hello $TEST_VAR!"
        result = manager.expand_vars(text)
        assert result == "Hello replaced_value!"

    def test_expand_vars_undefined_var(self) -> None:
        """测试展开未定义的环境变量保持原样."""
        manager = EnvironmentManager()

        text = "Hello ${UNDEFINED_VAR}!"
        result = manager.expand_vars(text)
        assert result == "Hello ${UNDEFINED_VAR}!"

    def test_check_enabled_true(self) -> None:
        """测试检查启用状态为True."""
        manager = EnvironmentManager()
        for val in ["1", "true", "yes", "on", "enabled", "TRUE", "Yes"]:
            manager.set("TEST_ENABLED", val)
            assert manager.check_enabled("TEST_ENABLED") is True

    def test_check_enabled_false(self) -> None:
        """测试检查启用状态为False."""
        manager = EnvironmentManager()
        for val in ["0", "false", "no", "off", "disabled", "FALSE", "No"]:
            manager.set("TEST_ENABLED", val)
            assert manager.check_enabled("TEST_ENABLED") is False

    def test_set_multiple(self) -> None:
        """测试批量设置环境变量."""
        manager = EnvironmentManager()
        vars_dict = {"TEST_VAR_1": "value1", "TEST_VAR_2": "value2"}
        manager.set_multiple(vars_dict, persistent=True)

        assert manager.get("TEST_VAR_1") == "value1"
        assert manager.get("TEST_VAR_2") == "value2"
        assert len(manager.list_persistent()) == 2

    def test_from_dict(self) -> None:
        """测试从字典设置环境变量."""
        manager = EnvironmentManager()
        vars_dict = {"TEST_VAR_1": "value1", "TEST_VAR_2": "value2"}
        manager.from_dict(vars_dict)

        assert manager.get("TEST_VAR_1") == "value1"
        assert manager.get("TEST_VAR_2") == "value2"
        # from_dict 应该创建临时变量
        assert len(manager.list_temp()) == 2

    def test_to_dict(self) -> None:
        """测试导出环境变量为字典."""
        manager = EnvironmentManager()
        manager.set("TEST_PERSISTENT", "persistent_value", persistent=True)
        manager.set("TEST_TEMP", "temp_value", persistent=False)

        result = manager.to_dict()
        assert result["TEST_PERSISTENT"] == "persistent_value"
        assert result["TEST_TEMP"] == "temp_value"

    def test_get_var_info(self) -> None:
        """测试获取环境变量详细信息."""
        manager = EnvironmentManager()
        manager.set(
            "TEST_VAR",
            "value",
            persistent=True,
            description="Test description",
        )

        info = manager.get_var_info("TEST_VAR")
        assert info is not None
        assert info.name == "TEST_VAR"
        assert info.value == "value"
        assert info.description == "Test description"
        assert info.is_persistent is True

    def test_repr(self) -> None:
        """测试 __repr__ 方法."""
        manager = EnvironmentManager()
        manager.set("TEST_PERSISTENT", "value", persistent=True)
        manager.set("TEST_TEMP", "value", persistent=False)

        repr_str = repr(manager)
        assert "persistent=1" in repr_str
        assert "temp=1" in repr_str
