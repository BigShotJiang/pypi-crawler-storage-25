"""日志模块线程安全测试."""

from __future__ import annotations

import threading
import time
from pathlib import Path


class TestThreadSafeLogging:
    """线程安全日志测试类."""

    def test_concurrent_log_writes(self, tmp_path: Path) -> None:
        """测试多线程并发写入日志."""
        import logging

        from bitool.core.logger import _Logger, _MultiProcessSafeRotatingFileHandler

        # 创建测试用的日志器
        test_log_file = tmp_path / "test_thread_safe.log"

        # 清理可能存在的旧日志器
        test_logger_name = "test_thread_safe_logger"
        old_logger = logging.getLogger(test_logger_name)
        for handler in old_logger.handlers[:]:
            old_logger.removeHandler(handler)

        # 创建新的日志器实例
        _Logger._instance = None
        _Logger._is_setup = False

        # 手动设置日志器使用线程安全处理器
        test_logger = logging.getLogger(test_logger_name)
        test_logger.setLevel(logging.DEBUG)

        # 添加线程安全的文件处理器
        file_handler = _MultiProcessSafeRotatingFileHandler(
            test_log_file,
            maxBytes=1024,  # 设置较小的值以触发轮转
            backupCount=3,
            encoding="utf-8",
        )
        file_handler.setLevel(logging.DEBUG)
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        )
        file_handler.setFormatter(formatter)
        test_logger.addHandler(file_handler)

        # 多线程并发写入
        error_list: list[str] = []

        def write_logs(thread_id: int, count: int) -> None:
            """写入日志的函数."""
            try:
                for i in range(count):
                    test_logger.info(f"线程 {thread_id} - 消息 {i}")
                    time.sleep(0.001)  # 短暂休眠增加并发冲突概率
            except Exception as e:  # noqa: BLE001
                # 测试中需要捕获所有异常来验证线程安全性
                error_list.append(f"线程 {thread_id} 异常: {e}")

        # 启动多个线程
        threads = []
        thread_count = 10
        messages_per_thread = 50

        for thread_id in range(thread_count):
            thread = threading.Thread(
                target=write_logs,
                args=(thread_id, messages_per_thread),
            )
            threads.append(thread)
            thread.start()

        # 等待所有线程完成
        for thread in threads:
            thread.join(timeout=10)

        # 验证没有错误（这是关键，说明线程安全）
        assert len(error_list) == 0, f"线程执行出现错误: {error_list}"

        # 验证日志文件存在（主文件或至少一个备份文件）
        has_log_file = test_log_file.exists()
        has_backup = any(
            (tmp_path / f"test_thread_safe.log.{i}").exists() for i in range(1, 5)
        )
        assert has_log_file or has_backup, "应该至少有一个日志文件"

        # 统计所有日志文件中的日志条数
        log_content = ""

        # 读取主日志文件
        if test_log_file.exists():
            log_content += test_log_file.read_text(encoding="utf-8")

        # 读取所有备份文件
        for i in range(1, 10):  # 最多检查10个备份
            backup_file = tmp_path / f"test_thread_safe.log.{i}"
            if backup_file.exists():
                log_content += backup_file.read_text(encoding="utf-8")
            else:
                break  # 备份文件是连续的，遇到不存在的就停止

        # 验证日志条数
        log_lines = [
            line
            for line in log_content.split("\n")
            if "线程" in line and "消息" in line
        ]
        total_messages = thread_count * messages_per_thread

        # 关键验证：没有线程安全错误（已通过上面的 error_list 验证）
        # 日志条数应该接近预期值（允许少量丢失，因为并发写入时可能有极少量覆盖）
        # 但主要验证的是不抛出 PermissionError 异常
        assert len(log_lines) > 0, "应该有日志记录"
        assert len(log_lines) <= total_messages, (
            f"日志条数不应超过预期: {len(log_lines)} > {total_messages}"
        )

    def test_rapid_rollover(self, tmp_path: Path) -> None:
        """测试快速触发日志轮转的线程安全性."""
        import logging

        from bitool.core.logger import _MultiProcessSafeRotatingFileHandler

        test_log_file = tmp_path / "test_rollover.log"

        # 创建日志器
        test_logger = logging.getLogger("test_rollover_logger")
        for handler in test_logger.handlers[:]:
            test_logger.removeHandler(handler)
        test_logger.setLevel(logging.DEBUG)

        # 使用非常小的 maxBytes 频繁触发轮转
        file_handler = _MultiProcessSafeRotatingFileHandler(
            test_log_file,
            maxBytes=512,  # 非常小, 频繁轮转
            backupCount=5,
            encoding="utf-8",
        )
        file_handler.setLevel(logging.DEBUG)
        test_logger.addHandler(file_handler)

        errors: list[str] = []

        def rapid_logging(thread_id: int) -> None:
            """快速写入日志."""
            try:
                for i in range(100):
                    test_logger.info(
                        f"线程 {thread_id} - 长消息 " + "x" * 50 + f" - {i}",
                    )
            except Exception as e:  # noqa: BLE001
                # 测试中需要捕获所有异常来验证线程安全性
                errors.append(f"线程 {thread_id} 异常: {e}")

        # 启动并发线程
        threads = []
        for i in range(5):
            t = threading.Thread(target=rapid_logging, args=(i,))
            threads.append(t)
            t.start()

        for t in threads:
            t.join(timeout=10)

        # 验证没有错误
        assert len(errors) == 0, f"快速轮转测试失败: {errors}"

        # 验证备份文件创建成功
        backup_files = list(tmp_path.glob("test_rollover.log.*"))
        assert len(backup_files) > 0, "应该创建备份文件"
