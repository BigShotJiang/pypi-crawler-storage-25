"""环境变量管理器."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field

_ENABLE_TAGS: set[str] = {"1", "true", "yes", "on", "enabled"}


@dataclass
class EnvironVar:
    """环境变量数据类."""

    name: str
    value: str
    description: str = ""
    is_persistent: bool = False

    def __post_init__(self) -> None:
        """验证环境变量名称格式."""
        if not self.name:
            msg = "环境变量名称不能为空"
            raise ValueError(msg)
        if not re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", self.name):
            msg = f"环境变量名称格式无效: {self.name}"
            raise ValueError(msg)


@dataclass
class EnvironmentManager:
    """环境变量管理器.

    提供环境变量的设置、获取、删除、持久化等操作.
    支持临时环境变量和持久化环境变量管理.
    """

    _persistent_vars: dict[str, EnvironVar] = field(default_factory=dict)
    _temp_vars: dict[str, EnvironVar] = field(default_factory=dict)

    def set(
        self,
        name: str,
        value: str,
        *,
        persistent: bool = False,
        description: str = "",
    ) -> None:
        """设置环境变量.

        Args:
            name: 环境变量名称
            value: 环境变量值
            persistent: 是否持久化保存
            description: 环境变量描述信息
        """
        env_var = EnvironVar(
            name=name,
            value=value,
            description=description,
            is_persistent=persistent,
        )

        # 设置到操作系统环境变量中
        os.environ[name] = value

        # 根据持久化标志存储到不同字典中
        if persistent:
            self._persistent_vars[name] = env_var
        else:
            self._temp_vars[name] = env_var

    def get(self, name: str, default: str | None = None) -> str | None:
        """获取环境变量值.

        Args:
            name: 环境变量名称
            default: 默认值（如果环境变量不存在）

        Returns:
            环境变量值或默认值
        """
        return os.environ.get(name, default)

    def get_var_info(self, name: str) -> EnvironVar | None:
        """获取环境变量详细信息.

        Args:
            name: 环境变量名称

        Returns:
            环境变量对象，如果不存在则返回None
        """
        # 先查找持久化变量，再查找临时变量
        if name in self._persistent_vars:
            return self._persistent_vars[name]
        if name in self._temp_vars:
            return self._temp_vars[name]

        # 如果都不存在，但系统环境变量中有，则创建一个临时对象
        if name in os.environ:
            return EnvironVar(name=name, value=os.environ[name])

        return None

    def unset(self, name: str, *, remove_persistent: bool = False) -> bool:
        """删除环境变量.

        Args:
            name: 环境变量名称
            remove_persistent: 是否同时从持久化存储中删除

        Returns:
            是否成功删除（环境变量存在时才返回True）
        """
        removed = False

        # 从系统环境变量中删除
        if name in os.environ:
            del os.environ[name]
            removed = True

        # 从临时变量中删除
        if name in self._temp_vars:
            del self._temp_vars[name]
            removed = True

        # 从持久化变量中删除（如果需要）
        if remove_persistent and name in self._persistent_vars:
            del self._persistent_vars[name]
            removed = True

        return removed

    def list_vars(self, pattern: str | None = None) -> dict[str, str]:
        """列出环境变量.

        Args:
            pattern: 过滤模式，只返回名称匹配此模式的环境变量

        Returns:
            环境变量名称到值的映射字典
        """
        envs = dict(os.environ)

        if pattern:
            # 使用正则表达式进行模式匹配（不区分大小写）
            try:
                regex = re.compile(pattern, re.IGNORECASE)
                envs = {k: v for k, v in envs.items() if regex.search(k)}
            except re.error:
                # 如果正则表达式无效，则进行简单的字符串包含匹配
                pattern_lower = pattern.lower()
                envs = {k: v for k, v in envs.items() if pattern_lower in k.lower()}

        return envs

    def list_persistent(self) -> dict[str, EnvironVar]:
        """列出所有持久化的环境变量.

        Returns:
            持久化环境变量名称到环境变量对象的映射字典
        """
        return self._persistent_vars.copy()

    def list_temp(self) -> dict[str, EnvironVar]:
        """列出所有临时环境变量.

        Returns:
            临时环境变量名称到环境变量对象的映射字典
        """
        return self._temp_vars.copy()

    def clear_temp(self) -> None:
        """清除所有临时环境变量."""
        # 从系统环境变量中删除临时变量
        for name in list(self._temp_vars.keys()):
            if name in os.environ:
                del os.environ[name]

        # 清空临时变量字典
        self._temp_vars.clear()

    def clear_all(self) -> None:
        """清除所有环境变量（包括持久化和临时的）."""
        # 清除临时变量（会从系统环境变量中删除）
        self.clear_temp()

        # 从系统环境变量中删除持久化变量
        for name in list(self._persistent_vars.keys()):
            if name in os.environ:
                del os.environ[name]

        # 清空持久化变量字典
        self._persistent_vars.clear()

    def has_var(self, name: str) -> bool:
        """检查环境变量是否存在.

        Args:
            name: 环境变量名称

        Returns:
            环境变量是否存在
        """
        return name in os.environ

    def expand_vars(self, text: str) -> str:
        """展开文本中的环境变量引用.

        支持两种格式：
        - ${VAR_NAME} 格式
        - $VAR_NAME 格式

        Args:
            text: 包含环境变量引用的文本

        Returns:
            展开后的文本（未定义的环境变量保持原样）
        """

        # 处理 ${VAR_NAME} 格式
        def replace_braced_var(match: re.Match[str]) -> str:
            var_name = match.group(1)
            return os.environ.get(var_name, match.group(0))

        result = re.sub(r"\$\{([^}]+)\}", replace_braced_var, text)

        # 处理 $VAR_NAME 格式（不在花括号中的）
        def replace_simple_var(match: re.Match[str]) -> str:
            var_name = match.group(1)
            return os.environ.get(var_name, match.group(0))

        result = re.sub(r"\$([a-zA-Z_][a-zA-Z0-9_]*)", replace_simple_var, result)

        return result

    def check_enabled(self, name: str) -> bool:
        """检查环境变量是否表示启用状态.

        Args:
            name: 环境变量名称

        Returns:
            如果环境变量值为启用标记则返回True，否则返回False
        """
        value = os.getenv(name, "0").strip().lower()
        return value in _ENABLE_TAGS

    def set_multiple(
        self,
        vars_dict: dict[str, str],
        *,
        persistent: bool = False,
    ) -> None:
        """批量设置环境变量.

        Args:
            vars_dict: 环境变量名称到值的映射字典
            persistent: 是否持久化保存
        """
        for name, value in vars_dict.items():
            self.set(name, value, persistent=persistent)

    def from_dict(self, vars_dict: dict[str, str]) -> None:
        """从字典批量设置环境变量（不持久化）.

        Args:
            vars_dict: 环境变量名称到值的映射字典
        """
        self.set_multiple(vars_dict, persistent=False)

    def to_dict(
        self,
        *,
        include_persistent: bool = True,
        include_temp: bool = True,
    ) -> dict[str, str]:
        """将环境变量导出为字典.

        Args:
            include_persistent: 是否包含持久化环境变量
            include_temp: 是否包含临时环境变量

        Returns:
            环境变量名称到值的映射字典
        """
        result: dict[str, str] = {}

        if include_persistent:
            for name, var in self._persistent_vars.items():
                result[name] = var.value

        if include_temp:
            for name, var in self._temp_vars.items():
                result[name] = var.value

        return result

    def __contains__(self, name: str) -> bool:
        """检查环境变量是否存在."""
        return self.has_var(name)

    def __getitem__(self, name: str) -> str:
        """获取环境变量值."""
        value = self.get(name)
        if value is None:
            msg = f"环境变量 {name} 不存在"
            raise KeyError(msg)
        return value

    def __setitem__(self, name: str, value: str) -> None:
        """设置环境变量（临时）."""
        self.set(name, value, persistent=False)

    def __delitem__(self, name: str) -> None:
        """删除环境变量."""
        if not self.unset(name):
            msg = f"环境变量 {name} 不存在"
            raise KeyError(msg)

    def __repr__(self) -> str:
        """返回环境管理器表示."""
        persistent_count = len(self._persistent_vars)
        temp_count = len(self._temp_vars)
        return f"EnvironmentManager(persistent={persistent_count}, temp={temp_count})"


_manager = EnvironmentManager()
getenv = _manager.get
setenv = _manager.set
checkenv = _manager.check_enabled
