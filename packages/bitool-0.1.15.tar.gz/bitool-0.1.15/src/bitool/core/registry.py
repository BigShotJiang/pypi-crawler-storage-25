"""通用注册表 - Pytola 的通用注册系统.

本模块提供了一个灵活的、类型安全的注册表系统,用于管理
类和组件.它支持多个独立的注册表,不依赖于任何特定模块.

使用示例:
    # 创建模块特定的注册表
    my_registry = Registry("my_module")

    # 注册一个类
    my_registry.register("build", BuildClass, aliases=["b"])

    # 或使用装饰器
    @register("my_module", name="build", aliases=["b"])
    class BuildClass:
        pass

    # 获取已注册的类
    cls = my_registry.get("build")
"""

from __future__ import annotations

import threading
from typing import Any, Callable, ClassVar, Generic, TypeVar

from .logger import logger

__all__ = ["DefaultRegistry", "Registry", "get_registry", "register"]

T = TypeVar("T")


MAX_REGISTRY_NAME_LENGTH = 64


def _validate_registration_name(name: str) -> None:
    """验证注册名称.

    Args:
        name: 要验证的名称

    Raises
    ------
        ValueError: 如果名称为空或超过最大长度
    """
    if not name:
        msg = "注册名称不能为空"
        raise ValueError(msg)
    if len(name) > MAX_REGISTRY_NAME_LENGTH:
        msg = f"注册名称 '{name}' 超过最大长度 {MAX_REGISTRY_NAME_LENGTH}"
        raise ValueError(msg)


def _validate_aliases(aliases: list[str]) -> None:
    """验证别名列表.

    Args:
        aliases: 要验证的别名列表

    Raises
    ------
        ValueError: 如果任何别名为空或超过最大长度
    """
    for alias in aliases:
        if not alias:
            msg = "别名不能为空字符串"
            raise ValueError(msg)
        if len(alias) > MAX_REGISTRY_NAME_LENGTH:
            msg = f"别名 '{alias}' 超过最大长度 {MAX_REGISTRY_NAME_LENGTH}"
            raise ValueError(msg)


class Registry(Generic[T]):
    """用于类注册的通用注册表.

    每个注册表实例都是独立的,通过唯一名称标识.
    这允许不同的模块拥有自己独立的注册表,
    同时共享相同的基础实现.

    Attributes
    ----------
        name: 此注册表的唯一标识符

    示例:
        # 为不同模块创建注册表
        command_registry = Registry[BaseCommand]("commands")
        plugin_registry = Registry[PluginBase]("plugins")

        # 在各自注册表中注册项
        command_registry.register("build", BuildCommand)
        plugin_registry.register("logger", LoggerPlugin)
    """

    _registries: ClassVar[dict[str, Registry]] = {}
    _lock: ClassVar[threading.Lock] = threading.Lock()

    def __new__(cls, name: str) -> Registry[T]:
        """获取或创建命名注册表实例.

        Args:
            name: 注册表的唯一标识符

        Returns
        -------
            注册表实例(如果不存在则创建新的)
        """
        with cls._lock:
            if name not in cls._registries:
                instance = super().__new__(cls)
                instance._name = name
                instance._initialized = False

                cls._registries[name] = instance
            return cls._registries[name]

    def __init__(self, name: str) -> None:
        """初始化注册表(如果尚未初始化)."""
        # 注意: _initialized 在 __new__ 中返回实例前已设置
        # 因此我们可以安全地在这里检查.不需要锁,因为:
        # 1. __new__ 在创建实例时持有锁
        # 2. __new__ 在返回前设置 _initialized=False
        # 3. 此方法是幂等的 - 多次调用是安全的
        if getattr(self, "_initialized", False):
            return

        # 此时我们知道 _initialized 是 False
        # 我们需要获取锁以防止竞争条件
        with self._lock:
            # 双重检查模式:另一个线程可能在我们等待锁时已完成初始化
            if getattr(self, "_initialized", False):
                return

            self._name = name
            self._items: dict[str, type[T]] = {}
            self._aliases: dict[str, str] = {}
            self._metadata: dict[str, dict[str, Any]] = {}
            self._initialized = True
            logger.debug(f"Registry '{name}' initialized")

    @property
    def name(self) -> str:
        """获取注册表名称."""
        return self._name

    def register(
        self,
        name: str,
        item_class: type[T],
        aliases: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """注册一个类.

        Args:
            name: 项的标准名称
            item_class: 要注册的类
            aliases: 可选的短名称/别名列表
            metadata: 可选的元数据字典

        Raises
        ------
            ValueError: 如果名称超过最大长度
        """
        # 验证输入
        _validate_registration_name(name)
        if aliases:
            _validate_aliases(aliases)

        # 检查是否已注册
        if name in self._items:
            logger.warning(f"项 '{name}' 已在 '{self._name}' 中注册.将覆盖.")

        # 注册项
        self._items[name] = item_class
        self._metadata[name] = metadata or {}

        # 注册别名
        if aliases:
            self._register_aliases(aliases, name)

        logger.debug(f"Registered item '{name}' in '{self._name}'")

    def _register_aliases(self, aliases: list[str], name: str) -> None:
        """为项注册别名.

        Args:
            aliases: 要注册的别名列表
            name: 这些别名指向的标准名称
        """
        for alias in aliases:
            if alias in self._aliases:
                logger.warning(f"别名 '{alias}' 已在 '{self._name}' 中注册.将覆盖.")
            self._aliases[alias] = name
            logger.debug(f"注册别名 '{alias}' -> '{name}' in '{self._name}'")

    def unregister(self, name: str) -> None:
        """注销项.

        Args:
            name: 要移除的项的标准名称
        """
        if name not in self._items:
            logger.warning(f"尝试注销不存在的项 '{name}' in '{self._name}'")
            return

        del self._items[name]

        # 移除关联的别名 - 优化的单次遍历
        for alias in list(self._aliases.keys()):
            if self._aliases[alias] == name:
                del self._aliases[alias]

        if name in self._metadata:
            del self._metadata[name]

        logger.info(f"Unregistered item '{name}' from '{self._name}'")

    def get(self, name_or_alias: str) -> type[T] | None:
        """通过名称或别名获取已注册的类.

        Args:
            name_or_alias: 标准名称或别名

        Returns
        -------
            已注册的类,如果未找到则返回 None
        """
        canonical_name = self._aliases.get(name_or_alias, name_or_alias)
        item_class = self._items.get(canonical_name)
        if item_class is None:
            logger.debug(f"Item '{name_or_alias}' not found in registry '{self._name}'")
        return item_class

    def get_instance(
        self,
        name_or_alias: str,
        *args: object,
        **kwargs: object,
    ) -> T | None:
        """获取已注册类的实例.

        Args:
            name_or_alias: 标准名称或别名
            *args: 位置参数用于实例化
            **kwargs: 关键字参数用于实例化

        Returns
        -------
            类的实例,如果未找到则返回 None
        """
        item_class = self.get(name_or_alias)
        if item_class is None:
            return None
        return item_class(*args, **kwargs)

    def get_classes(self) -> list[type[T]]:
        """获取所有已注册类的列表.

        Returns
        -------
            已注册类的列表
        """
        return list(self._items.values())

    def get_metadata(self, name: str) -> dict[str, Any]:
        """获取已注册项的元数据.

        Args:
            name: 标准名称

        Returns
        -------
            元数据字典(如果未找到则为空字典).
            包含标准字段(name, class_name, description 等)
            以及注册时提供的任何自定义元数据字段.
        """
        return self._metadata.get(name, {}).copy()

    def list_items(self) -> list[str]:
        """列出所有已注册项的名称.

        Returns
        -------
            标准名称列表
        """
        return list(self._items.keys())

    def list_all(self) -> dict[str, Any]:
        """列出所有已注册项及其元数据.

        Returns
        -------
            名称到元数据字典的映射.
            注意:返回的字典包含 'class' 键,值为实际的类对象.
        """
        result = {}
        for name, item_class in self._items.items():
            metadata = self._metadata.get(name, {}).copy()
            metadata["class"] = item_class
            metadata["aliases"] = [
                alias for alias, target in self._aliases.items() if target == name
            ]
            result[name] = metadata
        return result

    def clear(self) -> None:
        """清空此注册表中的所有已注册项."""
        self._items.clear()
        self._aliases.clear()
        self._metadata.clear()
        logger.debug(f"注册表 '{self._name}' 已清空")

    def __len__(self) -> int:
        """返回已注册项的数量.

        Returns
        -------
            int: 已注册项的计数.
        """
        return len(self._items)

    def __contains__(self, name: str) -> bool:
        """检查项是否已注册.

        Args:
            name (str): 要检查的项名称.

        Returns
        -------
            bool: 如果项已注册则返回 True,否则返回 False.
        """
        canonical_name = self._aliases.get(name, name)
        return canonical_name in self._items

    @classmethod
    def get_registry(cls, name: str) -> Registry[Any]:
        """通过名称获取注册表(便捷方法).

        Args:
            name: 注册表标识符

        Returns
        -------
            注册表实例
        """
        return cls(name)

    @classmethod
    def list_registries(cls) -> list[str]:
        """列出所有已注册表的名称.

        Returns
        -------
            注册表名称列表
        """
        return list(cls._registries.keys())

    @classmethod
    def clear_all(cls) -> None:
        """清空所有注册表(用于测试)."""
        with cls._lock:
            for registry in cls._registries.values():
                registry.clear()
            cls._registries.clear()
            logger.debug("All registries cleared")


class DefaultRegistry(Registry[Any]):
    """向后兼容的通用注册表.

    此类为使用旧版单例模式 GenericRegistry 的代码提供向后兼容性.
    它包装了 Registry("default") 以确保所有遗留代码共享同一个注册表实例.

    注意:新代码应直接使用 Registry[T].
    """

    def __new__(cls) -> Registry:
        """返回默认注册表实例."""
        # 快速路径 - 先不加锁检查
        if "default" in Registry._registries:
            return Registry._registries["default"]

        # 慢速路径 - 获取锁并在需要时创建
        with cls._lock:
            # 获取锁后双重检查
            if "default" not in Registry._registries:
                # 直接调用父类的 __new__ 创建,避免锁竞争
                instance: Registry[Any] = object.__new__(Registry)
                instance._name = "default"
                instance._initialized = False
                instance._items = {}
                instance._aliases = {}
                instance._metadata = {}
                instance._initialized = True
                Registry._registries["default"] = instance

        return Registry._registries["default"]

    def __init__(self) -> None:
        """无操作初始化 - 注册表由 __new__ 管理."""

    @classmethod
    def get_default_registry(cls) -> Registry:
        """获取默认注册表实例(向后兼容).

        Returns
        -------
            Registry: 默认注册表实例.
        """
        return cls()


def register(
    registry_or_name: str | None = None,
    *,
    name: str | None = None,
    aliases: list[str] | None = None,
    metadata: dict[str, Any] | None = None,
    description: str = "",
    help_text: str = "",
    **meta_kwargs: Any,
) -> Callable[[type[T]], type[T]]:
    """使用注册表注册类的装饰器.

    此装饰器支持两种调用约定:

    1. 新式(推荐):将注册表名称作为第一个参数指定
        @register("commands", name="build", aliases=["b"])
        class BuildCommand: ...

    2. 旧式(向后兼容):使用默认注册表
        @register(name="build", aliases=["b"], description="...")
        class BuildCommand: ...

    Args:
        registry_or_name: 要使用的注册表名称(新式),
                         或 None 使用默认注册表(旧式)
        name: 标准名称(默认为类名的小写形式)
        aliases: 可选的别名列表
        metadata: 可选的元数据字典
        description: 用于描述的旧式参数
        help_text: 用于帮助文本的旧式参数
        **meta_kwargs: 额外元数据作为关键字参数

    Returns
    -------
        装饰器函数
    """

    def decorator(cls: type[T]) -> type[T]:
        # 确定注册表名称和项名称
        reg_name = registry_or_name
        item_name = name

        # 处理装饰器在没有注册表名称但以关键字参数调用的旧情况
        # 例如 @register(name="...", aliases=[...])
        if reg_name is None:
            reg_name = "default"
        elif not isinstance(reg_name, str) or " " in reg_name:
            # 第一个参数不是有效的注册表名称,将其作为项名称处理(旧式)
            item_name = reg_name
            reg_name = "default"

        final_item_name = item_name or cls.__name__.lower()

        reg = Registry(reg_name)

        # 合并元数据 - 支持新式和旧式
        final_metadata = (metadata or {}).copy()
        final_metadata.update(meta_kwargs)
        final_metadata.setdefault("name", final_item_name)
        final_metadata.setdefault("class_name", cls.__name__)

        # 支持旧式的 description/help_text 参数
        if description:
            final_metadata.setdefault("description", description)
        if help_text:
            final_metadata.setdefault("help_text", help_text)

        reg.register(
            name=final_item_name,
            item_class=cls,
            aliases=aliases,
            metadata=final_metadata,
        )

        # 在类上存储元数据以保持向后兼容性
        cls._registry_metadata = final_metadata  # type: ignore[attr-defined]
        cls._registry_name = reg_name  # type: ignore[attr-defined]
        cls._action_metadata = final_metadata  # type: ignore[attr-defined]  # 旧式兼容性

        logger.debug(f"已装饰并注册 '{final_item_name}' in '{reg_name}'")
        return cls

    return decorator


def get_registry(name: str) -> Registry[Any]:
    """Get a registry by name.

    Args:
        name: Registry identifier

    Returns
    -------
        The registry instance

    Example:
        commands = get_registry("commands")
        build_class = commands.get("build")
    """
    return Registry(name)
