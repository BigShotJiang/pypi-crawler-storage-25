"""Bitool 的日志模块.

本模块提供一个简单的、类似 loguru 的日志系统,具有彩色输出、文件轮转和易于使用的 API.

快速开始
--------
>>> from bitool.core import logger
>>> import logging

>>> logger.info("Hello, World!")  # 彩色输出到控制台和文件
>>> logger.debug("看不到调试信息")
>>> logger.setLevel(logging.DEBUG)
>>> logger.debug("现在可以看到调试信息了")
"""

from __future__ import annotations

import contextlib
import logging
import logging.handlers
import os
import platform
import sys
import threading
import time
from pathlib import Path
from typing import ClassVar, Final

__all__ = ["logger"]

# 默认日志格式
_DEFAULT_CONSOLE_FORMAT: Final[str] = "%(asctime)s | %(levelname)-8s | %(message)s"
_DEFAULT_FILE_FORMAT: Final[str] = (
    "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
_DEFAULT_CONSOLE_DATEFMT: Final[str] = "%H:%M:%S"
_DEFAULT_FILE_DATEFMT: Final[str] = "%Y-%m-%d %H:%M:%S"

# 默认日志路径
_DEFAULT_LOG_DIR: Final[Path] = Path.home() / ".bitool" / "logs"
_DEFAULT_LOG_FILE: Final[Path] = _DEFAULT_LOG_DIR / "bitool.log"
_DEFAULT_MAX_BYTES: Final[int] = 10 * 1024 * 1024  # 10MB
_DEFAULT_BACKUP_COUNT: Final[int] = 5


class _MultiProcessSafeRotatingFileHandler(logging.handlers.RotatingFileHandler):
    """多进程安全的轮转文件处理器.

    解决 Windows 平台上多线程和多进程环境下的文件锁定问题.
    使用文件锁 + 重试机制协调多进程访问.
    """

    _lock_file: ClassVar[str | None] = None
    _lock_fd: ClassVar[int | None] = None

    def __init__(
        self,
        filename: str | Path,
        maxBytes: int = 0,
        backupCount: int = 0,
        encoding: str | None = None,
        delay: bool = False,
    ) -> None:
        """初始化多进程安全的轮转文件处理器."""
        super().__init__(
            filename=str(filename),
            maxBytes=maxBytes,
            backupCount=backupCount,
            encoding=encoding,
            delay=delay,
        )
        self._thread_lock = threading.Lock()
        self._setup_lock_file()

    def _setup_lock_file(self) -> None:
        """设置文件锁（用于多进程协调）."""
        if _MultiProcessSafeRotatingFileHandler._lock_file is None:
            lock_path = f"{self.baseFilename}.lock"
            _MultiProcessSafeRotatingFileHandler._lock_file = lock_path

    def _acquire_file_lock(self, blocking: bool = True) -> bool:
        """获取文件锁.

        参数
        ----------
        blocking : bool
            是否阻塞等待获取锁

        返回
        -------
        bool
            是否成功获取锁
        """
        if platform.system() == "Windows":
            return self._acquire_windows_lock(blocking)
        return self._acquire_unix_lock(blocking)

    def _acquire_windows_lock(self, blocking: bool = True) -> bool:
        """Windows 平台获取文件锁."""
        lock_path = _MultiProcessSafeRotatingFileHandler._lock_file
        if lock_path is None:
            return True

        max_retries = 10 if blocking else 1
        retry_delay = 0.05

        for attempt in range(max_retries):
            try:
                fd = os.open(lock_path, os.O_CREAT | os.O_RDWR)
                try:
                    msvcrt = __import__("msvcrt")
                    msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
                    _MultiProcessSafeRotatingFileHandler._lock_fd = fd
                    return True
                except (OSError, AttributeError):
                    os.close(fd)
                    fd = None
                    if attempt < max_retries - 1:
                        time.sleep(retry_delay)
            except OSError:
                if attempt < max_retries - 1:
                    time.sleep(retry_delay)

        return False

    def _acquire_unix_lock(self, blocking: bool = True) -> bool:
        """Unix 平台获取文件锁."""
        lock_path = _MultiProcessSafeRotatingFileHandler._lock_file
        if lock_path is None:
            return True

        try:
            import fcntl
            max_retries = 10 if blocking else 1
            retry_delay = 0.05

            for attempt in range(max_retries):
                try:
                    fd = os.open(lock_path, os.O_CREAT | os.O_RDWR)
                    lock_type = fcntl.LOCK_EX if blocking else fcntl.LOCK_EX | fcntl.LOCK_NB
                    fcntl.flock(fd, lock_type)
                    _MultiProcessSafeRotatingFileHandler._lock_fd = fd
                    return True
                except OSError:
                    os.close(fd)
                    fd = None
                    if attempt < max_retries - 1:
                        time.sleep(retry_delay)
        except ImportError:
            pass

        return False

    def _release_file_lock(self) -> None:
        """释放文件锁."""
        if platform.system() == "Windows":
            self._release_windows_lock()
        else:
            self._release_unix_lock()

    def _release_windows_lock(self) -> None:
        """Windows 平台释放文件锁."""
        fd = _MultiProcessSafeRotatingFileHandler._lock_fd
        if fd is not None:
            try:
                msvcrt = __import__("msvcrt")
                msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
            except (OSError, AttributeError):
                pass
            try:
                os.close(fd)
            except OSError:
                pass
            _MultiProcessSafeRotatingFileHandler._lock_fd = None

    def _release_unix_lock(self) -> None:
        """Unix 平台释放文件锁."""
        try:
            import fcntl
        except ImportError:
            return

        fd = _MultiProcessSafeRotatingFileHandler._lock_fd
        if fd is not None:
            try:
                fcntl.flock(fd, fcntl.LOCK_UN)
                os.close(fd)
            except OSError:
                pass
            _MultiProcessSafeRotatingFileHandler._lock_fd = None

    def emit(self, record: logging.LogRecord) -> None:
        """重写 emit 方法，添加多进程安全写入."""
        try:
            if self.shouldRollover(record):
                with self._thread_lock:
                    if self.shouldRollover(record):
                        self.doRollover()
            msg = self.format(record)
            stream = self.stream
            if stream is not None:
                stream.write(msg + self.terminator)
                self.flush()
        except Exception:
            self.handleError(record)

    def doRollover(self) -> None:
        """执行日志轮转，使用锁保护避免并发问题."""
        if not self._acquire_file_lock(blocking=True):
            return

        try:
            if self.stream is not None:
                self.stream.flush()
                self.stream.close()
                self.stream = None

            if self.backupCount > 0:
                for i in range(self.backupCount - 1, 0, -1):
                    sfn = self.rotation_filename(f"{self.baseFilename}.{i}")
                    dfn = self.rotation_filename(f"{self.baseFilename}.{i + 1}")
                    if os.path.exists(sfn):
                        if os.path.exists(dfn):
                            self._safe_remove(dfn)
                        self._safe_rename(sfn, dfn)
                dfn = self.rotation_filename(f"{self.baseFilename}.1")
                if os.path.exists(dfn):
                    self._safe_remove(dfn)
                self._safe_rename(self.baseFilename, dfn)

            if not self.delay:
                self.stream = self._open()

        except OSError as e:
            if self.stream is None and not self.delay:
                with contextlib.suppress(OSError):
                    self.stream = self._open()
            sys.stderr.write(f"日志轮转失败: {e}\n")
        finally:
            self._release_file_lock()

    def _safe_remove(self, path: str) -> None:
        """安全删除文件,处理文件锁定问题."""
        max_retries = 5
        retry_delay = 0.1
        for attempt in range(max_retries):
            try:
                os.remove(path)
                return
            except OSError:
                if attempt < max_retries - 1:
                    time.sleep(retry_delay)
                else:
                    with contextlib.suppress(OSError):
                        pass

    def _safe_rename(self, src: str, dst: str) -> None:
        """安全重命名文件,处理文件锁定问题."""
        max_retries = 5
        retry_delay = 0.1
        for attempt in range(max_retries):
            try:
                os.replace(src, dst)
                return
            except OSError:
                if attempt < max_retries - 1:
                    time.sleep(retry_delay)
                else:
                    raise


class _ColoredFormatter(logging.Formatter):
    """自定义格式化器,为日志消息添加 ANSI 颜色."""

    COLORS: ClassVar[dict[str, str]] = {
        "DEBUG": "\033[36m",
        "INFO": "\033[32m",
        "WARNING": "\033[33m",
        "ERROR": "\033[31m",
        "CRITICAL": "\033[41m",
        "RESET": "\033[0m",
    }

    def __init__(self, fmt: str | None = None, datefmt: str | None = None) -> None:
        """初始化格式化器,检测是否支持 ANSI 颜色."""
        super().__init__(fmt, datefmt)
        self._enable_colors = self._check_color_support()

    @staticmethod
    def _check_color_support() -> bool:
        """检查当前环境是否支持 ANSI 颜色."""
        if platform.system() == "Windows":
            try:
                version = platform.version()
                major_version = int(version.split(".")[0])
            except (ValueError, IndexError):
                return False
            else:
                return major_version >= 10
        return True

    def format(self, record: logging.LogRecord) -> str:
        """使用适当的颜色格式化日志记录."""
        message = super().format(record)
        if not self._enable_colors:
            return message
        log_color = self.COLORS.get(record.levelname, self.COLORS["RESET"])
        return f"{log_color}{message}{self.COLORS['RESET']}"


class _Logger:
    """一个简单的、类似 loguru 的日志器.

    提供干净、最小化的 API,用于带有自动控制台颜色和文件轮转的日志记录。
    """

    _instance: ClassVar[logging.Logger | None] = None
    _setup_lock: ClassVar[threading.Lock] = threading.Lock()
    _is_setup: ClassVar[bool] = False

    DEBUG: Final[int] = logging.DEBUG
    INFO: Final[int] = logging.INFO
    WARNING: Final[int] = logging.WARNING
    ERROR: Final[int] = logging.ERROR
    CRITICAL: Final[int] = logging.CRITICAL

    @classmethod
    def _setup(
        cls,
        name: str = "bitool",
        level: int = logging.INFO,
        console_format: str | None = None,
        file_format: str | None = None,
    ) -> logging.Logger:
        """设置带有控制台和文件处理器的日志器."""
        with cls._setup_lock:
            if cls._is_setup and cls._instance is not None:
                return cls._instance

            with contextlib.suppress(OSError):
                _DEFAULT_LOG_DIR.mkdir(parents=True, exist_ok=True)

            logger_instance = logging.getLogger(name)
            logger_instance.setLevel(logging.DEBUG)

            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setLevel(level)
            console_fmt = console_format if console_format else _DEFAULT_CONSOLE_FORMAT
            console_formatter = _ColoredFormatter(
                console_fmt,
                datefmt=_DEFAULT_CONSOLE_DATEFMT,
            )
            console_handler.setFormatter(console_formatter)

            file_handler = _MultiProcessSafeRotatingFileHandler(
                _DEFAULT_LOG_FILE,
                maxBytes=_DEFAULT_MAX_BYTES,
                backupCount=_DEFAULT_BACKUP_COUNT,
                encoding="utf-8",
            )
            file_handler.setLevel(logging.DEBUG)
            file_fmt = file_format if file_format else _DEFAULT_FILE_FORMAT
            file_formatter = logging.Formatter(file_fmt, datefmt=_DEFAULT_FILE_DATEFMT)
            file_handler.setFormatter(file_formatter)

            logger_instance.addHandler(console_handler)
            logger_instance.addHandler(file_handler)

            logger_instance.propagate = False

            cls._instance = logger_instance
            cls._is_setup = True
            return cls._instance

    @classmethod
    def _get_logger(cls, name: str = "bitool") -> logging.Logger:
        """获取日志器实例."""
        if cls._instance is None:
            return cls._setup(name)
        return cls._instance

    @classmethod
    def setLevel(cls, level: int) -> None:
        """设置日志级别."""
        if cls._instance is not None:
            logging.Logger.setLevel(cls._instance, level)
            for handler in cls._instance.handlers:
                handler.setLevel(level)


logger: Final[logging.Logger] = _Logger._get_logger()
logger.setLevel = _Logger.setLevel  # type: ignore
