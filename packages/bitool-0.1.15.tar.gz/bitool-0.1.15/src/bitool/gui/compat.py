"""PySide2/PySide6 兼容性模块.

该模块提供统一的 PySide 导入接口，自动检测并导入可用的 PySide 版本.
支持 PySide2 和 PySide6，优先尝试 PySide6，然后回退到 PySide2.
支持在不同环境中自动选择合适的 PySide 版本，确保应用程序兼容性.
"""

from __future__ import annotations

import importlib
import logging
from pathlib import Path

# 配置日志记录器，使用 INFO 级别
logging.basicConfig(level=logging.INFO, format="%(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# 检测可用的 PySide 版本
_pyside_module = None
_pyside_version = ""

PYSIDE_DIR: Path | None = None

# 步骤1: 尝试 PySide6
if _pyside_module is None:
    try:
        importlib.util.find_spec("PySide6")  # ty:ignore[possibly-missing-submodule]
        _pyside_module = importlib.import_module("PySide6")
        _pyside_version = "PySide6"
        QtUiTools = importlib.import_module(f"{_pyside_version}.QtUiTools")
    except ImportError:
        logger.warning("未找到 PySide6，尝试 PySide2...")
    else:
        logger.info("成功导入 PySide6")

# 步骤2: 尝试 PySide2（优先于 PyQt5，pymake 项目只配置了 PySide2）
if _pyside_module is None:
    try:
        importlib.util.find_spec("PySide2")  # ty:ignore[possibly-missing-submodule]
        _pyside_module = importlib.import_module("PySide2")
        _pyside_version = "PySide2"

        QtUiTools = importlib.import_module(f"{_pyside_version}.QtUiTools")
    except ImportError:
        logger.warning("未找到 PySide2，尝试 PyQt5...")
    else:
        logger.info("成功导入 PySide2")

# 步骤3: 尝试 PyQt5（最终回退）
if _pyside_module is None:
    try:
        importlib.util.find_spec("PyQt5")  # ty:ignore[possibly-missing-submodule]
        _pyside_module = importlib.import_module("PyQt5")
        _pyside_version = "PyQt5"
    except ImportError:
        logger.exception("PySide6/PySide2/PyQt5 均未安装, 请安装其中任意一个版本.")
    else:
        logger.info("成功导入 PyQt5")

if _pyside_module is not None:
    PYSIDE_DIR = Path(str(_pyside_module.__file__)).parent

# Import core modules
QtCore = importlib.import_module(f"{_pyside_version}.QtCore")
QtGui = importlib.import_module(f"{_pyside_version}.QtGui")
QtWidgets = importlib.import_module(f"{_pyside_version}.QtWidgets")
QtSvg = importlib.import_module(f"{_pyside_version}.QtSvg")
QtWebChannel = importlib.import_module(f"{_pyside_version}.QtWebChannel")


if _pyside_version == "PySide6":
    QtOpenGLWidgets = importlib.import_module(f"{_pyside_version}.QtOpenGLWidgets")
    QOpenGLWidget = QtOpenGLWidgets.QOpenGLWidget
    QtWebEngineCore = importlib.import_module(f"{_pyside_version}.QtWebEngineCore")
    QWebEngineSettings = QtWebEngineCore.QWebEngineSettings
    QtWebEngineWidgets = importlib.import_module(
        f"{_pyside_version}.QtWebEngineWidgets"
    )
    QWebEngineView = QtWebEngineWidgets.QWebEngineView
else:
    QOpenGLWidget = QtWidgets.QOpenGLWidget
    try:
        QtWebEngineWidgets = importlib.import_module(
            f"{_pyside_version}.QtWebEngineWidgets"
        )
        QWebEngineSettings = QtWebEngineWidgets.QWebEngineSettings
        QWebEngineView = QtWebEngineWidgets.QWebEngineView
    except ImportError:
        QtWebEngineWidgets = None  # type: ignore[assignment]
        QWebEngineSettings = None  # type: ignore[assignment]
        QWebEngineView = None  # type: ignore[assignment]


# Export commonly used classes and constants
QApplication = QtWidgets.QApplication
QAbstractItemModel = QtCore.QAbstractItemModel
QAbstractListModel = QtCore.QAbstractListModel
QFontMetrics = QtGui.QFontMetrics
QPainter = QtGui.QPainter
QPen = QtGui.QPen
QDir = QtCore.QDir
QButtonGroup = QtWidgets.QButtonGroup
QColorDialog = QtWidgets.QColorDialog
QCompleter = QtWidgets.QCompleter
QWidget = QtWidgets.QWidget
QMainWindow = QtWidgets.QMainWindow
QDialog = QtWidgets.QDialog
QLabel = QtWidgets.QLabel
QBrush = QtGui.QBrush
QColor = QtGui.QColor
QItemSelectionModel = QtCore.QItemSelectionModel
QTextCharFormat = QtGui.QTextCharFormat
QTextCursor = QtGui.QTextCursor
QPushButton = QtWidgets.QPushButton
QLineEdit = QtWidgets.QLineEdit
QProcess = QtCore.QProcess
QTextEdit = QtWidgets.QTextEdit
QTextBrowser = QtWidgets.QTextBrowser
QCheckBox = QtWidgets.QCheckBox
QShortcut = QtGui.QShortcut if _pyside_version == "PySide6" else QtWidgets.QShortcut
QWebChannel = QtWebChannel.QWebChannel
QDesktopServices = QtGui.QDesktopServices
QProgressBar = QtWidgets.QProgressBar
QProgressDialog = QtWidgets.QProgressDialog
QSpinBox = QtWidgets.QSpinBox
QVBoxLayout = QtWidgets.QVBoxLayout
QHBoxLayout = QtWidgets.QHBoxLayout
QStyle = QtWidgets.QStyle
QStyledItemDelegate = QtWidgets.QStyledItemDelegate
QStyleOptionViewItem = QtWidgets.QStyleOptionViewItem
QSvgRenderer = QtSvg.QSvgRenderer
QGridLayout = QtWidgets.QGridLayout
QSizePolicy = QtWidgets.QSizePolicy
QSpacerItem = QtWidgets.QSpacerItem
QTabWidget = QtWidgets.QTabWidget
QComboBox = QtWidgets.QComboBox
QSlider = QtWidgets.QSlider
QDoubleSpinBox = QtWidgets.QDoubleSpinBox
QGroupBox = QtWidgets.QGroupBox
QScrollArea = QtWidgets.QScrollArea
QFrame = QtWidgets.QFrame
QMenuBar = QtWidgets.QMenuBar
QMenu = QtWidgets.QMenu
QPlainTextEdit = QtWidgets.QPlainTextEdit
QPaintEvent = QtGui.QPaintEvent
# QAction is in QtGui for PySide6 and QtWidgets for PySide2
QAction = QtGui.QAction if _pyside_version == "PySide6" else QtWidgets.QAction
QFormLayout = QtWidgets.QFormLayout
QStatusBar = QtWidgets.QStatusBar
QVector3D = QtGui.QVector3D
QWheelEvent = QtGui.QWheelEvent
QDockWidget = QtWidgets.QDockWidget
QToolBar = QtWidgets.QToolBar
QToolButton = QtWidgets.QToolButton
QTreeWidget = QtWidgets.QTreeWidget
QTreeWidgetItem = QtWidgets.QTreeWidgetItem
QTableWidget = QtWidgets.QTableWidget
QTableWidgetItem = QtWidgets.QTableWidgetItem
QAbstractTableModel = QtCore.QAbstractTableModel
QHeaderView = QtWidgets.QHeaderView
QListView = QtWidgets.QListView
QListWidget = QtWidgets.QListWidget
QListWidgetItem = QtWidgets.QListWidgetItem
QStackedWidget = QtWidgets.QStackedWidget
QSplitter = QtWidgets.QSplitter
QScrollBar = QtWidgets.QScrollBar
QCalendarWidget = QtWidgets.QCalendarWidget
QTimeEdit = QtWidgets.QTimeEdit
QDateTimeEdit = QtWidgets.QDateTimeEdit
QDateEdit = QtWidgets.QDateEdit
QLCDNumber = QtWidgets.QLCDNumber
QModelIndex = QtCore.QModelIndex
QDial = QtWidgets.QDial
QRadioButton = QtWidgets.QRadioButton
QAbstractItemView = QtWidgets.QAbstractItemView
QTableView = QtWidgets.QTableView
QStyledItemDelegate = QtWidgets.QStyledItemDelegate
QFileSystemModel = QtWidgets.QFileSystemModel
QFileDialog = QtWidgets.QFileDialog
QMessageBox = QtWidgets.QMessageBox
QDialogButtonBox = QtWidgets.QDialogButtonBox
QFont = QtGui.QFont
QIcon = QtGui.QIcon
QImage = QtGui.QImage
QPixmap = QtGui.QPixmap
QScreen = QtGui.QScreen
QCloseEvent = QtGui.QCloseEvent
QKeyEvent = QtGui.QKeyEvent
QMoveEvent = QtGui.QMoveEvent
QResizeEvent = QtGui.QResizeEvent
QMouseEvent = QtGui.QMouseEvent
QFile = QtCore.QFile
QIODevice = QtCore.QIODevice
QUrl = QtCore.QUrl
QEvent = QtCore.QEvent
QObject = QtCore.QObject
QPoint = QtCore.QPoint
QRect = QtCore.QRect
QRectF = QtCore.QRectF
QStandardItem = QtGui.QStandardItem
QStandardItemModel = QtGui.QStandardItemModel
QStringListModel = QtCore.QStringListModel
QThread = QtCore.QThread
QSize = QtCore.QSize
Qt = QtCore.Qt
QTime = QtCore.QTime
QTimer = QtCore.QTimer
QContextMenuEvent = QtGui.QContextMenuEvent
QInputDialog = QtWidgets.QInputDialog
QKeySequence = QtGui.QKeySequence

if _pyside_version in ["PySide2", "PySide6"]:
    QUiLoader = QtUiTools.QUiLoader
    Signal = QtCore.Signal
    Slot = QtCore.Slot
    _use_uic_loader = False
else:
    # PyQt5: 使用 uic.loadUi，需要特殊处理
    Signal = QtCore.pyqtSignal
    Slot = QtCore.pyqtSlot
    _use_uic_loader = True

    class QUiLoader:
        """PyQt5 QUiLoader 兼容包装器.

        PyQt5 没有 QUiLoader，使用 PyQt5.uic.loadUi 实现相同功能.
        """

        def __init__(self) -> None:
            from PyQt5 import uic  # ty:ignore[unresolved-import]

            self._uic = uic
            self._cache: dict[str, type] = {}

        def load(
            self, file_or_path: QFile | str, parent: QWidget | None = None
        ) -> QWidget:
            """加载 UI 文件.

            Parameters
            ----------
            file_or_path : QFile or str
                QFile 对象或 UI 文件路径
            parent : QWidget, optional
                父 widget

            Returns
            -------
            QWidget
                加载的 widget 实例
            """
            ui_path = (
                file_or_path.fileName()
                if isinstance(file_or_path, QFile)
                else file_or_path
            )

            # PyQt5.uic.loadUi(ui_path, baseinstance) 会验证 baseinstance 类型
            # 必须与 .ui 文件定义的 toplevel widget 匹配，否则报错。
            # 为避免此限制，先加载到临时 widget，再转移 layout 和直接子控件到 parent。
            # 注意：QFile.open 的检查已在 _uiloader.py 中完成，此处直接加载。
            temp_widget = self._uic.loadUi(ui_path)

            if parent is not None:
                # 转移 layout（setLayout 会将 layout 的 items 转移到 parent）
                if temp_widget.layout() is not None:
                    parent.setLayout(temp_widget.layout())

                # 只 reparent 直接子控件（不包括 descendants）
                # 否则会破坏嵌套容器的 widget 树结构
                for child in temp_widget.children():
                    if isinstance(child, QObject) and child.objectName():
                        setattr(parent, child.objectName(), child)
                        child.setParent(parent)

                # 返回 parent 以保持与 PySide QUiLoader.load(parent) 的语义一致
                return parent

            return temp_widget


# Export version information
PYQT_VERSION = _pyside_version

__all__ = [
    "PYQT_VERSION",
    "PYSIDE_DIR",
    "QAbstractItemModel",
    "QAbstractItemView",
    "QAbstractListModel",
    "QAbstractTableModel",
    "QAction",
    "QApplication",
    "QBrush",
    "QButtonGroup",
    "QCalendarWidget",
    "QCheckBox",
    "QCloseEvent",
    "QColor",
    "QColorDialog",
    "QComboBox",
    "QCompleter",
    "QContextMenuEvent",
    "QDateEdit",
    "QDateTimeEdit",
    "QDesktopServices",
    "QDial",
    "QDialog",
    "QDialogButtonBox",
    "QDir",
    "QDockWidget",
    "QDoubleSpinBox",
    "QEvent",
    "QFile",
    "QFileDialog",
    "QFileSystemModel",
    "QFont",
    "QFontMetrics",
    "QFormLayout",
    "QFrame",
    "QGridLayout",
    "QGroupBox",
    "QHBoxLayout",
    "QHeaderView",
    "QIODevice",
    "QIcon",
    "QImage",
    "QInputDialog",
    "QItemSelectionModel",
    "QKeyEvent",
    "QKeySequence",
    "QLCDNumber",
    "QLabel",
    "QLineEdit",
    "QListView",
    "QListWidget",
    "QListWidgetItem",
    "QMainWindow",
    "QMenu",
    "QMenuBar",
    "QMessageBox",
    "QModelIndex",
    "QMouseEvent",
    "QMoveEvent",
    "QObject",
    "QPaintEvent",
    "QPainter",
    "QPen",
    "QPixmap",
    "QPlainTextEdit",
    "QPoint",
    "QProcess",
    "QProgressBar",
    "QProgressDialog",
    "QPushButton",
    "QRadioButton",
    "QRect",
    "QRectF",
    "QResizeEvent",
    "QScreen",
    "QScrollArea",
    "QScrollBar",
    "QShortcut",
    "QSize",
    "QSizePolicy",
    "QSlider",
    "QSpacerItem",
    "QSpinBox",
    "QSplitter",
    "QStackedWidget",
    "QStandardItem",
    "QStandardItemModel",
    "QStatusBar",
    "QStringListModel",
    "QStyle",
    "QStyleOptionViewItem",
    "QStyledItemDelegate",
    "QStyledItemDelegate",
    "QSvgRenderer",
    "QTabWidget",
    "QTableView",
    "QTableWidget",
    "QTableWidgetItem",
    "QTextBrowser",
    "QTextCharFormat",
    "QTextCursor",
    "QTextEdit",
    "QThread",
    "QTimeEdit",
    "QTimer",
    "QToolBar",
    "QToolButton",
    "QTreeWidget",
    "QTreeWidgetItem",
    "QUiLoader",
    "QUrl",
    "QVBoxLayout",
    "QWebChannel",
    "QWebEngineSettings",
    "QWebEngineView",
    "QWidget",
    "Qt",
    "Signal",
    "Slot",
]
