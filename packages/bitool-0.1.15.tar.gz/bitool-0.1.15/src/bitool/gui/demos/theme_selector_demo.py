"""主题选择器使用示例."""
# ty: ignore-file - PySide2 类型存根不完整

from __future__ import annotations

import sys

from .._themes import apply_theme
from ..compat import (
    QApplication,
    QCheckBox,
    QComboBox,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QProgressBar,
    QPushButton,
    QRadioButton,
    QSlider,
    QSpinBox,
    Qt,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)
from ..widgets.theme_selector import open_theme_selector


class ThemeSelectorExample(QMainWindow):
    """主题选择器使用示例."""

    def __init__(self) -> None:
        """初始化示例窗口."""
        super().__init__()
        self.current_theme = "aqua"

        self._init_ui()
        apply_theme(self, self.current_theme)

    def _init_ui(self) -> None:
        """初始化用户界面."""
        self.setWindowTitle("主题选择器使用示例")
        self.setGeometry(100, 100, 800, 600)

        # 创建菜单栏
        self._create_menu_bar()

        # 中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        # 主题控制区域
        theme_group = QGroupBox("主题控制")
        theme_layout = QHBoxLayout()

        self.theme_label = QLabel(f"当前主题: {self.current_theme}")
        theme_layout.addWidget(self.theme_label)

        self.change_theme_btn = QPushButton("更改主题")
        self.change_theme_btn.clicked.connect(self._open_theme_selector)
        theme_layout.addWidget(self.change_theme_btn)

        theme_layout.addStretch()
        theme_group.setLayout(theme_layout)
        main_layout.addWidget(theme_group)

        # 创建示例控件
        tab_widget = QTabWidget()
        tab_widget.addTab(self._create_basic_controls_tab(), "基础控件")
        tab_widget.addTab(self._create_input_controls_tab(), "输入控件")
        main_layout.addWidget(tab_widget)

        # 状态栏
        self.statusBar().showMessage("就绪")

    def _create_menu_bar(self) -> None:
        """创建菜单栏."""
        menubar = self.menuBar()

        # 文件菜单
        file_menu = menubar.addMenu("文件(&F)")
        file_menu.addAction("退出(&X)", self.close)

        # 主题菜单
        theme_menu = menubar.addMenu("主题(&T)")
        theme_menu.addAction("选择主题...", self._open_theme_selector)

    def _open_theme_selector(self) -> None:
        """打开主题选择器."""
        selected_theme = open_theme_selector(self, self.current_theme)
        if selected_theme:
            self.current_theme = selected_theme
            self.theme_label.setText(f"当前主题: {self.current_theme}")
            self.statusBar().showMessage(f"已应用主题: {self.current_theme}")

    def _create_basic_controls_tab(self) -> QWidget:
        """创建基础控件标签页."""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # 按钮组
        button_group = QGroupBox("按钮")
        button_layout = QHBoxLayout()

        btn1 = QPushButton("普通按钮")
        btn1.clicked.connect(lambda: self.statusBar().showMessage("普通按钮被点击"))
        button_layout.addWidget(btn1)

        btn2 = QPushButton("禁用按钮")
        btn2.setEnabled(False)
        button_layout.addWidget(btn2)

        button_group.setLayout(button_layout)
        layout.addWidget(button_group)

        # 复选框和单选按钮
        row2_layout = QHBoxLayout()

        checkbox_group = QGroupBox("复选框")
        checkbox_layout = QVBoxLayout()
        cb1 = QCheckBox("选项 1")
        cb1.setChecked(True)
        checkbox_layout.addWidget(cb1)
        cb2 = QCheckBox("选项 2")
        checkbox_layout.addWidget(cb2)
        checkbox_group.setLayout(checkbox_layout)
        row2_layout.addWidget(checkbox_group)

        radiobutton_group = QGroupBox("单选按钮")
        radiobutton_layout = QVBoxLayout()
        rb1 = QRadioButton("选项 A")
        rb1.setChecked(True)
        radiobutton_layout.addWidget(rb1)
        rb2 = QRadioButton("选项 B")
        radiobutton_layout.addWidget(rb2)
        radiobutton_group.setLayout(radiobutton_layout)
        row2_layout.addWidget(radiobutton_group)

        layout.addLayout(row2_layout)
        layout.addStretch()

        return widget

    def _create_input_controls_tab(self) -> QWidget:
        """创建输入控件标签页."""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # 文本输入
        row1_layout = QHBoxLayout()

        lineedit_group = QGroupBox("文本输入")
        lineedit_layout = QVBoxLayout()
        line_edit = QLineEdit()
        line_edit.setPlaceholderText("请输入文本...")
        lineedit_layout.addWidget(line_edit)
        lineedit_group.setLayout(lineedit_layout)
        row1_layout.addWidget(lineedit_group)

        combo_group = QGroupBox("下拉框")
        combo_layout = QVBoxLayout()
        combo = QComboBox()
        combo.addItems(["选项 1", "选项 2", "选项 3"])
        combo_layout.addWidget(combo)
        combo_group.setLayout(combo_layout)
        row1_layout.addWidget(combo_group)

        layout.addLayout(row1_layout)

        # 数值输入和滑块
        row2_layout = QHBoxLayout()

        spinbox_group = QGroupBox("整数微调框")
        spinbox_layout = QVBoxLayout()
        spinbox = QSpinBox()
        spinbox.setRange(0, 100)
        spinbox.setValue(50)
        spinbox_layout.addWidget(spinbox)
        spinbox_group.setLayout(spinbox_layout)
        row2_layout.addWidget(spinbox_group)

        slider_group = QGroupBox("滑块")
        slider_layout = QVBoxLayout()
        slider = QSlider(Qt.Horizontal)
        slider.setRange(0, 100)
        slider.setValue(50)
        slider_layout.addWidget(slider)
        slider_group.setLayout(slider_layout)
        row2_layout.addWidget(slider_group)

        progress_group = QGroupBox("进度条")
        progress_layout = QVBoxLayout()
        progress = QProgressBar()
        progress.setRange(0, 100)
        progress.setValue(65)
        progress_layout.addWidget(progress)
        progress_group.setLayout(progress_layout)
        row2_layout.addWidget(progress_group)

        layout.addLayout(row2_layout)

        # 文本编辑
        text_edit = QTextEdit()
        text_edit.setPlainText("这是一个 QTextEdit 控件\n支持多行文本编辑")
        text_edit.setMaximumHeight(100)
        layout.addWidget(text_edit)

        return widget


def main() -> None:
    """主函数."""
    app = QApplication(sys.argv)

    window = ThemeSelectorExample()
    window.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
