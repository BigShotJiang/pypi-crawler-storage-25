"""基于预构建 QSS 样式表的简化主题系统.

该模块提供一个简单的主题配置系统,用于加载已存在的 QSS 样式表文件.
"""

from __future__ import annotations

import threading
from pathlib import Path
from typing import ClassVar

from bitool.core import logger

from .compat import QWidget

__all__ = [
    "apply_theme",
    "get_theme_count",
    "get_theme_files",
    "has_theme",
    "list_themes",
]


_STYLESHEETS_DIR = Path(__file__).parent / "stylesheets"
_BASE_STRUCTURE_FILE = _STYLESHEETS_DIR / "base_structure.qss"


class ThemeManager:
    """简单的主题管理器,使用预构建的 QSS 样式表.

    功能:
    - 加载已存在的 QSS 样式表文件
    - 将主题应用到 Qt 控件
    - 列出可用主题
    - 预览主题信息

    Examples
    --------
        apply_theme(widget, "dark")

    Note
    ----
    本类是线程安全的,但 Qt 控件操作必须在主线程中执行.
    """

    _lock: ClassVar[threading.Lock] = threading.Lock()

    def __init__(self) -> None:
        """初始化主题管理器."""
        self._theme_files: dict[str, Path] = {}
        self._load_available_themes()

    def _load_available_themes(self) -> None:
        """从样式表目录加载可用的主题文件(线程安全)."""
        try:
            if not _STYLESHEETS_DIR.exists():
                logger.warning(f"未找到样式表目录:{_STYLESHEETS_DIR}")
                return

            themes = {}

            # 加载传统完整 QSS 文件（排除 base_structure.qss 和 *_colors.qss）
            for qss_file in _STYLESHEETS_DIR.glob("*.qss"):
                # 跳过基础结构文件和颜色文件
                if qss_file.name == "base_structure.qss" or qss_file.name.endswith(
                    "_colors.qss",
                ):
                    continue
                theme_name = qss_file.stem
                themes[theme_name] = qss_file

            # 加载只有颜色文件的主题（使用 base_structure.qss）
            if _BASE_STRUCTURE_FILE.exists():
                for color_file in _STYLESHEETS_DIR.glob("*_colors.qss"):
                    # 提取主题名称（去掉 _colors.qss 后缀）
                    theme_name = color_file.stem.replace("_colors", "")
                    # 如果主题尚未存在，添加它（标记为使用颜色文件）
                    if theme_name not in themes:
                        themes[theme_name] = color_file

            # 使用锁保护字典更新
            with self._lock:
                self._theme_files = themes

            logger.info(f"已加载 {len(self._theme_files)} 个主题样式表")

        except FileNotFoundError as e:
            logger.error(f"加载主题样式表失败:{e}")
            raise

    def _generate_qss(self, theme_name: str) -> str:
        """从文件加载 QSS 样式表(线程安全).

        Args:
            theme_name: 主题名称

        Returns
        -------
            完整的 QSS 样式表字符串
        """
        # 使用锁保护字典读取
        with self._lock:
            if theme_name not in self._theme_files:
                logger.warning(f"未找到主题 '{theme_name}'")
                return ""

            theme_file = self._theme_files[theme_name]

        # 如果是颜色文件，应该使用 _generate_qss_with_structure 方法
        if theme_file.name.endswith("_colors.qss"):
            return self._generate_qss_with_structure(theme_name)

        try:
            with theme_file.open("r", encoding="utf-8") as f:
                return f.read()
        except (FileNotFoundError, UnicodeDecodeError) as e:
            logger.error(f"加载主题 '{theme_name}' 失败:{e}")
            return ""

    def _generate_qss_with_structure(self, theme_name: str) -> str:
        """合并基础结构和颜色生成 QSS 样式表(线程安全).

        Args:
            theme_name: 主题名称

        Returns
        -------
            完整的 QSS 样式表字符串
        """
        # 检查是否有对应的颜色文件
        color_file = _STYLESHEETS_DIR / f"{theme_name}_colors.qss"

        # 如果没有颜色文件或基础结构文件，回退到传统方式
        if not color_file.exists() or not _BASE_STRUCTURE_FILE.exists():
            return self._generate_qss(theme_name)

        try:
            # 加载颜色定义
            with color_file.open("r", encoding="utf-8") as f:
                color_content = f.read()

            # 解析颜色变量
            color_vars = self._parse_color_variables(color_content)

            # 加载基础结构
            with _BASE_STRUCTURE_FILE.open("r", encoding="utf-8") as f:
                structure_content = f.read()

            # 替换颜色变量
            qss = self._replace_color_variables(structure_content, color_vars)
        except (FileNotFoundError, UnicodeDecodeError) as e:
            logger.error(f"加载主题 '{theme_name}' 失败:{e}")
            return ""
        else:
            return qss

    def _parse_color_variables(self, color_content: str) -> dict[str, str]:
        """解析颜色变量定义.

        Args:
            color_content: 颜色文件内容

        Returns
        -------
            颜色变量字典
        """
        color_vars = {}
        for line in color_content.splitlines():
            line = line.strip()
            # 跳过注释和空行(支持 /* 和 // 两种注释风格)
            if not line or line.startswith("/*") or line.startswith("//"):
                continue
            # 匹配 VARIABLE: VALUE; 格式
            if ":" in line and line.endswith(";"):
                parts = line[:-1].split(":", 1)  # 移除末尾的分号
                if len(parts) == 2:
                    var_name = parts[0].strip()
                    var_value = parts[1].strip()
                    # 验证变量名（只包含大写字母、数字和下划线）
                    if var_name and all(
                        c.isupper() or c.isdigit() or c == "_" for c in var_name
                    ):
                        color_vars[var_name] = var_value

        return color_vars

    def _replace_color_variables(
        self,
        qss_content: str,
        color_vars: dict[str, str],
    ) -> str:
        """替换 QSS 中的颜色变量.

        Args:
            qss_content: QSS 内容
            color_vars: 颜色变量字典

        Returns
        -------
            替换后的 QSS 内容
        """
        result = qss_content
        # 按变量名长度降序排序，避免短变量名误替换长变量名
        sorted_vars = sorted(color_vars.items(), key=lambda x: len(x[0]), reverse=True)
        for var_name, var_value in sorted_vars:
            result = result.replace(var_name, var_value)
        return result

    def apply_theme(self, widget: QWidget, theme_name: str) -> bool:
        """将主题应用到控件(线程安全).

        Args:
            widget: 要样式化的 Qt 控件(必须在主线程中)
            theme_name: 要应用的主题名称

        Returns
        -------
            如果成功则为 True

        Note
        ----
        Qt 控件操作必须在主线程中执行. 如果在子线程中调用,
        方法会尝试使用 Qt 的信号槽机制切换到主线程.
        """
        # 验证参数
        if widget is None:
            logger.error("控件不能为 None")
            return False

        if not theme_name:
            logger.error("主题名称不能为空")
            return False

        # 检查是否在主线程(Qt 要求 GUI 操作必须在主线程)
        main_thread = threading.main_thread()
        if threading.current_thread() != main_thread:
            logger.error(
                f"检测到子线程调用!Qt 控件操作必须在主线程中执行. 主题 '{theme_name}' 应用失败. ",
            )
            return False

        # 在主线程中直接应用
        logger.info(f"应用主题 '{theme_name}' 到控件 {widget}")
        return self._apply_theme_internal(widget, theme_name)

    def _apply_theme_internal(self, widget: QWidget, theme_name: str) -> bool:
        """内部方法:实际应用主题到控件.

        Args:
            widget: Qt 控件
            theme_name: 主题名称

        Returns
        -------
            如果成功则为 True
        """
        # 尝试使用结构和颜色分离的方式加载
        qss = self._generate_qss_with_structure(theme_name)

        # 如果失败，回退到传统方式
        if not qss:
            qss = self._generate_qss(theme_name)

        if not qss:
            logger.warning(f"主题 '{theme_name}' 未找到, 可选: {self.list_themes()}")
            return False

        # 应用样式表
        try:
            widget.setStyleSheet(qss)
        except RuntimeError as e:
            logger.error(f"应用主题 '{theme_name}' 失败:{e}")
            return False
        else:
            logger.debug(f"已应用主题 '{theme_name}' 到控件")
            return True

    def list_themes(self) -> list[str]:
        """列出可用主题(线程安全).

        Returns
        -------
            可用主题名称列表,按字母顺序排序
        """
        with self._lock:
            return sorted(self._theme_files.keys())

    def get_theme_files(self) -> dict[str, Path]:
        """获取主题文件字典(线程安全).

        Returns
        -------
            主题名称及其对应文件路径的字典(只读副本)
        """
        with self._lock:
            return dict(self._theme_files)

    def has_theme(self, theme_name: str) -> bool:
        """检查主题是否存在(线程安全).

        Args:
            theme_name: 主题名称

        Returns
        -------
            如果主题存在则为 True
        """
        with self._lock:
            return theme_name in self._theme_files

    def get_theme_count(self) -> int:
        """获取可用主题数量(线程安全).

        Returns
        -------
            主题数量
        """
        with self._lock:
            return len(self._theme_files)


_theme_manager = ThemeManager()
apply_theme = _theme_manager.apply_theme
get_theme_files = _theme_manager.get_theme_files
has_theme = _theme_manager.has_theme
get_theme_count = _theme_manager.get_theme_count
list_themes = _theme_manager.list_themes
