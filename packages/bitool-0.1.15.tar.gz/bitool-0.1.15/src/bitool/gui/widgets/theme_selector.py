"""主题选择器对话框.

提供一个便利的主题选择对话框界面,支持预览和应用主题.
"""

from __future__ import annotations

from .._themes import apply_theme, list_themes
from ..compat import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFont,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QSlider,
    Qt,
    QVBoxLayout,
    QWidget,
)


class ThemeSelectorDialog(QDialog):
    """主题选择器对话框.

    提供一个直观的界面让用户选择和应用主题.
    """

    def __init__(self, parent: QWidget | None = None, current_theme: str = "") -> None:
        """初始化主题选择器对话框.

        Args:
            parent: 父窗口
            current_theme: 当前应用的主题名称
        """
        super().__init__(parent)
        self._current_theme = current_theme
        self._selected_theme = current_theme
        self._preview_widget = QWidget()

        self._init_ui()
        self._load_themes()

    def _init_ui(self) -> None:
        """初始化用户界面."""
        self.setWindowTitle("选择主题")
        self.setModal(True)
        self.resize(600, 500)

        # 主布局
        main_layout = QVBoxLayout(self)

        # 标题
        title_label = QLabel("主题选择器")
        title_label.setAlignment(Qt.AlignCenter)
        title_font = QFont()
        title_font.setPointSize(14)
        title_font.setBold(True)
        title_label.setFont(title_font)
        main_layout.addWidget(title_label)

        # 内容区域
        content_layout = QHBoxLayout()

        # 左侧：主题列表
        left_layout = QVBoxLayout()

        list_label = QLabel("可用主题:")
        left_layout.addWidget(list_label)

        self.theme_list = QListWidget()
        self.theme_list.currentItemChanged.connect(self._on_theme_selected)
        left_layout.addWidget(self.theme_list)

        content_layout.addLayout(left_layout, 1)

        # 右侧：预览区域
        right_layout = QVBoxLayout()

        preview_label = QLabel("主题预览:")
        right_layout.addWidget(preview_label)

        # 预览控件容器
        self._preview_widget = QWidget()
        self._setup_preview_widgets()
        right_layout.addWidget(self._preview_widget)

        content_layout.addLayout(right_layout, 1)

        main_layout.addLayout(content_layout)

        # 按钮框
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.button(QDialogButtonBox.Ok).setText("确认")  # type: ignore[union-attr]
        button_box.button(QDialogButtonBox.Cancel).setText("取消")  # type: ignore[union-attr]
        button_box.accepted.connect(self._on_accept)  # type: ignore[union-attr]
        button_box.rejected.connect(self.reject)  # type: ignore[union-attr]
        main_layout.addWidget(button_box)

    def _setup_preview_widgets(self) -> None:
        """设置预览控件."""
        layout = QVBoxLayout(self._preview_widget)

        # 示例按钮
        self.preview_button = QPushButton("示例按钮")
        layout.addWidget(self.preview_button)

        # 示例标签
        self.preview_label = QLabel("这是一个预览标签")
        layout.addWidget(self.preview_label)

        # 示例输入框
        self.preview_line_edit = QLineEdit()
        self.preview_line_edit.setPlaceholderText("示例输入框...")
        layout.addWidget(self.preview_line_edit)

        # 示例复选框
        self.preview_checkbox = QCheckBox("示例复选框")
        self.preview_checkbox.setChecked(True)
        layout.addWidget(self.preview_checkbox)

        # 示例下拉框
        self.preview_combo = QComboBox()
        self.preview_combo.addItems(["选项 1", "选项 2", "选项 3"])
        layout.addWidget(self.preview_combo)

        # 示例滑块
        self.preview_slider = QSlider(Qt.Horizontal)
        self.preview_slider.setRange(0, 100)
        self.preview_slider.setValue(50)
        layout.addWidget(self.preview_slider)

        layout.addStretch()

    def _load_themes(self) -> None:
        """加载可用主题."""
        self.theme_list.clear()

        themes = list_themes()
        for theme_name in themes:
            item = QListWidgetItem(theme_name)
            self.theme_list.addItem(item)  # type: ignore[arg-type]

            # 标记当前主题
            if theme_name == self._current_theme:
                item.setSelected(True)

    def _on_theme_selected(
        self,
        current: QListWidgetItem | None,
        previous: QListWidgetItem | None,
    ) -> None:
        """处理主题选择事件.

        Args:
            current: 当前选中的项目
            previous: 之前选中的项目
        """
        if current:
            theme_name = current.text()
            self._selected_theme = theme_name
            self._apply_preview_theme(theme_name)

    def _apply_preview_theme(self, theme_name: str) -> None:
        """应用主题到预览控件.

        Args:
            theme_name: 要应用的主题名称
        """
        if theme_name:
            apply_theme(self._preview_widget, theme_name)

    def _on_accept(self) -> None:
        """处理接受按钮点击."""
        if self._selected_theme and self._selected_theme != self._current_theme:
            # 应用选中的主题到父窗口
            parent_widget = self.parent()
            if isinstance(parent_widget, QWidget):
                apply_theme(parent_widget, self._selected_theme)
        self.accept()

    def get_selected_theme(self) -> str:
        """获取选中的主题名称.

        Returns
        -------
            选中的主题名称
        """
        return self._selected_theme


def open_theme_selector(
    parent: QWidget | None = None,
    current_theme: str = "",
) -> str | None:
    """显示主题选择器对话框.

    Args:
        parent: 父窗口
        current_theme: 当前应用的主题名称

    Returns
    -------
        选中的主题名称,如果取消则返回 None
    """
    dialog = ThemeSelectorDialog(parent, current_theme)
    result = dialog.exec()  # type: ignore[attr-defined]

    if result == QDialog.Accepted:
        return dialog.get_selected_theme()
    return None
