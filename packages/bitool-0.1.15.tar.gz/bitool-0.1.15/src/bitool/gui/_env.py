"""PySide 环境管理器."""

from __future__ import annotations

import os
from pathlib import Path
from typing import ClassVar

from bitool.core import logger

from .compat import PYSIDE_DIR, QApplication


class _PySideEnv:
    """PySide 环境管理器.

    特性:
        - 支持 PySide2 和 PySide6.
        - 采取统一的接口, 自动检测并初始化 PySide2 或 PySide6.
    """

    _initialized: ClassVar[bool] = False
    _chinese_fonts: ClassVar[list[str]] = [
        # Windows 系统字体
        "Microsoft YaHei",
        "Microsoft YaHei UI",
        "Segoe UI",
        # Linux/WSL 中文字体
        "WenQuanYi Micro Hei",
        "WenQuanYi Zen Hei",
        "Noto Sans CJK SC",
        "Source Han Sans SC",
        "AR PL UMing CN",
        "AR PL UKai CN",
        # macOS 字体
        "PingFang SC",
    ]

    @classmethod
    def setup_env(cls) -> None:
        """初始化 PySide2 环境."""
        if cls._initialized:
            logger.warning("PySide 环境已初始化, 跳过.")
            return

        if not PYSIDE_DIR:
            logger.error("未找到 PySide 安装目录,请安装 PySide2 / PySide6")
            return

        logger.debug("开始初始化 PySide 环境.")

        plugins_path = PYSIDE_DIR / "plugins"
        if plugins_path.exists():
            qt_plugins_path = str(plugins_path.absolute()).strip()
            logger.debug(f"PySide 插件路径: {qt_plugins_path}")
            os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = qt_plugins_path
            os.environ["QT_PLUGIN_PATH"] = qt_plugins_path
        else:
            logger.warning("未找到 PySide 插件路径")

        cls._setup_chinese_fonts()

        cls._initialized = True
        logger.debug("PySide 环境初始化完成.")

    @staticmethod
    def _is_internal_path(file_path: Path) -> bool:
        """判断是否为内部路径(需要跳过的路径)."""
        path_str = str(file_path)

        # bitool.gui 内部（支持跨平台路径格式）
        if "bitool.gui" in path_str:
            return True

        # Python 标准库和虚拟环境
        internal_keywords = [".venv", "python", "anaconda", "<frozen"]
        return any(keyword in path_str.lower() for keyword in internal_keywords)

    @classmethod
    def _setup_chinese_fonts(cls) -> None:
        """设置中文字体."""
        app = QApplication.instance()
        if app is None:
            # 如果 QApplication 还未创建,通过环境变量设置
            # 注意:QT_DEFAULT_FONT_FAMILY 只在某些 Qt 版本中有效
            os.environ["QT_DEFAULT_FONT_FAMILY"] = cls._chinese_fonts[0]
            logger.debug(
                f"通过 QT_DEFAULT_FONT_FAMILY 设置中文字体:`{cls._chinese_fonts[0]}`",
            )
            return

        # 如果 QApplication 已经创建,直接设置字体
        # 注意:QApplication.instance() 返回 QCoreApplication*,需要类型转换
        # 使用 duck typing 检查,避免测试环境中 mock 对象的 isinstance 问题
        if hasattr(app, "font") and hasattr(app, "setFont"):
            try:
                # 获取应用程序的默认字体
                # 使用 QApplication.font() 类方法获取默认字体
                font = QApplication.font()
                # 尝试设置第一个可用的中文字体
                for font_name in cls._chinese_fonts:
                    font.setFamily(font_name)
                    # Qt 会自动回退到最接近的匹配,所以设置第一个即可
                    break

                QApplication.setFont(font)
                logger.info(f"已配置中文字体:`{cls._chinese_fonts[0]}`")
                logger.info(f"可用中文字体优先级列表:`{cls._chinese_fonts}`")
            except (AttributeError, TypeError) as e:
                logger.warning(f"设置字体时发生错误:{e}")


setup_pyside2_env = _PySideEnv.setup_env
setup_pyside2_env()
