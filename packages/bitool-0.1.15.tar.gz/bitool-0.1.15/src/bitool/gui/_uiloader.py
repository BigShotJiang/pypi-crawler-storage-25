"""动态 UI 加载器模块.

提供从 .ui 文件动态加载界面的功能,避免维护 .ui 和 .py 两套文件.

使用示例:
    # 方式 1: 自动查找 .ui 文件(推荐)
    from bitool.gui import load_ui

    class MyWidget(QWidget):
        def __init__(self):
            super().__init__()
            load_ui(parent=self)  # 自动查找 mywidget.ui

    # 方式 2: 手动指定 .ui 文件
    from bitool.gui import UILoader

    loader = UILoader(base_path=Path('/path/to/ui/files'))
    widget = loader.load_ui('custom.ui')

    # 方式 3: 兼容现有 setupUi 模式
    from bitool.gui import setup_ui

    class MyWidget(QWidget):
        def __init__(self):
            super().__init__()
            setup_ui(self)  # 自动查找并应用 mywidget.ui
"""

from __future__ import annotations

import inspect
import re
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from types import FrameType


from bitool.core import logger

from .compat import (
    QFile,
    QIODevice,
    QMainWindow,
    QObject,
    QUiLoader,
    QWebEngineView,
    QWidget,
    _use_uic_loader,
)

__all__ = ["clear_ui_cache", "load_ui", "setup_ui"]

# 常量
_UI_SUFFIXES_TO_REMOVE = ["_ui", "_widget"]


class _CustomUiLoader(QUiLoader):
    """自定义 UI 加载器，支持自定义控件提升."""

    # 自定义控件映射
    _custom_widgets = {
        "QWebEngineView": QWebEngineView,
    }

    def createWidget(self, className: str, parent: QWidget | None = None, name: str = "") -> QWidget:
        """创建自定义控件.

        Parameters
        ----------
        className : str
            控件类名
        parent : QWidget, optional
            父控件
        name : str, optional
            控件名称

        Returns
        -------
        QWidget
            创建的控件实例
        """
        # 检查是否是自定义控件
        if className in self._custom_widgets:
            widget_class = self._custom_widgets[className]
            widget = widget_class(parent)
            if name:
                widget.setObjectName(name)
            return widget

        # 否则使用默认的创建逻辑
        return super().createWidget(className, parent, name)


class UILoader:
    """动态 UI 加载器.

    提供从 .ui 文件动态加载界面的功能,支持自动查找和手动指定两种方式.

    Parameters
    ----------
    base_path : Path or str, optional
        基础路径,用于相对路径查找 .ui 文件

    Attributes
    ----------
    loader : QUiLoader
        Qt UI 加载器实例
    _cache : dict
        UI 文件缓存,键为文件路径和修改时间
    base_path : Path or None
        基础路径
    """

    def __init__(self, base_path: Path | str | None = None) -> None:
        """初始化UI加载器。

        Args:
            base_path: 基础路径,用于相对路径查找.ui文件
        """
        self.loader = _CustomUiLoader()
        self._cache: dict[str, QWidget] = {}
        self.base_path = Path(base_path) if base_path else None

    def _find_ui_file(
        self,
        ui_file: Path | str | None,
        caller_frame: FrameType,
    ) -> Path:
        """查找 UI 文件.

        查找优先级:
        1. 如果 ui_file 是绝对路径,直接使用
        2. 如果 ui_file 是相对路径,相对于 base_path 查找
        3. 如果 ui_file 为 None,自动查找调用者同名 .ui 文件

        Parameters
        ----------
        ui_file : Path, str, or None
            UI 文件路径,可以是绝对路径、相对路径或 None
        caller_frame : FrameType
            调用者帧对象

        Returns
        -------
        Path
            UI 文件的绝对路径

        Raises
        ------
        FileNotFoundError
            无法找到 UI 文件时抛出
        """
        if ui_file is None:
            caller_module = inspect.getmodule(caller_frame)
            if caller_module and caller_module.__file__:
                base_name = Path(caller_module.__file__).stem
                # 移除可能的后缀如 '_ui', '_widget' 等
                clean_name = base_name
                for suffix in _UI_SUFFIXES_TO_REMOVE:
                    clean_name = clean_name.replace(suffix, "")
                candidate = Path(caller_module.__file__).parent / f"{clean_name}.ui"
                if candidate.exists():
                    logger.info(f"自动找到UI文件: {candidate}")
                    return candidate
            raise FileNotFoundError(
                "无法自动找到.ui文件,请确保.py文件同级目录存在同名.ui文件",
            )

        ui_path = Path(ui_file)
        if not ui_path.is_absolute():
            ui_path = (self.base_path or Path.cwd()) / ui_path

        if not ui_path.exists():
            msg = f"UI文件不存在: {ui_path}"
            raise FileNotFoundError(msg)

        logger.info(f"找到UI文件: {ui_path}")
        return ui_path

    def _get_cache_key(self, ui_file: Path) -> str:
        """生成缓存键.

        使用文件路径和修改时间作为缓存键,确保文件修改后能自动重新加载.

        Parameters
        ----------
        ui_file : Path
            UI 文件路径

        Returns
        -------
        str
            缓存键字符串
        """
        return f"{ui_file.absolute()}:{ui_file.stat().st_mtime}"

    def _resolve_resources(self, ui_file: Path) -> None:
        """解析并注册 UI 文件引用的资源文件.

        读取 .ui 文件中的 qrc 引用，并尝试使用 QRCLoader 加载.

        Parameters
        ----------
        ui_file : Path
            UI 文件路径
        """
        # 读取.ui文件,查找qrc引用
        try:
            ui_content = ui_file.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as e:
            logger.warning(f"读取UI文件失败,无法解析资源: {e}")
            return

        # 查找 <include location="xxx.qrc"/> 格式的引用
        qrc_refs = re.findall(r'<include\s+location="([^"]+\.qrc)"/>', ui_content)

        from ._qrcloader import QRCLoader

        qrc_loader = QRCLoader(base_path=ui_file.parent)

        for qrc_ref in qrc_refs:
            qrc_path = (ui_file.parent / qrc_ref).resolve()

            # 使用 QRCLoader 加载资源
            if qrc_loader.load_qrc(qrc_path):
                logger.debug(f"已加载资源文件: {qrc_path}")
            else:
                logger.warning(f"加载资源文件失败: {qrc_path}")

    def load_ui(
        self,
        ui_file: Path | str | None = None,
        parent: QWidget | None = None,
    ) -> QWidget:
        """动态加载 UI 文件.

        Parameters
        ----------
        ui_file : Path, str, or None, optional
            UI 文件路径,可以是绝对路径、相对路径或 None(自动查找)
        parent : QWidget, optional
            父 widget

        Returns
        -------
        QWidget
            加载的 widget 实例

        Raises
        ------
        FileNotFoundError
            找不到 UI 文件时抛出
        RuntimeError
            加载 UI 文件失败时抛出
        """
        caller_frame = inspect.currentframe()
        if caller_frame is None or caller_frame.f_back is None:
            raise RuntimeError("无法获取调用者信息")

        # 当ui_file已指定时,不需要查找调用者来确定UI文件路径
        if ui_file is not None:
            # 直接使用传入的ui_file,跳过帧查找
            ui_path = self._find_ui_file(ui_file, caller_frame.f_back)
        else:
            # 跳过_uiloader.py内部的帧,找到真正的外部调用者
            target_frame = caller_frame.f_back
            while target_frame is not None:
                frame_module = inspect.getmodule(target_frame)
                if frame_module is None or not frame_module.__file__:
                    target_frame = target_frame.f_back
                    continue
                # 如果帧来自_uiloader.py,继续往上找
                if Path(frame_module.__file__).name == "_uiloader.py":
                    target_frame = target_frame.f_back
                else:
                    break

            if target_frame is None:
                # 如果找不到外部调用者，使用第一级调用者
                target_frame = caller_frame.f_back

            ui_path = self._find_ui_file(ui_file, target_frame)

        # 解析资源
        self._resolve_resources(ui_path)

        # 检查缓存 - 但仅在没有parent或parent与缓存中相同时使用缓存
        cache_key = self._get_cache_key(ui_path)
        if cache_key in self._cache and (parent is None or parent == self._cache.get(cache_key)):
            logger.debug(f"从缓存加载UI: {ui_path}")
            return self._cache[cache_key]

        # 加载 UI 文件
        if _use_uic_loader:
            # PyQt5: 先用 QFile.open 验证文件可读性（保持测试 mock 兼容性），再调用 uic.loadUi
            file = QFile(str(ui_path))
            if not file.open(QIODevice.ReadOnly):  # type: ignore[arg-type]
                msg = f"无法打开UI文件: {ui_path}"
                raise RuntimeError(msg)
            widget = self.loader.load(str(ui_path), parent)
        else:
            # PySide2/PySide6: 使用 QFile + QUiLoader
            file = QFile(str(ui_path))
            if not file.open(QIODevice.ReadOnly):  # type: ignore[arg-type]
                msg = f"无法打开UI文件: {ui_path}"
                raise RuntimeError(msg)
            widget = self.loader.load(file, parent)
            file.close()

        if widget is None:
            msg = f"加载UI文件失败: {ui_path}"
            raise RuntimeError(msg)

        # 如果有parent且widget与parent不是同一个对象,需要将widget的布局和子控件转移到parent
        if parent is not None and widget != parent:
            if isinstance(parent, QMainWindow):
                # QMainWindow 特殊处理：获取 centralWidget 并重新设置
                central_widget = widget.findChild(QWidget, "centralwidget")
                if central_widget is not None:
                    # 保存 centralWidget 的布局和子控件信息
                    central_widget.layout()  # type: ignore[union-attr]
                    children_info = [
                        (child.objectName(), child)
                        for child in central_widget.findChildren(QObject)  # type: ignore[union-attr]
                        if child.objectName() and not child.objectName().startswith("_")
                    ]

                    # 从原 widget 中移除 centralWidget
                    # 通过设置临时父对象来解除关系，避免直接传 None
                    temp_parent = QWidget()
                    central_widget.setParent(temp_parent)  # type: ignore[union-attr]
                    temp_parent.deleteLater()

                    # 设置到 parent
                    parent.setCentralWidget(central_widget)  # type: ignore[arg-type]
                    # 将 central_widget 的子控件作为 parent 的属性
                    for name, child in children_info:
                        setattr(parent, name, child)
                # 注意：不要调用 widget.hide()，因为设置 centralWidget 后原 widget 可能已被删除
            else:
                # 普通 QWidget：将 widget 的布局应用到 parent
                if widget.layout() is not None:
                    parent.setLayout(widget.layout())

                # 将 widget 的命名子控件作为 parent 的属性
                children = widget.findChildren(QObject)
                for child in children:
                    if child.objectName() and not child.objectName().startswith("_"):
                        setattr(parent, child.objectName(), child)

            if not isinstance(parent, QMainWindow):
                widget.hide()
            # 缓存 parent 而不是隐藏的 widget
            self._cache[cache_key] = parent
            logger.debug(f"动态加载 UI: {ui_path}")
            return parent
        else:
            if widget == parent and parent is not None:
                for child in parent.findChildren(QObject):
                    if child.objectName() and not child.objectName().startswith("_"):
                        setattr(parent, child.objectName(), child)
            self._cache[cache_key] = widget
            logger.debug(f"动态加载 UI: {ui_path}")
            return widget

    def setup_ui(self, widget: QWidget, ui_file: Path | str | None = None) -> None:
        """将 UI 加载到现有 widget.

        兼容现有的 setupUi 模式,将 .ui 文件中的控件作为属性添加到 widget.

        Parameters
        ----------
        widget : QWidget
            目标 widget
        ui_file : Path, str, or None, optional
            UI 文件路径,可以是绝对路径、相对路径或 None(自动查找)

        Raises
        ------
        FileNotFoundError
            找不到 UI 文件时抛出
        RuntimeError
            加载 UI 文件失败时抛出
        """
        self.load_ui(ui_file, widget)

        # 复制子控件和布局到widget
        # QUiLoader已经设置了widget的布局和子控件
        # 我们只需要将命名的子控件作为属性添加到widget
        for child in widget.findChildren(QObject):
            if child.objectName() and not child.objectName().startswith("_"):
                setattr(widget, child.objectName(), child)

    def clear_cache(self) -> None:
        """清除缓存.

        当 .ui 文件被修改后,可以调用此方法清除缓存以重新加载.
        """
        self._cache.clear()
        logger.debug("UI加载器缓存已清除")


# 模块级别的默认加载器实例
_default_loader = UILoader()


def load_ui(
    ui_file: Path | str | None = None,
    parent: QWidget | None = None,
) -> QWidget:
    """便捷函数:加载UI文件。

    Args:
        ui_file: UI文件路径,可以是绝对路径、相对路径或None(自动查找)
        parent: 父widget

    Returns:
        加载的widget实例
    """
    return _default_loader.load_ui(ui_file, parent)


def setup_ui(widget: QWidget, ui_file: Path | str | None = None) -> None:
    """便捷函数:将UI设置到现有widget。

    Args:
        widget: 目标widget
        ui_file: UI文件路径,可以是绝对路径、相对路径或None(自动查找)
    """
    _default_loader.setup_ui(widget, ui_file)


def clear_ui_cache() -> None:
    """便捷函数:清除UI加载器缓存。"""
    _default_loader.clear_cache()
