"""Pytest fixtures for GUI test isolation.

此模块提供Qt测试环境的隔离机制,确保每个测试在干净的环境中运行。
主要解决以下问题:
- 单例模式状态污染(_PySide2Env, _HighDPIManager, ThemeManager)
- Qt模块全局状态污染(QApplication实例、环境变量)
- sys.path污染(调用者路径注入)
- 环境变量污染(QT_*系列变量)
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Generator

import pytest

if TYPE_CHECKING:
    from bitool.gui.compat import QApplication

if TYPE_CHECKING:
    pass


@pytest.fixture(autouse=True)
def reset_gui_singletons() -> Generator[None, None, None]:
    """在每个测试前后重置GUI模块的单例状态。

    确保每个测试开始时单例处于未初始化状态,测试结束后恢复原状态。
    此fixture自动应用于所有gui/tests/下的测试。
    """
    import bitool.gui._env as env_module
    import bitool.gui._highdpi as highdpi_module

    # 保存原始状态
    original_env_initialized = env_module._PySideEnv._initialized
    original_highdpi_initialized = highdpi_module._HighDPIManager._initialized
    original_highdpi_scale = highdpi_module._HighDPIManager._scale_factor
    original_highdpi_is_high = highdpi_module._HighDPIManager._is_high_dpi

    # 保存原始环境变量
    original_env_vars = {
        "QT_QPA_PLATFORM_PLUGIN_PATH": os.environ.get("QT_QPA_PLATFORM_PLUGIN_PATH"),
        "QT_PLUGIN_PATH": os.environ.get("QT_PLUGIN_PATH"),
        "QT_DEFAULT_FONT_FAMILY": os.environ.get("QT_DEFAULT_FONT_FAMILY"),
    }

    # 保存原始sys.path
    original_sys_path = list(sys.path)

    try:
        # 测试前:重置单例状态
        env_module._PySideEnv._initialized = False
        highdpi_module._HighDPIManager._initialized = False
        highdpi_module._HighDPIManager._scale_factor = 1.0
        highdpi_module._HighDPIManager._is_high_dpi = False

        # 清除Qt相关环境变量
        for key in [
            "QT_QPA_PLATFORM_PLUGIN_PATH",
            "QT_PLUGIN_PATH",
            "QT_DEFAULT_FONT_FAMILY",
        ]:
            os.environ.pop(key, None)

        yield

    finally:
        # 测试后:恢复原始状态
        env_module._PySideEnv._initialized = original_env_initialized
        highdpi_module._HighDPIManager._initialized = original_highdpi_initialized
        highdpi_module._HighDPIManager._scale_factor = original_highdpi_scale
        highdpi_module._HighDPIManager._is_high_dpi = original_highdpi_is_high

        # 恢复环境变量
        for key, value in original_env_vars.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value

        # 恢复sys.path(移除测试中添加的路径)
        sys.path[:] = original_sys_path


@pytest.fixture
def themes_dir() -> Path:
    """获取themes目录路径。

    Returns
    -------
        themes目录的Path对象
    """
    return Path(__file__).parent.parent / "stylesheets"


def qapplication() -> QApplication | None:
    """提供QApplication实例用于需要真实Qt环境的测试。

    注意:此fixture会创建真实的QApplication实例,仅在需要真实Qt行为时使用。
    大多数测试应该使用mock_qapplication或isolated_qt_env。

    Yields
    ------
        QApplication实例或None(如果Qt不可用)
    """

    app = QApplication.instance()
    if app is not None:
        return app

    # 创建新实例(需要sys.argv)
    import sys

    app = QApplication(sys.argv)
    return app
