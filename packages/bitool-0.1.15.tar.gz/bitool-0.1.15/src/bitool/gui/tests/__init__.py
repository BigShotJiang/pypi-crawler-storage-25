"""bitool.gui 包的测试模块."""
