"""简化的 QSS 主题系统测试."""

import threading
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

# 使用绝对路径导入
from bitool.gui._themes import ThemeManager


class TestThemeManager:
    """测试 ThemeManager."""

    @pytest.fixture
    def manager(self) -> ThemeManager:
        """创建主题管理器实例."""
        return ThemeManager()

    def test_singleton_instance(self) -> None:
        """测试 ThemeManager 是模块级单例."""
        from bitool.gui._themes import _theme_manager

        mgr1 = _theme_manager
        mgr2 = _theme_manager
        assert mgr1 is mgr2

    def test_get_instance_thread_safe(self) -> None:
        """测试模块级实例的线程安全性."""
        from bitool.gui._themes import _theme_manager

        instances = []

        def get_instance() -> None:
            instances.append(_theme_manager)

        # 创建多个线程访问同一实例
        threads = [threading.Thread(target=get_instance) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # 所有都应该是同一实例
        assert len({id(inst) for inst in instances}) == 1

    def test_list_themes(self, manager: ThemeManager) -> None:
        """测试列出可用主题."""
        themes = manager.list_themes()
        # 应该至少有一些来自样式表目录的主题
        assert isinstance(themes, list)
        assert len(themes) > 0
        # 检查一些常见的主题名是否存在
        assert "aqua" in themes or len(themes) > 0  # 至少应该存在一个主题

    def test_apply_theme_invalid(self, manager: ThemeManager) -> None:
        """测试应用无效主题."""
        mock_widget = MagicMock()

        success = manager.apply_theme(mock_widget, "nonexistent_theme")

        # 应该优雅失败
        assert success is False

    def test_apply_theme_none_widget(self, manager: ThemeManager) -> None:
        """测试应用 None 控件的主题."""
        success = manager.apply_theme(None, "aqua")  # type: ignore[arg-type]
        assert success is False

    def test_apply_theme_empty_name(self, manager: ThemeManager) -> None:
        """测试应用空名称的主题."""
        mock_widget = MagicMock()
        success = manager.apply_theme(mock_widget, "")
        assert success is False

    def test_apply_theme_valid(self, manager: ThemeManager, themes_dir: Path) -> None:
        """测试应用有效主题."""
        mock_widget = MagicMock()
        success = manager.apply_theme(mock_widget, "aqua")

        # 应该成功
        assert success is True
        mock_widget.setStyleSheet.assert_called_once()

    def test_apply_theme_from_subthread(self, manager: ThemeManager) -> None:
        """测试从子线程应用主题(应该失败)."""
        mock_widget = MagicMock()
        result = {"success": None}

        def apply_in_thread() -> None:
            result["success"] = manager.apply_theme(mock_widget, "aqua")

        thread = threading.Thread(target=apply_in_thread)
        thread.start()
        thread.join()

        # 应该失败,因为 Qt 操作必须在主线程
        assert result["success"] is False

    def test_list_themes_returns_sorted_list(self, manager: ThemeManager) -> None:
        """测试 list_themes 返回排序列表."""
        themes = manager.list_themes()
        assert themes == sorted(themes)

    def test_multiple_instances_share_state(self) -> None:
        """测试模块级单例在多次导入时保持一致."""
        from bitool.gui._themes import _theme_manager

        mgr1 = _theme_manager
        mgr2 = _theme_manager

        # 模块级单例应该返回同一实例
        assert mgr1 is mgr2

    def test_has_theme_existing(self, manager: ThemeManager, themes_dir: Path) -> None:
        """测试 has_theme 对已存在主题的检测."""
        assert manager.has_theme("aqua") is True

    def test_has_theme_nonexisting(self, manager: ThemeManager) -> None:
        """测试 has_theme 对不存在主题的检测."""
        assert manager.has_theme("nonexistent_theme_xyz") is False

    def test_get_theme_count(self, manager: ThemeManager, themes_dir: Path) -> None:
        """测试 get_theme_count 返回正确数量."""
        # 统计实际主题文件(排除 base_structure.qss 和 *_colors.qss)
        qss_files = [
            f
            for f in themes_dir.glob("*.qss")
            if f.name != "base_structure.qss" and not f.name.endswith("_colors.qss")
        ]
        # 添加来自 *_colors.qss 文件的主题
        color_files = list(themes_dir.glob("*_colors.qss"))
        expected_count = len(qss_files) + len(color_files)
        count = manager.get_theme_count()
        assert count == expected_count

    def test_get_theme_files_returns_copy(self, manager: ThemeManager) -> None:
        """测试 get_theme_files 返回副本."""
        files1 = manager.get_theme_files()
        files2 = manager.get_theme_files()

        # 应该是不同的对象
        assert files1 is not files2
        # 但包含相同数据
        assert files1 == files2

    def test_generate_qss_valid_theme(
        self,
        manager: ThemeManager,
        themes_dir: Path,
    ) -> None:
        """测试 _generate_qss 对有效主题的处理."""
        qss = manager._generate_qss("aqua")
        assert isinstance(qss, str)
        assert len(qss) > 0
        # 应该包含 Qt 样式表语法
        assert "QWidget" in qss or "QPushButton" in qss or "{" in qss

    def test_generate_qss_invalid_theme(self, manager: ThemeManager) -> None:
        """测试 _generate_qss 对无效主题的处理."""
        qss = manager._generate_qss("nonexistent_theme_xyz")
        assert not qss

    def test_load_available_themes_empty_directory(self) -> None:
        """测试 _load_available_themes 在目录不存在时的行为."""
        # 创建不加载主题的管理器
        manager = object.__new__(ThemeManager)
        manager._theme_files = {}
        manager._lock = threading.Lock()

        with patch("bitool.gui._themes._STYLESHEETS_DIR") as mock_dir:
            mock_dir.exists.return_value = False
            mock_dir.glob.return_value = []

            # 不应该抛出异常,只记录警告
            manager._load_available_themes()

            # 应该没有主题
            assert manager.get_theme_count() == 0

    def test_thread_safety_list_themes(self, manager: ThemeManager) -> None:
        """测试 list_themes 的线程安全性."""
        results = []

        def list_themes() -> None:
            # 减少迭代次数
            results.extend(manager.list_themes() for _ in range(5))

        threads = [threading.Thread(target=list_themes) for _ in range(2)]  # 减少线程数
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # 所有结果都应该是列表
        assert all(isinstance(r, list) for r in results)

    def test_thread_safety_has_theme(self, manager: ThemeManager) -> None:
        """测试 has_theme 的线程安全性."""
        results = []

        def check_theme() -> None:
            # 减少迭代次数
            results.extend(manager.has_theme("aqua") for _ in range(5))

        threads = [threading.Thread(target=check_theme) for _ in range(2)]  # 减少线程数
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # 所有结果都应该是布尔值
        assert all(isinstance(r, bool) for r in results)

    def test_generate_qss_file_read_error(
        self,
        manager: ThemeManager,
        themes_dir: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """测试文件读取失败时 _generate_qss 的行为."""
        # 模拟 open 方法抛出错误
        original_open = Path.open

        def mock_open(self: Path, *args: Any, **kwargs: Any) -> Any:
            if self.name == "aqua_colors.qss":
                msg = "模拟读取错误"
                raise FileNotFoundError(msg)
            return original_open(self, *args, **kwargs)

        monkeypatch.setattr(Path, "open", mock_open)

        qss = manager._generate_qss("aqua")
        assert not qss

    def test_apply_theme_widget_error(
        self,
        manager: ThemeManager,
        themes_dir: Path,
    ) -> None:
        """测试当 widget.setStyleSheet 抛出错误时 apply_theme 的行为."""
        mock_widget = MagicMock()
        mock_widget.setStyleSheet.side_effect = RuntimeError("模拟 setStyleSheet 错误")

        success = manager.apply_theme(mock_widget, "aqua")
        assert success is False


class TestThemeConfiguration:
    """测试主题配置文件."""

    def test_stylesheets_directory_exists(self, themes_dir: Path) -> None:
        """测试样式表目录存在."""
        assert themes_dir.exists()
        assert themes_dir.is_dir()

    def test_qss_files_exist(self, themes_dir: Path) -> None:
        """测试至少存在一些 QSS 文件."""
        qss_files = list(themes_dir.glob("*.qss"))
        assert len(qss_files) > 0, "样式表目录中未找到 QSS 文件"

    def test_aqua_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 aqua_colors.qss 存在."""
        assert (themes_dir / "aqua_colors.qss").exists()

    def test_dracula_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 dracula_colors.qss 存在."""
        assert (themes_dir / "dracula_colors.qss").exists()

    def test_gruvbox_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 gruvbox_colors.qss 存在."""
        assert (themes_dir / "gruvbox_colors.qss").exists()

    def test_monokai_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 monokai_colors.qss 存在."""
        assert (themes_dir / "monokai_colors.qss").exists()

    def test_nord_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 nord_colors.qss 存在."""
        assert (themes_dir / "nord_colors.qss").exists()

    def test_onedark_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 onedark_colors.qss 存在."""
        assert (themes_dir / "onedark_colors.qss").exists()

    def test_tokyo_night_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 tokyo_night_colors.qss 存在."""
        assert (themes_dir / "tokyo_night_colors.qss").exists()

    def test_vitesse_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 vitesse_colors.qss 存在."""
        assert (themes_dir / "vitesse_colors.qss").exists()

    def test_catppuccin_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 catppuccin_colors.qss 存在."""
        assert (themes_dir / "catppuccin_colors.qss").exists()

    def test_material_dark_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 material_dark_colors.qss 存在."""
        assert (themes_dir / "material_dark_colors.qss").exists()

    def test_consolestyle_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 consolestyle_colors.qss 存在."""
        assert (themes_dir / "consolestyle_colors.qss").exists()

    def test_elegantdark_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 elegantdark_colors.qss 存在."""
        assert (themes_dir / "elegantdark_colors.qss").exists()

    def test_elegantpurple_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 elegantpurple_colors.qss 存在."""
        assert (themes_dir / "elegantpurple_colors.qss").exists()

    def test_synthwave_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 synthwave_colors.qss 存在."""
        assert (themes_dir / "synthwave_colors.qss").exists()

    def test_freshgreen_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 freshgreen_colors.qss 存在."""
        assert (themes_dir / "freshgreen_colors.qss").exists()

    def test_warmorange_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 warmorange_colors.qss 存在."""
        assert (themes_dir / "warmorange_colors.qss").exists()

    def test_professionalblue_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 professionalblue_colors.qss 存在."""
        assert (themes_dir / "professionalblue_colors.qss").exists()

    def test_high_contrast_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 high_contrast_colors.qss 存在."""
        assert (themes_dir / "high_contrast_colors.qss").exists()

    def test_macos_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 macos_colors.qss 存在."""
        assert (themes_dir / "macos_colors.qss").exists()

    def test_ubuntu_colors_qss_exists(self, themes_dir: Path) -> None:
        """测试 ubuntu_colors.qss 存在."""
        assert (themes_dir / "ubuntu_colors.qss").exists()

    def test_qss_file_valid(self, themes_dir: Path) -> None:
        """测试 QSS 文件有效且可读."""
        qss_file = themes_dir / "aqua_colors.qss"

        with qss_file.open("r", encoding="utf-8") as f:
            content = f.read()

        # 应该有内容
        assert len(content) > 0
        # 应该包含颜色变量语法
        assert "BG_PRIMARY:" in content or "FG_PRIMARY:" in content

    def test_qss_file_size_reasonable(self, themes_dir: Path) -> None:
        """测试 QSS 文件大小合理."""
        qss_files = list(themes_dir.glob("*.qss"))

        for qss_file in qss_files:
            size_kb = qss_file.stat().st_size / 1024
            # 每个 QSS 文件至少 1KB
            assert size_kb >= 1.0, f"{qss_file.name} 太小 ({size_kb:.1f}KB)"
            # 且不超过 1MB
            assert size_kb < 1024.0, f"{qss_file.name} 太大 ({size_kb:.1f}KB)"

    def test_all_qss_files_readable(self, themes_dir: Path) -> None:
        """测试所有 QSS 文件可读."""
        qss_files = list(themes_dir.glob("*.qss"))

        for qss_file in qss_files:
            with qss_file.open("r", encoding="utf-8") as f:
                content = f.read()
            assert len(content) > 0, f"{qss_file.name} 为空"

    def test_no_duplicate_theme_names(self, themes_dir: Path) -> None:
        """测试没有重复的主题名称."""
        qss_files = list(themes_dir.glob("*.qss"))
        theme_names = [f.stem for f in qss_files]

        # 检查重复
        assert len(theme_names) == len(set(theme_names)), "发现重复的主题名称"

    def test_theme_manager_loads_all_themes(self, themes_dir: Path) -> None:
        """测试主题管理器加载所有可用主题."""
        # 创建新管理器实例测试加载
        fresh_manager = ThemeManager()

        # 构建预期主题:传统 QSS 文件 + 基于颜色的主题
        qss_files = [
            f
            for f in themes_dir.glob("*.qss")
            if f.name != "base_structure.qss" and not f.name.endswith("_colors.qss")
        ]
        expected_themes = {f.stem for f in qss_files}

        # 添加来自 *_colors.qss 文件的主题
        color_files = themes_dir.glob("*_colors.qss")
        for cf in color_files:
            theme_name = cf.stem.replace("_colors", "")
            expected_themes.add(theme_name)

        loaded_themes = set(fresh_manager.list_themes())

        assert expected_themes == loaded_themes

    def test_load_available_themes_oserror(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """测试发生 OSError 时 _load_available_themes 的行为."""
        import pathlib

        # 创建不加载主题的管理器
        manager = object.__new__(ThemeManager)
        manager._theme_files = {}
        manager._lock = threading.Lock()

        # 模拟 pathlib.Path.glob 抛出 OSError
        original_glob = pathlib.Path.glob

        def mock_glob(self: pathlib.Path, pattern: str) -> Any:
            if "stylesheets" in str(self):
                msg = "模拟目录访问错误"
                raise OSError(msg)
            return original_glob(self, pattern)

        monkeypatch.setattr(pathlib.Path, "glob", mock_glob)

        # 应该抛出 OSError 并记录错误
        with pytest.raises(OSError, match="模拟目录访问错误"):
            manager._load_available_themes()


class TestColorVariableParsing:
    """测试颜色变量解析和替换."""

    @pytest.fixture
    def manager(self) -> ThemeManager:
        """创建主题管理器实例."""
        return ThemeManager()

    def test_parse_color_variables_basic(self, manager: ThemeManager) -> None:
        """测试基本颜色变量解析."""
        content = """BG_PRIMARY: #ffffff;
FG_PRIMARY: #000000;
/* 这是一个注释 */
ACCENT_COLOR: #ff0000;
"""
        result = manager._parse_color_variables(content)
        assert result == {
            "BG_PRIMARY": "#ffffff",
            "FG_PRIMARY": "#000000",
            "ACCENT_COLOR": "#ff0000",
        }

    def test_parse_color_variables_skips_comments(self, manager: ThemeManager) -> None:
        """测试跳过注释."""
        content = """/* 注释行 */
BG_PRIMARY: #ffffff;
// 另一种注释风格
FG_PRIMARY: #000000;
"""
        result = manager._parse_color_variables(content)
        assert "BG_PRIMARY" in result
        assert "FG_PRIMARY" in result

    def test_parse_color_variables_skips_empty_lines(
        self,
        manager: ThemeManager,
    ) -> None:
        """测试跳过空行."""
        content = """

BG_PRIMARY: #ffffff;

FG_PRIMARY: #000000;

"""
        result = manager._parse_color_variables(content)
        assert len(result) == 2

    def test_parse_color_variables_invalid_format(self, manager: ThemeManager) -> None:
        """测试解析无效格式行."""
        content = """BG_PRIMARY #ffffff;
FG_PRIMARY: #000000
无效行
VALID_VAR: #123456;
"""
        result = manager._parse_color_variables(content)
        # 只有 VALID_VAR 应该被解析(有冒号和分号)
        assert "VALID_VAR" in result
        assert "BG_PRIMARY" not in result  # 缺少冒号
        assert "FG_PRIMARY" not in result  # 缺少分号

    def test_parse_color_variables_lowercase_rejected(
        self,
        manager: ThemeManager,
    ) -> None:
        """测试小写变量名被拒绝."""
        content = "bg_primary: #ffffff;\nBG_PRIMARY: #000000;"
        result = manager._parse_color_variables(content)
        assert "BG_PRIMARY" in result
        assert "bg_primary" not in result

    def test_replace_color_variables(self, manager: ThemeManager) -> None:
        """测试颜色变量替换."""
        qss_content = """
QWidget {
    background-color: BG_PRIMARY;
    color: FG_PRIMARY;
}
QPushButton {
    background-color: ACCENT_COLOR;
}
"""
        color_vars = {
            "BG_PRIMARY": "#ffffff",
            "FG_PRIMARY": "#000000",
            "ACCENT_COLOR": "#ff0000",
        }
        result = manager._replace_color_variables(qss_content, color_vars)
        assert "background-color: #ffffff;" in result
        assert "color: #000000;" in result
        assert "background-color: #ff0000;" in result

    def test_replace_color_variables_longer_vars_first(
        self,
        manager: ThemeManager,
    ) -> None:
        """测试较长变量名优先替换以避免部分匹配."""
        qss_content = "BG_COLOR_PRIMARY and BG_COLOR"
        color_vars = {"BG_COLOR": "#fff", "BG_COLOR_PRIMARY": "#000"}
        result = manager._replace_color_variables(qss_content, color_vars)
        # 应该先替换 BG_COLOR_PRIMARY,然后替换 BG_COLOR
        assert result == "#000 and #fff"


class TestGenerateQssWithStructure:
    """测试 _generate_qss_with_structure 方法."""

    @pytest.fixture
    def manager(self) -> ThemeManager:
        """创建主题管理器实例."""
        return ThemeManager()

    def test_generate_qss_with_structure_valid(
        self,
        manager: ThemeManager,
        themes_dir: Path,
    ) -> None:
        """测试生成带结构和颜色文件的 QSS."""
        # aqua 主题使用 aqua_colors.qss
        qss = manager._generate_qss_with_structure("aqua")
        assert isinstance(qss, str)
        assert len(qss) > 0
        # 应该包含 Qt 样式表语法
        assert "{" in qss and "}" in qss

    def test_generate_qss_with_structure_missing_color_file(
        self,
        manager: ThemeManager,
    ) -> None:
        """测试颜色文件不存在时的行为."""
        qss = manager._generate_qss_with_structure("nonexistent_theme")
        # 应该回退到 _generate_qss,返回空字符串
        assert not qss

    def test_generate_qss_with_structure_fallback(
        self,
        manager: ThemeManager,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """测试 base_structure.qss 不存在时的回退."""
        import bitool.gui._themes as themes_module

        original_base = themes_module._BASE_STRUCTURE_FILE

        # 临时使基础结构文件显示为不存在
        class MockPath:
            def __init__(self, original: Path) -> None:
                self.original = original

            def exists(self) -> bool:
                return False

            def __truediv__(self, other: str) -> Path:
                return self.original / other

        with monkeypatch.context() as m:
            m.setattr(themes_module, "_BASE_STRUCTURE_FILE", MockPath(original_base))
            # 应该回退到 _generate_qss
            qss = manager._generate_qss_with_structure("nonexistent_theme")
            assert not qss


class TestColorThemeApplication:
    """测试应用基于颜色的主题."""

    @pytest.fixture
    def manager(self) -> ThemeManager:
        """创建主题管理器实例."""
        return ThemeManager()

    def test_apply_color_theme(self, manager: ThemeManager) -> None:
        """测试应用基于颜色的主题(如 aqua)."""
        mock_widget = MagicMock()
        success = manager.apply_theme(mock_widget, "aqua")
        assert success is True
        mock_widget.setStyleSheet.assert_called_once()
        # 验证样式表包含替换后的颜色
        qss_call = mock_widget.setStyleSheet.call_args[0][0]
        assert isinstance(qss_call, str)
        assert len(qss_call) > 0

    def test_apply_traditional_theme(self, manager: ThemeManager) -> None:
        """测试应用传统完整 QSS 主题."""
        # 检查是否有传统主题(非基于颜色的)
        manager.list_themes()
        # 查找不使用 _colors.qss 的主题
        traditional_theme = None
        theme_files = manager.get_theme_files()
        for theme_name, file_path in theme_files.items():
            if not file_path.name.endswith("_colors.qss"):
                traditional_theme = theme_name
                break

        if traditional_theme:
            mock_widget = MagicMock()
            success = manager.apply_theme(mock_widget, traditional_theme)
            assert success is True
            mock_widget.setStyleSheet.assert_called_once()


class TestModuleLevelFunctions:
    """测试模块级便捷函数."""

    def test_apply_theme_function(self) -> None:
        """测试模块级 apply_theme 函数."""
        from bitool.gui._themes import apply_theme

        mock_widget = MagicMock()
        success = apply_theme(mock_widget, "aqua")
        assert success is True

    def test_list_themes_function(self) -> None:
        """测试模块级 list_themes 函数."""
        from bitool.gui._themes import list_themes

        themes = list_themes()
        assert isinstance(themes, list)
        assert len(themes) > 0

    def test_has_theme_function(self) -> None:
        """测试模块级 has_theme 函数."""
        from bitool.gui._themes import has_theme

        assert has_theme("aqua") is True
        assert has_theme("nonexistent_xyz") is False

    def test_get_theme_count_function(self) -> None:
        """测试模块级 get_theme_count 函数."""
        from bitool.gui._themes import get_theme_count

        count = get_theme_count()
        assert isinstance(count, int)
        assert count > 0

    def test_get_theme_files_function(self) -> None:
        """测试模块级 get_theme_files 函数."""
        from bitool.gui._themes import get_theme_files

        files = get_theme_files()
        assert isinstance(files, dict)
        assert len(files) > 0
        # 所有值应该是 Path 对象
        from pathlib import Path

        assert all(isinstance(v, Path) for v in files.values())
