"""PySide2 环境设置模块的测试."""

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

import bitool.gui._env as env_module
from bitool.gui.compat import _pyside_version


def _create_fake_pyside2_dir(tmp_path: Path, with_plugins: bool = True) -> Path:
    """创建模拟的 PySide2 目录结构.

    Args:
        tmp_path: pytest 临时路径.
        with_plugins: 是否创建 plugins 目录.

    Returns:
        PySide2 目录路径.
    """
    fake_pyside2_dir = tmp_path / _pyside_version
    fake_pyside2_dir.mkdir()
    if with_plugins:
        fake_plugins_dir = fake_pyside2_dir / "plugins"
        fake_plugins_dir.mkdir()
    return fake_pyside2_dir


def _create_mock_pyside2_module(pyside2_dir: Path) -> MagicMock:
    """创建模拟的 PySide2 模块.

    Args:
        pyside2_dir: PySide2 目录路径.

    Returns:
        模拟的 PySide2 模块.
    """
    mock_pyside2 = MagicMock()
    mock_pyside2.__file__ = str(pyside2_dir / "__init__.py")
    return mock_pyside2


class TestPySide2EnvClass:
    """测试 _PySide2Env 类."""

    def test_class_attributes_exist(self) -> None:
        """测试类属性是否存在."""
        assert hasattr(env_module._PySideEnv, "_initialized")
        assert hasattr(env_module._PySideEnv, "_chinese_fonts")
        assert isinstance(env_module._PySideEnv._chinese_fonts, list)
        assert len(env_module._PySideEnv._chinese_fonts) > 0

    def test_setup_env_method_exists(self) -> None:
        """测试 setup_env 方法是否存在."""
        assert hasattr(env_module._PySideEnv, "setup_env")
        assert callable(env_module._PySideEnv.setup_env)


class TestSetupPySide2Env:
    """测试 setup_pyside2_env 函数(从 _PySide2Env.setup_env 别名)."""

    def test_setup_pyside2_env_is_callable(self) -> None:
        """测试 setup_pyside2_env 是否可调用."""
        assert callable(env_module.setup_pyside2_env)

    def test_setup_pyside2_env_plugins_not_found(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        """测试插件目录不存在时的设置."""
        # 创建没有插件的模拟 PySide2 目录
        fake_pyside2_dir = _create_fake_pyside2_dir(tmp_path, with_plugins=False)

        mock_pyside2 = _create_mock_pyside2_module(fake_pyside2_dir)

        with patch.dict("sys.modules", {"PySide2": mock_pyside2}):
            env_module.setup_pyside2_env()

    def test_setup_pyside2_env_idempotent(self) -> None:
        """测试 setup_pyside2_env 可以被多次安全调用."""
        # 第一次调用 - 应该初始化
        env_module.setup_pyside2_env()
        assert env_module._PySideEnv._initialized is True

        # 第二次调用 - 应该跳过初始化
        env_module.setup_pyside2_env()
        # 仍然已初始化
        assert env_module._PySideEnv._initialized is True


class TestChineseFontsConfiguration:
    """测试中文字体配置."""

    def test_chinese_fonts_list_not_empty(self) -> None:
        """测试中文字体列表不为空."""
        fonts = env_module._PySideEnv._chinese_fonts
        assert len(fonts) > 0

    @pytest.mark.parametrize(
        "font_name",
        ["Microsoft YaHei", "Microsoft YaHei UI", "Segoe UI", "PingFang SC"],
    )
    def test_chinese_fonts_contains_windows_fonts(self, font_name: str) -> None:
        """测试中文字体列表包含 Windows 字体."""
        fonts = env_module._PySideEnv._chinese_fonts
        assert font_name in fonts

    def test_chinese_fonts_contains_linux_fonts(self) -> None:
        """测试中文字体列表包含 Linux 字体."""
        fonts = env_module._PySideEnv._chinese_fonts
        assert "WenQuanYi Micro Hei" in fonts or "Noto Sans CJK SC" in fonts

    def test_chinese_fonts_order(self) -> None:
        """测试 Windows 字体具有更高优先级."""
        fonts = env_module._PySideEnv._chinese_fonts
        # 第一个字体应该是 Microsoft YaHei (Windows 默认)
        assert fonts[0] == "Microsoft YaHei"


class TestSetupChineseFonts:
    """测试 _setup_chinese_fonts 方法."""

    def test_setup_chinese_fonts_without_qt(self) -> None:
        """测试 Qt 不可用时的字体设置."""
        with patch.dict(
            "sys.modules",
            {"PySide2.QtGui": None, "PySide2.QtWidgets": None},
        ), patch(
            "builtins.__import__",
            side_effect=ImportError("No module named 'PySide2'"),
        ):
            # Should not raise an exception
            env_module._PySideEnv._setup_chinese_fonts()

    def test_setup_chinese_fonts_no_qapplication(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """测试 QApplication 实例不存在时的字体设置."""
        # 保存原始 QApplication
        original_qapplication = getattr(env_module, "QApplication", None)

        try:
            # 创建 mock QApplication 类，instance 返回 None
            mock_qapplication_class = MagicMock()
            mock_qapplication_class.instance.return_value = None

            # 替换模块中的 QApplication
            monkeypatch.setattr(env_module, "QApplication", mock_qapplication_class)

            # 清除环境变量以确保测试干净
            if "QT_DEFAULT_FONT_FAMILY" in os.environ:
                del os.environ["QT_DEFAULT_FONT_FAMILY"]

            env_module._PySideEnv._setup_chinese_fonts()

            # 应设置环境变量
            assert "QT_DEFAULT_FONT_FAMILY" in os.environ
            assert (
                os.environ["QT_DEFAULT_FONT_FAMILY"]
                == env_module._PySideEnv._chinese_fonts[0]
            )
        finally:
            # 恢复原始 QApplication
            if original_qapplication is not None:
                monkeypatch.setattr(env_module, "QApplication", original_qapplication)

    def test_setup_chinese_fonts_with_qapplication(self) -> None:
        """测试 QApplication 实例存在时的字体设置."""
        mock_qfont = MagicMock()

        mock_qapp_instance = MagicMock()
        mock_qapp_instance.font.return_value = mock_qfont
        mock_qapp_instance.setFont = MagicMock()

        with patch.object(env_module, "QApplication") as mock_qapp_class:
            mock_qapp_class.instance.return_value = mock_qapp_instance
            mock_qapp_class.font.return_value = mock_qfont

            env_module._PySideEnv._setup_chinese_fonts()

            # QFont.setFamily 应该至少被调用一次
            assert mock_qfont.setFamily.call_count >= 1
            mock_qapp_class.setFont.assert_called_once()

    def test_setup_chinese_fonts_font_iteration(self) -> None:
        """测试字体设置遍历可用字体."""
        mock_qfont = MagicMock()

        mock_qapp_instance = MagicMock()
        mock_qapp_instance.font.return_value = mock_qfont
        mock_qapp_instance.setFont = MagicMock()

        with patch.object(env_module, "QApplication") as mock_qapp_class:
            mock_qapp_class.instance.return_value = mock_qapp_instance
            mock_qapp_class.font.return_value = mock_qfont

            env_module._PySideEnv._setup_chinese_fonts()

            # 应至少尝试第一个字体
            assert mock_qfont.setFamily.call_count >= 1
            # 第一次调用应该使用列表中的第一个字体
            mock_qfont.setFamily.assert_any_call(
                env_module._PySideEnv._chinese_fonts[0],
            )


class TestModuleExports:
    """测试模块导出."""

    def test_setup_pyside2_env_exported(self) -> None:
        """测试 setup_pyside2_env 是否被导出."""
        assert hasattr(env_module, "setup_pyside2_env")
        # 它们应该在功能上等价(都是 classmethod 引用)
        assert callable(env_module.setup_pyside2_env)
        assert callable(env_module._PySideEnv.setup_env)


class TestIsInternalPath:
    """测试 _is_internal_path 静态方法."""

    @pytest.mark.parametrize(
        "path_str,expected",
        [
            # bitool.gui 内部路径
            ("d:\\_dev\\pytola\\pytola-qtstyles\\bitool.gui\\test.py", True),
            # venv 路径
            ("d:\\_dev\\pytola\\.venv\\Lib\\site-packages\\test.py", True),
            # Python 安装路径
            ("C:\\Python38\\Lib\\test.py", True),
            # conda 路径
            ("C:\\Users\\user\\anaconda3\\Lib\\test.py", True),
            # frozen 路径
            ("<frozen importlib._bootstrap>", True),
            # 外部路径(非内部)
            ("d:\\my_project\\my_script.py", False),
        ],
    )
    def test_is_internal_path_detection(self, path_str: str, expected: bool) -> None:
        """测试内部路径检测."""
        from pathlib import Path

        path = Path(path_str)
        assert env_module._PySideEnv._is_internal_path(path) is expected


class TestIsInternalPathEdgeCases:
    """测试 _is_internal_path 方法的边界情况."""

    def test_is_internal_path_with_posix_path(self) -> None:
        """测试 POSIX 风格路径的检测."""
        from pathlib import Path

        path = Path("/home/user/.venv/lib/site-packages/test.py")
        assert env_module._PySideEnv._is_internal_path(path) is True

    def test_is_internal_path_python_keyword_case_insensitive(self) -> None:
        """测试 'python' 关键字不区分大小写."""
        from pathlib import Path

        path = Path("C:\\PYTHON38\\Lib\\test.py")
        assert env_module._PySideEnv._is_internal_path(path) is True

    @pytest.mark.parametrize(
        "path_str",
        [
            "C:\\Users\\user\\anaconda3\\Lib\\test.py",
            "C:\\ProgramData\\Anaconda3\\Lib\\test.py",
        ],
    )
    def test_is_internal_path_anaconda_variants(self, path_str: str) -> None:
        """测试各种 anaconda 路径模式的检测."""
        from pathlib import Path

        # 测试不同的 anaconda 安装
        path = Path(path_str)
        assert env_module._PySideEnv._is_internal_path(path) is True

        # 注意:不含 'anaconda' 关键字的 miniconda3 不会被检测到
        # 这是基于实现的预期行为
