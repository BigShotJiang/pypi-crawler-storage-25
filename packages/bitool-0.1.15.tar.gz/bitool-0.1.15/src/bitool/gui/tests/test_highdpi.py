"""高 DPI 支持模块测试."""

from unittest.mock import MagicMock, patch

import pytest

from bitool.gui._highdpi import (
    HIGH_DPI_THRESHOLD,
    STANDARD_DPI,
    _HighDPIManager,
    get_scaled_font,
    get_scaling_factors,
    scale_value,
)
from bitool.gui.compat import QApplication, QFont, Qt


class TestConstants:
    """测试模块常量."""

    def test_standard_dpi(self) -> None:
        """测试 STANDARD_DPI 常量."""
        assert pytest.approx(96.0) == STANDARD_DPI

    def test_high_dpi_threshold(self) -> None:
        """测试 HIGH_DPI_THRESHOLD 常量."""
        assert pytest.approx(1.25) == HIGH_DPI_THRESHOLD


class Test_HighDPIManager:
    """测试 _HighDPIManager 类."""

    def test_manager_initialization(self) -> None:
        """测试管理器类属性初始化."""
        # conftest.py的reset_gui_singletons fixture已经自动重置状态
        assert _HighDPIManager._initialized is False
        assert pytest.approx(1.0) == _HighDPIManager._scale_factor
        assert _HighDPIManager._is_high_dpi is False

    def test_setup_highdpi_already_initialized(self) -> None:
        """测试如果已初始化则跳过 setup_highdpi."""
        # 设置为已初始化状态
        _HighDPIManager._initialized = True

        # 应该立即返回,不执行任何操作
        _HighDPIManager.setup_highdpi()
        assert _HighDPIManager._initialized is True

    def test_get_scale_factor_auto_initializes(self) -> None:
        """测试 get_scale_factor 自动初始化."""
        factor = _HighDPIManager.get_scale_factor()
        assert isinstance(factor, float)
        assert factor >= 1.0
        assert _HighDPIManager._initialized is True

    def test_is_high_dpi_auto_initializes(self) -> None:
        """测试 is_high_dpi 自动初始化."""
        result = _HighDPIManager.is_high_dpi()
        assert isinstance(result, bool)
        assert _HighDPIManager._initialized is True


class TestModuleFunctions:
    """测试模块级便捷函数."""

    def test_get_scaling_factors(self) -> None:
        """测试 get_scaling_factors 函数."""
        factors = get_scaling_factors()
        assert isinstance(factors, dict)
        assert "scale_factor" in factors
        assert "is_high_dpi" in factors
        assert isinstance(factors["scale_factor"], float)
        assert isinstance(factors["is_high_dpi"], bool)

    def test_scale_value_normal(self) -> None:
        """测试正常值缩放."""
        # 设置已知的缩放因子
        _HighDPIManager._scale_factor = 2.0
        _HighDPIManager._initialized = True

        result = scale_value(10.0)
        assert pytest.approx(20.0) == result

    def test_scale_value_with_min(self) -> None:
        """测试带最小值约束的缩放."""
        _HighDPIManager._scale_factor = 0.5  # 小缩放因子
        _HighDPIManager._initialized = True

        # 值小于 min_value 时应返回 min_value
        result = scale_value(0.5, min_value=1.0)
        assert result >= 1.0

    def test_scale_value_default_min(self) -> None:
        """测试使用默认最小值的缩放."""
        _HighDPIManager._scale_factor = 0.1  # 非常小的缩放因子
        _HighDPIManager._initialized = True

        # 应该使用默认 min_value 为 1.0
        result = scale_value(0.5)
        assert result >= 1.0


class TestScalingValues:
    """测试值缩放计算."""

    def test_scale_value_identity_at_1x(self) -> None:
        """测试在 1.0x 因子下值正确缩放."""
        _HighDPIManager._scale_factor = 1.0
        _HighDPIManager._initialized = True

        result = scale_value(100.0)
        assert pytest.approx(100.0) == result

    def test_scale_value_at_high_dpi(self) -> None:
        """测试在高 DPI 下缩放(超过阈值)."""
        _HighDPIManager._scale_factor = 2.0
        _HighDPIManager._is_high_dpi = True
        _HighDPIManager._initialized = True

        result = scale_value(50.0)
        assert pytest.approx(100.0) == result


class Test_HighDPIManagerWithQApp:
    """测试带 QApplication 实例的 _HighDPIManager."""

    def test_setup_highdpi_with_qapplication_instance(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """测试当 QApplication 实例存在时 setup_highdpi."""
        # conftest.py已重置状态,直接设置需要的初始值
        _HighDPIManager._scale_factor = 1.0
        _HighDPIManager._is_high_dpi = False

        # 创建带高 DPI 的模拟屏幕
        mock_screen = MagicMock()
        mock_screen.logicalDotsPerInch.return_value = 144.0  # 高 DPI

        # 创建模拟 QApplication
        mock_qapp = MagicMock()
        mock_qapp.primaryScreen.return_value = mock_screen

        # 保存原始方法
        original_instance = QApplication.instance

        try:
            # Mock QApplication.instance 返回我们的 mock
            QApplication.instance = MagicMock(return_value=mock_qapp)  # type: ignore[assignment]

            # 调用 setup
            _HighDPIManager.setup_highdpi()

            # 验证检测到高 DPI (144/96 = 1.5)
            assert _HighDPIManager._scale_factor > 1.0
            assert _HighDPIManager._initialized is True
        finally:
            # 恢复原始方法
            QApplication.instance = original_instance

    def test_setup_highdpi_screen_none(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """测试当屏幕为 None 时的 setup_highdpi."""
        _HighDPIManager._scale_factor = 1.0

        mock_qapp = MagicMock()
        mock_qapp.primaryScreen.return_value = None

        original_instance = QApplication.instance
        try:
            QApplication.instance = MagicMock(return_value=mock_qapp)  # type: ignore[assignment]
            _HighDPIManager.setup_highdpi()

            # 应该使用默认值
            assert _HighDPIManager._scale_factor == pytest.approx(1.0)
            assert _HighDPIManager._initialized is True
        finally:
            QApplication.instance = original_instance

    def test_setup_highdpi_no_logical_dpi_method(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """测试当屏幕没有 logicalDotsPerInch 方法时的 setup_highdpi."""
        _HighDPIManager._scale_factor = 1.0

        mock_screen = MagicMock(spec=[])  # 无方法
        mock_qapp = MagicMock()
        mock_qapp.primaryScreen.return_value = mock_screen

        original_instance = QApplication.instance
        try:
            QApplication.instance = MagicMock(return_value=mock_qapp)  # type: ignore[assignment]
            _HighDPIManager.setup_highdpi()

            # 应该使用默认值
            assert _HighDPIManager._scale_factor == pytest.approx(1.0)
            assert _HighDPIManager._initialized is True
        finally:
            QApplication.instance = original_instance

    def test_setup_highdpi_exception_handling(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """测试 setup_highdpi 优雅处理异常."""
        original_instance = QApplication.instance
        try:
            QApplication.instance = MagicMock(side_effect=RuntimeError("模拟错误"))  # type: ignore[assignment]
            # 不应该抛出异常
            _HighDPIManager.setup_highdpi()
            assert _HighDPIManager._initialized is True
        finally:
            QApplication.instance = original_instance


class TestGetScaledFont:
    """测试 get_scaled_font 函数."""

    def test_get_scaled_font_returns_qfont(self) -> None:
        """测试 get_scaled_font 返回 QFont 实例."""
        # 验证 Qt 可用时返回 QFont
        result = get_scaled_font(16)

        assert isinstance(result, QFont)
        assert result.pixelSize() == 16

    def test_get_scaled_font_default_size(self) -> None:
        """测试带默认大小的 get_scaled_font."""
        # 将缩放因子设为 1.0 以获得可预测的默认大小
        _HighDPIManager._scale_factor = 1.0
        _HighDPIManager._initialized = True

        result = get_scaled_font()

        assert isinstance(result, QFont)
        # 默认大小应该约为 14(缩放后)
        assert result.pixelSize() >= 14

    def test_get_scaled_font_default_size_uses_scaling(self) -> None:
        """测试默认字体大小使用缩放."""
        # 设置已知的缩放因子
        _HighDPIManager._scale_factor = 2.0
        _HighDPIManager._initialized = True

        # 当 size 为 None 时,应该使用 scale_value(14, 9)
        # 缩放因子=2.0 时: max(9, 14*2.0) = 28
        result = get_scaled_font(None)

        assert isinstance(result, QFont)
        # 默认大小应该缩放: max(9, 14*2.0) = 28
        assert result.pixelSize() == 28


class TestQtNotAvailable:
    """测试 Qt 不可用时的行为."""

    def test_qt_import_failure(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """测试当 PySide2 无法导入时的模块行为."""
        # 临时修改 sys.modules 模拟 PySide2 缺失
        with patch.dict("sys.modules", {"PySide2": None}):
            # 模块在导入期间应该优雅处理
            # 我们只验证常量仍然可访问
            assert pytest.approx(96.0) == STANDARD_DPI
            assert pytest.approx(1.25) == HIGH_DPI_THRESHOLD


class TestSetupHighDpiScaling:
    """测试 setup_highdpi_scaling 导出函数."""

    def test_setup_highdpi_scaling_callable(self) -> None:
        """测试 setup_highdpi_scaling 可调用."""
        from bitool.gui._highdpi import setup_highdpi_scaling

        assert callable(setup_highdpi_scaling)

    def test_setup_highdpi_scaling_idempotent(self) -> None:
        """测试 setup_highdpi_scaling 可以被多次调用."""
        from bitool.gui._highdpi import setup_highdpi_scaling

        # 第一次调用
        setup_highdpi_scaling()
        assert _HighDPIManager._initialized is True

        # 第二次调用(应该跳过)
        setup_highdpi_scaling()
        assert _HighDPIManager._initialized is True


class TestHighDpiEdgeCases:
    """测试 HighDPI 功能的边界情况."""

    def test_scale_value_zero(self) -> None:
        """测试零值缩放."""
        _HighDPIManager._scale_factor = 2.0
        _HighDPIManager._initialized = True

        result = scale_value(0.0)
        # 应该返回 min_value (1.0),因为 0 * 2.0 = 0 < 1.0
        assert result == pytest.approx(1.0)

    def test_scale_value_negative(self) -> None:
        """测试负值缩放."""
        _HighDPIManager._scale_factor = 2.0
        _HighDPIManager._initialized = True

        result = scale_value(-10.0)
        # 应该返回 min_value (1.0),因为 -10 * 2.0 = -20 < 1.0
        assert result == pytest.approx(1.0)

    def test_scale_value_custom_min(self) -> None:
        """测试带自定义最小值的缩放."""
        _HighDPIManager._scale_factor = 1.5
        _HighDPIManager._initialized = True

        result = scale_value(10.0, min_value=20.0)
        # 10 * 1.5 = 15,但 min_value 是 20
        assert result == pytest.approx(20.0)

    def test_get_scaled_font_type_error(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """测试 get_scaled_font 优雅处理 TypeError."""
        # 模拟 QFont.setPixelSize 抛出 TypeError
        original_set_pixel_size = QFont.setPixelSize

        def mock_set_pixel_size(self: QFont, size: int) -> None:
            msg = "模拟错误"
            raise TypeError(msg)

        try:
            QFont.setPixelSize = mock_set_pixel_size  # type: ignore[assignment]
            result = get_scaled_font(16)
            assert result is None
        finally:
            QFont.setPixelSize = original_set_pixel_size

    def test_get_scaled_font_value_error(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """测试 get_scaled_font 优雅处理 ValueError."""
        # 模拟 QFont.setPixelSize 抛出 ValueError
        original_set_pixel_size = QFont.setPixelSize

        def mock_set_pixel_size(self: QFont, size: int) -> None:
            msg = "模拟错误"
            raise ValueError(msg)

        try:
            QFont.setPixelSize = mock_set_pixel_size  # type: ignore[assignment]
            result = get_scaled_font(16)
            assert result is None
        finally:
            QFont.setPixelSize = original_set_pixel_size

    def test_setup_highdpi_no_qapplication_sets_attributes(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """测试即使没有 QApplication,setup_highdpi 也设置 Qt 属性."""
        original_instance = QApplication.instance
        original_set_attribute = QApplication.setAttribute

        try:
            # 模拟 QApplication.instance 返回 None
            QApplication.instance = MagicMock(return_value=None)  # type: ignore[assignment]

            # 跟踪 setAttribute 调用
            set_attribute_calls = []

            def mock_set_attribute(attr: int, value: bool) -> None:
                set_attribute_calls.append((attr, value))

            QApplication.setAttribute = mock_set_attribute  # type: ignore[assignment]

            _HighDPIManager.setup_highdpi()

            # 验证 Qt 属性已设置
            assert len(set_attribute_calls) >= 2
            # 检查 HighDpiScaling 和 HighDpiPixmaps 已启用
            assert (Qt.AA_EnableHighDpiScaling, True) in set_attribute_calls
            assert (Qt.AA_UseHighDpiPixmaps, True) in set_attribute_calls
        finally:
            QApplication.instance = original_instance
            QApplication.setAttribute = original_set_attribute


class TestGetScalingFactors:
    """测试 get_scaling_factors 函数."""

    def test_get_scaling_factors_returns_dict(self) -> None:
        """测试 get_scaling_factors 返回正确的字典结构."""
        factors = get_scaling_factors()
        assert isinstance(factors, dict)
        assert set(factors.keys()) == {"scale_factor", "is_high_dpi"}
        assert isinstance(factors["scale_factor"], float)
        assert isinstance(factors["is_high_dpi"], bool)

    def test_get_scaling_factors_reflects_current_state(self) -> None:
        """测试 get_scaling_factors 反映当前管理器状态."""
        _HighDPIManager._scale_factor = 1.5
        _HighDPIManager._is_high_dpi = True
        _HighDPIManager._initialized = True

        factors = get_scaling_factors()
        assert factors["scale_factor"] == pytest.approx(1.5)
        assert factors["is_high_dpi"] is True, "is_high_dpi 应该为 True"
