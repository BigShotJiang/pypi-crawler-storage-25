"""UILoader 模块测试."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from bitool.gui._uiloader import (
    UILoader,
    _default_loader,
    clear_ui_cache,
    load_ui,
    setup_ui,
)


class TestUILoader:
    """UILoader 类测试."""

    @pytest.mark.parametrize(
        ("base_path", "expected"),
        [
            (None, None),
            (Path("/test/path"), Path("/test/path")),
            ("/test/path", Path("/test/path")),
        ],
    )
    def test_init(self, base_path: Path | str | None, expected: Path | None) -> None:
        """测试 UILoader 初始化."""
        loader = UILoader(base_path=base_path)
        assert loader.base_path == expected
        assert loader._cache == {}

    @pytest.mark.parametrize(
        ("ui_content", "expected_qrc"),
        [
            ('<ui><include location="theme.qrc"/></ui>', ["theme.qrc"]),
            (
                '<ui><include location="icons.qrc"/><include location="styles.qrc"/></ui>',
                ["icons.qrc", "styles.qrc"],
            ),
            ("<ui></ui>", []),
            ('<ui><include location="missing.qrc"/></ui>', ["missing.qrc"]),
        ],
    )
    def test_resolve_resources_qrc_detection(
        self,
        tmp_path: Path,
        ui_content: str,
        expected_qrc: list,
    ) -> None:
        """测试 UI 文件中的 qrc 引用检测."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text(ui_content)

        loader = UILoader()
        # Mock QRCLoader 以避免实际加载资源文件
        with patch("bitool.gui._qrcloader.QRCLoader") as mock_qrc_loader_class:
            mock_qrc_loader = MagicMock()
            mock_qrc_loader_class.return_value = mock_qrc_loader
            mock_qrc_loader.load_qrc.return_value = True

            # Mock logger 以避免实际日志记录
            with patch("bitool.gui._uiloader.logger.warning"):
                loader._resolve_resources(ui_file)
        # 如果没有抛出异常,测试通过

    def test_resolve_resources_with_qrc_loader(self, tmp_path: Path) -> None:
        """测试使用 QRCLoader 解析资源."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text('<ui><include location="theme.qrc"/></ui>')

        loader = UILoader()
        with patch("bitool.gui._qrcloader.QRCLoader") as mock_qrc_loader_class:
            mock_qrc_loader = MagicMock()
            mock_qrc_loader_class.return_value = mock_qrc_loader
            mock_qrc_loader.load_qrc.return_value = True

            loader._resolve_resources(ui_file)

            mock_qrc_loader_class.assert_called_once_with(base_path=ui_file.parent)
            mock_qrc_loader.load_qrc.assert_called_once_with(ui_file.parent / "theme.qrc")

    def test_resolve_resources_multiple_qrc(self, tmp_path: Path) -> None:
        """测试多个 QRC 引用的资源解析."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text(
            '<ui><include location="theme.qrc"/><include location="icons.qrc"/></ui>',
        )

        loader = UILoader()
        with patch("bitool.gui._qrcloader.QRCLoader") as mock_qrc_loader_class:
            mock_qrc_loader = MagicMock()
            mock_qrc_loader_class.return_value = mock_qrc_loader
            mock_qrc_loader.load_qrc.return_value = True

            loader._resolve_resources(ui_file)

            assert mock_qrc_loader.load_qrc.call_count == 2

    def test_resolve_resources_read_error(self, tmp_path: Path) -> None:
        """测试 UI 文件读取错误处理."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        with patch.object(Path, "read_text", side_effect=OSError("读取错误")), patch(
            "bitool.gui._uiloader.logger.warning",
        ) as mock_warning:
            loader._resolve_resources(ui_file)
            mock_warning.assert_called_once()
            assert "读取UI文件失败" in str(mock_warning.call_args)

    @pytest.mark.parametrize(
        ("ui_path_type", "ui_path_value"),
        [
            ("absolute", None),  # 将在测试中设置
            ("relative", "test.ui"),
        ],
    )
    def test_find_ui_file_absolute(
        self,
        tmp_path: Path,
        ui_path_type: str,
        ui_path_value: str | None,
    ) -> None:
        """测试使用绝对路径查找 UI 文件."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_frame = MagicMock()

        if ui_path_type == "absolute":
            result = loader._find_ui_file(ui_file, mock_frame)  # type: ignore[invalid-argument-type]
        else:
            loader = UILoader(base_path=tmp_path)
            result = loader._find_ui_file(ui_path_value, mock_frame)  # type: ignore[invalid-argument-type]

        assert result == ui_file

    def test_find_ui_file_relative(self, tmp_path: Path) -> None:
        """测试使用相对路径查找 UI 文件."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader(base_path=tmp_path)
        mock_frame = MagicMock()

        result = loader._find_ui_file("test.ui", mock_frame)  # type: ignore[invalid-argument-type]
        assert result == ui_file

    @pytest.mark.parametrize(
        ("py_filename", "expected_ui"),
        [
            ("mymodule.py", "mymodule.ui"),
            ("mymodule_ui.py", "mymodule.ui"),
            ("mymodule_widget.py", "mymodule.ui"),
            ("my_widget_ui.py", "my.ui"),
        ],
    )
    def test_find_ui_file_auto(
        self,
        tmp_path: Path,
        py_filename: str,
        expected_ui: str,
    ) -> None:
        """测试使用不同命名模式自动查找 UI 文件."""
        py_file = tmp_path / py_filename
        py_file.write_text("# 测试")
        ui_file = tmp_path / expected_ui
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_frame = MagicMock()
        mock_module = MagicMock()
        mock_module.__file__ = str(py_file)

        with patch("bitool.gui._uiloader.inspect.getmodule", return_value=mock_module):
            result = loader._find_ui_file(None, mock_frame)  # type: ignore[invalid-argument-type]
            assert result == ui_file

    def test_find_ui_file_not_found(self, tmp_path: Path) -> None:
        """测试 UI 文件未找到时的错误."""
        loader = UILoader()
        mock_frame = MagicMock()
        mock_module = MagicMock()
        mock_module.__file__ = str(tmp_path / "nonexistent.py")

        with patch(
            "bitool.gui._uiloader.inspect.getmodule",
            return_value=mock_module,
        ), pytest.raises(FileNotFoundError, match=r"无法自动找到\.ui文件"):
            loader._find_ui_file(None, mock_frame)  # type: ignore[invalid-argument-type]

    def test_find_ui_file_specified_not_found(self, tmp_path: Path) -> None:
        """测试指定的 UI 文件未找到时的错误."""
        loader = UILoader()
        mock_frame = MagicMock()

        non_existent = tmp_path / "nonexistent.ui"
        with pytest.raises(FileNotFoundError, match=r"UI文件不存在:"):
            loader._find_ui_file(non_existent, mock_frame)  # type: ignore[invalid-argument-type]

    def test_find_ui_file_auto_no_module(self, tmp_path: Path) -> None:
        """测试自动查找 UI 文件但无模块信息时的错误."""
        loader = UILoader()
        mock_frame = MagicMock()
        mock_module = MagicMock()
        mock_module.__file__ = None

        with patch(
            "bitool.gui._uiloader.inspect.getmodule",
            return_value=mock_module,
        ), pytest.raises(FileNotFoundError, match=r"无法自动找到\.ui文件"):
            loader._find_ui_file(None, mock_frame)  # type: ignore[invalid-argument-type]

    def test_find_ui_file_auto_no_file_attribute(self, tmp_path: Path) -> None:
        """测试自动查找 UI 文件但模块没有 __file__ 时的错误."""
        loader = UILoader()
        mock_frame = MagicMock()
        mock_module = MagicMock()
        # 配置 MagicMock 不自动创建属性
        mock_module.configure_mock(**{"__file__": None})

        with patch(
            "bitool.gui._uiloader.inspect.getmodule",
            return_value=mock_module,
        ), pytest.raises(FileNotFoundError, match=r"无法自动找到\.ui文件"):
            loader._find_ui_file(None, mock_frame)  # type: ignore[invalid-argument-type]

    @pytest.mark.parametrize(
        ("mtime1", "mtime2", "expected_equal"),
        [(1000.0, 1000.0, True), (1000.0, 2000.0, False)],
    )
    def test_get_cache_key(
        self,
        tmp_path: Path,
        mtime1: float,
        mtime2: float,
        expected_equal: bool,
    ) -> None:
        """测试缓存键生成."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()

        # Mock stat 返回不同的 mtime 值
        mock_stat1 = MagicMock()
        mock_stat1.st_mtime = mtime1
        mock_stat2 = MagicMock()
        mock_stat2.st_mtime = mtime2

        with patch.object(Path, "stat", side_effect=[mock_stat1, mock_stat2]):
            key1 = loader._get_cache_key(ui_file)
            key2 = loader._get_cache_key(ui_file)

            if expected_equal:
                assert key1 == key2
            else:
                assert key1 != key2

            assert str(ui_file.absolute()) in key1

    def test_clear_cache(self) -> None:
        """测试缓存清除."""
        loader = UILoader()
        loader._cache = {"key1": MagicMock(), "key2": MagicMock()}

        loader.clear_cache()
        assert loader._cache == {}

    def test_resolve_resources_no_qrc(self, tmp_path: Path) -> None:
        """测试没有 qrc 引用时的资源解析."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        # 不应该抛出任何错误
        loader._resolve_resources(ui_file)


class TestLoadUI:
    """load_ui 方法测试."""

    def test_load_ui_with_parent(self, tmp_path: Path) -> None:
        """测试带父控件加载 UI."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_parent = MagicMock()
        mock_widget = MagicMock()
        mock_widget.layout.return_value = None
        mock_widget.findChildren.return_value = []

        with patch(
            "bitool.gui._uiloader.QUiLoader.load",
            return_value=mock_widget,
        ), patch("bitool.gui._uiloader.QFile") as mock_qfile:
            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True

            result = loader.load_ui(ui_file, mock_parent)

            assert result == mock_parent

    def test_load_ui_without_parent(self, tmp_path: Path) -> None:
        """测试不带父控件加载 UI."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_widget = MagicMock()

        with patch(
            "bitool.gui._uiloader.QUiLoader.load",
            return_value=mock_widget,
        ), patch("bitool.gui._uiloader.QFile") as mock_qfile:
            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True

            result = loader.load_ui(ui_file)

            assert result == mock_widget

    def test_load_ui_file_open_error(self, tmp_path: Path) -> None:
        """测试 UI 文件无法打开时的错误."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()

        with patch("bitool.gui._uiloader.QFile") as mock_qfile:
            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = False

            with pytest.raises(RuntimeError, match=r"无法打开UI文件:"):
                loader.load_ui(ui_file)

    def test_load_ui_load_error(self, tmp_path: Path) -> None:
        """测试 UI 加载失败时的错误."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()

        with patch("bitool.gui._uiloader.QUiLoader.load", return_value=None), patch(
            "bitool.gui._uiloader.QFile",
        ) as mock_qfile:
            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True

            with pytest.raises(RuntimeError, match=r"加载UI文件失败:"):
                loader.load_ui(ui_file)

    def test_load_ui_cannot_get_caller_info(self) -> None:
        """测试无法获取调用者信息时的错误."""
        loader = UILoader()

        with patch(
            "bitool.gui._uiloader.inspect.currentframe",
            return_value=None,
        ), pytest.raises(RuntimeError, match=r"无法获取调用者信息"):
            loader.load_ui(None)

    def test_load_ui_skip_uiloader_frames(self, tmp_path: Path) -> None:
        """测试 load_ui 在自动查找时跳过 _uiloader.py 的帧."""
        ui_file = tmp_path / "mywidget.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_widget = MagicMock()

        # 创建模拟帧,模拟调用栈
        mock_external_frame = MagicMock()
        mock_uiloader_frame = MagicMock()

        # 外部帧的模拟模块
        mock_external_module = MagicMock()
        mock_external_module.__file__ = str(tmp_path / "mywidget.py")

        # uiloader 帧的模拟模块
        mock_uiloader_module = MagicMock()
        mock_uiloader_module.__file__ = str(
            Path(__file__).parent.parent / "_uiloader.py",
        )

        # 设置帧链: currentframe -> uiloader_frame -> external_frame
        with patch(
            "bitool.gui._uiloader.inspect.currentframe",
        ) as mock_currentframe, patch(
            "bitool.gui._uiloader.inspect.getmodule",
        ) as mock_getmodule, patch(
            "bitool.gui._uiloader.QUiLoader.load",
            return_value=mock_widget,
        ), patch("bitool.gui._uiloader.QFile") as mock_qfile:
            mock_currentframe_instance = MagicMock()
            mock_currentframe_instance.f_back = mock_uiloader_frame
            mock_currentframe.return_value = mock_currentframe_instance

            mock_uiloader_frame.f_back = mock_external_frame

            def getmodule_side_effect(frame):
                if frame == mock_uiloader_frame:
                    return mock_uiloader_module
                elif frame == mock_external_frame:
                    return mock_external_module
                return None

            mock_getmodule.side_effect = getmodule_side_effect

            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True
            mock_widget.layout.return_value = None
            mock_widget.findChildren.return_value = []

            result = loader.load_ui(None)
            assert result == mock_widget

    def test_load_ui_no_external_frame_fallback(self, tmp_path: Path) -> None:
        """测试没有找到外部帧时的回退(所有帧都来自 _uiloader.py)."""
        ui_file = tmp_path / "mywidget.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_widget = MagicMock()

        # Mock 所有帧都来自 _uiloader.py
        mock_frame1 = MagicMock()
        mock_frame2 = MagicMock()

        mock_module1 = MagicMock()
        mock_module1.__file__ = str(Path(__file__).parent.parent / "_uiloader.py")

        # 第二个帧没有模块信息(模拟栈结束)
        mock_frame2.f_back = None

        with patch(
            "bitool.gui._uiloader.inspect.currentframe",
        ) as mock_currentframe, patch(
            "bitool.gui._uiloader.inspect.getmodule",
            return_value=mock_module1,
        ), patch(
            "bitool.gui._uiloader.QUiLoader.load",
            return_value=mock_widget,
        ), patch("bitool.gui._uiloader.QFile") as mock_qfile, pytest.raises(
            FileNotFoundError,
            match=r"无法自动找到\.ui文件",
        ):
            mock_currentframe_instance = MagicMock()
            mock_currentframe_instance.f_back = mock_frame1
            mock_currentframe.return_value = mock_currentframe_instance

            mock_frame1.f_back = mock_frame2

            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True

            loader.load_ui(None)

    @pytest.mark.parametrize(
        ("has_layout", "has_children", "expected_set_layout"),
        [
            (True, True, True),
            (False, True, False),
            (True, False, True),
            (False, False, False),
        ],
    )
    def test_load_ui_with_parent_and_children(
        self,
        tmp_path: Path,
        has_layout: bool,
        has_children: bool,
        expected_set_layout: bool,
    ) -> None:
        """测试带父控件和各种子控件配置加载 UI."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_parent = MagicMock()
        mock_widget = MagicMock()

        # 设置布局
        if has_layout:
            mock_layout = MagicMock()
            mock_widget.layout.return_value = mock_layout
        else:
            mock_widget.layout.return_value = None

        # 设置子控件
        if has_children:
            mock_child = MagicMock()
            mock_child.objectName.return_value = "testChild"
            mock_widget.findChildren.return_value = [mock_child]
            mock_parent.findChildren.return_value = []
        else:
            mock_widget.findChildren.return_value = []
            mock_parent.findChildren.return_value = []

        with patch(
            "bitool.gui._uiloader.QUiLoader.load",
            return_value=mock_widget,
        ), patch("bitool.gui._uiloader.QFile") as mock_qfile:
            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True

            result = loader.load_ui(ui_file, mock_parent)

            assert result == mock_parent
            if expected_set_layout:
                mock_parent.setLayout.assert_called_once()
            else:
                mock_parent.setLayout.assert_not_called()

    def test_load_ui_caching(self, tmp_path: Path) -> None:
        """测试 UI 加载使用缓存."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_widget = MagicMock()

        with patch(
            "bitool.gui._uiloader.QUiLoader.load",
            return_value=mock_widget,
        ) as mock_load, patch("bitool.gui._uiloader.QFile") as mock_qfile:
            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True

            # 第一次加载
            result1 = loader.load_ui(ui_file)
            assert mock_load.call_count == 1

            # 第二次加载应该使用缓存
            result2 = loader.load_ui(ui_file)
            assert mock_load.call_count == 1  # 仍为 1,使用缓存

            assert result1 == result2

    def test_load_ui_widget_equals_parent(self, tmp_path: Path) -> None:
        """测试当加载器返回的 widget 等于父控件时加载 UI."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_parent = MagicMock()

        # 在父控件上 Mock 子控件
        mock_child1 = MagicMock()
        mock_child1.objectName.return_value = "button1"
        mock_child2 = MagicMock()
        mock_child2.objectName.return_value = "_private"  # 应该被跳过
        mock_parent.findChildren.return_value = [mock_child1, mock_child2]

        with patch(
            "bitool.gui._uiloader.QUiLoader.load",
            return_value=mock_parent,
        ) as mock_load, patch("bitool.gui._uiloader.QFile") as mock_qfile:
            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True
            mock_parent.layout.return_value = None

            result = loader.load_ui(ui_file, mock_parent)

            assert result == mock_parent
            # 验证为有效子控件设置了属性
            assert hasattr(mock_parent, "button1")
            # _private 不应该被设置,因为它以下划线开头
            mock_load.assert_called_once()

    def test_load_ui_parent_with_children_on_widget(self, tmp_path: Path) -> None:
        """测试带父控件加载 UI 且子控件在加载的 widget 上."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_parent = MagicMock()
        mock_widget = MagicMock()

        # Widget 有子控件
        mock_child1 = MagicMock()
        mock_child1.objectName.return_value = "label1"
        mock_child2 = MagicMock()
        mock_child2.objectName.return_value = ""  # 空名称应该被跳过
        mock_widget.findChildren.return_value = [mock_child1, mock_child2]
        mock_parent.findChildren.return_value = []

        mock_layout = MagicMock()
        mock_widget.layout.return_value = mock_layout

        with patch(
            "bitool.gui._uiloader.QUiLoader.load",
            return_value=mock_widget,
        ), patch("bitool.gui._uiloader.QFile") as mock_qfile:
            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True

            result = loader.load_ui(ui_file, mock_parent)

            assert result == mock_parent
            mock_parent.setLayout.assert_called_once_with(mock_layout)
            mock_widget.hide.assert_called_once()
            # 验证设置了属性
            assert hasattr(mock_parent, "label1")

    def test_load_ui_parent_with_no_widget_children_uses_parent_children(
        self,
        tmp_path: Path,
    ) -> None:
        """测试当 widget 没有子控件时使用父控件的子控件."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_parent = MagicMock()
        mock_widget = MagicMock()

        # Widget 只有一个子控件(模拟没有业务控件)
        mock_widget.findChildren.return_value = [MagicMock()]

        # 父控件有实际子控件
        mock_child1 = MagicMock()
        mock_child1.objectName.return_value = "textbox1"
        mock_parent.findChildren.return_value = [mock_child1]

        mock_widget.layout.return_value = None

        with patch(
            "bitool.gui._uiloader.QUiLoader.load",
            return_value=mock_widget,
        ), patch("bitool.gui._uiloader.QFile") as mock_qfile:
            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True

            result = loader.load_ui(ui_file, mock_parent)

            assert result == mock_parent
            assert hasattr(mock_parent, "textbox1")


class TestSetupUI:
    """setup_ui 方法测试."""

    def test_setup_ui_basic(self, tmp_path: Path) -> None:
        """测试基本 setup_ui 功能."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_widget = MagicMock()
        mock_widget.findChildren.return_value = []

        with patch.object(loader, "load_ui") as mock_load_ui:
            loader.setup_ui(mock_widget, ui_file)
            mock_load_ui.assert_called_once_with(ui_file, mock_widget)

    def test_setup_ui_sets_attributes(self, tmp_path: Path) -> None:
        """测试 setup_ui 从子控件设置控件属性."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_widget = MagicMock()

        # Mock 带名称的子控件 - 只有有效名称应该被设置
        mock_child1 = MagicMock()
        mock_child1.objectName.return_value = "button1"

        mock_widget.findChildren.return_value = [mock_child1]

        with patch.object(loader, "load_ui"):
            loader.setup_ui(mock_widget, ui_file)
            # 验证为 button1 调用了 setattr
            assert hasattr(mock_widget, "button1")


class TestConvenienceFunctions:
    """模块级便捷函数测试."""

    def test_load_ui_function(self) -> None:
        """测试 load_ui 便捷函数."""
        # 这需要真实的 UI 文件和 Qt 应用
        # 现在只测试函数存在且可调用
        assert callable(load_ui)

    def test_setup_ui_function(self) -> None:
        """测试 setup_ui 便捷函数."""
        assert callable(setup_ui)

    def test_clear_cache_function(self) -> None:
        """测试 clear_cache 便捷函数."""
        # 不应该抛出任何错误
        clear_ui_cache()

    def test_load_ui_function_calls_default_loader(self, tmp_path: Path) -> None:
        """测试 load_ui 函数调用默认加载器."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        mock_widget = MagicMock()
        mock_widget.layout.return_value = None
        mock_widget.findChildren.return_value = []

        with patch.object(
            _default_loader,
            "load_ui",
            return_value=mock_widget,
        ) as mock_load:
            result = load_ui(ui_file)
            mock_load.assert_called_once_with(ui_file, None)
            assert result == mock_widget

    def test_setup_ui_function_calls_default_loader(self, tmp_path: Path) -> None:
        """测试 setup_ui 函数调用默认加载器."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        mock_widget = MagicMock()
        mock_widget.findChildren.return_value = []

        with patch.object(_default_loader, "setup_ui") as mock_setup:
            setup_ui(mock_widget, ui_file)
            mock_setup.assert_called_once_with(mock_widget, ui_file)

    def test_clear_cache_function_calls_default_loader(self) -> None:
        """测试 clear_cache 函数调用默认加载器."""
        with patch.object(_default_loader, "clear_cache") as mock_clear:
            clear_ui_cache()
            mock_clear.assert_called_once()

    def test_setup_ui_filters_private_children(self, tmp_path: Path) -> None:
        """测试 setup_ui 只为非私有子控件设置属性."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_widget = MagicMock()

        # Mock 子控件 - 有效名称和私有名称混合
        mock_child1 = MagicMock()
        mock_child1.objectName.return_value = "button1"
        mock_child2 = MagicMock()
        mock_child2.objectName.return_value = "_private_button"
        mock_child3 = MagicMock()
        mock_child3.objectName.return_value = ""  # 空名称
        mock_child4 = MagicMock()
        mock_child4.objectName.return_value = "label1"

        mock_widget.findChildren.return_value = [
            mock_child1,
            mock_child2,
            mock_child3,
            mock_child4,
        ]

        with patch.object(loader, "load_ui"):
            loader.setup_ui(mock_widget, ui_file)
            # 验证只为有效名称设置属性
            assert hasattr(mock_widget, "button1")
            assert hasattr(mock_widget, "label1")
            # _private_button 不应该被设置(以下划线开头)
            # 空名称也不应该被设置
