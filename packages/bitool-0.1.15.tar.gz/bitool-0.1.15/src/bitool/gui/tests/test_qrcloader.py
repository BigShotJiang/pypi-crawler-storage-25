"""QRCLoader 模块测试."""

from __future__ import annotations

import sys
from pathlib import Path
from types import FrameType
from typing import cast
from unittest.mock import MagicMock, patch

import pytest

from bitool.gui._qrcloader import (
    QRCLoader,
    _default_loader,
    clear_qrc_cache,
    load_qrc,
    load_resources,
)


class TestQRCLoader:
    """QRCLoader 类测试."""

    @pytest.mark.parametrize(
        ("base_path", "expected"),
        [
            (None, None),
            (Path("/test/path"), Path("/test/path")),
            ("/test/path", Path("/test/path")),
        ],
    )
    def test_init(self, base_path: Path | str | None, expected: Path | None) -> None:
        """测试 QRCLoader 初始化."""
        loader = QRCLoader(base_path=base_path)
        assert loader.base_path == expected
        assert loader._cache == {}

    @pytest.mark.parametrize(
        ("qrc_filename", "expected_rc_filename"),
        [
            ("resource.qrc", "resource_rc.py"),
            ("icons.qrc", "icons_rc.py"),
            ("custom_theme.qrc", "custom_theme_rc.py"),
        ],
    )
    def test_rc_filename_generation(
        self,
        qrc_filename: str,
        expected_rc_filename: str,
    ) -> None:
        """测试资源模块文件名生成."""
        qrc_path = Path("/test/dir") / qrc_filename
        rc_module_name = qrc_path.stem + "_rc"
        rc_py_path = qrc_path.with_name(rc_module_name + ".py")
        assert rc_py_path.name == expected_rc_filename

    def test_find_qrc_file_absolute(self, tmp_path: Path) -> None:
        """测试使用绝对路径查找 QRC 文件."""
        qrc_file = tmp_path / "test.qrc"
        qrc_file.write_text("<RCC></RCC>")

        loader = QRCLoader()

        result = loader._find_qrc_file(qrc_file, cast(FrameType, MagicMock()))
        assert result == qrc_file

    def test_find_qrc_file_relative(self, tmp_path: Path) -> None:
        """测试使用相对路径查找 QRC 文件."""
        qrc_file = tmp_path / "test.qrc"
        qrc_file.write_text("<RCC></RCC>")

        loader = QRCLoader(base_path=tmp_path)

        result = loader._find_qrc_file("test.qrc", cast(FrameType, MagicMock()))
        assert result == qrc_file

    @pytest.mark.parametrize(
        ("qrc_filenames", "expected_qrc"),
        [
            (["resource.qrc"], "resource.qrc"),
            (["resource.qrc", "icons.qrc"], "resource.qrc"),
            (["icons.qrc", "theme.qrc"], "icons.qrc"),
        ],
    )
    def test_find_qrc_file_auto(
        self,
        tmp_path: Path,
        qrc_filenames: list,
        expected_qrc: str,
    ) -> None:
        """测试自动查找 QRC 文件."""
        py_file = tmp_path / "mymodule.py"
        py_file.write_text("# 测试")

        for qrc_filename in qrc_filenames:
            qrc_file = tmp_path / qrc_filename
            qrc_file.write_text("<RCC></RCC>")

        loader = QRCLoader()
        mock_module = MagicMock()
        mock_module.__file__ = str(py_file)

        with patch(
            "bitool.gui._qrcloader.inspect.getmodule",
            return_value=mock_module,
        ):
            result = loader._find_qrc_file(None, cast(FrameType, MagicMock()))
            assert result.name == expected_qrc

    def test_find_qrc_file_not_found(self, tmp_path: Path) -> None:
        """测试 QRC 文件未找到时的错误."""
        loader = QRCLoader()
        mock_module = MagicMock()
        mock_module.__file__ = str(tmp_path / "nonexistent.py")

        with patch(
            "bitool.gui._qrcloader.inspect.getmodule",
            return_value=mock_module,
        ), pytest.raises(FileNotFoundError, match=r"无法自动找到\.qrc文件"):
            loader._find_qrc_file(None, cast(FrameType, MagicMock()))

    def test_find_qrc_file_specified_not_found(self, tmp_path: Path) -> None:
        """测试指定的 QRC 文件未找到时的错误."""
        loader = QRCLoader()

        non_existent = tmp_path / "nonexistent.qrc"
        with pytest.raises(FileNotFoundError, match=r"QRC文件不存在:"):
            loader._find_qrc_file(non_existent, cast(FrameType, MagicMock()))

    @pytest.mark.parametrize(
        ("mtime1", "mtime2", "expected_equal"),
        [(1000.0, 1000.0, True), (1000.0, 2000.0, False)],
    )
    def test_get_cache_key(
        self,
        tmp_path: Path,
        mtime1: float,
        mtime2: float,
        expected_equal: bool,
    ) -> None:
        """测试缓存键生成."""
        qrc_file = tmp_path / "test.qrc"
        qrc_file.write_text("<RCC></RCC>")

        loader = QRCLoader()

        mock_stat1 = MagicMock()
        mock_stat1.st_mtime = mtime1
        mock_stat2 = MagicMock()
        mock_stat2.st_mtime = mtime2

        with patch.object(Path, "stat", side_effect=[mock_stat1, mock_stat2]):
            key1 = loader._get_cache_key(qrc_file)
            key2 = loader._get_cache_key(qrc_file)

            if expected_equal:
                assert key1 == key2
            else:
                assert key1 != key2

            assert str(qrc_file.absolute()) in key1

    def test_clear_cache(self) -> None:
        """测试缓存清除."""
        loader = QRCLoader()
        loader._cache = {"key1": True, "key2": False}

        loader.clear_cache()
        assert loader._cache == {}

    @pytest.mark.parametrize(
        ("pyside_version", "expected_compilers"),
        [
            ("PySide6", ["pyside6-rcc", "rcc6"]),
            ("PySide2", ["pyside2-rcc", "rcc2"]),
            ("PyQt5", ["pyrcc5", "pyrcc"]),
        ],
    )
    def test_compile_qrc_compiler_selection(
        self,
        tmp_path: Path,
        pyside_version: str,
        expected_compilers: list,
    ) -> None:
        """测试根据 PySide 版本选择编译器."""
        qrc_path = tmp_path / "test.qrc"
        qrc_path.write_text("<RCC></RCC>")
        output_path = tmp_path / "test_rc.py"

        loader = QRCLoader()

        with patch(
            "bitool.gui._qrcloader._pyside_version",
            pyside_version,
        ), patch("subprocess.run") as mock_run:
            # 模拟第一个编译器失败，第二个成功
            mock_run.side_effect = [
                FileNotFoundError("编译器未找到"),
                MagicMock(returncode=0),
            ]

            result = loader._compile_qrc(qrc_path, output_path)
            assert result is True

            # 验证尝试了期望的编译器
            assert mock_run.call_count == 2
            called_compilers = [call[0][0][0] for call in mock_run.call_args_list]
            assert called_compilers == expected_compilers

    def test_compile_qrc_no_compilers_found(self, tmp_path: Path) -> None:
        """测试没有找到可用的编译器时返回 False."""
        qrc_path = tmp_path / "test.qrc"
        qrc_path.write_text("<RCC></RCC>")
        output_path = tmp_path / "test_rc.py"

        loader = QRCLoader()

        with patch(
            "bitool.gui._qrcloader._pyside_version",
            "PySide6",
        ), patch("subprocess.run", side_effect=FileNotFoundError("编译器未找到")):
            result = loader._compile_qrc(qrc_path, output_path)
            assert result is False

    def test_import_rc_module_success(self, tmp_path: Path) -> None:
        """测试成功导入资源模块."""
        from bitool.gui._qrcloader import _pyside_version

        rc_path = tmp_path / "test_rc.py"
        rc_path.write_text(
            f"""
from {_pyside_version} import QtCore
# test code
""",
            encoding="utf-8",
        )

        loader = QRCLoader()
        module_name = "test_rc"

        try:
            result = loader._import_rc_module(rc_path, module_name)
            assert result is True
        finally:
            # 清理
            if module_name in sys.modules:
                del sys.modules[module_name]

    def test_import_rc_module_already_loaded(self, tmp_path: Path) -> None:
        """测试资源模块已经加载时的行为."""
        rc_path = tmp_path / "test_rc.py"
        rc_path.write_text("")

        loader = QRCLoader()
        module_name = "already_loaded_module"

        # 模拟模块已存在于 sys.modules 中
        import sys

        sys.modules[module_name] = MagicMock()

        try:
            result = loader._import_rc_module(rc_path, module_name)
            assert result is True
        finally:
            # 清理
            if module_name in sys.modules:
                del sys.modules[module_name]

    def test_import_rc_module_error_handling(self, tmp_path: Path) -> None:
        """测试导入资源模块时的错误处理."""
        rc_path = tmp_path / "test_rc.py"
        rc_path.write_text("invalid syntax!!!")  # 无效的 Python 语法

        loader = QRCLoader()

        result = loader._import_rc_module(rc_path, "test_rc")
        assert result is False

    def test_load_qrc_with_existing_rc_file(self, tmp_path: Path) -> None:
        """测试加载 QRC 并且已有编译好的 rc 文件."""
        qrc_file = tmp_path / "test.qrc"
        qrc_file.write_text("<RCC></RCC>")
        rc_file = tmp_path / "test_rc.py"
        rc_file.write_text("from PyQt5 import QtCore\n")

        loader = QRCLoader()
        MagicMock()
        mock_module = MagicMock()
        mock_module.__file__ = str(tmp_path / "test.py")

        with patch(
            "bitool.gui._qrcloader.inspect.getmodule",
            return_value=mock_module,
        ), patch.object(loader, "_import_rc_module", return_value=True):
            result = loader.load_qrc(qrc_file)
            assert result is True

    def test_load_qrc_caching(self, tmp_path: Path) -> None:
        """测试 QRC 加载使用缓存."""
        qrc_file = tmp_path / "test.qrc"
        qrc_file.write_text("<RCC></RCC>")
        rc_file = tmp_path / "test_rc.py"
        rc_file.write_text("from PyQt5 import QtCore\n")

        loader = QRCLoader()

        with patch.object(loader, "_import_rc_module", return_value=True):
            # 第一次加载 (会跳过编译因为 rc 文件已存在且 mtime 更新)
            result1 = loader.load_qrc(qrc_file)
            # 第二次加载应该使用缓存
            result2 = loader.load_qrc(qrc_file)

            assert result1 is True
            assert result2 is True
            assert len(loader._cache) == 1

    def test_load_resources_method(self, tmp_path: Path) -> None:
        """测试 load_resources 方法（别名）."""
        qrc_file = tmp_path / "test.qrc"
        qrc_file.write_text("<RCC></RCC>")

        loader = QRCLoader()

        with patch.object(loader, "load_qrc", return_value=True) as mock_load_qrc:
            result = loader.load_resources(qrc_file)
            mock_load_qrc.assert_called_once_with(qrc_file)
            assert result is True


class TestConvenienceFunctions:
    """模块级便捷函数测试."""

    def test_load_qrc_function(self) -> None:
        """测试 load_qrc 便捷函数."""
        assert callable(load_qrc)

    def test_load_resources_function(self) -> None:
        """测试 load_resources 便捷函数."""
        assert callable(load_resources)

    def test_clear_cache_function(self) -> None:
        """测试 clear_qrc_cache 便捷函数."""
        clear_qrc_cache()  # 不应该抛出错误

    def test_load_qrc_function_calls_default_loader(self, tmp_path: Path) -> None:
        """测试 load_qrc 函数调用默认加载器."""
        qrc_file = tmp_path / "test.qrc"
        qrc_file.write_text("<RCC></RCC>")

        with patch.object(
            _default_loader,
            "load_qrc",
            return_value=True,
        ) as mock_load:
            result = load_qrc(qrc_file)
            mock_load.assert_called_once_with(qrc_file)
            assert result is True

    def test_load_resources_function_calls_default_loader(self, tmp_path: Path) -> None:
        """测试 load_resources 函数调用默认加载器."""
        qrc_file = tmp_path / "test.qrc"
        qrc_file.write_text("<RCC></RCC>")

        with patch.object(
            _default_loader,
            "load_resources",
            return_value=True,
        ) as mock_load:
            result = load_resources(qrc_file)
            mock_load.assert_called_once_with(qrc_file)
            assert result is True

    def test_clear_cache_function_calls_default_loader(self) -> None:
        """测试 clear_qrc_cache 函数调用默认加载器."""
        with patch.object(_default_loader, "clear_cache") as mock_clear:
            clear_qrc_cache()
            mock_clear.assert_called_once()
