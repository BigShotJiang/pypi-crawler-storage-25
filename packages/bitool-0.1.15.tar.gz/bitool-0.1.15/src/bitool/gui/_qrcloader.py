"""动态 QRC 资源加载器模块.

提供从 .qrc 文件动态加载资源的功能,避免维护 .qrc 和 _rc.py 两套文件.

使用示例:
    # 方式 1: 自动查找 .qrc 文件(推荐)
    from bitool.gui import load_qrc

    load_qrc()  # 自动查找同目录下的 qrc 文件

    # 方式 2: 手动指定 .qrc 文件
    from bitool.gui import QRCLoader

    loader = QRCLoader(base_path=Path('/path/to/qrc/files'))
    loader.load_qrc('resource.qrc')

    # 方式 3: 兼容现有导入模式
    from bitool.gui import load_resources
    load_resources()  # 自动加载同目录下的 qrc 文件
"""

from __future__ import annotations

import importlib.util
import inspect
import re
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING

from bitool.core import logger

from .compat import _pyside_version

if TYPE_CHECKING:
    from types import FrameType

__all__ = ["clear_qrc_cache", "load_qrc", "load_resources"]


class QRCLoader:
    """动态 QRC 资源加载器.

    提供从 .qrc 文件动态加载资源的功能,支持自动查找和手动指定两种方式.

    Parameters
    ----------
    base_path : Path or str, optional
        基础路径,用于相对路径查找 .qrc 文件

    Attributes
    ----------
    _cache : dict
        QRC 文件缓存,键为文件路径和修改时间
    base_path : Path or None
        基础路径
    """

    def __init__(self, base_path: Path | str | None = None) -> None:
        """初始化QRC加载器.

        Args:
            base_path: 基础路径,用于相对路径查找.qrc文件
        """
        self._cache: dict[str, bool] = {}
        self.base_path = Path(base_path) if base_path else None

    def _find_qrc_file(
        self,
        qrc_file: Path | str | None,
        caller_frame: FrameType,
    ) -> Path:
        """查找 QRC 文件.

        查找优先级:
        1. 如果 qrc_file 是绝对路径,直接使用
        2. 如果 qrc_file 是相对路径,相对于 base_path 查找
        3. 如果 qrc_file 为 None,自动查找调用者同级目录下的 qrc 文件

        Parameters
        ----------
        qrc_file : Path, str, or None
            QRC 文件路径,可以是绝对路径、相对路径或 None
        caller_frame : FrameType
            调用者帧对象

        Returns
        -------
        Path
            QRC 文件的绝对路径

        Raises
        ------
        FileNotFoundError
            无法找到 QRC 文件时抛出
        """
        if qrc_file is None:
            caller_module = inspect.getmodule(caller_frame)
            if caller_module and caller_module.__file__:
                caller_dir = Path(caller_module.__file__).parent
                # 查找目录下所有 .qrc 文件并按名称排序,确保结果确定性
                qrc_files = sorted(caller_dir.glob("*.qrc"))
                if qrc_files:
                    # 如果找到多个，优先查找名为 resource.qrc 的
                    for qrc in qrc_files:
                        if qrc.stem == "resource":
                            logger.info(f"自动找到QRC文件: {qrc}")
                            return qrc
                    # 否则返回找到的第一个
                    logger.info(f"自动找到QRC文件: {qrc_files[0]}")
                    return qrc_files[0]
            raise FileNotFoundError(
                "无法自动找到.qrc文件,请确保同级目录存在.qrc文件",
            )

        qrc_path = Path(qrc_file)
        if not qrc_path.is_absolute():
            qrc_path = (self.base_path or Path.cwd()) / qrc_path

        if not qrc_path.exists():
            msg = f"QRC文件不存在: {qrc_path}"
            raise FileNotFoundError(msg)

        logger.info(f"找到QRC文件: {qrc_path}")
        return qrc_path

    def _get_cache_key(self, qrc_file: Path) -> str:
        """生成缓存键.

        使用文件路径和修改时间作为缓存键,确保文件修改后能自动重新加载.

        Parameters
        ----------
        qrc_file : Path
            QRC 文件路径

        Returns
        -------
        str
            缓存键字符串
        """
        return f"{qrc_file.absolute()}:{qrc_file.stat().st_mtime}"

    def _compile_qrc(self, qrc_path: Path, output_path: Path) -> bool:
        """编译 .qrc 文件为 _rc.py 模块.

        尝试使用合适的资源编译器编译 qrc 文件.

        Parameters
        ----------
        qrc_path : Path
            输入的 .qrc 文件路径
        output_path : Path
            输出的 _rc.py 文件路径

        Returns
        -------
        bool
            编译是否成功
        """
        # 确定使用的资源编译器
        compilers = []
        if _pyside_version == "PySide6":
            compilers = ["pyside6-rcc", "rcc6"]
        elif _pyside_version == "PySide2":
            compilers = ["pyside2-rcc", "rcc2"]
        elif _pyside_version == "PyQt5":
            compilers = ["pyrcc5", "pyrcc"]

        if not compilers:
            logger.warning(f"未知的 PySide 版本: {_pyside_version}")
            return False

        success = False
        for compiler in compilers:
            try:
                subprocess.run(
                    [compiler, "-o", str(output_path), str(qrc_path)],
                    capture_output=True,
                    text=True,
                    cwd=qrc_path.parent,
                    check=True,
                )
                logger.info(f"使用 {compiler} 成功编译 QRC 文件")
                success = True
                break
            except (subprocess.SubprocessError, FileNotFoundError) as e:
                logger.debug(f"使用 {compiler} 编译失败: {e}")
                continue

        if not success:
            logger.warning(
                f"无法找到可用的资源编译器 (尝试过: {', '.join(compilers)})",
            )
        return success

    def _import_rc_module(
        self,
        rc_py_path: Path,
        module_name: str,
    ) -> bool:
        """动态导入资源模块，自动处理PySide版本兼容性.

        Parameters
        ----------
        rc_py_path : Path
            _rc.py 文件路径
        module_name : str
            模块名称

        Returns
        -------
        bool
            导入是否成功
        """
        try:
            # 如果模块已经存在，直接返回成功，避免重复导入
            if module_name in sys.modules:
                logger.debug(f"资源模块已加载: {module_name}")
                return True

            # 确保文件所在目录在 sys.path 中
            module_dir = str(rc_py_path.parent)
            if module_dir not in sys.path:
                sys.path.insert(0, module_dir)

            # 读取 resource_rc.py 文件内容并替换 PySide 版本导入语句
            with open(rc_py_path, encoding="utf-8") as f:
                content = f.read()

            # 使用正则表达式查找 import 语句
            # 匹配格式：from PySide2 import ... 或 from PyQt5 import ... 或 from PySide6 import ...
            import_pattern = r"from\s+(PySide[26]|PyQt5)\s+import\s+(.*)"
            match = re.search(import_pattern, content, re.MULTILINE)

            if match:
                # 提取 import 后面的内容
                import_content = match.group(2).strip()
                # 替换为当前 PySide 版本
                new_import_line = f"from {_pyside_version} import {import_content}"
                # 替换整个匹配行
                content = re.sub(
                    import_pattern,
                    new_import_line,
                    content,
                    count=1,
                    flags=re.MULTILINE,
                )

            # 创建临时模块
            spec = importlib.util.spec_from_file_location(module_name, rc_py_path)
            if spec is None or spec.loader is None:
                logger.warning(f"无法创建模块规范: {rc_py_path}")
                return False

            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module

            # 执行修改后的内容
            exec(content, module.__dict__)  # noqa: S102

            logger.info(f"成功导入资源模块: {rc_py_path}")
            return True

        except (
            OSError,
            UnicodeDecodeError,
            SyntaxError,
            ImportError,
            ModuleNotFoundError,
        ) as e:
            logger.warning(f"导入资源模块时出错 {rc_py_path}: {e}")
            # 清理可能已创建的模块
            if module_name in sys.modules:
                del sys.modules[module_name]
            return False

    def load_qrc(
        self,
        qrc_file: Path | str | None = None,
    ) -> bool:
        """动态加载 QRC 文件.

        Parameters
        ----------
        qrc_file : Path, str, or None, optional
            QRC 文件路径,可以是绝对路径、相对路径或 None(自动查找)

        Returns
        -------
        bool
            加载是否成功

        Raises
        ------
        FileNotFoundError
            找不到 QRC 文件时抛出
        """
        caller_frame = inspect.currentframe()
        if caller_frame is None or caller_frame.f_back is None:
            raise RuntimeError("无法获取调用者信息")

        # 跳过 _qrcloader.py 内部的帧，找到真正的外部调用者
        target_frame = caller_frame.f_back
        while target_frame is not None:
            frame_module = inspect.getmodule(target_frame)
            if frame_module is None or not frame_module.__file__:
                target_frame = target_frame.f_back
                continue
            # 如果帧来自 _qrcloader.py，继续往上找
            if Path(frame_module.__file__).name == "_qrcloader.py":
                target_frame = target_frame.f_back
            else:
                break

        if target_frame is None:
            # 如果找不到外部调用者，使用第一级调用者
            target_frame = caller_frame.f_back

        qrc_path = self._find_qrc_file(qrc_file, target_frame)

        # 检查缓存
        cache_key = self._get_cache_key(qrc_path)
        if cache_key in self._cache:
            logger.debug(f"从缓存加载 QRC: {qrc_path}")
            return self._cache[cache_key]

        # 先尝试查找同目录下已编译的 _rc.py 文件
        rc_module_name = qrc_path.stem + "_rc"
        rc_py_path = qrc_path.with_name(rc_module_name + ".py")

        # 如果 _rc.py 文件不存在或需要重新编译
        if (
            not rc_py_path.exists()
            or qrc_path.stat().st_mtime > rc_py_path.stat().st_mtime
        ):
            logger.info(f"需要编译 QRC 文件: {qrc_path}")
            # 在临时目录中编译，避免污染源目录
            with tempfile.TemporaryDirectory() as temp_dir:
                temp_rc_path = Path(temp_dir) / (rc_module_name + ".py")
                # 复制 qrc 文件到临时目录（如果需要）
                temp_qrc_path = Path(temp_dir) / qrc_path.name
                # 读取并写入 qrc 文件（处理相对路径）
                with open(qrc_path, encoding="utf-8") as f:
                    qrc_content = f.read()
                # 复制引用的资源文件到临时目录
                from xml.etree import ElementTree as ET

                try:
                    root = ET.fromstring(qrc_content)
                    for qresource in root.findall("qresource"):
                        for file_elem in qresource.findall("file"):
                            file_path = file_elem.text
                            if file_path:
                                src_file = qrc_path.parent / file_path
                                dest_file = Path(temp_dir) / file_path
                                dest_file.parent.mkdir(parents=True, exist_ok=True)
                                if src_file.exists():
                                    import shutil

                                    shutil.copy2(src_file, dest_file)
                except ET.ParseError as e:
                    logger.warning(f"解析 QRC 文件失败: {e}")
                # 写入 qrc 文件到临时目录
                with open(temp_qrc_path, "w", encoding="utf-8") as f:
                    f.write(qrc_content)
                # 尝试编译
                if not self._compile_qrc(temp_qrc_path, temp_rc_path):
                    logger.warning(
                        "编译失败，尝试使用现有 _rc.py 文件或继续尝试加载",
                    )
                    if not rc_py_path.exists():
                        self._cache[cache_key] = False
                        return False
                else:
                    # 复制编译后的文件到源目录
                    import shutil

                    shutil.copy2(temp_rc_path, rc_py_path)
                    logger.info(f"成功编译 QRC 文件: {rc_py_path}")

        # 导入资源模块
        success = self._import_rc_module(rc_py_path, rc_module_name)
        self._cache[cache_key] = success
        return success

    def load_resources(
        self,
        qrc_file: Path | str | None = None,
    ) -> bool:
        """便捷方法:加载资源文件.

        Args:
            qrc_file: QRC文件路径,可以是绝对路径、相对路径或None(自动查找)

        Returns:
            加载是否成功
        """
        return self.load_qrc(qrc_file)

    def clear_cache(self) -> None:
        """清除缓存.

        当 .qrc 文件被修改后,可以调用此方法清除缓存以重新加载.
        """
        self._cache.clear()
        logger.debug("QRC加载器缓存已清除")


# 模块级别的默认加载器实例
_default_loader = QRCLoader()


def load_qrc(
    qrc_file: Path | str | None = None,
) -> bool:
    """便捷函数:加载QRC文件.

    Args:
        qrc_file: QRC文件路径,可以是绝对路径、相对路径或None(自动查找)

    Returns:
        加载是否成功
    """
    return _default_loader.load_qrc(qrc_file)


def load_resources(
    qrc_file: Path | str | None = None,
) -> bool:
    """便捷函数:加载资源文件.

    Args:
        qrc_file: QRC文件路径,可以是绝对路径、相对路径或None(自动查找)

    Returns:
        加载是否成功
    """
    return _default_loader.load_resources(qrc_file)


def clear_qrc_cache() -> None:
    """便捷函数:清除QRC加载器缓存."""
    _default_loader.clear_cache()
