"""文件操作工具模块.

提供统一的文件操作工具函数,避免重复实现.
"""

from __future__ import annotations

import shutil
from pathlib import Path

from bitool.core import logger


def ensure_dir_exists(filepath: Path) -> bool:
    """确保文件父目录存在.

    参数:
        filepath: 文件路径

    返回:
        目录创建是否成功
    """
    try:
        filepath.parent.mkdir(parents=True, exist_ok=True)
        logger.info(msg=f"已创建目录: `{filepath.parent}`")
    except OSError as e:
        logger.error(msg=f"创建目录失败: `{e}`", exc_info=True)
        return False
    return True


def read_file_content(filepath: Path, encoding: str = "utf-8") -> str | None:
    """读取文件内容的公共函数.

    参数:
        filepath: 文件路径
        encoding: 文件编码,默认utf-8

    返回:
        文件内容,失败返回None
    """
    if not filepath.exists():
        logger.warning(msg=f"文件不存在: `{filepath}`")
        return None

    if not filepath.is_file():
        logger.warning(msg=f"路径不是文件: `{filepath}`")
        return None

    try:
        content = filepath.read_text(encoding=encoding)
        logger.info(msg=f"读取`{filepath}` 成功")
    except OSError as e:
        logger.error(msg=f"读取文件时出错: `{e}`", exc_info=True)
        return None
    except UnicodeDecodeError as e:
        logger.error(msg=f"文件编码错误: `{e}`", exc_info=True)
        return None
    else:
        return content


def write_file_content(
    filepath: Path,
    content: str,
    *,
    overwrite: bool = True,
    backup: bool = False,
    encoding: str = "utf-8",
) -> bool:
    """写入文件内容的公共函数.

    参数:
        filepath: 文件路径
        content: 文件内容
        overwrite: 是否覆盖已存在的文件
        backup: 写入前是否备份原文件
        encoding: 文件编码,默认utf-8

    返回:
        写入是否成功
    """
    if not ensure_dir_exists(filepath):
        return False

    if filepath.exists():
        if not overwrite:
            logger.warning(msg=f"文件已存在且不允许覆盖: `{filepath}`")
            return False

        if backup and backup_file(filepath) is None:
            return False

    try:
        filepath.write_text(data=content, encoding=encoding)
        logger.info(msg=f"写入`{filepath}` 成功")
    except OSError as e:
        logger.error(msg=f"写入文件时出错: `{e}`", exc_info=True)
        return False
    except UnicodeDecodeError as e:
        logger.error(msg=f"文件编码错误: `{e}`", exc_info=True)
        return False
    else:
        return True


def backup_file(filepath: Path, backup_path: Path | None = None) -> Path | None:
    """备份文件辅助函数.

    参数:
        filepath: 源文件路径
        backup_path: 备份文件路径,如果为None则自动生成

    返回:
        备份文件路径,如果备份失败则返回None
    """
    if not filepath.exists():
        logger.warning(msg=f"源文件不存在: `{filepath}`")
        return None

    if not filepath.is_file():
        logger.warning(msg=f"源路径不是文件: `{filepath}`")
        return None

    if backup_path is None or str(backup_path) == ".":
        backup_path = filepath.with_suffix(filepath.suffix + ".bak")

    try:
        backup_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(filepath, backup_path)
        logger.info(msg=f"已备份文件: `{filepath}` -> `{backup_path}`")
    except OSError as e:
        logger.error(msg=f"备份文件时出错: `{e}`", exc_info=True)
        return None
    else:
        return backup_path
