"""file_ops 模块测试."""

from __future__ import annotations

from pathlib import Path

from bitool.utils.file_ops import (
    backup_file,
    ensure_dir_exists,
    read_file_content,
    write_file_content,
)


class TestEnsureDirExists:
    """ensure_dir_exists 函数测试."""

    def test_create_dir_success(self, tmp_path: Path) -> None:
        """测试成功创建目录."""
        filepath = tmp_path / "subdir" / "file.txt"
        result = ensure_dir_exists(filepath)
        assert result is True
        assert filepath.parent.exists()

    def test_dir_already_exists(self, tmp_path: Path) -> None:
        """测试目录已存在."""
        subdir = tmp_path / "subdir"
        subdir.mkdir()
        filepath = subdir / "file.txt"
        result = ensure_dir_exists(filepath)
        assert result is True
        assert subdir.exists()

    def test_create_nested_dirs(self, tmp_path: Path) -> None:
        """测试创建多层父目录."""
        filepath = tmp_path / "a" / "b" / "c" / "file.txt"
        result = ensure_dir_exists(filepath)
        assert result is True
        assert filepath.parent.exists()


class TestReadFileContent:
    """read_file_content 函数测试."""

    def test_read_success(self, tmp_path: Path) -> None:
        """测试成功读取文件."""
        filepath = tmp_path / "test.txt"
        filepath.write_text("Hello, World!", encoding="utf-8")
        result = read_file_content(filepath)
        assert result == "Hello, World!"

    def test_read_with_encoding(self, tmp_path: Path) -> None:
        """测试指定编码读取."""
        filepath = tmp_path / "test.txt"
        filepath.write_text("中文测试", encoding="utf-8")
        result = read_file_content(filepath, encoding="utf-8")
        assert result == "中文测试"

    def test_read_file_not_exists(self, tmp_path: Path) -> None:
        """测试文件不存在."""
        filepath = tmp_path / "not_exists.txt"
        result = read_file_content(filepath)
        assert result is None

    def test_read_is_directory(self, tmp_path: Path) -> None:
        """测试路径是目录."""
        filepath = tmp_path / "subdir"
        filepath.mkdir()
        result = read_file_content(filepath)
        assert result is None


class TestWriteFileContent:
    """write_file_content 函数测试."""

    def test_write_new_file(self, tmp_path: Path) -> None:
        """测试写入新文件."""
        filepath = tmp_path / "new.txt"
        result = write_file_content(filepath, "content")
        assert result is True
        assert filepath.read_text() == "content"

    def test_overwrite_existing(self, tmp_path: Path) -> None:
        """测试覆盖已存在文件."""
        filepath = tmp_path / "existing.txt"
        filepath.write_text("old content")
        result = write_file_content(filepath, "new content", overwrite=True)
        assert result is True
        assert filepath.read_text() == "new content"

    def test_no_overwrite(self, tmp_path: Path) -> None:
        """测试不允许覆盖."""
        filepath = tmp_path / "existing.txt"
        filepath.write_text("old content")
        result = write_file_content(filepath, "new content", overwrite=False)
        assert result is False
        assert filepath.read_text() == "old content"

    def test_backup_before_write(self, tmp_path: Path) -> None:
        """测试写入前备份."""
        filepath = tmp_path / "backup_test.txt"
        filepath.write_text("original")
        result = write_file_content(filepath, "modified", backup=True)
        assert result is True
        assert filepath.read_text() == "modified"
        assert filepath.with_suffix(filepath.suffix + ".bak").exists()

    def test_create_parent_directory(self, tmp_path: Path) -> None:
        """测试自动创建父目录."""
        filepath = tmp_path / "subdir" / "nested" / "file.txt"
        result = write_file_content(filepath, "content")
        assert result is True
        assert filepath.exists()
        assert filepath.read_text() == "content"


class TestBackupFile:
    """backup_file 函数测试."""

    def test_backup_auto_path(self, tmp_path: Path) -> None:
        """测试自动生成备份路径."""
        filepath = tmp_path / "test.txt"
        filepath.write_text("content")
        result = backup_file(filepath)
        assert result is not None
        assert result.name == "test.txt.bak"
        assert result.exists()
        assert result.read_text() == "content"

    def test_backup_custom_path(self, tmp_path: Path) -> None:
        """测试指定备份路径."""
        filepath = tmp_path / "test.txt"
        filepath.write_text("content")
        backup_path = tmp_path / "custom_backup.txt"
        result = backup_file(filepath, backup_path)
        assert result == backup_path
        assert backup_path.exists()
        assert backup_path.read_text() == "content"

    def test_backup_creates_parent_dir(self, tmp_path: Path) -> None:
        """测试创建父目录."""
        subdir = tmp_path / "subdir"
        subdir.mkdir()
        filepath = subdir / "test.txt"
        filepath.write_text("content")
        backup_path = tmp_path / "backup" / "test.txt.bak"
        result = backup_file(filepath, backup_path)
        assert result == backup_path
        assert backup_path.exists()

    def test_backup_file_not_exists(self, tmp_path: Path) -> None:
        """测试源文件不存在."""
        filepath = tmp_path / "not_exists.txt"
        result = backup_file(filepath)
        assert result is None

    def test_backup_is_directory(self, tmp_path: Path) -> None:
        """测试源路径是目录."""
        filepath = tmp_path / "subdir"
        filepath.mkdir()
        result = backup_file(filepath)
        assert result is None
