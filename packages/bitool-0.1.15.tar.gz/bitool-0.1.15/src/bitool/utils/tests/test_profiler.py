"""性能分析工具模块测试."""

import os
import time
from typing import Generator, NoReturn
from unittest.mock import patch

import pytest

from bitool.utils.profiler import (
    _MS_PER_SEC,
    _FuncStats,
    _PyProfileRecord,
    _PythonPerformanceProfiler,
)


@pytest.fixture(autouse=True)
def enable_profiling() -> Generator[None, None, None]:
    """启用性能分析环境变量."""
    with patch.dict(os.environ, {"BITOOL_PROFILE": "1"}):
        yield


@pytest.fixture
def python_profiler() -> _PythonPerformanceProfiler:
    """创建 Python 性能分析器实例."""
    return _PythonPerformanceProfiler()


class TestPyProfileRecord:
    """测试性能记录数据结构."""

    def test_create_record(self) -> None:
        """测试创建性能记录."""
        record = _PyProfileRecord(
            name="test_func",
            duration_secs=1.5,
            memory_before_mb=10.0,
            memory_after_mb=12.5,
            memory_delta_mb=2.5,
            timestamp="2024-01-01 12:00:00",
        )

        assert record.name == "test_func"
        assert record.duration_secs == 1.5
        assert record.memory_before_mb == 10.0
        assert record.memory_after_mb == 12.5
        assert record.memory_delta_mb == 2.5
        assert record.timestamp == "2024-01-01 12:00:00"

    def test_default_values(self) -> None:
        """测试默认值."""
        record = _PyProfileRecord(name="test", duration_secs=1.0)

        assert record.memory_before_mb == 0.0
        assert record.memory_after_mb == 0.0
        assert record.memory_delta_mb == 0.0
        assert record.timestamp == ""

    def test_record_with_zero_duration(self) -> None:
        """测试零耗时记录."""
        record = _PyProfileRecord(name="instant_func", duration_secs=0.0)
        assert record.duration_secs == 0.0
        assert record.name == "instant_func"

    def test_record_with_negative_memory(self) -> None:
        """测试负内存变化记录."""
        record = _PyProfileRecord(
            name="memory_release_func",
            duration_secs=0.5,
            memory_before_mb=20.0,
            memory_after_mb=15.0,
            memory_delta_mb=-5.0,
        )
        assert record.memory_delta_mb == -5.0


class TestPythonPerformanceProfiler:
    """测试 Python 性能分析器实现."""

    def test_start_and_stop_timer(
        self,
        python_profiler: _PythonPerformanceProfiler,
    ) -> None:
        """测试开始和停止计时."""
        python_profiler.start_timer("test_func")
        time.sleep(0.01)
        record = python_profiler.stop_timer("test_func")

        assert record is not None
        assert record.name == "test_func"
        assert record.duration_secs >= 0.004  # 降低阈值，考虑时间精度问题
        assert record.duration_secs < 1.0  # 应该小于 1 秒

    def test_stop_nonexistent_timer(
        self,
        python_profiler: _PythonPerformanceProfiler,
    ) -> None:
        """测试停止不存在的计时器."""
        record = python_profiler.stop_timer("nonexistent")

        assert record is None

    def test_multiple_timers(self, python_profiler: _PythonPerformanceProfiler) -> None:
        """测试多个计时器."""
        python_profiler.start_timer("func1")
        python_profiler.start_timer("func2")
        time.sleep(0.01)

        record1 = python_profiler.stop_timer("func1")
        record2 = python_profiler.stop_timer("func2")

        assert record1 is not None
        assert record2 is not None
        assert record1.name == "func1"
        assert record2.name == "func2"

    def test_get_records(self, python_profiler: _PythonPerformanceProfiler) -> None:
        """测试获取记录."""
        python_profiler.start_timer("func1")
        python_profiler.stop_timer("func1")
        python_profiler.start_timer("func2")
        python_profiler.stop_timer("func2")

        records = python_profiler.get_records()

        assert len(records) == 2
        assert records[0].name == "func1"
        assert records[1].name == "func2"

    def test_get_call_count(self, python_profiler: _PythonPerformanceProfiler) -> None:
        """测试获取调用次数."""
        python_profiler.start_timer("func1")
        python_profiler.stop_timer("func1")
        python_profiler.start_timer("func1")
        python_profiler.stop_timer("func1")
        python_profiler.start_timer("func2")
        python_profiler.stop_timer("func2")

        assert python_profiler.get_call_count("func1") == 2
        assert python_profiler.get_call_count("func2") == 1
        assert python_profiler.get_call_count("nonexistent") == 0

    def test_clear(self, python_profiler: _PythonPerformanceProfiler) -> None:
        """测试清除记录."""
        python_profiler.start_timer("func1")
        python_profiler.stop_timer("func1")

        python_profiler.clear()

        assert len(python_profiler.get_records()) == 0
        assert python_profiler.get_call_count("func1") == 0

    def test_memory_tracking(self, python_profiler: _PythonPerformanceProfiler) -> None:
        """测试内存追踪."""
        python_profiler.start_timer("memory_test")
        # 分配一些内存
        _data = list(range(10000))
        record = python_profiler.stop_timer("memory_test")

        assert record is not None
        # 内存追踪应该工作（可能为 0 如果 tracemalloc 未启动）
        assert isinstance(record.memory_before_mb, float)
        assert isinstance(record.memory_after_mb, float)
        assert isinstance(record.memory_delta_mb, float)

    def test_records_are_copied(
        self,
        python_profiler: _PythonPerformanceProfiler,
    ) -> None:
        """测试获取记录返回副本."""
        python_profiler.start_timer("func1")
        python_profiler.stop_timer("func1")

        records1 = python_profiler.get_records()
        records2 = python_profiler.get_records()

        # 应该是不同的列表对象
        assert records1 is not records2
        # 但内容应该相同
        assert len(records1) == len(records2)
        assert records1[0].name == records2[0].name

    def test_timer_overwrite(self, python_profiler: _PythonPerformanceProfiler) -> None:
        """测试同名计时器覆盖."""
        python_profiler.start_timer("func1")
        time.sleep(0.01)
        # 再次启动同名计时器会覆盖
        python_profiler.start_timer("func1")
        time.sleep(0.01)
        record = python_profiler.stop_timer("func1")

        assert record is not None
        # 应该只记录了第二次的时间
        assert record.duration_secs >= 0.005


class TestProfileDecorator:
    """测试 @profile 装饰器."""

    def test_profile_disabled(self) -> None:
        """测试性能分析禁用时."""
        with patch.dict(os.environ, {"BITOOL_PROFILE": "0"}, clear=True):
            # 重新导入以应用环境变量
            import importlib

            from bitool.utils import profiler

            importlib.reload(profiler)

            @profiler.profile
            def test_func() -> int:
                return 42

            result = test_func()
            assert result == 42

    def test_profile_enabled(self) -> None:
        """测试性能分析启用时."""
        # 创建新的包装器实例以避免缓存问题
        from bitool.utils.profiler import _PerformanceProfilerWrapper

        wrapper = _PerformanceProfilerWrapper()

        @wrapper.profile
        def test_func() -> str:
            time.sleep(0.01)
            return "test_result"

        result = test_func()

        assert result == "test_result"
        # 应该有记录
        assert len(wrapper.records) > 0
        assert wrapper.records[-1].name == "test_func"

    def test_profile_with_exception(self) -> None:
        """测试装饰器处理异常."""
        from bitool.utils.profiler import _PerformanceProfilerWrapper

        wrapper = _PerformanceProfilerWrapper()

        @wrapper.profile
        def failing_func() -> NoReturn:
            raise ValueError("测试异常")

        with pytest.raises(ValueError, match="测试异常"):
            failing_func()

    def test_profile_preserves_function_metadata(self) -> None:
        """测试装饰器保留函数元数据."""
        from bitool.utils.profiler import _PerformanceProfilerWrapper

        wrapper = _PerformanceProfilerWrapper()

        @wrapper.profile
        def documented_func() -> str:
            """这是一个有文档的函数."""
            return "test"

        # functools.wraps 应该保留这些属性
        assert documented_func.__name__ == "documented_func"
        # 注意：装饰器可能会修改 __doc__，这不是必须的

    def test_profile_recursive_function(self) -> None:
        """测试装饰器处理递归函数."""
        from bitool.utils.profiler import _PerformanceProfilerWrapper

        wrapper = _PerformanceProfilerWrapper()
        call_count_holder = {"count": 0}

        def factorial_impl(n: int) -> int:
            """不使用装饰器的递归实现."""
            call_count_holder["count"] += 1
            if n <= 1:
                return 1
            return n * factorial_impl(n - 1)

        @wrapper.profile
        def factorial(n: int) -> int:
            return factorial_impl(n)

        result = factorial(5)
        assert result == 120
        # 应该只有 1 次 profiler 记录（外层调用）
        assert len(wrapper.records) == 1

    def test_profile_nested_calls(self) -> None:
        """测试嵌套函数调用."""
        from bitool.utils.profiler import _PerformanceProfilerWrapper

        wrapper = _PerformanceProfilerWrapper()

        @wrapper.profile
        def inner_func() -> str:
            time.sleep(0.01)
            return "inner"

        @wrapper.profile
        def outer_func() -> str:
            result = inner_func()
            time.sleep(0.01)
            return f"outer_{result}"

        result = outer_func()

        assert result == "outer_inner"
        # 应该有两个函数的记录
        assert len(wrapper.records) >= 2

    def test_profile_with_args(self) -> None:
        """测试装饰器处理带参数的函数."""
        from bitool.utils.profiler import _PerformanceProfilerWrapper

        wrapper = _PerformanceProfilerWrapper()

        @wrapper.profile
        def add(a: int, b: int) -> int:
            return a + b

        result = add(3, 5)

        assert result == 8
        assert len(wrapper.records) > 0

    def test_profile_with_kwargs(self) -> None:
        """测试装饰器处理带关键字参数的函数."""
        from bitool.utils.profiler import _PerformanceProfilerWrapper

        wrapper = _PerformanceProfilerWrapper()

        @wrapper.profile
        def greet(name: str, greeting: str = "Hello") -> str:
            return f"{greeting}, {name}!"

        result = greet("World", greeting="Hi")

        assert result == "Hi, World!"
        assert len(wrapper.records) > 0


class TestFuncStats:
    """测试函数统计数据."""

    def test_default_values(self) -> None:
        """测试默认值."""
        stats = _FuncStats()

        assert stats.total_time == 0.0
        assert stats.call_count == 0
        assert stats.memory_delta == 0.0

    def test_accumulation(self) -> None:
        """测试数据累加."""
        stats = _FuncStats()
        stats.total_time += 1.0
        stats.call_count += 1
        stats.memory_delta += 0.5

        assert stats.total_time == 1.0
        assert stats.call_count == 1
        assert stats.memory_delta == 0.5


class TestProfilerConstants:
    """测试常量定义."""

    def test_time_constants(self) -> None:
        """测试时间相关常量."""
        assert _MS_PER_SEC == 1000

    def test_display_constants_types(self) -> None:
        """测试显示常量类型."""
        from bitool.utils.profiler import (
            _COL_CALL_COUNT_STYLE,
            _COL_DURATION_STYLE,
            _COL_FUNC_NAME_STYLE,
            _COL_MEMORY_STYLE,
            _COL_PERCENTAGE_STYLE,
            _CONSOLE_WIDTH,
            _TABLE_BORDER_STYLE,
            _TABLE_HEADER_STYLE,
            _TABLE_TITLE_STYLE,
        )

        assert isinstance(_CONSOLE_WIDTH, int)
        assert isinstance(_TABLE_TITLE_STYLE, str)
        assert isinstance(_TABLE_BORDER_STYLE, str)
        assert isinstance(_TABLE_HEADER_STYLE, str)
        assert isinstance(_COL_FUNC_NAME_STYLE, str)
        assert isinstance(_COL_DURATION_STYLE, str)
        assert isinstance(_COL_PERCENTAGE_STYLE, str)
        assert isinstance(_COL_CALL_COUNT_STYLE, str)
        assert isinstance(_COL_MEMORY_STYLE, str)


class TestProfilerWrapper:
    """测试性能分析器包装器."""

    def test_clear_resets_state(self) -> None:
        """测试清除操作重置状态."""
        from bitool.utils.profiler import _profiler_wrapper

        # 添加一些记录
        _profiler_wrapper.profiler.start_timer("test")
        _profiler_wrapper.profiler.stop_timer("test")

        # 清除
        _profiler_wrapper.clear()

        # 记录应该被清除
        # 注意：cached_property 会缓存，所以需要重新访问
        assert len(_profiler_wrapper.profiler.get_records()) == 0

    def test_cached_properties(self) -> None:
        """测试缓存属性."""
        from bitool.utils.profiler import _PerformanceProfilerWrapper

        wrapper = _PerformanceProfilerWrapper()

        # 添加记录
        wrapper.profiler.start_timer("func1")
        time.sleep(0.01)
        wrapper.profiler.stop_timer("func1")

        # 访问缓存属性
        records = wrapper.records
        total_time = wrapper.total_time
        func_stats = wrapper.func_stats
        sorted_funcs = wrapper.sorted_funcs

        assert isinstance(records, list)
        assert isinstance(total_time, (int, float))  # 可能是 0 或 float
        assert isinstance(func_stats, dict)
        assert isinstance(sorted_funcs, list)

        # 验证排序
        if len(sorted_funcs) > 1:
            for i in range(len(sorted_funcs) - 1):
                assert (
                    sorted_funcs[i][1].total_time >= sorted_funcs[i + 1][1].total_time
                )

    def test_format_duration(self) -> None:
        """测试时间格式化."""
        from bitool.utils.profiler import _profiler_wrapper

        # 测试秒级
        assert _profiler_wrapper._format_duration(1.5) == "1.50s"
        assert _profiler_wrapper._format_duration(2.0) == "2.00s"
        assert _profiler_wrapper._format_duration(1.0) == "1.00s"

        # 测试毫秒级
        assert _profiler_wrapper._format_duration(0.5) == "500ms"
        assert _profiler_wrapper._format_duration(0.001) == "1ms"
        assert _profiler_wrapper._format_duration(0.999) == "999ms"

        # 测试微秒级
        assert _profiler_wrapper._format_duration(0.0005) == "500μs"
        assert _profiler_wrapper._format_duration(0.0001) == "100μs"
        assert _profiler_wrapper._format_duration(0.0) == "0μs"

    def test_format_memory(self) -> None:
        """测试内存格式化."""
        from bitool.utils.profiler import _profiler_wrapper

        # 测试显著变化
        assert _profiler_wrapper._format_memory(1.5) == "+1.50MB"
        assert _profiler_wrapper._format_memory(-0.5) == "-0.50MB"
        assert _profiler_wrapper._format_memory(0.0) == "~0MB"  # 0 在阈值内

        # 测试阈值内
        assert _profiler_wrapper._format_memory(0.005) == "~0MB"
        assert _profiler_wrapper._format_memory(-0.005) == "~0MB"
        assert _profiler_wrapper._format_memory(0.009) == "~0MB"  # 略小于阈值
        assert _profiler_wrapper._format_memory(0.011) == "+0.01MB"  # 略大于阈值

    def test_truncate_func_name(self) -> None:
        """测试函数名截断."""
        from bitool.utils.profiler import _profiler_wrapper

        # 短名称不截断
        assert _profiler_wrapper._truncate_func_name("short_name") == "short_name"
        assert (
            _profiler_wrapper._truncate_func_name("exact_28_chars_long_name_")
            == "exact_28_chars_long_name_"
        )

        # 长名称截断
        long_name = "very_very_very_very_long_function_name"
        truncated = _profiler_wrapper._truncate_func_name(long_name)
        assert len(truncated) == 28  # 25 + 3 for "..."
        assert truncated.endswith("...")
        assert truncated == "very_very_very_very_long_..."  # 修正期望值

        # 边界情况
        name_29_chars = "a" * 29
        truncated_29 = _profiler_wrapper._truncate_func_name(name_29_chars)
        assert len(truncated_29) == 28
        assert truncated_29 == "a" * 25 + "..."
