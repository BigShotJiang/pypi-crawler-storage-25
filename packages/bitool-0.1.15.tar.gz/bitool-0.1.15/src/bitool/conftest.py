"""Conftest module for bitool."""

import atexit
import contextlib
from pathlib import Path
from typing import Generator

import pytest


@pytest.fixture
def mock_enable_caplog(monkeypatch: pytest.MonkeyPatch) -> None:
    from bitool.core.logger import logger

    monkeypatch.setattr(logger, "propagate", True)


@pytest.fixture(scope="session", autouse=True)
def setup_global_temp_config(
    tmp_path_factory: pytest.TempPathFactory,
) -> Generator[Path, None, None]:
    """在测试会话开始时设置全局临时配置目录.

    这个 fixture 在所有模块导入之前执行，确保即使在模块级别实例化的
    JsonConfig 子类也会使用临时目录而不是用户目录。

    这解决了 pytest-xdist 环境下多个 worker 进程竞争访问
    C:\\Users\\zhou\\.bitool\\*.json 导致的 PermissionError 问题。
    """
    from bitool.core import JsonConfig

    # 创建会话级临时目录
    temp_dir = tmp_path_factory.mktemp("bitool_config_session")

    # 直接修改类属性，在整个会话期间生效
    original_root_dir = JsonConfig.ROOT_DIR
    JsonConfig.ROOT_DIR = temp_dir

    yield temp_dir

    # 恢复原始值
    JsonConfig.ROOT_DIR = original_root_dir


@pytest.fixture(scope="session", autouse=True)
def setup_global_temp_logger(
    tmp_path_factory: pytest.TempPathFactory,
) -> Generator[Path, None, None]:
    """在测试会话开始时设置全局临时日志目录.

    这个 fixture 在所有模块导入之前执行，确保即使在模块级别初始化的
    logger 也会使用临时目录而不是用户目录。

    这解决了 pytest-xdist 环境下多个 worker 进程竞争访问
    C:\\Users\\zhou\\.bitool\\logs\\*.log 导致的 PermissionError 和死锁问题。
    """
    from bitool.core import logger
    from bitool.core.logger import _DEFAULT_LOG_DIR, _DEFAULT_LOG_FILE, _Logger

    # 创建会话级临时日志目录
    temp_log_dir = tmp_path_factory.mktemp("bitool_logs_session")

    # 保存原始值
    original_log_dir = _DEFAULT_LOG_DIR
    original_log_file = _DEFAULT_LOG_FILE
    original_instance = _Logger._instance
    original_is_setup = _Logger._is_setup

    # 使用临时路径替换
    import sys

    sys.modules["bitool.core.logger"]._DEFAULT_LOG_DIR = temp_log_dir  # ty:ignore[unresolved-attribute]
    sys.modules["bitool.core.logger"]._DEFAULT_LOG_FILE = temp_log_dir / "bitool.log"  # ty:ignore[unresolved-attribute]

    # 重置日志器状态
    _Logger._instance = None
    _Logger._is_setup = False

    # 清理现有的日志处理器，避免重复
    for handler in logger.handlers[:]:
        with contextlib.suppress(Exception):
            handler.close()
        logger.removeHandler(handler)

    # 重新初始化日志器，使用临时目录
    _Logger._setup()

    yield temp_log_dir

    # 恢复原始值
    sys.modules["bitool.core.logger"]._DEFAULT_LOG_DIR = original_log_dir  # ty:ignore[unresolved-attribute]
    sys.modules["bitool.core.logger"]._DEFAULT_LOG_FILE = original_log_file  # ty:ignore[unresolved-attribute]

    # 清理临时日志处理器
    for handler in logger.handlers[:]:
        with contextlib.suppress(Exception):
            handler.close()
        logger.removeHandler(handler)

    # 恢复日志器状态
    _Logger._instance = original_instance
    _Logger._is_setup = original_is_setup


@pytest.fixture(scope="session", autouse=True)
def disable_atexit_for_tests() -> Generator[None, None, None]:
    """在测试会话期间禁用atexit, 避免测试配置写入用户目录.

    使用monkeypatch拦截atexit.register, 使所有atexit注册变为no-op.
    这是最优雅的解决方案, 无需修改业务代码.
    """

    def _no_op_register(*args: object, **kwargs: object) -> None:
        """替代的atexit.register, 不做任何事情."""
        pass

    # 使用MonkeyPatch.context()管理器, 自动处理替换和恢复
    with pytest.MonkeyPatch.context() as mp:
        mp.setattr(atexit, "register", _no_op_register)
        yield


@pytest.fixture(scope="session")
def temp_config_dir_session(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """创建会话级临时配置目录, 在所有测试间共享.

    适用于不需要隔离配置的只读测试场景.
    """
    return tmp_path_factory.mktemp("bitool_config")


@pytest.fixture(autouse=True)
def temp_config_dir(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> Generator[Path, None, None]:
    """创建临时配置目录, 避免 pytest-xdist 多线程写入冲突.

    每个测试工作进程使用独立的临时配置目录, 避免多个进程同时写入
    C:\\Users\\zhou\\.bitool\\filelevel.json 导致的权限错误.

    测试结束后自动清理临时目录, 确保不留任何测试文件.
    """
    from bitool.core import JsonConfig

    monkeypatch.setattr(JsonConfig, "ROOT_DIR", tmp_path)
    yield tmp_path
    # 测试结束后清理临时目录中的所有JSON文件
    import shutil

    if tmp_path.exists():
        shutil.rmtree(tmp_path, ignore_errors=True)
