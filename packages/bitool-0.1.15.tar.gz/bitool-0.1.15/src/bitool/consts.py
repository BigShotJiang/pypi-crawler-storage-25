"""Consts module for bitool."""

from __future__ import annotations

import platform
from dataclasses import dataclass
from typing import Final

_ARCH_DICT: Final[dict[str, str]] = {
    "x86_64": "amd64",
    "arm64": "arm64",
    "i386": "amd64",
    "i686": "amd64",
    "x86": "amd64",
    "aarch64": "arm64",
}


@dataclass(frozen=True)
class Constants:
    """常量类."""

    IS_WINDOWS = platform.system() == "Windows"
    IS_UNIX = platform.system() == "Linux" or platform.system() == "Darwin"
    IS_CYGWIN = platform.system() == "CYGWIN"
    IS_MINGW = platform.system() == "MINGW"
    IS_WSL = platform.system() == "Linux" and "microsoft" in platform.release().lower()
    IS_MSYS = platform.system() == "MSYS"

    EXTENSION = ".exe" if IS_WINDOWS else ""

    MACHINE = platform.machine().lower()
    ARCH = _ARCH_DICT.get(MACHINE, "amd64")
