"""Types module for bitool."""

from __future__ import annotations

from decimal import Decimal
from typing import Callable, TypeVar, Union

from typing_extensions import ParamSpec

ParamType = ParamSpec("ParamType")
ReturnType = TypeVar("ReturnType")
FunctionType = Callable[ParamType, ReturnType]
VariantType = Union[str, int, float, bool, list, dict, Decimal, complex, bytes, None]
