"""Bitool Web API 主入口."""

from __future__ import annotations

from pathlib import Path

from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi_offline import FastAPIOffline

from bitool.websvr.api.skills import router as skills_router
from bitool.websvr.api.todos import router as todos_router

FRONTEND_DIR = Path(__file__).parent.parent / "frontend" / "deploy"
API_DIR = Path(__file__).parent

app = FastAPIOffline(
    title="Bitool Web API",
    description="Bitool Web API",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health_check() -> dict:
    """健康检查端点."""
    return {"status": "healthy", "service": "Bitool Web API"}


@app.get("/skills", response_class=HTMLResponse)
async def skills_page() -> HTMLResponse:
    """技能工坊页面."""
    skills_html = API_DIR / "skills.html"
    if skills_html.exists():
        return HTMLResponse(content=skills_html.read_text(encoding="utf-8"))
    return HTMLResponse(content="<h1>skills.html not found</h1>", status_code=404)


app.include_router(todos_router)
app.include_router(skills_router)

if FRONTEND_DIR.exists():
    app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="static")
