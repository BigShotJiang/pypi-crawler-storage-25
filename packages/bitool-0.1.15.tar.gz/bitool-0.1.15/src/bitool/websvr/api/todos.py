"""FastAPI后端服务器 - 待办事项RESTful API."""

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

from fastapi import HTTPException, status
from fastapi.routing import APIRouter
from pydantic import BaseModel

router = APIRouter(
    prefix="/api/todos",
    tags=["todos"],
    responses={404: {"description": "待办事项不存在"}},
)

DATA_DIR = Path.home() / ".bitool" / "websvr"
DATA_DIR.mkdir(exist_ok=True)
SAMPLE_FILE = DATA_DIR / "todos.json"


class Todo(BaseModel):
    """待办事项模型."""

    id: int
    text: str
    completed: bool = False
    createdAt: str


class TodoCreate(BaseModel):
    """待办事项创建模型."""

    text: str


class TodoUpdate(BaseModel):
    """待办事项更新模型."""

    text: Optional[str] = None
    completed: Optional[bool] = None


class TodoList(BaseModel):
    """待办事项列表模型."""

    items: List[Todo]


class TodoStats(BaseModel):
    """待办事项统计模型."""

    total: int
    completed: int
    pending: int


def load_items() -> List[Todo]:
    """从文件加载待办事项."""
    if not SAMPLE_FILE.exists():
        return []

    try:
        with SAMPLE_FILE.open("r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                return [Todo(**item) for item in data]
            if isinstance(data, dict) and "items" in data:
                return [Todo(**item) for item in data["items"]]
            return []
    except (json.JSONDecodeError, KeyError, TypeError):
        return []


def save_items(items: List[Todo]) -> bool:
    """保存待办事项到文件."""
    try:
        SAMPLE_FILE.parent.mkdir(parents=True, exist_ok=True)
        data = [item.model_dump() for item in items]
        with SAMPLE_FILE.open("w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except OSError:
        return False
    return True


def get_next_id(items: List[Todo]) -> int:
    """获取下一个可用的ID."""
    if not items:
        return 1
    return max(item.id for item in items) + 1


@router.get("/", response_model=List[Todo])
def get_items() -> List[Todo]:
    """获取所有待办事项."""
    return load_items()


@router.post("/", response_model=Todo)
def create_item(item_data: TodoCreate) -> Todo:
    """创建新的待办事项."""
    items = load_items()

    new_item = Todo(
        id=get_next_id(items),
        text=item_data.text.strip(),
        completed=False,
        createdAt=datetime.now(tz=timezone.utc).isoformat(),
    )

    items.append(new_item)

    if save_items(items):
        return new_item
    raise HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail="保存待办事项失败",
    )


@router.get("/{item_id}", response_model=Todo)
def get_item(item_id: int) -> Todo:
    """获取指定ID的待办事项."""
    items = load_items()
    item = next((i for i in items if i.id == item_id), None)

    if not item:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"待办事项 {item_id} 不存在",
        )

    return item


@router.put("/{item_id}", response_model=Todo)
def update_item(item_id: int, item_update: TodoUpdate) -> Todo:
    """更新待办事项."""
    items = load_items()
    item = next((i for i in items if i.id == item_id), None)

    if not item:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"待办事项 {item_id} 不存在",
        )

    if item_update.text is not None:
        item.text = item_update.text.strip()
    if item_update.completed is not None:
        item.completed = item_update.completed

    if save_items(items):
        return item
    raise HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail="更新待办事项失败",
    )


@router.delete("/{item_id}")
def delete_item(item_id: int) -> dict:
    """删除待办事项."""
    items = load_items()
    original_length = len(items)

    items = [i for i in items if i.id != item_id]

    if len(items) == original_length:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"待办事项 {item_id} 不存在",
        )

    if save_items(items):
        return {"message": f"待办事项 {item_id} 已删除"}
    raise HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail="删除待办事项失败",
    )


@router.delete("/all")
def clear_all() -> dict:
    """清除所有待办事项."""
    if save_items([]):
        return {"message": "所有待办事项已清除"}
    raise HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail="清除所有待办事项失败",
    )


@router.get("/stats")
def get_stats() -> TodoStats:
    """获取待办事项统计信息."""
    items = load_items()
    total = len(items)
    completed = sum(1 for item in items if item.completed)

    return TodoStats(total=total, completed=completed, pending=total - completed)


@router.post("/import")
def import_items(item_list: TodoList) -> dict:
    """导入待办事项列表."""
    items = load_items()

    max_id = max([i.id for i in items], default=0)

    for imported_item in item_list.items:
        if imported_item.id <= max_id:
            max_id += 1
            imported_item.id = max_id

        existing = next((i for i in items if i.id == imported_item.id), None)
        if not existing:
            items.append(imported_item)

    if save_items(items):
        return {"message": f"成功导入 {len(item_list.items)} 个待办事项"}
    raise HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail="导入待办事项失败",
    )


@router.get("/export")
def export_items() -> dict:
    """导出所有待办事项."""
    items = load_items()
    return {"todos": [item.model_dump() for item in items]}
