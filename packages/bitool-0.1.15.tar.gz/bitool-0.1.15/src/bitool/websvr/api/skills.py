"""Bitool Skills RESTful API.

提供本地技能服务的HTTP接口,支持局域网访问.
"""

import contextlib
import shutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import HTTPException, UploadFile, status
from fastapi.responses import FileResponse
from fastapi.routing import APIRouter

try:
    import fitz

    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False

try:
    import pypdf

    HAS_PYPDF = True
except ImportError:
    HAS_PYPDF = False

router = APIRouter(prefix="/api/skills", tags=["skills"])

TEMP_DIR = Path.home() / ".bitool" / "websvr" / "temp"
TEMP_DIR.mkdir(parents=True, exist_ok=True)
MAX_FILE_SIZE = 100 * 1024 * 1024


@dataclass
class SkillResult:
    """技能执行结果."""

    success: bool
    message: str = ""
    data: Dict[str, Any] = field(default_factory=dict)
    output_file: Optional[Path] = None


def save_upload_file(upload_file: UploadFile) -> Path:
    """保存上传文件到临时目录."""
    temp_path = (
        TEMP_DIR
        / f"{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')}_{upload_file.filename}"
    )
    try:
        with temp_path.open("wb") as buffer:
            shutil.copyfileobj(upload_file.file, buffer)
    finally:
        upload_file.file.close()
    return temp_path


def save_upload_files(upload_files: List[UploadFile]) -> List[Path]:
    """批量保存上传文件."""
    return [save_upload_file(f) for f in upload_files]


def cleanup_temp_files(*paths: Path) -> None:
    """清理临时文件."""
    for path in paths:
        if path and path.exists():
            with contextlib.suppress(OSError):
                path.unlink()


@router.get("/list", response_model=SkillResult)
def list_skills() -> Dict[str, Any]:
    """获取所有可用技能列表."""
    skills = [
        {"name": "pdfmerge", "description": "合并多个PDF文件"},
        {"name": "pdfsplit", "description": "拆分PDF文件"},
        {"name": "pdfencrypt", "description": "PDF加密/解密"},
        {"name": "pdfcompress", "description": "压缩PDF文件"},
        {"name": "pdfrotate", "description": "旋转PDF页面"},
        {"name": "pdfextract", "description": "提取PDF页面"},
        {"name": "pdfinfo", "description": "获取PDF信息"},
        {"name": "pdf2img", "description": "PDF转图片"},
        {"name": "img2pdf", "description": "图片转PDF"},
        {"name": "pdfwatermark", "description": "PDF添加水印"},
        {"name": "pdfreorder", "description": "PDF页面重排序"},
        {"name": "pdfrepair", "description": "修复损坏的PDF"},
    ]
    return {"success": True, "message": "技能列表", "data": {"skills": skills}}


@router.post("/upload")
async def upload_file(file: UploadFile) -> Dict[str, Any]:
    """上传单个文件."""
    if not file.filename:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="文件名不能为空",
        )
    content = await file.read()
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"文件大小超过限制 ({MAX_FILE_SIZE // (1024 * 1024)}MB)",
        )
    file_path = save_upload_file(file)
    return {
        "success": True,
        "message": "文件上传成功",
        "data": {
            "filename": file.filename,
            "size": len(content),
            "content_type": file.content_type,
            "path": str(file_path),
        },
    }


@router.post("/upload/multiple")
async def upload_multiple_files(files: List[UploadFile]) -> Dict[str, Any]:
    """批量上传文件."""
    if not files:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="请至少上传一个文件",
        )
    results = []
    for file in files:
        if file.filename:
            file_path = save_upload_file(file)
            content = await file.read()
            results.append(
                {
                    "filename": file.filename,
                    "size": len(content),
                    "content_type": file.content_type,
                    "path": str(file_path),
                },
            )
    return {
        "success": True,
        "message": f"成功上传 {len(results)} 个文件",
        "data": {"files": results, "count": len(results)},
    }


@router.get("/download/{filename}")
def download_file(filename: str) -> FileResponse:
    """下载临时文件."""
    file_path = TEMP_DIR / filename
    if not file_path.exists():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="文件不存在")

    media_type = (
        "application/pdf"
        if filename.lower().endswith(".pdf")
        else "application/octet-stream"
    )

    return FileResponse(
        path=file_path,
        filename=filename,
        media_type=media_type,
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{filename}"},
    )


@router.post("/pdfmerge")
async def pdf_merge(files: List[UploadFile], sort: str = "name") -> Dict[str, Any]:
    """合并多个PDF文件.

    Parameters
    ----------
    files : List[UploadFile]
        要合并的PDF文件列表
    sort : str
        排序方式: name, date, size
    """
    if not HAS_PYMUPDF:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="PyMuPDF库未安装,请联系管理员",
        )

    if len(files) < 2:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="请至少上传2个PDF文件",
        )

    input_paths: list[Path] = [
        save_upload_file(f) for f in files if f.filename and f.filename.lower().endswith(".pdf")
    ]

    if len(input_paths) < 2:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="需要至少2个有效的PDF文件",
        )

    if sort == "name":
        input_paths = sorted(input_paths, key=lambda p: p.name.lower())
    elif sort == "date":
        input_paths = sorted(input_paths, key=lambda p: p.stat().st_mtime)
    elif sort == "size":
        input_paths = sorted(input_paths, key=lambda p: p.stat().st_size)

    output_path = TEMP_DIR / f"merged_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.pdf"

    try:
        writer = fitz.open()
        for pdf_path in input_paths:
            with fitz.open(pdf_path) as doc:
                writer.insert_pdf(doc)

        writer.save(str(output_path))
        writer.close()

        for path in input_paths:
            cleanup_temp_files(path)

        return {
            "success": True,
            "message": f"成功合并 {len(input_paths)} 个PDF文件",
            "data": {
                "output_file": output_path.name,
                "page_count": len(writer) if "writer" in dir() else 0,
            },
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"合并失败: {e!s}",
        ) from e


@router.post("/pdfsplit")
async def pdf_split(
    file: UploadFile,
    pages_per_file: int = 1,
    output_format: str = "prefix",
) -> Dict[str, Any]:
    """拆分PDF文件.

    Parameters
    ----------
    file : UploadFile
        要拆分的PDF文件
    pages_per_file : int
        每个输出文件的页数
    output_format : str
        输出格式: prefix, suffix, range
    """
    if not HAS_PYMUPDF:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="PyMuPDF库未安装,请联系管理员",
        )

    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="请上传有效的PDF文件",
        )

    input_path = save_upload_file(file)

    try:
        doc = fitz.open(str(input_path))
        total_pages = doc.page_count

        if pages_per_file <= 0:
            pages_per_file = 1

        output_files = []
        part_num = 1

        for i in range(0, total_pages, pages_per_file):
            end_page = min(i + pages_per_file, total_pages)
            output_path = (
                TEMP_DIR
                / f"split_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}_part{part_num:03d}.pdf"
            )

            writer = fitz.open()
            for page_num in range(i, end_page):
                writer.insert_pdf(doc, from_page=page_num, to_page=page_num)

            writer.save(str(output_path))
            writer.close()

            output_files.append(output_path.name)
            part_num += 1

        doc.close()
        cleanup_temp_files(input_path)

        return {
            "success": True,
            "message": f"成功拆分为 {len(output_files)} 个文件",
            "data": {
                "output_files": output_files,
                "total_pages": total_pages,
                "pages_per_file": pages_per_file,
            },
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"拆分失败: {e!s}",
        ) from e


@router.post("/pdfencrypt")
async def pdf_encrypt(
    file: UploadFile,
    password: str,
    action: str = "encrypt",
) -> Dict[str, Any]:
    """PDF加密/解密.

    Parameters
    ----------
    file : UploadFile
        要处理的PDF文件
    password : str
        密码
    action : str
        操作类型: encrypt, decrypt
    """
    if not HAS_PYPDF:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="pypdf库未安装,请联系管理员",
        )

    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="请上传有效的PDF文件",
        )

    input_path = save_upload_file(file)

    try:
        reader = pypdf.PdfReader(str(input_path))
        writer = pypdf.PdfWriter()

        for page in reader.pages:
            writer.add_page(page)

        if action == "encrypt":
            writer.encrypt(
                user_password=password,
                owner_password=password,
                use_128bit=True,
            )
        else:
            if reader.is_encrypted:
                reader.decrypt(password)

        output_path = (
            TEMP_DIR / f"{action}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.pdf"
        )
        writer.write(str(output_path))

        cleanup_temp_files(input_path)

        return {
            "success": True,
            "message": f"PDF{action}成功",
            "data": {
                "output_file": output_path.name,
                "action": action,
                "page_count": len(reader.pages),
            },
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"{action}失败: {e!s}",
        ) from e


@router.post("/pdfrotate")
async def pdf_rotate(
    file: UploadFile,
    angle: int = 90,
    pages: str = "",
) -> Dict[str, Any]:
    """旋转PDF页面.

    Parameters
    ----------
    file : UploadFile
        要旋转的PDF文件
    angle : int
        旋转角度: 90, 180, 270
    pages : str
        要旋转的页面,空表示全部,如: "1,3-5,7"
    """
    if not HAS_PYMUPDF:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="PyMuPDF库未安装,请联系管理员",
        )

    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="请上传有效的PDF文件",
        )

    if angle not in (90, 180, 270):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="旋转角度必须是90, 180或270",
        )

    input_path = save_upload_file(file)

    try:
        doc = fitz.open(str(input_path))
        total_pages = doc.page_count

        if pages:
            page_list = []
            for part in pages.split(","):
                part = part.strip()
                if "-" in part:
                    start_end = part.split("-")
                    start = int(start_end[0]) if start_end[0] else 1
                    end = int(start_end[1]) if start_end[1] else total_pages
                    start = max(1, min(start, total_pages))
                    end = max(1, min(end, total_pages))
                    page_list.extend(range(start - 1, end))
                else:
                    page_num = int(part)
                    if 1 <= page_num <= total_pages:
                        page_list.append(page_num - 1)
            page_list = sorted(set(page_list))
        else:
            page_list = list(range(total_pages))

        for page_num in page_list:
            page = doc[page_num]
            page.set_rotation((page.rotation + angle) % 360)

        output_path = (
            TEMP_DIR / f"rotated_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.pdf"
        )
        doc.save(str(output_path))
        doc.close()

        cleanup_temp_files(input_path)

        return {
            "success": True,
            "message": f"成功旋转 {len(page_list)} 个页面",
            "data": {
                "output_file": output_path.name,
                "rotated_pages": [p + 1 for p in page_list],
                "angle": angle,
            },
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"旋转失败: {e!s}",
        ) from e


@router.post("/pdfextract")
async def pdf_extract(
    file: UploadFile,
    pages: str,
    output_format: str = "single",
) -> Dict[str, Any]:
    """提取PDF页面.

    Parameters
    ----------
    file : UploadFile
        要提取页面的PDF文件
    pages : str
        要提取的页面,如: "1,3-5,7"
    output_format : str
        输出格式: single(单个文件), multiple(多个文件)
    """
    if not HAS_PYMUPDF:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="PyMuPDF库未安装,请联系管理员",
        )

    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="请上传有效的PDF文件",
        )

    if not pages:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="请指定要提取的页面",
        )

    input_path = save_upload_file(file)

    try:
        doc = fitz.open(str(input_path))
        total_pages = doc.page_count

        page_list = []
        for part in pages.split(","):
            part = part.strip()
            if "-" in part:
                start_end = part.split("-")
                start = int(start_end[0]) if start_end[0] else 1
                end = int(start_end[1]) if start_end[1] else total_pages
                start = max(1, min(start, total_pages))
                end = max(1, min(end, total_pages))
                page_list.extend(range(start - 1, end))
            else:
                page_num = int(part)
                if 1 <= page_num <= total_pages:
                    page_list.append(page_num - 1)

        page_list = sorted(set(page_list))

        if not page_list:
            raise HTTPException(  # noqa: TRY301
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="未找到有效的页面",
            )

        output_files = []

        if output_format == "multiple":
            for idx, page_num in enumerate(page_list, 1):
                writer = fitz.open()
                writer.insert_pdf(doc, from_page=page_num, to_page=page_num)
                output_path = (
                    TEMP_DIR
                    / f"extracted_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}_p{idx:03d}.pdf"
                )
                writer.save(str(output_path))
                writer.close()
                output_files.append(output_path.name)
        else:
            writer = fitz.open()
            for page_num in page_list:
                writer.insert_pdf(doc, from_page=page_num, to_page=page_num)
            output_path = (
                TEMP_DIR / f"extracted_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.pdf"
            )
            writer.save(str(output_path))
            writer.close()
            output_files.append(output_path.name)

        doc.close()
        cleanup_temp_files(input_path)

        return {
            "success": True,
            "message": f"成功提取 {len(page_list)} 个页面",
            "data": {
                "output_files": output_files,
                "extracted_pages": [p + 1 for p in page_list],
            },
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"提取失败: {e!s}",
        ) from e


@router.post("/pdfinfo")
async def pdf_info(file: UploadFile) -> Dict[str, Any]:
    """获取PDF信息.

    Parameters
    ----------
    file : UploadFile
        PDF文件
    """
    if not HAS_PYMUPDF:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="PyMuPDF库未安装,请联系管理员",
        )

    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="请上传有效的PDF文件",
        )

    input_path = save_upload_file(file)

    try:
        doc = fitz.open(str(input_path))
        info = {
            "title": doc.metadata.get("title", ""),
            "author": doc.metadata.get("author", ""),
            "subject": doc.metadata.get("subject", ""),
            "keywords": doc.metadata.get("keywords", ""),
            "creator": doc.metadata.get("creator", ""),
            "producer": doc.metadata.get("producer", ""),
        }

        page_info = []
        for i, page in enumerate(doc):
            page_info.append(
                {
                    "number": i + 1,
                    "width": round(page.rect.width, 2),
                    "height": round(page.rect.height, 2),
                },
            )

        result = {
            "success": True,
            "message": "获取PDF信息成功",
            "data": {
                "filename": file.filename,
                "page_count": doc.page_count,
                "metadata": info,
                "pages": page_info,
            },
        }

        doc.close()
        cleanup_temp_files(input_path)

        return result  # noqa: TRY300
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"获取信息失败: {e!s}",
        ) from e


@router.post("/pdf2img")
async def pdf_to_images(
    file: UploadFile,
    output_format: str = "png",
    dpi: int = 150,
    pages: str = "",
) -> Dict[str, Any]:
    """将PDF转换为图片.

    Parameters
    ----------
    file : UploadFile
        PDF文件
    format : str
        输出格式: png, jpg
    dpi : int
        图片分辨率
    pages : str
        要转换的页面,空表示全部,如: "1,3-5"
    """
    if not HAS_PYMUPDF:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="PyMuPDF库未安装,请联系管理员",
        )

    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="请上传有效的PDF文件",
        )

    if output_format not in ("png", "jpg", "jpeg"):
        output_format = "png"

    input_path = save_upload_file(file)

    try:
        doc = fitz.open(str(input_path))
        total_pages = doc.page_count

        if pages:
            page_list = []
            for part in pages.split(","):
                part = part.strip()
                if "-" in part:
                    start_end = part.split("-")
                    start = int(start_end[0]) if start_end[0] else 1
                    end = int(start_end[1]) if start_end[1] else total_pages
                    start = max(1, min(start, total_pages))
                    end = max(1, min(end, total_pages))
                    page_list.extend(range(start - 1, end))
                else:
                    page_num = int(part)
                    if 1 <= page_num <= total_pages:
                        page_list.append(page_num - 1)
            page_list = sorted(set(page_list))
        else:
            page_list = list(range(total_pages))

        output_files = []
        zoom = dpi / 72
        mat = fitz.Matrix(zoom, zoom)

        for idx, page_num in enumerate(page_list, 1):
            page = doc[page_num]
            pix = page.get_pixmap(matrix=mat)
            output_path = (
                TEMP_DIR
                / f"page_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}_{idx:03d}.{output_format}"
            )
            pix.save(str(output_path))
            output_files.append(output_path.name)

        doc.close()
        cleanup_temp_files(input_path)

        return {
            "success": True,
            "message": f"成功转换 {len(output_files)} 个页面为图片",
            "data": {
                "output_files": output_files,
                "format": output_format,
                "dpi": dpi,
                "converted_pages": [p + 1 for p in page_list],
            },
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"转换失败: {e!s}",
        ) from e


@router.post("/img2pdf")
async def images_to_pdf(
    files: List[UploadFile],
    page_size: str = "auto",
    orientation: str = "auto",
) -> Dict[str, Any]:
    """将图片转换为PDF.

    Parameters
    ----------
    files : list[UploadFile]
        图片文件列表
    page_size : str
        页面大小: auto, A4, letter, legal
    orientation : str
        页面方向: auto, portrait, landscape
    """
    if not HAS_PYMUPDF:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="PyMuPDF库未安装,请联系管理员",
        )

    valid_formats = {".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tiff", ".tif"}
    input_paths = []

    for f in files:
        if f.filename:
            ext = Path(f.filename).suffix.lower()
            if ext in valid_formats:
                input_paths.append(save_upload_file(f))

    if not input_paths:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"请上传有效的图片文件,支持格式: {', '.join(valid_formats)}",
        )

    try:
        writer = fitz.open()

        for img_path in input_paths:
            img = fitz.Pixmap(img_path)

            if img.xres > 0 and img.yres > 0:
                width_pt = img.width * 72 / img.xres
                height_pt = img.height * 72 / img.yres
            else:
                width_pt = img.width * 72 / 150
                height_pt = img.height * 72 / 150

            if page_size == "A4":
                width_pt, height_pt = 595.28, 841.89
            elif page_size == "letter":
                width_pt, height_pt = 612, 792
            elif page_size == "legal":
                width_pt, height_pt = 612, 1008

            if orientation == "landscape" or (
                orientation == "auto" and width_pt > height_pt
            ):
                width_pt, height_pt = height_pt, width_pt

            rect = fitz.Rect(0, 0, width_pt, height_pt)
            page = writer.new_page(width=width_pt, height=height_pt)
            page.insert_image(rect, filename=str(img_path))

        output_path = (
            TEMP_DIR / f"converted_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.pdf"
        )
        writer.save(str(output_path))
        writer.close()

        for path in input_paths:
            cleanup_temp_files(path)

        return {
            "success": True,
            "message": f"成功将 {len(input_paths)} 张图片转换为PDF",
            "data": {
                "output_file": output_path.name,
                "page_count": len(writer) if "writer" in dir() else len(input_paths),
                "page_size": page_size,
            },
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"转换失败: {e!s}",
        ) from e


@router.post("/pdfwatermark")
async def pdf_watermark(
    file: UploadFile,
    text: str = "",
    image: Optional[UploadFile] = None,
    opacity: float = 0.3,
    font_size: int = 48,
    position: str = "center",
) -> Dict[str, Any]:
    """为PDF添加水印.

    Parameters
    ----------
    file : UploadFile
        PDF文件
    text : str
        水印文字(与image二选一)
    image : UploadFile
        水印图片
    opacity : float
        透明度 0-1
    font_size : int
        字体大小
    position : str
        位置: center, diagonal
    """
    if not HAS_PYMUPDF:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="PyMuPDF库未安装,请联系管理员",
        )

    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="请上传有效的PDF文件",
        )

    if not text and not image:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="请提供水印文字或水印图片",
        )

    input_path = save_upload_file(file)
    image_path = None

    if image and image.filename:
        image_path = save_upload_file(image)

    try:
        doc = fitz.open(str(input_path))

        for page in doc:
            width = page.rect.width
            height = page.rect.height

            if text:
                if position == "diagonal":
                    text_point = fitz.Point(width / 4, height / 2)
                    page.insert_text(
                        text_point,
                        text,
                        fontsize=font_size,
                        color=(0.8, 0.8, 0.8),
                        render_mode=0,
                    )
                else:
                    text_rect = fitz.Rect(
                        0,
                        height / 2 - font_size,
                        width,
                        height / 2 + font_size,
                    )
                    page.insert_textbox(
                        text_rect,
                        text,
                        fontsize=font_size,
                        color=(0.8, 0.8, 0.8),
                        align=1,
                    )

            if image_path and image_path.exists():
                img_rect = fitz.Rect(
                    width * 0.2,
                    height * 0.2,
                    width * 0.8,
                    height * 0.8,
                )
                page.insert_image(img_rect, filename=str(image_path), opacity=opacity)

        output_path = (
            TEMP_DIR / f"watermarked_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.pdf"
        )
        doc.save(str(output_path))
        doc.close()

        cleanup_temp_files(input_path)
        if image_path:
            cleanup_temp_files(image_path)

        return {
            "success": True,
            "message": "成功添加水印",
            "data": {
                "output_file": output_path.name,
                "page_count": len(doc) if "doc" in dir() else 0,
            },
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"添加水印失败: {e!s}",
        ) from e


@router.post("/pdfcompress")
async def pdf_compress(file: UploadFile, quality: str = "medium") -> Dict[str, Any]:
    """压缩PDF文件.

    Parameters
    ----------
    file : UploadFile
        PDF文件
    quality : str
        压缩质量: low, medium, high
    """
    if not HAS_PYMUPDF:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="PyMuPDF库未安装,请联系管理员",
        )

    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="请上传有效的PDF文件",
        )

    input_path = save_upload_file(file)
    original_size = input_path.stat().st_size

    try:
        doc = fitz.open(str(input_path))

        if quality == "low" or quality == "high":
            pass
        else:
            pass

        output_path = (
            TEMP_DIR / f"compressed_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.pdf"
        )
        doc.save(str(output_path), garbage=4, deflate=True, clean=True)
        doc.close()

        compressed_size = output_path.stat().st_size
        ratio = (1 - compressed_size / original_size) * 100 if original_size > 0 else 0

        cleanup_temp_files(input_path)

        return {  # noqa: TRY300
            "success": True,
            "message": f"压缩完成,减少 {ratio:.1f}%",
            "output_file": output_path.name,
            "data": {
                "original_size": original_size,
                "compressed_size": compressed_size,
                "compression_ratio": f"{ratio:.1f}%",
            },
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"压缩失败: {e!s}",
        ) from e
