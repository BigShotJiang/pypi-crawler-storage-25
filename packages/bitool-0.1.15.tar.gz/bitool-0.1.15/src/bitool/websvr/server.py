"""Web 服务器实现模块."""

from __future__ import annotations

import abc
import http.server
import os
import platform
import shutil
import socket
import socketserver
import subprocess
import sys
import threading
import time
from pathlib import Path

import webview

from bitool.core import logger

from .config import ServerConfig


def check_command_available(cmd: str) -> bool:
    """检查命令是否可用."""
    from bitool.cmd import execute

    try:
        if platform.system() == "Windows":
            result = execute(
                ["where", cmd],
                capture_output=True,
                text=True,
            )
        else:
            result = execute(
                ["which", cmd],
                capture_output=True,
                text=True,
            )
        return result.returncode == 0  # noqa: TRY300
    except Exception:  # noqa: BLE001
        return False


def check_port_available(host: str, port: int) -> bool:
    """检查端口是否可用."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(1)
            result = sock.connect_ex((host, port))
            return result != 0
    except OSError:
        return False


def check_proc_by_name(name: str) -> bool:
    """检查进程是否存在."""
    from bitool.cmd import execute

    try:
        if platform.system() == "Windows":
            result = execute(
                ["tasklist"],
                capture_output=True,
                text=True,
            )
            return name.lower() in result.stdout.lower()
        else:
            result = execute(
                ["pgrep", "-x", name],
                capture_output=True,
                text=True,
            )
            return result.returncode == 0
    except Exception:  # noqa: BLE001
        return False


def kill_proc_by_port(port: int) -> None:
    """根据端口终止进程."""
    from bitool.cmd import execute

    try:
        if platform.system() == "Windows":
            result = execute(
                ["netstat", "-ano"],
                capture_output=True,
                text=True,
            )
            for line in result.stdout.split("\n"):
                if f":{port}" in line and "LISTENING" in line:
                    parts = line.split()
                    if parts:
                        pid = parts[-1]
                        execute(["taskkill", "/F", "/PID", pid])
        else:
            result = execute(
                ["lsof", "-ti", f":{port}"],
                capture_output=True,
                text=True,
            )
            if result.stdout.strip():
                pids = result.stdout.strip().split("\n")
                for pid in pids:
                    execute(["kill", "-9", pid])
    except Exception:  # noqa: BLE001, S110
        pass


class BaseServer(abc.ABC):
    """Web 服务器基类."""

    def __init__(self, config: ServerConfig | None = None) -> None:
        """初始化服务器.

        Args:
            config: 服务器配置，如果为 None 则使用默认配置
        """
        self.config = config or ServerConfig()
        self.server_proc: subprocess.Popen | None = None

    @property
    def cmd_suffix(self) -> str:
        """命令后缀."""
        if platform.system() == "Windows":
            return ".cmd"
        return ""

    @abc.abstractmethod
    def start(self, **kwargs: object) -> None:
        """启动服务器."""

    def stop(self) -> None:
        """停止服务器."""
        from bitool.cmd import execute

        if self.server_proc is None or self.server_proc.poll() is not None:
            logger.info("无需停止服务器, 因为服务器未启动")
            return

        logger.info("正在停止服务器...")
        try:
            if platform.system() == "Windows":
                execute(
                    ["taskkill", "/F", "/T", "/PID", str(self.server_proc.pid)],
                )
            else:
                self.server_proc.terminate()

            try:
                self.server_proc.wait(timeout=10)
                logger.info("服务器已正常关闭")
            except subprocess.TimeoutExpired:
                logger.warning("服务器未能正常关闭, 尝试强制终止")
                if platform.system() != "Windows":
                    self.server_proc.kill()
                self.server_proc.wait()
                logger.info("服务器已强制关闭")
        except ProcessLookupError:
            logger.warning("无法停止服务器, 因为服务器已不存在")
        except Exception as e:  # noqa: BLE001
            logger.error(f"停止服务器时出错: {e!s}")

    def find_package_manager(self) -> str | None:
        """查找可用的包管理器."""
        for cmd in self.config.package_managers:
            if check_command_available(f"{cmd}{self.cmd_suffix}"):
                return f"{cmd}{self.cmd_suffix}"
        return None

    def install_dependencies(self) -> None:
        """安装依赖."""
        from bitool.cmd import execute

        cmd = self.find_package_manager()
        if not cmd:
            logger.error("未找到包管理器")
            return

        original_dir = Path.cwd()
        try:
            os.chdir(str(self.config.frontend_dir))
            execute([cmd, "install"], check=True)
        finally:
            os.chdir(original_dir)

    def build(self) -> None:
        """构建前端."""
        from bitool.cmd import execute

        command = self.find_package_manager()
        if not command:
            logger.error("未找到构建命令")
            return

        original_dir = Path.cwd()
        try:
            os.chdir(str(self.config.frontend_dir))
            build_proc = execute([command, "run", "build"])
            if build_proc.returncode != 0:
                logger.error("构建失败, 请检查代码是否有错误")
        finally:
            os.chdir(original_dir)

    def clean(self) -> None:
        """清理构建文件."""
        if not self.config.dist_dir.exists():
            logger.info("构建文件不存在, 无需清理")
            return

        try:
            shutil.rmtree(self.config.dist_dir)
        except OSError as e:
            logger.error(f"清理构建文件时出错: {e!s}")
        else:
            logger.info("清理构建文件成功")

    def lint(self) -> None:
        """检查代码."""
        from bitool.cmd import execute

        command = self.find_package_manager()
        if not command:
            logger.error("未找到包管理器")
            return

        original_dir = Path.cwd()
        logger.info("正在检查代码...")
        try:
            os.chdir(str(self.config.frontend_dir))
            execute([command, "run", "lint"], check=True)
        except Exception as e:  # noqa: BLE001
            logger.error(f"检查代码时出错: {e!s}")
        else:
            logger.info("检查代码成功")
        finally:
            os.chdir(original_dir)


class ApiServer(BaseServer):
    """API 服务器."""

    def __init__(self, config: ServerConfig | None = None) -> None:
        super().__init__(config)
        self._api_dir = self.config.api_dir

    def start(self, port: int | None = None, host: str | None = None) -> None:
        """启动 API 服务器.

        Args:
            port: API 服务器端口，默认使用配置中的端口
            host: API 服务器主机，默认使用配置中的主机
        """
        port = port or self.config.api_port
        host = host or self.config.host

        if not self._api_dir.exists():
            logger.error(f"API 目录不存在: {self._api_dir}")
            return

        if not check_port_available(host, port):
            logger.warning(f"端口 {port} 已被占用, 尝试终止占用进程")
            kill_proc_by_port(port)

        def start_server() -> None:
            from bitool.cmd import execute

            original_dir = Path.cwd()
            os.chdir(self._api_dir)
            try:
                cmd = [
                    sys.executable,
                    "-m",
                    "uvicorn",
                    "main:app",
                    "--host",
                    host,
                    "--port",
                    str(port),
                    "--reload",
                ]
                execute(cmd, check=True)
            except Exception as e:  # noqa: BLE001
                logger.error(f"启动 API 服务器时出错: {e!s}")
                sys.exit(1)
            finally:
                os.chdir(original_dir)

        logger.info(f"正在启动 API 服务器, 端口: {port}...")
        api_thread = threading.Thread(target=start_server, daemon=True)
        api_thread.start()


class NativeServer(BaseServer):
    """本地模式, 静态服务器 (带 WebView)."""

    def start(
        self,
        title: str | None = None,
        *,
        port: int | None = None,
        debug: bool = False,
    ) -> None:
        """启动本地 WebView 服务器.

        Args:
            title: WebView 窗口标题，默认使用配置中的标题
            port: WebView 服务器端口，默认使用配置中的端口
            debug: 是否启用调试模式
        """
        title = title or self.config.webview_title
        port = port or self.config.webview_port

        if not self.config.dist_dir.exists() or not self.config.index_html.exists():
            if self.config.auto_build:
                logger.info("未找到生产环境文件, 正在构建...")
                self.build()
            else:
                logger.error("未找到生产环境文件，请先运行 build")
                return

        logger.info("正在启动生产服务器...")
        try:

            class FrontendRouterHandler(http.server.SimpleHTTPRequestHandler):
                DIST_DIR = (
                    BaseServer.DIST_DIR.fget(self)
                    if isinstance(self.config.dist_dir, property)
                    else self.config.dist_dir
                )

                API_PORT = 8001

                def __init__(self, *args: object, **kwargs: object) -> None:
                    super().__init__(*args, directory=str(self.DIST_DIR), **kwargs)

                def do_GET(self) -> None:
                    """处理 GET 请求."""
                    path = self.path.split("?")[0].split("#")[0]

                    if (
                        path.startswith("/api/")
                        or path.startswith("/health")
                        or path == "/skills"
                    ):
                        self._proxy_to_api("GET", path)
                    elif path in {"/", ""}:
                        self.path = "/"
                        super().do_GET()
                    else:
                        requested_file = Path(self.DIST_DIR) / Path(path.lstrip("/"))
                        if not requested_file.exists():
                            self.path = "/"
                            super().do_GET()
                        else:
                            super().do_GET()

                def do_POST(self) -> None:
                    """代理 POST 请求到 API 服务器."""
                    self._proxy_to_api("POST", self.path)

                def _proxy_to_api(self, method: str, path: str) -> None:
                    """将请求代理到 API 服务器."""
                    try:
                        import http.client

                        conn = http.client.HTTPConnection(
                            "127.0.0.1",
                            self.API_PORT,
                            timeout=30,
                        )

                        content_length = int(self.headers.get("Content-Length", 0))
                        body = (
                            self.rfile.read(content_length)
                            if content_length > 0
                            else None
                        )

                        conn.request(
                            method=method,
                            url=path,
                            body=body,
                            headers=self.headers,
                        )
                        response = conn.getresponse()
                        self.send_response(response.status)
                        for header, value in response.getheaders():
                            if header.lower() not in (
                                "transfer-encoding",
                                "connection",
                            ):
                                self.send_header(header, value)
                        self.end_headers()
                        self.wfile.write(response.read())
                        conn.close()
                    except Exception:  # noqa: BLE001
                        self.send_response(502)
                        self.send_header("Content-Type", "text/plain")
                        self.end_headers()
                        self.wfile.write(b"API Server not available")

                def log_message(self, format_str: str, *args: object) -> None:
                    """禁用日志输出."""
                    pass

            if not check_port_available("127.0.0.1", port):
                logger.warning(f"端口 {port} 已被占用, 尝试使用端口: {port + 1}")
                return self.start(title, port=port + 1, debug=debug)

            logger.info(f"启动内部HTTP服务器, 端口: {port}")
            with socketserver.TCPServer(("", port), FrontendRouterHandler) as httpd:
                server_thread = threading.Thread(
                    target=httpd.serve_forever,
                    daemon=True,
                )
                server_thread.start()

                time.sleep(0.5)

                try:
                    webview.create_window(
                        title=title,
                        url=f"http://127.0.0.1:{port}",
                        width=self.config.webview_width,
                        height=self.config.webview_height,
                        resizable=True,
                        min_size=(
                            self.config.webview_min_width,
                            self.config.webview_min_height,
                        ),
                        x=None,
                        y=None,
                    )
                    webview.start(debug=debug)
                finally:
                    httpd.shutdown()
                    httpd.server_close()
                    logger.info("内部HTTP服务器已关闭")
        except (RuntimeError, OSError, ImportError) as e:
            logger.error(f"启动 WebView 窗口时出错: {e!s}")
        finally:
            self.stop()


class ServeServer(BaseServer):
    """本地开发/预览服务器."""

    def start(
        self,
        port: int | None = None,
        host: str | None = None,
        *,
        dev: bool = False,
    ) -> None:
        """启动开发或预览服务器.

        Args:
            port: 服务器端口，默认使用配置中的前端端口
            host: 服务器主机，默认使用配置中的主机
            dev: 是否为开发模式
        """
        port = port or self.config.frontend_port
        host = host or self.config.host

        if not self.config.frontend_dir.exists():
            logger.error("未找到前端目录")
            return

        if not check_port_available(host, port):
            logger.warning(f"端口 {port} 已被占用, 尝试使用端口: {port + 1}")
            return self.start(port=port + 1, host=host, dev=dev)

        vite_cmd = f"vite{self.cmd_suffix}"
        if check_command_available(vite_cmd):
            original_dir = Path.cwd()
            try:
                os.chdir(str(self.config.frontend_dir))
                if dev:
                    self.server_proc = subprocess.Popen(  # noqa: S603
                        [vite_cmd, "--port", str(port), "--host", host],
                        cwd=str(self.config.frontend_dir),
                        stdout=None,
                        stderr=None,
                        text=True,
                    )
                    logger.info(
                        f"Vite 开发服务器已启动, 访问地址: http://{host}:{port}",
                    )
                else:
                    if (
                        not self.config.dist_dir.exists()
                        or not self.config.index_html.exists()
                    ):
                        if self.config.auto_build:
                            logger.info("未找到生产环境文件, 正在构建...")
                            self.build()
                        else:
                            logger.error("未找到生产环境文件，请先运行 build")
                            return

                    self.server_proc = subprocess.Popen(  # noqa: S603
                        [
                            vite_cmd,
                            "preview",
                            "--port",
                            str(port),
                            "--host",
                            host,
                            "--base",
                            "/",
                        ],
                        cwd=str(self.config.frontend_dir),
                        stdout=None,
                        stderr=None,
                        text=True,
                    )
                    logger.info(
                        f"Vite 预览服务器已启动, 访问地址: http://{host}:{port}",
                    )
            except (subprocess.CalledProcessError, OSError) as e:
                logger.error(f"启动 Vite 服务器失败: {e!s}")
                return
            finally:
                os.chdir(original_dir)
        else:
            logger.error("未找到 Vite 命令, 请检查是否已安装")

    @property
    def nginx_conf_dir(self) -> Path:
        """Nginx 配置目录."""
        return self.config.nginx_conf_dir


def _get_nginx_conf(port: int, host: str, dist_dir: str, working_dir: str) -> str:
    """生成 Nginx 配置文件内容."""
    logs_dir = f"{working_dir}/logs"
    tmp_dir = f"{working_dir}/tmp"  # noqa: S108

    return f"""
error_log {logs_dir}/error.log;
pid {tmp_dir}/nginx.pid;

events {{
    worker_connections 1024;
}}

http {{
    include       mime.types;
    default_type  application/octet-stream;

    server {{
        listen       {port};
        server_name  {host};

        access_log {logs_dir}/access.log;

        location /api/ {{
            proxy_pass http://127.0.0.1:8001/;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }}

        location /health {{
            proxy_pass http://127.0.0.1:8001/health;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }}

        location /static/ {{
            alias {dist_dir}/static/;
            expires 1y;
            add_header Cache-Control "public, immutable";
        }}

        location / {{
            root   {dist_dir};
            index  index.html index.htm;
            try_files $uri $uri/ /index.html;
        }}
    }}
}}
    """


class NginxServeServer(ServeServer):
    """使用 Nginx 启动静态文件服务器."""

    def start(self, port: int | None = None, host: str | None = None) -> None:
        """启动 Nginx 静态文件服务器.

        Args:
            port: 服务器端口，默认使用配置中的前端端口
            host: 服务器主机，默认使用配置中的主机
        """
        port = port or self.config.frontend_port
        host = host or self.config.host

        if not self.config.frontend_dir.exists():
            logger.error("未找到前端目录")
            return

        if not self.nginx_conf_dir.exists():
            logger.error(f"未找到 nginx 配置目录: {self.nginx_conf_dir}")
            return

        if not self.config.dist_dir.exists() or not self.config.index_html.exists():
            if self.config.auto_build:
                logger.info("未找到生产环境文件, 正在构建...")
                self.build()
            else:
                logger.error("未找到生产环境文件，请先运行 build")
                return

        if check_proc_by_name("nginx"):
            logger.info("已找到 Nginx 进程, 先停止 Nginx")
            self.stop()

        logger.info("正在启动 Nginx 服务器...")
        nginx_cmd = "nginx"
        if check_command_available(nginx_cmd):
            original_dir = Path.cwd()
            try:
                os.chdir(str(self.config.frontend_dir))

                for directory in ["logs", "tmp", "temp"]:
                    (self.nginx_conf_dir / directory).mkdir(exist_ok=True)

                self.write_nginx_conf(port=port, host=host)

                self.server_proc = subprocess.Popen(  # noqa: S603
                    [nginx_cmd, "-c", "nginx.conf"],
                    cwd=str(self.nginx_conf_dir),
                    stdout=None,
                    stderr=None,
                    text=True,
                )
                logger.info(f"Nginx 服务器已启动, 访问地址: http://{host}:{port}")
            except (subprocess.CalledProcessError, OSError) as e:
                logger.error(f"启动 Nginx 服务器失败: {e!s}")
                return
            finally:
                os.chdir(original_dir)
        else:
            logger.error("未找到 Nginx 命令, 请检查是否已安装")

    def write_nginx_conf(self, port: int, host: str) -> None:
        """写入 Nginx 配置文件."""
        conf_path = self.nginx_conf_dir / "nginx.conf"

        logger.info("正在写入 Nginx 配置文件...")
        conf = _get_nginx_conf(
            port=port,
            host=host,
            dist_dir=str(self.config.dist_dir),
            working_dir=self.nginx_conf_dir.as_posix(),
        )
        conf_path.write_text(conf)
        logger.info("Nginx 配置文件已写入: " + str(conf_path))

    def stop(self) -> None:
        """停止 Nginx 服务器."""
        logger.info("正在尝试停止 Nginx 服务器...")
        try:
            pid_file = self.nginx_conf_dir / "tmp" / "nginx.pid"
            if pid_file.exists():
                with Path(pid_file).open("r", encoding="utf-8") as f:
                    int(f.read().strip())

                self.server_proc = subprocess.Popen(  # noqa: S603
                    [
                        shutil.which("nginx") or "nginx",
                        "-s",
                        "stop",
                        "-c",
                        str(self.nginx_conf_dir / "nginx.conf"),
                    ],
                    cwd=str(self.nginx_conf_dir),
                    stdout=None,
                    stderr=None,
                    text=True,
                )

                try:
                    for _ in range(10):
                        if self.server_proc.poll() is not None:
                            break
                        time.sleep(1)

                    if self.server_proc.poll() is not None:
                        logger.info("Nginx 服务器已正常关闭")
                    else:
                        logger.warning("Nginx 服务器未能正常关闭, 尝试强制终止")
                        self.server_proc.terminate()
                        self.server_proc.wait()
                        logger.info("Nginx 服务器已强制关闭")
                except Exception as e:  # noqa: BLE001
                    logger.error(f"等待 Nginx 服务器关闭时出错: {e!s}")
            else:
                logger.warning("Nginx 服务器未运行")
                return
        except (OSError, subprocess.SubprocessError) as e:
            logger.error(f"停止 Nginx 服务器时出错: {e!s}")
