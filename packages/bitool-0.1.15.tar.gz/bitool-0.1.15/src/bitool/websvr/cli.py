"""Command-line interface for websvr."""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from bitool.core import logger
from bitool.websvr.server import ApiServer, NativeServer, NginxServeServer, ServeServer


def main() -> int:
    """主函数入口."""
    parser = argparse.ArgumentParser(
        description="Bitool Web Service - Web服务器管理工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  websvr build              # 构建前端
  websvr dev                # 开发模式
  websvr serve              # 仅启动Web服务
  websvr api                # 启动API服务器
  websvr skills-server      # 启动技能服务(局域网模式,支持PDF等操作)
  websvr ss -p 8001         # 在指定端口启动技能服务
        """,
    )

    subparsers = parser.add_subparsers(dest="command", help="可用命令")

    build_parser = subparsers.add_parser("build", aliases=["b"], help="构建静态文件")
    build_parser.add_argument("-b", "--build", action="store_true", help="构建静态文件")

    clean_parser = subparsers.add_parser("clean", aliases=["c"], help="清理静态文件")
    clean_parser.add_argument("-c", "--clean", action="store_true", help="清理静态文件")

    install_parser = subparsers.add_parser("install", aliases=["i"], help="安装依赖")
    install_parser.add_argument("-i", "--install", action="store_true", help="安装依赖")

    lint_parser = subparsers.add_parser("lint", aliases=["l"], help="代码检查")
    lint_parser.add_argument("-l", "--lint", action="store_true", help="代码检查")

    dev_parser = subparsers.add_parser("dev", aliases=["d"], help="开发模式")
    dev_parser.add_argument(
        "port",
        nargs="?",
        type=int,
        default=5173,
        help="指定端口 (仅开发模式)",
    )
    dev_parser.add_argument(
        "--host",
        "-H",
        default="0.0.0.0",  # noqa: S104
        help="指定主机 (0.0.0.0=局域网可访问)",
    )

    run_parser = subparsers.add_parser("run", aliases=["r"], help="生产模式")
    run_parser.add_argument("--debug", "-d", action="store_true", help="启用调试模式")

    serve_parser = subparsers.add_parser("serve", aliases=["s"], help="仅启动Web服务")
    serve_parser.add_argument(
        "port",
        nargs="?",
        type=int,
        default=5173,
        help="指定端口",
    )
    serve_parser.add_argument(
        "--host",
        "-H",
        default="0.0.0.0",  # noqa: S104
        help="指定主机 (0.0.0.0=局域网可访问)",
    )

    nginx_parser = subparsers.add_parser(
        "nginx-server",
        aliases=["ns"],
        help="使用Nginx启动",
    )
    nginx_parser.add_argument(
        "port",
        nargs="?",
        type=int,
        default=5173,
        help="指定端口",
    )
    nginx_parser.add_argument(
        "--host",
        "-H",
        default="0.0.0.0",  # noqa: S104
        help="指定主机 (0.0.0.0=局域网可访问)",
    )

    api_parser = subparsers.add_parser(
        "api-server",
        aliases=["api"],
        help="启动API服务器",
    )
    api_parser.add_argument(
        "--port",
        "-p",
        type=int,
        default=8001,
        help="指定API服务器端口",
    )
    api_parser.add_argument(
        "--host",
        "-H",
        default="0.0.0.0",  # noqa: S104
        help="指定API服务器主机 (0.0.0.0=局域网可访问)",
    )

    skills_parser = subparsers.add_parser(
        "skills-server",
        aliases=["ss"],
        help="启动技能服务API服务器(局域网模式)",
    )
    skills_parser.add_argument(
        "--port",
        "-p",
        type=int,
        default=8001,
        help="指定服务端口",
    )
    skills_parser.add_argument(
        "--host",
        "-H",
        default="0.0.0.0",  # noqa: S104
        help="指定服务主机 (0.0.0.0=局域网可访问)",
    )

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        return 0

    try:
        if args.command in ("build", "b"):
            svr = NativeServer()
            svr.build()
            return 0

        elif args.command in ("clean", "c"):
            svr = NativeServer()
            svr.clean()
            return 0

        elif args.command in ("install", "i"):
            svr = NativeServer()
            svr.install_dependencies()
            return 0

        elif args.command in ("lint", "l"):
            svr = NativeServer()
            svr.lint()
            return 0

        elif args.command in ("dev", "d"):
            api_server = ApiServer()
            api_server.start()
            svr = ServeServer()
            svr.start(port=args.port, host=args.host, dev=True)
            return 0

        elif args.command in ("run", "r"):
            api_server = ApiServer()
            api_server.start()
            svr = NativeServer()
            svr.start(debug=args.debug)
            return 0

        elif args.command in ("serve", "s"):
            api_server = ApiServer()
            api_server.start()
            svr = ServeServer()
            svr.start(port=args.port, host=args.host)
            return 0

        elif args.command in ("nginx-server", "ns"):
            api_server = ApiServer()
            api_server.start()
            svr = NginxServeServer()
            svr.start(port=args.port, host=args.host)
            return 0

        elif args.command in ("api-server", "api"):
            api_dir = Path(__file__).parent / "api"
            if not api_dir.exists():
                logger.error(f"API目录不存在: {api_dir}")
                return 1

            original_dir = Path.cwd()
            try:
                os.chdir(api_dir)
                logger.info("正在启动FastAPI服务器...")
                logger.info(f"访问地址: http://{args.host}:{args.port}")
                logger.info(f"API文档: http://{args.host}:{args.port}/docs")

                cmd = [
                    sys.executable,
                    "-m",
                    "uvicorn",
                    "main:app",
                    "--host",
                    args.host,
                    "--port",
                    str(args.port),
                    "--reload",
                    "--log-level",
                    "info",
                ]
                from bitool.cmd import execute

                execute(cmd, check=True, timeout=600)
            except KeyboardInterrupt:
                logger.info("FastAPI服务器已停止")
                return 0
            except Exception as e:  # noqa: BLE001
                logger.error(f"启动FastAPI服务器失败: {e}")
                return 1
            finally:
                os.chdir(original_dir)
            return 0

        elif args.command in ("skills-server", "ss"):
            api_dir = Path(__file__).parent / "api"
            if not api_dir.exists():
                logger.error(f"API目录不存在: {api_dir}")
                return 1

            original_dir = Path.cwd()
            try:
                os.chdir(api_dir)
                logger.info("正在启动Bitool技能服务API服务器...")
                logger.info(f"服务地址: http://{args.host}:{args.port}")
                logger.info(f"API文档: http://{args.host}:{args.port}/docs")
                logger.info(f"技能列表: http://{args.host}:{args.port}/api/skills/list")

                cmd = [
                    sys.executable,
                    "-m",
                    "uvicorn",
                    "main:app",
                    "--host",
                    args.host,
                    "--port",
                    str(args.port),
                    "--reload",
                    "--log-level",
                    "info",
                ]
                from bitool.cmd import execute

                execute(cmd, check=True)
            except KeyboardInterrupt:
                logger.info("技能服务API服务器已停止")
                return 0
            except Exception as e:  # noqa: BLE001
                logger.error(f"启动技能服务API服务器失败: {e}")
                return 1
            finally:
                os.chdir(original_dir)
            return 0

        else:
            parser.print_help()
            return 1

    except KeyboardInterrupt:
        logger.info("操作已取消")
        return 130
    except Exception as e:  # noqa: BLE001
        logger.error(f"执行失败: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
