"""Web 服务配置模块."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ServerConfig:
    """Web 服务配置类."""

    name: str = "WebApp"
    version: str = "1.0.0"

    frontend_dir: Path = field(
        default_factory=lambda: Path(__file__).parent / "frontend",
    )
    api_dir: Path = field(default_factory=lambda: Path(__file__).parent / "api")
    nginx_conf_dir: Path = field(
        default_factory=lambda: Path(__file__).parent / "nginx",
    )
    data_dir: Path = field(default_factory=lambda: Path.home() / ".bitool" / "websvr")

    frontend_port: int = 5173
    api_port: int = 8001
    webview_port: int = 11888
    host: str = "127.0.0.1"

    webview_title: str = "Bitool WebView"
    webview_width: int = 1200
    webview_height: int = 800
    webview_min_width: int = 800
    webview_min_height: int = 600

    package_managers: list[str] = field(
        default_factory=lambda: ["pnpm", "yarn", "npm", "bun"],
    )

    enable_api: bool = True
    auto_build: bool = True

    @property
    def dist_dir(self) -> Path:
        """前端构建输出目录."""
        return self.frontend_dir / "deploy"

    @property
    def index_html(self) -> Path:
        """index.html 文件路径."""
        return self.dist_dir / "index.html"

    def update(self, **kwargs: object) -> ServerConfig:
        """更新配置并返回新实例."""
        return ServerConfig(
            name=kwargs.get("name", self.name),
            version=kwargs.get("version", self.version),
            frontend_dir=kwargs.get("frontend_dir", self.frontend_dir),
            api_dir=kwargs.get("api_dir", self.api_dir),
            nginx_conf_dir=kwargs.get("nginx_conf_dir", self.nginx_conf_dir),
            data_dir=kwargs.get("data_dir", self.data_dir),
            frontend_port=kwargs.get("frontend_port", self.frontend_port),
            api_port=kwargs.get("api_port", self.api_port),
            webview_port=kwargs.get("webview_port", self.webview_port),
            host=kwargs.get("host", self.host),
            webview_title=kwargs.get("webview_title", self.webview_title),
            webview_width=kwargs.get("webview_width", self.webview_width),
            webview_height=kwargs.get("webview_height", self.webview_height),
            webview_min_width=kwargs.get("webview_min_width", self.webview_min_width),
            webview_min_height=kwargs.get(
                "webview_min_height",
                self.webview_min_height,
            ),
            package_managers=kwargs.get("package_managers", self.package_managers),
            enable_api=kwargs.get("enable_api", self.enable_api),
            auto_build=kwargs.get("auto_build", self.auto_build),
        )


@dataclass
class ApiRouterConfig:
    """API 路由配置."""

    prefix: str = "/api"
    tags: list[str] = field(default_factory=lambda: ["default"])
    responses: dict = field(
        default_factory=lambda: {404: {"description": "资源不存在"}},
    )


class DefaultConfig(ServerConfig):
    """默认配置工厂."""

    @classmethod
    def for_app(cls, app_name: str, base_path: Path | None = None) -> ServerConfig:
        """为应用创建配置."""
        base = base_path or Path(__file__).parent
        return cls(
            name=app_name,
            frontend_dir=base / "frontend",
            api_dir=base / "api",
            nginx_conf_dir=base / "nginx",
            data_dir=Path.home() / f".{app_name.lower().replace(' ', '_')}" / "websvr",
        )

    @classmethod
    def for_plugin(cls, plugin_name: str, plugin_path: Path) -> ServerConfig:
        """为插件创建配置."""
        return cls(
            name=plugin_name,
            frontend_dir=plugin_path / "frontend",
            api_dir=plugin_path / "api",
            nginx_conf_dir=plugin_path / "nginx",
            data_dir=plugin_path / "data",
        )
