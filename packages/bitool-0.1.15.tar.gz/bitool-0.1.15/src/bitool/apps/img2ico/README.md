# img2ico - Image to ICO 转换器

将各种图像格式转换为多尺寸 ICO 文件。

## 功能特性

- 转换单个图像或批量处理目录
- 生成针对 Windows 和 macOS 优化的多种图标尺寸：
  - **Windows**: 16, 24, 32, 48, 64, 128, 256 像素
  - **macOS**: 16, 32, 64, 128, 256, 512, 1024 像素
- 支持 JPG、PNG、GIF、BMP、WebP、TIFF 和 SVG 格式
- 保持宽高比并使用透明背景
- 可配置的输出尺寸
- **图形界面应用**，便于图像转换
- 质量模式：高（默认）、中、低

## 安装

```bash
# 基础安装（不包含 SVG 和 GUI 支持）
uv pip install -e pytola/img2ico

# 安装 SVG 支持
uv pip install -e pytola/img2ico[svg]

# 安装 GUI 支持
uv pip install -e pytola/img2ico[gui]

# 安装所有功能
uv pip install -e pytola/img2ico[svg,gui]
```

## 使用方法

### 图形界面应用

启动图形界面：

```bash
img2ico-gui
```

图形界面提供：

- 输入/输出文件和目录浏览器
- 可视化尺寸选择器
- 质量模式选择
- 实时进度跟踪
- 配置持久化

### 命令行

#### 转换单个图像

```bash
img2ico image.png
# Creates image.ico with default sizes

img2ico image.png output.ico
# Creates output.ico with default sizes
```

#### 转换目录中的所有图像

```bash
img2ico /path/to/images
# Creates ico_output/ directory with all converted icons

img2ico /path/to/images /path/to/output
# Creates icons in specified output directory
```

#### 指定自定义图标尺寸

```bash
img2ico image.png --sizes 16,32,48,256
# Creates icon with only specified sizes

img2ico image.png -s 32,64
# Short form for sizes option
```

#### 质量模式

```bash
img2ico image.png --quality high
# Use high quality (LANCZOS/BICUBIC resampling with sharpening)

img2ico image.png -q medium
# Use medium quality (BILINEAR resampling)

img2ico image.png -q low
# Use low quality (NEAREST resampling, fastest)
```

## API 使用方法

```python
from img2ico import ImageToIcoRunner
from pathlib import Path

# Convert single file with default sizes (optimized for Windows/macOS)
runner = ImageToIcoRunner(
    input_path=Path("image.png"),
    output_path=Path("output.ico"),
    # Default: {16, 24, 32, 48, 64, 128, 256, 512, 1024}
)
runner.run()

# Batch convert directory with custom quality
runner = ImageToIcoRunner(input_path=Path("/path/to/images"), output_path=Path("/path/to/output"), quality="high")
runner.run()

# Custom sizes
runner = ImageToIcoRunner(input_path=Path("image.png"), sizes={16, 32, 64, 256})
runner.run()
```

## 配置

配置存储在 `~/.pytola/img2ico.json` 文件中：

```json
{
    "DEFAULT_SIZES": [16, 24, 32, 48, 64, 128, 256, 512, 1024],
    "EXTENSIONS": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".tiff", ".svg"]
}
```

GUI 配置单独存储在 `~/.pytola/img2ico_gui.json` 文件中：

```json
{
    "input_path": "/last/used/path",
    "output_path": "/last/output/path",
    "sizes": "16,24,32,48,64,128,256,512,1024",
    "quality": "high",
    "window_width": 900,
    "window_height": 600,
    "recent_input_paths": [],
    "recent_output_paths": []
}
```

## 命令参考

### 命令行工具

| 选项            | 描述                                     |
| --------------- | --------------------------------------- |
| `input`         | 输入图像文件或目录                       |
| `output`        | 输出 ICO 文件或目录（可选）               |
| `-s, --sizes`   | 逗号分隔的图标尺寸列表                   |
| `-q, --quality` | 图像重采样质量（高/中/低）               |
| `-h, --help`    | 显示帮助信息                             |

### 图形界面工具

| 命令          | 描述                         |
| ------------- | ------------------------------- |
| `img2ico-gui` | 启动图形用户界面             |

## 支持的格式

- JPEG/JPG
- PNG
- GIF
- BMP
- WebP
- TIFF
- SVG *（需要 cairosvg 库）*

**注意**: SVG 支持需要 `cairosvg` 库。请使用 `[svg]` 扩展安装：

```bash
uv pip install -e pytola/img2ico[svg]
```

## 质量模式

- **高**（默认）：LANCZOS/BICUBIC 重采样，对大图像使用多步降采样，并对上采样进行锐化
- **中**：双线性重采样，在速度和质量之间取得平衡
- **低**：最近邻重采样，最快但质量最低
