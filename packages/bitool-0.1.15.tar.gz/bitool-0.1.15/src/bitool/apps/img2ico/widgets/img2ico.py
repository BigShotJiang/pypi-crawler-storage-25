"""Img2Ico module for widgets."""

from __future__ import annotations

from dataclasses import field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from bitool.core import JsonConfig, logger
from bitool.gui import apply_theme, setup_ui
from bitool.gui.compat import (
    QApplication,
    QFileDialog,
    QMessageBox,
    QObject,
    QThread,
    QWidget,
    Signal,
)

from ..cli import ImageToIcoRunner, parse_sizes


class Img2IcoConfig(JsonConfig):
    """Image to ICO GUI 配置，支持持久化存储。"""

    input_path: str = str(Path.cwd())
    output_path: str = ""
    sizes: str = "16,24,32,48,64,128,256,512,1024"
    quality: str = "high"
    window_width: int = 800
    window_height: int = 600
    window_x: int = 200
    window_y: int = 200
    max_recent_items: int = 10
    recent_input_paths: list[str] = field(default_factory=list)
    recent_output_paths: list[str] = field(default_factory=list)


conf = Img2IcoConfig()


class WorkerSignals(QObject):
    """工作线程信号。"""

    progress_message = Signal(str)
    progress_update = Signal(int, int)
    finished = Signal(dict)
    error = Signal(str)


class ConversionWorker(QThread):
    """在后台运行图像转换的工作线程。"""

    def __init__(
        self,
        input_path: Path,
        output_path: Path | None,
        sizes: set[int],
        quality: str,
    ) -> None:
        """初始化工作线程。"""
        super().__init__()
        self.input_path = input_path
        self.output_path = output_path
        self.sizes = sizes
        self.quality = quality
        self.signals = WorkerSignals()

    def run(self) -> None:
        """运行图像转换。"""
        try:
            self.signals.progress_message.emit("开始转换...")

            runner = ImageToIcoRunner(
                input_path=self.input_path,
                output_path=self.output_path,
                sizes=self.sizes,
                quality=self.quality,
            )

            # 处理单个文件 vs 目录
            if self.input_path.is_file():
                runner.run()
                result = {
                    "success": True,
                    "files_processed": 1,
                    "output_path": str(self.output_path)
                    if self.output_path
                    else str(self.input_path.with_suffix(".ico")),
                }
            else:
                # 目录转换
                image_files = runner.image_files
                total = len(image_files)

                if total == 0:
                    logger.error("目录中未找到有效的图像文件")
                    return

                self.signals.progress_message.emit(f"找到 {total} 个图像文件")

                for i, img_file in enumerate(image_files):
                    self.signals.progress_message.emit(f"正在转换 {img_file.name}...")
                    self.signals.progress_update.emit(i + 1, total)

                runner.run()

                result = {
                    "success": True,
                    "files_processed": total,
                    "output_path": str(self.output_path) if self.output_path else str(self.input_path / "ico_output"),
                }

            self.signals.progress_message.emit("转换完成!")
            self.signals.finished.emit(result)

        except (OSError, ValueError, RuntimeError) as e:
            self.signals.error.emit(str(e))


class Image2Ico(QWidget):
    """img2ico 应用的主 GUI 窗口。"""

    def __init__(self) -> None:
        """初始化 GUI 组件。"""
        super().__init__()

        self.conversion_worker = None
        self.is_converting = False

        setup_ui(self)
        self.setGeometry(conf.window_x, conf.window_y, conf.window_width, conf.window_height)
        apply_theme(self, "monokai")

        self.input_browse_btn.clicked.connect(self._browse_input)
        self.output_browse_btn.clicked.connect(self._browse_output)
        self.convert_btn.clicked.connect(self._start_conversion)
        self.actionExit.triggered.connect(self.close)
        self.actionAbout.triggered.connect(self._show_about)

    def _browse_input(self) -> None:
        """浏览输入文件或目录。"""
        # 显示组合对话框，同时提供文件和目录选项
        # 首先使用 getOpenFileName，因为大多数用户会选择单个图像
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "选择输入图像",
            self.input_edit.text() or str(Path.cwd()),
            "图像文件 (*.png *.jpg *.jpeg *.gif *.bmp *.webp *.tiff *.svg);;所有文件 (*.*)",
        )

        if file_path:
            self.input_edit.setText(str(Path(file_path)))

    def _browse_output(self) -> None:
        """浏览输出文件或目录。"""
        input_path = Path(self.input_edit.text())

        if input_path.is_file():
            # 单个文件输入 - 输出也是文件
            file_path, _ = QFileDialog.getSaveFileName(
                self,
                "选择输出 ICO 文件",
                str(input_path.with_suffix(".ico")),
                "ICO 文件 (*.ico)",
            )
            if file_path:
                self.output_edit.setText(str(Path(file_path)))
        else:
            # 目录输入 - 输出也是目录
            dir_path = QFileDialog.getExistingDirectory(
                self,
                "选择输出目录",
                self.output_edit.text() or str(Path.cwd() / "ico_output"),
            )
            if dir_path:
                self.output_edit.setText(str(Path(dir_path)))

    def _start_conversion(self) -> None:
        """开始图像转换。"""
        # Validate input
        input_path = Path(self.input_edit.text())
        if not input_path.exists():
            QMessageBox.warning(self, "错误", "输入路径不存在!")
            return

        # Parse sizes
        try:
            sizes = parse_sizes(self.sizes_edit.text())
        except ValueError as e:
            QMessageBox.warning(self, "错误", f"尺寸格式无效: {e}")
            return

        # Get output path
        output_path = None
        if self.output_edit.text().strip():
            output_path = Path(self.output_edit.text())

        # Clear previous results
        self.log_text.clear()
        self.progress_bar.setValue(0)

        # Disable convert button
        self.is_converting = True
        self.convert_btn.setEnabled(False)

        # Create and start worker
        quality = self.quality_combo.currentText()
        self.conversion_worker = ConversionWorker(
            input_path,
            output_path,
            sizes,
            quality,
        )
        self.conversion_worker.signals.progress_message.connect(self._log_message)
        self.conversion_worker.signals.progress_update.connect(self._update_progress)
        self.conversion_worker.signals.finished.connect(self._conversion_finished)
        self.conversion_worker.signals.error.connect(self._conversion_error)
        self.conversion_worker.start()

    def _conversion_finished(self, result: dict[str, Any]) -> None:
        """处理转换完成。"""
        self.is_converting = False
        self.convert_btn.setEnabled(True)
        self.progress_bar.setValue(100)

        files_count = result.get("files_processed", 0)
        output_path = result.get("output_path", "")

        self._log_message(f"成功转换了 {files_count} 个文件")
        self._log_message(f"输出位置: {output_path}")

        QMessageBox.information(
            self,
            "成功",
            f"转换完成!\n{files_count} 个文件已转换为 ICO 格式。",
        )

    def _conversion_error(self, error_msg: str) -> None:
        """处理转换错误。"""
        self.is_converting = False
        self.convert_btn.setEnabled(True)
        self._log_message(f"错误: {error_msg}")
        QMessageBox.critical(self, "错误", f"转换失败: {error_msg}")

    def _update_progress(self, current: int, total: int) -> None:
        """更新进度条。"""
        if total > 0:
            percentage = int((current / total) * 100)
            self.progress_bar.setValue(percentage)
            QApplication.processEvents()

    def _log_message(self, message: str) -> None:
        """向日志添加消息。"""
        timestamp = datetime.now(tz=timezone.utc).strftime("%H:%M:%S")
        self.log_text.append(f"[{timestamp}] {message}")
        QApplication.processEvents()

    def _show_about(self) -> None:
        """显示关于对话框。"""
        QMessageBox.about(
            self,
            "关于 Image to ICO 转换器",
            "Image to ICO 转换器 GUI\n\n版本 1.0\n\n将图像转换为多尺寸 ICO 格式",
        )