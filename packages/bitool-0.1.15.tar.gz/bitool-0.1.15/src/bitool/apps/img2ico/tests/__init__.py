"""img2ico 模块的测试。"""

from __future__ import annotations
