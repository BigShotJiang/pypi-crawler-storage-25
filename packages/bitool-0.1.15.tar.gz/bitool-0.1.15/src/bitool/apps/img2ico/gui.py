"""PySide2 GUI 版本的 img2ico 应用程序。"""

from __future__ import annotations

import sys

from bitool.gui.compat import QApplication

from .widgets.img2ico import Image2Ico


def main() -> None:
    """运行 img2ico GUI 应用程序的主入口点。"""
    app = QApplication(sys.argv)
    app.setApplicationName("Image to ICO 转换器")

    window = Image2Ico()
    window.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
