"""将图像转换为 ICO 格式。

该模块提供将各种图像格式转换为 ICO 文件的功能。
支持多种图标尺寸，并可处理单个文件或批量转换目录中的图像。

命令: img2ico [--sizes 尺寸] [输入路径] [输出路径]
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from functools import cached_property
from pathlib import Path
from typing import ClassVar

from PIL import Image
from PIL.Image import Resampling

from bitool.core import JsonConfig, logger

# Optional SVG support
try:
    import cairosvg

    CAIROSVG_AVAILABLE = True
except (ImportError, OSError) as e:
    # ImportError: cairosvg not installed
    # OSError: Cairo system libraries missing (common on Windows)
    CAIROSVG_AVAILABLE = False
    # Store error for better debugging
    _CAIROSVG_ERROR = str(e)


class ImageToIcoConfig(JsonConfig):
    """图像转 ICO 转换配置。"""

    DEFAULT_SIZES: ClassVar[set[int]] = {16, 24, 32, 48, 64, 128, 256, 512, 1024}
    EXTENSIONS: ClassVar[set[str]] = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".tiff", ".svg"}
    MAX_ICON_SIZE = 256


conf = ImageToIcoConfig()


# Magic numbers for image file headers.
_MAGIC_NUMBERS: dict[str, bytes] = {
    "jpg": b"\xff\xd8\xff",
    "jpeg": b"\xff\xd8\xff",
    "png": b"\x89PNG\r\n\x1a\n",
    "gif": b"GIF87a",
    "bmp": b"BM",
    "webp": b"RIFFf\x00\x00\x00WEBP",
    "tiff": b"II*\x00",
    "ico": b"\x00\x00\x01\x00",
    "svg": b"<?xml",  # SVG files typically start with XML declaration
}


def is_valid_image(file_path: Path) -> bool:
    """验证图像文件。

    参数:
        file_path: 要验证的图像文件路径

    返回值
    -------
        bool: 如果文件是有效的图像文件则返回 True，否则返回 False
    """
    # Basic validation.
    try:
        stat_result = file_path.stat()
        if stat_result.st_size == 0:
            logger.debug(f"空文件: {file_path}")
            return False
    except OSError:
        logger.debug(f"文件未找到或无法访问: {file_path}")
        return False

    # Extension validation.
    ext = file_path.suffix.lower()
    if not conf.EXTENSIONS or ext not in conf.EXTENSIONS:
        logger.debug(f"无效的图像扩展名: {ext}, {file_path}")
        return False

    # File header validation.
    try:
        with file_path.open("rb") as f:
            header = f.read(16)
            # Special handling for WEBP format (RIFF + 4 bytes size + WEBP)
            if ext == ".webp":
                if not (header.startswith(b"RIFF") and header[8:12] == b"WEBP"):
                    logger.debug(f"无效的 WebP 头部: {header[:12]}")
                    return False
            else:
                # Exclude webp magic number to avoid false matching
                non_webp_magic = {k: v for k, v in _MAGIC_NUMBERS.items() if k != "webp"}
                if not any(header.startswith(v) for v in non_webp_magic.values()):
                    logger.debug(f"无效的图像头部: {header[:8]}")
                    return False
    except OSError:
        logger.debug(f"无法读取文件头部: {file_path}")
        return False

    logger.info(f"有效的图像: {file_path}")
    return True


def parse_sizes(sizes_str: str) -> set[int]:
    """将尺寸字符串解析为整数集合。

    参数:
        sizes_str: 逗号分隔的尺寸字符串（例如 "16,32,48,256"）

    返回值
    -------
        整数尺寸集合

    异常
    ------
        ValueError: 如果尺寸字符串无效
    """

    def validate_and_parse_sizes(sizes_str: str) -> set[int]:
        """验证并解析尺寸字符串。"""
        # 首先检查字符串是否为空或仅包含逗号/空格
        stripped_parts = [s.strip() for s in sizes_str.split(",")]
        if not any(stripped_parts):
            msg = "未提供有效的尺寸"
            raise ValueError(msg)

        try:
            sizes = {int(s) for s in stripped_parts if s}
        except ValueError as e:
            msg = f"尺寸格式无效: {sizes_str}。期望逗号分隔的整数。"
            raise ValueError(msg) from e
        else:
            if not sizes:
                msg = "未提供有效的尺寸"
                raise ValueError(msg)
        return sizes

    return validate_and_parse_sizes(sizes_str)


@dataclass(frozen=True)
class ImageToIcoRunner:
    """Image to ICO 转换器处理器。

    处理图像文件并将它们转换为多尺寸 ICO 格式。
    支持单个文件和批量目录转换。
    """

    input_path: Path  # 输入文件或目录
    output_path: Path | None = None  # 输出 ICO 文件或目录
    sizes: set[int] | None = None  # 要生成的图标尺寸（可选，默认为 DEFAULT_SIZES）
    quality: str = "high"  # 图像质量: "low", "medium", "high"

    def __post_init__(self) -> None:
        """初始化后处理钩子，设置默认尺寸（如果未提供）。"""
        object.__setattr__(self, "sizes", self.sizes or conf.DEFAULT_SIZES)

    def run(self) -> None:
        """执行图像到 ICO 的转换过程。"""
        if self.input_path.is_file():
            self._convert_single_file(self.input_path, self.output_path)
        elif self.input_path.is_dir():
            self._convert_directory()
        else:
            logger.error(f"输入路径不存在: {self.input_path}")

    def _convert_single_file(self, input_file: Path, output_file: Path | None) -> None:
        """将单个图像文件转换为 ICO 格式。

        参数:
            input_file: 输入图像文件路径
            output_file: 输出 ICO 文件路径（可选）
        """
        if not is_valid_image(input_file):
            logger.error(f"无效的图像文件: {input_file}")
            return

        # 处理 SVG 文件
        if input_file.suffix.lower() == ".svg":
            self._convert_svg_file(input_file, output_file)
            return

        # 确定输出路径
        if output_file is None:
            output_file = input_file.with_suffix(".ico")
        elif output_file.exists() and output_file.is_dir():
            # 如果 output_file 是已存在的目录，在其内部创建文件
            output_file /= f"{input_file.stem}.ico"
        elif not output_file.exists() and not output_file.suffix:
            # 如果 output_file 不存在且没有后缀，将其视为目录
            output_file.mkdir(parents=True, exist_ok=True)
            output_file /= f"{input_file.stem}.ico"
        # 否则：output_file 被视为文件路径

        # 确保输出目录存在
        output_file.parent.mkdir(parents=True, exist_ok=True)

        try:
            # 打开并转换图像
            with Image.open(str(input_file)) as original_img:
                # 转换为 RGBA 以支持透明通道
                img = original_img.convert("RGBA") if original_img.mode != "RGBA" else original_img

                # 为每个尺寸生成图标图像
                icon_images = []
                for size in sorted(self.sizes or conf.DEFAULT_SIZES):
                    # 调整图像大小以保持宽高比
                    resized = self._resize_for_icon(img, size)
                    icon_images.append(resized)

                # 使用自定义方法保存包含所有尺寸的 ICO 文件
                self._save_multisize_ico(icon_images, sorted(self.sizes or conf.DEFAULT_SIZES), output_file)

            logger.info(f"创建了 ICO 文件: {output_file}")
            logger.info(f"图标尺寸: {sorted(self.sizes or conf.DEFAULT_SIZES)}")

        except (OSError, RuntimeError, ValueError):
            logger.exception(f"转换 {input_file} 失败")

    def _convert_directory(self) -> None:
        """将目录中的所有图像文件转换为 ICO 文件。"""
        image_files = self.image_files
        if not image_files:
            logger.warning(f"未找到有效的图像文件: {self.input_path}")
            return

        # Determine output directory
        output_dir = self.output_path or self.input_path / "ico_output"
        output_dir.mkdir(parents=True, exist_ok=True)

        logger.info(f"正在将 {len(image_files)} 个图像转换为 ICO 格式")

        for image_file in image_files:
            output_file = output_dir / f"{image_file.stem}.ico"
            self._convert_single_file(image_file, output_file)

    def _resize_for_icon(self, image: Image.Image, size: int) -> Image.Image:
        """调整图像大小以适应图标尺寸，同时保持宽高比。

        使用高质量重采样和锐化来保持图像细节。
        质量模式:
        - 低: 最快，使用最近邻重采样
        - 中: 平衡，使用双线性重采样
        - 高: 最佳质量，使用 Lanczos/Bicubic 重采样并锐化

        参数:
            image: 要调整大小的 PIL 图像对象
            size: 图标的尺寸（宽度和高度）

        返回值
        -------
            具有透明背景的调整大小后的 PIL 图像对象
        """
        from PIL import ImageFilter

        # 计算调整大小后的尺寸，保持宽高比
        img_width, img_height = image.size
        ratio = min(size / img_width, size / img_height)
        new_width = int(img_width * ratio)
        new_height = int(img_height * ratio)

        if self.quality == "low":
            # 快速但质量较低
            resized = image.resize((new_width, new_height), Resampling.NEAREST)
        elif self.quality == "medium":
            # 平衡质量和速度
            resized = image.resize((new_width, new_height), Resampling.BILINEAR)
        # 对于放大小图像，使用 BICUBIC 并锐化
        elif ratio > 1:
            resized = image.resize((new_width, new_height), Resampling.BICUBIC)
            # 应用轻微锐化以补偿放大模糊
            resized = resized.filter(ImageFilter.SHARPEN)
        elif ratio < 0.25:
            # 对于极端缩小，使用多步 LANCZOS
            # 首先调整为 4 倍目标大小，然后 2 倍，最后完成
            intermediate1 = image.resize((size * 4, size * 4), Resampling.LANCZOS)
            intermediate2 = intermediate1.resize((size * 2, size * 2), Resampling.LANCZOS)
            resized = intermediate2.resize((new_width, new_height), Resampling.LANCZOS)
        elif ratio < 0.5:
            # 对于重度缩小，使用两步 LANCZOS
            intermediate = image.resize((size * 2, size * 2), Resampling.LANCZOS)
            resized = intermediate.resize((new_width, new_height), Resampling.LANCZOS)
        else:
            # 使用 LANCZOS 正常缩小（最适合缩小）
            resized = image.resize((new_width, new_height), Resampling.LANCZOS)

        # 创建带透明背景的新图像
        icon_img = Image.new("RGBA", (size, size), (0, 0, 0, 0))

        # 将调整大小后的图像居中
        x_offset = (size - new_width) // 2
        y_offset = (size - new_height) // 2
        icon_img.paste(resized, (x_offset, y_offset), resized)

        return icon_img

    def _save_multisize_ico(self, icon_images: list[Image.Image], sizes: list[int], output_file: Path) -> None:
        """保存真正的多尺寸 ICO 文件，使用手工构造方法确保兼容性。

        参数:
            icon_images: 图像对象列表
            sizes: 对应的尺寸列表
            output_file: 输出文件路径
        """
        logger.info(f"开始保存多尺寸 ICO: {len(icon_images)} 个图像, 尺寸: {sizes}")
        # 直接使用手工构造方法, 因为 PIL 的多尺寸支持不可靠
        logger.info("使用手工构造方法创建真正的多尺寸 ICO")
        self._create_genuine_multisize_ico(icon_images, sizes, output_file)

    def _create_genuine_multisize_ico(
        self,
        icon_images: list[Image.Image],
        sizes: list[int],
        output_file: Path,
    ) -> None:
        """创建真正的多尺寸 ICO 文件。

        直接将每个图像保存为 PNG，然后手动构造包含所有尺寸的 ICO 文件结构。
        现代 ICO 格式支持将 PNG 数据直接嵌入，这是 Windows Vista 之后的标准做法。
        """
        import io
        import struct

        def validate_icon_data(png_data_list: list[tuple[bytes, int]]) -> None:
            """验证创建 ICO 文件前的图标数据。"""
            if not png_data_list:
                msg = "没有有效的图像数据"
                raise ValueError(msg)

        logger.info(f"开始手工构造多尺寸 ICO: {len(icon_images)} 个图像")

        # 为每个尺寸保存为 PNG 数据
        png_data_list = []
        for img, size in zip(icon_images, sizes):
            # 保存为 PNG 格式到内存缓冲区
            png_buffer = io.BytesIO()
            img.save(png_buffer, format="PNG")
            png_data = png_buffer.getvalue()
            png_data_list.append((png_data, size))
            png_buffer.close()
            logger.debug(f"保存尺寸 {size}x{size} 为 PNG ({len(png_data)} bytes)")

        # 验证图标数据
        validate_icon_data(png_data_list)

        logger.info(f"收集到 {len(png_data_list)} 个尺寸的 PNG 数据")

        # 构造多尺寸 ICO 文件结构
        # ICO 文件头: Reserved(2) + Type(2) + Count(2)
        count = len(png_data_list)
        header = struct.pack("<HHH", 0, 1, count)  # 0=保留, 1=ICO 类型

        # 构建目录项
        directory_entries = b""
        image_data_blocks = []
        current_offset = 6 + count * 16  # 头部 + 所有目录项大小

        for png_data, size in png_data_list:
            # 对于 PNG 格式的 ICO 图像, 目录项需要设置特殊标记
            # Width/Height 为 0 表示 256 或更大尺寸
            width = size if size < conf.MAX_ICON_SIZE else 0
            height = size if size < conf.MAX_ICON_SIZE else 0

            # PNG 图像的目录项:
            # - Width/Height: 实际尺寸(256以上用0表示)
            # - ColorCount: 0(PNG 不使用调色板)
            # - Reserved: 0
            # - Planes: 1(对于 PNG 通常为 1)
            # - BitCount: 32(RGBA)
            # - Size: PNG 数据的实际大小
            # - Offset: PNG 数据的偏移量

            directory_entry = struct.pack(
                "<BBBBHHII",
                width & 0xFF,  # Width (1 byte)
                height & 0xFF,  # Height (1 byte)
                0,  # ColorCount (1 byte, 0 for PNG)
                0,  # Reserved (1 byte)
                1,  # Planes (2 bytes, typically 1)
                32,  # BitCount (2 bytes, 32 for RGBA)
                len(png_data),  # Size in bytes (4 bytes)
                current_offset,  # Offset to image data (4 bytes)
            )

            directory_entries += directory_entry
            image_data_blocks.append(png_data)
            current_offset += len(png_data)
            logger.debug(f"添加尺寸 {size}x{size} PNG 到目录 (偏移: {current_offset}, 大小: {len(png_data)} bytes)")

        # 组合完整的 ICO 文件
        ico_data = header + directory_entries
        for image_data in image_data_blocks:
            ico_data += image_data

        # 保存最终的多尺寸 ICO 文件
        Path(output_file).write_bytes(ico_data)

        logger.info(f"✅ 真正的多尺寸 ICO 创建成功: {output_file}")
        logger.info(f"   包含尺寸: {[size for _, size in png_data_list]}")
        logger.info(f"   文件大小: {len(ico_data)} 字节")
        logger.info(f"   目录项数量: {count}")

    @cached_property
    def image_files(self) -> list[Path]:
        """获取输入目录中有效的图像文件列表。

        返回值
        -------
            表示有效图像文件的 Path 对象列表，按字母顺序排序。
        """
        all_files = list(self.input_path.iterdir())
        image_filepath = sorted([file for file in all_files if is_valid_image(file)])

        if not image_filepath:
            logger.warning(f"未找到有效的图像文件: {self.input_path}")
            logger.info(f"目录中的文件总数: {len(all_files)}")
        else:
            logger.info(f"在 {len(all_files)} 个总文件中找到了 {len(image_filepath)} 个有效的图像文件")

        return image_filepath

    def _convert_svg_file(self, svg_file: Path, output_file: Path | None) -> None:
        """使用 cairosvg 将 SVG 文件转换为 ICO 格式。

        参数:
            svg_file: 输入 SVG 文件路径
            output_file: 输出 ICO 文件路径（可选）
        """
        if not CAIROSVG_AVAILABLE:
            error_msg = f"无法转换 SVG 文件 {svg_file}: cairosvg 库不可用。 请使用以下命令安装: pip install cairosvg"
            if "_CAIROSVG_ERROR" in globals():
                error_msg += f"\n错误详情: {_CAIROSVG_ERROR}"
            logger.error(error_msg)
            return

        # 确定输出路径
        if output_file is None:
            output_file = svg_file.with_suffix(".ico")
        elif output_file.exists() and output_file.is_dir():
            # 如果 output_file 是已存在的目录，在其内部创建文件
            output_file /= f"{svg_file.stem}.ico"
        elif not output_file.exists() and not output_file.suffix:
            # 如果 output_file 不存在且没有后缀，将其视为目录
            output_file.mkdir(parents=True, exist_ok=True)
            output_file /= f"{svg_file.stem}.ico"
        # 否则：output_file 被视为文件路径

        # 确保输出目录存在
        output_file.parent.mkdir(parents=True, exist_ok=True)

        try:
            # 首先将 SVG 转换为内存中的 PNG
            png_data = cairosvg.svg2png(url=str(svg_file))

            # 将 PNG 数据作为 PIL Image 打开
            from io import BytesIO

            png_image = Image.open(BytesIO(png_data))

            # 转换为 RGBA 以支持透明通道
            if png_image.mode != "RGBA":
                png_image = png_image.convert("RGBA")

            # 为每个尺寸生成图标图像
            icon_images = []
            for size in sorted(self.sizes or conf.DEFAULT_SIZES):
                # 调整图像大小以保持宽高比
                resized = self._resize_for_icon(png_image, size)
                icon_images.append(resized)

            # 使用自定义方法保存包含所有尺寸的 ICO 文件
            self._save_multisize_ico(icon_images, sorted(self.sizes or conf.DEFAULT_SIZES), output_file)

            logger.info(f"从 SVG 创建了 ICO 文件: {output_file}")
            logger.info(f"图标尺寸: {sorted(self.sizes or conf.DEFAULT_SIZES)}")

        except (OSError, RuntimeError, ValueError):
            logger.exception(f"转换 SVG {svg_file} 失败")


def parse_args() -> argparse.Namespace:
    """解析 img2ico 工具的命令行参数。

    返回值
    -------
        包含已解析参数的 Namespace 对象:
        - input: 输入图像文件或目录的路径
        - output: 输出 ICO 文件或目录的路径
        - sizes: 要生成的图标尺寸集合
    """
    parser = argparse.ArgumentParser(description="将图像转换为多尺寸 ICO 格式。")
    parser.add_argument(
        "input",
        type=str,
        nargs="?",
        default=str(Path.cwd()),
        help="输入图像文件或目录, 默认当前目录",
    )
    parser.add_argument(
        "output",
        type=str,
        nargs="?",
        default=None,
        help="输出 ICO 文件或目录, 默认 input_name.ico 或 ico_output/",
    )
    parser.add_argument(
        "--sizes",
        "-s",
        type=str,
        default=None,
        help="逗号分隔的图标尺寸列表, 默认 Windows & macOS 优化 - 16,24,32,48,64,128,256,512,1024",
    )
    parser.add_argument(
        "--quality",
        "-q",
        type=str,
        choices=["low", "medium", "high"],
        default="high",
        help="图像重采样质量",
    )
    return parser.parse_args()


def main() -> None:
    """运行 img2ico 命令行工具的主入口点。

    解析命令行参数，验证输入路径，
    并执行图像到 ICO 的转换过程。
    """
    args = parse_args()

    # 将字符串路径转换为 Path 对象
    input_path = Path(args.input)
    output_path = Path(args.output) if args.output else None

    # 如果提供了尺寸，则解析
    sizes = None
    if args.sizes:
        try:
            sizes = parse_sizes(args.sizes)
        except ValueError:
            logger.exception("无效的尺寸参数")
            return

    # 验证输入路径是否存在
    if not input_path.exists():
        logger.error(f"输入路径不存在: {input_path}")
        return

    # 执行转换
    runner = ImageToIcoRunner(input_path=input_path, output_path=output_path, sizes=sizes, quality=args.quality)
    runner.run()


if __name__ == "__main__":
    main()
