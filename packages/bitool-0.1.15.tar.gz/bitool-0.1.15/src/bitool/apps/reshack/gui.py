"""Graphical user interface for reshack."""

import sys

from bitool.core import logger
from bitool.gui.compat import QApplication

from .ui.main_window import MainWindow


def main() -> None:
    """Launch the GUI application."""
    if QApplication is None:
        logger.error("GUI dependencies not available")
        logger.error("Error: GUI dependencies not available. Please install PySide2.")
        sys.exit(1)

    try:
        logger.info("Launching Resource Hacker GUI")

        # Create Qt application
        app = QApplication(sys.argv)
        app.setApplicationName("Resource Hacker")
        app.setApplicationVersion("0.1.0")

        # Create and show main window
        window = MainWindow()
        window.show()

        logger.info("GUI application started successfully")

        # Run application
        sys.exit(app.exec_())

    except ImportError:
        logger.exception("Failed to import GUI dependencies")
        logger.exception(
            "Error: GUI dependencies not available. Please install PySide2.",
        )
        sys.exit(1)
    except OSError:
        logger.exception("Failed to launch GUI")
        logger.exception("Error launching GUI")
        sys.exit(1)


if __name__ == "__main__":
    main()
