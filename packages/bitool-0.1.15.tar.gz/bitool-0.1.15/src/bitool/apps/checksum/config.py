"""Configuration for checksum."""

from __future__ import annotations

from typing import ClassVar


class ChecksumConfig:
    """Configuration for the checksum application."""

    # Window settings
    THEME: ClassVar[str] = "gruvbox"
    WIN_SIZE: ClassVar[tuple[int, int]] = (720, 480)
    WIN_POS: ClassVar[tuple[int, int]] = (300, 200)
    TITLE: ClassVar[str] = "校验和计算器 v1.0"


conf = ChecksumConfig()
