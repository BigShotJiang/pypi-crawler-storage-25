"""Checksum calculator widget with UI separation."""

from __future__ import annotations

from pathlib import Path

from bitool.core import logger
from bitool.gui import apply_theme, setup_ui
from bitool.gui.compat import (
    QCheckBox,
    QDialog,
    QDir,
    QFileDialog,
    QGroupBox,
    QLineEdit,
    QPushButton,
    QRadioButton,
    QTextEdit,
)

from ..cli import ChecksumCalculator, HashAlgorithm
from ..config import conf

__version__ = "1.0"


class ChecksumDialog:
    """Checksum calculation dialog interface with UI separation."""

    m_rbMD5: QRadioButton
    m_rbSHA1: QRadioButton
    m_rbSHA256: QRadioButton
    m_rbSHA384: QRadioButton
    m_rbSHA512: QRadioButton
    m_rbBlake2b: QRadioButton
    m_rbBlake2s: QRadioButton
    m_leString: QLineEdit
    m_pbGenerateString: QPushButton
    m_leFile: QLineEdit
    m_pbOpenFile: QPushButton
    m_pbGenerateFile: QPushButton
    m_cbEnableCompare: QCheckBox
    m_leCompare: QLineEdit
    m_teChecksum: QTextEdit
    dataSourceGroup: QGroupBox
    algorithmPanel: QGroupBox
    comparisonGroup: QGroupBox
    resultGroup: QGroupBox

    def __init__(self, parent: QDialog | None = None) -> None:
        """Initialize checksum dialog."""
        self._dialog = QDialog(parent)

        setup_ui(self._dialog)

        apply_theme(self._dialog, conf.THEME)

        # Apply styles
        self._dialog.setWindowTitle(conf.TITLE)
        self._dialog.resize(*conf.WIN_SIZE)

        # Initialize core calculator
        self.calculator = ChecksumCalculator()
        self.current_file_path: str = ""

        # 绑定 UI 控件到 self，以便直接访问
        self._bind_ui_controls()

        # Store algorithm buttons mapping
        self.algorithm_buttons: dict[str, QRadioButton] = {
            "MD5": self.m_rbMD5,
            "SHA1": self.m_rbSHA1,
            "SHA256": self.m_rbSHA256,
            "SHA384": self.m_rbSHA384,
            "SHA512": self.m_rbSHA512,
            "Blake2b": self.m_rbBlake2b,
            "Blake2s": self.m_rbBlake2s,
        }

        # Store group box references for dynamic title updates
        self.group_boxes: dict[str, QGroupBox] = {
            "data_source": self.dataSourceGroup,
            "algorithm": self.algorithmPanel,
            "comparison": self.comparisonGroup,
            "checksum_result": self.resultGroup,
        }

        # Initialize comparison feature
        self.enable_comparison: bool = False
        self.m_cbEnableCompare.setChecked(False)

        # Initialize UI connections
        self._init_ui()

    def _bind_ui_controls(self) -> None:
        """Bind UI controls from dialog to self for easy access."""
        # Bind all named controls from the dialog to self
        self.m_rbMD5 = self._dialog.findChild(QRadioButton, "m_rbMD5")
        self.m_rbSHA1 = self._dialog.findChild(QRadioButton, "m_rbSHA1")
        self.m_rbSHA256 = self._dialog.findChild(QRadioButton, "m_rbSHA256")
        self.m_rbSHA384 = self._dialog.findChild(QRadioButton, "m_rbSHA384")
        self.m_rbSHA512 = self._dialog.findChild(QRadioButton, "m_rbSHA512")
        self.m_rbBlake2b = self._dialog.findChild(QRadioButton, "m_rbBlake2b")
        self.m_rbBlake2s = self._dialog.findChild(QRadioButton, "m_rbBlake2s")
        self.m_leString = self._dialog.findChild(QLineEdit, "m_leString")
        self.m_pbGenerateString = self._dialog.findChild(
            QPushButton, "m_pbGenerateString"
        )
        self.m_leFile = self._dialog.findChild(QLineEdit, "m_leFile")
        self.m_pbOpenFile = self._dialog.findChild(QPushButton, "m_pbOpenFile")
        self.m_pbGenerateFile = self._dialog.findChild(QPushButton, "m_pbGenerateFile")
        self.m_cbEnableCompare = self._dialog.findChild(QCheckBox, "m_cbEnableCompare")
        self.m_leCompare = self._dialog.findChild(QLineEdit, "m_leCompare")
        self.m_teChecksum = self._dialog.findChild(QTextEdit, "m_teChecksum")
        self.dataSourceGroup = self._dialog.findChild(QGroupBox, "dataSourceGroup")
        self.algorithmPanel = self._dialog.findChild(QGroupBox, "algorithmPanel")
        self.comparisonGroup = self._dialog.findChild(QGroupBox, "comparisonGroup")
        self.resultGroup = self._dialog.findChild(QGroupBox, "resultGroup")

    def _init_ui(self) -> None:
        """Initialize user interface connections with modern event handling."""
        # Connect algorithm radio buttons
        for radio_button in self.algorithm_buttons.values():
            radio_button.toggled.connect(self._on_algorithm_changed)

        # Initialize comparison feature with enhanced logic
        self.m_cbEnableCompare.toggled.connect(self._toggle_comparison)
        self.m_leCompare.textChanged.connect(self._on_comparison_text_changed)

        # Connect action buttons with modern signal handling
        self.m_pbGenerateString.clicked.connect(self._generate_string_checksum)
        self.m_pbOpenFile.clicked.connect(self._open_file_dialog)
        self.m_pbGenerateFile.clicked.connect(self._generate_file_checksum)

        # Add placeholder text updates
        self.m_leString.textChanged.connect(self._update_string_placeholder)
        self.m_leFile.textChanged.connect(self._update_file_placeholder)

    def _toggle_comparison(self) -> None:
        """Toggle checksum comparison feature with enhanced UX."""
        self.enable_comparison = self.m_cbEnableCompare.isChecked()
        self.m_leCompare.setEnabled(self.enable_comparison)
        if not self.enable_comparison:
            self.m_leCompare.clear()

    def _on_comparison_text_changed(self, text: str) -> None:
        """Handle comparison text changes for real-time validation."""
        # Could add real-time validation here if needed

    def _update_string_placeholder(self, text: str) -> None:
        """Update string input placeholder based on content."""
        if text:
            self.m_leString.setPlaceholderText("")
        else:
            self.m_leString.setPlaceholderText("Input String")

    def _update_file_placeholder(self, text: str) -> None:
        """Update file input placeholder based on content."""
        if text:
            self.m_leFile.setPlaceholderText("")
        else:
            self.m_leFile.setPlaceholderText("Input File")

    def _on_algorithm_changed(self) -> None:
        """Handle hash algorithm selection change."""
        for algorithm_name, radio_button in self.algorithm_buttons.items():
            if radio_button.isChecked():
                try:
                    # Map UI algorithm names to HashAlgorithm enum members
                    algorithm_mapping = {
                        "MD5": HashAlgorithm.MD5,
                        "SHA1": HashAlgorithm.SHA1,
                        "SHA256": HashAlgorithm.SHA256,
                        "SHA384": HashAlgorithm.SHA384,
                        "SHA512": HashAlgorithm.SHA512,
                        "Blake2b": HashAlgorithm.BLAKE2B,
                        "Blake2s": HashAlgorithm.BLAKE2S,
                    }

                    if algorithm_name in algorithm_mapping:
                        algorithm = algorithm_mapping[algorithm_name]
                        self.calculator.set_algorithm(algorithm)
                    else:
                        logger.error(f"Unknown hash algorithm: {algorithm_name}")
                    break
                except (KeyError, AttributeError, TypeError):
                    logger.exception(f"Error setting algorithm {algorithm_name}")

    def _generate_string_checksum(self) -> None:
        """Generate checksum for input string."""
        content = self.m_leString.text()
        if not content.strip():
            self.m_teChecksum.setText("Please enter string")
            return

        try:
            hash_value = self.calculator.calculate_string_checksum(content)
            result_text = hash_value

            # Add comparison result if enabled
            if self.enable_comparison:
                expected = self.m_leCompare.text().strip()
                if not expected:
                    self.m_teChecksum.setText("Please enter comparison value")
                    return

                is_match = self.calculator.verify_checksum(hash_value, expected)
                verification_msg = (
                    "Verification Passed" if is_match else "Verification Failed"
                )
                result_text += f"\n{verification_msg}"

            self.m_teChecksum.setText(result_text)
        except (OSError, ValueError, TypeError) as e:
            logger.exception("Failed to calculate string checksum")
            self.m_teChecksum.setText(f"Error: {e!s}")

    def _open_file_dialog(self) -> None:
        """Open file selection dialog."""
        dialog = QFileDialog()
        filename, _ = dialog.getOpenFileName(
            self._dialog,
            "Select File",
            QDir.currentPath(),
            "All Files",
        )

        if filename:
            self.current_file_path = filename
            self.m_leFile.setText(filename)

    def _generate_file_checksum(self) -> None:
        """Generate checksum for selected file."""
        if not self.current_file_path or not Path(self.current_file_path).exists():
            self.m_teChecksum.setText("Please select a valid file")
            return

        try:
            file_path = Path(self.current_file_path)
            hash_value = self.calculator.calculate_file_checksum(file_path)
            result_text = hash_value

            # Add comparison result if enabled
            if self.enable_comparison:
                expected = self.m_leCompare.text().strip()
                if not expected:
                    self.m_teChecksum.setText("Please enter comparison value")
                    return

                is_match = self.calculator.verify_checksum(hash_value, expected)
                result_text += f"\nVerification: {'PASSED' if is_match else 'FAILED'}"

            self.m_teChecksum.setText(result_text)
        except (OSError, ValueError, TypeError) as e:
            logger.exception("Failed to calculate file checksum")
            self.m_teChecksum.setText(f"Error: {e!s}")

    def show(self) -> None:
        """Show the dialog."""
        self._dialog.show()

    def exec_(self) -> int:
        """Execute the dialog as modal."""
        return self._dialog.exec_()
