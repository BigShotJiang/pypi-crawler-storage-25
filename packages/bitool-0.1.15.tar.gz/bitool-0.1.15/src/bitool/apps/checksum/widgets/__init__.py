"""Checksum widgets module."""
