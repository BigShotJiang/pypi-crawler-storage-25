"""Graphical user interface for checksum."""

from __future__ import annotations

import sys

from bitool.gui.compat import QApplication

from .widgets.checksum import ChecksumDialog


def main() -> int:
    """Run checksum tool in graphical user interface mode."""
    app = QApplication(sys.argv)
    window = ChecksumDialog()
    window.show()
    return app.exec_()
