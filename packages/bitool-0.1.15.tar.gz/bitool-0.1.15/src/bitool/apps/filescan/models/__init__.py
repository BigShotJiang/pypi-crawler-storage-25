"""pytola-office 工具的模型模块."""
