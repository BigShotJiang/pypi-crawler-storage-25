"""Tests for PDF content rule - PDF 文件内容规则测试."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from ...models.fileinfo import FileInfo
from ..content.pdf import PdfRule


class TestPdfRule:
    """PdfRule 测试类."""

    @pytest.fixture
    def pdf_rule_config(self) -> dict:
        """PDF 规则配置."""
        return {
            "name": "PDF Test Rule",
            "description": "Test PDF matching",
            "pattern": "secret",
            "regex": False,
            "case_sensitive": False,
            "context_lines": 2,
        }

    @pytest.fixture
    def sample_fileinfo(self, tmp_path: Path) -> FileInfo:
        """创建样本文件信息对象."""
        test_file = tmp_path / "test.pdf"
        test_file.touch()
        return FileInfo(
            file_path=str(test_file),
            root_path=str(tmp_path),
            file_type=".pdf",
            file_size=0,
        )

    def test_init_with_valid_config(self, pdf_rule_config: dict) -> None:
        """测试使用有效配置初始化."""
        rule = PdfRule(pdf_rule_config)
        assert rule.name == "PDF Test Rule"
        assert rule.pattern == "secret"
        assert rule.is_regex is False
        assert rule.case_sensitive is False
        assert rule.context_lines == 2
        assert rule.file_type == "pdf"
        assert rule.use_ocr is False

    def test_init_with_ocr(self, pdf_rule_config: dict) -> None:
        """测试使用 OCR 初始化."""
        rule = PdfRule(pdf_rule_config, use_ocr=True)
        assert rule.use_ocr is True

    def test_parse_content_without_libraries(self, sample_fileinfo: FileInfo) -> None:
        """测试当没有安装 PDF 库时的解析."""
        with patch("bitool.apps.filescan.rules.content.pdf.pypdf", None):
            with patch("bitool.apps.filescan.rules.content.pdf.fitz", None):
                rule = PdfRule({"name": "Test", "pattern": ""})
                content = rule.parse_content(sample_fileinfo)
                assert content == ""

    @pytest.mark.skipif(True, reason="需要 PyMuPDF 或 PyPDF 库创建真实文件")
    def test_match_with_real_file(self, pdf_rule_config: dict) -> None:
        """测试使用真实 PDF 文件匹配（需要 PDF 库）."""
        pass

    def test_nonexistent_file(self, tmp_path: Path) -> None:
        """测试不存在的文件."""
        rule = PdfRule({"name": "Test", "pattern": "secret"})
        fileinfo = FileInfo(
            file_path=str(tmp_path / "nonexistent.pdf"),
            root_path=str(tmp_path),
            file_type=".pdf",
            file_size=0,
        )
        
        content = rule.parse_content(fileinfo)
        assert content == ""
        
        matches = rule.find_all_matches(fileinfo)
        assert len(matches) == 0
