"""Tests for CSV content rule - CSV 文件内容规则测试."""

from __future__ import annotations

from pathlib import Path

import pytest

from ...models.fileinfo import FileInfo
from ..content.csv import CsvRule


class TestCsvRule:
    """CsvRule 测试类."""

    @pytest.fixture
    def csv_rule_config(self) -> dict:
        """CSV 规则配置."""
        return {
            "name": "CSV Test Rule",
            "description": "Test CSV matching",
            "pattern": "secret",
            "regex": False,
            "case_sensitive": False,
            "context_lines": 2,
        }

    @pytest.fixture
    def sample_csv_file(self, tmp_path: Path) -> Path:
        """创建样本 CSV 文件."""
        csv_content = """name,email,phone
John Doe,john@example.com,123-456-7890
Jane Smith,jane@example.com,secret-123
Bob Johnson,bob@example.com,987-654-3210
"""
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content, encoding="utf-8")
        return csv_file

    @pytest.fixture
    def empty_csv_file(self, tmp_path: Path) -> Path:
        """创建空 CSV 文件."""
        csv_file = tmp_path / "empty.csv"
        csv_file.touch()
        return csv_file

    @pytest.fixture
    def sample_csv_fileinfo(self, sample_csv_file: Path) -> FileInfo:
        """创建样本文件信息对象."""
        return FileInfo(
            file_path=str(sample_csv_file),
            root_path=str(sample_csv_file.parent),
            file_type=".csv",
            file_size=sample_csv_file.stat().st_size,
        )

    @pytest.fixture
    def empty_csv_fileinfo(self, empty_csv_file: Path) -> FileInfo:
        """创建空文件信息对象."""
        return FileInfo(
            file_path=str(empty_csv_file),
            root_path=str(empty_csv_file.parent),
            file_type=".csv",
            file_size=0,
        )

    def test_init_with_valid_config(self, csv_rule_config: dict) -> None:
        """测试使用有效配置初始化."""
        rule = CsvRule(csv_rule_config)
        assert rule.name == "CSV Test Rule"
        assert rule.pattern == "secret"
        assert rule.is_regex is False
        assert rule.case_sensitive is False
        assert rule.context_lines == 2
        assert rule.file_type == "csv"

    def test_parse_content(self, sample_csv_fileinfo: FileInfo) -> None:
        """测试 CSV 内容解析."""
        rule = CsvRule({"name": "Test", "pattern": ""})
        content = rule.parse_content(sample_csv_fileinfo)
        
        assert "John Doe" in content
        assert "jane@example.com" in content
        assert "secret-123" in content
        assert " | " in content  # 分隔符存在

    def test_match_content(self, csv_rule_config: dict, sample_csv_fileinfo: FileInfo) -> None:
        """测试 CSV 内容匹配."""
        rule = CsvRule(csv_rule_config)
        result = rule.match(sample_csv_fileinfo)
        
        assert result is not None
        assert result.rule_name == "CSV Test Rule"
        assert "secret" in result.match_text
        assert result.analysis_type == "content"

    def test_match_no_match(self, sample_csv_fileinfo: FileInfo) -> None:
        """测试不匹配的情况."""
        config = {
            "name": "No Match Rule",
            "description": "No matches here",
            "pattern": "nonexistent",
            "regex": False,
        }
        rule = CsvRule(config)
        result = rule.match(sample_csv_fileinfo)
        
        assert result is None

    def test_find_all_matches(self, csv_rule_config: dict, sample_csv_fileinfo: FileInfo) -> None:
        """测试查找所有匹配."""
        rule = CsvRule(csv_rule_config)
        matches = rule.find_all_matches(sample_csv_fileinfo)
        
        assert len(matches) == 1
        assert matches[0].rule_name == "CSV Test Rule"
        assert "secret" in matches[0].match_text

    def test_parse_empty_csv(self, empty_csv_fileinfo: FileInfo) -> None:
        """测试解析空 CSV 文件."""
        rule = CsvRule({"name": "Test", "pattern": ""})
        content = rule.parse_content(empty_csv_fileinfo)
        
        assert content == ""

    def test_match_empty_csv(self, csv_rule_config: dict, empty_csv_fileinfo: FileInfo) -> None:
        """测试匹配空 CSV 文件."""
        rule = CsvRule(csv_rule_config)
        result = rule.match(empty_csv_fileinfo)
        
        assert result is None

    def test_nonexistent_file(self, tmp_path: Path) -> None:
        """测试不存在的文件."""
        rule = CsvRule({"name": "Test", "pattern": "secret"})
        fileinfo = FileInfo(
            file_path=str(tmp_path / "nonexistent.csv"),
            root_path=str(tmp_path),
            file_type=".csv",
            file_size=0,
        )
        
        content = rule.parse_content(fileinfo)
        assert content == ""
        
        matches = rule.find_all_matches(fileinfo)
        assert len(matches) == 0

    def test_csv_with_special_chars(self, tmp_path: Path) -> None:
        """测试包含特殊字符的 CSV."""
        csv_content = """col1,col2,col3
value1,"value,with,comma",value3
special,chars,test-secret-123
"""
        csv_file = tmp_path / "special.csv"
        csv_file.write_text(csv_content, encoding="utf-8")
        
        fileinfo = FileInfo(
            file_path=str(csv_file),
            root_path=str(tmp_path),
            file_type=".csv",
            file_size=csv_file.stat().st_size,
        )
        
        rule = CsvRule({"name": "Test", "pattern": "test-secret"})
        matches = rule.find_all_matches(fileinfo)
        
        assert len(matches) == 1

    def test_case_sensitive_match(self, tmp_path: Path) -> None:
        """测试区分大小写的匹配."""
        csv_content = """col1,col2
Secret,value
secret,value
"""
        csv_file = tmp_path / "case.csv"
        csv_file.write_text(csv_content, encoding="utf-8")
        
        fileinfo = FileInfo(
            file_path=str(csv_file),
            root_path=str(tmp_path),
            file_type=".csv",
            file_size=csv_file.stat().st_size,
        )
        
        config = {
            "name": "Case Sensitive",
            "description": "Case test",
            "pattern": "Secret",
            "regex": False,
            "case_sensitive": True,
        }
        rule = CsvRule(config)
        matches = rule.find_all_matches(fileinfo)
        
        # 应该只匹配大写的 "Secret"
        assert len(matches) == 1

    def test_regex_match(self, tmp_path: Path) -> None:
        """测试正则表达式匹配."""
        csv_content = """name,code
Alice,ABC-123
Bob,DEF-456
Charlie,GHI-789
"""
        csv_file = tmp_path / "regex.csv"
        csv_file.write_text(csv_content, encoding="utf-8")
        
        fileinfo = FileInfo(
            file_path=str(csv_file),
            root_path=str(tmp_path),
            file_type=".csv",
            file_size=csv_file.stat().st_size,
        )
        
        config = {
            "name": "Regex Rule",
            "description": "Test regex",
            "pattern": r"[A-Z]{3}-\d{3}",
            "regex": True,
            "case_sensitive": True,
        }
        rule = CsvRule(config)
        matches = rule.find_all_matches(fileinfo)
        
        assert len(matches) == 3
