"""Tests for Markdown content rule - Markdown 文件内容规则测试."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from ...models.fileinfo import FileInfo
from ..content.markdown import MarkdownRule


class TestMarkdownRule:
    """MarkdownRule 测试类."""

    @pytest.fixture
    def md_rule_config(self) -> dict:
        """Markdown 规则配置."""
        return {
            "name": "Markdown Test Rule",
            "description": "Test MD matching",
            "pattern": "secret",
            "regex": False,
            "case_sensitive": False,
            "context_lines": 2,
        }

    @pytest.fixture
    def sample_md_file(self, tmp_path: Path) -> Path:
        """创建样本 Markdown 文件."""
        md_content = """# Test Document

This is a **test** document.

## Section 1

It contains some confidential information: secret-123

## Section 2

More text here...
"""
        md_file = tmp_path / "test.md"
        md_file.write_text(md_content, encoding="utf-8")
        return md_file

    @pytest.fixture
    def sample_md_fileinfo(self, sample_md_file: Path) -> FileInfo:
        """创建样本文件信息对象."""
        return FileInfo(
            file_path=str(sample_md_file),
            root_path=str(sample_md_file.parent),
            file_type=".md",
            file_size=sample_md_file.stat().st_size,
        )

    def test_init_with_valid_config(self, md_rule_config: dict) -> None:
        """测试使用有效配置初始化."""
        rule = MarkdownRule(md_rule_config)
        assert rule.name == "Markdown Test Rule"
        assert rule.pattern == "secret"
        assert rule.is_regex is False
        assert rule.case_sensitive is False
        assert rule.context_lines == 2
        assert rule.file_type == "md"

    def test_parse_content(self, sample_md_fileinfo: FileInfo) -> None:
        """测试 Markdown 内容解析."""
        rule = MarkdownRule({"name": "Test", "pattern": ""})
        content = rule.parse_content(sample_md_fileinfo)

        # 检查内容是否保留
        assert "Test Document" in content
        assert "confidential" in content
        assert "secret-123" in content

    def test_parse_content_without_library(self, sample_md_fileinfo: FileInfo) -> None:
        """测试当没有安装 markdown 库时的解析."""
        with patch("bitool.apps.filescan.rules.content.markdown.markdown", None):
            rule = MarkdownRule({"name": "Test", "pattern": ""})
            content = rule.parse_content(sample_md_fileinfo)

            # 没有库时，应该返回原始内容
            assert "# Test Document" in content
            assert "**test**" in content

    def test_match_content(self, md_rule_config: dict, sample_md_fileinfo: FileInfo) -> None:
        """测试 Markdown 内容匹配."""
        rule = MarkdownRule(md_rule_config)
        result = rule.match(sample_md_fileinfo)

        assert result is not None
        assert result.rule_name == "Markdown Test Rule"
        assert "secret" in result.match_text
        assert result.analysis_type == "content"

    def test_match_no_match(self, tmp_path: Path) -> None:
        """测试不匹配的情况."""
        md_content = """# Clean Document

No secrets here.
"""
        md_file = tmp_path / "clean.md"
        md_file.write_text(md_content, encoding="utf-8")

        fileinfo = FileInfo(
            file_path=str(md_file),
            root_path=str(tmp_path),
            file_type=".md",
            file_size=md_file.stat().st_size,
        )

        config = {
            "name": "No Match Rule",
            "pattern": "nonexistent",
        }
        rule = MarkdownRule(config)
        result = rule.match(fileinfo)

        assert result is None

    def test_find_all_matches(self, tmp_path: Path) -> None:
        """测试查找所有匹配."""
        md_content = """# Multiple Items

First secret: abc123

Second secret: def456

Third secret: ghi789
"""
        md_file = tmp_path / "multi.md"
        md_file.write_text(md_content, encoding="utf-8")

        fileinfo = FileInfo(
            file_path=str(md_file),
            root_path=str(tmp_path),
            file_type=".md",
            file_size=md_file.stat().st_size,
        )

        rule = MarkdownRule({"name": "Test", "pattern": "secret"})
        matches = rule.find_all_matches(fileinfo)

        assert len(matches) == 3

    def test_nonexistent_file(self, tmp_path: Path) -> None:
        """测试不存在的文件."""
        rule = MarkdownRule({"name": "Test", "pattern": "secret"})
        fileinfo = FileInfo(
            file_path=str(tmp_path / "nonexistent.md"),
            root_path=str(tmp_path),
            file_type=".md",
            file_size=0,
        )

        content = rule.parse_content(fileinfo)
        assert content == ""

        matches = rule.find_all_matches(fileinfo)
        assert len(matches) == 0

    def test_empty_md_file(self, tmp_path: Path) -> None:
        """测试空 Markdown 文件."""
        md_file = tmp_path / "empty.md"
        md_file.touch()

        fileinfo = FileInfo(
            file_path=str(md_file),
            root_path=str(tmp_path),
            file_type=".md",
            file_size=0,
        )

        rule = MarkdownRule({"name": "Test", "pattern": "secret"})
        content = rule.parse_content(fileinfo)
        assert content == ""
