"""Tests for HTML content rule - HTML 文件内容规则测试."""

from __future__ import annotations

from pathlib import Path

import pytest

from ...models.fileinfo import FileInfo
from ..content.html import HtmlRule


class TestHtmlRule:
    """HtmlRule 测试类."""

    @pytest.fixture
    def html_rule_config(self) -> dict:
        """HTML 规则配置."""
        return {
            "name": "HTML Test Rule",
            "description": "Test HTML matching",
            "pattern": "secret",
            "regex": False,
            "case_sensitive": False,
            "context_lines": 2,
        }

    @pytest.fixture
    def sample_html_file(self, tmp_path: Path) -> Path:
        """创建样本 HTML 文件."""
        html_content = """<!DOCTYPE html>
<html>
<head>
    <title>Test Page</title>
</head>
<body>
    <h1>Welcome</h1>
    <p>This is a <strong>test</strong> page.</p>
    <p>It contains a secret message: confidential-123</p>
</body>
</html>
"""
        html_file = tmp_path / "test.html"
        html_file.write_text(html_content, encoding="utf-8")
        return html_file

    @pytest.fixture
    def sample_html_fileinfo(self, sample_html_file: Path) -> FileInfo:
        """创建样本文件信息对象."""
        return FileInfo(
            file_path=str(sample_html_file),
            root_path=str(sample_html_file.parent),
            file_type=".html",
            file_size=sample_html_file.stat().st_size,
        )

    def test_init_with_valid_config(self, html_rule_config: dict) -> None:
        """测试使用有效配置初始化."""
        rule = HtmlRule(html_rule_config)
        assert rule.name == "HTML Test Rule"
        assert rule.pattern == "secret"
        assert rule.is_regex is False
        assert rule.case_sensitive is False
        assert rule.context_lines == 2
        assert rule.file_type == "html"

    def test_parse_content(self, sample_html_fileinfo: FileInfo) -> None:
        """测试 HTML 内容解析."""
        rule = HtmlRule({"name": "Test", "pattern": ""})
        content = rule.parse_content(sample_html_fileinfo)
        
        # 检查标签是否被正确移除
        assert "<h1>" not in content
        assert "<strong>" not in content
        
        # 检查内容是否保留
        assert "Welcome" in content
        assert "test" in content
        assert "confidential" in content

    def test_match_content(self, html_rule_config: dict, sample_html_fileinfo: FileInfo) -> None:
        """测试 HTML 内容匹配."""
        rule = HtmlRule(html_rule_config)
        result = rule.match(sample_html_fileinfo)
        
        assert result is not None
        assert result.rule_name == "HTML Test Rule"
        assert "secret" in result.match_text
        assert result.analysis_type == "content"

    def test_match_no_match(self, tmp_path: Path) -> None:
        """测试不匹配的情况."""
        html_content = """<!DOCTYPE html>
<html>
<body>
    <p>No secrets here</p>
</body>
</html>
"""
        html_file = tmp_path / "clean.html"
        html_file.write_text(html_content, encoding="utf-8")
        
        fileinfo = FileInfo(
            file_path=str(html_file),
            root_path=str(tmp_path),
            file_type=".html",
            file_size=html_file.stat().st_size,
        )
        
        config = {
            "name": "No Match Rule",
            "pattern": "nonexistent",
        }
        rule = HtmlRule(config)
        result = rule.match(fileinfo)
        
        assert result is None

    def test_find_all_matches(self, tmp_path: Path) -> None:
        """测试查找所有匹配."""
        html_content = """<!DOCTYPE html>
<html>
<body>
    <p>First secret: abc123</p>
    <p>Second secret: def456</p>
    <p>Third secret: ghi789</p>
</body>
</html>
"""
        html_file = tmp_path / "multi.html"
        html_file.write_text(html_content, encoding="utf-8")
        
        fileinfo = FileInfo(
            file_path=str(html_file),
            root_path=str(tmp_path),
            file_type=".html",
            file_size=html_file.stat().st_size,
        )
        
        rule = HtmlRule({"name": "Test", "pattern": "secret"})
        matches = rule.find_all_matches(fileinfo)
        
        assert len(matches) == 3

    def test_html_entities(self, tmp_path: Path) -> None:
        """测试 HTML 实体解码."""
        html_content = """<!DOCTYPE html>
<html>
<body>
    <p>Test &amp; entities: &lt;secret&gt;</p>
</body>
</html>
"""
        html_file = tmp_path / "entities.html"
        html_file.write_text(html_content, encoding="utf-8")
        
        fileinfo = FileInfo(
            file_path=str(html_file),
            root_path=str(tmp_path),
            file_type=".html",
            file_size=html_file.stat().st_size,
        )
        
        rule = HtmlRule({"name": "Test", "pattern": "secret"})
        content = rule.parse_content(fileinfo)
        
        assert "&amp;" not in content
        assert "&lt;" not in content
        assert "secret" in content

    def test_nonexistent_file(self, tmp_path: Path) -> None:
        """测试不存在的文件."""
        rule = HtmlRule({"name": "Test", "pattern": "secret"})
        fileinfo = FileInfo(
            file_path=str(tmp_path / "nonexistent.html"),
            root_path=str(tmp_path),
            file_type=".html",
            file_size=0,
        )
        
        content = rule.parse_content(fileinfo)
        assert content == ""
        
        matches = rule.find_all_matches(fileinfo)
        assert len(matches) == 0

    def test_empty_html_file(self, tmp_path: Path) -> None:
        """测试空 HTML 文件."""
        html_file = tmp_path / "empty.html"
        html_file.touch()
        
        fileinfo = FileInfo(
            file_path=str(html_file),
            root_path=str(tmp_path),
            file_type=".html",
            file_size=0,
        )
        
        rule = HtmlRule({"name": "Test", "pattern": "secret"})
        content = rule.parse_content(fileinfo)
        assert content == ""
