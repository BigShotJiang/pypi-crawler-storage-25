"""文件扫描器 widgets 模块."""
