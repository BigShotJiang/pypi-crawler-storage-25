"""文件扫描器模块 - 支持简单搜索和规则扫描.

重构说明:
- 简化状态管理逻辑
- 优化提示信息显示
- 统一错误处理
- 提高代码可读性
"""

from __future__ import annotations

from bitool.gui import load_qrc, setup_highdpi_scaling
from bitool.gui.compat import QApplication

from .widgets.filescanner import FileScanner

load_qrc()


def main() -> int:
    """运行文件扫描器."""
    app = QApplication([])

    setup_highdpi_scaling()

    window = FileScanner()
    window.setWindowTitle("文件扫描器 - 支持规则匹配")
    window.show()

    return app.exec_()


if __name__ == "__main__":
    main()
