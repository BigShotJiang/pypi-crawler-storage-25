"""图像转 PDF 的图形用户界面."""

from __future__ import annotations

import sys

from bitool.gui.compat import QApplication

from .widgets.img2pdf import Img2PdfConverter

__version__ = "0.1.0"


def main() -> None:
    """运行 img2pdf GUI 应用程序的主入口点."""
    app = QApplication(sys.argv)
    app.setApplicationName("图像转 PDF 转换器")

    window = Img2PdfConverter()
    window.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
