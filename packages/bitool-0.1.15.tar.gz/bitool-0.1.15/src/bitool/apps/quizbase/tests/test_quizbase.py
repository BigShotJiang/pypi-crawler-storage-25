"""quizbase 模块的测试。"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from ..cli import (
    EssayQuestion,
    FillBlankQuestion,
    MultipleChoiceQuestion,
    Question,
    QuestionType,
    QuizResult,
    QuizSession,
    TrueFalseQuestion,
    create_sample_quiz_data,
)


@pytest.fixture
def sample_quiz_json(tmp_path: Path) -> Path:
    """创建示例答题 JSON 文件。"""
    quiz_file = tmp_path / "quiz.json"
    quiz_data = {
        "questions": [
            {
                "question_id": "mc1",
                "question_type": "multiple_choice",
                "question_text": "2+2 等于多少?",
                "options": ["3", "4", "5", "6"],
                "correct_answer": 1,
                "allow_multiple": False,
                "points": 1.0,
            },
            {
                "question_id": "mc2",
                "question_type": "multiple_choice",
                "question_text": "选择素数",
                "options": ["2", "4", "5", "6"],
                "correct_answer": [0, 2],
                "allow_multiple": True,
                "points": 2.0,
            },
            {
                "question_id": "fb1",
                "question_type": "fill_blank",
                "question_text": "法国的首都是 _____。",
                "correct_answers": ["Paris"],
                "case_sensitive": False,
                "points": 1.0,
            },
            {
                "question_id": "tf1",
                "question_type": "true_false",
                "question_text": "Python 是一种编译型语言。",
                "correct_answer": False,
                "points": 1.0,
            },
            {
                "question_id": "es1",
                "question_type": "essay",
                "question_text": "解释面向对象编程。",
                "model_answer": "面向对象编程...",
                "keywords": ["objects", "classes", "inheritance"],
                "points": 5.0,
            },
        ],
    }
    with Path(quiz_file).open("w", encoding="utf-8") as f:
        json.dump(quiz_data, f)
    return quiz_file


class TestMultipleChoiceQuestion:
    """MultipleChoiceQuestion 的测试。"""

    def test_single_correct_answer(self) -> None:
        """测试检查单个正确答案。"""
        question = MultipleChoiceQuestion(
            question_id="mc1",
            question_type=QuestionType.MULTIPLE_CHOICE,
            question_text="2+2 等于多少?",
            options=["3", "4", "5", "6"],
            correct_answer=1,
            allow_multiple=False,
        )

        is_correct, explanation = question.check_answer(1)
        assert is_correct, f"期望 is_correct 为 True, 实际为 {is_correct}"
        assert "正确" in explanation, f"期望 '正确' 在解释中, 实际为 '{explanation}'"

        is_correct, explanation = question.check_answer(0)
        assert not is_correct, f"期望 is_correct 为 False, 实际为 {is_correct}"
        assert "错误" in explanation, f"期望 '错误' 在解释中, 实际为 '{explanation}'"
        assert "4" in explanation, f"期望 '4' 在解释中, 实际为 '{explanation}'"

    def test_multiple_correct_answers(self) -> None:
        """测试检查多个正确答案。"""
        question = MultipleChoiceQuestion(
            question_id="mc2",
            question_type=QuestionType.MULTIPLE_CHOICE,
            question_text="选择素数",
            options=["2", "4", "5", "6"],
            correct_answer=[0, 2],
            allow_multiple=True,
        )

        is_correct, explanation = question.check_answer([0, 2])
        assert is_correct, f"期望 is_correct 为 True, 实际为 {is_correct}"
        assert "正确" in explanation, f"期望 '正确' 在解释中, 实际为 '{explanation}'"

        is_correct, explanation = question.check_answer([0])
        assert not is_correct, f"期望 is_correct 为 False, 实际为 {is_correct}"

    def test_to_dict(self) -> None:
        """测试将题目转换为字典。"""
        question = MultipleChoiceQuestion(
            question_id="mc1",
            question_type=QuestionType.MULTIPLE_CHOICE,
            question_text="2+2 等于多少?",
            options=["3", "4", "5", "6"],
            correct_answer=1,
            allow_multiple=False,
        )

        data = question.to_dict()
        assert data["question_id"] == "mc1", f"期望 question_id 'mc1', 实际为 '{data['question_id']}'"
        assert data["question_type"] == "multiple_choice", (
            f"期望 question_type 'multiple_choice', 实际为 '{data['question_type']}'"
        )
        assert data["options"] == ["3", "4", "5", "6"], f"期望 options ['3', '4', '5', '6'], 实际为 {data['options']}"
        assert data["correct_answer"] == 1, f"期望 correct_answer 1, 实际为 {data['correct_answer']}"

    def test_from_dict(self) -> None:
        """测试从字典创建题目。"""
        data = {
            "question_id": "mc1",
            "question_type": "multiple_choice",
            "question_text": "2+2 等于多少?",
            "options": ["3", "4", "5", "6"],
            "correct_answer": 1,
            "allow_multiple": False,
            "points": 1.0,
        }

        question = MultipleChoiceQuestion.from_dict(data)
        assert question.question_id == "mc1", f"期望 question_id 'mc1', 实际为 '{question.question_id}'"
        assert question.correct_answer == 1, f"期望 correct_answer 1, 实际为 {question.correct_answer}"
        assert question.points == pytest.approx(1.0), f"期望 points 1.0, 实际为 {question.points}"


class TestFillBlankQuestion:
    """FillBlankQuestion 的测试。"""

    def test_case_insensitive_answer(self) -> None:
        """测试不区分大小写的答案检查。"""
        question = FillBlankQuestion(
            question_id="fb1",
            question_type=QuestionType.FILL_BLANK,
            question_text="法国的首都是 _____。",
            correct_answers=["Paris"],
            case_sensitive=False,
        )

        is_correct, _ = question.check_answer("Paris")
        assert is_correct, f"期望答案 'Paris' 的 is_correct 为 True, 实际为 {is_correct}"

        is_correct, _ = question.check_answer("paris")
        assert is_correct, f"期望答案 'paris' 的 is_correct 为 True, 实际为 {is_correct}"

        is_correct, _ = question.check_answer("PARIS")
        assert is_correct, f"期望答案 'PARIS' 的 is_correct 为 True, 实际为 {is_correct}"

    def test_case_sensitive_answer(self) -> None:
        """测试区分大小写的答案检查。"""
        question = FillBlankQuestion(
            question_id="fb1",
            question_type=QuestionType.FILL_BLANK,
            question_text="法国的首都是 _____。",
            correct_answers=["Paris"],
            case_sensitive=True,
        )

        is_correct, _ = question.check_answer("Paris")
        assert is_correct, f"期望答案 'Paris' 的 is_correct 为 True, 实际为 {is_correct}"

        is_correct, _ = question.check_answer("paris")
        assert not is_correct, f"期望答案 'paris' 的 is_correct 为 False, 实际为 {is_correct}"

    def test_multiple_valid_answers(self) -> None:
        """测试多个有效答案的检查。"""
        question = FillBlankQuestion(
            question_id="fb1",
            question_type=QuestionType.FILL_BLANK,
            question_text="选择颜色",
            correct_answers=["Red", "Blue", "Green"],
            case_sensitive=False,
        )

        is_correct, _ = question.check_answer("red")
        assert is_correct, f"期望答案 'red' 的 is_correct 为 True, 实际为 {is_correct}"

        is_correct, _ = question.check_answer("blue")
        assert is_correct, f"期望答案 'blue' 的 is_correct 为 True, 实际为 {is_correct}"

    def test_to_dict_and_from_dict(self) -> None:
        """测试序列化和反序列化。"""
        question = FillBlankQuestion(
            question_id="fb1",
            question_type=QuestionType.FILL_BLANK,
            question_text="法国的首都是 _____。",
            correct_answers=["Paris"],
            case_sensitive=False,
            points=2.0,
        )

        data = question.to_dict()
        assert data["correct_answers"] == ["Paris"], f"期望 correct_answers ['Paris'], 实际为 {data['correct_answers']}"
        assert data["case_sensitive"] is False, f"期望 case_sensitive False, 实际为 {data['case_sensitive']}"

        new_question = FillBlankQuestion.from_dict(data)
        assert new_question.question_id == "fb1", f"期望 question_id 'fb1', 实际为 '{new_question.question_id}'"
        assert new_question.correct_answers == ["Paris"], (
            f"期望 correct_answers ['Paris'], 实际为 {new_question.correct_answers}"
        )


class TestTrueFalseQuestion:
    """TrueFalseQuestion 的测试。"""

    def test_boolean_answer(self) -> None:
        """测试布尔值答案检查。"""
        question = TrueFalseQuestion(
            question_id="tf1",
            question_type=QuestionType.TRUE_FALSE,
            question_text="Python 是一种编译型语言。",
            correct_answer=False,
        )

        is_correct, _ = question.check_answer(answer=False)
        assert is_correct, f"期望答案 False 的 is_correct 为 True, 实际为 {is_correct}"

        is_correct, _ = question.check_answer(answer=True)
        assert not is_correct, f"期望答案 True 的 is_correct 为 False, 实际为 {is_correct}"

    def test_string_answer(self) -> None:
        """测试字符串答案检查。"""
        question = TrueFalseQuestion(
            question_id="tf1",
            question_type=QuestionType.TRUE_FALSE,
            question_text="Python 是一种编译型语言。",
            correct_answer=False,
        )

        for answer in ["false", "f", "no", "n"]:
            is_correct, _ = question.check_answer(answer=answer)
            assert is_correct, f"期望答案 '{answer}' 的 is_correct 为 True, 实际为 {is_correct}"

        for answer in ["true", "t", "yes", "y"]:
            is_correct, _ = question.check_answer(answer=answer)
            assert not is_correct, f"期望答案 '{answer}' 的 is_correct 为 False, 实际为 {is_correct}"

    def test_invalid_string_answer(self) -> None:
        """测试无效字符串答案。"""
        question = TrueFalseQuestion(
            question_id="tf1",
            question_type=QuestionType.TRUE_FALSE,
            question_text="Python 是一种编译型语言。",
            correct_answer=False,
        )

        is_correct, explanation = question.check_answer(answer="invalid")
        assert not is_correct, f"期望答案 'invalid' 的 is_correct 为 False, 实际为 {is_correct}"
        assert "无效" in explanation, f"期望 '无效' 在解释中, 实际为 '{explanation}'"


class TestEssayQuestion:
    """EssayQuestion 的测试。"""

    def test_keyword_validation(self) -> None:
        """测试基于关键词的验证。"""
        question = EssayQuestion(
            question_id="es1",
            question_type=QuestionType.ESSAY,
            question_text="解释面向对象编程。",
            model_answer="面向对象编程...",
            keywords=["objects", "classes", "inheritance"],
        )

        # 测试匹配所有3个关键词
        is_correct, _ = question.check_answer("OOP uses objects and classes and inheritance.")
        assert is_correct, f"期望 is_correct 为 True, 实际为 {is_correct}"

        # 测试匹配2/3关键词 (66.7% >= 50% 阈值)
        is_correct, _ = question.check_answer("OOP uses objects and classes.")
        assert is_correct, f"期望 is_correct 为 True (3 个关键词中正确 2 个), 实际为 {is_correct}"

        # 测试不匹配关键词
        is_correct, _ = question.check_answer("I don't know.")
        assert not is_correct, f"期望 is_correct 为 False, 实际为 {is_correct}"

    def test_no_keywords(self) -> None:
        """测试没有关键词的问答题。"""
        question = EssayQuestion(
            question_id="es1",
            question_type=QuestionType.ESSAY,
            question_text="解释面向对象编程。",
            model_answer="面向对象编程...",
            keywords=[],
        )

        is_correct, explanation = question.check_answer("一些答案。")
        assert is_correct, f"期望没有关键词时 is_correct 为 True, 实际为 {is_correct}"
        assert "记录" in explanation, f"期望 '记录' 在解释中, 实际为 '{explanation}'"

    def test_to_dict_and_from_dict(self) -> None:
        """测试序列化和反序列化。"""
        question = EssayQuestion(
            question_id="es1",
            question_type=QuestionType.ESSAY,
            question_text="解释面向对象编程。",
            model_answer="面向对象编程...",
            keywords=["objects", "classes", "inheritance"],
            points=5.0,
        )

        data = question.to_dict()
        assert data["model_answer"] == "面向对象编程...", (
            f"期望 model_answer '面向对象编程...', 实际为 '{data['model_answer']}'"
        )
        assert data["keywords"] == ["objects", "classes", "inheritance"], (
            f"期望 keywords ['objects', 'classes', 'inheritance'], 实际为 {data['keywords']}"
        )

        new_question = EssayQuestion.from_dict(data)
        assert new_question.question_id == "es1", f"期望 question_id 'es1', 实际为 '{new_question.question_id}'"
        assert new_question.keywords == ["objects", "classes", "inheritance"], (
            f"期望 keywords ['objects', 'classes', 'inheritance'], 实际为 {new_question.keywords}"
        )


class TestQuestionFactory:
    """Question 工厂方法的测试。"""

    def test_from_dict_multiple_choice(self) -> None:
        """测试从字典创建 MultipleChoiceQuestion。"""
        data: dict[str, Any] = {
            "question_id": "mc1",
            "question_type": "multiple_choice",
            "question_text": "2+2 等于多少?",
            "options": ["3", "4", "5", "6"],
            "correct_answer": 1,
            "allow_multiple": False,
        }
        question = Question.from_dict(data)
        assert isinstance(question, MultipleChoiceQuestion), (
            f"期望 MultipleChoiceQuestion 实例, 实际为 {type(question)}"
        )

    def test_from_dict_fill_blank(self) -> None:
        """测试从字典创建 FillBlankQuestion。"""
        data: dict[str, Any] = {
            "question_id": "fb1",
            "question_type": "fill_blank",
            "question_text": "法国的首都是 _____。",
            "correct_answers": ["Paris"],
            "case_sensitive": False,
        }
        question = Question.from_dict(data)
        assert isinstance(question, FillBlankQuestion), f"期望 FillBlankQuestion 实例, 实际为 {type(question)}"

    def test_from_dict_true_false(self) -> None:
        """测试从字典创建 TrueFalseQuestion。"""
        data: dict[str, Any] = {
            "question_id": "tf1",
            "question_type": "true_false",
            "question_text": "Python 是一种编译型语言。",
            "correct_answer": False,
        }
        question = Question.from_dict(data)
        assert isinstance(question, TrueFalseQuestion), f"期望 TrueFalseQuestion 实例, 实际为 {type(question)}"

    def test_from_dict_essay(self) -> None:
        """测试从字典创建 EssayQuestion。"""
        data: dict[str, Any] = {
            "question_id": "es1",
            "question_type": "essay",
            "question_text": "解释面向对象编程。",
            "model_answer": "面向对象编程...",
            "keywords": ["objects", "classes"],
        }
        question = Question.from_dict(data)
        assert isinstance(question, EssayQuestion), f"期望 EssayQuestion 实例, 实际为 {type(question)}"


class TestQuizSession:
    """QuizSession 的测试。"""

    def test_load_from_json(self, sample_quiz_json: Path) -> None:
        """测试从 JSON 文件加载题目。"""
        session = QuizSession()
        session.load_from_json(sample_quiz_json)
        assert session.total_questions == 5, f"期望 total_questions 5, 实际为 {session.total_questions}"

    def test_sequential_order(self, sample_quiz_json: Path) -> None:
        """测试顺序题目顺序。"""
        session = QuizSession(random_order=False)
        session.load_from_json(sample_quiz_json)

        first_question = session.get_current_question()
        assert first_question, "期望 first_question 不为 None"
        assert first_question.question_id == "mc1", f"期望 question_id 'mc1', 实际为 '{first_question.question_id}'"

        session.submit_answer(1)

        second_question = session.get_current_question()
        assert second_question, "期望 second_question 不为 None"
        assert second_question.question_id == "mc2", f"期望 question_id 'mc2', 实际为 '{second_question.question_id}'"

    def test_random_order(self, sample_quiz_json: Path) -> None:
        """测试随机题目顺序。"""
        session = QuizSession(random_order=True)
        session.load_from_json(sample_quiz_json)

        question_ids = []
        while not session.is_finished():
            question = session.get_current_question()
            if question:
                question_ids.append(question.question_id)
                session.submit_answer(1 if isinstance(question, MultipleChoiceQuestion) else "test")

        assert len(question_ids) == 5, f"期望 5 个 question_ids, 实际为 {len(question_ids)}"

    def test_submit_answer(self, sample_quiz_json: Path) -> None:
        """测试提交答案。"""
        session = QuizSession()
        session.load_from_json(sample_quiz_json)

        question = session.get_current_question()
        assert isinstance(question, MultipleChoiceQuestion), f"期望 MultipleChoiceQuestion, 实际为 {type(question)}"

        result = session.submit_answer(1)
        assert result is not None, "期望 result 不为 None"
        assert result.is_correct, f"期望 result.is_correct 为 True, 实际为 {result.is_correct}"
        assert result.user_answer == 1, f"期望 user_answer 1, 实际为 {result.user_answer}"

    def test_statistics(self, sample_quiz_json: Path) -> None:
        """测试会话统计计算。"""
        session = QuizSession()
        session.load_from_json(sample_quiz_json)

        while not session.is_finished():
            question = session.get_current_question()
            if question:
                if isinstance(question, MultipleChoiceQuestion):
                    session.submit_answer(1 if not question.allow_multiple else [0])
                elif isinstance(question, FillBlankQuestion):
                    session.submit_answer("Paris")
                elif isinstance(question, TrueFalseQuestion):
                    session.submit_answer(True)
                else:
                    session.submit_answer("一些答案")

        summary = session.get_summary()
        assert summary["total_questions"] == 5, f"期望 total_questions 5, 实际为 {summary['total_questions']}"
        assert summary["answered"] == 5, f"期望 answered 5, 实际为 {summary['answered']}"
        assert summary["correct"] > 0 or summary["wrong"] > 0, (
            f"期望 correct>0 或 wrong>0, 实际 correct={summary['correct']}, wrong={summary['wrong']}"
        )
        assert summary["accuracy"] >= 0.0, f"期望 accuracy >= 0.0, 实际为 {summary['accuracy']}"
        assert summary["accuracy"] <= 100.0, f"期望 accuracy <= 100.0, 实际为 {summary['accuracy']}"

    def test_wrong_answers(self, tmp_path: Path) -> None:
        """测试错题收集和保存。"""
        quiz_file = tmp_path / "quiz.json"
        quiz_data = {
            "questions": [
                {
                    "question_id": "mc1",
                    "question_type": "multiple_choice",
                    "question_text": "2+2 等于多少?",
                    "options": ["3", "4", "5"],
                    "correct_answer": 1,
                    "allow_multiple": False,
                },
            ],
        }
        with Path(quiz_file).open("w", encoding="utf-8") as f:
            json.dump(quiz_data, f)

        session = QuizSession(wrong_answer_file=str(tmp_path / "wrong.json"))
        session.load_from_json(quiz_file)

        session.submit_answer(0)

        wrong_answers = session.get_wrong_answers()
        assert len(wrong_answers) == 1, f"期望 1 个错题, 实际为 {len(wrong_answers)}"
        assert not wrong_answers[0].is_correct, f"期望 is_correct 为 False, 实际为 {wrong_answers[0].is_correct}"

        session.save_wrong_answers()

        wrong_file = tmp_path / "wrong.json"
        assert wrong_file.exists(), f"期望 wrong_file {wrong_file} 存在"

        with Path(wrong_file).open(encoding="utf-8") as f:
            data = json.load(f)
            assert "wrong_answers" in data, f"期望 'wrong_answers' 键在 data 中, 实际为 {data.keys()}"
            assert len(data["wrong_answers"]) == 1, f"期望 data 中有 1 个错题, 实际为 {len(data['wrong_answers'])}"

    def test_reset(self, sample_quiz_json: Path) -> None:
        """测试重置答题会话。"""
        session = QuizSession()
        session.load_from_json(sample_quiz_json)

        session.submit_answer(1)
        assert len(session.results) == 1, f"期望 1 个结果, 实际为 {len(session.results)}"

        session.reset()
        assert len(session.results) == 0, f"期望重置后有 0 个结果, 实际为 {len(session.results)}"
        assert session._current_index == 0, f"期望 _current_index 为 0, 实际为 {session._current_index}"

    def test_get_current_question_after_finish(self, sample_quiz_json: Path) -> None:
        """测试答题完成后获取当前题目。"""
        session = QuizSession()
        session.load_from_json(sample_quiz_json)

        while not session.is_finished():
            question = session.get_current_question()
            if question:
                session.submit_answer(1 if isinstance(question, MultipleChoiceQuestion) else "test")

        question = session.get_current_question()
        assert question is None, f"期望答题完成后 question 为 None, 实际为 {question}"


class TestCreateSampleQuizData:
    """create_sample_quiz_data 函数的测试。"""

    def test_create_sample_quiz(self, tmp_path: Path) -> None:
        """测试创建示例答题数据文件。"""
        output_file = tmp_path / "sample_quiz.json"
        create_sample_quiz_data(output_file)

        assert output_file.exists(), f"期望 output_file {output_file} 存在"

        with Path(output_file).open(encoding="utf-8") as f:
            data = json.load(f)
            assert "title" in data, f"期望 'title' 键在 data 中, 实际为 {data.keys()}"
            assert "questions" in data, f"期望 'questions' 键在 data 中, 实际为 {data.keys()}"
            assert len(data["questions"]) == 7, f"期望 7 个题目, 实际为 {len(data['questions'])}"

            question_types = {q["question_type"] for q in data["questions"]}
            expected_types = {
                "multiple_choice",
                "fill_blank",
                "true_false",
                "essay",
            }
            assert question_types == expected_types, f"期望 question_types {expected_types}, 实际为 {question_types}"


class TestQuizResult:
    """QuizResult 数据类的测试。"""

    def test_to_dict(self) -> None:
        """测试将结果转换为字典。"""
        question = MultipleChoiceQuestion(
            question_id="mc1",
            question_type=QuestionType.MULTIPLE_CHOICE,
            question_text="2+2 等于多少?",
            options=["3", "4", "5", "6"],
            correct_answer=1,
            allow_multiple=False,
        )

        result = QuizResult(question=question, user_answer=1, is_correct=True, explanation="正确!")

        data = result.to_dict()
        assert data["question"]["question_id"] == "mc1", (
            f"期望 question_id 'mc1', 实际为 '{data['question']['question_id']}'"
        )
        assert data["user_answer"] == 1, f"期望 user_answer 1, 实际为 {data['user_answer']}"
        assert data["is_correct"] is True, f"期望 is_correct 为 True, 实际为 {data['is_correct']}"
        assert data["explanation"] == "正确!", f"期望 explanation '正确!', 实际为 '{data['explanation']}'"
