"""quizbase 模块的测试。"""
