"""quizbase_gui 模块的测试。"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from pytest_mock import MockerFixture
from pytestqt.qtbot import QtBot

from ..cli import (
    MultipleChoiceQuestion,
    QuestionType,
)
from ..gui import (
    ConfigManager,
    QuizConfig,
)

try:
    from ..gui import QuestionAnswerWidget, QuizBaseMainWindow

    GUI_AVAILABLE = True
except ImportError:
    GUI_AVAILABLE = False

import importlib.util

PYTEST_QT_AVAILABLE = importlib.util.find_spec("pytestqt") is not None


@pytest.fixture
def sample_quiz_json(tmp_path: Path) -> Path:
    """创建示例答题 JSON 文件。"""
    quiz_file = tmp_path / "quiz.json"
    quiz_data = {
        "questions": [
            {
                "question_id": "mc1",
                "question_type": "multiple_choice",
                "question_text": "2+2 等于多少?",
                "options": ["3", "4", "5", "6"],
                "correct_answer": 1,
                "allow_multiple": False,
                "points": 1.0,
            },
            {
                "question_id": "fb1",
                "question_type": "fill_blank",
                "question_text": "法国的首都是 _____。",
                "correct_answers": ["Paris"],
                "case_sensitive": False,
                "points": 1.0,
            },
        ],
    }
    with Path(quiz_file).open("w", encoding="utf-8") as f:
        json.dump(quiz_data, f)
    return quiz_file


class TestConfigManager:
    """ConfigManager 的测试。"""

    def test_default_config(self, tmp_path: Path) -> None:
        """测试加载默认配置。"""
        config_file = tmp_path / "config.json"
        manager = ConfigManager(config_file)
        config = manager.get_config()

        assert isinstance(config, QuizConfig)
        assert config.window_width == 1000, f"期望 window_width 为 1000, 实际为 {config.window_width}"
        assert config.window_height == 700, f"期望 window_height 为 700, 实际为 {config.window_height}"
        assert config.random_order is False, f"期望 random_order 为 False, 实际为 {config.random_order}"

    def test_save_and_load(self, tmp_path: Path) -> None:
        """测试保存和加载配置。"""
        config_file = tmp_path / "config.json"
        manager = ConfigManager(config_file)

        manager.set("window_width", 1200)
        manager.set("random_order", True)
        manager.save_config()

        manager2 = ConfigManager(config_file)
        config2 = manager2.get_config()

        assert config2.window_width == 1200, f"期望 window_width 为 1200, 实际为 {config2.window_width}"
        assert config2.random_order is True, f"期望 random_order 为 True, 实际为 {config2.random_order}"

    def test_add_recent_file(self, tmp_path: Path) -> None:
        """测试添加最近文件。"""
        config_file = tmp_path / "config.json"
        manager = ConfigManager(config_file)

        manager.add_recent_file("quiz1.json")
        manager.add_recent_file("quiz2.json")
        manager.add_recent_file("quiz1.json")

        config = manager.get_config()
        assert config.recent_files is not None, "期望 recent_files 不为 None"
        assert len(config.recent_files) == 2, f"期望 2 个最近文件, 实际为 {len(config.recent_files)}"
        assert config.recent_files[0] == "quiz1.json", (
            f"期望第一个最近文件为 'quiz1.json', 实际为 {config.recent_files[0]}"
        )
        assert config.recent_files[1] == "quiz2.json", (
            f"期望第二个最近文件为 'quiz2.json', 实际为 {config.recent_files[1]}"
        )

    def test_max_recent_files(self, tmp_path: Path) -> None:
        """测试最近文件数量限制。"""
        config_file = tmp_path / "config.json"
        manager = ConfigManager(config_file)

        for i in range(15):
            manager.add_recent_file(f"quiz{i}.json")

        config = manager.get_config()
        assert config.recent_files is not None, "期望 recent_files 不为 None"
        assert len(config.recent_files) == ConfigManager.MAX_RECENT_ITEMS, (
            f"期望 {ConfigManager.MAX_RECENT_ITEMS} 个最近文件, 实际为 {len(config.recent_files)}"
        )


class TestQuestionAnswerWidget:
    """QuestionAnswerWidget 的测试。"""

    def test_set_multiple_choice_question(self, qtbot: QtBot) -> None:
        """测试设置选择题。"""
        question = MultipleChoiceQuestion(
            question_id="mc1",
            question_type=QuestionType.MULTIPLE_CHOICE,
            question_text="2+2 等于多少?",
            options=["3", "4", "5", "6"],
            correct_answer=1,
            allow_multiple=False,
            points=1.0,
        )

        widget = QuestionAnswerWidget()
        qtbot.addWidget(widget)
        widget.show()
        widget.set_question(question)

        assert widget.question == question, f"期望 question {question}, 实际为 {widget.question}"
        assert widget.current_answer_widget is not None, "期望 current_answer_widget 不为 None"

    def test_get_answer_radio(self, qtbot: QtBot) -> None:
        """测试从单选按钮获取答案。"""
        question = MultipleChoiceQuestion(
            question_id="mc1",
            question_type=QuestionType.MULTIPLE_CHOICE,
            question_text="2+2 等于多少?",
            options=["3", "4", "5", "6"],
            correct_answer=1,
            allow_multiple=False,
            points=1.0,
        )

        widget = QuestionAnswerWidget()
        qtbot.addWidget(widget)
        widget.show()
        widget.set_question(question)

        assert widget.get_answer() is None, f"期望 get_answer() 为 None, 实际为 {widget.get_answer()}"

        widget.radio_buttons[1].setChecked(True)
        qtbot.wait(50)
        assert widget.get_answer() == 1, f"期望 get_answer() 为 1, 实际为 {widget.get_answer()}"

    def test_get_answer_checkbox(self, qtbot: QtBot) -> None:
        """测试从复选框获取答案。"""
        question = MultipleChoiceQuestion(
            question_id="mc1",
            question_type=QuestionType.MULTIPLE_CHOICE,
            question_text="选择素数",
            options=["2", "3", "4", "5"],
            correct_answer=[0, 1, 3],
            allow_multiple=True,
            points=1.0,
        )

        widget = QuestionAnswerWidget()
        qtbot.addWidget(widget)
        widget.show()
        widget.set_question(question)

        widget.checkboxes[0].setChecked(True)
        widget.checkboxes[3].setChecked(True)
        qtbot.wait(50)

        answer = widget.get_answer()
        assert isinstance(answer, list), f"期望 answer 为 list, 实际为 {type(answer)}"
        assert 0 in answer, f"期望 0 在 answer 中, 实际为 {answer}"
        assert 3 in answer, f"期望 3 在 answer 中, 实际为 {answer}"

    def test_clear_answer(self, qtbot: QtBot) -> None:
        """测试清除答案。"""
        question = MultipleChoiceQuestion(
            question_id="mc1",
            question_type=QuestionType.MULTIPLE_CHOICE,
            question_text="2+2 等于多少?",
            options=["3", "4", "5", "6"],
            correct_answer=1,
            allow_multiple=False,
            points=1.0,
        )

        widget = QuestionAnswerWidget()
        qtbot.addWidget(widget)
        widget.show()
        widget.set_question(question)
        widget.radio_buttons[1].setChecked(True)

        qtbot.wait(100)

        widget.clear_answer()

        qtbot.wait(100)

        assert not widget.radio_buttons[1].isChecked(), (
            f"期望 radio_buttons[1] 未选中, 实际为 {widget.radio_buttons[1].isChecked()}"
        )


class TestQuizBaseMainWindow:
    """QuizBaseMainWindow 的测试。"""

    def test_window_creation(self, qtbot: QtBot) -> None:
        """测试创建主窗口。"""
        window = QuizBaseMainWindow()
        qtbot.addWidget(window)

        assert window.windowTitle() == "QuizBase - 通用答题系统", (
            f"期望标题为 'QuizBase - 通用答题系统', 实际为 {window.windowTitle()}"
        )
        assert window.tab_widget.count() == 3, f"期望 3 个标签页, 实际为 {window.tab_widget.count()}"

    def test_load_quiz(self, qtbot: QtBot, sample_quiz_json: Path) -> None:
        """测试加载答题文件。"""
        window = QuizBaseMainWindow()
        qtbot.addWidget(window)

        window._load_quiz(str(sample_quiz_json))

        assert window.session is not None, "期望 session 不为 None"
        assert window.session.total_questions == 2, f"期望 2 道题目, 实际为 {window.session.total_questions}"
        assert window.submit_button.isEnabled(), "期望 submit_button 可用"

    def test_create_sample_quiz(self, qtbot: QtBot, tmp_path: Path, mocker: MockerFixture) -> None:
        """测试创建示例答题。"""
        window = QuizBaseMainWindow()
        qtbot.addWidget(window)

        sample_file = tmp_path / "sample.json"

        mocker.patch(
            "bitool.apps.quizbase.gui.QFileDialog.getSaveFileName",
            return_value=(str(sample_file), ""),
        )

        mocker.patch("bitool.apps.quizbase.gui.QMessageBox.information")

        window._create_sample_quiz()

        assert sample_file.exists()

    def test_submit_answer(self, qtbot: QtBot, sample_quiz_json: Path) -> None:
        """测试提交答案。"""
        window = QuizBaseMainWindow()
        qtbot.addWidget(window)

        window._load_quiz(str(sample_quiz_json))

        answer_widget = window.answer_widget
        if hasattr(answer_widget, "radio_buttons"):
            answer_widget.radio_buttons[1].setChecked(True)

        window._submit_answer()

        assert window.current_result is not None, "期望 current_result 不为 None"
        assert window.session is not None, "期望 session 不为 None"
        assert len(window.session.results) == 1, f"期望 1 个结果, 实际为 {len(window.session.results)}"

    def test_progress_update(self, qtbot: QtBot, sample_quiz_json: Path) -> None:
        """测试进度显示更新。"""
        window = QuizBaseMainWindow()
        qtbot.addWidget(window)

        window._load_quiz(str(sample_quiz_json))

        answer_widget = window.answer_widget
        if hasattr(answer_widget, "radio_buttons"):
            answer_widget.radio_buttons[1].setChecked(True)
        window._submit_answer()

        progress_text = window.progress_label.text()
        assert "进度: 1 / 2" in progress_text, f"期望 '进度: 1 / 2' 在进度文本中, 实际为 '{progress_text}'"

    def test_finish_quiz(self, qtbot: QtBot, sample_quiz_json: Path, mocker: MockerFixture) -> None:
        """测试完成答题。"""
        window = QuizBaseMainWindow()
        qtbot.addWidget(window)

        window._load_quiz(str(sample_quiz_json))

        for _ in range(2):
            answer_widget = window.answer_widget
            if hasattr(answer_widget, "radio_buttons"):
                answer_widget.radio_buttons[1].setChecked(True)
            window._submit_answer()

        mocker.patch("bitool.apps.quizbase.gui.QMessageBox.information")

        window._finish_quiz()

        assert window.session is not None, "期望 session 不为 None"
        summary = window.session.get_summary()
        assert summary["answered"] == 2, f"期望已答 2 道, 实际为 {summary['answered']}"
        assert summary["is_finished"] is True, f"期望 is_finished 为 True, 实际为 {summary['is_finished']}"

    def test_reset_quiz(self, qtbot: QtBot, sample_quiz_json: Path, mocker: MockerFixture) -> None:
        """测试重置答题。"""
        window = QuizBaseMainWindow()
        qtbot.addWidget(window)

        window._load_quiz(str(sample_quiz_json))

        answer_widget = window.answer_widget
        if hasattr(answer_widget, "radio_buttons"):
            answer_widget.radio_buttons[1].setChecked(True)
        window._submit_answer()

        mocker.patch(
            "bitool.apps.quizbase.gui.QMessageBox.question",
            return_value=16384,
        )

        window._reset_quiz()

        assert window.session is not None, "期望 session 不为 None"
        assert len(window.session.results) == 0, f"期望 0 个结果, 实际为 {len(window.session.results)}"
        assert window.current_result is None, f"期望 current_result 为 None, 实际为 {window.current_result}"

    def test_random_order_toggle(self, qtbot: QtBot, sample_quiz_json: Path) -> None:
        """测试随机顺序复选框。"""
        window = QuizBaseMainWindow()
        qtbot.addWidget(window)

        window._load_quiz(str(sample_quiz_json))

        window.random_checkbox.setChecked(True)

        assert window.session is not None, "期望 session 不为 None"
        assert window.session.random_order is True, f"期望 random_order 为 True, 实际为 {window.session.random_order}"
