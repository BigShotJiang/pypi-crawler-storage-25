"""通用答题系统,支持多种题型。"""

from __future__ import annotations

import argparse
import json
import random
from dataclasses import dataclass, field
from enum import Enum
from functools import cached_property
from pathlib import Path
from typing import Any

from bitool.core import logger


class QuestionType(Enum):
    """支持的题目类型。"""

    MULTIPLE_CHOICE = "multiple_choice"
    FILL_BLANK = "fill_blank"
    TRUE_FALSE = "true_false"
    ESSAY = "essay"


@dataclass
class Question:
    """题目基类数据结构。"""

    question_id: str
    question_type: QuestionType
    question_text: str
    points: float = 1.0

    def check_answer(self, answer: object) -> tuple[bool, str]:
        """检查答案是否正确。返回 (is_correct, explanation)。"""
        raise NotImplementedError

    def to_dict(self) -> dict[str, Any]:
        """将题目转换为字典格式。"""
        return {
            "question_id": self.question_id,
            "question_type": self.question_type.value,
            "question_text": self.question_text,
            "points": self.points,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Question:
        """从字典创建题目实例。"""
        qtype = QuestionType(data["question_type"])

        if qtype == QuestionType.MULTIPLE_CHOICE:
            return MultipleChoiceQuestion.from_dict(data)
        if qtype == QuestionType.FILL_BLANK:
            return FillBlankQuestion.from_dict(data)
        if qtype == QuestionType.TRUE_FALSE:
            return TrueFalseQuestion.from_dict(data)
        if qtype == QuestionType.ESSAY:
            return EssayQuestion.from_dict(data)
        msg = f"未知题目类型: {qtype}"
        raise ValueError(msg)


@dataclass
class MultipleChoiceQuestion(Question):
    """带单个或多个答案的选择题。"""

    options: list[str] = field(default_factory=list)
    correct_answer: list[int] | int = field(default_factory=list)
    allow_multiple: bool = False

    def check_answer(self, answer: object) -> tuple[bool, str]:
        """检查所选选项是否与正确答案匹配。"""
        if isinstance(answer, int):
            answer = [answer]

        if not isinstance(answer, list):
            return False, "答案必须是整数或整数列表"

        answer_int = [a if isinstance(a, int) else 0 for a in answer]

        correct = [self.correct_answer] if not isinstance(self.correct_answer, list) else self.correct_answer

        is_correct = sorted(answer_int) == sorted(correct)
        explanation = self._generate_explanation(answer_int, correct)
        return is_correct, explanation

    def _generate_explanation(self, selected: list[int], correct: list[int]) -> str:
        """生成答案解释。"""
        if not self.allow_multiple:
            correct_text = self.options[correct[0]]
            if sorted(selected) == sorted(correct):
                return f"正确！{correct_text} 是正确答案。"
            return f"错误。正确答案是: {correct_text}"

        correct_texts = [self.options[i] for i in correct]
        if sorted(selected) == sorted(correct):
            return f"正确！{', '.join(correct_texts)} 是正确答案。"
        return f"错误。正确答案有: {', '.join(correct_texts)}"

    def to_dict(self) -> dict[str, Any]:
        """转换为字典格式。"""
        base = super().to_dict()
        base.update(
            {
                "options": self.options,
                "correct_answer": self.correct_answer,
                "allow_multiple": self.allow_multiple,
            },
        )
        return base

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MultipleChoiceQuestion:
        """从字典创建实例。"""
        return cls(
            question_id=data["question_id"],
            question_type=QuestionType.MULTIPLE_CHOICE,
            question_text=data["question_text"],
            points=data.get("points", 1.0),
            options=data["options"],
            correct_answer=data["correct_answer"],
            allow_multiple=data.get("allow_multiple", False),
        )


@dataclass
class FillBlankQuestion(Question):
    """填空题。"""

    correct_answers: list[str] = field(default_factory=list)
    case_sensitive: bool = False

    def check_answer(self, answer: object) -> tuple[bool, str]:
        """检查答案是否与任何正确答案匹配。"""
        if not isinstance(answer, str):
            return False, "答案必须是字符串"

        if not self.case_sensitive:
            answer = answer.strip().lower()
            valid_answers = [a.strip().lower() for a in self.correct_answers]
        else:
            answer = answer.strip()
            valid_answers = [a.strip() for a in self.correct_answers]

        is_correct = answer in valid_answers
        if is_correct:
            return True, f"正确！'{answer}' 是正确答案。"
        return False, f"错误。正确答案有: {', '.join(self.correct_answers)}"

    def to_dict(self) -> dict[str, Any]:
        """转换为字典格式。"""
        base = super().to_dict()
        base.update(
            {
                "correct_answers": self.correct_answers,
                "case_sensitive": self.case_sensitive,
            },
        )
        return base

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> FillBlankQuestion:
        """从字典创建实例。"""
        return cls(
            question_id=data["question_id"],
            question_type=QuestionType.FILL_BLANK,
            question_text=data["question_text"],
            points=data.get("points", 1.0),
            correct_answers=data["correct_answers"],
            case_sensitive=data.get("case_sensitive", False),
        )


@dataclass
class TrueFalseQuestion(Question):
    """判断题。"""

    correct_answer: bool = True

    def check_answer(self, answer: object) -> tuple[bool, str]:
        """检查答案是否与正确值匹配。"""
        if isinstance(answer, str):
            answer_lower = answer.strip().lower()
            if answer_lower in {"true", "t", "yes", "y"}:
                answer = True
            elif answer_lower in {"false", "f", "no", "n"}:
                answer = False
            else:
                return False, "输入无效。请输入 True 或 False。"

        is_correct = answer == self.correct_answer
        correct_text = "True" if self.correct_answer else "False"
        if is_correct:
            return True, f"正确！该陈述为 {correct_text}。"
        return False, f"错误。该陈述为 {correct_text}。"

    def to_dict(self) -> dict[str, Any]:
        """转换为字典格式。"""
        base = super().to_dict()
        base.update({"correct_answer": self.correct_answer})
        return base

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TrueFalseQuestion:
        """从字典创建实例。"""
        return cls(
            question_id=data["question_id"],
            question_type=QuestionType.TRUE_FALSE,
            question_text=data["question_text"],
            points=data.get("points", 1.0),
            correct_answer=data["correct_answer"],
        )


@dataclass
class EssayQuestion(Question):
    """需要详细答案的问答题。"""

    model_answer: str = ""
    keywords: list[str] = field(default_factory=list)

    def check_answer(self, answer: object) -> tuple[bool, str]:
        """检查答案是否包含关键点（软验证）。"""
        if not isinstance(answer, str):
            return False, "答案必须是字符串"

        answer_lower = answer.lower()

        if self.keywords:
            matched_keywords = [kw for kw in self.keywords if kw.lower() in answer_lower]
            keyword_count = len(self.keywords)
            matched_count = len(matched_keywords)

            if matched_count >= keyword_count * 0.5:
                return (
                    True,
                    (f"回答不错！您涵盖了 {matched_count}/{keyword_count} 个关键点: {', '.join(matched_keywords)}"),
                )
            return (
                False,
                f"您的答案不完整。建议包含: {', '.join(self.keywords)}",
            )

        return True, "答案已记录。请参考标准答案进行对比。"

    def to_dict(self) -> dict[str, Any]:
        """转换为字典格式。"""
        base = super().to_dict()
        base.update(
            {
                "model_answer": self.model_answer,
                "keywords": self.keywords,
            },
        )
        return base

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> EssayQuestion:
        """从字典创建实例。"""
        return cls(
            question_id=data["question_id"],
            question_type=QuestionType.ESSAY,
            question_text=data["question_text"],
            points=data.get("points", 1.0),
            model_answer=data.get("model_answer", ""),
            keywords=data.get("keywords", []),
        )


@dataclass
class QuizResult:
    """答题结果。"""

    question: Question
    user_answer: Any
    is_correct: bool
    explanation: str

    def to_dict(self) -> dict[str, Any]:
        """将结果转换为字典。"""
        return {
            "question": self.question.to_dict(),
            "user_answer": self.user_answer,
            "is_correct": self.is_correct,
            "explanation": self.explanation,
        }


@dataclass
class QuizSession:
    """管理包含多个题目的答题会话。"""

    questions: list[Question] = field(default_factory=list)
    random_order: bool = False
    wrong_answer_file: str = "wrong_answers.json"
    results: list[QuizResult] = field(default_factory=list)
    _current_index: int = 0
    _shuffled_indices: list[int] = field(default_factory=list)
    adaptive_mode: bool = False

    @cached_property
    def total_questions(self) -> int:
        """获取题目总数。"""
        return len(self.questions)

    @cached_property
    def correct_count(self) -> int:
        """获取正确答案数量。"""
        return sum(1 for r in self.results if r.is_correct)

    @cached_property
    def wrong_count(self) -> int:
        """获取错误答案数量。"""
        return sum(1 for r in self.results if not r.is_correct)

    @cached_property
    def total_points(self) -> float:
        """获取总分。"""
        return sum(q.points for q in self.questions)

    @cached_property
    def earned_points(self) -> float:
        """获取已得分数。"""
        return sum(r.question.points for r in self.results if r.is_correct)

    @cached_property
    def accuracy(self) -> float:
        """计算正确率百分比。"""
        if len(self.results) == 0:
            return 0.0
        return (self.correct_count / len(self.results)) * 100

    def load_from_json(self, json_file: str | Path) -> None:
        """从 JSON 文件加载题目。"""
        with Path(json_file).open(encoding="utf-8") as f:
            data = json.load(f)

        self.questions = [Question.from_dict(q) for q in data.get("questions", [])]
        self._initialize_order()

    def _initialize_order(self) -> None:
        """根据随机设置初始化题目顺序。

        如果启用 random_order 则创建打乱后的索引,
        否则使用顺序排列。在加载题目或重置会话时调用。
        """
        if self.random_order:
            self._shuffled_indices = list(range(self.total_questions))
            random.shuffle(self._shuffled_indices)
        else:
            self._shuffled_indices = list(range(self.total_questions))

    def get_current_question(self) -> Question | None:
        """根据会话进度获取当前题目。

        根据打乱或顺序返回当前索引处的题目。
        如果所有题目都已答完则返回 None。

        返回
        -------
            当前题目对象,如果没有更多题目则返回 None
        """
        if self._current_index >= len(self._shuffled_indices):
            return None
        idx = self._shuffled_indices[self._current_index]
        return self.questions[idx]

    def submit_answer(self, answer: object) -> QuizResult | None:
        """提交当前题目的答案并进入下一题。

        评估答案,记录结果,并进入序列中的下一题。

        参数
        ----------
            answer: 要评估的用户答案

        返回
        -------
            包含评估结果的 QuizResult,如果没有当前题目则返回 None
        """
        question = self.get_current_question()
        if question is None:
            return None

        is_correct, explanation = question.check_answer(answer=answer)
        result = QuizResult(
            question=question,
            user_answer=answer,
            is_correct=is_correct,
            explanation=explanation,
        )
        self.results.append(result)
        self._current_index += 1
        return result

    def is_finished(self) -> bool:
        """检查答题是否完成。"""
        return self._current_index >= len(self._shuffled_indices)

    def get_wrong_answers(self) -> list[QuizResult]:
        """获取所有错误答案。"""
        return [r for r in self.results if not r.is_correct]

    def save_wrong_answers(self, file_path: str | Path | None = None) -> None:
        """将错误答案保存到 JSON 文件。"""
        wrong_answers = self.get_wrong_answers()
        if not wrong_answers:
            return

        output_path = Path(file_path) if file_path else Path(self.wrong_answer_file)
        data = {"wrong_answers": [r.to_dict() for r in wrong_answers]}
        with Path(output_path).open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    def get_summary(self) -> dict[str, Any]:
        """获取答题会话摘要。"""
        return {
            "total_questions": self.total_questions,
            "answered": len(self.results),
            "correct": self.correct_count,
            "wrong": self.wrong_count,
            "total_points": self.total_points,
            "earned_points": self.earned_points,
            "accuracy": self.accuracy,
            "is_finished": self.is_finished(),
        }

    def reset(self, *, random_order: bool | None = None) -> None:
        """重置答题会话。"""
        self._current_index = 0
        self.results = []
        if random_order is not None:
            self.random_order = random_order
        self._initialize_order()


def create_sample_quiz_data(output_file: str | Path) -> None:
    """创建包含所有题目类型的示例答题数据文件。"""
    questions = [
        {
            "question_id": "mc1",
            "question_type": "multiple_choice",
            "question_text": "法国的首都是哪里?",
            "options": ["伦敦", "巴黎", "柏林", "罗马"],
            "correct_answer": 1,
            "allow_multiple": False,
            "points": 1.0,
        },
        {
            "question_id": "mc2",
            "question_type": "multiple_choice",
            "question_text": "以下哪些是编程语言? (可多选)",
            "options": ["Python", "HTML", "Java", "CSS", "JavaScript"],
            "correct_answer": [0, 2, 4],
            "allow_multiple": True,
            "points": 2.0,
        },
        {
            "question_id": "fb1",
            "question_type": "fill_blank",
            "question_text": "离太阳最近的行星是 _____。",
            "correct_answers": ["Mercury"],
            "case_sensitive": False,
            "points": 1.0,
        },
        {
            "question_id": "fb2",
            "question_type": "fill_blank",
            "question_text": "地球上最大的海洋是 _____ 洋。",
            "correct_answers": ["Pacific", "pacific", "PACIFIC"],
            "case_sensitive": False,
            "points": 1.0,
        },
        {
            "question_id": "tf1",
            "question_type": "true_false",
            "question_text": "Python 是一种编译型语言。",
            "correct_answer": False,
            "points": 1.0,
        },
        {
            "question_id": "tf2",
            "question_type": "true_false",
            "question_text": "地球围绕太阳转。",
            "correct_answer": True,
            "points": 1.0,
        },
        {
            "question_id": "es1",
            "question_type": "essay",
            "question_text": "解释面向对象编程的概念。",
            "model_answer": (
                "面向对象编程(OOP)是一种基于对象概念的编程范式,"
                "对象可以包含数据和代码。"
                "四个主要原则是封装、抽象、继承和多态。"
            ),
            "keywords": [
                "objects",
                "classes",
                "inheritance",
                "encapsulation",
                "polymorphism",
                "abstraction",
            ],
            "points": 5.0,
        },
    ]

    data = {"title": "常识问答", "questions": questions}
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with Path(output_path).open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def parse_args() -> argparse.Namespace:
    """解析命令行参数。"""
    parser = argparse.ArgumentParser(description="通用答题系统")
    parser.add_argument("--create-sample", action="store_true", help="创建示例答题数据文件")
    parser.add_argument("--file", type=str, help="要加载的答题 JSON 文件")
    parser.add_argument("--random", action="store_true", help="打乱题目顺序")
    parser.add_argument(
        "--adaptive",
        action="store_true",
        help="基于表现使用自适应题目选择",
    )
    parser.add_argument(
        "--history-file",
        type=str,
        help="加载/保存用户表现历史的文件",
        default="user_performance.json",
    )
    parser.add_argument("--wrong", type=str, help="将错误答案保存到文件")
    return parser.parse_args()


def _process_answer(question: Question, answer: str) -> tuple[object, tuple[bool, str]] | None:
    """处理用户输入并转换为适当的答案类型。

    参数
    ----------
        question: 当前题目对象
        answer: 原始用户输入字符串

    返回
    -------
        如果成功则返回 (转换后的答案, (is_correct, explanation)),
        如果失败则返回 None
    """
    try:
        if isinstance(question, MultipleChoiceQuestion):
            converted = [int(x.strip()) for x in answer.split(",")] if question.allow_multiple else int(answer)
        elif isinstance(question, TrueFalseQuestion):
            converted = answer.strip().lower() in {"true", "t", "yes", "y"}
        else:
            converted = answer

        is_correct, explanation = question.check_answer(converted)
    except (ValueError, IndexError):
        return None
    else:
        return converted, (is_correct, explanation)


def _run_quiz_session(session: QuizSession) -> None:
    """运行主要答题循环。

    参数
    ----------
        session: QuizSession 或 AdaptiveQuizSession 实例
    """
    while not session.is_finished():
        question = session.get_current_question()
        if question is None:
            break

        if isinstance(question, MultipleChoiceQuestion):
            for _i, _option in enumerate(question.options):
                pass

        answer = input("\n您的答案: ")
        processed = _process_answer(question, answer)

        if processed:
            converted_answer, (is_correct, explanation) = processed
            result = QuizResult(
                question=question,
                user_answer=converted_answer,
                is_correct=is_correct,
                explanation=explanation,
            )
            session.results.append(result)
            session._current_index += 1


def _finalize_session(session: QuizSession, args: argparse.Namespace) -> None:
    """答题完成后保存结果并打印摘要。

    参数
    ----------
        session: QuizSession 或 AdaptiveQuizSession 实例
        args: 命令行参数
    """
    if args.adaptive:
        save_method = getattr(session, "save_performance_history", None)
        if callable(save_method):
            save_method()

    session.save_wrong_answers()
    session.get_summary()

    if args.adaptive:
        get_summary_method = getattr(session, "get_progress_summary", None)
        if callable(get_summary_method):
            perf_summary = get_summary_method()
            total_questions = len(perf_summary.get("performance_by_question", {}))
            avg_accuracy = perf_summary.get("average_accuracy", 0)
            logger.info("\n=== 性能统计 ===")
            logger.info(f"总题目数: {total_questions}")
            logger.info(f"平均正确率: {avg_accuracy:.1%}")


def _create_quiz_session(args: argparse.Namespace) -> QuizSession:
    """根据参数创建适当的答题会话。

    参数
    ----------
        args: 命令行参数

    返回
    -------
        QuizSession 或 AdaptiveQuizSession 实例
    """
    if args.adaptive:
        session = AdaptiveQuizSession(random_order=args.random)
        session.history_file = args.history_file
        session.load_performance_history()
    else:
        session = QuizSession(random_order=args.random)

    if args.wrong:
        session.wrong_answer_file = args.wrong

    return session


def main() -> None:
    """命令行界面的入口点。

    Quizbase 工具

    示例
    --------
      quizbase [options] <arguments>
    """
    args = parse_args()

    if args.create_sample:
        sample_file = Path("sample_quiz.json")
        create_sample_quiz_data(sample_file)
        return

    if args.file:
        session = _create_quiz_session(args)
        session.load_from_json(args.file)

        _run_quiz_session(session)
        _finalize_session(session, args)


@dataclass
class QuestionPerformance:
    """跟踪单个题目的表现统计。"""

    question_id: str
    correct_count: int = 0
    incorrect_count: int = 0
    total_attempts: int = 0

    def get_success_rate(self) -> float:
        """获取成功率 (0.0 到 1.0)。"""
        if self.total_attempts == 0:
            return 0.5
        return self.correct_count / self.total_attempts

    def get_weight(self) -> float:
        """计算自适应选择的权重。

        表现好的题目权重较低,表现差的题目权重较高。
        """
        success_rate = self.get_success_rate()
        return (1.0 - success_rate) + 0.1


@dataclass
class AdaptiveQuizSession(QuizSession):
    """基于用户表现的自适应题目选择答题会话。"""

    performance_history: dict[str, QuestionPerformance] = field(default_factory=dict)
    history_file: str = "user_performance.json"
    adaptive_mode: bool = True

    def __post_init__(self) -> None:
        """在数据类字段设置后初始化。"""
        if not self.performance_history:
            self.performance_history = {}

    def load_performance_history(self, file_path: str | Path | None = None) -> None:
        """从文件加载用户表现历史。"""
        path = Path(file_path) if file_path else Path(self.history_file)

        if path.exists():
            try:
                with Path(path).open(encoding="utf-8") as f:
                    data = json.load(f)

                for qid, perf_data in data.items():
                    self.performance_history[qid] = QuestionPerformance(
                        question_id=qid,
                        correct_count=perf_data.get("correct_count", 0),
                        incorrect_count=perf_data.get("incorrect_count", 0),
                        total_attempts=perf_data.get("total_attempts", 0),
                    )
            except (json.JSONDecodeError, KeyError):
                self.performance_history = {}
        else:
            self.performance_history = {}

    def save_performance_history(self, file_path: str | Path | None = None) -> None:
        """将用户表现历史保存到文件。"""
        path = Path(file_path) if file_path else Path(self.history_file)

        data = {}
        for qid, perf in self.performance_history.items():
            data[qid] = {
                "correct_count": perf.correct_count,
                "incorrect_count": perf.incorrect_count,
                "total_attempts": perf.total_attempts,
            }

        with Path(path).open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    def update_performance(self, question: Question, *, is_correct: bool = False) -> None:
        """更新题目的表现统计。"""
        qid = question.question_id

        if qid not in self.performance_history:
            self.performance_history[qid] = QuestionPerformance(question_id=qid)

        perf = self.performance_history[qid]
        perf.total_attempts += 1

        if is_correct:
            perf.correct_count += 1
        else:
            perf.incorrect_count += 1

    def get_adaptive_question_indices(self) -> list[int]:
        """获取基于表现的自适应加权题目索引。"""
        if not self.questions:
            return []

        all_have_data = all(q.question_id in self.performance_history for q in self.questions)

        if not all_have_data:
            indices = list(range(len(self.questions)))
            random.shuffle(indices)
            return indices

        weights = []
        for _, question in enumerate(self.questions):
            perf = self.performance_history.get(question.question_id)
            weight = perf.get_weight() if perf else 0.5
            weights.append(weight)

        total_weight = sum(weights)
        if total_weight == 0:
            probabilities = [1.0 / len(weights)] * len(weights)
        else:
            probabilities = [w / total_weight for w in weights]

        indices = list(range(len(self.questions)))
        adaptive_indices = []
        remaining_indices = indices[:]
        remaining_probs = probabilities[:]

        while remaining_indices:
            total_remaining_prob = sum(remaining_probs)
            if total_remaining_prob == 0:
                selected_idx = random.randint(0, len(remaining_indices) - 1)
            else:
                norm_probs = [p / total_remaining_prob for p in remaining_probs]
                selected_idx = random.choices(range(len(remaining_indices)), weights=norm_probs)[0]

            adaptive_indices.append(remaining_indices.pop(selected_idx))
            remaining_probs.pop(selected_idx)

        return adaptive_indices

    def submit_answer(self, answer: object) -> QuizResult | None:
        """提交答案并更新表现跟踪。"""
        question = self.get_current_question()
        if question is None:
            return None

        is_correct, explanation = question.check_answer(answer)
        result = QuizResult(
            question=question,
            user_answer=answer,
            is_correct=is_correct,
            explanation=explanation,
        )

        self.update_performance(question, is_correct=is_correct)

        self.results.append(result)
        self._current_index += 1
        return result

    def reset(self, *, random_order: bool | None = None) -> None:
        """重置答题会话同时保留表现历史。"""
        self._current_index = 0
        self.results = []

        if random_order is not None:
            self.random_order = random_order

        self._initialize_order()

    def _initialize_order(self) -> None:
        """根据设置和表现初始化题目顺序。"""
        if self.adaptive_mode and self.random_order:
            self._shuffled_indices = self.get_adaptive_question_indices()
        elif self.random_order:
            self._shuffled_indices = list(range(self.total_questions))
            random.shuffle(self._shuffled_indices)
        else:
            self._shuffled_indices = list(range(self.total_questions))

    def get_progress_summary(self) -> dict[str, Any]:
        """获取所有题目的详细进度摘要。"""
        summary = {
            "total_questions": self.total_questions,
            "answered_questions": len(self.results),
            "performance_by_question": {},
            "overall_accuracy": self.accuracy,
        }

        for question in self.questions:
            perf = self.performance_history.get(question.question_id)
            if perf:
                summary["performance_by_question"][question.question_id] = {
                    "question_text": question.question_text,
                    "correct_count": perf.correct_count,
                    "incorrect_count": perf.incorrect_count,
                    "total_attempts": perf.total_attempts,
                    "success_rate": perf.get_success_rate(),
                    "weight_for_selection": perf.get_weight(),
                }
            else:
                summary["performance_by_question"][question.question_id] = {
                    "question_text": question.question_text,
                    "correct_count": 0,
                    "incorrect_count": 0,
                    "total_attempts": 0,
                    "success_rate": 0.0,
                    "weight_for_selection": 0.5,
                }

        return summary


if __name__ == "__main__":
    main()
