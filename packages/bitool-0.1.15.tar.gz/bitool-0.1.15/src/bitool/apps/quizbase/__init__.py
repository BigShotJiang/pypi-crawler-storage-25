"""Quizbase 模块."""
