"""Quizbase 应用的 PySide2 GUI 版本。"""

from __future__ import annotations

import json
import sys
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import ClassVar

from bitool.core import logger
from bitool.gui.compat import (
    QAbstractItemView,
    QApplication,
    QButtonGroup,
    QCheckBox,
    QCloseEvent,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QRadioButton,
    QScrollArea,
    Qt,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from .cli import (
    AdaptiveQuizSession,
    EssayQuestion,
    FillBlankQuestion,
    MultipleChoiceQuestion,
    Question,
    QuizResult,
    QuizSession,
    TrueFalseQuestion,
    create_sample_quiz_data,
)

_WRONG_ANSWERS_FILE = Path.home() / ".pytola" / "wrong_answers.json"


@dataclass
class QuizConfig:
    """带持久化支持的答题 GUI 配置。"""

    window_width: int = 1000
    window_height: int = 700
    window_x: int = 100
    window_y: int = 100
    random_order: bool = False
    wrong_answers_file: str = str(_WRONG_ANSWERS_FILE)
    recent_files: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        """创建后初始化配置。"""
        if self.recent_files is None:
            self.recent_files = []


class ConfigManager:
    """使用数据类模式管理 GUI 配置持久化。"""

    MAX_RECENT_ITEMS: ClassVar[int] = 10
    DEFAULT_CONFIG: ClassVar[QuizConfig] = QuizConfig()

    def __init__(self, config_file: Path | None = None) -> None:
        """初始化配置管理器。"""
        if config_file is None:
            config_dir = Path.home() / ".pytola"
            config_dir.mkdir(exist_ok=True)
            config_file = config_dir / "quizbase_gui.json"
        self.config_file = config_file
        self.config = self._load_config()

    def _load_config(self) -> QuizConfig:
        """从文件加载配置。"""
        if self.config_file.exists():
            try:
                with Path(self.config_file).open(encoding="utf-8") as f:
                    config_data = json.load(f)
                return QuizConfig(
                    window_width=config_data.get(
                        "window_width",
                        self.DEFAULT_CONFIG.window_width,
                    ),
                    window_height=config_data.get(
                        "window_height",
                        self.DEFAULT_CONFIG.window_height,
                    ),
                    window_x=config_data.get("window_x", self.DEFAULT_CONFIG.window_x),
                    window_y=config_data.get("window_y", self.DEFAULT_CONFIG.window_y),
                    random_order=config_data.get(
                        "random_order",
                        self.DEFAULT_CONFIG.random_order,
                    ),
                    wrong_answers_file=config_data.get(
                        "wrong_answers_file",
                        self.DEFAULT_CONFIG.wrong_answers_file,
                    ),
                    recent_files=config_data.get(
                        "recent_files",
                        self.DEFAULT_CONFIG.recent_files.copy(),
                    ),
                )
            except (OSError, json.JSONDecodeError) as e:
                logger.warning(f"加载配置失败: {e}。使用默认值。")
        return QuizConfig()

    def save_config(self) -> None:
        """保存配置到文件。"""
        try:
            config_dict = {
                "window_width": self.config.window_width,
                "window_height": self.config.window_height,
                "window_x": self.config.window_x,
                "window_y": self.config.window_y,
                "random_order": self.config.random_order,
                "wrong_answers_file": self.config.wrong_answers_file,
                "recent_files": self.config.recent_files,
            }
            with Path(self.config_file).open("w", encoding="utf-8") as f:
                json.dump(config_dict, f, indent=2, ensure_ascii=False)
        except OSError as e:
            logger.warning(f"保存配置失败: {e}")

    def get(self, key: str, default: object = None) -> object:
        """获取配置值。"""
        return getattr(self.config, key, default)

    def set(self, key: str, value: object) -> None:
        """设置配置值。"""
        if hasattr(self.config, key):
            setattr(self.config, key, value)

    def add_recent_file(self, file_path: str) -> None:
        """添加文件到最近文件列表。"""
        recent_files = self.config.recent_files.copy()
        recent_files = [f for f in recent_files if f != file_path]
        recent_files.insert(0, file_path)
        recent_files = recent_files[: self.MAX_RECENT_ITEMS]
        self.config.recent_files = recent_files

    def get_config(self) -> QuizConfig:
        """获取配置为 QuizConfig 数据类。"""
        return self.config


class QuestionAnswerWidget(QWidget):
    """根据题目类型创建答题小部件。"""

    QUESTION_ATTRIBUTES: ClassVar[dict[str, list[str]]] = {
        "multiple_choice": ["radio_buttons", "checkboxes", "radio_button_group"],
        "fill_blank": ["text_input"],
        "true_false": ["true_radio", "false_radio"],
        "essay": ["text_edit"],
    }

    def __init__(self, parent: QWidget | None = None) -> None:
        """初始化答题小部件。"""
        super().__init__(parent)
        self.question: Question | None = None
        self._main_layout = QVBoxLayout(self)
        self.current_answer_widget: QWidget | None = None

    def _cleanup_question_attributes(self) -> None:
        """清理上一个题目类型的属性。"""
        attrs_to_remove = [attr for attrs in self.QUESTION_ATTRIBUTES.values() for attr in attrs]
        for attr in attrs_to_remove:
            if hasattr(self, attr):
                delattr(self, attr)

    def _create_answer_widget(self, question: Question) -> QWidget:
        """根据题目类型创建适当的答题小部件。"""
        widget_map: dict[type, Callable[..., QWidget]] = {
            MultipleChoiceQuestion: self._create_multiple_choice_widget,
            FillBlankQuestion: self._create_fill_blank_widget,
            TrueFalseQuestion: self._create_true_false_widget,
            EssayQuestion: self._create_essay_widget,
        }

        for question_type, creator_func in widget_map.items():
            if isinstance(question, question_type):
                return creator_func(question)

        return QLabel("未知题目类型")

    def set_question(self, question: Question) -> None:
        """设置题目并创建适当的答题小部件。"""
        self.question = question

        if self.current_answer_widget:
            self._main_layout.removeWidget(self.current_answer_widget)
            self.current_answer_widget.deleteLater()
            self.current_answer_widget = None

        self._cleanup_question_attributes()

        widget = self._create_answer_widget(question)

        self.current_answer_widget = widget
        self._main_layout.addWidget(widget)

    def _create_multiple_choice_widget(
        self,
        question: MultipleChoiceQuestion,
    ) -> QWidget:
        """为选择题创建小部件。"""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        if question.allow_multiple:
            self.checkboxes: list[QCheckBox] = []
            for i, option in enumerate(question.options):
                checkbox = QCheckBox(option)
                checkbox.setProperty("option_index", i)
                self.checkboxes.append(checkbox)
                layout.addWidget(checkbox)
        else:
            self.radio_buttons: list[QRadioButton] = []
            self.radio_button_group = QButtonGroup(self)
            for i, option in enumerate(question.options):
                radio = QRadioButton(option)
                radio.setProperty("option_index", i)
                self.radio_buttons.append(radio)
                self.radio_button_group.addButton(
                    radio,
                    i,
                )
                layout.addWidget(radio)

        return widget

    def _create_fill_blank_widget(self, question: FillBlankQuestion) -> QWidget:
        """为填空题创建小部件。"""
        widget = QWidget()
        layout = QHBoxLayout(widget)

        label = QLabel("答案:")
        self.text_input = QLineEdit()
        self.text_input.setPlaceholderText("在此输入答案...")

        layout.addWidget(label)
        layout.addWidget(self.text_input)

        return widget

    def _create_true_false_widget(self, question: TrueFalseQuestion) -> QWidget:
        """为判断题创建小部件。"""
        widget = QWidget()
        layout = QHBoxLayout(widget)

        self.true_radio = QRadioButton("正确")
        self.false_radio = QRadioButton("错误")
        self.true_radio.setProperty("answer", True)
        self.false_radio.setProperty("answer", False)

        layout.addWidget(self.true_radio)
        layout.addWidget(self.false_radio)

        return widget

    def _create_essay_widget(self, question: EssayQuestion) -> QWidget:
        """为问答题创建小部件。"""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        label = QLabel("您的答案:")
        label.setStyleSheet("font-weight: bold; margin-top: 10px;")

        self.text_edit = QTextEdit()
        self.text_edit.setPlaceholderText("在此输入您的答案...")
        self.text_edit.setMinimumHeight(200)

        if question.keywords:
            hint = QLabel(f"需要涵盖的要点: {', '.join(question.keywords)}")
            hint.setStyleSheet("color: gray; font-style: italic; margin-bottom: 5px;")
            layout.addWidget(hint)

        layout.addWidget(label)
        layout.addWidget(self.text_edit)

        return widget

    def get_answer(self) -> object:
        """获取用户答案。"""
        if isinstance(self.question, MultipleChoiceQuestion):
            if self.question.allow_multiple:
                return [cb.property("option_index") for cb in getattr(self, "checkboxes", []) if cb.isChecked()]
            for radio in getattr(self, "radio_buttons", []):
                if radio.isChecked():
                    return radio.property("option_index")
            return None
        if isinstance(self.question, FillBlankQuestion):
            return getattr(self, "text_input", QLineEdit()).text()
        if isinstance(self.question, TrueFalseQuestion):
            if getattr(self, "true_radio", None) and self.true_radio.isChecked():
                return True
            if getattr(self, "false_radio", None) and self.false_radio.isChecked():
                return False
            return None
        if isinstance(self.question, EssayQuestion):
            return getattr(self, "text_edit", QTextEdit()).toPlainText()
        return None

    def _clear_multiple_choice_answer(self) -> None:
        """清除选择题答案。"""
        if self.question.allow_multiple:
            for cb in getattr(self, "checkboxes", []):
                cb.setChecked(False)
        else:
            self._clear_radio_buttons()

    def _clear_radio_buttons(self) -> None:
        """使用适当的信号处理清除单选按钮选择。"""
        radio_buttons = getattr(self, "radio_buttons", None)
        button_group = getattr(self, "radio_button_group", None)

        if button_group:
            button_group.setExclusive(False)

        if radio_buttons:
            for radio in radio_buttons:
                radio.blockSignals(True)
                radio.setChecked(False)
                radio.blockSignals(False)

        if button_group:
            button_group.setExclusive(True)

        self._process_qt_events()

    def _clear_true_false_answer(self) -> None:
        """清除判断题答案。"""
        if getattr(self, "true_radio", None):
            self.true_radio.blockSignals(True)
            self.true_radio.setChecked(False)
            self.true_radio.blockSignals(False)
        if getattr(self, "false_radio", None):
            self.false_radio.blockSignals(True)
            self.false_radio.setChecked(False)
            self.false_radio.blockSignals(False)
        self._process_qt_events()

    def _clear_fill_blank_answer(self) -> None:
        """清除填空题答案。"""
        getattr(self, "text_input", QLineEdit()).clear()

    def _clear_essay_answer(self) -> None:
        """清除问答题答案。"""
        getattr(self, "text_edit", QTextEdit()).clear()

    def _process_qt_events(self) -> None:
        """处理 Qt 事件以确保 UI 更新。"""
        app = QApplication.instance()
        if app:
            app.processEvents()

    def clear_answer(self) -> None:
        """清除用户答案。"""
        if isinstance(self.question, MultipleChoiceQuestion):
            self._clear_multiple_choice_answer()
        elif isinstance(self.question, FillBlankQuestion):
            self._clear_fill_blank_answer()
        elif isinstance(self.question, TrueFalseQuestion):
            self._clear_true_false_answer()
        elif isinstance(self.question, EssayQuestion):
            self._clear_essay_answer()


class WrongAnswersDialog(QDialog):
    """显示错误答案的对话框。"""

    def __init__(self, results: list[QuizResult], parent: QWidget | None = None) -> None:
        """初始化错误答案对话框。"""
        super().__init__(parent)
        self.results = results
        self.setWindowTitle("错题回顾")
        self.setMinimumSize(800, 600)
        self._setup_ui()

    def _setup_ui(self) -> None:
        """设置对话框 UI。"""
        layout = QVBoxLayout(self)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)

        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)

        for i, result in enumerate(self.results, 1):
            result_group = QGroupBox(f"第 {i} 题")
            result_layout = QVBoxLayout()

            question_label = QLabel(f"<b>题目:</b> {result.question.question_text}")
            question_label.setWordWrap(True)
            result_layout.addWidget(question_label)

            user_answer_label = QLabel(f"<b>您的答案:</b> {result.user_answer}")
            user_answer_label.setWordWrap(True)
            result_layout.addWidget(user_answer_label)

            explanation_label = QLabel(f"<b>解析:</b> {result.explanation}")
            explanation_label.setWordWrap(True)
            explanation_label.setStyleSheet("color: red;")
            result_layout.addWidget(explanation_label)

            result_group.setLayout(result_layout)
            content_layout.addWidget(result_group)

        scroll.setWidget(content_widget)
        layout.addWidget(scroll)

        button_box = QDialogButtonBox(QDialogButtonBox.Close)
        button_box.rejected.connect(self.accept)
        layout.addWidget(button_box)


class QuizBaseMainWindow(QMainWindow):
    """QuizBase GUI 应用的主窗口。"""

    def __init__(self) -> None:
        """初始化主窗口。"""
        super().__init__()
        self.config_manager = ConfigManager()
        self.config = self.config_manager.get_config()
        self.session: QuizSession | None = None
        self.current_result: QuizResult | None = None
        self._setup_ui()
        self._load_settings()

    def _setup_ui(self) -> None:
        """设置用户界面。"""
        self.setWindowTitle("QuizBase - 通用答题系统")
        self.setMinimumSize(900, 700)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QVBoxLayout(central_widget)

        toolbar_layout = QHBoxLayout()

        self.open_button = QPushButton("打开答题文件")
        self.open_button.clicked.connect(self._open_quiz_file)
        toolbar_layout.addWidget(self.open_button)

        self.recent_combo = QComboBox()
        self.recent_combo.setMinimumWidth(300)
        self.recent_combo.currentIndexChanged.connect(self._load_recent_file)
        toolbar_layout.addWidget(self.recent_combo)

        self.random_checkbox = QCheckBox("随机顺序")
        self.random_checkbox.setChecked(self.config.random_order)
        self.random_checkbox.stateChanged.connect(self._on_random_changed)
        toolbar_layout.addWidget(self.random_checkbox)

        self.adaptive_checkbox = QCheckBox("自适应模式")
        self.adaptive_checkbox.setChecked(False)
        self.adaptive_checkbox.stateChanged.connect(self._on_adaptive_changed)
        toolbar_layout.addWidget(self.adaptive_checkbox)

        toolbar_layout.addStretch()

        self.create_sample_button = QPushButton("创建示例")
        self.create_sample_button.clicked.connect(self._create_sample_quiz)
        toolbar_layout.addWidget(self.create_sample_button)

        main_layout.addLayout(toolbar_layout)

        self.tab_widget = QTabWidget()
        main_layout.addWidget(self.tab_widget)

        self.quiz_tab = self._create_quiz_tab()
        self.tab_widget.addTab(self.quiz_tab, "答题")

        self.summary_tab = self._create_summary_tab()
        self.tab_widget.addTab(self.summary_tab, "摘要")

        self.wrong_tab = self._create_wrong_answers_tab()
        self.tab_widget.addTab(self.wrong_tab, "错题")

        self.status_label = QLabel("未加载答题")
        self.statusBar().addWidget(self.status_label)

        self._set_quiz_enabled(enabled=False)

    def _create_quiz_tab(self) -> QWidget:
        """创建答题标签页。"""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        progress_layout = QHBoxLayout()
        self.progress_label = QLabel("进度: - / -")
        progress_layout.addWidget(self.progress_label)
        progress_layout.addStretch()

        self.score_label = QLabel("得分: 0 / 0")
        progress_layout.addWidget(self.score_label)

        layout.addLayout(progress_layout)

        info_group = QGroupBox("题目信息")
        info_layout = QFormLayout()

        self.question_type_label = QLabel("-")
        self.question_points_label = QLabel("-")

        info_layout.addRow("类型:", self.question_type_label)
        info_layout.addRow("分值:", self.question_points_label)
        info_group.setLayout(info_layout)
        layout.addWidget(info_group)

        question_group = QGroupBox("题目")
        question_layout = QVBoxLayout()
        self.question_text_label = QLabel("未加载题目")
        self.question_text_label.setWordWrap(True)
        self.question_text_label.setStyleSheet(
            "font-size: 14px; font-weight: bold; margin: 10px;",
        )
        question_layout.addWidget(self.question_text_label)
        question_group.setLayout(question_layout)
        layout.addWidget(question_group)

        answer_group = QGroupBox("您的答案")
        answer_layout = QVBoxLayout()
        self.answer_widget = QuestionAnswerWidget()
        answer_layout.addWidget(self.answer_widget)
        answer_group.setLayout(answer_layout)
        layout.addWidget(answer_group)

        self.result_label = QLabel()
        self.result_label.setWordWrap(True)
        self.result_label.setStyleSheet("padding: 10px; margin: 10px;")
        layout.addWidget(self.result_label)

        button_layout = QHBoxLayout()

        self.submit_button = QPushButton("提交答案")
        self.submit_button.setEnabled(False)
        self.submit_button.clicked.connect(self._submit_answer)
        button_layout.addWidget(self.submit_button)

        self.next_button = QPushButton("下一题")
        self.next_button.setEnabled(False)
        self.next_button.clicked.connect(self._next_question)
        button_layout.addWidget(self.next_button)

        self.finish_button = QPushButton("完成答题")
        self.finish_button.setEnabled(False)
        self.finish_button.clicked.connect(self._finish_quiz)
        button_layout.addWidget(self.finish_button)

        self.reset_button = QPushButton("重新开始")
        self.reset_button.setEnabled(False)
        self.reset_button.clicked.connect(self._reset_quiz)
        button_layout.addWidget(self.reset_button)

        layout.addLayout(button_layout)

        return widget

    def _create_summary_tab(self) -> QWidget:
        """创建摘要标签页。"""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        self.summary_text = QTextEdit()
        self.summary_text.setReadOnly(True)
        self.summary_text.setPlainText("答题摘要将显示在此...")
        layout.addWidget(self.summary_text)

        return widget

    def _create_wrong_answers_tab(self) -> QWidget:
        """创建错题标签页。"""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        instruction = QLabel(
            "答题完成后错题将显示在此。",
        )
        layout.addWidget(instruction)

        self.wrong_answers_list = QListWidget()
        self.wrong_answers_list.setSelectionMode(QAbstractItemView.SingleSelection)
        layout.addWidget(self.wrong_answers_list)

        self.view_detail_button = QPushButton("查看详情")
        self.view_detail_button.setEnabled(False)
        self.view_detail_button.clicked.connect(self._view_wrong_answer_detail)
        layout.addWidget(self.view_detail_button)

        return widget

    def _set_quiz_enabled(self, *, enabled: bool) -> bool:
        """启用或禁用答题相关控件。"""
        self.submit_button.setEnabled(enabled)
        self.next_button.setEnabled(enabled)
        self.finish_button.setEnabled(enabled)
        self.reset_button.setEnabled(enabled)
        return enabled

    def _load_settings(self) -> None:
        """加载窗口设置。"""
        self.resize(self.config.window_width, self.config.window_height)
        self.move(self.config.window_x, self.config.window_y)
        self._update_recent_files()

    def _save_settings(self) -> None:
        """保存窗口设置。"""
        self.config_manager.set("window_width", self.width())
        self.config_manager.set("window_height", self.height())
        self.config_manager.set("window_x", self.x())
        self.config_manager.set("window_y", self.y())
        self.config_manager.set("random_order", self.random_checkbox.isChecked())
        self.config_manager.save_config()

    def _update_recent_files(self) -> None:
        """更新最近文件下拉列表。"""
        self.recent_combo.clear()
        self.recent_combo.addItem("-- 最近文件 --", None)
        for file_path in self.config.recent_files or []:
            self.recent_combo.addItem(Path(file_path).name, file_path)

    def _open_quiz_file(self) -> None:
        """打开答题文件对话框。"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "打开答题文件",
            "",
            "JSON 文件 (*.json);;所有文件 (*)",
        )

        if file_path:
            self._load_quiz(file_path)

    def _load_recent_file(self, index: int) -> None:
        """加载最近使用的文件。"""
        if index > 0:
            file_path = self.recent_combo.currentData()
            if file_path:
                self._load_quiz(file_path)
            self.recent_combo.setCurrentIndex(0)

    def _load_quiz(self, file_path: str) -> None:
        """从文件加载答题。"""
        try:
            if self.adaptive_checkbox.isChecked():
                self.session = AdaptiveQuizSession(
                    random_order=self.random_checkbox.isChecked(),
                )
                self.session.load_performance_history()
            else:
                self.session = QuizSession(
                    random_order=self.random_checkbox.isChecked(),
                )

            self.session.load_from_json(file_path)

            self.config_manager.add_recent_file(file_path)
            self._update_recent_files()

            self._set_quiz_enabled(enabled=True)
            self.status_label.setText(f"已加载答题: {Path(file_path).name}")
            self.tab_widget.setCurrentIndex(0)

            self._load_current_question()
            self._update_summary()

        except (OSError, json.JSONDecodeError, ValueError) as e:
            QMessageBox.critical(self, "错误", f"加载答题失败: {e}")

    def _create_sample_quiz(self) -> None:
        """创建示例答题数据。"""
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "保存示例答题",
            "sample_quiz.json",
            "JSON 文件 (*.json)",
        )

        if file_path:
            try:
                create_sample_quiz_data(file_path)
                self._load_quiz(file_path)
                QMessageBox.information(
                    self,
                    "成功",
                    "示例答题创建成功！",
                )
            except (OSError, json.JSONDecodeError, ValueError) as e:
                QMessageBox.critical(
                    self,
                    "错误",
                    f"创建示例答题失败: {e}",
                )

    def _on_random_changed(self, state: int) -> None:
        """处理随机顺序复选框变更。"""
        if self.session and not self.session.results:
            self.session.random_order = state == Qt.Checked
            self.session.reset()

    def _on_adaptive_changed(self, state: int) -> None:
        """处理自适应模式复选框变更。"""
        if self.session and hasattr(self.session, "adaptive_mode") and not self.session.results:
            self.session.adaptive_mode = state == Qt.Checked
            self.session.reset()

    def _load_current_question(self) -> None:
        """加载当前题目到 UI。"""
        if not self.session:
            return

        question = self.session.get_current_question()

        if question is None:
            self._finish_quiz()
            return

        self.question_type_label.setText(question.question_type.value)
        self.question_points_label.setText(str(question.points))
        self.question_text_label.setText(question.question_text)

        self.answer_widget.set_question(question)

        self._update_progress()

        self.result_label.clear()
        self.result_label.setStyleSheet("padding: 10px; margin: 10px;")

        self.submit_button.setEnabled(True)
        self.next_button.setEnabled(False)

    def _update_progress(self) -> None:
        """更新进度显示。"""
        if not self.session:
            return

        summary = self.session.get_summary()
        self.progress_label.setText(
            f"进度: {summary['answered']} / {summary['total_questions']}",
        )
        self.score_label.setText(
            f"得分: {summary['earned_points']:.1f} / {summary['total_points']:.1f}",
        )

    def _submit_answer(self) -> None:
        """提交当前题目的答案。"""
        if not self.session:
            return

        answer = self.answer_widget.get_answer()

        if answer is None:
            QMessageBox.warning(self, "警告", "请提供答案。")
            return

        self.current_result = self.session.submit_answer(answer)

        if self.current_result:
            if self.current_result.is_correct:
                self.result_label.setText(
                    f"✓ 正确！\n{self.current_result.explanation}",
                )
                self.result_label.setStyleSheet(
                    "background-color: #d4edda; color: #155724; padding: 10px; margin: 10px; border-radius: 5px;",
                )
            else:
                self.result_label.setText(
                    f"✗ 错误！\n{self.current_result.explanation}",
                )
                self.result_label.setStyleSheet(
                    "background-color: #f8d7da; color: #721c24; padding: 10px; margin: 10px; border-radius: 5px;",
                )

            self._update_progress()
            self._update_summary()

            self.submit_button.setEnabled(False)
            self.answer_widget.clear_answer()

            if not self.session.is_finished():
                self._load_current_question()
            else:
                self.finish_button.setEnabled(True)
                self.next_button.setEnabled(False)

    def _next_question(self) -> None:
        """加载下一题。"""
        self._load_current_question()

    def _finish_quiz(self) -> None:
        """完成答题并显示摘要。"""
        if not self.session:
            return

        wrong_answers_file = self.config_manager.get(
            "wrong_answers_file",
            str(_WRONG_ANSWERS_FILE),
        )
        if isinstance(wrong_answers_file, str):
            self.session.wrong_answer_file = wrong_answers_file
            self.session.save_wrong_answers()

        self._update_summary()
        self._update_wrong_answers()

        self.tab_widget.setCurrentIndex(1)

        summary = self.session.get_summary()
        message = (
            f"答题完成！\n\n"
            f"总题数: {summary['total_questions']}\n"
            f"正确: {summary['correct']}\n"
            f"错误: {summary['wrong']}\n"
            f"得分: {summary['earned_points']:.1f} / {summary['total_points']:.1f}\n"
            f"正确率: {summary['accuracy']:.1f}%"
        )
        QMessageBox.information(self, "答题完成", message)

        self.status_label.setText("答题完成")

    def _update_summary(self) -> None:
        """更新摘要标签页。"""
        if not self.session:
            return

        summary = self.session.get_summary()

        summary_text = (
            f"答题摘要\n"
            f"{'=' * 50}\n\n"
            f"总题数: {summary['total_questions']}\n"
            f"已答: {summary['answered']}\n"
            f"正确: {summary['correct']}\n"
            f"错误: {summary['wrong']}\n\n"
            f"得分: {summary['earned_points']:.1f} / {summary['total_points']:.1f}\n"
            f"正确率: {summary['accuracy']:.1f}%\n"
            f"状态: {'已完成' if summary['is_finished'] else '进行中'}\n"
        )

        if self.session.results:
            summary_text += f"\n{'=' * 50}\n\n题目详情:\n\n"
            for i, result in enumerate(self.session.results, 1):
                status = "✓" if result.is_correct else "✗"
                summary_text += f"{i}. {status} ({result.question.points} 分)\n"

        self.summary_text.setPlainText(summary_text)

    def _update_wrong_answers(self) -> None:
        """更新错题标签页。"""
        if not self.session:
            return

        self.wrong_answers_list.clear()

        wrong_results = self.session.get_wrong_answers()

        if not wrong_results:
            self.wrong_answers_list.addItem("没有错题！做得好！")
            self.view_detail_button.setEnabled(False)
            return

        for i, result in enumerate(wrong_results, 1):
            self.wrong_answers_list.addItem(
                f"{i}. {result.question.question_text[:50]}...",
            )

        self.wrong_answers = wrong_results
        self.view_detail_button.setEnabled(True)

    def _view_wrong_answer_detail(self) -> None:
        """查看所选错题的详情。"""
        if not hasattr(self, "wrong_answers") or not self.wrong_answers:
            return

        selected = self.wrong_answers_list.currentRow()
        if selected < 0 or selected >= len(self.wrong_answers):
            return

        result = self.wrong_answers[selected]
        dialog = WrongAnswersDialog([result], self)
        dialog.exec_()

    def _reset_quiz(self) -> None:
        """重置答题到开始。"""
        if not self.session:
            return

        reply = QMessageBox.question(
            self,
            "重新开始",
            "确定要重新开始此答题吗？所有进度将丢失。",
            QMessageBox.Yes | QMessageBox.No,
        )

        if reply == QMessageBox.Yes:
            self.session.reset(random_order=self.random_checkbox.isChecked())
            self.current_result = None
            self._load_current_question()
            self._update_summary()
            self.tab_widget.setCurrentIndex(0)
            self.status_label.setText("答题已重置")

    def closeEvent(self, event: QCloseEvent) -> None:
        """处理窗口关闭事件。"""
        self._save_settings()
        event.accept()


def main() -> None:
    """GUI 应用的入口点。

    Quizbase GUI 工具
    """
    app = QApplication(sys.argv)
    app.setStyle("Fusion")

    window = QuizBaseMainWindow()
    window.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
