"""resistcalc 核心功能的测试。"""

import numpy as np
import pytest

from bitool.apps.resistcalc.resistcalc import (
    PinGeometry,
    ResistorShape,
    SheetGeometry,
    SimulationParams,
    calculate_circular_resistance,
    calculate_horseshoe_resistance,
    calculate_meander_resistance,
    calculate_oval_resistance,
    calculate_pin_resistance,
    calculate_rectangle_resistance,
    calculate_resistor,
    calculate_sheet_resistance,
    calculate_temperature_rise,
    convert_to_meters,
)


class TestUnitConversions:
    """测试单位转换函数。"""

    def test_convert_mm_to_meters(self):
        assert convert_to_meters(1.0, "mm") == pytest.approx(1e-3)
        assert convert_to_meters(10.0, "mm") == pytest.approx(0.01)
        assert convert_to_meters(100.0, "mm") == pytest.approx(0.1)

    def test_convert_um_to_meters(self):
        assert convert_to_meters(1.0, "um") == pytest.approx(1e-6)
        assert convert_to_meters(100.0, "um") == pytest.approx(1e-4)

    def test_convert_cm_to_meters(self):
        assert convert_to_meters(1.0, "cm") == pytest.approx(1e-2)
        assert convert_to_meters(10.0, "cm") == pytest.approx(0.1)


class TestPinResistance:
    """测试圆柱形引脚电阻计算。"""

    def test_pin_resistance_basic(self):
        pin = PinGeometry(
            diameter=0.5,
            length=2.0,
            resistivity=1.68e-8,
        )
        r = calculate_pin_resistance(pin)
        assert r > 0
        assert r < 1e-3

    def test_pin_resistance_copper(self):
        pin = PinGeometry(
            diameter=1.0,
            length=10.0,
            resistivity=1.68e-8,
        )
        r = calculate_pin_resistance(pin)
        expected = pin.resistivity * (pin.length * 1e-3) / (np.pi * (pin.diameter * 1e-3 / 2) ** 2)
        assert r == pytest.approx(expected)

    def test_longer_pin_has_higher_resistance(self):
        pin_short = PinGeometry(diameter=0.5, length=1.0, resistivity=1e-6)
        pin_long = PinGeometry(diameter=0.5, length=2.0, resistivity=1e-6)
        assert calculate_pin_resistance(pin_long) > calculate_pin_resistance(pin_short)

    def test_thicker_pin_has_lower_resistance(self):
        pin_thin = PinGeometry(diameter=0.3, length=2.0, resistivity=1e-6)
        pin_thick = PinGeometry(diameter=0.6, length=2.0, resistivity=1e-6)
        assert calculate_pin_resistance(pin_thick) < calculate_pin_resistance(pin_thin)


class TestRectangleResistance:
    """测试矩形电阻片电阻计算。"""

    def test_rectangle_basic(self):
        r = calculate_rectangle_resistance(
            width=10.0,
            height=5.0,
            thickness=0.1,
            resistivity=1e-6,
            units="mm",
        )
        assert r > 0
        assert r < 2e-2

    def test_rectangle_length_affects_resistance(self):
        r_short = calculate_rectangle_resistance(5.0, 10.0, 0.1, 1e-6, "mm")
        r_long = calculate_rectangle_resistance(10.0, 10.0, 0.1, 1e-6, "mm")
        assert r_long == pytest.approx(2 * r_short)

    def test_rectangle_thickness_affects_resistance(self):
        r_thick = calculate_rectangle_resistance(10.0, 10.0, 0.2, 1e-6, "mm")
        r_thin = calculate_rectangle_resistance(10.0, 10.0, 0.1, 1e-6, "mm")
        assert r_thin == pytest.approx(2 * r_thick)


class TestCircularResistance:
    """测试环形/圆环电阻计算。"""

    def test_circular_basic(self):
        r = calculate_circular_resistance(
            outer_radius=10.0,
            inner_radius=5.0,
            thickness=0.1,
            resistivity=1e-6,
            units="mm",
        )
        assert r > 0

    def test_circular_larger_radius_difference(self):
        r_small = calculate_circular_resistance(8.0, 5.0, 0.1, 1e-6, "mm")
        r_large = calculate_circular_resistance(12.0, 5.0, 0.1, 1e-6, "mm")
        assert r_large > r_small

    def test_circular_inner_zero(self):
        r = calculate_circular_resistance(
            outer_radius=10.0,
            inner_radius=0.1,
            thickness=0.1,
            resistivity=1e-6,
            units="mm",
        )
        assert r > 0

    def test_circular_invalid_inner_radius(self):
        with pytest.raises(ValueError):
            calculate_circular_resistance(5.0, 10.0, 0.1, 1e-6, "mm")


class TestOvalResistance:
    """测试椭圆/椭圆形电阻计算。"""

    def test_oval_basic(self):
        r = calculate_oval_resistance(
            a_axis=15.0,
            b_axis=8.0,
            thickness=0.1,
            resistivity=1e-6,
            units="mm",
        )
        assert r > 0

    def test_oval_circular_limit(self):
        r_oval = calculate_oval_resistance(10.0, 10.0, 0.1, 1e-6, "mm")
        assert r_oval > 0


class TestHorseshoeResistance:
    """测试马蹄形/U形电阻计算。"""

    def test_horseshoe_basic(self):
        r = calculate_horseshoe_resistance(
            width=5.0,
            gap=8.0,
            turns=1,
            thickness=0.1,
            resistivity=1e-6,
            units="mm",
        )
        assert r > 0

    def test_horseshoe_more_turns_higher_resistance(self):
        r_single = calculate_horseshoe_resistance(5.0, 8.0, 1, 0.1, 1e-6, "mm")
        r_double = calculate_horseshoe_resistance(5.0, 8.0, 2, 0.1, 1e-6, "mm")
        assert r_double > r_single


class TestMeanderResistance:
    """测试蛇形/蜿蜒电阻计算。"""

    def test_meander_basic(self):
        r = calculate_meander_resistance(
            length=50.0,
            track_width=1.0,
            gap=1.0,
            segments=10,
            thickness=0.1,
            resistivity=1e-6,
            units="mm",
        )
        assert r > 0

    def test_meander_more_segments_higher_resistance(self):
        r_few = calculate_meander_resistance(50.0, 1.0, 1.0, 5, 0.1, 1e-6, "mm")
        r_many = calculate_meander_resistance(50.0, 1.0, 1.0, 10, 0.1, 1e-6, "mm")
        assert r_many > r_few

    def test_meander_narrower_track_higher_resistance(self):
        r_wide = calculate_meander_resistance(50.0, 2.0, 1.0, 10, 0.1, 1e-6, "mm")
        r_narrow = calculate_meander_resistance(50.0, 1.0, 1.0, 10, 0.1, 1e-6, "mm")
        assert r_narrow > r_wide


class TestSheetResistance:
    """测试统一的电阻片电阻计算函数。"""

    def test_sheet_rectangle(self):
        geo = SheetGeometry(shape=ResistorShape.RECTANGLE, width=10.0, height=5.0)
        r = calculate_sheet_resistance(geo)
        assert r > 0

    def test_sheet_circular(self):
        geo = SheetGeometry(shape=ResistorShape.CIRCULAR, outer_radius=10.0, inner_radius=5.0)
        r = calculate_sheet_resistance(geo)
        assert r > 0

    def test_sheet_oval(self):
        geo = SheetGeometry(shape=ResistorShape.OVAL, oval_a=15.0, oval_b=8.0)
        r = calculate_sheet_resistance(geo)
        assert r > 0

    def test_sheet_horseshoe(self):
        geo = SheetGeometry(shape=ResistorShape.HORSESHOE, horseshoe_width=5.0, horseshoe_gap=8.0)
        r = calculate_sheet_resistance(geo)
        assert r > 0

    def test_sheet_meander(self):
        geo = SheetGeometry(
            shape=ResistorShape.meander, meander_length=50.0, meander_track_width=1.0,
        )
        r = calculate_sheet_resistance(geo)
        assert r > 0


class TestTemperatureRise:
    """测试热仿真。"""

    def test_temperature_rise_basic(self):
        params = SimulationParams(current=1.0, ambient_temp=25.0, max_time_ms=100.0)
        thermal = calculate_temperature_rise(current=1.0, resistance=1.0, params=params)

        assert len(thermal.time_points) > 0
        assert len(thermal.temperature_points) > 0
        assert len(thermal.time_points) == len(thermal.temperature_points)

    def test_temperature_rises_over_time(self):
        params = SimulationParams(current=1.0, ambient_temp=25.0, max_time_ms=100.0)
        thermal = calculate_temperature_rise(current=1.0, resistance=1.0, params=params)

        assert thermal.temperature_points[-1] >= thermal.temperature_points[0]

    def test_temperature_equilibrium_reached(self):
        params = SimulationParams(current=1.0, ambient_temp=25.0, max_time_ms=500.0)
        thermal = calculate_temperature_rise(current=1.0, resistance=1.0, params=params)

        assert thermal.equilibrium_temperature >= thermal.equilibrium_temperature
        assert thermal.max_temperature <= thermal.equilibrium_temperature + 10

    def test_higher_current_causes_higher_temperature(self):
        params = SimulationParams(current=1.0, ambient_temp=25.0, max_time_ms=100.0)
        thermal_low = calculate_temperature_rise(current=0.5, resistance=1.0, params=params)
        thermal_high = calculate_temperature_rise(current=2.0, resistance=1.0, params=params)

        assert thermal_high.max_temperature > thermal_low.max_temperature


class TestCompleteCalculation:
    """测试完整的电阻计算。"""

    def test_complete_calculation(self):
        pin = PinGeometry(diameter=0.5, length=2.0, resistivity=1.68e-8)
        sheet = SheetGeometry(shape=ResistorShape.RECTANGLE, width=10.0, height=10.0)
        sim = SimulationParams(current=1.0, ambient_temp=25.0, max_time_ms=100.0)

        result = calculate_resistor(pin, sheet, sim)

        assert result.pin_resistance > 0
        assert result.sheet_resistance > 0
        assert result.total_resistance > 0
        assert result.voltage_drop > 0
        assert result.power_dissipation > 0

    def test_total_resistance_formula(self):
        pin = PinGeometry(diameter=0.5, length=2.0, resistivity=1e-6)
        sheet = SheetGeometry(
            shape=ResistorShape.RECTANGLE, width=10.0, height=10.0, resistivity=1e-6,
        )
        sim = SimulationParams(current=1.0)

        result = calculate_resistor(pin, sheet, sim)

        expected_total = 2 * result.pin_resistance + result.sheet_resistance
        assert result.total_resistance == pytest.approx(expected_total)

    def test_ohms_law_voltage(self):
        pin = PinGeometry(diameter=0.5, length=2.0, resistivity=1e-6)
        sheet = SheetGeometry(shape=ResistorShape.RECTANGLE, width=10.0, height=10.0)
        sim = SimulationParams(current=2.0)

        result = calculate_resistor(pin, sheet, sim)

        expected_v = sim.current * result.total_resistance
        assert result.voltage_drop == pytest.approx(expected_v)

    def test_power_dissipation_i2r(self):
        pin = PinGeometry(diameter=0.5, length=2.0, resistivity=1e-6)
        sheet = SheetGeometry(shape=ResistorShape.RECTANGLE, width=10.0, height=10.0)
        sim = SimulationParams(current=2.0)

        result = calculate_resistor(pin, sheet, sim)

        expected_p = sim.current**2 * result.total_resistance
        assert result.power_dissipation == pytest.approx(expected_p)

    def test_distribution_data_generated(self):
        pin = PinGeometry(diameter=0.5, length=2.0)
        sheet = SheetGeometry(shape=ResistorShape.RECTANGLE, width=10.0, height=10.0)
        sim = SimulationParams(current=1.0)

        result = calculate_resistor(pin, sheet, sim)

        assert "x" in result.distribution_data
        assert "y" in result.distribution_data
        assert "resistance_density" in result.distribution_data
