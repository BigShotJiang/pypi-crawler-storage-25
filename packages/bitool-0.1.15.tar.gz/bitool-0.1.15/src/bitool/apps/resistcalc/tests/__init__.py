"""resistcalc 的测试包。"""
