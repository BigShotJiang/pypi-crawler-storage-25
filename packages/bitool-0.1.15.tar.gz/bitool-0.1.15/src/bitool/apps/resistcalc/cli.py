"""材料电阻计算器的 CLI 模块。

提供命令行界面用于电阻计算。
"""

from __future__ import annotations

import argparse

from bitool.core import logger

from .resistcalc import (
    PinGeometry,
    ResistorShape,
    SheetGeometry,
    SimulationParams,
    calculate_resistor,
)


def print_result(result) -> None:
    """打印计算结果。"""


def main() -> int:
    """CLI 主入口函数。"""
    parser = argparse.ArgumentParser(
        description="电阻片材料电阻计算器 / Material Resistivity Calculator for Sheet Resistors",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument("--pin-diameter", type=float, default=0.5, help="引脚直径，单位 mm")
    parser.add_argument("--pin-length", type=float, default=2.0, help="引脚长度，单位 mm")
    parser.add_argument(
        "--pin-resistivity", type=float, default=1.68e-8, help="引脚材料电阻率，单位 Ω·m",
    )

    parser.add_argument(
        "--shape",
        type=str,
        default="rectangle",
        choices=["rectangle", "circular", "oval", "horseshoe", "meander"],
        help="电阻片形状",
    )
    parser.add_argument("--thickness", type=float, default=0.1, help="电阻片厚度，单位 mm")
    parser.add_argument(
        "--resistivity", type=float, default=1e-6, help="电阻片材料电阻率，单位 Ω·m",
    )

    parser.add_argument("--width", type=float, default=10.0, help="宽度/长度尺寸，单位 mm")
    parser.add_argument("--height", type=float, default=10.0, help="高度尺寸，单位 mm")
    parser.add_argument(
        "--outer-radius", type=float, default=10.0, help="环形形状的外半径，单位 mm",
    )
    parser.add_argument("--inner-radius", type=float, default=5.0, help="环形形状的内半径，单位 mm")

    parser.add_argument("--current", type=float, default=1.0, help="施加的电流，单位安培")
    parser.add_argument("--ambient-temp", type=float, default=25.0, help="环境温度，单位 °C")
    parser.add_argument("--max-time", type=float, default=1000.0, help="最大仿真时间，单位 ms")

    args = parser.parse_args()

    try:
        shape_map = {
            "rectangle": ResistorShape.RECTANGLE,
            "circular": ResistorShape.CIRCULAR,
            "oval": ResistorShape.OVAL,
            "horseshoe": ResistorShape.HORSESHOE,
            "meander": ResistorShape.meander,
        }

        pin = PinGeometry(
            diameter=args.pin_diameter,
            length=args.pin_length,
            resistivity=args.pin_resistivity,
        )

        sheet = SheetGeometry(
            shape=shape_map[args.shape],
            thickness=args.thickness,
            resistivity=args.resistivity,
            width=args.width,
            height=args.height,
            outer_radius=args.outer_radius,
            inner_radius=args.inner_radius,
        )

        simulation = SimulationParams(
            current=args.current,
            ambient_temp=args.ambient_temp,
            max_time_ms=args.max_time,
        )

        logger.info("开始计算")
        result = calculate_resistor(pin, sheet, simulation)

        print_result(result)

    except Exception as e:  # noqa: BLE001
        logger.error(f"错误: {e}")
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
