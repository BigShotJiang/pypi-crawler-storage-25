"""材料电阻分析的核心物理计算模块。

实现圆柱形引脚和各种形状电阻片的电阻计算，
以及温度升高的热仿真功能。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

import numpy as np

from bitool.core import logger


class ResistorShape(Enum):
    """电阻片形状枚举。"""

    RECTANGLE = "rectangle"
    CIRCULAR = "circular"
    OVAL = "oval"
    HORSESHOE = "horseshoe"
    meander = "meander"


@dataclass
class PinGeometry:
    """圆柱形引脚几何参数。"""

    diameter: float = 0.5
    length: float = 2.0
    resistivity: float = 1.68e-8
    units: str = "mm"


@dataclass
class SheetGeometry:
    """电阻片几何参数。"""

    shape: ResistorShape = ResistorShape.RECTANGLE
    thickness: float = 0.1
    resistivity: float = 1.0e-6

    width: float = 10.0
    height: float = 10.0

    outer_radius: float = 10.0
    inner_radius: float = 5.0

    oval_a: float = 15.0
    oval_b: float = 8.0

    horseshoe_width: float = 5.0
    horseshoe_gap: float = 8.0
    horseshoe_turns: int = 2

    meander_length: float = 50.0
    meander_track_width: float = 1.0
    meander_gap: float = 1.0
    meander_segments: int = 10

    units: str = "mm"


@dataclass
class SimulationParams:
    """热仿真参数。"""

    current: float = 1.0
    ambient_temp: float = 25.0
    max_time_ms: float = 1000.0
    time_step_ms: float = 1.0
    thermal_conductivity: float = 237.0
    density: float = 2700.0
    specific_heat: float = 900.0


@dataclass
class ThermalResult:
    """热仿真结果。"""

    time_points: np.ndarray = field(default_factory=lambda: np.array([]))
    temperature_points: np.ndarray = field(default_factory=lambda: np.array([]))
    max_temperature: float = 0.0
    equilibrium_temperature: float = 0.0
    time_constant: float = 0.0


@dataclass
class ResistanceResult:
    """电阻计算结果。"""

    pin_resistance: float = 0.0
    sheet_resistance: float = 0.0
    total_resistance: float = 0.0
    voltage_drop: float = 0.0
    power_dissipation: float = 0.0
    current_density: float = 0.0
    thermal_result: ThermalResult = field(default_factory=ThermalResult)
    distribution_data: dict = field(default_factory=dict)


def convert_to_meters(value: float, units: str) -> float:
    """将长度值转换为米。

    Args:
        value: 长度值
        units: 单位 (mm, cm, um, nm, m)

    Returns:
        米为单位的长度值
    """
    conversions = {
        "mm": 1e-3,
        "cm": 1e-2,
        "um": 1e-6,
        "nm": 1e-9,
        "m": 1.0,
    }
    return value * conversions.get(units, 1e-3)


def calculate_pin_resistance(geometry: PinGeometry) -> float:
    """计算圆柱形引脚的电阻。

    计算公式: R = ρ * L / A = ρ * L / (π * r²)

    Args:
        geometry: 引脚几何参数

    Returns:
        电阻值，单位：欧姆
    """
    length_m = convert_to_meters(geometry.length, geometry.units)
    radius_m = convert_to_meters(geometry.diameter / 2, geometry.units)
    resistivity = geometry.resistivity

    cross_area = np.pi * radius_m**2
    resistance = resistivity * length_m / cross_area

    logger.debug(
        f"引脚电阻: R={resistance:.6e}Ω, L={length_m * 1000:.3f}mm, A={cross_area * 1e6:.3f}mm²",
    )

    return resistance


def calculate_rectangle_resistance(
    width: float,
    height: float,
    thickness: float,
    resistivity: float,
    units: str = "mm",
) -> float:
    """计算矩形电阻片的电阻。

    当 L >> w 时（电流沿长度方向流动）:
        R = ρ * L / (w * t)
    当 L << w 时（电流沿宽度方向流动）:
        R = ρ * w / (L * t)

    Args:
        width: 矩形宽度（当 L>>W 时为电流路径长度）
        height: 矩形高度
        thickness: 电阻片厚度
        resistivity: 材料电阻率（Ω·m）
        units: 长度单位

    Returns:
        电阻值，单位：欧姆
    """
    length_m = convert_to_meters(width, units)
    width_m = convert_to_meters(height, units)
    thickness_m = convert_to_meters(thickness, units)

    cross_area = width_m * thickness_m
    resistance = resistivity * length_m / cross_area

    logger.debug(
        f"矩形电阻: R={resistance:.6e}Ω, L={length_m * 1000:.3f}mm, A={cross_area * 1e6:.6f}mm²",
    )

    return resistance


def calculate_circular_resistance(
    outer_radius: float,
    inner_radius: float,
    thickness: float,
    resistivity: float,
    units: str = "mm",
) -> float:
    """计算环形（圆环形状）电阻的电阻。

    计算公式: R = ρ * ln(r_outer / r_inner) / (2 * π * t)

    Args:
        outer_radius: 圆环外半径
        inner_radius: 圆环内半径
        thickness: 电阻片厚度
        resistivity: 材料电阻率（Ω·m）
        units: 长度单位

    Returns:
        电阻值，单位：欧姆
    """
    outer_m = convert_to_meters(outer_radius, units)
    inner_m = convert_to_meters(inner_radius, units)
    thickness_m = convert_to_meters(thickness, units)

    if inner_m >= outer_m:
        raise ValueError("内半径必须小于外半径")

    r_ratio = outer_m / 1e-10 if inner_m == 0 else outer_m / inner_m

    resistance = resistivity * np.log(r_ratio) / (2 * np.pi * thickness_m)

    logger.debug(
        f"环形电阻: R={resistance:.6e}Ω, r_out={outer_m * 1000:.3f}mm, r_in={inner_m * 1000:.3f}mm",
    )

    return resistance


def calculate_oval_resistance(
    a_axis: float,
    b_axis: float,
    thickness: float,
    resistivity: float,
    units: str = "mm",
) -> float:
    """计算椭圆形电阻片的电阻。

    使用数值积分方法沿电流路径计算。
    近似公式: R ≈ ρ * L_eff / (t * w_eff)

    Args:
        a_axis: 椭圆长半轴
        b_axis: 椭圆短半轴
        thickness: 电阻片厚度
        resistivity: 材料电阻率（Ω·m）
        units: 长度单位

    Returns:
        电阻值，单位：欧姆
    """
    a_m = convert_to_meters(a_axis, units)
    b_m = convert_to_meters(b_axis, units)
    thickness_m = convert_to_meters(thickness, units)

    np.sqrt(1 - (b_m / a_m) ** 2) if a_m > b_m else np.sqrt(1 - (a_m / b_m) ** 2)
    perimeter = (
        4 * a_m * b_m * np.pi / (a_m + b_m)
        if abs(a_m - b_m) < 1e-10
        else _ellipse_perimeter(a_m, b_m)
    )

    effective_length = perimeter / 2
    effective_width = 2 * b_m

    cross_area = effective_width * thickness_m
    resistance = resistivity * effective_length / cross_area

    logger.debug(f"椭圆电阻: R={resistance:.6e}Ω, a={a_m * 1000:.3f}mm, b={b_m * 1000:.3f}mm")

    return resistance


def _ellipse_perimeter(a: float, b: float) -> float:
    """使用拉马努金近似公式计算椭圆周长。

    Args:
        a: 长半轴
        b: 短半轴

    Returns:
        椭圆周长
    """
    h = ((a - b) ** 2) / ((a + b) ** 2)
    return np.pi * (a + b) * (1 + (3 * h) / (10 + np.sqrt(4 - 3 * h)))


def calculate_horseshoe_resistance(
    width: float,
    gap: float,
    turns: int,
    thickness: float,
    resistivity: float,
    units: str = "mm",
) -> float:
    """计算马蹄形（U形）电阻的电阻。

    Args:
        width: 马蹄形导线宽度
        gap: 马蹄形两端之间的间隙
        turns: 圈数（用于螺旋/线圈式马蹄形）
        thickness: 电阻片厚度
        resistivity: 材料电阻率（Ω·m）
        units: 长度单位

    Returns:
        电阻值，单位：欧姆
    """
    width_m = convert_to_meters(width, units)
    gap_m = convert_to_meters(gap, units)
    thickness_m = convert_to_meters(thickness, units)

    straight_section = 2 * (gap_m + width_m)
    curved_section = np.pi * gap_m
    total_perimeter = 2 * straight_section + 2 * curved_section

    effective_length = total_perimeter * max(1, turns)
    cross_area = width_m * thickness_m

    resistance = resistivity * effective_length / cross_area

    logger.debug(
        f"马蹄形电阻: R={resistance:.6e}Ω, width={width_m * 1000:.3f}mm, gap={gap_m * 1000:.3f}mm",
    )

    return resistance


def calculate_meander_resistance(
    length: float,
    track_width: float,
    gap: float,
    segments: int,
    thickness: float,
    resistivity: float,
    units: str = "mm",
) -> float:
    """计算蛇形（蜿蜒）电阻的电阻。

    Args:
        length: 蛇形总有效长度
        track_width: 每段导线的宽度
        gap: 导线之间的间隙
        segments: 段数/弯折次数
        thickness: 电阻片厚度
        resistivity: 材料电阻率（Ω·m）
        units: 长度单位

    Returns:
        电阻值，单位：欧姆
    """
    length_m = convert_to_meters(length, units)
    track_m = convert_to_meters(track_width, units)
    gap_m = convert_to_meters(gap, units)
    thickness_m = convert_to_meters(thickness, units)

    segment_length = length_m / segments
    straight_portion = 2 * segments * segment_length
    curved_portion = 2 * segments * np.pi * (gap_m / 2 + track_m / 2)

    total_length = straight_portion + curved_portion
    cross_area = track_m * thickness_m

    resistance = resistivity * total_length / cross_area

    logger.debug(
        f"蛇形电阻: R={resistance:.6e}Ω, length={length_m * 1000:.3f}mm, segments={segments}",
    )

    return resistance


def calculate_sheet_resistance(geometry: SheetGeometry) -> float:
    """根据形状计算电阻片的电阻。

    Args:
        geometry: 电阻片几何参数

    Returns:
        电阻值，单位：欧姆
    """
    thickness = geometry.thickness
    resistivity = geometry.resistivity
    units = geometry.units

    if geometry.shape == ResistorShape.RECTANGLE:
        return calculate_rectangle_resistance(
            geometry.width, geometry.height, thickness, resistivity, units,
        )
    elif geometry.shape == ResistorShape.CIRCULAR:
        return calculate_circular_resistance(
            geometry.outer_radius, geometry.inner_radius, thickness, resistivity, units,
        )
    elif geometry.shape == ResistorShape.OVAL:
        return calculate_oval_resistance(
            geometry.oval_a, geometry.oval_b, thickness, resistivity, units,
        )
    elif geometry.shape == ResistorShape.HORSESHOE:
        return calculate_horseshoe_resistance(
            geometry.horseshoe_width,
            geometry.horseshoe_gap,
            geometry.horseshoe_turns,
            thickness,
            resistivity,
            units,
        )
    elif geometry.shape == ResistorShape.meander:
        return calculate_meander_resistance(
            geometry.meander_length,
            geometry.meander_track_width,
            geometry.meander_gap,
            geometry.meander_segments,
            thickness,
            resistivity,
            units,
        )
    else:
        raise ValueError(f"不支持的形状: {geometry.shape}")


def calculate_temperature_rise(
    current: float,
    resistance: float,
    params: SimulationParams,
) -> ThermalResult:
    """模拟由于焦耳热导致的温度随时间升高。

    使用集总热容模型:
        dT/dt = (P - h*A*(T - T_ambient)) / (m * c)
        其中 P = I² * R（焦耳热功率）

    解析解:
        T(t) = T_ambient + (P/hA) * (1 - exp(-t/tau))
        其中 tau = m * c / (h * A)

    Args:
        current: 施加的电流，单位：安培
        resistance: 电阻值，单位：欧姆
        params: 仿真参数

    Returns:
        包含温度-时间数据的 ThermalResult 对象
    """
    power = current**2 * resistance

    time_points = np.arange(0, params.max_time_ms + params.time_step_ms, params.time_step_ms)
    time_seconds = time_points / 1000.0

    volume_est = 1e-9
    mass = params.density * volume_est
    h = params.thermal_conductivity

    surface_area = 1e-6
    time_constant = (mass * params.specific_heat) / (h * surface_area) if surface_area > 0 else 1.0

    equilibrium_rise = power / (h * surface_area) if surface_area > 0 else 0

    temperature_rise = equilibrium_rise * (1 - np.exp(-time_seconds / time_constant))
    temperatures = params.ambient_temp + temperature_rise

    result = ThermalResult(
        time_points=time_points,
        temperature_points=temperatures,
        max_temperature=float(np.max(temperatures)),
        equilibrium_temperature=float(params.ambient_temp + equilibrium_rise),
        time_constant=float(time_constant),
    )

    logger.debug(f"热仿真: ΔT_max={equilibrium_rise:.2f}°C, tau={time_constant:.3f}s")

    return result


def calculate_resistance_distribution(
    geometry: SheetGeometry,
    pin: PinGeometry,
    num_points: int = 100,
) -> dict:
    """计算电阻器内部的电阻分布。

    Args:
        geometry: 电阻片几何参数
        pin: 引脚几何参数
        num_points: 网格采样点数

    Returns:
        包含 x, y 坐标、电阻密度值和边界掩码的字典
    """
    num_points = min(num_points, 100)

    if geometry.shape == ResistorShape.RECTANGLE:
        x = np.linspace(-geometry.width / 2, geometry.width / 2, num_points)
        y = np.linspace(-geometry.height / 2, geometry.height / 2, num_points)
        X, Y = np.meshgrid(x, y)

        np.abs(X) / (geometry.width / 2)
        np.abs(Y) / (geometry.height / 2)

        center_dist = np.sqrt((X / (geometry.width / 2)) ** 2 + (Y / (geometry.height / 2)) ** 2)
        resistance_density = 0.3 + 0.7 * (1 - center_dist / np.sqrt(2))
        resistance_density = np.clip(resistance_density, 0.1, 0.95)

        mask = np.ones_like(X, dtype=bool)

    elif geometry.shape == ResistorShape.CIRCULAR:
        theta = np.linspace(0, 2 * np.pi, num_points)
        r = np.linspace(0, geometry.outer_radius, num_points)
        THETA, R = np.meshgrid(theta, r)

        X = R * np.cos(THETA)
        Y = R * np.sin(THETA)

        norm_r = R / geometry.outer_radius
        resistance_density = 0.3 + 0.7 * (1 - norm_r)
        resistance_density = np.clip(resistance_density, 0.1, 0.95)

        mask = geometry.outer_radius >= R

        inner_mask = (
            geometry.inner_radius <= R if geometry.inner_radius > 0 else np.ones_like(R, dtype=bool)
        )
        mask = mask & inner_mask

    elif geometry.shape == ResistorShape.OVAL:
        x = np.linspace(-geometry.oval_a, geometry.oval_a, num_points)
        y = np.linspace(-geometry.oval_b, geometry.oval_b, num_points)
        X, Y = np.meshgrid(x, y)

        oval_eq = (X / geometry.oval_a) ** 2 + (Y / geometry.oval_b) ** 2
        mask = oval_eq <= 1

        center_dist = np.sqrt((X / geometry.oval_a) ** 2 + (Y / geometry.oval_b) ** 2)
        resistance_density = 0.3 + 0.7 * (1 - center_dist)
        resistance_density = np.clip(resistance_density, 0.1, 0.95)

    elif geometry.shape == ResistorShape.HORSESHOE:
        width = geometry.horseshoe_width
        gap = geometry.horseshoe_gap
        turns = geometry.horseshoe_turns

        x = np.linspace(-gap / 2 - width, gap / 2 + width, num_points)
        y = np.linspace(-width * turns * 2, width * turns * 2, num_points)
        X, Y = np.meshgrid(x, y)

        mask = np.zeros_like(X, dtype=bool)
        resistance_density = np.zeros_like(X)

        for turn in range(turns):
            y_center = -width * turns + width + turn * 2 * width

            arc_mask_upper = (
                (-gap / 2 <= X)
                & (gap / 2 >= X)
                & (y_center - width / 2 <= Y)
                & (y_center + width / 2 >= Y)
            )
            arc_mask_lower = (
                (-gap / 2 <= X)
                & (gap / 2 >= X)
                & (y_center - width / 2 - width <= Y)
                & (y_center + width / 2 - width >= Y)
            )

            mask = mask | arc_mask_upper | arc_mask_lower
            resistance_density[arc_mask_upper | arc_mask_lower] = 0.5 + 0.3 * np.random.random(
                np.sum(arc_mask_upper | arc_mask_lower),
            )

    elif geometry.shape == ResistorShape.meander:
        length = geometry.meander_length
        track_width = geometry.meander_track_width
        gap = geometry.meander_gap
        segments = geometry.meander_segments

        segment_length = length / segments

        x_total = segment_length + (segments - 1) * (track_width + gap)
        y_total = track_width * 2 + gap

        x = np.linspace(-x_total / 2, x_total / 2, num_points)
        y = np.linspace(-y_total / 2, y_total / 2, num_points)
        X, Y = np.meshgrid(x, y)

        mask = np.zeros_like(X, dtype=bool)
        resistance_density = np.zeros_like(X)

        for seg in range(segments):
            x_start = -x_total / 2 + seg * (track_width + gap)
            x_end = x_start + segment_length
            y_pos = (-1) ** seg * (track_width / 2 + gap / 2)

            seg_mask = (x_start <= X) & (x_end >= X) & (np.abs(Y - y_pos) <= track_width / 2)
            mask = mask | seg_mask
            resistance_density[seg_mask] = 0.4 + 0.5 * np.random.random(np.sum(seg_mask))

    else:
        x = np.linspace(-geometry.width / 2, geometry.width / 2, num_points)
        y = np.linspace(-geometry.height / 2, geometry.height / 2, num_points)
        X, Y = np.meshgrid(x, y)
        resistance_density = 0.3 + 0.4 * np.random.random((num_points, num_points))
        mask = np.ones_like(X, dtype=bool)

    resistance_density[~mask] = np.nan

    pin_x_left = -geometry.width / 2 if hasattr(geometry, "width") else -5
    pin_x_right = geometry.width / 2 if hasattr(geometry, "width") else 5
    pin_y_center = 0

    pin_radius = pin.diameter / 2

    pin_mask_left = np.sqrt((X - pin_x_left) ** 2 + (Y - pin_y_center) ** 2) <= pin_radius * 2
    pin_mask_right = np.sqrt((X - pin_x_right) ** 2 + (Y - pin_y_center) ** 2) <= pin_radius * 2

    pin_density = np.where(pin_mask_left | pin_mask_right, 0.95, np.nan)

    return {
        "x": X,
        "y": Y,
        "resistance_density": resistance_density,
        "pin_density": pin_density,
        "mask": mask,
        "units": geometry.units,
        "shape": geometry.shape.value,
    }


def calculate_resistor(
    pin: PinGeometry,
    sheet: SheetGeometry,
    simulation: SimulationParams,
) -> ResistanceResult:
    """计算带引脚的电阻片的完整电阻。

    Args:
        pin: 引脚几何参数
        sheet: 电阻片几何参数
        simulation: 仿真参数

    Returns:
        包含所有计算值的 ResistanceResult 对象
    """
    logger.info("开始电阻计算")

    pin_resistance = calculate_pin_resistance(pin)
    sheet_resistance = calculate_sheet_resistance(sheet)
    total_resistance = 2 * pin_resistance + sheet_resistance

    voltage_drop = simulation.current * total_resistance
    power = simulation.current**2 * total_resistance

    cross_area = np.pi * (convert_to_meters(pin.diameter / 2, pin.units)) ** 2
    current_density = simulation.current / cross_area if cross_area > 0 else 0

    thermal = calculate_temperature_rise(simulation.current, total_resistance, simulation)

    distribution = calculate_resistance_distribution(sheet, pin)

    result = ResistanceResult(
        pin_resistance=pin_resistance,
        sheet_resistance=sheet_resistance,
        total_resistance=total_resistance,
        voltage_drop=voltage_drop,
        power_dissipation=power,
        current_density=current_density,
        thermal_result=thermal,
        distribution_data=distribution,
    )

    logger.info(
        f"计算完成: R_total={total_resistance:.6e}Ω, "
        f"P={power:.4f}W, ΔT={thermal.equilibrium_temperature - simulation.ambient_temp:.2f}°C",
    )

    return result
