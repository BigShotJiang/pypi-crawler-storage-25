"""材料电阻计算器的 GUI 模块。

提供交互式界面用于配置电阻几何参数、
运行仿真和可视化结果。
"""

from __future__ import annotations

import contextlib
import sys

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from bitool.core import logger
from bitool.gui.compat import (
    QApplication,
    QComboBox,
    QDoubleSpinBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QMainWindow,
    QPushButton,
    QSpinBox,
    QSplitter,
    Qt,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from .resistcalc import (
    PinGeometry,
    ResistorShape,
    SheetGeometry,
    SimulationParams,
    calculate_resistor,
)

plt.rcParams["axes.unicode_minus"] = False


class MplCanvas(FigureCanvas):
    """用于绑定的 Matplotlib 画布。"""

    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = fig.add_subplot(111)
        super().__init__(fig)
        self.setParent(parent)


class ResistCalcGUI(QMainWindow):
    """材料电阻计算器主窗口。"""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("材料电阻计算器 - Sheet Resistor Calculator")
        self.setGeometry(100, 100, 1200, 800)

        self.result = None
        self.setup_chinese_font()
        self.init_ui()
        logger.info("材料电阻计算器 GUI 初始化完成")

    def setup_chinese_font(self):
        """配置 matplotlib 中文字体。"""
        windows_fonts = ["SimHei", "Microsoft YaHei", "SimSun", "Arial Unicode MS"]
        mac_fonts = ["Arial Unicode MS", "PingFang SC", "Heiti TC"]
        linux_fonts = ["WenQuanYi Micro Hei", "Noto Sans CJK SC", "Noto Sans SC"]

        available_fonts = [f.name for f in font_manager.fontManager.ttflist]

        for font_list in [windows_fonts, mac_fonts, linux_fonts]:
            for font_name in font_list:
                if font_name in available_fonts:
                    plt.rcParams["font.sans-serif"] = [font_name, "sans-serif"]
                    logger.debug(f"使用中文字体: {font_name}")
                    return True

        plt.rcParams["font.sans-serif"] = ["sans-serif"]
        logger.warning("未找到中文字体，使用系统默认字体")
        return False

    def init_ui(self):
        """初始化 UI 组件。"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        splitter = QSplitter(Qt.Horizontal)

        left_widget = self.create_input_panel()
        splitter.addWidget(left_widget)

        right_widget = self.create_result_panel()
        splitter.addWidget(right_widget)

        splitter.setSizes([450, 750])
        main_layout.addWidget(splitter)

    def create_input_panel(self) -> QWidget:
        """创建输入配置面板。"""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        self.tabs = QTabWidget()

        self.tabs.addTab(self.create_pin_tab(), "引脚参数")
        self.tabs.addTab(self.create_sheet_tab(), "电阻片参数")
        self.tabs.addTab(self.create_simulation_tab(), "仿真参数")

        layout.addWidget(self.tabs)

        self.calculate_btn = QPushButton("计算 / Calculate")
        self.calculate_btn.clicked.connect(self.calculate)
        layout.addWidget(self.calculate_btn)

        layout.addStretch()
        return widget

    def create_pin_tab(self) -> QWidget:
        """创建引脚参数选项卡。"""
        widget = QWidget()
        layout = QFormLayout(widget)

        self.pin_diameter = QDoubleSpinBox()
        self.pin_diameter.setRange(0.01, 100.0)
        self.pin_diameter.setValue(0.5)
        self.pin_diameter.setSuffix(" mm")
        self.pin_diameter.setDecimals(3)
        layout.addRow("直径 (Diameter):", self.pin_diameter)

        self.pin_length = QDoubleSpinBox()
        self.pin_length.setRange(0.1, 500.0)
        self.pin_length.setValue(2.0)
        self.pin_length.setSuffix(" mm")
        self.pin_length.setDecimals(2)
        layout.addRow("长度 (Length):", self.pin_length)

        self.pin_resistivity = QDoubleSpinBox()
        self.pin_resistivity.setRange(1e-12, 1e-2)
        self.pin_resistivity.setValue(1.68e-8)
        with contextlib.suppress(AttributeError):
            self.pin_resistivity.setNotation(QDoubleSpinBox.ScientificNotation)
        self.pin_resistivity.setDecimals(6)
        layout.addRow("电阻率 (Resistivity):", self.pin_resistivity)

        return widget

    def create_sheet_tab(self) -> QWidget:
        """创建电阻片参数选项卡。"""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        shape_group = QGroupBox("形状选择")
        shape_layout = QFormLayout(shape_group)

        self.shape_combo = QComboBox()
        self.shape_combo.addItems(
            [
                "矩形 (Rectangle)",
                "环形 (Circular)",
                "椭圆形 (Oval)",
                "马蹄形 (Horseshoe)",
                "蛇形 (Meander)",
            ],
        )
        self.shape_combo.currentIndexChanged.connect(self.on_shape_changed)
        shape_layout.addRow("电阻片形状:", self.shape_combo)

        layout.addWidget(shape_group)

        self.shape_stack = QWidget()
        stack_layout = QVBoxLayout(self.shape_stack)

        stack_layout.addWidget(self.create_rectangle_panel())
        stack_layout.addWidget(self.create_circular_panel())
        stack_layout.addWidget(self.create_oval_panel())
        stack_layout.addWidget(self.create_horseshoe_panel())
        stack_layout.addWidget(self.create_meander_panel())

        self.on_shape_changed(0)

        layout.addWidget(self.shape_stack)

        layout.addStretch()
        return widget

    def create_rectangle_panel(self) -> QWidget:
        """创建矩形形状参数面板。"""
        widget = QWidget()
        layout = QFormLayout(widget)

        self.rect_width = QDoubleSpinBox()
        self.rect_width.setRange(0.1, 1000.0)
        self.rect_width.setValue(10.0)
        self.rect_width.setSuffix(" mm")
        self.rect_width.setDecimals(2)
        layout.addRow("宽度 (Width):", self.rect_width)

        self.rect_height = QDoubleSpinBox()
        self.rect_height.setRange(0.1, 1000.0)
        self.rect_height.setValue(10.0)
        self.rect_height.setSuffix(" mm")
        self.rect_height.setDecimals(2)
        layout.addRow("高度 (Height):", self.rect_height)

        self.rect_thickness = QDoubleSpinBox()
        self.rect_thickness.setRange(0.001, 10.0)
        self.rect_thickness.setValue(0.1)
        self.rect_thickness.setSuffix(" mm")
        self.rect_thickness.setDecimals(4)
        layout.addRow("厚度 (Thickness):", self.rect_thickness)

        self.rect_resistivity = QDoubleSpinBox()
        self.rect_resistivity.setRange(1e-12, 1e-2)
        self.rect_resistivity.setValue(1e-6)
        with contextlib.suppress(AttributeError):
            self.rect_resistivity.setNotation(QDoubleSpinBox.ScientificNotation)
        self.rect_resistivity.setDecimals(6)
        layout.addRow("电阻率 (Resistivity):", self.rect_resistivity)

        return widget

    def create_circular_panel(self) -> QWidget:
        """创建环形/圆环形状参数面板。"""
        widget = QWidget()
        layout = QFormLayout(widget)

        self.circ_outer = QDoubleSpinBox()
        self.circ_outer.setRange(0.1, 1000.0)
        self.circ_outer.setValue(10.0)
        self.circ_outer.setSuffix(" mm")
        self.circ_outer.setDecimals(2)
        layout.addRow("外半径 (Outer R):", self.circ_outer)

        self.circ_inner = QDoubleSpinBox()
        self.circ_inner.setRange(0.0, 990.0)
        self.circ_inner.setValue(5.0)
        self.circ_inner.setSuffix(" mm")
        self.circ_inner.setDecimals(2)
        layout.addRow("内半径 (Inner R):", self.circ_inner)

        self.circ_thickness = QDoubleSpinBox()
        self.circ_thickness.setRange(0.001, 10.0)
        self.circ_thickness.setValue(0.1)
        self.circ_thickness.setSuffix(" mm")
        self.circ_thickness.setDecimals(4)
        layout.addRow("厚度 (Thickness):", self.circ_thickness)

        self.circ_resistivity = QDoubleSpinBox()
        self.circ_resistivity.setRange(1e-12, 1e-2)
        self.circ_resistivity.setValue(1e-6)
        with contextlib.suppress(AttributeError):
            self.circ_resistivity.setNotation(QDoubleSpinBox.ScientificNotation)
        self.circ_resistivity.setDecimals(6)
        layout.addRow("电阻率 (Resistivity):", self.circ_resistivity)

        widget.hide()
        return widget

    def create_oval_panel(self) -> QWidget:
        """创建椭圆形参数面板。"""
        widget = QWidget()
        layout = QFormLayout(widget)

        self.oval_a = QDoubleSpinBox()
        self.oval_a.setRange(0.1, 1000.0)
        self.oval_a.setValue(15.0)
        self.oval_a.setSuffix(" mm")
        self.oval_a.setDecimals(2)
        layout.addRow("长轴 (A-axis):", self.oval_a)

        self.oval_b = QDoubleSpinBox()
        self.oval_b.setRange(0.1, 1000.0)
        self.oval_b.setValue(8.0)
        self.oval_b.setSuffix(" mm")
        self.oval_b.setDecimals(2)
        layout.addRow("短轴 (B-axis):", self.oval_b)

        self.oval_thickness = QDoubleSpinBox()
        self.oval_thickness.setRange(0.001, 10.0)
        self.oval_thickness.setValue(0.1)
        self.oval_thickness.setSuffix(" mm")
        self.oval_thickness.setDecimals(4)
        layout.addRow("厚度 (Thickness):", self.oval_thickness)

        self.oval_resistivity = QDoubleSpinBox()
        self.oval_resistivity.setRange(1e-12, 1e-2)
        self.oval_resistivity.setValue(1e-6)
        with contextlib.suppress(AttributeError):
            self.oval_resistivity.setNotation(QDoubleSpinBox.ScientificNotation)
        self.oval_resistivity.setDecimals(6)
        layout.addRow("电阻率 (Resistivity):", self.oval_resistivity)

        widget.hide()
        return widget

    def create_horseshoe_panel(self) -> QWidget:
        """创建马蹄形参数面板。"""
        widget = QWidget()
        layout = QFormLayout(widget)

        self.hs_width = QDoubleSpinBox()
        self.hs_width.setRange(0.1, 100.0)
        self.hs_width.setValue(5.0)
        self.hs_width.setSuffix(" mm")
        self.hs_width.setDecimals(2)
        layout.addRow("线宽 (Track Width):", self.hs_width)

        self.hs_gap = QDoubleSpinBox()
        self.hs_gap.setRange(0.5, 200.0)
        self.hs_gap.setValue(8.0)
        self.hs_gap.setSuffix(" mm")
        self.hs_gap.setDecimals(2)
        layout.addRow("间隙 (Gap):", self.hs_gap)

        self.hs_turns = QSpinBox()
        self.hs_turns.setRange(1, 10)
        self.hs_turns.setValue(2)
        layout.addRow("圈数 (Turns):", self.hs_turns)

        self.hs_thickness = QDoubleSpinBox()
        self.hs_thickness.setRange(0.001, 10.0)
        self.hs_thickness.setValue(0.1)
        self.hs_thickness.setSuffix(" mm")
        self.hs_thickness.setDecimals(4)
        layout.addRow("厚度 (Thickness):", self.hs_thickness)

        self.hs_resistivity = QDoubleSpinBox()
        self.hs_resistivity.setRange(1e-12, 1e-2)
        self.hs_resistivity.setValue(1e-6)
        with contextlib.suppress(AttributeError):
            self.hs_resistivity.setNotation(QDoubleSpinBox.ScientificNotation)
        self.hs_resistivity.setDecimals(6)
        layout.addRow("电阻率 (Resistivity):", self.hs_resistivity)

        widget.hide()
        return widget

    def create_meander_panel(self) -> QWidget:
        """创建蛇形/蜿蜒形状参数面板。"""
        widget = QWidget()
        layout = QFormLayout(widget)

        self.meander_length = QDoubleSpinBox()
        self.meander_length.setRange(1.0, 10000.0)
        self.meander_length.setValue(50.0)
        self.meander_length.setSuffix(" mm")
        self.meander_length.setDecimals(2)
        layout.addRow("总长度 (Total Length):", self.meander_length)

        self.meander_track = QDoubleSpinBox()
        self.meander_track.setRange(0.01, 50.0)
        self.meander_track.setValue(1.0)
        self.meander_track.setSuffix(" mm")
        self.meander_track.setDecimals(2)
        layout.addRow("线宽 (Track Width):", self.meander_track)

        self.meander_gap = QDoubleSpinBox()
        self.meander_gap.setRange(0.01, 50.0)
        self.meander_gap.setValue(1.0)
        self.meander_gap.setSuffix(" mm")
        self.meander_gap.setDecimals(2)
        layout.addRow("间距 (Gap):", self.meander_gap)

        self.meander_segments = QSpinBox()
        self.meander_segments.setRange(2, 100)
        self.meander_segments.setValue(10)
        layout.addRow("段数 (Segments):", self.meander_segments)

        self.meander_thickness = QDoubleSpinBox()
        self.meander_thickness.setRange(0.001, 10.0)
        self.meander_thickness.setValue(0.1)
        self.meander_thickness.setSuffix(" mm")
        self.meander_thickness.setDecimals(4)
        layout.addRow("厚度 (Thickness):", self.meander_thickness)

        self.meander_resistivity = QDoubleSpinBox()
        self.meander_resistivity.setRange(1e-12, 1e-2)
        self.meander_resistivity.setValue(1e-6)
        with contextlib.suppress(AttributeError):
            self.meander_resistivity.setNotation(QDoubleSpinBox.ScientificNotation)
        self.meander_resistivity.setDecimals(6)
        layout.addRow("电阻率 (Resistivity):", self.meander_resistivity)

        widget.hide()
        return widget

    def create_simulation_tab(self) -> QWidget:
        """创建仿真参数选项卡。"""
        widget = QWidget()
        layout = QFormLayout(widget)

        self.sim_current = QDoubleSpinBox()
        self.sim_current.setRange(0.001, 1000.0)
        self.sim_current.setValue(1.0)
        self.sim_current.setSuffix(" A")
        self.sim_current.setDecimals(4)
        layout.addRow("通电电流 (Current):", self.sim_current)

        self.sim_ambient = QDoubleSpinBox()
        self.sim_ambient.setRange(-50.0, 500.0)
        self.sim_ambient.setValue(25.0)
        self.sim_ambient.setSuffix(" °C")
        self.sim_ambient.setDecimals(1)
        layout.addRow("环境温度 (Ambient):", self.sim_ambient)

        self.sim_max_time = QDoubleSpinBox()
        self.sim_max_time.setRange(1.0, 10000.0)
        self.sim_max_time.setValue(1000.0)
        self.sim_max_time.setSuffix(" ms")
        self.sim_max_time.setDecimals(1)
        layout.addRow("最大时间 (Max Time):", self.sim_max_time)

        self.sim_time_step = QDoubleSpinBox()
        self.sim_time_step.setRange(0.1, 100.0)
        self.sim_time_step.setValue(1.0)
        self.sim_time_step.setSuffix(" ms")
        self.sim_time_step.setDecimals(2)
        layout.addRow("时间步长 (Time Step):", self.sim_time_step)

        self.sim_conductivity = QDoubleSpinBox()
        self.sim_conductivity.setRange(1.0, 500.0)
        self.sim_conductivity.setValue(237.0)
        self.sim_conductivity.setSuffix(" W/(m·K)")
        self.sim_conductivity.setDecimals(1)
        layout.addRow("热导率 (K):", self.sim_conductivity)

        self.sim_density = QDoubleSpinBox()
        self.sim_density.setRange(100.0, 20000.0)
        self.sim_density.setValue(2700.0)
        self.sim_density.setSuffix(" kg/m³")
        self.sim_density.setDecimals(0)
        layout.addRow("密度 (Density):", self.sim_density)

        self.sim_heat = QDoubleSpinBox()
        self.sim_heat.setRange(100.0, 5000.0)
        self.sim_heat.setValue(900.0)
        self.sim_heat.setSuffix(" J/(kg·K)")
        self.sim_heat.setDecimals(0)
        layout.addRow("比热容 (Cp):", self.sim_heat)

        return widget

    def create_result_panel(self) -> QWidget:
        """创建结果显示面板。"""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        result_group = QGroupBox("计算结果")
        result_layout = QVBoxLayout(result_group)

        self.result_text = QTextEdit()
        self.result_text.setReadOnly(True)
        result_layout.addWidget(self.result_text)

        layout.addWidget(result_group)

        plot_group = QGroupBox("可视化")
        plot_layout = QVBoxLayout(plot_group)

        view_layout = QHBoxLayout()
        self.resistance_view_btn = QPushButton("电阻分布")
        self.resistance_view_btn.clicked.connect(self.show_resistance_distribution)
        self.thermal_view_btn = QPushButton("温度曲线")
        self.thermal_view_btn.clicked.connect(self.show_thermal_curve)
        view_layout.addWidget(self.resistance_view_btn)
        view_layout.addWidget(self.thermal_view_btn)
        plot_layout.addLayout(view_layout)

        self.resistance_canvas = MplCanvas(self, width=6, height=4)
        self.thermal_canvas = MplCanvas(self, width=6, height=4)
        self.thermal_canvas.hide()

        plot_layout.addWidget(self.resistance_canvas)
        plot_layout.addWidget(self.thermal_canvas)

        layout.addWidget(plot_group)

        return widget

    def on_shape_changed(self, index: int):
        """处理形状选择变化。"""
        panels = [
            self.shape_stack.layout().itemAt(0).widget(),
            self.shape_stack.layout().itemAt(1).widget(),
            self.shape_stack.layout().itemAt(2).widget(),
            self.shape_stack.layout().itemAt(3).widget(),
            self.shape_stack.layout().itemAt(4).widget(),
        ]

        for i, panel in enumerate(panels):
            panel.hide() if i != index else panel.show()

    def get_current_sheet_geometry(self) -> SheetGeometry:
        """从 UI 获取当前电阻片几何参数。"""
        index = self.shape_combo.currentIndex()
        shapes = [
            ResistorShape.RECTANGLE,
            ResistorShape.CIRCULAR,
            ResistorShape.OVAL,
            ResistorShape.HORSESHOE,
            ResistorShape.meander,
        ]

        geometry = SheetGeometry(shape=shapes[index])

        if index == 0:
            geometry.width = self.rect_width.value()
            geometry.height = self.rect_height.value()
            geometry.thickness = self.rect_thickness.value()
            geometry.resistivity = self.rect_resistivity.value()
        elif index == 1:
            geometry.outer_radius = self.circ_outer.value()
            geometry.inner_radius = self.circ_inner.value()
            geometry.thickness = self.circ_thickness.value()
            geometry.resistivity = self.circ_resistivity.value()
        elif index == 2:
            geometry.oval_a = self.oval_a.value()
            geometry.oval_b = self.oval_b.value()
            geometry.thickness = self.oval_thickness.value()
            geometry.resistivity = self.oval_resistivity.value()
        elif index == 3:
            geometry.horseshoe_width = self.hs_width.value()
            geometry.horseshoe_gap = self.hs_gap.value()
            geometry.horseshoe_turns = self.hs_turns.value()
            geometry.thickness = self.hs_thickness.value()
            geometry.resistivity = self.hs_resistivity.value()
        elif index == 4:
            geometry.meander_length = self.meander_length.value()
            geometry.meander_track_width = self.meander_track.value()
            geometry.meander_gap = self.meander_gap.value()
            geometry.meander_segments = self.meander_segments.value()
            geometry.thickness = self.meander_thickness.value()
            geometry.resistivity = self.meander_resistivity.value()

        return geometry

    def calculate(self):
        """运行电阻计算。"""
        try:
            pin = PinGeometry(
                diameter=self.pin_diameter.value(),
                length=self.pin_length.value(),
                resistivity=self.pin_resistivity.value(),
            )

            sheet = self.get_current_sheet_geometry()

            simulation = SimulationParams(
                current=self.sim_current.value(),
                ambient_temp=self.sim_ambient.value(),
                max_time_ms=self.sim_max_time.value(),
                time_step_ms=self.sim_time_step.value(),
                thermal_conductivity=self.sim_conductivity.value(),
                density=self.sim_density.value(),
                specific_heat=self.sim_heat.value(),
            )

            self.result = calculate_resistor(pin, sheet, simulation)

            self.display_results()
            self.show_resistance_distribution()

            logger.info("计算完成")

        except Exception as e:  # noqa: BLE001
            self.result_text.setText(f"计算错误: {e}")
            logger.error(f"计算错误: {e}")

    def display_results(self):
        """显示计算结果。"""
        if self.result is None:
            return

        r = self.result
        thermal = r.thermal_result

        lines = []
        lines.append("=" * 60)
        lines.append("          材料电阻计算结果 / Resistance Results")
        lines.append("=" * 60)

        lines.append("\n【电阻参数 / Resistance Parameters】")
        lines.append(f"  引脚电阻:       {r.pin_resistance:.6e} Ω")
        lines.append(f"  电阻片电阻:     {r.sheet_resistance:.6e} Ω")
        lines.append(f"  总电阻:         {r.total_resistance:.6e} Ω")

        lines.append("\n【电气参数 / Electrical Parameters】")
        lines.append(f"  电压降:         {r.voltage_drop:.6f} V")
        lines.append(f"  功率耗散:       {r.power_dissipation:.6f} W")
        lines.append(f"  电流密度:       {r.current_density:.6e} A/m²")

        lines.append("\n【热参数 / Thermal Parameters】")
        lines.append(f"  环境温度:       {self.sim_ambient.value():.1f} °C")
        lines.append(f"  最终温度:       {thermal.max_temperature:.2f} °C")
        lines.append(
            f"  温升:          {thermal.max_temperature - self.sim_ambient.value():.2f} °C",
        )
        lines.append(f"  热时间常数:    {thermal.time_constant:.3f} s")

        lines.append("=" * 60)

        self.result_text.setText("\n".join(lines))

    def show_resistance_distribution(self):
        """显示带清晰边界的电阻分布图。"""
        if self.result is None:
            return

        self.resistance_canvas.show()
        self.thermal_canvas.hide()

        fig = self.resistance_canvas.figure
        fig.clf()
        ax = fig.add_subplot(111)

        dist = self.result.distribution_data
        X = dist["x"]
        Y = dist["y"]
        density = dist["resistance_density"]
        pin_density = dist.get("pin_density", None)
        shape = dist.get("shape", "rectangle")

        ax.set_facecolor("#1a1a2e")

        im = ax.pcolormesh(X, Y, density, cmap="coolwarm", shading="auto", vmin=0, vmax=1)

        if pin_density is not None:
            pin_mask = ~np.isnan(pin_density)
            if np.any(pin_mask):
                ax.scatter(X[pin_mask], Y[pin_mask], c="blue", s=2, alpha=0.8, label="引脚区域")

        ax.contour(
            X,
            Y,
            density,
            levels=[0.1, 0.3, 0.5, 0.7, 0.9],
            colors=["white"],
            linewidths=0.5,
            alpha=0.5,
        )

        if shape == "rectangle":
            ax.plot(
                [np.min(X), np.max(X), np.max(X), np.min(X), np.min(X)],
                [np.min(Y), np.min(Y), np.max(Y), np.max(Y), np.min(Y)],
                "w--",
                linewidth=2,
                alpha=0.8,
                label="边界",
            )
        elif shape == "circular":
            theta = np.linspace(0, 2 * np.pi, 100)
            outer_r = np.max(np.sqrt(X**2 + Y**2))
            ax.plot(
                outer_r * np.cos(theta),
                outer_r * np.sin(theta),
                "w--",
                linewidth=2,
                alpha=0.8,
                label="外边界",
            )
        elif shape == "oval":
            theta = np.linspace(0, 2 * np.pi, 100)
            a = np.max(np.abs(X))
            b = np.max(np.abs(Y))
            ax.plot(
                a * np.cos(theta), b * np.sin(theta), "w--", linewidth=2, alpha=0.8, label="边界",
            )

        ax.set_xlabel("X 位置 (mm)", fontsize=12, color="white")
        ax.set_ylabel("Y 位置 (mm)", fontsize=12, color="white")
        ax.set_title("电阻分布 / Resistance Distribution", fontsize=14, color="white")
        ax.set_aspect("equal")
        ax.tick_params(colors="white")

        cbar = fig.colorbar(im, ax=ax, label="电阻密度")
        cbar.set_label("电阻密度", color="white")
        cbar.ax.tick_params(colors="white")

        ax.legend()
        fig.tight_layout()
        self.resistance_canvas.draw()

    def show_thermal_curve(self):
        """显示温度升高曲线。"""
        if self.result is None:
            return

        self.resistance_canvas.hide()
        self.thermal_canvas.show()

        fig = self.thermal_canvas.figure
        fig.clf()
        ax = fig.add_subplot(111)

        thermal = self.result.thermal_result
        time_ms = thermal.time_points
        temps = thermal.temperature_points

        ax.plot(time_ms, temps, "r-", linewidth=2, label="温度 / Temperature")
        ax.axhline(
            y=thermal.equilibrium_temperature,
            color="g",
            linestyle="--",
            label=f"平衡温度 / Equilibrium: {thermal.equilibrium_temperature:.2f}°C",
        )

        ax.set_xlabel("时间 (ms)", fontsize=12)
        ax.set_ylabel("温度 (°C)", fontsize=12)
        ax.set_title("温度升高曲线 / Temperature Rise Curve", fontsize=14)
        ax.legend()
        ax.grid(True, alpha=0.3)

        fig.tight_layout()
        self.thermal_canvas.draw()


def main(example_name=None, auto_calculate=False):
    """GUI 主入口函数。

    Args:
        example_name: 可选的示例名称，用于自动加载
        auto_calculate: 是否自动计算
    """
    logger.info("启动材料电阻计算器 GUI")
    app = QApplication(sys.argv)
    window = ResistCalcGUI()
    window.show()
    sys.exit(app.exec())
