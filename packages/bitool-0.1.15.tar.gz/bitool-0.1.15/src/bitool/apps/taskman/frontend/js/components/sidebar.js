class Sidebar {
    constructor() {
        this.categoryList = document.getElementById('categoryList');
        this.tagList = document.getElementById('tagList');
        this.filterList = document.getElementById('filterList');
        
        this.categoryModal = document.getElementById('categoryModal');
        this.categoryForm = document.getElementById('categoryForm');
        this.tagModal = document.getElementById('tagModal');
        this.tagForm = document.getElementById('tagForm');
        
        this.attachEventListeners();
    }

    attachEventListeners() {
        document.getElementById('addCategoryBtn').addEventListener('click', () => this.openCategoryModal());
        document.getElementById('categoryModalClose').addEventListener('click', () => this.closeCategoryModal());
        document.getElementById('categoryCancelBtn').addEventListener('click', () => this.closeCategoryModal());
        this.categoryModal.querySelector('.modal-backdrop').addEventListener('click', () => this.closeCategoryModal());
        this.categoryForm.addEventListener('submit', (e) => this.handleCategorySubmit(e));

        document.getElementById('addTagBtn').addEventListener('click', () => this.openTagModal());
        document.getElementById('tagModalClose').addEventListener('click', () => this.closeTagModal());
        document.getElementById('tagCancelBtn').addEventListener('click', () => this.closeTagModal());
        this.tagModal.querySelector('.modal-backdrop').addEventListener('click', () => this.closeTagModal());
        this.tagForm.addEventListener('submit', (e) => this.handleTagSubmit(e));
    }

    async loadCategories() {
        try {
            const response = await TaskManAPI.getCategories();
            if (response.success) {
                this.renderCategories(response.data);
            }
        } catch (error) {
            console.error('Error loading categories:', error);
        }
    }

    renderCategories(categories) {
        this.categoryList.innerHTML = categories.map(cat => `
            <li class="category-item" data-id="${cat.id}">
                <div style="display: flex; align-items: center; flex: 1;">
                    <span class="category-color" style="background-color: ${cat.color}"></span>
                    <span class="category-name">${this.escapeHtml(cat.name)}</span>
                </div>
                <span class="category-count">${cat.task_count}</span>
            </li>
        `).join('');

        this.categoryList.querySelectorAll('.category-item').forEach(item => {
            item.addEventListener('click', () => {
                const categoryId = item.dataset.id;
                window.app.taskList.setCategory(parseInt(categoryId));
                this.setActiveCategory(categoryId);
            });

            item.addEventListener('dblclick', () => {
                const categoryId = item.dataset.id;
                this.editCategory(categoryId);
            });
        });
    }

    async loadTags() {
        try {
            const response = await TaskManAPI.getTags();
            if (response.success) {
                this.renderTags(response.data);
            }
        } catch (error) {
            console.error('Error loading tags:', error);
        }
    }

    renderTags(tags) {
        this.tagList.innerHTML = tags.map(tag => `
            <li class="tag-item" data-id="${tag.id}">
                <div style="display: flex; align-items: center; flex: 1;">
                    <span class="category-color" style="background-color: ${tag.color}"></span>
                    <span class="tag-name">${this.escapeHtml(tag.name)}</span>
                </div>
                <span class="tag-count">${tag.task_count}</span>
            </li>
        `).join('');

        this.tagList.querySelectorAll('.tag-item').forEach(item => {
            item.addEventListener('dblclick', () => {
                const tagId = item.dataset.id;
                this.editTag(tagId);
            });
        });
    }

    attachFilterListeners() {
        this.filterList.querySelectorAll('.filter-item').forEach(item => {
            item.addEventListener('click', () => {
                const filter = item.dataset.filter;
                window.app.taskList.setFilter(filter);
                this.setActiveFilter(filter);
            });
        });
    }

    setActiveCategory(categoryId) {
        this.categoryList.querySelectorAll('.category-item').forEach(item => {
            item.classList.toggle('active', item.dataset.id === categoryId);
        });
    }

    setActiveFilter(filter) {
        this.filterList.querySelectorAll('.filter-item').forEach(item => {
            item.classList.toggle('active', item.dataset.filter === filter);
        });
    }

    openCategoryModal(categoryId = null) {
        document.getElementById('categoryId').value = categoryId || '';
        document.getElementById('categoryName').value = '';
        document.getElementById('categoryColor').value = '#3B82F6';
        
        if (categoryId) {
            document.getElementById('categoryModalTitle').textContent = '编辑分类';
            this.loadCategoryForEdit(categoryId);
        } else {
            document.getElementById('categoryModalTitle').textContent = '添加分类';
        }
        
        this.categoryModal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    closeCategoryModal() {
        this.categoryModal.classList.remove('active');
        document.body.style.overflow = '';
    }

    async loadCategoryForEdit(categoryId) {
        try {
            const response = await TaskManAPI.getCategories();
            if (response.success) {
                const category = response.data.find(c => c.id === parseInt(categoryId));
                if (category) {
                    document.getElementById('categoryId').value = category.id;
                    document.getElementById('categoryName').value = category.name;
                    document.getElementById('categoryColor').value = category.color;
                }
            }
        } catch (error) {
            console.error('Error loading category:', error);
            window.app.showToast('加载分类失败', 'error');
        }
    }

    async editCategory(categoryId) {
        this.openCategoryModal(categoryId);
    }

    async handleCategorySubmit(e) {
        e.preventDefault();
        
        const categoryId = document.getElementById('categoryId').value;
        const categoryData = {
            name: document.getElementById('categoryName').value.trim(),
            color: document.getElementById('categoryColor').value
        };

        try {
            if (categoryId) {
                await TaskManAPI.updateCategory(parseInt(categoryId), categoryData);
                window.app.showToast('分类更新成功', 'success');
            } else {
                await TaskManAPI.createCategory(categoryData);
                window.app.showToast('分类创建成功', 'success');
            }
            
            this.closeCategoryModal();
            await this.loadCategories();
        } catch (error) {
            console.error('Error saving category:', error);
            window.app.showToast('保存分类失败', 'error');
        }
    }

    openTagModal(tagId = null) {
        document.getElementById('tagId').value = tagId || '';
        document.getElementById('tagName').value = '';
        document.getElementById('tagColor').value = '#8B5CF6';
        
        if (tagId) {
            document.getElementById('tagModalTitle').textContent = '编辑标签';
            this.loadTagForEdit(tagId);
        } else {
            document.getElementById('tagModalTitle').textContent = '添加标签';
        }
        
        this.tagModal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    closeTagModal() {
        this.tagModal.classList.remove('active');
        document.body.style.overflow = '';
    }

    async loadTagForEdit(tagId) {
        try {
            const response = await TaskManAPI.getTags();
            if (response.success) {
                const tag = response.data.find(t => t.id === parseInt(tagId));
                if (tag) {
                    document.getElementById('tagId').value = tag.id;
                    document.getElementById('tagName').value = tag.name;
                    document.getElementById('tagColor').value = tag.color;
                }
            }
        } catch (error) {
            console.error('Error loading tag:', error);
            window.app.showToast('加载标签失败', 'error');
        }
    }

    async editTag(tagId) {
        this.openTagModal(tagId);
    }

    async handleTagSubmit(e) {
        e.preventDefault();
        
        const tagId = document.getElementById('tagId').value;
        const tagData = {
            name: document.getElementById('tagName').value.trim(),
            color: document.getElementById('tagColor').value
        };

        try {
            if (tagId) {
                await TaskManAPI.updateTag(parseInt(tagId), tagData);
                window.app.showToast('标签更新成功', 'success');
            } else {
                await TaskManAPI.createTag(tagData);
                window.app.showToast('标签创建成功', 'success');
            }
            
            this.closeTagModal();
            await this.loadTags();
        } catch (error) {
            console.error('Error saving tag:', error);
            window.app.showToast('保存标签失败', 'error');
        }
    }

    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

window.Sidebar = Sidebar;
