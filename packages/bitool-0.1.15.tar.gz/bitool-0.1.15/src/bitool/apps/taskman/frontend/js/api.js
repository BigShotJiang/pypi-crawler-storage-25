class TaskManAPI {
    static get BASE_URL() {
        return API_CONFIG.getBaseUrl();
    }

    static async request(endpoint, options = {}) {
        const url = `${this.BASE_URL}${endpoint}`;
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
            },
        };
        const mergedOptions = { ...defaultOptions, ...options };

        try {
            const response = await fetch(url, mergedOptions);
            if (!response.ok) {
                const error = await response.json().catch(() => ({ detail: 'Request failed' }));
                throw new Error(error.detail || 'Request failed');
            }
            return response.json();
        } catch (error) {
            console.error(`API Error [${options.method || 'GET'} ${endpoint}]:`, error);
            throw error;
        }
    }

    static async getTasks(params = {}) {
        const queryString = new URLSearchParams(
            Object.entries(params).filter(([_, v]) => v != null)
        ).toString();
        return this.request(`/tasks${queryString ? '?' + queryString : ''}`);
    }

    static async getTask(id) {
        return this.request(`/tasks/${id}`);
    }

    static async createTask(data) {
        return this.request('/tasks', {
            method: 'POST',
            body: JSON.stringify(data),
        });
    }

    static async updateTask(id, data) {
        return this.request(`/tasks/${id}`, {
            method: 'PUT',
            body: JSON.stringify(data),
        });
    }

    static async deleteTask(id) {
        return this.request(`/tasks/${id}`, {
            method: 'DELETE',
        });
    }

    static async getCategories() {
        return this.request('/categories');
    }

    static async createCategory(data) {
        return this.request('/categories', {
            method: 'POST',
            body: JSON.stringify(data),
        });
    }

    static async updateCategory(id, data) {
        return this.request(`/categories/${id}`, {
            method: 'PUT',
            body: JSON.stringify(data),
        });
    }

    static async deleteCategory(id) {
        return this.request(`/categories/${id}`, {
            method: 'DELETE',
        });
    }

    static async getTags() {
        return this.request('/tags');
    }

    static async createTag(data) {
        return this.request('/tags', {
            method: 'POST',
            body: JSON.stringify(data),
        });
    }

    static async updateTag(id, data) {
        return this.request(`/tags/${id}`, {
            method: 'PUT',
            body: JSON.stringify(data),
        });
    }

    static async deleteTag(id) {
        return this.request(`/tags/${id}`, {
            method: 'DELETE',
        });
    }

    static async getStats() {
        return this.request('/stats');
    }
}

window.TaskManAPI = TaskManAPI;
