class TaskList {
    constructor() {
        this.container = document.getElementById('taskList');
        this.currentFilter = 'all';
        this.currentSort = 'created_at';
        this.currentCategory = null;
        this.searchQuery = '';
    }

    async render() {
        try {
            const params = {};
            if (this.currentFilter !== 'all') {
                params.status = this.currentFilter;
            }
            if (this.currentCategory) {
                params.category_id = this.currentCategory;
            }
            if (this.searchQuery) {
                params.search = this.searchQuery;
            }
            params.sort = this.currentSort;

            const response = await TaskManAPI.getTasks(params);
            
            if (response.success && response.data.length > 0) {
                this.renderTasks(response.data);
            } else {
                this.renderEmpty();
            }
        } catch (error) {
            console.error('Error loading tasks:', error);
            this.renderError('加载任务失败');
        }
    }

    renderTasks(tasks) {
        this.container.innerHTML = tasks.map(task => `
            <li class="task-item" data-id="${task.id}">
                <div class="task-checkbox ${task.status === 'completed' ? 'completed' : ''}" data-task-id="${task.id}">
                    ${task.status === 'completed' ? '<i class="fas fa-check"></i>' : ''}
                </div>
                <div class="task-content">
                    <div class="task-title ${task.status === 'completed' ? 'completed' : ''}">${this.escapeHtml(task.title)}</div>
                    ${task.description ? `<div class="task-description">${this.escapeHtml(task.description)}</div>` : ''}
                    <div class="task-meta">
                        <span class="priority-badge priority-${task.priority}">${this.getPriorityLabel(task.priority)}</span>
                        <span class="status-badge status-${task.status}">${this.getStatusLabel(task.status)}</span>
                        ${task.category ? `<span class="task-category" style="background-color: ${task.category.color}20; color: ${task.category.color}">${this.escapeHtml(task.category.name)}</span>` : ''}
                        ${task.tags.length > 0 ? `
                            <div class="task-tags">
                                ${task.tags.map(tag => `<span class="task-tag" style="background-color: ${tag.color}20; color: ${tag.color}">${this.escapeHtml(tag.name)}</span>`).join('')}
                            </div>
                        ` : ''}
                        ${task.due_date ? `<span class="task-due-date ${this.isOverdue(task.due_date, task.status) ? 'overdue' : ''}"><i class="fas fa-calendar"></i> ${task.due_date}</span>` : ''}
                    </div>
                </div>
                <div class="task-actions">
                    <button class="task-action-btn edit" data-task-id="${task.id}" title="编辑">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="task-action-btn delete" data-task-id="${task.id}" title="删除">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </li>
        `).join('');

        this.attachEventListeners();
    }

    renderEmpty() {
        this.container.innerHTML = `
            <li class="empty-state">
                <div class="empty-state-icon"><i class="fas fa-inbox"></i></div>
                <div class="empty-state-title">暂无任务</div>
                <div class="empty-state-description">点击右上角的"添加任务"按钮创建新任务</div>
            </li>
        `;
    }

    renderError(message) {
        this.container.innerHTML = `
            <li class="empty-state">
                <div class="empty-state-icon"><i class="fas fa-exclamation-triangle"></i></div>
                <div class="empty-state-title">出错了</div>
                <div class="empty-state-description">${message}</div>
            </li>
        `;
    }

    attachEventListeners() {
        this.container.querySelectorAll('.task-checkbox').forEach(checkbox => {
            checkbox.addEventListener('click', async (e) => {
                const taskId = checkbox.dataset.taskId;
                await this.toggleTaskStatus(taskId);
            });
        });

        this.container.querySelectorAll('.task-action-btn.edit').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const taskId = btn.dataset.taskId;
                window.app.editTask(taskId);
            });
        });

        this.container.querySelectorAll('.task-action-btn.delete').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const taskId = btn.dataset.taskId;
                if (confirm('确定要删除这个任务吗？')) {
                    await this.deleteTask(taskId);
                }
            });
        });

        this.container.querySelectorAll('.task-item').forEach(item => {
            item.addEventListener('click', (e) => {
                if (!e.target.closest('.task-checkbox') && 
                    !e.target.closest('.task-action-btn')) {
                    const taskId = item.dataset.id;
                    window.app.viewTask(taskId);
                }
            });
        });
    }

    async toggleTaskStatus(taskId) {
        try {
            const response = await TaskManAPI.getTask(taskId);
            if (response.success) {
                const task = response.data;
                let newStatus;
                if (task.status === 'pending') {
                    newStatus = 'in_progress';
                } else if (task.status === 'in_progress') {
                    newStatus = 'completed';
                } else if (task.status === 'completed') {
                    newStatus = 'pending';
                } else {
                    newStatus = 'pending';
                }

                await TaskManAPI.updateTask(taskId, { status: newStatus });
                window.app.showToast('任务状态已更新', 'success');
                await this.render();
                await window.app.loadStats();
            }
        } catch (error) {
            console.error('Error toggling task status:', error);
            window.app.showToast('更新任务状态失败', 'error');
        }
    }

    async deleteTask(taskId) {
        try {
            await TaskManAPI.deleteTask(taskId);
            window.app.showToast('任务删除成功', 'success');
            await this.render();
            await window.app.loadStats();
            await window.app.loadSidebar();
        } catch (error) {
            console.error('Error deleting task:', error);
            window.app.showToast('删除任务失败', 'error');
        }
    }

    setFilter(filter) {
        this.currentFilter = filter;
        this.render();
    }

    setCategory(categoryId) {
        this.currentCategory = categoryId;
        this.render();
    }

    setSearch(query) {
        this.searchQuery = query;
        this.render();
    }

    setSort(sort) {
        this.currentSort = sort;
        this.render();
    }

    getPriorityLabel(priority) {
        const labels = {
            'high': '高',
            'medium': '中',
            'low': '低'
        };
        return labels[priority] || priority;
    }

    getStatusLabel(status) {
        const labels = {
            'pending': '待办',
            'in_progress': '进行中',
            'completed': '已完成',
            'cancelled': '已取消'
        };
        return labels[status] || status;
    }

    isOverdue(dueDate, status) {
        if (status === 'completed' || status === 'cancelled') {
            return false;
        }
        const today = new Date().toISOString().split('T')[0];
        return dueDate < today;
    }

    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

window.TaskList = TaskList;
