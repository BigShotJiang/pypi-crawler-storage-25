class TaskModal {
    constructor() {
        this.modal = document.getElementById('taskModal');
        this.form = document.getElementById('taskForm');
        this.titleInput = document.getElementById('taskTitle');
        this.descriptionInput = document.getElementById('taskDescription');
        this.categorySelect = document.getElementById('taskCategory');
        this.prioritySelect = document.getElementById('taskPriority');
        this.statusSelect = document.getElementById('taskStatus');
        this.dueDateInput = document.getElementById('taskDueDate');
        this.tagSelector = document.getElementById('tagSelector');
        this.taskIdInput = document.getElementById('taskId');
        this.modalTitle = document.getElementById('modalTitle');
        
        this.isEditMode = false;
        this.selectedTagIds = [];
        
        this.attachEventListeners();
    }

    attachEventListeners() {
        document.getElementById('addTaskBtn').addEventListener('click', () => this.open());
        document.getElementById('modalClose').addEventListener('click', () => this.close());
        document.getElementById('cancelBtn').addEventListener('click', () => this.close());
        
        this.modal.querySelector('.modal-backdrop').addEventListener('click', () => this.close());
        
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
    }

    async open(taskId = null) {
        this.isEditMode = !!taskId;
        this.resetForm();
        await this.loadCategories();
        await this.loadTags();
        
        if (taskId) {
            this.modalTitle.textContent = '编辑任务';
            await this.loadTask(taskId);
        } else {
            this.modalTitle.textContent = '添加任务';
        }
        
        this.modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    close() {
        this.modal.classList.remove('active');
        document.body.style.overflow = '';
    }

    resetForm() {
        this.form.reset();
        this.taskIdInput.value = '';
        this.selectedTagIds = [];
        this.renderTagSelector([]);
    }

    async loadTask(taskId) {
        try {
            const response = await TaskManAPI.getTask(taskId);
            if (response.success) {
                const task = response.data;
                this.taskIdInput.value = task.id;
                this.titleInput.value = task.title;
                this.descriptionInput.value = task.description || '';
                this.categorySelect.value = task.category ? task.category.id : '';
                this.prioritySelect.value = task.priority;
                this.statusSelect.value = task.status;
                this.dueDateInput.value = task.due_date || '';
                
                this.selectedTagIds = task.tags.map(tag => tag.id);
                this.renderTagSelector(task.tags);
            }
        } catch (error) {
            console.error('Error loading task:', error);
            window.app.showToast('加载任务失败', 'error');
        }
    }

    async loadCategories() {
        try {
            const response = await TaskManAPI.getCategories();
            if (response.success) {
                this.categorySelect.innerHTML = '<option value="">无分类</option>' +
                    response.data.map(cat => 
                        `<option value="${cat.id}">${this.escapeHtml(cat.name)}</option>`
                    ).join('');
            }
        } catch (error) {
            console.error('Error loading categories:', error);
        }
    }

    async loadTags() {
        try {
            const response = await TaskManAPI.getTags();
            if (response.success) {
                this.allTags = response.data;
            }
        } catch (error) {
            console.error('Error loading tags:', error);
        }
    }

    renderTagSelector(selectedTags = []) {
        if (!this.allTags) return;
        
        this.tagSelector.innerHTML = this.allTags.map(tag => {
            const isSelected = this.selectedTagIds.includes(tag.id);
            return `
                <div class="tag-selector-item ${isSelected ? 'selected' : ''}" 
                     data-tag-id="${tag.id}"
                     style="background-color: ${tag.color}20; color: ${tag.color}; border-color: ${isSelected ? tag.color : 'transparent'}">
                    ${this.escapeHtml(tag.name)}
                </div>
            `;
        }).join('');

        this.tagSelector.querySelectorAll('.tag-selector-item').forEach(item => {
            item.addEventListener('click', () => {
                const tagId = parseInt(item.dataset.tagId);
                if (this.selectedTagIds.includes(tagId)) {
                    this.selectedTagIds = this.selectedTagIds.filter(id => id !== tagId);
                } else {
                    this.selectedTagIds.push(tagId);
                }
                const tag = this.allTags.find(t => t.id === tagId);
                this.renderTagSelector(this.allTags);
            });
        });
    }

    async handleSubmit(e) {
        e.preventDefault();
        
        const taskData = {
            title: this.titleInput.value.trim(),
            description: this.descriptionInput.value.trim(),
            category_id: this.categorySelect.value ? parseInt(this.categorySelect.value) : null,
            priority: this.prioritySelect.value,
            status: this.statusSelect.value,
            due_date: this.dueDateInput.value || null,
            tag_ids: this.selectedTagIds
        };

        try {
            if (this.isEditMode) {
                const taskId = this.taskIdInput.value;
                await TaskManAPI.updateTask(taskId, taskData);
                window.app.showToast('任务更新成功', 'success');
            } else {
                await TaskManAPI.createTask(taskData);
                window.app.showToast('任务创建成功', 'success');
            }
            
            this.close();
            await window.app.loadTasks();
            await window.app.loadStats();
            await window.app.loadSidebar();
        } catch (error) {
            console.error('Error saving task:', error);
            window.app.showToast('保存任务失败', 'error');
        }
    }

    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

window.TaskModal = TaskModal;
