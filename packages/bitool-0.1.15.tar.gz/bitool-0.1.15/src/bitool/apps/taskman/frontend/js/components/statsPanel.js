class StatsPanel {
    constructor() {
        this.container = document.getElementById('statsPanel');
    }

    async render() {
        try {
            const response = await TaskManAPI.getStats();
            if (response.success) {
                this.renderStats(response.data);
            }
        } catch (error) {
            console.error('Error loading stats:', error);
            this.renderError();
        }
    }

    renderStats(stats) {
        const completionRate = stats.completion_rate || 0;
        
        this.container.innerHTML = `
            <div class="stat-card">
                <div class="stat-card-header">
                    <span class="stat-card-title">总任务数</span>
                    <div class="stat-card-icon" style="background-color: var(--primary-light); color: var(--primary-color);">
                        <i class="fas fa-tasks"></i>
                    </div>
                </div>
                <div class="stat-card-value">${stats.total_tasks}</div>
                <div class="stat-card-subtitle">所有任务</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-card-header">
                    <span class="stat-card-title">待办任务</span>
                    <div class="stat-card-icon" style="background-color: var(--gray-100); color: var(--gray-600);">
                        <i class="fas fa-clock"></i>
                    </div>
                </div>
                <div class="stat-card-value">${stats.pending_tasks}</div>
                <div class="stat-card-subtitle">等待处理</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-card-header">
                    <span class="stat-card-title">进行中</span>
                    <div class="stat-card-icon" style="background-color: var(--primary-light); color: var(--primary-color);">
                        <i class="fas fa-spinner"></i>
                    </div>
                </div>
                <div class="stat-card-value">${stats.in_progress_tasks}</div>
                <div class="stat-card-subtitle">正在处理</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-card-header">
                    <span class="stat-card-title">已完成</span>
                    <div class="stat-card-icon" style="background-color: var(--success-light); color: var(--success-color);">
                        <i class="fas fa-check"></i>
                    </div>
                </div>
                <div class="stat-card-value">${stats.completed_tasks}</div>
                <div class="stat-card-subtitle">完成率 ${completionRate}%</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-card-header">
                    <span class="stat-card-title">高优先级</span>
                    <div class="stat-card-icon" style="background-color: var(--danger-light); color: var(--danger-color);">
                        <i class="fas fa-exclamation-circle"></i>
                    </div>
                </div>
                <div class="stat-card-value">${stats.high_priority_tasks}</div>
                <div class="stat-card-subtitle">需要关注</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-card-header">
                    <span class="stat-card-title">已逾期</span>
                    <div class="stat-card-icon" style="background-color: var(--warning-light); color: var(--warning-color);">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                </div>
                <div class="stat-card-value">${stats.overdue_tasks}</div>
                <div class="stat-card-subtitle">需要处理</div>
            </div>
        `;
    }

    renderError() {
        this.container.innerHTML = `
            <div class="stat-card">
                <div class="stat-card-header">
                    <span class="stat-card-title">统计</span>
                </div>
                <div class="stat-card-value">-</div>
                <div class="stat-card-subtitle">加载失败</div>
            </div>
        `;
    }
}

window.StatsPanel = StatsPanel;
