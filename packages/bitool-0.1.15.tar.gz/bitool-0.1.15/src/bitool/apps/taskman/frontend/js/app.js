class TaskManApp {
    constructor() {
        this.taskList = new TaskList();
        this.taskModal = new TaskModal();
        this.sidebar = new Sidebar();
        this.statsPanel = new StatsPanel();
        this.searchTimeout = null;
    }

    async init() {
        await this.loadSidebar();
        await this.loadTasks();
        await this.loadStats();
        this.attachGlobalEventListeners();
    }

    attachGlobalEventListeners() {
        const searchInput = document.getElementById('searchInput');
        searchInput.addEventListener('input', (e) => {
            clearTimeout(this.searchTimeout);
            this.searchTimeout = setTimeout(() => {
                const query = e.target.value.trim();
                this.taskList.setSearch(query);
            }, 300);
        });

        const sortSelect = document.getElementById('sortSelect');
        sortSelect.addEventListener('change', (e) => {
            this.taskList.setSort(e.target.value);
        });
    }

    async loadSidebar() {
        await this.sidebar.loadCategories();
        await this.sidebar.loadTags();
        this.sidebar.attachFilterListeners();
    }

    async loadTasks() {
        await this.taskList.render();
    }

    async loadStats() {
        await this.statsPanel.render();
    }

    async editTask(taskId) {
        await this.taskModal.open(taskId);
    }

    async viewTask(taskId) {
        await this.taskModal.open(taskId);
    }

    showToast(message, type = 'success') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        
        let icon = '';
        if (type === 'success') {
            icon = '<i class="fas fa-check-circle"></i>';
        } else if (type === 'error') {
            icon = '<i class="fas fa-exclamation-circle"></i>';
        } else if (type === 'warning') {
            icon = '<i class="fas fa-exclamation-triangle"></i>';
        }
        
        toast.innerHTML = `
            <span class="toast-icon">${icon}</span>
            <span class="toast-message">${message}</span>
        `;
        
        container.appendChild(toast);
        
        setTimeout(() => {
            toast.style.animation = 'toastSlideIn 0.3s ease reverse';
            setTimeout(() => {
                container.removeChild(toast);
            }, 300);
        }, 3000);
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    window.app = new TaskManApp();
    await window.app.init();
});
