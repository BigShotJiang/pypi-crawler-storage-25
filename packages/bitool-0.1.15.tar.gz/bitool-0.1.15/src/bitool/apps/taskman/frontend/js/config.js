const API_CONFIG = {
    getBaseUrl: function() {
        const params = new URLSearchParams(window.location.search);
        const configUrl = params.get('api');
        if (configUrl) {
            return configUrl;
        }
        return localStorage.getItem('taskman_api_url') || 'http://localhost:8000/api';
    },
    setBaseUrl: function(url) {
        localStorage.setItem('taskman_api_url', url);
    },
    getApiRoot: function() {
        return this.getBaseUrl().replace('/api', '');
    }
};

window.API_CONFIG = API_CONFIG;
