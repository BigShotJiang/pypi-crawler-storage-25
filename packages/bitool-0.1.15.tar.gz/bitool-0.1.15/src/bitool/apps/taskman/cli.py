"""TaskMan CLI - 多线任务管理系统的命令行工具."""

from __future__ import annotations

import argparse
import contextlib
import os
import sys
import webbrowser
from pathlib import Path


class TaskManCLI:
    """TaskMan CLI 主类."""

    def __init__(self) -> None:
        self.project_root = Path(__file__).parent
        self.backend_dir = self.project_root / "backend"
        self.frontend_dir = self.project_root / "frontend"
        self.backend_host = "0.0.0.0"  # noqa: S104
        self.backend_port = 8000
        self.frontend_port = 3000

    def run_backend(
        self,
        host: str = "0.0.0.0",  # noqa: S104
        port: int = 8000,
        reload: bool = False,
        log_level: str = "info",
    ) -> None:
        """启动后端服务.

        Args:
            host: 监听地址
            port: 监听端口
            reload: 是否启用热重载
            log_level: 日志级别
        """
        try:
            import uvicorn
        except ImportError:
            sys.exit(1)

        os.chdir(self.backend_dir)
        sys.path.insert(0, str(self.backend_dir))

        uvicorn.run(
            "app.main:app",
            host=host,
            port=port,
            reload=reload,
            log_level=log_level,
        )

    def run_frontend(
        self,
        host: str = "0.0.0.0",  # noqa: S104
        port: int = 3000,
        open_browser: bool = True,
    ) -> None:
        """启动前端开发服务器.

        Args:
            host: 监听地址
            port: 监听端口
            open_browser: 是否自动打开浏览器
        """
        import http.server
        import socketserver

        os.chdir(self.frontend_dir)

        class Handler(http.server.SimpleHTTPRequestHandler):
            def end_headers(self) -> None:
                self.send_header("Access-Control-Allow-Origin", "*")
                super().end_headers()

        with socketserver.TCPServer(("", port), Handler) as httpd:
            url = f"http://localhost:{port}"
            if open_browser:
                webbrowser.open(url)
            with contextlib.suppress(KeyboardInterrupt):
                httpd.serve_forever()

    def start_all(
        self,
        backend_host: str = "0.0.0.0",  # noqa: S104
        backend_port: int = 8000,
        frontend_port: int = 3000,
        open_browser: bool = True,
        reload: bool = False,
    ) -> None:
        """同时启动前后端服务.

        Args:
            backend_host: 后端监听地址
            backend_port: 后端监听端口
            frontend_port: 前端监听端口
            open_browser: 是否自动打开浏览器
            reload: 后端是否启用热重载
        """
        import threading
        import time

        frontend_thread = threading.Thread(
            target=self.run_frontend,
            args=("0.0.0.0", frontend_port, open_browser),  # noqa: S104
            daemon=True,
        )
        frontend_thread.start()

        time.sleep(1)

        self.run_backend(
            host=backend_host,
            port=backend_port,
            reload=reload,
            log_level="info",
        )


def create_parser() -> argparse.ArgumentParser:
    """创建命令行参数解析器."""
    parser = argparse.ArgumentParser(
        description="TaskMan - 多线任务管理系统",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  taskman start              # 启动前后端服务
  taskman backend            # 仅启动后端
  taskman frontend           # 仅启动前端
  taskman --help             # 显示帮助
        """,
    )

    subparsers = parser.add_subparsers(dest="command", help="可用命令")

    start_parser = subparsers.add_parser("start", help="启动前后端服务")
    start_parser.add_argument(
        "--backend-host",
        default="0.0.0.0",  # noqa: S104
        help="后端监听地址 (默认: 0.0.0.0)",
    )
    start_parser.add_argument(
        "--backend-port",
        type=int,
        default=8000,
        help="后端监听端口 (默认: 8000)",
    )
    start_parser.add_argument(
        "--frontend-port",
        type=int,
        default=3000,
        help="前端监听端口 (默认: 3000)",
    )
    start_parser.add_argument(
        "--no-browser",
        action="store_true",
        help="不自动打开浏览器",
    )
    start_parser.add_argument("--reload", action="store_true", help="启用后端热重载")

    backend_parser = subparsers.add_parser("backend", help="仅启动后端服务")
    backend_parser.add_argument(
        "--host",
        default="0.0.0.0",  # noqa: S104
        help="监听地址 (默认: 0.0.0.0)",
    )
    backend_parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="监听端口 (默认: 8000)",
    )
    backend_parser.add_argument("--reload", action="store_true", help="启用热重载")
    backend_parser.add_argument(
        "--log-level",
        default="info",
        choices=["debug", "info", "warning", "error"],
        help="日志级别 (默认: info)",
    )

    frontend_parser = subparsers.add_parser("frontend", help="仅启动前端服务")
    frontend_parser.add_argument(
        "--port",
        type=int,
        default=3000,
        help="监听端口 (默认: 3000)",
    )
    frontend_parser.add_argument(
        "--no-browser",
        action="store_true",
        help="不自动打开浏览器",
    )

    subparsers.add_parser("help", help="显示帮助").set_defaults(command="help")

    return parser


def main() -> int:
    """CLI 主入口."""
    parser = create_parser()
    args = parser.parse_args()

    cli = TaskManCLI()

    if args.command is None or args.command == "help":
        parser.print_help()
        return 0

    try:
        if args.command == "start":
            cli.start_all(
                backend_host=args.backend_host,
                backend_port=args.backend_port,
                frontend_port=args.frontend_port,
                open_browser=not args.no_browser,
                reload=args.reload,
            )
        elif args.command == "backend":
            cli.run_backend(
                host=args.host,
                port=args.port,
                reload=args.reload,
                log_level=args.log_level,
            )
        elif args.command == "frontend":
            cli.run_frontend(port=args.port, open_browser=not args.no_browser)
        return 0  # noqa: TRY300

    except KeyboardInterrupt:
        return 0
    except Exception:  # noqa: BLE001
        import traceback

        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
