"""TaskMan 后端应用包."""

from .main import app, create_app

__all__ = ["app", "create_app"]
