"""Tags module for routers."""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Tag
from app.schemas import TagCreate, TagUpdate

router = APIRouter()


@router.get("", response_model=dict)
def get_tags(db: Session = Depends(get_db)):
    tags = db.query(Tag).all()

    tag_list = []
    for tag in tags:
        active_tasks = [t for t in tag.tasks if t.deleted_at is None]
        tag_dict = {
            "id": tag.id,
            "name": tag.name,
            "color": tag.color,
            "task_count": len(active_tasks),
            "created_at": tag.created_at,
        }
        tag_list.append(tag_dict)

    return {"success": True, "data": tag_list}


@router.post("", response_model=dict)
def create_tag(tag_data: TagCreate, db: Session = Depends(get_db)):
    existing = db.query(Tag).filter(Tag.name == tag_data.name).first()
    if existing:
        raise HTTPException(status_code=400, detail="标签名称已存在")

    new_tag = Tag(name=tag_data.name, color=tag_data.color)

    db.add(new_tag)
    db.commit()
    db.refresh(new_tag)

    return {
        "success": True,
        "data": {"id": new_tag.id, "name": new_tag.name, "message": "标签创建成功"},
    }


@router.put("/{tag_id}", response_model=dict)
def update_tag(tag_id: int, tag_data: TagUpdate, db: Session = Depends(get_db)):
    tag = db.query(Tag).filter(Tag.id == tag_id).first()

    if not tag:
        raise HTTPException(status_code=404, detail="标签不存在")

    if tag_data.name and tag_data.name != tag.name:
        existing = db.query(Tag).filter(Tag.name == tag_data.name).first()
        if existing:
            raise HTTPException(status_code=400, detail="标签名称已存在")

    update_data = tag_data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(tag, key, value)

    db.commit()
    db.refresh(tag)

    return {"success": True, "data": {"id": tag.id, "message": "标签更新成功"}}


@router.delete("/{tag_id}", response_model=dict)
def delete_tag(tag_id: int, db: Session = Depends(get_db)):
    tag = db.query(Tag).filter(Tag.id == tag_id).first()

    if not tag:
        raise HTTPException(status_code=404, detail="标签不存在")

    db.delete(tag)
    db.commit()

    return {"success": True, "data": {"id": tag_id, "message": "标签删除成功"}}