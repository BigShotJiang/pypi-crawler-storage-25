"""Stats module for routers."""

from datetime import datetime, timezone

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Category, Task

router = APIRouter()


@router.get("", response_model=dict)
def get_stats(db: Session = Depends(get_db)):
    tasks = db.query(Task).filter(Task.deleted_at.is_(None)).all()

    total_tasks = len(tasks)
    pending_tasks = len([t for t in tasks if t.status == "pending"])
    in_progress_tasks = len([t for t in tasks if t.status == "in_progress"])
    completed_tasks = len([t for t in tasks if t.status == "completed"])
    cancelled_tasks = len([t for t in tasks if t.status == "cancelled"])

    completion_rate = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0

    high_priority_tasks = len([t for t in tasks if t.priority == "high"])
    medium_priority_tasks = len([t for t in tasks if t.priority == "medium"])
    low_priority_tasks = len([t for t in tasks if t.priority == "low"])

    today = datetime.now(tz=timezone.utc).date()
    overdue_tasks = len(
        [
            t
            for t in tasks
            if t.due_date
            and t.due_date < today
            and t.status not in ["completed", "cancelled"]
        ],
    )

    categories = db.query(Category).all()
    tasks_by_category = []
    for category in categories:
        active_tasks = [t for t in category.tasks if t.deleted_at is None]
        tasks_by_category.append(
            {"category": category.name, "count": len(active_tasks)},
        )

    uncategorized_count = len([t for t in tasks if t.category_id is None])
    if uncategorized_count > 0:
        tasks_by_category.append({"category": "未分类", "count": uncategorized_count})

    return {
        "success": True,
        "data": {
            "total_tasks": total_tasks,
            "pending_tasks": pending_tasks,
            "in_progress_tasks": in_progress_tasks,
            "completed_tasks": completed_tasks,
            "cancelled_tasks": cancelled_tasks,
            "completion_rate": round(completion_rate, 1),
            "high_priority_tasks": high_priority_tasks,
            "medium_priority_tasks": medium_priority_tasks,
            "low_priority_tasks": low_priority_tasks,
            "overdue_tasks": overdue_tasks,
            "tasks_by_category": tasks_by_category,
        },
    }