"""TaskMan 后端应用入口."""

from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import engine
from app.models import Base
from app.routers import categories, stats, tags, tasks


@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理."""
    from pathlib import Path

    data_dir = Path(__file__).parent.parent / "backend" / "data"
    data_dir.mkdir(parents=True, exist_ok=True)

    Base.metadata.create_all(bind=engine)
    yield


def create_app() -> FastAPI:
    """创建 FastAPI 应用实例."""
    app = FastAPI(
        title="TaskMan API",
        description="多线任务管理系统 API",
        version="1.0.0",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(tasks.router, prefix="/api/tasks", tags=["Tasks"])
    app.include_router(categories.router, prefix="/api/categories", tags=["Categories"])
    app.include_router(tags.router, prefix="/api/tags", tags=["Tags"])
    app.include_router(stats.router, prefix="/api/stats", tags=["Stats"])

    @app.get("/")
    async def root():
        return {
            "message": "TaskMan API is running",
            "version": "1.0.0",
            "docs": "/docs",
        }

    @app.get("/health")
    async def health_check():
        return {"status": "healthy"}

    return app


app = create_app()
