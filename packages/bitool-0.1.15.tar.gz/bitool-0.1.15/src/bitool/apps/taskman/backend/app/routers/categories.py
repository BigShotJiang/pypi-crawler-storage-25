"""Categories module for routers."""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Category, Task
from app.schemas import CategoryCreate, CategoryUpdate

router = APIRouter()


@router.get("", response_model=dict)
def get_categories(db: Session = Depends(get_db)):
    categories = db.query(Category).all()

    category_list = []
    for category in categories:
        active_tasks = [t for t in category.tasks if t.deleted_at is None]
        category_dict = {
            "id": category.id,
            "name": category.name,
            "color": category.color,
            "task_count": len(active_tasks),
            "created_at": category.created_at,
        }
        category_list.append(category_dict)

    return {"success": True, "data": category_list}


@router.post("", response_model=dict)
def create_category(category_data: CategoryCreate, db: Session = Depends(get_db)):
    existing = db.query(Category).filter(Category.name == category_data.name).first()
    if existing:
        raise HTTPException(status_code=400, detail="分类名称已存在")

    new_category = Category(name=category_data.name, color=category_data.color)

    db.add(new_category)
    db.commit()
    db.refresh(new_category)

    return {
        "success": True,
        "data": {
            "id": new_category.id,
            "name": new_category.name,
            "message": "分类创建成功",
        },
    }


@router.put("/{category_id}", response_model=dict)
def update_category(
    category_id: int,
    category_data: CategoryUpdate,
    db: Session = Depends(get_db),
):
    category = db.query(Category).filter(Category.id == category_id).first()

    if not category:
        raise HTTPException(status_code=404, detail="分类不存在")

    if category_data.name and category_data.name != category.name:
        existing = (
            db.query(Category).filter(Category.name == category_data.name).first()
        )
        if existing:
            raise HTTPException(status_code=400, detail="分类名称已存在")

    update_data = category_data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(category, key, value)

    db.commit()
    db.refresh(category)

    return {"success": True, "data": {"id": category.id, "message": "分类更新成功"}}


@router.delete("/{category_id}", response_model=dict)
def delete_category(category_id: int, db: Session = Depends(get_db)):
    category = db.query(Category).filter(Category.id == category_id).first()

    if not category:
        raise HTTPException(status_code=404, detail="分类不存在")

    tasks_with_category = db.query(Task).filter(Task.category_id == category_id).all()
    for task in tasks_with_category:
        task.category_id = None

    db.delete(category)
    db.commit()

    return {"success": True, "data": {"id": category_id, "message": "分类删除成功"}}