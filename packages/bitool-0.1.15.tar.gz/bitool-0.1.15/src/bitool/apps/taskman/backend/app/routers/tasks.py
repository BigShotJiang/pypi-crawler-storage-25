"""Tasks module for routers."""

from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Tag, Task
from app.schemas import TaskCreate, TaskUpdate

router = APIRouter()


@router.get("", response_model=dict)
def get_tasks(
    status: Optional[str] = None,
    priority: Optional[str] = None,
    category_id: Optional[int] = None,
    search: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    query = db.query(Task).filter(Task.deleted_at.is_(None))

    if status:
        query = query.filter(Task.status == status)
    if priority:
        query = query.filter(Task.priority == priority)
    if category_id:
        query = query.filter(Task.category_id == category_id)
    if search:
        search_pattern = f"%{search}%"
        query = query.filter(
            or_(Task.title.like(search_pattern), Task.description.like(search_pattern)),
        )

    total = query.count()
    tasks = (
        query.order_by(Task.created_at.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )

    task_list = []
    for task in tasks:
        task_dict = {
            "id": task.id,
            "title": task.title,
            "description": task.description,
            "status": task.status,
            "priority": task.priority,
            "category": {
                "id": task.category.id,
                "name": task.category.name,
                "color": task.category.color,
                "task_count": len(task.category.tasks),
                "created_at": task.category.created_at,
            }
            if task.category
            else None,
            "tags": [
                {
                    "id": tag.id,
                    "name": tag.name,
                    "color": tag.color,
                    "task_count": len(tag.tasks),
                    "created_at": tag.created_at,
                }
                for tag in task.tags
            ],
            "due_date": task.due_date,
            "created_at": task.created_at,
            "updated_at": task.updated_at,
        }
        task_list.append(task_dict)

    return {
        "success": True,
        "data": task_list,
        "total": total,
        "page": page,
        "page_size": page_size,
    }


@router.post("", response_model=dict)
def create_task(task_data: TaskCreate, db: Session = Depends(get_db)):
    new_task = Task(
        title=task_data.title,
        description=task_data.description,
        status=task_data.status,
        priority=task_data.priority,
        category_id=task_data.category_id,
        due_date=task_data.due_date,
    )

    if task_data.tag_ids:
        tags = db.query(Tag).filter(Tag.id.in_(task_data.tag_ids)).all()
        new_task.tags = tags

    db.add(new_task)
    db.commit()
    db.refresh(new_task)

    return {
        "success": True,
        "data": {"id": new_task.id, "title": new_task.title, "message": "任务创建成功"},
    }


@router.get("/{task_id}", response_model=dict)
def get_task(task_id: int, db: Session = Depends(get_db)):
    task = db.query(Task).filter(Task.id == task_id, Task.deleted_at.is_(None)).first()

    if not task:
        raise HTTPException(status_code=404, detail="任务不存在")

    return {
        "success": True,
        "data": {
            "id": task.id,
            "title": task.title,
            "description": task.description,
            "status": task.status,
            "priority": task.priority,
            "category": {
                "id": task.category.id,
                "name": task.category.name,
                "color": task.category.color,
                "task_count": len(task.category.tasks),
                "created_at": task.category.created_at,
            }
            if task.category
            else None,
            "tags": [
                {
                    "id": tag.id,
                    "name": tag.name,
                    "color": tag.color,
                    "task_count": len(tag.tasks),
                    "created_at": tag.created_at,
                }
                for tag in task.tags
            ],
            "due_date": task.due_date,
            "created_at": task.created_at,
            "updated_at": task.updated_at,
        },
    }


@router.put("/{task_id}", response_model=dict)
def update_task(task_id: int, task_data: TaskUpdate, db: Session = Depends(get_db)):
    task = db.query(Task).filter(Task.id == task_id, Task.deleted_at.is_(None)).first()

    if not task:
        raise HTTPException(status_code=404, detail="任务不存在")

    update_data = task_data.model_dump(exclude_unset=True)
    tag_ids = update_data.pop("tag_ids", None)

    for key, value in update_data.items():
        setattr(task, key, value)

    if tag_ids is not None:
        tags = db.query(Tag).filter(Tag.id.in_(tag_ids)).all()
        task.tags = tags

    task.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(task)

    return {"success": True, "data": {"id": task.id, "message": "任务更新成功"}}


@router.delete("/{task_id}", response_model=dict)
def delete_task(task_id: int, db: Session = Depends(get_db)):
    task = db.query(Task).filter(Task.id == task_id, Task.deleted_at.is_(None)).first()

    if not task:
        raise HTTPException(status_code=404, detail="任务不存在")

    task.deleted_at = datetime.now(timezone.utc)
    db.commit()

    return {"success": True, "data": {"id": task_id, "message": "任务删除成功"}}