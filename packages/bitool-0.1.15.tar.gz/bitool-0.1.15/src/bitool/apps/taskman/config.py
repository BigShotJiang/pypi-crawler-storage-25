"""TaskMan 配置管理模块."""

from __future__ import annotations

import os
from pathlib import Path


class Config:
    """TaskMan 配置类."""

    def __init__(self) -> None:
        self.project_root = Path(__file__).parent.parent.parent
        self.backend_dir = self.project_root / "backend"
        self.frontend_dir = self.project_root / "frontend"
        self.data_dir = self.backend_dir / "data"

        self._backend_host = os.getenv("TASKMAN_BACKEND_HOST", "0.0.0.0")  # noqa: S104
        self._backend_port = int(os.getenv("TASKMAN_BACKEND_PORT", "8000"))
        self._frontend_port = int(os.getenv("TASKMAN_FRONTEND_PORT", "3000"))
        self._api_base_url = os.getenv(
            "TASKMAN_API_BASE_URL",
            f"http://localhost:{self._backend_port}",
        )

    @property
    def backend_host(self) -> str:
        return self._backend_host

    @backend_host.setter
    def backend_host(self, value: str) -> None:
        self._backend_host = value

    @property
    def backend_port(self) -> int:
        return self._backend_port

    @backend_port.setter
    def backend_port(self, value: int) -> None:
        self._backend_port = value
        if self._api_base_url == f"http://localhost:{self._backend_port - 1}":
            self._api_base_url = f"http://localhost:{value}"

    @property
    def frontend_port(self) -> int:
        return self._frontend_port

    @frontend_port.setter
    def frontend_port(self, value: int) -> None:
        self._frontend_port = value

    @property
    def api_base_url(self) -> str:
        return self._api_base_url

    @api_base_url.setter
    def api_base_url(self, value: str) -> None:
        self._api_base_url = value

    @property
    def database_url(self) -> str:
        return f"sqlite:///{self.data_dir}/taskman.db"

    def ensure_directories(self) -> None:
        """确保必要的目录存在."""
        self.data_dir.mkdir(parents=True, exist_ok=True)

    def to_dict(self) -> dict:
        """转换为字典."""
        return {
            "backend_host": self.backend_host,
            "backend_port": self.backend_port,
            "frontend_port": self.frontend_port,
            "api_base_url": self.api_base_url,
            "database_url": self.database_url,
        }


config = Config()
