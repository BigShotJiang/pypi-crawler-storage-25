# TaskMan - 多线任务管理系统

## 项目简介

TaskMan 是一个现代化的多线任务管理系统，采用前后端分离架构，使用 Python FastAPI 作为后端框架，前端使用原生 JavaScript 构建响应式界面，后端数据持久化采用 SQLite 数据库。

## 技术栈

### 后端
- Python 3.10+
- FastAPI - Web 框架
- SQLAlchemy - ORM
- SQLite - 数据库
- Pydantic - 数据验证

### 前端
- HTML5 / CSS3
- 原生 JavaScript (ES6+)
- Font Awesome 6 - 图标库
- Google Fonts - 字体

## 快速开始

### 方式一：使用 taskman 命令（推荐）

#### 1. 安装依赖

```bash
cd apps/taskman/backend
pip install -r requirements.txt
```

#### 2. 启动服务

```bash
# 启动前后端服务
python -m bitool.apps.taskman start

# 仅启动后端
python -m bitool.apps.taskman backend

# 仅启动前端
python -m bitool.apps.taskman frontend
```

#### 3. 使用快捷脚本

在 Windows 上可以直接运行 `taskman.bat`：

```bash
taskman.bat
```

或者使用 Python 脚本：

```bash
python taskman.py
```

### 方式二：作为命令行工具安装

```bash
# 安装为命令行工具
cd apps/taskman
pip install -e .

# 现在可以直接使用 taskman 命令
taskman start
taskman backend
taskman frontend
```

### 方式三：手动启动

#### 后端

```bash
cd apps/taskman/backend
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

#### 前端

```bash
cd apps/taskman/frontend
python -m http.server 3000
```

## 命令行选项

### start 命令

```bash
taskman start [选项]
```

**选项：**
- `--backend-host`：后端监听地址（默认：0.0.0.0）
- `--backend-port`：后端监听端口（默认：8000）
- `--frontend-port`：前端监听端口（默认：3000）
- `--no-browser`：不自动打开浏览器
- `--no-reload`：禁用后端热重载

### backend 命令

```bash
taskman backend [选项]
```

**选项：**
- `--host`：监听地址（默认：0.0.0.0）
- `--port`：监听端口（默认：8000）
- `--no-reload`：禁用热重载
- `--log-level`：日志级别（debug/info/warning/error，默认：info）

### frontend 命令

```bash
taskman frontend [选项]
```

**选项：**
- `--port`：监听端口（默认：3000）
- `--no-browser`：不自动打开浏览器

## 访问应用

启动后，打开浏览器访问：
- 前端：http://localhost:3000
- 后端 API：http://localhost:8000
- API 文档：http://localhost:8000/docs

## 环境变量配置

可以通过设置环境变量来配置服务：

```bash
# 后端配置
TASKMAN_BACKEND_HOST=0.0.0.0
TASKMAN_BACKEND_PORT=8000

# 前端配置
TASKMAN_FRONTEND_PORT=3000

# API 地址
TASKMAN_API_BASE_URL=http://localhost:8000
```

## 项目结构

```
taskman/
├── __init__.py           # 包初始化
├── __main__.py           # CLI 入口
├── cli.py                # CLI 实现
├── config.py             # 配置管理
├── pyproject.toml        # 项目配置
├── taskman.py            # 启动脚本
├── taskman.bat           # Windows 启动脚本
├── .env.example          # 环境变量示例
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py              # FastAPI 应用入口
│   │   ├── database.py          # 数据库配置
│   │   ├── models.py             # 数据模型
│   │   ├── schemas.py            # Pydantic 模型
│   │   └── routers/
│   │       ├── tasks.py          # 任务 API
│   │       ├── categories.py    # 分类 API
│   │       ├── tags.py           # 标签 API
│   │       └── stats.py          # 统计 API
│   ├── tests/                   # 测试目录
│   ├── pyproject.toml           # 后端项目配置
│   └── requirements.txt          # 依赖列表
└── frontend/
    ├── index.html               # 主页面
    ├── css/
    │   └── styles.css           # 样式文件
    └── js/
        ├── config.js            # 前端配置
        ├── api.js               # API 调用封装
        ├── app.js               # 主应用
        └── components/          # 组件目录
            ├── taskList.js      # 任务列表
            ├── taskModal.js     # 任务模态框
            ├── sidebar.js       # 侧边栏
            └── statsPanel.js    # 统计面板
```

## 功能特性

### 任务管理
- ✅ 创建任务（标题、描述、优先级、截止日期）
- ✅ 编辑任务
- ✅ 删除任务（软删除）
- ✅ 任务状态流转（待办 → 进行中 → 已完成）
- ✅ 任务搜索
- ✅ 任务筛选（按状态、分类）

### 分类管理
- ✅ 创建分类
- ✅ 编辑分类
- ✅ 删除分类
- ✅ 分类颜色设置

### 标签管理
- ✅ 创建标签
- ✅ 编辑标签
- ✅ 删除标签
- ✅ 多标签支持
- ✅ 标签颜色设置

### 数据统计
- ✅ 任务总数统计
- ✅ 状态分布统计
- ✅ 完成率计算
- ✅ 优先级分布
- ✅ 逾期任务统计

### 用户界面
- 🎨 现代化设计
- 📱 响应式布局
- 🌙 友好的交互体验
- ⚡ 即时反馈提示

## API 接口

### 任务接口
- `GET /api/tasks` - 获取任务列表
- `POST /api/tasks` - 创建任务
- `GET /api/tasks/{id}` - 获取任务详情
- `PUT /api/tasks/{id}` - 更新任务
- `DELETE /api/tasks/{id}` - 删除任务

### 分类接口
- `GET /api/categories` - 获取分类列表
- `POST /api/categories` - 创建分类
- `PUT /api/categories/{id}` - 更新分类
- `DELETE /api/categories/{id}` - 删除分类

### 标签接口
- `GET /api/tags` - 获取标签列表
- `POST /api/tags` - 创建标签
- `PUT /api/tags/{id}` - 更新标签
- `DELETE /api/tags/{id}` - 删除标签

### 统计接口
- `GET /api/stats` - 获取统计数据

## 数据模型

### 任务 (Task)
- id: 任务 ID
- title: 任务标题
- description: 任务描述
- status: 状态（pending/in_progress/completed/cancelled）
- priority: 优先级（high/medium/low）
- category_id: 分类 ID
- due_date: 截止日期
- created_at: 创建时间
- updated_at: 更新时间
- deleted_at: 删除时间（软删除）

### 分类 (Category)
- id: 分类 ID
- name: 分类名称
- color: 分类颜色
- created_at: 创建时间

### 标签 (Tag)
- id: 标签 ID
- name: 标签名称
- color: 标签颜色
- created_at: 创建时间

## 开发指南

### 运行测试

```bash
cd backend
pytest tests/
```

### 代码格式化

```bash
cd backend
black app/
ruff check app/
```

## 注意事项

1. **数据库初始化**：首次启动后端服务时，数据库文件会自动创建在 `backend/data/taskman.db`
2. **CORS 配置**：当前配置允许所有来源访问，生产环境请根据需要修改
3. **数据备份**：SQLite 数据库文件位于 `backend/data/taskman.db`，请定期备份

## 许可证

MIT License
