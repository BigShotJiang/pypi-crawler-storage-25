"""
Diff Storage - 增量保存机制
检测演示文稿的变更，只保存变化部分，提升保存性能
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from bitool.core import logger

from ..models.models import Presentation
from ..models.storage import PresentationSerializer


class ChangeTracker:
    """
    变更跟踪器
    跟踪演示文稿的变化，支持增量保存
    """

    def __init__(self, presentation: Presentation) -> None:
        """
        初始化变更跟踪器

        Args:
            presentation: 要跟踪的演示文稿
        """
        self.presentation = presentation
        self._initial_state = self._get_presentation_state()
        self._changes: dict[str, Any] = {}
        self._dirty_slides: set[str] = set()
        self._dirty_flags = {
            "title": False,
            "theme": False,
            "slides_added": [],
            "slides_removed": [],
            "slides_modified": [],
        }

    def _get_presentation_state(self) -> dict[str, Any]:
        """
        获取演示文稿的当前状态（用于比较）

        Returns:
            演示文稿状态字典
        """
        return {
            "title": self.presentation.title,
            "theme_id": self.presentation.theme_id,
            "slide_ids": [slide.id for slide in self.presentation.slides],
            "slides": {
                slide.id: {
                    "order": slide.order,
                    "layout_type": slide.layout_type.value,
                    "content": {
                        "title": slide.content.title,
                        "subtitle": slide.content.subtitle,
                        "body": slide.content.body,
                        "bullets": slide.content.bullets.copy(),
                        "icon": slide.content.icon,
                    },
                }
                for slide in self.presentation.slides
            },
        }

    def track_changes(self) -> None:
        """
        检测并记录所有变更
        """
        current_state = self._get_presentation_state()
        self._changes = {}
        self._dirty_flags = {
            "title": False,
            "theme": False,
            "slides_added": [],
            "slides_removed": [],
            "slides_modified": [],
        }

        # 检测标题变更
        if current_state["title"] != self._initial_state["title"]:
            self._dirty_flags["title"] = True
            self._changes["title"] = current_state["title"]

        # 检测主题变更
        if current_state["theme_id"] != self._initial_state["theme_id"]:
            self._dirty_flags["theme"] = True
            self._changes["theme_id"] = current_state["theme_id"]

        # 检测幻灯片变更
        initial_slide_ids = set(self._initial_state["slide_ids"])
        current_slide_ids = set(current_state["slide_ids"])

        # 新增的幻灯片
        added_ids = current_slide_ids - initial_slide_ids
        for slide_id in added_ids:
            self._dirty_flags["slides_added"].append(current_state["slides"][slide_id])

        # 删除的幻灯片
        removed_ids = initial_slide_ids - current_slide_ids
        for slide_id in removed_ids:
            self._dirty_flags["slides_removed"].append(slide_id)

        # 修改的幻灯片
        common_ids = initial_slide_ids & current_slide_ids
        for slide_id in common_ids:
            initial = self._initial_state["slides"].get(slide_id, {})
            current = current_state["slides"].get(slide_id, {})
            if initial != current:
                self._dirty_flags["slides_modified"].append(current)
                self._dirty_slides.add(slide_id)

    def has_changes(self) -> bool:
        """
        检查是否有变更

        Returns:
            如果有变更返回True，否则返回False
        """
        return (
            self._dirty_flags["title"]
            or self._dirty_flags["theme"]
            or self._dirty_flags["slides_added"]
            or self._dirty_flags["slides_removed"]
            or self._dirty_flags["slides_modified"]
        )

    def get_changes(self) -> dict[str, Any]:
        """
        获取所有变更

        Returns:
            变更字典
        """
        return self._dirty_flags

    def get_dirty_slide_ids(self) -> set[str]:
        """
        获取修改过的幻灯片ID

        Returns:
            修改过的幻灯片ID集合
        """
        return self._dirty_slides

    def commit_changes(self) -> None:
        """
        提交变更，将当前状态设为初始状态
        """
        self._initial_state = self._get_presentation_state()
        self._changes = {}
        self._dirty_slides.clear()
        self._dirty_flags = {
            "title": False,
            "theme": False,
            "slides_added": [],
            "slides_removed": [],
            "slides_modified": [],
        }


class IncrementalStorage:
    """
    增量存储管理器
    支持完整保存和增量保存
    """

    BACKUP_EXTENSION = ".backup"
    TEMP_EXTENSION = ".tmp"

    @classmethod
    def save_full(cls, presentation: Presentation, file_path: Path) -> bool:
        """
        完整保存演示文稿

        Args:
            presentation: 演示文稿
            file_path: 保存路径

        Returns:
            保存成功返回True，否则返回False
        """
        try:
            data = PresentationSerializer.to_dict(presentation)

            # 先保存到临时文件
            temp_path = file_path.with_suffix(cls.TEMP_EXTENSION)
            with open(temp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)

            # 备份原文件
            if file_path.exists():
                backup_path = file_path.with_suffix(cls.BACKUP_EXTENSION)
                file_path.rename(backup_path)

            # 重命名临时文件为目标文件
            temp_path.rename(file_path)

        except (TypeError, ValueError) as exc:
            logger.error(
                "完整保存序列化失败: path=%s, error=%s",
                file_path,
                exc,
                exc_info=True,
            )
            cls._restore_backup(file_path)
            return False
        except OSError as exc:
            logger.error(
                "完整保存文件IO失败: path=%s, error=%s",
                file_path,
                exc,
                exc_info=True,
            )
            cls._restore_backup(file_path)
            return False
        else:
            return True

    @classmethod
    def _restore_backup(cls, file_path: Path) -> None:
        """在保存失败后尝试从备份恢复原文件"""
        backup_path = file_path.with_suffix(cls.BACKUP_EXTENSION)
        if backup_path.exists():
            try:
                backup_path.rename(file_path)
            except OSError as exc:
                logger.error(
                    "从备份恢复文件失败: backup=%s, target=%s, error=%s",
                    backup_path,
                    file_path,
                    exc,
                )

    @classmethod
    def save_incremental(cls, presentation: Presentation, file_path: Path, changes: dict[str, Any]) -> bool:
        """
        增量保存演示文稿

        Args:
            presentation: 演示文稿
            file_path: 保存路径
            changes: 变更字典

        Returns:
            保存成功返回True，否则返回False
        """
        if not changes:
            return True

        try:
            # 读取现有文件
            if file_path.exists():
                with open(file_path, encoding="utf-8") as f:
                    existing_data = json.load(f)
            else:
                # 如果文件不存在，执行完整保存
                return cls.save_full(presentation, file_path)

            # 应用增量变更
            if "title" in changes:
                existing_data["title"] = changes["title"]

            if "theme_id" in changes:
                existing_data["theme_id"] = changes["theme_id"]

            if changes.get("slides_added"):
                for slide_data in changes["slides_added"]:
                    existing_data["slides"].append(slide_data)

            if changes.get("slides_removed"):
                existing_data["slides"] = [
                    s for s in existing_data["slides"] if s["id"] not in changes["slides_removed"]
                ]

            if changes.get("slides_modified"):
                for slide_data in changes["slides_modified"]:
                    for i, existing_slide in enumerate(existing_data["slides"]):
                        if existing_slide["id"] == slide_data["id"]:
                            existing_data["slides"][i] = slide_data
                            break

            # 保存变更
            temp_path = file_path.with_suffix(cls.TEMP_EXTENSION)
            with open(temp_path, "w", encoding="utf-8") as f:
                json.dump(existing_data, f, ensure_ascii=False, indent=2)

            # 备份并替换
            backup_path = file_path.with_suffix(cls.BACKUP_EXTENSION)
            if file_path.exists():
                file_path.rename(backup_path)
            temp_path.rename(file_path)

        except json.JSONDecodeError as exc:
            logger.error(
                "增量保存读取现有文件失败，JSON格式错误: path=%s, error=%s",
                file_path,
                exc,
                exc_info=True,
            )
            cls._restore_backup(file_path)
            return False
        except (TypeError, ValueError) as exc:
            logger.error(
                "增量保存序列化失败: path=%s, error=%s",
                file_path,
                exc,
                exc_info=True,
            )
            cls._restore_backup(file_path)
            return False
        except OSError as exc:
            logger.error(
                "增量保存文件IO失败: path=%s, error=%s",
                file_path,
                exc,
                exc_info=True,
            )
            cls._restore_backup(file_path)
            return False
        else:
            return True

    @classmethod
    def load(cls, file_path: Path) -> Presentation | None:
        """
        加载演示文稿

        Args:
            file_path: 文件路径

        Returns:
            演示文稿对象，如果加载失败返回None
        """
        try:
            with open(file_path, encoding="utf-8") as f:
                data = json.load(f)

            # 尝试从主文件加载
            return PresentationSerializer.from_dict(data)
        except (json.JSONDecodeError, OSError, ValueError, KeyError, TypeError) as exc:
            logger.error(
                "加载演示文稿失败，尝试从备份恢复: path=%s, error=%s",
                file_path,
                exc,
                exc_info=True,
            )
            # 如果主文件损坏，尝试从备份文件加载
            backup_path = file_path.with_suffix(cls.BACKUP_EXTENSION)
            if backup_path.exists():
                try:
                    with open(backup_path, encoding="utf-8") as f:
                        data = json.load(f)
                    return PresentationSerializer.from_dict(data)
                except (json.JSONDecodeError, OSError, ValueError, KeyError, TypeError) as backup_exc:
                    logger.error(
                        "从备份加载演示文稿失败: backup=%s, error=%s",
                        backup_path,
                        backup_exc,
                        exc_info=True,
                    )
                    return None
            return None


class AutoSaveManager:
    """
    自动保存管理器
    定期自动保存草稿，防止数据丢失
    """

    def __init__(self, interval: int = 30) -> None:
        """
        初始化自动保存管理器

        Args:
            interval: 自动保存间隔（秒），默认为30秒
        """
        self._interval = interval
        self._last_save_time = datetime.now(timezone.utc)
        self._is_enabled = True
        self._pending_changes = False

    @property
    def is_enabled(self) -> bool:
        """是否启用自动保存"""
        return self._is_enabled

    @is_enabled.setter
    def is_enabled(self, value: bool) -> None:
        """设置是否启用自动保存"""
        self._is_enabled = value

    @property
    def interval(self) -> int:
        """自动保存间隔（秒）"""
        return self._interval

    @interval.setter
    def interval(self, value: int) -> None:
        """设置自动保存间隔（秒）"""
        self._interval = max(10, value)

    def mark_dirty(self) -> None:
        """标记有未保存的变更"""
        self._pending_changes = True

    def check_and_save(self, presentation: Presentation, file_path: Path | None) -> bool:
        """
        检查是否需要自动保存

        Args:
            presentation: 演示文稿
            file_path: 文件路径

        Returns:
            如果执行了保存返回True，否则返回False
        """
        if not self._is_enabled:
            return False

        if not self._pending_changes:
            return False

        now = datetime.now(timezone.utc)
        elapsed = (now - self._last_save_time).total_seconds()

        if elapsed >= self._interval:
            if file_path:
                success = IncrementalStorage.save_full(presentation, file_path)
                if success:
                    self._last_save_time = now
                    self._pending_changes = False
                    return True
            return False

        return False

    def force_save(self, presentation: Presentation, file_path: Path) -> bool:
        """
        强制保存

        Args:
            presentation: 演示文稿
            file_path: 文件路径

        Returns:
            保存成功返回True，否则返回False
        """
        success = IncrementalStorage.save_full(presentation, file_path)
        if success:
            self._last_save_time = datetime.now(timezone.utc)
            self._pending_changes = False
        return success

    def reset(self) -> None:
        """重置保存状态"""
        self._last_save_time = datetime.now(timezone.utc)
        self._pending_changes = False


# 全局自动保存管理器实例
_global_auto_save_manager = AutoSaveManager(interval=30)


def get_auto_save_manager() -> AutoSaveManager:
    """
    获取全局自动保存管理器实例

    Returns:
        自动保存管理器实例
    """
    return _global_auto_save_manager
