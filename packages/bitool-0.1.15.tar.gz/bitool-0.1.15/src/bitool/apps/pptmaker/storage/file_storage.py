"""
File Storage —— 演示文稿的文件级 IO

负责将 :class:`Presentation` 对象与磁盘上的 JSON 文件之间互相转换。
本模块只做文件读写，序列化逻辑委托给
:class:`bitool.apps.pptmaker.models.storage.PresentationSerializer`。
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from bitool.core import logger

from ..models.models import Presentation
from ..models.storage import PresentationSerializer


def save_to_file(presentation: Presentation, file_path: Path) -> bool:
    """将演示文稿保存到 JSON 文件。

    Args:
        presentation: 待保存的演示文稿对象。
        file_path: 目标文件路径。

    Returns:
        bool: 保存成功返回 ``True``，失败返回 ``False``。
    """
    try:
        presentation.updated_at = datetime.now(timezone.utc)
        data = PresentationSerializer.to_dict(presentation)

        file_path = Path(file_path)
        file_path.parent.mkdir(parents=True, exist_ok=True)

        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        logger.info(f"演示文稿已保存: {file_path}")
    except Exception as exc:  # noqa: BLE001 —— 保留旧 API 的失败语义
        logger.exception(f"保存演示文稿失败: {file_path} ({exc})")
        return False
    else:
        return True


def load_from_file(file_path: Path) -> Presentation | None:
    """从 JSON 文件加载演示文稿。

    Args:
        file_path: 目标文件路径。

    Returns:
        Presentation | None: 加载成功返回演示文稿对象，失败返回 ``None``。
    """
    try:
        file_path = Path(file_path)
        with open(file_path, encoding="utf-8") as f:
            data = json.load(f)
        logger.info(f"演示文稿已加载: {file_path}")
        return PresentationSerializer.from_dict(data)
    except Exception as exc:  # noqa: BLE001
        logger.exception(f"加载演示文稿失败: {file_path} ({exc})")
        return None


__all__ = ["load_from_file", "save_to_file"]
