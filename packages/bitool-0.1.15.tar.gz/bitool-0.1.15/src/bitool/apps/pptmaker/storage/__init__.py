"""
Storage Package - 存储管理模块

职责边界：
- 实际的文件 IO（``file_storage``）
- 增量保存与变更跟踪（``diff_storage``）
- 自动保存调度（``diff_storage.AutoSaveManager``）

序列化（dict/JSON 转换）位于 :mod:`bitool.apps.pptmaker.models.storage`。
"""

from .diff_storage import (
    AutoSaveManager,
    ChangeTracker,
    IncrementalStorage,
    get_auto_save_manager,
)
from .file_storage import load_from_file, save_to_file

__all__ = [
    "AutoSaveManager",
    "ChangeTracker",
    "IncrementalStorage",
    "get_auto_save_manager",
    "load_from_file",
    "save_to_file",
]
