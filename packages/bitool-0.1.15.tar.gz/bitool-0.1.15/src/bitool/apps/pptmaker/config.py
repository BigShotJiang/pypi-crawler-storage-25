"""
应用配置管理
存储和加载应用设置
"""

from __future__ import annotations

import json
from pathlib import Path

from bitool.core import logger


class AppConfig:
    """应用配置类"""

    def __init__(self, config_dir: Path | None = None) -> None:
        if config_dir is None:
            # 使用用户目录下的配置文件夹
            config_dir = Path.home() / ".pptmaker"
        self.config_dir = config_dir
        self.config_file = config_dir / "config.json"
        self.recent_files: list[str] = []
        self.default_theme_id: str = "default"
        self.window_geometry: str | None = None

        # 确保配置目录存在
        self.config_dir.mkdir(parents=True, exist_ok=True)

        # 加载配置
        self.load()

    def load(self) -> None:
        """从文件加载配置"""
        if not self.config_file.exists():
            return

        try:
            with open(self.config_file, encoding="utf-8") as f:
                data = json.load(f)
                self.recent_files = data.get("recent_files", [])
                self.default_theme_id = data.get("default_theme_id", "default")
                self.window_geometry = data.get("window_geometry")
        except FileNotFoundError:
            logger.warning("配置文件不存在，使用默认配置: %s", self.config_file)
        except json.JSONDecodeError as exc:
            logger.warning(
                "配置文件格式错误，降级为默认配置: path=%s, error=%s",
                self.config_file,
                exc,
            )
        except PermissionError as exc:
            logger.warning(
                "无权读取配置文件，使用默认配置: path=%s, error=%s",
                self.config_file,
                exc,
            )
        except OSError as exc:
            logger.warning(
                "读取配置文件出错，使用默认配置: path=%s, error=%s",
                self.config_file,
                exc,
            )

    def save(self) -> None:
        """保存配置到文件"""
        data = {
            "recent_files": self.recent_files,
            "default_theme_id": self.default_theme_id,
            "window_geometry": self.window_geometry,
        }

        try:
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except PermissionError as exc:
            logger.warning(
                "无权写入配置文件: path=%s, error=%s",
                self.config_file,
                exc,
            )
        except OSError as exc:
            logger.warning(
                "保存配置文件失败: path=%s, error=%s",
                self.config_file,
                exc,
            )
        except TypeError as exc:
            logger.error(
                "配置数据序列化失败: path=%s, error=%s",
                self.config_file,
                exc,
                exc_info=True,
            )

    def add_recent_file(self, file_path: str) -> None:
        """添加到近期文件列表"""
        # 先移除已存在的
        if file_path in self.recent_files:
            self.recent_files.remove(file_path)
        # 插入到开头
        self.recent_files.insert(0, file_path)
        # 只保留最近10个
        if len(self.recent_files) > 10:
            self.recent_files = self.recent_files[:10]
        self.save()

    def clear_recent_files(self) -> None:
        """清空近期文件列表"""
        self.recent_files = []
        self.save()


# 全局配置实例
_config_instance: AppConfig | None = None


def get_config() -> AppConfig:
    """获取全局配置实例"""
    global _config_instance
    if _config_instance is None:
        _config_instance = AppConfig()
    return _config_instance
