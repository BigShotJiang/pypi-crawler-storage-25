"""PPTMaker - 一个强大的幻灯片制作工具"""

__version__ = "0.1.3"

__all__ = ["__version__"]
