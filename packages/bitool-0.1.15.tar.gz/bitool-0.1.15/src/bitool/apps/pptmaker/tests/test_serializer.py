"""pptmaker 序列化层单元测试。

覆盖 `PresentationSerializer` 在 dict/JSON 与 `Presentation`
对象之间的双向转换、容错处理与 `create_new` 工厂方法。
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime

from bitool.apps.pptmaker.models import (
    LayoutType,
    Presentation,
    PresentationSerializer,
    Slide,
    SlideContent,
    SlideElement,
)


def _make_sample_presentation() -> Presentation:
    """构造一个包含多种内容字段的演示文稿用于序列化测试。"""
    elem = SlideElement(
        id="e1",
        element_type="text",
        content="hello",
        x=0.1,
        y=0.2,
        width=0.5,
        height=0.4,
        style={"color": "#ff0000", "size": 12},
    )
    slide = Slide(
        id="s1",
        order=0,
        layout_type=LayoutType.TITLE_BULLETS,
        content=SlideContent(
            title="标题",
            subtitle="副标题",
            body="正文内容",
            bullets=["a", "b", "c"],
            icon="star",
            image_path="img.png",
            elements=[elem],
        ),
        notes="演讲者备注",
    )
    return Presentation(
        id="p-001",
        title="测试演示文稿",
        theme_id="modern",
        layout_id="default",
        slides=[slide],
        metadata={"author": "tester"},
    )


class TestToDictFromDict:
    """to_dict / from_dict 的双向转换测试。"""

    def test_to_dict_structure(self) -> None:
        pres = _make_sample_presentation()
        data = PresentationSerializer.to_dict(pres)

        assert data["id"] == "p-001"
        assert data["title"] == "测试演示文稿"
        assert data["theme_id"] == "modern"
        assert data["metadata"] == {"author": "tester"}

        assert len(data["slides"]) == 1
        slide_data = data["slides"][0]
        assert slide_data["id"] == "s1"
        assert slide_data["layout_type"] == "title_bullets"
        assert slide_data["content"]["bullets"] == ["a", "b", "c"]
        assert slide_data["content"]["elements"][0]["id"] == "e1"
        assert slide_data["content"]["elements"][0]["style"] == {"color": "#ff0000", "size": 12}

    def test_round_trip_dict(self) -> None:
        pres = _make_sample_presentation()
        data = PresentationSerializer.to_dict(pres)
        restored = PresentationSerializer.from_dict(data)

        assert restored.id == pres.id
        assert restored.title == pres.title
        assert restored.theme_id == pres.theme_id
        assert restored.layout_id == pres.layout_id
        assert restored.metadata == pres.metadata
        assert len(restored.slides) == 1

        s = restored.slides[0]
        assert s.id == "s1"
        assert s.layout_type is LayoutType.TITLE_BULLETS
        assert s.content.title == "标题"
        assert s.content.bullets == ["a", "b", "c"]
        assert s.content.icon == "star"
        assert s.content.image_path == "img.png"
        assert len(s.content.elements) == 1
        assert s.content.elements[0].x == 0.1
        assert s.content.elements[0].style == {"color": "#ff0000", "size": 12}
        assert s.notes == "演讲者备注"

    def test_round_trip_preserves_timestamps(self) -> None:
        pres = _make_sample_presentation()
        data = PresentationSerializer.to_dict(pres)
        restored = PresentationSerializer.from_dict(data)
        assert restored.created_at == pres.created_at
        assert restored.updated_at == pres.updated_at


class TestJsonRoundTrip:
    """to_json_str / from_json_str 测试。"""

    def test_round_trip_json_str(self) -> None:
        pres = _make_sample_presentation()
        text = PresentationSerializer.to_json_str(pres)

        assert isinstance(text, str)
        # 默认 ensure_ascii=False，应保留中文
        assert "测试演示文稿" in text
        # 默认 indent=2 应当是格式化的多行 JSON
        assert "\n" in text

        restored = PresentationSerializer.from_json_str(text)
        assert restored.id == pres.id
        assert restored.title == pres.title
        assert restored.slides[0].content.bullets == ["a", "b", "c"]

    def test_to_json_str_with_no_indent(self) -> None:
        pres = _make_sample_presentation()
        text = PresentationSerializer.to_json_str(pres, indent=None)
        # 没有 indent 时应是单行紧凑 JSON（无换行）
        assert "\n" not in text
        # 仍然可以解析回来
        json.loads(text)


class TestFromDictTolerance:
    """from_dict 对缺失字段、额外字段的容错测试。"""

    def test_from_empty_dict_uses_defaults(self) -> None:
        pres = PresentationSerializer.from_dict({})

        assert isinstance(pres.id, str) and pres.id  # 自动生成 uuid
        # 自动生成的 id 应当是合法 UUID
        uuid.UUID(pres.id)
        assert pres.title == "未命名演示文稿"
        assert pres.theme_id == "default"
        assert pres.layout_id == "default"
        assert pres.slides == []
        assert pres.metadata == {}
        assert isinstance(pres.created_at, datetime)
        assert isinstance(pres.updated_at, datetime)

    def test_from_dict_missing_slide_fields(self) -> None:
        data = {
            "id": "p1",
            "slides": [
                {
                    # 缺失 id, order, layout_type, notes 等
                    "content": {"title": "only-title"},
                },
            ],
        }
        pres = PresentationSerializer.from_dict(data)
        assert len(pres.slides) == 1

        slide = pres.slides[0]
        assert slide.order == 0
        assert slide.layout_type is LayoutType.TITLE_CONTENT
        assert slide.content.title == "only-title"
        assert slide.content.bullets == []
        assert slide.content.elements == []
        assert slide.notes == ""
        # slide.id 未提供时应自动生成 uuid
        uuid.UUID(slide.id)

    def test_from_dict_ignores_extra_fields(self) -> None:
        data = {
            "id": "p1",
            "title": "T",
            "unknown_top_level": 123,
            "slides": [
                {
                    "id": "s1",
                    "order": 0,
                    "layout_type": "title_content",
                    "content": {
                        "title": "x",
                        "extra_field": "ignored",
                        "elements": [
                            {
                                "id": "e1",
                                "element_type": "text",
                                "content": "c",
                                "extra": "ignored",
                            },
                        ],
                    },
                    "extra": "ignored",
                },
            ],
        }
        pres = PresentationSerializer.from_dict(data)
        assert pres.id == "p1"
        assert pres.slides[0].content.title == "x"
        assert pres.slides[0].content.elements[0].id == "e1"

    def test_from_dict_missing_element_fields_uses_defaults(self) -> None:
        data = {
            "slides": [
                {
                    "content": {
                        "elements": [
                            # 完全空的 element 数据
                            {},
                        ],
                    },
                },
            ],
        }
        pres = PresentationSerializer.from_dict(data)
        elem = pres.slides[0].content.elements[0]
        # 默认 element_type 应为 text
        assert elem.element_type == "text"
        assert elem.content == ""
        assert elem.x == 0.0
        assert elem.width == 1.0
        assert elem.style == {}
        uuid.UUID(elem.id)


class TestCreateNew:
    """create_new 工厂方法测试。"""

    def test_create_new_default_title(self) -> None:
        pres = PresentationSerializer.create_new()
        assert pres.title == "未命名演示文稿"
        assert pres.theme_id == "default"
        assert pres.layout_id == "default"
        assert pres.slides == []
        # 应自动生成 UUID
        uuid.UUID(pres.id)

    def test_create_new_custom_title(self) -> None:
        pres = PresentationSerializer.create_new("我的演示")
        assert pres.title == "我的演示"

    def test_create_new_unique_ids(self) -> None:
        a = PresentationSerializer.create_new()
        b = PresentationSerializer.create_new()
        assert a.id != b.id
