"""pptmaker 数据模型单元测试。

覆盖纯 dataclass 数据模型 (`Presentation`, `Slide`, `Theme`,
`ThemeColors`, `ThemeFonts`, `Layout`, `LayoutType`) 的实例化与
`__post_init__` 校验逻辑。
"""

from __future__ import annotations

from datetime import datetime

import pytest

from bitool.apps.pptmaker.models import (
    Layout,
    LayoutType,
    Presentation,
    Slide,
    SlideContent,
    SlideElement,
    Theme,
    ThemeColors,
    ThemeFonts,
)


class TestLayoutTypeEnum:
    """LayoutType 枚举值测试。"""

    def test_all_layout_types_have_unique_values(self) -> None:
        values = [member.value for member in LayoutType]
        assert len(values) == len(set(values))

    def test_known_layout_values(self) -> None:
        assert LayoutType.TITLE_ONLY.value == "title_only"
        assert LayoutType.TITLE_CONTENT.value == "title_content"
        assert LayoutType.TITLE_CONTENT_ICON.value == "title_content_icon"
        assert LayoutType.TWO_COLUMNS.value == "two_columns"
        assert LayoutType.BIG_TITLE.value == "big_title"
        assert LayoutType.TITLE_BULLETS.value == "title_bullets"
        assert LayoutType.TITLE_IMAGE.value == "title_image"
        assert LayoutType.COMPARISON.value == "comparison"

    def test_layout_type_from_value(self) -> None:
        assert LayoutType("title_content") is LayoutType.TITLE_CONTENT


class TestThemeColors:
    """ThemeColors 颜色校验测试。"""

    def test_default_colors_are_valid(self) -> None:
        colors = ThemeColors()
        assert colors.primary.startswith("#")
        assert colors.background == "#ffffff"

    def test_custom_valid_hex_colors(self) -> None:
        colors = ThemeColors(primary="#abc", secondary="#ABCDEF", accent="#12345678")
        assert colors.primary == "#abc"
        assert colors.secondary == "#ABCDEF"
        assert colors.accent == "#12345678"

    @pytest.mark.parametrize(
        "bad_value",
        ["red", "#zzz", "#12", "#1234567", "123456", "#12345", ""],
    )
    def test_invalid_hex_color_raises_value_error(self, bad_value: str) -> None:
        with pytest.raises(ValueError):
            ThemeColors(primary=bad_value)

    def test_non_string_color_raises_value_error(self) -> None:
        with pytest.raises(ValueError):
            ThemeColors(primary=123)  # type: ignore[arg-type]


class TestThemeFonts:
    """ThemeFonts 必填字段校验测试。"""

    def test_default_fonts_are_valid(self) -> None:
        fonts = ThemeFonts()
        assert fonts.heading
        assert fonts.body
        assert fonts.code

    def test_empty_heading_raises_value_error(self) -> None:
        with pytest.raises(ValueError):
            ThemeFonts(heading="")

    def test_whitespace_only_body_raises_value_error(self) -> None:
        with pytest.raises(ValueError):
            ThemeFonts(body="   ")

    def test_empty_code_raises_value_error(self) -> None:
        with pytest.raises(ValueError):
            ThemeFonts(code="")


class TestTheme:
    """Theme dataclass 测试。"""

    def test_default_theme_construction(self) -> None:
        theme = Theme()
        assert theme.id == "default"
        assert theme.name == "默认主题"
        assert isinstance(theme.colors, ThemeColors)
        assert isinstance(theme.fonts, ThemeFonts)

    def test_custom_theme_construction(self) -> None:
        theme = Theme(id="custom", name="自定义", description="测试主题")
        assert theme.id == "custom"
        assert theme.name == "自定义"

    def test_empty_id_raises_value_error(self) -> None:
        with pytest.raises(ValueError):
            Theme(id="", name="X")

    def test_empty_name_raises_value_error(self) -> None:
        with pytest.raises(ValueError):
            Theme(id="x", name="")

    def test_invalid_colors_type_raises_type_error(self) -> None:
        with pytest.raises(TypeError):
            Theme(colors="not-a-colors")  # type: ignore[arg-type]

    def test_invalid_fonts_type_raises_type_error(self) -> None:
        with pytest.raises(TypeError):
            Theme(fonts={"heading": "x"})  # type: ignore[arg-type]


class TestLayout:
    """Layout dataclass 测试。"""

    def test_layout_construction(self) -> None:
        layout = Layout(
            id="title_content",
            name="标题+内容",
            description="经典布局",
            layout_type=LayoutType.TITLE_CONTENT,
        )
        assert layout.id == "title_content"
        assert layout.layout_type is LayoutType.TITLE_CONTENT
        assert layout.template_path is None

    def test_empty_layout_id_raises_value_error(self) -> None:
        with pytest.raises(ValueError):
            Layout(id="", name="X", description="x", layout_type=LayoutType.TITLE_CONTENT)

    def test_invalid_layout_type_raises_type_error(self) -> None:
        with pytest.raises(TypeError):
            Layout(id="x", name="X", description="x", layout_type="title_content")  # type: ignore[arg-type]


class TestSlideAndPresentation:
    """Slide/SlideContent/SlideElement/Presentation dataclass 测试。"""

    def test_slide_element_defaults(self) -> None:
        elem = SlideElement(id="e1", element_type="text", content="hello")
        assert elem.x == 0.0 and elem.y == 0.0
        assert elem.width == 1.0 and elem.height == 1.0
        assert elem.style == {}

    def test_slide_content_defaults(self) -> None:
        content = SlideContent()
        assert content.title == ""
        assert content.bullets == []
        assert content.elements == []
        assert content.icon is None
        assert content.image_path is None

    def test_slide_construction(self) -> None:
        slide = Slide(id="s1", order=0)
        assert slide.id == "s1"
        assert slide.layout_type is LayoutType.TITLE_CONTENT
        assert isinstance(slide.content, SlideContent)
        assert slide.notes == ""

    def test_presentation_construction(self) -> None:
        pres = Presentation(id="p1")
        assert pres.id == "p1"
        assert pres.title == "未命名演示文稿"
        assert pres.theme_id == "default"
        assert pres.layout_id == "default"
        assert pres.slides == []
        assert isinstance(pres.created_at, datetime)
        assert isinstance(pres.updated_at, datetime)
        assert pres.metadata == {}

    def test_presentation_with_slides(self) -> None:
        slide_a = Slide(id="a", order=0)
        slide_b = Slide(id="b", order=1, layout_type=LayoutType.BIG_TITLE)
        pres = Presentation(id="p2", slides=[slide_a, slide_b])
        assert len(pres.slides) == 2
        assert pres.slides[1].layout_type is LayoutType.BIG_TITLE
