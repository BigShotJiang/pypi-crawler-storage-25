"""pptmaker 自动布局引擎单元测试。

覆盖 `AutoLayoutEngine.determine_layout` 在不同内容组合下
返回正确的 `LayoutType`，以及 `apply_layout` / `optimize_slide`
对幻灯片对象的更新效果。
"""

from __future__ import annotations

from bitool.apps.pptmaker.auto_layout import AutoLayoutEngine
from bitool.apps.pptmaker.models import LayoutType, Slide, SlideContent


class TestDetermineLayout:
    """determine_layout 各内容组合的分支测试。"""

    def test_only_title_returns_big_title(self) -> None:
        content = SlideContent(title="只有标题")
        assert AutoLayoutEngine.determine_layout(content) is LayoutType.BIG_TITLE

    def test_title_with_bullets_returns_title_bullets(self) -> None:
        content = SlideContent(title="标题", bullets=["a", "b"])
        assert AutoLayoutEngine.determine_layout(content) is LayoutType.TITLE_BULLETS

    def test_title_body_icon_returns_title_content_icon(self) -> None:
        content = SlideContent(title="标题", body="正文", icon="star")
        assert AutoLayoutEngine.determine_layout(content) is LayoutType.TITLE_CONTENT_ICON

    def test_title_with_image_returns_title_image(self) -> None:
        content = SlideContent(title="标题", image_path="cover.png")
        assert AutoLayoutEngine.determine_layout(content) is LayoutType.TITLE_IMAGE

    def test_title_body_image_prefers_title_content_icon_over_title_image_when_icon(
        self,
    ) -> None:
        # 同时存在 icon 与 image，icon 分支优先匹配
        content = SlideContent(title="T", body="B", icon="star", image_path="x.png")
        assert AutoLayoutEngine.determine_layout(content) is LayoutType.TITLE_CONTENT_ICON

    def test_empty_content_returns_default_title_content(self) -> None:
        # 完全空白的内容，应回退到默认布局
        content = SlideContent()
        assert AutoLayoutEngine.determine_layout(content) is LayoutType.TITLE_CONTENT

    def test_title_only_with_whitespace_only_body_treated_as_only_title(self) -> None:
        # body 仅包含空白字符，不算有内容
        content = SlideContent(title="标题", body="   ")
        assert AutoLayoutEngine.determine_layout(content) is LayoutType.BIG_TITLE

    def test_title_and_body_returns_title_content(self) -> None:
        # 标题 + 正文 但无 icon/image/bullets
        content = SlideContent(title="标题", body="正文")
        assert AutoLayoutEngine.determine_layout(content) is LayoutType.TITLE_CONTENT

    def test_all_fields_present_returns_title_content_icon(self) -> None:
        # 所有字段都填了，icon 优先级会命中 TITLE_CONTENT_ICON
        content = SlideContent(
            title="T",
            subtitle="S",
            body="B",
            bullets=["x"],
            icon="i",
            image_path="p.png",
        )
        assert AutoLayoutEngine.determine_layout(content) is LayoutType.TITLE_CONTENT_ICON


class TestApplyLayout:
    """apply_layout 对 Slide 实例的副作用测试。"""

    def test_apply_layout_updates_slide_layout_type(self) -> None:
        slide = Slide(
            id="s1",
            order=0,
            layout_type=LayoutType.TITLE_CONTENT,
            content=SlideContent(title="只有标题"),
        )
        result = AutoLayoutEngine.apply_layout(slide)
        assert result is slide
        assert slide.layout_type is LayoutType.BIG_TITLE

    def test_apply_layout_with_bullets(self) -> None:
        slide = Slide(
            id="s2",
            order=0,
            content=SlideContent(title="标题", bullets=["a", "b"]),
        )
        AutoLayoutEngine.apply_layout(slide)
        assert slide.layout_type is LayoutType.TITLE_BULLETS


class TestOptimizeSlide:
    """optimize_slide 当前等价于 apply_layout 的行为。"""

    def test_optimize_updates_layout_type(self) -> None:
        slide = Slide(
            id="s3",
            order=0,
            layout_type=LayoutType.TITLE_CONTENT,
            content=SlideContent(title="标题", image_path="x.png"),
        )
        AutoLayoutEngine.optimize_slide(slide)
        assert slide.layout_type is LayoutType.TITLE_IMAGE
