"""pptmaker 命令栈单元测试。

覆盖：
- 各具体命令 (`AddSlideCommand`, `RemoveSlideCommand`,
  `CopySlideCommand`, `EditSlideCommand`, `ChangeLayoutCommand`)
  的 execute / undo / redo 行为；
- `CompositeCommand` 的批量执行与逆序撤销；
- `CommandMacro` 的录制与序列化；
- `CommandStack` 的 push / undo / redo / max_history。
"""

from __future__ import annotations

from bitool.apps.pptmaker.command_stack import (
    AddSlideCommand,
    ChangeLayoutCommand,
    Command,
    CommandMacro,
    CommandStack,
    CompositeCommand,
    CopySlideCommand,
    EditSlideCommand,
    RemoveSlideCommand,
)
from bitool.apps.pptmaker.models import (
    LayoutType,
    Presentation,
    Slide,
    SlideContent,
)


def _make_presentation_with_slides(n: int = 2) -> Presentation:
    pres = Presentation(id="p")
    for i in range(n):
        pres.slides.append(
            Slide(
                id=f"s{i}",
                order=i,
                content=SlideContent(title=f"标题{i}"),
            ),
        )
    return pres


# ---------------------------------------------------------------------------
# 具体命令
# ---------------------------------------------------------------------------


class TestAddSlideCommand:
    def test_execute_appends_slide_and_reorders(self) -> None:
        pres = _make_presentation_with_slides(2)
        new_slide = Slide(id="new", order=999, content=SlideContent(title="新页"))
        cmd = AddSlideCommand(pres, new_slide)
        cmd.execute()

        assert len(pres.slides) == 3
        assert pres.slides[-1] is new_slide
        # 新增后应自动重排 order
        assert [s.order for s in pres.slides] == [0, 1, 2]
        assert cmd.inserted_index == 2

    def test_undo_removes_slide(self) -> None:
        pres = _make_presentation_with_slides(2)
        new_slide = Slide(id="new", order=0)
        cmd = AddSlideCommand(pres, new_slide)
        cmd.execute()
        cmd.undo()

        assert len(pres.slides) == 2
        assert all(s.id != "new" for s in pres.slides)
        assert [s.order for s in pres.slides] == [0, 1]

    def test_redo_after_undo_restores_slide(self) -> None:
        pres = _make_presentation_with_slides(1)
        new_slide = Slide(id="x", order=0)
        cmd = AddSlideCommand(pres, new_slide)
        cmd.execute()
        cmd.undo()
        cmd.redo()
        assert len(pres.slides) == 2
        assert pres.slides[-1].id == "x"


class TestRemoveSlideCommand:
    def test_execute_removes_and_reorders(self) -> None:
        pres = _make_presentation_with_slides(3)
        cmd = RemoveSlideCommand(pres, index=1)
        cmd.execute()

        assert len(pres.slides) == 2
        assert [s.id for s in pres.slides] == ["s0", "s2"]
        assert [s.order for s in pres.slides] == [0, 1]
        assert cmd.removed_slide is not None
        assert cmd.removed_slide.id == "s1"

    def test_undo_restores_slide_at_original_index(self) -> None:
        pres = _make_presentation_with_slides(3)
        cmd = RemoveSlideCommand(pres, index=1)
        cmd.execute()
        cmd.undo()

        assert len(pres.slides) == 3
        assert [s.id for s in pres.slides] == ["s0", "s1", "s2"]
        assert [s.order for s in pres.slides] == [0, 1, 2]

    def test_execute_out_of_range_is_noop(self) -> None:
        pres = _make_presentation_with_slides(2)
        cmd = RemoveSlideCommand(pres, index=99)
        cmd.execute()
        assert len(pres.slides) == 2
        assert cmd.removed_slide is None


class TestCopySlideCommand:
    def test_execute_inserts_after_original(self) -> None:
        pres = _make_presentation_with_slides(2)
        copy = Slide(id="s0_copy", order=0, content=SlideContent(title="复制"))
        cmd = CopySlideCommand(pres, original_index=0, new_slide=copy)
        cmd.execute()

        assert [s.id for s in pres.slides] == ["s0", "s0_copy", "s1"]
        assert [s.order for s in pres.slides] == [0, 1, 2]

    def test_undo_removes_inserted_copy(self) -> None:
        pres = _make_presentation_with_slides(2)
        copy = Slide(id="copy", order=0)
        cmd = CopySlideCommand(pres, original_index=0, new_slide=copy)
        cmd.execute()
        cmd.undo()
        assert [s.id for s in pres.slides] == ["s0", "s1"]


class TestEditSlideCommand:
    def test_execute_replaces_content(self) -> None:
        pres = _make_presentation_with_slides(1)
        slide = pres.slides[0]
        old = slide.content
        new = SlideContent(title="新标题", body="新正文")

        cmd = EditSlideCommand(slide, old, new)
        cmd.execute()
        assert slide.content is new
        assert slide.content.title == "新标题"

        cmd.undo()
        assert slide.content is old
        assert slide.content.title == "标题0"

        cmd.redo()
        assert slide.content is new


class TestChangeLayoutCommand:
    def test_execute_and_undo_changes_layout(self) -> None:
        pres = _make_presentation_with_slides(1)
        slide = pres.slides[0]
        old_layout = slide.layout_type
        new_layout = LayoutType.BIG_TITLE

        cmd = ChangeLayoutCommand(slide, old_layout, new_layout)
        cmd.execute()
        assert slide.layout_type is new_layout

        cmd.undo()
        assert slide.layout_type is old_layout


# ---------------------------------------------------------------------------
# CompositeCommand
# ---------------------------------------------------------------------------


class _RecorderCommand(Command):
    """用于追踪 execute/undo 调用顺序的辅助命令。"""

    def __init__(self, name: str, log: list[str]) -> None:
        self.name = name
        self.log = log

    def execute(self) -> None:
        self.log.append(f"do:{self.name}")

    def undo(self) -> None:
        self.log.append(f"undo:{self.name}")

    def redo(self) -> None:
        self.log.append(f"redo:{self.name}")


class TestCompositeCommand:
    def test_execute_runs_all_in_order(self) -> None:
        log: list[str] = []
        comp = CompositeCommand(
            [_RecorderCommand("a", log), _RecorderCommand("b", log)],
            description="批量",
        )
        comp.execute()
        assert log == ["do:a", "do:b"]
        assert comp.description == "批量"

    def test_undo_runs_in_reverse_order(self) -> None:
        log: list[str] = []
        comp = CompositeCommand(
            [_RecorderCommand("a", log), _RecorderCommand("b", log)],
        )
        comp.execute()
        log.clear()
        comp.undo()
        assert log == ["undo:b", "undo:a"]

    def test_composite_with_real_commands(self) -> None:
        pres = _make_presentation_with_slides(1)
        slide_a = Slide(id="A", order=0)
        slide_b = Slide(id="B", order=0)
        composite = CompositeCommand(
            [AddSlideCommand(pres, slide_a), AddSlideCommand(pres, slide_b)],
            description="批量添加",
        )
        composite.execute()
        assert [s.id for s in pres.slides] == ["s0", "A", "B"]

        composite.undo()
        assert [s.id for s in pres.slides] == ["s0"]


# ---------------------------------------------------------------------------
# CommandMacro
# ---------------------------------------------------------------------------


class TestCommandMacro:
    def test_record_only_when_recording(self) -> None:
        pres = _make_presentation_with_slides(0)
        macro = CommandMacro("m1")
        cmd = AddSlideCommand(pres, Slide(id="x", order=0))

        # 未开始录制时不应记录
        macro.record_command(cmd)
        assert macro.command_count == 0

        macro.start_recording()
        assert macro.is_recording is True
        macro.record_command(cmd)
        assert macro.command_count == 1

        macro.stop_recording()
        assert macro.is_recording is False
        macro.record_command(cmd)
        # 停止录制后不会再增加
        assert macro.command_count == 1

    def test_clear_resets_commands(self) -> None:
        macro = CommandMacro()
        macro.start_recording()
        macro.record_command(AddSlideCommand(Presentation(id="p"), Slide(id="s", order=0)))
        assert macro.command_count == 1
        macro.clear()
        assert macro.command_count == 0

    def test_to_dict_and_from_dict_round_trip(self) -> None:
        macro = CommandMacro("演示宏")
        macro.start_recording()
        macro.record_command(AddSlideCommand(Presentation(id="p"), Slide(id="s", order=0)))
        macro.stop_recording()

        data = macro.to_dict()
        assert data["name"] == "演示宏"
        assert isinstance(data["commands"], list) and len(data["commands"]) == 1
        assert data["commands"][0]["type"] == "AddSlideCommand"
        assert data["recorded_at"] is not None

        restored = CommandMacro.from_dict(data)
        assert restored.name == "演示宏"
        assert restored.command_count == 1


# ---------------------------------------------------------------------------
# CommandStack
# ---------------------------------------------------------------------------


class TestCommandStack:
    def test_push_executes_and_enables_undo(self) -> None:
        pres = _make_presentation_with_slides(0)
        stack = CommandStack()

        assert stack.can_undo() is False
        assert stack.can_redo() is False

        stack.push(AddSlideCommand(pres, Slide(id="a", order=0)))
        assert len(pres.slides) == 1
        assert stack.can_undo() is True
        assert stack.can_redo() is False

    def test_undo_then_redo_round_trip(self) -> None:
        pres = _make_presentation_with_slides(0)
        stack = CommandStack()
        stack.push(AddSlideCommand(pres, Slide(id="a", order=0)))
        stack.push(AddSlideCommand(pres, Slide(id="b", order=0)))
        assert [s.id for s in pres.slides] == ["a", "b"]

        stack.undo()
        assert [s.id for s in pres.slides] == ["a"]
        assert stack.can_redo() is True

        stack.redo()
        assert [s.id for s in pres.slides] == ["a", "b"]
        assert stack.can_redo() is False

    def test_push_after_undo_clears_redo_stack(self) -> None:
        pres = _make_presentation_with_slides(0)
        stack = CommandStack()
        stack.push(AddSlideCommand(pres, Slide(id="a", order=0)))
        stack.undo()
        assert stack.can_redo() is True

        stack.push(AddSlideCommand(pres, Slide(id="c", order=0)))
        assert stack.can_redo() is False

    def test_undo_when_empty_is_safe_noop(self) -> None:
        stack = CommandStack()
        # 不应抛出异常
        stack.undo()
        stack.redo()

    def test_max_history_limit(self) -> None:
        pres = _make_presentation_with_slides(0)
        stack = CommandStack(max_history=3)
        for i in range(5):
            stack.push(AddSlideCommand(pres, Slide(id=f"s{i}", order=0)))

        info = stack.get_stack_info()
        assert info["undo_stack_size"] == 3
        assert info["max_history"] == 3

    def test_clear_resets_both_stacks(self) -> None:
        pres = _make_presentation_with_slides(0)
        stack = CommandStack()
        stack.push(AddSlideCommand(pres, Slide(id="a", order=0)))
        stack.undo()
        stack.clear()
        assert stack.can_undo() is False
        assert stack.can_redo() is False

    def test_change_callback_invoked_on_push_and_undo(self) -> None:
        pres = _make_presentation_with_slides(0)
        stack = CommandStack()
        calls: list[int] = []

        def on_change() -> None:
            calls.append(1)

        stack.add_change_callback(on_change)
        stack.push(AddSlideCommand(pres, Slide(id="a", order=0)))
        stack.undo()
        assert sum(calls) >= 2

        stack.remove_change_callback(on_change)
        stack.push(AddSlideCommand(pres, Slide(id="b", order=0)))
        # 移除回调后计数不再增加
        assert sum(calls) == 2

    def test_macro_recording_via_stack(self) -> None:
        pres = _make_presentation_with_slides(0)
        stack = CommandStack()
        assert stack.is_recording_macro() is False

        stack.start_macro_recording("test")
        assert stack.is_recording_macro() is True

        stack.push(AddSlideCommand(pres, Slide(id="x", order=0)))
        macro = stack.stop_macro_recording()
        assert stack.is_recording_macro() is False
        assert macro is not None
        assert macro.name == "test"
        assert macro.command_count == 1

    def test_batch_push_combines_commands(self) -> None:
        pres = _make_presentation_with_slides(0)
        stack = CommandStack()
        stack.batch_push(
            [
                AddSlideCommand(pres, Slide(id="a", order=0)),
                AddSlideCommand(pres, Slide(id="b", order=0)),
            ],
            description="批量",
        )
        assert [s.id for s in pres.slides] == ["a", "b"]
        # 批量被压入为一条 CompositeCommand
        assert stack.get_stack_info()["undo_stack_size"] == 1

        stack.undo()
        assert pres.slides == []

    def test_batch_push_empty_is_noop(self) -> None:
        stack = CommandStack()
        stack.batch_push([])
        assert stack.can_undo() is False

    def test_save_and_load_history(self, tmp_path) -> None:
        pres = _make_presentation_with_slides(0)
        stack = CommandStack()
        stack.push(AddSlideCommand(pres, Slide(id="a", order=0)))

        history_file = tmp_path / "history.json"
        assert stack.save_history(history_file) is True
        assert history_file.exists()
        assert stack.load_history(history_file) is True

    def test_load_history_missing_file(self, tmp_path) -> None:
        stack = CommandStack()
        assert stack.load_history(tmp_path / "missing.json") is False
