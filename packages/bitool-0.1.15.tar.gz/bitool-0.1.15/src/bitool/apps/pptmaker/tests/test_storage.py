"""pptmaker 存储层单元测试。

覆盖：
- `save_to_file` / `load_from_file` 的文件级 IO 往返；
- `IncrementalStorage.save_full` / `load` 完整保存与读取；
- `ChangeTracker` 的变更检测；
- 文件不存在等异常路径的容错处理。
"""

from __future__ import annotations

from pathlib import Path

from bitool.apps.pptmaker.models import (
    LayoutType,
    Presentation,
    PresentationSerializer,
    PresentationStorage,
    Slide,
    SlideContent,
)
from bitool.apps.pptmaker.storage import (
    ChangeTracker,
    IncrementalStorage,
    load_from_file,
    save_to_file,
)


def _make_presentation() -> Presentation:
    return Presentation(
        id="p-001",
        title="存储测试",
        theme_id="default",
        layout_id="default",
        slides=[
            Slide(
                id="s1",
                order=0,
                layout_type=LayoutType.TITLE_CONTENT,
                content=SlideContent(title="A", body="正文", bullets=["一", "二"]),
            ),
            Slide(
                id="s2",
                order=1,
                layout_type=LayoutType.BIG_TITLE,
                content=SlideContent(title="B"),
            ),
        ],
    )


# ---------------------------------------------------------------------------
# file_storage
# ---------------------------------------------------------------------------


class TestFileStorageRoundTrip:
    def test_save_and_load_round_trip(self, tmp_path: Path) -> None:
        pres = _make_presentation()
        target = tmp_path / "demo.json"

        assert save_to_file(pres, target) is True
        assert target.exists()

        loaded = load_from_file(target)
        assert loaded is not None
        assert loaded.id == pres.id
        assert loaded.title == pres.title
        assert len(loaded.slides) == 2
        assert loaded.slides[0].content.bullets == ["一", "二"]
        assert loaded.slides[1].layout_type is LayoutType.BIG_TITLE

    def test_save_creates_parent_directories(self, tmp_path: Path) -> None:
        pres = _make_presentation()
        target = tmp_path / "nested" / "deep" / "demo.json"
        assert save_to_file(pres, target) is True
        assert target.exists()

    def test_load_missing_file_returns_none(self, tmp_path: Path) -> None:
        loaded = load_from_file(tmp_path / "does_not_exist.json")
        assert loaded is None

    def test_load_invalid_json_returns_none(self, tmp_path: Path) -> None:
        bad = tmp_path / "bad.json"
        bad.write_text("not a json", encoding="utf-8")
        assert load_from_file(bad) is None

    def test_save_updates_updated_at(self, tmp_path: Path) -> None:
        pres = _make_presentation()
        before = pres.updated_at
        target = tmp_path / "u.json"
        assert save_to_file(pres, target) is True
        # save_to_file 会刷新 updated_at
        assert pres.updated_at >= before


class TestPresentationStorageCompat:
    """PresentationStorage 兼容外壳应委托到 file_storage。"""

    def test_compat_save_and_load(self, tmp_path: Path) -> None:
        pres = _make_presentation()
        target = tmp_path / "compat.json"

        assert PresentationStorage.save(pres, target) is True
        loaded = PresentationStorage.load(target)
        assert loaded is not None
        assert loaded.id == pres.id

    def test_compat_load_missing(self, tmp_path: Path) -> None:
        assert PresentationStorage.load(tmp_path / "no.json") is None

    def test_compat_create_new(self) -> None:
        pres = PresentationStorage.create_new("X")
        assert pres.title == "X"


# ---------------------------------------------------------------------------
# IncrementalStorage
# ---------------------------------------------------------------------------


class TestIncrementalStorage:
    def test_save_full_creates_file(self, tmp_path: Path) -> None:
        pres = _make_presentation()
        target = tmp_path / "full.json"
        assert IncrementalStorage.save_full(pres, target) is True
        assert target.exists()

    def test_save_full_then_load(self, tmp_path: Path) -> None:
        pres = _make_presentation()
        target = tmp_path / "full.json"
        IncrementalStorage.save_full(pres, target)
        loaded = IncrementalStorage.load(target)
        assert loaded is not None
        assert loaded.id == pres.id
        assert len(loaded.slides) == 2

    def test_save_full_creates_backup_on_overwrite(self, tmp_path: Path) -> None:
        pres = _make_presentation()
        target = tmp_path / "full.json"

        IncrementalStorage.save_full(pres, target)
        # 第二次保存会先把原文件重命名为 .backup
        IncrementalStorage.save_full(pres, target)

        backup = target.with_suffix(IncrementalStorage.BACKUP_EXTENSION)
        assert backup.exists()

    def test_load_missing_file_returns_none(self, tmp_path: Path) -> None:
        assert IncrementalStorage.load(tmp_path / "missing.json") is None

    def test_save_incremental_no_changes_returns_true(self, tmp_path: Path) -> None:
        pres = _make_presentation()
        target = tmp_path / "inc.json"
        IncrementalStorage.save_full(pres, target)

        # 空 changes 应当直接返回 True 不做任何事
        assert IncrementalStorage.save_incremental(pres, target, {}) is True

    def test_save_incremental_falls_back_to_full_when_file_missing(self, tmp_path: Path) -> None:
        pres = _make_presentation()
        target = tmp_path / "inc_missing.json"
        # 文件不存在时，save_incremental 应回退为 save_full
        result = IncrementalStorage.save_incremental(pres, target, {"title": "新标题"})
        assert result is True
        assert target.exists()

    def test_save_incremental_applies_title_change(self, tmp_path: Path) -> None:
        pres = _make_presentation()
        target = tmp_path / "inc.json"
        IncrementalStorage.save_full(pres, target)

        assert IncrementalStorage.save_incremental(pres, target, {"title": "新标题"}) is True

        loaded = IncrementalStorage.load(target)
        assert loaded is not None
        assert loaded.title == "新标题"


# ---------------------------------------------------------------------------
# ChangeTracker
# ---------------------------------------------------------------------------


class TestChangeTracker:
    def test_no_changes_initially(self) -> None:
        pres = _make_presentation()
        tracker = ChangeTracker(pres)
        tracker.track_changes()
        assert not tracker.has_changes()

    def test_detect_title_change(self) -> None:
        pres = _make_presentation()
        tracker = ChangeTracker(pres)
        pres.title = "改了标题"
        tracker.track_changes()
        assert tracker.has_changes()

        changes = tracker.get_changes()
        assert changes["title"] is True

    def test_detect_theme_change(self) -> None:
        pres = _make_presentation()
        tracker = ChangeTracker(pres)
        pres.theme_id = "modern"
        tracker.track_changes()
        assert tracker.has_changes()
        assert tracker.get_changes()["theme"] is True

    def test_detect_slide_added(self) -> None:
        pres = _make_presentation()
        tracker = ChangeTracker(pres)
        pres.slides.append(Slide(id="new", order=2, content=SlideContent(title="新")))
        tracker.track_changes()
        assert tracker.has_changes()
        assert len(tracker.get_changes()["slides_added"]) == 1

    def test_detect_slide_removed(self) -> None:
        pres = _make_presentation()
        tracker = ChangeTracker(pres)
        pres.slides.pop(0)
        tracker.track_changes()
        assert tracker.has_changes()
        assert tracker.get_changes()["slides_removed"] == ["s1"]

    def test_detect_slide_modified(self) -> None:
        pres = _make_presentation()
        tracker = ChangeTracker(pres)
        pres.slides[0].content.title = "修改后"
        tracker.track_changes()
        assert tracker.has_changes()
        assert "s1" in tracker.get_dirty_slide_ids()

    def test_commit_changes_resets_state(self) -> None:
        pres = _make_presentation()
        tracker = ChangeTracker(pres)
        pres.title = "X"
        tracker.track_changes()
        assert tracker.has_changes()

        tracker.commit_changes()
        # commit 后应将当前状态作为新的初始状态
        tracker.track_changes()
        assert not tracker.has_changes()


# ---------------------------------------------------------------------------
# 序列化兼容层（IncrementalStorage.load 失败回退到备份）
# ---------------------------------------------------------------------------


class TestLoadBackupFallback:
    def test_load_recovers_from_backup_when_main_corrupted(self, tmp_path: Path) -> None:
        pres = _make_presentation()
        target = tmp_path / "p.json"
        # 先写入一份正常文件作为备份
        backup = target.with_suffix(IncrementalStorage.BACKUP_EXTENSION)
        backup.write_text(
            PresentationSerializer.to_json_str(pres),
            encoding="utf-8",
        )
        # 主文件写入损坏内容
        target.write_text("not-json", encoding="utf-8")

        loaded = IncrementalStorage.load(target)
        assert loaded is not None
        assert loaded.id == pres.id
