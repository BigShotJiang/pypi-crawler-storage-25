"""
自动布局引擎
根据幻灯片内容自动选择最佳布局
"""

from __future__ import annotations

from .models import LayoutType, Slide, SlideContent


class AutoLayoutEngine:
    """自动布局引擎"""

    @staticmethod
    def determine_layout(content: SlideContent) -> LayoutType:
        """
        根据内容自动确定布局类型

        Args:
            content: 幻灯片内容

        Returns:
            最佳的布局类型
        """
        # 检查是否有内容
        has_title = bool(content.title.strip())
        has_subtitle = bool(content.subtitle.strip())
        has_body = bool(content.body.strip())
        has_bullets = len(content.bullets) > 0
        has_icon = bool(content.icon)
        has_image = bool(content.image_path)

        # 仅标题的情况
        if has_title and not has_subtitle and not has_body and not has_bullets and not has_icon and not has_image:
            return LayoutType.BIG_TITLE

        # 标题 + 要点列表
        if has_title and has_bullets and not has_body and not has_icon and not has_image:
            return LayoutType.TITLE_BULLETS

        # 标题 + 内容 + 图标
        if has_title and has_body and has_icon:
            return LayoutType.TITLE_CONTENT_ICON

        # 标题 + 图片
        if has_title and has_image:
            return LayoutType.TITLE_IMAGE

        # 默认使用标题+内容布局
        return LayoutType.TITLE_CONTENT

    @staticmethod
    def apply_layout(slide: Slide) -> Slide:
        """
        应用自动布局到幻灯片

        Args:
            slide: 幻灯片

        Returns:
            更新后的幻灯片
        """
        slide.layout_type = AutoLayoutEngine.determine_layout(slide.content)
        return slide

    @staticmethod
    def optimize_slide(slide: Slide) -> Slide:
        """
        优化幻灯片内容和布局

        Args:
            slide: 幻灯片

        Returns:
            优化后的幻灯片
        """
        # 首先确定布局
        slide = AutoLayoutEngine.apply_layout(slide)

        # 可以在这里添加更多优化逻辑
        # 例如：自动调整文本长度、优化要点数量等

        return slide
