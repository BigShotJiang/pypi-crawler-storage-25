"""
Slide Editor Widget - Slide editor panel component
"""

from __future__ import annotations

import copy

from bitool.gui.compat import (
    QCheckBox,
    QComboBox,
    QFormLayout,
    QGroupBox,
    QLineEdit,
    Qt,
    QTextEdit,
    QTimer,
    QVBoxLayout,
    QWidget,
    Signal,
)

from ..assets.icons.icon_library import get_icon_names
from ..auto_layout import AutoLayoutEngine
from ..models.models import LayoutType, Slide, SlideContent


class SlideEditorWidget(QWidget):
    """
    Slide Editor Widget - edits slide content
    """

    content_changed = Signal()
    request_edit = Signal(object, object)
    request_layout_change = Signal(object, object)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.slide: Slide | None = None
        self.saved_content: SlideContent | None = None
        self.edit_timer = QTimer()
        self.edit_timer.setSingleShot(True)
        self.edit_timer.timeout.connect(self._commit_edit)
        self._setup_ui()

    def _setup_ui(self) -> None:
        """Setup UI components"""
        layout = QVBoxLayout(self)

        # Title and subtitle editing
        title_layout = QFormLayout()
        self.title_edit = QLineEdit()
        self.title_edit.textChanged.connect(self._on_content_changed_delayed)
        title_layout.addRow("标题:", self.title_edit)

        self.subtitle_edit = QLineEdit()
        self.subtitle_edit.textChanged.connect(self._on_content_changed_delayed)
        title_layout.addRow("副标题:", self.subtitle_edit)
        layout.addLayout(title_layout)

        # Content editing
        content_group = QGroupBox("正文内容")
        content_layout = QVBoxLayout()
        self.content_edit = QTextEdit()
        self.content_edit.textChanged.connect(self._on_content_changed_delayed)
        content_layout.addWidget(self.content_edit)
        content_group.setLayout(content_layout)
        layout.addWidget(content_group)

        # Bullets editing
        bullets_group = QGroupBox("要点列表")
        bullets_layout = QVBoxLayout()
        self.bullets_edit = QTextEdit()
        self.bullets_edit.setPlaceholderText("每行一个要点")
        self.bullets_edit.textChanged.connect(self._on_content_changed_delayed)
        bullets_layout.addWidget(self.bullets_edit)
        bullets_group.setLayout(bullets_layout)
        layout.addWidget(bullets_group)

        # Layout and theme settings
        settings_group = QGroupBox("设置")
        settings_layout = QFormLayout()

        self.layout_combo = QComboBox()
        for layout_type in LayoutType:
            self.layout_combo.addItem(layout_type.name, layout_type)
        self.layout_combo.currentIndexChanged.connect(self._on_layout_changed)
        settings_layout.addRow("布局:", self.layout_combo)

        self.auto_layout_check = QCheckBox("自动布局")
        self.auto_layout_check.setChecked(True)
        self.auto_layout_check.stateChanged.connect(self._on_auto_layout_changed)
        settings_layout.addRow("", self.auto_layout_check)

        self.icon_combo = QComboBox()
        self.icon_combo.addItem("无图标", None)
        for icon_name in get_icon_names():
            self.icon_combo.addItem(icon_name, icon_name)
        self.icon_combo.currentIndexChanged.connect(self._on_content_changed_delayed)
        settings_layout.addRow("图标:", self.icon_combo)

        settings_group.setLayout(settings_layout)
        layout.addWidget(settings_group)

    def set_slide(self, slide: Slide | None) -> None:
        """Set slide to edit"""
        # Commit current edit before setting new slide
        if self.slide is not None and self.saved_content is not None:
            self._commit_edit()

        self.slide = slide
        self.saved_content = None
        if slide:
            self.saved_content = copy.deepcopy(slide.content)
        self._refresh_ui()

    def _refresh_ui(self) -> None:
        """Refresh UI from slide data"""
        if not self.slide:
            self.title_edit.clear()
            self.subtitle_edit.clear()
            self.content_edit.clear()
            self.bullets_edit.clear()
            self.layout_combo.setCurrentIndex(0)
            self.icon_combo.setCurrentIndex(0)
            self.saved_content = None
            return

        # Save cursor positions
        content_cursor = self.content_edit.textCursor()
        content_pos = content_cursor.position()

        bullets_cursor = self.bullets_edit.textCursor()
        bullets_pos = bullets_cursor.position()

        # Block signals while updating
        self.title_edit.blockSignals(True)
        self.subtitle_edit.blockSignals(True)
        self.content_edit.blockSignals(True)
        self.bullets_edit.blockSignals(True)
        self.layout_combo.blockSignals(True)
        self.icon_combo.blockSignals(True)

        self.title_edit.setText(self.slide.content.title)
        self.subtitle_edit.setText(self.slide.content.subtitle)
        self.content_edit.setText(self.slide.content.body)
        self.bullets_edit.setText("\n".join(self.slide.content.bullets))

        # Restore cursor positions
        if content_pos <= len(self.slide.content.body):
            content_cursor.setPosition(content_pos)
        else:
            content_cursor.setPosition(len(self.slide.content.body))
        self.content_edit.setTextCursor(content_cursor)

        bullets_text = "\n".join(self.slide.content.bullets)
        if bullets_pos <= len(bullets_text):
            bullets_cursor.setPosition(bullets_pos)
        else:
            bullets_cursor.setPosition(len(bullets_text))
        self.bullets_edit.setTextCursor(bullets_cursor)

        # Set layout
        index = self.layout_combo.findData(self.slide.layout_type)
        if index >= 0:
            self.layout_combo.setCurrentIndex(index)

        # Set icon
        icon_index = self.icon_combo.findData(self.slide.content.icon)
        if icon_index >= 0:
            self.icon_combo.setCurrentIndex(icon_index)

        # Restore signals
        self.title_edit.blockSignals(False)
        self.subtitle_edit.blockSignals(False)
        self.content_edit.blockSignals(False)
        self.bullets_edit.blockSignals(False)
        self.layout_combo.blockSignals(False)
        self.icon_combo.blockSignals(False)

        # Update saved content
        self.saved_content = copy.deepcopy(self.slide.content)

    def _on_content_changed_delayed(self) -> None:
        """Handle content change with debounce"""
        if not self.slide:
            return

        # Update preview immediately
        self._update_slide_content()

        # Delay commit to undo stack
        self.edit_timer.start(800)

    def _update_slide_content(self) -> None:
        """Update slide content without committing to undo stack"""
        if not self.slide:
            return

        self.slide.content.title = self.title_edit.text()
        self.slide.content.subtitle = self.subtitle_edit.text()
        self.slide.content.body = self.content_edit.toPlainText()

        # Parse bullets
        bullets_text = self.bullets_edit.toPlainText()
        self.slide.content.bullets = [line.strip() for line in bullets_text.split("\n") if line.strip()]

        # Auto layout
        if self.auto_layout_check.isChecked():
            old_layout = self.slide.layout_type
            AutoLayoutEngine.apply_layout(self.slide)
            if self.slide.layout_type != old_layout:
                self.layout_combo.blockSignals(True)
                index = self.layout_combo.findData(self.slide.layout_type)
                if index >= 0:
                    self.layout_combo.setCurrentIndex(index)
                self.layout_combo.blockSignals(False)

        # Emit content changed signal
        self.content_changed.emit()

    def _commit_edit(self) -> None:
        """Commit edit to undo stack"""
        if not self.slide or self.saved_content is None:
            return

        # Create new content object
        new_content = SlideContent(
            title=self.title_edit.text(),
            subtitle=self.subtitle_edit.text(),
            body=self.content_edit.toPlainText(),
            bullets=[line.strip() for line in self.bullets_edit.toPlainText().split("\n") if line.strip()],
            icon=self.icon_combo.itemData(self.icon_combo.currentIndex()),
        )

        # Check if content actually changed
        old_dict = {
            "title": self.saved_content.title,
            "subtitle": self.saved_content.subtitle,
            "body": self.saved_content.body,
            "bullets": self.saved_content.bullets,
            "icon": self.saved_content.icon,
        }
        new_dict = {
            "title": new_content.title,
            "subtitle": new_content.subtitle,
            "body": new_content.body,
            "bullets": new_content.bullets,
            "icon": new_content.icon,
        }

        if old_dict != new_dict:
            self.request_edit.emit(self.saved_content, new_content)

        # Update saved content
        self.saved_content = copy.deepcopy(new_content)

    def _on_layout_changed(self, index: int) -> None:
        """Handle layout change"""
        if self.slide:
            old_layout = self.slide.layout_type
            new_layout = self.layout_combo.itemData(index)
            if old_layout != new_layout:
                self._commit_edit()
                self.request_layout_change.emit(old_layout, new_layout)

    def _on_auto_layout_changed(self, state: int) -> None:
        """Handle auto layout toggle"""
        if state == Qt.CheckState.Checked and self.slide:
            AutoLayoutEngine.apply_layout(self.slide)
            self._refresh_ui()

    def _on_icon_changed(self, index: int) -> None:
        """Handle icon change (handled by _on_content_changed_delayed)"""
        pass
