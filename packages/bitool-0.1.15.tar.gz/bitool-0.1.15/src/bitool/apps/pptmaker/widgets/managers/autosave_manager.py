"""
自动保存管理器

负责自动保存定时器的创建与管理，周期性检测变更并触发持久化。
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from bitool.gui.compat import QTimer

from ...storage import get_auto_save_manager

if TYPE_CHECKING:
    from ..main_window import PPTMakerWindow


class AutoSaveManager:
    """自动保存管理器

    封装自动保存定时器逻辑，在主窗口中以固定间隔检测变更，
    并在条件满足时自动将演示文稿保存到磁盘。
    """

    def __init__(self, window: PPTMakerWindow, interval_ms: int = 1000) -> None:
        self._window = window
        self._storage_manager = get_auto_save_manager()

        # 创建定时器
        self._timer = QTimer(window)
        self._timer.setInterval(interval_ms)
        self._timer.timeout.connect(self._check_auto_save)
        self._timer.start()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def reset(self) -> None:
        """重置自动保存状态（用于新建/打开文件后）"""
        self._storage_manager.reset()

    def mark_dirty(self) -> None:
        """标记文档为脏状态（有未保存更改）"""
        self._storage_manager.mark_dirty()

    def stop(self) -> None:
        """停止自动保存定时器"""
        self._timer.stop()

    def start(self) -> None:
        """启动自动保存定时器"""
        self._timer.start()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _check_auto_save(self) -> None:
        """检查是否需要自动保存"""
        w = self._window
        if w.presentation and w.current_file:
            # 检测变更
            if w.change_tracker:
                w.change_tracker.track_changes()
                if w.change_tracker.has_changes():
                    self._storage_manager.mark_dirty()

            # 执行保存
            saved = self._storage_manager.check_and_save(w.presentation, w.current_file)
            if saved and w.change_tracker:
                w.change_tracker.commit_changes()
