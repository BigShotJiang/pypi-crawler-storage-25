"""
文件管理器

负责演示文稿的新建、打开、保存、导出以及近期文件管理。
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from bitool.gui.compat import QDialog, QFileDialog, QMessageBox

from ...config import get_config
from ...demos import get_demo_manager
from ...models import PresentationStorage
from ...ppt_generator import PPTGenerator
from ...storage import ChangeTracker

if TYPE_CHECKING:
    from ..main_window import PPTMakerWindow


class FileManager:
    """文件操作管理器

    管理演示文稿的创建、打开、保存、导出及近期文件列表。
    通过持有主窗口引用来访问共享状态和更新 UI。
    """

    def __init__(self, window: PPTMakerWindow) -> None:
        self._window = window

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def new_presentation(self) -> None:
        """创建新演示文稿"""
        w = self._window
        w.presentation = PresentationStorage.create_new("未命名演示文稿")
        w.current_file = None
        w.command_manager.clear()
        w.change_tracker = ChangeTracker(w.presentation)
        w.preview_cache.invalidate_all()
        w.autosave_manager.reset()
        w._refresh_ui()
        w.setWindowTitle("PPT Maker - 新演示文稿")

    def open_presentation(self) -> None:
        """打开演示文稿文件"""
        w = self._window
        file_path, _ = QFileDialog.getOpenFileName(
            w, "打开演示文稿", "", "PPT Maker 文件 (*.pptm.json);;所有文件 (*.*)",
        )
        if file_path:
            path = Path(file_path)
            presentation = PresentationStorage.load(path)
            if presentation:
                w.presentation = presentation
                w.current_file = path
                w.command_manager.clear()
                w.change_tracker = ChangeTracker(w.presentation)
                w.preview_cache.invalidate_all()
                w._refresh_ui()
                w.setWindowTitle(f"PPT Maker - {path.name}")
                config = get_config()
                config.add_recent_file(str(path))
                self.update_recent_menu()
            else:
                QMessageBox.warning(w, "错误", "无法打开文件")

    def save_presentation(self) -> None:
        """保存演示文稿"""
        w = self._window
        if not w.presentation:
            return

        if w.editor.slide is not None and w.editor.saved_content is not None:
            w.editor._commit_edit()

        success = False
        if w.current_file:
            success = PresentationStorage.save(w.presentation, w.current_file)
        else:
            file_path, _ = QFileDialog.getSaveFileName(
                w, "保存演示文稿", "", "PPT Maker 文件 (*.pptm.json);;所有文件 (*.*)",
            )
            if file_path:
                path = Path(file_path)
                if not path.suffix:
                    path = path.with_suffix(".pptm.json")
                success = PresentationStorage.save(w.presentation, path)
                if success:
                    w.current_file = path
                    w.setWindowTitle(f"PPT Maker - {path.name}")
                    config = get_config()
                    config.add_recent_file(str(path))
                    self.update_recent_menu()

        if not success:
            QMessageBox.warning(w, "错误", "保存失败")

    def export_ppt(self) -> None:
        """导出为 PowerPoint 文件"""
        w = self._window
        if not w.presentation or not w.presentation.slides:
            QMessageBox.warning(w, "提示", "请先添加幻灯片")
            return

        file_path, _ = QFileDialog.getSaveFileName(w, "导出PPT", "", "PowerPoint 文件 (*.pptx);;所有文件 (*.*)")
        if file_path:
            path = Path(file_path)
            if not path.suffix:
                path = path.with_suffix(".pptx")

            generator = PPTGenerator(w.presentation)
            success = generator.generate(path)

            if success:
                QMessageBox.information(w, "成功", f"PPT已导出到:\n{path}")
            else:
                QMessageBox.warning(w, "错误", "导出失败")

    def load_demo(self) -> None:
        """加载示例演示文稿"""
        from ..main_window import DemoDialog

        w = self._window
        dialog = DemoDialog(w)
        if dialog.exec_() == QDialog.DialogCode.Accepted and dialog.selected_demo_id:
            demo_manager = get_demo_manager()
            presentation = demo_manager.load_demo(dialog.selected_demo_id)

            if presentation:
                w.presentation = presentation
                w.current_file = None
                w.command_manager.clear()
                w.change_tracker = ChangeTracker(w.presentation)
                w.preview_cache.invalidate_all()
                w._refresh_ui()
                w.setWindowTitle(f"PPT Maker - {presentation.title} (示例)")
            else:
                QMessageBox.warning(w, "错误", "无法加载示例")

    # ------------------------------------------------------------------
    # Recent files
    # ------------------------------------------------------------------

    def update_recent_menu(self) -> None:
        """更新近期文件菜单"""
        w = self._window
        w.recent_menu.clear()
        config = get_config()
        if not config.recent_files:
            no_recent = w.recent_menu.addAction("无近期文件")
            no_recent.setEnabled(False)
            return

        for i, file_path in enumerate(config.recent_files):
            path = Path(file_path)
            action = w.recent_menu.addAction(f"{i + 1}. {path.name}")
            action.setData(file_path)
            action.triggered.connect(lambda checked=False, fp=file_path: self._open_recent_file(fp))

        w.recent_menu.addSeparator()
        clear_action = w.recent_menu.addAction("清空列表")
        clear_action.triggered.connect(self._clear_recent_files)

    def _open_recent_file(self, file_path: str) -> None:
        """打开近期文件"""
        w = self._window
        path = Path(file_path)
        if not path.exists():
            QMessageBox.warning(w, "错误", "文件不存在")
            config = get_config()
            config.recent_files.remove(file_path)
            config.save()
            self.update_recent_menu()
            return

        presentation = PresentationStorage.load(path)
        if presentation:
            w.presentation = presentation
            w.current_file = path
            w._refresh_ui()
            w.setWindowTitle(f"PPT Maker - {path.name}")
            config = get_config()
            config.add_recent_file(str(path))
            self.update_recent_menu()
        else:
            QMessageBox.warning(w, "错误", "无法打开文件")

    def _clear_recent_files(self) -> None:
        """清空近期文件列表"""
        config = get_config()
        config.clear_recent_files()
        self.update_recent_menu()
