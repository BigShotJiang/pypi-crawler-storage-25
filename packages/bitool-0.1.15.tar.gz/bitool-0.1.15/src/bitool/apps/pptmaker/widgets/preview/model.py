"""
Preview Model - Manages preview data and state
"""

from __future__ import annotations

from bitool.gui.compat import QObject, Signal

from ...models.models import Presentation, Slide
from ...models.presets import get_theme_by_id


class PreviewModel(QObject):
    """
    Preview Model - manages preview state and data
    """

    data_changed = Signal()
    current_index_changed = Signal(int)
    presentation_changed = Signal()
    slide_index_changed = Signal(int)

    def __init__(self) -> None:
        super().__init__()
        self._presentation: Presentation | None = None
        self._current_slide_index: int = 0
        self._thumbnail_size_index: int = 1
        self._thumbnail_sizes: list[tuple[int, int]] = [(80, 60), (120, 90), (160, 120)]
        self._thumbnail_scales: list[float] = [0.18, 0.25, 0.33]
        self._view_mode: str = "horizontal"

    @property
    def presentation(self) -> Presentation | None:
        return self._presentation

    @presentation.setter
    def presentation(self, value: Presentation | None) -> None:
        self._presentation = value
        self._current_slide_index = 0
        self.presentation_changed.emit()
        self.data_changed.emit()

    @property
    def current_slide_index(self) -> int:
        return self._current_slide_index

    @current_slide_index.setter
    def current_slide_index(self, value: int) -> None:
        if self._presentation and 0 <= value < len(self._presentation.slides):
            self._current_slide_index = value
            self.current_index_changed.emit(value)
            self.slide_index_changed.emit(value)
            self.data_changed.emit()

    @property
    def current_slide(self) -> Slide | None:
        if self._presentation and 0 <= self._current_slide_index < len(self._presentation.slides):
            return self._presentation.slides[self._current_slide_index]
        return None

    @property
    def theme(self):
        if self._presentation:
            return get_theme_by_id(self._presentation.theme_id)
        return None

    @property
    def thumbnail_size_index(self) -> int:
        return self._thumbnail_size_index

    @thumbnail_size_index.setter
    def thumbnail_size_index(self, value: int) -> None:
        if 0 <= value < len(self._thumbnail_sizes):
            self._thumbnail_size_index = value
            self.data_changed.emit()

    @property
    def thumbnail_size(self) -> tuple[int, int]:
        return self._thumbnail_sizes[self._thumbnail_size_index]

    @property
    def thumbnail_scale(self) -> float:
        return self._thumbnail_scales[self._thumbnail_size_index]

    @property
    def view_mode(self) -> str:
        return self._view_mode

    @view_mode.setter
    def view_mode(self, value: str) -> None:
        if value in ["horizontal", "vertical", "grid"]:
            self._view_mode = value
            self.data_changed.emit()

    def get_slide_count(self) -> int:
        if self._presentation:
            return len(self._presentation.slides)
        return 0

    def get_slide(self, index: int) -> Slide | None:
        if self._presentation and 0 <= index < len(self._presentation.slides):
            return self._presentation.slides[index]
        return None

    def next_slide(self) -> None:
        if self._presentation and self._current_slide_index < len(self._presentation.slides) - 1:
            self.current_slide_index += 1

    def previous_slide(self) -> None:
        if self._current_slide_index > 0:
            self.current_slide_index -= 1

    def refresh_data(self) -> None:
        """Notify that data has changed"""
        self.data_changed.emit()
