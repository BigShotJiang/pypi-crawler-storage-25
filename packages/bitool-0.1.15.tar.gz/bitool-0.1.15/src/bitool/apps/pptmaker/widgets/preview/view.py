"""
Preview View - Complete preview panel UI
"""

from __future__ import annotations

from typing import Callable

from bitool.gui.compat import (
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMouseEvent,
    QPushButton,
    QScrollArea,
    QSize,
    QSizePolicy,
    Qt,
    QVBoxLayout,
    QWidget,
    Signal,
)

from ...models import Presentation, Slide
from .controller import PreviewController
from .renderer import SlidePreviewWidget


class PreviewPanel(QWidget):
    """
    Preview Panel - Complete preview UI with thumbnails and main preview
    """

    slide_index_changed = Signal(int)

    def __init__(self, controller: PreviewController, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._controller = controller
        self._model = controller.model
        self._thumbnails: list[SlidePreviewWidget] = []
        self._setup_ui()
        self._connect_signals()

    def _setup_ui(self) -> None:
        """Setup UI components"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)

        # Title and control bar
        title_control_layout = QHBoxLayout()

        title_label = QLabel("实时预览")
        title_label.setFont(title_label.font())
        title_label.setFont(title_label.font())
        title_label_font = title_label.font()
        title_label_font.setPointSize(12)
        title_label_font.setBold(True)
        title_label.setFont(title_label_font)
        title_control_layout.addWidget(title_label)
        title_control_layout.addStretch()

        # View mode selector
        view_mode_label = QLabel("视图:")
        title_control_layout.addWidget(view_mode_label)

        self.view_mode_combo = QComboBox()
        self.view_mode_combo.addItem("水平", "horizontal")
        self.view_mode_combo.addItem("垂直", "vertical")
        self.view_mode_combo.addItem("网格", "grid")
        self.view_mode_combo.currentIndexChanged.connect(self._on_view_mode_changed)
        title_control_layout.addWidget(self.view_mode_combo)

        title_control_layout.addSpacing(10)

        # Thumbnail size selector
        size_label = QLabel("尺寸:")
        title_control_layout.addWidget(size_label)

        self.size_combo = QComboBox()
        self.size_combo.addItem("小", 0)
        self.size_combo.addItem("中", 1)
        self.size_combo.addItem("大", 2)
        self.size_combo.setCurrentIndex(self._model.thumbnail_size_index)
        self.size_combo.currentIndexChanged.connect(self._on_size_changed)
        title_control_layout.addWidget(self.size_combo)

        layout.addLayout(title_control_layout)

        # Thumbnail scroll area
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        self.thumbnail_container = QWidget()
        self.thumbnail_layout = QHBoxLayout(self.thumbnail_container)
        self.thumbnail_layout.setSpacing(10)
        self.thumbnail_layout.setAlignment(Qt.AlignLeft | Qt.AlignTop)

        scroll_area.setWidget(self.thumbnail_container)
        scroll_area.setMinimumHeight(180)
        scroll_area.setMaximumHeight(250)
        layout.addWidget(scroll_area)

        # Current slide preview
        preview_label = QLabel("当前页面预览")
        preview_label_font = preview_label.font()
        preview_label_font.setPointSize(11)
        preview_label_font.setBold(True)
        preview_label.setFont(preview_label_font)
        layout.addWidget(preview_label)

        self.preview_widget = SlidePreviewWidget(use_auto_scale=True)
        self.preview_widget.setMinimumSize(QSize(300, 225))
        self.preview_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        layout.addWidget(self.preview_widget)

        # Navigation buttons
        nav_layout = QHBoxLayout()
        self.prev_btn = QPushButton("◀ 上一页")
        self.prev_btn.clicked.connect(self._on_prev_clicked)
        self.next_btn = QPushButton("下一页 ▶")
        self.next_btn.clicked.connect(self._on_next_clicked)
        nav_layout.addWidget(self.prev_btn)
        nav_layout.addStretch()
        nav_layout.addWidget(self.next_btn)
        layout.addLayout(nav_layout)

        # Page indicator
        self.page_indicator = QLabel("第 1 页 / 共 1 页")
        self.page_indicator.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.page_indicator)

    def _connect_signals(self) -> None:
        """Connect model signals"""
        self._model.data_changed.connect(self._on_data_changed)
        self._model.current_index_changed.connect(self._on_current_index_changed)
        self._model.presentation_changed.connect(self._on_presentation_changed)
        self._controller.slide_index_changed.connect(self.slide_index_changed)

    def _on_view_mode_changed(self, index: int) -> None:
        """Handle view mode change"""
        view_mode = self.view_mode_combo.itemData(index)
        self._controller.set_view_mode(view_mode)

    def _on_size_changed(self, index: int) -> None:
        """Handle thumbnail size change"""
        self._controller.set_thumbnail_size(index)

    def _on_prev_clicked(self) -> None:
        """Handle previous button click"""
        self._controller.previous_slide()

    def _on_next_clicked(self) -> None:
        """Handle next button click"""
        self._controller.next_slide()

    def _on_data_changed(self) -> None:
        """Handle data change from model"""
        self._update_thumbnails()
        self._update_preview()
        self._update_page_indicator()
        self._update_nav_buttons()

    def _on_current_index_changed(self, index: int) -> None:
        """Handle current index change"""
        self._update_thumbnail_selection()
        self._update_preview()
        self._update_page_indicator()
        self._update_nav_buttons()

    def _on_presentation_changed(self) -> None:
        """Handle presentation change"""
        self._on_data_changed()

    def _create_thumbnail_widget(self, slide: Slide, index: int) -> SlidePreviewWidget:
        """Create a thumbnail widget"""
        thumb_widget = SlidePreviewWidget(
            slide,
            self._model.theme,
            scale=self._model.thumbnail_scale,
        )
        thumb_widget.setFixedSize(QSize(*self._model.thumbnail_size))

        # Bind click event
        def make_click_handler(idx: int) -> Callable[[QMouseEvent], None]:
            def handler(event: QMouseEvent) -> None:
                self._controller.set_current_slide_index(idx)

            return handler

        thumb_widget.mousePressEvent = make_click_handler(index)
        return thumb_widget

    def _update_thumbnails(self) -> None:
        """Update thumbnail area"""
        # Clear existing thumbnails
        while self.thumbnail_layout.count():
            item = self.thumbnail_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self._thumbnails = []

        # Create new layout based on view mode
        view_mode = self._model.view_mode
        if view_mode == "horizontal":
            new_layout = QHBoxLayout()
            new_layout.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        elif view_mode == "vertical":
            new_layout = QVBoxLayout()
            new_layout.setAlignment(Qt.AlignTop | Qt.AlignHCenter)
        else:
            new_layout = QGridLayout()
            new_layout.setAlignment(Qt.AlignLeft | Qt.AlignTop)

        new_layout.setSpacing(10)
        new_layout.setContentsMargins(0, 0, 0, 0)

        # Replace layout
        old_layout = self.thumbnail_layout
        self.thumbnail_layout = new_layout
        self.thumbnail_container.setLayout(new_layout)
        if old_layout:
            old_layout.deleteLater()

        if not self._model.presentation:
            return

        # Create thumbnails
        for i in range(self._model.get_slide_count()):
            slide = self._model.get_slide(i)
            if slide:
                thumbnail = self._create_thumbnail_widget(slide, i)
                self._thumbnails.append(thumbnail)

                if view_mode == "grid":
                    row = i // 3
                    col = i % 3
                    self.thumbnail_layout.addWidget(thumbnail, row, col)
                else:
                    self.thumbnail_layout.addWidget(thumbnail)

        # Add stretch
        if view_mode in ["horizontal", "vertical"]:
            self.thumbnail_layout.addStretch()

        self._update_thumbnail_selection()

    def _update_thumbnail_selection(self) -> None:
        """Update thumbnail selection state"""
        current_index = self._model.current_slide_index
        for i, widget in enumerate(self._thumbnails):
            if i == current_index:
                widget.setFrameStyle(QFrame.Box | QFrame.Raised)
                widget.setStyleSheet("border: 3px solid #1e40af;")
            else:
                widget.setFrameStyle(QFrame.Box | QFrame.Sunken)
                widget.setStyleSheet("border: 1px solid #ccc;")

    def _update_preview(self) -> None:
        """Update main preview area"""
        slide = self._model.current_slide
        theme = self._model.theme
        if slide and theme:
            self.preview_widget.set_slide(slide, theme)

    def _update_page_indicator(self) -> None:
        """Update page indicator text"""
        total = self._model.get_slide_count()
        current = self._model.current_slide_index + 1
        self.page_indicator.setText(f"第 {current} 页 / 共 {total} 页")

    def _update_nav_buttons(self) -> None:
        """Update navigation button states"""
        index = self._model.current_slide_index
        total = self._model.get_slide_count()
        self.prev_btn.setEnabled(index > 0)
        self.next_btn.setEnabled(index < total - 1)

    def set_presentation(self, presentation: Presentation | None) -> None:
        """Set presentation to preview"""
        self._controller.set_presentation(presentation)

    def set_current_index(self, index: int) -> None:
        """Set current slide index"""
        self._controller.set_current_slide_index(index)

    def refresh(self) -> None:
        """Refresh preview"""
        self._controller.refresh()
