"""
Slide List Widget - Slide list panel component
"""

from __future__ import annotations

import uuid

from bitool.gui.compat import (
    QAction,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMenu,
    QPushButton,
    Qt,
    QVBoxLayout,
    QWidget,
    Signal,
)

from ..assets.icons import get_icon
from ..models.models import Presentation, Slide


class SlideListWidget(QWidget):
    """
    Slide List Widget - displays and manages slide list
    """

    slide_selected = Signal(str)
    slide_added = Signal()
    slide_removed = Signal()
    slide_copy = Signal(int)
    request_add_slide = Signal(object)
    request_remove_slide = Signal(int)
    request_copy_slide = Signal(int)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.presentation: Presentation | None = None
        self._setup_ui()

    def _setup_ui(self) -> None:
        """Setup UI components"""
        layout = QVBoxLayout(self)

        # Title
        title_label = QLabel("幻灯片")
        title_font = title_label.font()
        title_font.setPointSize(12)
        title_font.setBold(True)
        title_label.setFont(title_font)
        layout.addWidget(title_label)

        # Slide list
        self.list_widget = QListWidget()
        self.list_widget.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.list_widget.customContextMenuRequested.connect(self._show_context_menu)
        self.list_widget.currentRowChanged.connect(self._on_slide_selected)
        layout.addWidget(self.list_widget)

        # Button group
        btn_layout = QHBoxLayout()
        self.add_btn = QPushButton("+ 添加")
        add_icon = get_icon("plus", color="#333333")
        if add_icon:
            self.add_btn.setIcon(add_icon)
        self.add_btn.clicked.connect(self._add_slide)
        self.remove_btn = QPushButton("- 删除")
        remove_icon = get_icon("trash", color="#333333")
        if remove_icon:
            self.remove_btn.setIcon(remove_icon)
        self.remove_btn.clicked.connect(self._remove_slide)
        btn_layout.addWidget(self.add_btn)
        btn_layout.addWidget(self.remove_btn)
        layout.addLayout(btn_layout)

    def set_presentation(self, presentation: Presentation) -> None:
        """Set presentation to display"""
        self.presentation = presentation
        self._refresh_list()

    def _refresh_list(self) -> None:
        """Refresh the slide list"""
        self.list_widget.clear()
        if not self.presentation:
            return

        for i, slide in enumerate(self.presentation.slides):
            title = slide.content.title or f"幻灯片 {i + 1}"
            item_text = f"{i + 1}. {title}"
            item = QListWidgetItem(item_text)
            item.setData(Qt.ItemDataRole.UserRole, slide.id)
            self.list_widget.addItem(item)

    def _add_slide(self) -> None:
        """Add a new slide"""
        if not self.presentation:
            return

        slide_id = str(uuid.uuid4())
        from ..models.models import SlideContent

        new_slide = Slide(id=slide_id, order=len(self.presentation.slides), content=SlideContent(title="新幻灯片"))
        self.request_add_slide.emit(new_slide)

    def _remove_slide(self) -> None:
        """Remove current slide"""
        if not self.presentation:
            return

        current_row = self.list_widget.currentRow()
        if current_row >= 0:
            self.request_remove_slide.emit(current_row)

    def _on_slide_selected(self, row: int) -> None:
        """Handle slide selection"""
        if row >= 0 and self.presentation and row < len(self.presentation.slides):
            slide_id = self.presentation.slides[row].id
            self.slide_selected.emit(slide_id)

    def _show_context_menu(self, pos) -> None:
        """Show context menu"""
        current_row = self.list_widget.currentRow()
        if current_row < 0:
            return

        menu = QMenu(self)

        # Copy action
        copy_action = QAction("复制幻灯片", self)
        copy_icon = get_icon("copy", color="#333333")
        if copy_icon:
            copy_action.setIcon(copy_icon)
        copy_action.triggered.connect(lambda: self._copy_slide(current_row))
        menu.addAction(copy_action)

        menu.addSeparator()

        # Delete action
        delete_action = QAction("删除", self)
        delete_icon = get_icon("trash", color="#333333")
        if delete_icon:
            delete_action.setIcon(delete_icon)
        delete_action.triggered.connect(self._remove_slide)
        menu.addAction(delete_action)

        menu.exec_(self.list_widget.mapToGlobal(pos))

    def _copy_slide(self, index: int) -> None:
        """Copy slide at index"""
        if not self.presentation or index < 0 or index >= len(self.presentation.slides):
            return

        self.request_copy_slide.emit(index)

    def set_current_index(self, index: int) -> None:
        """Set current slide index (called from preview panel)"""
        if not self.presentation or index < 0 or index >= len(self.presentation.slides):
            return
        self.list_widget.blockSignals(True)
        self.list_widget.setCurrentRow(index)
        self.list_widget.blockSignals(False)
