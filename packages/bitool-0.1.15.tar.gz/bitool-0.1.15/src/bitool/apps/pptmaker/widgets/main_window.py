"""
PPT Maker Main Window

主窗口负责 UI 布局与组件协调，具体业务逻辑委托给各管理器：
- FileManager: 文件操作
- CommandManager: 命令栈/撤销重做
- AutoSaveManager: 自动保存
- ThemeManager: 主题管理
"""

from __future__ import annotations

import sys
from pathlib import Path

from bitool.gui.compat import (
    QAction,
    QApplication,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QKeySequence,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMenu,
    QMenuBar,
    QMessageBox,
    QPushButton,
    QShortcut,
    QSize,
    QSplitter,
    Qt,
    QVBoxLayout,
    QWidget,
)

from ..assets.icons import get_icon
from ..demos import get_demo_manager
from ..models import Presentation, Slide, SlideContent, get_preset_themes
from ..storage import ChangeTracker
from .managers import AutoSaveManager, CommandManager, FileManager, ThemeManager
from .preview import PreviewController, PreviewModel, PreviewPanel, get_preview_cache
from .slide_editor import SlideEditorWidget
from .slide_list import SlideListWidget


class DemoDialog(QDialog):
    """Demo selection dialog"""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.selected_demo_id: str | None = None
        self._setup_ui()
        self._load_demos()

    def _setup_ui(self) -> None:
        """Setup UI components"""
        self.setWindowTitle("选择示例")
        self.setMinimumSize(QSize(600, 400))

        layout = QVBoxLayout(self)

        # Title
        title_label = QLabel("选择一个示例模板")
        title_font = title_label.font()
        title_font.setPointSize(14)
        title_font.setBold(True)
        title_label.setFont(title_font)
        layout.addWidget(title_label)

        # Category filter
        filter_layout = QHBoxLayout()
        filter_layout.addWidget(QLabel("分类:"))
        self.category_combo = QComboBox()
        self.category_combo.addItem("全部", None)
        self.category_combo.currentIndexChanged.connect(self._on_category_changed)
        filter_layout.addWidget(self.category_combo)
        filter_layout.addStretch()
        layout.addLayout(filter_layout)

        # Demo list
        self.demo_list = QListWidget()
        self.demo_list.itemDoubleClicked.connect(self.accept)
        self.demo_list.currentItemChanged.connect(self._on_demo_changed)
        layout.addWidget(self.demo_list)

        # Description
        desc_group = QGroupBox("描述")
        desc_layout = QVBoxLayout()
        self.desc_label = QLabel()
        self.desc_label.setWordWrap(True)
        desc_layout.addWidget(self.desc_label)
        desc_group.setLayout(desc_layout)
        layout.addWidget(desc_group)

        # Buttons
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _load_demos(self) -> None:
        """Load demo list"""
        demo_manager = get_demo_manager()

        # Add categories
        current_index = self.category_combo.currentIndex()
        current_category = self.category_combo.itemData(current_index)

        self.category_combo.blockSignals(True)
        self.category_combo.clear()
        self.category_combo.addItem("全部", None)
        for category in demo_manager.get_categories():
            self.category_combo.addItem(category, category)

        # Restore previous selection
        if current_category:
            index = self.category_combo.findData(current_category)
            if index >= 0:
                self.category_combo.setCurrentIndex(index)
        self.category_combo.blockSignals(False)

        self._refresh_demo_list()

    def _refresh_demo_list(self) -> None:
        """Refresh demo list"""
        demo_manager = get_demo_manager()
        current_index = self.category_combo.currentIndex()
        category = self.category_combo.itemData(current_index)

        demos = demo_manager.get_demos(category)

        self.demo_list.clear()
        for demo in demos:
            item = QListWidgetItem(f"{demo.name} ({demo.category})")
            item.setData(Qt.ItemDataRole.UserRole, demo.id)
            self.demo_list.addItem(item)

    def _on_category_changed(self, index: int) -> None:
        """Handle category change"""
        self._refresh_demo_list()

    def _on_demo_changed(self, current: QListWidgetItem | None, previous: QListWidgetItem | None) -> None:
        """Handle demo selection change"""
        if not current:
            self.desc_label.setText("")
            return

        demo_id = current.data(Qt.ItemDataRole.UserRole)
        demo_manager = get_demo_manager()
        demo = demo_manager.get_demo(demo_id)

        if demo:
            self.desc_label.setText(demo.description)
        else:
            self.desc_label.setText("")

    def accept(self) -> None:
        """Accept dialog"""
        current_item = self.demo_list.currentItem()
        if current_item:
            self.selected_demo_id = current_item.data(Qt.ItemDataRole.UserRole)
        super().accept()


class PPTMakerWindow(QMainWindow):
    """PPT Maker main window

    充当中介者角色，负责 UI 布局和组件间信号连接。
    具体业务逻辑委托给各管理器类处理。
    """

    def __init__(self) -> None:
        super().__init__()
        self.presentation: Presentation | None = None
        self.current_file: Path | None = None
        self.change_tracker: ChangeTracker | None = None
        self.preview_cache = get_preview_cache()

        # Initialize managers
        self.command_manager = CommandManager(self)
        self.file_manager = FileManager(self)
        self.autosave_manager = AutoSaveManager(self)
        self.theme_manager = ThemeManager(self)

        self._setup_ui()
        self.file_manager.new_presentation()

    def _setup_ui(self) -> None:
        """Setup UI components"""
        self.setWindowTitle("PPT Maker - 演示文稿生成器")
        self.setMinimumSize(QSize(1200, 800))

        # Create preview MVC
        self.preview_model = PreviewModel()
        self.preview_controller = PreviewController(self.preview_model)

        # Create menu bar
        self._create_menu_bar()

        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QVBoxLayout(central_widget)

        # Toolbar
        toolbar = self._create_toolbar()
        main_layout.addLayout(toolbar)

        # Main content area with splitter
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left - slide list
        self.slide_list = SlideListWidget()
        self.slide_list.slide_selected.connect(self._on_slide_selected)
        self.slide_list.request_add_slide.connect(self._on_request_add_slide)
        self.slide_list.request_remove_slide.connect(self._on_request_remove_slide)
        self.slide_list.request_copy_slide.connect(self._on_request_copy_slide)
        splitter.addWidget(self.slide_list)

        # Middle - editor
        self.editor = SlideEditorWidget()
        self.editor.content_changed.connect(self._on_editor_content_changed)
        self.editor.request_edit.connect(self._on_request_edit)
        self.editor.request_layout_change.connect(self._on_request_layout_change)
        splitter.addWidget(self.editor)

        # Right panel - preview and settings
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)

        # Presentation info
        info_group = QGroupBox("演示文稿信息")
        info_layout = QFormLayout()
        self.presentation_title_edit = QLineEdit()
        self.presentation_title_edit.textChanged.connect(self._on_title_changed)
        info_layout.addRow("标题:", self.presentation_title_edit)
        info_group.setLayout(info_layout)
        right_layout.addWidget(info_group)

        # Preview panel
        self.preview_panel = PreviewPanel(self.preview_controller)
        self.preview_panel.slide_index_changed.connect(self._on_preview_slide_changed)
        right_layout.addWidget(self.preview_panel)

        right_layout.addStretch()
        splitter.addWidget(right_panel)

        splitter.setSizes([250, 500, 250])
        main_layout.addWidget(splitter)

        # Setup shortcuts
        self._setup_shortcuts()

    def _setup_shortcuts(self) -> None:
        """Setup keyboard shortcuts"""
        undo_shortcut = QShortcut(QKeySequence.StandardKey.Undo, self)
        undo_shortcut.activated.connect(self.command_manager.undo)

        redo_shortcut = QShortcut(QKeySequence.StandardKey.Redo, self)
        redo_shortcut.activated.connect(self.command_manager.redo)

    def _create_menu_bar(self) -> None:
        """Create menu bar"""
        menu_bar = QMenuBar(self)
        self.setMenuBar(menu_bar)

        # File menu
        file_menu = menu_bar.addMenu("文件(&F)")

        # New
        new_action = QAction("新建(&N)", self)
        new_icon = get_icon("file_plus", color="#333333")
        if new_icon:
            new_action.setIcon(new_icon)
        new_action.triggered.connect(self.file_manager.new_presentation)
        new_action.setShortcut("Ctrl+N")
        file_menu.addAction(new_action)

        # Open
        open_action = QAction("打开(&O)", self)
        open_icon = get_icon("file_open", color="#333333")
        if open_icon:
            open_action.setIcon(open_icon)
        open_action.triggered.connect(self.file_manager.open_presentation)
        open_action.setShortcut("Ctrl+O")
        file_menu.addAction(open_action)

        # Recent files submenu
        self.recent_menu = QMenu("近期文件(&R)", self)
        self.file_manager.update_recent_menu()
        file_menu.addMenu(self.recent_menu)

        file_menu.addSeparator()

        # Save
        save_action = QAction("保存(&S)", self)
        save_icon = get_icon("save", color="#333333")
        if save_icon:
            save_action.setIcon(save_icon)
        save_action.triggered.connect(self.file_manager.save_presentation)
        save_action.setShortcut("Ctrl+S")
        file_menu.addAction(save_action)

        file_menu.addSeparator()

        # Export PPT
        export_action = QAction("导出 PPT(&E)", self)
        export_icon = get_icon("download", color="#333333")
        if export_icon:
            export_action.setIcon(export_icon)
        export_action.triggered.connect(self.file_manager.export_ppt)
        file_menu.addAction(export_action)

    def _create_toolbar(self) -> QHBoxLayout:
        """Create toolbar layout"""
        layout = QHBoxLayout()

        # File operations
        new_btn = QPushButton("新建")
        new_icon = get_icon("file_plus", color="#333333")
        if new_icon:
            new_btn.setIcon(new_icon)
        new_btn.clicked.connect(self.file_manager.new_presentation)
        layout.addWidget(new_btn)

        open_btn = QPushButton("打开")
        open_icon = get_icon("file_open", color="#333333")
        if open_icon:
            open_btn.setIcon(open_icon)
        open_btn.clicked.connect(self.file_manager.open_presentation)
        layout.addWidget(open_btn)

        save_btn = QPushButton("保存")
        save_icon = get_icon("save", color="#333333")
        if save_icon:
            save_btn.setIcon(save_icon)
        save_btn.clicked.connect(self.file_manager.save_presentation)
        layout.addWidget(save_btn)

        layout.addSpacing(10)

        # Separator
        line1 = QWidget()
        line1.setFixedWidth(2)
        line1.setStyleSheet("background-color: #ccc;")
        layout.addWidget(line1)
        layout.addSpacing(10)

        # Undo/Redo
        self.undo_btn = QPushButton("撤销")
        undo_icon = get_icon("undo", color="#333333")
        if undo_icon:
            self.undo_btn.setIcon(undo_icon)
        self.undo_btn.clicked.connect(self.command_manager.undo)
        self.undo_btn.setEnabled(False)
        layout.addWidget(self.undo_btn)

        self.redo_btn = QPushButton("重做")
        redo_icon = get_icon("redo", color="#333333")
        if redo_icon:
            self.redo_btn.setIcon(redo_icon)
        self.redo_btn.clicked.connect(self.command_manager.redo)
        self.redo_btn.setEnabled(False)
        layout.addWidget(self.redo_btn)

        layout.addSpacing(10)

        # Separator
        line2 = QWidget()
        line2.setFixedWidth(2)
        line2.setStyleSheet("background-color: #ccc;")
        layout.addWidget(line2)
        layout.addSpacing(10)

        # Demo button
        demo_btn = QPushButton("加载示例")
        demo_icon = get_icon("file_text", color="#333333")
        if demo_icon:
            demo_btn.setIcon(demo_icon)
        demo_btn.clicked.connect(self.file_manager.load_demo)
        demo_btn.setStyleSheet("background-color: #f0f0f0; color: #333;")
        layout.addWidget(demo_btn)

        layout.addSpacing(20)

        # Theme selection
        layout.addWidget(QLabel("主题:"))
        self.theme_combo = QComboBox()
        theme_icon = get_icon("palette", color="#333333")
        if theme_icon:
            self.theme_combo.addItem(theme_icon, "", None)
            self.theme_combo.removeItem(0)
        for theme in get_preset_themes():
            self.theme_combo.addItem(theme.name, theme.id)
        self.theme_combo.currentIndexChanged.connect(self.theme_manager.on_theme_changed)
        layout.addWidget(self.theme_combo)

        layout.addStretch()

        # Export
        export_btn = QPushButton("导出 PPT")
        export_icon = get_icon("download", color="#ffffff")
        if export_icon:
            export_btn.setIcon(export_icon)
        export_btn.clicked.connect(self.file_manager.export_ppt)
        export_btn.setStyleSheet("background-color: #1e40af; color: white; padding: 8px 16px; font-weight: bold;")
        layout.addWidget(export_btn)

        return layout

    # ------------------------------------------------------------------
    # Signal handlers (UI coordination)
    # ------------------------------------------------------------------

    def _on_request_add_slide(self, new_slide: Slide) -> None:
        """Handle add slide request"""
        self.command_manager.add_slide(self.presentation, new_slide)

    def _on_request_remove_slide(self, index: int) -> None:
        """Handle remove slide request"""
        self.command_manager.remove_slide(self.presentation, index)

    def _on_request_copy_slide(self, index: int) -> None:
        """Handle copy slide request"""
        self.command_manager.copy_slide(self.presentation, index)

    def _on_request_edit(self, old_content: SlideContent, new_content: SlideContent) -> None:
        """Handle edit request"""
        if not self.editor.slide:
            return
        self.command_manager.edit_slide(self.editor.slide, old_content, new_content)

    def _on_request_layout_change(self, old_layout, new_layout) -> None:
        """Handle layout change request"""
        if not self.editor.slide:
            return
        self.command_manager.change_layout(self.editor.slide, old_layout, new_layout)

    def _on_editor_content_changed(self) -> None:
        """Handle editor content change"""
        self.preview_panel.refresh()
        self.autosave_manager.mark_dirty()
        if self.editor.slide:
            self.preview_cache.invalidate(self.editor.slide)

    def _on_slide_selected(self, slide_id: str) -> None:
        """Handle slide selection from list"""
        if not self.presentation:
            return

        for i, slide in enumerate(self.presentation.slides):
            if slide.id == slide_id:
                self.editor.set_slide(slide)
                self.preview_controller.set_current_slide_index(i)
                return
        self.editor.set_slide(None)

    def _on_preview_slide_changed(self, index: int) -> None:
        """Handle slide selection from preview"""
        if not self.presentation or index < 0 or index >= len(self.presentation.slides):
            return

        slide = self.presentation.slides[index]
        self.editor.set_slide(slide)
        self.slide_list.set_current_index(index)

    def _on_title_changed(self, text: str) -> None:
        """Handle title change"""
        if self.presentation:
            self.presentation.title = text

    # ------------------------------------------------------------------
    # UI refresh
    # ------------------------------------------------------------------

    def _refresh_ui(self) -> None:
        """Refresh all UI components"""
        if not self.presentation:
            return

        self.undo_btn.setEnabled(self.command_manager.can_undo())
        self.redo_btn.setEnabled(self.command_manager.can_redo())

        self.presentation_title_edit.blockSignals(True)
        self.presentation_title_edit.setText(self.presentation.title)
        self.presentation_title_edit.blockSignals(False)

        theme_index = self.theme_combo.findData(self.presentation.theme_id)
        if theme_index >= 0:
            self.theme_combo.setCurrentIndex(theme_index)

        self.slide_list.set_presentation(self.presentation)

        if self.presentation.slides:
            self.slide_list.list_widget.setCurrentRow(0)

        self.preview_panel.set_presentation(self.presentation)

    def closeEvent(self, event) -> None:
        """Handle window close event"""
        if self.change_tracker:
            self.change_tracker.track_changes()
            if self.change_tracker.has_changes():
                reply = QMessageBox.question(
                    self,
                    "保存更改",
                    "您有未保存的更改，是否保存？",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No | QMessageBox.StandardButton.Cancel,
                )
                if reply == QMessageBox.StandardButton.Yes:
                    self.file_manager.save_presentation()
                elif reply == QMessageBox.StandardButton.Cancel:
                    event.ignore()
                    return

        event.accept()


def main() -> None:
    """Run entry point for the command-line interface.
    
        Command-line interface for widgets
    
        Examples:
        main_window [options] <arguments>
        """

    app = QApplication(sys.argv)
    app.setStyle("Fusion")

    window = PPTMakerWindow()
    window.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()