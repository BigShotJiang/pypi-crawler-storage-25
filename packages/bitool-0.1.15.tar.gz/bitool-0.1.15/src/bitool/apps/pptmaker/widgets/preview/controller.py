"""
Preview Controller - Coordinates between model and view
"""

from __future__ import annotations

from bitool.gui.compat import QObject, Signal

from ...models.models import Presentation
from .model import PreviewModel


class PreviewController(QObject):
    """
    Preview Controller - handles business logic for preview
    """

    slide_index_changed = Signal(int)

    def __init__(self, model: PreviewModel) -> None:
        super().__init__()
        self._model = model
        self._connect_signals()

    def _connect_signals(self) -> None:
        """Connect model signals"""
        self._model.slide_index_changed.connect(self._on_model_slide_index_changed)

    def _on_model_slide_index_changed(self, index: int) -> None:
        """Forward slide index change signal"""
        self.slide_index_changed.emit(index)

    def set_presentation(self, presentation: Presentation | None) -> None:
        """Set the presentation to preview"""
        self._model.presentation = presentation

    def set_current_slide_index(self, index: int) -> None:
        """Set the current slide index"""
        self._model.current_slide_index = index

    def set_thumbnail_size(self, index: int) -> None:
        """Set thumbnail size index"""
        self._model.thumbnail_size_index = index

    def set_view_mode(self, mode: str) -> None:
        """Set view mode (horizontal, vertical, grid)"""
        self._model.view_mode = mode

    def next_slide(self) -> None:
        """Go to next slide"""
        self._model.next_slide()

    def previous_slide(self) -> None:
        """Go to previous slide"""
        self._model.previous_slide()

    def refresh(self) -> None:
        """Refresh preview"""
        self._model.refresh_data()

    @property
    def model(self) -> PreviewModel:
        return self._model
