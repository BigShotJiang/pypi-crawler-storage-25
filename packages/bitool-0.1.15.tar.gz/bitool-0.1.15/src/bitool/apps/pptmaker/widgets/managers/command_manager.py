"""
命令管理器

负责撤销/重做、命令栈管理以及幻灯片操作命令的执行。
"""

from __future__ import annotations

import copy
import uuid
from typing import TYPE_CHECKING

from ...command_stack import (
    AddSlideCommand,
    ChangeLayoutCommand,
    CommandStack,
    CopySlideCommand,
    EditSlideCommand,
    RemoveSlideCommand,
)
from ...models import LayoutType, Slide, SlideContent

if TYPE_CHECKING:
    from ...models import Presentation
    from ..main_window import PPTMakerWindow


class CommandManager:
    """命令栈管理器

    持有 CommandStack 实例，负责执行撤销/重做操作，
    以及将幻灯片增删改操作封装为命令并入栈。
    """

    def __init__(self, window: PPTMakerWindow, max_history: int = 200) -> None:
        self._window = window
        self._stack = CommandStack(max_history=max_history)

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def stack(self) -> CommandStack:
        """获取底层命令栈"""
        return self._stack

    def can_undo(self) -> bool:
        return self._stack.can_undo()

    def can_redo(self) -> bool:
        return self._stack.can_redo()

    # ------------------------------------------------------------------
    # Undo / Redo
    # ------------------------------------------------------------------

    def undo(self) -> None:
        """执行撤销"""
        if not self._stack.can_undo():
            return
        w = self._window
        if w.editor.slide is not None and w.editor.saved_content is not None:
            w.editor._commit_edit()

        self._stack.undo()
        self._update_after_change()

    def redo(self) -> None:
        """执行重做"""
        if not self._stack.can_redo():
            return
        w = self._window
        if w.editor.slide is not None and w.editor.saved_content is not None:
            w.editor._commit_edit()

        self._stack.redo()
        self._update_after_change()

    def clear(self) -> None:
        """清空命令栈"""
        self._stack.clear()

    # ------------------------------------------------------------------
    # Slide operations (push commands)
    # ------------------------------------------------------------------

    def add_slide(self, presentation: Presentation, new_slide: Slide) -> None:
        """添加幻灯片命令"""
        w = self._window
        if w.editor.slide is not None and w.editor.saved_content is not None:
            w.editor._commit_edit()

        command = AddSlideCommand(presentation, new_slide)
        self._stack.push(command)
        self._update_after_change()
        w.slide_list.list_widget.setCurrentRow(len(presentation.slides) - 1)

    def remove_slide(self, presentation: Presentation, index: int) -> None:
        """删除幻灯片命令"""
        w = self._window
        if w.editor.slide is not None and w.editor.saved_content is not None:
            w.editor._commit_edit()

        command = RemoveSlideCommand(presentation, index)
        self._stack.push(command)
        self._update_after_change()

    def copy_slide(self, presentation: Presentation, index: int) -> None:
        """复制幻灯片命令"""
        if not presentation or index < 0 or index >= len(presentation.slides):
            return

        w = self._window
        if w.editor.slide is not None and w.editor.saved_content is not None:
            w.editor._commit_edit()

        original_slide = presentation.slides[index]
        new_content = SlideContent(
            title=original_slide.content.title,
            subtitle=original_slide.content.subtitle,
            body=original_slide.content.body,
            bullets=copy.deepcopy(original_slide.content.bullets),
            icon=original_slide.content.icon,
        )
        new_slide_id = str(uuid.uuid4())
        new_slide = Slide(
            id=new_slide_id,
            order=index + 1,
            layout_type=original_slide.layout_type,
            content=new_content,
        )

        command = CopySlideCommand(presentation, index, new_slide)
        self._stack.push(command)
        self._update_after_change()
        w.slide_list.list_widget.setCurrentRow(index + 1)

    def edit_slide(self, slide: Slide, old_content: SlideContent, new_content: SlideContent) -> None:
        """编辑幻灯片内容命令"""
        command = EditSlideCommand(slide, old_content, new_content)
        self._stack.push(command)
        self._update_buttons()

    def change_layout(self, slide: Slide, old_layout: LayoutType, new_layout: LayoutType) -> None:
        """更改幻灯片布局命令"""
        command = ChangeLayoutCommand(slide, old_layout, new_layout)
        self._stack.push(command)
        self._update_buttons()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _update_after_change(self) -> None:
        """命令执行后更新 UI"""
        self._update_buttons()
        self._window._refresh_ui()

    def _update_buttons(self) -> None:
        """更新撤销/重做按钮状态"""
        self._window.undo_btn.setEnabled(self._stack.can_undo())
        self._window.redo_btn.setEnabled(self._stack.can_redo())
