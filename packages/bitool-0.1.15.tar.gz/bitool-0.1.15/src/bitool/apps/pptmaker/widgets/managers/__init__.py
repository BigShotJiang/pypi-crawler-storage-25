"""
PPT Maker Manager Classes

将主窗口的各项职责拆分为独立的管理器类：
- FileManager: 文件打开/保存/导出操作
- CommandManager: 撤销/重做、命令栈管理
- AutoSaveManager: 自动保存定时器和逻辑
- ThemeManager: 主题切换和预览
"""

from .autosave_manager import AutoSaveManager
from .command_manager import CommandManager
from .file_manager import FileManager
from .theme_manager import ThemeManager

__all__ = [
    "AutoSaveManager",
    "CommandManager",
    "FileManager",
    "ThemeManager",
]
