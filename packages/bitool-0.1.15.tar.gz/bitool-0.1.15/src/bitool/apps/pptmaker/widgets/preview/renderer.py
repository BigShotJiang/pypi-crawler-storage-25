"""
Slide Renderer - Unified rendering engine for slide previews
"""

from __future__ import annotations

from bitool.gui.compat import (
    QColor,
    QFont,
    QFrame,
    QPainter,
    QPaintEvent,
    QPixmap,
    QRectF,
    QResizeEvent,
    QSize,
    Qt,
    QWidget,
)

from ...models.models import LayoutType, Slide, SlideContent, Theme
from .cache import get_preview_cache


class SlideRenderer:
    """
    Unified slide renderer - handles all slide drawing logic
    Uses base coordinate system (960x540) for consistent rendering
    """

    BASE_WIDTH = 960
    BASE_HEIGHT = 540

    @classmethod
    def draw_slide(
        cls,
        painter: QPainter,
        slide: Slide,
        theme: Theme,
        scale: float = 1.0,
        offset_x: float = 0.0,
        offset_y: float = 0.0,
    ) -> None:
        """
        Draw a slide using the base coordinate system
        """
        painter.save()
        painter.translate(offset_x, offset_y)
        painter.scale(scale, scale)

        # Draw background and header
        cls._draw_background(painter, theme)
        cls._draw_header(painter, theme)

        # Draw content based on layout
        content = slide.content
        layout_type = slide.layout_type

        if layout_type == LayoutType.BIG_TITLE:
            cls._draw_big_title(painter, content, theme)
        elif layout_type == LayoutType.TITLE_ONLY:
            cls._draw_title_only(painter, content, theme)
        elif layout_type == LayoutType.TITLE_CONTENT:
            cls._draw_title_content(painter, content, theme)
        elif layout_type == LayoutType.TITLE_BULLETS:
            cls._draw_title_bullets(painter, content, theme)
        elif layout_type == LayoutType.TITLE_CONTENT_ICON:
            cls._draw_title_content_icon(painter, content, theme)
        elif layout_type == LayoutType.TWO_COLUMNS:
            cls._draw_two_columns(painter, content, theme)
        else:
            cls._draw_title_content(painter, content, theme)

        painter.restore()

    @classmethod
    def _draw_background(cls, painter: QPainter, theme: Theme) -> None:
        """Draw slide background"""
        bg_color = QColor(theme.colors.background)
        rect = QRectF(0, 0, cls.BASE_WIDTH, cls.BASE_HEIGHT)
        painter.fillRect(rect, bg_color)

    @classmethod
    def _draw_header(cls, painter: QPainter, theme: Theme) -> None:
        """Draw header decoration"""
        primary_color = QColor(theme.colors.primary)
        painter.fillRect(0, 0, cls.BASE_WIDTH, 15, primary_color)

    @classmethod
    def _draw_big_title(cls, painter: QPainter, content: SlideContent, theme: Theme) -> None:
        """Draw big title layout"""
        rect = QRectF(0, 0, cls.BASE_WIDTH, cls.BASE_HEIGHT)
        text_color = QColor(theme.colors.text)
        text_light_color = QColor(theme.colors.text_light)

        font = QFont(theme.fonts.heading, 36)
        painter.setFont(font)
        painter.setPen(text_color)
        painter.drawText(rect, Qt.AlignCenter, content.title)

        if content.subtitle:
            font = QFont(theme.fonts.body, 20)
            painter.setFont(font)
            painter.setPen(text_light_color)
            subtitle_rect = rect.adjusted(0, 80, 0, 0)
            painter.drawText(subtitle_rect, Qt.AlignCenter, content.subtitle)

    @classmethod
    def _draw_title_only(cls, painter: QPainter, content: SlideContent, theme: Theme) -> None:
        """Draw title only layout"""
        rect = QRectF(0, 0, cls.BASE_WIDTH, cls.BASE_HEIGHT)
        primary_color = QColor(theme.colors.primary)

        font = QFont(theme.fonts.heading, 42)
        painter.setFont(font)
        painter.setPen(primary_color)
        painter.drawText(rect, Qt.AlignCenter, content.title)

    @classmethod
    def _draw_title_content(cls, painter: QPainter, content: SlideContent, theme: Theme) -> None:
        """Draw title + content layout"""
        primary_color = QColor(theme.colors.primary)
        text_color = QColor(theme.colors.text)

        # Title
        font = QFont(theme.fonts.heading, 32)
        painter.setFont(font)
        painter.setPen(primary_color)
        title_rect = QRectF(20, 30, cls.BASE_WIDTH - 40, 60)
        painter.drawText(title_rect, Qt.AlignLeft | Qt.TextWordWrap, content.title)

        # Content
        if content.body:
            font = QFont(theme.fonts.body, 18)
            painter.setFont(font)
            painter.setPen(text_color)
            content_rect = QRectF(20, 100, cls.BASE_WIDTH - 40, cls.BASE_HEIGHT - 120)
            painter.drawText(content_rect, Qt.AlignLeft | Qt.TextWordWrap, content.body)

    @classmethod
    def _draw_title_bullets(cls, painter: QPainter, content: SlideContent, theme: Theme) -> None:
        """Draw title + bullets layout"""
        primary_color = QColor(theme.colors.primary)
        text_color = QColor(theme.colors.text)

        # Title
        font = QFont(theme.fonts.heading, 32)
        painter.setFont(font)
        painter.setPen(primary_color)
        title_rect = QRectF(20, 30, cls.BASE_WIDTH - 40, 60)
        painter.drawText(title_rect, Qt.AlignLeft, content.title)

        # Bullets
        if content.bullets:
            font = QFont(theme.fonts.body, 16)
            painter.setFont(font)
            painter.setPen(text_color)
            y_offset = 100
            max_bullets = min(5, len(content.bullets))
            for i in range(max_bullets):
                bullet = content.bullets[i]
                bullet_text = f"• {bullet}"
                bullet_rect = QRectF(20, y_offset, cls.BASE_WIDTH - 40, 30)
                painter.drawText(bullet_rect, Qt.AlignLeft | Qt.TextWordWrap, bullet_text)
                y_offset += 35

    @classmethod
    def _draw_title_content_icon(cls, painter: QPainter, content: SlideContent, theme: Theme) -> None:
        """Draw title + content + icon layout"""
        primary_color = QColor(theme.colors.primary)
        text_color = QColor(theme.colors.text)

        # Title
        font = QFont(theme.fonts.heading, 32)
        painter.setFont(font)
        painter.setPen(primary_color)
        title_rect = QRectF(20, 30, cls.BASE_WIDTH - 40, 60)
        painter.drawText(title_rect, Qt.AlignLeft, content.title)

        # Content
        if content.body:
            font = QFont(theme.fonts.body, 18)
            painter.setFont(font)
            painter.setPen(text_color)
            content_rect = QRectF(20, 100, cls.BASE_WIDTH - 200, cls.BASE_HEIGHT - 120)
            painter.drawText(content_rect, Qt.AlignLeft | Qt.TextWordWrap, content.body)

        # Icon placeholder
        if content.icon:
            icon_rect = QRectF(cls.BASE_WIDTH - 150, 100, 130, cls.BASE_HEIGHT - 180)
            painter.setPen(text_color)
            painter.drawText(icon_rect, Qt.AlignCenter, "★")

    @classmethod
    def _draw_two_columns(cls, painter: QPainter, content: SlideContent, theme: Theme) -> None:
        """Draw two columns layout"""
        primary_color = QColor(theme.colors.primary)
        text_color = QColor(theme.colors.text)

        # Title
        font = QFont(theme.fonts.heading, 32)
        painter.setFont(font)
        painter.setPen(primary_color)
        title_rect = QRectF(20, 20, cls.BASE_WIDTH - 40, 50)
        painter.drawText(title_rect, Qt.AlignLeft, content.title)

        # Left column
        if content.body:
            font = QFont(theme.fonts.body, 16)
            painter.setFont(font)
            painter.setPen(text_color)
            left_rect = QRectF(20, 80, (cls.BASE_WIDTH / 2) - 30, cls.BASE_HEIGHT - 100)
            painter.drawText(left_rect, Qt.AlignLeft | Qt.TextWordWrap, content.body)

        # Right column
        if content.bullets:
            font = QFont(theme.fonts.body, 15)
            painter.setFont(font)
            painter.setPen(text_color)
            y_offset = 80
            line_height = 30
            max_bullets = min(4, len(content.bullets))
            for i in range(max_bullets):
                bullet = content.bullets[i]
                bullet_text = f"• {bullet}"
                bullet_rect = QRectF(cls.BASE_WIDTH / 2, y_offset, (cls.BASE_WIDTH / 2) - 20, 30)
                painter.drawText(bullet_rect, Qt.AlignLeft | Qt.TextWordWrap, bullet_text)
                y_offset += line_height

    @classmethod
    def render_to_pixmap(cls, slide: Slide, theme: Theme, size: QSize) -> QPixmap:
        """
        Render slide to QPixmap with caching support

        Args:
            slide: 幻灯片
            theme: 主题
            size: 输出尺寸

        Returns:
            渲染后的QPixmap
        """
        cache = get_preview_cache()

        # 尝试从缓存获取
        cached_pixmap = cache.get(slide, theme, size)
        if cached_pixmap:
            return cached_pixmap

        # 如果缓存未命中，进行渲染
        pixmap = QPixmap(size)
        pixmap.fill(QColor(theme.colors.background))

        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setRenderHint(QPainter.TextAntialiasing)

        scale_x = size.width() / cls.BASE_WIDTH
        scale_y = size.height() / cls.BASE_HEIGHT
        scale = min(scale_x, scale_y)

        painter.scale(scale, scale)
        offset_x = (size.width() / scale - cls.BASE_WIDTH) / 2
        offset_y = (size.height() / scale - cls.BASE_HEIGHT) / 2

        cls.draw_slide(painter, slide, theme, scale=1.0, offset_x=offset_x, offset_y=offset_y)
        painter.end()

        # 保存到缓存
        cache.set(slide, theme, size, pixmap)

        return pixmap


class SlidePreviewWidget(QFrame):
    """
    Reusable slide preview widget with auto-scaling
    """

    def __init__(
        self,
        slide: Slide | None = None,
        theme: Theme | None = None,
        scale: float = 0.3,
        parent: QWidget | None = None,
        *,
        use_auto_scale: bool = False,
    ) -> None:
        super().__init__(parent)
        self.slide = slide
        self.theme = theme
        self.scale = scale
        self.use_auto_scale = use_auto_scale
        self._setup_ui()

    def _setup_ui(self) -> None:
        """Setup UI"""
        self.setMinimumSize(QSize(100, 75))
        self.setFrameStyle(QFrame.Box | QFrame.Sunken)
        self.setAutoFillBackground(True)

    def set_slide(self, slide: Slide, theme: Theme) -> None:
        """Set slide to preview"""
        self.slide = slide
        self.theme = theme
        self.update()

    def set_scale(self, scale: float) -> None:
        """Set fixed scale"""
        self.scale = scale
        self.update()

    def resizeEvent(self, event: QResizeEvent) -> None:
        """Handle resize"""
        super().resizeEvent(event)
        self.update()

    def _get_auto_scale(self) -> float:
        """Calculate auto scale based on widget size"""
        current_width = float(max(1, self.width()))
        current_height = float(max(1, self.height()))

        scale_x = current_width / SlideRenderer.BASE_WIDTH
        scale_y = current_height / SlideRenderer.BASE_HEIGHT

        final_scale = min(scale_x, scale_y) * 0.9
        return max(min(final_scale, 2.0), 0.05)

    def paintEvent(self, event: QPaintEvent) -> None:
        """Paint the slide preview with caching support"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setRenderHint(QPainter.TextAntialiasing)

        # Draw background
        bg_color = QColor(self.theme.colors.background) if self.theme else QColor(240, 240, 240)
        painter.fillRect(self.rect(), bg_color)

        # No theme or slide - show placeholder
        if not self.theme or not self.slide:
            if not self.theme:
                painter.setPen(QColor(128, 128, 128))
                font_size = max(10, int(self.width() * 0.03))
                font = QFont("Arial", font_size)
                painter.setFont(font)
                painter.drawText(self.rect(), Qt.AlignCenter, "暂无预览内容")
            return

        # Use cache for rendering
        widget_size = QSize(self.width(), self.height())
        pixmap = SlideRenderer.render_to_pixmap(self.slide, self.theme, widget_size)

        # Draw the cached pixmap
        painter.drawPixmap(0, 0, pixmap)
