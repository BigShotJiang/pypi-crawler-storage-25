"""
主题管理器

负责主题切换和预览更新。
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..main_window import PPTMakerWindow


class ThemeManager:
    """主题管理器

    管理演示文稿主题选择与切换，更新主题后刷新预览面板。
    """

    def __init__(self, window: PPTMakerWindow) -> None:
        self._window = window

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def on_theme_changed(self, index: int) -> None:
        """处理主题切换事件

        Args:
            index: 主题下拉框当前索引
        """
        w = self._window
        if w.presentation:
            w.presentation.theme_id = w.theme_combo.itemData(index)
            w.preview_panel.refresh()
