"""
Preview Cache - 预览缓存机制
提供渲染结果缓存，避免重复绘制，提升性能
"""

from __future__ import annotations

import hashlib

from bitool.gui.compat import QPixmap, QSize

from ...models.models import Slide, Theme


class PreviewCache:
    """
    预览缓存管理器
    使用幻灯片内容的哈希值作为缓存键，缓存渲染结果
    """

    def __init__(self, max_cache_size: int = 50) -> None:
        """
        初始化缓存管理器

        Args:
            max_cache_size: 最大缓存条目数，超过后自动清理最旧的缓存
        """
        self._cache: dict[str, QPixmap] = {}
        self._cache_keys: list[str] = []  # 保持插入顺序，用于LRU清理
        self._max_cache_size = max_cache_size

    def _generate_cache_key(self, slide: Slide, theme: Theme, size: QSize) -> str:
        """
        生成缓存键

        Args:
            slide: 幻灯片
            theme: 主题
            size: 渲染尺寸

        Returns:
            唯一的缓存键
        """
        # 创建内容哈希
        content_str = (
            f"{slide.id}"
            f"{slide.content.title}"
            f"{slide.content.subtitle}"
            f"{slide.content.body}"
            f"{','.join(slide.content.bullets)}"
            f"{slide.content.icon or ''}"
            f"{slide.layout_type.value}"
            f"{theme.id}"
            f"{size.width()}x{size.height()}"
        )
        return hashlib.sha256(content_str.encode()).hexdigest()

    def get(self, slide: Slide, theme: Theme, size: QSize) -> QPixmap | None:
        """
        获取缓存的渲染结果

        Args:
            slide: 幻灯片
            theme: 主题
            size: 渲染尺寸

        Returns:
            缓存的QPixmap，如果未命中返回None
        """
        cache_key = self._generate_cache_key(slide, theme, size)
        if cache_key in self._cache:
            # 更新访问顺序（LRU）
            self._cache_keys.remove(cache_key)
            self._cache_keys.append(cache_key)
            return self._cache[cache_key]
        return None

    def set(self, slide: Slide, theme: Theme, size: QSize, pixmap: QPixmap) -> None:
        """
        设置缓存的渲染结果

        Args:
            slide: 幻灯片
            theme: 主题
            size: 渲染尺寸
            pixmap: 渲染结果
        """
        cache_key = self._generate_cache_key(slide, theme, size)

        # 如果已存在，先移除旧的
        if cache_key in self._cache:
            self._cache_keys.remove(cache_key)

        # 添加新缓存
        self._cache[cache_key] = pixmap
        self._cache_keys.append(cache_key)

        # 如果超过最大缓存大小，清理最旧的
        while len(self._cache) > self._max_cache_size:
            oldest_key = self._cache_keys.pop(0)
            del self._cache[oldest_key]

    def invalidate(self, slide: Slide) -> None:
        """
        使指定幻灯片的缓存失效

        Args:
            slide: 要失效的幻灯片
        """
        # 查找并删除所有与该幻灯片相关的缓存
        keys_to_remove = [key for key in self._cache_keys if slide.id in key]

        for key in keys_to_remove:
            self._cache_keys.remove(key)
            del self._cache[key]

    def invalidate_all(self) -> None:
        """
        使所有缓存失效
        """
        self._cache.clear()
        self._cache_keys.clear()

    def get_cache_stats(self) -> dict:
        """
        获取缓存统计信息

        Returns:
            统计字典，包含缓存大小和最大大小
        """
        return {
            "current_size": len(self._cache),
            "max_size": self._max_cache_size,
            "hit_rate": self._calculate_hit_rate(),
        }

    def _calculate_hit_rate(self) -> float:
        """
        计算缓存命中率（简化版本）

        Returns:
            命中率百分比
        """
        # 简化实现：返回缓存使用率
        return (len(self._cache) / self._max_cache_size) * 100


# 全局缓存实例
_global_cache = PreviewCache(max_cache_size=100)


def get_preview_cache() -> PreviewCache:
    """
    获取全局预览缓存实例

    Returns:
        预览缓存实例
    """
    return _global_cache
