"""
PPT生成引擎
使用python-pptx库生成PowerPoint演示文稿
"""

from __future__ import annotations

from pathlib import Path

from pptx import Presentation as PPTPresentation
from pptx.dml.color import RGBColor
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

from bitool.core import logger

from .models.models import LayoutType, Presentation, Slide
from .models.presets import get_theme_by_id

# 常用中文字体列表，按优先级
CHINESE_FONTS = [
    "微软雅黑",
    "Microsoft YaHei",
    "微软雅黑 Light",
    "SimHei",
    "黑体",
    "KaiTi",
    "楷体",
    "SimSun",
    "宋体",
    "Arial",
    "sans-serif",
]


class PPTGenerator:
    """PPT生成器"""

    def __init__(self, presentation: Presentation, show_header=True, show_footer=False) -> None:
        self.presentation = presentation
        self.theme = get_theme_by_id(presentation.theme_id)
        self.prs = PPTPresentation()
        self.show_header = show_header
        self.show_footer = show_footer
        # 设置默认页面尺寸为宽屏
        self.prs.slide_width = Inches(10)
        self.prs.slide_height = Inches(7.5)

    def _get_best_chinese_font(self, preferred_font: str) -> str:
        """获取可用的最佳中文字体"""
        if preferred_font and preferred_font in CHINESE_FONTS:
            return preferred_font
        for font in CHINESE_FONTS:
            return font
        return "Arial"

    def _hex_to_rgb(self, hex_color: str) -> RGBColor:
        """将十六进制颜色转换为RGBColor"""
        hex_color = hex_color.lstrip("#")
        return RGBColor(int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16))

    def _set_font_characteristics(self, paragraph, font_name, font_size, color_rgb, bold=False, italic=False) -> None:
        """统一设置字体样式"""
        run = paragraph.add_run() if not paragraph.runs else paragraph.runs[0]
        # 设置字体
        run.font.name = font_name

        # 最稳健的方法：不尝试设置中文字体 XML 属性
        # 因为不同版本的 python-pptx 库 API 可能有所不同
        # 简单地设置 font.name 通常就足够了

        # 设置其他字体属性
        run.font.size = font_size
        run.font.color.rgb = color_rgb
        run.font.bold = bold
        run.font.italic = italic

    def _apply_theme_to_slide(self, slide) -> None:
        """应用主题到幻灯片"""
        # 设置背景颜色
        background = slide.background
        fill = background.fill
        fill.solid()
        fill.fore_color.rgb = self._hex_to_rgb(self.theme.colors.background)

        # 添加主题风格的装饰条（页眉）
        if self.show_header:
            self._add_decorative_header(slide)

    def _add_decorative_header(self, slide) -> None:
        """添加主题装饰页眉"""
        # 添加顶部装饰条
        header_shape = slide.shapes.add_shape(
            1,  # 矩形
            Inches(0),
            Inches(0),
            Inches(10),
            Inches(0.3),
        )
        header_fill = header_shape.fill
        header_fill.solid()
        header_fill.fore_color.rgb = self._hex_to_rgb(self.theme.colors.primary)
        header_shape.line.fill.background()  # 透明边框

    def _add_footer(self, slide) -> None:
        """添加页脚"""
        footer_box = slide.shapes.add_textbox(Inches(1.0), Inches(7.2), Inches(8.5), Inches(0.3))
        footer_frame = footer_box.text_frame
        footer_frame.text = self.presentation.title
        footer_paragraph = footer_frame.paragraphs[0]
        footer_paragraph.font.size = Pt(10)
        footer_paragraph.font.color.rgb = self._hex_to_rgb(self.theme.colors.text_light)
        footer_paragraph.alignment = PP_ALIGN.CENTER

    def _add_title(self, slide, text: str, top: float = 1.0, height: float = 1.5, font_size: int = 36) -> None:
        """添加标题"""
        title_shape = slide.shapes.title
        if not title_shape:
            title_shape = slide.shapes.add_textbox(Inches(1.0), Inches(top), Inches(8.5), Inches(height))

        title_text_frame = title_shape.text_frame
        # 清空默认文本并添加新内容
        title_text_frame.clear()
        title_text_frame.word_wrap = True
        title_paragraph = title_text_frame.paragraphs[0]
        title_paragraph.text = text

        # 设置标题样式
        title_font = self._get_best_chinese_font(self.theme.fonts.heading)
        self._set_font_characteristics(
            title_paragraph, title_font, Pt(font_size), self._hex_to_rgb(self.theme.colors.primary), bold=True,
        )
        title_paragraph.alignment = PP_ALIGN.CENTER
        title_text_frame.vertical_anchor = MSO_ANCHOR.MIDDLE

    def _add_subtitle(self, slide, text: str, top: float = 5.5, height: float = 1.0) -> None:
        """添加副标题"""
        subtitle_box = slide.shapes.add_textbox(Inches(1.0), Inches(top), Inches(8.5), Inches(height))
        subtitle_frame = subtitle_box.text_frame
        subtitle_frame.text = text
        subtitle_frame.word_wrap = True
        subtitle_paragraph = subtitle_frame.paragraphs[0]
        subtitle_font = self._get_best_chinese_font(self.theme.fonts.body)
        self._set_font_characteristics(
            subtitle_paragraph, subtitle_font, Pt(24), self._hex_to_rgb(self.theme.colors.text_light),
        )
        subtitle_paragraph.alignment = PP_ALIGN.CENTER
        subtitle_frame.vertical_anchor = MSO_ANCHOR.MIDDLE

    def _add_body_text(
        self,
        slide,
        text: str,
        left: float = 1.0,
        top: float = 2.5,
        width: float = 8.5,
        height: float = 4.0,
        font_size: int = 18,
    ) -> None:
        """添加正文文本"""
        left_inches = Inches(left)
        top_inches = Inches(top)
        width_inches = Inches(width)
        height_inches = Inches(height)

        text_box = slide.shapes.add_textbox(left_inches, top_inches, width_inches, height_inches)
        text_frame = text_box.text_frame
        text_frame.clear()
        text_frame.word_wrap = True
        text_frame.vertical_anchor = MSO_ANCHOR.TOP

        paragraph = text_frame.paragraphs[0]
        paragraph.text = text

        body_font = self._get_best_chinese_font(self.theme.fonts.body)
        self._set_font_characteristics(paragraph, body_font, Pt(font_size), self._hex_to_rgb(self.theme.colors.text))
        paragraph.space_before = Pt(6)
        paragraph.space_after = Pt(6)

    def _add_bullets(
        self,
        slide,
        bullets: list,
        left: float = 1.0,
        top: float = 2.5,
        width: float = 8.5,
        height: float = 4.0,
        font_size: int = 18,
    ) -> None:
        """添加要点列表"""
        left_inches = Inches(left)
        top_inches = Inches(top)
        width_inches = Inches(width)
        height_inches = Inches(height)

        text_box = slide.shapes.add_textbox(left_inches, top_inches, width_inches, height_inches)
        text_frame = text_box.text_frame
        text_frame.clear()
        text_frame.word_wrap = True
        text_frame.vertical_anchor = MSO_ANCHOR.TOP

        # 添加要点
        body_font = self._get_best_chinese_font(self.theme.fonts.body)
        for i, bullet in enumerate(bullets):
            p = text_frame.paragraphs[0] if i == 0 else text_frame.add_paragraph()

            p.text = bullet
            p.level = 0
            self._set_font_characteristics(p, body_font, Pt(font_size), self._hex_to_rgb(self.theme.colors.text))
            p.space_before = Pt(8)
            p.space_after = Pt(8)

    def _render_title_only(self, slide, content) -> None:
        """渲染仅标题布局"""
        self._apply_theme_to_slide(slide)
        self._add_title(slide, content.title, top=3.0, height=2.0, font_size=44)
        if self.show_footer:
            self._add_footer(slide)

    def _render_title_content(self, slide, content) -> None:
        """渲染标题+内容布局"""
        self._apply_theme_to_slide(slide)
        self._add_title(slide, content.title)

        if content.body:
            self._add_body_text(slide, content.body)

        if content.bullets:
            self._add_bullets(slide, content.bullets)

        if self.show_footer:
            self._add_footer(slide)

    def _render_title_content_icon(self, slide, content) -> None:
        """渲染标题+内容+图标布局"""
        self._apply_theme_to_slide(slide)
        self._add_title(slide, content.title)

        # 内容靠左，图标靠右
        if content.body:
            self._add_body_text(slide, content.body, left=1.0, top=2.5, width=5.5, height=4.0)

        # 添加图标占位符
        if content.icon:
            icon_box = slide.shapes.add_textbox(Inches(7.0), Inches(3.0), Inches(2.0), Inches(2.0))
            icon_text_frame = icon_box.text_frame
            icon_text_frame.text = "🖼️"
            icon_text_frame.paragraphs[0].font.size = Pt(48)
            icon_text_frame.paragraphs[0].alignment = PP_ALIGN.CENTER

        if self.show_footer:
            self._add_footer(slide)

    def _render_two_columns(self, slide, content) -> None:
        """渲染双列布局"""
        self._apply_theme_to_slide(slide)
        self._add_title(slide, content.title, top=0.5, height=1.2, font_size=32)

        # 左列
        if content.body:
            self._add_body_text(slide, content.body, left=0.75, top=2.0, width=4.0, height=5.0, font_size=16)

        # 右列（要点）
        if content.bullets:
            self._add_bullets(slide, content.bullets, left=5.25, top=2.0, width=4.0, height=5.0, font_size=16)

        if self.show_footer:
            self._add_footer(slide)

    def _render_big_title(self, slide, content) -> None:
        """渲染大标题布局"""
        self._apply_theme_to_slide(slide)
        self._add_title(slide, content.title, top=2.5, height=3.0, font_size=44)

        if content.subtitle:
            self._add_subtitle(slide, content.subtitle)

        if self.show_footer:
            self._add_footer(slide)

    def _render_title_bullets(self, slide, content) -> None:
        """渲染标题+要点布局"""
        self._apply_theme_to_slide(slide)
        self._add_title(slide, content.title)
        self._add_bullets(slide, content.bullets)

        if self.show_footer:
            self._add_footer(slide)

    def _render_title_image(self, slide, content) -> None:
        """渲染标题+图片布局"""
        self._apply_theme_to_slide(slide)
        self._add_title(slide, content.title, top=0.5, height=1.2, font_size=32)

        # 图片占位符
        img_box = slide.shapes.add_textbox(Inches(1.0), Inches(2.0), Inches(8.5), Inches(5.0))
        img_frame = img_box.text_frame
        img_frame.text = "图片区域"
        img_frame.paragraphs[0].font.size = Pt(24)
        img_frame.paragraphs[0].alignment = PP_ALIGN.CENTER
        img_frame.vertical_anchor = MSO_ANCHOR.MIDDLE

        if self.show_footer:
            self._add_footer(slide)

    def _render_comparison(self, slide, content) -> None:
        """渲染对比布局"""
        self._apply_theme_to_slide(slide)
        self._add_title(slide, content.title, top=0.5, height=1.2, font_size=32)

        # 左侧
        left_box = slide.shapes.add_textbox(Inches(0.75), Inches(2.0), Inches(4.0), Inches(0.8))
        left_frame = left_box.text_frame
        left_frame.text = "项目A"
        left_paragraph = left_frame.paragraphs[0]
        left_font = self._get_best_chinese_font(self.theme.fonts.heading)
        self._set_font_characteristics(
            left_paragraph, left_font, Pt(24), self._hex_to_rgb(self.theme.colors.primary), bold=True,
        )
        left_paragraph.alignment = PP_ALIGN.CENTER

        # 右侧
        right_box = slide.shapes.add_textbox(Inches(5.25), Inches(2.0), Inches(4.0), Inches(0.8))
        right_frame = right_box.text_frame
        right_frame.text = "项目B"
        right_paragraph = right_frame.paragraphs[0]
        self._set_font_characteristics(
            right_paragraph, left_font, Pt(24), self._hex_to_rgb(self.theme.colors.accent), bold=True,
        )
        right_paragraph.alignment = PP_ALIGN.CENTER

        if self.show_footer:
            self._add_footer(slide)

    def _render_slide(self, slide: Slide) -> None:
        """渲染单个幻灯片"""
        # 创建空白布局
        blank_slide_layout = self.prs.slide_layouts[6]
        ppt_slide = self.prs.slides.add_slide(blank_slide_layout)

        # 根据布局类型渲染
        layout_renderers = {
            LayoutType.TITLE_ONLY: self._render_title_only,
            LayoutType.TITLE_CONTENT: self._render_title_content,
            LayoutType.TITLE_CONTENT_ICON: self._render_title_content_icon,
            LayoutType.TWO_COLUMNS: self._render_two_columns,
            LayoutType.BIG_TITLE: self._render_big_title,
            LayoutType.TITLE_BULLETS: self._render_title_bullets,
            LayoutType.TITLE_IMAGE: self._render_title_image,
            LayoutType.COMPARISON: self._render_comparison,
        }

        renderer = layout_renderers.get(slide.layout_type, self._render_title_content)
        renderer(ppt_slide, slide.content)

    def generate(self, output_path: Path) -> bool:
        """
        生成PPT文件

        Args:
            output_path: 输出文件路径

        Returns:
            是否成功
        """
        current_slide_id: str | None = None
        try:
            # 渲染所有幻灯片
            for slide in self.presentation.slides:
                current_slide_id = slide.id
                try:
                    self._render_slide(slide)
                except (ValueError, KeyError, AttributeError, TypeError) as exc:
                    logger.error(
                        "渲染幻灯片失败: slide_id=%s, order=%s, layout=%s, error=%s",
                        slide.id,
                        slide.order,
                        getattr(slide.layout_type, "value", slide.layout_type),
                        exc,
                        exc_info=True,
                    )
                    return False

            # 保存文件
            self.prs.save(str(output_path))
        except (OSError, PermissionError) as exc:
            logger.error(
                "保存PPT文件失败: path=%s, error=%s",
                output_path,
                exc,
                exc_info=True,
            )
            return False
        except (ValueError, KeyError, AttributeError, TypeError) as exc:
            logger.error(
                "生成PPT时发生数据异常: slide_id=%s, output=%s, error=%s",
                current_slide_id,
                output_path,
                exc,
                exc_info=True,
            )
            return False
        else:
            return True
