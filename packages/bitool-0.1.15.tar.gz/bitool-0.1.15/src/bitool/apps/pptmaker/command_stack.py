"""
命令栈 - 撤销/重做、批量操作、宏录制与持久化

提供：
- Command 基类与具体命令实现（添加/删除/复制/编辑/改变布局）
- CompositeCommand：将多个命令组合为一次原子操作
- CommandMacro：录制和回放命令序列
- CommandStack：支持撤销/重做、批量操作、宏录制和历史持久化的命令栈
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from bitool.core import logger

from .models.models import Presentation, Slide, SlideContent

# ---------------------------------------------------------------------------
# 命令基类
# ---------------------------------------------------------------------------


class Command(ABC):
    """命令基类"""

    @abstractmethod
    def execute(self) -> None:
        """执行命令"""
        pass

    @abstractmethod
    def undo(self) -> None:
        """撤销命令"""
        pass

    @abstractmethod
    def redo(self) -> None:
        """重做命令（默认是重新执行）"""
        pass


# ---------------------------------------------------------------------------
# 具体命令
# ---------------------------------------------------------------------------


class AddSlideCommand(Command):
    """添加幻灯片命令"""

    def __init__(self, presentation: Presentation, slide: Slide) -> None:
        self.presentation = presentation
        self.slide = slide
        self.inserted_index: int | None = None

    def execute(self) -> None:
        self.inserted_index = len(self.presentation.slides)
        self.presentation.slides.append(self.slide)
        # 重新排序
        for i, s in enumerate(self.presentation.slides):
            s.order = i

    def undo(self) -> None:
        if self.inserted_index is not None and 0 <= self.inserted_index < len(self.presentation.slides):
            self.presentation.slides.pop(self.inserted_index)
            # 重新排序
            for i, s in enumerate(self.presentation.slides):
                s.order = i

    def redo(self) -> None:
        self.execute()


class RemoveSlideCommand(Command):
    """删除幻灯片命令"""

    def __init__(self, presentation: Presentation, index: int) -> None:
        self.presentation = presentation
        self.index = index
        self.removed_slide: Slide | None = None

    def execute(self) -> None:
        if 0 <= self.index < len(self.presentation.slides):
            self.removed_slide = self.presentation.slides.pop(self.index)
            # 重新排序
            for i, s in enumerate(self.presentation.slides):
                s.order = i

    def undo(self) -> None:
        if self.removed_slide is not None:
            self.presentation.slides.insert(self.index, self.removed_slide)
            # 重新排序
            for i, s in enumerate(self.presentation.slides):
                s.order = i

    def redo(self) -> None:
        self.execute()


class CopySlideCommand(Command):
    """复制幻灯片命令"""

    def __init__(self, presentation: Presentation, original_index: int, new_slide: Slide) -> None:
        self.presentation = presentation
        self.original_index = original_index
        self.new_slide = new_slide
        self.inserted_index: int | None = None

    def execute(self) -> None:
        self.inserted_index = self.original_index + 1
        self.presentation.slides.insert(self.inserted_index, self.new_slide)
        # 重新排序
        for i, s in enumerate(self.presentation.slides):
            s.order = i

    def undo(self) -> None:
        if self.inserted_index is not None and 0 <= self.inserted_index < len(self.presentation.slides):
            self.presentation.slides.pop(self.inserted_index)
            # 重新排序
            for i, s in enumerate(self.presentation.slides):
                s.order = i

    def redo(self) -> None:
        self.execute()


class EditSlideCommand(Command):
    """编辑幻灯片内容命令"""

    def __init__(self, slide: Slide, old_content: SlideContent, new_content: SlideContent) -> None:
        self.slide = slide
        self.old_content = old_content
        self.new_content = new_content

    def execute(self) -> None:
        self.slide.content = self.new_content

    def undo(self) -> None:
        self.slide.content = self.old_content

    def redo(self) -> None:
        self.execute()


class ChangeLayoutCommand(Command):
    """改变幻灯片布局命令"""

    def __init__(self, slide: Slide, old_layout, new_layout) -> None:
        self.slide = slide
        self.old_layout = old_layout
        self.new_layout = new_layout

    def execute(self) -> None:
        self.slide.layout_type = self.new_layout

    def undo(self) -> None:
        self.slide.layout_type = self.old_layout

    def redo(self) -> None:
        self.execute()


class CompositeCommand(Command):
    """组合命令 - 允许将多个命令组合成一个单一操作"""

    def __init__(self, commands: list[Command], description: str = "复合操作") -> None:
        """
        初始化组合命令

        Args:
            commands: 要组合的命令列表
            description: 操作描述
        """
        super().__init__()
        self._commands = commands
        self._description = description

    def execute(self) -> None:
        """执行所有命令"""
        for command in self._commands:
            command.execute()

    def undo(self) -> None:
        """撤销所有命令（逆序）"""
        for command in reversed(self._commands):
            command.undo()

    def redo(self) -> None:
        """重做所有命令"""
        for command in self._commands:
            command.redo()

    @property
    def description(self) -> str:
        """获取命令描述"""
        return self._description


# ---------------------------------------------------------------------------
# 命令宏
# ---------------------------------------------------------------------------


class CommandMacro:
    """命令宏 - 录制和回放一系列命令"""

    def __init__(self, name: str = "") -> None:
        """
        初始化命令宏

        Args:
            name: 宏名称
        """
        self._name = name
        self._commands: list[dict[str, Any]] = []
        self._is_recording = False
        self._start_time: datetime | None = None

    @property
    def name(self) -> str:
        """获取宏名称"""
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        """设置宏名称"""
        self._name = value

    @property
    def is_recording(self) -> bool:
        """是否正在录制"""
        return self._is_recording

    @property
    def command_count(self) -> int:
        """录制的命令数量"""
        return len(self._commands)

    def start_recording(self) -> None:
        """开始录制"""
        self._commands = []
        self._is_recording = True
        self._start_time = datetime.now(timezone.utc)

    def stop_recording(self) -> None:
        """停止录制"""
        self._is_recording = False

    def record_command(self, command: Command) -> None:
        """
        录制命令

        Args:
            command: 要录制的命令
        """
        if not self._is_recording:
            return

        command_info = {
            "type": type(command).__name__,
            "description": getattr(command, "description", "Unknown"),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        self._commands.append(command_info)

    def clear(self) -> None:
        """清空录制的命令"""
        self._commands = []

    def to_dict(self) -> dict[str, Any]:
        """转换为字典"""
        return {
            "name": self._name,
            "commands": self._commands,
            "recorded_at": self._start_time.isoformat() if self._start_time else None,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CommandMacro:
        """从字典创建宏"""
        macro = cls(data.get("name", ""))
        macro._commands = data.get("commands", [])
        if data.get("recorded_at"):
            macro._start_time = datetime.fromisoformat(data["recorded_at"])
        return macro


# ---------------------------------------------------------------------------
# 命令栈
# ---------------------------------------------------------------------------


class CommandStack:
    """
    命令栈

    支持：
    - 标准撤销/重做操作
    - 批量命令（CompositeCommand）
    - 宏录制和回放
    - 命令历史持久化
    """

    def __init__(self, max_history: int = 100) -> None:
        """
        初始化命令栈

        Args:
            max_history: 最大历史记录数
        """
        self._undo_stack: list[Command] = []
        self._redo_stack: list[Command] = []
        self._max_history = max_history
        self._current_macro: CommandMacro | None = None
        self._is_playing_macro = False

        # 信号回调
        self._on_change_callbacks: list[Callable[[], None]] = []

    def push(self, command: Command) -> None:
        """
        添加命令到栈

        Args:
            command: 要执行的命令
        """
        # 执行命令
        command.execute()

        # 如果正在录制宏，记录命令
        if self._current_macro and self._current_macro.is_recording:
            self._current_macro.record_command(command)

        # 添加到撤销栈
        self._undo_stack.append(command)

        # 清空重做栈
        self._redo_stack = []

        # 限制历史记录数量
        while len(self._undo_stack) > self._max_history:
            self._undo_stack.pop(0)

        # 通知变化
        self._notify_change()

    def batch_push(self, commands: list[Command], description: str = "批量操作") -> None:
        """
        批量添加命令

        Args:
            commands: 命令列表
            description: 操作描述
        """
        if not commands:
            return

        composite = CompositeCommand(commands, description)
        self.push(composite)

    def undo(self) -> None:
        """撤销上一个操作"""
        if not self.can_undo():
            return

        command = self._undo_stack.pop()
        command.undo()
        self._redo_stack.append(command)

        self._notify_change()

    def redo(self) -> None:
        """重做上一个撤销的操作"""
        if not self.can_redo():
            return

        command = self._redo_stack.pop()
        command.redo()
        self._undo_stack.append(command)

        self._notify_change()

    def can_undo(self) -> bool:
        """是否可以撤销"""
        return len(self._undo_stack) > 0

    def can_redo(self) -> bool:
        """是否可以重做"""
        return len(self._redo_stack) > 0

    def clear(self) -> None:
        """清空命令栈"""
        self._undo_stack = []
        self._redo_stack = []
        self._notify_change()

    def get_history(self, count: int = 10) -> list[dict[str, Any]]:
        """
        获取最近的操作历史

        Args:
            count: 返回的历史记录数量

        Returns:
            历史记录列表
        """
        history = []
        for i, command in enumerate(reversed(self._undo_stack[-count:])):
            history.append({
                "index": len(self._undo_stack) - i - 1,
                "description": getattr(command, "description", "Unknown"),
                "type": type(command).__name__,
            })
        return history

    def get_stack_info(self) -> dict[str, int]:
        """
        获取栈信息

        Returns:
            包含撤销栈和重做栈大小的字典
        """
        return {
            "undo_stack_size": len(self._undo_stack),
            "redo_stack_size": len(self._redo_stack),
            "max_history": self._max_history,
        }

    # 宏录制功能
    def start_macro_recording(self, name: str = "") -> None:
        """
        开始录制宏

        Args:
            name: 宏名称
        """
        self._current_macro = CommandMacro(name)
        self._current_macro.start_recording()

    def stop_macro_recording(self) -> CommandMacro | None:
        """
        停止录制宏

        Returns:
            录制的宏，如果未在录制返回None
        """
        if not self._current_macro:
            return None

        self._current_macro.stop_recording()
        macro = self._current_macro
        self._current_macro = None
        return macro

    def is_recording_macro(self) -> bool:
        """是否正在录制宏"""
        return self._current_macro is not None and self._current_macro.is_recording

    # 信号机制
    def add_change_callback(self, callback: Callable[[], None]) -> None:
        """
        添加变化回调

        Args:
            callback: 回调函数
        """
        if callback not in self._on_change_callbacks:
            self._on_change_callbacks.append(callback)

    def remove_change_callback(self, callback: Callable[[], None]) -> None:
        """
        移除变化回调

        Args:
            callback: 回调函数
        """
        if callback in self._on_change_callbacks:
            self._on_change_callbacks.remove(callback)

    def _notify_change(self) -> None:
        """通知所有回调函数"""
        for callback in self._on_change_callbacks:
            callback()

    # 持久化功能
    def save_history(self, file_path: Path) -> bool:
        """
        保存命令历史到文件

        Args:
            file_path: 文件路径

        Returns:
            保存成功返回True，否则返回False
        """
        try:
            history_data = {
                "undo_stack": [
                    {
                        "type": type(cmd).__name__,
                        "description": getattr(cmd, "description", "Unknown"),
                    }
                    for cmd in self._undo_stack
                ],
                "redo_stack": [
                    {
                        "type": type(cmd).__name__,
                        "description": getattr(cmd, "description", "Unknown"),
                    }
                    for cmd in self._redo_stack
                ],
                "saved_at": datetime.now(timezone.utc).isoformat(),
            }

            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(history_data, f, ensure_ascii=False, indent=2)

        except (OSError, PermissionError) as exc:
            logger.warning("保存命令历史文件IO失败: path=%s, error=%s", file_path, exc)
            return False
        except (TypeError, ValueError) as exc:
            logger.warning("命令历史序列化失败: path=%s, error=%s", file_path, exc)
            return False
        else:
            return True

    def load_history(self, file_path: Path) -> bool:
        """
        从文件加载命令历史（注意：这只是加载历史记录，不执行命令）

        Args:
            file_path: 文件路径

        Returns:
            加载成功返回True，否则返回False
        """
        try:
            with open(file_path, encoding="utf-8") as f:
                json.load(f)

            # 这里只加载历史记录信息，不执行实际的命令恢复
            # 完整的命令恢复需要命令对象的序列化支持

        except FileNotFoundError:
            logger.warning("命令历史文件不存在: %s", file_path)
            return False
        except json.JSONDecodeError as exc:
            logger.warning("命令历史文件格式错误: path=%s, error=%s", file_path, exc)
            return False
        except OSError as exc:
            logger.warning("加载命令历史文件失败: path=%s, error=%s", file_path, exc)
            return False
        else:
            return True
