"""
PPTMaker数据模型
定义主题、布局、幻灯片和演示文稿的数据结构

本模块只包含纯数据模型定义（dataclass）与必要的数据有效性验证，
不包含任何 IO、序列化或业务逻辑。
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field, fields
from datetime import datetime, timezone
from enum import Enum
from typing import Any

from bitool.core import logger

# 有效的 十六进制颜色格式：#RGB / #RGBA / #RRGGBB / #RRGGBBAA
_HEX_COLOR_PATTERN = re.compile(r"^#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$")


def _validate_hex_color(value: str, field_name: str) -> None:
    """校验颜色字符串是否为合法的十六进制格式。"""
    if not isinstance(value, str) or not _HEX_COLOR_PATTERN.match(value):
        logger.error(f"主题颜色字段 {field_name!r} 值不合法: {value!r}")
        raise ValueError(f"颜色字段 {field_name!r} 必须为十六进制格式 (如 #RRGGBB)，实际为: {value!r}")


def _validate_non_empty(value: Any, field_name: str) -> None:
    """校验字符串字段非空。"""
    if not isinstance(value, str) or not value.strip():
        logger.error(f"必填字段 {field_name!r} 为空或类型错误: {value!r}")
        raise ValueError(f"必填字段 {field_name!r} 不能为空")


class LayoutType(Enum):
    """布局类型枚举"""

    TITLE_ONLY = "title_only"
    TITLE_CONTENT = "title_content"
    TITLE_CONTENT_ICON = "title_content_icon"
    TWO_COLUMNS = "two_columns"
    BIG_TITLE = "big_title"
    TITLE_BULLETS = "title_bullets"
    TITLE_IMAGE = "title_image"
    COMPARISON = "comparison"


@dataclass
class ThemeColors:
    """主题颜色配置。所有字段需为合法的十六进制颜色。"""

    primary: str = "#1e40af"
    secondary: str = "#3b82f6"
    accent: str = "#f97316"
    background: str = "#ffffff"
    text: str = "#1f2937"
    text_light: str = "#6b7280"
    success: str = "#10b981"
    warning: str = "#f59e0b"
    error: str = "#ef4444"

    def __post_init__(self) -> None:
        for f in fields(self):
            _validate_hex_color(getattr(self, f.name), f.name)


@dataclass
class ThemeFonts:
    """主题字体配置"""

    heading: str = "Microsoft YaHei"
    body: str = "Microsoft YaHei"
    code: str = "Consolas"

    def __post_init__(self) -> None:
        _validate_non_empty(self.heading, "heading")
        _validate_non_empty(self.body, "body")
        _validate_non_empty(self.code, "code")


@dataclass
class Theme:
    """演示文稿主题"""

    id: str = "default"
    name: str = "默认主题"
    description: str = "简洁现代的默认主题"
    colors: ThemeColors = field(default_factory=ThemeColors)
    fonts: ThemeFonts = field(default_factory=ThemeFonts)

    def __post_init__(self) -> None:
        _validate_non_empty(self.id, "id")
        _validate_non_empty(self.name, "name")
        if not isinstance(self.colors, ThemeColors):
            raise TypeError("Theme.colors 必须为 ThemeColors 实例")
        if not isinstance(self.fonts, ThemeFonts):
            raise TypeError("Theme.fonts 必须为 ThemeFonts 实例")


@dataclass
class Layout:
    """幻灯片布局定义"""

    id: str
    name: str
    description: str
    layout_type: LayoutType
    template_path: str | None = None

    def __post_init__(self) -> None:
        _validate_non_empty(self.id, "id")
        _validate_non_empty(self.name, "name")
        if not isinstance(self.layout_type, LayoutType):
            raise TypeError("Layout.layout_type 必须为 LayoutType 枚举")


@dataclass
class SlideElement:
    """幻灯片元素"""

    id: str
    element_type: str  # text, image, icon, shape
    content: str
    x: float = 0.0  # 相对位置 0-1
    y: float = 0.0
    width: float = 1.0
    height: float = 1.0
    style: dict[str, Any] = field(default_factory=dict)


@dataclass
class SlideContent:
    """幻灯片内容"""

    title: str = ""
    subtitle: str = ""
    body: str = ""
    bullets: list[str] = field(default_factory=list)
    icon: str | None = None
    image_path: str | None = None
    elements: list[SlideElement] = field(default_factory=list)


@dataclass
class Slide:
    """幻灯片"""

    id: str
    order: int
    layout_type: LayoutType = LayoutType.TITLE_CONTENT
    content: SlideContent = field(default_factory=SlideContent)
    notes: str = ""


@dataclass
class Presentation:
    """演示文稿"""

    id: str
    title: str = "未命名演示文稿"
    theme_id: str = "default"
    layout_id: str = "default"
    slides: list[Slide] = field(default_factory=list)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: dict[str, Any] = field(default_factory=dict)
