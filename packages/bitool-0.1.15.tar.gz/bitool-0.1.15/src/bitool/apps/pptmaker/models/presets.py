"""
预设主题和布局配置
"""

from __future__ import annotations

from .models import Layout, LayoutType, Theme, ThemeColors, ThemeFonts


def get_preset_themes() -> list[Theme]:
    """获取所有预设主题"""
    return [
        Theme(
            id="default",
            name="默认主题",
            description="简洁现代的默认主题",
            colors=ThemeColors(
                primary="#1e40af",
                secondary="#3b82f6",
                accent="#f97316",
                background="#ffffff",
                text="#1f2937",
                text_light="#6b7280",
            ),
            fonts=ThemeFonts(heading="Microsoft YaHei", body="Microsoft YaHei"),
        ),
        Theme(
            id="modern",
            name="现代商务",
            description="专业商务风格主题",
            colors=ThemeColors(
                primary="#0f172a",
                secondary="#334155",
                accent="#0ea5e9",
                background="#f8fafc",
                text="#1e293b",
                text_light="#64748b",
            ),
            fonts=ThemeFonts(heading="Microsoft YaHei", body="Microsoft YaHei"),
        ),
        Theme(
            id="creative",
            name="创意设计",
            description="富有创意的设计风格",
            colors=ThemeColors(
                primary="#7c3aed",
                secondary="#8b5cf6",
                accent="#ec4899",
                background="#faf5ff",
                text="#4c1d95",
                text_light="#7c3aed",
            ),
            fonts=ThemeFonts(heading="Microsoft YaHei", body="Microsoft YaHei"),
        ),
        Theme(
            id="minimal",
            name="极简风格",
            description="简约优雅的极简风格",
            colors=ThemeColors(
                primary="#111827",
                secondary="#374151",
                accent="#4b5563",
                background="#ffffff",
                text="#111827",
                text_light="#6b7280",
            ),
            fonts=ThemeFonts(heading="Microsoft YaHei", body="Microsoft YaHei"),
        ),
        Theme(
            id="warm",
            name="温暖活力",
            description="温暖活力的配色方案",
            colors=ThemeColors(
                primary="#dc2626",
                secondary="#ea580c",
                accent="#d97706",
                background="#fef3c7",
                text="#7c2d12",
                text_light="#92400e",
            ),
            fonts=ThemeFonts(heading="Microsoft YaHei", body="Microsoft YaHei"),
        ),
        # 教育主题
        Theme(
            id="education",
            name="教育文化",
            description="适合教育、培训、讲座的主题",
            colors=ThemeColors(
                primary="#1e3a8a",
                secondary="#3b82f6",
                accent="#059669",
                background="#f0f9ff",
                text="#1e293b",
                text_light="#64748b",
            ),
            fonts=ThemeFonts(heading="Microsoft YaHei", body="Microsoft YaHei"),
        ),
        # 党群/红色主题
        Theme(
            id="party",
            name="党群党建",
            description="适合党建、政府、国企的红色主题",
            colors=ThemeColors(
                primary="#b91c1c",
                secondary="#dc2626",
                accent="#f59e0b",
                background="#fef2f2",
                text="#1f2937",
                text_light="#7f1d1d",
            ),
            fonts=ThemeFonts(heading="SimHei", body="SimHei"),
        ),
        # 科技主题
        Theme(
            id="tech",
            name="科技前沿",
            description="适合科技、互联网、创新产品的主题",
            colors=ThemeColors(
                primary="#0f172a",
                secondary="#0ea5e9",
                accent="#06b6d4",
                background="#020617",
                text="#f0f9ff",
                text_light="#7dd3fc",
            ),
            fonts=ThemeFonts(heading="Microsoft YaHei", body="Microsoft YaHei"),
        ),
        # 现代简约主题
        Theme(
            id="modern_simple",
            name="现代简约",
            description="清新现代的简约风格",
            colors=ThemeColors(
                primary="#047857",
                secondary="#10b981",
                accent="#34d399",
                background="#f0fdf4",
                text="#064e3b",
                text_light="#059669",
            ),
            fonts=ThemeFonts(heading="Microsoft YaHei", body="Microsoft YaHei"),
        ),
        # 深蓝商务
        Theme(
            id="blue_business",
            name="深蓝商务",
            description="稳重专业的商务主题",
            colors=ThemeColors(
                primary="#1e3a8a",
                secondary="#1d4ed8",
                accent="#2563eb",
                background="#eff6ff",
                text="#1e293b",
                text_light="#64748b",
            ),
            fonts=ThemeFonts(heading="Microsoft YaHei", body="Microsoft YaHei"),
        ),
        # 紫色优雅
        Theme(
            id="purple_elegant",
            name="紫色优雅",
            description="优雅知性的紫色主题",
            colors=ThemeColors(
                primary="#581c87",
                secondary="#7c3aed",
                accent="#a855f7",
                background="#faf5ff",
                text="#581c87",
                text_light="#7c3aed",
            ),
            fonts=ThemeFonts(heading="Microsoft YaHei", body="Microsoft YaHei"),
        ),
        # 橙黄活力
        Theme(
            id="orange_vibrant",
            name="橙黄活力",
            description="充满活力的橙色主题",
            colors=ThemeColors(
                primary="#c2410c",
                secondary="#ea580c",
                accent="#f59e0b",
                background="#fff7ed",
                text="#7c2d12",
                text_light="#c2410c",
            ),
            fonts=ThemeFonts(heading="Microsoft YaHei", body="Microsoft YaHei"),
        ),
        # 森林自然
        Theme(
            id="forest_nature",
            name="森林自然",
            description="清新自然的绿色主题",
            colors=ThemeColors(
                primary="#166534",
                secondary="#15803d",
                accent="#22c55e",
                background="#f0fdf4",
                text="#14532d",
                text_light="#166534",
            ),
            fonts=ThemeFonts(heading="Microsoft YaHei", body="Microsoft YaHei"),
        ),
        # 医疗健康
        Theme(
            id="medical_health",
            name="医疗健康",
            description="专业医疗健康主题",
            colors=ThemeColors(
                primary="#0369a1",
                secondary="#0284c7",
                accent="#0ea5e9",
                background="#f0f9ff",
                text="#0c4a6e",
                text_light="#0369a1",
            ),
            fonts=ThemeFonts(heading="Microsoft YaHei", body="Microsoft YaHei"),
        ),
    ]


def get_preset_layouts() -> list[Layout]:
    """获取所有预设布局"""
    return [
        Layout(id="title_only", name="仅标题", description="大标题居中展示", layout_type=LayoutType.TITLE_ONLY),
        Layout(
            id="title_content",
            name="标题+内容",
            description="经典的标题和内容布局",
            layout_type=LayoutType.TITLE_CONTENT,
        ),
        Layout(
            id="title_content_icon",
            name="标题+内容+图标",
            description="标题、内容配合图标展示",
            layout_type=LayoutType.TITLE_CONTENT_ICON,
        ),
        Layout(id="two_columns", name="双列布局", description="左右分栏展示内容", layout_type=LayoutType.TWO_COLUMNS),
        Layout(id="big_title", name="大标题", description="醒目的大标题页面", layout_type=LayoutType.BIG_TITLE),
        Layout(
            id="title_bullets", name="标题+要点", description="标题和要点列表", layout_type=LayoutType.TITLE_BULLETS,
        ),
        Layout(id="title_image", name="标题+图片", description="标题配合图片展示", layout_type=LayoutType.TITLE_IMAGE),
        Layout(id="comparison", name="对比布局", description="左右对比展示内容", layout_type=LayoutType.COMPARISON),
    ]


def get_theme_by_id(theme_id: str) -> Theme:
    """根据ID获取主题"""
    themes = get_preset_themes()
    for theme in themes:
        if theme.id == theme_id:
            return theme
    return themes[0]


def get_layout_by_id(layout_id: str) -> Layout:
    """根据ID获取布局"""
    layouts = get_preset_layouts()
    for layout in layouts:
        if layout.id == layout_id:
            return layout
    return layouts[0]
