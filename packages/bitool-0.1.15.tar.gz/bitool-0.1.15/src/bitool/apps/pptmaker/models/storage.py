"""
演示文稿数据模型序列化层

本模块只负责数据结构与 dict/JSON 之间的转换，不进行任何文件 IO。
文件读写位于 ``bitool.apps.pptmaker.storage`` 包下。

提供：

- :class:`PresentationSerializer` —— 推荐使用的序列化入口，包含
  ``to_dict`` / ``from_dict`` / ``to_json_str`` / ``from_json_str``
  以及 ``create_new`` 工厂方法。
- :class:`PresentationStorage` —— 向后兼容的旧 API，``save`` / ``load``
  会委托到 ``storage`` 包下的文件 IO 实现。
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .models import LayoutType, Presentation, Slide, SlideContent, SlideElement


class PresentationSerializer:
    """演示文稿序列化器（纯数据格式转换）。"""

    # ------------------------------------------------------------------
    # dict <-> Presentation
    # ------------------------------------------------------------------

    @staticmethod
    def to_dict(presentation: Presentation) -> dict[str, Any]:
        """将演示文稿转换为可 JSON 序列化的字典。"""
        return {
            "id": presentation.id,
            "title": presentation.title,
            "theme_id": presentation.theme_id,
            "layout_id": presentation.layout_id,
            "slides": [
                {
                    "id": slide.id,
                    "order": slide.order,
                    "layout_type": slide.layout_type.value,
                    "content": {
                        "title": slide.content.title,
                        "subtitle": slide.content.subtitle,
                        "body": slide.content.body,
                        "bullets": list(slide.content.bullets),
                        "icon": slide.content.icon,
                        "image_path": slide.content.image_path,
                        "elements": [
                            {
                                "id": elem.id,
                                "element_type": elem.element_type,
                                "content": elem.content,
                                "x": elem.x,
                                "y": elem.y,
                                "width": elem.width,
                                "height": elem.height,
                                "style": elem.style,
                            }
                            for elem in slide.content.elements
                        ],
                    },
                    "notes": slide.notes,
                }
                for slide in presentation.slides
            ],
            "created_at": presentation.created_at.isoformat(),
            "updated_at": presentation.updated_at.isoformat(),
            "metadata": presentation.metadata,
        }

    @staticmethod
    def from_dict(data: dict[str, Any]) -> Presentation:
        """从字典构建演示文稿。"""
        slides: list[Slide] = []
        for slide_data in data.get("slides", []):
            content_data = slide_data.get("content", {})
            elements = [
                SlideElement(
                    id=elem_data.get("id", str(uuid.uuid4())),
                    element_type=elem_data.get("element_type", "text"),
                    content=elem_data.get("content", ""),
                    x=elem_data.get("x", 0.0),
                    y=elem_data.get("y", 0.0),
                    width=elem_data.get("width", 1.0),
                    height=elem_data.get("height", 1.0),
                    style=elem_data.get("style", {}),
                )
                for elem_data in content_data.get("elements", [])
            ]

            slide = Slide(
                id=slide_data.get("id", str(uuid.uuid4())),
                order=slide_data.get("order", 0),
                layout_type=LayoutType(slide_data.get("layout_type", "title_content")),
                content=SlideContent(
                    title=content_data.get("title", ""),
                    subtitle=content_data.get("subtitle", ""),
                    body=content_data.get("body", ""),
                    bullets=list(content_data.get("bullets", [])),
                    icon=content_data.get("icon"),
                    image_path=content_data.get("image_path"),
                    elements=elements,
                ),
                notes=slide_data.get("notes", ""),
            )
            slides.append(slide)

        now_iso = datetime.now(timezone.utc).isoformat()
        return Presentation(
            id=data.get("id", str(uuid.uuid4())),
            title=data.get("title", "未命名演示文稿"),
            theme_id=data.get("theme_id", "default"),
            layout_id=data.get("layout_id", "default"),
            slides=slides,
            created_at=datetime.fromisoformat(data.get("created_at", now_iso)),
            updated_at=datetime.fromisoformat(data.get("updated_at", now_iso)),
            metadata=data.get("metadata", {}),
        )

    # ------------------------------------------------------------------
    # str (JSON) <-> Presentation
    # ------------------------------------------------------------------

    @staticmethod
    def to_json_str(presentation: Presentation, *, indent: int | None = 2) -> str:
        """将演示文稿序列化为 JSON 字符串。"""
        return json.dumps(
            PresentationSerializer.to_dict(presentation),
            ensure_ascii=False,
            indent=indent,
        )

    @staticmethod
    def from_json_str(text: str) -> Presentation:
        """从 JSON 字符串反序列化演示文稿。"""
        return PresentationSerializer.from_dict(json.loads(text))

    # ------------------------------------------------------------------
    # 工厂方法
    # ------------------------------------------------------------------

    @staticmethod
    def create_new(title: str = "未命名演示文稿") -> Presentation:
        """创建一个全新的空演示文稿。"""
        now = datetime.now(timezone.utc)
        return Presentation(
            id=str(uuid.uuid4()),
            title=title,
            theme_id="default",
            layout_id="default",
            slides=[],
            created_at=now,
            updated_at=now,
        )


class PresentationStorage:
    """向后兼容的存储 API。

    序列化部分直接委托到 :class:`PresentationSerializer`，
    文件 IO 部分委托到 ``bitool.apps.pptmaker.storage.file_storage``。

    新代码请优先使用 :class:`PresentationSerializer` 与 ``storage`` 包下的
    ``save_to_file`` / ``load_from_file`` 函数。
    """

    # ---- 序列化（保持旧的私有命名以兼容历史调用） ---------------------

    @staticmethod
    def _presentation_to_dict(presentation: Presentation) -> dict[str, Any]:
        return PresentationSerializer.to_dict(presentation)

    @staticmethod
    def _dict_to_presentation(data: dict[str, Any]) -> Presentation:
        return PresentationSerializer.from_dict(data)

    # ---- 文件 IO（委托至 storage 包） --------------------------------

    @staticmethod
    def save(presentation: Presentation, file_path: Path) -> bool:
        """保存演示文稿到 JSON 文件（委托至 storage 包）。"""
        # 延迟导入以避免循环依赖
        from ..storage.file_storage import save_to_file

        return save_to_file(presentation, file_path)

    @staticmethod
    def load(file_path: Path) -> Presentation | None:
        """从 JSON 文件加载演示文稿（委托至 storage 包）。"""
        from ..storage.file_storage import load_from_file

        return load_from_file(file_path)

    @staticmethod
    def create_new(title: str = "未命名演示文稿") -> Presentation:
        """创建新的演示文稿（等价于 :meth:`PresentationSerializer.create_new`）。"""
        return PresentationSerializer.create_new(title)


__all__ = ["PresentationSerializer", "PresentationStorage"]
