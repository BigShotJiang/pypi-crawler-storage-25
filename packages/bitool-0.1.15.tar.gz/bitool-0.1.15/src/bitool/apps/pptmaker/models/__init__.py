"""数据模型模块。

按职责分层：

- :mod:`.models` —— 纯数据结构（dataclass / Enum）
- :mod:`.storage` —— 数据格式转换（dict/JSON 序列化），不做文件 IO
- :mod:`.presets` —— 内置主题与布局
"""

from .models import (
    Layout,
    LayoutType,
    Presentation,
    Slide,
    SlideContent,
    SlideElement,
    Theme,
    ThemeColors,
    ThemeFonts,
)
from .presets import (
    get_layout_by_id,
    get_preset_layouts,
    get_preset_themes,
    get_theme_by_id,
)
from .storage import PresentationSerializer, PresentationStorage

__all__ = [
    "Layout",
    "LayoutType",
    "Presentation",
    "PresentationSerializer",
    # 旧名称保留以维持向后兼容
    "PresentationStorage",
    "Slide",
    "SlideContent",
    "SlideElement",
    "Theme",
    "ThemeColors",
    "ThemeFonts",
    "get_layout_by_id",
    "get_preset_layouts",
    "get_preset_themes",
    "get_theme_by_id",
]
