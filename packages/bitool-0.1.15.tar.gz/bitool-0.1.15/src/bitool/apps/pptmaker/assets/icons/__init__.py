"""
SVG图标工具
将SVG转换为Qt图标
"""

from typing import Optional

from bitool.gui.compat import QIcon, QPainter, QPixmap, QSize, QSvgRenderer, Qt

from .icon_library import SVG_ICONS, get_icon_names, get_icon_svg, icon_exists

__all__ = [
    "SVG_ICONS",
    "get_icon",
    "get_icon_names",
    "get_icon_svg",
    "icon_exists",
    "svg_to_icon",
]


def svg_to_icon(svg_content: str, size: int = 24, color: Optional[str] = None) -> QIcon:
    """
    将SVG内容转换为QIcon

    Args:
        svg_content: SVG字符串
        size: 图标尺寸
        color: 图标颜色（如 #333333），None则使用默认颜色

    Returns:
        QIcon对象
    """
    if color:
        # 替换颜色
        svg_content = svg_content.replace('stroke="currentColor"', f'stroke="{color}"')

    # 创建SVG渲染器
    svg_renderer = QSvgRenderer(svg_content.encode("utf-8"))

    # 创建QPixmap
    pixmap = QPixmap(QSize(size, size))
    pixmap.fill(Qt.transparent)

    # 绘制
    painter = QPainter(pixmap)
    svg_renderer.render(painter)
    painter.end()

    return QIcon(pixmap)


def get_icon(
    icon_name: str, size: int = 24, color: Optional[str] = None
) -> Optional[QIcon]:
    """
    根据图标名称获取QIcon

    Args:
        icon_name: 图标名称
        size: 图标尺寸
        color: 图标颜色

    Returns:
        QIcon对象，失败返回None
    """
    if not icon_exists(icon_name):
        return None

    svg_content = get_icon_svg(icon_name)
    return svg_to_icon(svg_content, size, color)
