"""PPT Maker 资源包"""

from __future__ import annotations

__all__: list[str] = []
