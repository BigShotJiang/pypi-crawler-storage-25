"""
演示示例模块
包含典型的演示文稿示例和快速加载接口
"""

from .demo_manager import DemoManager, get_demo_manager
from .theme_preview import create_theme_demo_presentation, generate_all_theme_demos

__all__ = [
    "DemoManager",
    "create_theme_demo_presentation",
    "generate_all_theme_demos",
    "get_demo_manager",
]
