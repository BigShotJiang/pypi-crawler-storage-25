"""
演示示例管理器
提供典型示例的创建、保存和加载功能
"""

import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

from ..models.models import LayoutType, Presentation, Slide, SlideContent
from ..models.storage import PresentationStorage


class DemoInfo:
    """示例信息"""

    def __init__(
        self, demo_id: str, name: str, description: str, category: str, file_path: Path, thumbnail: Optional[str] = None,
    ) -> None:
        self.id = demo_id
        self.name = name
        self.description = description
        self.category = category
        self.file_path = file_path
        self.thumbnail = thumbnail


class DemoManager:
    """演示示例管理器"""

    def __init__(self, demos_dir: Optional[Path] = None) -> None:
        if demos_dir is None:
            demos_dir = Path(__file__).parent
        self.demos_dir = demos_dir
        self._demos: Dict[str, DemoInfo] = {}
        self._load_demos()

    def _load_demos(self) -> None:
        """加载所有示例"""
        # 预定义示例列表
        demo_definitions = [
            {
                "id": "welcome",
                "name": "欢迎使用",
                "description": "PPT Maker 介绍示例，展示基本功能",
                "category": "入门",
                "create_func": self._create_welcome_demo,
            },
            {
                "id": "business_plan",
                "name": "商业计划",
                "description": "专业的商业计划书模板",
                "category": "商务",
                "create_func": self._create_business_plan_demo,
            },
            {
                "id": "product_intro",
                "name": "产品介绍",
                "description": "产品发布和展示模板",
                "category": "营销",
                "create_func": self._create_product_intro_demo,
            },
            {
                "id": "course_lecture",
                "name": "课程讲座",
                "description": "教育培训类演示模板",
                "category": "教育",
                "create_func": self._create_course_lecture_demo,
            },
            {
                "id": "project_report",
                "name": "项目报告",
                "description": "项目进度和成果汇报",
                "category": "报告",
                "create_func": self._create_project_report_demo,
            },
            {
                "id": "party_building",
                "name": "党建工作",
                "description": "党建、政府、国企相关演示模板",
                "category": "党群",
                "create_func": self._create_party_building_demo,
            },
            {
                "id": "tech_presentation",
                "name": "科技发布",
                "description": "科技产品、互联网项目发布模板",
                "category": "科技",
                "create_func": self._create_tech_presentation_demo,
            },
            {
                "id": "medical_report",
                "name": "医疗健康",
                "description": "医疗、健康相关专业演示",
                "category": "医疗",
                "create_func": self._create_medical_report_demo,
            },
        ]

        # 确保 demo 文件存在
        for demo_def in demo_definitions:
            file_path = self.demos_dir / f"{demo_def['id']}.pptm.json"
            if not file_path.exists():
                presentation = demo_def["create_func"]()
                PresentationStorage.save(presentation, file_path)

            self._demos[demo_def["id"]] = DemoInfo(
                demo_id=demo_def["id"],
                name=demo_def["name"],
                description=demo_def["description"],
                category=demo_def["category"],
                file_path=file_path,
            )

    def get_demos(self, category: Optional[str] = None) -> List[DemoInfo]:
        """
        获取示例列表

        Args:
            category: 可选的分类筛选

        Returns:
            示例信息列表
        """
        demos = list(self._demos.values())
        if category:
            demos = [d for d in demos if d.category == category]
        return demos

    def get_categories(self) -> List[str]:
        """获取所有分类"""
        categories = list({d.category for d in self._demos.values()})
        return sorted(categories)

    def get_demo(self, demo_id: str) -> Optional[DemoInfo]:
        """根据 ID 获取示例"""
        return self._demos.get(demo_id)

    def load_demo(self, demo_id: str) -> Optional[Presentation]:
        """
        加载示例

        Args:
            demo_id: 示例 ID

        Returns:
            演示文稿对象
        """
        demo = self.get_demo(demo_id)
        if demo and demo.file_path.exists():
            return PresentationStorage.load(demo.file_path)
        return None

    def _create_welcome_demo(self) -> Presentation:
        """创建欢迎示例"""
        presentation = Presentation(
            id=str(uuid.uuid4()),
            title="欢迎使用 PPT Maker",
            theme_id="default",
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )

        # 幻灯片 1 - 欢迎
        slide1 = Slide(
            id=str(uuid.uuid4()),
            order=0,
            layout_type=LayoutType.BIG_TITLE,
            content=SlideContent(title="欢迎使用 PPT Maker", subtitle="快速创建专业演示文稿的强大工具"),
        )
        presentation.slides.append(slide1)

        # 幻灯片 2 - 功能介绍
        slide2 = Slide(
            id=str(uuid.uuid4()),
            order=1,
            layout_type=LayoutType.TITLE_BULLETS,
            content=SlideContent(
                title="主要功能",
                bullets=[
                    "13种精美主题，满足不同场景",
                    "8种幻灯片布局，灵活多变",
                    "内置SVG图标库，丰富内容",
                    "智能自动布局，省心省力",
                    "JSON数据格式，易于保存和分享",
                ],
            ),
        )
        presentation.slides.append(slide2)

        # 幻灯片 3 - 主题展示
        slide3 = Slide(
            id=str(uuid.uuid4()),
            order=2,
            layout_type=LayoutType.TITLE_CONTENT,
            content=SlideContent(
                title="13种专业主题",
                body="默认、现代商务、创意设计、极简风格、温暖活力、教育文化、党建工作、科技前沿、现代简约、深蓝商务、紫色优雅、橙黄活力、森林自然、医疗健康，总有一款适合你！",
            ),
        )
        presentation.slides.append(slide3)

        return presentation

    def _create_business_plan_demo(self) -> Presentation:
        """创建商业计划示例"""
        presentation = Presentation(
            id=str(uuid.uuid4()),
            title="商业计划书",
            theme_id="modern",
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )

        # 封面
        slide1 = Slide(
            id=str(uuid.uuid4()),
            order=0,
            layout_type=LayoutType.BIG_TITLE,
            content=SlideContent(title="智能科技商业计划书", subtitle="2024-2026 战略规划"),
        )
        presentation.slides.append(slide1)

        # 项目概述
        slide2 = Slide(
            id=str(uuid.uuid4()),
            order=1,
            layout_type=LayoutType.TITLE_CONTENT,
            content=SlideContent(
                title="项目概述",
                body="本项目致力于开发下一代人工智能解决方案，为企业提供智能化服务，提升工作效率和决策质量。",
            ),
        )
        presentation.slides.append(slide2)

        # 市场分析
        slide3 = Slide(
            id=str(uuid.uuid4()),
            order=2,
            layout_type=LayoutType.TITLE_BULLETS,
            content=SlideContent(
                title="市场分析",
                bullets=[
                    "AI市场规模快速增长，预计2026年达5000亿",
                    "企业数字化转型需求强烈",
                    "现有解决方案存在诸多痛点",
                    "我们的产品定位精准，差异化明显",
                ],
            ),
        )
        presentation.slides.append(slide3)

        # 商业模式
        slide4 = Slide(
            id=str(uuid.uuid4()),
            order=3,
            layout_type=LayoutType.TWO_COLUMNS,
            content=SlideContent(
                title="商业模式",
                body="采用订阅制为主，项目定制为辅的商业模式",
                bullets=["SaaS订阅服务", "企业定制开发", "技术咨询服务", "培训认证体系"],
            ),
        )
        presentation.slides.append(slide4)

        return presentation

    def _create_product_intro_demo(self) -> Presentation:
        """创建产品介绍示例"""
        presentation = Presentation(
            id=str(uuid.uuid4()),
            title="产品发布会",
            theme_id="creative",
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )

        # 封面
        slide1 = Slide(
            id=str(uuid.uuid4()),
            order=0,
            layout_type=LayoutType.BIG_TITLE,
            content=SlideContent(title="Product X", subtitle="重新定义工作方式"),
        )
        presentation.slides.append(slide1)

        # 产品亮点
        slide2 = Slide(
            id=str(uuid.uuid4()),
            order=1,
            layout_type=LayoutType.TITLE_CONTENT_ICON,
            content=SlideContent(title="核心亮点", body="全新设计，智能高效，让工作变得更简单、更快乐。", icon="star"),
        )
        presentation.slides.append(slide2)

        # 功能特性
        slide3 = Slide(
            id=str(uuid.uuid4()),
            order=2,
            layout_type=LayoutType.TITLE_BULLETS,
            content=SlideContent(
                title="功能特性",
                bullets=["AI 智能助手，24小时在线", "云端同步，多端协作", "安全加密，保护隐私", "简单易用，零学习成本"],
            ),
        )
        presentation.slides.append(slide3)

        return presentation

    def _create_course_lecture_demo(self) -> Presentation:
        """创建课程讲座示例"""
        presentation = Presentation(
            id=str(uuid.uuid4()),
            title="Python 编程入门",
            theme_id="minimal",
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )

        # 课程介绍
        slide1 = Slide(
            id=str(uuid.uuid4()),
            order=0,
            layout_type=LayoutType.TITLE_ONLY,
            content=SlideContent(title="Python 编程入门"),
        )
        presentation.slides.append(slide1)

        # 课程大纲
        slide2 = Slide(
            id=str(uuid.uuid4()),
            order=1,
            layout_type=LayoutType.TITLE_BULLETS,
            content=SlideContent(
                title="课程大纲",
                bullets=["第一章：Python 基础语法", "第二章：数据类型与变量", "第三章：控制流程", "第四章：函数与模块"],
            ),
        )
        presentation.slides.append(slide2)

        # 第一节课
        slide3 = Slide(
            id=str(uuid.uuid4()),
            order=2,
            layout_type=LayoutType.TITLE_CONTENT,
            content=SlideContent(
                title="第一章：Python 基础",
                body="Hello, World! 让我们开始 Python 编程之旅。学习 print 语句、注释、基本输入输出等基础内容。",
            ),
        )
        presentation.slides.append(slide3)

        return presentation

    def _create_project_report_demo(self) -> Presentation:
        """创建项目报告示例"""
        presentation = Presentation(
            id=str(uuid.uuid4()),
            title="项目进度报告",
            theme_id="warm",
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )

        # 报告封面
        slide1 = Slide(
            id=str(uuid.uuid4()),
            order=0,
            layout_type=LayoutType.BIG_TITLE,
            content=SlideContent(title="Q2 项目进度报告", subtitle="产品研发部 · 2024年6月"),
        )
        presentation.slides.append(slide1)

        # 完成情况
        slide2 = Slide(
            id=str(uuid.uuid4()),
            order=1,
            layout_type=LayoutType.TITLE_BULLETS,
            content=SlideContent(
                title="完成情况",
                bullets=["需求分析阶段 100% ✔", "系统设计阶段 100% ✔", "开发实现阶段 75% ▶", "测试验收阶段 0% ◯"],
            ),
        )
        presentation.slides.append(slide2)

        # 下一步计划
        slide3 = Slide(
            id=str(uuid.uuid4()),
            order=2,
            layout_type=LayoutType.TITLE_CONTENT,
            content=SlideContent(title="下一步计划", body="继续完成剩余开发工作，启动测试计划，准备上线部署。"),
        )
        presentation.slides.append(slide3)

        return presentation

    def _create_party_building_demo(self) -> Presentation:
        """创建党建工作示例"""
        presentation = Presentation(
            id=str(uuid.uuid4()),
            title="党建工作汇报",
            theme_id="party",
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )

        slide1 = Slide(
            id=str(uuid.uuid4()),
            order=0,
            layout_type=LayoutType.BIG_TITLE,
            content=SlideContent(title="党建工作汇报", subtitle="2024年度第二季度"),
        )
        presentation.slides.append(slide1)

        slide2 = Slide(
            id=str(uuid.uuid4()),
            order=1,
            layout_type=LayoutType.TITLE_BULLETS,
            content=SlideContent(
                title="主要工作",
                bullets=[
                    "深入学习贯彻党的二十大精神",
                    "加强支部建设，规范组织生活",
                    "开展党史学习教育常态化",
                    "服务群众，办实事、解难题",
                ],
            ),
        )
        presentation.slides.append(slide2)

        slide3 = Slide(
            id=str(uuid.uuid4()),
            order=2,
            layout_type=LayoutType.TITLE_CONTENT,
            content=SlideContent(
                title="工作成效",
                body="通过扎实的党建工作，党员干部的思想政治素质得到明显提升，党支部的战斗堡垒作用和党员的先锋模范作用得到充分发挥。",
            ),
        )
        presentation.slides.append(slide3)

        return presentation

    def _create_tech_presentation_demo(self) -> Presentation:
        """创建科技发布示例"""
        presentation = Presentation(
            id=str(uuid.uuid4()),
            title="Tech Product Launch",
            theme_id="tech",
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )

        slide1 = Slide(
            id=str(uuid.uuid4()),
            order=0,
            layout_type=LayoutType.BIG_TITLE,
            content=SlideContent(title="New Generation AI Platform", subtitle="Innovation Meets Intelligence"),
        )
        presentation.slides.append(slide1)

        slide2 = Slide(
            id=str(uuid.uuid4()),
            order=1,
            layout_type=LayoutType.TITLE_BULLETS,
            content=SlideContent(
                title="Key Features",
                bullets=[
                    "Advanced Machine Learning Models",
                    "Real-time Data Processing",
                    "Intelligent Automation",
                    "Scalable Cloud Architecture",
                ],
            ),
        )
        presentation.slides.append(slide2)

        slide3 = Slide(
            id=str(uuid.uuid4()),
            order=2,
            layout_type=LayoutType.TITLE_CONTENT,
            content=SlideContent(
                title="Technology Stack",
                body="Built with cutting-edge technologies: distributed computing, big data processing, and neural network architectures optimized for performance and scalability.",
            ),
        )
        presentation.slides.append(slide3)

        return presentation

    def _create_medical_report_demo(self) -> Presentation:
        """创建医疗健康示例"""
        presentation = Presentation(
            id=str(uuid.uuid4()),
            title="健康管理报告",
            theme_id="medical_health",
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )

        slide1 = Slide(
            id=str(uuid.uuid4()),
            order=0,
            layout_type=LayoutType.BIG_TITLE,
            content=SlideContent(title="健康管理年度报告", subtitle="2024年健康体检与评估"),
        )
        presentation.slides.append(slide1)

        slide2 = Slide(
            id=str(uuid.uuid4()),
            order=1,
            layout_type=LayoutType.TITLE_BULLETS,
            content=SlideContent(
                title="健康指标", bullets=["体重指数（BMI）正常", "血压控制良好", "血糖水平稳定", "心肺功能良好"],
            ),
        )
        presentation.slides.append(slide2)

        slide3 = Slide(
            id=str(uuid.uuid4()),
            order=2,
            layout_type=LayoutType.TITLE_CONTENT,
            content=SlideContent(
                title="健康建议",
                body="保持健康的生活方式，均衡饮食，适度运动，定期体检，保持良好的心态，是维护身心健康的关键。",
            ),
        )
        presentation.slides.append(slide3)

        return presentation


# 单例实例
_demo_manager_instance: Optional[DemoManager] = None


def get_demo_manager() -> DemoManager:
    """获取示例管理器单例"""
    global _demo_manager_instance
    if _demo_manager_instance is None:
        _demo_manager_instance = DemoManager()
    return _demo_manager_instance
