"""
主题预览和演示示例生成工具
"""

import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

from ..models.models import LayoutType, Presentation, Slide, SlideContent
from ..models.presets import get_preset_themes
from ..models.storage import PresentationStorage
from ..ppt_generator import PPTGenerator


def create_theme_demo_presentation(theme_id: str) -> Presentation:
    """
    创建指定主题的演示文稿示例

    Args:
        theme_id: 主题ID

    Returns:
        演示文稿对象
    """
    theme = next((t for t in get_preset_themes() if t.id == theme_id), get_preset_themes()[0])

    presentation = Presentation(
        id=str(uuid.uuid4()),
        title=f"{theme.name} 主题演示",
        theme_id=theme_id,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )

    # 封面页 - 大标题
    slide1 = Slide(
        id=str(uuid.uuid4()),
        order=0,
        layout_type=LayoutType.BIG_TITLE,
        content=SlideContent(title=theme.name, subtitle=theme.description),
    )
    presentation.slides.append(slide1)

    # 主题介绍
    slide2 = Slide(
        id=str(uuid.uuid4()),
        order=1,
        layout_type=LayoutType.TITLE_CONTENT,
        content=SlideContent(
            title="主题概览",
            body=f"{theme.name} 主题是 PPT Maker 提供的专业主题之一。\n\n该主题具有精心设计的配色方案，适合各类演示场景。\n\n主题特色：\n- 主色调：{theme.colors.primary}\n- 次色调：{theme.colors.secondary}\n- 强调色：{theme.colors.accent}",
        ),
    )
    presentation.slides.append(slide2)

    # 要点列表页
    slide3 = Slide(
        id=str(uuid.uuid4()),
        order=2,
        layout_type=LayoutType.TITLE_BULLETS,
        content=SlideContent(
            title="核心功能",
            bullets=[
                "美观专业的配色方案",
                "响应式布局设计",
                "多种排版风格支持",
                "一键导出 PowerPoint",
                "JSON 格式数据持久化",
            ],
        ),
    )
    presentation.slides.append(slide3)

    # 内容+图标页
    slide4 = Slide(
        id=str(uuid.uuid4()),
        order=3,
        layout_type=LayoutType.TITLE_CONTENT_ICON,
        content=SlideContent(
            title="智能布局",
            body="PPT Maker 提供智能自动布局功能，根据内容自动选择最优布局。\n\n支持 8 种不同的布局模板，包括：\n- 仅标题\n- 标题+内容\n- 双列布局\n- 对比布局 等",
            icon="star",
        ),
    )
    presentation.slides.append(slide4)

    # 双列布局
    slide5 = Slide(
        id=str(uuid.uuid4()),
        order=4,
        layout_type=LayoutType.TWO_COLUMNS,
        content=SlideContent(
            title="主题配色",
            body="左侧展示主题设计理念，右侧展示色彩搭配。\n\n每个主题都经过精心设计，确保视觉层次分明、专业美观。",
            bullets=["主色：用于标题和重点", "次色：用于装饰和辅助", "强调色：用于突出关键", "背景色：提供舒适底色"],
        ),
    )
    presentation.slides.append(slide5)

    return presentation


def generate_all_theme_demos(output_dir: Optional[Path] = None) -> List[str]:
    """
    生成所有主题的演示文稿示例

    Args:
        output_dir: 输出目录

    Returns:
        生成的文件路径列表
    """
    if output_dir is None:
        output_dir = Path(__file__).parent / "themes"

    output_dir.mkdir(parents=True, exist_ok=True)

    generated_files = []

    for theme in get_preset_themes():
        # 创建演示文稿
        presentation = create_theme_demo_presentation(theme.id)

        # 保存 JSON
        json_path = output_dir / f"{theme.id}_demo.pptm.json"
        if PresentationStorage.save(presentation, json_path):
            generated_files.append(str(json_path))

        # 生成 PPTX
        pptx_path = output_dir / f"{theme.id}_demo.pptx"
        generator = PPTGenerator(presentation)
        if generator.generate(pptx_path):
            generated_files.append(str(pptx_path))

    return generated_files


if __name__ == "__main__":
    generate_all_theme_demos()
