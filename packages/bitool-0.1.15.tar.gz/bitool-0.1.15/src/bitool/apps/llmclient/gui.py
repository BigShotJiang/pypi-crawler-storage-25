"""LLM 聊天客户端应用。

提供与 LLM 服务器流式对话的图形界面客户端。
支持实时流式响应显示、连接测试和参数调整。

注意：此模块已弃用，请使用 widgets.llmchat.LLMChat。
"""

from __future__ import annotations

import sys

from bitool.gui.compat import QApplication

from .widgets.llmchat import LLMChat


def main() -> None:
    """应用程序入口点。"""
    app = QApplication(sys.argv)

    window = LLMChat()
    window.show()

    sys.exit(app.exec_())
