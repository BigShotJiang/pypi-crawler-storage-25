"""Connect module for threads."""

from __future__ import annotations

from urllib.error import URLError
from urllib.request import Request

from bitool.core import logger, urlopen_safe, validate_url
from bitool.gui.compat import QThread, Signal

from ..conf import conf


class ConnectionTestWorker(QThread):
    """Server connection test worker thread.

    Tests whether the LLM server's health check endpoint is accessible in background thread.

    Signals:
        result_ready: Emitted when test completes, passes (success_flag, message_text)
    """

    result_ready = Signal(bool, str)

    def __init__(self, server_url: str) -> None:
        """初始化连接测试工作线程。

        参数:
            server_url: LLM 服务器地址
        """
        super().__init__()
        self.server_url = server_url

    def run(self) -> None:
        """通过访问服务器健康检查端点执行连接测试。

        尝试在超时时间内连接到服务器的 /health 端点。
        触发 result_ready 信号并传递成功状态和描述性消息。

        安全验证：在发起请求前验证 URL 方案以防止 SSRF 攻击。
        """
        try:
            if not validate_url(self.server_url):
                self.result_ready.emit(False, "无效的 URL 方案：仅允许 http/https")
                return

            request = Request(f"{self.server_url}/health")  # noqa: S310

            with urlopen_safe(request, timeout=conf.CONNECTION_TIMEOUT) as url_response:
                if url_response.status == 200:
                    self.result_ready.emit(True, "连接成功!")
                else:
                    self.result_ready.emit(False, f"连接失败: {url_response.status}")
        except URLError as e:
            logger.exception(f"连接错误: {e.reason}")
            self.result_ready.emit(False, f"连接错误: {e.reason}")
        except (OSError, RuntimeError):
            logger.exception("请求错误")
            self.result_ready.emit(False, "请求错误")
