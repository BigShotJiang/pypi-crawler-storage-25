"""LLM 线程模块。"""

from __future__ import annotations

import json
from codecs import IncrementalDecoder, getincrementaldecoder
from typing import TYPE_CHECKING, Iterable
from urllib.error import URLError
from urllib.request import Request

from bitool.core import logger, urlopen_safe, validate_url
from bitool.gui.compat import QThread, Signal

if TYPE_CHECKING:
    from ..widgets.llmchat import LLMRequestConfig


class LLMWorker(QThread):
    """LLM server communication worker thread.

    Handles HTTP streaming requests in background thread to avoid blocking UI main thread.
    Uses incremental UTF-8 decoder to correctly handle multi-byte characters across lines,
    preventing garbled text from truncated multi-byte characters.

    Signals:
        response_received: Emitted when response content is received, carries response text
        error_occurred: Emitted when error occurs, carries error message
        is_finished: Emitted when request completes
    """

    response_received = Signal(str)
    error_occurred = Signal(str)
    is_finished = Signal()

    def __init__(self, config: LLMRequestConfig) -> None:
        """初始化 LLM 工作线程。

        参数:
            config: 包含所有参数的 LLM 请求配置
        """
        super().__init__()
        self.prompt = config.prompt
        self.server_url = config.server_url
        self.max_tokens = config.max_tokens
        self.temperature = config.temperature
        self.top_p = config.top_p
        self.top_k = config.top_k
        self._is_running = True

    def _process_streaming_line(
        self, line: bytes, decoder: IncrementalDecoder, buffer: str
    ) -> tuple[str, bool]:
        """Process a single streaming response line.

        Args:
            line: Raw line bytes from response
            decoder: Incremental UTF-8 decoder object
            buffer: Current content buffer

        Returns
        -------
            Tuple of (updated_buffer, should_continue)
        """
        try:
            decoded_line = decoder.decode(line, final=False).strip()
            if not decoded_line:
                return buffer, True

            if decoded_line.startswith("data: "):
                json_str = decoded_line[6:]
                try:
                    json_data = json.loads(json_str)
                    content = json_data.get("content", "")
                    if content:
                        buffer += content
                        self.response_received.emit(buffer)
                except json.JSONDecodeError as e:
                    logger.debug(f"JSON parsing failed: {json_str}, error: {e}")
        except (UnicodeDecodeError, AttributeError) as e:
            logger.debug(f"Line processing failed: {e}")

        return buffer, True

    def _handle_streaming_response(self, response: Iterable[bytes]) -> None:
        """处理流式响应内容。

        参数:
            response: 包含流式内容的 HTTP 响应对象
        """
        decoder = getincrementaldecoder("utf-8")(errors="replace")
        buffer = ""

        for line in response:
            if not self._is_running:
                break

            if line:
                buffer, _ = self._process_streaming_line(line, decoder, buffer)

        decoder.decode(b"", final=True)

    def run(self) -> None:
        """执行流式 HTTP 请求并处理响应。

        使用 Server-Sent Events (SSE) 格式接收流式响应。
        使用增量 UTF-8 解码器避免截断多字节字符导致的乱码，
        确保全链字符编码一致性（请求/响应均使用 UTF-8）。

        安全验证：在发起请求前验证 URL 方案以防止 SSRF 攻击。
        """
        try:
            if not validate_url(self.server_url):
                self.error_occurred.emit("无效的 URL 方案：仅允许 http/https")
                return

            headers = {"Content-Type": "application/json; charset=utf-8"}
            data = {
                "prompt": self.prompt,
                "max_tokens": self.max_tokens,
                "temperature": self.temperature,
                "top_p": self.top_p,
                "top_k": self.top_k,
                "stream": True,
            }

            request = Request(  # noqa: S310
                f"{self.server_url}/completion",
                data=json.dumps(data, ensure_ascii=False).encode("utf-8"),
                headers=headers,
            )

            with urlopen_safe(request) as url_response:
                if not url_response.success or url_response.response is None:
                    self.error_occurred.emit(f"错误: {url_response.status} - 请求失败")
                    return

                if url_response.status != 200:
                    error_text = url_response.response.read().decode("utf-8")
                    self.error_occurred.emit(
                        f"错误: {url_response.status} - {error_text}"
                    )
                    return

                self._handle_streaming_response(url_response.response)

        except URLError as e:
            logger.exception(f"连接错误: {e.reason}")
            self.error_occurred.emit(f"连接错误: {e.reason}")
        except (OSError, RuntimeError):
            logger.exception("请求错误")
            self.error_occurred.emit("请求错误")
        finally:
            self.is_finished.emit()

    def stop(self) -> None:
        """Stop worker thread execution gracefully.

        Sets the internal flag to signal the worker thread to terminate its
        ongoing operations. The thread will complete its current iteration
        and exit cleanly.
        """
        self._is_running = False
