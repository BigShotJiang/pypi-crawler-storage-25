"""LLM 客户端配置模块。"""

from __future__ import annotations

from bitool.core import JsonConfig


class LLMClientConfig(JsonConfig):
    """LLM 聊天客户端配置，支持持久化存储。"""

    TITLE: str = "LLM 聊天客户端 v1.0"
    WIN_SIZE: list[int] = [900, 700]
    WIN_POS: list[int] = [100, 100]
    SERVER_URL: str = "http://localhost:8080"
    CONNECTION_TIMEOUT = 5
    MAX_TOKENS: int = 256
    TEMPERATURE: float = 0.7
    TOP_P: float = 0.9
    TOP_K: int = 40
    MAX_TOKENS_RANGE: list[int] = [1, 4096]
    TEMPERATURE_RANGE: list[float] = [0.0, 2.0]
    TOP_P_RANGE: list[float] = [0.0, 1.0]
    TOP_K_RANGE: list[int] = [1, 100]


conf = LLMClientConfig()
