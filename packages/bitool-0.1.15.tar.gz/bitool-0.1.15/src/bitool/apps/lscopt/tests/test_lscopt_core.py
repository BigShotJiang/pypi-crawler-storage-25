"""LSC优化器核心算法的测试。"""

from __future__ import annotations

import numpy as np
import pytest
from scipy.optimize import OptimizeResult

from ..cli import LSCCurve, LSCOptimizer


class TestLSCCurve:
    """LSCCurve类实现最小二乘曲线优化的测试。

    测试涵盖初始化、数学计算、约束处理和边界情况鲁棒性。
    """

    def test_curve_initialization(self) -> None:
        """测试LSCCurve使用默认值的初始化。"""
        curve = LSCCurve()

        assert curve.m == pytest.approx(-1.3)
        assert curve.m1 == pytest.approx(-2.4)
        assert curve.s == pytest.approx(1.2183)
        assert pytest.approx(0.5) == curve.H
        assert pytest.approx(80.0) == curve.J

        assert isinstance(curve.n, float)
        assert isinstance(curve.t, float)
        assert curve.n > 0
        assert curve.t > 0

    def test_curve_with_custom_parameters(self) -> None:
        """测试使用自定义参数值的LSCCurve。"""
        curve = LSCCurve(m=-2.0, m1=-3.0, s=2.0, H=1.0, J=90.0)

        assert curve.m == pytest.approx(-2.0)
        assert curve.m1 == pytest.approx(-3.0)
        assert curve.s == pytest.approx(2.0)
        assert pytest.approx(1.0) == curve.H
        assert pytest.approx(90.0) == curve.J

    def test_cached_properties_computation(self) -> None:
        """测试缓存属性是否正确计算。"""
        curve = LSCCurve()

        assert curve.ms == curve.m**2
        assert curve.mc == curve.m**3
        assert curve.ms4 == curve.m**4
        assert curve.m1s == curve.m1**2
        assert curve.m1c == curve.m1**3
        assert curve.m1s4 == curve.m1**4

        expected_n = 1 / np.tan(np.radians(curve.J))
        expected_t = 1 / np.tan(np.radians(curve.J1))
        assert abs(curve.n - expected_n) < 1e-10
        assert abs(curve.t - expected_t) < 1e-10

    def test_matrix_dimensions(self) -> None:
        """测试约束矩阵是否具有正确的维度。"""
        curve = LSCCurve()

        assert curve.C.shape == (8, 16)

        assert curve.d.shape == (8,)
        assert curve.A_ineq.shape[1] == 16
        assert curve.A_eq.shape[1] == 16
        assert len(curve.b_ineq) == curve.A_ineq.shape[0]
        assert len(curve.b_eq) == curve.A_eq.shape[0]

    def test_solution_computation(self) -> None:
        """测试优化问题是否可以求解。"""
        curve = LSCCurve()

        assert isinstance(curve.R, OptimizeResult)
        assert hasattr(curve.R, "x")
        assert hasattr(curve.R, "cost")

        assert isinstance(curve.x, np.ndarray)
        assert len(curve.x) == 16

        assert curve.R.cost >= 0
        assert not np.isnan(curve.R.cost)
        assert not np.isinf(curve.R.cost)

    def test_plot_method_exists(self) -> None:
        """测试plot方法是否存在且可以调用。"""
        curve = LSCCurve()

        try:
            curve.plot()
        except (ImportError, ModuleNotFoundError, RuntimeError) as e:
            if "matplotlib" not in str(e).lower():
                raise

    def test_edge_cases(self) -> None:
        """测试边界情况和边界条件。

        测试各种极端参数组合和边界条件，
        以确保算法的鲁棒性。
        """
        curve = LSCCurve(J=90.0, J1=90.0)
        assert abs(curve.n) < 1e-15
        assert abs(curve.t) < 1e-15

        curve_extreme = LSCCurve(m=-10.0, m1=-20.0, s=100.0, H=10.0)
        result = curve_extreme.R
        assert isinstance(result, OptimizeResult)

        curve_negative = LSCCurve(H=-0.1, H1=-0.05, H2=-0.15)
        result_negative = curve_negative.R
        assert isinstance(result_negative, OptimizeResult)

        curve_small = LSCCurve(m=-0.001, m1=-0.002, s=0.001)
        result_small = curve_small.R
        assert isinstance(result_small, OptimizeResult)


class TestLSCOptimizer:
    """LSCOptimizer类提供高级优化接口的测试。

    测试涵盖初始化、参数处理、一致性和敏感性分析。
    """

    def test_optimizer_initialization(self) -> None:
        """测试LSCOptimizer初始化。"""
        optimizer = LSCOptimizer()
        assert optimizer is not None

    def test_optimize_method(self) -> None:
        """测试optimize方法。"""
        optimizer = LSCOptimizer()

        x, cost = optimizer.optimize()
        assert isinstance(x, np.ndarray)
        assert isinstance(cost, float)
        assert len(x) == 16
        assert cost >= 0
        assert not np.isnan(cost)

    def test_optimize_with_custom_params(self) -> None:
        """测试使用自定义参数进行优化。"""
        optimizer = LSCOptimizer()

        x, cost = optimizer.optimize(m=-2.0, H=1.0, s=2.0)

        assert isinstance(x, np.ndarray)
        assert isinstance(cost, float)
        assert len(x) == 16
        assert cost >= 0

    def test_consistency(self) -> None:
        """测试使用相同参数重复调用是否产生一致的结果。

        确保优化算法的确定性行为。
        """
        optimizer = LSCOptimizer()

        x1, cost1 = optimizer.optimize(m=-1.5, H=0.8)
        x2, cost2 = optimizer.optimize(m=-1.5, H=0.8)

        np.testing.assert_array_almost_equal(x1, x2)
        assert abs(cost1 - cost2) < 1e-10

    def test_parameter_sensitivity(self) -> None:
        """测试对参数变化的敏感性。

        验证更改参数会产生不同的结果。
        使用较大的参数差异以确保可测量的变化。
        """
        optimizer = LSCOptimizer()

        x_baseline, cost_baseline = optimizer.optimize(m=-1.3, H=0.5)

        x_modified, cost_modified = optimizer.optimize(m=-2.0, H=1.0)

        assert not np.allclose(x_baseline, x_modified, rtol=1e-2)
        cost_diff = abs(cost_baseline - cost_modified)
        assert cost_diff > 1e-10 or cost_diff < 1e-20


def test_import_star() -> None:
    """测试__all__导出是否正常工作。

    验证模块导出是否正确定义和可访问。
    """
    try:
        from bitool.apps.lscopt.cli import __version__

        assert isinstance(__version__, str)
        assert __version__
    except ImportError:
        pass


def test_version_format() -> None:
    """测试版本字符串是否符合语义版本格式。

    验证版本字符串格式是否正确。
    """
    from ..cli import __version__

    parts = __version__.split(".")
    assert len(parts) == 3
    assert all(part.isdigit() for part in parts)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
