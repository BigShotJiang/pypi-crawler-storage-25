"""LSC优化器GUI的测试。"""

from __future__ import annotations

import pytest
import pytestqt.qtbot

from ..gui import (
    LSCOptimizerGUI,
    ParameterWidget,
    PlotWidget,
    ResultDisplayWidget,
)


class TestParameterWidget:
    """ParameterWidget的测试。"""

    def test_parameter_widget_creation(self, qtbot: pytestqt.qtbot.QtBot) -> None:
        """测试创建参数组件。"""
        widget = ParameterWidget("test_param", "测试参数", 1.0, 0.0, 10.0, 0.1)
        qtbot.addWidget(widget)

        assert widget.name == "test_param"
        assert widget.label == "测试参数"
        assert widget.get_value() == pytest.approx(1.0)

    def test_parameter_widget_set_value(self, qtbot: pytestqt.qtbot.QtBot) -> None:
        """测试设置参数值。"""
        widget = ParameterWidget("test_param", "测试参数", 1.0, 0.0, 10.0, 0.1)
        qtbot.addWidget(widget)

        widget.set_value(5.5)
        assert widget.get_value() == pytest.approx(5.5)


class TestResultDisplayWidget:
    """ResultDisplayWidget的测试。"""

    def test_result_display_creation(self, qtbot: pytestqt.qtbot.QtBot) -> None:
        """测试创建结果显示组件。"""
        widget = ResultDisplayWidget()
        qtbot.addWidget(widget)

        ready_text = widget.result_text.text()
        assert "Ready to calculate" in ready_text or "准备计算" in ready_text

    def test_update_results(self, qtbot: pytestqt.qtbot.QtBot) -> None:
        """测试更新结果显示。"""
        widget = ResultDisplayWidget()
        qtbot.addWidget(widget)

        widget.update_results(2.5, 0.001)
        result_text = widget.result_text.text()
        assert "Calculation completed" in result_text or "计算完成" in result_text
        assert "2.5000" in result_text
        assert "0.001000" in result_text

    def test_show_error(self, qtbot: pytestqt.qtbot.QtBot) -> None:
        """测试显示错误消息。"""
        widget = ResultDisplayWidget()
        qtbot.addWidget(widget)

        widget.show_error("测试错误消息")
        error_text = widget.result_text.text()
        assert "Error: 测试错误消息" in error_text or "错误: 测试错误消息" in error_text


class TestPlotWidget:
    """PlotWidget的测试。"""

    def test_plot_widget_creation(self, qtbot: pytestqt.qtbot.QtBot) -> None:
        """测试创建绘图组件。"""
        widget = PlotWidget()
        qtbot.addWidget(widget)

        assert widget.ax is not None
        assert widget.canvas is not None

    def test_clear_plot(self, qtbot: pytestqt.qtbot.QtBot) -> None:
        """测试清除绘图。"""
        widget = PlotWidget()
        qtbot.addWidget(widget)

        widget.ax.plot([1, 2, 3], [1, 4, 2])
        widget.canvas.draw()

        widget.clear_plot()
        assert len(widget.ax.lines) == 0


class TestLSCOptimizerGUI:
    """LSCOptimizerGUI主窗口的测试。"""

    def setup_method(self) -> None:
        """设置方法以确保英语语言以进行一致的测试。"""
        from bitool.apps.lscopt.translation import Language, translator

        translator.set_language(Language.ENGLISH)

    def test_window_creation(self, qtbot: pytestqt.qtbot.QtBot) -> None:
        """测试是否可以创建主窗口。"""
        window = LSCOptimizerGUI()
        qtbot.addWidget(window)

        assert window.windowTitle() == "LSC Optimizer v0.1.0"
        assert window.minimumSize().width() == 1200
        assert window.minimumSize().height() == 700

    def test_parameter_widgets_exist(self, qtbot: pytestqt.qtbot.QtBot) -> None:
        """测试参数组件是否已创建。"""
        window = LSCOptimizerGUI()
        qtbot.addWidget(window)

        assert hasattr(window, "param_widgets")
        assert len(window.param_widgets) > 0

        assert "m" in window.param_widgets
        assert "H" in window.param_widgets
        assert "J" in window.param_widgets

    def test_calculate_button_exists(self, qtbot: pytestqt.qtbot.QtBot) -> None:
        """测试计算按钮是否存在。"""
        window = LSCOptimizerGUI()
        qtbot.addWidget(window)

        assert hasattr(window, "calculate_button")
        assert window.calculate_button.text() == "Calculate"

    def test_reset_button_exists(self, qtbot: pytestqt.qtbot.QtBot) -> None:
        """测试重置按钮是否存在。"""
        window = LSCOptimizerGUI()
        qtbot.addWidget(window)

        assert hasattr(window, "reset_button")
        assert window.reset_button.text() == "Reset to Defaults"

    def test_plot_widget_exists(self, qtbot: pytestqt.qtbot.QtBot) -> None:
        """测试绘图组件是否存在。"""
        window = LSCOptimizerGUI()
        qtbot.addWidget(window)

        assert hasattr(window, "plot_widget")
        assert hasattr(window.plot_widget, "ax")
