"""LSCCurve参数验证功能的测试。"""

from __future__ import annotations

import pytest
from _pytest.logging import LogCaptureFixture

from ..cli import LSCCurve


class TestLSCCurveValidation:
    """LSCCurve参数验证的测试。"""

    def test_valid_parameters(self) -> None:
        """测试有效参数是否正常工作。"""
        curve = LSCCurve()
        assert curve.m == pytest.approx(-1.3)
        assert curve.m1 == pytest.approx(-2.4)

    def test_invalid_angle_parameters(self) -> None:
        """测试角度参数的验证。"""
        with pytest.raises(ValueError, match="总角度J必须在0到180度之间"):
            LSCCurve(J=-10)

        with pytest.raises(ValueError, match="总角度J必须在0到180度之间"):
            LSCCurve(J=200)

        with pytest.raises(ValueError, match="内部角度J1必须在0到180度之间"):
            LSCCurve(J1=-5)

        with pytest.raises(ValueError, match="内部角度J1必须在0到180度之间"):
            LSCCurve(J1=190)

    def test_invalid_breakpoint_parameters(self) -> None:
        """测试断点参数的验证。"""
        with pytest.raises(ValueError, match="内部断点m必须为负数"):
            LSCCurve(m=1.0)

        with pytest.raises(ValueError, match="外部断点m1必须为负数"):
            LSCCurve(m1=0.5)

        with pytest.raises(ValueError, match="必须小于内部断点"):
            LSCCurve(m=-1.0, m1=-0.5)

    def test_warning_conditions(self, caplog: LogCaptureFixture) -> None:
        """测试警告条件是否产生适当的日志消息。"""
        import logging

        from ..cli import logger as lscopt_logger

        caplog.set_level(logging.WARNING)
        lscopt_logger.setLevel(logging.WARNING)
        lscopt_logger.addHandler(caplog.handler)

        LSCCurve(H=-0.1, H1=-0.05, H2=-0.15)
        assert "负的切削高度H=-0.1可能导致意外结果" in caplog.text
        assert "负的内部保留高度H1=-0.05可能导致意外结果" in caplog.text
        assert "负的外部保留高度H2=-0.15可能导致意外结果" in caplog.text

        caplog.clear()
        lscopt_logger.removeHandler(caplog.handler)
        lscopt_logger.addHandler(caplog.handler)
        LSCCurve(s=-1.0, s1=-2.0)
        assert "负的内部斜率s=-1.0可能导致意外结果" in caplog.text
        assert "负的外部斜率s1=-2.0可能导致意外结果" in caplog.text

    def test_boundary_conditions(self) -> None:
        """测试参数的边界条件。"""
        curve = LSCCurve(J=0, J1=0)
        assert curve.J == 0
        assert curve.J1 == 0

        curve = LSCCurve(J=180, J1=180)
        assert curve.J == 180
        assert curve.J1 == 180

        with pytest.raises(ValueError, match="内部断点m必须为负数"):
            LSCCurve(m=0)

        with pytest.raises(ValueError, match="外部断点m1必须为负数"):
            LSCCurve(m1=0)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
