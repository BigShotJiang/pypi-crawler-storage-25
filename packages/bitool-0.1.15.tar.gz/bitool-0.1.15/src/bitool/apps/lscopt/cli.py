"""Lscopt模块，用于LSC优化器。"""

from __future__ import annotations

from dataclasses import dataclass
from functools import cached_property

import numpy as np
from matplotlib import pyplot as plt
from scipy.optimize import OptimizeResult, lsq_linear

from bitool.core import logger

__version__ = "0.1.0"


@dataclass
class LSCCurve:
    """LSC曲线计算器，用于解决优化问题。

    此类实现了带有各种几何约束的最小二乘曲线拟合算法（LSC，最小二乘曲线）。
    提供全面的参数验证和错误处理。
    """

    def __post_init__(self) -> None:
        """后初始化验证和设置。"""
        self._validate_parameters()

    def _validate_parameters(self) -> None:
        """验证所有输入参数的正确性和可行性。

        抛出
        ------
            ValueError: 如果任何参数值无效或不一致
        """
        self._validate_angles()
        self._validate_breakpoints()
        self._validate_heights()
        self._validate_slopes()
        logger.debug(
            f"LSCCurve初始化参数: m={self.m}, m1={self.m1}, H={self.H}",
        )

    def _validate_angles(self) -> None:
        """验证角度参数J和J1。

        抛出
        ------
            ValueError: 如果角度值超出有效范围[0, 180]
        """
        if not 0 <= self.J <= 180:
            msg = f"总角度J必须在0到180度之间，实际为{self.J}"
            raise ValueError(msg)
        if not 0 <= self.J1 <= 180:
            msg = f"内部角度J1必须在0到180度之间，实际为{self.J1}"
            raise ValueError(msg)

    def _validate_breakpoints(self) -> None:
        """验证断点参数m和m1。

        抛出
        ------
            ValueError: 如果断点值为非负数或顺序错误
        """
        if self.m >= 0:
            msg = f"内部断点m必须为负数，实际为{self.m}"
            raise ValueError(msg)
        if self.m1 >= 0:
            msg = f"外部断点m1必须为负数，实际为{self.m1}"
            raise ValueError(msg)
        if self.m1 >= self.m:
            msg = f"外部断点m1({self.m1})必须小于内部断点m({self.m})"
            raise ValueError(msg)

    def _validate_heights(self) -> None:
        """验证高度参数H、H1和H2。

        记录可能产生意外结果的负值的警告。
        """
        if self.H < 0:
            logger.warning(f"负的切削高度H={self.H}可能导致意外结果")
        if self.H1 < 0:
            logger.warning(
                f"负的内部保留高度H1={self.H1}可能导致意外结果",
            )
        if self.H2 < 0:
            logger.warning(
                f"负的外部保留高度H2={self.H2}可能导致意外结果",
            )

    def _validate_slopes(self) -> None:
        """验证斜率参数s和s1。

        记录可能产生意外结果的负值的警告。
        """
        if self.s < 0:
            logger.warning(f"负的内部斜率s={self.s}可能导致意外结果")
        if self.s1 < 0:
            logger.warning(
                f"负的外部斜率s1={self.s1}可能导致意外结果",
            )

    # 基础参数设置
    m: float = -1.3  # 内部断点
    m1: float = -2.4  # 外部断点
    s: float = 1.2183  # 内部斜率
    s1: float = 8.1  # 外部斜率
    H: float = 0.5  # 切削高度
    m2: float = 0.5  # 特定点
    H1: float = 0.2  # 内部保留高度
    H2: float = 0.65  # 外部保留高度
    J: float = 80  # 总角度
    J1: float = 40  # 断点角度

    @staticmethod
    def _cot(x: float) -> float:
        """计算余切函数。

        参数
        ----
            x: 弧度单位的输入参数

        返回
        -------
            float: 余切值
        """
        return 1 / np.tan(x)

    @cached_property
    def n(self) -> float:
        """计算cot(J)，其中J为总角度。"""
        return self._cot(np.radians(self.J))

    @cached_property
    def t(self) -> float:
        """计算cot(J1)，其中J1为内部角度。"""
        return self._cot(np.radians(self.J1))

    @cached_property
    def ms(self) -> float:
        """计算m的平方（第一个断点）。"""
        return self.m**2

    @cached_property
    def mc(self) -> float:
        """计算m的立方（第一个断点）。"""
        return self.m**3

    @cached_property
    def ms4(self) -> float:
        """计算m的四次方（第一个断点）。"""
        return self.m**4

    @cached_property
    def m1s(self) -> float:
        """计算m1的平方（第二个断点）。"""
        return self.m1**2

    @cached_property
    def m1c(self) -> float:
        """计算m1的立方（第二个断点）。"""
        return self.m1**3

    @cached_property
    def m1s4(self) -> float:
        """计算m1的四次方（第二个断点）。"""
        return self.m1**4

    @cached_property
    def m2s(self) -> float:
        """计算m2的平方（特定点）。"""
        return self.m2**2

    @cached_property
    def m2c(self) -> float:
        """计算m2的立方（特定点）。"""
        return self.m2**3

    @cached_property
    def m2s4(self) -> float:
        """计算m2的四次方（特定点）。"""
        return self.m2**4

    @cached_property
    def C(self) -> np.ndarray:
        """计算约束矩阵C。

        返回
        -------
            np.ndarray: 约束矩阵C (8x16)
        """
        return np.array(
            [
                [1, self.m, self.ms, self.mc, -1, -self.m, -self.ms, -self.mc, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, self.m, self.ms, self.mc, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, self.m, self.ms, self.mc, 0, 0, 0, 0, 0, 0, 0, 0],
                [
                    self.m,
                    self.ms / 2,
                    self.mc / 3,
                    self.ms4 / 4,
                    -self.m,
                    -self.ms / 2,
                    -self.mc / 3,
                    -self.ms4 / 4,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                ],
                [0, 0, 0, 0, 0, 0, 0, 0, 1, self.m1, self.m1s, self.m1c, -1, -self.m1, -self.m1s, -self.m1c],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, self.m1, self.m1s, self.m1c, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, self.m1, self.m1s, self.m1c],
                [
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    self.m1,
                    self.m1s / 2,
                    self.m1c / 3,
                    self.m1s4 / 4,
                    -self.m1,
                    -self.m1s / 2,
                    -self.m1c / 3,
                    -self.m1s4 / 4,
                ],
            ],
        )

    @cached_property
    def i(self) -> np.ndarray:
        """计算内部段的线性空间向量i。"""
        return np.linspace(self.m, 0, 100)

    @cached_property
    def j(self) -> np.ndarray:
        """计算外部段的线性空间向量j。"""
        return np.linspace(self.m1, 0, 100)

    @cached_property
    def d(self) -> np.ndarray:
        """计算优化的目标向量d。"""
        return np.array(
            [
                0,
                self.n * self.m,
                self.t * self.m,
                self.s / 2,
                0,
                self.n * self.m1,
                self.t * self.m1,
                self.s1 / 2,
            ],
        )

    @cached_property
    def A_ineq(self) -> np.ndarray:
        """计算不等式约束矩阵A_ineq。

        构造矩阵A和向量b以将等式约束转换为边界约束，
        因为lsq_linear不直接支持等式约束。对于等式Ax = b，
        构造两个不等式约束：Ax <= b和-Ax <= -b
        """
        return np.array(
            [
                [0, 1, 2 * self.m, 3 * self.ms, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, -1, -2 * self.m, -3 * self.ms, 0, 0, 0, 0, 0, 0, 0, 0],
                [1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2 * self.m1, 3 * self.m1s, 0, 0, 0, 0],
                [
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    -1,
                    -2 * self.m1,
                    -3 * self.m1s,
                ],
                [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, -1, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0],
                [1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            ],
        )

    @cached_property
    def b_ineq(self) -> np.ndarray:
        """计算不等式约束向量b_ineq。"""
        return np.array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -self.H])

    @cached_property
    def A_eq(self) -> np.ndarray:
        """计算等式约束矩阵A_eq。"""
        return np.array(
            [
                [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0],
                [1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0],
                [
                    1,
                    self.m2,
                    self.m2s,
                    self.m2c,
                    0,
                    0,
                    0,
                    0,
                    -1,
                    -self.m2,
                    -self.m2s,
                    -self.m2c,
                    0,
                    0,
                    0,
                    0,
                ],
                [0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
                [
                    0,
                    0,
                    0,
                    0,
                    -1,
                    -self.m2,
                    -self.m2s,
                    -self.m2c,
                    0,
                    0,
                    0,
                    0,
                    1,
                    self.m2,
                    self.m2s,
                    self.m2c,
                ],
                [
                    1,
                    self.m,
                    self.ms,
                    self.mc,
                    -1,
                    -self.m,
                    -self.ms,
                    -self.mc,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                ],
                [
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    1,
                    self.m1,
                    self.m1s,
                    self.m1c,
                    -1,
                    -self.m1,
                    -self.m1s,
                    -self.m1c,
                ],
                [
                    self.m,
                    self.ms / 2,
                    self.mc / 3,
                    self.ms4 / 4,
                    -self.m,
                    -self.ms / 2,
                    -self.mc / 3,
                    -self.ms4 / 4,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                ],
            ],
        )

    @cached_property
    def b_eq(self) -> np.ndarray:
        """计算等式约束向量b_eq。"""
        return np.array([0, 0, 0, 0, self.H1, self.H1, self.H2, self.H2, 0, 0, self.s / 2])

    @cached_property
    def R(self) -> OptimizeResult:
        """使用最小二乘法计算优化结果。

        返回
        -------
            OptimizeResult: 包含解向量x的优化结果
        """
        np.vstack([self.A_ineq, self.A_eq, -self.A_eq])
        np.hstack([self.b_ineq, self.b_eq, -self.b_eq])

        return lsq_linear(
            self.C,
            self.d,
            bounds=(-np.inf, np.inf),
            lsmr_tol="auto",
            verbose=0,
        )

    @cached_property
    def x(self) -> np.ndarray:
        """从优化结果计算解向量x。"""
        return self.R.x

    def calculate_angles(self) -> tuple[float, float, float, float]:
        """计算特定点的角度。

        返回
        -------
            tuple[float, float, float, float]: m和m1点处的角度
                (angle_m_upper, angle_m_lower, angle_m1_upper, angle_m1_lower)
                单位为度
        """
        try:
            y3 = self.x[0] + self.x[1] * self.m + self.x[2] * self.ms + self.x[3] * self.mc
            angle_m_upper = np.degrees(np.arctan2((y3 - self.x[0]), self.m))
            angle_m_lower = np.degrees(np.arctan2((y3 - self.x[4]), self.m))

            g3 = self.x[8] + self.x[9] * self.m1 + self.x[10] * self.m1s + self.x[11] * self.m1c
            angle_m1_upper = np.degrees(np.arctan2((g3 - self.x[8]), self.m1))
            angle_m1_lower = np.degrees(np.arctan2((g3 - self.x[12]), self.m1))

            logger.debug(
                f"计算角度: m_upper={angle_m_upper:.2f}°, "
                f"m_lower={angle_m_lower:.2f}°, m1_upper={angle_m1_upper:.2f}°, m1_lower={angle_m1_lower:.2f}°",
            )
        except (ValueError, RuntimeError, OSError) as e:
            logger.exception("计算角度时出错")
            msg = f"计算角度失败: {e}"
            raise RuntimeError(msg) from e
        else:
            return angle_m_upper, angle_m_lower, angle_m1_upper, angle_m1_lower

    def plot(self, ax: plt.Axes | None = None) -> plt.Axes:
        """使用matplotlib绘制LSC曲线。

        参数
        ----
            ax: 可选的matplotlib坐标轴对象。如果为None，则创建新图形。

        返回
        -------
            plt.Axes: 包含绘图的坐标轴对象

        抛出
        ------
            RuntimeError: 如果绘图因matplotlib问题失败
        """
        try:
            y1 = self.x[0] + self.x[1] * self.i + self.x[2] * self.i**2 + self.x[3] * self.i**3
            y2 = self.x[4] + self.x[5] * self.i + self.x[6] * self.i**2 + self.x[7] * self.i**3

            g1 = self.x[8] + self.x[9] * self.j + self.x[10] * self.j**2 + self.x[11] * self.j**3
            g2 = self.x[12] + self.x[13] * self.j + self.x[14] * self.j**2 + self.x[15] * self.j**3

            if not ax:
                fig = plt.figure(figsize=(12, 8))
                ax = fig.add_subplot(111)

            ax.clear()

            ax.plot(self.i, y1, "b-", linewidth=2, label="内部上")
            ax.plot(self.i, y2, "r-", linewidth=2, label="内部下")
            ax.plot(self.j, g1, "g-", linewidth=2, label="外部上")
            ax.plot(self.j, g2, "m-", linewidth=2, label="外部下")

            ax.plot(
                self.m,
                self.x[0] + self.x[1] * self.m + self.x[2] * self.ms + self.x[3] * self.mc,
                "bo",
                markersize=8,
                label=f"内部点({self.m}, y1)",
            )
            ax.plot(
                self.m1,
                self.x[8] + self.x[9] * self.m1 + self.x[10] * self.m1s + self.x[11] * self.m1c,
                "gs",
                markersize=8,
                label=f"外部点({self.m1}, g1)",
            )

            ax.set_xlabel("X", fontfamily="sans-serif", fontsize=12)
            ax.set_ylabel("Y", fontfamily="sans-serif", fontsize=12)
            ax.legend()
            ax.grid(visible=True, alpha=0.3)
            ax.axis("equal")
        except (ValueError, RuntimeError, OSError) as e:
            logger.exception("创建绘图时出错")
            msg = f"创建绘图失败: {e}"
            raise RuntimeError(msg) from e
        else:
            logger.debug("LSC曲线绘图创建成功")
            return ax


class LSCOptimizer:
    """LSC优化的主类。

    提供LSC曲线优化的高级接口，
    具有可配置参数、全面错误处理和日志支持。
    """

    def __init__(self) -> None:
        """初始化LSC优化器实例。"""

    def optimize(self, **kwargs: float) -> tuple[np.ndarray, float]:
        """使用给定参数执行LSC优化。

        参数
        ----
            **kwargs: LSC曲线参数，包括m、m1、s、s1、H、m2、H1、H2、J、J1

        返回
        -------
            tuple[np.ndarray, float]: 包含(解向量, 残差成本)的元组
                - solution_vector: 16元素的多项式系数数组
                - residual_cost: 优化残差/误差值

        抛出
        ------
            ValueError: 如果输入参数无效
            RuntimeError: 如果优化失败
        """
        try:
            logger.info(f"开始LSC优化，参数: {kwargs}")
            lscc = LSCCurve(**kwargs)
            solution_vector = lscc.x
            residual_cost = lscc.R.cost
        except ValueError:
            logger.exception("提供了无效参数")
            raise
        except (OSError, RuntimeError) as e:
            logger.exception("优化失败")
            msg = "LSC优化失败"
            raise RuntimeError(msg) from e
        else:
            logger.info(f"优化完成。残差成本: {residual_cost:.6f}")
            return solution_vector, residual_cost
