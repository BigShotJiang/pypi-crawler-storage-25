"""PySide2 GUI版本的LSC优化器应用。"""

from __future__ import annotations

import sys

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from bitool.core import JsonConfig, logger
from bitool.gui import apply_theme
from bitool.gui.compat import (
    QApplication,
    QDoubleSpinBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QKeyEvent,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    Qt,
    QTimer,
    QVBoxLayout,
    QWidget,
)

from .cli import LSCCurve
from .translation import translator

plt.rcParams["axes.unicode_minus"] = False


class LSCOptimizerConfig(JsonConfig):
    """LSC优化器GUI配置类，支持持久化存储。

    管理GUI设置，包括窗口几何形状和默认参数值。
    配置自动保存到~/.pytola/lscopt.json
    """

    window_width: int = 1200
    window_height: int = 800
    window_x: int = 100
    window_y: int = 100

    m: float = -1.3
    m1: float = -2.4
    s: float = 1.2183
    s1: float = 8.1
    H: float = 0.5
    m2: float = 0.5
    H1: float = 0.2
    H2: float = 0.65
    J: float = 80.0
    J1: float = 40.0


conf = LSCOptimizerConfig()


class ParameterWidget(QWidget):
    """使用双精度旋钮框的数值参数输入组件。

    提供带标签的浮点参数输入控件，支持可配置的范围和步长。
    """

    def __init__(
        self,
        name: str,
        label: str,
        default_value: float,
        min_val: float,
        max_val: float,
        step: float,
        parent: QWidget | None = None,
    ) -> None:
        """初始化参数输入组件。

        参数
        ----
            name: 内部参数名称
            label: 参数的显示标签
            default_value: 初始/默认值
            min_val: 允许的最小值
            max_val: 允许的最大值
            step: 递增/递减的步长
            parent: 父组件
        """
        super().__init__(parent)
        self.name = name
        self.label = label
        self.default_value = default_value

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.label_widget = QLabel(label)
        self.label_widget.setMinimumWidth(160)
        self.label_widget.setMaximumWidth(220)
        self.label_widget.setStyleSheet("font-size: 18px;")
        layout.addWidget(self.label_widget)

        self.spinbox = QDoubleSpinBox()
        self.spinbox.setRange(min_val, max_val)
        self.spinbox.setValue(default_value)
        self.spinbox.setSingleStep(step)
        self.spinbox.setDecimals(4 if abs(step) < 1 else 2)
        self.spinbox.setMinimumWidth(150)
        self.spinbox.setMinimumHeight(36)
        self.spinbox.setButtonSymbols(QDoubleSpinBox.UpDownArrows)
        layout.addWidget(self.spinbox)

        spacer = QWidget()
        spacer.setMinimumWidth(25)
        spacer.setMaximumWidth(50)
        layout.addWidget(spacer)

    def get_value(self) -> float:
        """从旋钮框获取当前值。

        返回
        -------
            float: 当前参数值
        """
        return self.spinbox.value()

    def set_value(self, value: float) -> None:
        """设置旋钮框中的参数值。

        参数
        ----
            value: 要设置的新值
        """
        self.spinbox.setValue(value)


class PlotWidget(QWidget):
    """matplotlib绘图的组件包装器。

    集成matplotlib画布用于LSC曲线可视化。
    """

    def __init__(self, parent: QWidget | None = None) -> None:
        """初始化matplotlib绘图组件。

        参数
        ----
            parent: 父组件
        """
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(5)

        self.setMinimumSize(480, 480)

        self.figure = Figure(figsize=(10, 7), tight_layout=True)
        self.canvas = FigureCanvas(self.figure)
        self.canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        layout.addWidget(self.canvas)

        self.ax = self.figure.add_subplot(111)

    def clear_plot(self) -> None:
        """清除当前绘图。"""
        self.ax.clear()
        self.canvas.draw()

    def update_plot(self, lscc: LSCCurve) -> None:
        """使用新的LSC曲线数据更新绘图。

        参数
        ----
            lscc: 包含要绘制的曲线数据的LSCCurve实例
        """
        self.ax.clear()

        i = np.linspace(lscc.m, 0, 100)
        j = np.linspace(lscc.m1, 0, 100)

        y1 = lscc.x[0] + lscc.x[1] * i + lscc.x[2] * i**2 + lscc.x[3] * i**3
        y2 = lscc.x[4] + lscc.x[5] * i + lscc.x[6] * i**2 + lscc.x[7] * i**3

        g1 = lscc.x[8] + lscc.x[9] * j + lscc.x[10] * j**2 + lscc.x[11] * j**3
        g2 = lscc.x[12] + lscc.x[13] * j + lscc.x[14] * j**2 + lscc.x[15] * j**3

        self.ax.plot(i, y1, label="内部上")
        self.ax.plot(i, y2, label="内部下")
        self.ax.plot(j, g1, label="外部上")
        self.ax.plot(j, g2, label="外部下")

        y3_point = lscc.x[0] + lscc.x[1] * lscc.m + lscc.x[2] * lscc.ms + lscc.x[3] * lscc.mc
        g3_point = lscc.x[8] + lscc.x[9] * lscc.m1 + lscc.x[10] * lscc.m1s + lscc.x[11] * lscc.m1c

        self.ax.plot(
            lscc.m,
            y3_point,
            marker="o",
            markersize=8,
            label=f"内部 ({lscc.m:.1f}, {y3_point:.2f})",
        )
        self.ax.plot(
            lscc.m1,
            g3_point,
            marker="s",
            markersize=8,
            label=f"外部 ({lscc.m1:.1f}, {g3_point:.2f})",
        )

        self.ax.set_xlabel("X")
        self.ax.set_ylabel("Y")
        self.ax.set_title("LSC曲线优化结果")
        self.ax.legend(loc="best")
        self.ax.grid(True)
        self.ax.axis("equal")

        self.canvas.draw()


class ResultDisplayWidget(QWidget):
    """用于显示LSC优化计算结果的增强组件。

    以现代样式显示优化结果，包括解向量范数和残差成本。
    """

    def __init__(self, parent: QWidget | None = None) -> None:
        """使用现代样式初始化增强的结果显示组件。

        设置具有现代视觉层次、一致间距和响应式设计元素的布局。

        参数
        ----
            parent: 父组件
        """
        super().__init__(parent)
        layout = QVBoxLayout(self)

        title_label = QLabel(translator.tr("results_panel"))
        layout.addWidget(title_label)

        self.result_text = QLabel(translator.tr("ready_text"))
        self.result_text.setWordWrap(True)
        self.result_text.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.result_text.setObjectName("resultContent")
        layout.addWidget(self.result_text)

    def update_results(self, norm: float, cost: float) -> None:
        """使用增强格式更新显示新的计算结果。

        参数
        ----
            norm: 解向量范数值
            cost: 优化残差成本
        """
        formatted_text = (
            f"{translator.tr('calculation_success')}\n\n"
            f"{translator.tr('solution_norm')}: {norm:.4f}\n"
            f"{translator.tr('optimization_residual')}: {cost:.6f}"
        )
        self.result_text.setText(formatted_text)

    def show_error(self, message: str) -> None:
        """使用适当的样式显示错误消息。

        参数
        ----
            message: 要显示的错误消息
        """
        self.result_text.setText(f"{translator.tr('error_prefix')}{message}")
        self.result_text.setStyleSheet(
            "background-color: #ffebee; color: #c62828; padding: 10px;",
        )


class LSCOptimizerGUI(QMainWindow):
    """LSC优化器应用的主GUI窗口。

    提供完整的LSC曲线优化图形界面，包括参数输入、实时绘图和结果展示。
    支持持久化配置和键盘快捷键。
    """

    def __init__(self) -> None:
        """初始化GUI组件并设置应用状态。

        创建配置管理器、加载设置、初始化UI，并设置信号连接。
        """
        super().__init__()
        self.lscc: LSCCurve | None = None
        self.auto_calc_timer = None
        self.setup_chinese_font()
        self.init_ui()
        self.load_settings()
        self.setup_connections()

    def setup_chinese_font(self) -> bool:
        """配置 matplotlib 中文字体。"""
        from matplotlib import font_manager

        windows_fonts = ["SimHei", "Microsoft YaHei", "SimSun", "Arial Unicode MS"]
        mac_fonts = ["Arial Unicode MS", "PingFang SC", "Heiti TC"]
        linux_fonts = ["WenQuanYi Micro Hei", "Noto Sans CJK SC", "Noto Sans SC"]

        all_chinese_fonts = windows_fonts + mac_fonts + linux_fonts
        available_font_names = {f.name for f in font_manager.fontManager.ttflist}

        for font_name in all_chinese_fonts:
            if font_name in available_font_names:
                plt.rcParams["font.sans-serif"] = [font_name, "DejaVu Sans"]
                logger.debug(f"使用中文字体: {font_name}")
                return True

        plt.rcParams["font.sans-serif"] = ["DejaVu Sans"]
        logger.warning("未找到中文字体, 使用系统默认字体")
        return False

    def init_ui(self) -> None:
        """使用现代样式初始化和设置完整的用户界面。

        创建主窗口布局，左侧为参数输入面板，右侧为结果/绘图面板。
        应用统一的现代配色方案、排版和视觉层次。
        """
        self.setWindowTitle(translator.tr("window_title"))
        self.setMinimumSize(1200, 700)

        self.create_menu_bar()

        self.create_status_bar()

        central_widget = QWidget()
        central_widget.setObjectName("centralWidget")
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout(central_widget)
        main_layout.setSpacing(15)
        main_layout.setContentsMargins(20, 20, 20, 20)

        left_panel = QGroupBox(translator.tr("parameters_panel"))
        left_panel.setObjectName("parameterPanel")
        left_layout = QVBoxLayout(left_panel)
        left_layout.setSpacing(12)
        left_layout.setContentsMargins(16, 16, 16, 16)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setObjectName("parameterScrollArea")

        scroll_widget = QWidget()
        scroll_widget.setObjectName("scrollWidget")
        self.params_layout = QFormLayout(scroll_widget)
        self.params_layout.setSpacing(12)
        self.params_layout.setContentsMargins(12, 12, 12, 12)
        self.params_layout.setRowWrapPolicy(
            QFormLayout.DontWrapRows,
        )

        scroll_area.setWidget(scroll_widget)
        left_layout.addWidget(scroll_area)

        separator = QWidget()
        separator.setFixedHeight(2)
        left_layout.addWidget(separator)

        self.create_parameter_widgets()

        separator2 = QWidget()
        separator2.setFixedHeight(2)
        separator2.setStyleSheet("""
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                      stop:0 transparent, stop:0.5 #4a6fa5, stop:1 transparent);
            margin: 8px 0px;
            border-radius: 1px;
        """)
        left_layout.addWidget(separator2)

        self.calculate_button = QPushButton(translator.tr("calculate_button"))
        self.calculate_button.setCursor(Qt.PointingHandCursor)

        left_layout.addWidget(self.calculate_button)

        self.reset_button = QPushButton(translator.tr("reset_button"))
        self.reset_button.setCursor(Qt.PointingHandCursor)
        left_layout.addWidget(self.reset_button)

        right_panel = QWidget()
        right_panel.setObjectName("plotPanel")
        right_layout = QVBoxLayout(right_panel)
        right_layout.setSpacing(0)
        right_layout.setContentsMargins(0, 0, 0, 0)

        self.plot_widget = PlotWidget()
        right_layout.addWidget(self.plot_widget, 1)

        main_layout.addWidget(left_panel, 1)
        main_layout.addWidget(right_panel, 2)

    def create_menu_bar(self) -> None:
        """创建带有标准文件菜单和帮助菜单的应用菜单栏。

        设置菜单结构和常用操作的键盘快捷键。
        """
        menubar = self.menuBar()

        file_menu = menubar.addMenu(translator.tr("menu_file"))

        reset_action = file_menu.addAction(translator.tr("menu_reset"))
        reset_action.triggered.connect(self.reset_parameters)
        reset_action.setShortcut("Ctrl+R")

        file_menu.addSeparator()

        exit_action = file_menu.addAction(translator.tr("menu_exit"))
        exit_action.triggered.connect(self.close)
        exit_action.setShortcut("Ctrl+Q")

        help_menu = menubar.addMenu(translator.tr("menu_help"))

        about_action = help_menu.addAction(translator.tr("menu_about"))
        about_action.triggered.connect(self.show_about)

    def create_status_bar(self) -> None:
        """创建用于显示计算结果和应用状态的状态栏。

        设置带有永久组件的状态栏，用于实时计算反馈。
        """
        self.status_bar = self.statusBar()

        self.calc_status_label = QLabel(translator.tr("ready_text"))

        self.status_bar.addPermanentWidget(self.calc_status_label)

        self.status_bar.showMessage(translator.tr("ready_status"))

    def show_about(self) -> None:
        """显示包含版本和使用信息的应用关于对话框。

        显示应用版本、描述和键盘快捷键。
        """
        QMessageBox.about(
            self,
            translator.tr("about_title"),
            translator.tr("about_content"),
        )

    def create_parameter_widgets(self) -> None:
        """创建和初始化所有参数输入组件。

        使用适当的范围、标签和默认值设置所有LSC曲线参数的控件。
        """
        param_labels = translator.tr_params()

        params = [
            ("m", param_labels["m"], conf.m, -5.0, 0, 0.05),
            ("m1", param_labels["m1"], conf.m1, -10.0, 0.0, 0.2),
            ("s", param_labels["s"], conf.s, 0.0, 10.0, 0.1),
            ("s1", param_labels["s1"], conf.s1, 0.0, 20.0, 0.1),
            ("H", param_labels["H"], conf.H, 0.0, 5.0, 0.1),
            ("m2", param_labels["m2"], conf.m2, -2.0, 2.0, 0.1),
            ("H1", param_labels["H1"], conf.H1, 0.0, 2.0, 0.1),
            ("H2", param_labels["H2"], conf.H2, 0.0, 2.0, 0.1),
            ("J", param_labels["J"], conf.J, 0.0, 180.0, 1.0),
            ("J1", param_labels["J1"], conf.J1, 0.0, 180.0, 1.0),
        ]

        self.param_widgets = {}
        for name, label, default, min_val, max_val, step in params:
            widget = ParameterWidget(name, label, default, min_val, max_val, step)
            self.param_widgets[name] = widget
            self.params_layout.addRow(widget.label_widget, widget)

            widget.spinbox.valueChanged.connect(self.auto_calculate_lsc)

    def setup_connections(self) -> None:
        """设置UI交互的Qt信号槽连接。

        将按钮点击、菜单操作和其他UI事件连接到各自的处理方法。
        """
        self.auto_calc_timer = QTimer()
        self.auto_calc_timer.setSingleShot(True)
        self.auto_calc_timer.timeout.connect(self.calculate_lsc)

        self.calculate_button.clicked.connect(self.calculate_lsc)
        self.reset_button.clicked.connect(self.reset_parameters)

    def auto_calculate_lsc(self) -> None:
        """使用防抖触发自动计算。

        使用计时器对快速参数更改进行防抖，防止交互调整期间过度计算。
        """
        if self.auto_calc_timer:
            self.auto_calc_timer.start(500)

    def calculate_lsc(self) -> None:
        """执行LSC曲线优化计算。

        收集当前参数值、运行优化、更新结果显示并刷新绘图可视化。
        优雅地处理错误并提供用户反馈。
        """
        try:
            params = {name: widget.get_value() for name, widget in self.param_widgets.items()}

            self.lscc = LSCCurve(**params)

            norm = float(np.linalg.norm(self.lscc.x))
            cost = self.lscc.R.cost
            status_text = (
                f"{translator.tr('calculation_success')} | "
                f"{translator.tr('solution_norm')}: {norm:.4f} | {translator.tr('optimization_residual')}: {cost:.6f}"
            )
            self.calc_status_label.setText(status_text)
            self.status_bar.showMessage(
                translator.tr("calculation_complete_status"),
                5000,
            )

            self.plot_widget.update_plot(self.lscc)

        except (OSError, RuntimeError, ValueError) as e:
            logger.exception("计算错误")
            error_text = f"{translator.tr('error_prefix')}{e!s}"
            self.calc_status_label.setText(error_text)
            self.status_bar.showMessage(translator.tr("calculation_error_status"), 5000)

    def reset_parameters(self) -> None:
        """将所有参数输入重置为默认配置值。

        清除绘图显示并将结果面板重置为初始状态。
        """
        for name, widget in self.param_widgets.items():
            default_value = getattr(conf, name)
            widget.set_value(default_value)

        self.plot_widget.clear_plot()
        self.calc_status_label.setText(translator.tr("ready_text"))
        self.status_bar.showMessage(translator.tr("ready_status"))

    def load_settings(self) -> None:
        """从配置加载窗口几何形状和参数值。

        恢复窗口位置/大小并将参数组件设置为之前保存的值。
        """
        self.resize(conf.window_width, conf.window_height)
        self.move(conf.window_x, conf.window_y)

        for name, widget in self.param_widgets.items():
            value = getattr(conf, name)
            widget.set_value(value)

    def keyPressEvent(self, event: QKeyEvent) -> None:
        """处理全局键盘快捷键事件。

        处理Enter/Return进行计算和Escape进行重置。
        将其他键委托给父类。

        参数
        ----
            event: Qt按键事件
        """
        if event.key() == Qt.Key_Return or event.key() == Qt.Key_Enter:
            self.calculate_lsc()
        elif event.key() == Qt.Key_Escape:
            self.reset_parameters()
        else:
            super().keyPressEvent(event)


def main() -> None:
    """运行LSC优化器GUI应用的主入口点。

    初始化Qt应用，创建主窗口，并启动事件循环。
    处理应用生命周期和清理。
    """
    app = QApplication(sys.argv)

    app.setApplicationName("LSC Optimizer")
    app.setApplicationVersion("0.1.0")

    window = LSCOptimizerGUI()
    apply_theme(window, "monokai")
    window.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
