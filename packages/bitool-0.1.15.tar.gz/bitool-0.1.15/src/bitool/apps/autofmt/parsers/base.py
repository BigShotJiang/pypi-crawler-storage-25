"""Base module for parsers."""

import ast

from ..formatters.base import BaseFormatter


class BaseParser(ast.NodeVisitor):
    """Base class for all parsers."""

    def __init__(self, formatter: BaseFormatter) -> None:
        self.formatter = formatter
