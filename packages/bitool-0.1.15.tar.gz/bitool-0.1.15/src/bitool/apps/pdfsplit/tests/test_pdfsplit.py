"""PDF分割功能测试。"""

import shutil
import tempfile
from pathlib import Path
from typing import Generator

import fitz
import pytest

from bitool.core import logger

from ..cli import parse_page_ranges, split_by_number, split_by_range, split_by_size


@pytest.fixture
def temp_dir() -> Generator[Path, None, None]:
    """创建测试文件用的临时目录。"""
    dir_path = Path(tempfile.mkdtemp())
    yield dir_path
    # 清理
    shutil.rmtree(dir_path, ignore_errors=True)


@pytest.fixture
def sample_pdf_10(temp_dir: Path) -> Path:
    """创建10页的测试PDF。"""
    pdf_path = temp_dir / "sample_10.pdf"
    doc = fitz.open()
    for i in range(10):
        page = doc.new_page()  # type: ignore[attr-defined]  # ty:ignore[unresolved-attribute]
        text = fitz.Point(50, 72)
        page.insert_text(text, f"这是第{i + 1}页", fontsize=12)
    doc.save(pdf_path)
    doc.close()
    logger.debug(f"已创建测试PDF: {pdf_path}，共10页")
    return pdf_path


@pytest.fixture
def sample_pdf_5(temp_dir: Path) -> Path:
    """创建5页的测试PDF。"""
    pdf_path = temp_dir / "sample_5.pdf"
    doc = fitz.open()
    for i in range(5):
        page = doc.new_page()  # type: ignore[attr-defined]  # ty:ignore[unresolved-attribute]
        text = fitz.Point(50, 72)
        page.insert_text(text, f"这是第{i + 1}页", fontsize=12)
    doc.save(pdf_path)
    doc.close()
    logger.debug(f"已创建测试PDF: {pdf_path}，共5页")
    return pdf_path


def get_page_count(pdf_path: Path) -> int:
    """获取PDF文件的页数。"""
    doc = fitz.open(pdf_path)
    count = doc.page_count
    doc.close()
    return count


def test_parse_page_ranges() -> None:
    """测试页码范围解析功能。"""
    # 单页
    assert parse_page_ranges("1,2,3", 10) == [1, 2, 3]

    # 范围
    assert parse_page_ranges("1-5", 10) == [1, 2, 3, 4, 5]

    # 混合
    assert parse_page_ranges("1,3,5-7", 10) == [1, 3, 5, 6, 7]

    # 开放结尾范围
    assert parse_page_ranges("5-", 10) == [5, 6, 7, 8, 9, 10]

    # 开放起始范围
    assert parse_page_ranges("-5", 10) == [1, 2, 3, 4, 5]

    # 超出范围的页码会被处理
    assert parse_page_ranges("1,2,20", 10) == [1, 2, 20]


def test_split_by_number_3_parts(sample_pdf_10: Path, temp_dir: Path) -> None:
    """测试将10页PDF分割成3部分。"""
    output_file = temp_dir / "output.pdf"
    split_by_number(sample_pdf_10, output_file, 3)

    # 检查是否创建了3个部分
    parts = sorted(temp_dir.glob("output_part*.pdf"))
    assert len(parts) == 3

    # 检查页数: 10页分成3部分应该是4、3、3页
    page_counts = [get_page_count(p) for p in parts]
    assert page_counts == [4, 3, 3]

    logger.info(f"已分割成3部分: {page_counts}")


def test_split_by_number_equal(sample_pdf_10: Path, temp_dir: Path) -> None:
    """测试将10页PDF分割成5部分。"""
    output_file = temp_dir / "output.pdf"
    split_by_number(sample_pdf_10, output_file, 5)

    parts = sorted(temp_dir.glob("output_part*.pdf"))
    assert len(parts) == 5

    # 每个部分应该有2页
    page_counts = [get_page_count(p) for p in parts]
    assert all(count == 2 for count in page_counts)

    logger.info(f"已分割成5个等份: {page_counts}")


def test_split_by_number_more_parts_than_pages(sample_pdf_5: Path, temp_dir: Path) -> None:
    """测试将5页PDF分割成10部分。"""
    output_file = temp_dir / "output.pdf"
    split_by_number(sample_pdf_5, output_file, 10)

    parts = sorted(temp_dir.glob("output_part*.pdf"))
    assert len(parts) == 5

    # 每个部分应该有1页
    page_counts = [get_page_count(p) for p in parts]
    assert all(count == 1 for count in page_counts)

    logger.info(f"5页分割成10部分: {page_counts}")


def test_split_by_size_3_pages(sample_pdf_10: Path, temp_dir: Path) -> None:
    """测试按每部分3页分割PDF。"""
    output_file = temp_dir / "output.pdf"
    split_by_size(sample_pdf_10, output_file, 3)

    parts = sorted(temp_dir.glob("output_part*.pdf"))
    assert len(parts) == 4

    # 页数应该是3、3、3、1
    page_counts = [get_page_count(p) for p in parts]
    assert page_counts == [3, 3, 3, 1]

    logger.info(f"按大小3分割: {page_counts}")


def test_split_by_size_1_page(sample_pdf_10: Path, temp_dir: Path) -> None:
    """测试按每部分1页分割PDF。"""
    output_file = temp_dir / "output.pdf"
    split_by_size(sample_pdf_10, output_file, 1)

    parts = sorted(temp_dir.glob("output_part*.pdf"))
    assert len(parts) == 10

    # 每个部分应该有1页
    page_counts = [get_page_count(p) for p in parts]
    assert all(count == 1 for count in page_counts)

    logger.info(f"按大小1分割: {page_counts}")


def test_split_by_size_exact_division(sample_pdf_10: Path, temp_dir: Path) -> None:
    """测试精确分割PDF。"""
    output_file = temp_dir / "output.pdf"
    split_by_size(sample_pdf_10, output_file, 5)

    parts = sorted(temp_dir.glob("output_part*.pdf"))
    assert len(parts) == 2

    # 每个部分应该有5页
    page_counts = [get_page_count(p) for p in parts]
    assert page_counts == [5, 5]

    logger.info(f"按大小5精确分割: {page_counts}")


def test_split_by_range_single_pages(sample_pdf_10: Path, temp_dir: Path) -> None:
    """测试提取单页。"""
    output_file = temp_dir / "extracted.pdf"
    split_by_range(sample_pdf_10, output_file, "1,3,5,7,9")

    assert output_file.exists()
    assert get_page_count(output_file) == 5

    # 验证内容（可选，仅检查页数）
    logger.info("已提取5页: 1,3,5,7,9")


def test_split_by_range_with_dash(sample_pdf_10: Path, temp_dir: Path) -> None:
    """测试提取页码范围。"""
    output_file = temp_dir / "extracted.pdf"
    split_by_range(sample_pdf_10, output_file, "1-3,5-7,9-10")

    assert output_file.exists()
    assert get_page_count(output_file) == 8  # 页面1,2,3,5,6,7,9,10

    logger.info("提取范围1-3,5-7,9-10共8页")


def test_split_by_range_open_end(sample_pdf_10: Path, temp_dir: Path) -> None:
    """测试从指定页到末尾的提取。"""
    output_file = temp_dir / "extracted.pdf"
    split_by_range(sample_pdf_10, output_file, "5-")

    assert output_file.exists()
    assert get_page_count(output_file) == 6  # 页面5,6,7,8,9,10

    logger.info("已提取页面5-（共6页）")


def test_split_by_range_open_start(sample_pdf_10: Path, temp_dir: Path) -> None:
    """测试从开头到指定页的提取。"""
    output_file = temp_dir / "extracted.pdf"
    split_by_range(sample_pdf_10, output_file, "-3")

    assert output_file.exists()
    assert get_page_count(output_file) == 3  # 页面1,2,3

    logger.info("已提取页面-3（共3页）")


def test_split_by_range_complex(sample_pdf_10: Path, temp_dir: Path) -> None:
    """测试复杂的页码范围。"""
    output_file = temp_dir / "extracted.pdf"
    split_by_range(sample_pdf_10, output_file, "1,2,4-6,8-")

    assert output_file.exists()
    assert get_page_count(output_file) == 8  # 页面1,2,4,5,6,8,9,10

    logger.info("提取复杂范围: 1,2,4-6,8-")


def test_split_by_range_out_of_range(sample_pdf_5: Path, temp_dir: Path) -> None:
    """测试提取超出PDF长度的页面。"""
    output_file = temp_dir / "extracted.pdf"
    split_by_range(sample_pdf_5, output_file, "1,3,10,20")

    assert output_file.exists()
    assert get_page_count(output_file) == 2  # 只有页面1和3存在

    logger.info("提取的页面有些超出范围: 1,3,10,20")


def test_split_by_range_all_pages(sample_pdf_10: Path, temp_dir: Path) -> None:
    """测试提取所有页面。"""
    output_file = temp_dir / "extracted.pdf"
    split_by_range(sample_pdf_10, output_file, "1-10")

    assert output_file.exists()
    assert get_page_count(output_file) == 10

    logger.info("已提取全部10页")


def test_split_by_range_duplicate_pages(sample_pdf_10: Path, temp_dir: Path) -> None:
    """测试提取带有重复页码规格的情况。"""
    output_file = temp_dir / "extracted.pdf"
    split_by_range(sample_pdf_10, output_file, "1,2,1,2,3-5,3-5")

    assert output_file.exists()
    # 应该去重: 1,2,3,4,5
    assert get_page_count(output_file) == 5

    logger.info("提取并去重（应去重）: 1,2,1,2,3-5,3-5")


def test_output_file_naming(sample_pdf_10: Path, temp_dir: Path) -> None:
    """测试输出文件命名是否正确。"""
    output_file = temp_dir / "test_output.pdf"
    split_by_number(sample_pdf_10, output_file, 3)

    # 检查各部分的命名是否正确
    parts = sorted(temp_dir.glob("test_output_part*.pdf"))
    assert len(parts) == 3

    # 检查文件名
    filenames = [p.name for p in parts]
    assert filenames == ["test_output_part1.pdf", "test_output_part2.pdf", "test_output_part3.pdf"]

    logger.info(f"文件命名测试通过: {filenames}")


def test_large_pdf(temp_dir: Path) -> None:
    """测试较大PDF（50页）。"""
    # 创建50页的PDF
    pdf_path = temp_dir / "large_50.pdf"
    doc = fitz.open()
    for i in range(50):
        page = doc.new_page()  # type: ignore[attr-defined]  # ty:ignore[unresolved-attribute]
        text = fitz.Point(50, 72)
        page.insert_text(text, f"这是第{i + 1}页", fontsize=12)
    doc.save(pdf_path)
    doc.close()

    # 测试按大小分割（每部分10页）
    output_file = temp_dir / "large_output.pdf"
    split_by_size(pdf_path, output_file, 10)

    parts = sorted(temp_dir.glob("large_output_part*.pdf"))
    assert len(parts) == 5

    # 每个部分应该有10页
    page_counts = [get_page_count(p) for p in parts]
    assert all(count == 10 for count in page_counts)

    logger.info("大PDF（50页）已分割成5个部分，每部分10页")


def test_edge_case_single_page_pdf(temp_dir: Path) -> None:
    """测试单页PDF。"""
    pdf_path = temp_dir / "single.pdf"
    doc = fitz.open()
    page = doc.new_page()  # type: ignore[attr-defined]  # ty:ignore[unresolved-attribute]
    text = fitz.Point(50, 72)
    page.insert_text(text, "单页", fontsize=12)
    doc.save(pdf_path)
    doc.close()

    # 按份数分割（应该能正常工作）
    output_file = temp_dir / "single_output.pdf"
    split_by_number(pdf_path, output_file, 2)

    parts = sorted(temp_dir.glob("single_output_part*.pdf"))
    assert len(parts) == 1
    assert get_page_count(parts[0]) == 1

    logger.info("单页PDF处理正确")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
