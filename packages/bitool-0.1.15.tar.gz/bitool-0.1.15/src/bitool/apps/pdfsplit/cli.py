"""PDF分割模块.

提供PDF文件分割功能
支持按份数、大小和页码范围分割
"""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

import fitz

from bitool.core import logger


def parse_page_ranges(range_str: str, total_pages: int) -> list[int]:
    """解析页码范围字符串并返回页码列表（从1开始索引）

    Args:
        range_str: 页码范围字符串，如"1,2,3-5,7-"
        total_pages: PDF总页数

    Returns:
        页码列表（从1开始索引）
    """
    pages = []
    for part in range_str.split(","):
        striped_part = part.strip()
        if not striped_part:
            continue
        if "-" in striped_part:
            start, end = striped_part.split("-")
            start = int(start) if start else 1
            end = int(end) if end else total_pages
            pages.extend(range(start, end + 1))
        else:
            pages.append(int(striped_part))
    return pages


def split_by_number(input_file: Path, output_file: Path, number: int) -> None:
    """将PDF平均分割成指定份数

    Args:
        input_file: 输入PDF文件路径
        output_file: 输出PDF文件路径
        number: 分割份数
    """
    doc = fitz.open(input_file)
    total_pages = doc.page_count
    base_pages = total_pages // number
    remainder = total_pages % number

    logger.debug(
        f"Total pages: {total_pages}, Splitting into {number} parts, "
        f"{base_pages} base pages per part, {remainder} extra pages",
    )

    current_page = 0
    for i in range(number):
        # 前'余数'部分会多分配一页
        pages_in_this_part = base_pages + (1 if i < remainder else 0)

        if current_page >= total_pages:
            logger.debug(f"跳过第{i + 1}部分: 没有剩余页面")
            continue

        end_page = min(current_page + pages_in_this_part, total_pages)

        part_file = output_file.parent / f"{output_file.stem}_part{i + 1}{output_file.suffix}"
        part_doc = fitz.open()

        for page_num in range(current_page, end_page):
            part_doc.insert_pdf(doc, from_page=page_num, to_page=page_num)

        part_doc.save(part_file)
        part_doc.close()
        logger.info(f"Created part {i + 1}: {part_file} (pages {current_page + 1}-{end_page})")

        current_page = end_page

    doc.close()


def split_by_size(input_file: Path, output_file: Path, size: int) -> None:
    """将PDF按指定页数分割成多个部分

    Args:
        input_file: 输入PDF文件路径
        output_file: 输出PDF文件路径
        size: 每个部分的页数
    """
    doc = fitz.open(input_file)
    total_pages = doc.page_count

    logger.debug(f"Total pages: {total_pages}, Splitting with {size} pages per part")

    part = 0
    start_page = 0

    while start_page < total_pages:
        end_page = min(start_page + size, total_pages)
        part_file = output_file.parent / f"{output_file.stem}_part{part + 1}{output_file.suffix}"
        part_doc = fitz.open()

        for page_num in range(start_page, end_page):
            part_doc.insert_pdf(doc, from_page=page_num, to_page=page_num)

        part_doc.save(part_file)
        part_doc.close()
        logger.info(f"Created part {part + 1}: {part_file} (pages {start_page + 1}-{end_page})")

        start_page = end_page
        part += 1

    doc.close()


def split_by_range(input_file: Path, output_file: Path, range_str: str) -> None:
    """根据页码范围从PDF中提取指定页面

    Args:
        input_file: 输入PDF文件路径
        output_file: 输出PDF文件路径
        range_str: 页码范围字符串，如"1,3,5-10"
    """
    doc = fitz.open(input_file)
    total_pages = doc.page_count

    pages = parse_page_ranges(range_str, total_pages)
    pages = [p - 1 for p in pages if 1 <= p <= total_pages]  # 转换为0索引

    if not pages:
        logger.error("指定范围内未找到有效页面")
        doc.close()
        return

    # 去除重复页码同时保持顺序
    pages = sorted(set(pages))

    logger.debug(f"正在提取页面: {[p + 1 for p in pages]}")

    new_doc = fitz.open()
    for page_num in pages:
        new_doc.insert_pdf(doc, from_page=page_num, to_page=page_num)

    new_doc.save(output_file)
    new_doc.close()
    doc.close()
    logger.info(f"已创建输出文件: {output_file} (共{len(pages)}页)")


def main() -> None:
    """命令行入口函数.

    PDF分割工具

    示例
    --------
      pdfsplit [选项] <参数>
    """
    parser = argparse.ArgumentParser(description="分割PDF文件")
    parser.add_argument("input", help="输入PDF文件")
    parser.add_argument("output", nargs="?", help="输出PDF文件（在使用-n和-s模式时可选）")
    parser.add_argument(
        "-o",
        "--output-dir",
        default=".",
        help="输出目录（默认：当前目录）",
    )
    parser.add_argument(
        "-f",
        "--output-format",
        help="输出文件格式模式，如 'split_{part:02d}.pdf'",
    )
    parser.add_argument("-v", "--verbose", action="store_true", help="详细输出")

    # 按份数、大小或范围分割
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("-n", "--number", type=int, help="分割份数")
    group.add_argument("-s", "--size", type=int, default=1, help="每个部分的页数")
    group.add_argument(
        "-r",
        "--range",
        type=str,
        help="要提取的页码范围，如 '1,2,4-10,15-20,25-'",
    )

    args = parser.parse_args()

    if args.verbose:
        logger.setLevel(logging.DEBUG)

    output_dir = Path(args.output_dir)
    if not output_dir.is_dir():
        logger.error(f"输出目录 {args.output_dir} 不存在，请检查路径。")
        return

    input_file = Path(args.input)
    if not input_file.is_file():
        logger.error(f"输入文件 {args.input} 不存在，请检查路径。")
        return

    # 对于-n和-s模式，输出文件可选，默认使用基础名称加后缀
    # 对于-r模式，输出文件是必需的
    if args.range and not args.output:
        logger.error("在-r/--range模式下需要指定输出文件")
        return

    if not args.range:
        output_file = output_dir / (input_file.stem + "_split.pdf") if not args.output else Path(args.output)
    else:
        output_file = Path(args.output)

    logger.info(f"开始分割 {input_file}")
    if args.number:
        split_by_number(input_file, output_file, args.number)
    elif args.size:
        split_by_size(input_file, output_file, args.size)
    elif args.range:
        split_by_range(input_file, output_file, args.range)
    else:
        logger.error("请指定 -n、-s 或 -r 之一")
        return
