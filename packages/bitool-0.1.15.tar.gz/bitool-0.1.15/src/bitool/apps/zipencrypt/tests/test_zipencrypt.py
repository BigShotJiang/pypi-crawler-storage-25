"""Zipencrypt 模块的单元测试。"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from ..cli import (
    _create_unencrypted_zip,
    _get_valid_entries,
)


class TestHelperFunctions:
    """辅助函数的测试类。"""

    def test_get_valid_entries_with_files_only(self, tmp_path: Path) -> None:
        """测试仅包含文件时的 _get_valid_entries。"""
        # 创建测试文件
        (tmp_path / "file1.txt").touch()
        (tmp_path / "file2.py").touch()

        entries = _get_valid_entries(tmp_path)
        entry_names = [entry.name for entry in entries]

        assert len(entries) == 2
        assert "file1.txt" in entry_names
        assert "file2.py" in entry_names

    def test_get_valid_entries_skips_hidden_directories(self, tmp_path: Path) -> None:
        """测试 _get_valid_entries 跳过隐藏目录。"""
        # 创建测试文件和目录
        (tmp_path / "file1.txt").touch()
        (tmp_path / ".hidden_dir").mkdir()
        (tmp_path / "__pycache__").mkdir()
        (tmp_path / "normal_dir").mkdir()

        entries = _get_valid_entries(tmp_path)
        entry_names = [entry.name for entry in entries]

        assert len(entries) == 2  # 只有 file1.txt 和 normal_dir
        assert "file1.txt" in entry_names
        assert "normal_dir" in entry_names
        assert ".hidden_dir" not in entry_names
        assert "__pycache__" not in entry_names

    def test_get_valid_entries_mixed_content(self, tmp_path: Path) -> None:
        """测试 _get_valid_entries 混合文件和目录的情况。"""
        # 创建混合内容
        (tmp_path / "file1.txt").touch()
        (tmp_path / "script.py").touch()
        (tmp_path / ".git").mkdir()
        (tmp_path / "src").mkdir()
        (tmp_path / "__pycache__").mkdir()

        entries = _get_valid_entries(tmp_path)
        entry_names = [entry.name for entry in entries]

        assert len(entries) == 3  # file1.txt, script.py, src
        assert set(entry_names) == {"file1.txt", "script.py", "src"}

    def test_create_unencrypted_zip_single_file(self, tmp_path: Path) -> None:
        """测试 _create_unencrypted_zip 处理单个文件。"""
        # 创建测试文件
        test_file = tmp_path / "test.txt"
        test_file.write_text("Hello World")

        # 创建 zip 文件
        zip_path = tmp_path / "test.zip"
        _create_unencrypted_zip(test_file, zip_path)

        # 验证 zip 已创建
        assert zip_path.exists()

        # 验证内容可以被解压
        import zipfile

        with zipfile.ZipFile(zip_path, "r") as zf:
            assert "test.txt" in zf.namelist()
            content = zf.read("test.txt").decode()
            assert content == "Hello World"

    def test_create_unencrypted_zip_directory(self, tmp_path: Path) -> None:
        """测试 _create_unencrypted_zip 处理目录。"""
        # 创建测试目录结构
        test_dir = tmp_path / "test_dir"
        test_dir.mkdir()

        # 在目录中创建文件
        (test_dir / "file1.txt").write_text("Content 1")
        (test_dir / "file2.txt").write_text("Content 2")
        sub_dir = test_dir / "subdir"
        sub_dir.mkdir()
        (sub_dir / "file3.txt").write_text("Content 3")

        # 创建 zip 文件
        zip_path = tmp_path / "test_dir.zip"
        _create_unencrypted_zip(test_dir, zip_path)

        # 验证 zip 已创建
        assert zip_path.exists()

        # 验证内容结构
        import zipfile

        with zipfile.ZipFile(zip_path, "r") as zf:
            namelist = zf.namelist()
            assert "file1.txt" in namelist
            assert "file2.txt" in namelist
            assert "subdir/file3.txt" in namelist
            assert len(namelist) == 3  # 只有文件，不包含目录


class TestIntegration:
    """Zipencrypt 功能的集成测试类。"""

    def test_complete_encryption_workflow(self, tmp_path: Path) -> None:
        """测试使用模拟外部工具的完整加密工作流程。"""
        # 创建包含文件的测试目录
        test_dir = tmp_path / "project"
        test_dir.mkdir()
        (test_dir / "main.py").write_text("print('hello')")
        (test_dir / "README.md").write_text("# Project")
        (test_dir / ".git").mkdir()  # 隐藏目录

        # 模拟配置
        with patch("bitool.apps.zipencrypt.cli.conf") as mock_conf:
            mock_conf.SKIP_PREFIXES = (".", "__")
            mock_conf.available_tools = []  # 强制使用 zipfile 回退
            mock_conf.has_encryption_support = False

            # 测试有效条目是否被正确识别
            entries = _get_valid_entries(test_dir)
            entry_names = [entry.name for entry in entries]
            assert set(entry_names) == {"main.py", "README.md"}
            assert ".git" not in entry_names


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
