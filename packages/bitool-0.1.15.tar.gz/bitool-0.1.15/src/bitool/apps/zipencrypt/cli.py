"""Zip 加密工具。"""

from __future__ import annotations

import argparse
import shutil
import sys
import zipfile
from functools import cached_property
from pathlib import Path
from time import perf_counter
from typing import ClassVar

from bitool.core import JsonConfig, logger


class ZipEncryptConfig(JsonConfig):
    """ZIP 加密工具配置类。"""

    SKIP_PREFIXES: ClassVar[tuple[str, ...]] = (
        ".",
        "__",
    )

    password: str = "DEFAULT_PASSWORD"  # noqa: S105
    max_name_len: int = 20
    max_file_count: int = 5
    max_workers: int = 10

    @cached_property
    def available_tools(self) -> list[str]:
        """获取可用的压缩工具列表。"""
        tools = []
        if shutil.which("7z"):
            tools.append("7z")
        if shutil.which("zip"):
            tools.append("zip")
        if shutil.which("rar"):
            tools.append("rar")
        return tools

    @cached_property
    def has_encryption_support(self) -> bool:
        """检查是否有可用的加密工具。"""
        return bool(self.available_tools)


def _execute_command(cmd: list[str]) -> None:
    """执行外部命令并处理结果。

    参数:
        cmd: 要执行的命令及其参数列表

    异常:
        Exception: 命令执行失败时抛出
    """
    from bitool.cmd import execute

    # 将所有参数转换为字符串
    cmd_str = [str(arg) for arg in cmd]
    logger.debug(f"正在执行命令: {' '.join(cmd_str)}")
    try:
        result = execute(
            cmd_str,
            capture_output=True,
            text=True,
            check=True,
            timeout=300,  # 5 分钟超时
        )
        logger.debug(f"命令输出: {result.stdout.strip()}")
        if result.stderr:
            logger.warning(f"命令错误输出: {result.stderr.strip()}")
    except Exception:
        logger.exception(f"命令执行失败: {' '.join(cmd_str)}")
        raise


# 在所有类和函数定义完成后初始化全局配置
conf = ZipEncryptConfig()


def encrypt_zip(
    root_path: str | Path | None = None,
    password: str | None = None,
    *,
    replace: bool = False,
) -> None:
    """将文件和目录加密为带密码保护的 ZIP 压缩包。

    参数:
        root_path: 包含要加密文件的目录，默认为当前目录。
        password: 加密密码，若未提供则使用配置的默认密码。
        replace: 是否替换已存在的 ZIP 文件，默认为 False。
    """
    # 如果未指定则使用当前目录
    root_path = Path.cwd() if root_path is None else Path(root_path)

    # 如果未提供密码则使用配置的密码
    if password is None:
        password = conf.password

    # 验证输入
    if not password:
        logger.error("密码不能为空")
        sys.exit(1)

    if not root_path.exists():
        logger.error(f"目录不存在: {root_path}")
        sys.exit(1)

    if not root_path.is_dir():
        logger.error(f"路径不是目录: {root_path}")
        sys.exit(1)

    # 按顺序获取并处理文件
    files = _get_valid_entries(root_path)
    if not files:
        logger.warning(f"在 {root_path} 中未找到目标文件")
        return

    logger.info(f"开始加密 {len(files)} 个文件/目录...")

    # 逐个处理文件
    try:
        for file_path in files:
            _make_archive(file_path, password=password, replace=replace)
        logger.info("加密过程成功完成")
    except (OSError, RuntimeError):
        logger.exception("加密过程失败")
        raise


def _create_encrypted_zip(filepath: Path, target_path: Path, password: str) -> None:
    """使用可用工具创建加密的 ZIP 文件。

    参数:
        filepath: 要加密的文件或目录路径
        target_path: 目标 ZIP 文件路径
        password: 加密密码
    """
    if "7z" in conf.available_tools:
        logger.info("使用 7z 命令进行加密")
        cmds = ["7z", "a", "-p" + password, "-mem=AES256", str(target_path), str(filepath)]
    elif "zip" in conf.available_tools:
        logger.info("使用 zip 命令进行加密")
        cmds = ["zip", "-r", "-P" + password, str(target_path), str(filepath)]
    elif "rar" in conf.available_tools:
        logger.info("使用 rar 命令进行加密")
        cmds = ["rar", "a", "-p" + password, "-m5", str(target_path), str(filepath)]
    else:
        logger.warning("未找到支持加密的工具，使用标准 zipfile（无加密）")
        _create_unencrypted_zip(filepath, target_path)
        return
    _execute_command(cmds)


def _create_unencrypted_zip(filepath: Path, target_path: Path) -> None:
    """创建未加密的 ZIP 文件作为备用选项。

    参数:
        filepath: 要压缩的文件或目录路径
        target_path: 目标 ZIP 文件路径
    """
    with zipfile.ZipFile(target_path, "w", zipfile.ZIP_DEFLATED) as zip_file:
        if filepath.is_file():
            # 使用相对路径，只包含文件名而非完整路径
            zip_file.write(filepath, filepath.name)
        elif filepath.is_dir():
            # 使用相对路径以确保 ZIP 只包含相对路径结构
            for file in filepath.rglob("*"):
                if file.is_file():
                    arcname = str(file.relative_to(filepath))
                    zip_file.write(file, arcname)


def _get_valid_entries(dirpath: Path) -> list[Path]:
    """获取有效的待处理条目列表。

    参数:
        dirpath: 目录路径

    返回:
        有效条目路径列表
    """
    return [
        entry
        for entry in dirpath.iterdir()
        if entry.is_file() or (entry.is_dir() and not any(entry.name.startswith(x) for x in conf.SKIP_PREFIXES))
    ]


def _make_archive(filepath: Path, password: str, *, replace: bool = True) -> None:
    """为单个文件或目录创建压缩包。

    参数:
        filepath: 要归档的文件或目录路径
        password: 加密密码
        replace: 是否替换已存在的压缩包
    """
    target_path = filepath.parent / f"{filepath.stem}.zip"
    if target_path.exists():  # 避免重复加密
        if replace:
            logger.info(f"{target_path} 已存在，正在覆盖。")
            target_path.unlink()
        else:
            logger.warning(f"{target_path} 已存在，跳过。")
            return

    t0 = perf_counter()
    # 使用密码创建加密 ZIP 文件
    if filepath.is_file():
        logger.info(f"正在加密文件: {filepath.name} ...")
    elif filepath.is_dir():
        logger.info(f"正在加密目录: {filepath.name} ...")
    else:
        logger.warning(f"{filepath} 不是文件或目录。")
        return

    _create_encrypted_zip(filepath, target_path, password=password)
    logger.info(f"加密完成: {target_path} ({perf_counter() - t0:.2f}秒)")


def parse_args() -> argparse.Namespace:
    """解析加密工具的命令行参数。"""
    parser = argparse.ArgumentParser(description="将文件和目录加密为带密码保护的 ZIP 压缩包。")
    parser.add_argument("root_path", help="包含要加密文件的目录")
    parser.add_argument("password", help="加密密码")
    parser.add_argument("--replace", action="store_true", help="是否替换已存在的 ZIP 文件")
    return parser.parse_args()


def main() -> None:
    """将文件和目录加密为带密码保护的 ZIP 压缩包。"""
    args = parse_args()

    if not args.password:
        logger.error("密码不能为空")
        return

    root_dir = Path(args.root_path)
    if not root_dir.exists():
        logger.error(f"目录不存在: {args.root_path}")
        return

    files = _get_valid_entries(root_dir)
    if not files:
        logger.warning(f"在 {args.root_path} 中未找到目标文件。")
        return

    logger.info(f"开始加密 {len(files)} 个文件/目录...")
    try:
        for file_path in files:
            _make_archive(file_path, password=args.password, replace=args.replace)
    except (OSError, RuntimeError):
        logger.exception("执行过程中发生错误")
        raise
