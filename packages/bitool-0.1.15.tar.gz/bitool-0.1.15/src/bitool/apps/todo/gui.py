"""待办事项列表应用程序命令行界面."""

import sys

from bitool.gui.compat import QApplication

from .config import conf
from .controller import TodoController


def main() -> int:
    """待办事项列表应用程序的入口点.

    Returns:
        int: 退出代码.
    """
    app = QApplication(sys.argv)

    # load global stylesheet
    global_stylesheet = conf._DIR_STYLES / "global.qss"
    app.setStyleSheet(global_stylesheet.read_text().strip())

    # create todo app
    todo_app = TodoController()
    todo_app.show()

    return app.exec_()


if __name__ == "__main__":
    sys.exit(main())
