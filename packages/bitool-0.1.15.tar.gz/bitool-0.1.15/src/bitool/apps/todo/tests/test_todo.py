from __future__ import annotations

from pathlib import Path
from typing import Generator

import pytest
from pytestqt.qtbot import QtBot

from bitool.apps.todo.controller import TodoController
from bitool.apps.todo.model import TodoItem, TodoListModel
from bitool.gui.compat import (
    QContextMenuEvent,
    QMessageBox,
    QObject,
    QPoint,
    Qt,
)


class TestTodoItem:
    """测试TodoItem类."""

    @pytest.mark.parametrize(
        ("text", "completed", "priority", "category"),
        [
            ("测试1", False, 0, ""),
            ("测试2", True, 1, "工作"),
            ("测试3", True, 2, "工作"),
            ("测试4", True, 3, "工作"),
        ],
    )
    def test_to_dict(
        self,
        text: str,
        *,
        completed: bool,
        priority: int,
        category: str,
    ) -> None:
        """测试TodoItem转换为字典."""
        item = TodoItem(
            text=text,
            completed=completed,
            priority=priority,
            category=category,
        )

        assert item.to_dict() == {
            "text": text,
            "completed": completed,
            "created_at": item.created_at.isoformat(),
            "completed_at": "",
            "priority": priority,
            "category": category,
        }

    def test_from_dict(self) -> None:
        """测试从字典创建TodoItem."""
        item = TodoItem.from_dict(
            {
                "text": "test",
                "completed": True,
                "created_at": "2023-01-01T00:00:00",
                "completed_at": "2023-01-01T00:00:00",
                "priority": 1,
                "category": "test",
            },
        )

        assert item.text == "test"
        assert item.completed
        assert item.created_at.isoformat() == "2023-01-01T00:00:00"
        assert item.completed_at
        assert item.completed_at.isoformat() == "2023-01-01T00:00:00"


class TestTodoListModel:
    """测试TodoListModel类."""

    @pytest.mark.parametrize(
        ("text", "priority", "category"),
        [
            ("测试1", 0, ""),
            ("测试2", 1, "工作"),
            ("测试3", 2, "工作"),
            ("测试4", 3, "工作"),
        ],
    )
    def test_normal_functions(
        self,
        text: str,
        *,
        priority: int,
        category: str,
    ) -> None:
        """测试添加项目功能."""
        model = TodoListModel()

        # 测试初始状态
        assert len(model.items) == 0
        assert model.count == 0

        # 测试添加项目
        model.add_item(text, priority, category)
        assert len(model.items) == 1
        assert model.count == 1
        assert str(model.get_item(0)) == str(
            TodoItem(
                text=text,
                completed=False,
                priority=priority,
                category=category,
            ),
        )

        # 测试更新项目
        assert model.completed_count == 0
        model.update_item(0, completed=True)
        assert model.completed_count == 1

        # 测试移除项目
        model.remove_item(0)
        assert model.count == 0


class TestTodoListView:
    """测试TodoListView类."""

    @pytest.fixture(autouse=True)
    def fixture_reset_data(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """重置数据文件."""
        monkeypatch.setattr(
            "bitool.apps.todo.controller.TodoController.get_data_file_path",
            lambda _: str(tmp_path / "todo_data.json"),
        )

    @pytest.fixture
    def mock_controller(
        self,
        qtbot: QtBot,
    ) -> Generator[TodoController, None, None]:
        """设置控制器.

        Yields:
            TodoController: TodoController实例
        """
        controller = TodoController()
        controller.show()
        qtbot.addWidget(controller.view)
        yield controller
        controller.save_data()

    def _click_item(
        self,
        mock_controller: TodoController,
        qtbot: QtBot,
        item: TodoItem,
        *,
        condition: bool = True,
    ) -> None:
        """点击项目."""
        if condition:
            filtered_index = mock_controller.model.filtered_items.index(item)
            index = mock_controller.model.index(filtered_index, 0)
            qtbot.mouseClick(
                mock_controller.view.todo_list.viewport(),
                Qt.LeftButton,
                pos=mock_controller.view.todo_list.visualRect(index).center(),
            )

    def _complete_count(self, mock_controller: TodoController) -> int:
        """获取完成数量.

        Returns:
            int: 完成数量
        """
        return sum(1 for item in mock_controller.model.items if item.completed)

    def test_add_item(
        self,
        mock_controller: TodoController,
        qtbot: QtBot,
    ) -> None:
        """测试应用程序运行."""
        assert mock_controller.view.isVisible()

        # 操作
        mock_controller.view.todo_input.setText("测试待办事项")
        qtbot.mouseClick(mock_controller.view.add_button, Qt.LeftButton)

        assert mock_controller.model.count == 1
        assert isinstance(mock_controller.model.get_item(0), TodoItem)
        assert not mock_controller.model.get_item(0).completed  # pyright: ignore[reportOptionalMemberAccess]
        assert mock_controller.model.get_item(0).text == "测试待办事项"  # pyright: ignore[reportOptionalMemberAccess]

    def test_item_clicked(
        self,
        mock_controller: TodoController,
        qtbot: QtBot,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """测试点击项目切换完成状态."""
        # Add two items to the model
        mock_controller.model.add_item("Test todo item 01", 1, "work")
        mock_controller.model.add_item("Test todo item 02", 2, "work")

        assert mock_controller.model.count == 2
        assert mock_controller.model.get_item(0).completed is False  # pyright: ignore[reportOptionalMemberAccess]
        assert mock_controller.model.get_item(1).completed is False  # pyright: ignore[reportOptionalMemberAccess]

        mock_controller.model.add_item("Test todo item 03", 3, "play")
        assert mock_controller.model.count == 3
        assert mock_controller.model.get_item(2).completed is False  # pyright: ignore[reportOptionalMemberAccess]

        # Click first item to complete it
        first_item = mock_controller.model.get_item(0)
        assert first_item is not None
        self._click_item(
            mock_controller,
            qtbot,
            first_item,
            condition=not first_item.completed,
        )
        assert self._complete_count(mock_controller) == 1

        # Click other items to complete it
        for _, item in enumerate(mock_controller.model.items):
            self._click_item(
                mock_controller,
                qtbot,
                item,
                condition=not item.completed,
            )

        # Check that one item is now completed
        assert self._complete_count(mock_controller) == 3

        # Mock the confirmation dialog for un-completing
        monkeypatch.setattr(
            QMessageBox,
            "exec_",
            lambda _: QMessageBox.StandardButton.Yes,
        )

        # Find the completed item and click it to un-complete
        for _, item in enumerate(mock_controller.model.items):
            self._click_item(
                mock_controller,
                qtbot,
                item,
                condition=item.completed,
            )
        assert self._complete_count(mock_controller) == 0

    def test_item_right_clicked(
        self,
        mock_controller: TodoController,
        qtbot: QtBot,
    ) -> None:
        """测试应用程序关闭."""
        mock_controller.model.add_item("Test todo item 01", 1, "work")
        assert mock_controller.model.count == 1

        index = mock_controller.model.index(0, 0)
        qtbot.mouseClick(
            mock_controller.view.todo_list.viewport(),
            Qt.RightButton,
            pos=mock_controller.view.todo_list.visualRect(index).center(),
        )

    def test_context_menu_event_edit(
        self,
        mock_controller: TodoController,
        qtbot: QtBot,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """测试上下文菜单编辑操作."""
        # Add an item to test with
        mock_controller.model.add_item("Test todo item 01", 1, "work")
        assert mock_controller.model.count == 1

        # Mock the QInputDialog to return a specific text
        monkeypatch.setattr(
            "bitool.gui.compat.QInputDialog.getText",
            lambda _, __: ("Updated item text", True),
        )

        # Get the position of the item
        index = mock_controller.model.index(0, 0)
        rect = mock_controller.view.todo_list.visualRect(index)

        # Simulate right-click to open context menu
        qtbot.mouseClick(
            mock_controller.view.todo_list.viewport(),
            Qt.RightButton,
            pos=rect.center(),
        )

        # 注意：我们无法通过键盘事件与上下文菜单交互
        # 因为它是一个独立的弹出菜单，不是列表部件的一部分。
        # 测试上下文菜单功能的正确方法是通过
        # 直接方法调用，如在direct_call测试中实现的那样。

    def test_context_menu_event_delete(
        self,
        mock_controller: TodoController,
        qtbot: QtBot,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """测试上下文菜单删除操作."""
        # Add an item to test with
        mock_controller.model.add_item("Test todo item 01", 1, "work")
        assert mock_controller.model.count == 1

        # Mock the confirmation dialog to automatically confirm deletion
        monkeypatch.setattr(
            "bitool.gui.compat.QMessageBox.exec_",
            lambda _: QMessageBox.StandardButton.Yes,  # pyright: ignore[reportAttributeAccessIssue]
        )

        # Get the position of the item
        index = mock_controller.model.index(0, 0)
        rect = mock_controller.view.todo_list.visualRect(index)

        # Simulate right-click to open context menu
        qtbot.mouseClick(
            mock_controller.view.todo_list.viewport(),
            Qt.RightButton,
            pos=rect.center(),
        )

        # 注意：我们无法通过键盘事件与上下文菜单交互
        # 因为它是一个独立的弹出菜单，不是列表部件的一部分。
        # 测试上下文菜单功能的正确方法是通过
        # 直接方法调用，如在direct_call测试中实现的那样。

    def test_context_menu_event_set_priority(
        self,
        mock_controller: TodoController,
        qtbot: QtBot,
    ) -> None:
        """测试上下文菜单设置优先级操作."""
        # Add an item to test with
        mock_controller.model.add_item("Test todo item 01", 1, "work")
        assert mock_controller.model.count == 1

        # Get the position of the item
        index = mock_controller.model.index(0, 0)
        rect = mock_controller.view.todo_list.visualRect(index)

        # Simulate right-click to open context menu
        qtbot.mouseClick(
            mock_controller.view.todo_list.viewport(),
            Qt.RightButton,
            pos=rect.center(),
        )

        # 注意：我们无法通过键盘事件与上下文菜单交互
        # 因为它是一个独立的弹出菜单，不是列表部件的一部分。
        # 测试上下文菜单功能的正确方法是通过
        # 直接方法调用，如在direct_call测试中实现的那样。

    def test_context_menu_event_direct_call_edit(
        self,
        mock_controller: TodoController,
        qtbot: QtBot,
        mocker,
    ) -> None:
        """通过直接调用方法测试上下文菜单事件的编辑操作."""
        # Add an item to test with
        mock_controller.model.add_item("Test todo item 01", 1, "work")
        assert mock_controller.model.count == 1

        # Show the view
        mock_controller.view.show()
        qtbot.waitForWindowShown(mock_controller.view)

        # Mock QInputDialog.getText to return specific values
        mocker.patch(
            "bitool.gui.compat.QInputDialog.getText",
            return_value=("Edited item text", True),
        )

        # Directly call edit_item method
        mock_controller.view.edit_item(0)

        # Check that the item text was updated
        assert mock_controller.model.get_item(0).text == "Edited item text"  # pyright: ignore[reportOptionalMemberAccess]

    def test_context_menu_event_direct_call_delete(
        self,
        mock_controller: TodoController,
        qtbot: QtBot,
        mocker: pytest.Mocker,
    ) -> None:
        """通过直接调用方法测试上下文菜单事件的删除操作."""
        # Add an item to test with
        mock_controller.model.add_item("Test todo item 01", 1, "work")
        assert mock_controller.model.count == 1

        # Mock the item_deleted signal
        deleted_row = []

        def capture_deleted_row(row: int) -> None:
            deleted_row.append(row)

        mock_controller.view.item_deleted.connect(capture_deleted_row)

        # Show the view
        mock_controller.view.show()
        qtbot.waitForWindowShown(mock_controller.view)

        # Get the item's index and position
        index = mock_controller.model.index(0, 0)
        rect = mock_controller.view.todo_list.visualRect(index)
        mock_controller.view.todo_list.mapToGlobal(rect.center())

        # Right-click to trigger context menu
        from bitool.gui.compat import Qt

        qtbot.mouseClick(
            mock_controller.view.todo_list,
            Qt.MouseButton.RightButton,
            pos=rect.center(),
        )

        # Process events
        from bitool.gui.compat import QApplication

        QApplication.processEvents()

        # The context menu should have been shown and the delete action triggered
        # Since we can't easily mock the blocking exec_ call, we directly call the method
        # that would be called when delete is selected
        mock_controller.view.item_deleted.emit(0)

        # Check that the delete signal was emitted with correct row
        assert deleted_row == [0]

    def test_context_menu_event_direct_call_set_priority(
        self,
        mock_controller: TodoController,
        qtbot: QtBot,
    ) -> None:
        """通过直接调用方法测试上下文菜单事件的设置优先级操作."""
        # Add an item to test with
        mock_controller.model.add_item("Test todo item 01", 1, "work")
        assert mock_controller.model.count == 1

        # Show the view
        mock_controller.view.show()
        qtbot.waitForWindowShown(mock_controller.view)

        # Directly call set_item_priority method
        mock_controller.view.set_item_priority(0, 3)

        # Check that the item priority was updated to "高" (index 3)
        assert mock_controller.model.get_item(0).priority == 3  # pyright: ignore[reportOptionalMemberAccess]

    def test_context_menu_event_with_invalid_index(
        self,
        mock_controller: TodoController,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """测试在无效索引点击时的上下文菜单事件."""
        # Add an item to test with
        mock_controller.model.add_item("Test todo item 01", 1, "work")
        assert mock_controller.model.count == 1

        # Get a position that is not on any item (e.g., at y=1000)
        global_pos = mock_controller.view.todo_list.mapToGlobal(
            mock_controller.view.todo_list.rect().topLeft(),
        )
        # Move the point to ensure it's not over any item
        global_pos += QPoint(0, 1000)

        # Create a context menu event
        event = QContextMenuEvent(
            QContextMenuEvent.Mouse,
            global_pos,
            global_pos,
        )

        # Mock QMenu.exec_ to ensure it doesn't cause issues
        menu_executed = []

        def mock_exec(self: QObject, pos: QPoint) -> None:
            menu_executed.append(True)

        monkeypatch.setattr("bitool.gui.compat.QMenu.exec_", mock_exec)

        # Call contextMenuEvent directly - should not raise any exception
        mock_controller.view.contextMenuEvent(event)

        # Ensure that menu.exec_ was not called since index is invalid
        assert len(menu_executed) == 0
