"""Tests for paramodeler composition module."""

import numpy as np
import pytest
import trimesh

from bitool.apps.paramodeler.models.composition import (
    batch_difference,
    batch_intersection,
    batch_union,
    chain_pattern,
    compose_transform,
    grid_pattern,
    hierarchical_combine,
    instanced_array,
    radial_pattern,
)
from bitool.apps.paramodeler.models.shapes import (
    create_box,
    create_cylinder,
    create_sphere,
)


class TestBatchOperations:
    """Tests for batch operations."""

    def test_batch_union(self) -> None:
        """Test batch union operation."""
        boxes = [create_box(center=(i, 0, 0)) for i in range(3)]
        result = batch_union(boxes)

        assert isinstance(result, trimesh.Trimesh)
        assert len(result.vertices) > len(boxes[0].vertices)

    def test_batch_union_single(self) -> None:
        """Test batch union with single mesh."""
        box = create_box()
        result = batch_union([box])

        assert isinstance(result, trimesh.Trimesh)

    def test_batch_union_empty(self) -> None:
        """Test batch union with empty list."""
        with pytest.raises(ValueError):
            batch_union([])

    def test_batch_difference(self) -> None:
        """Test batch difference operation."""
        base = create_box(width=3, height=3, depth=3)
        cutters = [
            create_box(center=(0, 0, 0)),
            create_sphere(radius=0.5, center=(1, 0, 0)),
        ]
        result = batch_difference(base, cutters)

        assert isinstance(result, trimesh.Trimesh)

    def test_batch_intersection(self) -> None:
        """Test batch intersection operation."""
        box1 = create_box(center=(0, 0, 0))
        box2 = create_box(center=(0.5, 0.5, 0.5))

        result = batch_intersection([box1, box2])

        if result is not None:
            assert isinstance(result, trimesh.Trimesh)


class TestTransformComposition:
    """Tests for compose_transform function."""

    def test_compose_transform(self) -> None:
        """Test composing multiple transformations."""
        box = create_box()
        operations = [
            ("translate", ((1, 2, 3),)),
            ("rotate", (np.pi / 2, (0, 1, 0))),
            ("scale", (2.0,)),
        ]

        result = compose_transform(box, operations)

        assert isinstance(result, trimesh.Trimesh)
        assert result is not box

    def test_compose_empty_operations(self) -> None:
        """Test compose_transform with no operations."""
        box = create_box()
        result = compose_transform(box, [])

        assert isinstance(result, trimesh.Trimesh)


class TestPatterns:
    """Tests for pattern generation functions."""

    def test_grid_pattern(self) -> None:
        """Test grid pattern generation."""
        box = create_box(width=0.5, height=0.2, depth=0.5)
        result = grid_pattern(box, grid_size=(3, 3, 1), spacing=(1.0, 1.0, 1.0))

        assert isinstance(result, trimesh.Trimesh)

    def test_radial_pattern(self) -> None:
        """Test radial pattern generation."""
        box = create_box(width=0.5, height=0.2, depth=0.5)
        result = radial_pattern(box, count=6, radius=2.0)

        assert isinstance(result, trimesh.Trimesh)

    def test_radial_single(self) -> None:
        """Test radial pattern with single instance."""
        box = create_box()
        result = radial_pattern(box, count=1, radius=0.0)

        assert isinstance(result, trimesh.Trimesh)

    def test_chain_pattern(self) -> None:
        """Test chain pattern generation."""
        link = create_cylinder(radius=0.2, height=0.8)
        result = chain_pattern(link, links=5, link_length=1.0)

        assert isinstance(result, trimesh.Trimesh)


class TestInstancedArray:
    """Tests for instanced_array function."""

    def test_instanced_array(self) -> None:
        """Test instanced array with positions."""
        box = create_box()
        positions = [(0, 0, 0), (1, 0, 0), (2, 0, 0)]
        result = instanced_array(box, positions)

        assert isinstance(result, trimesh.Trimesh)

    def test_instanced_array_with_rotations(self) -> None:
        """Test instanced array with positions and rotations."""
        box = create_box()
        positions = [(0, 0, 0), (1, 0, 0)]
        rotations = [0.0, np.pi / 2]
        result = instanced_array(box, positions, rotations=rotations)

        assert isinstance(result, trimesh.Trimesh)

    def test_instanced_array_with_scales(self) -> None:
        """Test instanced array with positions and scales."""
        box = create_box()
        positions = [(0, 0, 0), (2, 0, 0)]
        scales = [1.0, 2.0]
        result = instanced_array(box, positions, scales=scales)

        assert isinstance(result, trimesh.Trimesh)


class TestHierarchicalCombine:
    """Tests for hierarchical_combine function."""

    def test_hierarchical_combine(self) -> None:
        """Test hierarchical combination."""
        components = [
            ("base", create_box(width=2, height=0.5, depth=2), (0, 0, 0)),
            ("sphere", create_sphere(radius=0.5), (0, 0.75, 0)),
            ("cylinder", create_cylinder(radius=0.3, height=1.0), (0, 1.5, 0)),
        ]
        operations = [
            ("union", ["base", "sphere"]),
            ("union", ["_result_union", "cylinder"]),
        ]

        result = hierarchical_combine(components, operations)

        assert isinstance(result, trimesh.Trimesh)

    def test_hierarchical_difference(self) -> None:
        """Test hierarchical combination with difference."""
        components = [
            ("outer", create_box(width=3, height=3, depth=3), (0, 0, 0)),
            ("inner", create_box(width=1, height=1, depth=1), (0, 0, 0)),
        ]
        operations = [("difference", ["outer", "inner"])]

        result = hierarchical_combine(components, operations)

        assert isinstance(result, trimesh.Trimesh)
