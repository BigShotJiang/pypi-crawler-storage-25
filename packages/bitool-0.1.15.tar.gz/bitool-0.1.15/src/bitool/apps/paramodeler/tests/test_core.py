"""Tests for paramodeler core module."""

from pathlib import Path

import pytest

from bitool.apps.paramodeler.core.model_generator import (
    ModelGenerator,
    create_example_script,
)
from bitool.apps.paramodeler.core.parametric import (
    Parameter,
    ParameterType,
    ParametricScript,
    ScriptExecutor,
)


class TestParameter:
    """Tests for Parameter class."""

    def test_float_parameter_validation(self) -> None:
        """Test float parameter validation."""
        param = Parameter(
            name="test",
            param_type=ParameterType.FLOAT,
            default_value=5.0,
            min_value=0.0,
            max_value=10.0,
        )
        assert param.validate(5.0) is True
        assert param.validate(-1.0) is False
        assert param.validate(11.0) is False

    def test_int_parameter_validation(self) -> None:
        """Test int parameter validation."""
        param = Parameter(
            name="count",
            param_type=ParameterType.INT,
            default_value=5,
            min_value=0,
            max_value=10,
        )
        assert param.validate(5) is True
        assert param.validate(5.5) is False

    def test_parameter_clamp(self) -> None:
        """Test parameter value clamping."""
        param = Parameter(
            name="test",
            param_type=ParameterType.FLOAT,
            default_value=5.0,
            min_value=0.0,
            max_value=10.0,
        )
        assert param.clamp(-1.0) == 0.0
        assert param.clamp(11.0) == 10.0
        assert param.clamp(5.0) == 5.0


class TestParametricScript:
    """Tests for ParametricScript class."""

    def test_script_creation(self) -> None:
        """Test basic script creation."""
        script = ParametricScript(name="Test Script", description="A test script")
        assert script.name == "Test Script"
        assert script.description == "A test script"
        assert len(script.parameters) == 0

    def test_add_parameter(self) -> None:
        """Test adding parameters to script."""
        script = ParametricScript(name="Test")
        param = Parameter(
            name="width",
            param_type=ParameterType.FLOAT,
            default_value=1.0,
        )
        script.add_parameter(param)
        assert "width" in script.parameters
        assert script.get_value("width") == 1.0

    def test_set_value(self) -> None:
        """Test setting parameter values."""
        script = ParametricScript(name="Test")
        param = Parameter(
            name="width",
            param_type=ParameterType.FLOAT,
            default_value=1.0,
            min_value=0.0,
            max_value=10.0,
        )
        script.add_parameter(param)

        assert script.set_value("width", 2.0) is True
        assert script.get_value("width") == 2.0

        assert script.set_value("width", -1.0) is False
        assert script.get_value("width") == 2.0

    def test_serialization(self) -> None:
        """Test script serialization to/from dict."""
        script = ParametricScript(
            name="Test Script",
            description="Test",
            script_code="result = box(width=1, height=1, depth=1)",
        )
        script.add_parameter(
            Parameter(
                name="width",
                param_type=ParameterType.FLOAT,
                default_value=1.0,
                min_value=0.0,
                max_value=10.0,
            ),
        )

        data = script.to_dict()
        assert data["name"] == "Test Script"
        assert "width" in data["parameters"]

        loaded = ParametricScript.from_dict(data)
        assert loaded.name == script.name
        assert "width" in loaded.parameters

    def test_save_load(self, tmp_path: Path) -> None:
        """Test saving and loading scripts."""
        script = create_example_script("box_sphere")
        filepath = tmp_path / "test_script.json"

        script.save(str(filepath))
        assert filepath.exists()

        loaded = ParametricScript.load(str(filepath))
        assert loaded.name == script.name
        assert len(loaded.parameters) == len(script.parameters)


class TestScriptExecutor:
    """Tests for ScriptExecutor class."""

    def test_basic_execution(self) -> None:
        """Test basic script execution."""
        executor = ScriptExecutor()
        result = executor.execute("x = 5\ny = 10\nresult = x + y", {})
        assert result == 15

    def test_execution_with_parameters(self) -> None:
        """Test execution with parameters."""
        executor = ScriptExecutor()
        code = "result = width * height"
        result = executor.execute(code, {"width": 2.0, "height": 3.0})
        assert result == 6.0


class TestModelGenerator:
    """Tests for ModelGenerator class."""

    def test_generator_creation(self) -> None:
        """Test model generator initialization."""
        generator = ModelGenerator()
        assert generator is not None
        assert hasattr(generator, "executor")

    def test_generate_box_sphere(self) -> None:
        """Test generating box with sphere example."""
        generator = ModelGenerator()
        script = create_example_script("box_sphere")
        mesh = generator.generate(script)

        assert mesh is not None
        assert len(mesh.vertices) > 0
        assert len(mesh.faces) > 0

    def test_preview_mesh(self) -> None:
        """Test mesh preview information."""
        generator = ModelGenerator()
        script = create_example_script("box_sphere")
        mesh = generator.generate(script)

        assert mesh is not None
        info = generator.preview_mesh(mesh)

        assert "vertices" in info
        assert "faces" in info
        assert "bounds" in info
        assert info["vertices"] > 0
        assert info["faces"] > 0


class TestExampleScripts:
    """Tests for example scripts."""

    def test_box_sphere(self) -> None:
        """Test box with sphere example."""
        script = create_example_script("box_sphere")
        assert script.name == "Box with Sphere"
        assert len(script.parameters) == 4

    def test_cylinder_stack(self) -> None:
        """Test cylinder stack example."""
        script = create_example_script("cylinder_stack")
        assert script.name == "Cylinder Stack"
        assert len(script.parameters) == 4

    def test_gear(self) -> None:
        """Test gear example."""
        script = create_example_script("gear")
        assert script.name == "Simple Gear"
        assert len(script.parameters) == 3

    def test_invalid_example_type(self) -> None:
        """Test invalid example type."""
        with pytest.raises(ValueError):
            create_example_script("invalid_type")
