"""Tests for paramodeler package."""
