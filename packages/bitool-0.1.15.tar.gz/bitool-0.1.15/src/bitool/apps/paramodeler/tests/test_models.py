"""Tests for paramodeler models module."""

import numpy as np
import trimesh

from bitool.apps.paramodeler.models.operations import (
    array_pattern,
    mirror,
    rotate,
    scale,
    translate,
    union,
)
from bitool.apps.paramodeler.models.shapes import (
    create_box,
    create_capsule,
    create_cone,
    create_cylinder,
    create_prism,
    create_sphere,
    create_torus,
    create_uv_sphere,
)


class TestShapes:
    """Tests for shape primitives."""

    def test_create_box(self) -> None:
        """Test box creation."""
        mesh = create_box(width=2.0, height=1.0, depth=1.0)
        assert isinstance(mesh, trimesh.Trimesh)
        assert len(mesh.vertices) > 0
        assert len(mesh.faces) > 0

    def test_create_sphere(self) -> None:
        """Test sphere creation."""
        mesh = create_sphere(radius=1.0, subdivisions=2)
        assert isinstance(mesh, trimesh.Trimesh)
        assert len(mesh.vertices) > 0

    def test_create_cylinder(self) -> None:
        """Test cylinder creation."""
        mesh = create_cylinder(radius=1.0, height=2.0)
        assert isinstance(mesh, trimesh.Trimesh)

    def test_create_cone(self) -> None:
        """Test cone creation."""
        mesh = create_cone(radius=1.0, height=2.0)
        assert isinstance(mesh, trimesh.Trimesh)

    def test_create_torus(self) -> None:
        """Test torus creation."""
        mesh = create_torus(major_radius=2.0, minor_radius=0.5)
        assert isinstance(mesh, trimesh.Trimesh)

    def test_create_capsule(self) -> None:
        """Test capsule creation."""
        mesh = create_capsule(radius=0.5, height=2.0)
        assert isinstance(mesh, trimesh.Trimesh)

    def test_create_prism(self) -> None:
        """Test prism creation."""
        mesh = create_prism(radius=1.0, height=2.0, sides=6)
        assert isinstance(mesh, trimesh.Trimesh)

    def test_create_uv_sphere(self) -> None:
        """Test UV sphere creation."""
        mesh = create_uv_sphere(radius=1.0, count=(16, 8))
        assert isinstance(mesh, trimesh.Trimesh)


class TestOperations:
    """Tests for mesh operations."""

    def test_translate(self) -> None:
        """Test mesh translation."""
        mesh = create_box()
        translated = translate(mesh, (1.0, 2.0, 3.0))

        assert translated is not mesh
        assert len(translated.vertices) == len(mesh.vertices)

    def test_rotate(self) -> None:
        """Test mesh rotation."""
        mesh = create_box()
        rotated = rotate(mesh, np.pi / 2, (0, 0, 1))

        assert rotated is not mesh
        assert len(rotated.vertices) == len(mesh.vertices)

    def test_scale(self) -> None:
        """Test mesh scaling."""
        mesh = create_box()
        scaled = scale(mesh, 2.0)

        assert scaled is not mesh

    def test_union(self) -> None:
        """Test mesh union."""
        box1 = create_box(center=(0, 0, 0))
        box2 = create_box(center=(1, 0, 0))

        result = union(box1, box2)

        assert result is not box1
        assert result is not box2
        assert len(result.vertices) >= len(box1.vertices)

    def test_mirror(self) -> None:
        """Test mesh mirroring."""
        mesh = create_box()
        mirrored = mirror(mesh, (1, 0, 0))

        assert mirrored is not mesh

    def test_array_pattern(self) -> None:
        """Test array pattern creation."""
        mesh = create_box()
        result = array_pattern(mesh, count=(2, 1, 1), spacing=(2.0, 0, 0))

        assert result is not mesh
