"""
3D viewport using PyQt6 and OpenGL for real-time preview
"""

from __future__ import annotations

import numpy as np
import trimesh
from OpenGL.GL import *
from OpenGL.GLU import *

from bitool.gui.compat import (
    QMouseEvent,
    QOpenGLWidget,
    Qt,
    QVector3D,
    QWheelEvent,
    QWidget,
    Signal,
)


class Viewport3D(QOpenGLWidget):
    """OpenGL-based 3D viewport for real-time mesh preview."""

    mesh_updated = Signal(dict)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.mesh: trimesh.Trimesh | None = None
        self.vertices: np.ndarray | None = None
        self.faces: np.ndarray | None = None
        self.indices: np.ndarray | None = None
        self.normals: np.ndarray | None = None

        self.camera_distance = 5.0
        self.camera_azimuth = 45.0
        self.camera_elevation = 30.0
        self.camera_target = QVector3D(0, 0, 0)

        self.last_mouse_pos = None
        self.is_rotating = False
        self.is_panning = False

        self.show_wireframe = False
        self.show_faces = True
        self.background_color = (0.15, 0.15, 0.18, 1.0)
        self.mesh_color = (0.4, 0.7, 1.0, 1.0)
        self.wireframe_color = (0.2, 0.2, 0.2, 1.0)

        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def initializeGL(self) -> None:
        """Initialize OpenGL context."""
        glClearColor(*self.background_color)
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        glEnable(GL_COLOR_MATERIAL)
        glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE)

        glLightfv(GL_LIGHT0, GL_POSITION, [5.0, 5.0, 5.0, 1.0])
        glLightfv(GL_LIGHT0, GL_AMBIENT, [0.3, 0.3, 0.3, 1.0])
        glLightfv(GL_LIGHT0, GL_DIFFUSE, [0.8, 0.8, 0.8, 1.0])
        glLightfv(GL_LIGHT0, GL_SPECULAR, [1.0, 1.0, 1.0, 1.0])

        glShadeModel(GL_SMOOTH)

    def resizeGL(self, width: int, height: int) -> None:
        """Handle window resize."""
        glViewport(0, 0, width, height)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        aspect = width / height if height > 0 else 1.0
        gluPerspective(45.0, aspect, 0.1, 1000.0)
        glMatrixMode(GL_MODELVIEW)

    def paintGL(self) -> None:
        """Render the scene."""
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glLoadIdentity()

        self._setup_camera()
        self._draw_grid()
        self._draw_axes()

        if self.mesh is not None and self.vertices is not None:
            self._draw_mesh()

    def _setup_camera(self) -> None:
        """Set up camera view matrix."""
        azimuth_rad = np.radians(self.camera_azimuth)
        elevation_rad = np.radians(self.camera_elevation)

        x = self.camera_distance * np.cos(elevation_rad) * np.cos(azimuth_rad)
        y = self.camera_distance * np.sin(elevation_rad)
        z = self.camera_distance * np.cos(elevation_rad) * np.sin(azimuth_rad)

        eye = QVector3D(x, y, z) + self.camera_target
        up = QVector3D(0, 1, 0)

        gluLookAt(
            eye.x(),
            eye.y(),
            eye.z(),
            self.camera_target.x(),
            self.camera_target.y(),
            self.camera_target.z(),
            up.x(),
            up.y(),
            up.z(),
        )

    def _draw_grid(self) -> None:
        """Draw a reference grid on the XZ plane."""
        glDisable(GL_LIGHTING)
        glColor4f(0.3, 0.3, 0.3, 0.5)
        glLineWidth(1.0)

        grid_size = 10
        grid_step = 1.0

        glBegin(GL_LINES)
        for i in range(-grid_size, grid_size + 1):
            glVertex3f(i * grid_step, 0, -grid_size * grid_step)
            glVertex3f(i * grid_step, 0, grid_size * grid_step)
            glVertex3f(-grid_size * grid_step, 0, i * grid_step)
            glVertex3f(grid_size * grid_step, 0, i * grid_step)
        glEnd()

        glEnable(GL_LIGHTING)

    def _draw_axes(self) -> None:
        """Draw coordinate axes."""
        glDisable(GL_LIGHTING)
        glLineWidth(2.0)

        axis_length = 2.0

        glBegin(GL_LINES)
        glColor3f(1.0, 0.0, 0.0)
        glVertex3f(0, 0, 0)
        glVertex3f(axis_length, 0, 0)
        glColor3f(0.0, 1.0, 0.0)
        glVertex3f(0, 0, 0)
        glVertex3f(0, axis_length, 0)
        glColor3f(0.0, 0.0, 1.0)
        glVertex3f(0, 0, 0)
        glVertex3f(0, 0, axis_length)
        glEnd()

        glEnable(GL_LIGHTING)

    def _draw_mesh(self) -> None:
        """Draw the 3D mesh."""
        if self.show_faces:
            glEnable(GL_LIGHTING)
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
            glColor4f(*self.mesh_color)

            glEnableClientState(GL_VERTEX_ARRAY)
            glEnableClientState(GL_NORMAL_ARRAY)

            glVertexPointer(3, GL_FLOAT, 0, self.vertices)
            glNormalPointer(GL_FLOAT, 0, self.normals)
            glDrawElements(
                GL_TRIANGLES,
                len(self.indices),
                GL_UNSIGNED_INT,
                self.indices,
            )

            glDisableClientState(GL_VERTEX_ARRAY)
            glDisableClientState(GL_NORMAL_ARRAY)

        if self.show_wireframe:
            glDisable(GL_LIGHTING)
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
            glColor4f(*self.wireframe_color)
            glLineWidth(1.0)

            glEnableClientState(GL_VERTEX_ARRAY)
            glVertexPointer(3, GL_FLOAT, 0, self.vertices)
            glDrawElements(
                GL_TRIANGLES,
                len(self.indices),
                GL_UNSIGNED_INT,
                self.indices,
            )
            glDisableClientState(GL_VERTEX_ARRAY)

        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)

    def set_mesh(self, mesh: trimesh.Trimesh) -> None:
        """Set the mesh to display."""
        self.mesh = mesh

        if mesh is not None:
            self.vertices = mesh.vertices.astype(np.float32).flatten()
            self.faces = mesh.faces.astype(np.uint32)
            self.indices = self.faces.flatten()

            if mesh.vertex_normals is not None and len(mesh.vertex_normals) > 0:
                self.normals = mesh.vertex_normals.astype(np.float32).flatten()
            else:
                self.normals = mesh.vertex_normals.astype(np.float32).flatten()

            bounds = mesh.bounds
            size = np.max(bounds[1] - bounds[0])
            self.camera_distance = max(size * 2, 2.0)

            stats = {
                "vertices": len(mesh.vertices),
                "faces": len(mesh.faces),
                "bounds": bounds.tolist(),
            }
            self.mesh_updated.emit(stats)
        else:
            self.vertices = None
            self.faces = None
            self.indices = None
            self.normals = None

        self.update()

    def clear_mesh(self) -> None:
        """Clear the current mesh."""
        self.set_mesh(None)

    def set_wireframe(self, show: bool) -> None:
        """Toggle wireframe display."""
        self.show_wireframe = show
        self.update()

    def set_show_faces(self, show: bool) -> None:
        """Toggle face display."""
        self.show_faces = show
        self.update()

    def reset_view(self) -> None:
        """Reset camera to default position."""
        self.camera_distance = 5.0
        self.camera_azimuth = 45.0
        self.camera_elevation = 30.0
        self.camera_target = QVector3D(0, 0, 0)
        self.update()

    def mousePressEvent(self, event: QMouseEvent) -> None:
        """Handle mouse press."""
        self.last_mouse_pos = event.pos()

        if event.button() == Qt.MouseButton.LeftButton:
            self.is_rotating = True
        elif event.button() == Qt.MouseButton.RightButton:
            self.is_panning = True

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        """Handle mouse release."""
        if event.button() == Qt.MouseButton.LeftButton:
            self.is_rotating = False
        elif event.button() == Qt.MouseButton.RightButton:
            self.is_panning = False

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        """Handle mouse movement for camera control."""
        if self.last_mouse_pos is None:
            return

        dx = event.pos().x() - self.last_mouse_pos.x()
        dy = event.pos().y() - self.last_mouse_pos.y()

        if self.is_rotating:
            self.camera_azimuth += dx * 0.5
            self.camera_elevation = np.clip(
                self.camera_elevation - dy * 0.5,
                -89.0,
                89.0,
            )
            self.update()

        elif self.is_panning:
            pan_speed = self.camera_distance * 0.001
            azimuth_rad = np.radians(self.camera_azimuth)

            right = QVector3D(-np.sin(azimuth_rad), 0, np.cos(azimuth_rad))
            up = QVector3D(0, 1, 0)

            self.camera_target += right * dx * pan_speed
            self.camera_target += up * (-dy) * pan_speed
            self.update()

        self.last_mouse_pos = event.pos()

    def wheelEvent(self, event: QWheelEvent) -> None:
        """Handle mouse wheel for zooming."""
        delta = event.angleDelta().y()
        zoom_factor = 0.9 if delta > 0 else 1.1
        self.camera_distance *= zoom_factor
        self.camera_distance = max(0.1, min(1000.0, self.camera_distance))
        self.update()

    def keyPressEvent(self, event) -> None:
        """Handle keyboard shortcuts."""
        if event.key() == Qt.Key.Key_W:
            self.show_wireframe = not self.show_wireframe
            self.update()
        elif event.key() == Qt.Key.Key_F:
            self.show_faces = not self.show_faces
            self.update()
        elif event.key() == Qt.Key.Key_R:
            self.reset_view()
        elif event.key() == Qt.Key.Key_Space:
            self.clear_mesh()
        else:
            super().keyPressEvent(event)
