"""
Main application window
"""

from __future__ import annotations

import sys

import trimesh

from bitool.gui.compat import (
    QAction,
    QApplication,
    QComboBox,
    QFileDialog,
    QHBoxLayout,
    QKeySequence,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSplitter,
    QStatusBar,
    Qt,
    QTimer,
    QToolBar,
    QVBoxLayout,
    QWidget,
)

from ..core.model_generator import ModelGenerator, create_example_script
from ..core.parametric import ParametricScript
from .parameter_panel import ParameterPanel
from .viewport import Viewport3D


def main() -> int:
    """Run the Paramodeler GUI application."""
    app = QApplication(sys.argv)
    app.setApplicationName("Paramodeler")

    window = MainWindow()
    window.show()

    return app.exec()


class MainWindow(QMainWindow):
    """Main application window for Paramodeler."""

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Paramodeler - Parametric 3D Model Designer")
        self.setMinimumSize(1200, 800)

        self.model_generator = ModelGenerator()
        self.current_script: ParametricScript | None = None
        self.current_mesh: trimesh.Trimesh | None = None

        self._setup_ui()
        self._setup_menu()
        self._setup_toolbar()
        self._setup_statusbar()

        self.load_example("box_sphere")

    def _setup_ui(self) -> None:
        """Setup the main UI layout."""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(10, 10, 10, 10)

        example_layout = QHBoxLayout()
        example_layout.addWidget(QLabel("Example:"))
        self.example_combo = QComboBox()
        self.example_combo.addItems(
            [
                "Box with Sphere",
                "Cylinder Stack",
                "Simple Gear",
                "Grid Pattern",
                "Radial Pattern",
                "Component Assembly",
                "Hollow Box",
            ],
        )
        self.example_combo.currentIndexChanged.connect(self._on_example_changed)
        example_layout.addWidget(self.example_combo)
        left_layout.addLayout(example_layout)

        self.param_panel = ParameterPanel()
        self.param_panel.generate_requested.connect(self._generate_model)
        left_layout.addWidget(self.param_panel)

        left_panel.setMinimumWidth(350)
        left_panel.setMaximumWidth(450)

        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(0, 0, 0, 0)

        self.viewport = Viewport3D()
        self.viewport.mesh_updated.connect(self._on_mesh_updated)
        right_layout.addWidget(self.viewport)

        info_layout = QHBoxLayout()
        self.info_label = QLabel("No model loaded")
        info_layout.addWidget(self.info_label)
        info_layout.addStretch()

        self.wireframe_btn = QPushButton("Wireframe (W)")
        self.wireframe_btn.setCheckable(True)
        self.wireframe_btn.clicked.connect(self._toggle_wireframe)
        info_layout.addWidget(self.wireframe_btn)

        self.reset_view_btn = QPushButton("Reset View (R)")
        self.reset_view_btn.clicked.connect(self.viewport.reset_view)
        info_layout.addWidget(self.reset_view_btn)

        right_layout.addLayout(info_layout)

        splitter.addWidget(left_panel)
        splitter.addWidget(right_panel)
        splitter.setSizes([400, 800])

        main_layout.addWidget(splitter)

    def _setup_menu(self) -> None:
        """Setup menu bar."""
        menubar = self.menuBar()

        file_menu = menubar.addMenu("&File")

        new_action = QAction("&New Script", self)
        new_action.setShortcut(QKeySequence.StandardKey.New)
        new_action.triggered.connect(self._new_script)
        file_menu.addAction(new_action)

        open_action = QAction("&Open Script...", self)
        open_action.setShortcut(QKeySequence.StandardKey.Open)
        open_action.triggered.connect(self._open_script)
        file_menu.addAction(open_action)

        save_action = QAction("&Save Script...", self)
        save_action.setShortcut(QKeySequence.StandardKey.Save)
        save_action.triggered.connect(self._save_script)
        file_menu.addAction(save_action)

        file_menu.addSeparator()

        export_action = QAction("&Export Model...", self)
        export_action.setShortcut(QKeySequence("Ctrl+E"))
        export_action.triggered.connect(self._export_model)
        file_menu.addAction(export_action)

        file_menu.addSeparator()

        exit_action = QAction("E&xit", self)
        exit_action.setShortcut(QKeySequence.StandardKey.Quit)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        view_menu = menubar.addMenu("&View")

        reset_action = QAction("&Reset View", self)
        reset_action.setShortcut(QKeySequence("R"))
        reset_action.triggered.connect(self.viewport.reset_view)
        view_menu.addAction(reset_action)

        wireframe_action = QAction("&Wireframe", self)
        wireframe_action.setShortcut(QKeySequence("W"))
        wireframe_action.setCheckable(True)
        wireframe_action.triggered.connect(self._toggle_wireframe)
        view_menu.addAction(wireframe_action)
        self.wireframe_action = wireframe_action

        help_menu = menubar.addMenu("&Help")

        about_action = QAction("&About", self)
        about_action.triggered.connect(self._show_about)
        help_menu.addAction(about_action)

    def _setup_toolbar(self) -> None:
        """Setup toolbar."""
        toolbar = QToolBar("Main Toolbar")
        self.addToolBar(toolbar)

        generate_action = QAction("Generate", self)
        generate_action.triggered.connect(self._generate_model)
        toolbar.addAction(generate_action)

        toolbar.addSeparator()

        export_action = QAction("Export", self)
        export_action.triggered.connect(self._export_model)
        toolbar.addAction(export_action)

    def _setup_statusbar(self) -> None:
        """Setup status bar."""
        self.statusbar = QStatusBar()
        self.setStatusBar(self.statusbar)
        self.statusbar.showMessage("Ready")

    def load_example(self, example_type: str) -> None:
        """Load an example script."""
        try:
            self.current_script = create_example_script(example_type)
            self.param_panel.set_script(self.current_script)
            self._generate_model()
            self.statusbar.showMessage(f"Loaded example: {self.current_script.name}")
        except Exception as e:  # noqa: BLE001
            QMessageBox.critical(self, "Error", f"Failed to load example: {e!s}")

    def _on_example_changed(self, index: int) -> None:
        """Handle example selection change."""
        examples = [
            "box_sphere",
            "cylinder_stack",
            "gear",
            "grid",
            "radial",
            "assembly",
            "hollow_box",
        ]
        if 0 <= index < len(examples):
            self.load_example(examples[index])

    def _generate_model(self) -> None:
        """Generate the 3D model from current script."""
        if self.current_script is None:
            return

        self.statusbar.showMessage("Generating model...")
        QTimer.singleShot(10, self._do_generate)

    def _do_generate(self) -> None:
        """Perform actual model generation."""
        try:
            mesh = self.model_generator.generate(self.current_script)

            if mesh is not None:
                self.current_mesh = mesh
                self.viewport.set_mesh(mesh)
                self.statusbar.showMessage(
                    f"Model generated: {len(mesh.vertices)} vertices, {len(mesh.faces)} faces",
                )
            else:
                self.statusbar.showMessage("Failed to generate model")

        except Exception as e:  # noqa: BLE001
            QMessageBox.critical(
                self,
                "Generation Error",
                f"Error generating model:\n{e!s}",
            )
            self.statusbar.showMessage("Generation failed")

    def _on_mesh_updated(self, stats: dict) -> None:
        """Handle mesh update from viewport."""
        info = f"Vertices: {stats['vertices']}, Faces: {stats['faces']}"
        self.info_label.setText(info)

    def _toggle_wireframe(self, checked: bool | None = None) -> None:
        """Toggle wireframe display."""
        if checked is None:
            checked = not self.viewport.show_wireframe
        self.viewport.set_wireframe(checked)
        self.wireframe_btn.setChecked(checked)
        self.wireframe_action.setChecked(checked)

    def _new_script(self) -> None:
        """Create a new empty script."""
        self.current_script = ParametricScript(
            name="New Script",
            description="A new parametric script",
        )
        self.param_panel.set_script(self.current_script)
        self.viewport.clear_mesh()
        self.statusbar.showMessage("Created new script")

    def _open_script(self) -> None:
        """Open a script from file."""
        filepath, _ = QFileDialog.getOpenFileName(
            self,
            "Open Script",
            "",
            "JSON Files (*.json);;All Files (*)",
        )

        if filepath:
            try:
                self.current_script = ParametricScript.load(filepath)
                self.param_panel.set_script(self.current_script)
                self._generate_model()
                self.statusbar.showMessage(f"Opened: {filepath}")
            except Exception as e:  # noqa: BLE001
                QMessageBox.critical(self, "Error", f"Failed to open script:\n{e!s}")

    def _save_script(self) -> None:
        """Save current script to file."""
        if self.current_script is None:
            QMessageBox.warning(self, "Warning", "No script to save")
            return

        filepath, _ = QFileDialog.getSaveFileName(
            self,
            "Save Script",
            "",
            "JSON Files (*.json);;All Files (*)",
        )

        if filepath:
            try:
                if not filepath.endswith(".json"):
                    filepath += ".json"
                self.current_script.save(filepath)
                self.statusbar.showMessage(f"Saved: {filepath}")
            except Exception as e:  # noqa: BLE001
                QMessageBox.critical(self, "Error", f"Failed to save script:\n{e!s}")

    def _export_model(self) -> None:
        """Export current model to file."""
        if self.current_mesh is None:
            QMessageBox.warning(self, "Warning", "No model to export")
            return

        filepath, _ = QFileDialog.getSaveFileName(
            self,
            "Export Model",
            "",
            "STL Files (*.stl);;OBJ Files (*.obj);;PLY Files (*.ply);;GLB Files (*.glb);;All Files (*)",
        )

        if filepath:
            try:
                self.current_mesh.export(filepath)
                self.statusbar.showMessage(f"Exported: {filepath}")
            except Exception as e:  # noqa: BLE001
                QMessageBox.critical(self, "Error", f"Failed to export model:\n{e!s}")

    def _show_about(self) -> None:
        """Show about dialog."""
        QMessageBox.about(
            self,
            "About Paramodeler",
            """<h2>Paramodeler 0.1.0</h2>
            <p>A parametric 3D model design tool</p>
            <p>Features:</p>
            <ul>
                <li>Parametric script-based model generation</li>
                <li>Real-time 3D preview with OpenGL</li>
                <li>Visual parameter adjustment</li>
                <li>Export to standard 3D formats</li>
            </ul>
            <p>Built with Python, PyQt6, and Trimesh</p>
            """,
        )
