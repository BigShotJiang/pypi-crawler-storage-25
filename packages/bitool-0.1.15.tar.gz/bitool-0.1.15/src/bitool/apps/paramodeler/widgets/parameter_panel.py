"""
Parameter panel for visual parameter adjustment
"""

from __future__ import annotations

from typing import Any

from bitool.gui.compat import (
    QCheckBox,
    QColor,
    QColorDialog,
    QComboBox,
    QDoubleSpinBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QSlider,
    QSpinBox,
    Qt,
    QTimer,
    QVBoxLayout,
    QWidget,
    Signal,
)

from ..core.parametric import Parameter, ParameterType, ParametricScript


class ParameterWidget(QWidget):
    """Base class for parameter widgets."""

    value_changed = Signal(str, object)

    def __init__(self, parameter: Parameter, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.parameter = parameter
        self.param_name = parameter.name
        self._setup_ui()

    def _setup_ui(self) -> None:
        """Setup the UI - to be implemented by subclasses."""
        raise NotImplementedError

    def get_value(self) -> Any:
        """Get current value - to be implemented by subclasses."""
        raise NotImplementedError

    def set_value(self, value: Any) -> None:
        """Set current value - to be implemented by subclasses."""
        raise NotImplementedError


class FloatParameterWidget(ParameterWidget):
    """Widget for float parameters with slider and spinbox."""

    def _setup_ui(self) -> None:
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.label = QLabel(f"{self.parameter.name}:")
        self.label.setToolTip(self.parameter.description)
        layout.addWidget(self.label)

        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setMinimum(0)
        self.slider.setMaximum(1000)
        self.slider.setValue(500)
        layout.addWidget(self.slider)

        self.spinbox = QDoubleSpinBox()
        if self.parameter.min_value is not None:
            self.spinbox.setMinimum(self.parameter.min_value)
        else:
            self.spinbox.setMinimum(-999999)
        if self.parameter.max_value is not None:
            self.spinbox.setMaximum(self.parameter.max_value)
        else:
            self.spinbox.setMaximum(999999)
        if self.parameter.step is not None:
            self.spinbox.setSingleStep(self.parameter.step)
        else:
            self.spinbox.setSingleStep(0.1)
        self.spinbox.setDecimals(3)
        self.spinbox.setValue(self.parameter.default_value)
        layout.addWidget(self.spinbox)

        self.slider.valueChanged.connect(self._on_slider_changed)
        self.spinbox.valueChanged.connect(self._on_spinbox_changed)

        self._min = (
            self.parameter.min_value if self.parameter.min_value is not None else 0.0
        )
        self._max = (
            self.parameter.max_value if self.parameter.max_value is not None else 100.0
        )

    def _on_slider_changed(self, value: int) -> None:
        """Handle slider change."""
        normalized = value / 1000.0
        new_value = self._min + normalized * (self._max - self._min)
        self.spinbox.blockSignals(True)
        self.spinbox.setValue(new_value)
        self.spinbox.blockSignals(False)
        self.value_changed.emit(self.param_name, new_value)

    def _on_spinbox_changed(self, value: float) -> None:
        """Handle spinbox change."""
        normalized = (
            (value - self._min) / (self._max - self._min)
            if self._max != self._min
            else 0.5
        )
        slider_value = int(normalized * 1000)
        self.slider.blockSignals(True)
        self.slider.setValue(slider_value)
        self.slider.blockSignals(False)
        self.value_changed.emit(self.param_name, value)

    def get_value(self) -> float:
        return self.spinbox.value()

    def set_value(self, value: float) -> None:
        self.spinbox.setValue(value)


class IntParameterWidget(ParameterWidget):
    """Widget for integer parameters."""

    def _setup_ui(self) -> None:
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.label = QLabel(f"{self.parameter.name}:")
        self.label.setToolTip(self.parameter.description)
        layout.addWidget(self.label)

        self.slider = QSlider(Qt.Orientation.Horizontal)
        min_val = (
            self.parameter.min_value if self.parameter.min_value is not None else 0
        )
        max_val = (
            self.parameter.max_value if self.parameter.max_value is not None else 100
        )
        self.slider.setMinimum(min_val)
        self.slider.setMaximum(max_val)
        self.slider.setValue(self.parameter.default_value)
        layout.addWidget(self.slider)

        self.spinbox = QSpinBox()
        self.spinbox.setMinimum(min_val)
        self.spinbox.setMaximum(max_val)
        if self.parameter.step is not None:
            self.spinbox.setSingleStep(self.parameter.step)
        self.spinbox.setValue(self.parameter.default_value)
        layout.addWidget(self.spinbox)

        self.slider.valueChanged.connect(self._on_slider_changed)
        self.spinbox.valueChanged.connect(self._on_spinbox_changed)

    def _on_slider_changed(self, value: int) -> None:
        self.spinbox.blockSignals(True)
        self.spinbox.setValue(value)
        self.spinbox.blockSignals(False)
        self.value_changed.emit(self.param_name, value)

    def _on_spinbox_changed(self, value: int) -> None:
        self.slider.blockSignals(True)
        self.slider.setValue(value)
        self.slider.blockSignals(False)
        self.value_changed.emit(self.param_name, value)

    def get_value(self) -> int:
        return self.spinbox.value()

    def set_value(self, value: int) -> None:
        self.spinbox.setValue(value)


class BoolParameterWidget(ParameterWidget):
    """Widget for boolean parameters."""

    def _setup_ui(self) -> None:
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.checkbox = QCheckBox(self.parameter.name)
        self.checkbox.setToolTip(self.parameter.description)
        self.checkbox.setChecked(self.parameter.default_value)
        layout.addWidget(self.checkbox)
        layout.addStretch()

        self.checkbox.stateChanged.connect(self._on_changed)

    def _on_changed(self, state: int) -> None:
        value = state == Qt.CheckState.Checked.value
        self.value_changed.emit(self.param_name, value)

    def get_value(self) -> bool:
        return self.checkbox.isChecked()

    def set_value(self, value: bool) -> None:
        self.checkbox.setChecked(value)


class StringParameterWidget(ParameterWidget):
    """Widget for string parameters."""

    def _setup_ui(self) -> None:
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.label = QLabel(f"{self.parameter.name}:")
        self.label.setToolTip(self.parameter.description)
        layout.addWidget(self.label)

        if self.parameter.options:
            self.combobox = QComboBox()
            self.combobox.addItems(self.parameter.options)
            self.combobox.setCurrentText(self.parameter.default_value)
            self.combobox.currentTextChanged.connect(self._on_changed)
            layout.addWidget(self.combobox)
        else:
            self.lineedit = QLineEdit()
            self.lineedit.setText(self.parameter.default_value)
            self.lineedit.textChanged.connect(self._on_changed)
            layout.addWidget(self.lineedit)

        layout.addStretch()

    def _on_changed(self, value: str) -> None:
        self.value_changed.emit(self.param_name, value)

    def get_value(self) -> str:
        if hasattr(self, "combobox"):
            return self.combobox.currentText()
        return self.lineedit.text()

    def set_value(self, value: str) -> None:
        if hasattr(self, "combobox"):
            self.combobox.setCurrentText(value)
        else:
            self.lineedit.setText(value)


class ColorParameterWidget(ParameterWidget):
    """Widget for color parameters (RGB/RGBA)."""

    def _setup_ui(self) -> None:
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.label = QLabel(f"{self.parameter.name}:")
        self.label.setToolTip(self.parameter.description)
        layout.addWidget(self.label)

        self.color_btn = QPushButton()
        self.color_btn.setFixedSize(30, 20)
        self._update_color_preview(self.parameter.default_value)
        self.color_btn.clicked.connect(self._on_color_clicked)
        layout.addWidget(self.color_btn)

        self.r_spin = QSpinBox()
        self.g_spin = QSpinBox()
        self.b_spin = QSpinBox()

        for spin in [self.r_spin, self.g_spin, self.b_spin]:
            spin.setRange(0, 255)
            spin.setFixedWidth(50)
            layout.addWidget(spin)

        default = self.parameter.default_value
        self.r_spin.setValue(int(default[0] * 255))
        self.g_spin.setValue(int(default[1] * 255))
        self.b_spin.setValue(int(default[2] * 255))

        self.r_spin.valueChanged.connect(self._on_value_changed)
        self.g_spin.valueChanged.connect(self._on_value_changed)
        self.b_spin.valueChanged.connect(self._on_value_changed)

        layout.addStretch()

    def _update_color_preview(self, color: list) -> None:
        """Update color preview button."""
        r, g, b = int(color[0] * 255), int(color[1] * 255), int(color[2] * 255)
        self.color_btn.setStyleSheet(
            f"background-color: rgb({r}, {g}, {b}); border: 1px solid black;",
        )

    def _on_color_clicked(self) -> None:
        """Open color picker dialog."""
        current = self.get_value()
        color = QColorDialog.getColor(
            QColor(int(current[0] * 255), int(current[1] * 255), int(current[2] * 255)),
            self,
        )
        if color.isValid():
            self.r_spin.setValue(color.red())
            self.g_spin.setValue(color.green())
            self.b_spin.setValue(color.blue())

    def _on_value_changed(self) -> None:
        """Handle value change."""
        value = self.get_value()
        self._update_color_preview(value)
        self.value_changed.emit(self.param_name, value)

    def get_value(self) -> list:
        return [
            self.r_spin.value() / 255.0,
            self.g_spin.value() / 255.0,
            self.b_spin.value() / 255.0,
        ]

    def set_value(self, value: list) -> None:
        self.r_spin.setValue(int(value[0] * 255))
        self.g_spin.setValue(int(value[1] * 255))
        self.b_spin.setValue(int(value[2] * 255))


class Vector3ParameterWidget(ParameterWidget):
    """Widget for 3D vector parameters."""

    def _setup_ui(self) -> None:
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.label = QLabel(f"{self.parameter.name}:")
        self.label.setToolTip(self.parameter.description)
        layout.addWidget(self.label)

        self.x_spin = QDoubleSpinBox()
        self.y_spin = QDoubleSpinBox()
        self.z_spin = QDoubleSpinBox()

        for spin, label in [(self.x_spin, "X"), (self.y_spin, "Y"), (self.z_spin, "Z")]:
            spin.setRange(-9999, 9999)
            spin.setDecimals(3)
            spin.setSingleStep(0.1)
            spin.setFixedWidth(70)
            spin.setPrefix(f"{label}:")
            layout.addWidget(spin)

        default = self.parameter.default_value
        self.x_spin.setValue(default[0])
        self.y_spin.setValue(default[1])
        self.z_spin.setValue(default[2])

        self.x_spin.valueChanged.connect(self._on_value_changed)
        self.y_spin.valueChanged.connect(self._on_value_changed)
        self.z_spin.valueChanged.connect(self._on_value_changed)

        layout.addStretch()

    def _on_value_changed(self) -> None:
        value = self.get_value()
        self.value_changed.emit(self.param_name, value)

    def get_value(self) -> list:
        return [self.x_spin.value(), self.y_spin.value(), self.z_spin.value()]

    def set_value(self, value: list) -> None:
        self.x_spin.setValue(value[0])
        self.y_spin.setValue(value[1])
        self.z_spin.setValue(value[2])


class ParameterPanel(QWidget):
    """Panel for displaying and editing parameters."""

    parameter_changed = Signal(str, object)
    generate_requested = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.script: ParametricScript | None = None
        self.param_widgets: dict[str, ParameterWidget] = {}
        self._setup_ui()

        self._update_timer = QTimer()
        self._update_timer.setSingleShot(True)
        self._update_timer.timeout.connect(self._on_update_timeout)
        self._pending_updates: dict[str, Any] = {}

    def _setup_ui(self) -> None:
        """Setup the panel UI."""
        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        title = QLabel("Parameters")
        title.setStyleSheet("font-weight: bold; font-size: 14px;")
        layout.addWidget(title)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)

        self.params_container = QWidget()
        self.params_layout = QVBoxLayout(self.params_container)
        self.params_layout.setSpacing(5)
        self.params_layout.addStretch()

        scroll.setWidget(self.params_container)
        layout.addWidget(scroll)

        self.generate_btn = QPushButton("Generate Model")
        self.generate_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                padding: 10px;
                font-weight: bold;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        self.generate_btn.clicked.connect(self.generate_requested.emit)
        layout.addWidget(self.generate_btn)

        self.auto_update = QCheckBox("Auto-update")
        self.auto_update.setChecked(True)
        layout.addWidget(self.auto_update)

    def set_script(self, script: ParametricScript) -> None:
        """Set the current script and create parameter widgets."""
        self.script = script
        self._clear_widgets()

        if script is None:
            return

        for name, param in script.parameters.items():
            widget = self._create_widget_for_param(param)
            if widget:
                self.param_widgets[name] = widget
                widget.value_changed.connect(self._on_param_changed)
                self.params_layout.insertWidget(self.params_layout.count() - 1, widget)

    def _create_widget_for_param(self, param: Parameter) -> ParameterWidget | None:
        """Create appropriate widget for parameter type."""
        if param.param_type == ParameterType.FLOAT:
            return FloatParameterWidget(param)
        elif param.param_type == ParameterType.INT:
            return IntParameterWidget(param)
        elif param.param_type == ParameterType.BOOL:
            return BoolParameterWidget(param)
        elif param.param_type == ParameterType.STRING:
            return StringParameterWidget(param)
        elif param.param_type == ParameterType.COLOR:
            return ColorParameterWidget(param)
        elif param.param_type == ParameterType.VECTOR3:
            return Vector3ParameterWidget(param)
        return None

    def _clear_widgets(self) -> None:
        """Clear all parameter widgets."""
        for widget in self.param_widgets.values():
            widget.deleteLater()
        self.param_widgets.clear()

    def _on_param_changed(self, name: str, value: Any) -> None:
        """Handle parameter value change."""
        if self.script:
            self.script.set_value(name, value)

        if self.auto_update.isChecked():
            self._pending_updates[name] = value
            self._update_timer.start(100)

    def _on_update_timeout(self) -> None:
        """Handle update timer timeout."""
        if self._pending_updates:
            self.generate_requested.emit()
            self._pending_updates.clear()

    def get_current_values(self) -> dict[str, Any]:
        """Get all current parameter values."""
        return {name: widget.get_value() for name, widget in self.param_widgets.items()}

    def set_param_value(self, name: str, value: Any) -> None:
        """Set a specific parameter value."""
        if name in self.param_widgets:
            self.param_widgets[name].set_value(value)
            if self.script:
                self.script.set_value(name, value)
