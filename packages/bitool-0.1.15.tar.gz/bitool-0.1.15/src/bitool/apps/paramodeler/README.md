# Paramodeler - Parametric 3D Model Designer

A powerful parametric 3D model design tool built with Python, PyQt6, and Trimesh.

## Features

- **Parametric Script-Based Modeling**: Define 3D models using Python scripts with customizable parameters
- **Real-Time 3D Preview**: Interactive OpenGL viewport with smooth camera controls
- **Visual Parameter Adjustment**: Intuitive UI for adjusting parameters with sliders, spinboxes, and color pickers
- **Multiple Primitives**: Box, Sphere, Cylinder, Cone, Torus, Capsule, and more
- **Boolean Operations**: Union, Difference, Intersection
- **Transformations**: Translate, Rotate, Scale, Mirror, Array patterns
- **Export Support**: Export to STL, OBJ, PLY, GLB formats

## Installation

### Prerequisites

- Python 3.11 or higher
- UV package manager

### Setup

1. Clone or navigate to the project directory:
```bash
cd paramodeler
```

2. Install dependencies using UV:
```bash
uv sync
```

## Usage

### Running the Application

```bash
uv run paramodeler
```

Or activate the virtual environment and run:
```bash
.venv\Scripts\activate
python -m paramodeler
```

### Basic Workflow

1. **Select an Example**: Choose from predefined examples (Box with Sphere, Cylinder Stack, Simple Gear)
2. **Adjust Parameters**: Use the parameter panel on the left to modify values
3. **View in 3D**: The 3D viewport on the right updates in real-time
4. **Export**: Save your model to various 3D formats

### Creating Custom Scripts

You can create custom parametric scripts by defining parameters and writing Python code:

```python
# Example: Create a custom shape
base = box(width=width, height=height, depth=depth)
sphere_top = sphere(radius=sphere_r, center=(0, height/2 + sphere_r, 0))
result = union(base, sphere_top)
```

Available primitives:
- `box(width, height, depth, center)`
- `sphere(radius, center, subdivisions)`
- `cylinder(radius, height, center, segments)`
- `cone(radius, height, center, segments)`
- `torus(major_radius, minor_radius, center)`
- `capsule(radius, height, center)`

Available operations:
- `translate(mesh, (x, y, z))`
- `rotate(mesh, angle, axis, point)`
- `scale(mesh, factor)`
- `union(mesh1, mesh2)`
- `difference(mesh1, mesh2)`
- `intersection(mesh1, mesh2)`
- `mirror(mesh, axis)`
- `array(mesh, count, spacing)`

## Controls

### 3D Viewport

- **Left Mouse + Drag**: Rotate camera
- **Right Mouse + Drag**: Pan camera
- **Mouse Wheel**: Zoom in/out
- **W**: Toggle wireframe
- **F**: Toggle faces
- **R**: Reset view
- **Space**: Clear mesh

### Parameter Panel

- **Sliders**: Quick visual adjustment
- **SpinBoxes**: Precise numeric input
- **Auto-update**: Enable/disable automatic model regeneration
- **Generate Button**: Manually trigger model generation

## Project Structure

```
paramodeler/
├── src/
│   └── paramodeler/
│       ├── __init__.py
│       ├── main.py              # Entry point
│       ├── core/
│       │   ├── __init__.py
│       │   ├── parametric.py    # Parameter system
│       │   └── model_generator.py  # Model generation
│       ├── primitives/
│       │   ├── __init__.py
│       │   ├── shapes.py        # 3D primitives
│       │   └── operations.py    # Mesh operations
│       └── gui/
│           ├── __init__.py
│           ├── main_window.py   # Main UI
│           ├── viewport.py      # 3D viewport
│           └── parameter_panel.py  # Parameter controls
├── examples/                    # Example scripts
├── pyproject.toml
└── README.md
```

## License

MIT License

## Contributing

Contributions are welcome! Please feel free to submit issues and pull requests.
