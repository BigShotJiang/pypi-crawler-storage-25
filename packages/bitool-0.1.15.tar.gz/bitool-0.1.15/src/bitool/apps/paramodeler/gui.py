"""Main GUI entry point for Paramodeler."""

from __future__ import annotations

import sys

from .widgets.main_window import main

if __name__ == "__main__":
    sys.exit(main())
