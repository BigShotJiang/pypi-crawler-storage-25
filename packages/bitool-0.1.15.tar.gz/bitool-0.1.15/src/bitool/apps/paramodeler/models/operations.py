"""
3D mesh operations and transformations
"""

from __future__ import annotations

import numpy as np
import trimesh


def translate(
    mesh: trimesh.Trimesh,
    translation: tuple[float, float, float],
) -> trimesh.Trimesh:
    """Translate a mesh."""
    result = mesh.copy()
    result.apply_translation(translation)
    return result


def rotate(
    mesh: trimesh.Trimesh,
    angle: float,
    axis: tuple[float, float, float] = (0, 0, 1),
    point: tuple[float, float, float] = (0, 0, 0),
) -> trimesh.Trimesh:
    """Rotate a mesh around an axis."""
    result = mesh.copy()
    result.apply_transform(trimesh.transformations.rotation_matrix(angle, axis, point))
    return result


def scale(
    mesh: trimesh.Trimesh,
    scale_factors: float | tuple[float, float, float],
) -> trimesh.Trimesh:
    """Scale a mesh."""
    result = mesh.copy()
    if isinstance(scale_factors, (int, float)):
        scale_factors = (scale_factors, scale_factors, scale_factors)
    result.apply_scale(scale_factors)
    return result


def union(mesh1: trimesh.Trimesh, mesh2: trimesh.Trimesh) -> trimesh.Trimesh:
    """Boolean union of two meshes."""
    return trimesh.util.concatenate([mesh1, mesh2])


def difference(mesh1: trimesh.Trimesh, mesh2: trimesh.Trimesh) -> trimesh.Trimesh:
    """Boolean difference (mesh1 - mesh2)."""
    try:
        result = mesh1.difference(mesh2)
        return result if result is not None else mesh1.copy()
    except Exception:  # noqa: BLE001
        return mesh1.copy()


def intersection(mesh1: trimesh.Trimesh, mesh2: trimesh.Trimesh) -> trimesh.Trimesh:
    """Boolean intersection of two meshes."""
    try:
        result = mesh1.intersection(mesh2)
        return result if result is not None else mesh1.copy()
    except Exception:  # noqa: BLE001
        return mesh1.copy()


def extrude_polygon(
    polygon_points: list[tuple[float, float]],
    height: float,
    center: tuple[float, float, float] = (0, 0, 0),
) -> trimesh.Trimesh:
    """Extrude a 2D polygon into 3D."""
    mesh = trimesh.creation.extrude_polygon(polygon_points, height=height)
    mesh.apply_translation(center)
    return mesh


def extrude_path(
    path_points: list[tuple[float, float, float]],
    radius: float = 0.1,
    sections: int = 8,
) -> trimesh.Trimesh:
    """Create a tube along a path."""
    path = np.array(path_points)
    mesh = trimesh.creation.sweep_polygon(
        trimesh.creation.ellipse(radius, radius),
        path,
    )
    return mesh


def revolve(
    points: list[tuple[float, float]],
    angle: float = 2 * np.pi,
    axis: tuple[float, float, float] = (0, 1, 0),
    sections: int = 32,
) -> trimesh.Trimesh:
    """Revolve a 2D profile around an axis."""
    vertices_3d = [(r, h, 0) for r, h in points]

    mesh = trimesh.creation.revolve(
        vertices_3d,
        angle=angle,
        sections=sections,
        transform=None,
    )
    return mesh


def mirror(
    mesh: trimesh.Trimesh,
    axis: tuple[float, float, float] = (1, 0, 0),
) -> trimesh.Trimesh:
    """Mirror a mesh across a plane."""
    result = mesh.copy()

    axis = np.array(axis, dtype=float)
    axis = axis / np.linalg.norm(axis)

    reflection = np.eye(4)
    reflection[:3, :3] = np.eye(3) - 2 * np.outer(axis, axis)

    result.apply_transform(reflection)
    return result


def array_pattern(
    mesh: trimesh.Trimesh,
    count: tuple[int, int, int] = (3, 1, 1),
    spacing: tuple[float, float, float] = (1.0, 0.0, 0.0),
) -> trimesh.Trimesh:
    """Create an array of meshes."""
    meshes = []

    for i in range(count[0]):
        for j in range(count[1]):
            for k in range(count[2]):
                copy = mesh.copy()
                translation = (i * spacing[0], j * spacing[1], k * spacing[2])
                copy.apply_translation(translation)
                meshes.append(copy)

    return trimesh.util.concatenate(meshes)


def smooth_subdivide(mesh: trimesh.Trimesh, iterations: int = 1) -> trimesh.Trimesh:
    """Subdivide and smooth a mesh."""
    result = mesh.copy()
    for _ in range(iterations):
        result = result.subdivide()
    return result


def decimate(mesh: trimesh.Trimesh, target_faces: int) -> trimesh.Trimesh:
    """Reduce mesh complexity."""
    if len(mesh.faces) <= target_faces:
        return mesh.copy()

    result = mesh.simplify_quadric_decimation(target_faces)
    return result if result is not None else mesh.copy()
