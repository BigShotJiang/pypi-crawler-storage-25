"""
Basic 3D shape primitives using trimesh
"""

from __future__ import annotations

import trimesh


def create_box(
    width: float = 1.0,
    height: float = 1.0,
    depth: float = 1.0,
    center: tuple[float, float, float] = (0, 0, 0),
) -> trimesh.Trimesh:
    """Create a box primitive."""
    mesh = trimesh.creation.box(extents=[width, height, depth])
    mesh.apply_translation(center)
    return mesh


def create_sphere(
    radius: float = 1.0,
    center: tuple[float, float, float] = (0, 0, 0),
    subdivisions: int = 2,
) -> trimesh.Trimesh:
    """Create a sphere primitive."""
    mesh = trimesh.creation.icosphere(subdivisions=subdivisions, radius=radius)
    mesh.apply_translation(center)
    return mesh


def create_cylinder(
    radius: float = 1.0,
    height: float = 2.0,
    center: tuple[float, float, float] = (0, 0, 0),
    segments: int = 32,
) -> trimesh.Trimesh:
    """Create a cylinder primitive."""
    mesh = trimesh.creation.cylinder(radius=radius, height=height, sections=segments)
    mesh.apply_translation(center)
    return mesh


def create_cone(
    radius: float = 1.0,
    height: float = 2.0,
    center: tuple[float, float, float] = (0, 0, 0),
    segments: int = 32,
) -> trimesh.Trimesh:
    """Create a cone primitive."""
    mesh = trimesh.creation.cone(radius=radius, height=height, sections=segments)
    mesh.apply_translation([0, height / 2, 0])
    mesh.apply_translation(center)
    return mesh


def create_torus(
    major_radius: float = 2.0,
    minor_radius: float = 0.5,
    center: tuple[float, float, float] = (0, 0, 0),
    major_segments: int = 32,
    minor_segments: int = 16,
) -> trimesh.Trimesh:
    """Create a torus primitive."""
    mesh = trimesh.creation.torus(
        major_radius=major_radius,
        minor_radius=minor_radius,
        major_sections=major_segments,
        minor_sections=minor_segments,
    )
    mesh.apply_translation(center)
    return mesh


def create_capsule(
    radius: float = 0.5,
    height: float = 2.0,
    center: tuple[float, float, float] = (0, 0, 0),
    count: tuple[int, int] = (16, 16),
) -> trimesh.Trimesh:
    """Create a capsule primitive (cylinder with hemispherical ends)."""
    mesh = trimesh.creation.capsule(radius=radius, height=height, count=count)
    mesh.apply_translation(center)
    return mesh


def create_prism(
    radius: float = 1.0,
    height: float = 2.0,
    sides: int = 6,
    center: tuple[float, float, float] = (0, 0, 0),
) -> trimesh.Trimesh:
    """Create a prism with polygonal base."""
    import numpy as np

    angles = np.linspace(0, 2 * np.pi, sides, endpoint=False)
    vertices = []
    for angle in angles:
        vertices.append([radius * np.cos(angle), radius * np.sin(angle), 0])
        vertices.append([radius * np.cos(angle), radius * np.sin(angle), height])
    vertices = np.array(vertices)

    faces = []
    for i in range(sides):
        next_i = (i + 1) % sides
        faces.append([i * 2, next_i * 2, next_i * 2 + 1])
        faces.append([i * 2, next_i * 2 + 1, i * 2 + 1])

    mesh = trimesh.Trimesh(vertices=vertices, faces=faces)
    mesh.apply_translation(center)
    return mesh


def create_uv_sphere(
    radius: float = 1.0,
    center: tuple[float, float, float] = (0, 0, 0),
    count: tuple[int, int] = (32, 16),
) -> trimesh.Trimesh:
    """Create a UV sphere (latitude/longitude based)."""
    mesh = trimesh.creation.uv_sphere(radius=radius, count=count)
    mesh.apply_translation(center)
    return mesh
