"""
Enhanced operations for multi-structure composition.
"""

from __future__ import annotations

from typing import Callable

import numpy as np
import trimesh


def batch_union(meshes: list[trimesh.Trimesh]) -> trimesh.Trimesh:
    """
    Batch union operation on multiple meshes.

    Args:
        meshes: List of meshes to combine

    Returns:
        Combined mesh
    """
    if not meshes:
        raise ValueError("At least one mesh is required")
    if len(meshes) == 1:
        return meshes[0].copy()

    result = meshes[0].copy()
    for mesh in meshes[1:]:
        result = trimesh.util.concatenate([result, mesh])
    return result


def batch_difference(
    base_mesh: trimesh.Trimesh,
    cutters: list[trimesh.Trimesh],
) -> trimesh.Trimesh:
    """
    Batch difference operation - subtract multiple cutters from base mesh.

    Args:
        base_mesh: The base mesh to subtract from
        cutters: List of meshes to subtract

    Returns:
        Result mesh after all subtractions
    """
    result = base_mesh.copy()
    for cutter in cutters:
        try:
            result = result.difference(cutter)
            if result is None:
                break
        except Exception:  # noqa: BLE001, S112
            continue
    return result if result is not None else base_mesh.copy()


def batch_intersection(meshes: list[trimesh.Trimesh]) -> trimesh.Trimesh | None:
    """
    Batch intersection operation on multiple meshes.

    Args:
        meshes: List of meshes to intersect

    Returns:
        Intersection result or None if no intersection
    """
    if not meshes:
        raise ValueError("At least one mesh is required")
    if len(meshes) == 1:
        return meshes[0].copy()

    result = meshes[0].copy()
    for mesh in meshes[1:]:
        try:
            result = result.intersection(mesh)
            if result is None:
                return None
        except Exception:  # noqa: BLE001
            return None
    return result


def compose_transform(
    mesh: trimesh.Trimesh,
    operations: list[tuple[str, tuple]],
) -> trimesh.Trimesh:
    """
    Apply a sequence of transformations to a mesh.

    Args:
        mesh: The mesh to transform
        operations: List of (operation_name, args) tuples
                    e.g., [("translate", ((1, 0, 0),)), ("rotate", (np.pi/2, (0, 1, 0)))]

    Returns:
        Transformed mesh
    """
    result = mesh.copy()

    operation_map: dict[str, Callable] = {
        "translate": translate,
        "rotate": rotate,
        "scale": scale,
        "mirror": mirror,
    }

    for op_name, args in operations:
        if op_name in operation_map:
            result = operation_map[op_name](result, *args)

    return result


def instanced_array(
    mesh: trimesh.Trimesh,
    positions: list[tuple[float, float, float]],
    rotations: list[float] | None = None,
    scales: list[float | tuple[float, float, float]] | None = None,
) -> trimesh.Trimesh:
    """
    Create an array of mesh instances with individual transforms.

    Args:
        mesh: Base mesh to instance
        positions: List of positions for each instance
        rotations: Optional list of rotation angles (in radians around Z-axis)
        scales: Optional list of scales for each instance

    Returns:
        Combined mesh of all instances
    """
    instances = []
    num_instances = len(positions)

    for i in range(num_instances):
        instance = mesh.copy()

        if scales is not None and i < len(scales):
            instance = scale(instance, scales[i])

        if rotations is not None and i < len(rotations):
            instance = rotate(instance, rotations[i], (0, 1, 0))

        instance = translate(instance, positions[i])
        instances.append(instance)

    return trimesh.util.concatenate(instances)


def grid_pattern(
    mesh: trimesh.Trimesh,
    grid_size: tuple[int, int, int] = (3, 3, 1),
    spacing: tuple[float, float, float] = (1.0, 1.0, 1.0),
    offset: tuple[float, float, float] = (0, 0, 0),
) -> trimesh.Trimesh:
    """
    Create a regular grid pattern of meshes.

    Args:
        mesh: Base mesh
        grid_size: Number of elements in each dimension (x, y, z)
        spacing: Spacing between elements
        offset: Offset from origin

    Returns:
        Combined mesh with grid pattern
    """
    meshes = []
    offset_x = -(grid_size[0] - 1) * spacing[0] / 2 + offset[0]
    offset_y = -(grid_size[1] - 1) * spacing[1] / 2 + offset[1]
    offset_z = -(grid_size[2] - 1) * spacing[2] / 2 + offset[2]

    for i in range(grid_size[0]):
        for j in range(grid_size[1]):
            for k in range(grid_size[2]):
                copy = mesh.copy()
                pos = (
                    i * spacing[0] + offset_x,
                    j * spacing[1] + offset_y,
                    k * spacing[2] + offset_z,
                )
                copy.apply_translation(pos)
                meshes.append(copy)

    return trimesh.util.concatenate(meshes)


def radial_pattern(
    mesh: trimesh.Trimesh,
    count: int = 8,
    radius: float = 2.0,
    height: float = 0.0,
    start_angle: float = 0.0,
) -> trimesh.Trimesh:
    """
    Create a radial/circular pattern of meshes.

    Args:
        mesh: Base mesh
        count: Number of instances
        radius: Radius of the circle
        height: Z-offset for all instances
        start_angle: Starting angle in radians

    Returns:
        Combined mesh with radial pattern
    """
    if count < 1:
        return mesh.copy()

    instances = []
    angle_step = 2 * np.pi / count

    for i in range(count):
        instance = mesh.copy()
        angle = start_angle + i * angle_step
        x = radius * np.cos(angle)
        z = radius * np.sin(angle)
        instance = translate(instance, (x, height, z))
        instance = rotate(instance, angle, (0, 1, 0))
        instances.append(instance)

    return trimesh.util.concatenate(instances)


def chain_pattern(
    mesh: trimesh.Trimesh,
    links: int = 5,
    link_length: float = 1.0,
    twist_angle: float = 0.0,
) -> trimesh.Trimesh:
    """
    Create a chain-like pattern of meshes.

    Args:
        mesh: Base mesh (should be designed as a link)
        links: Number of links in the chain
        link_length: Distance between link centers
        twist_angle: Rotation twist between links

    Returns:
        Combined mesh forming a chain
    """
    if links < 1:
        return mesh.copy()

    instances = []
    current_angle = 0.0

    for i in range(links):
        instance = mesh.copy()
        x_pos = i * link_length - (links - 1) * link_length / 2
        instance = translate(instance, (x_pos, 0, 0))
        instance = rotate(instance, current_angle, (1, 0, 0))
        instances.append(instance)
        current_angle += twist_angle

    return trimesh.util.concatenate(instances)


def hierarchical_combine(
    components: list[tuple[str, trimesh.Trimesh, tuple[float, float, float]]],
    operations: list[tuple[str, list[str]]],
) -> trimesh.Trimesh:
    """
    Hierarchical combination of components with named references.

    Args:
        components: List of (name, mesh, position) tuples
        operations: List of (operation, [component_names]) tuples
                    Operations: "union", "difference", "intersection"

    Returns:
        Final combined mesh
    """
    component_dict = {name: mesh.copy() for name, mesh, pos in components}

    for name, _mesh, pos in components:
        component_dict[name] = translate(component_dict[name], pos)

    for op_name, component_names in operations:
        if not component_names:
            continue

        meshes = [
            component_dict[name] for name in component_names if name in component_dict
        ]
        if not meshes:
            continue

        if op_name == "union":
            result = batch_union(meshes)
        elif op_name == "difference":
            result = batch_difference(meshes[0], meshes[1:]) if len(meshes) >= 2 else meshes[0].copy()
        elif op_name == "intersection":
            result = batch_intersection(meshes)
            if result is None:
                result = meshes[0].copy()
        else:
            result = meshes[0].copy()

        component_dict[f"_result_{op_name}"] = result

    if "_result_union" in component_dict:
        return component_dict["_result_union"]
    elif component_dict:
        return next(iter(component_dict.values()))
    else:
        raise ValueError("No components provided")


# Re-export basic operations for backwards compatibility
from .operations import mirror, rotate, scale, translate  # noqa: E402
