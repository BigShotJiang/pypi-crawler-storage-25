"""
3D primitives, operations, and composition utilities.
"""

from .composition import (
    batch_difference,
    batch_intersection,
    batch_union,
    chain_pattern,
    compose_transform,
    grid_pattern,
    hierarchical_combine,
    instanced_array,
    radial_pattern,
)
from .operations import (
    array_pattern,
    decimate,
    difference,
    extrude_path,
    extrude_polygon,
    intersection,
    mirror,
    revolve,
    rotate,
    scale,
    smooth_subdivide,
    translate,
    union,
)
from .shapes import (
    create_box,
    create_capsule,
    create_cone,
    create_cylinder,
    create_prism,
    create_sphere,
    create_torus,
    create_uv_sphere,
)

__all__ = [
    "array_pattern",
    "batch_difference",
    "batch_intersection",
    # Composition operations
    "batch_union",
    "chain_pattern",
    "compose_transform",
    # Shapes
    "create_box",
    "create_capsule",
    "create_cone",
    "create_cylinder",
    "create_prism",
    "create_sphere",
    "create_torus",
    "create_uv_sphere",
    "decimate",
    "difference",
    "extrude_path",
    "extrude_polygon",
    "grid_pattern",
    "hierarchical_combine",
    "instanced_array",
    "intersection",
    "mirror",
    "radial_pattern",
    "revolve",
    "rotate",
    "scale",
    "smooth_subdivide",
    # Basic operations
    "translate",
    "union",
]
