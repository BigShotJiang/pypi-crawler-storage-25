"""Command-line interface for paramodeler."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .core.model_generator import ModelGenerator
from .core.parametric import ParametricScript


def main() -> int:
    """Run paramodeler from command line."""
    parser = argparse.ArgumentParser(
        description="Paramodeler - A parametric 3D model design tool",
    )
    parser.add_argument(
        "script",
        type=str,
        nargs="?",
        help="Path to a parametric script file (.json)",
    )
    parser.add_argument(
        "--export",
        "-e",
        type=str,
        help="Export the generated model to file",
    )
    parser.add_argument(
        "--format",
        "-f",
        type=str,
        default="stl",
        choices=["stl", "obj", "ply", "glb"],
        help="Export format (default: stl)",
    )
    parser.add_argument(
        "--params",
        "-p",
        type=str,
        help="JSON string of parameter overrides",
    )
    parser.add_argument(
        "--list-params",
        "-l",
        action="store_true",
        help="List parameters in the script",
    )
    parser.add_argument(
        "--info",
        "-i",
        action="store_true",
        help="Show model information without exporting",
    )

    args = parser.parse_args()

    if not args.script:
        parser.print_help()
        return 1

    script_path = Path(args.script)
    if not script_path.exists():
        return 1

    try:
        script = ParametricScript.load(str(script_path))
    except Exception:  # noqa: BLE001
        return 1

    if args.params:
        try:
            params = json.loads(args.params)
            for name, value in params.items():
                script.set_value(name, value)
        except json.JSONDecodeError:
            return 1

    generator = ModelGenerator()

    if args.list_params:
        for name in script.parameters:
            script.get_value(name)
        return 0

    try:
        mesh = generator.generate(script)
    except Exception:  # noqa: BLE001
        return 1

    if mesh is None:
        return 1

    if args.info:
        generator.preview_mesh(mesh)
        return 0

    if args.export:
        export_path = Path(args.export)
        if export_path.suffix == "":
            export_path = export_path.with_suffix(f".{args.format}")

        try:
            mesh.export(str(export_path))
        except Exception:  # noqa: BLE001
            return 1
        else:
            return 0

    return 0


if __name__ == "__main__":
    sys.exit(main())
