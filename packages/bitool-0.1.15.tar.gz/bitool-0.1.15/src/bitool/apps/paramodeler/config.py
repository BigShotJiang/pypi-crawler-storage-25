"""Configuration module for paramodeler."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import ClassVar


@dataclass
class ParamodelerConfig:
    """Configuration for Paramodeler application."""

    DEFAULT_VIEWPORT_SIZE: ClassVar[tuple[int, int]] = (1200, 800)
    DEFAULT_CAMERA_DISTANCE: ClassVar[float] = 5.0
    DEFAULT_CAMERA_AZIMUTH: ClassVar[float] = 45.0
    DEFAULT_CAMERA_ELEVATION: ClassVar[float] = 30.0

    DEFAULT_MESH_COLOR: ClassVar[tuple[float, float, float, float]] = (
        0.4,
        0.7,
        1.0,
        1.0,
    )
    DEFAULT_WIREFRAME_COLOR: ClassVar[tuple[float, float, float, float]] = (
        0.2,
        0.2,
        0.2,
        1.0,
    )
    DEFAULT_BACKGROUND_COLOR: ClassVar[tuple[float, float, float, float]] = (
        0.15,
        0.15,
        0.18,
        1.0,
    )

    EXPORT_FORMATS: ClassVar[list[str]] = ["stl", "obj", "ply", "glb"]
    SCRIPT_EXTENSION: ClassVar[str] = ".json"

    auto_update: bool = True
    update_debounce_ms: int = 100
    show_grid: bool = True
    show_axes: bool = True
    wireframe_mode: bool = False

    recent_scripts: list[Path] = field(default_factory=list)
    max_recent_scripts: int = 10


conf = ParamodelerConfig()
