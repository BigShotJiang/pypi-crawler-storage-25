"""
Model generator that combines parametric scripts with 3D primitives
"""

from __future__ import annotations

from typing import Any

import numpy as np
import trimesh

from ..models import composition, operations, shapes
from .parametric import Parameter, ParameterType, ParametricScript, ScriptExecutor


class ModelGenerator:
    """Generates 3D models from parametric scripts."""

    def __init__(self) -> None:
        self.executor = ScriptExecutor()
        self._setup_primitives_namespace()

    def _setup_primitives_namespace(self) -> None:
        """Setup the namespace with all available primitives and operations."""
        self.executor.globals.update(
            {
                # Basic shapes
                "box": shapes.create_box,
                "sphere": shapes.create_sphere,
                "cylinder": shapes.create_cylinder,
                "cone": shapes.create_cone,
                "torus": shapes.create_torus,
                "capsule": shapes.create_capsule,
                "prism": shapes.create_prism,
                "uv_sphere": shapes.create_uv_sphere,
                # Basic operations
                "translate": operations.translate,
                "rotate": operations.rotate,
                "scale": operations.scale,
                "union": operations.union,
                "difference": operations.difference,
                "intersection": operations.intersection,
                "extrude_polygon": operations.extrude_polygon,
                "extrude_path": operations.extrude_path,
                "revolve": operations.revolve,
                "mirror": operations.mirror,
                "array": operations.array_pattern,
                "subdivide": operations.smooth_subdivide,
                "decimate": operations.decimate,
                # Composition operations
                "batch_union": composition.batch_union,
                "batch_diff": composition.batch_difference,
                "batch_intersect": composition.batch_intersection,
                "compose": composition.compose_transform,
                "instanced_array": composition.instanced_array,
                "grid": composition.grid_pattern,
                "radial": composition.radial_pattern,
                "chain": composition.chain_pattern,
                "hierarchical": composition.hierarchical_combine,
                # Constants and utilities
                "np": np,
                "pi": 3.141592653589793,
                "tau": 6.283185307179586,
            },
        )

    def generate(self, script: ParametricScript) -> trimesh.Trimesh | None:
        """Generate a 3D model from a parametric script."""
        try:
            result = self.executor.execute(script.script_code, script.current_values)

            if isinstance(result, trimesh.Trimesh):
                return result
            elif isinstance(result, list) and len(result) > 0 and all(isinstance(m, trimesh.Trimesh) for m in result):
                return trimesh.util.concatenate(result)

        except Exception:  # noqa: BLE001, S110
            pass

        return None

    def generate_with_params(
        self,
        script: ParametricScript,
        params: dict[str, Any],
    ) -> trimesh.Trimesh | None:
        """Generate model with custom parameter values."""
        for name, value in params.items():
            script.set_value(name, value)

        return self.generate(script)

    def preview_mesh(self, mesh: trimesh.Trimesh) -> dict[str, Any]:
        """Get preview information about a mesh."""
        return {
            "vertices": len(mesh.vertices),
            "faces": len(mesh.faces),
            "bounds": mesh.bounds.tolist(),
            "volume": float(mesh.volume) if mesh.is_watertight else None,
            "surface_area": float(mesh.area),
            "is_watertight": mesh.is_watertight,
            "is_winding_consistent": mesh.is_winding_consistent,
        }


# Example scripts demonstrating multi-structure composition
EXAMPLE_BOX_SPHERE = """
box_width = width
box_height = height
box_depth = depth

base = box(width=box_width, height=box_height, depth=box_depth, center=(0, 0, 0))

sphere_radius = radius
sphere_pos = (0, box_height/2 + sphere_radius, 0)
top = sphere(radius=sphere_radius, center=sphere_pos)

result = union(base, top)
"""

EXAMPLE_CYLINDER_STACK = """
cylinders = []
num_cylinders = num_layers
base_radius = max_radius
height_per_layer = layer_height

for i in range(num_cylinders):
    radius = base_radius * (1 - i * taper)
    y_pos = (i - num_cylinders/2) * height_per_layer
    cyl = cylinder(radius=radius, height=height_per_layer, center=(0, y_pos, 0))
    cylinders.append(cyl)

result = cylinders[0]
for cyl in cylinders[1:]:
    result = union(result, cyl)
"""

EXAMPLE_GEAR = """
teeth = num_teeth
outer_radius = radius
inner_radius = radius * 0.7
tooth_height = radius * 0.15
thickness = gear_thickness

gear = cylinder(radius=inner_radius, height=thickness, center=(0, 0, 0))

for i in range(teeth):
    angle = 2 * np.pi * i / teeth
    x = np.cos(angle) * (outer_radius - tooth_height/2)
    z = np.sin(angle) * (outer_radius - tooth_height/2)

    tooth = cylinder(radius=tooth_height, height=thickness, center=(x, 0, z))
    gear = union(gear, tooth)

result = gear
"""

EXAMPLE_GRID_PATTERN = """
cell_size = grid_spacing
grid_dim = grid_size

base_cell = box(width=cell_size*0.8, height=0.2, depth=cell_size*0.8)

result = grid(base_cell, grid_size=(grid_dim, grid_dim, 1), spacing=(cell_size, cell_size, 1))
"""

EXAMPLE_RADIAL_PATTERN = """
petal_cnt = num_petals
petal_r = radius
petal_t = thickness

petal = cylinder(radius=petal_t/2, height=petal_r*0.6, center=(petal_r*0.3, 0, 0))
petal = rotate(petal, np.pi/4, (0, 0, 1))

result = radial(petal, count=petal_cnt, radius=petal_r, height=0)
"""

EXAMPLE_ASSEMBLY = """
base_cyl = cylinder(radius=base_radius, height=base_height, center=(0, -base_height/2, 0))

arm_l = arm_length
arm_w = 0.2
arm_box = box(width=arm_l, height=arm_w, depth=arm_w)
arm_box = translate(arm_box, (arm_l/2, 0, 0))

arms = radial(arm_box, count=num_arms, radius=base_radius*0.8, height=base_height/2)

center_sphere = sphere(radius=sphere_radius, center=(0, base_height/2 + sphere_radius, 0))

result = batch_union([base_cyl, arms, center_sphere])
"""

EXAMPLE_HOLLOW_BOX = """
outer_width = width
outer_height = height
outer_depth = depth
wall_thickness = thickness

outer = box(width=outer_width, height=outer_height, depth=outer_depth)

inner_width = outer_width - wall_thickness * 2
inner_height = outer_height - wall_thickness * 2
inner_depth = outer_depth - wall_thickness * 2
inner = box(width=inner_width, height=inner_height, depth=inner_depth)

result = difference(outer, inner)
"""


def create_example_script(example_type: str = "box_sphere") -> ParametricScript:
    """Create a predefined example script."""
    if example_type == "box_sphere":
        script = ParametricScript(
            name="Box with Sphere",
            description="A box with a sphere on top",
            script_code=EXAMPLE_BOX_SPHERE,
        )
        script.add_parameter(
            Parameter(
                name="width",
                param_type=ParameterType.FLOAT,
                default_value=2.0,
                min_value=0.1,
                max_value=10.0,
                step=0.1,
                description="Box width",
            ),
        )
        script.add_parameter(
            Parameter(
                name="height",
                param_type=ParameterType.FLOAT,
                default_value=1.0,
                min_value=0.1,
                max_value=10.0,
                step=0.1,
                description="Box height",
            ),
        )
        script.add_parameter(
            Parameter(
                name="depth",
                param_type=ParameterType.FLOAT,
                default_value=2.0,
                min_value=0.1,
                max_value=10.0,
                step=0.1,
                description="Box depth",
            ),
        )
        script.add_parameter(
            Parameter(
                name="radius",
                param_type=ParameterType.FLOAT,
                default_value=0.8,
                min_value=0.1,
                max_value=5.0,
                step=0.1,
                description="Sphere radius",
            ),
        )
        return script

    elif example_type == "cylinder_stack":
        script = ParametricScript(
            name="Cylinder Stack",
            description="A tapered stack of cylinders",
            script_code=EXAMPLE_CYLINDER_STACK,
        )
        script.add_parameter(
            Parameter(
                name="num_layers",
                param_type=ParameterType.INT,
                default_value=5,
                min_value=1,
                max_value=20,
                step=1,
                description="Number of cylinder layers",
            ),
        )
        script.add_parameter(
            Parameter(
                name="max_radius",
                param_type=ParameterType.FLOAT,
                default_value=2.0,
                min_value=0.5,
                max_value=5.0,
                step=0.1,
                description="Base radius",
            ),
        )
        script.add_parameter(
            Parameter(
                name="layer_height",
                param_type=ParameterType.FLOAT,
                default_value=0.5,
                min_value=0.1,
                max_value=2.0,
                step=0.1,
                description="Height of each layer",
            ),
        )
        script.add_parameter(
            Parameter(
                name="taper",
                param_type=ParameterType.FLOAT,
                default_value=0.15,
                min_value=0.0,
                max_value=0.5,
                step=0.01,
                description="Taper factor per layer",
            ),
        )
        return script

    elif example_type == "gear":
        script = ParametricScript(
            name="Simple Gear",
            description="A simple gear with teeth",
            script_code=EXAMPLE_GEAR,
        )
        script.add_parameter(
            Parameter(
                name="num_teeth",
                param_type=ParameterType.INT,
                default_value=12,
                min_value=3,
                max_value=50,
                step=1,
                description="Number of gear teeth",
            ),
        )
        script.add_parameter(
            Parameter(
                name="radius",
                param_type=ParameterType.FLOAT,
                default_value=3.0,
                min_value=1.0,
                max_value=10.0,
                step=0.1,
                description="Gear radius",
            ),
        )
        script.add_parameter(
            Parameter(
                name="gear_thickness",
                param_type=ParameterType.FLOAT,
                default_value=0.5,
                min_value=0.1,
                max_value=2.0,
                step=0.1,
                description="Gear thickness",
            ),
        )
        return script

    elif example_type == "grid":
        script = ParametricScript(
            name="Grid Pattern",
            description="A grid of boxes demonstrating pattern composition",
            script_code=EXAMPLE_GRID_PATTERN,
        )
        script.add_parameter(
            Parameter(
                name="grid_spacing",
                param_type=ParameterType.FLOAT,
                default_value=1.0,
                min_value=0.2,
                max_value=3.0,
                step=0.1,
                description="Spacing between grid cells",
            ),
        )
        script.add_parameter(
            Parameter(
                name="grid_size",
                param_type=ParameterType.INT,
                default_value=5,
                min_value=2,
                max_value=10,
                step=1,
                description="Number of cells per dimension",
            ),
        )
        return script

    elif example_type == "radial":
        script = ParametricScript(
            name="Radial Pattern",
            description="A radial pattern of petals",
            script_code=EXAMPLE_RADIAL_PATTERN,
        )
        script.add_parameter(
            Parameter(
                name="num_petals",
                param_type=ParameterType.INT,
                default_value=6,
                min_value=3,
                max_value=20,
                step=1,
                description="Number of petals",
            ),
        )
        script.add_parameter(
            Parameter(
                name="radius",
                param_type=ParameterType.FLOAT,
                default_value=2.0,
                min_value=0.5,
                max_value=5.0,
                step=0.1,
                description="Pattern radius",
            ),
        )
        script.add_parameter(
            Parameter(
                name="thickness",
                param_type=ParameterType.FLOAT,
                default_value=0.3,
                min_value=0.1,
                max_value=1.0,
                step=0.05,
                description="Petal thickness",
            ),
        )
        return script

    elif example_type == "assembly":
        script = ParametricScript(
            name="Component Assembly",
            description="An assembly of multiple components using batch operations",
            script_code=EXAMPLE_ASSEMBLY,
        )
        script.add_parameter(
            Parameter(
                name="base_radius",
                param_type=ParameterType.FLOAT,
                default_value=2.0,
                min_value=0.5,
                max_value=5.0,
                step=0.1,
                description="Base radius",
            ),
        )
        script.add_parameter(
            Parameter(
                name="base_height",
                param_type=ParameterType.FLOAT,
                default_value=0.5,
                min_value=0.2,
                max_value=2.0,
                step=0.1,
                description="Base height",
            ),
        )
        script.add_parameter(
            Parameter(
                name="arm_length",
                param_type=ParameterType.FLOAT,
                default_value=1.5,
                min_value=0.5,
                max_value=3.0,
                step=0.1,
                description="Arm length",
            ),
        )
        script.add_parameter(
            Parameter(
                name="num_arms",
                param_type=ParameterType.INT,
                default_value=4,
                min_value=2,
                max_value=8,
                step=1,
                description="Number of arms",
            ),
        )
        script.add_parameter(
            Parameter(
                name="sphere_radius",
                param_type=ParameterType.FLOAT,
                default_value=0.5,
                min_value=0.2,
                max_value=1.5,
                step=0.1,
                description="Center sphere radius",
            ),
        )
        return script

    elif example_type == "hollow_box":
        script = ParametricScript(
            name="Hollow Box",
            description="A hollow box created using boolean difference",
            script_code=EXAMPLE_HOLLOW_BOX,
        )
        script.add_parameter(
            Parameter(
                name="width",
                param_type=ParameterType.FLOAT,
                default_value=2.0,
                min_value=0.5,
                max_value=5.0,
                step=0.1,
                description="Outer width",
            ),
        )
        script.add_parameter(
            Parameter(
                name="height",
                param_type=ParameterType.FLOAT,
                default_value=2.0,
                min_value=0.5,
                max_value=5.0,
                step=0.1,
                description="Outer height",
            ),
        )
        script.add_parameter(
            Parameter(
                name="depth",
                param_type=ParameterType.FLOAT,
                default_value=2.0,
                min_value=0.5,
                max_value=5.0,
                step=0.1,
                description="Outer depth",
            ),
        )
        script.add_parameter(
            Parameter(
                name="thickness",
                param_type=ParameterType.FLOAT,
                default_value=0.2,
                min_value=0.05,
                max_value=0.5,
                step=0.05,
                description="Wall thickness",
            ),
        )
        return script

    else:
        raise ValueError(f"Unknown example type: {example_type}")
