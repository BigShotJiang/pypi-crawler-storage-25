"""
Parametric script parsing and execution module
"""

from __future__ import annotations

import ast
import json
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any

import numpy as np


class ParameterType(Enum):
    """Parameter types supported by the system"""

    FLOAT = auto()
    INT = auto()
    BOOL = auto()
    STRING = auto()
    COLOR = auto()
    VECTOR3 = auto()


@dataclass
class Parameter:
    """Represents a single parameter with its properties"""

    name: str
    param_type: ParameterType
    default_value: Any
    min_value: float | int | None = None
    max_value: float | int | None = None
    step: float | int | None = None
    description: str = ""
    options: list[str] | None = None  # For dropdown/select parameters

    def validate(self, value: Any) -> bool:
        """Validate if the given value is acceptable for this parameter"""
        if self.param_type == ParameterType.FLOAT:
            if not isinstance(value, (int, float)):
                return False
            if self.min_value is not None and value < self.min_value:
                return False
            if self.max_value is not None and value > self.max_value:
                return False
        elif self.param_type == ParameterType.INT:
            if not isinstance(value, int):
                return False
            if self.min_value is not None and value < self.min_value:
                return False
            if self.max_value is not None and value > self.max_value:
                return False
        elif self.param_type == ParameterType.BOOL:
            if not isinstance(value, bool):
                return False
        elif self.param_type == ParameterType.STRING:
            if not isinstance(value, str):
                return False
            if self.options and value not in self.options:
                return False
        elif self.param_type == ParameterType.COLOR:
            # Color should be a list/tuple of 3-4 values (RGB or RGBA)
            if not isinstance(value, (list, tuple)) or len(value) not in [3, 4]:
                return False
        elif self.param_type == ParameterType.VECTOR3:
            # Vector3 should be a list/tuple of 3 values
            if not isinstance(value, (list, tuple)) or len(value) != 3:
                return False
        return True

    def clamp(self, value: Any) -> Any:
        """Clamp value to valid range"""
        if self.param_type in (ParameterType.FLOAT, ParameterType.INT):
            if self.min_value is not None:
                value = max(self.min_value, value)
            if self.max_value is not None:
                value = min(self.max_value, value)
            if self.param_type == ParameterType.INT:
                value = int(value)
        return value


@dataclass
class ParametricScript:
    """
    Represents a parametric script that can generate 3D models
    """

    name: str = "Untitled"
    description: str = ""
    parameters: dict[str, Parameter] = field(default_factory=dict)
    script_code: str = ""
    current_values: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """Initialize current values with defaults"""
        if not self.current_values:
            self.current_values = {
                name: param.default_value for name, param in self.parameters.items()
            }

    def add_parameter(self, parameter: Parameter) -> None:
        """Add a parameter to the script"""
        self.parameters[parameter.name] = parameter
        if parameter.name not in self.current_values:
            self.current_values[parameter.name] = parameter.default_value

    def set_value(self, name: str, value: Any) -> bool:
        """Set a parameter value after validation"""
        if name not in self.parameters:
            return False

        param = self.parameters[name]
        if not param.validate(value):
            return False

        self.current_values[name] = param.clamp(value)
        return True

    def get_value(self, name: str) -> Any:
        """Get current value of a parameter"""
        return self.current_values.get(name)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary"""
        return {
            "name": self.name,
            "description": self.description,
            "parameters": {
                name: {
                    "type": param.param_type.name,
                    "default": param.default_value,
                    "min": param.min_value,
                    "max": param.max_value,
                    "step": param.step,
                    "description": param.description,
                    "options": param.options,
                }
                for name, param in self.parameters.items()
            },
            "script_code": self.script_code,
            "current_values": self.current_values,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ParametricScript:
        """Deserialize from dictionary"""
        script = cls(
            name=data.get("name", "Untitled"),
            description=data.get("description", ""),
            script_code=data.get("script_code", ""),
        )

        # Parse parameters
        for name, param_data in data.get("parameters", {}).items():
            param_type = ParameterType[param_data.get("type", "FLOAT")]
            param = Parameter(
                name=name,
                param_type=param_type,
                default_value=param_data.get("default"),
                min_value=param_data.get("min"),
                max_value=param_data.get("max"),
                step=param_data.get("step"),
                description=param_data.get("description", ""),
                options=param_data.get("options"),
            )
            script.add_parameter(param)

        # Set current values
        script.current_values = data.get("current_values", script.current_values)

        return script

    def save(self, filepath: str) -> None:
        """Save script to JSON file"""
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)

    @classmethod
    def load(cls, filepath: str) -> ParametricScript:
        """Load script from JSON file"""
        with open(filepath, encoding="utf-8") as f:
            data = json.load(f)
        return cls.from_dict(data)


class ScriptExecutor:
    """
    Executes parametric scripts in a safe environment
    """

    def __init__(self) -> None:
        self.globals = {
            "np": np,
            "__builtins__": {
                "abs": abs,
                "max": max,
                "min": min,
                "pow": pow,
                "round": round,
                "sum": sum,
                "len": len,
                "range": range,
                "zip": zip,
                "enumerate": enumerate,
                "list": list,
                "tuple": tuple,
                "dict": dict,
                "float": float,
                "int": int,
                "str": str,
                "bool": bool,
            },
        }
        self.locals = {}

    def execute(self, script_code: str, parameters: dict[str, Any]) -> Any:
        """
        Execute script code with given parameters
        Returns the result of the script execution
        """
        # Create safe execution environment
        exec_globals = self.globals.copy()
        exec_locals = parameters.copy()

        try:
            # Parse and validate AST
            tree = ast.parse(script_code)

            # Execute the script
            exec(  # noqa: S102
                compile(tree, "<parametric_script>", "exec"),
                exec_globals,
                exec_locals,
            )

            # Return the 'result' variable if it exists
            if "result" in exec_locals:
                return exec_locals["result"]
            elif "mesh" in exec_locals:
                return exec_locals["mesh"]
            else:
                return exec_locals

        except Exception as e:
            raise RuntimeError(f"Script execution error: {e!s}") from e
