"""Paramodeler - A parametric 3D model design tool."""

__version__ = "0.1.7"
__author__ = "Paramodeler Team"

from .config import conf
from .core import (
    ModelGenerator,
    Parameter,
    ParameterType,
    ParametricScript,
    ScriptExecutor,
    create_example_script,
)

__all__ = [
    "ModelGenerator",
    "Parameter",
    "ParameterType",
    "ParametricScript",
    "ScriptExecutor",
    "conf",
    "create_example_script",
]
