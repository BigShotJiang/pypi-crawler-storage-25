"""Graphical user interface for salesmap."""

import sys
from pathlib import Path

from bitool.gui.compat import QApplication

from .depends.salesmapwindow import SalesMapWindow

sys.path.append(str(Path(__file__).parent))

# TODO: 1、增加地区颜色显示及其读取; 2、增加地区客户数量显示;


def main() -> None:
    """Run entry point for the GUI application.

    Graphical interface for salesmap
    """
    app = QApplication(sys.argv)
    ui = SalesMapWindow()
    ui.show()
    app.exec_()


if __name__ == "__main__":
    main()
