"""Configuration for depends."""

from pathlib import Path

DIR_DEP = Path(__file__).parent
DIR_SRC = DIR_DEP.parent
DIR_DATA = DIR_SRC / "data"
DIR_WEB = DIR_SRC / "web"

JSON_NAME = "city-version-4.json"
JSON_PATH = DIR_DATA / JSON_NAME

PROJECT_NAME = "sdlw-salesmap"
APP_NAME = "salesmap"
APP_VERSION = "1.2"
APP_TITLE = f"山东鲁潍销售区域管理系统Ver{APP_VERSION}"

AREA_COLUMNS = 1
AREA_LABELS = ["省-市-区、县"]

AREA_PROVINCE_LEVEL_CITIES = ["北京市", "天津市", "上海市", "重庆市"]  # 直辖市