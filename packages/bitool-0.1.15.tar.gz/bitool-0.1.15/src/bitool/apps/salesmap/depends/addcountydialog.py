"""Addcountydialog module for depends."""

import json

from bitool.gui import setup_ui
from bitool.gui.compat import QDialog, Signal

from .config import AREA_PROVINCE_LEVEL_CITIES, JSON_PATH


class AddCountyDialog(QDialog):
    sigAddCounty = Signal(str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)

        setup_ui(self)

        self.json_data = None
        self.provinces = []
        self.cities = []
        self.counties = []

        self.read_json_file()
        self.init_ui()

    def read_json_file(self) -> None:
        """读取全国地区json文件."""
        try:
            with open((JSON_PATH).as_posix()) as f:
                self.json_data = json.load(f)
        except OSError:
            return

        # 存取数据到AddCountyDialog对象中
        for province in self.json_data["provinceList"]:
            self.provinces.append(province["name"])
            for city in province["cityList"]:
                if city["name"] != "市辖区":
                    self.cities.append(city["name"])
                for county in city["countyList"]:
                    self.counties.append(county["name"])

    def init_ui(self) -> None:
        """初始化界面内容及事件."""
        try:
            provinces = self.provinces
            cities = self.get_cities(provinces[0])
            counties = self.get_counties(provinces[0], cities[0])

            self.cbProvince.addItems(provinces)
            self.cbCity.addItems(cities)
            self.cbCounty.addItems(counties)
        except KeyError:
            return

        self.cbProvince.currentTextChanged.connect(self.on_province_change)
        self.cbCity.currentTextChanged.connect(self.on_city_change)
        self.bbConfirm.accepted.connect(self.on_confirm)

    def on_province_change(self, text) -> None:
        """处理省下拉框变更"""
        if text == "":
            return

        self.cbCity.clear()
        self.cbCity.addItems(self.get_cities(text))

    def on_city_change(self, text) -> None:
        """处理市下拉框变更"""
        if text == "":
            return

        self.cbCounty.clear()
        self.cbCounty.addItems(self.get_counties(self.cbProvince.currentText(), text))

    def on_confirm(self) -> None:
        area_info = " ".join([ui.currentText() for ui in [self.cbProvince, self.cbCity, self.cbCounty]])
        self.sigAddCounty.emit(area_info)

    def get_cities(self, province):
        if province == "":
            return []

        if province in AREA_PROVINCE_LEVEL_CITIES:
            return [f"#{province}#"]

        province_data = next(filter(lambda x: x["name"] == province, self.json_data["provinceList"]))
        return [item.get("name") for item in province_data["cityList"] if item.get("name") != "市辖区"]

    def get_counties(self, province, city):
        if province == "" or city == "":
            return []

        province_data = next(filter(lambda x: x["name"] == province, self.json_data["provinceList"]))
        if province in AREA_PROVINCE_LEVEL_CITIES:
            city_data = next(filter(lambda x: x["name"] == "市辖区", province_data["cityList"]))
        else:
            city_data = next(filter(lambda x: x["name"] == city, province_data["cityList"]))

        return [item.get("name") for item in city_data["countyList"] if item.get("name") != "市辖区"]
