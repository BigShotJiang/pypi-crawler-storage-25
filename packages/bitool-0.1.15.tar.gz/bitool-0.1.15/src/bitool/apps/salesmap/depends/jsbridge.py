"""Jsbridge module for depends."""

from bitool.gui.compat import QObject, Signal, Slot


class JSBridge(QObject):
    sigMessageFromJS = Signal(str)
    sigGetBoundary = Signal(str)
    sigCenterOn = Signal(str, int)
    sigResetMap = Signal()
    sigClearMap = Signal()
    sigResizeMap = Signal(int)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)

    @Slot(str)
    def log(self, msg) -> None:
        self.sigMessageFromJS.emit(msg)

    @Slot(str, str)
    def test(self, message) -> str:
        return "ok"
