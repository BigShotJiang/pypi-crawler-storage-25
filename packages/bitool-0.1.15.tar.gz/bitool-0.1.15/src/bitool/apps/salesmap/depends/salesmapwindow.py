"""Salesmapwindow module for depends."""

import os

from bitool.apps.salesmap.depends import config
from bitool.apps.salesmap.depends.addcountydialog import AddCountyDialog
from bitool.apps.salesmap.depends.jsbridge import JSBridge
from bitool.gui import load_qrc, setup_ui
from bitool.gui.compat import (
    QAbstractItemView,
    QDir,
    QFileDialog,
    QMainWindow,
    QStandardItem,
    QStandardItemModel,
    Qt,
    QUrl,
    QWebChannel,
    QWebEngineSettings,
)

load_qrc()


class SalesMapWindow(QMainWindow):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)

        setup_ui(self)

        self.resize(1800, 1040)

        self.selected_areas = {}
        self.current_selection = None

        self.weMap.setMaximumWidth(self.width() - self.gbMessage.width())
        self.weMap.settings().setAttribute(QWebEngineSettings.JavascriptEnabled, True)

        self.jsBridge = JSBridge(self)
        channel = QWebChannel(self.weMap.page())
        channel.registerObject("jsBridge", self.jsBridge)
        self.weMap.page().setWebChannel(channel)

        page = QUrl.fromLocalFile((config.DIR_WEB / "page.html").as_posix())
        self.weMap.load(page)

        self.jsBridge.sigMessageFromJS.connect(self.on_message_from_js)
        self.action_open.triggered.connect(self.on_open_file)
        self.action_save.triggered.connect(self.on_save_file)
        self.action_add.triggered.connect(self.on_add)
        self.action_revert.triggered.connect(self.on_reset_map)
        self.action_opentree.triggered.connect(self.on_action_open_tree)
        self.action_closetree.triggered.connect(self.on_action_close_tree)

        self.model = QStandardItemModel(0, config.AREA_COLUMNS, parent)
        self.model.setHorizontalHeaderLabels(config.AREA_LABELS)
        self.tvAreas.setModel(self.model)
        self.tvAreas.setColumnWidth(0, 200)
        self.tvAreas.setSelectionMode(QAbstractItemView.SingleSelection)
        self.tvAreas.setEditTriggers(QAbstractItemView.NoEditTriggers)

        self.tvAreas.clicked.connect(self.on_select_area)

        self.add_county_dialog = AddCountyDialog(self)
        self.add_county_dialog.sigAddCounty.connect(self.on_add_county)

    def on_open_file(self) -> None:
        """打开地区文本文件, 以 'txt' 格式储存"""
        filename = QFileDialog.getOpenFileName(self, "打开文件", config.DIR_DATA.as_posix(), "地区文件 (*.txt)")[0]
        if os.path.isfile(filename):
            if self.model:
                self.model.clear()
                self.selected_areas = {}
                self.model.setHorizontalHeaderLabels(config.AREA_LABELS)
                self.jsBridge.sigClearMap.emit()

            with open(os.path.abspath(filename), encoding="utf-8") as f:
                lines = f.readlines()
                for line in lines:
                    try:
                        province, city, county = line.strip().split(" ")
                    except ValueError:
                        self.lwMessage.addItem(f"文件{filename}包含的地区内容不合法")
                    else:
                        self.add_county(province, city, county)

    def on_save_file(self) -> None:
        filename = QFileDialog.getSaveFileName(self, "保存文件", QDir.currentPath(), "地区文件 (*.txt)")[0]
        if filename == "":
            return

        with open(os.path.abspath(filename), "w", encoding="utf-8") as f:
            for province in self.selected_areas:
                for city in self.selected_areas[province]:
                    for county in self.selected_areas[province][city]:
                        f.write(f"{province} {city} {county}\n")

    def on_message_from_js(self, msg) -> None:
        """展示从JS到Qt控件消息的传递"""
        self.lwMessage.addItem(msg)

    def on_add_county(self, area_info) -> None:
        province, city, county = area_info.split(" ")
        self.lwMessage.addItem(f"增加区域:{province}-{city}-{county}")
        self.add_county(province, city, county)

    def add_county(self, province, city, county) -> None:
        if province in self.selected_areas:
            item_province = self.model.findItems(f"{province}*", Qt.MatchWildcard)[0]
            if city in self.selected_areas[province]:
                item_city = self.model.findItems(f"{city}*", Qt.MatchWildcard | Qt.MatchRecursive)[0]
                if county in self.selected_areas[province][city]:
                    self.lwMessage.addItem(f"{province}-{city}-{county}已存在")
                    return
                else:
                    self.selected_areas[province][city].append(county)

                    item_county = QStandardItem(county)
                    item_city.setText(f"{city}({len(self.selected_areas[province][city])})")
                    item_city.appendRow(item_county)
            else:
                self.selected_areas[province][city] = [county]

                item_city = QStandardItem(f"{city}(1)")
                item_county = QStandardItem(county)
                item_city.appendRow(item_county)
                item_province.appendRow(item_city)

            num_county = [len(self.selected_areas[province][c]) for c in self.selected_areas[province]]
            item_province.setText(f"{province}({sum(num_county)})")
        else:
            self.selected_areas[province] = {city: [county]}

            item_province = QStandardItem(f"{province}(1)")
            item_city = QStandardItem(f"{city}(1)")
            item_county = QStandardItem(county)

            item_city.appendRow(item_county)
            item_province.appendRow(item_city)
            self.model.appendRow(item_province)

        self.jsBridge.sigGetBoundary.emit(county)

    def remove_county(self) -> None:
        pass

    def on_add(self) -> None:
        """展示从Qt控件到JS的消息传递"""
        self.add_county_dialog.show()

    def on_action_open_tree(self) -> None:
        self.tvAreas.expandAll()

    def on_action_close_tree(self) -> None:
        self.tvAreas.collapseAll()

    def on_select_area(self, index) -> None:
        item = self.model.itemData(index)
        self.current_selection = index

        raw_text = item[0][: item[0].index("(")] if "(" in item[0] else item[0]
        raw_text = raw_text.replace("#", "")
        if raw_text in self.add_county_dialog.counties:
            self.lwMessage.addItem(f"缩放到目标县区:{raw_text}")
            self.jsBridge.sigCenterOn.emit(raw_text, 11)
        elif raw_text in self.add_county_dialog.cities:
            self.lwMessage.addItem(f"缩放到目标市:{raw_text}")
            self.jsBridge.sigCenterOn.emit(raw_text, 10)
        elif raw_text in self.add_county_dialog.provinces:
            if raw_text not in config.AREA_PROVINCE_LEVEL_CITIES:
                self.lwMessage.addItem(f"缩放到目标省:{raw_text}")
            else:
                self.lwMessage.addItem(f"缩放到目标市:{raw_text}")
            self.jsBridge.sigCenterOn.emit(raw_text, 8)

    def on_reset_map(self) -> None:
        self.jsBridge.sigResetMap.emit()
