"""Ui module for rimworld_lite."""

import pygame

from .constants import (
    BUILDING_BED,
    BUILDING_DOOR,
    BUILDING_FARM_PLOT,
    BUILDING_FLOOR_WOOD,
    BUILDING_INFO,
    BUILDING_STORAGE,
    BUILDING_WALL_STONE,
    BUILDING_WALL_WOOD,
    BUILDING_WORKBENCH,
    COLOR_UI_BG,
    COLOR_UI_BORDER,
    COLOR_UI_BUTTON,
    COLOR_UI_BUTTON_ACTIVE,
    COLOR_UI_BUTTON_HOVER,
    COLOR_UI_HIGHLIGHT,
    COLOR_UI_PANEL,
    COLOR_UI_TEXT,
    CROP_INFO,
    CROP_POTATO,
    CROP_RICE,
    SCREEN_HEIGHT,
    SCREEN_WIDTH,
    SPEED_FAST,
    SPEED_NORMAL,
    SPEED_PAUSED,
    SPEED_VERY_FAST,
)


class Button:
    def __init__(self, x, y, w, h, text, action=None, tooltip="") -> None:
        self.rect = pygame.Rect(x, y, w, h)
        self.text = text
        self.action = action
        self.tooltip = tooltip
        self.hovered = False
        self.active = False

    def draw(self, surface, font) -> None:
        if self.active:
            color = COLOR_UI_BUTTON_ACTIVE
        elif self.hovered:
            color = COLOR_UI_BUTTON_HOVER
        else:
            color = COLOR_UI_BUTTON

        pygame.draw.rect(surface, color, self.rect, border_radius=4)
        pygame.draw.rect(surface, COLOR_UI_BORDER, self.rect, 1, border_radius=4)

        text_surf = font.render(self.text, True, COLOR_UI_TEXT)
        text_rect = text_surf.get_rect(center=self.rect.center)
        surface.blit(text_surf, text_rect)

    def check_hover(self, pos):
        self.hovered = self.rect.collidepoint(pos)
        return self.hovered

    def check_click(self, pos) -> bool:
        if self.rect.collidepoint(pos):
            if self.action:
                self.action()
            return True
        return False


class UI:
    def __init__(self, screen) -> None:
        self.screen = screen
        self.font_small = None
        self.font_medium = None
        self.font_large = None
        self._init_fonts()

        self.mode = "normal"  # normal, build, farm, hunt, chop
        self.selected_building = BUILDING_WALL_WOOD
        self.selected_crop = CROP_RICE
        self.game_speed = SPEED_NORMAL
        self.show_build_menu = False
        self.show_farm_menu = False

        # Build menu buttons
        self.build_buttons = []
        self.farm_buttons = []
        self.speed_buttons = []
        self.mode_buttons = []
        self._create_buttons()

        self.tooltip_text = ""
        self.tooltip_pos = (0, 0)

    def _init_fonts(self) -> None:
        try:
            self.font_small = pygame.font.SysFont("simhei", 13)
            self.font_medium = pygame.font.SysFont("simhei", 16)
            self.font_large = pygame.font.SysFont("simhei", 22)
        except Exception:  # noqa: BLE001
            self.font_small = pygame.font.Font(None, 15)
            self.font_medium = pygame.font.Font(None, 18)
            self.font_large = pygame.font.Font(None, 24)

    def _create_buttons(self) -> None:
        # Bottom bar mode buttons
        bar_y = SCREEN_HEIGHT - 50
        btn_w = 70
        btn_h = 35
        start_x = 10

        self.mode_buttons = [
            Button(
                start_x,
                bar_y,
                btn_w,
                btn_h,
                "选择",
                lambda: self._set_mode("normal"),
                "选择殖民者",
            ),
            Button(
                start_x + btn_w + 5,
                bar_y,
                btn_w,
                btn_h,
                "建造",
                lambda: self._set_mode("build"),
                "建造建筑",
            ),
            Button(
                start_x + (btn_w + 5) * 2,
                bar_y,
                btn_w,
                btn_h,
                "种植",
                lambda: self._set_mode("farm"),
                "种植作物",
            ),
            Button(
                start_x + (btn_w + 5) * 3,
                bar_y,
                btn_w,
                btn_h,
                "捕猎",
                lambda: self._set_mode("hunt"),
                "标记猎物",
            ),
            Button(
                start_x + (btn_w + 5) * 4,
                bar_y,
                btn_w,
                btn_h,
                "砍树",
                lambda: self._set_mode("chop"),
                "砍伐树木",
            ),
            Button(
                start_x + (btn_w + 5) * 5,
                bar_y,
                btn_w,
                btn_h,
                "收获",
                lambda: self._set_mode("harvest"),
                "收获作物",
            ),
        ]

        # Speed buttons (top right)
        speed_x = SCREEN_WIDTH - 180
        speed_y = 5
        self.speed_buttons = [
            Button(
                speed_x,
                speed_y,
                40,
                25,
                "⏸",
                lambda: self._set_speed(SPEED_PAUSED),
                "暂停",
            ),
            Button(
                speed_x + 45,
                speed_y,
                40,
                25,
                "▶",
                lambda: self._set_speed(SPEED_NORMAL),
                "正常速度",
            ),
            Button(
                speed_x + 90,
                speed_y,
                40,
                25,
                "▶▶",
                lambda: self._set_speed(SPEED_FAST),
                "快速",
            ),
            Button(
                speed_x + 135,
                speed_y,
                40,
                25,
                "▶▶▶",
                lambda: self._set_speed(SPEED_VERY_FAST),
                "极速",
            ),
        ]

        # Building submenu buttons
        self.build_buttons = [
            Button(
                10,
                SCREEN_HEIGHT - 130,
                90,
                30,
                "木墙(木5)",
                lambda: self._select_building(BUILDING_WALL_WOOD),
                "建造木墙 - 需要5木材",
            ),
            Button(
                105,
                SCREEN_HEIGHT - 130,
                90,
                30,
                "石墙(石8)",
                lambda: self._select_building(BUILDING_WALL_STONE),
                "建造石墙 - 需要8石材",
            ),
            Button(
                10,
                SCREEN_HEIGHT - 95,
                90,
                30,
                "木地板(木2)",
                lambda: self._select_building(BUILDING_FLOOR_WOOD),
                "建造木地板 - 需要2木材",
            ),
            Button(
                105,
                SCREEN_HEIGHT - 95,
                90,
                30,
                "工作台(木10石2)",
                lambda: self._select_building(BUILDING_WORKBENCH),
                "建造工作台 - 需要10木材2石材",
            ),
            Button(
                10,
                SCREEN_HEIGHT - 60,
                90,
                30,
                "储物区(木5)",
                lambda: self._select_building(BUILDING_STORAGE),
                "建造储物区 - 需要5木材",
            ),
            Button(
                105,
                SCREEN_HEIGHT - 60,
                90,
                30,
                "床(木8)",
                lambda: self._select_building(BUILDING_BED),
                "建造床 - 需要8木材",
            ),
            Button(
                200,
                SCREEN_HEIGHT - 130,
                90,
                30,
                "门(木4)",
                lambda: self._select_building(BUILDING_DOOR),
                "建造门 - 需要4木材",
            ),
            Button(
                200,
                SCREEN_HEIGHT - 95,
                90,
                30,
                "农田(木3)",
                lambda: self._select_building(BUILDING_FARM_PLOT),
                "建造农田 - 需要3木材",
            ),
        ]

        # Farm submenu buttons
        self.farm_buttons = [
            Button(
                10,
                SCREEN_HEIGHT - 130,
                90,
                30,
                "水稻",
                lambda: self._select_crop(CROP_RICE),
                "种植水稻",
            ),
            Button(
                105,
                SCREEN_HEIGHT - 130,
                90,
                30,
                "土豆",
                lambda: self._select_crop(CROP_POTATO),
                "种植土豆",
            ),
        ]

    def _set_mode(self, mode) -> None:
        self.mode = mode
        self.show_build_menu = mode == "build"
        self.show_farm_menu = mode == "farm"

    def _set_speed(self, speed) -> None:
        self.game_speed = speed

    def _select_building(self, building_type) -> None:
        self.selected_building = building_type

    def _select_crop(self, crop_type) -> None:
        self.selected_crop = crop_type

    def handle_event(self, event) -> bool:
        if event.type == pygame.MOUSEMOTION:
            pos = event.pos
            for btn in self.mode_buttons + self.speed_buttons:
                btn.check_hover(pos)
            if self.show_build_menu:
                for btn in self.build_buttons:
                    btn.check_hover(pos)
            if self.show_farm_menu:
                for btn in self.farm_buttons:
                    btn.check_hover(pos)

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = event.pos
            for btn in self.mode_buttons:
                if btn.check_click(pos):
                    return True
            for btn in self.speed_buttons:
                if btn.check_click(pos):
                    return True
            if self.show_build_menu:
                for btn in self.build_buttons:
                    if btn.check_click(pos):
                        return True
            if self.show_farm_menu:
                for btn in self.farm_buttons:
                    if btn.check_click(pos):
                        return True
        return False

    def draw(
        self,
        screen,
        resource_manager,
        colonists,
        animals,
        game_time,
        world,
    ) -> None:
        # Top resource bar
        self._draw_resource_bar(screen, resource_manager)

        # Speed buttons
        for i, btn in enumerate(self.speed_buttons):
            btn.active = (
                self.game_speed
                == [SPEED_PAUSED, SPEED_NORMAL, SPEED_FAST, SPEED_VERY_FAST][i]
            )
            btn.draw(screen, self.font_small)

        # Game time display
        days = int(game_time // 3600)
        hours = int((game_time % 3600) // 150)
        time_text = f"第 {days + 1} 天  {hours:02d}:00"
        time_surf = self.font_medium.render(time_text, True, COLOR_UI_TEXT)
        screen.blit(time_surf, (SCREEN_WIDTH // 2 - time_surf.get_width() // 2, 8))

        # Population info
        alive_colonists = sum(1 for c in colonists if c.hp > 0)
        pop_text = f"人口: {alive_colonists}"
        pop_surf = self.font_medium.render(pop_text, True, COLOR_UI_TEXT)
        screen.blit(pop_surf, (SCREEN_WIDTH // 2 - pop_surf.get_width() // 2, 30))

        # Bottom bar background
        bar_rect = pygame.Rect(0, SCREEN_HEIGHT - 55, SCREEN_WIDTH, 55)
        pygame.draw.rect(screen, COLOR_UI_BG, bar_rect)
        pygame.draw.line(
            screen,
            COLOR_UI_BORDER,
            (0, SCREEN_HEIGHT - 55),
            (SCREEN_WIDTH, SCREEN_HEIGHT - 55),
            2,
        )

        # Mode buttons
        for btn in self.mode_buttons:
            btn.active = self.mode == {
                "normal": "选择",
                "build": "建造",
                "farm": "种植",
                "hunt": "捕猎",
                "chop": "砍树",
                "harvest": "收获",
            }.get(self.mode, "")
            btn.draw(screen, self.font_small)

        # Build submenu
        if self.show_build_menu:
            menu_rect = pygame.Rect(5, SCREEN_HEIGHT - 140, 300, 85)
            pygame.draw.rect(screen, COLOR_UI_PANEL, menu_rect, border_radius=5)
            pygame.draw.rect(screen, COLOR_UI_BORDER, menu_rect, 1, border_radius=5)
            for btn in self.build_buttons:
                btn.active = btn.text.startswith(
                    BUILDING_INFO[self.selected_building][0][:1],
                )
                btn.draw(screen, self.font_small)

        # Farm submenu
        if self.show_farm_menu:
            menu_rect = pygame.Rect(5, SCREEN_HEIGHT - 140, 200, 40)
            pygame.draw.rect(screen, COLOR_UI_PANEL, menu_rect, border_radius=5)
            pygame.draw.rect(screen, COLOR_UI_BORDER, menu_rect, 1, border_radius=5)
            for btn in self.farm_buttons:
                btn.active = (
                    self.selected_crop == CROP_RICE and "水稻" in btn.text
                ) or (self.selected_crop == CROP_POTATO and "土豆" in btn.text)
                btn.draw(screen, self.font_small)

        # Mode indicator
        mode_names = {
            "normal": "🖱 选择模式",
            "build": f"🔨 建造模式 - {BUILDING_INFO[self.selected_building][0]}",
            "farm": f"🌱 种植模式 - {CROP_INFO[self.selected_crop][0]}",
            "hunt": "🏹 捕猎模式 - 点击动物标记",
            "chop": "🪓 砍树模式 - 点击树木位置",
            "harvest": "🌾 收获模式 - 点击成熟作物",
        }
        mode_text = mode_names.get(self.mode, "")
        mode_surf = self.font_medium.render(mode_text, True, COLOR_UI_HIGHLIGHT)
        screen.blit(mode_surf, (10, 35))

        # Selected colonist info panel (right side)
        selected = [c for c in colonists if c.selected]
        if selected:
            self._draw_colonist_panel(screen, selected[0])

        # Help text
        help_texts = [
            "WASD/方向键:移动视角  滚轮:缩放  右键拖拽:平移",
            "左键:选择/操作  ESC:取消模式",
        ]
        for i, text in enumerate(help_texts):
            help_surf = self.font_small.render(text, True, (150, 150, 160))
            screen.blit(
                help_surf,
                (10, SCREEN_HEIGHT - 55 - (len(help_texts) - i) * 16),
            )

    def _draw_resource_bar(self, screen, resource_manager) -> None:
        bar_rect = pygame.Rect(0, 0, SCREEN_WIDTH, 32)
        pygame.draw.rect(screen, COLOR_UI_BG, bar_rect)
        pygame.draw.line(screen, COLOR_UI_BORDER, (0, 32), (SCREEN_WIDTH, 32), 1)

        resources = resource_manager.get_all()
        x = 10
        icons = {
            "木材": (139, 90, 43),
            "石材": (160, 160, 160),
            "食物": (200, 180, 50),
            "肉": (180, 60, 60),
        }
        for res_name, amount in resources.items():
            color = icons.get(res_name, (200, 200, 200))
            # Icon
            pygame.draw.rect(screen, color, (x, 8, 14, 14), border_radius=2)
            # Text
            text = f"{res_name}: {amount}"
            text_surf = self.font_small.render(text, True, COLOR_UI_TEXT)
            screen.blit(text_surf, (x + 18, 9))
            x += text_surf.get_width() + 30

    def _draw_colonist_panel(self, screen, colonist) -> None:
        panel_w = 200
        panel_h = 200
        panel_x = SCREEN_WIDTH - panel_w - 10
        panel_y = 40

        panel_rect = pygame.Rect(panel_x, panel_y, panel_w, panel_h)
        pygame.draw.rect(screen, COLOR_UI_PANEL, panel_rect, border_radius=5)
        pygame.draw.rect(screen, COLOR_UI_BORDER, panel_rect, 1, border_radius=5)

        y = panel_y + 8
        x = panel_x + 10

        # Name
        name_surf = self.font_medium.render(colonist.name, True, COLOR_UI_HIGHLIGHT)
        screen.blit(name_surf, (x, y))
        y += 25

        # HP
        hp_text = f"生命: {int(colonist.hp)}/{colonist.max_hp}"
        hp_surf = self.font_small.render(hp_text, True, COLOR_UI_TEXT)
        screen.blit(hp_surf, (x, y))
        y += 18

        # HP bar
        bar_w = panel_w - 20
        pygame.draw.rect(screen, (60, 60, 60), (x, y, bar_w, 8))
        hp_ratio = colonist.hp / colonist.max_hp
        hp_color = (
            (50, 200, 50)
            if hp_ratio > 0.5
            else (200, 200, 50)
            if hp_ratio > 0.25
            else (200, 50, 50)
        )
        pygame.draw.rect(screen, hp_color, (x, y, int(bar_w * hp_ratio), 8))
        y += 16

        # Hunger
        hunger_text = f"饥饿: {int(colonist.hunger)}%"
        hunger_surf = self.font_small.render(hunger_text, True, COLOR_UI_TEXT)
        screen.blit(hunger_surf, (x, y))
        y += 18

        # Hunger bar
        pygame.draw.rect(screen, (60, 60, 60), (x, y, bar_w, 8))
        hunger_ratio = colonist.hunger / 100
        pygame.draw.rect(screen, (200, 150, 50), (x, y, int(bar_w * hunger_ratio), 8))
        y += 16

        # Skills
        skills = [
            ("建造", colonist.build_skill),
            ("种植", colonist.farm_skill),
            ("狩猎", colonist.hunt_skill),
        ]
        for skill_name, skill_val in skills:
            skill_text = f"{skill_name}: {'★' * skill_val}{'☆' * (10 - skill_val)}"
            skill_surf = self.font_small.render(skill_text, True, COLOR_UI_TEXT)
            screen.blit(skill_surf, (x, y))
            y += 18

        # State
        state_names = {
            "idle": "空闲",
            "moving": "移动中",
            "building": "建造中",
            "farming": "种植中",
            "hunting": "捕猎中",
            "harvesting": "收获中",
            "eating": "进食中",
            "sleeping": "睡眠中",
        }
        state_text = f"状态: {state_names.get(colonist.state, colonist.state)}"
        state_surf = self.font_small.render(state_text, True, COLOR_UI_TEXT)
        screen.blit(state_surf, (x, y))