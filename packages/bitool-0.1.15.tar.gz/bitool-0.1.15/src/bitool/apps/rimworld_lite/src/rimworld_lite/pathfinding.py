"""Pathfinding module for rimworld_lite."""

import heapq


class PathFinder:
    def __init__(self, world) -> None:
        self.world = world
        self.cache = {}

    def find_path(self, start, end, max_iterations=500):
        """A*路径查找。start 和 end 是 (x, y) 瓦片坐标。"""
        if start == end:
            return [start]

        if not self.world.is_passable(end[0], end[1]):
            # 尝试找到离终点最近的可通行瓦片
            end = self._find_nearest_passable(end)
            if end is None:
                return []

        cache_key = (start, end)
        if cache_key in self.cache:
            return self.cache[cache_key]

        open_set = []
        heapq.heappush(open_set, (0, start))
        came_from = {}
        g_score = {start: 0}
        f_score = {start: self._heuristic(start, end)}
        iterations = 0

        while open_set and iterations < max_iterations:
            iterations += 1
            current = heapq.heappop(open_set)[1]

            if current == end:
                path = self._reconstruct_path(came_from, current)
                self.cache[cache_key] = path
                if len(self.cache) > 200:
                    # 限制缓存大小
                    keys = list(self.cache.keys())
                    for k in keys[:50]:
                        del self.cache[k]
                return path

            for neighbor in self._get_neighbors(current):
                tentative_g = g_score[current] + 1

                if neighbor not in g_score or tentative_g < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f_score[neighbor] = tentative_g + self._heuristic(neighbor, end)
                    heapq.heappush(open_set, (f_score[neighbor], neighbor))

        self.cache[cache_key] = []
        return []

    def _heuristic(self, a, b):
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    def _get_neighbors(self, pos):
        x, y = pos
        neighbors = []
        for dx, dy in [(0, -1), (0, 1), (-1, 0), (1, 0)]:
            nx, ny = x + dx, y + dy
            if self.world.is_passable(nx, ny):
                neighbors.append((nx, ny))
        return neighbors

    def _reconstruct_path(self, came_from, current):
        path = [current]
        while current in came_from:
            current = came_from[current]
            path.append(current)
        path.reverse()
        return path

    def _find_nearest_passable(self, pos):
        x, y = pos
        for radius in range(1, 10):
            for dy in range(-radius, radius + 1):
                for dx in range(-radius, radius + 1):
                    if abs(dx) == radius or abs(dy) == radius:
                        nx, ny = x + dx, y + dy
                        if self.world.is_passable(nx, ny):
                            return (nx, ny)
        return None

    def invalidate_cache(self) -> None:
        self.cache.clear()
