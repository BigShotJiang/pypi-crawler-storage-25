"""Ai module for rimworld_lite."""

import random

from .constants import (
    BUILDING_INFO,
    CROP_INFO,
    CROP_NONE,
    RESOURCE_FOOD,
    RESOURCE_MEAT,
    STATE_BUILDING,
    STATE_EATING,
    STATE_FARMING,
    STATE_HARVESTING,
    STATE_HUNTING,
    STATE_IDLE,
    STATE_MOVING,
)


class TaskManager:
    def __init__(self) -> None:
        self.tasks = []  # List of task dicts
        self.hunting_targets = []  # Animals marked for hunting

    def add_build_task(self, x, y, building_type):
        info = BUILDING_INFO.get(building_type)
        if info:
            task = {
                "type": "build",
                "x": x,
                "y": y,
                "building_type": building_type,
                "name": f"建造 {info[0]}",
                "required_wood": info[2],
                "required_stone": info[3],
                "work_needed": info[1],
                "work_done": 0,
                "assigned": False,
            }
            self.tasks.append(task)
            return task
        return None

    def add_farm_task(self, x, y, crop_type):
        info = CROP_INFO.get(crop_type)
        if info:
            task = {
                "type": "farm",
                "x": x,
                "y": y,
                "crop_type": crop_type,
                "name": f"种植 {info[0]}",
                "work_needed": 60,
                "work_done": 0,
                "assigned": False,
            }
            self.tasks.append(task)
            return task
        return None

    def add_harvest_task(self, x, y, crop_type):
        info = CROP_INFO.get(crop_type)
        if info:
            task = {
                "type": "harvest",
                "x": x,
                "y": y,
                "crop_type": crop_type,
                "name": f"收获 {info[0]}",
                "work_needed": 30,
                "work_done": 0,
                "assigned": False,
            }
            self.tasks.append(task)
            return task
        return None

    def add_hunt_task(self, animal):
        task = {
            "type": "hunt",
            "animal": animal,
            "name": f"捕猎 {animal.name}",
            "assigned": False,
        }
        self.tasks.append(task)
        self.hunting_targets.append(animal)
        return task

    def get_available_task(self, colonist):
        """获取下一个适合殖民者的未分配任务"""
        for task in self.tasks:
            if not task["assigned"]:
                task["assigned"] = True
                return task
        return None

    def remove_task(self, task) -> None:
        if task in self.tasks:
            self.tasks.remove(task)
        if task.get("animal") in self.hunting_targets:
            self.hunting_targets.remove(task["animal"])

    def get_tasks_at(self, x, y):
        """获取位置上的所有任务"""
        return [t for t in self.tasks if t.get("x") == x and t.get("y") == y]


class ColonistAI:
    def __init__(self, colonist, task_manager, world, pathfinder) -> None:
        self.colonist = colonist
        self.task_manager = task_manager
        self.world = world
        self.pathfinder = pathfinder
        self.current_task = None
        self.action_timer = 0
        self.idle_timer = 0

    def update(self, dt, game) -> None:
        colonist = self.colonist

        # 更新饥饿度
        colonist.hunger = min(100, colonist.hunger + 0.015 * dt * 60)

        # 优先级:非常饥饿时进食
        if colonist.hunger > 80:
            food_pos = self.world.find_nearest_resource(
                colonist.x,
                colonist.y,
                RESOURCE_FOOD,
                max_range=50,
            )
            if food_pos:
                if colonist.state == STATE_IDLE or self.current_task is None:
                    self.current_task = {
                        "type": "eat",
                        "target": food_pos,
                        "assigned": True,
                    }
            elif colonist.hunger > 95:
                colonist.hp -= 0.1 * dt * 60

        # 如果没有当前任务,获取一个
        if self.current_task is None and colonist.state == STATE_IDLE:
            self.idle_timer -= dt
            if self.idle_timer <= 0:
                self.idle_timer = 1.0  # 每秒检查一次
                task = self.task_manager.get_available_task(colonist)
                if task:
                    self.current_task = task

        # 处理当前任务
        if self.current_task:
            self._process_task(dt, game)
        else:
            colonist.state = STATE_IDLE

    def _process_task(self, dt, game) -> None:
        task = self.current_task

        if task["type"] == "build":
            self._handle_build_task(dt, task)
        elif task["type"] == "farm":
            self._handle_farm_task(dt, task)
        elif task["type"] == "harvest":
            self._handle_harvest_task(dt, task)
        elif task["type"] == "hunt":
            self._handle_hunt_task(dt, game, task)
        elif task["type"] == "eat":
            self._handle_eat_task(dt, task)

    def _handle_build_task(self, dt, task) -> None:
        colonist = self.colonist
        tx, ty = task["x"], task["y"]

        # 移动到建筑工地
        if colonist.state != STATE_BUILDING:
            # 找到相邻的可通行瓦片
            adj = self._find_adjacent_passable(tx, ty)
            if adj:
                path = self.pathfinder.find_path((colonist.x, colonist.y), adj)
                if path:
                    colonist.set_path(path)
                    colonist.state = STATE_MOVING
                else:
                    self._give_up_task("无法到达")
                    return
            else:
                self._give_up_task("无法到达")
                return

        # 检查是否到达建筑工地
        cx, cy = colonist.get_tile_pos()
        dist = abs(cx - tx) + abs(cy - ty)
        if dist <= 1:
            colonist.state = STATE_BUILDING
            task["work_done"] += colonist.build_skill * dt * 60
            if task["work_done"] >= task["work_needed"]:
                # 建筑完成
                self.world.place_building(tx, ty, task["building_type"])
                self.task_manager.remove_task(task)
                self.current_task = None
                colonist.state = STATE_IDLE

    def _handle_farm_task(self, dt, task) -> None:
        colonist = self.colonist
        tx, ty = task["x"], task["y"]

        if colonist.state != STATE_FARMING:
            adj = self._find_adjacent_passable(tx, ty)
            if adj:
                path = self.pathfinder.find_path((colonist.x, colonist.y), adj)
                if path:
                    colonist.set_path(path)
                    colonist.state = STATE_MOVING
                else:
                    self._give_up_task("无法到达")
                    return
            else:
                self._give_up_task("无法到达")
                return

        cx, cy = colonist.get_tile_pos()
        dist = abs(cx - tx) + abs(cy - ty)
        if dist <= 1:
            colonist.state = STATE_FARMING
            task["work_done"] += colonist.farm_skill * dt * 60
            if task["work_done"] >= task["work_needed"]:
                # 种植作物
                self.world.crops[ty][tx] = task["crop_type"]
                self.world.crop_growth[ty][tx] = 0
                self.task_manager.remove_task(task)
                self.current_task = None
                colonist.state = STATE_IDLE

    def _handle_harvest_task(self, dt, task) -> None:
        colonist = self.colonist
        tx, ty = task["x"], task["y"]

        if colonist.state != STATE_HARVESTING:
            adj = self._find_adjacent_passable(tx, ty)
            if adj:
                path = self.pathfinder.find_path((colonist.x, colonist.y), adj)
                if path:
                    colonist.set_path(path)
                    colonist.state = STATE_MOVING
                else:
                    self._give_up_task("无法到达")
                    return
            else:
                self._give_up_task("无法到达")
                return

        cx, cy = colonist.get_tile_pos()
        dist = abs(cx - tx) + abs(cy - ty)
        if dist <= 1:
            colonist.state = STATE_HARVESTING
            task["work_done"] += colonist.farm_skill * dt * 60
            if task["work_done"] >= task["work_needed"]:
                # 收获
                crop_type = task["crop_type"]
                info = CROP_INFO.get(crop_type)
                if info:
                    self.world.add_resource_on_ground(tx, ty, RESOURCE_FOOD, info[2])
                self.world.crops[ty][tx] = CROP_NONE
                self.world.crop_growth[ty][tx] = 0
                self.task_manager.remove_task(task)
                self.current_task = None
                colonist.state = STATE_IDLE

    def _handle_hunt_task(self, dt, game, task) -> None:
        colonist = self.colonist
        animal = task["animal"]

        if not animal.alive:
            self.task_manager.remove_task(task)
            self.current_task = None
            colonist.state = STATE_IDLE
            return

        # 移向动物
        dist = abs(colonist.x - animal.x) + abs(colonist.y - animal.y)

        if dist > 1:
            # 靠近
            adj = self._find_adjacent_passable(animal.x, animal.y)
            if adj:
                path = self.pathfinder.find_path((colonist.x, colonist.y), adj)
                if path:
                    colonist.set_path(path)
                    colonist.state = STATE_MOVING
                else:
                    self._give_up_task("无法到达猎物")
                    return
        else:
            # 攻击
            colonist.state = STATE_HUNTING
            self.action_timer -= dt
            if self.action_timer <= 0:
                self.action_timer = 1.0  # 每秒攻击一次
                damage = colonist.hunt_skill * random.randint(2, 5)
                animal.hp -= damage
                if animal.hp <= 0:
                    animal.alive = False
                    # 掉落肉
                    self.world.add_resource_on_ground(
                        animal.x,
                        animal.y,
                        RESOURCE_MEAT,
                        animal.meat_amount,
                    )
                    self.task_manager.remove_task(task)
                    self.current_task = None
                    colonist.state = STATE_IDLE

    def _handle_eat_task(self, dt, task) -> None:
        colonist = self.colonist
        tx, ty = task["target"]

        # 移动到食物处
        if colonist.state != STATE_EATING:
            path = self.pathfinder.find_path((colonist.x, colonist.y), (tx, ty))
            if path:
                colonist.set_path(path)
                colonist.state = STATE_MOVING
            else:
                self.current_task = None
                colonist.state = STATE_IDLE
                return

        cx, cy = colonist.get_tile_pos()
        if cx == tx and cy == ty:
            colonist.state = STATE_EATING
            self.action_timer -= dt
            if self.action_timer <= 0:
                self.action_timer = 0.5
                eaten = self.world.remove_resource_on_ground(tx, ty, RESOURCE_FOOD, 5)
                if eaten > 0:
                    colonist.hunger = max(0, colonist.hunger - eaten * 3)
                if colonist.hunger < 30:
                    self.current_task = None
                    colonist.state = STATE_IDLE

    def _find_adjacent_passable(self, x, y):
        """找到与 (x, y) 相邻的可通行瓦片"""
        for dx, dy in [
            (0, -1),
            (0, 1),
            (-1, 0),
            (1, 0),
            (-1, -1),
            (1, -1),
            (-1, 1),
            (1, 1),
        ]:
            nx, ny = x + dx, y + dy
            if self.world.is_passable(nx, ny):
                return (nx, ny)
        return None

    def _give_up_task(self, reason="") -> None:
        if self.current_task:
            self.task_manager.remove_task(self.current_task)
            self.current_task = None
        self.colonist.state = STATE_IDLE