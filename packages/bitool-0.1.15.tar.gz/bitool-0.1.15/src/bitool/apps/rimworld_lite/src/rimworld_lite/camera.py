"""Camera module for rimworld_lite."""

import pygame

from .constants import SCREEN_HEIGHT, SCREEN_WIDTH, TILE_SIZE


class Camera:
    def __init__(self, world_width, world_height) -> None:
        self.x = world_width * TILE_SIZE // 2 - SCREEN_WIDTH // 2
        self.y = world_height * TILE_SIZE // 2 - SCREEN_HEIGHT // 2
        self.zoom = 1.0
        self.min_zoom = 0.5
        self.max_zoom = 2.0
        self.scroll_speed = 10
        self.world_pixel_width = world_width * TILE_SIZE
        self.world_pixel_height = world_height * TILE_SIZE
        self.dragging = False
        self.drag_start = (0, 0)
        self.cam_start = (0, 0)

    def update(self, keys, dt) -> None:
        speed = int(self.scroll_speed * dt * 60)
        if keys[pygame.K_w] or keys[pygame.K_UP]:
            self.y -= speed
        if keys[pygame.K_s] or keys[pygame.K_DOWN]:
            self.y += speed
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            self.x -= speed
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            self.x += speed
        self._clamp()

    def _clamp(self) -> None:
        view_w = SCREEN_WIDTH / self.zoom
        view_h = SCREEN_HEIGHT / self.zoom
        self.x = max(0, min(self.x, self.world_pixel_width - view_w))
        self.y = max(0, min(self.y, self.world_pixel_height - view_h))

    def zoom_at(self, mouse_x, mouse_y, direction) -> None:
        old_zoom = self.zoom
        if direction > 0:
            self.zoom = min(self.max_zoom, self.zoom * 1.1)
        else:
            self.zoom = max(self.min_zoom, self.zoom / 1.1)

        # 向鼠标位置缩放
        mouse_world_x = self.x + mouse_x / old_zoom
        mouse_world_y = self.y + mouse_y / old_zoom
        self.x = mouse_world_x - mouse_x / self.zoom
        self.y = mouse_world_y - mouse_y / self.zoom
        self._clamp()

    def start_drag(self, mouse_pos) -> None:
        self.dragging = True
        self.drag_start = mouse_pos
        self.cam_start = (self.x, self.y)

    def update_drag(self, mouse_pos) -> None:
        if self.dragging:
            dx = (mouse_pos[0] - self.drag_start[0]) / self.zoom
            dy = (mouse_pos[1] - self.drag_start[1]) / self.zoom
            self.x = self.cam_start[0] - dx
            self.y = self.cam_start[1] - dy
            self._clamp()

    def stop_drag(self) -> None:
        self.dragging = False

    def screen_to_world(self, sx, sy):
        wx = int((sx / self.zoom + self.x) // TILE_SIZE)
        wy = int((sy / self.zoom + self.y) // TILE_SIZE)
        return wx, wy

    def world_to_screen(self, wx, wy):
        sx = (wx * TILE_SIZE - self.x) * self.zoom
        sy = (wy * TILE_SIZE - self.y) * self.zoom
        return sx, sy

    def apply(self, surface):
        surface.fill((0, 0, 0))
        return surface

    def get_visible_tiles(self):
        start_x = max(0, int(self.x / TILE_SIZE))
        start_y = max(0, int(self.y / TILE_SIZE))
        end_x = min(int((self.x + SCREEN_WIDTH / self.zoom) / TILE_SIZE) + 2, 100)
        end_y = min(int((self.y + SCREEN_HEIGHT / self.zoom) / TILE_SIZE) + 2, 100)
        return start_x, start_y, end_x, end_y