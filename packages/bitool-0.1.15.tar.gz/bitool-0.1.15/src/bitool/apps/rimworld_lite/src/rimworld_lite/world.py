"""World module for rimworld_lite."""

import math
import random

from .constants import (
    BUILDING_INFO,
    BUILDING_NONE,
    COLOR_DIRT,
    COLOR_FARM_PLOT,
    COLOR_FLOOR,
    COLOR_GRASS,
    COLOR_GRASS_DARK,
    COLOR_GRASS_LIGHT,
    COLOR_SAND,
    COLOR_STONE_GROUND,
    COLOR_WATER,
    COLOR_WATER_DEEP,
    TERRAIN_DIRT,
    TERRAIN_FARM_PLOT,
    TERRAIN_FLOOR,
    TERRAIN_GRASS,
    TERRAIN_SAND,
    TERRAIN_STONE,
    TERRAIN_WATER,
    WORLD_HEIGHT,
    WORLD_WIDTH,
)


class World:
    def __init__(self) -> None:
        self.width = WORLD_WIDTH
        self.height = WORLD_HEIGHT
        self.terrain = [
            [TERRAIN_GRASS for _ in range(self.width)] for _ in range(self.height)
        ]
        self.buildings = [
            [BUILDING_NONE for _ in range(self.width)] for _ in range(self.height)
        ]
        self.building_progress = [
            [0 for _ in range(self.width)] for _ in range(self.height)
        ]
        self.crops = [[0 for _ in range(self.width)] for _ in range(self.height)]
        self.crop_growth = [[0 for _ in range(self.width)] for _ in range(self.height)]
        self.resources_on_ground = {}  # (x, y) -> {resource_type: amount}
        self.generate()

    def generate(self) -> None:
        # 使用随机圆生成水域
        num_water = random.randint(3, 6)
        for _ in range(num_water):
            cx = random.randint(10, self.width - 10)
            cy = random.randint(10, self.height - 10)
            radius = random.randint(3, 8)
            for y in range(max(0, cy - radius - 2), min(self.height, cy + radius + 3)):
                for x in range(
                    max(0, cx - radius - 2),
                    min(self.width, cx + radius + 3),
                ):
                    dist = math.sqrt((x - cx) ** 2 + (y - cy) ** 2)
                    if dist < radius:
                        self.terrain[y][x] = TERRAIN_WATER
                    elif dist < radius + 2 and random.random() < 0.4:
                        self.terrain[y][x] = TERRAIN_SAND

        # 生成石头区域
        num_stone = random.randint(5, 10)
        for _ in range(num_stone):
            cx = random.randint(5, self.width - 5)
            cy = random.randint(5, self.height - 5)
            radius = random.randint(2, 5)
            for y in range(max(0, cy - radius), min(self.height, cy + radius + 1)):
                for x in range(max(0, cx - radius), min(self.width, cx + radius + 1)):
                    dist = math.sqrt((x - cx) ** 2 + (y - cy) ** 2)
                    if dist < radius and self.terrain[y][x] == TERRAIN_GRASS and random.random() < 0.6:
                        self.terrain[y][x] = TERRAIN_STONE

        # 生成泥土区域
        num_dirt = random.randint(4, 8)
        for _ in range(num_dirt):
            cx = random.randint(5, self.width - 5)
            cy = random.randint(5, self.height - 5)
            radius = random.randint(3, 7)
            for y in range(max(0, cy - radius), min(self.height, cy + radius + 1)):
                for x in range(max(0, cx - radius), min(self.width, cx + radius + 1)):
                    dist = math.sqrt((x - cx) ** 2 + (y - cy) ** 2)
                    if dist < radius and self.terrain[y][x] == TERRAIN_GRASS and random.random() < 0.5:
                        self.terrain[y][x] = TERRAIN_DIRT

        # 确保中心区域大部分是草地用于起始
        center_x, center_y = self.width // 2, self.height // 2
        for y in range(center_y - 8, center_y + 9):
            for x in range(center_x - 8, center_x + 9):
                if 0 <= x < self.width and 0 <= y < self.height:
                    dist = math.sqrt((x - center_x) ** 2 + (y - center_y) ** 2)
                    if dist < 8:
                        self.terrain[y][x] = TERRAIN_GRASS

    def is_passable(self, x, y):
        if x < 0 or x >= self.width or y < 0 or y >= self.height:
            return False
        if self.terrain[y][x] == TERRAIN_WATER:
            return False
        building = self.buildings[y][x]
        if building == BUILDING_NONE:
            return True
        info = BUILDING_INFO.get(building)
        if info:
            return info[4]  # 可通行
        return False

    def get_terrain_color(self, x, y):
        terrain = self.terrain[y][x]
        # 添加轻微变化
        seed = (x * 7 + y * 13) % 3
        if terrain == TERRAIN_GRASS:
            colors = [COLOR_GRASS, COLOR_GRASS_DARK, COLOR_GRASS_LIGHT]
            return colors[seed]
        elif terrain == TERRAIN_DIRT:
            return COLOR_DIRT
        elif terrain == TERRAIN_SAND:
            return COLOR_SAND
        elif terrain == TERRAIN_WATER:
            return COLOR_WATER if seed != 0 else COLOR_WATER_DEEP
        elif terrain == TERRAIN_STONE:
            return COLOR_STONE_GROUND
        elif terrain == TERRAIN_FLOOR:
            return COLOR_FLOOR
        elif terrain == TERRAIN_FARM_PLOT:
            return COLOR_FARM_PLOT
        return COLOR_GRASS

    def place_building(self, x, y, building_type) -> bool:
        if 0 <= x < self.width and 0 <= y < self.height and self.terrain[y][x] != TERRAIN_WATER:
            self.buildings[y][x] = building_type
            self.building_progress[y][x] = 0
            if building_type == BUILDING_INFO.get(8) and 8 in BUILDING_INFO:
                pass  # 农田地形变化单独处理
            return True
        return False

    def remove_building(self, x, y) -> None:
        if 0 <= x < self.width and 0 <= y < self.height:
            self.buildings[y][x] = BUILDING_NONE
            self.building_progress[y][x] = 0

    def add_resource_on_ground(self, x, y, resource_type, amount) -> None:
        key = (x, y)
        if key not in self.resources_on_ground:
            self.resources_on_ground[key] = {}
        if resource_type not in self.resources_on_ground[key]:
            self.resources_on_ground[key][resource_type] = 0
        self.resources_on_ground[key][resource_type] += amount

    def remove_resource_on_ground(self, x, y, resource_type, amount):
        key = (x, y)
        if key in self.resources_on_ground and resource_type in self.resources_on_ground[key]:
            removed = min(amount, self.resources_on_ground[key][resource_type])
            self.resources_on_ground[key][resource_type] -= removed
            if self.resources_on_ground[key][resource_type] <= 0:
                del self.resources_on_ground[key][resource_type]
            if not self.resources_on_ground[key]:
                del self.resources_on_ground[key]
            return removed
        return 0

    def find_nearest_resource(self, x, y, resource_type, max_range=30):
        """查找给定类型最近的地面资源"""
        best_dist = float("inf")
        best_pos = None
        for (rx, ry), resources in self.resources_on_ground.items():
            if resource_type in resources and resources[resource_type] > 0:
                dist = abs(rx - x) + abs(ry - y)
                if dist < best_dist and dist <= max_range:
                    best_dist = dist
                    best_pos = (rx, ry)
        return best_pos

    def find_nearest_storage(self, x, y, max_range=50):
        """查找最近的储物建筑"""
        from .constants import BUILDING_STORAGE

        best_dist = float("inf")
        best_pos = None
        for row in range(self.height):
            for col in range(self.width):
                if self.buildings[row][col] == BUILDING_STORAGE:
                    dist = abs(col - x) + abs(row - y)
                    if dist < best_dist and dist <= max_range:
                        best_dist = dist
                        best_pos = (col, row)
        return best_pos

    def find_trees_to_chop(self, x, y, max_range=30):
        """查找可砍伐的树木(用草地瓦片表示树木) - 使用更简单的方法"""
        # 树木在草地上;我们选择一个随机的附近草地瓦片
        # 在完整的游戏中,树木将是独立的实体
        best_dist = float("inf")
        best_pos = None
        for dy in range(-max_range, max_range + 1):
            for dx in range(-max_range, max_range + 1):
                nx, ny = x + dx, y + dy
                if (
                    0 <= nx < self.width
                    and 0 <= ny < self.height
                    and (
                        self.terrain[ny][nx] == TERRAIN_GRASS
                        and self.buildings[ny][nx] == 0
                    )
                ):
                    dist = abs(dx) + abs(dy)
                    if dist < best_dist and dist > 3:
                        best_dist = dist
                        best_pos = (nx, ny)
        if best_pos:
            return best_pos
        return None