"""Constants module for rimworld_lite."""

# 屏幕设置
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
FPS = 60

# 瓦片设置
TILE_SIZE = 32
WORLD_WIDTH = 100
WORLD_HEIGHT = 100

# 颜色定义
COLOR_BLACK = (0, 0, 0)
COLOR_WHITE = (255, 255, 255)
COLOR_GRAY = (128, 128, 128)
COLOR_DARK_GRAY = (64, 64, 64)
COLOR_LIGHT_GRAY = (192, 192, 192)

# 地形颜色
COLOR_GRASS = (76, 153, 0)
COLOR_GRASS_DARK = (60, 130, 0)
COLOR_GRASS_LIGHT = (100, 180, 30)
COLOR_DIRT = (139, 119, 101)
COLOR_SAND = (210, 180, 140)
COLOR_WATER = (64, 164, 223)
COLOR_WATER_DEEP = (30, 120, 200)
COLOR_STONE_GROUND = (160, 160, 160)
COLOR_FLOOR = (180, 160, 130)

# 建筑颜色
COLOR_WOOD = (139, 90, 43)
COLOR_WOOD_WALL = (120, 75, 35)
COLOR_STONE_WALL = (140, 140, 140)
COLOR_STONE_WALL_DARK = (110, 110, 110)
COLOR_WORKBENCH = (160, 120, 60)
COLOR_STORAGE = (180, 140, 80)
COLOR_BED = (200, 100, 100)
COLOR_DOOR = (100, 70, 40)
COLOR_FARM_PLOT = (90, 60, 30)

# 实体颜色
COLOR_COLONIST = (65, 105, 225)
COLOR_COLONIST_SELECTED = (100, 149, 237)
COLOR_DEER = (180, 130, 70)
COLOR_RABBIT = (200, 180, 160)
COLOR_WOLF = (100, 100, 100)
COLOR_CHICKEN = (240, 220, 180)

# 作物颜色
COLOR_CROP_SEED = (139, 119, 60)
COLOR_CROP_GROWING = (50, 150, 50)
COLOR_CROP_MATURE = (200, 180, 50)

# UI颜色
COLOR_UI_BG = (40, 40, 50)
COLOR_UI_PANEL = (50, 50, 65)
COLOR_UI_BORDER = (80, 80, 100)
COLOR_UI_BUTTON = (70, 70, 90)
COLOR_UI_BUTTON_HOVER = (90, 90, 120)
COLOR_UI_BUTTON_ACTIVE = (110, 110, 150)
COLOR_UI_TEXT = (220, 220, 220)
COLOR_UI_HIGHLIGHT = (255, 200, 50)
COLOR_UI_HEALTH = (200, 50, 50)
COLOR_UI_HUNGER = (200, 150, 50)

# 地形类型
TERRAIN_GRASS = 0
TERRAIN_DIRT = 1
TERRAIN_SAND = 2
TERRAIN_WATER = 3
TERRAIN_STONE = 4
TERRAIN_FLOOR = 5
TERRAIN_FARM_PLOT = 6

# 建筑类型
BUILDING_NONE = 0
BUILDING_WALL_WOOD = 1
BUILDING_WALL_STONE = 2
BUILDING_FLOOR_WOOD = 3
BUILDING_WORKBENCH = 4
BUILDING_STORAGE = 5
BUILDING_BED = 6
BUILDING_DOOR = 7
BUILDING_FARM_PLOT = 8

# 建筑信息: {类型: (名称, 建造时间(帧), 需要木材, 需要石材, 是否可通行, 是否可建造在已有建筑上)}
BUILDING_INFO = {
    BUILDING_WALL_WOOD: ("木墙", 120, 5, 0, False, False),
    BUILDING_WALL_STONE: ("石墙", 180, 0, 8, False, False),
    BUILDING_FLOOR_WOOD: ("木地板", 60, 2, 0, True, False),
    BUILDING_WORKBENCH: ("工作台", 240, 10, 2, False, False),
    BUILDING_STORAGE: ("储物区", 120, 5, 0, True, False),
    BUILDING_BED: ("床", 150, 8, 0, False, False),
    BUILDING_DOOR: ("门", 100, 4, 0, True, False),
    BUILDING_FARM_PLOT: ("农田", 90, 3, 0, True, False),
}

# 资源类型
RESOURCE_WOOD = "木材"
RESOURCE_STONE = "石材"
RESOURCE_FOOD = "食物"
RESOURCE_MEAT = "肉"

# 作物类型
CROP_NONE = 0
CROP_RICE = 1
CROP_POTATO = 2

CROP_INFO = {
    CROP_RICE: ("水稻", 600, 8),  # (名称, 生长时间(帧), 产量)
    CROP_POTATO: ("土豆", 900, 12),
}

# 实体状态
STATE_IDLE = "idle"
STATE_MOVING = "moving"
STATE_BUILDING = "building"
STATE_FARMING = "farming"
STATE_HUNTING = "hunting"
STATE_HARVESTING = "harvesting"
STATE_EATING = "eating"
STATE_SLEEPING = "sleeping"
STATE_FLEEING = "fleeing"
STATE_WANDERING = "wandering"

# 动物类型
ANIMAL_DEER = "deer"
ANIMAL_RABBIT = "rabbit"
ANIMAL_WOLF = "wolf"
ANIMAL_CHICKEN = "chicken"

ANIMAL_INFO = {
    ANIMAL_DEER: {
        "name": "鹿",
        "hp": 80,
        "speed": 1.5,
        "meat": 20,
        "hostile": False,
        "flee": True,
    },
    ANIMAL_RABBIT: {
        "name": "兔子",
        "hp": 20,
        "speed": 2.5,
        "meat": 5,
        "hostile": False,
        "flee": True,
    },
    ANIMAL_WOLF: {
        "name": "狼",
        "hp": 100,
        "speed": 2.0,
        "meat": 25,
        "hostile": True,
        "flee": False,
    },
    ANIMAL_CHICKEN: {
        "name": "鸡",
        "hp": 15,
        "speed": 1.8,
        "meat": 4,
        "hostile": False,
        "flee": True,
    },
}

# 游戏速度
SPEED_PAUSED = 0
SPEED_NORMAL = 1
SPEED_FAST = 2
SPEED_VERY_FAST = 3

SPEED_MULTIPLIERS = {
    SPEED_PAUSED: 0,
    SPEED_NORMAL: 1,
    SPEED_FAST: 3,
    SPEED_VERY_FAST: 6,
}