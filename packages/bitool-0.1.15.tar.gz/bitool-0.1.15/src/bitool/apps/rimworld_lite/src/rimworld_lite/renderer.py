"""Renderer module for rimworld_lite."""

import pygame

from .constants import (
    BUILDING_BED,
    BUILDING_DOOR,
    BUILDING_FARM_PLOT,
    BUILDING_FLOOR_WOOD,
    BUILDING_NONE,
    BUILDING_STORAGE,
    BUILDING_WALL_STONE,
    BUILDING_WALL_WOOD,
    BUILDING_WORKBENCH,
    COLOR_BED,
    COLOR_CROP_GROWING,
    COLOR_CROP_MATURE,
    COLOR_CROP_SEED,
    COLOR_DOOR,
    COLOR_FARM_PLOT,
    COLOR_STONE_WALL,
    COLOR_STONE_WALL_DARK,
    COLOR_STORAGE,
    COLOR_WOOD,
    COLOR_WOOD_WALL,
    COLOR_WORKBENCH,
    CROP_INFO,
    CROP_NONE,
    CROP_POTATO,
    CROP_RICE,
    RESOURCE_FOOD,
    RESOURCE_MEAT,
    RESOURCE_STONE,
    RESOURCE_WOOD,
    TILE_SIZE,
)


class Renderer:
    def __init__(self, screen) -> None:
        self.screen = screen
        self.font_small = None
        self.font_medium = None
        self.font_large = None
        self._init_fonts()

    def _init_fonts(self) -> None:
        try:
            self.font_small = pygame.font.SysFont("simhei", 14)
            self.font_medium = pygame.font.SysFont("simhei", 18)
            self.font_large = pygame.font.SysFont("simhei", 24)
        except Exception:  # noqa: BLE001
            self.font_small = pygame.font.Font(None, 16)
            self.font_medium = pygame.font.Font(None, 20)
            self.font_large = pygame.font.Font(None, 28)

    def draw_world(self, world, camera) -> None:
        start_x, start_y, end_x, end_y = camera.get_visible_tiles()
        zoom = camera.zoom
        tile_screen_size = int(TILE_SIZE * zoom)

        for y in range(start_y, end_y):
            for x in range(start_x, end_x):
                if 0 <= x < world.width and 0 <= y < world.height:
                    sx, sy = camera.world_to_screen(x, y)
                    sx, sy = int(sx), int(sy)

                    # 绘制地形
                    color = world.get_terrain_color(x, y)
                    pygame.draw.rect(
                        self.screen,
                        color,
                        (sx, sy, tile_screen_size, tile_screen_size),
                    )

                    # 绘制网格线(淡淡的)
                    if zoom > 0.7:
                        grid_color = (color[0] - 15, color[1] - 15, color[2] - 15)
                        grid_color = tuple(max(0, c) for c in grid_color)
                        pygame.draw.rect(
                            self.screen,
                            grid_color,
                            (sx, sy, tile_screen_size, tile_screen_size),
                            1,
                        )

                    # 绘制建筑
                    building = world.buildings[y][x]
                    if building != BUILDING_NONE:
                        self._draw_building(sx, sy, tile_screen_size, building, zoom)

                    # 绘制作物
                    crop = world.crops[y][x]
                    if crop != CROP_NONE:
                        self._draw_crop(
                            sx,
                            sy,
                            tile_screen_size,
                            crop,
                            world.crop_growth[y][x],
                            zoom,
                        )

                    # 绘制地面上的资源
                    key = (x, y)
                    if key in world.resources_on_ground:
                        self._draw_ground_resources(
                            sx,
                            sy,
                            tile_screen_size,
                            world.resources_on_ground[key],
                            zoom,
                        )

    def _draw_building(self, sx, sy, size, building_type, zoom) -> None:
        margin = max(1, int(size * 0.05))

        if building_type == BUILDING_WALL_WOOD:
            pygame.draw.rect(
                self.screen,
                COLOR_WOOD_WALL,
                (sx + margin, sy + margin, size - margin * 2, size - margin * 2),
            )
            # 木纹线条
            line_color = (100, 60, 25)
            for i in range(3):
                ly = sy + margin + int((size - margin * 2) * (i + 1) / 4)
                pygame.draw.line(
                    self.screen,
                    line_color,
                    (sx + margin + 2, ly),
                    (sx + size - margin - 2, ly),
                    1,
                )

        elif building_type == BUILDING_WALL_STONE:
            pygame.draw.rect(
                self.screen,
                COLOR_STONE_WALL,
                (sx + margin, sy + margin, size - margin * 2, size - margin * 2),
            )
            # 石头纹理
            dark = COLOR_STONE_WALL_DARK
            pygame.draw.line(
                self.screen,
                dark,
                (sx + size // 2, sy + margin),
                (sx + size // 2, sy + size - margin),
                1,
            )
            pygame.draw.line(
                self.screen,
                dark,
                (sx + margin, sy + size // 2),
                (sx + size - margin, sy + size // 2),
                1,
            )

        elif building_type == BUILDING_FLOOR_WOOD:
            pygame.draw.rect(
                self.screen,
                COLOR_WOOD,
                (sx + margin, sy + margin, size - margin * 2, size - margin * 2),
            )
            # 板条线条
            line_color = (120, 80, 35)
            for i in range(1, 4):
                lx = sx + margin + int((size - margin * 2) * i / 4)
                pygame.draw.line(
                    self.screen,
                    line_color,
                    (lx, sy + margin),
                    (lx, sy + size - margin),
                    1,
                )

        elif building_type == BUILDING_WORKBENCH:
            pygame.draw.rect(
                self.screen,
                COLOR_WORKBENCH,
                (sx + margin, sy + margin, size - margin * 2, size - margin * 2),
            )
            # 顶部的工具
            tool_color = (100, 80, 40)
            cx, cy = sx + size // 2, sy + size // 2
            pygame.draw.line(
                self.screen,
                tool_color,
                (cx - 5, cy - 5),
                (cx + 5, cy + 5),
                2,
            )
            pygame.draw.line(
                self.screen,
                tool_color,
                (cx + 5, cy - 5),
                (cx - 5, cy + 5),
                2,
            )

        elif building_type == BUILDING_STORAGE:
            pygame.draw.rect(
                self.screen,
                COLOR_STORAGE,
                (sx + margin, sy + margin, size - margin * 2, size - margin * 2),
            )
            # 箱子图标
            box_color = (140, 100, 50)
            inner = int(size * 0.3)
            bx = sx + (size - inner) // 2
            by = sy + (size - inner) // 2
            pygame.draw.rect(self.screen, box_color, (bx, by, inner, inner), 2)

        elif building_type == BUILDING_BED:
            pygame.draw.rect(
                self.screen,
                COLOR_BED,
                (sx + margin, sy + margin, size - margin * 2, size - margin * 2),
            )
            # 枕头
            pillow_color = (230, 220, 200)
            pw = int(size * 0.3)
            ph = int(size * 0.2)
            pygame.draw.rect(
                self.screen,
                pillow_color,
                (sx + margin + 2, sy + margin + 2, pw, ph),
            )

        elif building_type == BUILDING_DOOR:
            pygame.draw.rect(
                self.screen,
                COLOR_DOOR,
                (sx + margin, sy + margin, size - margin * 2, size - margin * 2),
            )
            # 门把手
            handle_color = (200, 180, 100)
            hx = sx + int(size * 0.7)
            hy = sy + size // 2
            pygame.draw.circle(
                self.screen,
                handle_color,
                (hx, hy),
                max(2, int(3 * zoom)),
            )

        elif building_type == BUILDING_FARM_PLOT:
            pygame.draw.rect(
                self.screen,
                COLOR_FARM_PLOT,
                (sx + margin, sy + margin, size - margin * 2, size - margin * 2),
            )
            # 垄沟线条
            furrow_color = (70, 45, 20)
            for i in range(1, 4):
                ly = sy + margin + int((size - margin * 2) * i / 4)
                pygame.draw.line(
                    self.screen,
                    furrow_color,
                    (sx + margin + 1, ly),
                    (sx + size - margin - 1, ly),
                    1,
                )

    def _draw_crop(self, sx, sy, size, crop_type, growth, zoom) -> None:
        info = CROP_INFO.get(crop_type)
        if not info:
            return

        total_growth = info[1]
        progress = min(1.0, growth / total_growth)

        # 根据生长阶段确定颜色
        if progress < 0.2:
            color = COLOR_CROP_SEED
        elif progress < 0.8:
            color = COLOR_CROP_GROWING
        else:
            color = COLOR_CROP_MATURE

        # 绘制作物为小圆点
        cx, cy = sx + size // 2, sy + size // 2
        dot_size = max(2, int(3 * zoom * (0.5 + progress * 0.5)))

        if crop_type == CROP_RICE:
            # 水稻: 多个小茎
            for i in range(3):
                dx = (i - 1) * int(4 * zoom)
                pygame.draw.circle(self.screen, color, (cx + dx, cy), dot_size)
            if progress > 0.5:
                # 顶部的稻谷
                grain_color = (240, 230, 180)
                for i in range(3):
                    dx = (i - 1) * int(4 * zoom)
                    pygame.draw.circle(
                        self.screen,
                        grain_color,
                        (cx + dx, cy - int(4 * zoom)),
                        max(1, dot_size - 1),
                    )
        elif crop_type == CROP_POTATO:
            # 土豆: 灌木状
            pygame.draw.circle(self.screen, color, (cx, cy), int(dot_size * 1.5))
            if progress > 0.6:
                # 花朵
                flower_color = (200, 180, 220)
                for dx, dy in [(-3, -3), (3, -3), (0, -5)]:
                    pygame.draw.circle(
                        self.screen,
                        flower_color,
                        (cx + int(dx * zoom), cy + int(dy * zoom)),
                        max(1, int(2 * zoom)),
                    )

    def _draw_ground_resources(self, sx, sy, size, resources, zoom) -> None:
        """绘制地面上的资源指示器"""
        y_offset = 0
        for res_type, amount in resources.items():
            if amount <= 0:
                continue
            # 根据资源类型设置颜色
            if res_type == RESOURCE_WOOD:
                color = (139, 90, 43)
            elif res_type == RESOURCE_STONE:
                color = (160, 160, 160)
            elif res_type == RESOURCE_FOOD:
                color = (200, 180, 50)
            elif res_type == RESOURCE_MEAT:
                color = (180, 60, 60)
            else:
                color = (200, 200, 200)

            # 绘制资源堆
            pile_size = min(int(size * 0.4), int(6 + amount * 0.5))
            px = sx + size // 2
            py = sy + size // 2 + y_offset
            pygame.draw.circle(self.screen, color, (px, py), pile_size)
            # 高光
            highlight = tuple(min(255, c + 40) for c in color)
            pygame.draw.circle(
                self.screen,
                highlight,
                (px - 1, py - 1),
                max(1, pile_size - 2),
            )

            # 数量文本
            if zoom > 0.8:
                font = pygame.font.SysFont("simhei", max(8, int(10 * zoom)))
                text = font.render(str(amount), True, (255, 255, 255))
                self.screen.blit(
                    text,
                    (px - text.get_width() // 2, py - text.get_height() // 2),
                )
            y_offset += int(8 * zoom)

    def draw_build_preview(self, camera, x, y, building_type) -> None:
        """绘制建筑放置预览"""
        sx, sy = camera.world_to_screen(x, y)
        zoom = camera.zoom
        size = int(TILE_SIZE * zoom)

        # 半透明预览
        preview_surf = pygame.Surface((size, size), pygame.SRCALPHA)
        preview_surf.fill((100, 200, 100, 80))
        self.screen.blit(preview_surf, (int(sx), int(sy)))
        pygame.draw.rect(
            self.screen,
            (100, 255, 100),
            (int(sx), int(sy), size, size),
            2,
        )

    def draw_selection_box(self, camera, start, end) -> None:
        """绘制选择矩形框"""
        sx1, sy1 = start
        sx2, sy2 = end
        x = min(sx1, sx2)
        y = min(sy1, sy2)
        w = abs(sx2 - sx1)
        h = abs(sy2 - sy1)

        sel_surf = pygame.Surface((w, h), pygame.SRCALPHA)
        sel_surf.fill((100, 149, 237, 40))
        self.screen.blit(sel_surf, (x, y))
        pygame.draw.rect(self.screen, (100, 149, 237), (x, y, w, h), 2)