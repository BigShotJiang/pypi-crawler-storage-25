"""Main module for rimworld_lite."""

import math
import random

import pygame

from .ai import ColonistAI, TaskManager
from .camera import Camera
from .constants import (
    ANIMAL_CHICKEN,
    ANIMAL_DEER,
    ANIMAL_RABBIT,
    ANIMAL_WOLF,
    BUILDING_FARM_PLOT,
    BUILDING_INFO,
    BUILDING_NONE,
    COLOR_UI_BG,
    CROP_INFO,
    CROP_NONE,
    FPS,
    RESOURCE_FOOD,
    RESOURCE_STONE,
    RESOURCE_WOOD,
    SCREEN_HEIGHT,
    SCREEN_WIDTH,
    SPEED_MULTIPLIERS,
    TERRAIN_GRASS,
    TERRAIN_STONE,
    TERRAIN_WATER,
    WORLD_HEIGHT,
    WORLD_WIDTH,
)
from .entities import Animal, Colonist
from .pathfinding import PathFinder
from .renderer import Renderer
from .resources import ResourceManager
from .ui import UI
from .world import World


class Game:
    def __init__(self) -> None:
        pygame.init()
        pygame.display.set_caption("殖民边缘 - RimWorld Lite")
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.clock = pygame.time.Clock()
        self.running = True

        # 核心系统
        self.world = World()
        self.camera = Camera(WORLD_WIDTH, WORLD_HEIGHT)
        self.pathfinder = PathFinder(self.world)
        self.resource_manager = ResourceManager()
        self.task_manager = TaskManager()
        self.renderer = Renderer(self.screen)
        self.ui = UI(self.screen)

        # 游戏状态
        self.game_time = 0.0
        self.colonists = []
        self.animals = []
        self.colonist_ais = []

        # 输入状态
        self.selecting = False
        self.select_start = (0, 0)
        self.select_end = (0, 0)
        self.mouse_world_pos = (0, 0)

        # 初始化游戏
        self._spawn_initial_colonists()
        self._spawn_initial_animals()
        self._spawn_initial_resources()

    def _spawn_initial_colonists(self) -> None:
        names = ["张三", "李四", "王五"]
        cx, cy = WORLD_WIDTH // 2, WORLD_HEIGHT // 2
        for i, name in enumerate(names):
            x = cx - 1 + i
            y = cy
            colonist = Colonist(x, y, name)
            self.colonists.append(colonist)
            ai = ColonistAI(colonist, self.task_manager, self.world, self.pathfinder)
            self.colonist_ais.append(ai)

    def _spawn_initial_animals(self) -> None:
        animal_types = [ANIMAL_DEER, ANIMAL_RABBIT, ANIMAL_CHICKEN, ANIMAL_WOLF]
        for _ in range(25):
            for _attempt in range(20):
                x = random.randint(5, WORLD_WIDTH - 5)
                y = random.randint(5, WORLD_HEIGHT - 5)
                if self.world.terrain[y][x] == TERRAIN_GRASS:
                    # 不要在中心附近生成
                    dist = math.sqrt(
                        (x - WORLD_WIDTH // 2) ** 2 + (y - WORLD_HEIGHT // 2) ** 2,
                    )
                    if dist > 15:
                        animal_type = random.choices(
                            animal_types,
                            weights=[40, 30, 20, 10],
                        )[0]
                        animal = Animal(x, y, animal_type)
                        self.animals.append(animal)
                        break

    def _spawn_initial_resources(self) -> None:
        """在地图上生成一些初始资源"""
        # 在地图上散布木材和石材
        for _ in range(40):
            x = random.randint(5, WORLD_WIDTH - 5)
            y = random.randint(5, WORLD_HEIGHT - 5)
            if self.world.terrain[y][x] == TERRAIN_GRASS:
                amount = random.randint(3, 10)
                self.world.add_resource_on_ground(x, y, RESOURCE_WOOD, amount)

        for _ in range(25):
            x = random.randint(5, WORLD_WIDTH - 5)
            y = random.randint(5, WORLD_HEIGHT - 5)
            if self.world.terrain[y][x] == TERRAIN_STONE:
                amount = random.randint(3, 8)
                self.world.add_resource_on_ground(x, y, RESOURCE_STONE, amount)

        # 一些靠近中心的食物
        for _ in range(10):
            x = WORLD_WIDTH // 2 + random.randint(-10, 10)
            y = WORLD_HEIGHT // 2 + random.randint(-10, 10)
            if 0 <= x < WORLD_WIDTH and 0 <= y < WORLD_HEIGHT and self.world.terrain[y][x] == TERRAIN_GRASS:
                self.world.add_resource_on_ground(
                    x,
                    y,
                    RESOURCE_FOOD,
                    random.randint(5, 15),
                )

    def run(self) -> None:
        while self.running:
            dt = self.clock.tick(FPS) / 1000.0
            self._handle_events()
            self._update(dt)
            self._draw()
        pygame.quit()

    def _handle_events(self) -> None:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
                return

            # 先让UI处理事件
            if self.ui.handle_event(event):
                continue

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.ui._set_mode("normal")
                elif event.key == pygame.K_1:
                    self.ui._set_speed(0)  # 暂停
                elif event.key == pygame.K_2:
                    self.ui._set_speed(1)  # 正常
                elif event.key == pygame.K_3:
                    self.ui._set_speed(2)  # 快速
                elif event.key == pygame.K_4:
                    self.ui._set_speed(3)  # 极速
                elif event.key == pygame.K_b:
                    self.ui._set_mode("build")
                elif event.key == pygame.K_f:
                    self.ui._set_mode("farm")
                elif event.key == pygame.K_h:
                    self.ui._set_mode("hunt")
                elif event.key == pygame.K_c:
                    self.ui._set_mode("chop")
                elif event.key == pygame.K_r:
                    self.ui._set_mode("harvest")
                elif event.key == pygame.K_SPACE:
                    # 切换暂停
                    if self.ui.game_speed == 0:
                        self.ui._set_speed(1)
                    else:
                        self.ui._set_speed(0)

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # 左键点击
                    self._handle_left_click(event.pos)
                elif event.button == 3:  # 右键点击 - 开始拖拽
                    self.camera.start_drag(event.pos)
                elif event.button == 4:  # 滚轮向上 - 放大
                    self.camera.zoom_at(event.pos[0], event.pos[1], 1)
                elif event.button == 5:  # 滚轮向下 - 缩小
                    self.camera.zoom_at(event.pos[0], event.pos[1], -1)

            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    if self.selecting:
                        self._handle_selection()
                        self.selecting = False
                elif event.button == 3:
                    self.camera.stop_drag()

            elif event.type == pygame.MOUSEMOTION:
                if self.camera.dragging:
                    self.camera.update_drag(event.pos)
                if self.selecting:
                    self.select_end = event.pos

                # 更新鼠标世界位置
                self.mouse_world_pos = self.camera.screen_to_world(
                    event.pos[0],
                    event.pos[1],
                )

    def _handle_left_click(self, pos) -> None:
        mode = self.ui.mode
        wx, wy = self.camera.screen_to_world(pos[0], pos[1])

        if mode == "normal":
            # 检查是否点击了殖民者
            clicked_colonist = False
            for colonist in self.colonists:
                cx, cy = colonist.get_tile_pos()
                if cx == wx and cy == wy:
                    # 如果按住了Shift键,切换选择
                    keys = pygame.key.get_mods()
                    if keys & pygame.KMOD_SHIFT:
                        colonist.selected = not colonist.selected
                    else:
                        for c in self.colonists:
                            c.selected = False
                        colonist.selected = True
                    clicked_colonist = True
                    break

            if not clicked_colonist:
                # 开始框选
                keys = pygame.key.get_mods()
                if not (keys & pygame.KMOD_SHIFT):
                    for c in self.colonists:
                        c.selected = False
                self.selecting = True
                self.select_start = pos
                self.select_end = pos

        elif mode == "build":
            self._handle_build(wx, wy)

        elif mode == "farm":
            self._handle_farm(wx, wy)

        elif mode == "hunt":
            self._handle_hunt(wx, wy)

        elif mode == "chop":
            self._handle_chop(wx, wy)

        elif mode == "harvest":
            self._handle_harvest(wx, wy)

    def _handle_selection(self) -> None:
        """处理殖民者的框选"""
        x1, y1 = self.select_start
        x2, y2 = self.select_end

        if abs(x2 - x1) < 5 and abs(y2 - y1) < 5:
            return  # 太小,忽略

        # 将屏幕坐标转换为世界坐标
        wx1, wy1 = self.camera.screen_to_world(min(x1, x2), min(y1, y2))
        wx2, wy2 = self.camera.screen_to_world(max(x1, x2), max(y1, y2))

        for colonist in self.colonists:
            cx, cy = colonist.get_tile_pos()
            if wx1 <= cx <= wx2 and wy1 <= cy <= wy2:
                colonist.selected = True

    def _handle_build(self, wx, wy) -> None:
        building_type = self.ui.selected_building
        info = BUILDING_INFO.get(building_type)
        if not info:
            return

        # 检查资源
        if not self.resource_manager.has(RESOURCE_WOOD, info[2]):
            return
        if not self.resource_manager.has(RESOURCE_STONE, info[3]):
            return

        # 检查瓦片是否有效
        if not (0 <= wx < WORLD_WIDTH and 0 <= wy < WORLD_HEIGHT):
            return
        if self.world.terrain[wy][wx] == TERRAIN_WATER:
            return
        if self.world.buildings[wy][wx] != BUILDING_NONE:
            return

        # 检查该位置是否有现有任务
        existing = self.task_manager.get_tasks_at(wx, wy)
        if existing:
            return

        # 扣除资源
        self.resource_manager.remove(RESOURCE_WOOD, info[2])
        self.resource_manager.remove(RESOURCE_STONE, info[3])

        # 创建建造任务
        self.task_manager.add_build_task(wx, wy, building_type)

        # 使路径查找缓存失效
        self.pathfinder.invalidate_cache()

    def _handle_farm(self, wx, wy) -> None:
        crop_type = self.ui.selected_crop

        # 必须在农田上
        if not (0 <= wx < WORLD_WIDTH and 0 <= wy < WORLD_HEIGHT):
            return
        if self.world.buildings[wy][wx] != BUILDING_FARM_PLOT:
            return
        if self.world.crops[wy][wx] != CROP_NONE:
            return

        # 检查现有任务
        existing = self.task_manager.get_tasks_at(wx, wy)
        if existing:
            return

        self.task_manager.add_farm_task(wx, wy, crop_type)

    def _handle_hunt(self, wx, wy) -> None:
        # 在该位置查找动物
        for animal in self.animals:
            if animal.alive and animal.x == wx and animal.y == wy:
                # 检查是否已被标记
                if animal not in self.task_manager.hunting_targets:
                    self.task_manager.add_hunt_task(animal)
                break

    def _handle_chop(self, wx, wy) -> None:
        """处理砍树命令 - 在位置创建砍树任务"""
        if not (0 <= wx < WORLD_WIDTH and 0 <= wy < WORLD_HEIGHT):
            return
        if self.world.terrain[wy][wx] != TERRAIN_GRASS:
            return
        if self.world.buildings[wy][wx] != BUILDING_NONE:
            return

        # 在位置生成木材资源(模拟砍树)
        amount = random.randint(5, 12)
        self.world.add_resource_on_ground(wx, wy, RESOURCE_WOOD, amount)

    def _handle_harvest(self, wx, wy) -> None:
        """处理收获命令 - 标记成熟作物进行收获"""
        if not (0 <= wx < WORLD_WIDTH and 0 <= wy < WORLD_HEIGHT):
            return

        crop = self.world.crops[wy][wx]
        if crop == CROP_NONE:
            return

        # 检查是否成熟
        info = CROP_INFO.get(crop)
        if not info:
            return

        growth = self.world.crop_growth[wy][wx]
        if growth >= info[1]:  # 成熟
            existing = self.task_manager.get_tasks_at(wx, wy)
            if not existing:
                self.task_manager.add_harvest_task(wx, wy, crop)

    def _update(self, dt) -> None:
        speed_mult = SPEED_MULTIPLIERS.get(self.ui.game_speed, 1)
        if speed_mult == 0:
            # 仍然更新相机
            keys = pygame.key.get_pressed()
            self.camera.update(keys, dt)
            return

        game_dt = dt * speed_mult
        self.game_time += game_dt * 60  # 游戏时间(以ticks为单位)

        # 更新相机
        keys = pygame.key.get_pressed()
        self.camera.update(keys, dt)

        # 更新作物
        self._update_crops(game_dt)

        # 更新殖民者
        for i, colonist in enumerate(self.colonists):
            if colonist.hp > 0:
                self.colonist_ais[i].update(game_dt, self)

        # 更新动物
        self._update_animals(game_dt)

        # 偶尔自动生成动物
        if random.random() < 0.0005 * speed_mult:
            self._spawn_animal()

    def _update_crops(self, dt) -> None:
        for y in range(WORLD_HEIGHT):
            for x in range(WORLD_WIDTH):
                crop = self.world.crops[y][x]
                if crop != CROP_NONE:
                    self.world.crop_growth[y][x] += dt * 60
                    # 成熟时自动创建收获任务
                    info = CROP_INFO.get(crop)
                    if info and self.world.crop_growth[y][x] >= info[1]:
                        existing = self.task_manager.get_tasks_at(x, y)
                        if not existing:
                            self.task_manager.add_harvest_task(x, y, crop)

    def _update_animals(self, dt) -> None:
        for animal in self.animals:
            if not animal.alive:
                continue

            animal.update(dt, self)

            # 捕猎模式下动物逃离附近的殖民者
            if animal.flee_on_sight:
                for colonist in self.colonists:
                    if colonist.hp > 0:
                        dist = abs(colonist.x - animal.x) + abs(colonist.y - animal.y)
                        if dist < 6:
                            animal.flee_from(colonist.x, colonist.y, self)
                            break

            # 狼攻击附近的殖民者
            if animal.hostile and animal.attack_cooldown <= 0:
                for colonist in self.colonists:
                    if colonist.hp > 0:
                        dist = abs(colonist.x - animal.x) + abs(colonist.y - animal.y)
                        if dist <= 1:
                            damage = random.randint(3, 8)
                            colonist.hp -= damage
                            animal.attack_cooldown = 2.0
                            break

        # 移除死亡的动物(延迟一段时间,保留以收集资源)
        self.animals = [a for a in self.animals if a.alive or (a.x, a.y) in self.world.resources_on_ground]

    def _spawn_animal(self) -> None:
        if len([a for a in self.animals if a.alive]) >= 40:
            return
        for _ in range(10):
            # 在边缘生成
            edge = random.randint(0, 3)
            if edge == 0:
                x, y = random.randint(0, WORLD_WIDTH - 1), 0
            elif edge == 1:
                x, y = random.randint(0, WORLD_WIDTH - 1), WORLD_HEIGHT - 1
            elif edge == 2:
                x, y = 0, random.randint(0, WORLD_HEIGHT - 1)
            else:
                x, y = WORLD_WIDTH - 1, random.randint(0, WORLD_HEIGHT - 1)

            if self.world.is_passable(x, y):
                animal_type = random.choices(
                    [ANIMAL_DEER, ANIMAL_RABBIT, ANIMAL_CHICKEN, ANIMAL_WOLF],
                    weights=[40, 30, 20, 10],
                )[0]
                animal = Animal(x, y, animal_type)
                self.animals.append(animal)
                break

    def _draw(self) -> None:
        self.screen.fill(COLOR_UI_BG)

        # 绘制世界
        self.renderer.draw_world(self.world, self.camera)

        # 绘制建造预览
        if self.ui.mode == "build":
            wx, wy = self.mouse_world_pos
            if 0 <= wx < WORLD_WIDTH and 0 <= wy < WORLD_HEIGHT:
                self.renderer.draw_build_preview(
                    self.camera,
                    wx,
                    wy,
                    self.ui.selected_building,
                )

        # 绘制动物
        for animal in self.animals:
            animal.draw(self.screen, self.camera)

        # 绘制殖民者
        for colonist in self.colonists:
            if colonist.hp > 0:
                colonist.draw(self.screen, self.camera)

        # 绘制选择框
        if self.selecting:
            self.renderer.draw_selection_box(
                self.camera,
                self.select_start,
                self.select_end,
            )

        # 绘制UI(在最上层)
        self.ui.draw(
            self.screen,
            self.resource_manager,
            self.colonists,
            self.animals,
            self.game_time,
            self.world,
        )

        pygame.display.flip()


def main() -> None:
    """Run entry point for the command-line interface.

    Command-line interface for rimworld_lite

    Examples:
    main [options] <arguments>
    """

    game = Game()
    game.run()


if __name__ == "__main__":
    main()
