"""Resources module for rimworld_lite."""

from .constants import RESOURCE_FOOD, RESOURCE_MEAT, RESOURCE_STONE, RESOURCE_WOOD


class ResourceManager:
    def __init__(self) -> None:
        self.resources = {
            RESOURCE_WOOD: 50,
            RESOURCE_STONE: 30,
            RESOURCE_FOOD: 40,
            RESOURCE_MEAT: 0,
        }

    def add(self, resource_type, amount) -> None:
        if resource_type in self.resources:
            self.resources[resource_type] += amount

    def remove(self, resource_type, amount):
        if resource_type in self.resources:
            actual = min(amount, self.resources[resource_type])
            self.resources[resource_type] -= actual
            return actual
        return 0

    def has(self, resource_type, amount):
        if resource_type in self.resources:
            return self.resources[resource_type] >= amount
        return False

    def get(self, resource_type):
        return self.resources.get(resource_type, 0)

    def get_all(self):
        return dict(self.resources)