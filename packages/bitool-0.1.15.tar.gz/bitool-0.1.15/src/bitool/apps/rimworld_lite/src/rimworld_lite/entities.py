"""Entities module for rimworld_lite."""

import math
import random

from .constants import (
    ANIMAL_CHICKEN,
    ANIMAL_DEER,
    ANIMAL_INFO,
    ANIMAL_RABBIT,
    ANIMAL_WOLF,
    COLOR_CHICKEN,
    COLOR_COLONIST,
    COLOR_COLONIST_SELECTED,
    COLOR_DEER,
    COLOR_RABBIT,
    COLOR_WOLF,
    RESOURCE_FOOD,
    STATE_BUILDING,
    STATE_EATING,
    STATE_FARMING,
    STATE_FLEEING,
    STATE_HARVESTING,
    STATE_HUNTING,
    STATE_IDLE,
    STATE_MOVING,
    STATE_SLEEPING,
    STATE_WANDERING,
    TILE_SIZE,
)


class Entity:
    def __init__(self, x, y) -> None:
        self.x = x
        self.y = y
        self.pixel_x = float(x * TILE_SIZE + TILE_SIZE // 2)
        self.pixel_y = float(y * TILE_SIZE + TILE_SIZE // 2)
        self.state = STATE_IDLE
        self.path = []
        self.path_index = 0
        self.speed = 2.0
        self.selected = False
        self.target = None  # (x, y) 目标位置
        self.task = None  # 当前任务对象
        self.hp = 100
        self.max_hp = 100
        self.hunger = 0  # 0-100, 100 = 饥饿
        self.name = ""

    def get_tile_pos(self):
        return int(self.pixel_x // TILE_SIZE), int(self.pixel_y // TILE_SIZE)

    def move_along_path(self, dt) -> bool:
        if not self.path or self.path_index >= len(self.path):
            return True  # 路径完成

        target = self.path[self.path_index]
        target_px = target[0] * TILE_SIZE + TILE_SIZE // 2
        target_py = target[1] * TILE_SIZE + TILE_SIZE // 2

        dx = target_px - self.pixel_x
        dy = target_py - self.pixel_y
        dist = math.sqrt(dx * dx + dy * dy)

        move_speed = self.speed * TILE_SIZE * dt

        if dist <= move_speed:
            self.pixel_x = target_px
            self.pixel_y = target_py
            self.x, self.y = target
            self.path_index += 1
            if self.path_index >= len(self.path):
                self.path = []
                self.path_index = 0
                return True
        else:
            self.pixel_x += (dx / dist) * move_speed
            self.pixel_y += (dy / dist) * move_speed
            self.x = int(self.pixel_x // TILE_SIZE)
            self.y = int(self.pixel_y // TILE_SIZE)

        return False

    def set_path(self, path) -> None:
        self.path = path
        self.path_index = 0
        if path:
            self.state = STATE_MOVING


class Colonist(Entity):
    def __init__(self, x, y, name="殖民者") -> None:
        super().__init__(x, y)
        self.name = name
        self.hp = 100
        self.max_hp = 100
        self.hunger = 0
        self.speed = 2.0
        self.build_skill = random.randint(3, 8)
        self.farm_skill = random.randint(3, 8)
        self.hunt_skill = random.randint(2, 7)
        self.color = COLOR_COLONIST
        self.work_timer = 0
        self.assigned_task = None  # 引用任务队列中的任务

    def update(self, dt, game) -> None:
        # 更新饥饿度
        self.hunger = min(100, self.hunger + 0.02 * dt * 60)

        if self.hunger > 80 and self.state != STATE_EATING:
            # 寻找食物
            food_pos = game.world.find_nearest_resource(
                self.x,
                self.y,
                RESOURCE_FOOD,
                max_range=40,
            )
            if food_pos:
                self.assigned_task = {"type": "eat", "target": food_pos}

        # 平滑更新像素位置
        if self.state == STATE_MOVING:
            done = self.move_along_path(dt)
            if done:
                self.state = STATE_IDLE

    def draw(self, surface, camera) -> None:
        sx, sy = camera.world_to_screen(self.x, self.y)
        zoom = camera.zoom
        size = int(TILE_SIZE * zoom * 0.6)

        # 绘制阴影
        shadow_rect = pygame.Rect(
            sx + size * 0.1,
            sy + size * 0.8,
            size * 0.8,
            size * 0.3,
        )
        shadow_surf = pygame.Surface(
            (int(shadow_rect.width), int(shadow_rect.height)),
            pygame.SRCALPHA,
        )
        shadow_surf.fill((0, 0, 0, 40))
        surface.blit(shadow_surf, (int(shadow_rect.x), int(shadow_rect.y)))

        # 绘制身体
        color = COLOR_COLONIST_SELECTED if self.selected else self.color
        body_rect = pygame.Rect(sx, sy, size, size)
        pygame.draw.rect(surface, color, body_rect, border_radius=int(size * 0.3))

        # 绘制头部
        head_size = int(size * 0.5)
        head_rect = pygame.Rect(
            sx + (size - head_size) // 2,
            sy - head_size // 3,
            head_size,
            head_size,
        )
        skin_color = (220, 185, 150)
        pygame.draw.rect(
            surface,
            skin_color,
            head_rect,
            border_radius=int(head_size * 0.4),
        )

        # 绘制选中指示器
        if self.selected:
            indicator_rect = pygame.Rect(sx - 2, sy - 2, size + 4, size + 4)
            pygame.draw.rect(
                surface,
                (255, 255, 100),
                indicator_rect,
                2,
                border_radius=int(size * 0.3),
            )

        # 绘制生命条
        bar_width = size
        bar_height = 3
        bar_x = sx
        bar_y = sy - 8
        # 背景
        pygame.draw.rect(surface, (60, 60, 60), (bar_x, bar_y, bar_width, bar_height))
        # 生命值
        health_width = int(bar_width * self.hp / self.max_hp)
        health_color = (
            (50, 200, 50)
            if self.hp > 50
            else (200, 200, 50)
            if self.hp > 25
            else (200, 50, 50)
        )
        pygame.draw.rect(
            surface,
            health_color,
            (bar_x, bar_y, health_width, bar_height),
        )

        # 绘制饥饿条
        hunger_y = bar_y + bar_height + 1
        pygame.draw.rect(
            surface,
            (60, 60, 60),
            (bar_x, hunger_y, bar_width, bar_height),
        )
        hunger_width = int(bar_width * self.hunger / 100)
        pygame.draw.rect(
            surface,
            (200, 150, 50),
            (bar_x, hunger_y, hunger_width, bar_height),
        )

        # 绘制名称
        font = pygame.font.SysFont("simhei", max(10, int(12 * zoom)))
        name_surf = font.render(self.name, True, (255, 255, 255))
        surface.blit(name_surf, (sx + size // 2 - name_surf.get_width() // 2, sy - 22))

        # 绘制状态文本
        state_text = {
            STATE_IDLE: "空闲",
            STATE_MOVING: "移动中",
            STATE_BUILDING: "建造中",
            STATE_FARMING: "种植中",
            STATE_HUNTING: "捕猎中",
            STATE_HARVESTING: "收获中",
            STATE_EATING: "进食中",
            STATE_SLEEPING: "睡眠中",
        }.get(self.state, "")
        if state_text:
            state_surf = font.render(state_text, True, (200, 200, 200))
            surface.blit(
                state_surf,
                (sx + size // 2 - state_surf.get_width() // 2, sy + size + 4),
            )


class Animal(Entity):
    def __init__(self, x, y, animal_type=ANIMAL_DEER) -> None:
        super().__init__(x, y)
        self.animal_type = animal_type
        info = ANIMAL_INFO[animal_type]
        self.name = info["name"]
        self.hp = info["hp"]
        self.max_hp = info["hp"]
        self.speed = info["speed"]
        self.meat_amount = info["meat"]
        self.hostile = info["hostile"]
        self.flee_on_sight = info["flee"]
        self.wander_timer = 0
        self.wander_target = None
        self.flee_target = None
        self.attack_target = None
        self.attack_cooldown = 0
        self.alive = True

        # 根据类型设置颜色
        self.color = {
            ANIMAL_DEER: COLOR_DEER,
            ANIMAL_RABBIT: COLOR_RABBIT,
            ANIMAL_WOLF: COLOR_WOLF,
            ANIMAL_CHICKEN: COLOR_CHICKEN,
        }.get(animal_type, (150, 150, 150))

    def update(self, dt, game) -> None:
        if not self.alive:
            return

        self.attack_cooldown = max(0, self.attack_cooldown - dt)

        if self.state == STATE_FLEEING:
            if self.flee_target:
                if self.path and self.path_index < len(self.path):
                    done = self.move_along_path(dt)
                    if done:
                        self.state = STATE_WANDERING
                        self.flee_target = None
                else:
                    self.state = STATE_WANDERING
            else:
                self.state = STATE_WANDERING

        elif self.state == STATE_WANDERING:
            self.wander_timer -= dt
            if self.wander_timer <= 0:
                self.wander_timer = random.uniform(2, 6)
                # 选择一个附近的随机瓦片
                dx = random.randint(-5, 5)
                dy = random.randint(-5, 5)
                nx, ny = self.x + dx, self.y + dy
                if game.world.is_passable(nx, ny):
                    self.wander_target = (nx, ny)
                    path = game.pathfinder.find_path((self.x, self.y), (nx, ny))
                    if path:
                        self.set_path(path)

            if self.path and self.path_index < len(self.path):
                self.move_along_path(dt)
            else:
                self.state = STATE_WANDERING

        elif self.state == STATE_MOVING:
            done = self.move_along_path(dt)
            if done:
                self.state = STATE_WANDERING

    def flee_from(self, fx, fy, game) -> None:
        """从位置 (fx, fy) 逃离"""
        dx = self.x - fx
        dy = self.y - fy
        dist = math.sqrt(dx * dx + dy * dy)
        if dist == 0:
            dx, dy = 1, 0
        else:
            dx, dy = dx / dist, dy / dist

        flee_dist = 10
        tx = int(self.x + dx * flee_dist)
        ty = int(self.y + dy * flee_dist)
        tx = max(0, min(game.world.width - 1, tx))
        ty = max(0, min(game.world.height - 1, ty))

        path = game.pathfinder.find_path((self.x, self.y), (tx, ty))
        if path:
            self.set_path(path)
            self.state = STATE_FLEEING
            self.flee_target = (tx, ty)

    def draw(self, surface, camera) -> None:
        if not self.alive:
            return

        sx, sy = camera.world_to_screen(self.x, self.y)
        zoom = camera.zoom
        size = int(TILE_SIZE * zoom * 0.5)

        # 绘制阴影
        shadow_surf = pygame.Surface(
            (int(size * 0.8), int(size * 0.25)),
            pygame.SRCALPHA,
        )
        shadow_surf.fill((0, 0, 0, 30))
        surface.blit(shadow_surf, (int(sx + size * 0.1), int(sy + size * 0.7)))

        # 根据动物类型绘制身体
        if self.animal_type == ANIMAL_DEER:
            # 鹿: 椭圆形身体 + 腿
            pygame.draw.ellipse(surface, self.color, (sx, sy, size, int(size * 0.7)))
            # 头
            head_size = int(size * 0.35)
            pygame.draw.circle(
                surface,
                self.color,
                (sx + size, sy + int(size * 0.2)),
                head_size,
            )
            # 鹿角
            pygame.draw.line(
                surface,
                (100, 70, 40),
                (sx + size, sy + int(size * 0.1)),
                (sx + size + 4, sy - 4),
                2,
            )
            pygame.draw.line(
                surface,
                (100, 70, 40),
                (sx + size + 2, sy - 2),
                (sx + size + 8, sy - 2),
                1,
            )

        elif self.animal_type == ANIMAL_RABBIT:
            # 兔子: 小圆形身体
            pygame.draw.ellipse(
                surface,
                self.color,
                (sx + 2, sy + 2, int(size * 0.8), int(size * 0.6)),
            )
            # 耳朵
            pygame.draw.ellipse(
                surface,
                self.color,
                (sx + int(size * 0.5), sy - 4, 3, 8),
            )
            pygame.draw.ellipse(
                surface,
                self.color,
                (sx + int(size * 0.7), sy - 4, 3, 8),
            )

        elif self.animal_type == ANIMAL_WOLF:
            # 狼: 棱角形身体
            points = [
                (sx, sy + int(size * 0.5)),
                (sx + size, sy + int(size * 0.3)),
                (sx + size + 4, sy),
                (sx + size, sy - int(size * 0.1)),
                (sx + int(size * 0.3), sy),
            ]
            pygame.draw.polygon(surface, self.color, points)
            # 眼睛
            pygame.draw.circle(
                surface,
                (255, 50, 50),
                (sx + int(size * 0.8), sy - 1),
                2,
            )

        elif self.animal_type == ANIMAL_CHICKEN:
            # 鸡: 小圆形身体
            pygame.draw.ellipse(
                surface,
                self.color,
                (sx, sy, int(size * 0.7), int(size * 0.6)),
            )
            # 头
            pygame.draw.circle(
                surface,
                self.color,
                (sx + int(size * 0.6), sy - 2),
                int(size * 0.2),
            )
            # 喙
            pygame.draw.polygon(
                surface,
                (255, 180, 50),
                [
                    (sx + int(size * 0.75), sy - 2),
                    (sx + int(size * 0.9), sy),
                    (sx + int(size * 0.75), sy + 1),
                ],
            )

        # 生命条(仅在受伤时显示)
        if self.hp < self.max_hp:
            bar_width = size
            bar_height = 2
            bar_x = sx
            bar_y = sy - 6
            pygame.draw.rect(
                surface,
                (60, 60, 60),
                (bar_x, bar_y, bar_width, bar_height),
            )
            health_width = int(bar_width * self.hp / self.max_hp)
            pygame.draw.rect(
                surface,
                (200, 50, 50),
                (bar_x, bar_y, health_width, bar_height),
            )

        # 名称
        font = pygame.font.SysFont("simhei", max(8, int(10 * zoom)))
        name_surf = font.render(self.name, True, (200, 200, 200))
        surface.blit(
            name_surf,
            (sx + size // 2 - name_surf.get_width() // 2, sy + size + 2),
        )


# 需要导入pygame用于绘制
import pygame  # noqa: E402