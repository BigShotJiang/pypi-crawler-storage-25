# RimMod - RimWorld Mod Manager

A RimWorld mod manager written in Python using PySide6.

## Features

- **Load Mods**: Automatically discovers and loads RimWorld mods from standard locations
- **Steam Integration**: Automatically finds RimWorld mods installed via Steam
- **Automatic Sorting**: Sorts mods based on dependencies and load order
- **Import/Export**: Import and export mod lists in XML format
- **Save Changes**: Directly applies mod order changes to RimWorld's config
- **Drag and Drop**: Reorder mods with drag and drop
- **Theme Support**: Multiple UI themes

## Installation

```bash
# Install using pip
pip install -e ".[app]"
```

## Usage

```bash
# Launch the UI
rimmodw
```

## Default Locations

RimMod will try to find mods from:

- **Windows**: `%USERPROFILE%/AppData/LocalLow/Ludeon Studios/RimWorld by Ludeon Studios/Mods`
- **macOS**: `~/Library/Application Support/Ludeon Studios/RimWorld/Mods`
- **Linux**: `~/.config/unity3d/Ludeon Studios/RimWorld/Mods`

And will also check Steam for RimWorld installations.

## Security

RimMod uses secure XML parsing (via `defusedxml`) to avoid XXE attacks.
