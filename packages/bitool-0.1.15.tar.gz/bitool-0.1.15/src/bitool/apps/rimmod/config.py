"""RimWorld Mod 管理器配置模块。"""

from __future__ import annotations

import platform
import winreg
from pathlib import Path
from typing import ClassVar

from bitool.core import JsonConfig

__all__ = ["conf"]

_ROOT_DIR = Path(__file__).parent


class RimmodConfig(JsonConfig):
    """RimWorld Mod 管理器配置类。"""

    _ASSETS_DIR: ClassVar[Path] = _ROOT_DIR / "assets"

    APP_TITLE: str = "RimMod - RimWorld Mod Manager"
    VERSION: str = "0.1.1"

    DEFAULT_THEME: str = "aqua"
    WINDOW_SIZE: list[int] = [900, 700]
    WINDOW_POS: list[int] = [200, 100]

    MOD_FOLDER_PATH: str = ""

    CURRENT_MOD_LIST: list[str] = []
    RECENT_MOD_LISTS: list[str] = []
    MAX_RECENT_LISTS: int = 10

    AUTO_SORT_ENABLED: bool = True
    SORT_METHOD: str = "load_order"
    SHOW_DISABLED_MODS: bool = True

    @staticmethod
    def find_steam_rimworld_mods() -> Path | None:
        """尝试通过 Steam 查找 RimWorld 模组目录。

        Returns:
            RimWorld Mods 目录，或者 None。
        """
        system = platform.system()
        if system == "Windows":
            return RimmodConfig._find_steam_rimworld_windows()
        elif system == "Darwin":
            return RimmodConfig._find_steam_rimworld_macos()
        else:
            return RimmodConfig._find_steam_rimworld_linux()

    @staticmethod
    def _find_steam_rimworld_windows() -> Path | None:
        """Windows 系统：通过 Steam 注册表查找 RimWorld 路径。

        Returns:
            RimWorld Mods 目录，或者 None。
        """
        possible_paths: list[Path] = []

        steam_path = None
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam") as key:
                steam_path = Path(winreg.QueryValueEx(key, "SteamPath")[0])
                if steam_path:
                    workshop_path = steam_path / "steamapps" / "workshop" / "content" / "294100"
                    possible_paths.append(workshop_path)
                    possible_paths.append(steam_path / "steamapps" / "common" / "RimWorld" / "Mods")
        except (FileNotFoundError, OSError):
            pass

        library_paths = []
        if steam_path:
            library_folders = steam_path / "steamapps" / "libraryfolders.vdf"
            if library_folders.exists():
                library_paths.extend(RimmodConfig._parse_library_folders_for_all(library_folders))
        else:
            try:
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam\Apps\294100") as key:
                    rimworld_installed = winreg.QueryValueEx(key, "Installed")[0]
                    if rimworld_installed:
                        try:
                            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam") as key:
                                steam_path = Path(winreg.QueryValueEx(key, "SteamPath")[0])
                                if steam_path:
                                    library_folders = steam_path / "steamapps" / "libraryfolders.vdf"
                                    if library_folders.exists():
                                        library_paths.extend(
                                            RimmodConfig._parse_library_folders_for_all(library_folders),
                                        )
                        except (FileNotFoundError, OSError):
                            pass
            except (FileNotFoundError, OSError):
                pass

        for lib_path in library_paths:
            workshop_path = lib_path / "steamapps" / "workshop" / "content" / "294100"
            possible_paths.append(workshop_path)
            possible_paths.append(lib_path / "steamapps" / "common" / "RimWorld" / "Mods")

        default_steam_paths = [
            Path("C:/Program Files (x86)/Steam/steamapps/workshop/content/294100"),
            Path("C:/Program Files/Steam/steamapps/workshop/content/294100"),
            Path("D:/Steam/steamapps/workshop/content/294100"),
            Path("E:/Steam/steamapps/workshop/content/294100"),
            Path.home() / ".steam/steam/SteamApps/workshop/content/294100",
            Path("C:/Program Files (x86)/Steam/steamapps/common/RimWorld/Mods"),
            Path("C:/Program Files/Steam/steamapps/common/RimWorld/Mods"),
            Path("D:/Steam/steamapps/common/RimWorld/Mods"),
            Path("E:/Steam/steamapps/common/RimWorld/Mods"),
            Path.home() / ".steam/steam/SteamApps/common/RimWorld/Mods",
        ]
        possible_paths.extend(default_steam_paths)

        for path in possible_paths:
            if path.exists():
                return path
        return None

    @staticmethod
    def _parse_library_folders(library_folders: Path) -> list[Path]:
        """解析 libraryfolders.vdf 查找 RimWorld Mods 目录。

        Args:
            library_folders: libraryfolders.vdf 文件路径。

        Returns:
            RimWorld Mods 目录列表。
        """
        if not library_folders.exists():
            return []

        found = []
        try:
            content = library_folders.read_text(encoding="utf-8", errors="ignore")
            import re

            for match in re.finditer(r'"path"\s*"([^"]+)"', content, re.IGNORECASE):
                folder = Path(match.group(1).replace(r"\\", "\\"))
                rim_mods = folder / "steamapps/common/RimWorld/Mods"
                found.append(rim_mods)
        except (OSError, UnicodeDecodeError):
            pass
        return found

    @staticmethod
    def _parse_library_folders_for_all(library_folders: Path) -> list[Path]:
        """解析 libraryfolders.vdf 查找所有 Steam 库目录。

        Args:
            library_folders: libraryfolders.vdf 文件路径。

        Returns:
            Steam 库目录列表。
        """
        if not library_folders.exists():
            return []

        found = []
        try:
            content = library_folders.read_text(encoding="utf-8", errors="ignore")
            import re

            for match in re.finditer(r'"path"\s*"([^"]+)"', content, re.IGNORECASE):
                folder = Path(match.group(1).replace(r"\\", "\\"))
                found.append(folder)
        except (OSError, UnicodeDecodeError):
            pass
        return found

    @staticmethod
    def _find_steam_rimworld_macos() -> Path | None:
        """macOS 系统：查找 RimWorld 模组目录。

        Returns:
            RimWorld Mods 目录，或者 None。
        """
        possible_paths = [
            Path.home() / "Library/Application Support/Steam/SteamApps/workshop/content/294100",
            Path.home() / "Library/Application Support/Steam/SteamApps/common/RimWorld/Mods",
            Path("/Applications/Steam.app/Contents/MacOS/SteamApps/workshop/content/294100"),
            Path("/Applications/Steam.app/Contents/MacOS/SteamApps/common/RimWorld/Mods"),
        ]

        for path in possible_paths:
            if path.exists():
                return path
        return None

    @staticmethod
    def _find_steam_rimworld_linux() -> Path | None:
        """Linux 系统：查找 RimWorld 模组目录。

        Returns:
            RimWorld Mods 目录，或者 None。
        """
        possible_paths = [
            Path.home() / ".steam/steam/steamapps/workshop/content/294100",
            Path.home() / ".steam/steam/SteamApps/workshop/content/294100",
            Path.home() / ".local/share/Steam/steamapps/workshop/content/294100",
            Path.home() / ".steam/steam/steamapps/common/RimWorld/Mods",
            Path.home() / ".steam/steam/SteamApps/common/RimWorld/Mods",
            Path.home() / ".local/share/Steam/steamapps/common/RimWorld/Mods",
        ]

        for path in possible_paths:
            if path.exists():
                return path
        return None

    @staticmethod
    def get_default_mod_path() -> Path:
        """根据操作系统获取默认的 RimWorld 模组文件夹路径。

        优先查找 Steam 的 RimWorld 模组，如果找不到，使用传统目录。

        Returns:
            默认的 RimWorld 模组目录。
        """
        steam_mods = RimmodConfig.find_steam_rimworld_mods()
        if steam_mods:
            return steam_mods

        system = platform.system()
        if system == "Windows":
            base = Path.home() / "AppData" / "Local" / "Low" / "Ludeon Studios" / "RimWorld by Ludeon Studios"
        elif system == "Darwin":
            base = Path.home() / "Library" / "Application Support" / "Ludeon Studios" / "RimWorld"
        else:
            base = Path.home() / ".config" / "unity3d" / "Ludeon Studios" / "RimWorld"
        return base / "Mods"

    @staticmethod
    def get_all_mod_paths() -> list[Path]:
        """获取所有可能的 RimWorld 模组文件夹路径。

        Returns:
            所有可能的 RimWorld 模组目录列表。
        """
        all_paths = []
        system = platform.system()

        if system == "Windows":
            paths = RimmodConfig._find_all_steam_rimworld_windows()
            all_paths.extend(paths)
        elif system == "Darwin":
            paths = RimmodConfig._find_all_steam_rimworld_macos()
            all_paths.extend(paths)
        else:
            paths = RimmodConfig._find_all_steam_rimworld_linux()
            all_paths.extend(paths)

        if system == "Windows":
            base = Path.home() / "AppData" / "Local" / "Low" / "Ludeon Studios" / "RimWorld by Ludeon Studios"
        elif system == "Darwin":
            base = Path.home() / "Library" / "Application Support" / "Ludeon Studios" / "RimWorld"
        else:
            base = Path.home() / ".config" / "unity3d" / "Ludeon Studios" / "RimWorld"
        all_paths.append(base / "Mods")

        unique_paths = []
        seen = set()
        for path in all_paths:
            path_str = str(path.resolve())
            if path_str not in seen and path.exists():
                seen.add(path_str)
                unique_paths.append(path)
        return unique_paths

    @staticmethod
    def _find_all_steam_rimworld_windows() -> list[Path]:
        """Windows 系统：查找所有可能的 RimWorld 模组目录。

        Returns:
            RimWorld Mods 目录列表。
        """
        possible_paths: list[Path] = []

        steam_path = None
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam") as key:
                steam_path = Path(winreg.QueryValueEx(key, "SteamPath")[0])
                if steam_path:
                    workshop_path = steam_path / "steamapps" / "workshop" / "content" / "294100"
                    possible_paths.append(workshop_path)
                    possible_paths.append(steam_path / "steamapps" / "common" / "RimWorld" / "Mods")
        except (FileNotFoundError, OSError):
            pass

        library_paths = []
        if steam_path:
            library_folders = steam_path / "steamapps" / "libraryfolders.vdf"
            if library_folders.exists():
                library_paths.extend(RimmodConfig._parse_library_folders_for_all(library_folders))
        else:
            try:
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam\Apps\294100") as key:
                    rimworld_installed = winreg.QueryValueEx(key, "Installed")[0]
                    if rimworld_installed:
                        try:
                            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam") as key:
                                steam_path = Path(winreg.QueryValueEx(key, "SteamPath")[0])
                                if steam_path:
                                    library_folders = steam_path / "steamapps" / "libraryfolders.vdf"
                                    if library_folders.exists():
                                        library_paths.extend(
                                            RimmodConfig._parse_library_folders_for_all(library_folders),
                                        )
                        except (FileNotFoundError, OSError):
                            pass
            except (FileNotFoundError, OSError):
                pass

        for lib_path in library_paths:
            workshop_path = lib_path / "steamapps" / "workshop" / "content" / "294100"
            possible_paths.append(workshop_path)
            possible_paths.append(lib_path / "steamapps" / "common" / "RimWorld" / "Mods")

        default_steam_paths = [
            Path("C:/Program Files (x86)/Steam/steamapps/workshop/content/294100"),
            Path("C:/Program Files/Steam/steamapps/workshop/content/294100"),
            Path("D:/Steam/steamapps/workshop/content/294100"),
            Path("E:/Steam/steamapps/workshop/content/294100"),
            Path.home() / ".steam/steam/SteamApps/workshop/content/294100",
            Path("C:/Program Files (x86)/Steam/steamapps/common/RimWorld/Mods"),
            Path("C:/Program Files/Steam/steamapps/common/RimWorld/Mods"),
            Path("D:/Steam/steamapps/common/RimWorld/Mods"),
            Path("E:/Steam/steamapps/common/RimWorld/Mods"),
            Path.home() / ".steam/steam/SteamApps/common/RimWorld/Mods",
        ]
        possible_paths.extend(default_steam_paths)

        return possible_paths

    @staticmethod
    def _find_all_steam_rimworld_macos() -> list[Path]:
        """macOS 系统：查找所有可能的 RimWorld 模组目录。

        Returns:
            RimWorld Mods 目录列表。
        """
        possible_paths = [
            Path.home() / "Library/Application Support/Steam/SteamApps/workshop/content/294100",
            Path.home() / "Library/Application Support/Steam/SteamApps/common/RimWorld/Mods",
            Path("/Applications/Steam.app/Contents/MacOS/SteamApps/workshop/content/294100"),
            Path("/Applications/Steam.app/Contents/MacOS/SteamApps/common/RimWorld/Mods"),
        ]
        return possible_paths

    @staticmethod
    def _find_all_steam_rimworld_linux() -> list[Path]:
        """Linux 系统：查找所有可能的 RimWorld 模组目录。

        Returns:
            RimWorld Mods 目录列表。
        """
        possible_paths = [
            Path.home() / ".steam/steam/steamapps/workshop/content/294100",
            Path.home() / ".steam/steam/SteamApps/workshop/content/294100",
            Path.home() / ".local/share/Steam/steamapps/workshop/content/294100",
            Path.home() / ".steam/steam/steamapps/common/RimWorld/Mods",
            Path.home() / ".steam/steam/SteamApps/common/RimWorld/Mods",
            Path.home() / ".local/share/Steam/steamapps/common/RimWorld/Mods",
        ]
        return possible_paths

    @staticmethod
    def get_mod_list_path() -> Path:
        """根据操作系统获取默认的 Mod 列表文件路径。

        Returns:
            默认 RimWorld 模组列表文件路径。
        """
        system = platform.system()
        if system == "Windows":
            base = Path.home() / "AppData" / "Local" / "Low" / "Ludeon Studios" / "RimWorld by Ludeon Studios"
        elif system == "Darwin":
            base = Path.home() / "Library" / "Application Support" / "Ludeon Studios" / "RimWorld"
        else:
            base = Path.home() / ".config" / "unity3d" / "Ludeon Studios" / "RimWorld"
        return base / "ModList" / "Mods.xml"


conf = RimmodConfig()
