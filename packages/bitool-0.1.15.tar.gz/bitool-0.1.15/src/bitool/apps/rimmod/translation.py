#!/usr/bin/env python3
"""
RimMod - 环世界Mod管理器的翻译系统。

提供国际化支持，包含英文和中文翻译。
"""

from __future__ import annotations

from enum import Enum


class Language(Enum):
    """支持的语言。"""

    ENGLISH = "en"
    CHINESE = "zh"


class Translator:
    """RimMod GUI 翻译管理器。"""

    def __init__(self, default_language: Language = Language.CHINESE) -> None:
        """初始化翻译器，设置默认语言。

        Args:
            default_language: 默认使用的语言
        """
        self.current_language = default_language
        self.translations = self._load_translations()

    def _load_translations(self) -> dict[str, dict[str, str]]:
        """加载所有翻译字符串。"""
        return {  # type: ignore[return-value]
            "window_title": {
                Language.ENGLISH.value: "RimMod - RimWorld Mod Manager",
                Language.CHINESE.value: "RimMod - 环世界Mod管理器",
            },
            "unapplied_mods": {
                Language.ENGLISH.value: "Unapplied Mods",
                Language.CHINESE.value: "未激活Mods",
            },
            "applied_mods": {
                Language.ENGLISH.value: "Applied Mods",
                Language.CHINESE.value: "已激活Mods",
            },
            "load_mods": {
                Language.ENGLISH.value: "📁 Load Mods",
                Language.CHINESE.value: "📁 加载Mods",
            },
            "import_list": {
                Language.ENGLISH.value: "📥 Import List",
                Language.CHINESE.value: "📥 导入列表",
            },
            "export_list": {
                Language.ENGLISH.value: "📤 Export List",
                Language.CHINESE.value: "📤 导出列表",
            },
            "undo": {
                Language.ENGLISH.value: "↩️ Undo",
                Language.CHINESE.value: "↩️ 撤销",
            },
            "redo": {
                Language.ENGLISH.value: "↪️ Redo",
                Language.CHINESE.value: "↪️ 重做",
            },
            "save_preset": {
                Language.ENGLISH.value: "💾 Save Preset",
                Language.CHINESE.value: "💾 保存预设",
            },
            "load_preset": {
                Language.ENGLISH.value: "📂 Load Preset",
                Language.CHINESE.value: "📂 加载预设",
            },
            "diagnose": {
                Language.ENGLISH.value: "🔍 Diagnose",
                Language.CHINESE.value: "🔍 诊断",
            },
            "apply_changes": {
                Language.ENGLISH.value: "✅ Apply Changes",
                Language.CHINESE.value: "✅ 应用更改",
            },
            "save": {
                Language.ENGLISH.value: "💾 Save",
                Language.CHINESE.value: "💾 保存",
            },
            "theme": {
                Language.ENGLISH.value: "Theme:",
                Language.CHINESE.value: "主题:",
            },
            "language": {
                Language.ENGLISH.value: "Language:",
                Language.CHINESE.value: "语言:",
            },
            "search": {
                Language.ENGLISH.value: "Search...",
                Language.CHINESE.value: "搜索...",
            },
            "support": {
                Language.ENGLISH.value: "Support",
                Language.CHINESE.value: "支持",
            },
            "ready_status": {
                Language.ENGLISH.value: "Ready",
                Language.CHINESE.value: "就绪",
            },
            "mod_info": {
                Language.ENGLISH.value: "Mod Info",
                Language.CHINESE.value: "Mod信息",
            },
            "name": {
                Language.ENGLISH.value: "Name",
                Language.CHINESE.value: "名称",
            },
            "package_id": {
                Language.ENGLISH.value: "Package ID",
                Language.CHINESE.value: "包ID",
            },
            "author": {
                Language.ENGLISH.value: "Author",
                Language.CHINESE.value: "作者",
            },
            "version": {
                Language.ENGLISH.value: "Version",
                Language.CHINESE.value: "版本",
            },
            "description": {
                Language.ENGLISH.value: "Description",
                Language.CHINESE.value: "描述",
            },
            "path": {
                Language.ENGLISH.value: "Path",
                Language.CHINESE.value: "路径",
            },
            "dependencies": {
                Language.ENGLISH.value: "Dependencies",
                Language.CHINESE.value: "依赖",
            },
            "no_dependencies": {
                Language.ENGLISH.value: "No dependencies",
                Language.CHINESE.value: "无依赖",
            },
            "loading_mods": {
                Language.ENGLISH.value: "Loading Mods...",
                Language.CHINESE.value: "正在加载Mod...",
            },
            "cancelled": {
                Language.ENGLISH.value: "Cancelled",
                Language.CHINESE.value: "已取消",
            },
            "mod_count": {
                Language.ENGLISH.value: "{unapplied} Unapplied, {applied} Applied",
                Language.CHINESE.value: "{unapplied} 未激活, {applied} 已激活",
            },
            "select_folder": {
                Language.ENGLISH.value: "Select Mod Folder",
                Language.CHINESE.value: "选择Mod文件夹",
            },
            "import_success": {
                Language.ENGLISH.value: "Successfully imported {count} mods",
                Language.CHINESE.value: "成功导入 {count} 个Mod",
            },
            "export_success": {
                Language.ENGLISH.value: "Successfully exported mod list",
                Language.CHINESE.value: "成功导出Mod列表",
            },
            "save_success": {
                Language.ENGLISH.value: "Successfully saved mod list",
                Language.CHINESE.value: "成功保存Mod列表",
            },
            "no_mod_selected": {
                Language.ENGLISH.value: "No mod selected",
                Language.CHINESE.value: "未选择Mod",
            },
            "open_url": {
                Language.ENGLISH.value: "Open URL",
                Language.CHINESE.value: "打开链接",
            },
            "open_steam": {
                Language.ENGLISH.value: "Open Steam Workshop",
                Language.CHINESE.value: "打开Steam创意工坊",
            },
            "view_dependencies": {
                Language.ENGLISH.value: "View Dependencies",
                Language.CHINESE.value: "查看依赖",
            },
            "diagnosis_title": {
                Language.ENGLISH.value: "Diagnosis Results",
                Language.CHINESE.value: "诊断结果",
            },
            "diagnosis_issues": {
                Language.ENGLISH.value: "Issues Found ({count}):",
                Language.CHINESE.value: "发现问题 ({count}):",
            },
            "diagnosis_warnings": {
                Language.ENGLISH.value: "Warnings ({count}):",
                Language.CHINESE.value: "警告 ({count}):",
            },
            "diagnosis_ok": {
                Language.ENGLISH.value: "No issues found!",
                Language.CHINESE.value: "未发现问题!",
            },
            "dependency_missing": {
                Language.ENGLISH.value: "Missing dependency '{id}'",
                Language.CHINESE.value: "缺少依赖 '{id}'",
            },
            "dependency_inactive": {
                Language.ENGLISH.value: "Dependency '{id}' is not activated",
                Language.CHINESE.value: "依赖 '{id}' 未被激活",
            },
            "dependency_info_title": {
                Language.ENGLISH.value: "Dependency Information",
                Language.CHINESE.value: "依赖信息",
            },
            "dependency_no_deps": {
                Language.ENGLISH.value: "Mod '{name}' has no declared dependencies.",
                Language.CHINESE.value: "Mod '{name}' 没有声明任何依赖。",
            },
            "dependency_loaded": {
                Language.ENGLISH.value: "Activated dependencies ({count}):",
                Language.CHINESE.value: "已激活的依赖 ({count}):",
            },
            "dependency_missing_list": {
                Language.ENGLISH.value: "Missing dependencies ({count}):",
                Language.CHINESE.value: "未找到的依赖 ({count}):",
            },
            "preset_save_title": {
                Language.ENGLISH.value: "Save Preset",
                Language.CHINESE.value: "保存预设",
            },
            "preset_load_title": {
                Language.ENGLISH.value: "Load Preset",
                Language.CHINESE.value: "加载预设",
            },
            "preset_filter": {
                Language.ENGLISH.value: "Preset Files (*.json)",
                Language.CHINESE.value: "预设文件 (*.json)",
            },
            "preset_saved": {
                Language.ENGLISH.value: "Preset saved successfully",
                Language.CHINESE.value: "预设保存成功",
            },
            "preset_loaded": {
                Language.ENGLISH.value: "Preset loaded: {name}",
                Language.CHINESE.value: "已加载预设: {name}",
            },
            "confirm_title": {
                Language.ENGLISH.value: "Confirm",
                Language.CHINESE.value: "确认",
            },
            "unsaved_changes": {
                Language.ENGLISH.value: "You have unsaved changes. Do you want to save them?",
                Language.CHINESE.value: "您有未保存的更改。是否保存？",
            },
            "confirm_apply": {
                Language.ENGLISH.value: "Apply Changes",
                Language.CHINESE.value: "应用更改",
            },
            "confirm_apply_message": {
                Language.ENGLISH.value: "Are you sure you want to apply these changes?",
                Language.CHINESE.value: "确定要应用这些更改吗？",
            },
            "error_title": {
                Language.ENGLISH.value: "Error",
                Language.CHINESE.value: "错误",
            },
            "error_load_mods": {
                Language.ENGLISH.value: "Failed to load mods: {error}",
                Language.CHINESE.value: "加载Mod失败: {error}",
            },
            "add_selected": {
                Language.ENGLISH.value: "Add Selected",
                Language.CHINESE.value: "添加选中",
            },
            "remove_selected": {
                Language.ENGLISH.value: "Remove Selected",
                Language.CHINESE.value: "移除选中",
            },
            "add_all": {
                Language.ENGLISH.value: "Add All",
                Language.CHINESE.value: "添加全部",
            },
            "remove_all": {
                Language.ENGLISH.value: "Remove All",
                Language.CHINESE.value: "移除全部",
            },
            "sorting": {
                Language.ENGLISH.value: "Sorting mods...",
                Language.CHINESE.value: "正在排序Mod...",
            },
            "sort_complete": {
                Language.ENGLISH.value: "Sorting complete",
                Language.CHINESE.value: "排序完成",
            },
            "load_order": {
                Language.ENGLISH.value: "Load Order",
                Language.CHINESE.value: "加载顺序",
            },
        }

    def set_language(self, language: Language) -> None:
        """更改当前语言。

        Args:
            language: 要切换到的语言
        """
        self.current_language = language

    def tr(self, key: str, **kwargs: object) -> str:
        """将字符串键翻译为当前语言。

        Args:
            key: 翻译键
            **kwargs: 额外的格式化参数

        Returns
        -------
            翻译后的字符串
        """
        if key not in self.translations:
            return key

        translation_dict = self.translations[key]
        current_lang = self.current_language.value

        if current_lang in translation_dict:
            result = translation_dict[current_lang]
            if kwargs:
                result = result.format(**kwargs)
            return result
        if Language.ENGLISH.value in translation_dict:
            result = translation_dict[Language.ENGLISH.value]
            if kwargs:
                result = result.format(**kwargs)
            return result
        return key


translator = Translator()
