"""RimWorld Mod 管理器图形用户界面。"""

from __future__ import annotations

from bitool.gui import setup_highdpi_scaling
from bitool.gui.compat import QApplication

from .widgets.rimmod import RimMod


def main() -> int:
    """GUI 应用程序入口点。"""
    app = QApplication([])

    setup_highdpi_scaling()

    window = RimMod()
    window.setWindowTitle("RimMod - 环世界Mod管理器")
    window.show()

    return app.exec_()


if __name__ == "__main__":
    main()
