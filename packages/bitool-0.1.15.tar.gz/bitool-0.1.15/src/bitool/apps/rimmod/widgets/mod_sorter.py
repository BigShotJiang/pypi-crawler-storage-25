"""基于依赖关系自动排序 Mod 的模块。"""

from __future__ import annotations

from collections import defaultdict, deque
from pathlib import Path

from bitool.core import logger


class ModSorter:
    """基于 RimWorld 加载顺序依赖关系对 Mod 进行排序。"""

    def __init__(self, mods: list[dict]) -> None:
        """初始化 Mod 排序器。

        Args:
            mods: 包含 Mod 信息的字典列表
        """
        self.mods = mods
        self.mod_dict = {mod.get("id", ""): mod for mod in mods}
        self.dependencies: dict[str, set[str]] = defaultdict(set)
        self.load_order: list[str] = []

    def sort(self) -> list[dict]:
        """基于依赖关系对 Mod 进行排序。

        Returns:
            排序后的 Mod 字典列表
        """
        self._parse_all_dependencies()
        sorted_ids = self._topological_sort()
        return self._reorder_mods(sorted_ids)

    def _parse_all_dependencies(self) -> None:
        """从所有 Mod 的 About.xml 文件解析依赖关系。"""
        self.deps_info: dict[str, dict] = {}

        for mod in self.mods:
            mod_id = mod.get("id", "")
            mod_path = Path(mod.get("path", ""))

            deps_info = self._get_mod_dependencies(mod_path)
            self.deps_info[mod_id] = deps_info

            direct_deps = deps_info["modDependencies"] | deps_info["loadAfter"]
            self.dependencies[mod_id] = direct_deps

            for dep_id in direct_deps:
                if dep_id not in self.mod_dict:
                    logger.info(f"Dependency '{dep_id}' for '{mod_id}' not found in loaded mods")

        for mod_id, deps_info in self.deps_info.items():
            for target_mod in deps_info["loadBefore"]:
                if target_mod in self.mod_dict:
                    self.dependencies[target_mod].add(mod_id)

    def _get_mod_dependencies(self, mod_path: Path) -> dict:
        """从 Mod 的 About.xml 中提取依赖关系，使用安全解析。

        Args:
            mod_path: Mod 文件夹路径

        Returns:
            包含以下键的字典：
            - 'modDependencies': 必须在该 Mod 之前加载的 Mod
            - 'loadAfter': 必须在该 Mod 之前加载的 Mod
            - 'loadBefore': 必须在该 Mod 之后加载的 Mod
        """
        about_file = mod_path / "About" / "About.xml"
        if not about_file.exists():
            about_file = mod_path / "About.xml"

        if not about_file.exists():
            return {"modDependencies": set(), "loadAfter": set(), "loadBefore": set()}

        result = {
            "modDependencies": set(),
            "loadAfter": set(),
            "loadBefore": set(),
        }

        root = self._parse_about_safe(about_file)
        if root is None:
            return result

        def extract_package_id(li_elem):
            """从 li 元素中提取包 ID。"""
            pkg_elem = li_elem.find("packageId")
            if pkg_elem is not None and pkg_elem.text:
                return pkg_elem.text.strip()
            if li_elem.text and li_elem.text.strip():
                return li_elem.text.strip()
            return None

        for li in root.findall(".//modDependencies/li"):
            pkg_id = extract_package_id(li)
            if pkg_id:
                result["modDependencies"].add(pkg_id)

        for version_elem in root.findall(".//modDependenciesByVersion/*"):
            for li in version_elem.findall(".//li"):
                pkg_id = extract_package_id(li)
                if pkg_id:
                    result["modDependencies"].add(pkg_id)

        for li in root.findall(".//loadAfter/li"):
            pkg_id = extract_package_id(li)
            if pkg_id:
                result["loadAfter"].add(pkg_id)

        for version_elem in root.findall(".//loadAfterByVersion/*"):
            for li in version_elem.findall(".//li"):
                pkg_id = extract_package_id(li)
                if pkg_id:
                    result["loadAfter"].add(pkg_id)

        for li in root.findall(".//loadBefore/li"):
            pkg_id = extract_package_id(li)
            if pkg_id:
                result["loadBefore"].add(pkg_id)

        for version_elem in root.findall(".//loadBeforeByVersion/*"):
            for li in version_elem.findall(".//li"):
                pkg_id = extract_package_id(li)
                if pkg_id:
                    result["loadBefore"].add(pkg_id)

        return result

    @staticmethod
    def _parse_about_safe(file_path: Path):
        """安全地解析 About.xml 以避免 XXE。

        Args:
            file_path: About.xml 文件路径。

        Returns:
            XML 根元素，如果解析失败返回 None。
        """
        try:
            from defusedxml.ElementTree import parse

            tree = parse(file_path)
            return tree.getroot()
        except ImportError:
            try:
                from lxml import etree

                parser = etree.XMLParser(resolve_entities=False)
                tree = etree.parse(file_path, parser)
                return tree.getroot()
            except ImportError:
                from xml.etree import ElementTree as ET
                from xml.etree.ElementTree import XMLParser

                parser = XMLParser(resolve_entities=False)
                tree = ET.parse(file_path, parser)
                return tree.getroot()
        return None

    def _topological_sort(self) -> list[str]:
        """对 Mod 依赖关系执行拓扑排序。

        Returns:
            按依赖顺序排列的 Mod ID 列表
        """
        in_degree = dict.fromkeys(self.mod_dict, 0)
        graph: dict[str, list[str]] = defaultdict(list)

        for mod_id, deps in self.dependencies.items():
            if mod_id in in_degree:
                for dep_id in deps:
                    if dep_id in in_degree:
                        graph[dep_id].append(mod_id)
                        in_degree[mod_id] += 1

        queue = deque([mod_id for mod_id, degree in in_degree.items() if degree == 0])
        sorted_ids = []

        while queue:
            current = queue.popleft()
            sorted_ids.append(current)

            for neighbor in graph[current]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        if len(sorted_ids) != len(self.mod_dict):
            logger.warning("Circular dependency detected, using fallback sort")
            sorted_ids = self._fallback_sort()

        return sorted_ids

    def _fallback_sort(self) -> list[str]:
        """当存在循环依赖时使用后备排序。

        Returns:
            按字母顺序排列的 Mod ID 列表
        """
        return sorted(self.mod_dict.keys(), key=lambda x: x.lower())

    def _reorder_mods(self, sorted_ids: list[str]) -> list[dict]:
        """根据排序后的 ID 重新排序 Mod。

        Args:
            sorted_ids: 按排序顺序排列的 Mod ID 列表

        Returns:
            重新排序后的 Mod 字典列表
        """
        sorted_mods = [self.mod_dict[mod_id] for mod_id in sorted_ids if mod_id in self.mod_dict]

        for mod in self.mods:
            mod_id = mod.get("id", "")
            if mod_id not in sorted_ids:
                sorted_mods.append(mod)

        return sorted_mods

    def get_dependency_tree(self, mod_id: str) -> dict[str, list[str]]:
        """获取特定 Mod 的依赖树。

        Args:
            mod_id: 要获取依赖关系的 Mod ID

        Returns:
            将 Mod ID 映射到其依赖项的字典
        """
        tree = {}
        visited = set()
        queue = deque([mod_id])

        while queue:
            current = queue.popleft()
            if current in visited:
                continue
            visited.add(current)

            if current in self.dependencies:
                tree[current] = list(self.dependencies[current])
                for dep in self.dependencies[current]:
                    if dep not in visited:
                        queue.append(dep)

        return tree

    def validate_dependencies(self) -> dict[str, list[str]]:
        """验证所有依赖关系并查找缺失的依赖项。

        Returns:
            包含验证结果的字典：
            - 'missing': (mod_id, missing_dependency) 元组列表
            - 'circular': 循环依赖链列表
        """
        results = {
            "missing": [],
            "circular": [],
        }

        for mod_id, deps in self.dependencies.items():
            for dep_id in deps:
                if dep_id not in self.mod_dict:
                    results["missing"].append((mod_id, dep_id))
                    logger.warning(f"Mod '{mod_id}' depends on missing mod '{dep_id}'")

        visited = set()
        rec_stack = set()

        def dfs(node: str, path: list[str]) -> list[str] | None:
            visited.add(node)
            rec_stack.add(node)
            path.append(node)

            if node in self.dependencies:
                for neighbor in self.dependencies[node]:
                    if neighbor not in visited:
                        cycle = dfs(neighbor, path.copy())
                        if cycle:
                            return cycle
                    elif neighbor in rec_stack:
                        cycle_start = path.index(neighbor)
                        return [*path[cycle_start:], neighbor]

            rec_stack.remove(node)
            return None

        for mod_id in self.mod_dict:
            if mod_id not in visited:
                cycle = dfs(mod_id, [])
                if cycle:
                    results["circular"].append(cycle)
                    logger.warning(f"Circular dependency detected: {' -> '.join(cycle)}")

        return results
