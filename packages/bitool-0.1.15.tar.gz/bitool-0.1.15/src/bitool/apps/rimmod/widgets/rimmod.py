"""RimMod 主窗口组件。"""

from __future__ import annotations

from pathlib import Path

from bitool.core import logger
from bitool.gui import apply_theme, list_themes, setup_ui
from bitool.gui.compat import (
    QCloseEvent,
    QFileDialog,
    QMessageBox,
    QMoveEvent,
    QResizeEvent,
    Qt,
    QTableWidget,
    QTableWidgetItem,
    QWidget,
)

from ..config import conf
from ..translation import Language, translator
from .mod_sorter import ModSorter


class RimMod(QWidget):
    """RimWorld Mod 管理器主窗口，采用双面板布局。"""

    MAX_UNDO_STACK_SIZE = 50

    def __init__(self) -> None:
        super().__init__()

        self.all_mods: list[dict] = []
        self.unapplied_mods: list[dict] = []
        self.applied_mods: list[dict] = []
        self.filtered_unapplied: list[dict] = []
        self.filtered_applied: list[dict] = []
        self.mod_folder = Path()
        self.is_modified = False

        self.undo_stack: list[dict] = []
        self.redo_stack: list[dict] = []

        setup_ui(widget=self)

        self._save_state()

        self._setup_tables()

        self._load_default_mod_path()

        self._connect_signals()

        self._apply_theme()

    def _setup_tables(self) -> None:
        """设置表格属性。"""
        self.left_table.setSelectionBehavior(
            QTableWidget.SelectionBehavior.SelectRows,
        )
        self.left_table.setAlternatingRowColors(True)
        self.left_table.horizontalHeader().setStretchLastSection(True)

        self.right_table.setSelectionBehavior(
            QTableWidget.SelectionBehavior.SelectRows,
        )
        self.right_table.setAlternatingRowColors(True)
        self.right_table.viewport().setAcceptDrops(True)
        self.right_table.setDropIndicatorShown(True)
        self.right_table.horizontalHeader().setStretchLastSection(True)

        self.setGeometry(*conf.WINDOW_POS, *conf.WINDOW_SIZE)

    def _connect_signals(self) -> None:
        """连接按钮信号到槽函数。"""
        self.btn_load_mods.clicked.connect(self.on_load_mods)
        self.btn_import.clicked.connect(self.on_import_list)
        self.btn_export.clicked.connect(self.on_export_list)
        self.btn_apply.clicked.connect(self.on_apply_changes)
        self.btn_save.clicked.connect(self.on_save_mod_list)

        self.btn_add.clicked.connect(self.on_add_selected)
        self.btn_remove.clicked.connect(self.on_remove_selected)
        self.btn_add_all.clicked.connect(self.on_add_all)
        self.btn_remove_all.clicked.connect(self.on_remove_all)

        self.left_table.cellDoubleClicked.connect(self.on_left_double_click)
        self.right_table.cellDoubleClicked.connect(self.on_right_double_click)

        self.right_table.model().rowsMoved.connect(self.on_right_rows_moved)

        self.left_table.selectionModel().selectionChanged.connect(self.on_selection_changed)
        self.right_table.selectionModel().selectionChanged.connect(self.on_selection_changed)

        self.btn_open_url.clicked.connect(self.on_open_url)

        self.search_left.textChanged.connect(self.on_search_changed)
        self.search_right.textChanged.connect(self.on_search_changed)

        self.btn_save_preset.clicked.connect(self.on_save_preset)
        self.btn_load_preset.clicked.connect(self.on_load_preset)

        self.btn_diagnose.clicked.connect(self.on_diagnose)

        self.btn_undo.clicked.connect(self.on_undo)
        self.btn_redo.clicked.connect(self.on_redo)

        self.btn_open_steam.clicked.connect(self.on_open_steam)

        self.btn_view_dependencies.clicked.connect(self.on_view_dependencies)

        self.theme_combo.currentTextChanged.connect(self.on_theme_changed)

        self.lang_combo.currentTextChanged.connect(self.on_language_changed)

    def _apply_theme(self) -> None:
        """应用主题到窗口。"""
        themes = list_themes()
        self.theme_combo.clear()
        self.theme_combo.addItems(themes)

        default_theme = conf.DEFAULT_THEME
        if default_theme in themes:
            self.theme_combo.setCurrentText(default_theme)

        languages = [lang.value for lang in Language]
        self.lang_combo.clear()
        self.lang_combo.addItems(languages)

        current_lang = translator.current_language.value
        self.lang_combo.setCurrentText(current_lang)

        apply_theme(self, default_theme)

    def _load_default_mod_path(self) -> None:
        """加载默认的 RimWorld Mod 文件夹路径。"""
        all_paths = conf.get_all_mod_paths()
        if all_paths:
            self.mod_folder = all_paths[0]
            path_str = ", ".join([str(p) for p in all_paths])
            self.status_label.setText(f"Mod 路径: {path_str}")
            self._load_mods_from_folders(all_paths)

    def on_load_mods(self) -> None:
        """从选定文件夹加载 Mod。"""
        folder = QFileDialog.getExistingDirectory(
            self,
            "选择 Mod 文件夹",
            str(self.mod_folder) if self.mod_folder.exists() else str(Path.home()),
        )

        if not folder:
            return

        self.mod_folder = Path(folder)
        conf.MOD_FOLDER_PATH = str(self.mod_folder)

        all_paths = conf.get_all_mod_paths()
        if self.mod_folder not in all_paths:
            all_paths.insert(0, self.mod_folder)

        self._load_mods_from_folders(all_paths)

        self.status_label.setText(f"已从 {len(all_paths)} 个目录加载 Mod")
        logger.info(f"Loaded mods from {len(all_paths)} folders")

    def _load_mods_from_folders(self, folders: list[Path]) -> None:
        """从多个文件夹加载 Mod 并分成已激活/未激活。"""
        from bitool.gui.compat import QProgressDialog

        progress = QProgressDialog("正在加载 Mod...", "取消", 0, 100, self)
        progress.setWindowTitle("加载中")
        progress.setModal(True)
        progress.setValue(0)
        progress.show()
        self.repaint()

        self.all_mods = []
        seen_ids = set()

        total_folders = len(folders)
        for idx, folder in enumerate(folders):
            if not folder.exists():
                continue

            progress.setValue(int((idx / total_folders) * 50))
            self.repaint()

            if progress.wasCanceled():
                break

            mods = self._scan_mod_folder(folder)
            for mod in mods:
                mod_id = mod.get("id", "").lower()
                folder_name = mod.get("folder_name", "").lower()
                if mod_id not in seen_ids and folder_name not in seen_ids:
                    seen_ids.add(mod_id)
                    seen_ids.add(folder_name)
                    self.all_mods.append(mod)

        progress.setValue(50)
        self.repaint()

        self.all_mods.sort(key=lambda x: x.get("name", "").lower())

        mod_list_path = conf.get_mod_list_path()
        applied_ids = self._parse_mod_list(mod_list_path) if mod_list_path.exists() else []

        progress.setValue(60)
        self.repaint()

        if applied_ids:
            self.applied_mods = []
            matched_mods = set()
            mod_by_id = {mod.get("id", "").lower(): mod for mod in self.all_mods}
            mod_by_folder = {mod.get("folder_name", "").lower(): mod for mod in self.all_mods}

            for mod_id in applied_ids:
                mod_id_lower = mod_id.lower()
                if mod_id_lower in mod_by_id:
                    self.applied_mods.append(mod_by_id[mod_id_lower])
                    matched_mods.add(mod_by_id[mod_id_lower])
                elif mod_id_lower in mod_by_folder:
                    self.applied_mods.append(mod_by_folder[mod_id_lower])
                    matched_mods.add(mod_by_folder[mod_id_lower])

            self.unapplied_mods = [mod for mod in self.all_mods if mod not in matched_mods]
        else:
            self.unapplied_mods = self.all_mods.copy()
            self.applied_mods = []

        self.filtered_unapplied = self.unapplied_mods.copy()
        self.filtered_applied = self.applied_mods.copy()

        self._populate_tables()
        self._update_mod_count()

        progress.setValue(100)
        progress.close()

    def _scan_mod_folder(self, folder: Path) -> list[dict]:
        """扫描 Mod 文件夹并收集 Mod 信息。"""
        mods = []

        if not folder.exists():
            return mods

        is_workshop = self._is_workshop_folder(folder)

        for item in folder.iterdir():
            if not item.is_dir():
                continue

            mod_info = self._get_mod_info(item, is_workshop)
            if mod_info:
                mods.append(mod_info)

        return mods

    def _is_workshop_folder(self, folder: Path) -> bool:
        """检查文件夹是否为 Steam 创意工坊文件夹。"""
        if "workshop" in str(folder).lower():
            return True

        return bool(folder.name.isdigit())

    def _get_mod_info(self, mod_path: Path, is_workshop: bool = False) -> dict | None:
        """从 About.xml 获取 Mod 信息。"""
        about_file = mod_path / "About" / "About.xml"
        if not about_file.exists():
            about_file = mod_path / "About.xml"

        folder_name = mod_path.name

        if not about_file.exists():
            return {
                "id": folder_name,
                "folder_name": folder_name,
                "name": folder_name,
                "author": "Unknown",
                "description": "",
                "version": "Unknown",
                "supported_versions": [],
                "url": "",
                "preview_image": None,
                "source": "Workshop" if is_workshop else "Local",
                "path": str(mod_path),
            }

        try:
            mod_info = self._parse_mod_about_safe(about_file)
            if mod_info:
                package_id = mod_info.get("packageId", folder_name)
                preview_image = self._find_preview_image(mod_path)
                return {
                    "id": package_id,
                    "folder_name": folder_name,
                    "name": mod_info.get("name", folder_name),
                    "author": mod_info.get("author", "Unknown"),
                    "description": mod_info.get("description", ""),
                    "version": mod_info.get("version", "Unknown"),
                    "supported_versions": mod_info.get("supportedVersions", []),
                    "url": mod_info.get("url", ""),
                    "preview_image": preview_image,
                    "path": str(mod_path),
                }
            else:
                return {
                    "id": folder_name,
                    "folder_name": folder_name,
                    "name": folder_name,
                    "author": "Unknown",
                    "description": "",
                    "version": "Unknown",
                    "supported_versions": [],
                    "url": "",
                    "preview_image": None,
                    "path": str(mod_path),
                }
        except (OSError, ValueError) as e:
            logger.warning(f"Failed to parse About.xml for {mod_path.name}: {e}")
            return {
                "id": folder_name,
                "folder_name": folder_name,
                "name": folder_name,
                "author": "Unknown",
                "description": "",
                "version": "Unknown",
                "supported_versions": [],
                "url": "",
                "preview_image": None,
                "path": str(mod_path),
            }

    @staticmethod
    def _find_preview_image(mod_path: Path) -> str | None:
        """查找 Mod 的预览图。"""
        about_dir = mod_path / "About"
        preview_files = ["Preview.png", "Preview.jpg", "Preview.gif", "preview.png", "preview.jpg", "preview.gif"]
        for preview_file in preview_files:
            image_path = about_dir / preview_file
            if image_path.exists():
                return str(image_path)
        return None

    @staticmethod
    def _parse_mod_about_safe(file_path: Path) -> dict | None:
        """安全地解析 About.xml，避免 XXE 攻击。"""
        try:
            from defusedxml.ElementTree import parse

            tree = parse(file_path)
            root = tree.getroot()
        except ImportError:
            try:
                from lxml import etree

                parser = etree.XMLParser(resolve_entities=False)
                tree = etree.parse(file_path, parser)
                root = tree.getroot()
            except ImportError:
                from xml.etree import ElementTree as ET
                from xml.etree.ElementTree import XMLParser

                parser = XMLParser(resolve_entities=False)
                tree = ET.parse(file_path, parser)
                root = tree.getroot()

        name_elem = root.find("name")
        author_elem = root.find("author")
        package_id_elem = root.find("packageId")
        description_elem = root.find("description")
        version_elem = root.find("modVersion")
        url_elem = root.find("url")

        supported_versions = []
        sv_elem = root.find("supportedVersions")
        if sv_elem is not None:
            supported_versions.extend(li_elem.text for li_elem in sv_elem.findall("li") if li_elem.text)

        return {
            "name": name_elem.text if name_elem is not None else None,
            "author": author_elem.text if author_elem is not None else None,
            "packageId": package_id_elem.text if package_id_elem is not None else None,
            "description": description_elem.text if description_elem is not None else "",
            "version": version_elem.text if version_elem is not None else "Unknown",
            "supportedVersions": supported_versions,
            "url": url_elem.text if url_elem is not None else "",
        }

    def _populate_tables(self) -> None:
        """用当前 Mod 数据填充两个表格。"""
        self.left_table.setRowCount(len(self.filtered_unapplied))
        for i, mod in enumerate(self.filtered_unapplied):
            index_item = QTableWidgetItem(str(i + 1))
            index_item.setFlags(index_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.left_table.setItem(i, 0, index_item)

            name_item = QTableWidgetItem(mod.get("name", "Unknown"))
            name_item.setToolTip(f"作者: {mod.get('author', 'Unknown')}")
            self.left_table.setItem(i, 1, name_item)

            id_item = QTableWidgetItem(mod.get("id", ""))
            id_item.setFlags(id_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.left_table.setItem(i, 2, id_item)

        self.right_table.setRowCount(len(self.filtered_applied))
        for i, mod in enumerate(self.filtered_applied):
            index_item = QTableWidgetItem(str(i + 1))
            index_item.setFlags(index_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.right_table.setItem(i, 0, index_item)

            name_item = QTableWidgetItem(mod.get("name", "Unknown"))
            name_item.setToolTip(f"作者: {mod.get('author', 'Unknown')}")
            self.right_table.setItem(i, 1, name_item)

            id_item = QTableWidgetItem(mod.get("id", ""))
            id_item.setFlags(id_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.right_table.setItem(i, 2, id_item)

    def _update_mod_count(self) -> None:
        """更新 Mod 数量标签。"""
        self.mod_count_label.setText(f"未激活: {len(self.unapplied_mods)} | 已激活: {len(self.applied_mods)}")

    def on_add_selected(self) -> None:
        """将选中的 Mod 从左侧添加到右侧。"""
        selected_rows = sorted({index.row() for index in self.left_table.selectedIndexes()}, reverse=True)

        if not selected_rows:
            return

        mods_to_move = []
        for row in selected_rows:
            if 0 <= row < len(self.filtered_unapplied):
                mod = self.filtered_unapplied[row]
                mods_to_move.append(mod)

        for mod in mods_to_move:
            if mod in self.unapplied_mods:
                self.unapplied_mods.remove(mod)
                self.applied_mods.append(mod)

        self._save_state()

        self.on_search_changed()
        self._update_mod_count()
        self.is_modified = True

    def on_remove_selected(self) -> None:
        """将选中的 Mod 从右侧移除到左侧。"""
        selected_rows = sorted({index.row() for index in self.right_table.selectedIndexes()}, reverse=True)

        if not selected_rows:
            return

        mods_to_move = []
        for row in selected_rows:
            if 0 <= row < len(self.filtered_applied):
                mod = self.filtered_applied[row]
                mods_to_move.append(mod)

        for mod in mods_to_move:
            if mod in self.applied_mods:
                self.applied_mods.remove(mod)
                self.unapplied_mods.append(mod)

        self.unapplied_mods.sort(key=lambda x: x.get("name", "").lower())

        self._save_state()

        self.on_search_changed()
        self._update_mod_count()
        self.is_modified = True

    def on_add_all(self) -> None:
        """添加所有 Mod 到已激活列表。"""
        if not self.unapplied_mods:
            return

        self.applied_mods.extend(self.unapplied_mods)
        self.unapplied_mods.clear()

        self._save_state()

        self.on_search_changed()
        self._update_mod_count()
        self.is_modified = True

    def on_remove_all(self) -> None:
        """从已激活列表中移除所有 Mod。"""
        if not self.applied_mods:
            return

        self.unapplied_mods.extend(self.applied_mods)
        self.applied_mods.clear()

        self.unapplied_mods.sort(key=lambda x: x.get("name", "").lower())

        self._save_state()

        self.on_search_changed()
        self._update_mod_count()
        self.is_modified = True

    def on_left_double_click(self, row: int, column: int) -> None:
        """处理左侧表格双击以添加 Mod。"""
        if 0 <= row < len(self.filtered_unapplied):
            mod = self.filtered_unapplied[row]
            if mod in self.unapplied_mods:
                self.unapplied_mods.remove(mod)
                self.applied_mods.append(mod)

                self._save_state()

                self.on_search_changed()
                self._update_mod_count()
                self.is_modified = True

    def on_right_double_click(self, row: int, column: int) -> None:
        """处理右侧表格双击以移除 Mod。"""
        if 0 <= row < len(self.filtered_applied):
            mod = self.filtered_applied[row]
            if mod in self.applied_mods:
                self.applied_mods.remove(mod)
                self.unapplied_mods.append(mod)
                self.unapplied_mods.sort(key=lambda x: x.get("name", "").lower())

                self._save_state()

                self.on_search_changed()
                self._update_mod_count()
                self.is_modified = True

    def on_right_rows_moved(self, sourceParent, sourceStart, sourceEnd, destinationParent, destinationRow) -> None:
        """处理拖放排序已激活的 Mod。"""
        new_order = []
        for i in range(self.right_table.rowCount()):
            id_item = self.right_table.item(i, 2)
            if id_item:
                mod_id = id_item.text()
                for mod in self.applied_mods:
                    if mod.get("id", "") == mod_id:
                        new_order.append(mod)
                        break

        self.applied_mods = new_order

        self.on_search_changed()

        for i in range(self.right_table.rowCount()):
            index_item = self.right_table.item(i, 0)
            if index_item:
                index_item.setText(str(i + 1))

        self.is_modified = True

    def on_import_list(self) -> None:
        """从文件导入 Mod 列表。"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "导入 Mod 列表",
            str(Path.home()),
            "XML Files (*.xml);;All Files (*.*)",
        )

        if not file_path:
            return

        imported_ids = self._parse_mod_list(Path(file_path))

        if not imported_ids:
            QMessageBox.warning(self, "警告", "无法解析导入的文件或文件为空")
            return

        self._apply_imported_list(imported_ids)
        self.status_label.setText(f"已从 {file_path} 导入 Mod 配置")
        self.is_modified = True

    def _parse_mod_list(self, file_path: Path) -> list[str]:
        """从 XML 文件解析 Mod 列表，安全避免 XXE 攻击。"""
        if not file_path.exists():
            return []

        try:
            from defusedxml.ElementTree import parse

            tree = parse(file_path)
            root = tree.getroot()
        except ImportError:
            try:
                from lxml import etree

                parser = etree.XMLParser(resolve_entities=False)
                tree = etree.parse(file_path, parser)
                root = tree.getroot()
            except ImportError:
                from xml.etree import ElementTree as ET
                from xml.etree.ElementTree import XMLParser

                parser = XMLParser(resolve_entities=False)
                tree = ET.parse(file_path, parser)
                root = tree.getroot()

        mods = []
        for li in root.findall(".//li"):
            mod_id = li.text
            if mod_id:
                mods.append(mod_id)

        if not mods:
            for mod in root.findall(".//mod"):
                mod_id = mod.get("id") or mod.get("packageId") or mod.text
                if mod_id:
                    mods.append(mod_id)

        return mods

    def _apply_imported_list(self, mod_ids: list[str]) -> None:
        """应用导入的 Mod 列表以分隔两个面板中的 Mod。"""
        mod_by_id = {mod.get("id", "").lower(): mod for mod in self.all_mods}
        mod_by_folder = {mod.get("folder_name", "").lower(): mod for mod in self.all_mods}

        self.applied_mods = []
        matched_mods = set()

        for mod_id in mod_ids:
            mod_id_lower = mod_id.lower()
            if mod_id_lower in mod_by_id:
                self.applied_mods.append(mod_by_id[mod_id_lower])
                matched_mods.add(mod_by_id[mod_id_lower])
            elif mod_id_lower in mod_by_folder:
                self.applied_mods.append(mod_by_folder[mod_id_lower])
                matched_mods.add(mod_by_folder[mod_id_lower])

        self.unapplied_mods = [mod for mod in self.all_mods if mod not in matched_mods]
        self.unapplied_mods.sort(key=lambda x: x.get("name", "").lower())

        self.on_search_changed()
        self._update_mod_count()

    def on_export_list(self) -> None:
        """导出 Mod 列表到文件。"""
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "导出 Mod 列表",
            str(Path.home() / "modlist.xml"),
            "XML Files (*.xml);;All Files (*.*)",
        )

        if not file_path:
            return

        if self._save_mod_list(Path(file_path)):
            QMessageBox.information(self, "成功", f"Mod 列表已导出到:\n{file_path}")
            self.status_label.setText("列表导出成功")
        else:
            QMessageBox.critical(self, "错误", "导出列表失败")

    def _save_mod_list(self, file_path: Path) -> bool:
        """保存 Mod 列表到 XML 文件，安全避免 XXE。"""
        try:
            from xml.etree import ElementTree as ET

            root = ET.Element("Mods")
            for mod in self.applied_mods:
                li = ET.SubElement(root, "li")
                li.text = mod.get("id", "")

            tree = ET.ElementTree(root)
            tree.write(file_path, encoding="utf-8", xml_declaration=True)
        except OSError as e:
            logger.error(f"Failed to save mod list: {e}")
            return False
        else:
            return True

    def _auto_sort_mods(self) -> None:
        """根据依赖关系自动排序已激活的 Mod。"""
        if not self.applied_mods:
            return

        validation_result = self._validate_dependencies()
        if not validation_result["valid"]:
            warning_msg = "检测到以下依赖问题:\n\n"
            for issue in validation_result["issues"]:
                warning_msg += f"• {issue}\n"
            warning_msg += "\n是否继续排序？"

            reply = QMessageBox.warning(
                self,
                "依赖验证警告",
                warning_msg,
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            )

            if reply == QMessageBox.StandardButton.No:
                return

        sorter = ModSorter(self.applied_mods)
        sorted_mods = sorter.sort()

        self.applied_mods = sorted_mods
        self.on_search_changed()
        self.status_label.setText("已自动排序")

    def _validate_dependencies(self) -> dict:
        """验证 Mod 依赖关系并检查问题。"""
        issues = []

        {mod.get("id", "").lower() for mod in self.all_mods}
        {mod.get("folder_name", "").lower() for mod in self.all_mods}

        for mod in self.applied_mods:
            mod_id = mod.get("id", "").lower()
            mod_name = mod.get("name", mod_id)

            matching = [m for m in self.applied_mods if m.get("id", "").lower() == mod_id]
            if len(matching) > 1:
                issues.append(f"'{mod_name}' (ID: {mod_id}) 在列表中出现多次")

        return {
            "valid": len(issues) == 0,
            "issues": issues,
        }

    def on_apply_changes(self) -> None:
        """应用更改到 RimWorld Mod 列表并进行自动排序。"""
        if not self.mod_folder.exists():
            QMessageBox.warning(self, "警告", "Mod 文件夹不存在")
            return

        self._auto_sort_mods()

        mod_list_path = conf.get_mod_list_path()
        mod_list_path.parent.mkdir(parents=True, exist_ok=True)

        if self._save_mod_list(mod_list_path):
            QMessageBox.information(self, "成功", f"已将 Mod 列表应用到:\n{mod_list_path}")
            self.status_label.setText("已应用更改")
            self.is_modified = False
        else:
            QMessageBox.critical(self, "错误", "应用更改失败")

    def on_save_mod_list(self) -> None:
        """将当前 Mod 列表保存到 RimWorld 配置。"""
        self.on_apply_changes()

    def moveEvent(self, event: QMoveEvent) -> None:
        """处理窗口移动事件。"""
        super().moveEvent(event)
        conf.WINDOW_POS = [self.x(), self.y()]

    def resizeEvent(self, event: QResizeEvent) -> None:
        """处理窗口调整大小事件。"""
        super().resizeEvent(event)
        conf.WINDOW_SIZE = [self.width(), self.height()]

    def closeEvent(self, event: QCloseEvent) -> None:
        """处理窗口关闭事件。"""
        if self.is_modified:
            reply = QMessageBox.question(
                self,
                "确认退出",
                "有未保存的更改，是否保存？",
                QMessageBox.StandardButton.Save
                | QMessageBox.StandardButton.Discard
                | QMessageBox.StandardButton.Cancel,
            )

            if reply == QMessageBox.StandardButton.Save:
                self.on_apply_changes()
                event.accept()
            elif reply == QMessageBox.StandardButton.Discard:
                event.accept()
            else:
                event.ignore()
                return

        event.accept()

    def on_selection_changed(self) -> None:
        """处理选择变化并更新详情面板。"""
        selected = self._get_selected_mod()
        if selected:
            self._update_mod_details(selected)
        else:
            self._clear_mod_details()

    def _get_selected_mod(self) -> dict | None:
        """从任一表格获取当前选中的 Mod。"""
        left_selected = self.left_table.selectedIndexes()
        if left_selected:
            row = left_selected[0].row()
            if 0 <= row < len(self.filtered_unapplied):
                return self.filtered_unapplied[row]

        right_selected = self.right_table.selectedIndexes()
        if right_selected:
            row = right_selected[0].row()
            if 0 <= row < len(self.filtered_applied):
                return self.filtered_applied[row]

        return None

    def _update_mod_details(self, mod: dict) -> None:
        """用 Mod 信息更新详情面板。"""
        self.mod_name_label.setText(mod.get("name", "Unknown"))
        self.mod_author.setText(mod.get("author", "-"))
        self.mod_version.setText(mod.get("version", "-"))
        self.mod_id.setText(mod.get("id", "-"))

        supported_versions = mod.get("supported_versions", [])
        if supported_versions:
            self.mod_support.setText(", ".join(supported_versions))
        else:
            self.mod_support.setText("-")

        description = mod.get("description", "无描述")
        self.mod_description.setText(description)

        url = mod.get("url", "")
        if url:
            self.btn_open_url.setEnabled(True)
            self.btn_open_url.setProperty("mod_url", url)
        else:
            self.btn_open_url.setEnabled(False)

        self._load_preview_image(mod.get("preview_image"))

    def _clear_mod_details(self) -> None:
        """清空 Mod 详情面板。"""
        self.mod_name_label.setText("未选择 Mod")
        self.mod_author.setText("-")
        self.mod_version.setText("-")
        self.mod_id.setText("-")
        self.mod_support.setText("-")
        self.mod_description.setText("选择一个 Mod 查看详情")
        self.btn_open_url.setEnabled(False)
        self._clear_preview_image()

    def _load_preview_image(self, image_path: str | None) -> None:
        """加载预览图并在预览标签中显示。"""
        if not image_path or not Path(image_path).exists():
            self._clear_preview_image()
            return

        try:
            from bitool.gui.compat import QPixmap

            pixmap = QPixmap(image_path)
            if not pixmap.isNull():
                scaled_pixmap = pixmap.scaled(
                    self.mod_preview.size(),
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
                self.mod_preview.setPixmap(scaled_pixmap)
                self.mod_preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
            else:
                self._clear_preview_image()
        except (OSError, RuntimeError) as e:
            logger.warning(f"Failed to load preview image: {e}")
            self._clear_preview_image()

    def _clear_preview_image(self) -> None:
        """清空预览图并显示占位符。"""
        self.mod_preview.clear()
        self.mod_preview.setText("（无预览图）")
        self.mod_preview.setStyleSheet(
            "QLabel { background-color: #333333; border-radius: 4px; color: #888888; }",
        )

    def on_open_url(self) -> None:
        """在 Web 浏览器中打开 Mod 的 URL。"""
        url = self.btn_open_url.property("mod_url")
        if not url:
            return

        try:
            from bitool.gui.compat import QDesktopServices, QUrl

            QDesktopServices.openUrl(QUrl(url))
            self.status_label.setText("已打开 Mod URL")
        except (OSError, RuntimeError) as e:
            logger.warning(f"Failed to open URL: {e}")
            QMessageBox.warning(self, "警告", "无法打开 URL")

    def on_search_changed(self) -> None:
        """处理搜索框文本变化并过滤 Mod 列表。"""
        search_left_text = self.search_left.text().strip().lower()
        search_right_text = self.search_right.text().strip().lower()

        if search_left_text:
            self.filtered_unapplied = [
                mod
                for mod in self.unapplied_mods
                if (
                    search_left_text in mod.get("name", "").lower()
                    or search_left_text in mod.get("id", "").lower()
                    or search_left_text in mod.get("author", "").lower()
                )
            ]
        else:
            self.filtered_unapplied = self.unapplied_mods.copy()

        if search_right_text:
            self.filtered_applied = [
                mod
                for mod in self.applied_mods
                if (
                    search_right_text in mod.get("name", "").lower()
                    or search_right_text in mod.get("id", "").lower()
                    or search_right_text in mod.get("author", "").lower()
                )
            ]
        else:
            self.filtered_applied = self.applied_mods.copy()

        self._populate_tables()

    def on_save_preset(self) -> None:
        """将当前 Mod 列表保存为预设。"""
        from datetime import datetime, timezone

        from bitool.gui.compat import QInputDialog, QLineEdit

        preset_name, ok = QInputDialog.getText(
            self,
            "保存预设",
            "请输入预设名称：",
            QLineEdit.EchoMode.Normal,
            "",
        )

        if not ok or not preset_name:
            return

        description, ok = QInputDialog.getText(
            self,
            "预设描述",
            "请输入预设描述（可选）：",
            QLineEdit.EchoMode.Normal,
            "",
        )

        if not ok:
            description = ""

        preset_data = {
            "name": preset_name,
            "description": description,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "mod_count": len(self.applied_mods),
            "mods": [
                {
                    "id": mod.get("id", ""),
                    "folder_name": mod.get("folder_name", ""),
                    "name": mod.get("name", ""),
                }
                for mod in self.applied_mods
            ],
        }

        presets_folder = self._get_presets_folder()
        presets_folder.mkdir(parents=True, exist_ok=True)

        filename = self._sanitize_filename(preset_name) + ".json"
        file_path = presets_folder / filename

        try:
            import json

            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(preset_data, f, ensure_ascii=False, indent=2)

            QMessageBox.information(
                self,
                "成功",
                f"预设 '{preset_name}' 已保存到：\n{file_path}",
            )
            self.status_label.setText(f"已保存预设: {preset_name}")
            logger.info(f"Saved preset '{preset_name}' to {file_path}")

        except (OSError, ValueError) as e:
            logger.error(f"Failed to save preset: {e}")
            QMessageBox.critical(
                self,
                "错误",
                f"保存预设失败：\n{e!s}",
            )

    def on_load_preset(self) -> None:
        """从文件加载预设。"""
        presets_folder = self._get_presets_folder()
        if not presets_folder.exists():
            QMessageBox.information(
                self,
                "提示",
                "还没有保存任何预设。\n请先使用「保存预设」功能创建预设。",
            )
            return

        preset_files = sorted(presets_folder.glob("*.json"))
        if not preset_files:
            QMessageBox.information(
                self,
                "提示",
                "还没有保存任何预设。\n请先使用「保存预设」功能创建预设。",
            )
            return

        preset_list = []
        for file_path in preset_files:
            try:
                import json

                with open(file_path, encoding="utf-8") as f:
                    data = json.load(f)
                    name = data.get("name", file_path.stem)
                    mod_count = data.get("mod_count", 0)
                    timestamp = data.get("timestamp", "")
                    if timestamp:
                        try:
                            from datetime import datetime

                            dt = datetime.fromisoformat(timestamp)
                            timestamp = dt.strftime("%Y-%m-%d %H:%M")
                        except (ValueError, TypeError):
                            pass
                    preset_list.append(f"{name} ({mod_count} mods) - {timestamp}")
            except (OSError, ValueError) as e:
                logger.warning(f"Failed to read preset {file_path}: {e}")
                preset_list.append(f"{file_path.stem} (读取失败)")

        from bitool.gui.compat import QInputDialog

        selected, ok = QInputDialog.getItem(
            self,
            "加载预设",
            "选择要加载的预设：",
            preset_list,
            0,
            False,
        )

        if not ok or not selected:
            return

        index = preset_list.index(selected)
        preset_file = preset_files[index]

        self._apply_preset(preset_file)

    def _apply_preset(self, file_path: Path) -> None:
        """应用来自文件的预设。"""
        try:
            import json

            with open(file_path, encoding="utf-8") as f:
                preset_data = json.load(f)

            preset_name = preset_data.get("name", file_path.stem)
            mod_ids = [mod.get("id", "") or mod.get("folder_name", "") for mod in preset_data.get("mods", [])]

            if not mod_ids:
                QMessageBox.warning(
                    self,
                    "警告",
                    f"预设 '{preset_name}' 中没有Mod。",
                )
                return

            self._apply_imported_list(mod_ids)

            QMessageBox.information(
                self,
                "成功",
                f"已加载预设 '{preset_name}'\n共 {len(mod_ids)} 个Mod",
            )
            self.status_label.setText(f"已加载预设: {preset_name}")
            logger.info(f"Loaded preset '{preset_name}' from {file_path}")

        except (OSError, ValueError) as e:
            logger.error(f"Failed to load preset: {e}")
            QMessageBox.critical(
                self,
                "错误",
                f"加载预设失败：\n{e!s}",
            )

    def _get_presets_folder(self) -> Path:
        """获取存储预设的文件夹。"""
        config_dir = Path.home() / ".bitool" / "rimmod" / "presets"
        return config_dir

    def _sanitize_filename(self, name: str) -> str:
        """清理字符串以用作文件名。"""
        import re

        filename = re.sub(r'[<>:"/\\|?*]', "_", name)
        filename = filename[:100]
        return filename

    def _validate_mod_dependencies(self) -> dict:
        """通过读取 About.xml 文件验证 Mod 依赖关系。"""
        issues = []
        warnings = []

        mod_by_id = {mod.get("id", "").lower(): mod for mod in self.all_mods}
        mod_by_folder = {mod.get("folder_name", "").lower(): mod for mod in self.all_mods}

        applied_ids = {mod.get("id", "").lower() for mod in self.applied_mods}

        for mod in self.applied_mods:
            mod_id = mod.get("id", "").lower()
            mod_name = mod.get("name", mod_id)
            mod_path = Path(mod.get("path", ""))

            if not mod_path.exists():
                continue

            about_file = mod_path / "About" / "About.xml"
            if not about_file.exists():
                about_file = mod_path / "About.xml"

            if not about_file.exists():
                continue

            deps_info = self._get_mod_dependencies_from_xml(about_file)

            for dep_id in deps_info.get("modDependencies", []):
                dep_id_lower = dep_id.lower()

                if dep_id_lower not in applied_ids:
                    if dep_id_lower in mod_by_id or dep_id_lower in mod_by_folder:
                        warnings.append(
                            f"'{mod_name}' 依赖的 '{dep_id}' 未被激活",
                        )
                    else:
                        issues.append(
                            f"'{mod_name}' 依赖的 '{dep_id}' 不存在",
                        )

        return {
            "valid": len(issues) == 0,
            "issues": issues,
            "warnings": warnings,
        }

    def _validate_load_order(self) -> list[str]:
        """基于 loadAfter/loadBefore 依赖验证加载顺序。"""
        issues = []

        mod_positions = {}
        for idx, mod in enumerate(self.applied_mods):
            mod_id = mod.get("id", "").lower()
            mod_positions[mod_id] = idx

        for mod in self.applied_mods:
            mod_id = mod.get("id", "").lower()
            mod_name = mod.get("name", mod_id)
            mod_path = Path(mod.get("path", ""))
            mod_position = mod_positions.get(mod_id, -1)

            if not mod_path.exists():
                continue

            about_file = mod_path / "About" / "About.xml"
            if not about_file.exists():
                about_file = mod_path / "About.xml"

            if not about_file.exists():
                continue

            deps_info = self._get_mod_dependencies_from_xml(about_file)

            for after_id in deps_info.get("loadAfter", []):
                after_id_lower = after_id.lower()
                if after_id_lower in mod_positions:
                    after_position = mod_positions[after_id_lower]
                    if mod_position <= after_position:
                        issues.append(
                            f"'{mod_name}' 需要在 '{after_id}' 之后加载",
                        )

            for before_id in deps_info.get("loadBefore", []):
                before_id_lower = before_id.lower()
                if before_id_lower in mod_positions:
                    before_position = mod_positions[before_id_lower]
                    if mod_position >= before_position:
                        issues.append(
                            f"'{mod_name}' 需要在 '{before_id}' 之前加载",
                        )

        return issues

    def _get_mod_dependencies_from_xml(self, about_file: Path) -> dict:
        """从 About.xml 文件中提取依赖信息。

        Returns:
            包含以下键的字典：
            - 'modDependencies': 必需 Mod 的 ID 列表
            - 'loadAfter': 必须在此 Mod 之前加载的 Mod 列表
            - 'loadBefore': 必须在此 Mod 之后加载的 Mod 列表
        """
        try:
            from defusedxml.ElementTree import parse

            tree = parse(about_file)
            root = tree.getroot()
        except ImportError:
            try:
                from lxml import etree

                parser = etree.XMLParser(resolve_entities=False)
                tree = etree.parse(about_file, parser)
                root = tree.getroot()
            except ImportError:
                from xml.etree import ElementTree as ET
                from xml.etree.ElementTree import XMLParser

                parser = XMLParser(resolve_entities=False)
                tree = ET.parse(about_file, parser)
                root = tree.getroot()

        result = {
            "modDependencies": [],
            "loadAfter": [],
            "loadBefore": [],
        }

        def extract_package_id(li_elem):
            """从 li 元素中提取包 ID。

            处理两种格式：
            1. <li>packageId</li> - 直接文本
            2. <li><packageId>xxx</packageId></li> - 嵌套元素
            """
            pkg_elem = li_elem.find("packageId")
            if pkg_elem is not None and pkg_elem.text:
                return pkg_elem.text.strip()
            if li_elem.text and li_elem.text.strip():
                return li_elem.text.strip()
            return None

        for li in root.findall(".//modDependencies/li"):
            pkg_id = extract_package_id(li)
            if pkg_id:
                result["modDependencies"].append(pkg_id)

        for version_elem in root.findall(".//modDependenciesByVersion/*"):
            for li in version_elem.findall(".//li"):
                pkg_id = extract_package_id(li)
                if pkg_id and pkg_id not in result["modDependencies"]:
                    result["modDependencies"].append(pkg_id)

        for li in root.findall(".//loadAfter/li"):
            pkg_id = extract_package_id(li)
            if pkg_id:
                result["loadAfter"].append(pkg_id)

        for version_elem in root.findall(".//loadAfterByVersion/*"):
            for li in version_elem.findall(".//li"):
                pkg_id = extract_package_id(li)
                if pkg_id:
                    result["loadAfter"].append(pkg_id)

        for li in root.findall(".//loadBefore/li"):
            pkg_id = extract_package_id(li)
            if pkg_id:
                result["loadBefore"].append(pkg_id)

        for version_elem in root.findall(".//loadBeforeByVersion/*"):
            for li in version_elem.findall(".//li"):
                pkg_id = extract_package_id(li)
                if pkg_id:
                    result["loadBefore"].append(pkg_id)

        return result

    def on_diagnose(self) -> None:
        """对当前 Mod 配置运行诊断检查。"""
        if not self.applied_mods:
            QMessageBox.information(
                self,
                "诊断",
                "当前没有激活的Mod。",
            )
            return

        from bitool.gui.compat import QProgressDialog

        progress = QProgressDialog("正在进行诊断...", "取消", 0, 100, self)
        progress.setWindowTitle("诊断中")
        progress.setModal(True)
        progress.setValue(10)
        progress.show()
        self.repaint()

        results = {
            "missing_dependencies": [],
            "missing_mods": [],
            "duplicates": [],
            "load_order_issues": [],
            "warnings": [],
        }

        progress.setValue(30)
        self.repaint()

        results["missing_dependencies"] = self._check_missing_dependencies()

        progress.setValue(50)
        self.repaint()

        results["missing_mods"] = self._check_missing_mods()

        progress.setValue(70)
        self.repaint()

        results["duplicates"] = self._check_duplicates()

        progress.setValue(80)
        self.repaint()

        results["load_order_issues"] = self._validate_load_order()

        progress.setValue(90)
        self.repaint()

        validation = self._validate_mod_dependencies()
        results["warnings"] = validation.get("warnings", [])

        progress.setValue(100)
        progress.close()

        self._show_diagnostic_results(results)

    def _check_missing_dependencies(self) -> list[str]:
        """检查缺失的 Mod 依赖。"""
        validation = self._validate_mod_dependencies()
        missing = list(validation.get("issues", []))

        return missing

    def _check_missing_mods(self) -> list[str]:
        """检查引用缺失文件的 Mod。"""
        missing = []
        for mod in self.applied_mods:
            mod_path = Path(mod.get("path", ""))
            if not mod_path.exists():
                missing.append(f"Mod '{mod.get('name', 'Unknown')}' 的路径不存在")

        return missing

    def _check_duplicates(self) -> list[str]:
        """检查重复的 Mod ID。"""
        duplicates = []

        seen_ids = {}
        for mod in self.applied_mods:
            mod_id = mod.get("id", "")
            if mod_id in seen_ids:
                duplicates.append(
                    f"Mod ID '{mod_id}' 出现多次",
                )
            else:
                seen_ids[mod_id] = mod

        return duplicates

    def _show_diagnostic_results(self, results: dict) -> None:
        """向用户显示诊断结果。"""
        total_issues = (
            len(results["missing_dependencies"])
            + len(results["missing_mods"])
            + len(results["duplicates"])
            + len(results["load_order_issues"])
        )

        if total_issues == 0:
            QMessageBox.information(
                self,
                "诊断结果",
                "✅ 没有发现任何问题！\n\n您的Mod配置看起来一切正常。",
            )
            self.status_label.setText("诊断完成：未发现问题")
            return

        message = f"⚠️ 发现 {total_issues} 个问题：\n\n"

        if results["missing_dependencies"]:
            message += "❌ 缺失依赖：\n"
            for issue in results["missing_dependencies"]:
                message += f"  • {issue}\n"
            message += "\n"

        if results["missing_mods"]:
            message += "❌ 缺失Mod文件：\n"
            for issue in results["missing_mods"]:
                message += f"  • {issue}\n"
            message += "\n"

        if results["duplicates"]:
            message += "⚠️ 重复Mod：\n"
            for issue in results["duplicates"]:
                message += f"  • {issue}\n"
            message += "\n"

        if results["load_order_issues"]:
            message += "⚠️ 加载顺序问题：\n"
            for issue in results["load_order_issues"]:
                message += f"  • {issue}\n"
            message += "\n"

        if results["warnings"]:
            message += "💡 警告：\n"
            for warning in results["warnings"]:
                message += f"  • {warning}\n"
            message += "\n"

        message += "\n建议：修复这些问题以确保游戏正常运行。"

        QMessageBox.warning(
            self,
            "诊断结果",
            message,
        )
        self.status_label.setText(f"诊断完成：发现 {total_issues} 个问题")

    def _save_state(self) -> None:
        """保存当前状态到撤销栈。"""
        state = {
            "unapplied_mods": [mod.copy() for mod in self.unapplied_mods],
            "applied_mods": [mod.copy() for mod in self.applied_mods],
        }

        self.undo_stack.append(state)

        if len(self.undo_stack) > self.MAX_UNDO_STACK_SIZE:
            self.undo_stack.pop(0)

        self.redo_stack.clear()

        self._update_undo_redo_buttons()

    def _restore_state(self, state: dict) -> None:
        """从撤销/重做栈恢复状态。"""
        self.unapplied_mods = state.get("unapplied_mods", [])
        self.applied_mods = state.get("applied_mods", [])

        self.on_search_changed()
        self._update_mod_count()

    def _update_undo_redo_buttons(self) -> None:
        """更新撤销/重做按钮状态。"""
        self.btn_undo.setEnabled(len(self.undo_stack) > 1)
        self.btn_redo.setEnabled(len(self.redo_stack) > 0)

    def on_undo(self) -> None:
        """撤销上一个操作。"""
        if len(self.undo_stack) <= 1:
            return

        current_state = self.undo_stack.pop()
        self.redo_stack.append(current_state)

        previous_state = self.undo_stack[-1]
        self._restore_state(previous_state)

        self.is_modified = True
        self._update_undo_redo_buttons()
        self.status_label.setText("已撤销")

    def on_redo(self) -> None:
        """重做上一个撤销的操作。"""
        if not self.redo_stack:
            return

        state = self.redo_stack.pop()

        self.undo_stack.append(state)

        self._restore_state(state)

        self.is_modified = True
        self._update_undo_redo_buttons()
        self.status_label.setText("已重做")

    def on_open_steam(self) -> None:
        """打开 Mod 的 Steam 创意工坊页面。"""
        mod = self._get_selected_mod()
        if not mod:
            return

        mod_path = Path(mod.get("path", ""))
        steam_url = self._get_steam_workshop_url(mod_path)

        if not steam_url:
            QMessageBox.information(
                self,
                "提示",
                "无法找到此Mod的Steam创意工坊链接。\n此Mod可能不是从Steam创意工坊下载的。",
            )
            return

        try:
            from bitool.gui.compat import QDesktopServices, QUrl

            QDesktopServices.openUrl(QUrl(steam_url))
            self.status_label.setText("已在浏览器中打开Steam页面")
        except (OSError, RuntimeError) as e:
            logger.warning(f"Failed to open Steam URL: {e}")
            QMessageBox.warning(self, "警告", "无法打开Steam链接")

    def _get_steam_workshop_url(self, mod_path: Path) -> str | None:
        """通过检查 Mod 文件夹结构获取 Steam 创意工坊 URL。"""
        if not mod_path or not mod_path.exists():
            return None

        workshop_path = self._find_workshop_directory()
        if not workshop_path:
            return None

        try:
            mod_path.resolve().relative_to(workshop_path.resolve())
            url = self._get_steam_id_from_about(mod_path)
            if url:
                return url
        except ValueError:
            pass

        return None

    def _find_workshop_directory(self) -> Path | None:
        """查找 RimWorld 的 Steam 创意工坊目录。"""
        import platform

        system = platform.system()

        if system == "Windows":
            possible_paths = [
                Path.home() / "Steam" / "steamapps" / "workshop" / "content" / "294100",
                Path("C:/Program Files (x86)/Steam/steamapps/workshop/content/294100"),
                Path("C:/Program Files/Steam/steamapps/workshop/content/294100"),
            ]
        elif system == "Darwin":
            possible_paths = [
                Path.home()
                / "Library"
                / "Application Support"
                / "Steam"
                / "steamapps"
                / "workshop"
                / "content"
                / "294100",
            ]
        else:
            possible_paths = [
                Path.home() / ".steam" / "steam" / "steamapps" / "workshop" / "content" / "294100",
                Path.home() / ".local" / "share" / "Steam" / "steamapps" / "workshop" / "content" / "294100",
            ]

        for path in possible_paths:
            if path.exists():
                return path

        return None

    def _get_steam_id_from_about(self, mod_path: Path) -> str | None:
        """从 About.xml 中提取 Steam publishedFileId。"""
        about_file = mod_path / "About" / "About.xml"
        if not about_file.exists():
            about_file = mod_path / "About.xml"

        if not about_file.exists():
            return None

        try:
            root = self._parse_about_xml(about_file)
            if root is None:
                return None

            published_id = root.find(".//publishedFileId")
            if published_id is not None and published_id.text:
                return f"https://steamcommunity.com/sharedfiles/filedetails/?id={published_id.text}"

            steam_url = root.find(".//SteamURL")
            if steam_url is not None and steam_url.text:
                return steam_url.text

        except (OSError, ValueError) as e:
            logger.warning(f"Failed to read Steam ID from {about_file}: {e}")

        return None

    def _parse_about_xml(self, file_path: Path):
        """安全地解析 About.xml。"""
        try:
            from defusedxml.ElementTree import parse

            tree = parse(file_path)
            return tree.getroot()
        except ImportError:
            try:
                from lxml import etree

                parser = etree.XMLParser(resolve_entities=False)
                tree = etree.parse(file_path, parser)
                return tree.getroot()
            except ImportError:
                from xml.etree import ElementTree as ET
                from xml.etree.ElementTree import XMLParser

                parser = XMLParser(resolve_entities=False)
                tree = ET.parse(file_path, parser)
                return tree.getroot()
        return None

    def on_view_dependencies(self) -> None:
        """显示选中 Mod 的依赖信息。"""
        mod = self._get_selected_mod()
        if not mod:
            return

        mod_id = mod.get("id", "")
        mod_name = mod.get("name", mod_id)
        mod_path = Path(mod.get("path", ""))

        deps = self._get_mod_dependencies_from_xml(mod_path / "About" / "About.xml")
        if not deps:
            deps = self._get_mod_dependencies_from_xml(mod_path / "About.xml")

        if not deps:
            QMessageBox.information(
                self,
                "依赖信息",
                f"Mod '{mod_name}' 没有声明任何依赖。",
            )
            return

        loaded_deps = []
        missing_deps = []
        available_mods = {m.get("id", "").lower() for m in self.all_mods}

        for dep in deps:
            if dep.lower() in available_mods:
                loaded_deps.append(dep)
            else:
                missing_deps.append(dep)

        message = f"Mod '{mod_name}' 的依赖：\n\n"

        if loaded_deps:
            message += f"✅ 已激活的依赖 ({len(loaded_deps)}):\n"
            for dep in loaded_deps:
                message += f"  • {dep}\n"
            message += "\n"

        if missing_deps:
            message += f"❌ 未找到的依赖 ({len(missing_deps)}):\n"
            for dep in missing_deps:
                message += f"  • {dep}\n"

        QMessageBox.information(self, "依赖信息", message)

    def on_theme_changed(self, theme_name: str) -> None:
        """处理主题选择变化。"""
        apply_theme(self, theme_name)
        logger.info(f"Theme changed to: {theme_name}")

    def on_language_changed(self, lang_code: str) -> None:
        """处理语言选择变化。"""
        for lang in Language:
            if lang.value == lang_code:
                translator.set_language(lang)
                break

        self._update_ui_texts()
        logger.info(f"Language changed to: {lang_code}")

    def _update_ui_texts(self) -> None:
        """更新所有 UI 文本到当前语言。"""
        self.btn_load_mods.setText(translator.tr("load_mods"))
        self.btn_import.setText(translator.tr("import_list"))
        self.btn_export.setText(translator.tr("export_list"))
        self.btn_undo.setText(translator.tr("undo"))
        self.btn_redo.setText(translator.tr("redo"))
        self.btn_save_preset.setText(translator.tr("save_preset"))
        self.btn_load_preset.setText(translator.tr("load_preset"))
        self.btn_diagnose.setText(translator.tr("diagnose"))
        self.btn_apply.setText(translator.tr("apply_changes"))
        self.btn_save.setText(translator.tr("save"))

        self.theme_label.setText(translator.tr("theme"))
        self.lang_label.setText(translator.tr("language"))
        self.left_label.setText(translator.tr("unapplied_mods"))
        self.right_label.setText(translator.tr("applied_mods"))

        self.search_left.setPlaceholderText(translator.tr("search"))
        self.search_right.setPlaceholderText(translator.tr("search"))

        self.details_label.setText(translator.tr("mod_info"))
        self.info_group.setTitle(translator.tr("name"))
        self.desc_group.setTitle(translator.tr("description"))
        self.author_caption.setText(translator.tr("author") + ":")
        self.version_caption.setText(translator.tr("version") + ":")
        self.id_caption.setText(translator.tr("package_id") + ":")
        self.support_caption.setText(translator.tr("support") + ":")

        self.btn_open_url.setText(translator.tr("open_url"))
        self.btn_open_steam.setText(translator.tr("open_steam"))
        self.btn_view_dependencies.setText(translator.tr("view_dependencies"))

        self.status_label.setText(translator.tr("ready_status"))
        self._update_mod_count()
