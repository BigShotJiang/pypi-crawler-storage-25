"""用于扫描 RimWorld Mod 的后台线程。"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path
from typing import TYPE_CHECKING

from bitool.core import logger
from bitool.gui.compat import QThread, Signal

if TYPE_CHECKING:
    from ..widgets.rimmod import RimMod


class ScanThread(QThread):
    """用于在后台扫描 Mod 文件夹的线程。"""

    signal_scan_started = Signal()
    signal_scan_progress = Signal(int, int)
    signal_scan_finished = Signal(list)
    signal_scan_error = Signal(str)

    def __init__(self, parent: RimMod, mod_folder: Path) -> None:
        """初始化扫描线程。

        Args:
            parent: 父窗口组件
            mod_folder: 要扫描的 Mod 文件夹路径
        """
        super().__init__(parent)
        self.mod_folder = mod_folder
        self._is_running = True

    def run(self) -> None:
        """运行扫描线程。"""
        self.signal_scan_started.emit()
        logger.info(f"Starting mod scan: {self.mod_folder}")

        try:
            mods = self._scan_folder()
            if self._is_running:
                self.signal_scan_finished.emit(mods)
            else:
                logger.info("Scan cancelled")
        except Exception as e:  # noqa: BLE001
            logger.error(f"Scan error: {e}", exc_info=True)
            if self._is_running:
                self.signal_scan_error.emit(str(e))

    def _scan_folder(self) -> list[dict]:
        """扫描 Mod 文件夹并返回 Mod 信息。

        Returns:
            Mod 字典列表
        """
        mods = []

        if not self.mod_folder.exists():
            return mods

        folders = [f for f in self.mod_folder.iterdir() if f.is_dir()]
        total = len(folders)

        for i, folder in enumerate(folders):
            if not self._is_running:
                break

            mod_info = self._get_mod_info(folder)
            if mod_info:
                mods.append(mod_info)

            self.signal_scan_progress.emit(i + 1, total)

        return mods

    def _get_mod_info(self, mod_path: Path) -> dict | None:
        """从 About.xml 获取 Mod 信息。

        Args:
            mod_path: Mod 文件夹路径

        Returns:
            包含 Mod 信息的字典，如果失败则返回 None
        """
        about_file = mod_path / "About" / "About.xml"
        if not about_file.exists():
            about_file = mod_path / "About.xml"

        if not about_file.exists():
            return {
                "id": mod_path.name,
                "name": mod_path.name,
                "author": "Unknown",
                "path": str(mod_path),
                "enabled": True,
            }

        try:
            tree = ET.parse(about_file)
            root = tree.getroot()

            mod_name = root.findtext("name") or mod_path.name
            author = root.findtext("author") or "Unknown"
            package_id = root.findtext("packageId") or mod_path.name

            return {
                "id": package_id,
                "name": mod_name,
                "author": author,
                "path": str(mod_path),
                "enabled": True,
            }
        except ET.ParseError as e:
            logger.warning(f"Failed to parse About.xml for {mod_path.name}: {e}")
            return {
                "id": mod_path.name,
                "name": mod_path.name,
                "author": "Unknown",
                "path": str(mod_path),
                "enabled": True,
            }

    def stop(self) -> None:
        """停止扫描线程。"""
        self._is_running = False
