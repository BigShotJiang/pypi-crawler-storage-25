"""pdfcrypt模块测试套件。"""
