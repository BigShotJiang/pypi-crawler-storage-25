"""命令行入口.

用法:
    pyprofiler run script.py [args...]
    pyprofiler run -m module [args...]
    pyprofiler load file.prof
"""

from __future__ import annotations

import argparse
import logging
import sys
import webbrowser
from pathlib import Path

from .analyzer import AnalyzeConfig, ProfileAnalyzer
from .core import ProfileLoader, ProfileRunner
from .models import ProfilerConfig
from .reporter import ReportGenerator


def _add_common_args(parser: argparse.ArgumentParser) -> None:
    """向解析器添加公共可选参数."""
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=Path("profile_report.html"),
        help="输出 HTML 文件路径 (默认: profile_report.html)",
    )
    parser.add_argument(
        "--no-open",
        action="store_true",
        dest="no_open",
        help="生成后不自动打开浏览器",
    )
    parser.add_argument(
        "--top",
        type=int,
        default=50,
        dest="top_n",
        help="函数排行表显示前 N 个 (默认: 50)",
    )
    parser.add_argument(
        "--sort-by",
        choices=["tottime", "cumtime", "calls"],
        default="tottime",
        help="默认排序字段 (默认: tottime)",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="启用调试日志",
    )


def _build_parser() -> argparse.ArgumentParser:
    """构建命令行参数解析器.

    Returns
    -------
        argparse.ArgumentParser: 命令行参数解析器
    """
    parser = argparse.ArgumentParser(
        prog="pyprofiler",
        description="非侵入式 Python 代码性能分析工具, 生成 HTML 报告",
    )
    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version="%(prog)s 0.1.0",
    )

    subparsers = parser.add_subparsers(dest="command", help="子命令")

    # run 子命令
    run_parser = subparsers.add_parser(
        "run",
        help="运行并分析 Python 脚本/模块",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  pyprof run script.py                  # 分析简单脚本
  pyprof run script.py -- arg1 arg2     # 传递参数给脚本
  pyprof run script.py -- --level 4     # 传递带选项的参数
  pyprof run -m module.name -- args...  # 分析模块
  pyprof run --no-open script.py -- -h  # pyprof 选项在前""",
    )
    run_parser.add_argument(
        "script",
        nargs="?",
        type=Path,
        default=None,
        help="要分析的 Python 脚本路径",
    )
    run_parser.add_argument(
        "-m",
        "--module",
        type=str,
        default=None,
        dest="module",
        help="以模块方式运行 (类似 python -m)",
    )
    _add_common_args(run_parser)
    run_parser.add_argument(
        "script_args",
        nargs="*",
        default=[],
        help="传递给目标脚本/模块的参数 (使用 -- 分隔)",
    )

    # load 子命令
    load_parser = subparsers.add_parser("load", help="加载已有的 .prof/.pstats 文件生成报告")
    load_parser.add_argument(
        "profile_file",
        type=Path,
        help=".prof 或 .pstats 文件路径",
    )
    _add_common_args(load_parser)

    return parser


def _parse_args(argv: list[str] | None = None) -> ProfilerConfig:
    """解析命令行参数并返回配置.

    Parameters
    ----------
    argv : list[str] | None
        命令行参数列表, None 时使用 sys.argv

    Returns
    -------
    ProfilerConfig
        解析后的配置对象
    """
    parser = _build_parser()

    # 处理 -- 分隔符，将后面的参数传递给目标脚本
    if argv is None:
        argv = sys.argv[1:]  # 移除程序名

    # 查找 -- 分隔符
    script_args = []
    if "--" in argv:
        sep_index = argv.index("--")
        script_args = argv[sep_index + 1 :]
        argv = argv[:sep_index]

    args = parser.parse_args(argv)

    # 合并显式指定的 script_args
    if hasattr(args, "script_args") and args.script_args:
        script_args = args.script_args + script_args

    # 将解析后的 script_args 存回 args
    args.script_args = script_args

    if not args.command:
        parser.print_help()
        sys.exit(1)

    if args.debug:
        logging.basicConfig(level=logging.DEBUG, format="%(levelname)s: %(message)s")
    else:
        logging.basicConfig(level=logging.INFO, format="%(message)s")

    open_browser = not args.no_open

    if args.command == "run":
        # 手动验证 script 和 module 必须选一个且只能选一个
        # 注意: 当使用 -m 时, script 可能会吃到后面的参数(argparse 行为), 所以需要特殊处理
        if args.module is not None:
            # 使用模块模式, 忽略 script 的值(可能是误解析的)
            args.script = None
        elif args.script is None:
            parser.error("one of script or -m/--module is required")

        return ProfilerConfig(
            mode="run",
            script=args.script,
            module=args.module,
            script_args=args.script_args or [],
            output=args.output,
            open_browser=open_browser,
            top_n=args.top_n,
            sort_by=args.sort_by,
        )

    # load
    return ProfilerConfig(
        mode="load",
        profile_file=args.profile_file,
        output=args.output,
        open_browser=open_browser,
        top_n=args.top_n,
        sort_by=args.sort_by,
    )


def main(argv: list[str] | None = None) -> None:
    """CLI 主入口.

    Parameters
    ----------
    argv : list[str] | None
        命令行参数列表
    """
    config = _parse_args(argv)

    # 收集性能数据
    print("正在收集性能数据...", flush=True)  # noqa: T201
    if config.mode == "run":
        if config.module:
            target_name = f"-m {config.module}"
            stats = ProfileRunner.run_module(config.module, config.script_args)
        elif config.script:
            target_name = str(config.script)
            stats = ProfileRunner.run_script(config.script, config.script_args)
        else:
            print("错误: 必须指定脚本路径或 -m 模块名", file=sys.stderr)  # noqa: T201
            sys.exit(1)
    elif config.mode == "load":
        if not config.profile_file:
            print("错误: 必须指定 .prof/.pstats 文件路径", file=sys.stderr)  # noqa: T201
            sys.exit(1)
        target_name = str(config.profile_file)
        stats = ProfileLoader.load(config.profile_file)
    else:
        sys.exit(1)

    # 分析数据
    print("正在分析性能数据...", flush=True)  # noqa: T201
    analyze_config = AnalyzeConfig(
        top_n=config.top_n,
        sort_by=config.sort_by,
        target_name=target_name,
    )
    report = ProfileAnalyzer.analyze(stats, analyze_config)

    # 生成报告
    print("正在生成 HTML 报告...", flush=True)  # noqa: T201
    generator = ReportGenerator()
    output_path = generator.generate(report, config.output.resolve(), top_n=config.top_n)
    print(f"报告已生成: {output_path}", flush=True)  # noqa: T201

    # 默认自动打开浏览器
    if config.open_browser:
        print("正在打开浏览器...", flush=True)  # noqa: T201
        webbrowser.open(output_path.as_uri())


if __name__ == "__main__":
    main()
