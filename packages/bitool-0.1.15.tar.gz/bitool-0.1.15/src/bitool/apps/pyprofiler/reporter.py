"""Jinja2 HTML 报告生成器."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

from jinja2 import Environment, FileSystemLoader

from .models import FlameNode, FunctionStat, ModuleStat, ProfileReport

_TEMPLATES_DIR = Path(__file__).parent / "templates"

# 延迟导入避免循环
_classify_origin = None


def _get_classify_origin() -> Callable[[str], str]:
    """获取来源分类函数.

    Returns
    -------
    Callable[[str], str]
        来源分类函数
    """
    global _classify_origin
    if _classify_origin is None:
        from .analyzer import _classify_origin as _co

        _classify_origin = _co
    return _classify_origin


def _origin_of(filename: str) -> str:
    """Jinja2 过滤器: 根据文件路径返回来源分类.

    Parameters
    ----------
    filename : str
        文件路径

    Returns
    -------
    str
        来源分类
    """
    return _get_classify_origin()(filename)


MS = 1e-3
US = 1e-6


def _format_time(seconds: float) -> str:
    """将秒数格式化为人可读的时间字符串.

    Parameters
    ----------
    seconds : float
        秒数

    Returns
    -------
    str
        人可读的时间字符串
    """
    if seconds <= 0:
        return "0 s"
    if seconds >= 1:
        return f"{seconds:.3f} s"
    if seconds >= MS:
        return f"{seconds * 1e3:.3f} ms"
    if seconds >= US:
        return f"{seconds * 1e6:.3f} \u03bcs"
    return f"{seconds * 1e9:.3f} ns"


def _format_calls(ncalls: str) -> str:
    """格式化调用次数.

    Parameters
    ----------
    ncalls : str
        调用次数, 格式为 "ncalls: 100" 或 "ncalls: 100/1000"

    Returns
    -------
    str
        格式化后的调用次数
    """
    if "/" in ncalls:
        parts = ncalls.split("/")
        return f"{int(parts[0]):,}/{int(parts[1]):,}"
    return f"{int(ncalls):,}"


def _truncate_path(path: str, max_len: int = 50) -> str:
    """截断过长的文件路径.

    Parameters
    ----------
    path : str
        文件路径
    max_len : int
        最大长度

    Returns
    -------
    str
        截断后的文件路径
    """
    if len(path) <= max_len:
        return path
    return "..." + path[-(max_len - 3) :]


def _func_id(filename: str, lineno: int, func_name: str) -> str:
    """生成函数的唯一 HTML id.

    Parameters
    ----------
    filename : str
        文件名
    lineno : int
        行号
    func_name : str
        函数名

    Returns
    -------
    str
        唯一的 HTML id
    """
    raw = f"{filename}_{lineno}_{func_name}"
    safe = "".join(c if c.isalnum() or c == "_" else "_" for c in raw)
    return f"fn_{safe}"


# ---------------------------------------------------------------------------
# JSON 序列化
# ---------------------------------------------------------------------------


def _flame_node_to_dict(node: FlameNode) -> dict[str, object]:
    """将 FlameNode 树转为 JSON 可序列化的字典.

    Returns
    -------
        dict: JSON 可序列化的字典
    """
    return {
        "n": node.name,
        "f": Path(node.filename).name if not node.filename.startswith(("<", "{", "~")) else node.filename,
        "fp": node.filename,
        "l": node.lineno,
        "v": round(node.value, 6),
        "s": round(node.self_time, 6),
        "o": node.origin,
        "c": [_flame_node_to_dict(c) for c in node.children],
    }


def _func_stat_to_dict(fs: FunctionStat) -> dict[str, object]:
    """将 FunctionStat 转为 JSON 字典用于调用树和跳转.

    Returns
    -------
        dict: JSON 可序列化的字典
    """
    return {
        "id": fs.func_id,
        "filename": fs.filename,
        "lineno": fs.lineno,
        "func_name": fs.func_name,
        "full_name": fs.full_name,
        "display_name": fs.display_name,
        "ncalls": fs.ncalls,
        "tottime": round(fs.tottime, 6),
        "cumtime": round(fs.cumtime, 6),
        "origin": fs.origin,
        "callees": [
            {
                "func_name": c.func_name,
                "filename": c.filename,
                "lineno": c.lineno,
                "ncalls": c.ncalls,
                "tottime": round(c.tottime, 6),
                "cumtime": round(c.cumtime, 6),
            }
            for c in fs.callees
        ],
        "callers": [
            {
                "func_name": c.func_name,
                "filename": c.filename,
                "lineno": c.lineno,
                "ncalls": c.ncalls,
                "tottime": round(c.tottime, 6),
                "cumtime": round(c.cumtime, 6),
            }
            for c in fs.callers
        ],
    }


def _module_stat_to_dict(ms: ModuleStat) -> dict[str, object]:
    """将 ModuleStat 转为 JSON 字典.

    Returns
    -------
        dict: JSON 可序列化的字典
    """
    return {
        "filename": ms.filename,
        "display_name": ms.display_name,
        "total_tottime": round(ms.total_tottime, 6),
        "total_cumtime": round(ms.total_cumtime, 6),
        "call_count": ms.call_count,
        "func_count": ms.func_count,
        "origin": ms.origin,
        "functions": [
            {
                "func_name": f.func_name,
                "filename": f.filename,
                "lineno": f.lineno,
                "tottime": round(f.tottime, 6),
                "cumtime": round(f.cumtime, 6),
                "ncalls": f.ncalls,
                "id": f.func_id,
            }
            for f in ms.functions[:30]  # 每个模块最多 30 个函数
        ],
    }


class ReportGenerator:
    """HTML 报告生成器."""

    def __init__(self) -> None:
        self._env = Environment(
            loader=FileSystemLoader(str(_TEMPLATES_DIR)),
            autoescape=True,
        )
        self._env.filters["format_time"] = _format_time
        self._env.filters["format_calls"] = _format_calls
        self._env.filters["truncate_path"] = _truncate_path
        self._env.filters["origin_of"] = _origin_of
        self._env.globals["format_time"] = _format_time  # type: ignore[index]
        self._env.globals["func_id"] = _func_id  # type: ignore[index]

    def generate(self, report: ProfileReport, output: Path, top_n: int = 50) -> Path:
        """生成 HTML 报告文件.

        Parameters
        ----------
        report : ProfileReport
            性能分析报告数据
        output : Path
            输出文件路径
        top_n : int
            排行榜显示数量

        Returns
        -------
        Path
            输出文件路径
        """
        # 预先序列化为 JSON
        flame_json = json.dumps(
            [_flame_node_to_dict(r) for r in report.flame_roots],
            ensure_ascii=False,
        )
        call_graph_json = json.dumps(
            [_func_stat_to_dict(fs) for fs in report.function_stats],
            ensure_ascii=False,
        )
        module_json = json.dumps(
            [_module_stat_to_dict(ms) for ms in report.module_stats],
            ensure_ascii=False,
        )

        template = self._env.get_template("report.html.j2")
        html = template.render(
            report=report,
            config_top_n=top_n,
            flame_json=flame_json,
            call_graph_json=call_graph_json,
            module_json=module_json,
        )
        output = output.resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(html, encoding="utf-8")
        return output.resolve()
