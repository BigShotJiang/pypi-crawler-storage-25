"""GUI tests for alarmclock module using pytest-qt."""

from __future__ import annotations

from typing import TYPE_CHECKING

from bitool.apps.alarmclock.config import conf
from bitool.apps.alarmclock.widgets.alarmclock import AlarmClock
from bitool.apps.alarmclock.widgets.reminder import Reminder
from bitool.gui.compat import QTime

if TYPE_CHECKING:
    from pytestqt.qtbot import QtBot


class TestAlarmClockGUI:
    """Tests for main AlarmClock GUI."""

    def test_alarm_clock_initialization(self, qtbot: QtBot) -> None:
        """Test AlarmClock main window initialization."""
        clock = AlarmClock()
        qtbot.addWidget(clock)

        # Test window properties
        assert conf.ALARM_CLOCK_TITLE in clock.windowTitle()

    def test_alarm_clock_widgets_exist(self, qtbot: QtBot) -> None:
        """Test that all required widgets are created."""
        clock = AlarmClock()
        qtbot.addWidget(clock)

        # 验证主要组件存在
        assert hasattr(clock, "clock_label")
        assert hasattr(clock, "alarm_time_spinbox")
        assert hasattr(clock, "set_button")
        assert hasattr(clock, "status_label")
        assert hasattr(clock, "repeat_checkbox")
        assert hasattr(clock, "theme_button")

    def test_clock_label_exists(self, qtbot: QtBot) -> None:
        """Test that clock label widget exists."""
        clock = AlarmClock()
        qtbot.addWidget(clock)

        # Look for clock_label (QLabel used as digital clock)
        assert hasattr(clock, "clock_label")
        assert clock.clock_label is not None

    def test_clock_label_initial_style(self, qtbot: QtBot) -> None:
        """Test clock label has correct initial styling."""
        clock = AlarmClock()
        qtbot.addWidget(clock)

        style = clock.clock_label.styleSheet()
        assert "background-color: black" in style
        assert "color: white" in style
        assert "border: 2px dashed" in style

    def test_clock_displays_time(self, qtbot: QtBot) -> None:
        """Test that clock label displays time."""
        clock = AlarmClock()
        qtbot.addWidget(clock)

        time_text = clock.clock_label.text()
        # 时间格式应为 HH:MM:SS
        assert len(time_text) == 8
        assert time_text[2] == ":"
        assert time_text[5] == ":"

    def test_alarm_time_spinbox_default(self, qtbot: QtBot) -> None:
        """Test alarm time spinbox has valid default time."""
        clock = AlarmClock()
        qtbot.addWidget(clock)

        alarm_time = clock.alarm_time_spinbox.time()
        # 默认时间应该是当前时间加上第一个延时步长
        assert alarm_time.hour() >= 0 and alarm_time.minute() >= 0

    def test_set_button_initial_text(self, qtbot: QtBot) -> None:
        """Test set button shows correct initial text."""
        clock = AlarmClock()
        qtbot.addWidget(clock)

        assert clock.set_button.text() == "设置闹钟"

    def test_status_label_initial_text(self, qtbot: QtBot) -> None:
        """Test status label shows initial status."""
        clock = AlarmClock()
        qtbot.addWidget(clock)

        # 状态标签初始应有文本
        assert clock.status_label.text() is not None


class TestAlarmClockFunctionality:
    """Tests for AlarmClock functionality."""

    def test_toggle_alarm_on(self, qtbot: QtBot) -> None:
        """Test turning on the alarm."""
        clock = AlarmClock()
        qtbot.addWidget(clock)

        # 设置闹钟
        clock.on_toggle_alarm()

        assert clock.alarm_set is True
        assert clock.set_button.text() == "取消闹钟"
        assert "闹钟已设置" in clock.status_label.text()

    def test_toggle_alarm_off(self, qtbot: QtBot) -> None:
        """Test turning off the alarm."""
        clock = AlarmClock()
        qtbot.addWidget(clock)

        # 先开启再关闭
        clock.on_toggle_alarm()
        clock.on_toggle_alarm()

        assert clock.alarm_set is False
        assert clock.set_button.text() == "设置闹钟"
        assert "闹钟已取消" in clock.status_label.text()

    def test_set_delay(self, qtbot: QtBot) -> None:
        """Test setting delay for alarm."""
        clock = AlarmClock()
        qtbot.addWidget(clock)

        original_time = clock.alarm_time_spinbox.time()
        # 设置 5 分钟延时
        clock.set_delay(5)
        new_time = clock.alarm_time_spinbox.time()

        # 新时间应该比原时间多 5 分钟(300秒)
        secs_diff = original_time.secsTo(new_time)
        assert secs_diff == 300

    def test_reset_alarm_time(self, qtbot: QtBot) -> None:
        """Test resetting alarm time to current time."""
        clock = AlarmClock()
        qtbot.addWidget(clock)

        # 设置一个未来时间
        clock.set_delay(60)
        clock.reset_alarm_time()

        # 重置后应该接近当前时间
        reset_time = clock.alarm_time_spinbox.time()
        current_time = QTime.currentTime()
        # 允许 2 秒误差
        assert abs(reset_time.secsTo(current_time)) <= 2

    def test_alarm_timer_starts_when_set(self, qtbot: QtBot) -> None:
        """Test that alarm timer starts when alarm is set."""
        clock = AlarmClock()
        qtbot.addWidget(clock)

        assert not clock.alarm_timer.isActive()
        clock.on_toggle_alarm()
        assert clock.alarm_timer.isActive()

    def test_alarm_timer_stops_when_cancelled(self, qtbot: QtBot) -> None:
        """Test that alarm timer stops when alarm is cancelled."""
        clock = AlarmClock()
        qtbot.addWidget(clock)

        clock.on_toggle_alarm()
        assert clock.alarm_timer.isActive()

        clock.on_toggle_alarm()
        assert not clock.alarm_timer.isActive()

    def test_delay_buttons_created(self, qtbot: QtBot) -> None:
        """Test that delay buttons are created for each step."""
        clock = AlarmClock()
        qtbot.addWidget(clock)

        # 延时按钮应该已经添加到布局中
        # 通过检查 verticalLayout 的子项来验证
        layout_count = clock.verticalLayout.count()
        # 至少应该有原始组件加延时按钮布局
        assert layout_count >= 3


class TestReminderDialog:
    """Tests for Reminder dialog."""

    def test_reminder_initialization(self, qtbot: QtBot) -> None:
        """Test Reminder dialog initialization."""
        reminder = Reminder()
        qtbot.addWidget(reminder)

        assert reminder.windowTitle() == conf.BLINK_TITLE
        assert reminder.isModal()

    def test_reminder_ui_components(self, qtbot: QtBot) -> None:
        """Test that Reminder has required UI components."""
        reminder = Reminder()
        qtbot.addWidget(reminder)

        # 应该有 blink_timer
        assert hasattr(reminder, "blink_timer")
        assert reminder.blink_timer is not None

    def test_reminder_blink_timer_active(self, qtbot: QtBot) -> None:
        """Test that blink timer starts on initialization."""
        reminder = Reminder()
        qtbot.addWidget(reminder)

        assert reminder.blink_timer.isActive()

    def test_reminder_close_alarm(self, qtbot: QtBot) -> None:
        """Test closing the reminder dialog."""
        reminder = Reminder()
        qtbot.addWidget(reminder)

        assert reminder.blink_timer.isActive()
        reminder.close_alarm()

        # 关闭后定时器应停止
        assert not reminder.blink_timer.isActive()

    def test_reminder_stop_blinking(self, qtbot: QtBot) -> None:
        """Test stopping blinking effect."""
        reminder = Reminder()
        qtbot.addWidget(reminder)

        reminder.stop_blinking()
        assert not reminder.blink_timer.isActive()
        assert abs(reminder.windowOpacity() - 1.0) < 0.01

    def test_reminder_update_blink(self, qtbot: QtBot) -> None:
        """Test blink update changes background color."""
        reminder = Reminder()
        qtbot.addWidget(reminder)

        original_color = reminder.bg_color
        reminder.update_blink()

        # 颜色应该改变
        assert reminder.bg_color != original_color
        assert reminder.bg_color in conf.BLINK_BG_COLORS


class TestAlarmClockIntegration:
    """Integration tests for AlarmClock."""

    def test_full_alarm_cycle(self, qtbot: QtBot) -> None:
        """Test complete alarm set and cancel cycle."""
        clock = AlarmClock()
        qtbot.addWidget(clock)

        # 初始状态
        assert not clock.alarm_set
        assert not clock.alarm_timer.isActive()

        # 设置闹钟
        clock.on_toggle_alarm()
        assert clock.alarm_set
        assert clock.alarm_timer.isActive()

        # 取消闹钟
        clock.on_toggle_alarm()
        assert not clock.alarm_set
        assert not clock.alarm_timer.isActive()

    def test_alarm_with_delay(self, qtbot: QtBot) -> None:
        """Test alarm with delay setting."""
        clock = AlarmClock()
        qtbot.addWidget(clock)

        # 设置延时
        clock.set_delay(10)

        # 设置闹钟
        clock.on_toggle_alarm()
        assert clock.alarm_set

        # 验证闹钟时间已更新
        alarm_time = clock.alarm_time_spinbox.time()
        assert alarm_time.hour() >= 0 and alarm_time.minute() >= 0

    def test_theme_button_exists(self, qtbot: QtBot) -> None:
        """Test theme button is present and functional."""
        clock = AlarmClock()
        qtbot.addWidget(clock)

        assert hasattr(clock, "theme_button")
        assert clock.theme_button.isEnabled()

    def test_repeat_checkbox_exists(self, qtbot: QtBot) -> None:
        """Test repeat checkbox is present."""
        clock = AlarmClock()
        qtbot.addWidget(clock)

        assert hasattr(clock, "repeat_checkbox")
        # 复选框初始未选中
        assert not clock.repeat_checkbox.isChecked()
