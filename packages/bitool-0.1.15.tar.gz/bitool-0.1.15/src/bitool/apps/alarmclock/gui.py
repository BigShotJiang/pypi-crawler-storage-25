"""Graphical user interface for alarmclock."""

from __future__ import annotations

import sys

from bitool.gui import load_qrc
from bitool.gui.compat import QApplication

from .widgets.alarmclock import AlarmClock

load_qrc()


def main() -> None:
    """Run entry point for the GUI application."""
    app = QApplication(sys.argv)

    window = AlarmClock()
    window.show()

    sys.exit(app.exec_())
