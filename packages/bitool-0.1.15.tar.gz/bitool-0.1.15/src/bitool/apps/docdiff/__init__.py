"""Docdiff 文档对比模块。"""
