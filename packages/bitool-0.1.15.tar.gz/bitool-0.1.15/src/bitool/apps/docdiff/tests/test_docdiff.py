import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from ..cli import DiffDocCommand


def _is_win32com_available() -> bool:
    """Check if win32com is available."""
    try:
        import win32com.client  # noqa: F401
    except ImportError:
        return False
    else:
        return True


class TestDiffDocCommand:
    """Test DiffDocCommand functionality."""

    def test_command_initialization(self, tmp_path: Path) -> None:
        """Test DiffDocCommand initialization."""
        old_file = tmp_path / "old.docx"
        new_file = tmp_path / "new.docx"
        output_path = tmp_path / "output"

        command = DiffDocCommand(old_file, new_file, output_path)

        assert command.old_doc == old_file
        assert command.new_doc == new_file
        assert command.output_path == output_path

    def test_command_with_nonexistent_files(self, tmp_path: Path) -> None:
        """Test DiffDocCommand with nonexistent files."""
        old_file = tmp_path / "nonexistent_old.docx"
        new_file = tmp_path / "nonexistent_new.docx"

        # Mock platform to bypass Windows-only check
        with patch("bitool.apps.docdiff.cli.platform.system", return_value="Windows"):
            command = DiffDocCommand(old_file, new_file)

            with pytest.raises(FileNotFoundError) as exc_info:
                command.run()

            assert "exist" in str(exc_info.value).lower() or "not found" in str(exc_info.value).lower()

    def test_validate_files_property(self, tmp_path: Path) -> None:
        """Test the validate_files property."""
        old_file = tmp_path / "old.docx"
        new_file = tmp_path / "new.docx"

        # Create the files
        old_file.touch()
        new_file.touch()

        DiffDocCommand(old_file, new_file)

        # Since validate_files is a cached property, we can't easily patch it.
        # Instead, we'll test the underlying logic by checking file extensions
        assert old_file.suffix.lower() in {".doc", ".docx"}
        assert new_file.suffix.lower() in {".doc", ".docx"}
        assert old_file.exists()
        assert new_file.exists()

        # Test with invalid extension
        bad_file = tmp_path / "bad.txt"
        bad_file.touch()

        # Create a new command with the bad file
        _ = DiffDocCommand(bad_file, new_file)
        # We can't easily test the property directly due to frozen dataclass,
        # but we can test the logic
        assert bad_file.suffix.lower() not in {".doc", ".docx"}

    def test_command_missing_win32com(self, tmp_path, caplog) -> None:
        """Test DiffDocCommand when win32com is not available."""
        old_file = tmp_path / "old.docx"
        new_file = tmp_path / "new.docx"

        # Create the files
        old_file.touch()
        new_file.touch()

        # Mock platform and file validation to bypass early checks
        with patch("bitool.apps.docdiff.cli.platform.system", return_value="Windows"), patch.object(
            Path,
            "exists",
            return_value=True,
        ):
            command = DiffDocCommand(old_file, new_file)

            # Temporarily remove win32com from sys.modules if present
            original_win32com = sys.modules.get("win32com")
            if "win32com" in sys.modules:
                del sys.modules["win32com"]

            try:
                # Try to access the word_app property which will trigger win32com import
                with patch.dict("sys.modules", {"win32com.client": None}):
                    _ = command.word_app  # This should trigger the ImportError
            except ImportError:
                pass  # Expected when win32com is not available
            finally:
                # Restore original module if it existed
                if original_win32com is not None:
                    sys.modules["win32com"] = original_win32com

    def test_word_app_property_success(self, tmp_path: Path) -> None:
        """Test word_app property when win32com is available."""
        old_file = tmp_path / "old.docx"
        new_file = tmp_path / "new.docx"

        old_file.touch()
        new_file.touch()

        mock_app = MagicMock()
        mock_gencache = MagicMock()
        mock_gencache.EnsureDispatch.return_value = mock_app
        mock_win32_client = MagicMock()
        mock_win32_client.gencache = mock_gencache
        mock_win32 = MagicMock()
        mock_win32.client = mock_win32_client

        with patch("bitool.apps.docdiff.cli.platform.system", return_value="Windows"), patch.object(
            Path,
            "exists",
            return_value=True,
        ), patch.dict("sys.modules", {"win32com": mock_win32, "win32com.client": mock_win32_client}):
            command = DiffDocCommand(old_file, new_file)
            app = command.word_app

            mock_gencache.EnsureDispatch.assert_called_once_with("Word.Application")
            assert app == mock_app
            assert mock_app.Visible is False
            assert mock_app.DisplayAlerts is False


class TestIntegration:
    """Integration tests for docdiff functionality."""

    def test_command_creation(self, tmp_path: Path) -> None:
        """Test creating and using DiffDocCommand."""
        old_file = tmp_path / "old.docx"
        new_file = tmp_path / "new.docx"
        output_file = tmp_path / "output.docx"

        old_file.touch()
        new_file.touch()

        command = DiffDocCommand(old_file, new_file, output_file)

        assert command.old_doc == old_file
        assert command.new_doc == new_file
        assert command.output_path == output_file
