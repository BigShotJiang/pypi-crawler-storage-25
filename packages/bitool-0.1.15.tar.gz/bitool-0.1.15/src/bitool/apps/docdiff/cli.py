"""Docdiff 文档对比模块。"""

from __future__ import annotations

import argparse
import platform
import subprocess
import time
from dataclasses import dataclass
from functools import cached_property
from pathlib import Path
from typing import Any

from bitool.core import JsonConfig, logger


class DocDiffConfig(JsonConfig):
    """文档对比配置类。"""

    DOC_DIFF_TITLE: str = "对比结果"
    OUTPUT_DIR: str = str(Path.home())
    COMPARE_MODE: str = "original"
    SHOW_CHANGES: bool = True
    TRACK_REVISIONS: bool = True


conf = DocDiffConfig()


@dataclass(frozen=True)
class DiffDocCommand:
    """文档对比命令类。"""

    old_doc: Path
    new_doc: Path
    output_path: Path | None = None

    def run(self) -> None:
        """执行文档对比命令。"""
        if not self._check_platform():
            return
        self._validate_input_files()
        self._validate_environment()
        self._execute_comparison()

    def _check_platform(self) -> bool:
        """检查当前平台是否为 Windows。"""
        if platform.system() != "Windows":
            logger.error("此工具仅在 Windows 平台可用。")
            return False
        return True

    def _validate_input_files(self) -> None:
        """验证输入文件是否存在且扩展名正确。"""
        if not self.old_doc.exists():
            logger.error(f"旧文件不存在: {self.old_doc}")
            msg = f"旧文件不存在: {self.old_doc}"
            raise FileNotFoundError(msg)

        if not self.new_doc.exists():
            logger.error(f"新文件不存在: {self.new_doc}")
            msg = f"新文件不存在: {self.new_doc}"
            raise FileNotFoundError(msg)

        if not self.validate_files:
            logger.error("无效的文件路径或扩展名")
            msg = "无效的文件路径或扩展名"
            raise ValueError(msg)

    def _validate_environment(self) -> None:
        """验证 Word 应用程序和对比数据是否可用。"""
        if self.word_app is None:
            logger.error("Word 应用程序不可用")
            msg = "Word 应用程序不可用"
            raise RuntimeError(msg)

        if self.compare_data is None:
            msg = "对比失败"
            raise RuntimeError(msg)

    def _execute_comparison(self) -> None:
        """执行对比并保存结果。"""
        self.output.parent.mkdir(parents=True, exist_ok=True)
        try:
            self.compare_data.SaveAs2(str(self.output))
            self.compare_data.Close()
        except (OSError, RuntimeError):
            logger.exception("对比失败")
            raise
        else:
            logger.info(f"对比完成。已保存至: {self.output}")
        finally:
            self._cleanup()

    def _cleanup(self) -> None:
        """清理 Word 应用程序资源。"""
        self._close_word_documents()
        self._kill_word_process()

    def _close_word_documents(self) -> None:
        """关闭 Word 文档并退出应用程序。"""
        try:
            self.word_app.Documents.Close(SaveChanges=False)
        except (OSError, RuntimeError):
            logger.exception("关闭文档失败！")
        else:
            self.word_app.Quit()

    def _kill_word_process(self) -> None:
        """强制终止 WINWORD.EXE 进程。"""
        from bitool.cmd import execute

        try:
            execute(["taskkill", "/f", "/t", "/im", "WINWORD.EXE"])
        except (subprocess.SubprocessError, OSError):
            logger.exception("Taskkill 执行失败！")
        else:
            logger.info("Taskkill 执行成功")

    @cached_property
    def word_app(self) -> Any:
        """启动 Word 应用程序用于文档对比。"""
        try:
            import win32com.client as win32
        except ImportError:
            logger.exception("win32com.client 未安装，正在退出。")
            raise
        else:
            logger.info("已启动 Word 应用程序")
            app = win32.gencache.EnsureDispatch("Word.Application")
            app.Visible = False
            app.DisplayAlerts = False

            try:
                app.Options.TrackRevisions = conf.TRACK_REVISIONS
            except AttributeError:
                logger.warning(
                    "此版本 Word 不支持 TrackRevisions 选项",
                )

            return app

    @cached_property
    def validate_files(self) -> bool:
        """验证输入文件是否可用于对比。"""
        return all(
            [
                self.old_doc.exists(),
                self.new_doc.exists(),
                self.old_doc.suffix.lower() in {".doc", ".docx"},
                self.new_doc.suffix.lower() in {".doc", ".docx"},
            ],
        )

    @cached_property
    def compare_data(self) -> Any:
        """使用 Word 应用程序执行文档对比。"""
        try:
            compared = self.word_app.CompareDocuments(
                self.old_doc_data,
                self.new_doc_data,
                0,
                2 if conf.COMPARE_MODE == "revised" else 0,
                True,
            )
        except (OSError, RuntimeError):
            logger.exception("对比失败")
            return None
        else:
            if compared:
                logger.info("对比成功完成")
                compared.ShowRevisions = conf.SHOW_CHANGES
                return compared
            return None

    @cached_property
    def old_doc_data(self) -> Any:
        """打开旧文档用于对比。"""
        logger.info(f"正在打开旧文件: {self.old_doc}")
        return self.word_app.Documents.Open(str(self.old_doc.resolve()))

    @cached_property
    def new_doc_data(self) -> Any:
        """打开新文档用于对比。"""
        logger.info(f"正在打开新文件: {self.new_doc}")
        return self.word_app.Documents.Open(str(self.new_doc.resolve()))

    @cached_property
    def output(self) -> Path:
        """确定对比结果的输出目录。"""
        output_filename = f"{conf.DOC_DIFF_TITLE}@{time.strftime('%Y%m%d_%H_%M_%S')}.docx"

        if self.output_path is None:
            output_dir = Path(conf.OUTPUT_DIR) if conf.OUTPUT_DIR else self.new_doc.parent
            return output_dir / output_filename

        if self.output_path.is_dir():
            return self.output_path / output_filename
        if self.output_path.is_file():
            return self.output_path
        msg = f"无效的输出路径: {self.output_path}"
        raise ValueError(msg)


def parse_args() -> argparse.Namespace:
    """解析文档对比的命令行参数。"""
    parser = argparse.ArgumentParser(description="对比两个 doc/docx 文件。")
    parser.add_argument(
        "files",
        nargs=2,
        help="要对比的两个输入文件（旧文件 新文件）",
    )
    parser.add_argument(
        "-o",
        "--output",
        dest="output",
        default=".",
        help="输出文件路径",
    )
    parser.add_argument("--title", help="对比结果的标题")
    parser.add_argument(
        "--show-changes",
        action="store_true",
        help="在对比中显示变更",
    )
    parser.add_argument(
        "--hide-changes",
        action="store_true",
        help="在对比中隐藏变更",
    )
    parser.add_argument(
        "--compare-mode",
        choices=["original", "revised"],
        help="对比模式: original 或 revised",
    )
    parser.add_argument("--output-dir", help="结果文件的输出目录")

    args = parser.parse_args()

    if args.title:
        conf.DOC_DIFF_TITLE = args.title
    if args.show_changes:
        conf.SHOW_CHANGES = True
    if args.hide_changes:
        conf.SHOW_CHANGES = False
    if args.compare_mode:
        conf.COMPARE_MODE = args.compare_mode
    if args.output_dir:
        conf.OUTPUT_DIR = args.output_dir

    return args


def main() -> None:
    """对比两个 doc/docx 文件。"""
    args = parse_args()

    DiffDocCommand(
        Path(args.files[0]),
        Path(args.files[1]),
        Path(args.output),
    ).run()
