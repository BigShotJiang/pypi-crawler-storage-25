"""LLM量化模块测试套件."""

from __future__ import annotations

import tempfile
from pathlib import Path
from typing import TYPE_CHECKING
from unittest import mock

import pytest

if TYPE_CHECKING:
    from pytestqt.qtbot import QtBot

from bitool.apps.llmquantize.widgets.llmquantize import (
    LLMQuantize,
    QuantizationWorker,
    _process_gguf_stem,
)


class TestProcessGGUFStem:
    """_process_gguf_stem函数的测试用例."""

    @pytest.mark.parametrize(
        ("filename", "expected_result"),
        [
            ("model-F16", "model"),  # 标准F16后缀大写
            ("llama-2-F16", "llama-2"),  # 带连字符的模型名和F16后缀
            ("model-f16", "model"),  # 小写f16也会被移除(不区分大小写)
            ("model", "model"),  # 无F16后缀
            ("model-F16-quantized", "model-F16-quantized"),  # F16不在末尾
            ("F16", "F16"),  # 只有F16文本
            ("model-F16-F16", "model-F16"),  # 多个F16(只移除最后一个)
            ("", ""),  # 空字符串
            ("my-model-v2-F16", "my-model-v2"),  # 带F16的复杂模型名
        ],
    )
    def test_process_gguf_stem_various_cases(self, filename: str, expected_result: str) -> None:
        """测试_process_gguf_stem处理各种文件名模式."""
        result = _process_gguf_stem(filename)
        assert result == expected_result

    @pytest.mark.parametrize("filename", ["abcdef", "hello", "mymodel", "testfile", "xyz"])
    def test_process_gguf_stem_without_f16_suffix_property_based(self, filename: str) -> None:
        """无F16后缀文件名的属性测试."""
        # 确保输入不以-F16结尾
        if filename.upper().endswith("-F16"):
            filename = filename[:-4] + "xx"

        result = _process_gguf_stem(filename)
        # 无F16后缀时结果应与输入相同
        assert result == filename

    @pytest.mark.parametrize("base_filename", ["abcdef", "hello", "mymodel", "testfile", "xyz"])
    def test_process_gguf_stem_with_f16_suffix_property_based(self, base_filename: str) -> None:
        """带F16后缀文件名的属性测试."""
        filename = f"{base_filename}-F16"
        result = _process_gguf_stem(filename)
        assert result == base_filename


class TestQuantizationWorker:
    """QuantizationWorker类的测试用例."""

    def test_worker_initialization(self) -> None:
        """测试QuantizationWorker初始化."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            input_file = Path(tmp_dir) / "model-F16.gguf"
            input_file.write_text("mock model content")

            quant_types = ["Q4_K_M", "Q5_K_M"]
            worker = QuantizationWorker(input_file, quant_types)

            assert worker.input_file == input_file
            assert worker.quant_types == quant_types
            assert worker.input_dir == input_file.parent
            assert worker.base_name == "model"  # F16应被移除
            assert worker.total_files == 2
            assert worker.completed_files == 0
            assert worker.success is True

    def test_worker_base_name_without_f16(self) -> None:
        """测试无F16后缀时的基础名称提取."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            input_file = Path(tmp_dir) / "mymodel.gguf"
            input_file.write_text("mock model content")

            worker = QuantizationWorker(input_file, ["Q4_K_M"])

            assert worker.base_name == "mymodel"

    @mock.patch("subprocess.Popen")
    def test_worker_run_successful_conversion(self, mock_popen: mock.Mock) -> None:
        """测试成功的转换执行."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            input_file = Path(tmp_dir) / "model-F16.gguf"
            input_file.write_text("mock model content")

            # 使用正确的IO行为模拟子进程
            mock_process = mock.Mock()
            # 创建模拟的文件对象用于stdout
            mock_stdout = mock.Mock()
            mock_stdout.__iter__ = mock.Mock(return_value=iter(["Converting...", "Complete"]))
            mock_stdout.close = mock.Mock()
            mock_process.stdout = mock_stdout
            mock_process.returncode = 0
            mock_process.wait.return_value = None
            mock_popen.return_value = mock_process

            worker = QuantizationWorker(input_file, ["Q4_K_M"])

            # 收集发出的信号
            progress_messages = []
            progress_counts = []
            finished = []

            worker.progress_msg_updated.connect(progress_messages.append)
            worker.progress_count_updated.connect(progress_counts.append)
            worker.is_finished.connect(lambda: finished.append(True))

            worker.run()

            # 验证信号已发出
            assert len(progress_messages) > 0
            assert len(progress_counts) > 0
            assert len(finished) == 1
            assert worker.success is True
            assert worker.completed_files == 1

    @mock.patch("subprocess.Popen")
    def test_worker_run_failed_conversion(self, mock_popen: mock.Mock) -> None:
        """测试失败的转换执行."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            input_file = Path(tmp_dir) / "model-F16.gguf"
            input_file.write_text("mock model content")

            # 模拟子进程失败
            mock_process = mock.Mock()
            mock_stdout = mock.Mock()
            mock_stdout.__iter__ = mock.Mock(return_value=iter(["Error occurred"]))
            mock_stdout.close = mock.Mock()
            mock_process.stdout = mock_stdout
            mock_process.returncode = 1
            mock_process.wait.return_value = None
            mock_popen.return_value = mock_process

            worker = QuantizationWorker(input_file, ["Q4_K_M"])

            finished = []
            worker.is_finished.connect(lambda: finished.append(True))

            worker.run()

            # 验证失败已被处理
            assert len(finished) == 1
            assert worker.success is False
            assert worker.completed_files == 0

    @mock.patch("subprocess.Popen")
    def test_worker_run_with_permission_error(self, mock_popen: mock.Mock) -> None:
        """测试权限错误时的转换."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            input_file = Path(tmp_dir) / "model-F16.gguf"
            input_file.write_text("mock model content")

            # 模拟权限错误
            mock_popen.side_effect = PermissionError("Permission denied")

            worker = QuantizationWorker(input_file, ["Q4_K_M"])

            progress_messages = []
            worker.progress_msg_updated.connect(progress_messages.append)

            worker.run()

            # 验证错误已被处理
            assert worker.success is False
            assert any("无法启动量化进程" in msg for msg in progress_messages)

    @pytest.mark.parametrize("quant_types", [["Q4_K_M"], ["Q5_K_M", "Q6_K"], ["Q4_K_M", "Q5_K_M", "Q6_K"]])
    def test_worker_multiple_quant_types_property_based(self, quant_types: list[str]) -> None:
        """多量化类型的属性测试."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            input_file = Path(tmp_dir) / "model-F16.gguf"
            input_file.write_text("mock model content")

            worker = QuantizationWorker(input_file, quant_types)

            assert worker.total_files == len(quant_types)
            assert worker.quant_types == quant_types


class TestGGUFQuantizerGUI:
    """GGUFQuantizerGUI类的测试用例."""

    def test_gui_check_existing_quant_files(self, qtbot: QtBot) -> None:
        """测试检查现有量化文件."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)

            # 创建测试输入文件
            input_file = tmp_path / "model-F16.gguf"
            input_file.write_text("mock model content")

            # 创建已存在的量化文件
            existing_quant = tmp_path / "model-Q4_K_M.gguf"
            existing_quant.write_text("existing quantized model")

            with mock.patch(
                "bitool.apps.llmquantize.widgets.llmquantize.conf",
            ) as mock_conf:
                mock_conf.TITLE = "GGUF 量化转换工具"
                mock_conf.WIN_SIZE = [600, 500]
                mock_conf.WIN_POS = [100, 100]
                mock_conf.LAST_INPUT_FILE = ""
                mock_conf.SELECTED_QUANTS = ["Q4_K_M", "Q5_K_M"]
                gui = LLMQuantize()
                qtbot.addWidget(gui)

                gui.input_file = input_file
                gui.check_existing_quant_files()

                # 验证已存在文件的复选框被标记
                checkbox_text = gui.quant_checks["Q4_K_M"].text()
                assert "(已存在)" in checkbox_text

                # 验证不存在文件的复选框未被标记
                checkbox_text_q5 = gui.quant_checks["Q5_K_M"].text()
                assert "(已存在)" not in checkbox_text_q5

    def test_gui_on_quant_type_changed(self, qtbot: QtBot) -> None:
        """测试量化类型变更处理程序."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            Path(tmp_dir) / "test_gui.json"

            with mock.patch(
                "bitool.apps.llmquantize.widgets.llmquantize.conf",
            ) as mock_conf:
                mock_conf.TITLE = "GGUF 量化转换工具"
                mock_conf.WIN_SIZE = [600, 500]
                mock_conf.WIN_POS = [100, 100]
                mock_conf.LAST_INPUT_FILE = ""
                mock_conf.SELECTED_QUANTS = ["Q4_K_M", "Q5_K_M"]
                gui = LLMQuantize()
                qtbot.addWidget(gui)

                # 模拟勾选某些量化类型
                gui.quant_checks["Q4_K_M"].setChecked(True)
                gui.quant_checks["Q6_K"].setChecked(True)

                # 验证配置已更新(在实际场景中会被调用)
                assert "Q4_K_M" in [q for q, check in gui.quant_checks.items() if check.isChecked()]
                assert "Q6_K" in [q for q, check in gui.quant_checks.items() if check.isChecked()]

    def test_gui_move_event_saves_position(self, qtbot: QtBot) -> None:
        """测试移动窗口时保存位置到配置."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            Path(tmp_dir) / "test_gui.json"

            with mock.patch(
                "bitool.apps.llmquantize.widgets.llmquantize.conf",
            ) as mock_conf:
                mock_conf.TITLE = "GGUF 量化转换工具"
                mock_conf.WIN_POS = [100, 100]
                mock_conf.WIN_SIZE = [600, 500]
                mock_conf.LAST_INPUT_FILE = ""
                mock_conf.SELECTED_QUANTS = ["Q4_K_M", "Q5_K_M"]
                gui = LLMQuantize()
                qtbot.addWidget(gui)

                # 移动窗口
                gui.move(250, 300)
                qtbot.wait(10)  # 等待事件处理

                # 验证位置已保存到配置
                # 注意:由于窗口装饰,实际位置可能略有不同
                assert isinstance(mock_conf.WIN_POS, list)
                assert len(mock_conf.WIN_POS) == 2

    def test_gui_resize_event_saves_size(self, qtbot: QtBot) -> None:
        """测试调整窗口大小时保存大小到配置."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            Path(tmp_dir) / "test_gui.json"

            with mock.patch(
                "bitool.apps.llmquantize.widgets.llmquantize.conf",
            ) as mock_conf:
                mock_conf.TITLE = "GGUF 量化转换工具"
                mock_conf.WIN_SIZE = [600, 500]
                mock_conf.WIN_POS = [100, 100]
                mock_conf.LAST_INPUT_FILE = ""
                mock_conf.SELECTED_QUANTS = ["Q4_K_M", "Q5_K_M"]
                gui = LLMQuantize()
                qtbot.addWidget(gui)

                # 调整窗口大小
                gui.resize(800, 600)
                qtbot.wait(10)  # 等待事件处理

                # 验证大小已保存到配置
                assert isinstance(mock_conf.WIN_SIZE, list)
                assert len(mock_conf.WIN_SIZE) == 2


class TestIntegration:
    """完整工作流程的集成测试."""

    @pytest.mark.parametrize(
        ("input_filename", "expected_base"),
        [
            ("model-F16.gguf", "model"),
            ("llama-2-7b-F16.gguf", "llama-2-7b"),
            ("custom-model-F16.gguf", "custom-model"),
            ("simple.gguf", "simple"),
        ],
    )
    def test_worker_base_name_extraction_parametrized(self, input_filename: str, expected_base: str) -> None:
        """工作线程中基础名称提取的参数化测试."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            input_file = Path(tmp_dir) / input_filename
            input_file.write_text("mock model content")

            worker = QuantizationWorker(input_file, ["Q4_K_M"])
            assert worker.base_name == expected_base


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
