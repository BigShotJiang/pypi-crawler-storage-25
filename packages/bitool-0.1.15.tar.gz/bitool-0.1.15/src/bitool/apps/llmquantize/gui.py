"""GGUF量化转换工具入口."""

from __future__ import annotations

import sys

from bitool.core import logger
from bitool.gui.compat import QApplication
from bitool.utils import execute

from .widgets.llmquantize import LLMQuantize


def main() -> None:
    """主程序入口函数."""
    app = QApplication(sys.argv)

    # 检查是否已安装llama.cpp
    try:
        execute(["llama-quantize", "--help"])
    except FileNotFoundError:
        logger.error("错误:未找到llama-quantize工具")
        logger.error("请确保已编译llama.cpp并将quantize工具放在llama.cpp/目录下")
        sys.exit(1)

    window = LLMQuantize()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
