"""基于 GJB377B 标准的感度统计计算器测试。"""

from __future__ import annotations

import pytest

from bitool.apps.sensitivecalc import (
    BrucetonMethod,
    DixonMoodMethod,
    LanglieMethod,
    LogitMethod,
    ProbitMethod,
    SensitivityResult,
)


class TestBrucetonMethod:
    """BrucetonMethod 测试类。"""

    def test_calculate_basic(self) -> None:
        """测试基本计算。"""
        method = BrucetonMethod()
        result = method.calculate(
            x=[1.0, 1.2, 1.4, 1.2, 1.4, 1.6, 1.4],
            responses=[0, 1, 1, 0, 1, 1, 1],
            d=0.2,
        )

        assert isinstance(result, SensitivityResult)
        assert result.method == "Bruceton"
        assert isinstance(result.mu, float)
        assert isinstance(result.sigma, float)
        assert result.sigma > 0
        assert result.success_rate is not None

    def test_error_empty_data(self) -> None:
        """测试空数据错误。"""
        method = BrucetonMethod()

        with pytest.raises(ValueError, match="未提供数据"):
            method.calculate(x=[], responses=[], d=0.1)


class TestDixonMoodMethod:
    """DixonMoodMethod 测试类。"""

    def test_calculate_basic(self) -> None:
        """测试基本计算。"""
        method = DixonMoodMethod()
        result = method.calculate(
            x=[1.0, 1.2, 1.4, 1.2, 1.4, 1.6, 1.4],
            responses=[0, 1, 1, 0, 1, 1, 1],
            d=0.2,
        )

        assert isinstance(result, SensitivityResult)
        assert result.method == "Dixon-Mood"
        assert isinstance(result.mu, float)
        assert isinstance(result.sigma, float)


class TestLanglieMethod:
    """LanglieMethod 测试类。"""

    def test_calculate_basic(self) -> None:
        """测试基本计算。"""
        method = LanglieMethod()
        result = method.calculate(
            x=[1.0, 1.2, 1.4, 1.2, 1.4, 1.6, 1.4],
            responses=[0, 1, 1, 0, 1, 1, 1],
            d=0.2,
        )

        assert isinstance(result, SensitivityResult)
        assert result.method == "Langlie"
        assert isinstance(result.mu, float)
        assert isinstance(result.sigma, float)


class TestProbitMethod:
    """ProbitMethod 测试类。"""

    def test_calculate_basic(self) -> None:
        """测试基本计算。"""
        method = ProbitMethod()
        result = method.calculate(
            x=[1.0, 1.2, 1.4, 1.6, 1.8],
            n=[10, 10, 10, 10, 10],
            r=[1, 3, 6, 8, 9],
        )

        assert isinstance(result, SensitivityResult)
        assert result.method == "Probit"
        assert isinstance(result.mu, float)
        assert isinstance(result.sigma, float)
        assert result.success_rate is not None

    def test_error_empty_trials(self) -> None:
        """测试全部 n=0 的错误。"""
        method = ProbitMethod()

        with pytest.raises(ValueError, match="无有效试验"):
            method.calculate(x=[1.0, 2.0], n=[0, 0], r=[0, 0])


class TestLogitMethod:
    """LogitMethod 测试类。"""

    def test_calculate_basic(self) -> None:
        """测试基本计算。"""
        method = LogitMethod()
        result = method.calculate(
            x=[1.0, 1.2, 1.4, 1.6, 1.8],
            n=[10, 10, 10, 10, 10],
            r=[1, 3, 6, 8, 9],
        )

        assert isinstance(result, SensitivityResult)
        assert result.method == "Logit"
        assert isinstance(result.mu, float)
        assert isinstance(result.sigma, float)

    def test_compare_probit_logit(self) -> None:
        """测试 Probit 和 Logit 方法给出相似结果。"""
        x = [1.0, 1.2, 1.4, 1.6, 1.8]
        n = [10, 10, 10, 10, 10]
        r = [1, 3, 6, 8, 9]

        probit_method = ProbitMethod()
        probit_result = probit_method.calculate(x, n, r)

        logit_method = LogitMethod()
        logit_result = logit_method.calculate(x, n, r)

        assert abs(probit_result.mu - logit_result.mu) < 0.5


class TestCLI:
    """命令行功能测试类。"""

    def test_cli_import(self) -> None:
        """测试命令行模块可被导入。"""
        from bitool.apps.sensitivecalc import cli

        assert cli is not None

    def test_main_function_exists(self) -> None:
        """测试 main 函数存在。"""
        from bitool.apps.sensitivecalc.cli import main

        assert callable(main)


class TestGUI:
    """GUI 功能测试类。"""

    def test_gui_import(self) -> None:
        """测试 GUI 模块可被导入。"""
        from bitool.apps.sensitivecalc import gui

        assert gui is not None

    def test_main_function_exists(self) -> None:
        """测试 GUI 中 main 函数存在。"""
        from bitool.apps.sensitivecalc.gui import main

        assert callable(main)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
