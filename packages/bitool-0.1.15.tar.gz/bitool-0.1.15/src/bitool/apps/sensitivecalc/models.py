"""感度统计计算器的数据模型。"""

from __future__ import annotations

from bitool.gui.compat import (
    QAbstractTableModel,
    QModelIndex,
    Qt,
)


class UpDownTableModel(QAbstractTableModel):
    """升降法数据表格模型。固定 40 行（GJB377B 要求）。"""

    FIXED_ROWS = 40

    def __init__(self, parent=None):
        super().__init__(parent)
        self._data = [[None, None] for _ in range(self.FIXED_ROWS)]
        self._headers = ["序号", "刺激量 (x)", "响应 (0/1)"]

    def rowCount(self, parent=QModelIndex()) -> int:
        """返回行数。"""
        return self.FIXED_ROWS

    def columnCount(self, parent=QModelIndex()) -> int:
        """返回列数。"""
        return 3

    def data(self, index, role=Qt.DisplayRole) -> str | None:
        if not index.isValid():
            return None

        row, col = index.row(), index.column()

        if role == Qt.DisplayRole or role == Qt.EditRole:
            if col == 0:
                return str(row + 1)
            elif col == 1:
                return str(self._data[row][0]) if self._data[row][0] is not None else ""
            elif col == 2:
                return str(self._data[row][1]) if self._data[row][1] is not None else ""

        return None

    def setData(self, index, value, role=Qt.EditRole):
        if not index.isValid():
            return False

        row, col = index.row(), index.column()

        if role == Qt.EditRole:
            try:
                if col == 1:
                    if value.strip():
                        self._data[row][0] = float(value)
                    else:
                        self._data[row][0] = None
                elif col == 2:
                    if value.strip():
                        v = int(value)
                        self._data[row][1] = 0 if v == 0 else 1
                    else:
                        self._data[row][1] = None
            except ValueError:
                return False
            else:
                self.dataChanged.emit(index, index)
                return True

        return False

    def flags(self, index) -> Qt.ItemFlag:
        if not index.isValid():
            return Qt.NoItemFlags

        if index.column() == 0:
            return Qt.ItemIsSelectable | Qt.ItemIsEnabled
        else:
            return Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsEditable

    def headerData(self, section, orientation, role=Qt.DisplayRole) -> str | None:
        """返回表头数据。"""
        if role == Qt.DisplayRole:
            if orientation == Qt.Horizontal:
                return self._headers[section]
            else:
                return str(section + 1)
        return None

    def clear(self):
        """清空所有数据。"""
        self.beginResetModel()
        self._data = [[None, None] for _ in range(self.FIXED_ROWS)]
        self.endResetModel()

    def get_data(self):
        """获取数据为列表。"""
        x = []
        responses = []
        for row in self._data:
            if row[0] is not None and row[1] is not None:
                x.append(row[0])
                responses.append(row[1])
        return x, responses

    def set_data(self, x, responses):
        """从列表设置数据。"""
        self.beginResetModel()
        self._data = [[None, None] for _ in range(self.FIXED_ROWS)]
        min_len = min(len(x), len(responses), self.FIXED_ROWS)
        for i in range(min_len):
            self._data[i] = [x[i], responses[i]]
        self.endResetModel()


class GroupedTableModel(QAbstractTableModel):
    """分组法数据表格模型。固定 20 行。"""

    FIXED_ROWS = 20

    def __init__(self, parent=None):
        super().__init__(parent)
        self._data = [[None, None, None] for _ in range(self.FIXED_ROWS)]
        self._headers = ["序号", "刺激量 (x)", "试验次数 (n)", "成功次数 (r)"]

    def rowCount(self, parent=QModelIndex()) -> int:
        """返回行数。"""
        return self.FIXED_ROWS

    def columnCount(self, parent=QModelIndex()) -> int:
        """返回列数。"""
        return 4

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None

        row, col = index.row(), index.column()

        if role == Qt.DisplayRole or role == Qt.EditRole:
            if col == 0:
                return str(row + 1)
            elif col == 1:
                return str(self._data[row][0]) if self._data[row][0] is not None else ""
            elif col == 2:
                return str(self._data[row][1]) if self._data[row][1] is not None else ""
            elif col == 3:
                return str(self._data[row][2]) if self._data[row][2] is not None else ""

        return None

    def setData(self, index, value, role=Qt.EditRole):
        if not index.isValid():
            return False

        row, col = index.row(), index.column()

        if role == Qt.EditRole:
            try:
                if col == 1:
                    if value.strip():
                        self._data[row][0] = float(value)
                    else:
                        self._data[row][0] = None
                elif col in (2, 3):
                    if value.strip():
                        self._data[row][col - 1] = int(value)
                    else:
                        self._data[row][col - 1] = None
            except ValueError:
                return False
            else:
                self.dataChanged.emit(index, index)
                return True

        return False

    def flags(self, index):
        if not index.isValid():
            return Qt.NoItemFlags

        if index.column() == 0:
            return Qt.ItemIsSelectable | Qt.ItemIsEnabled
        else:
            return Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsEditable

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role == Qt.DisplayRole:
            if orientation == Qt.Horizontal:
                return self._headers[section]
            else:
                return str(section + 1)
        return None

    def clear(self):
        """清空所有数据。"""
        self.beginResetModel()
        self._data = [[None, None, None] for _ in range(self.FIXED_ROWS)]
        self.endResetModel()

    def get_data(self):
        """获取数据为列表。"""
        x = []
        n = []
        r = []
        for row in self._data:
            if row[0] is not None and row[1] is not None and row[2] is not None:
                x.append(row[0])
                n.append(row[1])
                r.append(row[2])
        return x, n, r

    def set_data(self, x, n, r):
        """从列表设置数据。"""
        self.beginResetModel()
        self._data = [[None, None, None] for _ in range(self.FIXED_ROWS)]
        min_len = min(len(x), len(n), len(r), self.FIXED_ROWS)
        for i in range(min_len):
            self._data[i] = [x[i], n[i], r[i]]
        self.endResetModel()
