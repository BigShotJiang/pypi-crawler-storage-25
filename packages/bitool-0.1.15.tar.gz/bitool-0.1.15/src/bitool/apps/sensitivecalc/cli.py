"""感度统计计算器的命令行模块。

与 bitool 核心工具集成，包括日志记录功能。
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
from scipy import stats
from scipy.optimize import minimize

from bitool.core import logger


@dataclass
class SensitivityResult:
    """感度分析结果类。"""

    method: str
    mu: float
    sigma: float
    mu_std: float = 0.0
    sigma_std: float = 0.0
    success_rate: dict[float, float] | None = None
    data: dict[str, Any] | None = None
    additional_info: dict[str, Any] | None = None


class BaseSensitivityMethod:
    """感度分析方法的抽象基类。"""

    def calculate(self, *args: object, **kwargs: object) -> SensitivityResult:
        """计算感度统计数据。"""
        raise NotImplementedError("子类必须实现 calculate 方法")


class BrucetonMethod(BaseSensitivityMethod):
    """Bruceton 升降法感度分析。"""

    def calculate(self, x: list[float], responses: list[int], d: float) -> SensitivityResult:
        """使用 Bruceton 法计算感度。"""
        logger.info(f"开始 Bruceton 计算，共 {len(x)} 个数据点")

        x_array = np.array(x)
        responses_array = np.array(responses)

        n = len(x_array)
        if n == 0:
            raise ValueError("未提供数据")

        x_mean = np.mean(x_array)
        x_var = np.var(x_array, ddof=1)

        p = np.mean(responses_array)

        sigma = d / np.sqrt(2) if x_var == 0 else np.sqrt(x_var)

        mu = x_mean - p * d

        mu_std = sigma / np.sqrt(n)
        sigma_std = sigma / np.sqrt(2 * (n - 1))

        unique_x = np.unique(x_array)
        success_rate = {}
        for xi in unique_x:
            mask = x_array == xi
            if np.any(mask):
                success_rate[float(xi)] = float(np.mean(responses_array[mask]))

        logger.debug(f"Bruceton 结果: mu={mu:.4f}, sigma={sigma:.4f}")

        return SensitivityResult(
            method="Bruceton",
            mu=float(mu),
            sigma=float(sigma),
            mu_std=float(mu_std),
            sigma_std=float(sigma_std),
            success_rate=success_rate,
            data={"x": x, "responses": responses, "d": d},
            additional_info={"n": n, "p_mean": float(p)},
        )


class DixonMoodMethod(BaseSensitivityMethod):
    """Dixon-Mood 法感度分析。"""

    def calculate(self, x: list[float], responses: list[int], d: float) -> SensitivityResult:
        """使用 Dixon-Mood 法计算感度。"""
        logger.info(f"开始 Dixon-Mood 计算，共 {len(x)} 个数据点")

        x_array = np.array(x)
        responses_array = np.array(responses)

        n = len(x_array)
        if n == 0:
            raise ValueError("未提供数据")

        x_sorted = np.sort(x_array)
        r = np.sum(responses_array)

        p = r / n
        mu = np.percentile(x_sorted, p * 100)

        sigma = d / np.sqrt(2 * np.pi) * np.sqrt(n / (r * (n - r))) if r > 0 and r < n else d

        mu_std = sigma / np.sqrt(n)
        sigma_std = sigma / np.sqrt(2 * (n - 1))

        unique_x = np.unique(x_array)
        success_rate = {}
        for xi in unique_x:
            mask = x_array == xi
            if np.any(mask):
                success_rate[float(xi)] = float(np.mean(responses_array[mask]))

        logger.debug(f"Dixon-Mood 结果: mu={mu:.4f}, sigma={sigma:.4f}")

        return SensitivityResult(
            method="Dixon-Mood",
            mu=float(mu),
            sigma=float(sigma),
            mu_std=float(mu_std),
            sigma_std=float(sigma_std),
            success_rate=success_rate,
            data={"x": x, "responses": responses, "d": d},
            additional_info={"n": n, "success_count": r},
        )


class LanglieMethod(BaseSensitivityMethod):
    """Langlie 法感度分析。"""

    def calculate(self, x: list[float], responses: list[int], d: float) -> SensitivityResult:
        """使用 Langlie 法计算感度。"""
        logger.info(f"开始 Langlie 计算，共 {len(x)} 个数据点")

        x_array = np.array(x)
        responses_array = np.array(responses)

        n = len(x_array)
        if n == 0:
            raise ValueError("未提供数据")

        x_mean = np.mean(x_array)
        x_var = np.var(x_array, ddof=1)

        p = np.mean(responses_array)
        z = stats.norm.ppf(p) if 0 < p < 1 else 0

        sigma = d / np.sqrt(2) if x_var == 0 else np.sqrt(x_var)

        mu = x_mean - z * sigma

        mu_std = sigma / np.sqrt(n)
        sigma_std = sigma / np.sqrt(2 * (n - 1))

        unique_x = np.unique(x_array)
        success_rate = {}
        for xi in unique_x:
            mask = x_array == xi
            if np.any(mask):
                success_rate[float(xi)] = float(np.mean(responses_array[mask]))

        logger.debug(f"Langlie 结果: mu={mu:.4f}, sigma={sigma:.4f}")

        return SensitivityResult(
            method="Langlie",
            mu=float(mu),
            sigma=float(sigma),
            mu_std=float(mu_std),
            sigma_std=float(sigma_std),
            success_rate=success_rate,
            data={"x": x, "responses": responses, "d": d},
            additional_info={"n": n, "p_mean": float(p), "z_score": float(z)},
        )


class ProbitMethod(BaseSensitivityMethod):
    """使用最大似然估计的 Probit 法感度分析。"""

    @staticmethod
    def _probit_likelihood(
        params: np.ndarray, x: np.ndarray, n: np.ndarray, r: np.ndarray,
    ) -> float:
        """计算 Probit 模型的负对数似然函数。"""
        mu, log_sigma = params
        sigma = np.exp(log_sigma)

        z = (x - mu) / sigma
        p = stats.norm.cdf(z)

        p = np.clip(p, 1e-10, 1 - 1e-10)
        log_likelihood = np.sum(r * np.log(p) + (n - r) * np.log(1 - p))

        return -log_likelihood

    def calculate(self, x: list[float], n: list[int], r: list[int]) -> SensitivityResult:
        """使用 Probit 法计算感度。"""
        logger.info(f"开始 Probit 计算，共 {len(x)} 个剂量组")

        x_array = np.array(x)
        n_array = np.array(n)
        r_array = np.array(r)

        if np.sum(n_array) == 0:
            raise ValueError("无有效试验")

        np.sum(r_array) / np.sum(n_array)
        mu_initial = np.mean(x_array)
        sigma_initial = np.std(x_array) if len(x_array) > 1 else 1.0

        initial_params = np.array([mu_initial, np.log(max(sigma_initial, 0.1))])

        try:
            result = minimize(
                self._probit_likelihood,
                initial_params,
                args=(x_array, n_array, r_array),
                method="L-BFGS-B",
                bounds=[(None, None), (-10, 10)],
            )
        except (ValueError, RuntimeError):
            logger.exception("Probit 优化失败")
            mu, sigma = mu_initial, sigma_initial
            success_rate = None
            opt_result = None
        else:
            mu, log_sigma = result.x
            sigma = np.exp(log_sigma)
            opt_result = {
                "success": result.success,
                "message": result.message,
                "nit": result.nit,
                "nfev": result.nfev,
            }

            z = (x_array - mu) / sigma
            success_rate = {float(xi): float(stats.norm.cdf(zi)) for xi, zi in zip(x_array, z)}

        mu_std = sigma / np.sqrt(np.sum(n_array))
        sigma_std = sigma / np.sqrt(2 * (np.sum(n_array) - 1))

        logger.debug(f"Probit 结果: mu={mu:.4f}, sigma={sigma:.4f}")

        return SensitivityResult(
            method="Probit",
            mu=float(mu),
            sigma=float(sigma),
            mu_std=float(mu_std),
            sigma_std=float(sigma_std),
            success_rate=success_rate,
            data={"x": x, "n": n, "r": r},
            additional_info={"optimization_result": opt_result},
        )


class LogitMethod(BaseSensitivityMethod):
    """使用最大似然估计的 Logit 法感度分析。"""

    @staticmethod
    def _logit_likelihood(params: np.ndarray, x: np.ndarray, n: np.ndarray, r: np.ndarray) -> float:
        """计算 Logit 模型的负对数似然函数。"""
        beta0, beta1 = params

        eta = beta0 + beta1 * x
        p = 1 / (1 + np.exp(-eta))

        p = np.clip(p, 1e-10, 1 - 1e-10)
        log_likelihood = np.sum(r * np.log(p) + (n - r) * np.log(1 - p))

        return -log_likelihood

    def calculate(self, x: list[float], n: list[int], r: list[int]) -> SensitivityResult:
        """使用 Logit 法计算感度。"""
        logger.info(f"开始 Logit 计算，共 {len(x)} 个剂量组")

        x_array = np.array(x)
        n_array = np.array(n)
        r_array = np.array(r)

        if np.sum(n_array) == 0:
            raise ValueError("无有效试验")

        p_initial = np.sum(r_array) / np.sum(n_array)

        try:
            initial_params = (
                np.array([np.log(p_initial / (1 - p_initial)), 1.0])
                if 0 < p_initial < 1
                else np.array([0.0, 1.0])
            )

            result = minimize(
                self._logit_likelihood,
                initial_params,
                args=(x_array, n_array, r_array),
                method="L-BFGS-B",
            )
        except (ValueError, RuntimeError):
            logger.exception("Logit 优化失败")
            mu = np.mean(x_array)
            sigma = np.std(x_array) if len(x_array) > 1 else 1.0
            beta0, beta1 = 0.0, 1.0
            success_rate = None
            opt_result = None
        else:
            beta0, beta1 = result.x
            mu = -beta0 / beta1 if beta1 != 0 else np.mean(x_array)
            sigma = (
                np.pi / (np.sqrt(3) * abs(beta1))
                if beta1 != 0
                else np.std(x_array)
                if len(x_array) > 1
                else 1.0
            )

            opt_result = {
                "success": result.success,
                "message": result.message,
                "nit": result.nit,
                "nfev": result.nfev,
                "beta0": float(beta0),
                "beta1": float(beta1),
            }

            eta = beta0 + beta1 * x_array
            success_rate = {float(xi): float(1 / (1 + np.exp(-ei))) for xi, ei in zip(x_array, eta)}

        mu_std = sigma / np.sqrt(np.sum(n_array))
        sigma_std = sigma / np.sqrt(2 * (np.sum(n_array) - 1))

        logger.debug(f"Logit 结果: mu={mu:.4f}, sigma={sigma:.4f}")

        return SensitivityResult(
            method="Logit",
            mu=float(mu),
            sigma=float(sigma),
            mu_std=float(mu_std),
            sigma_std=float(sigma_std),
            success_rate=success_rate,
            data={"x": x, "n": n, "r": r},
            additional_info={
                "beta0": float(beta0),
                "beta1": float(beta1),
                "optimization_result": opt_result,
            },
        )


def print_result(result: SensitivityResult) -> None:
    """打印感度分析结果。"""

    if result.success_rate:
        for _xi in sorted(result.success_rate.keys()):
            pass

    if result.additional_info:
        for value in result.additional_info.values():
            if isinstance(value, float) or (isinstance(value, dict) and "success" in value):
                pass


def load_data_from_json(file_path: str | Path) -> dict[str, Any]:
    """从 JSON 文件加载数据。"""
    with open(file_path, encoding="utf-8") as f:
        return json.load(f)


def main() -> int:
    """命令行主入口。"""
    parser = argparse.ArgumentParser(
        description="基于 GJB377B 标准的感度统计计算器",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    subparsers = parser.add_subparsers(dest="method", help="计算方法")

    bruceton_parser = subparsers.add_parser("bruceton", help="Bruceton（升降法）")
    bruceton_parser.add_argument("--x", type=float, nargs="+", required=True, help="刺激量水平")
    bruceton_parser.add_argument(
        "--responses", type=int, nargs="+", required=True, help="响应结果 (0/1)",
    )
    bruceton_parser.add_argument("--d", type=float, required=True, help="步长")
    bruceton_parser.add_argument("--file", type=str, help="包含数据的 JSON 文件")

    dixon_parser = subparsers.add_parser("dixon", help="Dixon-Mood 法")
    dixon_parser.add_argument("--x", type=float, nargs="+", required=True, help="刺激量水平")
    dixon_parser.add_argument(
        "--responses", type=int, nargs="+", required=True, help="响应结果 (0/1)",
    )
    dixon_parser.add_argument("--d", type=float, required=True, help="步长")

    langlie_parser = subparsers.add_parser("langlie", help="Langlie 法")
    langlie_parser.add_argument("--x", type=float, nargs="+", required=True, help="刺激量水平")
    langlie_parser.add_argument(
        "--responses", type=int, nargs="+", required=True, help="响应结果 (0/1)",
    )
    langlie_parser.add_argument("--d", type=float, required=True, help="步长")

    probit_parser = subparsers.add_parser("probit", help="Probit 法")
    probit_parser.add_argument("--x", type=float, nargs="+", required=True, help="刺激量水平")
    probit_parser.add_argument("--n", type=int, nargs="+", required=True, help="试验次数")
    probit_parser.add_argument("--r", type=int, nargs="+", required=True, help="成功次数")

    logit_parser = subparsers.add_parser("logit", help="Logit 法")
    logit_parser.add_argument("--x", type=float, nargs="+", required=True, help="刺激量水平")
    logit_parser.add_argument("--n", type=int, nargs="+", required=True, help="试验次数")
    logit_parser.add_argument("--r", type=int, nargs="+", required=True, help="成功次数")

    args = parser.parse_args()

    if args.method is None:
        parser.print_help()
        return 1

    try:
        if args.method == "bruceton":
            if hasattr(args, "file") and args.file:
                data = load_data_from_json(args.file)
                x, responses, d = data["x"], data["responses"], data["d"]
            else:
                x, responses, d = args.x, args.responses, args.d

            method = BrucetonMethod()
            result = method.calculate(x, responses, d)

        elif args.method == "dixon":
            method = DixonMoodMethod()
            result = method.calculate(args.x, args.responses, args.d)

        elif args.method == "langlie":
            method = LanglieMethod()
            result = method.calculate(args.x, args.responses, args.d)

        elif args.method == "probit":
            method = ProbitMethod()
            result = method.calculate(args.x, args.n, args.r)

        elif args.method == "logit":
            method = LogitMethod()
            result = method.calculate(args.x, args.n, args.r)

        else:
            logger.error(f"未知方法: {args.method}")
            return 1

        print_result(result)

    except Exception as e:  # noqa: BLE001
        logger.error(f"错误: {e}")
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
