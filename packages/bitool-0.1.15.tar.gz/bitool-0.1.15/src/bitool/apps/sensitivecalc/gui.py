"""感度统计计算器的 GUI 入口点。"""

from __future__ import annotations

import sys

from bitool.gui.compat import QApplication

from .widgets import SensitiveCalcGUI


def main() -> None:
    """运行感度统计计算器 GUI 应用程序的主入口点。"""
    app = QApplication(sys.argv)
    app.setApplicationName("感度统计计算器")

    window = SensitiveCalcGUI()
    window.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
