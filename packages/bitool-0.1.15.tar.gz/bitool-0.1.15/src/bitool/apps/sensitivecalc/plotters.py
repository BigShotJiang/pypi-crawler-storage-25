"""感度统计计算器的绘图工具。"""

from __future__ import annotations

import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from bitool.core import logger


class MplCanvas(FigureCanvas):
    """用于绘图的 Matplotlib 画布。"""

    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = fig.add_subplot(111)
        super().__init__(fig)
        self.setParent(parent)


def setup_chinese_font():
    """设置 matplotlib 中文字体。"""
    windows_fonts = ["SimHei", "Microsoft YaHei", "SimSun", "Arial Unicode MS"]
    mac_fonts = ["Arial Unicode MS", "PingFang SC", "Heiti TC"]
    linux_fonts = ["WenQuanYi Micro Hei", "Noto Sans CJK SC", "Noto Sans SC"]

    available_fonts = [f.name for f in font_manager.fontManager.ttflist]

    for font_list in [windows_fonts, mac_fonts, linux_fonts]:
        for font_name in font_list:
            if font_name in available_fonts:
                plt.rcParams["font.sans-serif"] = [font_name, "sans-serif"]
                logger.debug(f"使用中文字体: {font_name}")
                return True

    plt.rcParams["font.sans-serif"] = ["sans-serif"]
    logger.warning("未找到中文字体，使用系统默认字体")
    return False


def plot_cdf(canvas, result):
    """绘制 CDF 曲线，根据不同方法采用不同的显示方式。"""
    ax = canvas.axes
    ax.clear()

    method_name = result.method

    has_raw_responses = result.data is not None and "responses" in result.data
    has_grouped_data = result.data is not None and "n" in result.data and "r" in result.data

    if has_raw_responses:
        _plot_updown_method(ax, result)
    elif has_grouped_data:
        _plot_grouped_method(ax, result)
    else:
        _plot_cdf_only(ax, result)

    ax.set_xlabel("刺激量", fontsize=12)
    ax.set_ylabel("响应 (0/1) / 成功概率", fontsize=12)
    ax.set_title(f"试验结果与 CDF - {method_name}", fontsize=14)
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3)
    ax.set_ylim(-0.2, 1.3)

    canvas.draw()


def plot_raw_data(canvas, result):
    """绘制原始数据视图：横坐标为试验编号，纵坐标为刺激量。"""
    ax = canvas.axes
    ax.clear()

    has_raw_responses = result.data is not None and "responses" in result.data
    has_grouped_data = result.data is not None and "n" in result.data and "r" in result.data

    if has_raw_responses:
        x_data = result.data["x"]
        responses = result.data["responses"]
        trial_numbers = list(range(1, len(x_data) + 1))

        ax.plot(trial_numbers, x_data, "b-", linewidth=1.5, alpha=0.5, label="刺激量变化")

        for i, (trial, x, r) in enumerate(zip(trial_numbers, x_data, responses)):
            if r == 1:
                ax.scatter(trial, x, marker="x", color="green", s=80, zorder=5)
            else:
                ax.scatter(trial, x, marker="o", color="red", s=80, zorder=5)
            ax.annotate(
                str(i + 1),
                (trial, x),
                textcoords="offset points",
                xytext=(8, 0),
                ha="left",
                fontsize=10,
                color="black",
            )

        ax.set_xlabel("试验编号", fontsize=12)
        ax.set_ylabel("刺激量", fontsize=12)
        ax.set_title(f"试验序列 - {result.method}", fontsize=14)
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        ax.set_xlim(0, len(x_data) + 1)

    elif has_grouped_data:
        x_data = result.data["x"]
        n_data = result.data["n"]
        r_data = result.data["r"]
        group_numbers = list(range(1, len(x_data) + 1))

        ax.scatter(group_numbers, x_data, marker="s", color="blue", s=100, zorder=5, label="剂量组")

        for _i, (group, x, _n, _r) in enumerate(zip(group_numbers, x_data, n_data, r_data)):
            ax.annotate(
                f"{x}",
                (group, x),
                textcoords="offset points",
                xytext=(8, 0),
                ha="left",
                fontsize=10,
                color="blue",
            )

        ax.set_xlabel("剂量组编号", fontsize=12)
        ax.set_ylabel("刺激量", fontsize=12)
        ax.set_title(f"剂量组分布 - {result.method}", fontsize=14)
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        ax.set_xlim(0, len(x_data) + 1)

    canvas.draw()


def _plot_updown_method(ax, result):
    """绘制升降法的图表：试验序列 + 拟合CDF。"""
    x_data = result.data["x"]
    responses = result.data["responses"]

    y_data = [float(r) for r in responses]
    ax.plot(x_data, y_data, "b-", linewidth=1.5, alpha=0.5, label="试验序列")

    for _i, (x, r) in enumerate(zip(x_data, responses)):
        if r == 1:
            ax.scatter(x, float(r), marker="o", color="green", s=80, zorder=5)
            ax.annotate(
                "O",
                (x, float(r)),
                textcoords="offset points",
                xytext=(0, 12),
                ha="center",
                fontsize=10,
                color="green",
            )
        else:
            ax.scatter(x, float(r), marker="x", color="red", s=80, zorder=5)
            ax.annotate(
                "X",
                (x, float(r)),
                textcoords="offset points",
                xytext=(0, 12),
                ha="center",
                fontsize=10,
                color="red",
            )

    if result.success_rate:
        x_vals = sorted(result.success_rate.keys())
        y_vals = [result.success_rate[x] for x in x_vals]
        ax.plot(x_vals, y_vals, "r--", linewidth=2, label="拟合 CDF")
        ax.scatter(x_vals, y_vals, c="red", s=60, zorder=4)

        for xi, yi in zip(x_vals, y_vals):
            ax.annotate(
                f"{yi:.2f}",
                (xi, yi),
                textcoords="offset points",
                xytext=(0, 10),
                ha="center",
                fontsize=9,
            )


def _plot_grouped_method(ax, result):
    """绘制分组法的图表：分组数据点 + 拟合CDF。"""
    x_data = result.data["x"]
    n_data = result.data["n"]
    r_data = result.data["r"]

    success_rates = [r / n if n > 0 else 0 for r, n in zip(r_data, n_data)]
    ax.scatter(x_data, success_rates, marker="s", color="blue", s=100, zorder=5, label="分组数据")

    for _i, (x, n, r) in enumerate(zip(x_data, n_data, r_data)):
        rate = r / n if n > 0 else 0
        ax.annotate(
            f"{r}/{n}",
            (x, rate),
            textcoords="offset points",
            xytext=(0, 12),
            ha="center",
            fontsize=9,
            color="blue",
        )

    if result.success_rate:
        x_vals = sorted(result.success_rate.keys())
        y_vals = [result.success_rate[x] for x in x_vals]
        ax.plot(x_vals, y_vals, "r-", linewidth=2, label="拟合 CDF")
        ax.scatter(x_vals, y_vals, c="red", s=60, zorder=4)

        for xi, yi in zip(x_vals, y_vals):
            ax.annotate(
                f"{yi:.2f}",
                (xi, yi),
                textcoords="offset points",
                xytext=(0, 10),
                ha="center",
                fontsize=9,
            )


def _plot_cdf_only(ax, result):
    """仅绘制 CDF 曲线。"""
    if result.success_rate:
        x_vals = sorted(result.success_rate.keys())
        y_vals = [result.success_rate[x] for x in x_vals]
        ax.plot(x_vals, y_vals, "b-", linewidth=2, label="CDF")
        ax.scatter(x_vals, y_vals, c="blue", s=60, zorder=4)
