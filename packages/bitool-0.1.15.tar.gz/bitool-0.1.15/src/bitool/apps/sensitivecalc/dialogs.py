"""感度统计计算器的对话框类。"""

from __future__ import annotations

from bitool.gui.compat import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QVBoxLayout,
)

from .examples import ALL_EXAMPLES


class ExampleDialog(QDialog):
    """示例数据选择对话框。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("选择示例数据")
        self.setMinimumSize(600, 400)
        self.selected_example = None
        self.selected_data = None
        self.init_ui()

    def init_ui(self):
        """初始化对话框UI。"""
        layout = QVBoxLayout(self)

        info_label = QLabel("选择一个示例数据来测试功能：")
        layout.addWidget(info_label)

        method_layout = QHBoxLayout()
        method_layout.addWidget(QLabel("计算方法:"))
        self.method_combo = QComboBox()
        self.method_combo.addItems(list(ALL_EXAMPLES.keys()))
        self.method_combo.currentTextChanged.connect(self.on_method_changed)
        method_layout.addWidget(self.method_combo)
        layout.addLayout(method_layout)

        self.example_list = QListWidget()
        self.example_list.itemDoubleClicked.connect(self.accept)
        layout.addWidget(self.example_list)

        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

        self.on_method_changed(self.method_combo.currentText())

    def on_method_changed(self, method_name):
        """处理方法选择变化。"""
        self.example_list.clear()
        if method_name in ALL_EXAMPLES:
            for name, data in ALL_EXAMPLES[method_name].items():
                desc = data.get("description", "")
                self.example_list.addItem(f"{name} - {desc}")

            if self.example_list.count() > 0:
                self.example_list.setCurrentRow(0)

    def get_selected_example(self):
        """获取选中的示例，返回三元组 (method_name, example_name, example_data)。"""
        current_item = self.example_list.currentItem()
        if not current_item and self.example_list.count() > 0:
            self.example_list.setCurrentRow(0)
            current_item = self.example_list.currentItem()

        if current_item:
            text = current_item.text()
            example_name = text.split(" - ")[0]
            method_name = self.method_combo.currentText()
            if method_name in ALL_EXAMPLES and example_name in ALL_EXAMPLES[method_name]:
                return method_name, example_name, ALL_EXAMPLES[method_name][example_name]
        return None, None, None
