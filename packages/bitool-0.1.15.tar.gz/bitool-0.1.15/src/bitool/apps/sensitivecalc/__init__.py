"""基于 GJB377B 标准的感度统计计算器。

本模块提供多种感度试验分析方法：
- Bruceton 法（升降法）
- Dixon-Mood 法
- Langlie 法
- Probit 法（概率单位法）
- Logit 法（逻辑单位法）
"""

from __future__ import annotations

from .cli import (
    BrucetonMethod,
    DixonMoodMethod,
    LanglieMethod,
    LogitMethod,
    ProbitMethod,
    SensitivityResult,
    main,
)
from .widgets import SensitiveCalcGUI

__all__ = [
    "BrucetonMethod",
    "DixonMoodMethod",
    "LanglieMethod",
    "LogitMethod",
    "ProbitMethod",
    "SensitiveCalcGUI",
    "SensitivityResult",
    "main",
]
__version__ = "0.1.7"
