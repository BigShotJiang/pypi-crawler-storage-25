"""感度统计计算器的主窗口组件。"""

from __future__ import annotations

import json

from bitool.core import logger
from bitool.gui import setup_ui
from bitool.gui.compat import (
    QFileDialog,
    QHeaderView,
    QMainWindow,
    QMessageBox,
    QVBoxLayout,
)

from ..cli import (
    BrucetonMethod,
    DixonMoodMethod,
    LanglieMethod,
    LogitMethod,
    ProbitMethod,
)
from ..dialogs import ExampleDialog
from ..models import GroupedTableModel, UpDownTableModel
from ..plotters import MplCanvas, plot_cdf, plot_raw_data, setup_chinese_font


class SensitiveCalcGUI(QMainWindow):
    """感度统计计算器主窗口。"""

    def __init__(self):
        super().__init__()
        setup_ui(self)
        setup_chinese_font()
        self.resize(1400, 900)

        self.methods = {
            "Bruceton (升降法)": BrucetonMethod,
            "Dixon-Mood": DixonMoodMethod,
            "Langlie": LanglieMethod,
            "Probit (概率单位法)": ProbitMethod,
            "Logit (逻辑单位法)": LogitMethod,
        }

        self.init_models()
        self.init_canvas()
        self.setup_connections()

        self.method_combo.addItems(list(self.methods.keys()))
        self.on_method_changed(self.method_combo.currentText())

        logger.info("感度统计计算器 GUI 初始化完成")

    def init_models(self):
        """初始化数据模型。"""
        self.updown_model = UpDownTableModel()
        self.updown_table.setModel(self.updown_model)
        self.updown_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        self.grouped_model = GroupedTableModel()
        self.grouped_table.setModel(self.grouped_model)
        self.grouped_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

    def init_canvas(self):
        """初始化绘图画布。"""
        self.cdf_canvas = MplCanvas(self.plot_container, width=6, height=4)
        self.raw_canvas = MplCanvas(self.plot_container, width=6, height=4)
        self.raw_canvas.hide()

        layout = QVBoxLayout(self.plot_container)
        layout.addWidget(self.cdf_canvas)
        layout.addWidget(self.raw_canvas)

    def setup_connections(self):
        """设置信号槽连接。"""
        self.method_combo.currentTextChanged.connect(self.on_method_changed)
        self.clear_btn.clicked.connect(self.clear_data)
        self.load_button.clicked.connect(self.load_from_file)
        self.save_button.clicked.connect(self.save_to_file)
        self.example_button.clicked.connect(self.show_example_dialog)
        self.calculate_button.clicked.connect(self.calculate)
        self.cdf_view_btn.clicked.connect(self.switch_to_cdf_view)
        self.raw_view_btn.clicked.connect(self.switch_to_raw_view)
        self.actionExit.triggered.connect(self.close)
        self.actionAbout.triggered.connect(self._show_about)

    def on_method_changed(self, method_name):
        """处理方法选择变化。"""
        is_up_down = method_name in [
            "Bruceton (升降法)",
            "Dixon-Mood",
            "Langlie",
        ]
        self.step_group.setEnabled(is_up_down)

        if is_up_down:
            self.updown_scroll.show()
            self.grouped_scroll.hide()
            self.data_group.setTitle("数据输入 (升降法 - 40个试验点)")
        else:
            self.updown_scroll.hide()
            self.grouped_scroll.show()
            self.data_group.setTitle("数据输入 (分组法)")

    def clear_data(self):
        """清空所有数据。"""
        if self.updown_scroll.isVisible():
            self.updown_model.clear()
        else:
            self.grouped_model.clear()

    def load_from_file(self):
        """从 JSON 文件加载数据。"""
        file_path, _ = QFileDialog.getOpenFileName(self, "打开数据文件", "", "JSON 文件 (*.json)")
        if file_path:
            try:
                with open(file_path, encoding="utf-8") as f:
                    data = json.load(f)

                if "x" in data:
                    if "responses" in data and "d" in data:
                        self.method_combo.setCurrentText("Bruceton (升降法)")
                        self.updown_model.set_data(data["x"], data["responses"])
                        self.d_input.setText(str(data["d"]))
                    elif "n" in data and "r" in data:
                        self.method_combo.setCurrentText("Probit (概率单位法)")
                        self.grouped_model.set_data(data["x"], data["n"], data["r"])

                logger.info(f"从文件加载数据: {file_path}")
                self.result_text.setText("数据加载成功！")
            except (json.JSONDecodeError, ValueError, OSError) as e:
                self.result_text.setText(f"加载文件时出错: {e}")
                logger.error(f"加载文件时出错: {e}")

    def save_to_file(self):
        """保存数据到 JSON 文件。"""
        file_path, _ = QFileDialog.getSaveFileName(self, "保存数据文件", "", "JSON 文件 (*.json)")
        if file_path:
            try:
                data = {}

                if self.updown_scroll.isVisible():
                    x, responses = self.updown_model.get_data()
                    data["x"] = x
                    data["responses"] = responses
                    try:
                        data["d"] = float(self.d_input.text())
                    except ValueError:
                        data["d"] = 0.2
                else:
                    x, n, r = self.grouped_model.get_data()
                    data["x"] = x
                    data["n"] = n
                    data["r"] = r

                with open(file_path, "w", encoding="utf-8") as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)

                logger.info(f"数据保存到文件: {file_path}")
                self.result_text.setText("数据保存成功！")
            except (OSError, ValueError) as e:
                self.result_text.setText(f"保存文件时出错: {e}")
                logger.error(f"保存文件时出错: {e}")

    def calculate(self):
        """执行计算。"""
        try:
            method_name = self.method_combo.currentText()
            method_class = self.methods[method_name]
            method = method_class()

            if self.updown_scroll.isVisible():
                x, responses = self.updown_model.get_data()
                try:
                    d = float(self.d_input.text())
                except ValueError:
                    d = 0.2
                    self.d_input.setText("0.2")

                if not x or not responses:
                    self.result_text.setText("请输入数据！")
                    return

                result = method.calculate(x, responses, d)
            else:
                x, n, r = self.grouped_model.get_data()

                if not x or not n or not r:
                    self.result_text.setText("请输入数据！")
                    return

                result = method.calculate(x, n, r)

            result_str = self.format_result(result)
            self.result_text.setText(result_str)

            plot_cdf(self.cdf_canvas, result)
            plot_raw_data(self.raw_canvas, result)

            logger.info(f"使用 {method_name} 方法计算完成")

        except (ValueError, RuntimeError) as e:
            self.result_text.setText(f"计算错误: {e}")
            logger.error(f"计算错误: {e}")

    def switch_to_cdf_view(self):
        """切换到 CDF 曲线视图。"""
        self.cdf_canvas.show()
        self.raw_canvas.hide()

    def switch_to_raw_view(self):
        """切换到原始数据视图。"""
        self.cdf_canvas.hide()
        self.raw_canvas.show()

    def format_result(self, result):
        """格式化计算结果。"""
        lines = []
        lines.append("=" * 60)
        lines.append(f"  计算方法: {result.method}")
        lines.append("=" * 60)
        lines.append(f"  均值 (μ):            {result.mu:.6f}")
        lines.append(f"  均值标准误差:        {result.mu_std:.6f}")
        lines.append(f"  标准差 (σ):          {result.sigma:.6f}")
        lines.append(f"  标准差标准误差:      {result.sigma_std:.6f}")

        if result.success_rate:
            lines.append("\n  各刺激水平成功率:")
            for xi in sorted(result.success_rate.keys()):
                rate = result.success_rate[xi]
                lines.append(f"    x={xi:.2f}: {rate:.4f}")

        if result.additional_info:
            lines.append("\n  附加信息:")
            for key, value in result.additional_info.items():
                if key == "optimization_result":
                    continue
                if isinstance(value, float):
                    lines.append(f"    {key}: {value:.4f}")
                else:
                    lines.append(f"    {key}: {value}")

        lines.append("=" * 60)
        return "\n".join(lines)

    def show_example_dialog(self):
        """显示示例数据选择对话框。"""
        dialog = ExampleDialog(self)
        if dialog.exec_():
            method_name, example_name, example_data = dialog.get_selected_example()
            self.load_example_data(method_name, example_name, example_data)

    def load_example_data(self, method_name, example_name, example_data):
        """加载示例数据。"""
        try:
            if method_name is None or example_name is None or example_data is None:
                self.result_text.setText("请选择一个有效的示例数据！")
                return

            self.method_combo.setCurrentText(method_name)

            if "responses" in example_data and "d" in example_data:
                self.updown_model.set_data(example_data["x"], example_data["responses"])
                self.d_input.setText(str(example_data["d"]))
            elif "n" in example_data and "r" in example_data:
                self.grouped_model.set_data(example_data["x"], example_data["n"], example_data["r"])

            desc = example_data.get("description", "")
            self.result_text.setText(
                f"已加载示例: {example_name}\n{desc}\n\n点击「计算」查看结果！",
            )
            logger.info(f"加载示例数据: {example_name}")
        except (ValueError, KeyError, OSError) as e:
            self.result_text.setText(f"加载示例时出错: {e}")
            import traceback

            logger.error(f"加载示例时出错: {e}\n{traceback.format_exc()}")

    def _show_about(self):
        """显示关于对话框。"""
        QMessageBox.about(
            self,
            "关于感度统计计算器",
            "感度统计计算器 GUI\n\n版本 1.0\n\n基于 GJB377B 标准的感度统计计算工具",
        )
