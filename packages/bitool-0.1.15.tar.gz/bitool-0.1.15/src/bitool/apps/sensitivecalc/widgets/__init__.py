"""感度统计计算器的组件模块。"""

from .sensitivecalc import SensitiveCalcGUI

__all__ = ["SensitiveCalcGUI"]
