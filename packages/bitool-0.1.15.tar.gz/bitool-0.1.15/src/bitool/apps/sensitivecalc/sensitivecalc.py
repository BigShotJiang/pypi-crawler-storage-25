#!/usr/bin/env python3
"""感度统计计算器 GUI 应用程序的入口点。"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from bitool.apps.sensitivecalc.gui import main

if __name__ == "__main__":
    main()
