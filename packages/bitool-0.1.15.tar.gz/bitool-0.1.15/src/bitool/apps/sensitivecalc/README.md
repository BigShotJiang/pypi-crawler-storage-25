# Sensitivity Statistics Calculator

基于 GJB377B 标准的感度统计计算器，整合到 bitool 工具集中。

## 功能特性

### 支持的计算方法

1. **Bruceton Method (升降法/up-and-down)**
   - 经典的升降法感度测试分析
   - 适用于连续刺激水平测试

2. **Dixon-Mood Method**
   - Dixon-Mood 方法
   - 升降法的变体

3. **Langlie Method**
   - Langlie 方法
   - 序贯感度测试分析

4. **Probit Method (概率单位法)**
   - 基于正态分布的最大似然估计
   - 适用于分组数据

5. **Logit Method (逻辑单位法)**
   - 基于 Logistic 分布的最大似然估计
   - 适用于分组数据

### 输出结果

- 50% 感度水平 (μ) 及其标准误差
- 标准差 (σ) 及其标准误差
- 各刺激水平的成功率
- CDF 曲线图（GUI 模式）

## 安装

```bash
# 作为 bitool 的一部分安装
pip install bitool

# 或单独安装此模块
pip install bitool-sensitivecalc

# 安装 GUI 支持
pip install bitool-sensitivecalc[gui]
```

## 使用方法

### 命令行界面 (CLI)

```bash
# Bruceton 方法
sensitivecalc bruceton --x 1.0 1.2 1.4 1.2 1.4 1.6 1.4 --responses 0 1 1 0 1 1 1 --d 0.2

# Probit 方法
sensitivecalc probit --x 1.0 1.2 1.4 1.6 1.8 --n 10 10 10 10 10 --r 1 3 6 8 9

# 从 JSON 文件加载数据
sensitivecalc bruceton --file data.json
```

### 图形用户界面 (GUI)

```bash
sensitivecalcgui
```

### 编程接口

```python
from bitool.apps.sensitivecalc import BrucetonMethod, ProbitMethod

# Bruceton 方法
method = BrucetonMethod()
result = method.calculate(
    x=[1.0, 1.2, 1.4, 1.2, 1.4, 1.6, 1.4],
    responses=[0, 1, 1, 0, 1, 1, 1],
    d=0.2
)

print(f"Mean (μ): {result.mu:.4f}")
print(f"Std Dev (σ): {result.sigma:.4f}")

# Probit 方法
method = ProbitMethod()
result = method.calculate(
    x=[1.0, 1.2, 1.4, 1.6, 1.8],
    n=[10, 10, 10, 10, 10],
    r=[1, 3, 6, 8, 9]
)
```

## 数据格式

### 升降法数据格式 (Bruceton/Dixon-Mood/Langlie)

```json
{
    "x": [1.0, 1.2, 1.4, 1.2, 1.4, 1.6, 1.4],
    "responses": [0, 1, 1, 0, 1, 1, 1],
    "d": 0.2
}
```

### 分组数据格式 (Probit/Logit)

```json
{
    "x": [1.0, 1.2, 1.4, 1.6, 1.8],
    "n": [10, 10, 10, 10, 10],
    "r": [1, 3, 6, 8, 9]
}
```

## 整合 bitool 功能

本模块整合了以下 bitool 功能：

- **日志系统**: 使用 `bitool.core.logger` 进行日志记录
- **配置管理**: 可与 bitool 配置系统集成
- **GUI 框架**: 使用 PyQt5 和 matplotlib 构建 GUI

## 开发

### 运行测试

```bash
pytest tests/ -v
```

### 测试覆盖率

```bash
pytest tests/ -v --cov=bitool.apps.sensitivecalc --cov-report=term-missing
```

## 参考

- GJB 377B-2022: 感度试验用升降法

## 许可证

MIT License
