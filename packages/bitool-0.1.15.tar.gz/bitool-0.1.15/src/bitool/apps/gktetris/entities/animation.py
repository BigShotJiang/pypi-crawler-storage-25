"""Animation module for entities."""

from __future__ import annotations

import math
import random
from abc import ABC, abstractmethod
from typing import Any

import pygame

from ..conf import BOARD_WIDTH, CELL_SIZE, COLS, PIECE_COLORS


class BaseAnimation(ABC):
    """所有动画的基类"""

    active: bool

    def __init__(self) -> None:
        self.timer: float = 0.0
        self.active = True

    def update(self, dt: float) -> None:
        self.timer += dt

    @abstractmethod
    def draw(self, *args: Any, **kwargs: Any) -> None:
        raise NotImplementedError


class LineClearAnimation(BaseAnimation, ABC):
    """行消除动画基类"""

    ANIM_PARAMS: dict[str, dict[str, Any]] = {
        "SINGLE": {
            "dur": 0.5,
            "flash_col": (255, 255, 255),
            "flash_a": 180,
            "shrink": True,
            "shake_i": 2,
            "shake_dur": 0.15,
            "particle_n": 6,
            "particle_s": (2, 5),
            "wave": False,
            "screen_flash": False,
            "color_burst": False,
            "extra_glow": False,
        },
        "DOUBLE": {
            "dur": 0.55,
            "flash_col": (255, 220, 100),
            "flash_a": 220,
            "shrink": True,
            "shake_i": 4,
            "shake_dur": 0.2,
            "particle_n": 10,
            "particle_s": (3, 6),
            "wave": False,
            "screen_flash": False,
            "color_burst": False,
            "extra_glow": False,
        },
        "TRIPLE": {
            "dur": 0.65,
            "flash_col": (255, 120, 255),
            "flash_a": 255,
            "shrink": True,
            "shake_i": 6,
            "shake_dur": 0.25,
            "particle_n": 14,
            "particle_s": (3, 7),
            "wave": True,
            "screen_flash": True,
            "color_burst": True,
            "extra_glow": False,
        },
        "TETRIS": {
            "dur": 0.75,
            "flash_col": (255, 200, 50),
            "flash_a": 255,
            "shrink": False,
            "shake_i": 10,
            "shake_dur": 0.35,
            "particle_n": 20,
            "particle_s": (4, 8),
            "wave": True,
            "screen_flash": True,
            "color_burst": True,
            "extra_glow": True,
        },
        "TSPIN": {
            "dur": 0.7,
            "flash_col": (180, 80, 255),
            "flash_a": 255,
            "shrink": True,
            "shake_i": 6,
            "shake_dur": 0.3,
            "particle_n": 16,
            "particle_s": (3, 7),
            "wave": True,
            "screen_flash": True,
            "color_burst": True,
            "extra_glow": False,
        },
        "TSPIN_MINI": {
            "dur": 0.5,
            "flash_col": (160, 120, 255),
            "flash_a": 180,
            "shrink": True,
            "shake_i": 3,
            "shake_dur": 0.2,
            "particle_n": 10,
            "particle_s": (2, 5),
            "wave": False,
            "screen_flash": True,
            "color_burst": False,
            "extra_glow": False,
        },
        "PERFECT": {
            "dur": 1.0,
            "flash_col": (255, 220, 50),
            "flash_a": 255,
            "shrink": False,
            "shake_i": 14,
            "shake_dur": 0.5,
            "particle_n": 30,
            "particle_s": (4, 10),
            "wave": True,
            "screen_flash": True,
            "color_burst": True,
            "extra_glow": True,
        },
        "B2B_TETRIS": {
            "dur": 0.8,
            "flash_col": (255, 150, 50),
            "flash_a": 255,
            "shrink": False,
            "shake_i": 12,
            "shake_dur": 0.4,
            "particle_n": 24,
            "particle_s": (4, 9),
            "wave": True,
            "screen_flash": True,
            "color_burst": True,
            "extra_glow": True,
        },
    }

    def __init__(self, rows: list[int], anim_type: str = "SINGLE", board: list[list[str | None]] | None = None) -> None:
        super().__init__()
        self.rows: list[int] = rows
        self.n: int = len(rows)
        self.anim_type: str = anim_type
        self.board: list[list[str | None]] | None = board
        self.params: dict[str, Any] = self.ANIM_PARAMS.get(anim_type, self.ANIM_PARAMS["SINGLE"])
        self.duration: float = self.params["dur"]

    def update(self, dt: float) -> None:
        super().update(dt)
        if self.timer >= self.duration:
            self.active = False

    @staticmethod
    def _draw_cell(surface: pygame.Surface, rect: pygame.Rect, colors: tuple, brightness: float = 1.0) -> None:
        main, light, dark, _ = colors
        r: int = min(255, int(main[0] * brightness))
        g: int = min(255, int(main[1] * brightness))
        b: int = min(255, int(main[2] * brightness))
        pygame.draw.rect(surface, (r, g, b), rect)
        lr: int = min(255, int(light[0] * brightness))
        lg: int = min(255, int(light[1] * brightness))
        lb: int = min(255, int(light[2] * brightness))
        dr: int = min(255, int(dark[0] * brightness))
        dg: int = min(255, int(dark[1] * brightness))
        db: int = min(255, int(dark[2] * brightness))
        pygame.draw.line(surface, (lr, lg, lb), rect.topleft, rect.topright, 2)
        pygame.draw.line(surface, (lr, lg, lb), rect.topleft, rect.bottomleft, 2)
        pygame.draw.line(surface, (dr, dg, db), rect.bottomleft, rect.bottomright, 2)
        pygame.draw.line(surface, (dr, dg, db), rect.topright, rect.bottomright, 2)

    def _draw_flash(self, surface: pygame.Surface, bx: int, by: int, progress: float, flash_end: float) -> None:
        if progress < flash_end:
            alpha: int = int(self.params["flash_a"] * (progress / flash_end))
            for row in self.rows:
                surf: pygame.Surface = pygame.Surface((BOARD_WIDTH, CELL_SIZE), pygame.SRCALPHA)
                surf.fill((*self.params["flash_col"], alpha))
                surface.blit(surf, (bx, by + row * CELL_SIZE))


class ShrinkLineClear(LineClearAnimation):
    """缩小消失的行消除动画（SINGLE/DOUBLE/TSPIN/TSPIN_MINI/TRIPLE）"""

    def draw(self, surface: pygame.Surface, bx: int, by: int) -> None:
        if not self.active:
            return
        progress: float = self.timer / self.duration
        self._draw_flash(surface, bx, by, progress, 0.25)
        if 0.25 <= progress < 1.0:
            shrink: float = 1.0 - (progress - 0.25) / 0.75
            for row in self.rows:
                for col in range(COLS):
                    cell: str | None = self.board[row][col] if self.board else None
                    if cell:
                        cx: int = bx + col * CELL_SIZE + CELL_SIZE // 2
                        cy: int = by + row * CELL_SIZE + CELL_SIZE // 2
                        w: int = max(1, int(CELL_SIZE * shrink))
                        h: int = max(1, int(CELL_SIZE * shrink))
                        colors = PIECE_COLORS.get(cell, ((200, 200, 200),) * 4)
                        rect: pygame.Rect = pygame.Rect(cx - w // 2, cy - h // 2, w, h)
                        self._draw_cell(surface, rect, colors, 0.7)
        if self.params["wave"]:
            self._draw_wave(surface, bx, by, progress)
        if self.params["extra_glow"] and progress < 0.4:
            self._draw_glow(surface, bx, by, progress)

    def _draw_wave(self, surface: pygame.Surface, bx: int, by: int, progress: float) -> None:
        wave_peak: float = 0.3
        if progress > wave_peak:
            return
        wave_val: float = math.sin(progress / wave_peak * math.pi)
        amplitude: float = CELL_SIZE * 0.4 * wave_val
        for row in self.rows:
            for col in range(COLS):
                cx: int = bx + col * CELL_SIZE + CELL_SIZE // 2
                cy: int = by + row * CELL_SIZE + CELL_SIZE // 2
                offset: int = int(amplitude * math.sin(col * 0.9 + progress * 15))
                if abs(offset) > 2:
                    pygame.draw.circle(
                        surface,
                        self.params["flash_col"],
                        (cx + offset, cy),
                        max(1, int(3 * wave_val)),
                    )

    def _draw_glow(self, surface: pygame.Surface, bx: int, by: int, progress: float) -> None:
        glow_intensity: float = (1.0 - progress / 0.4) * 0.6
        for row in self.rows:
            surf: pygame.Surface = pygame.Surface((BOARD_WIDTH + 20, CELL_SIZE + 20), pygame.SRCALPHA)
            c: tuple[int, int, int] = self.params["flash_col"]
            surf.fill((c[0], c[1], c[2], int(100 * glow_intensity)))
            surface.blit(surf, (bx - 10, by + row * CELL_SIZE - 10))


class DissolveLineClear(LineClearAnimation):
    """溶解消失的行消除动画（TETRIS/PERFECT/B2B_TETRIS）"""

    def draw(self, surface: pygame.Surface, bx: int, by: int) -> None:
        if not self.active:
            return
        progress: float = self.timer / self.duration
        self._draw_flash(surface, bx, by, progress, 0.15)
        if 0.15 <= progress < 1.0:
            t: float = (progress - 0.15) / 0.85
            for row in self.rows:
                for col in range(COLS):
                    cell: str | None = self.board[row][col] if self.board else None
                    if cell:
                        cx: int = bx + col * CELL_SIZE + CELL_SIZE // 2
                        cy: int = by + row * CELL_SIZE + CELL_SIZE // 2
                        offset_y: int = int(t * CELL_SIZE * 1.5)
                        wave: int = int(math.sin(col * 0.8 + t * 8) * CELL_SIZE * 0.4 * t)
                        cx_shake: int = int(math.cos(t * 10 + col) * CELL_SIZE * 0.3 * t)
                        w: int = max(1, int(CELL_SIZE * (1 - t * 0.7)))
                        h: int = max(1, int(CELL_SIZE * (1 - t * 0.3)))
                        colors = PIECE_COLORS.get(cell, ((200, 200, 200),) * 4)
                        rect: pygame.Rect = pygame.Rect(
                            cx - w // 2 + cx_shake,
                            cy - h // 2 + offset_y + wave,
                            w,
                            h,
                        )
                        self._draw_cell(surface, rect, colors, 1.0 - t * 0.6)
        if self.params["wave"]:
            self._draw_wave(surface, bx, by, progress)
        if self.params["extra_glow"] and progress < 0.4:
            self._draw_glow(surface, bx, by, progress)

    def _draw_wave(self, surface: pygame.Surface, bx: int, by: int, progress: float) -> None:
        wave_peak: float = 0.3
        if progress > wave_peak:
            return
        wave_val: float = math.sin(progress / wave_peak * math.pi)
        amplitude: float = CELL_SIZE * 0.4 * wave_val
        for row in self.rows:
            for col in range(COLS):
                cx: int = bx + col * CELL_SIZE + CELL_SIZE // 2
                cy: int = by + row * CELL_SIZE + CELL_SIZE // 2
                offset: int = int(amplitude * math.sin(col * 0.9 + progress * 15))
                if abs(offset) > 2:
                    pygame.draw.circle(
                        surface,
                        self.params["flash_col"],
                        (cx + offset, cy),
                        max(1, int(3 * wave_val)),
                    )

    def _draw_glow(self, surface: pygame.Surface, bx: int, by: int, progress: float) -> None:
        glow_intensity: float = (1.0 - progress / 0.4) * 0.6
        for row in self.rows:
            surf: pygame.Surface = pygame.Surface((BOARD_WIDTH + 20, CELL_SIZE + 20), pygame.SRCALPHA)
            c: tuple[int, int, int] = self.params["flash_col"]
            surf.fill((c[0], c[1], c[2], int(100 * glow_intensity)))
            surface.blit(surf, (bx - 10, by + row * CELL_SIZE - 10))


def create_line_clear_animation(
    rows: list[int],
    anim_type: str = "SINGLE",
    board: list[list[str | None]] | None = None,
) -> LineClearAnimation:
    """工厂函数，根据 anim_type 创建对应的 LineClearAnimation 子类"""
    params: dict[str, Any] = LineClearAnimation.ANIM_PARAMS.get(anim_type, LineClearAnimation.ANIM_PARAMS["SINGLE"])
    if params["shrink"]:
        return ShrinkLineClear(rows, anim_type, board)
    else:
        return DissolveLineClear(rows, anim_type, board)


class ShockwaveAnimation(BaseAnimation):
    """冲击波动画（用于 Tetris / Perfect）"""

    def __init__(self, center_y: float, color: tuple[int, int, int] = (255, 200, 50)) -> None:
        super().__init__()
        self.center_y: float = center_y
        self.color: tuple[int, int, int] = color
        self.duration: float = 0.4

    def draw(self, surface: pygame.Surface, bx: int, by: int) -> None:
        if not self.active:
            return
        t: float = self.timer / self.duration
        radius: int = int(BOARD_WIDTH * (0.5 + t * 1.5))
        alpha: int = int(200 * (1 - t))
        if alpha <= 0:
            return
        cy: int = by + int(self.center_y)
        surf: pygame.Surface = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
        pygame.draw.ellipse(surf, (*self.color, alpha), (0, 0, radius * 2, radius * 2), max(1, int(6 * (1 - t))))
        rect: pygame.Rect = surf.get_rect(center=(bx + BOARD_WIDTH // 2, cy))
        surface.blit(surf, rect)


class ColorBurstAnimation(BaseAnimation):
    """彩虹粒子爆发（用于 Triple / Tetris / T-spin）"""

    def __init__(self, rows: list[int], board: list[list[str | None]]) -> None:
        super().__init__()
        self.particles: list[dict[str, float | int | tuple[int, int, int]]] = []
        self.duration: float = 0.8
        hues: list[int] = [0, 60, 120, 180, 240, 300]
        for row in rows:
            for col in range(COLS):
                if board[row][col]:
                    cx: int = col * CELL_SIZE + CELL_SIZE // 2
                    cy: int = row * CELL_SIZE + CELL_SIZE // 2
                    for _ in range(3):
                        angle: float = random.uniform(0, 2 * math.pi)
                        speed: float = random.uniform(3, 10)
                        hue: int = random.choice(hues)
                        r: int = int(128 + 127 * math.sin(hue * math.pi / 180))
                        g: int = int(128 + 127 * math.sin((hue + 120) * math.pi / 180))
                        b: int = int(128 + 127 * math.sin((hue + 240) * math.pi / 180))
                        self.particles.append({
                            "x": float(cx),
                            "y": float(cy),
                            "vx": math.cos(angle) * speed,
                            "vy": math.sin(angle) * speed - 3,
                            "color": (r, g, b),
                            "life": random.uniform(0.4, 0.8),
                            "max_life": 0.8,
                            "size": random.uniform(2, 5),
                        })

    def update(self, dt: float) -> None:
        super().update(dt)
        for p in self.particles:
            p["x"] += p["vx"] * dt * 60
            p["y"] += p["vy"] * dt * 60
            p["vy"] = p["vy"] + 0.2 * dt * 60
            p["life"] = p["life"] - dt  # type: ignore[operator]
        self.particles = [p for p in self.particles if p["life"] > 0]  # type: ignore[operator]
        if self.timer >= self.duration and not self.particles:
            self.active = False

    def draw(self, surface: pygame.Surface, bx: int, by: int) -> None:
        for p in self.particles:
            alpha: float = max(0, p["life"] / p["max_life"])  # type: ignore[operator]
            size: int = max(1, int(p["size"] * alpha))  # type: ignore[operator]
            c: tuple[int, int, int] = p["color"]  # type: ignore[assignment]
            pygame.draw.circle(surface, c, (bx + int(p["x"]), by + int(p["y"])), size)  # type: ignore[arg-type]


class ScreenFlashAnimation(BaseAnimation):
    """全屏闪光动画"""

    def __init__(
        self,
        color: tuple[int, int, int] = (255, 255, 255),
        duration: float = 0.15,
        intensity: float = 0.4,
    ) -> None:
        super().__init__()
        self.color: tuple[int, int, int] = color
        self.duration: float = duration
        self.intensity: float = intensity

    def draw(self, surface: pygame.Surface, width: int, height: int) -> None:
        if not self.active:
            return
        t: float = self.timer / self.duration
        alpha: int = (
            int(255 * self.intensity * (t / 0.3)) if t < 0.3 else int(255 * self.intensity * (1 - (t - 0.3) / 0.7))
        )
        if alpha <= 0:
            return
        surf: pygame.Surface = pygame.Surface((width, height), pygame.SRCALPHA)
        surf.fill((*self.color, alpha))
        surface.blit(surf, (0, 0))