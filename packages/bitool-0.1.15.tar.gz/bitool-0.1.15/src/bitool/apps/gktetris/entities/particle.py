"""GK Tetris 实体模块 - 包含粒子效果等游戏实体"""

from __future__ import annotations

import math
import random

import pygame

from ..conf import CELL_SIZE, COLS, PIECE_COLORS


class Particle:
    """粒子类 - 用于消除方块时的粒子效果"""

    def __init__(self, x, y, color) -> None:
        self.x = x
        self.y = y
        angle = random.uniform(0, 2 * math.pi)
        speed = random.uniform(2, 8)
        self.vx = math.cos(angle) * speed
        self.vy = math.sin(angle) * speed - random.uniform(1, 4)
        self.color = color
        self.life = random.uniform(0.5, 1.5)
        self.max_life = self.life
        self.size = random.uniform(2, 6)

    def update(self, dt):
        """更新粒子状态

        Args:
            dt: 时间增量

        Returns:
            粒子是否仍然存活
        """
        self.x += self.vx * dt * 60
        self.y += self.vy * dt * 60
        self.vy += 0.15 * dt * 60
        self.life -= dt
        return self.life > 0

    def draw(self, surface) -> None:
        """绘制粒子到指定表面"""
        alpha = max(0, self.life / self.max_life)
        size = max(1, int(self.size * alpha))
        r = min(255, int(self.color[0] * alpha + 255 * (1 - alpha)))
        g = min(255, int(self.color[1] * alpha + 255 * (1 - alpha)))
        b = min(255, int(self.color[2] * alpha + 255 * (1 - alpha)))
        pygame.draw.circle(surface, (r, g, b), (int(self.x), int(self.y)), size)


class ParticleSystem:
    """粒子系统 - 管理所有粒子效果"""

    def __init__(self) -> None:
        self.particles = []

    def emit_row(self, row, board_offset_x, board_offset_y, board) -> None:
        """为消除的行生成粒子效果

        Args:
            row: 消除的行索引
            board_offset_x: 游戏区域 X 偏移
            board_offset_y: 游戏区域 Y 偏移
            board: 游戏板数据
        """
        for col in range(COLS):
            cell = board[row][col]
            if cell:
                cx = board_offset_x + col * CELL_SIZE + CELL_SIZE // 2
                cy = board_offset_y + row * CELL_SIZE + CELL_SIZE // 2
                color = PIECE_COLORS.get(cell, ((255, 255, 255),) * 4)[0]
                for _ in range(8):
                    self.particles.append(Particle(cx, cy, color))

    def update(self, dt) -> None:
        """更新所有粒子状态"""
        self.particles = [p for p in self.particles if p.update(dt)]

    def draw(self, surface) -> None:
        """绘制所有粒子"""
        for p in self.particles:
            p.draw(surface)
