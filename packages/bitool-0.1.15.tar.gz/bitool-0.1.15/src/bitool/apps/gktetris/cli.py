"""GK Tetris 命令行入口模块"""

from __future__ import annotations

import pygame

from bitool.apps.gktetris.game import TetrisGame


def main() -> None:
    """启动 GK Tetris 游戏"""
    pygame.init()
    game = TetrisGame()
    game.run()


if __name__ == "__main__":
    main()
