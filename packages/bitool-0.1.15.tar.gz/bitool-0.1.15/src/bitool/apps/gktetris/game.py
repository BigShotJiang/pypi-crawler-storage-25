"""
GK Tetris - 现代化俄罗斯方块
基于 Pygame, 拥有丰富渐变色彩和动感消除效果
"""

from __future__ import annotations

import contextlib
import math
import random
import sys

import numpy
import pygame

from .conf import (
    ACCENT_COLOR,
    BG_COLOR,
    BOARD_BG,
    BOARD_HEIGHT,
    BOARD_WIDTH,
    BORDER_COLOR,
    BORDER_GLOW,
    CELL_SIZE,
    COLS,
    FPS,
    GRID_COLOR,
    PIECE_COLORS,
    ROWS,
    SCREEN_HEIGHT,
    SCREEN_WIDTH,
    SHAPES,
    SIDEBAR_BG,
    SIDEBAR_WIDTH,
    TEXT_COLOR,
    WALL_KICKS,
)
from .entities.animation import (
    ColorBurstAnimation,
    LineClearAnimation,
    ScreenFlashAnimation,
    ShockwaveAnimation,
    create_line_clear_animation,
)
from .entities.particle import ParticleSystem
from .entities.piece import Piece, PieceGenerator


# ============================================================
# 游戏主类
# ============================================================
class TetrisGame:
    def __init__(self) -> None:
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("🎮 GK Tetris - 现代俄罗斯方块")
        self.clock = pygame.time.Clock()

        def _font(size: int, bold: bool = False) -> pygame.font.Font:
            paths = [
                "C:/Windows/Fonts/simhei.ttf",
                "C:/Windows/Fonts/msyh.ttc",
                "C:/Windows/Fonts/simsun.ttc",
                "C:/Windows/Fonts/arial.ttf",
            ]
            for p in paths:
                try:
                    f = pygame.font.Font(p, size)
                    if bold:
                        f.set_bold(True)
                    return f  # noqa: TRY300
                except Exception:  # noqa: BLE001, S112
                    continue
            f = pygame.font.Font(None, size)
            if bold:
                f.set_bold(True)
            return f

        self.font_large = _font(36, bold=True)
        self.font_medium = _font(22, bold=True)
        self.font_small = _font(16)

        self._init_sounds()

        self.piece_generator = PieceGenerator()
        self.preview_queue = []

        # 游戏区域偏移
        self.board_x = 20
        self.board_y = 40

        # 游戏状态
        self.board = [[None] * COLS for _ in range(ROWS)]
        self.current_piece = None
        self.next_piece = None
        self.held_piece = None
        self.can_hold = True
        self.score = 0
        self.level = 1
        self.lines_cleared = 0
        self.game_over = False
        self.paused = False

        # 技能系统
        self.skill_charges = 0
        self.skill_max_charges = 3
        self.skill_active = False
        self.skill_timer = 0
        self.skill_flash_timer = 0
        self.skill_sweep_rows = []
        self.skill_sweep_progress = 0
        self.skill_lightning_rows = []
        self.skill_lightning_progress = 0

        # 垃圾行系统（对战模式）
        self.pending_garbage = 0
        self.garbage_rows = []
        self.attack_meter = 0

        # 计时
        self.fall_timer = 0
        self.fall_speed = self._get_fall_speed()
        self.lock_timer = 0
        self.lock_delay = 0.5
        self.is_locking = False

        # 动画
        self.particles = ParticleSystem()
        self.clear_animation = None
        self.clearing_rows = []
        self.shockwave = None
        self.color_burst = None
        self.screen_flash = None

        # 视觉效果
        self.glow_timer = 0
        self.shake_timer = 0
        self.shake_intensity = 0
        self.combo_count = 0
        self.b2b_count = 0
        self.last_move_was_rotate = False
        self.tspin_trace = {"was_kick": False}
        self.notification_text = ""
        self.notification_timer = 0

        # 背景星星
        self.stars = [
            (
                random.randint(0, SCREEN_WIDTH),
                random.randint(0, SCREEN_HEIGHT),
                random.uniform(0.5, 2.0),
                random.uniform(0.3, 1.0),
            )
            for _ in range(50)
        ]

        # 初始化方块
        self._spawn_piece()

    def _get_fall_speed(self):
        """根据等级计算下落速度"""
        return max(0.05, 1.0 - (self.level - 1) * 0.08)

    def _spawn_piece(self) -> None:
        self.piece_generator.refill_queue(5)
        if self.next_piece is None:
            self.current_piece = Piece(self.piece_generator.pop())
            self.next_piece = Piece(self.piece_generator.pop())
        else:
            self.current_piece = self.next_piece
            self.next_piece = Piece(self.piece_generator.pop())
        self.can_hold = True
        self.is_locking = False
        self.lock_timer = 0

        for x, y in self.current_piece.get_cells():
            if y < 0 or x < 0 or x >= COLS or y >= ROWS:
                self.game_over = True
                self._play_sound("gameover")
                return
            if self.board[y][x] is not None:
                self.game_over = True
                self._play_sound("gameover")
                return

    def _is_valid_position(self, piece, x_off=0, y_off=0, rotation=None) -> bool:
        if rotation is not None:
            cells = [(piece.x + dx + x_off, piece.y + dy + y_off) for dx, dy in SHAPES[piece.type][rotation]]
        else:
            cells = piece.get_cells_with_offset(x_off, y_off)
        for x, y in cells:
            if x < 0 or x >= COLS or y >= ROWS:
                return False
            if y >= 0 and self.board[y][x] is not None:
                return False
        return True

    def _charge_skill(self, lines: int) -> None:
        self.skill_charges = min(self.skill_max_charges, self.skill_charges + lines)
        if self.skill_charges >= 1:
            self.skill_flash_timer = 0.3

    def _use_skill(self, skill_type: str) -> bool:
        if self.skill_charges <= 0:
            return False
        if self.skill_active:
            return False
        self.skill_charges -= 1
        self.skill_active = True
        self.skill_timer = 0
        self.skill_type = skill_type
        if skill_type == "NUKE":
            self._skill_nuke()
        elif skill_type == "SHOCKWAVE":
            self._skill_shockwave()
        elif skill_type == "LASER":
            self._skill_laser()
        return True

    def _skill_nuke(self) -> None:
        nuke_col = self.current_piece.x + 1 if self.current_piece else COLS // 2
        radius = 2
        self.skill_sweep_rows = []
        for dy in range(-radius, radius + 1):
            row = ROWS // 2 + dy
            if 0 <= row < ROWS:
                cleared = False
                for col in range(max(0, nuke_col - radius), min(COLS, nuke_col + radius + 1)):
                    if self.board[row][col] is not None:
                        self.board[row][col] = None
                        cleared = True
                if cleared:
                    self.skill_sweep_rows.append(row)
        if self.skill_sweep_rows:
            self.skill_sweep_progress = 0
            self._play_sound("skill_nuke")
            self._show_notification("核弹!")
            self.screen_flash = ScreenFlashAnimation(color=(255, 100, 0), duration=0.5, intensity=0.5)
        else:
            self.skill_active = False

    def _skill_shockwave(self) -> None:
        shock_row = self.current_piece.y if self.current_piece else ROWS // 2
        self.skill_sweep_rows = [r for r in range(shock_row - 1, shock_row + 2) if 0 <= r < ROWS]
        for row in self.skill_sweep_rows:
            for col in range(COLS):
                if self.board[row][col] is not None:
                    self.board[row][col] = None
        if self.skill_sweep_rows:
            self.skill_sweep_progress = 0
            self._play_sound("skill_shockwave")
            self._show_notification("冲击波!")
            self.screen_flash = ScreenFlashAnimation(color=(0, 200, 255), duration=0.4, intensity=0.4)
        else:
            self.skill_active = False

    def _skill_laser(self) -> None:
        laser_col = self.current_piece.x + 1 if self.current_piece else COLS // 2
        self.skill_laser_col = max(0, min(COLS - 1, laser_col))
        self.skill_sweep_rows = []
        for row in range(ROWS):
            if self.board[row][self.skill_laser_col] is not None:
                self.board[row][self.skill_laser_col] = None
                self.skill_sweep_rows.append(row)
        if self.skill_sweep_rows:
            self.skill_sweep_progress = 0
            self._play_sound("skill_laser")
            self._show_notification("激光!")
            self.screen_flash = ScreenFlashAnimation(color=(255, 0, 100), duration=0.4, intensity=0.4)
        else:
            self.skill_active = False

    def _add_garbage_rows(self, count: int) -> None:
        for _ in range(count):
            self.garbage_rows.append([None] * COLS)
        if self.garbage_rows:
            self._apply_pending_garbage()

    def _apply_pending_garbage(self) -> None:
        if not self.garbage_rows:
            return
        for _ in range(len(self.garbage_rows)):
            del self.board[0]
            self.board.append(self.garbage_rows.pop(0))
        for row_idx in range(ROWS):
            hole_col = random.randint(0, COLS - 1)
            for col in range(COLS):
                if self.board[row_idx][col] is not None and col != hole_col:
                    self.board[row_idx][col] = "GARBAGE"
        self.pending_garbage = 0

    def _check_tspin(self) -> str:
        """检测 T-spin 状态。返回 'TSPIN', 'TSPIN_MINI' 或 ''"""
        p = self.current_piece
        if p.type != "T":
            return ""
        if not self.last_move_was_rotate:
            return ""
        cx, cy = p.x + 1, p.y + 1
        corners = [
            (cx - 1, cy - 1),
            (cx + 1, cy - 1),
            (cx + 1, cy + 1),
            (cx - 1, cy + 1),
        ]
        filled = 0
        for x, y in corners:
            if y < 0 or (0 <= y < ROWS and 0 <= x < COLS and self.board[y][x] is not None):
                filled += 1
        if filled >= 3:
            return "TSPIN" if self.tspin_trace["was_kick"] else "TSPIN_MINI"
        return ""

    def _show_notification(self, text: str) -> None:
        self.notification_text = text
        self.notification_timer = 1.5

    def _init_sounds(self) -> None:
        try:
            pygame.mixer.init(frequency=22050, size=-8, channels=1, buffer=256)
        except Exception:  # noqa: BLE001
            self.sounds = {}
            return
        self.sounds = {}
        try:

            def _tone(freq, dur, vol):
                n = int(22050 * dur)
                wave = numpy.sin(2 * numpy.pi * freq * numpy.arange(n) / 22050) * vol
                arr = numpy.clip(wave * 32767, -32768, 32767).astype(numpy.int16)
                return pygame.sndarray.make_sound(arr)

            def _noise(dur, vol):
                n = int(22050 * dur)
                wave = numpy.random.uniform(-vol, vol, n)
                arr = numpy.clip(wave * 32767, -32768, 32767).astype(numpy.int16)
                return pygame.sndarray.make_sound(arr)

            self.sounds["move"] = _tone(200, 0.04, 0.15)
            self.sounds["rotate"] = _tone(330, 0.05, 0.2)
            self.sounds["drop"] = _tone(180, 0.08, 0.25)
            self.sounds["clear"] = _tone(523, 0.12, 0.4)
            self.sounds["tetris"] = _tone(659, 0.15, 0.5)
            self.sounds["lock"] = _tone(260, 0.06, 0.3)
            self.sounds["gameover"] = _tone(200, 0.2, 0.5)
            self.sounds["tspin"] = _tone(700, 0.1, 0.45)
            self.sounds["hold"] = _tone(300, 0.04, 0.2)
            self.sounds["skill_nuke"] = _noise(0.4, 0.6)
            self.sounds["skill_shockwave"] = _noise(0.3, 0.5)
            self.sounds["skill_laser"] = _tone(880, 0.2, 0.5)
        except Exception:  # noqa: BLE001
            self.sounds = {}

    def _play_sound(self, name: str) -> None:
        if name in self.sounds and pygame.mixer.get_init():
            with contextlib.suppress(Exception):
                self.sounds[name].play()

    def _rotate_piece(self, direction=1) -> bool:
        old_rotation = self.current_piece.rotation
        new_rotation = (old_rotation + direction) % 4
        kick_table = WALL_KICKS["I"] if self.current_piece.type == "I" else WALL_KICKS["default"]
        kicks = kick_table.get((old_rotation, new_rotation), [(0, 0)])

        self.last_move_was_rotate = True
        for dx, dy in kicks:
            if dx != 0 or dy != 0:
                self.tspin_trace["was_kick"] = True
            if self._is_valid_position(self.current_piece, dx, dy, new_rotation):
                self.current_piece.x += dx
                self.current_piece.y += dy
                self.current_piece.rotation = new_rotation
                if self.is_locking:
                    self.lock_timer = 0
                self._play_sound("rotate")
                return True

        for dx, dy in [(-1, 0), (1, 0), (-2, 0), (2, 0), (-1, 1), (1, 1), (-1, -1), (1, -1)]:
            if dx != 0 or dy != 0:
                self.tspin_trace["was_kick"] = True
            if self._is_valid_position(self.current_piece, dx, dy, new_rotation):
                self.current_piece.x += dx
                self.current_piece.y += dy
                self.current_piece.rotation = new_rotation
                if self.is_locking:
                    self.lock_timer = 0
                self._play_sound("rotate")
                return True
        self.last_move_was_rotate = False
        return False

    def _move_piece(self, dx, dy) -> bool:
        self.last_move_was_rotate = False
        if self._is_valid_position(self.current_piece, dx, dy):
            self.current_piece.x += dx
            self.current_piece.y += dy
            if dy == 0:
                self._play_sound("move")
            if self.is_locking and dy == 0:
                self.lock_timer = 0
            return True
        return False

    def _hard_drop(self) -> None:
        drop_distance = 0
        while self._is_valid_position(self.current_piece, 0, 1):
            self.current_piece.y += 1
            drop_distance += 1
        self.score += drop_distance * 2
        self._play_sound("drop")
        self._lock_piece()

    def _get_ghost_y(self):
        ghost_y = self.current_piece.y
        while True:
            valid = True
            for dx, dy in SHAPES[self.current_piece.type][self.current_piece.rotation]:
                nx = self.current_piece.x + dx
                ny = ghost_y + dy + 1
                if ny >= ROWS or (ny >= 0 and self.board[ny][nx] is not None):
                    valid = False
                    break
            if not valid:
                break
            ghost_y += 1
        return ghost_y

    def _lock_piece(self) -> None:
        for x, y in self.current_piece.get_cells():
            if 0 <= y < ROWS and 0 <= x < COLS:
                self.board[y][x] = self.current_piece.type

        full_rows = [r for r in range(ROWS) if all(self.board[r][c] is not None for c in range(COLS))]
        n = len(full_rows)
        spin_type = self._check_tspin()
        is_perfect = n == 4

        anim_type_map = {
            (1, "", False): "SINGLE",
            (2, "", False): "DOUBLE",
            (3, "", False): "TRIPLE",
            (4, "", False): "TETRIS",
            (4, "", True): "PERFECT",
            (0, "TSPIN", False): "TSPIN",
            (0, "TSPIN_MINI", False): "TSPIN_MINI",
            (1, "TSPIN", False): "TSPIN",
            (2, "TSPIN", False): "TSPIN",
            (3, "TSPIN", False): "TSPIN",
            (4, "TSPIN", False): "TSPIN",
            (4, "TSPIN", True): "PERFECT",
        }
        anim_key = (n, spin_type, is_perfect and n == 4)
        anim_type = anim_type_map.get(anim_key, "SINGLE")

        if n > 0:
            self.clearing_rows = full_rows
            p = LineClearAnimation.ANIM_PARAMS[anim_type]
            self.clear_animation = create_line_clear_animation(full_rows, anim_type=anim_type, board=self.board)
            self.particles.emit_row(full_rows[0], self.board_x, self.board_y, self.board)
            if n > 1:
                self.particles.emit_row(full_rows[-1], self.board_x, self.board_y, self.board)
            self.shake_timer = p["shake_dur"]
            self.shake_intensity = p["shake_i"]
            self.combo_count += 1
            self._charge_skill(n)

            if p["color_burst"]:
                self.color_burst = ColorBurstAnimation(full_rows, self.board)
            if p["screen_flash"]:
                self.screen_flash = ScreenFlashAnimation(color=p["flash_col"], duration=0.2, intensity=0.3)
            if p["extra_glow"]:
                center_y = sum(full_rows) / len(full_rows) * CELL_SIZE + CELL_SIZE // 2
                self.shockwave = ShockwaveAnimation(center_y, color=p["flash_col"])
        else:
            self.combo_count = 0
            self._spawn_piece()

        base_score = 0
        if spin_type == "TSPIN":
            line_score = {1: 300, 2: 500, 3: 800, 4: 1000}
            base_score = line_score.get(n, 0)
        elif spin_type == "TSPIN_MINI":
            line_score = {1: 100, 2: 200, 3: 400, 4: 600}
            base_score = line_score.get(n, 0)
        elif n > 0:
            base_score = {1: 100, 2: 300, 3: 500, 4: 800}.get(n, 0)

        b2b_active = is_perfect or (n > 0 and self.b2b_count >= 1)
        if b2b_active and n > 0:
            base_score = int(base_score * 1.5)
            self.b2b_count += 1
        elif n > 0:
            self.b2b_count = 0

        combo_bonus = self.combo_count * 50 if self.combo_count > 1 else 0
        self.score += (base_score + combo_bonus) * self.level
        self.lines_cleared += n
        self.level = self.lines_cleared // 10 + 1
        self.fall_speed = self._get_fall_speed()

        if spin_type == "TSPIN":
            if is_perfect:
                self._show_notification("PERFECT CLEAR!")
            elif n > 0:
                self._show_notification(f"TSPIN {n}L")
        elif spin_type == "TSPIN_MINI":
            self._show_notification("MINI TSPIN")
        elif is_perfect:
            self._show_notification("PERFECT CLEAR!")
        elif n == 4:
            self._show_notification("QUAD!")
        elif self.combo_count >= 3:
            self._show_notification(f"COMBO x{self.combo_count}")

        if n == 0:
            self._play_sound("lock")
        elif n == 4:
            self._play_sound("tetris")
        elif spin_type:
            self._play_sound("tspin")
        else:
            self._play_sound("clear")

        self.last_move_was_rotate = False
        self.tspin_trace["was_kick"] = False

    def _remove_cleared_rows(self) -> None:
        for row in sorted(self.clearing_rows, reverse=True):
            del self.board[row]
            self.board.insert(0, [None] * COLS)
        self.clearing_rows = []
        self.clear_animation = None
        self.shockwave = None
        self.color_burst = None
        self.screen_flash = None
        
        # 检查是否有新的完整行形成（连锁消除）
        full_rows = [r for r in range(ROWS) if all(self.board[r][c] is not None for c in range(COLS))]
        n = len(full_rows)
        
        if n > 0:
            # 有新的完整行，继续消除
            self.clearing_rows = full_rows
            anim_type_map = {
                1: "SINGLE",
                2: "DOUBLE",
                3: "TRIPLE",
                4: "TETRIS",
            }
            anim_type = anim_type_map.get(n, "SINGLE")
            p = LineClearAnimation.ANIM_PARAMS[anim_type]
            self.clear_animation = create_line_clear_animation(full_rows, anim_type=anim_type, board=self.board)
            self.particles.emit_row(full_rows[0], self.board_x, self.board_y, self.board)
            if n > 1:
                self.particles.emit_row(full_rows[-1], self.board_x, self.board_y, self.board)
            self.shake_timer = p["shake_dur"]
            self.shake_intensity = p["shake_i"]
            self.combo_count += 1
            self._charge_skill(n)

            if p["color_burst"]:
                self.color_burst = ColorBurstAnimation(full_rows, self.board)
            if p["screen_flash"]:
                self.screen_flash = ScreenFlashAnimation(color=p["flash_col"], duration=0.2, intensity=0.3)
            if p["extra_glow"]:
                center_y = sum(full_rows) / len(full_rows) * CELL_SIZE + CELL_SIZE // 2
                self.shockwave = ShockwaveAnimation(center_y, color=p["flash_col"])
            
            # 更新分数和消除行数
            base_score = {1: 100, 2: 300, 3: 500, 4: 800}.get(n, 0)
            combo_bonus = self.combo_count * 50 if self.combo_count > 1 else 0
            self.score += (base_score + combo_bonus) * self.level
            self.lines_cleared += n
            self.level = self.lines_cleared // 10 + 1
            self.fall_speed = self._get_fall_speed()
            
            # 显示通知
            if n == 4:
                self._show_notification("QUAD!")
            elif self.combo_count >= 3:
                self._show_notification(f"COMBO x{self.combo_count}")
            
            # 播放音效
            if n == 4:
                self._play_sound("tetris")
            else:
                self._play_sound("clear")
        else:
            # 没有新的完整行，结束连锁消除，生成新方块
            self.skill_charges = 0
            self.skill_active = False
            self.skill_timer = 0
            self.skill_flash_timer = 0
            self.skill_sweep_rows = []
            self.skill_sweep_progress = 0
            self.skill_lightning_rows = []
            self.skill_lightning_progress = 0
            self.pending_garbage = 0
            self.garbage_rows = []
            self.attack_meter = 0
            self.piece_generator.clear()
            self._spawn_piece()

    def _hold_piece(self) -> None:
        if not self.can_hold:
            return
        self.can_hold = False
        self._play_sound("hold")
        if self.held_piece is None:
            self.held_piece = Piece(self.current_piece.type)
            self._spawn_piece()
        else:
            old_type = self.held_piece.type
            self.held_piece = Piece(self.current_piece.type)
            self.current_piece = Piece(old_type)

    def _draw_gradient_cell(self, surface, x, y, colors, alpha=1.0, glow=False) -> None:
        """绘制带渐变效果的方块"""
        main, light, dark, glow_color = colors
        pygame.Rect(x, y, CELL_SIZE, CELL_SIZE)

        # 发光效果
        if glow:
            glow_surf = pygame.Surface((CELL_SIZE + 8, CELL_SIZE + 8), pygame.SRCALPHA)
            glow_alpha = int(40 * alpha * (0.7 + 0.3 * math.sin(self.glow_timer * 3)))
            pygame.draw.rect(
                glow_surf,
                (*glow_color, glow_alpha),
                (0, 0, CELL_SIZE + 8, CELL_SIZE + 8),
                border_radius=4,
            )
            surface.blit(glow_surf, (x - 4, y - 4))

        # 主体渐变
        inner_rect = pygame.Rect(x + 1, y + 1, CELL_SIZE - 2, CELL_SIZE - 2)

        # 绘制渐变（从上到下：亮→主→暗）
        for i in range(CELL_SIZE - 2):
            t = i / (CELL_SIZE - 2)
            if t < 0.3:
                # 顶部高光
                lt = t / 0.3
                r = int(light[0] * (1 - lt) + main[0] * lt)
                g = int(light[1] * (1 - lt) + main[1] * lt)
                b = int(light[2] * (1 - lt) + main[2] * lt)
            elif t < 0.7:
                # 中间主体
                r, g, b = main
            else:
                # 底部阴影
                lt = (t - 0.7) / 0.3
                r = int(main[0] * (1 - lt) + dark[0] * lt)
                g = int(main[1] * (1 - lt) + dark[1] * lt)
                b = int(main[2] * (1 - lt) + dark[2] * lt)

            r = min(255, max(0, int(r * alpha)))
            g = min(255, max(0, int(g * alpha)))
            b = min(255, max(0, int(b * alpha)))
            pygame.draw.line(surface, (r, g, b), (x + 1, y + 1 + i), (x + CELL_SIZE - 2, y + 1 + i))

        # 内部高光（玻璃效果）
        highlight_rect = pygame.Rect(x + 3, y + 3, CELL_SIZE - 10, (CELL_SIZE - 6) // 3)
        highlight_surf = pygame.Surface((highlight_rect.width, highlight_rect.height), pygame.SRCALPHA)
        highlight_surf.fill((255, 255, 255, int(35 * alpha)))
        surface.blit(highlight_surf, highlight_rect.topleft)

        # 边框
        border_alpha = int(180 * alpha)
        pygame.draw.rect(surface, (*light, border_alpha), inner_rect, 1, border_radius=2)

    def _draw_board(self, surface) -> None:
        """绘制游戏区域"""
        # 震动偏移
        shake_x, shake_y = 0, 0
        if self.shake_timer > 0:
            shake_x = random.randint(-int(self.shake_intensity), int(self.shake_intensity))
            shake_y = random.randint(-int(self.shake_intensity), int(self.shake_intensity))

        bx = self.board_x + shake_x
        by = self.board_y + shake_y

        # 游戏区域背景
        board_rect = pygame.Rect(bx - 2, by - 2, BOARD_WIDTH + 4, BOARD_HEIGHT + 4)
        # 外发光边框
        glow_surf = pygame.Surface((BOARD_WIDTH + 16, BOARD_HEIGHT + 16), pygame.SRCALPHA)
        glow_alpha = int(30 + 15 * math.sin(self.glow_timer * 2))
        pygame.draw.rect(
            glow_surf,
            (*BORDER_GLOW, glow_alpha),
            (0, 0, BOARD_WIDTH + 16, BOARD_HEIGHT + 16),
            border_radius=6,
        )
        surface.blit(glow_surf, (bx - 10, by - 10))

        pygame.draw.rect(surface, BOARD_BG, board_rect, border_radius=4)
        pygame.draw.rect(surface, BORDER_COLOR, board_rect, 2, border_radius=4)

        # 网格线
        for row in range(ROWS + 1):
            y = by + row * CELL_SIZE
            pygame.draw.line(surface, GRID_COLOR, (bx, y), (bx + BOARD_WIDTH, y))
        for col in range(COLS + 1):
            x = bx + col * CELL_SIZE
            pygame.draw.line(surface, GRID_COLOR, (x, by), (x, by + BOARD_HEIGHT))

        # 已放置的方块
        for row in range(ROWS):
            for col in range(COLS):
                if self.board[row][col] is not None:
                    # 跳过正在消除动画中的行
                    if self.clear_animation and row in self.clearing_rows:
                        continue
                    colors = PIECE_COLORS[self.board[row][col]]
                    self._draw_gradient_cell(surface, bx + col * CELL_SIZE, by + row * CELL_SIZE, colors)

        # 消除动画
        if self.clear_animation:
            self.clear_animation.draw(surface, bx, by)

        # 幽灵方块
        if self.current_piece and not self.game_over:
            ghost_y = self._get_ghost_y()
            for dx, dy in SHAPES[self.current_piece.type][self.current_piece.rotation]:
                gx = bx + (self.current_piece.x + dx) * CELL_SIZE
                gy = by + (ghost_y + dy) * CELL_SIZE
                ghost_surf = pygame.Surface((CELL_SIZE, CELL_SIZE), pygame.SRCALPHA)
                main = self.current_piece.colors[0]
                pygame.draw.rect(ghost_surf, (*main, 40), (0, 0, CELL_SIZE, CELL_SIZE), border_radius=2)
                pygame.draw.rect(ghost_surf, (*main, 80), (0, 0, CELL_SIZE, CELL_SIZE), 2, border_radius=2)
                surface.blit(ghost_surf, (gx, gy))

        # 当前方块
        if self.current_piece and not self.game_over:
            for dx, dy in SHAPES[self.current_piece.type][self.current_piece.rotation]:
                px = bx + (self.current_piece.x + dx) * CELL_SIZE
                py = by + (self.current_piece.y + dy) * CELL_SIZE
                self._draw_gradient_cell(surface, px, py, self.current_piece.colors, glow=True)

        # 粒子效果
        self.particles.draw(surface)
        if self.shockwave:
            self.shockwave.draw(surface, bx, by)
        if self.color_burst:
            self.color_burst.draw(surface, bx, by)

    def _draw_mini_piece(self, surface, piece_type, x, y, cell_size=20) -> None:
        """绘制小预览方块"""
        if piece_type is None:
            return
        colors = PIECE_COLORS[piece_type]
        shape = SHAPES[piece_type][0]
        # 计算居中偏移
        min_x = min(dx for dx, dy in shape)
        max_x = max(dx for dx, dy in shape)
        min_y = min(dy for dx, dy in shape)
        max_y = max(dy for dx, dy in shape)
        w = (max_x - min_x + 1) * cell_size
        h = (max_y - min_y + 1) * cell_size
        ox = x - w // 2
        oy = y - h // 2

        for dx, dy in shape:
            cx = ox + (dx - min_x) * cell_size
            cy = oy + (dy - min_y) * cell_size
            rect = pygame.Rect(cx, cy, cell_size, cell_size)
            main, light, dark, _ = colors
            # 简化渐变
            for i in range(cell_size):
                t = i / cell_size
                if t < 0.3:
                    lt = t / 0.3
                    r = int(light[0] * (1 - lt) + main[0] * lt)
                    g = int(light[1] * (1 - lt) + main[1] * lt)
                    b = int(light[2] * (1 - lt) + main[2] * lt)
                else:
                    lt = (t - 0.3) / 0.7
                    r = int(main[0] * (1 - lt) + dark[0] * lt)
                    g = int(main[1] * (1 - lt) + dark[1] * lt)
                    b = int(main[2] * (1 - lt) + dark[2] * lt)
                pygame.draw.line(surface, (r, g, b), (cx, cy + i), (cx + cell_size - 1, cy + i))
            pygame.draw.rect(surface, light, rect, 1, border_radius=1)

    def _draw_sidebar(self, surface) -> None:
        """绘制侧边栏"""
        sx = self.board_x + BOARD_WIDTH + 20
        sy = self.board_y

        # 侧边栏背景
        sidebar_rect = pygame.Rect(sx - 5, sy - 5, SIDEBAR_WIDTH, BOARD_HEIGHT + 10)
        pygame.draw.rect(surface, SIDEBAR_BG, sidebar_rect, border_radius=8)
        pygame.draw.rect(surface, BORDER_COLOR, sidebar_rect, 1, border_radius=8)

        # 标题
        title = self.font_large.render("GK", True, ACCENT_COLOR)
        surface.blit(title, (sx + 10, sy + 5))
        title2 = self.font_large.render("TETRIS", True, TEXT_COLOR)
        surface.blit(title2, (sx + 10 + title.get_width() + 5, sy + 5))

        # 分数
        y_pos = sy + 60
        self._draw_label(surface, "分数", sx + 10, y_pos)
        score_text = self.font_medium.render(f"{self.score:,}", True, ACCENT_COLOR)
        surface.blit(score_text, (sx + 10, y_pos + 22))

        # 等级
        y_pos += 60
        self._draw_label(surface, "等级", sx + 10, y_pos)
        level_text = self.font_medium.render(str(self.level), True, ACCENT_COLOR)
        surface.blit(level_text, (sx + 10, y_pos + 22))

        # 消除行数
        y_pos += 60
        self._draw_label(surface, "消除", sx + 10, y_pos)
        lines_text = self.font_medium.render(str(self.lines_cleared), True, ACCENT_COLOR)
        surface.blit(lines_text, (sx + 10, y_pos + 22))

        # 下一个方块
        y_pos = sy + 280
        self._draw_label(surface, "下一个", sx + 10, y_pos)
        preview_rect = pygame.Rect(sx + 10, y_pos + 25, SIDEBAR_WIDTH - 30, 70)
        pygame.draw.rect(surface, (15, 15, 30), preview_rect, border_radius=6)
        pygame.draw.rect(surface, BORDER_COLOR, preview_rect, 1, border_radius=6)
        if self.next_piece:
            self._draw_mini_piece(
                surface,
                self.next_piece.type,
                sx + 10 + (SIDEBAR_WIDTH - 30) // 2,
                y_pos + 25 + 35,
                cell_size=22,
            )

        # 队列预览（横向排列，标签+方块一行）
        y_pos += 95
        self._draw_label(surface, "队列", sx + 10, y_pos)
        queue_bg = pygame.Rect(sx + 10, y_pos + 22, SIDEBAR_WIDTH - 30, 50)
        pygame.draw.rect(surface, (15, 15, 30), queue_bg, border_radius=6)
        pygame.draw.rect(surface, BORDER_COLOR, queue_bg, 1, border_radius=6)
        for i in range(3):
            ty = self.piece_generator.peek(i) if hasattr(self, "piece_generator") else "I"
            self._draw_mini_piece(
                surface,
                ty,
                sx + 10 + 30 + i * 50,
                y_pos + 47,
                cell_size=14,
            )

        # 暂存方块
        y_pos += 80
        self._draw_label(surface, "暂存 [C]", sx + 10, y_pos)
        hold_rect = pygame.Rect(sx + 10, y_pos + 25, SIDEBAR_WIDTH - 30, 70)
        pygame.draw.rect(surface, (15, 15, 30), hold_rect, border_radius=6)
        pygame.draw.rect(surface, BORDER_COLOR, hold_rect, 1, border_radius=6)
        if self.held_piece:
            self._draw_mini_piece(
                surface,
                self.held_piece.type,
                sx + 10 + (SIDEBAR_WIDTH - 30) // 2,
                y_pos + 25 + 35,
                cell_size=22,
            )

        # 技能充能（底部独立区块）
        y_pos += 95
        skill_bg = pygame.Rect(sx + 10, y_pos, SIDEBAR_WIDTH - 30, 80)
        pygame.draw.rect(surface, (15, 15, 30), skill_bg, border_radius=6)
        pygame.draw.rect(surface, BORDER_COLOR, skill_bg, 1, border_radius=6)
        self._draw_label(surface, "技能", sx + 18, y_pos + 6)
        bar_w = SIDEBAR_WIDTH - 36
        bar_h = 14
        bar_rect = pygame.Rect(sx + 18, y_pos + 26, bar_w, bar_h)
        pygame.draw.rect(surface, (25, 25, 45), bar_rect, border_radius=4)
        if self.skill_max_charges > 0:
            fill_w = int(bar_w * self.skill_charges / self.skill_max_charges)
            if fill_w > 0:
                charge_color = (255, 100, 0) if self.skill_charges >= self.skill_max_charges else (80, 160, 255)
                pygame.draw.rect(surface, charge_color, (sx + 18, y_pos + 26, fill_w, bar_h), border_radius=4)
            charge_text = self.font_small.render(f"{self.skill_charges}/{self.skill_max_charges}", True, TEXT_COLOR)
            surface.blit(charge_text, (sx + 18 + bar_w // 2 - charge_text.get_width() // 2, y_pos + 26))
        skill_keys = [("X", "核弹", (255, 100, 0)), ("S", "波", (0, 200, 255)), ("F", "激光", (255, 0, 100))]
        key_y = y_pos + 48
        for idx, (key, label, kc) in enumerate(skill_keys):
            kx = sx + 18 + idx * 62
            pygame.draw.circle(surface, kc, (kx + 8, key_y + 8), 10)
            kt = self.font_small.render(key, True, (255, 255, 255))
            surface.blit(kt, (kx + 8 - kt.get_width() // 2, key_y + 8 - kt.get_height() // 2))
            lt = self.font_small.render(label, True, (140, 140, 180))
            surface.blit(lt, (kx + 20, key_y + 2))

        # 操作说明
        y_pos = sy + BOARD_HEIGHT - 130
        controls = [
            "← → 移动",
            "↑ 旋转",
            "↓ 软降",
            "空格 硬降",
            "C 暂存",
            "P 暂停",
            "X 核弹",
            "S 冲击波",
            "F 激光",
        ]
        self._draw_label(surface, "操作", sx + 10, y_pos)
        for i, ctrl in enumerate(controls):
            text = self.font_small.render(ctrl, True, (120, 120, 160))
            surface.blit(text, (sx + 15, y_pos + 24 + i * 18))

    def _draw_label(self, surface, text, x, y) -> None:
        """绘制标签"""
        label = self.font_small.render(text, True, (140, 140, 180))
        surface.blit(label, (x, y))

    def _draw_background(self, surface) -> None:
        """绘制动态背景"""
        surface.fill(BG_COLOR)
        # 星星闪烁
        for sx, sy, size, brightness in self.stars:
            alpha = brightness * (0.5 + 0.5 * math.sin(self.glow_timer * 2 + sx))
            color_val = int(80 * alpha)
            pygame.draw.circle(surface, (color_val, color_val, color_val + 20), (int(sx), int(sy)), max(1, int(size)))

    def _draw_game_over(self, surface) -> None:
        """绘制游戏结束画面"""
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 150))
        surface.blit(overlay, (0, 0))

        # 游戏结束文字
        go_text = self.font_large.render("游戏结束", True, (255, 80, 80))
        go_rect = go_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 40))
        surface.blit(go_text, go_rect)

        score_text = self.font_medium.render(f"最终分数: {self.score:,}", True, TEXT_COLOR)
        score_rect = score_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 10))
        surface.blit(score_text, score_rect)

        restart_text = self.font_medium.render("按 R 重新开始", True, ACCENT_COLOR)
        restart_rect = restart_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 50))
        # 闪烁效果
        if int(self.glow_timer * 2) % 2:
            surface.blit(restart_text, restart_rect)

    def _draw_paused(self, surface) -> None:
        """绘制暂停画面"""
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 120))
        surface.blit(overlay, (0, 0))

        pause_text = self.font_large.render("暂停", True, TEXT_COLOR)
        pause_rect = pause_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
        surface.blit(pause_text, pause_rect)

        hint_text = self.font_medium.render("按 P 继续", True, ACCENT_COLOR)
        hint_rect = hint_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 45))
        surface.blit(hint_text, hint_rect)

    def _draw_notification(self, surface) -> None:
        if self.notification_timer <= 0 or not self.notification_text:
            return
        fade_start = 1.2
        alpha = min(1.0, self.notification_timer / 0.3)
        if self.notification_timer < fade_start:
            alpha = self.notification_timer / fade_start
        if self.notification_text.startswith("TSPIN"):
            notif_color = (200, 80, 255)
        elif self.notification_text.startswith("MINI"):
            notif_color = (180, 120, 255)
        elif self.notification_text in ("QUAD", "PERFECT CLEAR!"):
            notif_color = (255, 220, 50)
        elif self.notification_text.startswith("COMBO"):
            notif_color = (255, 160, 50)
        else:
            notif_color = (100, 200, 255)
        text_surf = self.font_medium.render(self.notification_text, True, notif_color)
        text_surf.set_alpha(int(255 * alpha))
        text_rect = text_surf.get_rect(center=(BOARD_WIDTH // 2, 25))
        notif_surf = pygame.Surface((BOARD_WIDTH, 50), pygame.SRCALPHA)
        notif_surf.blit(text_surf, text_rect)
        surface.blit(
            notif_surf,
            (self.board_x, self.board_y + BOARD_HEIGHT // 2 - 25),
        )

    def reset(self) -> None:
        """重置游戏"""
        self.board = [[None] * COLS for _ in range(ROWS)]
        self.current_piece = None
        self.next_piece = None
        self.held_piece = None
        self.can_hold = True
        self.score = 0
        self.level = 1
        self.lines_cleared = 0
        self.game_over = False
        self.paused = False
        self.fall_timer = 0
        self.fall_speed = self._get_fall_speed()
        self.lock_timer = 0
        self.is_locking = False
        self.particles = ParticleSystem()
        self.clear_animation = None
        self.clearing_rows = []
        self.shake_timer = 0
        self.combo_count = 0
        self.b2b_count = 0
        self.last_move_was_rotate = False
        self.tspin_trace["was_kick"] = False
        self.notification_text = ""
        self.notification_timer = 0
        self.shockwave = None
        self.color_burst = None
        self.screen_flash = None
        self._spawn_piece()

    def run(self) -> None:
        """游戏主循环"""
        running = True
        das_timer = 0
        das_direction = 0
        das_delay = 0.17
        das_repeat = 0.05
        das_active = False

        while running:
            dt = self.clock.tick(FPS) / 1000.0
            self.glow_timer += dt

            # 事件处理
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False

                    if self.game_over:
                        if event.key == pygame.K_r:
                            self.reset()
                        continue

                    if event.key == pygame.K_p:
                        self.paused = not self.paused
                        continue

                    if self.paused:
                        continue

                    if self.clear_animation:
                        continue

                    if event.key == pygame.K_LEFT:
                        self._move_piece(-1, 0)
                        das_direction = -1
                        das_timer = 0
                        das_active = False
                    elif event.key == pygame.K_RIGHT:
                        self._move_piece(1, 0)
                        das_direction = 1
                        das_timer = 0
                        das_active = False
                    elif event.key == pygame.K_UP:
                        self._rotate_piece(1)
                    elif event.key == pygame.K_z:
                        self._rotate_piece(-1)
                    elif event.key == pygame.K_DOWN:
                        self._move_piece(0, 1)
                        self.fall_timer = 0
                    elif event.key == pygame.K_SPACE:
                        self._hard_drop()
                    elif event.key == pygame.K_c:
                        self._hold_piece()
                    elif event.key == pygame.K_x:
                        self._use_skill("NUKE")
                    elif event.key == pygame.K_s:
                        self._use_skill("SHOCKWAVE")
                    elif event.key == pygame.K_f:
                        self._use_skill("LASER")

                if event.type == pygame.KEYUP and event.key in (pygame.K_LEFT, pygame.K_RIGHT):
                    das_direction = 0
                    das_active = False

            if self.paused or self.game_over:
                # 绘制
                self._draw_background(self.screen)
                self._draw_board(self.screen)
                self._draw_sidebar(self.screen)
                if self.game_over:
                    self._draw_game_over(self.screen)
                if self.paused:
                    self._draw_paused(self.screen)
                pygame.display.flip()
                continue

            # 软降
            if das_direction != 0 and not self.clear_animation:
                das_timer += dt
                if not das_active and das_timer >= das_delay:
                    das_active = True
                    das_timer = 0
                if das_active and das_timer >= das_repeat:
                    self._move_piece(das_direction, 0)
                    das_timer = 0

            # 消除动画更新
            if self.clear_animation:
                self.clear_animation.update(dt)
                self.particles.update(dt)
                if not self.clear_animation.active:
                    self._remove_cleared_rows()
            else:
                # 自动下落
                self.fall_timer += dt
                if self.fall_timer >= self.fall_speed:
                    self.fall_timer = 0
                    if self._move_piece(0, 1):
                        if pygame.key.get_pressed()[pygame.K_DOWN]:
                            self.score += 1
                    else:
                        if not self.is_locking:
                            self.is_locking = True
                            self.lock_timer = 0

                # 锁定计时
                if self.is_locking:
                    self.lock_timer += dt
                    # 检查是否还能下移
                    if self._is_valid_position(self.current_piece, 0, 1):
                        self.is_locking = False
                        self.lock_timer = 0
                    elif self.lock_timer >= self.lock_delay:
                        self._lock_piece()

            # 更新震动
            if self.shake_timer > 0:
                self.shake_timer -= dt
                self.shake_intensity *= 0.9

            # 更新粒子和特效动画
            self.particles.update(dt)
            if self.shockwave:
                self.shockwave.update(dt)
                if not self.shockwave.active:
                    self.shockwave = None
            if self.color_burst:
                self.color_burst.update(dt)
                if not self.color_burst.active:
                    self.color_burst = None
            if self.screen_flash:
                self.screen_flash.update(dt)
                if not self.screen_flash.active:
                    self.screen_flash = None

            # 更新通知
            if self.notification_timer > 0:
                self.notification_timer -= dt

            # 绘制
            self._draw_background(self.screen)
            self._draw_board(self.screen)
            self._draw_notification(self.screen)
            self._draw_sidebar(self.screen)

            if self.screen_flash:
                self.screen_flash.draw(self.screen, SCREEN_WIDTH, SCREEN_HEIGHT)

            pygame.display.flip()

        pygame.quit()
        sys.exit()


# ============================================================
# 启动游戏
# ============================================================
if __name__ == "__main__":
    game = TetrisGame()
    game.run()
