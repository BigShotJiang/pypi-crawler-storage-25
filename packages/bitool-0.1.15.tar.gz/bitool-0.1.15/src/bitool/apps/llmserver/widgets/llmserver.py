"""Llama本地模型服务器GUI界面模块."""

from __future__ import annotations

import os
from pathlib import Path

from bitool.apps.llmserver.conf import conf
from bitool.apps.llmserver.threads import ServerWorker
from bitool.core import logger
from bitool.gui import apply_theme, load_ui
from bitool.gui.compat import (
    QBrush,
    QCloseEvent,
    QColor,
    QDesktopServices,
    QFileDialog,
    QLineEdit,
    QMainWindow,
    QMoveEvent,
    QPushButton,
    QResizeEvent,
    QSpinBox,
    QTextCharFormat,
    QTextCursor,
    QTextEdit,
    QUrl,
)


class LLMServer(QMainWindow):
    """Llama本地模型服务器GUI界面类."""

    # 颜色常量
    COLOR_ERROR = QColor(255, 0, 0)
    COLOR_WARNING = QColor(255, 165, 0)
    COLOR_INFO = QColor(0, 0, 0)

    load_model_btn: QPushButton
    start_btn: QPushButton
    port_spin: QSpinBox
    threads_spin: QSpinBox
    model_path_input: QLineEdit
    output_area: QTextEdit
    browser_btn: QPushButton

    def __init__(self) -> None:
        """初始化Llama本地模型服务器."""
        super().__init__()

        load_ui(parent=self)

        self.setWindowTitle(conf.TITLE)

        # 从配置中应用窗口几何属性
        self.setGeometry(conf.WIN_POS[0], conf.WIN_POS[1], conf.WIN_SIZE[0], conf.WIN_SIZE[1])

        self.server_worker: ServerWorker | None = None

        apply_theme(self, "high_contrast")

        # 初始化UI文本
        self._update_ui_text()

        # 连接信号
        self._connect_signals()

        # 将加载的配置应用到UI控件
        self.apply_config_to_ui()

    def _connect_signals(self) -> None:
        """连接UI信号与处理函数."""
        self.load_model_btn.clicked.connect(self.on_load_model)
        self.start_btn.clicked.connect(self.toggle_server)
        self.browser_btn.clicked.connect(self.on_start_browser)
        self.port_spin.valueChanged.connect(self.on_config_changed)
        self.threads_spin.valueChanged.connect(self.on_config_changed)
        self.model_path_input.textChanged.connect(self._update_model_path_tooltip)

        # 配置微调框范围
        self.port_spin.setRange(*conf.LISTEN_PORT_RNG)
        self.threads_spin.setRange(*conf.THREAD_COUNT_RNG)

        # 为不同类型的消息设置颜色
        self.error_format = self.create_text_format(self.COLOR_ERROR)
        self.warning_format = self.create_text_format(self.COLOR_WARNING)
        self.info_format = self.create_text_format(self.COLOR_INFO)

    def _update_ui_text(self) -> None:
        """更新所有UI文本元素."""
        # 更新基本UI元素
        self.setWindowTitle("Llama 本地模型服务器 v1.0")
        self.model_path_input.setPlaceholderText("选择模型文件...")
        self.output_area.setPlaceholderText("服务器输出将显示在这里...")

        # 根据状态更新开始按钮
        self._update_start_button_text()

    def _update_start_button_text(self) -> None:
        """根据服务器状态更新开始按钮文本."""
        if self.server_worker and self.server_worker.isRunning():
            self.start_btn.setText("停止服务器")
        else:
            self.start_btn.setText("启动服务器")

    @staticmethod
    def create_text_format(color: QColor) -> QTextCharFormat:
        """创建文本格式."""
        text_format = QTextCharFormat()
        text_format.setForeground(QBrush(color))
        return text_format

    def apply_config_to_ui(self) -> None:
        """将加载的配置应用到UI控件."""
        model_path = conf.MODEL_PATH
        if model_path and Path(model_path).exists():
            self.model_path_input.setText(str(model_path))
        else:
            self.model_path_input.setPlaceholderText("选择模型文件...")
            if model_path:
                self.append_output(
                    f"警告: 之前选择的模型文件未找到: {model_path}\n",
                    self.warning_format,
                )

        self.port_spin.setValue(conf.LISTEN_PORT)
        self.threads_spin.setValue(conf.THREAD_COUNT)

    def _update_model_path_tooltip(self, text: str) -> None:
        """更新模型路径输入框的工具提示以显示完整路径."""
        self.model_path_input.setToolTip(text)

    def on_config_changed(self) -> None:
        """处理配置变更并更新内部状态."""
        conf.MODEL_PATH = self.model_path_input.text().strip()
        conf.LISTEN_PORT = self.port_spin.value()
        conf.THREAD_COUNT = self.threads_spin.value()

    def on_load_model(self) -> None:
        """使用改进的文件对话框选择模型文件."""
        initial_dir = (
            str(Path(conf.MODEL_PATH).parent)
            if conf.MODEL_PATH and Path(conf.MODEL_PATH).exists()
            else str(Path.home())
        )

        path, _ = QFileDialog.getOpenFileName(
            self,
            "选择 GGUF 模型文件",
            initial_dir,
            "GGUF 模型 (*.gguf);;所有文件 (*.*)",
        )

        if path:
            conf.MODEL_PATH = path
            normalized_path = os.path.normpath(path)
            self.model_path_input.setText(normalized_path)
            self.model_path_input.setToolTip(normalized_path)
            self.append_output(f"模型已选择: {path}\n", self.info_format)

    def toggle_server(self) -> None:
        """启动或停止服务器."""
        if self.server_worker and self.server_worker.isRunning():
            self.stop_server()
        else:
            self.start_server()

    def start_server(self) -> None:
        """启动服务器,包含增强的验证和错误处理."""
        model_path_str = self.model_path_input.text().strip()
        port = self.port_spin.value()
        threads = self.threads_spin.value()

        if not model_path_str:
            self.append_output("错误:请先选择一个模型文件\n", self.error_format)
            return

        self.server_worker = ServerWorker(model_path_str, port, threads)
        self.server_worker.started.connect(self.on_server_started)
        self.server_worker.stopped.connect(self.on_server_stopped)
        self.server_worker.error_occurred.connect(self.on_server_error)
        self.server_worker.output_received.connect(self.on_server_output)

        self.append_output(f"使用模型启动服务器: {model_path_str}\n", self.info_format)
        self.server_worker.start()

    def stop_server(self) -> None:
        """停止服务器."""
        if self.server_worker and self.server_worker.isRunning():
            self.append_output("正在关闭服务器...\n", self.info_format)
            self.server_worker.stop()

    @staticmethod
    def on_start_browser() -> None:
        """启动浏览器."""
        QDesktopServices.openUrl(QUrl(f"{conf.URL}:{conf.LISTEN_PORT}"))

    def on_server_started(self) -> None:
        """处理服务器启动事件."""
        self.update_ui_state(running=True)
        self.append_output("服务器已启动\n", self.info_format)

    def on_server_stopped(self) -> None:
        """处理服务器停止事件."""
        self.update_ui_state(running=False)
        self.append_output("服务器已停止\n", self.info_format)
        if self.server_worker:
            self.server_worker.quit()
            self.server_worker.wait()
            self.server_worker = None

    def on_server_error(self, error_msg: str) -> None:
        """处理服务器错误事件."""
        self.append_output(f"{error_msg}\n", self.error_format)
        self.update_ui_state(running=False)

    def on_server_output(self, text: str) -> None:
        """处理服务器输出事件."""
        self.append_output(text, self.info_format)

    def append_output(self, text: str, text_format: QTextCharFormat | None = None) -> None:
        """追加输出."""
        cursor: QTextCursor = self.output_area.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)

        if text_format:
            cursor.setCharFormat(text_format)

        cursor.insertText(text)

        self.output_area.setTextCursor(cursor)
        self.output_area.ensureCursorVisible()

    def update_ui_state(self, *, running: bool) -> None:
        """更新UI状态."""
        self.model_path_input.setEnabled(not running)
        self.load_model_btn.setEnabled(not running)
        self.port_spin.setEnabled(not running)
        self.threads_spin.setEnabled(not running)
        self.browser_btn.setEnabled(running)

        self._update_start_button_text()

    def moveEvent(self, event: QMoveEvent) -> None:
        """处理窗口移动事件."""
        top_left = self.geometry().topLeft()
        conf.WIN_POS = [top_left.x(), top_left.y()]
        super().moveEvent(event)

    def resizeEvent(self, event: QResizeEvent) -> None:
        """处理窗口调整大小事件."""
        geometry = self.geometry()
        conf.WIN_SIZE = [geometry.width(), geometry.height()]
        super().resizeEvent(event)

    def closeEvent(self, event: QCloseEvent) -> None:
        """处理窗口关闭事件,包含增强的清理操作."""
        try:
            logger.info("退出时配置保存成功")
        except (RuntimeError, OSError, TypeError, ValueError):
            logger.exception("退出时保存配置失败")

        try:
            if self.server_worker and self.server_worker.isRunning():
                self.append_output("正在关闭服务器...\n", self.info_format)
                self.server_worker.stop()
                self.server_worker.wait(3000)
                self.append_output("服务器关闭完成\n", self.info_format)
        except (OSError, RuntimeError):
            logger.exception("关闭过程中发生错误")
        finally:
            event.accept()
