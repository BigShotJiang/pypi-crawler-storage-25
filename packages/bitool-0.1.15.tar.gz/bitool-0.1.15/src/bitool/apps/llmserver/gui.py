"""LLM服务器图形用户界面."""

from __future__ import annotations

import sys

from bitool.gui.compat import QApplication

from .widgets.llmserver import LLMServer


def main() -> None:
    """GUI应用程序的主入口函数."""
    app = QApplication(sys.argv)
    window = LLMServer()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
