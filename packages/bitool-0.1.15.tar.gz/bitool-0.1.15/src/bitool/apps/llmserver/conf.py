"""LLM服务器配置模块."""

from __future__ import annotations

from pathlib import Path

from bitool.core import JsonConfig


class LLMServerConfig(JsonConfig):
    """LLM服务器配置类,支持配置持久化."""

    # 应用程序元数据
    TITLE: str = "Llama 本地模型服务器 v1.0"

    # 窗口配置
    WIN_SIZE: list[int] = [600, 400]  # 窗口大小
    WIN_POS: list[int] = [200, 200]  # 窗口位置

    # 服务器配置
    MODEL_PATH: str = ""
    URL: str = "http://127.0.0.1"
    LISTEN_PORT: int = 8080
    LISTEN_PORT_RNG: list[int] = [1024, 65535]  # 端口范围
    THREAD_COUNT: int = 4
    THREAD_COUNT_RNG: list[int] = [1, 24]  # 线程数范围

    # 配置文件路径
    CONFIG_FILE: Path = Path.home() / ".pytola" / "llmserver.json"


conf = LLMServerConfig()
