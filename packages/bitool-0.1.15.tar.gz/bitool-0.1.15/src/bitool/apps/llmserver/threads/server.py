"""LLM服务器工作线程模块."""

from __future__ import annotations

import os
import shutil
from pathlib import Path

from bitool.core import logger
from bitool.gui.compat import QProcess, QThread, Signal


class ServerWorker(QThread):
    """LLM服务器工作线程.

    在后台线程中处理llama-server进程的启动/停止,
    避免阻塞UI主线程.

    Signals
    -------
        started: 服务器启动成功时发出
        stopped: 服务器停止时发出
        error_occurred: 发生错误时发出,携带错误消息
        output_received: 收到输出时发出,携带输出文本
    """

    started = Signal()
    stopped = Signal()
    error_occurred = Signal(str)
    output_received = Signal(str)

    def __init__(self, model_path: str, port: int, threads: int) -> None:
        """初始化服务器工作线程.

        Args:
            model_path: GGUF模型文件路径
            port: 服务器端口号
            threads: 使用的线程数
        """
        super().__init__()
        self.model_path = Path(model_path)
        self.port = port
        self.threads = threads
        self.process: QProcess | None = None
        self._is_running = True

    def run(self) -> None:
        """执行服务器进程."""
        try:
            # 验证模型文件
            if not self.model_path.exists():
                self.error_occurred.emit(f"错误:未找到模型文件: {self.model_path}")
                return

            if not self.model_path.is_file():
                self.error_occurred.emit(f"错误:路径不是文件: {self.model_path}")
                return

            if self.model_path.suffix.lower() != ".gguf":
                logger.warning(f"模型文件没有.gguf扩展名: {self.model_path}")

            # 检查llama-server是否可用
            llama_server_path = shutil.which("llama-server")
            if not llama_server_path:
                self.error_occurred.emit(
                    "错误:在PATH中未找到llama-server。请安装llama.cpp。",
                )
                return

            self.output_received.emit(f"找到llama-server于: {llama_server_path}\n")

            # 切换到模型目录
            try:
                os.chdir(str(self.model_path.parent))
            except OSError as e:
                self.error_occurred.emit(f"错误:无法访问模型目录: {e}")
                return

            # 构建命令
            cmd = [
                "llama-server",
                "--model",
                self.model_path.name,
                "--port",
                str(self.port),
                "--threads",
                str(self.threads),
            ]

            self.output_received.emit(f"启动服务器: {' '.join(cmd)}\n")
            self.output_received.emit(f"工作目录: {self.model_path.parent}\n")

            # 创建并配置进程
            self.process = QProcess()
            self.process.setProgram(cmd[0])
            self.process.setArguments(cmd[1:])

            # 连接信号
            self.process.readyReadStandardOutput.connect(self._handle_stdout)
            self.process.readyReadStandardError.connect(self._handle_stderr)
            self.process.finished.connect(self._on_process_finished)

            # 启动进程
            self.process.start()
            if self.process.waitForStarted(5000):
                self.started.emit()
                # 保持事件循环运行
                self.exec_()
            else:
                self.error_occurred.emit(
                    f"错误:无法启动服务器进程。错误: {self.process.errorString()}",
                )

        except (OSError, RuntimeError) as e:
            logger.exception("服务器错误")
            self.error_occurred.emit(f"启动失败: {e!s}")

    def _handle_stdout(self) -> None:
        """处理标准输出."""
        if self.process:
            data = self.process.readAllStandardOutput()
            text = data.data().decode("utf-8", errors="replace")
            self.output_received.emit(text)

    def _handle_stderr(self) -> None:
        """处理标准错误."""
        if self.process:
            data = self.process.readAllStandardError()
            text = data.data().decode("utf-8", errors="replace")
            self.output_received.emit(text)

    def _on_process_finished(self, exit_code: int, exit_status: int) -> None:
        """进程结束回调函数."""
        status_msg = f"服务器已停止。退出码: {exit_code},状态: {exit_status}"
        self.output_received.emit(f"\n{status_msg}\n")

        if exit_code != 0:
            self.output_received.emit("注意:非零退出码可能表示发生错误。\n")

        self.stopped.emit()
        self.quit()

    def stop(self) -> None:
        """优雅地停止服务器."""
        self._is_running = False
        if self.process and self.process.state() == QProcess.Running:
            self.process.terminate()
            if not self.process.waitForFinished(2000):
                self.process.kill()
                self.process.waitForFinished(1000)
