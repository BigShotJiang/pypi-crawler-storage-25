"""Bitool 命令注册表.

动态发现所有命令入口点，无需硬编码.
"""

from __future__ import annotations

import importlib
import pkgutil
from pathlib import Path
from typing import Iterator

# 缓存已发现的命令
_cached_commands: dict[str, str] | None = None


def _iter_package_modules(package_name: str) -> Iterator[str]:
    """递归迭代包中的所有模块.

    Parameters
    ----------
    package_name : str
        包名，例如 'bitool.apps'

    Yields
    ------
    str
        完整的模块路径
    """
    try:
        package = importlib.import_module(package_name)
    except ImportError:
        return

    package_path = getattr(package, "__path__", None)
    if not package_path:
        return

    for _, module_name, is_pkg in pkgutil.iter_modules(package_path):
        full_module_name = f"{package_name}.{module_name}"
        yield full_module_name

        if is_pkg:
            yield from _iter_package_modules(full_module_name)


def _find_main_functions() -> dict[str, str]:
    """扫描 bitool 包，查找所有包含 main 函数的模块.

    Returns
    -------
    dict[str, str]
        命令名到模块路径的映射
    """
    commands = {}

    # 优先直接从 pyproject.toml 读取（最可靠的来源，且快速）
    try:
        from bitool.compat import tomllib

        current_dir = Path(__file__).resolve().parent
        for parent in [current_dir, *list(current_dir.parents)]:
            pyproject_path = parent / "pyproject.toml"
            if pyproject_path.exists():
                with open(pyproject_path, "rb") as f:
                    pyproject = tomllib.load(f)
                    scripts = pyproject.get("project", {}).get("scripts", {})
                    exclude = {"bitool"}
                    for name, path in scripts.items():
                        if name not in exclude:
                            commands[name] = path
                break
    except Exception:
        pass

    # 如果 pyproject.toml 读取成功且包含足够的命令，直接返回
    if len(commands) > 10:  # 有足够的命令，不需要动态扫描
        return commands

    # 回退到动态扫描（仅在 pyproject.toml 不可用时）
        # 扫描已知的命令位置
        packages_to_scan = [
            "bitool.apps",
            "bitool.skills",
            "bitool.websvr",
        ]

        for package in packages_to_scan:
            for module_path in _iter_package_modules(package):
                try:
                    module = importlib.import_module(module_path)
                    if hasattr(module, "main") and callable(module.main):
                        # 根据模块路径生成命令名
                        parts = module_path.split(".")

                        # 对于 apps 目录
                        if len(parts) >= 3 and parts[1] == "apps":
                            app_name = parts[2]
                            if parts[-1] == "gui":
                                cmd_name = app_name + "w"
                            elif parts[-1] == "cli":
                                cmd_name = app_name
                            else:
                                cmd_name = app_name
                            commands[cmd_name] = f"{module_path}:main"
                        # 对于 skills 目录
                        elif len(parts) >= 3 and parts[1] == "skills":
                            skill_name = parts[-1]
                            # 一些特殊映射
                            special_map = {
                                "clearscreen": "cls",
                                "which": "wch",
                                "screenshotskill": "screenshot",
                            }
                            cmd_name = special_map.get(skill_name, skill_name)
                            commands[cmd_name] = f"{module_path}:main"
                        # 对于 websvr
                        elif module_path == "bitool.websvr.cli":
                            commands["websvr"] = f"{module_path}:main"
                except Exception:
                    continue

    # 对于 rimlite 这种特殊情况，单独处理
    if "rimlite" not in commands:
        commands["rimlite"] = "bitool.apps.rimworld_lite.src.rimworld_lite.main:main"

    return commands


def _get_commands() -> dict[str, str]:
    """获取命令映射，带缓存.

    Returns
    -------
    dict[str, str]
        命令名到模块路径的映射
    """
    global _cached_commands
    if _cached_commands is None:
        _cached_commands = _find_main_functions()
    return _cached_commands


def get_all_commands() -> list[str]:
    """获取所有可用命令的列表.

    Returns
    -------
    list[str]
        所有可用命令的有序列表.
    """
    return sorted(_get_commands().keys())


def get_command_module(command: str) -> str | None:
    """获取命令对应的模块导入路径.

    Parameters
    ----------
    command : str
        命令名称.

    Returns
    -------
    str | None
        模块导入路径（格式: "module.path:function_name"），如果命令不存在则返回 None.
    """
    return _get_commands().get(command)


def resolve_command(command: str) -> tuple[str | None, str | None]:
    """解析命令获取模块路径和函数名.

    Parameters
    ----------
    command : str
        命令名称.

    Returns
    -------
    tuple[str | None, str | None]
        (模块路径, 函数名) 元组，如果命令不存在则返回 (None, None).
    """
    module_path = get_command_module(command)
    if not module_path:
        return (None, None)

    if ":" in module_path:
        mod_part, func_part = module_path.split(":", 1)
        return (mod_part, func_part)

    return (module_path, "main")
