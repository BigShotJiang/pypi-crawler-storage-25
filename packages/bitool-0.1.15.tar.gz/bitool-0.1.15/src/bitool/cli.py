"""Bitool 主 CLI 入口.

提供 `bitool` 命令，用于访问所有 bitool 工具."""

from __future__ import annotations

import argparse
import importlib
import sys

from bitool.core import logger


def run_command(command: str, cmd_args: list[str]) -> int:
    """直接运行指定的命令.

    Parameters
    ----------
    command : str
        要执行的命令名称.
    cmd_args : list[str]
        传递给命令的参数列表.

    Returns
    -------
    int
        退出码.
    """
    from bitool.commands_registry import resolve_command

    mod_path, func_name = resolve_command(command)
    if not mod_path or not func_name:
        logger.error(f"无效的命令: {command}")
        logger.info("使用 --list 查看所有可用命令")
        return 1

    try:
        # 动态导入模块
        module = importlib.import_module(mod_path)
        # 获取函数
        func = getattr(module, func_name)

        # 保存原始的 sys.argv
        original_argv = sys.argv.copy()

        # 设置新的 sys.argv
        sys.argv = [command, *cmd_args]

        try:
            # 执行函数
            func()
            return 0
        except SystemExit as e:
            # 处理命令内部调用 sys.exit() 的情况
            return e.code if isinstance(e.code, int) else 1
        finally:
            # 恢复原始的 sys.argv
            sys.argv = original_argv

    except ImportError:
        logger.error(f"无法导入模块: {mod_path}")
        return 1
    except AttributeError:
        logger.error(f"模块 {mod_path} 中没有找到函数: {func_name}")
        return 1
    except Exception as e:  # noqa: BLE001
        logger.error(f"执行命令失败: {e}")
        return 1


def main() -> int:
    """主函数入口.

    Returns
    -------
    int
        退出码.
    """
    parser = argparse.ArgumentParser(
        description="Bitool - Rust + Python 混合架构工具集",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  bitool --help          # 显示帮助
  bitool --list          # 列出所有可用命令
  bitool [command] ...   # 执行指定命令
        """,
    )

    parser.add_argument("--list", action="store_true", help="列出所有可用命令")
    parser.add_argument("--version", action="store_true", help="显示版本信息")
    parser.add_argument("command", type=str, nargs="?", help="要执行的命令")
    parser.add_argument("args", type=str, nargs="*", help="命令参数")

    args = parser.parse_args()

    # 显示版本信息
    if args.version:
        from bitool import __version__

        logger.info(f"bitool {__version__}")
        return 0

    # 列出所有可用命令
    if args.list:
        from bitool.commands_registry import get_all_commands

        commands = get_all_commands()
        logger.info("可用的 bitool 命令:")
        logger.info("-" * 60)
        for cmd in commands:
            logger.info(f"  - {cmd}")
        logger.info("-" * 60)
        logger.info(f"共 {len(commands)} 个命令")
        return 0

    # 如果没有指定命令，显示帮助
    if args.command is None:
        parser.print_help()
        return 0

    # 执行指定命令
    try:
        return run_command(args.command, args.args)
    except KeyboardInterrupt:
        logger.info("操作已取消")
        return 130
    except Exception as e:  # noqa: BLE001
        logger.error(f"执行失败: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
