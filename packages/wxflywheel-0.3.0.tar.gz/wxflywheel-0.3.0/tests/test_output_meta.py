"""Tests for meta field injection in wxflywheel.output.emit_payload."""

from __future__ import annotations

import json
from typing import Any

import pytest
from click.testing import CliRunner

from wxflywheel import __version__, output, version_check
from wxflywheel.cli import cli


def test_emit_payload_includes_meta_by_default(
    capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """When include_meta is default, a cli meta object must be attached."""
    monkeypatch.setenv("WXFLYWHEEL_NO_META", "1")  # deterministic stub meta
    output.emit_payload({"code": 200, "data": {"foo": "bar"}, "message": ""})
    captured = capsys.readouterr()
    payload = json.loads(captured.out)
    assert "meta" in payload
    assert payload["meta"]["cli"]["current_version"] == __version__
    assert payload["data"]["foo"] == "bar"


def test_emit_payload_skips_meta_when_flag_false(
    capsys: pytest.CaptureFixture[str],
) -> None:
    output.emit_payload(
        {"code": 200, "data": {"foo": "bar"}, "message": ""}, include_meta=False
    )
    captured = capsys.readouterr()
    payload = json.loads(captured.out)
    assert "meta" not in payload


def test_emit_payload_meta_injection_failure_is_silent(
    capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """If build_meta raises, the main payload must still be emitted."""

    def _boom() -> dict[str, Any]:
        raise RuntimeError("broken")

    monkeypatch.setattr(version_check, "build_meta", _boom)
    monkeypatch.delenv("WXFLYWHEEL_NO_META", raising=False)
    output.emit_payload({"code": 200, "data": "ok", "message": ""})
    captured = capsys.readouterr()
    payload = json.loads(captured.out)
    assert payload["data"] == "ok"
    assert "meta" not in payload  # injection failed, but main payload survived


def test_all_existing_commands_still_return_three_field_envelope(
    mock_resp: Any, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Regression: code/data/message contract is preserved even with meta."""
    from unittest.mock import patch

    monkeypatch.delenv("WXFLYWHEEL_NO_META", raising=False)  # use stub meta via conftest default
    runner = CliRunner()
    api_resp = {"code": 200, "data": {"loginState": 1}, "message": ""}
    env = {"WXFLYWHEEL_KEY": "test-key", "WXFLYWHEEL_HOST": "http://localhost:8011"}
    with patch(
        "wxflywheel.client.requests.request", return_value=mock_resp(api_resp)
    ):
        result = runner.invoke(cli, ["login", "status"], env=env)
    payload = json.loads(result.output)
    # Original three fields
    assert "code" in payload
    assert "data" in payload
    assert "message" in payload
    # Plus the new meta field (stubbed by autouse conftest fixture)
    assert "meta" in payload
    assert payload["meta"]["cli"]["current_version"] == __version__
