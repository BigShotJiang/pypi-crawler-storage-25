"""Tests for wxflywheel.version_check (pure unit tests, no network)."""

from __future__ import annotations

import json
import subprocess
import time
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest
import requests

from wxflywheel import __version__, version_check


@pytest.fixture
def _isolated_cache(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Point the cache dir at a tmp_path and ensure no meta stub is active."""
    monkeypatch.setenv("WXFLYWHEEL_CACHE_DIR", str(tmp_path / "cache"))
    monkeypatch.delenv("WXFLYWHEEL_NO_META", raising=False)
    return tmp_path / "cache"


# ---------------------------------------------------------------------------
# cache_dir / cache_file
# ---------------------------------------------------------------------------


def test_cache_dir_respects_env_override(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("WXFLYWHEEL_CACHE_DIR", str(tmp_path))
    assert version_check.cache_dir() == tmp_path
    assert version_check.cache_file() == tmp_path / "version_check.json"


def test_cache_dir_defaults_to_home_cache(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("WXFLYWHEEL_CACHE_DIR", raising=False)
    result = version_check.cache_dir()
    assert result == Path.home() / ".cache" / "wxflywheel"


# ---------------------------------------------------------------------------
# load_cache / save_cache
# ---------------------------------------------------------------------------


def test_load_cache_returns_none_when_missing(_isolated_cache: Path) -> None:
    assert version_check.load_cache() is None


def test_load_cache_returns_dict_when_present(_isolated_cache: Path) -> None:
    _isolated_cache.mkdir(parents=True)
    cache_data = {"latest_version": "0.9.9", "checked_at_epoch": time.time()}
    (_isolated_cache / "version_check.json").write_text(json.dumps(cache_data))
    loaded = version_check.load_cache()
    assert loaded == cache_data


def test_load_cache_returns_none_on_corrupted_json(_isolated_cache: Path) -> None:
    _isolated_cache.mkdir(parents=True)
    (_isolated_cache / "version_check.json").write_text("{not json")
    assert version_check.load_cache() is None


def test_load_cache_returns_none_when_top_level_not_dict(_isolated_cache: Path) -> None:
    _isolated_cache.mkdir(parents=True)
    (_isolated_cache / "version_check.json").write_text("[1, 2, 3]")
    assert version_check.load_cache() is None


def test_load_cache_returns_none_on_os_error(monkeypatch: pytest.MonkeyPatch) -> None:
    def _raise(*args: Any, **kwargs: Any) -> None:
        raise OSError("permission denied")

    monkeypatch.setattr(Path, "open", _raise)
    monkeypatch.setattr(Path, "exists", lambda self: True)
    assert version_check.load_cache() is None


def test_save_cache_creates_directory_and_writes_file(_isolated_cache: Path) -> None:
    assert version_check.save_cache({"foo": "bar"}) is True
    assert _isolated_cache.exists()
    data = json.loads((_isolated_cache / "version_check.json").read_text())
    assert data == {"foo": "bar"}


def test_save_cache_returns_false_on_os_error(monkeypatch: pytest.MonkeyPatch) -> None:
    def _raise(*args: Any, **kwargs: Any) -> None:
        raise OSError("disk full")

    monkeypatch.setattr(Path, "mkdir", _raise)
    assert version_check.save_cache({"foo": "bar"}) is False


# ---------------------------------------------------------------------------
# is_cache_expired / compute_cache_age_seconds
# ---------------------------------------------------------------------------


def test_is_cache_expired_true_when_old() -> None:
    old_cache = {"checked_at_epoch": time.time() - 25 * 3600}
    assert version_check.is_cache_expired(old_cache) is True


def test_is_cache_expired_false_when_recent() -> None:
    fresh = {"checked_at_epoch": time.time() - 60}
    assert version_check.is_cache_expired(fresh) is False


def test_is_cache_expired_true_when_timestamp_missing() -> None:
    assert version_check.is_cache_expired({}) is True
    assert version_check.is_cache_expired({"checked_at_epoch": "not a number"}) is True


def test_compute_cache_age_seconds_returns_int() -> None:
    cache = {"checked_at_epoch": time.time() - 120}
    age = version_check.compute_cache_age_seconds(cache)
    assert age is not None
    assert 118 <= age <= 122


def test_compute_cache_age_seconds_returns_none_when_missing() -> None:
    assert version_check.compute_cache_age_seconds({}) is None
    assert version_check.compute_cache_age_seconds({"checked_at_epoch": "bad"}) is None


def test_compute_cache_age_seconds_clamps_to_zero_for_future_time() -> None:
    cache = {"checked_at_epoch": time.time() + 300}
    assert version_check.compute_cache_age_seconds(cache) == 0


# ---------------------------------------------------------------------------
# fetch_pypi_latest
# ---------------------------------------------------------------------------


def _mock_pypi_response(version: str, upload_time: str | None = None) -> MagicMock:
    m = MagicMock()
    m.raise_for_status = MagicMock()
    release_files: list[dict[str, Any]] = []
    if upload_time is not None:
        release_files.append({"upload_time_iso_8601": upload_time})
    m.json.return_value = {
        "info": {"version": version},
        "releases": {version: release_files},
    }
    return m


def test_fetch_pypi_latest_success(monkeypatch: pytest.MonkeyPatch) -> None:
    resp = _mock_pypi_response("0.9.9", "2026-04-06T12:34:56Z")
    monkeypatch.setattr(requests, "get", lambda *a, **kw: resp)
    result = version_check.fetch_pypi_latest(timeout=1.0)
    assert result == ("0.9.9", "2026-04-06T12:34:56Z")


def test_fetch_pypi_latest_success_without_upload_time(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    resp = _mock_pypi_response("0.9.9")
    monkeypatch.setattr(requests, "get", lambda *a, **kw: resp)
    result = version_check.fetch_pypi_latest(timeout=1.0)
    assert result == ("0.9.9", "")


def test_fetch_pypi_latest_returns_none_on_request_exception(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def _raise(*a: Any, **kw: Any) -> None:
        raise requests.ConnectionError("no network")

    monkeypatch.setattr(requests, "get", _raise)
    assert version_check.fetch_pypi_latest(timeout=1.0) is None


def test_fetch_pypi_latest_returns_none_on_bad_json(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    m = MagicMock()
    m.raise_for_status = MagicMock()
    m.json.side_effect = ValueError("bad json")
    monkeypatch.setattr(requests, "get", lambda *a, **kw: m)
    assert version_check.fetch_pypi_latest(timeout=1.0) is None


def test_fetch_pypi_latest_returns_none_when_top_level_not_dict(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    m = MagicMock()
    m.raise_for_status = MagicMock()
    m.json.return_value = []
    monkeypatch.setattr(requests, "get", lambda *a, **kw: m)
    assert version_check.fetch_pypi_latest(timeout=1.0) is None


def test_fetch_pypi_latest_returns_none_when_info_missing_version(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    m = MagicMock()
    m.raise_for_status = MagicMock()
    m.json.return_value = {"info": {}, "releases": {}}
    monkeypatch.setattr(requests, "get", lambda *a, **kw: m)
    assert version_check.fetch_pypi_latest(timeout=1.0) is None


def test_fetch_pypi_latest_handles_non_dict_info(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    m = MagicMock()
    m.raise_for_status = MagicMock()
    m.json.return_value = {"info": "not a dict"}
    monkeypatch.setattr(requests, "get", lambda *a, **kw: m)
    assert version_check.fetch_pypi_latest(timeout=1.0) is None


def test_fetch_pypi_latest_handles_non_dict_releases(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Covers the `if isinstance(releases, dict)` False branch."""
    m = MagicMock()
    m.raise_for_status = MagicMock()
    m.json.return_value = {"info": {"version": "1.0.0"}, "releases": "not a dict"}
    monkeypatch.setattr(requests, "get", lambda *a, **kw: m)
    result = version_check.fetch_pypi_latest(timeout=1.0)
    assert result == ("1.0.0", "")


def test_fetch_pypi_latest_handles_non_dict_first_file(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Covers the `if isinstance(first_file, dict)` False branch."""
    m = MagicMock()
    m.raise_for_status = MagicMock()
    m.json.return_value = {
        "info": {"version": "1.0.0"},
        "releases": {"1.0.0": ["not a dict"]},
    }
    monkeypatch.setattr(requests, "get", lambda *a, **kw: m)
    result = version_check.fetch_pypi_latest(timeout=1.0)
    assert result == ("1.0.0", "")


def test_fetch_pypi_latest_handles_non_str_upload_time(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Covers the `if isinstance(raw_time, str)` False branch."""
    m = MagicMock()
    m.raise_for_status = MagicMock()
    m.json.return_value = {
        "info": {"version": "1.0.0"},
        "releases": {"1.0.0": [{"upload_time_iso_8601": None, "upload_time": 12345}]},
    }
    monkeypatch.setattr(requests, "get", lambda *a, **kw: m)
    result = version_check.fetch_pypi_latest(timeout=1.0)
    assert result == ("1.0.0", "")


# ---------------------------------------------------------------------------
# fetch_changelog_breaking
# ---------------------------------------------------------------------------


def _mock_changelog_response(body: str) -> MagicMock:
    m = MagicMock()
    m.raise_for_status = MagicMock()
    m.text = body
    return m


def test_fetch_changelog_breaking_true_when_section_has_header(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    changelog = (
        "# Changelog\n\n"
        "## [0.9.0] - 2026-04-06\n\n"
        "### Breaking\n- something broke\n\n"
        "## [0.8.0] - 2026-04-05\n"
    )
    monkeypatch.setattr(requests, "get", lambda *a, **kw: _mock_changelog_response(changelog))
    assert version_check.fetch_changelog_breaking("0.9.0") is True


def test_fetch_changelog_breaking_true_on_phrase(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    changelog = (
        "## [0.9.0] - 2026-04-06\n\n### Changed\nThis introduces a BREAKING CHANGE in X.\n"
    )
    monkeypatch.setattr(requests, "get", lambda *a, **kw: _mock_changelog_response(changelog))
    assert version_check.fetch_changelog_breaking("0.9.0") is True


def test_fetch_changelog_breaking_true_on_prefix(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    changelog = "## [0.9.0] - 2026-04-06\n\n- BREAKING: removed old field\n"
    monkeypatch.setattr(requests, "get", lambda *a, **kw: _mock_changelog_response(changelog))
    assert version_check.fetch_changelog_breaking("0.9.0") is True


def test_fetch_changelog_breaking_false_when_no_marker(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    changelog = "## [0.9.0] - 2026-04-06\n\n### Added\n- new command\n"
    monkeypatch.setattr(requests, "get", lambda *a, **kw: _mock_changelog_response(changelog))
    assert version_check.fetch_changelog_breaking("0.9.0") is False


def test_fetch_changelog_breaking_ignores_other_version_sections(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    changelog = (
        "## [0.9.0] - 2026-04-06\n\n### Added\n- new command\n\n"
        "## [0.8.0] - 2026-04-05\n\n### Breaking\n- old breaking in previous version\n"
    )
    monkeypatch.setattr(requests, "get", lambda *a, **kw: _mock_changelog_response(changelog))
    assert version_check.fetch_changelog_breaking("0.9.0") is False


def test_fetch_changelog_breaking_false_when_version_not_in_changelog(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    changelog = "## [0.8.0] - 2026-04-05\n\n### Added\n- something\n"
    monkeypatch.setattr(requests, "get", lambda *a, **kw: _mock_changelog_response(changelog))
    assert version_check.fetch_changelog_breaking("0.9.0") is False


def test_fetch_changelog_breaking_false_on_network_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def _raise(*a: Any, **kw: Any) -> None:
        raise requests.ConnectionError("offline")

    monkeypatch.setattr(requests, "get", _raise)
    assert version_check.fetch_changelog_breaking("0.9.0") is False


# ---------------------------------------------------------------------------
# refresh_cache_from_pypi
# ---------------------------------------------------------------------------


def test_refresh_cache_from_pypi_success(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(
        version_check,
        "fetch_pypi_latest",
        lambda timeout: ("99.0.0", "2026-04-06T00:00:00Z"),
    )
    monkeypatch.setattr(version_check, "fetch_changelog_breaking", lambda v, timeout=5.0: False)
    assert version_check.refresh_cache_from_pypi() is True
    loaded = version_check.load_cache()
    assert loaded is not None
    assert loaded["latest_version"] == "99.0.0"
    assert loaded["has_breaking"] is False
    assert "changelog_url" in loaded
    assert "checked_at_epoch" in loaded


def test_refresh_cache_from_pypi_returns_false_on_pypi_failure(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(version_check, "fetch_pypi_latest", lambda timeout: None)
    assert version_check.refresh_cache_from_pypi() is False


def test_refresh_cache_from_pypi_skips_changelog_when_no_upgrade(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(
        version_check,
        "fetch_pypi_latest",
        lambda timeout: (__version__, "2026-04-06T00:00:00Z"),
    )
    call_count = {"n": 0}

    def _fake_breaking(v: str, timeout: float = 5.0) -> bool:
        call_count["n"] += 1
        return False

    monkeypatch.setattr(version_check, "fetch_changelog_breaking", _fake_breaking)
    assert version_check.refresh_cache_from_pypi() is True
    assert call_count["n"] == 0  # no upgrade → no changelog call


def test_refresh_cache_from_pypi_handles_invalid_version(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(
        version_check,
        "fetch_pypi_latest",
        lambda timeout: ("not-a-version", "2026-04-06T00:00:00Z"),
    )
    assert version_check.refresh_cache_from_pypi() is True
    loaded = version_check.load_cache()
    assert loaded is not None
    assert loaded["has_breaking"] is False


# ---------------------------------------------------------------------------
# compare_versions / compute_severity / compute_days_behind
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "current,latest,expected",
    [
        ("0.2.0", "0.3.0", -1),
        ("0.3.0", "0.3.0", 0),
        ("0.3.0", "0.2.0", 1),
        ("1.0.0", "2.0.0", -1),
        ("not-a-version", "0.3.0", 0),
        ("0.3.0", "bad", 0),
    ],
)
def test_compare_versions(current: str, latest: str, expected: int) -> None:
    assert version_check.compare_versions(current, latest) == expected


@pytest.mark.parametrize(
    "current,latest,has_breaking,expected",
    [
        ("0.2.1", "0.2.2", False, "patch"),
        ("0.2.1", "0.3.0", False, "minor"),
        ("0.2.1", "1.0.0", False, "major"),
        ("0.2.1", "0.3.0", True, "breaking"),
        ("0.3.0", "0.3.0", False, None),
        ("0.3.0", "0.2.0", False, None),
        ("bad", "0.3.0", False, None),
    ],
)
def test_compute_severity(
    current: str, latest: str, has_breaking: bool, expected: str | None
) -> None:
    assert version_check.compute_severity(current, latest, has_breaking) == expected


def test_compute_days_behind_with_iso_timezone() -> None:
    past = "2020-01-01T00:00:00+00:00"
    days = version_check.compute_days_behind(past)
    assert days is not None
    assert days > 2000  # at least 5 years


def test_compute_days_behind_with_z_suffix() -> None:
    past = "2020-01-01T00:00:00Z"
    days = version_check.compute_days_behind(past)
    assert days is not None
    assert days > 2000


def test_compute_days_behind_without_tz() -> None:
    past = "2020-01-01T00:00:00"
    days = version_check.compute_days_behind(past)
    assert days is not None
    assert days > 2000


def test_compute_days_behind_returns_none_for_empty() -> None:
    assert version_check.compute_days_behind(None) is None
    assert version_check.compute_days_behind("") is None


def test_compute_days_behind_returns_none_for_bad_format() -> None:
    assert version_check.compute_days_behind("not a date") is None


def test_compute_days_behind_clamps_to_zero_for_future() -> None:
    future = "2099-01-01T00:00:00Z"
    assert version_check.compute_days_behind(future) == 0


# ---------------------------------------------------------------------------
# try_trigger_background_refresh
# ---------------------------------------------------------------------------


def test_try_trigger_background_refresh_in_worker_mode_is_noop(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("WXFLYWHEEL_WORKER", "1")
    called = {"spawned": False}

    def _fake_popen(*a: Any, **kw: Any) -> MagicMock:
        called["spawned"] = True
        return MagicMock()

    monkeypatch.setattr(subprocess, "Popen", _fake_popen)
    version_check.try_trigger_background_refresh()
    assert called["spawned"] is False


def test_try_trigger_background_refresh_spawns_popen(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("WXFLYWHEEL_WORKER", raising=False)
    calls: list[Any] = []

    def _fake_popen(args: list[str], **kwargs: Any) -> MagicMock:
        calls.append((args, kwargs))
        return MagicMock()

    monkeypatch.setattr(subprocess, "Popen", _fake_popen)
    version_check.try_trigger_background_refresh()
    assert len(calls) == 1
    spawned_args, _ = calls[0]
    assert "_version_check_worker" in spawned_args[-1]


def test_try_trigger_background_refresh_fallback_on_oserror(
    monkeypatch: pytest.MonkeyPatch, _isolated_cache: Path
) -> None:
    monkeypatch.delenv("WXFLYWHEEL_WORKER", raising=False)

    def _raise(*a: Any, **kw: Any) -> None:
        raise OSError("fork denied")

    monkeypatch.setattr(subprocess, "Popen", _raise)
    refresh_called = {"n": 0}

    def _fake_refresh(timeout: float = 0.5) -> bool:
        refresh_called["n"] += 1
        return True

    monkeypatch.setattr(version_check, "refresh_cache_from_pypi", _fake_refresh)
    version_check.try_trigger_background_refresh()
    assert refresh_called["n"] == 1


def test_try_trigger_background_refresh_fallback_swallows_refresh_exception(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("WXFLYWHEEL_WORKER", raising=False)

    def _popen_raise(*a: Any, **kw: Any) -> None:
        raise OSError("fork denied")

    def _refresh_raise(timeout: float = 0.5) -> bool:
        raise RuntimeError("boom")

    monkeypatch.setattr(subprocess, "Popen", _popen_raise)
    monkeypatch.setattr(version_check, "refresh_cache_from_pypi", _refresh_raise)
    # Must NOT raise
    version_check.try_trigger_background_refresh()


def test_try_trigger_background_refresh_windows_creationflags(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("WXFLYWHEEL_WORKER", raising=False)
    monkeypatch.setattr("sys.platform", "win32")
    captured: dict[str, Any] = {}

    def _fake_popen(args: list[str], **kwargs: Any) -> MagicMock:
        captured.update(kwargs)
        return MagicMock()

    monkeypatch.setattr(subprocess, "Popen", _fake_popen)
    version_check.try_trigger_background_refresh()
    assert "creationflags" in captured
    assert "start_new_session" not in captured


# ---------------------------------------------------------------------------
# build_meta
# ---------------------------------------------------------------------------


def test_build_meta_test_mode_returns_minimal_stub(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("WXFLYWHEEL_NO_META", "1")
    meta = version_check.build_meta()
    assert meta == {"cli": {"current_version": __version__}}


def test_build_meta_empty_cache_returns_12_keys(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    # Prevent spawning during the test
    monkeypatch.setattr(version_check, "try_trigger_background_refresh", lambda: None)
    meta = version_check.build_meta()
    cli = meta["cli"]
    assert cli["current_version"] == __version__
    assert cli["latest_version"] is None
    assert cli["update_available"] is None
    assert cli["update_severity"] is None
    assert cli["days_behind"] is None
    assert cli["changelog_url"] is None
    assert cli["latest_release_date"] is None
    assert cli["has_breaking"] is None
    assert cli["cache_age_seconds"] is None
    assert cli["update_command"] == version_check.UPDATE_COMMAND
    assert cli["self_update_command"] == version_check.SELF_UPDATE_COMMAND
    assert "python_version" in cli


def test_build_meta_with_fresh_cache_populates_fields(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(version_check, "try_trigger_background_refresh", lambda: None)
    _isolated_cache.mkdir(parents=True)
    cache = {
        "latest_version": "99.0.0",
        "latest_release_date": "2026-04-06T00:00:00Z",
        "changelog_url": "https://example.com/release",
        "has_breaking": False,
        "checked_at_epoch": time.time() - 60,
    }
    (_isolated_cache / "version_check.json").write_text(json.dumps(cache))
    meta = version_check.build_meta()
    cli = meta["cli"]
    assert cli["latest_version"] == "99.0.0"
    assert cli["update_available"] is True
    assert cli["update_severity"] == "major"
    assert cli["changelog_url"] == "https://example.com/release"
    assert cli["has_breaking"] is False
    assert cli["cache_age_seconds"] is not None


def test_build_meta_triggers_refresh_when_cache_expired(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _isolated_cache.mkdir(parents=True)
    stale_cache = {
        "latest_version": "99.0.0",
        "checked_at_epoch": time.time() - 2 * version_check.CACHE_TTL_SECONDS,
    }
    (_isolated_cache / "version_check.json").write_text(json.dumps(stale_cache))

    triggered = {"n": 0}

    def _fake_trigger() -> None:
        triggered["n"] += 1

    monkeypatch.setattr(version_check, "try_trigger_background_refresh", _fake_trigger)
    version_check.build_meta()
    assert triggered["n"] == 1


def test_build_meta_does_not_trigger_refresh_when_cache_fresh(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _isolated_cache.mkdir(parents=True)
    fresh_cache = {
        "latest_version": __version__,
        "checked_at_epoch": time.time() - 60,
    }
    (_isolated_cache / "version_check.json").write_text(json.dumps(fresh_cache))

    triggered = {"n": 0}
    monkeypatch.setattr(
        version_check,
        "try_trigger_background_refresh",
        lambda: triggered.__setitem__("n", triggered["n"] + 1),
    )
    version_check.build_meta()
    assert triggered["n"] == 0


def test_build_meta_handles_partial_cache_fields(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Cache with only some fields populated should still yield a stable
    12-key schema with missing fields as None."""
    monkeypatch.setattr(version_check, "try_trigger_background_refresh", lambda: None)
    _isolated_cache.mkdir(parents=True)
    partial = {
        "latest_version": "99.0.0",
        "checked_at_epoch": time.time() - 60,
        # No latest_release_date, no changelog_url
    }
    (_isolated_cache / "version_check.json").write_text(json.dumps(partial))
    meta = version_check.build_meta()
    cli = meta["cli"]
    assert cli["latest_version"] == "99.0.0"
    assert cli["latest_release_date"] is None
    assert cli["changelog_url"] is None
    assert cli["days_behind"] is None


def test_build_meta_handles_cache_without_latest_version_key(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Covers the `if isinstance(latest, str) and latest:` False branch — when
    the cache file exists but the latest_version key is missing or empty."""
    monkeypatch.setattr(version_check, "try_trigger_background_refresh", lambda: None)
    _isolated_cache.mkdir(parents=True)
    cache_without_latest = {
        "checked_at_epoch": time.time() - 60,
        # No latest_version at all
    }
    (_isolated_cache / "version_check.json").write_text(json.dumps(cache_without_latest))
    meta = version_check.build_meta()
    cli = meta["cli"]
    assert cli["latest_version"] is None
    assert cli["update_available"] is None
    assert cli["update_severity"] is None


def test_build_meta_handles_cache_with_empty_latest_version_string(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Covers the `if isinstance(latest, str) and latest:` False branch when
    the value is an empty string (distinct from missing key)."""
    monkeypatch.setattr(version_check, "try_trigger_background_refresh", lambda: None)
    _isolated_cache.mkdir(parents=True)
    cache = {
        "latest_version": "",
        "checked_at_epoch": time.time() - 60,
    }
    (_isolated_cache / "version_check.json").write_text(json.dumps(cache))
    meta = version_check.build_meta()
    assert meta["cli"]["latest_version"] is None
