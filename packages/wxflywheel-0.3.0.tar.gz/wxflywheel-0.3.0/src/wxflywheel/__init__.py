"""wxflywheel CLI package."""

__version__ = "0.3.0"
