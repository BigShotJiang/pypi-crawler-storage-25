from __future__ import annotations

import json
from functools import wraps
from typing import Any, Callable, TypeVar

import click

from wxflywheel.exceptions import SUCCESS_CODE, WxflywheelError

JsonObject = dict[str, Any]
F = TypeVar("F", bound=Callable[..., JsonObject])


def success_payload(data: Any, message: str = "") -> JsonObject:
    return {"code": SUCCESS_CODE, "data": data, "message": message}


def error_payload(code: int, message: str, data: Any = None) -> JsonObject:
    return {"code": code, "data": data, "message": message}


def emit_payload(
    payload: JsonObject, *, err: bool = False, include_meta: bool = True
) -> None:
    """Emit a JSON payload to stdout (or stderr if ``err=True``).

    When ``include_meta=True`` (default), the payload is augmented with a
    top-level ``meta`` field containing version info and update-check status
    for AI Agents. Meta injection is wrapped in a broad except so that any
    failure in the version-check subsystem (network, filesystem, parsing) can
    never break the main command's output contract — the Agent always gets
    its primary ``code/data/message`` response even when ``meta`` is absent.
    """
    if include_meta:
        try:
            # Delayed import to avoid circular dependency with wxflywheel.__init__
            from wxflywheel.version_check import build_meta

            payload = {**payload, "meta": build_meta()}
        except Exception:
            # Meta injection must never fail the main command
            pass
    click.echo(json.dumps(payload, ensure_ascii=False, indent=2), err=err)


def emit_error_payload(code: int, message: str, data: Any = None, *, err: bool = True) -> None:
    emit_payload(error_payload(code, message, data), err=err)


def emit_error(error: WxflywheelError) -> None:
    emit_error_payload(error.code, error.message, error.data)
    raise SystemExit(1)


def json_command(func: F) -> F:
    @wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> None:
        try:
            payload = func(*args, **kwargs)
        except WxflywheelError as error:
            emit_error(error)
        else:
            emit_payload(payload)

    return wrapper  # type: ignore[return-value]
