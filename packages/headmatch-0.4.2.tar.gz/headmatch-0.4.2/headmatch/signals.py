from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Tuple

import numpy as np
from scipy import signal


@dataclass
class SweepSpec:
    sample_rate: int = 48000
    duration_s: float = 8.0
    f_start: float = 20.0
    f_end: float = 22000.0
    pre_silence_s: float = 0.5
    post_silence_s: float = 1.0
    amplitude: float = 0.2
    channel: str = 'both'  # left, right, both



def generate_log_sweep(spec: SweepSpec) -> Tuple[np.ndarray, np.ndarray]:
    """Returns stereo sweep and mono reference sweep."""
    n = int(round(spec.duration_s * spec.sample_rate))
    t = np.linspace(0.0, spec.duration_s, n, endpoint=False)
    mono = signal.chirp(
        t,
        f0=spec.f_start,
        t1=spec.duration_s,
        f1=spec.f_end,
        method='logarithmic',
        phi=-90,
    ).astype(np.float64)

    # Cosine fade to reduce clicks
    fade_len = min(int(0.02 * spec.sample_rate), len(mono) // 10)
    if fade_len > 1:
        fade = 0.5 - 0.5 * np.cos(np.linspace(0, np.pi, fade_len))
        mono[:fade_len] *= fade
        mono[-fade_len:] *= fade[::-1]

    mono *= spec.amplitude

    pre = np.zeros(int(round(spec.pre_silence_s * spec.sample_rate)))
    post = np.zeros(int(round(spec.post_silence_s * spec.sample_rate)))
    mono_with_padding = np.concatenate([pre, mono, post])
    stereo = np.zeros((len(mono_with_padding), 2), dtype=np.float64)
    if spec.channel in ('left', 'both'):
        stereo[:, 0] = mono_with_padding
    if spec.channel in ('right', 'both'):
        stereo[:, 1] = mono_with_padding
    return stereo, mono



def fractional_octave_smoothing(freqs_hz: np.ndarray, values_db: np.ndarray, fraction: float = 12.0) -> np.ndarray:
    if len(freqs_hz) != len(values_db):
        raise ValueError('freq and values must have the same length')
    logf = np.log(np.maximum(freqs_hz, 1e-9))
    half_bw = max(np.log(2.0) / (2.0 * fraction), 1e-9)
    # Vectorised: compute full NxN Gaussian weight matrix via outer product
    diff = logf[:, None] - logf[None, :]
    w = np.exp(-0.5 * (diff / half_bw) ** 2)
    w_sum = np.sum(w, axis=1)
    return np.where(w_sum > 1e-12, w @ values_db / w_sum, values_db)



def geometric_log_grid(f_min: float = 20.0, f_max: float = 20000.0, points_per_octave: int = 48) -> np.ndarray:
    octaves = math.log2(f_max / f_min)
    points = int(octaves * points_per_octave) + 1
    return np.geomspace(f_min, f_max, points)
