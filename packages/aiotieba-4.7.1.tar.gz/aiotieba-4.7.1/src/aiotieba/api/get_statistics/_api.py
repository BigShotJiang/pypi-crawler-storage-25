from __future__ import annotations

from typing import TYPE_CHECKING

import yarl

from ...const import APP_BASE_HOST, LATEST_VERSION
from ...exception import TiebaServerError
from ...helper import parse_json
from ._classdef import Statistics

if TYPE_CHECKING:
    from ...core import HttpCore


def parse_body(body: bytes) -> Statistics:
    res_json = parse_json(body)
    if code := int(res_json["error_code"]):
        raise TiebaServerError(code, res_json["error_msg"])

    data_map = res_json["data"]
    stat = Statistics.from_json(data_map)

    return stat


async def request(http_core: HttpCore, fid: int) -> Statistics:
    data = [
        ("BDUSS", http_core.account.BDUSS),
        ("_client_version", LATEST_VERSION),
        ("forum_id", fid),
    ]

    request = http_core.pack_form_request(
        yarl.URL.build(scheme="https", host=APP_BASE_HOST, path="/c/f/forum/getforumdata"), data
    )

    body = await http_core.net_core.send_request(request, read_bufsize=4 * 1024)
    return parse_body(body)
