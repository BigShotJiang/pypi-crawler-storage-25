"""
FangcunGuard Hook SDK (Python)

Inline detection for any agent framework. The agent keeps its own
LLM URL and API key — this SDK only sends input/output content to a
FangcunGuard Hook server for scanning, then applies the returned
action (pass / block / replace / anonymize / restore) locally.

Quick start:

    from fangcun_hook_sdk import HookClient, Action

    hook = HookClient(
        base_url="http://localhost:5002",
        api_key="sk-xxai-...",
    )

    result = hook.scan_input(messages=[
        {"role": "user", "content": "My email is john@example.com"}
    ])
    if result.action == Action.BLOCK:
        raise RuntimeError(result.message)
"""

from .types import Action, ScanResult, FangcunBlocked, FangcunReplaced
from .core import HookClient, AsyncHookClient

__version__ = "0.1.0"

__all__ = [
    "HookClient",
    "AsyncHookClient",
    "Action",
    "ScanResult",
    "FangcunBlocked",
    "FangcunReplaced",
    "__version__",
]
