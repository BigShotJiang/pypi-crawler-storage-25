"""HTTP client for the FangcunGuard Hook server.

Two flavors:
- HookClient        — synchronous, blocks the caller (use in plain Python code)
- AsyncHookClient   — asyncio-based (use inside async agent frameworks)
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import httpx

from .types import Action, ScanResult

logger = logging.getLogger("fangcun_hook_sdk")


_DEFAULT_TIMEOUT = 10.0
_USER_AGENT = "fangcun-hook-sdk-python/0.1"


class _BaseHookClient:
    def __init__(
        self,
        base_url: str,
        api_key: str,
        *,
        timeout: float = _DEFAULT_TIMEOUT,
        fail_open: bool = True,
        primary_path: str = "/v1/hook",
    ):
        """
        Args:
            base_url:     e.g. "http://localhost:5002" — root of the hook server.
            api_key:      application API key (sk-xxai-...).
            timeout:      per-call HTTP timeout in seconds.
            fail_open:    if True (default), network/server errors are logged
                          and the SDK returns Action.PASS so the agent keeps
                          working. Set to False to surface errors as exceptions.
            primary_path: prefix for the new endpoints. Override to "/v1/gateway"
                          to talk to an older server that only has legacy paths.
        """
        if not base_url:
            raise ValueError("base_url is required")
        if not api_key:
            raise ValueError("api_key is required")

        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self.fail_open = fail_open
        self.primary_path = primary_path.rstrip("/")

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": _USER_AGENT,
        }

    def _scan_input_url(self) -> str:
        # /v1/hook/scan-input is primary; /v1/gateway/process-input is the legacy alias.
        path = "scan-input" if self.primary_path.endswith("/hook") else "process-input"
        return f"{self.base_url}{self.primary_path}/{path}"

    def _scan_output_url(self) -> str:
        path = "scan-output" if self.primary_path.endswith("/hook") else "process-output"
        return f"{self.base_url}{self.primary_path}/{path}"

    def _on_error(self, exc: Exception, context: str) -> ScanResult:
        if self.fail_open:
            logger.warning("fangcun-hook %s failed (%s) — failing open with PASS", context, exc)
            return ScanResult(
                action=Action.PASS,
                detection_result={"error": str(exc), "fail_open": True},
                raw={"error": str(exc)},
            )
        raise


class HookClient(_BaseHookClient):
    """Synchronous hook client."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._http = httpx.Client(timeout=self.timeout)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "HookClient":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def scan_input(
        self,
        messages: List[Dict[str, Any]],
        *,
        stream: bool = False,
        client_ip: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> ScanResult:
        """Run the input detection pipeline. See ScanResult.action for outcomes."""
        payload = {"messages": messages, "stream": stream}
        if client_ip:
            payload["client_ip"] = client_ip
        if user_id:
            payload["user_id"] = user_id

        try:
            r = self._http.post(self._scan_input_url(), json=payload, headers=self._headers())
            r.raise_for_status()
            return ScanResult.from_response(r.json())
        except Exception as e:
            return self._on_error(e, "scan_input")

    def scan_output(
        self,
        content: str,
        *,
        restore_mapping: Optional[Dict[str, str]] = None,
        session_id: Optional[str] = None,
        is_streaming: bool = False,
        chunk_index: int = 0,
        messages: Optional[List[Dict[str, Any]]] = None,
    ) -> ScanResult:
        """Run output detection (with optional PII restoration)."""
        payload: Dict[str, Any] = {
            "content": content,
            "is_streaming": is_streaming,
            "chunk_index": chunk_index,
        }
        if restore_mapping:
            payload["restore_mapping"] = restore_mapping
        if session_id:
            payload["session_id"] = session_id
        if messages:
            payload["messages"] = messages

        try:
            r = self._http.post(self._scan_output_url(), json=payload, headers=self._headers())
            r.raise_for_status()
            return ScanResult.from_response(r.json())
        except Exception as e:
            return self._on_error(e, "scan_output")


class AsyncHookClient(_BaseHookClient):
    """Asyncio variant of HookClient."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._http = httpx.AsyncClient(timeout=self.timeout)

    async def aclose(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> "AsyncHookClient":
        return self

    async def __aexit__(self, *exc) -> None:
        await self.aclose()

    async def scan_input(
        self,
        messages: List[Dict[str, Any]],
        *,
        stream: bool = False,
        client_ip: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> ScanResult:
        payload: Dict[str, Any] = {"messages": messages, "stream": stream}
        if client_ip:
            payload["client_ip"] = client_ip
        if user_id:
            payload["user_id"] = user_id

        try:
            r = await self._http.post(self._scan_input_url(), json=payload, headers=self._headers())
            r.raise_for_status()
            return ScanResult.from_response(r.json())
        except Exception as e:
            return self._on_error(e, "scan_input")

    async def scan_output(
        self,
        content: str,
        *,
        restore_mapping: Optional[Dict[str, str]] = None,
        session_id: Optional[str] = None,
        is_streaming: bool = False,
        chunk_index: int = 0,
        messages: Optional[List[Dict[str, Any]]] = None,
    ) -> ScanResult:
        payload: Dict[str, Any] = {
            "content": content,
            "is_streaming": is_streaming,
            "chunk_index": chunk_index,
        }
        if restore_mapping:
            payload["restore_mapping"] = restore_mapping
        if session_id:
            payload["session_id"] = session_id
        if messages:
            payload["messages"] = messages

        try:
            r = await self._http.post(self._scan_output_url(), json=payload, headers=self._headers())
            r.raise_for_status()
            return ScanResult.from_response(r.json())
        except Exception as e:
            return self._on_error(e, "scan_output")
