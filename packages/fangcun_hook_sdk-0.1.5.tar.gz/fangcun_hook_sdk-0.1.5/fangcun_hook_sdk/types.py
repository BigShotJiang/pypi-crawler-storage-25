"""Types and exceptions used by the Hook SDK."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class Action(str, Enum):
    """Disposition action returned by the hook server.

    The SDK turns the server's JSON `action` field into one of these.
    Client code is expected to handle each case explicitly:

    - PASS:               nothing to do, forward the original messages/content
    - BLOCK:              raise / refuse — `message` holds the user-facing reason
    - REPLACE:            return `message` to the user instead of calling the LLM
                          (input scan) or instead of the LLM's response (output scan)
    - ANONYMIZE:          forward `anonymized_messages` to the LLM, keep
                          `restore_mapping` for the output-side restore step
    - RESTORE:            on output scan only — `content` is the restored text
                          (placeholders replaced with originals); use this instead
                          of the raw LLM response
    - SWITCH_PRIVATE_MODEL: route this request to a private model rather than
                          the public LLM (advanced; requires server-side config)
    - UNKNOWN:            fallback for unrecognized server actions — treat as PASS
                          but log
    """
    PASS = "pass"
    BLOCK = "block"
    REPLACE = "replace"
    ANONYMIZE = "anonymize"
    RESTORE = "restore"
    SWITCH_PRIVATE_MODEL = "switch_private_model"
    UNKNOWN = "unknown"

    @classmethod
    def from_str(cls, value: Optional[str]) -> "Action":
        if not value:
            return cls.UNKNOWN
        try:
            return cls(value)
        except ValueError:
            return cls.UNKNOWN


@dataclass
class ScanResult:
    """Normalized result of a scan_input or scan_output call."""

    action: Action
    request_id: Optional[str] = None
    message: Optional[str] = None
    """User-facing reason / replacement content (set for BLOCK and REPLACE)."""

    content: Optional[str] = None
    """Restored output content (set for RESTORE on scan_output)."""

    anonymized_messages: Optional[List[Dict[str, Any]]] = None
    """Anonymized input messages (set for ANONYMIZE on scan_input).
    Forward these to the LLM instead of the originals."""

    session_id: Optional[str] = None
    """Session ID for the (deprecated) server-side mapping lookup. Prefer
    keeping `restore_mapping` client-side instead."""

    restore_mapping: Optional[Dict[str, str]] = None
    """Placeholder->original mapping. The client must store this between the
    scan_input call and the matching scan_output call so PII can be restored."""

    detection_result: Dict[str, Any] = field(default_factory=dict)
    """Full detection breakdown from the server: risk levels, matched scanners,
    DLP entities, etc. Useful for logging / dashboards."""

    private_model: Optional[Dict[str, Any]] = None
    """Private model config (set for SWITCH_PRIVATE_MODEL)."""

    processing_time_ms: Optional[float] = None

    raw: Dict[str, Any] = field(default_factory=dict)
    """Raw server response. Always populated as a safety net for fields the
    SDK does not surface yet."""

    @classmethod
    def from_response(cls, data: Dict[str, Any]) -> "ScanResult":
        action = Action.from_str(data.get("action"))
        # The server uses different keys in different code paths:
        #   block  -> "message"  (user-facing block reason)
        #   replace-> "message"  (template content)
        #   restore-> "content"  (restored text)
        # Output-scan replace can also surface in "message" or "suggest_answer".
        message = (
            data.get("message")
            or data.get("suggest_answer")
            or data.get("reason")
        )
        return cls(
            action=action,
            request_id=data.get("request_id"),
            message=message,
            content=data.get("content"),
            anonymized_messages=data.get("anonymized_messages"),
            session_id=data.get("session_id"),
            restore_mapping=data.get("restore_mapping"),
            detection_result=data.get("detection_result") or {},
            private_model=data.get("private_model"),
            processing_time_ms=data.get("processing_time_ms"),
            raw=data,
        )

    @property
    def overall_risk_level(self) -> str:
        return self.detection_result.get("overall_risk_level", "unknown")

    def is_blocked(self) -> bool:
        return self.action == Action.BLOCK

    def is_modified(self) -> bool:
        """True if the scan altered the content the agent should pass on."""
        return self.action in (
            Action.REPLACE,
            Action.ANONYMIZE,
            Action.RESTORE,
        )


class FangcunError(Exception):
    """Base class for SDK-level errors."""


class FangcunBlocked(FangcunError):
    """Raised by adapters when the hook server returns action=block."""

    def __init__(self, message: str, result: Optional[ScanResult] = None):
        super().__init__(message)
        self.result = result


class FangcunReplaced(FangcunError):
    """Signaling exception adapters MAY raise to short-circuit the LLM call when
    action=replace. Most adapters prefer to return a fake completion instead."""

    def __init__(self, message: str, result: Optional[ScanResult] = None):
        super().__init__(message)
        self.result = result
