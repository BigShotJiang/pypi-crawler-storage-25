"""Claude Code installer + hook runtime.

`fangcun install --agent claude-code` calls `ClaudeCodeInstaller.install()`,
which:
  1. Materializes a tiny shim at ~/.fangcun/scripts/claude_code.py that
     calls `hook_main()` from this module.
  2. Reads ~/.claude/settings.json (or creates an empty one), merges three
     hook events (UserPromptSubmit / PostToolUse / Stop) pointing at the
     materialized shim, and injects FANGCUN_API_KEY into the `env` block.
  3. Each entry we add is tagged with `_fangcun_managed: true` so we can
     remove only our own entries on `fangcun remove`.
"""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..types import Action
from .base import (
    FANGCUN_HOOK_TAG,
    AgentDetection,
    AgentInstaller,
    InstallResult,
    InstallStatus,
    build_client_from_env,
    emit_block,
    emit_pass,
    emit_replace,
    load_mapping,
    read_stdin_json,
    save_mapping,
)


# ============================================================
# Runtime: hook_main called by the materialized shim script
# ============================================================


def _user_prompt_messages(payload: Dict[str, Any]) -> List[Dict[str, Any]]:
    text = payload.get("prompt") or payload.get("user_prompt") or ""
    if not text:
        return []
    return [{"role": "user", "content": text}]


def _tool_result_text(payload: Dict[str, Any]) -> str:
    tr = payload.get("tool_response") or payload.get("toolResponse") or {}
    if isinstance(tr, str):
        return tr
    if isinstance(tr, dict):
        for key in ("output", "content", "stdout", "result"):
            v = tr.get(key)
            if isinstance(v, str) and v:
                return v
            if isinstance(v, list):
                texts = [b.get("text", "") for b in v if isinstance(b, dict)]
                joined = "".join(texts)
                if joined:
                    return joined
    return ""


def _stop_message_text(payload: Dict[str, Any]) -> str:
    msg = payload.get("response") or payload.get("assistant_message") or ""
    if isinstance(msg, str):
        return msg
    if isinstance(msg, dict):
        return str(msg.get("content", ""))
    return ""


def _session_id(payload: Dict[str, Any]) -> Optional[str]:
    return payload.get("session_id") or payload.get("sessionId")


def _handle_user_prompt_submit(client, payload: Dict[str, Any]) -> None:
    msgs = _user_prompt_messages(payload)
    if not msgs:
        emit_pass()
        return
    result = client.scan_input(msgs, stream=False)
    if result.action == Action.BLOCK:
        emit_block(result.message or "blocked by FangcunGuard")
        return
    if result.action == Action.REPLACE:
        emit_replace(result.message or "[replaced]")
        return
    if result.action == Action.ANONYMIZE and result.restore_mapping:
        sid = _session_id(payload) or result.session_id or "default"
        save_mapping(sid, result.restore_mapping)
    emit_pass()


def _handle_post_tool_use(client, payload: Dict[str, Any]) -> None:
    text = _tool_result_text(payload)
    if not text:
        emit_pass()
        return
    sid = _session_id(payload)
    mapping = load_mapping(sid)
    result = client.scan_output(text, restore_mapping=mapping)
    if result.action == Action.BLOCK:
        emit_block(result.message or "blocked by FangcunGuard (tool result)")
        return
    if result.action in (Action.REPLACE, Action.RESTORE):
        emit_replace(result.content or result.message or text)
        return
    emit_pass()


def _handle_stop(client, payload: Dict[str, Any]) -> None:
    text = _stop_message_text(payload)
    if not text:
        emit_pass()
        return
    sid = _session_id(payload)
    mapping = load_mapping(sid)
    result = client.scan_output(text, restore_mapping=mapping)
    if result.action == Action.BLOCK:
        emit_block(result.message or "blocked by FangcunGuard (assistant output)")
        return
    if result.action in (Action.REPLACE, Action.RESTORE):
        emit_replace(result.content or result.message or text)
        return
    emit_pass()


_DISPATCH = {
    "UserPromptSubmit": _handle_user_prompt_submit,
    "PostToolUse": _handle_post_tool_use,
    "Stop": _handle_stop,
}


def hook_main() -> int:
    """Stdin/stdout entry point. Called from both
    `integrations/claude-code/fangcun_claude_hook.py` and the materialized
    `~/.fangcun/scripts/claude_code.py` shim."""
    payload = read_stdin_json()
    event = payload.get("hook_event_name") or payload.get("hookEventName") or ""
    handler = _DISPATCH.get(event)
    if handler is None:
        emit_pass()
        return 0
    client = build_client_from_env()
    if client is None:
        emit_pass()
        return 0
    try:
        handler(client, payload)
    finally:
        client.close()
    return 0


# ============================================================
# Install / uninstall / status
# ============================================================


_CONFIG_DIR = Path.home() / ".claude"
_CONFIG_FILE = _CONFIG_DIR / "settings.json"
_HOOK_EVENTS = ("UserPromptSubmit", "PostToolUse", "Stop")


def _hook_command() -> List[str]:
    """The settings.json `command` field — uses `python` from PATH and the
    materialized script's absolute path."""
    script = (Path.home() / ".fangcun" / "scripts" / "claude_code.py").as_posix()
    py = sys.executable.replace("\\", "/")
    return [f'"{py}" "{script}"']


def _read_settings(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_settings(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _is_fangcun_entry(matcher_block: Dict[str, Any]) -> bool:
    """A `matcher` block looks like {"matcher": "...", "hooks": [...]}.
    We tag each `hooks` entry we add with `_fangcun_managed: true`."""
    for h in matcher_block.get("hooks", []) or []:
        if isinstance(h, dict) and h.get("_fangcun_managed"):
            return True
    return False


def _strip_fangcun(matcher_block: Dict[str, Any]) -> Dict[str, Any]:
    matcher_block["hooks"] = [
        h for h in matcher_block.get("hooks", []) or []
        if not (isinstance(h, dict) and h.get("_fangcun_managed"))
    ]
    return matcher_block


def _build_fangcun_matcher_block(command: str) -> Dict[str, Any]:
    return {
        "matcher": "",
        "hooks": [
            {
                "type": "command",
                "command": command,
                "timeout": 30,
                "_fangcun_managed": True,
            }
        ],
    }


class ClaudeCodeInstaller(AgentInstaller):
    name = "claude-code"
    display_name = "Claude Code"
    script_filename = "claude_code.py"

    def detect(self) -> AgentDetection:
        binary = shutil.which("claude")
        config_exists = _CONFIG_DIR.exists()
        found = bool(binary) or config_exists
        notes = []
        if not binary and config_exists:
            notes.append("`claude` not in PATH but ~/.claude/ exists; will configure anyway.")
        if not found:
            notes.append("Could not find `claude` binary or ~/.claude/ directory.")
        return AgentDetection(
            found=found,
            binary_path=Path(binary) if binary else None,
            config_path=_CONFIG_FILE,
            notes=notes,
        )

    def install(self, api_key: str, hook_url: str, fail_open: bool = True) -> InstallResult:
        actions: List[str] = []
        warnings: List[str] = []
        errors: List[str] = []

        try:
            script_path = self.materialize_script()
            actions.append(f"Wrote hook shim: {script_path}")
        except OSError as e:
            errors.append(f"Failed to write hook shim: {e}")
            return InstallResult(success=False, actions=actions, warnings=warnings, errors=errors)

        settings = _read_settings(_CONFIG_FILE)

        # 1. Inject env so the agent's hook subprocess inherits FANGCUN_*
        env = settings.setdefault("env", {})
        env["FANGCUN_API_KEY"] = api_key
        env["FANGCUN_HOOK_URL"] = hook_url
        env["FANGCUN_FAIL_OPEN"] = "true" if fail_open else "false"
        actions.append("Injected FANGCUN_* env into settings.json")

        # 2. Register hook command for each event (idempotent: drop any
        #    prior fangcun-tagged entry first, then append fresh)
        hooks_root = settings.setdefault("hooks", {})
        command = _hook_command()[0]
        registered = 0
        for event in _HOOK_EVENTS:
            event_blocks = hooks_root.setdefault(event, [])
            event_blocks[:] = [
                _strip_fangcun(b) for b in event_blocks if isinstance(b, dict)
            ]
            event_blocks[:] = [b for b in event_blocks if b.get("hooks")]
            event_blocks.append(_build_fangcun_matcher_block(command))
            registered += 1
        actions.append(f"Registered FangcunGuard hooks on {registered} events: {', '.join(_HOOK_EVENTS)}")

        try:
            _write_settings(_CONFIG_FILE, settings)
            actions.append(f"Updated {_CONFIG_FILE}")
        except OSError as e:
            errors.append(f"Failed to write settings.json: {e}")
            return InstallResult(success=False, actions=actions, warnings=warnings, errors=errors)

        return InstallResult(success=True, actions=actions, warnings=warnings, errors=errors)

    def uninstall(self) -> InstallResult:
        actions: List[str] = []
        warnings: List[str] = []

        if self.remove_materialized_script():
            actions.append(f"Removed {self.materialized_script_path}")

        if not _CONFIG_FILE.exists():
            return InstallResult(success=True, actions=actions, warnings=warnings)

        settings = _read_settings(_CONFIG_FILE)
        hooks_root = settings.get("hooks", {})
        removed = 0
        for event in list(hooks_root.keys()):
            blocks = hooks_root.get(event) or []
            new_blocks = []
            for b in blocks:
                if not isinstance(b, dict):
                    new_blocks.append(b)
                    continue
                stripped = _strip_fangcun(b)
                if stripped.get("hooks"):
                    new_blocks.append(stripped)
                else:
                    removed += 1
            if new_blocks:
                hooks_root[event] = new_blocks
            else:
                del hooks_root[event]
        if not hooks_root:
            settings.pop("hooks", None)
        env = settings.get("env", {})
        for k in ("FANGCUN_API_KEY", "FANGCUN_HOOK_URL", "FANGCUN_FAIL_OPEN"):
            env.pop(k, None)
        if env == {}:
            settings.pop("env", None)

        _write_settings(_CONFIG_FILE, settings)
        if removed:
            actions.append(f"Removed {removed} FangcunGuard hook entries from {_CONFIG_FILE}")
        else:
            warnings.append(f"No FangcunGuard hook entries found in {_CONFIG_FILE}")

        return InstallResult(success=True, actions=actions, warnings=warnings)

    def status(self) -> InstallStatus:
        det = self.detect()
        installed = False
        hook_url = None
        if _CONFIG_FILE.exists():
            settings = _read_settings(_CONFIG_FILE)
            for event in _HOOK_EVENTS:
                for b in settings.get("hooks", {}).get(event, []) or []:
                    if isinstance(b, dict) and _is_fangcun_entry(b):
                        installed = True
                        break
                if installed:
                    break
            hook_url = settings.get("env", {}).get("FANGCUN_HOOK_URL")
        return InstallStatus(
            agent_name=self.display_name,
            detected=det.found,
            fangcun_installed=installed,
            config_path=_CONFIG_FILE,
            script_path=self.materialized_script_path if self.materialized_script_path.exists() else None,
            hook_url=hook_url,
            notes=det.notes,
        )
