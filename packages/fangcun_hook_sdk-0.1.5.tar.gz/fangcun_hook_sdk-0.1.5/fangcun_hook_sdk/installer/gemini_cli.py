"""Gemini CLI installer + hook runtime.

Uniquely scans the FULL LLM request body via BeforeModel — see
integrations/gemini-cli/README.md.

Output protocol: exit 0 + JSON on stdout = success; exit 2 + reason on
stderr = block.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..types import Action
from .base import (
    AgentDetection,
    AgentInstaller,
    InstallResult,
    InstallStatus,
    build_client_from_env,
    load_mapping,
    read_stdin_json,
    save_mapping,
)


# ============================================================
# Runtime
# ============================================================


def _emit(out: Dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(out, ensure_ascii=False))
    sys.stdout.flush()


def _block(reason: str) -> int:
    sys.stderr.write(reason + "\n")
    return 2


def _normalize_messages(raw_messages: List[Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for m in raw_messages:
        if not isinstance(m, dict):
            continue
        role = m.get("role") or "user"
        content = m.get("content") or m.get("parts") or ""
        if isinstance(content, list):
            text = " ".join(
                str(p.get("text", "")) if isinstance(p, dict) else str(p) for p in content
            )
        else:
            text = str(content)
        if text:
            out.append({"role": str(role), "content": text})
    return out


def _extract_response_text(response: Any) -> str:
    if response is None:
        return ""
    if isinstance(response, str):
        return response
    if isinstance(response, dict):
        for key in ("text", "content", "output"):
            v = response.get(key)
            if isinstance(v, str) and v:
                return v
        candidates = response.get("candidates")
        if isinstance(candidates, list) and candidates:
            first = candidates[0]
            if isinstance(first, dict):
                content = first.get("content") or {}
                parts = content.get("parts") if isinstance(content, dict) else None
                if isinstance(parts, list):
                    return " ".join(
                        str(p.get("text", "")) if isinstance(p, dict) else str(p) for p in parts
                    )
    return str(response)


def _handle_before_model(client, payload: Dict[str, Any]) -> int:
    req = payload.get("llm_request") or payload.get("request") or {}
    if not isinstance(req, dict):
        _emit({})
        return 0
    raw_messages = req.get("messages") or []
    msgs = _normalize_messages(raw_messages)
    if not msgs:
        _emit({})
        return 0
    result = client.scan_input(msgs, stream=False)
    sid = payload.get("session_id") or payload.get("sessionId") or "default"

    if result.action == Action.BLOCK:
        return _block(result.message or "blocked by FangcunGuard")
    if result.action == Action.REPLACE:
        synthetic = {"candidates": [{"content": {"parts": [{"text": result.message or "[replaced]"}]}}]}
        _emit({"hookSpecificOutput": {"llm_response": synthetic}, "decision": "skip"})
        return 0
    if result.action == Action.ANONYMIZE and result.anonymized_messages:
        if result.restore_mapping:
            save_mapping(sid, result.restore_mapping)
        new_req = {**req, "messages": result.anonymized_messages}
        _emit({"hookSpecificOutput": {"llm_request": new_req}})
        return 0
    _emit({})
    return 0


def _handle_after_model(client, payload: Dict[str, Any]) -> int:
    response = payload.get("llm_response") or payload.get("response") or {}
    text = _extract_response_text(response)
    if not text:
        _emit({})
        return 0
    sid = payload.get("session_id") or payload.get("sessionId")
    mapping = load_mapping(sid)
    result = client.scan_output(text, restore_mapping=mapping)

    if result.action == Action.BLOCK:
        return _block(result.message or "blocked by FangcunGuard (output)")
    if result.action in (Action.REPLACE, Action.RESTORE):
        new_text = result.content or result.message or text
        synthetic = {"candidates": [{"content": {"parts": [{"text": new_text}]}}]}
        _emit({"hookSpecificOutput": {"llm_response": synthetic}})
        return 0
    _emit({})
    return 0


def hook_main() -> int:
    payload = read_stdin_json()
    event = payload.get("hook_event_name") or payload.get("event") or ""
    client = build_client_from_env()
    if client is None:
        _emit({})
        return 0
    try:
        if event in ("BeforeModel", "before_model"):
            return _handle_before_model(client, payload)
        if event in ("AfterModel", "after_model"):
            return _handle_after_model(client, payload)
        _emit({})
        return 0
    finally:
        client.close()


# ============================================================
# Install / uninstall
# ============================================================


_CONFIG_DIR_CANDIDATES = [
    Path.home() / ".gemini",
    Path.home() / ".gemini-cli",
]


def _config_dir() -> Path:
    for c in _CONFIG_DIR_CANDIDATES:
        if c.exists():
            return c
    return _CONFIG_DIR_CANDIDATES[0]


def _config_file() -> Path:
    d = _config_dir()
    return d / "hooks.json"


_HOOK_EVENTS = ("BeforeModel", "AfterModel")


def _hook_command_str() -> str:
    script = (Path.home() / ".fangcun" / "scripts" / "gemini_cli.py").as_posix()
    py = sys.executable.replace("\\", "/")
    return f'"{py}" "{script}"'


def _read_json(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_json(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _is_fangcun(entry: Dict[str, Any]) -> bool:
    return bool(entry.get("_fangcun_managed"))


class GeminiCliInstaller(AgentInstaller):
    name = "gemini-cli"
    display_name = "Gemini CLI"
    script_filename = "gemini_cli.py"

    def detect(self) -> AgentDetection:
        binary = shutil.which("gemini") or shutil.which("gemini-cli")
        existing_dir = next((c for c in _CONFIG_DIR_CANDIDATES if c.exists()), None)
        found = bool(binary) or existing_dir is not None
        notes = []
        if not found:
            notes.append("Could not find `gemini`/`gemini-cli` binary or config dir.")
        return AgentDetection(
            found=found,
            binary_path=Path(binary) if binary else None,
            config_path=_config_file(),
            notes=notes,
        )

    def install(self, api_key: str, hook_url: str, fail_open: bool = True) -> InstallResult:
        actions: List[str] = []
        errors: List[str] = []

        try:
            script_path = self.materialize_script()
            actions.append(f"Wrote hook shim: {script_path}")
        except OSError as e:
            errors.append(f"Failed to write hook shim: {e}")
            return InstallResult(success=False, actions=actions, errors=errors)

        cfg_path = _config_file()
        cfg = _read_json(cfg_path)

        env = cfg.setdefault("env", {})
        env["FANGCUN_API_KEY"] = api_key
        env["FANGCUN_HOOK_URL"] = hook_url
        env["FANGCUN_FAIL_OPEN"] = "true" if fail_open else "false"
        actions.append("Injected FANGCUN_* env into hooks.json")

        hooks = cfg.setdefault("hooks", {})
        cmd = _hook_command_str()
        for event in _HOOK_EVENTS:
            arr = hooks.setdefault(event, [])
            arr[:] = [h for h in arr if not (isinstance(h, dict) and _is_fangcun(h))]
            arr.append({"command": cmd, "timeout": 30000, "_fangcun_managed": True})
        actions.append(f"Registered BeforeModel + AfterModel hooks (full LLM request scanning)")

        _write_json(cfg_path, cfg)
        actions.append(f"Updated {cfg_path}")
        return InstallResult(success=True, actions=actions)

    def uninstall(self) -> InstallResult:
        actions: List[str] = []
        warnings: List[str] = []

        if self.remove_materialized_script():
            actions.append(f"Removed {self.materialized_script_path}")

        cfg_path = _config_file()
        if not cfg_path.exists():
            return InstallResult(success=True, actions=actions, warnings=warnings)

        cfg = _read_json(cfg_path)
        hooks = cfg.get("hooks", {})
        removed = 0
        for event in list(hooks.keys()):
            arr = hooks[event] or []
            new_arr = [h for h in arr if not (isinstance(h, dict) and _is_fangcun(h))]
            removed += len(arr) - len(new_arr)
            if new_arr:
                hooks[event] = new_arr
            else:
                del hooks[event]
        env = cfg.get("env", {})
        for k in ("FANGCUN_API_KEY", "FANGCUN_HOOK_URL", "FANGCUN_FAIL_OPEN"):
            env.pop(k, None)
        if env == {}:
            cfg.pop("env", None)
        if not hooks:
            cfg.pop("hooks", None)
        _write_json(cfg_path, cfg)
        if removed:
            actions.append(f"Removed {removed} FangcunGuard hook entries from {cfg_path}")
        else:
            warnings.append(f"No FangcunGuard hook entries found in {cfg_path}")
        return InstallResult(success=True, actions=actions, warnings=warnings)

    def status(self) -> InstallStatus:
        det = self.detect()
        installed = False
        hook_url = None
        cfg_path = _config_file()
        if cfg_path.exists():
            cfg = _read_json(cfg_path)
            for event in _HOOK_EVENTS:
                if any(_is_fangcun(h) for h in cfg.get("hooks", {}).get(event, []) if isinstance(h, dict)):
                    installed = True
                    break
            hook_url = cfg.get("env", {}).get("FANGCUN_HOOK_URL")
        return InstallStatus(
            agent_name=self.display_name,
            detected=det.found,
            fangcun_installed=installed,
            config_path=cfg_path,
            script_path=self.materialized_script_path if self.materialized_script_path.exists() else None,
            hook_url=hook_url,
            notes=det.notes,
        )
