"""Per-agent installers for FangcunGuard Tier-A native hooks.

This sub-package is logically separate from `fangcun_hook_sdk.adapters/`:

- `adapters/` contains in-process Python callbacks/wrappers users import
  directly into their own code (LangChain, LlamaIndex, OpenAI, etc.).
- `installer/` contains the install machinery + runtime entry points for
  agent apps that load hooks via their own native config systems
  (Claude Code, Codex CLI, Cursor, Gemini CLI, OpenClaw).

Public surface used by `fangcun_hook_sdk.cli`:
"""
from __future__ import annotations

from typing import Dict, Type

from .base import AgentDetection, AgentInstaller, InstallResult, InstallStatus
from .claude_code import ClaudeCodeInstaller
from .codex_cli import CodexCliInstaller
from .cursor import CursorInstaller
from .gemini_cli import GeminiCliInstaller
from .openclaw import OpenclawInstaller


REGISTRY: Dict[str, Type[AgentInstaller]] = {
    ClaudeCodeInstaller.name: ClaudeCodeInstaller,
    CodexCliInstaller.name: CodexCliInstaller,
    CursorInstaller.name: CursorInstaller,
    GeminiCliInstaller.name: GeminiCliInstaller,
    OpenclawInstaller.name: OpenclawInstaller,
}


__all__ = [
    "AgentDetection",
    "AgentInstaller",
    "InstallResult",
    "InstallStatus",
    "ClaudeCodeInstaller",
    "CodexCliInstaller",
    "CursorInstaller",
    "GeminiCliInstaller",
    "OpenclawInstaller",
    "REGISTRY",
]
