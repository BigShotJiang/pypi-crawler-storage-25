"""Project-mode installer: `fangcun install --project ./my-app`.

Combines two existing surfaces into one workflow:

  1. The 5 native-agent installers (Claude Code / Codex / Cursor / Gemini /
     OpenClaw) — they write to ~/.<agent>/ regardless of project, so we
     just run their existing detect → install logic.
  2. The new framework patchers (LangChain MVP; LlamaIndex / AutoGen /
     CrewAI to follow) — these scan the project source for LLM
     construction sites and emit unified-diff PatchPlans.

Default mode is dry-run (preview only): nothing on disk changes for the
framework half. The agent half always writes when `apply=True` because
that's what `fangcun install --all` already does.

Pass `apply=True` AND `write=True` to turn diffs into real file edits;
each touched .py file gets a `<name>.py.bak` backup beside it.
"""
from __future__ import annotations

import difflib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from . import REGISTRY as AGENT_REGISTRY
from .base import AgentInstaller, InstallResult
from .framework_base import FrameworkResult, PatchPlan
from .frameworks import REGISTRY as FRAMEWORK_REGISTRY


@dataclass
class AgentRunResult:
    """One agent installer's outcome inside a project run."""
    agent_name: str
    detected_on_machine: bool
    install_result: Optional[InstallResult] = None     # None if skipped
    skipped_reason: Optional[str] = None


@dataclass
class ProjectInstallReport:
    project_root: Path
    api_key_hint: str                                   # last 6 chars only, for echo
    hook_url: str
    agent_results: List[AgentRunResult] = field(default_factory=list)
    framework_results: List[FrameworkResult] = field(default_factory=list)
    write_applied: bool = False                         # did we touch user files?

    @property
    def has_framework_changes(self) -> bool:
        return any(fr.has_changes for fr in self.framework_results)

    @property
    def overall_ok(self) -> bool:
        for ar in self.agent_results:
            if ar.install_result and not ar.install_result.success:
                return False
        for fr in self.framework_results:
            if fr.errors:
                return False
        return True


class ProjectInstaller:
    """The thing `fangcun install --project ...` actually runs."""

    def __init__(
        self,
        project_root: Path,
        api_key: str,
        hook_url: str,
        *,
        fail_open: bool = True,
    ) -> None:
        self.project_root = project_root.resolve()
        self.api_key = api_key
        self.hook_url = hook_url
        self.fail_open = fail_open

    # ──────────────────────────────────────────────────────────────
    # Public entry: detect everything, optionally apply
    # ──────────────────────────────────────────────────────────────

    def run(self, *, apply: bool = True, write: bool = False, force: bool = False) -> ProjectInstallReport:
        if not self.project_root.is_dir():
            raise NotADirectoryError(f"--project path not a directory: {self.project_root}")

        report = ProjectInstallReport(
            project_root=self.project_root,
            api_key_hint=("…" + self.api_key[-6:]) if len(self.api_key) > 6 else self.api_key,
            hook_url=self.hook_url,
        )

        report.agent_results = self._run_agents(apply=apply, force=force)
        report.framework_results = self._run_frameworks()

        if write and apply:
            for fr in report.framework_results:
                for plan in fr.patches:
                    if plan.is_noop:
                        continue
                    _apply_patch_to_disk(plan)
            report.write_applied = True

        return report

    # ──────────────────────────────────────────────────────────────
    # Agent half — global config, doesn't read project source
    # ──────────────────────────────────────────────────────────────

    def _run_agents(self, *, apply: bool, force: bool) -> List[AgentRunResult]:
        out: List[AgentRunResult] = []
        for cls in AGENT_REGISTRY.values():
            inst: AgentInstaller = cls()
            det = inst.detect()
            if not det.found and not force:
                out.append(AgentRunResult(
                    agent_name=inst.display_name,
                    detected_on_machine=False,
                    skipped_reason="agent not detected on this machine",
                ))
                continue
            if not apply:
                out.append(AgentRunResult(
                    agent_name=inst.display_name,
                    detected_on_machine=det.found,
                    skipped_reason="dry-run (apply=False)",
                ))
                continue
            try:
                ir = inst.install(api_key=self.api_key, hook_url=self.hook_url, fail_open=self.fail_open)
            except Exception as e:
                ir = InstallResult(success=False, errors=[f"installer raised: {e!r}"])
            out.append(AgentRunResult(
                agent_name=inst.display_name,
                detected_on_machine=det.found,
                install_result=ir,
            ))
        return out

    # ──────────────────────────────────────────────────────────────
    # Framework half — reads project source, emits PatchPlans
    # ──────────────────────────────────────────────────────────────

    def _run_frameworks(self) -> List[FrameworkResult]:
        out: List[FrameworkResult] = []
        for cls in FRAMEWORK_REGISTRY.values():
            patcher = cls()
            try:
                detection = patcher.detect(self.project_root)
            except Exception as e:
                out.append(FrameworkResult(
                    framework_name=patcher.name,
                    detection=type("D", (), {"found": False, "framework_name": patcher.name})(),  # placeholder
                    errors=[f"detect() raised: {e!r}"],
                ))
                continue

            if not detection.found:
                out.append(FrameworkResult(framework_name=patcher.name, detection=detection))
                continue

            # Detected → find call sites → group by file → build patches
            try:
                sites = patcher.find_call_sites(self.project_root)
            except Exception as e:
                out.append(FrameworkResult(
                    framework_name=patcher.name,
                    detection=detection,
                    errors=[f"find_call_sites() raised: {e!r}"],
                ))
                continue

            by_file: Dict[Path, List] = {}
            for s in sites:
                by_file.setdefault(s.file, []).append(s)

            patches: List[PatchPlan] = []
            for file, file_sites in by_file.items():
                try:
                    source = file.read_text(encoding="utf-8")
                except OSError as e:
                    patches.append(PatchPlan(
                        file=file, original="", patched="",
                        call_sites_modified=0, skipped_reason=f"read failed: {e}",
                    ))
                    continue
                try:
                    plan = patcher.build_patch(
                        file=file,
                        source=source,
                        call_sites=file_sites,
                        api_key=self.api_key,
                        hook_url=self.hook_url,
                    )
                except Exception as e:
                    plan = PatchPlan(
                        file=file, original=source, patched=source,
                        call_sites_modified=0, skipped_reason=f"build_patch raised: {e!r}",
                    )
                patches.append(plan)

            manual: Optional[str] = None
            if not sites:
                manual = _manual_instructions(patcher.display_name, self.api_key, self.hook_url)

            out.append(FrameworkResult(
                framework_name=patcher.name,
                detection=detection,
                patches=patches,
                manual_instructions=manual,
            ))
        return out


# ============================================================
# Pretty-printing helpers (used by cli.py)
# ============================================================


def render_unified_diff(plan: PatchPlan, *, n_context: int = 3) -> str:
    if plan.is_noop:
        return ""
    rel = plan.file
    return "".join(
        difflib.unified_diff(
            plan.original.splitlines(keepends=True),
            plan.patched.splitlines(keepends=True),
            fromfile=str(rel),
            tofile=str(rel),
            n=n_context,
        )
    )


def _apply_patch_to_disk(plan: PatchPlan) -> None:
    """Write `plan.patched` to `plan.file`, dropping a `<name>.py.bak`
    next to it first. No-op if the patch is identical."""
    if plan.is_noop:
        return
    bak = plan.file.with_suffix(plan.file.suffix + ".bak")
    try:
        bak.write_text(plan.original, encoding="utf-8")
    except OSError:
        pass
    plan.file.write_text(plan.patched, encoding="utf-8")


def _manual_instructions(framework_display: str, api_key: str, hook_url: str) -> str:
    return (
        f"{framework_display} detected via requirements / imports, but no LLM "
        f"construction site auto-located. Add this manually anywhere in your code:\n\n"
        f"    from fangcun_hook_sdk import HookClient\n"
        f"    from fangcun_hook_sdk.adapters.langchain_callback import FangcunCallbackHandler\n"
        f"    _fc_hook = HookClient(api_key={api_key!r}, base_url={hook_url!r})\n"
        f"    _fc = FangcunCallbackHandler(hook=_fc_hook)\n\n"
        f"Then add `callbacks=[_fc]` to your LLM constructor:\n"
        f"    llm = ChatOpenAI(..., callbacks=[_fc])\n"
    )
