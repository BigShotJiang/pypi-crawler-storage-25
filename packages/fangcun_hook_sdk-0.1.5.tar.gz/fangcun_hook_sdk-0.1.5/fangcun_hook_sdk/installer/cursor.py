"""Cursor IDE installer + hook runtime."""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..types import Action
from .base import (
    AgentDetection,
    AgentInstaller,
    InstallResult,
    InstallStatus,
    build_client_from_env,
    load_mapping,
    read_stdin_json,
    save_mapping,
    write_json,
)


# ============================================================
# Runtime — Cursor expects {"continue": bool, "reason"?: string}
# ============================================================


def _emit_cursor(decision: str, reason: Optional[str] = None) -> None:
    if decision in ("block", "replace"):
        out: Dict[str, Any] = {"continue": False, "reason": reason or "blocked by FangcunGuard"}
    else:
        out = {"continue": True}
    write_json(out)


def _prompt_text(payload: Dict[str, Any]) -> str:
    return str(
        payload.get("prompt") or payload.get("message") or payload.get("text") or payload.get("input") or ""
    )


def _shell_command_text(payload: Dict[str, Any]) -> str:
    cmd = payload.get("command") or payload.get("shellCommand") or ""
    if isinstance(cmd, list):
        return " ".join(str(c) for c in cmd)
    return str(cmd)


def _mcp_call_text(payload: Dict[str, Any]) -> str:
    name = payload.get("toolName") or payload.get("name") or ""
    args = payload.get("arguments") or payload.get("params") or {}
    return f"[mcp:{name}] {json.dumps(args, ensure_ascii=False) if args else ''}"


def _result_text(payload: Dict[str, Any]) -> str:
    out = payload.get("output") or payload.get("result") or payload.get("stdout") or ""
    if isinstance(out, str):
        return out
    return json.dumps(out, ensure_ascii=False)


def _session_id(payload: Dict[str, Any]) -> Optional[str]:
    return payload.get("sessionId") or payload.get("session_id")


def _scan_input(client, payload, text: str, kind: str) -> None:
    if not text:
        _emit_cursor("pass")
        return
    msgs = [{"role": "user", "content": text}]
    result = client.scan_input(msgs, stream=False)
    if result.action == Action.BLOCK:
        _emit_cursor("block", result.message or f"blocked by FangcunGuard ({kind})")
        return
    if result.action == Action.REPLACE:
        _emit_cursor("replace", result.message or "[replaced]")
        return
    if result.action == Action.ANONYMIZE and result.restore_mapping:
        sid = _session_id(payload) or result.session_id or "default"
        save_mapping(sid, result.restore_mapping)
    _emit_cursor("pass")


def _scan_output(client, payload, text: str, kind: str) -> None:
    if not text:
        _emit_cursor("pass")
        return
    sid = _session_id(payload)
    mapping = load_mapping(sid)
    result = client.scan_output(text, restore_mapping=mapping)
    if result.action == Action.BLOCK:
        _emit_cursor("block", result.message or f"blocked by FangcunGuard ({kind})")
        return
    if result.action in (Action.REPLACE, Action.RESTORE):
        _emit_cursor("replace", result.content or result.message or text)
        return
    _emit_cursor("pass")


def hook_main() -> int:
    payload = read_stdin_json()
    event = payload.get("hook") or payload.get("event") or payload.get("hookEventName") or ""
    client = build_client_from_env()
    if client is None:
        _emit_cursor("pass")
        return 0
    try:
        if event in ("beforeSubmitPrompt", "userMessage"):
            _scan_input(client, payload, _prompt_text(payload), "prompt")
        elif event == "beforeShellExecution":
            _scan_input(client, payload, _shell_command_text(payload), "shell")
        elif event == "beforeMCPExecution":
            _scan_input(client, payload, _mcp_call_text(payload), "mcp")
        elif event in ("afterShellExecution", "afterMCPExecution"):
            _scan_output(client, payload, _result_text(payload), event)
        else:
            _emit_cursor("pass")
    finally:
        client.close()
    return 0


# ============================================================
# Install / uninstall
# ============================================================


_CONFIG_DIR = Path.home() / ".cursor"
_CONFIG_FILE = _CONFIG_DIR / "hooks.json"
_HOOK_EVENTS = (
    "beforeSubmitPrompt",
    "beforeShellExecution",
    "beforeMCPExecution",
    "afterShellExecution",
    "afterMCPExecution",
)


def _hook_command_str() -> str:
    script = (Path.home() / ".fangcun" / "scripts" / "cursor.py").as_posix()
    py = sys.executable.replace("\\", "/")
    return f'"{py}" "{script}"'


def _read_json(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_json(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _is_fangcun(entry: Dict[str, Any]) -> bool:
    return bool(entry.get("_fangcun_managed"))


class CursorInstaller(AgentInstaller):
    name = "cursor"
    display_name = "Cursor"
    script_filename = "cursor.py"

    def detect(self) -> AgentDetection:
        binary = shutil.which("cursor")
        config_exists = _CONFIG_DIR.exists()
        found = bool(binary) or config_exists
        notes = []
        if not found:
            notes.append("Could not find `cursor` binary or ~/.cursor/ directory.")
        return AgentDetection(
            found=found,
            binary_path=Path(binary) if binary else None,
            config_path=_CONFIG_FILE,
            notes=notes,
        )

    def install(self, api_key: str, hook_url: str, fail_open: bool = True) -> InstallResult:
        actions: List[str] = []
        errors: List[str] = []

        try:
            script_path = self.materialize_script()
            actions.append(f"Wrote hook shim: {script_path}")
        except OSError as e:
            errors.append(f"Failed to write hook shim: {e}")
            return InstallResult(success=False, actions=actions, errors=errors)

        cfg = _read_json(_CONFIG_FILE)
        cfg["version"] = cfg.get("version", 1)
        env = cfg.setdefault("env", {})
        env["FANGCUN_API_KEY"] = api_key
        env["FANGCUN_HOOK_URL"] = hook_url
        env["FANGCUN_FAIL_OPEN"] = "true" if fail_open else "false"
        actions.append("Injected FANGCUN_* env into hooks.json")

        hooks = cfg.setdefault("hooks", {})
        cmd = _hook_command_str()
        for event in _HOOK_EVENTS:
            arr = hooks.setdefault(event, [])
            arr[:] = [h for h in arr if not (isinstance(h, dict) and _is_fangcun(h))]
            arr.append({"command": cmd, "_fangcun_managed": True})
        actions.append(f"Registered FangcunGuard on {len(_HOOK_EVENTS)} hook events")

        _write_json(_CONFIG_FILE, cfg)
        actions.append(f"Updated {_CONFIG_FILE}")
        return InstallResult(success=True, actions=actions)

    def uninstall(self) -> InstallResult:
        actions: List[str] = []
        warnings: List[str] = []

        if self.remove_materialized_script():
            actions.append(f"Removed {self.materialized_script_path}")

        if not _CONFIG_FILE.exists():
            return InstallResult(success=True, actions=actions, warnings=warnings)

        cfg = _read_json(_CONFIG_FILE)
        hooks = cfg.get("hooks", {})
        removed = 0
        for event in list(hooks.keys()):
            arr = hooks[event] or []
            new_arr = [h for h in arr if not (isinstance(h, dict) and _is_fangcun(h))]
            if len(new_arr) != len(arr):
                removed += len(arr) - len(new_arr)
            if new_arr:
                hooks[event] = new_arr
            else:
                del hooks[event]
        env = cfg.get("env", {})
        for k in ("FANGCUN_API_KEY", "FANGCUN_HOOK_URL", "FANGCUN_FAIL_OPEN"):
            env.pop(k, None)
        if env == {}:
            cfg.pop("env", None)
        if not hooks:
            cfg.pop("hooks", None)
        _write_json(_CONFIG_FILE, cfg)
        if removed:
            actions.append(f"Removed {removed} FangcunGuard hook entries from {_CONFIG_FILE}")
        else:
            warnings.append(f"No FangcunGuard hook entries found in {_CONFIG_FILE}")
        return InstallResult(success=True, actions=actions, warnings=warnings)

    def status(self) -> InstallStatus:
        det = self.detect()
        installed = False
        hook_url = None
        if _CONFIG_FILE.exists():
            cfg = _read_json(_CONFIG_FILE)
            for event in _HOOK_EVENTS:
                if any(_is_fangcun(h) for h in cfg.get("hooks", {}).get(event, []) if isinstance(h, dict)):
                    installed = True
                    break
            hook_url = cfg.get("env", {}).get("FANGCUN_HOOK_URL")
        return InstallStatus(
            agent_name=self.display_name,
            detected=det.found,
            fangcun_installed=installed,
            config_path=_CONFIG_FILE,
            script_path=self.materialized_script_path if self.materialized_script_path.exists() else None,
            hook_url=hook_url,
            notes=det.notes,
        )
