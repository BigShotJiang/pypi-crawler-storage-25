"""OpenClaw installer.

Different model from the Tier-A script-based agents: OpenClaw has a real
plugin marketplace + lifecycle, so we don't materialize a Python shim.
Instead we either delegate to `openclaw plugins install` (when our npm
package is published) or instruct the user to copy our local
`integrations/openclaw-plugin/` into their `<openclaw>/extensions/`. Either
way we then write the enable flag + apiKey into ~/.openclaw/openclaw.json.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

from .base import (
    AgentDetection,
    AgentInstaller,
    InstallResult,
    InstallStatus,
)


_CONFIG_DIR = Path.home() / ".openclaw"
_CONFIG_FILE = _CONFIG_DIR / "openclaw.json"
_PLUGIN_ID = "fangcun-openclaw-guardian"
_NPM_PACKAGE = "@fangcun/openclaw-plugin"


def _read_json(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_json(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


class OpenclawInstaller(AgentInstaller):
    name = "openclaw"
    display_name = "OpenClaw"
    script_filename = ""  # not used — OpenClaw loads via its own plugin system

    def detect(self) -> AgentDetection:
        binary = shutil.which("openclaw")
        config_exists = _CONFIG_DIR.exists()
        found = bool(binary) or config_exists
        notes = []
        if not found:
            notes.append("Could not find `openclaw` binary or ~/.openclaw/ directory.")
        return AgentDetection(
            found=found,
            binary_path=Path(binary) if binary else None,
            config_path=_CONFIG_FILE,
            notes=notes,
        )

    def _install_npm_plugin(self, warnings: List[str]) -> bool:
        """Install the openclaw-plugin into ~/.openclaw/extensions/ from
        the source bundled inside this SDK wheel. Plain copy + npm install
        + npm run build — does NOT touch the npm registry, so it works
        whether or not @fangcun/openclaw-plugin is published."""
        # Find the bundled plugin source. The directory is shipped as
        # package_data inside fangcun_hook_sdk._bundled.openclaw_plugin —
        # see pyproject.toml.
        try:
            from importlib.resources import files
            bundle = files("fangcun_hook_sdk._bundled.openclaw_plugin")
        except Exception as e:
            warnings.append(
                f"Bundled openclaw-plugin not found in this SDK install: {e}. "
                f"Reinstall the SDK or copy integrations/openclaw-plugin/ "
                f"manually to ~/.openclaw/extensions/{_PLUGIN_ID}/."
            )
            return False

        # Copy bundled source to ~/.openclaw/extensions/<plugin-id>/.
        ext_dir = _CONFIG_DIR / "extensions" / _PLUGIN_ID
        try:
            ext_dir.parent.mkdir(parents=True, exist_ok=True)
            if ext_dir.exists():
                shutil.rmtree(ext_dir)
            # `files(...)` may return a Traversable backed by a zip in some
            # install layouts; resolve to a real path via as_file when needed.
            try:
                src_path = Path(str(bundle))
                if not src_path.is_dir():
                    raise FileNotFoundError(src_path)
                shutil.copytree(src_path, ext_dir)
            except (TypeError, FileNotFoundError):
                # Zip-backed: walk + copy manually
                from importlib.resources import as_file
                with as_file(bundle) as p:
                    shutil.copytree(p, ext_dir)
        except Exception as e:
            warnings.append(f"copy bundled plugin to {ext_dir} failed: {e}")
            return False

        # Run `npm install` inside the copied directory to fetch the
        # plugin's RUNTIME deps (axios etc.). This still hits npm registry,
        # but only for normal libraries — never for our @fangcun/* package.
        if not shutil.which("npm"):
            warnings.append(
                f"plugin source copied to {ext_dir}, but `npm` is not on PATH "
                "so dependencies couldn't be installed. Install Node.js, then run:\n"
                f"  cd {ext_dir} && npm install && npm run build"
            )
            return False

        try:
            r1 = subprocess.run(
                ["npm", "install", "--no-audit", "--no-fund"],
                cwd=str(ext_dir),
                capture_output=True, text=True, timeout=300,
            )
            if r1.returncode != 0:
                warnings.append(
                    f"npm install in {ext_dir} returned {r1.returncode}: "
                    f"{(r1.stderr or r1.stdout or '').strip()[:300]}"
                )
                return False
            r2 = subprocess.run(
                ["npm", "run", "build"],
                cwd=str(ext_dir),
                capture_output=True, text=True, timeout=180,
            )
            if r2.returncode != 0:
                warnings.append(
                    f"npm run build in {ext_dir} returned {r2.returncode}: "
                    f"{(r2.stderr or r2.stdout or '').strip()[:300]}"
                )
                return False
        except Exception as e:
            warnings.append(f"npm install/build failed: {e}")
            return False
        return True

    def install(self, api_key: str, hook_url: str, fail_open: bool = True) -> InstallResult:
        actions: List[str] = []
        warnings: List[str] = []
        errors: List[str] = []

        installed_via_npm = self._install_npm_plugin(warnings)
        if installed_via_npm:
            actions.append(
                f"Copied bundled plugin source to {_CONFIG_DIR / 'extensions' / _PLUGIN_ID} "
                f"and ran npm install + npm run build"
            )

        # OpenClaw's host config schema is strict on `plugins.entries.<id>` —
        # only `enabled` and `config` are accepted at the entry level. The
        # plugin's own configSchema (hookUrl/apiKey/failOpen/timeoutMs/...)
        # validates the contents of `config`, NOT the entry itself.
        # Past mistakes the schema flagged:
        #
        #   1. `_fangcun_managed: true` marker → rejected. Identify the entry
        #      by its id (`fangcun-openclaw-guardian` is unique to us) — no
        #      marker needed.
        #   2. Writing settings at root (`cfg[_PLUGIN_ID] = {...}`) → unknown
        #      top-level key. Must live under `plugins.entries.<id>`.
        #   3. Writing settings flat inside the entry (sibling to `enabled`)
        #      → "Unrecognized keys: hookUrl, apiKey, failOpen". Must nest
        #      inside `config`.
        cfg = _read_json(_CONFIG_FILE)
        plugins = cfg.setdefault("plugins", {})
        entries = plugins.setdefault("entries", {})
        entries[_PLUGIN_ID] = {
            "enabled": True,
            "config": {
                "hookUrl": hook_url,
                "apiKey": api_key,
                "failOpen": fail_open,
            },
        }
        actions.append(
            f"Wrote plugins.entries.{_PLUGIN_ID} "
            f"(enabled + config.{{hookUrl,apiKey,failOpen}}) in {_CONFIG_FILE}"
        )

        _write_json(_CONFIG_FILE, cfg)
        actions.append(f"Updated {_CONFIG_FILE}")

        return InstallResult(
            success=not errors,
            actions=actions,
            warnings=warnings,
            errors=errors,
        )

    def uninstall(self) -> InstallResult:
        actions: List[str] = []
        warnings: List[str] = []

        if shutil.which("openclaw"):
            try:
                subprocess.run(
                    ["openclaw", "plugins", "remove", _NPM_PACKAGE],
                    capture_output=True, text=True, timeout=60,
                )
                actions.append(f"Removed npm plugin {_NPM_PACKAGE}")
            except Exception:
                pass

        if not _CONFIG_FILE.exists():
            return InstallResult(success=True, actions=actions, warnings=warnings)

        cfg = _read_json(_CONFIG_FILE)
        entries = cfg.get("plugins", {}).get("entries", {})
        if _PLUGIN_ID in entries:
            del entries[_PLUGIN_ID]
            actions.append(f"Removed plugins.entries.{_PLUGIN_ID}")
        if _PLUGIN_ID in cfg:
            del cfg[_PLUGIN_ID]
            actions.append(f"Removed {_PLUGIN_ID} settings block")
        _write_json(_CONFIG_FILE, cfg)
        return InstallResult(success=True, actions=actions, warnings=warnings)

    def status(self) -> InstallStatus:
        det = self.detect()
        installed = False
        hook_url = None
        if _CONFIG_FILE.exists():
            cfg = _read_json(_CONFIG_FILE)
            entry = cfg.get("plugins", {}).get("entries", {}).get(_PLUGIN_ID, {})
            entry_cfg = entry.get("config", {}) or {}
            # Legacy locations honored for detection only:
            #   - `cfg[_PLUGIN_ID]` was where 0.1.0 wrote settings (root key)
            #   - flat sibling-of-`enabled` was where 0.1.1/0.1.2 wrote them
            legacy_root = cfg.get(_PLUGIN_ID, {})
            installed = bool(entry.get("enabled")) or bool(legacy_root)
            hook_url = (
                entry_cfg.get("hookUrl")
                or entry.get("hookUrl")
                or legacy_root.get("hookUrl")
            )
        return InstallStatus(
            agent_name=self.display_name,
            detected=det.found,
            fangcun_installed=installed,
            config_path=_CONFIG_FILE,
            script_path=None,
            hook_url=hook_url,
            notes=det.notes,
        )
