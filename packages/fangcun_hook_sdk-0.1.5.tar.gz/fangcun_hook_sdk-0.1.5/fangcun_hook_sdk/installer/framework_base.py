"""Base class + dataclasses + shared AST/text helpers for project-mode
framework patchers.

Sibling to `installer/base.py::AgentInstaller`. The split exists because
agent installers and framework patchers do fundamentally different work:

- AgentInstaller writes ~/.<agent>/config — global, no project context.
- FrameworkPatcher reads + edits the user's project source code, e.g.
  inserts `callbacks=[_fc]` into a `ChatOpenAI(...)` call.

Both end up wired together by `installer/project.py::ProjectInstaller`,
which is what `fangcun install --project ./my-app` actually invokes.

The bottom half of this file (after the `# Shared AST + text helpers`
banner) is the toolbox each framework patcher pulls from: ast walk,
column-offset slicing, kw insertion, top-of-file block injection,
import-block detection. Keep them framework-agnostic; per-framework
content (ctor names, kw shape, _fc init text) lives in each framework's
own module under `frameworks/`.
"""
from __future__ import annotations

import ast
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Sequence


# ============================================================
# Dataclasses returned by FrameworkPatcher methods
# ============================================================


@dataclass
class CallSite:
    """One LLM construction site found in the user's source."""
    file: Path
    line: int                   # 1-based
    col: int                    # 0-based, points at the constructor's start
    end_line: int
    end_col: int                # right after the closing `)`
    ctor_name: str              # e.g. "ChatOpenAI"
    source_snippet: str         # the matched call's text, multi-line OK


@dataclass
class FrameworkDetection:
    """Was this framework detected in the project?"""
    found: bool
    framework_name: str
    requirements_evidence: List[str] = field(default_factory=list)   # e.g. ["requirements.txt:langchain==0.2.0"]
    import_evidence: List[str] = field(default_factory=list)         # e.g. ["main.py:from langchain_openai import ChatOpenAI"]
    notes: List[str] = field(default_factory=list)


@dataclass
class PatchPlan:
    """A single file's before / after. Generated even in dry-run mode."""
    file: Path
    original: str
    patched: str
    call_sites_modified: int
    skipped_reason: Optional[str] = None    # set if no change was emitted

    @property
    def is_noop(self) -> bool:
        return self.original == self.patched


@dataclass
class FrameworkResult:
    """Output of running one FrameworkPatcher against a project."""
    framework_name: str
    detection: FrameworkDetection
    patches: List[PatchPlan] = field(default_factory=list)
    manual_instructions: Optional[str] = None    # filled when AST patching fails
    errors: List[str] = field(default_factory=list)

    @property
    def has_changes(self) -> bool:
        return any(not p.is_noop for p in self.patches)


# ============================================================
# FrameworkPatcher abstract base
# ============================================================


class FrameworkPatcher(ABC):
    """One per supported Python AI framework (LangChain, LlamaIndex, etc.).

    Subclasses MUST set:
        name             — short ID, e.g. "langchain"
        display_name     — human-readable, e.g. "LangChain"
        package_names    — strings to look for in requirements.txt / pyproject.toml
        import_prefixes  — strings to look for at the start of `from X import Y` lines

    And implement:
        find_call_sites(project_root, files_to_scan) -> List[CallSite]
        build_patch(file, source, call_sites, api_key, hook_url) -> PatchPlan

    detect() has a default impl that uses package_names + import_prefixes.
    """

    name: str = ""
    display_name: str = ""
    package_names: List[str] = []
    import_prefixes: List[str] = []

    # ---- detection (default impl; override only if framework needs custom logic) ----

    def detect(self, project_root: Path) -> FrameworkDetection:
        req_evidence = _scan_requirements(project_root, self.package_names)
        import_evidence = _scan_imports(project_root, self.import_prefixes, max_files=200)
        return FrameworkDetection(
            found=bool(req_evidence) or bool(import_evidence),
            framework_name=self.name,
            requirements_evidence=req_evidence,
            import_evidence=import_evidence,
        )

    # ---- patching (subclass must implement) ----

    @abstractmethod
    def find_call_sites(self, project_root: Path) -> List[CallSite]:
        """Walk *.py files, return every LLM construction call we can patch."""

    @abstractmethod
    def build_patch(
        self,
        file: Path,
        source: str,
        call_sites: List[CallSite],
        api_key: str,
        hook_url: str,
    ) -> PatchPlan:
        """Given the source of one file + every call site found in it,
        return the patched source. If we can't safely patch, return a
        no-op PatchPlan with `skipped_reason` set."""


# ============================================================
# Shared scan helpers used by the default detect() impl
# ============================================================


_REQ_FILES = ("requirements.txt", "requirements-dev.txt", "pyproject.toml", "setup.py", "Pipfile")
_SKIP_DIRS = {".git", ".venv", "venv", "env", "node_modules", "__pycache__", ".tox", "build", "dist", ".mypy_cache", ".pytest_cache"}


def _scan_requirements(project_root: Path, package_names: List[str]) -> List[str]:
    out: List[str] = []
    for fname in _REQ_FILES:
        p = project_root / fname
        if not p.is_file():
            continue
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        lower = text.lower()
        for pkg in package_names:
            if pkg.lower() in lower:
                out.append(f"{fname}: {pkg}")
                break    # one hit per file is enough
    return out


def _scan_imports(project_root: Path, import_prefixes: List[str], *, max_files: int = 200) -> List[str]:
    if not import_prefixes:
        return []
    out: List[str] = []
    seen = 0
    for path in _walk_python_files(project_root):
        if seen >= max_files:
            break
        seen += 1
        try:
            with path.open("r", encoding="utf-8", errors="ignore") as f:
                for i, line in enumerate(f, start=1):
                    stripped = line.lstrip()
                    if not (stripped.startswith("from ") or stripped.startswith("import ")):
                        continue
                    for pref in import_prefixes:
                        if pref in stripped:
                            rel = path.relative_to(project_root) if path.is_relative_to(project_root) else path
                            out.append(f"{rel}:{i}: {stripped.rstrip()}")
                            break
                    if len(out) >= 20:
                        return out
        except OSError:
            continue
    return out


def _walk_python_files(project_root: Path):
    """Yield .py files under project_root, skipping vendored / generated dirs."""
    for path in project_root.rglob("*.py"):
        # Skip if any parent is in _SKIP_DIRS
        try:
            parts = path.relative_to(project_root).parts
        except ValueError:
            parts = path.parts
        if any(p in _SKIP_DIRS for p in parts):
            continue
        yield path


# ============================================================
# Shared AST + text helpers (used by every framework patcher)
# ============================================================


def ctor_name(func: ast.expr) -> Optional[str]:
    """Return the constructor name for `Foo(...)` or `bar.Foo(...)`."""
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        return func.attr
    return None


def slice_source(lines: List[str], start_line: int, start_col: int, end_line: Optional[int], end_col: Optional[int]) -> str:
    """Return the substring of `lines` between (start_line, start_col) and (end_line, end_col).
    Lines are 1-based, cols 0-based — matching the convention of `ast` node positions."""
    if end_line is None:
        return lines[start_line - 1][start_col:]
    if start_line == end_line:
        return lines[start_line - 1][start_col:end_col]
    parts = [lines[start_line - 1][start_col:]]
    for i in range(start_line, end_line - 1):
        parts.append(lines[i])
    parts.append(lines[end_line - 1][:end_col])
    return "\n".join(parts)


def find_call_sites_for_ctors(
    project_root: Path,
    ctor_names: Sequence[str],
    import_filter_substrings: Optional[Sequence[str]] = None,
) -> List["CallSite"]:
    """Walk *.py under project_root, return every Call node whose function
    name matches one in `ctor_names`. Used by all framework patchers.

    `import_filter_substrings`: if given, only consider files whose source
    text contains at least one of these substrings (cheap pre-check before
    ast.parse). Avoids cross-framework ctor-name collisions — e.g. both
    LangChain and LlamaIndex have a class named `OpenAI`, but only the file
    importing the right prefix should be patched.

    Skips files that fail to ast.parse (syntax error in user code shouldn't
    abort the whole project run).
    """
    out: List[CallSite] = []
    targets = set(ctor_names)
    for path in _walk_python_files(project_root):
        try:
            source = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        if import_filter_substrings and not any(s in source for s in import_filter_substrings):
            continue
        try:
            tree = ast.parse(source, filename=str(path))
        except SyntaxError:
            continue
        lines = source.splitlines(keepends=False)
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            cn = ctor_name(node.func)
            if cn not in targets:
                continue
            snippet = slice_source(lines, node.lineno, node.col_offset, node.end_lineno, node.end_col_offset)
            out.append(CallSite(
                file=path,
                line=node.lineno,
                col=node.col_offset,
                end_line=node.end_lineno or node.lineno,
                end_col=node.end_col_offset or 0,
                ctor_name=cn,  # type: ignore[arg-type]
                source_snippet=snippet,
            ))
    return out


def has_kw_in_snippet(snippet: str, kw_name: str) -> bool:
    """True if `kw_name=` appears in the call-site source. Used to detect
    when a constructor already has e.g. `callbacks=...` so we can fall
    back to manual instructions instead of silently merging."""
    return bool(re.search(rf"\b{re.escape(kw_name)}\s*=", snippet))


def insert_kw_args_before_paren(source: str, site: "CallSite", kw_text: str) -> str:
    """Insert `kw_text` right before the closing `)` of `site`. Branches on
    whether the call already has args (insert with leading `, `) or is
    empty (just `kw_text`).

    `kw_text` is a kw-argument fragment like `callbacks=[_fc]` or
    `callback_manager=cm, step_callback=cb` — caller is responsible for
    formatting commas BETWEEN multiple kws inside that string.

    `site.end_col` from ast is the position right AFTER `)`, so we insert
    at `end_col - 1` on `end_line`. Returns `source` unchanged if the
    site can't be safely modified."""
    lines = source.split("\n")
    if site.end_line < 1 or site.end_line > len(lines):
        return source
    target_line = lines[site.end_line - 1]
    insert_at = site.end_col - 1
    if insert_at < 0 or insert_at > len(target_line):
        return source
    if target_line[insert_at:insert_at + 1] != ")":
        return source
    snippet_no_ws = re.sub(r"\s", "", site.source_snippet)
    is_empty_args = snippet_no_ws.endswith("()")
    fragment = kw_text if is_empty_args else f", {kw_text}"
    new_line = target_line[:insert_at] + fragment + target_line[insert_at:]
    lines[site.end_line - 1] = new_line
    return "\n".join(lines)


_FUTURE_IMPORT_RE = re.compile(r"^\s*from\s+__future__\s+import\b")
_DOCSTRING_END_RE = re.compile(r'^\s*("""|\'\'\')')
_REGULAR_IMPORT_RE = re.compile(r"^\s*(import\s+\S|from\s+\S)")


def inject_block_after_imports(source: str, block_lines: Sequence[str]) -> str:
    """Insert `block_lines` (joined with `\\n`) at the right top-of-file spot:
    AFTER any module docstring + `from __future__` imports + contiguous
    existing import block. Don't trip Python's "futures must come first"
    rule and don't break apart import groups."""
    block = "\n".join(block_lines)
    lines = source.split("\n")
    insert_at = _find_top_insertion_point(lines)
    return "\n".join(lines[:insert_at] + [block] + lines[insert_at:])


def _find_top_insertion_point(lines: List[str]) -> int:
    """Return the line index AFTER which an injected block should land.

    Order to skip past:
      1. shebang
      2. encoding cookie / coding line
      3. module docstring
      4. all `from __future__` imports
      5. contiguous run of regular imports (don't break them apart)
    """
    i = 0
    n = len(lines)

    if i < n and lines[i].startswith("#!"):
        i += 1
    if i < n and re.match(r"^\s*#.*coding[:=]\s*[-\w.]+", lines[i]):
        i += 1
    if i < n:
        m = _DOCSTRING_END_RE.match(lines[i])
        if m:
            quote = m.group(1)
            stripped = lines[i].strip()
            if stripped.count(quote) >= 2 and len(stripped) > len(quote) * 2:
                i += 1
            else:
                i += 1
                while i < n and quote not in lines[i]:
                    i += 1
                if i < n:
                    i += 1
    while i < n and (not lines[i].strip() or _FUTURE_IMPORT_RE.match(lines[i])):
        i += 1
    last_import = i - 1
    while i < n:
        if _REGULAR_IMPORT_RE.match(lines[i]):
            last_import = i
            i += 1
            continue
        if not lines[i].strip() or lines[i].lstrip().startswith("#"):
            i += 1
            continue
        break
    return last_import + 1
