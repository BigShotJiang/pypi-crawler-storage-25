"""Codex CLI installer + hook runtime.

Codex CLI's config is TOML at ~/.codex/config.toml. To avoid adding a TOML
dep, we edit by inserting a sentinel-bracketed block; uninstall removes
exactly that block.
"""
from __future__ import annotations

import os
import re
import shutil
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..types import Action
from .base import (
    AgentDetection,
    AgentInstaller,
    InstallResult,
    InstallStatus,
    build_client_from_env,
    emit_block,
    emit_pass,
    emit_replace,
    load_mapping,
    read_stdin_json,
    save_mapping,
)


# ============================================================
# Runtime
# ============================================================


def _prompt_messages(payload: Dict[str, Any]) -> List[Dict[str, Any]]:
    text = payload.get("prompt") or payload.get("user_message") or payload.get("message") or ""
    if not text:
        return []
    return [{"role": "user", "content": str(text)}]


def _tool_input_messages(payload: Dict[str, Any]) -> List[Dict[str, Any]]:
    tool_input = payload.get("tool_input") or payload.get("arguments") or {}
    tool_name = payload.get("tool_name") or payload.get("name") or ""
    if not tool_input:
        return []
    text = tool_input if isinstance(tool_input, str) else str(tool_input)
    return [{"role": "user", "content": f"[tool:{tool_name}] {text}"}]


def _tool_result_text(payload: Dict[str, Any]) -> str:
    tr = payload.get("tool_result") or payload.get("result") or payload.get("output") or ""
    if isinstance(tr, str):
        return tr
    if isinstance(tr, dict):
        for k in ("output", "content", "stdout", "text"):
            v = tr.get(k)
            if isinstance(v, str) and v:
                return v
    return ""


def _assistant_text(payload: Dict[str, Any]) -> str:
    msg = payload.get("response") or payload.get("assistant_message") or payload.get("text") or ""
    if isinstance(msg, str):
        return msg
    if isinstance(msg, dict):
        return str(msg.get("content", ""))
    return ""


def _session_id(payload: Dict[str, Any]) -> Optional[str]:
    return payload.get("session_id") or payload.get("conversation_id")


def _scan_input(client, payload, extractor) -> None:
    msgs = extractor(payload)
    if not msgs:
        emit_pass()
        return
    result = client.scan_input(msgs, stream=False)
    if result.action == Action.BLOCK:
        emit_block(result.message or "blocked by FangcunGuard")
        return
    if result.action == Action.REPLACE:
        emit_replace(result.message or "[replaced]")
        return
    if result.action == Action.ANONYMIZE and result.restore_mapping:
        sid = _session_id(payload) or result.session_id or "default"
        save_mapping(sid, result.restore_mapping)
    emit_pass()


def _scan_output(client, payload, extractor) -> None:
    text = extractor(payload)
    if not text:
        emit_pass()
        return
    sid = _session_id(payload)
    mapping = load_mapping(sid)
    result = client.scan_output(text, restore_mapping=mapping)
    if result.action == Action.BLOCK:
        emit_block(result.message or "blocked by FangcunGuard")
        return
    if result.action in (Action.REPLACE, Action.RESTORE):
        emit_replace(result.content or result.message or text)
        return
    emit_pass()


def hook_main() -> int:
    payload = read_stdin_json()
    event = payload.get("event") or payload.get("hook_event_name") or payload.get("hookEventName") or ""
    client = build_client_from_env()
    if client is None:
        emit_pass()
        return 0
    try:
        if event in ("UserPromptSubmit", "user_prompt_submit"):
            _scan_input(client, payload, _prompt_messages)
        elif event in ("PreToolUse", "pre_tool_use"):
            _scan_input(client, payload, _tool_input_messages)
        elif event in ("PostToolUse", "post_tool_use"):
            _scan_output(client, payload, _tool_result_text)
        elif event in ("Stop", "stop"):
            _scan_output(client, payload, _assistant_text)
        else:
            emit_pass()
    finally:
        client.close()
    return 0


# ============================================================
# Install / uninstall
# ============================================================


_CONFIG_DIR = Path.home() / ".codex"
_CONFIG_FILE = _CONFIG_DIR / "config.toml"
_HOOK_EVENTS = ("UserPromptSubmit", "PreToolUse", "PostToolUse", "Stop")
_BEGIN_TAG = "# === BEGIN FANGCUN_GUARD_HOOK ==="
_END_TAG = "# === END FANGCUN_GUARD_HOOK ==="


def _hook_command() -> str:
    script = (Path.home() / ".fangcun" / "scripts" / "codex_cli.py").as_posix()
    py = sys.executable.replace("\\", "/")
    return f'"{py}" "{script}"'


def _build_block(api_key: str, hook_url: str, fail_open: bool) -> str:
    cmd = _hook_command()
    lines = [_BEGIN_TAG]
    lines.append(f'# Managed by `fangcun install --agent codex-cli`. Do not edit manually.')
    lines.append("[hooks.env]")
    lines.append(f'FANGCUN_API_KEY = "{api_key}"')
    lines.append(f'FANGCUN_HOOK_URL = "{hook_url}"')
    lines.append(f'FANGCUN_FAIL_OPEN = "{ "true" if fail_open else "false" }"')
    lines.append("")
    for event in _HOOK_EVENTS:
        lines.append(f"[[hooks.{event}]]")
        lines.append(f"command = {cmd!r}")
        lines.append("")
    lines.append(_END_TAG)
    return "\n".join(lines) + "\n"


_BLOCK_RE = re.compile(
    re.escape(_BEGIN_TAG) + r".*?" + re.escape(_END_TAG) + r"\n?",
    re.DOTALL,
)


def _strip_existing(content: str) -> str:
    return _BLOCK_RE.sub("", content)


class CodexCliInstaller(AgentInstaller):
    name = "codex-cli"
    display_name = "OpenAI Codex CLI"
    script_filename = "codex_cli.py"

    def detect(self) -> AgentDetection:
        binary = shutil.which("codex")
        config_exists = _CONFIG_DIR.exists()
        found = bool(binary) or config_exists
        notes = []
        if not found:
            notes.append("Could not find `codex` binary or ~/.codex/ directory.")
        return AgentDetection(
            found=found,
            binary_path=Path(binary) if binary else None,
            config_path=_CONFIG_FILE,
            notes=notes,
        )

    def install(self, api_key: str, hook_url: str, fail_open: bool = True) -> InstallResult:
        actions: List[str] = []
        warnings: List[str] = []
        errors: List[str] = []

        try:
            script_path = self.materialize_script()
            actions.append(f"Wrote hook shim: {script_path}")
        except OSError as e:
            errors.append(f"Failed to write hook shim: {e}")
            return InstallResult(success=False, actions=actions, warnings=warnings, errors=errors)

        _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        existing = _CONFIG_FILE.read_text(encoding="utf-8") if _CONFIG_FILE.exists() else ""
        cleaned = _strip_existing(existing).rstrip() + ("\n\n" if existing.strip() else "")
        new_block = _build_block(api_key, hook_url, fail_open)
        _CONFIG_FILE.write_text(cleaned + new_block, encoding="utf-8")
        actions.append(f"Wrote managed block to {_CONFIG_FILE} ({len(_HOOK_EVENTS)} hook events)")

        return InstallResult(success=True, actions=actions, warnings=warnings, errors=errors)

    def uninstall(self) -> InstallResult:
        actions: List[str] = []
        warnings: List[str] = []

        if self.remove_materialized_script():
            actions.append(f"Removed {self.materialized_script_path}")

        if not _CONFIG_FILE.exists():
            return InstallResult(success=True, actions=actions, warnings=warnings)

        existing = _CONFIG_FILE.read_text(encoding="utf-8")
        new = _strip_existing(existing)
        if new == existing:
            warnings.append(f"No FangcunGuard block found in {_CONFIG_FILE}")
        else:
            _CONFIG_FILE.write_text(new, encoding="utf-8")
            actions.append(f"Removed FangcunGuard block from {_CONFIG_FILE}")

        return InstallResult(success=True, actions=actions, warnings=warnings)

    def status(self) -> InstallStatus:
        det = self.detect()
        installed = False
        hook_url = None
        if _CONFIG_FILE.exists():
            content = _CONFIG_FILE.read_text(encoding="utf-8")
            installed = _BEGIN_TAG in content and _END_TAG in content
            m = re.search(r'FANGCUN_HOOK_URL\s*=\s*"([^"]+)"', content)
            if m:
                hook_url = m.group(1)
        return InstallStatus(
            agent_name=self.display_name,
            detected=det.found,
            fangcun_installed=installed,
            config_path=_CONFIG_FILE,
            script_path=self.materialized_script_path if self.materialized_script_path.exists() else None,
            hook_url=hook_url,
            notes=det.notes,
        )
