"""CrewAI framework patcher.

Same shape as LangChain (find ctor → add kw) but the kw set is two
(`step_callback=`, `task_callback=`) and the values are factory-fn
calls rather than a pre-built handler — see [adapters/crewai_callback.py]
for the runtime side.
"""
from __future__ import annotations

from pathlib import Path
from typing import List

from ..framework_base import (
    CallSite,
    FrameworkPatcher,
    PatchPlan,
    find_call_sites_for_ctors,
    has_kw_in_snippet,
    inject_block_after_imports,
    insert_kw_args_before_paren,
)


# CrewAI's main composition objects. `Crew` is the orchestrator (gets
# step + task callbacks); `Agent` accepts step_callback only but for MVP
# we patch Crew only — that's the canonical injection point per the
# adapter's documented usage.
_CTOR_NAMES = ("Crew",)

_KW_TEXT = (
    "step_callback=make_step_callback(_fc_hook), "
    "task_callback=make_task_callback(_fc_hook)"
)
# Idempotency: the import line is the most reliable presence marker since
# we don't construct a `_fc` object (we use the factory funcs inline).
_MARKER = "from fangcun_hook_sdk.adapters.crewai_callback import"


class CrewAIPatcher(FrameworkPatcher):
    name = "crewai"
    display_name = "CrewAI"
    package_names = ["crewai", "crewai-tools"]
    import_prefixes = ["crewai"]

    def find_call_sites(self, project_root: Path) -> List[CallSite]:
        return find_call_sites_for_ctors(
            project_root, _CTOR_NAMES,
            import_filter_substrings=("crewai",),
        )

    def build_patch(
        self,
        file: Path,
        source: str,
        call_sites: List[CallSite],
        api_key: str,
        hook_url: str,
    ) -> PatchPlan:
        if _MARKER in source:
            return PatchPlan(
                file=file, original=source, patched=source,
                call_sites_modified=0,
                skipped_reason="file already patched (crewai_callback import present)",
            )

        # Bail on call sites that already pass either kw — don't try to
        # merge into existing values for MVP.
        unsafe = [
            c for c in call_sites
            if has_kw_in_snippet(c.source_snippet, "step_callback")
            or has_kw_in_snippet(c.source_snippet, "task_callback")
        ]
        if unsafe:
            return PatchPlan(
                file=file, original=source, patched=source,
                call_sites_modified=0,
                skipped_reason=(
                    f"{len(unsafe)} Crew(...) call site(s) already pass step_callback "
                    "or task_callback; merge manually using `make_step_callback(_fc_hook)`."
                ),
            )

        sorted_sites = sorted(
            call_sites,
            key=lambda c: (c.end_line, c.end_col),
            reverse=True,
        )
        patched = source
        modified = 0
        for site in sorted_sites:
            new = insert_kw_args_before_paren(patched, site, _KW_TEXT)
            if new is patched:
                continue
            patched = new
            modified += 1

        if modified == 0:
            return PatchPlan(
                file=file, original=source, patched=source,
                call_sites_modified=0,
                skipped_reason="no Crew(...) call sites could be patched",
            )

        block_lines = [
            "",
            "# FANGCUN_GUARD_HOOK — added by `fangcun install --project`. "
            "Edit the api_key / base_url below if your env doesn't carry them.",
            "from fangcun_hook_sdk import HookClient",
            "from fangcun_hook_sdk.adapters.crewai_callback import "
            "make_step_callback, make_task_callback",
            f"_fc_hook = HookClient(api_key={api_key!r}, base_url={hook_url!r})",
            "",
        ]
        patched = inject_block_after_imports(patched, block_lines)

        return PatchPlan(
            file=file, original=source, patched=patched,
            call_sites_modified=modified,
        )
