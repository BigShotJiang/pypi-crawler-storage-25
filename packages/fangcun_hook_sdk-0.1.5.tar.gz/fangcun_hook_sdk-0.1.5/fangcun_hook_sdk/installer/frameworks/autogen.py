"""AutoGen framework patcher (0.2.x API only).

The wire-up shape is different from the others — instead of adding a kw
to the constructor, we insert an `attach_to_agent(<var>, _fc_hook)` call
on the line right after each `agent = ConversableAgent(...)` assignment.
That requires finding the *variable name* the agent is bound to, which
means walking ast.Assign nodes (not bare ast.Call nodes).

Out-of-scope for MVP:
- AutoGen 0.4+ / Microsoft Agent Framework — uses runtime intervention
  handlers, completely different paradigm; user will see manual hint.
- Compound assignments like `agents = [ConversableAgent(...), ...]` —
  too many edge cases for AST text-rewriting; user gets manual hint.
- Tuple-unpacking like `a, b = ConversableAgent(...), ConversableAgent(...)` — same.
"""
from __future__ import annotations

import ast
from pathlib import Path
from typing import List, Tuple

from ..framework_base import (
    CallSite,
    FrameworkPatcher,
    PatchPlan,
    _walk_python_files,
    ctor_name,
    inject_block_after_imports,
    slice_source,
)


# Constructors AutoGen 0.2.x users instantiate. Each represents an
# agent that needs a hook attached.
_AGENT_CTORS = (
    "ConversableAgent",
    "AssistantAgent",
    "UserProxyAgent",
    "GroupChatManager",
)

_MARKER = "from fangcun_hook_sdk.adapters.autogen_hooks import"


class AutoGenPatcher(FrameworkPatcher):
    name = "autogen"
    display_name = "AutoGen"
    package_names = ["autogen", "pyautogen", "autogen-agentchat", "autogen_agentchat"]
    import_prefixes = ["autogen"]

    # Override default detect to filter out v0.4+ — when only `autogen_core`
    # / `autogen_agentchat` is imported we can't safely patch the 0.2-style
    # `attach_to_agent` call. The default detect would still flag the
    # framework as "found" but build_patch will then return a no-op with
    # manual instructions, which is the right UX.

    def find_call_sites(self, project_root: Path) -> List[CallSite]:
        """For AutoGen we collect Assign nodes (target=Name, value=Call)
        whose Call's ctor_name is in _AGENT_CTORS — that's the only shape
        we can patch automatically."""
        out: List[CallSite] = []
        targets = set(_AGENT_CTORS)
        for path in _walk_python_files(project_root):
            try:
                source = path.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            # Filter to files that actually mention autogen — same defensive
            # pattern the other patchers use to avoid cross-framework hits.
            if "autogen" not in source:
                continue
            try:
                tree = ast.parse(source, filename=str(path))
            except SyntaxError:
                continue
            lines = source.splitlines(keepends=False)
            for node in ast.walk(tree):
                if not isinstance(node, ast.Assign):
                    continue
                if not isinstance(node.value, ast.Call):
                    continue
                cn = ctor_name(node.value.func)
                if cn not in targets:
                    continue
                # Only handle the simple `var = Ctor(...)` shape.
                if len(node.targets) != 1 or not isinstance(node.targets[0], ast.Name):
                    continue
                var_name = node.targets[0].id
                # Encode the variable name into source_snippet so build_patch
                # can recover it without re-walking the AST.
                snippet = (
                    f"{var_name} = "
                    + slice_source(lines, node.value.lineno, node.value.col_offset,
                                   node.value.end_lineno, node.value.end_col_offset)
                )
                out.append(CallSite(
                    file=path,
                    line=node.lineno,
                    col=node.col_offset,
                    end_line=node.end_lineno or node.lineno,
                    end_col=node.end_col_offset or 0,
                    ctor_name=cn,  # type: ignore[arg-type]
                    source_snippet=snippet,
                ))
        return out

    def build_patch(
        self,
        file: Path,
        source: str,
        call_sites: List[CallSite],
        api_key: str,
        hook_url: str,
    ) -> PatchPlan:
        if _MARKER in source:
            return PatchPlan(
                file=file, original=source, patched=source,
                call_sites_modified=0,
                skipped_reason="file already patched (autogen_hooks import present)",
            )

        # Insert `attach_to_agent(<var>, _fc_hook)` after each Assign's
        # end_line. Process bottom-up so earlier line numbers stay valid.
        sites_with_var: List[Tuple[CallSite, str]] = []
        for site in call_sites:
            # Recover var name from snippet prefix `var = ...`.
            head = site.source_snippet.split("=", 1)[0].strip()
            if head and head.isidentifier():
                sites_with_var.append((site, head))
        if not sites_with_var:
            return PatchPlan(
                file=file, original=source, patched=source,
                call_sites_modified=0,
                skipped_reason="no `var = AgentCtor(...)` shapes found",
            )

        sites_with_var.sort(key=lambda pair: pair[0].end_line, reverse=True)

        lines = source.split("\n")
        modified = 0
        for site, var in sites_with_var:
            # Find indentation of the assignment line so the inserted call
            # matches the same block scope (function body, top-level, etc.)
            assign_line = lines[site.line - 1] if 1 <= site.line <= len(lines) else ""
            indent = assign_line[:len(assign_line) - len(assign_line.lstrip())]
            new_call = f"{indent}attach_to_agent({var}, _fc_hook)"
            insert_idx = site.end_line  # 0-based index for the line AFTER end_line
            if 0 <= insert_idx <= len(lines):
                lines.insert(insert_idx, new_call)
                modified += 1

        if modified == 0:
            return PatchPlan(
                file=file, original=source, patched=source,
                call_sites_modified=0,
                skipped_reason="no agent assignments could be patched",
            )

        patched = "\n".join(lines)

        block_lines = [
            "",
            "# FANGCUN_GUARD_HOOK — added by `fangcun install --project`. "
            "Edit the api_key / base_url below if your env doesn't carry them.",
            "from fangcun_hook_sdk import HookClient",
            "from fangcun_hook_sdk.adapters.autogen_hooks import attach_to_agent",
            f"_fc_hook = HookClient(api_key={api_key!r}, base_url={hook_url!r})",
            "",
        ]
        patched = inject_block_after_imports(patched, block_lines)

        return PatchPlan(
            file=file, original=source, patched=patched,
            call_sites_modified=modified,
        )
