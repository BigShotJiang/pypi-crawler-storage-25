"""LangChain framework patcher — first MVP target for `fangcun install
--project`.

Detects LangChain in user's project, finds LLM construction sites
(ChatOpenAI / ChatAnthropic / etc.), and emits a PatchPlan that adds:

  1. Two imports at the top of each file that holds a call site
  2. A module-level `_fc_hook` + `_fc` definition near those imports
  3. A `callbacks=[_fc]` keyword arg to each LLM constructor

All AST + text manipulation lives in `framework_base.py`; this file
just declares LangChain-specific names + templates.
"""
from __future__ import annotations

from pathlib import Path
from typing import List

from ..framework_base import (
    CallSite,
    FrameworkPatcher,
    PatchPlan,
    find_call_sites_for_ctors,
    has_kw_in_snippet,
    inject_block_after_imports,
    insert_kw_args_before_paren,
)


# Constructor names we recognize as "LLM construction sites" worth patching.
# Cover both old (`langchain.chat_models`) and new (`langchain_openai` etc.)
# import paths — we don't care which path the user used, only the ctor name.
_LLM_CTOR_NAMES = (
    "ChatOpenAI",
    "ChatAnthropic",
    "ChatGoogleGenerativeAI",
    "ChatBedrock",
    "ChatBedrockConverse",
    "ChatVertexAI",
    "ChatCohere",
    "ChatMistralAI",
    "ChatGroq",
    "ChatTogether",
    "ChatFireworks",
    "ChatOllama",
    "AzureChatOpenAI",
    "OpenAI",
    "Anthropic",
    "Cohere",
)

_KW_NAME = "callbacks"
_KW_TEXT = "callbacks=[_fc]"
_MARKER = "_fc = FangcunCallbackHandler"


class LangChainPatcher(FrameworkPatcher):
    name = "langchain"
    display_name = "LangChain"
    package_names = [
        "langchain",
        "langchain-openai",
        "langchain-anthropic",
        "langchain-community",
        "langchain-core",
        "langchain_openai",
        "langchain_anthropic",
    ]
    import_prefixes = [
        "langchain",
        "langchain_openai",
        "langchain_anthropic",
        "langchain_community",
        "langchain_core",
        "langchain_google",
        "langchain_aws",
    ]

    def find_call_sites(self, project_root: Path) -> List[CallSite]:
        # Filter on `langchain` substring so a generic ctor name like
        # `OpenAI` in a LlamaIndex file doesn't get accidentally patched.
        return find_call_sites_for_ctors(
            project_root, _LLM_CTOR_NAMES,
            import_filter_substrings=("langchain",),
        )

    def build_patch(
        self,
        file: Path,
        source: str,
        call_sites: List[CallSite],
        api_key: str,
        hook_url: str,
    ) -> PatchPlan:
        # Idempotency: if we've already patched this file, leave it alone.
        if _MARKER in source:
            return PatchPlan(
                file=file, original=source, patched=source,
                call_sites_modified=0,
                skipped_reason="file already patched (FangcunCallbackHandler present)",
            )

        # Bail out cleanly if any call site already passes a `callbacks=`
        # keyword — for MVP we don't try to merge into existing lists.
        unsafe = [c for c in call_sites if has_kw_in_snippet(c.source_snippet, _KW_NAME)]
        if unsafe:
            return PatchPlan(
                file=file, original=source, patched=source,
                call_sites_modified=0,
                skipped_reason=(
                    f"{len(unsafe)} call site(s) already pass a `{_KW_NAME}=` kw; "
                    "merge manually by appending `_fc` to that list."
                ),
            )

        # Modify call sites end-to-start so earlier offsets stay valid.
        sorted_sites = sorted(
            call_sites,
            key=lambda c: (c.end_line, c.end_col),
            reverse=True,
        )
        patched = source
        modified = 0
        for site in sorted_sites:
            new = insert_kw_args_before_paren(patched, site, _KW_TEXT)
            if new is patched:
                continue
            patched = new
            modified += 1

        if modified == 0:
            return PatchPlan(
                file=file, original=source, patched=source,
                call_sites_modified=0,
                skipped_reason="no call sites could be patched",
            )

        # Inject imports + _fc init at the top.
        block_lines = [
            "",
            "# FANGCUN_GUARD_HOOK — added by `fangcun install --project`. "
            "Edit the api_key / base_url below if your env doesn't carry them.",
            "from fangcun_hook_sdk import HookClient",
            "from fangcun_hook_sdk.adapters.langchain_callback import FangcunCallbackHandler",
            f"_fc_hook = HookClient(api_key={api_key!r}, base_url={hook_url!r})",
            "_fc = FangcunCallbackHandler(hook=_fc_hook)",
            "",
        ]
        patched = inject_block_after_imports(patched, block_lines)

        return PatchPlan(
            file=file, original=source, patched=patched,
            call_sites_modified=modified,
        )
