"""Framework patcher registry.

Per the rollout plan in PROJECT memory `project_b_framework_patchers`:
LangChain shipped first as the MVP, then LlamaIndex / AutoGen / CrewAI
follow using the same template — see each module for the framework-
specific overrides.
"""
from __future__ import annotations

from typing import Dict, Type

from ..framework_base import FrameworkPatcher
from .autogen import AutoGenPatcher
from .crewai import CrewAIPatcher
from .langchain import LangChainPatcher
from .llamaindex import LlamaIndexPatcher


REGISTRY: Dict[str, Type[FrameworkPatcher]] = {
    LangChainPatcher.name: LangChainPatcher,
    LlamaIndexPatcher.name: LlamaIndexPatcher,
    AutoGenPatcher.name: AutoGenPatcher,
    CrewAIPatcher.name: CrewAIPatcher,
}


__all__ = [
    "REGISTRY",
    "LangChainPatcher",
    "LlamaIndexPatcher",
    "AutoGenPatcher",
    "CrewAIPatcher",
]
