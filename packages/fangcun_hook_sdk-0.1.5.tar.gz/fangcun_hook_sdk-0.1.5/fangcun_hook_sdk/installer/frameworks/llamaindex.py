"""LlamaIndex framework patcher.

LlamaIndex's recommended integration is a one-shot global registration:

    Settings.callback_manager = CallbackManager([FangcunLlamaIndexHandler(hook)])

That binds the handler to every LLM the app constructs after that line
runs, so we don't need to find and rewrite every `OpenAI(...)` /
`Anthropic(...)` site individually — and that's a good thing, because
LlamaIndex shares those ctor names with LangChain (both have an `OpenAI`
class), and ctor-level patching can't tell them apart from AST alone.

Strategy: for every project file that imports `llama_index`, prepend
the global setup block at the top. Multiple assignments to
`Settings.callback_manager` are idempotent — last one wins, and they're
all the same — so injecting in every file is fine.
"""
from __future__ import annotations

from pathlib import Path
from typing import List

from ..framework_base import (
    CallSite,
    FrameworkPatcher,
    PatchPlan,
    _walk_python_files,
    inject_block_after_imports,
)


# Idempotency marker — a string that ONLY appears in files we patched.
_MARKER = "Settings.callback_manager = CallbackManager([FangcunLlamaIndexHandler"

# Substring used to flag a file as "user wires LlamaIndex here". Cheap
# in-source check before parsing — avoids spinning up ast.parse for files
# that obviously don't touch llama_index.
_IMPORT_FLAG = "llama_index"


class LlamaIndexPatcher(FrameworkPatcher):
    name = "llamaindex"
    display_name = "LlamaIndex"
    package_names = [
        "llama-index",
        "llama-index-core",
        "llama-index-llms-openai",
        "llama-index-llms-anthropic",
        "llama_index",
    ]
    import_prefixes = ["llama_index"]

    def find_call_sites(self, project_root: Path) -> List[CallSite]:
        """LlamaIndex doesn't patch ctors. Return one placeholder CallSite
        per file that imports llama_index, used only to flag the file —
        positional fields (line/col) are unused by build_patch."""
        out: List[CallSite] = []
        for path in _walk_python_files(project_root):
            try:
                source = path.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            if _IMPORT_FLAG not in source:
                continue
            out.append(CallSite(
                file=path, line=1, col=0, end_line=1, end_col=0,
                ctor_name="<llama_index_module>",
                source_snippet="",
            ))
        return out

    def build_patch(
        self,
        file: Path,
        source: str,
        call_sites: List[CallSite],
        api_key: str,
        hook_url: str,
    ) -> PatchPlan:
        if _MARKER in source:
            return PatchPlan(
                file=file, original=source, patched=source,
                call_sites_modified=0,
                skipped_reason="file already patched (Settings.callback_manager set)",
            )

        block_lines = [
            "",
            "# FANGCUN_GUARD_HOOK — added by `fangcun install --project`. "
            "Edit the api_key / base_url below if your env doesn't carry them.",
            "from fangcun_hook_sdk import HookClient",
            "from fangcun_hook_sdk.adapters.llamaindex_callback import FangcunLlamaIndexHandler",
            "from llama_index.core import Settings",
            "from llama_index.core.callbacks import CallbackManager",
            f"_fc_hook = HookClient(api_key={api_key!r}, base_url={hook_url!r})",
            "Settings.callback_manager = CallbackManager([FangcunLlamaIndexHandler(_fc_hook)])",
            "",
        ]
        patched = inject_block_after_imports(source, block_lines)

        return PatchPlan(
            file=file, original=source, patched=patched,
            # call_sites_modified counts FILES touched for LlamaIndex,
            # since we don't operate on individual ctors here.
            call_sites_modified=1,
        )
