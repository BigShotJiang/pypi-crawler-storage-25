"""Base class + shared types + runtime helpers for agent installers.

The runtime helpers in the second half (read_stdin_json, emit_*,
save/load_mapping) are imported by each `installer/<agent>.py::hook_main()`
to avoid duplicating the stdin/stdout JSON dance and the on-disk session
cache for ANONYMIZE restore mappings.
"""
from __future__ import annotations

import json
import os
import sys
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..core import HookClient


# ============================================================
# Installer base
# ============================================================


@dataclass
class AgentDetection:
    found: bool
    binary_path: Optional[Path] = None
    config_path: Optional[Path] = None
    notes: List[str] = field(default_factory=list)


@dataclass
class InstallResult:
    success: bool
    actions: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


@dataclass
class InstallStatus:
    agent_name: str
    detected: bool
    fangcun_installed: bool
    config_path: Optional[Path] = None
    script_path: Optional[Path] = None
    hook_url: Optional[str] = None
    notes: List[str] = field(default_factory=list)


# Where every materialized hook script lives.
SCRIPTS_DIR = Path(
    os.environ.get("FANGCUN_SCRIPTS_DIR", str(Path.home() / ".fangcun" / "scripts"))
)


# Marker string the installer drops into a config file so we can later detect
# our own entries on `remove` and `status` without touching unrelated user
# config.
FANGCUN_HOOK_TAG = "FANGCUN_GUARD_HOOK"


class AgentInstaller(ABC):
    """One per supported agent app. The CLI calls these via the
    `installer.REGISTRY` mapping."""

    name: str = ""               # CLI flag, e.g. "claude-code"
    display_name: str = ""        # human-readable, e.g. "Claude Code"
    script_filename: str = ""     # materialized name in SCRIPTS_DIR

    @abstractmethod
    def detect(self) -> AgentDetection:
        """Return whether the agent is installed on this machine and where
        we'd write its config."""

    @abstractmethod
    def install(self, api_key: str, hook_url: str, fail_open: bool = True) -> InstallResult:
        """Materialize the hook script + patch the agent's config."""

    @abstractmethod
    def uninstall(self) -> InstallResult:
        """Remove FangcunGuard's entries from the agent's config and delete
        the materialized script."""

    @abstractmethod
    def status(self) -> InstallStatus:
        """Report whether FangcunGuard is currently configured for this agent."""

    # ---- helpers shared across installers ----

    @property
    def materialized_script_path(self) -> Path:
        return SCRIPTS_DIR / self.script_filename

    def materialize_script(self) -> Path:
        """Write the small Python shim that calls `installer.<agent>.hook_main`.
        Same shim is used for all agents — only the import target differs."""
        SCRIPTS_DIR.mkdir(parents=True, exist_ok=True)
        path = self.materialized_script_path
        body = (
            "#!/usr/bin/env python3\n"
            f"# {FANGCUN_HOOK_TAG} — materialized by `fangcun install --agent {self.name}`.\n"
            f"# Edit logic in fangcun_hook_sdk.installer.{self._module_name()} instead.\n"
            "import sys\n"
            f"from fangcun_hook_sdk.installer.{self._module_name()} import hook_main\n\n"
            "if __name__ == \"__main__\":\n"
            "    sys.exit(hook_main())\n"
        )
        path.write_text(body, encoding="utf-8")
        try:
            os.chmod(path, 0o755)
        except OSError:
            pass
        return path

    def _module_name(self) -> str:
        # ClaudeCodeInstaller -> claude_code, CodexCliInstaller -> codex_cli
        # Fall back to a kebab→snake on `name` if subclass overrides nothing else.
        return self.name.replace("-", "_")

    def remove_materialized_script(self) -> bool:
        path = self.materialized_script_path
        if path.exists():
            try:
                path.unlink()
                return True
            except OSError:
                pass
        return False


# ============================================================
# Runtime helpers used by installer/<agent>.py::hook_main
# ============================================================


def build_client_from_env() -> Optional[HookClient]:
    api_key = os.environ.get("FANGCUN_API_KEY")
    if not api_key:
        sys.stderr.write("[fangcun-hook] FANGCUN_API_KEY not set; passing through\n")
        return None
    base_url = os.environ.get("FANGCUN_HOOK_URL", "http://localhost:5002")
    fail_open = os.environ.get("FANGCUN_FAIL_OPEN", "true").lower() not in {"0", "false", "no"}
    return HookClient(base_url=base_url, api_key=api_key, fail_open=fail_open)


def read_stdin_json() -> Dict[str, Any]:
    raw = sys.stdin.read()
    if not raw or not raw.strip():
        return {}
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except json.JSONDecodeError:
        return {}


def write_json(obj: Dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(obj, ensure_ascii=False))
    sys.stdout.flush()


def emit_pass(extra: Optional[Dict[str, Any]] = None) -> None:
    out: Dict[str, Any] = {"decision": "pass"}
    if extra:
        out.update(extra)
    write_json(out)


def emit_block(reason: str, extra: Optional[Dict[str, Any]] = None) -> None:
    out: Dict[str, Any] = {"decision": "block", "reason": reason}
    if extra:
        out.update(extra)
    write_json(out)


def emit_replace(content: str, extra: Optional[Dict[str, Any]] = None) -> None:
    out: Dict[str, Any] = {"decision": "replace", "content": content}
    if extra:
        out.update(extra)
    write_json(out)


# ANONYMIZE restore-mapping cache (cross-process for Tier-A scripts)

_DEFAULT_SESSION_DIR = Path(
    os.environ.get("FANGCUN_SESSION_DIR", str(Path.home() / ".fangcun" / "sessions"))
)


def _session_path(session_id: str, base_dir: Optional[Path] = None) -> Path:
    base = base_dir or _DEFAULT_SESSION_DIR
    safe = "".join(c for c in session_id if c.isalnum() or c in "-_")
    if not safe:
        raise ValueError(f"refusing to use unsafe session_id: {session_id!r}")
    return base / f"{safe}.json"


def save_mapping(session_id: str, mapping: Dict[str, str], *, base_dir: Optional[Path] = None) -> None:
    if not mapping:
        return
    path = _session_path(session_id, base_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"saved_at": time.time(), "mapping": mapping}
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")


def load_mapping(session_id: Optional[str], *, base_dir: Optional[Path] = None) -> Optional[Dict[str, str]]:
    if not session_id:
        return None
    path = _session_path(session_id, base_dir)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data.get("mapping") or None
    except Exception:
        return None


def purge_expired(*, ttl: float = 3600.0, base_dir: Optional[Path] = None) -> int:
    base = base_dir or _DEFAULT_SESSION_DIR
    if not base.exists():
        return 0
    now = time.time()
    removed = 0
    for child in base.iterdir():
        if not child.is_file() or child.suffix != ".json":
            continue
        try:
            data = json.loads(child.read_text(encoding="utf-8"))
            saved_at = float(data.get("saved_at", 0))
        except Exception:
            saved_at = 0
        if now - saved_at > ttl:
            try:
                child.unlink()
                removed += 1
            except OSError:
                pass
    return removed
