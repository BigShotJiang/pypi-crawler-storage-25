"""Adapter: monkey-patch `litellm.completion` and `litellm.acompletion` so any
agent that routes its LLM call through LiteLLM gets FangcunGuard scanning
automatically — without changing the agent's source.

Targets covered (because they all route through `litellm.completion(...)`):
    - aider          (https://github.com/Aider-AI/aider)
    - open-interpreter (https://github.com/OpenInterpreter/open-interpreter)
    - smolagents     (https://github.com/huggingface/smolagents) when using
                     LiteLLMModel
    - agno           (when using OpenAILike model)

Usage (patch ONCE, before the agent does any LLM call):

    import litellm
    from fangcun_hook_sdk import HookClient
    from fangcun_hook_sdk.adapters.litellm import wrap_litellm

    hook = HookClient(base_url="http://localhost:5002", api_key="sk-xxai-...")
    wrap_litellm(litellm, hook)

    # From here on, litellm.completion(...) and litellm.acompletion(...)
    # are scanned. aider / open-interpreter etc. don't need to change.
"""
from __future__ import annotations

import time
from typing import Any, Optional, Union

from ..core import AsyncHookClient, HookClient
from ..types import Action, FangcunBlocked, ScanResult


# ---------- response shape helpers ----------
# LiteLLM normalises every backend's response into an OpenAI-compatible
# ModelResponse, but we don't want to depend on litellm's pydantic types here.
# We support both pydantic-style attribute access and dict access.


def _extract_content(response: Any) -> str:
    try:
        return response.choices[0].message.content or ""
    except (AttributeError, IndexError, TypeError):
        try:
            return response["choices"][0]["message"]["content"] or ""
        except Exception:
            return ""


def _set_content(response: Any, new_content: str) -> bool:
    """Mutate response in place. Returns True on success."""
    try:
        response.choices[0].message.content = new_content
        return True
    except (AttributeError, IndexError, TypeError):
        pass
    try:
        response["choices"][0]["message"]["content"] = new_content
        return True
    except Exception:
        return False


def _fake_stream(content: str, model: str, response_id: Optional[str] = None,
                 chunk_size: int = 50):
    """Yield a real `litellm.completion(stream=True)` already returns a generator
    of streaming chunks. When we internally turn streaming OFF (so we can run
    output scan on the full response), we still need to hand the agent something
    that looks like a stream — otherwise its `for chunk in completion:` code
    explodes. This generator chops the final content into small pieces and
    yields them in litellm's streaming-chunk shape."""
    rid = response_id or f"fangcun-stream-{int(time.time() * 1000)}"
    pieces = [content[i:i + chunk_size] for i in range(0, len(content), chunk_size)] or [""]
    last = len(pieces) - 1

    try:
        from litellm.types.utils import (  # type: ignore
            Delta,
            ModelResponseStream,
            StreamingChoices,
        )
        for i, piece in enumerate(pieces):
            yield ModelResponseStream(
                id=rid,
                model=model,
                choices=[StreamingChoices(
                    index=0,
                    delta=Delta(role="assistant" if i == 0 else None, content=piece),
                    finish_reason="stop" if i == last else None,
                )],
            )
        return
    except Exception:
        # litellm types unavailable; fall back to plain dict shape.
        for i, piece in enumerate(pieces):
            yield {
                "id": rid,
                "object": "chat.completion.chunk",
                "created": int(time.time()),
                "model": model,
                "choices": [{
                    "index": 0,
                    "delta": {"role": "assistant", "content": piece} if i == 0 else {"content": piece},
                    "finish_reason": "stop" if i == last else None,
                }],
            }


async def _fake_stream_async(content: str, model: str, response_id: Optional[str] = None,
                             chunk_size: int = 50):
    """Async variant of _fake_stream for litellm.acompletion(stream=True) callers."""
    for chunk in _fake_stream(content, model, response_id, chunk_size):
        yield chunk


def _build_replacement(message: str, model: str = "fangcun-hook") -> Any:
    """Construct a litellm/OpenAI-shaped response carrying a replacement message."""
    try:
        from litellm.types.utils import Choices, Message, ModelResponse  # type: ignore

        return ModelResponse(
            id=f"fangcun-replace-{int(time.time() * 1000)}",
            choices=[Choices(
                index=0,
                message=Message(role="assistant", content=message),
                finish_reason="stop",
            )],
            model=model,
        )
    except Exception:
        # Fallback: a plain dict — litellm consumers usually accept either.
        return {
            "id": f"fangcun-replace-{int(time.time() * 1000)}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": model,
            "choices": [{
                "index": 0,
                "message": {"role": "assistant", "content": message},
                "finish_reason": "stop",
            }],
            "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
        }


# ---------- the patcher ----------

def wrap_litellm(
    litellm_module: Any,
    hook: Union[HookClient, AsyncHookClient],
    *,
    raise_on_block: bool = True,
) -> Any:
    """Patch `litellm.completion` and `litellm.acompletion` in place.

    Args:
        litellm_module: the imported `litellm` module.
        hook: either a HookClient (used for sync paths) or AsyncHookClient
              (used for async paths). If you need both sync and async agents
              in the same process, pass both — see `wrap_litellm_dual`.
        raise_on_block: if True (default), `action=block` raises
                        FangcunBlocked. If False, a replacement response
                        with the block message is returned instead.

    Returns:
        The same litellm module (for chaining / debugging).
    """
    sync_hook: Optional[HookClient] = hook if isinstance(hook, HookClient) else None
    async_hook: Optional[AsyncHookClient] = hook if isinstance(hook, AsyncHookClient) else None

    original_completion = litellm_module.completion
    original_acompletion = getattr(litellm_module, "acompletion", None)

    def _apply_input_scan(scan_in: ScanResult, kwargs: dict, model: str):
        """Returns (override_response, kwargs, restore_mapping, forwarded_messages)
        — override_response is non-None when we want to short-circuit the LLM call."""
        if scan_in.action == Action.BLOCK:
            if raise_on_block:
                raise FangcunBlocked(scan_in.message or "blocked by FangcunGuard", scan_in)
            return _build_replacement(scan_in.message or "[blocked]", model), kwargs, None, kwargs.get("messages")
        if scan_in.action == Action.REPLACE:
            return _build_replacement(scan_in.message or "[replaced]", model), kwargs, None, kwargs.get("messages")
        if scan_in.action == Action.ANONYMIZE and scan_in.anonymized_messages:
            kwargs["messages"] = scan_in.anonymized_messages
            return None, kwargs, scan_in.restore_mapping, scan_in.anonymized_messages
        return None, kwargs, None, kwargs.get("messages")

    def _apply_output_scan(response: Any, scan_out: ScanResult) -> Any:
        if scan_out.action == Action.BLOCK:
            if raise_on_block:
                raise FangcunBlocked(scan_out.message or "blocked by FangcunGuard", scan_out)
            _set_content(response, scan_out.message or "[blocked]")
        elif scan_out.action == Action.REPLACE:
            _set_content(response, scan_out.message or "[replaced]")
        elif scan_out.action == Action.RESTORE and scan_out.content is not None:
            _set_content(response, scan_out.content)
        return response

    def patched_completion(*args: Any, **kwargs: Any):
        if sync_hook is None:
            raise RuntimeError(
                "wrap_litellm: litellm.completion (sync) called but only "
                "AsyncHookClient was supplied. Pass HookClient or use only acompletion."
            )
        messages = kwargs.get("messages")
        model = kwargs.get("model", "unknown")
        requested_stream = bool(kwargs.get("stream", False))
        if messages is None:
            return original_completion(*args, **kwargs)

        # Scanning a real chunk-stream is hard; force the underlying LLM call
        # to be non-streaming so we can run scan_output on the full content,
        # then re-stream the final content back to the caller.
        if requested_stream:
            kwargs["stream"] = False

        scan_in = sync_hook.scan_input(messages=messages, stream=requested_stream)
        override, kwargs, restore_mapping, forwarded = _apply_input_scan(scan_in, kwargs, model)
        if override is not None:
            if requested_stream:
                return _fake_stream(_extract_content(override), model,
                                    getattr(override, "id", None))
            return override

        response = original_completion(*args, **kwargs)
        content = _extract_content(response)
        if content:
            scan_out = sync_hook.scan_output(
                content=content, restore_mapping=restore_mapping, messages=forwarded
            )
            response = _apply_output_scan(response, scan_out)

        if requested_stream:
            return _fake_stream(_extract_content(response), model,
                                getattr(response, "id", None))
        return response

    async def patched_acompletion(*args: Any, **kwargs: Any):
        if async_hook is None:
            raise RuntimeError(
                "wrap_litellm: litellm.acompletion (async) called but only "
                "HookClient was supplied. Pass AsyncHookClient or use only completion."
            )
        messages = kwargs.get("messages")
        model = kwargs.get("model", "unknown")
        requested_stream = bool(kwargs.get("stream", False))
        if messages is None:
            return await original_acompletion(*args, **kwargs)

        if requested_stream:
            kwargs["stream"] = False

        scan_in = await async_hook.scan_input(messages=messages, stream=requested_stream)
        override, kwargs, restore_mapping, forwarded = _apply_input_scan(scan_in, kwargs, model)
        if override is not None:
            if requested_stream:
                return _fake_stream_async(_extract_content(override), model,
                                          getattr(override, "id", None))
            return override

        response = await original_acompletion(*args, **kwargs)
        content = _extract_content(response)
        if content:
            scan_out = await async_hook.scan_output(
                content=content, restore_mapping=restore_mapping, messages=forwarded
            )
            response = _apply_output_scan(response, scan_out)

        if requested_stream:
            return _fake_stream_async(_extract_content(response), model,
                                      getattr(response, "id", None))
        return response

    litellm_module.completion = patched_completion
    if original_acompletion is not None:
        litellm_module.acompletion = patched_acompletion

    return litellm_module


def wrap_litellm_dual(
    litellm_module: Any,
    sync_hook: HookClient,
    async_hook: AsyncHookClient,
    *,
    raise_on_block: bool = True,
) -> Any:
    """Convenience: patch both sync and async paths when an agent uses both."""
    # Patch sync first, then re-patch async on top.
    wrap_litellm(litellm_module, sync_hook, raise_on_block=raise_on_block)
    wrap_litellm(litellm_module, async_hook, raise_on_block=raise_on_block)
    return litellm_module
