"""Adapter: wrap an Anthropic client so `client.messages.create` goes
through FangcunGuard hook scanning.

Targets covered:
    - Direct anthropic SDK callers (Claude python users)
    - LangChain ChatAnthropic (when its underlying client is wrapped)
    - Any custom agent that imports `anthropic.Anthropic` / `AsyncAnthropic`

Usage (sync):
    from anthropic import Anthropic
    from fangcun_hook_sdk import HookClient
    from fangcun_hook_sdk.adapters.anthropic import wrap_anthropic

    client = Anthropic(api_key="...")
    hook   = HookClient(base_url="http://localhost:5002", api_key="sk-xxai-...")
    wrap_anthropic(client, hook)

    response = client.messages.create(
        model="claude-3-5-sonnet-20241022",
        max_tokens=1024,
        messages=[{"role": "user", "content": "Hi"}],
    )

Usage (async):
    Use AsyncAnthropic + AsyncHookClient — same call, await the create.
"""
from __future__ import annotations

import asyncio
import time
from typing import Any, List, Optional, Union

from ..core import AsyncHookClient, HookClient
from ..types import Action, FangcunBlocked, ScanResult


# ---------- request shape adapters (Anthropic <-> OpenAI-format hook) ----------


def _flatten_content(content: Any) -> str:
    """Anthropic message content can be a str OR a list of ContentBlock dicts.
    For scanning, flatten to a single string (only text blocks are scanned;
    image / tool_use blocks are passed through opaquely)."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                parts.append(block.get("text", ""))
            elif hasattr(block, "type") and getattr(block, "type", None) == "text":
                parts.append(getattr(block, "text", ""))
        return "\n".join(parts)
    return str(content) if content is not None else ""


def _normalize_for_hook(messages: List[dict], system: Optional[Any]) -> List[dict]:
    """Convert Anthropic-style (separate system + messages) into OpenAI-style
    (messages with role=system) so the hook server processes them uniformly."""
    out: List[dict] = []
    if system:
        # system can also be a list of content blocks in newer API
        sys_text = system if isinstance(system, str) else _flatten_content(system)
        if sys_text:
            out.append({"role": "system", "content": sys_text})
    for m in messages:
        role = m.get("role") if isinstance(m, dict) else getattr(m, "role", None)
        content = m.get("content") if isinstance(m, dict) else getattr(m, "content", None)
        out.append({"role": role, "content": _flatten_content(content)})
    return out


# ---------- response shape helpers ----------


def _extract_text(response: Any) -> str:
    """Concatenate all text blocks from an Anthropic Message response."""
    try:
        parts: List[str] = []
        for block in response.content:
            if hasattr(block, "text"):
                parts.append(block.text or "")
            elif isinstance(block, dict) and block.get("type") == "text":
                parts.append(block.get("text", ""))
        return "".join(parts)
    except (AttributeError, IndexError, TypeError):
        return ""


def _set_text(response: Any, new_text: str) -> bool:
    """Replace the text of the first text block. Other block types kept as-is."""
    try:
        for block in response.content:
            if hasattr(block, "text"):
                block.text = new_text
                return True
            if isinstance(block, dict) and block.get("type") == "text":
                block["text"] = new_text
                return True
        return False
    except (AttributeError, IndexError, TypeError):
        return False


def _build_replacement(message: str, model: str = "fangcun-hook") -> Any:
    """Construct an Anthropic-shaped Message response carrying a replacement text."""
    try:
        from anthropic.types import Message, TextBlock, Usage  # type: ignore
        return Message(
            id=f"fangcun-replace-{int(time.time() * 1000)}",
            type="message",
            role="assistant",
            content=[TextBlock(type="text", text=message)],
            model=model,
            stop_reason="end_turn",
            stop_sequence=None,
            usage=Usage(input_tokens=0, output_tokens=0),
        )
    except Exception:
        return {
            "id": f"fangcun-replace-{int(time.time() * 1000)}",
            "type": "message",
            "role": "assistant",
            "content": [{"type": "text", "text": message}],
            "model": model,
            "stop_reason": "end_turn",
            "usage": {"input_tokens": 0, "output_tokens": 0},
        }


# ---------- the patcher ----------


def wrap_anthropic(
    client: Any,
    hook: Union[HookClient, AsyncHookClient],
    *,
    raise_on_block: bool = True,
) -> Any:
    """Patch `client.messages.create` so every call runs through the hook.

    Auto-detects sync (`Anthropic`) vs async (`AsyncAnthropic`) client and
    requires the matching hook flavour (HookClient vs AsyncHookClient).
    """
    messages_resource = client.messages
    original_create = messages_resource.create
    is_async = asyncio.iscoroutinefunction(original_create)

    if is_async and not isinstance(hook, AsyncHookClient):
        raise RuntimeError(
            "wrap_anthropic: AsyncAnthropic clients need an AsyncHookClient."
        )
    if not is_async and not isinstance(hook, HookClient):
        raise RuntimeError(
            "wrap_anthropic: Anthropic (sync) clients need a HookClient."
        )

    def _apply_input(scan_in: ScanResult, kwargs: dict, model: str):
        if scan_in.action == Action.BLOCK:
            if raise_on_block:
                raise FangcunBlocked(scan_in.message or "blocked by FangcunGuard", scan_in)
            return _build_replacement(scan_in.message or "[blocked]", model), kwargs, None
        if scan_in.action == Action.REPLACE:
            return _build_replacement(scan_in.message or "[replaced]", model), kwargs, None
        if scan_in.action == Action.ANONYMIZE and scan_in.anonymized_messages:
            # The hook server returned messages in OpenAI shape (system as
            # a role inside the list). Convert back to Anthropic shape:
            # split out the system role into the `system=` kwarg.
            new_system = None
            new_messages: List[dict] = []
            for m in scan_in.anonymized_messages:
                if m.get("role") == "system":
                    new_system = m.get("content")
                else:
                    new_messages.append(m)
            kwargs["messages"] = new_messages
            if new_system is not None:
                kwargs["system"] = new_system
            return None, kwargs, scan_in.restore_mapping
        return None, kwargs, None

    def _apply_output(response: Any, scan_out: ScanResult) -> Any:
        if scan_out.action == Action.BLOCK:
            if raise_on_block:
                raise FangcunBlocked(scan_out.message or "blocked by FangcunGuard", scan_out)
            _set_text(response, scan_out.message or "[blocked]")
        elif scan_out.action == Action.REPLACE:
            _set_text(response, scan_out.message or "[replaced]")
        elif scan_out.action == Action.RESTORE and scan_out.content is not None:
            _set_text(response, scan_out.content)
        return response

    if is_async:
        assert isinstance(hook, AsyncHookClient)

        async def patched_create(*args: Any, **kwargs: Any):
            messages = kwargs.get("messages")
            system = kwargs.get("system")
            model = kwargs.get("model", "unknown")
            stream = bool(kwargs.get("stream", False))
            if messages is None:
                return await original_create(*args, **kwargs)

            normalized = _normalize_for_hook(messages, system)
            scan_in = await hook.scan_input(messages=normalized, stream=stream)
            override, kwargs, restore_mapping = _apply_input(scan_in, kwargs, model)
            if override is not None:
                return override

            response = await original_create(*args, **kwargs)
            if stream:
                return response  # streaming chunk-level scan: future enhancement

            content = _extract_text(response)
            if not content:
                return response

            scan_out = await hook.scan_output(
                content=content, restore_mapping=restore_mapping, messages=normalized
            )
            return _apply_output(response, scan_out)

        messages_resource.create = patched_create
    else:
        assert isinstance(hook, HookClient)

        def patched_create(*args: Any, **kwargs: Any):
            messages = kwargs.get("messages")
            system = kwargs.get("system")
            model = kwargs.get("model", "unknown")
            stream = bool(kwargs.get("stream", False))
            if messages is None:
                return original_create(*args, **kwargs)

            normalized = _normalize_for_hook(messages, system)
            scan_in = hook.scan_input(messages=normalized, stream=stream)
            override, kwargs, restore_mapping = _apply_input(scan_in, kwargs, model)
            if override is not None:
                return override

            response = original_create(*args, **kwargs)
            if stream:
                return response

            content = _extract_text(response)
            if not content:
                return response

            scan_out = hook.scan_output(
                content=content, restore_mapping=restore_mapping, messages=normalized
            )
            return _apply_output(response, scan_out)

        messages_resource.create = patched_create

    return client
