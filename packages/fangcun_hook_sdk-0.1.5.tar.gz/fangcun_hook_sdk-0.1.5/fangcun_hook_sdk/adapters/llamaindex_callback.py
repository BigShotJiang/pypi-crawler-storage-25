"""LlamaIndex BaseCallbackHandler adapter for FangcunGuard.

Usage:

    from fangcun_hook_sdk import HookClient
    from fangcun_hook_sdk.adapters.llamaindex_callback import (
        FangcunLlamaIndexHandler,
    )
    from llama_index.core import Settings
    from llama_index.core.callbacks import CallbackManager

    hook = HookClient(base_url="http://localhost:5002", api_key="sk-xxai-...")
    Settings.callback_manager = CallbackManager([FangcunLlamaIndexHandler(hook)])

Scans both LLM events (input messages and output text) and FUNCTION_CALL
events (tool args + return value).
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

try:
    from llama_index.core.callbacks.base_handler import BaseCallbackHandler
    from llama_index.core.callbacks.schema import CBEventType, EventPayload
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "fangcun_hook_sdk.adapters.llamaindex_callback requires llama-index-core. "
        "Install with: pip install 'fangcun-hook-sdk[llamaindex]'"
    ) from e

from ..core import HookClient
from ..types import Action, FangcunBlocked


_SCAN_INPUT_TYPES = {CBEventType.LLM, CBEventType.FUNCTION_CALL, CBEventType.AGENT_STEP}
_SCAN_OUTPUT_TYPES = {CBEventType.LLM, CBEventType.FUNCTION_CALL}


def _payload_to_messages(payload: Optional[Dict[str, Any]]) -> List[Dict[str, Any]]:
    if not payload:
        return []
    msgs = payload.get(EventPayload.MESSAGES) or payload.get(EventPayload.PROMPT)
    if msgs is None:
        return []
    if isinstance(msgs, str):
        return [{"role": "user", "content": msgs}]
    out: List[Dict[str, Any]] = []
    for m in msgs:
        role = getattr(m, "role", None) or (m.get("role") if isinstance(m, dict) else "user")
        content = getattr(m, "content", None) or (
            m.get("content") if isinstance(m, dict) else str(m)
        )
        if hasattr(role, "value"):
            role = role.value
        out.append({"role": str(role), "content": content if isinstance(content, str) else str(content)})
    return out


def _payload_to_output_text(payload: Optional[Dict[str, Any]]) -> str:
    if not payload:
        return ""
    response = (
        payload.get(EventPayload.RESPONSE)
        or payload.get(EventPayload.COMPLETION)
        or payload.get(EventPayload.FUNCTION_OUTPUT)
    )
    if response is None:
        return ""
    if isinstance(response, str):
        return response
    text = getattr(response, "text", None) or getattr(response, "message", None)
    if text and not isinstance(text, str):
        text = getattr(text, "content", None) or str(text)
    return text or str(response)


class FangcunLlamaIndexHandler(BaseCallbackHandler):
    """LlamaIndex callback that scans LLM and tool events."""

    def __init__(
        self,
        hook: HookClient,
        *,
        event_starts_to_ignore: Optional[List[CBEventType]] = None,
        event_ends_to_ignore: Optional[List[CBEventType]] = None,
    ):
        super().__init__(
            event_starts_to_ignore=event_starts_to_ignore or [],
            event_ends_to_ignore=event_ends_to_ignore or [],
        )
        self._hook = hook

    def on_event_start(
        self,
        event_type: CBEventType,
        payload: Optional[Dict[str, Any]] = None,
        event_id: str = "",
        parent_id: str = "",
        **kwargs: Any,
    ) -> str:
        if event_type in _SCAN_INPUT_TYPES:
            messages = _payload_to_messages(payload)
            if messages:
                result = self._hook.scan_input(messages, stream=False)
                if result.action == Action.BLOCK:
                    raise FangcunBlocked(
                        result.message or f"blocked by FangcunGuard ({event_type.value})"
                    )
        return event_id

    def on_event_end(
        self,
        event_type: CBEventType,
        payload: Optional[Dict[str, Any]] = None,
        event_id: str = "",
        **kwargs: Any,
    ) -> None:
        if event_type in _SCAN_OUTPUT_TYPES:
            text = _payload_to_output_text(payload)
            if text:
                result = self._hook.scan_output(text)
                if result.action == Action.BLOCK:
                    raise FangcunBlocked(
                        result.message or f"blocked by FangcunGuard ({event_type.value})"
                    )

    def start_trace(self, trace_id: Optional[str] = None) -> None:
        return None

    def end_trace(
        self,
        trace_id: Optional[str] = None,
        trace_map: Optional[Dict[str, List[str]]] = None,
    ) -> None:
        return None


__all__ = ["FangcunLlamaIndexHandler"]
