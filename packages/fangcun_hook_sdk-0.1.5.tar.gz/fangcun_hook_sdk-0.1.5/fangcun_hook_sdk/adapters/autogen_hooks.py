"""AutoGen / Microsoft Agent Framework hook adapter for FangcunGuard.

Two API generations are supported:

1. **AutoGen 0.2.x** (`autogen` package) — `register_hook` on `ConversableAgent`
   for `process_message_before_send` and `process_last_received_message`.
2. **AutoGen 0.4+ / Microsoft Agent Framework** (`autogen_core` / `agent_framework`)
   — message-handler middleware via `intervention_handlers`.

Use `attach_to_agent(agent, hook)` for 0.2.x and `make_intervention_handler(hook)`
for 0.4+.

AutoGen has had unstable APIs across versions; this adapter is a thin
best-effort wrapper. If your version is not detected, fall back to the
in-process LangChain or wrap-client adapter.
"""
from __future__ import annotations

from typing import Any, Awaitable, Callable, Dict, List, Optional

from ..core import AsyncHookClient, HookClient
from ..types import Action, FangcunBlocked


def _coerce_messages(payload: Any) -> List[Dict[str, Any]]:
    if payload is None:
        return []
    if isinstance(payload, str):
        return [{"role": "user", "content": payload}]
    if isinstance(payload, dict):
        if "content" in payload:
            return [{"role": payload.get("role", "user"), "content": str(payload["content"])}]
        return [payload]
    if isinstance(payload, list):
        out: List[Dict[str, Any]] = []
        for m in payload:
            if isinstance(m, dict) and "content" in m:
                out.append({"role": m.get("role", "user"), "content": str(m["content"])})
            elif isinstance(m, str):
                out.append({"role": "user", "content": m})
        return out
    return [{"role": "user", "content": str(payload)}]


def _coerce_text(payload: Any) -> str:
    if payload is None:
        return ""
    if isinstance(payload, str):
        return payload
    if isinstance(payload, dict):
        return str(payload.get("content", ""))
    return str(payload)


def attach_to_agent(agent: Any, hook: HookClient) -> None:
    """AutoGen 0.2.x: register input/output hooks on a ConversableAgent.

    Raises AttributeError if the agent does not expose `register_hook`.
    """
    if not hasattr(agent, "register_hook"):
        raise AttributeError(
            "agent does not expose register_hook(); not an AutoGen 0.2.x ConversableAgent"
        )

    def _input_hook(sender, message, recipient, silent):  # noqa: ANN001
        msgs = _coerce_messages(message)
        if not msgs:
            return message
        result = hook.scan_input(msgs, stream=False)
        if result.action == Action.BLOCK:
            raise FangcunBlocked(result.message or "blocked by FangcunGuard (autogen input)")
        if result.action == Action.ANONYMIZE and result.anonymized_messages:
            anon = result.anonymized_messages[0]
            if isinstance(message, dict):
                return {**message, "content": anon.get("content", message.get("content"))}
            return anon.get("content", message)
        return message

    def _output_hook(message):  # noqa: ANN001
        text = _coerce_text(message)
        if not text:
            return message
        result = hook.scan_output(text)
        if result.action == Action.BLOCK:
            raise FangcunBlocked(result.message or "blocked by FangcunGuard (autogen output)")
        if result.action == Action.REPLACE and result.message:
            if isinstance(message, dict):
                return {**message, "content": result.message}
            return result.message
        return message

    agent.register_hook(hookable_method="process_message_before_send", hook=_input_hook)
    agent.register_hook(hookable_method="process_last_received_message", hook=_output_hook)


def make_intervention_handler(hook: AsyncHookClient) -> Any:
    """AutoGen 0.4+ / Microsoft Agent Framework: build a message intervention
    handler that scans every message routed through the runtime.

    The returned object follows the `DefaultInterventionHandler` protocol —
    callers attach it to the runtime via `intervention_handlers=[...]`.
    """
    try:
        from autogen_core import DefaultInterventionHandler
        from autogen_core import DropMessage
    except ImportError as e:  # pragma: no cover
        raise ImportError(
            "make_intervention_handler requires autogen-core (AutoGen 0.4+)"
        ) from e

    class _Handler(DefaultInterventionHandler):
        async def on_send(self, message: Any, *, message_context: Any, recipient: Any) -> Any:
            text = _coerce_text(message)
            if text:
                result = await hook.scan_input(
                    [{"role": "user", "content": text}], stream=False
                )
                if result.action == Action.BLOCK:
                    return DropMessage
            return message

        async def on_publish(self, message: Any, *, message_context: Any) -> Any:
            text = _coerce_text(message)
            if text:
                result = await hook.scan_output(text)
                if result.action == Action.BLOCK:
                    return DropMessage
            return message

    return _Handler()


__all__ = ["attach_to_agent", "make_intervention_handler"]
