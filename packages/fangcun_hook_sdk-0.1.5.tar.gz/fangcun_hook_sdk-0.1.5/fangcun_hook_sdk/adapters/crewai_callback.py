"""CrewAI step/task callback adapter for FangcunGuard.

CrewAI exposes `step_callback` and `task_callback` parameters on `Crew` and
`Agent` constructors. Use `make_step_callback(hook)` and
`make_task_callback(hook)` to build callbacks that run the FangcunGuard scan
on each step output / task output.

Usage:

    from fangcun_hook_sdk import HookClient
    from fangcun_hook_sdk.adapters.crewai_callback import (
        make_step_callback, make_task_callback,
    )

    hook = HookClient(base_url="http://localhost:5002", api_key="sk-xxai-...")
    crew = Crew(
        agents=[...],
        tasks=[...],
        step_callback=make_step_callback(hook),
        task_callback=make_task_callback(hook),
    )

CrewAI does not surface the actual prompt sent to the LLM in step callbacks
(that's handled inside LiteLLM, which already has its own adapter — see
`adapters/litellm.py`). This adapter scans **outputs** of each step/task only.
"""
from __future__ import annotations

from typing import Any, Callable

from ..core import HookClient
from ..types import Action, FangcunBlocked


def _step_text(step_output: Any) -> str:
    if step_output is None:
        return ""
    if isinstance(step_output, str):
        return step_output
    for attr in ("output", "text", "result", "content", "raw"):
        v = getattr(step_output, attr, None)
        if isinstance(v, str) and v:
            return v
    if isinstance(step_output, dict):
        for key in ("output", "text", "result", "content", "raw"):
            v = step_output.get(key)
            if isinstance(v, str) and v:
                return v
    return str(step_output)


def _task_text(task_output: Any) -> str:
    if task_output is None:
        return ""
    if isinstance(task_output, str):
        return task_output
    for attr in ("raw", "output", "result", "summary", "json_dict"):
        v = getattr(task_output, attr, None)
        if isinstance(v, str) and v:
            return v
    return str(task_output)


def make_step_callback(hook: HookClient) -> Callable[[Any], None]:
    """Return a CrewAI-compatible step_callback that scans each step output."""

    def _cb(step_output: Any) -> None:
        text = _step_text(step_output)
        if not text:
            return
        result = hook.scan_output(text)
        if result.action == Action.BLOCK:
            raise FangcunBlocked(result.message or "blocked by FangcunGuard (crewai step)")

    return _cb


def make_task_callback(hook: HookClient) -> Callable[[Any], None]:
    """Return a CrewAI-compatible task_callback that scans each completed task."""

    def _cb(task_output: Any) -> None:
        text = _task_text(task_output)
        if not text:
            return
        result = hook.scan_output(text)
        if result.action == Action.BLOCK:
            raise FangcunBlocked(result.message or "blocked by FangcunGuard (crewai task)")

    return _cb


__all__ = ["make_step_callback", "make_task_callback"]
