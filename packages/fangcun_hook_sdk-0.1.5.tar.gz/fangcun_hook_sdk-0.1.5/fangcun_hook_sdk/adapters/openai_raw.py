"""Adapter: wrap a raw `openai.OpenAI` client so chat completions go through
FangcunGuard hook scanning.

Usage:
    from openai import OpenAI
    from fangcun_hook_sdk import HookClient
    from fangcun_hook_sdk.adapters.openai_raw import wrap_openai

    llm  = OpenAI(api_key="sk-...", base_url="https://api.openai.com/v1")
    hook = HookClient(base_url="http://localhost:5002", api_key="sk-xxai-...")
    llm  = wrap_openai(llm, hook)

    # From here on, every llm.chat.completions.create(...) is scanned.
    completion = llm.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "hi"}],
    )
"""
from __future__ import annotations

import time
from typing import Any

from ..core import HookClient
from ..types import Action, FangcunBlocked, ScanResult


def _build_replacement_completion(message: str, model: str = "fangcun-hook"):
    """Mimic the shape of an openai.types.chat.ChatCompletion just enough that
    callers can keep doing completion.choices[0].message.content."""
    try:
        from openai.types.chat import ChatCompletion, ChatCompletionMessage
        from openai.types.chat.chat_completion import Choice
        from openai.types.completion_usage import CompletionUsage
    except ImportError as e:
        raise RuntimeError(
            "openai package is required for the openai_raw adapter"
        ) from e

    return ChatCompletion(
        id=f"fangcun-replace-{int(time.time() * 1000)}",
        object="chat.completion",
        created=int(time.time()),
        model=model,
        choices=[
            Choice(
                index=0,
                message=ChatCompletionMessage(role="assistant", content=message),
                finish_reason="stop",
                logprobs=None,
            )
        ],
        usage=CompletionUsage(prompt_tokens=0, completion_tokens=0, total_tokens=0),
    )


def wrap_openai(client: Any, hook: HookClient, *, raise_on_block: bool = True) -> Any:
    """Patch `client.chat.completions.create` to run input/output scans.

    Args:
        client: an `openai.OpenAI` instance (or compatible).
        hook:   a HookClient pointing at the FangcunGuard Hook server.
        raise_on_block: if True (default), action=block raises FangcunBlocked.
                        if False, returns a ChatCompletion with the block message
                        as the assistant content (useful for chatbot UIs that
                        want to display the refusal).

    Returns:
        The same client, with `.chat.completions.create` patched in place.
    """
    chat_completions = client.chat.completions
    original_create = chat_completions.create

    def patched_create(*args: Any, **kwargs: Any):
        messages = kwargs.get("messages")
        model = kwargs.get("model", "unknown")
        stream = bool(kwargs.get("stream", False))
        if messages is None:
            # Caller passed messages positionally; defer to original.
            return original_create(*args, **kwargs)

        # --- Input scan ---
        scan_in: ScanResult = hook.scan_input(messages=messages, stream=stream)

        if scan_in.action == Action.BLOCK:
            if raise_on_block:
                raise FangcunBlocked(scan_in.message or "blocked by FangcunGuard", scan_in)
            return _build_replacement_completion(scan_in.message or "[blocked]", model=model)

        if scan_in.action == Action.REPLACE:
            return _build_replacement_completion(scan_in.message or "[replaced]", model=model)

        if scan_in.action == Action.ANONYMIZE and scan_in.anonymized_messages:
            kwargs["messages"] = scan_in.anonymized_messages
            restore_mapping = scan_in.restore_mapping
            forwarded_messages = scan_in.anonymized_messages
        else:
            restore_mapping = None
            forwarded_messages = messages

        # SWITCH_PRIVATE_MODEL is intentionally not implemented here — that's a
        # server-controlled routing feature that requires the gateway path. In
        # hook mode we just pass through.

        # --- Real LLM call ---
        completion = original_create(*args, **kwargs)

        if stream:
            # Stream wrapping needs per-chunk scan_output — out of scope for
            # this minimal adapter. Document and move on.
            return completion

        # --- Output scan ---
        try:
            choice = completion.choices[0]
            content = choice.message.content or ""
        except (AttributeError, IndexError):
            return completion

        scan_out: ScanResult = hook.scan_output(
            content=content,
            restore_mapping=restore_mapping,
            messages=forwarded_messages,
        )

        if scan_out.action == Action.BLOCK:
            if raise_on_block:
                raise FangcunBlocked(scan_out.message or "blocked by FangcunGuard", scan_out)
            choice.message.content = scan_out.message or "[blocked]"
        elif scan_out.action == Action.REPLACE:
            choice.message.content = scan_out.message or "[replaced]"
        elif scan_out.action == Action.RESTORE and scan_out.content is not None:
            choice.message.content = scan_out.content

        return completion

    chat_completions.create = patched_create  # type: ignore[assignment]
    return client
