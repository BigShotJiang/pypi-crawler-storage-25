"""Framework-specific adapters for the Hook SDK.

Each adapter sub-module is independent and only imports its target framework
on demand — installing fangcun-hook-sdk does NOT install OpenAI / OpenAI
Agents SDK / etc. You bring those yourself.
"""
