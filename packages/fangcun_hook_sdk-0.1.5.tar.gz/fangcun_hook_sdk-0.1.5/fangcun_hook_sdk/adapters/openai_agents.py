"""Adapter: wire FangcunGuard scans into the OpenAI Agents SDK as
input_guardrails / output_guardrails.

OpenAI Agents SDK reference:
    https://openai.github.io/openai-agents-python/guardrails/

Usage:
    from agents import Agent, Runner
    from fangcun_hook_sdk import AsyncHookClient
    from fangcun_hook_sdk.adapters.openai_agents import (
        make_input_guardrail,
        make_output_guardrail,
    )

    hook = AsyncHookClient(base_url="http://localhost:5002", api_key="sk-xxai-...")

    agent = Agent(
        name="my-agent",
        instructions="You are a helpful assistant.",
        input_guardrails=[make_input_guardrail(hook)],
        output_guardrails=[make_output_guardrail(hook)],
    )

    result = await Runner.run(agent, "What's the weather in Tokyo?")
"""
from __future__ import annotations

from typing import Any, Callable

from ..core import AsyncHookClient
from ..types import Action


def _ensure_messages(input_data: Any) -> list:
    """The Agents SDK passes input as either a string or a list of message dicts.
    Normalize to OpenAI messages format for the hook."""
    if isinstance(input_data, str):
        return [{"role": "user", "content": input_data}]
    if isinstance(input_data, list):
        return input_data
    return [{"role": "user", "content": str(input_data)}]


def make_input_guardrail(hook: AsyncHookClient) -> Callable:
    """Build an `input_guardrail`-decorated function for the Agents SDK.

    Tripwire (block) is fired when the hook server returns action=BLOCK.
    On REPLACE / ANONYMIZE we currently let the request through but stash
    the metadata in `output_info` so callers can inspect it; future versions
    may rewrite the input via tool-call surgery.
    """
    try:
        from agents import input_guardrail, GuardrailFunctionOutput  # type: ignore
    except ImportError as e:
        raise RuntimeError(
            "openai-agents package is required for the openai_agents adapter"
        ) from e

    @input_guardrail
    async def fangcun_input_guardrail(ctx, agent, input_data):
        messages = _ensure_messages(input_data)
        result = await hook.scan_input(messages=messages)
        info = {
            "action": result.action.value,
            "request_id": result.request_id,
            "risk_level": result.overall_risk_level,
            "message": result.message,
            "detection_result": result.detection_result,
        }
        return GuardrailFunctionOutput(
            output_info=info,
            tripwire_triggered=(result.action == Action.BLOCK),
        )

    return fangcun_input_guardrail


def make_output_guardrail(hook: AsyncHookClient) -> Callable:
    """Build an `output_guardrail`-decorated function for the Agents SDK.

    Note: the Agents SDK's output_guardrail signature receives the agent's
    final output as a string. Restoration / replacement here only sets the
    tripwire — content rewriting requires deeper integration (PR welcome)."""
    try:
        from agents import output_guardrail, GuardrailFunctionOutput  # type: ignore
    except ImportError as e:
        raise RuntimeError(
            "openai-agents package is required for the openai_agents adapter"
        ) from e

    @output_guardrail
    async def fangcun_output_guardrail(ctx, agent, output):
        content = output if isinstance(output, str) else str(output)
        result = await hook.scan_output(content=content)
        info = {
            "action": result.action.value,
            "request_id": result.request_id,
            "risk_level": result.overall_risk_level,
            "message": result.message,
            "restored_content": result.content,
            "detection_result": result.detection_result,
        }
        return GuardrailFunctionOutput(
            output_info=info,
            tripwire_triggered=(result.action == Action.BLOCK),
        )

    return fangcun_output_guardrail
