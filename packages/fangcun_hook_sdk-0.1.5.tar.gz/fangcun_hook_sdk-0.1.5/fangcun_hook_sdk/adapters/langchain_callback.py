"""LangChain BaseCallbackHandler adapter for FangcunGuard.

Usage:

    from fangcun_hook_sdk import HookClient
    from fangcun_hook_sdk.adapters.langchain_callback import FangcunCallbackHandler

    hook = HookClient(base_url="http://localhost:5002", api_key="sk-xxai-...")
    handler = FangcunCallbackHandler(hook)

    llm = ChatOpenAI(callbacks=[handler])
    # or pass via .invoke(..., config={"callbacks": [handler]})

In-process callback gives full visibility on the assembled messages going to
the LLM (system + messages + tools schema), unlike Tier-A native hooks of
Claude Code / Codex / Cursor / OpenClaw which only see fragments.

ANONYMIZE caveat: by the time `on_chat_model_start` fires, the messages have
already been serialized inside the LangChain runnable. The handler reports
ANONYMIZE via `FangcunBlocked` so the call is halted; users that need the
anonymized message rewritten in-flight should use the wrap-client adapters
(`adapters/openai_raw.py` etc.) instead.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence
from uuid import UUID

try:
    from langchain_core.callbacks import AsyncCallbackHandler, BaseCallbackHandler
    from langchain_core.messages import BaseMessage
    from langchain_core.outputs import LLMResult
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "fangcun_hook_sdk.adapters.langchain_callback requires langchain-core. "
        "Install with: pip install 'fangcun-hook-sdk[langchain]'"
    ) from e

from ..core import AsyncHookClient, HookClient
from ..types import Action, FangcunBlocked, FangcunReplaced


def _messages_to_openai(messages: Sequence[BaseMessage]) -> List[Dict[str, Any]]:
    """Convert LangChain BaseMessage list to OpenAI-shape dicts the hook
    server expects."""
    role_map = {"human": "user", "ai": "assistant", "system": "system", "tool": "tool"}
    out: List[Dict[str, Any]] = []
    for m in messages:
        role = role_map.get(getattr(m, "type", ""), getattr(m, "type", "user"))
        content = m.content if isinstance(m.content, str) else str(m.content)
        out.append({"role": role, "content": content})
    return out


def _flatten_message_batch(messages_batch: List[List[BaseMessage]]) -> List[Dict[str, Any]]:
    if not messages_batch:
        return []
    return _messages_to_openai(messages_batch[0])


def _llm_result_text(response: LLMResult) -> str:
    parts: List[str] = []
    for gen_list in response.generations:
        for gen in gen_list:
            text = getattr(gen, "text", None) or ""
            parts.append(text)
    return "".join(parts)


def _apply_input_action(action: Action, message: Optional[str], context: str) -> None:
    if action == Action.BLOCK:
        raise FangcunBlocked(message or f"blocked by FangcunGuard ({context})")
    if action == Action.REPLACE:
        raise FangcunReplaced(message or f"[replaced by FangcunGuard] ({context})")
    if action == Action.ANONYMIZE:
        raise FangcunBlocked(
            "FangcunGuard returned ANONYMIZE; the LangChain callback cannot "
            "rewrite messages in-flight. Use the wrap-client adapter or run "
            "the hook server in pre-process mode."
        )


class FangcunCallbackHandler(BaseCallbackHandler):
    """Synchronous LangChain callback handler."""

    def __init__(self, hook: HookClient, *, scan_tool_output: bool = True):
        self._hook = hook
        self._scan_tool_output = scan_tool_output

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List[BaseMessage]],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        flat = _flatten_message_batch(messages)
        if not flat:
            return
        result = self._hook.scan_input(flat, stream=False)
        _apply_input_action(result.action, result.message, "on_chat_model_start")

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        if not prompts:
            return
        msgs = [{"role": "user", "content": p} for p in prompts]
        result = self._hook.scan_input(msgs, stream=False)
        _apply_input_action(result.action, result.message, "on_llm_start")

    def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        text = _llm_result_text(response)
        if not text:
            return
        result = self._hook.scan_output(text)
        if result.action == Action.BLOCK:
            raise FangcunBlocked(result.message or "blocked by FangcunGuard (on_llm_end)")

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        if not self._scan_tool_output:
            return
        text = output if isinstance(output, str) else str(output)
        if not text:
            return
        result = self._hook.scan_output(text)
        if result.action == Action.BLOCK:
            raise FangcunBlocked(result.message or "blocked by FangcunGuard (on_tool_end)")


class AsyncFangcunCallbackHandler(AsyncCallbackHandler):
    """Async LangChain callback handler."""

    def __init__(self, hook: AsyncHookClient, *, scan_tool_output: bool = True):
        self._hook = hook
        self._scan_tool_output = scan_tool_output

    async def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List[BaseMessage]],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        flat = _flatten_message_batch(messages)
        if not flat:
            return
        result = await self._hook.scan_input(flat, stream=False)
        _apply_input_action(result.action, result.message, "on_chat_model_start")

    async def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        if not prompts:
            return
        msgs = [{"role": "user", "content": p} for p in prompts]
        result = await self._hook.scan_input(msgs, stream=False)
        _apply_input_action(result.action, result.message, "on_llm_start")

    async def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        text = _llm_result_text(response)
        if not text:
            return
        result = await self._hook.scan_output(text)
        if result.action == Action.BLOCK:
            raise FangcunBlocked(result.message or "blocked by FangcunGuard (on_llm_end)")

    async def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        if not self._scan_tool_output:
            return
        text = output if isinstance(output, str) else str(output)
        if not text:
            return
        result = await self._hook.scan_output(text)
        if result.action == Action.BLOCK:
            raise FangcunBlocked(result.message or "blocked by FangcunGuard (on_tool_end)")


__all__ = ["FangcunCallbackHandler", "AsyncFangcunCallbackHandler"]
