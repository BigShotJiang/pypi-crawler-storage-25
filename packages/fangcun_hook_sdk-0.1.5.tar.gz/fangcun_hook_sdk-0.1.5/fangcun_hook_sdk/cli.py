"""`fangcun` command-line installer for agent-app native hooks.

Usage:

    fangcun install --agent claude-code --api-key sk-xxai-...
    fangcun install --all --api-key sk-xxai-...
    fangcun status
    fangcun remove --agent claude-code
    fangcun verify --api-key sk-xxai-...

Available agents: claude-code, codex-cli, cursor, gemini-cli, openclaw.

The SDK adapters (LangChain / LlamaIndex / OpenAI / Anthropic / LiteLLM /
AutoGen / CrewAI / OpenAI Agents) are NOT managed by this CLI — those are
imported directly into your code, so there's nothing to install separately.
"""
from __future__ import annotations

import argparse
import json
import sys
import urllib.error
import urllib.request
from typing import Any, Dict, List, Optional

from .installer import REGISTRY, AgentInstaller, InstallResult, InstallStatus


_DEFAULT_HOOK_URL = "http://localhost:5002"


def _all_agents() -> List[str]:
    return sorted(REGISTRY.keys())


def _resolve_targets(agent: Optional[str], all_flag: bool) -> List[AgentInstaller]:
    if all_flag:
        return [cls() for cls in REGISTRY.values()]
    if agent and agent in REGISTRY:
        return [REGISTRY[agent]()]
    raise SystemExit(
        f"--agent must be one of {_all_agents()} or use --all"
    )


def _print_result(label: str, result: InstallResult) -> None:
    head = "[OK]" if result.success else "[FAIL]"
    print(f"  {head} {label}: {'OK' if result.success else 'FAILED'}")
    for a in result.actions:
        print(f"      - {a}")
    for w in result.warnings:
        print(f"      ! {w}")
    for e in result.errors:
        print(f"      x {e}")


def _print_status(status: InstallStatus) -> None:
    detect_mark = "[FOUND]" if status.detected else "[----]"
    install_mark = "[ON]" if status.fangcun_installed else "[--]"
    print(f"  {detect_mark} {status.agent_name:18} install={install_mark}  "
          f"hook_url={status.hook_url or '(unset)'}")
    if status.config_path:
        print(f"      config: {status.config_path}")
    if status.script_path:
        print(f"      script: {status.script_path}")
    for n in status.notes:
        print(f"      note: {n}")


# ============================================================
# Commands
# ============================================================


def cmd_install(args: argparse.Namespace) -> int:
    if args.project:
        return _cmd_install_project(args)

    targets = _resolve_targets(args.agent, args.all)
    print(f"[fangcun] Installing FangcunGuard for {len(targets)} agent(s)")
    print(f"[fangcun] hook_url: {args.hook_url}")
    print()

    overall_ok = True
    for inst in targets:
        det = inst.detect()
        if not det.found and not args.force:
            print(f"  · {inst.display_name}: not detected on this machine, skipping")
            for n in det.notes:
                print(f"      note: {n}")
            print(f"      (use --force to install anyway)")
            continue
        if not det.found and args.force:
            print(f"  ! {inst.display_name}: not detected, but --force was set")
        result = inst.install(api_key=args.api_key, hook_url=args.hook_url, fail_open=not args.fail_closed)
        _print_result(inst.display_name, result)
        if not result.success:
            overall_ok = False
        print()

    print("[fangcun] Done.")
    if overall_ok and any(inst.detect().found for inst in targets):
        print("[fangcun] Restart each agent for the changes to take effect.")
    return 0 if overall_ok else 1


def _cmd_install_project(args: argparse.Namespace) -> int:
    """Project-mode install: scan a project dir, do agents + framework patches."""
    from pathlib import Path
    from .installer.project import ProjectInstaller, render_unified_diff

    root = Path(args.project).expanduser().resolve()
    print(f"[fangcun] Project install: {root}")
    print(f"[fangcun] hook_url: {args.hook_url}")
    print(f"[fangcun] mode:     {'WRITE (will edit files)' if args.write else 'DRY-RUN (preview only)'}")
    print()

    inst = ProjectInstaller(
        project_root=root,
        api_key=args.api_key,
        hook_url=args.hook_url,
        fail_open=not args.fail_closed,
    )
    try:
        report = inst.run(apply=True, write=args.write, force=args.force)
    except NotADirectoryError as e:
        print(f"[fangcun] {e}")
        return 2

    # ── Agent half ────────────────────────────────────────────
    print("=" * 60)
    print("Agent installs (machine-level — these write to ~/.<agent>/)")
    print("=" * 60)
    any_agent_action = False
    for ar in report.agent_results:
        if ar.skipped_reason:
            print(f"  · {ar.agent_name}: skipped ({ar.skipped_reason})")
            continue
        if ar.install_result is None:
            continue
        any_agent_action = True
        _print_result(ar.agent_name, ar.install_result)
    if not any_agent_action:
        print("  (no native agent CLIs found on this machine)")
    print()

    # ── Framework half ────────────────────────────────────────
    print("=" * 60)
    print("Framework patches (project-level — read your source)")
    print("=" * 60)
    any_framework_change = False
    for fr in report.framework_results:
        if not fr.detection.found:
            print(f"  · {fr.framework_name}: not detected in this project")
            continue
        print(f"  ✓ {fr.framework_name}: detected")
        for ev in fr.detection.requirements_evidence[:3]:
            print(f"      requirements: {ev}")
        for ev in fr.detection.import_evidence[:3]:
            print(f"      import:       {ev}")
        for err in fr.errors:
            print(f"      ! error: {err}")
        if fr.manual_instructions:
            print()
            print(fr.manual_instructions)
            continue
        for plan in fr.patches:
            if plan.is_noop:
                if plan.skipped_reason:
                    print(f"      · {plan.file}: skipped — {plan.skipped_reason}")
                continue
            any_framework_change = True
            print(f"      → {plan.file} ({plan.call_sites_modified} call site(s))")
            print()
            print(render_unified_diff(plan))
        print()

    # ── Summary ───────────────────────────────────────────────
    print("=" * 60)
    if report.write_applied and any_framework_change:
        print("[fangcun] Files written. Backups: <name>.py.bak next to each touched file.")
    elif any_framework_change:
        print("[fangcun] Diff above is preview only. Re-run with --write to apply.")
    else:
        print("[fangcun] No framework changes proposed.")
    print(f"[fangcun] Done. (api_key {report.api_key_hint})")
    return 0 if report.overall_ok else 1


def cmd_status(_args: argparse.Namespace) -> int:
    print(f"[fangcun] Status across {len(REGISTRY)} agents")
    print()
    for cls in REGISTRY.values():
        _print_status(cls().status())
    return 0


def cmd_remove(args: argparse.Namespace) -> int:
    targets = _resolve_targets(args.agent, args.all)
    print(f"[fangcun] Removing FangcunGuard from {len(targets)} agent(s)")
    print()
    overall_ok = True
    for inst in targets:
        result = inst.uninstall()
        _print_result(inst.display_name, result)
        if not result.success:
            overall_ok = False
        print()
    return 0 if overall_ok else 1


def cmd_verify(args: argparse.Namespace) -> int:
    """Hit the hook server's scan-input endpoint to verify the API key works."""
    url = args.hook_url.rstrip("/") + "/v1/hook/scan-input"
    payload = {"messages": [{"role": "user", "content": "fangcun verify"}], "stream": False}
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {args.api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=args.timeout) as r:
            body = r.read().decode("utf-8")
            print(f"[fangcun] Hook server reachable at {args.hook_url}")
            print(f"[fangcun] Response status: {r.status}")
            try:
                parsed = json.loads(body)
                print(f"[fangcun] Action: {parsed.get('action')}")
            except Exception:
                print(f"[fangcun] Response body: {body[:200]}")
            return 0
    except urllib.error.HTTPError as e:
        print(f"[fangcun] Hook server returned HTTP {e.code}: {e.reason}")
        try:
            print(f"[fangcun] Body: {e.read().decode('utf-8')[:500]}")
        except Exception:
            pass
        return 1
    except urllib.error.URLError as e:
        print(f"[fangcun] Cannot reach {args.hook_url}: {e.reason}")
        return 1


# ============================================================
# Argparse plumbing
# ============================================================


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="fangcun",
        description="Deploy FangcunGuard onto agent-app native hook systems.",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    install = sub.add_parser("install", help="Install FangcunGuard onto an agent")
    install.add_argument("--agent", choices=_all_agents(), help="Which agent to install for")
    install.add_argument("--all", action="store_true", help="Install onto every detected agent")
    install.add_argument(
        "--project",
        type=str,
        default=None,
        help="Path to a Python project. Combines --all (machine-level agent install) "
             "with framework patching: scans the project for LangChain etc. and emits "
             "a unified diff. Add --write to actually edit user files.",
    )
    install.add_argument("--write", action="store_true",
                         help="With --project: apply the framework patches in place "
                              "(creates `<file>.py.bak` next to each touched file). "
                              "Without --write, --project only previews the diff.")
    install.add_argument("--api-key", required=True, help="Your FangcunGuard application key (sk-xxai-...)")
    install.add_argument("--hook-url", default=_DEFAULT_HOOK_URL, help=f"FangcunGuard hook server URL (default {_DEFAULT_HOOK_URL})")
    install.add_argument("--fail-closed", action="store_true", help="On hook server error, BLOCK instead of pass-through")
    install.add_argument("--force", action="store_true", help="Install even if the agent isn't detected on PATH / config dir")
    install.set_defaults(func=cmd_install)

    status = sub.add_parser("status", help="Show install state for every agent")
    status.set_defaults(func=cmd_status)

    remove = sub.add_parser("remove", help="Uninstall FangcunGuard from an agent")
    remove.add_argument("--agent", choices=_all_agents(), help="Which agent to uninstall from")
    remove.add_argument("--all", action="store_true", help="Uninstall from every agent")
    remove.set_defaults(func=cmd_remove)

    verify = sub.add_parser("verify", help="Probe the hook server with your API key")
    verify.add_argument("--api-key", required=True)
    verify.add_argument("--hook-url", default=_DEFAULT_HOOK_URL)
    verify.add_argument("--timeout", type=float, default=10.0)
    verify.set_defaults(func=cmd_verify)

    return parser


def main(argv: Optional[List[str]] = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
