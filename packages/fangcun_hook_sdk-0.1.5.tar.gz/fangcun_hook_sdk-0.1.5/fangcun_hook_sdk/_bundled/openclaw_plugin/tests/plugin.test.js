// Run with: node --test tests/plugin.test.js
// Requires `npm run build` first (and the _ts-core sibling built too).

const test = require("node:test");
const assert = require("node:assert/strict");
const http = require("node:http");
const setup = require("../dist/index.js").default;

function startFakeServer(actions) {
  let i = 0;
  const server = http.createServer((req, res) => {
    let body = "";
    req.on("data", (c) => (body += c));
    req.on("end", () => {
      const action = actions[i % actions.length];
      i++;
      const payload = { action, request_id: `f-${i}`, detection_result: {} };
      if (action === "block") payload.message = "blocked-by-test";
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify(payload));
    });
  });
  return new Promise((r) => server.listen(0, "127.0.0.1", () => r(server)));
}

function buildApi(cfg) {
  const handlers = new Map();
  return {
    handlers,
    api: {
      on: (event, cb) => handlers.set(event, cb),
      logger: { info: () => {}, warn: () => {}, error: () => {} },
      config: cfg,
    },
  };
}

test("registers all four event handlers when enabled", async () => {
  const srv = await startFakeServer(["pass"]);
  const port = srv.address().port;
  const { api, handlers } = buildApi({
    enabled: true,
    apiKey: "sk-xxai-test",
    hookUrl: `http://127.0.0.1:${port}`,
  });
  setup(api);
  assert.ok(handlers.has("message_received"));
  assert.ok(handlers.has("before_agent_start"));
  assert.ok(handlers.has("before_tool_call"));
  assert.ok(handlers.has("after_tool_call"));
  srv.close();
});

test("blocks on message_received when server returns block", async () => {
  const srv = await startFakeServer(["block"]);
  const port = srv.address().port;
  const { api, handlers } = buildApi({
    enabled: true,
    apiKey: "sk-xxai-test",
    hookUrl: `http://127.0.0.1:${port}`,
  });
  setup(api);
  const result = await handlers.get("message_received")({ content: "danger" }, {});
  assert.equal(result.block, true);
  assert.equal(result.blockReason, "blocked-by-test");
  srv.close();
});

test("passes when server returns pass", async () => {
  const srv = await startFakeServer(["pass"]);
  const port = srv.address().port;
  const { api, handlers } = buildApi({
    enabled: true,
    apiKey: "sk-xxai-test",
    hookUrl: `http://127.0.0.1:${port}`,
  });
  setup(api);
  const result = await handlers.get("before_tool_call")(
    { toolName: "Bash", params: { cmd: "ls" } },
    {},
  );
  assert.equal(result, undefined);
  srv.close();
});

test("inactive when no apiKey", () => {
  const { api, handlers } = buildApi({ enabled: true });
  delete process.env.FANGCUN_API_KEY;
  setup(api);
  assert.equal(handlers.size, 0);
});
