// TypeScript port of sdk/python/fangcun_hook_sdk/types.py.
// Keep enum string values in sync with the Python side — the hook server
// returns these literal strings.

export enum Action {
  PASS = "pass",
  BLOCK = "block",
  REPLACE = "replace",
  ANONYMIZE = "anonymize",
  RESTORE = "restore",
  SWITCH_PRIVATE_MODEL = "switch_private_model",
  UNKNOWN = "unknown",
}

export function actionFromString(value: string | undefined): Action {
  if (!value) return Action.UNKNOWN;
  const known = Object.values(Action) as string[];
  return known.includes(value) ? (value as Action) : Action.UNKNOWN;
}

export interface Message {
  role: string;
  content: string;
  [key: string]: unknown;
}

export interface PrivateModel {
  endpoint?: string;
  model?: string;
  [key: string]: unknown;
}

export interface DetectionResult {
  overall_risk_level?: string;
  matched_scanners?: string[];
  [key: string]: unknown;
}

export interface ScanResult {
  action: Action;
  requestId?: string;
  message?: string;
  content?: string;
  anonymizedMessages?: Message[];
  sessionId?: string;
  restoreMapping?: Record<string, string>;
  detectionResult: DetectionResult;
  privateModel?: PrivateModel;
  processingTimeMs?: number;
  raw: Record<string, unknown>;
}

export function scanResultFromResponse(data: Record<string, unknown>): ScanResult {
  const action = actionFromString(data["action"] as string | undefined);
  const message =
    (data["message"] as string | undefined) ??
    (data["suggest_answer"] as string | undefined) ??
    (data["reason"] as string | undefined);
  return {
    action,
    requestId: data["request_id"] as string | undefined,
    message,
    content: data["content"] as string | undefined,
    anonymizedMessages: data["anonymized_messages"] as Message[] | undefined,
    sessionId: data["session_id"] as string | undefined,
    restoreMapping: data["restore_mapping"] as Record<string, string> | undefined,
    detectionResult: (data["detection_result"] as DetectionResult) ?? {},
    privateModel: data["private_model"] as PrivateModel | undefined,
    processingTimeMs: data["processing_time_ms"] as number | undefined,
    raw: data,
  };
}

export class FangcunBlocked extends Error {
  result?: ScanResult;
  constructor(message: string, result?: ScanResult) {
    super(message);
    this.name = "FangcunBlocked";
    this.result = result;
  }
}

export class FangcunReplaced extends Error {
  result?: ScanResult;
  constructor(message: string, result?: ScanResult) {
    super(message);
    this.name = "FangcunReplaced";
    this.result = result;
  }
}
