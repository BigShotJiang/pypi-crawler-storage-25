// TypeScript port of sdk/python/fangcun_hook_sdk/core.py.
// Uses the Node 18+ global `fetch` — no extra HTTP dependency.

import {
  Action,
  Message,
  ScanResult,
  scanResultFromResponse,
} from "./types.js";

export interface HookClientOptions {
  baseUrl: string;
  apiKey: string;
  timeoutMs?: number;
  failOpen?: boolean;
  primaryPath?: string;
  fetch?: typeof fetch;
}

export interface ScanInputOptions {
  stream?: boolean;
  clientIp?: string;
  userId?: string;
}

export interface ScanOutputOptions {
  restoreMapping?: Record<string, string>;
  sessionId?: string;
  isStreaming?: boolean;
  chunkIndex?: number;
  messages?: Message[];
}

const DEFAULT_TIMEOUT_MS = 10_000;
const USER_AGENT = "fangcun-hook-sdk-ts/0.1";

export class HookClient {
  private readonly baseUrl: string;
  private readonly apiKey: string;
  private readonly timeoutMs: number;
  private readonly failOpen: boolean;
  private readonly primaryPath: string;
  private readonly fetchImpl: typeof fetch;

  constructor(opts: HookClientOptions) {
    if (!opts.baseUrl) throw new Error("baseUrl is required");
    if (!opts.apiKey) throw new Error("apiKey is required");
    this.baseUrl = opts.baseUrl.replace(/\/+$/, "");
    this.apiKey = opts.apiKey;
    this.timeoutMs = opts.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    this.failOpen = opts.failOpen ?? true;
    this.primaryPath = (opts.primaryPath ?? "/v1/hook").replace(/\/+$/, "");
    this.fetchImpl = opts.fetch ?? fetch;
  }

  private headers(): Record<string, string> {
    return {
      Authorization: `Bearer ${this.apiKey}`,
      "Content-Type": "application/json",
      "User-Agent": USER_AGENT,
    };
  }

  private url(action: "input" | "output"): string {
    const usingHook = this.primaryPath.endsWith("/hook");
    const slug = usingHook
      ? action === "input"
        ? "scan-input"
        : "scan-output"
      : action === "input"
      ? "process-input"
      : "process-output";
    return `${this.baseUrl}${this.primaryPath}/${slug}`;
  }

  private failOpenResult(action: "scan_input" | "scan_output", err: unknown): ScanResult {
    if (this.failOpen) {
      return {
        action: Action.PASS,
        detectionResult: { error: String(err), fail_open: true } as Record<string, unknown>,
        raw: { error: String(err) },
      };
    }
    throw err instanceof Error ? err : new Error(String(err));
  }

  private async post(
    url: string,
    payload: Record<string, unknown>,
  ): Promise<Record<string, unknown>> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const r = await this.fetchImpl(url, {
        method: "POST",
        headers: this.headers(),
        body: JSON.stringify(payload),
        signal: controller.signal,
      });
      if (!r.ok) {
        throw new Error(`hook server returned ${r.status} ${r.statusText}`);
      }
      return (await r.json()) as Record<string, unknown>;
    } finally {
      clearTimeout(timer);
    }
  }

  async scanInput(messages: Message[], opts: ScanInputOptions = {}): Promise<ScanResult> {
    const payload: Record<string, unknown> = {
      messages,
      stream: opts.stream ?? false,
    };
    if (opts.clientIp) payload["client_ip"] = opts.clientIp;
    if (opts.userId) payload["user_id"] = opts.userId;
    try {
      const data = await this.post(this.url("input"), payload);
      return scanResultFromResponse(data);
    } catch (e) {
      return this.failOpenResult("scan_input", e);
    }
  }

  async scanOutput(content: string, opts: ScanOutputOptions = {}): Promise<ScanResult> {
    const payload: Record<string, unknown> = {
      content,
      is_streaming: opts.isStreaming ?? false,
      chunk_index: opts.chunkIndex ?? 0,
    };
    if (opts.restoreMapping) payload["restore_mapping"] = opts.restoreMapping;
    if (opts.sessionId) payload["session_id"] = opts.sessionId;
    if (opts.messages) payload["messages"] = opts.messages;
    try {
      const data = await this.post(this.url("output"), payload);
      return scanResultFromResponse(data);
    } catch (e) {
      return this.failOpenResult("scan_output", e);
    }
  }
}
