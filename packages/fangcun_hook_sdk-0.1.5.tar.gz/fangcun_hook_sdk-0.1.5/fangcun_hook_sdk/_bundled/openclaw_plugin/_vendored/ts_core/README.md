# @fangcun/hook-core

Shared TypeScript client for the FangcunGuard Hook server. Used by
[`@fangcun/openclaw-plugin`](../openclaw-plugin) and
[`@fangcun/geminicli-plugin`](../geminicli-plugin); also usable directly
from any Node 18+ TS/JS project.

Mirrors `sdk/python/fangcun_hook_sdk/{core,types}.py` line-for-line so the
two language SDKs stay in sync against the same hook server contract.

## Install

```bash
npm install @fangcun/hook-core
```

## Usage

```ts
import { HookClient, Action } from "@fangcun/hook-core";

const hook = new HookClient({
  baseUrl: "http://localhost:5002",
  apiKey: process.env.FANGCUN_API_KEY!,
});

const result = await hook.scanInput([
  { role: "user", content: "My email is john@example.com" },
]);

if (result.action === Action.BLOCK) {
  throw new Error(result.message ?? "blocked by FangcunGuard");
}
```

## Build

```bash
npm install
npm run build
```

## Test

```bash
npm test
```
