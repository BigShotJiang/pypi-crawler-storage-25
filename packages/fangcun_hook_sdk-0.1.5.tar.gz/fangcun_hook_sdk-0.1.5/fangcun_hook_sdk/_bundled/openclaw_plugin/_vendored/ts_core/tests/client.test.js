// Run with: node --test tests/client.test.js
// Builds against the compiled JS in dist/ — run `npm run build` first.

const test = require("node:test");
const assert = require("node:assert/strict");
const http = require("node:http");
const { HookClient, Action } = require("../dist/index.js");

function startFakeServer(actions) {
  let i = 0;
  const server = http.createServer((req, res) => {
    let body = "";
    req.on("data", (chunk) => (body += chunk));
    req.on("end", () => {
      const action = actions[i % actions.length];
      i++;
      const payload = {
        action,
        request_id: `fake-${i}`,
        detection_result: { overall_risk_level: action === "pass" ? "no_risk" : "high_risk" },
      };
      if (action === "block") payload.message = "blocked";
      if (action === "replace") payload.message = "[replaced]";
      if (action === "anonymize") {
        payload.anonymized_messages = [{ role: "user", content: "[anon]" }];
        payload.restore_mapping = { __anon_1__: "real" };
      }
      if (action === "restore") payload.content = "restored text";
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify(payload));
    });
  });
  return new Promise((resolve) => {
    server.listen(0, "127.0.0.1", () => resolve(server));
  });
}

test("scanInput PASS", async () => {
  const srv = await startFakeServer(["pass"]);
  const port = srv.address().port;
  const client = new HookClient({ baseUrl: `http://127.0.0.1:${port}`, apiKey: "sk-xxai-test" });
  const r = await client.scanInput([{ role: "user", content: "hi" }]);
  assert.equal(r.action, Action.PASS);
  srv.close();
});

test("scanInput BLOCK surfaces message", async () => {
  const srv = await startFakeServer(["block"]);
  const port = srv.address().port;
  const client = new HookClient({ baseUrl: `http://127.0.0.1:${port}`, apiKey: "sk-xxai-test" });
  const r = await client.scanInput([{ role: "user", content: "hi" }]);
  assert.equal(r.action, Action.BLOCK);
  assert.equal(r.message, "blocked");
  srv.close();
});

test("scanInput ANONYMIZE returns mapping", async () => {
  const srv = await startFakeServer(["anonymize"]);
  const port = srv.address().port;
  const client = new HookClient({ baseUrl: `http://127.0.0.1:${port}`, apiKey: "sk-xxai-test" });
  const r = await client.scanInput([{ role: "user", content: "hi" }]);
  assert.equal(r.action, Action.ANONYMIZE);
  assert.deepEqual(r.restoreMapping, { __anon_1__: "real" });
  srv.close();
});

test("scanOutput RESTORE returns content", async () => {
  const srv = await startFakeServer(["restore"]);
  const port = srv.address().port;
  const client = new HookClient({ baseUrl: `http://127.0.0.1:${port}`, apiKey: "sk-xxai-test" });
  const r = await client.scanOutput("payload");
  assert.equal(r.action, Action.RESTORE);
  assert.equal(r.content, "restored text");
  srv.close();
});

test("fail-open returns PASS on server error", async () => {
  const client = new HookClient({
    baseUrl: "http://127.0.0.1:1",
    apiKey: "sk-xxai-test",
    timeoutMs: 200,
  });
  const r = await client.scanInput([{ role: "user", content: "hi" }]);
  assert.equal(r.action, Action.PASS);
});
