# @fangcun/openclaw-plugin

FangcunGuard native plugin for [OpenClaw](https://github.com/openclaw).
Hooks into OpenClaw's plugin events to scan input messages, tool calls, and
tool results through the FangcunGuard Hook server. Conceptually parallel to
[openclaw-lynx-guardian](https://github.com/shouxuai/openclaw-lynx-guardian)
— same form factor, different scanner backend.

## One-line install

```bash
pip install fangcun-hook-sdk
fangcun install --agent openclaw --api-key sk-xxai-...
# Restart OpenClaw.
```

The CLI tries `openclaw plugins install @fangcun/openclaw-plugin` (when the
package is published to npm), falls back to printing manual `cp -r`
instructions if that fails, and writes the plugin enable flag + apiKey
into `~/.openclaw/openclaw.json`.

## Manual install (if not on npm yet, or no `openclaw` binary)

```bash
git clone https://github.com/<org>/FangcunGuard-Hook.git
cd FangcunGuard-Hook/integrations/openclaw-plugin
npm install
npm run build
cp -r . /path/to/openclaw/extensions/openclaw-plugin
```

Then enable in `~/.openclaw/openclaw.json`:

```json
{
  "plugins": {
    "entries": {
      "fangcun-openclaw-guardian": { "enabled": true }
    }
  },
  "fangcun-openclaw-guardian": {
    "hookUrl": "http://localhost:5002",
    "apiKey": "sk-xxai-..."
  }
}
```

(Or set `FANGCUN_API_KEY` env if you prefer.)

## Coverage

| Event hooked | What gets scanned |
|---|---|
| `message_received` | inbound user message text |
| `before_agent_start` | the assembled prompt + message history before the agent runs |
| `before_tool_call` | tool name + params (treated as input) |
| `after_tool_call` | tool result (treated as output) |

**Cannot see**:
- The system prompt OpenClaw constructs internally (no event for it)
- The full LLM request body OpenClaw sends to the model vendor

For full LLM-request visibility use the Python in-process SDK or
`@fangcun/geminicli-plugin`.

## Action mapping

| Server action | OpenClaw effect |
|---|---|
| `pass` | request continues |
| `block` | `{ block: true, blockReason }` — OpenClaw shows the reason and aborts |
| `replace` | downgraded to block with the replacement text as reason |
| `anonymize` | downgraded to block (OpenClaw hooks cannot rewrite payloads in-flight) |
| `switch_private_model` | not supported here; treated as pass |

## Verify

```bash
fangcun verify --api-key sk-xxai-...
```

## Build (development)

```bash
npm install
npm run build
npm test
```
