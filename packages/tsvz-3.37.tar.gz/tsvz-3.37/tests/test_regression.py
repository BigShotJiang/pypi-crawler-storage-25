import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import TSVZ


class TestTSVZRegressions(unittest.TestCase):
    def test_append_and_read_preserves_embedded_tab_and_newline(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = os.path.join(temp_dir, "embedded.tsv")
            header = ["key", "payload"]
            row = ["row1", "hello\tworld\nline2"]

            TSVZ.appendTabularFile(
                path,
                row,
                header=header,
                createIfNotExist=True,
                verifyHeader=True,
                strict=True,
                delimiter="\t",
            )

            data = TSVZ.readTabularFile(
                path,
                header=header,
                verifyHeader=True,
                strict=True,
                delimiter="\t",
            )

            self.assertIn("row1", data)
            self.assertEqual(data["row1"], row)

    def test_read_uses_defaults_row_for_missing_values(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = os.path.join(temp_dir, "defaults.tsv")
            with open(path, "w", encoding="utf8") as handle:
                handle.write("key\tcpu\tmem\n")
                handle.write(f"{TSVZ.DEFAULTS_INDICATOR_KEY}\t4\t8G\n")
                handle.write("job1\t2\t16G\n")
                handle.write("job2\t\t32G\n")

            data = TSVZ.readTabularFile(
                path,
                header=["key", "cpu", "mem"],
                verifyHeader=True,
                strict=True,
                delimiter="\t",
            )

            self.assertEqual(data["job1"], ["job1", "2", "16G"])
            self.assertEqual(data["job2"], ["job2", "4", "32G"])

    def test_last_line_only_ignores_delete_marker_line(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = os.path.join(temp_dir, "lastline.tsv")
            with open(path, "w", encoding="utf8") as handle:
                handle.write("key\tvalue\n")
                handle.write("alive\t42\n")
                handle.write("alive\n")

            last_valid = TSVZ.readTabularFile(
                path,
                header=["key", "value"],
                verifyHeader=True,
                lastLineOnly=True,
                strict=False,
                delimiter="\t",
            )

            self.assertEqual(last_valid, ["alive", "42"])

    def test_append_and_read_gzip_file(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = os.path.join(temp_dir, "compressed.tsv.gz")
            header = ["key", "value"]

            TSVZ.appendTabularFile(
                path,
                ["gk", "gv"],
                header=header,
                createIfNotExist=True,
                verifyHeader=True,
                strict=True,
                delimiter="\t",
            )

            data = TSVZ.readTabularFile(
                path,
                header=header,
                verifyHeader=True,
                strict=True,
                delimiter="\t",
            )

            self.assertEqual(data["gk"], ["gk", "gv"])


if __name__ == "__main__":
    unittest.main()
