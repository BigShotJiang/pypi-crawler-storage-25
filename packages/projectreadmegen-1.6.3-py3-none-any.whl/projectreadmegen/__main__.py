import sys

if len(sys.argv) > 1:
    from projectreadmegen.cli import app
    app()
else:
    from projectreadmegen.cli import main_menu_loop
    main_menu_loop()
