from __future__ import annotations

from wexample_wex_addon_app.service.app_service import AppService as BaseAppService


class AppService(BaseAppService):
    def get_workdir_contribution(self) -> dict:
        from wexample_filestate.const.disk import DiskItemType

        return {
            "children": [
                {
                    "name": "logs",
                    "type": DiskItemType.DIRECTORY,
                    "should_exist": True,
                    "mode": {
                        "owner": "999:999",
                        "permissions": "750",
                        "recursive": True,
                    },
                },
                {
                    "name": "mongo-keyfile",
                    "type": DiskItemType.FILE,
                    "should_exist": True,
                    "mode": {
                        "owner": "999:999",
                        "permissions": "400",
                    },
                },
            ]
        }
