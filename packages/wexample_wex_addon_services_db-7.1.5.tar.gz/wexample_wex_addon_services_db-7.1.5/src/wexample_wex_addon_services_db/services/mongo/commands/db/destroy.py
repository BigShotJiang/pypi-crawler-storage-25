from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command
from wexample_wex_core.decorator.option import option

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@option(
    name="database",
    short_name="d",
    type=str,
    required=False,
    description="Database name (defaults to db.main from runtime config)",
)
@option(
    name="recreate",
    short_name="r",
    type=bool,
    required=False,
    default=True,
    description="Recreate a minimal database scaffold after drop",
)
@command(
    type=COMMAND_TYPE_SERVICE,
    description="Drop and optionally recreate the mongo database",
)
def mongo__db__destroy(
    context: ExecutionContext,
    service: AppService,
    database: str | None = None,
    recreate: bool = True,
) -> None:
    import subprocess

    runtime = service.app_workdir.get_runtime_config()
    app_project_name = runtime.search("app.project_name").get_str()
    container_name = f"{app_project_name}_{service.name}"
    db_name = (
        database
        or runtime.search("db.main").get_str_or_none()
        or runtime.search("app.name").get_str()
    )

    drop_result = subprocess.run(
        [
            "docker",
            "exec",
            container_name,
            "mongosh",
            "--quiet",
            "--eval",
            f'db.getSiblingDB("{db_name}").dropDatabase().ok',
        ],
        capture_output=True,
        text=True,
    )
    if drop_result.returncode != 0:
        raise RuntimeError(f"mongo db/destroy failed:\n{drop_result.stderr}")

    if recreate:
        recreate_result = subprocess.run(
            [
                "docker",
                "exec",
                container_name,
                "mongosh",
                "--quiet",
                "--eval",
                f'db = db.getSiblingDB("{db_name}"); db.createCollection("__wex_init")',
            ],
            capture_output=True,
            text=True,
        )
        if recreate_result.returncode != 0:
            raise RuntimeError(f"mongo db/recreate failed:\n{recreate_result.stderr}")

    context.io.log(f'Mongo database "{db_name}" reset')
