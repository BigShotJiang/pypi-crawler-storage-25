from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command
from wexample_wex_core.decorator.option import option

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@option(
    name="file_name",
    short_name="f",
    type=str,
    required=True,
    description="Dump directory name to restore from /var/www/dumps/",
)
@option(
    name="database",
    short_name="d",
    type=str,
    required=False,
    description="Database name (unused, reserved for future multi-db support)",
)
@command(type=COMMAND_TYPE_SERVICE, description="Restore a mongo dump directory")
def mongo__db__restore(
    context: ExecutionContext,
    service: AppService,
    file_name: str,
    database: str | None = None,
) -> str:
    import subprocess

    from wexample_app.const.globals import WORKDIR_SETUP_DIR

    runtime = service.app_workdir.get_runtime_config()
    app_project_name = runtime.search("app.project_name").get_str()
    container_name = f"{app_project_name}_{service.name}"

    result = subprocess.run(
        [
            "docker",
            "exec",
            container_name,
            "mongorestore",
            "--drop",
            f"/var/www/dumps/{file_name}",
        ],
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        raise RuntimeError(f"mongorestore failed:\n{result.stderr}")

    return str(
        service.app_workdir.get_path()
        / WORKDIR_SETUP_DIR
        / service.name
        / "dumps"
        / file_name
    )
