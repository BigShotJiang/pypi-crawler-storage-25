from __future__ import annotations

from wexample_wex_addon_app.service.app_service import AppService as BaseAppService


class AppService(BaseAppService):
    def get_workdir_contribution(self) -> dict:
        from wexample_filestate.const.disk import DiskItemType

        # Elasticsearch container runs as uid 1000 (elasticsearch user)
        es_mode = {"owner": "1000:1000", "permissions": "750", "recursive": True}

        return {
            "children": [
                {
                    "name": "elasticsearch",
                    "type": DiskItemType.DIRECTORY,
                    "should_exist": True,
                    "children": [
                        {
                            "name": "data",
                            "type": DiskItemType.DIRECTORY,
                            "should_exist": True,
                            "mode": es_mode,
                        },
                    ],
                },
            ]
        }
