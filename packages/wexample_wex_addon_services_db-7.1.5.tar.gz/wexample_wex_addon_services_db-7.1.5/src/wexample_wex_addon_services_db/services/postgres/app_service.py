from __future__ import annotations

from wexample_wex_addon_app.service.app_service import AppService as BaseAppService


class AppService(BaseAppService):
    def get_workdir_contribution(self) -> dict:
        from wexample_app.const.globals import WORKDIR_SETUP_DIR
        from wexample_filestate.const.disk import DiskItemType

        return {
            "children": [
                {
                    "name": WORKDIR_SETUP_DIR,
                    "type": DiskItemType.DIRECTORY,
                    "children": [
                        {
                            "name": "postgres",
                            "type": DiskItemType.DIRECTORY,
                            "children": [
                                {
                                    "name": "logs",
                                    "type": DiskItemType.DIRECTORY,
                                    "should_exist": True,
                                    "mode": {
                                        "owner": "999:999",
                                        "permissions": "750",
                                        "recursive": True,
                                    },
                                },
                            ],
                        }
                    ],
                }
            ]
        }
