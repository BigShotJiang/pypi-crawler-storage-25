from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command

if TYPE_CHECKING:
    from wexample_app.response.boolean_response import BooleanResponse
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@command(type=COMMAND_TYPE_SERVICE, description="Check if postgres service is ready")
def postgres__service__ready(
    context: ExecutionContext,
    service: AppService,
) -> BooleanResponse:
    import subprocess

    from wexample_app.response.boolean_response import BooleanResponse

    runtime = service.app_workdir.get_runtime_config()
    app_project_name = runtime.search("app.project_name").get_str()
    container_name = f"{app_project_name}_{service.name}"
    user = runtime.search(f"service.{service.name}.user").get_str_or_default("postgres")
    db_name = (
        runtime.search("db.main").get_str_or_none()
        or runtime.search("app.name").get_str()
    )
    password = runtime.search(f"service.{service.name}.password").get_str_or_default("")

    result = subprocess.run(
        [
            "docker",
            "exec",
            "-e",
            f"PGPASSWORD={password}",
            container_name,
            "psql",
            "-h",
            "localhost",
            "-U",
            user,
            "-d",
            db_name,
            "--pset=pager=off",
            "-t",
            "-A",
            "-c",
            "SELECT 1",
        ],
        capture_output=True,
        text=True,
    )

    return BooleanResponse(
        kernel=context.kernel,
        content=result.returncode == 0 and result.stdout.strip() == "1",
    )
