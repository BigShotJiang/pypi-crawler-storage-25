from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command
from wexample_wex_core.decorator.option import option

if TYPE_CHECKING:
    from wexample_app.response.abstract_response import AbstractResponse
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@option(
    name="sql",
    short_name="c",
    type=str,
    required=True,
    description="SQL command to execute",
)
@option(
    name="database",
    short_name="d",
    type=str,
    required=False,
    description="Database name (defaults to db.main from runtime config)",
)
@command(type=COMMAND_TYPE_SERVICE, description="Execute a SQL command in postgres")
def postgres__db__exec(
    context: ExecutionContext,
    service: AppService,
    sql: str,
    database: str | None = None,
) -> AbstractResponse:
    from wexample_app.response.shell_command_response import ShellCommandResponse

    runtime = service.app_workdir.get_runtime_config()
    app_project_name = runtime.search("app.project_name").get_str()
    container_name = f"{app_project_name}_{service.name}"
    db_name = (
        database
        or runtime.search("db.main").get_str_or_none()
        or runtime.search("app.name").get_str()
    )
    user = runtime.search(f"service.{service.name}.user").get_str_or_default("postgres")
    password = runtime.search(f"service.{service.name}.password").get_str_or_default("")

    return ShellCommandResponse(
        kernel=context.kernel,
        content=[
            "docker",
            "exec",
            "-e",
            f"PGPASSWORD={password}",
            container_name,
            "psql",
            "-h",
            "localhost",
            "-U",
            user,
            "-d",
            db_name,
            "--pset=pager=off",
            "-t",
            "-A",
            "-c",
            sql,
        ],
    )
