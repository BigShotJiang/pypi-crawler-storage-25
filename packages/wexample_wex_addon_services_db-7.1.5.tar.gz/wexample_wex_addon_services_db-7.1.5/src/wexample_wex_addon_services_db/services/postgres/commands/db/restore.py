from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command
from wexample_wex_core.decorator.option import option

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@option(
    name="file_name",
    short_name="f",
    type=str,
    required=True,
    description="SQL dump file name (without path, must be in /var/www/dumps/)",
)
@option(
    name="database",
    short_name="d",
    type=str,
    required=False,
    description="Database name (defaults to db.main from runtime config)",
)
@command(
    type=COMMAND_TYPE_SERVICE,
    description="Restore a postgres database from a .sql dump",
)
def postgres__db__restore(
    context: ExecutionContext,
    service: AppService,
    file_name: str,
    database: str | None = None,
) -> None:
    import subprocess

    runtime = service.app_workdir.get_runtime_config()
    app_project_name = runtime.search("app.project_name").get_str()
    container_name = f"{app_project_name}_{service.name}"
    db_name = (
        database
        or runtime.search("db.main").get_str_or_none()
        or runtime.search("app.name").get_str()
    )
    user = runtime.search(f"service.{service.name}.user").get_str_or_default("postgres")
    password = runtime.search(f"service.{service.name}.password").get_str_or_default("")

    result = subprocess.run(
        [
            "docker",
            "exec",
            "-e",
            f"PGPASSWORD={password}",
            container_name,
            "sh",
            "-lc",
            f'psql -h localhost -U "{user}" -d "{db_name}" < "/var/www/dumps/{file_name}"',
        ],
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        raise RuntimeError(f"postgres db/restore failed:\n{result.stderr}")
