from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@command(type=COMMAND_TYPE_SERVICE, description="Write postgres runtime configuration")
def postgres__config__runtime(
    context: ExecutionContext,
    service: AppService,
) -> None:
    from wexample_config.config_value.nested_config_value import NestedConfigValue
    from wexample_helpers.helpers.dict import dict_merge

    config = service.app_workdir.get_config()
    db_name = config.search(f"service.{service.name}.name").get_str_or_default(
        service.name
    )

    base = service.app_workdir.build_runtime_config_value().to_dict()
    merged = dict_merge(base, {"db": {"main": db_name}})
    service.app_workdir.get_runtime_config_file().write_config(
        NestedConfigValue(raw=merged)
    )

    context.io.log(f"postgres config/runtime: written (db.main={db_name})")
