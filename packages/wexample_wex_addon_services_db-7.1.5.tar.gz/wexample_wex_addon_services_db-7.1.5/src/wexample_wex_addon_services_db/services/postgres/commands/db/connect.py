from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command
from wexample_wex_core.decorator.option import option

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@option(
    name="protocol",
    short_name="p",
    type=str,
    required=False,
    default="postgresql",
    description="Connection protocol",
)
@option(
    name="database",
    short_name="d",
    type=str,
    required=False,
    description="Database name",
)
@command(type=COMMAND_TYPE_SERVICE, description="Return postgres connection string")
def postgres__db__connect(
    context: ExecutionContext,
    service: AppService,
    protocol: str = "postgresql",
    database: str | None = None,
) -> str:
    runtime = service.app_workdir.get_runtime_config()
    user = runtime.search(f"service.{service.name}.user").get_str_or_default("postgres")
    password = runtime.search(f"service.{service.name}.password").get_str_or_default("")
    db_name = (
        database
        or runtime.search("db.main").get_str_or_none()
        or runtime.search(f"service.{service.name}.name").get_str_or_default(
            service.name
        )
    )

    return f'{protocol}://{user}:"{password}"@localhost/{db_name}'
