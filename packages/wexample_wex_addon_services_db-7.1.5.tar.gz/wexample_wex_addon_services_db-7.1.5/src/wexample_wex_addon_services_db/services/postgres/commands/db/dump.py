from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command
from wexample_wex_core.decorator.option import option

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@option(
    name="file_name",
    short_name="f",
    type=str,
    required=True,
    description="Dump file name (without extension)",
)
@command(
    type=COMMAND_TYPE_SERVICE, description="Dump the postgres database to a .sql file"
)
def postgres__db__dump(
    context: ExecutionContext,
    service: AppService,
    file_name: str,
) -> str:
    import subprocess

    from wexample_app.const.globals import WORKDIR_SETUP_DIR

    runtime = service.app_workdir.get_runtime_config()
    app_project_name = runtime.search("app.project_name").get_str()
    container_name = f"{app_project_name}_{service.name}"
    db_name = (
        runtime.search("db.main").get_str_or_none()
        or runtime.search("app.name").get_str()
    )
    user = runtime.search(f"service.{service.name}.user").get_str_or_default("postgres")
    password = runtime.search(f"service.{service.name}.password").get_str_or_default("")

    sql_file = f"{file_name}.sql"
    dumps_dir = (
        service.app_workdir.get_path() / WORKDIR_SETUP_DIR / service.name / "dumps"
    )
    dumps_dir.mkdir(parents=True, exist_ok=True)

    result = subprocess.run(
        [
            "docker",
            "exec",
            "-e",
            f"PGPASSWORD={password}",
            container_name,
            "sh",
            "-lc",
            f'pg_dump -h localhost -U "{user}" "{db_name}" -f "/var/www/dumps/{sql_file}"',
        ],
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        raise RuntimeError(f"pg_dump failed:\n{result.stderr}")

    return str(dumps_dir / sql_file)
