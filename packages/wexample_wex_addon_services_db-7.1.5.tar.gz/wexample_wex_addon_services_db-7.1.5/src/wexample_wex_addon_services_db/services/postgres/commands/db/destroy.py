from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command
from wexample_wex_core.decorator.option import option

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@option(
    name="database",
    short_name="d",
    type=str,
    required=False,
    description="Database name (defaults to db.main from runtime config)",
)
@option(
    name="recreate",
    short_name="r",
    type=bool,
    required=False,
    default=True,
    description="Recreate an empty database after drop",
)
@command(
    type=COMMAND_TYPE_SERVICE,
    description="Drop and optionally recreate the postgres database",
)
def postgres__db__destroy(
    context: ExecutionContext,
    service: AppService,
    database: str | None = None,
    recreate: bool = True,
) -> None:
    import subprocess

    runtime = service.app_workdir.get_runtime_config()
    app_project_name = runtime.search("app.project_name").get_str()
    container_name = f"{app_project_name}_{service.name}"
    db_name = (
        database
        or runtime.search("db.main").get_str_or_none()
        or runtime.search("app.name").get_str()
    )
    fallback_database = "postgres"
    user = runtime.search(f"service.{service.name}.user").get_str_or_default("postgres")
    password = runtime.search(f"service.{service.name}.password").get_str_or_default("")

    def run_psql(sql: str, message: str) -> None:
        context.io.log(message)
        result = subprocess.run(
            [
                "docker",
                "exec",
                "-e",
                f"PGPASSWORD={password}",
                container_name,
                "psql",
                "-h",
                "localhost",
                "-U",
                user,
                "-d",
                fallback_database,
                "-c",
                sql,
            ],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise RuntimeError(f"postgres db/destroy failed:\n{result.stderr}")

    run_psql(
        (
            "SELECT pg_terminate_backend(pg_stat_activity.pid) "
            f"FROM pg_stat_activity WHERE pg_stat_activity.datname = '{db_name}' "
            "AND pid <> pg_backend_pid();"
        ),
        f'Terminating connections to the database "{db_name}"',
    )
    run_psql(
        f'DROP DATABASE IF EXISTS "{db_name}";', f'Dropping the database "{db_name}"'
    )

    if recreate:
        run_psql(
            f'CREATE DATABASE "{db_name}";', f'Creating an empty database "{db_name}"'
        )
