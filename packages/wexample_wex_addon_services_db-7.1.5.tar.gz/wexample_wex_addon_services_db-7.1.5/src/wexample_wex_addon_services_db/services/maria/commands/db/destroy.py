from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command
from wexample_wex_core.decorator.option import option

from wexample_wex_addon_services_db.services.mysql.commands.db.destroy import (
    mysql__db__destroy,
)

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@option(
    name="database",
    type=str,
    required=False,
    description="Database name (defaults to db.main from runtime config)",
)
@command(type=COMMAND_TYPE_SERVICE, description="Drop and recreate the maria database")
def maria__db__destroy(
    context: ExecutionContext,
    service: AppService,
    database: str | None = None,
) -> None:
    return mysql__db__destroy(context=context, service=service, database=database)
