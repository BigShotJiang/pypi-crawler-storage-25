from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command
from wexample_wex_core.decorator.option import option

from wexample_wex_addon_services_db.services.mysql.commands.db.restore import (
    mysql__db__restore,
)

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@option(
    name="file_name",
    type=str,
    required=True,
    description="SQL dump file name (without path, must be in /var/www/dumps/)",
)
@option(
    name="database",
    type=str,
    required=False,
    description="Database name (defaults to db.main from runtime config)",
)
@command(
    type=COMMAND_TYPE_SERVICE, description="Restore a maria database from a .sql dump"
)
def maria__db__restore(
    context: ExecutionContext,
    service: AppService,
    file_name: str,
    database: str | None = None,
) -> None:
    return mysql__db__restore(
        context=context,
        service=service,
        file_name=file_name,
        database=database,
    )
