from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command
from wexample_wex_core.decorator.option import option

from wexample_wex_addon_services_db.services.mysql.commands.db.exec import (
    mysql__db__exec,
)

if TYPE_CHECKING:
    from wexample_app.response.abstract_response import AbstractResponse
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@option(
    name="sql",
    type=str,
    required=True,
    description="SQL command to execute",
)
@command(type=COMMAND_TYPE_SERVICE, description="Execute a SQL command in maria")
def maria__db__exec(
    context: ExecutionContext,
    service: AppService,
    sql: str,
) -> AbstractResponse:
    return mysql__db__exec(context=context, service=service, sql=sql)
