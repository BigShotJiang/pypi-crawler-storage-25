from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command
from wexample_wex_core.decorator.option import option

from wexample_wex_addon_services_db.services.mysql.commands.db.dumps_list import (
    mysql__db__dumps_list,
)

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@option(
    name="database",
    short_name="d",
    type=str,
    required=False,
    description="Database name (unused, reserved for future multi-db support)",
)
@command(type=COMMAND_TYPE_SERVICE, description="List available maria dump files")
def maria__db__dumps_list(
    context: ExecutionContext,
    service: AppService,
    database: str | None = None,
) -> list[str]:
    return mysql__db__dumps_list(context=context, service=service, database=database)
