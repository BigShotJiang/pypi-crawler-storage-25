from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command

from wexample_wex_addon_services_db.services.mysql.commands.config.runtime import (
    mysql__config__runtime,
)

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@command(type=COMMAND_TYPE_SERVICE, description="Write maria runtime configuration")
def maria__config__runtime(
    context: ExecutionContext,
    service: AppService,
) -> None:
    return mysql__config__runtime(context=context, service=service)
