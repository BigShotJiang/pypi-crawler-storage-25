from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command

from wexample_wex_addon_services_db.services.mysql.commands.db.connect import (
    mysql__db__connect,
)

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@command(
    type=COMMAND_TYPE_SERVICE, description="Return maria connection arguments string"
)
def maria__db__connect(
    context: ExecutionContext,
    service: AppService,
) -> str:
    return mysql__db__connect(context=context, service=service)
