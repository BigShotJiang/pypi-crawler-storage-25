from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command
from wexample_wex_core.decorator.option import option

from wexample_wex_addon_services_db.services.mysql.commands.db.dump import (
    mysql__db__dump,
)

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@option(
    name="file_name",
    type=str,
    required=True,
    description="Dump file name (without extension)",
)
@command(
    type=COMMAND_TYPE_SERVICE, description="Dump the maria database to a .sql file"
)
def maria__db__dump(
    context: ExecutionContext,
    service: AppService,
    file_name: str,
) -> str:
    return mysql__db__dump(context=context, service=service, file_name=file_name)
