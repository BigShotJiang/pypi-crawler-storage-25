from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command

from wexample_wex_addon_services_db.services.mysql.commands.db.go import mysql__db__go

if TYPE_CHECKING:
    from wexample_app.response.abstract_response import AbstractResponse
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@command(
    type=COMMAND_TYPE_SERVICE,
    description="Open an interactive MariaDB CLI in the container",
)
def maria__db__go(
    context: ExecutionContext,
    service: AppService,
) -> AbstractResponse:
    return mysql__db__go(context=context, service=service)
