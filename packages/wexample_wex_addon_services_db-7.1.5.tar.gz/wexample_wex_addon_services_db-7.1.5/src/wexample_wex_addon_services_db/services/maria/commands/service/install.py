from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command

from wexample_wex_addon_services_db.services.mysql.commands.service.install import (
    mysql__service__install,
)

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@command(
    type=COMMAND_TYPE_SERVICE,
    description="Configure maria service in app config",
)
def maria__service__install(
    context: ExecutionContext,
    service: AppService,
) -> None:
    return mysql__service__install(context=context, service=service)
