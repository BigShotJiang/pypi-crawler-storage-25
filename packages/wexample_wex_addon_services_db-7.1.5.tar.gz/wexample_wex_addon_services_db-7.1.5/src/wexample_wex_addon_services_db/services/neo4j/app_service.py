from __future__ import annotations

from wexample_wex_addon_app.service.app_service import AppService as BaseAppService


class AppService(BaseAppService):
    def get_workdir_contribution(self) -> dict:
        from wexample_filestate.const.disk import DiskItemType

        # Neo4j container runs as uid 7474 (neo4j user)
        neo4j_mode = {"owner": "7474:7474", "permissions": "755", "recursive": True}

        return {
            "children": [
                {
                    "name": "logs",
                    "type": DiskItemType.DIRECTORY,
                    "should_exist": True,
                    "mode": neo4j_mode,
                },
                {
                    "name": "data",
                    "type": DiskItemType.DIRECTORY,
                    "should_exist": True,
                    "mode": neo4j_mode,
                },
                {
                    "name": "plugins",
                    "type": DiskItemType.DIRECTORY,
                    "should_exist": True,
                    "mode": neo4j_mode,
                },
            ]
        }
