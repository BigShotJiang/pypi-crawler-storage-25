from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command

if TYPE_CHECKING:
    from wexample_app.response.abstract_response import AbstractResponse
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@command(
    type=COMMAND_TYPE_SERVICE,
    description="Open an interactive MySQL CLI in the container",
)
def mysql__db__go(
    context: ExecutionContext,
    service: AppService,
) -> AbstractResponse:
    from wexample_app.response.interactive_shell_command_response import (
        InteractiveShellCommandResponse,
    )

    runtime = service.app_workdir.get_runtime_config()
    app_project_name = runtime.search("app.project_name").get_str()
    container_name = f"{app_project_name}_{service.name}"

    return InteractiveShellCommandResponse(
        kernel=context.kernel,
        content=[
            "docker",
            "exec",
            "-ti",
            container_name,
            "mysql",
            "--defaults-extra-file=/tmp/mysql.cnf",
        ],
    )
