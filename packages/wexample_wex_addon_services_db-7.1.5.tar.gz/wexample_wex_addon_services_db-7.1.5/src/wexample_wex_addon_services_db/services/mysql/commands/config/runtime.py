from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext

MYSQL_CONF_FILE = "mysql.cnf"


@command(type=COMMAND_TYPE_SERVICE, description="Write mysql runtime configuration")
def mysql__config__runtime(
    context: ExecutionContext,
    service: AppService,
) -> None:
    import os

    from wexample_app.const.globals import WORKDIR_SETUP_DIR
    from wexample_config.config_value.nested_config_value import NestedConfigValue
    from wexample_helpers.helpers.dict import dict_merge
    from wexample_wex_core.const.globals import CORE_DIR_NAME_TMP

    app_workdir = service.app_workdir
    service_name = service.name

    # Read service credentials from config.yml
    config = app_workdir.get_config()
    user = config.search(f"service.{service_name}.user").get_str_or_default("root")
    password = config.search(f"service.{service_name}.password").get_str_or_default("")
    db_name = config.search(f"service.{service_name}.name").get_str_or_default(
        service_name
    )

    # Write mysql.cnf in .wex/tmp/
    tmp_dir = app_workdir.get_path() / WORKDIR_SETUP_DIR / CORE_DIR_NAME_TMP
    tmp_dir.mkdir(parents=True, exist_ok=True)
    cnf_path = tmp_dir / MYSQL_CONF_FILE
    cnf_path.write_text(
        f"[client]{os.linesep}"
        f'user = "{user}"{os.linesep}'
        f'password = "{password}"{os.linesep}'
    )
    cnf_path.chmod(0o644)

    # Write db.main into runtime config
    base = app_workdir.build_runtime_config_value().to_dict()
    merged = dict_merge(base, {"db": {"main": db_name}})
    app_workdir.get_runtime_config_file().write_config(NestedConfigValue(raw=merged))

    context.io.log(f"mysql config/runtime: written (db.main={db_name}, cnf={cnf_path})")
