from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command
from wexample_wex_core.decorator.option import option

if TYPE_CHECKING:
    from wexample_app.response.abstract_response import AbstractResponse
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@option(
    name="sql",
    type=str,
    required=True,
    description="SQL command to execute",
)
@command(type=COMMAND_TYPE_SERVICE, description="Execute a SQL command in mysql")
def mysql__db__exec(
    context: ExecutionContext,
    service: AppService,
    sql: str,
) -> AbstractResponse:
    from wexample_app.response.shell_command_response import ShellCommandResponse

    runtime = service.app_workdir.get_runtime_config()
    app_project_name = runtime.search("app.project_name").get_str()
    container_name = f"{app_project_name}_{service.name}"

    return ShellCommandResponse(
        kernel=context.kernel,
        content=[
            "docker",
            "exec",
            container_name,
            "mysql",
            "--defaults-extra-file=/tmp/mysql.cnf",
            "-s",
            "-N",
            "-e",
            sql,
        ],
    )
