from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command

if TYPE_CHECKING:
    from wexample_app.response.boolean_response import BooleanResponse
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


def check_mysql_ready(
    context: ExecutionContext, service: AppService
) -> BooleanResponse:
    import subprocess

    from wexample_app.response.boolean_response import BooleanResponse

    runtime = service.app_workdir.get_runtime_config()
    app_project_name = runtime.search("app.project_name").get_str()
    container_name = f"{app_project_name}_{service.name}"

    user = runtime.search(f"service.{service.name}.user").get_str_or_default("root")
    password = runtime.search(f"service.{service.name}.password").get_str_or_default("")

    cmd = [
        "docker",
        "exec",
        container_name,
        "mysqladmin",
        "ping",
        "-h",
        "localhost",
        f"-u{user}",
        "--silent",
    ]
    if password:
        cmd.append(f"-p{password}")

    result = subprocess.run(cmd, capture_output=True)

    return BooleanResponse(kernel=context.kernel, content=result.returncode == 0)


@command(type=COMMAND_TYPE_SERVICE, description="Check if mysql service is ready")
def mysql__service__ready(
    context: ExecutionContext,
    service: AppService,
) -> BooleanResponse:
    return check_mysql_ready(context=context, service=service)
