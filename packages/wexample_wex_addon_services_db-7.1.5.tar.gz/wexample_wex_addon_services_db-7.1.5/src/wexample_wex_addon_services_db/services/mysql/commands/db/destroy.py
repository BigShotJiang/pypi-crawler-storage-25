from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command
from wexample_wex_core.decorator.option import option

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@option(
    name="database",
    type=str,
    required=False,
    description="Database name (defaults to db.main from runtime config)",
)
@command(type=COMMAND_TYPE_SERVICE, description="Drop and recreate the mysql database")
def mysql__db__destroy(
    context: ExecutionContext,
    service: AppService,
    database: str | None = None,
) -> None:
    import subprocess

    runtime = service.app_workdir.get_runtime_config()
    app_project_name = runtime.search("app.project_name").get_str()
    container_name = f"{app_project_name}_{service.name}"
    db_name = (
        database
        or runtime.search("db.main").get_str_or_none()
        or runtime.search("app.name").get_str()
    )

    context.io.log(f'Recreating empty database "{db_name}"')

    result = subprocess.run(
        [
            "docker",
            "exec",
            container_name,
            "mysql",
            "--defaults-extra-file=/tmp/mysql.cnf",
            "-e",
            f"DROP DATABASE IF EXISTS {db_name}; CREATE DATABASE {db_name}",
        ],
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        raise RuntimeError(f"db/destroy failed:\n{result.stderr}")
