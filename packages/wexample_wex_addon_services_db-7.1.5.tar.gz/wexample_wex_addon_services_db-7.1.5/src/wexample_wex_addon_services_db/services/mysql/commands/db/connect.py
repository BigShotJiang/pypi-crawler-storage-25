from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@command(
    type=COMMAND_TYPE_SERVICE, description="Return mysql connection arguments string"
)
def mysql__db__connect(
    context: ExecutionContext,
    service: AppService,
) -> str:
    return "--defaults-extra-file=/tmp/mysql.cnf"
