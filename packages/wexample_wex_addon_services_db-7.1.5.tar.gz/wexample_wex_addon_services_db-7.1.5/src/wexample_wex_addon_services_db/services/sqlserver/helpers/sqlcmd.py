from __future__ import annotations

import shlex


def build_sqlcmd_command(
    *,
    container_name: str,
    user: str,
    password: str,
    database: str | None = None,
    query: str | None = None,
    interactive: bool = False,
) -> list[str]:
    script_parts = [
        'SQLCMD_BIN="/opt/mssql-tools18/bin/sqlcmd"',
        'if [ ! -x "$SQLCMD_BIN" ]; then SQLCMD_BIN="/opt/mssql-tools/bin/sqlcmd"; fi',
        'if [ ! -x "$SQLCMD_BIN" ]; then SQLCMD_BIN="$(command -v sqlcmd)"; fi',
        '[ -n "$SQLCMD_BIN" ] || { echo "sqlcmd not found" >&2; exit 127; }',
    ]

    command_parts = [
        'exec "$SQLCMD_BIN"',
        "-S localhost",
        f"-U {shlex.quote(user)}",
    ]

    if database:
        command_parts.append(f"-d {shlex.quote(database)}")

    if interactive:
        command_parts.append("-C")
    else:
        command_parts.append("-C -h -1 -W")
        if query is not None:
            command_parts.append(f"-Q {shlex.quote(f'SET NOCOUNT ON; {query}')}")

    script_parts.append(" ".join(command_parts))

    command = ["docker", "exec", "-e", f"SQLCMDPASSWORD={password}"]
    if interactive:
        command.append("-ti")
    command.extend([container_name, "sh", "-lc", "; ".join(script_parts)])
    return command
