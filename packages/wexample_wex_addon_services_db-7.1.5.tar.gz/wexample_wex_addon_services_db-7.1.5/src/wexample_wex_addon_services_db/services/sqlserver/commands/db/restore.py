from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command
from wexample_wex_core.decorator.option import option

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@option(
    name="file_name",
    short_name="f",
    type=str,
    required=True,
    description="Backup file name (must exist in /var/opt/mssql/dumps/)",
)
@option(
    name="database",
    short_name="d",
    type=str,
    required=False,
    description="Database name (defaults to db.main from runtime config)",
)
@command(
    type=COMMAND_TYPE_SERVICE,
    description="Restore a SQL Server database from a .bak dump",
)
def sqlserver__db__restore(
    context: ExecutionContext,
    service: AppService,
    file_name: str,
    database: str | None = None,
) -> None:
    import subprocess

    from wexample_wex_addon_services_db.services.sqlserver.helpers.sqlcmd import (
        build_sqlcmd_command,
    )

    runtime = service.app_workdir.get_runtime_config()
    app_project_name = runtime.search("app.project_name").get_str()
    container_name = f"{app_project_name}_{service.name}"
    db_name = (
        database
        or runtime.search("db.main").get_str_or_none()
        or runtime.search("app.name").get_str()
    )
    user = runtime.search(f"service.{service.name}.user").get_str_or_default("sa")
    password = runtime.search(f"service.{service.name}.password").get_str_or_default("")

    query = (
        f"USE master; ALTER DATABASE [{db_name}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; "
        f"RESTORE DATABASE [{db_name}] FROM DISK = '/var/opt/mssql/dumps/{file_name}' WITH REPLACE; "
        f"ALTER DATABASE [{db_name}] SET MULTI_USER;"
    )
    result = subprocess.run(
        build_sqlcmd_command(
            container_name=container_name,
            user=user,
            password=password,
            database="master",
            query=query,
        ),
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"sqlserver db/restore failed:\n{result.stderr}")
