from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command
from wexample_wex_core.decorator.option import option

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@option(
    name="database",
    short_name="d",
    type=str,
    required=False,
    description="Database name (unused, reserved for future multi-db support)",
)
@command(type=COMMAND_TYPE_SERVICE, description="List available SQL Server dump files")
def sqlserver__db__dumps_list(
    context: ExecutionContext,
    service: AppService,
    database: str | None = None,
) -> list[str]:
    import glob

    from wexample_app.const.globals import WORKDIR_SETUP_DIR

    dumps_dir = (
        service.app_workdir.get_path() / WORKDIR_SETUP_DIR / service.name / "dumps"
    )

    dump_files = []
    for pattern in ["*.bak", "*.zip"]:
        dump_files.extend(glob.glob(str(dumps_dir / pattern)))

    return sorted(dump_files)
