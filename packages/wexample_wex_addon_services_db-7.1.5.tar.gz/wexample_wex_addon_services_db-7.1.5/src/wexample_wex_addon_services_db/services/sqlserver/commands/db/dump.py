from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command
from wexample_wex_core.decorator.option import option

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@option(
    name="file_name",
    short_name="f",
    type=str,
    required=True,
    description="Dump file name (without extension)",
)
@command(
    type=COMMAND_TYPE_SERVICE, description="Dump the SQL Server database to a .bak file"
)
def sqlserver__db__dump(
    context: ExecutionContext,
    service: AppService,
    file_name: str,
) -> str:
    import subprocess

    from wexample_app.const.globals import WORKDIR_SETUP_DIR

    from wexample_wex_addon_services_db.services.sqlserver.helpers.sqlcmd import (
        build_sqlcmd_command,
    )

    runtime = service.app_workdir.get_runtime_config()
    app_project_name = runtime.search("app.project_name").get_str()
    container_name = f"{app_project_name}_{service.name}"
    db_name = (
        runtime.search("db.main").get_str_or_none()
        or runtime.search("app.name").get_str()
    )
    user = runtime.search(f"service.{service.name}.user").get_str_or_default("sa")
    password = runtime.search(f"service.{service.name}.password").get_str_or_default("")

    backup_file = f"{file_name}.bak"
    dumps_dir = (
        service.app_workdir.get_path() / WORKDIR_SETUP_DIR / service.name / "dumps"
    )
    dumps_dir.mkdir(parents=True, exist_ok=True)

    result = subprocess.run(
        build_sqlcmd_command(
            container_name=container_name,
            user=user,
            password=password,
            database="master",
            query=f"BACKUP DATABASE [{db_name}] TO DISK = '/var/opt/mssql/dumps/{backup_file}'",
        ),
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"sqlserver db/dump failed:\n{result.stderr}")

    perms_result = subprocess.run(
        [
            "docker",
            "exec",
            "-u",
            "0",
            container_name,
            "chown",
            "1000:1000",
            f"/var/opt/mssql/dumps/{backup_file}",
        ],
        capture_output=True,
        text=True,
    )
    if perms_result.returncode != 0:
        raise RuntimeError(
            f"sqlserver dump ownership update failed:\n{perms_result.stderr}"
        )

    return str(dumps_dir / backup_file)
