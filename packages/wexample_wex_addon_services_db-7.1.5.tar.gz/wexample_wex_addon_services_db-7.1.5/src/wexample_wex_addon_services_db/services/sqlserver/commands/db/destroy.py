from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command
from wexample_wex_core.decorator.option import option

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@option(
    name="database",
    short_name="d",
    type=str,
    required=False,
    description="Database name (defaults to db.main from runtime config)",
)
@option(
    name="recreate",
    short_name="r",
    type=bool,
    required=False,
    default=True,
    description="Recreate an empty database after drop",
)
@command(
    type=COMMAND_TYPE_SERVICE,
    description="Drop and optionally recreate the SQL Server database",
)
def sqlserver__db__destroy(
    context: ExecutionContext,
    service: AppService,
    database: str | None = None,
    recreate: bool = True,
) -> None:
    import subprocess

    from wexample_wex_addon_services_db.services.sqlserver.helpers.sqlcmd import (
        build_sqlcmd_command,
    )

    runtime = service.app_workdir.get_runtime_config()
    app_project_name = runtime.search("app.project_name").get_str()
    container_name = f"{app_project_name}_{service.name}"
    db_name = (
        database
        or runtime.search("db.main").get_str_or_none()
        or runtime.search("app.name").get_str()
    )
    user = runtime.search(f"service.{service.name}.user").get_str_or_default("sa")
    password = runtime.search(f"service.{service.name}.password").get_str_or_default("")

    drop_query = (
        f"IF DB_ID(N'{db_name}') IS NOT NULL BEGIN "
        f"ALTER DATABASE [{db_name}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; "
        f"DROP DATABASE [{db_name}]; END"
    )
    drop_result = subprocess.run(
        build_sqlcmd_command(
            container_name=container_name,
            user=user,
            password=password,
            database="master",
            query=drop_query,
        ),
        capture_output=True,
        text=True,
    )
    if drop_result.returncode != 0:
        raise RuntimeError(f"sqlserver db/destroy failed:\n{drop_result.stderr}")

    if recreate:
        create_result = subprocess.run(
            build_sqlcmd_command(
                container_name=container_name,
                user=user,
                password=password,
                database="master",
                query=f"CREATE DATABASE [{db_name}]",
            ),
            capture_output=True,
            text=True,
        )
        if create_result.returncode != 0:
            raise RuntimeError(f"sqlserver db/recreate failed:\n{create_result.stderr}")

    context.io.log(f'SQL Server database "{db_name}" reset')
