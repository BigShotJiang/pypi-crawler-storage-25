"""SLIP 协议编码/解码"""


def slip_encode(data: list) -> list:
    """SLIP 编码

    Args:
        data: 原始字节列表

    Returns:
        编码后的字节列表
    """
    END = 0xC0
    ESC = 0xDB
    ESC_END = 0xDC
    ESC_ESC = 0xDD

    result = [END]
    for byte in data:
        if byte == END:
            result.extend([ESC, ESC_END])
        elif byte == ESC:
            result.extend([ESC, ESC_ESC])
        else:
            result.append(byte)
    result.append(END)
    return result


def slip_decode(data: list) -> list:
    """SLIP 解码

    Args:
        data: 编码后的字节列表

    Returns:
        解码后的字节列表
    """
    END = 0xC0
    ESC = 0xDB
    ESC_END = 0xDC
    ESC_ESC = 0xDD

    result = []
    for i, byte in enumerate(data):
        if byte == END and i == 0:
            continue
        if i == len(data) - 1 and byte == END:
            break
        if byte == ESC and i + 1 < len(data):
            next_byte = data[i + 1]
            if next_byte == ESC_END:
                result.append(END)
            elif next_byte == ESC_ESC:
                result.append(ESC)
        elif byte != ESC:
            result.append(byte)
    return result