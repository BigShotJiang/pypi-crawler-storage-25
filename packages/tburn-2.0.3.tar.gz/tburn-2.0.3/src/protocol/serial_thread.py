"""串口读取线程"""
import threading
import time
import logging

try:
    from serial import Serial
    HAS_SERIAL = True
except ImportError:
    HAS_SERIAL = False
    Serial = None

from .utils import print_hex
from .chips import ChipType, is_rts_inverted, get_chip_config


class ReadSerialThread(threading.Thread):
    """串口读取线程

    负责异步读取串口数据，避免阻塞主线程。
    """

    def __init__(self, serial_dump_dbg=False, port=None):
        threading.Thread.__init__(self)
        self.serial = None
        self.serial_is_open = False
        self.serial_port = port
        self.serial_dump_dbg = serial_dump_dbg
        self.end_read = False
        self.lock = threading.RLock()
        self.is_running = False
        self.com_msg = []
        self.baudrate = 115200

    def init_serial(self, port=None, baud=115200) -> bool:
        """初始化串口

        Args:
            port: 串口端口
            baud: 波特率

        Returns:
            是否成功
        """
        if not HAS_SERIAL:
            logging.error("pyserial 未安装")
            return False

        self.baudrate = baud
        if port:
            self.serial_port = port

        if self.serial and self.serial_is_open:
            self.deinit_serial()

        # 确保线程停止
        self.is_running = False
        time.sleep(0.05)

        try:
            self.lock.acquire()
            self.serial = Serial(self.serial_port, baud, timeout=0.1)
            self.serial_is_open = True
            self.lock.release()
            logging.info(f"串口已打开: {self.serial_port}@{baud}")
            return True
        except Exception as e:
            self.lock.release()
            logging.error(f"串口打开失败: {e}")
            return False
            return False

    def deinit_serial(self):
        """关闭串口"""
        # 先停止线程
        self.is_running = False
        time.sleep(0.05)  # 等待线程停止

        if self.serial and self.serial_is_open:
            self.serial_is_open = False
            self.lock.acquire()
            try:
                self.serial.close()
            except:
                pass
            self.lock.release()

    def reload(self, baud=115200) -> bool:
        """重新初始化串口（更改波特率）

        Args:
            baud: 新波特率

        Returns:
            是否成功
        """
        # 先停止线程
        self.is_running = False
        time.sleep(0.05)  # 等待线程停止

        self.deinit_serial()
        result = self.init_serial(self.serial_port, baud)

        # 重新启动线程（如果之前在运行）
        # 注意：不需要调用 start()，因为线程已经在运行
        # 只需要恢复 is_running 状态
        self.is_running = True

        return result

    def mark_start(self):
        """标记线程开始运行"""
        self.is_running = True

    def mark_stop(self):
        """标记线程停止运行"""
        self.is_running = False

    def notice_end_read(self):
        """通知线程结束"""
        self.end_read = True

    def run(self):
        """线程运行主循环"""
        while not self.end_read and self.is_running:
            try:
                if self.serial and self.serial.is_open and self.serial_is_open:
                    self.lock.acquire()
                    if self.serial_is_open:
                        tmp_msg = self.serial.read_all()
                    else:
                        tmp_msg = b''
                    self.lock.release()

                    if tmp_msg:
                        tmp_msg_hex = list(bytearray.fromhex(tmp_msg.hex()))
                        if self.serial_dump_dbg:
                            logging.debug('ReadSerialThread:')
                            print_hex(tmp_msg_hex)
                        if isinstance(tmp_msg_hex, list):
                            self.com_msg.extend(tmp_msg_hex)
                    else:
                        time.sleep(0.01)
                else:
                    time.sleep(0.01)
            except Exception as err:
                logging.warning(f"串口读取错误: {err}")
                self.notice_end_read()

    def write(self, msg):
        """写入数据

        Args:
            msg: 字符串或字节列表
        """
        if self.serial and msg:
            if isinstance(msg, str):
                self.serial.write(f'{msg}\n'.encode('utf-8'))
            elif isinstance(msg, list):
                self.serial.write(bytes(msg))
            self.serial.flush()

    def read(self) -> list:
        """读取缓冲数据

        Returns:
            字节列表
        """
        return list(self.com_msg)

    def swap(self):
        """清空缓冲"""
        self.com_msg = []

    # ==================== RTS/DTR 控制 ====================

    def set_rts(self, state: bool):
        """设置 RTS 信号

        Args:
            state: True=HIGH, False=LOW
        """
        if self.serial and self.serial_is_open:
            try:
                self.serial.rts = state
                if self.serial_dump_dbg:
                    logging.debug(f"RTS set to {state}")
            except Exception as e:
                logging.warning(f"设置 RTS 失败: {e}")

    def set_dtr(self, state: bool):
        """设置 DTR 信号

        Args:
            state: True=HIGH, False=LOW
        """
        if self.serial and self.serial_is_open:
            try:
                self.serial.dtr = state
                if self.serial_dump_dbg:
                    logging.debug(f"DTR set to {state}")
            except Exception as e:
                logging.warning(f"设置 DTR 失败: {e}")

    def get_rts(self) -> bool:
        """获取当前 RTS 状态"""
        if self.serial and self.serial_is_open:
            return self.serial.rts
        return False

    def get_dtr(self) -> bool:
        """获取当前 DTR 状态"""
        if self.serial and self.serial_is_open:
            return self.serial.dtr
        return False

    def reset_sequence(self, chip_type: ChipType, reset_delay: int = 100):
        """执行芯片复位序列，触发设备进入烧录模式

        不同芯片使用不同的 RTS/DTR 序列：
        - CSK 系列: 标准 RTS/DTR 序列
        - ARCS/VENUSA: iBurn2 标准序列

        Args:
            chip_type: 芯片类型
            reset_delay: 复位延迟时间（毫秒），ARCS 默认 100ms
        """
        if not self.serial or not self.serial_is_open:
            logging.warning("串口未打开，无法执行复位序列")
            return

        config = get_chip_config(chip_type)
        rts_inverted = config["rts_inverted"]

        logging.info(f"执行复位序列 ({chip_type.value}, delay={reset_delay}ms)")

        if rts_inverted:
            # ARCS/VENUSA: iBurn2 使用的序列（已验证可工作）
            # 参考: transport-v2.js resetDevice() bootloader mode (lines 333-341)
            # 序列: RTS=HIGH, DTR=LOW → 100ms → RTS=LOW, DTR=HIGH → 100ms → RTS=HIGH, DTR=HIGH
            logging.info("ARCS reset: iBurn2 sequence")
            self.set_rts(True)    # RTS=HIGH (asserted)
            self.set_dtr(False)   # DTR=LOW (not asserted)
            time.sleep(0.1)

            self.set_rts(False)   # RTS=LOW (not asserted)
            self.set_dtr(True)    # DTR=HIGH (asserted)
            time.sleep(0.1)

            self.set_rts(True)    # RTS=HIGH (asserted)
            self.set_dtr(True)    # DTR=HIGH (asserted)
        else:
            # CSK 系列: 标准 RTS/DTR 序列
            # 序列: UPDATE=HIGH, RESET=HIGH → UPDATE=LOW, RESET=LOW → delay → RESET=HIGH
            self.set_rts(False)   # UPDATE=HIGH (RTS not active)
            self.set_dtr(True)    # RESET=HIGH
            time.sleep(0.01)
            self.set_rts(True)    # UPDATE=LOW (rts_active)
            self.set_dtr(False)   # RESET=LOW
            time.sleep(reset_delay / 1000.0)
            self.set_dtr(True)    # RESET=HIGH

    def reset_device(self, chip_type: ChipType, reset_delay: int = 500):
        """复位设备（烧录完成后使用）

        Args:
            chip_type: 芯片类型
            reset_delay: 复位延迟时间（毫秒）
        """
        if not self.serial or not self.serial_is_open:
            return

        config = get_chip_config(chip_type)
        rts_inverted = config["rts_inverted"]

        if rts_inverted:
            # ARCS/VENUSA 复位
            self.set_dtr(False)   # UPDATE=HIGH
            self.set_rts(False)   # RESET=LOW
            time.sleep(reset_delay / 1000.0)
            self.set_rts(True)    # RESET=HIGH
        else:
            # CSK 复位
            self.set_rts(False)   # UPDATE=HIGH
            self.set_dtr(False)   # RESET=LOW
            time.sleep(reset_delay / 1000.0)
            self.set_dtr(True)    # RESET=HIGH