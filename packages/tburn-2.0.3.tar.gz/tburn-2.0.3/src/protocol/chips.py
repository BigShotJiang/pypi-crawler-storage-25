"""芯片类型和烧录目标定义"""
from enum import Enum
from typing import Dict, Any


class ChipType(Enum):
    """芯片类型枚举"""
    CSK6 = 6
    ARCS = "arcs"
    ARCS_DUAL = "arcs_dual"
    VENUSA = "venusa"


class BurnTarget(Enum):
    """烧录目标枚举"""
    FLASH = "flash"
    EMMC = "emmc"
    NAND = "nand"


# 芯片配置表 - 包含每种芯片的特定参数
CHIP_CONFIG: Dict[ChipType, Dict[str, Any]] = {
    ChipType.CSK6: {
        "load_addr": 0x0,              # RAM 加载地址
        "burner": "burner_6.img",      # burner 文件名
        "rts_inverted": False,         # 标准 RTS/DTR 序列
        "needs_sys_clk": False,        # 不需要时钟配置
        "supports_emmc": False,        # 不支持 eMMC
        "supports_dual_flash": False,  # 不支持双 Flash
        "needs_erase_before_write": False,  # 不需要烧录前擦除
    },
    ChipType.ARCS: {
        "load_addr": 0x20040000,       # RAM 加载地址
        "burner": "burner_arcs.img",
        "rts_inverted": True,          # 反向 RTS/DTR 序列
        "needs_sys_clk": False,
        "supports_emmc": True,         # 支持 eMMC
        "supports_dual_flash": False,
        "needs_erase_before_write": True,  # ARCS 需要烧录前擦除
    },
    ChipType.ARCS_DUAL: {
        "load_addr": 0x20040000,
        "burner": "burner_arcs_dual.img",
        "rts_inverted": True,
        "needs_sys_clk": False,
        "supports_emmc": True,
        "supports_dual_flash": True,   # 支持 Flash0/Flash1 选择
        "needs_erase_before_write": True,
    },
    ChipType.VENUSA: {
        "load_addr": 0x20050000,       # RAM 加载地址
        "burner": "burner_venusa.img",
        "rts_inverted": True,
        "needs_sys_clk": True,         # 需要时钟配置
        "supports_emmc": False,
        "supports_dual_flash": False,
        "needs_erase_before_write": False,
    },
}


def get_chip_config(chip_type: ChipType) -> Dict[str, Any]:
    """获取芯片配置"""
    return CHIP_CONFIG.get(chip_type, CHIP_CONFIG[ChipType.CSK6])


def get_load_addr(chip_type: ChipType) -> int:
    """获取芯片的 RAM 加载地址"""
    return get_chip_config(chip_type)["load_addr"]


def get_burner_name(chip_type: ChipType) -> str:
    """获取芯片的 burner 文件名"""
    return get_chip_config(chip_type)["burner"]


def is_rts_inverted(chip_type: ChipType) -> bool:
    """判断芯片是否使用反向 RTS/DTR 序列"""
    return get_chip_config(chip_type)["rts_inverted"]


def needs_sys_clk(chip_type: ChipType) -> bool:
    """判断芯片是否需要时钟配置"""
    return get_chip_config(chip_type)["needs_sys_clk"]


def supports_emmc(chip_type: ChipType) -> bool:
    """判断芯片是否支持 eMMC"""
    return get_chip_config(chip_type)["supports_emmc"]


def supports_dual_flash(chip_type: ChipType) -> bool:
    """判断芯片是否支持双 Flash"""
    return get_chip_config(chip_type)["supports_dual_flash"]


def needs_erase_before_write(chip_type: ChipType) -> bool:
    """判断芯片烧录前是否需要擦除"""
    return get_chip_config(chip_type)["needs_erase_before_write"]


def chip_to_str(chip_type: ChipType) -> str:
    """芯片类型转换为显示字符串"""
    if isinstance(chip_type.value, int):
        return f"CSK{chip_type.value}"
    return chip_type.value.upper()