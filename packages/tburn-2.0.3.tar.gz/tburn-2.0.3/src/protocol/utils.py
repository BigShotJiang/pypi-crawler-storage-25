"""协议工具函数"""
import os
import hashlib
import logging
from functools import reduce

# 模块logger
_logger = logging.getLogger(__name__)


def checksum(data: list) -> int:
    """计算校验和

    Args:
        data: 字节列表

    Returns:
        校验和值
    """
    CHECKSUM_MAGIC = 0xef
    state = CHECKSUM_MAGIC
    for byte in data:
        state = state ^ byte
    return state


def get_bytes_hex_list(value: int, length: int) -> list:
    """将整数转换为字节列表（小端序）

    Args:
        value: 整数值
        length: 字节长度

    Returns:
        字节列表
    """
    return [(value >> (8 * i)) & 0xFF for i in range(length)]


def get_hex_from_list(data: list) -> int:
    """将字节列表转换为整数（小端序）

    Args:
        data: 字节列表

    Returns:
        整数值
    """
    return sum(byte << (8 * i) for i, byte in enumerate(data))


def getmd5(file_path: str) -> int:
    """计算文件 MD5

    Args:
        file_path: 文件路径

    Returns:
        MD5 值（整数）
    """
    m = hashlib.md5()
    with open(file_path, 'rb') as f:
        for line in f:
            m.update(line)
    return int(m.hexdigest(), 16)


def getmd5_fromlist(data: list) -> int:
    """从数据列表计算 MD5

    Args:
        data: 字节列表

    Returns:
        MD5 值（整数）
    """
    m = hashlib.md5()
    m.update(bytes(data))
    return int(m.hexdigest(), 16)


def read_hex_from_bin(file_path: str) -> list:
    """读取二进制文件为字节列表

    Args:
        file_path: 文件路径

    Returns:
        字节列表
    """
    if not os.path.isfile(file_path):
        return []
    with open(file_path, 'rb') as f:
        return list(bytearray.fromhex(f.read().hex()))


def print_hex(data: list, head=None):
    """打印十六进制数据（调试用）

    使用logging.debug输出，格式清晰，避免污染TUI显示。

    Args:
        data: 字节列表
        head: 表头列表
    """
    if not data:
        return

    lines = []
    lines.append("─" * 60)  # 分隔线

    if head:
        # 表头行
        head_str = ' '.join(f'{h:>3}' for h in head[:16])  # 只显示前16个
        lines.append(f"Offset  {head_str}")
        lines.append("─" * 60)

    for i in range(0, len(data), 16):
        chunk = data[i:i+16]
        # 地址 + hex字节
        hex_str = ' '.join(f'{b:02x}' for b in chunk)
        # ASCII显示（可选）
        ascii_str = ''.join(chr(b) if 32 <= b < 127 else '.' for b in chunk)
        lines.append(f"{i:05x}   {hex_str:<48}  {ascii_str}")

    lines.append("─" * 60)  # 结束分隔线
    lines.append(f"Total: {len(data)} bytes")

    # 使用logging输出整块（会被重定向到TUI LogPanel）
    _logger.debug("\n" + "\n".join(lines))