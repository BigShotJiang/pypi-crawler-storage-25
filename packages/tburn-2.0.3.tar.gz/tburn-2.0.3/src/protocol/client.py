"""CSK 烧录协议客户端"""
import time
import logging

from .slip import slip_encode, slip_decode
from .utils import checksum, get_bytes_hex_list, get_hex_from_list
from .serial_thread import ReadSerialThread


class CSKBurnProtocolClient:
    """CSK 烧录协议客户端

    实现所有 CSK 芯片的串口烧录协议命令。
    """

    # 协议常量
    DIR_REQ = 0x00
    DIR_RES = 0x01

    CMD_FLASH_BEGIN = 0x02
    CMD_FLASH_DATA = 0x03
    CMD_FLASH_END = 0x04
    CMD_MEM_BEGIN = 0x05
    CMD_MEM_END = 0x06
    CMD_MEM_DATA = 0x07
    CMD_SYNC = 0x08
    CMD_READ_REG = 0x0a
    CMD_READ_FLASH = 0x0e
    CMD_CHANGE_BAUDRATE = 0x0f
    CMD_SPI_FLASH_MD5 = 0x13

    # 新增命令码
    CMD_NAND_INIT = 0x20
    CMD_NAND_BEGIN = 0x21
    CMD_NAND_DATA = 0x22
    CMD_NAND_END = 0x23
    CMD_NAND_MD5 = 0x24
    CMD_SET_SYS_CLK = 0x31       # VENUSA 时钟配置
    CMD_EMMC_GET_INFO = 0x41     # eMMC 获取信息
    CMD_EMMC_BEGIN = 0x42        # eMMC 开始写入
    CMD_EMMC_DATA = 0x43         # eMMC 数据写入
    CMD_EMMC_END = 0x44          # eMMC 结束写入
    CMD_EMMC_MD5 = 0x45          # eMMC MD5 校验
    CMD_EMMC_READ_DATA = 0x46    # eMMC 读取数据
    CMD_EMMC_ERASE_DATA = 0x47   # eMMC 擦除
    CMD_FLASH_ERASE_CHIP = 0xD0
    CMD_FLASH_ERASE_REGION = 0xD1
    CMD_FLASH_LOCK = 0xD4
    CMD_FLASH_UNLOCK = 0xD5
    CMD_READ_FLASH_ID = 0xF3
    CMD_READ_CHIP_ID = 0xF4
    CMD_SET_FLASH_INDEX = 0xF5   # ARCS_DUAL Flash 选择
    CMD_FLASH_MD5_CHALLENGE = 0xF2

    # 命令名称映射
    CMD_NAMES = {
        0x02: "FLASH_BEGIN", 0x03: "FLASH_DATA", 0x04: "FLASH_END",
        0x05: "MEM_BEGIN", 0x06: "MEM_END", 0x07: "MEM_DATA",
        0x08: "SYNC", 0x0a: "READ_REG", 0x0e: "READ_FLASH",
        0x0f: "CHANGE_BAUD", 0x13: "SPI_FLASH_MD5",
        0x20: "NAND_INIT", 0x21: "NAND_BEGIN", 0x22: "NAND_DATA",
        0x23: "NAND_END", 0x24: "NAND_MD5",
        0x31: "SET_SYS_CLK",
        0x41: "EMMC_GET_INFO", 0x42: "EMMC_BEGIN", 0x43: "EMMC_DATA",
        0x44: "EMMC_END", 0x45: "EMMC_MD5",
        0xD0: "FLASH_ERASE_CHIP", 0xD1: "FLASH_ERASE_REGION",
        0xD4: "FLASH_LOCK", 0xD5: "FLASH_UNLOCK",
        0xF3: "READ_FLASH_ID", 0xF4: "READ_CHIP_ID",
        0xF5: "SET_FLASH_INDEX", 0xF2: "FLASH_MD5_CHALLENGE"
    }

    # 常量
    RAM_BLOCK_SIZE = 0x800
    FLASH_BLOCK_SIZE = 0x1000

    def __init__(self, serial_thread: ReadSerialThread, dump_dbg=False, funcname_dbg=False, log_callback=None):
        self.serial_thread = serial_thread
        self.dump_dbg = dump_dbg
        self.funcname_dbg = funcname_dbg
        self.log_callback = log_callback

        # 响应解析映射
        self.response_map = {
            'direction': {'pos': 0, 'lens': 1},
            'command': {'pos': 1, 'lens': 1},
            'size': {'pos': 2, 'lens': 2},
            'value': {'pos': 4, 'lens': 4},
            'error': {'pos': 8, 'lens': 1},
            'status': {'pos': 9, 'lens': 1},
            'md5': {'pos': 10, 'lens': 16}
        }

    def _log(self, direction: str, cmd: int, msg: str):
        """内部日志方法"""
        if self.log_callback:
            cmd_name = self.CMD_NAMES.get(cmd, f"{cmd:02X}")
            self.log_callback(direction, cmd, msg)

    def BLOCKS(self, size: int, block_size: int) -> int:
        """计算需要的块数"""
        return int((size + block_size - 1) / block_size)

    def serial_read(self) -> list:
        """从线程缓冲区读取"""
        return self.serial_thread.read()

    def serial_swap(self):
        """清空线程缓冲区"""
        self.serial_thread.swap()

    def serial_write(self, data: list):
        """写入数据"""
        self.serial_thread.write(data)

    def _direct_read_response(self, timeout: float) -> list:
        """直接从串口读取响应（用于 ARCS 设备）

        Args:
            timeout: 超时时间

        Returns:
            解码后的响应数据列表
        """
        if not self.serial_thread.serial or not self.serial_thread.serial_is_open:
            return []

        received = []
        start_time = time.time()

        # 暂停线程读取（避免冲突）- 使用锁确保线程停止
        original_running = self.serial_thread.is_running
        self.serial_thread.is_running = False

        # 等待线程停止（线程循环检查 is_running）
        time.sleep(0.05)  # 增加等待时间确保线程停止

        # 清空线程缓冲区（避免残留数据干扰）
        self.serial_thread.swap()

        while time.time() - start_time < timeout:
            try:
                # 直接读取串口数据
                data = self.serial_thread.serial.read(200)
                if data:
                    received.extend(list(data))

                    # 检查是否有完整的 SLIP 帧
                    if 0xC0 in received:
                        # 找到 SLIP 开始和结束
                        try:
                            start_idx = received.index(0xC0)
                            end_idx = received.index(0xC0, start_idx + 1)
                            if end_idx >= start_idx + 10:  # 最小响应长度
                                frame = received[start_idx:end_idx + 1]
                                decoded = slip_decode(frame)
                                if len(decoded) >= 8:
                                    # 恢复线程读取
                                    self.serial_thread.is_running = original_running
                                    return decoded
                        except ValueError:
                            pass

                time.sleep(0.01)
            except Exception as e:
                logging.warning(f"串口读取错误: {e}")
                break

        # 恢复线程读取
        self.serial_thread.is_running = original_running
        return []

    def set_request_hdr(self, data: list, command: int, chk: int) -> dict:
        """设置请求头"""
        return {
            'direction': self.DIR_REQ,
            'command': command,
            'size': len(data),
            'checksum': chk
        }

    def get_req_raw_data(self, req_hdr: dict, req_data: list) -> list:
        """构建请求原始数据"""
        result = [
            req_hdr['direction'],
            req_hdr['command']
        ]
        result.extend(get_bytes_hex_list(req_hdr['size'], 2))
        result.extend(get_bytes_hex_list(req_hdr['checksum'], 4))
        if isinstance(req_data, list):
            result.extend(req_data)
        elif isinstance(req_data, int):
            result.append(req_data)
        return result

    def parse_response(self, data: list, key: str) -> int:
        """解析响应字段"""
        if key not in self.response_map:
            return 0

        pos = self.response_map[key]['pos']
        lens = self.response_map[key]['lens']

        if pos > len(data) - 1 or pos + lens - 1 > len(data) - 1:
            return 0

        spec_data = data[pos:pos + lens]
        if key == 'md5':
            spec_data.reverse()
        return get_hex_from_list(spec_data)

    def command(self, command: int, data: list, chk: int, timeout=0.2) -> dict:
        """发送命令并接收响应

        Args:
            command: 命令码
            data: 数据
            chk: 校验和
            timeout: 超时时间

        Returns:
            响应结果字典
        """
        res_ret = {
            'ret': False,
            'res_ret': {'error': 0, 'code': 0, 'value': 0, 'size': 0, 'md5': 0}
        }

        # 构建请求
        req_hdr = self.set_request_hdr(data, command, chk)
        req_raw = self.get_req_raw_data(req_hdr, data)
        req_slip = slip_encode(req_raw)

        self._log('REQ', command, f"发送 {len(req_raw)} 字节")

        if self.dump_dbg:
            logging.debug(f"REQ raw: {req_raw[:16]}...")

        # 清空输入缓冲区（发送前清空）
        if self.serial_thread.serial and self.serial_thread.serial_is_open:
            try:
                self.serial_thread.serial.reset_input_buffer()
            except:
                pass

        # 发送
        self.serial_write(req_slip)
        time.sleep(0.01)

        # 直接从串口读取响应（适用于 ARCS 设备）
        res_raw = self._direct_read_response(timeout)

        if not res_raw or len(res_raw) < 8:
            self._log('RES', command, "超时无响应")
            return res_ret

        if self.dump_dbg:
            logging.debug(f"RES raw: {res_raw[:16]}...")

        # 解析响应
        ret_direction = self.parse_response(res_raw, 'direction')
        ret_command = self.parse_response(res_raw, 'command')
        ret_value = self.parse_response(res_raw, 'value')
        ret_size = self.parse_response(res_raw, 'size')

        res_ret['res_ret']['error'] = self.parse_response(res_raw, 'error')
        res_ret['res_ret']['code'] = self.parse_response(res_raw, 'status')
        res_ret['res_ret']['value'] = ret_value
        res_ret['res_ret']['size'] = ret_size

        # MD5 特殊处理
        if ret_size == 2 + 16 and command == self.CMD_SPI_FLASH_MD5:
            res_ret['res_ret']['md5'] = self.parse_response(res_raw, 'md5')

        # 验证响应
        if ret_command == command and ret_direction == self.DIR_RES:
            res_ret['ret'] = True
            self._log('RES', command, f"成功 value={ret_value:08X}")
        else:
            self._log('RES', command, f"失败 error={res_ret['res_ret']['error']:02X}")

        return res_ret

    def check_command(self, command: int, data: list, chk: int, timeout=0.2):
        """检查命令响应"""
        ret = self.command(command, data, chk, timeout)
        if not ret['ret']:
            return 0xFE
        if len(ret.get('res_ret')) < 2:
            logging.error(f'错误: 指令 {command:02X} 串口读取异常')
            return 0xFF

        if ret['res_ret']['error']:
            logging.error(f'错误: 指令 {command:02X} 设备返回异常 0x{ret["res_ret"]["code"]:02X}')
            if command == self.CMD_READ_REG:
                return ret['res_ret']['value']
        elif command == self.CMD_READ_REG:
            return ret['res_ret']['value']
        elif command == self.CMD_FLASH_DATA:
            return ret
        else:
            return (True, 0x00)

    # ==================== 具体命令实现 ====================

    def cmd_sync(self, timeout=0.3) -> bool:
        """同步命令"""
        if self.funcname_dbg:
            logging.debug('cmd_sync')
        cmd = [0x07, 0x07, 0x12, 0x20] + [0x55] * 32
        return self.command(self.CMD_SYNC, cmd, 0, timeout).get('ret')

    def cmd_read_reg(self, reg: int):
        """读取寄存器"""
        if self.funcname_dbg:
            logging.debug('cmd_read_reg')
        cmd = get_bytes_hex_list(reg, 4)
        return self.check_command(self.CMD_READ_REG, cmd, 0)

    def cmd_mem_begin(self, size: int, blocks: int, block_size: int = 0, offset: int = 0) -> bool:
        """开始内存写入"""
        if self.funcname_dbg:
            logging.debug('cmd_mem_begin')
        cmd = get_bytes_hex_list(size, 4) + get_bytes_hex_list(blocks, 4) + \
              get_bytes_hex_list(block_size, 4) + get_bytes_hex_list(offset, 4)
        return self.check_command(self.CMD_MEM_BEGIN, cmd, 0) == (True, 0x00)

    def cmd_mem_block(self, data: list, data_len: int, seq: int) -> bool:
        """写入内存块"""
        if self.funcname_dbg:
            logging.debug('cmd_mem_block')
        cmd = get_bytes_hex_list(data_len, 4) + get_bytes_hex_list(seq, 4) + \
              get_bytes_hex_list(0, 4) + get_bytes_hex_list(0, 4) + data
        return self.check_command(self.CMD_MEM_DATA, cmd, checksum(data), 0.5) == (True, 0x00)

    def cmd_mem_end(self, entry_point: int = 0) -> bool:
        """结束内存写入并跳转到入口点

        Args:
            entry_point: 跳转地址（默认为0，表示不跳转让设备自动处理）

        Returns:
            是否成功
        """
        if self.funcname_dbg:
            logging.debug('cmd_mem_end')

        # MEM_END 数据格式（参考 iBurn2）：
        # [option(4字节)] + [address(4字节)]
        # option = 0x00000000 表示 REBOOT
        # address = entry_point 跳转地址
        cmd = get_bytes_hex_list(0, 4) + get_bytes_hex_list(entry_point, 4)
        return self.check_command(self.CMD_MEM_END, cmd, 0) == (True, 0x00)

    def cmd_flash_begin(self, size: int, blocks: int, block_size: int, offset: int, md5: int = 0) -> bool:
        """开始 Flash 写入

        Args:
            size: 数据总大小
            blocks: 块数量
            block_size: 块大小（通常 4096）
            offset: Flash 地址偏移
            md5: MD5 校验值（可选，某些芯片需要）

        Returns:
            是否成功
        """
        if self.funcname_dbg:
            logging.debug('cmd_flash_begin')

        # 参考 iBurn2：FLASH_BEGIN 数据格式为 16 字节（不含 MD5）
        # [size(4字节)] + [blocks(4字节)] + [block_size(4字节)] + [offset(4字节)]
        cmd = get_bytes_hex_list(size, 4) + get_bytes_hex_list(blocks, 4) + \
              get_bytes_hex_list(block_size, 4) + get_bytes_hex_list(offset, 4)

        # checksum 使用 0
        return self.check_command(self.CMD_FLASH_BEGIN, cmd, 0) == (True, 0x00)

    def cmd_flash_block(self, data: list, data_len: int, seq: int) -> dict:
        """写入 Flash 块"""
        if self.funcname_dbg:
            logging.debug('cmd_flash_block')
        cmd = get_bytes_hex_list(data_len, 4) + get_bytes_hex_list(seq, 4) + \
              get_bytes_hex_list(0, 4) + get_bytes_hex_list(0, 4) + data
        ret = self.check_command(self.CMD_FLASH_DATA, cmd, checksum(data), 1.0)
        if isinstance(ret, dict) and ret.get('res_ret'):
            if ret['res_ret']['error'] != 0x00:
                logging.error(f'错误: 数据块 {seq} 写失败: {ret["res_ret"]["error"]:02X}')
            if ret['res_ret']['error'] == 0x0A:
                time.sleep(0.5)
        return ret

    def cmd_flash_finish(self) -> bool:
        """结束 Flash 写入"""
        if self.funcname_dbg:
            logging.debug('cmd_flash_finish')
        cmd = get_bytes_hex_list(0, 4) + get_bytes_hex_list(0, 4)
        return self.check_command(self.CMD_FLASH_END, cmd, 0) == (True, 0x00)

    def cmd_flash_md5sum(self, address: int, size: int) -> str:
        """读取 Flash MD5"""
        if self.funcname_dbg:
            logging.debug('cmd_flash_md5sum')
        cmd = get_bytes_hex_list(address, 4) + get_bytes_hex_list(size, 4) + \
              get_bytes_hex_list(0, 4) + get_bytes_hex_list(0, 4)
        ret = self.command(self.CMD_SPI_FLASH_MD5, cmd, 0, 5.0)
        if not ret['ret']:
            return ''
        if ret['res_ret']['size'] < 2:
            logging.error('错误: 串口读取异常')
            return ''
        if ret['res_ret']['error'] != 0:
            logging.error(f'错误: 设备返回异常 {ret["res_ret"]["error"]:02X}{ret["res_ret"]["code"]:02X}')
        return hex(ret['res_ret']['md5'])

    def cmd_flash_md5_challenge(self) -> bool:
        """MD5 挑战"""
        if self.funcname_dbg:
            logging.debug('cmd_flash_md5_challenge')
        return self.check_command(self.CMD_FLASH_MD5_CHALLENGE, [], 0, 5.0) == (True, 0x00)

    def cmd_change_baud(self, baud: int) -> bool:
        """更改波特率

        Args:
            baud: 新波特率

        Returns:
            是否成功
        """
        if self.funcname_dbg:
            logging.debug('cmd_change_baud')

        # ARCS 协议需要发送新波特率和旧波特率（共8字节）
        # 格式: [new_baud(4字节)] + [old_baud(4字节)]
        old_baud = self.serial_thread.baudrate  # 当前波特率
        cmd = get_bytes_hex_list(baud, 4) + get_bytes_hex_list(old_baud, 4)

        ret = self.command(self.CMD_CHANGE_BAUDRATE, cmd, 0, 1.0)
        if not ret['ret']:
            return False
        return self.serial_thread.reload(baud)

    # ==================== 新增命令（多芯片支持） ====================

    def cmd_set_sys_clk(self, config: dict = None) -> bool:
        """VENUSA 时钟配置

        Args:
            config: 时钟配置字典，包含 p11_clk_div_t 结构字段
                   默认使用 0xFF 表示自动配置

        Returns:
            是否成功
        """
        if self.funcname_dbg:
            logging.debug('cmd_set_sys_clk')
        # p11_clk_div_t 结构：8字节，全部用 0xFF 表示自动配置
        if config is None:
            config = {}
        cmd = [
            config.get('cpu_cfg_para', 0xFF),
            config.get('flash_clk_div', 0xFF),
            config.get('peri_pclk_div', 0xFF),
            config.get('aon_cfg_pclk_div', 0xFF),
            config.get('cmn_peri_pclk_div', 0xFF),
            config.get('reserved', 0xFF),
            config.get('hclk_div', 0xFF),
            config.get('pll_enable_flag', 0xFF),
        ]
        return self.check_command(self.CMD_SET_SYS_CLK, cmd, 0, 1.0) == (True, 0x00)

    def cmd_set_flash_index(self, index: int) -> bool:
        """ARCS_DUAL 双 Flash 选择

        Args:
            index: Flash 索引
                   0 = Flash0
                   1 = Flash1
                   0xFF = 释放选择（烧录完成后）

        Returns:
            是否成功
        """
        if self.funcname_dbg:
            logging.debug('cmd_set_flash_index')
        # 4字节：index + 3字节保留
        cmd = get_bytes_hex_list(index, 4)
        return self.check_command(self.CMD_SET_FLASH_INDEX, cmd, 0) == (True, 0x00)

    def cmd_read_chip_id(self) -> str:
        """读取芯片 ID（8字节）

        Returns:
            芯片 ID 字符串（16字符十六进制）或空字符串（失败）
        """
        if self.funcname_dbg:
            logging.debug('cmd_read_chip_id')
        ret = self.command(self.CMD_READ_CHIP_ID, [], 0, 0.5)
        if not ret['ret']:
            return ''
        # 响应包含：status(2字节) + chip_id(8字节)
        res_ret = ret.get('res_ret', {})
        if res_ret.get('error', 0) != 0:
            return ''
        # 需要从响应中提取 chip_id
        # 暂时返回空，后续完善
        return ''

    def cmd_read_flash_id(self) -> int:
        """读取 Flash ID

        Returns:
            Flash ID（3字节厂商+容量信息）或 0（失败）
        """
        if self.funcname_dbg:
            logging.debug('cmd_read_flash_id')
        ret = self.command(self.CMD_READ_FLASH_ID, [], 0, 0.5)
        if not ret['ret']:
            return 0
        return ret['res_ret'].get('value', 0)

    def cmd_flash_erase_region(self, address: int, size: int) -> bool:
        """擦除指定 Flash 区域

        Args:
            address: 起始地址
            size: 擦除大小（需 4K 对齐）

        Returns:
            是否成功
        """
        if self.funcname_dbg:
            logging.debug('cmd_flash_erase_region')
        cmd = get_bytes_hex_list(address, 4) + get_bytes_hex_list(size, 4)
        # 擦除耗时较长，按 MB 计算超时
        timeout = max(5.0, size / (1024 * 1024) * 10.0)
        return self.check_command(self.CMD_FLASH_ERASE_REGION, cmd, 0, timeout) == (True, 0x00)

    # ==================== eMMC 命令 ====================

    def cmd_emmc_get_info(self) -> dict:
        """获取 eMMC 信息

        Returns:
            card_info_t 信息字典：
            - sctcnts: 扇区总数
            - sctsize: 扇区大小
            - erasize: 擦除块大小
            - cardtype: 卡类型
        """
        if self.funcname_dbg:
            logging.debug('cmd_emmc_get_info')
        ret = self.command(self.CMD_EMMC_GET_INFO, [], 0, 1.0)
        if not ret['ret']:
            return {}
        # 解析响应中的 card_info_t 结构
        # 暂时返回空字典
        return {}

    def cmd_emmc_begin(self, size: int, blocks: int, block_size: int, offset: int) -> bool:
        """开始 eMMC 写入

        Args:
            size: 总大小
            blocks: 块数
            block_size: 块大小
            offset: 偏移地址

        Returns:
            是否成功
        """
        if self.funcname_dbg:
            logging.debug('cmd_emmc_begin')
        cmd = get_bytes_hex_list(size, 4) + get_bytes_hex_list(blocks, 4) + \
              get_bytes_hex_list(block_size, 4) + get_bytes_hex_list(offset, 4)
        return self.check_command(self.CMD_EMMC_BEGIN, cmd, 0) == (True, 0x00)

    def cmd_emmc_block(self, data: list, data_len: int, seq: int) -> dict:
        """写入 eMMC 块

        Args:
            data: 数据字节列表
            data_len: 数据长度
            seq: 块序号

        Returns:
            响应结果
        """
        if self.funcname_dbg:
            logging.debug('cmd_emmc_block')
        cmd = get_bytes_hex_list(data_len, 4) + get_bytes_hex_list(seq, 4) + \
              get_bytes_hex_list(0, 4) + get_bytes_hex_list(0, 4) + data
        ret = self.check_command(self.CMD_EMMC_DATA, cmd, checksum(data), 1.0)
        if isinstance(ret, dict) and ret.get('ret'):
            if ret['res_ret'].get('error') == 0x0A:
                time.sleep(0.25)
            return ret
        return {'ret': False, 'res_ret': {'error': 0xFF}}

    def cmd_emmc_finish(self) -> bool:
        """结束 eMMC 写入

        Returns:
            是否成功
        """
        if self.funcname_dbg:
            logging.debug('cmd_emmc_finish')
        cmd = get_bytes_hex_list(0, 4)
        return self.check_command(self.CMD_EMMC_END, cmd, 0, 2.0) == (True, 0x00)

    def cmd_emmc_md5(self, address: int, size: int) -> str:
        """计算 eMMC 区域 MD5

        Args:
            address: 起始地址
            size: 大小

        Returns:
            MD5 字符串或空字符串
        """
        if self.funcname_dbg:
            logging.debug('cmd_emmc_md5')
        cmd = get_bytes_hex_list(address, 4) + get_bytes_hex_list(size, 4) + \
              get_bytes_hex_list(0, 4) + get_bytes_hex_list(0, 4)
        timeout = max(5.0, size / (1024 * 1024) * 1.0)
        ret = self.command(self.CMD_EMMC_MD5, cmd, 0, timeout)
        if not ret['ret']:
            return ''
        # 需要从响应中提取 MD5
        return hex(ret['res_ret'].get('md5', 0))