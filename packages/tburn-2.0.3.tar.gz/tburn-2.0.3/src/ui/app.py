"""主应用"""
import asyncio
import logging
import os
import sys
from datetime import datetime
from pathlib import Path

from textual.app import App, ComposeResult
from textual.containers import Container
from textual.widgets import Header, Footer
from textual.binding import Binding

# 本地模块
from state import State, Status, _state
from firmware import FirmwareInfo
from config import load_config, save_config
from protocol import ReadSerialThread, CSKBurnProtocolClient, read_hex_from_bin, getmd5_fromlist
from protocol.chips import ChipType, BurnTarget, get_chip_config, get_load_addr, needs_sys_clk, supports_emmc, supports_dual_flash, needs_erase_before_write, chip_to_str

# 日志重定向（关键：将所有协议模块日志重定向到TUI）
from logging_handler import configure_logging, bind_tui_logging, unbind_tui_logging, restore_streams, install_exception_hook

# UI 模块
from ui.screens import PortSelectScreen, FirmwareEditScreen, ChipSelectScreen, TargetSelectScreen, FlashIndexSelectScreen, BaudrateSelectScreen
from ui.widgets import StatusPanel, ProgressPanel, FirmwarePanel, CommandPanel, BurnPanel, LogPanel

# 检查 pyserial
try:
    import serial
    from serial.tools import list_ports
    HAS_SERIAL = True
except ImportError:
    HAS_SERIAL = False
    logging.warning("pyserial 未安装，串口功能将不可用")


class TBurn(App):
    """TBurn TUI 应用

    模块化设计的串口烧录工具界面。
    支持鼠标点击操作各元素。
    """

    CSS = """
    Screen { layout: vertical; }
    Header { dock: top; }
    Footer { dock: bottom; }
    #main { layout: horizontal; height: 1fr; }
    #left { width: 1fr; layout: vertical; padding: 1; }
    #right { width: 2fr; border-left: solid green; padding: 1; }

    /* 固件面板样式 - 蓝色边框 */
    FirmwarePanel {
        height: auto;
        min-height: 5;
    }

    /* 烧录操作面板样式 - 黄色边框 */
    BurnPanel {
        height: auto;
        min-height: 4;
    }

    /* 命令面板样式 - 紫色边框 */
    CommandPanel {
        height: auto;
        min-height: 2;
    }
    """

    BINDINGS = [
        Binding("c", "connect", "连接"),
        Binding("e", "enter_burn", "烧录模式"),
        Binding("r", "read_id", "读ID"),
        Binding("v", "verify", "校验"),
        Binding("b", "burn", "烧录"),
        Binding("p", "select_port", "选串口"),
        Binding("t", "select_chip", "选芯片"),
        Binding("g", "select_target", "选目标"),
        Binding("a", "toggle_auto_burn", "自动烧录"),
        Binding("s", "save_log", "保存日志"),
        Binding("n", "add_firmware", "新增固件"),
        Binding("d", "delete_firmware", "删除固件"),
        Binding("D", "toggle_debug", "调试模式"),
        Binding("q", "quit", "退出"),
    ]

    def __init__(self, port: str = None, **kwargs):
        super().__init__(**kwargs)

        # 从配置文件加载
        config = load_config()
        _state.port = port or config.get('port')
        _state.baudrate = config.get('baudrate', 1536000)

        # 加载芯片类型和烧录目标
        chip_type_str = config.get('chip_type')
        if chip_type_str:
            # 支持字符串和整数格式
            chip_type_map = {
                'csk6': ChipType.CSK6,
                'arcs': ChipType.ARCS,
                'arcs_dual': ChipType.ARCS_DUAL,
                'venusa': ChipType.VENUSA,
                6: ChipType.CSK6,
            }
            # 处理整数字符串
            if isinstance(chip_type_str, str) and chip_type_str.isdigit():
                chip_type_str = int(chip_type_str)
            _state.chip_type = chip_type_map.get(chip_type_str, ChipType.CSK6)

        target_str = config.get('burn_target')
        if target_str:
            if target_str == 'emmc':
                _state.burn_target = BurnTarget.EMMC
            elif target_str == 'flash':
                _state.burn_target = BurnTarget.FLASH

        _state.flash_index = config.get('flash_index', 0)
        _state.auto_burn_mode = config.get('auto_burn_mode', 'manual')

        # 加载固件列表
        fw_list = config.get('firmwares', [])
        for fw_dict in fw_list:
            fw = FirmwareInfo.from_dict(fw_dict)
            _state.firmwares.append(fw)

        # 加载上次固件路径
        _state.last_firmware_dir = config.get('last_firmware_dir')

        # 重新加载 burner（根据芯片类型）
        _state._load_burner()

        self._save_config()

    def compose(self) -> ComposeResult:
        """构建界面"""
        yield Header()
        with Container(id="main"):
            with Container(id="left"):
                yield StatusPanel(id="status")
                yield ProgressPanel(id="progress")
                yield FirmwarePanel(id="firmwares")
                yield BurnPanel(id="burn_op")
                yield CommandPanel(id="commands")
            with Container(id="right"):
                yield LogPanel(id="log")
        yield Footer()

    def on_mount(self):
        """初始化"""
        # ⚠️ 关键：配置日志重定向，将所有协议模块日志重定向到TUI LogPanel
        # 这是在TUI启动前必须完成的，否则外部日志会污染终端显示
        configure_logging(log_callback=self.write_log, debug_mode=_state.dump_dbg)

        # 安装异常钩子，捕获未处理的异常
        install_exception_hook(log_callback=self.write_log)

        # 延迟刷新面板（等待 widget 完全挂载）
        self.set_timer(0.1, self._refresh_all)

        # 设置自动进入烧录模式状态
        burn_panel = self.query_one(BurnPanel)
        burn_panel.auto_enter_burn = _state.auto_enter_burn

        # 显示提示
        self.write_log("cyan", "TBurn TUI 已启动")
        self.write_log("dim", "所有日志已重定向到此面板")
        if _state.auto_enter_burn:
            self.write_log("dim", "自动进入烧录模式已开启（烧录时自动控制 RTS/DTR）")

    # ==================== 状态面板点击事件 ====================
    def on_status_panel_chip_clicked(self, event: StatusPanel.ChipClicked):
        """芯片字段点击"""
        self.action_select_chip()

    def on_status_panel_target_clicked(self, event: StatusPanel.TargetClicked):
        """目标字段点击"""
        self.action_select_target()

    def on_status_panel_port_clicked(self, event: StatusPanel.PortClicked):
        """端口字段点击"""
        self.action_select_port()

    def on_status_panel_baudrate_clicked(self, event: StatusPanel.BaudrateClicked):
        """波特率字段点击"""
        self.push_screen(BaudrateSelectScreen(_state.baudrate),
                        self._on_baudrate_selected)

    # ==================== 烧录操作面板点击事件 ====================
    def on_burn_panel_burn_clicked(self, event: BurnPanel.BurnClicked):
        """烧录操作面板点击"""
        asyncio.create_task(self._do_full_burn())

    def on_burn_panel_auto_enter_burn_toggled(self, event: BurnPanel.AutoEnterBurnToggled):
        """自动进入烧录模式开关切换"""
        _state.auto_enter_burn = event.enabled
        status = "开启" if event.enabled else "关闭"
        self.write_log("cyan", f"自动进入烧录模式: {status}")
        if event.enabled:
            self.write_log("dim", "烧录时会自动控制 RTS/DTR 让芯片进入烧录模式")
        else:
            self.write_log("dim", "烧录时需手动让芯片进入烧录模式")

    async def _do_full_burn(self):
        """执行完整烧录流程"""
        # 1. 检查固件列表
        fw_list = _state.get_burnable_firmwares()
        if not fw_list:
            self.write_log("yellow", "⚠️ 无固件可烧录，请先添加固件")
            return

        # 2. 检查串口
        if not _state.port:
            self.write_log("yellow", "⚠️ 请先选择串口")
            return

        # 3. 初始化串口
        self.write_log("cyan", "=== 步骤1: 初始化串口 ===")
        if not self._init_serial():
            self.write_log("red", "❌ 串口初始化失败")
            return

        # 4. 自动进入烧录模式（控制 RTS/DTR）
        if _state.auto_enter_burn:
            self.write_log("cyan", "=== 步骤2: 自动进入烧录模式 ===")
            self.write_log("dim", "执行 RTS/DTR 序列让芯片进入烧录模式...")

            # 执行 iBurn2 复位序列
            _state.serial_thread.reset_sequence(_state.chip_type, 100)
            await asyncio.sleep(0.2)  # 等待设备稳定

            # 同步设备
            self.write_log("cyan", "=== 步骤3: 同步设备 ===")
            sync_success = False
            for attempt in range(10):
                if _state.protocol_client.cmd_sync(0.3):
                    sync_success = True
                    self.write_log("green", f"✅ 设备同步成功 (尝试 {attempt+1})")
                    _state.connected = True
                    break
                await asyncio.sleep(0.1)

            if not sync_success:
                self.write_log("red", "❌ 设备同步失败")
                self.write_log("yellow", "请确认设备已正确连接")
                return

            # 读取芯片 ID
            chip_id = _state.protocol_client.cmd_read_chip_id()
            if chip_id:
                self.write_log("green", f"✅ 芯片 ID: {chip_id}")
                _state.chip_id = chip_id
                self.query_one(StatusPanel).update_content()

        else:
            # 手动模式：等待用户手动让芯片进入烧录模式
            self.write_log("cyan", "=== 步骤2: 同步设备 (手动模式) ===")
            self.write_log("yellow", "请手动让芯片进入烧录模式（按复位键或断电重启）")

            sync_success = False
            for attempt in range(30):  # 等待 30 次，约 3 秒
                if _state.protocol_client.cmd_sync(0.1):
                    sync_success = True
                    self.write_log("green", f"✅ 设备同步成功")
                    _state.connected = True
                    break
                await asyncio.sleep(0.1)

            if not sync_success:
                self.write_log("red", "❌ 设备同步超时")
                self.write_log("yellow", "请手动复位设备使其进入烧录模式")
                return

        # 5. 进入烧录模式（加载 Burner）
        self.write_log("cyan", "=== 步骤4: 加载 Burner ===")
        await self._do_enter_burn()
        if not _state.in_burn_mode:
            self.write_log("red", "❌ 加载 Burner 失败")
            return

        # 6. 烧录固件
        self.write_log("cyan", "=== 步骤5: 烧录固件 ===")
        await self._do_burn_with_status(fw_list)

        # 7. 复位设备（启动应用）
        self.write_log("cyan", "=== 步骤6: 复位设备 ===")
        _state.serial_thread.reset_device(_state.chip_type, 100)
        self.write_log("green", "✅ 设备已复位，固件启动")

        # 8. 关闭串口
        self.write_log("cyan", "=== 步骤7: 关闭串口 ===")
        if _state.serial_thread:
            _state.serial_thread.deinit_serial()
            self.write_log("green", "✅ 串口已关闭")

        # 重置状态
        _state.connected = False
        _state.in_burn_mode = False
        _state.status = Status.UNINIT
        self.query_one(StatusPanel).update_content()
        self.write_log("green", "=== 烧录流程完成 ===")

    async def _do_burn_with_status(self, fw_list):
        """执行烧录并更新状态"""
        _state.status = Status.BURNING
        self.query_one(StatusPanel).refresh()

        total_fw = len(fw_list)

        for fw_idx, fw in enumerate(fw_list):
            fw.burn_status = "烧录中"  # 临时状态
            self.query_one(FirmwarePanel).update_content()

            self.write_log("cyan",
                f"烧录 {fw.name} ({fw_idx+1}/{total_fw})")
            self.write_log("dim",
                f"  地址: 0x{fw.addr:X}, 大小: {fw.size/1024:.1f}KB")

            try:
                # 加载固件数据
                fw_data = read_hex_from_bin(fw.file_path)
                fw_len = len(fw_data)

                # ARCS芯片需要显式擦除Flash区域
                # 计算对齐后的大小（向上对齐到Flash扇区大小4096字节）
                flash_align = CSKBurnProtocolClient.FLASH_BLOCK_SIZE  # 4096
                aligned_size = ((fw_len + flash_align - 1) // flash_align) * flash_align

                if _state.chip_type in [ChipType.ARCS, ChipType.ARCS_DUAL, ChipType.VENUSA]:
                    self.write_log("cyan", f"擦除 Flash 区域 0x{fw.addr:X}-0x{fw.addr + aligned_size:X}...")
                    self._set_progress(0, 1, f"擦除 {fw.name}")

                    # 执行擦除（可能需要较长时间）
                    if not _state.protocol_client.cmd_flash_erase_region(fw.addr, aligned_size):
                        self.write_log("red", f"❌ Flash 区域擦除失败")
                        fw.burn_status = "×"
                        burn_success = False
                        continue

                    self.write_log("green", f"✅ Flash 区域擦除完成")
                    self._set_progress(1, 1, f"擦除 {fw.name}")

                # 分段烧录
                bunch_size = 191
                total_blocks = _state.protocol_client.BLOCKS(
                    fw_len,
                    CSKBurnProtocolClient.FLASH_BLOCK_SIZE
                )
                total_bunches = int((total_blocks + bunch_size - 1) / bunch_size)

                burn_success = True

                for bunch_idx in range(total_bunches):
                    bunch_start = bunch_idx * bunch_size * CSKBurnProtocolClient.FLASH_BLOCK_SIZE
                    bunch_len = min(bunch_size * CSKBurnProtocolClient.FLASH_BLOCK_SIZE,
                                   fw_len - bunch_start)
                    bunch_blocks = _state.protocol_client.BLOCKS(
                        bunch_len,
                        CSKBurnProtocolClient.FLASH_BLOCK_SIZE
                    )
                    bunch_addr = fw.addr + bunch_start
                    bunch_md5 = getmd5_fromlist(
                        fw_data[bunch_start:bunch_start + bunch_len]
                    )

                    self.write_log("dim",
                        f"  分段 {bunch_idx+1}/{total_bunches}: 0x{bunch_addr:X}")

                    # FLASH_BEGIN
                    if not _state.protocol_client.cmd_flash_begin(
                        bunch_len, bunch_blocks,
                        CSKBurnProtocolClient.FLASH_BLOCK_SIZE,
                        bunch_addr
                    ):
                        self.write_log("red", "❌ FLASH_BEGIN 失败")
                        burn_success = False
                        break

                    # FLASH_DATA
                    self._set_progress(0, bunch_blocks,
                        f"写入 {fw.name} 分段 {bunch_idx+1}")

                    for block_idx in range(bunch_blocks):
                        offset = CSKBurnProtocolClient.FLASH_BLOCK_SIZE * block_idx
                        length = min(CSKBurnProtocolClient.FLASH_BLOCK_SIZE,
                                   bunch_len - offset)

                        # 重试机制
                        ret = None
                        for retry in range(5):
                            ret = _state.protocol_client.cmd_flash_block(
                                fw_data[bunch_start + offset:bunch_start + offset + length],
                                length, block_idx
                            )

                            if isinstance(ret, dict) and ret.get('ret'):
                                break

                            if retry > 0:
                                self.write_log("yellow",
                                    f"  重试 block {block_idx} ({retry}/5)")
                            await asyncio.sleep(0.1)

                        if not isinstance(ret, dict) or not ret.get('ret'):
                            self.write_log("red",
                                f"❌ FLASH_DATA block {block_idx} 失败")
                            burn_success = False
                            break

                        self._set_progress(block_idx + 1, bunch_blocks,
                            f"写入 {fw.name}")
                        await asyncio.sleep(0.005)

                    if not burn_success:
                        break

                    await asyncio.sleep(0.1)

                # 烧录完成后进行MD5校验
                if burn_success:
                    self.write_log("cyan", f"校验 {fw.name}...")
                    self._set_progress(0, 1, f"校验 {fw.name}")

                    # 计算本地固件MD5
                    expected_md5 = f"{getmd5_fromlist(fw_data):032x}"

                    # 读取设备上的MD5
                    md5_result = _state.protocol_client.cmd_flash_md5sum(fw.addr, fw_len)

                    if md5_result:
                        # 解析设备返回的MD5
                        actual_md5 = md5_result.replace('0x', '').lstrip('0').zfill(32)

                        if expected_md5 == actual_md5:
                            fw.burn_status = "√"
                            self.write_log("green", f"✅ {fw.name} MD5校验通过")
                            self.write_log("dim", f"  MD5: {expected_md5}")
                        else:
                            fw.burn_status = "×"
                            burn_success = False
                            self.write_log("red", f"❌ {fw.name} MD5校验失败")
                            self.write_log("dim", f"  期望: {expected_md5}")
                            self.write_log("dim", f"  实际: {actual_md5}")
                    else:
                        fw.burn_status = "×"
                        burn_success = False
                        self.write_log("red", f"❌ {fw.name} 无法获取MD5")

                    self._set_progress(1, 1, f"校验 {fw.name}")

                # 更新烧录状态
                if burn_success:
                    fw.burn_status = "√"
                    self.write_log("green", f"✅ {fw.name} 烧录成功")
                else:
                    fw.burn_status = "×"
                    self.write_log("red", f"❌ {fw.name} 烧录失败")

            except Exception as e:
                fw.burn_status = "×"
                self.write_log("red", f"❌ {fw.name} 烧录异常: {e}")

            self.query_one(FirmwarePanel).update_content()
            self._save_config()

        _state.status = Status.ENTERED
        self.write_log("green", "=== 烧录流程完成 ===")
        self.query_one(StatusPanel).refresh()
        self._set_progress(0, 100, "")

        self.write_log("cyan", "TBurn TUI 已启动")
        self.write_log("gray", f"Python {sys.version.split()[0]}")
        self.write_log("cyan" if HAS_SERIAL else "red",
                      f"pyserial: {'已加载' if HAS_SERIAL else '未安装'}")

        # 检查 burner
        burner = _state.get_firmware_by_name('burner')
        if burner and burner.file_path and os.path.isfile(burner.file_path):
            self.write_log("green", f"✅ burner.img 已加载 ({burner.size/1024:.1f}KB)")

        if _state.port:
            self.write_log("cyan", f"端口: {_state.port} (上次配置)")

    def _refresh_all(self):
        """刷新所有面板"""
        self.query_one(StatusPanel).update_content()
        self.query_one(ProgressPanel).update_content()
        self.query_one(FirmwarePanel).update_content()
        self.query_one(BurnPanel).update_content()
        self.query_one(CommandPanel).update_content()

    def _set_progress(self, val: int, max_val: int, msg: str = ""):
        """设置进度"""
        _state.progress_val = val
        _state.progress_max = max_val
        _state.progress_msg = msg
        self.query_one(ProgressPanel).update_content()

    def _save_config(self):
        """保存配置"""
        config = {
            'port': _state.port,
            'baudrate': _state.baudrate,
            'chip_type': _state.chip_type.value,
            'burn_target': _state.burn_target.value,
            'flash_index': _state.flash_index,
            'auto_burn_mode': _state.auto_burn_mode,
            'last_firmware_dir': _state.last_firmware_dir,
            'firmwares': [
                fw.to_dict() for fw in _state.firmwares
            ]
        }
        save_config(config)

    def write_log(self, color: str, msg: str):
        """写日志"""
        log_panel = self.query_one(LogPanel)
        log_panel.write_log(color, msg)

    # ==================== 串口操作 ====================

    def action_select_port(self):
        """选择串口"""
        if not HAS_SERIAL:
            self.write_log("red", "❌ 缺少 pyserial 模块")
            self.write_log("yellow", "请安装: pip install pyserial")
            return

        try:
            ports = [p.device for p in list_ports.comports()]
            self.write_log("cyan", f"发现 {len(ports)} 个串口")

            if not ports:
                self.write_log("yellow", "⚠️ 无串口设备")
                return

            self.push_screen(PortSelectScreen(ports), self._on_port_selected)
        except Exception as e:
            self.write_log("red", f"❌ 错误: {e}")

    def _on_port_selected(self, port):
        """串口选择回调"""
        if port:
            _state.port = port
            self.write_log("green", f"✅ 已选择: {port}")
            self.query_one(StatusPanel).update_content()
            self._save_config()
        else:
            self.write_log("yellow", "⚠️ 已取消选择")
        self.set_focus(None)

    def _on_baudrate_selected(self, baudrate):
        """波特率选择回调"""
        if baudrate:
            _state.baudrate = baudrate
            self.write_log("green", f"✅ 波特率: {baudrate}")
            self.query_one(StatusPanel).update_content()
            self._save_config()
        else:
            self.write_log("yellow", "⚠️ 已取消选择")
        self.set_focus(None)

    def _init_serial(self) -> bool:
        """初始化串口"""
        if not _state.port:
            self.write_log("yellow", "⚠️ 请先选择串口")
            return False

        if not HAS_SERIAL:
            self.write_log("red", "❌ pyserial 模块未加载")
            return False

        # 每次烧录都重新创建线程对象（Python线程只能start一次）
        # 先关闭旧的串口和线程
        if _state.serial_thread:
            _state.serial_thread.deinit_serial()
            _state.serial_thread.notice_end_read()

        # 创建新的线程对象
        _state.serial_thread = ReadSerialThread(_state.dump_dbg, _state.port)

        # 先用 115200 初始化
        try:
            if not _state.serial_thread.init_serial(_state.port, 115200):
                self.write_log("red", f"❌ 无法打开串口 {_state.port}")
                self.write_log("yellow", "请检查：1.设备是否连接 2.权限是否正确 3.端口是否被占用")
                return False
        except Exception as e:
            self.write_log("red", f"❌ 串口初始化异常: {e}")
            return False

        # 启动线程（新创建的线程对象可以直接启动）
        _state.serial_thread.start()
        _state.serial_thread.mark_start()

        # 创建协议客户端，传入日志回调
        _state.protocol_client = CSKBurnProtocolClient(
            _state.serial_thread,
            dump_dbg=_state.dump_dbg,
            funcname_dbg=_state.dump_dbg,
            log_callback=self._protocol_log_callback
        )

        self.write_log("green", f"✅ 串口已打开: {_state.port}@115200")
        return True

    def _protocol_log_callback(self, direction: str, cmd: int, msg: str):
        """协议日志回调"""
        cmd_names = {
            0x02: "FLASH_BEGIN", 0x03: "FLASH_DATA", 0x04: "FLASH_END",
            0x05: "MEM_BEGIN", 0x06: "MEM_END", 0x07: "MEM_DATA",
            0x08: "SYNC", 0x0a: "READ_REG", 0x0f: "CHANGE_BAUD",
            0x13: "SPI_FLASH_MD5", 0xF2: "MD5_CHALLENGE"
        }
        cmd_name = cmd_names.get(cmd, f"{cmd:02X}")

        if direction == 'REQ':
            self.write_log("yellow", f"→ {cmd_name}")
        else:
            self.write_log("dim", f"← {cmd_name}: {msg}")

    # ==================== 协议操作 ====================

    def action_connect(self):
        """连接设备"""
        if not _state.port:
            self.write_log("yellow", "⚠️ 请先选择串口 (P)")
            return

        asyncio.create_task(self._do_connect())

    async def _do_connect(self):
        """执行连接"""
        _state.status = Status.BURNING
        self.query_one(StatusPanel).refresh()

        self.write_log("cyan", "正在初始化串口...")
        if not self._init_serial():
            _state.status = Status.ERROR
            self.query_one(StatusPanel).refresh()
            return

        self.write_log("cyan", f"正在同步设备 ({_state.chip_type.value})...")
        self._set_progress(0, 10, "同步设备...")

        # 执行芯片特定的复位序列
        self.write_log("dim", f"执行复位序列...")
        _state.serial_thread.reset_sequence(_state.chip_type, 100)  # iBurn2 使用 100ms

        await asyncio.sleep(0.2)  # 等待设备稳定

        retry_count = 10
        for i in range(retry_count):
            self._set_progress(i, retry_count, f"同步尝试 {i+1}/{retry_count}")
            await asyncio.sleep(0.05)

            if _state.protocol_client.cmd_sync(0.3):
                self.write_log("green", "✅ 设备同步成功")
                _state.connected = True
                _state.status = Status.CONNECTED
                self.query_one(StatusPanel).refresh()
                self._set_progress(0, 100, "")
                return

        self.write_log("red", "❌ 设备同步失败")
        self.write_log("yellow", "请确认设备已连接并处于烧录模式")
        _state.status = Status.ERROR
        self.query_one(StatusPanel).refresh()
        self._set_progress(0, 100, "")

    def action_enter_burn(self):
        """进入烧录模式"""
        if not _state.connected:
            self.write_log("yellow", "⚠️ 请先连接设备 (C)")
            return

        asyncio.create_task(self._do_enter_burn())

    async def _do_enter_burn(self):
        """执行进入烧录模式"""
        _state.status = Status.BURNING
        self.query_one(StatusPanel).refresh()

        # 获取 burner（根据芯片类型）
        burner = _state.burner
        if not burner or not burner.file_path or not os.path.isfile(burner.file_path):
            self.write_log("red", "❌ 缺少 burner 文件")
            _state.status = Status.ERROR
            self.query_one(StatusPanel).refresh()
            return

        # 获取芯片特定的 load_addr
        load_addr = get_load_addr(_state.chip_type)

        self.write_log("cyan", f"正在加载 burner ({burner.size/1024:.1f}KB)...")
        self.write_log("dim", f"芯片: {_state.chip_type.value}, load_addr: 0x{load_addr:X}")

        # 加载 burner 数据
        burner_data = read_hex_from_bin(burner.file_path)
        burner_len = len(burner_data)
        blocks = _state.protocol_client.BLOCKS(
            burner_len,
            CSKBurnProtocolClient.RAM_BLOCK_SIZE
        )

        # CSK6 和 ARCS/VENUSA 支持 ROM 波特率切换
        if _state.chip_type in [ChipType.CSK6, ChipType.ARCS, ChipType.ARCS_DUAL, ChipType.VENUSA] \
           and _state.baudrate != 115200:
            # 尝试在 ROM 阶段切换波特率（上限 3000000）
            rom_baud = min(_state.baudrate, 3000000)
            self.write_log("dim", f"ROM 波特率切换: {rom_baud}")
            if _state.protocol_client.cmd_change_baud(rom_baud):
                await asyncio.sleep(0.1)
                # 同步确认
                if _state.protocol_client.cmd_sync(2):
                    self.write_log("green", f"✅ ROM 波特率切换成功: {rom_baud}")
                else:
                    self.write_log("yellow", "⚠️ ROM 波特率切换失败，继续使用默认")

        # MEM_BEGIN（使用芯片特定的 load_addr）
        self.write_log("dim", f"MEM_BEGIN: {burner_len} bytes, {blocks} blocks, addr=0x{load_addr:X}")
        if not _state.protocol_client.cmd_mem_begin(
            burner_len, blocks,
            CSKBurnProtocolClient.RAM_BLOCK_SIZE, load_addr
        ):
            self.write_log("red", "❌ MEM_BEGIN 失败")
            _state.status = Status.ERROR
            self.query_one(StatusPanel).refresh()
            return

        # MEM_DATA
        self._set_progress(0, blocks, "写入 burner...")
        for i in range(blocks):
            offset = CSKBurnProtocolClient.RAM_BLOCK_SIZE * i
            length = min(CSKBurnProtocolClient.RAM_BLOCK_SIZE, burner_len - offset)

            if not _state.protocol_client.cmd_mem_block(
                burner_data[offset:offset+length], length, i
            ):
                self.write_log("red", f"❌ MEM_DATA block {i} 失败")
                _state.status = Status.ERROR
                self.query_one(StatusPanel).refresh()
                return

            self._set_progress(i + 1, blocks, f"写入 burner {i+1}/{blocks}")
            await asyncio.sleep(0.01)

        # MEM_END（跳转到 burner）
        self.write_log("dim", f"MEM_END: 跳转到 0x{load_addr:X}")
        if not _state.protocol_client.cmd_mem_end(load_addr):
            self.write_log("red", "❌ MEM_END 失败")
            _state.status = Status.ERROR
            self.query_one(StatusPanel).refresh()
            return

        # 重要：ROM 波特率切换后，burner 启动时使用 115200
        # 需要切换回 115200 再同步 burner（参考 iBurn2）
        if _state.baudrate != 115200:
            self.write_log("dim", "切换回 115200 以同步 Burner...")
            _state.serial_thread.reload(115200)
            await asyncio.sleep(0.1)

        self.write_log("cyan", "等待 burner 启动...")
        await asyncio.sleep(1.0)  # 增加等待时间

        # 清空串口缓冲区
        _state.serial_thread.swap()
        if _state.serial_thread.serial:
            try:
                _state.serial_thread.serial.reset_input_buffer()
            except:
                pass

        # 同步 Burner（多次尝试）
        sync_success = False
        for attempt in range(20):
            if _state.protocol_client.cmd_sync(0.5):
                sync_success = True
                self.write_log("green", f"✅ Burner 同步成功 (尝试 {attempt+1})")
                break
            await asyncio.sleep(0.1)

        if not sync_success:
            self.write_log("red", "❌ 无法识别设备 (Burner 同步失败)")
            _state.status = Status.ERROR
            self.query_one(StatusPanel).refresh()
            return

        # VENUSA: 需要时钟配置
        if needs_sys_clk(_state.chip_type):
            self.write_log("cyan", "VENUSA: 设置系统时钟...")
            if _state.protocol_client.cmd_set_sys_clk():
                self.write_log("green", "✅ 时钟配置成功")
            else:
                self.write_log("yellow", "⚠️ 时钟配置失败，继续尝试")

        # ARCS_DUAL: 设置 Flash 索引
        if supports_dual_flash(_state.chip_type):
            self.write_log("cyan", f"ARCS_DUAL: 选择 Flash{_state.flash_index}")
            if _state.protocol_client.cmd_set_flash_index(_state.flash_index):
                self.write_log("green", f"✅ Flash 索引设置成功")
            else:
                self.write_log("yellow", "⚠️ Flash 索引设置失败")

        # 更改波特率
        self.write_log("cyan", f"正在更改波特率到 {_state.baudrate}...")
        if not _state.protocol_client.cmd_change_baud(_state.baudrate):
            self.write_log("yellow", "⚠️ 波特率更改失败，继续使用 115200")
        else:
            self.write_log("green", f"✅ 波特率已更改: {_state.baudrate}")

        # 再次同步
        for i in range(5):
            await asyncio.sleep(0.1)
            if _state.protocol_client.cmd_sync(0.3):
                self.write_log("green", "✅ 高速同步成功")
                break

        _state.in_burn_mode = True
        _state.status = Status.ENTERED
        self.write_log("green", "✅ 进入烧录模式成功")
        self.query_one(StatusPanel).refresh()
        self._set_progress(0, 100, "")

    def action_read_id(self):
        """读取芯片 ID"""
        if not _state.in_burn_mode:
            self.write_log("yellow", "⚠️ 请先进入烧��模式 (E)")
            return

        asyncio.create_task(self._do_read_id())

    async def _do_read_id(self):
        """执行读取芯片 ID"""
        self.write_log("cyan", "正在读取芯片 ID...")
        self._set_progress(0, 2, "读取芯片 ID...")

        EFUSE_BASE = 0xF1800000

        id1 = _state.protocol_client.cmd_read_reg(EFUSE_BASE + 0x80 + 0x0A)
        self._set_progress(1, 2, "读取芯片 ID...")
        await asyncio.sleep(0.1)

        id0 = _state.protocol_client.cmd_read_reg(EFUSE_BASE + 0x80 + 0x0E)

        if isinstance(id0, int) and isinstance(id1, int):
            _state.chip_id = f"{id0:08x}{id1:08x}"
            self.write_log("green", f"✅ 芯片 ID: {_state.chip_id}")
        else:
            self.write_log("red", "❌ 读取芯片 ID 失败")

        self.query_one(StatusPanel).refresh()
        self._set_progress(0, 100, "")

    def action_verify(self):
        """校验固件"""
        if not _state.in_burn_mode:
            self.write_log("yellow", "⚠️ 请先进入烧录模式 (E)")
            return

        asyncio.create_task(self._do_verify())

    async def _do_verify(self):
        """执行校验"""
        _state.status = Status.VERIFYING
        self.query_one(StatusPanel).refresh()

        fw_list = _state.get_burnable_firmwares()
        if not fw_list:
            self.write_log("yellow", "⚠️ 无固件可校验")
            _state.status = Status.ENTERED
            self.query_one(StatusPanel).refresh()
            return

        self._set_progress(0, len(fw_list), "校验固件...")

        for i, fw in enumerate(fw_list):
            self.write_log("cyan",
                f"校验 {fw.name} (地址 0x{fw.addr:X}, 大小 {fw.size/1024:.1f}KB)")

            md5_result = _state.protocol_client.cmd_flash_md5sum(fw.addr, fw.size)

            if md5_result:
                expected_md5 = f"{fw.md5:032x}"
                actual_md5 = md5_result.replace('0x', '').lstrip('0').zfill(32)

                if expected_md5 == actual_md5:
                    self.write_log("green", f"✅ {fw.name} MD5 校验通过")
                else:
                    self.write_log("red", f"❌ {fw.name} MD5 不匹配")
                    self.write_log("dim", f"  期望: {expected_md5}")
                    self.write_log("dim", f"  实际: {actual_md5}")
            else:
                self.write_log("yellow", f"⚠️ {fw.name} 无法获取 MD5")

            self._set_progress(i + 1, len(fw_list), f"校验 {fw.name}")
            await asyncio.sleep(0.1)

        _state.status = Status.ENTERED
        self.write_log("green", "✅ 校验完成")
        self.query_one(StatusPanel).refresh()
        self._set_progress(0, 100, "")

    def action_burn(self):
        """烧录固件"""
        if not _state.in_burn_mode:
            self.write_log("yellow", "⚠️ 请先进入烧录模式 (E)")
            return

        fw_list = _state.get_burnable_firmwares()
        if not fw_list:
            self.write_log("yellow", "⚠️ 无固件可烧录，请先添加固件 (N)")
            return

        asyncio.create_task(self._do_burn(fw_list))

    async def _do_burn(self, fw_list):
        """执行烧录"""
        _state.status = Status.BURNING
        self.query_one(StatusPanel).refresh()

        total_fw = len(fw_list)

        for fw_idx, fw in enumerate(fw_list):
            self.write_log("cyan",
                f"烧录 {fw.name} ({fw_idx+1}/{total_fw})")
            self.write_log("dim",
                f"  地址: 0x{fw.addr:X}, 大小: {fw.size/1024:.1f}KB")

            # 加载固件数据
            fw_data = read_hex_from_bin(fw.file_path)
            fw_len = len(fw_data)

            # ARCS芯片需要显式擦除Flash区域
            flash_align = CSKBurnProtocolClient.FLASH_BLOCK_SIZE  # 4096
            aligned_size = ((fw_len + flash_align - 1) // flash_align) * flash_align

            if _state.chip_type in [ChipType.ARCS, ChipType.ARCS_DUAL, ChipType.VENUSA]:
                self.write_log("cyan", f"擦除 Flash 区域 0x{fw.addr:X}-0x{fw.addr + aligned_size:X}...")
                self._set_progress(0, 1, f"擦除 {fw.name}")

                if not _state.protocol_client.cmd_flash_erase_region(fw.addr, aligned_size):
                    self.write_log("red", f"❌ Flash 区域擦除失败")
                    _state.status = Status.ERROR
                    self.query_one(StatusPanel).refresh()
                    return

                self.write_log("green", f"✅ Flash 区域擦除完成")
                self._set_progress(1, 1, f"擦除 {fw.name}")

            # 分段烧录
            bunch_size = 191
            total_blocks = _state.protocol_client.BLOCKS(
                fw_len,
                CSKBurnProtocolClient.FLASH_BLOCK_SIZE
            )
            total_bunches = int((total_blocks + bunch_size - 1) / bunch_size)

            for bunch_idx in range(total_bunches):
                bunch_start = bunch_idx * bunch_size * CSKBurnProtocolClient.FLASH_BLOCK_SIZE
                bunch_len = min(bunch_size * CSKBurnProtocolClient.FLASH_BLOCK_SIZE,
                               fw_len - bunch_start)
                bunch_blocks = _state.protocol_client.BLOCKS(
                    bunch_len,
                    CSKBurnProtocolClient.FLASH_BLOCK_SIZE
                )
                bunch_addr = fw.addr + bunch_start
                bunch_md5 = getmd5_fromlist(
                    fw_data[bunch_start:bunch_start + bunch_len]
                )

                self.write_log("dim",
                    f"  分段 {bunch_idx+1}/{total_bunches}: 0x{bunch_addr:X}")

                # FLASH_BEGIN
                if not _state.protocol_client.cmd_flash_begin(
                    bunch_len, bunch_blocks,
                    CSKBurnProtocolClient.FLASH_BLOCK_SIZE,
                    bunch_addr
                ):
                    self.write_log("red", "❌ FLASH_BEGIN 失败")
                    _state.status = Status.ERROR
                    self.query_one(StatusPanel).refresh()
                    return

                # FLASH_DATA
                self._set_progress(0, bunch_blocks,
                    f"写入 {fw.name} 分段 {bunch_idx+1}")

                for block_idx in range(bunch_blocks):
                    offset = CSKBurnProtocolClient.FLASH_BLOCK_SIZE * block_idx
                    length = min(CSKBurnProtocolClient.FLASH_BLOCK_SIZE,
                               bunch_len - offset)

                    # 重试机制
                    for retry in range(5):
                        ret = _state.protocol_client.cmd_flash_block(
                            fw_data[bunch_start + offset:bunch_start + offset + length],
                            length, block_idx
                        )

                        if isinstance(ret, dict) and ret.get('ret'):
                            break

                        if retry > 0:
                            self.write_log("yellow",
                                f"  重试 block {block_idx} ({retry}/5)")
                        await asyncio.sleep(0.1)

                    if not isinstance(ret, dict) or not ret.get('ret'):
                        self.write_log("red",
                            f"❌ FLASH_DATA block {block_idx} 失败")
                        _state.status = Status.ERROR
                        self.query_one(StatusPanel).refresh()
                        return

                    self._set_progress(block_idx + 1, bunch_blocks,
                        f"写入 {fw.name}")
                    await asyncio.sleep(0.005)

                await asyncio.sleep(0.1)

            # 烧录完成后进行MD5校验
            self.write_log("cyan", f"校验 {fw.name}...")
            self._set_progress(0, 1, f"校验 {fw.name}")

            # 计算本地固件MD5
            expected_md5 = f"{getmd5_fromlist(fw_data):032x}"

            # 读取设备上的MD5
            md5_result = _state.protocol_client.cmd_flash_md5sum(fw.addr, fw_len)

            if md5_result:
                # 解析设备返回的MD5
                actual_md5 = md5_result.replace('0x', '').lstrip('0').zfill(32)

                if expected_md5 == actual_md5:
                    self.write_log("green", f"✅ {fw.name} MD5校验通过")
                    self.write_log("dim", f"  MD5: {expected_md5}")
                else:
                    self.write_log("red", f"❌ {fw.name} MD5校验失败")
                    self.write_log("dim", f"  期望: {expected_md5}")
                    self.write_log("dim", f"  实际: {actual_md5}")
                    _state.status = Status.ERROR
                    self.query_one(StatusPanel).refresh()
                    return
            else:
                self.write_log("red", f"❌ {fw.name} 无法获取MD5")
                _state.status = Status.ERROR
                self.query_one(StatusPanel).refresh()
                return

            self._set_progress(1, 1, f"校验 {fw.name}")
            self.write_log("green", f"✅ {fw.name} 烧录完成")

        _state.status = Status.ENTERED
        self.write_log("green", "✅ 所有固件烧录完成")
        self.query_one(StatusPanel).refresh()
        self._set_progress(0, 100, "")

    # ==================== 固件管理 ====================

    def action_add_firmware(self):
        """新增固件"""
        self.push_screen(FirmwareEditScreen(FirmwareInfo()),
                        self._on_firmware_added)

    def _on_firmware_added(self, firmware):
        """固件添加回调"""
        if firmware:
            _state.add_firmware(firmware)  # 使用 add_firmware 自动排序并记录路径
            self.write_log("green",
                f"✅ 新增固件: {firmware.name} @ 0x{firmware.addr:X}")
            self.query_one(FirmwarePanel).update_content()
            self._save_config()
        else:
            self.write_log("yellow", "⚠️ 已取消添加")
        self.set_focus(None)

    # ==================== 固件面板点击事件 ====================
    def on_firmware_panel_firmware_edit_requested(self, event: FirmwarePanel.FirmwareEditRequested):
        """固件编辑请求"""
        self.push_screen(FirmwareEditScreen(event.firmware),
                        lambda fw: self._on_firmware_edited(event.index, fw))

    def on_firmware_panel_firmware_delete_requested(self, event: FirmwarePanel.FirmwareDeleteRequested):
        """固件删除请求"""
        if event.index < len(_state.firmwares):
            deleted = _state.firmwares.pop(event.index)
            self.write_log("yellow", f"已删除固件: {deleted.name}")
            self.query_one(FirmwarePanel).update_content()
            self._save_config()

    def on_firmware_panel_firmware_add_requested(self, event: FirmwarePanel.FirmwareAddRequested):
        """固件添加请求"""
        self.action_add_firmware()

    def _on_firmware_edited(self, index: int, firmware):
        """固件编辑回调"""
        if firmware:
            # 更新固件信息
            _state.firmwares[index] = firmware
            _state.firmwares.sort(key=lambda fw: fw.addr)
            self.write_log("green",
                f"✅ 已更新固件: {firmware.name} @ 0x{firmware.addr:X}")
            self.query_one(FirmwarePanel).update_content()
            self._save_config()
        else:
            self.write_log("yellow", "⚠️ 已取消编辑")
        self.set_focus(None)

    def action_delete_firmware(self):
        """删除固件"""
        if not _state.firmwares:
            self.write_log("yellow", "⚠️ 无固件可删除")
            return

        # 删除最后一个固件（按地址排序后的最后一个）
        deleted = _state.firmwares.pop()
        self.write_log("yellow", f"已删除固件: {deleted.name}")
        self.query_one(FirmwarePanel).update_content()
        self._save_config()

    def action_toggle_debug(self):
        """切换调试模式"""
        _state.dump_dbg = not _state.dump_dbg

        if _state.protocol_client:
            _state.protocol_client.dump_dbg = _state.dump_dbg
            _state.protocol_client.funcname_dbg = _state.dump_dbg

        if _state.serial_thread:
            _state.serial_thread.serial_dump_dbg = _state.dump_dbg

        # ⚠️ 关键：重新配置日志级别
        configure_logging(log_callback=self.write_log, debug_mode=_state.dump_dbg)

        status = "开启" if _state.dump_dbg else "关闭"
        self.write_log("cyan", f"调试模式: {status}")

    def action_save_log(self):
        """保存日志"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

            # 日志保存到 logs 目录
            logs_dir = Path(__file__).parent.parent.parent / "logs"
            logs_dir.mkdir(exist_ok=True)
            log_file = logs_dir / f"serialburn_{timestamp}.log"

            if not _state.log_history:
                self.write_log("yellow", "⚠️ 日志为空")
                return

            log_file.write_text("\n".join(_state.log_history), encoding='utf-8')
            self.write_log("green", f"✅ 日志已保存: {log_file.absolute()}")
        except Exception as e:
            self.write_log("red", f"❌ 保存失败: {e}")

    # ==================== 芯片选择 ====================

    def action_select_chip(self):
        """选择芯片类型"""
        self.push_screen(ChipSelectScreen(_state.chip_type), self._on_chip_selected)

    def _on_chip_selected(self, chip_type):
        """芯片选择回调"""
        if chip_type:
            _state.set_chip_type(chip_type)
            chip_name = chip_to_str(chip_type)
            self.write_log("green", f"✅ 已选择芯片: {chip_name}")

            # 显示芯片特性
            config = get_chip_config(chip_type)
            if config.get("supports_emmc"):
                self.write_log("dim", "  支持 eMMC 烧录")
            if config.get("supports_dual_flash"):
                self.write_log("dim", f"  支持双 Flash (当前: Flash{_state.flash_index})")
            if config.get("needs_sys_clk"):
                self.write_log("dim", "  需要时钟配置")

            self.query_one(StatusPanel).update_content()
            self.query_one(FirmwarePanel).refresh()
            self._save_config()
        else:
            self.write_log("yellow", "⚠️ 已取消选择")
        self.set_focus(None)

    def action_select_target(self):
        """选择烧录目标"""
        if supports_emmc(_state.chip_type):
            self.push_screen(TargetSelectScreen(_state.burn_target, _state.chip_type),
                           self._on_target_selected)
        elif supports_dual_flash(_state.chip_type):
            # ARCS_DUAL 可以选择 Flash 索引
            self.push_screen(FlashIndexSelectScreen(_state.flash_index),
                           self._on_flash_index_selected)
        else:
            self.write_log("yellow", f"{_state.chip_type.value} 仅支持 SPI Flash")

    def _on_target_selected(self, target):
        """烧录目标选���回调"""
        if target:
            _state.burn_target = target
            self.write_log("green", f"✅ 已选择目标: {target.value}")
            self.query_one(StatusPanel).update_content()
            self._save_config()
        else:
            self.write_log("yellow", "⚠️ 已取消选择")
        self.set_focus(None)

    def _on_flash_index_selected(self, index):
        """Flash 索引选择回调"""
        if index is not None:
            _state.flash_index = index
            self.write_log("green", f"✅ 已选择 Flash{index}")
            self.query_one(StatusPanel).update_content()
            self._save_config()
        else:
            self.write_log("yellow", "⚠️ 已取消选择")
        self.set_focus(None)

    # ==================== 自动烧录 ====================

    def action_toggle_auto_burn(self):
        """切换自动烧录模式"""
        if not _state.port:
            self.write_log("yellow", "⚠️ 请先选择串口 (P)")
            return

        modes = ["manual", "wait", "repeat"]
        idx = modes.index(_state.auto_burn_mode)
        _state.auto_burn_mode = modes[(idx + 1) % len(modes)]

        mode_names = {"manual": "手动", "wait": "等待设备", "repeat": "循环烧录"}
        self.write_log("cyan", f"自动烧录模式: {mode_names[_state.auto_burn_mode]}")
        self.query_one(StatusPanel).update_content()
        self._save_config()

        # 启动自动烧录
        if _state.auto_burn_mode in ["wait", "repeat"]:
            asyncio.create_task(self._auto_burn_loop())

    async def _auto_burn_loop(self):
        """自动烧录循环"""
        _state.auto_burn_count = 0
        mode = _state.auto_burn_mode

        self.write_log("cyan", f"启动自动烧录 ({mode})...")

        # 初始化串口
        # 每次重新创建线程对象（Python线程只能start一次）
        if _state.serial_thread:
            _state.serial_thread.deinit_serial()
            _state.serial_thread.notice_end_read()

        _state.serial_thread = ReadSerialThread(_state.dump_dbg, _state.port)

        if not _state.serial_thread.init_serial(_state.port, 115200):
            self.write_log("red", "❌ 无法打开串口")
            _state.auto_burn_mode = "manual"
            self.query_one(StatusPanel).update_content()
            return

        # 启动线程（新创建的线程对象可以直接启动）
        _state.serial_thread.start()
        _state.serial_thread.mark_start()

        _state.protocol_client = CSKBurnProtocolClient(
            _state.serial_thread,
            dump_dbg=_state.dump_dbg,
            funcname_dbg=_state.dump_dbg,
            log_callback=self._protocol_log_callback
        )

        while _state.auto_burn_mode in ["wait", "repeat"]:
            _state.status = Status.BURNING
            self.query_one(StatusPanel).refresh()

            self.write_log("cyan", f"[{_state.auto_burn_count + 1}] 等待设备...")

            # 等待设备出现
            connected = False
            for attempt in range(20):  # 最多等待 10 秒
                # 执行复位序列
                _state.serial_thread.reset_sequence(_state.chip_type, 100)  # iBurn2 使用 100ms

                await asyncio.sleep(0.2)  # 等待设备稳定

                if _state.protocol_client.cmd_sync(0.3):
                    connected = True
                    self.write_log("green", f"[{_state.auto_burn_count + 1}] 设备已连接")
                    break

                await asyncio.sleep(0.5)

                # 检查是否切换了模式
                if _state.auto_burn_mode not in ["wait", "repeat"]:
                    self.write_log("yellow", "自动烧录已取消")
                    break

            if not connected or _state.auto_burn_mode not in ["wait", "repeat"]:
                if _state.auto_burn_mode == "repeat":
                    self.write_log("yellow", "等待超时，继续等待...")
                    continue
                else:
                    self.write_log("yellow", "等待超时")
                    break

            # 执行烧录流程
            await self._do_enter_burn_auto()
            await self._do_burn(_state.get_burnable_firmwares())

            _state.auto_burn_count += 1
            self.write_log("green", f"✅ 第 {_state.auto_burn_count} 台设备烧录完成")
            self.query_one(StatusPanel).update_content()

            # 复位设备
            _state.serial_thread.reset_device(_state.chip_type, 500)

            # wait 模式：完成后停止
            if mode == "wait":
                self.write_log("green", "✅ 自动烧录完成，恢复手动模式")
                _state.auto_burn_mode = "manual"
                break

            # repeat 模式：等待设备拔出
            self.write_log("dim", "等待设备拔出...")
            await asyncio.sleep(2)

        # 恢复状态
        _state.status = Status.UNINIT
        _state.connected = False
        _state.in_burn_mode = False
        self.query_one(StatusPanel).update_content()
        self._set_progress(0, 100, "")
        self._save_config()

    async def _do_enter_burn_auto(self):
        """自动烧录时进入烧录模式（简化版）"""
        burner = _state.burner
        if not burner or not burner.file_path:
            return False

        load_addr = get_load_addr(_state.chip_type)
        burner_data = read_hex_from_bin(burner.file_path)
        burner_len = len(burner_data)
        blocks = _state.protocol_client.BLOCKS(burner_len, CSKBurnProtocolClient.RAM_BLOCK_SIZE)

        # ARCS: 在上传 burner 前切换波特率（加速上传）
        if _state.chip_type in [ChipType.ARCS, ChipType.ARCS_DUAL, ChipType.VENUSA] and _state.baudrate != 115200:
            rom_baud = min(_state.baudrate, 3000000)
            self.write_log("dim", f"ROM 波特率切换: {rom_baud}")
            if _state.protocol_client.cmd_change_baud(rom_baud):
                await asyncio.sleep(0.1)
                if _state.protocol_client.cmd_sync(0.5):
                    self.write_log("green", f"✅ ROM 波特率切换成功")

        # MEM_BEGIN
        if not _state.protocol_client.cmd_mem_begin(burner_len, blocks,
                                                     CSKBurnProtocolClient.RAM_BLOCK_SIZE, load_addr):
            return False

        # 发送 burner 数据
        for i in range(blocks):
            offset = CSKBurnProtocolClient.RAM_BLOCK_SIZE * i
            length = min(CSKBurnProtocolClient.RAM_BLOCK_SIZE, burner_len - offset)
            if not _state.protocol_client.cmd_mem_block(burner_data[offset:offset+length], length, i):
                return False

        # MEM_END
        if not _state.protocol_client.cmd_mem_end(load_addr):
            return False

        # 重要：ROM 波特率切换后，burner 启动时使用 115200
        if _state.baudrate != 115200:
            _state.serial_thread.reload(115200)
            await asyncio.sleep(0.1)

        # 等待 burner 启动
        await asyncio.sleep(1.0)

        # 清空串口缓冲区
        _state.serial_thread.swap()
        if _state.serial_thread.serial:
            try:
                _state.serial_thread.serial.reset_input_buffer()
            except:
                pass

        # 同步 burner（多次尝试）
        sync_success = False
        for attempt in range(20):
            if _state.protocol_client.cmd_sync(0.5):
                sync_success = True
                break
            await asyncio.sleep(0.1)

        if not sync_success:
            return False

        # VENUSA 时钟配置
        if needs_sys_clk(_state.chip_type):
            _state.protocol_client.cmd_set_sys_clk()

        # ARCS_DUAL Flash 索引
        if supports_dual_flash(_state.chip_type):
            _state.protocol_client.cmd_set_flash_index(_state.flash_index)

        # 波特率切换
        if _state.protocol_client.cmd_change_baud(_state.baudrate):
            await asyncio.sleep(0.1)
            _state.protocol_client.cmd_sync(0.3)

        _state.in_burn_mode = True
        return True
