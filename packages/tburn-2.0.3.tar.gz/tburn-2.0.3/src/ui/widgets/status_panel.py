"""状态面板组件 - 紧凑布局，支持鼠标点击"""
from textual.widgets import Static
from textual.reactive import reactive
from textual.message import Message
from rich.panel import Panel

from state import Status, _state
from protocol.chips import chip_to_str, supports_dual_flash


class StatusPanel(Static):
    """状态面板

    显示当前串口状态、端口、波特率、芯片ID等信息。
    紧凑布局，支持点击芯片、目标、端口、波特率进行选择。
    """

    # 点击事件消息
    class ChipClicked(Message):
        """芯片字段点击"""
        pass

    class TargetClicked(Message):
        """目标字段点击"""
        pass

    class PortClicked(Message):
        """端口字段点击"""
        pass

    class BaudrateClicked(Message):
        """波特率字段点击"""
        pass

    status_text = reactive("")

    def render(self) -> Panel:
        """渲染面板（返回 Panel 对象）"""
        # 状态颜色映射
        colors = {
            Status.UNINIT: "gray",
            Status.CONNECTED: "green",
            Status.ENTERED: "cyan",
            Status.BURNING: "yellow",
            Status.VERIFYING: "blue",
            Status.ERROR: "red"
        }

        c = colors.get(_state.status, "white")

        # 芯片类型显示（可点击，用蓝色标记）
        chip_name = chip_to_str(_state.chip_type)

        # 烧录目标显示（可点击）
        target_name = _state.burn_target.value.upper()

        # Flash 索引（ARCS_DUAL 双 Flash）
        flash_info = ""
        if supports_dual_flash(_state.chip_type):
            flash_info = f" (Flash{_state.flash_index})"

        # 自动烧录模式显示
        auto_mode_map = {
            "manual": "手动",
            "wait": "[yellow]等待设备[/yellow]",
            "repeat": "[cyan]循环烧录[/cyan]"
        }
        auto_mode = auto_mode_map.get(_state.auto_burn_mode, "手动")

        # 烧录计数（repeat 模式）
        count_info = ""
        if _state.auto_burn_mode == "repeat" and _state.auto_burn_count > 0:
            count_info = f" (已烧录 {_state.auto_burn_count} 台)"

        # 芯片和目标分开显示，便于点击区分
        lines = [
            f"状态: [{c}]{_state.status.value}[/{c}]",
            f"芯片: [u purple]{chip_name}[/u purple]",  # 单独一行，点击选择芯片
            f"目标: [u purple]{target_name}{flash_info}[/u purple]",  # 单独一行，点击选择目标
            f"端口: [u purple]{_state.port or '[dim]未选择[/dim]'}[/u purple]",
            f"波特率: [u purple]{_state.baudrate}[/u purple]",
            f"芯片ID: {_state.chip_id or '[dim]未读取[/dim]'}",
            f"模式: {auto_mode}{count_info}",
            "",
            "[green]提示：点击紫色字段可修改[/green]",
        ]

        return Panel(
            "\n".join(lines),
            title="[bold cyan]📡 状态[/bold cyan]",
            border_style="cyan"
        )

    def update_content(self):
        """更新面板内容"""
        self.update(self.render())

    def on_click(self, event):
        """处理点击事件 - 根据点击 Y 坐标判断点击了哪个字段"""
        # Panel 结构（含边框）：
        # y=0: 顶部边框（标题嵌入）
        # y=1: "状态: ..."（不响应）
        # y=2: "芯片: ..." → 芯片选择
        # y=3: "目标: ..." → 目标选择
        # y=4: "端口: ..." → 端口选择
        # y=5: "波特: ..." → 波特率选择
        # y=6: "芯片ID: ..."（不响应）
        # y=7: "模式: ..."（不响应）
        # y=8: 空行
        # y=9: 提示行

        y = event.y

        # 根据绝对 Y 坐标判断（Panel 边框占 1 行）
        if y == 2:  # 芯片行
            self.post_message(self.ChipClicked())
        elif y == 3:  # 目标行
            self.post_message(self.TargetClicked())
        elif y == 4:  # 端口行
            self.post_message(self.PortClicked())
        elif y == 5:  # 波特率行
            self.post_message(self.BaudrateClicked())