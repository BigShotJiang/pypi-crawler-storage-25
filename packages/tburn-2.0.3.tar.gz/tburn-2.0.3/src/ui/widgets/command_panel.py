"""快捷命令面板组件 - 显示快捷键列表"""
from textual.widgets import Static
from textual.reactive import reactive
from rich.panel import Panel


class CommandPanel(Static):
    """命令面板

    显示快捷键命令列表。
    """

    command_text = reactive("")

    def render(self) -> Panel:
        """渲染面板"""
        cmds = (
            "C:连接  E:烧录模式  R:读ID  V:校验\n"
            "B:烧录  P:选串口  N:新增固件\n"
            "T:选芯片  G:选目标  A:自动烧录\n"
            "d:删除  D:调试  S:保存  Q:退出"
        )
        return Panel(
            f"[dim]{cmds}[/dim]",
            title="[bold magenta]🎮 命令[/bold magenta]",
            border_style="magenta"
        )

    def update_content(self):
        """更新面板内容"""
        self.update(self.render())