"""进度面板组件"""
from textual.widgets import Static
from textual.reactive import reactive
from rich.panel import Panel

from state import _state


class ProgressPanel(Static):
    """进度面板

    显示当前操作进度条。
    """

    progress_text = reactive("")

    def render(self) -> Panel:
        """渲染面板"""
        try:
            pct = (_state.progress_val / _state.progress_max * 100) if _state.progress_max > 0 else 0
        except Exception:
            pct = 0

        # 进度条（20格）
        filled = int(20 * pct / 100)
        bar = "█" * filled + "░" * (20 - filled)

        lines = [f"[cyan]{bar}[/cyan] {pct:.0f}%"]
        if _state.progress_msg:
            lines.insert(0, f"[yellow]{_state.progress_msg}[/yellow]")

        return Panel(
            "\n".join(lines),
            title="[bold green]📊 进度[/bold green]",
            border_style="green"
        )

    def update_content(self):
        """更新面板内容"""
        self.update(self.render())