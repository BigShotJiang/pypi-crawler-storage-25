"""烧录操作面板组件"""
from textual.widgets import Static, Button
from textual.message import Message
from textual.reactive import reactive
from textual.app import ComposeResult
from rich.panel import Panel


class BurnPanel(Static):
    """烧录操作面板

    包含两个独立操作：
    1. 自动进入烧录模式开关
    2. 开始烧录按钮
    """

    # 自动进入烧录模式开关（控制 RTS/DTR）
    auto_enter_burn: reactive[bool] = reactive(True)

    class BurnClicked(Message):
        """烧录按钮点击"""
        pass

    class AutoEnterBurnToggled(Message):
        """自动进入烧录模式开关切换"""
        def __init__(self, enabled: bool):
            self.enabled = enabled
            super().__init__()

    def render(self) -> Panel:
        """渲染面板"""
        if self.auto_enter_burn:
            auto_status = "[bold green]✓ 开启[/bold green]"
            auto_hint = "[dim](烧录时自动控制 RTS/DTR)[/dim]"
        else:
            auto_status = "[bold red]✗ 关闭[/bold red]"
            auto_hint = "[dim](需手动让芯片进入烧录模式)[/dim]"

        content = (
            f"[bold]自动进入烧录模式:[/bold] {auto_status}\n"
            f"{auto_hint}\n\n"
            f"[bold yellow]>>> 点击开始烧录 <<<[/bold yellow]"
        )
        return Panel(
            content,
            title="[bold yellow]🔥 烧录操作[/bold yellow]",
            border_style="yellow"
        )

    def on_mount(self):
        """挂载后渲染"""
        # 使用 refresh() 而不是 update()，因为 render() 会自动被调用
        self.refresh()

    def on_click(self, event):
        """点击事件 - 根据位置判断操作"""
        # 获取点击位置
        y = event.y

        # Panel 大约 4-5 行：
        # 第 1 行: 标题栏
        # 第 2 行: "自动进入烧录模式: ✓ 开启"
        # 第 3 行: 提示文字
        # 第 4 行: 空行
        # 第 5 行: ">>> 点击开始烧录 <<<"

        # y <= 3: 切换开关
        # y > 3:  触发烧录

        if y <= 3:
            # 切换自动进入烧录模式
            self.toggle_auto_enter_burn()
        else:
            # 触发烧录
            self.post_message(self.BurnClicked())

    def update_content(self):
        """更新面板内容"""
        self.refresh()

    def toggle_auto_enter_burn(self):
        """切换自动进入烧录模式"""
        self.auto_enter_burn = not self.auto_enter_burn
        self.update_content()
        self.post_message(self.AutoEnterBurnToggled(self.auto_enter_burn))