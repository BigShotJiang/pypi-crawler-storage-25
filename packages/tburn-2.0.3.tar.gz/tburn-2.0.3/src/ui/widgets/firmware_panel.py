"""固件面板组件 - 支持鼠标点击操作，蓝色边框"""
from textual.widgets import Static
from textual.reactive import reactive
from textual.message import Message
from rich.panel import Panel
from rich.table import Table

from state import _state


class FirmwarePanel(Static):
    """固件面板

    显示固件列表（不含 burner），按地址排序。
    蓝色边框，支持鼠标点击编辑、新增、删除。
    底部有"+ 新增固件"行，点击可新增。
    包含烧录状态列：√ 成功、× 失败、- 未烧录
    """

    class FirmwareEditRequested(Message):
        """请求编辑固件"""
        def __init__(self, index: int, firmware):
            super().__init__()
            self.index = index
            self.firmware = firmware

    class FirmwareDeleteRequested(Message):
        """请求删除固件"""
        def __init__(self, index: int):
            super().__init__()
            self.index = index

    class FirmwareAddRequested(Message):
        """请求添加固件"""
        pass

    def render(self) -> Panel:
        """渲染面板（返回 Panel 对象）"""
        burnable = _state.get_burnable_firmwares()

        # 创建表格，增加烧录状态列
        t = Table(show_header=True, box=None, expand=True)
        t.add_column("状态", style="dim")
        t.add_column("序号", style="dim")
        t.add_column("名称", style="cyan")
        t.add_column("地址", style="yellow")
        t.add_column("大小", style="green")
        t.add_column("路径", style="dim")
        t.add_column("操作", style="red")

        if burnable:
            for i, fw in enumerate(burnable):
                sz_str = f"{fw.size/1024:.1f}KB" if fw.size else "-"
                path_short = fw.file_path.split('/')[-1] if fw.file_path else "-"
                # 烧录状态显示
                status_display = fw.burn_status
                if fw.burn_status == "√":
                    status_display = "[green]√[/green]"
                elif fw.burn_status == "×":
                    status_display = "[red]×[/red]"
                t.add_row(status_display, str(i), fw.name, f"0x{fw.addr:X}", sz_str, path_short, "[red]删除[/red]")
        else:
            t.add_row("-", "-", "[dim]无固件[/dim]", "-", "-", "-", "-")

        # 添加新增固件行
        t.add_row("", "", "[bold cyan]+ 新增固件[/bold cyan]", "", "", "", "")

        return Panel(
            t,
            title="[bold blue]📦 固件[/bold blue]",
            border_style="blue"
        )

    def on_click(self, event):
        """处理点击事件 - 根据点击位置判断操作"""
        # 获取点击的行号
        y = event.y
        widget_height = self.size.height

        burnable = _state.get_burnable_firmwares()
        total_rows = len(burnable) + 1  # 固件行 + 新增行

        # Panel 边框占 2 行（上下各1），标题占 1 行
        # 内容区域从 y=2 开始
        content_y = y - 2

        if widget_height > 0:
            # 根据相对位置计算行号
            row_height = (widget_height - 3) / (total_rows + 1)  # 减去边框和标题
            row = int(content_y / row_height) if row_height > 0 else 0

            if row < len(burnable):
                # 点击固件行 - 根据X坐标判断是编辑还是删除
                x = event.x
                widget_width = self.size.width
                col_width = widget_width / 7  # 7列

                col = int(x / col_width) if col_width > 0 else 0

                if col == 6:  # 操作列 = 删除
                    self.post_message(self.FirmwareDeleteRequested(row))
                elif col in [3, 5]:  # 地址或路径列 = 编辑
                    self.post_message(self.FirmwareEditRequested(row, burnable[row]))
            elif row == len(burnable):
                # 点击新增固件行
                self.post_message(self.FirmwareAddRequested())

    def update_content(self):
        """更新面板内容"""
        self.update(self.render())