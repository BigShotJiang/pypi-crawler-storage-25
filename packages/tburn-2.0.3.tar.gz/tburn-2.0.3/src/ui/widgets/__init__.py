# Widgets module
from .status_panel import StatusPanel
from .progress_panel import ProgressPanel
from .firmware_panel import FirmwarePanel
from .command_panel import CommandPanel
from .burn_panel import BurnPanel
from .log_panel import LogPanel

__all__ = ['StatusPanel', 'ProgressPanel', 'FirmwarePanel', 'CommandPanel', 'BurnPanel', 'LogPanel']