"""日志面板组件 - 支持复制"""
from textual.widgets import RichLog
from textual.binding import Binding
from datetime import datetime

from state import _state


class LogPanel(RichLog):
    """日志面板

    显示操作日志，支持复制功能。
    """

    BINDINGS = [
        Binding("ctrl+c", "copy_log", "复制日志"),
    ]

    def __init__(self, **kwargs):
        super().__init__(
            highlight=True,
            markup=True,
            wrap=True,
            **kwargs
        )

    def action_copy_log(self):
        """复制日志到剪贴板"""
        try:
            import pyperclip
            if _state.log_history:
                content = "\n".join(_state.log_history)
                pyperclip.copy(content)
                self.write("[green]✅ 日志已复制到剪贴板[/green]")
            else:
                self.write("[yellow]⚠️ 日志为空[/yellow]")
        except ImportError:
            # 如果没有 pyperclip，尝试其他方式
            self.write("[yellow]⚠️ 请安装 pyperclip: pip install pyperclip[/yellow]")
            self.write("[dim]或手动从终端复制[/dim]")

    def write_log(self, color: str, msg: str):
        """写入日志

        Args:
            color: 日志颜色
            msg: 日志消息
        """
        t = datetime.now().strftime("%H:%M:%S")
        self.write(f"[{color}]{t}[/{color}] {msg}")
        # 保存到历史记录
        _state.log_history.append(f"{t} {msg}")

    def clear_history(self):
        """清空历史记录"""
        _state.log_history.clear()
        self.clear()