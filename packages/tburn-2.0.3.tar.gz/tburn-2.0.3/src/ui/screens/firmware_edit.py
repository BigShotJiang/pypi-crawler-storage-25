"""固件编辑对话框"""
from pathlib import Path
from textual.screen import ModalScreen
from textual.containers import Container, Horizontal
from textual.widgets import Static, Input, Button
from textual.binding import Binding
from textual.app import ComposeResult
from textual.reactive import reactive

from textual_fspicker import FileOpen, Filters

from firmware import FirmwareInfo
from state import _state


class FirmwareEditScreen(ModalScreen):
    """固件信息编辑对话框 - 简化版，自动从文件名生成固件名称"""

    CSS = """
    FirmwareEditScreen {
        align: center middle;
    }
    #dialog {
        width: 70;
        height: auto;
        max-height: 90%;
        border: thick $primary;
        background: $surface;
        padding: 1 2;
    }
    #title {
        text-align: center;
        text-style: bold;
        color: $primary;
        margin-bottom: 1;
    }
    .label {
        color: $text;
        margin-top: 1;
    }
    #addr_input {
        width: 100%;
        margin-bottom: 1;
    }
    #addr_input:focus {
        background: $primary-background;
    }
    #file_display {
        color: $text-muted;
        width: 100%;
        height: auto;
        margin-bottom: 1;
        padding: 0 1;
    }
    #buttons {
        layout: horizontal;
        width: 100%;
        height: auto;
        margin-top: 1;
    }
    #buttons Button {
        width: 1fr;
        margin: 0 1;
    }
    #buttons Button:focus {
        background: $primary;
        color: $text;
    }
    """

    BINDINGS = [
        Binding("escape", "cancel", "取消"),
        Binding("up", "move_up", "上移", show=False),
        Binding("down", "move_down", "下移", show=False),
        Binding("enter", "confirm", "确认"),
        Binding("f", "select_file", "选择文件"),
    ]

    firmware_addr = reactive("0x0")
    firmware_path = reactive("")
    firmware_name = reactive("")  # 自动从文件名生成

    def __init__(self, firmware: FirmwareInfo = None, **kwargs):
        super().__init__(**kwargs)
        self._firmware = firmware or FirmwareInfo()
        self._result = None
        # 预填充已有信息
        if self._firmware.file_path:
            self.firmware_path = self._firmware.file_path
            self.firmware_name = Path(self._firmware.file_path).stem or self._firmware.name
        if self._firmware.addr:
            self.firmware_addr = f"0x{self._firmware.addr:X}"

    def compose(self) -> ComposeResult:
        with Container(id="dialog"):
            yield Static("编辑固件信息", id="title")
            yield Static("烧录地址 (hex):", classes="label")
            yield Input(
                value=self.firmware_addr,
                id="addr_input",
                placeholder="0x0"
            )
            yield Static("固件路径:", classes="label")
            yield Static(
                self.firmware_path or "(未选择)",
                id="file_display"
            )
            with Horizontal(id="buttons"):
                yield Button("选择文件 [F]", id="file_btn", variant="default")
                yield Button("确定 [Enter]", id="confirm_btn", variant="primary")
                yield Button("取消 [Esc]", id="cancel_btn", variant="error")

    def on_mount(self):
        """挂载后设置焦点"""
        addr_input = self.query_one("#addr_input", Input)
        addr_input.focus()

    def on_input_changed(self, event: Input.Changed):
        if event.input.id == "addr_input":
            self.firmware_addr = event.value

    def on_button_pressed(self, event: Button.Pressed):
        if event.button.id == "confirm_btn":
            self.action_confirm()
        elif event.button.id == "cancel_btn":
            self.action_cancel()
        elif event.button.id == "file_btn":
            self.action_select_file()

    def on_key(self, event):
        """键盘导航"""
        if event.key == "up":
            self._nav_focus(-1)
            event.stop()
        elif event.key == "down":
            self._nav_focus(1)
            event.stop()

    def _nav_focus(self, direction: int):
        """焦点导航"""
        focusable = [
            self.query_one("#addr_input", Input),
            self.query_one("#file_btn", Button),
            self.query_one("#confirm_btn", Button),
            self.query_one("#cancel_btn", Button),
        ]

        focused = self.focused
        if focused and focused in focusable:
            idx = focusable.index(focused)
            new_idx = (idx + direction) % len(focusable)
            focusable[new_idx].focus()
        else:
            focusable[0].focus() if direction > 0 else focusable[-1].focus()

    def action_move_up(self):
        self._nav_focus(-1)

    def action_move_down(self):
        self._nav_focus(1)

    def action_select_file(self):
        """使用 textual-fspicker 打开文件选择对话框"""
        # 创建固件文件过滤器
        filters = Filters(
            ("固件文件 (*.bin, *.img)", lambda p: str(p).endswith('.bin') or str(p).endswith('.img')),
            ("所有文件 (*)", lambda p: True),
        )

        # 从上次路径或当前目录开始
        start_location = _state.last_firmware_dir or "."

        # 打开文件选择对话框
        file_open = FileOpen(
            location=start_location,
            title="选择固件文件",
            filters=filters,
            must_exist=True,
        )

        self.app.push_screen(file_open, self._on_file_selected)

    def _on_file_selected(self, file_path):
        """文件选择回调"""
        if file_path:
            self.firmware_path = str(file_path)
            # 自动从文件名生成固件名称（不含扩展名）
            self.firmware_name = Path(file_path).stem

            # 更新文件显示
            file_display = self.query_one("#file_display", Static)
            file_display.update(str(file_path))

            # 焦点回到地址输入
            addr_input = self.query_one("#addr_input", Input)
            addr_input.focus()

    def action_confirm(self):
        """确认并返回结果"""
        try:
            addr_str = self.firmware_addr.strip()
            if addr_str.startswith("0x") or addr_str.startswith("0X"):
                addr = int(addr_str, 16)
            else:
                addr = int(addr_str)

            file_path = self.firmware_path or self._firmware.file_path
            if not file_path:
                self.dismiss(None)
                return

            name = self.firmware_name or self._firmware.name or Path(file_path).stem

            result = FirmwareInfo(
                name=name,
                addr=addr,
                file_path=file_path
            )
            result.update_from_file()
            self.dismiss(result)

        except ValueError:
            self.dismiss(None)

    def action_cancel(self):
        """取消"""
        self.dismiss(None)