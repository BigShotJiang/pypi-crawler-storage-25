"""波特率选择对话框"""
from textual.screen import ModalScreen
from textual.containers import Container
from textual.widgets import Static, Button
from textual.binding import Binding
from textual.app import ComposeResult

# 常用波特率列表
BAUDRATES = [115200, 921600, 1536000, 2000000]


class BaudrateSelectScreen(ModalScreen):
    """波特率选择对话框"""

    CSS = """
    BaudrateSelectScreen {
        align: center middle;
    }
    #dialog {
        width: 30;
        height: auto;
        border: thick $primary;
        background: $surface;
        padding: 1;
    }
    #title {
        text-align: center;
        text-style: bold;
        color: $primary;
        margin-bottom: 1;
    }
    Button {
        width: 100%;
        margin-bottom: 1;
    }
    Button:focus {
        background: $primary;
        color: $text;
    }
    """

    BINDINGS = [
        Binding("escape", "cancel", "取消"),
        Binding("1", "select_0", ""),
        Binding("2", "select_1", ""),
        Binding("3", "select_2", ""),
        Binding("4", "select_3", ""),
    ]

    def __init__(self, current_baudrate: int = 1536000, **kwargs):
        super().__init__(**kwargs)
        self.current_baudrate = current_baudrate

    def compose(self) -> ComposeResult:
        with Container(id="dialog"):
            yield Static("选择波特率", id="title")
            for i, baud in enumerate(BAUDRATES):
                label = f"{baud}"
                if baud == self.current_baudrate:
                    label = f"{baud} ✓"
                yield Button(label, id=f"baud_{i}", variant="default")
            yield Button("取消", id="cancel_btn", variant="error")

    def on_button_pressed(self, event: Button.Pressed):
        if event.button.id == "cancel_btn":
            self.dismiss(None)
        elif event.button.id and event.button.id.startswith("baud_"):
            idx = int(event.button.id.split("_")[1])
            self.dismiss(BAUDRATES[idx])

    def action_cancel(self):
        self.dismiss(None)

    def action_select_0(self):
        self.dismiss(BAUDRATES[0])

    def action_select_1(self):
        self.dismiss(BAUDRATES[1])

    def action_select_2(self):
        self.dismiss(BAUDRATES[2])

    def action_select_3(self):
        self.dismiss(BAUDRATES[3])