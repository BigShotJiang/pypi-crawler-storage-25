"""芯片类型选择对话框"""
from textual.screen import ModalScreen
from textual.containers import Container, VerticalScroll
from textual.widgets import Static, Button, ListView, ListItem
from textual.binding import Binding
from textual.app import ComposeResult

import sys
import os
_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _root not in sys.path:
    sys.path.insert(0, _root)

from protocol.chips import ChipType, chip_to_str, supports_emmc, supports_dual_flash


class ChipSelectScreen(ModalScreen):
    """芯片类型选择对话框"""

    CSS = """
    ChipSelectScreen {
        align: center middle;
    }
    #dialog {
        width: 50;
        height: auto;
        max-height: 80%;
        border: thick $primary;
        background: $surface;
        padding: 1;
    }
    #title {
        text-align: center;
        text-style: bold;
        color: $primary;
        margin-bottom: 1;
    }
    VerticalScroll {
        width: 100%;
        height: auto;
    }
    ListItem {
        padding: 1 2;
    }
    ListItem:hover {
        background: $primary-background;
    }
    ListItem:focus {
        background: $primary;
        color: $text;
    }
    Button {
        width: 100%;
        margin-bottom: 1;
    }
    Button:focus {
        background: $primary;
        color: $text;
    }
    #hint {
        text-align: center;
        color: $text-muted;
        margin-top: 1;
    }
    .chip-item {
        width: 100%;
    }
    """

    BINDINGS = [
        Binding("escape", "cancel", "取消"),
        Binding("up", "move_up", "上移"),
        Binding("down", "move_down", "下移"),
        Binding("enter", "select_current", "确认"),
        Binding("1", "select_csk6", "CSK6"),
        Binding("2", "select_arcs", "ARCS"),
        Binding("3", "select_arcs_dual", "ARCS_DUAL"),
        Binding("4", "select_venusa", "VENUSA"),
    ]

    def __init__(self, current_chip: ChipType = ChipType.CSK6, **kwargs):
        super().__init__(**kwargs)
        self._current_chip = current_chip
        self._chips = [
            ChipType.CSK6,
            ChipType.ARCS,
            ChipType.ARCS_DUAL,
            ChipType.VENUSA,
        ]
        self._current_index = 0

        # 设置初始索引为当前芯片
        for i, chip in enumerate(self._chips):
            if chip == current_chip:
                self._current_index = i
                break

    def compose(self) -> ComposeResult:
        with Container(id="dialog"):
            yield Static("选择芯片类型", id="title")
            with VerticalScroll():
                for i, chip in enumerate(self._chips):
                    label = self._get_chip_label(chip)
                    marker = " ●" if chip == self._current_chip else ""
                    # 使用 Button 并设置样式
                    yield Button(
                        f"{i+1}: {label}{marker}",
                        id=f"chip_{i}",
                        variant="primary" if chip == self._current_chip else "default"
                    )
            yield Static("↑↓=移动  1-4=快选  Enter=确认  Esc=取消", id="hint")

    def _get_chip_label(self, chip: ChipType) -> str:
        """获取芯片标签（带特性说明）"""
        name = chip_to_str(chip)
        features = []
        if supports_emmc(chip):
            features.append("eMMC")
        if supports_dual_flash(chip):
            features.append("双Flash")
        if features:
            return f"{name} ({', '.join(features)})"
        return name

    def on_mount(self):
        """挂载后设置焦点"""
        # 焦点到当前芯片对应的按钮
        buttons = self.query(Button)
        if buttons and self._current_index < len(buttons):
            buttons[self._current_index].focus()

    def on_button_pressed(self, event: Button.Pressed):
        """按钮点击处理"""
        button_id = event.button.id
        if button_id and button_id.startswith("chip_"):
            index = int(button_id.replace("chip_", ""))
            if 0 <= index < len(self._chips):
                self.dismiss(self._chips[index])
                return
        self.dismiss(None)

    def on_key(self, event):
        """键盘事件处理"""
        key = event.key

        if key == "up":
            self._nav_focus(-1)
            event.stop()
        elif key == "down":
            self._nav_focus(1)
            event.stop()

    def _nav_focus(self, direction: int):
        """移动焦点"""
        buttons = self.query(Button)
        if not buttons:
            return

        # 找到当前焦点按钮
        focused = self.focused
        if focused and focused in buttons:
            current_idx = list(buttons).index(focused)
            new_idx = (current_idx + direction) % len(buttons)
            buttons[new_idx].focus()
            self._current_index = new_idx
        else:
            # 没有焦点时，聚焦到第一个或最后一个
            if direction > 0:
                buttons[0].focus()
            else:
                buttons[-1].focus()

    def action_move_up(self):
        """上移"""
        self._nav_focus(-1)

    def action_move_down(self):
        """下移"""
        self._nav_focus(1)

    def action_select_current(self):
        """选择当前焦点项"""
        if 0 <= self._current_index < len(self._chips):
            self.dismiss(self._chips[self._current_index])

    def action_select_csk6(self):
        self.dismiss(ChipType.CSK6)

    def action_select_arcs(self):
        self.dismiss(ChipType.ARCS)

    def action_select_arcs_dual(self):
        self.dismiss(ChipType.ARCS_DUAL)

    def action_select_venusa(self):
        self.dismiss(ChipType.VENUSA)

    def action_cancel(self):
        self.dismiss(None)