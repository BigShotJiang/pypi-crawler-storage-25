"""串口选择对话框"""
from textual.screen import ModalScreen
from textual.containers import Container
from textual.widgets import Static, Select, Button
from textual.binding import Binding
from textual.app import ComposeResult


class PortSelectScreen(ModalScreen):
    """非阻塞的串口选择对话框"""

    CSS = """
    PortSelectScreen {
        align: center middle;
    }
    #dialog {
        width: 50;
        height: 15;
        border: thick $primary;
        background: $surface;
        padding: 1;
    }
    #title {
        text-align: center;
        text-style: bold;
        color: $primary;
        margin-bottom: 1;
    }
    Select {
        width: 100%;
        margin-bottom: 1;
    }
    Button {
        width: 100%;
    }
    #hint {
        text-align: center;
        color: $text-muted;
    }
    """

    BINDINGS = [
        Binding("escape", "cancel", "取消"),
    ]

    def __init__(self, ports: list, **kwargs):
        super().__init__(**kwargs)
        self._ports = ports
        self._selected = ports[0] if ports else None

    def compose(self) -> ComposeResult:
        with Container(id="dialog"):
            yield Static("选择串口设备", id="title")
            options = [(p, p) for p in self._ports]
            yield Select(options, id="port_select", value=self._selected)
            yield Button("确定 (Enter)", id="confirm_btn", variant="primary")
            yield Static("Enter=确认  Esc=取消", id="hint")

    def on_select_changed(self, event: Select.Changed):
        self._selected = str(event.value)

    def on_button_pressed(self, event: Button.Pressed):
        if event.button.id == "confirm_btn":
            self.action_confirm()

    def on_key(self, event):
        # Enter 键在不同终端模式下可能是 "enter" 或 "ctrl+j"
        if event.key == "enter" or event.key == "ctrl+j":
            self.action_confirm()
            event.stop()

    def action_confirm(self):
        if self._selected:
            self.dismiss(self._selected)

    def action_cancel(self):
        self.dismiss(None)