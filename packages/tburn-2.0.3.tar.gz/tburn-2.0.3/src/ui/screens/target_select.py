"""烧录目标选择对话框"""
from textual.screen import ModalScreen
from textual.containers import Container, VerticalScroll
from textual.widgets import Static, Button
from textual.binding import Binding
from textual.app import ComposeResult

import sys
import os
_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _root not in sys.path:
    sys.path.insert(0, _root)

from protocol.chips import BurnTarget, ChipType, supports_emmc, supports_dual_flash


class TargetSelectScreen(ModalScreen):
    """烧录目标选择对话框（Flash/eMMC）"""

    CSS = """
    TargetSelectScreen {
        align: center middle;
    }
    #dialog {
        width: 50;
        height: auto;
        max-height: 80%;
        border: thick $primary;
        background: $surface;
        padding: 1;
    }
    #title {
        text-align: center;
        text-style: bold;
        color: $primary;
        margin-bottom: 1;
    }
    VerticalScroll {
        width: 100%;
        height: auto;
    }
    Button {
        width: 100%;
        margin-bottom: 1;
    }
    Button:focus {
        background: $primary;
        color: $text;
    }
    #hint {
        text-align: center;
        color: $text-muted;
        margin-top: 1;
    }
    .disabled {
        color: $text-muted;
        text-style: italic;
    }
    """

    BINDINGS = [
        Binding("escape", "cancel", "取消"),
        Binding("up", "move_up", "上移"),
        Binding("down", "move_down", "下移"),
        Binding("enter", "select_current", "确认"),
        Binding("f", "select_flash", "Flash"),
        Binding("e", "select_emmc", "eMMC"),
    ]

    def __init__(self, current_target: BurnTarget = BurnTarget.FLASH,
                 chip_type: ChipType = ChipType.CSK6, **kwargs):
        super().__init__(**kwargs)
        self._current_target = current_target
        self._chip_type = chip_type
        self._targets = [BurnTarget.FLASH]
        if supports_emmc(chip_type):
            self._targets.append(BurnTarget.EMMC)
        self._current_index = 0

        # 设置初始索引
        for i, target in enumerate(self._targets):
            if target == current_target:
                self._current_index = i
                break

    def compose(self) -> ComposeResult:
        with Container(id="dialog"):
            yield Static("选择烧录目标", id="title")
            with VerticalScroll():
                # SPI Flash（所有芯片支持）
                flash_marker = " ●" if self._current_target == BurnTarget.FLASH else ""
                yield Button(
                    f"F: SPI Flash{flash_marker}",
                    id="flash",
                    variant="primary" if self._current_target == BurnTarget.FLASH else "default"
                )

                # eMMC（仅 ARCS 支持）
                if supports_emmc(self._chip_type):
                    emmc_marker = " ●" if self._current_target == BurnTarget.EMMC else ""
                    yield Button(
                        f"E: eMMC{emmc_marker}",
                        id="emmc",
                        variant="primary" if self._current_target == BurnTarget.EMMC else "default"
                    )
                else:
                    yield Static("  eMMC: 仅 ARCS 支持", classes="disabled")

            yield Static("↑↓=移动  F/E=快选  Enter=确认  Esc=取消", id="hint")

    def on_mount(self):
        """挂载后设置焦点"""
        buttons = self.query(Button)
        if buttons and self._current_index < len(buttons):
            buttons[self._current_index].focus()

    def on_button_pressed(self, event: Button.Pressed):
        """按钮点击处理"""
        button_id = event.button.id
        if button_id == "flash":
            self.dismiss(BurnTarget.FLASH)
        elif button_id == "emmc":
            if supports_emmc(self._chip_type):
                self.dismiss(BurnTarget.EMMC)
            else:
                self.dismiss(None)

    def on_key(self, event):
        """键盘事件处理"""
        key = event.key

        if key == "up":
            self._nav_focus(-1)
            event.stop()
        elif key == "down":
            self._nav_focus(1)
            event.stop()

    def _nav_focus(self, direction: int):
        """移动焦点"""
        buttons = self.query(Button)
        if not buttons:
            return

        focused = self.focused
        if focused and focused in buttons:
            current_idx = list(buttons).index(focused)
            new_idx = (current_idx + direction) % len(buttons)
            buttons[new_idx].focus()
            self._current_index = new_idx
        else:
            if direction > 0:
                buttons[0].focus()
            else:
                buttons[-1].focus()

    def action_move_up(self):
        """上移"""
        self._nav_focus(-1)

    def action_move_down(self):
        """下移"""
        self._nav_focus(1)

    def action_select_current(self):
        """选择当前焦点项"""
        if self._current_index == 0:
            self.dismiss(BurnTarget.FLASH)
        elif self._current_index == 1 and supports_emmc(self._chip_type):
            self.dismiss(BurnTarget.EMMC)

    def action_select_flash(self):
        self.dismiss(BurnTarget.FLASH)

    def action_select_emmc(self):
        if supports_emmc(self._chip_type):
            self.dismiss(BurnTarget.EMMC)
        else:
            self.dismiss(None)

    def action_cancel(self):
        self.dismiss(None)


class FlashIndexSelectScreen(ModalScreen):
    """Flash 索引选择对话框（ARCS_DUAL 双 Flash）"""

    CSS = """
    FlashIndexSelectScreen {
        align: center middle;
    }
    #dialog {
        width: 50;
        height: auto;
        max-height: 80%;
        border: thick $primary;
        background: $surface;
        padding: 1;
    }
    #title {
        text-align: center;
        text-style: bold;
        color: $primary;
        margin-bottom: 1;
    }
    VerticalScroll {
        width: 100%;
        height: auto;
    }
    Button {
        width: 100%;
        margin-bottom: 1;
    }
    Button:focus {
        background: $primary;
        color: $text;
    }
    #hint {
        text-align: center;
        color: $text-muted;
        margin-top: 1;
    }
    """

    BINDINGS = [
        Binding("escape", "cancel", "取消"),
        Binding("up", "move_up", "上移"),
        Binding("down", "move_down", "下移"),
        Binding("enter", "select_current", "确认"),
        Binding("0", "select_flash0", "Flash0"),
        Binding("1", "select_flash1", "Flash1"),
    ]

    def __init__(self, current_index: int = 0, **kwargs):
        super().__init__(**kwargs)
        self._current_index = current_index

    def compose(self) -> ComposeResult:
        with Container(id="dialog"):
            yield Static("选择 Flash 索引（ARCS_DUAL）", id="title")
            with VerticalScroll():
                flash0_marker = " ●" if self._current_index == 0 else ""
                yield Button(
                    f"0: Flash0{flash0_marker}",
                    id="flash0",
                    variant="primary" if self._current_index == 0 else "default"
                )
                flash1_marker = " ●" if self._current_index == 1 else ""
                yield Button(
                    f"1: Flash1{flash1_marker}",
                    id="flash1",
                    variant="primary" if self._current_index == 1 else "default"
                )
            yield Static("↑↓=移动  0/1=快选  Enter=确认  Esc=取消", id="hint")

    def on_mount(self):
        """挂载后设置焦点"""
        buttons = self.query(Button)
        if buttons and self._current_index < len(buttons):
            buttons[self._current_index].focus()

    def on_button_pressed(self, event: Button.Pressed):
        """按钮点击处理"""
        button_id = event.button.id
        if button_id == "flash0":
            self.dismiss(0)
        elif button_id == "flash1":
            self.dismiss(1)

    def on_key(self, event):
        """键盘事件处理"""
        key = event.key

        if key == "up":
            self._nav_focus(-1)
            event.stop()
        elif key == "down":
            self._nav_focus(1)
            event.stop()

    def _nav_focus(self, direction: int):
        """移动焦点"""
        buttons = self.query(Button)
        if not buttons:
            return

        focused = self.focused
        if focused and focused in buttons:
            current_idx = list(buttons).index(focused)
            new_idx = (current_idx + direction) % len(buttons)
            buttons[new_idx].focus()
            self._current_index = new_idx
        else:
            if direction > 0:
                buttons[0].focus()
            else:
                buttons[-1].focus()

    def action_move_up(self):
        """上移"""
        self._nav_focus(-1)

    def action_move_down(self):
        """下移"""
        self._nav_focus(1)

    def action_select_current(self):
        """选择当前焦点项"""
        self.dismiss(self._current_index)

    def action_select_flash0(self):
        self.dismiss(0)

    def action_select_flash1(self):
        self.dismiss(1)

    def action_cancel(self):
        self.dismiss(None)