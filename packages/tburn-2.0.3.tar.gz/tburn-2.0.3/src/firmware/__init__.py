"""固件信息类"""
import os
from protocol.utils import getmd5


class FirmwareInfo:
    """固件信息

    存储单个固件的名称、地址、路径、大小等信息。
    burn_status: 烧录状态 (- 未烧录, √ 成功, × 失败)
    """

    def __init__(self, name: str = "", addr: int = 0x0, file_path: str = ""):
        self.name = name
        self.addr = addr
        self.file_path = file_path
        self.size = 0
        self.md5 = 0
        self.burn_status = "-"  # 默认未烧录

        if file_path and os.path.isfile(file_path):
            self.update_from_file()

    def update_from_file(self):
        """从文件更新信息"""
        if self.file_path and os.path.isfile(self.file_path):
            self.size = os.path.getsize(self.file_path)
            self.md5 = getmd5(self.file_path)

    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            'name': self.name,
            'addr': self.addr,
            'file_path': self.file_path,
            'size': self.size,
            'md5': self.md5,
            'burn_status': self.burn_status
        }

    @staticmethod
    def from_dict(d: dict) -> 'FirmwareInfo':
        """从字典创建"""
        info = FirmwareInfo(
            d.get('name', ''),
            d.get('addr', 0x0),
            d.get('file_path', '')
        )
        info.size = d.get('size', 0)
        info.md5 = d.get('md5', 0)
        info.burn_status = d.get('burn_status', '-')
        return info

    def __repr__(self) -> str:
        return f"FirmwareInfo(name={self.name}, addr=0x{self.addr:X}, size={self.size}, status={self.burn_status})"