"""全局状态"""
import os
from enum import Enum
from typing import Optional, List
from pathlib import Path

from firmware import FirmwareInfo
from protocol.serial_thread import ReadSerialThread
from protocol.client import CSKBurnProtocolClient
from protocol.chips import ChipType, BurnTarget, get_chip_config, get_load_addr, get_burner_name


class Status(Enum):
    """状态枚举"""
    UNINIT = "未初始化"
    CONNECTED = "已连接"
    ENTERED = "烧录模式"
    BURNING = "烧录中"
    VERIFYING = "校验中"
    ERROR = "错误"


class State:
    """全局状态

    存储应用的所有状态信息，包括串口、固件、进度等。
    """

    def __init__(self):
        # 状态
        self.status = Status.UNINIT

        # 串口信息
        self.port: Optional[str] = None
        self.baudrate: int = 1536000
        self.chip_id: Optional[str] = None
        self.connected = False
        self.in_burn_mode = False

        # 新增：芯片类型和烧录目标
        self.chip_type: ChipType = ChipType.CSK6
        self.burn_target: BurnTarget = BurnTarget.FLASH
        self.flash_index: int = 0  # ARCS_DUAL 双 Flash 选择 (0/1)
        self.auto_burn_mode: str = "manual"  # "manual", "wait", "repeat"
        self.auto_burn_count: int = 0  # repeat 模式烧录计数
        self.auto_enter_burn: bool = True  # 自动进入烧录模式（自动控制 RTS/DTR），默认开启

        # 固件列表（不含 burner）
        self.firmwares: List[FirmwareInfo] = []

        # burner（代理程序，不存储到 flash）
        self.burner: Optional[FirmwareInfo] = None

        # 上次固件路径（用于文件选择）
        self.last_firmware_dir: Optional[str] = None

        # 加载 burner（根据芯片类型动态选择）
        self._load_burner()

        # 进度
        self.progress_val = 0
        self.progress_max = 100
        self.progress_msg = ""

        # 日志历史
        self.log_history: List[str] = []

        # 串口相关实例
        self.serial_thread: Optional[ReadSerialThread] = None
        self.protocol_client: Optional[CSKBurnProtocolClient] = None

        # 调试模式
        self.dump_dbg = False

    def _load_burner(self):
        """加载当前芯片类型的 burner"""
        burner_name = get_burner_name(self.chip_type)
        # res 目录在 src/ 目录下，state/__init__.py 的 parent.parent 是 src/
        burner_path = Path(__file__).parent.parent / "res" / burner_name
        if burner_path.exists():
            self.burner = FirmwareInfo("burner", get_load_addr(self.chip_type), str(burner_path))

    def set_chip_type(self, chip_type: ChipType):
        """设置芯片类型并重新加载 burner"""
        self.chip_type = chip_type
        self._load_burner()
        # 重置烧录目标（如果不是 ARCS，不能选择 eMMC）
        if self.burn_target == BurnTarget.EMMC and not get_chip_config(chip_type).get("supports_emmc", False):
            self.burn_target = BurnTarget.FLASH
        # 重置 flash_index
        if not get_chip_config(chip_type).get("supports_dual_flash", False):
            self.flash_index = 0

    def get_burner_path(self) -> Optional[str]:
        """获取当前芯片的 burner 文件路径"""
        if self.burner and self.burner.file_path:
            return self.burner.file_path
        return None

    def get_load_addr(self) -> int:
        """获取当前芯片的 RAM 加载地址"""
        return get_load_addr(self.chip_type)

    def get_firmware_by_name(self, name: str) -> Optional[FirmwareInfo]:
        """按名称获取固件（不含 burner）"""
        for fw in self.firmwares:
            if fw.name == name:
                return fw
        return None

    def get_burnable_firmwares(self) -> List[FirmwareInfo]:
        """获取可烧录的固件列表（不含 burner，按地址排序）"""
        valid_fws = [
            fw for fw in self.firmwares
            if fw.file_path and os.path.isfile(fw.file_path)
        ]
        # 按地址排序
        return sorted(valid_fws, key=lambda fw: fw.addr)

    def add_firmware(self, firmware: FirmwareInfo):
        """添加固件并按地址排序"""
        self.firmwares.append(firmware)
        self.firmwares.sort(key=lambda fw: fw.addr)
        # 记住路径
        if firmware.file_path:
            self.last_firmware_dir = str(Path(firmware.file_path).parent)

    def clear_log_history(self):
        """清空日志历史"""
        self.log_history = []


# 全局状态实例
_state = State()