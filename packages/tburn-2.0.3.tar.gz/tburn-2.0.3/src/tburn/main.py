"""TBurn 主入口"""
import argparse
import logging

from ui.app import TBurn
from state import _state

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description='TBurn - 跨平台串口烧录工具'
    )
    parser.add_argument(
        '-p', '--port',
        help='串口端口'
    )
    parser.add_argument(
        '--debug',
        action='store_true',
        help='调试模式'
    )
    args = parser.parse_args()

    if args.debug:
        _state.dump_dbg = True

    # 启动应用
    app = TBurn(port=args.port)
    app.run()


if __name__ == "__main__":
    main()
