"""TBurn - 跨平台串口烧录工具"""
__version__ = "2.0.0"

from .main import main

__all__ = ["main", "__version__"]