"""TUI 应用模拟测试 - 验证烧录流程"""

import sys
import os
import asyncio
import time

sys.path.insert(0, '/Users/abc/workshop/abc/temp/2026/04/10/temp/TBurn/tui-app/src')

from pathlib import Path
from firmware import FirmwareInfo
from protocol.chips import ChipType, BurnTarget, get_load_addr, needs_sys_clk, supports_dual_flash
from protocol import read_hex_from_bin, getmd5_fromlist
from protocol.slip import slip_encode, slip_decode
from protocol.client import CSKBurnProtocolClient
from protocol.serial_thread import ReadSerialThread
from state import _state, Status

try:
    import serial
    from serial import Serial
    HAS_SERIAL = True
except ImportError:
    HAS_SERIAL = False
    print("❌ pyserial 未安装")
    sys.exit(1)


def log_callback(direction, cmd, msg):
    """日志回调"""
    cmd_names = {
        0x02: "FLASH_BEGIN", 0x03: "FLASH_DATA", 0x04: "FLASH_END",
        0x05: "MEM_BEGIN", 0x06: "MEM_END", 0x07: "MEM_DATA",
        0x08: "SYNC", 0x0a: "READ_REG", 0x0f: "CHANGE_BAUD",
        0x13: "SPI_FLASH_MD5", 0x31: "SET_SYS_CLK",
        0x42: "EMMC_BEGIN", 0x43: "EMMC_DATA", 0x44: "EMMC_END",
        0xF5: "SET_FLASH_INDEX"
    }
    cmd_name = cmd_names.get(cmd, f"0x{cmd:02X}")
    if direction == 'REQ':
        print(f"→ {cmd_name}")
    else:
        print(f"← {cmd_name}: {msg}")


async def test_tui_burn_flow():
    """模拟 TUI 烧录流程"""
    print("=" * 60)
    print("TUI 烧录流程模拟测试")
    print("=" * 60)

    # 配置参数（模拟 _state）
    port = "/dev/cu.wchusbserial5ABA1276681"
    chip_type = ChipType.ARCS
    baudrate = 2000000
    auto_enter_burn = True  # 自动进入烧录模式（控制 RTS/DTR）

    # 固件
    firmware_path = "/Users/abc/Downloads/helloworld.bin"
    firmware_addr = 0x0

    # Burner
    burner_path = Path('/Users/abc/workshop/abc/temp/2026/04/10/temp/TBurn/tui-app/src/res/burner_arcs.img')

    print(f"\n配置:")
    print(f"  端口: {port}")
    print(f"  芯片: {chip_type.value}")
    print(f"  波特率: {baudrate}")
    print(f"  自动进入烧录模式: {auto_enter_burn}")
    print(f"  固件: {firmware_path}")
    print(f"  Burner: {burner_path}")

    # 检查文件
    if not os.path.isfile(firmware_path):
        print(f"❌ 固件文件不存在")
        return False
    if not burner_path.exists():
        print(f"❌ Burner 文件不存在")
        return False

    firmware_data = read_hex_from_bin(firmware_path)
    firmware_size = len(firmware_data)
    burner_data = read_hex_from_bin(str(burner_path))
    burner_size = len(burner_data)

    print(f"  固件大小: {firmware_size/1024:.1f}KB")
    print(f"  Burner大小: {burner_size/1024:.1f}KB")

    # ==================== 步骤1: 初始化串口 ====================
    print("\n" + "=" * 60)
    print("步骤1: 初始化串口")
    print("=" * 60)

    serial_thread = ReadSerialThread(True, port)
    if not serial_thread.init_serial(port, 115200):
        print(f"❌ 无法打开串口 {port}")
        return False

    serial_thread.start()
    serial_thread.mark_start()

    protocol_client = CSKBurnProtocolClient(
        serial_thread,
        dump_dbg=False,
        funcname_dbg=False,
        log_callback=log_callback
    )

    print(f"✅ 串口已打开: {port}@115200")

    # ==================== 步骤2: 自动进入烧录模式 ====================
    print("\n" + "=" * 60)
    if auto_enter_burn:
        print("步骤2: 自动进入烧录模式 (RTS/DTR 控制)")
        print("=" * 60)
        print("执行 iBurn2 复位序列...")

        serial_thread.reset_sequence(chip_type, 100)
        await asyncio.sleep(0.5)  # 等待设备稳定

        print("✅ RTS/DTR 序列执行完成")
    else:
        print("步骤2: 手动进入烧录模式")
        print("=" * 60)
        print("请手动让芯片进入烧录模式")
        # 等待用户操作...

    # ==================== 步骤3: 同步设备 ====================
    print("\n" + "=" * 60)
    print("步骤3: 同步设备")
    print("=" * 60)

    sync_success = False
    for attempt in range(20):
        if protocol_client.cmd_sync(0.3):
            sync_success = True
            print(f"✅ 设备同步成功 (尝试 {attempt+1})")
            break
        await asyncio.sleep(0.1)

    if not sync_success:
        print("❌ 设备同步失败")
        serial_thread.deinit_serial()
        return False

    # 读取芯片 ID
    chip_id = protocol_client.cmd_read_chip_id()
    if chip_id:
        print(f"✅ 芯片 ID: {chip_id}")

    # ==================== 步骤4: 加载 Burner ====================
    print("\n" + "=" * 60)
    print("步骤4: 加载 Burner")
    print("=" * 60)

    load_addr = get_load_addr(chip_type)
    print(f"加载地址: 0x{load_addr:X}")

    # ROM 波特率切换 - cmd_change_baud 已内置 reload
    if baudrate != 115200:
        rom_baud = min(baudrate, 3000000)
        print(f"ROM 波特率切换: {rom_baud}")

        # cmd_change_baud 会发送命令并自动切换波特率
        if protocol_client.cmd_change_baud(rom_baud):
            print(f"✅ ROM 波特率切换成功")

            # 同步确认
            for sync_attempt in range(5):
                if protocol_client.cmd_sync(0.5):
                    print(f"✅ ROM 同步成功")
                    break
                await asyncio.sleep(0.1)

    # MEM_BEGIN
    blocks = protocol_client.BLOCKS(burner_size, protocol_client.RAM_BLOCK_SIZE)
    print(f"发送 {blocks} 个数据块...")

    if not protocol_client.cmd_mem_begin(burner_size, blocks, protocol_client.RAM_BLOCK_SIZE, load_addr):
        print("❌ MEM_BEGIN 失败")
        serial_thread.deinit_serial()
        return False

    # MEM_DATA
    for i in range(blocks):
        offset = protocol_client.RAM_BLOCK_SIZE * i
        length = min(protocol_client.RAM_BLOCK_SIZE, burner_size - offset)

        if not protocol_client.cmd_mem_block(burner_data[offset:offset+length], length, i):
            print(f"❌ MEM_DATA block {i} 失败")
            serial_thread.deinit_serial()
            return False

        if i % 10 == 0:
            print(f"  进度: {i+1}/{blocks}")

    print("✅ Burner 数据发送完成")

    # MEM_END - 传入跳转地址（参考 iBurn2）
    # 格式: [option(4字节,=0)] + [address(4字节,=load_addr)]
    if not protocol_client.cmd_mem_end(load_addr):
        print("❌ MEM_END 失败")
        serial_thread.deinit_serial()
        return False

    print("✅ Burner 加载完成")

    # 重要：ROM 波特率切换后，burner 启动时使用 115200
    # 需要切换回 115200 再同步 burner（参考 iBurn2）
    if baudrate != 115200:
        print(f"切换回 115200 以同步 Burner...")
        serial_thread.reload(115200)
        await asyncio.sleep(0.1)

    # 等待 Burner 启动
    await asyncio.sleep(1.0)

    # 清空串口缓冲区
    serial_thread.swap()
    if serial_thread.serial:
        serial_thread.serial.reset_input_buffer()

    # 同步 Burner（多次尝试）
    sync_success = False
    for attempt in range(20):
        print(f"  SYNC 尝试 {attempt+1}/20...")
        if protocol_client.cmd_sync(0.5):
            sync_success = True
            print(f"✅ Burner 同步成功 (尝试 {attempt+1})")
            break
        await asyncio.sleep(0.1)

    if not sync_success:
        print("❌ Burner 同步失败")
        serial_thread.deinit_serial()
        return False

    # ==================== 步骤5: 切换波特率 ====================
    print("\n" + "=" * 60)
    print("步骤5: 切换波特率")
    print("=" * 60)

    if protocol_client.cmd_change_baud(baudrate):
        print(f"✅ 波特率切换成功: {baudrate}")

        if protocol_client.cmd_sync(0.3):
            print(f"✅ 高速波特率同步成功")

    # ==================== 步骤6: 烧录固件 ====================
    print("\n" + "=" * 60)
    print("步骤6: 烧录固件")
    print("=" * 60)

    flash_block_size = 0x1000
    bunch_size = 191

    total_blocks = (firmware_size + flash_block_size - 1) // flash_block_size
    total_bunches = (total_blocks + bunch_size - 1) // bunch_size

    # ARCS芯片需要显式擦除Flash区域
    # 计算对齐后的大小（向上对齐到4096字节）
    flash_align = flash_block_size  # 4096
    aligned_size = ((firmware_size + flash_align - 1) // flash_align) * flash_align

    print(f"擦除 Flash 区域 0x{firmware_addr:X}-0x{firmware_addr + aligned_size:X}...")

    if not protocol_client.cmd_flash_erase_region(firmware_addr, aligned_size):
        print("❌ Flash 区域擦除失败")
        serial_thread.deinit_serial()
        return False

    print("✅ Flash 区域擦除完成")

    print(f"烧录 {firmware_size/1024:.1f}KB")

    burn_success = True

    for bunch_idx in range(total_bunches):
        bunch_start = bunch_idx * bunch_size * flash_block_size
        bunch_len = min(bunch_size * flash_block_size, firmware_size - bunch_start)
        bunch_blocks = (bunch_len + flash_block_size - 1) // flash_block_size
        bunch_addr = firmware_addr + bunch_start
        bunch_md5 = getmd5_fromlist(firmware_data[bunch_start:bunch_start + bunch_len])

        print(f"分段 {bunch_idx+1}/{total_bunches}: 0x{bunch_addr:X}")

        if not protocol_client.cmd_flash_begin(bunch_len, bunch_blocks, flash_block_size, bunch_addr, bunch_md5):
            print("❌ FLASH_BEGIN 失败")
            burn_success = False
            break

        for block_idx in range(bunch_blocks):
            offset = flash_block_size * block_idx
            length = min(flash_block_size, bunch_len - offset)
            block_data = firmware_data[bunch_start + offset:bunch_start + offset + length]

            ret = protocol_client.cmd_flash_block(block_data, length, block_idx)
            if not isinstance(ret, dict) or not ret.get('ret'):
                print(f"❌ FLASH_DATA block {block_idx} 失败")
                burn_success = False
                break

            if block_idx % 10 == 0:
                print(f"  进度: {block_idx+1}/{bunch_blocks}")

        if not burn_success:
            break

        await asyncio.sleep(0.1)

    # ==================== 步骤7: 校验 ====================
    if burn_success:
        print("\n" + "=" * 60)
        print("步骤7: 校验固件 (MD5)")
        print("=" * 60)

        # 计算本地固件MD5
        expected_md5 = f"{getmd5_fromlist(firmware_data):032x}"
        print(f"本地 MD5: {expected_md5}")

        md5_result = protocol_client.cmd_flash_md5sum(firmware_addr, firmware_size)
        if md5_result:
            actual_md5 = md5_result.replace('0x', '').lstrip('0').zfill(32)
            print(f"设备 MD5: {actual_md5}")

            if expected_md5 == actual_md5:
                print("✅ MD5校验通过")
            else:
                print(f"❌ MD5校验失败")
                burn_success = False
        else:
            print("❌ 无法获取设备MD5")
            burn_success = False

    # ==================== 步骤8: 复位设备 ====================
    print("\n" + "=" * 60)
    print("步骤8: 复位设备")
    print("=" * 60)

    serial_thread.reset_device(chip_type, 100)
    print("✅ 设备已复位")

    # 清理
    serial_thread.deinit_serial()

    print("\n" + "=" * 60)
    print("烧录结果")
    print("=" * 60)

    if burn_success:
        print("\n✅ 烧录成功!")
        return True
    else:
        print("\n❌ 烧录失败!")
        return False


if __name__ == "__main__":
    result = asyncio.run(test_tui_burn_flow())
    sys.exit(0 if result else 1)