"""测试 TUI 内部烧录逻辑 - 验证修复"""

import sys
import os
import asyncio

sys.path.insert(0, '/Users/abc/workshop/abc/temp/2026/04/10/temp/TBurn/tui-app/src')

from pathlib import Path
from protocol.chips import ChipType, get_load_addr
from protocol import read_hex_from_bin
from protocol.client import CSKBurnProtocolClient
from protocol.serial_thread import ReadSerialThread
from state import _state, Status
from firmware import FirmwareInfo

try:
    import serial
    HAS_SERIAL = True
except ImportError:
    HAS_SERIAL = False
    print("❌ pyserial 未安装")
    sys.exit(1)


def log_callback(direction, cmd, msg):
    """日志回调"""
    cmd_names = {
        0x02: "FLASH_BEGIN", 0x03: "FLASH_DATA", 0x04: "FLASH_END",
        0x05: "MEM_BEGIN", 0x06: "MEM_END", 0x07: "MEM_DATA",
        0x08: "SYNC", 0x0a: "READ_REG", 0x0f: "CHANGE_BAUD",
        0x13: "SPI_FLASH_MD5"
    }
    cmd_name = cmd_names.get(cmd, f"0x{cmd:02X}")
    if direction == 'REQ':
        print(f"→ {cmd_name}")
    else:
        print(f"← {cmd_name}: {msg}")


async def test_tui_enter_burn():
    """测试 TUI 的 _do_enter_burn 逻辑"""
    print("=" * 60)
    print("测试 TUI _do_enter_burn 逻辑（验证修复）")
    print("=" * 60)

    # 配置
    port = "/dev/cu.wchusbserial5ABA1276681"
    chip_type = ChipType.ARCS
    baudrate = 2000000

    burner_path = Path('/Users/abc/workshop/abc/temp/2026/04/10/temp/TBurn/tui-app/src/res/burner_arcs.img')
    if not burner_path.exists():
        print(f"❌ Burner 文件不存在")
        return False

    print(f"\n配置:")
    print(f"  端口: {port}")
    print(f"  芯片: {chip_type.value}")
    print(f"  波特率: {baudrate}")
    print(f"  Burner: {burner_path}")

    burner_data = read_hex_from_bin(str(burner_path))
    burner_len = len(burner_data)
    print(f"  Burner大小: {burner_len/1024:.1f}KB")

    # ========== 步骤1: 初始化串口 ==========
    print("\n" + "=" * 60)
    print("步骤1: 初始化串口")
    print("=" * 60)

    serial_thread = ReadSerialThread(False, port)
    if not serial_thread.init_serial(port, 115200):
        print(f"❌ 无法打开串口 {port}")
        return False

    serial_thread.start()
    serial_thread.mark_start()

    protocol_client = CSKBurnProtocolClient(
        serial_thread,
        dump_dbg=False,
        funcname_dbg=False,
        log_callback=log_callback
    )

    print(f"✅ 串口已打开: {port}@115200")

    # ========== 步骤2: 复位设备 ==========
    print("\n" + "=" * 60)
    print("步骤2: 复位设备 (RTS/DTR)")
    print("=" * 60)

    print("执行 ARCS 复位序列...")
    serial_thread.reset_sequence(chip_type, 100)
    await asyncio.sleep(0.5)

    # ========== 步骤3: 同步设备 ==========
    print("\n" + "=" * 60)
    print("步骤3: 同步设备")
    print("=" * 60)

    sync_success = False
    for attempt in range(10):
        if protocol_client.cmd_sync(0.3):
            sync_success = True
            print(f"✅ 设备同步成功 (尝试 {attempt+1})")
            break
        await asyncio.sleep(0.1)

    if not sync_success:
        print("❌ 设备同步失败")
        serial_thread.deinit_serial()
        return False

    # ========== 步骤4: 加载 Burner ==========
    print("\n" + "=" * 60)
    print("步骤4: 加载 Burner")
    print("=" * 60)

    load_addr = get_load_addr(chip_type)
    blocks = protocol_client.BLOCKS(burner_len, protocol_client.RAM_BLOCK_SIZE)
    print(f"加载地址: 0x{load_addr:X}, {blocks} 个数据块")

    # ROM 波特率切换
    if baudrate != 115200:
        rom_baud = min(baudrate, 3000000)
        print(f"ROM 波特率切换: {rom_baud}")

        if protocol_client.cmd_change_baud(rom_baud):
            print(f"✅ ROM 波特率切换成功")
            await asyncio.sleep(0.1)

            # 同步确认
            for sync_attempt in range(5):
                if protocol_client.cmd_sync(0.5):
                    print(f"✅ ROM 同步成功")
                    break
                await asyncio.sleep(0.1)

    # MEM_BEGIN
    if not protocol_client.cmd_mem_begin(burner_len, blocks, protocol_client.RAM_BLOCK_SIZE, load_addr):
        print("❌ MEM_BEGIN 失败")
        serial_thread.deinit_serial()
        return False
    print("✅ MEM_BEGIN 成功")

    # MEM_DATA
    for i in range(blocks):
        offset = protocol_client.RAM_BLOCK_SIZE * i
        length = min(protocol_client.RAM_BLOCK_SIZE, burner_len - offset)

        if not protocol_client.cmd_mem_block(burner_data[offset:offset+length], length, i):
            print(f"❌ MEM_DATA block {i} 失败")
            serial_thread.deinit_serial()
            return False

        if i % 10 == 0:
            print(f"  进度: {i+1}/{blocks}")

    print("✅ Burner 数据发送完成")

    # MEM_END - 传入 load_addr
    print(f"MEM_END: 跳转到 0x{load_addr:X}")
    if not protocol_client.cmd_mem_end(load_addr):
        print("❌ MEM_END 失败")
        serial_thread.deinit_serial()
        return False
    print("✅ Burner 加载完成")

    # ========== 关键修复步骤 ==========
    # 重要：ROM 波特率切换后，burner 启动时使用 115200
    # 需要切换回 115200 再同步 burner（参考 iBurn2）
    if baudrate != 115200:
        print("\n关键修复步骤: 切换回 115200 以同步 Burner...")
        serial_thread.reload(115200)
        await asyncio.sleep(0.1)

    print("等待 burner 启动...")
    await asyncio.sleep(1.0)

    # 清空串口缓冲区
    serial_thread.swap()
    if serial_thread.serial:
        serial_thread.serial.reset_input_buffer()

    # 同步 Burner（多次尝试）
    print("同步 Burner...")
    sync_success = False
    for attempt in range(20):
        if protocol_client.cmd_sync(0.5):
            sync_success = True
            print(f"✅ Burner 同步成功 (尝试 {attempt+1})")
            break
        await asyncio.sleep(0.1)

    if not sync_success:
        print("❌ Burner 同步失败")
        serial_thread.deinit_serial()
        return False

    # ========== 步骤5: 切换波特率 ==========
    print("\n" + "=" * 60)
    print("步骤5: 切换波特率")
    print("=" * 60)

    if protocol_client.cmd_change_baud(baudrate):
        print(f"✅ 波特率切换成功: {baudrate}")

        for sync_attempt in range(5):
            await asyncio.sleep(0.1)
            if protocol_client.cmd_sync(0.3):
                print(f"✅ 高速波特率同步成功")
                break

    # ========== 步骤6: 复位设备 ==========
    print("\n" + "=" * 60)
    print("步骤6: 复位设备")
    print("=" * 60)

    serial_thread.reset_device(chip_type, 100)
    print("✅ 设备已复位")

    # 清理
    serial_thread.deinit_serial()

    print("\n" + "=" * 60)
    print("测试结果")
    print("=" * 60)
    print("\n✅ _do_enter_burn 逻辑验证成功!")
    return True


if __name__ == "__main__":
    result = asyncio.run(test_tui_enter_burn())
    sys.exit(0 if result else 1)