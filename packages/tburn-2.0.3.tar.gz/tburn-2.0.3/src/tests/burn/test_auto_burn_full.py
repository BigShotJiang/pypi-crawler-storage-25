"""TUI 自动烧录完整测试

模拟 TUI 的自动烧录流程，验证所有步骤是否正常工作。
"""

import sys
import os
import asyncio
import time

sys.path.insert(0, '/Users/abc/workshop/abc/temp/2026/04/10/temp/TBurn/tui-app/src')

from pathlib import Path
from firmware import FirmwareInfo
from protocol.chips import ChipType, BurnTarget, get_load_addr, needs_sys_clk, supports_dual_flash
from protocol import read_hex_from_bin, getmd5_fromlist
from protocol.slip import slip_encode, slip_decode
from protocol.client import CSKBurnProtocolClient
from protocol.serial_thread import ReadSerialThread
from state import _state, Status

try:
    import serial
    from serial import Serial
    HAS_SERIAL = True
except ImportError:
    HAS_SERIAL = False
    print("❌ pyserial 未安装")
    sys.exit(1)


def slip_encode_bytes(data):
    """SLIP 编码返回字节"""
    return bytes(slip_encode(list(data)))


def parse_response(data):
    """解析响应"""
    if len(data) < 8:
        return None
    return {
        'direction': data[0],
        'command': data[1],
        'size': data[2] | (data[3] << 8),
        'value': data[4] | (data[5] << 8) | (data[6] << 16) | (data[7] << 24),
        'valid': data[0] == 0x01
    }


def send_command_direct(s, cmd_code, data, timeout=0.2):
    """直接发送命令并等待响应"""
    data_len = len(data)
    header = bytes([
        0x00, cmd_code,
        data_len & 0xFF, (data_len >> 8) & 0xFF,
        0, 0, 0, 0
    ])
    packet = header + bytes(data)
    slip_packet = slip_encode_bytes(packet)

    # 清空缓冲区
    s.reset_input_buffer()

    # 发送
    s.write(slip_packet)
    s.flush()

    # 等待响应
    received = []
    start_time = time.time()

    while time.time() - start_time < timeout:
        data = s.read(200)
        if data:
            received.extend(list(data))
            if 0xC0 in received:
                try:
                    start_idx = received.index(0xC0)
                    end_idx = received.index(0xC0, start_idx + 1)
                    if end_idx >= start_idx + 10:
                        frame = received[start_idx:end_idx + 1]
                        decoded = slip_decode(frame)
                        if len(decoded) >= 8:
                            return parse_response(decoded)
                except ValueError:
                    pass
        time.sleep(0.01)

    return None


async def test_auto_burn():
    """完整自动烧录测试"""
    print("=" * 60)
    print("TUI 自动烧录完整测试")
    print("=" * 60)

    # 配置
    port = "/dev/cu.wchusbserial5ABA1276681"
    chip_type = ChipType.ARCS
    baudrate = 2000000
    firmware_addr = 0x0
    firmware_path = "/Users/abc/Downloads/helloworld.bin"

    # 加载 burner
    burner_path = Path('/Users/abc/workshop/abc/temp/2026/04/10/temp/TBurn/tui-app/src/res/burner_arcs.img')
    if not burner_path.exists():
        print(f"❌ Burner 文件不存在: {burner_path}")
        return False

    # 检查固件
    if not os.path.isfile(firmware_path):
        print(f"❌ 固件文件不存在: {firmware_path}")
        return False

    firmware_data = read_hex_from_bin(firmware_path)
    firmware_size = len(firmware_data)
    burner_data = read_hex_from_bin(str(burner_path))
    burner_size = len(burner_data)

    print(f"\n配置:")
    print(f"  端口: {port}")
    print(f"  芯片: {chip_type.value}")
    print(f"  波特率: {baudrate}")
    print(f"  固件: {firmware_size/1024:.1f}KB")
    print(f"  Burner: {burner_size/1024:.1f}KB")

    # 打开串口
    print("\n" + "=" * 60)
    print("步骤1: 打开串口")
    print("=" * 60)

    try:
        s = Serial(port, 115200, timeout=0.1)
        print(f"✅ 串口已打开: {port}@115200")
    except Exception as e:
        print(f"❌ 无法打开串口: {e}")
        return False

    # 复位设备
    print("\n" + "=" * 60)
    print("步骤2: 复位设备 (自动烧录)")
    print("=" * 60)

    print("执行 ARCS 复位序列...")
    s.rts = True
    s.dtr = False
    time.sleep(0.1)
    s.rts = False
    s.dtr = True
    time.sleep(0.1)
    s.rts = True
    s.dtr = True
    print("✅ 复位序列完成")
    time.sleep(0.5)  # 增加等待时间，让设备稳定

    # 同步
    print("\n" + "=" * 60)
    print("步骤3: 同步设备")
    print("=" * 60)

    sync_data = [0x07, 0x07, 0x12, 0x20] + [0x55] * 32

    # 多次尝试同步
    sync_result = None
    for attempt in range(20):
        sync_result = send_command_direct(s, 0x08, sync_data, 0.3)
        if sync_result and sync_result['valid']:
            print(f"✅ 设备同步成功 (尝试 {attempt+1}/20)")
            break
        time.sleep(0.1)

    if not sync_result or not sync_result['valid']:
        print("❌ 设备同步失败")
        s.close()
        return False

    # 加载 Burner
    print("\n" + "=" * 60)
    print("步骤4: 加载 Burner")
    print("=" * 60)

    load_addr = get_load_addr(chip_type)
    ram_block_size = 0x800
    blocks = (burner_size + ram_block_size - 1) // ram_block_size

    print(f"加载到 0x{load_addr:X}, {blocks} 个数据块")

    # ROM 波特率切换
    if baudrate != 115200:
        rom_baud = min(baudrate, 3000000)
        print(f"ROM 波特率切换: {rom_baud}")
        baud_cmd = [
            rom_baud & 0xFF, (rom_baud >> 8) & 0xFF, (rom_baud >> 16) & 0xFF, (rom_baud >> 24) & 0xFF,
            115200 & 0xFF, (115200 >> 8) & 0xFF, (115200 >> 16) & 0xFF, (115200 >> 24) & 0xFF,
        ]
        baud_result = send_command_direct(s, 0x0F, baud_cmd, 0.5)
        if baud_result and baud_result['valid']:
            print("✅ ROM 波特率切换命令成功")
            time.sleep(0.1)

            # 关闭串口，用新波特率重新打开
            s.close()
            try:
                s = Serial(port, rom_baud, timeout=0.1)
                print(f"✅ 串口已切换到 {rom_baud}")
            except:
                print(f"⚠️ 无法以 {rom_baud} 打开串口，继续使用 115200")
                s = Serial(port, 115200, timeout=0.1)

            sync_result = send_command_direct(s, 0x08, sync_data, 0.5)
            if sync_result and sync_result['valid']:
                print("✅ 高速同步成功")

    # MEM_BEGIN
    mem_begin_data = [
        burner_size & 0xFF, (burner_size >> 8) & 0xFF, (burner_size >> 16) & 0xFF, (burner_size >> 24) & 0xFF,
        blocks & 0xFF, (blocks >> 8) & 0xFF, (blocks >> 16) & 0xFF, (blocks >> 24) & 0xFF,
        ram_block_size & 0xFF, (ram_block_size >> 8) & 0xFF, (ram_block_size >> 16) & 0xFF, (ram_block_size >> 24) & 0xFF,
        load_addr & 0xFF, (load_addr >> 8) & 0xFF, (load_addr >> 16) & 0xFF, (load_addr >> 24) & 0xFF,
    ]

    mem_result = send_command_direct(s, 0x05, mem_begin_data, 1.0)
    if not mem_result or not mem_result['valid']:
        print("❌ MEM_BEGIN 失败")
        s.close()
        return False
    print("✅ MEM_BEGIN 成功")

    # 发送 burner 数据
    print(f"发送 {blocks} 个数据块...")
    for i in range(blocks):
        offset = ram_block_size * i
        length = min(ram_block_size, burner_size - offset)
        block_data = list(burner_data[offset:offset + length])

        mem_data_cmd = [
            length & 0xFF, (length >> 8) & 0xFF, (length >> 16) & 0xFF, (length >> 24) & 0xFF,
            i & 0xFF, (i >> 8) & 0xFF, (i >> 16) & 0xFF, (i >> 24) & 0xFF,
            0, 0, 0, 0,
        ] + block_data

        mem_result = send_command_direct(s, 0x07, mem_data_cmd, 0.5)
        if not mem_result or not mem_result['valid']:
            print(f"❌ MEM_DATA block {i} 失败")
            s.close()
            return False

        if i % 10 == 0:
            print(f"  进度: {i+1}/{blocks}")

    print("✅ Burner 数据发送完成")

    # MEM_END
    mem_end_data = [0] * 4
    mem_result = send_command_direct(s, 0x06, mem_end_data, 1.0)
    if not mem_result or not mem_result['valid']:
        print("❌ MEM_END 失败")
        s.close()
        return False
    print("✅ Burner 加载完成")

    time.sleep(0.5)

    # 同步 burner
    sync_result = send_command_direct(s, 0x08, sync_data, 0.5)
    if not sync_result or not sync_result['valid']:
        print("❌ Burner 同步失败")
        s.close()
        return False
    print("✅ Burner 同步成功")

    # 切换波特率
    print("\n" + "=" * 60)
    print("步骤5: 切换波特率")
    print("=" * 60)

    baud_cmd = [
        baudrate & 0xFF, (baudrate >> 8) & 0xFF, (baudrate >> 16) & 0xFF, (baudrate >> 24) & 0xFF,
        115200 & 0xFF, (115200 >> 8) & 0xFF, (115200 >> 16) & 0xFF, (115200 >> 24) & 0xFF,
    ]

    baud_result = send_command_direct(s, 0x0F, baud_cmd, 0.5)
    if baud_result and baud_result['valid']:
        print(f"✅ 波特率切换命令成功")
        time.sleep(0.1)
        s.close()

        try:
            s = Serial(port, baudrate, timeout=0.1)
            print(f"✅ 串口已切换到 {baudrate}")
        except:
            print(f"⚠️ 无法以 {baudrate} 打开串口，使用 115200")
            s = Serial(port, 115200, timeout=0.1)

        sync_result = send_command_direct(s, 0x08, sync_data, 0.5)
        if sync_result and sync_result['valid']:
            print("✅ 高速波特率同步成功")

    # 烧录固件
    print("\n" + "=" * 60)
    print("步骤6: 烧录固件")
    print("=" * 60)

    flash_block_size = 0x1000
    bunch_size = 191

    total_blocks = (firmware_size + flash_block_size - 1) // flash_block_size
    total_bunches = (total_blocks + bunch_size - 1) // bunch_size

    print(f"烧录 {firmware_size/1024:.1f}KB, {total_blocks} 个数据块")

    burn_success = True

    for bunch_idx in range(total_bunches):
        bunch_start = bunch_idx * bunch_size * flash_block_size
        bunch_len = min(bunch_size * flash_block_size, firmware_size - bunch_start)
        bunch_blocks = (bunch_len + flash_block_size - 1) // flash_block_size
        bunch_addr = firmware_addr + bunch_start
        bunch_md5 = getmd5_fromlist(firmware_data[bunch_start:bunch_start + bunch_len])

        # MD5 转 16 字节
        md5_bytes = [(bunch_md5 >> (8 * (15 - i))) & 0xFF for i in range(16)]

        print(f"\n分段 {bunch_idx+1}/{total_bunches}: 地址 0x{bunch_addr:X}")

        # FLASH_BEGIN
        flash_begin_data = [
            bunch_len & 0xFF, (bunch_len >> 8) & 0xFF, (bunch_len >> 16) & 0xFF, (bunch_len >> 24) & 0xFF,
            bunch_blocks & 0xFF, (bunch_blocks >> 8) & 0xFF, (bunch_blocks >> 16) & 0xFF, (bunch_blocks >> 24) & 0xFF,
            flash_block_size & 0xFF, (flash_block_size >> 8) & 0xFF, (flash_block_size >> 16) & 0xFF, (flash_block_size >> 24) & 0xFF,
            bunch_addr & 0xFF, (bunch_addr >> 8) & 0xFF, (bunch_addr >> 16) & 0xFF, (bunch_addr >> 24) & 0xFF,
        ] + md5_bytes

        flash_result = send_command_direct(s, 0x02, flash_begin_data, 1.0)
        if not flash_result or not flash_result['valid']:
            print("❌ FLASH_BEGIN 失败")
            burn_success = False
            break

        # FLASH_DATA
        for block_idx in range(bunch_blocks):
            offset = flash_block_size * block_idx
            length = min(flash_block_size, bunch_len - offset)
            block_data = list(firmware_data[bunch_start + offset:bunch_start + offset + length])

            flash_data_cmd = [
                length & 0xFF, (length >> 8) & 0xFF, (length >> 16) & 0xFF, (length >> 24) & 0xFF,
                block_idx & 0xFF, (block_idx >> 8) & 0xFF, (block_idx >> 16) & 0xFF, (block_idx >> 24) & 0xFF,
                0, 0, 0, 0,
            ] + block_data

            # 重试
            for retry in range(5):
                flash_result = send_command_direct(s, 0x03, flash_data_cmd, 1.0)
                if flash_result and flash_result['valid']:
                    break
                time.sleep(0.1)

            if not flash_result or not flash_result['valid']:
                print(f"❌ FLASH_DATA block {block_idx} 失败")
                burn_success = False
                break

            if block_idx % 10 == 0:
                print(f"  进度: {block_idx+1}/{bunch_blocks}")

        if not burn_success:
            break

        time.sleep(0.1)

    # 校验
    if burn_success:
        print("\n" + "=" * 60)
        print("步骤7: 校验固件")
        print("=" * 60)

        verify_md5 = getmd5_fromlist(firmware_data)
        verify_md5_bytes = [(verify_md5 >> (8 * (15 - i))) & 0xFF for i in range(16)]

        flash_verify_data = [
            firmware_size & 0xFF, (firmware_size >> 8) & 0xFF, (firmware_size >> 16) & 0xFF, (firmware_size >> 24) & 0xFF,
            firmware_addr & 0xFF, (firmware_addr >> 8) & 0xFF, (firmware_addr >> 16) & 0xFF, (firmware_addr >> 24) & 0xFF,
        ] + verify_md5_bytes

        verify_result = send_command_direct(s, 0x13, flash_verify_data, 2.0)
        if verify_result and verify_result['valid']:
            print("✅ 校验成功")
        else:
            print("⚠️ 校验失败（但烧录可能成功）")

    # 复位设备
    print("\n" + "=" * 60)
    print("步骤8: 复位设备（启动应用）")
    print("=" * 60)

    # ARCS 复位序列（启动应用）
    s.rts = True
    s.dtr = False
    time.sleep(0.5)
    s.rts = True
    s.dtr = True
    print("✅ 设备已复位")

    # 清理
    s.close()

    # 结果
    print("\n" + "=" * 60)
    print("烧录结果")
    print("=" * 60)

    if burn_success:
        print("\n✅ 烧录成功!")
        return True
    else:
        print("\n❌ 烧录失败!")
        return False


if __name__ == "__main__":
    result = asyncio.run(test_auto_burn())
    print(f"\n测试结果: {'成功' if result else '失败'}")
    sys.exit(0 if result else 1)