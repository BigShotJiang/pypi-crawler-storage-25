"""发送 SYNC 命令并等待响应"""
import sys
import os
import time

try:
    import serial
    from serial import Serial
except ImportError:
    print("❌ pyserial 未安装")
    sys.exit(1)

port = "/dev/cu.wchusbserial5ABA1276681"

print("=" * 60)
print("发送 SYNC 命令测试")
print("=" * 60)

print("\n打开串口...")
try:
    s = Serial(port, 115200, timeout=0.1)
    print(f"✅ 串口已打开")
except Exception as e:
    print(f"❌ 无法打开串口: {e}")
    sys.exit(1)

# 清空缓冲区
print("\n清空缓冲区...")
s.reset_input_buffer()

# 执行 iBurn2 复位序列
print("\n执行复位序列:")
s.rts = True
s.dtr = False
print("  RTS=True, DTR=False")
time.sleep(0.1)

s.rts = False
s.dtr = True
print("  RTS=False, DTR=True")
time.sleep(0.1)

s.rts = True
s.dtr = True
print("  RTS=True, DTR=HIGH")

# 等待设备稳定
time.sleep(0.2)

# 构建 SYNC 命令
print("\n构建 SYNC 命令...")
# SYNC 数据: [0x07, 0x07, 0x12, 0x20] + 32 bytes 0x55
sync_data = bytes([0x07, 0x07, 0x12, 0x20] + [0x55] * 32)

# 构建 SLIP 包
# Header: direction(0x00), command(0x08), size(36), checksum(0)
header = bytes([0x00, 0x08, 36, 0, 0, 0, 0, 0])  # 8 bytes header
packet = header + sync_data

# SLIP 编码
def slip_encode(data):
    END = 0xC0
    ESC = 0xDB
    ESC_END = 0xDC
    ESC_ESC = 0xDD
    result = [END]
    for b in data:
        if b == END:
            result.extend([ESC, ESC_END])
        elif b == ESC:
            result.extend([ESC, ESC_ESC])
        else:
            result.append(b)
    result.append(END)
    return bytes(result)

slip_packet = slip_encode(list(packet))
print(f"  SLIP 包大小: {len(slip_packet)} 字节")
print(f"  SLIP 包内容 (前20字节): {list(slip_packet)[:20]}")

# 发送 SYNC 命令
print("\n发送 SYNC 命令...")
s.write(slip_packet)
s.flush()

# 等待响应
print("\n等待响应...")
received = []
for i in range(50):
    data = s.read(200)
    if data:
        received.extend(list(data))
        print(f"  收到数据: {len(data)} 字节")

        # 检查是否有完整的 SLIP 帧
        if 0xC0 in received and len(received) >= 10:
            print(f"✅ 可能收到完整响应")
            print(f"  累计收到: {len(received)} 字节")
            print(f"  内容: {received[:50]}")
            break

    if i % 10 == 0:
        print(f"  等待 {i+1}/50...")
    time.sleep(0.05)

if received:
    print(f"\n最终收到: {len(received)} 字节")
    print(f"  内容: {received}")

    # 尝试解析 SLIP
    if len(received) >= 10:
        # 跳过第一个 C0
        if received[0] == 0xC0:
            # 找第二个 C0
            try:
                end_idx = received.index(0xC0, 1)
                frame = received[1:end_idx]
                print(f"\nSLIP 解码后: {frame}")

                # 解析响应
                if len(frame) >= 8:
                    direction = frame[0]
                    command = frame[1]
                    size = frame[2] | (frame[3] << 8)
                    value = frame[4] | (frame[5] << 8) | (frame[6] << 16) | (frame[7] << 24)
                    print(f"  direction: {direction}")
                    print(f"  command: 0x{command:02X}")
                    print(f"  size: {size}")
                    print(f"  value: {value}")

                    if direction == 0x01 and command == 0x08:
                        print("\n✅ SYNC 成功!")
            except:
                pass
else:
    print("\n❌ 未收到任何响应")

s.close()
print("\n测试完成")