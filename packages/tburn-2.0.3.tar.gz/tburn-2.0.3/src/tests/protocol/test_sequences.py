"""测试不同的 RTS/DTR 序列"""
import sys
import os
import time

_root = os.path.dirname(os.path.abspath(__file__))
if _root not in sys.path:
    sys.path.insert(0, _root)

from protocol.serial_thread import ReadSerialThread

port = "/dev/cu.wchusbserial5ABA1276681"

print("=" * 60)
print("测试不同的 RTS/DTR 序列")
print("=" * 60)

sequences = [
    # 序列1: iBurn2 序列
    {
        "name": "iBurn2 (RTS=1,DTR=0 → RTS=0,DTR=1 → RTS=1,DTR=1)",
        "steps": [
            (True, False, 0.1),   # RTS=HIGH, DTR=LOW
            (False, True, 0.1),   # RTS=LOW, DTR=HIGH
            (True, True, 0.0),    # RTS=HIGH, DTR=HIGH
        ]
    },
    # 序列2: 相反的序列
    {
        "name": "反向 (RTS=0,DTR=1 → RTS=1,DTR=0 → RTS=0,DTR=0)",
        "steps": [
            (False, True, 0.1),   # RTS=LOW, DTR=HIGH
            (True, False, 0.1),   # RTS=HIGH, DTR=LOW
            (False, False, 0.0),  # RTS=LOW, DTR=LOW
        ]
    },
    # 序列3: C 代码序列
    {
        "name": "C code (DTR=0,RTS=0 → DTR=1,RTS=1 → DTR=0,RTS=1)",
        "steps": [
            (False, False, 0.5),  # RTS=LOW, DTR=LOW
            (True, True, 0.5),    # RTS=HIGH, DTR=HIGH
            (True, False, 0.0),   # RTS=HIGH, DTR=LOW
        ]
    },
    # 序列4: 仅切换 RTS
    {
        "name": "仅 RTS 切换",
        "steps": [
            (False, True, 0.1),
            (True, True, 0.1),
            (False, True, 0.1),
            (True, True, 0.0),
        ]
    },
    # 序列5: 仅切换 DTR
    {
        "name": "仅 DTR 切换",
        "steps": [
            (True, False, 0.1),
            (True, True, 0.1),
            (True, False, 0.1),
            (True, True, 0.0),
        ]
    },
]

serial_thread = None

for seq in sequences:
    print(f"\n测试序列: {seq['name']}")

    # 创建新的串口线程
    serial_thread = ReadSerialThread(True, port)

    # 初始化串口
    if not serial_thread.init_serial(port, 115200):
        print(f"❌ 无法打开串口")
        time.sleep(1)
        continue

    serial_thread.start()
    serial_thread.mark_start()

    # 清空缓冲区
    time.sleep(0.1)
    serial_thread.swap()

    # 执行序列
    for rts, dtr, delay in seq['steps']:
        serial_thread.set_rts(rts)
        serial_thread.set_dtr(dtr)
        print(f"  RTS={rts}, DTR={dtr}")
        if delay > 0:
            time.sleep(delay)

    # 等待响应
    print("  等待响应...")
    time.sleep(0.3)

    received = serial_thread.read()
    if received:
        print(f"✅ 收到数据: {len(received)} 字节")
        print(f"  内容: {received[:30]}")
        serial_thread.deinit_serial()
        break
    else:
        print("  无响应")

    serial_thread.deinit_serial()
    time.sleep(1)

print("\n测试完成")