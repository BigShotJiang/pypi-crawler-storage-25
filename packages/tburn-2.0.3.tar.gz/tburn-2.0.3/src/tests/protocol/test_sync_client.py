"""快速测试 CSKBurnProtocolClient 的同步功能"""

import sys
import os
import asyncio
import time

sys.path.insert(0, '/Users/abc/workshop/abc/temp/2026/04/10/temp/TBurn/tui-app/src')

from protocol.chips import ChipType
from protocol.serial_thread import ReadSerialThread
from protocol.client import CSKBurnProtocolClient

port = "/dev/cu.wchusbserial5ABA1276681"
chip_type = ChipType.ARCS

print("=" * 60)
print("测试 CSKBurnProtocolClient 同步")
print("=" * 60)

# 初始化串口
print("\n初始化串口...")
serial_thread = ReadSerialThread(True, port)
if not serial_thread.init_serial(port, 115200):
    print(f"❌ 无法打开串口 {port}")
    sys.exit(1)

serial_thread.start()
serial_thread.mark_start()

print(f"✅ 串口已打开")

# 创建协议客户端
protocol_client = CSKBurnProtocolClient(
    serial_thread,
    dump_dbg=True,
    funcname_dbg=True
)

# 执行复位序列
print("\n执行复位序列...")
# ARCS: iBurn2 序列
serial_thread.set_rts(True)
serial_thread.set_dtr(False)
print("  RTS=True, DTR=False")
time.sleep(0.1)

serial_thread.set_rts(False)
serial_thread.set_dtr(True)
print("  RTS=False, DTR=True")
time.sleep(0.1)

serial_thread.set_rts(True)
serial_thread.set_dtr(True)
print("  RTS=True, DTR=True")

time.sleep(0.2)

# 同步测试
print("\n同步测试 (最多 10 次)...")

for i in range(10):
    print(f"尝试 {i+1}/10...")

    ret = protocol_client.cmd_sync(0.3)
    if ret:
        print(f"✅ 同步成功 (尝试 {i+1})")
        serial_thread.deinit_serial()
        sys.exit(0)

    time.sleep(0.1)

print("❌ 同步失败")
serial_thread.deinit_serial()
sys.exit(1)