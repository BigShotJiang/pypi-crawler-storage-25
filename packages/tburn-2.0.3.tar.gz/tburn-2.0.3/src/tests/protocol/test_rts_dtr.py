"""验证 RTS/DTR 控制"""
import sys
import os
import time

try:
    import serial
    from serial import Serial
except ImportError:
    print("❌ pyserial 未安装")
    sys.exit(1)

port = "/dev/cu.wchusbserial5ABA1276681"

print("=" * 60)
print("验证 RTS/DTR 控制")
print("=" * 60)

print("\n打开串口...")
try:
    s = Serial(port, 115200, timeout=0.1)
    print(f"✅ 串口已打开: {port}")
except Exception as e:
    print(f"❌ 无法打开串口: {e}")
    sys.exit(1)

print("\n测试 RTS/DTR 控制:")
print(f"  初始状态: RTS={s.rts}, DTR={s.dtr}")

# 测试 RTS
print("\n测试 RTS:")
s.rts = True
print(f"  RTS=True → 实际={s.rts}")
time.sleep(0.1)
s.rts = False
print(f"  RTS=False → 实际={s.rts}")
time.sleep(0.1)
s.rts = True
print(f"  RTS=True → 实际={s.rts}")

# 测试 DTR
print("\n测试 DTR:")
s.dtr = True
print(f"  DTR=True → 实际={s.dtr}")
time.sleep(0.1)
s.dtr = False
print(f"  DTR=False → 实际={s.dtr}")
time.sleep(0.1)
s.dtr = True
print(f"  DTR=True → 实际={s.dtr}")

# 执行 iBurn2 序列
print("\n执行 iBurn2 复位序列:")
print("  步骤1: RTS=True, DTR=False")
s.rts = True
s.dtr = False
time.sleep(0.1)

print("  步骤2: RTS=False, DTR=True")
s.rts = False
s.dtr = True
time.sleep(0.1)

print("  步骤3: RTS=True, DTR=True")
s.rts = True
s.dtr = True

print("\n等待设备响应...")
for i in range(10):
    data = s.read(100)
    if data:
        print(f"✅ 收到数据: {len(data)} 字节 - {list(data)[:30]}")
        break
    if i % 2 == 0:
        print(f"  等待 {i+1}/10...")
    time.sleep(0.5)

s.close()
print("\n测试完成")