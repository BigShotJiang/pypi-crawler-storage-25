"""测试状态管理 - Mock"""
import pytest
import sys
import os
from unittest.mock import patch, MagicMock

# 添加src到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from protocol.chips import ChipType, BurnTarget


class TestStatus:
    """测试状态枚举"""

    def test_status_enum_values(self):
        """测试状态枚举值"""
        from state import Status

        assert Status.UNINIT.value == "未初始化"
        assert Status.CONNECTED.value == "已连接"
        assert Status.ENTERED.value == "烧录模式"
        assert Status.BURNING.value == "烧录中"
        assert Status.VERIFYING.value == "校验中"
        assert Status.ERROR.value == "错误"


class TestState:
    """测试状态管理"""

    def test_state_chip_type_default(self):
        """测试默认芯片类型"""
        from state import State
        state = State()
        assert state.chip_type == ChipType.CSK6

    def test_state_burn_target_default(self):
        """测试默认烧录目标"""
        from state import State
        state = State()
        assert state.burn_target == BurnTarget.FLASH

    def test_state_port_default(self):
        """测试默认端口"""
        from state import State
        state = State()
        assert state.port is None

    def test_state_baudrate_default(self):
        """测试默认波特率"""
        from state import State
        state = State()
        assert state.baudrate == 1536000

    def test_state_auto_enter_burn_default(self):
        """测试默认自动进入烧录模式"""
        from state import State
        state = State()
        assert state.auto_enter_burn == True

    def test_state_auto_burn_mode_default(self):
        """测试默认自动烧录模式"""
        from state import State
        state = State()
        assert state.auto_burn_mode == "manual"

    def test_state_flash_index_default(self):
        """测试默认Flash索引"""
        from state import State
        state = State()
        assert state.flash_index == 0

    def test_state_firmwares_default(self):
        """测试默认固件列表"""
        from state import State
        state = State()
        assert state.firmwares == []

    def test_state_log_history_default(self):
        """测试默认日志历史"""
        from state import State
        state = State()
        assert state.log_history == []

    def test_state_set_chip_type(self):
        """测试设置芯片类型"""
        from state import State
        state = State()
        state.set_chip_type(ChipType.ARCS)
        assert state.chip_type == ChipType.ARCS

    def test_state_set_chip_type_to_arcs_dual(self):
        """测试设置芯片类型为ARCS_DUAL"""
        from state import State
        state = State()
        state.set_chip_type(ChipType.ARCS_DUAL)
        assert state.chip_type == ChipType.ARCS_DUAL

    def test_state_set_burn_target(self):
        """测试设置烧录目标"""
        from state import State
        state = State()
        state.burn_target = BurnTarget.EMMC
        assert state.burn_target == BurnTarget.EMMC

    def test_state_set_port(self):
        """测试设置端口"""
        from state import State
        state = State()
        state.port = "/dev/ttyUSB0"
        assert state.port == "/dev/ttyUSB0"

    def test_state_set_baudrate(self):
        """测试设置波特率"""
        from state import State
        state = State()
        state.baudrate = 1500000
        assert state.baudrate == 1500000

    def test_state_auto_enter_burn_toggle(self):
        """测试自动进入烧录模式切换"""
        from state import State
        state = State()
        state.auto_enter_burn = False
        assert state.auto_enter_burn == False
        state.auto_enter_burn = True
        assert state.auto_enter_burn == True

    def test_state_auto_burn_mode_setter(self):
        """测试自动烧录模式设置"""
        from state import State
        state = State()
        state.auto_burn_mode = "wait"
        assert state.auto_burn_mode == "wait"
        state.auto_burn_mode = "repeat"
        assert state.auto_burn_mode == "repeat"

    def test_state_clear_log_history(self):
        """测试清空日志历史"""
        from state import State
        state = State()
        state.log_history = ["log1", "log2"]
        state.clear_log_history()
        assert state.log_history == []

    def test_state_get_load_addr(self):
        """测试获取加载地址"""
        from state import State
        state = State()
        state.set_chip_type(ChipType.ARCS)
        addr = state.get_load_addr()
        assert addr == 0x20040000


class TestFirmwareInfo:
    """测试固件信息"""

    def test_firmware_info_creation(self):
        """测试固件信息创建"""
        from firmware import FirmwareInfo
        fw = FirmwareInfo(name="master.bin", addr=0x10000, file_path="")
        assert fw.name == "master.bin"
        assert fw.addr == 0x10000
        assert fw.file_path == ""
        assert fw.burn_status == "-"

    def test_firmware_info_to_dict(self):
        """测试固件信息转字典"""
        from firmware import FirmwareInfo
        fw = FirmwareInfo(name="test.bin", addr=0x40000, file_path="")
        d = fw.to_dict()
        assert d['name'] == "test.bin"
        assert d['addr'] == 0x40000
        assert d['file_path'] == ""
        assert d['burn_status'] == "-"

    def test_firmware_info_from_dict(self):
        """测试从字典创建固件信息"""
        from firmware import FirmwareInfo
        d = {'name': 'test.bin', 'addr': 0x80000, 'file_path': '/tmp/test.bin', 'burn_status': '√'}
        fw = FirmwareInfo.from_dict(d)
        assert fw.name == "test.bin"
        assert fw.addr == 0x80000
        assert fw.file_path == "/tmp/test.bin"
        assert fw.burn_status == "√"

    def test_firmware_info_repr(self):
        """测试固件信息字符串表示"""
        from firmware import FirmwareInfo
        fw = FirmwareInfo(name="test.bin", addr=0x10000, file_path="")
        repr_str = repr(fw)
        assert "test.bin" in repr_str
        assert "0x10000" in repr_str


class TestConfig:
    """测试配置管理"""

    @patch('config.CONFIG_FILE')
    def test_load_config_empty(self, mock_config_file):
        """测试加载空配置"""
        from config import load_config
        mock_config_file.exists = MagicMock(return_value=False)
        config = load_config()
        assert config == {}

    @patch('config.CONFIG_FILE')
    def test_load_config_with_data(self, mock_config_file):
        """测试加载有数据的配置"""
        from config import load_config
        mock_config_file.exists = MagicMock(return_value=True)
        mock_config_file.read_text = MagicMock(
            return_value='{"port": "/dev/ttyUSB0", "baudrate": 1500000}'
        )
        config = load_config()
        assert config.get("port") == "/dev/ttyUSB0"
        assert config.get("baudrate") == 1500000

    @patch('config.CONFIG_FILE')
    def test_save_config(self, mock_config_file):
        """测试保存配置"""
        from config import save_config
        mock_config_file.write_text = MagicMock()
        save_config({"port": "/dev/ttyUSB1"})
        mock_config_file.write_text.assert_called_once()