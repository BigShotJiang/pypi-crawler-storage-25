"""手动烧录测试 - 诊断脚本"""
import sys
import os
import asyncio

# 添加项目路径
_root = os.path.dirname(os.path.abspath(__file__))
if _root not in sys.path:
    sys.path.insert(0, _root)

from protocol.chips import ChipType
from protocol.serial_thread import ReadSerialThread

print("=" * 60)
print("ARCS 设备诊断脚本")
print("=" * 60)

port = "/dev/cu.wchusbserial5ABA1276681"

print(f"\n请按以下步骤操作:")
print("1. 确保 ARCS 设备已正确连接到串口")
print("2. 手动给设备断电")
print("3. 等待 3 秒后给设备通电")
print("4. 脚本将自动继续...")
print("")

import time
time.sleep(5)  # 给用户时间操作

print("\n初始化串口...")
serial_thread = ReadSerialThread(True, port)
if not serial_thread.init_serial(port, 115200):
    print(f"❌ 无法打开串口 {port}")
    sys.exit(1)

serial_thread.start()
serial_thread.mark_start()
print(f"✅ 串口已打开")

print("\n执行 ARCS 复位序列...")
# iBurn2 序列
serial_thread.set_rts(True)
serial_thread.set_dtr(False)
print("  RTS=HIGH, DTR=LOW")
import time
time.sleep(0.1)

serial_thread.set_rts(False)
serial_thread.set_dtr(True)
print("  RTS=LOW, DTR=HIGH")
time.sleep(0.1)

serial_thread.set_rts(True)
serial_thread.set_dtr(True)
print("  RTS=HIGH, DTR=HIGH")

print("\n等待设备响应...")
for i in range(30):
    received = serial_thread.read()
    if received:
        print(f"✅ 收到数据: {len(received)} 字节")
        print(f"  内容: {received[:50]}")
        break

    if i % 5 == 0:
        print(f"  等待 {i+1}/30 秒...")
    time.sleep(1)

serial_thread.deinit_serial()
print("\n诊断完成")