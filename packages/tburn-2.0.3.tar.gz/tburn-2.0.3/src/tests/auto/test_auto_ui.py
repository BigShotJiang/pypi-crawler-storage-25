"""
TBurn TUI 自动化测试脚本

使用 Textual Pilot 框架模拟用户随机操作，测试应用稳定性。

运行方式：
    python test_auto_ui.py

或使用 pytest：
    pytest test_auto_ui.py -v
"""
import asyncio
import random
import sys
import os
from pathlib import Path

# 确保项目路径在 sys.path
_root = Path(__file__).parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

# 导入应用
from ui.app import TBurn
from state import _state, Status
from protocol.chips import ChipType, BurnTarget, chip_to_str


class AutoUITester:
    """自动化 UI 测试器"""

    # 可测试的按键列表
    TEST_KEYS = [
        't',      # 选择芯片
        'g',      # 选择目标
        'a',      # 自动烧录模式
        'p',      # 选择串口
        'n',      # 新增固件
        'd',      # 删除固件
        'D',      # 调试模式
        'r',      # 读ID（需先连接）
        'v',      # 校验（需先连接）
        'c',      # 连接（需先选串口）
        'e',      # 烧录模式（需先连接）
        'b',      # 烧录（需先进入模式）
        'escape', # 取消/退出对话框
        'tab',    # 切换焦点
        'enter',  # 确认
        '1', '2', '3', '4',  # 芯片选择快捷键
        'q',      # 退出（慎用）
    ]

    # 芯片选择按键
    CHIP_KEYS = ['1', '2', '3', '4']

    def __init__(self, app: TBurn, verbose: bool = True):
        self.app = app
        self.verbose = verbose
        self.test_count = 0
        self.error_count = 0
        self.log = []

    def _print(self, msg: str):
        """打印日志"""
        if self.verbose:
            print(msg)
        self.log.append(msg)

    async def press_and_wait(self, pilot, key: str, wait: float = 0.1):
        """按键并等待"""
        self._print(f"  → 按键: {key}")
        await pilot.press(key)
        await pilot.pause()
        await asyncio.sleep(wait)
        self.test_count += 1

    async def random_chip_select(self, pilot):
        """随机选择芯片"""
        self._print("\n[测试] 随机芯片选择")

        # 打开芯片选择对话框
        await self.press_and_wait(pilot, 't', 0.3)

        # 随机选择芯片
        chip_key = random.choice(self.CHIP_KEYS)
        await self.press_and_wait(pilot, chip_key, 0.2)

        # 验证芯片切换
        chip_names = {
            '1': ChipType.CSK6,
            '2': ChipType.ARCS,
            '3': ChipType.ARCS_DUAL,
            '4': ChipType.VENUSA,
        }
        expected = chip_names.get(chip_key)
        if expected and _state.chip_type == expected:
            self._print(f"  ✓ 芯片切换成功: {chip_to_str(_state.chip_type)}")
        else:
            self._print(f"  ! 芯片状态: {chip_to_str(_state.chip_type)}")

    async def random_target_select(self, pilot):
        """随机选择烧录目标"""
        self._print("\n[测试] 随机目标选择")

        await self.press_and_wait(pilot, 'g', 0.3)

        # ARCS 可选择 eMMC
        if _state.chip_type in [ChipType.ARCS, ChipType.ARCS_DUAL]:
            # 随机选择 Flash 或 eMMC
            target_key = random.choice(['f', 'e'])
            await self.press_and_wait(pilot, target_key, 0.2)
            self._print(f"  ✓ 目标: {_state.burn_target.value}")

        # ARCS_DUAL 可选择 Flash 索引
        if _state.chip_type == ChipType.ARCS_DUAL:
            await self.press_and_wait(pilot, 'g', 0.3)
            flash_key = random.choice(['0', '1'])
            await self.press_and_wait(pilot, flash_key, 0.2)
            self._print(f"  ✓ Flash 索引: {_state.flash_index}")

    async def toggle_auto_burn(self, pilot):
        """切换自动烧录模式"""
        self._print("\n[测试] 自动烧录模式切换")

        for _ in range(3):
            await self.press_and_wait(pilot, 'a', 0.2)
            mode_names = {"manual": "手动", "wait": "等待", "repeat": "循环"}
            self._print(f"  ✓ 模式: {mode_names.get(_state.auto_burn_mode, _state.auto_burn_mode)}")

    async def toggle_debug(self, pilot):
        """切换调试模式"""
        self._print("\n[测试] 调试模式切换")

        await self.press_and_wait(pilot, 'D', 0.2)
        status = "开启" if _state.dump_dbg else "关闭"
        self._print(f"  ✓ 调试模式: {status}")

    async def test_dialog_cancel(self, pilot):
        """测试对话框取消"""
        self._print("\n[测试] 对话框取消操作")

        # 打开芯片选择然后取消
        await self.press_and_wait(pilot, 't', 0.3)
        await self.press_and_wait(pilot, 'escape', 0.2)
        self._print(f"  ✓ 取消芯片选择，当前: {chip_to_str(_state.chip_type)}")

    async def test_firmware_edit_nav(self, pilot):
        """测试固件编辑界面上下导航"""
        self._print("\n[测试] 固件编辑界面导航")

        # 打开固件编辑对话框
        await self.press_and_wait(pilot, 'n', 0.3)

        # 测试上下导航
        for _ in range(3):
            await self.press_and_wait(pilot, 'down', 0.1)
        for _ in range(3):
            await self.press_and_wait(pilot, 'up', 0.1)

        # 测试 F 快捷键提示（不实际打开文件选择器）
        await self.press_and_wait(pilot, 'tab', 0.1)

        # 取消退出
        await self.press_and_wait(pilot, 'escape', 0.2)
        self._print(f"  ✓ 固件编辑界面导航测试完成")

    async def test_baudrate_select(self, pilot):
        """测试波特率选择（通过按键）"""
        self._print("\n[测试] 波特率选择")

        # 波特率选择需要通过状态面板点击，这里用按键模拟
        # 暂时跳过，因为没有直接按键入口
        self._print(f"  ✓ 波特率选择测试跳过（需要鼠标点击）")

    async def test_firmware_panel(self, pilot):
        """测试固件面板操作"""
        self._print("\n[测试] 固件面板操作")

        # Tab 切换焦点到固件面板
        for _ in range(3):
            await self.press_and_wait(pilot, 'tab', 0.1)

        self._print(f"  ✓ 焦点切换完成")

        # 测试新增固件按钮（通过快捷键 n）
        await self.press_and_wait(pilot, 'n', 0.3)
        await self.press_and_wait(pilot, 'escape', 0.2)
        self._print(f"  ✓ 新增固件对话框测试完成")

    async def random_key_test(self, pilot, count: int = 10):
        """随机按键测试"""
        self._print(f"\n[测试] 随机按键测试 ({count} 次)")

        # 安全按键（不会退出应用）
        safe_keys = ['t', 'g', 'a', 'D', 'tab', 'escape', 'p']

        for i in range(count):
            key = random.choice(safe_keys)
            self._print(f"  [{i+1}/{count}] 按键: {key}")
            await pilot.press(key)
            await pilot.pause()
            await asyncio.sleep(0.05)
            self.test_count += 1

    async def check_status_panel(self, pilot):
        """检查状态面板显示"""
        self._print("\n[检查] 状态面板")

        self._print(f"  状态: {_state.status.value}")
        self._print(f"  芯片: {chip_to_str(_state.chip_type)}")
        self._print(f"  目标: {_state.burn_target.value}")
        self._print(f"  Flash索引: {_state.flash_index}")
        self._print(f"  自动模式: {_state.auto_burn_mode}")

    def report(self):
        """生成测试报告"""
        print("\n" + "=" * 50)
        print("测试报告")
        print("=" * 50)
        print(f"总测试次数: {self.test_count}")
        print(f"错误次数: {self.error_count}")
        print(f"成功率: {(self.test_count - self.error_count) / self.test_count * 100:.1f}%")
        print("=" * 50)


async def run_auto_test(verbose: bool = True, random_count: int = 20):
    """运行自动化测试"""

    print("=" * 50)
    print("TBurn TUI 自动化测试")
    print("=" * 50)

    # 创建应用
    app = TBurn()

    # 创建测试器
    tester = AutoUITester(app, verbose=verbose)

    # 运行测试
    async with app.run_test() as pilot:

        print("\n[阶段1] 启动验证")
        await tester.check_status_panel(pilot)

        print("\n[阶段2] 芯片切换测试")
        # 测试所有芯片类型
        for chip_key in ['1', '2', '3', '4']:
            await tester.press_and_wait(pilot, 't', 0.3)
            await tester.press_and_wait(pilot, chip_key, 0.2)
            await tester.check_status_panel(pilot)

        print("\n[阶段3] 目标选择测试")
        # 切换到 ARCS_DUAL 测试双 Flash
        await tester.press_and_wait(pilot, 't', 0.3)
        await tester.press_and_wait(pilot, '3', 0.2)
        await tester.press_and_wait(pilot, 'g', 0.3)
        await tester.press_and_wait(pilot, '0', 0.2)
        await tester.press_and_wait(pilot, 'g', 0.3)
        await tester.press_and_wait(pilot, '1', 0.2)

        print("\n[阶段4] 自动烧录模式测试")
        await tester.toggle_auto_burn(pilot)

        print("\n[阶段5] 调试模式测试")
        await tester.toggle_debug(pilot)

        print("\n[阶段6] 对话框取消测试")
        await tester.test_dialog_cancel(pilot)

        print("\n[阶段7] 焦点切换测试")
        await tester.test_firmware_panel(pilot)

        print("\n[阶段8] 固件编辑界面导航测试")
        await tester.test_firmware_edit_nav(pilot)

        print("\n[阶段9] 波特率选择测试")
        await tester.test_baudrate_select(pilot)

        print("\n[阶段10] 随机按键测试")
        await tester.random_key_test(pilot, count=random_count)

        print("\n[阶段11] 最终状态检查")
        await tester.check_status_panel(pilot)

    # 生成报告
    tester.report()

    return tester.error_count == 0


async def run_stress_test(iterations: int = 5):
    """压力测试：多次随机操作"""

    print("=" * 50)
    print("压力测试模式")
    print("=" * 50)

    app = TBurn()
    tester = AutoUITester(app, verbose=False)

    async with app.run_test() as pilot:
        for i in range(iterations):
            print(f"\n[迭代 {i+1}/{iterations}]")

            # 随机芯片切换
            chip_key = random.choice(['1', '2', '3', '4'])
            await pilot.press('t')
            await pilot.pause()
            await asyncio.sleep(0.3)
            await pilot.press(chip_key)
            await pilot.pause()
            await asyncio.sleep(0.2)

            # 随机按键序列
            sequence_length = random.randint(5, 15)
            safe_keys = ['t', 'g', 'a', 'D', 'tab', 'escape']
            for _ in range(sequence_length):
                key = random.choice(safe_keys)
                await pilot.press(key)
                await pilot.pause()
                await asyncio.sleep(0.05)
                tester.test_count += 1

            # 检查状态
            if tester.verbose:
                print(f"  状态: {_state.status.value}, 芯片: {chip_to_str(_state.chip_type)}")

    tester.report()
    return tester.error_count == 0


def main():
    """主入口"""
    import argparse

    parser = argparse.ArgumentParser(description='TBurn TUI 自动化测试')
    parser.add_argument('--stress', action='store_true', help='运行压力测试')
    parser.add_argument('--iterations', type=int, default=5, help='压力测试迭代次数')
    parser.add_argument('--random', type=int, default=20, help='随机按键次数')
    parser.add_argument('--quiet', action='store_true', help='静默模式')

    args = parser.parse_args()

    if args.stress:
        success = asyncio.run(run_stress_test(args.iterations))
    else:
        success = asyncio.run(run_auto_test(
            verbose=not args.quiet,
            random_count=args.random
        ))

    if success:
        print("\n✅ 测试全部通过")
        sys.exit(0)
    else:
        print("\n❌ 测试存在错误")
        sys.exit(1)


# pytest 测试用例（仅当 pytest 已安装）
try:
    import pytest
    HAS_PYTEST = True
except ImportError:
    HAS_PYTEST = False

if HAS_PYTEST:
    @pytest.mark.asyncio
    async def test_app_startup():
        """测试应用启动"""
        app = TBurn()
        async with app.run_test():
            assert _state.status == Status.UNINIT

    @pytest.mark.asyncio
    async def test_chip_switch():
        """测试芯片切换"""
        app = TBurn()
        async with app.run_test() as pilot:
            # 切换到 ARCS
            await pilot.press('t')
            await pilot.pause()
            await asyncio.sleep(0.3)
            await pilot.press('2')  # ARCS
            await pilot.pause()

            assert _state.chip_type == ChipType.ARCS

    @pytest.mark.asyncio
    async def test_auto_burn_toggle():
        """测试自动烧录模式切换"""
        app = TBurn()
        async with app.run_test() as pilot:
            # 切换 3 次，应该循环：manual -> wait -> repeat -> manual
            await pilot.press('a')
            await pilot.pause()
            assert _state.auto_burn_mode == 'wait'

            await pilot.press('a')
            await pilot.pause()
            assert _state.auto_burn_mode == 'repeat'

            await pilot.press('a')
            await pilot.pause()
            assert _state.auto_burn_mode == 'manual'

    @pytest.mark.asyncio
    async def test_dual_flash_select():
        """测试双 Flash 选择"""
        app = TBurn()
        async with app.run_test() as pilot:
            # 切换到 ARCS_DUAL
            await pilot.press('t')
            await pilot.pause()
            await asyncio.sleep(0.3)
            await pilot.press('3')  # ARCS_DUAL
            await pilot.pause()

            assert _state.chip_type == ChipType.ARCS_DUAL

            # 选择 Flash 索引
            await pilot.press('g')
            await pilot.pause()
            await asyncio.sleep(0.3)
            await pilot.press('1')
            await pilot.pause()

            assert _state.flash_index == 1


if __name__ == '__main__':
    main()
