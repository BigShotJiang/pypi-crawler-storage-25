"""自动化烧录脚本 - 使用直接串口访问"""
import sys
import os
import asyncio
import time

try:
    import serial
    from serial import Serial
except ImportError:
    print("❌ pyserial 未安装")
    sys.exit(1)

# 添加项目路径
_root = os.path.dirname(os.path.abspath(__file__))
if _root not in sys.path:
    sys.path.insert(0, _root)

from pathlib import Path
from firmware import FirmwareInfo
from protocol.chips import ChipType, BurnTarget, get_load_addr
from protocol import read_hex_from_bin, getmd5_fromlist
from protocol.slip import slip_encode, slip_decode


def slip_encode_list(data):
    """SLIP 编码，返回字节"""
    return slip_encode(data)


def parse_response(data):
    """解析响应"""
    if len(data) < 8:
        return None

    direction = data[0]
    command = data[1]
    size = data[2] | (data[3] << 8)
    value = data[4] | (data[5] << 8) | (data[6] << 16) | (data[7] << 24)

    return {
        'direction': direction,
        'command': command,
        'size': size,
        'value': value,
        'valid': direction == 0x01  # 响应方向
    }


def send_command(s, cmd_code, data, timeout=0.2):
    """发送命令并等待响应"""
    # 构建请求 - size 是 16 位
    data_len = len(data)
    header = bytes([
        0x00, cmd_code,
        data_len & 0xFF, (data_len >> 8) & 0xFF,  # size (16-bit little endian)
        0, 0, 0, 0  # checksum placeholder
    ])
    packet = header + bytes(data)
    slip_packet = bytes(slip_encode(list(packet)))

    # 清空缓冲区
    s.reset_input_buffer()

    # 发送
    s.write(slip_packet)
    s.flush()

    # 等待响应
    received = []
    start_time = time.time()

    while time.time() - start_time < timeout:
        data = s.read(200)
        if data:
            received.extend(list(data))

            # 检查是否有完整的 SLIP 帧
            if 0xC0 in received:
                # 找到 SLIP 开始和结束
                try:
                    start_idx = received.index(0xC0)
                    end_idx = received.index(0xC0, start_idx + 1)
                    if end_idx > start_idx + 8:  # 最小响应长度
                        frame = received[start_idx:end_idx + 1]
                        decoded = slip_decode(frame)

                        if len(decoded) >= 8:
                            return parse_response(decoded)
                except:
                    pass

        time.sleep(0.01)

    return None


def auto_burn():
    """自动化烧录"""
    print("=" * 60)
    print("自动化烧录测试")
    print("=" * 60)

    # 1. 配置参数
    port = "/dev/cu.wchusbserial5ABA1276681"
    chip_type = ChipType.ARCS
    baudrate = 2000000
    firmware_addr = 0x0
    firmware_path = "/Users/abc/Downloads/helloworld.bin"

    # 加载 burner
    burner_path = Path(__file__).parent / "res" / "burner_arcs.img"
    if not burner_path.exists():
        print(f"❌ Burner 文件不存在: {burner_path}")
        return False

    print(f"\n配置:")
    print(f"  端口: {port}")
    print(f"  芯片: {chip_type.value}")
    print(f"  波特率: {baudrate}")
    print(f"  固件地址: 0x{firmware_addr:X}")
    print(f"  固件路径: {firmware_path}")

    # 检查固件文件
    if not os.path.isfile(firmware_path):
        print(f"\n❌ 固件文件不存在: {firmware_path}")
        return False

    firmware_data = read_hex_from_bin(firmware_path)
    firmware_size = len(firmware_data)
    print(f"  固件大小: {firmware_size/1024:.1f}KB")

    burner_data = read_hex_from_bin(str(burner_path))
    burner_size = len(burner_data)
    print(f"  Burner: {burner_size/1024:.1f}KB")

    print("\n" + "=" * 60)
    print("步骤1: 打开串口")
    print("=" * 60)

    # 2. 打开串口
    try:
        s = Serial(port, 115200, timeout=0.1)
        print(f"✅ 串口已打开: {port}@115200")
    except Exception as e:
        print(f"❌ 无法打开串口: {e}")
        return False

    # 清空缓冲区
    s.reset_input_buffer()

    print("\n" + "=" * 60)
    print("步骤2: 复位设备")
    print("=" * 60)

    # 3. 执行 iBurn2 复位序列
    print("执行 ARCS 复位序列 (iBurn2)...")

    s.rts = True
    s.dtr = False
    print("  RTS=True, DTR=False")
    time.sleep(0.1)

    s.rts = False
    s.dtr = True
    print("  RTS=False, DTR=True")
    time.sleep(0.1)

    s.rts = True
    s.dtr = True
    print("  RTS=True, DTR=True")

    # 等待设备稳定
    time.sleep(0.2)

    print("\n" + "=" * 60)
    print("步骤3: 同步设备")
    print("=" * 60)

    # 4. 同步
    print("发送 SYNC 命令...")

    sync_data = [0x07, 0x07, 0x12, 0x20] + [0x55] * 32
    sync_result = send_command(s, 0x08, sync_data, 0.3)

    if sync_result and sync_result['valid']:
        print("✅ 设备同步成功!")
    else:
        print("❌ 设备同步失败")
        s.close()
        return False

    print("\n" + "=" * 60)
    print("步骤4: 加载 Burner")
    print("=" * 60)

    # 5. 加载 burner 到 RAM
    load_addr = get_load_addr(chip_type)  # 0x20040000 for ARCS
    print(f"加载 burner 到 0x{load_addr:X}, 大小 {burner_size/1024:.1f}KB")

    # MEM_BEGIN
    ram_block_size = 0x800  # 2KB
    blocks = (burner_size + ram_block_size - 1) // ram_block_size

    mem_begin_data = [
        burner_size & 0xFF, (burner_size >> 8) & 0xFF, (burner_size >> 16) & 0xFF, (burner_size >> 24) & 0xFF,
        blocks & 0xFF, (blocks >> 8) & 0xFF, (blocks >> 16) & 0xFF, (blocks >> 24) & 0xFF,
        ram_block_size & 0xFF, (ram_block_size >> 8) & 0xFF, (ram_block_size >> 16) & 0xFF, (ram_block_size >> 24) & 0xFF,
        load_addr & 0xFF, (load_addr >> 8) & 0xFF, (load_addr >> 16) & 0xFF, (load_addr >> 24) & 0xFF,
    ]

    mem_result = send_command(s, 0x05, mem_begin_data, 1.0)
    if not mem_result or not mem_result['valid']:
        print("❌ MEM_BEGIN 失败")
        s.close()
        return False

    print("✅ MEM_BEGIN 成功")

    # 发送 burner 数据块
    print(f"发送 {blocks} 个数据块...")
    for i in range(blocks):
        offset = ram_block_size * i
        length = min(ram_block_size, burner_size - offset)

        # 构建数据块
        block_data = list(burner_data[offset:offset + length])

        # 计算 checksum
        checksum = 0xEF
        for b in block_data:
            checksum ^= b

        # MEM_DATA 命令数据: length, seq, 0, 0 + data
        mem_data_cmd = [
            length & 0xFF, (length >> 8) & 0xFF, (length >> 16) & 0xFF, (length >> 24) & 0xFF,
            i & 0xFF, (i >> 8) & 0xFF, (i >> 16) & 0xFF, (i >> 24) & 0xFF,
            0, 0, 0, 0,
        ] + block_data

        mem_result = send_command(s, 0x07, mem_data_cmd, 0.5)
        if not mem_result or not mem_result['valid']:
            print(f"❌ MEM_DATA block {i} 失败")
            s.close()
            return False

        if i % 10 == 0:
            print(f"  进度: {i+1}/{blocks}")

    print("✅ Burner 数据发送完成")

    # MEM_END
    mem_end_data = [0] * 4
    mem_result = send_command(s, 0x06, mem_end_data, 1.0)
    if not mem_result or not mem_result['valid']:
        print("❌ MEM_END 失败")
        s.close()
        return False

    print("✅ Burner 加载完成，设备已跳转到 burner")

    # 等待 burner 启动
    time.sleep(0.5)

    # 再次同步
    print("\n同步 burner...")
    sync_result = send_command(s, 0x08, sync_data, 1.0)
    if not sync_result or not sync_result['valid']:
        print("❌ Burner 同步失败")
        s.close()
        return False

    print("✅ Burner 同步成功")

    print("\n" + "=" * 60)
    print("步骤5: 切换波特率")
    print("=" * 60)

    # 6. 切换波特率
    print(f"切换波特率: 115200 → {baudrate}")

    baud_data = [
        baudrate & 0xFF, (baudrate >> 8) & 0xFF, (baudrate >> 16) & 0xFF, (baudrate >> 24) & 0xFF,
        115200 & 0xFF, (115200 >> 8) & 0xFF, (115200 >> 16) & 0xFF, (115200 >> 24) & 0xFF,
    ]

    baud_result = send_command(s, 0x0F, baud_data, 1.0)
    if baud_result and baud_result['valid']:
        print(f"✅ 波特率切换命令成功")

        # 关闭串口，用新波特率重新打开
        time.sleep(0.1)
        s.close()

        try:
            s = Serial(port, baudrate, timeout=0.1)
            print(f"✅ 串口已切换到 {baudrate}")
        except Exception as e:
            print(f"⚠️ 无法以 {baudrate} 打开串口，继续使用 115200")
            s = Serial(port, 115200, timeout=0.1)

        # 再次同步
        sync_result = send_command(s, 0x08, sync_data, 1.0)
        if sync_result and sync_result['valid']:
            print("✅ 高速波特率同步成功")
        else:
            print("⚠️ 高速波特率同步失败")

    print("\n" + "=" * 60)
    print("步骤6: 烧录固件")
    print("=" * 60)

    # 7. 烧录固件到 FLASH
    flash_block_size = 0x1000  # 4KB
    bunch_size = 191  # 每次烧录的块数

    total_blocks = (firmware_size + flash_block_size - 1) // flash_block_size
    total_bunches = (total_blocks + bunch_size - 1) // bunch_size

    print(f"烧录固件: {firmware_size/1024:.1f}KB")
    print(f"总块数: {total_blocks}, 分段: {total_bunches}")

    burn_success = True

    for bunch_idx in range(total_bunches):
        bunch_start = bunch_idx * bunch_size * flash_block_size
        bunch_len = min(bunch_size * flash_block_size, firmware_size - bunch_start)
        bunch_blocks = (bunch_len + flash_block_size - 1) // flash_block_size
        bunch_addr = firmware_addr + bunch_start
        bunch_md5 = getmd5_fromlist(firmware_data[bunch_start:bunch_start + bunch_len])

        print(f"\n分段 {bunch_idx+1}/{total_bunches}: 地址 0x{bunch_addr:X}")

        # FLASH_BEGIN - MD5 需要转换为 16 字节
        md5_bytes = []
        for i in range(16):
            md5_bytes.append((bunch_md5 >> (8 * (15 - i))) & 0xFF)

        flash_begin_data = [
            bunch_len & 0xFF, (bunch_len >> 8) & 0xFF, (bunch_len >> 16) & 0xFF, (bunch_len >> 24) & 0xFF,
            bunch_blocks & 0xFF, (bunch_blocks >> 8) & 0xFF, (bunch_blocks >> 16) & 0xFF, (bunch_blocks >> 24) & 0xFF,
            flash_block_size & 0xFF, (flash_block_size >> 8) & 0xFF, (flash_block_size >> 16) & 0xFF, (flash_block_size >> 24) & 0xFF,
            bunch_addr & 0xFF, (bunch_addr >> 8) & 0xFF, (bunch_addr >> 16) & 0xFF, (bunch_addr >> 24) & 0xFF,
        ] + md5_bytes

        flash_result = send_command(s, 0x02, flash_begin_data, 1.0)
        if not flash_result or not flash_result['valid']:
            print("❌ FLASH_BEGIN 失败")
            burn_success = False
            break

        # FLASH_DATA
        for block_idx in range(bunch_blocks):
            offset = flash_block_size * block_idx
            length = min(flash_block_size, bunch_len - offset)

            block_data = list(firmware_data[bunch_start + offset:bunch_start + offset + length])

            # 计算 checksum
            checksum = 0xEF
            for b in block_data:
                checksum ^= b

            flash_data_cmd = [
                length & 0xFF, (length >> 8) & 0xFF, (length >> 16) & 0xFF, (length >> 24) & 0xFF,
                block_idx & 0xFF, (block_idx >> 8) & 0xFF, (block_idx >> 16) & 0xFF, (block_idx >> 24) & 0xFF,
                0, 0, 0, 0,
            ] + block_data

            # 重试机制
            for retry in range(5):
                flash_result = send_command(s, 0x03, flash_data_cmd, 1.0)
                if flash_result and flash_result['valid']:
                    break
                time.sleep(0.1)

            if not flash_result or not flash_result['valid']:
                print(f"❌ FLASH_DATA block {block_idx} 失败")
                burn_success = False
                break

            if block_idx % 20 == 0:
                print(f"  进度: {block_idx+1}/{bunch_blocks}")

        if not burn_success:
            break

        time.sleep(0.1)

    if burn_success:
        print("\n✅ 固件烧录完成!")

        # 校验
        print("\n校验固件...")
        verify_md5 = getmd5_fromlist(firmware_data)

        # MD5 需要转换为 16 字节
        verify_md5_bytes = []
        for i in range(16):
            verify_md5_bytes.append((verify_md5 >> (8 * (15 - i))) & 0xFF)

        flash_verify_data = [
            firmware_size & 0xFF, (firmware_size >> 8) & 0xFF, (firmware_size >> 16) & 0xFF, (firmware_size >> 24) & 0xFF,
            firmware_addr & 0xFF, (firmware_addr >> 8) & 0xFF, (firmware_addr >> 16) & 0xFF, (firmware_addr >> 24) & 0xFF,
        ] + verify_md5_bytes

        verify_result = send_command(s, 0x13, flash_verify_data, 2.0)
        if verify_result and verify_result['valid']:
            print("✅ 校验成功!")
        else:
            print("⚠️ 校验失败（但烧录可能成功）")

    # 清理
    s.close()

    print("\n" + "=" * 60)
    print("烧录结果")
    print("=" * 60)

    if burn_success:
        print("\n✅ 烧录成功!")
        return True
    else:
        print("\n❌ 烧录失败!")
        return False


if __name__ == "__main__":
    success = auto_burn()
    sys.exit(0 if success else 1)