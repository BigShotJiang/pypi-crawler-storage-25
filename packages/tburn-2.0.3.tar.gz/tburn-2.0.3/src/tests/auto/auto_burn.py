"""自动化烧录脚本"""
import sys
import os
import asyncio

# 添加项目路径
_root = os.path.dirname(os.path.abspath(__file__))
if _root not in sys.path:
    sys.path.insert(0, _root)

from pathlib import Path
from state import _state, Status
from firmware import FirmwareInfo
from protocol.chips import ChipType, BurnTarget, get_load_addr
from protocol.serial_thread import ReadSerialThread
from protocol.client import CSKBurnProtocolClient
from protocol import read_hex_from_bin, getmd5_fromlist


async def auto_burn():
    """自动化烧录"""
    print("=" * 60)
    print("自动化烧录测试")
    print("=" * 60)

    # 1. 配置参数
    port = "/dev/cu.wchusbserial5ABA1276681"
    chip_type = ChipType.ARCS
    target = BurnTarget.FLASH
    baudrate = 2000000
    firmware_addr = 0x0
    firmware_path = "/Users/abc/Downloads/helloworld.bin"

    print(f"\n配置:")
    print(f"  端口: {port}")
    print(f"  芯片: {chip_type.value}")
    print(f"  目标: {target.value}")
    print(f"  波特率: {baudrate}")
    print(f"  固件地址: 0x{firmware_addr:X}")
    print(f"  固件路径: {firmware_path}")

    # 检查固件文件
    if not os.path.isfile(firmware_path):
        print(f"\n❌ 固件文件不存在: {firmware_path}")
        return False

    firmware = FirmwareInfo("helloworld", firmware_addr, firmware_path)
    print(f"  固件大小: {firmware.size/1024:.1f}KB")

    # 2. 设置状态
    _state.port = port
    _state.chip_type = chip_type
    _state.burn_target = target
    _state.baudrate = baudrate
    _state.firmwares = [firmware]

    # 加载 burner
    burner_name = "burner_arcs.img"
    burner_path = Path(__file__).parent / "res" / burner_name
    if burner_path.exists():
        _state.burner = FirmwareInfo("burner", get_load_addr(chip_type), str(burner_path))
        print(f"  Burner: {burner_name} ({_state.burner.size/1024:.1f}KB)")
    else:
        print(f"\n❌ Burner 文件不存在: {burner_path}")
        return False

    print("\n" + "=" * 60)
    print("步骤1: 初始化串口")
    print("=" * 60)

    # 3. 初始化串口
    serial_thread = ReadSerialThread(True, port)  # 开启调试
    if not serial_thread.init_serial(port, 115200):
        print(f"❌ 无法打开串口 {port}")
        return False

    serial_thread.start()
    serial_thread.mark_start()

    protocol_client = CSKBurnProtocolClient(serial_thread, dump_dbg=True, funcname_dbg=True)
    _state.serial_thread = serial_thread
    _state.protocol_client = protocol_client

    print(f"✅ 串口已打开: {port}@115200")

    print("\n" + "=" * 60)
    print("步骤2: 同步设备")
    print("=" * 60)

    # 先尝试不执行复位序列直接同步（多次尝试）
    print("尝试直接同步（不复位）...")
    sync_success = False

    # 显示发送的数据
    sync_cmd = [0x07, 0x07, 0x12, 0x20] + [0x55] * 32
    print(f"SYNC 命令数据: {sync_cmd[:8]}... (共 {len(sync_cmd)} 字节)")

    # 更多尝试次数，更长超时
    for i in range(50):
        # 清空缓冲区
        serial_thread.swap()

        ret = protocol_client.cmd_sync(0.2)  # iBurn2 使用 200ms 超时
        if ret:
            sync_success = True
            print(f"✅ 直接同步成功 (尝试 {i+1}/50)")
            break

        # 检查是否有任何数据返回
        received = serial_thread.read()
        if received:
            print(f"  收到数据: {len(received)} 字节 - {received[:20]}")

        if i % 10 == 0:
            print(f"  同步尝试 {i+1}/50...")
        await asyncio.sleep(0.2)  # 更长的等待

    # 如果直接同步失败，执行复位序列
    if not sync_success:
        print("\n直接同步失败，执行复位序列...")

        # 执行复位序列
        serial_thread.reset_sequence(chip_type, 100)
        await asyncio.sleep(0.2)  # iBurn2 等待 200ms

        # 清空缓冲区
        serial_thread.swap()

        # 同步尝试（iBurn2 默认 20 次，超时 200ms）
        for i in range(20):
            # 每次尝试前清空缓冲区
            serial_thread.swap()

            ret = protocol_client.cmd_sync(0.2)  # iBurn2 使用 200ms 超时
            if ret:
                sync_success = True
                print(f"✅ 复位后同步成功 (尝试 {i+1}/20)")
                break

            if i % 5 == 0:
                print(f"  同步尝试 {i+1}/20...")
            await asyncio.sleep(0.05)  # 等待后再次尝试

    if not sync_success:
        print("❌ 同步失败")
        serial_thread.deinit_serial()
        return False

    # 检查是否有任何数据从设备返回
    print("\n检查设备响应...")
    await asyncio.sleep(0.5)
    received_data = serial_thread.read()
    if received_data:
        print(f"收到数据: {len(received_data)} 字节")
        print(f"数据内容: {received_data[:50]}...")
    else:
        print("未收到任何数据，设备可能未进入烧录模式")

    print("\n" + "=" * 60)
    print("步骤3: 进入烧录模式 (加载 Burner)")
    print("=" * 60)

    # 5. 加载 burner 到 RAM
    load_addr = get_load_addr(chip_type)
    burner_data = read_hex_from_bin(_state.burner.file_path)
    burner_len = len(burner_data)
    blocks = protocol_client.BLOCKS(burner_len, protocol_client.RAM_BLOCK_SIZE)

    print(f"加载 burner 到 0x{load_addr:X}, 大小 {burner_len/1024:.1f}KB")

    if not protocol_client.cmd_mem_begin(burner_len, blocks, protocol_client.RAM_BLOCK_SIZE, load_addr):
        print("❌ MEM_BEGIN 失败")
        serial_thread.deinit_serial()
        return False

    # 发送 burner 数据
    for block_idx in range(blocks):
        offset = protocol_client.RAM_BLOCK_SIZE * block_idx
        length = min(protocol_client.RAM_BLOCK_SIZE, burner_len - offset)

        ret = protocol_client.cmd_mem_block(
            burner_data[offset:offset + length],
            length, block_idx
        )

        if not isinstance(ret, dict) or not ret.get('ret'):
            print(f"❌ MEM_BLOCK {block_idx} 失败")
            serial_thread.deinit_serial()
            return False

        if block_idx % 50 == 0:
            print(f"  发送进度: {block_idx}/{blocks}")

    # MEM_END
    if not protocol_client.cmd_mem_end():
        print("❌ MEM_END 失败")
        serial_thread.deinit_serial()
        return False

    print("✅ Burner 加载完成")

    # 6. 切换波特率
    print(f"\n切换波特率: 115200 -> {baudrate}")

    if not protocol_client.cmd_change_baudrate(baudrate):
        print("⚠️ 波特率切换失败，继续使用 115200")
    else:
        # 重新初始化串口
        await asyncio.sleep(0.1)
        serial_thread.deinit_serial()
        if not serial_thread.init_serial(port, baudrate):
            print(f"⚠️ 无法以 {baudrate} 打开串口，回退到 115200")
            serial_thread.init_serial(port, 115200)
        else:
            print(f"✅ 波特率切换成功: {baudrate}")

    print("\n" + "=" * 60)
    print("步骤4: 烧录固件")
    print("=" * 60)

    # 7. 烧录固件到 FLASH
    fw_data = read_hex_from_bin(firmware_path)
    fw_len = len(fw_data)

    bunch_size = 191
    total_blocks = protocol_client.BLOCKS(fw_len, protocol_client.FLASH_BLOCK_SIZE)
    total_bunches = int((total_blocks + bunch_size - 1) / bunch_size)

    print(f"烧录 {firmware.name} @ 0x{firmware_addr:X}")
    print(f"大小: {fw_len/1024:.1f}KB, 分段: {total_bunches}")

    burn_success = True

    for bunch_idx in range(total_bunches):
        bunch_start = bunch_idx * bunch_size * protocol_client.FLASH_BLOCK_SIZE
        bunch_len = min(bunch_size * protocol_client.FLASH_BLOCK_SIZE, fw_len - bunch_start)
        bunch_blocks = protocol_client.BLOCKS(bunch_len, protocol_client.FLASH_BLOCK_SIZE)
        bunch_addr = firmware_addr + bunch_start
        bunch_md5 = getmd5_fromlist(fw_data[bunch_start:bunch_start + bunch_len])

        print(f"  分段 {bunch_idx+1}/{total_bunches}: 地址 0x{bunch_addr:X}")

        # FLASH_BEGIN
        if not protocol_client.cmd_flash_begin(
            bunch_len, bunch_blocks,
            protocol_client.FLASH_BLOCK_SIZE,
            bunch_addr, bunch_md5
        ):
            print("❌ FLASH_BEGIN 失败")
            burn_success = False
            break

        # FLASH_DATA
        for block_idx in range(bunch_blocks):
            offset = protocol_client.FLASH_BLOCK_SIZE * block_idx
            length = min(protocol_client.FLASH_BLOCK_SIZE, bunch_len - offset)

            # 重试机制
            ret = None
            for retry in range(5):
                ret = protocol_client.cmd_flash_block(
                    fw_data[bunch_start + offset:bunch_start + offset + length],
                    length, block_idx
                )
                if isinstance(ret, dict) and ret.get('ret'):
                    break
                await asyncio.sleep(0.1)

            if not isinstance(ret, dict) or not ret.get('ret'):
                print(f"❌ FLASH_DATA block {block_idx} 失败")
                burn_success = False
                break

            if block_idx % 20 == 0:
                print(f"    写入进度: {block_idx}/{bunch_blocks}")

        if not burn_success:
            break

        await asyncio.sleep(0.1)

    if burn_success:
        print("✅ 固件烧录完成")
        firmware.burn_status = "√"
    else:
        firmware.burn_status = "×"

    print("\n" + "=" * 60)
    print("步骤5: 校验固件")
    print("=" * 60)

    # 8. 校验固件
    if burn_success:
        verify_md5 = getmd5_fromlist(fw_data)
        ret = protocol_client.cmd_flash_verify(fw_len, firmware_addr, verify_md5)

        if ret:
            print(f"✅ 校验成功 - MD5 匹配")
        else:
            print("⚠️ 校验失败（但烧录可能成功）")

    print("\n" + "=" * 60)
    print("烧录结果")
    print("=" * 60)

    print(f"固件: {firmware.name}")
    print(f"地址: 0x{firmware.addr:X}")
    print(f"大小: {firmware.size/1024:.1f}KB")
    print(f"状态: {firmware.burn_status}")

    # 清理
    serial_thread.deinit_serial()

    if burn_success:
        print("\n✅ 烧录成功!")
        return True
    else:
        print("\n❌ 烧录失败!")
        return False


if __name__ == "__main__":
    success = asyncio.run(auto_burn())
    sys.exit(0 if success else 1)