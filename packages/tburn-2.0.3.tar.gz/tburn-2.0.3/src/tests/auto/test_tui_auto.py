"""TUI 自动化测试脚本

测试流程：
1. 启动 TUI 应用
2. 配置端口、芯片、固件
3. 开启自动烧录
4. 验证烧录流程执行

使用 textual 的 pilot 测试框架进行自动化测试。
"""

import sys
import os
import asyncio
import pytest

# 添加项目路径
_root = os.path.dirname(os.path.abspath(__file__))
if _root not in sys.path:
    sys.path.insert(0, _root)

from textual.pilot import Pilot
from textual.app import App

# 导入应用和状态
from ui.app import TBurn
from state import _state, Status
from firmware import FirmwareInfo
from protocol.chips import ChipType, BurnTarget


class TestTBurnTUI:
    """TUI 自动化测试"""

    @pytest.fixture
    def app(self):
        """创建测试应用"""
        # 配置测试参数
        _state.port = "/dev/cu.wchusbserial5ABA1276681"
        _state.chip_type = ChipType.ARCS
        _state.burn_target = BurnTarget.FLASH
        _state.baudrate = 2000000
        _state.auto_burn_enabled = True

        # 添加测试固件
        firmware = FirmwareInfo("helloworld", 0x0, "/Users/abc/Downloads/helloworld.bin")
        _state.firmwares = [firmware]

        app = TBurn()
        yield app
        # 清理
        if _state.serial_thread:
            _state.serial_thread.deinit_serial()

    async def test_app_startup(self, app):
        """测试应用启动"""
        async with app.run_test() as pilot:
            # 验证应用已启动
            assert app.is_running

            # 验证面板已加载
            from ui.widgets import StatusPanel, ProgressPanel, FirmwarePanel, BurnPanel, LogPanel
            assert app.query_one(StatusPanel) is not None
            assert app.query_one(ProgressPanel) is not None
            assert app.query_one(FirmwarePanel) is not None
            assert app.query_one(BurnPanel) is not None
            assert app.query_one(LogPanel) is not None

    async def test_auto_burn_enabled(self, app):
        """测试自动烧录开关"""
        async with app.run_test() as pilot:
            burn_panel = app.query_one(BurnPanel)

            # 验证默认开启
            assert burn_panel.auto_burn_enabled == True

            # 点击切换
            burn_panel.toggle_auto_burn()
            assert burn_panel.auto_burn_enabled == False

            # 再次切换
            burn_panel.toggle_auto_burn()
            assert burn_panel.auto_burn_enabled == True

    async def test_chip_selection(self, app):
        """测��芯片选择"""
        async with app.run_test() as pilot:
            # 按 T 键选择芯片
            await pilot.press("t")

            # 验证芯片选择屏幕已打开
            # (实际测试需要模拟选择操作)

    async def test_port_selection(self, app):
        """测试端口选择"""
        async with app.run_test() as pilot:
            # 按 P 键选择端口
            await pilot.press("p")

            # 验证端口选择屏幕已打开

    async def test_burn_flow(self, app):
        """测试烧录流程"""
        async with app.run_test() as pilot:
            # 点击烧录按钮
            from ui.widgets import BurnPanel
            burn_panel = app.query_one(BurnPanel)
            burn_panel.post_message(BurnPanel.BurnClicked())

            # 等待烧录完成（需要设备连接）
            # 这里只验证流程启动，不验证实际烧录
            await asyncio.sleep(1)

            # 验证状态已变更
            # (实际测试需要设备连接)


def run_manual_test():
    """手动测试 - 用于实际设备测试"""
    print("=" * 60)
    print("TUI 自动化烧录手动测试")
    print("=" * 60)

    # 配置参数
    config = {
        "port": "/dev/cu.wchusbserial5ABA1276681",
        "chip": "ARCS",
        "target": "FLASH",
        "baudrate": 2000000,
        "firmware_addr": 0x0,
        "firmware_path": "/Users/abc/Downloads/helloworld.bin",
        "auto_burn": True
    }

    print("\n配置参数:")
    for key, value in config.items():
        print(f"  {key}: {value}")

    print("\n启动 TUI 应用...")
    print("自动烧录已开启，等待设备接入后自动开始烧录")
    print("按 Ctrl+C 退出")
    print("")

    # 设置状态
    _state.port = config["port"]
    _state.chip_type = ChipType.ARCS
    _state.burn_target = BurnTarget.FLASH
    _state.baudrate = config["baudrate"]
    _state.auto_burn_enabled = config["auto_burn"]

    # 添加固件
    if os.path.isfile(config["firmware_path"]):
        firmware = FirmwareInfo("helloworld", config["firmware_addr"], config["firmware_path"])
        _state.firmwares = [firmware]
        print(f"固件已加载: {firmware.name} ({firmware.size/1024:.1f}KB)")
    else:
        print(f"警告: 固件文件不存在 {config['firmware_path']}")

    # 启动应用
    app = TBurn(port=config["port"])
    app.run()


def run_headless_test():
    """无头测试 - 不启动 GUI，直接测试烧录流程"""
    print("=" * 60)
    print("TUI 无头自动化测试")
    print("=" * 60)

    # 配置参数
    _state.port = "/dev/cu.wchusbserial5ABA1276681"
    _state.chip_type = ChipType.ARCS
    _state.burn_target = BurnTarget.FLASH
    _state.baudrate = 2000000
    _state.auto_burn_enabled = True

    # 添加固件
    firmware_path = "/Users/abc/Downloads/helloworld.bin"
    if os.path.isfile(firmware_path):
        firmware = FirmwareInfo("helloworld", 0x0, firmware_path)
        _state.firmwares = [firmware]
        print(f"固件: {firmware.name} ({firmware.size/1024:.1f}KB)")
    else:
        print(f"❌ 固件文件不存在: {firmware_path}")
        return False

    print("\n端口:", _state.port)
    print("芯片:", _state.chip_type.value)
    print("自动烧录:", "开启" if _state.auto_burn_enabled else "关闭")

    print("\n加载 burner...")
    _state._load_burner()
    if _state.burner:
        print(f"✅ Burner: {_state.burner.name} ({_state.burner.size/1024:.1f}KB)")
    else:
        print("❌ 无法加载 burner")
        return False

    # 这里可以执行烧录测试
    # (实际测试需要设备连接)

    print("\n配置验证完成")
    return True


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="TUI 自动化测试")
    parser.add_argument("--manual", action="store_true", help="启动手动测试 (带 GUI)")
    parser.add_argument("--headless", action="store_true", help="无头测试 (不带 GUI)")
    parser.add_argument("--pytest", action="store_true", help="运行 pytest 测试")

    args = parser.parse_args()

    if args.manual:
        run_manual_test()
    elif args.headless:
        run_headless_test()
    elif args.pytest:
        pytest.main([__file__, "-v"])
    else:
        # 默认运行手动测试
        run_manual_test()
