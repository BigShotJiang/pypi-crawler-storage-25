"""TUI日志处理器

将Python logging输出、stdout、stderr全部重定向到TUI的LogPanel，避免污染终端显示。

架构原理：
1. Python logging模块使用Handler来处理日志输出
2. 默认的StreamHandler输出到stdout/stderr
3. 终端TUI应用需要独占终端屏幕，外部输出会破坏渲染
4. 自定义Handler将日志写入_state.log_history，由LogPanel显示
5. 同时重定向sys.stdout/sys.stderr来捕获print()和异常输出
"""
import logging
import sys
import os
from datetime import datetime
from typing import Optional, Callable
from queue import Queue
import threading


class TUILogHandler(logging.Handler):
    """TUI日志处理器

    将所有logging输出重定向到TUI LogPanel。
    支持延迟绑定：在TUI启动前收集日志，启动后刷新到界面。
    """

    # 日志级别颜色映射
    LEVEL_COLORS = {
        logging.DEBUG: "dim",
        logging.INFO: "cyan",
        logging.WARNING: "yellow",
        logging.ERROR: "red",
        logging.CRITICAL: "red bold",
    }

    # 日志级别前缀
    LEVEL_PREFIX = {
        logging.DEBUG: "🔍",
        logging.INFO: "ℹ️",
        logging.WARNING: "⚠️",
        logging.ERROR: "❌",
        logging.CRITICAL: "🔥",
    }

    def __init__(self):
        super().__init__()
        # 日志回调函数（绑定到app.write_log）
        self._log_callback: Optional[Callable] = None
        # 延迟队列：TUI未启动时暂存日志
        self._pending_logs: Queue = Queue()
        # 是否已绑定TUI
        self._bound = False

    def bind_tui(self, log_callback: Callable):
        """绑定TUI日志回调

        Args:
            log_callback: app.write_log函数，签名为 (color: str, msg: str)
        """
        self._log_callback = log_callback
        self._bound = True

        # 刷新待处理的日志
        self._flush_pending()

    def unbind_tui(self):
        """解绑TUI（退出时使用）"""
        self._bound = False
        self._log_callback = None

    def emit(self, record: logging.LogRecord):
        """处理日志记录

        这是Handler的核心方法，每次logging调用都会触发。
        """
        try:
            # 格式化消息
            msg = self.format(record)

            # 获取颜色和前缀
            color = self.LEVEL_COLORS.get(record.levelno, "white")
            prefix = self.LEVEL_PREFIX.get(record.levelno, "")

            # 添加模块名作为来源标识
            source = record.name.split('.')[-1] if record.name else ""

            # ⚠️ 特殊处理多行消息（如 hex dump）
            # 保持原始格式，整块输出
            if '\n' in msg:
                # 多行消息：添加标题行，然后保持原格式
                if source and source not in ['root', '__main__']:
                    header = f"[{source}] {prefix} ▼"
                else:
                    header = f"{prefix} ▼"
                full_msg = f"{header}\n{msg}"
            else:
                # 单行消息：正常格式
                if source and source not in ['root', '__main__']:
                    full_msg = f"[{source}] {prefix} {msg}"
                else:
                    full_msg = f"{prefix} {msg}"

            if self._bound and self._log_callback:
                # 直接写入TUI
                self._log_callback(color, full_msg)
            else:
                # 暂存到队列
                timestamp = datetime.now().strftime("%H:%M:%S")
                self._pending_logs.put((timestamp, color, full_msg))

        except Exception:
            # 避免日志处理本身出错
            self.handleError(record)

    def _flush_pending(self):
        """刷新待处理的日志到TUI"""
        if not self._bound or not self._log_callback:
            return

        # 从队列取出所有日志
        while not self._pending_logs.empty():
            try:
                timestamp, color, msg = self._pending_logs.get_nowait()
                # 带时间戳的日志
                self._log_callback(color, f"[pending] {msg}")
            except:
                break

    def write_direct(self, msg: str, color: str = "dim"):
        """直接写入日志（用于stdout/stderr重定向）"""
        if self._bound and self._log_callback:
            self._log_callback(color, msg)
        else:
            timestamp = datetime.now().strftime("%H:%M:%S")
            self._pending_logs.put((timestamp, color, msg))


class TUIStreamRedirector:
    """stdout/stderr重定向器

    捕获所有print()输出和sys.stderr异常输出，重定向到TUI。
    """

    def __init__(self, handler: TUILogHandler, stream_type: str = "stdout"):
        self._handler = handler
        self._stream_type = stream_type
        self._original_stream = None
        # stdout用dim颜色，stderr用red颜色
        self._color = "dim" if stream_type == "stdout" else "red"

    def write(self, text: str):
        """写入文本（替代原始stream的write方法）"""
        if not text or text.strip() == "":
            return

        # 过滤ANSI控制序列（TUI自己输出的）
        if '\x1b[' in text or '[?1' in text or '[?' in text:
            # 这些是TUI的控制序列，忽略
            return

        # 清理文本
        text = text.strip()

        # 写入TUI
        prefix = f"[{self._stream_type}]"
        self._handler.write_direct(f"{prefix} {text}", self._color)

    def flush(self):
        """刷新缓冲区"""
        pass

    def fileno(self):
        """返回文件描述符（某些库需要）"""
        return self._original_stream.fileno() if self._original_stream else -1

    def isatty(self):
        """是否是终端"""
        return False


class LogRedirector:
    """日志重定向器

    统一管理所有模块的日志重定向配置。
    重定向所有logging、stdout、stderr输出到TUI LogPanel。
    """

    def __init__(self):
        self._handler = TUILogHandler()
        self._handler.setFormatter(logging.Formatter('%(message)s'))
        self._stdout_redirector = None
        self._stderr_redirector = None
        self._original_stdout = None
        self._original_stderr = None

    def configure(self, log_callback: Optional[Callable] = None,
                  level: int = logging.INFO):
        """配置日志重定向

        Args:
            log_callback: TUI日志回调函数
            level: 日志级别
        """
        # ========== 1. 配置logging ==========

        # 配置根logger，捕获所有模块的日志
        root_logger = logging.getLogger()
        root_logger.setLevel(level)

        # 移除所有默认Handler（避免输出到终端）
        for handler in root_logger.handlers[:]:
            root_logger.removeHandler(handler)

        # 添加TUI Handler到根logger
        root_logger.addHandler(self._handler)

        # ========== 2. 重定向stdout/stderr ==========

        # 保存原始stream
        self._original_stdout = sys.stdout
        self._original_stderr = sys.stderr

        # 创建重定向器
        self._stdout_redirector = TUIStreamRedirector(self._handler, "stdout")
        self._stderr_redirector = TUIStreamRedirector(self._handler, "stderr")

        # 替换sys.stdout和sys.stderr
        sys.stdout = self._stdout_redirector
        sys.stderr = self._stderr_redirector

        # ========== 3. 绑定TUI回调 ==========

        if log_callback:
            self._handler.bind_tui(log_callback)

    def bind_tui(self, log_callback: Callable):
        """绑定TUI日志回调"""
        self._handler.bind_tui(log_callback)

    def unbind_tui(self):
        """解绑TUI"""
        self._handler.unbind_tui()

    def restore_original_streams(self):
        """恢复原始stdout/stderr（退出时使用）"""
        if self._original_stdout:
            sys.stdout = self._original_stdout
        if self._original_stderr:
            sys.stderr = self._original_stderr


# 全局日志重定向器实例
_log_redirector = LogRedirector()


def configure_logging(log_callback: Optional[Callable] = None,
                      debug_mode: bool = False):
    """配置日志重定向（入口函数）

    ⚠️ 关键：这个函数必须在TUI启动后立即调用！

    Args:
        log_callback: TUI日志回调函数
        debug_mode: 是否开启调试模式
    """
    level = logging.DEBUG if debug_mode else logging.INFO
    _log_redirector.configure(log_callback=log_callback, level=level)


def bind_tui_logging(log_callback: Callable):
    """绑定TUI日志回调"""
    _log_redirector.bind_tui(log_callback)


def unbind_tui_logging():
    """解绑TUI日志"""
    _log_redirector.unbind_tui()


def restore_streams():
    """恢复原始stdout/stderr（退出时使用）"""
    _log_redirector.restore_original_streams()


def install_exception_hook(log_callback: Optional[Callable] = None):
    """安装异常钩子，捕获未处理的异常

    Args:
        log_callback: TUI日志回调函数（可选）
    """
    original_hook = sys.excepthook

    def tui_exception_hook(exc_type, exc_value, exc_tb):
        """异常钩子"""
        # 格式化异常信息
        import traceback
        tb_lines = traceback.format_exception(exc_type, exc_value, exc_tb)
        error_msg = "".join(tb_lines).strip()

        # 写入TUI（如果已绑定）
        if log_callback:
            log_callback("red bold", f"🔥 未捕获异常: {error_msg}")
        else:
            # 如果TUI未启动，写入原始stderr
            original_hook(exc_type, exc_value, exc_tb)

    sys.excepthook = tui_exception_hook