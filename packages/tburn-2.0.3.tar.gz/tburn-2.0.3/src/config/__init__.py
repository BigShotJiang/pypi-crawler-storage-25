"""配置管理"""
import json
import logging
from pathlib import Path

# 模块logger
_logger = logging.getLogger(__name__)

# 配置文件路径（保存在用户目录）
CONFIG_FILE = Path.home() / ".tburn_config.json"


def load_config() -> dict:
    """加载配置

    Returns:
        配置字典
    """
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text(encoding='utf-8'))
        except Exception:
            return {}
    return {}


def save_config(config: dict):
    """保存配置

    Args:
        config: 配置字典
    """
    try:
        CONFIG_FILE.write_text(
            json.dumps(config, ensure_ascii=False, indent=2),
            encoding='utf-8'
        )
    except Exception as e:
        _logger.warning(f"配置保存失败: {e}")