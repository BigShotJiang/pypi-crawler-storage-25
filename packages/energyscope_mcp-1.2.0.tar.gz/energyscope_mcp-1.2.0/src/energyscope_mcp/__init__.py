"""EnergyScope MCP Server — AI agent tools for energy market data and analytics."""
__version__ = "1.2.0"
