"""The `Citeformer` orchestrator — the public entry point for generation.

Composes a `Backend` with a citation policy and a CSL style. Calls the backend to
produce raw text with inline `[N]` markers, parses those markers into `Citation`
objects, renders the reference list, and packages the whole thing as a
`GenerationResult`.

Reference rendering uses the home-grown formatters in
``citeformer.render.formatters`` — see ADR-004 for the rationale.

Streaming:

- `Citeformer.stream()` returns a `StreamingResult` — iterate to consume chunks
  as they're decoded, then call `.finalize()` to get the full `GenerationResult`.
  See the class docstring below for the usage pattern.
"""

from __future__ import annotations

import re
from collections.abc import AsyncIterator, Iterator
from typing import Any

from citeformer.backends.base import Backend
from citeformer.core import (
    Citation,
    GenerationResult,
    MarkerStyle,
    Policy,
    Reference,
    Source,
    TokenUsage,
)
from citeformer.render import render_references

# Pattern for extracting [N] markers from generated text. The grammar layer
# constrains N to the valid source id range at decode time; this pattern only
# does the post-hoc parsing, not enforcement.
_CITE_PATTERN = re.compile(r"\[(\d+)\]")

# Run-of-markers pattern used by `deduplicate_adjacent_cites`. Matches two or
# more `[N]` markers separated only by whitespace — the exact "stacking"
# shape the REQUIRED policy produces on small models that want to close a
# sentence but keep choosing in-range cite ids.
_CITE_RUN_PATTERN = re.compile(r"(?:\[\d+\]\s*){2,}\[\d+\]")


#: Regex patterns for extracting inline markers from generated text. Keyed by
#: :class:`~citeformer.core.MarkerStyle`. The pattern captures the digit(s)
#: inside group 1.
_MARKER_PATTERNS: dict[MarkerStyle, re.Pattern[str]] = {
    MarkerStyle.BRACKET: re.compile(r"\[(\d+)\]"),
    MarkerStyle.PAREN: re.compile(r"\((\d+)\)"),
    MarkerStyle.CURLY: re.compile(r"\{(\d+)\}"),
    MarkerStyle.CARET: re.compile(r"\^(\d+)"),
}


def _pattern_for(style: MarkerStyle) -> re.Pattern[str]:
    """Return the compiled regex for a marker style (not exposed publicly)."""
    return _MARKER_PATTERNS[style]


def deduplicate_adjacent_cites(text: str) -> str:
    """Collapse runs of adjacent ``[N]`` markers to the unique ids only.

    The REQUIRED policy's grammar allows ``cite-group ::= cite-id (ws
    cite-id)*`` — more than one citation between content and ``sent-end``.
    Small instruction-tuned models under REQUIRED often emit runs like
    ``[1] [2] [3] [1] [2] [3] [1]`` when closing a sentence where they
    *wanted* to cite something out-of-scope: the grammar forces progress,
    but the model fills the cite-group by cycling valid ids.

    This helper rewrites each such run to contain each cite id at most
    once, preserving order of first appearance. ``[1] [2] [3] [1] [2]`` →
    ``[1] [2] [3]``. Single markers are untouched.

    Args:
        text: The generated text (``GenerationResult.text``).

    Returns:
        The same string with adjacent-cite runs deduplicated. Non-citation
        content is copied verbatim.

    Example:
        >>> deduplicate_adjacent_cites("Foo [1] [2] [3] [1] [2]. Bar [4].")
        'Foo [1] [2] [3]. Bar [4].'
    """

    def _collapse(match: re.Match[str]) -> str:
        ids = _CITE_PATTERN.findall(match.group(0))
        # Dedupe preserving first-appearance order.
        seen: list[str] = []
        for i in ids:
            if i not in seen:
                seen.append(i)
        return " ".join(f"[{i}]" for i in seen)

    return _CITE_RUN_PATTERN.sub(_collapse, text)


class Citeformer:
    """High-level orchestrator for generating citation-backed text.

    Wraps a `Backend` with a citation policy and a CSL style. References are
    rendered deterministically by the home-grown formatters in
    ``citeformer.render.formatters`` — the model never emits bibliography text.

    Example:
        >>> from citeformer import Citeformer, Source
        >>> from citeformer.backends import MockBackend
        >>> sources = [Source(metadata={"id": "a", "type": "book"}, content="...")]
        >>> cf = Citeformer(backend=MockBackend())
        >>> result = cf.generate(prompt="hi", sources=sources)
        >>> "[1]" in result.text
        True

    Attributes:
        backend: The backend used to generate raw text.
        style: CSL style identifier (e.g. `"apa-7"`) for the reference renderer.
        citation_policy: Default citation enforcement policy.
    """

    def __init__(
        self,
        backend: Backend,
        style: str = "apa-7",
        citation_policy: Policy = Policy.REQUIRED,
        marker_style: MarkerStyle = MarkerStyle.BRACKET,
    ) -> None:
        """Construct a Citeformer.

        Args:
            backend: Backend instance to delegate generation to.
            style: CSL style identifier for reference rendering (see
                ``bundled_style_names()`` for available styles).
            citation_policy: Default citation enforcement policy for `generate()`.
            marker_style: Shape of inline citation markers. Default is
                :attr:`MarkerStyle.BRACKET` (``[N]``). Swap for ``PAREN``
                (``(N)``), ``CURLY`` (``{N}``), or ``CARET`` (``^N``) when
                the downstream pipeline already reserves square brackets.
                The structural guarantee (digit enum bounded by ``len(sources)``)
                holds identically across styles.
        """
        self.backend = backend
        self.style = style
        self.citation_policy = citation_policy
        self.marker_style = marker_style

    def generate(
        self,
        prompt: str,
        sources: list[Source],
        policy: Policy | None = None,
        **options: Any,
    ) -> GenerationResult:
        """Generate text with constrained citations.

        Args:
            prompt: User prompt. The orchestrator passes it through to the backend
                verbatim; retrieval-augmented stitching is the caller's job until
                we add a prompt-assembly helper in a later phase.
            sources: Evidence chunks in scope. Position (1-indexed) determines the
                citation id the model emits and the id used in `Citation.source_id`
                and `Reference.source_id`.
            policy: Override the default `citation_policy` for this call.
            **options: Backend-specific options forwarded to `Backend.generate()`.
                Pass ``marker_style=`` to override the orchestrator's default for
                a single call.

        Returns:
            A `GenerationResult` with text, parsed citations, and rendered references.
        """
        effective_policy = policy if policy is not None else self.citation_policy
        effective_marker = options.pop("marker_style", self.marker_style)
        text = self.backend.generate(
            prompt=prompt,
            sources=sources,
            policy=effective_policy,
            marker_style=effective_marker,
            **options,
        )
        citations = self._parse_citations(
            text,
            effective_marker,
            rich=_pull_rich_citations(self.backend),
        )
        references = self._render_references(sources, citations)
        return GenerationResult(
            text=text,
            citations=citations,
            references=references,
            sources=list(sources),
            usage=_pull_usage(self.backend),
        )

    def stream(
        self,
        prompt: str,
        sources: list[Source],
        policy: Policy | None = None,
        **options: Any,
    ) -> StreamingResult:
        """Stream generation as text chunks while tracking state for finalization.

        Returns a `StreamingResult` which is both iterable (yielding decoded
        chunks in order) and finalizable (building a full `GenerationResult`
        from the accumulated text after the stream completes).

        Typical usage::

            stream = cf.stream(prompt="...", sources=sources)
            for chunk in stream:
                print(chunk, end="", flush=True)
            result = stream.finalize()  # full GenerationResult with refs + verify()

        If you call `.finalize()` without consuming the iterator first, it will
        exhaust the iterator internally so you get a complete result either way.

        Args:
            prompt: User prompt, same semantics as `generate()`.
            sources: Sources in scope (position → citation id).
            policy: Override the default `citation_policy` for this call.
            **options: Forwarded to `Backend.stream()`.

        Returns:
            A `StreamingResult` wrapping the backend's chunk iterator.
        """
        effective_policy = policy if policy is not None else self.citation_policy
        effective_marker = options.pop("marker_style", self.marker_style)
        chunks = self.backend.stream(
            prompt=prompt,
            sources=sources,
            policy=effective_policy,
            marker_style=effective_marker,
            **options,
        )
        return StreamingResult(
            chunks=chunks,
            sources=list(sources),
            style=self.style,
            marker_style=effective_marker,
            backend=self.backend,
        )

    async def agenerate(
        self,
        prompt: str,
        sources: list[Source],
        policy: Policy | None = None,
        **options: Any,
    ) -> GenerationResult:
        """Async counterpart of :meth:`generate`. See ADR-014.

        Calls the backend's ``agenerate()`` (which is concrete on every backend
        — the ABC default uses ``asyncio.to_thread``; OpenAI / Anthropic
        backends override with native async clients). Parsing, rendering, and
        usage-threading are identical to the sync path; the only difference is
        the ``await`` on the backend call.

        Returns:
            Same as :meth:`generate`.
        """
        effective_policy = policy if policy is not None else self.citation_policy
        effective_marker = options.pop("marker_style", self.marker_style)
        text = await self.backend.agenerate(
            prompt=prompt,
            sources=sources,
            policy=effective_policy,
            marker_style=effective_marker,
            **options,
        )
        citations = self._parse_citations(
            text,
            effective_marker,
            rich=_pull_rich_citations(self.backend),
        )
        references = self._render_references(sources, citations)
        return GenerationResult(
            text=text,
            citations=citations,
            references=references,
            sources=list(sources),
            usage=_pull_usage(self.backend),
        )

    def astream(
        self,
        prompt: str,
        sources: list[Source],
        policy: Policy | None = None,
        **options: Any,
    ) -> AsyncStreamingResult:
        """Async counterpart of :meth:`stream`. See ADR-014.

        Returns an :class:`AsyncStreamingResult` — async-iterable for chunk
        consumption and ``await`` -finalizable to a complete
        :class:`GenerationResult`. The orchestrator method itself is sync (no
        ``await``); the async work happens when you iterate or finalize.

        Typical usage::

            stream = cf.astream(prompt="...", sources=sources)
            async for chunk in stream:
                print(chunk, end="", flush=True)
            result = await stream.finalize()

        Args:
            prompt: User prompt, same semantics as :meth:`generate`.
            sources: Sources in scope (position → citation id).
            policy: Override the default ``citation_policy`` for this call.
            **options: Forwarded to :meth:`Backend.astream`.

        Returns:
            An :class:`AsyncStreamingResult` wrapping the backend's async
            chunk iterator.
        """
        effective_policy = policy if policy is not None else self.citation_policy
        effective_marker = options.pop("marker_style", self.marker_style)
        chunks = self.backend.astream(
            prompt=prompt,
            sources=sources,
            policy=effective_policy,
            marker_style=effective_marker,
            **options,
        )
        return AsyncStreamingResult(
            chunks=chunks,
            sources=list(sources),
            style=self.style,
            marker_style=effective_marker,
            backend=self.backend,
        )

    @staticmethod
    def _parse_citations(
        text: str,
        marker_style: MarkerStyle = MarkerStyle.BRACKET,
        rich: list[dict[str, Any]] | None = None,
    ) -> list[Citation]:
        """Extract markers from `text` into `Citation` objects.

        If ``rich`` is supplied (the Anthropic backend's
        ``last_rich_citations`` is the only producer today), each marker
        is merged with the corresponding rich-metadata dict by *order*
        — both lists track the same emit sequence, so ``rich[i]`` lines
        up with the i-th marker the regex finds. Length mismatches fall
        through silently (the marker stays plain) since misaligned data
        is worse than no data.
        """
        pattern = _pattern_for(marker_style)
        matches = list(pattern.finditer(text))
        rich = rich or []
        rich_aligned = len(rich) == len(matches)
        citations: list[Citation] = []
        for i, m in enumerate(matches):
            extra: dict[str, Any] = {}
            if rich_aligned:
                meta = rich[i]
                extra["cited_text"] = meta.get("cited_text")
                src_span = meta.get("source_span")
                extra["source_span"] = tuple(src_span) if src_span is not None else None
                extra["document_title"] = meta.get("document_title")
            citations.append(
                Citation(
                    span=(m.start(), m.end()),
                    source_id=int(m.group(1)),
                    **extra,
                )
            )
        return citations

    def _render_references(
        self,
        sources: list[Source],
        citations: list[Citation],
    ) -> list[Reference]:
        """Render the reference list via the built-in formatters.

        Delegates to `citeformer.render.render_references`. Out-of-range cite
        ids are skipped silently (grammar-level enforcement prevents them at
        decode time; this is the belt-and-suspenders path for mock backends
        and hand-constructed tests).
        """
        return render_references(sources, citations, self.style)


class StreamingResult:
    """Iterable wrapper over a backend's streaming output.

    Acts as an `Iterator[str]`, yielding decoded chunks in order. Internally
    accumulates the full text so that after iteration completes, `finalize()`
    can parse citations + render references and return a `GenerationResult`
    identical to what `Citeformer.generate()` would have produced for the
    same (prompt, sources, policy).

    Idempotent: calling `finalize()` multiple times returns the same
    `GenerationResult` instance. Calling it before exhausting the iterator
    consumes the remaining chunks so the result is complete — partial
    finalize isn't supported by design; if you want the partial text at
    any point, use the `text` property.

    Attributes:
        sources: Sources passed to `Citeformer.stream()`.
        style: CSL style used to render references.
    """

    def __init__(
        self,
        *,
        chunks: Iterator[str],
        sources: list[Source],
        style: str,
        marker_style: MarkerStyle = MarkerStyle.BRACKET,
        backend: Backend | None = None,
    ) -> None:
        """Wrap a backend chunk iterator. Not for direct construction by users."""
        self._chunks = chunks
        self.sources = sources
        self.style = style
        self.marker_style = marker_style
        self._accumulated: list[str] = []
        self._finalized: GenerationResult | None = None
        self._backend = backend

    def __iter__(self) -> StreamingResult:
        return self

    def __next__(self) -> str:
        chunk = next(self._chunks)
        self._accumulated.append(chunk)
        return chunk

    @property
    def text(self) -> str:
        """The text consumed so far. Updates as iteration progresses."""
        return "".join(self._accumulated)

    def finalize(self) -> GenerationResult:
        """Exhaust the iterator (if needed) and build the full `GenerationResult`.

        Safe to call multiple times — the first call caches the result and
        subsequent calls return the same instance.
        """
        if self._finalized is not None:
            return self._finalized
        # Exhaust any remaining chunks so the result is complete.
        for _ in self:
            pass
        text = self.text
        rich = _pull_rich_citations(self._backend) if self._backend is not None else None
        citations = Citeformer._parse_citations(text, self.marker_style, rich=rich)
        references = render_references(self.sources, citations, self.style)
        self._finalized = GenerationResult(
            text=text,
            citations=citations,
            references=references,
            sources=self.sources,
            usage=_pull_usage(self._backend) if self._backend is not None else None,
        )
        return self._finalized


class AsyncStreamingResult:
    """Async-iterable wrapper over a backend's async streaming output.

    The async parallel of :class:`StreamingResult`. Same surface — chunks
    arrive in order, accumulated text is exposed via :attr:`text`, and
    :meth:`finalize` builds the full :class:`GenerationResult` — but the
    iteration is ``async for`` and ``finalize()`` is awaitable.

    Idempotent: calling ``await stream.finalize()`` multiple times returns
    the same `GenerationResult` instance. Calling it before exhausting
    the iterator awaits the remaining chunks so the result is complete.

    Typical usage::

        stream = cf.astream(prompt="...", sources=sources)
        async for chunk in stream:
            print(chunk, end="", flush=True)
        result = await stream.finalize()

    Attributes:
        sources: Sources passed to :meth:`Citeformer.astream`.
        style: CSL style used to render references.
    """

    def __init__(
        self,
        *,
        chunks: AsyncIterator[str],
        sources: list[Source],
        style: str,
        marker_style: MarkerStyle = MarkerStyle.BRACKET,
        backend: Backend | None = None,
    ) -> None:
        """Wrap a backend async-chunk iterator. Not for direct construction by users."""
        self._chunks = chunks
        self.sources = sources
        self.style = style
        self.marker_style = marker_style
        self._accumulated: list[str] = []
        self._finalized: GenerationResult | None = None
        self._backend = backend

    def __aiter__(self) -> AsyncStreamingResult:
        return self

    async def __anext__(self) -> str:
        chunk = await self._chunks.__anext__()
        self._accumulated.append(chunk)
        return chunk

    @property
    def text(self) -> str:
        """The text consumed so far. Updates as iteration progresses."""
        return "".join(self._accumulated)

    async def finalize(self) -> GenerationResult:
        """Exhaust the async iterator (if needed) and build the full result.

        Safe to call multiple times — the first call caches the result and
        subsequent calls return the same instance.
        """
        if self._finalized is not None:
            return self._finalized
        # Exhaust any remaining chunks so the result is complete.
        async for _ in self:
            pass
        text = self.text
        rich = _pull_rich_citations(self._backend) if self._backend is not None else None
        citations = Citeformer._parse_citations(text, self.marker_style, rich=rich)
        references = render_references(self.sources, citations, self.style)
        self._finalized = GenerationResult(
            text=text,
            citations=citations,
            references=references,
            sources=self.sources,
            usage=_pull_usage(self._backend) if self._backend is not None else None,
        )
        return self._finalized


def _pull_usage(backend: Backend) -> TokenUsage | None:
    """Read ``backend.last_usage`` if the backend exposes it.

    Local backends (HF, vLLM, llama.cpp, MockBackend) don't define
    ``last_usage``; getattr's default keeps them silent. API backends set
    it at the end of every ``generate()`` / ``stream()`` call so the
    orchestrator can copy the value onto the resulting ``GenerationResult``.
    """
    return getattr(backend, "last_usage", None)


def _pull_rich_citations(backend: Backend) -> list[dict[str, Any]] | None:
    """Read ``backend.last_rich_citations`` if the backend exposes it.

    Anthropic is the only backend today that surfaces rich per-citation
    metadata (``cited_text``, ``source_span``, ``document_title``) — this
    helper hides the duck-typed lookup so the orchestrator stays
    backend-agnostic.
    """
    rich = getattr(backend, "last_rich_citations", None)
    return rich if rich else None
