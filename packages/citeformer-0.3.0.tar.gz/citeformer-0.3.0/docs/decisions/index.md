# Architecture decisions

Ongoing log of non-obvious design choices in citeformer, in
[ADR (Architecture Decision Record)](https://adr.github.io/) style. Each entry
is a short record of *what* we decided, *why*, and *what follows*. Decisions
are numbered in the order they were made; when one is superseded, we mark it
and link to the replacement rather than editing history.

```{toctree}
:maxdepth: 1

001-gbnf-over-lark
002-inline-markers-stay-numeric
003-bundle-five-csl-styles
004-citeproc-rewrite
005-metadata-deps-in-main-install
006-vllm-excluded-from-all-extra
007-required-policy-progression-gap
008-generation-result-schema-v2
009-bounded-content-required
010-verification-report-schema-v3
011-configurable-marker-styles
012-generation-result-schema-v3
013-citation-rich-attribution
014-async-surface
015-defer-bedrock-vertex
016-defer-fine-grain-windowing
017-defer-cost-tables
```
