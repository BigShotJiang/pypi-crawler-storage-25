#pragma once
#include <stdint.h>
#include <stddef.h>

#define __global__
#define __device__
#define __host__
#define __restrict__ __restrict
#define __popcll __builtin_popcountll

struct uint3 {
    int x, y, z;
};

extern uint3 blockIdx;
extern uint3 blockDim;
extern uint3 threadIdx;

typedef int cudaError_t;
#define cudaSuccess 0

cudaError_t cudaMalloc(void** devPtr, size_t size);
cudaError_t cudaMemcpy(void* dst, const void* src, size_t count, int kind);
cudaError_t cudaFree(void* devPtr);
cudaError_t cudaDeviceSynchronize();

#define cudaMemcpyHostToDevice 1
#define cudaMemcpyDeviceToHost 2
#define cudaMemcpyDeviceToDevice 3

template<typename T>
void atomicAdd(T* address, T val) {}

struct dim3 {
    unsigned int x, y, z;
    dim3(unsigned int x=1, unsigned int y=1, unsigned int z=1) : x(x), y(y), z(z) {}
};

