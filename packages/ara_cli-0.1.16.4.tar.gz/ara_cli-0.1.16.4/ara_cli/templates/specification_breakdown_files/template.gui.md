- [\<Name\_of\_View\>](#name_of_view)
  - [Visual](#visual)
    - [Design Rules](#design-rules)
  - [Layout Overview](#layout-overview)
    - [Sections](#sections)
    - [Dimensions](#dimensions)
      - [Notes](#notes)
    - [Color Palette](#color-palette)
    - [Typography](#typography)


# <Name_of_View>

## Visual

> 📷 **Screenshot placeholder** — place the view screenshot here

![Visual example](./screenshot.png)

### Design Rules
- [ ] eg. "use material UI"

---

## Layout Overview
### Sections
1. Header
2. Content
3. Footer

---

### Dimensions

Screen resolution | Column widths: left  | center  | right  
--- | --- | --- | --- 
1024 × 768 px | 352 px | 256 px | 352 px

#### Notes 

(with 16 px margins and gaps).

---

### Color Palette

| Element | RGB |
|--------|-----|
| Dark navy (header, blue buttons, active keys) | 0, 51, 102 |


---

### Typography

| Element | Size | Weight |
|--------|------|--------|
| Screen title, time/date values | 18 px | Bold |
