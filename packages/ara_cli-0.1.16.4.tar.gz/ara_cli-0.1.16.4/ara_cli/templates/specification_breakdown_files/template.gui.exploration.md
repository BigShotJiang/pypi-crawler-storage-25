# GUI Exploration: <descriptive title of exploration challenge>

- [GUI Exploration: ](#gui-exploration-)
- [Prompt to identify and specify the major relevant GUI building blocks](#prompt-to-identify-and-specify-the-major-relevant-gui-building-blocks)
- [Further define and refine GUI decisions prompt](#further-define-and-refine-gui-decisions-prompt)

# Prompt to identify and specify the major relevant GUI building blocks
given the vision statement of <...>
```
<vision statement>
```

and given the business goal of <...>
```
<business goal>
```

and given the user profile / operator profile <...>
```
<user types, skills, context of use>
```

and given the main usage scenarios <...>
```
<key workflows, tasks, frequency, critical situations>
```

and given the targeted capabilities <...>
```
<what the GUI must enable users to do>
```

and given the targeted key features <...>
```
<important screen functions and interactions>
```

and given further known functional requirements
```
* list of known functional requirements if any
```

and given further known non functional requirements
```
* list of known non functional requirements if any
```

and given any upfront decided technical or design constraints
```
<screen size, hardware keys, branding, platform, accessibility, performance, legacy constraints>
```

and given the specified design concept
```
<style, design system, visual principles, existing references>
```

create a list of the most important GUI constraints and design decisions by using the following format template:
```
# Title: <descriptive title of the explored GUI concept>

- [Title: ](#title-)
- [Decision for screen purpose and user goal](#decision-for-screen-purpose-and-user-goal)
- [Decision for layout structure](#decision-for-layout-structure)
- [Decision for navigation concept](#decision-for-navigation-concept)
- [Decision for header content](#decision-for-header-content)
- [Decision for content areas and information hierarchy](#decision-for-content-areas-and-information-hierarchy)
- [Decision for actions and button priorities](#decision-for-actions-and-button-priorities)
- [Decision for status, feedback, and error display](#decision-for-status-feedback-and-error-display)
- [Decision for color usage](#decision-for-color-usage)
- [Decision for typography](#decision-for-typography)
- [Decision for icons and labels](#decision-for-icons-and-labels)
- [Decision for interaction states and behaviors](#decision-for-interaction-states-and-behaviors)
- [Decision for GUI elements to document in gui.md](#decision-for-gui-elements-to-document-in-guimd)

# Decision for screen purpose and user goal
<screen purpose>: <why this screen exists and what success means>

# Decision for layout structure
<zones / columns / panels / bars>: <purpose and value>

# Decision for navigation concept
<primary navigation / secondary navigation / hardware keys / menu logic>: <purpose and value>

# Decision for header content
<title / logo / time / date / context information>: <purpose and value>

# Decision for content areas and information hierarchy
<main information blocks>: <purpose and value>

# Decision for actions and button priorities
<primary / secondary / destructive / passive actions>: <purpose and value>

# Decision for status, feedback, and error display
<status indicators / warnings / errors / logs / confirmations>: <purpose and value>

# Decision for color usage
<main colors and semantic meaning>: <purpose and value>

# Decision for typography
<font sizes / weights / readability rules>: <purpose and value>

# Decision for icons and labels
<icon style / terminology / wording>: <purpose and value>

# Decision for interaction states and behaviors
<active / disabled / selected / focused / error / loading>: <purpose and value>

# Decision for GUI elements to document in gui.md
<list of sections and concrete values to capture in the final GUI spec>: <purpose and value>
```

Explain why these GUI decisions fit the given constraints, user needs, and operating context, and identify which decisions still need validation by visual exploration or stakeholder review.

# Further define and refine GUI decisions prompt
Take the previously identified GUI decisions and refine them into concrete, documentable values for `gui.md`.

For each decision:
- make assumptions explicit
- propose 2–3 viable alternatives where useful
- compare pros, cons, and risks
- identify the preferred option
- provide concrete values where possible (dimensions, labels, colors, typography, spacing, button roles, states)
- separate clearly between facts, assumptions, and open questions

Structure the refinement so that the result can directly fill these `gui.md` sections:
- Visual
- Layout Overview
- Header Bar
- Content Area
- Navigation Areas
- Information Panels
- Status Display
- Action / Function Key Bar
- Color Palette
- Typography
- Interaction States
- Open Issues / Validation Notes
