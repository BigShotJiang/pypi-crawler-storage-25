from ara_cli.file_classifier import FileClassifier
from ara_cli.artefact_reader import ArtefactReader
from ara_cli.file_lister import list_files_in_directory
from ara_cli.list_filter import ListFilter, filter_list
from ara_cli.artefact_fuzzy_search import suggest_close_name_matches
from ara_cli.artefact_models.artefact_data_retrieval import (
    artefact_content_retrieval,
    artefact_path_retrieval,
    artefact_tags_retrieval,
)
from ara_cli.classifier import Classifier
import typer
import os


class ArtefactLister:
    def __init__(self, file_system=None):
        self.file_system = file_system or os

    def filter_artefacts(self, classified_files: list, list_filter: ListFilter):
        filtered_list = filter_list(
            list_to_filter=classified_files,
            list_filter=list_filter,
            content_retrieval_strategy=artefact_content_retrieval,
            file_path_retrieval=artefact_path_retrieval,
            tag_retrieval=artefact_tags_retrieval,
        )
        return filtered_list

    def list_files(
        self, tags=None, navigate_to_target=False, list_filter: ListFilter | None = None
    ):
        artefact_list = ArtefactReader(self.file_system).read_artefacts(tags=tags)
        artefact_list = self.filter_artefacts(artefact_list, list_filter)

        filtered_artefact_list = {
            key: [artefact for artefact in value if artefact is not None]
            for key, value in artefact_list.items()
        }
        file_classifier = FileClassifier(self.file_system)
        file_classifier.print_classified_files(filtered_artefact_list)

    def list_branch(
        self, classifier, artefact_name, list_filter: ListFilter | None = None
    ):
        file_classifier = FileClassifier(os)
        classified_artefacts = file_classifier.classify_files()
        artefact_info = classified_artefacts.get(classifier, [])
        matching_artefact_info = [
            p for p in artefact_info if p["title"] == artefact_name
        ]

        if not matching_artefact_info:
            suggest_close_name_matches(
                artefact_name, [info["title"] for info in artefact_info]
            )

        artefacts_by_classifier = {classifier: []}
        ArtefactReader(self.file_system).step_through_value_chain(
            artefact_name=artefact_name,
            classifier=classifier,
            artefacts_by_classifier=artefacts_by_classifier,
        )
        artefacts_by_classifier = self.filter_artefacts(
            artefacts_by_classifier, list_filter
        )
        file_classifier.print_classified_files(artefacts_by_classifier)

    def list_children(
        self, classifier, artefact_name, list_filter: ListFilter | None = None
    ):
        file_classifier = FileClassifier(os)
        classified_artefacts = file_classifier.classify_files()
        artefact_info = classified_artefacts.get(classifier, [])
        matching_artefact_info = [
            p for p in artefact_info if p["title"] == artefact_name
        ]

        if not matching_artefact_info:
            suggest_close_name_matches(
                artefact_name, [info["title"] for info in artefact_info]
            )

        child_artefacts = ArtefactReader(self.file_system).find_children(
            artefact_name=artefact_name, classifier=classifier
        )

        child_artefacts = self.filter_artefacts(child_artefacts, list_filter)

        file_classifier.print_classified_files(child_artefacts)

    def list_all_children(
        self, classifier, artefact_name, list_filter: ListFilter | None = None
    ):
        matching_artefact_info = self._validate_artefact_exists(classifier, artefact_name)

        all_descendants = ArtefactReader(self.file_system).find_all_descendants(
            artefact_name=artefact_name,
            classifier=classifier,
        )

        if list_filter:
            all_descendants = self._filter_descendants(all_descendants, list_filter)

        self._print_descendants_tree(all_descendants)

    def _validate_artefact_exists(self, classifier, artefact_name):
        """Validate if the artefact exists and return matching info or suggest alternatives."""
        file_classifier = FileClassifier(os)
        classified_artefacts = file_classifier.classify_files()
        artefact_info = classified_artefacts.get(classifier, [])
        matching_artefact_info = [
            p for p in artefact_info if p["title"] == artefact_name
        ]

        if not matching_artefact_info:
            suggest_close_name_matches(
                artefact_name, [info["title"] for info in artefact_info]
            )
        return matching_artefact_info

    def _filter_descendants(self, all_descendants, list_filter):
        """Filter descendants based on the provided list_filter."""
        flat_artefacts = {}
        for artefact, child_classifier, _ in all_descendants:
            if child_classifier not in flat_artefacts:
                flat_artefacts[child_classifier] = []
            flat_artefacts[child_classifier].append(artefact)

        flat_artefacts = self.filter_artefacts(flat_artefacts, list_filter)

        filtered_titles = set()
        for artefacts in flat_artefacts.values():
            for a in artefacts:
                filtered_titles.add(getattr(a, "title", None))

        return [
            (a, c, d)
            for a, c, d in all_descendants
            if getattr(a, "title", None) in filtered_titles
        ]

    @staticmethod
    def _print_descendants_tree(descendants: list):
        """Print descendants as a tree with box-drawing characters (├──, └──, │).

        Each entry is (artefact, classifier, depth) where depth=0 means direct child.
        """
        if not descendants:
            return

        # Build index: for each position, what is the depth?
        depths = [depth for _, _, depth in descendants]
        n = len(descendants)

        # For each node, determine whether it is the last sibling at its depth
        # by checking if any later node has the same or lesser depth before
        # a node of smaller depth appears.
        def is_last_at_pos(i):
            current_depth = depths[i]
            for j in range(i + 1, n):
                if depths[j] < current_depth:
                    return True
                if depths[j] == current_depth:
                    return False
            return True

        # For each depth level, track whether the ancestor at that level was
        # the last sibling — used to decide │ vs blank continuation.
        last_at_depth: dict[int, bool] = {}

        for i, (artefact, child_classifier, depth) in enumerate(descendants):
            last = is_last_at_pos(i)
            last_at_depth[depth] = last

            # Build prefix from ancestor levels (depth 0 needs no prefix columns)
            prefix = ""
            for level in range(depth):
                if last_at_depth.get(level, True):
                    prefix += "    "
                else:
                    prefix += "│   "

            connector = "└── " if last else "├── "
            file_path = getattr(artefact, "file_path", None)
            path_str = (
                f"./{os.path.relpath(file_path, os.getcwd())}"
                if file_path
                else getattr(artefact, "title", str(artefact))
            )
            classifier_label = Classifier.get_artefact_title(child_classifier)
            typer.echo(f"{prefix}{connector}{classifier_label}: {path_str}")

    def list_data(
        self, classifier, artefact_name, list_filter: ListFilter | None = None
    ):
        file_classifier = FileClassifier(os)
        classified_artefact_info = file_classifier.classify_files()
        artefact_info_dict = classified_artefact_info.get(classifier, [])

        matching_info = [
            info for info in artefact_info_dict if info["title"] == artefact_name
        ]

        if not matching_info:
            suggest_close_name_matches(
                artefact_name, [info["title"] for info in artefact_info_dict]
            )
            return

        artefact_info = matching_info[0]
        data_dir = os.path.splitext(artefact_info["file_path"])[0] + ".data"
        if os.path.exists(data_dir):
            list_files_in_directory(data_dir, list_filter)
