import os
from typing import List, Dict, Optional

class AspectDiscoveryService:
    def __init__(self):
        from ara_cli.file_classifier import FileClassifier
        self.file_classifier = FileClassifier(os)
        self.classified_artefacts = self.file_classifier.classify_files()

    def discover(self, aspect_types: List[str], target_context: Optional[Dict] = None) -> List[Dict]:
        from ara_cli.directory_navigator import DirectoryNavigator
        root = DirectoryNavigator.find_ara_directory_root()
        if not root:
            return []

        all_found = []
        for atype in aspect_types:
            all_found.extend(self._scan_for_type(root, atype))

        if target_context and (target_context.get("target_name") or target_context.get("target_classifier")):
            return self._filter_by_hierarchy(all_found, target_context)

        return all_found

    def _scan_for_type(self, root: str, aspect_type: str) -> List[Dict]:
        aspects = []
        pattern = f"{aspect_type}.md"
        
        # We only want to look at: ara/<classifier>/<artefact_name>.data/<aspect_type>.md
        # This prevents picking up files from nested folders like prompt.data/
        
        try:
            for classifier_dir in os.listdir(root):
                classifier_path = os.path.join(root, classifier_dir)
                if not os.path.isdir(classifier_path) or classifier_dir.startswith('.'):
                    continue
                    
                # We are now at e.g. ara/features/ or ara/examples/
                for item in os.listdir(classifier_path):
                    if item.endswith(".data"):
                        data_dir_path = os.path.join(classifier_path, item)
                        if not os.path.isdir(data_dir_path):
                            continue
                            
                        # Look for the aspect file DIRECTLY inside this .data directory
                        aspect_file_path = os.path.join(data_dir_path, pattern)
                        if os.path.isfile(aspect_file_path):
                            # Exclude exploration files
                            if "_exploration" in pattern:
                                continue
                                
                            aspect_entry = self._build_aspect_entry(data_dir_path, pattern, aspect_type)
                            if aspect_entry:
                                aspects.append(aspect_entry)
        except Exception:
            pass
            
        return aspects

    def _build_aspect_entry(self, dirpath: str, filename: str, aspect_type: str) -> Optional[Dict]:
        basename = os.path.basename(dirpath)
        
        # Only scan inside .data directories
        if not basename.endswith(".data"):
            return None

        artefact_base = basename[:-5]
        artefact_folder = os.path.dirname(dirpath)
        
        # 1. Try to find the matching classified artefact
        for classifier, artefacts in self.classified_artefacts.items():
            for a in artefacts:
                a_folder_abs = os.path.abspath(os.path.dirname(a["file_path"]))
                artefact_folder_abs = os.path.abspath(artefact_folder)
                if a["title"].lower() == artefact_base.lower() and a_folder_abs == artefact_folder_abs:
                    return {
                        "aspect_type": aspect_type,
                        "filename": filename,
                        "aspect_path": os.path.join(dirpath, filename),
                        "artefact_name": artefact_base,
                        "artefact_classifier": classifier,
                        "artefact_path": a["file_path"]
                    }
        
        # 2. Fallback for unclassified .data dirs (like in examples/ or temp folders)
        # We still want to show these aspects by guessing their classifier from path
        potential_classifier = "unknown"
        from ara_cli.classifier import Classifier
        for c, sub_dir in Classifier.valid_classifiers.items():
            if sub_dir in dirpath:
                potential_classifier = c
                break
        
        return {
            "aspect_type": aspect_type,
            "filename": filename,
            "aspect_path": os.path.join(dirpath, filename),
            "artefact_name": artefact_base,
            "artefact_classifier": potential_classifier,
            "artefact_path": dirpath # Use dirpath as fallback artefact path
        }

    def _filter_by_hierarchy(self, aspects: List[Dict], context: Dict) -> List[Dict]:
        target_name = context.get("target_name")
        target_classifier = context.get("target_classifier")
        
        # Case 1: Only classifier provided (e.g. ara list example --aspect all)
        if target_classifier and not target_name:
            # Ensure we compare strings (classifier might be an Enum)
            t_class = target_classifier.value if hasattr(target_classifier, "value") else str(target_classifier)
            return [a for a in aspects if a["artefact_classifier"] == t_class]
            
        # Case 2: Specific artefact name provided (e.g. ara list feature login --aspect gui)
        if target_name:
            target_artefact = None
            t_name_low = target_name.lower()
            
            target_artefact = context.get("artefact")
            
            if not target_artefact:
                for classifier, artefacts in self.classified_artefacts.items():
                    # Ensure we compare strings (classifier might be an Enum)
                    c_str = classifier.value if hasattr(classifier, "value") else str(classifier)
                    t_class_str = target_classifier.value if hasattr(target_classifier, "value") else str(target_classifier) if target_classifier else None
                    
                    if t_class_str and c_str != t_class_str:
                        continue
                        
                    for a in artefacts:
                        if a["title"].lower() == t_name_low:
                            target_artefact = a
                            break
                    if target_artefact: break
                
            if not target_artefact:
                return []

            target_file_path_abs = os.path.abspath(target_artefact["file_path"])
            relevant_paths = {target_file_path_abs}
            
            t_class = target_artefact["classifier"]
            t_name = target_artefact.get("title", target_artefact.get("artefact_name", target_name))
            
            # Case 2a: Include children (transitive)
            if context.get("include_children") or context.get("include_all_children"):
                from ara_cli.artefact_reader import ArtefactReader
                descendants = ArtefactReader().find_all_descendants(artefact_name=t_name, classifier=t_class)
                for c_artefact, _c_class, _depth in descendants:
                    if getattr(c_artefact, "file_path", None):
                        relevant_paths.add(os.path.abspath(c_artefact.file_path))
            
            # Case 2b: Include parents (transitive branch)
            if context.get("include_parent") or context.get("include_branch"):
                from ara_cli.artefact_reader import ArtefactReader
                artefacts_by_classifier = {}
                ArtefactReader().step_through_value_chain(
                    artefact_name=t_name,
                    classifier=t_class,
                    artefacts_by_classifier=artefacts_by_classifier
                )
                for class_list in artefacts_by_classifier.values():
                    for p_artefact in class_list:
                        if getattr(p_artefact, "file_path", None):
                            relevant_paths.add(os.path.abspath(p_artefact.file_path))
            
            return [a for a in aspects if os.path.abspath(a["artefact_path"]) in relevant_paths]
            
        return aspects
