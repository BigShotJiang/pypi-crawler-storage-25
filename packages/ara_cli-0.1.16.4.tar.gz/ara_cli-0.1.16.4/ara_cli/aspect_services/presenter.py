import json
import os
import typer
from typing import List, Dict

class AspectPresenter:
    @staticmethod
    def to_json(aspect_types: List[str], aspects: List[Dict], summary: str = None, conflicts: str = None) -> str:
        """
        Returns a rich JSON representation of the aspects, including optional AI analysis.
        """
        # Group aspects by their artefact classifier
        grouped_results = {}
        for aspect in aspects:
            classifier = aspect.get("artefact_classifier", "unknown")
            if classifier not in grouped_results:
                grouped_results[classifier] = []
            grouped_results[classifier].append(aspect)

        output = {
            "metadata": {
                "aspect_types": aspect_types,
                "count": len(aspects),
                "has_summary": bool(summary),
                "has_conflicts": bool(conflicts)
            },
            "analysis": {
                "summary": summary,
                "conflicts": conflicts
            },
            "results": grouped_results
        }
        return json.dumps(output, indent=2)

    @staticmethod
    def to_terminal(aspects: List[Dict]):
        """
        Prints aspects to terminal grouped by classifier and sorted by hierarchy.
        """
        from ara_cli.classifier import Classifier
        ordered = Classifier.ordered_classifiers()
        
        # Sort by classifier order then artefact name
        aspects.sort(key=lambda x: (
            ordered.index(x["artefact_classifier"]) if x["artefact_classifier"] in ordered else 99, 
            x["artefact_name"]
        ))

        grouped = {}
        for a in aspects:
            c = a["artefact_classifier"]
            if c not in grouped: grouped[c] = []
            grouped[c].append(a)

        for classifier in ordered:
            if classifier in grouped:
                typer.echo(f"\n{classifier.capitalize()} files:")
                for item in grouped[classifier]:
                    rel_path = os.path.relpath(item["aspect_path"], os.getcwd())
                    clickable_path = rel_path.replace("\\", "/")
                    typer.echo(f"  - [{item['artefact_name']}] - ./{clickable_path}")
        typer.echo("")
