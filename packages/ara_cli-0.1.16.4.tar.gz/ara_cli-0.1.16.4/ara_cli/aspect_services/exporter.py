import os
from typing import List, Dict
from collections import OrderedDict

class AspectExporter:
    @staticmethod
    def export_to_markdown(aspect_type: str, aspects: List[Dict], export_path: str, summary: str = None, conflicts: str = None):
        """
        Exports aspects to a collection markdown file.
        """
        content = [f"# Aspect Collection: {aspect_type}\n"]
        
        if summary:
            content.append(f"## AI Generated Summary\n\n{summary}\n")

        if conflicts:
            content.append(f"## AI Detected Conflicts\n\n{conflicts}\n")

        # Group by artefact
        grouped = OrderedDict()
        for a in aspects:
            path = a["artefact_path"]
            if path not in grouped:
                grouped[path] = {
                    "name": a["artefact_name"],
                    "classifier": a["artefact_classifier"],
                    "aspects": []
                }
            grouped[path]["aspects"].append(a)

        # Table of Contents
        content.append("## Table of Contents\n")
        for path, data in grouped.items():
            anchor = data["name"].lower().replace(" ", "-")
            content.append(f"- [{data['name']} (_{data['classifier']}_)](#{anchor})")
        content.append("\n---\n")

        # Details
        for path, data in grouped.items():
            content.append(f"## {data['name']}\n")
            rel_path = os.path.relpath(path, os.getcwd())
            abs_path_link = os.path.abspath(path).replace("\\", "/")
            content.append(f"**Artefact File:** [{rel_path}](file:///{abs_path_link})\n")
            
            try:
                with open(path, "r", encoding="utf-8") as f:
                    content.append("### Artefact Specification\n")
                    content.append(f"`````md\n{f.read()}\n`````\n")
            except Exception: pass

            for aspect in data["aspects"]:
                content.append(f"### Aspect: {aspect['filename']}\n")
                rel_aspect = os.path.relpath(aspect["aspect_path"], os.getcwd())
                abs_aspect_link = os.path.abspath(aspect["aspect_path"]).replace("\\", "/")
                content.append(f"**Source File:** [{rel_aspect}](file:///{abs_aspect_link})\n")
                try:
                    with open(aspect["aspect_path"], "r", encoding="utf-8") as f:
                        content.append(f"`````md\n{f.read()}\n`````\n")
                except Exception: pass
            content.append("\n---\n")

        with open(export_path, "w", encoding="utf-8") as f:
            f.write("\n".join(content))
