import os
import typer
from ara_cli.aspect_services.discovery import AspectDiscoveryService
from ara_cli.aspect_services.presenter import AspectPresenter
from ara_cli.aspect_services.exporter import AspectExporter
from ara_cli.prompt_handler import process_aspect_llm_task

def list_aspect_action(args):
    """
    Main entry point for 'ara list aspect'. Orchestrates discovery, analysis, and presentation.
    """
    # 1. Parse aspect types
    raw_type = getattr(args, "aspect_type", "") or ""
    if raw_type.lower() == "all":
        aspect_types = ["gui", "technology", "rules", "concept", "persona", "customer"]
    else:
        aspect_types = [t.strip() for t in raw_type.split(",") if t.strip()]
    
    if not aspect_types:
        aspect_types = ["gui", "technology", "rules", "concept", "persona", "customer"]

    # 2. Setup target context if any
    target_context = {
        "target_name": getattr(args, "target_name", None),
        "target_classifier": getattr(args, "target_classifier", None),
        "include_children": getattr(args, "include_children", False),
        "include_all_children": getattr(args, "include_all_children", False),
        "include_parent": getattr(args, "include_parent", False),
        "include_branch": getattr(args, "include_branch", False)
    }

    if target_context["target_name"] and target_context["target_classifier"]:
        from ara_cli.artefact_reader import ArtefactReader
        try:
            # Ensure classifier is a plain string (not a ClassifierEnum)
            raw_classifier = target_context["target_classifier"]
            classifier_str = raw_classifier.value if hasattr(raw_classifier, "value") else str(raw_classifier)
            target = ArtefactReader().read_artefact(
                classifier=classifier_str,
                artefact_name=target_context["target_name"]
            )
            target_context["artefact"] = {
                "title": target.title,
                "classifier": target.artefact_type,
                "file_path": target.file_path
            }
        except Exception:
            typer.echo(f"Artefact '{target_context['target_name']}' ({target_context['target_classifier']}) not found.")
            return

    # 3. Discovery
    discovery_service = AspectDiscoveryService()
    aspects = discovery_service.discover(aspect_types, target_context)

    if not aspects:
        typer.echo(f"No aspects of type '{', '.join(aspect_types)}' found.")
        return

    # 4. Analysis (LLM) - Summary and Conflict Check
    summary_text = None
    conflict_report = None
    
    # We only call LLM if requested (summary or conflict flags)
    if getattr(args, "summary", False):
        summary_text = process_aspect_llm_task(aspects, task_type="summary")
        
    if getattr(args, "check_conflicts", False):
        conflict_report = process_aspect_llm_task(aspects, task_type="conflict_check")

    # 5. Output Presentation
    
    # JSON Output (AI Agents prefer this)
    if getattr(args, "json_output", False):
        json_data = AspectPresenter.to_json(aspect_types, aspects, summary_text, conflict_report)
        print(json_data)
        return

    # Markdown Export
    if getattr(args, "export", False):
        export_name = f"{aspect_types[0]}.collection.md" if len(aspect_types) == 1 else "multi.collection.md"
        
        # Decide export directory
        if target_context.get("artefact"):
            target = target_context["artefact"]
            export_dir = os.path.join(os.path.dirname(target["file_path"]), f"{target['title']}.data")
            os.makedirs(export_dir, exist_ok=True)
            export_path = os.path.join(export_dir, export_name)
        else:
            export_path = export_name

        AspectExporter.export_to_markdown(", ".join(aspect_types), aspects, export_path, summary_text, conflict_report)
        
        # Show relative path in terminal for cleaner output
        rel_export_path = os.path.relpath(export_path, os.getcwd()).replace("\\", "/")
        typer.echo(f"Exported {len(aspects)} aspects to: ./{rel_export_path}")

    # Terminal Output (with optional summary streaming)
    if not getattr(args, "export", False) and not getattr(args, "json_output", False):
        if summary_text:
            typer.echo("\n--- AI Generated Summary ---")
            typer.echo(summary_text)
            typer.echo("---------------------------\n")
            
        AspectPresenter.to_terminal(aspects)
