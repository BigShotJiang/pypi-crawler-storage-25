from ara_cli.file_loaders.document_reader import DocumentReader


class PptxReader(DocumentReader):
    """Reader for PowerPoint files"""

    @staticmethod
    def _getActionImage(shape, MSO_SHAPE_TYPE):
        try:
            if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
                return shape.image.blob, shape.image.ext
            elif shape.is_placeholder and hasattr(shape, "image"):
                return shape.image.blob, shape.image.ext
        except Exception:
            pass
        return None, None

    @staticmethod
    def _get_shape_text(shape, slide):
        if not shape.has_text_frame:
            return []

        lines = []
        is_title = False
        try:
            if shape == slide.shapes.title:
                is_title = True
        except AttributeError:
            pass

        text_frame = shape.text_frame
        if is_title:
            lines.append(f"### {text_frame.text}")
        else:
            for paragraph in text_frame.paragraphs:
                text = paragraph.text.strip()
                if text:
                    lines.append(f"- {text}")
        return lines

    def read(self, extract_images: bool = False) -> str:
        from pptx import Presentation
        from pptx.enum.shapes import MSO_SHAPE_TYPE
        import io

        try:
            prs = Presentation(self.file_path)
            md_lines = []

            # Prepare image extraction if requested
            images_dir = None
            image_counter = 1
            image_descriptions = []

            if extract_images:
                images_dir = self.create_image_data_dir("pptx")

            def process_shape(shape):
                # Recursive function to handle groups and extract images
                if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
                    for sub_shape in shape.shapes:
                        process_shape(sub_shape)
                    return

                # Text extraction
                md_lines.extend(self._get_shape_text(shape, slide))

                # Image extraction
                if extract_images:
                    blob, ext = self._getActionImage(shape, MSO_SHAPE_TYPE)
                    if blob and ext:
                        try:
                            nonlocal image_counter
                            relative_path, description = self.save_and_describe_image(
                                blob, ext, images_dir, image_counter
                            )
                            image_desc_text = (
                                f"\nImage: {relative_path}\n[{description}]\n"
                            )
                            md_lines.append(image_desc_text)
                            image_descriptions.append(image_desc_text)
                            image_counter += 1
                        except Exception as img_err:
                            print(
                                f"Warning: Failed to extract image from slide {index+1}: {img_err}"
                            )

            for index, slide in enumerate(prs.slides):
                md_lines.append(f"## Slide {index + 1}")

                # Collect shapes and sort by top position
                shapes = sorted(
                    [s for s in slide.shapes], key=lambda x: (x.top or 0, x.left or 0)
                )

                for shape in shapes:
                    process_shape(shape)

                md_lines.append("\n---\n")

            return "\n".join(md_lines)

        except Exception as e:
            return f"Error reading PowerPoint file: {str(e)}"
