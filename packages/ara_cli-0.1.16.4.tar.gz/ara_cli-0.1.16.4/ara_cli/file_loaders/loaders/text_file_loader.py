import os
import re
import base64
import tempfile
from typing import Optional, Tuple
import requests
from charset_normalizer import from_path
from ara_cli.file_loaders.file_loader import FileLoader
from ara_cli.file_loaders.readers.markdown_reader import MarkdownReader


class TextFileLoader(FileLoader):
    """Loads text files"""

    def load(
        self,
        file_path: str,
        prefix: str = "",
        suffix: str = "",
        block_delimiter: str = "",
        extract_images: bool = False,
        **kwargs,
    ) -> bool:
        """Load text file with optional markdown image extraction"""

        is_md_file = file_path.lower().endswith(".md")

        if is_md_file and extract_images:
            reader = MarkdownReader(file_path)
            file_content = reader.read(extract_images=True).replace("\r\n", "\n")
        else:
            # Use charset-normalizer to detect encoding
            encoded_content = from_path(file_path).best()
            if not encoded_content:
                print(f"Failed to detect encoding for {file_path}")
                return False
            file_content = str(encoded_content).replace("\r\n", "\n")

        if block_delimiter:
            file_content = f"{block_delimiter}\n{file_content}\n{block_delimiter}"

        write_content = f"{prefix}{file_content}{suffix}\n"

        with open(self.chat.chat_name, "a", encoding="utf-8") as chat_file:
            chat_file.write(write_content)

        return True
