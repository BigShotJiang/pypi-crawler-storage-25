import os
from abc import ABC, abstractmethod
from typing import Tuple, Optional


class DocumentReader(ABC):
    """Abstract base class for document readers"""

    def __init__(self, file_path: str):
        self.file_path = file_path
        self.base_dir = os.path.dirname(file_path)

    @abstractmethod
    def read(self, extract_images: bool = False) -> str:
        """Read document and optionally extract images"""
        pass

    def create_image_data_dir(self, extension_suffix: str) -> str:
        """
        Create data directory for images with file extension suffix to avoid conflicts.

        Returns:
            str: Path to images directory
        """
        file_name_with_ext = os.path.splitext(os.path.basename(self.file_path))[
            0] + f"_{extension_suffix}"
        data_dir = os.path.join(self.base_dir, f"{file_name_with_ext}.data")
        images_dir = os.path.join(data_dir, "images")
        if not os.path.exists(images_dir):
            os.makedirs(images_dir)
        return images_dir

    def save_and_describe_image(
        self,
        image_data: bytes,
        image_format: str,
        save_dir: str,
        image_counter: int
    ) -> Tuple[str, str]:
        """
        Save image data and get its description from LLM.

        Returns:
            tuple: (relative_image_path, description)
        """
        from ara_cli.prompt_handler import describe_image

        # Save image
        image_filename = f"{image_counter}.{image_format}"
        image_path = os.path.join(save_dir, image_filename)

        with open(image_path, "wb") as image_file:
            image_file.write(image_data)

        # Get image description from LLM
        description = describe_image(image_path)

        # Get relative path
        relative_image_path = os.path.relpath(image_path, self.base_dir)

        return relative_image_path, description






