import os
from typing import Optional
from ara_cli.file_loaders.document_reader import DocumentReader
from ara_cli.file_loaders.readers.docx_reader import DocxReader
from ara_cli.file_loaders.readers.pdf_reader import PdfReader
from ara_cli.file_loaders.readers.odt_reader import OdtReader
from ara_cli.file_loaders.readers.excel_reader import ExcelReader
from ara_cli.file_loaders.readers.pptx_reader import PptxReader

class DocumentReaderFactory:
    """Factory for creating appropriate document readers"""

    @staticmethod
    def create_reader(file_path: str) -> Optional[DocumentReader]:
        """Create appropriate reader based on file extension"""
        _, ext = os.path.splitext(file_path)
        ext = ext.lower()

        readers = {
            '.docx': DocxReader,
            '.pdf': PdfReader,
            '.odt': OdtReader,
            '.xlsx': ExcelReader,
            '.xls': ExcelReader,
            '.pptx': PptxReader
        }

        reader_class = readers.get(ext)
        if reader_class:
            return reader_class(file_path)

        return None
