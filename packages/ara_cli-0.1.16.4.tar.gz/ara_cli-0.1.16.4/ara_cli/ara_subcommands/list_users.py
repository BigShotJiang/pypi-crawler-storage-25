import typer
from typing import Optional
from .common import (
    MockArgs,
    ClassifierArgument,
    ArtefactNameArgument,
    ClassifierOption,
    ClassifierEnum,
)
from ara_cli.ara_command_action import list_users_action


def list_users_main(
    classifier: Optional[str] = ClassifierArgument(
        "Classifier of the artefact", default=None
    ),
    artefact_name: Optional[str] = ArtefactNameArgument(
        "Name of the artefact", default=None
    ),
    json_output: bool = typer.Option(
        False, "-j", "--json/--no-json", help="Output users as JSON"
    ),
    include_classifier: Optional[ClassifierEnum] = ClassifierOption(
        "Show users for an artefact type", "--include-classifier"
    ),
    exclude_classifier: Optional[ClassifierEnum] = ClassifierOption(
        "Show users for an artefact type", "--exclude-classifier"
    ),
):
    """List users."""
    args = MockArgs(
        classifier=classifier,
        artefact_name=artefact_name,
        json=json_output,
        include_classifier=include_classifier.value if include_classifier else None,
        exclude_classifier=exclude_classifier.value if exclude_classifier else None,
    )
    list_users_action(args)


def register(parent: typer.Typer):
    help_text = "List users"
    parent.command(name="list-users", help=help_text)(list_users_main)
