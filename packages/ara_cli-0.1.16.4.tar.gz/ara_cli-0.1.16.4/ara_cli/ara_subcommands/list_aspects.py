import typer
import json as json_lib
from rich.console import Console
from rich.table import Table
from ara_cli.constants import VALID_ASPECTS

def list_aspects(
    json: bool = typer.Option(
        False,
        "-j",
        "--json",
        help="Output the available aspects as JSON.",
    ),
):
    """
    List all available aspect types that can be created.
    """
    console = Console()
    
    if json:
        console.print(json_lib.dumps({"aspects": VALID_ASPECTS}))
        return

    table = Table(title="Available Aspect Types")
    table.add_column("Aspect Name", style="cyan", no_wrap=True)

    for aspect in VALID_ASPECTS:
        table.add_row(aspect)

    console.print(table)
    
def register(app: typer.Typer):
    app.command(name="list-aspects", help="List available aspect types that can be created.")(
        list_aspects
    )
