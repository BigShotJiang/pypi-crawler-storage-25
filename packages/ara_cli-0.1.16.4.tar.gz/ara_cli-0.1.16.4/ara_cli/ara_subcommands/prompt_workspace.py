import typer
from ara_cli.update_config_prompt import update_artefact_config_prompt_files

def prompt_workspace_main(
    step: str = typer.Argument(..., help="Action: update")
):
    """
    Prompt interaction mode for workspace.
    """
    if step == "update":
        update_artefact_config_prompt_files(None, None, automatic_update=True)
    else:
        typer.echo(f"Error: Invalid step '{step}'. Only 'update' is supported for workspace.", err=True)
        raise typer.Exit(1)

def register(parent: typer.Typer):
    parent.command(name="prompt-workspace", help="Prompt interaction mode for workspace")(
        prompt_workspace_main
    )
