from typing import Optional, List, Dict, Any
from ara_cli.error_handler import AraError

class ListValidator:
    """
    Systematically validates the compatibility of 'ara list' flags.
    SOLID: Single Responsibility - Only handles validation logic.
    """
    
    def __init__(self, 
                 classifier: Any, 
                 artefact_name: Optional[str], 
                 aspect_type: Optional[str], 
                 **kwargs):
        self.classifier = classifier
        self.artefact_name = artefact_name
        self.aspect_type = aspect_type
        self.flags = kwargs

    def _check_missing_action_flag(self):
        """
        Ensures that if an artefact name is provided, an action flag is also present.
        """
        if self.artefact_name:
            action_flags = [
                self.aspect_type,
                self.flags.get("branch"),
                self.flags.get("children"),
                self.flags.get("all_children"),
                self.flags.get("data")
            ]
            if not any(action_flags):
                classifier_name = self.classifier.value if hasattr(self.classifier, 'value') else self.classifier
                raise AraError(
                    f"To list specific info for '{classifier_name} {self.artefact_name}', "
                    "you must provide one of: --children, --all-children, --branch, --data, or --aspect."
                )

    def validate(self):
        """Run all validation rules."""
        self._check_aspect_only_flags()
        self._check_regular_only_flags()
        self._check_exclusive_hierarchy_flags()
        self._check_hierarchy_context()
        self._check_missing_action_flag()
        self._check_extension_exclusivity()

    def _check_extension_exclusivity(self):
        """Validate that include and exclude extension options are mutually exclusive."""
        if self.flags.get("include_extension") and self.flags.get("exclude_extension"):
            raise AraError(
                "--include-extension/-i and --exclude-extension/-e are mutually exclusive"
            )

    def _check_aspect_only_flags(self):
        """Checks flags that MUST have --aspect."""
        aspect_only = {
            "--export": self.flags.get("export"),
            "--summary": self.flags.get("summary"),
            "--check-conflicts": self.flags.get("check_conflicts")
        }
        
        if not self.aspect_type:
            active = [name for name, val in aspect_only.items() if val]
            if active:
                raise AraError(
                    f"The following flags are ONLY supported with '--aspect': {', '.join(active)}.\n"
                    "Try: ara list --aspect all " + active[0]
                )

    def _check_regular_only_flags(self):
        """Checks flags that are incompatible with --aspect."""
        if self.aspect_type:
            incompatible = {
                "--data": self.flags.get("data"),
                "--include-extension": self.flags.get("include_extension"),
                "--exclude-extension": self.flags.get("exclude_extension")
            }
            active = [name for name, val in incompatible.items() if val]
            if active:
                raise AraError(
                    f"Flag(s) {', '.join(active)} cannot be used with '--aspect' mode."
                )

    def _check_exclusive_hierarchy_flags(self):
        """Prevents using multiple hierarchy flags simultaneously."""
        h_flags = {
            "--branch": self.flags.get("branch"),
            "--children": self.flags.get("children"),
            "--all-children": self.flags.get("all_children"),
            "--data": self.flags.get("data")
        }
        active = [name for name, val in h_flags.items() if val]
        if len(active) > 1:
            raise AraError(f"Mutually exclusive flags detected: {', '.join(active)}. Please use only one.")

    def _check_hierarchy_context(self):
        """
        Validates that hierarchy flags have necessary context (artefact name).
        """
        h_flags = {
            "--branch": self.flags.get("branch"),
            "--children": self.flags.get("children"),
            "--all-children": self.flags.get("all_children"),
            "--data": self.flags.get("data")
        }
        active_h = [name for name, val in h_flags.items() if val]

        if active_h and not self.artefact_name:
            classifier_name = self.classifier.value if hasattr(self.classifier, 'value') else self.classifier
            raise AraError(
                f"Flags {', '.join(active_h)} require a specific artefact name.\n"
                f"Example: ara list {classifier_name or 'feature'} <name> {active_h[0]}"
            )
