import typer
from ara_cli.error_handler import AraError
from typing import Optional, List, Tuple
from .common import MockArgs, ClassifierEnum, ClassifierArgument, ArtefactNameArgument
from ara_cli.completers import DynamicCompleters
from ara_cli.ara_command_action import list_action



def list_main(
    classifier: ClassifierEnum = ClassifierArgument(
        "The classifier of the artefact.", default=None
    ),
    artefact_name: str = ArtefactNameArgument(
        "The name of the artefact", default=None
    ),
    include_content: Optional[List[str]] = typer.Option(
        None,
        "-I",
        "--include-content",
        help="filter for files which include given content",
    ),
    exclude_content: Optional[List[str]] = typer.Option(
        None,
        "-E",
        "--exclude-content",
        help="filter for files which do not include given content",
    ),
    include_tags: Optional[List[str]] = typer.Option(
        None, "--include-tags", help="filter for files which include given tags"
    ),
    exclude_tags: Optional[List[str]] = typer.Option(
        None, "--exclude-tags", help="filter for files which do not include given tags"
    ),
    include_extension: Optional[List[str]] = typer.Option(
        None,
        "-i",
        "--include-extension",
        "--include-classifier",
        help="list of extensions to include in listing",
    ),
    exclude_extension: Optional[List[str]] = typer.Option(
        None,
        "-e",
        "--exclude-extension",
        "--exclude-classifier",
        help="list of extensions to exclude from listing",
    ),
    branch: bool = typer.Option(
        False,
        "-b",
        "--branch",
        help="List artefacts in the parent chain (requires classifier and artefact_name)",
    ),
    children: bool = typer.Option(
        False,
        "-c",
        "--children",
        help="List child artefacts (requires classifier and artefact_name)",
    ),
    all_children: bool = typer.Option(
        False,
        "-C",
        "--all-children",
        help="Recursively list all descendant artefacts down to leaf nodes as an indented tree (requires classifier and artefact_name)",
    ),
    data: bool = typer.Option(
        False,
        "-d",
        "--data",
        help="List file in the data directory (requires classifier and artefact_name)",
    ),
    export: bool = typer.Option(
        False,
        "--export",
        help="Export aspects to a compiled Markdown file (aspect only)",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output the results in JSON format (aspect only)",
    ),
    summary: bool = typer.Option(
        False,
        "--summary",
        help="Include an AI generated summary (aspect only)",
    ),
    aspect_type: Optional[str] = typer.Option(
        None,
        "-A",
        "--aspect",
        "--aspect-type",
        help="List/Export specific aspect breakdown files (e.g. gui, technology). Use '--aspect all' for everything.",
        autocompletion=DynamicCompleters.create_aspect_completer(),
    ),
    check_conflicts: bool = typer.Option(
        False,
        "--check-conflicts",
        help="Detect and report conflicts between aspects using LLM",
    ),
):
    """List files or aspect breakdown specifications.

    Examples:
        ara list feature my_feature --data
        ara list --include-extension .feature
        ara list userstory my_story --all-children
        ara list --aspect all
        ara list --aspect technology --export --summary
        ara list capability auth --aspect rules --children --json
    """
    # 1. Systematic Validation using SOLID ListValidator
    from ara_cli.ara_subcommands.list_validator import ListValidator

    validator = ListValidator(
        classifier=classifier,
        artefact_name=artefact_name,
        aspect_type=aspect_type,
        branch=branch,
        children=children,
        all_children=all_children,
        data=data,
        export=export,
        json_output=json_output,
        summary=summary,
        check_conflicts=check_conflicts,
        include_extension=include_extension,
        exclude_extension=exclude_extension,
    )
    validator.validate()

    # 2. Handle Aspect-specific listing (Only via flag)
    if aspect_type:
        from ara_cli.aspect_lister import list_aspect_action

        args = MockArgs(
            aspect_type=aspect_type,
            target_classifier=classifier,
            target_name=artefact_name,
            export=export,
            json_output=json_output,
            summary=summary,
            include_children=children,
            include_all_children=all_children,
            include_parent=branch,
            include_branch=False,
            check_conflicts=check_conflicts,
        )
        list_aspect_action(args)
        return

    # 3. Regular artefact listing logic
    args = MockArgs(
        classifier=classifier,
        artefact_name=artefact_name,
        branch=branch,
        children=children,
        all_children=all_children,
        data=data,
        include_extension=include_extension,
        exclude_extension=exclude_extension,
        json=json_output,
        include_content=include_content,
        exclude_content=exclude_content,
        include_tags=include_tags,
        exclude_tags=exclude_tags,
    )
    list_action(args)


def register(parent: typer.Typer):
    help_text = "List files with optional tags"
    parent.command(name="list", help=help_text)(list_main)
