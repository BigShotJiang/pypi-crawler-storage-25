import pytest
from unittest.mock import MagicMock, patch
from ara_cli.artefact_reader import ArtefactReader


@pytest.mark.parametrize("artefact_content, artefact_titles, expected_output", [
    ("Contributes to: parent_name Example", ["Example"], ("parent_name", "Example")),
    ("Contributes to parent_name Example", ["Example"], ("parent_name", "Example")),
    ("Contributes to : parent_name Feature", ["Example", "Feature"], ("parent_name", "Feature")),
    ("No contribution information here.", ["Example"], (None, None)),
    ("Contributes to : parent_name NotListedTitle", ["Example"], (None, None)),
])
def test_extract_parent_tree(artefact_content, artefact_titles, expected_output):
    with patch('ara_cli.classifier.Classifier.artefact_titles', return_value=artefact_titles):
        parent_name, parent_type = ArtefactReader.extract_parent_tree(artefact_content)
        assert (parent_name, parent_type) == expected_output


def _make_artefact(title, parent_name=None, parent_classifier=None):
    """Helper: create a mock Artefact with title and optional contribution."""
    from ara_cli.artefact_models.artefact_model import Artefact, Contribution

    artefact = MagicMock(spec=Artefact)
    artefact.title = title
    artefact._file_path = f"ara/{title}.{parent_classifier or 'task'}"
    if parent_name and parent_classifier:
        contribution = MagicMock()
        contribution.artefact_name = parent_name
        contribution.classifier = parent_classifier
        artefact.contribution = contribution
    else:
        artefact.contribution = None
    return artefact


class TestFindAllDescendants:
    """Tests for ArtefactReader.find_all_descendants()"""

    def test_no_children_returns_empty_list(self):
        """Leaf node: artefact has no children → empty result."""
        reader = ArtefactReader()
        classified_artefacts = {
            "epic": [_make_artefact("my_epic")],
            "feature": [_make_artefact("feat1", parent_name="other_epic", parent_classifier="epic")],
        }
        with patch.object(reader, "read_artefacts", return_value=classified_artefacts):
            result = reader.find_all_descendants("my_epic", "epic")
        assert result == []

    def test_single_level_children(self):
        """Artefact has two direct children, no deeper levels."""
        reader = ArtefactReader()
        feature1 = _make_artefact("feat1", parent_name="my_epic", parent_classifier="epic")
        feature1._file_path = "ara/feat1.feature"
        feature2 = _make_artefact("feat2", parent_name="my_epic", parent_classifier="epic")
        feature2._file_path = "ara/feat2.feature"
        classified_artefacts = {
            "epic": [_make_artefact("my_epic")],
            "feature": [feature1, feature2],
        }
        with patch.object(reader, "read_artefacts", return_value=classified_artefacts):
            result = reader.find_all_descendants("my_epic", "epic")

        titles = [(a.title, c, d) for a, c, d in result]
        assert len(titles) == 2
        assert all(d == 0 for _, _, d in result), "Direct children should have depth 0"
        assert {t for t, _, _ in titles} == {"feat1", "feat2"}

    def test_multi_level_descendants(self):
        """Two-level tree: epic → feature → task."""
        reader = ArtefactReader()
        feature = _make_artefact("feat1", parent_name="my_epic", parent_classifier="epic")
        feature._file_path = "ara/feat1.feature"
        task = _make_artefact("task1", parent_name="feat1", parent_classifier="feature")
        task._file_path = "ara/task1.task"
        classified_artefacts = {
            "epic": [_make_artefact("my_epic")],
            "feature": [feature],
            "task": [task],
        }
        with patch.object(reader, "read_artefacts", return_value=classified_artefacts):
            result = reader.find_all_descendants("my_epic", "epic")

        assert len(result) == 2
        depths = {a.title: d for a, _, d in result}
        assert depths["feat1"] == 0
        assert depths["task1"] == 1

    def test_cycle_protection(self):
        """Circular contribution references should not cause infinite recursion."""
        reader = ArtefactReader()
        # A contributes to B, B contributes to A
        art_a = _make_artefact("a", parent_name="b", parent_classifier="task")
        art_a._file_path = "ara/a.task"
        art_b = _make_artefact("b", parent_name="a", parent_classifier="task")
        art_b._file_path = "ara/b.task"
        classified_artefacts = {
            "task": [art_a, art_b],
        }
        with patch.object(reader, "read_artefacts", return_value=classified_artefacts):
            # Should complete without RecursionError
            result = reader.find_all_descendants("a", "task")
        assert isinstance(result, list)

    def test_classified_artefacts_read_once(self):
        """read_artefacts() is called only once even for deep trees."""
        reader = ArtefactReader()
        feature = _make_artefact("feat1", parent_name="my_epic", parent_classifier="epic")
        feature._file_path = "ara/feat1.feature"
        task = _make_artefact("task1", parent_name="feat1", parent_classifier="feature")
        task._file_path = "ara/task1.task"
        classified_artefacts = {
            "epic": [_make_artefact("my_epic")],
            "feature": [feature],
            "task": [task],
        }
        with patch.object(reader, "read_artefacts", return_value=classified_artefacts) as mock_read:
            reader.find_all_descendants("my_epic", "epic")
        mock_read.assert_called_once()