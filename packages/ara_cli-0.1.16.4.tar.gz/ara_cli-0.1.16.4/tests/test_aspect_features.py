import pytest
import os
import json
from unittest.mock import MagicMock, patch
from ara_cli.aspect_services.discovery import AspectDiscoveryService
from ara_cli.aspect_services.presenter import AspectPresenter
from ara_cli.aspect_lister import list_aspect_action

class MockArgs:
    def __init__(self, **kwargs):
        self.aspect_type = kwargs.get("aspect_type", "gui")
        self.export = kwargs.get("export", False)
        self.json_output = kwargs.get("json_output", False)
        self.summary = kwargs.get("summary", False)
        self.check_conflicts = kwargs.get("check_conflicts", False)
        self.target_name = kwargs.get("target_name", None)
        self.target_classifier = kwargs.get("target_classifier", None)
        self.include_children = kwargs.get("include_children", False)

@pytest.fixture
def mock_aspect_data():
    return [
        {
            "aspect_type": "gui",
            "filename": "gui.md",
            "aspect_path": "/root/ara/features/f1.data/gui.md",
            "artefact_name": "f1",
            "artefact_classifier": "feature",
            "artefact_path": "/root/ara/features/f1.feature"
        }
    ]

def test_discovery_rules_and_depth_limitation(tmp_path):
    """
    Ensures that discovery finds correct aspects at the right depth and filters correctly.
    """
    ara_root = tmp_path / "ara"
    ara_root.mkdir()

    # 1. Correct structure: ara/features/login.data/gui.md
    feature_dir = ara_root / "features"
    feature_dir.mkdir()
    login_data = feature_dir / "login.data"
    login_data.mkdir()
    (login_data / "gui.md").write_text("correct aspect")
    (login_data / "gui_exploration.md").write_text("should be ignored")
    
    # 2. Nested data (should be ignored): ara/features/login.data/prompt.data/gui.md
    nested_data = login_data / "prompt.data"
    nested_data.mkdir()
    (nested_data / "gui.md").write_text("too deep")
    
    # 3. Example directory (unclassified but valid): ara/examples/test_script.data/technology.md
    example_dir = ara_root / "examples"
    example_dir.mkdir()
    test_example_data = example_dir / "test_script.data"
    test_example_data.mkdir()
    (test_example_data / "technology.md").write_text("example technology")
    
    # 4. Hidden directory (should be ignored): ara/.hidden/secret.data/gui.md
    hidden_dir = ara_root / ".hidden"
    hidden_dir.mkdir()
    secret_data = hidden_dir / "secret.data"
    secret_data.mkdir()
    (secret_data / "gui.md").write_text("hidden")

    # Mock FileClassifier to recognize 'login' as a feature
    mock_classified = {
        "feature": [{"title": "login", "file_path": str(feature_dir / "login.feature")}]
    }

    with patch('ara_cli.directory_navigator.DirectoryNavigator.find_ara_directory_root', return_value=str(ara_root)), \
         patch('ara_cli.file_classifier.FileClassifier.classify_files', return_value=mock_classified):
        
        service = AspectDiscoveryService()
        
        # Test GUI discovery
        gui_aspects = service.discover(["gui"])
        gui_paths = [os.path.normpath(a["aspect_path"]) for a in gui_aspects]
        
        # Check that we found login/gui.md
        assert any("login.data" in p and "gui.md" in p for p in gui_paths)
        
        # Check that we did NOT find the nested prompt.data/gui.md
        assert not any("prompt.data" in p for p in gui_paths)
        
        # Check exploration filter
        assert not any("gui_exploration.md" in p for p in gui_paths)
        
        # Check hidden dir filter
        assert not any(".hidden" in p for p in gui_paths)
        
        # Test Technology discovery (Example folder)
        tech_aspects = service.discover(["technology"])
        assert len(tech_aspects) == 1
        assert tech_aspects[0]["artefact_classifier"] == "example"
        assert tech_aspects[0]["artefact_name"] == "test_script"

def test_rich_json_output_structure(mock_aspect_data):
    summary = "System overview"
    conflicts = "No conflicts found"
    
    json_str = AspectPresenter.to_json(["gui"], mock_aspect_data, summary, conflicts)
    data = json.loads(json_str)
    
    assert "metadata" in data
    assert data["metadata"]["count"] == 1
    assert data["analysis"]["summary"] == "System overview"
    assert data["analysis"]["conflicts"] == "No conflicts found"
    assert len(data["results"]) == 1

@patch('ara_cli.aspect_lister.process_aspect_llm_task')
@patch('ara_cli.aspect_services.discovery.AspectDiscoveryService.discover')
def test_list_aspect_action_integration(mock_discover, mock_llm, capsys, mock_aspect_data):
    mock_discover.return_value = mock_aspect_data
    mock_llm.return_value = "AI Response"
    
    args = MockArgs(json_output=True, summary=True, check_conflicts=True)
    list_aspect_action(args)
    
    captured = capsys.readouterr()
    json_data = json.loads(captured.out)
    
    assert json_data["metadata"]["has_summary"] is True
    assert json_data["metadata"]["has_conflicts"] is True
    assert json_data["analysis"]["summary"] == "AI Response"
    assert mock_llm.call_count == 2 

def test_tree_sorting_order():
    aspects = [
        {"artefact_classifier": "userstory", "artefact_name": "story1", "aspect_path": "p1"},
        {"artefact_classifier": "feature", "artefact_name": "feature1", "aspect_path": "p2"},
        {"artefact_classifier": "businessgoal", "artefact_name": "goal1", "aspect_path": "p3"}
    ]
    
    from ara_cli.classifier import Classifier
    with patch('ara_cli.classifier.Classifier.ordered_classifiers', return_value=["businessgoal", "feature", "userstory"]):
        AspectPresenter.to_terminal(aspects)
        
    # Check sorting order in memory (to_terminal modifies the list in place)
    assert aspects[0]["artefact_name"] == "goal1"
    assert aspects[1]["artefact_name"] == "feature1"
    assert aspects[2]["artefact_name"] == "story1"
