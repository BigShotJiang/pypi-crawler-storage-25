import pytest
from ara_cli.ara_subcommands.list_validator import ListValidator
from ara_cli.error_handler import AraError

def test_list_validator_exclusive_extensions():
    validator = ListValidator(
        classifier="feature",
        artefact_name=None,
        aspect_type=None,
        include_extension=[".feature"],
        exclude_extension=[".task"]
    )
    with pytest.raises(AraError) as excinfo:
        validator.validate()
    assert "--include-extension/-i and --exclude-extension/-e are mutually exclusive" in str(excinfo.value)

def test_list_validator_exclusive_hierarchy():
    validator = ListValidator(
        classifier="feature",
        artefact_name="my_feature",
        aspect_type=None,
        branch=True,
        children=True
    )
    with pytest.raises(AraError) as excinfo:
        validator.validate()
    assert "Mutually exclusive flags detected" in str(excinfo.value)

def test_list_validator_missing_artefact_name():
    validator = ListValidator(
        classifier="feature",
        artefact_name=None,
        aspect_type=None,
        branch=True
    )
    with pytest.raises(AraError) as excinfo:
        validator.validate()
    assert "require a specific artefact name" in str(excinfo.value)

def test_list_validator_aspect_only_flags():
    validator = ListValidator(
        classifier="feature",
        artefact_name=None,
        aspect_type=None,
        export=True
    )
    with pytest.raises(AraError) as excinfo:
        validator.validate()
    assert "ONLY supported with '--aspect'" in str(excinfo.value)

def test_list_validator_valid_case():
    validator = ListValidator(
        classifier="feature",
        artefact_name="my_feature",
        aspect_type="technology",
        summary=True,
        export=True
    )
    # Should not raise any error
    validator.validate()
