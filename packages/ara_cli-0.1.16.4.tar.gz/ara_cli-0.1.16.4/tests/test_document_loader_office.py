import unittest
from unittest.mock import MagicMock, patch, ANY
import sys
import os

# Mock the new dependencies to avoid import errors during test collection if they are not installed
sys.modules["pandas"] = MagicMock()
sys.modules["openpyxl"] = MagicMock()
sys.modules["pptx"] = MagicMock()
sys.modules["pptx.presentation"] = MagicMock()
sys.modules["pptx.enum.shapes"] = MagicMock()

from ara_cli.file_loaders.readers.excel_reader import ExcelReader
from ara_cli.file_loaders.readers.pptx_reader import PptxReader
from ara_cli.file_loaders.factories.document_reader_factory import DocumentReaderFactory


class TestExcelReader(unittest.TestCase):
    @patch("pandas.read_excel")
    def test_read_excel_success(self, mock_read_excel):
        # Setup mock dataframe
        mock_df = MagicMock()
        mock_df.empty = False
        mock_df.to_markdown.return_value = "| Col1 | Col2 |\n|---|---|\n| Val1 | Val2 |"
        mock_df.fillna.return_value = mock_df

        # Setup read_excel return value (dict of sheets)
        mock_read_excel.return_value = {"Sheet1": mock_df}

        reader = ExcelReader("test.xlsx")
        content = reader.read()

        self.assertIn("### Sheet: Sheet1", content)
        self.assertIn("| Col1 | Col2 |", content)
        mock_read_excel.assert_called_once_with("test.xlsx", sheet_name=None)
        mock_df.to_markdown.assert_called_once()

    @patch("pandas.read_excel")
    def test_read_excel_empty_sheet(self, mock_read_excel):
        mock_df = MagicMock()
        mock_df.empty = True

        mock_read_excel.return_value = {"SheetEmpty": mock_df}

        reader = ExcelReader("test.xlsx")
        content = reader.read()

        self.assertIn("### Sheet: SheetEmpty", content)
        self.assertIn("_Empty Sheet_", content)

    @patch("pandas.read_excel")
    def test_read_excel_error(self, mock_read_excel):
        mock_read_excel.side_effect = Exception("File not found")

        reader = ExcelReader("test.xlsx")
        content = reader.read()

        self.assertIn("Error reading Excel file: File not found", content)


class TestPptxReader(unittest.TestCase):
    @patch("pptx.Presentation")
    def test_read_pptx_success(self, mock_presentation):
        # Setup mock presentation
        mock_prs = MagicMock()
        mock_slide = MagicMock()

        # Setup shapes
        mock_shape_title = MagicMock()
        mock_shape_title.has_text_frame = True
        mock_shape_title.text_frame.text = "Slide Title"
        mock_shape_title.top = 0
        mock_shape_title.left = 0

        mock_shape_content = MagicMock()
        mock_shape_content.has_text_frame = True
        mock_shape_content.text_frame.paragraphs = [
            MagicMock(text="Bullet 1"),
            MagicMock(text="Bullet 2"),
        ]
        mock_shape_content.top = 100
        mock_shape_content.left = 0

        # slide.shapes must be a mock that is iterable AND has a title attribute
        mock_shapes = MagicMock()
        mock_shapes.__iter__.return_value = [mock_shape_title, mock_shape_content]
        mock_shapes.title = mock_shape_title

        mock_slide.shapes = mock_shapes

        mock_slide.shapes = mock_shapes
        mock_prs.slides = [mock_slide]

        mock_presentation.return_value = mock_prs

        reader = PptxReader("test.pptx")
        content = reader.read()

        self.assertIn("## Slide 1", content)
        self.assertIn("### Slide Title", content)
        self.assertIn("- Bullet 1", content)
        self.assertIn("- Bullet 2", content)

    @patch("pptx.Presentation")
    def test_read_pptx_with_images(self, mock_presentation):
        from pptx.enum.shapes import MSO_SHAPE_TYPE

        # Setup mock presentation
        mock_prs = MagicMock()
        mock_slide = MagicMock()

        # Setup shapes
        mock_shape_image = MagicMock()
        mock_shape_image.has_text_frame = False
        mock_shape_image.shape_type = MSO_SHAPE_TYPE.PICTURE
        mock_shape_image.image.blob = b"fake_image_data"
        mock_shape_image.image.ext = "png"
        mock_shape_image.top = 0
        mock_shape_image.left = 0

        # Mock shapes as list is fine here if we don't access .title, but cleaner to be consistent if code checks .title
        mock_shapes = MagicMock()
        mock_shapes.__iter__.return_value = [mock_shape_image]
        # If code checks slide.shapes.title, we should ensure it doesn't crash or has it
        # The code does: try: if shape == slide.shapes.title: ... except AttributeError: ...
        # So it handles missing title attribute.

        mock_slide.shapes = mock_shapes
        mock_prs.slides = [mock_slide]
        mock_presentation.return_value = mock_prs

        # Mock create_image_data_dir and save_and_describe_image
        with patch.object(
            PptxReader, "create_image_data_dir"
        ) as mock_create_dir, patch.object(
            PptxReader, "save_and_describe_image"
        ) as mock_save_describe:

            mock_create_dir.return_value = "fake/dir"
            mock_save_describe.return_value = (
                "fake/dir/1.png",
                "A fake image description",
            )

            reader = PptxReader("test.pptx")
            content = reader.read(extract_images=True)

            self.assertIn("## Slide 1", content)
            self.assertIn("Image: fake/dir/1.png", content)
            self.assertIn("[A fake image description]", content)

    @patch("pptx.Presentation")
    def test_read_pptx_groups_and_placeholders(self, mock_presentation):
        from pptx.enum.shapes import MSO_SHAPE_TYPE

        mock_prs = MagicMock()
        mock_slide = MagicMock()

        # 1. Group Shape containing an image
        mock_group = MagicMock()
        mock_group.shape_type = MSO_SHAPE_TYPE.GROUP

        mock_sub_image = MagicMock()
        mock_sub_image.shape_type = MSO_SHAPE_TYPE.PICTURE
        mock_sub_image.image.blob = b"group_img"
        mock_sub_image.image.ext = "jpg"

        mock_group.shapes = [mock_sub_image]
        mock_group.top = 0
        mock_group.left = 0

        # 2. Placeholder with image
        mock_placeholder = MagicMock()
        mock_placeholder.shape_type = 0  # Not PICTURE
        mock_placeholder.is_placeholder = True
        mock_placeholder.image.blob = b"place_img"
        mock_placeholder.image.ext = "png"
        mock_placeholder.top = 100
        mock_placeholder.left = 0

        # 3. Shape that raises error on image access (code robustness check)
        mock_broken_image = MagicMock()
        mock_broken_image.shape_type = MSO_SHAPE_TYPE.PICTURE
        type(mock_broken_image.image).blob = unittest.mock.PropertyMock(
            side_effect=Exception("Corrupt")
        )
        mock_broken_image.top = 200
        mock_broken_image.left = 0

        # 4. Shape with text that looks like a title but raises AttributeError (line 47 coverage)
        mock_title_ish = MagicMock()
        mock_title_ish.has_text_frame = True
        mock_title_ish.text_frame.text = "A Title"
        mock_title_ish.text_frame.paragraphs = [MagicMock(text="A Title")]
        mock_title_ish.is_placeholder = (
            False  # Important: default valid MagicMock is truthy!
        )
        # Ensure checking slide.shapes.title raises AttributeError
        mock_slide.shapes.title = unittest.mock.PropertyMock(
            side_effect=AttributeError("No title")
        )
        mock_title_ish.top = 300
        mock_title_ish.left = 0

        # Configure slide shapes iteration
        mock_slide.shapes.__iter__.return_value = [
            mock_group,
            mock_placeholder,
            mock_broken_image,
            mock_title_ish,
        ]

        mock_prs.slides = [mock_slide]
        mock_presentation.return_value = mock_prs

        with patch.object(
            PptxReader, "create_image_data_dir", return_value="dir"
        ), patch.object(
            PptxReader, "save_and_describe_image", return_value=("path", "desc")
        ):

            reader = PptxReader("test.pptx")
            # Force AttributeError on slide.shapes.title access during loop
            # The code does: `if shape == slide.shapes.title:`
            # We need checking `slide.shapes.title` to fail
            type(mock_slide.shapes).title = unittest.mock.PropertyMock(
                side_effect=AttributeError
            )

            content = reader.read(extract_images=True)

            # Should match group image
            # Should match placeholder image
            # Should handle broken image gracefully (print warning)
            # Should handle title attribute error (continue)

            # Since save_and_describe_image is mocked, we just check count or content existence
            # We expect 2 valid images (group + placeholder)
            self.assertEqual(content.count("Image: path"), 2)
            # Since AttributeError on title check, correct behavior is falling back to paragraph iteration
            self.assertIn("- A Title", content)

    @patch("pptx.Presentation")
    def test_read_pptx_top_level_error(self, mock_presentation):
        mock_presentation.side_effect = Exception("File corrupt")
        reader = PptxReader("test.pptx")
        content = reader.read()
        self.assertEqual(content, "Error reading PowerPoint file: File corrupt")


class TestDocumentReaderFactory(unittest.TestCase):
    def test_create_reader(self):
        from ara_cli.file_loaders.readers.docx_reader import DocxReader

        self.assertIsInstance(
            DocumentReaderFactory.create_reader("test.xlsx"), ExcelReader
        )
        self.assertIsInstance(
            DocumentReaderFactory.create_reader("test.pptx"), PptxReader
        )
        self.assertIsInstance(
            DocumentReaderFactory.create_reader("test.DOCX"), DocxReader
        )


if __name__ == "__main__":
    unittest.main()
