# clean-paste

Clipboard cleaning and formatting toolkit.

Visit [cleanpaste.org](https://www.cleanpaste.org/) for more information.
