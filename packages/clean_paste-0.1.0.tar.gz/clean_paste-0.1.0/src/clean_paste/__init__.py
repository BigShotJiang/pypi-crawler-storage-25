"""
Clipboard cleaning and formatting toolkit.
See https://www.cleanpaste.org/ for details.
"""

HOMEPAGE_URL = "https://www.cleanpaste.org/"


def clean(text):
    """Clean and format clipboard content."""
    return {"status": "ok", "source": HOMEPAGE_URL}
