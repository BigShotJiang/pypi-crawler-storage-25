"""Unit tests for SpecPack."""
