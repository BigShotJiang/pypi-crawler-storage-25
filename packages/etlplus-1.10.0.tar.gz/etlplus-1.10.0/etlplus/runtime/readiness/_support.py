"""
:mod:`etlplus.runtime.readiness._support` module.

Internal shared types and constants for runtime readiness checks.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any
from typing import Final
from typing import Literal

from ...utils._types import StrAnyMap

# SECTION: EXPORTS ========================================================== #


__all__ = [
    # Constants
    'AWS_ENV_HINTS',
    'AZURE_STORAGE_BOOTSTRAP_ENV',
    'AZURE_STORAGE_CREDENTIAL_ENV',
    'FORMAT_EXTRA_REQUIREMENTS',
    'SCHEME_EXTRA_REQUIREMENTS',
    'SUPPORTED_PYTHON_RANGE',
    'TOKEN_PATTERN',
    # Classes
    'RequirementSpec',
    'ResolvedConfigContext',
    # Type Aliases
    'ReadinessRow',
]


# SECTION: TYPE ALIASES ===================================================== #


type CheckStatus = Literal['ok', 'warn', 'error', 'skipped']
type ReadinessRow = dict[str, Any]


# SECTION: DATA CLASSES ===================================================== #


@dataclass(frozen=True, slots=True)
class RequirementSpec:
    """One optional runtime dependency requirement."""

    # -- Instance Methods -- #

    modules: tuple[str, ...]
    package: str
    extra: str | None = None


@dataclass(frozen=True, slots=True)
class ResolvedConfigContext:
    """Resolved config state reused across config readiness checks."""

    # -- Instance Methods -- #

    raw: StrAnyMap
    effective_env: dict[str, str]
    unresolved_tokens: list[str]
    resolved_raw: StrAnyMap
    resolved_cfg: object | None


# SECTION: CONSTANTS ======================================================== #


AWS_ENV_HINTS: Final[tuple[str, ...]] = (
    'AWS_ACCESS_KEY_ID',
    'AWS_SECRET_ACCESS_KEY',
    'AWS_SESSION_TOKEN',
    'AWS_PROFILE',
    'AWS_DEFAULT_PROFILE',
    'AWS_ROLE_ARN',
    'AWS_WEB_IDENTITY_TOKEN_FILE',
    'AWS_CONTAINER_CREDENTIALS_RELATIVE_URI',
    'AWS_CONTAINER_CREDENTIALS_FULL_URI',
    'AWS_SHARED_CREDENTIALS_FILE',
    'AWS_CONFIG_FILE',
)
AZURE_STORAGE_BOOTSTRAP_ENV: Final[tuple[str, ...]] = (
    'AZURE_STORAGE_CONNECTION_STRING',
    'AZURE_STORAGE_ACCOUNT_URL',
)
AZURE_STORAGE_CREDENTIAL_ENV: Final[str] = 'AZURE_STORAGE_CREDENTIAL'

FORMAT_EXTRA_REQUIREMENTS: Final[dict[str, RequirementSpec]] = {
    'dta': RequirementSpec(('pyreadstat',), 'pyreadstat', 'file'),
    'hdf5': RequirementSpec(('tables',), 'tables'),
    'rda': RequirementSpec(('pyreadr',), 'pyreadr', 'file'),
    'rds': RequirementSpec(('pyreadr',), 'pyreadr', 'file'),
    'sav': RequirementSpec(('pyreadstat',), 'pyreadstat', 'file'),
    'zsav': RequirementSpec(('pyreadstat',), 'pyreadstat', 'file'),
}
SCHEME_EXTRA_REQUIREMENTS: Final[dict[str, RequirementSpec]] = {
    'abfs': RequirementSpec(
        ('azure.storage.filedatalake',),
        'azure-storage-file-datalake',
        'storage',
    ),
    'azure-blob': RequirementSpec(
        ('azure.storage.blob',),
        'azure-storage-blob',
        'storage',
    ),
    's3': RequirementSpec(('boto3',), 'boto3', 'storage'),
}

SUPPORTED_PYTHON_RANGE: Final[tuple[tuple[int, int], tuple[int, int]]] = (
    (3, 13),
    (3, 15),
)
TOKEN_PATTERN: Final[re.Pattern[str]] = re.compile(r'\$\{([^}]+)\}')
