import os
import xml.etree.ElementTree as ET
import csv
import gzip
import datetime
from pathlib import Path

import basic_svg_chart

this_dir = Path(__file__).resolve().parent
dir_real_examples = this_dir.parent / "examples"

def get_data():
    x = []
    y = []

    dataset = dir_real_examples / "data/meteo.csv.gz"
    
    # https://stackoverflow.com/questions/6451655/how-to-convert-python-datetime-dates-to-decimal-float-years
    def year_fraction(date):
        elapsed_seconds = (date - datetime.datetime(date.year, 1, 1)).total_seconds()
        year_length = (datetime.date(date.year + 1, 1, 1) - datetime.date(date.year, 1, 1)).total_seconds()
        return date.year + (elapsed_seconds / year_length)
    
    with gzip.open(dataset, mode = "rt") as f:
        reader = csv.DictReader(f)
        # i = 0
        for row in reader:
            date = row["AAAAMMJJHH"]
            x.append(year_fraction(datetime.datetime.strptime(date,"%Y%m%d%H"))) # .timestamp()
            y.append(float(row["T"]))
            # i += 1
            # if i == 100:
                # break

    return x, y
    
def test_meteo(tmp_path):
    x, y = get_data()
    out_file = tmp_path / "my_chart.svg"
    
    root = basic_svg_chart.chart(
        chart_type = ("line"),
        circles = None,
        x = x,
        y = y,
        y_min = -20,
        y_max = 40,
        y_unit = "°C",
        y_ticks_interval = 10,
        x_ticks = range(1880, 2021, 10),
        # x_ticks = [1872] + list(range(1880, 2021, 10)) + [2026],
        x_ticks_format = "{x:.0f}",
        tooltip_type = None,
        legend_position = None,
        width = 1600,
        height = 754,
        css = ("g.series > path {stroke-width: 1px;}", "g.series > path:hover {stroke-width: 1px;}"),
        colors = "deepskyblue",
        lang = "fr",
        title = "Température horaire à la station météo Paris-Montsouris",
        notes = "Source : <a href='https://www.data.gouv.fr/datasets/donnees-climatologiques-de-base-horaires'>Météo-France</a>, données extraites le 11/03/2026.",
        pretty = True,
        output = str(out_file)
    )

    assert isinstance(root, ET.Element)
    assert out_file.is_file()
    assert round(os.path.getsize(out_file) / 1e6) == 10
    content = out_file.read_text(encoding = "utf-8")
    assert len(content) > 1e7
    num_lines = sum(1 for _ in open(out_file))
    assert num_lines == 113
    assert content.startswith("<?xml version='1.0' encoding='UTF-8'?>\n<svg")
    assert "path" in content
    assert content.endswith("</svg>")

