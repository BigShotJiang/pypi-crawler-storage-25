import os
import re
import xml.etree.ElementTree as ET
from types import SimpleNamespace
import random
import string

import pytest

import basic_svg_chart as bsc

# width and height for a 500x500 chart area
W500 = 500 + 29 + 20
H500 = 500 + 27 + 34.5

def test_chart_string_output():
    svg = bsc.chart(x = [0, 1, 2], y = [[10, 20, 30], [15, 8, 22], [None, 15, 5]])
    assert isinstance(svg, str)
    assert svg.startswith('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1200 800" style="font-size: 15px" role="img" width="1200" height="800"><style type="text/css">')
    assert "a {fill: darkblue;} a:hover {text-decoration: underline;}" in svg
    assert '<defs><filter id="bg_val" x="0" width="1" y="0.1" height="0.8"><feFlood' in svg
    assert '<g id="position" transform="translate(38, 27)"><g id="ordinate"><line stroke-width="2" stroke-linecap="square" x1="0" x2="0"' in svg
    assert '<g id="series_plots"><g class="series color1" id="series1"><title>Data series 1</title><path stroke-width="3" stroke-linejoin="round" d="M' in svg
    assert 'class="hide">22</text>' in svg
    assert 'class="hide">5</text><g class="legend" id="legend3"><line stroke-width="5"' in svg
    assert svg.endswith('Data series 3</text></g></g></g></g></svg>')


def test_chart_etree_output():
    root = bsc.chart(x = [0, 1, 2], y = [[10, 20, 30], [15, 8, 22], [None, 15, 5]], output = "etree")
    assert isinstance(root, ET.Element)
    assert root.tag == "svg"
    assert root.attrib["width"] == "1200"
    assert len(root) == 4


def test_chart_write_file(tmp_path):
    out_file = tmp_path / "my_chart.svg"
    root = bsc.chart(x = range(100), y = range(100), pretty = True, output = str(out_file))
    assert isinstance(root, ET.Element)
    assert out_file.is_file()
    assert os.path.getsize(out_file) > 10000
    content = out_file.read_text(encoding = "utf-8")
    assert len(content) > 10000
    num_lines = sum(1 for _ in open(out_file))
    assert num_lines > 200
    assert content.startswith("<?xml version='1.0' encoding='UTF-8'?>\n<svg")
    assert content.endswith("</svg>")


def test_line_chart():
    svg = bsc.chart(x = range(100), y = range(100), tooltip_type = None)
    svg2 = bsc.line_chart(x = range(100), y = range(100), tooltip_type = None)
    assert svg == svg2
    assert "<circle " not in svg
    regex = re.compile(r'<path stroke-width="3" stroke-linejoin="round" d="[0-9ML\,\. ]+" fill="none" />')
    assert bool(regex.search(svg))


def test_scatter_chart():
    svg = bsc.chart(chart_type = "scatter", x = range(100), y = range(100))
    svg2 = bsc.scatter_chart(x = range(100), y = range(100))
    assert "<circle " in svg
    assert "<path " not in svg
    assert svg == svg2


def test_scatter_line_chart():
    svg = bsc.chart(chart_type = "line+scatter", x = range(100), y = range(100), tooltip_type = None)
    svg2 = bsc.scatter_line_chart(x = range(100), y = range(100), tooltip_type = None)
    assert svg == svg2
    assert "<circle " in svg
    assert "<path " in svg


def test_bar_chart():
    svg = bsc.chart(chart_type = "bar", x = range(100), y = range(100), background_color = None)
    svg2 = bsc.bar_chart(x = range(100), y = range(100), background_color = None)
    assert svg == svg2
    assert "<rect " in svg
    assert "<circle " not in svg
    assert "<path " not in svg
    assert bool(re.search(r"<g id=\"series_plots\"><g[^>]+><title>[^<]+</title>(<rect [^>]+/><text[^>]*class=\"hide\"[^>]*>[0-9]+</text>){99}", svg))


def test_box_plot_chart():
    svg = bsc.chart(chart_type = "box plot", x = ["Box plot"], y = range(5), background_color = None)
    svg2 = bsc.box_plot_chart(x = ["Box plot"], y = range(5), background_color = None)
    assert svg == svg2
    assert "<polyline " in svg
    assert "<rect " not in svg
    assert "<path " not in svg


def test_title():
    svg = bsc.chart(x = range(100), y = range(100), title = "Identity function")
    assert isinstance(svg, str)
    assert svg.startswith("<svg")
    assert "<title id=\"title\">Identity function</title>" in svg
    assert bool(re.search(r"<text class=\"title\"[^>]+>Identity function</text>", svg))


def test_desc():
    svg = bsc.chart(x = range(10), y = range(10), desc = "Line chart 📈 representing y values for x between 0 and 9.")
    assert isinstance(svg, str)
    assert svg.startswith("<svg")
    assert "<desc id=\"description\">Line chart 📈 representing y values for x between 0 and 9.</desc>" in svg
    assert 'aria-describedby="description"' in svg


def test_x_list_integers():
    svg = bsc.chart(x = range(6), y = range(6), width = W500, height = H500, legend_position = None)

    regex = re.compile(r'<svg.+<g id="position" transform="translate\(29, 27\)">.+<g id="series_plots"><g class="series color1" id="series1"><title>Data series 1</title>.+</svg>')
    assert bool(regex.match(svg))
    assert '<path stroke-width="3" stroke-linejoin="round" d="M 0,500 L 100,400 L 200,300 L 300,200 L 400,100 L 500,0' in svg
    
    for x_i in range(6):
        regex = re.compile(f'<circle r="4" cx="{x_i * 100}"[^>]+ /><text x="{x_i * 100}"[^>]+>{x_i}</text>')
        assert bool(regex.search(svg))


def test_x_list_doubles():
    x = [0, 1.5, 4.0, 2.5, 5, 3.01]
    svg = bsc.chart(x = x, y = range(6), width = W500, height = H500, legend_position = None)

    regex = re.compile(r'<svg.+<g id="position" transform="translate\(29, 27\)">.+<g id="series_plots"><g class="series color1" id="series1"><title>Data series 1</title>.+</svg>')
    assert bool(regex.match(svg))
    assert '<path stroke-width="3" stroke-linejoin="round" d="M 0,500 L 150,400 L 400,300 L 250,200 L 500,100 L 301,0 ' in svg

    for x_i in x:
        pos = round(x_i * 100)
        assert bool(re.search(f'<circle r="4" cx="{pos}"[^>]+ /><text x="{pos}"[^>]+>[0-9\\.]+</text>', svg))


def test_x_list_strings():
    x = [x for x in string.ascii_uppercase[0:6]]
    svg = bsc.chart(x = x, y = range(6), width = W500, height = H500, legend_position = None)

    regex = re.compile(r'<svg.+<g id="position" transform="translate\(29, 27\)">.+<g id="series_plots"><g class="series color1" id="series1"><title>Data series 1</title>.+</svg>')
    assert bool(regex.match(svg))
    assert '<path stroke-width="3" stroke-linejoin="round" d="M 0,500 L 100,400 L 200,300 L 300,200 L 400,100 L 500,0' in svg

    for x_i in range(6):
        pos = x_i * 100
        assert bool(re.search(f'<circle r="4" cx="{pos}"[^>]+ /><text x="{pos}"[^>]+>{x_i}</text>', svg))


def test_y_1series():
    x = range(6)
    y = range(6)
    svg = bsc.chart(x, y, width = W500, height = H500, legend_position = None)
    svg2 = bsc.chart(x, (y), width = W500, height = H500, legend_position = None)
    assert svg == svg2

    regex = re.compile(r'<svg.+<g id="position" transform="translate\(29, 27\)">.+<g id="series_plots"><g class="series color1" id="series1"><title>Data series 1</title>.+</svg>')
    assert bool(regex.match(svg))
    path = " ".join([f"L {x[i]*100},{(5-y[i])*100}" for i in range(len(x))])
    path = 'd="M' + path[1:]
    assert path in svg

    for y_i in y:
        assert bool(re.search(f'<circle r="4" cx="[0-9\\.]+" cy="{(5-y_i) * 100}" class="hide" /><text[^>]+>{y_i}</text>', svg))

    # Random doubles between 0 and 5
    y = [5 * random.random() for i in range(10)]
    svg = bsc.chart(x, y, y_min = 0, y_max = 5, width = W500, height = H500, legend_position = None)
    path = " ".join([f"L {x[i]*100},{(5-y[i])*100:.2f}" for i in range(len(x))])
    path = 'd="M' + path[1:]
    # For avoiding floating-point issues
    path = path.replace(".00", "")
    svg = svg.replace(".00", "")
    assert path in svg
    for y_i in y[0:6]:
        pattern = f'<circle r="4" cx="[0-9\\.]+" cy="{(5 - y_i) * 100:.2f}" class="hide" /><text[^>]+>{y_i}</text>'
        pattern = pattern.replace(".00", "")
        assert bool(re.search(pattern, svg))


def test_y_multiple_series():
    x = range(6)
    y = (range(6), [1.2, 2.34, 3.456, 4.567, 4.5678, 0.987654321], (0.123456, 4.99999, 3.5))
    svg = bsc.chart(x, y, width = W500, height = H500, legend_position = None)

    path1 = "M 0,500 L 100,400 L 200,300 L 300,200 L 400,100 L 500,0 "
    assert f'<g id="series_plots"><g class="series color1" id="series1"><title>Data series 1</title><path stroke-width="3" stroke-linejoin="round" d="{path1}" fill="none" />' in svg

    path2 = " ".join([f"L {x[i]*100},{(5-y[1][i])*100:.2f}" for i in range(len(x))])
    path2 = "M" + path2[1:] + " "
    path2 = path2.replace(".00", "")
    assert f'<g class="series color2" id="series2"><title>Data series 2</title><path stroke-width="3" stroke-linejoin="round" d="{path2}" fill="none" />' in svg

    path3 = "M 0,487.65 L 100,0.00 L 200,150 "
    assert f'<g class="series color3" id="series3"><title>Data series 3</title><path stroke-width="3" stroke-linejoin="round" d="{path3}" fill="none" />' in svg


def test_xy():
    xy = [[[1,1], [2,2], [3,3]], [[4.5,2.5]], [[0,3], [1,4], [2,5], [3, 2]]]
    root = bsc.chart(xy = xy, output = "etree")
    assert isinstance(root, ET.Element)
    assert root.tag == "svg"
    assert len(root) == 4

    series_plots = root.find(".//g[@id='series_plots']")
    assert len(series_plots) == 3
    assert len(series_plots[0].findall("circle")) == 3
    assert series_plots[0].findall("text")[0].text == "1"
    assert len(series_plots[1].findall("circle")) == 1
    assert series_plots[1].findall("text")[0].text == "2.5"
    assert len(series_plots[2].findall("circle")) == 4
    assert series_plots[2].findall("text")[3].text == "2"


def create_x_axis(x_ticks, width = 500, height = 520) -> str:
    x_axis_content = [
        '<g id="abscissa_lines">',
        f'<line stroke-width="2" stroke-linecap="square" x1="-8" x2="{width}" y1="{height-27}" y2="{height-27}" stroke="black" />'
    ]

    x_tick_min = min(x_ticks)
    x_tick_max = max(x_ticks)
    for x in x_ticks[1:]:
        pos = width * (x - x_tick_min) / (x_tick_max - x_tick_min)
        x_axis_content.append(f'<use xlink:href="#vertical_dotted_lines" x="{bsc.num_attr(pos)}" />')

    x_axis_content.append("</g>")
    x_axis_content.append('<g id="abscissa_text">')

    for x in x_ticks:
        pos = width * (x - x_tick_min) / (x_tick_max - x_tick_min)
        x_axis_content.append(f'<text x="{bsc.num_attr(pos)}" y="{height}">{x}</text>')

    x_axis_content.append("</g>")

    return "".join(x_axis_content)


def test_x_ticks_int():
    x = range(1900, 2026)
    y = [random.random() for i in range(len(x))]
    width = 714.5
    height = 554.5

    # default value (6)
    svg = bsc.chart(x, y, width = width, height = height)
    assert isinstance(svg, str) and svg.startswith("<svg") and svg.endswith("</svg>")
    assert create_x_axis([1900, 1925, 1950, 1975, 2000, 2025]) in svg

    # x_ticks = 9
    svg = bsc.chart(x, y, x_ticks = 9, width = width, height = height)
    assert isinstance(svg, str) and svg.startswith("<svg") and svg.endswith("</svg>")
    assert create_x_axis([1900, 1916, 1932, 1948, 1964, 1980, 1996, 2012, 2025]) in svg

    # x_ticks = 26 (= every 5 years)
    svg = bsc.chart(x, y, x_ticks = 26, width = width, height = height)
    assert isinstance(svg, str) and svg.startswith("<svg") and svg.endswith("</svg>")
    assert create_x_axis(range(1900, 2026, 5)) in svg

    # x_ticks = 0 (converted to 2 if x_ticks < 2)
    svg = bsc.chart(x, y, x_ticks = 0, width = width, height = height)
    assert isinstance(svg, str) and svg.startswith("<svg") and svg.endswith("</svg>")
    assert create_x_axis([1900, 2025]) in svg

    # check other x_ticks < 2
    svg_new = bsc.chart(x, y, x_ticks = 1, width = width, height = height)
    assert svg_new == svg
    svg_new = bsc.chart(x, y, x_ticks = 0, width = width, height = height)
    assert svg_new == svg
    svg_new = bsc.chart(x, y, x_ticks = -666, width = width, height = height)
    assert svg_new == svg

    # Strings with 6 ticks
    svg = bsc.chart(x = ("a", "b", "c", "d", "e", "f"), y = range(5))
    assert isinstance(svg, str) and svg.startswith("<svg") and svg.endswith("</svg>")
    regex = re.compile(r'<g id="abscissa_lines"><line[^>]+/>(<use xlink:href="#vertical_dotted_lines"[^>]+/>){5}</g><g id="abscissa_text"><text[^>]+>a</text><text[^>]+>b</text><text[^>]+>c</text><text[^>]+>d</text><text[^>]+>e</text><text[^>]+>f</text></g>')
    assert bool(regex.search(svg))

    # Strings with 4 ticks
    svg = bsc.chart(x = ("a", "b", "c", "d", "e", "f", "g"), y = range(5), x_ticks = 4)
    assert isinstance(svg, str) and svg.startswith("<svg") and svg.endswith("</svg>")
    regex = re.compile(r'<g id="abscissa_lines"><line[^>]+/>(<use xlink:href="#vertical_dotted_lines"[^>]+/>){3}</g><g id="abscissa_text"><text[^>]+>a</text><text[^>]+>c</text><text[^>]+>e</text><text[^>]+>g</text></g>')
    assert bool(regex.search(svg))

    # not an integer
    with pytest.raises(TypeError):
        bsc.chart(x, y, x_ticks = -5.7, width = width, height = height)


def test_x_ticks_sequence():
    x = range(1900, 2026)
    y = [random.random() for i in range(len(x))]
    width = 714.5
    height = 554.5

    # Every 25 years
    svg = bsc.chart(x, y, x_ticks = range(1900, 2026, 25), width = width, height = height)
    assert isinstance(svg, str) and svg.startswith("<svg") and svg.endswith("</svg>")
    assert create_x_axis([1900, 1925, 1950, 1975, 2000, 2025]) in svg

    # Every year
    svg = bsc.chart(x, y, x_ticks = range(1900, 2026), width = width, height = height)
    assert isinstance(svg, str) and svg.startswith("<svg") and svg.endswith("</svg>")
    assert create_x_axis(range(1900, 2026)) in svg

    # Random years
    svg = bsc.chart(x, y, x_ticks = (1920, 1958, 1993, 2007), width = width, height = height)
    assert isinstance(svg, str) and svg.startswith("<svg") and svg.endswith("</svg>")
    regex = re.compile(r'<g id="abscissa_lines"><line[^>]+/>(<use xlink:href="#vertical_dotted_lines"[^>]+/>){4}</g><g id="abscissa_text"><text[^>]+>1920</text><text[^>]+>1958</text><text[^>]+>1993</text><text[^>]+>2007</text></g>')
    assert bool(regex.search(svg))

    # Years outside range(1900, 2026)
    svg = bsc.chart(x, y, x_ticks = (1800, 1900, 2000, 2100), width = width, height = height)
    assert isinstance(svg, str) and svg.startswith("<svg") and svg.endswith("</svg>")
    assert create_x_axis(range(1800, 2101, 100)) in svg

    # Strings
    svg = bsc.chart(x = ("a", "b", "c", "d", "e"), y = range(5), x_ticks = ("a", "b", "c", "d", "e"))
    assert isinstance(svg, str) and svg.startswith("<svg") and svg.endswith("</svg>")
    regex = re.compile(r'<g id="abscissa_lines"><line[^>]+/>(<use xlink:href="#vertical_dotted_lines"[^>]+/>){4}</g><g id="abscissa_text"><text[^>]+>a</text><text[^>]+>b</text><text[^>]+>c</text><text[^>]+>d</text><text[^>]+>e</text></g>')
    assert bool(regex.search(svg))

    svg = bsc.chart(x = ("a", "b", "c", "d", "e", "f", "g"), y = range(5), x_ticks = ("b", "c", "f"))
    assert isinstance(svg, str) and svg.startswith("<svg") and svg.endswith("</svg>")
    regex = re.compile(r'<g id="abscissa_lines"><line[^>]+/>(<use xlink:href="#vertical_dotted_lines"[^>]+/>){3}</g><g id="abscissa_text"><text[^>]+>b</text><text[^>]+>c</text><text[^>]+>f</text></g>')
    assert bool(regex.search(svg))


def test_x_ticks_format():
    svg = bsc.chart(x = range(3, 10), y = range(10), x_ticks_format="{}")
    assert bool(re.search('<g id="abscissa_text"><text x="0" y="[0-9\\.]+">3</text>', svg))

    svg = bsc.chart(x = range(5), y = range(5), x_ticks = (1.47265, 3.5), x_ticks_format="{:.2f}")
    assert bool(re.search('<g id="abscissa_text"><text x="[0-9\\.]+" y="[0-9\\.]+">1.47</text>', svg))

    svg = bsc.chart(x = range(1, 7), y = range(6), x_unit = "°C", x_ticks_format="{x}{x_unit}")
    assert bool(re.search('<g id="abscissa_text"><text x="0" y="[0-9\\.]+">1°C</text>', svg))
    
    svg = bsc.chart(x = range(1000, 2000), y = range(1000, 2000), x_ticks_format="{x:,}")
    assert bool(re.search('<g id="abscissa_text"><text x="0" y="[0-9\\.]+">1,000</text>', svg))
    
    svg = bsc.chart(x = range(1234567, 1235000), y = range(1000), x_ticks_format="{x:_}", big_mark = " ")
    assert bool(re.search('<g id="abscissa_text"><text x="0" y="[0-9\\.]+">1 234 567</text>', svg))


def test_x_axis_discrete():
    params = SimpleNamespace(
        chart_type = "scatter and line",
        x = (0, 8.3, 5, 2.99, 4, 0.9, 2.4, 0.55, 3.666, 1.5, 10),
        y = [y /2 for y in range(11, 0, -1)],
        y_ticks = range(7),
        legend_position = None,
        width = 500 + 20 + 9*1 + 20 + 11.5,
        height = 554.5,
        tooltip_type = "value",
        values_format = "({x}, {y})",
        # output = "/tmp/chart.svg"
    )

    # Default values (x_ticks = 6, x_axis_discrete = True)
    svg = bsc.chart(**vars(params))
    assert isinstance(svg, str) and svg.startswith("<svg") and svg.endswith("</svg>")
    assert create_x_axis([0, 0.9, 2.4, 3.666, 5, 10]) in svg

    # x_axis_discrete = False
    svg = bsc.chart(**vars(params), x_axis_discrete = False)
    assert isinstance(svg, str) and svg.startswith("<svg") and svg.endswith("</svg>")
    assert create_x_axis(range(0, 11, 2)) in svg

    # x_axis_discrete = False ans x_ticks = 11
    svg = bsc.chart(**vars(params), x_axis_discrete = False, x_ticks = 11)
    assert isinstance(svg, str) and svg.startswith("<svg") and svg.endswith("</svg>")
    assert create_x_axis(range(11)) in svg


def test_y_ticks_int():
    # default: y_ticks = 6
    svg = bsc.chart(range(6), range(6), width = W500, height = H500)
    assert '<g id="ordinate"><line stroke-width="2" stroke-linecap="square" x1="0" x2="0" y1="508" y2="0" stroke="black" /><text x="-14" y="500">0</text>' in svg
    for i in range(1, 6):
        assert f'<use xlink:href="#horizontal_dotted_lines" y="{(5-i)*100}" /><text x="-14" y="{(5-i)*100}">{i}</text>' in svg

    # y_ticks = 2
    svg = bsc.chart(range(6), range(6), y_ticks = 2, width = W500, height = H500)
    g_ordinate = '''
    <g id="ordinate">
    <line stroke-width="2" stroke-linecap="square" x1="0" x2="0" y1="508" y2="0" stroke="black" />
    <text x="-14" y="500">0</text>
    <use xlink:href="#horizontal_dotted_lines" y="0" />
    <text x="-14" y="0">5</text>
    </g>
    '''

    g_ordinate = "".join([g.strip() for g in g_ordinate.splitlines()[1:]])
    # g_ordinate = re.sub(r'[\r\n]+', '', g_ordinate)

    assert g_ordinate in svg

    # y_ticks = 10
    svg = bsc.chart(range(11), range(11), y_ticks = 11, width = W500, height = H500)
    assert '<g id="ordinate"><line stroke-width="2" stroke-linecap="square" x1="0" x2="0" y1="508" y2="0" stroke="black" /><text x="-14" y="500">0</text>' in svg
    for i in range(1, 11):
        assert f'<use xlink:href="#horizontal_dotted_lines" y="{(10-i)*50}" /><text x="-14" y="{(10-i)*50}">{i}</text>' in svg


def test_y_ticks_sequence():
    # y_ticks = (0, 5)
    svg = bsc.chart(range(6), range(6), y_ticks = (0, 5), height = H500)
    g_ordinate = '''
    <g id="ordinate">
    <line stroke-width="2" stroke-linecap="square" x1="0" x2="0" y1="508" y2="0" stroke="black" />
    <text x="-14" y="500">0</text>
    <use xlink:href="#horizontal_dotted_lines" y="0" />
    <text x="-14" y="0">5</text>
    </g>
    '''
    g_ordinate = "".join([g.strip() for g in g_ordinate.splitlines()[1:]])
    print(g_ordinate)
    assert g_ordinate in svg

    # y_ticks = (0, 4, 5)
    y_ticks = (4, 2, 5, 0)
    svg = bsc.chart(range(6), range(6), y_ticks = y_ticks, height = H500)
    assert '<text x="-14" y="500">0</text>' in svg
    for y_i in [y_i for y_i in y_ticks if y_i != 0]:
        assert f'<use xlink:href="#horizontal_dotted_lines" y="{(5-y_i)*100}" /><text x="-14" y="{(5-y_i)*100}">{y_i}</text>' in svg

    # y_ticks with negative and positive values
    y_ticks = [-5, 3, 10, 3.75, 20.83] + [random.random() for i in range(10)]
    svg = bsc.chart(range(6), range(6), y_ticks = y_ticks, y_ticks_format = "{}")
    for yt in y_ticks:
        assert bool(re.search(f'<text x="-14" y="[0-9\\.]+">{yt}</text>', svg))


def test_y_ticks_interval():
    # y_ticks_interval = 1
    svg = bsc.chart(range(6), range(6), y_ticks_interval = 1, height = H500)
    assert '<g id="ordinate"><line stroke-width="2" stroke-linecap="square" x1="0" x2="0" y1="508" y2="0" stroke="black" /><text x="-14" y="500">0</text>' in svg
    for i in range(1, 6):
        assert f'<use xlink:href="#horizontal_dotted_lines" y="{(5-i)*100}" /><text x="-14" y="{(5-i)*100}">{i}</text>' in svg

    # y_ticks_interval = 0.5
    svg = bsc.chart(range(6), range(6), y_ticks_interval = 0.5, height = H500)
    assert '<g id="ordinate"><line stroke-width="2" stroke-linecap="square" x1="0" x2="0" y1="508" y2="0" stroke="black" /><text x="-14" y="500">0</text>' in svg

    for i in range(1, 11):
        val = int(i/2) if i % 2 == 0 else i/2
        assert f'<use xlink:href="#horizontal_dotted_lines" y="{(10-i)*50}" /><text x="-14" y="{(10-i)*50}">{val}</text>' in svg

    # y_ticks_interval = 2
    svg = bsc.chart(range(11), range(11), y_ticks_interval = 2, height = H500)
    assert '<g id="ordinate"><line stroke-width="2" stroke-linecap="square" x1="0" x2="0" y1="508" y2="0" stroke="black" /><text x="-14" y="500">0</text>' in svg
    for i in range(1, 6):
        assert f'<use xlink:href="#horizontal_dotted_lines" y="{(5-i)*100}" /><text x="-14" y="{(5-i)*100}">{i*2}</text>' in svg


def test_y_ticks_format():
    svg = bsc.chart(x = range(6), y = range(6), y_ticks_format="{}")
    assert bool(re.search('<use xlink:href="#horizontal_dotted_lines"[^>]+><text x="-14" y="[0-9\\.]+">1</text>', svg))
    
    svg = bsc.chart(x = range(6), y = range(6), y_ticks_format="{:.3f}")
    assert bool(re.search('<use xlink:href="#horizontal_dotted_lines"[^>]+><text x="-14" y="[0-9\\.]+">2.000</text>', svg))

    svg = bsc.chart(x = range(6), y = range(6), y_unit = "€uros", y_ticks_format="{y} {y_unit}")
    assert bool(re.search('<use xlink:href="#horizontal_dotted_lines"[^>]+><text x="-14" y="[0-9\\.]+">3 €uros</text>', svg))
    
    svg = bsc.chart(x = range(2000), y = range(2000), y_ticks = (0, 1000, 2000), y_ticks_format="{y:,}")
    assert bool(re.search('<use xlink:href="#horizontal_dotted_lines"[^>]+><text x="-14" y="[0-9\\.]+">1,000</text>', svg))
    
    svg = bsc.chart(x = range(2000), y = range(2000), y_ticks = (0, 1000, 2000), y_ticks_format="{y:_}", big_mark = " ")
    assert bool(re.search('<use xlink:href="#horizontal_dotted_lines"[^>]+><text x="-14" y="[0-9\\.]+">2 000</text>', svg))


def test_y_min():
    x = [0, 1, 2]
    y = [[10, 20, 30], [-15, -8, -30], [None, -7, 4]]
    font_size = 15
    height = 600 + 20 + 12 + font_size + font_size/2 + 7

    # default value (0)
    svg = bsc.chart(x, y, height = height)

    default_y_ticks = 6
    y_interval_val = 30 / (default_y_ticks-1)
    y_interval_px = 600 / (default_y_ticks-1)
    horizontal_dotted_lines = "".join([f'<use xlink:href="#horizontal_dotted_lines" y="{bsc.num_attr(600 - y_interval_px*i)}" /><text x="-14" y="{bsc.num_attr(600 - y_interval_px*i)}">{int(y_interval_val * i)}</text>' for i in range(1, default_y_ticks)])

    assert f'<g id="ordinate"><line stroke-width="2" stroke-linecap="square" x1="0" x2="0" y1="608" y2="0" stroke="black" /><text x="-14" y="600">0</text>{horizontal_dotted_lines}</g>' in svg

    # y_min None
    svg = bsc.chart(x, y, y_min = None, y_ticks_interval = 10, height = height)

    horizontal_dotted_lines = "".join([f'<use xlink:href="#horizontal_dotted_lines" y="{bsc.num_attr(500 - 100*i)}" /><text x="-14" y="{bsc.num_attr(500 - 100*i)}">{int(-20 + 10 * i)}</text>' for i in range(default_y_ticks)])
    assert f'<g id="ordinate"><line stroke-width="2" stroke-linecap="square" x1="0" x2="0" y1="608" y2="0" stroke="black" /><text x="-14" y="600">-30</text>{horizontal_dotted_lines}</g>' in svg

    # y_min = -90
    svg = bsc.chart(x, y, y_min = -90, y_ticks = 5, height = height)

    horizontal_dotted_lines = "".join([f'<use xlink:href="#horizontal_dotted_lines" y="{bsc.num_attr(600 - 150*i)}" /><text x="-14" y="{bsc.num_attr(600 - 150*i)}">{int(-90 + 30*i)}</text>' for i in range(1, 5)])
    assert f'<g id="ordinate"><line stroke-width="2" stroke-linecap="square" x1="0" x2="0" y1="608" y2="0" stroke="black" /><text x="-14" y="600">-90</text>{horizontal_dotted_lines}</g>' in svg


def test_y_max():
    x = range(6)
    y = range(6)

    # default y_max = max(y)
    svg = bsc.chart(x, y, width = W500, height = H500, legend_position = None)
    assert '<use xlink:href="#horizontal_dotted_lines" y="0" /><text x="-14" y="0">5</text></g><g id="abscissa_lines">' in svg
    assert '<path stroke-width="3" stroke-linejoin="round" d="M 0,500 L 100,400 L 200,300 L 300,200 L 400,100 L 500,0 " fill="none" />' in svg

    # y_max = 10
    width = 500 + 38 + 20
    svg = bsc.chart(x, y, y_max = 10, width = width, height = H500, legend_position = None)
    assert '<use xlink:href="#horizontal_dotted_lines" y="0" /><text x="-14" y="0">10</text></g><g id="abscissa_lines">' in svg
    assert '<path stroke-width="3" stroke-linejoin="round" d="M 0,500 L 100,450 L 200,400 L 300,350 L 400,300 L 500,250 " fill="none" />' in svg

    # y_max = 2.5
    width = 500 + 47 + 20
    svg = bsc.chart(x, y, y_max = 2.5, width = width, height = H500, legend_position = None)
    assert '<use xlink:href="#horizontal_dotted_lines" y="0" /><text x="-14" y="0">2.5</text></g><g id="abscissa_lines">' in svg
    assert '<path stroke-width="3" stroke-linejoin="round" d="M 0,500 L 100,300 L 200,100 L 300,-100 L 400,-300 L 500,-500 " fill="none" />' in svg

    # y_max and y_ticks defined -> y_max = max(y_ticks)
    svg = bsc.chart(x = range(5), y = range(5), y_max = 20, y_ticks = range(9), width = W500, height = H500, legend_position = None)
    assert '<use xlink:href="#horizontal_dotted_lines" y="0" /><text x="-14" y="0">8</text></g><g id="abscissa_lines">' in svg
    assert '<path stroke-width="3" stroke-linejoin="round" d="M 0,500 L 125,437.50 L 250,375 L 375,312.50 L 500,250 " fill="none" />' in svg


def test_default_colors():
    # Okabe-Ito
    svg = bsc.chart(x = [0, 1, 2], y = [[10, 20, 30], [15, 8, 22], [None, 15, 5]])
    assert ".color1 {fill: #E69F00; stroke: #E69F00;}" in svg
    assert "#56B4E9" in svg and ".color2" in svg
    assert "#009E73" in svg and ".color3" in svg
    assert "#F0E442" not in svg and ".color4" not in svg # only 3 series
    assert "#440154" not in svg # Viridis

    # Viridis
    random.seed(36)
    svg = bsc.chart(x = range(10), y = [random.choices(range(20), k = 10) for i in range(10)])
    assert ".color1 {fill: #440154; stroke: #440154;}" in svg
    assert ".color2 {fill: #482878; stroke: #482878;}" in svg
    assert "#3e4989" in svg and ".color3" in svg
    assert "#b5de2b" in svg and ".color8" in svg
    assert ".color10 {fill: #fde725; stroke: #fde725;}" in svg
    assert "#482475" not in svg and ".color11" not in svg # only 10 series


def test_colors():
    colors = ("ForestGreen", "#8a5cd1", "rgb(255, 215, 0)")
    svg = bsc.chart(x = [0, 1, 2], y = [[10, 20, 30], [15, 8, 22], [None, 15, 5]], colors = colors)
    assert ".color1 {fill: ForestGreen; stroke: ForestGreen;}" in svg
    assert "text.color1 {fill: ForestGreen;" in svg
    assert ".color2 {fill: #8a5cd1; stroke: #8a5cd1;}" in svg
    assert ".color3 {fill: rgb(255, 215, 0); stroke: rgb(255, 215, 0);}" in svg


def test_circles():
    # Default : circles = 4
    svg = bsc.chart(range(8), range(8))
    assert '<circle r="4" cx' in svg
    assert "circle:hover {r: 6px;}" in svg

    # circles = 9.7
    svg = bsc.chart(range(8), range(8), circles = 9.7)
    assert '<circle r="9.7" cx' in svg
    assert "circle:hover {r: 12.125px;}" in svg # 9.7 * 1.5 = 12.125

    # circles = 1
    svg = bsc.chart(range(50, 1000, 50), range(0, 40, 2), circles = 1)
    assert '<circle r="1" cx' in svg
    assert "circle:hover {r: 3px;}" in svg

    # line chart without values shown
    svg = bsc.line_chart(x = range(4), y = range(4), circles = 8, tooltip_type = None)
    assert '<circle' not in svg

    # Scatter chart with None or negative value -> 4
    svg = bsc.scatter_chart(x = range(2), y = range(2), circles = None, tooltip_type = None)
    svg2 = bsc.scatter_chart(x = range(2), y = range(2), circles = -3, tooltip_type = None)
    assert svg == svg2
    assert '<circle r="4" cx' in svg
    assert "circle:hover {r: 6px;}" in svg


def test_tooltip_title():
    svg = bsc.chart(
        x = range(3),
        y = (5, 10, 15),
        tooltip_type="title"
    )
    regex = re.compile(r'<g class="series color1" id="series1">.+<circle [^>]+ class="hide"><title>Data series 1: x = 0, y = 5</title></circle>')
    assert bool(regex.search(svg))
    assert "<title>Data series 1: x = 1, y = 10</title></circle>" in svg
    assert "<title>Data series 1: x = 2, y = 15</title></circle>" in svg


def test_tooltip_value():
    svg = bsc.chart(
        x = range(3),
        y = (5, 10, 15),
        tooltip_type="value"
    )
    assert "text.hide {transform: translate(1200px, 800px);}" in svg
    regex = re.compile(r'<g class="series color1" id="series1">.+<text [^>]+ class="hide">5</text>')
    assert bool(regex.search(svg))
    assert 'class="hide">10</text><circle r="4"' in svg
    assert 'class="hide">15</text><g class="legend" id="legend1">' in svg


def test_tooltip_vertical_line():
    svg = bsc.chart(
        x = range(3),
        y = (5, 10, 15),
        tooltip_type="vertical line"
    )
    assert ".hover_values" in svg
    assert 'id="bg_abs"' in svg


def test_show_values():
    svg = bsc.chart(
        x = range(3),
        y = (5, 10, 15),
        tooltip_type = None,
        show_values=(1, 2)
    )
    assert "text.hide {transform: translate(1200px, 800px);}" not in svg
    assert ">5</text" not in svg
    regex = re.compile(r'<g class="series color1" id="series1">.+<text x="[0-9\.\-]+" y="[0-9\.\-]+">10</text>.+<text x="[0-9\.\-]+" y="[0-9\.\-]+">15</text>')
    assert bool(regex.search(svg))


def test_show_values_all():
    svg = bsc.chart(
        x = range(3),
        y = (5, 10, 15),
        tooltip_type = None,
        show_values = "all"
    )
    assert "text.hide {transform: translate(1200px, 800px);}" not in svg
    regex = re.compile(r'<g class="series color1" id="series1">.+<text x="[0-9\.\-]+" y="[0-9\.\-]+">5</text>.+<text x="[0-9\.\-]+" y="[0-9\.\-]+">10</text>.+<text x="[0-9\.\-]+" y="[0-9\.\-]+">15</text>')
    assert bool(regex.search(svg))


def test_show_values_last():
    svg = bsc.chart(
        x = range(3),
        y = (5, 10, 15),
        tooltip_type = None,
        show_values = "last",
    )
    assert "text.hide {transform: translate(1200px, 800px);}" not in svg
    assert ">5</text" not in svg
    assert ">10</text" not in svg
    assert ">15</text" in svg
    regex = re.compile(r'<g class="series color1" id="series1"><title>Data series 1</title><path[^>]+/><circle[^>]+/><text [^>]+>15</text><g class="legend" id="legend1">')
    assert bool(regex.search(svg))


def test_values_position_top():
    svg = bsc.chart(x = range(6), y = range(6), tooltip_type = "value", values_position = "top", width = 600, height = 600, margin = [50] * 4)
    assert "g.series &gt; text {text-anchor: middle;}" in svg
    assert "text.hide {transform: translate(600px, 600px);}" in svg
    assert '<circle r="4" cx="500" cy="0" class="hide" /><text x="500" y="-12" class="hide">5</text>' in svg


def test_values_position_right():
    svg = bsc.chart(x = range(6), y = range(6), tooltip_type = "value", values_position = "right", width = 600, height = 600, margin = [50] * 4)
    assert "g.series &gt; text {text-anchor: start; dominant-baseline: central;}" in svg
    assert "text.hide {transform: translate(600px, 600px);}" in svg
    assert '<circle r="4" cx="500" cy="0" class="hide" /><text x="512" y="0" class="hide">5</text>' in svg


def test_values_position_bottom():
    svg = bsc.chart(x = range(6), y = range(6), tooltip_type = "value", values_position = "bottom", width = 600, height = 600, margin = [50] * 4)
    assert "g.series &gt; text {text-anchor: middle;}" in svg
    assert "text.hide {transform: translate(600px, 600px);}" in svg
    assert '<circle r="4" cx="500" cy="0" class="hide" /><text x="500" y="20" class="hide">5</text>' in svg


def test_values_position_left():
    svg = bsc.chart(x = range(6), y = range(6), tooltip_type = "value", values_position = "left", width = 600, height = 600, margin = [50] * 4)
    assert "g.series &gt; text {text-anchor: end; dominant-baseline: central;}" in svg
    assert "text.hide {transform: translate(600px, 600px);}" in svg
    assert '<circle r="4" cx="500" cy="0" class="hide" /><text x="488" y="0" class="hide">5</text>' in svg


def test_values_position_fixed_above_chart():
    svg = bsc.chart(x = range(6), y = range(6), tooltip_type = "value", values_position = "fixed above chart", width = 600, height = 600, margin = [50] * 4)
    assert "g.series &gt; text {text-anchor: start; dominant-baseline: central;}" in svg
    assert "text.hide {transform: translate(600px, 600px);}" in svg
    assert '<circle r="4" cx="200" cy="300" class="hide" /><text x="5" y="-18.75" class="hide">2</text>' in svg


def test_values_position_fixed_under_chart():
    svg = bsc.chart(x = range(6), y = range(6), tooltip_type = "value", values_position = "fixed under chart", width = 600, height = 600, margin = [50] * 4)
    assert "g.series &gt; text {text-anchor: start; dominant-baseline: central;}" in svg
    assert "text.hide {transform: translate(600px, 600px);}" in svg
    assert '<circle r="4" cx="200" cy="300" class="hide" /><text x="0" y="542" class="hide">2</text>' in svg


def test_values_position_shift():
    # values_position_shift = (0, 0)
    svg = bsc.chart(x = range(6), y = range(6), tooltip_type = "value", values_position = "top", values_position_shift = (0, 0), width = 600, height = 600, margin = [50] * 4)
    assert "g.series &gt; text {text-anchor: middle;}" in svg
    assert "text.hide {transform: translate(600px, 600px);}" in svg
    assert '<circle r="4" cx="200" cy="300" class="hide" /><text x="200" y="300" class="hide">2</text>' in svg
    
    # values_position_shift = (-20, -20)
    svg = bsc.chart(x = range(6), y = range(6), tooltip_type = "value", values_position_shift = (-20, -20), width = 600, height = 600, margin = [50] * 4)
    assert '<circle r="4" cx="200" cy="300" class="hide" /><text x="180" y="280" class="hide">2</text>' in svg
    
    # values_position_shift = (10.7, -66.6)
    svg = bsc.chart(x = range(6), y = range(6), tooltip_type = "value", values_position_shift = (10.7, -66.6), width = 600, height = 600, margin = [50] * 4)
    assert '<circle r="4" cx="200" cy="300" class="hide" /><text x="210.70" y="233.40" class="hide">2</text>' in svg
    
    # values_position_shift = [0, 50]
    svg = bsc.chart(x = range(6), y = range(6), tooltip_type = "value", values_position_shift = [0, 50], width = 600, height = 600, margin = [50] * 4)
    assert '<circle r="4" cx="200" cy="300" class="hide" /><text x="200" y="350" class="hide">2</text>' in svg


def test_extra_lines():
    svg = bsc.chart(
        x = range(3),
        y = (5, 10, 15),
        extra_lines = ({"x": 2}, {"y": 12, "color": "blue", "thickness": 5, "position": "front"})
    )
    regex = re.compile(r'<svg.+<line [^>]+ stroke="black" stroke-width="2" stroke-linecap="square" />.+<g id="series_plots">.+</svg>')
    assert bool(regex.match(svg))
    regex = re.compile(r'<svg.+<g id="series_plots">.+<line [^>]+ stroke="blue" stroke-width="5" stroke-linecap="square" />.+</svg>')
    assert bool(regex.match(svg))


def test_x_unit():
    svg = bsc.chart(
        x = range(3),
        y = (5, 10, 15),
        x_unit = "°C"
    )
    regex = re.compile(r'<g id="abscissa_text">.+<text class="unit" dominant-baseline="central" x="497.25" y="758">°C</text></g>')
    assert bool(regex.search(svg))


def test_x_unit_svg_tags():
    svg = bsc.chart(
        x = range(3),
        y = (5, 10, 15),
        x_unit = "<tspan class='abbr'><title>degree Celsius</title>°C</tspan>"
    )
    regex = re.compile(r'<g id="abscissa_text">.+<text class="unit" dominant-baseline="central" x="497.25" y="758"><tspan class="abbr"><title>degree Celsius</title>°C</tspan></text></g>')
    assert bool(regex.search(svg))


def test_y_unit():
    svg = bsc.chart(
        x = range(3),
        y = (5, 10, 15),
        y_unit = "GWh"
    )
    regex = re.compile(r'<g id="ordinate">.+<text class="unit" x="-20" y="-18.75">GWh</text></g>')
    assert bool(regex.search(svg))


def test_y_unit_svg_tags():
    svg = bsc.chart(
        x = range(3),
        y = (5, 10, 15),
        y_unit = "<title>gigawatt-hours</title>GWh"
    )
    regex = re.compile(r'<g id="ordinate">.+<text class="unit" x="-20" y="-18.75"><title>gigawatt-hours</title>GWh</text></g>')
    assert bool(regex.search(svg))


def test_values_format():
    svg = bsc.chart(
        x = range(3),
        y = (5, 10, 15),
        names = "Electricity consumption",
        extra_data = ["01/01/1988", "02/01/1988", "03/01/1988"],
        x_unit = "°C",
        y_unit = "GWh",
        values_format = "{name} on {extra}: {y} {y_unit}, while temp = {x} {x_unit}",
    )
    assert '<text x="312" y="225.67" class="hide">Electricity consumption on 02/01/1988: 10 GWh, while temp = 1 °C</text>' in svg


def test_values_format_svg_tags():
    svg = bsc.chart(
        x = range(3),
        y = (5, 10, 15),
        values_format = "<tspan style='font-weight: bold; fill: darkblue;'>{y} GWh</tspan> ; {x}°C",
    )
    assert '<text x="0" y="480.33" class="hide"><tspan style="font-weight: bold; fill: darkblue;">5 GWh</tspan> ; 0°C</text>' in svg


def test_values_format_newline():
    svg = bsc.chart(
        x = range(3),
        y = (5, 10, 15),
        values_format = "{name}\n{x}:\n**{y}**",
        values_position_shift = (0, -55),
    )

    assert '<circle r="4" cx="0" cy="463.67" class="hide" /><text y="408.67" class="hide"><tspan x="0">Data series 1</tspan><tspan x="0" dy="1.3em">0:</tspan><tspan x="0" dy="1.3em">**5**</tspan></text><circle r="4"' in svg


def test_values_format_sequence():
    svg = bsc.chart(
        x = range(10),
        y = (range(10), (15.26, 13.4999, 10.01234), range(5), range(5, 20)),
        tooltip_type = "value",
        values_format = ("{x} = {y}", "{y:.2f}", None, "{name} = {y}"),
    )
    assert '<text x="0" y="726.50" class="hide">0 = 0</text>' in svg
    assert '<text x="211.44" y="356.79" class="hide">10.01</text>' in svg
    assert '<g class="series color3" id="series3"><title>Data series 3</title><path stroke-width="3" stroke-linejoin="round" d="M 0,738.50 L 105.72,701.58 L 211.44,664.65 L 317.17,627.73 L 422.89,590.80 " fill="none" /><g class="legend" id="legend3">' in svg
    assert '<text x="317.17" y="431.10" class="hide">Data series 4 = 8</text>' in svg


def test_title_tooltip_format():
    svg = bsc.chart(
        x = range(3),
        y = (5, 10, 15),
        tooltip_type = "title",
        names = "Electricity consumption",
        extra_data = ["01/01/1988", "02/01/1988", "03/01/1988"],
        x_unit = "°C",
        y_unit = "GWh",
        title_tooltip_format = "{name} on {extra}: {y} {y_unit}, while temp = {x} {x_unit}",
    )
    assert 'class="hide"><title>Electricity consumption on 01/01/1988: 5 GWh, while temp = 0 °C</title></circle>' in svg
    assert 'class="hide"><title>Electricity consumption on 02/01/1988: 10 GWh, while temp = 1 °C</title></circle>' in svg
    assert 'class="hide"><title>Electricity consumption on 03/01/1988: 15 GWh, while temp = 2 °C</title></circle>' in svg


def test_title_tooltip_format_svg_tags():
    svg = bsc.chart(
        x = range(3),
        y = (5, 10, 15),
        tooltip_type = "title",
        names = "Electricity consumption",
        extra_data = ["01/01/1988", "02/01/1988", "03/01/1988"],
        x_unit = "°C",
        y_unit = "GWh",
        title_tooltip_format = "{name} on <tspan class='bold'>{extra}</tspan>: {y} {y_unit} <title>{x} {x_unit}</title>",
    )
    assert 'class="hide"><title>Electricity consumption on 01/01/1988: 5 GWh (0 °C)</title></circle>' in svg
    assert 'class="hide"><title>Electricity consumption on 02/01/1988: 10 GWh (1 °C)</title></circle>' in svg
    assert 'class="hide"><title>Electricity consumption on 03/01/1988: 15 GWh (2 °C)</title></circle>' in svg


def test_title_tooltip_format_sequence():
    svg = bsc.chart(
        x = range(10),
        y = (range(10), (15.26, 13.4999, 10.01234), range(5), range(5, 20)),
        tooltip_type = "title",
        title_tooltip_format = ("{x} = {y}", "{y:.2f}", None, "{name} = {y}")
    )
    assert "<title>1 = 1</title></circle>" in svg
    assert "<title>13.50</title></circle>" in svg
    assert '<g class="series color3" id="series3"><title>Data series 3</title><path stroke-width="3" stroke-linejoin="round" d="M 0,745.50 L 110.50,708.23 L 221,670.95 L 331.50,633.67 L 442,596.40 " fill="none" /><g class="legend" id="legend3">' in svg
    assert "<title>Data series 4 = 14</title></circle>" in svg


def test_extra_data():
    # 1 series
    svg = bsc.chart(x = range(10), y = range(10), extra_data = string.ascii_lowercase, values_format = "{extra}: ({x}, {y})")
    assert bool(re.search(r'<text x="[0-9\.\-]+" y="[0-9\.\-]+" class="hide">a: \(0, 0\)</text>', svg))
    assert bool(re.search(r'<text x="[0-9\.\-]+" y="[0-9\.\-]+" class="hide">d: \(3, 3\)</text>', svg))
    assert bool(re.search(r'<text x="[0-9\.\-]+" y="[0-9\.\-]+" class="hide">f: \(5, 5\)</text>', svg))

    # several series
    svg = bsc.chart(
        x = range(5),
        y = (range(5), [4] * 5, [None, 3, None, 2, 1]),
        extra_data = (range(1000, 10000, 1000), ["987", 1.23456, None, "Extra", "Data"]),
        values_format = ("{y} [{extra} km]", "{extra}", "{x} = {y}")
    )
    assert bool(re.search(r'<text x="[0-9\.\-]+" y="[0-9\.\-]+" class="hide">0 \[1000 km\]</text><circle', svg))
    assert bool(re.search(r'<text x="[0-9\.\-]+" y="[0-9\.\-]+" class="hide">4 \[5000 km\]</text><g', svg))
    assert 'class="hide">987</text><circle' in svg
    assert 'class="hide">1.23456</text><circle' in svg
    assert 'class="hide">None</text><circle' in svg
    assert 'class="hide">Extra</text><circle' in svg
    assert 'class="hide">1 = 3</text><circle' in svg


def test_chart_invalid_y_ticks():
    with pytest.raises(TypeError):
        bsc.chart(range(100), y = range(100), y_ticks = "NaN")


def test_chart_margin_auto_top():
    # default with no title or y_unit and tooltip_type = "value" and values_position = "top"
    svg = bsc.chart(range(6), range(6))
    assert '<g id="position" transform="translate(29, 27)">' in svg

    # title with default font_size
    svg = bsc.chart(range(6), range(6), title = "🌻🌻🌻")
    # reg_pos = re.search(r'<g id="position" transform="translate\(([0-9\.]+), ([0-9\.]+)\)">', svg)
    # print(reg_pos.group(1), reg_pos.group(2))
    assert '<g id="position" transform="translate(29, 42)">' in svg

    # title with larger font_size
    svg = bsc.chart(range(6), range(6), title = "🌻🌻🌻", font_size = 20)
    assert '<g id="position" transform="translate(32, 56)">' in svg

    # title with smaller font_size
    svg = bsc.chart(range(6), range(6), title = "🌻🌻🌻", font_size = 10)
    assert '<g id="position" transform="translate(26, 28)">' in svg

    # y_unit
    svg = bsc.chart(range(6), range(6), y_unit = "happiness")
    assert re.search(r'<g id="position" transform="translate\(([0-9\.]+), ([0-9\.]+)\)">', svg).group(2) == "30"

    # y_unit with larger font_size
    svg = bsc.chart(range(6), range(6), y_unit = "happiness", font_size = 20)
    assert re.search(r'<g id="position" transform="translate\(([0-9\.]+), ([0-9\.]+)\)">', svg).group(2) == "40"
    
    # no tooltip
    svg = bsc.chart(range(6), range(6), tooltip_type = None)
    assert '<g id="position" transform="translate(29, 20)">' in svg

    # show values
    svg = bsc.chart(range(6), range(6), tooltip_type = None, show_values = "all")
    assert '<g id="position" transform="translate(29, 27)">' in svg

    # show values with larger font size
    svg = bsc.chart(range(6), range(6), tooltip_type = None, show_values = "all", font_size = 20)
    assert re.search(r'<g id="position" transform="translate\(([0-9\.]+), ([0-9\.]+)\)">', svg).group(2) == "32"

    # show values with bottom position
    svg = bsc.chart(range(6), range(6), tooltip_type = None, show_values = "all", values_position = "bottom")
    assert '<g id="position" transform="translate(29, 20)">' in svg

    # tooltip values with right position
    svg = bsc.chart(range(6), range(6), values_position = "right")
    assert '<g id="position" transform="translate(29, 20)">' in svg

    # specific values_position_shift
    svg = bsc.chart(range(6), range(6), values_position_shift = (20, -15))
    assert '<g id="position" transform="translate(29, 30)">' in svg
    
    # legend_position = "top"
    svg = bsc.chart(range(6), range(6), legend_position = "top")
    assert '<g id="position" transform="translate(29, 50)">' in svg
    
    # values_position = "fixed above chart"
    svg = bsc.chart(range(6), range(6), values_position = "fixed above chart")
    assert '<g id="position" transform="translate(29, 35)">' in svg
    svg = bsc.chart(range(6), range(6), values_position = "fixed above chart", font_size = 20)
    assert '<g id="position" transform="translate(32, 40)">' in svg


def get_right_margin(svg):
    width = float(re.search(r'<svg [^>]+ width="([0-9\.]+)"', svg).group(1))
    chart_area_width = float(re.search(r'<g id="abscissa_lines"><line [^>]+ x2="([0-9\.]+)"', svg).group(1))
    x_shift = float(re.search(r'<g id="position" transform="translate\(([0-9\.]+), ([0-9\.]+)\)">', svg).group(1))
    return pytest.approx(width - chart_area_width - x_shift)

def test_chart_margin_auto_right():
    # default with legend
    svg = bsc.chart(range(6), range(6))
    legend_width = 70 + len("Data series 1") * 15 / 2
    assert get_right_margin(svg) == legend_width

    svg = bsc.chart(range(6), (range(6), range(10), range(4)), names = ("name1", "blablabla2", "z"))
    assert get_right_margin(svg) == 145

    # no legend
    svg = bsc.chart(range(6), range(6), legend_position = None)
    assert get_right_margin(svg) == 20

    # legend bottom right
    svg = bsc.chart(range(6), range(6), legend_position = "bottom right")
    assert get_right_margin(svg) == 20

    # large last x tick
    coeff = 1e10
    svg = bsc.chart(range(0, int(6 * coeff), int(coeff)), range(6), legend_position = None)
    assert get_right_margin(svg) == 15 * 0.6 * 11 / 2
    svg = bsc.chart(("a", "b", "c", "d", string.ascii_lowercase), range(6), legend_position = None)
    assert get_right_margin(svg) == 15 * 0.6 * 26 / 2

    # large value shown on hover
    svg = bsc.chart(range(6), [0] * 6, y_max = 1, values_format = "{y} days since Trump's latest insanity", legend_position = None)
    assert get_right_margin(svg) == 162


def get_bottom_margin(svg):
    height = float(re.search(r'<svg [^>]+ height="([0-9\.]+)"', svg).group(1))
    chart_area_height = float(re.search(r'<g id="vertical_dotted_lines"><line [^>]+stroke-dasharray=[^>]+y2="([0-9\.]+)"', svg).group(1))
    y_shift = float(re.search(r'<g id="position" transform="translate\(([0-9\.]+), ([0-9\.]+)\)">', svg).group(2))
    return pytest.approx(height - chart_area_height - y_shift)

def test_chart_margin_auto_bottom():
    # default
    svg = bsc.chart(range(6), range(6))
    assert get_bottom_margin(svg) == 34.5
    
    # larger font size fox x ticks
    svg = bsc.chart(range(6), range(6), font_size = 20)
    assert get_bottom_margin(svg) == 42
    
    # x_unit
    svg = bsc.chart(range(6), range(6), x_unit = "📏")
    assert get_bottom_margin(svg) == 57
    
    # bottom legend
    svg = bsc.chart(range(6), range(6), legend_position = "bottom")
    assert get_bottom_margin(svg) == 64.5
    
    # show values on bottom
    svg = bsc.chart(range(6), range(6), values_position = "bottom", values_position_shift = (0, 50))
    assert get_bottom_margin(svg) == 57.5

    # Single note
    svg = bsc.chart(range(6), range(6), notes = "First note")
    assert get_bottom_margin(svg) == 57

    # Single note and x_unit and bottom legend
    svg = bsc.chart(range(6), range(6), notes = "First note", legend_position = "bottom", x_unit = "year")
    assert get_bottom_margin(svg) == 109.5

    # Multi notes
    svg = bsc.chart(range(6), range(6), notes = ("note1", "note2", "note3"))
    assert get_bottom_margin(svg) == 102
    
    # values_position = "fixed under chart"
    svg = bsc.chart(range(6), range(6), values_position = "fixed under chart")
    assert get_bottom_margin(svg) == 57 # 12+15 + 15/2 + 15*1.5
    svg = bsc.chart(range(6), range(6), values_position = "fixed under chart", font_size = 20)
    assert get_bottom_margin(svg) == 72 # 12+20 + 20/2 + 20*1.5

def test_chart_margin_auto_left():
    # default
    svg = bsc.chart(range(6), range(6))
    assert '<g id="position" transform="translate(29,' in svg

    # larger font size
    svg = bsc.chart(range(6), range(6), font_size = 20)
    assert '<g id="position" transform="translate(32,' in svg

    # legend on the left side
    svg = bsc.chart(range(6), range(6), legend_position = "left")
    assert '<g id="position" transform="translate(196.5' in svg

    # large first x tick
    svg = bsc.chart((string.ascii_lowercase, "a", "b", "c", "d",), range(6))
    assert '<g id="position" transform="translate(117,' in svg

    # large value shown on hover
    svg = bsc.chart(range(6), range(6), values_format = "•`_´• {y} ( 0 _ 0 )")
    assert '<g id="position" transform="translate(76.50,' in svg

def test_chart_margin():
    # Auto
    svg = bsc.chart(range(6), range(6), margin = "auto")
    assert '<g id="position" transform="translate(29, 27)' in svg
    assert get_right_margin(svg) == 167.5
    assert get_bottom_margin(svg) == 34.5

    # range
    svg = bsc.chart(range(6), range(6), margin = range(4))
    assert '<g id="position" transform="translate(3, 0)' in svg
    assert get_right_margin(svg) == 1
    assert get_bottom_margin(svg) == 2

    # random tuple
    svg = bsc.chart(range(6), range(6), margin = (27, 66.66666, 36.37, 10.5))
    assert '<g id="position" transform="translate(10.50, 27)' in svg
    assert get_right_margin(svg) == 66.67
    assert get_bottom_margin(svg) == 36.37

    # Balanced margin
    svg = bsc.chart(range(6), range(6), margin = [93.09] * 4)
    assert '<g id="position" transform="translate(93.09, 93.09)' in svg
    assert get_right_margin(svg) == 93.09
    assert get_bottom_margin(svg) == 93.09

    # errors
    with pytest.raises(TypeError):
        bsc.chart(range(100), y = range(100), margin = "NaN")

    with pytest.raises(TypeError):
        bsc.chart(range(100), y = range(100), margin = [1, 2])


def test_x_ticks_margin():
    # no x ticks margin
    svg = bsc.chart(range(6), range(6))
    assert bool(re.search(r"<g id=\"series_plots\"><g[^>]+><title>[^<]+</title><path [^>]+ d=\"M 0,[^>]+/><circle [^>]+ cx=\"0\"[^>]+/><text x=\"0\"", svg))

    # x ticks margin = 20
    svg = bsc.chart(range(6), range(6), width = W500, legend_position = None, x_ticks_margin = 20)
    assert '<g id="abscissa_text"><text x="20"' in svg
    assert '<use xlink:href="#vertical_dotted_lines" x="480" /></g>' in svg
    assert bool(re.search(r"<g id=\"series_plots\"><g[^>]+><title>[^<]+</title><path [^>]+ d=\"M 20,[^>]+/><circle [^>]+ cx=\"20\"[^>]+/><text x=\"20\"", svg))
    assert '<text x="480" y="-12" class="hide">5</text></g></g></g></svg>' in svg

    # bar chart: default x_ticks_margin = bar_width/2
    svg = bsc.bar_chart(x = range(5), y = [i + 1 for i in range(5)], width = W500, legend_position = None)
    assert '<g id="abscissa_text"><text x="50"' in svg
    assert '<use xlink:href="#vertical_dotted_lines" x="450" /></g>' in svg
    assert '<text x="450" y="-12" class="hide">5</text></g></g></g></svg>' in svg

    # bar chart: default x_ticks_margin = bar_width/2
    svg = bsc.bar_chart(x = range(5), y = [i + 1 for i in range(5)], width = W500, legend_position = None, bar_param = {'group_padding': 1})
    assert '<g id="abscissa_text"><text x="50"' in svg
    assert '<use xlink:href="#vertical_dotted_lines" x="450" /></g>' in svg
    assert '<g class="series color1" id="series1"><title>Data series 1</title><rect x="0"' in svg
    assert '<text x="450" y="-12" class="hide">5</text></g></g></g></svg>' in svg

    # bar chart: force x_ticks_margin = 100
    svg = bsc.bar_chart(x = range(5), y = [i + 1 for i in range(5)], width = W500, legend_position = None, bar_param = {'group_padding': 1}, x_ticks_margin = 100)
    assert '<g id="abscissa_text"><text x="100"' in svg
    assert '<use xlink:href="#vertical_dotted_lines" x="400" /></g>' in svg
    assert '<g class="series color1" id="series1"><title>Data series 1</title><rect x="62.5' in svg
    assert '<text x="400" y="-12" class="hide">5</text></g></g></g></svg>' in svg


def test_bar_param_group_padding():
    # default group_padding = 80%
    svg = bsc.bar_chart(x = range(5), y = ([i + 1 for i in range(5)], [3] * 6), width = W500, legend_position = None, tooltip_type = None)
    assert bool(re.search(r"<g id=\"series_plots\"><g[^>]+><title>[^<]+</title><rect x=\"10\" y=\"[0-9\.]+\" width=\"40\" height=\"[0-9\.]+\" /><rect x=\"110\"", svg))
    assert bool(re.search(r"<title>Data series 2</title><rect x=\"50\" y=\"[0-9\.]+\" width=\"40\" height=\"[0-9\.]+\" /><rect x=\"150\"", svg))
    assert bool(re.search(r"<rect x=\"450\" y=\"[0-9\.]+\" width=\"40\" height=\"[0-9\.]+\" /></g></g></g></svg>", svg))
    
    # No group_padding
    svg = bsc.bar_chart(x = range(5), y = ([i + 1 for i in range(5)], [3] * 6), width = W500, legend_position = None, tooltip_type = None, bar_param = {'group_padding': 1})
    assert bool(re.search(r"<g id=\"series_plots\"><g[^>]+><title>[^<]+</title><rect x=\"0\" y=\"[0-9\.]+\" width=\"50\" height=\"[0-9\.]+\" /><rect x=\"100\"", svg))
    assert bool(re.search(r"<title>Data series 2</title><rect x=\"50\" y=\"[0-9\.]+\" width=\"50\" height=\"[0-9\.]+\" /><rect x=\"150\"", svg))
    assert bool(re.search(r"<rect x=\"450\" y=\"[0-9\.]+\" width=\"50\" height=\"[0-9\.]+\" /></g></g></g></svg>", svg))
    
    # group_padding = 50%
    svg = bsc.bar_chart(x = range(5), y = ([i + 1 for i in range(5)], [3] * 6), width = W500, legend_position = None, tooltip_type = None, bar_param = {'group_padding': 0.5})
    assert bool(re.search(r"<g id=\"series_plots\"><g[^>]+><title>[^<]+</title><rect x=\"25\" y=\"[0-9\.]+\" width=\"25\" height=\"[0-9\.]+\" /><rect x=\"125\"", svg))
    assert bool(re.search(r"<title>Data series 2</title><rect x=\"50\" y=\"[0-9\.]+\" width=\"25\" height=\"[0-9\.]+\" /><rect x=\"150\"", svg))
    assert bool(re.search(r"<rect x=\"450\" y=\"[0-9\.]+\" width=\"25\" height=\"[0-9\.]+\" /></g></g></g></svg>", svg))


def test_bar_param_bar_padding():
    # default bar_padding = 100%
    svg = bsc.bar_chart(x = range(5), y = ([i + 1 for i in range(5)], [3] * 6), width = W500, legend_position = None, tooltip_type = None, bar_param = {'group_padding': 1})
    assert bool(re.search(r"<g id=\"series_plots\"><g[^>]+><title>[^<]+</title><rect x=\"0\" y=\"[0-9\.]+\" width=\"50\" height=\"[0-9\.]+\" /><rect x=\"100\"", svg))
    assert bool(re.search(r"<title>Data series 2</title><rect x=\"50\" y=\"[0-9\.]+\" width=\"50\" height=\"[0-9\.]+\" /><rect x=\"150\"", svg))
    assert bool(re.search(r"<rect x=\"450\" y=\"[0-9\.]+\" width=\"50\" height=\"[0-9\.]+\" /></g></g></g></svg>", svg))
    
    # bar padding = 80%
    svg = bsc.bar_chart(x = range(5), y = ([i + 1 for i in range(5)], [3] * 6), width = W500, legend_position = None, tooltip_type = None, bar_param = {'group_padding': 1, 'bar_padding': 0.8})
    assert bool(re.search(r"<g id=\"series_plots\"><g[^>]+><title>[^<]+</title><rect x=\"5\" y=\"[0-9\.]+\" width=\"40\" height=\"[0-9\.]+\" /><rect x=\"105\"", svg))
    assert bool(re.search(r"<title>Data series 2</title><rect x=\"55\" y=\"[0-9\.]+\" width=\"40\" height=\"[0-9\.]+\" /><rect x=\"155\"", svg))
    assert bool(re.search(r"<rect x=\"455\" y=\"[0-9\.]+\" width=\"40\" height=\"[0-9\.]+\" /></g></g></g></svg>", svg))
    
    # bar padding = 50%
    svg = bsc.bar_chart(x = range(5), y = ([i + 1 for i in range(5)], [3] * 6), width = W500, legend_position = None, tooltip_type = None, bar_param = {'group_padding': 1, 'bar_padding': 0.5})
    assert bool(re.search(r"<g id=\"series_plots\"><g[^>]+><title>[^<]+</title><rect x=\"12.50\" y=\"[0-9\.]+\" width=\"25\" height=\"[0-9\.]+\" /><rect x=\"112.50\"", svg))
    assert bool(re.search(r"<title>Data series 2</title><rect x=\"62.50\" y=\"[0-9\.]+\" width=\"25\" height=\"[0-9\.]+\" /><rect x=\"162.50\"", svg))
    assert bool(re.search(r"<rect x=\"462.50\" y=\"[0-9\.]+\" width=\"25\" height=\"[0-9\.]+\" /></g></g></g></svg>", svg))


def test_bar_param_bar_group():
    y = ([5] * 5, range(1, 6), [y/2 for y in range(3, 8)], range(5, 0, -1))
    width500 = {'width': W500, 'height': H500, 'legend_position': None}
    # default bar_param["group"]
    svg = bsc.bar_chart(x = range(5), y = y, **width500)
    assert '<g class="series color1" id="series1"><title>Data series 1</title><rect x="10" y="0" width="20" height="500" /><text x="20" y="-12" class="hide">5</text><rect x="110" y="0" width="20" height="500" />' in svg
    assert 'id="series2"><title>Data series 2</title><rect x="30"' in svg
    assert 'id="series3"><title>Data series 3</title><rect x="50"' in svg
    assert 'id="series4"><title>Data series 4</title><rect x="70"' in svg
    assert bool(re.search(r"<g id=\"abscissa_lines\"><line [^>]+ />(<use xlink:href=\"#vertical_dotted_lines\" x=\"[0-9\.]+\" />){5}</g>", svg))
    assert '<g id="abscissa_text"><text x="50" y="527">0</text><text x="150" y="527">1</text><text x="250" y="527">2</text><text x="350" y="527">3</text><text x="450" y="527">4</text></g>' in svg

    # bar_param["group"] = "x"
    svg_group_x = bsc.bar_chart(x = range(5), y = y, bar_param = {'group': "x"}, **width500)
    assert svg_group_x == svg

    # bar_param["group"] = "zzzz"
    svg = bsc.bar_chart(x = range(5), y = y, bar_param = {'group': "zzzz"}, **width500)
    assert svg == svg_group_x

    # bar_param["group"] = "series"
    svg = bsc.bar_chart(x = range(5), y = y, bar_param = {'group': "series"}, **width500)
    assert svg != svg_group_x
    assert '<g class="series color1" id="series1"><title>Data series 1</title><rect x="12.50" y="0" width="20" height="500" /><text x="22.50" y="-12" class="hide">5</text><rect x="32.50" y="0" width="20" height="500" />' in svg
    assert 'id="series2"><title>Data series 2</title><rect x="137.50"' in svg
    assert 'id="series3"><title>Data series 3</title><rect x="262.50"' in svg
    assert 'id="series4"><title>Data series 4</title><rect x="387.50"' in svg
    assert bool(re.search(r"<g id=\"abscissa_lines\"><line [^>]+ />(<use xlink:href=\"#vertical_dotted_lines\" x=\"[0-9\.]+\" />){4}</g>", svg))
    assert '<g id="abscissa_text"><text x="62.50" y="527">Data series 1</text><text x="187.50" y="527">Data series 2</text><text x="312.50" y="527">Data series 3</text><text x="437.50" y="527">Data series 4</text></g>' in svg


def test_bar_param_bar_stack():
    # default = False
    margins = (150, 150, 150, 50)
    svg = bsc.chart(x = range(5), y = (range(5), [2] * 4), chart_type = "bar", margin = margins)
    svg2 = bsc.chart(x = range(5), y = (range(5), [2] * 4), chart_type = "bar", bar_param = {'stack': False}, margin = margins)
    assert svg == svg2

    # 2 series
    svg = bsc.chart(x = range(5), y = (range(5), [2] * 4), chart_type = "bar", bar_param = {'stack': True}, margin = margins)
    assert svg != svg2
    assert '<title>Data series 1</title><rect x="220" y="400" width="160" height="100" />' in svg
    assert '<rect x="220" y="200" width="160" height="200" />' in svg
    assert '<text x="1065" y="20">Data series 2</text>' in svg
    assert '<text x="1065" y="50">Data series 1</text>' in svg

    # 4 series including scatter
    svg = bsc.chart(
        x = range(5),
        y = (range(5), [10, 9, 8, 7, 6], [2] * 4, range(1, 6)),
        chart_type = ["bar", "scatter", "bar", "bar"],
        bar_param = {'stack': True},
        margin = margins
    )
    assert '<rect x="620" y="350" width="160" height="150" />' in svg
    assert '<circle r="4" cx="700" cy="150" />' in svg
    assert '<rect x="620" y="250" width="160" height="100" />' in svg
    assert '<rect x="620" y="50" width="160" height="200" />' in svg
    assert '<text x="1065" y="20">Data series 2</text>' in svg
    assert '<text x="1065" y="50">Data series 4</text>' in svg
    assert '<text x="1065" y="80">Data series 3</text>' in svg
    assert '<text x="1065" y="110">Data series 1</text>' in svg

    # Negative and positive values
    svg = bsc.bar_chart(x = range(5), y = (range(5), [-1, -2, 2, -5, 1]), y_min = -5, y_ticks = 11, bar_param = {'stack': True}, margin = margins)
    assert '<rect x="620" y="100" width="160" height="150" />' in svg
    assert '<rect x="620" y="250" width="160" height="250" />' in svg
    assert '<rect x="820" y="50" width="160" height="200" />' in svg
    assert '<rect x="820" y="0" width="160" height="50" />' in svg

    # Values <= 0
    y = ([-i for i in range(5)], [-4] * 4, (None, -2, -1, None, -6))
    svg = bsc.bar_chart(x = range(5), y = y, bar_param = {'stack': True}, margin = margins)
    assert '<rect x="220" y="0" width="160" height="50" />' in svg
    assert '<rect x="220" y="50" width="160" height="200" />' in svg
    assert '<rect x="220" y="250" width="160" height="100" />' in svg
    assert '<text x="1065" y="20">Data series 1</text>' in svg
    assert '<text x="1065" y="50">Data series 2</text>' in svg
    assert '<text x="1065" y="80">Data series 3</text>' in svg

    # Values < 0
    y = ([-i for i in range(10, 15)], [-1] * 5)
    svg = bsc.bar_chart(x = range(5), y = y, y_max = -5, bar_param = {'stack': True}, margin = margins)
    assert '<rect x="20" y="0" width="160" height="250" />' in svg
    assert '<rect x="20" y="250" width="160" height="50" />' in svg
    assert '<text x="1065" y="20">Data series 1</text>' in svg
    assert '<text x="1065" y="50">Data series 2</text>' in svg


def test_box_plot_param_calculate_quantiles():
    # Default value = False
    svg = bsc.box_plot_chart(x = ["test"], y = range(5))
    svg2 = bsc.box_plot_chart(x = ["test"], y = range(5), box_plot_param = {'calculate_quantiles': False})
    assert 'line class="lower-whisker"' in svg
    assert 'line class="quartile1"' in svg
    assert 'line class="median"' in svg
    assert 'line class="quartile3"' in svg
    assert 'line class="upper-whisker"' in svg
    assert svg == svg2

    # calculate_quantiles = True > min, Q1, Q2, Q3, max
    y = range(0, 101)
    svg = bsc.box_plot_chart(x = ["test"], y = y, box_plot_param = {'calculate_quantiles': True}, width = 500, height = 1000, margin = [0]*4, values_position_shift = (0,0))
    assert '<line class="lower-whisker" x1="125" x2="375" y1="1000" y2="1000" /><text x="375" y="1000" class="hide">0</text>' in svg
    assert '<line class="quartile1" x1="125" x2="375" y1="755" y2="755" /><text x="375" y="755" class="hide">24.5</text>' in svg
    assert '<line class="median" x1="125" x2="375" y1="500" y2="500" /><text x="375" y="500" class="hide">50.0</text>' in svg
    assert '<line class="quartile3" x1="125" x2="375" y1="245" y2="245" /><text x="375" y="245" class="hide">75.5</text>' in svg
    assert '<line class="upper-whisker" x1="125" x2="375" y1="0" y2="0" /><text x="375" y="0" class="hide">100</text>' in svg

    # calculate_quantiles = True + whiskers = (P10, P90)
    y = range(0, 51)
    svg = bsc.box_plot_chart(x = ["test"], y = y, box_plot_param = {'calculate_quantiles': True, 'whiskers': ("P10", "P90") }, y_max = 100, width = 500, height = 1000, margin = [0]*4, values_position_shift = (0,0))
    assert '<line class="lower-whisker" x1="125" x2="375" y1="958" y2="958" /><text x="375" y="958" class="hide">4.2</text>' in svg
    assert '<line class="quartile1" x1="125" x2="375" y1="880" y2="880" /><text x="375" y="880" class="hide">12.0</text>' in svg
    assert '<line class="median" x1="125" x2="375" y1="750" y2="750" /><text x="375" y="750" class="hide">25.0</text>' in svg
    assert '<line class="quartile3" x1="125" x2="375" y1="620" y2="620" /><text x="375" y="620" class="hide">38.0</text>' in svg
    assert '<line class="upper-whisker" x1="125" x2="375" y1="542" y2="542" /><text x="375" y="542" class="hide">45.8</text>' in svg


def test_box_plot_param_whiskers():
    # Default = ("min", "max")
    svg = bsc.box_plot_chart(x = ["test"], y = range(5), box_plot_param = {'calculate_quantiles': True})
    svg2 = bsc.box_plot_chart(x = ["test"], y = range(5), box_plot_param = {'calculate_quantiles': True, 'whiskers': ["min", "max"]})
    assert 'line class="lower-whisker"' in svg
    assert 'line class="upper-whisker"' in svg
    assert svg == svg2

    # IQR
    y = (9.99, 10, 10.01, 40, 42, 43, 44, 50, 51, 51, 59, 60, 88, 91, 99) # Q1=40, Q2=50, Q3=60 -> Q1-1.5*IQR=10 ; Q3+1.5*IQR=90
    svg = bsc.box_plot_chart(x = ["test"], y = y, box_plot_param = {'calculate_quantiles': True, 'whiskers': "IQR"}, y_max = 100, height = 1000, margin = [0]*4)
    assert '<line class="lower-whisker" x1="300" x2="900" y1="900" y2="900" /><text x="900" y="888" class="hide">10</text>' in svg
    assert '<line class="upper-whisker" x1="300" x2="900" y1="120" y2="120" /><text x="900" y="108" class="hide">88</text>' in svg

    # Percentiles
    y = range(1, 1000)
    svg = bsc.box_plot_chart(x = ["test"], y = y, box_plot_param = {'calculate_quantiles': True, 'whiskers': ("P5", "P88")}, y_max = 1000, height = 1040, width = 1100, margin = (20, 50, 20, 50), values_position_shift = (0,0))
    assert '<line class="lower-whisker" x1="250" x2="750" y1="950" y2="950" /><text x="750" y="950" class="hide">50.0</text>' in svg
    assert '<line class="upper-whisker" x1="250" x2="750" y1="120" y2="120" /><text x="750" y="120" class="hide">880.0</text>' in svg

    y = range(1, 10)
    svg = bsc.box_plot_chart(x = ["test"], y = y, box_plot_param = {'calculate_quantiles': True, 'whiskers': ("P20", "P90")}, y_max = 10, height = 1040, width = 1100, margin = (20, 50, 20, 50), values_position_shift = (0,0))
    assert '<line class="lower-whisker" x1="250" x2="750" y1="800" y2="800" /><text x="750" y="800" class="hide">2.0</text>' in svg
    assert '<line class="upper-whisker" x1="250" x2="750" y1="100" y2="100" /><text x="750" y="100" class="hide">9.0</text>' in svg


def test_box_plot_param_padding():
    # Default = 0.5
    svg = bsc.box_plot_chart(x = ["test"], y = range(5))
    svg2 = bsc.box_plot_chart(x = ["test"], y = range(5), box_plot_param = {'padding': 0.5})
    assert 'line class="lower-whisker"' in svg
    assert 'line class="quartile1"' in svg
    assert 'line class="median"' in svg
    assert 'line class="quartile3"' in svg
    assert 'line class="upper-whisker"' in svg
    assert svg == svg2

    # Padding = 1
    svg = bsc.box_plot_chart(x = ["test"], y = range(1, 6), box_plot_param = {'padding': 1}, height = 500, width = 500, margin = [0] * 4)
    assert '<line class="lower-whisker" x1="0" x2="500" y1="400" y2="400" />' in svg
    assert '<line class="median" x1="0" x2="500" y1="200" y2="200" />' in svg
    assert '<line class="iqr-left-side" x1="0" x2="0" y1="300" y2="100" />' in svg
    assert '<line class="iqr-right-side" x1="500" x2="500" y1="300" y2="100" />' in svg

    # Padding = 0.2
    svg = bsc.box_plot_chart(x = ["test"], y = range(1, 6), box_plot_param = {'padding': 0.2}, height = 500, width = 500, margin = [0] * 4)
    assert '<line class="lower-whisker" x1="200" x2="300" y1="400" y2="400" />' in svg
    assert '<line class="median" x1="200" x2="300" y1="200" y2="200" />' in svg
    assert '<line class="iqr-left-side" x1="200" x2="200" y1="300" y2="100" />' in svg
    assert '<line class="iqr-right-side" x1="300" x2="300" y1="300" y2="100" />' in svg


def test_box_plot_param_mean():
    # Default: no mean
    svg = bsc.box_plot_chart(x = ["test"], y = range(5), legend_position = None)
    assert '<polyline' not in svg
    assert 'line class="quartile1"' in svg
    assert 'line class="median"' in svg
    
    # Mean = 6
    svg = bsc.box_plot_chart(x = ["test"], y = (1, 3, 4, 5, 10, 6), box_plot_param = {'mean': True}, height = 1000, width = 1000, margin = [0] * 4)
    assert '<polyline class="mean" points="490,400 500,410 510,400 500,390 490,400" /><text x="500" y="388" class="hide">6</text>' in svg
    
    # Mean = 4.5
    svg = bsc.box_plot_chart(x = ["test"], y = (2, 3, 4, 6, 10, 4.5), box_plot_param = {'mean': True}, height = 1000, width = 1000, margin = [0] * 4, values_position_shift = (0, 0))
    assert '<polyline class="mean" points="490,550 500,560 510,550 500,540 490,550" /><text x="500" y="550" class="hide">4.5</text>' in svg


def test_box_plot_param_outliers():
    # Default: no outliers
    svg = bsc.box_plot_chart(x = ["test"], y = range(5))
    assert '<circle' not in svg
    assert 'line class="quartile1"' in svg
    assert 'line class="median"' in svg

    # Whiskers = (min, max): no outliers
    svg = bsc.box_plot_chart(x = ["test"], y = range(1, 100), box_plot_param = {'calculate_quantiles': True, 'outliers': True, 'whiskers': ("min", "max")})
    assert '<circle' not in svg

    # 8 outliers
    svg = bsc.box_plot_chart(x = ["test"], y = range(1, 100), box_plot_param = {'calculate_quantiles': True, 'outliers': True, 'whiskers': ("P5", "P95")}, height = 1000, width = 1000, margin = [0] * 4, values_position_shift = (0, 0))
    assert '<circle class="outlier" r="4" cx="500" cy="990" /><text x="500" y="990" class="hide">1</text>' in svg
    assert '<circle class="outlier" r="4" cx="500" cy="30" /><text x="500" y="30" class="hide">97</text>' in svg
    assert bool(re.search(r"<line class=\"upper-line\"[^>]+/>(<circle class=\"outlier\"[^>]+/><text[^>]+>[0-9]+</text>){8}<g class=\"legend\"", svg))
    

def test_x_ticks_position_middle():
    svg = bsc.chart(x = range(6), y = range(6), width = W500, height = H500, legend_position = None)
    svg2 = bsc.chart(x = range(6), y = range(6), width = W500, height = H500, legend_position = None, x_ticks_position = "middle")
    assert svg == svg2
    assert '<g id="vertical_dotted_lines"><line stroke-width="1" stroke-linecap="square" stroke-dasharray="5.5" x1="0" x2="0" y1="0" y2="500" stroke="lightgrey" /><line x1="0" x2="0" y1="500" y2="508" stroke="black" /></g>' in svg
    assert '<g id="abscissa_lines"><line stroke-width="2" stroke-linecap="square" x1="-8" x2="500" y1="500" y2="500" stroke="black" /><use xlink:href="#vertical_dotted_lines" x="100" /><use xlink:href="#vertical_dotted_lines" x="200" />' in svg


def test_x_ticks_position_external():
    svg = bsc.bar_chart(x = range(5), y = [i + 1 for i in range(5)], x_ticks_position = "external", width = W500, height = H500, legend_position = None)
    assert '<g id="vertical_dotted_lines"><line stroke-width="1" stroke-linecap="square" stroke-dasharray="5.5" x1="0" x2="0" y1="0" y2="500" stroke="lightgrey" /></g><g id="x_ticks"><line x1="-50" x2="-50" y1="500" y2="508" stroke="black" /></g>' in svg
    assert bool(re.search(r"<g id=\"abscissa_lines\"><line [^>]+ />(<use xlink:href=\"#vertical_dotted_lines\" x=\"[0-9\.]+\" /><use xlink:href=\"#x_ticks\" x=\"[0-9\.]+\" />){5}<use xlink:href=\"#x_ticks\" x=\"550\" /></g>", svg))


def test_x_ticks_position_None():
    svg = bsc.bar_chart(x = range(5), y = [i + 1 for i in range(5)], x_ticks_position = None, width = W500, height = H500, legend_position = None)
    assert '<g id="vertical_dotted_lines"><line stroke-width="1" stroke-linecap="square" stroke-dasharray="5.5" x1="0" x2="0" y1="0" y2="500" stroke="lightgrey" /></g>' in svg
    assert bool(re.search(r"<g id=\"abscissa_lines\"><line [^>]+ />(<use xlink:href=\"#vertical_dotted_lines\" x=\"[0-9\.]+\" />){5}</g>", svg))


def test_show_only_hovered_value():
    css_circle = "circle:hover ~ circle:not(.hide), circle:not(.hide):has(~ circle:hover) {opacity: 0.2;} circle:hover ~ text, text:has(~ circle:hover) {opacity: 0;} circle:hover + text {opacity: 1; transform: none;}"
    css_rect = ".series &gt; rect:hover ~ text, .series &gt; text:has(~ rect:hover) {opacity: 0;}"

    # default parameters
    svg = bsc.chart(range(6), range(6))
    assert css_circle not in svg
    assert css_rect not in svg

    # scatter chart
    svg = bsc.chart(range(6), range(6), chart_type = "scatter")
    assert css_circle in svg
    assert css_rect not in svg

    svg = bsc.chart(range(6), range(6), chart_type = "scatter", show_only_hovered_value = False)
    assert css_circle not in svg

    # show_values
    svg = bsc.chart(range(6), range(6), show_values = "last")
    assert css_circle in svg
    assert css_rect not in svg

    svg = bsc.chart(range(6), range(6), show_values = "last", show_only_hovered_value = False)
    assert css_circle not in svg

    # tooltip_type = "title"
    svg = bsc.chart(range(6), range(6), show_values = "last", tooltip_type = "title")
    assert css_circle not in svg
    assert css_rect not in svg

    # tooltip_type = "vertical line"
    svg = bsc.chart(range(6), range(6), show_values = "last", tooltip_type = "vertical line")
    assert css_circle in svg
    assert css_rect not in svg

    # bar chart
    svg = bsc.chart(range(6), range(6), chart_type = "bar")
    assert css_rect not in svg
    assert css_circle not in svg

    # bar chart + show_values
    svg = bsc.chart(range(6), range(6), chart_type = "bar", show_values = "all")
    assert css_rect in svg
    assert css_circle not in svg

    svg = bsc.chart(range(6), range(6), chart_type = "bar", show_values = "all", show_only_hovered_value = False)
    assert css_rect not in svg


def test_names():
    # Default value
    svg = bsc.chart(x = range(6), y = range(6))
    assert '<g class="series color1" id="series1"><title>Data series 1</title>' in svg
    assert bool(re.search(r"<g class=\"legend\" id=\"legend1\"><line [^>]+ /><text[^>]+>Data series 1</text></g></g></g></g></svg", svg))

    svg = bsc.chart(x = range(6), y = [[random.random()] * 6 for i in range(10)])
    assert '<g class="series color5" id="series5"><title>Data series 5</title>' in svg
    assert bool(re.search(r"<g class=\"legend\" id=\"legend9\"><line [^>]+ /><text[^>]+>Data series 9</text>", svg))

    # Names provided
    svg = bsc.chart(x = range(6), y = range(6), names = "Series with a cool name 😎")
    assert '<g class="series color1" id="series1"><title>Series with a cool name 😎</title>' in svg
    assert bool(re.search(r"<g class=\"legend\" id=\"legend1\"><line [^>]+ /><text[^>]+>Series with a cool name 😎</text></g></g></g></g></svg", svg))

    names = ("My series name", "anticonstitutionnellement", "📊📈📉", "🚀 ?!")
    svg = bsc.chart(x = range(6), y = [[random.random()] * 6 for i in range(10)], names = names)
    assert '<g class="series color1" id="series1"><title>My series name</title>' in svg
    assert '<g class="series color2" id="series2"><title>anticonstitutionnellement</title>' in svg
    assert '<g class="series color3" id="series3"><title>📊📈📉</title>' in svg
    assert '<g class="series color4" id="series4"><title>🚀 ?!</title>' in svg
    assert '<g class="series color5" id="series5"><title>Data series 5</title>' in svg
    assert bool(re.search(r"<g class=\"legend\" id=\"legend10\"><line [^>]+ /><text[^>]+>Data series 10</text></g></g></g></g></svg", svg))


def test_legend_position_right():
    # Right = default
    svg = bsc.chart(x = range(6), y = range(6), margin = (20, 100, 20, 100), width = 1000)
    svg2 = bsc.chart(x = range(6), y = range(6), legend_position = "right", margin = (20, 100, 20, 100), width = 1000)
    assert svg == svg2
    assert '<g class="legend" id="legend1"><line stroke-width="5" x1="825" x2="850" y1="15" y2="15" /><text x="865" y="20">Data series 1</text></g>' in svg

    # Multiple series
    svg = bsc.scatter_chart(x = range(6), y = [range(6)] * 5, legend_position = "right", names = ("First name", "Last name"), margin = (20, 100, 20, 100), width = 1200)
    assert '<g class="legend" id="legend1"><circle cx="1037.50" cy="15" r="4" /><text x="1065" y="20">First name</text></g>' in svg
    assert '<g class="legend" id="legend2"><circle cx="1037.50" cy="45" r="4" /><text x="1065" y="50">Last name</text></g>' in svg
    assert '<g class="legend" id="legend3"><circle cx="1037.50" cy="75" r="4" /><text x="1065" y="80">Data series 3</text></g>' in svg

    # Font size = 30
    svg = bsc.scatter_chart(x = range(6), y = [range(6)] * 5, legend_position = "right", font_size = 30, names = ("First name", "Last name"), margin = (20, 100, 20, 100), width = 1200)
    assert '<g class="legend" id="legend1"><circle cx="1037.50" cy="30" r="4" /><text x="1065" y="40">First name</text></g>' in svg
    assert '<g class="legend" id="legend2"><circle cx="1037.50" cy="90" r="4" /><text x="1065" y="100">Last name</text></g>' in svg
    assert '<g class="legend" id="legend3"><circle cx="1037.50" cy="150" r="4" /><text x="1065" y="160">Data series 3</text></g>' in svg


def test_legend_position_left():
    # 1 series
    svg = bsc.chart(x = range(6), y = range(6), legend_position = "left", margin = (20, 100, 20, 100), width = 1000)
    assert '<g class="legend" id="legend1"><line stroke-width="5" x1="-80" x2="-55" y1="15" y2="15" /><text x="-40" y="20">Data series 1</text></g>' in svg

    # Multiple series
    svg = bsc.scatter_chart(x = range(6), y = [range(6)] * 5, legend_position = "left", names = ("First name", "Last name"), margin = (20, 100, 20, 100), width = 1200)
    assert '<g class="legend" id="legend1"><circle cx="-67.50" cy="15" r="4" /><text x="-40" y="20">First name</text></g>' in svg
    assert '<g class="legend" id="legend2"><circle cx="-67.50" cy="45" r="4" /><text x="-40" y="50">Last name</text></g>' in svg
    assert '<g class="legend" id="legend4"><circle cx="-67.50" cy="105" r="4" /><text x="-40" y="110">Data series 4</text></g>' in svg

    # Font size = 30
    svg = bsc.scatter_chart(x = range(6), y = [range(6)] * 5, legend_position = "left", font_size = 30, names = ("First name", "Last name"), margin = (20, 100, 20, 100), width = 1200)
    assert '<g class="legend" id="legend1"><circle cx="-67.50" cy="30" r="4" /><text x="-40" y="40">First name</text></g>' in svg
    assert '<g class="legend" id="legend2"><circle cx="-67.50" cy="90" r="4" /><text x="-40" y="100">Last name</text></g>' in svg
    assert '<g class="legend" id="legend4"><circle cx="-67.50" cy="210" r="4" /><text x="-40" y="220">Data series 4</text></g>' in svg


def test_legend_position_top():
    # 1 series
    svg = bsc.chart(x = range(6), y = range(6), legend_position = "top", margin = (40, 20, 40, 40))
    assert '<g class="legend" id="legend1"><line stroke-width="5" x1="5" x2="30" y1="-18.75" y2="-18.75" /><text x="45" y="-13.75">Data series 1</text></g>' in svg

    # Multiple series
    svg = bsc.scatter_chart(x = range(6), y = [range(6)] * 5, legend_position = "top", names = ("First name", "Last name"), margin = (40, 20, 40, 40))
    assert '<g class="legend" id="legend1"><circle cx="17.50" cy="-18.75" r="4" /><text x="45" y="-13.75">First name</text></g>' in svg
    assert '<g class="legend" id="legend2"><circle cx="152.50" cy="-18.75" r="4" /><text x="180" y="-13.75">Last name</text></g>' in svg
    assert '<g class="legend" id="legend5"><circle cx="595" cy="-18.75" r="4" /><text x="622.50" y="-13.75">Data series 5</text></g>' in svg

    # Font size = 30
    svg = bsc.scatter_chart(x = range(6), y = [range(6)] * 5, legend_position = "top", names = ("First name", "Last name"), font_size = 30, margin = (60, 20, 40, 40))
    assert '<g class="legend" id="legend1"><circle cx="17.50" cy="-37.50" r="4" /><text x="45" y="-27.50">First name</text></g>' in svg
    assert '<g class="legend" id="legend2"><circle cx="227.50" cy="-37.50" r="4" /><text x="255" y="-27.50">Last name</text></g>' in svg
    assert '<g class="legend" id="legend3"><circle cx="422.50" cy="-37.50" r="4" /><text x="450" y="-27.50">Data series 3</text></g>' in svg


def test_legend_position_bottom():
    # 1 series
    svg = bsc.chart(x = range(6), y = range(6), legend_position = "bottom", margin = (20, 20, 60, 40), height = 680)
    assert '<g class="legend" id="legend1"><line stroke-width="5" x1="-20" x2="5" y1="642" y2="642" /><text x="20" y="647">Data series 1</text></g>' in svg

    # Multiple series
    svg = bsc.scatter_chart(x = range(6), y = [range(6)] * 5, legend_position = "bottom", names = ("First name", "Last name"), margin = (20, 20, 60, 40), height = 680)
    assert '<g class="legend" id="legend1"><circle cx="-7.50" cy="642" r="4" /><text x="20" y="647">First name</text></g>' in svg
    assert '<g class="legend" id="legend2"><circle cx="127.50" cy="642" r="4" /><text x="155" y="647">Last name</text></g>' in svg
    assert '<g class="legend" id="legend3"><circle cx="255" cy="642" r="4" /><text x="282.50" y="647">Data series 3</text></g>' in svg

    # Font size = 9
    svg = bsc.scatter_chart(x = range(6), y = [range(6)] * 5, legend_position = "bottom", names = ("First name", "Last name"), margin = (20, 20, 60, 40), height = 680, font_size = 9)
    assert '<g class="legend" id="legend1"><circle cx="-7.50" cy="630" r="4" /><text x="20" y="633">First name</text></g>' in svg
    assert '<g class="legend" id="legend2"><circle cx="97.50" cy="630" r="4" /><text x="125" y="633">Last name</text></g>' in svg
    assert '<g class="legend" id="legend4"><circle cx="316.50" cy="630" r="4" /><text x="344" y="633">Data series 4</text></g>' in svg


def test_legend_position_top_left():
    # 1 series
    svg = bsc.chart(x = range(6), y = range(6), legend_position = "top left", margin = [40] * 4)
    assert '<g class="legend" id="legend1"><line stroke-width="5" x1="20" x2="45" y1="15" y2="15" /><text x="60" y="20">Data series 1</text></g>' in svg

    # Multiple series
    svg = bsc.scatter_chart(x = range(6), y = [range(6)] * 5, legend_position = "top left", names = ("First name", "Last name"), margin = [40] * 4)
    assert '<g class="legend" id="legend1"><circle cx="32.50" cy="15" r="4" /><text x="60" y="20">First name</text></g>' in svg
    assert '<g class="legend" id="legend2"><circle cx="32.50" cy="45" r="4" /><text x="60" y="50">Last name</text></g>' in svg
    assert '<g class="legend" id="legend4"><circle cx="32.50" cy="105" r="4" /><text x="60" y="110">Data series 4</text></g>' in svg

    # Font size = 27
    svg = bsc.scatter_chart(x = range(6), y = [range(6)] * 5, legend_position = "top left", names = ("First name", "Last name"), margin = [40] * 4, font_size = 27)
    assert '<g class="legend" id="legend1"><circle cx="32.50" cy="27" r="4" /><text x="60" y="36">First name</text></g>' in svg
    assert '<g class="legend" id="legend2"><circle cx="32.50" cy="81" r="4" /><text x="60" y="90">Last name</text></g>' in svg
    assert '<g class="legend" id="legend5"><circle cx="32.50" cy="243" r="4" /><text x="60" y="252">Data series 5</text></g>' in svg


def test_legend_position_top_right():
    # 1 series
    svg = bsc.chart(x = range(6), y = range(6, 0, -1), legend_position = "top right", margin = [40] * 4)
    assert '<g class="legend" id="legend1"><line stroke-width="5" x1="952.50" x2="977.50" y1="15" y2="15" /><text x="992.50" y="20">Data series 1</text></g>' in svg

    # Multiple series
    svg = bsc.scatter_chart(x = range(6), y = [range(6, 0, -1)] * 5, legend_position = "top right", names = ("First name", "Last name"), margin = [40] * 4)
    assert '<g class="legend" id="legend1"><circle cx="965" cy="15" r="4" /><text x="992.50" y="20">First name</text></g>' in svg
    assert '<g class="legend" id="legend2"><circle cx="965" cy="45" r="4" /><text x="992.50" y="50">Last name</text></g>' in svg
    assert '<g class="legend" id="legend5"><circle cx="965" cy="135" r="4" /><text x="992.50" y="140">Data series 5</text></g>' in svg

    # Font size = 18
    svg = bsc.scatter_chart(x = range(6), y = [range(6, 0, -1)] * 5, legend_position = "top right", names = ("First name", "Last name"), margin = [40] * 4, font_size = 18)
    assert '<g class="legend" id="legend1"><circle cx="945.50" cy="18" r="4" /><text x="973" y="24">First name</text></g>' in svg
    assert '<g class="legend" id="legend2"><circle cx="945.50" cy="54" r="4" /><text x="973" y="60">Last name</text></g>' in svg
    assert '<g class="legend" id="legend3"><circle cx="945.50" cy="90" r="4" /><text x="973" y="96">Data series 3</text></g>' in svg


def test_legend_position_bottom_right():
    # 1 series
    svg = bsc.chart(x = range(6), y = range(6), legend_position = "bottom right", margin = [40] * 4, height = 680)
    assert '<g class="legend" id="legend1"><line stroke-width="5" x1="952.50" x2="977.50" y1="570" y2="570" /><text x="992.50" y="575">Data series 1</text></g>' in svg

    # Multiple series
    svg = bsc.scatter_chart(x = range(6), y = [range(6)] * 5, legend_position = "bottom right", names = ("First name", "Last name"), margin = [40] * 4, height = 680)
    assert '<g class="legend" id="legend1"><circle cx="965" cy="450" r="4" /><text x="992.50" y="455">First name</text></g>' in svg
    assert '<g class="legend" id="legend2"><circle cx="965" cy="480" r="4" /><text x="992.50" y="485">Last name</text></g>' in svg
    assert '<g class="legend" id="legend3"><circle cx="965" cy="510" r="4" /><text x="992.50" y="515">Data series 3</text></g>' in svg

    # Font size = 21
    svg = bsc.scatter_chart(x = range(6), y = [range(6)] * 5, legend_position = "bottom right", names = ("First name", "Last name"), margin = [40] * 4, height = 680, font_size = 21)
    assert '<g class="legend" id="legend1"><circle cx="926" cy="390" r="4" /><text x="953.50" y="397">First name</text></g>' in svg
    assert '<g class="legend" id="legend2"><circle cx="926" cy="432" r="4" /><text x="953.50" y="439">Last name</text></g>' in svg
    assert '<g class="legend" id="legend4"><circle cx="926" cy="516" r="4" /><text x="953.50" y="523">Data series 4</text></g>' in svg


def test_legend_position_bottom_left():
    # 1 series
    svg = bsc.chart(x = range(6), y = range(6, 0, -1), legend_position = "bottom left", margin = [40] * 4, height = 680)
    assert '<g class="legend" id="legend1"><line stroke-width="5" x1="20" x2="45" y1="570" y2="570" /><text x="60" y="575">Data series 1</text></g>' in svg

    # Multiple series
    svg = bsc.scatter_chart(x = range(6), y = [range(6, 0, -1)] * 5, legend_position = "bottom left", names = ("First name", "Last name"), margin = [40] * 4, height = 680)
    assert '<g class="legend" id="legend1"><circle cx="32.50" cy="450" r="4" /><text x="60" y="455">First name</text></g>' in svg
    assert '<g class="legend" id="legend2"><circle cx="32.50" cy="480" r="4" /><text x="60" y="485">Last name</text></g>' in svg
    assert '<g class="legend" id="legend4"><circle cx="32.50" cy="540" r="4" /><text x="60" y="545">Data series 4</text></g>' in svg

    # Font size = 12
    svg = bsc.scatter_chart(x = range(6), y = [range(6, 0, -1)] * 5, legend_position = "bottom left", names = ("First name", "Last name"), font_size = 12, margin = [40] * 4, height = 680)
    assert '<g class="legend" id="legend1"><circle cx="32.50" cy="480" r="4" /><text x="60" y="484">First name</text></g>' in svg
    assert '<g class="legend" id="legend2"><circle cx="32.50" cy="504" r="4" /><text x="60" y="508">Last name</text></g>' in svg
    assert '<g class="legend" id="legend5"><circle cx="32.50" cy="576" r="4" /><text x="60" y="580">Data series 5</text></g>' in svg


def test_legend_background():
    # Default = None
    svg = bsc.chart(x = range(6), y = range(6), margin = (20, 100, 20, 100), width = 1000)
    svg2 = bsc.chart(x = range(6), y = range(6), legend_background = None, margin = (20, 100, 20, 100), width = 1000)
    assert svg == svg2
    assert '<rect id="legend_bg"' not in svg

    # Color
    svg = bsc.chart(x = range(6), y = range(6), legend_background = "red", margin = (20, 100, 20, 100), width = 1000)
    assert '<rect id="legend_bg" opacity="0.7" x="820" width="167.50" y="2" height="26" fill="red" />' in svg

    # Multiple series + hex code
    svg = bsc.chart(x = range(6), y = [range(6)] * 5, legend_background = "#12ab89", margin = (20, 100, 20, 100), width = 1000)
    assert '<rect id="legend_bg" opacity="0.7" x="820" width="167.50" y="2" height="146" fill="#12ab89" />' in svg

    # Legend top
    svg = bsc.chart(x = range(6), y = [range(6)] * 5, legend_background = "rgb(245, 245, 235)", legend_position = "top", font_size = 20, margin = (50, 100, 50, 100), width = 1200)
    assert '<rect id="legend_bg" opacity="0.7" x="0" width="975" y="-43" height="36" fill="rgb(245, 245, 235)" />' in svg


def test_lang():
    # Default value: no lang
    svg = bsc.chart(x = range(6), y = range(6))
    assert '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1200 800" style="font-size: 15px" role="img" width="1200" height="800">' in svg
    assert "lang" not in svg

    svg = bsc.chart(x = range(6), y = range(6), lang = "fr")
    assert '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1200 800" style="font-size: 15px" role="img" width="1200" height="800" lang="fr" xml:lang="fr">' in svg

    svg = bsc.chart(x = range(6), y = range(6), lang = "es-ES")
    assert '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1200 800" style="font-size: 15px" role="img" width="1200" height="800" lang="es-ES" xml:lang="es-ES">' in svg


def test_width():
    # Default value: 1200
    svg = bsc.chart(x = range(6), y = range(6))
    assert 'viewBox="0 0 1200' in svg
    assert 'width="1200"' in svg

    # Other integer
    svg = bsc.chart(x = range(6), y = range(6), width = 500)
    assert 'viewBox="0 0 500' in svg
    assert 'width="500"' in svg

    # Other float
    svg = bsc.chart(x = range(6), y = range(6), width = 1234.56789)
    assert 'viewBox="0 0 1234.56789' in svg
    assert 'width="1234.56789"' in svg


def test_height():
    # Default value: 800
    svg = bsc.chart(x = range(6), y = range(6))
    assert 'viewBox="0 0 1200 800"' in svg
    assert 'height="800"' in svg

    # Other integer
    svg = bsc.chart(x = range(6), y = range(6), height = 500)
    assert bool(re.search(r"viewBox=\"0 0 [0-9\.]+ 500\"", svg))
    assert 'height="500"' in svg

    # Other float
    svg = bsc.chart(x = range(6), y = range(6), height = 876.5)
    assert bool(re.search(r"viewBox=\"0 0 [0-9\.]+ 876.5\"", svg))
    assert 'height="876.5"' in svg


def test_fullscreen():
    # Default value: False
    svg = bsc.chart(x = range(6), y = range(6))
    assert 'viewBox="0 0 1200 800' in svg
    assert 'width="1200"' in svg
    assert 'height="800"' in svg

    # True
    svg = bsc.chart(x = range(6), y = range(6), fullscreen = True)
    assert '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1200 800" style="font-size: 15px" role="img">' in svg


def test_big_mark():
    # Default: big_mark = ""
    svg = bsc.chart(x = range(0, 6000000, 1000000), y = range(0, 6000000, 1000000))
    assert '<use xlink:href="#horizontal_dotted_lines" y="0" /><text x="-14" y="0">5000000</text>' in svg
    assert "3000000" in svg

    # big_mark = " " without formatting
    svg = bsc.chart(x = range(0, 6000000, 1000000), y = range(0, 6000000, 1000000), big_mark = " ")
    assert '<use xlink:href="#horizontal_dotted_lines" y="0" /><text x="-14" y="0">5000000</text>' in svg
    assert "3000000" in svg

    # big_mark = "*" with formatting
    svg = bsc.chart(x = range(0, 6000000, 1000000), y = range(0, 6000000, 1000000), big_mark = "*", y_ticks_format = "{:_}")
    assert '<use xlink:href="#horizontal_dotted_lines" y="0" /><text x="-14" y="0">5*000*000</text>' in svg
    assert "3*000*000" in svg

    # lang = "fr" -> big_mark = " "
    svg = bsc.chart(x = range(0, 6000000, 1000000), y = range(0, 6000000, 1000000), lang = "fr", y_ticks_format = "{:_}")
    assert '<use xlink:href="#horizontal_dotted_lines" y="0" /><text x="-14" y="0">5 000 000</text>' in svg
    assert "3 000 000" in svg


def test_decimal_mark():
    # Default: decimal_mark = "."
    svg = bsc.chart(x = range(6), y = [y/10 for y in range(6)])
    assert '<use xlink:href="#horizontal_dotted_lines" y="0" /><text x="-14" y="0">0.5</text>' in svg
    assert "0.3" in svg

    # decimal_mark = "δ"
    svg = bsc.chart(x = range(6), y = [y/10 for y in range(6)], decimal_mark = "δ")
    assert '<use xlink:href="#horizontal_dotted_lines" y="0" /><text x="-14" y="0">0δ5</text>' in svg
    assert "0δ3" in svg

    # lang = "fr" -> decimal_mark = ","
    svg = bsc.chart(x = range(6), y = [y/10 for y in range(6)], lang = "fr")
    assert '<use xlink:href="#horizontal_dotted_lines" y="0" /><text x="-14" y="0">0,5</text>' in svg
    assert "0,3" in svg


def test_css():
    # No extra css
    svg = bsc.chart(x = range(6), y = range(6))
    assert 'feFlood {flood-color: black; flood-opacity: 0.7;} } </style><rect class="background-color"' in svg
    
    # 1 css declaration
    svg = bsc.chart(x = range(6), y = range(6), css = "text.title {font-size: 1em;}", title = "Chart title")
    assert 'text.title {font-size: 1em;} </style><rect class="background-color"' in svg

    # Multiple css declarations
    css = ["#legend1 {transform: translate(-20px);}", "#ordinate > text {fill: green;}", ".series > path {stroke-width: 5;}"]
    svg = bsc.chart(x = range(6), y = range(6), css = css)
    assert '#legend1 {transform: translate(-20px);} #ordinate &gt; text {fill: green;} .series &gt; path {stroke-width: 5;} </style><rect class="background-color"' in svg

    # Pretty
    svg = bsc.chart(x = range(6), y = range(6), css = css, pretty = True)
    assert '\n    }\n    #legend1 {transform: translate(-20px);}\n    #ordinate &gt; text {fill: green;}\n    .series &gt; path {stroke-width: 5;}\n</style>\n  <rect class="background-color"' in svg


def test_notes():
    # Default: no note
    svg = bsc.chart(x = range(6), y = range(6))
    assert '<text id="notes"' not in svg

    # Single note
    svg = bsc.chart(x = range(6), y = range(6), notes = "This is a note.", height = 800)
    assert '<text id="notes" y="743"><tspan x="-9" dy="1.5em">This is a note.</tspan></text></g></svg>' in svg

    # Multi notes
    notes = (
        "First note",
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non risus. Suspendisse lectus tortor, dignissim sit amet, adipiscing nec, ultricies sed, dolor.",
        "Emojis: ✅🦊🦝🫏🐘🐻🦔🐿️🦄",
    )
    svg = bsc.chart(x = range(6), y = range(6), notes = notes)
    tspan_notes = "".join([f'<tspan x="-9" dy="1.5em">{n}</tspan>' for n in notes])
    assert f'<text id="notes" y="698">{tspan_notes}</text>' in svg

    # Italic and bold
    svg = bsc.chart(x = range(6), y = range(6), notes = ["<i>Italic note", "<b>Bold note"])
    assert bool(re.search(r'<text id="notes"[^>]+><tspan x="-9" dy="1.5em" font-style="italic">Italic note</tspan><tspan x="-9" dy="1.5em" font-weight="bold">Bold note</tspan></text>', svg))

    # SVG notes
    notes = (
        "Source: <a href='https://www.data.gouv.fr/'>datagouv</a>.",
        "<i><tspan class='abbr'>CH<tspan dominant-baseline='middle'>4</tspan><title>Methane</title></tspan>"
    )
    svg = bsc.chart(x = range(6), y = range(6), notes = notes)
    assert bool(re.search(r'<text id="notes"[^>]+><tspan x="-9" dy="1.5em">Source: <a href="https://www.data.gouv.fr/">datagouv</a>.</tspan><tspan x="-9" dy="1.5em" font-style="italic"><tspan class="abbr">CH<tspan dominant-baseline="middle">4</tspan><title>Methane</title></tspan></tspan></text>', svg))


def test_font_size():
    # Default = 15
    svg = bsc.chart(x = range(6), y = range(6), title = "Fake title")
    svg2 = bsc.chart(x = range(6), y = range(6), font_size = 15, title = "Fake title")
    assert svg == svg2
    assert 'style="font-size: 15px"' in svg
    assert '<g id="position" transform="translate(29, 42)">' in svg
    
    svg = bsc.chart(x = range(6), y = range(6), font_size = 10, title = "Fake title")
    assert 'style="font-size: 10px"' in svg
    assert '<g id="position" transform="translate(26, 28)">' in svg
    
    svg = bsc.chart(x = range(6), y = range(6), font_size = 23.456789, title = "Fake title")
    assert 'style="font-size: 23.456789px"' in svg
    assert '<g id="position" transform="translate(34, 65.68)">' in svg


def test_background_color():
    # Default = "auto"
    svg = bsc.chart(x = range(6), y = range(6))
    svg2 = bsc.chart(x = range(6), y = range(6), background_color = "auto")
    svg3 = bsc.chart(x = range(6), y = range(6), background_color = "white", dark_mode = "user")
    assert svg == svg2
    assert svg == svg3
    assert '<rect class="background-color" width="100%" height="100%" />' in svg
    assert 'rect.background-color {fill: white;}' in svg
    assert '@media (prefers-color-scheme: dark) {   rect.background-color {display: none;}' in svg

    # dark_mode = force
    svg = bsc.chart(x = range(6), y = range(6), dark_mode = "force")
    assert '<rect class="background-color" width="100%" height="100%" />' in svg
    assert 'rect.background-color {fill: black;}' in svg
    assert 'rect.background-color {display: none;}' not in svg

    # None
    svg = bsc.chart(x = range(6), y = range(6), background_color = None)
    assert '<rect class="background-color" width="100%" height="100%" />' not in svg

    # green
    svg = bsc.chart(x = range(6), y = range(6), background_color = "green")
    assert '<rect class="background-color" width="100%" height="100%" />' in svg
    assert 'rect.background-color {fill: green;}' in svg

    # #e91585
    svg = bsc.chart(x = range(6), y = range(6), background_color = "#e91585")
    assert '<rect class="background-color" width="100%" height="100%" />' in svg
    assert 'rect.background-color {fill: #e91585;}' in svg


def test_dark_mode():
    # Default = "user"
    svg = bsc.chart(x = range(6), y = range(6))
    svg2 = bsc.chart(x = range(6), y = range(6), dark_mode = "user")
    assert svg == svg2
    assert ":root {color-scheme: light dark;}" in svg
    assert "@media (prefers-color-scheme: dark) {   rect.background-color {display: none;}" in svg
    assert "text {fill: white;}" in svg

    # dark_mode = "force"
    svg = bsc.chart(x = range(6), y = range(6), dark_mode = "force")
    assert ":root {color-scheme: dark;}" in svg
    assert "@media (prefers-color-scheme: dark)" not in svg
    assert "text {fill: white;}" in svg
    assert "filter#bg_abs &gt; feFlood {flood-color: green;}" in svg


def test_pretty():
    # Default = False
    svg = bsc.chart(x = range(6), y = range(6))
    svg2 = bsc.chart(x = range(6), y = range(6), pretty = False)
    assert svg == svg2
    assert '<style type="text/css"> text.title {font-weight: bold; font-size: 1.4em; text-anchor: middle;}' in svg
    assert 'Data series 1</text></g></g></g></g></svg>' in svg

    # pretty = True
    svg = bsc.chart(x = range(6), y = range(6), pretty = True)
    assert '<style type="text/css">\n    text.title {font-weight: bold; font-size: 1.4em; text-anchor: middle;}' in svg
    assert 'Data series 1</text>\n        </g>\n      </g>\n    </g>\n  </g>\n</svg>' in svg
