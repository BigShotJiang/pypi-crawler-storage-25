""" Basic SVG charting library """

# from .basic_svg_chart import *
from .basic_svg_chart import chart, line_chart, scatter_chart, scatter_line_chart, bar_chart, box_plot_chart, replace_tags, num_attr, OKABE_ITO, VIRIDIS

# https://docs.python.org/3/tutorial/modules.html#importing-from-a-package
__all__ = ["chart", "line_chart", "scatter_chart", "scatter_line_chart", "bar_chart", "box_plot_chart", "replace_tags", "num_attr", "OKABE_ITO", "VIRIDIS"]

__version__ = "0.2.1"

