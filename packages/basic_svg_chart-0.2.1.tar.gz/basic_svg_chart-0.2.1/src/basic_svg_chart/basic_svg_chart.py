""" Basic SVG charting library """
# /// script
# requires-python = ">=3.10"
# ///

import xml.etree.ElementTree as ET
import math
import copy
import sys
import re
from types import SimpleNamespace # https://stackoverflow.com/questions/16279212/how-to-use-dot-notation-for-dict-in-python#16279578
from collections.abc import Sequence # https://docs.python.org/3/library/stdtypes.html#sequence-types-list-tuple-range
import logging
import statistics
import os

# Default tooltip title format
DEFAULT_TOOLTIP = "{name}: x = {x}{x_unit}, y = {y}{y_unit}"

# Okabe-Ito palette:
# https://siegal.bio.nyu.edu/color-palette/
# https://jfly.uni-koeln.de/color/
OKABE_ITO = ("#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7", "grey") # "grey" instead or "black" in case of dark mode used

# Viridis palette: https://waldyrious.net/viridis-palette-generator/
VIRIDIS =  (
("black"),
('#440154', '#fde725'),
('#440154', '#21918c', '#fde725'),
('#440154', '#31688e', '#35b779', '#fde725'),
('#440154', '#3b528b', '#21918c', '#5ec962', '#fde725'),
('#440154', '#414487', '#2a788e', '#22a884', '#7ad151', '#fde725'),
('#440154', '#443983', '#31688e', '#21918c', '#35b779', '#90d743', '#fde725'),
('#440154', '#46327e', '#365c8d', '#277f8e', '#1fa187', '#4ac16d', '#a0da39', '#fde725'),
('#440154', '#472d7b', '#3b528b', '#2c728e', '#21918c', '#28ae80', '#5ec962', '#addc30', '#fde725'),
('#440154', '#482878', '#3e4989', '#31688e', '#26828e', '#1f9e89', '#35b779', '#6ece58', '#b5de2b', '#fde725'),
('#440154', '#482475', '#414487', '#355f8d', '#2a788e', '#21918c', '#22a884', '#44bf70', '#7ad151', '#bddf26', '#fde725'),
('#440154', '#482173', '#433e85', '#38588c', '#2d708e', '#25858e', '#1e9b8a', '#2ab07f', '#52c569', '#86d549', '#c2df23', '#fde725'),
('#440154', '#481f70', '#443983', '#3b528b', '#31688e', '#287c8e', '#21918c', '#20a486', '#35b779', '#5ec962', '#90d743', '#c8e020', '#fde725'),
('#440154', '#481c6e', '#453581', '#3d4d8a', '#34618d', '#2b748e', '#24878e', '#1f998a', '#25ac82', '#40bd72', '#67cc5c', '#98d83e', '#cde11d', '#fde725'),
('#440154', '#481b6d', '#46327e', '#3f4788', '#365c8d', '#2e6e8e', '#277f8e', '#21918c', '#1fa187', '#2db27d', '#4ac16d', '#73d056', '#a0da39', '#d0e11c', '#fde725'),
('#440154', '#481a6c', '#472f7d', '#414487', '#39568c', '#31688e', '#2a788e', '#23888e', '#1f988b', '#22a884', '#35b779', '#54c568', '#7ad151', '#a5db36', '#d2e21b', '#fde725'),
('#440154', '#48186a', '#472d7b', '#424086', '#3b528b', '#33638d', '#2c728e', '#26828e', '#21918c', '#1fa088', '#28ae80', '#3fbc73', '#5ec962', '#84d44b', '#addc30', '#d8e219', '#fde725'),
('#440154', '#481769', '#472a7a', '#433d84', '#3d4e8a', '#355e8d', '#2e6d8e', '#297b8e', '#23898e', '#1f978b', '#21a585', '#2eb37c', '#46c06f', '#65cb5e', '#89d548', '#b0dd2f', '#d8e219', '#fde725'),
('#440154', '#481668', '#482878', '#443983', '#3e4989', '#375a8c', '#31688e', '#2b758e', '#26828e', '#21918c', '#1f9e89', '#25ab82', '#35b779', '#4ec36b', '#6ece58', '#90d743', '#b5de2b', '#dae319', '#fde725'),
('#440154', '#481467', '#482576', '#453781', '#404688', '#39558c', '#33638d', '#2d718e', '#287d8e', '#238a8d', '#1f968b', '#20a386', '#29af7f', '#3dbc74', '#56c667', '#75d054', '#95d840', '#bade28', '#dde318', '#fde725')
)

# CSS style added to all charts (will be extended according to the parameters)
DEFAULT_CSS = (
    "text.title {font-weight: bold; font-size: 1.4em; text-anchor: middle;}",
    "g.series > path:hover {stroke-width: 5px;}",
    "g#series_plots:hover .series {opacity: 0.2;}",
    "g#series_plots > g.series:hover {opacity: 1;}",
    ".abbr {cursor: help; text-decoration:underline dashed; text-underline-position: under; text-decoration-thickness: 1.5px;}",
    "a {fill: darkblue;}",
    "a:hover {text-decoration: underline;}",
    "g#ordinate > text {text-anchor: end; dominant-baseline: central;}",
    "g#ordinate > text.unit {text-anchor: start;}",
    "g#abscissa_text > text {text-anchor: middle;}",
    ".hide {opacity: 0;}",
    "circle:hover + text.hide {opacity: 1; transform: none;}",
    "circle.hide:hover {opacity: 1;}",
)

# Default CSS style for dark mode
DARK_MODE_CSS = (
    "text {fill: white;}", # text:not([fill])
    "[stroke='black'] {stroke: white;}",
    "line[stroke-dasharray] {stroke: grey;}",
    "a {fill: deepskyblue;}",
    "g#series_plots:hover .series {opacity: 0.4;}",
    "rect#legend_bg[fill='white'] {fill: black;}",
    ".hover_values > line {stroke: white;}",
    "filter#bg_abs > feFlood {flood-color: green;}",
    "filter#bg_val > feFlood {flood-color: black; flood-opacity: 0.7;}",
)

# text-anchor CSS property for values shown of the chart, depending on `values_position` parameter
# https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/text-anchor
VALUES_ANCHOR = {
    'top': "middle",
    'bottom': "middle",
    'right': "start",
    'left': "end",
    'fixed above chart': "start",
    'fixed under chart': "start",
}

# Default (x, y) shift from the data point for values shown of the chart, depending on `values_position`
DEFAULT_VALUES_POSITION_SHIFT = {
    'top': (0, -12),
    'bottom': (0, 20),
    'right': (12, 0),
    'left': (-12, 0),
}

# Number of decimals for various coordinates (x, y, path, rect width and height...) defined in the SVG output
if "CHART_DECIMALS" in os.environ:
    CHART_DECIMALS = int(os.environ["CHART_DECIMALS"])
    chart_decimals_defined = True
else:
    CHART_DECIMALS = 2
    chart_decimals_defined = False


# Define some Union types reused several times
# https://docs.python.org/3/whatsnew/3.10.html#pep-604-new-type-union-operator
Number = int | float
Number_or_string = int | float | str
Seq = list | tuple | range

def chart(
    x: Sequence[Number_or_string] = None,
    y: Sequence[Sequence[Number | None]] | Sequence[Number | None] = None,
    xy: Sequence[Sequence[Sequence[Number_or_string]]] = None,
    chart_type: str | Sequence[str] = "line",
    bar_param: dict = {'group_padding': 0.8, 'bar_padding': 1, 'group': "x", 'stack': False},
    box_plot_param: dict = {'calculate_quantiles': False, 'whiskers': ("min", "max"), 'padding': 0.5, 'mean': False, 'outliers': False},
    names: Sequence[str] | str = None,
    title: str = None,
    desc: str = None,
    lang: str = None,
    colors: Sequence[str] = None,
    width: Number = 1200,
    height: Number = 800,
    fullscreen: bool = False,
    margin: str | Sequence[Number] = "auto",
    x_unit: str = None,
    y_unit: str = None,
    x_ticks: int | Sequence[Number_or_string] = 6,
    x_axis_discrete: bool = True,
    x_ticks_margin: int | float = None,
    x_ticks_position: str | None = "middle",
    y_ticks: int | Sequence[Number] = 6,
    y_ticks_interval: Number = None,
    y_min: Number | None = 0,
    y_max: Number = None,
    big_mark: str = None,
    decimal_mark: str = None,
    x_ticks_format: str = "{:n}",
    y_ticks_format: str = "{:n}",
    show_values: str | Sequence[Number_or_string] = None,
    values_position: str = "top",
    values_position_shift: Sequence[Number] = None,
    values_format: str | Sequence[str] = "{y}{y_unit}",
    show_only_hovered_value: bool = True,
    tooltip_type: str | Sequence[str] = "value",
    title_tooltip_format: str | Sequence[str] = DEFAULT_TOOLTIP,
    extra_data: Sequence[Sequence[Number_or_string]] | Sequence[Number_or_string] = None,
    circles: Number = 4,
    extra_lines: Sequence[dict] | dict = None,
    legend_position: str = "right",
    legend_background: str = None,
    css: Sequence[str] | str = None,
    notes: str | Sequence[str] = None,
    font_size: Number = 15,
    background_color: str = "auto",
    dark_mode: str = "user",
    pretty: bool = False,
    output: str = "string",
    **kwargs
) -> str | ET.Element:
    
    """
    Create a SVG chart

    Parameters
    ----------
    x : Sequence[int | float | str]
        The x values.
    y : Sequence[Sequence[int | float | None]] | Sequence[int | float | None]
        The y values. If multiple series must be drawn, must be a sequence of sequences.
        If some series has missing values, they have to be specified with None. If series sequence length < len(x), the last values will be missing.
    xy: Sequence[Sequence[Sequence[int | float | str]]], optional
        If `x` and `y` are not provided, `xy` must contains the data points expressed as a sequence of series,
        where each series is a sequence of points where each point is a sequence of 2 elements: x and y as (x, y).
    chart_type : str | Sequence[str], optional, default "line"
        The type of the chart, can be "line", "scatter", "scatter line", "bar" or "box plot".
        If a sequence is provided and there are multiple series, each series will have the specified type (based on sequence position, same as `y`).
    bar_param: dict, optional, default {'group_padding': 0.8, 'bar_padding': 1, 'group': "x", 'stack': False}
        Specific parameters for bar charts.
        * bar_param["group_padding"] (default 0.8) is a float between 0 and 1 defining the space used by the group of <rect> elements / the maximum available space between 2 groups of <rect>s.
        * bar_param["bar_padding"] (default 1) is a float between 0 and 1 defining the space used by each <rect> / the maximum available space between 2 <rect>s.
        * bar_param["group"] defines how bars are grouped, with 2 possibles values:
            - "x" (the default) for grouping by x values (like line charts): first bar (on the left) is x1 for series1, then x1 for series2...
            - "series" for grouping by series: first bar (on the left) is x1 for series1 then x2 for series1...
        * bar_param["stack"] (default False) defines if bars must be stacked for each x. When bars are stacked, the first series (as defined in `y` sequence order) will be the closest to 0, and then stack follow series order.
    box_plot_param: dict, optional, default {'calculate_quantiles': False, 'whiskers': ("min", "max"), 'padding': 0.5, 'mean': False, 'outliers': False}
        Specific parameters for box plot charts.
        * box_plot_param["calculate_quantiles"] (default False): if True, `y` values will be converted to [lower whisker, Q1, Q2, Q3, upper whisker]. Builtin method statistics.quantiles (https://docs.python.org/3/library/statistics.html#statistics.quantiles) is used to calculate the values.
        * box_plot_param["whiskers"] (default ["min", "max"]): if box_plot_param["calculate_quantiles"] is True, define the metrics used for whiskers. Can be either "IQR" ([Q1-1.5*IQR, Q3-1.5*IQR], see https://en.wikipedia.org/wiki/Box_plot#Whiskers) or a couple (lower, upper) where lower and upper can be "min", "max" or a percentile as "Pn".
        * box_plot_param["padding"] (default 0.5): Define the width of the box as a percentage of the maximum possible width.
        * box_plot_param["mean"] (default False): if True, the mean will be added (and calculated if box_plot_param["calculate_quantiles"]) and represented as a diamond.
        * box_plot_param["outliers"] (default False): if True and box_plot_param["calculate_quantiles"] is True, the outliers will be added and represented as circles.
    names : Sequence[str] | str, optional
        Names of a the series. The position in the sequence must match the position of the series in y sequence.
        If not provided (or less names than the number of series defined in y), defaults to "Data series n" (with `n` incremental) or to `title` if there is just one series.
    title : str, optional
        The optional title of the chart. If provided, will be printed as a <text> element above the plotting area + a <title> element.
    desc : str
        The optional description of the chart, used in a <desc> element which is referenced by the <svg> `aria-describedby` attribute.
    lang : str, optional
        A BCP 47 language tag used in `lang` and `xml:lang` attributes added to the root <svg> element.
        If "fr" then `big_mark` parameter defaults to " " and `decimal_mark` to ",".
        See: https://developer.mozilla.org/en-US/docs/Glossary/BCP_47_language_tag.
    colors : Sequence[str], optional
        The colors of the series. Can be a color name (e.g. "green"), a hex code (e.g. "#e91585") or a RGB triplet (e.g. "rgb(0, 191, 255)").
        If not provided (or less colors than the number of series defined in y), defaults to Okabe-Ito palette if 8 series or less, and Viridis palette if 9 <= len(series) <= 20.
        If more than 20 series in `y`, `colors` must be provided.
        Color names: https://www.w3schools.com/tags/ref_colornames.asp
        Okabe-Ito palette: https://siegal.bio.nyu.edu/color-palette
        Viridis palette: https://waldyrious.net/viridis-palette-generator
    width : int | float, optional, default 1200
        The width of the <svg> element. Used in a `viewbox` attribute (viewBox="0 0 {width} {height}").
        Will also be used in a <svg> `width` attribute if `fullscreen` = False.
    height : int | float, optional, default 800
        The height of the <svg> element. Used in a `viewbox` attribute (viewBox="0 0 {width} {height}")
        Will also be used in a <svg> `height` attribute if `fullscreen` = False.
    fullscreen : bool, optional, default False
        If False (the default), the root <svg> element will have `width` and `height` attributes as specified in the eponymous parameters.
    margin: str | Sequence[int | float], optional, default "auto"
        Define the margins around the chart area.
        Defaults to "auto" which try to calculate « optimal » margins depending on all elements of the chart (title, legend, units, notes...).
        Otherwise, must be a sequence of 4 numbers which define [top, right, bottom, left] margins (in this order) in px.
    x_unit : str, optional
        An optional unit for x values. If specified, will be drawn below the x axis (and centered).
        Can also be used in `x_ticks_format`, `values_format` and `title_tooltip_format` parameters as "{x_unit}".
    y_unit : str, optional
        An optional unit for y values. If specified, will be drawn above the y axis.
        Can also be used in `y_ticks_format`, `values_format` and `title_tooltip_format` parameters as "{y_unit}".
    x_ticks : int | Sequence[int | float | str], optional, default 6
        The ticks drawn in the x axis. Can be either an integer representing the number of ticks to show (see `x_axis_discrete`),
        or a sequence of values.
    x_axis_discrete : bool, optional, default True
        If True and `x_ticks` is an integer, the x ticks values will be pulled from `x` values, which can lead to an irregular scale.
        If False and `x_ticks` is an integer, the x ticks will be equally distributed from min(x) to max(x), even if the ticks are not included in `x` values, leading to a regular scale.
    x_ticks_margin: int | float, optional, default None
        The margin between the x ticks and the left and right sides of the chart area.
        Defaults to None, which means:
        - Line or scatter charts: 0;
        - Bar charts: the space between the left side of the first rectangle and the left side of the chart area;
        - Box plot charts: 1.5 * the space between the left side of the first rectangle and the left side of the chart area.
    x_ticks_position: str, optional, default "middle"
        The position of the x ticks: either "middle" (the default) for having ticks centered (same as the tick label) or "external" for having ticks around the tick label.
        All other values will remove the x ticks (but keeping the vertical dotted lines and labels).
    y_ticks : int | Sequence[int | float], optional, default 6
        The ticks drawn in the y axis. Can be either an int representing the number of ticks to show (not used if `y_ticks_interval` provided),
        or a sequence of values.
    y_ticks_interval : int | float, optional
        If `y_ticks` is not a sequence, `y_ticks_interval` defines the fixed interval between each tick, from `y_min` to `y_max`.
    y_min : int | float | None, optional, default 0
        The min value drawn on the y ticks. If None (and `y_ticks` is not a sequence), will be defined as min(y).
    y_max : int | float, optional
        The max value drawn on the y ticks. If not provided and `y_ticks` not provided as a sequence, will be defined as max(y), or will be computed using `y_ticks_interval` if provided.
    big_mark : str, optional
        Can be used to replace default "_" big mark separator when some numbers are formatted with "{:_}" in `x_ticks_format`, `y_ticks_format`, `values_format` or `title_tooltip_format`.
        In such a case, dont use "_" as literal text in these formats as it will also be replaced by `big_mark`.
    decimal_mark : str, optional
        Can be used to replace default "." decimal mark when some numbers are formatted with "{:.1f}" in `x_ticks_format`, `y_ticks_format`, `values_format` or `title_tooltip_format`.
        In such a case, dont use "." as literal text in these formats as it will also be replaced by `decimal_mark`.
    x_ticks_format : str, optional, default "{:n}"
        The string format used to format x ticks values. "{x}" (with formatting options) will be replaced by the tick value and "{x_unit}" by the corresponding parameter.
        See: https://docs.python.org/3/library/string.html#format-string-syntax
    y_ticks_format : str, optionall, default "{:n}"
        The string format used to format y ticks values. "{y}" (with formatting options) will be replaced by the tick value and "{y_unit}" by the corresponding parameter.
        See: https://docs.python.org/3/library/string.html#format-string-syntax
    show_values : str | Sequence[int | float | str], optional
        If provided, the specified values will be drawn on the chart (as <text> elements), next to the corresponding data points.
        Can be either "all" for displaying all values, "last" for displaying only last values or a sequence of x values for displaying only the corresponding y values.
    values_position : str, optional, default "top"
        Where the value will be drawn relatively to the corresponding data point when `show_values` is provided or `tooltip_type` contains "value".
        Can be one of "top", "right", "bottom", "left", "fixed above chart" and "fixed under chart".
    values_position_shift : Sequence[int | float], optional
        The specific shift in px defined as (x, y) relatively to the data points where to draw values when `show_values` is provided or `tooltip_type` contains "value".
        Defaults to (0, -12) when values_position="top", (0, 20) when "bottom", (12, 0) when "right" and (-12, 0) when "left".
    values_format : str | Sequence[str], optional, default "{y}{y_unit}"
        The string format used to format values when `show_values` is provided or `tooltip_type` contains "value".
        "{y}" will be replaced by the y value, "{x}" by the x value, "{name}" by the series name, "{extra}" by the corresponding `extra_data` for the point/series hovered, and "{x_unit}" and "{y_unit}" by the corresponding parameters.
        See: https://docs.python.org/3/library/string.html#format-string-syntax
    show_only_hovered_value : bool, optional, default True
        If True and `tooltip_type` contains "value" or "vertical line" and (`show_values` is defined or `chart_type` contains "scatter"), when hovering a specific value then
        all other values for the same series will be hidden and other circles will have reduced opacity. 
    tooltip_type : str | Sequence[str] | None, optional, default "value"
        The type of tooltip to display when hovering a data point. Can be a sequence containing "title", "value", "vertical line" or None to display no tooltip.
        "value" will use <text> elements hidden by default and shown when hovering.
        "title" will use <title> elements inside each <circle> elements representing the data points. These <title> elements are not rendered in mobile browsers.
        "vertical line" will show a vertical line and all y values when hovering a x virtual vertical line. It doesn't work well if lots of x values.
    title_tooltip_format : str | Sequence[str], optional, default "{name}: x = {x}{x_unit}, y = {y}{y_unit}"
        The string format used to format tooltip when `tooltip_type` contains "title".
        "{y}" will be replaced by the y value, "{x}" by the x value, "{name}" by the series name, "{extra}" by the corresponding `extra_data` for the point/series hovered, and "{x_unit}" and "{y_unit}" by the corresponding parameters.
        If a sequence is provided and there are multiple series, each series will have the specified tooltip format on hover (based on sequence position, same as `y`).
        See: https://docs.python.org/3/library/string.html#format-string-syntax
    extra_data : Sequence[Sequence[int | float | str]] | Sequence[int | float | str], optional
        Extra data that can be used in `title_tooltip_format` and `values_format`.
        Must be the same type as `y`: each data point will match the specified extra data based on sequence (of sequence) position.
    circles : int | float, optional, default 4
        The <circle> radius in px (as `r` attribute).
        Used when `chart_type` contains "scatter", or `show values` is provided, or `tooltip_type` is not None.
    extra_lines : Sequence[dict] | dict, optional
        Extra horizontal or vertical lines to draw on the chart.
        Each line is defined by a dictionary containing between 1 and 4 keys:
        * 'x' for a vertical line or 'y' for a horizontal line, the value representing where to draw the line in the x or y axis. Must be the same type as `x` and `y`, multiple lines are drawn if a sequence is provided.
        * 'color' (optional, default "black"): the color of the line, as a color name (e.g. "green"), a hex code (e.g. "#e91585") or a RGB triplet (e.g. "rgb(0, 191, 255)").
        * 'thickness' (optional, default 2): the `stroke-width` attribute of the <line> element.
        * 'position' (optional, default "back"): whether the lines are drawn behind ("back") or in front of ("front") the plots.
        Multiple lines can be drawn using a sequence of dictionaries.
    legend_position : str | None, optional, default "right"
        Where to draw the legend (containing series names).
        To draw the legend outside the plotting area, use one of "top", "right", "bottom", "left".
        To draw the legend inside the plotting area, use one of "top left", "top right", "bottom left", "bottom right".
        None if legend must not be displayed.
    legend_background : str, optional
        If provided, the background color of the legend (no background by default), as a color name (e.g. "green"), a hex code (e.g. "#e91585") or a RGB triplet (e.g. "rgb(0, 191, 255)").
    css : Sequence[str] | str, optional
        The optional css properties to add to the <style> element.
    notes : str | Sequence[str], optional
        The optional notes to display as a <text> element above the chart.
        Can contain svg elements (such as <a> for example) and raw text.
        If a note starts with "<i>", text will be displayed in italic. If it starts with "<b>", text will be displayed in bold.
        If a sequence is provided, each element will be treated as a new line, using `<tspan dy="1.5em">`.
    font_size : int | float, optional, default 15
        The font size (in px) of the root <svg> element.
    background_color : str | None, optional, default "auto"
        If not None, draw a <rect> filled with the specified color behind the chart.
        Can be a color name (e.g. "green"), a hex code (e.g. "#e91585"), or a RGB triplet (e.g. "rgb(0, 191, 255)")..
        Defaults to "auto", which translates to "black" if `dark_mode`="force", otherwise "white".
        If `dark_mode`="user", the background <rect> will be hidden if the browser is configured in dark color scheme. 
    dark_mode : str | None, optional, default "user"
        If "user", add a few css properties to handle color scheme preference of user on web browser.
        If "force", display the chart with a black background (instead of white in light mode) and white texts and axis lines (instead of black in light mode).
        Otherwise, use light mode (white background + black text and axis lines).
    pretty : bool, optional, default False
        If True, the <svg> output will be prettified using xml.etree.ElementTree.indent() function.
        If False, the <svg> output will be minified (fits in one line).
        See: https://docs.python.org/3/library/xml.etree.elementtree.html#xml.etree.ElementTree.indent
    output : str, optional, default "string"
        If "string", the function will return the <svg> content as a string.
        If "etree", the function will return the <svg> content as a xml.etree.ElementTree.Element.
        Otherwise, will be interpreted as the name (absolute or relative path) of the svg file to create containing the chart.
        In such a case, the function will also return the xml.etree.ElementTree.Element.

    Returns
    -------
    str | xml.etree.ElementTree.Element
        SVG chart, either as a string if `output` = "string" or a xml.etree.ElementTree.Element otherwise.
        Note that if `output` is the name (absolute or relative) of a file, the SVG content is written to that file
        and the function returns the xml.etree.ElementTree.Element.
    
    Examples
    -------
    
    Create a SVG line chart with 1 series and store it in a string:
    
    >>>> my_line_chart = basic_svg_chart.chart(x = range(3), y = [100, 1000, 10000])
    
    Create a line + scatter chart with 3 series, and write it to a file named `my_chart.svg`:
    
    >>>> basic_svg_chart.chart(
    ...     type = "line scatter",
    ...     x = (2000, 2010, 2020, 2030),
    ...     y = [[10, 20, 30, None], [15, 8, 13, 22], [None, 15, 5, 10]],
    ...     names = ("", "", ""),
    ...     colors = ("red", "green", "#0d7cf8"),
    ...     output = "my_chart.svg"
    ... )

    """

    ## Check parameters and modify them when needed ##
    
    # if not isinstance(height, int | float):
    #     logging.error("🚨 height must be a number")
    #     raise SystemExit

    # Transform xy into x + y
    # Ugly, code needs to be improved !!
    if xy is not None and x is None and y is None:
        x = []
        y = []

        for series in xy:
            tmp_y = [None] * len(x)
            if not any(isinstance(el, Seq) for el in series):
                series = [series]
            for pt in series:
                # if chart_type == "scatter" and pt[0] in x:
                #     tmp_y[x.index(pt[0])] = pt[1]
                # else:
                #     x.append(pt[0])
                #     tmp_y.append(pt[1])
                x.append(pt[0])
                tmp_y.append(pt[1])
            y.append(tmp_y)
    
    # y must be a list of lists
    if not any(isinstance(el, Seq) for el in y):
        y = [y, ]
    
    if not isinstance(y, list):
        y = list(y)

    y_values = y.copy()
    
    # chart_type
    if isinstance(chart_type, str):
        chart_type = [chart_type for i in range(len(y))]
    elif len(chart_type) < len(y):
        chart_type = list(chart_type)
        chart_type.extend([chart_type[-1] for i in range(len(y) - len(chart_type))])

    num_bars = chart_type.count("bar")
    num_box_plots = chart_type.count("box plot")

    # Extra data
    if extra_data is not None and not any(isinstance(el, Seq) for el in extra_data):
        extra_data = [extra_data, ]
    if extra_data is not None and not isinstance(extra_data, list):
        extra_data = list(extra_data)

    # Bar charts specific parameters
    if num_bars > 0:
        if "group_padding" not in bar_param:
            bar_param["group_padding"] = 0.8
        if "bar_padding" not in bar_param:
            bar_param["bar_padding"] = 1
        if "group" not in bar_param:
            bar_param["group"] = "x"
        if "stack" not in bar_param:
            bar_param["stack"] = False

        # Stack data
        # /!\ Non-performant code...
        if bar_param["stack"] and num_bars > 1:
            num_bars = 1
            first_bar = True
            for i_y in range(len(y)):
                if chart_type[i_y] == "bar":
                    cur_y = list(y[i_y])
                    if first_bar:
                        if len(cur_y) < len(x):
                            cur_y.extend([0] * (len(x) - len(cur_y)))
                        stacked_pos = [max(val or 0, 0) for val in cur_y]
                        stacked_neg = [min(val or 0, 0) for val in cur_y]
                        first_bar = False
                    else:
                        for i_x in range(min(len(x), len(cur_y))):
                            if cur_y[i_x] is not None:
                                if cur_y[i_x] > 0:
                                    cur_y[i_x] = cur_y[i_x] + stacked_pos[i_x]
                                    stacked_pos[i_x] = cur_y[i_x]
                                elif cur_y[i_x] < 0:
                                    cur_y[i_x] = cur_y[i_x] + stacked_neg[i_x]
                                    stacked_neg[i_x] = cur_y[i_x]
                        y[i_y] = cur_y


    # Box plot charts specific parameters
    if num_box_plots > 0:
        if "calculate_quantiles" not in box_plot_param:
            box_plot_param["calculate_quantiles"] = False
        if "whiskers" not in box_plot_param:
            box_plot_param["whiskers"] = ("min", "max")
        if "padding" not in box_plot_param:
            box_plot_param["padding"] = 0.5
        if "mean" not in box_plot_param:
            box_plot_param["mean"] = False
        if "outliers" not in box_plot_param:
            box_plot_param["outliers"] = False

        start_outliers = 6 if box_plot_param["mean"] else 5

        # calculate quantiles if not set
        if box_plot_param["calculate_quantiles"]:
            for i_y in range(len(y)):
                if chart_type[i_y] == "box plot":
                    series_values = y[i_y]
                    lower_whisker = None
                    upper_whisker = None
                    quartiles = statistics.quantiles(series_values)
                    if box_plot_param["whiskers"] == "IQR":
                        iqr = quartiles[2] - quartiles[0]
                        lower_whisker = quartiles[0] - 1.5*iqr
                        upper_whisker = quartiles[2] + 1.5*iqr
                        lower_whisker = min([y for y in series_values if y >= lower_whisker])
                        upper_whisker = max([y for y in series_values if y <= upper_whisker])
                        name_lower_whisker = "Q1 - 1.5IQR"
                        name_upper_whisker = "Q3 + 1.5IQR"
                    else:
                        if box_plot_param["whiskers"][0] == "min":
                            lower_whisker = min(series_values)
                            name_lower_whisker = "Min"
                        if box_plot_param["whiskers"][1] == "max":
                            upper_whisker = max(series_values)
                            name_upper_whisker = "Max"
                        if lower_whisker is None or upper_whisker is None:
                            percentiles = statistics.quantiles(series_values, n = 100)
                            if lower_whisker is None:
                                p = box_plot_param["whiskers"][0].replace("P", "")
                                lower_whisker = percentiles[int(p) - 1]
                                name_lower_whisker = "P" + p
                            if upper_whisker is None:
                                p = box_plot_param["whiskers"][1].replace("P", "")
                                upper_whisker = percentiles[int(p) - 1]
                                name_upper_whisker = "P" + p

                    bp_values = [lower_whisker] + quartiles + [upper_whisker]
                    bp_extra = [name_lower_whisker] + ["Q1", "Q2", "Q3"] + [name_upper_whisker]

                    if box_plot_param["mean"]:
                        bp_values.append(statistics.mean([y for y in y[i_y] if y is not None]))
                        bp_extra.append("Mean")

                    if box_plot_param["outliers"]:
                        bp_values = bp_values + [y for y in y[i_y] if y < lower_whisker] + [y for y in y[i_y] if y > upper_whisker]
                        if extra_data is not None:
                            bp_extra = (bp_extra +
                                [extra_data[i_y][i] for i in range(len(y[i_y])) if y[i_y][i] < lower_whisker] +
                                [extra_data[i_y][i] for i in range(len(y[i_y])) if y[i_y][i] > upper_whisker])
                            extra_data[i_y] = bp_extra
                    
                    y[i_y] = bp_values
    
    # Names
    if names is None:
        names = []
    elif isinstance(names, tuple) or isinstance(names, range):
        names = list(names)
    elif not isinstance(names, list):
        names = [str(names)]
    
    for i in range(len(names)):
        if not isinstance(names[i], str):
            names[i] = str(names[i])
    
    # If less names provided than series, add default extra names
    old_length = len(names)
    if len(y) == 1 and old_length == 0 and title is not None and title != "":
        names = [title]
    else:
        for i in range(len(y) - len(names)):
            names.append(f"Data series {old_length + i + 1}")
    
    names_text = [replace_tags(n, keep_title = False) for n in names]
    
    # x and x_ticks
    if isinstance(x, range | tuple):
        x = list(x)

    if num_bars > 0 and bar_param["group"] == "series":
        if not isinstance(x_ticks, list | tuple) or not all([tick in names for tick in x_ticks]):
            x_ticks = names
        x_type_number = False
        x_ticks_names = True

    else:
        x_ticks_names = False
        if x_ticks is None:
            x_ticks = list(x)
        elif isinstance(x_ticks, tuple | range):
            x_ticks = list(x_ticks)
        elif isinstance(x_ticks, int):
            x_ticks = min(x_ticks, len(x))
        
        # x must be a list of numbers or a list of strings
        if any(isinstance(el, str) for el in x):
            x = [str(el) for el in x]
            x_type_number = False
            if not(isinstance(x_ticks, int)):
                x_ticks = [str(el) for el in x_ticks]
        else:
            x_type_number = True
    
    # Default big_mark and decimal_mark when lang="fr"
    if lang is not None and "fr" in lang.lower():
        big_mark = " " if big_mark is None else big_mark
        decimal_mark = "," if decimal_mark is None else decimal_mark

    ## x ticks ##
    
    if x_type_number:
        x_min = min(x)
        if isinstance(x_ticks, list) and min(x_ticks) < x_min:
            x_min = min(x_ticks)
        
        x_max = max(x)
        if isinstance(x_ticks, list) and max(x_ticks) > x_max:
            x_max = max(x_ticks)
        
        if isinstance(x_ticks, int):
            x_ticks = max(2, x_ticks)
            if x_axis_discrete:
                x_values = x.copy()
                x_values.sort()
                
                interval = round((len(x) - 1)  / (x_ticks - 1))
                list_ticks = []
                for i in range(x_ticks - 1):
                    list_ticks.append(x_values[i * interval])
                    
                list_ticks.append(x_max)
                x_ticks = list_ticks
            
            else:
                list_ticks = []
                x_value = x_min
                for i in range(x_ticks):
                    list_ticks.append(x_value)
                    x_value = x_value + (x_max - x_min) / (x_ticks - 1)
                    if isinstance(x_value, float) and x_value.is_integer():
                        x_value = int(x_value)
                x_ticks = list_ticks
        
    else:
        x_min = x[0]
        
        if isinstance(x_ticks, int):
            if len(x) > 1:
                interval = round((len(x) - 1)  / (x_ticks - 1))
                list_ticks = []
                for i in range(x_ticks - 1):
                    list_ticks.append(x[i * interval])
                    
                list_ticks.append(x[-1])
                x_ticks = list_ticks
            else:
                x_ticks = x
    
    # x ticks format
    if x_ticks_format is None:
        x_ticks_format = "{}"

    x_ticks_values = []
    for tick in x_ticks:
        if x_type_number:
            text = format_text_numbers(x_ticks_format.format(tick, x = tick, x_unit = x_unit), big_mark, decimal_mark)
        else:
            text = str(tick) if x_ticks_format == "{:n}" else x_ticks_format.format(str(tick), x = str(tick), x_unit = x_unit)
        x_ticks_values.append(text)
           
    ## y ticks ##
    
    if y_ticks_format is None:
        y_ticks_format = "{}"
    
    y_ticks_values = []
    if isinstance(y_ticks, range | tuple):
        y_ticks = list(y_ticks)

    if isinstance(y_ticks, list):
        y_max = max(y_ticks)
        y_min = min(y_ticks)
        y_ticks_values = [format_text_numbers(y_ticks_format.format(z, y = z, y_unit = y_unit), big_mark, decimal_mark) for z in y_ticks]

    elif y_ticks_interval is not None:
        y_ticks_interval = abs(y_ticks_interval)
        y_max_defined = True
        if y_max is None:
            y_max_defined = False
            y_max = max([max([i for i in el if i is not None]) for el in y])
            
        if y_min is None:
            y_min = min([min([i for i in el if i is not None]) for el in y])
        if y_max <= y_min:
            y_min = y_max - y_ticks_interval

        y_ticks = []
        y_value = y_min
        while y_value < y_max:
            y_ticks.append(y_value)
            y_value = y_value + y_ticks_interval
            if isinstance(y_value, float) and y_value.is_integer():
                y_value = int(y_value)
            elif isinstance(y_value, float):
                y_value = round(y_value * 1e12) / 1e12
        
        if y_max_defined:
            y_ticks.append(y_max)
        else:
            y_ticks.append(y_value)
            y_max = y_value
        
        # power_tens = math.floor(math.log10(abs(y_max))) - 1
    
    elif isinstance(y_ticks, int):
        y_ticks = max(y_ticks, 2)
        if y_max is None:
            y_max = max([max([i for i in el if i is not None]) for el in y])
            if y_max != 0:
                power_tens = math.ceil(math.log10(abs(y_max))) - 1 # https://stackoverflow.com/questions/61008937/python-round-to-next-highest-power-of-10
                factor = 10 ** power_tens
                if 1 < y_max/factor < 1.6 or 2 < y_max/factor < 2.6 :
                    power_tens -= 1
                factor = 10 ** power_tens
                y_max = math.ceil(y_max/factor) * factor * y_max / y_max
        # else:
            # power_tens = math.floor(math.log10(abs(y_max))) - 1
            
        if isinstance(y_max, float) and y_max.is_integer():
            y_max = int(y_max)
        
        if y_min is None or y_max <= y_min:
            y_min = min([min([i for i in el if i is not None]) for el in y])
            
        y_ticks = [y_min + i * (y_max - y_min) / (y_ticks - 1) for i in range(y_ticks)]
        y_ticks = [round(yt * 1e12) / 1e12 if isinstance(yt, float) else yt for yt in y_ticks]
    
    else:
        raise TypeError("`y_ticks` must be an integer or a sequence of numbers")

    if y_ticks_values == []:
        for y_value in y_ticks:
            if isinstance(y_value, float) and y_value.is_integer():
                y_value = int(y_value)
                
            y_ticks_values.append(format_text_numbers(y_ticks_format.format(y_value, y = y_value, y_unit = y_unit), big_mark, decimal_mark))

    # Units
    x_unit = str(x_unit or "")
    y_unit = str(y_unit or "")
    
    # Tooltip
    if tooltip_type is None:
        tooltip_type = "no"
        
    # Show values
    if show_values == "last":
        show_values = x[-1]
    
    if show_values is not None and not isinstance(show_values, Sequence | Number_or_string) and show_values != "all":
        show_values = None

    if isinstance(show_values, Number_or_string) and show_values != "all":
        show_values = (show_values, )
    
    if isinstance(values_position_shift, Number):
        values_position_shift = (values_position_shift, 0)
    elif values_position_shift is not None and not isinstance(values_position_shift, Seq):
        logging.warning(f"⚠️  `values_position_shift` must be a sequence, not a {type(values_position_shift)}")
        values_position_shift = None
    
    show_some_values = show_values is not None or "vertical line" in tooltip_type or "value" in tooltip_type
    
    if values_position_shift is None and show_some_values and not values_position.startswith("fixed"):
        values_position_shift = DEFAULT_VALUES_POSITION_SHIFT[values_position]
    
    # Circles
    # if circles <= 0 and ("title" in tooltip_type or "vertical line" in tooltip_type or show_values is not None):
    if circles is None or circles <= 0:
        circles = 4
    
    ## Chart plotting area size, and space around it for title, legend, notes... ##
    
    abscissa_height = 12 + font_size
    # Space for legend
    max_length_names = max([len(n) for n in names_text])
    if 5 <= max_length_names < 10:
        max_length_names = 10
    legend_width = 70 + (max_length_names * font_size / 2)
    legend_height = font_size * 2

    if x_ticks_margin is None:
        x_ticks_margin = 0
        x_ticks_margin_undefined = True
    else:
        x_ticks_margin_undefined = False

    if margin == "auto":
        if title is not None and title != "":
            top = font_size * 1.4 * 2
        elif y_unit != "":
            top = font_size * 2
        else:
            top = 20
        if values_position == "fixed above chart":
            top = top + font_size
        
        width_y_max = max([len(x) for x in y_ticks_values])
        left = 20 + round(font_size * 0.6 * width_y_max)
        
        bottom = abscissa_height
        
        if isinstance(notes, str):
            notes = [notes]
        
        if notes is not None and len(notes) > 0:
            bottom = bottom + (font_size / 2) + (font_size * 1.5 * len(notes))
        else:
            bottom = bottom + (font_size / 2)
        
        right = 20
        
        if legend_position == "right":
            right = legend_width
        elif legend_position == "top":
            top = top + legend_height
        elif legend_position == "left":
            left = left + legend_width
        elif legend_position == "bottom":
            bottom = bottom + legend_height

        if x_unit != "" or values_position == "fixed under chart":
            bottom = bottom + (font_size * 1.5)

        # Add extra space if large first and last x ticks
        if num_bars + num_box_plots == 0:
            left = max(left, font_size * 0.6 * len(x_ticks_values[0]) / 2)
            right = max(right, font_size * 0.6 * len(x_ticks_values[-1]) / 2)
        
        # Add extra space if large values must be drawn

        if show_some_values and not values_position.startswith("fixed"):
            if values_format is not None:
                max_fmt = max([v or "" for v in values_format], key = len) if isinstance(values_format, Seq) else values_format
                if "{extra" in max_fmt and extra_data is not None:
                    extra = extra_data[0][0] if extra_data[0] is not None else None
                else:
                    extra = ""
                len_fmt_min = len(format_text_numbers(max_fmt.format(y_max, y = y_max, y_unit = y_unit, name = max(names, key = len), x = x[0], x_unit = x_unit, extra = extra), big_mark, decimal_mark))
                len_fmt_max = len(format_text_numbers(max_fmt.format(y_max, y = y_max, y_unit = y_unit, name = max(names, key = len), x = x[-1], x_unit = x_unit, extra = extra), big_mark, decimal_mark))
            else:
                len_fmt_min = 0
                len_fmt_max = 0

            # first and last x values can be different from first and last x ticks, in that case substract the distance between these values to the potential extra left/right spaces added
            if x_type_number:
                chart_width = width - left - right - 2 * x_ticks_margin

                if x_ticks_margin_undefined and any(c == "box plot" for c in chart_type):
                    x_interval_px = chart_width / (x_max - x_min) / (1 + 1 / (x_max - x_min))
                    extra_px = x_interval_px * 2 / 3
                elif x_ticks_margin_undefined and any(c == "bar" for c in chart_type):
                    x_interval_px = chart_width / (x_max - x_min) / (1 + 1 / (x_max - x_min))
                    extra_px = x_interval_px / 2
                else:
                    x_interval_px = chart_width / (x_max - x_min)
                    extra_px = 0
                
                coord_first_x = round(x_interval_px * (min(x) - min(x_ticks)) + extra_px, 2) 
                coord_last_x = round(chart_width - (x_interval_px * (max(x) - x_min)) - extra_px, 2)
            else:
                coord_first_x = x_ticks_margin
                coord_last_x = x_ticks_margin

            # for taking into account css properties "text-anchor" and "dominant-baseline"
            coeff = 2 if values_position in ("top", "bottom") else 1

            if values_position != "right":
                left = max(left, (len_fmt_min * font_size * 0.6 / coeff) - values_position_shift[0] - coord_first_x)
            
            if values_position != "left":
                right = max(right, (len_fmt_max * font_size * 0.6 / coeff) + values_position_shift[0] - coord_last_x)
            
            bottom = max(bottom, font_size/coeff + values_position_shift[1])
            top = max(top, font_size/(2/coeff) - values_position_shift[1])
        
        spaces = SimpleNamespace(top = top, right = right, bottom = bottom, left = left)

    # user defined margins
    elif isinstance(margin, Seq) and len(margin) == 4:
        spaces = SimpleNamespace(top = margin[0], right = margin[1], bottom = margin[2], left = margin[3])

    else:
        raise TypeError("🚨 `margin` must be either \"auto\" or a sequence of 4 numbers")
    
    chart_width = width - spaces.left - spaces.right
    chart_height = height - spaces.top - spaces.bottom

    if len(x) == 1:
        x_width = 1
    elif x_type_number:
        x_width = x_max - x_min
    elif x_ticks_names:
        x_width = len(names) - 1
    else:
        x_width = len(x) - 1
    x_interval_px = (chart_width - 2*x_ticks_margin) / x_width

    if x_ticks_margin_undefined and any(c == "box plot" for c in chart_type):
        if len(x) > 1:
            x_interval_px = x_interval_px / (1 + 1 / x_width)
            x_ticks_margin = x_interval_px/2
        else:
            x_interval_px = chart_width
            x_ticks_margin = (1-box_plot_param["padding"])*chart_width/2

    elif x_ticks_margin_undefined and any("bar" in c for c in chart_type):
        x_interval_px = x_interval_px / (1 + 1 / x_width)
        x_ticks_margin = x_interval_px/2
    
    logging.info(f"plotting area size: {num_attr(chart_width)} x {num_attr(chart_height)}")
    logging.info(f"margin: ({num_attr(spaces.top)}, {num_attr(spaces.right)}, {num_attr(spaces.bottom)}, {num_attr(spaces.left)})")
    
    ## <svg> ##
    chart = ET.Element("svg",
        # https://stackoverflow.com/questions/56061765/inkscape-ignores-use
        # https://www.unimelb.edu.au/accessibility/techniques/accessible-svgs
        attrib = {'xmlns': "http://www.w3.org/2000/svg", 'xmlns:xlink': "http://www.w3.org/1999/xlink"},
        viewBox = f"0 0 {width} {height}",
        # preserveAspectRatio = "xMinYMin", # https://developer.mozilla.org/fr/docs/Web/SVG/Reference/Attribute/preserveAspectRatio
        style = f"font-size: {font_size}px",
        role = "img",
    )
    
    if not fullscreen:
       chart.attrib.update({'width': str(width), 'height': str(height)}) 
    
    if lang is not None:
        # https://kb.daisy.org/publishing/docs/html/svg.html#desc-lang
        chart.attrib.update({'lang': lang, 'xml:lang': lang})
    
    # <style>
    style = ET.SubElement(chart, "style", type = "text/css")
    style_css = list(DEFAULT_CSS)
    r_circles_hover = max(circles + 2, circles * 1.25)
    style_css.append(f"circle:hover {{r: {r_circles_hover}px;}}")
        
    # Background color
    if background_color is not None and background_color != "":
        chart.append(ET.Element("rect", width = "100%", height = "100%", attrib = {'class': "background-color"}))
        if background_color == "auto":
            background_color = "black" if dark_mode == "force" else "white"
        style_css.append(f"rect.background-color {{fill: {background_color};}}")
    else:
        background_color = None

    # Show values on hover
    if "value" in tooltip_type or "vertical line" in tooltip_type:
        style_css.append(f"text.hide {{transform: translate({width}px, {height}px);}}")

    if show_only_hovered_value and ("value" in tooltip_type or "vertical line" in tooltip_type) and (show_values is not None or any("scatter" in c for c in chart_type)):
        if num_bars > 0:
            style_css.append(".series > rect:hover ~ text, .series > text:has(~ rect:hover) {opacity: 0;}")
        
        if num_bars < len(y):
            style_css.extend((
                "circle:hover ~ circle:not(.hide), circle:not(.hide):has(~ circle:hover) {opacity: 0.2;}",
                "circle:hover ~ text, text:has(~ circle:hover) {opacity: 0;}",
                "circle:hover + text {opacity: 1; transform: none;}",
            ))
    
    if num_bars > 0:
        style_css.append(".series > rect:hover + text {opacity: 1; transform: none;}")

    if num_box_plots > 0:
        style_css.append(".box-plot > line {stroke-width: 3; &:hover{stroke-width: 5;}}")
        style_css.append("g#series_plots > g.box-plot:hover {line, circle, polyline {opacity: 0.2;} *:hover {opacity: 1;}}")
        style_css.append(".box-plot > line:hover + text {opacity: 1; transform: none;}")
        style_css.append(".box-plot > polyline:hover + text {opacity: 1; transform: none;}")
        if show_only_hovered_value:
            style_css.append("line:hover ~ text, text:has(~ line:hover) {opacity: 0;}")
            if box_plot_param["mean"]:
                style_css.append("polyline:hover ~ text, text:has(~ polyline:hover) {opacity: 0;}")

    newline_in_values_format = False
    
    # <title>
    if title is not None and title != "":
        # No builtin support for CDATA with ET: https://stackoverflow.com/questions/174890/how-to-output-cdata-using-elementtree
        # "<![CDATA[" + title + "]]>"
        ET.SubElement(chart, "title", id = "title").text = replace_tags(title)
        chart.attrib["aria-labelledby"] = "title"
    
    # <desc>
    if desc is not None and desc != "":
        ET.SubElement(chart, "desc", id = "description").text = desc
        chart.attrib["aria-describedby"] = "description"
    
    # <defs>
    defs = ET.SubElement(chart, "defs")
    
    if show_some_values:
        baseline = " dominant-baseline: central;" if values_position in ["left", "right", "fixed above chart", "fixed under chart"] else ""
        style_css.append(f"g.series > text {{text-anchor: {VALUES_ANCHOR[values_position]};{baseline}}}")
        
        # Add background color for value hovered
        if background_color is not None:
            filter_bg_val = ET.SubElement(defs, "filter", id = "bg_val", x = "0", width = "1", y = "0.1", height = "0.8")
            ET.SubElement(filter_bg_val, "feFlood", {'flood-color': background_color, 'flood-opacity': "0.9", 'result': "bg_val_text"})
            feMerge = ET.SubElement(filter_bg_val, "feMerge")
            ET.SubElement(feMerge, "feMergeNode", {'in': "bg_val_text"})
            ET.SubElement(feMerge, "feMergeNode", {'in': "SourceGraphic"})
                
            style_css.append("g.series > text {filter: url(#bg_val);}")
    
    # Colors
    if colors is None:
        colors = []
    elif isinstance(colors, str):
        colors = [colors]
    elif isinstance(colors, tuple):
        colors = list(colors)
    
    missing_colors_nb = len(y) - len(colors)
    if missing_colors_nb > len(VIRIDIS):
        logging.error("🚨 You have to specify `colors` when more than 20 series")
        raise SystemExit
    elif missing_colors_nb > 0:
        # palette = OKABE_ITO if len(y) <= 8 else VIRIDIS
        if missing_colors_nb <= len(OKABE_ITO):
            colors.extend(OKABE_ITO[0:missing_colors_nb])
        else:
            colors.extend(VIRIDIS[missing_colors_nb - 1])
    
    for i in range(len(y)):
        color_rect = f", .color{i + 1} rect" if chart_type[i] in ("bar", "box plot") else ""
        color = colors[min(len(colors) - 1, i)]
        style_css.append(f".color{i + 1} {{fill: {color}; stroke: {color};}}")
        style_css.append(f".color{i + 1} text, text.color{i + 1}{color_rect} {{fill: {color}; stroke: none; font-weight: bold;}}")
    
    # Title text
    if title is not None and title != "":
        title = "<text>" + title + "</text>"
        title = ET.fromstring(title)
        title.attrib = {'class': "title", 'x': num_attr(spaces.left + chart_width/2), 'y': num_attr(font_size * 2.8 / 1.8)}
        chart.append(title)
    
    # Chart shift
    translate = ET.SubElement(chart, "g", id = "position", transform = f"translate({num_attr(spaces.left)}, {num_attr(spaces.top)})")
    
    ## Abscissa axis ##
    
    g_abscissa_lines = ET.Element("g", id = "abscissa_lines")
    g_abscissa_text = ET.Element("g", id = "abscissa_text")
    
    # Abscissa line
    ET.SubElement(g_abscissa_lines, "line", x1 = "-8", x2 = num_attr(chart_width), y1 = num_attr(chart_height), y2 = num_attr(chart_height), stroke = "black", attrib = {'stroke-width': "2", 'stroke-linecap': "square"})
    
    # Vertical dotted gridlines
    vertical_dotted_lines = ET.SubElement(defs, "g", id = "vertical_dotted_lines")
    ET.SubElement(vertical_dotted_lines, "line", x1 = "0", x2 = "0", y1 = "0", y2 = num_attr(chart_height), stroke = "lightgrey", attrib = {'stroke-width': "1", 'stroke-linecap': "square", 'stroke-dasharray': "5.5"})
    if x_ticks_position == "middle":
        ET.SubElement(vertical_dotted_lines, "line", x1 = "0", x2 = "0", y1 = num_attr(chart_height), y2 = num_attr(chart_height + 8), stroke = "black")
    elif x_ticks_position == "external":
        g_x_ticks = ET.SubElement(defs, "g", id = "x_ticks")
        ET.SubElement(g_x_ticks, "line", x1 = num_attr(-x_interval_px/2), x2 = num_attr(-x_interval_px/2), y1 = num_attr(chart_height), y2 = num_attr(chart_height + 8), stroke = "black")
    
    coord_x = 0
    # for tick in [el for el in x_ticks if (not(x_type_number) or el >= x_min)]:
    for i in range(len(x_ticks)):
        tick = x_ticks[i]
        text = x_ticks_values[i]
        if len(x) == 1:
            coord_x = x_ticks_margin + x_interval_px * box_plot_param["padding"] / 2
        elif x_type_number:
            coord_x = x_interval_px * (tick - x_min) + x_ticks_margin
        elif not x_ticks_names:
            coord_x = x_interval_px * x.index(tick) + x_ticks_margin
        else:
            coord_x = x_interval_px * names.index(tick) + x_ticks_margin
        if round(coord_x, 2) <= round(chart_width, 2):
            if tick != x_min or x_ticks_margin > 0:
                ET.SubElement(g_abscissa_lines, "use", attrib = {"xlink:href": "#vertical_dotted_lines"}, x = num_attr(coord_x))
            if x_ticks_position == "external":
                ET.SubElement(g_abscissa_lines, "use", attrib = {"xlink:href": "#x_ticks"}, x = num_attr(coord_x))
                if i == len(x_ticks) - 1:
                    ET.SubElement(g_abscissa_lines, "use", attrib = {"xlink:href": "#x_ticks"}, x = num_attr(coord_x + x_interval_px))
            
            ET.SubElement(g_abscissa_text, "text", x = num_attr(coord_x), y = num_attr(chart_height + abscissa_height)).text = text

        
    # Unit
    if x_unit != "":
        x_unit_svg = ET.fromstring("<text>" + x_unit + "</text>")
        x_unit_svg.attrib = {
            'class': "unit",
            'dominant-baseline': "central",
            'x': num_attr(chart_width/2),
            'y': num_attr(chart_height + abscissa_height + font_size)
        }
        g_abscissa_text.append(x_unit_svg)
  
    ## Ordinate axis ##
    
    g_ordinate_axis = ET.Element("g", id = "ordinate")
    y_interval_px = chart_height / (y_max - y_min)
    
    # Vertical ordinate line
    y1 = chart_height + 8 if x_ticks_margin == 0 else chart_height
    ET.SubElement(g_ordinate_axis, "line", {'stroke-width': "2", 'stroke-linecap': "square"}, x1 = "0", x2 = "0", y1 = num_attr(y1), y2 = "0", stroke = "black")
    
    # Horizontal dotted gridlines
    horizontal_dotted_lines = ET.SubElement(defs, "g", id = "horizontal_dotted_lines")
    ET.SubElement(horizontal_dotted_lines, "line", x1 = "0", x2 = num_attr(chart_width), y1 = "0", y2 = "0", stroke = "lightgrey", attrib = {'stroke-width': "1", 'stroke-linecap': "square", 'stroke-dasharray': "5.5"})
    ET.SubElement(horizontal_dotted_lines, "line", x1 = "0", x2 = "-8", y1 = "0", y2 = "0", stroke = "black")   

    for i in range(len(y_ticks)):
        y_value = y_ticks[i]
        pos = chart_height * (y_max - y_value) / (y_max - y_min)

        if y_value != y_min:
            ET.SubElement(g_ordinate_axis, "use", attrib = {"xlink:href": "#horizontal_dotted_lines"}, y = num_attr(pos))

        val = y_ticks_values[i]
        if val != "":
            ET.SubElement(g_ordinate_axis, "text", x = "-14", y = num_attr(pos)).text = val
    
    # Ordinate unit
    if y_unit != "":
        y_unit_svg = ET.fromstring("<text>" + y_unit + "</text>")
        y_unit_svg.attrib = {'class': "unit", 'x': '-20', 'y': num_attr(-font_size * 1.25)}
        g_ordinate_axis.append(y_unit_svg)
        
    ## Extra lines ##
    # If color, thickness and/or position not provided, add default values
    back_lines, front_lines = [], []
    if extra_lines is not None:
        if isinstance(extra_lines, dict):
            extra_lines = (extra_lines, )
        for li in extra_lines:
            if "color" not in li:
                li["color"] = "black"
            if "thickness" not in li:
                li["thickness"] = 2
            if "position" not in li:
                li["position"] = "back"
    else:
        extra_lines = ()
        
    for li in extra_lines:
        if "y" in li:
            if not isinstance(li["y"], list):
                li["y"] = [li["y"]]
            
            for y_value in li["y"]:
                pos = chart_height * (y_max - y_value) / (y_max - y_min)
                line = ET.Element("line", attrib = {'x1': "0", 'x2': num_attr(chart_width), 'y1': num_attr(pos), 'y2': num_attr(pos), 'stroke': li["color"], 'stroke-width': num_attr(li["thickness"]), 'stroke-linecap': "square"})
                back_lines.append(line) if li["position"] == "back" else front_lines.append(line)
                
        if "x" in li:
            if not isinstance(li["x"], list):
                li["x"] = [li["x"]]
                
            for x_value in li["x"]:
                if x_type_number:
                    pos = x_interval_px * (x_value - x_min)
                elif x_ticks_names:
                    pos = x_interval_px * names.index(x_value)
                else:
                    pos = x_interval_px * x.index(x_value)
                pos = pos + x_ticks_margin
                line = ET.Element("line", attrib = {'x1': num_attr(pos), 'x2': num_attr(pos), 'y1': "0", 'y2': num_attr(chart_height), 'stroke': li["color"], 'stroke-width': num_attr(li["thickness"]), 'stroke-linecap': "square"})
                back_lines.append(line) if li["position"] == "back" else front_lines.append(line)
    
    # Add elements to translate root element
    translate.append(g_ordinate_axis)
    translate.append(g_abscissa_lines)
    translate.extend(back_lines)
    # translate.append(g_abscissa_text)
    
    ## Vertical line showing values on hover ##
    if "vertical line" in tooltip_type:
        style_css.append(".hover_values * {opacity: 0;}")
        style_css.append(".hover_values:hover > line {stroke-width: 3px; opacity: 1;}")
        style_css.append(".hover_values:hover > text.abscissa {opacity: 1;}")
        style_css.append(".hover_values > text.abscissa {text-anchor: middle; font-weight: bold; filter: url(#bg_abs);}")
        style_css.append(f".hover_values > line {{stroke: black; stroke-width: {round(x_interval_px * 1.5)}px;}}")
        style_css.append(".hover_values:hover ~ g#abscissa_text {opacity: 0.2;}")

        if show_only_hovered_value:
            style_css.append(".hover_values:hover ~ g#series_plots > g.series > circle {opacity: 0;}")
            style_css.append(".hover_values:hover ~ g#series_plots > g.series > text {opacity: 0; transform: none;}")
        
        # Add background color for highlighted abscissa
        # https://stackoverflow.com/questions/15500894/background-color-of-text-in-svg
        filter_bg_abs = ET.SubElement(defs, "filter", id = "bg_abs", x = "-0.3", y = "-0.1", width = "1.6", height = "1.2")
        ET.SubElement(filter_bg_abs, "feFlood", {'flood-color': "yellow", 'result': "bg_abs_text"})
        feMerge = ET.SubElement(filter_bg_abs, "feMerge")
        ET.SubElement(feMerge, "feMergeNode", {'in': "bg_abs_text"})
        ET.SubElement(feMerge, "feMergeNode", {'in': "SourceGraphic"})
        
        # Line and abscissa text
        hv_line = ET.Element("line", x1 = "0", x2 = "0", y1 = "0", y2 = num_attr(chart_height + 8))
        hv_abs_text = ET.Element("text", {'class': "abscissa"}, x = "0", y = num_attr(chart_height + abscissa_height))

        for i in range(len(x)):
            if x_type_number:
                coord_x = x_interval_px * (x[i] - x_min) + x_ticks_margin
            else:
                coord_x = x_interval_px * i + x_ticks_margin
            
            hover_values = ET.SubElement(translate, "g", {'class': f"hover_values x{i + 1}"}, transform = f"translate({num_attr(coord_x)})")
            hover_values.append(hv_line)
            text = format_text_numbers(x_ticks_format.format(x[i], x = x[i], x_unit = x_unit), big_mark, decimal_mark) if x_type_number else str(x[i])
            t = copy.deepcopy(hv_abs_text)
            t.text = text
            hover_values.append(t)
            style_css.append(f".hover_values.x{i + 1}:hover ~ g#series_plots .x{i + 1} {{opacity: 1; r: {r_circles_hover}px;}}")
    
    translate.append(g_abscissa_text)
    
    ### Series plots ###
    
    series_plots = ET.SubElement(translate, "g", id = "series_plots")
    
    current_bar = 0
    first_bar = True
    
    ## Line, scatter or bar chart
    # For each series
    for i_y in range(len(y)):
        fig = ET.SubElement(series_plots, "g", {'class': f"series color{i_y + 1}"}, id = f"series{i_y + 1}")
        ET.SubElement(fig, "title").text = names_text[i_y]
        points = ""
        coord_x = 0
        first = True

        show_circles = "scatter" in chart_type[i_y] or ("title" in tooltip_type and title_tooltip_format[i_y] is not None)

        y_sign = 0
        if "bar" in chart_type[i_y]:
            if y_max >= 0 and y_min >= 0:
                y_sign = 1
            elif y_max >= 0 and y_min < 0:
                y_sign = 0
            elif y_max < 0 and y_min < 0:
                y_sign = -1

        # box plot: multi lines
        if chart_type[i_y] == "box plot":
            fig.attrib["class"] = fig.attrib["class"] + " box-plot"

            coord_y = [(y_max - bp_val) * chart_height / (y_max - y_min) for bp_val in y[i_y]]

            bar_width = x_interval_px * box_plot_param["padding"]

            if len(x) == 1:
                coord_x = x_ticks_margin
            elif x_type_number:
                coord_x = x_interval_px * (x[i_y] - x_min) + x_ticks_margin - x_interval_px * box_plot_param["padding"] / 2
            else:
                coord_x = x_interval_px * i_y + x_ticks_margin - x_interval_px * box_plot_param["padding"] / 2
            
            # Lower whisker
            ET.SubElement(fig, "line", attrib = {'class': "lower-whisker"}, x1 = num_attr(coord_x), x2 = num_attr(coord_x + bar_width), y1 = num_attr(coord_y[0]), y2 = num_attr(coord_y[0]))
            ET.SubElement(fig, "line", attrib = {'class': "lower-line"}, x1 = num_attr(coord_x + bar_width/2), x2 = num_attr(coord_x + bar_width/2), y1 = num_attr(coord_y[0]), y2 = num_attr(coord_y[1]))
            # Q1
            ET.SubElement(fig, "line", attrib = {'class': "quartile1"}, x1 = num_attr(coord_x), x2 = num_attr(coord_x + bar_width), y1 = num_attr(coord_y[1]), y2 = num_attr(coord_y[1]))
            # Median
            ET.SubElement(fig, "line", attrib = {'class': "median"}, x1 = num_attr(coord_x), x2 = num_attr(coord_x + bar_width), y1 = num_attr(coord_y[2]), y2 = num_attr(coord_y[2]))
            # Q3
            ET.SubElement(fig, "line", attrib = {'class': "quartile3"}, x1 = num_attr(coord_x), x2 = num_attr(coord_x + bar_width), y1 = num_attr(coord_y[3]), y2 = num_attr(coord_y[3]))
            # IQR sides
            ET.SubElement(fig, "line", attrib = {'class': "iqr-left-side"}, x1 = num_attr(coord_x), x2 = num_attr(coord_x), y1 = num_attr(coord_y[1]), y2 = num_attr(coord_y[3]))
            ET.SubElement(fig, "line", attrib = {'class': "iqr-right-side"}, x1 = num_attr(coord_x + bar_width), x2 = num_attr(coord_x + bar_width), y1 = num_attr(coord_y[1]), y2 = num_attr(coord_y[3]))
            # Upper whisker
            ET.SubElement(fig, "line", attrib = {'class': "upper-whisker"}, x1 = num_attr(coord_x), x2 = num_attr(coord_x + bar_width), y1 = num_attr(coord_y[4]), y2 = num_attr(coord_y[4]))
            ET.SubElement(fig, "line", attrib = {'class': "upper-line"}, x1 = num_attr(coord_x + bar_width/2), x2 = num_attr(coord_x + bar_width/2), y1 = num_attr(coord_y[3]), y2 = num_attr(coord_y[4]))

            if box_plot_param["mean"]:
                x_middle = coord_x + bar_width/2
                pl_side = min(10, max(5, bar_width/8))
                points_mean_bp = " ".join([
                    num_attr(x_middle - pl_side) + "," + num_attr(coord_y[5]),
                    num_attr(x_middle) + "," + num_attr(coord_y[5] + pl_side),
                    num_attr(x_middle + pl_side) + "," + num_attr(coord_y[5]),
                    num_attr(x_middle) + "," + num_attr(coord_y[5] - pl_side),
                    num_attr(x_middle - pl_side) + "," + num_attr(coord_y[5])
                ])

                ET.SubElement(fig, "polyline", attrib = {'class': "mean"}, points = points_mean_bp)

            # Outliers
            if box_plot_param["outliers"]:
                if len(coord_y) > start_outliers:
                    for outlier in coord_y[start_outliers:]:
                        ET.SubElement(fig, "circle", attrib = {'class': "outlier"}, r = str(circles), cx = num_attr(coord_x + bar_width/2), cy = num_attr(outlier))

            # Move to next i_y
            # continue

        # For each data point
        num_data_points = min(len(x), len(y[i_y])) if chart_type[i_y] != "box plot" else len(y[i_y])
        for i in range(num_data_points):
            y_value = y_values[i_y][i] if bar_param["stack"] else y[i_y][i]
            if y[i_y][i] is not None:
                if chart_type[i_y] != "box plot":
                    if x_type_number:
                        coord_x = x_interval_px * (x[i] - x_min) + x_ticks_margin
                    else:
                        coord_x = x_interval_px * i + x_ticks_margin

                    coord_y = (y_max - y[i_y][i]) * chart_height / (y_max - y_min)
                        
                # <path>
                if "line" in chart_type[i_y] :
                    if first and (i == len(y[i_y]) - 1 or y[i_y][i+1] is None):
                        isolated_point = True
                    else:
                        isolated_point = False
                        command = "M " if first else "L "
                        points += command + num_attr(coord_x) + "," + num_attr(coord_y) + " "
                else:
                    isolated_point = True
                
                # extra data
                if isinstance(extra_data, Seq):
                    try:
                        extra_text = extra_data[i_y][i]
                    except (IndexError, TypeError):
                        extra_text = None
                else:
                    extra_text = None
                
                # show some values
                x_value = x[i] if chart_type[i_y] != "box plot" else i
                show_val = show_values is not None and (show_values == "all" or x_value in show_values)
                cur_text = None
                if show_val or "vertical line" in tooltip_type or "value" in tooltip_type:
                    if isinstance(values_format, Seq):
                        try:
                            val_fmt = values_format[i_y]
                        except IndexError:
                            val_fmt = None
                    else:
                        val_fmt = values_format
                    
                    if val_fmt is not None:
                        if chart_type[i_y] == "box plot":
                            if i >= start_outliers:
                                bp_el_pos = 2*i + start_outliers - int(box_plot_param["mean"])
                                current_bp_el = fig[bp_el_pos]
                                coord_x = float(current_bp_el.get("cx"))
                                coord_y = float(current_bp_el.get("cy"))
                            elif i == 5 and box_plot_param["mean"]:
                                bp_el_pos = 15
                                mean_pt = []
                                for p in fig[bp_el_pos].get("points").split(","):
                                    mean_pt.extend(p.split(" "))
                                coord_x = float(mean_pt[2])
                                coord_y = float(mean_pt[1])
                            else:
                                if i == 0 :
                                    bp_el_pos = 1
                                elif i == 1 :
                                    bp_el_pos = 3
                                elif i == 2 :
                                    bp_el_pos = 4
                                elif i == 3 :
                                    bp_el_pos = 5
                                elif i == 4 :
                                    bp_el_pos = 8
                                bp_el_pos = bp_el_pos + i
                                current_bp_el = fig[bp_el_pos]
                                coord_x = float(current_bp_el.get("x1")) if values_position == "left" else float(current_bp_el.get("x2"))
                                coord_y = float(current_bp_el.get("y2"))

                        val = format_text_numbers(val_fmt.format(y_value, y = y_value, y_unit = y_unit, name = names_text[i_y], x = x_value, x_unit = x_unit, extra = extra_text), big_mark, decimal_mark)
                        if val != "":
                            if values_position == "fixed above chart":
                                x_pos = "0" if y_unit is None else num_attr(5 + (len(y_unit) * font_size / 2))
                            elif values_position == "fixed under chart":
                                x_pos = "0"
                            else:
                                x_pos = num_attr(coord_x + values_position_shift[0])
                            if "\n" in val:
                                newline_in_values_format = True
                                cur_text = ET.Element("text")
                                i = 0
                                for t in val.split("\n"):
                                    dy = 'dy="1.3em"' if i > 0 else ''
                                    tspan = f"<tspan x='{x_pos}' {dy}>" + t + "</tspan>"
                                    tspan = ET.fromstring(tspan)
                                    cur_text.append(tspan)
                                    i =+ 1
                            else:
                                cur_text = ET.fromstring("<text>" + val + "</text>")
                                cur_text.set("x", x_pos)

                            if values_position == "fixed above chart":
                                y_pos = - font_size*1.25
                            elif values_position == "fixed under chart":
                                y_pos = chart_height + abscissa_height + font_size
                            else:
                                y_pos = coord_y + values_position_shift[1]
                            cur_text.set("y", num_attr(y_pos))
                            
                            cl = "" if show_val else "hide"
                            if "vertical line" in tooltip_type:
                                cl = cl + f" x{i + 1}"
                            if cl != "":
                                cur_text.attrib["class"] = cl.strip()
                            
                            if chart_type[i_y] == "box plot":
                                fig.insert(bp_el_pos + 1, cur_text)
                                cur_text = None

                # text for <title> tooltip
                if "title" in tooltip_type:
                    if isinstance(title_tooltip_format, Seq):
                        try:
                            tooltip_text = title_tooltip_format[i_y]
                        except IndexError:
                            tooltip_text = DEFAULT_TOOLTIP
                    else:
                        tooltip_text = title_tooltip_format
                    
                    if tooltip_text is not None and tooltip_text != "":
                        tooltip_text = format_text_numbers(
                            tooltip_text.format(name = names_text[i_y], x = x_value, x_unit = x_unit, y = y_value, y_unit = y_unit, extra = extra_text),
                            big_mark,
                            decimal_mark)
 
                    if chart_type[i_y] == "box plot":
                        if i >= start_outliers:
                            current_bp_el = fig.findall("circle")[i-start_outliers]
                        elif box_plot_param["mean"] and i == 5:
                            current_bp_el = fig.find("polyline")
                        else:
                            if i == 0 :
                                bp_el_pos = 0
                            elif 1 <= i <= 3 :
                                bp_el_pos = i + 1
                            elif i == 4 :
                                bp_el_pos = 7
                            current_bp_el = fig.findall("line")[bp_el_pos]
                        ET.SubElement(current_bp_el, "title").text = replace_tags(tooltip_text)

                # bar: <rect>
                if chart_type[i_y] == "bar":
                    if chart_decimals_defined:
                        nb_decimals = CHART_DECIMALS
                    elif bar_param["stack"]:
                        nb_decimals = 4
                    else:
                        nb_decimals = 2
                    if y_value == 0:
                        cur_text = None
                    else:
                        if bar_param["group"] == "series":
                            old_x_interval_px = x_interval_px * num_bars / len(x)
                            bar_width = old_x_interval_px * bar_param["group_padding"] / num_bars
                            coord_x = old_x_interval_px * i + x_ticks_margin
                            rect_x = coord_x - i * old_x_interval_px + current_bar * x_interval_px + i * bar_width - x_interval_px * bar_param["group_padding"] / 2 + bar_width * (1 - bar_param["bar_padding"]) / 2

                        else:
                            bar_width = x_interval_px * bar_param["group_padding"] / num_bars
                            rect_x = coord_x + bar_width * current_bar - bar_width * (num_bars - (1-bar_param["bar_padding"])) / 2
                        
                        bar_width = bar_width * bar_param["bar_padding"]
                        if y_value >= 0:
                            rect_y = coord_y
                            bar_height = chart_height - coord_y if y_sign == 1 and not bar_param["stack"] else y_value * y_interval_px
                        elif bar_param["stack"]:
                            rect_y = max(0, (y_value - y[i_y][i] + y_max) * y_interval_px)
                            bar_height = (y_max - y_value) * y_interval_px if first_bar and y_sign == -1 else -y_value * y_interval_px
                        else:
                            rect_y = 0 if y_sign == -1 else y_max * y_interval_px
                            bar_height = (y_max - y_value) * y_interval_px if y_sign == -1 else -y_value * y_interval_px

                        cur_rect = ET.SubElement(fig, "rect", x = num_attr(rect_x), y = num_attr(rect_y, nb_decimals), width = num_attr(bar_width), height = num_attr(bar_height, nb_decimals))
                        isolated_point = False
                        if cur_text is not None:
                            if values_position == "fixed above chart":
                                x_pos = "0" if y_unit is None else num_attr(5 + (len(y_unit) * font_size / 2))
                            elif values_position == "fixed under chart":
                                x_pos = "0"
                            else:
                                x_pos = num_attr(rect_x + bar_width/2 + values_position_shift[0])
                            cur_text.set("x", x_pos)
                        if "title" in tooltip_type:
                            ET.SubElement(cur_rect, "title").text = replace_tags(tooltip_text)
                
                # <circle>
                elif chart_type[i_y] != "box plot" and (show_circles or cur_text is not None or isolated_point):
                    cur_circle = ET.SubElement(fig, "circle", r = str(circles), cx = num_attr(coord_x), cy = num_attr(coord_y))
                    cl = "" if show_val or isolated_point or "scatter" in chart_type[i_y] else "hide"
                    if "vertical line" in tooltip_type:
                        cl = cl + f" x{i + 1}"
                    if cl != "":
                        cur_circle.attrib["class"] = cl.strip()
                    
                    if "title" in tooltip_type and tooltip_text is not None:
                        ET.SubElement(cur_circle, "title").text = replace_tags(tooltip_text)
                
                # Add <text> after <circle>
                if cur_text is not None:
                    fig.append(cur_text)
                
                if first:
                    first = False

            else:
                first = True
        
        if points != "":
            fig.insert(1, ET.Element("path", d = points, fill = "none", attrib = {'stroke-width': "3", 'stroke-linejoin': "round"}))

        if chart_type[i_y] in ("bar", "box plot") and not bar_param["stack"]:
            current_bar += 1
        
        if first_bar:
            first_bar = False
        
        # go to next series


    # Extra font lines
    translate.extend(front_lines)
    
    ## Legend ##
    if legend_position is not None and legend_position != "" and legend_position != "no":
        # x coordinate
        if legend_position == "right":
            coord_x = chart_width + 25
        elif legend_position == "left":
            coord_x = 20 - spaces.left
        elif "right" in legend_position:
            coord_x = chart_width - legend_width
        elif legend_position == "top":
            coord_x = 20 if y_unit is None else 5 + (len(y_unit) * font_size / 2)
        elif legend_position == "bottom":
            coord_x = 20 - spaces.left
        else:
            coord_x = 20
        
        # y coordinate
        if legend_position in ["right", "left", "top right", "top left"]:
            coord_y = font_size
        elif legend_position == "top" and values_position == "fixed above chart":
            coord_y = -font_size * 2.5
        elif legend_position == "top":
            coord_y = -font_size * 1.25
        elif legend_position == "bottom":
            coord_y = chart_height + abscissa_height + font_size
            if x_unit != "" or values_position == "fixed under chart":
                coord_y = coord_y + font_size * 1.5
        elif "bottom" in legend_position:
            coord_y = chart_height - (2 * font_size * len(y))
            
        if legend_background is not None:
            coord_y_rect = coord_y - font_size + 2
        
        # Symbol + text

        # If stacked bar chart, reorder series_plots, chart_type, names, names_text
        if bar_param["stack"]:
            # Other types before bars
            others = [i for i, c in enumerate(chart_type) if c != "bar"]
            bars_order = [i for i, c in enumerate(chart_type) if c == "bar"]
            if not all([all([val <= 0 for val in y[i] if val is not None]) for i in bars_order]):
                bars_order.reverse()
            ranks = others + bars_order
            series_plots = [series_plots[ranks[i]] for i in range(len(y))]
            chart_type = [chart_type[ranks[i]] for i in range(len(y))]
            names = [names[ranks[i]] for i in range(len(y))]
            names_text = [names_text[ranks[i]] for i in range(len(y))]

        for i_y in range(len(y)):
            g_legend = ET.SubElement(series_plots[i_y], "g", id = f"legend{i_y + 1}", attrib = {'class': "legend"})
            if "line" in chart_type[i_y] :
                ET.SubElement(g_legend, "line", {'stroke-width': "5"}, x1 = num_attr(coord_x), x2 = num_attr(coord_x + 25), y1 = num_attr(coord_y), y2 = num_attr(coord_y))
            elif "bar" in chart_type[i_y]:
                ET.SubElement(g_legend, "rect", x = num_attr(coord_x + 12.5 - 5), width = num_attr(10), y = num_attr(coord_y - 0.75 * font_size), height = num_attr(font_size*1.5))
            elif "box plot" in chart_type[i_y]:
                lg_width = 10
                lg_height = font_size * 0.8
                x_left = coord_x + 12.5 - lg_width/2
                y_top = coord_y - 0.43 * font_size
                points = " ".join([
                    num_attr(x_left) + "," + num_attr(y_top),
                    num_attr(x_left + lg_width) + "," + num_attr(y_top),
                    num_attr(x_left + lg_width) + "," + num_attr(y_top + lg_height),
                    num_attr(x_left) + "," + num_attr(y_top + lg_height),
                    num_attr(x_left) + "," + num_attr(y_top)
                ])

                ET.SubElement(g_legend, "polyline", points = points, fill = "none")
                ET.SubElement(g_legend, "line", x1 = num_attr(x_left), x2 = num_attr(x_left + lg_width), y1 = num_attr(y_top + lg_height/2), y2 = num_attr(y_top + lg_height/2))
                ET.SubElement(g_legend, "line", x1 = num_attr(x_left + lg_width/2), x2 = num_attr(x_left + lg_width/2), y1 = num_attr(y_top), y2 = num_attr(y_top - 0.35 * font_size))
                ET.SubElement(g_legend, "line", x1 = num_attr(x_left), x2 = num_attr(x_left + lg_width), y1 = num_attr(y_top - 0.35 * font_size), y2 = num_attr(y_top - 0.35 * font_size))
                ET.SubElement(g_legend, "line", x1 = num_attr(x_left + lg_width/2), x2 = num_attr(x_left + lg_width/2), y1 = num_attr(y_top + lg_height), y2 = num_attr(y_top + 1.15 * font_size))
                ET.SubElement(g_legend, "line", x1 = num_attr(x_left), x2 = num_attr(x_left + lg_width), y1 = num_attr(y_top + 1.15 * font_size), y2 = num_attr(y_top + 1.15 * font_size))
            
            if "scatter" in chart_type[i_y] or show_values == "all":
                ET.SubElement(g_legend, "circle", cx = num_attr(coord_x + 12.5), cy = num_attr(coord_y), r = num_attr(circles))

            if names_text[i_y] != names[i_y]:
                cur_legend = ET.SubElement(g_legend, "text", x = num_attr(coord_x + 40), y = num_attr(coord_y + font_size/3))
                if names[i_y].startswith("<") and names[i_y].endswith(">"):
                    cur_legend.append(ET.fromstring(names[i_y]))
                else:
                    cur_legend.append(ET.fromstring("<tspan>" + names[i_y] + "</tspan>"))
            else:
                ET.SubElement(g_legend, "text", x = num_attr(coord_x + 40), y = num_attr(coord_y + font_size/3)).text = f"{names[i_y]}"
            
            if legend_position in ["top", "bottom"]:
                coord_x += 60 + (len(names_text[i_y]) * font_size / 2)
            else:
                coord_y += 2 * font_size
        
        # Add a rect background color behind the legend elements
        if legend_background is not None and legend_background != "":
            if legend_position in ("top", "bottom"):
                height = 2 * font_size
                end_x = coord_x
                if legend_position == "top":
                    coord_x = 20 if y_unit is None else 5 + (len(y_unit) * font_size / 2)
                else:
                    coord_x = 20 - spaces.left
                legend_width = end_x - coord_x + 25
            else:
                height = 2 * font_size * len(y)
            pos = len(translate) - 1
            translate.insert(pos, ET.Element("rect", id = "legend_bg", opacity = "0.7", x = num_attr(coord_x - 5), width = num_attr(legend_width), y = num_attr(coord_y_rect), height = num_attr(height - 4), fill = legend_background))
    
    ## If newline in values_format
    if newline_in_values_format:
        try:
            filter_bg_val.set("y", "0")
            filter_bg_val.set("height", "1")
        except UnboundLocalError:
            pass
    
    ## Notes ##
    
    if notes is not None and len(notes) > 0:
        text_notes = ET.SubElement(translate, "text", id = "notes")
        text_y = chart_height + abscissa_height
        if legend_position == "bottom":
            text_y += legend_height
        if x_unit != "" or values_position == "fixed under chart":
            text_y += font_size * 1.5
        
        text_notes.attrib["y"] = num_attr(text_y)

        if not isinstance(notes, Seq):
            notes = (notes, )

        for n in notes:
            tag = n[:3]
            if tag in ["<i>", "<b>"]:
                n = n[3:]
            
            n = "<tspan>" + n + "</tspan>"
            tspan = ET.fromstring(n)
            tspan.attrib = {'x': num_attr(20 - spaces.left), 'dy': "1.5em"}
            if tag == "<i>":
                tspan.attrib["font-style"] = "italic"
            elif tag == "<b>":
                tspan.attrib["font-weight"] = "bold"
            text_notes.append(tspan)
    
    ## CSS ##
    # Dark mode
    if background_color is None or background_color in ("white", "black"):
        if dark_mode == "user":
            style_css.append(":root {color-scheme: light dark;}")
            style_css.append("@media (prefers-color-scheme: dark) {")
            style_css.append("  rect.background-color {display: none;}")
            style_css.extend(["  " + c for c in DARK_MODE_CSS])
            style_css.append("}")
            
        elif dark_mode == "force":
            style_css.append(":root {color-scheme: dark;}")
            style_css.extend(DARK_MODE_CSS)
    
    # Personalised css
    if css is not None:
        css = [css] if isinstance(css, str) else css
        style_css.extend(css)
    
    # String transformation
    if pretty:
        style_css = ["    " + c for c in style_css]
    
    css_sep = "\n" if pretty else " "
    style_css = css_sep.join(style_css)
    
    style.text = css_sep + style_css + css_sep

    if pretty:
        # requires Python >= 3.9 : https://docs.python.org/3/library/xml.etree.elementtree.html#xml.etree.ElementTree.indent
        try:
            ET.indent(chart)
        except AttributeError:
            python_version = "python " + ".".join(map(str, sys.version_info[:3]))
            logging.warning(f"⚠️  You're using {python_version}, but python >= 3.9 required if parameter pretty=True (because it's using `xml.etree.ElementTree.indent` function)\n➡️ The SVG output won't be prettified")
    
    if output == "string":
        chart = ET.tostring(chart, encoding = "UTF-8").decode("UTF-8")
        # try:
            # chart = ET.tostring(chart, encoding = "UTF-8", xml_declaration = True).decode("UTF-8")
        # except TypeError:
            # `xml_declaration` parameter added in Python 3.8 : https://docs.python.org/3/library/xml.etree.elementtree.html#xml.etree.ElementTree.tostring
            # chart = ET.tostring(chart, encoding = "UTF-8").decode("UTF-8")
    
    elif output != "etree":
        ET.ElementTree(chart).write(output, encoding = "UTF-8", xml_declaration = True)
        logging.info(f"chart written in file {output}")
        # return

    logging.info(chart.__class__)
    
    return chart

# Alternate functions with fixed chart_type

# https://www.geeksforgeeks.org/python/transfer-kwargs-parameter-to-a-different-function-in-python/
def line_chart(**kwargs):
    """ Create a SVG line chart """
    return chart(chart_type = "line", **kwargs)

def scatter_chart(**kwargs):
    """ Create a SVG scatter chart """
    return chart(chart_type = "scatter", **kwargs)

def scatter_line_chart(**kwargs):
    """ Create a SVG scatter + line chart """
    return chart(chart_type = "scatter line", **kwargs)

def bar_chart(**kwargs):
    """ Create a SVG bar chart """
    return chart(chart_type = "bar", **kwargs)

def box_plot_chart(**kwargs):
    """ Create a SVG box plot chart """
    return chart(chart_type = "box plot", **kwargs)

# Utility functions
def replace_tags(text: str, keep_title: bool = True) -> str:
    """ Remove xml tags from a string, while keeping their content except for <title> if keep_title is False """
    if keep_title:
        text = re.sub(r"<title[^>]*>([^<]+)</title>", " (\\1) ", text)
    else:
        text = re.sub(r"<title[^>]*>([^<]+)</title>", " ", text)
    text = re.sub(r"<[^<]+>", "", text)
    text = re.sub(" {2,}", " ", text)
    return(text.strip())

def num_attr(x: float, decimals: int = CHART_DECIMALS) -> str:
    """ Convert a float to string, while first converting it to integer if this number is_integer() or rounding it if it isn't """

    # For avoiding floating-point issues (like 6.4 + 0.2 = 6.6000000000000005), value must be rounded first.
    # Drawback: it is slower, chart creation takes about 1ms more for 1 to 5 thousands data points (depending on chart type too).
    # https://docs.python.org/3/tutorial/floatingpoint.html
    # x = round(x, decimals)
    if isinstance(x, float) and x.is_integer():
        return str(int(x))
    elif isinstance(x, float):
        return f"{{:.{decimals}f}}".format(x)

    return(str(x))

def format_text_numbers(text: str, big_mark: str, decimal_mark: str) -> str:
    """ Replace characters "_" and "." in a string by specified replacements """
    if big_mark is not None and big_mark != "":
        text = text.replace('_', big_mark)
    if decimal_mark is not None and decimal_mark != "":
       text = text.replace('.', decimal_mark)
    return text

