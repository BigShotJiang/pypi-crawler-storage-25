import brainforge.auth as auth
import click
from brainforge.run import generate_sbatch_script
from brainforge.run import parse_spec
from brainforge.run import submit_job
from brainforge.run import validate_spec


@click.group()
@click.version_option(version="0.1.0")
def main():
    """
    Brainforge command-line interface.
    """
    pass


@main.command()
def info():
    """Display information about Brainforge CLI."""
    click.echo("Welcome to the Brainforge CLI v0.1.0")
    click.echo("Run 'brainforge --help' to see all available commands.")


@main.command()
def login():
    """Authenticate with Globus."""
    auth.login()


@main.command()
def logout():
    """Logout of Globus."""
    auth.logout()


@main.command()
@click.argument('spec_file', type=click.Path(exists=True, dir_okay=False))
@click.option(
    '--dry-run',
    is_flag=True,
    help="Generate and print the sbatch script without submitting to SLURM.",
)
def run(spec_file, dry_run):
    """Run a SLURM job with a YAML spec file."""
    # Parse the YAML
    spec = parse_spec(spec_file)

    # Validate the spec
    validate_spec(spec)

    # Generate script
    script_content = generate_sbatch_script(spec)

    # Submit job (or print if dry_run)
    submit_job(script_content, spec, dry_run=dry_run)


if __name__ == "__main__":
    main()
