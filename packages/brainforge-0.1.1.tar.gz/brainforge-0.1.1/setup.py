from setuptools import find_packages
from setuptools import setup

setup(
    name="brainforge",
    version="0.1.1",
    description="Command-line interface for Brainforge",
    author="Daniel Trinh",
    packages=find_packages(),
    install_requires=[
        "requests",
        "click",
        "PyYAML",
        "globus-sdk",
    ],
    entry_points={
        "console_scripts": [
            "brainforge=brainforge.cli:main",
        ],
    },
    python_requires=">=3.8",
)
