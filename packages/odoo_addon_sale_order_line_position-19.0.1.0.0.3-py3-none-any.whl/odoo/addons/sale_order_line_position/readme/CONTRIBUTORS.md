- Thierry Ducrest \<<thierry.ducrest@camptocamp.com>\>
- [Trobz](https://trobz.com):
  - Nguyen Hoang Hiep \<<hiepnh@trobz.com>\>
  - Do Anh Duy \<<duyda@trobz.com>\>
  - Kien Kim Khoi \<<khoikk@trobz.com>\>
- Nils Coenen \<<nils.coenen@nico-solutions.de>\>

