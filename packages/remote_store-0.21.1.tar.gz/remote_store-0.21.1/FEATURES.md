# Features — remote-store v0.21.1

Authoritative snapshot of the Store API, capabilities, backends,
extensions, and install extras for the current version. Updated each
release.

---

## Store API

The Store provides a portable API for file operations across any
backend. Methods are grouped by capability gate. Query at runtime with
`store.supports(Capability.X)`.

### Ungated (always available)

| Method | Description |
|---|---|
| `exists(path)` | Check whether a file exists |
| `is_file(path)` | Check whether a path is a file |
| `is_folder(path)` | Check whether a path is a folder |
| `ping()` | Health check — verify backend is reachable |
| `close()` | Release backend resources |
| `child(subpath)` | Create a scoped sub-store |
| `unwrap(type_hint)` | Extract underlying backend by type |
| `resolve(key)` | Return the resolution plan for a key |
| `native_path(key)` | Return the backend-native path for a key |
| `to_key(path)` | Convert a native path back to a store key |
| `supports(capability)` | Query whether a capability is available |

### READ

| Method | Description |
|---|---|
| `read(path)` | Open a binary stream for reading |
| `read_bytes(path)` | Read entire file into bytes |
| `read_text(path)` | Read entire file as decoded string |
| `read_seekable(path)` | Open a seekable binary stream (always seekable via spool fallback) |

### WRITE

| Method | Description |
|---|---|
| `write(path, content)` | Create or overwrite a file |
| `write_text(path, text)` | Write a string as a file |

### ATOMIC_WRITE

| Method | Description |
|---|---|
| `write_atomic(path, content)` | Write via temp-and-rename (no partial reads) |
| `open_atomic(path)` | Context manager for streaming atomic writes |

### DELETE

| Method | Description |
|---|---|
| `delete(path)` | Remove a file |
| `delete_folder(path)` | Remove a folder |

### LIST

| Method | Description |
|---|---|
| `list_files(path)` | Enumerate files under a path |
| `list_folders(path)` | Enumerate subfolders under a path |
| `iter_children(path)` | Iterate files and folders together |

### MOVE

| Method | Description |
|---|---|
| `move(src, dst)` | Rename or relocate within same backend |

### COPY

| Method | Description |
|---|---|
| `copy(src, dst)` | Duplicate within same backend |

### METADATA

| Method | Description |
|---|---|
| `get_file_info(path)` | Retrieve file metadata (size, modified, etc.) |
| `get_folder_info(path)` | Retrieve folder metadata and contents |

### GLOB

| Method | Description |
|---|---|
| `glob(pattern)` | Native pattern matching on file paths |

---

## Capabilities

Capabilities gate which Store methods are available for a given backend.
Query at runtime with `store.supports(Capability.X)`.

| Capability | Description | Gated methods |
|---|---|---|
| `READ` | Stream or bulk-read file content | `read()`, `read_bytes()`, `read_text()`, `read_seekable()` |
| `WRITE` | Create or overwrite files | `write()`, `write_text()` |
| `DELETE` | Remove files and folders | `delete()`, `delete_folder()` |
| `LIST` | Enumerate files and subfolders | `list_files()`, `list_folders()`, `iter_children()` |
| `MOVE` | Rename/relocate within same backend | `move()` |
| `COPY` | Duplicate within same backend | `copy()` |
| `ATOMIC_WRITE` | Write via temp-and-rename (no partial reads) | `write_atomic()`, `open_atomic()` |
| `METADATA` | Retrieve file/folder metadata | `get_file_info()`, `get_folder_info()` |
| `GLOB` | Native pattern matching on file paths | `glob()` |
| `SEEKABLE_READ` | `read()` returns natively seekable streams | — (quality flag, not a method gate) |

---

## Backends

Backends implement storage-specific behavior behind the Store API.

| Type string | Description | Class | Extras | Always available | Capabilities |
|---|---|---|---|---|---|
| `local` | Local filesystem storage | `LocalBackend` | — | Yes | ALL |
| `memory` | In-memory store for testing and caching | `MemoryBackend` | — | Yes | All except GLOB |
| `http` | Read-only HTTP file access (stdlib urllib; optional `requests`/`httpx` adapters) | `ReadOnlyHttpBackend` | — (`requests`, `httpx` optional) | Yes | READ, METADATA |
| `s3` | Amazon S3 via s3fs | `S3Backend` | `pip install remote-store[s3]` | No | ALL |
| `s3-pyarrow` | Amazon S3 via PyArrow C++ filesystem | `S3PyArrowBackend` | `pip install remote-store[s3-pyarrow]` | No | ALL |
| `sftp` | SFTP via paramiko | `SFTPBackend` | `pip install remote-store[sftp]` | No | All except GLOB |
| `azure` | Azure Data Lake Storage via Azure SDK | `AzureBackend` | `pip install remote-store[azure]` | No | All except SEEKABLE_READ |
| `sql-blob` | SQL blob store via SQLAlchemy | `SQLBlobBackend` | `pip install remote-store[sql]` | No | ALL |
| `sql-query` | SQL query store for tabular data via SQLAlchemy + PyArrow | `SQLQueryBackend` | `pip install remote-store[sql-query]` | No | READ, LIST, METADATA, GLOB, SEEKABLE_READ |

---

## Configuration

`RegistryConfig` manages backend and store definitions. Load from dicts,
TOML, YAML, or Pydantic models. Credentials in sensitive keys are
auto-wrapped in `Secret`.

| Function / Method | Description | Location |
|---|---|---|
| `RegistryConfig.from_dict(data)` | Construct from a plain dict | `remote_store` |
| `RegistryConfig.from_toml(path, *, table, resolve_env_vars)` | Load from a TOML file | `remote_store` |
| `from_yaml(path, *, resolve_env_vars)` | Load from a YAML file | `remote_store.ext.yaml` |
| `from_pydantic(model)` | Convert a Pydantic model | `remote_store.ext.pydantic` |
| `resolve_env(data, *, environ)` | Resolve `${VAR}` / `${VAR:-default}` placeholders in a config dict | `remote_store` |

---

## Extensions

Extensions add optional capabilities alongside the core.

### Always available (included in base install)

| Extension | Description | Module | Key exports |
|---|---|---|---|
| Batch | Bulk copy, delete, and existence checks across files | `remote_store.ext.batch` | `BatchResult`, `batch_copy`, `batch_delete`, `batch_exists` |
| Cache | Transparent read-through caching layer | `remote_store.ext.cache` | `CachedStore`, `CacheBackend`, `CacheStats`, `MemoryCache`, `cache` |
| Glob | Portable glob for backends without native GLOB capability | `remote_store.ext.glob` | `glob_files` |
| Integrity | Content checksums and digest verification | `remote_store.ext.integrity` | `checksum`, `verify`, `verify_hex`, `content_digest` |
| Observe | Event hooks and operation logging | `remote_store.ext.observe` | `BufferedObserver`, `ObservedStore`, `StoreEvent`, `observe`, `set_correlation_id` |
| Partition | Hive-style partition path parsing and construction | `remote_store.ext.partition` | `ParsedPartition`, `parse_partition`, `partition_path` |
| Streams | Progress reporting and checksum wrappers for streams | `remote_store.ext.streams` | `ChecksumReader`, `ChecksumWriter`, `ProgressReader`, `ProgressWriter`, `read_with_progress` |
| Transfer | High-level upload, download, and store-to-store transfer | `remote_store.ext.transfer` | `upload`, `download`, `transfer` |

### Optional (require extras)

| Extension | Description | Module | Key exports | Extras |
|---|---|---|---|---|
| Arrow | PyArrow filesystem bridge | `remote_store.ext.arrow` | `StoreFileSystemHandler`, `pyarrow_fs` | `pip install remote-store[arrow]` |
| Parquet | Read and write Parquet files via PyArrow | `remote_store.ext.parquet` | `ParquetDatasetStore`, `DatasetManifest` | `pip install remote-store[arrow]` |
| OpenTelemetry | Distributed tracing spans for store operations | `remote_store.ext.otel` | `otel_hooks`, `otel_observe` | `pip install remote-store[otel]` |
| Pydantic | Pydantic settings integration for store configuration | `remote_store.ext.pydantic` | `from_pydantic` | `pip install remote-store[pydantic]` |
| YAML | YAML configuration file loading | `remote_store.ext.yaml` | `from_yaml` | `pip install remote-store[yaml]` |
| Dagster | Dagster IO manager and resource integration | `remote_store.ext.dagster` | `RemoteStoreIOManager`, `DagsterStoreResource`, `dagster_io_manager` | `pip install remote-store[dagster]` |

---

## Async API

The `remote_store.aio` module provides native `async`/`await` support.

| Class | Description |
|---|---|
| `AsyncStore` | Async counterpart to `Store` with coroutine methods for all operations |
| `AsyncBackend` | Abstract base class for native async backends |
| `SyncBackendAdapter` | Wraps any synchronous backend for async use via thread-pool executor |
| `AsyncMemoryBackend` | In-memory async backend for testing |
| `AsyncAzureBackend` | Native async Azure backend using Azure SDK async clients |
| `AsyncWritableContent` | Type alias: `bytes | AsyncIterator[bytes]` |

---

## Install extras

```
pip install remote-store[s3]          # S3 via s3fs
pip install remote-store[s3-pyarrow]  # S3 via s3fs + PyArrow
pip install remote-store[sftp]        # SFTP via paramiko
pip install remote-store[azure]       # Azure Data Lake via azure SDK
pip install remote-store[sql]         # SQL blob store via SQLAlchemy
pip install remote-store[sql-query]   # SQL query store via SQLAlchemy + PyArrow
pip install remote-store[arrow]       # PyArrow filesystem + Parquet extension
pip install remote-store[otel]        # OpenTelemetry tracing
pip install remote-store[pydantic]    # Pydantic settings integration
pip install remote-store[yaml]        # YAML config loading
pip install remote-store[dagster]     # Dagster IO manager
pip install remote-store[toml]        # TOML config (stdlib on 3.11+)
pip install remote-store[requests]    # requests HTTP adapter
pip install remote-store[httpx]       # httpx HTTP adapter
```
