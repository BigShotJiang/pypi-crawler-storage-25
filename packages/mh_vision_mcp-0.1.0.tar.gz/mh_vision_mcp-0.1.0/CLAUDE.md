# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
# Install in editable mode
pip install -e .

# Run the MCP server (stdio transport)
vision-mcp

# Test tools directly without an MCP client
python test_tools.py describe <image_source>
python test_tools.py ocr <image_source>
python test_tools.py extract_ui <image_source> [--format markdown]
python test_tools.py analyze_diagram <image_source>
python test_tools.py describe ./screenshot.png --focus "buttons and navigation"

# Lint
ruff check

# Tests
pytest
```

## Architecture

**`server.py`** is the entry point. It loads config, instantiates a provider via the factory, then conditionally registers MCP tools using `@mcp.tool()`. Tools are only registered if `tools.<name>.enabled` is `true` in config — the decorator never fires for disabled tools, so they genuinely don't exist in the server.

**`config.py`** loads `config.yaml` (or the path in `VISION_MCP_CONFIG` env var) into a Pydantic `AppConfig` model. Falls back to all defaults if no file is found. The `AppConfig.get_provider_config()` method dynamically returns the right sub-config for the active provider.

**`image.py`** — `load_image(source)` normalizes any image source into `ImagePayload(data: str, mime_type: str)` where `data` is always base64-encoded. Resolution order: data URI → HTTP/S URL → local file path → raw base64 (last resort, assumes `image/jpeg`).

**`providers/`** — the provider abstraction:
- `base.py`: `BaseVisionProvider` ABC with a single contract: `async query(image: ImagePayload, prompt: str) → str`
- `__init__.py`: `get_provider(config)` factory that maps provider name → concrete class
- `ollama.py`, `openai.py`, `anthropic.py`, `zhipuai.py`: concrete implementations

**`errors.py`** — exception hierarchy: `VisionMCPError` (base) → `ImageLoadError`, `ProviderError`, `ConfigError`. The `_run()` wrapper in `server.py` catches all three and returns them as string error messages to the MCP caller rather than crashing.

## Adding a New Provider

1. Create `src/vision_mcp/providers/<name>.py` implementing `BaseVisionProvider` (`query` + `name`)
2. Add a config model in `config.py` and add it to `ProvidersConfig`
3. Register it in the `get_provider()` factory in `providers/__init__.py`
4. Add an entry under `providers:` in `config.yaml`

## Configuration

`config.yaml` controls the active provider, model, provider-specific credentials, and per-tool enable/disable. The `VISION_MCP_CONFIG` env var overrides the config file path.

<!-- code-review-graph MCP tools -->
## MCP Tools: code-review-graph

**IMPORTANT: This project has a knowledge graph. ALWAYS use the
code-review-graph MCP tools BEFORE using Grep/Glob/Read to explore
the codebase.** The graph is faster, cheaper (fewer tokens), and gives
you structural context (callers, dependents, test coverage) that file
scanning cannot.

### When to use graph tools FIRST

- **Exploring code**: `semantic_search_nodes` or `query_graph` instead of Grep
- **Understanding impact**: `get_impact_radius` instead of manually tracing imports
- **Code review**: `detect_changes` + `get_review_context` instead of reading entire files
- **Finding relationships**: `query_graph` with callers_of/callees_of/imports_of/tests_for
- **Architecture questions**: `get_architecture_overview` + `list_communities`

Fall back to Grep/Glob/Read **only** when the graph doesn't cover what you need.

### Key Tools

| Tool | Use when |
|------|----------|
| `detect_changes` | Reviewing code changes — gives risk-scored analysis |
| `get_review_context` | Need source snippets for review — token-efficient |
| `get_impact_radius` | Understanding blast radius of a change |
| `get_affected_flows` | Finding which execution paths are impacted |
| `query_graph` | Tracing callers, callees, imports, tests, dependencies |
| `semantic_search_nodes` | Finding functions/classes by name or keyword |
| `get_architecture_overview` | Understanding high-level codebase structure |
| `refactor_tool` | Planning renames, finding dead code |

### Workflow

1. The graph auto-updates on file changes (via hooks).
2. Use `detect_changes` for code review.
3. Use `get_affected_flows` to understand impact.
4. Use `query_graph` pattern="tests_for" to check coverage.
