"""Tests for vision-mcp configuration models."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from vision_mcp.config import (
    AnthropicConfig,
    AppConfig,
    CustomProviderConfig,
    OllamaCloudConfig,
    OllamaConfig,
    OpenAIConfig,
    ProvidersConfig,
    ToolConfig,
    ToolsConfig,
    ZhipuAIConfig,
    load_config,
)
from vision_mcp.errors import ConfigError


class TestOllamaConfig:
    def test_default_values(self):
        config = OllamaConfig()
        assert config.base_url == "http://localhost:11434"

    def test_custom_base_url(self):
        config = OllamaConfig(base_url="http://custom:8080")
        assert config.base_url == "http://custom:8080"


class TestOpenAIConfig:
    def test_default_values(self):
        config = OpenAIConfig()
        assert config.api_key == ""
        assert config.base_url == "https://api.openai.com/v1"

    def test_custom_values(self):
        config = OpenAIConfig(
            api_key="sk-test",
            base_url="http://localhost:8000/v1",
        )
        assert config.api_key == "sk-test"
        assert config.base_url == "http://localhost:8000/v1"


class TestAnthropicConfig:
    def test_default_values(self):
        config = AnthropicConfig()
        assert config.api_key == ""

    def test_custom_api_key(self):
        config = AnthropicConfig(api_key="sk-ant-test")
        assert config.api_key == "sk-ant-test"


class TestZhipuAIConfig:
    def test_default_values(self):
        config = ZhipuAIConfig()
        assert config.api_key == ""
        assert config.base_url == "https://open.bigmodel.cn/api/paas/v4"


class TestOllamaCloudConfig:
    def test_default_values(self):
        config = OllamaCloudConfig()
        assert config.api_key == ""
        assert config.base_url == "https://api.ollama.com/v1"

    def test_custom_values(self):
        config = OllamaCloudConfig(
            api_key="oc_test",
            base_url="https://custom.ollama.com/v1",
        )
        assert config.api_key == "oc_test"
        assert config.base_url == "https://custom.ollama.com/v1"


class TestCustomProviderConfig:
    def test_openai_compatible_defaults(self):
        config = CustomProviderConfig(
            api_style="openai_compatible",
            base_url="http://localhost:8000/v1",
        )
        assert config.api_style == "openai_compatible"
        assert config.base_url == "http://localhost:8000/v1"
        assert config.api_key == ""
        assert config.model == ""

    def test_ollama_style_defaults(self):
        config = CustomProviderConfig(
            api_style="ollama",
            base_url="http://localhost:11434",
        )
        assert config.api_style == "ollama"
        assert config.base_url == "http://localhost:11434"
        assert config.api_key == ""
        assert config.model == ""

    def test_invalid_api_style(self):
        with pytest.raises(ValidationError):
            CustomProviderConfig(
                api_style="invalid_style",
                base_url="http://localhost:8000/v1",
            )


class TestToolConfig:
    def test_default_values(self):
        config = ToolConfig()
        assert config.enabled is True
        assert config.default_detail == "high"
        assert config.output_format == "json"
        assert config.model is None

    def test_custom_model(self):
        config = ToolConfig(model="gpt-4o")
        assert config.model == "gpt-4o"

    def test_tool_disabled(self):
        config = ToolConfig(enabled=False)
        assert config.enabled is False


class TestToolsConfig:
    def test_default_tools(self):
        config = ToolsConfig()
        assert config.describe_image.enabled is True
        assert config.extract_ui.enabled is True
        assert config.ocr.enabled is True
        assert config.analyze_diagram.enabled is True

    def test_per_tool_model_override(self):
        config = ToolsConfig(
            describe_image=ToolConfig(model="llava:latest"),
            extract_ui=ToolConfig(model="gpt-4o"),
            ocr=ToolConfig(model="moondream"),
            analyze_diagram=ToolConfig(model=None),
        )
        assert config.describe_image.model == "llava:latest"
        assert config.extract_ui.model == "gpt-4o"
        assert config.ocr.model == "moondream"
        assert config.analyze_diagram.model is None


class TestProvidersConfig:
    def test_builtin_providers(self):
        config = ProvidersConfig()
        assert isinstance(config.ollama, OllamaConfig)
        assert isinstance(config.openai, OpenAIConfig)
        assert isinstance(config.anthropic, AnthropicConfig)
        assert isinstance(config.zhipuai, ZhipuAIConfig)
        assert isinstance(config.ollama_cloud, OllamaCloudConfig)

    def test_custom_providers_dict(self):
        config = ProvidersConfig(
            custom_providers={
                "my_provider": CustomProviderConfig(
                    api_style="openai_compatible",
                    base_url="http://localhost:8000",
                )
            }
        )
        assert "my_provider" in config.custom_providers
        assert config.custom_providers["my_provider"].api_style == "openai_compatible"

    def test_extra_fields_merged_into_custom_providers(self):
        config = ProvidersConfig(
            custom_providers={},
            my_provider={
                "api_style": "openai_compatible",
                "base_url": "http://localhost:8000",
            },
        )
        assert "my_provider" in config.custom_providers
        provider = config.custom_providers["my_provider"]
        assert provider.api_style == "openai_compatible"
        assert provider.base_url == "http://localhost:8000"


class TestAppConfig:
    def test_default_values(self):
        config = AppConfig()
        assert config.provider == "ollama"
        assert config.model == "llava:latest"
        assert isinstance(config.providers, ProvidersConfig)
        assert isinstance(config.tools, ToolsConfig)

    def test_get_ollama_provider_config(self):
        config = AppConfig(provider="ollama")
        provider_cfg = config.get_provider_config()
        assert isinstance(provider_cfg, OllamaConfig)

    def test_get_openai_provider_config(self):
        config = AppConfig(provider="openai")
        provider_cfg = config.get_provider_config()
        assert isinstance(provider_cfg, OpenAIConfig)

    def test_get_anthropic_provider_config(self):
        config = AppConfig(provider="anthropic")
        provider_cfg = config.get_provider_config()
        assert isinstance(provider_cfg, AnthropicConfig)

    def test_get_zhipuai_provider_config(self):
        config = AppConfig(provider="zhipuai")
        provider_cfg = config.get_provider_config()
        assert isinstance(provider_cfg, ZhipuAIConfig)

    def test_get_ollama_cloud_provider_config(self):
        config = AppConfig(provider="ollama_cloud")
        provider_cfg = config.get_provider_config()
        assert isinstance(provider_cfg, OllamaCloudConfig)

    def test_get_custom_provider_config(self):
        config = AppConfig(
            provider="my_custom",
            providers=ProvidersConfig(
                custom_providers={
                    "my_custom": CustomProviderConfig(
                        api_style="openai_compatible",
                        base_url="http://localhost:8000",
                    )
                }
            ),
        )
        provider_cfg = config.get_provider_config()
        assert isinstance(provider_cfg, CustomProviderConfig)
        assert provider_cfg.api_style == "openai_compatible"

    def test_get_provider_config_fallback_to_ollama(self):
        config = AppConfig(provider="unknown_provider")
        provider_cfg = config.get_provider_config()
        assert isinstance(provider_cfg, OllamaConfig)


class TestLoadConfig:
    def test_load_default_config(self, tmp_path):
        config_path = tmp_path / "nonexistent.yaml"
        config = load_config(str(config_path))
        assert isinstance(config, AppConfig)
        assert config.provider == "ollama"

    def test_load_from_yaml_file(self, tmp_path):
        config_path = tmp_path / "config.yaml"
        config_path.write_text("""
provider: openai
model: gpt-4o
providers:
  openai:
    api_key: sk-test
""")
        config = load_config(str(config_path))
        assert config.provider == "openai"
        assert config.model == "gpt-4o"
        assert config.providers.openai.api_key == "sk-test"

    def test_load_custom_provider_from_yaml(self, tmp_path):
        config_path = tmp_path / "config.yaml"
        config_path.write_text("""
provider: my_provider
providers:
  custom_providers:
    my_provider:
      api_style: openai_compatible
      base_url: http://localhost:8000
      api_key: test-key
""")
        config = load_config(str(config_path))
        assert config.provider == "my_provider"
        assert "my_provider" in config.providers.custom_providers

    def test_load_ollama_cloud_from_yaml(self, tmp_path):
        config_path = tmp_path / "config.yaml"
        config_path.write_text("""
provider: ollama_cloud
model: llava:latest
providers:
  ollama_cloud:
    api_key: oc_test
""")
        config = load_config(str(config_path))
        assert config.provider == "ollama_cloud"
        assert config.providers.ollama_cloud.api_key == "oc_test"

    def test_load_with_per_tool_models(self, tmp_path):
        config_path = tmp_path / "config.yaml"
        config_path.write_text("""
tools:
  describe_image:
    enabled: true
    model: llava:latest
  extract_ui:
    enabled: true
    model: gpt-4o
""")
        config = load_config(str(config_path))
        assert config.tools.describe_image.model == "llava:latest"
        assert config.tools.extract_ui.model == "gpt-4o"

    def test_custom_provider_collision_raises_error(self, tmp_path):
        config_path = tmp_path / "config.yaml"
        config_path.write_text("""
provider: ollama
providers:
  custom_providers:
    ollama:
      api_style: openai_compatible
      base_url: http://custom:8000
""")
        with pytest.raises(ConfigError) as exc_info:
            load_config(str(config_path))
        assert "collides with a built-in provider name" in str(exc_info.value)

    def test_empty_yaml_returns_defaults(self, tmp_path):
        config_path = tmp_path / "config.yaml"
        config_path.write_text("")
        config = load_config(str(config_path))
        assert isinstance(config, AppConfig)
        assert config.provider == "ollama"

    def test_backward_compatible_simple_provider_config(self, tmp_path):
        config_path = tmp_path / "config.yaml"
        config_path.write_text("""
provider: openai
model: gpt-4o
""")
        config = load_config(str(config_path))
        assert config.provider == "openai"
        assert config.model == "gpt-4o"
        assert config.providers.openai.api_key == ""
