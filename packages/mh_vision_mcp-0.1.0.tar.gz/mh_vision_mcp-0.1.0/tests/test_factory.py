"""Tests for get_provider() factory."""

from __future__ import annotations

import pytest

from vision_mcp.config import (
    AppConfig,
    CustomProviderConfig,
    OllamaCloudConfig,
    ProvidersConfig,
)
from vision_mcp.providers import get_provider
from vision_mcp.providers.anthropic import AnthropicProvider
from vision_mcp.providers.custom import CustomProvider
from vision_mcp.providers.ollama import OllamaProvider
from vision_mcp.providers.ollama_cloud import OllamaCloudProvider
from vision_mcp.providers.openai import OpenAIProvider
from vision_mcp.providers.zhipuai import ZhipuAIProvider


class TestGetProviderBuiltin:
    def test_returns_ollama_provider(self):
        config = AppConfig(provider="ollama", model="llava:latest")
        provider = get_provider(config)
        assert isinstance(provider, OllamaProvider)
        assert provider.name == "ollama/llava:latest"

    def test_returns_openai_provider(self):
        config = AppConfig(
            provider="openai",
            model="gpt-4o",
            providers=ProvidersConfig(
                openai={"api_key": "sk-test"}  # type: ignore
            ),
        )
        provider = get_provider(config)
        assert isinstance(provider, OpenAIProvider)

    def test_returns_anthropic_provider(self):
        config = AppConfig(
            provider="anthropic",
            model="claude-opus-4-6",
            providers=ProvidersConfig(
                anthropic={"api_key": "sk-ant-test"}  # type: ignore
            ),
        )
        provider = get_provider(config)
        assert isinstance(provider, AnthropicProvider)

    def test_returns_zhipuai_provider(self):
        config = AppConfig(
            provider="zhipuai",
            model="glm-4v",
            providers=ProvidersConfig(
                zhipuai={"api_key": "test-key"}  # type: ignore
            ),
        )
        provider = get_provider(config)
        assert isinstance(provider, ZhipuAIProvider)


class TestGetProviderOllamaCloud:
    def test_returns_ollama_cloud_provider(self):
        config = AppConfig(
            provider="ollama_cloud",
            model="llava:latest",
            providers=ProvidersConfig(
                ollama_cloud=OllamaCloudConfig(api_key="oc_test")
            ),
        )
        provider = get_provider(config)
        assert isinstance(provider, OllamaCloudProvider)
        assert provider.name == "ollama_cloud/llava:latest"

    def test_raises_error_without_api_key(self):
        config = AppConfig(
            provider="ollama_cloud",
            model="llava:latest",
            providers=ProvidersConfig(ollama_cloud=OllamaCloudConfig(api_key="")),
        )
        from vision_mcp.errors import ConfigError

        with pytest.raises(ConfigError):
            get_provider(config)


class TestGetProviderCustom:
    def test_returns_custom_openai_compatible_provider(self):
        config = AppConfig(
            provider="custom_providers.my_vllm",
            model="vision-model",
            providers=ProvidersConfig(
                custom_providers={
                    "custom_providers.my_vllm": CustomProviderConfig(
                        api_style="openai_compatible",
                        base_url="http://localhost:8000/v1",
                        api_key="test-key",
                    )
                }
            ),
        )
        provider = get_provider(config)
        assert isinstance(provider, CustomProvider)

    def test_returns_custom_ollama_provider(self):
        config = AppConfig(
            provider="custom_providers.my_ollama",
            model="llava:latest",
            providers=ProvidersConfig(
                custom_providers={
                    "custom_providers.my_ollama": CustomProviderConfig(
                        api_style="ollama",
                        base_url="http://localhost:11434",
                    )
                }
            ),
        )
        provider = get_provider(config)
        assert isinstance(provider, CustomProvider)

    def test_custom_provider_name_format(self):
        config = AppConfig(
            provider="my_custom",
            model="vision-model",
            providers=ProvidersConfig(
                custom_providers={
                    "my_custom": CustomProviderConfig(
                        api_style="openai_compatible",
                        base_url="http://localhost:8000/v1",
                    )
                }
            ),
        )
        provider = get_provider(config)
        assert isinstance(provider, CustomProvider)
        assert provider.name == "custom/vision-model"


class TestGetProviderCaseInsensitive:
    def test_provider_name_lowercase(self):
        from vision_mcp.config import OpenAIConfig

        config = AppConfig(
            provider="openai",
            model="gpt-4o",
            providers=ProvidersConfig(openai=OpenAIConfig(api_key="sk-test")),
        )
        provider = get_provider(config)
        assert isinstance(provider, OpenAIProvider)

    def test_ollama_cloud_lowercase(self):
        config = AppConfig(
            provider="ollama_cloud",
            model="llava:latest",
            providers=ProvidersConfig(
                ollama_cloud=OllamaCloudConfig(api_key="oc_test")
            ),
        )
        provider = get_provider(config)
        assert isinstance(provider, OllamaCloudProvider)


class TestGetProviderError:
    def test_raises_error_for_unknown_provider(self):
        config = AppConfig(provider="unknown_provider", model="model")
        with pytest.raises(ValueError) as exc_info:
            get_provider(config)
        assert "Unknown provider" in str(exc_info.value)
        assert "unknown_provider" in str(exc_info.value)

    def test_error_message_includes_supported_providers(self):
        config = AppConfig(provider="unknown", model="model")
        with pytest.raises(ValueError) as exc_info:
            get_provider(config)
        error_msg = str(exc_info.value)
        assert "ollama" in error_msg
        assert "openai" in error_msg
        assert "anthropic" in error_msg
        assert "zhipuai" in error_msg
        assert "ollama_cloud" in error_msg


class TestGetProviderWithPerToolModel:
    def test_provider_inherits_global_model(self):
        config = AppConfig(
            provider="ollama",
            model="llava:latest",
        )
        provider = get_provider(config)
        assert provider._model == "llava:latest"

    def test_tool_model_not_affecting_provider_model(self):
        from vision_mcp.config import ToolConfig, ToolsConfig

        config = AppConfig(
            provider="ollama",
            model="llava:latest",
            tools=ToolsConfig(
                describe_image=ToolConfig(model="gpt-4o"),
            ),
        )
        provider = get_provider(config)
        assert provider._model == "llava:latest"
