import pytest

from vision_mcp.config import OllamaCloudConfig
from vision_mcp.errors import ConfigError, ProviderError
from vision_mcp.providers.ollama_cloud import OllamaCloudProvider
from unittest.mock import patch


class TestOllamaCloudProviderInit:
    def test_init_with_valid_api_key(self):
        cfg = OllamaCloudConfig(
            api_key="oc_test_key", base_url="https://api.ollama.com/v1"
        )
        provider = OllamaCloudProvider(cfg, model="llava:latest")
        assert provider._api_key == "oc_test_key"
        assert provider._base_url == "https://api.ollama.com/v1"
        assert provider._model == "llava:latest"

    def test_init_without_api_key_raises_config_error(self):
        cfg = OllamaCloudConfig(api_key="", base_url="https://api.ollama.com/v1")
        with pytest.raises(ConfigError) as exc_info:
            OllamaCloudProvider(cfg, model="llava:latest")
        assert "API key is required" in str(exc_info.value)

    def test_name_property(self):
        cfg = OllamaCloudConfig(api_key="oc_test", base_url="https://api.ollama.com/v1")
        provider = OllamaCloudProvider(cfg, model="llava:latest")
        assert provider.name == "ollama_cloud/llava:latest"

    def test_base_url_trailing_slash_stripped(self):
        cfg = OllamaCloudConfig(
            api_key="oc_test", base_url="https://api.ollama.com/v1/"
        )
        provider = OllamaCloudProvider(cfg, model="llava:latest")
        assert provider._base_url == "https://api.ollama.com/v1"


@pytest.mark.asyncio
class TestOllamaCloudProviderQuery:
    async def test_query_success(self, sample_image_payload):
        class FakeResponse:
            status_code = 200

            def json(self):
                return {"choices": [{"message": {"content": "Test response"}}]}

            def raise_for_status(self):
                pass

        class FakeClient:
            async def post(self, *args, **kwargs):
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = OllamaCloudConfig(
                api_key="oc_test", base_url="https://api.ollama.com/v1"
            )
            provider = OllamaCloudProvider(cfg, model="llava:latest")
            result = await provider.query(sample_image_payload, "Describe this image")
            assert result == "Test response"

    async def test_query_with_model_override(self, sample_image_payload):
        received_payload = {}

        class FakeResponse:
            status_code = 200

            def json(self):
                return {"choices": [{"message": {"content": "Test response"}}]}

            def raise_for_status(self):
                pass

        class FakeClient:
            async def post(self, url, headers=None, json=None):
                received_payload.update(json or {})
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = OllamaCloudConfig(
                api_key="oc_test", base_url="https://api.ollama.com/v1"
            )
            provider = OllamaCloudProvider(cfg, model="default-model")
            result = await provider.query(
                sample_image_payload, "Describe this image", model="override-model"
            )
            assert received_payload.get("model") == "override-model"
            assert result == "Test response"

    async def test_query_401_error(self, sample_image_payload):
        import httpx

        class FakeResponse:
            status_code = 401
            text = '{"error": "Unauthorized"}'

            def raise_for_status(self):
                raise httpx.HTTPStatusError("Unauthorized", request=None, response=self)

        class FakeClient:
            async def post(self, *args, **kwargs):
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = OllamaCloudConfig(
                api_key="oc_test", base_url="https://api.ollama.com/v1"
            )
            provider = OllamaCloudProvider(cfg, model="llava:latest")
            with pytest.raises(ProviderError) as exc_info:
                await provider.query(sample_image_payload, "Describe this image")
            assert "API key is invalid or missing" in str(exc_info.value)

    async def test_query_429_error(self, sample_image_payload):
        import httpx

        class FakeResponse:
            status_code = 429
            text = '{"error": "Rate limit exceeded"}'

            def raise_for_status(self):
                raise httpx.HTTPStatusError("Rate Limited", request=None, response=self)

        class FakeClient:
            async def post(self, *args, **kwargs):
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = OllamaCloudConfig(
                api_key="oc_test", base_url="https://api.ollama.com/v1"
            )
            provider = OllamaCloudProvider(cfg, model="llava:latest")
            with pytest.raises(ProviderError) as exc_info:
                await provider.query(sample_image_payload, "Describe this image")
            assert "rate limit" in str(exc_info.value).lower()

    async def test_query_500_error(self, sample_image_payload):
        import httpx

        class FakeResponse:
            status_code = 500
            text = '{"error": "Internal Server Error"}'

            def raise_for_status(self):
                raise httpx.HTTPStatusError("Server Error", request=None, response=self)

        class FakeClient:
            async def post(self, *args, **kwargs):
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = OllamaCloudConfig(
                api_key="oc_test", base_url="https://api.ollama.com/v1"
            )
            provider = OllamaCloudProvider(cfg, model="llava:latest")
            with pytest.raises(ProviderError) as exc_info:
                await provider.query(sample_image_payload, "Describe this image")
            assert "API error 500" in str(exc_info.value)

    async def test_query_unexpected_response_shape(self, sample_image_payload):
        class FakeResponse:
            status_code = 200

            def json(self):
                return {"unexpected": "structure"}

            def raise_for_status(self):
                pass

        class FakeClient:
            async def post(self, *args, **kwargs):
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = OllamaCloudConfig(
                api_key="oc_test", base_url="https://api.ollama.com/v1"
            )
            provider = OllamaCloudProvider(cfg, model="llava:latest")
            with pytest.raises(ProviderError) as exc_info:
                await provider.query(sample_image_payload, "Describe this image")
            assert "unexpected response shape" in str(exc_info.value)

    async def test_query_uses_correct_endpoint(self, sample_image_payload):
        received_url = None

        class FakeResponse:
            status_code = 200

            def json(self):
                return {"choices": [{"message": {"content": "Test response"}}]}

            def raise_for_status(self):
                pass

        class FakeClient:
            async def post(self, url, **kwargs):
                nonlocal received_url
                received_url = url
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = OllamaCloudConfig(
                api_key="oc_test", base_url="https://api.ollama.com/v1"
            )
            provider = OllamaCloudProvider(cfg, model="llava:latest")
            result = await provider.query(sample_image_payload, "Describe this image")
            assert received_url == "https://api.ollama.com/v1/chat/completions"

    async def test_query_includes_correct_headers(self, sample_image_payload):
        received_headers = {}

        class FakeResponse:
            status_code = 200

            def json(self):
                return {"choices": [{"message": {"content": "Test response"}}]}

            def raise_for_status(self):
                pass

        class FakeClient:
            async def post(self, url, headers=None, json=None):
                received_headers.update(headers or {})
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = OllamaCloudConfig(
                api_key="oc_test", base_url="https://api.ollama.com/v1"
            )
            provider = OllamaCloudProvider(cfg, model="llava:latest")
            result = await provider.query(sample_image_payload, "Describe this image")
            assert received_headers["Authorization"] == "Bearer oc_test"
            assert received_headers["Content-Type"] == "application/json"

    async def test_query_includes_correct_payload(self, sample_image_payload):
        received_payload = {}

        class FakeResponse:
            status_code = 200

            def json(self):
                return {"choices": [{"message": {"content": "Test response"}}]}

            def raise_for_status(self):
                pass

        class FakeClient:
            async def post(self, url, headers=None, json=None):
                received_payload.update(json or {})
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = OllamaCloudConfig(
                api_key="oc_test", base_url="https://api.ollama.com/v1"
            )
            provider = OllamaCloudProvider(cfg, model="llava:latest")
            result = await provider.query(sample_image_payload, "Describe this image")
            assert received_payload["model"] == "llava:latest"
            assert received_payload["max_tokens"] == 4096
            assert len(received_payload["messages"]) == 1
            assert received_payload["messages"][0]["role"] == "user"
            assert len(received_payload["messages"][0]["content"]) == 2

    async def test_query_uses_image_payload_mime_type(self, sample_image_payload):
        received_payload = {}

        class FakeResponse:
            status_code = 200

            def json(self):
                return {"choices": [{"message": {"content": "Test response"}}]}

            def raise_for_status(self):
                pass

        class FakeClient:
            async def post(self, url, headers=None, json=None):
                received_payload.update(json or {})
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = OllamaCloudConfig(
                api_key="oc_test", base_url="https://api.ollama.com/v1"
            )
            provider = OllamaCloudProvider(cfg, model="llava:latest")
            result = await provider.query(sample_image_payload, "Describe this image")
            image_url = received_payload["messages"][0]["content"][0]["image_url"][
                "url"
            ]
            assert image_url.startswith("data:image/png")
