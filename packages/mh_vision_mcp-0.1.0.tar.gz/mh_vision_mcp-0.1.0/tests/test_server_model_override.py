"""Tests for server.py per-tool model override integration.

Verifies that each of the 4 MCP tools passes the correct model kwarg
to provider.query() based on the tool's config, and that when model
is None (default), no model kwarg is passed.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from vision_mcp.config import (
    AppConfig,
    OllamaConfig,
    ProvidersConfig,
    ToolConfig,
    ToolsConfig,
)
from vision_mcp.image import ImagePayload
from vision_mcp.providers.ollama import OllamaProvider

MOCK_IMAGE = ImagePayload(
    data="iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==",
    mime_type="image/png",
)


def _config(
    describe_model: str | None = "llava:latest",
    extract_model: str | None = "gpt-4o",
    ocr_model: str | None = "moondream",
    diagram_model: str | None = None,
) -> AppConfig:
    return AppConfig(
        provider="ollama",
        model="llava:latest",
        providers=ProvidersConfig(ollama=OllamaConfig()),
        tools=ToolsConfig(
            describe_image=ToolConfig(enabled=True, model=describe_model),
            extract_ui=ToolConfig(enabled=True, model=extract_model),
            ocr=ToolConfig(enabled=True, model=ocr_model),
            analyze_diagram=ToolConfig(enabled=True, model=diagram_model),
        ),
    )


def _provider() -> MagicMock:
    p = MagicMock(spec=OllamaProvider)
    p.name = "ollama/llava:latest"
    p.query = AsyncMock(return_value="result")
    return p


class TestDescribeImageModelOverride:
    """describe_image passes its configured model to provider.query()."""

    @pytest.mark.asyncio
    async def test_model_override_passed(self):
        cfg = _config(describe_model="gpt-4o")
        provider = _provider()

        with (
            patch("vision_mcp.server.provider", provider),
            patch("vision_mcp.server.config", cfg),
            patch("vision_mcp.server.tools_cfg", cfg.tools),
            patch("vision_mcp.server.load_image", return_value=MOCK_IMAGE),
        ):
            from vision_mcp.server import describe_image

            await describe_image("data:image/png;base64,abc")
            assert provider.query.call_args.kwargs["model"] == "gpt-4o"

    @pytest.mark.asyncio
    async def test_no_model_when_none(self):
        cfg = _config(describe_model=None)
        provider = _provider()

        with (
            patch("vision_mcp.server.provider", provider),
            patch("vision_mcp.server.config", cfg),
            patch("vision_mcp.server.tools_cfg", cfg.tools),
            patch("vision_mcp.server.load_image", return_value=MOCK_IMAGE),
        ):
            from vision_mcp.server import describe_image

            await describe_image("data:image/png;base64,abc")
            assert "model" not in provider.query.call_args.kwargs


class TestExtractUIModelOverride:
    """extract_ui passes its configured model to provider.query()."""

    @pytest.mark.asyncio
    async def test_model_override_passed(self):
        cfg = _config(extract_model="gpt-4o-mini")
        provider = _provider()

        with (
            patch("vision_mcp.server.provider", provider),
            patch("vision_mcp.server.config", cfg),
            patch("vision_mcp.server.tools_cfg", cfg.tools),
            patch("vision_mcp.server.load_image", return_value=MOCK_IMAGE),
        ):
            from vision_mcp.server import extract_ui

            await extract_ui("data:image/png;base64,abc")
            assert provider.query.call_args.kwargs["model"] == "gpt-4o-mini"

    @pytest.mark.asyncio
    async def test_no_model_when_none(self):
        cfg = _config(extract_model=None)
        provider = _provider()

        with (
            patch("vision_mcp.server.provider", provider),
            patch("vision_mcp.server.config", cfg),
            patch("vision_mcp.server.tools_cfg", cfg.tools),
            patch("vision_mcp.server.load_image", return_value=MOCK_IMAGE),
        ):
            from vision_mcp.server import extract_ui

            await extract_ui("data:image/png;base64,abc")
            assert "model" not in provider.query.call_args.kwargs


class TestOCRModelOverride:
    """ocr passes its configured model to provider.query()."""

    @pytest.mark.asyncio
    async def test_model_override_passed(self):
        cfg = _config(ocr_model="moondream")
        provider = _provider()

        with (
            patch("vision_mcp.server.provider", provider),
            patch("vision_mcp.server.config", cfg),
            patch("vision_mcp.server.tools_cfg", cfg.tools),
            patch("vision_mcp.server.load_image", return_value=MOCK_IMAGE),
        ):
            from vision_mcp.server import ocr

            await ocr("data:image/png;base64,abc")
            assert provider.query.call_args.kwargs["model"] == "moondream"

    @pytest.mark.asyncio
    async def test_no_model_when_none(self):
        cfg = _config(ocr_model=None)
        provider = _provider()

        with (
            patch("vision_mcp.server.provider", provider),
            patch("vision_mcp.server.config", cfg),
            patch("vision_mcp.server.tools_cfg", cfg.tools),
            patch("vision_mcp.server.load_image", return_value=MOCK_IMAGE),
        ):
            from vision_mcp.server import ocr

            await ocr("data:image/png;base64,abc")
            assert "model" not in provider.query.call_args.kwargs


class TestAnalyzeDiagramModelOverride:
    """analyze_diagram passes its configured model to provider.query()."""

    @pytest.mark.asyncio
    async def test_model_override_passed(self):
        cfg = _config(diagram_model="gpt-4o")
        provider = _provider()

        with (
            patch("vision_mcp.server.provider", provider),
            patch("vision_mcp.server.config", cfg),
            patch("vision_mcp.server.tools_cfg", cfg.tools),
            patch("vision_mcp.server.load_image", return_value=MOCK_IMAGE),
        ):
            from vision_mcp.server import analyze_diagram

            await analyze_diagram("data:image/png;base64,abc")
            assert provider.query.call_args.kwargs["model"] == "gpt-4o"

    @pytest.mark.asyncio
    async def test_no_model_when_none(self):
        cfg = _config(diagram_model=None)
        provider = _provider()

        with (
            patch("vision_mcp.server.provider", provider),
            patch("vision_mcp.server.config", cfg),
            patch("vision_mcp.server.tools_cfg", cfg.tools),
            patch("vision_mcp.server.load_image", return_value=MOCK_IMAGE),
        ):
            from vision_mcp.server import analyze_diagram

            await analyze_diagram("data:image/png;base64,abc")
            assert "model" not in provider.query.call_args.kwargs


class TestMixedModelOverrides:
    """Different tools can have different model overrides."""

    @pytest.mark.asyncio
    async def test_different_tools_different_models(self):
        cfg = _config(
            describe_model="gpt-4o",
            extract_model="gpt-4o-mini",
            ocr_model="moondream",
            diagram_model=None,
        )
        provider = _provider()

        with (
            patch("vision_mcp.server.provider", provider),
            patch("vision_mcp.server.config", cfg),
            patch("vision_mcp.server.tools_cfg", cfg.tools),
            patch("vision_mcp.server.load_image", return_value=MOCK_IMAGE),
        ):
            from vision_mcp.server import (
                analyze_diagram,
                describe_image,
                extract_ui,
                ocr,
            )

            await describe_image("data:image/png;base64,abc")
            assert provider.query.call_args.kwargs["model"] == "gpt-4o"

            provider.query.reset_mock()
            await extract_ui("data:image/png;base64,abc")
            assert provider.query.call_args.kwargs["model"] == "gpt-4o-mini"

            provider.query.reset_mock()
            await ocr("data:image/png;base64,abc")
            assert provider.query.call_args.kwargs["model"] == "moondream"

            provider.query.reset_mock()
            await analyze_diagram("data:image/png;base64,abc")
            assert "model" not in provider.query.call_args.kwargs


class TestProviderReceivesCorrectArguments:
    """Verify the full call signature: image, prompt, and optional model."""

    @pytest.mark.asyncio
    async def test_query_called_with_image_prompt_and_model(self):
        cfg = _config(describe_model="gpt-4o")
        provider = _provider()

        with (
            patch("vision_mcp.server.provider", provider),
            patch("vision_mcp.server.config", cfg),
            patch("vision_mcp.server.tools_cfg", cfg.tools),
            patch("vision_mcp.server.load_image", return_value=MOCK_IMAGE),
        ):
            from vision_mcp.server import describe_image

            await describe_image("data:image/png;base64,abc")

            args = provider.query.call_args.args
            assert len(args) == 2
            assert isinstance(args[0], ImagePayload)
            assert isinstance(args[1], str)
            assert provider.query.call_args.kwargs["model"] == "gpt-4o"
