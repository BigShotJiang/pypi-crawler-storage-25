import pytest
from unittest.mock import MagicMock, patch

from vision_mcp.config import CustomProviderConfig
from vision_mcp.errors import ProviderError
from vision_mcp.providers.custom import CustomProvider


class TestCustomProviderName:
    def test_name_property_openai_compatible(self):
        cfg = CustomProviderConfig(
            api_style="openai_compatible",
            base_url="http://localhost:8000/v1",
        )
        provider = CustomProvider(cfg, model="vision-model")
        assert provider.name == "custom/vision-model"

    def test_name_property_ollama(self):
        cfg = CustomProviderConfig(
            api_style="ollama",
            base_url="http://localhost:11434",
        )
        provider = CustomProvider(cfg, model="llava:latest")
        assert provider.name == "custom/llava:latest"


class TestCustomProviderInit:
    def test_init_stores_config(self):
        cfg = CustomProviderConfig(
            api_style="openai_compatible",
            base_url="http://localhost:8000/v1",
            api_key="test-key",
            model="default-model",
        )
        provider = CustomProvider(cfg, model="override-model")
        assert provider._cfg == cfg
        assert provider._model == "override-model"

    def test_init_defaults(self):
        cfg = CustomProviderConfig(
            api_style="openai_compatible",
            base_url="http://localhost:8000/v1",
        )
        provider = CustomProvider(cfg, model="vision-model")
        assert provider._cfg.api_key == ""
        assert provider._cfg.model == ""


class TestCustomProviderConfig:
    def test_custom_openai_config(self):
        cfg = CustomProviderConfig(
            api_style="openai_compatible",
            base_url="http://localhost:8000/v1",
            api_key="my-key",
            model="my-model",
        )
        assert cfg.api_style == "openai_compatible"
        assert cfg.base_url == "http://localhost:8000/v1"
        assert cfg.api_key == "my-key"
        assert cfg.model == "my-model"

    def test_custom_ollama_config(self):
        cfg = CustomProviderConfig(
            api_style="ollama",
            base_url="http://localhost:11434",
        )
        assert cfg.api_style == "ollama"
        assert cfg.base_url == "http://localhost:11434"

    def test_custom_config_without_optional_fields(self):
        cfg = CustomProviderConfig(
            api_style="openai_compatible",
            base_url="http://api.example.com",
        )
        assert cfg.api_key == ""
        assert cfg.model == ""


@pytest.mark.asyncio
class TestCustomProviderAsync:
    async def test_openai_compatible_success(self, sample_image_payload):
        class FakeResponse:
            status_code = 200

            def json(self):
                return {"choices": [{"message": {"content": "Success"}}]}

            def raise_for_status(self):
                pass

        class FakeClient:
            async def post(self, *args, **kwargs):
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = CustomProviderConfig(
                api_style="openai_compatible",
                base_url="http://localhost:8000/v1",
            )
            provider = CustomProvider(cfg, model="vision-model")
            result = await provider.query(sample_image_payload, "Describe")
            assert result == "Success"

    async def test_openai_compatible_with_api_key(self, sample_image_payload):
        received_headers = {}

        class FakeResponse:
            status_code = 200

            def json(self):
                return {"choices": [{"message": {"content": "Success"}}]}

            def raise_for_status(self):
                pass

        class FakeClient:
            async def post(self, url, headers=None, json=None):
                received_headers.update(headers or {})
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = CustomProviderConfig(
                api_style="openai_compatible",
                base_url="http://localhost:8000/v1",
                api_key="my-secret-key",
            )
            provider = CustomProvider(cfg, model="vision-model")
            result = await provider.query(sample_image_payload, "Describe")
            assert received_headers.get("Authorization") == "Bearer my-secret-key"

    async def test_openai_compatible_model_override(self, sample_image_payload):
        received_payload = {}

        class FakeResponse:
            status_code = 200

            def json(self):
                return {"choices": [{"message": {"content": "Success"}}]}

            def raise_for_status(self):
                pass

        class FakeClient:
            async def post(self, url, headers=None, json=None):
                received_payload.update(json or {})
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = CustomProviderConfig(
                api_style="openai_compatible",
                base_url="http://localhost:8000/v1",
            )
            provider = CustomProvider(cfg, model="default-model")
            result = await provider.query(
                sample_image_payload, "Describe", model="override-model"
            )
            assert received_payload.get("model") == "override-model"

    async def test_ollama_style_success(self, sample_image_payload):
        class FakeResponse:
            status_code = 200

            def json(self):
                return {"response": "Ollama result"}

            def raise_for_status(self):
                pass

        class FakeClient:
            async def post(self, *args, **kwargs):
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = CustomProviderConfig(
                api_style="ollama",
                base_url="http://localhost:11434",
            )
            provider = CustomProvider(cfg, model="llava:latest")
            result = await provider.query(sample_image_payload, "Describe")
            assert result == "Ollama result"

    async def test_ollama_style_model_override(self, sample_image_payload):
        received_payload = {}

        class FakeResponse:
            status_code = 200

            def json(self):
                return {"response": "Ollama result"}

            def raise_for_status(self):
                pass

        class FakeClient:
            async def post(self, url, json=None, **kwargs):
                received_payload.update(json or {})
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = CustomProviderConfig(
                api_style="ollama",
                base_url="http://localhost:11434",
            )
            provider = CustomProvider(cfg, model="default-model")
            result = await provider.query(
                sample_image_payload, "Describe", model="override-model"
            )
            assert received_payload.get("model") == "override-model"

    async def test_ollama_connection_error(self, sample_image_payload):
        import httpx

        class FakeClient:
            async def post(self, *args, **kwargs):
                raise httpx.ConnectError("Connection refused")

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = CustomProviderConfig(
                api_style="ollama",
                base_url="http://localhost:11434",
            )
            provider = CustomProvider(cfg, model="llava:latest")
            with pytest.raises(ProviderError) as exc_info:
                await provider.query(sample_image_payload, "Describe")
            assert "Cannot connect to custom Ollama-style provider" in str(
                exc_info.value
            )

    async def test_openai_compatible_401_error(self, sample_image_payload):
        import httpx

        class FakeResponse:
            status_code = 401
            text = '{"error": "Unauthorized"}'

            def raise_for_status(self):
                raise httpx.HTTPStatusError("Unauthorized", request=None, response=self)

        class FakeClient:
            async def post(self, *args, **kwargs):
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = CustomProviderConfig(
                api_style="openai_compatible",
                base_url="http://localhost:8000/v1",
            )
            provider = CustomProvider(cfg, model="vision-model")
            with pytest.raises(ProviderError) as exc_info:
                await provider.query(sample_image_payload, "Describe")
            assert "API key is invalid or missing" in str(exc_info.value)

    async def test_openai_compatible_500_error(self, sample_image_payload):
        import httpx

        class FakeResponse:
            status_code = 500
            text = '{"error": "Server Error"}'

            def raise_for_status(self):
                raise httpx.HTTPStatusError("Server Error", request=None, response=self)

        class FakeClient:
            async def post(self, *args, **kwargs):
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = CustomProviderConfig(
                api_style="openai_compatible",
                base_url="http://localhost:8000/v1",
            )
            provider = CustomProvider(cfg, model="vision-model")
            with pytest.raises(ProviderError) as exc_info:
                await provider.query(sample_image_payload, "Describe")
            assert "API error 500" in str(exc_info.value)

    async def test_ollama_404_error(self, sample_image_payload):
        import httpx

        class FakeResponse:
            status_code = 404
            text = "Not Found"

            def raise_for_status(self):
                raise httpx.HTTPStatusError("Not Found", request=None, response=self)

        class FakeClient:
            async def post(self, *args, **kwargs):
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = CustomProviderConfig(
                api_style="ollama",
                base_url="http://localhost:11434",
            )
            provider = CustomProvider(cfg, model="llava:latest")
            with pytest.raises(ProviderError) as exc_info:
                await provider.query(sample_image_payload, "Describe")
            assert "API error 404" in str(exc_info.value)

    async def test_openai_unexpected_response_shape(self, sample_image_payload):
        class FakeResponse:
            status_code = 200

            def json(self):
                return {"unexpected": "shape"}

            def raise_for_status(self):
                pass

        class FakeClient:
            async def post(self, *args, **kwargs):
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = CustomProviderConfig(
                api_style="openai_compatible",
                base_url="http://localhost:8000/v1",
            )
            provider = CustomProvider(cfg, model="vision-model")
            with pytest.raises(ProviderError) as exc_info:
                await provider.query(sample_image_payload, "Describe")
            assert "unexpected response shape" in str(exc_info.value)

    async def test_ollama_unexpected_response_shape(self, sample_image_payload):
        class FakeResponse:
            status_code = 200

            def json(self):
                return {"unexpected": "shape"}

            def raise_for_status(self):
                pass

        class FakeClient:
            async def post(self, *args, **kwargs):
                return FakeResponse()

            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                pass

        with patch("httpx.AsyncClient", return_value=FakeClient()):
            cfg = CustomProviderConfig(
                api_style="ollama",
                base_url="http://localhost:11434",
            )
            provider = CustomProvider(cfg, model="llava:latest")
            with pytest.raises(ProviderError) as exc_info:
                await provider.query(sample_image_payload, "Describe")
            assert "unexpected response shape" in str(exc_info.value)
