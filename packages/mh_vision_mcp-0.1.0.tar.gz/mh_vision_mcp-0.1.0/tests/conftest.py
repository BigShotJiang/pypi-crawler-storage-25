"""Shared fixtures for vision-mcp tests."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from vision_mcp.config import (
    AnthropicConfig,
    AppConfig,
    CustomProviderConfig,
    OllamaCloudConfig,
    OllamaConfig,
    OpenAIConfig,
    ProvidersConfig,
    ToolConfig,
    ToolsConfig,
    ZhipuAIConfig,
)
from vision_mcp.image import ImagePayload


# Image Payload Fixtures


@pytest.fixture
def sample_image_payload():
    return ImagePayload(
        data="iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==",
        mime_type="image/png",
    )


@pytest.fixture
def sample_image_data():
    return "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="


@pytest.fixture
def sample_mime_type():
    return "image/png"


# Mock HTTP Client Fixtures


@pytest.fixture
def mock_httpx_client():
    mock_client = MagicMock(spec=httpx.AsyncClient)
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)
    return mock_client


@pytest.fixture
def mock_http_response():
    mock_resp = MagicMock(spec=httpx.Response)
    mock_resp.status_code = 200
    mock_resp.text = '{"choices": [{"message": {"content": "Test response"}}]}'
    mock_resp.json.return_value = {
        "choices": [{"message": {"content": "Test response"}}]
    }
    return mock_resp


@pytest.fixture
def mock_ollama_response():
    mock_resp = MagicMock(spec=httpx.Response)
    mock_resp.status_code = 200
    mock_resp.text = '{"response": "Test Ollama response"}'
    mock_resp.json.return_value = {"response": "Test Ollama response"}
    return mock_resp


@pytest.fixture
def mock_async_client_factory(mock_http_response):
    def _create_mock(response=None):
        response = response or mock_http_response
        mock_client = MagicMock(spec=httpx.AsyncClient)
        mock_client.post = AsyncMock(return_value=response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)
        return mock_client

    return _create_mock


@pytest.fixture(autouse=True)
def patch_httpx_async_client(mock_http_response):
    mock_client = MagicMock(spec=httpx.AsyncClient)
    mock_client.post = AsyncMock(return_value=mock_http_response)
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)

    with patch("httpx.AsyncClient", return_value=mock_client):
        yield mock_client


# Config Fixtures


@pytest.fixture
def default_app_config():
    return AppConfig()


@pytest.fixture
def custom_openai_provider_config():
    return CustomProviderConfig(
        api_style="openai_compatible",
        base_url="http://localhost:8000/v1",
        api_key="test-api-key",
        model="vision-model",
    )


@pytest.fixture
def custom_ollama_provider_config():
    return CustomProviderConfig(
        api_style="ollama",
        base_url="http://localhost:11434",
        api_key="",
        model="llava:latest",
    )


@pytest.fixture
def ollama_cloud_config():
    return OllamaCloudConfig(
        api_key="oc_test_api_key",
        base_url="https://api.ollama.com/v1",
    )


@pytest.fixture
def ollama_config():
    return OllamaConfig(base_url="http://localhost:11434")


@pytest.fixture
def openai_config():
    return OpenAIConfig(
        api_key="sk-test",
        base_url="https://api.openai.com/v1",
    )


@pytest.fixture
def anthropic_config():
    return AnthropicConfig(api_key="sk-ant-test")


@pytest.fixture
def zhipuai_config():
    return ZhipuAIConfig(
        api_key="test-key",
        base_url="https://open.bigmodel.cn/api/paas/v4",
    )


@pytest.fixture
def providers_config():
    return ProvidersConfig(
        ollama=OllamaConfig(base_url="http://localhost:11434"),
        openai=OpenAIConfig(api_key="sk-test"),
        anthropic=AnthropicConfig(api_key="sk-ant-test"),
        zhipuai=ZhipuAIConfig(api_key="test-key"),
        ollama_cloud=OllamaCloudConfig(api_key="oc-test"),
        custom_providers={
            "my_openai": CustomProviderConfig(
                api_style="openai_compatible",
                base_url="http://localhost:8000/v1",
                api_key="test-key",
            ),
            "my_ollama": CustomProviderConfig(
                api_style="ollama",
                base_url="http://localhost:11434",
            ),
        },
    )


@pytest.fixture
def tools_config():
    return ToolsConfig(
        describe_image=ToolConfig(
            enabled=True,
            default_detail="high",
            output_format="json",
            model="llava:latest",
        ),
        extract_ui=ToolConfig(
            enabled=True,
            output_format="json",
            model="gpt-4o",
        ),
        ocr=ToolConfig(
            enabled=True,
            output_format="plain",
            model="moondream",
        ),
        analyze_diagram=ToolConfig(
            enabled=True,
            output_format="json",
            model=None,
        ),
    )


# Error Response Fixtures


@pytest.fixture
def unauthorized_response():
    mock_resp = MagicMock(spec=httpx.Response)
    mock_resp.status_code = 401
    mock_resp.text = '{"error": "Unauthorized"}'
    return mock_resp


@pytest.fixture
def rate_limited_response():
    mock_resp = MagicMock(spec=httpx.Response)
    mock_resp.status_code = 429
    mock_resp.text = '{"error": "Rate limit exceeded"}'
    return mock_resp


@pytest.fixture
def bad_request_response():
    mock_resp = MagicMock(spec=httpx.Response)
    mock_resp.status_code = 400
    mock_resp.text = '{"error": "Bad request"}'
    return mock_resp


@pytest.fixture
def malformed_json_response():
    mock_resp = MagicMock(spec=httpx.Response)
    mock_resp.status_code = 200
    mock_resp.text = "not json"
    mock_resp.json.side_effect = Exception("Invalid JSON")
    return mock_resp


@pytest.fixture
def unexpected_shape_response():
    mock_resp = MagicMock(spec=httpx.Response)
    mock_resp.status_code = 200
    mock_resp.text = '{"unexpected": "structure"}'
    mock_resp.json.return_value = {"unexpected": "structure"}
    return mock_resp


@pytest.fixture
def connect_error():
    return httpx.ConnectError("Connection refused")


# Async Test Configuration


@pytest.fixture(scope="session")
def event_loop():
    import asyncio

    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()
