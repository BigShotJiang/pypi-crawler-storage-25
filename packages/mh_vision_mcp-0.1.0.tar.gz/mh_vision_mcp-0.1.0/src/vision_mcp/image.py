"""Normalize any image source into base64 for the vision model."""
from __future__ import annotations
import base64
import re
from pathlib import Path
from typing import NamedTuple
import httpx
from .errors import ImageLoadError


SUPPORTED_MIME = {
    ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
    ".png": "image/png", ".gif": "image/gif",
    ".webp": "image/webp",
}


class ImagePayload(NamedTuple):
    data: str        # base64-encoded bytes
    mime_type: str   # e.g. "image/png"


def _mime_from_path(path: str) -> str:
    ext = Path(path).suffix.lower()
    return SUPPORTED_MIME.get(ext, "image/jpeg")


def _is_base64(s: str) -> bool:
    return s.startswith("data:") or bool(re.fullmatch(r"[A-Za-z0-9+/\n]+=*", s.strip()))


def load_image(source: str) -> ImagePayload:
    """
    Accept:
      - Local file path  (/home/user/img.png, ./img.png)
      - HTTP/S URL       (https://example.com/img.png)
      - Raw base64       (iVBORw0KGgo...)
      - Data URI         (data:image/png;base64,iVBOR...)
    Returns an ImagePayload with base64 data and mime type.
    """
    source = source.strip()

    # Data URI
    if source.startswith("data:"):
        match = re.match(r"data:(image/\w+);base64,(.+)", source, re.DOTALL)
        if not match:
            raise ImageLoadError(f"Invalid data URI: {source[:60]}")
        return ImagePayload(data=match.group(2).strip(), mime_type=match.group(1))

    # HTTP/S URL
    if source.startswith("http://") or source.startswith("https://"):
        response = httpx.get(source, follow_redirects=True, timeout=30)
        response.raise_for_status()
        content_type = response.headers.get("content-type", "image/jpeg").split(";")[0]
        data = base64.b64encode(response.content).decode()
        return ImagePayload(data=data, mime_type=content_type)

    # Local file path
    path = Path(source)
    if path.exists():
        raw = path.read_bytes()
        data = base64.b64encode(raw).decode()
        return ImagePayload(data=data, mime_type=_mime_from_path(source))

    # Raw base64 (last resort)
    if _is_base64(source):
        return ImagePayload(data=source.strip(), mime_type="image/jpeg")

    raise ImageLoadError(
        f"Cannot resolve image source: '{source[:80]}'. "
        "Expected a file path, URL, base64 string, or data URI."
    )
