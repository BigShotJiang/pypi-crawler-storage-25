"""MH Vision MCP — give any non-vision model the ability to see."""

__version__ = "0.1.0"
