from .base import BaseVisionProvider
from .ollama import OllamaProvider
from .openai import OpenAIProvider
from .anthropic import AnthropicProvider
from .zhipuai import ZhipuAIProvider
from .ollama_cloud import OllamaCloudProvider
from .custom import CustomProvider
from ..config import AppConfig


def get_provider(config: AppConfig) -> BaseVisionProvider:
    """Factory: return the right provider from config."""
    name = config.provider.lower()
    cfg = config.get_provider_config()
    model = config.model

    if name == "ollama":
        return OllamaProvider(cfg, model)
    elif name == "openai":
        return OpenAIProvider(cfg, model)
    elif name == "anthropic":
        return AnthropicProvider(cfg, model)
    elif name == "zhipuai":
        return ZhipuAIProvider(cfg, model)
    elif name == "ollama_cloud":
        return OllamaCloudProvider(cfg, model)
    elif name in config.providers.custom_providers:
        return CustomProvider(config.providers.custom_providers[name], model)
    else:
        raise ValueError(
            f"Unknown provider '{name}'. "
            "Supported: ollama, openai, anthropic, zhipuai, ollama_cloud. "
            "For custom providers, add them to config.providers.custom_providers."
        )
