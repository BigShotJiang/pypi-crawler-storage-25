from __future__ import annotations
import httpx
from ..config import OllamaCloudConfig
from ..image import ImagePayload
from .base import BaseVisionProvider
from ..errors import ConfigError, ProviderError


class OllamaCloudProvider(BaseVisionProvider):
    def __init__(self, cfg: OllamaCloudConfig, model: str):
        if not cfg.api_key:
            raise ConfigError("Ollama Cloud API key is required but not provided.")
        self._base_url = cfg.base_url.rstrip("/")
        self._api_key = cfg.api_key
        self._model = model

    @property
    def name(self) -> str:
        return f"ollama_cloud/{self._model}"

    async def query(
        self, image: ImagePayload, prompt: str, *, model: str | None = None
    ) -> str:
        effective_model = model or self._model
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": effective_model,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:{image.mime_type};base64,{image.data}"
                            },
                        },
                        {"type": "text", "text": prompt},
                    ],
                }
            ],
            "max_tokens": 4096,
        }
        try:
            async with httpx.AsyncClient(timeout=120) as client:
                resp = await client.post(
                    f"{self._base_url}/chat/completions",
                    headers=headers,
                    json=payload,
                )
                resp.raise_for_status()
                return resp.json()["choices"][0]["message"]["content"]
        except httpx.HTTPStatusError as e:
            body = e.response.text[:300]
            if e.response.status_code == 401:
                raise ProviderError("Ollama Cloud API key is invalid or missing.")
            if e.response.status_code == 429:
                raise ProviderError(
                    "Ollama Cloud rate limit hit. Try again in a moment."
                )
            raise ProviderError(
                f"Ollama Cloud API error {e.response.status_code}: {body}"
            )
        except KeyError:
            raise ProviderError("Ollama Cloud returned an unexpected response shape.")
