"""Abstract base for all vision providers."""

from __future__ import annotations
from abc import ABC, abstractmethod
from ..image import ImagePayload


class BaseVisionProvider(ABC):
    """
    Every provider implements one method: query().
    It takes an image payload + a text prompt and returns a string.
    That's the entire contract.
    """

    @abstractmethod
    async def query(
        self, image: ImagePayload, prompt: str, *, model: str | None = None
    ) -> str:
        """Send image + prompt to the vision model, return text response.

        Args:
            image: The image payload to analyze.
            prompt: The text prompt describing what to analyze.
            model: Optional per-request model override. If None, the provider's
                configured default model is used.
        """
        ...

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable provider name for error messages."""
        ...
