"""Ollama provider — calls local Ollama API."""

from __future__ import annotations
import httpx
from ..config import OllamaConfig
from ..image import ImagePayload
from .base import BaseVisionProvider
from ..errors import ProviderError


class OllamaProvider(BaseVisionProvider):
    def __init__(self, cfg: OllamaConfig, model: str):
        self._base_url = cfg.base_url.rstrip("/")
        self._model = model

    @property
    def name(self) -> str:
        return f"ollama/{self._model}"

    async def query(
        self, image: ImagePayload, prompt: str, *, model: str | None = None
    ) -> str:
        effective_model = model or self._model
        payload = {
            "model": effective_model,
            "prompt": prompt,
            "images": [image.data],
            "stream": False,
        }
        try:
            async with httpx.AsyncClient(timeout=120) as client:
                resp = await client.post(f"{self._base_url}/api/generate", json=payload)
                resp.raise_for_status()
                return resp.json()["response"]
        except httpx.ConnectError:
            raise ProviderError(
                f"Cannot connect to Ollama at {self._base_url}. "
                "Is Ollama running? Try: ollama serve"
            )
        except httpx.HTTPStatusError as e:
            raise ProviderError(
                f"Ollama API error {e.response.status_code}: {e.response.text[:200]}"
            )
        except KeyError:
            raise ProviderError("Ollama returned an unexpected response shape.")
