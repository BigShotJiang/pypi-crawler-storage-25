"""Custom provider — routes to openai_compatible or ollama API style."""

from __future__ import annotations
import httpx
from ..config import CustomProviderConfig
from ..image import ImagePayload
from .base import BaseVisionProvider
from ..errors import ProviderError


class CustomProvider(BaseVisionProvider):
    def __init__(self, cfg: CustomProviderConfig, model: str):
        self._cfg = cfg
        self._model = model

    @property
    def name(self) -> str:
        return f"custom/{self._model}"

    async def query(
        self, image: ImagePayload, prompt: str, *, model: str | None = None
    ) -> str:
        effective_model = model or self._model
        if self._cfg.api_style == "openai_compatible":
            return await self._query_openai_compatible(image, prompt, effective_model)
        else:
            return await self._query_ollama(image, prompt, effective_model)

    async def _query_openai_compatible(
        self, image: ImagePayload, prompt: str, effective_model: str
    ) -> str:
        headers = {"Content-Type": "application/json"}
        if self._cfg.api_key:
            headers["Authorization"] = f"Bearer {self._cfg.api_key}"
        payload = {
            "model": effective_model,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:{image.mime_type};base64,{image.data}"
                            },
                        },
                        {"type": "text", "text": prompt},
                    ],
                }
            ],
            "max_tokens": 4096,
        }
        try:
            async with httpx.AsyncClient(timeout=120) as client:
                resp = await client.post(
                    f"{self._cfg.base_url.rstrip('/')}/chat/completions",
                    headers=headers,
                    json=payload,
                )
                resp.raise_for_status()
                return resp.json()["choices"][0]["message"]["content"]
        except httpx.HTTPStatusError as e:
            body = e.response.text[:300]
            if e.response.status_code == 401:
                raise ProviderError(
                    f"Custom provider ({self._cfg.api_style}) API key is invalid or missing."
                )
            raise ProviderError(
                f"Custom provider ({self._cfg.api_style}) API error {e.response.status_code}: {body}"
            )
        except KeyError:
            raise ProviderError(
                f"Custom provider ({self._cfg.api_style}) returned an unexpected response shape."
            )

    async def _query_ollama(
        self, image: ImagePayload, prompt: str, effective_model: str
    ) -> str:
        payload = {
            "model": effective_model,
            "prompt": prompt,
            "images": [image.data],
            "stream": False,
        }
        try:
            async with httpx.AsyncClient(timeout=120) as client:
                resp = await client.post(
                    f"{self._cfg.base_url.rstrip('/')}/api/generate", json=payload
                )
                resp.raise_for_status()
                return resp.json()["response"]
        except httpx.ConnectError:
            raise ProviderError(
                f"Cannot connect to custom Ollama-style provider at {self._cfg.base_url}."
            )
        except httpx.HTTPStatusError as e:
            raise ProviderError(
                f"Custom provider ({self._cfg.api_style}) API error {e.response.status_code}: {e.response.text[:200]}"
            )
        except KeyError:
            raise ProviderError(
                f"Custom provider ({self._cfg.api_style}) returned an unexpected response shape."
            )
