"""Anthropic provider — Claude 3+ vision."""

from __future__ import annotations
import httpx
from ..config import AnthropicConfig
from ..image import ImagePayload
from .base import BaseVisionProvider
from ..errors import ProviderError


class AnthropicProvider(BaseVisionProvider):
    def __init__(self, cfg: AnthropicConfig, model: str):
        self._api_key = cfg.api_key
        self._model = model

    @property
    def name(self) -> str:
        return f"anthropic/{self._model}"

    async def query(
        self, image: ImagePayload, prompt: str, *, model: str | None = None
    ) -> str:
        effective_model = model or self._model
        headers = {
            "x-api-key": self._api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        payload = {
            "model": effective_model,
            "max_tokens": 4096,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": image.mime_type,
                                "data": image.data,
                            },
                        },
                        {"type": "text", "text": prompt},
                    ],
                }
            ],
        }
        try:
            async with httpx.AsyncClient(timeout=120) as client:
                resp = await client.post(
                    "https://api.anthropic.com/v1/messages",
                    headers=headers,
                    json=payload,
                )
                resp.raise_for_status()
                return resp.json()["content"][0]["text"]
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                raise ProviderError("Anthropic API key is invalid or missing.")
            raise ProviderError(
                f"Anthropic API error {e.response.status_code}: {e.response.text[:300]}"
            )
        except KeyError:
            raise ProviderError("Anthropic returned an unexpected response shape.")
