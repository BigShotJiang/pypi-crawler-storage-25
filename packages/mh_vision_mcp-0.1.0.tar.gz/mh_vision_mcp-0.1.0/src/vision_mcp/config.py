from __future__ import annotations
import os
from pathlib import Path
from typing import Any, Literal
import yaml
from pydantic import BaseModel, ConfigDict, Field, model_validator


class OllamaConfig(BaseModel):
    base_url: str = "http://localhost:11434"


class OpenAIConfig(BaseModel):
    api_key: str = ""
    base_url: str = "https://api.openai.com/v1"


class AnthropicConfig(BaseModel):
    api_key: str = ""


class ZhipuAIConfig(BaseModel):
    api_key: str = ""
    base_url: str = "https://open.bigmodel.cn/api/paas/v4"


class OllamaCloudConfig(BaseModel):
    api_key: str = ""
    base_url: str = "https://api.ollama.com/v1"


class CustomProviderConfig(BaseModel):
    api_style: Literal["openai_compatible", "ollama"]
    base_url: str
    api_key: str = ""
    model: str = ""


class ProvidersConfig(BaseModel):
    model_config = ConfigDict(extra="allow")

    ollama: OllamaConfig = Field(default_factory=OllamaConfig)
    openai: OpenAIConfig = Field(default_factory=OpenAIConfig)
    anthropic: AnthropicConfig = Field(default_factory=AnthropicConfig)
    zhipuai: ZhipuAIConfig = Field(default_factory=ZhipuAIConfig)
    custom_providers: dict[str, CustomProviderConfig] = Field(default_factory=dict)
    ollama_cloud: OllamaCloudConfig = Field(default_factory=OllamaCloudConfig)

    @model_validator(mode="after")
    def _merge_extra_into_custom_providers(self) -> "ProvidersConfig":
        builtins = {
            "ollama",
            "openai",
            "anthropic",
            "zhipuai",
            "custom_providers",
            "ollama_cloud",
        }
        for key, value in (self.__pydantic_extra__ or {}).items():
            if key not in builtins and key not in self.custom_providers:
                if isinstance(value, dict):
                    self.custom_providers[key] = CustomProviderConfig(**value)
        return self


class ToolConfig(BaseModel):
    enabled: bool = True
    default_detail: str = "high"
    output_format: str = "json"
    model: str | None = None


class ToolsConfig(BaseModel):
    describe_image: ToolConfig = Field(default_factory=ToolConfig)
    extract_ui: ToolConfig = Field(default_factory=ToolConfig)
    ocr: ToolConfig = Field(default_factory=ToolConfig)
    analyze_diagram: ToolConfig = Field(default_factory=ToolConfig)


class AppConfig(BaseModel):
    provider: str = "ollama"
    model: str = "llava:latest"
    providers: ProvidersConfig = Field(default_factory=ProvidersConfig)
    tools: ToolsConfig = Field(default_factory=ToolsConfig)

    def get_provider_config(self) -> Any:
        # Check built-in providers first
        if self.provider in ("ollama", "openai", "anthropic", "zhipuai"):
            return getattr(self.providers, self.provider)
        # Handle ollama_cloud provider
        if self.provider == "ollama_cloud":
            return self.providers.ollama_cloud
        # Fall back to custom_providers for unknown names
        if self.provider in self.providers.custom_providers:
            return self.providers.custom_providers[self.provider]
        return getattr(self.providers, "ollama")


def load_config(path: str | Path | None = None) -> AppConfig:
    """Load config from YAML file. Falls back to defaults if file not found."""
    from .errors import ConfigError

    if path is None:
        path = Path(os.environ.get("VISION_MCP_CONFIG", "config.yaml"))
    path = Path(path)
    if not path.exists():
        return AppConfig()
    with open(path) as f:
        raw = yaml.safe_load(f) or {}
    config = AppConfig(**raw)
    builtins = {"ollama", "openai", "anthropic", "zhipuai"}
    if (
        config.provider in builtins
        and config.provider in config.providers.custom_providers
    ):
        raise ConfigError(
            f"Custom provider name '{config.provider}' collides with a built-in provider name. "
            f"Choose a different name for your custom provider."
        )
    return config
