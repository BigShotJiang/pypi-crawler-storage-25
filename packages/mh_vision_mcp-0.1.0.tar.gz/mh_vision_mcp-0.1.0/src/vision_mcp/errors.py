"""Clean error types for the vision MCP server."""
from __future__ import annotations


class VisionMCPError(Exception):
    """Base error — always has a user-readable message."""


class ImageLoadError(VisionMCPError):
    """Failed to load or decode an image from the given source."""


class ProviderError(VisionMCPError):
    """The vision model API returned an error or unexpected response."""


class ConfigError(VisionMCPError):
    """Something is wrong with config.yaml."""
