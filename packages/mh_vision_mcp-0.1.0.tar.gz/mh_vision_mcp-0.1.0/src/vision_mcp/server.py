"""Vision MCP server — exposes vision tools to any non-vision model."""

from __future__ import annotations
from mcp.server.fastmcp import FastMCP
from .config import load_config
from .image import load_image
from .providers import get_provider
from .errors import VisionMCPError, ImageLoadError, ProviderError

# Load config (respects VISION_MCP_CONFIG env var, falls back to ./config.yaml)
config = load_config()
provider = get_provider(config)
tools_cfg = config.tools

mcp = FastMCP(
    name="mh-vision-mcp",
    instructions=(
        f"Vision tools powered by {provider.name}. "
        "Use these tools whenever you need to read, describe, or extract "
        "information from images, screenshots, or design files."
    ),
)


async def _run(coro) -> str:
    """Wrap a provider query — return clean error string on failure."""
    try:
        return await coro
    except (ImageLoadError, ProviderError, VisionMCPError) as e:
        return f"[mh-vision-mcp error] {e}"
    except Exception as e:
        return f"[mh-vision-mcp unexpected error] {type(e).__name__}: {e}"


# ── Tool 1: describe_image ─────────────────────────────────────────────────
if tools_cfg.describe_image.enabled:

    @mcp.tool()
    async def describe_image(
        source: str,
        detail: str = "high",
        focus: str = "",
    ) -> str:
        """
        Describe what's in an image using a vision model.

        Args:
            source: Image source — file path, URL, base64 string, or data URI.
            detail: Level of detail — 'high' for thorough description,
                    'low' for a quick summary.
            focus:  Optional instruction to focus on specific aspects
                    (e.g. 'focus on text content' or 'describe the colors').
        """
        image = load_image(source)
        focus_instruction = f"\n\nFocus on: {focus}" if focus else ""
        detail_instruction = (
            "Provide a thorough, detailed description of everything visible."
            if detail == "high"
            else "Provide a brief summary of the main content."
        )
        prompt = f"{detail_instruction}{focus_instruction}"
        tool_model = tools_cfg.describe_image.model
        kwargs = {"model": tool_model} if tool_model else {}
        return await _run(provider.query(image, prompt, **kwargs))


# ── Tool 2: extract_ui ────────────────────────────────────────────────────
if tools_cfg.extract_ui.enabled:

    @mcp.tool()
    async def extract_ui(
        source: str,
        output_format: str = "json",
    ) -> str:
        """
        Extract UI components from a screenshot or design file.

        Args:
            source: Image source — file path, URL, base64, or data URI.
            output_format: 'json' for structured data, 'markdown' for readable list.
        """
        image = load_image(source)
        if output_format == "json":
            prompt = """Analyze this UI screenshot or design and extract all components.
Return ONLY valid JSON (no markdown fences) in this exact structure:
{
  "layout": "description of the overall layout",
  "components": [
    {
      "type": "button|input|text|image|icon|nav|card|modal|...",
      "label": "visible text or aria label",
      "position": "top-left|top-center|top-right|center|bottom-left|...",
      "state": "default|hover|active|disabled|...",
      "notes": "any relevant details"
    }
  ],
  "color_palette": ["#hex1", "#hex2"],
  "typography": "brief note on fonts/sizes used",
  "accessibility_notes": "any obvious accessibility observations"
}"""
        else:
            prompt = """Analyze this UI screenshot or design.
List all visible components in markdown format:
- For each component: type, label/content, position, and any notable states.
- Group by section (header, main content, footer, etc.).
- Note the color scheme and typography briefly at the end."""
        tool_model = tools_cfg.extract_ui.model
        kwargs = {"model": tool_model} if tool_model else {}
        return await _run(provider.query(image, prompt, **kwargs))


# ── Tool 3: ocr ───────────────────────────────────────────────────────────
if tools_cfg.ocr.enabled:

    @mcp.tool()
    async def ocr(
        source: str,
        output_format: str = "plain",
        language_hint: str = "",
    ) -> str:
        """
        Extract text from an image using OCR via a vision model.

        Args:
            source: Image source — file path, URL, base64, or data URI.
            output_format: 'plain' for raw text, 'structured' for JSON with regions.
            language_hint: Optional hint about the language (e.g. 'Arabic', 'Chinese').
        """
        image = load_image(source)
        lang_note = f" The text may be in {language_hint}." if language_hint else ""
        if output_format == "structured":
            prompt = f"""Extract all text from this image.{lang_note}
Return ONLY valid JSON (no markdown fences):
{{
  "full_text": "all text concatenated in reading order",
  "regions": [
    {{
      "text": "text in this region",
      "region": "top|middle|bottom + left|center|right",
      "style": "heading|body|caption|label|code|..."
    }}
  ]
}}"""
        else:
            prompt = f"""Extract all text from this image exactly as it appears.{lang_note}
Preserve line breaks and formatting. Return only the extracted text, nothing else."""
        tool_model = tools_cfg.ocr.model
        kwargs = {"model": tool_model} if tool_model else {}
        return await _run(provider.query(image, prompt, **kwargs))


# ── Tool 4: analyze_diagram ───────────────────────────────────────────────
if tools_cfg.analyze_diagram.enabled:

    @mcp.tool()
    async def analyze_diagram(
        source: str,
        diagram_type: str = "auto",
    ) -> str:
        """
        Analyze a diagram, chart, flowchart, or technical drawing.

        Args:
            source: Image source — file path, URL, base64, or data URI.
            diagram_type: Type hint — 'auto', 'flowchart', 'erd', 'sequence',
                          'chart', 'architecture', 'wireframe', 'mindmap'.
        """
        image = load_image(source)
        type_hint = (
            "" if diagram_type == "auto" else f" This appears to be a {diagram_type}."
        )
        prompt = f"""Analyze this diagram.{type_hint}
Return ONLY valid JSON (no markdown fences):
{{
  "diagram_type": "detected type",
  "title": "diagram title if present",
  "summary": "one sentence describing what this diagram shows",
  "nodes": [
    {{"id": "A", "label": "label text", "type": "process|decision|data|..."}}
  ],
  "edges": [
    {{"from": "A", "to": "B", "label": "edge label if any"}}
  ],
  "notes": "any legends, annotations, or important details"
}}"""
        tool_model = tools_cfg.analyze_diagram.model
        kwargs = {"model": tool_model} if tool_model else {}
        return await _run(provider.query(image, prompt, **kwargs))


def main() -> None:
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
