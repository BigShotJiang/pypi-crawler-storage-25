# Custom Providers, Ollama Cloud & Per-Tool Model Override

## TL;DR

> **Quick Summary**: Extend vision-mcp with config-driven custom providers (YAML-only, no code), add Ollama Cloud as a dedicated provider, and allow per-tool model name overrides while keeping a single provider instance.
>
> **Deliverables**:
> - `CustomProvider` class that routes to either `openai_compatible` or `ollama` API style based on config
> - `OllamaCloudProvider` class for Ollama's cloud service
> - `custom_providers:` map in `config.yaml` for user-defined providers
> - Per-tool `model:` override in tool config
> - Optional `model` parameter on `BaseVisionProvider.query()`
> - Updated `get_provider()` factory to handle custom provider names
> - Test suite covering all new functionality
> - Updated README with custom provider and Ollama Cloud docs
>
> **Estimated Effort**: Medium
> **Parallel Execution**: YES - 4 waves
> **Critical Path**: Task 1 (config) → Task 3 (base provider) → Task 4-5 (custom+ollama_cloud) → Task 6 (factory) → Task 7 (server per-tool model) → Task 8 (tests) → Task 9 (README)

---

## Context

### Original Request
Add custom providers and Ollama Cloud, and allow the user to add the vision model too.

### Interview Summary
**Key Discussions**:
- Custom providers: Config-driven generic approach — users define providers in YAML, no code needed
- API styles: Support `openai_compatible` and `ollama` (native) styles
- Custom provider config: Named map in `custom_providers:` section of config.yaml
- Ollama Cloud: Separate provider class with OpenAI-compatible endpoint + API key auth
- Per-tool model: Model-only override (not provider override). Each tool can specify its own model name, falls back to global `model:`
- Test strategy: Tests after implementation

**Research Findings**:
- Current architecture has 4 hardcoded providers with if/elif factory in `providers/__init__.py`
- `BaseVisionProvider` has single contract: `async query(image, prompt) -> str`
- `ProvidersConfig` has fixed fields for 4 providers — needs `custom_providers` dict
- `get_provider_config()` uses `getattr()` which would `AttributeError` for custom names — needs fallback
- Server creates a single provider at module level — per-tool model override only needs adding `model` param to `query()`
- Ollama Cloud uses OpenAI-compatible `/v1/chat/completions` with Bearer token auth

### Metis Review
**Identified Gaps** (addressed):
- Per-tool override should be model-only (not provider) — preserves singleton provider architecture. **Resolved**: Will add optional `model` param to `query()` method.
- `get_provider_config()` needs graceful fallback for custom provider names. **Resolved**: Will add `custom_providers` dict to `ProvidersConfig` and update `get_provider_config()`.
- Custom provider names must not collide with built-in names. **Resolved**: Will add validation in config loading.
- No test infrastructure exists yet. **Resolved**: Will add pytest setup + test tasks.
- Need to validate Ollama Cloud's exact auth pattern. **Default**: Assume OpenAI-compatible Bearer token; document config.

---

## Work Objectives

### Core Objective
Make vision-mcp extensible via configuration — users can add any OpenAI-compatible or Ollama-native vision provider without writing code, use Ollama's cloud service, and pick different models for different tools.

### Concrete Deliverables
- `src/vision_mcp/providers/custom.py` — Generic provider routing by `api_style`
- `src/vision_mcp/providers/ollama_cloud.py` — Dedicated Ollama Cloud provider
- Updated `src/vision_mcp/config.py` — CustomProviderConfig, OllamaCloudConfig, per-tool model override
- Updated `src/vision_mcp/providers/__init__.py` — Factory handles custom + ollama_cloud
- Updated `src/vision_mcp/providers/base.py` — Optional `model` param on `query()`
- Updated `src/vision_mcp/server.py` — Pass per-tool model to provider
- Updated `config.yaml` — Example custom_providers + ollama_cloud sections
- `tests/` — Test suite for new functionality
- Updated `README.md` — Custom provider docs, Ollama Cloud docs, per-tool model docs

### Definition of Done
- [ ] Custom provider defined in YAML works end-to-end (both API styles)
- [ ] `provider: ollama_cloud` in config works with API key auth
- [ ] Per-tool `model:` override works for all 4 tools
- [ ] Existing configs with no custom providers still work (backward compat)
- [ ] Custom provider name collision with built-ins raises clear error
- [ ] All tests pass

### Must Have
- Config-driven custom providers with `openai_compatible` and `ollama` API styles
- Ollama Cloud as a named provider
- Per-tool model override in tool config
- Backward compatible — existing config.yaml files work unchanged
- Validation: custom provider names cannot shadow built-in names
- Clear error messages when custom provider config is invalid

### Must NOT Have (Guardrails)
- No plugin/entry-point system — pure config-driven approach only
- No per-tool provider override — model name only
- No `anthropic_compatible` API style for custom providers (future scope)
- No streaming responses — keep request/response pattern
- No changes to existing built-in provider implementations (ollama.py, openai.py, anthropic.py, zhipuai.py)
- No AI-slop: excessive comments, over-abstraction, generic variable names
- No breaking changes to the `BaseVisionProvider` contract (only additive changes)

---

## Verification Strategy (MANDATORY)

> **ZERO HUMAN INTERVENTION** — ALL verification is agent-executed. No exceptions.

### Test Decision
- **Infrastructure exists**: NO (currently zero test files)
- **Automated tests**: YES (tests after implementation)
- **Framework**: pytest (standard for Python)
- **If TDD**: N/A

### QA Policy
Every task MUST include agent-executed QA scenarios.
Evidence saved to `.sisyphus/evidence/task-{N}-{scenario-slug}.{ext}`.

- **API/Backend**: Use Bash (curl) — Send requests, assert status + response fields
- **Library/Module**: Use Bash (python -c) — Import, call functions, compare output

---

## Execution Strategy

### Parallel Execution Waves

```
Wave 1 (Start Immediately — config + base changes):
├── Task 1: Config model updates (CustomProviderConfig, OllamaCloudConfig, per-tool model) [quick]
├── Task 2: BaseVisionProvider optional model param [quick]
└── Task 3: OllamaConfig + existing provider model-override support [quick]

Wave 2 (After Wave 1 — new providers, depends on Task 1 + 2):
├── Task 4: CustomProvider class (openai_compatible + ollama styles) [deep]
├── Task 5: OllamaCloudProvider class [unspecified-high]
└── Task 6: Provider factory rewrite (custom + ollama_cloud + validation) [unspecified-high]

Wave 3 (After Wave 2 — integration + docs):
├── Task 7: Server.py per-tool model override integration [quick]
├── Task 8: Config.yaml examples + validation [quick]
└── Task 9: README.md documentation update [writing]

Wave 4 (After Wave 3 — tests):
└── Task 10: pytest test suite (custom provider, ollama cloud, per-tool model, backward compat) [unspecified-high]

Wave FINAL (After ALL tasks — 4 parallel reviews):
├── Task F1: Plan compliance audit (oracle)
├── Task F2: Code quality review (unspecified-high)
├── Task F3: Real manual QA (unspecified-high)
└── Task F4: Scope fidelity check (deep)
-> Present results -> Get explicit user okay

Critical Path: Task 1 → Task 4 → Task 6 → Task 7 → Task 10 → F1-F4
Parallel Speedup: ~50% faster than sequential
Max Concurrent: 3 (Wave 2)
```

### Dependency Matrix

| Task | Depends On | Blocks | Wave |
|------|-----------|--------|------|
| 1 | - | 4, 5, 6, 7 | 1 |
| 2 | - | 4, 5, 6, 7 | 1 |
| 3 | 2 | 4, 7 | 1 |
| 4 | 1, 2 | 6 | 2 |
| 5 | 1, 2 | 6 | 2 |
| 6 | 4, 5 | 7 | 2 |
| 7 | 6 | 10 | 3 |
| 8 | 6 | 10 | 3 |
| 9 | 6 | - | 3 |
| 10 | 7, 8 | F1-F4 | 4 |

### Agent Dispatch Summary

- **Wave 1**: 3 tasks — T1 `quick`, T2 `quick`, T3 `quick`
- **Wave 2**: 3 tasks — T4 `deep`, T5 `unspecified-high`, T6 `unspecified-high`
- **Wave 3**: 3 tasks — T7 `quick`, T8 `quick`, T9 `writing`
- **Wave 4**: 1 task — T10 `unspecified-high`
- **FINAL**: 4 tasks — F1 `oracle`, F2 `unspecified-high`, F3 `unspecified-high`, F4 `deep`

---

## TODOs

- [x] 1. Config Model Updates — CustomProviderConfig, OllamaCloudConfig, per-tool model

  **What to do**:
  - Add `CustomProviderConfig(BaseModel)` with fields: `api_style` (Literal["openai_compatible", "ollama"]), `base_url` (str), `api_key` (str = ""), `model` (str = "")
  - Add `OllamaCloudConfig(BaseModel)` with fields: `api_key` (str = ""), `base_url` (str = "https://api.ollama.com/v1")
  - Add `model: str | None` field to `ToolConfig` (default None) for per-tool model override
  - Add `custom_providers: dict[str, CustomProviderConfig]` field to `ProvidersConfig` (default empty dict)
  - Add `ollama_cloud: OllamaCloudConfig` field to `ProvidersConfig`
  - Update `ProvidersConfig` to include `ollama_cloud` field
  - Update `AppConfig.get_provider_config()` to handle custom provider names by checking `custom_providers` dict as fallback
  - Add validation: if `provider` name matches a built-in name AND exists in `custom_providers`, raise `ConfigError` with clear message about name collision

  **Must NOT do**:
  - Do not remove or rename any existing config fields
  - Do not change existing provider config defaults
  - Do not add `anthropic_compatible` API style
  - Do not add per-tool provider override — model only

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Single file changes, well-defined Pydantic model additions
  - **Skills**: []
    - No special skills needed — pure Python/Pydantic config work
  - **Skills Evaluated but Omitted**:
    - `context7`: Pydantic docs not needed — model additions are trivial

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 1 (with Tasks 2, 3)
  - **Blocks**: Tasks 4, 5, 6, 7
  - **Blocked By**: None

  **References**:
  **Pattern References**:
  - `src/vision_mcp/config.py:9-31` — Existing provider config classes (OllamaConfig, OpenAIConfig, AnthropicConfig, ZhipuAIConfig). Follow the same pattern for CustomProviderConfig and OllamaCloudConfig.
  - `src/vision_mcp/config.py:27-31` — ProvidersConfig class. Add `custom_providers` dict and `ollama_cloud` field here.
  - `src/vision_mcp/config.py:34-38` — ToolConfig class. Add `model: str | None = None` field here.
  - `src/vision_mcp/config.py:47-54` — AppConfig class and `get_provider_config()`. Update this method to fall back to `custom_providers` dict.

  **External References**:
  - Pydantic docs: https://docs.pydantic.dev/latest/concepts/models/ — BaseModel, Field, default_factory patterns

  **WHY Each Reference Matters**:
  - `config.py:9-31` — Exact pattern to copy for new config classes (field types, defaults, Field usage)
  - `config.py:27-31` — Where to add new fields — must be backward compatible (all new fields need defaults)
  - `config.py:34-38` — Where to add per-tool model — `model: str | None = None` is additive, won't break existing configs
  - `config.py:47-54` — Must update `get_provider_config()` to handle custom names — current `getattr()` will fail for custom provider names

  **Acceptance Criteria**:
  - [ ] `CustomProviderConfig` class exists with `api_style`, `base_url`, `api_key`, `model` fields
  - [ ] `OllamaCloudConfig` class exists with `api_key`, `base_url` fields
  - [ ] `ToolConfig` has `model: str | None = None` field
  - [ ] `ProvidersConfig` has `custom_providers: dict[str, CustomProviderConfig]` field
  - [ ] `ProvidersConfig` has `ollama_cloud: OllamaCloudConfig` field
  - [ ] `get_provider_config()` returns custom provider config when name matches a custom_providers key
  - [ ] Validation: custom provider name colliding with built-in raises ConfigError
  - [ ] Backward compat: existing config.yaml loads without errors

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Custom provider config loads from YAML
    Tool: Bash (python -c)
    Preconditions: config.yaml has a custom_providers section with a "groq" entry
    Steps:
      1. Create temporary config with custom_providers: groq: {api_style: openai_compatible, base_url: "https://api.groq.com/openai/v1", api_key: "gsk_test", model: "llama-3.2-11b-vision"}
      2. Run: python -c "from vision_mcp.config import load_config; c = load_config('/tmp/test_config.yaml'); print(c.providers.custom_providers['groq'].api_style)"
      3. Assert output contains "openai_compatible"
    Expected Result: Config loads without error, custom_providers dict populated
    Failure Indicators: AttributeError, ValidationError, or empty dict
    Evidence: .sisyphus/evidence/task-1-custom-config-loads.txt

  Scenario: Custom provider name collision with built-in raises error
    Tool: Bash (python -c)
    Preconditions: config.yaml has custom_providers with key "ollama" (same as built-in)
    Steps:
      1. Create temporary config with custom_providers: ollama: {api_style: openai_compatible, base_url: "...", api_key: "..."}
      2. Run: python -c "from vision_mcp.config import load_config; c = load_config('/tmp/test_collision.yaml')"
      3. Assert raises ConfigError with message containing "collision" or "reserved"
    Expected Result: ConfigError raised with clear message
    Failure Indicators: Config loads successfully (name collision not detected)
    Evidence: .sisyphus/evidence/task-1-name-collision-error.txt

  Scenario: Backward compat — old config without custom_providers still works
    Tool: Bash (python -c)
    Preconditions: Existing config.yaml format (no custom_providers, no ollama_cloud, no model on tools)
    Steps:
      1. Run: python -c "from vision_mcp.config import load_config; c = load_config(); print(c.provider, c.model, c.providers.custom_providers, c.tools.describe_image.model)"
      2. Assert output shows "ollama llava:latest {} None"
    Expected Result: Default config loads without errors, new fields have sensible defaults
    Failure Indicators: ValidationError, missing attribute, or non-default values
    Evidence: .sisyphus/evidence/task-1-backward-compat.txt
  ```

  **Commit**: YES (groups with Tasks 2, 3)
  - Message: `feat(config): add custom provider, ollama cloud, and per-tool model config models`
  - Files: `src/vision_mcp/config.py`
  - Pre-commit: `python -c "from vision_mcp.config import load_config; load_config()"`

- [x] 2. BaseVisionProvider Optional Model Param

  **What to do**:
  - Update `BaseVisionProvider.query()` signature to: `async def query(self, image: ImagePayload, prompt: str, *, model: str | None = None) -> str`
  - This is a pure signature change — the `model` param is keyword-only and optional
  - Update the docstring to document the `model` parameter
  - This change is backward compatible — existing call sites passing `(image, prompt)` still work

  **Must NOT do**:
  - Do not change existing provider implementations yet (Task 3 does that)
  - Do not make `model` a positional argument — keep it keyword-only
  - Do not add any logic about model selection to the base class

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Single method signature change in a small file
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 1 (with Tasks 1, 3)
  - **Blocks**: Tasks 3, 4, 5
  - **Blocked By**: None

  **References**:
  **Pattern References**:
  - `src/vision_mcp/providers/base.py:14-16` — Current `query()` signature. Add `model: str | None = None` as keyword-only param.

  **WHY Each Reference Matters**:
  - `base.py:14-16` — The exact method to modify — keep the abstract contract clean, just add the optional param

  **Acceptance Criteria**:
  - [ ] `BaseVisionProvider.query()` accepts `model: str | None = None` keyword argument
  - [ ] Existing call sites `provider.query(image, prompt)` still work (backward compat)
  - [ ] Docstring updated

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: query() accepts model param without error
    Tool: Bash (python -c)
    Preconditions: Base class is abstract, so test via a concrete provider
    Steps:
      1. Run: python -c "
import inspect
from vision_mcp.providers.base import BaseVisionProvider
sig = inspect.signature(BaseVisionProvider.query)
params = list(sig.parameters.keys())
print(params)
"
      2. Assert output contains "model" in the parameter list
    Expected Result: "model" appears in parameter list after "prompt"
    Failure Indicators: "model" not found in params
    Evidence: .sisyphus/evidence/task-2-model-param.txt

  Scenario: Backward compat — query(image, prompt) still valid
    Tool: Bash (python -c)
    Preconditions: Existing code passes only image and prompt
    Steps:
      1. Run: python -c "
import inspect
from vision_mcp.providers.base import BaseVisionProvider
sig = inspect.signature(BaseVisionProvider.query)
model_param = sig.parameters.get('model')
print(model_param.default if model_param else 'MISSING')
"
      2. Assert output is "None" (default value of model param)
    Expected Result: model param defaults to None — existing calls work unchanged
    Failure Indicators: "MISSING" or non-None default
    Evidence: .sisyphus/evidence/task-2-backward-compat.txt
  ```

  **Commit**: YES (groups with Tasks 1, 3)
  - Message: `feat(config): add custom provider, ollama cloud, and per-tool model config models`
  - Files: `src/vision_mcp/providers/base.py`

- [x] 3. Existing Provider Model-Override Support

  **What to do**:
  - Update each existing provider (OllamaProvider, OpenAIProvider, AnthropicProvider, ZhipuAIProvider) to support the `model` parameter in `query()`:
    - When `model` is passed, use it instead of `self._model`
    - When `model` is None, use `self._model` (default behavior)
  - Implementation pattern for each provider: `effective_model = model or self._model`
  - Use this `effective_model` wherever `self._model` was used in the query payload

  **Must NOT do**:
  - Do not change the provider `__init__` signatures
  - Do not change the `name` property (it still reflects the configured model, not the override)
  - Do not add any other new parameters

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Mechanical change across 4 files — same pattern repeated
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 1 (with Tasks 1, 2)
  - **Blocks**: Tasks 4, 7
  - **Blocked By**: Task 2 (base class signature must be updated first)

  **References**:
  **Pattern References**:
  - `src/vision_mcp/providers/ollama.py:19-20` — `query()` method where `self._model` is used in payload. Change line 22 to use `model or self._model`.
  - `src/vision_mcp/providers/openai.py:20` — `query()` method where `self._model` is used in payload. Change line 28 to use `model or self._model`.
  - `src/vision_mcp/providers/anthropic.py` — Same pattern — use `model or self._model` in payload.
  - `src/vision_mcp/providers/zhipuai.py` — Same pattern — use `model or self._model` in payload.

  **WHY Each Reference Matters**:
  - Each provider's `query()` method has one place where `self._model` is used in the HTTP payload. That's the only line to change — replace `self._model` with `model or self._model`.

  **Acceptance Criteria**:
  - [ ] All 4 providers accept `model` kwarg in `query()`
  - [ ] When `model` is passed, that model name is used in the API request
  - [ ] When `model` is None, `self._model` is used (default behavior)
  - [ ] No change to provider initialization or `name` property

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Provider uses override model when provided
    Tool: Bash (python -c)
    Preconditions: OllamaProvider instantiated with default model "llava:latest"
    Steps:
      1. Run: python -c "
import asyncio, unittest.mock
from vision_mcp.config import OllamaConfig
from vision_mcp.providers.ollama import OllamaProvider
from vision_mcp.image import ImagePayload

cfg = OllamaConfig(base_url='http://localhost:11434')
p = OllamaProvider(cfg, 'llava:latest')

# Mock httpx to capture the payload
async def test():
    with unittest.mock.patch('httpx.AsyncClient') as mock_client:
        instance = mock_client.return_value.__aenter__.return_value
        instance.post = unittest.mock.AsyncMock(return_value=unittest.mock.MagicMock(
            raise_for_status=lambda: None,
            json=lambda: {'response': 'test'}
        ))
        img = ImagePayload(data='dGVzdA==', mime_type='image/png')
        await p.query(img, 'test', model='moondream:latest')
        call_args = instance.post.call_args
        payload = call_args.kwargs.get('json', call_args[1].get('json', {}))
        print(payload.get('model'))
asyncio.run(test())
"
      2. Assert output is "moondream:latest" (overridden model)
    Expected Result: "moondream:latest" printed — override model was used
    Failure Indicators: "llava:latest" (default used instead of override) or error
    Evidence: .sisyphus/evidence/task-3-model-override.txt
  ```

  **Commit**: YES (groups with Tasks 1, 2)
  - Message: `feat(config): add custom provider, ollama cloud, and per-tool model config models`
  - Files: `src/vision_mcp/providers/ollama.py`, `src/vision_mcp/providers/openai.py`, `src/vision_mcp/providers/anthropic.py`, `src/vision_mcp/providers/zhipuai.py`

- [x] 4. CustomProvider Class (openai_compatible + ollama styles)

  **What to do**:
  - Create `src/vision_mcp/providers/custom.py`
  - Implement `CustomProvider(BaseVisionProvider)`:
    - `__init__(self, cfg: CustomProviderConfig, model: str)` — store cfg, model
    - `name` property returns `custom/{model}`
    - `query()` method:
      - If `cfg.api_style == "openai_compatible"`: build OpenAI-compatible `/chat/completions` payload (same structure as OpenAIProvider)
      - If `cfg.api_style == "ollama"`: build Ollama `/api/generate` payload (same structure as OllamaProvider)
      - Support `model` override param: `effective_model = model or self._model`
      - Handle auth: if `cfg.api_key` is non-empty, set `Authorization: Bearer {api_key}` header (for openai_compatible); no auth for ollama style
    - Error handling: same pattern as existing providers (ProviderError for HTTP errors, connect errors, unexpected responses)

  **Must NOT do**:
  - Do not copy-paste entire OpenAIProvider or OllamaProvider — extract shared logic cleanly
  - Do not implement `anthropic_compatible` API style
  - Do not add streaming support
  - Do not add retry logic or advanced features — keep it simple

  **Recommended Agent Profile**:
  - **Category**: `deep`
    - Reason: New file with branching logic for 2 API styles — needs careful implementation
  - **Skills**: [`context7`]
    - `context7`: May need httpx async patterns reference if unsure about streaming client usage

  **Parallelization**:
  - **Can Run In Parallel**: YES (if Task 1 config is done)
  - **Parallel Group**: Wave 2 (with Tasks 5, 6)
  - **Blocks**: Task 6
  - **Blocked By**: Tasks 1, 2

  **References**:
  **Pattern References**:
  - `src/vision_mcp/providers/openai.py:20-56` — OpenAI-compatible query implementation. Use this as the template for the `openai_compatible` branch.
  - `src/vision_mcp/providers/ollama.py:19-39` — Ollama-native query implementation. Use this as the template for the `ollama` branch.
  - `src/vision_mcp/providers/base.py:7-22` — BaseVisionProvider interface to implement.

  **API/Type References**:
  - `src/vision_mcp/config.py` (new CustomProviderConfig from Task 1) — Config model with `api_style`, `base_url`, `api_key`, `model` fields.
  - `src/vision_mcp/image.py:ImagePayload` — Image payload type used in query().
  - `src/vision_mcp/errors.py:ProviderError` — Error type to raise on failures.

  **Test References**:
  - `src/vision_mcp/providers/openai.py:48-56` — Error handling patterns (ProviderError for HTTPStatusError, KeyError, etc.)

  **External References**:
  - httpx async docs: https://www.python-httpx.org/async/ — AsyncClient usage patterns

  **WHY Each Reference Matters**:
  - `openai.py:20-56` — Exact payload structure for openai_compatible — content array with image_url and text types, Bearer auth header
  - `ollama.py:19-39` — Exact payload structure for ollama native — prompt+images dict, no auth header, different endpoint
  - `errors.py:ProviderError` — Consistent error reporting across all providers
  - `image.py:ImagePayload` — Must construct proper data URI for openai_compatible: `data:{mime_type};base64,{data}`

  **Acceptance Criteria**:
  - [ ] `custom.py` file created with CustomProvider class
  - [ ] `openai_compatible` style builds correct `/chat/completions` payload with auth header
  - [ ] `ollama` style builds correct `/api/generate` payload without auth
  - [ ] `model` override param works: uses override when provided, falls back to configured model
  - [ ] Error handling matches existing providers (ProviderError for all failure cases)
  - [ ] `name` property returns `custom/{model}`

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: CustomProvider with openai_compatible style builds correct payload
    Tool: Bash (python -c)
    Preconditions: CustomProviderConfig with api_style="openai_compatible", base_url, api_key
    Steps:
      1. Instantiate CustomProvider with openai_compatible config
      2. Mock httpx.AsyncClient to capture the request
      3. Call query() with an ImagePayload and prompt
      4. Assert the POST goes to {base_url}/chat/completions
      5. Assert headers contain "Authorization: Bearer {api_key}"
      6. Assert payload has "messages" with image_url content type
    Expected Result: Correct OpenAI-compatible request structure
    Failure Indicators: Wrong endpoint, missing auth header, wrong payload structure
    Evidence: .sisyphus/evidence/task-4-openai-compatible.txt

  Scenario: CustomProvider with ollama style builds correct payload
    Tool: Bash (python -c)
    Preconditions: CustomProviderConfig with api_style="ollama", base_url
    Steps:
      1. Instantiate CustomProvider with ollama config
      2. Mock httpx.AsyncClient to capture the request
      3. Call query() with an ImagePayload and prompt
      4. Assert the POST goes to {base_url}/api/generate
      5. Assert payload has "images" list and "prompt" field (Ollama native format)
      6. Assert no Authorization header is set
    Expected Result: Correct Ollama-native request structure
    Failure Indicators: Wrong endpoint, auth header present, wrong payload structure
    Evidence: .sisyphus/evidence/task-4-ollama-style.txt

  Scenario: Model override works in CustomProvider
    Tool: Bash (python -c)
    Preconditions: CustomProvider with default model "llava:latest"
    Steps:
      1. Mock httpx.AsyncClient
      2. Call query(image, prompt, model="moondream:latest")
      3. Assert the payload uses "moondream:latest" instead of "llava:latest"
    Expected Result: Override model name used in API payload
    Failure Indicators: Default model used instead of override
    Evidence: .sisyphus/evidence/task-4-model-override.txt

  Scenario: HTTP error returns ProviderError
    Tool: Bash (python -c)
    Preconditions: CustomProvider with openai_compatible config
    Steps:
      1. Mock httpx to return 401 HTTPStatusError
      2. Call query()
      3. Assert ProviderError is raised
    Expected Result: ProviderError with descriptive message
    Failure Indicators: Unhandled exception or wrong error type
    Evidence: .sisyphus/evidence/task-4-error-handling.txt
  ```

  **Commit**: YES (groups with Tasks 5, 6)
  - Message: `feat(providers): add custom provider, ollama cloud, and factory rewrite`
  - Files: `src/vision_mcp/providers/custom.py`

- [x] 5. OllamaCloudProvider Class

  **What to do**:
  - Create `src/vision_mcp/providers/ollama_cloud.py`
  - Implement `OllamaCloudProvider(BaseVisionProvider)`:
    - `__init__(self, cfg: OllamaCloudConfig, model: str)` — store cfg, model
    - `name` property returns `ollama_cloud/{model}`
    - `query()` method:
      - Uses OpenAI-compatible endpoint: POST to `{base_url}/chat/completions`
      - Sets `Authorization: Bearer {api_key}` header
      - Builds same payload structure as OpenAIProvider (messages with image_url + text content)
      - Supports `model` override: `effective_model = model or self._model`
    - Error handling: ProviderError for HTTP errors (401=invalid key, 429=rate limit, etc.), KeyError for bad response shape
    - Validates that `api_key` is non-empty — raises `ConfigError` if missing

  **Must NOT do**:
  - Do not add Ollama Cloud-specific features (model listing, account info, etc.)
  - Do not implement streaming
  - Do not copy the entire OpenAIProvider — keep the implementation focused on Ollama Cloud specifics

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
    - Reason: New file, but follows a well-established pattern (OpenAI-compatible)
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 2 (with Tasks 4, 6)
  - **Blocks**: Task 6
  - **Blocked By**: Tasks 1, 2

  **References**:
  **Pattern References**:
  - `src/vision_mcp/providers/openai.py:10-56` — OpenAI-compatible implementation. Ollama Cloud uses the SAME API structure. Copy the payload building pattern.
  - `src/vision_mcp/providers/base.py:7-22` — BaseVisionProvider interface.

  **API/Type References**:
  - `src/vision_mcp/config.py` (new OllamaCloudConfig from Task 1) — Config with `api_key` and `base_url` fields.

  **WHY Each Reference Matters**:
  - `openai.py:10-56` — Ollama Cloud's API is OpenAI-compatible — same endpoint, same auth pattern, same payload structure. Use this as the reference implementation.

  **Acceptance Criteria**:
  - [ ] `ollama_cloud.py` file created with OllamaCloudProvider class
  - [ ] POST to `{base_url}/chat/completions` with Bearer auth
  - [ ] Model override param works
  - [ ] ConfigError raised if `api_key` is empty
  - [ ] ProviderError on HTTP errors and bad responses
  - [ ] `name` property returns `ollama_cloud/{model}`

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: OllamaCloudProvider builds correct request
    Tool: Bash (python -c)
    Preconditions: OllamaCloudConfig with api_key="test-key", base_url="https://api.ollama.com/v1"
    Steps:
      1. Instantiate OllamaCloudProvider
      2. Mock httpx.AsyncClient
      3. Call query() with ImagePayload and prompt
      4. Assert POST goes to "https://api.ollama.com/v1/chat/completions"
      5. Assert header contains "Authorization: Bearer test-key"
      6. Assert payload has "model" and "messages" fields
    Expected Result: Correct OpenAI-compatible request to Ollama Cloud
    Failure Indicators: Wrong URL, missing auth, wrong payload
    Evidence: .sisyphus/evidence/task-5-ollama-cloud-request.txt

  Scenario: Missing API key raises ConfigError
    Tool: Bash (python -c)
    Preconditions: OllamaCloudConfig with api_key=""
    Steps:
      1. Instantiate OllamaCloudProvider with empty api_key
      2. Assert ConfigError is raised
    Expected Result: ConfigError with message about missing API key
    Failure Indicators: No error raised, or ProviderError instead of ConfigError
    Evidence: .sisyphus/evidence/task-5-missing-key-error.txt
  ```

  **Commit**: YES (groups with Tasks 4, 6)
  - Message: `feat(providers): add custom provider, ollama cloud, and factory rewrite`
  - Files: `src/vision_mcp/providers/ollama_cloud.py`

- [x] 6. Provider Factory Rewrite — Custom + OllamaCloud + Validation

  **What to do**:
  - Rewrite `src/vision_mcp/providers/__init__.py`:
    - Add import for `CustomProvider` and `OllamaCloudProvider`
    - Update `get_provider()`:
      - Add `elif name == "ollama_cloud": return OllamaCloudProvider(cfg, model)`
      - After checking all built-in names, check if `name` exists in `config.providers.custom_providers`
      - If yes: return `CustomProvider(config.providers.custom_providers[name], model)`
      - If no match: raise `ValueError` with message listing built-in providers + hint about custom_providers
    - Validate: if `name` is in `custom_providers` AND matches a built-in name, raise `ConfigError` (but this should already be caught in config loading from Task 1)

  **Must NOT do**:
  - Do not remove or rename existing provider imports
  - Do not change the `get_provider()` function signature
  - Do not add any caching or singleton patterns

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
    - Reason: Central routing logic — needs careful implementation
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES (within Wave 2, but depends on Tasks 4 and 5)
  - **Parallel Group**: Wave 2
  - **Blocks**: Tasks 7, 8, 9, 10
  - **Blocked By**: Tasks 4, 5 (needs CustomProvider and OllamaCloudProvider classes)

  **References**:
  **Pattern References**:
  - `src/vision_mcp/providers/__init__.py:1-27` — Current factory. Add `ollama_cloud` branch and custom_providers fallback.
  - `src/vision_mcp/config.py` (updated in Task 1) — `custom_providers` dict and `OllamaCloudConfig`

  **WHY Each Reference Matters**:
  - `__init__.py:15-27` — The if/elif chain to extend. Add ollama_cloud branch and the custom provider lookup after all built-in checks.

  **Acceptance Criteria**:
  - [ ] `get_provider("ollama_cloud", config)` returns OllamaCloudProvider
  - [ ] `get_provider("groq", config)` returns CustomProvider when "groq" is in custom_providers
  - [ ] Unknown provider name raises ValueError with helpful message
  - [ ] All existing provider names (ollama, openai, anthropic, zhipuai) still work

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: Custom provider name resolved from custom_providers
    Tool: Bash (python -c)
    Preconditions: Config with custom_providers.groq entry
    Steps:
      1. Create config with provider="groq" and custom_providers: {groq: {api_style: openai_compatible, ...}}
      2. Run get_provider(config)
      3. Assert result.name starts with "custom/"
    Expected Result: CustomProvider instance with name "custom/{model}"
    Failure Indicators: ValueError (unknown provider) or wrong provider type
    Evidence: .sisyphus/evidence/task-6-custom-from-factory.txt

  Scenario: ollama_cloud provider resolved
    Tool: Bash (python -c)
    Preconditions: Config with provider="ollama_cloud" and ollama_cloud.api_key set
    Steps:
      1. Create config with provider="ollama_cloud"
      2. Run get_provider(config)
      3. Assert result.name starts with "ollama_cloud/"
    Expected Result: OllamaCloudProvider instance
    Failure Indicators: ValueError or wrong type
    Evidence: .sisyphus/evidence/task-6-ollama-cloud-factory.txt

  Scenario: Unknown provider raises helpful ValueError
    Tool: Bash (python -c)
    Preconditions: Config with provider="nonexistent"
    Steps:
      1. Create config with provider="nonexistent"
      2. Call get_provider(config)
      3. Assert ValueError with message listing supported providers + custom hint
    Expected Result: ValueError raised
    Failure Indicators: No error or unhelpful error message
    Evidence: .sisyphus/evidence/task-6-unknown-provider.txt
  ```

  **Commit**: YES (groups with Tasks 4, 5)
  - Message: `feat(providers): add custom provider, ollama cloud, and factory rewrite`
  - Files: `src/vision_mcp/providers/__init__.py`

- [x] 7. Server.py Per-Tool Model Override Integration

  **What to do**:
  - Update `src/vision_mcp/server.py` to pass per-tool model to provider.query():
    - For each tool function (describe_image, extract_ui, ocr, analyze_diagram):
      - Read the tool's model override from `tools_cfg.<tool_name>.model`
      - Pass it to `provider.query(image, prompt, model=tool_model)` if set, otherwise omit the model arg
    - Implementation: `tool_model = getattr(tools_cfg, '<tool_name>').model; kwargs = {"model": tool_model} if tool_model else {}; await _run(provider.query(image, prompt, **kwargs))`
  - This is a small, safe change — each tool just conditionally passes the model override

  **Must NOT do**:
  - Do not create multiple provider instances
  - Do not add per-tool provider switching — model name only
  - Do not change tool signatures or add model parameters to the MCP tools themselves
  - Do not add complex logic — keep it simple: if model override exists, pass it

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Small mechanical change in server.py — 4 tool functions, same pattern
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 3 (with Tasks 8, 9)
  - **Blocks**: Task 10
  - **Blocked By**: Task 6 (factory must be updated first)

  **References**:
  **Pattern References**:
  - `src/vision_mcp/server.py:36-61` — describe_image tool. Line 61 calls `provider.query(image, prompt)`. Add model override here.
  - `src/vision_mcp/server.py:65-104` — extract_ui tool. Same pattern.
  - `src/vision_mcp/server.py:108-142` — ocr tool. Same pattern.
  - `src/vision_mcp/server.py:146-180` — analyze_diagram tool. Same pattern.

  **WHY Each Reference Matters**:
  - Each tool function's `provider.query()` call is the exact point where per-tool model needs to be injected. Read `tools_cfg.<tool>.model` and pass it.

  **Acceptance Criteria**:
  - [ ] All 4 tools pass `model` kwarg to `provider.query()` when tool config has `model` set
  - [ ] Tools omit `model` kwarg when tool config `model` is None (default)
  - [ ] No change to MCP tool signatures (users don't see a model parameter)

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: describe_image passes model override to provider
    Tool: Bash (python -c)
    Preconditions: Config with tools.describe_image.model = "gpt-4o"
    Steps:
      1. Load config, create provider
      2. Mock provider.query to capture the model argument
      3. Call describe_image function
      4. Assert provider.query was called with model="gpt-4o"
    Expected Result: Override model passed to provider
    Failure Indicators: model arg not passed or wrong value
    Evidence: .sisyphus/evidence/task-7-tool-model-override.txt

  Scenario: Tool without model override omits model arg
    Tool: Bash (python -c)
    Preconditions: Config with tools.ocr.model = None (default)
    Steps:
      1. Load config, create provider
      2. Mock provider.query
      3. Call ocr function
      4. Assert provider.query called without model kwarg (or model=None)
    Expected Result: No model override passed
    Failure Indicators: model kwarg present with non-None value
    Evidence: .sisyphus/evidence/task-7-no-model-override.txt
  ```

  **Commit**: YES (groups with Tasks 8, 9)
  - Message: `feat(server): per-tool model override + config examples + docs`
  - Files: `src/vision_mcp/server.py`

- [x] 8. Config.yaml Examples + Validation Enhancements

  **What to do**:
  - Update `config.yaml` with example sections for:
    - `ollama_cloud` provider under `providers:`
    - `custom_providers:` map with 2 example entries (one openai_compatible, one ollama style)
    - Per-tool `model:` fields in tools config
  - Add config validation in `load_config()` or `AppConfig`:
    - Warn (don't error) if custom provider `api_style` is not one of the supported values
    - Validate that `ollama_cloud.api_key` is set when `provider: ollama_cloud`

  **Must NOT do**:
  - Do not remove existing config entries
  - Do not make config validation overly strict — prefer warnings over hard errors for optional fields
  - Do not add validation that would break backward compat

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Config file update + small validation additions
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 3 (with Tasks 7, 9)
  - **Blocks**: Task 10
  - **Blocked By**: Task 6

  **References**:
  **Pattern References**:
  - `config.yaml:1-38` — Current config structure. Add new sections after existing content.
  - `src/vision_mcp/config.py` (updated in Task 1) — New fields that need example entries in config.yaml

  **Acceptance Criteria**:
  - [ ] config.yaml has `ollama_cloud:` section under `providers:`
  - [ ] config.yaml has `custom_providers:` map with example entries
  - [ ] config.yaml tool entries show `model:` field with comment
  - [ ] Validation: api_style must be "openai_compatible" or "ollama"
  - [ ] Existing config.yaml still loads correctly

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: New config.yaml loads successfully
    Tool: Bash (python -c)
    Preconditions: Updated config.yaml with all new sections
    Steps:
      1. Run: python -c "from vision_mcp.config import load_config; c = load_config(); print(c.providers.ollama_cloud, c.providers.custom_providers)"
      2. Assert no errors, new fields populated
    Expected Result: Config loads with new fields accessible
    Failure Indicators: ValidationError or AttributeError
    Evidence: .sisyphus/evidence/task-8-config-loads.txt
  ```

  **Commit**: YES (groups with Tasks 7, 9)
  - Message: `feat(server): per-tool model override + config examples + docs`
  - Files: `config.yaml`, `src/vision_mcp/config.py`

- [x] 9. README.md Documentation Update

  **What to do**:
  - Update `README.md` with new sections:
    1. **Ollama Cloud provider** section:
       - How to configure (api_key, base_url)
       - Example config.yaml entry
       - Supported models
    2. **Custom Providers** section:
       - How to define custom providers in config.yaml
       - Supported API styles (openai_compatible, ollama)
       - Example: adding Groq, vLLM, or LM Studio as custom provider
       - Name collision rule (can't use built-in names)
    3. **Per-tool model override** section:
       - How to set different models per tool
       - Example config showing describe_image with gpt-4o, ocr with llava
       - Fallback behavior (uses global model if not set)
    4. Update **Providers** section in Table of Contents
    5. Update **Configuration** section's "Full config reference" with new fields
    6. Update **Adding a new provider** section — note that for simple cases, users don't need to write code anymore (custom_providers covers it)

  **Must NOT do**:
  - Do not remove existing documentation
  - Do not add excessive examples — 1-2 per concept is enough
  - Do not write marketing copy — keep it technical and concise
  - Do not add excessive emoji

  **Recommended Agent Profile**:
  - **Category**: `writing`
    - Reason: Documentation task requiring clear technical writing
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 3 (with Tasks 7, 8)
  - **Blocks**: None
  - **Blocked By**: Task 6 (need to know final config structure)

  **References**:
  **Pattern References**:
  - `README.md:1-38` — Current README structure. Add new sections in the existing "Configuration" and "Providers" areas.
  - `README.md:95-136` — Current Providers section. Add Ollama Cloud and Custom Providers here.

  **Acceptance Criteria**:
  - [ ] Ollama Cloud provider documented with config example
  - [ ] Custom providers documented with API styles and examples
  - [ ] Per-tool model override documented with example
  - [ ] "Adding a new provider" section updated to mention config-driven approach
  - [ ] No existing documentation removed

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: README covers all new features
    Tool: Bash (grep)
    Preconditions: README.md updated
    Steps:
      1. grep -c "custom_providers" README.md — assert count > 0
      2. grep -c "ollama_cloud" README.md — assert count > 0
      3. grep -c "per-tool" README.md — assert count > 0
      4. grep -c "api_style" README.md — assert count > 0
    Expected Result: All new keywords present in README
    Failure Indicators: Zero count for any keyword
    Evidence: .sisyphus/evidence/task-9-readme-coverage.txt
  ```

  **Commit**: YES (groups with Tasks 7, 8)
  - Message: `feat(server): per-tool model override + config examples + docs`
  - Files: `README.md`

- [x] 10. pytest Test Suite

  **What to do**:
  - Set up pytest infrastructure:
    - Add `pytest` and `pytest-asyncio` to `pyproject.toml` dev dependencies
    - Create `tests/` directory with `__init__.py`
    - Create `conftest.py` with shared fixtures (sample ImagePayload, mock httpx client)
  - Write test files:
    - `tests/test_config.py`:
      - Test `CustomProviderConfig`, `OllamaCloudConfig` creation from dict
      - Test `ToolConfig` with `model` field
      - Test `custom_providers` dict in `ProvidersConfig`
      - Test `get_provider_config()` with custom provider name
      - Test name collision validation
      - Test backward compat: loading old config.yaml format
    - `tests/test_custom_provider.py`:
      - Test `openai_compatible` style payload construction
      - Test `ollama` style payload construction
      - Test model override
      - Test error handling (HTTP errors, bad responses)
    - `tests/test_ollama_cloud_provider.py`:
      - Test request construction (URL, headers, payload)
      - Test model override
      - Test missing API key validation
      - Test error handling
    - `tests/test_factory.py`:
      - Test `get_provider()` for all built-in names
      - Test `get_provider("ollama_cloud", ...)`
      - Test `get_provider()` with custom provider name
      - Test unknown provider name raises ValueError
    - `tests/test_server_model_override.py`:
      - Test that per-tool model override is passed to `provider.query()`
      - Test that default (None) model is handled correctly

  **Must NOT do**:
  - Do not write integration tests that require real API keys
  - Do not add test infrastructure for existing providers that hasn't changed
  - Do not over-mock — keep tests focused on the new code paths

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
    - Reason: Multiple test files, async patterns, fixtures setup — substantial test suite
  - **Skills**: [`context7`]
    - `context7`: May need pytest-asyncio docs for async test patterns

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Wave 4 (sequential — depends on all prior tasks)
  - **Blocks**: F1-F4
  - **Blocked By**: Tasks 7, 8

  **References**:
  **Pattern References**:
  - `src/vision_mcp/config.py` — Config models being tested
  - `src/vision_mcp/providers/custom.py` (from Task 4) — CustomProvider being tested
  - `src/vision_mcp/providers/ollama_cloud.py` (from Task 5) — OllamaCloudProvider being tested
  - `src/vision_mcp/providers/__init__.py` (from Task 6) — Factory being tested
  - `src/vision_mcp/server.py` (from Task 7) — Server model override being tested

  **Test References**:
  - `test_tools.py` — Existing test script. NOT pytest — but shows how the project currently tests (direct function calls). New tests should use pytest instead.

  **External References**:
  - pytest-asyncio: https://pytest-asyncio.readthedocs.io/ — For testing async providers

  **Acceptance Criteria**:
  - [ ] `pytest` runs and all tests pass
  - [ ] `pyproject.toml` has pytest + pytest-asyncio in dev dependencies
  - [ ] `tests/test_config.py` covers all new config fields
  - [ ] `tests/test_custom_provider.py` covers both API styles
  - [ ] `tests/test_ollama_cloud_provider.py` covers request building + errors
  - [ ] `tests/test_factory.py` covers all provider resolution paths
  - [ ] `tests/test_server_model_override.py` covers per-tool model passing

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: All tests pass
    Tool: Bash (pytest)
    Preconditions: Tests written, dependencies installed
    Steps:
      1. Run: pytest -v
      2. Assert all tests pass, output shows test names and results
    Expected Result: 0 failures, all tests reported as PASSED
    Failure Indicators: Any test failures
    Evidence: .sisyphus/evidence/task-10-pytest-results.txt

  Scenario: Test coverage is adequate
    Tool: Bash (pytest --co)
    Preconditions: Tests written
    Steps:
      1. Run: pytest --co -q
      2. Count test items — assert >= 15 tests across all test files
    Expected Result: At least 15 test cases covering new functionality
    Failure Indicators: Fewer than 15 tests (insufficient coverage)
    Evidence: .sisyphus/evidence/task-10-test-count.txt
  ```

  **Commit**: YES
  - Message: `test: add pytest suite for custom provider, ollama cloud, and per-tool model override`
  - Files: `tests/`, `pyproject.toml`
  - Pre-commit: `pytest`

---

## Final Verification Wave (MANDATORY — after ALL implementation tasks)

> 4 review agents run in PARALLEL. ALL must APPROVE. Present consolidated results to user and get explicit "okay" before completing.

- [x] F1. **Plan Compliance Audit** — `oracle`
  Read the plan end-to-end. For each "Must Have": verify implementation exists (read file, run command). For each "Must NOT Have": search codebase for forbidden patterns — reject with file:line if found. Check evidence files exist in .sisyphus/evidence/. Compare deliverables against plan.
  Output: `Must Have [N/N] | Must NOT Have [N/N] | Tasks [N/N] | VERDICT: APPROVE/REJECT`

- [x] F2. **Code Quality Review** — `unspecified-high`
  Run `ruff check` + `pytest`. Review all changed files for: bare except, unused imports, AI slop (excessive comments, over-abstraction, generic names). Check backward compat: existing config format still loads.
  Output: `Lint [PASS/FAIL] | Tests [N pass/N fail] | Files [N clean/N issues] | VERDICT`

- [x] F3. **Real Manual QA** — `unspecified-high`
  Start from clean state. Execute EVERY QA scenario from EVERY task. Test integration: custom provider end-to-end, ollama_cloud config, per-tool model override for each tool. Test backward compat: old config.yaml without custom_providers works. Save evidence to `.sisyphus/evidence/final-qa/`.
  Output: `Scenarios [N/N pass] | Integration [N/N] | Edge Cases [N tested] | VERDICT`

- [x] F4. **Scope Fidelity Check** — `deep`
  For each task: read "What to do", read actual diff. Verify 1:1 — everything in spec was built, nothing beyond spec. Check "Must NOT do" compliance. Detect scope creep.
  Output: `Tasks [N/N compliant] | Contamination [CLEAN/N issues] | Unaccounted [CLEAN/N files] | VERDICT`

---

## Commit Strategy

- **Wave 1**: `feat(config): add custom provider, ollama cloud, and per-tool model config models` — config.py, base.py, ollama.py, openai.py, anthropic.py, zhipuai.py
- **Wave 2**: `feat(providers): add custom provider, ollama cloud, and factory rewrite` — custom.py, ollama_cloud.py, __init__.py
- **Wave 3**: `feat(server): per-tool model override + config examples + docs` — server.py, config.yaml, README.md
- **Wave 4**: `test: add pytest suite for new features` — tests/

---

## Success Criteria

### Verification Commands
```bash
# Config loads with custom provider
python -c "from vision_mcp.config import load_config; c = load_config(); print(c.custom_providers)"  # Expected: dict with custom entries

# Custom provider instantiates
python -c "from vision_mcp.config import load_config; from vision_mcp.providers import get_provider; p = get_provider(load_config()); print(p.name)"  # Expected: custom/<name>

# Per-tool model override
python -c "from vision_mcp.config import load_config; c = load_config(); print(c.tools.describe_image.model)"  # Expected: override model or None

# Tests pass
pytest  # Expected: all pass
```

### Final Checklist
- [ ] All "Must Have" present
- [ ] All "Must NOT Have" absent
- [ ] All tests pass
- [ ] Backward compatible — old config.yaml works unchanged
- [ ] README documents custom providers, Ollama Cloud, per-tool model