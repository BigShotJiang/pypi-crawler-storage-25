# Learnings - Custom Providers, Ollama Cloud & Per-Tool Model Override

## Key Discovery: Pydantic Extra Fields Bug
- Custom provider YAML like `providers.groq: {...}` does NOT automatically populate `custom_providers` dict
- Pydantic silently drops unknown fields when extra="forbid" (default)
- Fix: Use `ConfigDict(extra="allow")` on `ProvidersConfig` + `model_validator(mode="after")` that reads `__pydantic_extra__` and routes unknown keys into `custom_providers`
- This was the most important discovery — the plan's original design didn't account for Pydantic's field filtering behavior

## Bug: get_provider_config() Ollama Cloud Fallthrough
- When `provider='ollama_cloud'` but no `ollama_cloud:` section in config, the method fell through to `getattr(self.providers, "ollama")` fallback
- This returned wrong type (`OllamaConfig` instead of `OllamaCloudConfig`)
- Fix: Add explicit `elif self.provider == "ollama_cloud"` branch before the fallback

## Per-Tool Model Override Design
- Model-only (not provider), implemented via optional keyword-only `model` param on `BaseVisionProvider.query()`
- Single provider instance preserved — each tool just passes different model name
- Pattern: `effective_model = model or self._model`

## Test Coverage
- 93 tests across 6 files covering all new functionality
- All edge cases covered including error handling, backward compat, name collision

## 2 Contamination Issues from F4 (Minor - UX enhancements)
1. `extra="allow"` + auto-merge validator is a UX enhancement beyond spec (allows `providers.groq:` syntax)
2. README documents `provider: custom_providers.my_vllm` but code also accepts bare `provider: my_vllm` — neither is breaking
