"""
Quick test script — call vision tools directly without an MCP client.

Usage:
    python test_tools.py describe <image_source>
    python test_tools.py ocr <image_source>
    python test_tools.py extract_ui <image_source>
    python test_tools.py analyze_diagram <image_source>

<image_source> can be a file path, URL, or base64 string.

Examples:
    python test_tools.py describe ./screenshot.png
    python test_tools.py ocr https://example.com/form.png
    python test_tools.py describe ./ui.jpg --focus "buttons and navigation"
    python test_tools.py extract_ui ./figma-export.png --format markdown
"""
from __future__ import annotations
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))

from vision_mcp.config import load_config
from vision_mcp.image import load_image
from vision_mcp.providers import get_provider
from vision_mcp.errors import VisionMCPError


PROMPTS = {
    "describe": (
        "Provide a thorough, detailed description of everything visible in this image."
    ),
    "ocr": (
        "Extract all text from this image exactly as it appears. "
        "Preserve line breaks and formatting. Return only the text, nothing else."
    ),
    "extract_ui": (
        'Analyze this UI screenshot and return ONLY valid JSON (no markdown fences):\n'
        '{\n'
        '  "layout": "...",\n'
        '  "components": [{"type": "...", "label": "...", "position": "...", "notes": "..."}],\n'
        '  "color_palette": ["#hex"],\n'
        '  "typography": "..."\n'
        '}'
    ),
    "analyze_diagram": (
        'Analyze this diagram and return ONLY valid JSON (no markdown fences):\n'
        '{\n'
        '  "diagram_type": "...",\n'
        '  "summary": "...",\n'
        '  "nodes": [{"id": "...", "label": "..."}],\n'
        '  "edges": [{"from": "...", "to": "...", "label": "..."}]\n'
        '}'
    ),
}


async def run_test(tool: str, source: str, focus: str = "", fmt: str = "") -> None:
    config = load_config()
    provider = get_provider(config)

    print(f"\n{'─' * 60}")
    print(f"  Provider : {provider.name}")
    print(f"  Tool     : {tool}")
    print(f"  Source   : {source[:80]}")
    if focus:
        print(f"  Focus    : {focus}")
    if fmt:
        print(f"  Format   : {fmt}")
    print(f"{'─' * 60}\n")

    try:
        image = load_image(source)
        print(f"  Image loaded — {image.mime_type}, {len(image.data)} base64 chars\n")
    except VisionMCPError as e:
        print(f"  ✗ Image load failed: {e}")
        return

    prompt = PROMPTS.get(tool, "Describe this image.")

    # Apply optional modifiers
    if focus:
        prompt += f"\n\nFocus on: {focus}"
    if fmt and tool == "extract_ui":
        if fmt == "markdown":
            prompt = (
                "Analyze this UI screenshot. List all visible components in markdown:\n"
                "- Group by section (header, main, footer, etc.)\n"
                "- For each: type, label, position, notable states\n"
                "- Note color scheme and typography at the end."
            )

    print("  Querying vision model...\n")
    try:
        result = await provider.query(image, prompt)
        print("  Result:\n")
        print(result)
    except VisionMCPError as e:
        print(f"  ✗ Provider error: {e}")


def main() -> None:
    args = sys.argv[1:]
    if len(args) < 2:
        print(__doc__)
        sys.exit(1)

    tool = args[0]
    source = args[1]
    focus = ""
    fmt = ""

    if "--focus" in args:
        idx = args.index("--focus")
        if idx + 1 < len(args):
            focus = args[idx + 1]

    if "--format" in args:
        idx = args.index("--format")
        if idx + 1 < len(args):
            fmt = args[idx + 1]

    if tool not in PROMPTS:
        print(f"Unknown tool '{tool}'. Choose from: {', '.join(PROMPTS)}")
        sys.exit(1)

    asyncio.run(run_test(tool, source, focus, fmt))


if __name__ == "__main__":
    main()
