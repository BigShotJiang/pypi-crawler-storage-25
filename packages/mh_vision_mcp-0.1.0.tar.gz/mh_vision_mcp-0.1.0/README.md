# mh-vision-mcp

Give any non-vision model the ability to see by delegating image tasks to a
configurable vision model provider over the
[Model Context Protocol (MCP)](https://modelcontextprotocol.io).

When an AI coding assistant (Claude Code, OpenCode, Cursor, etc.) needs to
read a screenshot, extract text, or analyze a diagram, it calls one of the
four tools exposed by this server. The server normalizes the image, forwards
it to whichever vision model you configure, and returns the result as a
string — all transparent to the caller.

---

## Table of contents

- [How it works](#how-it-works)
- [Requirements](#requirements)
- [Installation](#installation)
- [Configuration](#configuration)
  - [Providers](#providers)
  - [Tools](#tools)
- [MCP client setup](#mcp-client-setup)
- [Tools reference](#tools-reference)
  - [describe\_image](#describe_image)
  - [extract\_ui](#extract_ui)
  - [ocr](#ocr)
  - [analyze\_diagram](#analyze_diagram)
- [Image source formats](#image-source-formats)
- [Testing without an MCP client](#testing-without-an-mcp-client)
- [Architecture](#architecture)
- [Adding a new provider](#adding-a-new-provider)
- [Error handling](#error-handling)
- [Development](#development)

---

## How it works

```
MCP client (Claude Code, etc.)
        │
        │  calls tool(source, ...)
        ▼
  server.py  ──► load_image(source)  ──► ImagePayload(base64, mime)
        │
        ▼
  provider.query(image, prompt)
        │
        ├── OllamaProvider    → POST /api/generate
        ├── OpenAIProvider    → POST /v1/chat/completions
        ├── AnthropicProvider → POST /v1/messages
        └── ZhipuAIProvider   → POST /v4/chat/completions
        │
        ▼
  string result  ──► MCP client
```

Tools are only registered at startup if `enabled: true` in `config.yaml`.
Disabled tools genuinely don't exist in the server — the `@mcp.tool()`
decorator never fires for them.

---

## Requirements

- Python 3.12+
- One of the supported vision backends (see [Providers](#providers))

---

## Installation

### Option A — editable install (development)

```bash
cd ~/my-projects/vision-mcp
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

### Option B — run directly with uvx (no venv needed)

```bash
uvx mh-vision-mcp
```

---

## Configuration

`mh-vision-mcp` reads `config.yaml` from the current directory by default.
Override the path with the `VISION_MCP_CONFIG` environment variable:

```bash
VISION_MCP_CONFIG=/absolute/path/to/config.yaml mh-vision-mcp
```

If no config file is found, all settings fall back to defaults
(`ollama` provider, `llava:latest` model, all tools enabled).

### Full config reference

```yaml
# Active provider — one of: ollama, openai, anthropic, zhipuai
provider: ollama

# Model name passed to the active provider
model: llava:latest

providers:
  ollama:
    base_url: http://localhost:11434      # default

  openai:
    api_key: YOUR_OPENAI_API_KEY
    base_url: https://api.openai.com/v1  # override for vLLM / LM Studio

  anthropic:
    api_key: YOUR_ANTHROPIC_API_KEY

  zhipuai:
    api_key: YOUR_ZHIPUAI_API_KEY
    base_url: https://open.bigmodel.cn/api/paas/v4  # default

  ollama_cloud:
    api_key: YOUR_OLLAMA_CLOUD_API_KEY
    base_url: https://api.ollama.com/v1  # default

  custom_providers:
    my_provider:
      api_style: openai_compatible  # or "ollama"
      base_url: http://localhost:8000/v1
      api_key: ""
      model: ""

tools:
  describe_image:
    enabled: true
    default_detail: high    # high | low

  extract_ui:
    enabled: true
    output_format: json     # json | markdown

  ocr:
    enabled: true
    output_format: plain    # plain | structured

  analyze_diagram:
    enabled: true
```

### Providers

#### Ollama (local, default)

Run a vision model locally — no API key required.

```bash
ollama pull llava:latest   # or llava:13b, llava:34b, moondream, bakllava
ollama serve               # starts on http://localhost:11434
```

```yaml
provider: ollama
model: llava:latest
providers:
  ollama:
    base_url: http://localhost:11434
```

Supported models: any Ollama model with vision capability (`llava`, `llava:13b`,
`llava:34b`, `moondream`, `bakllava`, etc.).

#### OpenAI

```yaml
provider: openai
model: gpt-4o
providers:
  openai:
    api_key: sk-...
    base_url: https://api.openai.com/v1
```

Also works with any OpenAI-compatible API (vLLM, LM Studio, Together AI):
just change `base_url`.

Supported models: `gpt-4o`, `gpt-4o-mini`, and any OpenAI-compatible vision model.

#### Anthropic

```yaml
provider: anthropic
model: claude-opus-4-6
providers:
  anthropic:
    api_key: sk-ant-...
```

Supported models: `claude-opus-4-6`, `claude-sonnet-4-6`, `claude-haiku-4-5`,
and any Claude model with vision support.

#### ZhipuAI

```yaml
provider: zhipuai
model: glm-4v-flash
providers:
  zhipuai:
    api_key: YOUR_KEY
    base_url: https://open.bigmodel.cn/api/paas/v4
```

Supported models: `glm-4v`, `glm-4v-plus`, `glm-4v-flash`.

#### Ollama Cloud

Managed hosted Ollama service. Get your API key at [ollama.com](https://ollama.com).

```yaml
provider: ollama_cloud
model: llava:latest
providers:
  ollama_cloud:
    api_key: oc_...
    base_url: https://api.ollama.com/v1
```

#### Custom Providers

Define additional providers without code changes using `custom_providers`. Supports two API styles:

| `api_style` | Description |
|-------------|-------------|
| `openai_compatible` | OpenAI-compatible endpoints (vLLM, LM Studio, etc.) |
| `ollama` | Ollama-style endpoints (custom Ollama-like servers) |

```yaml
providers:
  custom_providers:
    my_vllm:
      api_style: openai_compatible
      base_url: http://localhost:8000/v1
      api_key: ""
      model: vision-model-1

    my_custom_vision:
      api_style: ollama
      base_url: http://localhost:11434
      api_key: ""
      model: ""
```

Then reference them with: `provider: custom_providers.my_vllm`

### Per-tool model override

Each tool can use a different model by setting the optional `model` field:

```yaml
tools:
  describe_image:
    enabled: true
    model: llava:latest      # override global model

  extract_ui:
    enabled: true
    model: gpt-4o-mini       # different model for UI extraction

  ocr:
    enabled: true
    model: moondream         # optimized for text

  analyze_diagram:
    enabled: true
    # uses global model if not specified
```

---

## MCP client setup

### Claude Code / `.mcp.json` (project-level)

```json
{
  "mcpServers": {
    "vision": {
      "command": "mh-vision-mcp",
      "env": {
        "VISION_MCP_CONFIG": "/absolute/path/to/mh-vision-mcp/config.yaml"
      }
    }
  }
}
```

### With uvx (no install required)

```json
{
  "mcpServers": {
    "vision": {
      "command": "uvx",
      "args": ["mh-vision-mcp"],
      "env": {
        "VISION_MCP_CONFIG": "/absolute/path/to/config.yaml"
      },
      "type": "stdio"
    }
  }
}
```

### Claude Desktop (`claude_desktop_config.json`)

```json
{
  "mcpServers": {
    "vision": {
      "command": "/path/to/.venv/bin/mh-vision-mcp",
      "env": {
        "VISION_MCP_CONFIG": "/absolute/path/to/config.yaml"
      }
    }
  }
}
```

---

## Tools reference

All tools accept an image `source` as their first argument. See
[Image source formats](#image-source-formats) for what's accepted.

### `describe_image`

Describe what's visible in an image using the configured vision model.

| Argument | Type   | Default  | Description |
|----------|--------|----------|-------------|
| `source` | string | required | Image source (path, URL, base64, data URI) |
| `detail` | string | `"high"` | `"high"` — thorough description; `"low"` — brief summary |
| `focus`  | string | `""`     | Optional instruction, e.g. `"focus on text content"` |

**Example (from an AI assistant):**
```
describe_image(source="./screenshot.png", detail="high", focus="buttons and navigation")
```

### `extract_ui`

Decompose a UI screenshot or design file into its component parts.

| Argument        | Type   | Default  | Description |
|-----------------|--------|----------|-------------|
| `source`        | string | required | Image source |
| `output_format` | string | `"json"` | `"json"` — structured data; `"markdown"` — readable list |

**JSON output shape:**
```json
{
  "layout": "description of the overall layout",
  "components": [
    {
      "type": "button|input|text|image|icon|nav|card|modal|...",
      "label": "visible text or aria label",
      "position": "top-left|center|bottom-right|...",
      "state": "default|hover|active|disabled|...",
      "notes": "any relevant details"
    }
  ],
  "color_palette": ["#hex1", "#hex2"],
  "typography": "brief note on fonts/sizes used",
  "accessibility_notes": "any obvious accessibility observations"
}
```

### `ocr`

Extract text from an image using the vision model as an OCR engine.

| Argument        | Type   | Default    | Description |
|-----------------|--------|------------|-------------|
| `source`        | string | required   | Image source |
| `output_format` | string | `"plain"`  | `"plain"` — raw text; `"structured"` — JSON with regions |
| `language_hint` | string | `""`       | Optional hint, e.g. `"Arabic"`, `"Chinese"` |

**Structured JSON output shape:**
```json
{
  "full_text": "all text concatenated in reading order",
  "regions": [
    {
      "text": "text in this region",
      "region": "top-left|middle-center|bottom-right|...",
      "style": "heading|body|caption|label|code|..."
    }
  ]
}
```

### `analyze_diagram`

Parse a flowchart, ERD, sequence diagram, architecture drawing, or any
technical chart into structured data.

| Argument       | Type   | Default   | Description |
|----------------|--------|-----------|-------------|
| `source`       | string | required  | Image source |
| `diagram_type` | string | `"auto"`  | Type hint: `"auto"`, `"flowchart"`, `"erd"`, `"sequence"`, `"chart"`, `"architecture"`, `"wireframe"`, `"mindmap"` |

**JSON output shape:**
```json
{
  "diagram_type": "detected type",
  "title": "diagram title if present",
  "summary": "one sentence describing what this diagram shows",
  "nodes": [
    {"id": "A", "label": "label text", "type": "process|decision|data|..."}
  ],
  "edges": [
    {"from": "A", "to": "B", "label": "edge label if any"}
  ],
  "notes": "any legends, annotations, or important details"
}
```

---

## Image source formats

`load_image()` accepts any of the following and normalizes them to
`ImagePayload(data: str, mime_type: str)` where `data` is always base64-encoded.

| Format | Example |
|--------|---------|
| Local file path | `./screenshot.png`, `/home/user/img.jpg` |
| HTTP/S URL | `https://example.com/diagram.png` |
| Data URI | `data:image/png;base64,iVBOR...` |
| Raw base64 | `iVBORw0KGgo...` (assumed `image/jpeg`) |

Supported file extensions: `.jpg`, `.jpeg`, `.png`, `.gif`, `.webp`.
URLs are fetched with a 30-second timeout and follow redirects.

---

## Testing without an MCP client

`test_tools.py` lets you call the vision pipeline directly from the command
line without needing a running MCP client.

```bash
source .venv/bin/activate

# Describe an image
python test_tools.py describe ./screenshot.png

# Focus on specific elements
python test_tools.py describe ./ui.jpg --focus "buttons and navigation"

# OCR
python test_tools.py ocr ./form.png

# Extract UI components as JSON
python test_tools.py extract_ui ./design.png

# Extract UI components as markdown
python test_tools.py extract_ui ./design.png --format markdown

# Analyze a diagram
python test_tools.py analyze_diagram ./flowchart.png

# Works with URLs too
python test_tools.py ocr https://example.com/invoice.png
```

---

## Architecture

```
src/vision_mcp/
├── server.py          # Entry point — loads config, registers MCP tools
├── config.py          # Pydantic config models + YAML loader
├── image.py           # load_image() — normalizes any source to ImagePayload
├── errors.py          # Exception hierarchy
└── providers/
    ├── base.py        # BaseVisionProvider ABC — one method: query()
    ├── __init__.py    # get_provider() factory
    ├── ollama.py      # Local Ollama via /api/generate
    ├── openai.py      # OpenAI-compatible via /chat/completions
    ├── anthropic.py   # Anthropic Claude via /v1/messages
    └── zhipuai.py     # ZhipuAI GLM-4V via /chat/completions
```

### Key design decisions

**Conditional tool registration** — Tools are registered inside `if tools_cfg.<name>.enabled:` blocks at module load time. A disabled tool never appears in the MCP server's tool list at all; it isn't just hidden or rejected at call time.

**Provider abstraction** — `BaseVisionProvider` has a single contract: `async query(image: ImagePayload, prompt: str) → str`. Adding a new backend requires implementing only this one method and a `name` property.

**Error isolation** — The `_run()` coroutine wrapper in `server.py` catches all `VisionMCPError` subclasses and unexpected exceptions and returns them as prefixed strings (`[mh-vision-mcp error] ...`). The MCP caller always receives a string, never a crash.

**Image normalization** — `load_image()` resolves the source format in priority order: data URI → HTTP/S URL → local file path → raw base64. Every provider always receives base64-encoded bytes regardless of the original source format.

---

## Adding a new provider

### Option A: Config-driven (recommended for OpenAI/Ollama-compatible APIs)

If your provider supports OpenAI-compatible or Ollama-style endpoints, use
`custom_providers` in `config.yaml` without any code changes:

```yaml
providers:
  custom_providers:
    my_provider:
      api_style: openai_compatible  # or "ollama"
      base_url: http://localhost:8000/v1
      api_key: ""
      model: ""  # optional per-provider default
```

### Option B: Code-driven (for custom API formats)

For providers with unique API formats, implement a new provider:

1. **Create the provider** — `src/vision_mcp/providers/myprovider.py`:

```python
from ..image import ImagePayload
from .base import BaseVisionProvider
from ..errors import ProviderError

class MyProvider(BaseVisionProvider):
    def __init__(self, cfg, model: str):
        self._model = model
        # store whatever you need from cfg

    @property
    def name(self) -> str:
        return f"myprovider/{self._model}"

    async def query(self, image: ImagePayload, prompt: str) -> str:
        # Call your API, return a string response
        ...
```

2. **Add a config model** — in `config.py`:

```python
class MyProviderConfig(BaseModel):
    api_key: str = ""
    base_url: str = "https://api.example.com"
```

3. **Register it in `ProvidersConfig`** — in `config.py`:

```python
class ProvidersConfig(BaseModel):
    ...
    myprovider: MyProviderConfig = Field(default_factory=MyProviderConfig)
```

4. **Wire up the factory** — in `providers/__init__.py`:

```python
from .myprovider import MyProvider

def get_provider(config: AppConfig) -> BaseVisionProvider:
    ...
    elif name == "myprovider":
        return MyProvider(cfg, model)
```

5. **Add to `config.yaml`**:

```yaml
provider: myprovider
model: my-vision-model
providers:
  myprovider:
    api_key: YOUR_KEY
    base_url: https://api.example.com
```

---

## Error handling

| Exception | Meaning |
|-----------|---------|
| `VisionMCPError` | Base class — all errors have a user-readable message |
| `ImageLoadError` | Failed to load or decode the image from the given source |
| `ProviderError` | The vision API returned an error or unexpected response shape |
| `ConfigError` | Something is wrong with `config.yaml` |

All errors are caught by `_run()` in `server.py` and returned as strings to
the MCP caller with a `[vision-mcp error]` prefix. The server never crashes
on provider or image load failures.

---

## Development

```bash
# Install in editable mode
pip install -e .

# Lint
ruff check

# Tests
pytest

# Run the server directly (stdio transport)
mh-vision-mcp

# Run with a specific config
VISION_MCP_CONFIG=./config.yaml mh-vision-mcp
```
