"""
分页工具模块
提供自动分页获取所有数据的功能
"""
import logging
from typing import List, Callable, Optional, TypeVar, Generic
from ..models.response import QingflowResponse, QingflowPageResponse
from ..models.request import PageRequest

logger = logging.getLogger(__name__)

T = TypeVar("T")
P = TypeVar("P", bound=PageRequest)


class PaginationHelper:
    """分页辅助工具"""
    
    @staticmethod
    def loop_get_all_data(
        page_size: int,
        fetch_func: Callable[[PageRequest], QingflowResponse[QingflowPageResponse[T]]],
        initial_page: Optional[PageRequest] = None
    ) -> List[T]:
        """
        循环调用分页接口，获取所有数据
        
        Args:
            page_size: 每页大小
            fetch_func: 分页获取函数
            initial_page: 初始分页参数
            
        Returns:
            所有数据列表
        """
        page = initial_page or PageRequest(page_num=1, page_size=page_size)
        all_results = []
        
        while True:
            logger.debug(f"获取第 {page.page_num} 页，每页 {page.page_size} 条")
            response = fetch_func(page)
            response.raise_for_error()
            
            page_response = response.result
            if not page_response:
                break
            
            all_results.extend(page_response.result)
            
            # 判断是否还有下一页
            if page.page_num >= page_response.page_amount:
                break
            
            page.page_num += 1
        
        logger.info(f"分页获取完成，共 {len(all_results)} 条数据")
        return all_results
    
    @staticmethod
    async def async_loop_get_all_data(
        page_size: int,
        fetch_func: Callable[[PageRequest], "QingflowResponse[QingflowPageResponse[T]]"],
        initial_page: Optional[PageRequest] = None
    ) -> List[T]:
        """
        异步循环调用分页接口，获取所有数据
        """
        page = initial_page or PageRequest(page_num=1, page_size=page_size)
        all_results = []
        
        while True:
            logger.debug(f"获取第 {page.page_num} 页，每页 {page.page_size} 条")
            response = await fetch_func(page)
            response.raise_for_error()
            
            page_response = response.result
            if not page_response:
                break
            
            all_results.extend(page_response.result)
            
            if page.page_num >= page_response.page_amount:
                break
            
            page.page_num += 1
        
        logger.info(f"异步分页获取完成，共 {len(all_results)} 条数据")
        return all_results
