"""
响应模型模块
定义所有 API 响应数据
"""
from __future__ import annotations
from pydantic import Field
from typing import Optional, List, Generic, TypeVar, Any
from .base import QingflowModel, AnswerDTO

# 前向引用，避免循环导入
from .request import UserDTO, DeptDTO, RoleDTO  # noqa: F401, E402


# 泛型类型变量
T = TypeVar("T")


class QingflowResponse(QingflowModel, Generic[T]):
    """标准响应"""
    
    err_code: Optional[int] = Field(
        default=0,
        description="错误码，0 表示成功"
    )
    err_msg: Optional[str] = Field(
        default="",
        description="错误信息"
    )
    result: Optional[T] = Field(
        default=None,
        description="响应数据"
    )
    details: Optional[Any] = Field(
        default=None,
        description="详细信息"
    )
    question_relations: Optional[List] = Field(
        default=None,
        description="字段关系"
    )
    
    @property
    def is_success(self) -> bool:
        """是否成功"""
        return self.err_code is not None and self.err_code == 0
    
    def raise_for_error(self) -> None:
        """如果失败则抛出异常"""
        if not self.is_success:
            from ..exceptions import create_error_from_response
            raise create_error_from_response(
                err_code=self.err_code or -1,
                err_msg=self.err_msg or "未知错误",
                details=self.details
            )


class QingflowPageResponse(QingflowModel, Generic[T]):
    """分页响应"""
    
    page_num: int = Field(
        description="当前页码"
    )
    page_size: int = Field(
        description="每页条数"
    )
    result_amount: int = Field(
        description="总记录数"
    )
    page_amount: int = Field(
        description="总页数"
    )
    result: List[T] = Field(
        description="数据列表"
    )


# ==================== 应用模块响应 ====================

class GetAccessTokenResponse(QingflowModel):
    """获取 Access Token 响应"""
    
    access_token: str = Field(
        description="访问令牌"
    )
    expire_time: int = Field(
        description="过期时间（秒）"
    )


class GetAppDataResponse(QingflowModel):
    """获取应用数据响应"""
    
    apply_id: Optional[int] = Field(
        default=None,
        description="数据 ID（整数）"
    )
    apply_id_string: Optional[str] = Field(
        default=None,
        description="数据 ID（字符串）"
    )
    answers: Optional[List[AnswerDTO]] = Field(
        default=None,
        description="字段答案列表"
    )


class AddAppDataResponse(QingflowModel):
    """添加应用数据响应"""
    
    request_id: str = Field(
        description="请求 ID"
    )
    apply_id: Optional[str] = Field(
        default=None,
        description="数据 ID"
    )


class UpdateAppDataResponse(QingflowModel):
    """更新应用数据响应"""
    
    apply_id: Optional[str] = Field(
        default=None,
        description="数据 ID"
    )
    apply_ids: Optional[List[str]] = Field(
        default=None,
        description="数据 ID 列表"
    )
    request_id: str = Field(
        description="请求 ID"
    )


class DeleteAppDataResponse(QingflowModel):
    """删除应用数据响应"""
    
    request_id: str = Field(
        description="请求 ID"
    )


class AuditRecordResponse(QingflowModel):
    """流程日志响应"""
    
    class AuditUser(QingflowModel):
        """审计用户"""
        user_id: Optional[str] = None
        display_name: Optional[str] = None
        email: Optional[str] = None
        mobile_num: Optional[str] = None
        head_img: Optional[str] = None
        nick_name: Optional[str] = None
        platform: Optional[str] = None
        que_id: Optional[str] = None
        que_title: Optional[str] = None
        remark: Optional[str] = None
        status: Optional[bool] = None
        type: Optional[int] = None
        uid: Optional[int] = None
        user_representation: Optional[str] = None
        wechat_head_img: Optional[str] = None
        wechat_name: Optional[str] = None
        finish_audit: Optional[bool] = None
    
    class AuditRecord(QingflowModel):
        """审计记录"""
        audit_node_id: Optional[int] = None
        audit_node_name: Optional[str] = None
        audit_time: Optional[int] = None
        audit_result: Optional[str] = None
        audit_feedback: Optional[str] = None
        audit_user: Optional["AuditRecordResponse.AuditUser"] = None
        wait_audit_user_list: Optional[List["AuditRecordResponse.AuditUser"]] = None
        audit_rcd_id: Optional[int] = None
    
    class CurrentNode(QingflowModel):
        """当前节点"""
        audit_node_id: Optional[int] = None
        audit_node_name: Optional[str] = None
        audit_time: Optional[int] = None
        audit_result: Optional[str] = None
        audit_feedback: Optional[str] = None
        audit_user: Optional["AuditRecordResponse.AuditUser"] = None
        wait_audit_user_list: Optional[List["AuditRecordResponse.AuditUser"]] = None
        audit_rcd_id: Optional[int] = None
    
    apply_status: Optional[int] = Field(
        default=None,
        description="应用状态"
    )
    audit_records: Optional[List[AuditRecord]] = Field(
        default=None,
        description="审计记录列表"
    )
    current_nodes: Optional[List[CurrentNode]] = Field(
        default=None,
        description="当前节点列表"
    )
    
    def get_current_audit_node_ids(self) -> List[int]:
        """获取当前节点的节点 ID 列表"""
        if not self.current_nodes:
            return []
        return [node.audit_node_id for node in self.current_nodes if node.audit_node_id]


class ReassinResponse(QingflowModel):
    """重新指派响应"""
    
    request_id: str = Field(
        description="请求 ID"
    )


class GetAppListResponse(QingflowModel):
    """获取应用列表响应"""
    
    class Authmember(QingflowModel):
        """权限成员"""
        class Role(QingflowModel):
            role_id: Optional[int] = None
            role_name: Optional[str] = None
        
        class User(QingflowModel):
            user_id: Optional[str] = None
            user_name: Optional[str] = None
        
        class Dept(QingflowModel):
            dept_id: Optional[int] = None
            dept_name: Optional[str] = None
        
        roles: Optional[List[Role]] = None
        users: Optional[List[User]] = None
        depts: Optional[List[Dept]] = None
    
    class Creator(QingflowModel):
        user_id: Optional[str] = None
        display_name: Optional[str] = None
    
    class Tag(QingflowModel):
        tag_id: Optional[int] = None
        tag_name: Optional[str] = None
    
    app_icon: Optional[str] = None
    app_name: Optional[str] = None
    app_key: Optional[str] = None
    app_publish_status: Optional[int] = None
    app_auth: Optional[int] = None
    create_time: Optional[str] = None
    creator: Optional[Creator] = None
    authmembers: Optional[Authmember] = None
    tags: Optional[List[Tag]] = None


class GetAllAppInfoResponse(QingflowModel):
    """获取所有应用信息响应"""
    
    apps: Optional[List[GetAppListResponse]] = None


class GetDashInfoResponse(QingflowModel):
    """获取门户信息响应"""
    
    dash_id: Optional[int] = None
    dash_key: Optional[str] = None
    dash_name: Optional[str] = None
    dash_icon: Optional[str] = None
    create_time: Optional[str] = None


class GetTagListResponse(QingflowModel):
    """获取应用包列表响应"""
    
    tag_id: Optional[int] = None
    tag_name: Optional[str] = None
    app_keys: Optional[List[str]] = None


class GetTemplateResponse(QingflowModel):
    """获取打印模板响应"""
    
    template_url: Optional[str] = None
    template_content: Optional[str] = None


# ==================== 环境模块响应 ====================

class GetAdminAccessTokenResponse(QingflowModel):
    """获取环境级 Token 响应"""
    
    admin_access_token: str = Field(
        description="环境级访问令牌"
    )
    expire_time: int = Field(
        description="过期时间（秒）"
    )


class CreateUserResponse(QingflowModel):
    """创建用户响应"""
    
    open_user_id: str = Field(
        description="开放用户 ID"
    )


class GetUserIdInfoResponse(QingflowModel):
    """获取用户信息响应"""
    
    class WsInfo(QingflowModel):
        ws_id: Optional[str] = None
        ws_name: Optional[str] = None
        role: Optional[str] = None
    
    class IdInfo(QingflowModel):
        user_id: Optional[str] = None
        open_user_id: Optional[str] = None
        workspace_infos: Optional[List["GetUserIdInfoResponse.WsInfo"]] = None
    
    user_infos: Optional[List[IdInfo]] = None


class CreateWorkspaceResponse(QingflowModel):
    """创建工作区响应"""
    
    ws_id: str = Field(
        description="工作区 ID"
    )


class UpdateWorkspaceResponse(QingflowModel):
    """更新工作区响应"""
    
    success: bool = Field(
        description="是否成功"
    )


class DeleteWorkspaceResponse(QingflowModel):
    """删除工作区响应"""
    
    success: bool = Field(
        description="是否成功"
    )


class GetWorkspaceInfoResponse(QingflowModel):
    """获取工作区信息响应"""
    
    ws_id: Optional[str] = None
    ws_name: Optional[str] = None
    industry_type: Optional[int] = None
    status: Optional[int] = None
    admin_user_id: Optional[str] = None
    create_time: Optional[str] = None


class OpenQingflowServiceResponse(QingflowModel):
    """开通轻流服务响应"""
    
    service_id: str = Field(
        description="服务 ID"
    )


class InstallPluginResponse(QingflowModel):
    """安装插件响应"""
    
    success: bool = Field(
        description="是否成功"
    )


# ==================== 通讯录模块响应 ====================

class UserIdDTO(QingflowModel):
    """用户 ID 响应"""
    
    user_id: str = Field(
        description="用户 ID"
    )


class GetLoginCodeResponse(QingflowModel):
    """获取登录 Code 响应"""
    
    code: str = Field(
        description="登录 Code"
    )


class GetUserByOIDCResponse(QingflowModel):
    """OIDC 获取用户信息响应"""
    
    user_id: Optional[str] = None
    user_name: Optional[str] = None
    email: Optional[str] = None
    mobile_num: Optional[str] = None


class ManagerResponseDTO(QingflowModel):
    """管理员响应"""
    
    manager_user_ids: List[str] = Field(
        description="管理员用户 ID 列表"
    )


class GetUndepartedResponse(QingflowModel):
    """获取不在部门的成员响应"""
    
    users: Optional[List["UserDTO"]] = None


class GetDeptListResponse(QingflowModel):
    """获取部门列表响应"""
    
    departments: Optional[List[DeptDTO]] = None


class DeptIdDTO(QingflowModel):
    """部门 ID 响应"""
    
    dept_id: int = Field(
        description="部门 ID"
    )


class GetDepartmentMembersResponse(QingflowModel):
    """获取部门成员响应"""
    
    users: Optional[List[UserDTO]] = None


class RoleIdDTO(QingflowModel):
    """角色 ID 响应"""
    
    role_id: int = Field(
        description="角色 ID"
    )


class GetRoleMemberResponse(QingflowModel):
    """获取角色成员响应"""
    
    users: Optional[List[UserDTO]] = None


class GetRoleListResponse(QingflowModel):
    """获取角色列表响应"""
    
    roles: Optional[List[RoleDTO]] = None


class RequestIdDTO(QingflowModel):
    """请求 ID 响应"""
    
    request_id: str = Field(
        description="请求 ID"
    )


# 重建嵌套类以解析前向引用
AuditRecordResponse.model_rebuild()
GetUserIdInfoResponse.model_rebuild()
GetUndepartedResponse.model_rebuild()
GetDepartmentMembersResponse.model_rebuild()
GetRoleListResponse.model_rebuild()
