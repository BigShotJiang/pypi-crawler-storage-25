"""
应用数据模型基类
支持通过装饰器定义字段映射，自动完成 AnswerDTO ↔ 模型实例的转换

使用示例：
    from qingflow.models.app_data import AppDataModel, app_data_field
    
    class CustomerData(AppDataModel):
        app_key: str = "customer_mgmt"
        
        name: str = app_data_field(que_id=1001, que_title="姓名")
        age: int = app_data_field(que_id=1002, que_title="年龄", default=0)
        email: str = app_data_field(que_id=1003, que_title="邮箱")
    
    # 从 API 响应解析
    response = client.app.get_app_data("customer_mgmt", request)
    customers = CustomerData.from_answers(response.result.result)
    
    # 直接访问属性
    for c in customers:
        print(f"{c.name}, {c.age}岁, {c.email}")
    
    # 转换为 AnswerDTO 用于创建/更新
    customer = CustomerData(name="张三", age=30, email="zhangsan@example.com")
    answers = customer.to_answers()
"""
from __future__ import annotations
import logging
from typing import Any, Dict, List, Optional, Type, TypeVar, get_origin, get_args
from datetime import datetime

from ..models.base import AnswerDTO, ValueDTO

logger = logging.getLogger(__name__)

T = TypeVar("T", bound="AppDataModel")


class FieldMapping:
    """字段映射定义"""
    
    def __init__(
        self,
        que_id: int,
        que_title: Optional[str] = None,
        que_type: Optional[str] = None,
        default: Any = None,
        required: bool = False,
    ):
        self.que_id = que_id
        self.que_title = que_title
        self.que_type = que_type
        self.default = default
        self.required = required
    
    def __repr__(self):
        return f"FieldMapping(que_id={self.que_id}, que_title='{self.que_title}')"


def app_data_field(
    que_id: int,
    que_title: Optional[str] = None,
    que_type: Optional[str] = None,
    default: Any = None,
    required: bool = False,
) -> FieldMapping:
    """
    定义应用数据字段映射
    
    Args:
        que_id: 字段 ID
        que_title: 字段标题（可选，用于匹配）
        que_type: 字段类型（可选）
        default: 默认值
        required: 是否必填
        
    Example:
        name: str = app_data_field(que_id=1001, que_title="姓名")
        age: int = app_data_field(que_id=1002, que_title="年龄", default=0)
    """
    return FieldMapping(
        que_id=que_id,
        que_title=que_title,
        que_type=que_type,
        default=default,
        required=required,
    )


class AppDataModel:
    """
    应用数据模型基类
    
    继承此类并定义字段映射，即可自动完成 AnswerDTO ↔ 模型实例的转换
    不使用 pydantic BaseModel，避免 FieldMapping 冲突
    """
    
    # 子类可覆盖
    app_key: str = ""
    
    # ==================== 类方法 ====================
    
    @classmethod
    def _get_field_mappings(cls) -> Dict[str, FieldMapping]:
        """获取所有字段映射（从 __dict__ 中收集 FieldMapping 对象）"""
        mappings = {}
        for name in dir(cls):
            if name.startswith("_"):
                continue
            value = getattr(cls, name, None)
            if isinstance(value, FieldMapping):
                mappings[name] = value
        return mappings
    
    @classmethod
    def _get_type_hints(cls) -> Dict[str, type]:
        """获取类型提示"""
        hints = {}
        for name in cls._get_field_mappings():
            if name in cls.__annotations__:
                hints[name] = cls.__annotations__[name]
        return hints
    
    @classmethod
    def from_answer(
        cls: Type[T],
        item: Any,
    ) -> T:
        """
        从单个应用数据响应项解析为模型实例
        
        Args:
            item: GetAppDataResponse 实例（包含 answers 属性）
            
        Returns:
            模型实例
        """
        answers = item.answers if hasattr(item, 'answers') else []
        apply_id = getattr(item, 'apply_id_string', None) or getattr(item, 'apply_id', None)
        return cls._parse_answers(answers, apply_id)
    
    @classmethod
    def from_answers(
        cls: Type[T],
        items: List[Any],
    ) -> List[T]:
        """
        批量从应用数据响应列表解析为模型实例列表
        
        Args:
            items: GetAppDataResponse.result.result 列表
            
        Returns:
            模型实例列表
        """
        return [cls.from_answer(item) for item in items]
    
    @classmethod
    def _parse_answers(
        cls: Type[T],
        answers: List[AnswerDTO],
        apply_id: Optional[str] = None,
    ) -> T:
        """内部方法：解析 answers 列表"""
        mappings = cls._get_field_mappings()
        type_hints = cls._get_type_hints()
        
        # 构建 que_id -> AnswerDTO 的映射
        answer_map = {}
        for answer in answers:
            answer_map[answer.que_id] = answer
        
        # 解析每个字段
        data = {}
        for field_name, mapping in mappings.items():
            answer = answer_map.get(mapping.que_id)
            
            if answer and answer.values:
                # 提取值
                values = [v.value for v in answer.values if v.value]
                
                if values:
                    # 根据类型提示转换
                    target_type = type_hints.get(field_name)
                    data[field_name] = cls._convert_value(values, target_type)
                else:
                    # 有 answer 但没有值，使用默认值
                    data[field_name] = mapping.default
            else:
                # 没有 answer，使用默认值
                data[field_name] = mapping.default
        
        # 保存 apply_id 到实例
        if apply_id is not None:
            data["apply_id"] = str(apply_id)
        
        return cls(**data)
    
    @classmethod
    def _convert_value(cls, values: List[str], target_type: Optional[type] = None):
        """根据类型提示转换值"""
        if not values:
            return None
        
        # 如果是列表类型
        origin = get_origin(target_type)
        if origin is list:
            return values
        
        # 单值转换
        value = values[0]
        
        if target_type is int or target_type is Optional[int]:
            try:
                return int(value)
            except (ValueError, TypeError):
                return 0
        elif target_type is float or target_type is Optional[float]:
            try:
                return float(value)
            except (ValueError, TypeError):
                return 0.0
        elif target_type is bool or target_type is Optional[bool]:
            return value.lower() in ("true", "1", "yes", "是")
        elif target_type is datetime or target_type is Optional[datetime]:
            try:
                return datetime.strptime(value, "%Y-%m-%d %H:%M:%S")
            except (ValueError, TypeError):
                try:
                    return datetime.strptime(value, "%Y-%m-%d")
                except (ValueError, TypeError):
                    return None
        else:
            # 默认返回字符串
            return value
    
    # ==================== 实例方法 ====================
    
    def __init__(self, **data):
        """初始化模型实例"""
        mappings = self._get_field_mappings()
        
        # 设置所有字段（包括未提供的，设为默认值）
        for field_name, mapping in mappings.items():
            if field_name in data:
                object.__setattr__(self, field_name, data[field_name])
            elif mapping.default is not None:
                object.__setattr__(self, field_name, mapping.default)
            else:
                object.__setattr__(self, field_name, None)
        
        # 设置额外数据（如 apply_id）
        for name, value in data.items():
            if name not in mappings:
                object.__setattr__(self, name, value)
    
    def to_answers(self) -> List[AnswerDTO]:
        """
        将模型实例转换为 AnswerDTO 列表（用于创建/更新数据）
        
        Returns:
            AnswerDTO 列表
        """
        mappings = self._get_field_mappings()
        answers = []
        
        for field_name, mapping in mappings.items():
            # 从实例 __dict__ 获取值（避免回退到类属性的 FieldMapping）
            value = self.__dict__.get(field_name)
            
            # 跳过 None
            if value is None:
                continue
            
            # 转换为字符串值
            if isinstance(value, list):
                value_list = [str(v) for v in value]
            elif isinstance(value, datetime):
                value_list = [value.strftime("%Y-%m-%d %H:%M:%S")]
            elif isinstance(value, bool):
                value_list = ["是" if value else "否"]
            else:
                value_list = [str(value)]
            
            answer = AnswerDTO(
                que_id=mapping.que_id,
                que_title=mapping.que_title,
                values=[ValueDTO(value=v) for v in value_list],
            )
            answers.append(answer)
        
        return answers
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典（queTitle -> value）"""
        mappings = self._get_field_mappings()
        result = {}
        
        for field_name, mapping in mappings.items():
            value = self.__dict__.get(field_name)
            title = mapping.que_title or field_name
            result[title] = value
        
        return result
    
    def __repr__(self) -> str:
        data = self.to_dict()
        fields = ", ".join(f"{k}={v!r}" for k, v in data.items())
        return f"{self.__class__.__name__}({fields})"
