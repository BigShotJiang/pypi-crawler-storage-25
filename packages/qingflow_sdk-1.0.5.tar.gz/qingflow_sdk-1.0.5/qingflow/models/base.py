"""
基础模型模块
提供所有数据模型的基类
"""
from pydantic import BaseModel, ConfigDict, AliasGenerator
from typing import Any, Dict, Optional, Union
from datetime import datetime


def to_camel(string: str) -> str:
    """snake_case 转 camelCase"""
    components = string.split("_")
    return components[0] + "".join(x.title() for x in components[1:])


class QingflowModel(BaseModel):
    """轻流数据模型基类"""
    
    model_config = ConfigDict(
        populate_by_name=True,        # 支持字段别名
        validate_assignment=True,     # 赋值时验证
        extra="ignore",               # 忽略额外字段
        str_strip_whitespace=True,    # 字符串去空格
        alias_generator=AliasGenerator(alias=to_camel),  # 自动生成 camelCase 别名
        json_schema_extra={
            "examples": []
        }
    )
    
    def to_dict(self, exclude_none: bool = True) -> Dict[str, Any]:
        """转换为字典（使用 camelCase 别名，适配轻流 API）"""
        return self.model_dump(exclude_none=exclude_none, by_alias=True)
    
    def to_json(self, exclude_none: bool = True) -> str:
        """转换为 JSON 字符串"""
        return self.model_dump_json(exclude_none=exclude_none)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "QingflowModel":
        """从字典创建实例"""
        return cls.model_validate(data)
    
    @classmethod
    def from_json(cls, json_str: str) -> "QingflowModel":
        """从 JSON 字符串创建实例"""
        return cls.model_validate_json(json_str)


class PageRequest(QingflowModel):
    """分页请求基类"""
    
    page_num: int = 1
    page_size: int = 20
    
    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {"page_num": 1, "page_size": 20}
            ]
        }
    )


class QueryCondition(QingflowModel):
    """查询条件"""
    
    que_id: int
    search_key: Optional[str] = None
    search_keys: Optional[list[str]] = None
    min_value: Optional[str] = None
    max_value: Optional[str] = None
    
    @classmethod
    def exact_match(cls, que_id: int, value: str) -> "QueryCondition":
        """
        精确匹配查询条件（使用 searchKeys，轻流系统会进行精准筛选）
        
        Args:
            que_id: 字段 ID
            value: 精确匹配的值
            
        Returns:
            QueryCondition 实例
        """
        return cls(que_id=que_id, search_keys=[value])
    
    @classmethod
    def exact_match_multi(cls, que_id: int, values: list[str]) -> "QueryCondition":
        """
        多值精确匹配查询条件（使用 searchKeys，匹配任意一个值）
        
        Args:
            que_id: 字段 ID
            values: 精确匹配的值列表（OR 关系）
            
        Returns:
            QueryCondition 实例
        """
        return cls(que_id=que_id, search_keys=values)


class ValueDTO(QingflowModel):
    """字段值"""
    
    value: str
    id: Optional[Union[str, int]] = None
    option_id: Optional[str] = None
    other_info: Optional[str] = None


class AnswerDTO(QingflowModel):
    """字段答案"""
    
    que_id: int
    que_title: Optional[str] = None
    que_type: Optional[Union[str, int]] = None
    values: Optional[list[ValueDTO]] = None
    table_values: Optional[list[list["AnswerDTO"]]] = None


class ApplyUserDTO(QingflowModel):
    """提交用户"""
    
    user_id: Optional[str] = None
    user_name: Optional[str] = None
    email: Optional[str] = None
    mobile_num: Optional[str] = None
