"""
请求模型模块
定义所有 API 请求参数
"""
from pydantic import Field
from typing import Optional, List
from .base import QingflowModel, PageRequest, QueryCondition, AnswerDTO, ApplyUserDTO


# ==================== 应用模块请求 ====================

class GetAppDataRequest(PageRequest):
    """获取应用数据请求"""
    
    queries: Optional[List[QueryCondition]] = Field(
        default=None,
        description="查询条件列表"
    )
    
    @classmethod
    def create_single_query(
        cls,
        que_id: int,
        search_key: str,
        page_size: int = 100
    ) -> "GetAppDataRequest":
        """创建单条件查询"""
        return cls(
            page_num=1,
            page_size=page_size,
            queries=[QueryCondition(que_id=que_id, search_key=search_key)]
        )
    
    @classmethod
    def create_multi_query(
        cls,
        queries: List[QueryCondition],
        page_size: int = 200
    ) -> "GetAppDataRequest":
        """创建多条件查询"""
        return cls(
            page_num=1,
            page_size=page_size,
            queries=queries
        )


class AddAppDataRequest(QingflowModel):
    """添加应用数据请求"""
    
    apply_user: Optional[ApplyUserDTO] = Field(
        default=None,
        description="提交用户信息"
    )
    answers: List[AnswerDTO] = Field(
        description="字段值列表"
    )


class UpdateAppDataRequest(QingflowModel):
    """更新应用数据请求"""
    
    apply_id: str = Field(
        description="数据 ID"
    )
    answers: List[AnswerDTO] = Field(
        description="更新的字段值"
    )


class DeleteAppDataRequest(PageRequest):
    """删除应用数据请求"""
    
    queries: Optional[List[QueryCondition]] = Field(
        default=None,
        description="删除条件"
    )
    query_key: Optional[str] = Field(
        default=None,
        description="查询键"
    )
    apply_ids: Optional[List[str]] = Field(
        default=None,
        description="数据 ID 列表"
    )
    delete_type: Optional[str] = Field(
        default=None,
        alias="type",
        description="删除类型"
    )


class AuditRequest(QingflowModel):
    """审批请求"""
    
    audit_result: int = Field(
        description="审批结果：1=提交，2=通过，3=驳回，5=加签，6=退回申请人"
    )
    audit_node_id: int = Field(
        description="审批节点 ID"
    )
    audit_feedback: Optional[str] = Field(
        default=None,
        description="审批意见"
    )


class AuditRollbackRequest(QingflowModel):
    """流程回退请求"""
    
    user_id: str = Field(
        description="操作用户 ID"
    )
    audit_node_id: int = Field(
        description="当前节点 ID"
    )
    target_audit_node_id: int = Field(
        description="目标节点 ID"
    )
    audit_feedback: Optional[str] = Field(
        default=None,
        description="回退原因"
    )


class ReassinRequest(QingflowModel):
    """重新指派请求"""
    
    class ReassignmentInfo(QingflowModel):
        """重新指派信息"""
        audit_node_id: int = Field(description="审批节点 ID")
        user_id_list: List[str] = Field(description="指派用户 ID 列表")
    
    reassignment_info: List[ReassignmentInfo] = Field(
        description="重新指派信息列表"
    )


class GetAppListRequest(PageRequest):
    """获取应用列表请求"""
    
    app_key: Optional[str] = Field(
        default=None,
        description="应用 Key（筛选）"
    )


class GetAllAppRequest(QingflowModel):
    """获取所有应用请求"""
    
    user_id: Optional[str] = Field(
        default=None,
        description="用户 ID（筛选收藏）"
    )
    favourite: Optional[int] = Field(
        default=None,
        description="是否收藏：0=全部，1=收藏"
    )


class GetDashInfoRequest(PageRequest):
    """获取门户信息请求"""
    
    dash_key: Optional[str] = Field(
        default=None,
        description="门户 Key（筛选）"
    )


class GetTagListRequest(PageRequest):
    """获取应用包列表请求"""
    
    tag_id: Optional[str] = Field(
        default=None,
        description="应用包 ID（筛选）"
    )


class GetTemplateRequest(QingflowModel):
    """获取打印模板请求"""
    
    dom: Optional[str] = Field(
        default=None,
        description="DOM 内容"
    )


# ==================== 环境模块请求 ====================

class GetAdminAccessTokenRequest(QingflowModel):
    """获取环境级 Token 请求"""
    
    environ_id: str = Field(
        description="环境 ID"
    )
    secret: str = Field(
        description="环境 Secret"
    )


class CreateUserForQingflowRequest(QingflowModel):
    """创建轻流用户请求"""
    
    user_id: str = Field(
        description="用户 ID"
    )
    user_name: str = Field(
        description="用户名"
    )
    email: str = Field(
        description="邮箱"
    )
    mobile_num: Optional[str] = Field(
        default=None,
        description="手机号"
    )
    department_id: Optional[int] = Field(
        default=None,
        description="部门 ID"
    )
    role_ids: Optional[List[int]] = Field(
        default=None,
        description="角色 ID 列表"
    )


class GetUserIdInfoRequest(QingflowModel):
    """获取用户信息请求"""
    
    user_ids: Optional[List[str]] = Field(
        default=None,
        description="用户 ID 列表"
    )
    emails: Optional[List[str]] = Field(
        default=None,
        description="邮箱列表"
    )
    mobile_nums: Optional[List[str]] = Field(
        default=None,
        description="手机号列表"
    )


class VerificationRequest(QingflowModel):
    """发送验证码请求"""
    
    mobile_num: Optional[str] = Field(
        default=None,
        description="手机号"
    )
    email: Optional[str] = Field(
        default=None,
        description="邮箱"
    )


class UpdateUserPasswordRequest(QingflowModel):
    """修改密码请求"""
    
    user_id: str = Field(
        description="用户 ID"
    )
    verification_code: str = Field(
        description="验证码"
    )
    new_password: str = Field(
        description="新密码"
    )


class CreateWorkspaceRequest(QingflowModel):
    """创建工作区请求"""
    
    ws_name: str = Field(
        description="工作区名称"
    )
    industry_type: int = Field(
        description="行业类型"
    )
    admin_user_id: str = Field(
        description="管理员用户 ID"
    )
    service_id: Optional[str] = Field(
        default=None,
        description="服务 ID"
    )


class UpdateWorkspaceRequest(QingflowModel):
    """更新工作区请求"""
    
    ws_id: str = Field(
        description="工作区 ID"
    )
    ws_name: Optional[str] = Field(
        default=None,
        description="工作区名称"
    )
    admin_user_id: Optional[str] = Field(
        default=None,
        description="管理员用户 ID"
    )


class DeleteWorkspaceRequest(QingflowModel):
    """删除工作区请求"""
    
    ws_id: str = Field(
        description="工作区 ID"
    )


class OpenQingflowServiceRequest(QingflowModel):
    """开通轻流服务请求"""
    
    ws_id: str = Field(
        description="工作区 ID"
    )
    service_type: int = Field(
        description="服务类型"
    )
    quantity: int = Field(
        default=1,
        description="数量"
    )


class ExtensionPackRequest(QingflowModel):
    """购买扩展包请求"""
    
    ws_id: str = Field(
        description="工作区 ID"
    )
    pack_type: int = Field(
        description="扩展包类型"
    )
    quantity: int = Field(
        default=1,
        description="数量"
    )


class InstallPluginRequest(QingflowModel):
    """安装插件请求"""
    
    ws_id: str = Field(
        description="工作区 ID"
    )
    plugin_id: str = Field(
        description="插件 ID"
    )


# ==================== 通讯录模块请求 ====================

class UserDTO(QingflowModel):
    """用户信息"""
    
    user_id: Optional[str] = Field(
        default=None,
        description="用户 ID"
    )
    user_name: Optional[str] = Field(
        default=None,
        description="用户名"
    )
    email: Optional[str] = Field(
        default=None,
        description="邮箱"
    )
    mobile_num: Optional[str] = Field(
        default=None,
        description="手机号"
    )
    department_id: Optional[int] = Field(
        default=None,
        description="部门 ID"
    )
    department_name: Optional[str] = Field(
        default=None,
        description="部门名称"
    )
    role_ids: Optional[List[int]] = Field(
        default=None,
        description="角色 ID 列表"
    )
    status: Optional[int] = Field(
        default=1,
        description="状态：0=禁用，1=启用"
    )


class BatchCreateUserRequest(QingflowModel):
    """批量创建用户请求"""
    
    users: List[UserDTO] = Field(
        description="用户列表"
    )


class DeptDTO(QingflowModel):
    """部门信息"""
    
    dept_id: Optional[int] = Field(
        default=None,
        description="部门 ID"
    )
    dept_name: str = Field(
        description="部门名称"
    )
    parent_id: Optional[int] = Field(
        default=None,
        description="父部门 ID"
    )
    order: Optional[int] = Field(
        default=None,
        description="排序"
    )


class DepartmentMemberRequest(QingflowModel):
    """部门成员请求"""
    
    dept_id: int = Field(
        description="部门 ID"
    )
    user_ids: List[str] = Field(
        description="用户 ID 列表"
    )


class RoleDTO(QingflowModel):
    """角色信息"""
    
    role_id: Optional[int] = Field(
        default=None,
        description="角色 ID"
    )
    role_name: str = Field(
        description="角色名称"
    )


class RoleMemberRequest(QingflowModel):
    """角色成员请求"""
    
    role_id: int = Field(
        description="角色 ID"
    )
    user_ids: List[str] = Field(
        description="用户 ID 列表"
    )


class ManagerDTO(QingflowModel):
    """管理员信息"""
    
    manager_user_ids: List[str] = Field(
        description="管理员用户 ID 列表"
    )


class GetLoginCodeRequest(QingflowModel):
    """获取登录 Code 请求"""
    
    user_id: str = Field(
        description="用户 ID"
    )
