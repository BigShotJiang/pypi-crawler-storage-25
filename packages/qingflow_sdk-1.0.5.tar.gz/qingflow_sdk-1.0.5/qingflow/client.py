"""
主客户端模块
提供统一的 API 入口
"""
import logging
from typing import Optional
from contextlib import contextmanager
from .config import QingflowConfig, get_config, set_config
from .http.client import HTTPClient
from .modules.app import AppModule
from .modules.env import EnvModule
from .modules.contact import ContactModule
from .exceptions import QingflowConfigurationError

logger = logging.getLogger(__name__)


class QingflowClient:
    """
    轻流 OpenAPI 客户端
    
    使用示例：
        # 方式 1：基础初始化
        client = QingflowClient(access_token="your-token")
        
        # 方式 2：完整配置
        client = QingflowClient(
            access_token="your-token",
            base_domain="https://your-domain.com",
            auto_assert_success=True,
            timeout=60.0
        )
        
        # 方式 3：上下文管理
        with QingflowClient(access_token="your-token") as client:
            response = client.app.get_app_data("app_key", request)
        
        # 方式 4：异步使用
        async with QingflowClient(access_token="your-token", client_type="async") as client:
            response = await client.app.async_get_app_data("app_key", request)
    """
    
    def __init__(
        self,
        access_token: Optional[str] = None,
        base_domain: Optional[str] = None,
        auto_assert_success: bool = False,
        client_type: str = "sync",
        timeout: Optional[float] = None,
        max_retries: Optional[int] = None,
        log_level: Optional[str] = None,
        log_requests: bool = False,
        log_responses: bool = False,
        **kwargs
    ):
        """
        初始化客户端
        
        Args:
            access_token: 工作区访问令牌
            base_domain: 轻流 API 基础域名
            auto_assert_success: 自动断言接口返回成功
            client_type: 客户端类型（sync/async）
            timeout: 请求超时时间（秒）
            max_retries: 最大重试次数
            log_level: 日志级别
            log_requests: 记录请求日志
            log_responses: 记录响应日志
            **kwargs: 其他配置参数
        """
        # 构建配置
        config_dict = {
            "access_token": access_token,
            "base_domain": base_domain or "https://api.qingflow.com",
            "auto_assert_success": auto_assert_success,
            "client_type": client_type,
            "timeout": timeout,
            "max_retries": max_retries,
            "log_level": log_level,
            "log_requests": log_requests,
            "log_responses": log_responses,
            **kwargs
        }
        
        # 过滤 None 值
        config_dict = {k: v for k, v in config_dict.items() if v is not None}
        
        self.config = QingflowConfig(**config_dict)
        set_config(self.config)
        
        # 初始化 HTTP 客户端
        self.http_client = HTTPClient(self.config)
        
        # 初始化业务模块
        self.app = AppModule(self.http_client, self)
        self.env = EnvModule(self.http_client, self)
        self.contact = ContactModule(self.http_client, self)
        
        logger.info(f"QingflowClient 初始化完成，base_domain={self.config.base_domain}")
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.aclose()
    
    def close(self) -> None:
        """关闭客户端"""
        self.http_client.close()
        logger.info("QingflowClient 已关闭")
    
    async def aclose(self) -> None:
        """异步关闭客户端"""
        await self.http_client.aclose()
        logger.info("QingflowClient 已异步关闭")
    
    @classmethod
    def from_env(cls) -> "QingflowClient":
        """从环境变量初始化客户端"""
        return cls()
    
    @classmethod
    def from_config_file(cls, config_path: str) -> "QingflowClient":
        """从配置文件初始化客户端"""
        import yaml
        with open(config_path, "r", encoding="utf-8") as f:
            config_data = yaml.safe_load(f)
        return cls(**config_data)
    
    def get_access_token(self) -> Optional[str]:
        """获取当前 access token"""
        return self.config.access_token_str
    
    def set_access_token(self, token: str) -> None:
        """设置 access token"""
        from pydantic import SecretStr
        self.config.access_token = SecretStr(token)
        logger.info("Access token 已更新")
    
    @contextmanager
    def with_token(self, token: str):
        """
        临时使用指定 token
        
        使用示例：
            with client.with_token("temp-token"):
                response = client.app.get_app_data("app_key", request)
        """
        old_token = self.config.access_token
        try:
            from pydantic import SecretStr
            self.config.access_token = SecretStr(token)
            yield
        finally:
            self.config.access_token = old_token
