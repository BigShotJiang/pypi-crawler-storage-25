"""
配置管理模块
支持环境变量、配置文件、代码配置三种方式
"""
from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional
from enum import Enum


class LogLevel(str, Enum):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"


class ClientType(str, Enum):
    SYNC = "sync"
    ASYNC = "async"


class QingflowConfig(BaseSettings):
    """轻流客户端配置"""
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
        env_prefix="qingflow_",
    )
    
    # ==================== 基础配置 ====================
    access_token: Optional[SecretStr] = Field(
        default=None,
        description="工作区访问令牌"
    )
    base_domain: str = Field(
        default="https://api.qingflow.com",
        description="轻流 API 基础域名"
    )
    client_type: ClientType = Field(
        default=ClientType.SYNC,
        description="客户端类型：sync/async"
    )
    
    # ==================== HTTP 配置 ====================
    timeout: float = Field(
        default=30.0,
        description="请求超时时间（秒）"
    )
    connect_timeout: float = Field(
        default=10.0,
        description="连接超时时间（秒）"
    )
    max_retries: int = Field(
        default=3,
        description="最大重试次数"
    )
    retry_backoff: float = Field(
        default=1.0,
        description="重试退避系数（秒）"
    )
    max_connections: int = Field(
        default=100,
        description="最大连接数"
    )
    max_keepalive_connections: int = Field(
        default=20,
        description="最大保持连接数"
    )
    
    # ==================== 行为配置 ====================
    auto_assert_success: bool = Field(
        default=False,
        description="自动断言接口返回成功，失败则抛异常"
    )
    log_level: LogLevel = Field(
        default=LogLevel.INFO,
        description="日志级别"
    )
    log_requests: bool = Field(
        default=False,
        description="记录请求日志"
    )
    log_responses: bool = Field(
        default=False,
        description="记录响应日志"
    )
    
    # ==================== 专有云配置 ====================
    environ_id: Optional[str] = Field(
        default=None,
        description="环境 ID（专有云）"
    )
    env_secret: Optional[SecretStr] = Field(
        default=None,
        description="环境 Secret（专有云）"
    )
    
    @property
    def api_base_url(self) -> str:
        """获取 API 基础 URL"""
        return f"{self.base_domain.rstrip('/')}/openApi"
    
    @property
    def access_token_str(self) -> Optional[str]:
        """获取 access token 字符串"""
        return self.access_token.get_secret_value() if self.access_token else None
    
    @property
    def env_secret_str(self) -> Optional[str]:
        """获取 env secret 字符串"""
        return self.env_secret.get_secret_value() if self.env_secret else None


# 全局配置实例（单例模式）
_config: Optional[QingflowConfig] = None


def get_config() -> QingflowConfig:
    """获取全局配置实例"""
    global _config
    if _config is None:
        _config = QingflowConfig()
    return _config


def set_config(config: QingflowConfig) -> None:
    """设置全局配置实例"""
    global _config
    _config = config
