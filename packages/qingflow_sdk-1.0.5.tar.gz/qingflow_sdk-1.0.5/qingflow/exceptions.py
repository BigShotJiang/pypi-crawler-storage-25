"""
异常定义模块
统一异常体系，便于错误处理
"""
from typing import Optional, Any, Dict


class QingflowError(Exception):
    """轻流 SDK 基础异常"""
    
    def __init__(
        self,
        message: str,
        err_code: Optional[int] = None,
        details: Optional[Any] = None
    ):
        self.message = message
        self.err_code = err_code
        self.details = details
        super().__init__(self.message)
    
    def __str__(self) -> str:
        if self.err_code:
            return f"QingflowError [{self.err_code}]: {self.message}"
        return f"QingflowError: {self.message}"


class QingflowAPIError(QingflowError):
    """API 调用异常"""
    
    def __init__(
        self,
        message: str,
        err_code: int,
        status_code: Optional[int] = None,
        details: Optional[Any] = None,
        request_id: Optional[str] = None
    ):
        self.status_code = status_code
        self.request_id = request_id
        super().__init__(message, err_code, details)
    
    def __str__(self) -> str:
        parts = [f"QingflowAPIError [{self.err_code}"]
        if self.status_code:
            parts.append(f" HTTP {self.status_code}")
        parts.append(f"]: {self.message}")
        if self.request_id:
            parts.append(f" (request_id: {self.request_id})")
        return "".join(parts)


class QingflowAuthenticationError(QingflowAPIError):
    """认证异常"""
    pass


class QingflowPermissionError(QingflowAPIError):
    """权限异常"""
    pass


class QingflowRateLimitError(QingflowAPIError):
    """频率限制异常"""
    
    def __init__(
        self,
        message: str,
        err_code: int,
        retry_after: Optional[int] = None,
        **kwargs
    ):
        self.retry_after = retry_after
        super().__init__(message, err_code, **kwargs)


class QingflowResourceNotFoundError(QingflowAPIError):
    """资源不存在异常"""
    pass


class QingflowValidationError(QingflowError):
    """参数验证异常"""
    pass


class QingflowConfigurationError(QingflowError):
    """配置异常"""
    pass


class QingflowTimeoutError(QingflowError):
    """超时异常"""
    pass


class QingflowConnectionError(QingflowError):
    """连接异常"""
    pass


# 错误码映射
ERROR_CODE_MAP: Dict[int, str] = {
    0: "成功",
    40000: "参数错误",
    40001: "认证失败",
    40002: "权限不足",
    40003: "资源不存在",
    40004: "请求频率限制",
    40005: "数据格式错误",
    40006: "应用不存在",
    40007: "工作区不存在",
    40008: "用户不存在",
    40009: "部门不存在",
    40010: "角色不存在",
    40096: "该字段不存在",
    49300: "工作区未开通或已停用",
    49304: "数据不存在或无权限",
    50000: "服务器内部错误",
}


def create_error_from_response(
    err_code: int,
    err_msg: str,
    status_code: int = None,
    details: Any = None,
    request_id: str = None
) -> QingflowAPIError:
    """根据响应创建异常"""
    # 使用 SDK 错误码映射补充错误信息
    if not err_msg and err_code in ERROR_CODE_MAP:
        err_msg = ERROR_CODE_MAP[err_code]
    elif not err_msg:
        err_msg = f"未知错误 (err_code={err_code})"
    
    # 根据错误码选择异常类型
    if err_code in (40001, 401):
        return QingflowAuthenticationError(
            message=err_msg,
            err_code=err_code,
            status_code=status_code,
            details=details,
            request_id=request_id
        )
    elif err_code in (40002, 403):
        return QingflowPermissionError(
            message=err_msg,
            err_code=err_code,
            status_code=status_code,
            details=details,
            request_id=request_id
        )
    elif err_code in (40004, 429):
        return QingflowRateLimitError(
            message=err_msg,
            err_code=err_code,
            status_code=status_code,
            details=details,
            request_id=request_id
        )
    elif err_code in (40003, 404):
        return QingflowResourceNotFoundError(
            message=err_msg,
            err_code=err_code,
            status_code=status_code,
            details=details,
            request_id=request_id
        )
    else:
        return QingflowAPIError(
            message=err_msg,
            err_code=err_code,
            status_code=status_code,
            details=details,
            request_id=request_id
        )
