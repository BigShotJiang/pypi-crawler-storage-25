"""
常量定义模块
定义 API 路径、错误码等常量
"""


class QingflowPathConstant:
    """轻流 API 路径常量"""
    
    # 默认公有云地址
    PUBLIC_QINGFLOW_DOMAIN = "https://api.qingflow.com"
    
    # OpenAPI 前缀
    OPEN_API = "/openApi"
    
    class Env:
        """环境模块路径"""
        ENV = "/env"
        ADMIN_ACCESS_TOKEN = ENV + "/environAccessToken"
        CREATE_USER = ENV + "/user/create"
        GET_ID_INFO = ENV + "/users/getId"
        CREATE_WORKSPACE = ENV + "/workspace/create"
        UPDATE_WORKSPACE = ENV + "/workspace/update"
        DELETE_WORKSPACE = ENV + "/workspace"
        GET_WORKSPACE_INFO_WITH_WS_ID = ENV + "/workspace?wsId=%s"
        GET_WORKSPACE_INFO_WITH_OPEN_USER_ID = ENV + "/workspace?openUserId=%s"
        INSTALL_PLUGIN = ENV + "/plugin"
        OPEN_SERVICE = ENV + "/service/create"
        EXTENSION_PACK = ENV + "/service/extensionPack"
        VERIFICATION_CODE = ENV + "/user/verification"
        UPDATE_USER_PASSWORD = ENV + "/user/updatePassword"
    
    class App:
        """应用模块路径"""
        APP = "/app"
        GET_ACCESS_TOKEN_WITH_SECRET = "/accesstoken?wsId=%s&wsSecret=%s"
        GET_ACCESS_TOKEN_WITH_ADMIN_TOKEN = "/accesstoken?wsId=%s&adminAccessToken=%s"
        GET_APP_DATA_TEMPLATE = APP + "/%s/apply/filter"
        ADD_APP_DATA_TEMPLATE = APP + "/%s/apply"
        UPDATE_APP_DATA_TEMPLATE = "/apply/%s"
        DELETE_APP_DATA_TEMPLATE = APP + "/%s/apply"
        GET_APP_TEMPLATE_TEMPLATE = "/apply/%s/%s/print"
        GET_CHART_DATA_TEMPLATE = "/chart/%s/apply/filter"
        REASSIN_TEMPLATE = "/apply/%s/reassign"
        AUDIT_ROLLBACK_TEMPLATE = "/%s/audit/rollback"
        AUDIT_RECORD_TEMPLATE = "/apply/%s/auditRecord"
        AUDIT_TEMPLATE = "/%s/audit"
        APPS = "/apps?pageNum=%d&pageSize=%d"
        ALL_APP = "/app"
        ALL_DASH = "/dash"
        DASH_WITH_DASH_KEY = "/dashes?dashKey=%s&pageNum=%d&pageSize=%d"
        DASHES = "/dashes?pageNum=%d&pageSize=%d"
        ALL_APP_WITH_USERID_FAVOURITE = "/app?userId=%s&favourite=%d"
        APPS_WITH_APP_KEY = "/apps?appKey=%s&pageNum=%d&pageSize=%d"
        TAG = "/tag?pageNum=%d&pageSize=%d"
        TAG_WITH_TAG_ID = "/tag?tagId=%s&pageNum=%d&pageSize=%d"
    
    class Contact:
        """通讯录模块路径"""
        USER = "/user"
        GET_USER_FOR_MOBILE = USER + "/getId?mobile=%s&email=%s"
        USER_REST_TEMPLATE = USER + "/%s"
        GET_ALL_USER_TEMPLATE = USER + "?pageSize=%d&pageNum=%d"
        BATCH_USER = USER + "/batch"
        OIDC_USER = "/oidcAuthentication"
        DEPARTMENT = "/department"
        DEPART_QUERY_TEMPLATE = DEPARTMENT + "?deptId=%s"
        DEPART_QUERY_DETAIL = DEPARTMENT + "/%s"
        DEPARTMENT_REST_TEMPLATE = DEPARTMENT + "/%s"
        DEPARTMENT_MEMBER_REST_TEMPLATE = DEPARTMENT + "/%s" + USER
        GET_DEPARTMENT_MEMBERS = DEPARTMENT_MEMBER_REST_TEMPLATE + "?fetchChild=%s"
        MANAGER = "/manager/super"
        GET_TO_DO = "/dynamic/audits?pageSize=%s&pageNum=%s&userId=%s&status=%s&type=%s"
        UNDEPARTED = USER + "/undeparted"
        ROLE = "/role"
        ROLE_REST_TEMPLATE = ROLE + "/%s"
        ROLE_MEMBER_REST_TEMPLATE = ROLE + "/%s" + USER
        GET_LOGIN_CODE = USER + "/login"
        CODE_LOGIN_URL_TEMPLATE = "%s/code-login/?code=%s"
        CODE_LOGIN_URL_WITH_REDIRECT_URL_TEMPLATE = CODE_LOGIN_URL_TEMPLATE + "&encodeRedirectUrl=true&redirectUrl=%s"


class QingflowErrorCode:
    """轻流错误码"""
    
    SUCCESS = 0
    PARAM_ERROR = 40000
    AUTH_ERROR = 40001
    PERMISSION_ERROR = 40002
    RESOURCE_NOT_FOUND = 40003
    RATE_LIMIT = 40004
    DATA_FORMAT_ERROR = 40005
    APP_NOT_FOUND = 40006
    WORKSPACE_NOT_FOUND = 40007
    USER_NOT_FOUND = 40008
    DEPT_NOT_FOUND = 40009
    ROLE_NOT_FOUND = 40010
    SERVER_ERROR = 50000


class AuditResult:
    """审批结果枚举"""
    
    SUBMIT = 1          # 提交
    ACCEPT = 2          # 通过
    REJECT = 3          # 驳回
    CRAFT = 5           # 加签
    RETURN_TO_APPLICANT = 6  # 退回申请人
