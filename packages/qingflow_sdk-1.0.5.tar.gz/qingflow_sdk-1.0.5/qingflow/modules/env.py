"""
环境管理模块
提供环境级 Token、用户管理、工作区管理等功能
注意：以下接口仅限专有云环境使用
"""
import logging
import json
from typing import Optional, List
from ..models.request import (
    GetAdminAccessTokenRequest, CreateUserForQingflowRequest,
    GetUserIdInfoRequest, VerificationRequest, UpdateUserPasswordRequest,
    CreateWorkspaceRequest, UpdateWorkspaceRequest, DeleteWorkspaceRequest,
    OpenQingflowServiceRequest, ExtensionPackRequest, InstallPluginRequest
)
from ..models.response import (
    QingflowResponse,
    GetAdminAccessTokenResponse, CreateUserResponse,
    GetUserIdInfoResponse, CreateWorkspaceResponse,
    UpdateWorkspaceResponse, DeleteWorkspaceResponse,
    GetWorkspaceInfoResponse, OpenQingflowServiceResponse,
    InstallPluginResponse
)
from ..constants import QingflowPathConstant

logger = logging.getLogger(__name__)


class EnvModule:
    """环境管理模块"""
    
    def __init__(self, http_client, client):
        self.http = http_client
        self.client = client
    
    def get_admin_access_token(
        self,
        environ_id: str,
        env_secret: str
    ) -> QingflowResponse[GetAdminAccessTokenResponse]:
        """
        获取环境级 Token（专有云）
        
        Args:
            environ_id: 环境 ID
            env_secret: 环境 Secret
            
        Returns:
            环境级 Token
        """
        url = QingflowPathConstant.Env.ADMIN_ACCESS_TOKEN
        request = GetAdminAccessTokenRequest(environ_id=environ_id, secret=env_secret)
        response = self.http.post(url, request.to_dict())
        return self._parse_response(response, GetAdminAccessTokenResponse)
    
    def create_qingflow_user(
        self,
        admin_access_token: str,
        request: CreateUserForQingflowRequest
    ) -> QingflowResponse[CreateUserResponse]:
        """
        创建轻流用户（专有云）
        
        Args:
            admin_access_token: 环境级 Token
            request: 创建用户请求
            
        Returns:
            创建结果
        """
        url = QingflowPathConstant.Env.CREATE_USER
        response = self.http.post(url, request.to_dict(), admin_access_token)
        return self._parse_response(response, CreateUserResponse)
    
    def get_user_info_in_env(
        self,
        admin_access_token: str,
        request: GetUserIdInfoRequest
    ) -> QingflowResponse[GetUserIdInfoResponse]:
        """
        获取用户信息（专有云）
        
        Args:
            admin_access_token: 环境级 Token
            request: 查询请求
            
        Returns:
            用户信息
        """
        url = QingflowPathConstant.Env.GET_ID_INFO
        response = self.http.post(url, request.to_dict(), admin_access_token)
        return self._parse_response(response, GetUserIdInfoResponse)
    
    def send_verification_code(
        self,
        admin_access_token: str,
        request: VerificationRequest
    ) -> QingflowResponse:
        """
        发送重置密码验证码（专有云）
        
        Args:
            admin_access_token: 环境级 Token
            request: 验证码请求
            
        Returns:
            发送结果
        """
        url = QingflowPathConstant.Env.VERIFICATION_CODE
        response = self.http.post(url, request.to_dict(), admin_access_token)
        return self._parse_response(response, object)
    
    def update_user_password(
        self,
        admin_access_token: str,
        request: UpdateUserPasswordRequest
    ) -> QingflowResponse[str]:
        """
        修改密码（专有云）
        
        Args:
            admin_access_token: 环境级 Token
            request: 修改密码请求
            
        Returns:
            修改结果
        """
        url = QingflowPathConstant.Env.UPDATE_USER_PASSWORD
        response = self.http.post(url, request.to_dict(), admin_access_token)
        return self._parse_response(response, str)
    
    def create_workspace(
        self,
        admin_access_token: str,
        request: CreateWorkspaceRequest
    ) -> QingflowResponse[CreateWorkspaceResponse]:
        """
        创建工作区（专有云）
        
        Args:
            admin_access_token: 环境级 Token
            request: 创建工作区请求
            
        Returns:
            创建结果
        """
        url = QingflowPathConstant.Env.CREATE_WORKSPACE
        response = self.http.post(url, request.to_dict(), admin_access_token)
        return self._parse_response(response, CreateWorkspaceResponse)
    
    def update_workspace(
        self,
        admin_access_token: str,
        request: UpdateWorkspaceRequest
    ) -> QingflowResponse[UpdateWorkspaceResponse]:
        """
        更新工作区（专有云）
        
        Args:
            admin_access_token: 环境级 Token
            request: 更新工作区请求
            
        Returns:
            更新结果
        """
        url = QingflowPathConstant.Env.UPDATE_WORKSPACE
        response = self.http.post(url, request.to_dict(), admin_access_token)
        return self._parse_response(response, UpdateWorkspaceResponse)
    
    def delete_workspace(
        self,
        admin_access_token: str,
        request: DeleteWorkspaceRequest
    ) -> QingflowResponse[DeleteWorkspaceResponse]:
        """
        删除工作区（专有云）
        
        Args:
            admin_access_token: 环境级 Token
            request: 删除工作区请求
            
        Returns:
            删除结果
        """
        url = QingflowPathConstant.Env.DELETE_WORKSPACE
        response = self.http.delete(url, request.to_dict(), admin_access_token)
        return self._parse_response(response, DeleteWorkspaceResponse)
    
    def get_workspace_info_with_ws_id(
        self,
        admin_access_token: str,
        ws_id: str
    ) -> QingflowResponse[List[GetWorkspaceInfoResponse]]:
        """
        获取工作区信息（按 WS ID）
        
        Args:
            admin_access_token: 环境级 Token
            ws_id: 工作区 ID
            
        Returns:
            工作区信息列表
        """
        url = QingflowPathConstant.Env.GET_WORKSPACE_INFO_WITH_WS_ID % ws_id
        response = self.http.get(url, admin_access_token)
        return self._parse_list_response(response, GetWorkspaceInfoResponse)
    
    def get_workspace_info_with_open_user_id(
        self,
        admin_access_token: str,
        open_user_id: str
    ) -> QingflowResponse[List[GetWorkspaceInfoResponse]]:
        """
        获取工作区信息（按 Open User ID）
        
        Args:
            admin_access_token: 环境级 Token
            open_user_id: 开放用户 ID
            
        Returns:
            工作区信息列表
        """
        url = QingflowPathConstant.Env.GET_WORKSPACE_INFO_WITH_OPEN_USER_ID % open_user_id
        response = self.http.get(url, admin_access_token)
        return self._parse_list_response(response, GetWorkspaceInfoResponse)
    
    def install_plugin(
        self,
        admin_access_token: str,
        request: InstallPluginRequest
    ) -> QingflowResponse[InstallPluginResponse]:
        """
        安装插件（专有云）
        
        Args:
            admin_access_token: 环境级 Token
            request: 安装插件请求
            
        Returns:
            安装结果
        """
        url = QingflowPathConstant.Env.INSTALL_PLUGIN
        response = self.http.post(url, request.to_dict(), admin_access_token)
        return self._parse_response(response, InstallPluginResponse)
    
    def open_qingflow_service(
        self,
        admin_access_token: str,
        request: OpenQingflowServiceRequest
    ) -> QingflowResponse[OpenQingflowServiceResponse]:
        """
        开通轻流服务（专有云）
        
        Args:
            admin_access_token: 环境级 Token
            request: 开通服务请求
            
        Returns:
            开通结果
        """
        url = QingflowPathConstant.Env.OPEN_SERVICE
        response = self.http.post(url, request.to_dict(), admin_access_token)
        return self._parse_response(response, OpenQingflowServiceResponse)
    
    def extension_pack(
        self,
        admin_access_token: str,
        request: ExtensionPackRequest
    ) -> QingflowResponse[OpenQingflowServiceResponse]:
        """
        购买扩展包（专有云）
        
        Args:
            admin_access_token: 环境级 Token
            request: 扩展包请求
            
        Returns:
            购买结果
        """
        url = QingflowPathConstant.Env.EXTENSION_PACK
        response = self.http.post(url, request.to_dict(), admin_access_token)
        return self._parse_response(response, OpenQingflowServiceResponse)
    
    # ==================== 内部方法 ====================
    
    def _parse_response(self, response, result_type):
        """解析响应"""
        data = json.loads(response.text)
        
        # 适配不同的响应格式（errCode/errMsg 或 statusCode/message）
        err_code = data.get("errCode") if data.get("errCode") is not None else data.get("statusCode")
        err_msg = data.get("errMsg") if data.get("errMsg") is not None else data.get("message")
        
        qf_response = QingflowResponse(
            err_code=err_code,
            err_msg=err_msg,
            details=data.get("details"),
            question_relations=data.get("questionRelations")
        )
        
        if data.get("result") is not None and result_type not in (str, object):
            qf_response.result = result_type.model_validate(data["result"])
        else:
            qf_response.result = data.get("result")
        
        if self.client.config.auto_assert_success:
            qf_response.raise_for_error()
        
        return qf_response
    
    def _parse_list_response(self, response, item_type):
        """解析列表响应"""
        data = json.loads(response.text)
        
        # 适配不同的响应格式（errCode/errMsg 或 statusCode/message）
        err_code = data.get("errCode") if data.get("errCode") is not None else data.get("statusCode")
        err_msg = data.get("errMsg") if data.get("errMsg") is not None else data.get("message")
        
        qf_response = QingflowResponse(
            err_code=err_code,
            err_msg=err_msg,
            details=data.get("details"),
            question_relations=data.get("questionRelations")
        )
        
        if data.get("result"):
            qf_response.result = [
                item_type.model_validate(item) for item in data["result"]
            ]
        
        if self.client.config.auto_assert_success:
            qf_response.raise_for_error()
        
        return qf_response
