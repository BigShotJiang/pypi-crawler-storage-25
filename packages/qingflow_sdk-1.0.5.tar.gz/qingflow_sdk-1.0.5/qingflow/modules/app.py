"""
应用管理模块
提供应用数据的 CRUD、流程审批、报表查询等功能
"""
import logging
import json
from typing import Optional, List, Type, TypeVar
from ..models.request import (
    GetAppDataRequest, AddAppDataRequest, UpdateAppDataRequest,
    DeleteAppDataRequest, AuditRequest, AuditRollbackRequest,
    ReassinRequest, GetAppListRequest, GetAllAppRequest,
    GetDashInfoRequest, GetTagListRequest, GetTemplateRequest
)
from ..models.response import (
    QingflowResponse, QingflowPageResponse,
    GetAccessTokenResponse, GetAppDataResponse,
    AddAppDataResponse, UpdateAppDataResponse, DeleteAppDataResponse,
    AuditRecordResponse, ReassinResponse, GetAppListResponse,
    GetAllAppInfoResponse, GetDashInfoResponse, GetTagListResponse,
    GetTemplateResponse
)
from ..constants import QingflowPathConstant
from ..utils.pagination import PaginationHelper

logger = logging.getLogger(__name__)

T = TypeVar("T")


class AppModule:
    """应用管理模块"""
    
    def __init__(self, http_client, client):
        self.http = http_client
        self.client = client
        self.pagination = PaginationHelper()
    
    # ==================== Access Token ====================
    
    def get_access_token_with_secret(
        self,
        ws_id: str,
        ws_secret: str
    ) -> QingflowResponse[GetAccessTokenResponse]:
        """
        获取 Access Token（Secret 方式）
        
        Args:
            ws_id: 工作区 ID
            ws_secret: 权限组 Secret
            
        Returns:
            Access Token 响应
        """
        url = QingflowPathConstant.App.GET_ACCESS_TOKEN_WITH_SECRET % (ws_id, ws_secret)
        response = self.http.get(url)
        return self._parse_response(response, GetAccessTokenResponse)
    
    def get_access_token_with_admin_token(
        self,
        ws_id: str,
        admin_access_token: str
    ) -> QingflowResponse[GetAccessTokenResponse]:
        """
        获取 Access Token（环境级 Token 方式）
        
        Args:
            ws_id: 工作区 ID
            admin_access_token: 环境级 Token
            
        Returns:
            Access Token 响应
        """
        url = QingflowPathConstant.App.GET_ACCESS_TOKEN_WITH_ADMIN_TOKEN % (ws_id, admin_access_token)
        response = self.http.get(url)
        return self._parse_response(response, GetAccessTokenResponse)
    
    # ==================== 应用数据 CRUD ====================
    
    def get_app_data(
        self,
        app_key: str,
        request: GetAppDataRequest,
        access_token: Optional[str] = None
    ) -> QingflowResponse[QingflowPageResponse[GetAppDataResponse]]:
        """
        获取应用数据（分页查询）
        
        Args:
            app_key: 应用 Key
            request: 查询请求
            access_token: 访问令牌（可选，默认使用客户端配置的 token）
            
        Returns:
            分页数据响应
        """
        url = QingflowPathConstant.App.GET_APP_DATA_TEMPLATE % app_key
        response = self.http.post(url, request.to_dict(), access_token)
        return self._parse_page_response(response, GetAppDataResponse)
    
    def get_app_data_single(
        self,
        app_key: str,
        request: GetAppDataRequest,
        access_token: Optional[str] = None
    ) -> Optional[GetAppDataResponse]:
        """
        获取单条应用数据
        
        Args:
            app_key: 应用 Key
            request: 查询请求（只能有一个查询条件）
            access_token: 访问令牌
            
        Returns:
            单条数据，未找到返回 None
        """
        if not request.queries or len(request.queries) != 1:
            raise ValueError("查询条件只能有一个")
        
        request.page_num = 1
        request.page_size = 1
        
        response = self.get_app_data(app_key, request, access_token)
        response.raise_for_error()
        
        if response.result and response.result.result:
            return response.result.result[0]
        return None
    
    def get_chart_data(
        self,
        chart_key: str,
        request: GetAppDataRequest,
        access_token: Optional[str] = None
    ) -> QingflowResponse[QingflowPageResponse[GetAppDataResponse]]:
        """
        获取报表数据
        
        Args:
            chart_key: 报表 Key
            request: 查询请求
            access_token: 访问令牌
            
        Returns:
            分页数据响应
        """
        url = QingflowPathConstant.App.GET_CHART_DATA_TEMPLATE % chart_key
        response = self.http.post(url, request.to_dict(), access_token)
        return self._parse_page_response(response, GetAppDataResponse)
    
    def add_app_data(
        self,
        app_key: str,
        request: AddAppDataRequest,
        access_token: Optional[str] = None
    ) -> QingflowResponse[AddAppDataResponse]:
        """
        添加应用数据
        
        Args:
            app_key: 应用 Key
            request: 添加请求
            access_token: 访问令牌
            
        Returns:
            添加结果
        """
        url = QingflowPathConstant.App.ADD_APP_DATA_TEMPLATE % app_key
        response = self.http.post(url, request.to_dict(), access_token)
        return self._parse_response(response, AddAppDataResponse)
    
    def update_app_data(
        self,
        apply_id: str,
        request: UpdateAppDataRequest,
        access_token: Optional[str] = None
    ) -> QingflowResponse[UpdateAppDataResponse]:
        """
        更新应用数据
        
        Args:
            apply_id: 数据 ID
            request: 更新请求
            access_token: 访问令牌
            
        Returns:
            更新结果
        """
        url = QingflowPathConstant.App.UPDATE_APP_DATA_TEMPLATE % apply_id
        response = self.http.post(url, request.to_dict(), access_token)
        return self._parse_response(response, UpdateAppDataResponse)
    
    def delete_app_data(
        self,
        app_key: str,
        request: DeleteAppDataRequest,
        access_token: Optional[str] = None
    ) -> str:
        """
        删除应用数据
        
        Args:
            app_key: 应用 Key
            request: 删除请求
            access_token: 访问令牌
            
        Returns:
            请求 ID
        """
        url = QingflowPathConstant.App.DELETE_APP_DATA_TEMPLATE % app_key
        response = self.http.delete(url, request.to_dict(), access_token)
        result = self._parse_response(response, DeleteAppDataResponse)
        return result.result.request_id
    
    def insert_or_update_data(
        self,
        app_key: str,
        primary_key_que_id: int,
        primary_key_value: str,
        request: AddAppDataRequest,
        access_token: Optional[str] = None
    ) -> str:
        """
        插入或更新数据（根据主键判断）
        
        Args:
            app_key: 应用 Key
            primary_key_que_id: 主键字段 ID
            primary_key_value: 主键值
            request: 数据请求
            access_token: 访问令牌
            
        Returns:
            请求 ID
        """
        # 先查询是否存在
        query_request = GetAppDataRequest.create_single_query(
            que_id=primary_key_que_id,
            search_key=primary_key_value,
            page_size=1
        )
        
        existing = self.get_app_data_single(app_key, query_request, access_token)
        
        if existing:
            # 存在则更新
            apply_id = existing.apply_id_string or str(existing.apply_id)
            update_request = UpdateAppDataRequest(
                apply_id=apply_id,
                answers=request.answers
            )
            result = self.update_app_data(apply_id, update_request, access_token)
        else:
            # 不存在则新增
            result = self.add_app_data(app_key, request, access_token)
        
        return result.result.request_id
    
    # ==================== 流程审批 ====================
    
    def audit(
        self,
        apply_id: str,
        user_id: str,
        request: AuditRequest,
        access_token: Optional[str] = None
    ) -> QingflowResponse[str]:
        """
        审批处理
        
        Args:
            apply_id: 数据 ID
            user_id: 操作用户 ID
            request: 审批请求
            access_token: 访问令牌
            
        Returns:
            审批结果
        """
        url = QingflowPathConstant.App.AUDIT_TEMPLATE % apply_id
        body = {"userId": user_id}
        body.update(request.to_dict())
        response = self.http.post(url, body, access_token)
        return self._parse_response(response, str)
    
    def audit_record(
        self,
        apply_id: str,
        access_token: Optional[str] = None
    ) -> QingflowResponse[AuditRecordResponse]:
        """
        获取流程日志
        
        Args:
            apply_id: 数据 ID
            access_token: 访问令牌
            
        Returns:
            流程日志
        """
        url = QingflowPathConstant.App.AUDIT_RECORD_TEMPLATE % apply_id
        response = self.http.get(url, access_token)
        return self._parse_response(response, AuditRecordResponse)
    
    def audit_rollback(
        self,
        apply_id: str,
        request: AuditRollbackRequest,
        access_token: Optional[str] = None
    ) -> QingflowResponse[bool]:
        """
        流程回退
        
        Args:
            apply_id: 数据 ID
            request: 回退请求
            access_token: 访问令牌
            
        Returns:
            回退结果
        """
        url = QingflowPathConstant.App.AUDIT_ROLLBACK_TEMPLATE % apply_id
        response = self.http.post(url, request.to_dict(), access_token)
        return self._parse_response(response, bool)
    
    def reassign(
        self,
        apply_id: str,
        request: ReassinRequest,
        access_token: Optional[str] = None
    ) -> QingflowResponse[ReassinResponse]:
        """
        重新指派
        
        Args:
            apply_id: 数据 ID
            request: 重新指派请求
            access_token: 访问令牌
            
        Returns:
            重新指派结果
        """
        url = QingflowPathConstant.App.REASSIN_TEMPLATE % apply_id
        response = self.http.post(url, request.to_dict(), access_token)
        return self._parse_response(response, ReassinResponse)
    
    # ==================== 应用列表 ====================
    
    def get_app_list(
        self,
        request: GetAppListRequest,
        access_token: Optional[str] = None
    ) -> QingflowResponse[QingflowPageResponse[GetAppListResponse]]:
        """
        获取应用列表
        
        Args:
            request: 查询请求
            access_token: 访问令牌
            
        Returns:
            应用列表
        """
        if request.app_key:
            url = QingflowPathConstant.App.APPS_WITH_APP_KEY % (
                request.app_key, request.page_num, request.page_size
            )
        else:
            url = QingflowPathConstant.App.APPS % (request.page_num, request.page_size)
        
        response = self.http.get(url, access_token)
        return self._parse_page_response(response, GetAppListResponse)
    
    def get_all_app(
        self,
        request: Optional[GetAllAppRequest] = None,
        access_token: Optional[str] = None
    ) -> QingflowResponse[GetAllAppInfoResponse]:
        """
        获取所有应用
        
        Args:
            request: 查询请求（可选）
            access_token: 访问令牌
            
        Returns:
            所有应用信息
        """
        if request and request.user_id:
            url = QingflowPathConstant.App.ALL_APP_WITH_USERID_FAVOURITE % (
                request.user_id, request.favourite or 0
            )
        else:
            url = QingflowPathConstant.App.ALL_APP
        
        response = self.http.get(url, access_token)
        return self._parse_response(response, GetAllAppInfoResponse)
    
    # ==================== 门户管理 ====================
    
    def get_all_dash(
        self,
        access_token: Optional[str] = None
    ) -> QingflowResponse[List[GetDashInfoResponse]]:
        """
        获取所有门户
        
        Args:
            access_token: 访问令牌
            
        Returns:
            门户列表
        """
        url = QingflowPathConstant.App.ALL_DASH
        response = self.http.get(url, access_token)
        return self._parse_list_response(response, GetDashInfoResponse)
    
    def get_dash_info(
        self,
        request: GetDashInfoRequest,
        access_token: Optional[str] = None
    ) -> QingflowResponse[QingflowPageResponse[GetDashInfoResponse]]:
        """
        获取门户详细信息
        
        Args:
            request: 查询请求
            access_token: 访问令牌
            
        Returns:
            门户信息
        """
        if request.dash_key:
            url = QingflowPathConstant.App.DASH_WITH_DASH_KEY % (
                request.dash_key, request.page_num, request.page_size
            )
        else:
            url = QingflowPathConstant.App.DASHES % (request.page_num, request.page_size)
        
        response = self.http.get(url, access_token)
        return self._parse_page_response(response, GetDashInfoResponse)
    
    # ==================== 应用包管理 ====================
    
    def get_tag_list(
        self,
        request: GetTagListRequest,
        access_token: Optional[str] = None
    ) -> QingflowResponse[QingflowPageResponse[GetTagListResponse]]:
        """
        获取应用包列表
        
        Args:
            request: 查询请求
            access_token: 访问令牌
            
        Returns:
            应用包列表
        """
        if request.tag_id:
            url = QingflowPathConstant.App.TAG_WITH_TAG_ID % (
                request.tag_id, request.page_num, request.page_size
            )
        else:
            url = QingflowPathConstant.App.TAG % (request.page_num, request.page_size)
        
        response = self.http.get(url, access_token)
        return self._parse_page_response(response, GetTagListResponse)
    
    # ==================== 打印模板 ====================
    
    def get_app_template(
        self,
        apply_id: str,
        print_key: str,
        request: Optional[GetTemplateRequest] = None,
        access_token: Optional[str] = None
    ) -> QingflowResponse[GetTemplateResponse]:
        """
        获取打印模板
        
        Args:
            apply_id: 数据 ID
            print_key: 打印模板 Key
            request: 请求参数
            access_token: 访问令牌
            
        Returns:
            模板信息
        """
        url = QingflowPathConstant.App.GET_APP_TEMPLATE_TEMPLATE % (apply_id, print_key)
        body = request.to_dict() if request else {}
        response = self.http.post(url, body, access_token)
        return self._parse_response(response, GetTemplateResponse)
    
    # ==================== 分页工具 ====================
    
    def loop_get_all_app_data(
        self,
        app_key: str,
        page_size: int = 200,
        initial_request: Optional[GetAppDataRequest] = None,
        access_token: Optional[str] = None
    ) -> List[GetAppDataResponse]:
        """
        循环获取所有应用数据
        
        Args:
            app_key: 应用 Key
            page_size: 每页大小
            initial_request: 初始查询请求
            access_token: 访问令牌
            
        Returns:
            所有数据列表
        """
        def fetch_func(page: GetAppDataRequest):
            if initial_request:
                page.queries = initial_request.queries
            return self.get_app_data(app_key, page, access_token)
        
        initial = initial_request or GetAppDataRequest(page_size=page_size)
        initial.page_size = page_size
        
        return self.pagination.loop_get_all_data(page_size, fetch_func, initial)
    
    # ==================== 异步方法 ====================
    
    async def async_get_access_token_with_secret(
        self,
        ws_id: str,
        ws_secret: str
    ) -> QingflowResponse[GetAccessTokenResponse]:
        """异步获取 Access Token（Secret 方式）"""
        url = QingflowPathConstant.App.GET_ACCESS_TOKEN_WITH_SECRET % (ws_id, ws_secret)
        response = await self.http.async_get(url)
        return self._parse_response(response, GetAccessTokenResponse)
    
    async def async_get_app_data(
        self,
        app_key: str,
        request: GetAppDataRequest,
        access_token: Optional[str] = None
    ) -> QingflowResponse[QingflowPageResponse[GetAppDataResponse]]:
        """异步获取应用数据"""
        url = QingflowPathConstant.App.GET_APP_DATA_TEMPLATE % app_key
        response = await self.http.async_post(url, request.to_dict(), access_token)
        return self._parse_page_response(response, GetAppDataResponse)
    
    async def async_add_app_data(
        self,
        app_key: str,
        request: AddAppDataRequest,
        access_token: Optional[str] = None
    ) -> QingflowResponse[AddAppDataResponse]:
        """异步添加应用数据"""
        url = QingflowPathConstant.App.ADD_APP_DATA_TEMPLATE % app_key
        response = await self.http.async_post(url, request.to_dict(), access_token)
        return self._parse_response(response, AddAppDataResponse)
    
    async def async_update_app_data(
        self,
        apply_id: str,
        request: UpdateAppDataRequest,
        access_token: Optional[str] = None
    ) -> QingflowResponse[UpdateAppDataResponse]:
        """异步更新应用数据"""
        url = QingflowPathConstant.App.UPDATE_APP_DATA_TEMPLATE % apply_id
        response = await self.http.async_post(url, request.to_dict(), access_token)
        return self._parse_response(response, UpdateAppDataResponse)
    
    async def async_delete_app_data(
        self,
        app_key: str,
        request: DeleteAppDataRequest,
        access_token: Optional[str] = None
    ) -> str:
        """异步删除应用数据"""
        url = QingflowPathConstant.App.DELETE_APP_DATA_TEMPLATE % app_key
        response = await self.http.async_delete(url, request.to_dict(), access_token)
        result = self._parse_response(response, DeleteAppDataResponse)
        return result.result.request_id
    
    async def async_loop_get_all_app_data(
        self,
        app_key: str,
        page_size: int = 200,
        initial_request: Optional[GetAppDataRequest] = None,
        access_token: Optional[str] = None
    ) -> List[GetAppDataResponse]:
        """异步循环获取所有应用数据"""
        async def fetch_func(page: GetAppDataRequest):
            if initial_request:
                page.queries = initial_request.queries
            return await self.async_get_app_data(app_key, page, access_token)
        
        initial = initial_request or GetAppDataRequest(page_size=page_size)
        initial.page_size = page_size
        
        return await self.pagination.async_loop_get_all_data(page_size, fetch_func, initial)
    
    # ==================== 内部方法 ====================
    
    def _parse_response(
        self,
        response,
        result_type: Type[T]
    ) -> QingflowResponse[T]:
        """解析响应"""
        data = json.loads(response.text)
        
        # 适配不同的响应格式
        err_code = data.get("errCode") if data.get("errCode") is not None else data.get("statusCode")
        err_msg = data.get("errMsg") if data.get("errMsg") is not None else data.get("message")
        
        # 构建响应对象
        qf_response = QingflowResponse(
            err_code=err_code,
            err_msg=err_msg,
            details=data.get("details"),
            question_relations=data.get("questionRelations")
        )
        
        # 解析 result
        if data.get("result") is not None and result_type not in (str, bool):
            qf_response.result = result_type.model_validate(data["result"])
        elif result_type == str:
            qf_response.result = data.get("result")
        elif result_type == bool:
            qf_response.result = data.get("result", False)
        else:
            qf_response.result = data.get("result")
        
        # 自动断言
        if self.client.config.auto_assert_success:
            qf_response.raise_for_error()
        
        return qf_response
    
    def _parse_page_response(
        self,
        response,
        item_type: Type[T]
    ) -> QingflowResponse[QingflowPageResponse[T]]:
        """解析分页响应"""
        data = json.loads(response.text)
        
        # 适配不同的响应格式
        err_code = data.get("errCode") if data.get("errCode") is not None else data.get("statusCode")
        err_msg = data.get("errMsg") if data.get("errMsg") is not None else data.get("message")
        
        qf_response = QingflowResponse(
            err_code=err_code,
            err_msg=err_msg,
            details=data.get("details"),
            question_relations=data.get("questionRelations")
        )
        
        if data.get("result"):
            result_data = data["result"]
            result_data["result"] = [
                item_type.model_validate(item) for item in result_data.get("result", [])
            ]
            qf_response.result = QingflowPageResponse[item_type].model_validate(result_data)
        
        if self.client.config.auto_assert_success:
            qf_response.raise_for_error()
        
        return qf_response
    
    def _parse_list_response(
        self,
        response,
        item_type: Type[T]
    ) -> QingflowResponse[List[T]]:
        """解析列表响应"""
        data = json.loads(response.text)
        
        # 适配不同的响应格式（errCode/errMsg 或 statusCode/message）
        err_code = data.get("errCode") if data.get("errCode") is not None else data.get("statusCode")
        err_msg = data.get("errMsg") if data.get("errMsg") is not None else data.get("message")
        
        qf_response = QingflowResponse(
            err_code=err_code,
            err_msg=err_msg,
            details=data.get("details"),
            question_relations=data.get("questionRelations")
        )
        
        if data.get("result"):
            qf_response.result = [
                item_type.model_validate(item) for item in data["result"]
            ]
        
        if self.client.config.auto_assert_success:
            qf_response.raise_for_error()
        
        return qf_response
