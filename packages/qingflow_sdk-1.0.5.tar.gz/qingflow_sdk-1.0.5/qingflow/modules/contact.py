"""
通讯录管理模块
提供用户管理、部门管理、角色管理、管理员管理等功能
"""
import logging
import json
import base64
from typing import Optional, List
from ..models.request import (
    UserDTO, BatchCreateUserRequest, DeptDTO, DepartmentMemberRequest,
    RoleDTO, RoleMemberRequest, ManagerDTO, GetLoginCodeRequest
)
from ..models.response import (
    QingflowResponse, QingflowPageResponse,
    UserIdDTO, GetLoginCodeResponse, GetUserByOIDCResponse,
    ManagerResponseDTO as ManagerResponse, GetUndepartedResponse,
    GetDeptListResponse, DeptIdDTO, GetDepartmentMembersResponse,
    RoleIdDTO, GetRoleMemberResponse, GetRoleListResponse,
    RequestIdDTO
)
from ..models.request import PageRequest
from ..constants import QingflowPathConstant
from ..utils.pagination import PaginationHelper

logger = logging.getLogger(__name__)


class ContactModule:
    """通讯录管理模块"""
    
    def __init__(self, http_client, client):
        self.http = http_client
        self.client = client
        self.pagination = PaginationHelper()
    
    # ==================== 用户管理 ====================
    
    def get_single_user(
        self,
        user_id: str,
        access_token: Optional[str] = None
    ) -> QingflowResponse[UserDTO]:
        """
        获取单个用户信息
        
        Args:
            user_id: 用户 ID
            access_token: 访问令牌
            
        Returns:
            用户信息
        """
        url = QingflowPathConstant.Contact.USER_REST_TEMPLATE % user_id
        response = self.http.get(url, access_token)
        return self._parse_response(response, UserDTO)
    
    def get_users(
        self,
        page: PageRequest,
        access_token: Optional[str] = None
    ) -> QingflowResponse[QingflowPageResponse[UserDTO]]:
        """
        批量获取用户列表
        
        Args:
            page: 分页参数
            access_token: 访问令牌
            
        Returns:
            用户列表
        """
        url = QingflowPathConstant.Contact.GET_ALL_USER_TEMPLATE % (
            page.page_size, page.page_num
        )
        response = self.http.get(url, access_token)
        return self._parse_page_response(response, UserDTO)
    
    def create_user(
        self,
        request: UserDTO,
        access_token: Optional[str] = None
    ) -> QingflowResponse[UserIdDTO]:
        """
        创建用户（专有云）
        
        Args:
            request: 用户信息
            access_token: 访问令牌
            
        Returns:
            创建结果
        """
        url = QingflowPathConstant.Contact.USER
        response = self.http.post(url, request.to_dict(), access_token)
        return self._parse_response(response, UserIdDTO)
    
    def update_user(
        self,
        user_id: str,
        request: UserDTO,
        access_token: Optional[str] = None
    ) -> QingflowResponse[UserIdDTO]:
        """
        更新用户（专有云）
        
        Args:
            user_id: 用户 ID
            request: 用户信息
            access_token: 访问令牌
            
        Returns:
            更新结果
        """
        url = QingflowPathConstant.Contact.USER_REST_TEMPLATE % user_id
        response = self.http.post(url, request.to_dict(), access_token)
        return self._parse_response(response, UserIdDTO)
    
    def delete_user(
        self,
        user_id: str,
        access_token: Optional[str] = None
    ) -> QingflowResponse[UserIdDTO]:
        """
        删除用户（专有云）
        
        Args:
            user_id: 用户 ID
            access_token: 访问令牌
            
        Returns:
            删除结果
        """
        url = QingflowPathConstant.Contact.USER_REST_TEMPLATE % user_id
        response = self.http.delete(url, access_token=access_token)
        return self._parse_response(response, UserIdDTO)
    
    def batch_create_users(
        self,
        request: BatchCreateUserRequest,
        access_token: Optional[str] = None
    ) -> QingflowResponse[RequestIdDTO]:
        """
        批量创建用户（专有云）
        
        Args:
            request: 批量创建请求
            access_token: 访问令牌
            
        Returns:
            请求 ID
        """
        url = QingflowPathConstant.Contact.BATCH_USER
        response = self.http.post(url, request.to_dict(), access_token)
        return self._parse_response(response, RequestIdDTO)
    
    def get_user_by_email_or_mobile(
        self,
        mobile: Optional[str] = None,
        email: Optional[str] = None,
        access_token: Optional[str] = None
    ) -> QingflowResponse[List[UserDTO]]:
        """
        根据手机号或邮箱获取用户 ID
        
        Args:
            mobile: 手机号
            email: 邮箱
            access_token: 访问令牌
            
        Returns:
            用户列表
        """
        if not email:
            url = QingflowPathConstant.Contact.GET_USER_FOR_MOBILE % (mobile or "", "")
        else:
            url = QingflowPathConstant.Contact.GET_USER_FOR_MOBILE % (mobile or "", email)
        
        response = self.http.get(url, access_token)
        return self._parse_list_response(response, UserDTO)
    
    def get_user_by_oidc(
        self,
        oidc_token: str
    ) -> QingflowResponse[GetUserByOIDCResponse]:
        """
        OIDC 获取用户信息
        
        Args:
            oidc_token: OIDC Token
            
        Returns:
            用户信息
        """
        url = QingflowPathConstant.Contact.OIDC_USER
        headers = {"oidctoken": oidc_token}
        # 使用自定义请求头
        response = self.http.sync_client.get(
            url,
            headers=headers
        )
        return self._parse_response(response, GetUserByOIDCResponse)
    
    # ==================== 部门管理 ====================
    
    def get_departments(
        self,
        access_token: Optional[str] = None
    ) -> QingflowResponse[GetDeptListResponse]:
        """
        获取部门列表
        
        Args:
            access_token: 访问令牌
            
        Returns:
            部门列表
        """
        url = QingflowPathConstant.Contact.DEPARTMENT
        response = self.http.get(url, access_token)
        return self._parse_response(response, GetDeptListResponse)
    
    def get_single_department(
        self,
        dept_id: str,
        access_token: Optional[str] = None
    ) -> QingflowResponse[GetDeptListResponse]:
        """
        获取部门列表（递归子部门）
        
        Args:
            dept_id: 部门 ID
            access_token: 访问令牌
            
        Returns:
            部门列表
        """
        url = QingflowPathConstant.Contact.DEPART_QUERY_TEMPLATE % dept_id
        response = self.http.get(url, access_token)
        return self._parse_response(response, GetDeptListResponse)
    
    def get_department_detail(
        self,
        dept_id: str,
        access_token: Optional[str] = None
    ) -> QingflowResponse[DeptDTO]:
        """
        获取单个部门详情
        
        Args:
            dept_id: 部门 ID
            access_token: 访问令牌
            
        Returns:
            部门详情
        """
        url = QingflowPathConstant.Contact.DEPARTMENT_REST_TEMPLATE % dept_id
        response = self.http.get(url, access_token)
        return self._parse_response(response, DeptDTO)
    
    def create_department(
        self,
        request: DeptDTO,
        access_token: Optional[str] = None
    ) -> QingflowResponse[DeptIdDTO]:
        """
        创建部门（专有云）
        
        Args:
            request: 部门信息
            access_token: 访问令牌
            
        Returns:
            创建结果
        """
        url = QingflowPathConstant.Contact.DEPARTMENT
        response = self.http.post(url, request.to_dict(), access_token)
        return self._parse_response(response, DeptIdDTO)
    
    def update_department(
        self,
        old_dept_id: str,
        request: DeptDTO,
        access_token: Optional[str] = None
    ) -> QingflowResponse[DeptIdDTO]:
        """
        更新部门（专有云）
        
        Args:
            old_dept_id: 原部门 ID
            request: 部门信息
            access_token: 访问令牌
            
        Returns:
            更新结果
        """
        url = QingflowPathConstant.Contact.DEPARTMENT_REST_TEMPLATE % old_dept_id
        response = self.http.post(url, request.to_dict(), access_token)
        return self._parse_response(response, DeptIdDTO)
    
    def delete_department(
        self,
        dept_id: str,
        access_token: Optional[str] = None
    ) -> QingflowResponse[DeptIdDTO]:
        """
        删除部门（专有云）
        
        Args:
            dept_id: 部门 ID
            access_token: 访问令牌
            
        Returns:
            删除结果
        """
        url = QingflowPathConstant.Contact.DEPARTMENT_REST_TEMPLATE % dept_id
        response = self.http.delete(url, access_token=access_token)
        return self._parse_response(response, DeptIdDTO)
    
    def get_department_members(
        self,
        dept_id: str,
        fetch_child: bool = False,
        access_token: Optional[str] = None
    ) -> QingflowResponse[GetDepartmentMembersResponse]:
        """
        获取部门成员列表
        
        Args:
            dept_id: 部门 ID
            fetch_child: 是否递归获取子部门成员
            access_token: 访问令牌
            
        Returns:
            部门成员列表
        """
        url = QingflowPathConstant.Contact.GET_DEPARTMENT_MEMBERS % (dept_id, fetch_child)
        response = self.http.get(url, access_token)
        return self._parse_response(response, GetDepartmentMembersResponse)
    
    def add_department_member(
        self,
        request: DepartmentMemberRequest,
        access_token: Optional[str] = None
    ) -> QingflowResponse[DeptIdDTO]:
        """
        添加部门成员（专有云）
        
        Args:
            request: 添加请求
            access_token: 访问令牌
            
        Returns:
            添加结果
        """
        url = QingflowPathConstant.Contact.DEPARTMENT_MEMBER_REST_TEMPLATE % request.dept_id
        response = self.http.post(url, request.to_dict(), access_token)
        return self._parse_response(response, DeptIdDTO)
    
    def remove_department_member(
        self,
        request: DepartmentMemberRequest,
        access_token: Optional[str] = None
    ) -> QingflowResponse[DeptIdDTO]:
        """
        移除部门成员（专有云）
        
        Args:
            request: 移除请求
            access_token: 访问令牌
            
        Returns:
            移除结果
        """
        url = QingflowPathConstant.Contact.DEPARTMENT_MEMBER_REST_TEMPLATE % request.dept_id
        response = self.http.delete(url, request.to_dict(), access_token)
        return self._parse_response(response, DeptIdDTO)
    
    # ==================== 角色管理 ====================
    
    def get_roles(
        self,
        access_token: Optional[str] = None
    ) -> QingflowResponse[GetRoleListResponse]:
        """
        获取角色列表
        
        Args:
            access_token: 访问令牌
            
        Returns:
            角色列表
        """
        url = QingflowPathConstant.Contact.ROLE
        response = self.http.get(url, access_token)
        return self._parse_response(response, GetRoleListResponse)
    
    def create_role(
        self,
        request: RoleDTO,
        access_token: Optional[str] = None
    ) -> QingflowResponse[RoleIdDTO]:
        """
        创建角色（专有云）
        
        Args:
            request: 角色信息
            access_token: 访问令牌
            
        Returns:
            创建结果
        """
        url = QingflowPathConstant.Contact.ROLE
        response = self.http.post(url, request.to_dict(), access_token)
        return self._parse_response(response, RoleIdDTO)
    
    def update_role(
        self,
        old_role_id: str,
        request: RoleDTO,
        access_token: Optional[str] = None
    ) -> QingflowResponse[RoleIdDTO]:
        """
        更新角色（专有云）
        
        Args:
            old_role_id: 原角色 ID
            request: 角色信息
            access_token: 访问令牌
            
        Returns:
            更新结果
        """
        url = QingflowPathConstant.Contact.ROLE_REST_TEMPLATE % old_role_id
        response = self.http.post(url, request.to_dict(), access_token)
        return self._parse_response(response, RoleIdDTO)
    
    def get_role_members(
        self,
        role_id: str,
        access_token: Optional[str] = None
    ) -> QingflowResponse[GetRoleMemberResponse]:
        """
        获取角色成员
        
        Args:
            role_id: 角色 ID
            access_token: 访问令牌
            
        Returns:
            角色成员列表
        """
        url = QingflowPathConstant.Contact.ROLE_MEMBER_REST_TEMPLATE % role_id
        response = self.http.get(url, access_token)
        return self._parse_response(response, GetRoleMemberResponse)
    
    def add_role_member(
        self,
        request: RoleMemberRequest,
        access_token: Optional[str] = None
    ) -> QingflowResponse[RoleIdDTO]:
        """
        添加角色成员（专有云）
        
        Args:
            request: 添加请求
            access_token: 访问令牌
            
        Returns:
            添加结果
        """
        url = QingflowPathConstant.Contact.ROLE_MEMBER_REST_TEMPLATE % request.role_id
        response = self.http.post(url, request.to_dict(), access_token)
        return self._parse_response(response, RoleIdDTO)
    
    def remove_role_member(
        self,
        request: RoleMemberRequest,
        access_token: Optional[str] = None
    ) -> QingflowResponse[RoleIdDTO]:
        """
        移除角色成员（专有云）
        
        Args:
            request: 移除请求
            access_token: 访问令牌
            
        Returns:
            移除结果
        """
        url = QingflowPathConstant.Contact.ROLE_MEMBER_REST_TEMPLATE % request.role_id
        response = self.http.delete(url, request.to_dict(), access_token)
        return self._parse_response(response, RoleIdDTO)
    
    # ==================== 管理员管理 ====================
    
    def get_managers(
        self,
        access_token: Optional[str] = None
    ) -> QingflowResponse[ManagerResponse]:
        """
        获取管理员列表
        
        Args:
            access_token: 访问令牌
            
        Returns:
            管理员列表
        """
        url = QingflowPathConstant.Contact.MANAGER
        response = self.http.get(url, access_token)
        return self._parse_response(response, ManagerResponse)
    
    def set_managers(
        self,
        manager_user_ids: List[str],
        access_token: Optional[str] = None
    ) -> QingflowResponse:
        """
        设置管理员（专有云）
        
        Args:
            manager_user_ids: 管理员用户 ID 列表
            access_token: 访问令牌
            
        Returns:
            设置结果
        """
        url = QingflowPathConstant.Contact.MANAGER
        request = ManagerDTO(manager_user_ids=manager_user_ids)
        response = self.http.post(url, request.to_dict(), access_token)
        return self._parse_response(response, object)
    
    def remove_managers(
        self,
        manager_user_ids: List[str],
        access_token: Optional[str] = None
    ) -> QingflowResponse:
        """
        移除管理员（专有云）
        
        Args:
            manager_user_ids: 管理员用户 ID 列表
            access_token: 访问令牌
            
        Returns:
            移除结果
        """
        url = QingflowPathConstant.Contact.MANAGER
        request = ManagerDTO(manager_user_ids=manager_user_ids)
        response = self.http.delete(url, request.to_dict(), access_token)
        return self._parse_response(response, object)
    
    # ==================== Code Login ====================
    
    def get_login_code(
        self,
        user_id: str,
        access_token: Optional[str] = None
    ) -> QingflowResponse[GetLoginCodeResponse]:
        """
        获取登录 Code（专有云）
        
        Args:
            user_id: 用户 ID
            access_token: 访问令牌
            
        Returns:
            登录 Code
        """
        url = QingflowPathConstant.Contact.GET_LOGIN_CODE
        request = GetLoginCodeRequest(user_id=user_id)
        response = self.http.post(url, request.to_dict(), access_token)
        return self._parse_response(response, GetLoginCodeResponse)
    
    def build_code_login_url(
        self,
        code: str,
        redirect_url: Optional[str] = None
    ) -> str:
        """
        构建 Code Login URL
        
        Args:
            code: 登录 Code
            redirect_url: 跳转地址（可选）
            
        Returns:
            Code Login URL
        """
        base_domain = self.client.config.base_domain
        
        if redirect_url:
            encoded_url = base64.b64encode(
                redirect_url.encode("utf-8")
            ).decode("utf-8")
            return (
                f"{base_domain}/code-login/?code={code}"
                f"&encodeRedirectUrl=true&redirectUrl={encoded_url}"
            )
        else:
            return f"{base_domain}/code-login/?code={code}"
    
    # ==================== 其他接口 ====================
    
    def get_undeparted_users(
        self,
        access_token: Optional[str] = None
    ) -> QingflowResponse[GetUndepartedResponse]:
        """
        获取不在部门的成员列表
        
        Args:
            access_token: 访问令牌
            
        Returns:
            未分配部门成员列表
        """
        url = QingflowPathConstant.Contact.UNDEPARTED
        response = self.http.get(url, access_token)
        return self._parse_response(response, GetUndepartedResponse)
    
    # ==================== 分页工具 ====================
    
    def loop_get_all_users(
        self,
        page_size: int = 200,
        access_token: Optional[str] = None
    ) -> List[UserDTO]:
        """
        循环获取所有用户
        
        Args:
            page_size: 每页大小
            access_token: 访问令牌
            
        Returns:
            所有用户列表
        """
        def fetch_func(page: PageRequest):
            return self.get_users(page, access_token)
        
        initial = PageRequest(page_num=1, page_size=page_size)
        return self.pagination.loop_get_all_data(page_size, fetch_func, initial)
    
    # ==================== 内部方法 ====================
    
    def _parse_response(self, response, result_type):
        """解析响应"""
        data = json.loads(response.text)
        
        # 适配不同的响应格式
        err_code = data.get("errCode") if data.get("errCode") is not None else data.get("statusCode")
        err_msg = data.get("errMsg") if data.get("errMsg") is not None else data.get("message")
        
        qf_response = QingflowResponse(
            err_code=err_code,
            err_msg=err_msg,
            details=data.get("details"),
            question_relations=data.get("questionRelations")
        )
        
        if data.get("result") is not None and result_type not in (str, object):
            qf_response.result = result_type.model_validate(data["result"])
        else:
            qf_response.result = data.get("result")
        
        if self.client.config.auto_assert_success:
            qf_response.raise_for_error()
        
        return qf_response
    
    def _parse_page_response(self, response, item_type):
        """解析分页响应"""
        data = json.loads(response.text)
        
        # 适配不同的响应格式（errCode/errMsg 或 statusCode/message）
        err_code = data.get("errCode") if data.get("errCode") is not None else data.get("statusCode")
        err_msg = data.get("errMsg") if data.get("errMsg") is not None else data.get("message")
        
        qf_response = QingflowResponse(
            err_code=err_code,
            err_msg=err_msg,
            details=data.get("details"),
            question_relations=data.get("questionRelations")
        )
        
        if data.get("result"):
            result_data = data["result"]
            result_data["result"] = [
                item_type.model_validate(item) for item in result_data.get("result", [])
            ]
            qf_response.result = QingflowPageResponse[item_type].model_validate(result_data)
        
        if self.client.config.auto_assert_success:
            qf_response.raise_for_error()
        
        return qf_response
    
    def _parse_list_response(self, response, item_type):
        """解析列表响应"""
        data = json.loads(response.text)
        
        # 适配不同的响应格式（errCode/errMsg 或 statusCode/message）
        err_code = data.get("errCode") if data.get("errCode") is not None else data.get("statusCode")
        err_msg = data.get("errMsg") if data.get("errMsg") is not None else data.get("message")
        
        qf_response = QingflowResponse(
            err_code=err_code,
            err_msg=err_msg,
            details=data.get("details"),
            question_relations=data.get("questionRelations")
        )
        
        if data.get("result"):
            qf_response.result = [
                item_type.model_validate(item) for item in data["result"]
            ]
        
        if self.client.config.auto_assert_success:
            qf_response.raise_for_error()
        
        return qf_response
