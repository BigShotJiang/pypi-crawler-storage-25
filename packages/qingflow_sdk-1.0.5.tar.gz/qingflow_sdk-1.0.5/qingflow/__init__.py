"""
轻流 OpenAPI Python SDK

提供轻流无代码平台的完整 API 封装，支持：
- 应用管理（App）：数据 CRUD、流程审批、报表查询
- 环境管理（Env）：用户管理、工作区管理、服务开通
- 通讯录管理（Contact）：用户/部门/角色管理

使用示例：
    from qingflow import QingflowClient
    
    # 初始化客户端
    client = QingflowClient(access_token="your-token")
    
    # 获取应用数据
    from qingflow.models import GetAppDataRequest, QueryCondition
    
    request = GetAppDataRequest(
        page_num=1,
        page_size=20,
        queries=[QueryCondition(que_id=1001, search_key="张三")]
    )
    response = client.app.get_app_data("customer_mgmt", request)
    
    if response.is_success:
        for item in response.result.result:
            print(f"Apply ID: {item.apply_id}")
"""
__version__ = "1.0.0"
__author__ = "高文伟"
__license__ = "MIT"

# 导出核心类
from .client import QingflowClient
from .config import QingflowConfig
from .exceptions import (
    QingflowError,
    QingflowAPIError,
    QingflowAuthenticationError,
    QingflowPermissionError,
    QingflowRateLimitError,
    QingflowResourceNotFoundError,
    QingflowValidationError,
    QingflowConfigurationError,
    QingflowTimeoutError,
    QingflowConnectionError
)

# 导出模型
from .models.base import (
    PageRequest, QueryCondition, AnswerDTO, ValueDTO, ApplyUserDTO
)
from .models.request import (
    GetAppDataRequest, AddAppDataRequest, UpdateAppDataRequest,
    DeleteAppDataRequest, AuditRequest, AuditRollbackRequest,
    ReassinRequest, GetAppListRequest, GetAllAppRequest,
    GetDashInfoRequest, GetTagListRequest, GetTemplateRequest,
    GetAdminAccessTokenRequest, CreateUserForQingflowRequest,
    GetUserIdInfoRequest, VerificationRequest, UpdateUserPasswordRequest,
    CreateWorkspaceRequest, UpdateWorkspaceRequest, DeleteWorkspaceRequest,
    OpenQingflowServiceRequest, ExtensionPackRequest, InstallPluginRequest,
    UserDTO, BatchCreateUserRequest, DeptDTO, DepartmentMemberRequest,
    RoleDTO, RoleMemberRequest, ManagerDTO, GetLoginCodeRequest
)

from .models.response import (
    QingflowResponse, QingflowPageResponse,
    GetAccessTokenResponse, GetAppDataResponse,
    AddAppDataResponse, UpdateAppDataResponse, DeleteAppDataResponse,
    AuditRecordResponse, ReassinResponse, GetAppListResponse,
    GetAllAppInfoResponse, GetDashInfoResponse, GetTagListResponse,
    GetTemplateResponse, GetAdminAccessTokenResponse, CreateUserResponse,
    GetUserIdInfoResponse, CreateWorkspaceResponse,
    UpdateWorkspaceResponse, DeleteWorkspaceResponse,
    GetWorkspaceInfoResponse, OpenQingflowServiceResponse,
    InstallPluginResponse, UserIdDTO, GetLoginCodeResponse,
    GetUserByOIDCResponse, ManagerResponseDTO,
    GetUndepartedResponse, GetDeptListResponse, DeptIdDTO,
    GetDepartmentMembersResponse, RoleIdDTO, GetRoleMemberResponse,
    GetRoleListResponse, RequestIdDTO
)

# 导出常量
from .constants import QingflowPathConstant, QingflowErrorCode, AuditResult

# 导出工具类
from .utils.pagination import PaginationHelper

# 导出应用数据模型（类似 Java SDK @AppDataField 注解）
from .models.app_data import AppDataModel, app_data_field

__all__ = [
    # 版本信息
    "__version__",
    "__author__",
    "__license__",
    
    # 核心类
    "QingflowClient",
    "QingflowConfig",
    
    # 异常类
    "QingflowError",
    "QingflowAPIError",
    "QingflowAuthenticationError",
    "QingflowPermissionError",
    "QingflowRateLimitError",
    "QingflowResourceNotFoundError",
    "QingflowValidationError",
    "QingflowConfigurationError",
    "QingflowTimeoutError",
    "QingflowConnectionError",
    
    # 请求模型
    "GetAppDataRequest",
    "AddAppDataRequest",
    "UpdateAppDataRequest",
    "DeleteAppDataRequest",
    "AuditRequest",
    "AuditRollbackRequest",
    "ReassinRequest",
    "GetAppListRequest",
    "GetAllAppRequest",
    "GetDashInfoRequest",
    "GetTagListRequest",
    "GetTemplateRequest",
    "GetAdminAccessTokenRequest",
    "CreateUserForQingflowRequest",
    "GetUserIdInfoRequest",
    "VerificationRequest",
    "UpdateUserPasswordRequest",
    "CreateWorkspaceRequest",
    "UpdateWorkspaceRequest",
    "DeleteWorkspaceRequest",
    "OpenQingflowServiceRequest",
    "ExtensionPackRequest",
    "InstallPluginRequest",
    "UserDTO",
    "BatchCreateUserRequest",
    "DeptDTO",
    "DepartmentMemberRequest",
    "RoleDTO",
    "RoleMemberRequest",
    "ManagerDTO",
    "GetLoginCodeRequest",
    "PageRequest",
    "QueryCondition",
    "AnswerDTO",
    "ValueDTO",
    "ApplyUserDTO",
    
    # 响应模型
    "QingflowResponse",
    "QingflowPageResponse",
    "GetAccessTokenResponse",
    "GetAppDataResponse",
    "AddAppDataResponse",
    "UpdateAppDataResponse",
    "DeleteAppDataResponse",
    "AuditRecordResponse",
    "ReassinResponse",
    "GetAppListResponse",
    "GetAllAppInfoResponse",
    "GetDashInfoResponse",
    "GetTagListResponse",
    "GetTemplateResponse",
    "GetAdminAccessTokenResponse",
    "CreateUserResponse",
    "GetUserIdInfoResponse",
    "CreateWorkspaceResponse",
    "UpdateWorkspaceResponse",
    "DeleteWorkspaceResponse",
    "GetWorkspaceInfoResponse",
    "OpenQingflowServiceResponse",
    "InstallPluginResponse",
    "UserIdDTO",
    "GetLoginCodeResponse",
    "GetUserByOIDCResponse",
    "ManagerResponseDTO",
    "GetUndepartedResponse",
    "GetDeptListResponse",
    "DeptIdDTO",
    "GetDepartmentMembersResponse",
    "RoleIdDTO",
    "GetRoleMemberResponse",
    "GetRoleListResponse",
    "RequestIdDTO",
    
    # 常量
    "QingflowPathConstant",
    "QingflowErrorCode",
    "AuditResult",
    
    # 工具类
    "PaginationHelper",
    
    # 应用数据模型（类似 Java SDK @AppDataField 注解）
    "AppDataModel",
    "app_data_field",
]
