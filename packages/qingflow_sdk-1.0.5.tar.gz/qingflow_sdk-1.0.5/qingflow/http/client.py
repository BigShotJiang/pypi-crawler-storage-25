"""
HTTP 客户端模块
基于 httpx 封装，支持同步/异步、重试、超时
"""
import httpx
import logging
from typing import Optional, Dict, Any, Union
from .retry import RetryStrategy
from .timeout import TimeoutConfig
from ..config import QingflowConfig
from ..exceptions import (
    QingflowTimeoutError,
    QingflowConnectionError,
    QingflowAPIError,
    create_error_from_response
)

logger = logging.getLogger(__name__)


class HTTPClient:
    """HTTP 客户端"""
    
    def __init__(
        self,
        config: QingflowConfig,
        retry_strategy: Optional[RetryStrategy] = None,
        timeout_config: Optional[TimeoutConfig] = None
    ):
        self.config = config
        self.retry_strategy = retry_strategy or RetryStrategy(
            max_retries=config.max_retries,
            backoff=config.retry_backoff
        )
        self.timeout_config = timeout_config or TimeoutConfig(
            timeout=config.timeout,
            connect_timeout=config.connect_timeout
        )
        
        # 创建同步客户端
        self._sync_client: Optional[httpx.Client] = None
        # 创建异步客户端
        self._async_client: Optional[httpx.AsyncClient] = None
    
    @property
    def sync_client(self) -> httpx.Client:
        """获取同步客户端（懒加载）"""
        if self._sync_client is None:
            self._sync_client = httpx.Client(
                base_url=self.config.api_base_url,
                timeout=self.timeout_config.to_httpx_timeout(),
                limits=httpx.Limits(
                    max_connections=self.config.max_connections,
                    max_keepalive_connections=self.config.max_keepalive_connections
                ),
                headers=self._get_default_headers()
            )
        return self._sync_client
    
    @property
    def async_client(self) -> httpx.AsyncClient:
        """获取异步客户端（懒加载）"""
        if self._async_client is None:
            self._async_client = httpx.AsyncClient(
                base_url=self.config.api_base_url,
                timeout=self.timeout_config.to_httpx_timeout(),
                limits=httpx.Limits(
                    max_connections=self.config.max_connections,
                    max_keepalive_connections=self.config.max_keepalive_connections
                ),
                headers=self._get_default_headers()
            )
        return self._async_client
    
    def _get_default_headers(self) -> Dict[str, str]:
        """获取默认请求头"""
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "Qingflow-Python-SDK/1.0.0"
        }
        if self.config.access_token_str:
            headers["accessToken"] = self.config.access_token_str
        return headers
    
    def _get_headers(self, access_token: Optional[str] = None) -> Dict[str, str]:
        """获取请求头"""
        headers = self._get_default_headers()
        if access_token:
            headers["accessToken"] = access_token
        return headers
    
    def _log_request(self, method: str, url: str, headers: Dict, json_data: Any = None) -> None:
        """记录请求日志"""
        if self.config.log_requests:
            logger.debug(
                f"Request: {method} {url} | Headers: {headers} | Body: {json_data}"
            )
    
    def _log_response(self, status_code: int, response_text: str) -> None:
        """记录响应日志"""
        if self.config.log_responses:
            logger.debug(
                f"Response: {status_code} | Body: {response_text[:500]}"
            )
    
    # ==================== 同步方法 ====================
    
    def get(
        self,
        path: str,
        access_token: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None
    ) -> httpx.Response:
        """发送 GET 请求"""
        headers = self._get_headers(access_token)
        self._log_request("GET", path, headers)
        
        try:
            response = self.sync_client.get(
                path,
                headers=headers,
                params=params
            )
            self._log_response(response.status_code, response.text)
            return response
        except httpx.TimeoutException as e:
            raise QingflowTimeoutError(f"请求超时：{path}") from e
        except httpx.ConnectError as e:
            raise QingflowConnectionError(f"连接失败：{path}") from e
    
    def post(
        self,
        path: str,
        json_data: Any = None,
        access_token: Optional[str] = None
    ) -> httpx.Response:
        """发送 POST 请求"""
        headers = self._get_headers(access_token)
        self._log_request("POST", path, headers, json_data)
        
        try:
            response = self.sync_client.post(
                path,
                json=json_data,
                headers=headers
            )
            self._log_response(response.status_code, response.text)
            return response
        except httpx.TimeoutException as e:
            raise QingflowTimeoutError(f"请求超时：{path}") from e
        except httpx.ConnectError as e:
            raise QingflowConnectionError(f"连接失败：{path}") from e
    
    def delete(
        self,
        path: str,
        json_data: Any = None,
        access_token: Optional[str] = None
    ) -> httpx.Response:
        """发送 DELETE 请求"""
        headers = self._get_headers(access_token)
        self._log_request("DELETE", path, headers, json_data)
        
        try:
            response = self.sync_client.request(
                "DELETE",
                path,
                json=json_data,
                headers=headers
            )
            self._log_response(response.status_code, response.text)
            return response
        except httpx.TimeoutException as e:
            raise QingflowTimeoutError(f"请求超时：{path}") from e
        except httpx.ConnectError as e:
            raise QingflowConnectionError(f"连接失败：{path}") from e
    
    # ==================== 异步方法 ====================
    
    async def async_get(
        self,
        path: str,
        access_token: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None
    ) -> httpx.Response:
        """发送异步 GET 请求"""
        headers = self._get_headers(access_token)
        self._log_request("GET", path, headers)
        
        try:
            response = await self.async_client.get(
                path,
                headers=headers,
                params=params
            )
            self._log_response(response.status_code, response.text)
            return response
        except httpx.TimeoutException as e:
            raise QingflowTimeoutError(f"请求超时：{path}") from e
        except httpx.ConnectError as e:
            raise QingflowConnectionError(f"连接失败：{path}") from e
    
    async def async_post(
        self,
        path: str,
        json_data: Any = None,
        access_token: Optional[str] = None
    ) -> httpx.Response:
        """发送异步 POST 请求"""
        headers = self._get_headers(access_token)
        self._log_request("POST", path, headers, json_data)
        
        try:
            response = await self.async_client.post(
                path,
                json=json_data,
                headers=headers
            )
            self._log_response(response.status_code, response.text)
            return response
        except httpx.TimeoutException as e:
            raise QingflowTimeoutError(f"请求超时：{path}") from e
        except httpx.ConnectError as e:
            raise QingflowConnectionError(f"连接失败：{path}") from e
    
    async def async_delete(
        self,
        path: str,
        json_data: Any = None,
        access_token: Optional[str] = None
    ) -> httpx.Response:
        """发送异步 DELETE 请求"""
        headers = self._get_headers(access_token)
        self._log_request("DELETE", path, headers, json_data)
        
        try:
            response = await self.async_client.request(
                "DELETE",
                path,
                json=json_data,
                headers=headers
            )
            self._log_response(response.status_code, response.text)
            return response
        except httpx.TimeoutException as e:
            raise QingflowTimeoutError(f"请求超时：{path}") from e
        except httpx.ConnectError as e:
            raise QingflowConnectionError(f"连接失败：{path}") from e
    
    # ==================== 上下文管理 ====================
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.aclose()
    
    def close(self) -> None:
        """关闭同步客户端"""
        if self._sync_client:
            self._sync_client.close()
            self._sync_client = None
    
    async def aclose(self) -> None:
        """关闭异步客户端"""
        if self._async_client:
            await self._async_client.aclose()
            self._async_client = None
