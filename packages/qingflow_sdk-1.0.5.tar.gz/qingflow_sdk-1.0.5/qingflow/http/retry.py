"""
重试策略模块
支持指数退避重试
"""
import time
import logging
from typing import Callable, Optional
import httpx

logger = logging.getLogger(__name__)


class RetryStrategy:
    """重试策略"""
    
    def __init__(
        self,
        max_retries: int = 3,
        backoff: float = 1.0,
        retry_on_status: Optional[list[int]] = None
    ):
        self.max_retries = max_retries
        self.backoff = backoff
        self.retry_on_status = retry_on_status or [429, 500, 502, 503, 504]
    
    def execute_with_retry(
        self,
        func: Callable,
        *args,
        **kwargs
    ):
        """执行带重试的函数"""
        last_exception = None
        
        for attempt in range(self.max_retries + 1):
            try:
                response = func(*args, **kwargs)
                
                # 检查是否需要重试
                if response.status_code in self.retry_on_status:
                    if attempt < self.max_retries:
                        wait_time = self.backoff * (2 ** attempt)
                        logger.warning(
                            f"请求失败 (status={response.status_code})，"
                            f"第 {attempt + 1} 次重试，等待 {wait_time}s"
                        )
                        time.sleep(wait_time)
                        continue
                    else:
                        raise httpx.HTTPStatusError(
                            f"请求失败，已达最大重试次数",
                            request=response.request,
                            response=response
                        )
                
                # 检查 HTTP 状态码
                response.raise_for_status()
                return response
                
            except httpx.HTTPStatusError as e:
                last_exception = e
                if e.response.status_code in self.retry_on_status and attempt < self.max_retries:
                    wait_time = self.backoff * (2 ** attempt)
                    logger.warning(
                        f"HTTP 错误 (status={e.response.status_code})，"
                        f"第 {attempt + 1} 次重试，等待 {wait_time}s"
                    )
                    time.sleep(wait_time)
                    continue
                raise
            except Exception as e:
                last_exception = e
                if attempt < self.max_retries:
                    wait_time = self.backoff * (2 ** attempt)
                    logger.warning(
                        f"请求异常 ({type(e).__name__})，"
                        f"第 {attempt + 1} 次重试，等待 {wait_time}s"
                    )
                    time.sleep(wait_time)
                    continue
                raise
        
        raise last_exception
