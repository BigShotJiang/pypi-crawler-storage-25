"""
超时控制模块
"""
from dataclasses import dataclass
from typing import Optional
import httpx


@dataclass
class TimeoutConfig:
    """超时配置"""
    
    timeout: float = 30.0              # 总超时
    connect_timeout: float = 10.0      # 连接超时
    read_timeout: Optional[float] = None  # 读取超时
    write_timeout: Optional[float] = None # 写入超时
    
    def to_httpx_timeout(self) -> httpx.Timeout:
        """转换为 httpx.Timeout"""
        return httpx.Timeout(
            timeout=self.timeout,
            connect=self.connect_timeout,
            read=self.read_timeout,
            write=self.write_timeout
        )
