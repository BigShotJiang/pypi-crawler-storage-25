"""
异常模块测试
"""
import pytest
from qingflow.exceptions import (
    QingflowError,
    QingflowAPIError,
    QingflowAuthenticationError,
    QingflowPermissionError,
    QingflowRateLimitError,
    QingflowResourceNotFoundError,
    QingflowValidationError,
    QingflowConfigurationError,
    QingflowTimeoutError,
    QingflowConnectionError,
    create_error_from_response,
)


class TestQingflowError:
    """基础异常测试"""

    def test_basic_error(self):
        """测试基础异常"""
        error = QingflowError("Something went wrong")
        assert error.message == "Something went wrong"
        assert error.err_code is None
        assert str(error) == "QingflowError: Something went wrong"

    def test_error_with_code(self):
        """测试带错误码的异常"""
        error = QingflowError("API error", err_code=40001)
        assert str(error) == "QingflowError [40001]: API error"

    def test_error_with_details(self):
        """测试带详细信息的异常"""
        error = QingflowError("Error", err_code=500, details={"key": "value"})
        assert error.details == {"key": "value"}


class TestQingflowAPIError:
    """API 异常测试"""

    def test_api_error_basic(self):
        """测试基础 API 异常"""
        error = QingflowAPIError("API failed", err_code=40000)
        assert error.message == "API failed"
        assert error.err_code == 40000
        assert error.status_code is None
        assert error.request_id is None

    def test_api_error_with_status(self):
        """测试带 HTTP 状态码的 API 异常"""
        error = QingflowAPIError(
            "Not found", err_code=40003, status_code=404, request_id="req-123"
        )
        assert "HTTP 404" in str(error)
        assert "req-123" in str(error)


class TestSpecificErrors:
    """具体异常类型测试"""

    def test_authentication_error(self):
        error = QingflowAuthenticationError("Token expired", err_code=40001)
        assert isinstance(error, QingflowAPIError)
        assert isinstance(error, QingflowError)

    def test_permission_error(self):
        error = QingflowPermissionError("No permission", err_code=40002)
        assert isinstance(error, QingflowAPIError)

    def test_rate_limit_error(self):
        error = QingflowRateLimitError("Too many requests", err_code=40004, retry_after=60)
        assert error.retry_after == 60

    def test_resource_not_found_error(self):
        error = QingflowResourceNotFoundError("User not found", err_code=40003)
        assert isinstance(error, QingflowAPIError)

    def test_validation_error(self):
        error = QingflowValidationError("Invalid parameter")
        assert isinstance(error, QingflowError)
        assert not isinstance(error, QingflowAPIError)

    def test_configuration_error(self):
        error = QingflowConfigurationError("Missing access_token")
        assert isinstance(error, QingflowError)

    def test_timeout_error(self):
        error = QingflowTimeoutError("Request timeout")
        assert isinstance(error, QingflowError)

    def test_connection_error(self):
        error = QingflowConnectionError("Connection refused")
        assert isinstance(error, QingflowError)


class TestCreateErrorFromResponse:
    """根据响应创建异常测试"""

    def test_create_auth_error(self):
        error = create_error_from_response(err_code=40001, err_msg="认证失败")
        assert isinstance(error, QingflowAuthenticationError)
        assert error.err_code == 40001

    def test_create_permission_error(self):
        error = create_error_from_response(err_code=40002, err_msg="权限不足")
        assert isinstance(error, QingflowPermissionError)

    def test_create_rate_limit_error(self):
        error = create_error_from_response(err_code=40004, err_msg="频率限制")
        assert isinstance(error, QingflowRateLimitError)

    def test_create_resource_not_found_error(self):
        error = create_error_from_response(err_code=40003, err_msg="资源不存在")
        assert isinstance(error, QingflowResourceNotFoundError)

    def test_create_generic_api_error(self):
        error = create_error_from_response(err_code=50000, err_msg="服务器错误")
        assert isinstance(error, QingflowAPIError)
        assert not isinstance(error, QingflowAuthenticationError)

    def test_error_code_map_fallback(self):
        """测试错误码映射回退"""
        error = create_error_from_response(err_code=40000, err_msg="")
        assert error.message == "参数错误"

    def test_with_status_code_and_request_id(self):
        error = create_error_from_response(
            err_code=40001,
            err_msg="认证失败",
            status_code=401,
            request_id="req-abc",
        )
        assert error.status_code == 401
        assert error.request_id == "req-abc"
