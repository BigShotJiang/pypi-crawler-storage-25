"""
配置模块测试
"""
import pytest
from qingflow.config import QingflowConfig, ClientType, LogLevel, get_config, set_config
from pydantic import SecretStr


class TestQingflowConfig:
    """配置类测试"""

    def test_default_config(self):
        """测试默认配置值"""
        config = QingflowConfig()
        assert config.base_domain == "https://api.qingflow.com"
        assert config.client_type == ClientType.SYNC
        assert config.timeout == 30.0
        assert config.connect_timeout == 10.0
        assert config.max_retries == 3
        assert config.retry_backoff == 1.0
        assert config.max_connections == 100
        assert config.auto_assert_success is False
        assert config.log_level == LogLevel.INFO
        assert config.log_requests is False
        assert config.log_responses is False

    def test_custom_config(self):
        """测试自定义配置"""
        config = QingflowConfig(
            access_token="my-token",
            base_domain="https://custom.qingflow.com",
            client_type=ClientType.ASYNC,
            timeout=60.0,
            max_retries=5,
            auto_assert_success=True,
            log_level=LogLevel.DEBUG,
        )
        assert config.access_token_str == "my-token"
        assert config.base_domain == "https://custom.qingflow.com"
        assert config.client_type == ClientType.ASYNC
        assert config.timeout == 60.0
        assert config.max_retries == 5
        assert config.auto_assert_success is True
        assert config.log_level == LogLevel.DEBUG

    def test_api_base_url(self):
        """测试 API 基础 URL 生成"""
        config = QingflowConfig(base_domain="https://api.qingflow.com")
        assert config.api_base_url == "https://api.qingflow.com/openApi"

        config2 = QingflowConfig(base_domain="https://api.qingflow.com/")
        assert config2.api_base_url == "https://api.qingflow.com/openApi"

    def test_access_token_str(self):
        """测试 access_token 字符串获取"""
        config = QingflowConfig(access_token="secret-token")
        assert config.access_token_str == "secret-token"

        config2 = QingflowConfig()
        assert config2.access_token_str is None

    def test_env_secret_str(self):
        """测试 env_secret 字符串获取"""
        config = QingflowConfig(env_secret="my-env-secret")
        assert config.env_secret_str == "my-env-secret"

        config2 = QingflowConfig()
        assert config2.env_secret_str is None

    def test_secret_str_protection(self):
        """测试 SecretStr 保护（repr 不显示明文）"""
        config = QingflowConfig(access_token="sensitive-token")
        config_repr = repr(config)
        assert "sensitive-token" not in config_repr


class TestConfigSingleton:
    """全局配置单例测试"""

    def test_get_config(self):
        """测试获取全局配置"""
        config = get_config()
        assert isinstance(config, QingflowConfig)

    def test_set_config(self):
        """测试设置全局配置"""
        new_config = QingflowConfig(access_token="new-token")
        set_config(new_config)
        assert get_config() is new_config
        assert get_config().access_token_str == "new-token"
