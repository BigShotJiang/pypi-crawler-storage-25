"""
主客户端测试
"""
import pytest
from unittest.mock import MagicMock, patch

from qingflow import QingflowClient, QingflowConfig
from qingflow.modules.app import AppModule
from qingflow.modules.env import EnvModule
from qingflow.modules.contact import ContactModule


class TestQingflowClient:
    """主客户端测试"""

    def test_basic_initialization(self):
        """测试基础初始化"""
        client = QingflowClient(access_token="test-token")
        assert client.config.access_token_str == "test-token"
        assert client.config.base_domain == "https://api.qingflow.com"
        assert isinstance(client.app, AppModule)
        assert isinstance(client.env, EnvModule)
        assert isinstance(client.contact, ContactModule)

    def test_custom_initialization(self):
        """测试自定义初始化"""
        client = QingflowClient(
            access_token="custom-token",
            base_domain="https://custom.qingflow.com",
            timeout=60.0,
            max_retries=5,
            auto_assert_success=True,
            log_level="DEBUG",
            log_requests=True,
        )
        assert client.config.access_token_str == "custom-token"
        assert client.config.base_domain == "https://custom.qingflow.com"
        assert client.config.timeout == 60.0
        assert client.config.max_retries == 5
        assert client.config.auto_assert_success is True
        assert client.config.log_level.value == "DEBUG"
        assert client.config.log_requests is True

    def test_get_access_token(self):
        """测试获取 access token"""
        client = QingflowClient(access_token="my-token")
        assert client.get_access_token() == "my-token"

    def test_set_access_token(self):
        """测试设置 access token"""
        client = QingflowClient(access_token="old-token")
        client.set_access_token("new-token")
        assert client.get_access_token() == "new-token"

    def test_with_token_context(self):
        """测试临时切换 token"""
        client = QingflowClient(access_token="main-token")
        assert client.get_access_token() == "main-token"

        with client.with_token("temp-token"):
            assert client.get_access_token() == "temp-token"

        # 退出上下文后恢复
        assert client.get_access_token() == "main-token"

    def test_context_manager(self):
        """测试上下文管理"""
        with QingflowClient(access_token="test-token") as client:
            assert client.config.access_token_str == "test-token"

    def test_close(self):
        """测试关闭客户端"""
        client = QingflowClient(access_token="test-token")
        # 触发 HTTP 客户端懒加载
        _ = client.http_client.sync_client
        client.close()
        assert client.http_client._sync_client is None

    @pytest.mark.asyncio
    async def test_async_close(self):
        """测试异步关闭客户端"""
        client = QingflowClient(access_token="test-token", client_type="async")
        # 触发异步客户端懒加载
        _ = client.http_client.async_client
        await client.aclose()
        assert client.http_client._async_client is None

    @pytest.mark.asyncio
    async def test_async_context_manager(self):
        """测试异步上下文管理"""
        async with QingflowClient(access_token="test-token", client_type="async") as client:
            assert client.config.access_token_str == "test-token"

    def test_from_env(self):
        """测试从环境变量初始化"""
        with patch.dict("os.environ", {"QINGFLOW_ACCESS_TOKEN": "env-token"}):
            client = QingflowClient.from_env()
            assert client.config.access_token_str == "env-token"

    def test_from_config_file(self, tmp_path):
        """测试从配置文件初始化"""
        import yaml
        config_data = {
            "access_token": "file-token",
            "base_domain": "https://file.qingflow.com",
            "timeout": 45.0,
        }
        config_file = tmp_path / "config.yaml"
        config_file.write_text(yaml.dump(config_data))

        client = QingflowClient.from_config_file(str(config_file))
        assert client.config.access_token_str == "file-token"
        assert client.config.base_domain == "https://file.qingflow.com"
        assert client.config.timeout == 45.0

    def test_module_references(self):
        """测试模块引用正确性"""
        client = QingflowClient(access_token="test-token")
        # 确保模块持有正确的 client 引用
        assert client.app.client is client
        assert client.env.client is client
        assert client.contact.client is client
