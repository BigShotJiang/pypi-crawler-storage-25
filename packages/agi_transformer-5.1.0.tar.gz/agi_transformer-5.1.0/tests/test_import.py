"""
Smoke test: verify package imports and basic forward pass.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

import torch
from agi_core import AGiConfig, AGiTransformer


def test_import():
    assert AGiTransformer is not None


def test_forward():
    config = AGiConfig(vocab_size=100, d_model=64, n_layers=2, n_heads=2, max_seq_len=32)
    model = AGiTransformer(config)
    x = torch.randint(0, 100, (2, 16))
    logits, loss = model(x, x)
    assert logits.shape == (2, 16, 100)
    assert loss is not None
    assert not torch.isnan(loss)


def test_generate():
    config = AGiConfig(vocab_size=100, d_model=64, n_layers=2, n_heads=2)
    model = AGiTransformer(config)
    model.eval()
    x = torch.randint(0, 100, (1, 5))
    with torch.no_grad():
        out = model.generate(x, max_new_tokens=3)
    assert out.shape[1] == 8


if __name__ == "__main__":
    test_import()
    test_forward()
    test_generate()
    print("All tests passed!")
