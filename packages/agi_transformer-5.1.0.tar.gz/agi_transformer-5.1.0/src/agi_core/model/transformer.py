"""
AGi Transformer v5.1 — Full Model
Parallel blocks + Mamba hybrid + FP4 quantization.
"""
import torch
import torch.nn as nn
from agi_core.config import AGiConfig
from agi_core.layers.parallel_block import ParallelBlock


class AGiTransformer(nn.Module):
    """Full transformer with parallel blocks and Mamba layers."""
    def __init__(self, config: AGiConfig):
        super().__init__()
        self.config = config
        self.embed = nn.Embedding(config.vocab_size, config.d_model)

        self.blocks = nn.ModuleList([
            ParallelBlock(
                d_model=config.d_model,
                n_heads=config.n_heads,
                mla_ratio=config.mla_compression_ratio,
                use_mamba=(i in config.mamba_layer_indices),
                dropout=config.dropout,
            )
            for i in range(config.n_layers)
        ])

        self.ln_f = nn.RMSNorm(config.d_model)
        self.lm_head = nn.Linear(config.d_model, config.vocab_size, bias=False)
        self.lm_head.weight = self.embed.weight  # Tied

    def forward(self, input_ids, targets=None):
        x = self.embed(input_ids)
        for block in self.blocks:
            x = block(x)
        x = self.ln_f(x)
        logits = self.lm_head(x)

        loss = None
        if targets is not None:
            loss = nn.functional.cross_entropy(
                logits.view(-1, logits.size(-1)), targets.view(-1)
            )
        return logits, loss

    @torch.no_grad()
    def generate(self, input_ids, max_new_tokens=20, temperature=1.0):
        self.eval()
        for _ in range(max_new_tokens):
            logits, _ = self.forward(input_ids)
            logits = logits[:, -1, :] / temperature
            probs = torch.softmax(logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)
            input_ids = torch.cat([input_ids, next_token], dim=1)
        return input_ids
