"""
AGi Transformer v5.1 — Configuration
Optimized for accuracy and extensibility.
"""
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class AGiConfig:
    """Model and training configuration."""
    # Model
    vocab_size: int = 32000
    d_model: int = 512
    n_layers: int = 8
    n_heads: int = 8
    head_dim: int = 64  # d_model // n_heads if not set
    mla_compression_ratio: int = 4
    max_seq_len: int = 2048
    dropout: float = 0.0

    # Quantization
    weight_format: str = "fp4_e2m1"  # fp4_e2m1 | nf4 | int8
    group_size: int = 64
    outlier_thresh: float = 3.0
    use_smoothquant: bool = True
    smoothquant_alpha_scalar: float = 0.5  # fallback

    # Architecture switches
    use_parallel_block: bool = True
    use_mamba_layers: bool = True
    mamba_layer_indices: List[int] = field(default_factory=list)
    mamba_d_state: int = 16
    mamba_expand: int = 2

    # Training
    lr: float = 1e-3
    weight_decay: float = 0.01
    grad_clip: float = 1.0
    warmup_steps: int = 100

    def __post_init__(self):
        if self.head_dim is None:
            self.head_dim = self.d_model // self.n_heads
        if not self.mamba_layer_indices and self.use_mamba_layers:
            mid = self.n_layers // 2
            self.mamba_layer_indices = [mid - 2, mid - 1, mid, mid + 1]
        # Clamp indices to valid range
        self.mamba_layer_indices = [
            i for i in self.mamba_layer_indices if 0 <= i < self.n_layers
        ]
