"""
AGi Transformer v5.1 — Advanced Core Library
Public API exports.
"""
__version__ = "5.1.0"

from agi_core.config import AGiConfig
from agi_core.model.transformer import AGiTransformer

__all__ = ["AGiConfig", "AGiTransformer", "__version__"]
