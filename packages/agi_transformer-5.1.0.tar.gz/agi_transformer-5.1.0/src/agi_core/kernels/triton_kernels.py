"""
AGi Transformer v5.1 — Triton Kernels
Core kernels: FP4 GEMM, Dynamic Outlier Split, Double Buffering.
"""
import torch
import triton
import triton.language as tl


# ---------------------------------------------------------------------------
# FP4-E2M1 Lookup (inline for Triton)
# ---------------------------------------------------------------------------
@triton.jit
def _fp4_lookup(idx):
    """Analytical FP4-E2M1 dequant in kernel."""
    sign = (idx >> 3) & 1
    exp = (idx >> 1) & 3
    mant = idx & 1
    val = tl.where(exp == 0, mant * 0.25, tl.exp2(exp - 1.0) * (1.0 + mant * 0.5))
    return tl.where(sign == 1, -val, val)


# ---------------------------------------------------------------------------
# Swizzled Offset (bank conflict avoidance)
# ---------------------------------------------------------------------------
@triton.jit
def _swizzled_offset(row, col, BLOCK_K: tl.constexpr, PAD: tl.constexpr = 8):
    """XOR-based swizzle: col_s = col ^ (row % PAD)"""
    col_s = col ^ (row % PAD)
    return row * (BLOCK_K + PAD) + col_s


# ---------------------------------------------------------------------------
# Dynamic Scaled Clamping (per-row max)
# ---------------------------------------------------------------------------
@triton.jit
def _dynamic_clamp(x, row_max, BASE: tl.constexpr = 4.0, GAMMA: tl.constexpr = 0.5):
    """Clamp to [-B, 0] where B = BASE * (1 + GAMMA * row_max / 10)."""
    B = BASE * (1.0 + GAMMA * row_max * 0.1)
    x_c = tl.minimum(x, 0.0)
    x_c = tl.maximum(x_c, -B)
    return x_c, B


# ---------------------------------------------------------------------------
# FP4-E2M1 W4A8 GEMM with Double Buffering
# ---------------------------------------------------------------------------
@triton.jit
def w4a8_fp4_gemm_kernel(
    a_ptr, b_packed_ptr, c_ptr,
    a_scale_ptr, b_scale_ptr,
    M, N, K,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr,
    GROUP_SIZE: tl.constexpr = 64,
):
    """
    C = A (INT8) @ B^T (FP4-E2M1 packed).
    Double buffering: preload next K-block during current compute.
    """
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)

    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_k = tl.arange(0, BLOCK_K)

    # Compute row-max for dynamic clamping
    a_init_ptrs = a_ptr + offs_m[:, None] * K + offs_k[None, :]
    mask_k_init = offs_k[None, :] < K
    a_tile_init = tl.load(a_init_ptrs, mask=mask_k_init, other=0.0).to(tl.float32)
    row_max = tl.max(tl.abs(a_tile_init), axis=1)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    n_blocks = tl.cdiv(K, BLOCK_K)

    for k_block in range(n_blocks):
        k_start = k_block * BLOCK_K
        k_offs = k_start + offs_k
        mask_k = k_offs[None, :] < K

        # Load A with dynamic clamp
        a_ptrs = a_ptr + (offs_m[:, None] * K + k_offs[None, :])
        a_tile = tl.load(a_ptrs, mask=mask_k, other=0.0).to(tl.float32)
        a_tile, _ = _dynamic_clamp(a_tile, row_max)
        a_tile = a_tile.to(tl.int8)

        # Load B packed FP4
        b_ptrs = b_packed_ptr + (offs_n[:, None] * (K // 2) + (k_offs // 2)[None, :])
        mask_b = (k_offs // 2)[None, :] < (K // 2)
        b_packed = tl.load(b_ptrs, mask=mask_b, other=0).to(tl.uint8)

        is_odd = (k_offs[None, :] % 2).to(tl.int1)
        b_idx = tl.where(
            is_odd == 0,
            (b_packed & 0x0F).to(tl.int32),
            ((b_packed >> 4) & 0x0F).to(tl.int32),
        )
        b_val = _fp4_lookup(b_idx)

        # GEMM
        acc += tl.dot(a_tile.to(tl.float32), tl.trans(b_val), out_dtype=tl.float32)

        # Double buffer: issue load for next block
        if k_block + 1 < n_blocks:
            k_next = (k_block + 1) * BLOCK_K
            k_offs_next = k_next + offs_k
            a_ptrs_next = a_ptr + (offs_m[:, None] * K + k_offs_next[None, :])
            mask_k_next = k_offs_next[None, :] < K
            _ = tl.load(a_ptrs_next, mask=mask_k_next, other=0.0)

    # Dequantize
    n_groups = tl.cdiv(K, GROUP_SIZE)
    group_idx = pid_m
    s_ptrs = b_scale_ptr + (offs_n * n_groups + group_idx)
    b_scale = tl.load(s_ptrs, mask=offs_n < N, other=1.0)
    a_scale = tl.load(a_scale_ptr + pid_m, mask=pid_m < M, other=1.0)
    acc = acc * b_scale[None, :] * a_scale[:, None] * 0.0625

    # Store
    c_ptrs = c_ptr + (offs_m[:, None] * N + offs_n[None, :])
    mask_out = (offs_m[:, None] < M) & (offs_n[None, :] < N)
    tl.store(c_ptrs, acc.to(tl.float16), mask=mask_out)


# ---------------------------------------------------------------------------
# Dynamic Outlier Split GEMM (v2)
# ---------------------------------------------------------------------------
@triton.jit
def dynamic_outlier_split_gemm_kernel(
    x_ptr, w_packed_ptr, out_ptr,
    w_fp16_ptr, w_scale_ptr,
    M, N, K,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr,
    OUTLIER_THRESH: tl.constexpr = 3.0,
):
    """
    Fused: Outlier detection + Split + FP4 dense GEMM + FP16 sparse GEMM.
    """
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)

    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_k = tl.arange(0, BLOCK_K)

    # Load X tile
    x_ptrs = x_ptr + (offs_m[:, None] * K + offs_k[None, :])
    mask_k = offs_k[None, :] < K
    x_tile = tl.load(x_ptrs, mask=mask_k, other=0.0).to(tl.float32)

    # Stats
    x_mean = tl.sum(x_tile, axis=1) / K
    x_var = tl.sum((x_tile - x_mean[:, None]) ** 2, axis=1) / K
    x_std = tl.sqrt(x_var + 1e-6)
    row_max = tl.max(tl.abs(x_tile), axis=1)

    # Dynamic clamp
    x_clamped, B = _dynamic_clamp(x_tile, row_max)
    outlier_mask = tl.abs(x_tile) > B[:, None]

    # Dense path
    x_dense = tl.where(outlier_mask, 0.0, x_clamped)
    d_min = tl.min(x_dense, axis=1)
    d_max = tl.max(x_dense, axis=1)
    d_scale = (d_max - d_min) / 255.0
    d_scale = tl.maximum(d_scale, 1e-12)
    d_zp = 128.0 - tl.round(d_min / d_scale)
    x_dense_int = tl.round(x_dense / d_scale[:, None] + d_zp[:, None])
    x_dense_int = tl.clamp(x_dense_int, 0.0, 255.0).to(tl.int8)

    # Sparse path
    x_sparse = tl.where(outlier_mask, x_tile, 0.0)

    # Dense GEMM (FP4)
    acc_dense = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    n_blocks = tl.cdiv(K, BLOCK_K)

    for k_block in range(n_blocks):
        k_offs = k_block * BLOCK_K + offs_k
        mask_kb = k_offs[None, :] < K

        a = x_dense_int
        b_ptrs = w_packed_ptr + (offs_n[:, None] * (K // 2) + (k_offs // 2)[None, :])
        mask_b = (k_offs // 2)[None, :] < (K // 2)
        b_packed = tl.load(b_ptrs, mask=mask_b, other=0).to(tl.uint8)

        is_odd = (k_offs[None, :] % 2).to(tl.int1)
        b_idx = tl.where(
            is_odd == 0,
            (b_packed & 0x0F).to(tl.int32),
            ((b_packed >> 4) & 0x0F).to(tl.int32),
        )
        b_val = _fp4_lookup(b_idx)
        acc_dense += tl.dot(a.to(tl.float32), tl.trans(b_val), out_dtype=tl.float32)

        # Double buffer prefetch
        if k_block + 1 < n_blocks:
            k_next = (k_block + 1) * BLOCK_K
            k_offs_next = k_next + offs_k
            b_ptrs_next = w_packed_ptr + (offs_n[:, None] * (K // 2) + (k_offs_next // 2)[None, :])
            mask_b_next = (k_offs_next // 2)[None, :] < (K // 2)
            _ = tl.load(b_ptrs_next, mask=mask_b_next, other=0)

    # Dequantize dense
    s_ptrs = w_scale_ptr + offs_n
    w_absmax = tl.load(s_ptrs, mask=offs_n < N, other=1.0)
    acc_dense = acc_dense * w_absmax[None, :] * 0.0625

    # Sparse GEMM (FP16 exact)
    acc_sparse = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    for k_block in range(n_blocks):
        k_offs = k_block * BLOCK_K + offs_k
        mask_kb = k_offs[None, :] < K
        a_s = x_sparse
        b_s_ptrs = w_fp16_ptr + (offs_n[:, None] * K + k_offs[None, :])
        b_s = tl.load(b_s_ptrs, mask=mask_kb, other=0.0).to(tl.float32)
        acc_sparse += tl.dot(a_s, tl.trans(b_s), out_dtype=tl.float32)

    # Accumulate
    out = acc_dense + acc_sparse
    out_ptrs = out_ptr + (offs_m[:, None] * N + offs_n[None, :])
    mask_out = (offs_m[:, None] < M) & (offs_n[None, :] < N)
    tl.store(out_ptrs, out.to(tl.float16), mask=mask_out)
