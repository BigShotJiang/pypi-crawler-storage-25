"""
FP4-E2M1 utilities: pack/unpack and lookup table.
Format: 1 sign, 2 exponent, 1 mantissa. Bias=1.
"""
import torch

# FP4-E2M1 lookup table (16 entries)
# E=0 (denormal): (-1)^s * 2^(-1) * m/2
# E>0 (normal): (-1)^s * 2^(E-1) * (1 + m/2)
_FP4_TABLE = torch.tensor([
    0.0, 0.25, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0,
    -0.0, -0.25, -1.0, -1.5, -2.0, -3.0, -4.0, -6.0,
], dtype=torch.float16)


def fp4_lookup(idx: torch.Tensor) -> torch.Tensor:
    """Vectorized FP4 index -> float16 lookup."""
    return _FP4_TABLE.to(idx.device)[idx.view(-1).long()].view(idx.shape)


def pack_fp4_e2m1(weights: torch.Tensor) -> torch.Tensor:
    """
    Pack FP16 weights into FP4-E2M1 (2 values per uint8 byte).
    Args:
        weights: (N, K) float16
    Returns:
        packed: (N, K//2) uint8
    """
    flat = weights.view(-1).float()
    table = _FP4_TABLE.float().to(flat.device)
    dist = (flat.unsqueeze(1) - table.unsqueeze(0)).abs()
    idx = dist.argmin(dim=1).to(torch.uint8)

    even = idx[0::2]
    odd = idx[1::2]
    packed = (even & 0x0F) | ((odd & 0x0F) << 4)

    N, K = weights.shape
    return packed.view(N, K // 2)


def unpack_fp4_e2m1(packed: torch.Tensor, K: int) -> torch.Tensor:
    """
    Unpack (N, K//2) uint8 -> (N, K) fp16.
    """
    N = packed.shape[0]
    flat = packed.view(-1).long()
    low = flat & 0x0F
    high = (flat >> 4) & 0x0F
    interleaved = torch.stack([low, high], dim=1).view(-1)
    return _FP4_TABLE.to(packed.device)[interleaved].view(N, K)
