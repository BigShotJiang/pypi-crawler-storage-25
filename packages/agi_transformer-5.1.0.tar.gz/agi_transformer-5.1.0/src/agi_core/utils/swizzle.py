"""
Matrix swizzling utilities for shared memory bank conflict avoidance.
"""
import torch


def swizzle_index(row: int, col: int, block_k: int, pad: int = 8) -> int:
    """XOR-based swizzle: col_s = col ^ (row % pad)."""
    col_s = col ^ (row % pad)
    return row * (block_k + pad) + col_s


def apply_swizzle(tensor_2d: torch.Tensor, pad: int = 8) -> torch.Tensor:
    """Reorder 2D tensor for swizzled layout (debug)."""
    M, K = tensor_2d.shape
    K_pad = K + pad
    out = torch.zeros(M, K_pad, dtype=tensor_2d.dtype, device=tensor_2d.device)
    for r in range(M):
        for c in range(K):
            c_s = c ^ (r % pad)
            out[r, c_s] = tensor_2d[r, c]
    return out
