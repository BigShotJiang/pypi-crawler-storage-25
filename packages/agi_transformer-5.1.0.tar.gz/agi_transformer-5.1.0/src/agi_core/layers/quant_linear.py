"""
FP4-E2M1 Quantized Linear with Split-Matrix.
"""
import math
from typing import Tuple, Dict
import torch
import torch.nn as nn
from agi_core.kernels.fp4_utils import pack_fp4_e2m1, unpack_fp4_e2m1


class FP4Linear(nn.Module):
    """
    Linear layer: FP4-E2M1 weights + INT8 activations (W4A8).
    • Per-channel smooth_alpha vector (d_model,)
    • Dynamic per-token outlier detection (MAD-based)
    • Split-Matrix: dense FP4 + sparse FP16
    """
    def __init__(self, in_features: int, out_features: int,
                 group_size: int = 64, outlier_thresh: float = 3.0):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.group_size = group_size
        self.outlier_thresh = outlier_thresh

        # Master weight (FP32 for training)
        self.weight = nn.Parameter(torch.randn(out_features, in_features) * 0.02)

        # FP4 packed buffer
        self.register_buffer(
            "weight_fp4",
            torch.zeros(out_features, in_features // 2, dtype=torch.uint8),
        )
        self.register_buffer(
            "w_scale",
            torch.ones(out_features, math.ceil(in_features / group_size), dtype=torch.float16),
        )
        self.register_buffer(
            "w_fp16",
            torch.zeros(out_features, in_features, dtype=torch.float16),
        )

        # SmoothAlpha vector (per-channel, not scalar)
        self.smooth_alpha = nn.Parameter(torch.ones(in_features) * 0.5)

    def pack_weights(self):
        """Pack FP32 -> FP4 after calibration."""
        with torch.no_grad():
            w_smooth = self.weight * self.smooth_alpha.unsqueeze(0)
            self.w_fp16.copy_(w_smooth.half())
            self.weight_fp4.copy_(pack_fp4_e2m1(w_smooth.half()))

    def detect_outliers(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Dynamic per-token outlier detection."""
        median = x.median(dim=-1, keepdim=True)[0]
        mad = (x - median).abs().median(dim=-1, keepdim=True)[0]
        std = x.std(dim=-1, keepdim=True)
        mad = torch.where(mad < 1e-6, std * 0.6745, mad)
        robust_z = (x - median).abs() / (mad + 1e-12)
        mask = robust_z > self.outlier_thresh

        x_dense = x.clone()
        x_dense[mask] = 0.0
        x_sparse = x.clone()
        x_sparse[~mask] = 0.0
        return mask, x_dense, x_sparse

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, Dict]:
        """
        Args:
            x: (..., in_features)
        Returns:
            output, info dict
        """
        orig_shape = x.shape
        x = x.view(-1, self.in_features).to(torch.float16)

        # Per-channel smoothquant
        x_smooth = x / self.smooth_alpha.unsqueeze(0).half().clamp(min=0.1)

        # Outlier detection
        mask, x_dense, x_sparse = self.detect_outliers(x_smooth)
        ratio = mask.float().mean().item()

        # Dense path: INT8 quant
        x_min = x_dense.min(dim=-1, keepdim=True)[0]
        x_max = x_dense.max(dim=-1, keepdim=True)[0]
        scale = (x_max - x_min) / 255.0
        scale = torch.clamp(scale, min=1e-12)
        zp = 128 - torch.round(x_min / scale)
        x_dense_int = torch.round(x_dense / scale + zp).clamp(0, 255).to(torch.int8)

        # GEMM dense (fallback; Triton kernel ready)
        w_deq = unpack_fp4_e2m1(self.weight_fp4, self.in_features)
        y_dense = torch.matmul(x_dense_int.float() * (scale / 255.0), w_deq.float().t())

        # Sparse path: FP16 exact
        y_sparse = torch.matmul(x_sparse, self.w_fp16.t())

        output = y_dense + y_sparse
        output = output.view(orig_shape[:-1] + (self.out_features,))

        return output, {
            "outlier_ratio": ratio,
            "smooth_alpha_mean": self.smooth_alpha.mean().item(),
            "format": "FP4-E2M1",
        }
