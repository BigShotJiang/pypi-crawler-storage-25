"""
Simplified Mamba (State Space Model) block.
Replaces attention in middle layers.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class MambaBlock(nn.Module):
    """
    Simplified SSM block: Linear -> Conv1D -> Selective Scan -> Linear.
    """
    def __init__(self, d_model: int, d_state: int = 16, d_conv: int = 4, expand: int = 2):
        super().__init__()
        self.d_model = d_model
        self.d_state = d_state
        self.d_inner = int(expand * d_model)

        self.in_proj = nn.Linear(d_model, self.d_inner * 2, bias=False)
        self.conv1d = nn.Conv1d(
            in_channels=self.d_inner,
            out_channels=self.d_inner,
            kernel_size=d_conv,
            padding=d_conv - 1,
            groups=self.d_inner,
            bias=True,
        )
        self.x_proj = nn.Linear(self.d_inner, d_state * 2, bias=False)
        self.dt_proj = nn.Linear(self.d_inner, self.d_inner, bias=True)

        A = torch.arange(1, d_state + 1, dtype=torch.float32).repeat(self.d_inner, 1)
        self.A_log = nn.Parameter(torch.log(A))
        self.D = nn.Parameter(torch.ones(self.d_inner))
        self.out_proj = nn.Linear(self.d_inner, d_model, bias=False)

    def forward(self, x):
        B, L, D = x.shape
        xz = self.in_proj(x)
        x_branch, z = xz.chunk(2, dim=-1)

        x_conv = self.conv1d(x_branch.transpose(1, 2))[:, :, :L].transpose(1, 2)
        x_conv = F.silu(x_conv)

        x_ssm = x_conv
        B_mat = self.x_proj(x_ssm)
        B_ssm, C_ssm = B_mat.chunk(2, dim=-1)
        delta = F.softplus(self.dt_proj(x_ssm))
        A = -torch.exp(self.A_log.float())

        y = self.selective_scan(x_conv, delta, A, B_ssm, C_ssm)
        y = y * F.silu(z)
        return self.out_proj(y)

    def selective_scan(self, x, delta, A, B, C):
        """Sequential scan (simplified; production uses fused CUDA)."""
        Bb, L, d_inner = x.shape
        d_state = A.shape[1]

        deltaA = torch.exp(torch.einsum("bld,dn->bldn", delta, A))
        deltaB = torch.einsum("bld,bln->bldn", delta, B)

        h = torch.zeros(Bb, d_inner, d_state, device=x.device, dtype=x.dtype)
        ys = []
        for t in range(L):
            h = deltaA[:, t] * h + deltaB[:, t] * x[:, t].unsqueeze(-1)
            y = torch.einsum("bdn,bn->bd", h, C[:, t])
            ys.append(y)
        return torch.stack(ys, dim=1)
