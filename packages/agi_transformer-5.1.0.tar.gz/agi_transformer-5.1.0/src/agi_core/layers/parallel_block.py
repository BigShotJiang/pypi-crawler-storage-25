"""
Parallel Transformer Block (PaLM-style).
Attention and FFN run in parallel, residuals added together.
y = x + Attn(LN(x)) + FFN(LN(x))
"""
import math
import torch
import torch.nn as nn
from agi_core.layers.quant_linear import FP4Linear
from agi_core.layers.mamba import MambaBlock


class ParallelBlock(nn.Module):
    """
    Parallel block with optional Mamba replacement.
    """
    def __init__(self, d_model: int, n_heads: int, mla_ratio: int = 4,
                 use_mamba: bool = False, dropout: float = 0.0):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        self.use_mamba = use_mamba

        self.ln = nn.RMSNorm(d_model)

        if use_mamba:
            self.attn_branch = MambaBlock(d_model, d_state=16, expand=2)
        else:
            self.q_proj = FP4Linear(d_model, d_model)
            self.k_proj = FP4Linear(d_model, d_model // mla_ratio)
            self.v_proj = FP4Linear(d_model, d_model // mla_ratio)
            self.o_proj = FP4Linear(d_model, d_model)

        # FFN (SwiGLU)
        hidden_dim = 4 * d_model
        self.gate_proj = FP4Linear(d_model, hidden_dim)
        self.up_proj = FP4Linear(d_model, hidden_dim)
        self.down_proj = FP4Linear(hidden_dim, d_model)

        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()

    def forward(self, x):
        normed = self.ln(x)

        if self.use_mamba:
            attn_out = self.attn_branch(normed)
        else:
            B, L, D = normed.shape
            q = self.q_proj(normed)[0].view(B, L, self.n_heads, self.head_dim).transpose(1, 2)
            k = self.k_proj(normed)[0].view(B, L, self.n_heads, self.head_dim).transpose(1, 2)
            v = self.v_proj(normed)[0].view(B, L, self.n_heads, self.head_dim).transpose(1, 2)

            scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(self.head_dim)
            scores = scores - scores.max(dim=-1, keepdim=True)[0]
            probs = torch.softmax(scores, dim=-1)
            attn = torch.matmul(probs, v).transpose(1, 2).contiguous().view(B, L, D)
            attn_out = self.o_proj(attn)[0]

        # SwiGLU
        gate = torch.sigmoid(self.gate_proj(normed)[0])
        up = self.up_proj(normed)[0]
        ffn_out = self.down_proj(gate * up)[0]

        # Parallel residual
        return x + self.dropout(attn_out) + self.dropout(ffn_out)
