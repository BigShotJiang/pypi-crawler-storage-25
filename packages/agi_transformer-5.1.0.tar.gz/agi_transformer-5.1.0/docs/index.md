# AGi Transformer v5.1 Documentation

## Architecture
- Parallel Blocks (PaLM-style)
- Mamba/TTT Hybrid Layers
- FP4-E2M1 Quantization
- Double Buffering Triton Kernels

## API
```python
from agi_core import AGiConfig, AGiTransformer

config = AGiConfig(d_model=512, n_layers=8)
model = AGiTransformer(config)
```

## Training
```bash
python scripts/train.py --steps 5000 --d-model 512 --n-layers 8
```

## Checkpoints
- `checkpoints/agi_v51_initialized.pt` — Pre-trained weights
- `checkpoints/agi_v51_trained.pt` — 10-step smoke test
