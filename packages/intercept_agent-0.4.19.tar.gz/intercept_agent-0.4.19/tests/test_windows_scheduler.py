"""Tests for :class:`posture_agent.platforms.windows.WindowsScheduler` (C12).

The scheduler shells out to ``schtasks.exe`` via :mod:`subprocess`. These tests
patch both ``subprocess.run`` (so no schtasks process is ever spawned) and
``platform.system`` (so the cross-platform guards behave as if running on
Windows). The tests run on macOS / Linux CI without modification.
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pytest
from posture_agent.platforms import windows
from posture_agent.platforms.base import (
    SchedulerStatus,
    UnsupportedPlatformError,
)


def _fake_proc(returncode: int = 0, stdout: str = "", stderr: str = "") -> SimpleNamespace:
    """Build a stand-in for ``subprocess.CompletedProcess`` with the given fields."""
    return SimpleNamespace(returncode=returncode, stdout=stdout, stderr=stderr)


# ---------------------------------------------------------------------------
# install()
# ---------------------------------------------------------------------------


class TestWindowsSchedulerInstall:
    def test_install_hourly_calls_schtasks_create(self):
        sched = windows.WindowsScheduler()
        captured: dict = {}

        def fake_run(cmd, *args, **kwargs):
            captured["cmd"] = cmd
            captured["kwargs"] = kwargs
            return _fake_proc(returncode=0, stdout="SUCCESS: ...")

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            sched.install(Path(r"C:\Users\test\intercept-agent.exe"))

        cmd = captured["cmd"]
        assert cmd[0] == "schtasks.exe"
        assert "/Create" in cmd
        # Schedule is HOURLY by default
        sc_idx = cmd.index("/SC")
        assert cmd[sc_idx + 1] == "HOURLY"
        # Task name is the canonical "Intercept Agent"
        tn_idx = cmd.index("/TN")
        assert cmd[tn_idx + 1] == "Intercept Agent"
        # /F is present so re-install is idempotent
        assert "/F" in cmd
        # The /TR action quotes the executable and includes "collect --report"
        tr_idx = cmd.index("/TR")
        assert cmd[tr_idx + 1] == r'"C:\Users\test\intercept-agent.exe" collect --report'

    def test_install_passes_capture_and_timeout(self):
        sched = windows.WindowsScheduler()
        captured: dict = {}

        def fake_run(cmd, *args, **kwargs):
            captured["kwargs"] = kwargs
            return _fake_proc(returncode=0)

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            sched.install(Path(r"C:\agent.exe"))

        assert captured["kwargs"].get("capture_output") is True
        assert captured["kwargs"].get("text") is True
        assert captured["kwargs"].get("check") is False
        # Timeout is bounded; the exact value lives in the implementation.
        assert isinstance(captured["kwargs"].get("timeout"), int)
        assert captured["kwargs"]["timeout"] > 0

    def test_install_raises_on_failure(self):
        sched = windows.WindowsScheduler()

        def fake_run(cmd, *args, **kwargs):
            return _fake_proc(returncode=1, stderr="ERROR: Access is denied.")

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
            pytest.raises(RuntimeError) as excinfo,
        ):
            sched.install(Path(r"C:\agent.exe"))

        # The error message surfaces the exit code and stderr so users can
        # diagnose without scraping captured logs.
        assert "schtasks /Create failed" in str(excinfo.value)
        assert "exit=1" in str(excinfo.value)
        assert "Access is denied" in str(excinfo.value)

    def test_install_raises_on_non_windows(self):
        sched = windows.WindowsScheduler()
        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Darwin",
            ),
            pytest.raises(UnsupportedPlatformError),
        ):
            sched.install(Path(r"C:\agent.exe"))

    def test_install_with_custom_interval_uppercases(self):
        """A non-'hourly' interval is forwarded uppercased so `daily` => `DAILY`."""
        sched = windows.WindowsScheduler()
        captured: dict = {}

        def fake_run(cmd, *args, **kwargs):
            captured["cmd"] = cmd
            return _fake_proc(returncode=0)

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            sched.install(Path(r"C:\agent.exe"), interval="daily")

        cmd = captured["cmd"]
        sc_idx = cmd.index("/SC")
        assert cmd[sc_idx + 1] == "DAILY"


# ---------------------------------------------------------------------------
# uninstall()
# ---------------------------------------------------------------------------


class TestWindowsSchedulerUninstall:
    def test_uninstall_calls_delete(self):
        sched = windows.WindowsScheduler()
        captured: dict = {}

        def fake_run(cmd, *args, **kwargs):
            captured["cmd"] = cmd
            return _fake_proc(returncode=0, stdout="SUCCESS: ...")

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            sched.uninstall()

        cmd = captured["cmd"]
        assert cmd[0] == "schtasks.exe"
        assert "/Delete" in cmd
        assert "/F" in cmd
        tn_idx = cmd.index("/TN")
        assert cmd[tn_idx + 1] == "Intercept Agent"

    def test_uninstall_swallows_missing_task(self):
        """A 'cannot find' error from schtasks means the task is already absent."""
        sched = windows.WindowsScheduler()

        def fake_run(cmd, *args, **kwargs):
            return _fake_proc(
                returncode=1,
                stderr="ERROR: The system cannot find the file specified.",
            )

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            sched.uninstall()  # must not raise

    def test_uninstall_raises_other_errors(self):
        sched = windows.WindowsScheduler()

        def fake_run(cmd, *args, **kwargs):
            return _fake_proc(returncode=1, stderr="ERROR: Access is denied.")

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
            pytest.raises(RuntimeError) as excinfo,
        ):
            sched.uninstall()

        assert "schtasks /Delete failed" in str(excinfo.value)
        assert "Access is denied" in str(excinfo.value)

    def test_uninstall_raises_on_non_windows(self):
        sched = windows.WindowsScheduler()
        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Linux",
            ),
            pytest.raises(UnsupportedPlatformError),
        ):
            sched.uninstall()


# ---------------------------------------------------------------------------
# status()
# ---------------------------------------------------------------------------


# Sample LIST output adapted from a real `schtasks /Query /FO LIST /V` dump.
# Field ordering, blank lines, and trailing whitespace are preserved so the
# parser is exercised against output as close to the real thing as practical.
_LIST_RUNNING = """\

Folder: \\
HostName:                             DEV-PC
TaskName:                             \\Intercept Agent
Next Run Time:                        4/30/2026 4:00:00 PM
Status:                               Running
Logon Mode:                           Interactive only
Last Run Time:                        4/30/2026 3:00:00 PM
Last Result:                          0
Author:                               DEV-PC\\test
Task To Run:                          "C:\\Users\\test\\intercept-agent.exe" collect --report
Start In:                             N/A
Comment:                              N/A
Scheduled Task State:                 Enabled
"""

_LIST_READY = """\

Folder: \\
HostName:                             DEV-PC
TaskName:                             \\Intercept Agent
Next Run Time:                        4/30/2026 4:00:00 PM
Status:                               Ready
Logon Mode:                           Interactive only
Last Run Time:                        4/30/2026 3:00:00 PM
Last Result:                          0
"""


class TestWindowsSchedulerStatus:
    def test_status_when_installed_running(self):
        sched = windows.WindowsScheduler()

        def fake_run(cmd, *args, **kwargs):
            return _fake_proc(returncode=0, stdout=_LIST_RUNNING)

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            status = sched.status()

        assert isinstance(status, SchedulerStatus)
        assert status.installed is True
        assert status.running is True
        assert status.last_run == "4/30/2026 3:00:00 PM"
        assert status.raw is not None
        # Spot-check that the parser preserved a few well-known fields.
        assert status.raw.get("TaskName") == "\\Intercept Agent"
        assert status.raw.get("Status") == "Running"

    def test_status_when_installed_not_running(self):
        sched = windows.WindowsScheduler()

        def fake_run(cmd, *args, **kwargs):
            return _fake_proc(returncode=0, stdout=_LIST_READY)

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            status = sched.status()

        assert status.installed is True
        assert status.running is False
        assert status.last_run == "4/30/2026 3:00:00 PM"

    def test_status_when_not_installed(self):
        sched = windows.WindowsScheduler()

        def fake_run(cmd, *args, **kwargs):
            return _fake_proc(
                returncode=1,
                stderr="ERROR: The system cannot find the file specified.",
            )

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            status = sched.status()

        assert status.installed is False
        assert status.running is None
        assert status.last_run is None

    def test_status_on_non_windows(self):
        sched = windows.WindowsScheduler()
        with patch(
            "posture_agent.platforms.windows.platform.system",
            return_value="Darwin",
        ):
            status = sched.status()

        assert status.installed is False
        assert status.running is None
        assert status.last_run is None

    def test_status_handles_subprocess_oserror(self):
        """If schtasks itself can't be invoked (e.g., PATH stripped), don't crash."""
        sched = windows.WindowsScheduler()

        def fake_run(cmd, *args, **kwargs):
            raise OSError("no such file: schtasks.exe")

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            status = sched.status()

        assert status.installed is False
        assert status.running is None
        assert status.last_run is None

    def test_status_handles_subprocess_subprocesserror(self):
        sched = windows.WindowsScheduler()

        def fake_run(cmd, *args, **kwargs):
            raise subprocess.SubprocessError("timeout-ish")

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            status = sched.status()

        assert status.installed is False
