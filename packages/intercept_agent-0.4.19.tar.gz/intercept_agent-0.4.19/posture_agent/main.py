"""Intercept Posture Agent CLI."""

import asyncio
import json
import logging
import shutil
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

import click

from posture_agent.collectors.ai_tools import AIToolsCollector
from posture_agent.collectors.dev_tools import DevToolsCollector
from posture_agent.collectors.extensions import ExtensionCollector
from posture_agent.collectors.ides import IDECollector
from posture_agent.collectors.machine import MachineCollector
from posture_agent.collectors.mcp_servers import MCPServersCollector
from posture_agent.collectors.package_managers import PackageManagerCollector
from posture_agent.collectors.security import SecurityCollector
from posture_agent.core.config import get_settings
from posture_agent.core.logging import setup_agent_logging
from posture_agent.models.report import PostureReportPayload
from posture_agent.platforms import get_bundle
from posture_agent.services.fingerprint import get_machine_fingerprint
from posture_agent.services.reporter import _get_user_agent, report_uninstall, send_report

logger = logging.getLogger(__name__)


# Re-exported from platforms.macos so existing tests that patch
# `posture_agent.main.PLIST_PATH` keep working.
PLIST_NAME = "com.hijacksecurity.intercept-agent"
PLIST_PATH = Path.home() / "Library" / "LaunchAgents" / f"{PLIST_NAME}.plist"


def _pip_user_bin_candidates() -> list[Path]:
    """Return candidate paths where pip --user installs scripts.

    Delegates to the platform bundle.
    """
    return get_bundle().path_expander.pip_user_bin_candidates()


async def run_collection(report: bool = False) -> None:
    """Run all collectors and optionally report to API."""
    settings = get_settings()

    # Get machine fingerprint
    fingerprint = await get_machine_fingerprint()

    # Run enabled collectors
    collectors = []
    if settings.collectors.machine:
        collectors.append(MachineCollector())
    if settings.collectors.ides:
        collectors.append(IDECollector())
    if settings.collectors.extensions:
        collectors.append(ExtensionCollector())
    if settings.collectors.ai_tools:
        collectors.append(AIToolsCollector())
    if settings.collectors.dev_tools:
        collectors.append(DevToolsCollector())
    if settings.collectors.security:
        collectors.append(SecurityCollector())
    if settings.collectors.package_managers:
        collectors.append(PackageManagerCollector())
    if settings.collectors.mcp_servers:
        collectors.append(MCPServersCollector())

    results = await asyncio.gather(
        *(c.collect() for c in collectors),
        return_exceptions=True,
    )

    # Build payload
    payload_data: dict = {
        "fingerprint": fingerprint,
        "agent_version": settings.agent_version,
        "collected_at": datetime.now(UTC),
        "enrolled_email": settings.api.enrolled_email,
    }

    for result in results:
        if isinstance(result, Exception):
            logger.error("Collector failed: %s", result)
            continue
        payload_data[result.collector] = result.data

    payload = PostureReportPayload(**payload_data)

    if report:
        click.echo(f"Sending report to {settings.api.url}...")
        try:
            response = await send_report(payload, settings)
            click.echo(f"Report submitted: {response.get('id', 'ok')}")
        except Exception as e:
            logger.error("Failed to send report: %s", e)
            sys.exit(1)
    else:
        click.echo(json.dumps(payload.model_dump(mode="json"), indent=2))


@click.group()
@click.version_option(version=get_settings().agent_version, package_name="intercept-agent")
@click.option("--debug", is_flag=True, help="Enable debug logging")
def cli(debug: bool) -> None:
    """Intercept Developer Posture Agent."""
    settings = get_settings()
    log_cfg = dict(settings.logging_config)
    if debug or settings.debug:
        log_cfg["level"] = "DEBUG"
    setup_agent_logging(logging_config=log_cfg)


@cli.command()
@click.option("--report", is_flag=True, help="Send report to API (default: dry-run to stdout)")
def collect(report: bool) -> None:
    """Collect developer environment data."""
    asyncio.run(run_collection(report=report))


@cli.command()
@click.option(
    "--bin-path",
    default=None,
    help="Absolute path to the intercept-agent binary (skips PATH lookup)",
)
def install(bin_path: str | None) -> None:
    """Install scheduler for hourly collection (launchd plist on macOS)."""
    settings = get_settings()
    interval = settings.schedule.interval_seconds

    # Ensure config directory and logs exist
    logs_dir = CONFIG_DIR / "logs"
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    logs_dir.mkdir(parents=True, exist_ok=True)

    # Write default config if not present
    if not CONFIG_FILE.exists():
        CONFIG_FILE.write_text(
            "api:\n"
            f'  url: "{settings.api.url}"\n'
            "  timeout: 30\n"
            "  retries: 3\n"
            "collectors:\n"
            "  machine: true\n"
            "  ides: true\n"
            "  extensions: true\n"
            "  ai_tools: true\n"
            "  dev_tools: true\n"
            "  security: true\n"
            "  package_managers: true\n"
            "  mcp_servers: true\n"
            "schedule:\n"
            f"  interval_seconds: {interval}\n"
        )
        click.echo(f"Config written to {CONFIG_FILE}")

    # Find the intercept-agent binary
    agent_bin = bin_path
    if not agent_bin:
        agent_bin = shutil.which("intercept-agent")
    if not agent_bin:
        # Try common pip --user locations
        for candidate in _pip_user_bin_candidates():
            if candidate.exists():
                agent_bin = str(candidate)
                break
    if not agent_bin:
        logger.error("intercept-agent not found. Pass --bin-path or add pip's bin dir to PATH.")
        sys.exit(1)

    # Delegate plist creation + launchctl load to the platform scheduler.
    bundle = get_bundle()
    bundle.scheduler.install(Path(agent_bin), interval=str(interval))
    click.echo(f"Plist written to {PLIST_PATH}")
    click.echo("Agent installed and started.")


@cli.command()
@click.option("--purge", is_flag=True, help="Also remove config and logs.")
def uninstall(purge: bool) -> None:
    """Uninstall the agent: stop scheduler and remove plist."""
    # Report uninstall to API before cleaning up local files
    # (needs config to know where and how to authenticate)
    click.echo("Reporting uninstall to API...")
    report_uninstall()

    if PLIST_PATH.exists():
        get_bundle().scheduler.uninstall()
        click.echo(f"Removed {PLIST_PATH}")
    else:
        click.echo("Launchd plist not found (already removed).")

    config_dir = Path.home() / ".config" / "intercept"
    if purge and config_dir.exists():
        shutil.rmtree(config_dir)
        click.echo(f"Removed {config_dir}")

    click.echo("Agent uninstalled.")


@cli.command()
def status() -> None:
    """Show agent status."""
    settings = get_settings()

    click.echo(f"Agent version: {settings.agent_version}")
    click.echo(f"API URL: {settings.api.url}")
    click.echo(f"Schedule: every {settings.schedule.interval_seconds}s")
    click.echo(f"Plist: {PLIST_PATH}")
    click.echo(f"Installed: {PLIST_PATH.exists()}")

    if PLIST_PATH.exists():
        sched_status = get_bundle().scheduler.status()
        if sched_status.running:
            click.echo("Status: loaded")
            raw = sched_status.raw or {}
            for line in (raw.get("launchctl_list", "") or "").strip().split("\n"):
                if "PID" in line or "LastExitStatus" in line:
                    click.echo(f"  {line.strip()}")
        else:
            click.echo("Status: not loaded")

    # Check logs
    stdout_log = Path.home() / ".config" / "intercept" / "logs" / "agent.stdout.log"
    if stdout_log.exists():
        lines = stdout_log.read_text().strip().split("\n")
        if lines:
            click.echo(f"Last output: {lines[-1]}")


@cli.command()
def update() -> None:
    """Update the agent to the latest version from PyPI."""
    from posture_agent.core.config import Settings

    PACKAGE_NAME = "intercept-agent"

    # Record current version before upgrade
    current_settings = get_settings()
    old_version = current_settings.agent_version

    click.echo(f"Current version: {old_version}")
    click.echo("Checking for updates...")

    # Determine the best installer: prefer uv, fall back to pip
    uv_bin = shutil.which("uv")
    pip_bin = shutil.which("pip3") or shutil.which("pip")

    if uv_bin:
        cmd = [uv_bin, "pip", "install", "--system", "--upgrade", PACKAGE_NAME]
    elif pip_bin:
        cmd = [pip_bin, "install", "--upgrade", PACKAGE_NAME]
    else:
        click.echo(
            "Error: Neither uv nor pip found. Install pip or uv and try again.",
            err=True,
        )
        sys.exit(1)

    installer_name = "uv" if uv_bin else "pip"
    click.echo(f"Upgrading with {installer_name}...")

    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.returncode != 0:
        click.echo(f"Error: Upgrade failed (exit code {result.returncode}).", err=True)
        if result.stderr:
            click.echo(result.stderr.strip(), err=True)
        sys.exit(1)

    # Read the new version from fresh package metadata (bypass lru_cache)
    new_settings = Settings()
    new_version = new_settings.agent_version

    if new_version == old_version:
        click.echo(f"Already up to date ({old_version}).")
    else:
        click.echo(f"Updated: {old_version} -> {new_version}")
        click.echo("The new version will be reported on the next scheduled check-in.")


CONFIG_DIR = Path.home() / ".config" / "intercept"
CONFIG_FILE = CONFIG_DIR / "agent.yaml"
DEFAULT_API_URL = "https://intercept.hijacksecurity.com"


def _mask_key(key: str) -> str:
    """Mask an API key for safe display (e.g., 'hsk_a8kM...')."""
    if len(key) <= 12:
        return key[:4] + "..."
    return key[:12] + "..."


def _get_os_version() -> str:
    """Get the OS version string. Delegates to the platform bundle."""
    return get_bundle().hardware.os_version()


@cli.command()
@click.option("--token", required=True, help="Enrollment token (hse_...) from your admin")
@click.option("--api-url", default=None, help="API URL (defaults to production)")
def setup(token: str, api_url: str | None) -> None:
    """One-command agent setup: enroll, configure, install, and report."""
    import getpass
    import platform as _platform
    import stat

    import httpx
    import yaml

    # 1. Validate token
    if not token.startswith("hse_"):
        click.echo("Error: Invalid enrollment token. Must start with 'hse_'.", err=True)
        click.echo(
            "Get a valid token from your admin (Settings > Agent in the Intercept dashboard).",
            err=True,
        )
        sys.exit(1)

    effective_url = (api_url or DEFAULT_API_URL).rstrip("/")

    # 2. Create config directory
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    (CONFIG_DIR / "logs").mkdir(parents=True, exist_ok=True)

    # 3. Check for existing config
    if CONFIG_FILE.exists():
        try:
            existing = yaml.safe_load(CONFIG_FILE.read_text()) or {}
            existing_key = existing.get("api", {}).get("api_key", "")
            if existing_key and existing_key.startswith("hsk_"):
                click.echo(f"Agent is already configured (key: {_mask_key(existing_key)}).")
                click.echo(
                    "To reconfigure, run: intercept-agent uninstall --purge && intercept-agent setup --token <token>"
                )
                sys.exit(1)
        except Exception:
            pass  # Corrupt config, allow overwrite

    # 4. Generate machine fingerprint
    click.echo("Generating machine fingerprint...")
    fingerprint = asyncio.run(get_machine_fingerprint())

    # 5. Collect machine metadata
    hostname = _platform.node()
    username = getpass.getuser()
    os_name = _platform.system()
    os_version = _get_os_version()
    settings = get_settings()
    agent_version = settings.agent_version

    # 6. Call enrollment endpoint
    click.echo(f"Enrolling with {effective_url}...")
    enroll_url = f"{effective_url}/api/v1/identity/enroll"
    body = {
        "token": token,
        "machine_fingerprint": fingerprint,
        "hostname": hostname,
        "username": username,
        "os_name": os_name,
        "os_version": os_version,
        "agent_version": agent_version,
    }

    try:
        with httpx.Client(
            timeout=30,
            headers={"User-Agent": _get_user_agent()},
        ) as client:
            resp = client.post(enroll_url, json=body)
    except httpx.ConnectError:
        click.echo(
            f"Error: Could not connect to {effective_url}. Check the URL and your network.",
            err=True,
        )
        sys.exit(1)
    except httpx.TimeoutException:
        click.echo("Error: Enrollment request timed out. Try again.", err=True)
        sys.exit(1)

    # 7. Handle response
    if resp.status_code == 201:
        data = resp.json()
        api_key = data["api_key"]
        # `enrolled_email` is the email of the user who created the
        # enrollment token. Older identity versions don't return it; tolerate
        # the absence gracefully (None) so setup keeps working.
        enrolled_email = data.get("enrolled_email")
        click.echo(f"Enrolled successfully! Key: {_mask_key(api_key)}")
    elif resp.status_code == 401:
        click.echo("Error: Invalid enrollment token. Please check with your admin.", err=True)
        sys.exit(1)
    elif resp.status_code == 409:
        detail = resp.json().get("detail", "")
        if "already enrolled" in detail.lower():
            click.echo(
                "Error: This machine is already enrolled. To re-enroll, ask your admin to revoke the existing key.",
                err=True,
            )
        else:
            click.echo(
                "Error: Enrollment limit reached for this token. Ask your admin for a new one.",
                err=True,
            )
        sys.exit(1)
    elif resp.status_code == 410:
        click.echo("Error: Enrollment token has expired. Ask your admin for a new one.", err=True)
        sys.exit(1)
    elif resp.status_code == 422:
        click.echo("Error: Invalid request. Check your enrollment token format.", err=True)
        sys.exit(1)
    else:
        click.echo(
            f"Error: Enrollment failed (HTTP {resp.status_code}). Contact your admin.", err=True
        )
        sys.exit(1)

    # 8. Write config file
    api_section_lines = [
        "api:",
        f'  url: "{effective_url}"',
        f'  api_key: "{api_key}"',
    ]
    if enrolled_email:
        # JSON-encoded strings are valid YAML double-quoted scalars and
        # safely handle any embedded quotes/backslashes/control chars.
        api_section_lines.append(f"  enrolled_email: {json.dumps(enrolled_email)}")
    api_section_lines.extend(
        [
            "  timeout: 30",
            "  retries: 3",
        ]
    )
    config_content = (
        "\n".join(api_section_lines) + "\n" + "collectors:\n"
        "  machine: true\n"
        "  ides: true\n"
        "  extensions: true\n"
        "  ai_tools: true\n"
        "  dev_tools: true\n"
        "  security: true\n"
        "  package_managers: true\n"
        "  mcp_servers: true\n"
        "schedule:\n"
        "  interval_seconds: 3600\n"
    )
    CONFIG_FILE.write_text(config_content)
    CONFIG_FILE.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 0600
    click.echo(f"Configuration saved to {CONFIG_FILE}")

    # Clear cached settings so install and run_collection read the new config
    get_settings.cache_clear()

    # 9. Install launchd schedule
    click.echo("Installing launchd schedule...")
    try:
        ctx = click.Context(install)
        ctx.invoke(install, bin_path=None)
    except SystemExit:
        pass  # install may exit on success, that's fine

    # 10. Run first collection
    click.echo("Running first collection...")
    try:
        asyncio.run(run_collection(report=True))
    except Exception as e:
        click.echo(f"Agent enrolled but first report failed: {e}")
        click.echo("It will retry automatically on the next scheduled run.")
        return

    click.echo("Agent enrolled and first report submitted successfully!")


if __name__ == "__main__":
    cli()
