//! Bitool Maturin - Rust 核心库
//!
//! 提供高性能的文件操作、文本处理、配置管理、命令执行等功能
#![allow(non_local_definitions)]

pub mod core;
pub mod plugins;
pub mod python;

use pyo3::prelude::*;
use python::py_cmd_exec::PyCommandExecutor;
use python::py_config::{PyBitoolConfig, PyWorkspaceConfig};
use python::py_file_ops::PyFileOps;
use python::py_profiler::PyPerformanceProfiler;
use python::py_profiler::PyProfileRecord;
use python::py_text_proc::PyTextProcessor;
use python::py_pdf_ops::PyPdfOps;

/// Python 模块初始化函数
#[pymodule]
fn _rust(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // 注册 Python 绑定类
    m.add_class::<PyBitoolConfig>()?;
    m.add_class::<PyWorkspaceConfig>()?;

    m.add_class::<PyCommandExecutor>()?;
    // fileops
    m.add_class::<PyFileOps>()?;
    // profiler
    m.add_class::<PyProfileRecord>()?;
    m.add_class::<PyPerformanceProfiler>()?;

    m.add_class::<PyTextProcessor>()?;
    
    // pdfops
    m.add_class::<PyPdfOps>()?;

    Ok(())
}
