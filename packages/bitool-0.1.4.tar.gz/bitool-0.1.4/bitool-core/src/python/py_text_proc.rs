use crate::core::text_proc::{DiffLine, MatchInfo, MatchResult, TextProcessor};
/// Python 文本处理接口绑定
use pyo3::prelude::*;

/// Python 可用的文本处理器
#[pyclass]
pub struct PyTextProcessor {
    inner: TextProcessor,
}

#[pymethods]
impl PyTextProcessor {
    #[new]
    fn new() -> Self {
        Self {
            inner: TextProcessor,
        }
    }

    /// 执行正则搜索
    fn regex_search(&self, pattern: &str, text: &str) -> PyResult<PyMatchResult> {
        let result = self.inner.regex_search(pattern, text)?;
        Ok(PyMatchResult { inner: result })
    }

    /// 执行正则替换
    fn regex_replace(&self, pattern: &str, text: &str, replacement: &str) -> PyResult<String> {
        self.inner.regex_replace(pattern, text, replacement)
    }

    /// 验证正则表达式
    fn validate_regex(&self, pattern: &str) -> PyResult<bool> {
        self.inner.validate_regex(pattern)
    }

    /// 文本 diff
    fn text_diff(&self, old_text: &str, new_text: &str) -> PyResult<Vec<PyDiffLine>> {
        let diff = self.inner.text_diff(old_text, new_text)?;
        Ok(diff.into_iter().map(|d| PyDiffLine { inner: d }).collect())
    }

    /// 编码转换
    fn convert_encoding(
        &self,
        text: &str,
        from_encoding: &str,
        to_encoding: &str,
    ) -> PyResult<String> {
        self.inner
            .convert_encoding(text, from_encoding, to_encoding)
    }
}

/// Python 可用的匹配结果
#[pyclass]
pub struct PyMatchResult {
    inner: MatchResult,
}

#[pymethods]
impl PyMatchResult {
    #[getter]
    fn matched(&self) -> bool {
        self.inner.matched
    }

    #[getter]
    fn matches(&self) -> Vec<PyMatchInfo> {
        self.inner
            .matches
            .iter()
            .map(|m| PyMatchInfo { inner: m.clone() })
            .collect()
    }
}

/// Python 可用的匹配信息
#[pyclass]
pub struct PyMatchInfo {
    inner: MatchInfo,
}

#[pymethods]
impl PyMatchInfo {
    #[getter]
    fn start(&self) -> usize {
        self.inner.start
    }

    #[getter]
    fn end(&self) -> usize {
        self.inner.end
    }

    #[getter]
    fn text(&self) -> String {
        self.inner.text.clone()
    }

    #[getter]
    fn groups(&self) -> Vec<String> {
        self.inner.groups.clone()
    }
}

/// Python 可用的 Diff 行
#[pyclass]
pub struct PyDiffLine {
    inner: DiffLine,
}

#[pymethods]
impl PyDiffLine {
    #[getter]
    fn line_type(&self) -> String {
        self.inner.line_type.clone()
    }

    #[getter]
    fn line_number(&self) -> usize {
        self.inner.line_number
    }

    #[getter]
    fn content(&self) -> String {
        self.inner.content.clone()
    }

    fn __repr__(&self) -> String {
        format!(
            "DiffLine(type='{}', line={}, content='{}')",
            self.inner.line_type, self.inner.line_number, self.inner.content
        )
    }
}
