use crate::plugins::registry::{PluginInfo, PluginRegistry};
/// 插件加载器
use std::path::Path;

/// 插件加载器
pub struct PluginLoader;

impl PluginLoader {
    pub fn new() -> Self {
        Self
    }

    /// 从目录加载插件（简化版，实际应解析 Python 插件文件）
    pub fn load_plugins_from_directory(
        &self,
        directory: &str,
        registry: &mut PluginRegistry,
    ) -> Result<(), String> {
        let path = Path::new(directory);

        if !path.exists() {
            return Ok(()); // 目录不存在时静默返回
        }

        if !path.is_dir() {
            return Err(format!("路径不是目录: {}", directory));
        }

        // 扫描目录中的 .py 文件
        for entry in std::fs::read_dir(path).map_err(|e| format!("读取目录失败: {}", e))? {
            let entry = entry.map_err(|e| format!("读取条目失败: {}", e))?;
            let path = entry.path();

            if path.extension().and_then(|s| s.to_str()) == Some("py") {
                if let Some(file_name) = path.file_stem().and_then(|s| s.to_str()) {
                    // 跳过 __init__ 文件
                    if file_name.starts_with("__") {
                        continue;
                    }

                    let plugin_info = PluginInfo {
                        name: file_name.to_string(),
                        version: "0.1.0".to_string(),
                        description: format!("从 {} 加载的插件", path.display()),
                    };

                    if let Err(e) = registry.register_plugin(plugin_info) {
                        eprintln!("警告: {}", e);
                    }
                }
            }
        }

        Ok(())
    }
}
