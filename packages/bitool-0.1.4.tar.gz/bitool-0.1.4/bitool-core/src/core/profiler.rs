use pyo3::prelude::*;
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

/// 单次调用的性能指标
#[derive(Debug, Clone)]
#[pyclass(skip_from_py_object)]
pub struct ProfileRecord {
    /// 函数/方法名称
    #[pyo3(get)]
    pub name: String,
    /// 调用时间（秒）
    #[pyo3(get)]
    pub duration_secs: f64,
    /// 调用开始时的内存占用（MB）
    #[pyo3(get)]
    pub memory_before_mb: f64,
    /// 调用结束时的内存占用（MB）
    #[pyo3(get)]
    pub memory_after_mb: f64,
    /// 内存变化（MB）
    #[pyo3(get)]
    pub memory_delta_mb: f64,
    /// 调用时间戳
    #[pyo3(get)]
    pub timestamp: String,
}

#[pymethods]
impl ProfileRecord {
    fn __repr__(&self) -> String {
        format!(
            "ProfileRecord(name='{}', time={:.4}s, memory_delta={:.2}MB)",
            self.name, self.duration_secs, self.memory_delta_mb
        )
    }
}

/// 性能分析器
///
/// 用于追踪 Rust 函数的调用时间和内存占用
#[pyclass]
pub struct PerformanceProfiler {
    /// 存储所有性能记录
    records: Arc<Mutex<Vec<ProfileRecord>>>,
    /// 当前活跃的计时器 (name -> (Instant, memory_before_mb))
    active_timers: Arc<Mutex<HashMap<String, (Instant, f64)>>>,
    /// 调用次数统计
    call_counts: Arc<Mutex<HashMap<String, u64>>>,
    /// 总耗时统计
    total_durations: Arc<Mutex<HashMap<String, Duration>>>,
}

#[pymethods]
impl PerformanceProfiler {
    #[new]
    /// 创建新的性能分析器实例
    pub fn new() -> Self {
        Self {
            records: Arc::new(Mutex::new(Vec::new())),
            active_timers: Arc::new(Mutex::new(HashMap::new())),
            call_counts: Arc::new(Mutex::new(HashMap::new())),
            total_durations: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    /// 开始追踪某个函数调用
    pub fn start_timer(&self, name: &str) {
        let mut timers = self.active_timers.lock().unwrap();
        // 记录开始时间和内存
        let memory_before = self.get_current_memory_mb();
        timers.insert(name.to_string(), (Instant::now(), memory_before));
    }

    /// 停止追踪并记录性能数据
    pub fn stop_timer(&self, name: &str) -> PyResult<Option<ProfileRecord>> {
        let (instant, memory_before) = {
            let mut timers = self.active_timers.lock().unwrap();
            timers.remove(name).ok_or_else(|| {
                pyo3::exceptions::PyValueError::new_err(format!("未找到计时器: {}", name))
            })?
        };

        let duration = instant.elapsed();
        let duration_secs = duration.as_secs_f64();

        // 获取内存信息
        let memory_after = self.get_current_memory_mb();
        let memory_delta = memory_after - memory_before;

        // 生成时间戳
        let timestamp = chrono::Local::now()
            .format("%Y-%m-%d %H:%M:%S%.3f")
            .to_string();

        let record = ProfileRecord {
            name: name.to_string(),
            duration_secs,
            memory_before_mb: memory_before,
            memory_after_mb: memory_after,
            memory_delta_mb: memory_delta,
            timestamp,
        };

        // 保存记录
        {
            let mut records = self.records.lock().unwrap();
            records.push(record.clone());
        }

        // 更新统计信息
        {
            let mut counts = self.call_counts.lock().unwrap();
            *counts.entry(name.to_string()).or_insert(0) += 1;
        }

        {
            let mut durations = self.total_durations.lock().unwrap();
            let entry = durations
                .entry(name.to_string())
                .or_insert(Duration::new(0, 0));
            *entry += duration;
        }

        Ok(Some(record))
    }

    /// 获取当前进程的内存占用（MB）
    fn get_current_memory_mb(&self) -> f64 {
        // 在 Windows 上，我们可以通过读取进程信息获取内存使用量
        // 这里使用一个简单的估算方法，实际项目中可以使用更精确的方法
        #[cfg(target_os = "windows")]
        {
            // Windows 特定实现
            // 使用 sysinfo crate 会更准确，但为了减少依赖，这里返回 0
            // 实际使用时建议添加 sysinfo 依赖
            0.0
        }

        #[cfg(not(target_os = "windows"))]
        {
            // Unix/Linux 实现
            // 读取 /proc/self/status 中的 VmRSS
            use std::fs;
            if let Ok(status) = fs::read_to_string("/proc/self/status") {
                for line in status.lines() {
                    if line.starts_with("VmRSS:") {
                        if let Some(value) = line.split_whitespace().nth(1) {
                            if let Ok(kb) = value.parse::<f64>() {
                                return kb / 1024.0; // 转换为 MB
                            }
                        }
                    }
                }
            }
            0.0
        }
    }

    /// 获取所有性能记录
    pub fn get_records(&self) -> Vec<ProfileRecord> {
        let records = self.records.lock().unwrap();
        records.clone()
    }

    /// 获取特定函数的调用次数
    pub fn get_call_count(&self, name: &str) -> u64 {
        let counts = self.call_counts.lock().unwrap();
        counts.get(name).copied().unwrap_or(0)
    }

    /// 获取特定函数的总耗时（秒）
    pub fn get_total_duration(&self, name: &str) -> f64 {
        let durations = self.total_durations.lock().unwrap();
        durations.get(name).map(|d| d.as_secs_f64()).unwrap_or(0.0)
    }

    /// 获取特定函数的平均调用时间（秒）
    pub fn get_average_duration(&self, name: &str) -> f64 {
        let count = self.get_call_count(name);
        if count == 0 {
            return 0.0;
        }
        let total = self.get_total_duration(name);
        total / count as f64
    }

    /// 清除所有记录
    pub fn clear(&self) {
        let mut records = self.records.lock().unwrap();
        records.clear();

        let mut counts = self.call_counts.lock().unwrap();
        counts.clear();

        let mut durations = self.total_durations.lock().unwrap();
        durations.clear();

        let mut timers = self.active_timers.lock().unwrap();
        timers.clear();
    }

    /// 获取性能摘要
    pub fn get_summary(&self) -> PyResult<String> {
        let counts = self.call_counts.lock().unwrap();
        let durations = self.total_durations.lock().unwrap();
        let records = self.records.lock().unwrap();

        if records.is_empty() {
            return Ok("无性能数据".to_string());
        }

        let mut summary = String::from("性能分析摘要:\n");
        summary.push_str(&"=".repeat(50));
        summary.push_str("\n");

        let total_calls: u64 = counts.values().sum();
        let total_time: f64 = durations.values().map(|d| d.as_secs_f64()).sum();

        summary.push_str(&format!("总调用次数: {}\n", total_calls));
        summary.push_str(&format!("总耗时: {:.4}s\n", total_time));
        summary.push_str(&format!("记录总数: {}\n", records.len()));
        summary.push_str(&"-".repeat(50));
        summary.push_str("\n");

        // 按函数名称汇总
        for (name, count) in counts.iter() {
            let total_dur = durations.get(name).map(|d| d.as_secs_f64()).unwrap_or(0.0);
            let avg_dur = if *count > 0 {
                total_dur / *count as f64
            } else {
                0.0
            };

            summary.push_str(&format!(
                "函数: {} | 调用次数: {} | 总耗时: {:.4}s | 平均耗时: {:.4}s\n",
                name, count, total_dur, avg_dur
            ));
        }

        summary.push_str(&"=".repeat(50));

        Ok(summary)
    }
}

/// 为 PerformanceProfiler 实现 Send 和 Sync，使其可以在多线程环境中安全使用
unsafe impl Send for PerformanceProfiler {}
unsafe impl Sync for PerformanceProfiler {}
