use pyo3::prelude::*;
/// 配置管理模块
///
/// 使用 serde 进行高性能 JSON/YAML 解析，支持配置缓存和热重载
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs;
use std::path::Path;

/// 工作空间配置
#[derive(Debug, Clone, Serialize, Deserialize)]
#[pyclass(from_py_object)]
pub struct WorkspaceConfig {
    #[pyo3(get, set)]
    pub root: String,
    #[pyo3(get, set)]
    pub env_file: String,
    #[pyo3(get, set)]
    pub variables: HashMap<String, String>,
}


#[pymethods]
impl WorkspaceConfig {
    #[new]
    pub fn new(root: Option<String>, env_file: Option<String>) -> Self {
        Self {
            root: root.unwrap_or_default(),
            env_file: env_file.unwrap_or_else(|| ".env".to_string()),
            variables: HashMap::new(),
        }
    }

    /// 设置工作空间变量
    pub fn set_var(&mut self, name: String, value: String) {
        self.variables.insert(name, value);
    }

    /// 获取工作空间变量
    pub fn get_var(&self, name: &str, default: Option<String>) -> String {
        self.variables
            .get(name)
            .cloned()
            .unwrap_or(default.unwrap_or_default())
    }

    /// 解析相对于工作空间根目录的路径
    pub fn resolve_path(&self, relative_path: &str) -> PyResult<String> {
        let path = Path::new(relative_path);
        if path.is_absolute() {
            Ok(relative_path.to_string())
        } else {
            let root_path = Path::new(&self.root);
            let resolved = root_path.join(path);
            Ok(resolved.to_string_lossy().to_string())
        }
    }
}

/// Bitool 主配置
#[derive(Debug, Clone, Serialize, Deserialize)]
#[pyclass(from_py_object)]
pub struct BitoolConfig {
    #[pyo3(get, set)]
    pub mode: String,
    #[pyo3(get, set)]
    pub log_level: String,
    #[pyo3(get, set)]
    pub workspace: Option<WorkspaceConfig>,
    #[pyo3(get, set)]
    pub plugin_dirs: Vec<String>,
}


#[pymethods]
impl BitoolConfig {
    #[new]
    pub fn new(
        mode: Option<String>,
        log_level: Option<String>,
        workspace: Option<WorkspaceConfig>,
        plugin_dirs: Option<Vec<String>>,
    ) -> Self {
        Self {
            mode: mode.unwrap_or_else(|| "local".to_string()),
            log_level: log_level.unwrap_or_else(|| "INFO".to_string()),
            workspace,
            plugin_dirs: plugin_dirs.unwrap_or_else(|| vec!["~/.bitool/plugins".to_string()]),
        }
    }

    /// 从 JSON 文件加载配置
    #[staticmethod]
    pub fn load_from_file(config_file: &str) -> PyResult<Self> {
        let path = Path::new(config_file);
        if !path.exists() {
            return Err(pyo3::exceptions::PyFileNotFoundError::new_err(format!(
                "配置文件不存在: {}",
                config_file
            )));
        }

        let content = fs::read_to_string(path).map_err(|e| {
            pyo3::exceptions::PyIOError::new_err(format!("读取配置文件失败: {}", e))
        })?;

        let config: BitoolConfig = serde_json::from_str(&content).map_err(|e| {
            pyo3::exceptions::PyValueError::new_err(format!("解析配置文件失败: {}", e))
        })?;

        Ok(config)
    }

    /// 保存配置到 JSON 文件
    pub fn save_to_file(&self, config_file: &str) -> PyResult<()> {
        let path = Path::new(config_file);
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent).map_err(|e| {
                pyo3::exceptions::PyIOError::new_err(format!("创建目录失败: {}", e))
            })?;
        }

        let content = serde_json::to_string_pretty(self).map_err(|e| {
            pyo3::exceptions::PyValueError::new_err(format!("序列化配置失败: {}", e))
        })?;

        fs::write(path, content).map_err(|e| {
            pyo3::exceptions::PyIOError::new_err(format!("写入配置文件失败: {}", e))
        })?;

        Ok(())
    }

    /// 展开环境变量 (如 ${HOME})
    pub fn expand_env_vars(&self, value: &str) -> String {
        let re = regex::Regex::new(r"\$\{(\w+)\}").unwrap();
        re.replace_all(value, |caps: &regex::Captures| {
            let env_var = &caps[1];
            std::env::var(env_var).unwrap_or_else(|_| caps[0].to_string())
        })
        .to_string()
    }
}
