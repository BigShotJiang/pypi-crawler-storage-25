use pyo3::prelude::*;
/// 文本处理模块
///
/// 提供高性能正则匹配、编码转换、文本 diff 算法
use regex::Regex;

/// 正则匹配结果
#[derive(Debug, Clone)]
#[pyclass(skip_from_py_object)]
pub struct MatchResult {
    #[pyo3(get)]
    pub matched: bool,
    #[pyo3(get)]
    pub matches: Vec<MatchInfo>,
}

#[derive(Debug, Clone)]
#[pyclass(skip_from_py_object)]
pub struct MatchInfo {
    #[pyo3(get)]
    pub start: usize,
    #[pyo3(get)]
    pub end: usize,
    #[pyo3(get)]
    pub text: String,
    #[pyo3(get)]
    pub groups: Vec<String>,
}

/// 文本处理器
#[pyclass]
pub struct TextProcessor;

#[pymethods]
impl TextProcessor {
    #[new]
    fn new() -> Self {
        Self
    }

    /// 执行正则搜索
    pub fn regex_search(&self, pattern: &str, text: &str) -> PyResult<MatchResult> {
        let re = Regex::new(pattern).map_err(|e| {
            pyo3::exceptions::PyValueError::new_err(format!("无效的正则表达式: {}", e))
        })?;

        let matches: Vec<MatchInfo> = re
            .find_iter(text)
            .map(|mat| {
                let groups: Vec<String> = (0..mat.as_str().len())
                    .map(|i| mat.as_str()[i..i + 1].to_string())
                    .collect();

                MatchInfo {
                    start: mat.start(),
                    end: mat.end(),
                    text: mat.as_str().to_string(),
                    groups,
                }
            })
            .collect();

        Ok(MatchResult {
            matched: !matches.is_empty(),
            matches,
        })
    }

    /// 执行正则替换
    pub fn regex_replace(&self, pattern: &str, text: &str, replacement: &str) -> PyResult<String> {
        let re = Regex::new(pattern).map_err(|e| {
            pyo3::exceptions::PyValueError::new_err(format!("无效的正则表达式: {}", e))
        })?;

        Ok(re.replace_all(text, replacement).to_string())
    }

    /// 验证正则表达式是否有效
    pub fn validate_regex(&self, pattern: &str) -> PyResult<bool> {
        match Regex::new(pattern) {
            Ok(_) => Ok(true),
            Err(_) => Ok(false),
        }
    }

    /// 简单的文本 diff（行级别）
    pub fn text_diff(&self, old_text: &str, new_text: &str) -> PyResult<Vec<DiffLine>> {
        let old_lines: Vec<&str> = old_text.lines().collect();
        let new_lines: Vec<&str> = new_text.lines().collect();

        let mut diff = Vec::new();
        let mut i = 0;
        let mut j = 0;

        while i < old_lines.len() || j < new_lines.len() {
            if i < old_lines.len() && j < new_lines.len() {
                if old_lines[i] == new_lines[j] {
                    diff.push(DiffLine {
                        line_type: "unchanged".to_string(),
                        line_number: i + 1,
                        content: old_lines[i].to_string(),
                    });
                    i += 1;
                    j += 1;
                } else {
                    // 简单的删除/添加检测
                    diff.push(DiffLine {
                        line_type: "removed".to_string(),
                        line_number: i + 1,
                        content: old_lines[i].to_string(),
                    });
                    diff.push(DiffLine {
                        line_type: "added".to_string(),
                        line_number: j + 1,
                        content: new_lines[j].to_string(),
                    });
                    i += 1;
                    j += 1;
                }
            } else if i < old_lines.len() {
                diff.push(DiffLine {
                    line_type: "removed".to_string(),
                    line_number: i + 1,
                    content: old_lines[i].to_string(),
                });
                i += 1;
            } else {
                diff.push(DiffLine {
                    line_type: "added".to_string(),
                    line_number: j + 1,
                    content: new_lines[j].to_string(),
                });
                j += 1;
            }
        }

        Ok(diff)
    }

    /// 编码转换（简化版，实际应使用 encoding_rs）
    pub fn convert_encoding(
        &self,
        text: &str,
        from_encoding: &str,
        to_encoding: &str,
    ) -> PyResult<String> {
        // 这里简化处理，实际应使用 encoding_rs crate
        // 目前只支持 UTF-8 相关转换
        if from_encoding.to_lowercase() == "utf-8" && to_encoding.to_lowercase() == "utf-8" {
            Ok(text.to_string())
        } else {
            Err(pyo3::exceptions::PyValueError::new_err(format!(
                "不支持的编码转换: {} -> {}",
                from_encoding, to_encoding
            )))
        }
    }
}

/// Diff 行信息
#[derive(Debug, Clone)]
#[pyclass(skip_from_py_object)]
pub struct DiffLine {
    #[pyo3(get)]
    pub line_type: String, // "added", "removed", "unchanged"
    #[pyo3(get)]
    pub line_number: usize,
    #[pyo3(get)]
    pub content: String,
}

#[pymethods]
impl DiffLine {
    fn __repr__(&self) -> String {
        format!(
            "DiffLine(type='{}', line={}, content='{}')",
            self.line_type, self.line_number, self.content
        )
    }
}
