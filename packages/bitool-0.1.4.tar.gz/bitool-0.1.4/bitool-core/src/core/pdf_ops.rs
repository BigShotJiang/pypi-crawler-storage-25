//! PDF操作核心模块
//! 提供PDF拆分、合并、压缩、转换等功能

use lopdf::Document;
use pdfium_render::prelude::*;
use std::fs;
use std::path::Path;

/// PDF操作结构体
pub struct PdfOps;

impl PdfOps {
    /// 创建新的PDF操作实例
    pub fn new() -> Self {
        PdfOps
    }

    /// 按页数拆分PDF
    /// 
    /// # 参数
    /// - `input_path`: 输入PDF文件路径
    /// - `output_dir`: 输出目录
    /// - `pages_per_file`: 每个文件的页数
    /// 
    /// # 返回
    /// 成功时返回生成的文件路径列表，失败时返回错误信息
    pub fn split_pdf(
        input_path: &str,
        output_dir: &str,
        pages_per_file: usize,
    ) -> Result<Vec<String>, String> {
        if pages_per_file == 0 {
            return Err("每文件页数必须大于0".to_string());
        }

        let doc = Document::load(input_path)
            .map_err(|e| format!("无法加载PDF文件: {}", e))?;

        let total_pages = doc.page_iter().count();
        fs::create_dir_all(output_dir)
            .map_err(|e| format!("无法创建输出目录: {}", e))?;

        let mut output_files = Vec::new();
        let mut current_page = 1;

        while current_page <= total_pages {
            let end_page = std::cmp::min(current_page + pages_per_file - 1, total_pages);
            let output_path = format!(
                "{}/part_{}-{}.pdf",
                output_dir, current_page, end_page
            );

            Self::extract_pages(&doc, current_page, end_page, &output_path)?;
            output_files.push(output_path);

            current_page = end_page + 1;
        }

        Ok(output_files)
    }

    /// 按页码范围拆分PDF
    /// 
    /// # 参数
    /// - `input_path`: 输入PDF文件路径
    /// - `output_dir`: 输出目录
    /// - `ranges`: 页码范围列表，格式如 "1-5,10-15,20"
    /// 
    /// # 返回
    /// 成功时返回生成的文件路径列表，失败时返回错误信息
    pub fn split_pdf_by_ranges(
        input_path: &str,
        output_dir: &str,
        ranges: &str,
    ) -> Result<Vec<String>, String> {
        let doc = Document::load(input_path)
            .map_err(|e| format!("无法加载PDF文件: {}", e))?;

        let total_pages = doc.page_iter().count();
        fs::create_dir_all(output_dir)
            .map_err(|e| format!("无法创建输出目录: {}", e))?;

        let mut output_files = Vec::new();
        let range_parts: Vec<&str> = ranges.split(',').collect();

        for (idx, range_str) in range_parts.iter().enumerate() {
            let (start, end) = Self::parse_range(range_str.trim(), total_pages)?;
            let output_path = format!("{}/range_{}.pdf", output_dir, idx + 1);

            Self::extract_pages(&doc, start, end, &output_path)?;
            output_files.push(output_path);
        }

        Ok(output_files)
    }

    /// 合并多个PDF文件
    /// 
    /// # 参数
    /// - `input_paths`: 输入PDF文件路径列表
    /// - `output_path`: 输出PDF文件路径
    /// 
    /// # 返回
    /// 成功时返回Ok(())，失败时返回错误信息
    pub fn merge_pdfs(input_paths: &[String], output_path: &str) -> Result<(), String> {
        if input_paths.is_empty() {
            return Err("输入文件列表不能为空".to_string());
        }

        // 使用第一个PDF作为基础
        let mut merged_doc = Document::load(&input_paths[0])
            .map_err(|e| format!("无法加载PDF文件 {}: {}", &input_paths[0], e))?;

        // 从第二个PDF开始合并
        for path in &input_paths[1..] {
            let doc = Document::load(path)
                .map_err(|e| format!("无法加载PDF文件 {}: {}", path, e))?;

            // 使用lopdf的merge_document方法（如果可用）
            // 或者手动复制页面对象
            for (_, page_id) in doc.get_pages() {
                if let Ok(page_obj) = doc.get_object(page_id) {
                    let new_id = merged_doc.new_object_id();
                    merged_doc.objects.insert(new_id, page_obj.clone());
                }
            }
        }

        // 保存合并后的PDF
        if let Some(parent) = Path::new(output_path).parent() {
            fs::create_dir_all(parent)
                .map_err(|e| format!("无法创建输出目录: {}", e))?;
        }

        merged_doc
            .save(output_path)
            .map_err(|e| format!("无法保存合并后的PDF: {}", e))?;

        Ok(())
    }

    /// 压缩PDF文件
    /// 
    /// # 参数
    /// - `input_path`: 输入PDF文件路径
    /// - `output_path`: 输出PDF文件路径
    /// - `quality`: 压缩质量 (1-100，值越高质量越好)
    /// 
    /// # 返回
    /// 成功时返回Ok(())，失败时返回错误信息
    pub fn compress_pdf(
        input_path: &str,
        output_path: &str,
        quality: u8,
    ) -> Result<(), String> {
        if quality == 0 || quality > 100 {
            return Err("压缩质量必须在1-100之间".to_string());
        }

        let mut doc = Document::load(input_path)
            .map_err(|e| format!("无法加载PDF文件: {}", e))?;

        // 简化压缩：移除未使用的对象
        doc.delete_pages(&[]); // 清理未使用的页面
        doc.prune_objects();

        // 保存压缩后的PDF
        if let Some(parent) = Path::new(output_path).parent() {
            fs::create_dir_all(parent)
                .map_err(|e| format!("无法创建输出目录: {}", e))?;
        }

        doc.save(output_path)
            .map_err(|e| format!("无法保存压缩后的PDF: {}", e))?;

        Ok(())
    }

    /// 将PDF转换为图片
    /// 
    /// # 参数
    /// - `input_path`: 输入PDF文件路径
    /// - `output_dir`: 输出目录
    /// - `format`: 图片格式 ("png" 或 "jpg")
    /// - `dpi`: 分辨率 (dots per inch)
    /// 
    /// # 返回
    /// 成功时返回生成的图片文件路径列表，失败时返回错误信息
    pub fn pdf_to_images(
        input_path: &str,
        output_dir: &str,
        fmt: &str,
        _dpi: u32,
    ) -> Result<Vec<String>, String> {
        // 创建输出目录
        fs::create_dir_all(output_dir)
            .map_err(|e| format!("无法创建输出目录: {}", e))?;

        // 初始化PDFium
        let pdfium = Pdfium::new(
            Pdfium::bind_to_library(
                Pdfium::pdfium_platform_library_name_at_path(".")
            ).or_else(|_| {
                Pdfium::bind_to_system_library()
            }).map_err(|e| format!("无法加载PDFium库: {}。请确保PDFium库已正确配置。", e))?
        );

        // 加载PDF文档
        let pdf = pdfium.load_pdf_from_file(input_path, None)
            .map_err(|e| format!("无法加载PDF文件: {}", e))?;

        let pages = pdf.pages();
        let mut output_files = Vec::new();

        // 遍历每一页并转换为图片
        for (idx, page) in pages.iter().enumerate() {
            // 渲染页面为图片
            let render_config = PdfRenderConfig::new();
            let bitmap = page.render_with_config(&render_config)
                .map_err(|e| format!("渲染页面 {} 失败: {}", idx + 1, e))?;

            // 根据格式保存图片
            let output_path = format!("{}/page_{}.{}", output_dir, idx + 1, fmt);
            
            let image = bitmap.as_image();
            match fmt.to_lowercase().as_str() {
                "png" => {
                    image.save_with_format(&output_path, image::ImageFormat::Png)
                        .map_err(|e| format!("保存图片 {} 失败: {}", output_path, e))?;
                }
                "jpg" | "jpeg" => {
                    image.save_with_format(&output_path, image::ImageFormat::Jpeg)
                        .map_err(|e| format!("保存图片 {} 失败: {}", output_path, e))?;
                }
                other => {
                    return Err(format!("不支持的图片格式: {}。支持的格式: png, jpg, jpeg", other));
                }
            }

            output_files.push(output_path);
        }

        Ok(output_files)
    }

    /// 将图片列表转换为PDF
    /// 
    /// # 参数
    /// - `image_paths`: 输入图片文件路径列表
    /// - `output_path`: 输出PDF文件路径
    /// - `page_size`: 页面尺寸 ("A4", "letter" 或 "auto")
    /// 
    /// # 返回
    /// 成功时返回Ok(())，失败时返回错误信息
    pub fn images_to_pdf(
        image_paths: &[String],
        output_path: &str,
        _page_size: &str,
    ) -> Result<(), String> {
        if image_paths.is_empty() {
            return Err("图片路径列表不能为空".to_string());
        }

        let mut doc = Document::with_version("1.7");

        for (_idx, img_path) in image_paths.iter().enumerate() {
            // 读取图片
            let _img_data = fs::read(img_path)
                .map_err(|e| format!("无法读取图片文件 {}: {}", img_path, e))?;

            // 这里需要更复杂的逻辑来处理图片尺寸和页面布局
            // 简化实现：创建一个页面并添加图片
            // 实际实现需要使用lopdf的图像嵌入功能
        }

        // 保存PDF
        if let Some(parent) = Path::new(output_path).parent() {
            fs::create_dir_all(parent)
                .map_err(|e| format!("无法创建输出目录: {}", e))?;
        }

        doc.save(output_path)
            .map_err(|e| format!("无法保存PDF: {}", e))?;

        Ok(())
    }

    // ==================== 私有辅助方法 ====================

    /// 从PDF文档中提取指定页面并保存
    fn extract_pages(
        doc: &Document,
        start_page: usize,
        end_page: usize,
        output_path: &str,
    ) -> Result<(), String> {
        let mut new_doc = Document::with_version(doc.version.clone());

        // 获取所有页面
        let pages = doc.get_pages();
        let page_vec: Vec<_> = pages.iter().collect();
        
        // 复制指定范围的页面
        for i in (start_page-1)..end_page {
            if i < page_vec.len() {
                let (_, page_id) = page_vec[i];
                if let Ok(page_obj) = doc.get_object(*page_id) {
                    let new_id = new_doc.new_object_id();
                    new_doc.objects.insert(new_id, page_obj.clone());
                }
            }
        }

        // 保存新文档
        new_doc
            .save(output_path)
            .map_err(|e| format!("无法保存拆分后的PDF: {}", e))?;

        Ok(())
    }

    /// 解析页码范围字符串
    fn parse_range(range_str: &str, total_pages: usize) -> Result<(usize, usize), String> {
        if range_str.contains('-') {
            let parts: Vec<&str> = range_str.split('-').collect();
            if parts.len() != 2 {
                return Err(format!("无效的页码范围: {}", range_str));
            }

            let start: usize = parts[0]
                .trim()
                .parse()
                .map_err(|e| format!("无效的起始页码: {}", e))?;
            let end: usize = parts[1]
                .trim()
                .parse()
                .map_err(|e| format!("无效的结束页码: {}", e))?;

            if start == 0 || end == 0 || start > total_pages || end > total_pages || start > end {
                return Err(format!(
                    "页码范围无效: {} (总页数: {})",
                    range_str, total_pages
                ));
            }

            Ok((start, end))
        } else {
            // 单个页码
            let page: usize = range_str
                .trim()
                .parse()
                .map_err(|e| format!("无效的页码: {}", e))?;

            if page == 0 || page > total_pages {
                return Err(format!("页码无效: {} (总页数: {})", range_str, total_pages));
            }

            Ok((page, page))
        }
    }
}
