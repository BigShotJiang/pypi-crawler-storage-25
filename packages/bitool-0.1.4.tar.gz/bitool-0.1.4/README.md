# Bitool

基于 Maturin 的 Rust + Python 混合架构工具集，将性能瓶颈和共性部分使用 Rust 实现，接口和逻辑部分使用 Python 实现。

## 特性

- **高性能**：核心计算和 I/O 操作使用 Rust 实现
- **易用性**：Python 提供简洁的 API 接口
- **可扩展**：插件系统支持功能扩展
- **跨平台**：支持 Windows、Linux、macOS

## 安装

```bash
pip install bitool
```

## 开发

### 快速开始（推荐）

```bash
# 安装开发环境（自动构建 Rust + Python 双包）
pymake ia

# 验证安装
pymake t
```

### 常用命令

```bash
# 构建所有包（Rust + Python）
pymake ba

# 代码格式化与检查
pymake lint

# 运行测试
pymake t

# 清理所有构建产物
pymake ca

# 查看完整帮助
pymake help
```

### 手动构建（可选）

```bash
# 构建 Rust 核心模块
cd bitool-core && maturin develop

# 构建 Python 主包
cd .. && pip install -e .

# 构建发布包
cd bitool-core && maturin build -r
cd .. && python -m build
```

> 📖 详细文档：[PyMake 使用指南](docs/PYMAKE_GUIDE.md) | [双包构建指南](docs/DUAL_PACKAGE_BUILD.md)

## 项目结构

```bash
bitool/
├── bitool-core/            # Rust 核心模块
│   ├── src/                # Rust 源代码
│   │   ├── core/           # 核心功能模块
│   │   ├── plugins/        # 插件系统核心
│   │   └── python/         # Python 绑定
│   ├── Cargo.toml          # Rust 依赖配置
│   └── pyproject.toml      # Maturin 构建配置
├── src/bitool/             # Python 主包
│   ├── core/               # 核心业务逻辑
│   ├── cmd/                # 命令系统
│   ├── scripts/            # CLI 工具集
│   ├── utils/              # 工具模块
│   └── cli/                # 命令行入口
├── docs/                   # 项目文档
├── pyproject.toml          # Python 包配置
├── Makefile                # 构建脚本（可选）
└── build_all.py            # Python 构建脚本
```

## 使用示例

```python
from bitool import FileOps, TextProcessor

# 文件操作
file_ops = FileOps()
files = file_ops.scan_directory("/path/to/dir")

# 文本处理
processor = TextProcessor()
result = processor.regex_search(pattern, text)
```

## 许可证

MIT License
