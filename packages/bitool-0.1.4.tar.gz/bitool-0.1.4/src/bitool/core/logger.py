"""Bitool 的日志模块.

本模块提供一个简单的、类似 loguru 的日志系统,具有彩色输出、文件轮转和易于使用的 API.

快速开始
--------
>>> from bitool.core import logger
>>> logger.info("Hello, World!")  # 彩色输出到控制台和文件
>>> logger.debug("看不到调试信息")
>>> logger.setLevel(logger.DEBUG)
>>> logger.debug("现在可以看到调试信息了")
"""

from __future__ import annotations

import contextlib
import logging
import logging.handlers
import platform
import sys
import threading
from pathlib import Path
from typing import ClassVar, Final

__all__ = ["logger"]

# 默认日志格式
_DEFAULT_CONSOLE_FORMAT: Final[str] = "%(asctime)s | %(levelname)-8s | %(message)s"
_DEFAULT_FILE_FORMAT: Final[str] = (
    "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
_DEFAULT_CONSOLE_DATEFMT: Final[str] = "%H:%M:%S"
_DEFAULT_FILE_DATEFMT: Final[str] = "%Y-%m-%d %H:%M:%S"

# 默认日志路径
_DEFAULT_LOG_DIR: Final[Path] = Path.home() / ".bitool" / "logs"
_DEFAULT_LOG_FILE: Final[Path] = _DEFAULT_LOG_DIR / "bitool.log"
_DEFAULT_MAX_BYTES: Final[int] = 10 * 1024 * 1024  # 10MB
_DEFAULT_BACKUP_COUNT: Final[int] = 5


class _ColoredFormatter(logging.Formatter):
    """自定义格式化器,为日志消息添加 ANSI 颜色."""

    COLORS: ClassVar[dict[str, str]] = {
        "DEBUG": "\033[36m",  # 青色
        "INFO": "\033[32m",  # 绿色
        "WARNING": "\033[33m",  # 黄色
        "ERROR": "\033[31m",  # 红色
        "CRITICAL": "\033[41m",  # 红底白字
        "RESET": "\033[0m",  # 重置颜色
    }

    def __init__(self, fmt: str | None = None, datefmt: str | None = None) -> None:
        """初始化格式化器,检测是否支持 ANSI 颜色."""
        super().__init__(fmt, datefmt)
        # 检测是否启用彩色输出
        self._enable_colors = self._check_color_support()

    @staticmethod
    def _check_color_support() -> bool:
        """检查当前环境是否支持 ANSI 颜色."""
        # Windows 10 及以上版本支持 ANSI 转义序列
        if platform.system() == "Windows":
            try:
                # 获取 Windows 版本号
                version = platform.version()
                # Windows 版本号格式为 "major.minor.build"
                major_version = int(version.split(".")[0])
                # Windows 10 的版本号为 10, Windows 7 为 6

            except (ValueError, IndexError):
                # 如果无法解析版本号,保守起见禁用颜色
                return False
            else:
                return major_version >= 10

        # 非 Windows 系统通常支持 ANSI 颜色
        return True

    def format(self, record: logging.LogRecord) -> str:
        """使用适当的颜色格式化日志记录."""
        message = super().format(record)
        if not self._enable_colors:
            return message
        log_color = self.COLORS.get(record.levelname, self.COLORS["RESET"])
        return f"{log_color}{message}{self.COLORS['RESET']}"


class _Logger:
    """一个简单的、类似 loguru 的日志器.

    提供干净、最小化的 API,用于带有自动控制台颜色和文件轮转的日志记录。

    示例
    --------
        >>> from bitool.core import logger
        >>> logger.info("Hello, World!")
        >>> logger.debug("Debug message")  # 仅在启用调试时显示
        >>> logger.error("Error occurred")
    """

    _instance: ClassVar[logging.Logger | None] = None
    _setup_lock: ClassVar[threading.Lock] = threading.Lock()
    _is_setup: ClassVar[bool] = False

    # 日志级别常量 (与 Python logging 模块兼容)
    DEBUG: Final[int] = logging.DEBUG
    INFO: Final[int] = logging.INFO
    WARNING: Final[int] = logging.WARNING
    ERROR: Final[int] = logging.ERROR
    CRITICAL: Final[int] = logging.CRITICAL

    @classmethod
    def _setup(
        cls,
        name: str = "bitool",
        level: int = logging.INFO,
        console_format: str | None = None,
        file_format: str | None = None,
    ) -> logging.Logger:
        """设置带有控制台和文件处理器的日志器.

        此方法应在应用程序启动时调用一次。
        后续调用将返回现有的日志器实例。

        参数
        ----------
        name : str
            日志器名称。默认为 "bitool"
        level : int
            最低日志级别。默认为 INFO
            使用 logger.DEBUG 获取更详细的输出
        console_format : str, optional
            控制台日志格式。默认为 "%(asctime)s | %(levelname)-8s | %(message)s"
        file_format : str, optional
            文件日志格式。默认为 "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

        返回
        -------
        logging.Logger
            配置好的带有控制台和文件处理器的日志器
        """
        # 线程安全的单例初始化
        with cls._setup_lock:
            if cls._is_setup and cls._instance is not None:
                return cls._instance

            # 确保日志目录存在
            with contextlib.suppress(OSError):
                _DEFAULT_LOG_DIR.mkdir(parents=True, exist_ok=True)

            # 创建日志器
            logger_instance = logging.getLogger(name)
            logger_instance.setLevel(logging.DEBUG)  # 捕获所有级别,在处理器级别过滤

            # 控制台处理器
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setLevel(level)
            console_fmt = console_format if console_format else _DEFAULT_CONSOLE_FORMAT
            console_formatter = _ColoredFormatter(
                console_fmt, datefmt=_DEFAULT_CONSOLE_DATEFMT
            )
            console_handler.setFormatter(console_formatter)

            # 文件处理器 - 捕获所有 DEBUG+ 日志并带轮转功能
            file_handler = logging.handlers.RotatingFileHandler(
                _DEFAULT_LOG_FILE,
                maxBytes=_DEFAULT_MAX_BYTES,
                backupCount=_DEFAULT_BACKUP_COUNT,
                encoding="utf-8",
            )
            file_handler.setLevel(logging.DEBUG)
            file_fmt = file_format if file_format else _DEFAULT_FILE_FORMAT
            file_formatter = logging.Formatter(file_fmt, datefmt=_DEFAULT_FILE_DATEFMT)
            file_handler.setFormatter(file_formatter)

            # 添加处理器
            logger_instance.addHandler(console_handler)
            logger_instance.addHandler(file_handler)

            # 防止多次添加处理器
            logger_instance.propagate = False

            cls._instance = logger_instance
            cls._is_setup = True
            return cls._instance

    @classmethod
    def _get_logger(cls, name: str = "bitool") -> logging.Logger:
        """获取日志器实例.

        如果日志器尚未设置,此方法将使用默认设置进行设置。
        如需自定义配置,请显式调用 setup()。

        参数
        ----------
        name : str
            日志器名称。默认为 "bitool"

        返回
        -------
        logging.Logger
            配置好的日志器实例
        """
        if cls._instance is None:
            return cls._setup(name)
        return cls._instance

    @classmethod
    def setLevel(cls, level: int) -> None:
        """设置日志级别,同时更新 Logger 和所有 Handler 的级别.

        解决 Python logging 的两级过滤问题:
        - Logger 级别:决定哪些消息进入日志系统
        - Handler 级别:决定哪些消息实际输出

        参数
        ----------
        level : int
            日志级别,如 logging.DEBUG, logging.INFO 等

        示例
        --------
        >>> from bitool.core import logger
        >>> logger.setLevel(logger.DEBUG)  # 启用调试日志
        >>> logger.debug("调试信息")  # 现在会正常输出
        """
        if cls._instance is not None:
            logging.Logger.setLevel(cls._instance, level)
            for handler in cls._instance.handlers:
                handler.setLevel(level)


# 预配置的日志器实例,便于导入
logger: Final[logging.Logger] = _Logger._get_logger()
logger.setLevel = _Logger.setLevel  # type: ignore
