"""PDF操作模块, 提供用户友好的PDF操作接口.

注意: 本模块的多个命令类存在重复的验证和错误处理逻辑,
已在内部提取公共辅助函数进行精简.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

try:
    import fitz  # PyMuPDF

    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False

from bitool.cmd import BaseCommand
from bitool.core import logger

__all__ = [
    "CompressPdfCommand",
    "ImagesToPdfCommand",
    "MergePdfsCommand",
    "PdfToImagesCommand",
    "SplitPdfCommand",
]


def _check_pymupdf() -> bool:
    """检查 PyMuPDF 是否可用.

    Returns
    -------
    bool
        如果 PyMuPDF 可用返回 True
    """
    if not HAS_PYMUPDF:
        logger.error("未安装PyMuPDF库, 请安装: pip install PyMuPDF")
        return False
    return True


def _check_input_file(filepath: Path, label: str = "输入文件") -> bool:
    """检查输入文件是否存在.

    Parameters
    ----------
    filepath : Path
        文件路径
    label : str
        文件标签（用于错误提示）

    Returns
    -------
    bool
        如果文件存在返回 True
    """
    if not filepath.exists():
        logger.error(f"{label}不存在: {filepath}")
        return False
    return True


@dataclass
class SplitPdfCommand(BaseCommand):
    """按页数拆分PDF命令

    将PDF文件按照指定的页数拆分成多个小文件
    """

    name = "split_pdf"
    description = "按页数拆分PDF"

    input_path: Path = field(default_factory=Path.cwd)
    output_dir: Path = field(default_factory=Path.cwd)
    pages_per_file: int = 1
    output_files: list[str] = field(default_factory=list)

    def run(self) -> bool:
        """执行PDF拆分操作

        Returns
        -------
        bool
            操作是否成功
        """
        if not _check_pymupdf():
            return False

        if self.pages_per_file <= 0:
            logger.error("每文件页数必须大于0")
            return False

        if not _check_input_file(self.input_path):
            return False

        try:
            # 确保输出目录存在
            self.output_dir.mkdir(parents=True, exist_ok=True)

            logger.info(
                f"开始拆分PDF: {self.input_path}, 每文件 {self.pages_per_file} 页"
            )

            # 打开PDF文档
            doc = fitz.open(self.input_path)
            total_pages = len(doc)
            self.output_files = []

            try:
                # 计算需要拆分成多少个文件
                num_files = (
                    total_pages + self.pages_per_file - 1
                ) // self.pages_per_file

                for i in range(num_files):
                    # 创建新文档
                    new_doc = fitz.open()
                    start_page = i * self.pages_per_file
                    end_page = min(start_page + self.pages_per_file, total_pages)

                    # 添加页面到新文档
                    for page_num in range(start_page, end_page):
                        new_doc.insert_pdf(doc, from_page=page_num, to_page=page_num)

                    # 保存新文档
                    output_path = self.output_dir / f"part_{i + 1}.pdf"
                    new_doc.save(str(output_path))
                    new_doc.close()
                    self.output_files.append(str(output_path))

                logger.info(f"PDF拆分完成, 生成 {len(self.output_files)} 个文件")
            finally:
                doc.close()
        except FileNotFoundError as e:
            logger.error(f"输入文件不存在: {e}")
            return False
        except ValueError as e:
            logger.error(f"参数错误: {e}")
            return False
        except Exception as e:  # noqa: BLE001
            logger.error(f"PDF拆分失败: {e}")
            return False
        else:
            return len(self.output_files) > 0


@dataclass
class MergePdfsCommand(BaseCommand):
    """合并多个PDF文件命令

    将多个PDF文件合并成一个完整的PDF文件
    """

    name = "merge_pdfs"
    description = "合并多个PDF文件"

    input_paths: list[Path] = field(default_factory=list)
    output_path: Path = field(default_factory=lambda: Path.cwd())

    def run(self) -> bool:
        """执行PDF合并操作

        Returns
        -------
        bool
            操作是否成功
        """
        if not _check_pymupdf():
            return False

        if not self.input_paths:
            logger.error("输入文件列表为空")
            return False

        # 检查所有输入文件
        for input_path in self.input_paths:
            if not _check_input_file(input_path):
                return False

        try:
            logger.info(
                f"开始合并 {len(self.input_paths)} 个PDF文件 -> {self.output_path}"
            )

            # 创建新文档
            merged_doc = fitz.open()

            try:
                # 遍历所有输入文件
                for input_path in self.input_paths:
                    doc = fitz.open(str(input_path))
                    merged_doc.insert_pdf(doc)
                    doc.close()

                # 确保输出目录存在
                self.output_path.parent.mkdir(parents=True, exist_ok=True)

                # 保存合并后的文档
                merged_doc.save(str(self.output_path))
                logger.info(f"PDF合并完成: {self.output_path}")
            finally:
                merged_doc.close()
        except FileNotFoundError as e:
            logger.error(f"输入文件不存在: {e}")
            return False
        except Exception as e:  # noqa: BLE001
            logger.error(f"PDF合并失败: {e}")
            return False
        else:
            return True


@dataclass
class CompressPdfCommand(BaseCommand):
    """压缩PDF文件命令

    对PDF文件进行压缩以减小文件大小
    """

    name = "compress_pdf"
    description = "压缩PDF文件"

    input_path: Path = field(default_factory=Path.cwd)
    output_path: Path = field(default_factory=Path.cwd)
    quality: int = 75

    def run(self) -> bool:
        """执行PDF压缩操作

        Returns
        -------
        bool
            操作是否成功
        """
        if not _check_pymupdf():
            return False

        if not (1 <= self.quality <= 100):
            logger.error("压缩质量必须在1-100之间")
            return False

        if not _check_input_file(self.input_path):
            return False

        try:
            logger.info(f"开始压缩PDF: {self.input_path} -> {self.output_path}")

            # 打开PDF文档
            doc = fitz.open(self.input_path)

            try:
                # 确保输出目录存在
                self.output_path.parent.mkdir(parents=True, exist_ok=True)

                # 使用PyMuPDF的压缩功能
                doc.save(
                    str(self.output_path),
                    garbage=4,  # 删除未使用的对象
                    deflate=True,  # 压缩流
                    clean=True,  # 清理内容
                )
                logger.info(f"PDF压缩完成: {self.output_path}")
            finally:
                doc.close()
        except FileNotFoundError as e:
            logger.error(f"输入文件不存在: {e}")
            return False
        except ValueError as e:
            logger.error(f"参数错误: {e}")
            return False
        except Exception as e:  # noqa: BLE001
            logger.error(f"PDF压缩失败: {e}")
            return False
        else:
            return True


@dataclass
class PdfToImagesCommand(BaseCommand):
    """将PDF转换为图片命令

    将PDF文件的每一页转换为图片格式
    """

    name = "pdf_to_images"
    description = "将PDF转换为图片"

    input_path: Path = field(default_factory=lambda: Path.cwd())
    output_dir: Path = field(default_factory=lambda: Path.cwd())
    fmt: str = "png"
    dpi: int = 150
    output_files: list[str] = field(default_factory=list)

    def run(self) -> bool:
        """执行PDF转图片操作

        Returns
        -------
        bool
            操作是否成功
        """
        if not _check_pymupdf():
            return False

        if not _check_input_file(self.input_path):
            return False

        try:
            logger.info(f"开始转换PDF为图片: {self.input_path} -> {self.output_dir}")

            # 确保输出目录存在
            self.output_dir.mkdir(parents=True, exist_ok=True)

            # 打开PDF文档
            doc = fitz.open(str(self.input_path))
            self.output_files = []

            try:
                # 计算缩放比例 (DPI / 72是PDF的默认分辨率)
                zoom = self.dpi / 72.0
                mat = fitz.Matrix(zoom, zoom)

                # 遍历每一页
                for page_num in range(len(doc)):
                    page = doc[page_num]

                    # 渲染页面为图片
                    pix = page.get_pixmap(matrix=mat)

                    # 保存图片
                    output_path = self.output_dir / f"page_{page_num + 1}.{self.fmt}"
                    pix.save(str(output_path))
                    self.output_files.append(str(output_path))

                logger.info(f"PDF转图片完成, 生成 {len(self.output_files)} 个文件")
            finally:
                doc.close()
        except FileNotFoundError as e:
            logger.error(f"输入文件不存在: {e}")
            return False
        except ValueError as e:
            logger.error(f"参数错误: {e}")
            return False
        except Exception as e:  # noqa: BLE001
            logger.error(f"PDF转图片失败: {e}")
            return False
        else:
            return len(self.output_files) > 0


@dataclass
class ImagesToPdfCommand(BaseCommand):
    """将图片列表转换为PDF命令

    将多张图片合并成一个PDF文件
    """

    name = "images_to_pdf"
    description = "将图片列表转换为PDF"

    image_paths: list[Path] = field(default_factory=list)
    output_path: Path = field(default_factory=lambda: Path.cwd())
    page_size: str = "auto"

    def run(self) -> bool:
        """执行图片转PDF操作

        Returns
        -------
        bool
            操作是否成功
        """
        if not _check_pymupdf():
            return False

        if not self.image_paths:
            logger.error("图片列表为空")
            return False

        # 检查所有图片文件
        for image_path in self.image_paths:
            if not _check_input_file(image_path, "图片文件"):
                return False

        try:
            logger.info(
                f"开始将 {len(self.image_paths)} 张图片转换为PDF: {self.output_path}"
            )

            # 创建新PDF文档
            pdf_doc = fitz.open()

            try:
                # 遍历所有图片
                for image_path in self.image_paths:
                    # 打开图片
                    img_doc = fitz.open(str(image_path))

                    # 将图片转换为PDF页面
                    pdf_bytes = img_doc.convert_to_pdf()
                    img_pdf = fitz.open("pdf", pdf_bytes)

                    # 插入到主文档
                    pdf_doc.insert_pdf(img_pdf)

                    img_doc.close()
                    img_pdf.close()

                # 确保输出目录存在
                self.output_path.parent.mkdir(parents=True, exist_ok=True)

                # 保存PDF
                pdf_doc.save(str(self.output_path))
                logger.info(f"图片转PDF完成: {self.output_path}")
            finally:
                pdf_doc.close()
        except FileNotFoundError as e:
            logger.error(f"输入文件不存在: {e}")
            return False
        except ValueError as e:
            logger.error(f"参数错误: {e}")
            return False
        except Exception as e:  # noqa: BLE001
            logger.error(f"图片转PDF失败: {e}")
            return False
        else:
            return True
