"""环境变量操作模块, 提供用户友好的环境变量配置接口.

注意: 本模块保留仅为向后兼容, 推荐使用 bitool.core.env 中的 EnvironmentManager.
"""

from __future__ import annotations

import os
from pathlib import Path

from ..consts import Constants
from ..core import logger
from ..core.env import EnvironmentManager, EnvironVar
from ..utils.executor import execute
from ._base import BaseCommand

# 使用 core.env 中的统一管理器
_env_manager = EnvironmentManager()


__all__ = [
    "ExportEnvCommand",
    "GetEnvCommand",
    "ImportEnvCommand",
    "ListEnvCommand",
    "SetEnvCommand",
    "UnsetEnvCommand",
]


class GetEnvCommand(BaseCommand):
    """获取环境变量命令（向后兼容，推荐使用 core.env.getenv）"""

    name = "getenv"
    description = "获取环境变量值"

    def __init__(self, name: str, default: str | None = None) -> None:
        super().__init__()
        self.name_val: str = name
        self.default: str | None = default
        self.value: str | None = None

    def run(self) -> bool:
        """获取环境变量值"""
        self.value = _env_manager.get(self.name_val, self.default)
        if self.value is not None:
            logger.info(f"环境变量 {self.name_val}={self.value}")
        else:
            logger.warning(f"环境变量 {self.name_val} 未设置")
        return self.value is not None


class UnsetEnvCommand(BaseCommand):
    """删除环境变量命令（向后兼容，推荐使用 core.env._manager.unset）"""

    name = "unsetenv"
    description = "删除环境变量"

    def __init__(self, name: str) -> None:
        super().__init__()
        self.name = name

    def run(self) -> bool:
        """删除环境变量"""
        return _env_manager.unset(self.name)


class ListEnvCommand(BaseCommand):
    """列出环境变量命令"""

    name = "listenv"
    description = "列出环境变量"

    def __init__(self, pattern: str | None = None) -> None:
        super().__init__()
        self.pattern: str | None = pattern
        self.envs: dict[str, str] = {}

    def run(self) -> bool:
        """列出环境变量"""
        self.envs = dict(os.environ)
        if self.pattern:
            self.envs = {
                k: v for k, v in self.envs.items() if self.pattern.lower() in k.lower()
            }

        if self.envs:
            logger.info(f"找到 {len(self.envs)} 个环境变量")
            for key, value in self.envs.items():
                logger.info(f"  {key}={value}")
        else:
            logger.warning("未找到匹配的环境变量")
        return len(self.envs) > 0


class ExportEnvCommand(BaseCommand):
    """导出环境变量命令"""

    name = "exportenv"
    description = "导出环境变量到文件"

    def __init__(self, filepath: str, shell_type: str = "bash") -> None:
        super().__init__()
        self.filepath: str = filepath
        self.shell_type: str = shell_type

    def run(self) -> bool:
        """导出环境变量到文件"""
        from bitool.cmd.io import write_file_content

        # 生成环境变量脚本内容
        filepath_path = Path(self.filepath)
        lines: list[str] = []
        if self.shell_type == "cmd":
            lines.append("@echo off")
            lines.append(":: 环境变量配置脚本")
            for key, value in os.environ.items():
                lines.append(f"set {key}={value}")
        elif self.shell_type == "powershell":
            lines.append("# 环境变量配置脚本 (PowerShell)")
            for key, value in os.environ.items():
                lines.append(f'$env:{key}="{value}"')
        else:  # bash/sh 脚本
            lines.append("#!/bin/bash")
            lines.append("# 环境变量配置脚本")
            for key, value in os.environ.items():
                lines.append(f'export {key}="{value}"')

        content = "\n".join(lines) + "\n"

        # 使用公共函数写入文件
        return write_file_content(
            filepath=filepath_path, content=content, overwrite=True, backup=False
        )


class ImportEnvCommand(BaseCommand):
    """导入环境变量命令"""

    name = "importenv"
    description = "从文件导入环境变量"

    def __init__(self, filepath: str) -> None:
        super().__init__()
        self.filepath: str = filepath
        self.count: int = 0

    def run(self) -> bool:
        """从文件导入环境变量"""
        filepath_path = Path(self.filepath)
        if not filepath_path.exists():
            logger.error(f"文件不存在: {self.filepath}")
            return False

        try:
            count = 0
            with filepath_path.open("r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    # 跳过注释和空行
                    if not line or line.startswith("#") or line.startswith("@"):
                        continue

                    # 解析 export VAR=value (bash)
                    if line.startswith("export "):
                        line = line[7:]  # 移除 "export "
                        if "=" in line:
                            key, value = line.split("=", 1)
                            # 移除引号
                            value = value.strip("'\"")
                            os.environ[key] = value
                            count += 1

                    # 解析 set VAR=value (cmd)
                    elif line.startswith("set "):
                        line = line[4:]  # 移除 "set "
                        if "=" in line:
                            key, value = line.split("=", 1)
                            os.environ[key] = value
                            count += 1

                    # 解析 $env:VAR="value" (powershell)
                    elif line.startswith("$env:"):
                        line = line[5:]  # 移除 "$env:"
                        if "=" in line:
                            key, value = line.split("=", 1)
                            # 移除引号
                            value = value.strip("'\"")
                            os.environ[key] = value
                            count += 1

            self.count = count
            logger.info(f"从文件导入了 {count} 个环境变量: {self.filepath}")
        except Exception as e:  # noqa: BLE001
            logger.error(f"导入环境变量失败: {e}")
            return False
        else:
            return count > 0


class SetEnvCommand(BaseCommand):
    """设置环境变量命令（向后兼容，推荐使用 core.env._manager.set）"""

    name = "setenv"
    description = "设置环境变量"

    def __init__(self, envs: list[tuple[str, str]]) -> None:
        super().__init__()

        self.envs: list[EnvironVar] = [
            EnvironVar(name=name, value=value) for name, value in envs
        ]

    def run(self) -> bool:
        """设置环境变量"""
        if not self.envs:
            logger.warning("未提供环境变量对")
            return False

        if Constants.IS_WINDOWS:
            for env_var in self.envs:
                execute(["setx", env_var.name, env_var.value])
        else:
            bashrc_path = os.path.expanduser("~/.bashrc")
            # 读取现有的 bashrc 内容
            existing_lines = []
            if os.path.exists(bashrc_path):
                with open(bashrc_path, encoding="utf-8") as f:
                    existing_lines = f.readlines()

            # 追踪需要更新的环境变量
            env_names = {env_var.name for env_var in self.envs}

            # 过滤掉已存在的环境变量行，并构建新的内容
            new_lines = []
            for line in existing_lines:
                # 检查是否是 export 语句且匹配我们要设置的环境变量
                if line.strip().startswith("export "):
                    # 提取变量名
                    export_part = line.strip()[7:]  # 去掉 "export "
                    if "=" in export_part:
                        var_name = export_part.split("=", 1)[0]
                        if var_name not in env_names:
                            new_lines.append(line)
                    else:
                        new_lines.append(line)
                else:
                    new_lines.append(line)

            # 添加新的环境变量配置
            new_lines.extend(
                f"export {env_var.name}={env_var.value}\n" for env_var in self.envs
            )

            # 写回 bashrc 文件
            with open(bashrc_path, "w", encoding="utf-8") as f:
                f.writelines(new_lines)

        return True


# 注意: EnvOps 类已移除，请使用 core.env.EnvironmentManager 替代
