"""TOML文件操作命令模块.

提供TOML文件的读取、写入等功能.
注意: 版本号管理已整合到 version.py 中的 BumpFileVersionCommand.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import tomli
    import tomli_w
except ImportError:
    try:
        import tomli_w
        import tomllib as tomli  # ty: ignore[unresolved-import]
    except ImportError:
        tomli = None  # ty: ignore
        tomli_w = None  # ty: ignore

from bitool.cmd._base import BaseCommand
from bitool.core import logger

__all__ = ["ReadTomlCommand", "WriteTomlCommand"]


@dataclass
class ReadTomlCommand(BaseCommand):
    """读取TOML文件命令.

    Attributes:
        filepath: TOML文件路径
        data: 解析后的TOML数据
    """

    name: str = "read-toml"
    description: str = "读取TOML文件"
    filepath: Path = Path()
    data: dict[str, Any] = field(default_factory=dict)

    def run(self) -> bool:
        """执行TOML文件读取.

        Returns
        -------
        bool
            读取成功返回True, 否则返回False
        """
        if not self.filepath.exists():
            logger.warning(f"TOML文件不存在: {self.filepath}")
            return False

        try:
            with self.filepath.open("rb") as f:
                if tomli is not None:
                    self.data = tomli.load(f)
                else:
                    logger.error("未安装tomli或tomllib库")
                    return False
        except Exception as e:  # noqa: BLE001
            logger.error(f"读取TOML文件失败: {e}")
            return False
        else:
            logger.info(f"成功读取TOML文件: {self.filepath}")
            return True


@dataclass
class WriteTomlCommand(BaseCommand):
    """写入TOML文件命令.

    Attributes:
        filepath: TOML文件路径
        data: 要写入的TOML数据
        overwrite: 是否覆盖已存在的文件
        backup: 写入前是否备份原文件
    """

    name: str = "write-toml"
    description: str = "写入TOML文件"
    filepath: Path = Path()
    data: dict[str, Any] = field(default_factory=dict)
    overwrite: bool = True
    backup: bool = False

    def run(self) -> bool:
        """执行TOML文件写入.

        Returns
        -------
        bool
            写入成功返回True, 否则返回False
        """
        if tomli_w is None:
            logger.error("未安装tomli_w库")
            return False

        # 先将TOML数据转为字符串
        import io

        buffer = io.BytesIO()
        try:
            tomli_w.dump(self.data, buffer)
            buffer.getvalue().decode("utf-8")
        except Exception as e:  # noqa: BLE001
            logger.error(f"序列化TOML数据失败: {e}")
            return False

        # 使用公共函数写入文件(需要以二进制模式写入)
        if self.filepath.exists() and not self.overwrite:
            logger.warning(f"TOML文件已存在且不允许覆盖: {self.filepath}")
            return False

        try:
            # 备份原文件
            if self.backup and self.filepath.exists():
                from bitool.cmd.io import backup_file

                if backup_file(self.filepath) is None:
                    return False

            # 确保父目录存在
            from bitool.cmd.io import ensure_dir_exists

            if not ensure_dir_exists(self.filepath):
                return False

            # 写入TOML文件
            with self.filepath.open("wb") as f:
                tomli_w.dump(self.data, f)
        except Exception as e:  # noqa: BLE001
            logger.error(f"写入TOML文件失败: {e}")
            return False
        else:
            logger.info(f"成功写入TOML文件: {self.filepath}")
            return True


# 注意: UpdateTomlVersionCommand 和 ReadTomlVersionCommand 已移除
# 请使用 version.py 中的 BumpFileVersionCommand 替代
