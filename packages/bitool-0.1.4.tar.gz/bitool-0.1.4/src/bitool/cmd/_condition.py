from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from shutil import which
from typing import Callable

from bitool.consts import Constants

__all__ = ["Condition"]


@dataclass
class Condition:
    """命令条件类"""

    func: Callable[[], bool]
    reason: str = "未知原因"

    @classmethod
    def from_data(cls, data: tuple[Callable[[], bool], str] | Condition) -> Condition:
        """从 tuple 或 Condition 对象创建 Condition 实例."""
        if isinstance(data, Condition):
            return data
        return cls(func=data[0], reason=data[1])


class BuiltinConditions:
    """内置条件类

    提供常用的条件检查,包括系统、文件、目录、命令等.
    """

    # 系统条件
    IS_WINDOWS = Condition(lambda: Constants.IS_WINDOWS, "当前系统是 Windows")
    IS_UNIX = Condition(lambda: Constants.IS_UNIX, "当前系统是 Unix")

    @staticmethod
    def HAS_APP_INSTALLED(app: str) -> Condition:
        """检查系统中是否已安装指定应用.

        Args:
            app: 应用程序名称.

        Returns:
            Condition实例.
        """
        return Condition(lambda: which(app) is not None, f"{app} 已安装")

    @staticmethod
    def HAS_ENTRY_IN_DIR(entry: str, directory: Path) -> Condition:
        """检查系统路径中是否包含指定条目.

        Args:
            entry: 条目名称.
            directory: 目录路径.

        Returns:
            Condition实例.
        """
        return Condition(
            lambda: entry.lower() in [f.name.lower() for f in directory.iterdir()],
            f"{entry} 在 {directory} 中",
        )

    @staticmethod
    def FILE_EXISTS(filepath: Path) -> Condition:
        """检查文件是否存在.

        Args:
            filepath: 文件路径.

        Returns:
            Condition实例.
        """
        return Condition(
            lambda: filepath.exists() and filepath.is_file(), f"文件 {filepath} 存在"
        )

    @staticmethod
    def DIR_EXISTS(dirpath: Path) -> Condition:
        """检查目录是否存在.

        Args:
            dirpath: 目录路径.

        Returns:
            Condition实例.
        """
        return Condition(
            lambda: dirpath.exists() and dirpath.is_dir(), f"目录 {dirpath} 存在"
        )

    @staticmethod
    def IS_GIT_REPO() -> Condition:
        """检查当前目录是否为Git仓库.

        Returns:
            Condition实例.
        """
        from shutil import which as _which

        from bitool.utils.executor import execute

        def _check_git_repo() -> bool:
            """检查是否为Git仓库."""
            if _which("git") is None:
                return False
            try:
                execute(
                    ["git", "rev-parse", "--git-dir"], check=True, capture_output=True
                )
            except (FileNotFoundError, OSError, RuntimeError):
                return False
            else:
                return True

        return Condition(_check_git_repo, "当前目录是 Git 仓库")
