"""任务模型模块.

本模块提供任务数据结构,用于定义单个可执行任务.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from functools import cached_property
from typing import Any, Callable

from .executor import RunResult


@dataclass
class Task:
    """单个任务项.

    Attributes
    ----------
    name : str
        任务唯一标识,用于依赖引用
    cmd : list[str], optional
        命令及其参数列表
    func : Callable[[], RunResult], optional
        可执行的函数
    condition : Callable[[], bool], optional
        执行条件函数,返回True才执行
    description : str
        任务描述信息
    parallel : bool
        是否允许并行执行,默认 False (顺序执行)
    depends_on : list[str]
        依赖的任务名称列表,用于DAG调度
    """

    cmd: list[str] | None = None
    func: Callable[[], RunResult] | None = None
    condition: Callable[[], bool] | None = None
    description: str = ""
    parallel: bool = False
    name: str = ""
    depends_on: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        """验证任务项配置."""
        if self.cmd is None and self.func is None:
            msg = "Task 必须提供 cmd 或 func 参数"
            raise ValueError(msg)

        # 如果声明了依赖,必须有名称
        if self.depends_on and not self.name:
            msg = "Task 如果声明了 depends_on,必须提供 name 参数"
            raise ValueError(msg)

    @cached_property
    def is_executable(self) -> bool:
        """检查是否应该执行此任务."""
        if self.condition is None:
            return True

        return self.condition()

    @cached_property
    def executable_cmd(self) -> list[str] | Callable[[], RunResult] | None:
        """转换为可执行对象."""
        if self.cmd is not None:
            return self.cmd

        return self.func

    @classmethod
    def from_dict(cls, config: dict[str, Any]) -> Task:
        """从字典配置创建任务.

        Parameters
        ----------
        config : dict[str, Any]
            任务配置字典

        Returns
        -------
        Task
            任务实例
        """
        return cls(
            name=config.get("name", ""),
            cmd=config.get("cmd"),
            func=config.get("func"),
            condition=config.get("condition"),
            description=config.get("description", ""),
            parallel=config.get("parallel", False),
            depends_on=config.get("depends_on", []),
        )
