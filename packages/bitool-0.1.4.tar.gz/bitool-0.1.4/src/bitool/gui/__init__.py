"""初始化 bitool GUI 模块."""

from ._env import setup_pyside2_env
from ._highdpi import setup_highdpi_scaling
from ._themes import (
    apply_theme,
    get_theme_count,
    get_theme_files,
    has_theme,
    list_themes,
)
from ._uiloader import clear_ui_cache, load_ui, setup_ui
from .widgets import ThemeSelectorDialog, open_theme_selector

__all__ = [
    # theme-selector
    "ThemeSelectorDialog",
    # themes
    "apply_theme",
    # uiloader
    "clear_ui_cache",
    "get_theme_count",
    "get_theme_files",
    "has_theme",
    "list_themes",
    "load_ui",
    "open_theme_selector",
    # highdpi
    "setup_highdpi_scaling",
    # env
    "setup_pyside2_env",
    "setup_ui",
]
