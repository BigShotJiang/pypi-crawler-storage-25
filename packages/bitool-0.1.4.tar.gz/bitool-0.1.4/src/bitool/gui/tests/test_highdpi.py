"""Tests for high DPI support module."""

from unittest.mock import MagicMock, patch

import pytest

from bitool.gui._highdpi import (
    HIGH_DPI_THRESHOLD,
    STANDARD_DPI,
    _HighDPIManager,
    get_scaled_font,
    get_scaling_factors,
    scale_value,
)


class TestConstants:
    """Test module constants."""

    def test_standard_dpi(self) -> None:
        """Test STANDARD_DPI constant."""
        assert pytest.approx(96.0) == STANDARD_DPI

    def test_high_dpi_threshold(self) -> None:
        """Test HIGH_DPI_THRESHOLD constant."""
        assert pytest.approx(1.25) == HIGH_DPI_THRESHOLD


class Test_HighDPIManager:
    """Test __HighDPIManager class."""

    def test_manager_initialization(self) -> None:
        """Test manager class attributes initialization."""
        # Reset the singleton for testing
        _HighDPIManager._initialized = False

        assert _HighDPIManager._initialized is False
        assert pytest.approx(1.0) == _HighDPIManager._scale_factor
        assert _HighDPIManager._is_high_dpi is False

    def test_setup_highdpi_already_initialized(self) -> None:
        """Test that setup_highdpi skips if already initialized."""
        # Set as already initialized
        _HighDPIManager._initialized = True

        # Should return immediately without doing anything
        _HighDPIManager.setup_highdpi()
        assert _HighDPIManager._initialized is True

    def test_get_scale_factor_auto_initializes(self) -> None:
        """Test that get_scale_factor auto-initializes."""
        # Reset initialization
        _HighDPIManager._initialized = False

        factor = _HighDPIManager.get_scale_factor()
        assert isinstance(factor, float)
        assert factor >= 1.0
        assert _HighDPIManager._initialized is True

    def test_is_high_dpi_auto_initializes(self) -> None:
        """Test that is_high_dpi auto-initializes."""
        # Reset initialization
        _HighDPIManager._initialized = False

        result = _HighDPIManager.is_high_dpi()
        assert isinstance(result, bool)
        assert _HighDPIManager._initialized is True


class TestModuleFunctions:
    """Test module-level convenience functions."""

    def test_get_scaling_factors(self) -> None:
        """Test get_scaling_factors function."""
        factors = get_scaling_factors()
        assert isinstance(factors, dict)
        assert "scale_factor" in factors
        assert "is_high_dpi" in factors
        assert isinstance(factors["scale_factor"], float)
        assert isinstance(factors["is_high_dpi"], bool)

    def test_scale_value_normal(self) -> None:
        """Test normal value scaling."""
        # Set a known scale factor
        _HighDPIManager._scale_factor = 2.0
        _HighDPIManager._initialized = True

        result = scale_value(10.0)
        assert pytest.approx(20.0) == result

    def test_scale_value_with_min(self) -> None:
        """Test scaling with minimum value constraint."""
        _HighDPIManager._scale_factor = 0.5  # Small scale factor
        _HighDPIManager._initialized = True

        # Value smaller than min_value should return min_value
        result = scale_value(0.5, min_value=1.0)
        assert result >= 1.0

    def test_scale_value_default_min(self) -> None:
        """Test scaling with default minimum value."""
        _HighDPIManager._scale_factor = 0.1  # Very small scale factor
        _HighDPIManager._initialized = True

        # Should use default min_value of 1.0
        result = scale_value(0.5)
        assert result >= 1.0


class TestScalingValues:
    """Test value scaling calculations."""

    def test_scale_value_identity_at_1x(self) -> None:
        """Test that values scale correctly at 1.0x factor."""
        _HighDPIManager._scale_factor = 1.0
        _HighDPIManager._initialized = True

        result = scale_value(100.0)
        assert pytest.approx(100.0) == result

    def test_scale_value_at_high_dpi(self) -> None:
        """Test scaling at high DPI (above threshold)."""
        _HighDPIManager._scale_factor = 2.0
        _HighDPIManager._is_high_dpi = True
        _HighDPIManager._initialized = True

        result = scale_value(50.0)
        assert pytest.approx(100.0) == result


class Test_HighDPIManagerWithQApp:
    """Test __HighDPIManager with QApplication instance."""

    def test_setup_highdpi_with_qapplication_instance(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test setup_highdpi when QApplication instance exists."""
        # Reset initialization
        _HighDPIManager._initialized = False
        _HighDPIManager._scale_factor = 1.0
        _HighDPIManager._is_high_dpi = False

        # Mock the actual PySide2 modules that are already imported
        import PySide2.QtWidgets

        # Create mock screen with high DPI
        mock_screen = MagicMock()
        mock_screen.logicalDotsPerInch.return_value = 144.0  # High DPI

        # Create mock QApplication
        mock_qapp = MagicMock()
        mock_qapp.primaryScreen.return_value = mock_screen

        # Store original method
        original_instance = PySide2.QtWidgets.QApplication.instance

        try:
            # Mock QApplication.instance to return our mock
            PySide2.QtWidgets.QApplication.instance = MagicMock(return_value=mock_qapp)  # type: ignore[assignment]

            # Call setup
            _HighDPIManager.setup_highdpi()

            # Verify it detected high DPI (144/96 = 1.5)
            assert _HighDPIManager._scale_factor > 1.0
            assert _HighDPIManager._initialized is True
        finally:
            # Restore original method
            PySide2.QtWidgets.QApplication.instance = original_instance

    def test_setup_highdpi_screen_none(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test setup_highdpi when screen is None."""
        _HighDPIManager._initialized = False
        _HighDPIManager._scale_factor = 1.0

        import PySide2.QtWidgets

        mock_qapp = MagicMock()
        mock_qapp.primaryScreen.return_value = None

        original_instance = PySide2.QtWidgets.QApplication.instance
        try:
            PySide2.QtWidgets.QApplication.instance = MagicMock(return_value=mock_qapp)  # type: ignore[assignment]
            _HighDPIManager.setup_highdpi()

            # Should use default values
            assert _HighDPIManager._scale_factor == pytest.approx(1.0)
            assert _HighDPIManager._initialized is True
        finally:
            PySide2.QtWidgets.QApplication.instance = original_instance

    def test_setup_highdpi_no_logical_dpi_method(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test setup_highdpi when screen doesn't have logicalDotsPerInch."""
        _HighDPIManager._initialized = False
        _HighDPIManager._scale_factor = 1.0

        import PySide2.QtWidgets

        mock_screen = MagicMock(spec=[])  # No methods
        mock_qapp = MagicMock()
        mock_qapp.primaryScreen.return_value = mock_screen

        original_instance = PySide2.QtWidgets.QApplication.instance
        try:
            PySide2.QtWidgets.QApplication.instance = MagicMock(return_value=mock_qapp)  # type: ignore[assignment]
            _HighDPIManager.setup_highdpi()

            # Should use default values
            assert _HighDPIManager._scale_factor == pytest.approx(1.0)
            assert _HighDPIManager._initialized is True
        finally:
            PySide2.QtWidgets.QApplication.instance = original_instance

    def test_setup_highdpi_exception_handling(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test setup_highdpi handles exceptions gracefully."""
        _HighDPIManager._initialized = False

        import PySide2.QtWidgets

        original_instance = PySide2.QtWidgets.QApplication.instance
        try:
            PySide2.QtWidgets.QApplication.instance = MagicMock(
                side_effect=RuntimeError("Mock error")
            )  # type: ignore[assignment]
            # Should not raise an exception
            _HighDPIManager.setup_highdpi()
            assert _HighDPIManager._initialized is True
        finally:
            PySide2.QtWidgets.QApplication.instance = original_instance


class TestGetScaledFont:
    """Test get_scaled_font function."""

    def test_get_scaled_font_returns_qfont(self) -> None:
        """Test that get_scaled_font returns a QFont instance."""
        # Just verify it returns a QFont when Qt is available
        result = get_scaled_font(16)
        from PySide2.QtGui import QFont

        assert isinstance(result, QFont)
        assert result.pixelSize() == 16

    def test_get_scaled_font_default_size(self) -> None:
        """Test get_scaled_font with default size."""
        # Set scale factor to 1.0 for predictable default size
        _HighDPIManager._scale_factor = 1.0
        _HighDPIManager._initialized = True

        result = get_scaled_font()
        from PySide2.QtGui import QFont

        assert isinstance(result, QFont)
        # Default size should be around 14 (scaled)
        assert result.pixelSize() >= 14

    def test_get_scaled_font_default_size_uses_scaling(self) -> None:
        """Test that default font size uses scaling."""
        # Set a known scale factor
        _HighDPIManager._scale_factor = 2.0
        _HighDPIManager._initialized = True

        # When size is None, it should use scale_value(14, 9)
        # With scale_factor=2.0: max(9, 14*2.0) = 28
        result = get_scaled_font(None)
        from PySide2.QtGui import QFont

        assert isinstance(result, QFont)
        # Default size should be scaled: max(9, 14*2.0) = 28
        assert result.pixelSize() == 28


class TestQtNotAvailable:
    """Test behavior when Qt is not available."""

    def test_qt_import_failure(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test module behavior when PySide2 cannot be imported."""
        # Temporarily modify sys.modules to simulate missing PySide2
        with patch.dict("sys.modules", {"PySide2": None}):
            # The module should handle this gracefully during import
            # We just verify the constants are still accessible
            assert pytest.approx(96.0) == STANDARD_DPI
            assert pytest.approx(1.25) == HIGH_DPI_THRESHOLD


class TestSetupHighDpiScaling:
    """Test setup_highdpi_scaling export function."""

    def test_setup_highdpi_scaling_callable(self) -> None:
        """Test that setup_highdpi_scaling is callable."""
        from bitool.gui._highdpi import setup_highdpi_scaling

        assert callable(setup_highdpi_scaling)

    def test_setup_highdpi_scaling_idempotent(self) -> None:
        """Test that setup_highdpi_scaling can be called multiple times."""
        from bitool.gui._highdpi import setup_highdpi_scaling

        # Reset initialization
        _HighDPIManager._initialized = False

        # First call
        setup_highdpi_scaling()
        assert _HighDPIManager._initialized is True

        # Second call (should skip)
        setup_highdpi_scaling()
        assert _HighDPIManager._initialized is True


class TestGetScaledFontQtUnavailable:
    """Test get_scaled_font when Qt is not available."""

    def test_get_scaled_font_qt_unavailable(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test get_scaled_font returns None when Qt is unavailable."""
        import bitool.gui._highdpi as highdpi_module

        # Temporarily set QT_AVAILABLE to False
        original_qt_available = highdpi_module.QT_AVAILABLE
        try:
            highdpi_module.QT_AVAILABLE = False
            result = highdpi_module.get_scaled_font(16)
            assert result is None
        finally:
            highdpi_module.QT_AVAILABLE = original_qt_available


class TestHighDpiEdgeCases:
    """Test edge cases for HighDPI functionality."""

    def test_scale_value_zero(self) -> None:
        """Test scaling zero value."""
        _HighDPIManager._scale_factor = 2.0
        _HighDPIManager._initialized = True

        result = scale_value(0.0)
        # Should return min_value (1.0) since 0 * 2.0 = 0 < 1.0
        assert result == pytest.approx(1.0)

    def test_scale_value_negative(self) -> None:
        """Test scaling negative value."""
        _HighDPIManager._scale_factor = 2.0
        _HighDPIManager._initialized = True

        result = scale_value(-10.0)
        # Should return min_value (1.0) since -10 * 2.0 = -20 < 1.0
        assert result == pytest.approx(1.0)

    def test_scale_value_custom_min(self) -> None:
        """Test scaling with custom minimum value."""
        _HighDPIManager._scale_factor = 1.5
        _HighDPIManager._initialized = True

        result = scale_value(10.0, min_value=20.0)
        # 10 * 1.5 = 15, but min_value is 20
        assert result == pytest.approx(20.0)

    def test_get_scaled_font_type_error(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test get_scaled_font handles TypeError gracefully."""
        # Mock QFont.setPixelSize to raise TypeError
        from PySide2.QtGui import QFont

        import bitool.gui._highdpi as highdpi_module

        original_set_pixel_size = QFont.setPixelSize

        def mock_set_pixel_size(self: QFont, size: int) -> None:
            msg = "Mock error"
            raise TypeError(msg)

        try:
            QFont.setPixelSize = mock_set_pixel_size  # type: ignore[assignment]
            result = highdpi_module.get_scaled_font(16)
            assert result is None
        finally:
            QFont.setPixelSize = original_set_pixel_size

    def test_get_scaled_font_value_error(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test get_scaled_font handles ValueError gracefully."""
        from PySide2.QtGui import QFont

        import bitool.gui._highdpi as highdpi_module

        # Mock QFont.setPixelSize to raise ValueError
        original_set_pixel_size = QFont.setPixelSize

        def mock_set_pixel_size(self: QFont, size: int) -> None:
            msg = "Mock error"
            raise ValueError(msg)

        try:
            QFont.setPixelSize = mock_set_pixel_size  # type: ignore[assignment]
            result = highdpi_module.get_scaled_font(16)
            assert result is None
        finally:
            QFont.setPixelSize = original_set_pixel_size

    def test_setup_highdpi_no_qapplication_sets_attributes(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test that setup_highdpi sets Qt attributes even without QApplication."""
        _HighDPIManager._initialized = False

        import PySide2.QtWidgets
        from PySide2.QtCore import Qt

        original_instance = PySide2.QtWidgets.QApplication.instance
        original_set_attribute = PySide2.QtWidgets.QApplication.setAttribute

        try:
            # Mock QApplication.instance to return None
            PySide2.QtWidgets.QApplication.instance = MagicMock(return_value=None)  # type: ignore[assignment]

            # Track setAttribute calls
            set_attribute_calls = []

            def mock_set_attribute(attr: int, value: bool) -> None:
                set_attribute_calls.append((attr, value))

            PySide2.QtWidgets.QApplication.setAttribute = mock_set_attribute  # type: ignore[assignment]

            _HighDPIManager.setup_highdpi()

            # Verify Qt attributes were set
            assert len(set_attribute_calls) >= 2
            # Check that HighDpiScaling and HighDpiPixmaps were enabled
            assert (Qt.AA_EnableHighDpiScaling, True) in set_attribute_calls
            assert (Qt.AA_UseHighDpiPixmaps, True) in set_attribute_calls
        finally:
            PySide2.QtWidgets.QApplication.instance = original_instance
            PySide2.QtWidgets.QApplication.setAttribute = original_set_attribute


class TestGetScalingFactors:
    """Test get_scaling_factors function."""

    def test_get_scaling_factors_returns_dict(self) -> None:
        """Test that get_scaling_factors returns correct dict structure."""
        factors = get_scaling_factors()
        assert isinstance(factors, dict)
        assert set(factors.keys()) == {"scale_factor", "is_high_dpi"}
        assert isinstance(factors["scale_factor"], float)
        assert isinstance(factors["is_high_dpi"], bool)

    def test_get_scaling_factors_reflects_current_state(self) -> None:
        """Test that get_scaling_factors reflects current manager state."""
        _HighDPIManager._scale_factor = 1.5
        _HighDPIManager._is_high_dpi = True
        _HighDPIManager._initialized = True

        factors = get_scaling_factors()
        assert factors["scale_factor"] == pytest.approx(1.5)
        assert factors["is_high_dpi"] is True, "is_high_dpi should be True"
