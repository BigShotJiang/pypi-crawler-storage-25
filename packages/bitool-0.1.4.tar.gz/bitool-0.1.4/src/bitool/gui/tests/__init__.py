"""Test module for bitool.gui package."""
