"""Tests for the simplified QSS theme system."""

import threading
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

# Import using absolute path
from bitool.gui._themes import ThemeManager


@pytest.fixture
def themes_dir() -> Path:
    """Get themes directory."""
    return Path(__file__).parent.parent / "stylesheets"


class TestThemeManager:
    """测试 ThemeManager."""

    @pytest.fixture
    def manager(self) -> ThemeManager:
        """Create a theme manager instance."""
        return ThemeManager()

    def test_singleton_instance(self) -> None:
        """测试 ThemeManager 是模块级单例."""
        from bitool.gui._themes import _theme_manager

        mgr1 = _theme_manager
        mgr2 = _theme_manager
        assert mgr1 is mgr2

    def test_get_instance_thread_safe(self) -> None:
        """测试模块级实例的线程安全性."""
        from bitool.gui._themes import _theme_manager

        instances = []

        def get_instance() -> None:
            instances.append(_theme_manager)

        # 创建多个线程访问同一实例
        threads = [threading.Thread(target=get_instance) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # 所有都应该是同一实例
        assert len({id(inst) for inst in instances}) == 1

    def test_list_themes(self, manager: ThemeManager) -> None:
        """测试列出可用主题."""
        themes = manager.list_themes()
        # 应该至少有一些来自样式表目录的主题
        assert isinstance(themes, list)
        assert len(themes) > 0
        # 检查一些常见的主题名是否存在
        assert "aqua" in themes or len(themes) > 0  # 至少应该存在一个主题

    def test_apply_theme_invalid(self, manager: ThemeManager) -> None:
        """Test applying invalid theme."""
        mock_widget = MagicMock()

        success = manager.apply_theme(mock_widget, "nonexistent_theme")

        # Should fail gracefully
        assert success is False

    def test_apply_theme_none_widget(self, manager: ThemeManager) -> None:
        """Test applying theme with None widget."""
        success = manager.apply_theme(None, "aqua")  # type: ignore[arg-type]
        assert success is False

    def test_apply_theme_empty_name(self, manager: ThemeManager) -> None:
        """Test applying theme with empty name."""
        mock_widget = MagicMock()
        success = manager.apply_theme(mock_widget, "")
        assert success is False

    def test_apply_theme_valid(self, manager: ThemeManager, themes_dir: Path) -> None:
        """Test applying valid theme."""
        mock_widget = MagicMock()
        success = manager.apply_theme(mock_widget, "aqua")

        # Should succeed
        assert success is True
        mock_widget.setStyleSheet.assert_called_once()

    def test_apply_theme_from_subthread(self, manager: ThemeManager) -> None:
        """Test applying theme from subthread (should fail)."""
        mock_widget = MagicMock()
        result = {"success": None}

        def apply_in_thread() -> None:
            result["success"] = manager.apply_theme(mock_widget, "aqua")

        thread = threading.Thread(target=apply_in_thread)
        thread.start()
        thread.join()

        # Should fail because Qt operations must be in main thread
        assert result["success"] is False

    def test_list_themes_returns_sorted_list(self, manager: ThemeManager) -> None:
        """Test that list_themes returns a sorted list."""
        themes = manager.list_themes()
        assert themes == sorted(themes)

    def test_multiple_instances_share_state(self) -> None:
        """测试模块级单例在多次导入时保持一致."""
        from bitool.gui._themes import _theme_manager

        mgr1 = _theme_manager
        mgr2 = _theme_manager

        # 模块级单例应该返回同一实例
        assert mgr1 is mgr2

    def test_has_theme_existing(self, manager: ThemeManager, themes_dir: Path) -> None:
        """Test has_theme with existing theme."""
        assert manager.has_theme("aqua") is True

    def test_has_theme_nonexisting(self, manager: ThemeManager) -> None:
        """Test has_theme with non-existing theme."""
        assert manager.has_theme("nonexistent_theme_xyz") is False

    def test_get_theme_count(self, manager: ThemeManager, themes_dir: Path) -> None:
        """Test get_theme_count returns correct count."""
        # Count actual theme files (excluding base_structure.qss and *_colors.qss)
        qss_files = [
            f
            for f in themes_dir.glob("*.qss")
            if f.name != "base_structure.qss" and not f.name.endswith("_colors.qss")
        ]
        # Add themes from *_colors.qss files
        color_files = list(themes_dir.glob("*_colors.qss"))
        expected_count = len(qss_files) + len(color_files)
        count = manager.get_theme_count()
        assert count == expected_count

    def test_get_theme_files_returns_copy(self, manager: ThemeManager) -> None:
        """Test that get_theme_files returns a copy."""
        files1 = manager.get_theme_files()
        files2 = manager.get_theme_files()

        # Should be different objects
        assert files1 is not files2
        # But contain same data
        assert files1 == files2

    def test_generate_qss_valid_theme(
        self, manager: ThemeManager, themes_dir: Path
    ) -> None:
        """Test _generate_qss with valid theme."""
        qss = manager._generate_qss("aqua")
        assert isinstance(qss, str)
        assert len(qss) > 0
        # Should contain Qt stylesheet syntax
        assert "QWidget" in qss or "QPushButton" in qss or "{" in qss

    def test_generate_qss_invalid_theme(self, manager: ThemeManager) -> None:
        """Test _generate_qss with invalid theme."""
        qss = manager._generate_qss("nonexistent_theme_xyz")
        assert not qss

    def test_load_available_themes_empty_directory(self) -> None:
        """Test _load_available_themes with non-existent directory."""
        # Create a manager without loading themes
        manager = object.__new__(ThemeManager)
        manager._theme_files = {}
        manager._lock = threading.Lock()

        with patch("bitool.gui._themes._STYLESHEETS_DIR") as mock_dir:
            mock_dir.exists.return_value = False
            mock_dir.glob.return_value = []

            # Should not raise, just log warning
            manager._load_available_themes()

            # Should have no themes
            assert manager.get_theme_count() == 0

    def test_thread_safety_list_themes(self, manager: ThemeManager) -> None:
        """Test that list_themes is thread-safe."""
        results = []

        def list_themes() -> None:
            # Reduced iterations
            results.extend(manager.list_themes() for _ in range(5))

        threads = [
            threading.Thread(target=list_themes) for _ in range(2)
        ]  # Reduced threads
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # All results should be lists
        assert all(isinstance(r, list) for r in results)

    def test_thread_safety_has_theme(self, manager: ThemeManager) -> None:
        """Test that has_theme is thread-safe."""
        results = []

        def check_theme() -> None:
            # Reduced iterations
            results.extend(manager.has_theme("aqua") for _ in range(5))

        threads = [
            threading.Thread(target=check_theme) for _ in range(2)
        ]  # Reduced threads
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # All results should be booleans
        assert all(isinstance(r, bool) for r in results)

    def test_generate_qss_file_read_error(
        self, manager: ThemeManager, themes_dir: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test _generate_qss when file reading fails."""
        # Mock the open method to raise an error
        original_open = Path.open

        def mock_open(self: Path, *args: Any, **kwargs: Any) -> Any:
            if self.name == "aqua_colors.qss":
                msg = "Mocked read error"
                raise FileNotFoundError(msg)
            return original_open(self, *args, **kwargs)

        monkeypatch.setattr(Path, "open", mock_open)

        qss = manager._generate_qss("aqua")
        assert not qss

    def test_apply_theme_widget_error(
        self, manager: ThemeManager, themes_dir: Path
    ) -> None:
        """Test apply_theme when widget.setStyleSheet raises error."""
        mock_widget = MagicMock()
        mock_widget.setStyleSheet.side_effect = RuntimeError(
            "Mocked setStyleSheet error"
        )

        success = manager.apply_theme(mock_widget, "aqua")
        assert success is False


class TestThemeConfiguration:
    """Test theme configuration files."""

    def test_stylesheets_directory_exists(self, themes_dir: Path) -> None:
        """Test that stylesheets directory exists."""
        assert themes_dir.exists()
        assert themes_dir.is_dir()

    def test_qss_files_exist(self, themes_dir: Path) -> None:
        """Test that at least some QSS files exist."""
        qss_files = list(themes_dir.glob("*.qss"))
        assert len(qss_files) > 0, "No QSS files found in stylesheets directory"

    def test_aqua_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that aqua_colors.qss exists."""
        assert (themes_dir / "aqua_colors.qss").exists()

    def test_dracula_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that dracula_colors.qss exists."""
        assert (themes_dir / "dracula_colors.qss").exists()

    def test_gruvbox_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that gruvbox_colors.qss exists."""
        assert (themes_dir / "gruvbox_colors.qss").exists()

    def test_monokai_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that monokai_colors.qss exists."""
        assert (themes_dir / "monokai_colors.qss").exists()

    def test_nord_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that nord_colors.qss exists."""
        assert (themes_dir / "nord_colors.qss").exists()

    def test_onedark_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that onedark_colors.qss exists."""
        assert (themes_dir / "onedark_colors.qss").exists()

    def test_tokyo_night_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that tokyo_night_colors.qss exists."""
        assert (themes_dir / "tokyo_night_colors.qss").exists()

    def test_vitesse_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that vitesse_colors.qss exists."""
        assert (themes_dir / "vitesse_colors.qss").exists()

    def test_catppuccin_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that catppuccin_colors.qss exists."""
        assert (themes_dir / "catppuccin_colors.qss").exists()

    def test_material_dark_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that material_dark_colors.qss exists."""
        assert (themes_dir / "material_dark_colors.qss").exists()

    def test_consolestyle_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that consolestyle_colors.qss exists."""
        assert (themes_dir / "consolestyle_colors.qss").exists()

    def test_elegantdark_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that elegantdark_colors.qss exists."""
        assert (themes_dir / "elegantdark_colors.qss").exists()

    def test_elegantpurple_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that elegantpurple_colors.qss exists."""
        assert (themes_dir / "elegantpurple_colors.qss").exists()

    def test_synthwave_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that synthwave_colors.qss exists."""
        assert (themes_dir / "synthwave_colors.qss").exists()

    def test_freshgreen_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that freshgreen_colors.qss exists."""
        assert (themes_dir / "freshgreen_colors.qss").exists()

    def test_warmorange_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that warmorange_colors.qss exists."""
        assert (themes_dir / "warmorange_colors.qss").exists()

    def test_professionalblue_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that professionalblue_colors.qss exists."""
        assert (themes_dir / "professionalblue_colors.qss").exists()

    def test_high_contrast_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that high_contrast_colors.qss exists."""
        assert (themes_dir / "high_contrast_colors.qss").exists()

    def test_macos_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that macos_colors.qss exists."""
        assert (themes_dir / "macos_colors.qss").exists()

    def test_ubuntu_colors_qss_exists(self, themes_dir: Path) -> None:
        """Test that ubuntu_colors.qss exists."""
        assert (themes_dir / "ubuntu_colors.qss").exists()

    def test_qss_file_valid(self, themes_dir: Path) -> None:
        """Test that a QSS file is valid and readable."""
        qss_file = themes_dir / "aqua_colors.qss"

        with qss_file.open("r", encoding="utf-8") as f:
            content = f.read()

        # Should have some content
        assert len(content) > 0
        # Should contain color variable syntax
        assert "BG_PRIMARY:" in content or "FG_PRIMARY:" in content

    def test_qss_file_size_reasonable(self, themes_dir: Path) -> None:
        """Test that QSS files have reasonable size."""
        qss_files = list(themes_dir.glob("*.qss"))

        for qss_file in qss_files:
            size_kb = qss_file.stat().st_size / 1024
            # Each QSS file should be at least 1KB
            assert size_kb >= 1.0, f"{qss_file.name} is too small ({size_kb:.1f}KB)"
            # And not excessively large (less than 1MB)
            assert size_kb < 1024.0, f"{qss_file.name} is too large ({size_kb:.1f}KB)"

    def test_all_qss_files_readable(self, themes_dir: Path) -> None:
        """Test that all QSS files are readable."""
        qss_files = list(themes_dir.glob("*.qss"))

        for qss_file in qss_files:
            with qss_file.open("r", encoding="utf-8") as f:
                content = f.read()
            assert len(content) > 0, f"{qss_file.name} is empty"

    def test_no_duplicate_theme_names(self, themes_dir: Path) -> None:
        """Test that there are no duplicate theme names."""
        qss_files = list(themes_dir.glob("*.qss"))
        theme_names = [f.stem for f in qss_files]

        # Check for duplicates
        assert len(theme_names) == len(set(theme_names)), "Duplicate theme names found"

    def test_theme_manager_loads_all_themes(self, themes_dir: Path) -> None:
        """Test that theme manager loads all available themes."""
        # Create a new manager instance to test loading
        fresh_manager = ThemeManager()

        # Build expected themes: traditional QSS files + color-based themes
        qss_files = [
            f
            for f in themes_dir.glob("*.qss")
            if f.name != "base_structure.qss" and not f.name.endswith("_colors.qss")
        ]
        expected_themes = {f.stem for f in qss_files}

        # Add themes from *_colors.qss files
        color_files = themes_dir.glob("*_colors.qss")
        for cf in color_files:
            theme_name = cf.stem.replace("_colors", "")
            expected_themes.add(theme_name)

        loaded_themes = set(fresh_manager.list_themes())

        assert expected_themes == loaded_themes

    def test_load_available_themes_oserror(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test _load_available_themes when OSError occurs."""
        import pathlib

        # Create a manager without loading themes
        manager = object.__new__(ThemeManager)
        manager._theme_files = {}
        manager._lock = threading.Lock()

        # Mock pathlib.Path.glob to raise OSError
        original_glob = pathlib.Path.glob

        def mock_glob(self: pathlib.Path, pattern: str) -> Any:
            if "stylesheets" in str(self):
                msg = "Mocked directory access error"
                raise OSError(msg)
            return original_glob(self, pattern)

        monkeypatch.setattr(pathlib.Path, "glob", mock_glob)

        # Should raise OSError and log error
        with pytest.raises(OSError, match="Mocked directory access error"):
            manager._load_available_themes()


class TestColorVariableParsing:
    """Test color variable parsing and replacement."""

    @pytest.fixture
    def manager(self) -> ThemeManager:
        """Create a theme manager instance."""
        return ThemeManager()

    def test_parse_color_variables_basic(self, manager: ThemeManager) -> None:
        """Test basic color variable parsing."""
        content = """BG_PRIMARY: #ffffff;
FG_PRIMARY: #000000;
/* This is a comment */
ACCENT_COLOR: #ff0000;
"""
        result = manager._parse_color_variables(content)
        assert result == {
            "BG_PRIMARY": "#ffffff",
            "FG_PRIMARY": "#000000",
            "ACCENT_COLOR": "#ff0000",
        }

    def test_parse_color_variables_skips_comments(self, manager: ThemeManager) -> None:
        """Test that comments are skipped."""
        content = """/* Comment line */
BG_PRIMARY: #ffffff;
// Another comment style
FG_PRIMARY: #000000;
"""
        result = manager._parse_color_variables(content)
        assert "BG_PRIMARY" in result
        assert "FG_PRIMARY" in result

    def test_parse_color_variables_skips_empty_lines(
        self, manager: ThemeManager
    ) -> None:
        """Test that empty lines are skipped."""
        content = """

BG_PRIMARY: #ffffff;

FG_PRIMARY: #000000;

"""
        result = manager._parse_color_variables(content)
        assert len(result) == 2

    def test_parse_color_variables_invalid_format(self, manager: ThemeManager) -> None:
        """Test parsing with invalid format lines."""
        content = """BG_PRIMARY #ffffff;
FG_PRIMARY: #000000
INVALID LINE
VALID_VAR: #123456;
"""
        result = manager._parse_color_variables(content)
        # Only VALID_VAR should be parsed (has colon and semicolon)
        assert "VALID_VAR" in result
        assert "BG_PRIMARY" not in result  # Missing colon
        assert "FG_PRIMARY" not in result  # Missing semicolon

    def test_parse_color_variables_lowercase_rejected(
        self, manager: ThemeManager
    ) -> None:
        """Test that lowercase variable names are rejected."""
        content = "bg_primary: #ffffff;\nBG_PRIMARY: #000000;"
        result = manager._parse_color_variables(content)
        assert "BG_PRIMARY" in result
        assert "bg_primary" not in result

    def test_replace_color_variables(self, manager: ThemeManager) -> None:
        """Test color variable replacement."""
        qss_content = """
QWidget {
    background-color: BG_PRIMARY;
    color: FG_PRIMARY;
}
QPushButton {
    background-color: ACCENT_COLOR;
}
"""
        color_vars = {
            "BG_PRIMARY": "#ffffff",
            "FG_PRIMARY": "#000000",
            "ACCENT_COLOR": "#ff0000",
        }
        result = manager._replace_color_variables(qss_content, color_vars)
        assert "background-color: #ffffff;" in result
        assert "color: #000000;" in result
        assert "background-color: #ff0000;" in result

    def test_replace_color_variables_longer_vars_first(
        self, manager: ThemeManager
    ) -> None:
        """Test that longer variable names are replaced first to avoid partial matches."""
        qss_content = "BG_COLOR_PRIMARY and BG_COLOR"
        color_vars = {"BG_COLOR": "#fff", "BG_COLOR_PRIMARY": "#000"}
        result = manager._replace_color_variables(qss_content, color_vars)
        # Should replace BG_COLOR_PRIMARY first, then BG_COLOR
        assert result == "#000 and #fff"


class TestGenerateQssWithStructure:
    """Test _generate_qss_with_structure method."""

    @pytest.fixture
    def manager(self) -> ThemeManager:
        """Create a theme manager instance."""
        return ThemeManager()

    def test_generate_qss_with_structure_valid(
        self, manager: ThemeManager, themes_dir: Path
    ) -> None:
        """Test generating QSS with structure and color files."""
        # aqua theme uses aqua_colors.qss
        qss = manager._generate_qss_with_structure("aqua")
        assert isinstance(qss, str)
        assert len(qss) > 0
        # Should contain Qt stylesheet syntax
        assert "{" in qss and "}" in qss

    def test_generate_qss_with_structure_missing_color_file(
        self, manager: ThemeManager
    ) -> None:
        """Test when color file doesn't exist."""
        qss = manager._generate_qss_with_structure("nonexistent_theme")
        # Should fall back to _generate_qss which returns empty string
        assert not qss

    def test_generate_qss_with_structure_fallback(
        self, manager: ThemeManager, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test fallback when base_structure.qss doesn't exist."""
        import bitool.gui._themes as themes_module

        original_base = themes_module._BASE_STRUCTURE_FILE

        # Temporarily make base structure file appear non-existent
        class MockPath:
            def __init__(self, original: Path) -> None:
                self.original = original

            def exists(self) -> bool:
                return False

            def __truediv__(self, other: str) -> Path:
                return self.original / other

        with monkeypatch.context() as m:
            m.setattr(themes_module, "_BASE_STRUCTURE_FILE", MockPath(original_base))
            # Should fall back to _generate_qss
            qss = manager._generate_qss_with_structure("nonexistent_theme")
            assert not qss


class TestColorThemeApplication:
    """Test applying color-based themes."""

    @pytest.fixture
    def manager(self) -> ThemeManager:
        """Create a theme manager instance."""
        return ThemeManager()

    def test_apply_color_theme(self, manager: ThemeManager) -> None:
        """Test applying a color-based theme (e.g., aqua)."""
        mock_widget = MagicMock()
        success = manager.apply_theme(mock_widget, "aqua")
        assert success is True
        mock_widget.setStyleSheet.assert_called_once()
        # Verify the stylesheet contains substituted colors
        qss_call = mock_widget.setStyleSheet.call_args[0][0]
        assert isinstance(qss_call, str)
        assert len(qss_call) > 0

    def test_apply_traditional_theme(self, manager: ThemeManager) -> None:
        """Test applying a traditional full QSS theme."""
        # Check if there are any traditional themes (non-color-based)
        manager.list_themes()
        # Find a theme that doesn't use _colors.qss
        traditional_theme = None
        theme_files = manager.get_theme_files()
        for theme_name, file_path in theme_files.items():
            if not file_path.name.endswith("_colors.qss"):
                traditional_theme = theme_name
                break

        if traditional_theme:
            mock_widget = MagicMock()
            success = manager.apply_theme(mock_widget, traditional_theme)
            assert success is True
            mock_widget.setStyleSheet.assert_called_once()


class TestModuleLevelFunctions:
    """Test module-level convenience functions."""

    def test_apply_theme_function(self) -> None:
        """Test module-level apply_theme function."""
        from bitool.gui._themes import apply_theme

        mock_widget = MagicMock()
        success = apply_theme(mock_widget, "aqua")
        assert success is True

    def test_list_themes_function(self) -> None:
        """Test module-level list_themes function."""
        from bitool.gui._themes import list_themes

        themes = list_themes()
        assert isinstance(themes, list)
        assert len(themes) > 0

    def test_has_theme_function(self) -> None:
        """Test module-level has_theme function."""
        from bitool.gui._themes import has_theme

        assert has_theme("aqua") is True
        assert has_theme("nonexistent_xyz") is False

    def test_get_theme_count_function(self) -> None:
        """Test module-level get_theme_count function."""
        from bitool.gui._themes import get_theme_count

        count = get_theme_count()
        assert isinstance(count, int)
        assert count > 0

    def test_get_theme_files_function(self) -> None:
        """Test module-level get_theme_files function."""
        from bitool.gui._themes import get_theme_files

        files = get_theme_files()
        assert isinstance(files, dict)
        assert len(files) > 0
        # All values should be Path objects
        from pathlib import Path

        assert all(isinstance(v, Path) for v in files.values())
