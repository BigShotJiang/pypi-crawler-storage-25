"""Tests for UILoader module."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from bitool.gui._uiloader import (
    UILoader,
    _default_loader,
    clear_ui_cache,
    load_ui,
    setup_ui,
)


class TestUILoader:
    """Tests for UILoader class."""

    @pytest.mark.parametrize(
        ("base_path", "expected"),
        [
            (None, None),
            (Path("/test/path"), Path("/test/path")),
            ("/test/path", Path("/test/path")),
        ],
    )
    def test_init(self, base_path: Path | str | None, expected: Path | None) -> None:
        """Test UILoader initialization."""
        loader = UILoader(base_path=base_path)
        assert loader.base_path == expected
        assert loader._cache == {}

    @pytest.mark.parametrize(
        ("ui_content", "expected_qrc"),
        [
            ('<ui><include location="theme.qrc"/></ui>', ["theme.qrc"]),
            (
                '<ui><include location="icons.qrc"/><include location="styles.qrc"/></ui>',
                ["icons.qrc", "styles.qrc"],
            ),
            ("<ui></ui>", []),
            ('<ui><include location="missing.qrc"/></ui>', ["missing.qrc"]),
        ],
    )
    def test_resolve_resources_qrc_detection(
        self, tmp_path: Path, ui_content: str, expected_qrc: list
    ) -> None:
        """Test qrc reference detection in UI files."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text(ui_content)

        loader = UILoader()
        # Mock logger to avoid actual logging
        with patch("bitool.gui._uiloader.logger.warning"):
            loader._resolve_resources(ui_file)
        # If no exception raised, test passes

    def test_resolve_resources_with_rc_module(self, tmp_path: Path) -> None:
        """Test resource resolution with compiled _rc.py module."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text('<ui><include location="theme.qrc"/></ui>')

        # Create fake _rc.py file
        rc_file = tmp_path / "theme_rc.py"
        rc_file.write_text("# fake rc module")

        loader = UILoader()
        with patch(
            "bitool.gui._uiloader.importlib.util.spec_from_file_location"
        ) as mock_spec:
            mock_spec_instance = MagicMock()
            mock_spec.return_value = mock_spec_instance
            mock_spec_instance.loader = MagicMock()

            loader._resolve_resources(ui_file)
            mock_spec.assert_called_once()

    def test_resolve_resources_rc_module_not_found(self, tmp_path: Path) -> None:
        """Test warning when _rc.py module doesn't exist."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text('<ui><include location="theme.qrc"/></ui>')

        loader = UILoader()
        with patch("bitool.gui._uiloader.logger.warning") as mock_warning:
            loader._resolve_resources(ui_file)
            mock_warning.assert_called_once()
            assert "资源模块不存在" in str(mock_warning.call_args)

    def test_resolve_resources_read_error(self, tmp_path: Path) -> None:
        """Test handling of UI file read errors."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        with patch.object(Path, "read_text", side_effect=OSError("Read error")), patch(
            "bitool.gui._uiloader.logger.warning"
        ) as mock_warning:
            loader._resolve_resources(ui_file)
            mock_warning.assert_called_once()
            assert "读取UI文件失败" in str(mock_warning.call_args)

    @pytest.mark.parametrize(
        ("ui_path_type", "ui_path_value"),
        [
            ("absolute", None),  # Will be set in test
            ("relative", "test.ui"),
        ],
    )
    def test_find_ui_file_absolute(
        self, tmp_path: Path, ui_path_type: str, ui_path_value: str | None
    ) -> None:
        """Test finding UI file with absolute path."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_frame = MagicMock()

        if ui_path_type == "absolute":
            result = loader._find_ui_file(ui_file, mock_frame)  # ty: ignore[invalid-argument-type]
        else:
            loader = UILoader(base_path=tmp_path)
            result = loader._find_ui_file(ui_path_value, mock_frame)  # ty: ignore[invalid-argument-type]

        assert result == ui_file

    def test_find_ui_file_relative(self, tmp_path: Path) -> None:
        """Test finding UI file with relative path."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader(base_path=tmp_path)
        mock_frame = MagicMock()

        result = loader._find_ui_file("test.ui", mock_frame)  # ty: ignore[invalid-argument-type]
        assert result == ui_file

    @pytest.mark.parametrize(
        ("py_filename", "expected_ui"),
        [
            ("mymodule.py", "mymodule.ui"),
            ("mymodule_ui.py", "mymodule.ui"),
            ("mymodule_widget.py", "mymodule.ui"),
            ("my_widget_ui.py", "my.ui"),
        ],
    )
    def test_find_ui_file_auto(
        self, tmp_path: Path, py_filename: str, expected_ui: str
    ) -> None:
        """Test automatic UI file finding with different naming patterns."""
        py_file = tmp_path / py_filename
        py_file.write_text("# test")
        ui_file = tmp_path / expected_ui
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_frame = MagicMock()
        mock_module = MagicMock()
        mock_module.__file__ = str(py_file)

        with patch("bitool.gui._uiloader.inspect.getmodule", return_value=mock_module):
            result = loader._find_ui_file(None, mock_frame)  # ty: ignore[invalid-argument-type]
            assert result == ui_file

    def test_find_ui_file_not_found(self, tmp_path: Path) -> None:
        """Test error when UI file not found."""
        loader = UILoader()
        mock_frame = MagicMock()
        mock_module = MagicMock()
        mock_module.__file__ = str(tmp_path / "nonexistent.py")

        with patch(
            "bitool.gui._uiloader.inspect.getmodule", return_value=mock_module
        ), pytest.raises(FileNotFoundError, match=r"无法自动找到\.ui文件"):
            loader._find_ui_file(None, mock_frame)  # ty: ignore[invalid-argument-type]

    def test_find_ui_file_specified_not_found(self, tmp_path: Path) -> None:
        """Test error when specified UI file not found."""
        loader = UILoader()
        mock_frame = MagicMock()

        non_existent = tmp_path / "nonexistent.ui"
        with pytest.raises(FileNotFoundError, match=r"UI文件不存在:"):
            loader._find_ui_file(non_existent, mock_frame)  # ty: ignore[invalid-argument-type]

    def test_find_ui_file_auto_no_module(self, tmp_path: Path) -> None:
        """Test error when auto-finding UI file but no module info available."""
        loader = UILoader()
        mock_frame = MagicMock()
        mock_module = MagicMock()
        mock_module.__file__ = None

        with patch(
            "bitool.gui._uiloader.inspect.getmodule", return_value=mock_module
        ), pytest.raises(FileNotFoundError, match=r"无法自动找到\.ui文件"):
            loader._find_ui_file(None, mock_frame)  # ty: ignore[invalid-argument-type]

    def test_find_ui_file_auto_no_file_attribute(self, tmp_path: Path) -> None:
        """Test error when auto-finding UI file but module has no __file__."""
        loader = UILoader()
        mock_frame = MagicMock()
        mock_module = MagicMock()
        # Configure MagicMock to not auto-create attributes
        mock_module.configure_mock(**{"__file__": None})

        with patch(
            "bitool.gui._uiloader.inspect.getmodule", return_value=mock_module
        ), pytest.raises(FileNotFoundError, match=r"无法自动找到\.ui文件"):
            loader._find_ui_file(None, mock_frame)  # ty: ignore[invalid-argument-type]

    @pytest.mark.parametrize(
        ("mtime1", "mtime2", "expected_equal"),
        [(1000.0, 1000.0, True), (1000.0, 2000.0, False)],
    )
    def test_get_cache_key(
        self, tmp_path: Path, mtime1: float, mtime2: float, expected_equal: bool
    ) -> None:
        """Test cache key generation."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()

        # Mock stat to return different mtime values
        mock_stat1 = MagicMock()
        mock_stat1.st_mtime = mtime1
        mock_stat2 = MagicMock()
        mock_stat2.st_mtime = mtime2

        with patch.object(Path, "stat", side_effect=[mock_stat1, mock_stat2]):
            key1 = loader._get_cache_key(ui_file)
            key2 = loader._get_cache_key(ui_file)

            if expected_equal:
                assert key1 == key2
            else:
                assert key1 != key2

            assert str(ui_file.absolute()) in key1

    def test_clear_cache(self) -> None:
        """Test cache clearing."""
        loader = UILoader()
        loader._cache = {"key1": MagicMock(), "key2": MagicMock()}

        loader.clear_cache()
        assert loader._cache == {}

    def test_resolve_resources_no_qrc(self, tmp_path: Path) -> None:
        """Test resource resolution when no qrc references."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        # Should not raise any errors
        loader._resolve_resources(ui_file)


class TestLoadUI:
    """Tests for load_ui method."""

    def test_load_ui_with_parent(self, tmp_path: Path) -> None:
        """Test loading UI with parent widget."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_parent = MagicMock()
        mock_widget = MagicMock()
        mock_widget.layout.return_value = None
        mock_widget.findChildren.return_value = []

        with patch(
            "bitool.gui._uiloader.QUiLoader.load", return_value=mock_widget
        ), patch("bitool.gui._uiloader.QFile") as mock_qfile:
            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True

            result = loader.load_ui(ui_file, mock_parent)

            assert result == mock_parent

    def test_load_ui_without_parent(self, tmp_path: Path) -> None:
        """Test loading UI without parent widget."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_widget = MagicMock()

        with patch(
            "bitool.gui._uiloader.QUiLoader.load", return_value=mock_widget
        ), patch("bitool.gui._uiloader.QFile") as mock_qfile:
            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True

            result = loader.load_ui(ui_file)

            assert result == mock_widget

    def test_load_ui_file_open_error(self, tmp_path: Path) -> None:
        """Test error when UI file cannot be opened."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()

        with patch("bitool.gui._uiloader.QFile") as mock_qfile:
            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = False

            with pytest.raises(RuntimeError, match=r"无法打开UI文件:"):
                loader.load_ui(ui_file)

    def test_load_ui_load_error(self, tmp_path: Path) -> None:
        """Test error when UI loading fails."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()

        with patch("bitool.gui._uiloader.QUiLoader.load", return_value=None), patch(
            "bitool.gui._uiloader.QFile"
        ) as mock_qfile:
            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True

            with pytest.raises(RuntimeError, match=r"加载UI文件失败:"):
                loader.load_ui(ui_file)

    def test_load_ui_cannot_get_caller_info(self) -> None:
        """Test error when caller information cannot be obtained."""
        loader = UILoader()

        with patch(
            "bitool.gui._uiloader.inspect.currentframe", return_value=None
        ), pytest.raises(RuntimeError, match=r"无法获取调用者信息"):
            loader.load_ui(None)

    def test_load_ui_skip_uiloader_frames(self, tmp_path: Path) -> None:
        """Test that load_ui skips frames from _uiloader.py when auto-finding."""
        ui_file = tmp_path / "mywidget.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_widget = MagicMock()

        # Create mock frames simulating the call stack
        mock_external_frame = MagicMock()
        mock_uiloader_frame = MagicMock()

        # Mock module for external frame
        mock_external_module = MagicMock()
        mock_external_module.__file__ = str(tmp_path / "mywidget.py")

        # Mock module for uiloader frame
        mock_uiloader_module = MagicMock()
        mock_uiloader_module.__file__ = str(
            Path(__file__).parent.parent / "_uiloader.py"
        )

        # Setup frame chain: currentframe -> uiloader_frame -> external_frame
        with patch(
            "bitool.gui._uiloader.inspect.currentframe"
        ) as mock_currentframe, patch(
            "bitool.gui._uiloader.inspect.getmodule"
        ) as mock_getmodule, patch(
            "bitool.gui._uiloader.QUiLoader.load", return_value=mock_widget
        ), patch("bitool.gui._uiloader.QFile") as mock_qfile:
            mock_currentframe_instance = MagicMock()
            mock_currentframe_instance.f_back = mock_uiloader_frame
            mock_currentframe.return_value = mock_currentframe_instance

            mock_uiloader_frame.f_back = mock_external_frame

            def getmodule_side_effect(frame):  # noqa: ANN202
                if frame == mock_uiloader_frame:
                    return mock_uiloader_module
                elif frame == mock_external_frame:
                    return mock_external_module
                return None

            mock_getmodule.side_effect = getmodule_side_effect

            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True
            mock_widget.layout.return_value = None
            mock_widget.findChildren.return_value = []

            result = loader.load_ui(None)
            assert result == mock_widget

    def test_load_ui_no_external_frame_fallback(self, tmp_path: Path) -> None:
        """Test fallback when no external frame is found (all frames from _uiloader.py)."""
        ui_file = tmp_path / "mywidget.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_widget = MagicMock()

        # Mock frames where all are from _uiloader.py
        mock_frame1 = MagicMock()
        mock_frame2 = MagicMock()

        mock_module1 = MagicMock()
        mock_module1.__file__ = str(Path(__file__).parent.parent / "_uiloader.py")

        # Second frame has no module info (simulating end of stack)
        mock_frame2.f_back = None

        with patch(
            "bitool.gui._uiloader.inspect.currentframe"
        ) as mock_currentframe, patch(
            "bitool.gui._uiloader.inspect.getmodule", return_value=mock_module1
        ), patch(
            "bitool.gui._uiloader.QUiLoader.load", return_value=mock_widget
        ), patch("bitool.gui._uiloader.QFile") as mock_qfile, pytest.raises(
            FileNotFoundError, match=r"无法自动找到\.ui文件"
        ):
            mock_currentframe_instance = MagicMock()
            mock_currentframe_instance.f_back = mock_frame1
            mock_currentframe.return_value = mock_currentframe_instance

            mock_frame1.f_back = mock_frame2

            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True

            loader.load_ui(None)

    @pytest.mark.parametrize(
        ("has_layout", "has_children", "expected_set_layout"),
        [
            (True, True, True),
            (False, True, False),
            (True, False, True),
            (False, False, False),
        ],
    )
    def test_load_ui_with_parent_and_children(
        self,
        tmp_path: Path,
        has_layout: bool,
        has_children: bool,
        expected_set_layout: bool,
    ) -> None:
        """Test loading UI with parent and various child configurations."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_parent = MagicMock()
        mock_widget = MagicMock()

        # Setup layout
        if has_layout:
            mock_layout = MagicMock()
            mock_widget.layout.return_value = mock_layout
        else:
            mock_widget.layout.return_value = None

        # Setup children
        if has_children:
            mock_child = MagicMock()
            mock_child.objectName.return_value = "testChild"
            mock_widget.findChildren.return_value = [mock_child]
            mock_parent.findChildren.return_value = []
        else:
            mock_widget.findChildren.return_value = []
            mock_parent.findChildren.return_value = []

        with patch(
            "bitool.gui._uiloader.QUiLoader.load", return_value=mock_widget
        ), patch("bitool.gui._uiloader.QFile") as mock_qfile:
            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True

            result = loader.load_ui(ui_file, mock_parent)

            assert result == mock_parent
            if expected_set_layout:
                mock_parent.setLayout.assert_called_once()
            else:
                mock_parent.setLayout.assert_not_called()

    def test_load_ui_caching(self, tmp_path: Path) -> None:
        """Test that UI loading uses cache."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_widget = MagicMock()

        with patch(
            "bitool.gui._uiloader.QUiLoader.load", return_value=mock_widget
        ) as mock_load, patch("bitool.gui._uiloader.QFile") as mock_qfile:
            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True

            # First load
            result1 = loader.load_ui(ui_file)
            assert mock_load.call_count == 1

            # Second load should use cache
            result2 = loader.load_ui(ui_file)
            assert mock_load.call_count == 1  # Still 1, used cache

            assert result1 == result2

    def test_load_ui_widget_equals_parent(self, tmp_path: Path) -> None:
        """Test loading UI when widget returned by loader equals parent."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_parent = MagicMock()

        # Mock children on parent
        mock_child1 = MagicMock()
        mock_child1.objectName.return_value = "button1"
        mock_child2 = MagicMock()
        mock_child2.objectName.return_value = "_private"  # Should be skipped
        mock_parent.findChildren.return_value = [mock_child1, mock_child2]

        with patch(
            "bitool.gui._uiloader.QUiLoader.load", return_value=mock_parent
        ) as mock_load, patch("bitool.gui._uiloader.QFile") as mock_qfile:
            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True
            mock_parent.layout.return_value = None

            result = loader.load_ui(ui_file, mock_parent)

            assert result == mock_parent
            # Verify attributes were set for valid children
            assert hasattr(mock_parent, "button1")
            # _private should not be set as it starts with underscore
            mock_load.assert_called_once()

    def test_load_ui_parent_with_children_on_widget(self, tmp_path: Path) -> None:
        """Test loading UI with parent when children are on the loaded widget."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_parent = MagicMock()
        mock_widget = MagicMock()

        # Widget has children
        mock_child1 = MagicMock()
        mock_child1.objectName.return_value = "label1"
        mock_child2 = MagicMock()
        mock_child2.objectName.return_value = ""  # Empty name should be skipped
        mock_widget.findChildren.return_value = [mock_child1, mock_child2]
        mock_parent.findChildren.return_value = []

        mock_layout = MagicMock()
        mock_widget.layout.return_value = mock_layout

        with patch(
            "bitool.gui._uiloader.QUiLoader.load", return_value=mock_widget
        ), patch("bitool.gui._uiloader.QFile") as mock_qfile:
            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True

            result = loader.load_ui(ui_file, mock_parent)

            assert result == mock_parent
            mock_parent.setLayout.assert_called_once_with(mock_layout)
            mock_widget.hide.assert_called_once()
            # Verify attribute was set
            assert hasattr(mock_parent, "label1")

    def test_load_ui_parent_with_no_widget_children_uses_parent_children(
        self, tmp_path: Path
    ) -> None:
        """Test that when widget has no children, parent's children are used."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_parent = MagicMock()
        mock_widget = MagicMock()

        # Widget has only 1 child (simulating no business controls)
        mock_widget.findChildren.return_value = [MagicMock()]

        # Parent has actual children
        mock_child1 = MagicMock()
        mock_child1.objectName.return_value = "textbox1"
        mock_parent.findChildren.return_value = [mock_child1]

        mock_widget.layout.return_value = None

        with patch(
            "bitool.gui._uiloader.QUiLoader.load", return_value=mock_widget
        ), patch("bitool.gui._uiloader.QFile") as mock_qfile:
            mock_file_instance = MagicMock()
            mock_qfile.return_value = mock_file_instance
            mock_file_instance.open.return_value = True

            result = loader.load_ui(ui_file, mock_parent)

            assert result == mock_parent
            assert hasattr(mock_parent, "textbox1")


class TestSetupUI:
    """Tests for setup_ui method."""

    def test_setup_ui_basic(self, tmp_path: Path) -> None:
        """Test basic setup_ui functionality."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_widget = MagicMock()
        mock_widget.findChildren.return_value = []

        with patch.object(loader, "load_ui") as mock_load_ui:
            loader.setup_ui(mock_widget, ui_file)
            mock_load_ui.assert_called_once_with(ui_file, mock_widget)

    def test_setup_ui_sets_attributes(self, tmp_path: Path) -> None:
        """Test that setup_ui sets widget attributes from children."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_widget = MagicMock()

        # Mock children with names - only valid names should be set
        mock_child1 = MagicMock()
        mock_child1.objectName.return_value = "button1"

        mock_widget.findChildren.return_value = [mock_child1]

        with patch.object(loader, "load_ui"):
            loader.setup_ui(mock_widget, ui_file)
            # Verify setattr was called for button1
            assert hasattr(mock_widget, "button1")


class TestConvenienceFunctions:
    """Tests for module-level convenience functions."""

    def test_load_ui_function(self) -> None:
        """Test load_ui convenience function."""
        # This would require a real UI file and Qt app
        # For now, just test that the function exists and is callable
        assert callable(load_ui)

    def test_setup_ui_function(self) -> None:
        """Test setup_ui convenience function."""
        assert callable(setup_ui)

    def test_clear_cache_function(self) -> None:
        """Test clear_cache convenience function."""
        # Should not raise any errors
        clear_ui_cache()

    def test_load_ui_function_calls_default_loader(self, tmp_path: Path) -> None:
        """Test that load_ui function calls the default loader."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        mock_widget = MagicMock()
        mock_widget.layout.return_value = None
        mock_widget.findChildren.return_value = []

        with patch.object(
            _default_loader, "load_ui", return_value=mock_widget
        ) as mock_load:
            result = load_ui(ui_file)
            mock_load.assert_called_once_with(ui_file, None)
            assert result == mock_widget

    def test_setup_ui_function_calls_default_loader(self, tmp_path: Path) -> None:
        """Test that setup_ui function calls the default loader."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        mock_widget = MagicMock()
        mock_widget.findChildren.return_value = []

        with patch.object(_default_loader, "setup_ui") as mock_setup:
            setup_ui(mock_widget, ui_file)
            mock_setup.assert_called_once_with(mock_widget, ui_file)

    def test_clear_cache_function_calls_default_loader(self) -> None:
        """Test that clear_cache function calls the default loader."""
        with patch.object(_default_loader, "clear_cache") as mock_clear:
            clear_ui_cache()
            mock_clear.assert_called_once()

    def test_setup_ui_filters_private_children(self, tmp_path: Path) -> None:
        """Test that setup_ui only sets attributes for non-private children."""
        ui_file = tmp_path / "test.ui"
        ui_file.write_text("<ui></ui>")

        loader = UILoader()
        mock_widget = MagicMock()

        # Mock children - mix of valid and private names
        mock_child1 = MagicMock()
        mock_child1.objectName.return_value = "button1"
        mock_child2 = MagicMock()
        mock_child2.objectName.return_value = "_private_button"
        mock_child3 = MagicMock()
        mock_child3.objectName.return_value = ""  # Empty name
        mock_child4 = MagicMock()
        mock_child4.objectName.return_value = "label1"

        mock_widget.findChildren.return_value = [
            mock_child1,
            mock_child2,
            mock_child3,
            mock_child4,
        ]

        with patch.object(loader, "load_ui"):
            loader.setup_ui(mock_widget, ui_file)
            # Verify only valid names are set as attributes
            assert hasattr(mock_widget, "button1")
            assert hasattr(mock_widget, "label1")
            # _private_button should not be set (starts with _)
            # Empty name should not be set
