"""uiloader_demo.py 的动态UI加载器使用示例.

此示例演示如何使用UILoader动态加载.ui文件,无需维护*_ui.py文件.
"""

from __future__ import annotations

import sys
from pathlib import Path

from PySide2.QtWidgets import QApplication, QDialog, QPushButton

# 导入动态UI加载器
from bitool.gui import load_ui, setup_ui

SIZE = (480, 320)
POSITIONS = [(x * SIZE[0] + 480, 400) for x in range(3)]


class ExampleDialogAuto(QDialog):
    """示例:自动查找.ui文件.

    这种方式会在同级目录自动查找与.py文件同名的.ui文件.
    例如:uiloader_demo.py -> 查找 uiloader_demo.ui
    """

    close_button: QPushButton

    def __init__(self) -> None:
        super().__init__()

        # 自动加载uiloader_demo.ui文件
        load_ui(parent=self)

        self.setWindowTitle("自动查找UI示例")
        self.setGeometry(*POSITIONS[0], *SIZE)

        self.close_button.clicked.connect(self.close)


class ExampleDialogManual(QDialog):
    """示例:手动指定.ui文件.

    这种方式允许你明确指定要加载的.ui文件路径.
    """

    close_button: QPushButton

    def __init__(self, ui_file_path: Path) -> None:
        super().__init__()

        # 手动指定.ui文件路径
        load_ui(ui_file_path, parent=self)
        self.setWindowTitle("手动指定UI示例")
        self.setGeometry(*POSITIONS[1], *SIZE)

        # 连接关闭按钮
        self.close_button.clicked.connect(self.close)


class ExampleDialogSetupUi(QDialog):
    """示例:使用setup_ui方式(兼容现有代码).

    这种方式与现有的setupUi模式类似,将UI控件作为属性添加到widget
    """

    close_button: QPushButton

    def __init__(self) -> None:
        super().__init__()

        # 使用setup_ui将UI加载到self
        setup_ui(self)

        self.setWindowTitle("SetupUI方式示例")
        self.setGeometry(*POSITIONS[2], *SIZE)

        self.close_button.clicked.connect(self.close)


def main() -> None:
    """运行示例."""
    app = QApplication(sys.argv)

    # 示例1, 自动查找.ui文件
    dialog1 = ExampleDialogAuto()
    dialog1.show()

    # 示例2, 手动指定.ui文件
    ui_file = Path(__file__).parent / "uiloader_demo.ui"
    dialog2 = ExampleDialogManual(ui_file)
    dialog2.show()

    # 示例3, 使用setup_ui方式
    dialog3 = ExampleDialogSetupUi()
    dialog3.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
