"""Pytola Qt Styles 演示程序包.

包含主题测试器和其他演示应用
"""
