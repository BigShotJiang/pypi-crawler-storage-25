import platform
from dataclasses import dataclass


@dataclass(frozen=True)
class Constants:
    IS_WINDOWS = platform.system() == "Windows"
    IS_UNIX = platform.system() == "Linux" or platform.system() == "Darwin"
    IS_CYGWIN = platform.system() == "CYGWIN"
    IS_MINGW = platform.system() == "MINGW"
    IS_WSL = platform.system() == "Linux" and "microsoft" in platform.release().lower()
    IS_MSYS = platform.system() == "MSYS"

    EXTENSION = ".exe" if IS_WINDOWS else ""
