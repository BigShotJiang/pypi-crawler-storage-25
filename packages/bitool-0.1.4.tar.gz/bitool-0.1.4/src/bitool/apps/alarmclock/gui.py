"""Graphical user interface for alarmclock."""

from __future__ import annotations

import sys

from PySide2.QtWidgets import QApplication

from .widgets.alarmclock import AlarmClock


def main() -> None:
    """Run entry point for the GUI application."""
    app = QApplication(sys.argv)

    window = AlarmClock()
    window.show()

    sys.exit(app.exec_())
