"""Configuration for alarmclock."""

from __future__ import annotations

from bitool.core import JsonConfig


class AlarmClockConfig(JsonConfig):
    """Configuration for the alarm clock application."""

    CLOCK_SIZE = [480, 400]  # noqa: RUF012
    WIN_SIZE = [480, 400]  # noqa: RUF012
    WIN_POS = [300, 200]  # noqa: RUF012
    THEME = "high_contrast"
    ALARM_CLOCK_TITLE = "Digital Alarm Clock"
    DIGITAL_FONT = "bold italic 81px 'Consolas'"
    DIGITAL_BORDER_COLORS = ("#00aa00", "#eecc00", "#aa00aa", "#c0e0b0")
    DIGITAL_TIMER_FORMAT = "%H:%M:%S"
    DIGITAL_UPDATE_INTERVAL = 1000

    BLINK_TITLE = "Alarm Reminder!"
    BLINK_CONTENT = "⏰ Time's Up!"
    BLINK_TYPE = "color"
    BLINK_BG_COLORS = ("#baf1ba", "#f8ccc3", "#aab4f0", "#efaec0")
    BLINK_INTERVAL = 300
    DELAY_STEPS = (1, 5, 10, 15, 30, 60)


conf = AlarmClockConfig()
