"""Alarmclock module."""
