# Bitool PyPack

Bitool PyPack 是一个 Python 项目完整打包工具，用于将 Python 项目打包为独立的可执行分发包。

## 功能特性

- **项目扫描和管理**: 自动扫描目录中的 Python 项目
- **嵌入式 Python 下载和安装**: 自动下载并安装嵌入式 Python 运行时
- **依赖库打包**: 使用 pip 打包所有依赖库
- **加载器生成**: 生成 C 语言加载器，支持 Console 和 GUI 模式
- **源码打包**: 智能打包源代码，避免无限递归
- **多格式归档**: 支持 ZIP、TAR、GZTAR、BZTAR、XZTAR、7z 等格式

## 安装

```bash
pip install bitool-pypack
```

## 使用方法

### 构建项目

```bash
pypack build
```

### 列出项目

```bash
pypack list
```

### 运行项目

```bash
pypack run --project myproject
```

### 清理构建产物

```bash
pypack clean
```

## 命令行参数

- `--project`, `-p`: 指定项目名称
- `--python-version`: 指定 Python 版本（默认: 3.8.10）
- `--loader-type`: 加载器类型（console 或 gui）
- `--archive`, `-a`: 归档格式（zip、tar、gztar 等）
- `--offline`, `-o`: 离线模式
- `--jobs`, `-j`: 最大并发任务数
- `--debug`, `-d`: 调试模式

## 开发

```bash
pip install -e ".[dev]"
```

## 许可证

MIT
