"""嵌入式 Python 安装器."""

from __future__ import annotations

import platform
import time
import zipfile
from dataclasses import dataclass
from functools import cached_property
from pathlib import Path
from typing import Final
from urllib.request import Request, urlopen

from bitool.core import logger

# 默认缓存目录
_DEFAULT_CACHE_DIR: Final[Path] = (
    Path.home() / ".bitool" / "pypack" / "cache" / "embed-python"
)
_DEFAULT_PYTHON_VER: Final[str] = "3.8.10"

# 架构映射
ARCH_DICT: Final[dict[str, str]] = {
    "amd64": "amd64",
    "x86_64": "amd64",
    "x86": "amd64",
    "arm64": "arm64",
    "aarch64": "arm64",
}

# User-Agent
USER_AGENT: Final[str] = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
)


@dataclass(frozen=True)
class EmbedInstaller:
    """嵌入式 Python 安装器.

    Attributes
    ----------
    root_dir : Path
        项目根目录
    python_version : str
        Python 版本
    cache_dir : Path | None
        缓存目录
    offline : bool
        离线模式
    timeout : int
        下载超时时间
    """

    root_dir: Path
    python_version: str = _DEFAULT_PYTHON_VER
    cache_dir: Path | None = None
    offline: bool = False
    timeout: int = 300

    @cached_property
    def arch(self) -> str:
        """获取系统架构.

        Returns
        -------
        str
            架构名称
        """
        machine = platform.machine().lower()
        return ARCH_DICT.get(machine, "amd64")

    @cached_property
    def actual_cache_dir(self) -> Path:
        """获取实际的缓存目录.

        Returns
        -------
        Path
            缓存目录路径
        """
        return self.cache_dir or _DEFAULT_CACHE_DIR

    @cached_property
    def embed_dir(self) -> Path:
        """获取嵌入式 Python 安装目录.

        Returns
        -------
        Path
            安装目录
        """
        return self.root_dir / ".cbuild" / "python"

    def run(self) -> bool:
        """执行安装.

        Returns
        -------
        bool
            是否成功
        """
        logger.info("正在安装嵌入式 Python...")
        start_time = time.perf_counter()

        try:
            # 检查是否已安装
            if self.embed_dir.exists() and (self.embed_dir / "python.exe").exists():
                logger.info(f"嵌入式 Python 已存在: {self.embed_dir}")
                return True

            # 下载嵌入式 Python
            downloader = EmbedDownloader(self, self.python_version)
            if not downloader.download():
                logger.error("下载嵌入式 Python 失败")
                return False

            # 解压
            self._extract(downloader.cache_file)

            elapsed = time.perf_counter() - start_time
            logger.info(f"嵌入式 Python 安装完成，耗时 {elapsed:.2f}秒")
            return True

        except Exception:
            logger.exception("嵌入式 Python 安装失败")
            return False

    def _extract(self, zip_file: Path) -> None:
        """解压嵌入式 Python.

        Parameters
        ----------
        zip_file : Path
            ZIP 文件路径
        """
        logger.info(f"正在解压到: {self.embed_dir}")
        self.embed_dir.mkdir(parents=True, exist_ok=True)

        with zipfile.ZipFile(zip_file, "r") as zf:
            zf.extractall(self.embed_dir)

        logger.info(f"解压完成: {self.embed_dir}")


@dataclass(frozen=True)
class EmbedDownloader:
    """嵌入式 Python 下载器.

    Attributes
    ----------
    parent : EmbedInstaller
        父安装器
    version : str
        Python 版本
    """

    parent: EmbedInstaller
    version: str

    @cached_property
    def cache_file(self) -> Path:
        """获取缓存文件路径.

        Returns
        -------
        Path
            缓存文件路径
        """
        return (
            self.parent.actual_cache_dir
            / f"python-{self.version}-embed-{self.parent.arch}.zip"
        )

    @cached_property
    def download_urls(self) -> list[str]:
        """获取下载 URL 列表.

        Returns
        -------
        list[str]
            URL 列表
        """
        version = self.version
        arch = self.parent.arch

        # 镜像源 URL
        mirrors = [
            f"https://mirrors.huaweicloud.com/python/{version}/python-{version}-embed-{arch}.zip",
            f"https://mirrors.aliyun.com/python-release/{version}/python-{version}-embed-{arch}.zip",
            f"https://mirrors.tuna.tsinghua.edu.cn/python/{version}/python-{version}-embed-{arch}.zip",
        ]

        # 官方 URL
        official = f"https://www.python.org/ftp/python/{version}/python-{version}-embed-{arch}.zip"

        return [*mirrors, official]

    def download(self) -> bool:
        """执行下载.

        Returns
        -------
        bool
            是否成功
        """
        # 检查缓存
        if self.cache_file.exists() and zipfile.is_zipfile(self.cache_file):
            logger.info(f"使用缓存文件: {self.cache_file}")
            return True

        # 删除损坏的缓存
        if self.cache_file.exists():
            logger.warning("缓存文件损坏，将重新下载")
            self.cache_file.unlink()

        if self.parent.offline:
            logger.error("离线模式：未找到缓存文件")
            return False

        # 尝试从各个 URL 下载
        for i, url in enumerate(self.download_urls, 1):
            logger.info(f"尝试下载 {i}/{len(self.download_urls)}: {url}")
            try:
                self._download_from_url(url)
                if zipfile.is_zipfile(self.cache_file):
                    logger.info("下载成功")
                    return True
                logger.warning("下载的文件损坏，尝试下一个 URL")
            except Exception as e:
                logger.warning(f"下载失败: {e}")

        logger.error("所有下载源均失败")
        return False

    def _download_from_url(self, url: str) -> None:
        """从 URL 下载文件.

        Parameters
        ----------
        url : str
            下载 URL
        """
        req = Request(url, headers={"User-Agent": USER_AGENT})

        with urlopen(req, timeout=self.parent.timeout) as response:
            total_size = int(response.getheader("content-length", 0))
            self.cache_file.parent.mkdir(parents=True, exist_ok=True)

            downloaded = 0
            last_progress = 0

            with self.cache_file.open("wb") as f:
                while chunk := response.read(65536):
                    f.write(chunk)
                    downloaded += len(chunk)

                    if total_size > 0:
                        progress = int((downloaded / total_size) * 100)
                        if progress > last_progress:
                            logger.info(
                                f"下载进度: {downloaded / 1024 / 1024:.2f} MB / "
                                f"{total_size / 1024 / 1024:.2f} MB ({progress}%)"
                            )
                            last_progress = progress
