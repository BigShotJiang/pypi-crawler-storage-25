"""加载器生成器.
生成 C 语言加载器，用于启动 Python 解释器并执行指定脚本.
"""

from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path

from bitool.core import logger


@dataclass
class PyLoaderGenerator:
    """加载器生成器.

    生成 C 语言加载器源代码并编译为可执行文件.

    Attributes
    ----------
    root_dir : Path
        根目录
    project_name : str
        项目名称
    python_exe : Path
        Python 解释器路径
    script_name : str
        主脚本名称，默认 main.py
    loader_type : str
        加载器类型：console 或 gui
    """

    root_dir: Path
    project_name: str
    python_exe: Path
    script_name: str = "main.py"
    loader_type: str = "console"

    def run(self) -> bool:
        """执行加载器生成.

        Returns
        -------
        bool
            是否成功
        """
        try:
            # 生成 C 源代码
            source_file = self._generate_source()
            if not source_file:
                return False

            # 编译为可执行文件
            exe_file = self._compile(source_file)
            return exe_file is not None

        except Exception as exc:
            logger.error(f"生成加载器失败: {exc}")
            return False

    def _generate_source(self) -> Path | None:
        """生成 C 语言源代码文件."""
        try:
            source_file = self.root_dir / f"{self.project_name}_loader.c"

            # 根据类型选择子系统
            subsystem = "windows" if self.loader_type == "gui" else "console"

            # 使用绝对路径
            python_exe_abs = self.python_exe.resolve()

            c_code = self._get_c_template().format(
                python_exe=str(python_exe_abs).replace("\\", "\\\\"),
                script_name=self.script_name,
                subsystem=subsystem,
                project_name=self.project_name,
            )

            source_file.write_text(c_code, encoding="utf-8")
            logger.debug(f"生成加载器源码: {source_file}")
            return source_file

        except Exception as exc:
            logger.error(f"生成源代码失败: {exc}")
            return None

    def _compile(self, source_file: Path) -> Path | None:
        """编译 C 源代码为可执行文件."""
        try:
            exe_file = self.root_dir / f"{self.project_name}.exe"

            # 尝试使用 MSVC 编译器
            if self._try_msvc(source_file, exe_file):
                logger.info(f"使用 MSVC 编译成功: {exe_file}")
                return exe_file

            # 尝试使用 MinGW
            if self._try_mingw(source_file, exe_file):
                logger.info(f"使用 MinGW 编译成功: {exe_file}")
                return exe_file

            # 两个编译器都失败
            logger.warning("未找到可用的 C 编译器，跳过加载器编译")
            logger.info("提示: 请安装 MinGW (https://www.mingw-w64.org/) 或 MSVC")
            return None

        except Exception as exc:
            logger.error(f"编译失败: {exc}")
            return None

    def _try_msvc(self, source: Path, output: Path) -> bool:
        """尝试使用 MSVC 编译."""
        try:
            subsystem = (
                "/SUBSYSTEM:WINDOWS"
                if self.loader_type == "gui"
                else "/SUBSYSTEM:CONSOLE"
            )
            cmd = ["cl", "/nologo", "/O2", subsystem, f"/Fe:{output}", str(source)]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            return result.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    def _try_mingw(self, source: Path, output: Path) -> bool:
        """尝试使用 MinGW 编译."""
        try:
            # 构建编译命令，只在 GUI 模式添加 -mwindows
            cmd = ["gcc", "-O2"]
            if self.loader_type == "gui":
                cmd.append("-mwindows")
            cmd.extend(["-o", str(output), str(source)])

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            return result.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    def _get_c_template(self) -> str:
        """获取 C 代码模板."""
        return """// 自动生成的加载器，用于 {project_name}
#include <windows.h>
#include <stdio.h>
#include <direct.h>

int main(int argc, char* argv[]) {{
    char python_path[] = "{python_exe}";
    char script_name[] = "{script_name}";
    
    // 获取可执行文件所在目录
    char exe_path[MAX_PATH];
    GetModuleFileNameA(NULL, exe_path, MAX_PATH);
    
    // 提取目录部分
    char* last_backslash = strrchr(exe_path, '\\\\');
    if (last_backslash) {{
        *(last_backslash + 1) = '\\0';
    }}
    
    // 设置工作目录为可执行文件所在目录
    SetCurrentDirectoryA(exe_path);
    
    // 尝试在多个位置查找 main.py
    char script_path[MAX_PATH];
    BOOL found = FALSE;
    
    // 尝试 1: 当前目录 (./main.py)
    snprintf(script_path, sizeof(script_path), "%s", script_name);
    if (GetFileAttributesA(script_path) != INVALID_FILE_ATTRIBUTES) {{
        found = TRUE;
    }}
    
    // 尝试 2: src/{project_name}/main.py
    if (!found) {{
        snprintf(script_path, sizeof(script_path), "src\\\\{project_name}\\\\%s", script_name);
        if (GetFileAttributesA(script_path) != INVALID_FILE_ATTRIBUTES) {{
            found = TRUE;
        }}
    }}
    
    // 尝试 3: src/main.py
    if (!found) {{
        snprintf(script_path, sizeof(script_path), "src\\\\%s", script_name);
        if (GetFileAttributesA(script_path) != INVALID_FILE_ATTRIBUTES) {{
            found = TRUE;
        }}
    }}
    
    if (!found) {{
        printf("错误: 找不到脚本文件 %s\\n", script_name);
        printf("请确保打包正确。\\n");
        return 1;
    }}
    
    // 启动 Python 解释器执行脚本，并传递命令行参数
    char cmd_line[MAX_PATH * 4];
    
    // 构建命令：python.exe main.py [args...]
    // 首先添加 python 解释器和脚本路径
    int len = snprintf(cmd_line, sizeof(cmd_line), "\\"%s\\" \\"%s\\"", python_path, script_path);
    
    // 添加额外的命令行参数（从 argv[1] 开始）
    if (len > 0 && len < (int)sizeof(cmd_line)) {{
        for (int i = 1; i < argc; i++) {{
            int remaining = sizeof(cmd_line) - len - 1;
            if (remaining > 0) {{
                len += snprintf(cmd_line + len, remaining, " \\"%s\\"", argv[i]);
            }}
        }}
    }}
    
    STARTUPINFO si = {{0}};
    PROCESS_INFORMATION pi = {{0}};
    si.cb = sizeof(si);
    
    if (CreateProcessA(
        NULL,
        cmd_line,
        NULL,
        NULL,
        FALSE,
        0,
        NULL,
        NULL,
        &si,
        &pi
    )) {{
        WaitForSingleObject(pi.hProcess, INFINITE);
        DWORD exit_code = 0;
        GetExitCodeProcess(pi.hProcess, &exit_code);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
        return (int)exit_code;
    }} else {{
        printf("错误: 无法启动 Python 解释器\\n");
        return 1;
    }}
}}
"""  # noqa: E501
