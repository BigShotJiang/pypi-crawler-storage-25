"""归档器.
实现多种格式的归档功能，包括 ZIP、tar.gz 等.
"""

from __future__ import annotations

import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

from bitool.core import logger


@dataclass
class PyArchiver:
    """归档器.

    支持多种归档格式：ZIP、tar.gz、7z 等.

    Attributes
    ----------
    root_dir : Path
        根目录
    build_dir : Path
        构建目录（.cbuild）
    """

    root_dir: Path
    build_dir: Path | None = None

    def __post_init__(self) -> None:
        """初始化后设置默认构建目录."""
        if self.build_dir is None:
            self.build_dir = self.root_dir / ".cbuild"

    def run(self, archive_format: str = "zip") -> bool:
        """执行归档.

        Parameters
        ----------
        archive_format : str
            归档格式，支持：zip、tar、gztar、bztar、xztar、7z

        Returns
        -------
        bool
            是否成功
        """
        try:
            # 确保 build_dir 已设置
            if self.build_dir is None:
                self.build_dir = self.root_dir / ".cbuild"

            build_dir = self.build_dir  # 类型窄化

            if not build_dir.exists():
                logger.warning(f"构建目录不存在: {build_dir}")
                return False

            # 根据格式选择归档方法
            if archive_format == "7z":
                return self._archive_7z(build_dir)
            elif archive_format in {"zip", "tar", "gztar", "bztar", "xztar"}:
                return self._archive_shutil(archive_format, build_dir)
            else:
                logger.error(f"不支持的归档格式: {archive_format}")
                return False

        except Exception as exc:
            logger.error(f"归档失败: {exc}")
            return False

    def _archive_shutil(self, archive_format: str, build_dir: Path) -> bool:
        """使用 shutil 进行归档.

        Parameters
        ----------
        archive_format : str
            归档格式：zip、tar、gztar、bztar、xztar
        build_dir : Path
            构建目录

        Returns
        -------
        bool
            是否成功
        """
        try:
            # 输出文件名（不含扩展名）
            output_name = self.root_dir / f"{self.root_dir.name}_package"

            logger.info(f"正在创建 {archive_format} 归档...")

            # 使用 shutil.make_archive
            archive_path = shutil.make_archive(
                base_name=str(output_name),
                format=archive_format,
                root_dir=str(build_dir),
            )

            logger.info(f"归档完成: {archive_path}")
        except Exception as exc:
            logger.error(f"shutil 归档失败: {exc}")
            return False
        else:
            return True

    def _archive_7z(self, build_dir: Path) -> bool:
        """使用 7-Zip 进行归档.

        Parameters
        ----------
        build_dir : Path
            构建目录

        Returns
        -------
        bool
            是否成功
        """
        try:
            # 检查 7z 是否可用
            if not self._check_7z():
                logger.warning("未找到 7z 命令，回退到 ZIP 格式")
                return self._archive_shutil("zip", build_dir)

            output_file = self.root_dir / f"{self.root_dir.name}_package.7z"

            logger.info("正在创建 7z 归档...")

            # 构建通配符路径
            source_pattern = str(build_dir / "*")

            cmd = [
                "7z",
                "a",
                "-t7z",
                "-mx=9",  # 最高压缩级别
                str(output_file),
                source_pattern,
            ]

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)

            if result.returncode == 0:
                logger.info(f"7z 归档完成: {output_file}")
                return True
            else:
                logger.error(f"7z 归档失败: {result.stderr}")
                return False

        except Exception as exc:
            logger.error(f"7z 归档失败: {exc}")
            return False

    def _check_7z(self) -> bool:
        """检查 7z 命令是否可用.

        Returns
        -------
        bool
            是否可用
        """
        try:
            result = subprocess.run(
                ["7z", "--help"], capture_output=True, text=True, timeout=5
            )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False
        else:
            return result.returncode == 0
