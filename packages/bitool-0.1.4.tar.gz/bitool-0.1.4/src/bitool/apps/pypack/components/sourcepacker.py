"""源码打包器."""

from __future__ import annotations

import shutil
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Final

try:
    import tomllib  # ty:ignore[unresolved-import]
except ImportError:
    import tomli as tomllib  # type: ignore[import-not-found, no-redef]

from bitool.core import logger

from ..progress import format_file_size

# 默认忽略模式
_DEFAULT_IGNORE_PATTERNS: Final[frozenset[str]] = frozenset(
    [
        "__pycache__",
        "*.pyc",
        "*.pyo",
        ".git",
        ".pytest_cache",
        ".coverage",
        "*.egg-info",
        "build",
        "*.log",
        ".ruff_cache",
        ".benchmarks",
    ]
)


@dataclass
class PySourcePacker:
    """源码打包器.

    Attributes
    ----------
    root_dir : Path
        根目录
    """

    root_dir: Path

    def run(self) -> bool:
        """执行源代码打包.

        Returns
        -------
        bool
            是否成功
        """
        logger.info("正在打包源代码...")
        start_time = time.perf_counter()

        try:
            # 扫描项目
            projects = self._scan_projects()

            if not projects:
                logger.info("没有找到项目")
                return True

            # 打包每个项目
            total_size = 0
            for project_dir in projects:
                size = self._pack_project(project_dir)
                total_size += size

            elapsed = time.perf_counter() - start_time
            logger.info(f"源代码打包完成，耗时 {elapsed:.2f}秒")
            logger.info(f"总打包体积: {format_file_size(total_size)}")
            return True

        except Exception:
            logger.exception("源代码打包失败")
            return False

    def _scan_projects(self) -> list[Path]:
        """扫描项目.

        Returns
        -------
        list[Path]
            项目目录列表
        """
        projects = []

        for pyproject in self.root_dir.rglob("pyproject.toml"):
            # 跳过忽略的目录
            if any(part in {"dist", ".cbuild", "build"} for part in pyproject.parts):
                continue

            projects.append(pyproject.parent)

        return projects

    def _pack_project(self, project_dir: Path) -> int:
        """打包单个项目.

        Parameters
        ----------
        project_dir : Path
            项目目录

        Returns
        -------
        int
            打包的字节数
        """
        # 从 pyproject.toml 读取项目名称
        pyproject_file = project_dir / "pyproject.toml"
        project_name = project_dir.name or "root"

        if pyproject_file.exists():
            try:
                content = pyproject_file.read_text(encoding="utf-8")
                data = tomllib.loads(content)
                project_name = data.get("project", {}).get("name", project_name)
            except Exception:
                pass

        source_dir = self.root_dir / ".cbuild" / "src" / project_name
        source_dir.mkdir(parents=True, exist_ok=True)

        logger.info(f"正在打包: {project_name}")

        # 检查是否为 src layout（代码在 src/ 子目录下）
        src_subdir = project_dir / "src"
        if src_subdir.exists() and src_subdir.is_dir():
            # src layout: 复制 src/ 目录下的所有包
            logger.info("检测到 src layout，复制 src/ 目录")
            target_dir = source_dir / "src"
            target_dir.mkdir(parents=True, exist_ok=True)
            self._copy_tree(src_subdir, target_dir)
        else:
            # flat layout: 直接复制项目目录
            self._copy_tree(project_dir, source_dir)

        # 检查并创建入口文件
        self._ensure_entry_file(project_dir, source_dir)

        # 计算打包体积
        total_size = sum(f.stat().st_size for f in source_dir.rglob("*") if f.is_file())
        logger.info(f"已打包: {project_name} ({format_file_size(total_size)})")

        return total_size

    def _copy_tree(self, src: Path, dst: Path) -> None:
        """复制目录树.

        Parameters
        ----------
        src : Path
            源目录
        dst : Path
            目标目录
        """
        # 防止无限递归：检查目标是否是源的子目录
        try:
            dst.relative_to(src)
            # 如果到这里没抛异常，说明 dst 是 src 的子目录，跳过
            logger.warning(f"跳过递归目录: {dst}")
            return
        except ValueError:
            pass  # 正常情况，dst 不是 src 的子目录

        # 也检查是否正在复制到 .cbuild 内部的项目目录（避免重复打包）
        if ".cbuild" in dst.parts:
            # 检查目标是否已经在 .cbuild 中，避免重复复制
            pass

        for item in src.iterdir():
            # 跳过忽略的文件和目录（包括 .cbuild）
            if item.name == ".cbuild" or self._should_ignore(item):
                continue

            src_item = src / item.name
            dst_item = dst / item.name

            if item.is_dir():
                dst_item.mkdir(exist_ok=True)
                self._copy_tree(src_item, dst_item)
            else:
                shutil.copy2(src_item, dst_item)

    def _should_ignore(self, path: Path) -> bool:
        """判断是否应该忽略.

        Parameters
        ----------
        path : Path
            路径

        Returns
        -------
        bool
            是否应该忽略
        """
        import fnmatch

        name = path.name

        # 检查是否匹配忽略模式
        for pattern in _DEFAULT_IGNORE_PATTERNS:
            if fnmatch.fnmatch(name, pattern):
                return True

        return False

    def _ensure_entry_file(self, project_dir: Path, source_dir: Path) -> None:
        """确保存在入口文件.

        如果项目没有 main.py，则从 pyproject.toml 的 scripts 配置生成.

        Parameters
        ----------
        project_dir : Path
            项目目录
        source_dir : Path
            源码目标目录
        """
        try:
            import tomllib  # ty:ignore[unresolved-import]
        except ImportError:
            import tomli as tomllib  # type: ignore[import-not-found, no-redef]

        # 检查是否已有 main.py
        main_file = source_dir / "main.py"
        if main_file.exists():
            logger.info("已存在 main.py，跳过创建")
            return

        # 尝试从 pyproject.toml 读取 scripts 配置
        pyproject_file = project_dir / "pyproject.toml"
        if not pyproject_file.exists():
            logger.warning("未找到 pyproject.toml，无法创建入口文件")
            return

        try:
            content = pyproject_file.read_text(encoding="utf-8")
            data = tomllib.loads(content)
            scripts = data.get("project", {}).get("scripts", {})

            if not scripts:
                logger.info("项目没有定义 scripts，跳过创建入口文件")
                return

            # 使用第一个脚本作为入口
            first_script = next(iter(scripts.values()))
            logger.info(f"从 pyproject.toml 检测到入口: {first_script}")

            # 生成 main.py
            main_content = self._generate_main_from_script(first_script)
            main_file.write_text(main_content, encoding="utf-8")
            logger.info(f"已创建入口文件: {main_file}")

        except Exception as e:
            logger.warning(f"创建入口文件失败: {e}")

    def _generate_main_from_script(self, script_entry: str) -> str:
        """从脚本入口配置生成 main.py.

        Parameters
        ----------
        script_entry : str
            脚本入口配置，如 "bitool.skills.bumpversion:main"

        Returns
        -------
        str
            main.py 的内容
        """
        # 解析模块和函数名
        if ":" in script_entry:
            module_path, func_name = script_entry.rsplit(":", 1)
        else:
            module_path = script_entry
            func_name = "main"

        # 生成代码
        main_code = f'''"""自动生成的入口文件，用于 {module_path}."""

import sys
import os
from pathlib import Path

# 保存脚本所在目录（用于模块路径查找）
# 必须在切换工作目录之前获取并转为绝对路径
base_dir = Path(__file__).parent.resolve()

# 如果当前在 .cbuild 目录下，切换到父目录（项目根目录）
current_dir = Path.cwd()
if current_dir.name == ".cbuild":
    os.chdir(str(current_dir.parent))

# 添加可能的模块路径到 Python 路径
possible_paths = [
    base_dir / "src",  # src layout
    base_dir,  # flat layout
    base_dir.parent / "src",  # sibling src
]

# 如果是子包（如 bitool-pypack），还需要查找兄弟项目的 src
# 例如：.cbuild/src/bitool-pypack/ 需要找到 .cbuild/src/bitool/src/
if base_dir.parent.name == "src":
    # 当前在 .cbuild/src/bitool-pypack/
    # 查找 .cbuild/src/*/src/
    parent_dir = base_dir.parent  # .cbuild/src/
    for sibling in parent_dir.iterdir():
        if sibling.is_dir() and sibling != base_dir:
            sibling_src = sibling / "src"
            if sibling_src.exists():
                possible_paths.append(sibling_src)

for path in possible_paths:
    if path.exists():
        sys.path.insert(0, str(path))

# 添加 lib 目录（依赖库）到 Python 路径
# 注意：必须在 src 路径之后添加，避免 lib 中的包覆盖项目源码
# 查找 .cbuild/lib/ 目录
cbuild_dir = base_dir.parent.parent if base_dir.parent.name == "src" else base_dir.parent
lib_dir = cbuild_dir / "lib"
if lib_dir.exists():
    # 插入到 possible_paths 之后，但在原始 sys.path 之前
    insert_pos = len([p for p in possible_paths if p.exists()])
    sys.path.insert(insert_pos, str(lib_dir))

# 导入并执行主函数
try:
    from {module_path} import {func_name}
    
    if __name__ == "__main__":
        sys.exit({func_name}())
except ImportError as e:
    print(f"错误: 无法导入模块 {module_path}: {{e}}")
    print("请确保模块已正确安装。")
    sys.exit(1)
'''  # noqa: E501

        return main_code
