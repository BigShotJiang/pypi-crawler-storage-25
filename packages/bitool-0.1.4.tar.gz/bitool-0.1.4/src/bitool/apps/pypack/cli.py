"""PyPack CLI 接口."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from bitool.cmd import CommandScheduler
from bitool.core import logger
from bitool.skills._base import BaseSkill

from .config import PyPackConfig
from .workflow import PackageWorkflow, WorkflowConfig

conf = PyPackConfig()


class PyPackSkill(BaseSkill):
    """PyPack 打包技能.

    提供完整的项目打包功能，包括:
    - 项目扫描和管理
    - 嵌入式 Python 下载
    - 依赖库打包
    - 加载器生成
    - 源码打包
    - 多格式归档
    """

    name = "pypack"
    description = "Bitool PyPack - Python项目完整打包工具"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "action",
            nargs="?",
            type=str,
            help="要执行的操作: build(b), clean(c), list(l), run(r), version(v)",
        )
        parser.add_argument(
            "project",
            nargs="?",
            type=str,
            default=None,
            help="项目名称（用于 run 操作）",
        )
        parser.add_argument(
            "extra_args",
            nargs="*",
            default=[],
            help="传递给打包程序的额外参数",
        )
        parser.add_argument(
            "--project", "-p", type=str, default=None, help=argparse.SUPPRESS
        )
        parser.add_argument(
            "--python-version",
            type=str,
            default=conf.DEFAULT_PYTHON_VERSION,
            help=f"Python 版本（默认: {conf.DEFAULT_PYTHON_VERSION}）",
        )
        parser.add_argument(
            "--loader-type",
            type=str,
            choices=conf.LOADER_TYPES,
            default=conf.DEFAULT_LOADER_TYPE,
            help="加载器类型",
        )
        parser.add_argument(
            "--archive",
            "-a",
            type=str,
            choices=conf.ARCHIVE_FORMATS,
            default=None,
            help="归档格式",
        )
        parser.add_argument(
            "--mirror",
            type=str,
            choices=conf.MIRRORS,
            default=conf.DEFAULT_MIRROR,
            help="PyPI 镜像源",
        )
        parser.add_argument("--offline", "-o", action="store_true", help="离线模式")
        parser.add_argument(
            "--jobs",
            "-j",
            type=int,
            default=conf.DEFAULT_MAX_WORKERS,
            help="最大并发任务数",
        )
        parser.add_argument("--debug", "-d", action="store_true", help="调试模式")

    def run(self, args: list[str] | None = None) -> int:
        """运行 PyPack."""
        try:
            parsed_args = self.parse_args(args)

            # 合并位置参数和选项参数
            project_name = parsed_args.project or parsed_args.project

            if not parsed_args.action:
                logger.error("请指定操作类型")
                logger.info("可用操作: build(b), clean(c), list(l), run(r), version(v)")
                return 1

            action = parsed_args.action

            if action in {"build", "b"}:
                success = self._build_project(parsed_args)
            elif action in {"clean", "c"}:
                success = self._clean_project()
            elif action in {"list", "l", "ls"}:
                success = self._list_projects()
            elif action in {"run", "r"}:
                success = self._run_project(parsed_args, project_name)
            elif action in {"version", "v"}:
                success = self._show_version()
            else:
                logger.error(f"无效的操作: {action}")
                return 1

            return 0 if success else 1

        except KeyboardInterrupt:
            logger.info("操作已取消")
            return 130
        except SystemExit:
            raise
        except Exception as e:
            logger.error(f"PyPack 执行失败: {e}")
            return 1

    def _create_workflow(self, args: argparse.Namespace) -> PackageWorkflow:
        """创建工作流实例."""
        config = WorkflowConfig(
            directory=Path.cwd(),
            project_name=args.project,
            python_version=args.python_version,
            loader_type=args.loader_type,
            offline=args.offline,
            max_concurrent=args.jobs,
            debug=args.debug,
            archive_type=args.archive,
        )
        return PackageWorkflow(root_dir=Path.cwd(), config=config)

    def _build_project(self, args: argparse.Namespace) -> bool:
        """构建项目."""
        workflow = self._create_workflow(args)
        import asyncio

        result = asyncio.run(workflow.build())
        return result.get("success", False)

    def _clean_project(self) -> bool:
        """清理项目."""
        workflow = self._create_workflow(
            argparse.Namespace(
                project=None,
                python_version=conf.DEFAULT_PYTHON_VERSION,
                loader_type=conf.DEFAULT_LOADER_TYPE,
                offline=False,
                jobs=conf.DEFAULT_MAX_WORKERS,
                debug=False,
                archive=None,
            )
        )
        workflow.clean_project()
        return True

    def _list_projects(self) -> bool:
        """列出项目."""
        workflow = self._create_workflow(
            argparse.Namespace(
                project=None,
                python_version=conf.DEFAULT_PYTHON_VERSION,
                loader_type=conf.DEFAULT_LOADER_TYPE,
                offline=False,
                jobs=conf.DEFAULT_MAX_WORKERS,
                debug=False,
                archive=None,
            )
        )
        workflow.list_projects()
        return True

    def _run_project(
        self, args: argparse.Namespace, project_name: str | None = None
    ) -> bool:
        """运行项目."""
        # 优先使用位置参数，其次使用选项参数
        name = project_name or args.project
        if not name:
            logger.error("请指定项目名称")
            logger.info("用法: pypack run <project_name> 或 pypack r <project_name>")
            logger.info("")

            # 列出可用项目
            try:
                from .models.solution import Solution

                solution = Solution.from_directory(Path.cwd())
                if solution.projects:
                    logger.info("可用项目:")
                    for proj_name in sorted(solution.projects.keys()):
                        logger.info(f"  - {proj_name}")
                else:
                    logger.info("未找到任何项目，请先运行: pypack build")
            except Exception:
                logger.info("无法获取项目列表")

            return False
        workflow = self._create_workflow(args)
        # 传递额外参数给打包程序
        extra_args = getattr(args, "extra_args", [])
        workflow.run_project(name, args=extra_args if extra_args else None)
        return True

    def _show_version(self) -> bool:
        """显示版本."""
        logger.info("Bitool PyPack v0.1.0")
        logger.info("Python 项目完整打包工具")
        return True

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建命令调度器（兼容抽象方法，实际使用 run 方法）."""
        # 由于我们覆盖了 run 方法，这个方法不会被调用
        # 但必须实现以满足抽象基类要求
        return CommandScheduler(commands=[])


def main() -> None:
    """主函数入口."""
    exit_code = PyPackSkill().run()
    sys.exit(exit_code)
