"""进度显示工具.

提供简单的进度显示功能，无需外部依赖.
"""

from __future__ import annotations

import sys

from bitool.core import logger


class ProgressBar:
    """简单的进度条显示."""

    def __init__(self, total: int, desc: str = "进度", width: int = 40) -> None:
        """初始化进度条.

        Parameters
        ----------
        total : int
            总任务数
        desc : str
            描述文本
        width : int
            进度条宽度
        """
        self.total = total
        self.desc = desc
        self.width = width
        self.current = 0

    def update(self, n: int = 1, message: str = "") -> None:
        """更新进度.

        Parameters
        ----------
        n : int
            完成的数量
        message : str
            额外消息
        """
        self.current += n
        self._display(message)

    def _display(self, message: str = "") -> None:
        """显示进度条."""
        if self.total == 0:
            return

        percentage = self.current / self.total
        filled = int(self.width * percentage)
        bar = "█" * filled + "░" * (self.width - filled)

        # 构建显示文本
        text = f"\r{self.desc}: |{bar}| {self.current}/{self.total} ({percentage:.0%})"
        if message:
            text += f" - {message}"

        # 输出到终端
        sys.stdout.write(text)
        sys.stdout.flush()

        # 完成时换行
        if self.current >= self.total:
            logger.info(f"{self.desc} 完成")

    def close(self) -> None:
        """关闭进度条."""
        if self.current < self.total:
            self.current = self.total
            self._display()


class TaskReporter:
    """任务进度报告器."""

    def __init__(self, total_tasks: int, desc: str = "任务") -> None:
        """初始化报告器.

        Parameters
        ----------
        total_tasks : int
            总任务数
        desc : str
            任务描述
        """
        self.total = total_tasks
        self.desc = desc
        self.current = 0
        self.bar = ProgressBar(total_tasks, desc)

    def start_task(self, task_name: str) -> None:
        """开始任务.

        Parameters
        ----------
        task_name : str
            任务名称
        """
        logger.info(f"[{self.current + 1}/{self.total}] {task_name}")

    def complete_task(self, success: bool = True, message: str = "") -> None:
        """完成任务.

        Parameters
        ----------
        success : bool
            是否成功
        message : str
            额外消息
        """
        self.current += 1
        status = "成功" if success else "失败"
        msg = f"{status}"
        if message:
            msg += f" - {message}"
        self.bar.update(1, msg)

    def finish(self) -> None:
        """完成所有任务."""
        self.bar.close()


def format_file_size(size_bytes: int) -> str:
    """格式化文件大小.

    Parameters
    ----------
    size_bytes : int
        字节数

    Returns
    -------
    str
        格式化后的大小
    """
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"


def format_time(seconds: float) -> str:
    """格式化时间.

    Parameters
    ----------
    seconds : float
        秒数

    Returns
    -------
    str
        格式化后的时间
    """
    if seconds < 1:
        return f"{seconds * 1000:.0f}ms"
    elif seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        minutes = int(seconds // 60)
        secs = seconds % 60
        return f"{minutes}m {secs:.0f}s"
    else:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        return f"{hours}h {minutes}m"
