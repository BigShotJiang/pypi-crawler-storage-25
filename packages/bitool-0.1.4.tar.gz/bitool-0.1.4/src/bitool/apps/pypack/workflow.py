"""PyPack 工作流编排器."""

from __future__ import annotations

import asyncio
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from bitool.core import logger

from .components.archiver import PyArchiver
from .components.embedinstaller import EmbedInstaller
from .components.libpacker import PyLibPacker, PyLibPackerConfig
from .components.loader import PyLoaderGenerator
from .components.sourcepacker import PySourcePacker
from .models.solution import Solution
from .progress import TaskReporter, format_time


@dataclass(frozen=True)
class WorkflowConfig:
    """工作流配置."""

    directory: Path
    project_name: str | None = None
    python_version: str = "3.8.10"
    loader_type: str = "console"
    offline: bool = False
    max_concurrent: int = 4
    debug: bool = False
    archive_type: str | None = None

    @property
    def dist_dir(self) -> Path:
        """获取分发包目录."""
        return self.directory / "dist"

    @property
    def build_dir(self) -> Path:
        """获取构建目录."""
        return self.directory / ".cbuild"


@dataclass(frozen=True)
class PackageWorkflow:
    """打包工作流编排器."""

    root_dir: Path
    config: WorkflowConfig

    @property
    def solution(self) -> Solution:
        """获取解决方案."""
        return Solution.from_directory(self.root_dir)

    async def build(self) -> dict[str, Any]:
        """执行打包工作流."""
        logger.info("正在启动打包工作流...")
        start_time = time.perf_counter()

        try:
            solution = self.solution
            project_count = len(solution.projects)
            logger.info(f"找到 {project_count} 个项目")

            if not solution.projects:
                logger.warning("未找到任何项目")
                return {"success": False, "message": "未找到项目"}

            # 创建进度报告器
            reporter = TaskReporter(4, "打包进度")

            # Phase 1: 下载嵌入式 Python
            reporter.start_task("下载嵌入式 Python")
            await self._pack_embed_python()
            reporter.complete_task(True, "Python 环境就绪")

            # Phase 2: 并行执行打包任务
            reporter.start_task("执行打包任务")
            await asyncio.gather(
                self._pack_loaders(), self._pack_libraries(), self._pack_source()
            )
            reporter.complete_task(True, "所有组件打包完成")

            # Phase 3: 归档（可选）
            if self.config.archive_type:
                reporter.start_task(f"创建 {self.config.archive_type} 归档")
                archiver = PyArchiver(root_dir=self.root_dir)
                if archiver.run(self.config.archive_type):
                    reporter.complete_task(True, "归档创建成功")
                else:
                    reporter.complete_task(False, "归档创建失败")

            # 清理
            reporter.finish()

            elapsed = time.perf_counter() - start_time
            logger.info(f"打包工作流完成，耗时 {format_time(elapsed)}")

            return {
                "success": True,
                "output_dir": str(self.config.dist_dir),
                "elapsed": elapsed,
                "project_count": project_count,
            }

        except Exception as e:
            logger.exception("打包工作流失败")
            return {"success": False, "message": str(e)}

    def clean_project(self) -> None:
        """清理构建产物."""
        logger.info("正在清理构建产物...")

        dirs_to_clean = [
            self.root_dir / ".cbuild",
            self.root_dir / "dist",
            self.root_dir / "build",
        ]

        cleaned = 0
        for dir_path in dirs_to_clean:
            if dir_path.exists():
                try:
                    shutil.rmtree(dir_path)
                    logger.info(f"已清理: {dir_path}")
                    cleaned += 1
                except Exception as e:
                    logger.warning(f"清理失败 {dir_path}: {e}")

        if cleaned == 0:
            logger.info("未找到需要清理的构建产物")
        else:
            logger.info(f"已清理 {cleaned} 个目录")

    def list_projects(self) -> None:
        """列出所有可用项目."""
        logger.info(f"正在列出 {self.root_dir} 中的项目...")

        try:
            solution = self.solution
            if not solution.projects:
                logger.info("未找到任何项目")
                return

            logger.info(f"找到 {len(solution.projects)} 个项目:")
            logger.info("=" * 60)

            for _name, project in sorted(solution.projects.items()):
                logger.info(f"  {project}")
                if project.dependencies:
                    logger.info(f"    依赖: {', '.join(project.dependencies[:5])}")
                    if len(project.dependencies) > 5:
                        logger.info(
                            f"    ... 及其他 {len(project.dependencies) - 5} 个"
                        )

            logger.info("=" * 60)

        except Exception as e:
            logger.error(f"列出项目失败: {e}")

    def run_project(self, project_name: str, args: list[str] | None = None) -> None:
        """运行打包的应用.

        Parameters
        ----------
        project_name : str
            项目名称
        args : list[str] | None
            命令行参数
        """
        # 查找可执行文件
        exe_path = self._find_executable(project_name)

        if exe_path is None:
            logger.error(f"未找到可执行文件: {project_name}")
            logger.info("请先运行构建命令")
            return

        logger.info(f"正在运行: {exe_path}")
        if args:
            logger.info(f"参数: {' '.join(args)}")

        try:
            # 构建命令
            cmd = [str(exe_path)]
            if args:
                cmd.extend(args)

            # 在 .cbuild 目录下执行（打包程序的工作目录）
            # 打包程序会自动检测父目录的项目
            result = subprocess.run(cmd, cwd=str(self.config.build_dir))

            if result.returncode == 0:
                logger.info("程序执行成功")
            else:
                logger.warning(f"程序退出，返回码: {result.returncode}")

        except Exception as exc:
            logger.error(f"运行失败: {exc}")

    def _find_executable(self, project_name: str) -> Path | None:
        """查找可执行文件.

        Parameters
        ----------
        project_name : str
            项目名称

        Returns
        -------
        Path | None
            可执行文件路径，未找到返回 None
        """
        build_dir = self.config.build_dir

        # 可能的可执行文件位置
        candidates = [
            build_dir / f"{project_name}.exe",
            build_dir / project_name / f"{project_name}.exe",
            build_dir / "src" / project_name / f"{project_name}.exe",
        ]

        for path in candidates:
            if path.exists():
                return path

        return None

    async def _pack_embed_python(self) -> None:
        """下载嵌入式 Python."""
        installer = EmbedInstaller(
            root_dir=self.root_dir,
            python_version=self.config.python_version,
            offline=self.config.offline,
        )
        installer.run()

    async def _pack_loaders(self) -> None:
        """生成加载器."""
        logger.info("正在生成加载器...")

        solution = self.solution
        build_dir = self.config.build_dir
        python_exe = build_dir / "python" / "python.exe"

        if not python_exe.exists():
            logger.warning("Python 解释器不存在，跳过加载器生成")
            return

        for project_name in solution.projects:
            # 如果有指定项目名称，只处理该项目
            if self.config.project_name and project_name != self.config.project_name:
                continue

            loader_gen = PyLoaderGenerator(
                root_dir=build_dir,
                project_name=project_name,
                python_exe=python_exe,
                script_name="main.py",
                loader_type=self.config.loader_type,
            )

            if loader_gen.run():
                logger.info(f"项目 {project_name} 加载器生成成功")
            else:
                logger.warning(f"项目 {project_name} 加载器生成失败")

    async def _pack_libraries(self) -> None:
        """打包依赖库."""
        config = PyLibPackerConfig(max_workers=self.config.max_concurrent)
        packer = PyLibPacker(working_dir=self.root_dir, config=config)
        packer.run()

    async def _pack_source(self) -> None:
        """打包源代码."""
        packer = PySourcePacker(root_dir=self.root_dir)
        packer.run()
