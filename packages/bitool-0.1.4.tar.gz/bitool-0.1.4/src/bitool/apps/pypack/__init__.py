"""PyPack 打包工具模块.

将 pypack 的所有功能集成到 bitool skill 系统中,提供:
- 项目扫描和管理
- 嵌入式 Python 下载和安装
- 依赖库打包
- 加载器生成
- 源码打包
- 多格式归档
"""

from bitool.apps.pypack.cli import PyPackSkill

__all__ = ["PyPackSkill"]
