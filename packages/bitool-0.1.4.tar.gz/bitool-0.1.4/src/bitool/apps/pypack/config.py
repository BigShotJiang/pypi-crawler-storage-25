"""PyPack 配置管理."""

from __future__ import annotations

from pathlib import Path

from bitool.core import JsonConfig


class PyPackConfig(JsonConfig):
    """PyPack 配置类.

    管理打包工具的配置选项.
    """

    # Python 版本
    DEFAULT_PYTHON_VERSION = "3.8.10"

    # 加载器类型
    LOADER_TYPES = ["console", "gui"]  # noqa: RUF012
    DEFAULT_LOADER_TYPE = "console"

    # 归档格式
    ARCHIVE_FORMATS = ["zip", "tar", "gztar", "bztar", "xztar", "7z", "nsis"]  # noqa: RUF012

    # 镜像源
    MIRRORS = ["pypi", "tsinghua", "aliyun", "ustc", "douban", "tencent"]  # noqa: RUF012
    DEFAULT_MIRROR = "aliyun"

    # 并发
    DEFAULT_MAX_WORKERS = 4

    # 缓存目录
    CACHE_DIR = Path.home() / ".bitool" / "pypack" / "cache"

    # 构建目录
    BUILD_DIR_NAME = ".cbuild"
    DIST_DIR_NAME = "dist"

    # 超时
    BUILD_TIMEOUT = 3600  # 1小时
    DOWNLOAD_TIMEOUT = 300  # 5分钟

    # 入口文件后缀
    DEFAULT_ENTRY_SUFFIX = ".ent"
