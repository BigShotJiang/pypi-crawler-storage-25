"""依赖项模型."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Dependency:
    """表示一个项目依赖项.

    Attributes
    ----------
    name : str
        依赖项名称
    version : str | None
        版本号约束
    extras : list[str]
        可选的额外依赖
    """

    name: str
    version: str | None = None
    extras: list[str] | None = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        """初始化后处理."""
        if self.extras is None:
            object.__setattr__(self, "extras", [])

    def __str__(self) -> str:
        """返回依赖项的字符串表示."""
        if self.version:
            return f"{self.name}{self.version}"
        return self.name

    def to_dict(self) -> dict[str, Any]:
        """转换为字典.

        Returns
        -------
        dict[str, Any]
            依赖项的字典表示
        """
        return {"name": self.name, "version": self.version, "extras": self.extras}

    @classmethod
    def from_string(cls, dep_str: str) -> Dependency:
        """从字符串创建依赖项.

        Parameters
        ----------
        dep_str : str
            依赖项字符串,如 "requests>=2.28.0"

        Returns
        -------
        Dependency
            依赖项实例
        """
        import re

        # 匹配包名和版本约束
        match = re.match(r"^([a-zA-Z0-9_.-]+)\s*(.*)?$", dep_str.strip())
        if not match:
            return cls(name=dep_str.strip())

        name = match.group(1)
        version = match.group(2).strip() if match.group(2) else None
        return cls(name=name, version=version)
