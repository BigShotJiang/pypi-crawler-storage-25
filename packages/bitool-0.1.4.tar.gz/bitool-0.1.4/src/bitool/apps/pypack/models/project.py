"""项目模型."""

from __future__ import annotations

import platform
import re
from dataclasses import dataclass, field
from functools import cached_property
from pathlib import Path
from re import Pattern
from typing import Any, Final

from bitool.core import logger

from .entryfile import EntryFile

IS_WINDOWS = platform.system() == "Windows"
_DEP_NAME_PATTERN: Final[Pattern[str]] = re.compile(r"^([a-zA-Z0-9._-]+)")


@dataclass(frozen=True)
class Project:
    """表示一个 Python 项目.

    从 pyproject.toml 解析项目信息.

    Attributes
    ----------
    name : str
        项目名称
    version : str
        项目版本
    description : str
        项目描述
    project_dir : Path
        项目目录
    pyproject_file : Path
        pyproject.toml 文件路径
    dependencies : list[str]
        依赖项列表
    """

    name: str
    version: str
    description: str
    project_dir: Path
    pyproject_file: Path
    dependencies: list[str] = field(default_factory=list)

    def __repr__(self) -> str:
        """返回项目的字符串表示."""
        return f"<Project({self.name}=={self.version}, {len(self.dependencies)} deps)>"

    def __str__(self) -> str:
        """返回项目的简洁字符串表示."""
        return f"{self.name}=={self.version} - {self.description or 'No description'}"

    @cached_property
    def is_gui_project(self) -> bool:
        """判断是否为 GUI 项目.

        Returns
        -------
        bool
            如果是 GUI 项目返回 True
        """
        gui_keywords = {"gui", "desktop", "qt", "pyside", "pyqt"}
        deps_lower = [d.lower() for d in self.dependencies]
        return any(kw in " ".join(deps_lower) for kw in gui_keywords)

    def get_project_info(self) -> dict[str, Any]:
        """获取项目详细信息.

        Returns
        -------
        dict[str, Any]
            项目信息字典
        """
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "project_dir": str(self.project_dir),
            "dependencies": self.dependencies,
            "is_gui": self.is_gui_project,
        }


def is_entry_file(file_path: Path) -> bool:
    """判断 Python 文件是否为入口文件.

    入口文件必须包含:
    - def main() 函数
    - 或 if __name__ == '__main__': 块

    Parameters
    ----------
    file_path : Path
        Python 文件路径

    Returns
    -------
    bool
        如果是入口文件返回 True
    """
    if not file_path.is_file() or file_path.suffix != ".py":
        return False

    try:
        content = file_path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return False
    else:
        return (
            "def main(" in content
            or "if __name__ == '__main__':" in content
            or 'if __name__ == "__main__":' in content
        )


def detect_entry_files(
    project_dir: Path, project_name: str, project_root: Path | None = None
) -> list[EntryFile]:
    """检测项目目录中的所有入口文件.

    Parameters
    ----------
    project_dir : Path
        要扫描的目录
    project_name : str
        项目名称
    project_root : Path | None
        项目根目录

    Returns
    -------
    list[EntryFile]
        检测到的入口文件列表
    """
    entry_files: list[EntryFile] = []
    normalized_name = project_name.lower().replace("-", "_")

    for py_file in project_dir.glob("*.py"):
        if is_entry_file(py_file):
            entry_file = EntryFile(
                project_name=normalized_name,
                source_file=py_file,
                project_root=project_root,
            )
            entry_files.append(entry_file)
            logger.debug(f"Found entry file: {entry_file}")

    return entry_files
