"""解决方案模型 - 管理多个项目."""

from __future__ import annotations

import datetime
import time
from dataclasses import dataclass, field
from functools import cached_property
from pathlib import Path
from typing import Final

from bitool.core import logger

from .project import Project

# 默认排除的目录模式
_DEFAULT_EXCLUDE_PATTERNS: Final[frozenset[str]] = frozenset(
    (
        "dist",
        ".cbuild",
        "build",
        "__pycache__",
        ".git",
        ".pytest_cache",
        ".benchmarks",
        "node_modules",
        ".idea",
    )
)


@dataclass(frozen=True)
class Solution:
    """表示目录中的一组 Python 项目.

    Attributes
    ----------
    root_dir : Path
        根目录
    projects : dict[str, Project]
        项目字典
    """

    root_dir: Path
    projects: dict[str, Project]
    start_time: float = field(default_factory=time.perf_counter)
    time_stamp: datetime.datetime = field(default_factory=datetime.datetime.now)

    def __repr__(self) -> str:
        """返回解决方案的字符串表示."""
        return (
            f"<Solution(\n"
            f"  root_dir={self.root_dir!r},\n"
            f"  projects: {len(self.projects)},\n"
            f"  time_used={self.elapsed_time:.4f}s\n"
            f")>"
        )

    @cached_property
    def elapsed_time(self) -> float:
        """计算耗时.

        Returns
        -------
        float
            耗时（秒）
        """
        return time.perf_counter() - self.start_time

    @cached_property
    def dependencies(self) -> set[str]:
        """获取所有项目的依赖项.

        Returns
        -------
        set[str]
            依赖项集合
        """
        return {
            dep for project in self.projects.values() for dep in project.dependencies
        }

    @classmethod
    def from_directory(cls, root_dir: Path) -> Solution:
        """从目录扫描创建 Solution.

        Parameters
        ----------
        root_dir : Path
            根目录

        Returns
        -------
        Solution
            Solution 实例
        """
        projects = cls._scan_projects(root_dir)
        return cls(root_dir=root_dir, projects=projects)

    @classmethod
    def _scan_projects(cls, root_dir: Path) -> dict[str, Project]:
        """扫描目录中的项目.

        Parameters
        ----------
        root_dir : Path
            根目录

        Returns
        -------
        dict[str, Project]
            项目字典
        """
        projects: dict[str, Project] = {}

        for pyproject_file in root_dir.rglob("pyproject.toml"):
            # 跳过排除的目录
            if any(part in _DEFAULT_EXCLUDE_PATTERNS for part in pyproject_file.parts):
                continue

            try:
                project = cls._parse_pyproject(pyproject_file)
                if project:
                    projects[project.name] = project
            except Exception as e:
                logger.warning(f"Failed to parse {pyproject_file}: {e}")

        return projects

    @classmethod
    def _parse_pyproject(cls, pyproject_file: Path) -> Project | None:
        """解析 pyproject.toml 文件.

        Parameters
        ----------
        pyproject_file : Path
            pyproject.toml 文件路径

        Returns
        -------
        Project | None
            Project 实例或 None
        """
        import tomli as tomllib

        try:
            content = pyproject_file.read_text(encoding="utf-8")
            data = tomllib.loads(content)
        except Exception as e:
            logger.warning(f"Failed to read {pyproject_file}: {e}")
            return None

        project_data = data.get("project", {})
        name = project_data.get("name")
        version = project_data.get("version", "0.0.0")
        description = project_data.get("description", "")
        dependencies = project_data.get("dependencies", [])

        if not name:
            return None

        return Project(
            name=name,
            version=version,
            description=description,
            project_dir=pyproject_file.parent,
            pyproject_file=pyproject_file,
            dependencies=dependencies,
        )

    def find_matching_projects(self, pattern: str) -> list[str]:
        """查找匹配的项目.

        Parameters
        ----------
        pattern : str
            匹配模式

        Returns
        -------
        list[str]
            匹配的项目名称列表
        """
        if not pattern:
            return []

        lower_pattern = pattern.lower()
        return [name for name in self.projects if lower_pattern in name.lower()]

    def resolve_project_name(self, project_name: str | None) -> str | None:
        """解析项目名称.

        Parameters
        ----------
        project_name : str | None
            项目名称

        Returns
        -------
        str | None
            解析后的项目名称
        """
        if not project_name:
            # 如果只有一个项目，自动选择
            if len(self.projects) == 1:
                return next(iter(self.projects))
            return None

        # 精确匹配
        if project_name in self.projects:
            return project_name

        # 模糊匹配
        matches = self.find_matching_projects(project_name)
        if len(matches) == 1:
            return matches[0]

        return None
