"""入口文件模型."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class EntryFile:
    """表示一个 Python 入口文件.

    Attributes
    ----------
    project_name : str
        项目名称
    source_file : Path
        源文件路径
    project_root : Path | None
        项目根目录
    """

    project_name: str
    source_file: Path
    project_root: Path | None = None

    @property
    def relative_path(self) -> Path | str:
        """获取相对于项目根目录的路径.

        Returns
        -------
        Path | str
            相对路径或者文件名
        """
        if self.project_root:
            return self.source_file.relative_to(self.project_root)

        return self.source_file.name

    @property
    def output_stem(self) -> str:
        """获取输出文件名（不含扩展名）.

        Returns
        -------
        str
            输出文件名
        """
        return self.source_file.stem

    def to_dict(self) -> dict[str, Any]:
        """转换为字典.

        Returns
        -------
        dict[str, Any]
            入口文件的字典表示
        """
        return {
            "project_name": self.project_name,
            "source_file": str(self.source_file),
            "output_stem": self.output_stem,
        }

    def __str__(self) -> str:
        """返回入口文件的字符串表示."""
        return f"{self.project_name}:{self.source_file.name}"
