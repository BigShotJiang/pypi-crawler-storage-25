"""Git 工具模块.

提供 Git 仓库管理的常用操作封装,
支持初始化、提交、清理、推送等功能.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path

from bitool.cmd import CommandScheduler, RunCommand
from bitool.core import JsonConfig
from bitool.skills._registry import MultiCommandSkill
from bitool.utils import execute


class GitToolConfig(JsonConfig):
    """Git工具配置类."""

    CACHE_DIRS_FOR_CLEAN: list[str] = [  # noqa: RUF012
        ".coverage",
        ".benchmarks",
        ".ruff_cache",
        ".pytest_cache",
        ".mypy_cache",
        "__pycache__",
        ".hypothesis",
        "htmlcov",
    ]

    EXCLUDE_DIRS_FOR_CLEAN: list[str] = [  # noqa: RUF012
        ".venv",
        "node_modules",
        ".git",
        ".idea",
        ".vscode",
    ]


conf = GitToolConfig()


class GitToolSkill(MultiCommandSkill):
    """Git 工具技能."""

    name = "gittool"
    description = "Git仓库管理的常用操作"
    config = conf

    def __init__(self) -> None:
        """初始化Git工具, 注册所有子命令."""
        super().__init__()

        self.register("a", self._add_commit, "添加并提交所有更改")
        self.register("c", self._clean_status, "清理工作区并显示状态")
        self.register("i", self._init_add_commit, "初始化、添加并提交")
        self.register("isub", self._init_subdirs, "初始化子目录的Git仓库")
        self.register("p", self._push, "推送更改到远程仓库")
        self.register("pl", self._pull, "从远程仓库拉取最新更改")
        self.register("re", self._restart_tgitcache, "重启tgitcache服务")

    def _add_commit(self) -> CommandScheduler:
        """添加并提交所有更改."""
        return CommandScheduler(
            commands=[
                RunCommand(
                    name="add",
                    cmd=["git", "add", "."],
                    description="将所有更改添加到暂存区",
                ),
                RunCommand(
                    name="commit",
                    cmd=["git", "commit", "-m", "chore: update"],
                    description="提交所有更改",
                ),
            ]
        )

    def _clean_status(self) -> CommandScheduler:
        """清理工作区并显示状态."""
        return CommandScheduler(
            commands=[
                RunCommand(
                    name="clean",
                    cmd=["git", "clean", "-xfd"]
                    + [arg for d in conf.EXCLUDE_DIRS_FOR_CLEAN for arg in ["-e", d]],
                    description="清理工作区",
                ),
                RunCommand(
                    name="status",
                    cmd=["git", "status", "--porcelain"],
                    description="显示状态",
                ),
            ]
        )

    def _init_add_commit(self) -> CommandScheduler:
        """初始化、添加并提交."""
        return CommandScheduler(
            commands=[
                RunCommand(
                    name="init",
                    cmd=["git", "init"],
                    description="初始化Git仓库",
                    forbid_conditions=[
                        (
                            lambda: (
                                ".git"
                                in [d.name for d in Path.cwd().iterdir() if d.is_dir()]
                            ),
                            "Git仓库已初始化",
                        )
                    ],
                ),
                RunCommand(
                    name="add",
                    cmd=["git", "add", "."],
                    description="将所有更改添加到暂存区",
                    forbid_conditions=[
                        (lambda: not Path.cwd().glob("*"), "没有文件可添加")
                    ],
                ),
                RunCommand(
                    name="commit",
                    cmd=["git", "commit", "-m", "chore: update"],
                    description="提交所有更改",
                    forbid_conditions=[
                        (lambda: not Path.cwd().glob("*"), "没有文件可提交")
                    ],
                ),
            ]
        )

    def _init_subdirs(self) -> CommandScheduler:
        """初始化子目录的Git仓库."""

        def func() -> None:
            """初始化子目录的Git仓库."""
            origin = Path.cwd()
            subdirs = [d for d in Path.cwd().iterdir() if d.is_dir()]
            for subdir in subdirs:
                os.chdir(str(subdir))
                execute(
                    [
                        ["git", "init"],
                        ["git", "add", "."],
                        ["git", "commit", "-m", "init commit"],
                    ]
                )
            os.chdir(str(origin))

        return CommandScheduler(commands=[RunCommand(cmd=func)])

    def _push(self) -> CommandScheduler:
        """推送更改到远程仓库."""
        return CommandScheduler(
            commands=[
                RunCommand(
                    name="push", cmd=["git", "push"], description="推送更改到远程仓库"
                )
            ]
        )

    def _pull(self) -> CommandScheduler:
        """从远程仓库拉取最新更改."""
        return CommandScheduler(
            commands=[
                RunCommand(
                    name="pull",
                    cmd=["git", "pull"],
                    description="从远程仓库拉取最新更改",
                )
            ]
        )

    def _restart_tgitcache(self) -> CommandScheduler:
        """重启tgitcache服务."""
        return CommandScheduler(
            commands=[
                RunCommand(
                    name="重启tgitcache",
                    cmd=["taskkill", "/f", "/t", "/im", "tgitcache.exe"],
                    description="重启tgitcache服务(如果正在运行)",
                )
            ]
        )


def main() -> None:
    """Git工具主函数."""

    tool = GitToolSkill()
    parser = argparse.ArgumentParser(description="Git工具")
    parser.add_argument("action", choices=tool.list_commands(), help="要执行的操作")
    args = parser.parse_args()

    scheduler: CommandScheduler | None = tool.get_scheduler(args.action)
    if not scheduler:
        raise ValueError(f"无效的操作: {args.action}")

    scheduler.run()
