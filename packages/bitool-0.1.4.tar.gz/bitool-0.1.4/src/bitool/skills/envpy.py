"""Python 环境配置工具.

用于设置 pip 镜像源, 支持清华和阿里云等国内镜像源,
同时配置 UV 和 Conda 的镜像源.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from bitool.cmd import CommandScheduler, SetEnvCommand, WriteFileCommand
from bitool.consts import Constants
from bitool.core import JsonConfig
from bitool.skills._base import BaseSkill


class EnvPyConfig(JsonConfig):
    """Python环境配置类。"""

    # pip 镜像源配置
    PIP_DEFAULT_INDEX_URL: str = "https://pypi.org/simple"
    PIP_INDEX_URLS: dict[str, str] = {  # noqa: RUF012
        "tsinghua": "https://pypi.tuna.tsinghua.edu.cn/simple",
        "aliyun": "https://mirrors.aliyun.com/pypi/simple/",
    }
    PIP_TRUSTED_HOSTS: dict[str, str] = {  # noqa: RUF012
        "tsinghua": "pypi.tuna.tsinghua.edu.cn",
        "aliyun": "mirrors.aliyun.com",
    }

    # UV相关配置
    UV_INDEX_URL: str = "https://mirrors.aliyun.com/pypi/simple/"
    UV_DEFAULT_INDEX: str = "https://mirrors.aliyun.com/pypi/simple/"
    UV_HTTP_TIMEOUT: int = 600
    UV_LINK_MODE: str = "copy"

    # Conda相关配置
    CONDA_DEFAULT_MIRROR: str = "tsinghua"
    _CONDA_MIRROR_URLS: dict[str, list[str]] = {  # noqa: RUF012
        "tsinghua": [
            "https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/main/",
            "https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/free/",
            "https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/r/",
            "https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/msys2/",
            "https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/pro/",
            "https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/conda-forge/",
            "https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/bioconda/",
            "https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/menpo/",
            "https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/pytorch/",
        ],
        "ustc": [
            "https://mirrors.ustc.edu.cn/anaconda/pkgs/main/",
            "https://mirrors.ustc.edu.cn/anaconda/pkgs/free/",
            "https://mirrors.ustc.edu.cn/anaconda/pkgs/r/",
            "https://mirrors.ustc.edu.cn/anaconda/pkgs/msys2/",
            "https://mirrors.ustc.edu.cn/anaconda/pkgs/pro/",
            "https://mirrors.ustc.edu.cn/anaconda/pkgs/dev/",
            "https://mirrors.ustc.edu.cn/anaconda/cloud/conda-forge/",
            "https://mirrors.ustc.edu.cn/anaconda/cloud/bioconda/",
            "https://mirrors.ustc.edu.cn/anaconda/cloud/menpo/",
            "https://mirrors.ustc.edu.cn/anaconda/cloud/pytorch/",
        ],
        "bsfu": [
            "https://mirrors.bsfu.edu.cn/anaconda/pkgs/main/",
            "https://mirrors.bsfu.edu.cn/anaconda/pkgs/free/",
            "https://mirrors.bsfu.edu.cn/anaconda/pkgs/r/",
            "https://mirrors.bsfu.edu.cn/anaconda/pkgs/msys2/",
            "https://mirrors.bsfu.edu.cn/anaconda/pkgs/pro/",
            "https://mirrors.bsfu.edu.cn/anaconda/pkgs/dev/",
            "https://mirrors.bsfu.edu.cn/anaconda/cloud/conda-forge/",
            "https://mirrors.bsfu.edu.cn/anaconda/cloud/bioconda/",
            "https://mirrors.bsfu.edu.cn/anaconda/cloud/menpo/",
            "https://mirrors.bsfu.edu.cn/anaconda/cloud/pytorch/",
        ],
        "aliyun": [
            "https://mirrors.aliyun.com/anaconda/pkgs/main/",
            "https://mirrors.aliyun.com/anaconda/pkgs/free/",
            "https://mirrors.aliyun.com/anaconda/pkgs/r/",
            "https://mirrors.aliyun.com/anaconda/pkgs/msys2/",
            "https://mirrors.aliyun.com/anaconda/pkgs/pro/",
            "https://mirrors.aliyun.com/anaconda/pkgs/dev/",
            "https://mirrors.aliyun.com/anaconda/cloud/conda-forge/",
            "https://mirrors.aliyun.com/anaconda/cloud/bioconda/",
            "https://mirrors.aliyun.com/anaconda/cloud/menpo/",
            "https://mirrors.aliyun.com/anaconda/cloud/pytorch/",
        ],
    }


conf = EnvPyConfig()


class EnvPySkill(BaseSkill):
    """Python 环境配置技能。"""

    name = "envpy"
    description = "设置Python包的pip镜像源"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数。"""
        parser.add_argument(
            "mirror",
            type=str,
            nargs="?",
            default="tsinghua",
            choices=conf.PIP_INDEX_URLS.keys(),
            help="要使用的pip镜像源",
        )
        parser.add_argument(
            "--token", type=str, nargs="?", help="PyPI token for publishing"
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建环境配置调度器。"""
        return CommandScheduler(
            commands=[
                SetEnvCommand(
                    envs=[
                        (
                            "PIP_INDEX_URL",
                            conf.PIP_INDEX_URLS.get(
                                args.mirror, conf.PIP_DEFAULT_INDEX_URL
                            ),
                        ),
                        ("UV_INDEX_URL", conf.UV_INDEX_URL),
                        ("UV_DEFAULT_INDEX", conf.UV_DEFAULT_INDEX),
                        ("UV_HTTP_TIMEOUT", str(conf.UV_HTTP_TIMEOUT)),
                        ("UV_LINK_MODE", conf.UV_LINK_MODE),
                    ]
                ),
                WriteFileCommand(
                    filepath=Path.home() / ".pip" / "pip.conf"
                    if Constants.IS_UNIX
                    else Path.home() / "pip" / "pip.ini",
                    content=f"[global]\nindex-url = {conf.PIP_INDEX_URLS.get(args.mirror, conf.PIP_DEFAULT_INDEX_URL)}\
                        \n[install]\ntrusted-host = {conf.PIP_TRUSTED_HOSTS.get(args.mirror, '')}",
                ),
                WriteFileCommand(
                    filepath=Path.home() / ".condarc",
                    content="show_channel_urls: true\nchannels:\n"
                    + "\n".join(
                        f"  - {url}"
                        for url in conf._CONDA_MIRROR_URLS.get(
                            args.mirror, conf._CONDA_MIRROR_URLS["tsinghua"]
                        )
                    )
                    + "\n  - defaults",
                ),
                WriteFileCommand(
                    filepath=Path.home() / ".pypirc",
                    content=f"""[pypi]
repository: https://upload.pypi.org/legacy/
username: __token__
password: {args.token if args.token else ""}
""",
                    allow_conditions=[(lambda: bool(args.token), "有效的token")],
                ),
            ]
        )


def main() -> None:
    """主函数, 解析命令行参数并运行调度器。"""
    EnvPySkill().run_cli()
