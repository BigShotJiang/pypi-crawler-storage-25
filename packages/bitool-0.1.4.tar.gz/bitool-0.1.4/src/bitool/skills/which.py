"""查找命令的可执行路径.

支持 Windows 和 Unix 系统的命令查找,
提供模糊匹配和内置命令检测功能.
"""

from __future__ import annotations

import argparse
import re
import sys
from dataclasses import dataclass

from bitool.cmd import CommandScheduler, RunCommand
from bitool.consts import Constants
from bitool.core import logger
from bitool.skills._base import BaseSkill

IS_WINDOWS = Constants.IS_WINDOWS

# 命令名称验证正则表达式: 只允许字母, 数字, 连字符, 下划线和点号
COMMAND_PATTERN = re.compile(r"^[a-zA-Z0-9_\-\.]+$")
WINDOWS_BUILTINS: set[str] = {
    "assoc",
    "attrib",
    "break",
    "bcdedit",
    "cacls",
    "call",
    "cd",
    "chcp",
    "chdir",
    "chkdsk",
    "chkntfs",
    "cls",
    "cmd",
    "color",
    "comp",
    "compact",
    "convert",
    "copy",
    "date",
    "del",
    "dir",
    "diskpart",
    "doskey",
    "driverquery",
    "echo",
    "endlocal",
    "erase",
    "exit",
    "fc",
    "find",
    "findstr",
    "for",
    "format",
    "fsutil",
    "ftype",
    "goto",
    "gpresult",
    "help",
    "icacls",
    "if",
    "label",
    "md",
    "mkdir",
    "mklink",
    "mode",
    "more",
    "move",
    "openfiles",
    "path",
    "pause",
    "popd",
    "print",
    "prompt",
    "pushd",
    "rd",
    "recover",
    "rem",
    "ren",
    "rename",
    "replace",
    "rmdir",
    "robocopy",
    "set",
    "setlocal",
    "sc",
    "schtasks",
    "shift",
    "shutdown",
    "sort",
    "start",
    "subst",
    "systeminfo",
    "tasklist",
    "taskkill",
    "time",
    "title",
    "tree",
    "type",
    "ver",
    "verify",
    "vol",
    "xcopy",
    "wmic",
}


@dataclass
class FindResult:
    """查找可执行结果的数据类."""

    name: str
    path: list[str] | str | None

    def __str__(self) -> str:
        """返回格式化的查找结果字符串."""
        if self.path:
            return f"[找到] {self.name} -> {self.path}"
        return f"[未找到] {self.name} -> 未找到"


class WhichSkill(BaseSkill):
    """Which 技能实现."""

    name = "which"
    description = "查找命令的可执行路径"

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加 which 命令参数."""
        parser.add_argument("commands", type=str, nargs="+", help="要查询的命令")
        parser.add_argument("-f", "--fuzzy", action="store_true", help="启用模糊匹配")

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建命令查找调度器."""
        # 过滤空字符串命令
        commands = [cmd for cmd in args.commands if cmd.strip()]

        if not commands:
            logger.error("未提供有效的命令名称")
            sys.exit(1)

        # 检查内置命令并给出提示
        builtin_cmds = [cmd for cmd in commands if cmd.lower() in WINDOWS_BUILTINS]
        if builtin_cmds:
            logger.warning(
                f"以下命令是 Windows 内置命令, "
                f"可能没有独立的可执行文件: {', '.join(builtin_cmds)}"
            )

        return CommandScheduler(
            commands=[
                RunCommand(
                    cmd=[
                        "where" if IS_WINDOWS else "which",
                        name if not args.fuzzy else f"*{name}*{Constants.EXTENSION}",
                    ],
                    allow_conditions=[
                        (
                            lambda n=name: COMMAND_PATTERN.match(n) is not None,
                            "命令名称格式合理",
                        )
                    ],
                )
                for name in commands
            ]
        )


def main() -> None:
    """主函数入口."""
    skill = WhichSkill()
    skill.run_cli()
