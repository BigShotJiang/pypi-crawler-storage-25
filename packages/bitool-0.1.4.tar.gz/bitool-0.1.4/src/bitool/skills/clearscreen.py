"""跨平台控制台清屏工具.

支持 Windows 和 Unix 系统的控制台清屏操作,
自动检测平台并执行对应的清屏命令.
"""

from __future__ import annotations

import argparse
import sys

from bitool.cmd import BuiltinConditions, CommandScheduler, RunCommand
from bitool.consts import Constants
from bitool.core import JsonConfig
from bitool.skills._base import BaseSkill


class ClearScreenSkill(BaseSkill):
    """清屏技能实现.

    根据操作系统平台自动选择清屏命令:
    - Windows: cls
    - Unix/Linux/macOS: clear
    """

    name = "clearscreen"
    description = "跨平台控制台清屏工具"
    config = JsonConfig()

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数.

        清屏工具不需要额外参数, 直接返回.

        Parameters
        ----------
        parser : argparse.ArgumentParser
            参数解析器实例
        """
        pass

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建清屏命令调度器.

        Parameters
        ----------
        args : argparse.Namespace
            解析后的命令行参数 (未使用)

        Returns
        -------
        CommandScheduler
            配置好的清屏命令调度器
        """
        return CommandScheduler(
            commands=[
                RunCommand(
                    cmd=["cls" if Constants.IS_WINDOWS else "clear"],
                    allow_conditions=[BuiltinConditions.IS_WINDOWS],
                ),
                RunCommand(cmd=self.reset_cursor),
            ]
        )

    @staticmethod
    def reset_cursor() -> None:
        """将光标重置到控制台的起始位置.

        使用 ANSI 转义序列 \033[H 将光标移动到屏幕左上角.
        """
        sys.stdout.write("\033[H")
        sys.stdout.flush()


def main() -> None:
    """主函数入口.

    创建清屏技能实例并运行.
    """
    skill = ClearScreenSkill()
    skill.run_cli()
