"""跨平台进程终止工具.

支持 Windows 和 Unix 系统的进程查找和终止操作,
提供进程名匹配和批量终止功能.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import fnmatch
import logging
import platform
import sys
import time
from dataclasses import dataclass, field
from functools import cached_property
from typing import Final

from bitool.cmd import CommandScheduler
from bitool.skills._base import BaseSkill
from bitool.utils import execute

logging.basicConfig(level=logging.INFO, format="%(message)s", force=True)
logger = logging.getLogger(__name__)

IS_WINDOWS = platform.system() == "Windows"

# 常量
DEFAULT_MATCH_THRESHOLD: Final[int] = 10
FORCE_MATCH_THRESHOLD: Final[int] = 1000
PROCESS_LIST_TIMEOUT: Final[int] = 15
ENCODING_ATTEMPTS: Final[tuple[str, ...]] = ("gbk", "utf8")

# 基准测试常量
BENCHMARK_LARGE_PROCESS_COUNT: Final[int] = 1000
BENCHMARK_MEDIUM_PROCESS_COUNT: Final[int] = 200
TEST_EXPECTED_MATCHES_TWO: Final[int] = 2
TEST_EXPECTED_CALL_COUNT_TWO: Final[int] = 2
CACHE_TIMEOUT: Final[int] = 5


@dataclass
class ProcessInfo:
    """表示系统进程信息.

    Attributes
    ----------
    name : str
        进程可执行文件名称
    pid : str
        进程标识符字符串
    """

    name: str
    pid: str

    def __hash__(self) -> int:
        """生成 ProcessInfo 对象的哈希值.

        Returns
        -------
        int
            基于进程名称和 PID 的哈希值
        """
        return hash((self.name, self.pid))


@dataclass
class TaskkillCommand:
    """表示用于终止系统进程的命令.

    Attributes
    ----------
    processes : list[ProcessInfo]
        表示当前系统进程的 ProcessInfo 对象列表
    force : bool
        是否绕过进程终止的安全阈值
    """

    processes: list[ProcessInfo] = field(default_factory=list)
    force: bool = False

    # 添加进程列表缓存
    _process_cache = None
    _cache_timestamp = 0

    def kill(self, process_name: str) -> bool:
        """终止匹配给定名称或模式的进程.

        Parameters
        ----------
        process_name : str
            用于匹配进程名称的模式

        Returns
        -------
        bool
            如果所有匹配的进程都成功终止则返回 True,
            如果部分或全部终止失败则返回 False

        Notes
        -----
        执行不区分大小写的通配符匹配。默认情况下,如果没有显式通配符,
        则通过自动添加 * 前缀和后缀进行模糊匹配.
        """
        logger.info("正在终止匹配 '%s' 的进程", process_name)
        matched_processes = self.match(process_name)

        if not matched_processes:
            logger.warning("未找到匹配 '%s' 的进程", process_name)
            return False

        match_count = len(matched_processes)
        if match_count > self.match_threshold:
            logger.warning(
                "找到 %d 个匹配 '%s' 的进程 (超过阈值 %d)",
                match_count,
                process_name,
                self.match_threshold,
            )
            logger.warning("进程名称:")
            for i, p in enumerate(matched_processes, 1):
                logger.warning("  %d. %s (PID: %s)", i, p.name, p.pid)
            logger.warning("使用更具体的进程名称以避免意外终止")
            return False

        logger.info(
            "找到 %d 个匹配 '%s' 的进程:%s",
            match_count,
            process_name,
            [m.name for m in matched_processes],
        )

        success_count = 0
        failure_count = 0

        for process in matched_processes:
            if self.kill_by_pid(process.pid):
                logger.info("成功终止进程 %s (PID: %s)", process.name, process.pid)
                success_count += 1
            else:
                logger.info("终止进程 %s (PID: %s) 失败", process.name, process.pid)
                failure_count += 1

        logger.info("成功终止 %d 个匹配 '%s' 的进程", success_count, process_name)
        if failure_count > 0:
            logger.warning("终止 %d 个进程失败", failure_count)
            return False
        return True

    def kill_by_pid(self, pid: str) -> bool:
        """终止给定 PID 的进程.

        Args:
            pid: 要终止的进程的 PID

        Returns
        -------
            bool: 如果成功终止进程则返回 True, 否则返回 False
        """
        # 验证 PID 是否为纯数字以防止命令注入
        if not pid.isdigit():
            logger.error("无效的 PID: %s", pid)
            return False

        if IS_WINDOWS:
            return self._kill_by_pid_windows(pid)
        return self._kill_by_pid_unix(pid)

    def match(self, process_name: str) -> list[ProcessInfo]:
        """使进程与给定模式匹配.

        对进程名称执行不区分大小写的通配符匹配.
        默认情况下,如果输入中不存在显式通配符 (*, ?, [, ]),
        则通过添加 * 前缀和后缀进行模糊匹配.

        Parameters
        ----------
        process_name : str
            用于匹配进程名称的模式

        Returns
        -------
        list[ProcessInfo]
            匹配模式的 ProcessInfo 对象列表
        """
        if not any(char in process_name for char in ["*", "?", "[", "]"]):
            pattern = f"*{process_name}*".lower()
        else:
            pattern = process_name.lower()
        return [p for p in self.processes if fnmatch.fnmatch(p.name.lower(), pattern)]

    @cached_property
    def match_threshold(self) -> int:
        """获取进程匹配的匹配阈值.

        Returns
        -------
        int
            匹配阈值,如果设置了 force 标志则更高
        """
        return FORCE_MATCH_THRESHOLD if self.force else DEFAULT_MATCH_THRESHOLD

    def __post_init__(self) -> None:
        """基于操作系统初始化进程列表."""
        current_time = time.time()

        # 检查缓存是否有效
        if (
            self._process_cache is not None
            and current_time - self._cache_timestamp < CACHE_TIMEOUT
        ):
            self.processes.extend(self._process_cache)
            return

        # 重新获取进程列表
        if IS_WINDOWS:
            self._get_process_list_windows()
        else:
            self._get_process_list_unix()

        # 更新缓存
        self._process_cache = self.processes.copy()
        self._cache_timestamp: float = current_time

    def _get_process_list_windows(self, encoding: str = "gbk") -> None:
        try:
            # 使用更高效的参数减少输出量
            result = execute(["tasklist", "/fo", "csv", "/nh"])

            if not result.success:
                logger.error("执行 tasklist 命令失败")
                return

            logger.debug("使用 %s 解码成功", encoding)
            for line in result.stdout.strip().split("\n"):
                if line:
                    parts = line.split('","')
                    if len(parts) >= 2:
                        name = parts[0].strip('"')
                        pid = parts[1].strip('"')
                        self.processes.append(ProcessInfo(name, pid))
        except UnicodeDecodeError:
            logger.warning("编码解码失败,无法获取进程列表")
            return
        except (OSError, ValueError) as e:
            logger.exception("获取进程列表时发生未知错误:%s", e.__class__.__name__)
            return

    def _get_process_list_unix(self) -> None:
        try:
            result = execute(["ps", "-eo", "pid,comm", "--no-headers"])

            if not result.success:
                logger.error("执行 ps 命令失败")
                return

            for line in result.stdout.strip().split("\n"):
                if line:
                    parts = line.strip().split(maxsplit=1)
                    if len(parts) >= 2:
                        pid = parts[0]
                        name = parts[1]
                        self.processes.append(ProcessInfo(name, pid))
        except (OSError, ValueError) as e:
            logger.exception("获取进程列表失败:%s", e.__class__.__name__)
            return

    @staticmethod
    def _kill_by_pid_windows(pid: str) -> bool:
        """在 Windows 上使用 taskkill 命令终止进程.

        Args:
            pid: 进程标识符字符串

        Returns
        -------
            bool: 如果成功终止进程则返回 True, 否则返回 False
        """
        try:
            result = execute(["taskkill", "/F", "/PID", pid])

            if not result.success:
                logger.error("终止进程 PID %s 失败", pid)
                if result.stdout:
                    logger.debug("taskkill 标准输出:%s", result.stdout.strip())
                if result.stderr:
                    logger.debug("taskkill 标准错误:%s", result.stderr.strip())
                return False

            logger.debug("taskkill 输出:%s", result.stdout.strip())

        except (OSError, ValueError):
            logger.exception("终止进程 PID %s 异常", pid)
            return False
        else:
            return True

    @staticmethod
    def _kill_by_pid_unix(pid: str) -> bool:
        """在 Unix/Linux 上使用 kill 命令终止进程.

        Args:
            pid: 进程标识符字符串

        Returns
        -------
            bool: 如果成功终止进程则返回 True, 否则返回 False
        """
        try:
            result = execute(["kill", "-9", pid])

            if not result.success:
                logger.error("终止进程 PID %s 失败", pid)
                if result.stdout:
                    logger.debug("kill 标准输出:%s", result.stdout.strip())
                if result.stderr:
                    logger.debug("kill 标准错误:%s", result.stderr.strip())
                return False

            logger.debug("kill 输出:%s", result.stdout.strip())
        except (OSError, ValueError):
            logger.exception("终止进程 PID %s 异常", pid)
            return False
        else:
            return True


class TaskKillSkill(BaseSkill):
    """进程终止技能."""

    name = "taskkill"
    description = "跨平台进程终止工具"

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "processes", type=str, nargs="+", help="要终止的进程名称或模式 (支持通配符)"
        )
        parser.add_argument(
            "--debug", "-d", action="store_true", help="启用调试日志以获取详细输出"
        )
        parser.add_argument(
            "--force",
            "-f",
            action="store_true",
            help="即使匹配数量超过安全阈值也强制终止",
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建进程终止调度器."""
        if args.debug:
            logger.setLevel(logging.DEBUG)
            logger.debug("调试模式已启用")

        if args.force:
            cmd = TaskkillCommand(force=True)
            logger.debug("力模式已启用,阈值增加到 %d", cmd.match_threshold)
        else:
            cmd = TaskkillCommand()

        t0 = time.perf_counter()
        max_workers = min(10, len(args.processes))
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [executor.submit(cmd.kill, process) for process in args.processes]

        # 收集结果以确保所有操作完成
        results = []
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            results.append(result)

        # 刷新 stdout 以确保显示所有输出
        sys.stdout.flush()

        # 返回总体成功状态
        success = all(results) if results else False
        logger.info("操作在 %.4f 秒内完成", time.perf_counter() - t0)
        sys.stdout.flush()

        if not success:
            raise SystemExit(1)

        # 返回空调度器（主要工作已在上面完成）
        return CommandScheduler(commands=[])


def main() -> None:
    """主函数入口."""
    TaskKillSkill().run_cli()
