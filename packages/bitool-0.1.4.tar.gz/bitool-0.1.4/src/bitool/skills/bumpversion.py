"""版本号自动管理工具.

参考旧版 bumpversion 和 pymake 的设计, 使用 CommandScheduler 模式实现.
支持语义化版本管理和多文件格式的版本号更新.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from bitool.cmd import (
    BumpProjectVersionCommand,
    CommandScheduler,
    GitCommitCommand,
    GitTagCommand,
)
from bitool.core import JsonConfig, logger
from bitool.skills._base import BaseSkill


class BumpversionConfig(JsonConfig):
    """Bumpversion 配置类."""

    # 排除的目录
    EXCLUDED_DIRS: set[str] = {  # noqa: RUF012
        "__pycache__",
        ".venv",
        "venv",
        "env",
        ".git",
        "dist",
        "build",
        ".tox",
        ".pytest_cache",
    }


class BumpVersionSkill(BaseSkill):
    """版本号管理技能."""

    name = "bumpversion"
    description = "版本号自动管理工具 (支持语义化版本和多文件格式)"
    config = BumpversionConfig()

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "action",
            nargs="?",
            default="patch",
            choices=OPTIONS,
            type=str,
            help="要执行的操作, 可选值: " + ", ".join(OPTIONS),
        )
        parser.add_argument(
            "-t",
            "--tag",
            action="store_true",
            default=False,
            help="递增版本号后创建 Git 标签",
        )
        parser.add_argument(
            "-c",
            "--commit",
            action="store_true",
            default=False,
            help="递增版本号后提交更改到 Git",
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建版本号管理调度器.

        根据命令行参数创建对应的命令调度器，包含版本号递增命令。
        Git 操作（tag/commit）将在 run 方法中处理。

        Parameters
        ----------
        args : argparse.Namespace
            解析后的命令行参数

        Returns
        -------
        CommandScheduler
            配置好的命令调度器，包含版本递增命令
        """
        scheduler_map = create_scheduler_map()
        scheduler: CommandScheduler | None = scheduler_map.get(args.action, None)

        if not scheduler:
            logger.error(f"无效的操作: {args.action}")
            raise SystemExit(1)

        return scheduler

    def run(self, args: list[str] | None = None) -> int:
        """运行 BumpVersion Skill.

        重写基类方法以支持 Git 操作（需要在版本递增后获取新版本号）。

        Parameters
        ----------
        args : list[str], optional
            参数列表，默认使用 sys.argv[1:]

        Returns
        -------
        int
            退出码 (0 表示成功，非 0 表示失败)
        """
        try:
            # 步骤 1: 解析参数
            parsed_args = self.parse_args(args)

            # 步骤 2: 创建调度器
            scheduler = self.create_scheduler(parsed_args)

            # 步骤 3: 执行版本号递增命令
            success = scheduler.run()

            # 步骤 4: 如果指定了 tag 或 commit，执行 Git 操作
            if success and (parsed_args.tag or parsed_args.commit):
                self._handle_git_operations(
                    scheduler,
                    create_tag=parsed_args.tag,
                    create_commit=parsed_args.commit,
                )

        except KeyboardInterrupt:
            logger.info("操作已取消")
            return 130
        except SystemExit:
            raise
        except Exception as e:  # noqa: BLE001
            logger.error(f"{self.name} 执行失败: {e}")
            return 1
        else:
            return 0 if success else 1

    def _handle_git_operations(
        self, scheduler: CommandScheduler, *, create_tag: bool, create_commit: bool
    ) -> None:
        """处理 Git 相关操作（tag 和 commit）."""
        # 从 BumpProjectVersionCommand 中获取更新后的文件列表和新版本号
        for cmd in scheduler.commands:
            if isinstance(cmd, BumpProjectVersionCommand) and cmd.updated_files:
                # 从第一个更新的文件对应的命令中获取新版本号
                # 由于 BumpProjectVersionCommand 会为每个文件创建 BumpFileVersionCommand，
                # 我们需要重新读取第一个文件的新版本号
                first_file = cmd.updated_files[0]

                # 根据文件类型读取新版本号
                new_version = self._read_version_from_file(first_file)
                if not new_version:
                    logger.warning("未能读取到新版本号, 跳过 Git 操作")
                    break

                logger.info(f"检测到新版本号: {new_version}")

                # 创建 git tag（如果指定）
                if create_tag:
                    tag_cmd = GitTagCommand(
                        tag_name=f"v{new_version}", message=f"Release {new_version}"
                    )
                    tag_cmd.validate_and_run()

                # 提交更改（如果指定）
                if create_commit:
                    commit_cmd = GitCommitCommand(
                        message=f"chore: bump version to {new_version}"
                    )
                    commit_cmd.validate_and_run()

                break

    def _read_version_from_file(self, filepath: Path) -> str | None:
        """从版本文件中读取当前版本号.

        Parameters
        ----------
        filepath : Path
            版本文件路径

        Returns
        -------
        str | None
            版本号，读取失败时返回 None
        """
        from bitool.cmd.version import BumpFileVersionCommand

        # 创建临时命令来读取版本号（不执行递增）
        temp_bump_cmd = BumpFileVersionCommand(filepath=filepath)
        return temp_bump_cmd._read_version()


def create_scheduler_map() -> dict[str, CommandScheduler]:
    """创建命令调度器映射.

    Returns
    -------
    dict[str, CommandScheduler]
        操作名称到命令调度器的映射字典.
    """

    return {
        # === 版本号递增命令 ===
        # 递增补丁号 (1.0.0 -> 1.0.1)
        "patch": CommandScheduler(commands=[BumpProjectVersionCommand(part="patch")]),
        # 递增次版本号 (1.0.0 -> 1.1.0)
        "minor": CommandScheduler(commands=[BumpProjectVersionCommand(part="minor")]),
        # 递增主版本号 (1.0.0 -> 2.0.0)
        "major": CommandScheduler(commands=[BumpProjectVersionCommand(part="major")]),
        # 递增补丁号并设置预发布标识 (1.0.0 -> 1.0.1-alpha)
        "patch-alpha": CommandScheduler(
            commands=[BumpProjectVersionCommand(part="patch", prerelease="alpha")]
        ),
    }


OPTIONS: list[str] = list(create_scheduler_map().keys())


def show_help() -> str:
    """显示帮助信息.

    Returns
    -------
    str
        帮助信息文本
    """
    help_text = """
╔══════════════════════════════════════════════════════════╗
║              Bitool 版本号自动管理工具                   ║
╚══════════════════════════════════════════════════════════╝

📈 版本号递增命令:
  bumpversion patch        - 递增补丁号 (1.0.0 -> 1.0.1)
  bumpversion minor        - 递增次版本号 (1.0.0 -> 1.1.0)
  bumpversion major        - 递增主版本号 (1.0.0 -> 2.0.0)
  bumpversion patch-alpha  - 递增补丁号并设置预发布标识 (1.0.0 -> 1.0.1-alpha)

💡 支持的文件格式:
  - pyproject.toml: version = "1.0.0"
  - __init__.py: __version__ = "1.0.0"
  - setup.py: version = "1.0.0"
  - package.json: "version": "1.0.0"
  - Cargo.toml: version = "1.0.0"

📝 示例:
  bumpversion patch          # 递增补丁号
  bumpversion minor          # 递增次版本号
  bumpversion patch-alpha    # 递增补丁号并添加 alpha 预发布标识
"""
    return help_text


def main() -> None:
    """主函数入口."""
    skill = BumpVersionSkill()
    skill.run_cli()


if __name__ == "__main__":
    main()
