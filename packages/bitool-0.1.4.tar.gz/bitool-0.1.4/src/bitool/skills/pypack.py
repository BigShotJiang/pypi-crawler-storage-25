"""Python 打包工具模块.

基于 pypack 提供统一的项目打包、归档、发布功能,
复用 bitool cmd 模块的命令调度能力.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from bitool.cmd import BuiltinConditions, CommandScheduler, RunCommand
from bitool.core import JsonConfig, logger
from bitool.skills._base import BaseSkill


class PyPackConfig(JsonConfig):
    """PyPack 配置类."""

    # 项目根目录
    PROJECT_ROOT = Path(__file__).parent.parent.parent.parent

    # 打包工具
    PYTOOL = "pypack"
    BUILD_COMMAND = [PYTOOL, "build"]  # noqa: RUF012
    CLEAN_COMMAND = [PYTOOL, "clean"]  # noqa: RUF012
    LIST_COMMAND = [PYTOOL, "list"]  # noqa: RUF012

    # 归档工具
    ARCHIVE_FORMATS = ["zip", "tar", "gztar", "bztar", "xztar", "7z", "nsis"]  # noqa: RUF012

    # Python 版本
    DEFAULT_PYTHON_VERSION = "3.8.10"

    # 加载器类型
    LOADER_TYPES = ["console", "gui"]  # noqa: RUF012

    # 镜像源
    MIRRORS = ["pypi", "tsinghua", "aliyun", "ustc", "douban", "tencent"]  # noqa: RUF012

    # 构建超时
    BUILD_TIMEOUT = 600


conf = PyPackConfig()


class PyPackSkill(BaseSkill):
    """PyPack 打包技能."""

    name = "pypack"
    description = "Bitool PyPack - Python项目打包工具（基于pypack）"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "action",
            nargs="?",
            type=str,
            help="要执行的操作, 可选值: " + ", ".join(OPTIONS),
        )
        parser.add_argument(
            "--project", "-p", type=str, default=None, help="项目名称（用于 build/run）"
        )
        parser.add_argument(
            "--python-version",
            type=str,
            default=conf.DEFAULT_PYTHON_VERSION,
            help=f"Python 版本（默认: {conf.DEFAULT_PYTHON_VERSION}）",
        )
        parser.add_argument(
            "--loader-type",
            type=str,
            choices=conf.LOADER_TYPES,
            default="console",
            help="加载器类型（默认: console）",
        )
        parser.add_argument(
            "--archive",
            "-a",
            type=str,
            choices=conf.ARCHIVE_FORMATS,
            default=None,
            help="归档格式（构建后创建归档）",
        )
        parser.add_argument(
            "--mirror",
            type=str,
            choices=conf.MIRRORS,
            default="aliyun",
            help="PyPI 镜像源（默认: aliyun）",
        )
        parser.add_argument("--offline", "-o", action="store_true", help="离线模式")
        parser.add_argument(
            "--jobs", "-j", type=int, default=4, help="最大并发任务数（默认: 4）"
        )
        parser.add_argument("--debug", "-d", action="store_true", help="调试模式")

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建打包调度器."""
        scheduler: CommandScheduler | None = create_scheduler_map(args).get(
            args.action, None
        )
        if not scheduler:
            logger.error(f"无效的操作: {args.action}")
            raise SystemExit(1)

        return scheduler


def create_scheduler_map(args: argparse.Namespace) -> dict[str, CommandScheduler]:
    """创建命令调度器映射.

    Parameters
    ----------
    args : argparse.Namespace
        解析后的命令行参数

    Returns
    -------
    dict[str, CommandScheduler]
        操作名称到命令调度器的映射字典.
    """
    # 构建基础命令
    build_cmd = [conf.PYTOOL, "build"]
    if args.project:
        build_cmd.extend(["--project", args.project])
    build_cmd.extend(["--python-version", args.python_version])
    build_cmd.extend(["--loader-type", args.loader_type])
    build_cmd.extend(["--mirror", args.mirror])
    build_cmd.extend(["--jobs", str(args.jobs)])
    if args.offline:
        build_cmd.append("--offline")
    if args.archive:
        build_cmd.extend(["--archive", args.archive])
    if args.debug:
        build_cmd.append("--debug")

    return {
        # === 打包命令 ===
        # 构建项目
        "b": CommandScheduler(
            commands=[
                RunCommand(
                    cmd=build_cmd,
                    allow_conditions=[_PYTOOL_CONDITION],
                    timeout=conf.BUILD_TIMEOUT,
                )
            ]
        ),
        # 清理构建产物
        "c": CommandScheduler(
            commands=[
                RunCommand(cmd=conf.CLEAN_COMMAND, allow_conditions=[_PYTOOL_CONDITION])
            ]
        ),
        # 列出可用项目
        "l": CommandScheduler(
            commands=[
                RunCommand(cmd=conf.LIST_COMMAND, allow_conditions=[_PYTOOL_CONDITION])
            ]
        ),
        # 运行打包的应用
        "r": CommandScheduler(
            commands=[
                RunCommand(
                    cmd=[conf.PYTOOL, "run", args.project]
                    if args.project
                    else [conf.PYTOOL, "run"],
                    allow_conditions=[_PYTOOL_CONDITION],
                )
            ]
        ),
        # 显示版本信息
        "v": CommandScheduler(
            commands=[
                RunCommand(
                    cmd=[conf.PYTOOL, "version"], allow_conditions=[_PYTOOL_CONDITION]
                )
            ]
        ),
        # 完整构建（包含归档）
        "ba": CommandScheduler(
            commands=[
                RunCommand(
                    cmd=[*build_cmd, "--archive", args.archive or "zip"],
                    allow_conditions=[_PYTOOL_CONDITION],
                    timeout=conf.BUILD_TIMEOUT,
                )
            ]
        ),
        # GUI 模式构建
        "bg": CommandScheduler(
            commands=[
                RunCommand(
                    cmd=[*build_cmd, "--loader-type", "gui"],
                    allow_conditions=[_PYTOOL_CONDITION],
                    timeout=conf.BUILD_TIMEOUT,
                )
            ]
        ),
        # 离线构建
        "bo": CommandScheduler(
            commands=[
                RunCommand(
                    cmd=[*build_cmd, "--offline"],
                    allow_conditions=[_PYTOOL_CONDITION],
                    timeout=conf.BUILD_TIMEOUT,
                )
            ]
        ),
    }


# 命令条件判断
_PYTOOL_CONDITION = BuiltinConditions.HAS_APP_INSTALLED(conf.PYTOOL)


OPTIONS: list[str] = list(
    create_scheduler_map(
        argparse.Namespace(
            project=None,
            python_version=conf.DEFAULT_PYTHON_VERSION,
            loader_type="console",
            archive=None,
            mirror="aliyun",
            offline=False,
            jobs=4,
            debug=False,
            action=None,
        )
    ).keys()
)


def show_help() -> str:
    """显示帮助信息."""
    help_text = """
╔══════════════════════════════════════════════════════════╗
║                  Bitool PyPack 打包工具                  ║
╚══════════════════════════════════════════════════════════╝

📦 打包命令:
  pypack b    - 构建项目 (pypack build)
  pypack ba   - 构建并归档 (默认zip)
  pypack bg   - GUI模式构建
  pypack bo   - 离线构建

🧹 清理命令:
  pypack c    - 清理构建产物

📋 查询命令:
  pypack l    - 列出可用项目
  pypack v    - 显示版本信息

🚀 运行命令:
  pypack r    - 运行打包的应用（需指定 --project）

💡 常用选项:
  --project, -p      项目名称
  --python-version   Python版本（默认: 3.8.10）
  --loader-type      加载器类型: console/gui
  --archive, -a      归档格式: zip/tar/7z/nsis等
  --mirror           PyPI镜像源: aliyun/tsinghua等
  --offline, -o      离线模式
  --jobs, -j         并发任务数（默认: 4）
  --debug, -d        调试模式

📝 示例:
  pypack b -p myapp                    # 构建myapp项目
  pypack ba -p myapp -a 7z             # 构建并打包为7z
  pypack bg -p mygui --loader-type gui # GUI模式构建
  pypack l                             # 列出所有项目
  pypack r -p myapp                    # 运行myapp
  pypack c                             # 清理构建产物
"""
    return help_text


def main() -> None:
    """主函数入口."""
    PyPackSkill().run_cli()
