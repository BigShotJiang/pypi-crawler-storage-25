"""PDF转图片脚本.

将PDF文件的每一页转换为图片格式, 支持多种输出格式和分辨率设置.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from bitool.cmd import CommandScheduler, PdfToImagesCommand
from bitool.core import JsonConfig, logger
from bitool.skills._base import BaseSkill


class PdfToImageConfig(JsonConfig):
    """PDF转图片配置类."""

    DPI: int = 150
    DPI_RANGE: tuple[int, int] = (72, 300)
    FORMAT: str = "png"
    QUALITY: int = 90
    QUALITY_RANGE: tuple[int, int] = (1, 100)
    VALID_FORMATS: set[str] = {"png", "jpg", "jpeg"}  # noqa: RUF012


conf = PdfToImageConfig()


class Pdf2ImgSkill(BaseSkill):
    """PDF转图片技能."""

    name = "pdf2img"
    description = "将PDF转换为图片"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "input_path",
            type=str,
            nargs="?",
            default=None,
            help="输入PDF文件路径(可选, 默认搜索当前目录)",
        )
        parser.add_argument(
            "output_dir", type=str, nargs="?", default=None, help="输出目录"
        )
        parser.add_argument(
            "--format", type=str, default=conf.FORMAT, help="输出图片格式"
        )
        parser.add_argument("--dpi", type=int, default=conf.DPI, help="图片分辨率(DPI)")
        parser.add_argument(
            "--quality", type=int, default=conf.QUALITY, help="图片质量"
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建PDF转图片调度器."""
        # 验证输入路径
        input_path = Path(args.input_path) if args.input_path else Path.cwd()

        # 如果输入路径是目录, 搜索该目录下的所有PDF文件
        if input_path.is_dir():
            pdf_files = list(input_path.glob("*.pdf")) + list(input_path.glob("*.PDF"))
            if not pdf_files:
                logger.error(f"在目录 {input_path} 中未找到PDF文件")
                sys.exit(1)
            logger.info(f"在目录 {input_path} 中找到 {len(pdf_files)} 个PDF文件")
            # 处理第一个找到的PDF文件
            input_path = pdf_files[0]
            logger.info(f"将处理: {input_path}")

        if not input_path.exists():
            logger.error(f"未找到输入路径: {input_path}")
            sys.exit(1)

        # 确定输出目录
        output_dir = Path(args.output_dir) if args.output_dir else None
        if output_dir is None:
            output_dir = input_path.parent / "converted_images"

        if not output_dir.exists():
            output_dir.mkdir(parents=True)
            logger.info(f"创建输出目录: {output_dir}")

        # 验证参数范围
        if not conf.QUALITY_RANGE[0] <= args.quality <= conf.QUALITY_RANGE[1]:
            logger.error(
                f"图片质量必须在 {conf.QUALITY_RANGE[0]} 到 {conf.QUALITY_RANGE[1]} 之间"
            )
            sys.exit(1)

        if not conf.DPI_RANGE[0] <= args.dpi <= conf.DPI_RANGE[1]:
            logger.error(f"DPI必须在 {conf.DPI_RANGE[0]} 到 {conf.DPI_RANGE[1]} 之间")
            sys.exit(1)

        if args.format not in conf.VALID_FORMATS:
            logger.error(f"无效的图片格式, 请选择 {conf.VALID_FORMATS}")
            sys.exit(1)

        logger.info(
            f"开始转换: {input_path} -> {output_dir} (DPI={args.dpi}, 格式={args.format})"
        )

        return CommandScheduler(
            commands=[
                PdfToImagesCommand(
                    input_path=input_path,
                    output_dir=output_dir,
                    dpi=args.dpi,
                    fmt=args.format,
                )
            ]
        )


def main() -> None:
    """PDF转图片主函数."""
    Pdf2ImgSkill().run_cli()
