from typing import Callable, TypeVar

from typing_extensions import ParamSpec

ParamType = ParamSpec("ParamType")
ReturnType = TypeVar("ReturnType")
FunctionType = Callable[ParamType, ReturnType]
