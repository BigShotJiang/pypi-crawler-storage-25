"""JsonConfig 配置模块测试 - 配置隔离测试."""

import json
import threading
from decimal import Decimal
from pathlib import Path
from typing import NoReturn
from unittest.mock import patch

from bitool.consts import Constants
from bitool.core.config import JsonConfig


class TestSystemConfig:
    """测试系统配置属性（已迁移到 Constants）."""

    def test_system_properties(self, tmp_path: Path) -> None:
        """测试系统属性获取（使用 Constants）。"""

        class TestConfig(JsonConfig):
            NAME = "system_test"

        TestConfig()

        # 测试 Constants 中的系统属性
        assert isinstance(Constants.IS_WINDOWS, bool)
        assert isinstance(Constants.IS_UNIX, bool)
        assert isinstance(Constants.EXTENSION, str)

    def test_is_windows(self, tmp_path: Path) -> None:
        """测试 Windows 检测。"""
        import platform

        # 测试 Constants.IS_WINDOWS
        expected = platform.system() == "Windows"
        assert expected == Constants.IS_WINDOWS

    def test_extension(self, tmp_path: Path) -> None:
        """测试扩展名检测。"""
        import platform

        # 测试 Constants.EXTENSION
        expected = ".exe" if platform.system() == "Windows" else ""
        assert expected == Constants.EXTENSION


class TestJsonConfigIsolation:
    """测试配置隔离功能."""

    def test_config_uses_temp_directory(self, tmp_path: Path) -> None:
        """验证配置使用临时目录而非真实目录."""

        # 创建测试子类
        class TestConfig(JsonConfig):
            NAME = "test_isolation"

        # 实例化时应使用被monkeypatch的ROOT_DIR
        config = TestConfig()

        # 保存配置文件路径用于后续验证
        config_file_path = config._config_file

        # 验证配置文件在临时目录中
        expected_path = tmp_path / "test_isolation.json"
        assert config_file_path == expected_path
        assert not expected_path.exists()  # 首次实例化不应创建文件

        # 清理atexit注册，避免在测试结束时保存到用户目录
        # 注意：这里我们不能真正取消注册，但我们可以确保配置不会被保存
        # 通过删除配置引用来实现

    def test_multiple_configs_isolated(self, tmp_path: Path) -> None:
        """验证多个配置实例相互隔离."""

        class ConfigA(JsonConfig):
            NAME = "config_a"

        class ConfigB(JsonConfig):
            NAME = "config_b"

        config_a = ConfigA()
        config_b = ConfigB()

        # 设置不同的值
        config_a.test_key = "value_a"
        config_b.test_key = "value_b"

        # 验证隔离
        assert config_a.test_key == "value_a"
        assert config_b.test_key == "value_b"

        # 验证配置文件路径不同
        assert config_a._config_file != config_b._config_file

    def test_attrs_with_private(self, tmp_path: Path) -> None:
        """测试包含私有属性的attrs."""

        class TestConfig(JsonConfig):
            NAME = "private_attrs_test"

        config = TestConfig()
        config.public_key = "public_value"
        # 直接设置到_attrs避免被__setattr__处理（它会跳过_开头的属性）
        config._attrs["_private_key"] = "private_value"

        # attrs不应该包含私有属性（以_开头的键）
        assert "public_key" in config.attrs
        assert "_private_key" not in config.attrs

        # attrs_with_private应该包含私有属性（以_开头的键）
        assert "public_key" in config.attrs_with_private
        assert "_private_key" in config.attrs_with_private
        assert config.attrs_with_private["_private_key"] == "private_value"


class TestJsonConfigLoadSave:
    """测试配置加载和保存功能."""

    def test_load_nonexistent_config(self, tmp_path: Path) -> None:
        """测试加载不存在的配置文件."""

        class TestConfig(JsonConfig):
            NAME = "nonexistent"

        config = TestConfig()
        # 不应该抛出异常，但会包含NAME类属性
        assert "NAME" in config.attrs or config.attrs == {}

    def test_save_and_load_config(self, tmp_path: Path) -> None:
        """测试保存和加载配置."""

        class TestConfig(JsonConfig):
            NAME = "test_save_load"

        config = TestConfig()

        # 设置配置值
        config.string_key = "test_value"
        config.int_key = 42
        config.float_key = 3.14
        config.bool_key = True

        # 保存配置
        config.save_to_json()

        # 验证文件已创建
        config_file = tmp_path / "test_save_load.json"
        assert config_file.exists()

        # 读取并验证内容
        with open(config_file, encoding="utf-8") as f:
            saved_data = json.load(f)

        assert saved_data["string_key"] == "test_value"
        assert saved_data["int_key"] == 42
        assert saved_data["float_key"] == 3.14
        assert saved_data["bool_key"] is True

    def test_load_from_existing_file(self, tmp_path: Path) -> None:
        """测试从现有文件加载配置."""
        # 创建配置文件
        config_file = tmp_path / "test_load.json"
        test_data = {"existing_key": "existing_value", "number": 123}
        with open(config_file, "w", encoding="utf-8") as f:
            json.dump(test_data, f)

        class TestConfig(JsonConfig):
            NAME = "test_load"

        config = TestConfig()

        # 验证加载了文件中的值
        assert config.existing_key == "existing_value"
        assert config.number == 123


class TestJsonConfigThreadSafety:
    """测试配置的线程安全性."""

    def test_concurrent_attribute_access(self, tmp_path: Path) -> None:
        """测试并发属性访问的线程安全."""

        class TestConfig(JsonConfig):
            NAME = "thread_safety"

        config = TestConfig()
        errors = []

        def write_attributes(thread_id: int) -> None:
            try:
                for i in range(100):
                    setattr(config, f"thread_{thread_id}_key_{i}", f"value_{i}")
            except Exception as e:  # noqa: BLE001
                errors.append(e)

        # 创建多个线程同时写入
        threads = []
        for i in range(5):
            thread = threading.Thread(target=write_attributes, args=(i,))
            threads.append(thread)
            thread.start()

        # 等待所有线程完成
        for thread in threads:
            thread.join()

        # 验证没有错误
        assert len(errors) == 0

        # 验证所有值都被正确设置
        for i in range(5):
            for j in range(100):
                key = f"thread_{i}_key_{j}"
                assert getattr(config, key) == f"value_{j}"


class TestJsonConfigErrorHandling:
    """测试错误处理路径."""

    def test_load_null_json(self, tmp_path: Path) -> None:
        """测试加载null值的JSON文件."""
        config_file = tmp_path / "null_test.json"
        with open(config_file, "w", encoding="utf-8") as f:
            f.write("null")

        class TestConfig(JsonConfig):
            NAME = "null_test"

        config = TestConfig()
        # 应该忽略null值，使用默认值
        assert config.attrs == {"NAME": "null_test"}

    def test_load_invalid_json_format(self, tmp_path: Path) -> None:
        """测试加载非dict类型的JSON."""
        config_file = tmp_path / "invalid_format.json"
        with open(config_file, "w", encoding="utf-8") as f:
            json.dump([1, 2, 3], f)  # 列表而非字典

        class TestConfig(JsonConfig):
            NAME = "invalid_format"

        config = TestConfig()
        # 应该忽略无效格式，使用默认值
        assert config.attrs == {"NAME": "invalid_format"}

    def test_load_os_error(self, tmp_path: Path) -> None:
        """测试读取文件时的OSError."""

        class TestConfig(JsonConfig):
            NAME = "os_error_test"

        config = TestConfig()

        # Mock open 方法抛出 OSError（需要在文件存在时触发）
        config_file = tmp_path / "os_error_test.json"
        config_file.write_text('{"key": "value"}')

        with patch.object(Path, "open", side_effect=OSError("Permission denied")):
            # 不应该抛出异常
            config.load_from_json()

        # 由于OSError，应该使用默认值（文件配置未加载）
        assert config.attrs == {"NAME": "os_error_test"}

    def test_restore_from_invalid_backup(self, tmp_path: Path) -> None:
        """测试从无效的备份文件恢复."""

        class TestConfig(JsonConfig):
            NAME = "invalid_backup"

        config = TestConfig()
        config.test_key = "test_value"
        config.save_to_json()

        # 破坏备份文件
        backup_file = tmp_path / "invalid_backup.json.bak"
        with open(backup_file, "w", encoding="utf-8") as f:
            f.write("invalid backup{{{")

        # 破坏配置文件
        config_file = tmp_path / "invalid_backup.json"
        with open(config_file, "w", encoding="utf-8") as f:
            f.write("invalid config{{{")

        # 重新加载，应该能处理备份也无效的情况
        config2 = TestConfig()
        # 不会抛出异常，但数据可能丢失
        assert hasattr(config2, "_file_attrs")

    def test_serialize_custom_object(self, tmp_path: Path) -> None:
        """测试自定义对象序列化."""

        class CustomClass:
            def __init__(self) -> None:
                self.name = "test"
                self.value = 123
                self._private = "hidden"

        class TestConfig(JsonConfig):
            NAME = "custom_obj"

        config = TestConfig()
        config.custom = CustomClass()

        # 保存配置
        config.save_to_json()

        # 验证文件可以正常读取
        config_file = tmp_path / "custom_obj.json"
        assert config_file.exists()

        with open(config_file, encoding="utf-8") as f:
            data = json.load(f)

        # 验证自定义对象被序列化
        assert data["custom"]["__class__"] == "CustomClass"
        assert data["custom"]["name"] == "test"
        assert data["custom"]["value"] == 123
        # 私有属性不应该被序列化
        assert "_private" not in data["custom"]

    def test_serialize_internal_class(self, tmp_path: Path) -> None:
        """测试内部类（以_开头）序列化."""

        class _InternalClass:
            def __init__(self) -> None:
                self.value = "internal"

        class TestConfig(JsonConfig):
            NAME = "internal_class"

        config = TestConfig()
        config.internal = _InternalClass()

        # 保存配置
        config.save_to_json()

        # 验证文件可以正常读取
        config_file = tmp_path / "internal_class.json"
        with open(config_file, encoding="utf-8") as f:
            data = json.load(f)

        # 内部类应该被转换为字符串
        assert isinstance(data["internal"], str)

    def test_serialize_type_object(self, tmp_path: Path) -> None:
        """测试type对象序列化."""

        class TestConfig(JsonConfig):
            NAME = "type_obj"

        config = TestConfig()

        # type对象是callable，会被_filter_serializable_attrs过滤掉
        # 直接测试_default_encoder方法
        encoded = config._default_encoder(str)

        # type对象应该被转换为字符串
        assert isinstance(encoded, str)
        assert "str" in encoded or "type" in encoded.lower()

    def test_serialize_path_object(self, tmp_path: Path) -> None:
        """测试Path对象序列化."""

        class TestConfig(JsonConfig):
            NAME = "path_obj"

        config = TestConfig()
        test_path = Path("/tmp/test")
        config._attrs["path_val"] = test_path  # ty:ignore[invalid-assignment]  # 直接设置避免被过滤

        # 保存配置
        config.save_to_json()

        config_file = tmp_path / "path_obj.json"
        with open(config_file, encoding="utf-8") as f:
            data = json.load(f)

        # Path应该被转换为字符串（跨平台兼容）
        assert "path_val" in data
        # Windows上会是 \tmp\test，Linux上是 /tmp/test
        assert data["path_val"] in ["/tmp/test", "\\tmp\\test", str(test_path)]


class TestJsonConfigCircularReference:
    """测试配置的序列化功能."""

    def test_serialize_complex_types(self, tmp_path: Path) -> None:
        """测试复杂类型的序列化."""

        class TestConfig(JsonConfig):
            NAME = "serialize_complex"

        config = TestConfig()

        # 设置复杂类型
        config.decimal_value = Decimal("123.456")
        config.complex_value = complex(1, 2)
        config.set_value = {1, 2, 3}
        config.bytes_value = b"test bytes"

        # 保存配置
        config.save_to_json()

        # 验证文件可以正常读取
        config_file = tmp_path / "serialize_complex.json"
        assert config_file.exists()

        with open(config_file, encoding="utf-8") as f:
            data = json.load(f)

        # 验证复杂类型被正确序列化
        assert data["decimal_value"] == 123.456
        assert data["complex_value"]["__complex__"] is True
        assert data["complex_value"]["real"] == 1.0
        assert data["complex_value"]["imag"] == 2.0
        assert set(data["set_value"]) == {1, 2, 3}
        assert data["bytes_value"] == "test bytes"

    def test_serialize_circular_reference(self, tmp_path: Path) -> None:
        """测试循环引用的处理."""

        class TestConfig(JsonConfig):
            NAME = "circular_ref"

        config = TestConfig()

        # 创建循环引用 - 使用 dict[str, Any] 类型来避免类型检查错误
        from typing import Any

        data: dict[str, Any] = {"key": "value"}
        data["self_ref"] = data  # 循环引用

        config.circular_data = data

        # 保存配置不应抛出异常
        config.save_to_json()

        # 验证文件存在
        config_file = tmp_path / "circular_ref.json"
        assert config_file.exists()


class TestJsonConfigBackup:
    """测试配置备份功能."""

    def test_backup_creation(self, tmp_path: Path) -> None:
        """测试备份文件创建."""

        class TestConfig(JsonConfig):
            NAME = "backup_test"

        config = TestConfig()
        config.test_key = "test_value"

        # 保存配置
        config.save_to_json()

        # 验证备份文件存在
        backup_file = tmp_path / "backup_test.json.bak"
        assert backup_file.exists()

        # 验证备份内容
        with open(backup_file, encoding="utf-8") as f:
            backup_data = json.load(f)

        assert backup_data["test_key"] == "test_value"

    def test_restore_from_backup(self, tmp_path: Path) -> None:
        """测试从备份恢复配置."""

        class TestConfig(JsonConfig):
            NAME = "restore_test"

        # 创建初始配置并保存
        config1 = TestConfig()
        config1.original_key = "original_value"
        config1.save_to_json()

        # 创建备份
        config_file = tmp_path / "restore_test.json"
        backup_file = tmp_path / "restore_test.json.bak"

        # 确保备份文件存在且包含正确的内容
        assert backup_file.exists()
        with open(backup_file, encoding="utf-8") as f:
            backup_data = json.load(f)
        assert backup_data.get("original_key") == "original_value"

        # 破坏配置文件
        with open(config_file, "w", encoding="utf-8") as f:
            f.write("invalid json{{{")

        # 重新加载配置（应触发从备份恢复）
        config2 = TestConfig()

        # 验证备份文件中的内容被恢复到 _file_attrs
        # 注意：当前实现中 _restore_from_backup 只恢复 _file_attrs，不会自动合并到 _attrs
        # 但备份文件本身应该包含原始数据
        assert config2._file_attrs.get("original_key") == "original_value"


class TestJsonConfigValidation:
    """测试序列化验证逻辑."""

    def test_validate_basic_types(self, tmp_path: Path) -> None:
        """测试基本类型的验证."""

        class TestConfig(JsonConfig):
            NAME = "validate_basic"

        config = TestConfig()

        # 测试各种基本类型
        assert config._is_basic_serializable("string") is True
        assert config._is_basic_serializable(123) is True
        assert config._is_basic_serializable(3.14) is True
        assert config._is_basic_serializable(obj=True) is True
        assert config._is_basic_serializable(None) is True
        assert config._is_basic_serializable(Decimal("1.5")) is True
        assert config._is_basic_serializable(complex(1, 2)) is True
        assert config._is_basic_serializable(b"bytes") is True

    def test_validate_deep_nesting(self, tmp_path: Path) -> None:
        """测试深层嵌套验证."""

        class TestConfig(JsonConfig):
            NAME = "deep_nesting"

        config = TestConfig()

        # 创建超过最大深度的嵌套结构
        deep_obj: dict = {}
        current = deep_obj
        for _i in range(60):  # 超过max_depth=50
            current["level"] = {}
            current = current["level"]

        config.deep = deep_obj

        # 验证应该失败（超过最大深度）
        assert config._validate_serializable(deep_obj) is False

    def test_validate_dict_with_non_string_keys(self, tmp_path: Path) -> None:
        """测试包含非字符串键的字典验证."""

        class TestConfig(JsonConfig):
            NAME = "non_string_keys"

        config = TestConfig()

        # 创建包含非字符串键的字典（虽然Python允许，但JSON不支持）
        invalid_dict = {1: "value1", 2: "value2"}

        # 验证应该失败
        assert config._validate_serializable(invalid_dict) is False

    def test_validate_circular_in_list(self, tmp_path: Path) -> None:
        """测试列表中的循环引用验证."""

        class TestConfig(JsonConfig):
            NAME = "circular_list"

        config = TestConfig()

        # 创建列表中的循环引用
        lst: list = []
        lst.append(lst)

        # 验证应该失败（检测到循环引用）
        assert config._validate_serializable(lst) is False

    def test_remove_circular_refs_in_list(self, tmp_path: Path) -> None:
        """测试_remove_circular_refs处理列表循环引用（覆盖行490-499）."""

        class TestConfig(JsonConfig):
            NAME = "circular_list_remove"

        config = TestConfig()

        # 创建列表中的循环引用
        lst: list = []
        lst.append(lst)
        lst.append("value")

        # _remove_circular_refs应该能检测到循环引用并替换为"<circular reference>"
        result = config._remove_circular_refs(lst)
        assert isinstance(result, list)
        assert result[0] == "<circular reference>"
        assert result[1] == "value"

    def test_remove_circular_refs_in_tuple(self, tmp_path: Path) -> None:
        """测试_remove_circular_refs处理元组循环引用（覆盖行490-499）."""

        class TestConfig(JsonConfig):
            NAME = "circular_tuple_remove"

        config = TestConfig()

        # 创建元组包含循环引用（元组中包含列表，列表引用回元组）
        inner_list: list = []
        tpl: tuple = (inner_list, "value")
        inner_list.append(tpl)

        # _remove_circular_refs应该能处理这种情况（覆盖行490-499的元组分支）
        result = config._remove_circular_refs(tpl)
        assert isinstance(result, list)  # 元组会被转换为列表


class TestJsonConfigObserver:
    """测试配置观察者模式."""

    def test_add_remove_observer(self, tmp_path: Path) -> None:
        """测试添加和移除观察者."""

        class TestConfig(JsonConfig):
            NAME = "observer_test"

        config = TestConfig()
        change_log = []

        def observer(key: str, old_value, new_value) -> None:
            change_log.append((key, old_value, new_value))

        # 添加观察者
        config.add_observer(observer)

        # 修改配置
        config.test_key = "test_value"

        # 验证观察者被调用
        assert len(change_log) == 1
        assert change_log[0] == ("test_key", None, "test_value")

        # 移除观察者
        config.remove_observer(observer)

        # 再次修改配置
        config.test_key = "new_value"

        # 验证观察者不再被调用
        assert len(change_log) == 1  # 仍然只有1条记录

    def test_observer_oserror_exception(self, tmp_path: Path) -> None:
        """测试观察者OSError异常处理."""

        class TestConfig(JsonConfig):
            NAME = "observer_oserror"

        config = TestConfig()

        def failing_observer(key, old, new) -> NoReturn:
            raise OSError("Observer OSError")

        config.add_observer(failing_observer)

        # 修改配置，观察者失败不应该影响配置设置
        config.test_key = "test_value"

        # 配置值应该被正确设置
        assert config.test_key == "test_value"

    def test_observer_runtimeerror_exception(self, tmp_path: Path) -> None:
        """测试观察者RuntimeError异常处理."""

        class TestConfig(JsonConfig):
            NAME = "observer_runtimeerror"

        config = TestConfig()

        def failing_observer(key, old, new) -> NoReturn:
            raise RuntimeError("Observer RuntimeError")

        config.add_observer(failing_observer)

        # 修改配置，观察者失败不应该影响配置设置
        config.test_key = "test_value"

        # 配置值应该被正确设置
        assert config.test_key == "test_value"

    def test_observer_valueerror_exception(self, tmp_path: Path) -> None:
        """测试观察者ValueError异常处理."""

        class TestConfig(JsonConfig):
            NAME = "observer_valueerror"

        config = TestConfig()

        def failing_observer(key, old, new) -> NoReturn:
            raise ValueError("Observer ValueError")

        config.add_observer(failing_observer)

        # 修改配置，观察者失败不应该影响配置设置
        config.test_key = "test_value"

        # 配置值应该被正确设置
        assert config.test_key == "test_value"

    def test_observer_exception_handling(self, tmp_path: Path) -> None:
        """测试观察者异常处理."""

        class TestConfig(JsonConfig):
            NAME = "observer_exception"

        config = TestConfig()

        # 创建会抛出异常的观察者（保留原有测试兼容性）
        def failing_observer(key, old, new) -> NoReturn:
            raise OSError("Observer failed")

        config.add_observer(failing_observer)

        # 修改配置，观察者失败不应该影响配置设置
        config.test_key = "test_value"

        # 配置值应该被正确设置
        assert config.test_key == "test_value"

    def test_multiple_observers(self, tmp_path: Path) -> None:
        """测试多个观察者."""

        class TestConfig(JsonConfig):
            NAME = "multi_observers"

        config = TestConfig()
        call_order = []

        def observer1(key, old, new) -> None:
            call_order.append(1)

        def observer2(key, old, new) -> None:
            call_order.append(2)

        def observer3(key, old, new) -> None:
            call_order.append(3)

        config.add_observer(observer1)
        config.add_observer(observer2)
        config.add_observer(observer3)

        # 修改配置
        config.test_key = "value"

        # 所有观察者都应该被调用
        assert call_order == [1, 2, 3]

    def test_duplicate_observer(self, tmp_path: Path) -> None:
        """测试添加重复观察者."""

        class TestConfig(JsonConfig):
            NAME = "duplicate_observer"

        config = TestConfig()
        call_count = [0]

        def observer(key, old, new) -> None:
            call_count[0] += 1

        # 添加两次相同的观察者
        config.add_observer(observer)
        config.add_observer(observer)

        # 修改配置
        config.test_key = "value"

        # 观察者应该只被调用一次（去重）
        assert call_count[0] == 1


class TestJsonConfigEdgeCases:
    """测试边界情况."""

    def test_config_with_special_characters(self, tmp_path: Path) -> None:
        """测试包含特殊字符的配置."""

        class TestConfig(JsonConfig):
            NAME = "special_chars"

        config = TestConfig()

        # 设置包含特殊字符的值
        config.chinese = "中文测试"
        config.emoji = "🎉🚀"
        config.special = "!@#$%^&*()"

        # 保存配置
        config.save_to_json()

        # 验证可以正确读取
        assert config.chinese == "中文测试"
        assert config.emoji == "🎉🚀"
        assert config.special == "!@#$%^&*()"

    def test_config_directory_creation(self, tmp_path: Path) -> None:
        """测试配置目录自动创建."""
        nested_dir = tmp_path / "nested" / "dirs"

        class TestConfig(JsonConfig):
            NAME = "nested_config"
            ROOT_DIR = nested_dir

        # 实例化时应创建目录
        config = TestConfig()
        assert nested_dir.exists()

        # 配置文件应该在嵌套目录中
        expected_file = nested_dir / "nested_config.json"
        assert config._config_file == expected_file

    def test_default_name_from_class(self, tmp_path: Path) -> None:
        """测试从类名自动生成默认名称."""

        class MyCustomConfig(JsonConfig):
            pass

        config = MyCustomConfig()

        # 验证默认名称是从类名转换而来（去掉Config后缀，转为snake_case）
        assert config._default_name == "my_custom"

    def test_serialize_object_with_dict_error(self, tmp_path: Path) -> None:
        """测试序列化时__dict__访问异常的处理."""

        class BrokenDictClass:
            """一个__dict__属性访问会抛出异常的类."""

            @property
            def __dict__(self) -> None:  # type: ignore[override, return-value]
                raise AttributeError("Cannot access __dict__")

        class TestConfig(JsonConfig):
            NAME = "broken_dict"

        config = TestConfig()
        broken_obj = BrokenDictClass()

        # 测试_default_encoder处理异常的情况
        result = config._default_encoder(broken_obj)

        # 应该回退到字符串表示
        assert isinstance(result, str)

    def test_serialize_object_with_type_error_in_dict(self, tmp_path: Path) -> None:
        """测试序列化时__dict__访问抛出TypeError的处理."""

        class TypeErrorDictClass:
            """一个__dict__属性访问会抛出TypeError的类."""

            def __init__(self) -> None:
                self.value = "test"

        class TestConfig(JsonConfig):
            NAME = "type_error_dict"

        config = TestConfig()
        error_obj = TypeErrorDictClass()

        # 直接修改__dict__为不可访问的形式，测试isinstance检查失败的情况（覆盖行440）
        # 这种情况下不会抛出异常，而是isinstance检查失败，继续到行459

        # 测试_default_encoder处理对象（正常路径，覆盖行438-452）
        result = config._default_encoder(error_obj)

        # 应该返回包含类信息的字典（行448-452）
        assert isinstance(result, dict)
        # 验证字典包含期望的键值对（使用in避免类型检查错误）
        assert "__class__" in result
        assert "value" in result
        assert result["__class__"] == "TypeErrorDictClass"  # ty:ignore[invalid-argument-type]
        assert result["value"] == "test"  # ty:ignore[invalid-argument-type]

    def test_validate_circular_in_tuple(self, tmp_path: Path) -> None:
        """测试元组中的循环引用验证."""

        class TestConfig(JsonConfig):
            NAME = "circular_tuple"

        config = TestConfig()

        # 创建元组（元组本身不可变，但可以包含循环引用的列表）
        inner_list: list = []
        tpl = (inner_list,)
        inner_list.append(tpl)

        # 验证应该失败（检测到循环引用）
        assert config._validate_serializable(tpl) is False

    def test_validate_list_success(self, tmp_path: Path) -> None:
        """测试列表验证成功路径."""

        class TestConfig(JsonConfig):
            NAME = "valid_list"

        config = TestConfig()

        # 创建一个有效的列表（不触发循环引用）
        valid_list = [1, "two", 3.0, True, None]

        # 验证应该成功，覆盖列表验证的成功分支（行574）
        assert config._validate_serializable(valid_list) is True

    def test_validate_dict_success(self, tmp_path: Path) -> None:
        """测试字典验证成功路径."""

        class TestConfig(JsonConfig):
            NAME = "valid_dict"

        config = TestConfig()

        # 创建一个有效的字典（不触发循环引用）
        valid_dict = {"key1": "value1", "key2": 123}

        # 验证应该成功，覆盖字典验证的成功分支（行574）
        assert config._validate_serializable(valid_dict) is True

    def test_validate_basic_type_returns_true(self, tmp_path: Path) -> None:
        """测试基本类型验证直接返回True."""

        class TestConfig(JsonConfig):
            NAME = "basic_validate"

        config = TestConfig()

        # 基本类型应该直接返回True，覆盖行610
        assert config._validate_serializable("string") is True
        assert config._validate_serializable(123) is True
        assert config._validate_serializable(3.14) is True

    def test_validate_other_type_returns_true(self, tmp_path: Path) -> None:
        """测试其他类型验证返回True（会在编码时转换为字符串）."""

        class TestConfig(JsonConfig):
            NAME = "other_validate"

        config = TestConfig()

        # 其他类型（如自定义对象）应该返回True，覆盖行628
        # 因为_default_encoder会处理它们
        class CustomObj:
            pass

        obj = CustomObj()
        assert config._validate_serializable(obj) is True

    def test_save_to_json_os_error_with_backup(self, tmp_path: Path) -> None:
        """测试save_to_json遇到OSError时从备份恢复（覆盖行654-657）."""
        import json

        class TestConfig(JsonConfig):
            NAME = "save_oserror"

        # 首先创建正常配置和备份
        config1 = TestConfig()
        config1.test_key = "original_value"
        config1.save_to_json()

        # 验证备份文件存在且包含原始值
        backup_file = tmp_path / "save_oserror.json.bak"
        assert backup_file.exists()
        with open(backup_file, encoding="utf-8") as f:
            backup_data = json.load(f)
        assert backup_data.get("test_key") == "original_value"

        # 现在模拟save_to_json时失败（通过mock _atomic_write_config抛出OSError）
        config2 = TestConfig()
        config2.new_key = "new_value"

        # Mock原子写入失败，触发异常处理路径（行654-657）
        with patch.object(
            config2, "_atomic_write_config", side_effect=OSError("Write failed")
        ):
            # save_to_json应该捕获异常并尝试从备份恢复（行656-657）
            config2.save_to_json()

        # 验证备份文件仍然存在（恢复后应该保留）
        assert backup_file.exists()

    def test_create_backup_os_error(self, tmp_path: Path) -> None:
        """测试创建备份时的OSError处理."""

        class TestConfig(JsonConfig):
            NAME = "backup_oserror"

        config = TestConfig()
        config.test_key = "test_value"
        config.save_to_json()

        # Mock _backup_file.open 抛出 OSError（覆盖行668-669）
        config_file = tmp_path / "backup_oserror.json"
        tmp_path / "backup_oserror.json.bak"

        # 先确保配置文件存在
        assert config_file.exists()

        # Mock备份文件写入失败，但不应该抛出异常
        with patch.object(Path, "open", side_effect=OSError("Disk full")):
            # 不应该抛出异常，只是记录debug日志
            config._create_backup()

        # 验证不会因为这个错误而崩溃


class TestJsonConfigAtomicWrite:
    """测试原子写入功能."""

    def test_atomic_write_creates_temp_file(self, tmp_path: Path) -> None:
        """测试原子写入创建临时文件."""

        class TestConfig(JsonConfig):
            NAME = "atomic_write"

        config = TestConfig()
        config.test_key = "test_value"

        # 保存配置
        config.save_to_json()

        # 验证最终配置文件存在
        config_file = tmp_path / "atomic_write.json"
        assert config_file.exists()

        # 验证没有残留的临时文件
        temp_files = list(tmp_path.glob("*.tmp"))
        assert len(temp_files) == 0

    def test_atomic_write_permission_error_retry(self, tmp_path: Path) -> None:
        """测试原子写入时PermissionError的重试逻辑."""

        class TestConfig(JsonConfig):
            NAME = "atomic_retry"

        config = TestConfig()
        config.test_key = "test_value"

        # 创建一个占位配置文件并设置只读属性（Windows上模拟占用）
        config_file = tmp_path / "atomic_retry.json"
        config_file.write_text("existing content")

        # 在Windows上，我们模拟第一次删除失败，第二次成功
        call_count = [0]
        original_unlink = Path.unlink

        def mock_unlink(self_path: Path) -> None:
            call_count[0] += 1
            if call_count[0] == 1:
                # 第一次调用抛出PermissionError（模拟文件被占用）
                raise PermissionError("Access denied")
            # 第二次调用正常删除
            original_unlink(self_path)

        with patch.object(Path, "unlink", mock_unlink):
            # 保存配置，应该会在第一次失败后重试
            config.save_to_json()

        # 验证最终文件存在且包含正确的内容
        assert config_file.exists()
        import json

        with open(config_file, encoding="utf-8") as f:
            data = json.load(f)
        assert data["test_key"] == "test_value"

    def test_atomic_write_max_retries_exceeded(self, tmp_path: Path) -> None:
        """测试原子写入时达到最大重试次数（覆盖行391）."""

        class TestConfig(JsonConfig):
            NAME = "atomic_max_retry"

        config = TestConfig()
        config.test_key = "test_value"

        # 创建一个占位配置文件
        config_file = tmp_path / "atomic_max_retry.json"
        config_file.write_text("existing content")

        # Mock unlink总是失败，模拟文件一直被占用（覆盖行391的最后一次重试失败）

        def mock_unlink_always_fail(self_path: Path) -> None:
            # 总是抛出PermissionError
            raise PermissionError("Access denied - file in use")

        with patch.object(Path, "unlink", mock_unlink_always_fail):
            # 保存配置会在5次重试后失败，覆盖行391的raise语句
            import contextlib

            with contextlib.suppress(PermissionError):
                config.save_to_json()

    def test_atomic_write_cleanup_on_error(self, tmp_path: Path) -> None:
        """测试原子写入错误时清理临时文件."""
        import os

        class TestConfig(JsonConfig):
            NAME = "atomic_cleanup"

        config = TestConfig()
        config.test_key = "test_value"

        # Mock os.replace 总是失败，触发异常处理路径（行397-410, 414-415）
        original_replace = os.replace
        replace_call_count = [0]

        def mock_replace(src: str, dst: str) -> None:
            replace_call_count[0] += 1
            # 总是抛出OSError模拟替换失败
            raise OSError("Replace failed")

        with patch("os.replace", mock_replace):
            # 保存配置会失败，但应该清理临时文件
            try:
                config.save_to_json()
            except OSError:
                pass  # 预期会失败
            finally:
                # 恢复原始函数
                os.replace = original_replace  # type: ignore[method-assign]

        # 验证没有残留的临时文件（应该被清理了）
        temp_files = list(tmp_path.glob("*.tmp"))
        assert len(temp_files) == 0, f"发现残留临时文件: {temp_files}"
