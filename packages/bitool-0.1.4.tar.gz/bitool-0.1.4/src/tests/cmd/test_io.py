"""测试 IO 命令模块, 包括文件读写、备份、复制、移动和删除."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from bitool.cmd.io import (
    BackupFileCommand,
    CopyFileCommand,
    DeleteFileCommand,
    MoveFileCommand,
    ReadFileCommand,
    WriteFileCommand,
    backup_file,
)


class TestBackupFile:
    """测试 backup_file 辅助函数."""

    def test_backup_with_auto_path(self, tmp_path: Path) -> None:
        """测试自动生成备份路径."""
        filepath = tmp_path / "test.txt"
        filepath.write_text("content", encoding="utf-8")

        backup_path = backup_file(filepath)

        assert backup_path is not None
        assert backup_path == tmp_path / "test.txt.bak"
        assert backup_path.exists()
        assert backup_path.read_text(encoding="utf-8") == "content"

    def test_backup_with_custom_path(self, tmp_path: Path) -> None:
        """测试自定义备份路径."""
        filepath = tmp_path / "test.txt"
        filepath.write_text("content", encoding="utf-8")
        custom_backup = tmp_path / "backup" / "custom.bak"

        backup_path = backup_file(filepath, custom_backup)

        assert backup_path is not None
        assert backup_path == custom_backup
        assert backup_path.exists()
        assert backup_path.read_text(encoding="utf-8") == "content"

    def test_backup_creates_parent_dir(self, tmp_path: Path) -> None:
        """测试备份时自动创建父目录."""
        filepath = tmp_path / "test.txt"
        filepath.write_text("content", encoding="utf-8")
        backup_path = tmp_path / "nested" / "dir" / "backup.bak"

        result = backup_file(filepath, backup_path)

        assert result is not None
        assert backup_path.exists()

    def test_backup_failure_returns_none(self, tmp_path: Path) -> None:
        """测试备份失败时返回 None."""
        filepath = tmp_path / "test.txt"
        filepath.write_text("content", encoding="utf-8")

        # Mock shutil.copy2 抛出异常
        with patch("bitool.cmd.io.shutil.copy2", side_effect=OSError("权限错误")):
            result = backup_file(filepath)

        assert result is None

    def test_write_file_backup_failure(self, tmp_path: Path) -> None:
        """测试写入文件时备份失败."""
        filepath = tmp_path / "test.txt"
        filepath.write_text("original", encoding="utf-8")

        # Mock shutil.copy2 抛出异常, 导致备份失败
        with patch("bitool.cmd.io.shutil.copy2", side_effect=OSError("备份失败")):
            cmd = WriteFileCommand(
                filepath=filepath, content="new content", backup=True
            )
            result = cmd.run()

        assert result is False

    def test_backup_with_dot_path(self, tmp_path: Path) -> None:
        """测试备份路径为 '.' 时自动生成."""
        filepath = tmp_path / "test.txt"
        filepath.write_text("content", encoding="utf-8")

        backup_path = backup_file(filepath, Path("."))

        assert backup_path is not None
        assert backup_path == tmp_path / "test.txt.bak"


class TestReadFileCommand:
    """测试 ReadFileCommand 类."""

    def test_read_file_success(self, tmp_path: Path) -> None:
        """测试成功读取文件."""
        filepath = tmp_path / "test.txt"
        content = "Hello, World!"
        filepath.write_text(content, encoding="utf-8")

        cmd = ReadFileCommand(filepath=filepath)
        result = cmd.run()

        assert result is True
        assert cmd.content == content

    def test_read_file_not_exists(self, tmp_path: Path) -> None:
        """测试读取不存在的文件."""
        filepath = tmp_path / "nonexistent.txt"

        cmd = ReadFileCommand(filepath=filepath)
        result = cmd.run()

        assert result is False
        assert cmd.content == ""

    def test_read_file_is_directory(self, tmp_path: Path) -> None:
        """测试读取目录而非文件."""
        dir_path = tmp_path / "subdir"
        dir_path.mkdir()

        cmd = ReadFileCommand(filepath=dir_path)
        result = cmd.run()

        assert result is False

    @patch("pathlib.Path.read_text")
    def test_read_file_os_error(self, mock_read: MagicMock, tmp_path: Path) -> None:
        """测试读取文件时发生 OSError."""
        filepath = tmp_path / "test.txt"
        filepath.write_text("content", encoding="utf-8")
        mock_read.side_effect = OSError("读取错误")

        cmd = ReadFileCommand(filepath=filepath)
        result = cmd.run()

        assert result is False

    @patch("pathlib.Path.write_text")
    def test_write_file_os_error(self, mock_write: MagicMock, tmp_path: Path) -> None:
        """测试写入文件时发生 OSError."""
        filepath = tmp_path / "test.txt"
        mock_write.side_effect = OSError("写入错误")

        cmd = WriteFileCommand(filepath=filepath, content="content", backup=False)
        result = cmd.run()

        assert result is False


class TestBackupFileCommand:
    """测试 BackupFileCommand 类."""

    def test_backup_success(self, tmp_path: Path) -> None:
        """测试成功备份文件."""
        filepath = tmp_path / "test.txt"
        filepath.write_text("content", encoding="utf-8")
        backup_path = tmp_path / "backup.bak"

        cmd = BackupFileCommand(filepath=filepath, backup_path=backup_path)
        result = cmd.run()

        assert result is True
        assert backup_path.exists()
        assert backup_path.read_text(encoding="utf-8") == "content"

    def test_backup_file_not_exists(self, tmp_path: Path) -> None:
        """测试备份不存在的文件."""
        filepath = tmp_path / "nonexistent.txt"
        backup_path = tmp_path / "backup.bak"

        cmd = BackupFileCommand(filepath=filepath, backup_path=backup_path)
        result = cmd.run()

        assert result is False

    def test_backup_is_directory(self, tmp_path: Path) -> None:
        """测试备份目录而非文件."""
        dir_path = tmp_path / "subdir"
        dir_path.mkdir()
        backup_path = tmp_path / "backup.bak"

        cmd = BackupFileCommand(filepath=dir_path, backup_path=backup_path)
        result = cmd.run()

        assert result is False


class TestCopyFileCommand:
    """测试 CopyFileCommand 类."""

    def test_copy_success(self, tmp_path: Path) -> None:
        """测试成功复制文件."""
        source = tmp_path / "source.txt"
        source.write_text("content", encoding="utf-8")
        dest = tmp_path / "dest.txt"

        cmd = CopyFileCommand(source=source, destination=dest)
        result = cmd.run()

        assert result is True
        assert dest.exists()
        assert dest.read_text(encoding="utf-8") == "content"

    def test_copy_source_not_exists(self, tmp_path: Path) -> None:
        """测试复制不存在的源文件."""
        source = tmp_path / "nonexistent.txt"
        dest = tmp_path / "dest.txt"

        cmd = CopyFileCommand(source=source, destination=dest)
        result = cmd.run()

        assert result is False

    def test_copy_source_is_directory(self, tmp_path: Path) -> None:
        """测试复制目录而非文件."""
        source = tmp_path / "subdir"
        source.mkdir()
        dest = tmp_path / "dest.txt"

        cmd = CopyFileCommand(source=source, destination=dest)
        result = cmd.run()

        assert result is False

    def test_copy_no_overwrite(self, tmp_path: Path) -> None:
        """测试不覆盖已存在的目标文件."""
        source = tmp_path / "source.txt"
        source.write_text("source content", encoding="utf-8")
        dest = tmp_path / "dest.txt"
        dest.write_text("dest content", encoding="utf-8")

        cmd = CopyFileCommand(source=source, destination=dest, overwrite=False)
        result = cmd.run()

        assert result is False
        # 目标文件不应被修改
        assert dest.read_text(encoding="utf-8") == "dest content"

    def test_copy_creates_parent_dir(self, tmp_path: Path) -> None:
        """测试复制时自动创建父目录."""
        source = tmp_path / "source.txt"
        source.write_text("content", encoding="utf-8")
        dest = tmp_path / "nested" / "dir" / "dest.txt"

        cmd = CopyFileCommand(source=source, destination=dest)
        result = cmd.run()

        assert result is True
        assert dest.exists()

    @patch("shutil.copy2")
    def test_copy_os_error(self, mock_copy: MagicMock, tmp_path: Path) -> None:
        """测试复制文件时发生 OSError."""
        source = tmp_path / "source.txt"
        source.write_text("content", encoding="utf-8")
        dest = tmp_path / "dest.txt"
        mock_copy.side_effect = OSError("复制错误")

        cmd = CopyFileCommand(source=source, destination=dest)
        result = cmd.run()

        assert result is False


class TestMoveFileCommand:
    """测试 MoveFileCommand 类."""

    def test_move_success(self, tmp_path: Path) -> None:
        """测试成功移动文件."""
        source = tmp_path / "source.txt"
        source.write_text("content", encoding="utf-8")
        dest = tmp_path / "dest.txt"

        cmd = MoveFileCommand(source=source, destination=dest)
        result = cmd.run()

        assert result is True
        assert dest.exists()
        assert not source.exists()
        assert dest.read_text(encoding="utf-8") == "content"

    def test_move_source_not_exists(self, tmp_path: Path) -> None:
        """测试移动不存在的源文件."""
        source = tmp_path / "nonexistent.txt"
        dest = tmp_path / "dest.txt"

        cmd = MoveFileCommand(source=source, destination=dest)
        result = cmd.run()

        assert result is False

    def test_move_source_is_directory(self, tmp_path: Path) -> None:
        """测试移动目录而非文件."""
        source = tmp_path / "subdir"
        source.mkdir()
        dest = tmp_path / "dest.txt"

        cmd = MoveFileCommand(source=source, destination=dest)
        result = cmd.run()

        assert result is False

    def test_move_no_overwrite(self, tmp_path: Path) -> None:
        """测试不覆盖已存在的目标文件."""
        source = tmp_path / "source.txt"
        source.write_text("source content", encoding="utf-8")
        dest = tmp_path / "dest.txt"
        dest.write_text("dest content", encoding="utf-8")

        cmd = MoveFileCommand(source=source, destination=dest, overwrite=False)
        result = cmd.run()

        assert result is False
        # 源文件不应被移动
        assert source.exists()

    def test_move_creates_parent_dir(self, tmp_path: Path) -> None:
        """测试移动时自动创建父目录."""
        source = tmp_path / "source.txt"
        source.write_text("content", encoding="utf-8")
        dest = tmp_path / "nested" / "dir" / "dest.txt"

        cmd = MoveFileCommand(source=source, destination=dest)
        result = cmd.run()

        assert result is True
        assert dest.exists()

    @patch("shutil.move")
    def test_move_os_error(self, mock_move: MagicMock, tmp_path: Path) -> None:
        """测试移动文件时发生 OSError."""
        source = tmp_path / "source.txt"
        source.write_text("content", encoding="utf-8")
        dest = tmp_path / "dest.txt"
        mock_move.side_effect = OSError("移动错误")

        cmd = MoveFileCommand(source=source, destination=dest)
        result = cmd.run()

        assert result is False


class TestDeleteFileCommand:
    """测试 DeleteFileCommand 类."""

    def test_delete_success(self, tmp_path: Path) -> None:
        """测试成功删除文件."""
        filepath = tmp_path / "test.txt"
        filepath.write_text("content", encoding="utf-8")

        cmd = DeleteFileCommand(filepath=filepath)
        result = cmd.run()

        assert result is True
        assert not filepath.exists()

    def test_delete_not_exists(self, tmp_path: Path) -> None:
        """测试删除不存在的文件."""
        filepath = tmp_path / "nonexistent.txt"

        cmd = DeleteFileCommand(filepath=filepath)
        result = cmd.run()

        assert result is False

    def test_delete_not_exists_force(self, tmp_path: Path) -> None:
        """测试强制删除不存在的文件."""
        filepath = tmp_path / "nonexistent.txt"

        cmd = DeleteFileCommand(filepath=filepath, force=True)
        result = cmd.run()

        assert result is True

    def test_delete_is_directory(self, tmp_path: Path) -> None:
        """测试删除目录而非文件."""
        dir_path = tmp_path / "subdir"
        dir_path.mkdir()

        cmd = DeleteFileCommand(filepath=dir_path)
        result = cmd.run()

        assert result is False

    @patch("pathlib.Path.unlink")
    def test_delete_os_error(self, mock_unlink: MagicMock, tmp_path: Path) -> None:
        """测试删除文件时发生 OSError."""
        filepath = tmp_path / "test.txt"
        filepath.write_text("content", encoding="utf-8")
        mock_unlink.side_effect = OSError("删除错误")

        cmd = DeleteFileCommand(filepath=filepath)
        result = cmd.run()

        assert result is False


class TestWriteFileCommand:
    """测试 WriteFileCommand 类."""

    def test_write_new_file(self, tmp_path: Path) -> None:
        """测试写入新文件."""
        filepath = tmp_path / "test.txt"
        content = "Hello, World!"

        cmd = WriteFileCommand(filepath=filepath, content=content)
        result = cmd.run()

        assert result is True
        assert filepath.exists()
        assert filepath.read_text(encoding="utf-8") == content

    def test_overwrite_existing_file(self, tmp_path: Path) -> None:
        """测试覆盖已存在的文件."""
        filepath = tmp_path / "test.txt"
        filepath.write_text("Original content", encoding="utf-8")

        new_content = "New content"
        cmd = WriteFileCommand(
            filepath=filepath, content=new_content, overwrite=True, backup=False
        )
        result = cmd.run()

        assert result is True
        assert filepath.read_text(encoding="utf-8") == new_content

    def test_no_overwrite_existing_file(self, tmp_path: Path) -> None:
        """测试不覆盖已存在的文件."""
        filepath = tmp_path / "test.txt"
        original_content = "Original content"
        filepath.write_text(original_content, encoding="utf-8")

        new_content = "New content"
        cmd = WriteFileCommand(
            filepath=filepath, content=new_content, overwrite=False, backup=False
        )
        result = cmd.run()

        assert result is False
        # 原文件内容不应被修改
        assert filepath.read_text(encoding="utf-8") == original_content

    def test_backup_existing_file(self, tmp_path: Path) -> None:
        """测试备份已存在的文件."""
        filepath = tmp_path / "test.txt"
        original_content = "Original content"
        filepath.write_text(original_content, encoding="utf-8")

        new_content = "New content"
        cmd = WriteFileCommand(
            filepath=filepath, content=new_content, overwrite=True, backup=True
        )
        result = cmd.run()

        assert result is True
        # 新文件应包含新内容
        assert filepath.read_text(encoding="utf-8") == new_content
        # 备份文件应包含原内容
        backup_path = tmp_path / "test.txt.bak"
        assert backup_path.exists()
        assert backup_path.read_text(encoding="utf-8") == original_content

    def test_no_backup_when_disabled(self, tmp_path: Path) -> None:
        """测试禁用备份时不创建备份文件."""
        filepath = tmp_path / "test.txt"
        original_content = "Original content"
        filepath.write_text(original_content, encoding="utf-8")

        new_content = "New content"
        cmd = WriteFileCommand(
            filepath=filepath, content=new_content, overwrite=True, backup=False
        )
        result = cmd.run()

        assert result is True
        # 新文件应包含新内容
        assert filepath.read_text(encoding="utf-8") == new_content
        # 不应有备份文件
        backup_path = tmp_path / "test.txt.bak"
        assert not backup_path.exists()

    def test_create_parent_directory(self, tmp_path: Path) -> None:
        """测试自动创建父目录."""
        filepath = tmp_path / "subdir" / "nested" / "test.txt"
        content = "Nested content"

        cmd = WriteFileCommand(filepath=filepath, content=content)
        result = cmd.run()

        assert result is True
        assert filepath.exists()
        assert filepath.read_text(encoding="utf-8") == content
