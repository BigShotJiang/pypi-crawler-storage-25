"""PyPack 打包技能测试.

测试 pypack 模块的所有核心功能.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from bitool.apps.pypack.config import PyPackConfig
from bitool.apps.pypack.models.dependency import Dependency
from bitool.apps.pypack.models.entryfile import EntryFile
from bitool.apps.pypack.models.project import Project
from bitool.apps.pypack.models.solution import Solution
from bitool.apps.pypack.workflow import PackageWorkflow, WorkflowConfig


class TestDependency:
    """Dependency 模型测试."""

    def test_create_dependency(self) -> None:
        """测试创建依赖项."""
        dep = Dependency(name="requests", version=">=2.28.0")
        assert dep.name == "requests"
        assert dep.version == ">=2.28.0"
        assert dep.extras == []

    def test_dependency_str(self) -> None:
        """测试依赖项字符串表示."""
        dep = Dependency(name="requests", version=">=2.28.0")
        assert str(dep) == "requests>=2.28.0"

        dep_no_version = Dependency(name="requests")
        assert str(dep_no_version) == "requests"

    def test_dependency_to_dict(self) -> None:
        """测试依赖项转字典."""
        dep = Dependency(name="requests", version=">=2.28.0")
        d = dep.to_dict()
        assert d["name"] == "requests"
        assert d["version"] == ">=2.28.0"

    def test_dependency_from_string(self) -> None:
        """测试从字符串创建依赖项."""
        dep = Dependency.from_string("requests>=2.28.0")
        assert dep.name == "requests"
        assert dep.version == ">=2.28.0"


class TestEntryFile:
    """EntryFile 模型测试."""

    def test_create_entry_file(self, tmp_path: Path) -> None:
        """测试创建入口文件."""
        source = tmp_path / "main.py"
        source.touch()

        entry = EntryFile(project_name="myapp", source_file=source)
        assert entry.project_name == "myapp"
        assert entry.source_file == source
        assert entry.output_stem == "main"

    def test_entry_file_with_project_root(self, tmp_path: Path) -> None:
        """测试带项目根目录的入口文件."""
        project_root = tmp_path / "myproject"
        project_root.mkdir()
        source = project_root / "src" / "main.py"
        source.parent.mkdir()
        source.touch()

        entry = EntryFile(
            project_name="myapp", source_file=source, project_root=project_root
        )
        assert entry.relative_path == Path("src/main.py")

    def test_entry_file_without_project_root(self, tmp_path: Path) -> None:
        """测试不带项目根目录的入口文件."""
        source = tmp_path / "app.py"
        source.touch()

        entry = EntryFile(project_name="myapp", source_file=source)
        assert entry.relative_path == "app.py"

    def test_entry_file_str(self, tmp_path: Path) -> None:
        """测试入口文件字符串表示."""
        source = tmp_path / "main.py"
        source.touch()

        entry = EntryFile(project_name="myapp", source_file=source)
        assert str(entry) == "myapp:main.py"

    def test_entry_file_to_dict(self, tmp_path: Path) -> None:
        """测试入口文件转字典."""
        source = tmp_path / "main.py"
        source.touch()

        entry = EntryFile(project_name="myapp", source_file=source)
        d = entry.to_dict()
        assert d["project_name"] == "myapp"
        assert d["source_file"] == str(source)
        assert d["output_stem"] == "main"

    @pytest.mark.parametrize(
        ("filename", "expected_stem"),
        [
            ("main.py", "main"),
            ("app.py", "app"),
            ("cli_tool.py", "cli_tool"),
            ("__main__.py", "__main__"),
        ],
    )
    def test_entry_file_output_stem(
        self, tmp_path: Path, filename: str, expected_stem: str
    ) -> None:
        """测试不同文件名的输出茎."""
        source = tmp_path / filename
        source.touch()

        entry = EntryFile(project_name="myapp", source_file=source)
        assert entry.output_stem == expected_stem


class TestProject:
    """Project 模型测试."""

    def test_create_project(self, tmp_path: Path) -> None:
        """测试创建项目."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nname = "test"\nversion = "1.0.0"')

        project = Project(
            name="test",
            version="1.0.0",
            description="Test project",
            project_dir=tmp_path,
            pyproject_file=pyproject,
            dependencies=["requests"],
        )

        assert project.name == "test"
        assert project.version == "1.0.0"
        assert len(project.dependencies) == 1

    def test_project_str(self, tmp_path: Path) -> None:
        """测试项目字符串表示."""
        pyproject = tmp_path / "pyproject.toml"
        project = Project(
            name="test",
            version="1.0.0",
            description="Test",
            project_dir=tmp_path,
            pyproject_file=pyproject,
        )
        assert "test==1.0.0" in str(project)

    def test_project_repr(self, tmp_path: Path) -> None:
        """测试项目 repr 表示."""
        pyproject = tmp_path / "pyproject.toml"
        project = Project(
            name="test",
            version="1.0.0",
            description="Test",
            project_dir=tmp_path,
            pyproject_file=pyproject,
            dependencies=["requests", "numpy"],
        )
        assert "test==1.0.0" in repr(project)
        assert "2 deps" in repr(project)

    def test_project_get_info(self, tmp_path: Path) -> None:
        """测试获取项目信息."""
        pyproject = tmp_path / "pyproject.toml"
        project = Project(
            name="test",
            version="1.0.0",
            description="Test project",
            project_dir=tmp_path,
            pyproject_file=pyproject,
            dependencies=["requests>=2.28.0", "numpy"],
        )

        info = project.get_project_info()
        assert info["name"] == "test"
        assert info["version"] == "1.0.0"
        assert info["description"] == "Test project"
        assert info["project_dir"] == str(tmp_path)
        assert len(info["dependencies"]) == 2
        assert "is_gui" in info

    @pytest.mark.parametrize(
        ("dependencies", "expected_gui"),
        [
            (["requests", "numpy"], False),
            (["PyQt5", "requests"], True),
            (["PySide6"], True),
            (["gui-framework"], True),
            (["desktop-app"], True),
        ],
    )
    def test_project_is_gui(
        self, tmp_path: Path, dependencies: list[str], expected_gui: bool
    ) -> None:
        """测试 GUI 项目判断."""
        pyproject = tmp_path / "pyproject.toml"
        project = Project(
            name="test",
            version="1.0.0",
            description="Test",
            project_dir=tmp_path,
            pyproject_file=pyproject,
            dependencies=dependencies,
        )
        assert project.is_gui_project == expected_gui


class TestSolution:
    """Solution 模型测试."""

    def test_scan_projects(self, tmp_path: Path) -> None:
        """测试扫描项目."""
        # 创建一个项目
        project_dir = tmp_path / "myproject"
        project_dir.mkdir()
        pyproject = project_dir / "pyproject.toml"
        pyproject.write_text(
            '[project]\nname = "myproject"\nversion = "1.0.0"\ndescription = "Test"'
        )

        solution = Solution.from_directory(tmp_path)
        assert len(solution.projects) == 1
        assert "myproject" in solution.projects

    def test_solution_repr(self, tmp_path: Path) -> None:
        """测试解决方案的 repr 表示."""
        project_dir = tmp_path / "myproject"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "myproject"\nversion = "1.0.0"'
        )

        solution = Solution.from_directory(tmp_path)
        repr_str = repr(solution)
        assert "Solution" in repr_str
        assert "projects: 1" in repr_str
        assert "time_used=" in repr_str

    def test_solution_elapsed_time(self, tmp_path: Path) -> None:
        """测试解决方案的耗时计算."""
        solution = Solution.from_directory(tmp_path)
        elapsed = solution.elapsed_time
        assert elapsed >= 0

    def test_solution_dependencies(self, tmp_path: Path) -> None:
        """测试获取所有依赖."""
        # 创建两个项目
        for i in range(2):
            project_dir = tmp_path / f"project{i}"
            project_dir.mkdir()
            deps = (
                'dependencies = ["requests", "numpy"]'
                if i == 0
                else 'dependencies = ["flask"]'
            )
            (project_dir / "pyproject.toml").write_text(
                f'[project]\nname = "project{i}"\nversion = "1.0.0"\n{deps}'
            )

        solution = Solution.from_directory(tmp_path)
        all_deps = solution.dependencies
        assert "requests" in all_deps
        assert "numpy" in all_deps
        assert "flask" in all_deps

    def test_find_matching_projects(self, tmp_path: Path) -> None:
        """测试查找匹配的项目."""
        for name in ["myapp-core", "myapp-ui", "other-project"]:
            project_dir = tmp_path / name
            project_dir.mkdir()
            (project_dir / "pyproject.toml").write_text(
                f'[project]\nname = "{name}"\nversion = "1.0.0"'
            )

        solution = Solution.from_directory(tmp_path)

        # 精确匹配
        matches = solution.find_matching_projects("myapp")
        assert len(matches) == 2
        assert "myapp-core" in matches
        assert "myapp-ui" in matches

        # 无匹配
        matches = solution.find_matching_projects("nonexistent")
        assert len(matches) == 0

        # 空模式
        matches = solution.find_matching_projects("")
        assert len(matches) == 0

    def test_resolve_project_name_exact(self, tmp_path: Path) -> None:
        """测试精确解析项目名称."""
        project_dir = tmp_path / "myapp"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "myapp"\nversion = "1.0.0"'
        )

        solution = Solution.from_directory(tmp_path)
        resolved = solution.resolve_project_name("myapp")
        assert resolved == "myapp"

    def test_resolve_project_name_fuzzy(self, tmp_path: Path) -> None:
        """测试模糊解析项目名称."""
        project_dir = tmp_path / "myapp-core"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "myapp-core"\nversion = "1.0.0"'
        )

        solution = Solution.from_directory(tmp_path)
        resolved = solution.resolve_project_name("myapp")
        assert resolved == "myapp-core"

    def test_resolve_project_name_auto_select(self, tmp_path: Path) -> None:
        """测试自动选择唯一项目."""
        project_dir = tmp_path / "only-project"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "only-project"\nversion = "1.0.0"'
        )

        solution = Solution.from_directory(tmp_path)
        resolved = solution.resolve_project_name(None)
        assert resolved == "only-project"

    def test_resolve_project_name_ambiguous(self, tmp_path: Path) -> None:
        """测试模糊匹配有多个结果时返回 None."""
        for name in ["myapp-core", "myapp-ui"]:
            project_dir = tmp_path / name
            project_dir.mkdir()
            (project_dir / "pyproject.toml").write_text(
                f'[project]\nname = "{name}"\nversion = "1.0.0"'
            )

        solution = Solution.from_directory(tmp_path)
        resolved = solution.resolve_project_name("myapp")
        assert resolved is None


class TestWorkflowConfig:
    """WorkflowConfig 测试."""

    def test_default_config(self, tmp_path: Path) -> None:
        """测试默认配置."""
        config = WorkflowConfig(directory=tmp_path)
        assert config.directory == tmp_path
        assert config.python_version == "3.8.10"
        assert config.loader_type == "console"
        assert config.max_concurrent == 4

    def test_custom_config(self, tmp_path: Path) -> None:
        """测试自定义配置."""
        config = WorkflowConfig(
            directory=tmp_path,
            python_version="3.10.0",
            loader_type="gui",
            max_concurrent=8,
        )
        assert config.python_version == "3.10.0"
        assert config.loader_type == "gui"
        assert config.max_concurrent == 8


class TestPackageWorkflow:
    """PackageWorkflow 测试."""

    def test_list_projects(self, tmp_path: Path) -> None:
        """测试列出项目."""
        # 创建项目
        project_dir = tmp_path / "testproj"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "testproj"\nversion = "1.0.0"\ndescription = "Test"'
        )

        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        # 应该不抛出异常
        workflow.list_projects()

    def test_clean_project(self, tmp_path: Path) -> None:
        """测试清理项目."""
        # 创建构建目录
        build_dir = tmp_path / ".cbuild"
        build_dir.mkdir()
        (build_dir / "temp.txt").write_text("test")

        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        workflow.clean_project()
        assert not build_dir.exists()

    def test_run_project_not_found(self, tmp_path: Path) -> None:
        """测试运行不存在的项目."""
        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        # 应该不抛出异常
        workflow.run_project("nonexistent")

    def test_workflow_config_properties(self, tmp_path: Path) -> None:
        """测试工作流配置属性."""
        config = WorkflowConfig(directory=tmp_path)

        assert config.dist_dir == tmp_path / "dist"
        assert config.build_dir == tmp_path / ".cbuild"

    def test_workflow_solution_property(self, tmp_path: Path) -> None:
        """测试解决方案属性."""
        project_dir = tmp_path / "myapp"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "myapp"\nversion = "1.0.0"'
        )

        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        solution = workflow.solution
        assert len(solution.projects) == 1
        assert "myapp" in solution.projects

    def test_find_executable(self, tmp_path: Path) -> None:
        """测试查找可执行文件."""
        build_dir = tmp_path / ".cbuild"
        build_dir.mkdir()

        # 创建可执行文件
        exe = build_dir / "myapp.exe"
        exe.touch()

        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        found = workflow._find_executable("myapp")
        assert found == exe

    def test_find_executable_nested(self, tmp_path: Path) -> None:
        """测试查找嵌套的可执行文件."""
        build_dir = tmp_path / ".cbuild"
        project_build = build_dir / "src" / "myapp"
        project_build.mkdir(parents=True)

        exe = project_build / "myapp.exe"
        exe.touch()

        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        found = workflow._find_executable("myapp")
        assert found == exe

    def test_find_executable_not_found(self, tmp_path: Path) -> None:
        """测试找不到可执行文件."""
        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        found = workflow._find_executable("nonexistent")
        assert found is None

    @pytest.mark.parametrize(
        ("loader_type", "archive_type"),
        [("console", None), ("gui", None), ("console", "zip"), ("gui", "tar")],
    )
    def test_workflow_config_variants(
        self, tmp_path: Path, loader_type: str, archive_type: str | None
    ) -> None:
        """测试不同的工作流配置."""
        config = WorkflowConfig(
            directory=tmp_path, loader_type=loader_type, archive_type=archive_type
        )

        workflow = PackageWorkflow(root_dir=tmp_path, config=config)
        assert workflow.config.loader_type == loader_type
        assert workflow.config.archive_type == archive_type


class TestPyPackConfig:
    """PyPackConfig 测试."""

    def test_config_defaults(self) -> None:
        """测试配置默认值."""
        config = PyPackConfig()
        assert config.DEFAULT_PYTHON_VERSION == "3.8.10"
        assert config.DEFAULT_LOADER_TYPE == "console"
        assert config.DEFAULT_MIRROR == "aliyun"
        assert config.DEFAULT_MAX_WORKERS == 4


class TestSourcePacker:
    """PySourcePacker 测试."""

    def test_no_infinite_recursion(self, tmp_path: Path) -> None:
        """测试不会无限递归。"""
        from bitool.apps.pypack.components.sourcepacker import PySourcePacker

        # 创建项目结构
        project_dir = tmp_path / "testproject"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "testproject"\nversion = "1.0.0"\ndescription = "Test"'
        )
        (project_dir / "main.py").write_text('print("hello")')

        # 创建子目录和文件
        src_dir = project_dir / "src"
        src_dir.mkdir()
        (src_dir / "module.py").write_text('print("module")')

        # 打包器应该在复制时跳过 .cbuild 目录
        packer = PySourcePacker(root_dir=tmp_path)

        # 执行打包（不应该无限递归）
        success = packer.run()
        assert success is True

        # 验证 .cbuild 目录存在且包含项目
        cbuild_dir = tmp_path / ".cbuild"
        assert cbuild_dir.exists()

        # 验证 .cbuild 内部没有嵌套的 .cbuild
        nested_cbuild = cbuild_dir / "src" / "testproject" / ".cbuild"
        assert not nested_cbuild.exists(), "不应该有嵌套的 .cbuild 目录"

    def test_skip_cbuild_directory(self, tmp_path: Path) -> None:
        """测试跳过 .cbuild 目录。"""
        from bitool.apps.pypack.components.sourcepacker import PySourcePacker

        # 创建 .cbuild 目录和内部文件
        cbuild_dir = tmp_path / ".cbuild"
        cbuild_dir.mkdir()
        (cbuild_dir / "should_skip.txt").write_text("skip me")

        # 创建正常项目
        project_dir = tmp_path / "myproject"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "myproject"\nversion = "1.0.0"\ndescription = "Test"'
        )

        packer = PySourcePacker(root_dir=tmp_path)
        success = packer.run()
        assert success is True

    def test_scan_projects(self, tmp_path: Path) -> None:
        """测试项目扫描."""
        from bitool.apps.pypack.components.sourcepacker import PySourcePacker

        # 创建多个项目
        for i in range(3):
            project_dir = tmp_path / f"project{i}"
            project_dir.mkdir()
            (project_dir / "pyproject.toml").write_text(
                f'[project]\nname = "project{i}"\nversion = "1.0.0"'
            )

        # 创建应该在 .cbuild 中被跳过的项目
        cbuild_project = tmp_path / ".cbuild" / "skipped"
        cbuild_project.mkdir(parents=True)
        (cbuild_project / "pyproject.toml").write_text(
            '[project]\nname = "skipped"\nversion = "1.0.0"'
        )

        packer = PySourcePacker(root_dir=tmp_path)
        projects = packer._scan_projects()

        assert len(projects) == 3

    def test_should_ignore_patterns(self, tmp_path: Path) -> None:
        """测试忽略模式."""
        from bitool.apps.pypack.components.sourcepacker import PySourcePacker

        packer = PySourcePacker(root_dir=tmp_path)

        # 测试各种应该被忽略的模式
        assert packer._should_ignore(tmp_path / "__pycache__") is True
        assert packer._should_ignore(tmp_path / "test.pyc") is True
        assert packer._should_ignore(tmp_path / "test.pyo") is True
        assert packer._should_ignore(tmp_path / ".git") is True
        assert packer._should_ignore(tmp_path / ".pytest_cache") is True
        assert packer._should_ignore(tmp_path / "test.log") is True

        # 测试不应该被忽略的文件
        assert packer._should_ignore(tmp_path / "main.py") is False
        assert packer._should_ignore(tmp_path / "module.txt") is False

    def test_pack_project_with_src_layout(self, tmp_path: Path) -> None:
        """测试 src layout 项目打包."""
        from bitool.apps.pypack.components.sourcepacker import PySourcePacker

        # 创建 src layout 项目
        project_dir = tmp_path / "myapp"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "myapp"\nversion = "1.0.0"'
        )

        # 创建 src 子目录
        src_dir = project_dir / "src" / "mypackage"
        src_dir.mkdir(parents=True)
        (src_dir / "__init__.py").write_text("")
        (src_dir / "module.py").write_text("# module")

        packer = PySourcePacker(root_dir=tmp_path)
        size = packer._pack_project(project_dir)

        # 验证打包后的结构
        cbuild_src = tmp_path / ".cbuild" / "src" / "myapp" / "src" / "mypackage"
        assert cbuild_src.exists()
        assert (cbuild_src / "module.py").exists()
        assert size > 0

    def test_ensure_entry_file_from_scripts(self, tmp_path: Path) -> None:
        """测试从 scripts 配置创建入口文件."""
        from bitool.apps.pypack.components.sourcepacker import PySourcePacker

        project_dir = tmp_path / "myapp"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "myapp"\nversion = "1.0.0"\n'
            '[project.scripts]\nmyapp = "myapp.cli:main"'
        )

        source_dir = tmp_path / ".cbuild" / "src" / "myapp"
        source_dir.mkdir(parents=True)

        packer = PySourcePacker(root_dir=tmp_path)
        packer._ensure_entry_file(project_dir, source_dir)

        # 验证 main.py 已创建
        main_file = source_dir / "main.py"
        assert main_file.exists()
        content = main_file.read_text(encoding="utf-8")
        assert "myapp.cli" in content
        assert "main" in content

    def test_generate_main_from_script(self, tmp_path: Path) -> None:
        """测试生成 main.py 代码."""
        from bitool.apps.pypack.components.sourcepacker import PySourcePacker

        packer = PySourcePacker(root_dir=tmp_path)

        # 测试带冒号的脚本
        code = packer._generate_main_from_script("mymodule.cli:run")
        assert "from mymodule.cli import run" in code
        assert "sys.exit(run())" in code

        # 测试不带冒号的脚本
        code = packer._generate_main_from_script("mymodule.main")
        assert "from mymodule.main import main" in code


class TestArchiver:
    """PyArchiver 测试."""

    def test_archive_zip(self, tmp_path: Path) -> None:
        """测试 ZIP 归档."""
        from bitool.apps.pypack.components.archiver import PyArchiver

        # 创建构建目录
        build_dir = tmp_path / ".cbuild"
        build_dir.mkdir()
        (build_dir / "test.txt").write_text("test content")

        archiver = PyArchiver(root_dir=tmp_path, build_dir=build_dir)
        success = archiver.run("zip")

        assert success is True
        # 验证归档文件已创建
        archive_file = tmp_path / f"{tmp_path.name}_package.zip"
        assert archive_file.exists()

    def test_archive_tar(self, tmp_path: Path) -> None:
        """测试 TAR 归档."""
        from bitool.apps.pypack.components.archiver import PyArchiver

        build_dir = tmp_path / ".cbuild"
        build_dir.mkdir()
        (build_dir / "test.txt").write_text("test content")

        archiver = PyArchiver(root_dir=tmp_path, build_dir=build_dir)
        success = archiver.run("tar")

        assert success is True

    def test_archive_invalid_format(self, tmp_path: Path) -> None:
        """测试无效归档格式."""
        from bitool.apps.pypack.components.archiver import PyArchiver

        build_dir = tmp_path / ".cbuild"
        build_dir.mkdir()

        archiver = PyArchiver(root_dir=tmp_path, build_dir=build_dir)
        success = archiver.run("invalid")

        assert success is False

    def test_archive_missing_build_dir(self, tmp_path: Path) -> None:
        """测试构建目录不存在."""
        from bitool.apps.pypack.components.archiver import PyArchiver

        archiver = PyArchiver(root_dir=tmp_path)
        success = archiver.run("zip")

        assert success is False

    def test_archive_default_build_dir(self, tmp_path: Path) -> None:
        """测试默认构建目录."""
        from bitool.apps.pypack.components.archiver import PyArchiver

        build_dir = tmp_path / ".cbuild"
        build_dir.mkdir()
        (build_dir / "test.txt").write_text("content")

        # 不指定 build_dir，应该自动使用 .cbuild
        archiver = PyArchiver(root_dir=tmp_path)
        success = archiver.run("zip")

        assert success is True

    @pytest.mark.parametrize(
        "archive_format", ["zip", "tar", "gztar", "bztar", "xztar"]
    )
    def test_archive_formats(self, tmp_path: Path, archive_format: str) -> None:
        """测试各种归档格式."""
        from bitool.apps.pypack.components.archiver import PyArchiver

        build_dir = tmp_path / ".cbuild"
        build_dir.mkdir()
        (build_dir / "test.txt").write_text("content")

        archiver = PyArchiver(root_dir=tmp_path, build_dir=build_dir)
        success = archiver.run(archive_format)

        assert success is True


class TestLoaderGenerator:
    """PyLoaderGenerator 测试."""

    def test_generate_source_code(self, tmp_path: Path) -> None:
        """测试生成源代码."""
        from bitool.apps.pypack.components.loader import PyLoaderGenerator

        python_exe = tmp_path / "python.exe"
        python_exe.touch()

        loader_gen = PyLoaderGenerator(
            root_dir=tmp_path,
            project_name="myapp",
            python_exe=python_exe,
            script_name="main.py",
            loader_type="console",
        )

        source_file = loader_gen._generate_source()

        assert source_file is not None
        assert source_file.exists()
        assert source_file.name == "myapp_loader.c"

        # 验证生成的 C 代码
        content = source_file.read_text(encoding="utf-8")
        assert "main(int argc" in content
        assert "CreateProcessA" in content

    def test_generate_gui_loader(self, tmp_path: Path) -> None:
        """测试生成 GUI 加载器."""
        from bitool.apps.pypack.components.loader import PyLoaderGenerator

        python_exe = tmp_path / "python.exe"
        python_exe.touch()

        loader_gen = PyLoaderGenerator(
            root_dir=tmp_path,
            project_name="guiapp",
            python_exe=python_exe,
            loader_type="gui",
        )

        source_file = loader_gen._generate_source()

        assert source_file is not None
        content = source_file.read_text(encoding="utf-8")
        assert "guiapp" in content

    def test_generate_with_custom_script(self, tmp_path: Path) -> None:
        """测试自定义脚本名称."""
        from bitool.apps.pypack.components.loader import PyLoaderGenerator

        python_exe = tmp_path / "python.exe"
        python_exe.touch()

        loader_gen = PyLoaderGenerator(
            root_dir=tmp_path,
            project_name="myapp",
            python_exe=python_exe,
            script_name="app.py",
        )

        source_file = loader_gen._generate_source()

        assert source_file is not None
        content = source_file.read_text(encoding="utf-8")
        assert "app.py" in content

    def test_compile_no_compiler(self, tmp_path: Path) -> None:
        """测试无编译器时的行为."""
        from bitool.apps.pypack.components.loader import PyLoaderGenerator

        python_exe = tmp_path / "python.exe"
        python_exe.touch()

        source_file = tmp_path / "test.c"
        source_file.write_text("int main() { return 0; }")

        loader_gen = PyLoaderGenerator(
            root_dir=tmp_path, project_name="myapp", python_exe=python_exe
        )

        # 在没有编译器的环境下应该返回 None
        exe_file = loader_gen._compile(source_file)
        # 可能返回 None 或 Path（如果有编译器）
        assert exe_file is None or exe_file.exists()


class TestEmbedInstaller:
    """EmbedInstaller 测试."""

    def test_embed_dir_property(self, tmp_path: Path) -> None:
        """测试嵌入目录属性."""
        from bitool.apps.pypack.components.embedinstaller import EmbedInstaller

        installer = EmbedInstaller(root_dir=tmp_path)
        expected_dir = tmp_path / ".cbuild" / "python"

        assert installer.embed_dir == expected_dir

    def test_arch_property(self, tmp_path: Path) -> None:
        """测试架构属性."""
        from bitool.apps.pypack.components.embedinstaller import EmbedInstaller

        installer = EmbedInstaller(root_dir=tmp_path)
        arch = installer.arch
        # 应该是有效的架构名称
        assert arch in {"amd64", "arm64"}

    def test_cache_dir_property(self, tmp_path: Path) -> None:
        """测试缓存目录属性."""
        from bitool.apps.pypack.components.embedinstaller import EmbedInstaller

        custom_cache = tmp_path / "custom_cache"
        installer = EmbedInstaller(root_dir=tmp_path, cache_dir=custom_cache)

        assert installer.actual_cache_dir == custom_cache

    def test_default_cache_dir(self, tmp_path: Path) -> None:
        """测试默认缓存目录."""
        from bitool.apps.pypack.components.embedinstaller import (
            _DEFAULT_CACHE_DIR,
            EmbedInstaller,
        )

        installer = EmbedInstaller(root_dir=tmp_path)
        assert installer.actual_cache_dir == _DEFAULT_CACHE_DIR

    def test_offline_mode(self, tmp_path: Path) -> None:
        """测试离线模式."""
        from bitool.apps.pypack.components.embedinstaller import EmbedInstaller

        # 使用空的临时缓存目录, 确保没有缓存文件
        empty_cache = tmp_path / "empty_cache"
        installer = EmbedInstaller(
            root_dir=tmp_path, offline=True, cache_dir=empty_cache
        )
        # 离线模式下，如果没有缓存应该返回 False
        success = installer.run()
        # 因为没有缓存且离线，应该失败
        assert success is False

    def test_already_installed(self, tmp_path: Path) -> None:
        """测试已安装的情况."""
        from bitool.apps.pypack.components.embedinstaller import EmbedInstaller

        # 创建已安装的目录结构
        embed_dir = tmp_path / ".cbuild" / "python"
        embed_dir.mkdir(parents=True)
        (embed_dir / "python.exe").touch()

        installer = EmbedInstaller(root_dir=tmp_path)
        success = installer.run()
        assert success is True


class TestLibPacker:
    """PyLibPacker 测试."""

    def test_create_packer(self, tmp_path: Path) -> None:
        """测试创建打包器."""
        from bitool.apps.pypack.components.libpacker import (
            PyLibPacker,
            PyLibPackerConfig,
        )

        config = PyLibPackerConfig()
        packer = PyLibPacker(working_dir=tmp_path, config=config)

        assert packer.working_dir == tmp_path
        assert packer.config == config

    def test_packer_default_config(self, tmp_path: Path) -> None:
        """测试打包器默认配置."""
        from bitool.apps.pypack.components.libpacker import (
            PyLibPacker,
            PyLibPackerConfig,
        )

        config = PyLibPackerConfig()
        packer = PyLibPacker(working_dir=tmp_path, config=config)

        assert packer.working_dir == tmp_path

    def test_pack_empty_dependencies(self, tmp_path: Path) -> None:
        """测试空依赖列表."""
        from bitool.apps.pypack.components.libpacker import (
            PyLibPacker,
            PyLibPackerConfig,
        )

        config = PyLibPackerConfig()
        packer = PyLibPacker(working_dir=tmp_path, config=config)

        # run 不接受参数，直接调用即可
        success = packer.run()
        assert success is True

    def test_config_custom_values(self, tmp_path: Path) -> None:
        """测试自定义配置值."""
        from bitool.apps.pypack.components.libpacker import PyLibPackerConfig

        config = PyLibPackerConfig(
            cache_dir=tmp_path / "cache",
            mirror="tsinghua",
            optimize=False,
            max_workers=8,
        )

        assert config.cache_dir == tmp_path / "cache"
        assert config.mirror == "tsinghua"
        assert config.optimize is False
        assert config.max_workers == 8

    def test_config_defaults(self) -> None:
        """测试配置默认值."""
        from bitool.apps.pypack.components.libpacker import PyLibPackerConfig

        config = PyLibPackerConfig()
        assert config.cache_dir is None
        assert config.mirror == "aliyun"
        assert config.optimize is True
        assert config.max_workers == 4

    def test_packer_with_dependencies(self, tmp_path: Path) -> None:
        """测试有依赖的打包(使用 mock)."""
        from unittest.mock import patch

        from bitool.apps.pypack.components.libpacker import (
            PyLibPacker,
            PyLibPackerConfig,
        )

        config = PyLibPackerConfig()
        packer = PyLibPacker(working_dir=tmp_path, config=config)

        # Mock _get_dependencies 返回依赖列表
        with patch.object(
            packer, "_get_dependencies", return_value=["requests"]
        ), patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            success = packer.run()
            assert success is True
            # 验证调用了 pip download
            mock_run.assert_called_once()


class TestSolutionAdvanced:
    """Solution 高级功能测试."""

    def test_scan_multiple_projects(self, tmp_path: Path) -> None:
        """测试扫描多个项目."""
        # 创建多个项目
        for i in range(3):
            project_dir = tmp_path / f"project{i}"
            project_dir.mkdir()
            (project_dir / "pyproject.toml").write_text(
                f'[project]\nname = "project{i}"\nversion = "1.0.{i}"\ndescription = "Test {i}"'
            )

        solution = Solution.from_directory(tmp_path)

        assert len(solution.projects) == 3
        for i in range(3):
            assert f"project{i}" in solution.projects

    def test_scan_exclude_patterns(self, tmp_path: Path) -> None:
        """测试排除模式."""
        # 创建应该被排除的项目
        excluded_dir = tmp_path / ".cbuild" / "project"
        excluded_dir.mkdir(parents=True)
        (excluded_dir / "pyproject.toml").write_text(
            '[project]\nname = "excluded"\nversion = "1.0.0"'
        )

        # 创建正常项目
        normal_dir = tmp_path / "normal"
        normal_dir.mkdir()
        (normal_dir / "pyproject.toml").write_text(
            '[project]\nname = "normal"\nversion = "1.0.0"'
        )

        solution = Solution.from_directory(tmp_path)

        assert len(solution.projects) == 1
        assert "normal" in solution.projects
        assert "excluded" not in solution.projects

    def test_scan_empty_directory(self, tmp_path: Path) -> None:
        """测试扫描空目录."""
        solution = Solution.from_directory(tmp_path)

        assert len(solution.projects) == 0


class TestProjectAdvanced:
    """Project 高级功能测试."""

    def test_detect_entry_files(self, tmp_path: Path) -> None:
        """测试检测入口文件."""
        from bitool.apps.pypack.models.project import detect_entry_files

        # 创建入口文件
        main_file = tmp_path / "main.py"
        main_file.write_text("def main():\n    pass")

        app_file = tmp_path / "app.py"
        app_file.write_text("if __name__ == '__main__':\n    pass")

        # 创建非入口文件
        (tmp_path / "module.py").write_text("def helper():\n    pass")

        entry_files = detect_entry_files(tmp_path, "myapp")

        assert len(entry_files) == 2

    def test_is_entry_file_with_main(self, tmp_path: Path) -> None:
        """测试入口文件判断 - main 函数."""
        from bitool.apps.pypack.models.project import is_entry_file

        main_file = tmp_path / "main.py"
        main_file.write_text("def main():\n    pass")

        assert is_entry_file(main_file) is True

    def test_is_entry_file_with_name_main(self, tmp_path: Path) -> None:
        """测试入口文件判断 - __name__ == '__main__'."""
        from bitool.apps.pypack.models.project import is_entry_file

        app_file = tmp_path / "app.py"
        app_file.write_text("if __name__ == '__main__':\n    print('hello')")

        assert is_entry_file(app_file) is True

    def test_is_not_entry_file(self, tmp_path: Path) -> None:
        """测试非入口文件."""
        from bitool.apps.pypack.models.project import is_entry_file

        module_file = tmp_path / "module.py"
        module_file.write_text("def helper():\n    pass")

        assert is_entry_file(module_file) is False


class TestWorkflowConfigAdvanced:
    """WorkflowConfig 高级功能测试."""

    def test_dist_dir_property(self, tmp_path: Path) -> None:
        """测试分发目录属性."""
        config = WorkflowConfig(directory=tmp_path)

        assert config.dist_dir == tmp_path / "dist"

    def test_build_dir_property(self, tmp_path: Path) -> None:
        """测试构建目录属性."""
        config = WorkflowConfig(directory=tmp_path)

        assert config.build_dir == tmp_path / ".cbuild"

    @pytest.mark.parametrize(
        ("archive_type", "expected"),
        [("zip", "zip"), ("7z", "7z"), ("gztar", "gztar"), (None, None)],
    )
    def test_archive_type_config(
        self, tmp_path: Path, archive_type: str | None, expected: str | None
    ) -> None:
        """测试归档类型配置."""
        config = WorkflowConfig(directory=tmp_path, archive_type=archive_type)

        assert config.archive_type == expected


class TestDependencyAdvanced:
    """Dependency 高级功能测试."""

    @pytest.mark.parametrize(
        ("input_str", "expected_name", "expected_version"),
        [
            ("requests", "requests", None),
            ("requests>=2.28.0", "requests", ">=2.28.0"),
            ("requests==2.28.0", "requests", "==2.28.0"),
            ("requests>=2.28.0,<3.0.0", "requests", ">=2.28.0,<3.0.0"),
            ("numpy>=1.20", "numpy", ">=1.20"),
        ],
    )
    def test_dependency_parsing(
        self, input_str: str, expected_name: str, expected_version: str | None
    ) -> None:
        """测试依赖项解析."""
        dep = Dependency.from_string(input_str)

        assert dep.name == expected_name
        assert dep.version == expected_version

    def test_dependency_with_extras(self) -> None:
        """测试带额外依赖的依赖项."""
        dep = Dependency(name="requests", version=">=2.28.0", extras=["security"])

        assert dep.extras == ["security"]

    def test_dependency_dict_format(self) -> None:
        """测试依赖项字典格式."""
        dep = Dependency(name="requests", version=">=2.28.0", extras=["security"])
        d = dep.to_dict()

        assert d["name"] == "requests"
        assert d["version"] == ">=2.28.0"
        assert d["extras"] == ["security"]


class TestIntegration:
    """集成测试."""

    def test_full_workflow(self, tmp_path: Path) -> None:
        """测试完整工作流（不含实际下载）."""
        # 创建项目
        project_dir = tmp_path / "myapp"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "myapp"\nversion = "1.0.0"\ndescription = "Test app"'
        )
        (project_dir / "main.py").write_text('print("Hello")')

        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        # 测试列出项目
        workflow.list_projects()

        # 测试清理
        workflow.clean_project()

        # 应该不抛出异常
        assert True

    def test_workflow_with_archive(self, tmp_path: Path) -> None:
        """测试带归档的工作流配置."""
        config = WorkflowConfig(
            directory=tmp_path,
            archive_type="zip",
            python_version="3.10.0",
            loader_type="console",
        )

        PackageWorkflow(root_dir=tmp_path, config=config)

        assert config.archive_type == "zip"
        assert config.python_version == "3.10.0"


class TestCLI:
    """CLI 接口测试."""

    def test_version_command(self) -> None:
        """测试版本命令."""
        from bitool.apps.pypack.cli import PyPackSkill

        skill = PyPackSkill()
        exit_code = skill.run(["v"])
        assert exit_code == 0

    def test_list_command(self) -> None:
        """测试列表命令."""
        from bitool.apps.pypack.cli import PyPackSkill

        skill = PyPackSkill()
        # 应该不抛出异常
        exit_code = skill.run(["l"])
        assert exit_code == 0

    def test_invalid_command(self) -> None:
        """测试无效命令."""
        from bitool.apps.pypack.cli import PyPackSkill

        skill = PyPackSkill()
        exit_code = skill.run(["invalid"])
        assert exit_code == 1

    def test_no_command(self) -> None:
        """测试无命令."""
        from bitool.apps.pypack.cli import PyPackSkill

        skill = PyPackSkill()
        exit_code = skill.run([])
        assert exit_code == 1

    def test_clean_command(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """测试清理命令."""
        from bitool.apps.pypack.cli import PyPackSkill

        # 切换到临时目录
        monkeypatch.chdir(tmp_path)

        skill = PyPackSkill()
        exit_code = skill.run(["c"])
        assert exit_code == 0

    def test_run_project_without_name(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """测试运行项目但不指定名称."""
        from bitool.apps.pypack.cli import PyPackSkill

        monkeypatch.chdir(tmp_path)

        skill = PyPackSkill()
        exit_code = skill.run(["r"])
        # 应该失败，因为没有指定项目名称
        assert exit_code == 1

    @pytest.mark.parametrize("command", ["v", "version"])
    def test_version_variants(self, command: str) -> None:
        """测试版本命令的多种变体."""
        from bitool.apps.pypack.cli import PyPackSkill

        skill = PyPackSkill()
        exit_code = skill.run([command])
        assert exit_code == 0

    @pytest.mark.parametrize("command", ["l", "list", "ls"])
    def test_list_variants(self, command: str) -> None:
        """测试列表命令的多种变体."""
        from bitool.apps.pypack.cli import PyPackSkill

        skill = PyPackSkill()
        exit_code = skill.run([command])
        assert exit_code == 0

    @pytest.mark.parametrize("command", ["c", "clean"])
    def test_clean_variants(
        self, command: str, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """测试清理命令的多种变体."""
        from bitool.apps.pypack.cli import PyPackSkill

        monkeypatch.chdir(tmp_path)

        skill = PyPackSkill()
        exit_code = skill.run([command])
        assert exit_code == 0


class TestPyPackConfigAdvanced:
    """PyPackConfig 高级功能测试."""

    def test_config_supported_formats(self) -> None:
        """测试支持的归档格式."""
        config = PyPackConfig()

        assert "zip" in config.ARCHIVE_FORMATS
        assert "7z" in config.ARCHIVE_FORMATS
        assert "tar" in config.ARCHIVE_FORMATS

    def test_config_supported_mirrors(self) -> None:
        """测试支持的镜像源."""
        config = PyPackConfig()

        assert "aliyun" in config.MIRRORS
        assert "tsinghua" in config.MIRRORS
        assert "pypi" in config.MIRRORS

    def test_config_loader_types(self) -> None:
        """测试支持的加载器类型."""
        config = PyPackConfig()

        assert "console" in config.LOADER_TYPES
        assert "gui" in config.LOADER_TYPES


class TestProgress:
    """进度模块测试."""

    def test_format_file_size_bytes(self) -> None:
        """测试文件大小格式化 - 字节."""
        from bitool.apps.pypack.progress import format_file_size

        assert format_file_size(0) == "0 B"
        assert format_file_size(512) == "512 B"
        assert format_file_size(1023) == "1023 B"

    def test_format_file_size_kb(self) -> None:
        """测试文件大小格式化 - KB."""
        from bitool.apps.pypack.progress import format_file_size

        assert format_file_size(1024) == "1.0 KB"
        assert format_file_size(1536) == "1.5 KB"
        assert format_file_size(10240) == "10.0 KB"

    def test_format_file_size_mb(self) -> None:
        """测试文件大小格式化 - MB."""
        from bitool.apps.pypack.progress import format_file_size

        assert format_file_size(1024 * 1024) == "1.0 MB"
        assert format_file_size(1024 * 1024 * 5) == "5.0 MB"

    def test_format_file_size_gb(self) -> None:
        """测试文件大小格式化 - GB."""
        from bitool.apps.pypack.progress import format_file_size

        assert format_file_size(1024 * 1024 * 1024) == "1.0 GB"
        assert format_file_size(1024 * 1024 * 1024 * 2) == "2.0 GB"

    @pytest.mark.parametrize(
        ("seconds", "expected"),
        [
            (0.5, "500ms"),
            (0.123, "123ms"),
            (1.5, "1.5s"),
            (30.0, "30.0s"),
            (59.9, "59.9s"),
            (60.0, "1m 0s"),
            (125.0, "2m 5s"),
            (3600.0, "1h 0m"),
            (7265.0, "2h 1m"),
        ],
    )
    def test_format_time(self, seconds: float, expected: str) -> None:
        """测试时间格式化."""
        from bitool.apps.pypack.progress import format_time

        assert format_time(seconds) == expected

    def test_progress_bar(self, capsys: pytest.CaptureFixture) -> None:
        """测试进度条."""
        from bitool.apps.pypack.progress import ProgressBar

        bar = ProgressBar(total=10, desc="测试")
        bar.update(5)

        # 验证输出
        captured = capsys.readouterr()
        assert "测试" in captured.out
        assert "5/10" in captured.out

    def test_task_reporter(self) -> None:
        """测试任务报告器."""
        from bitool.apps.pypack.progress import TaskReporter

        reporter = TaskReporter(total_tasks=3, desc="测试任务")
        assert reporter.total == 3
        assert reporter.current == 0

        reporter.start_task("任务1")
        reporter.complete_task(success=True, message="任务1完成")
        assert reporter.current == 1

        reporter.finish()


class TestIntegrationExtended:
    """集成测试扩展."""

    def test_full_workflow(self, tmp_path: Path) -> None:
        """测试完整工作流（不含实际下载）."""
        # 创建项目
        project_dir = tmp_path / "myapp"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "myapp"\nversion = "1.0.0"\ndescription = "Test app"'
        )
        (project_dir / "main.py").write_text('print("Hello")')

        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        # 测试列出项目
        workflow.list_projects()

        # 测试清理
        workflow.clean_project()

        # 应该不抛出异常
        assert True

    def test_workflow_with_archive(self, tmp_path: Path) -> None:
        """测试带归档的工作流配置."""
        config = WorkflowConfig(
            directory=tmp_path,
            archive_type="zip",
            python_version="3.10.0",
            loader_type="console",
        )

        PackageWorkflow(root_dir=tmp_path, config=config)

        assert config.archive_type == "zip"
        assert config.python_version == "3.10.0"

    def test_multiple_projects_workflow(self, tmp_path: Path) -> None:
        """测试多项目工作流."""
        # 创建多个项目
        for i in range(3):
            project_dir = tmp_path / f"project{i}"
            project_dir.mkdir()
            (project_dir / "pyproject.toml").write_text(
                f'[project]\nname = "project{i}"\nversion = "1.0.{i}"'
            )
            (project_dir / "main.py").write_text(f'print("Project {i}")')

        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        # 验证能扫描到所有项目
        solution = workflow.solution
        assert len(solution.projects) == 3

    def test_project_with_dependencies_workflow(self, tmp_path: Path) -> None:
        """测试带依赖的项目工作流."""
        project_dir = tmp_path / "myapp"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "myapp"\nversion = "1.0.0"\n'
            'dependencies = ["requests>=2.28.0", "numpy"]'
        )

        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(root_dir=tmp_path, config=config)

        solution = workflow.solution
        project = solution.projects["myapp"]
        assert len(project.dependencies) == 2
        assert "requests>=2.28.0" in project.dependencies
