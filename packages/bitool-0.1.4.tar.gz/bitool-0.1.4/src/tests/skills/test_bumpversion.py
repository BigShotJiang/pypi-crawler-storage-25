"""bumpversion 模块的功能测试.

测试 BumpProjectVersionCommand 命令类的版本号递增功能.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Generator

import pytest

from bitool.cmd.version import BumpProjectVersionCommand
from bitool.skills.bumpversion import create_scheduler_map, show_help


@pytest.fixture
def temp_workspace(tmp_path: Path) -> Generator[Path, None, None]:
    """创建临时工作目录并切换."""
    original_cwd = Path.cwd()
    os.chdir(tmp_path)
    yield tmp_path
    os.chdir(original_cwd)


def _create_pyproject(path: Path, version: str = "1.0.0", name: str = "test") -> Path:
    """创建 pyproject.toml 文件的辅助函数.

    Parameters
    ----------
    path : Path
        文件路径或目录路径 (如果是目录, 会在其中创建 pyproject.toml)
    version : str
        版本号
    name : str
        项目名称

    Returns
    -------
    Path
        pyproject.toml 文件的实际路径
    """
    pyproject = path / "pyproject.toml" if path.is_dir() else path
    pyproject.write_text(
        f'[project]\nname = "{name}"\nversion = "{version}"\n', encoding="utf-8"
    )
    return pyproject


def _create_init_py(path: Path, version: str = "1.0.0") -> Path:
    """创建 __init__.py 文件的辅助函数.

    Parameters
    ----------
    path : Path
        目录路径
    version : str
        版本号

    Returns
    -------
    Path
        __init__.py 文件的路径
    """
    init_file = path / "__init__.py"
    init_file.write_text(
        f'"""Test package."""\n\n__version__ = "{version}"\n', encoding="utf-8"
    )
    return init_file


class TestBumpProjectVersionCommand:
    """BumpProjectVersionCommand 命令测试."""

    def test_bump_pyproject_patch(self, temp_workspace: Path) -> None:
        """测试递增 pyproject.toml 的补丁号."""
        pyproject = _create_pyproject(temp_workspace, version="1.0.0")

        cmd = BumpProjectVersionCommand(root_path=temp_workspace, part="patch")
        result = cmd.run()

        assert result is True
        content = pyproject.read_text(encoding="utf-8")
        assert 'version = "1.0.1"' in content
        assert len(cmd.updated_files) == 1

    def test_bump_pyproject_minor(self, temp_workspace: Path) -> None:
        """测试递增 pyproject.toml 的次版本号."""
        pyproject = _create_pyproject(temp_workspace, version="1.0.0")

        cmd = BumpProjectVersionCommand(root_path=temp_workspace, part="minor")
        result = cmd.run()

        assert result is True
        content = pyproject.read_text(encoding="utf-8")
        assert 'version = "1.1.0"' in content

    def test_bump_pyproject_major(self, temp_workspace: Path) -> None:
        """测试递增 pyproject.toml 的主版本号."""
        pyproject = _create_pyproject(temp_workspace, version="1.5.3")

        cmd = BumpProjectVersionCommand(root_path=temp_workspace, part="major")
        result = cmd.run()

        assert result is True
        content = pyproject.read_text(encoding="utf-8")
        assert 'version = "2.0.0"' in content

    def test_bump_pyproject_with_prerelease(self, temp_workspace: Path) -> None:
        """测试递增并设置预发布标识."""
        pyproject = _create_pyproject(temp_workspace, version="1.0.0")

        cmd = BumpProjectVersionCommand(
            root_path=temp_workspace, part="patch", prerelease="alpha"
        )
        result = cmd.run()

        assert result is True
        content = pyproject.read_text(encoding="utf-8")
        assert 'version = "1.0.1-alpha"' in content

    def test_bump_multiple_files(self, temp_workspace: Path) -> None:
        """测试同时递增多个文件."""
        # 创建 pyproject.toml
        pyproject = _create_pyproject(temp_workspace, version="1.0.0")

        # 创建 __init__.py
        src_dir = temp_workspace / "src"
        src_dir.mkdir()
        init_file = _create_init_py(src_dir, version="1.0.0")

        cmd = BumpProjectVersionCommand(root_path=temp_workspace, part="minor")
        result = cmd.run()

        assert result is True

        # 验证 pyproject.toml
        content = pyproject.read_text(encoding="utf-8")
        assert 'version = "1.1.0"' in content

        # 验证 __init__.py
        content = init_file.read_text(encoding="utf-8")
        assert '__version__ = "1.1.0"' in content

        assert len(cmd.updated_files) == 2

    def test_exclude_root_pyproject(self, temp_workspace: Path) -> None:
        """测试排除根目录的 pyproject.toml."""
        # 创建根目录 pyproject.toml
        root_pyproject = _create_pyproject(temp_workspace, version="1.0.0")

        # 创建子项目 pyproject.toml
        sub_project = temp_workspace / "sub-project"
        sub_project.mkdir()
        sub_pyproject = _create_pyproject(sub_project, version="2.0.0")

        cmd = BumpProjectVersionCommand(
            root_path=temp_workspace, part="patch", exclude_root=True
        )
        result = cmd.run()

        assert result is True

        # 根目录不应被更新
        content = root_pyproject.read_text(encoding="utf-8")
        assert 'version = "1.0.0"' in content

        # 子项目应该被更新
        content = sub_pyproject.read_text(encoding="utf-8")
        assert 'version = "2.0.1"' in content

    def test_excluded_dirs(self, temp_workspace: Path) -> None:
        """测试排除目录."""
        # 创建 .venv 目录中的 pyproject.toml (不应被更新)
        venv_dir = temp_workspace / ".venv"
        venv_dir.mkdir()
        venv_pyproject = _create_pyproject(venv_dir, version="1.0.0")

        # 创建正常目录中的 pyproject.toml
        src_dir = temp_workspace / "src"
        src_dir.mkdir()
        src_pyproject = _create_pyproject(src_dir, version="1.0.0")

        cmd = BumpProjectVersionCommand(root_path=temp_workspace, part="patch")
        result = cmd.run()

        assert result is True

        # .venv 中的文件不应被更新
        content = venv_pyproject.read_text(encoding="utf-8")
        assert 'version = "1.0.0"' in content

        # src 中的文件应该被更新
        content = src_pyproject.read_text(encoding="utf-8")
        assert 'version = "1.0.1"' in content

    def test_no_version_files(self, temp_workspace: Path) -> None:
        """测试没有版本文件的情况."""
        # 创建空目录
        (temp_workspace / "empty.txt").write_text("empty", encoding="utf-8")

        cmd = BumpProjectVersionCommand(root_path=temp_workspace, part="patch")
        result = cmd.run()

        assert result is False

    def test_nonexistent_path(self, tmp_path: Path) -> None:
        """测试不存在的目录."""
        cmd = BumpProjectVersionCommand(
            root_path=tmp_path / "nonexistent", part="patch"
        )
        result = cmd.run()

        assert result is False


class TestSchedulerMap:
    """命令调度器映射测试."""

    def test_create_scheduler_map(self) -> None:
        """测试创建调度器映射."""
        scheduler_map = create_scheduler_map()

        assert "patch" in scheduler_map
        assert "minor" in scheduler_map
        assert "major" in scheduler_map
        assert "patch-alpha" in scheduler_map

    def test_show_help(self) -> None:
        """测试显示帮助信息."""
        help_text = show_help()

        assert "版本号自动管理工具" in help_text
        assert "patch" in help_text
        assert "minor" in help_text
        assert "major" in help_text
