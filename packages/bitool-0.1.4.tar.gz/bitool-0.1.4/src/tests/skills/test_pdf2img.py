"""PDF转图片脚本的功能测试。

在临时目录中创建真实的PDF文件, 验证转换前后的实际效果。
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Generator

import pytest

try:
    import fitz  # PyMuPDF

    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False

from bitool.skills.pdf2img import Pdf2ImgSkill, PdfToImageConfig


@pytest.fixture
def temp_workspace(tmp_path: Path) -> Generator[Path, None, None]:
    """创建临时工作目录并切换。"""
    original_cwd = Path.cwd()
    os.chdir(tmp_path)
    yield tmp_path
    os.chdir(original_cwd)


def _create_test_pdf(pdf_path: Path, pages: int = 3) -> None:
    """创建测试PDF的辅助函数（避免重复代码）。"""
    doc = fitz.open()
    for i in range(pages):
        blank = fitz.open()
        blank.new_page()  # type: ignore
        doc.insert_pdf(blank)
        page = doc[-1]
        page.insert_textbox((100, 100, 500, 700), f"这是第 {i + 1} 页")
        blank.close()
    doc.save(str(pdf_path))
    doc.close()


@pytest.fixture(scope="session")
def session_sample_pdf(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """创建会话级3页示例PDF（跨测试共享，避免重复创建）。"""
    if not HAS_PYMUPDF:
        pytest.skip("PyMuPDF未安装")  # type: ignore

    tmp_path = Path(tmp_path_factory.mktemp("sample_pdf"))  # type: ignore[arg-type]
    pdf_path = tmp_path / "sample.pdf"
    _create_test_pdf(pdf_path, pages=3)
    return pdf_path


@pytest.fixture(scope="session")
def session_sample_pdf_single_page(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """创建会话级单页示例PDF（跨测试共享）。"""
    if not HAS_PYMUPDF:
        pytest.skip("PyMuPDF未安装")  # type: ignore

    tmp_path = Path(tmp_path_factory.mktemp("single_page_pdf"))  # type: ignore[arg-type]
    pdf_path = tmp_path / "single_page.pdf"
    doc = fitz.open()
    doc.new_page()  # type: ignore
    page = doc[-1]
    page.insert_textbox((100, 100, 500, 700), "单页PDF测试")
    doc.save(str(pdf_path))
    doc.close()
    return pdf_path


# 保持向后兼容的function级别fixture（用于需要修改PDF的测试）
@pytest.fixture
def sample_pdf(session_sample_pdf: Path, tmp_path: Path) -> Path:
    """创建包含3页的示例PDF文件（拷贝会话级PDF）。"""
    import shutil

    dest = tmp_path / session_sample_pdf.name
    shutil.copy2(session_sample_pdf, dest)
    return dest


@pytest.fixture
def sample_pdf_single_page(
    session_sample_pdf_single_page: Path, tmp_path: Path
) -> Path:
    """创建单页的示例PDF文件（拷贝会话级PDF）。"""
    import shutil

    dest = tmp_path / session_sample_pdf_single_page.name
    shutil.copy2(session_sample_pdf_single_page, dest)
    return dest


@pytest.mark.skipif(not HAS_PYMUPDF, reason="需要PyMuPDF库")
class TestPdfToImagesCommand:
    """测试PDF转图片命令。"""

    def test_create_scheduler(self, sample_pdf: Path, tmp_path: Path) -> None:
        """测试创建命令调度器。"""
        output_dir = tmp_path / "output"
        skill = Pdf2ImgSkill()
        import argparse

        args = argparse.Namespace(
            input_path=str(sample_pdf),
            output_dir=str(output_dir),
            format="png",
            dpi=150,
            quality=90,
        )
        scheduler = skill.create_scheduler(args)

        assert scheduler is not None
        assert len(scheduler.commands) == 1

    def test_convert_pdf_to_png(self, sample_pdf: Path, tmp_path: Path) -> None:
        """测试将PDF转换为PNG图片。"""
        output_dir = tmp_path / "png_output"
        skill = Pdf2ImgSkill()
        import argparse

        args = argparse.Namespace(
            input_path=str(sample_pdf),
            output_dir=str(output_dir),
            format="png",
            dpi=150,
            quality=90,
        )
        scheduler = skill.create_scheduler(args)
        success = scheduler.run()

        # scheduler.run() 返回字典 {"base": True/False}
        assert success == {"base": True}
        assert output_dir.exists()

        # 验证生成的图片文件
        png_files = list(output_dir.glob("*.png"))
        assert len(png_files) == 3  # PDF有3页

        # 验证文件名格式
        for i in range(3):
            expected_file = output_dir / f"page_{i + 1}.png"
            assert expected_file.exists()

    def test_convert_pdf_to_jpg(self, sample_pdf: Path, tmp_path: Path) -> None:
        """测试将PDF转换为JPG图片。"""
        output_dir = tmp_path / "jpg_output"
        skill = Pdf2ImgSkill()
        import argparse

        args = argparse.Namespace(
            input_path=str(sample_pdf),
            output_dir=str(output_dir),
            format="jpg",
            dpi=150,
            quality=90,
        )
        scheduler = skill.create_scheduler(args)
        success = scheduler.run()

        # scheduler.run() 返回字典 {"base": True/False}
        assert success == {"base": True}

        # 验证生成的图片文件
        jpg_files = list(output_dir.glob("*.jpg"))
        assert len(jpg_files) == 3

    def test_convert_single_page_pdf(
        self, sample_pdf_single_page: Path, tmp_path: Path
    ) -> None:
        """测试转换单页PDF。"""
        output_dir = tmp_path / "single_output"
        skill = Pdf2ImgSkill()
        import argparse

        args = argparse.Namespace(
            input_path=str(sample_pdf_single_page),
            output_dir=str(output_dir),
            format="png",
            dpi=150,
            quality=90,
        )
        scheduler = skill.create_scheduler(args)
        success = scheduler.run()

        # scheduler.run() 返回字典 {"base": True/False}
        assert success == {"base": True}

        # 验证只生成了1张图片
        png_files = list(output_dir.glob("*.png"))
        assert len(png_files) == 1

    @pytest.mark.parametrize("dpi", [72, 150, 200, 300])
    def test_different_dpi_settings(
        self, sample_pdf: Path, tmp_path: Path, dpi: int
    ) -> None:
        """测试不同DPI设置。"""
        output_dir = tmp_path / f"dpi_{dpi}"
        skill = Pdf2ImgSkill()
        import argparse

        args = argparse.Namespace(
            input_path=str(sample_pdf),
            output_dir=str(output_dir),
            format="png",
            dpi=dpi,
            quality=90,
        )
        scheduler = skill.create_scheduler(args)
        success = scheduler.run()

        # scheduler.run() 返回字典 {"base": True/False}
        assert success == {"base": True}

        # 验证生成的图片数量正确
        png_files = list(output_dir.glob("*.png"))
        assert len(png_files) == 3

    def test_nonexistent_input_pdf(self, tmp_path: Path) -> None:
        """测试输入PDF不存在的情况。"""
        output_dir = tmp_path / "output"
        nonexistent_pdf = tmp_path / "nonexistent.pdf"
        skill = Pdf2ImgSkill()
        import argparse

        args = argparse.Namespace(
            input_path=str(nonexistent_pdf),
            output_dir=str(output_dir),
            format="png",
            dpi=150,
            quality=90,
        )
        # 不存在的PDF会导致sys.exit(1)，需要捕获
        with pytest.raises(SystemExit):
            skill.create_scheduler(args)


@pytest.mark.skipif(not HAS_PYMUPDF, reason="需要PyMuPDF库")
class TestPdfToImageConfig:
    """测试配置类。"""

    def test_default_config(self) -> None:
        """测试默认配置值。"""
        config = PdfToImageConfig()
        assert config.DPI == 150
        assert config.DPI_RANGE == (72, 300)
        assert config.FORMAT == "png"
        assert config.QUALITY == 90
        assert config.QUALITY_RANGE == (1, 100)
        assert {"png", "jpg", "jpeg"} == config.VALID_FORMATS

    def test_config_instance(self) -> None:
        """测试配置实例。"""
        from bitool.skills.pdf2img import conf

        assert isinstance(conf, PdfToImageConfig)


@pytest.mark.skipif(not HAS_PYMUPDF, reason="需要PyMuPDF库")
class TestMainFunction:
    """测试main函数。"""

    def test_main_with_pdf_file(
        self, sample_pdf: Path, tmp_path: Path, monkeypatch
    ) -> None:
        """测试使用PDF文件路径运行主函数。"""
        from bitool.skills.pdf2img import Pdf2ImgSkill

        output_dir = tmp_path / "converted"

        # 创建mock args对象
        import argparse

        mock_args = argparse.Namespace(
            input_path=str(sample_pdf),
            output_dir=str(output_dir),
            format="png",
            dpi=150,
            quality=90,
        )

        # 直接测试create_scheduler方法
        skill = Pdf2ImgSkill()
        scheduler = skill.create_scheduler(mock_args)
        success = scheduler.run()

        # scheduler.run() 返回字典 {"base": True/False}
        assert success == {"base": True}

        # 验证输出文件存在
        assert output_dir.exists()
        png_files = list(output_dir.glob("*.png"))
        assert len(png_files) == 3

    def test_main_with_directory(
        self, sample_pdf: Path, tmp_path: Path, monkeypatch
    ) -> None:
        """测试使用目录运行主函数(自动查找PDF)。"""
        import argparse

        from bitool.skills.pdf2img import Pdf2ImgSkill

        # Mock参数 - 传入目录而非文件
        mock_args = argparse.Namespace(
            input_path=str(sample_pdf.parent),  # 传入PDF所在目录
            output_dir=None,  # 使用默认输出目录
            format="png",
            dpi=150,
            quality=90,
        )

        # 直接测试create_scheduler方法(这会处理目录查找逻辑)
        skill = Pdf2ImgSkill()
        scheduler = skill.create_scheduler(mock_args)
        success = scheduler.run()

        # scheduler.run() 返回字典 {"base": True/False}
        assert success == {"base": True}

        # 验证默认输出目录被创建(在sample_pdf的父目录下)
        default_output_dir = sample_pdf.parent / "converted_images"
        assert default_output_dir.exists()
        png_files = list(default_output_dir.glob("*.png"))
        assert len(png_files) == 3

    def test_main_no_pdf_in_directory(self, tmp_path: Path, monkeypatch) -> None:
        """测试目录中没有PDF文件的情况。"""
        import argparse

        from bitool.skills.pdf2img import Pdf2ImgSkill

        mock_args = argparse.Namespace(
            input_path=str(tmp_path), output_dir=None, format="png", dpi=150, quality=90
        )

        # 直接测试create_scheduler方法,应该退出并返回错误码
        skill = Pdf2ImgSkill()
        with pytest.raises(SystemExit) as exc_info:
            skill.create_scheduler(mock_args)

        assert exc_info.value.code == 1

    def test_main_invalid_format(
        self, sample_pdf: Path, tmp_path: Path, monkeypatch
    ) -> None:
        """测试无效的图片格式。"""
        import argparse

        from bitool.skills.pdf2img import Pdf2ImgSkill

        mock_args = argparse.Namespace(
            input_path=str(sample_pdf),
            output_dir=str(tmp_path / "output"),
            format="gif",  # 不支持的格式
            dpi=150,
            quality=90,
        )

        # 直接测试create_scheduler方法
        skill = Pdf2ImgSkill()
        with pytest.raises(SystemExit) as exc_info:
            skill.create_scheduler(mock_args)

        assert exc_info.value.code == 1

    @pytest.mark.parametrize("invalid_dpi", [50, 350])
    def test_main_invalid_dpi(
        self, sample_pdf: Path, tmp_path: Path, invalid_dpi: int, monkeypatch
    ) -> None:
        """测试无效的DPI值。"""
        import argparse

        from bitool.skills.pdf2img import Pdf2ImgSkill

        mock_args = argparse.Namespace(
            input_path=str(sample_pdf),
            output_dir=str(tmp_path / "output"),
            format="png",
            dpi=invalid_dpi,
            quality=90,
        )

        # 直接测试create_scheduler方法
        skill = Pdf2ImgSkill()
        with pytest.raises(SystemExit) as exc_info:
            skill.create_scheduler(mock_args)

        assert exc_info.value.code == 1

    @pytest.mark.parametrize("invalid_quality", [0, 101])
    def test_main_invalid_quality(
        self, sample_pdf: Path, tmp_path: Path, invalid_quality: int, monkeypatch
    ) -> None:
        """测试无效的图片质量值。"""
        import argparse

        from bitool.skills.pdf2img import Pdf2ImgSkill

        mock_args = argparse.Namespace(
            input_path=str(sample_pdf),
            output_dir=str(tmp_path / "output"),
            format="png",
            dpi=150,
            quality=invalid_quality,
        )

        # 直接测试create_scheduler方法
        skill = Pdf2ImgSkill()
        with pytest.raises(SystemExit) as exc_info:
            skill.create_scheduler(mock_args)

        assert exc_info.value.code == 1

    def test_main_nonexistent_pdf(self, tmp_path: Path, monkeypatch) -> None:
        """测试不存在的PDF文件。"""
        import argparse

        from bitool.skills.pdf2img import Pdf2ImgSkill

        nonexistent_pdf = tmp_path / "nonexistent.pdf"

        mock_args = argparse.Namespace(
            input_path=str(nonexistent_pdf),
            output_dir=str(tmp_path / "output"),
            format="png",
            dpi=150,
            quality=90,
        )

        # 直接测试create_scheduler方法
        skill = Pdf2ImgSkill()
        with pytest.raises(SystemExit) as exc_info:
            skill.create_scheduler(mock_args)

        assert exc_info.value.code == 1
