"""envrs 工具的功能测试。

测试 EnvRsSkill 类的 Rust 环境配置功能。
"""

from __future__ import annotations

import pytest

from bitool.skills.envrs import EnvRsSkill


class TestEnvRsSkill:
    """EnvRsSkill 测试。"""

    def test_skill_name(self) -> None:
        """测试技能名称。"""
        skill = EnvRsSkill()
        assert skill.name == "envrs"

    def test_skill_description(self) -> None:
        """测试技能描述。"""
        skill = EnvRsSkill()
        assert skill.description == "设置 Rust 国内镜像环境变量"

    def test_add_arguments(self) -> None:
        """测试参数添加。"""
        skill = EnvRsSkill()
        parser = skill.create_parser()

        # 测试默认参数
        args = parser.parse_args([])
        assert args.version == "nightly"

        # 测试指定版本
        args = parser.parse_args(["stable"])
        assert args.version == "stable"

        args = parser.parse_args(["1.75.0"])
        assert args.version == "1.75.0"

    def test_create_scheduler_default(self) -> None:
        """测试默认调度器创建。"""
        import argparse

        skill = EnvRsSkill()
        args = argparse.Namespace(version="nightly", mirror="aliyun")
        scheduler = skill.create_scheduler(args)

        assert scheduler is not None
        # SetEnv + 2个RunCommand(Windows/Unix) + WriteFile + RunCommand(rustup install)
        assert len(scheduler.commands) == 5

    @pytest.mark.parametrize("version", ["nightly", "stable", "1.75.0"])
    def test_create_scheduler_with_version(self, version: str) -> None:
        """测试不同版本的调度器创建。"""
        import argparse

        skill = EnvRsSkill()
        args = argparse.Namespace(version=version, mirror="aliyun")
        scheduler = skill.create_scheduler(args)

        assert scheduler is not None
        assert len(scheduler.commands) == 5

    def test_run_method(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """测试 run 方法（不实际执行命令）。

        使用 mock 避免实际下载和安装 Rust 工具链。
        """
        from unittest.mock import Mock, patch

        skill = EnvRsSkill()

        # Mock CommandScheduler.run 方法，避免实际执行命令
        with patch("bitool.skills.envrs.CommandScheduler") as mock_scheduler_class:
            mock_scheduler = Mock()
            mock_scheduler.run.return_value = True
            mock_scheduler_class.return_value = mock_scheduler

            # 测试运行（不会真正执行下载和安装）
            exit_code = skill.run(["nightly"])

            # 验证返回成功退出码
            assert exit_code == 0
            # 验证调度器的 run 方法被调用
            mock_scheduler.run.assert_called_once()
