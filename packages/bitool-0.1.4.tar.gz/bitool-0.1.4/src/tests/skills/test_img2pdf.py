"""图片转PDF脚本的功能测试。

在临时目录中创建真实的图片文件, 验证转换前后的实际效果。
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Generator

import pytest

try:
    import fitz  # PyMuPDF

    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False

from bitool.skills.img2pdf import ImageToPdfConfig, Img2PdfSkill


@pytest.fixture
def temp_workspace(tmp_path: Path) -> Generator[Path, None, None]:
    """创建临时工作目录并切换。"""
    original_cwd = Path.cwd()
    os.chdir(tmp_path)
    yield tmp_path
    os.chdir(original_cwd)


def _create_test_image(img_path: Path, text: str) -> None:
    """创建测试图片的辅助函数（避免重复代码）。"""
    doc = fitz.open()
    doc.new_page()  # type: ignore
    page = doc[-1]
    page.insert_textbox((100, 100, 500, 700), text)
    pix = page.get_pixmap()
    pix.save(str(img_path))
    doc.close()


@pytest.fixture(scope="session")
def session_sample_images(tmp_path_factory: pytest.TempPathFactory) -> list[Path]:
    """创建会话级示例PNG图片（跨测试共享，避免重复创建）。"""
    if not HAS_PYMUPDF:
        pytest.skip("PyMuPDF未安装")  # type: ignore

    tmp_path = Path(tmp_path_factory.mktemp("sample_images"))  # type: ignore[arg-type]
    images = []
    for i in range(3):
        img_path = tmp_path / f"image_{i + 1}.png"
        _create_test_image(img_path, f"测试图片 {i + 1}")
        images.append(img_path)

    return images


@pytest.fixture(scope="session")
def session_sample_jpg_images(tmp_path_factory: pytest.TempPathFactory) -> list[Path]:
    """创建会话级示例JPG图片（跨测试共享）。"""
    if not HAS_PYMUPDF:
        pytest.skip("PyMuPDF未安装")  # type: ignore

    tmp_path = Path(tmp_path_factory.mktemp("sample_jpg_images"))  # type: ignore[arg-type]
    images = []
    for i in range(2):
        img_path = tmp_path / f"photo_{i + 1}.jpg"
        _create_test_image(img_path, f"测试JPG图片 {i + 1}")
        images.append(img_path)

    return images


@pytest.fixture(scope="session")
def session_single_image(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """创建会话级单个示例图片（跨测试共享）。"""
    if not HAS_PYMUPDF:
        pytest.skip("PyMuPDF未安装")  # type: ignore

    tmp_path = Path(tmp_path_factory.mktemp("single_image"))  # type: ignore[arg-type]
    img_path = tmp_path / "single.png"
    _create_test_image(img_path, "单张图片测试")
    return img_path


# 保持向后兼容的function级别fixture（用于需要修改图片的测试）
@pytest.fixture
def sample_images(session_sample_images: list[Path], tmp_path: Path) -> list[Path]:
    """创建3个示例PNG图片文件（拷贝会话级图片到临时目录）。"""
    import shutil

    copies = []
    for img in session_sample_images:
        dest = tmp_path / img.name
        shutil.copy2(img, dest)
        copies.append(dest)
    return copies


@pytest.fixture
def sample_jpg_images(
    session_sample_jpg_images: list[Path], tmp_path: Path
) -> list[Path]:
    """创建2个示例JPG图片文件（拷贝会话级图片）。"""
    import shutil

    copies = []
    for img in session_sample_jpg_images:
        dest = tmp_path / img.name
        shutil.copy2(img, dest)
        copies.append(dest)
    return copies


@pytest.fixture
def single_image(session_single_image: Path, tmp_path: Path) -> Path:
    """创建单个示例图片文件（拷贝会话级图片）。"""
    import shutil

    dest = tmp_path / session_single_image.name
    shutil.copy2(session_single_image, dest)
    return dest


@pytest.mark.skipif(not HAS_PYMUPDF, reason="需要PyMuPDF库")
class TestImagesToPdfCommand:
    """测试图片转PDF命令。"""

    def test_create_scheduler(self, sample_images: list[Path], tmp_path: Path) -> None:
        """测试创建命令调度器。"""
        output_path = tmp_path / "output.pdf"
        skill = Img2PdfSkill()
        import argparse

        args = argparse.Namespace(
            input_paths=[str(p) for p in sample_images],
            output_path=str(output_path),
            page_size="auto",
        )
        scheduler = skill.create_scheduler(args)

        assert scheduler is not None
        assert len(scheduler.commands) == 1

    def test_convert_images_to_pdf(
        self, sample_images: list[Path], tmp_path: Path
    ) -> None:
        """测试将多张图片转换为PDF。"""
        output_path = tmp_path / "output.pdf"
        skill = Img2PdfSkill()
        import argparse

        args = argparse.Namespace(
            input_paths=[str(p) for p in sample_images],
            output_path=str(output_path),
            page_size="auto",
        )
        scheduler = skill.create_scheduler(args)
        success = scheduler.run()

        # scheduler.run() 返回字典 {"base": True/False}
        assert success == {"base": True}
        assert output_path.exists()

        # 验证生成的PDF文件
        pdf_doc = fitz.open(str(output_path))
        try:
            assert len(pdf_doc) == 3  # 应该有3页
        finally:
            pdf_doc.close()

    def test_convert_jpg_images_to_pdf(
        self, sample_jpg_images: list[Path], tmp_path: Path
    ) -> None:
        """测试将JPG图片转换为PDF。"""
        output_path = tmp_path / "output.pdf"
        skill = Img2PdfSkill()
        import argparse

        args = argparse.Namespace(
            input_paths=[str(p) for p in sample_jpg_images],
            output_path=str(output_path),
            page_size="auto",
        )
        scheduler = skill.create_scheduler(args)
        success = scheduler.run()

        # scheduler.run() 返回字典 {"base": True/False}
        assert success == {"base": True}
        assert output_path.exists()

        # 验证生成的PDF文件
        pdf_doc = fitz.open(str(output_path))
        try:
            assert len(pdf_doc) == 2  # 应该有2页
        finally:
            pdf_doc.close()

    def test_convert_single_image(self, single_image: Path, tmp_path: Path) -> None:
        """测试转换单张图片。"""
        output_path = tmp_path / "single.pdf"
        skill = Img2PdfSkill()
        import argparse

        args = argparse.Namespace(
            input_paths=[str(single_image)],
            output_path=str(output_path),
            page_size="auto",
        )
        scheduler = skill.create_scheduler(args)
        success = scheduler.run()

        # scheduler.run() 返回字典 {"base": True/False}
        assert success == {"base": True}

        # 验证生成的PDF只有1页
        pdf_doc = fitz.open(str(output_path))
        try:
            assert len(pdf_doc) == 1
        finally:
            pdf_doc.close()

    def test_convert_images_with_output_dir_creation(
        self, sample_images: list[Path], tmp_path: Path
    ) -> None:
        """测试自动创建输出目录。"""
        output_path = tmp_path / "subdir" / "nested" / "output.pdf"
        skill = Img2PdfSkill()
        import argparse

        args = argparse.Namespace(
            input_paths=[str(p) for p in sample_images],
            output_path=str(output_path),
            page_size="auto",
        )
        scheduler = skill.create_scheduler(args)
        success = scheduler.run()

        # scheduler.run() 返回字典 {"base": True/False}
        assert success == {"base": True}
        assert output_path.exists()
        assert output_path.parent.exists()

    def test_empty_image_list(self, tmp_path: Path) -> None:
        """测试空图片列表。"""
        output_path = tmp_path / "output.pdf"
        skill = Img2PdfSkill()
        import argparse

        args = argparse.Namespace(
            input_paths=[], output_path=str(output_path), page_size="auto"
        )
        # 空列表会导致sys.exit(1)，需要捕获
        with pytest.raises(SystemExit):
            skill.create_scheduler(args)

    def test_nonexistent_image_file(self, tmp_path: Path) -> None:
        """测试不存在的图片文件。"""
        output_path = tmp_path / "output.pdf"
        nonexistent = tmp_path / "nonexistent.png"
        skill = Img2PdfSkill()
        import argparse

        args = argparse.Namespace(
            input_paths=[str(nonexistent)],
            output_path=str(output_path),
            page_size="auto",
        )
        # 不存在的文件会导致sys.exit(1)，需要捕获
        with pytest.raises(SystemExit):
            skill.create_scheduler(args)


@pytest.mark.skipif(not HAS_PYMUPDF, reason="需要PyMuPDF库")
class TestImageToPdfConfig:
    """测试配置类。"""

    def test_default_config(self) -> None:
        """测试默认配置值。"""
        config = ImageToPdfConfig()
        assert config.FORMAT == "pdf"
        assert config.PAGE_SIZE == "auto"
        assert {"png", "jpg", "jpeg", "bmp", "gif", "tiff", "tif"} == set(
            config.VALID_IMAGE_FORMATS
        )
        assert {"pdf"} == set(config.VALID_OUTPUT_FORMATS)

    def test_config_instance(self) -> None:
        """测试配置实例。"""
        from bitool.skills.img2pdf import conf

        assert isinstance(conf, ImageToPdfConfig)


@pytest.mark.skipif(not HAS_PYMUPDF, reason="需要PyMuPDF库")
class TestMainFunction:
    """测试main函数。"""

    def test_main_with_image_files(
        self, sample_images: list[Path], tmp_path: Path
    ) -> None:
        """测试使用图片文件路径运行主函数。"""
        import argparse

        import bitool.skills.img2pdf as img2pdf_module

        output_path = tmp_path / "output.pdf"

        # 直接创建 skill 和 args，绕过 argparse 的歧义问题
        skill = img2pdf_module.Img2PdfSkill()
        args = argparse.Namespace(
            input_paths=[str(p) for p in sample_images],
            output_path=str(output_path),
            page_size="auto",
        )

        scheduler = skill.create_scheduler(args)
        result = scheduler.run()

        # 验证结果
        assert result == {"base": True}
        assert output_path.exists()

        # 验证PDF页数
        pdf_doc = fitz.open(str(output_path))
        try:
            assert len(pdf_doc) == 3
        finally:
            pdf_doc.close()

    def test_main_auto_detect_images(
        self, sample_images: list[Path], tmp_path: Path
    ) -> None:
        """测试自动检测当前目录的图片文件。"""
        import argparse
        import shutil

        import bitool.skills.img2pdf as img2pdf_module

        output_path = tmp_path / "output.pdf"

        # 将图片拷贝到 tmp_path
        for img in sample_images:
            dest = tmp_path / img.name
            if dest != img:  # 避免拷贝到自身
                shutil.copy2(img, dest)

        # 切换到包含图片的目录
        original_cwd = Path.cwd()
        os.chdir(tmp_path)

        try:
            # 直接创建 skill 和 args，input_paths 为 None 触发自动检测
            skill = img2pdf_module.Img2PdfSkill()
            args = argparse.Namespace(
                input_paths=None,  # 自动检测
                output_path=str(output_path),
                page_size="auto",
            )

            scheduler = skill.create_scheduler(args)
            result = scheduler.run()

            # 验证结果
            assert result == {"base": True}
            assert output_path.exists()
        finally:
            os.chdir(original_cwd)

    def test_main_no_images_in_directory(self, tmp_path: Path, monkeypatch) -> None:
        """测试目录中没有图片文件的情况。"""
        import sys

        import bitool.skills.img2pdf as img2pdf_module

        # Mock sys.argv - 自动检测但没有图片
        monkeypatch.setattr(sys, "argv", ["img2pdf"])

        # 切换到空目录
        original_cwd = Path.cwd()
        os.chdir(tmp_path)

        try:
            # 应该退出并返回错误码
            with pytest.raises(SystemExit) as exc_info:
                img2pdf_module.main()

            assert exc_info.value.code == 1
        finally:
            os.chdir(original_cwd)

    def test_main_nonexistent_image(self, tmp_path: Path, monkeypatch) -> None:
        """测试不存在的图片文件。"""
        import sys

        import bitool.skills.img2pdf as img2pdf_module

        nonexistent = tmp_path / "nonexistent.png"

        # Mock sys.argv
        monkeypatch.setattr(
            sys, "argv", ["img2pdf", str(nonexistent), str(tmp_path / "output.pdf")]
        )

        with pytest.raises(SystemExit) as exc_info:
            img2pdf_module.main()

        assert exc_info.value.code == 1

    def test_main_unsupported_image_format(self, tmp_path: Path, monkeypatch) -> None:
        """测试不支持的图片格式。"""
        import sys

        import bitool.skills.img2pdf as img2pdf_module

        # 创建一个不支持格式的文件（webp不在支持列表中）
        unsupported_file = tmp_path / "test.webp"
        unsupported_file.write_text("fake image")

        # Mock sys.argv
        monkeypatch.setattr(
            sys,
            "argv",
            ["img2pdf", str(unsupported_file), str(tmp_path / "output.pdf")],
        )

        with pytest.raises(SystemExit) as exc_info:
            img2pdf_module.main()

        assert exc_info.value.code == 1

    def test_main_unsupported_output_format(
        self, sample_images: list[Path], tmp_path: Path, monkeypatch
    ) -> None:
        """测试不支持的输出格式。"""
        import sys

        import bitool.skills.img2pdf as img2pdf_module

        output_path = tmp_path / "output.docx"  # 不支持的格式
        input_files = [str(p) for p in sample_images]

        # Mock sys.argv
        monkeypatch.setattr(sys, "argv", ["img2pdf", *input_files, str(output_path)])

        with pytest.raises(SystemExit) as exc_info:
            img2pdf_module.main()

        assert exc_info.value.code == 1

    def test_main_default_output_path(
        self, sample_images: list[Path], tmp_path: Path, monkeypatch
    ) -> None:
        """测试默认输出路径(使用第一张图片所在目录)。"""
        import sys

        import bitool.skills.img2pdf as img2pdf_module

        # sample_images 已经在 tmp_path 中（通过 fixture 拷贝）
        # Mock sys.argv - 不指定输出路径
        input_files = [str(p) for p in sample_images]
        monkeypatch.setattr(
            sys, "argv", ["img2pdf", *input_files, "--page-size", "auto"]
        )

        with pytest.raises(SystemExit):
            img2pdf_module.main()

        # 验证默认输出文件被创建
        default_output = tmp_path / "output.pdf"
        assert default_output.exists()
