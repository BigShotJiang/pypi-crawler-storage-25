# Internal Model Go Example

This example demonstrates using the MCA SDK with an internal ML model in Go.

## Prerequisites

- Go 1.21+
- OTel Collector running at `http://localhost:4318`

## Installation

### Development (from source)

When working from the monorepo:

```bash
cd mca-prototype/sdk-examples/internal-model-go
go run main.go
```

The go.mod includes a `replace` directive for local development.

### Production (from GitLab)

The SDK is in a private GitLab repository. Complete this one-time setup first:

```bash
# 1. Set Git credentials (use a token with read_repository scope)
git config --global url."https://oauth2:YOUR_GITLAB_TOKEN@gitlab.com/".insteadOf "https://gitlab.com/"

# 2. Bypass the public module proxy for private repos
export GOPRIVATE=gitlab.com/bhsf/*
export GONOSUMDB=gitlab.com/bhsf/*
```

Then remove the `replace` directive from go.mod and install:

```bash
# Remove the replace directive from go.mod, then:
go get gitlab.com/bhsf/ai_ml/model-monitoring/sdk/mca-prototype/mca-sdk-go@mca-prototype/mca-sdk-go/v0.1.0
go build
./internal-model-go
```

## Running the Example

```bash
# Ensure OTel Collector is running
docker-compose -f ../../docker-compose.yml up -d otel-collector

# Run the example
go run main.go
```

The example will:
1. Initialize the MCA SDK client
2. Record single predictions
3. Record multiple sequential predictions
4. Demonstrate concurrent prediction recording
5. Show context timeout handling

## Output

You should see log output showing:
- SDK initialization
- Prediction recordings
- Telemetry being sent to OTel Collector

Check the OTel Collector logs to see exported metrics and traces.
