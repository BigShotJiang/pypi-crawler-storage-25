"""Secret Manager client for fetching secrets from GCP Secret Manager.

This module provides the SecretManagerClient for securely fetching secrets
from GCP Secret Manager with automatic caching and fallback to environment variables.

Configuration:
    All policy values can be configured via environment variables:
    - MCA_SECRET_CACHE_TTL: Default cache time-to-live in seconds (default: 3600)
    - MCA_SECRET_MAX_CACHE_TTL: Maximum allowed TTL in seconds (default: 604800 = 1 week)
    - MCA_SECRET_FAILURE_CACHE_TTL: TTL for caching transient failures (default: 10)
    - MCA_SECRET_DEBOUNCE_TTL: Debounce TTL for deterministic errors (default: 1)

Example:
    export MCA_SECRET_CACHE_TTL=1800  # 30 minutes default cache
    export MCA_SECRET_MAX_CACHE_TTL=86400  # 24 hours max
    export MCA_SECRET_FAILURE_CACHE_TTL=5  # 5 second failure cache
    export MCA_SECRET_DEBOUNCE_TTL=2  # 2 second debounce
"""

import atexit
import logging
import os
import re
import threading
import time
from typing import Dict, Optional, Tuple, Any
from urllib.parse import urlparse, parse_qs

from google.cloud import secretmanager
from google.api_core import exceptions as gcp_exceptions

from ..utils.exceptions import MCASDKError

logger = logging.getLogger(__name__)

# Sentinel object to mark cache entries being refreshed
_REFRESHING = object()


# Wrapper class for cached failures
class _CachedFailure:
    """Wrapper for cached failure to prevent thundering herd on downstream failures."""

    def __init__(self, error: Exception):
        self.error = error
        self.error_type = type(error).__name__
        self.error_message = str(error)


# Module-level singleton instance
_singleton_client = None
_singleton_lock = threading.Lock()


class SecretManagerError(MCASDKError):
    """Base exception for Secret Manager operations.

    This is the base class for all Secret Manager-related exceptions.
    Catch specific subclasses for fine-grained error handling, or catch
    this base class to handle all Secret Manager errors.

    Examples:
        - Failed to connect to GCP Secret Manager
        - Secret not found
        - Invalid secret URL format
        - Authentication failure
    """


class SecretNotFoundError(SecretManagerError):
    """Raised when a secret does not exist in GCP Secret Manager.

    This typically means:
    - Secret name is incorrect
    - Secret was deleted
    - Project ID is wrong
    - Version number/name is invalid

    Example:
        try:
            secret = client.fetch_secret("secret://proj/nonexistent/latest")
        except SecretNotFoundError:
            # Handle missing secret - maybe use default value
            pass
    """


class SecretPermissionError(SecretManagerError):
    """Raised when the service account lacks permission to access a secret.

    This typically means:
    - Service account missing secretmanager.versions.access permission
    - Secret exists but IAM policy denies access
    - Wrong service account credentials

    Example:
        try:
            secret = client.fetch_secret("secret://proj/restricted/latest")
        except SecretPermissionError:
            # Handle permission error - log security issue
            logger.error("Insufficient permissions to access secret")
    """


class SecretAuthenticationError(SecretManagerError):
    """Raised when GCP authentication fails.

    This typically means:
    - GOOGLE_APPLICATION_CREDENTIALS not set or invalid
    - Service account key expired or revoked
    - ADC (Application Default Credentials) not configured

    Example:
        try:
            secret = client.fetch_secret("secret://proj/token/latest")
        except SecretAuthenticationError:
            # Handle auth error - check credentials
            logger.error("GCP authentication failed - check credentials")
    """


class SecretInvalidURLError(SecretManagerError):
    """Raised when secret URL format is invalid.

    This typically means:
    - URL doesn't match secret:// pattern
    - Missing required components (project, secret name)
    - Invalid characters in URL

    Example:
        try:
            secret = client.fetch_secret("invalid-url")
        except SecretInvalidURLError:
            # Handle invalid URL - fix format
            logger.error("Invalid secret URL format")
    """


class SecretNetworkError(SecretManagerError):
    """Raised when network/connectivity issues prevent secret fetch.

    This typically means:
    - GCP API endpoint unreachable
    - Network timeout
    - DNS resolution failure
    - Firewall blocking traffic

    Example:
        try:
            secret = client.fetch_secret("secret://proj/token/latest")
        except SecretNetworkError:
            # Handle network error - retry or use fallback
            logger.error("Network error accessing Secret Manager")
    """


class SecretDecodingError(SecretManagerError):
    """Raised when secret payload cannot be decoded as UTF-8.

    This typically means:
    - Secret contains binary data (not text)
    - Secret encoding is not UTF-8
    - Corrupted secret data

    Example:
        try:
            secret = client.fetch_secret("secret://proj/binary-data/latest")
        except SecretDecodingError:
            # Handle non-text secret
            logger.error("Secret contains non-UTF-8 data")
    """


class SecretManagerClient:
    """Client for fetching secrets from GCP Secret Manager.

    Features:
        - Parse secret:// URLs
        - Fetch secrets from GCP Secret Manager
        - In-memory caching with TTL and thread-safety
        - Automatic fallback to environment variables
        - Never logs actual secret values
        - Singleton pattern for efficient resource sharing
        - Intelligent failure caching (transient only)
        - Memory leak prevention for concurrency primitives

    Thread Safety:
        All methods are thread-safe. Cache access is protected by RLock.
        Concurrent fetches are protected against cache stampede via
        event-based coordination. Events are automatically cleaned up
        to prevent memory leaks.

    Resource Management:
        RECOMMENDED PATTERN (Singleton - Long-running services):
            >>> # At application startup - cleanup is automatically registered with atexit
            >>> client = SecretManagerClient.get_instance()
            >>> token = client.fetch_secret(
            ...     "secret://my-project/registry-token/latest",
            ...     fallback_env="MCA_REGISTRY_TOKEN"
            ... )
            >>>
            >>> # For containerized/serverless environments, ALSO register SIGTERM handler:
            >>> import signal
            >>> signal.signal(signal.SIGTERM, lambda s, f: client.close())

        ALTERNATIVE PATTERN (Direct instantiation - Scripts/Testing):
            >>> client = SecretManagerClient()  # atexit cleanup automatically registered
            >>> try:
            ...     token = client.fetch_secret("secret://my-project/token/latest")
            ... finally:
            ...     client.close()  # Explicitly close when done for immediate cleanup

        SERVERLESS PATTERN (Disable automatic cleanup):
            >>> # For AWS Lambda, Google Cloud Functions, etc. where atexit may not fire
            >>> client = SecretManagerClient(register_atexit=False)
            >>> # Manage cleanup manually based on runtime lifecycle

        TEST PATTERN (Avoid atexit handler accumulation):
            >>> # In test code, use register_atexit=False to prevent handler leak
            >>> client = SecretManagerClient(register_atexit=False)
            >>> # Or use the testing utility:
            >>> from mca_sdk.security._testing import reset_secret_manager_for_testing
            >>> reset_secret_manager_for_testing()  # Clears singleton

        ATEXIT HANDLER LIMITATION:
            Python's atexit module does NOT provide a deregistration API. Once
            `atexit.register(client.close)` is called, the handler persists until
            process exit. In test suites creating many client instances, this causes
            handler accumulation (100+ no-op close() calls at exit). Use
            `register_atexit=False` in tests to prevent this.

        Kubernetes/Container shutdown:
            While atexit provides automatic cleanup on normal process exit, containers
            terminated via SIGTERM may not always trigger atexit handlers before the grace
            period expires. Register a SIGTERM handler (shown above) for guaranteed cleanup.

    Failure Caching Policy:
        Transient errors (network failures) are cached for 10 seconds to prevent
        thundering herd on downstream service outages.

        Deterministic errors (404 Not Found, 403 Permission Denied, 401 Unauthorized,
        invalid URL, decode errors) are cached for 1 second as a debounce rate-limit.
        This prevents rapid-fire retry abuse and excessive API costs when configuration
        errors exist, while still allowing quick retry after fixes (1s delay vs 10s).

    Exceptions:
        Methods raise specific SecretManagerError subclasses for different failures:
        - SecretInvalidURLError: Invalid secret URL format
        - SecretNotFoundError: Secret not found in GCP
        - SecretPermissionError: Permission denied
        - SecretAuthenticationError: Authentication failure
        - SecretNetworkError: Network/connectivity issues (CACHED)
        - SecretDecodingError: Secret contains non-UTF-8 data
        - SecretManagerError: Generic/unexpected errors (CACHED)

        Catch specific exceptions for fine-grained handling, or catch
        SecretManagerError base class to handle all Secret Manager errors.
    """

    # Regex pattern for secret:// URLs
    # Format: secret://project-id/secret-name[/version][?ttl=seconds]
    # Version is optional, defaults to "latest"
    # TTL query parameter is optional, for per-secret cache duration
    SECRET_URL_PATTERN = re.compile(r'^secret://([^/\?]+)/([^/\?]+)(?:/([^/\?]+))?(?:\?.*)?$')

    # Default cache TTL in seconds (1 hour)
    DEFAULT_CACHE_TTL = 3600

    # Maximum allowed TTL in seconds (1 week) - prevents misconfiguration
    MAX_CACHE_TTL = 604800

    # Failure cache TTL in seconds (short duration to prevent thundering herd)
    # Only applies to TRANSIENT failures (network errors, timeouts)
    FAILURE_CACHE_TTL = 10

    # Debounce TTL for deterministic errors (1 second)
    # Prevents rapid-fire retry abuse and excessive API costs when configuration errors exist
    DETERMINISTIC_ERROR_DEBOUNCE_TTL = 1

    def __init__(
        self,
        project_id: Optional[str] = None,
        cache_ttl: Optional[int] = None,
        max_cache_ttl: Optional[int] = None,
        failure_cache_ttl: Optional[int] = None,
        deterministic_error_debounce_ttl: Optional[int] = None,
        register_atexit: bool = True
    ):
        """Initialize Secret Manager client.

        Args:
            project_id: Optional default GCP project ID
            cache_ttl: Cache time-to-live in seconds. If not provided, reads from
                      MCA_SECRET_CACHE_TTL environment variable or defaults to 3600 (1 hour)
            max_cache_ttl: Maximum allowed TTL in seconds. If not provided, reads from
                          MCA_SECRET_MAX_CACHE_TTL environment variable
                          or defaults to 604800 (1 week)
            failure_cache_ttl: TTL for caching transient failures
                             in seconds. If not provided, reads from
                             MCA_SECRET_FAILURE_CACHE_TTL env variable
                             or defaults to 10 seconds
            deterministic_error_debounce_ttl: Debounce TTL for deterministic errors in seconds.
                                            If not provided, reads from MCA_SECRET_DEBOUNCE_TTL
                                            environment variable or defaults to 1 second
            register_atexit: If True (default), automatically registers close() method with atexit
                           for safe-by-default cleanup on process
                           exit. Set to False for specialized use
                           cases like serverless environments where
                           manual resource management is needed.

        Raises:
            SecretManagerError: If GCP client initialization fails
        """
        try:
            self._client: Optional[
                secretmanager.SecretManagerServiceClient
            ] = secretmanager.SecretManagerServiceClient()
            # Cache structure: URL -> (value or _REFRESHING, timestamp, ttl_seconds)
            self._cache: Dict[str, Tuple[Any, float, float]] = {}
            self._lock = threading.RLock()
            # URL -> Event for refresh completion
            self._refresh_events: Dict[
                str, threading.Event
            ] = {}
            self._project_id = project_id

            # Resolve all TTL fields from: 1) parameter, 2) environment variable, 3) class default
            self._cache_ttl = self._resolve_env_int(
                cache_ttl, "MCA_SECRET_CACHE_TTL", self.DEFAULT_CACHE_TTL, "cache_ttl"
            )
            self.max_cache_ttl = self._resolve_env_int(
                max_cache_ttl, "MCA_SECRET_MAX_CACHE_TTL", self.MAX_CACHE_TTL, "max_cache_ttl"
            )
            self.failure_cache_ttl = self._resolve_env_int(
                failure_cache_ttl, "MCA_SECRET_FAILURE_CACHE_TTL",
                self.FAILURE_CACHE_TTL, "failure_cache_ttl"
            )
            self.deterministic_error_debounce_ttl = self._resolve_env_int(
                deterministic_error_debounce_ttl, "MCA_SECRET_DEBOUNCE_TTL",
                self.DETERMINISTIC_ERROR_DEBOUNCE_TTL, "deterministic_error_debounce_ttl"
            )

            if cache_ttl is not None:
                config_source = "parameter"
            elif "MCA_SECRET_CACHE_TTL" in os.environ:
                config_source = "MCA_SECRET_CACHE_TTL env"
            else:
                config_source = "default"
            logger.debug(
                "SecretManagerClient initialized successfully with cache TTL=%d seconds "
                "(configured via %s)",
                self._cache_ttl,
                config_source,
            )

            # Auto-register cleanup for safe-by-default behavior
            if register_atexit:
                atexit.register(self.close)
                logger.debug("Registered close() with atexit for automatic cleanup on process exit")
        except Exception as e:
            raise SecretManagerError(
                f"Failed to initialize Secret Manager client: {e}. "
                "Ensure GOOGLE_APPLICATION_CREDENTIALS is configured."
            )

    def _resolve_env_int(
        self,
        param_value: Optional[int],
        env_var_name: str,
        default: int,
        attr_name: str,
    ) -> int:
        """Resolve an integer config value from parameter, env var, or default.

        Resolution order (highest to lowest priority):
            1. Directly provided parameter value
            2. Environment variable (parsed and validated as non-negative int)
            3. Class-level default constant

        Args:
            param_value: Value passed directly to the constructor (or None if not provided)
            env_var_name: Name of the environment variable to check
            default: Fallback default value (typically a class constant)
            attr_name: Attribute name used only for internal traceability in logs

        Returns:
            The resolved integer value
        """
        if param_value is not None:
            return param_value
        env_val = os.getenv(env_var_name)
        if env_val is not None:
            try:
                value = int(env_val)
                if value < 0:
                    logger.warning(
                        "Invalid %s (must be >= 0), using default: %d",
                        env_var_name,
                        default,
                    )
                    return default
                return value
            except ValueError:
                logger.warning(
                    "Invalid %s (must be integer), using default: %d",
                    env_var_name,
                    default,
                )
                return default
        return default

    @classmethod
    def get_instance(
        cls,
        cache_ttl: Optional[int] = None,
        max_cache_ttl: Optional[int] = None,
        failure_cache_ttl: Optional[int] = None,
        deterministic_error_debounce_ttl: Optional[int] = None,
        register_atexit: bool = True
    ) -> "SecretManagerClient":
        """Get or create singleton instance of SecretManagerClient.

        Uses simple locking pattern for thread-safe singleton initialization.
        The Python GIL makes this safe and efficient.

        Args:
            cache_ttl: Cache time-to-live in seconds. Only used on first call.
                      Subsequent calls ignore this parameter.
            max_cache_ttl: Maximum allowed TTL in seconds. Only used on first call.
            failure_cache_ttl: TTL for caching transient failures. Only used on first call.
            deterministic_error_debounce_ttl: Debounce TTL for
                deterministic errors. Only used on first call.
            register_atexit: If True (default), automatically registers close() method with atexit.
                           Only used on first call. Set to False for specialized use cases
                           like serverless environments.

        Returns:
            Singleton SecretManagerClient instance
        """
        global _singleton_client
        with _singleton_lock:
            if _singleton_client is None:
                _singleton_client = cls(
                    cache_ttl=cache_ttl,
                    max_cache_ttl=max_cache_ttl,
                    failure_cache_ttl=failure_cache_ttl,
                    deterministic_error_debounce_ttl=deterministic_error_debounce_ttl,
                    register_atexit=register_atexit
                )
        return _singleton_client

    def close(self) -> None:
        """Close the Secret Manager client and clear cache.

        Should be called during application shutdown for graceful cleanup.
        Thread-safe and idempotent.
        """
        with self._lock:
            if hasattr(self, '_client') and self._client:
                try:
                    # Close the GCP client if it has a close method
                    if hasattr(self._client, 'close'):
                        self._client.close()
                except Exception as e:
                    logger.warning(f"Error closing Secret Manager client: {e}")
                finally:
                    self._client = None

            # Clear cache
            if hasattr(self, '_cache'):
                self._cache.clear()

            # Clear refresh events
            if hasattr(self, '_refresh_events'):
                self._refresh_events.clear()

            logger.debug("SecretManagerClient closed and cache cleared")

    def invalidate(self, secret_url: str) -> bool:
        """Proactively invalidate a specific secret from cache.

        Use this when a secret is known to have been rotated or compromised,
        forcing a fresh fetch on the next access.

        Args:
            secret_url: Secret URL to invalidate (will be canonicalized)

        Returns:
            True if secret was in cache and removed, False otherwise

        Thread Safety:
            Fully thread-safe. Safe to call concurrently.

        Example:
            >>> client.invalidate("secret://my-project/rotated-token/latest")
            True
        """
        cache_key = self._canonicalize_secret_url(secret_url)
        with self._lock:
            if cache_key in self._cache:
                del self._cache[cache_key]
                logger.info(f"Proactively invalidated secret from cache: {cache_key}")
                return True
            return False

    def clear_cache(self) -> int:
        """Clear all cached secrets.

        Use sparingly - typically only needed during secret rotation events
        or in testing scenarios.

        Returns:
            Number of cache entries cleared

        Thread-safe.
        """
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
            logger.info(f"Cleared all cached secrets (count: {count})")
            return count

    def _canonicalize_secret_url(self, secret_url: str) -> str:
        """Canonicalize secret URL for cache key consistency.

        Different but equivalent URLs (e.g., with/without explicit '/latest')
        are normalized to the same cache key to prevent redundant entries.

        Args:
            secret_url: Raw secret URL

        Returns:
            Canonicalized secret URL

        Examples:
            >>> client._canonicalize_secret_url("secret://proj/secret")
            'secret://proj/secret/latest'
            >>> client._canonicalize_secret_url("secret://proj/secret/latest")
            'secret://proj/secret/latest'
        """
        # Parse and reconstruct to normalize
        project_id, secret_name, version = self._parse_secret_url(secret_url)
        return f"secret://{project_id}/{secret_name}/{version}"

    def _claim_refresh(self, cache_key: str, current_time: float, secret_ttl: float) -> None:
        """Mark a cache entry as being refreshed and create a waiter event.

        Must be called with self._lock held.
        """
        self._cache[cache_key] = (_REFRESHING, current_time, secret_ttl)
        self._refresh_events[cache_key] = threading.Event()

    def _resolve_cache_state(self, cache_key: str, secret_ttl: float) -> Tuple[str, Any]:
        """Thread-safe cache-state resolution for stampede protection.

        Returns:
            ("return", value)  — cache hit; caller should return value.
            ("refresh", None)  — caller claimed refresh responsibility; do the fetch.
            ("wait", Event)    — another thread is fetching; wait on the event.

        Raises:
            Cached failure exception if a previous fetch failed and TTL has not expired.
        """
        current_time = time.monotonic()

        with self._lock:
            if cache_key not in self._cache:
                logger.debug(f"Secret not in cache: {cache_key}, fetching")
                self._claim_refresh(cache_key, current_time, secret_ttl)
                return ("refresh", None)

            cached_entry, cached_time, cached_ttl = self._cache[cache_key]

            # Another thread is already fetching — hand back the event to wait on
            if cached_entry is _REFRESHING:
                if cache_key not in self._refresh_events:
                    self._refresh_events[cache_key] = threading.Event()
                logger.debug(f"Another thread is refreshing secret {cache_key}, waiting on event")
                return ("wait", self._refresh_events[cache_key])

            # Cached failure — re-raise if still within TTL, otherwise retry
            if isinstance(cached_entry, _CachedFailure):
                failure_age = current_time - cached_time
                if failure_age < cached_ttl:
                    logger.debug(
                        f"Returning cached failure for {cache_key} "
                        f"(age: {int(failure_age)}s, TTL: {cached_ttl}s)"
                    )
                    raise type(cached_entry.error)(
                        f"Cached failure (from "
                        f"{int(failure_age)}s ago): "
                        f"{cached_entry.error_message}"
                    )
                logger.debug(f"Cached failure expired for {cache_key}, retrying fetch")
                self._claim_refresh(cache_key, current_time, secret_ttl)
                return ("refresh", None)

            # TTL=0 means "do not cache"
            if cached_ttl == 0:
                logger.debug(f"Secret has TTL=0 (do not cache), refreshing: {cache_key}")
                self._claim_refresh(cache_key, current_time, secret_ttl)
                return ("refresh", None)

            cache_age = current_time - cached_time
            if cache_age < cached_ttl:
                logger.debug(
                    f"Secret cache hit for {cache_key} "
                    f"(age: {int(cache_age)}s, TTL: {cached_ttl}s)"
                )
                return ("return", cached_entry)

            # Expired — claim refresh
            logger.debug(
                f"Secret cache expired for {cache_key} "
                f"(age: {int(cache_age)}s, TTL: {cached_ttl}s), refreshing"
            )
            self._claim_refresh(cache_key, current_time, secret_ttl)
            return ("refresh", None)

    def fetch_secret(self, secret_url: str, fallback_env: Optional[str] = None) -> str:
        """Fetch secret from Secret Manager with fallback.

        Prevents cache stampede: Only one thread will fetch a secret when cache expires.
        Other threads wait efficiently using threading.Event until the refreshed value is ready.

        Supports per-secret TTL via query parameter:
            secret://project/secret/latest?ttl=1800  # Cache for 30 minutes
            secret://project/token/latest?ttl=0      # Do not cache

        Args:
            secret_url: Secret reference (secret://project/secret/version[?ttl=seconds]).
                       Version is optional and defaults to "latest".
                       TTL query parameter is optional and overrides default cache TTL.
            fallback_env: Environment variable name for fallback when GCP unavailable

        Returns:
            Secret value (never logged)

        Raises:
            SecretInvalidURLError: If secret URL format is invalid
            SecretNotFoundError: If secret does not exist
            SecretPermissionError: If permission denied
            SecretAuthenticationError: If authentication fails
            SecretNetworkError: If network/connectivity issues
            SecretDecodingError: If secret contains non-UTF-8 data
            SecretManagerError: For other unexpected errors

        Thread Safety:
            Fully thread-safe. Multiple concurrent calls for the same secret
            will only trigger one GCP fetch (stampede protection).

        Security:
            - Secrets cached in memory only (never disk)
            - Secret values never logged (URLs and secret names are safe to log)
            - Thread-safe cache access with stampede protection
            - Cache entries expire after TTL (global or per-secret)
        """
        # Canonicalize URL for consistent cache keys
        cache_key = self._canonicalize_secret_url(secret_url)

        # Parse TTL from URL (if specified)
        secret_ttl = self._parse_ttl_from_url(secret_url)

        refresh_wait_timeout = 30.0  # Max time to wait for another thread's refresh (seconds)

        while True:
            action, payload = self._resolve_cache_state(cache_key, secret_ttl)
            if action == "return":
                return str(payload)
            if action == "wait":
                if not payload.wait(timeout=refresh_wait_timeout):
                    raise SecretManagerError(
                        f"Timeout waiting for secret refresh: {cache_key}. "
                        "Another thread may have encountered an error during fetch."
                    )
                logger.debug(f"Refresh event triggered for {cache_key}, rechecking cache")
                continue
            break  # action == "refresh" — fall through to GCP fetch

        # Critical: Use try/finally to guarantee _REFRESHING cleanup on ANY failure
        # This prevents cache poisoning where a failed fetch leaves the sentinel
        try:
            # Parse URL (outside lock - this is fast and doesn't hit network)
            # Note: cache_key is already canonicalized, but we need components
            project_id, secret_name, version = self._parse_secret_url(cache_key)

            # Fetch from GCP (outside lock - this is I/O bound)
            secret_value = self._fetch_from_gcp(project_id, secret_name, version)

            # Update cache with fetched value (thread-safe)
            with self._lock:
                self._cache[cache_key] = (secret_value, time.monotonic(), secret_ttl)
                # CRITICAL: Always clean up event to prevent memory leak
                self._cleanup_refresh_event(cache_key)

            logger.debug(
                f"Successfully fetched and cached secret: {cache_key} "
                f"(TTL: {secret_ttl}s{' [no cache]' if secret_ttl == 0 else ''})"
            )
            return secret_value

        except (SecretNotFoundError, SecretPermissionError, SecretAuthenticationError,
                SecretInvalidURLError, SecretDecodingError, SecretNetworkError) as e:
            # Specific Secret Manager errors - already properly typed
            # Log with context: secret name/path but never the secret value
            logger.error(
                f"Failed to fetch secret from GCP Secret Manager. "
                f"Secret: {project_id}/{secret_name}/{version}, "
                f"Error: {str(e)}"
            )

            # Try fallback to environment variable
            if fallback_env:
                fallback_value = os.getenv(fallback_env)
                if fallback_value:
                    logger.warning(
                        f"Using fallback environment variable "
                        f"{fallback_env} for secret "
                        f"{cache_key}. "
                        f"This should only happen in "
                        f"local development."
                    )
                    # Cache the fallback value (not a failure)
                    with self._lock:
                        self._cache[cache_key] = (fallback_value, time.monotonic(), secret_ttl)
                    return fallback_value
                # Fallback configured but not available
                error = type(e)(
                    f"{str(e)} Fallback environment "
                    f"variable {fallback_env} also not set."
                )
            else:
                # No fallback configured - wrap with context
                error = type(e)(f"{str(e)} No fallback configured.")

            # Determine if this is a transient or deterministic failure
            is_transient = isinstance(e, (SecretNetworkError,))
            is_deterministic = isinstance(
                e,
                (
                    SecretNotFoundError,
                    SecretPermissionError,
                    SecretAuthenticationError,
                    SecretInvalidURLError,
                    SecretDecodingError,
                ),
            )

            # Cache failures to prevent abuse, with different TTLs based on error type
            with self._lock:
                if is_transient:
                    # TRANSIENT failures (network errors) cached
                    # longer to prevent thundering herd
                    self._cache[cache_key] = (
                        _CachedFailure(error),
                        time.monotonic(),
                        self.failure_cache_ttl,
                    )
                    logger.debug(
                        f"Cached TRANSIENT failure for "
                        f"{cache_key} "
                        f"(TTL: {self.failure_cache_ttl}s) "
                        "to prevent thundering herd on "
                        "service outages"
                    )
                elif is_deterministic:
                    # DETERMINISTIC errors (404, 403, 401) cached
                    # briefly (1s) to prevent rapid-fire abuse.
                    # Short TTL allows quick retry after config
                    # fix while preventing excessive API costs
                    self._cache[cache_key] = (
                        _CachedFailure(error),
                        time.monotonic(),
                        self.deterministic_error_debounce_ttl,
                    )
                    logger.debug(
                        f"Cached DETERMINISTIC failure for "
                        f"{cache_key} (TTL: "
                        f"{self.deterministic_error_debounce_ttl}"
                        f"s) ({type(e).__name__}): debounce "
                        "rate-limiting to prevent retry abuse"
                    )
                else:
                    # Unknown error type - cache with transient
                    # TTL to be safe
                    self._cache[cache_key] = (
                        _CachedFailure(error),
                        time.monotonic(),
                        self.failure_cache_ttl,
                    )
                    logger.debug(
                        f"Cached UNKNOWN failure for {cache_key} (TTL: {self.failure_cache_ttl}s)"
                    )
                # CRITICAL: Always clean up event to prevent memory leak
                self._cleanup_refresh_event(cache_key)

            raise error

        except Exception as e:
            # Catch ANY other exception (programming errors, etc.) and wrap
            logger.error(
                f"Unexpected exception during secret "
                f"fetch for {cache_key}: "
                f"{type(e).__name__}: {e}"
            )
            unexpected_error = SecretManagerError(
                f"Unexpected error fetching secret "
                f"{cache_key}: {type(e).__name__}: {e}"
            )

            # Cache unexpected errors (treat as transient)
            with self._lock:
                self._cache[cache_key] = (
                    _CachedFailure(unexpected_error),
                    time.monotonic(),
                    self.failure_cache_ttl,
                )
                logger.debug(
                    f"Cached UNEXPECTED failure for {cache_key} (TTL: {self.failure_cache_ttl}s) "
                    "to prevent thundering herd on unknown error"
                )
                # CRITICAL: Always clean up event to prevent memory leak
                self._cleanup_refresh_event(cache_key)

            raise unexpected_error

    def _parse_secret_url(self, secret_url: str) -> Tuple[str, str, str]:
        """Parse secret:// URL into components.

        Args:
            secret_url: Secret URL to parse

        Returns:
            Tuple of (project_id, secret_name, version)

        Raises:
            SecretInvalidURLError: If URL format is invalid
        """
        match = self.SECRET_URL_PATTERN.match(secret_url)
        if not match:
            raise SecretInvalidURLError(
                f"Invalid secret URL format: {secret_url}. "
                f"Expected format: secret://project-id/secret-name[/version][?ttl=seconds]"
            )

        project_id, secret_name, version = match.groups()
        version = version or "latest"  # Default to latest if not specified

        return project_id, secret_name, version

    def _cleanup_refresh_event(self, cache_key: str) -> None:
        """Clean up refresh event for a secret to prevent memory leak.

        CRITICAL: This method MUST be called after every fetch (success or failure)
        to prevent the _refresh_events dictionary from growing indefinitely.

        Args:
            cache_key: Canonicalized secret URL

        Thread Safety:
            Must be called while holding self._lock
        """
        if cache_key in self._refresh_events:
            # Signal waiting threads
            self._refresh_events[cache_key].set()
            # Remove event to prevent memory leak
            del self._refresh_events[cache_key]
            logger.debug(f"Cleaned up refresh event for {cache_key} (memory leak prevention)")

    def _parse_ttl_from_url(self, secret_url: str) -> int:
        """Parse and validate TTL from secret URL query parameter.

        TTL Configuration Precedence (highest to lowest):
        1. Per-secret TTL via query parameter (?ttl=seconds)
        2. Instance-level TTL (constructor parameter)
        3. Environment variable (MCA_SECRET_CACHE_TTL)
        4. Default TTL (3600 seconds = 1 hour)

        Args:
            secret_url: Secret URL potentially containing ?ttl=seconds

        Returns:
            Validated TTL in seconds (clamped to [0, MAX_CACHE_TTL])

        Validation Rules:
            - TTL=0 is valid ("do not cache")
            - Negative values fallback to default with warning
            - Values > MAX_CACHE_TTL (1 week) are clamped with warning
            - Non-numeric values fallback to default with warning

        Examples:
            >>> client._parse_ttl_from_url("secret://proj/secret/latest?ttl=1800")
            1800
            >>> client._parse_ttl_from_url("secret://proj/secret/latest")
            3600  # Uses instance/env/default TTL
            >>> client._parse_ttl_from_url("secret://proj/secret/latest?ttl=0")
            0  # "do not cache"
            >>> client._parse_ttl_from_url("secret://proj/secret/latest?ttl=999999999")
            604800  # Clamped to MAX_CACHE_TTL (1 week)
        """
        try:
            parsed = urlparse(secret_url)
            query_params = parse_qs(parsed.query)

            if 'ttl' in query_params:
                ttl_str = query_params['ttl'][0]
                ttl = int(ttl_str)

                # Validate: TTL=0 is valid ("do not cache")
                if ttl < 0:
                    logger.warning(
                        f"Invalid TTL value '{ttl}' in secret URL (must be >= 0). "
                        f"Using default: {self._cache_ttl}"
                    )
                    return self._cache_ttl

                # Validate: Clamp excessive TTL to prevent misconfiguration
                if ttl > self.max_cache_ttl:
                    logger.warning(
                        f"TTL value '{ttl}' exceeds maximum {self.max_cache_ttl}s (1 week). "
                        f"Clamping to maximum for safety."
                    )
                    return self.max_cache_ttl

                return ttl
            else:
                # No TTL specified - use instance default (which may come from env or default)
                return self._cache_ttl

        except (ValueError, IndexError) as e:
            logger.warning(
                f"Failed to parse TTL from secret URL '{secret_url}': {e}. "
                f"Using default: {self._cache_ttl}"
            )
            return self._cache_ttl

    def _fetch_from_gcp(self, project_id: str, secret_name: str, version: str) -> str:
        """Fetch secret value from GCP Secret Manager.

        Args:
            project_id: GCP project ID
            secret_name: Name of the secret
            version: Version of the secret (or "latest")

        Returns:
            Secret value as string

        Raises:
            SecretNotFoundError: If secret does not exist
            SecretPermissionError: If permission denied
            SecretAuthenticationError: If authentication fails
            SecretDecodingError: If secret contains non-UTF-8 data
            SecretNetworkError: If network/connectivity issues
            SecretManagerError: For other unexpected errors
        """
        # Build resource name
        name = f"projects/{project_id}/secrets/{secret_name}/versions/{version}"

        try:
            # Fetch secret
            if self._client is None:
                raise SecretManagerError("Secret Manager client is not initialized")
            response = self._client.access_secret_version(request={"name": name})
            secret_value = response.payload.data.decode("UTF-8")

            return secret_value

        except gcp_exceptions.NotFound:
            raise SecretNotFoundError(
                f"Secret not found: {project_id}/{secret_name}/{version}. "
                "Verify the secret exists in GCP Secret Manager."
            )
        except gcp_exceptions.PermissionDenied:
            raise SecretPermissionError(
                f"Permission denied accessing secret: {project_id}/{secret_name}/{version}. "
                "Verify service account has secretmanager.versions.access permission."
            )
        except gcp_exceptions.Unauthenticated:
            raise SecretAuthenticationError(
                "Authentication failed. Ensure GOOGLE_APPLICATION_CREDENTIALS "
                "is configured with valid credentials."
            )
        except UnicodeDecodeError as exc:
            raise SecretDecodingError(
                f"Secret contains non-UTF-8 data: {project_id}/{secret_name}/{version}. "
                "Secrets must be UTF-8 encoded strings."
            ) from exc
        except gcp_exceptions.GoogleAPIError as e:
            # Network, timeout, or other GCP API errors
            raise SecretNetworkError(
                f"Network error accessing secret {project_id}/{secret_name}/{version}: {str(e)}. "
                "Check network connectivity and GCP API availability."
            ) from e
        except Exception as e:
            # Log with context but sanitize sensitive details
            error_type = type(e).__name__
            logger.error(
                "Unexpected error fetching secret from GCP. Secret: %s/%s/%s, Error type: %s",
                project_id,
                secret_name,
                version,
                error_type,
            )
            raise SecretManagerError(
                f"Unexpected error fetching secret "
                f"{project_id}/{secret_name}/{version} "
                f"({error_type}). Check GCP credentials "
                "and network connectivity."
            ) from e
