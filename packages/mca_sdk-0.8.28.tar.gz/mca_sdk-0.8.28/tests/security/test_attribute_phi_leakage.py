import pytest
import re
import logging
from unittest.mock import MagicMock
from opentelemetry import trace
from mca_sdk.core.client import MCAClient

class TestAttributePHILleakage:
    @pytest.fixture
    def client(self):
        import os
        os.environ["MCA_VERBOSE_LOGGING"] = "true"
        
        client = MCAClient(
            service_name="test-service",
            model_id="mdl-001",
            team_name="test-team",
            strict_validation=False
        )
        return client

    @pytest.mark.xfail(reason="PHI filtering not yet implemented in SDK for extra attributes")
    def test_ssn_pattern_not_in_span_attributes(self, client, caplog):
        caplog.set_level(logging.INFO)
        with client.trace("test-span") as span:
            client.record_prediction(
                latency=0.5,
                prediction_id="pred-123",
                ssn_val="123-45-6789", # SSN pattern
                mrn_val="MRN123456789", # MRN pattern
                dob_val="01/01/1980" # DOB pattern
            )
            
        log_text = caplog.text
        
        assert "pred-123" in log_text, "Prediction ID should be logged"
        
        assert "123-45-6789" not in log_text, "SSN leaked into logs!"
        assert "MRN123456789" not in log_text, "MRN leaked into logs!"
        assert "01/01/1980" not in log_text, "DOB leaked into logs!"
