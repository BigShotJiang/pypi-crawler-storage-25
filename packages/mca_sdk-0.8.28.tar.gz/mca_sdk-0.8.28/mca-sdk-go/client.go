// Package mca provides OpenTelemetry instrumentation for ML models.
//
// The MCA (Model Collector Agent) SDK enables healthcare ML models to emit
// metrics, logs, and distributed traces through OpenTelemetry.
package mca

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"net/url"
	"sync"
	"time"

	"gitlab.com/bhsf/ai_ml/model-monitoring/sdk/mca-prototype/mca-sdk-go/config"
	"gitlab.com/bhsf/ai_ml/model-monitoring/sdk/mca-prototype/mca-sdk-go/internal/telemetry"
	"github.com/google/uuid"

	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/codes"
	"go.opentelemetry.io/otel/log"
	"go.opentelemetry.io/otel/metric"
	sdklog "go.opentelemetry.io/otel/sdk/log"
	sdkmetric "go.opentelemetry.io/otel/sdk/metric"
	"go.opentelemetry.io/otel/sdk/resource"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
	"go.opentelemetry.io/otel/trace"
)

const (
	// MaxCustomAttributes is the maximum number of custom attributes per prediction
	MaxCustomAttributes = 50
	// MaxAttributeValueLength is the maximum length for attribute string values
	MaxAttributeValueLength = 256
)

// ErrClientClosed is returned when operations are attempted on a closed client
var ErrClientClosed = errors.New("client has been shut down")

// ErrInstanceNotInitialized is returned when GetInstance is called before NewClient
var ErrInstanceNotInitialized = errors.New("MCA client not initialized")

// Singleton instance variables for global client access
var (
	instance   *Client
	instanceMu sync.RWMutex
)

// goalState tracks an active goal's span and timing information.
type goalState struct {
	span      trace.Span
	startTime time.Time
}

// Client is the main entry point for MCA SDK instrumentation.
// It manages OpenTelemetry providers and provides methods for recording
// model predictions with metrics, logs, and traces.
//
// Client is goroutine-safe and can be used concurrently from multiple goroutines.
type Client struct {
	config         *config.Config
	resource       *resource.Resource
	meterProvider  *sdkmetric.MeterProvider
	tracerProvider *sdktrace.TracerProvider
	loggerProvider *sdklog.LoggerProvider
	meter          metric.Meter
	tracer         trace.Tracer
	logger         log.Logger

	// Core metrics instruments
	predictionCounter metric.Int64Counter
	latencyHistogram  metric.Float64Histogram

	// Agentic AI metrics instruments
	goalsStartedCounter       metric.Int64Counter
	goalsCompletedCounter     metric.Int64Counter
	goalsFailedCounter        metric.Int64Counter
	goalDurationHistogram     metric.Float64Histogram
	toolCallsCounter          metric.Int64Counter
	toolLatencyHistogram      metric.Float64Histogram
	humanInterventionsCounter metric.Int64Counter
	policyViolationsCounter   metric.Int64Counter

	// Advanced core metrics instruments
	errorsCounter metric.Int64Counter
	maeHistogram  metric.Float64Histogram
	rmseHistogram metric.Float64Histogram

	// GenAI metrics instruments
	genaiRequestsCounter            metric.Int64Counter
	genaiTokensCounter              metric.Int64Counter
	genaiLatencyHistogram           metric.Float64Histogram
	genaiCostCounter                metric.Float64Counter
	genaiEmbeddingRequestsCounter   metric.Int64Counter
	genaiEmbeddingTokensCounter     metric.Int64Counter
	genaiEmbeddingLatencyHistogram  metric.Float64Histogram
	recoveriesCounter               metric.Int64Counter

	// Goal tracking state
	activeGoals map[string]*goalState
	goalsMu     sync.RWMutex

	// Registry client (optional)
	registryClient *RegistryClient
	thresholds     map[string]interface{}
	thresholdsMu   sync.RWMutex

	// Shutdown management
	shutdownOnce sync.Once
	shutdownErr  error
	isShutdown   bool
	mu           sync.RWMutex
}

// NewClient creates and initializes a new MCA Client with a context.
//
// SINGLETON BEHAVIOR: The first call creates a client and stores it as
// the singleton instance. Subsequent calls return the existing singleton,
// ignoring the provided configuration. Use GetInstance() to access the
// singleton, or call resetInstance() before NewClient() to create a new
// client (typically only needed in tests).
//
// The context is used for provider initialization and has a timeout to prevent
// indefinite hangs if the collector is unreachable.
//
// Example:
//
//	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
//	defer cancel()
//	cfg := &config.Config{
//	    ServiceName: "readmission-model",
//	    ModelID:     "mdl-001",
//	    TeamName:    "clinical-ai",
//	}
//	client, err := mca.NewClient(ctx, cfg)
//	if err != nil {
//	    return err
//	}
//	defer client.Shutdown()
func NewClient(ctx context.Context, cfg *config.Config) (*Client, error) {
	// Check if singleton already exists (strict singleton pattern)
	instanceMu.Lock()
	if instance != nil {
		instanceMu.Unlock()
		return instance, nil
	}
	defer instanceMu.Unlock()

	// Apply defaults and validate configuration
	cfg.ApplyDefaults()
	if err := cfg.Validate(); err != nil {
		return nil, err
	}

	// Create resource with model attributes
	res, err := telemetry.CreateResource(
		cfg.ServiceName,
		cfg.ModelID,
		cfg.ModelVersion,
		cfg.TeamName,
		cfg.ModelType,
		cfg.ModelCategory,
		Version, // Pass SDK version to avoid duplication
	)
	if err != nil {
		return nil, fmt.Errorf("failed to create resource: %w", err)
	}

	// Parse endpoint properly using net/url
	parsedURL, err := url.Parse(cfg.CollectorEndpoint)
	if err != nil {
		return nil, fmt.Errorf("invalid collector endpoint: %w", err)
	}
	endpoint := parsedURL.Host
	if endpoint == "" {
		endpoint = parsedURL.Path
	}

	// Create timeout context for initialization if not already bounded
	initCtx := ctx
	if _, hasDeadline := ctx.Deadline(); !hasDeadline {
		var cancel context.CancelFunc
		initCtx, cancel = context.WithTimeout(ctx, 30*time.Second)
		defer cancel()
	}

	// Setup OpenTelemetry providers
	meterProvider, err := telemetry.SetupMeterProvider(initCtx, endpoint, res, cfg.TLSInsecure, cfg.FilterSystemMetrics)
	if err != nil {
		return nil, fmt.Errorf("failed to setup meter provider: %w", err)
	}

	tracerProvider, err := telemetry.SetupTracerProvider(initCtx, endpoint, res, cfg.TLSInsecure)
	if err != nil {
		// Rollback with timeout context
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to setup tracer provider: %w", err)
	}

	loggerProvider, err := telemetry.SetupLoggerProvider(initCtx, endpoint, res, cfg.TLSInsecure)
	if err != nil {
		// Rollback with timeout context
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to setup logger provider: %w", err)
	}

	// Create meter, tracer, and logger from providers
	meter := meterProvider.Meter("mca-sdk-go")
	tracer := tracerProvider.Tracer("mca-sdk-go")
	logger := loggerProvider.Logger("mca-sdk-go")

	// Create metric instruments
	predictionCounter, err := meter.Int64Counter(
		"model.predictions_total",
		metric.WithDescription("Total number of model predictions"),
		metric.WithUnit("{prediction}"),
	)
	if err != nil {
		// Rollback with timeout context
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create prediction counter: %w", err)
	}

	latencyHistogram, err := meter.Float64Histogram(
		"model.latency_seconds",
		metric.WithDescription("Model prediction latency"),
		metric.WithUnit("s"),
	)
	if err != nil {
		// Rollback with timeout context
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create latency histogram: %w", err)
	}

	// Create Agentic AI metric instruments
	goalsStartedCounter, err := meter.Int64Counter(
		"agent.goals_started_total",
		metric.WithDescription("Total number of agent goals started"),
		metric.WithUnit("{goal}"),
	)
	if err != nil {
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create goals started counter: %w", err)
	}

	goalsCompletedCounter, err := meter.Int64Counter(
		"agent.goals_completed_total",
		metric.WithDescription("Total number of agent goals completed successfully"),
		metric.WithUnit("{goal}"),
	)
	if err != nil {
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create goals completed counter: %w", err)
	}

	goalsFailedCounter, err := meter.Int64Counter(
		"agent.goals_failed_total",
		metric.WithDescription("Total number of agent goals that failed"),
		metric.WithUnit("{goal}"),
	)
	if err != nil {
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create goals failed counter: %w", err)
	}

	goalDurationHistogram, err := meter.Float64Histogram(
		"agent.goal_duration_seconds",
		metric.WithDescription("Agent goal completion duration"),
		metric.WithUnit("s"),
	)
	if err != nil {
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create goal duration histogram: %w", err)
	}

	toolCallsCounter, err := meter.Int64Counter(
		"agent.tool_calls_total",
		metric.WithDescription("Total number of tool calls"),
		metric.WithUnit("{call}"),
	)
	if err != nil {
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create tool calls counter: %w", err)
	}

	toolLatencyHistogram, err := meter.Float64Histogram(
		"agent.tool_latency_seconds",
		metric.WithDescription("Tool execution latency"),
		metric.WithUnit("s"),
	)
	if err != nil {
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create tool latency histogram: %w", err)
	}

	humanInterventionsCounter, err := meter.Int64Counter(
		"agent.human_interventions_total",
		metric.WithDescription("Total number of human interventions"),
		metric.WithUnit("{intervention}"),
	)
	if err != nil {
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create human interventions counter: %w", err)
	}

	policyViolationsCounter, err := meter.Int64Counter(
		"agent.policy_violations_total",
		metric.WithDescription("Total number of policy violations"),
		metric.WithUnit("{violation}"),
	)
	if err != nil {
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create policy violations counter: %w", err)
	}

	// Create advanced core metric instruments
	errorsCounter, err := meter.Int64Counter(
		"model.errors_total",
		metric.WithDescription("Total number of model errors"),
		metric.WithUnit("{error}"),
	)
	if err != nil {
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create errors counter: %w", err)
	}

	maeHistogram, err := meter.Float64Histogram(
		"model.mae",
		metric.WithDescription("Model Mean Absolute Error evaluation metric"),
		metric.WithUnit("1"),
	)
	if err != nil {
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create MAE histogram: %w", err)
	}

	rmseHistogram, err := meter.Float64Histogram(
		"model.rmse",
		metric.WithDescription("Model Root Mean Squared Error evaluation metric"),
		metric.WithUnit("1"),
	)
	if err != nil {
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create RMSE histogram: %w", err)
	}

	// Create GenAI metric instruments
	genaiRequestsCounter, err := meter.Int64Counter(
		"genai.requests_total",
		metric.WithDescription("Total number of GenAI LLM requests"),
		metric.WithUnit("{request}"),
	)
	if err != nil {
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create genai requests counter: %w", err)
	}

	genaiTokensCounter, err := meter.Int64Counter(
		"genai.tokens_total",
		metric.WithDescription("Total number of GenAI tokens (prompt + completion)"),
		metric.WithUnit("{token}"),
	)
	if err != nil {
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create genai tokens counter: %w", err)
	}

	genaiLatencyHistogram, err := meter.Float64Histogram(
		"genai.latency_seconds",
		metric.WithDescription("GenAI request latency"),
		metric.WithUnit("s"),
	)
	if err != nil {
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create genai latency histogram: %w", err)
	}

	genaiCostCounter, err := meter.Float64Counter(
		"genai.cost_dollars",
		metric.WithDescription("Total GenAI cost in dollars"),
		metric.WithUnit("USD"),
	)
	if err != nil {
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create genai cost counter: %w", err)
	}

	genaiEmbeddingRequestsCounter, err := meter.Int64Counter(
		"genai.embedding.requests_total",
		metric.WithDescription("Total number of GenAI embedding requests"),
		metric.WithUnit("{request}"),
	)
	if err != nil {
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create genai embedding requests counter: %w", err)
	}

	genaiEmbeddingTokensCounter, err := meter.Int64Counter(
		"genai.embedding.tokens_total",
		metric.WithDescription("Total number of GenAI embedding input tokens"),
		metric.WithUnit("{token}"),
	)
	if err != nil {
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create genai embedding tokens counter: %w", err)
	}

	genaiEmbeddingLatencyHistogram, err := meter.Float64Histogram(
		"genai.embedding.latency_seconds",
		metric.WithDescription("GenAI embedding request latency"),
		metric.WithUnit("s"),
	)
	if err != nil {
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create genai embedding latency histogram: %w", err)
	}

	recoveriesCounter, err := meter.Int64Counter(
		"model.recoveries_total",
		metric.WithDescription("Total number of model recoveries after errors"),
		metric.WithUnit("{recovery}"),
	)
	if err != nil {
		rollbackCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = meterProvider.Shutdown(rollbackCtx)
		_ = tracerProvider.Shutdown(rollbackCtx)
		_ = loggerProvider.Shutdown(rollbackCtx)
		cancel()
		return nil, fmt.Errorf("failed to create recoveries counter: %w", err)
	}

	client := &Client{
		config:         cfg,
		resource:       res,
		meterProvider:  meterProvider,
		tracerProvider: tracerProvider,
		loggerProvider: loggerProvider,
		meter:          meter,
		tracer:         tracer,
		logger:         logger,

		// Core metrics
		predictionCounter: predictionCounter,
		latencyHistogram:  latencyHistogram,

		// Agentic AI metrics
		goalsStartedCounter:       goalsStartedCounter,
		goalsCompletedCounter:     goalsCompletedCounter,
		goalsFailedCounter:        goalsFailedCounter,
		goalDurationHistogram:     goalDurationHistogram,
		toolCallsCounter:          toolCallsCounter,
		toolLatencyHistogram:      toolLatencyHistogram,
		humanInterventionsCounter: humanInterventionsCounter,
		policyViolationsCounter:   policyViolationsCounter,

		// Advanced core metrics
		errorsCounter: errorsCounter,
		maeHistogram:  maeHistogram,
		rmseHistogram: rmseHistogram,

		// GenAI metrics
		genaiRequestsCounter:           genaiRequestsCounter,
		genaiTokensCounter:             genaiTokensCounter,
		genaiLatencyHistogram:          genaiLatencyHistogram,
		genaiCostCounter:               genaiCostCounter,
		genaiEmbeddingRequestsCounter:  genaiEmbeddingRequestsCounter,
		genaiEmbeddingTokensCounter:    genaiEmbeddingTokensCounter,
		genaiEmbeddingLatencyHistogram: genaiEmbeddingLatencyHistogram,
		recoveriesCounter:              recoveriesCounter,

		// Goal tracking state
		activeGoals: make(map[string]*goalState),

		// Initialize thresholds map
		thresholds: make(map[string]interface{}),

		isShutdown: false,
	}

	// Log PHI/PII warnings once at startup
	if cfg.CaptureInputData {
		var r log.Record
		r.SetSeverity(log.SeverityWarn)
		r.SetBody(log.StringValue("WARNING: Input data capture enabled. Ensure all PHI/PII is sanitized BEFORE passing to SDK."))
		client.logger.Emit(ctx, r)
	}
	if cfg.CaptureOutputData {
		var r log.Record
		r.SetSeverity(log.SeverityWarn)
		r.SetBody(log.StringValue("WARNING: Output data capture enabled. Ensure all PHI/PII is sanitized BEFORE passing to SDK."))
		client.logger.Emit(ctx, r)
	}

	// Store as singleton (we hold the lock from the beginning of the function)
	instance = client

	return client, nil
}

// RecordPrediction records a model prediction event with metrics, logs, and traces.
//
// This method creates a trace span, increments the prediction counter, records latency
// if provided, and emits a structured log with the prediction details.
//
// The context is used for trace propagation and cancellation. If the context
// contains an active span, the prediction will be correlated with that span.
//
// Custom attributes are validated and limited to 50 attributes with 256 char values.
//
// Example:
//
//	latency := 0.15
//	pred := &mca.Prediction{
//	    Latency:      &latency,
//	    PredictionID: "pred-123",
//	    Attributes: map[string]string{
//	        "model_version": "2.0",
//	        "input_size":    "1024",
//	    },
//	}
//	err := client.RecordPrediction(ctx, pred)
func (c *Client) RecordPrediction(ctx context.Context, pred *Prediction) error {
	c.mu.RLock()
	defer c.mu.RUnlock() // Hold read lock for entire method to prevent race with Shutdown

	if c.isShutdown {
		return ErrClientClosed
	}

	// Create trace span for correlation
	ctx, span := c.tracer.Start(ctx, "record_prediction",
		trace.WithSpanKind(trace.SpanKindInternal),
	)
	defer span.End()

	// Build system attributes first (will take precedence)
	attrs := []attribute.KeyValue{
		attribute.String("model.id", c.config.ModelID),
		attribute.String("model.version", c.config.ModelVersion),
		attribute.String("model.type", c.config.ModelType),
	}

	if pred.PredictionID != "" {
		attrs = append(attrs, attribute.String("prediction.id", pred.PredictionID))
		span.SetAttributes(attribute.String("prediction.id", pred.PredictionID))
	}

	// Validate and add custom attributes (before system attrs to allow system override)
	if len(pred.Attributes) > 0 {
		if len(pred.Attributes) > MaxCustomAttributes {
			var r log.Record
			r.SetSeverity(log.SeverityWarn)
			r.SetBody(log.StringValue(fmt.Sprintf("Prediction has %d attributes, maximum %d allowed - excess ignored", len(pred.Attributes), MaxCustomAttributes)))
			c.logger.Emit(ctx, r)
		}

		count := 0
		for k, v := range pred.Attributes {
			if count >= MaxCustomAttributes {
				break
			}
			// Truncate long values
			if len(v) > MaxAttributeValueLength {
				v = v[:MaxAttributeValueLength]
			}
			// Add user attributes before system attributes
			attrs = append([]attribute.KeyValue{attribute.String(k, v)}, attrs...)
			count++
		}
	}

	// Capture input data if enabled
	if c.config.CaptureInputData && pred.InputData != nil {
		inputStr, err := SerializeForTelemetry(pred.InputData, MaxSerializedLength)
		if err != nil {
			var r log.Record
			r.SetSeverity(log.SeverityError)
			r.SetBody(log.StringValue("Failed to serialize input data for telemetry: " + err.Error()))
			c.logger.Emit(ctx, r)
		} else if inputStr != "" {
			span.SetAttributes(attribute.String("input_data", inputStr))
		}
	}

	// Capture output data if enabled
	if c.config.CaptureOutputData && pred.OutputData != nil {
		outputStr, err := SerializeForTelemetry(pred.OutputData, MaxSerializedLength)
		if err != nil {
			var r log.Record
			r.SetSeverity(log.SeverityError)
			r.SetBody(log.StringValue("Failed to serialize output data for telemetry: " + err.Error()))
			c.logger.Emit(ctx, r)
		} else if outputStr != "" {
			span.SetAttributes(attribute.String("output_data", outputStr))
		}
	}
	attrSet := attribute.NewSet(attrs...)

	// Increment prediction counter
	c.predictionCounter.Add(ctx, 1, metric.WithAttributeSet(attrSet))

	// Record latency histogram if latency is provided (nil means not provided)
	if pred.Latency != nil {
		c.latencyHistogram.Record(ctx, *pred.Latency, metric.WithAttributeSet(attrSet))
		span.SetAttributes(attribute.Float64("latency_seconds", *pred.Latency))
		span.AddEvent("latency_recorded", trace.WithAttributes(
			attribute.Float64("value", *pred.Latency),
		))
	}

	// Emit structured log with proper type handling
	logRecord := log.Record{}
	logRecord.SetTimestamp(time.Now())
	logRecord.SetBody(log.StringValue("Model prediction recorded"))
	logRecord.SetSeverity(log.SeverityInfo)

	// Add trace context to log for correlation
	spanCtx := span.SpanContext()
	if spanCtx.IsValid() {
		logRecord.AddAttributes(
			log.String("trace_id", spanCtx.TraceID().String()),
			log.String("span_id", spanCtx.SpanID().String()),
		)
	}

	// Add attributes to log record with proper type handling
	for _, attr := range attrs {
		switch attr.Value.Type() {
		case attribute.BOOL:
			logRecord.AddAttributes(log.Bool(string(attr.Key), attr.Value.AsBool()))
		case attribute.INT64:
			logRecord.AddAttributes(log.Int64(string(attr.Key), attr.Value.AsInt64()))
		case attribute.FLOAT64:
			logRecord.AddAttributes(log.Float64(string(attr.Key), attr.Value.AsFloat64()))
		case attribute.STRING:
			logRecord.AddAttributes(log.String(string(attr.Key), attr.Value.AsString()))
		default:
			logRecord.AddAttributes(log.String(string(attr.Key), attr.Value.AsString()))
		}
	}

	if pred.Latency != nil {
		logRecord.AddAttributes(log.Float64("latency_seconds", *pred.Latency))
	}

	c.logger.Emit(ctx, logRecord)

	// Mark span as successful
	span.SetStatus(codes.Ok, "Prediction recorded")

	return nil
}

// RecordGoalStarted starts tracking an agent goal and returns a unique goal ID.
//
// This method creates a new goal span, generates a UUID for tracking, and
// increments the goals_started counter. The goal must be completed by calling
// RecordGoalCompleted() with the returned goal ID.
//
// The description and goalType parameters are sanitized to prevent high-cardinality
// issues. Descriptions are truncated to 200 characters and types to 50 characters.
//
// Example:
//
//	goalID, err := client.RecordGoalStarted(ctx, "Research treatment options", "research", map[string]interface{}{
//	    "priority": "high",
//	})
//	if err != nil {
//	    return err
//	}
//	// ... execute goal steps ...
//	client.RecordGoalCompleted(ctx, goalID, "success", nil)
func (c *Client) RecordGoalStarted(ctx context.Context, description string, goalType string, attributes map[string]interface{}) (string, error) {
	c.mu.RLock()
	defer c.mu.RUnlock()

	if c.isShutdown {
		return "", ErrClientClosed
	}

	// Generate UUID
	goalID := uuid.New().String()

	// Sanitize inputs (prevent high cardinality)
	descSanitized := description
	if len(descSanitized) > 200 {
		descSanitized = descSanitized[:200]
	}
	typeSanitized := goalType
	if len(typeSanitized) > 50 {
		typeSanitized = typeSanitized[:50]
	}

	// Start span
	spanAttrs := []attribute.KeyValue{
		attribute.String("goal_id", goalID),
		attribute.String("goal_type", typeSanitized),
		attribute.String("goal_description", descSanitized),
	}
	// Add custom attributes
	if attributes != nil {
		for k, v := range attributes {
			spanAttrs = append(spanAttrs, convertToAttribute(k, v))
		}
	}

	ctx, span := c.tracer.Start(ctx, "agent.goal",
		trace.WithSpanKind(trace.SpanKindInternal),
		trace.WithAttributes(spanAttrs...),
	)

	// Store goal state
	c.goalsMu.Lock()
	c.activeGoals[goalID] = &goalState{
		span:      span,
		startTime: time.Now(),
	}
	c.goalsMu.Unlock()

	// Increment counter
	c.goalsStartedCounter.Add(ctx, 1, metric.WithAttributes(
		attribute.String("goal_type", typeSanitized),
	))

	return goalID, nil
}

// RecordGoalCompleted completes tracking of an agent goal.
//
// This method ends the goal span, records duration metrics, and increments
// the appropriate completion counter (completed or failed) based on status.
//
// Valid status values are "success", "failure", and "partial". Any other
// value will result in an error.
//
// Example:
//
//	err := client.RecordGoalCompleted(ctx, goalID, "success", map[string]interface{}{
//	    "tasks_completed": 5,
//	})
func (c *Client) RecordGoalCompleted(ctx context.Context, goalID string, status string, attributes map[string]interface{}) error {
	c.mu.RLock()
	defer c.mu.RUnlock()

	if c.isShutdown {
		return ErrClientClosed
	}

	// Validate status
	if status != "success" && status != "failure" && status != "partial" {
		return fmt.Errorf("invalid goal status: %s (must be success, failure, or partial)", status)
	}

	// Retrieve and remove goal state
	c.goalsMu.Lock()
	state, ok := c.activeGoals[goalID]
	if !ok {
		c.goalsMu.Unlock()
		return fmt.Errorf("unknown goal_id: %s", goalID)
	}
	delete(c.activeGoals, goalID)
	c.goalsMu.Unlock()

	duration := time.Since(state.startTime).Seconds()

	// Set span attributes
	state.span.SetAttributes(
		attribute.String("goal_status", status),
		attribute.Float64("goal_completion_time", duration),
	)
	if attributes != nil {
		for k, v := range attributes {
			state.span.SetAttributes(convertToAttribute(k, v))
		}
	}

	// Set span status
	if status == "failure" {
		state.span.SetStatus(codes.Error, "Goal failed")
	} else {
		state.span.SetStatus(codes.Ok, "")
	}
	state.span.End()

	// Record metrics
	statusAttr := metric.WithAttributes(attribute.String("status", status))
	if status == "failure" {
		c.goalsFailedCounter.Add(ctx, 1, statusAttr)
	} else {
		c.goalsCompletedCounter.Add(ctx, 1, statusAttr)
	}
	c.goalDurationHistogram.Record(ctx, duration, statusAttr)

	return nil
}

// TrackTool wraps tool execution with automatic timing and error handling.
//
// This method provides a higher-order function pattern (Go's equivalent to
// Python's context manager) that automatically records tool latency, handles
// errors, and emits appropriate metrics and spans.
//
// The provided function receives the context and should return an error if
// the tool execution fails. TrackTool will propagate this error after recording
// the failure metrics.
//
// Example:
//
//	err := client.TrackTool(ctx, "pubmed_search", goalID, map[string]interface{}{
//	    "query": "diabetes treatment",
//	}, func(ctx context.Context) error {
//	    results, err := pubmedClient.Search(ctx, "diabetes treatment")
//	    return err
//	})
func (c *Client) TrackTool(ctx context.Context, toolName string, goalID string, attributes map[string]interface{}, fn func(context.Context) error) error {
	c.mu.RLock()

	if c.isShutdown {
		c.mu.RUnlock()
		return ErrClientClosed
	}

	// Sanitize tool name
	toolNameSanitized := toolName
	if len(toolNameSanitized) > 100 {
		toolNameSanitized = toolNameSanitized[:100]
	}

	startTime := time.Now()

	// Build span attributes
	spanAttrs := []attribute.KeyValue{
		attribute.String("tool_name", toolNameSanitized),
	}
	if goalID != "" {
		spanAttrs = append(spanAttrs, attribute.String("goal_id", goalID))
	}
	if attributes != nil {
		for k, v := range attributes {
			spanAttrs = append(spanAttrs, convertToAttribute(k, v))
		}
	}

	// Start span
	ctx, span := c.tracer.Start(ctx, fmt.Sprintf("agent.tool.%s", toolNameSanitized),
		trace.WithSpanKind(trace.SpanKindInternal),
		trace.WithAttributes(spanAttrs...),
	)

	// We release RLock during function execution to prevent deadlock if
	// the function calls other client methods, or if Shutdown is called.
	c.mu.RUnlock()

	defer span.End()

	// Execute function
	err := fn(ctx)
	latency := time.Since(startTime).Seconds()

	c.mu.RLock()
	defer c.mu.RUnlock()

	// Record metrics
	metricAttrs := []attribute.KeyValue{
		attribute.String("tool_name", toolNameSanitized),
	}
	if goalID != "" {
		metricAttrs = append(metricAttrs, attribute.String("goal_id", goalID))
	}

	if err != nil {
		// Tool failed
		errorType := fmt.Sprintf("%T", err)
		if len(errorType) > 64 {
			errorType = errorType[:64]
		}
		span.SetStatus(codes.Error, err.Error())
		span.SetAttributes(
			attribute.String("error_type", errorType),
			attribute.Float64("tool_latency_seconds", latency),
		)
		metricAttrs = append(metricAttrs, attribute.String("status", "error"))
		c.toolCallsCounter.Add(ctx, 1, metric.WithAttributes(metricAttrs...))
		return err
	}

	// Tool succeeded
	span.SetStatus(codes.Ok, "")
	span.SetAttributes(attribute.Float64("tool_latency_seconds", latency))
	metricAttrs = append(metricAttrs, attribute.String("status", "success"))
	c.toolCallsCounter.Add(ctx, 1, metric.WithAttributes(metricAttrs...))

	latencyAttrs := []attribute.KeyValue{attribute.String("tool_name", toolNameSanitized)}
	if goalID != "" {
		latencyAttrs = append(latencyAttrs, attribute.String("goal_id", goalID))
	}
	c.toolLatencyHistogram.Record(ctx, latency, metric.WithAttributes(latencyAttrs...))

	return nil
}

// RecordHumanIntervention records when the agent requires human assistance.
//
// This method adds a span event to the current active span and increments the
// human interventions counter. It is typically called when an agent needs
// approval, review, or clarification from a human operator.
//
// The timestamp parameter should use time.Now() when the intervention occurs.
// Inputs are sanitized: reason truncated to 200 chars, type to 50 chars.
//
// Example:
//
//	err := client.RecordHumanIntervention(ctx, "expert_review_needed", 120.0, "review", time.Now())
func (c *Client) RecordHumanIntervention(ctx context.Context, reason string, waitTime float64, interventionType string, timestamp time.Time) error {
	c.mu.RLock()
	defer c.mu.RUnlock()

	if c.isShutdown {
		return ErrClientClosed
	}

	// Sanitize inputs
	reasonSanitized := reason
	if len(reasonSanitized) > 200 {
		reasonSanitized = reasonSanitized[:200]
	}
	typeSanitized := interventionType
	if len(typeSanitized) > 50 {
		typeSanitized = typeSanitized[:50]
	}

	// Get current span
	span := trace.SpanFromContext(ctx)
	if span.IsRecording() {
		// Add span event
		span.AddEvent("genai.agent.human_intervention",
			trace.WithAttributes(
				attribute.Bool("intervention.required", true),
				attribute.String("intervention.reason", reasonSanitized),
			),
			trace.WithTimestamp(timestamp),
		)
	}

	// Record metric
	c.humanInterventionsCounter.Add(ctx, 1, metric.WithAttributes(
		attribute.String("reason", reasonSanitized),
		attribute.String("intervention_type", typeSanitized),
	))

	return nil
}

// RecordPolicyViolation records a security policy violation event.
//
// This method adds a span event to the current active span and increments the
// policy violations counter. It is used for observability and compliance tracking
// when the agent attempts or detects unauthorized actions.
//
// The policyType parameter should be a generic category (e.g., "data_access",
// "api_quota", "unauthorized_tool_use") and is truncated to 100 characters.
//
// Example:
//
//	if !user.HasPermission("admin") {
//	    client.RecordPolicyViolation(ctx, "unauthorized_admin_access")
//	    return errors.New("permission denied")
//	}
func (c *Client) RecordPolicyViolation(ctx context.Context, policyType string) error {
	c.mu.RLock()
	defer c.mu.RUnlock()

	if c.isShutdown {
		return ErrClientClosed
	}

	// Sanitize policy type
	policyTypeSanitized := policyType
	if len(policyTypeSanitized) > 100 {
		policyTypeSanitized = policyTypeSanitized[:100]
	}

	// Get current span and add event
	span := trace.SpanFromContext(ctx)
	if span.IsRecording() {
		span.AddEvent("genai.agent.policy_violation",
			trace.WithAttributes(
				attribute.Bool("unauthorized_action_attempted", true),
				attribute.String("policy_violated_type", policyTypeSanitized),
			),
		)
	}

	// Record metric
	c.policyViolationsCounter.Add(ctx, 1, metric.WithAttributes(
		attribute.String("policy_type", policyTypeSanitized),
	))

	return nil
}

// RecordError records a prediction error with dual metrics and detailed telemetry.
//
// This method creates a dedicated error span, records to both predictions_total
// (with status="error") and errors_total counters for comprehensive tracking,
// and emits a structured error log.
//
// The error type is extracted from the error's type name and truncated to 64
// characters to prevent unbounded cardinality. Error messages are truncated
// to 200 characters.
//
// If latency is nil, only the error counts are recorded. If predictionID is
// empty, a new UUID is generated.
//
// Example:
//
//	latency := 0.5
//	err := client.RecordError(ctx, fmt.Errorf("validation failed"), &latency, "pred-123", nil)
func (c *Client) RecordError(ctx context.Context, err error, latency *float64, predictionID string, attributes map[string]interface{}) error {
	c.mu.RLock()
	defer c.mu.RUnlock()

	if c.isShutdown {
		return ErrClientClosed
	}

	// Generate prediction ID if not provided
	if predictionID == "" {
		predictionID = uuid.New().String()
	}

	// Sanitize error type (prevent unbounded cardinality)
	errorType := fmt.Sprintf("%T", err)
	if len(errorType) > 64 {
		errorType = errorType[:64]
	}

	errorMessage := err.Error()
	if len(errorMessage) > 200 {
		errorMessage = errorMessage[:200]
	}

	// Start span for error
	ctx, span := c.tracer.Start(ctx, "record_error",
		trace.WithSpanKind(trace.SpanKindInternal),
	)
	defer span.End()

	span.SetStatus(codes.Error, errorMessage)
	span.SetAttributes(
		attribute.String("prediction.id", predictionID),
		attribute.String("error_type", errorType),
		attribute.String("error_message", errorMessage),
	)
	if latency != nil {
		span.SetAttributes(attribute.Float64("latency_seconds", *latency))
	}

	// Build metric attributes
	attrs := []attribute.KeyValue{
		attribute.String("model.id", c.config.ModelID),
		attribute.String("model.version", c.config.ModelVersion),
		attribute.String("status", "error"),
		attribute.String("error_type", errorType),
	}
	attrSet := attribute.NewSet(attrs...)

	// Dual recording: predictions_total and errors_total
	c.predictionCounter.Add(ctx, 1, metric.WithAttributeSet(attrSet))
	c.errorsCounter.Add(ctx, 1, metric.WithAttributeSet(attrSet))

	// Record latency if provided
	if latency != nil {
		c.latencyHistogram.Record(ctx, *latency, metric.WithAttributeSet(attrSet))
	}

	// Emit log
	logRecord := log.Record{}
	logRecord.SetTimestamp(time.Now())
	logRecord.SetBody(log.StringValue(fmt.Sprintf("Prediction error: %s", errorType)))
	logRecord.SetSeverity(log.SeverityError)
	logRecord.AddAttributes(
		log.String("prediction.id", predictionID),
		log.String("error_type", errorType),
		log.String("error_message", errorMessage),
	)
	if latency != nil {
		logRecord.AddAttributes(log.Float64("latency_seconds", *latency))
	}
	c.logger.Emit(ctx, logRecord)

	return nil
}

// RecordEvaluation records model evaluation metrics (MAE, RMSE, etc.).
//
// This method accepts a map of metric names to values and records them to
// the appropriate histogram instruments. Currently supports "mae" and "rmse"
// metrics. Additional metrics in the map are ignored.
//
// The dataset parameter identifies which dataset was evaluated (e.g., "test",
// "validation", "production"). Additional attributes can be provided for
// filtering and grouping.
//
// Example:
//
//	metrics := map[string]float64{
//	    "mae":  0.05,
//	    "rmse": 0.08,
//	}
//	err := client.RecordEvaluation(ctx, metrics, "test", map[string]interface{}{
//	    "model_variant": "v2",
//	})
func (c *Client) RecordEvaluation(ctx context.Context, metrics map[string]float64, dataset string, attributes map[string]interface{}) error {
	c.mu.RLock()
	defer c.mu.RUnlock()

	if c.isShutdown {
		return ErrClientClosed
	}

	// Build attributes
	attrs := []attribute.KeyValue{
		attribute.String("dataset", dataset),
	}
	if attributes != nil {
		for k, v := range attributes {
			attrs = append(attrs, convertToAttribute(k, v))
		}
	}
	attrSet := attribute.NewSet(attrs...)

	// Record each metric
	if mae, ok := metrics["mae"]; ok {
		c.maeHistogram.Record(ctx, mae, metric.WithAttributeSet(attrSet))
	}
	if rmse, ok := metrics["rmse"]; ok {
		c.rmseHistogram.Record(ctx, rmse, metric.WithAttributeSet(attrSet))
	}

	return nil
}

// Flush forces all OpenTelemetry providers to flush their buffers immediately.
//
// This method is useful for batch processing scenarios where you want to ensure
// telemetry is exported without shutting down the client. It blocks until all
// pending telemetry data has been exported or the context deadline is reached.
//
// If the provided context does not have a deadline, a 30-second timeout is applied.
//
// Example:
//
//	// Flush after processing a batch
//	if err := client.Flush(ctx); err != nil {
//	    log.Printf("flush error: %v", err)
//	}
// isConnectionError returns true if the error is a network connectivity error.
// Connection errors during export are expected when no OTel collector is running
// and should not be treated as SDK failures (graceful degradation).
func isConnectionError(err error) bool {
	var netErr *net.OpError
	return errors.As(err, &netErr)
}

func (c *Client) Flush(ctx context.Context) error {
	c.mu.RLock()
	defer c.mu.RUnlock()

	if c.isShutdown {
		return ErrClientClosed
	}

	// Create timeout context if not bounded
	flushCtx := ctx
	if _, hasDeadline := ctx.Deadline(); !hasDeadline {
		var cancel context.CancelFunc
		flushCtx, cancel = context.WithTimeout(ctx, 30*time.Second)
		defer cancel()
	}

	var errs []error

	// Force flush all providers; connection errors are expected when no collector
	// is running and are suppressed per graceful degradation design.
	if err := c.meterProvider.ForceFlush(flushCtx); err != nil && !isConnectionError(err) {
		errs = append(errs, fmt.Errorf("meter provider flush: %w", err))
	}
	if err := c.tracerProvider.ForceFlush(flushCtx); err != nil && !isConnectionError(err) {
		errs = append(errs, fmt.Errorf("tracer provider flush: %w", err))
	}
	if err := c.loggerProvider.ForceFlush(flushCtx); err != nil && !isConnectionError(err) {
		errs = append(errs, fmt.Errorf("logger provider flush: %w", err))
	}

	if len(errs) > 0 {
		return errors.Join(errs...)
	}
	return nil
}

// Shutdown gracefully shuts down all OpenTelemetry providers.
//
// This method flushes any pending telemetry data and releases resources.
// It is safe to call multiple times (subsequent calls are no-ops).
//
// Shutdown uses a 30-second timeout for graceful shutdown. If shutdown
// takes longer than 30 seconds, it returns an error.
//
// This method should be called with defer immediately after creating the client:
//
//	client, err := mca.NewClient(ctx, cfg)
//	if err != nil {
//	    return err
//	}
//	defer client.Shutdown()
func (c *Client) Shutdown() error {
	c.shutdownOnce.Do(func() {
		c.mu.Lock()
		defer c.mu.Unlock()

		// Mark as shutdown to prevent new operations
		c.isShutdown = true

		// Create context with timeout for shutdown
		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer cancel()

		var errs []error

		// Shutdown meter provider; connection errors are suppressed per graceful
		// degradation design (collector may not be running in all environments).
		if err := c.meterProvider.Shutdown(ctx); err != nil && !isConnectionError(err) {
			errs = append(errs, fmt.Errorf("meter provider shutdown: %w", err))
		}

		// Shutdown tracer provider
		if err := c.tracerProvider.Shutdown(ctx); err != nil && !isConnectionError(err) {
			errs = append(errs, fmt.Errorf("tracer provider shutdown: %w", err))
		}

		// Shutdown logger provider
		if err := c.loggerProvider.Shutdown(ctx); err != nil && !isConnectionError(err) {
			errs = append(errs, fmt.Errorf("logger provider shutdown: %w", err))
		}

		// Combine errors using errors.Join (Go 1.20+)
		if len(errs) > 0 {
			c.shutdownErr = errors.Join(errs...)
		}
	})

	return c.shutdownErr
}

// Config returns a copy of the client configuration.
func (c *Client) Config() config.Config {
	return *c.config
}

// convertToAttribute converts interface{} values to OpenTelemetry attribute.KeyValue.
// This helper function supports common Go types and falls back to string representation
// for unsupported types.
func convertToAttribute(key string, value interface{}) attribute.KeyValue {
	switch v := value.(type) {
	case string:
		return attribute.String(key, v)
	case int:
		return attribute.Int(key, v)
	case int64:
		return attribute.Int64(key, v)
	case float64:
		return attribute.Float64(key, v)
	case bool:
		return attribute.Bool(key, v)
	default:
		return attribute.String(key, fmt.Sprintf("%v", v))
	}
}

// RecordRecovery records a retry/recovery event after an error.
//
// This method tracks resilience patterns when your application retries failed operations.
// It records a counter metric with error type and attempt dimensions, and creates a trace span.
//
// Example:
//
//	// After successful retry
//	err := client.RecordRecovery(ctx, "network_error", 3, 5*time.Second)
func (c *Client) RecordRecovery(ctx context.Context, errorType string, attempts int, totalDuration time.Duration) error {
	c.mu.RLock()
	defer c.mu.RUnlock()

	if c.isShutdown {
		return ErrClientClosed
	}

	// Create trace span for recovery
	ctx, span := c.tracer.Start(ctx, "model.recovery",
		trace.WithSpanKind(trace.SpanKindInternal),
	)
	defer span.End()

	// Add recovery metadata to span
	span.SetAttributes(
		attribute.String("error_type", errorType),
		attribute.Int("attempts", attempts),
		attribute.Float64("total_duration_seconds", totalDuration.Seconds()),
	)

	// Add span event
	span.AddEvent("model.recovery", trace.WithAttributes(
		attribute.String("error_type", errorType),
		attribute.Int("attempts", attempts),
	))

	// Build attributes for metric
	attrs := []attribute.KeyValue{
		attribute.String("error_type", errorType),
		attribute.Int("attempts", attempts),
	}

	// Record recovery counter
	c.recoveriesCounter.Add(ctx, 1, metric.WithAttributes(attrs...))

	span.SetStatus(codes.Ok, "Recovery recorded")

	return nil
}

// GetInstance returns the singleton client instance.
//
// This allows accessing the client from different packages without passing
// the client through function parameters. The client must be initialized
// with NewClient before calling this method.
//
// Example:
//
//	// In main package
//	client, err := mca.NewClient(ctx, cfg)
//	if err != nil {
//	    return err
//	}
//	defer client.Shutdown()
//
//	// In another package
//	client, err := mca.GetInstance()
//	if err != nil {
//	    return err
//	}
//	client.RecordPrediction(ctx, pred)
func GetInstance() (*Client, error) {
	instanceMu.RLock()
	defer instanceMu.RUnlock()

	if instance == nil {
		return nil, ErrInstanceNotInitialized
	}
	return instance, nil
}

// resetInstance clears the singleton instance.
// This function is intended for testing purposes only.
func resetInstance() {
	instanceMu.Lock()
	defer instanceMu.Unlock()
	instance = nil
}

// Thresholds returns the current threshold values from registry configuration.
//
// Returns a deep copy of the thresholds map to prevent external modification.
// The returned map is fully independent, including nested maps and slices.
// If registry integration is not enabled, returns an empty map.
//
// Example:
//
//	thresholds := client.Thresholds()
//	if maxLatency, ok := thresholds["latency_ms"].(float64); ok {
//	    if latency > maxLatency {
//	        log.Warn("Latency threshold exceeded")
//	    }
//	}
func (c *Client) Thresholds() map[string]interface{} {
	c.thresholdsMu.RLock()
	defer c.thresholdsMu.RUnlock()

	// Return a deep copy via JSON to prevent nested structure mutation
	jsonData, err := json.Marshal(c.thresholds)
	if err != nil {
		// Fallback to shallow copy if marshal fails
		result := make(map[string]interface{}, len(c.thresholds))
		for k, v := range c.thresholds {
			result[k] = v
		}
		return result
	}

	var result map[string]interface{}
	if err := json.Unmarshal(jsonData, &result); err != nil {
		// Fallback to shallow copy if unmarshal fails
		fallback := make(map[string]interface{}, len(c.thresholds))
		for k, v := range c.thresholds {
			fallback[k] = v
		}
		return fallback
	}

	return result
}
