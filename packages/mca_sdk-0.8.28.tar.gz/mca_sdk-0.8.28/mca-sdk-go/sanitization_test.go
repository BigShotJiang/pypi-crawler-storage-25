package mca

import (
	"strings"
	"testing"
)

// TestSanitizeCredentials_AWSKey tests AWS access key masking.
func TestSanitizeCredentials_AWSKey(t *testing.T) {
	tests := []struct {
		name  string
		input string
		want  string
	}{
		{
			name:  "AWS key in error message",
			input: "Authentication failed with key AKIAIOSFODNN7EXAMPLE",
			want:  "Authentication failed with key [AWS-KEY-REDACTED]",
		},
		{
			name:  "Multiple AWS keys",
			input: "Keys: AKIAIOSFODNN7EXAMPLE and AKIAI44QH8DHBEXAMPLE",
			want:  "Keys: [AWS-KEY-REDACTED] and [AWS-KEY-REDACTED]",
		},
		{
			name:  "AWS key in JSON",
			input: `{"access_key": "AKIAIOSFODNN7EXAMPLE", "region": "us-east-1"}`,
			want:  `{"access_key": "[AWS-KEY-REDACTED]", "region": "us-east-1"}`,
		},
		{
			name:  "No AWS key",
			input: "Normal log message without credentials",
			want:  "Normal log message without credentials",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := SanitizeCredentials(tt.input)
			if got != tt.want {
				t.Errorf("SanitizeCredentials() = %q, want %q", got, tt.want)
			}
		})
	}
}

// TestSanitizeCredentials_GCPKey tests GCP service account key masking.
func TestSanitizeCredentials_GCPKey(t *testing.T) {
	tests := []struct {
		name  string
		input string
		want  string
	}{
		{
			name:  "GCP private key in JSON",
			input: `{"type": "service_account", "private_key": "-----BEGIN PRIVATE KEY-----\nMIIE....\n-----END PRIVATE KEY-----\n"}`,
			want:  `{"type": "service_account", "private_key":"[GCP-KEY-REDACTED]"}`,
		},
		{
			name:  "GCP key with spaces",
			input: `"private_key":  "key_content_here"`,
			want:  `"private_key":"[GCP-KEY-REDACTED]"`,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := SanitizeCredentials(tt.input)
			if got != tt.want {
				t.Errorf("SanitizeCredentials() = %q, want %q", got, tt.want)
			}
		})
	}
}

// TestSanitizeCredentials_BearerToken tests Bearer token masking.
func TestSanitizeCredentials_BearerToken(t *testing.T) {
	tests := []struct {
		name  string
		input string
		want  string
	}{
		{
			name:  "Bearer token in Authorization header",
			input: "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9",
			want:  "Authorization: Bearer [TOKEN-REDACTED]",
		},
		{
			name:  "Multiple Bearer tokens",
			input: "Bearer abc123xyz Bearer def456uvw",
			want:  "Bearer [TOKEN-REDACTED] Bearer [TOKEN-REDACTED]",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := SanitizeCredentials(tt.input)
			if got != tt.want {
				t.Errorf("SanitizeCredentials() = %q, want %q", got, tt.want)
			}
		})
	}
}

// TestSanitizeCredentials_APIKey tests API key masking.
func TestSanitizeCredentials_APIKey(t *testing.T) {
	tests := []struct {
		name  string
		input string
		want  string
	}{
		{
			name:  "API key with equals",
			input: "api_key=NOT_A_REAL_KEY_test_fixture",
			want:  "api_key=[KEY-REDACTED]",
		},
		{
			name:  "API key with dash",
			input: "api-key=secret_key_12345",
			want:  "api_key=[KEY-REDACTED]",
		},
		{
			name:  "API key with colon",
			input: `"apikey": "my_secret_api_key_value"`,
			want:  "api_key=[KEY-REDACTED]",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := SanitizeCredentials(tt.input)
			if !strings.Contains(got, "[KEY-REDACTED]") {
				t.Errorf("SanitizeCredentials() = %q, want to contain [KEY-REDACTED]", got)
			}
		})
	}
}

// TestSanitizeCredentials_JWT tests JWT token masking.
func TestSanitizeCredentials_JWT(t *testing.T) {
	tests := []struct {
		name  string
		input string
		want  string
	}{
		{
			name:  "Valid JWT",
			input: "Token: eyJFAKE.eyJNOT_REAL.sig_DUMMY",
			want:  "Token: [JWT-REDACTED]",
		},
		{
			name:  "JWT in log message",
			input: "Authentication failed: eyJDUMMY.eyJTEST_FIXTURE.sig_NOT_REAL",
			want:  "Authentication failed: [JWT-REDACTED]",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := SanitizeCredentials(tt.input)
			if got != tt.want {
				t.Errorf("SanitizeCredentials() = %q, want %q", got, tt.want)
			}
		})
	}
}

// TestSanitizeCredentials_MultipleTypes tests masking multiple credential types.
func TestSanitizeCredentials_MultipleTypes(t *testing.T) {
	input := `{
		"aws_key": "AKIAIOSFODNN7EXAMPLE",
		"bearer": "Bearer abc123xyz",
		"jwt": "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0In0.signature",
		"normal_field": "this should not be redacted"
	}`

	got := SanitizeCredentials(input)

	// Verify all credentials are masked
	if strings.Contains(got, "AKIAIOSFODNN7EXAMPLE") {
		t.Error("AWS key should be masked")
	}
	if !strings.Contains(got, "[AWS-KEY-REDACTED]") {
		t.Error("AWS key redaction marker not found")
	}
	if strings.Contains(got, "Bearer abc123xyz") {
		t.Error("Bearer token should be masked")
	}
	if strings.Contains(got, "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0In0.signature") {
		t.Error("JWT should be masked")
	}
	// Normal field should remain
	if !strings.Contains(got, "this should not be redacted") {
		t.Error("Normal field should not be affected")
	}
}

// TestSanitizeCredentials_EmptyString tests empty string handling.
func TestSanitizeCredentials_EmptyString(t *testing.T) {
	got := SanitizeCredentials("")
	if got != "" {
		t.Errorf("SanitizeCredentials(\"\") = %q, want \"\"", got)
	}
}

// TestSanitizeMap tests recursive map sanitization.
func TestSanitizeMap(t *testing.T) {
	input := map[string]interface{}{
		"message": "Error with key AKIAIOSFODNN7EXAMPLE",
		"user":    "alice",
		"nested": map[string]interface{}{
			"token": "Bearer abc123xyz",
		},
	}

	got := SanitizeMap(input)

	// Check top-level sanitization
	msg, ok := got["message"].(string)
	if !ok {
		t.Fatal("message should be string")
	}
	if strings.Contains(msg, "AKIAIOSFODNN7EXAMPLE") {
		t.Error("AWS key should be masked in message")
	}
	if !strings.Contains(msg, "[AWS-KEY-REDACTED]") {
		t.Error("AWS key redaction marker not found")
	}

	// Check nested sanitization
	nested, ok := got["nested"].(map[string]interface{})
	if !ok {
		t.Fatal("nested should be map")
	}
	token, ok := nested["token"].(string)
	if !ok {
		t.Fatal("token should be string")
	}
	if strings.Contains(token, "abc123xyz") {
		t.Error("Bearer token should be masked in nested map")
	}

	// Check unaffected field
	if got["user"] != "alice" {
		t.Error("user field should not be affected")
	}
}

// TestSanitizeMap_SliceValues tests sanitization of slice values.
func TestSanitizeMap_SliceValues(t *testing.T) {
	input := map[string]interface{}{
		"errors": []interface{}{
			"Error 1: AKIAIOSFODNN7EXAMPLE",
			"Error 2: Bearer token123",
		},
	}

	got := SanitizeMap(input)

	errors, ok := got["errors"].([]interface{})
	if !ok {
		t.Fatal("errors should be slice")
	}

	err1, ok := errors[0].(string)
	if !ok {
		t.Fatal("first error should be string")
	}
	if strings.Contains(err1, "AKIAIOSFODNN7EXAMPLE") {
		t.Error("AWS key should be masked in slice element")
	}
}

// TestIsSensitiveKey tests sensitive key detection.
func TestIsSensitiveKey(t *testing.T) {
	tests := []struct {
		key  string
		want bool
	}{
		{"password", true},
		{"api_key", true},
		{"secret_token", true},
		{"access_key", true},
		{"username", false},
		{"email", false},
		{"id", false},
		{"AUTH_TOKEN", true}, // Case insensitive
	}

	for _, tt := range tests {
		t.Run(tt.key, func(t *testing.T) {
			got := isSensitiveKey(tt.key)
			if got != tt.want {
				t.Errorf("isSensitiveKey(%q) = %v, want %v", tt.key, got, tt.want)
			}
		})
	}
}

// BenchmarkSanitizeCredentials benchmarks the sanitization performance.
func BenchmarkSanitizeCredentials(b *testing.B) {
	input := "Error: AWS key AKIAIOSFODNN7EXAMPLE failed with Bearer token123 and JWT eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0In0.sig"
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_ = SanitizeCredentials(input)
	}
}

// BenchmarkSanitizeCredentials_NoCredentials benchmarks performance with clean input.
func BenchmarkSanitizeCredentials_NoCredentials(b *testing.B) {
	input := "Normal log message without any credentials or sensitive data"
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_ = SanitizeCredentials(input)
	}
}
