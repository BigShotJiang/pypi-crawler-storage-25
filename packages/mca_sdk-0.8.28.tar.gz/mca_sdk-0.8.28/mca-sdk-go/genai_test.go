package mca

import (
	"context"
	"testing"
	"time"

	"gitlab.com/bhsf/ai_ml/model-monitoring/sdk/mca-prototype/mca-sdk-go/config"
)

// TestTrackLLMCompletion_Success tests LLM completion tracking.
func TestTrackLLMCompletion_Success(t *testing.T) {
	defer resetInstance()
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	request := &LLMRequest{
		Model:       "gpt-4",
		Provider:    "openai",
		MaxTokens:   1000,
		Temperature: 0.7,
	}

	cost := 0.03
	response := &LLMResponse{
		Model:            "gpt-4",
		PromptTokens:     150,
		CompletionTokens: 850,
		TotalTokens:      1000,
		Cost:             &cost,
		Latency:          2 * time.Second,
		Status:           "success",
	}

	err = client.TrackLLMCompletion(ctx, request, response)
	if err != nil {
		t.Errorf("TrackLLMCompletion() error: %v", err)
	}
}

// TestTrackLLMCompletion_ClosedClient tests error handling for closed client.
func TestTrackLLMCompletion_ClosedClient(t *testing.T) {
	defer resetInstance()
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}

	// Shutdown client
	if err := client.Shutdown(); err != nil {
		t.Fatalf("Shutdown() error: %v", err)
	}

	request := &LLMRequest{
		Model:    "gpt-4",
		Provider: "openai",
	}

	response := &LLMResponse{
		Model:   "gpt-4",
		Status:  "success",
		Latency: 1 * time.Second,
	}

	err = client.TrackLLMCompletion(ctx, request, response)
	if err != ErrClientClosed {
		t.Errorf("TrackLLMCompletion() error = %v, want %v", err, ErrClientClosed)
	}
}

// TestTrackLLMEmbedding_Success tests embedding tracking.
func TestTrackLLMEmbedding_Success(t *testing.T) {
	defer resetInstance()
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	request := &EmbeddingRequest{
		Model:    "text-embedding-ada-002",
		Provider: "openai",
		Input:    "test input",
	}

	cost := 0.0001
	response := &EmbeddingResponse{
		Model:       "text-embedding-ada-002",
		InputTokens: 50,
		Dimensions:  1536,
		Cost:        &cost,
		Latency:     200 * time.Millisecond,
		Status:      "success",
	}

	err = client.TrackLLMEmbedding(ctx, request, response)
	if err != nil {
		t.Errorf("TrackLLMEmbedding() error: %v", err)
	}
}

// TestTrackLLMEmbedding_ClosedClient tests error handling for closed client.
func TestTrackLLMEmbedding_ClosedClient(t *testing.T) {
	defer resetInstance()
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}

	// Shutdown client
	if err := client.Shutdown(); err != nil {
		t.Fatalf("Shutdown() error: %v", err)
	}

	request := &EmbeddingRequest{
		Model:    "text-embedding-ada-002",
		Provider: "openai",
	}

	response := &EmbeddingResponse{
		Model:   "text-embedding-ada-002",
		Status:  "success",
		Latency: 200 * time.Millisecond,
	}

	err = client.TrackLLMEmbedding(ctx, request, response)
	if err != ErrClientClosed {
		t.Errorf("TrackLLMEmbedding() error = %v, want %v", err, ErrClientClosed)
	}
}

// TestLLMRequest_Fields tests LLMRequest struct fields.
func TestLLMRequest_Fields(t *testing.T) {
	req := &LLMRequest{
		Model:       "gpt-4",
		Provider:    "openai",
		Prompt:      "test prompt",
		MaxTokens:   1000,
		Temperature: 0.7,
		Metadata:    map[string]interface{}{"key": "value"},
	}

	if req.Model != "gpt-4" {
		t.Errorf("Model = %v, want gpt-4", req.Model)
	}
	if req.Provider != "openai" {
		t.Errorf("Provider = %v, want openai", req.Provider)
	}
}

// TestLLMResponse_Fields tests LLMResponse struct fields.
func TestLLMResponse_Fields(t *testing.T) {
	cost := 0.05
	resp := &LLMResponse{
		Model:            "gpt-4",
		PromptTokens:     100,
		CompletionTokens: 200,
		TotalTokens:      300,
		Cost:             &cost,
		Latency:          1 * time.Second,
		Status:           "success",
		Completion:       "test completion",
		Metadata:         map[string]interface{}{"key": "value"},
	}

	if resp.TotalTokens != 300 {
		t.Errorf("TotalTokens = %v, want 300", resp.TotalTokens)
	}
	if *resp.Cost != 0.05 {
		t.Errorf("Cost = %v, want 0.05", *resp.Cost)
	}
}

// TestEmbeddingRequest_Fields tests EmbeddingRequest struct fields.
func TestEmbeddingRequest_Fields(t *testing.T) {
	req := &EmbeddingRequest{
		Model:    "text-embedding-ada-002",
		Provider: "openai",
		Input:    "test input",
		Metadata: map[string]interface{}{"key": "value"},
	}

	if req.Model != "text-embedding-ada-002" {
		t.Errorf("Model = %v, want text-embedding-ada-002", req.Model)
	}
}

// TestEmbeddingResponse_Fields tests EmbeddingResponse struct fields.
func TestEmbeddingResponse_Fields(t *testing.T) {
	cost := 0.0001
	resp := &EmbeddingResponse{
		Model:       "text-embedding-ada-002",
		InputTokens: 50,
		Dimensions:  1536,
		Cost:        &cost,
		Latency:     100 * time.Millisecond,
		Status:      "success",
		Metadata:    map[string]interface{}{"key": "value"},
	}

	if resp.Dimensions != 1536 {
		t.Errorf("Dimensions = %v, want 1536", resp.Dimensions)
	}
	if *resp.Cost != 0.0001 {
		t.Errorf("Cost = %v, want 0.0001", *resp.Cost)
	}
}
