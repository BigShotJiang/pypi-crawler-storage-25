package com.bhsf.mca.sdk.exporters;

import com.bhsf.mca.sdk.exceptions.ConfigurationException;
import com.google.auth.Credentials;
import com.google.cloud.MonitoredResource;
import com.google.cloud.logging.LogEntry;
import com.google.cloud.logging.Logging;
import com.google.cloud.logging.LoggingOptions;
import com.google.cloud.logging.Payload;
import com.google.cloud.logging.Severity;
import io.opentelemetry.api.trace.SpanContext;
import io.opentelemetry.sdk.common.CompletableResultCode;
import io.opentelemetry.sdk.logs.data.LogRecordData;
import io.opentelemetry.sdk.logs.export.LogRecordExporter;
import io.opentelemetry.sdk.resources.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Implementation of GCP Cloud Logging exporter with strongly-typed API access.
 *
 * <p>This class is only loaded when the google-cloud-logging library is available.
 * It provides compile-time type safety while supporting optional dependency patterns.
 *
 * <p><strong>Note:</strong> This class uses direct imports from the GCP Logging SDK. It will only
 * be instantiated if the optional dependency is present at runtime. Public access should be
 * through {@link GCPLoggingExporterFactory} which handles availability checks.
 *
 * <p><strong>Key Features:</strong>
 * <ul>
 *   <li>Batched writes - single RPC per export() call for efficiency</li>
 *   <li>Structured JSON payload for rich log data (not plain strings)</li>
 *   <li>Log-to-trace correlation via trace/span IDs</li>
 *   <li>Preserves original telemetry timestamps</li>
 *   <li>Thread-safe with lazy client initialization</li>
 * </ul>
 */
class GCPLoggingExporterImpl implements LogRecordExporter {
    private static final Logger log = LoggerFactory.getLogger(GCPLoggingExporterImpl.class);

    private static final int MAX_LABEL_KEY_LENGTH = 63;
    private static final int MAX_LABEL_VALUE_LENGTH = 63;
    private static final int MAX_MESSAGE_LENGTH = 1000;

    private final String projectId;
    private final String logName;
    private final Credentials credentials;
    private final String resourceType;

    private volatile Logging loggingClient;
    private final ReentrantLock clientLock = new ReentrantLock();

    /**
     * Create GCP Cloud Logging exporter implementation.
     *
     * @param projectId GCP project ID
     * @param logName Cloud Logging log name
     * @param credentials Google Cloud credentials (passed as Object from factory)
     * @param resourceType GCP monitored resource type
     * @return GCPLoggingExporterImpl instance
     * @throws ConfigurationException if validation fails
     */
    static GCPLoggingExporterImpl create(String projectId, String logName, Object credentials, String resourceType) {
        // Validate credentials type
        if (!(credentials instanceof Credentials)) {
            throw new ConfigurationException(
                    "Invalid credentials type. Expected com.google.auth.Credentials from GCPAuthFactory");
        }

        return new GCPLoggingExporterImpl(projectId, logName, (Credentials) credentials, resourceType);
    }

    /**
     * Private constructor.
     *
     * @param projectId GCP project ID
     * @param logName Cloud Logging log name
     * @param credentials Google Cloud credentials
     * @param resourceType GCP monitored resource type
     */
    private GCPLoggingExporterImpl(String projectId, String logName, Credentials credentials, String resourceType) {
        this.projectId = projectId;
        this.logName = logName;
        this.credentials = credentials;
        this.resourceType = resourceType;

        log.debug("GCP Cloud Logging exporter implementation created for project: {}, log: {}", projectId, logName);
    }

    /**
     * Lazily initialize Cloud Logging client (thread-safe).
     */
    private void ensureClient() {
        if (loggingClient != null) {
            return;
        }

        clientLock.lock();
        try {
            // Double-check pattern for thread safety
            if (loggingClient != null) {
                return;
            }

            LoggingOptions options = LoggingOptions.newBuilder()
                    .setProjectId(projectId)
                    .setCredentials(credentials)
                    .build();

            loggingClient = options.getService();

            log.debug("Cloud Logging client initialized for project: {}", projectId);
        } catch (Exception e) {
            log.error("Failed to initialize Cloud Logging client: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to initialize Cloud Logging client", e);
        } finally {
            clientLock.unlock();
        }
    }

    @Override
    public CompletableResultCode export(Collection<LogRecordData> logs) {
        if (logs == null || logs.isEmpty()) {
            return CompletableResultCode.ofSuccess();
        }

        try {
            ensureClient();

            // Convert all log records to Cloud Logging entries
            List<LogEntry> entries = new ArrayList<>();
            for (LogRecordData logRecord : logs) {
                try {
                    LogEntry entry = convertLogRecord(logRecord);
                    if (entry != null) {
                        entries.add(entry);
                    }
                } catch (Exception e) {
                    log.warn("Failed to convert log record: {}", e.getMessage());
                }
            }

            // Batch write all entries in a single RPC call
            if (!entries.isEmpty()) {
                loggingClient.write(entries);
                log.debug("Exported {} log entries to GCP Cloud Logging in single batch", entries.size());
            }

            return CompletableResultCode.ofSuccess();

        } catch (Exception e) {
            // Provide specific error messages for common failure modes
            String errorMsg = e.getMessage();
            if (errorMsg != null) {
                if (errorMsg.contains("403") || errorMsg.contains("Forbidden")) {
                    log.error("Permission denied exporting to Cloud Logging. " +
                            "Ensure service account has 'logging.logWriter' role: {}", errorMsg);
                } else if (errorMsg.contains("401") || errorMsg.contains("Unauthorized")) {
                    log.error("Authentication failed for Cloud Logging. Check GCP credentials: {}", errorMsg);
                } else if (errorMsg.contains("404") || errorMsg.contains("Not Found")) {
                    log.error("Project not found. Check project ID '{}': {}", projectId, errorMsg);
                } else if (errorMsg.contains("429") || errorMsg.contains("Quota")) {
                    log.error("Cloud Logging quota exceeded. Consider reducing log volume: {}", errorMsg);
                } else if (errorMsg.toLowerCase().contains("timeout")) {
                    log.error("Cloud Logging API timeout. Check network connectivity: {}", errorMsg);
                } else {
                    log.error("Failed to export logs to Cloud Logging: {}", errorMsg);
                }
            } else {
                log.error("Failed to export logs to Cloud Logging", e);
            }

            return CompletableResultCode.ofFailure();
        }
    }

    /**
     * Convert a single log record to Cloud Logging entry.
     *
     * <p>Uses structured JSON payload instead of plain string for rich log data.
     * Includes log-to-trace correlation and preserves original timestamps.
     */
    private LogEntry convertLogRecord(LogRecordData logRecord) {
        // Extract severity
        Severity severity = convertSeverity(logRecord.getSeverity());

        // Build structured JSON payload
        Map<String, Object> jsonFields = new HashMap<>();

        // Add message body
        String message = extractMessage(logRecord);
        if (message != null && !message.isEmpty()) {
            if (message.length() > MAX_MESSAGE_LENGTH) {
                message = message.substring(0, MAX_MESSAGE_LENGTH) + "...[truncated]";
            }
            jsonFields.put("message", message);
        }

        // Add log attributes as JSON fields
        logRecord.getAttributes().forEach((key, value) -> {
            jsonFields.put(key.getKey(), value);
        });

        // Add resource attributes with "resource." prefix
        Resource resource = logRecord.getResource();
        if (resource != null) {
            resource.getAttributes().forEach((key, value) -> {
                jsonFields.put("resource." + key.getKey(), value);
            });
        }

        // Create labels for Cloud Logging (separate from JSON fields)
        Map<String, String> labels = new HashMap<>();

        // Add severity text as label
        if (logRecord.getSeverityText() != null) {
            labels.put("severity_text", sanitizeLabelValue(logRecord.getSeverityText()));
        }

        // Create monitored resource
        MonitoredResource monitoredResource = MonitoredResource.newBuilder(resourceType).build();

        // Build log entry
        LogEntry.Builder entryBuilder = LogEntry.newBuilder(Payload.JsonPayload.of(jsonFields))
                .setSeverity(severity)
                .setLogName(logName)
                .setResource(monitoredResource)
                .setLabels(labels);

        // Set timestamp from telemetry data (preserves original timestamp)
        long timestampNanos = logRecord.getTimestampEpochNanos();
        if (timestampNanos > 0) {
            long timestampMillis = TimeUnit.NANOSECONDS.toMillis(timestampNanos);
            entryBuilder.setTimestamp(timestampMillis);
        }

        // Add log-to-trace correlation
        SpanContext spanContext = logRecord.getSpanContext();
        if (spanContext != null && spanContext.isValid()) {
            // Set trace ID for correlation
            String traceId = spanContext.getTraceId();
            if (traceId != null && !traceId.isEmpty()) {
                // Format: projects/{project}/traces/{trace_id}
                String fullTraceName = "projects/" + projectId + "/traces/" + traceId;
                entryBuilder.setTrace(fullTraceName);
            }

            // Set span ID for correlation
            String spanId = spanContext.getSpanId();
            if (spanId != null && !spanId.isEmpty()) {
                entryBuilder.setSpanId(spanId);
            }

            // Set trace sampled flag
            entryBuilder.setTraceSampled(spanContext.isSampled());
        }

        return entryBuilder.build();
    }

    /**
     * Convert OTel log severity to Cloud Logging severity.
     */
    private Severity convertSeverity(io.opentelemetry.api.logs.Severity otelSeverity) {
        if (otelSeverity == null) {
            return Severity.INFO;
        }

        String severityText = otelSeverity.name();

        if (severityText.contains("DEBUG") || severityText.contains("TRACE")) {
            return Severity.DEBUG;
        } else if (severityText.contains("INFO")) {
            return Severity.INFO;
        } else if (severityText.contains("WARN")) {
            return Severity.WARNING;
        } else if (severityText.contains("ERROR")) {
            return Severity.ERROR;
        } else if (severityText.contains("FATAL") || severityText.contains("CRITICAL")) {
            return Severity.CRITICAL;
        }

        return Severity.INFO;
    }

    /**
     * Extract message from log record body.
     */
    private String extractMessage(LogRecordData logRecord) {
        if (logRecord.getBody() == null) {
            return "";
        }

        String bodyValue = logRecord.getBody().asString();
        if (bodyValue == null) {
            return "";
        }

        return bodyValue;
    }

    /**
     * Sanitize label value to Cloud Logging limits (max 63 chars).
     */
    private String sanitizeLabelValue(String value) {
        if (value == null) {
            return "";
        }

        if (value.length() > MAX_LABEL_VALUE_LENGTH) {
            return value.substring(0, MAX_LABEL_VALUE_LENGTH);
        }

        return value;
    }

    @Override
    public CompletableResultCode flush() {
        // Cloud Logging client handles flushing automatically
        return CompletableResultCode.ofSuccess();
    }

    @Override
    public CompletableResultCode shutdown() {
        log.info("Shutting down GCP Cloud Logging exporter");
        try {
            if (loggingClient != null) {
                loggingClient.close();
            }
            return CompletableResultCode.ofSuccess();
        } catch (Exception e) {
            log.error("Error shutting down GCP Cloud Logging exporter: {}", e.getMessage());
            return CompletableResultCode.ofFailure();
        }
    }
}
