package com.bhsf.mca.sdk.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.Map;

/**
 * JSON serialization utilities for telemetry data capture.
 *
 * <p>Provides safe JSON serialization with fallback handling for non-serializable
 * types and truncation for large payloads to prevent OOM issues.
 *
 * <p>This class is stateless and thread-safe. All methods are static.
 *
 * <p>Example usage:
 * <pre>{@code
 * Map<String, Object> data = Map.of("key", "value", "count", 42);
 * String json = Serialization.toJson(data);
 * // Result: {"key":"value","count":42}
 *
 * String largePayload = Serialization.toJsonSafe(data, 1000);
 * // Result: truncated to 1000 bytes with marker if needed
 * }</pre>
 *
 * @since 0.2.0
 */
public final class Serialization {

    private static final Logger logger = LoggerFactory.getLogger(Serialization.class);
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    // Maximum serialized size to prevent OOM
    private static final int DEFAULT_MAX_SIZE_BYTES = 10_000; // 10KB
    private static final int MAX_COLLECTION_LENGTH = 100_000;
    private static final String TRUNCATE_MARKER = "...[truncated]";

    private Serialization() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    /**
     * Serializes data to JSON string with default size limit (10KB).
     *
     * @param data data to serialize
     * @return JSON string or safe string representation
     */
    public static String toJson(Object data) {
        return toJsonSafe(data, DEFAULT_MAX_SIZE_BYTES);
    }

    /**
     * Serializes data to JSON with size limit and truncation.
     *
     * <p>Returns basic Java types unchanged since they are OTel-compatible.
     * Converts complex types to JSON strings with graceful fallback to
     * toString() for non-serializable objects. Truncates large payloads.
     *
     * @param data data to serialize
     * @param maxSizeBytes maximum size in bytes for serialized string
     * @return JSON string (possibly truncated) or fallback string representation
     */
    public static String toJsonSafe(Object data, int maxSizeBytes) {
        // Handle null
        if (data == null) {
            return null;
        }

        // Check collection size to prevent OOM on huge collections
        if (data instanceof Collection) {
            Collection<?> coll = (Collection<?>) data;
            if (coll.size() > MAX_COLLECTION_LENGTH) {
                return String.format("[Collection too large: %d items exceeds limit of %d]",
                        coll.size(), MAX_COLLECTION_LENGTH);
            }
        } else if (data instanceof Map) {
            Map<?, ?> map = (Map<?, ?>) data;
            if (map.size() > MAX_COLLECTION_LENGTH) {
                return String.format("[Map too large: %d entries exceeds limit of %d]",
                        map.size(), MAX_COLLECTION_LENGTH);
            }
        }

        // Return basic Java types as their string representation (OTel-compatible, no JSON quoting)
        if (data instanceof String || data instanceof Number || data instanceof Boolean) {
            return truncateToByteLimit(data.toString(), maxSizeBytes);
        }

        try {
            // Complex types use JSON serialization
            String json = OBJECT_MAPPER.writeValueAsString(data);
            return truncateToByteLimit(json, maxSizeBytes);
        } catch (JsonProcessingException e) {
            // Fallback to toString() for non-serializable objects
            logger.debug("JSON serialization failed for {}: {}. Using toString() fallback.",
                    data.getClass().getSimpleName(), e.getMessage());
            String fallback = data.toString();
            return truncateToByteLimit(fallback, maxSizeBytes);
        }
    }

    /**
     * Extracts shape information from data (for model inputs/outputs).
     *
     * <p>Returns shape string like "(100, 5)" for arrays/matrices, or null if
     * shape cannot be determined.
     *
     * @param data data to extract shape from
     * @return shape string or null
     */
    public static String extractShape(Object data) {
        if (data == null) {
            return null;
        }

        // Handle collections
        if (data instanceof Collection) {
            Collection<?> coll = (Collection<?>) data;
            return String.format("(%d,)", coll.size());
        }

        // Handle arrays (primitive and object arrays)
        if (data.getClass().isArray()) {
            int length = java.lang.reflect.Array.getLength(data);
            return String.format("(%d,)", length);
        }

        // Handle Map
        if (data instanceof Map) {
            Map<?, ?> map = (Map<?, ?>) data;
            return String.format("(%d entries)", map.size());
        }

        return null;
    }

    /**
     * Truncates string to fit within byte limit (UTF-8 encoding).
     *
     * @param value string to truncate
     * @param maxBytes maximum size in bytes
     * @return original or truncated string with marker
     */
    private static String truncateToByteLimit(String value, int maxBytes) {
        if (value == null) {
            return null;
        }

        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        if (bytes.length <= maxBytes) {
            return value;
        }

        // Calculate space for truncation marker
        byte[] markerBytes = TRUNCATE_MARKER.getBytes(StandardCharsets.UTF_8);
        int allowedDataBytes = maxBytes - markerBytes.length;

        // If maxBytes is too small for even the marker, return empty string
        if (allowedDataBytes <= 0) {
            return "";
        }

        // Find a valid UTF-8 character boundary by iterating backward
        // UTF-8 continuation bytes have the pattern 10xxxxxx (0x80-0xBF)
        int truncateAt = allowedDataBytes;
        while (truncateAt > 0 && (bytes[truncateAt] & 0xC0) == 0x80) {
            truncateAt--;
        }

        // If we didn't find a boundary, just use allowedDataBytes and accept possible replacement char
        if (truncateAt == 0) {
            truncateAt = Math.max(1, allowedDataBytes);
        }

        // Decode the truncated bytes
        String truncated = new String(bytes, 0, truncateAt, StandardCharsets.UTF_8);

        // Double-check: if decoding introduced replacement character at the end, remove it
        while (truncated.length() > 0 && truncated.charAt(truncated.length() - 1) == '\uFFFD') {
            truncated = truncated.substring(0, truncated.length() - 1);
        }

        return truncated + TRUNCATE_MARKER;
    }

}
