package com.bhsf.mca.sdk.instrumentation;

import com.bhsf.mca.sdk.integrations.TelemetryAttributeUtil;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.StatusCode;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Manages OpenTelemetry span lifecycle with try-with-resources pattern.
 *
 * <p>Java equivalent of Python SDK's trace() context manager.
 * Automatically ends the span and closes the scope when the try block exits.
 *
 * <p>Usage example:
 * <pre>{@code
 * try (var span = client.trace("model.predict")) {
 *     span.setAttribute("input_size", data.size());
 *     // ... prediction logic
 *     span.setAttribute("output", result);
 * }
 * }</pre>
 *
 * <p><b>CRITICAL THREAD-SAFETY WARNING:</b> SpanManager instances are permanently bound to the
 * thread that created them via the OpenTelemetry Scope (thread-local context). Passing a
 * SpanManager instance to another thread or calling close() from a different thread will
 * <b>irreparably corrupt</b> the OpenTelemetry context on both threads, resulting in broken
 * distributed tracing and incorrect span relationships.
 *
 * <p><b>DO NOT:</b>
 * <ul>
 *   <li>Pass SpanManager instances between threads</li>
 *   <li>Share SpanManager instances across ExecutorService tasks</li>
 *   <li>Call close() from a thread other than the one that created the instance</li>
 *   <li>Store SpanManager in static or shared fields accessible to multiple threads</li>
 * </ul>
 *
 * <p><b>SAFE PATTERNS:</b>
 * <ul>
 *   <li>Create new SpanManager instances on each thread that needs tracing</li>
 *   <li>Use try-with-resources to ensure cleanup happens on the same thread</li>
 *   <li>Propagate context between threads using OpenTelemetry Context API, not SpanManager</li>
 * </ul>
 *
 * @see com.bhsf.mca.sdk.MCAClient#trace(String, Map)
 */
public class SpanManager implements AutoCloseable {

    private static final org.slf4j.Logger log = LoggerFactory.getLogger(SpanManager.class);

    private final Span span;
    private final Scope scope;
    private final AtomicBoolean isClosed = new AtomicBoolean(false);

    /**
     * Create a new SpanManager and start a span.
     *
     * <p>The span is made current in the context, so nested spans will automatically
     * become children of this span.
     *
     * <p><b>CRITICAL:</b> If initialization fails during attribute setting, this constructor
     * ensures the span and scope are properly cleaned up to prevent permanent thread-local
     * context poisoning that would corrupt all subsequent telemetry on this thread.
     *
     * @param tracer OpenTelemetry Tracer for creating the span
     * @param spanName Name of the span (e.g., "model.predict")
     * @param attributes Initial attributes to attach to the span (may be null)
     * @throws IllegalArgumentException if tracer or spanName is null
     */
    public SpanManager(Tracer tracer, String spanName, Map<String, Object> attributes) {
        if (tracer == null) {
            throw new IllegalArgumentException("Tracer cannot be null");
        }
        if (spanName == null || spanName.trim().isEmpty()) {
            throw new IllegalArgumentException("Span name cannot be null or empty");
        }

        // Start the span
        Span tempSpan = tracer.spanBuilder(spanName).startSpan();

        // Make the span current (enables distributed tracing context propagation)
        Scope tempScope = tempSpan.makeCurrent();

        try {
            // Set initial attributes if provided
            if (attributes != null && !attributes.isEmpty()) {
                // Defensive copy to prevent ConcurrentModificationException
                Map<String, Object> safeAttrs = TelemetryAttributeUtil.defensiveCopy(attributes);
                if (safeAttrs != null) {
                    for (Map.Entry<String, Object> entry : safeAttrs.entrySet()) {
                        setAttributeInternal(tempSpan, entry.getKey(), entry.getValue());
                    }
                }
            }

            // Only assign to instance fields after successful initialization
            this.span = tempSpan;
            this.scope = tempScope;

            log.debug("Started span: {}", spanName);
        } catch (Exception e) {
            // CRITICAL: Clean up scope on failure to prevent thread context leak.
            // Do NOT end the span — ending exports it to the exporter, which is
            // incorrect for a span that never completed initialization.
            try {
                tempScope.close();
            } catch (Exception closeEx) {
                log.error("Error closing scope during cleanup", closeEx);
            }
            log.error("Failed to initialize SpanManager. Closed scope to prevent context leak.", e);
            throw e;
        }
    }

    /**
     * Get the underlying OpenTelemetry Span.
     *
     * <p>Direct access to the span allows advanced operations like recording exceptions
     * or setting span status.
     *
     * @return The OpenTelemetry Span instance
     */
    public Span getSpan() {
        return span;
    }

    /**
     * Set an attribute on the span with fluent API.
     *
     * <p>Supports common types: String, Long, Integer, Double, Float, Boolean,
     * String[], List, Collection.
     *
     * @param key Attribute key
     * @param value Attribute value
     * @return This SpanManager for method chaining
     */
    public SpanManager setAttribute(String key, Object value) {
        setAttributeInternal(span, key, value);
        return this;
    }

    /**
     * Record an exception on the span and set status to ERROR.
     *
     * <p>This method provides parity with Python SDK's trace manager and simplifies
     * error tracking. It automatically:
     * <ul>
     *   <li>Records the exception event on the span with stack trace</li>
     *   <li>Sets the span status to ERROR</li>
     *   <li>Returns the SpanManager for fluent chaining</li>
     * </ul>
     *
     * <p>Usage example:
     * <pre>{@code
     * try (var span = client.trace("model.predict")) {
     *     try {
     *         // ... prediction logic that may fail
     *     } catch (Exception e) {
     *         span.recordException(e);
     *         throw e;  // Re-throw if needed
     *     }
     * }
     * }</pre>
     *
     * @param throwable The exception to record
     * @return This SpanManager for method chaining
     */
    public SpanManager recordException(Throwable throwable) {
        if (throwable == null) {
            log.warn("recordException called with null throwable - ignoring");
            return this;
        }

        try {
            // Record the exception event with stack trace
            span.recordException(throwable);

            // Set span status to ERROR
            span.setStatus(StatusCode.ERROR, throwable.getMessage());

            log.debug("Recorded exception on span: {}", throwable.getClass().getSimpleName());
        } catch (Exception e) {
            // Defensive: don't let exception recording crash the application
            log.error("Error recording exception on span", e);
        }

        return this;
    }

    /**
     * Internal method to set attribute with type handling.
     *
     * <p>Delegates to TelemetryAttributeUtil for consistent attribute handling across SDK.
     * This eliminates code duplication and provides extended type support including Arrays
     * and Collections which were previously missing.
     *
     * @param targetSpan The span to set the attribute on
     * @param key Attribute key
     * @param value Attribute value (supports String, Long, Integer, Double, Float, Boolean,
     *              String[], List, Collection)
     */
    private void setAttributeInternal(Span targetSpan, String key, Object value) {
        // Delegate to shared utility for consistent type handling and extended type support
        // This eliminates the code duplication that existed here and grants Array/Collection support
        TelemetryAttributeUtil.addSpanAttribute(targetSpan, key, value);
    }

    /**
     * End the span and close the scope.
     *
     * <p>This method is called automatically when the try-with-resources block exits.
     * It is truly idempotent - calling it multiple times is safe and will not corrupt
     * the OpenTelemetry context stack.
     *
     * <p><b>CRITICAL:</b> Uses AtomicBoolean to guarantee only one execution of cleanup
     * logic, preventing premature popping of parent scopes from the thread-local context.
     */
    @Override
    public void close() {
        // Atomic check-and-set to ensure cleanup logic runs exactly once
        if (!isClosed.compareAndSet(false, true)) {
            // Already closed - safe no-op
            log.debug("SpanManager already closed. Skipping duplicate close().");
            return;
        }

        try {
            // Close scope first (restores previous context)
            if (scope != null) {
                scope.close();
            }
        } catch (Exception e) {
            log.error("Error closing span scope", e);
        } finally {
            try {
                // End span last (records span to telemetry backend)
                if (span != null) {
                    span.end();
                    log.debug("Ended span");
                }
            } catch (Exception e) {
                log.error("Error ending span", e);
            }
        }
    }
}
