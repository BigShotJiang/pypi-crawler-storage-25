package com.bhsf.mca.sdk.exceptions;

/**
 * Exception thrown when registry authentication fails.
 *
 * <p>This exception indicates an authentication failure when attempting to
 * access the registry service. Common causes include:
 * <ul>
 *   <li>Invalid bearer token - Token is malformed or not recognized</li>
 *   <li>Expired token - Token has exceeded its lifetime</li>
 *   <li>Missing credentials - No authentication provided when required</li>
 *   <li>Insufficient permissions - Token lacks required scopes/permissions</li>
 * </ul>
 *
 * <p>SECURITY NOTE: Error messages automatically sanitize tokens to prevent
 * credential leakage in logs. Tokens are masked as "***XXXX" (last 4 characters).
 *
 * <p>Usage example:
 * <pre>{@code
 * try {
 *     ModelConfig config = registryClient.fetchModelConfig("mdl-001");
 * } catch (RegistryAuthException e) {
 *     logger.error("Authentication failed - check token validity", e);
 *     // Token may need refresh or renewal
 * }
 * }</pre>
 */
public class RegistryAuthException extends RegistryException implements NonRetryableException {

    /**
     * Create an authentication exception with a message.
     *
     * <p>SECURITY: Ensure tokens are not included in the message.
     * Use token sanitization if constructing messages with token references.
     *
     * @param message Error message describing the authentication failure
     */
    public RegistryAuthException(String message) {
        super(message);
    }

    /**
     * Create an authentication exception with a message and cause.
     *
     * @param message Error message describing the authentication failure
     * @param cause   Underlying cause (e.g., HTTP 401 response)
     */
    public RegistryAuthException(String message, Throwable cause) {
        super(message, cause);
    }
}
