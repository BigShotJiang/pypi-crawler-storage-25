package com.bhsf.mca.sdk.exceptions;

/**
 * Marker interface for exceptions that should not be retried by RetryPolicy.
 *
 * <p>Implement this interface on exceptions representing definitive failures
 * (e.g., HTTP 404 Not Found, HTTP 401 Unauthorized) where retrying would be
 * pointless and wasteful.
 *
 * <p>RetryPolicy checks for this interface and propagates the exception
 * immediately without further retry attempts.
 */
public interface NonRetryableException {
}
