package com.bhsf.mca.sdk.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Parser for YAML configuration files.
 *
 * <p>Loads and parses YAML configuration files into a Map structure.
 * Handles missing files gracefully by returning empty map.
 *
 * <p>Supports both YAML (.yaml, .yml) and Properties (.properties) formats.
 */
public class YamlConfigParser {

    private static final Logger logger = LoggerFactory.getLogger(YamlConfigParser.class);
    private static final ObjectMapper yamlMapper = new ObjectMapper(new YAMLFactory());
    private static final ObjectMapper jsonMapper = new ObjectMapper();

    /**
     * Parse YAML file into a map.
     *
     * @param filePath Path to YAML file
     * @return Map of configuration values, or empty map if file not found
     */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> parseYaml(String filePath) {
        File file = new File(filePath);

        if (!file.exists()) {
            logger.debug("Config file not found: {}", filePath);
            return new HashMap<>();
        }

        try (InputStream input = new FileInputStream(file)) {
            logger.info("Loading config from: {}", filePath);
            Map<String, Object> config = yamlMapper.readValue(input, Map.class);
            return config != null ? config : new HashMap<>();

        } catch (IOException e) {
            logger.warn("Failed to parse YAML config file: {}", filePath, e);
            return new HashMap<>();
        }
    }

    /**
     * Parse properties file into a map.
     *
     * @param filePath Path to properties file
     * @return Map of configuration values, or empty map if file not found
     */
    public static Map<String, Object> parseProperties(String filePath) {
        File file = new File(filePath);

        if (!file.exists()) {
            logger.debug("Config file not found: {}", filePath);
            return new HashMap<>();
        }

        try (InputStream input = new FileInputStream(file)) {
            logger.info("Loading config from: {}", filePath);
            java.util.Properties props = new java.util.Properties();
            props.load(input);

            Map<String, Object> config = new HashMap<>();
            for (String key : props.stringPropertyNames()) {
                config.put(key, props.getProperty(key));
            }
            return config;

        } catch (IOException e) {
            logger.warn("Failed to parse properties file: {}", filePath, e);
            return new HashMap<>();
        }
    }

    /**
     * Get string value from config map.
     *
     * @param config Config map
     * @param key    Key to lookup
     * @return String value, or null if not found
     */
    public static String getString(Map<String, Object> config, String key) {
        Object value = config.get(key);
        return value != null ? value.toString() : null;
    }

    /**
     * Get integer value from config map.
     *
     * @param config Config map
     * @param key    Key to lookup
     * @param defaultValue Default value if not found or invalid
     * @return Integer value, or defaultValue if not found/invalid
     */
    public static int getInt(Map<String, Object> config, String key, int defaultValue) {
        Object value = config.get(key);
        if (value == null) {
            return defaultValue;
        }

        try {
            if (value instanceof Number) {
                return ((Number) value).intValue();
            }
            return Integer.parseInt(value.toString());
        } catch (NumberFormatException e) {
            logger.warn("Invalid integer value for key {}: {}", key, value);
            return defaultValue;
        }
    }

    /**
     * Get boolean value from config map.
     *
     * @param config Config map
     * @param key    Key to lookup
     * @param defaultValue Default value if not found
     * @return Boolean value, or defaultValue if not found
     */
    public static boolean getBoolean(Map<String, Object> config, String key, boolean defaultValue) {
        Object value = config.get(key);
        if (value == null) {
            return defaultValue;
        }

        if (value instanceof Boolean) {
            return (Boolean) value;
        }

        return Boolean.parseBoolean(value.toString());
    }

    /**
     * Get integer value from config map, returning null if not found.
     *
     * @param config Config map
     * @param key    Key to lookup
     * @param defaultValue Default value if not found or invalid (may be null)
     * @return Integer value, or defaultValue if not found/invalid
     */
    public static Integer getInt(Map<String, Object> config, String key, Integer defaultValue) {
        Object value = config.get(key);
        if (value == null) {
            return defaultValue;
        }
        try {
            if (value instanceof Number) {
                return ((Number) value).intValue();
            }
            return Integer.parseInt(value.toString());
        } catch (NumberFormatException e) {
            logger.warn("Invalid integer value for key {}: {}", key, value);
            return defaultValue;
        }
    }

    /**
     * Get boolean value from config map, returning null if not found.
     *
     * @param config Config map
     * @param key    Key to lookup
     * @param defaultValue Default value if not found (may be null)
     * @return Boolean value, or defaultValue if not found
     */
    public static Boolean getBoolean(Map<String, Object> config, String key, Boolean defaultValue) {
        Object value = config.get(key);
        if (value == null) {
            return defaultValue;
        }
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        return Boolean.parseBoolean(value.toString());
    }

    /**
     * Get map value from config map.
     *
     * @param config Config map
     * @param key    Key to lookup
     * @return Map value, or empty map if not found
     */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> getMap(Map<String, Object> config, String key) {
        Object value = config.get(key);
        if (value instanceof Map) {
            return (Map<String, Object>) value;
        }
        return new HashMap<>();
    }
}
