package com.bhsf.mca.sdk.security;

import org.junit.jupiter.api.Test;

import java.io.FileNotFoundException;
import java.security.cert.CertPathValidatorException;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for certificate exception classes.
 */
class CertificateExceptionsTest {

    // CertificateLoadException Tests

    @Test
    void testCertificateLoadExceptionMessage() {
        String message = "Failed to load certificate from /path/to/cert.pem";
        CertificateLoadException exception = new CertificateLoadException(message);

        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    void testCertificateLoadExceptionWithCause() {
        String message = "Certificate file not found";
        FileNotFoundException cause = new FileNotFoundException("/path/to/cert.pem");
        CertificateLoadException exception = new CertificateLoadException(message, cause);

        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }

    @Test
    void testCertificateLoadExceptionExtendsCertificateException() {
        Exception exception = new CertificateLoadException("Test");
        assertTrue(exception instanceof CertificateException);
        assertTrue(exception instanceof Exception);
        // CertificateException is checked, not RuntimeException
        assertFalse(exception instanceof RuntimeException);
    }

    // CertificateValidationException Tests

    @Test
    void testCertificateValidationExceptionMessage() {
        String message = "Certificate chain validation failed";
        CertificateValidationException exception = new CertificateValidationException(message);

        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    void testCertificateValidationExceptionWithCause() {
        String message = "Hostname mismatch: expected example.com, got example.net";
        CertPathValidatorException cause = new CertPathValidatorException("Invalid path");
        CertificateValidationException exception = new CertificateValidationException(message, cause);

        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }

    @Test
    void testCertificateValidationExceptionExtendsCertificateException() {
        CertificateValidationException exception = new CertificateValidationException("Test");
        assertTrue(exception instanceof CertificateException);
    }

    // CertificateExpiredException Tests

    @Test
    void testCertificateExpiredExceptionMessage() {
        String message = "Certificate expired on 2026-01-15T10:30:00Z";
        CertificateExpiredException exception = new CertificateExpiredException(message);

        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    void testCertificateExpiredExceptionWithCause() {
        String message = "Certificate expired";
        java.security.cert.CertificateExpiredException cause =
            new java.security.cert.CertificateExpiredException("Expired");
        CertificateExpiredException exception = new CertificateExpiredException(message, cause);

        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }

    @Test
    void testCertificateExpiredExceptionWithDate() {
        Date expirationDate = new Date(1768473000000L); // 2026-01-15T10:30:00Z
        CertificateExpiredException exception = new CertificateExpiredException(expirationDate);

        String message = exception.getMessage();
        assertTrue(message.contains("Certificate expired on"));
        assertTrue(message.contains("2026-01-15"));
    }

    @Test
    void testCertificateExpiredExceptionNotYetValid() {
        Date notBefore = new Date(System.currentTimeMillis() + 86400000); // Tomorrow
        CertificateExpiredException exception = new CertificateExpiredException(notBefore, true);

        String message = exception.getMessage();
        assertTrue(message.contains("not yet valid"));
        assertTrue(message.contains("valid from"));
    }

    @Test
    void testCertificateExpiredExceptionExtendsCertificateException() {
        CertificateExpiredException exception = new CertificateExpiredException("Test");
        assertTrue(exception instanceof CertificateException);
    }
}
