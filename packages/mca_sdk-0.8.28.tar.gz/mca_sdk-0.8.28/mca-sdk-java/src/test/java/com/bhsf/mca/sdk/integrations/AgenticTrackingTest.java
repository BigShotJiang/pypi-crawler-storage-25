package com.bhsf.mca.sdk.integrations;

import io.opentelemetry.api.metrics.Meter;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.sdk.metrics.SdkMeterProvider;
import io.opentelemetry.sdk.testing.exporter.InMemoryMetricReader;
import io.opentelemetry.sdk.trace.SdkTracerProvider;
import io.opentelemetry.sdk.trace.export.SimpleSpanProcessor;
import io.opentelemetry.sdk.testing.exporter.InMemorySpanExporter;
import io.opentelemetry.sdk.trace.data.SpanData;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for AgenticTracking.
 */
public class AgenticTrackingTest {

    private InMemoryMetricReader metricReader;
    private InMemorySpanExporter spanExporter;
    private SdkMeterProvider meterProvider;
    private SdkTracerProvider tracerProvider;
    private Meter meter;
    private Tracer tracer;
    private AgenticTracking agentic;

    @BeforeEach
    public void setUp() {
        // Set up in-memory metric reader for testing
        metricReader = InMemoryMetricReader.create();
        meterProvider = SdkMeterProvider.builder()
                .registerMetricReader(metricReader)
                .build();
        meter = meterProvider.get("test");

        // Set up in-memory span exporter for testing
        spanExporter = InMemorySpanExporter.create();
        tracerProvider = SdkTracerProvider.builder()
                .addSpanProcessor(SimpleSpanProcessor.create(spanExporter))
                .build();
        tracer = tracerProvider.get("test");

        agentic = new AgenticTracking(meter, tracer);
    }

    @AfterEach
    public void tearDown() {
        if (meterProvider != null) {
            meterProvider.close();
        }
        if (tracerProvider != null) {
            tracerProvider.close();
        }
    }

    @Test
    public void testConstructorWithNullMeter() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new AgenticTracking(null, tracer);
        });
        assertTrue(exception.getMessage().contains("Meter cannot be null"));
    }

    @Test
    public void testConstructorWithNullTracer() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new AgenticTracking(meter, null);
        });
        assertTrue(exception.getMessage().contains("Tracer cannot be null"));
    }

    @Test
    public void testRecordGoalStarted() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("priority", "high");

        String goalId = agentic.recordGoalStarted("Research treatments", "research", attrs);

        assertNotNull(goalId, "Goal ID should not be null");
        assertFalse(goalId.isEmpty(), "Goal ID should not be empty");

        // Complete goal so span is ended and exported
        agentic.recordGoalCompleted(goalId, "success", null);

        // Verify span was created and exported
        tracerProvider.forceFlush();
        List<SpanData> spans = spanExporter.getFinishedSpanItems();
        assertFalse(spans.isEmpty(), "At least one span should be created");
    }

    @Test
    public void testRecordGoalStartedSetsCurrentGoalId() {
        String goalId = agentic.recordGoalStarted("Test goal", "general", null);

        assertEquals(goalId, agentic.getCurrentGoalId(),
                "Current goal ID should match the started goal");
    }

    @Test
    public void testRecordGoalCompleted() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("priority", "high");

        String goalId = agentic.recordGoalStarted("Research treatments", "research", attrs);

        // Complete the goal
        assertDoesNotThrow(() -> {
            agentic.recordGoalCompleted(goalId, "success", null);
        });

        // Verify span was ended
        tracerProvider.forceFlush();
        List<SpanData> spans = spanExporter.getFinishedSpanItems();
        assertEquals(1, spans.size(), "One span should be finished");
    }

    @Test
    public void testRecordGoalCompletedWithInvalidStatus() {
        String goalId = agentic.recordGoalStarted("Test goal", "general", null);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            agentic.recordGoalCompleted(goalId, "invalid", null);
        });
        assertTrue(exception.getMessage().contains("Invalid goal status"));
    }

    @Test
    public void testRecordGoalCompletedWithNullStatus() {
        String goalId = agentic.recordGoalStarted("Test goal", "general", null);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            agentic.recordGoalCompleted(goalId, null, null);
        });
        assertTrue(exception.getMessage().contains("Invalid goal status"));
    }

    @Test
    public void testRecordGoalCompletedWithUnknownGoalId() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            agentic.recordGoalCompleted("unknown-goal-id", "success", null);
        });
        assertTrue(exception.getMessage().contains("Goal ID not found"));
    }

    @Test
    public void testRecordGoalCompletedClearsCurrentGoalId() {
        String goalId = agentic.recordGoalStarted("Test goal", "general", null);
        assertEquals(goalId, agentic.getCurrentGoalId());

        agentic.recordGoalCompleted(goalId, "success", null);

        assertNull(agentic.getCurrentGoalId(),
                "Current goal ID should be cleared after completion");
    }

    @Test
    public void testTrackTool() throws Exception {
        String goalId = agentic.recordGoalStarted("Test goal", "general", null);

        Map<String, Object> attrs = new HashMap<>();
        attrs.put("query", "diabetes");

        try (var tool = agentic.trackTool("pubmed_search", goalId, attrs)) {
            assertNotNull(tool, "Tool context should not be null");
            assertNotNull(tool.getSpan(), "Tool span should not be null");

            // Simulate tool execution
            Thread.sleep(10);
        }

        // Verify spans were created
        tracerProvider.forceFlush();
        List<SpanData> spans = spanExporter.getFinishedSpanItems();
        assertTrue(spans.size() >= 1, "At least one tool span should be created");

        agentic.recordGoalCompleted(goalId, "success", null);
    }

    @Test
    public void testTrackToolWithoutGoalId() throws Exception {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("query", "diabetes");

        try (var tool = agentic.trackTool("pubmed_search", null, attrs)) {
            assertNotNull(tool, "Tool context should work without goal ID");
            Thread.sleep(10);
        }

        // Verify tool span was created
        tracerProvider.forceFlush();
        List<SpanData> spans = spanExporter.getFinishedSpanItems();
        assertEquals(1, spans.size(), "One tool span should be created");
    }

    @Test
    public void testNestedToolCalls() throws Exception {
        String goalId = agentic.recordGoalStarted("Nested test", "research", null);

        try (var outerTool = agentic.trackTool("outer_tool", goalId, null)) {
            Thread.sleep(10);

            try (var innerTool = agentic.trackTool("inner_tool", goalId, null)) {
                Thread.sleep(10);
            }
        }

        agentic.recordGoalCompleted(goalId, "success", null);

        // Verify multiple tool spans were created
        tracerProvider.forceFlush();
        List<SpanData> spans = spanExporter.getFinishedSpanItems();
        assertTrue(spans.size() >= 2, "At least two tool spans should be created for nested calls");
    }

    @Test
    public void testGetCurrentGoalIdReturnsNull() {
        assertNull(agentic.getCurrentGoalId(),
                "Current goal ID should be null when no goal is active");
    }

    @Test
    public void testGoalDescriptionTruncation() {
        String longDescription = "a".repeat(300);
        String goalId = agentic.recordGoalStarted(longDescription, "general", null);

        assertNotNull(goalId);
        agentic.recordGoalCompleted(goalId, "success", null);

        // Verify no exceptions were thrown due to long description
    }

    @Test
    public void testGoalTypeTruncation() {
        String longType = "b".repeat(100);
        String goalId = agentic.recordGoalStarted("Test", longType, null);

        assertNotNull(goalId);
        agentic.recordGoalCompleted(goalId, "success", null);

        // Verify no exceptions were thrown due to long type
    }

    @Test
    public void testToolNameTruncation() throws Exception {
        String goalId = agentic.recordGoalStarted("Test", "general", null);
        String longToolName = "c".repeat(200);

        try (var tool = agentic.trackTool(longToolName, goalId, null)) {
            Thread.sleep(10);
        }

        agentic.recordGoalCompleted(goalId, "success", null);

        // Verify no exceptions were thrown due to long tool name
    }

    @Test
    public void testThreadSafetyGoalContext() throws InterruptedException {
        int threadCount = 10;
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        CountDownLatch latch = new CountDownLatch(threadCount);
        AtomicInteger successCount = new AtomicInteger(0);

        for (int i = 0; i < threadCount; i++) {
            final int threadId = i;
            executor.submit(() -> {
                try {
                    // Each thread starts its own goal
                    String goalId = agentic.recordGoalStarted(
                            "Thread " + threadId + " goal",
                            "test",
                            Map.of("thread_id", threadId)
                    );

                    // Verify thread-local isolation
                    assertEquals(goalId, agentic.getCurrentGoalId(),
                            "Each thread should have its own goal context");

                    // Simulate some work
                    Thread.sleep(10);

                    // Complete goal
                    agentic.recordGoalCompleted(goalId, "success", null);

                    // Verify context was cleared
                    assertNull(agentic.getCurrentGoalId(),
                            "Goal context should be cleared after completion");

                    successCount.incrementAndGet();
                } catch (Exception e) {
                    log.error("Thread {} failed", threadId, e);
                } finally {
                    latch.countDown();
                }
            });
        }

        assertTrue(latch.await(10, TimeUnit.SECONDS),
                "All threads should complete within timeout");
        executor.shutdown();

        assertEquals(threadCount, successCount.get(),
                "All threads should complete successfully");
    }

    @Test
    public void testThreadSafetyToolTracking() throws InterruptedException {
        String goalId = agentic.recordGoalStarted("Concurrent tools test", "test", null);

        int threadCount = 10;
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        CountDownLatch latch = new CountDownLatch(threadCount);

        for (int i = 0; i < threadCount; i++) {
            final int threadId = i;
            executor.submit(() -> {
                try {
                    try (var tool = agentic.trackTool(
                            "tool_" + threadId,
                            goalId,
                            Map.of("thread_id", threadId)
                    )) {
                        Thread.sleep(10);
                    }
                } catch (Exception e) {
                    log.error("Thread {} failed", threadId, e);
                } finally {
                    latch.countDown();
                }
            });
        }

        assertTrue(latch.await(10, TimeUnit.SECONDS),
                "All threads should complete within timeout");
        executor.shutdown();

        agentic.recordGoalCompleted(goalId, "success", null);

        // Verify all tool spans were created
        tracerProvider.forceFlush();
        List<SpanData> spans = spanExporter.getFinishedSpanItems();
        assertTrue(spans.size() >= threadCount,
                "At least " + threadCount + " tool spans should be created");
    }

    @Test
    public void testMultipleGoalsWithDifferentStatuses() {
        String goal1 = agentic.recordGoalStarted("Goal 1", "research", null);
        String goal2 = agentic.recordGoalStarted("Goal 2", "analysis", null);

        agentic.recordGoalCompleted(goal1, "success", null);
        agentic.recordGoalCompleted(goal2, "failure", null);

        // Verify both goals were tracked
        tracerProvider.forceFlush();
        List<SpanData> spans = spanExporter.getFinishedSpanItems();
        assertEquals(2, spans.size(), "Two goal spans should be created");
    }

    @Test
    public void testToolContextSpanAccess() throws Exception {
        String goalId = agentic.recordGoalStarted("Test", "general", null);

        try (var tool = agentic.trackTool("test_tool", goalId, null)) {
            // Should be able to access span and add custom attributes
            tool.getSpan().setAttribute("custom_attr", "custom_value");
        }

        agentic.recordGoalCompleted(goalId, "success", null);
    }

    @Test
    public void testAttributeTypes() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("string_attr", "value");
        attrs.put("long_attr", 123L);
        attrs.put("int_attr", 456);
        attrs.put("double_attr", 78.9);
        attrs.put("float_attr", 10.11f);
        attrs.put("boolean_attr", true);

        String goalId = agentic.recordGoalStarted("Test", "general", attrs);

        assertDoesNotThrow(() -> {
            agentic.recordGoalCompleted(goalId, "success", attrs);
        });
    }

    @Test
    public void testUnsupportedAttributeType() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("list_attr", java.util.Arrays.asList("a", "b", "c"));

        // Should not throw, but should log warning and ignore unsupported type
        String goalId = agentic.recordGoalStarted("Test", "general", attrs);

        assertDoesNotThrow(() -> {
            agentic.recordGoalCompleted(goalId, "success", null);
        });
    }

    @Test
    public void testPartialGoalStatus() {
        String goalId = agentic.recordGoalStarted("Partial goal", "test", null);

        assertDoesNotThrow(() -> {
            agentic.recordGoalCompleted(goalId, "partial", null);
        });
    }

    @Test
    public void testEmptyGoalDescription() {
        String goalId = agentic.recordGoalStarted("", "general", null);
        assertNotNull(goalId);
        agentic.recordGoalCompleted(goalId, "success", null);
    }

    @Test
    public void testNullGoalDescription() {
        String goalId = agentic.recordGoalStarted(null, "general", null);
        assertNotNull(goalId);
        agentic.recordGoalCompleted(goalId, "success", null);
    }

    @Test
    public void testEmptyToolName() throws Exception {
        String goalId = agentic.recordGoalStarted("Test", "general", null);

        try (var tool = agentic.trackTool("", goalId, null)) {
            Thread.sleep(10);
        }

        agentic.recordGoalCompleted(goalId, "success", null);
    }

    @Test
    public void testNullToolName() throws Exception {
        String goalId = agentic.recordGoalStarted("Test", "general", null);

        try (var tool = agentic.trackTool(null, goalId, null)) {
            Thread.sleep(10);
        }

        agentic.recordGoalCompleted(goalId, "success", null);
    }

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(AgenticTrackingTest.class);
}
