"""AI client: context assembly + streaming response to WebSocket viewers.

Supports Claude (Anthropic), Gemini (Google), and Local (Ollama) as providers.
Provider is auto-detected from available API keys (Claude preferred).
"""

from __future__ import annotations

import base64
import logging
import time
from pathlib import Path
from typing import TYPE_CHECKING, List

if TYPE_CHECKING:
    from ai_interview.config import Config
    from ai_interview.state import AppState

logger = logging.getLogger(__name__)


def _assemble_messages(state: "AppState", config: "Config") -> list:
    """Build the messages list for the API call, including conversation history."""
    from ai_interview.metrics import metrics
    _t0 = time.monotonic()
    transcript = state.transcript_buffer.get_recent(minutes=config.context_minutes) if state.transcript_buffer is not None else ""
    # Clear transcript after consuming — conversation_history carries prior context,
    # so the next query should only see what's spoken AFTER this point
    if state.transcript_buffer is not None:
        state.transcript_buffer.clear()
    screenshots: List[Path] = state.screenshot_buffer.pop_all() if state.screenshot_buffer is not None else []
    if screenshots:
        from ai_interview.server.websocket import broadcast_info
        import asyncio
        asyncio.ensure_future(broadcast_info())

    # Read clipboard only when explicitly requested (Ctrl double-tap sets the flag)
    clipboard = ""
    if state.include_clipboard:
        state.include_clipboard = False
        try:
            import subprocess
            result = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=1)
            clipboard = result.stdout.strip()
        except Exception:
            pass

    content = []

    if transcript:
        content.append({
            "type": "text",
            "text": f"## Interview context (last {config.context_minutes} minutes of audio):\n\n{transcript}",
        })

    if clipboard:
        content.append({
            "type": "text",
            "text": f"## Additional context (from clipboard):\n\n{clipboard}",
        })
        logger.debug("Clipboard included (%d chars)", len(clipboard))

    if screenshots:
        from ai_interview.screenshot import encode_screenshot_b64
        n = len(screenshots)
        content.append({
            "type": "text",
            "text": (
                f"## Interviewer's screen ({n} screenshot{'s' if n > 1 else ''}):\n"
                f"The following image{'s were' if n > 1 else ' was'} captured during the session — "
                "likely showing the challenge problem, constraints, or examples on the interviewer's shared screen. "
                "Use these alongside the audio transcript above to get the full picture of what was asked."
            ),
        })
        for path in screenshots:
            try:
                b64 = encode_screenshot_b64(path)
                content.append({
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": "image/jpeg",
                        "data": b64,
                    },
                })
                logger.debug("Attached screenshot: %s", path.name)
            except Exception as exc:
                logger.warning("Could not attach screenshot %s: %s", path.name, exc)

    if not content:
        content.append({
            "type": "text",
            "text": (
                "No audio transcript or screenshots captured yet. "
                "Please describe the coding challenge you are working on."
            ),
        })

    # Prepend conversation history, then add current turn
    messages = list(state.conversation_history)
    messages.append({"role": "user", "content": content})
    metrics.record(
        "query_assemble",
        val=int((time.monotonic() - _t0) * 1000),
        has_screenshots=bool(screenshots),
        has_clipboard=bool(clipboard),
    )
    return messages


# ---------------------------------------------------------------------------
# Claude (Anthropic) streaming
# ---------------------------------------------------------------------------

async def _stream_claude(state: "AppState", config: "Config", messages: list, current_user_turn: dict, system_prompt: str = "") -> None:
    """Stream response from Claude API."""
    from ai_interview.server.websocket import broadcast
    from ai_interview.metrics import metrics
    import anthropic

    is_oauth = config.anthropic_api_key.startswith("sk-ant-oat")
    if is_oauth:
        client = anthropic.AsyncAnthropic(
            api_key="placeholder",
            default_headers={"Authorization": f"Bearer {config.anthropic_api_key}"},
        )
    else:
        client = anthropic.AsyncAnthropic(api_key=config.anthropic_api_key)

    full_text = ""
    _t0 = time.monotonic()
    _first_chunk_ms: int | None = None

    try:
        async with client.messages.stream(
            model=config.claude_model,
            max_tokens=config.max_tokens,
            system=system_prompt or config.system_prompt,
            messages=messages,
        ) as stream:
            async for text_delta in stream.text_stream:
                if _first_chunk_ms is None:
                    _first_chunk_ms = int((time.monotonic() - _t0) * 1000)
                full_text += text_delta
                await broadcast({"type": "chunk", "text": text_delta})

        state.last_response = full_text
        state.conversation_history.append(current_user_turn)
        state.conversation_history.append({"role": "assistant", "content": full_text})

        max_entries = config.max_history_turns * 2
        if len(state.conversation_history) > max_entries:
            state.conversation_history = state.conversation_history[-max_entries:]

        await broadcast({"type": "done", "full_text": full_text})
        logger.info("Claude query complete (%d chars)", len(full_text))
        _tags = dict(provider="claude", ok=True, retried=False)
        _dur = int((time.monotonic() - _t0) * 1000)
        metrics.record("claude_query.duration_ms", val=_dur, **_tags)
        metrics.record("claude_query.first_chunk_ms", val=_first_chunk_ms or 0, **_tags)
        metrics.record("claude_query.chars", val=len(full_text), **_tags)

    except anthropic.AuthenticationError:
        msg = "Invalid Anthropic API key. Check your --api-key value."
        logger.error(msg)
        await broadcast({"type": "error", "message": msg})
        metrics.record("claude_query.duration_ms", val=int((time.monotonic()-_t0)*1000),
                       provider="claude", ok=False, error="auth")

    except anthropic.BadRequestError as exc:
        if "token" in str(exc).lower():
            trimmed = len(state.conversation_history)
            half = max(2, len(state.conversation_history) // 2)
            state.conversation_history = state.conversation_history[half:]
            logger.warning("Context too long (%d entries) — trimmed to %d, retrying", trimmed, len(state.conversation_history))
            await broadcast({"type": "start"})
            await broadcast({"type": "chunk", "text": "_Context too long — trimming history and retrying…_"})

            messages_retry = list(state.conversation_history)
            messages_retry.append(current_user_turn)
            try:
                full_text = ""
                async with client.messages.stream(
                    model=config.claude_model,
                    max_tokens=config.max_tokens,
                    system=system_prompt or config.system_prompt,
                    messages=messages_retry,
                ) as stream:
                    await broadcast({"type": "start"})
                    async for text_delta in stream.text_stream:
                        full_text += text_delta
                        await broadcast({"type": "chunk", "text": text_delta})

                state.last_response = full_text
                state.conversation_history.append(current_user_turn)
                state.conversation_history.append({"role": "assistant", "content": full_text})
                await broadcast({"type": "done", "full_text": full_text})
                metrics.record("claude_query.duration_ms", val=int((time.monotonic()-_t0)*1000),
                               provider="claude", ok=True, retried=True)
            except Exception as retry_exc:
                logger.error("Retry after trim failed: %s", retry_exc)
                await broadcast({"type": "error", "message": f"Failed after trimming: {retry_exc}"})
                metrics.record("claude_query.duration_ms", val=int((time.monotonic()-_t0)*1000),
                               provider="claude", ok=False, retried=True, error="retry_failed")
        else:
            logger.error("Bad request: %s", exc)
            await broadcast({"type": "error", "message": f"Bad request: {exc}"})

    except anthropic.APIConnectionError as exc:
        logger.error("Connection error: %s", exc)
        await broadcast({"type": "error", "message": f"Connection error: {exc}"})

    except Exception as exc:
        logger.error("Unexpected error: %s", exc)
        await broadcast({"type": "error", "message": f"Unexpected error: {exc}"})


# ---------------------------------------------------------------------------
# Gemini (Google) streaming
# ---------------------------------------------------------------------------

def _messages_to_gemini_contents(messages: list, system_prompt: str) -> list:
    """Convert internal message format to Gemini contents list."""
    from google.genai import types

    contents = []

    for msg in messages:
        role = "user" if msg["role"] == "user" else "model"
        parts = []

        if isinstance(msg["content"], str):
            parts.append(types.Part.from_text(text=msg["content"]))
        elif isinstance(msg["content"], list):
            for block in msg["content"]:
                if block.get("type") == "text":
                    parts.append(types.Part.from_text(text=block["text"]))
                elif block.get("type") == "image":
                    b64_data = block["source"]["data"]
                    mime = block["source"].get("media_type", "image/jpeg")
                    image_bytes = base64.b64decode(b64_data)
                    parts.append(types.Part.from_bytes(data=image_bytes, mime_type=mime))

        if parts:
            contents.append(types.Content(role=role, parts=parts))

    return contents


async def _stream_gemini(state: "AppState", config: "Config", messages: list, current_user_turn: dict, system_prompt: str = "") -> None:
    """Stream response from Gemini API."""
    import asyncio
    from ai_interview.server.websocket import broadcast
    from ai_interview.metrics import metrics
    _t0 = time.monotonic()
    _first_chunk_ms: int | None = None
    _system_prompt = system_prompt or config.system_prompt

    try:
        from google import genai
        from google.genai import types

        client = genai.Client(api_key=config.google_api_key)
        contents = _messages_to_gemini_contents(messages, _system_prompt)

        # Run synchronous streaming in a thread to avoid blocking asyncio
        full_text = ""

        def _stream_sync():
            nonlocal full_text, _first_chunk_ms
            chunks = []
            for chunk in client.models.generate_content_stream(
                model=config.gemini_model,
                contents=contents,
                config=types.GenerateContentConfig(
                    system_instruction=_system_prompt,
                    max_output_tokens=config.max_tokens,
                ),
            ):
                if chunk.text:
                    if _first_chunk_ms is None:
                        _first_chunk_ms = int((time.monotonic() - _t0) * 1000)
                    full_text += chunk.text
                    chunks.append(chunk.text)
            return chunks

        loop = asyncio.get_event_loop()
        chunks = await loop.run_in_executor(None, _stream_sync)

        # Broadcast all chunks
        for chunk_text in chunks:
            await broadcast({"type": "chunk", "text": chunk_text})

        state.last_response = full_text
        state.conversation_history.append(current_user_turn)
        state.conversation_history.append({"role": "assistant", "content": full_text})

        max_entries = config.max_history_turns * 2
        if len(state.conversation_history) > max_entries:
            state.conversation_history = state.conversation_history[-max_entries:]

        await broadcast({"type": "done", "full_text": full_text})
        logger.info("Gemini query complete (%d chars)", len(full_text))
        _tags = dict(provider="gemini", ok=True)
        _dur = int((time.monotonic() - _t0) * 1000)
        metrics.record("gemini_query.duration_ms", val=_dur, **_tags)
        metrics.record("gemini_query.first_chunk_ms", val=_first_chunk_ms or 0, **_tags)
        metrics.record("gemini_query.chars", val=len(full_text), **_tags)

    except ImportError:
        msg = "google-genai not installed. Run: pip install google-genai"
        logger.error(msg)
        await broadcast({"type": "error", "message": msg})

    except Exception as exc:
        error_str = str(exc).lower()
        if "api key" in error_str or "authenticate" in error_str or "403" in error_str:
            msg = "Invalid Google API key. Check your key at https://aistudio.google.com/api-keys"
            logger.error(msg)
            await broadcast({"type": "error", "message": msg})
        elif "quota" in error_str or "429" in error_str or "rate" in error_str:
            msg = "Gemini rate limit reached (free tier: 10 req/min). Wait a moment and retry."
            logger.warning(msg)
            await broadcast({"type": "error", "message": msg})
        else:
            msg = f"Gemini error: {exc}"
            logger.error(msg)
            await broadcast({"type": "error", "message": msg})
        metrics.record("gemini_query.duration_ms", val=int((time.monotonic()-_t0)*1000),
                       provider="gemini", ok=False)


# ---------------------------------------------------------------------------
# Local (Ollama) streaming
# ---------------------------------------------------------------------------

def _ensure_ollama(model: str) -> bool:
    """Ensure Ollama is installed, running, and the model is available. Returns True if ready."""
    from ai_interview.ollama_utils import is_ollama_installed, start_ollama, get_installed_models, keep_alive

    if not is_ollama_installed():
        logger.error("Ollama not installed. Run: ai-interview version")
        return False

    if not start_ollama():
        logger.error("Ollama server failed to start")
        return False

    # Cancel idle timer — we're in an active session
    keep_alive()

    installed = get_installed_models(start_server=True)
    if model not in installed:
        logger.error("Model %s not downloaded. Download it from Settings.", model)
        return False

    return True


async def _stream_local(state: "AppState", config: "Config", messages: list, current_user_turn: dict, system_prompt: str = "") -> None:
    """Stream response from a local Ollama model."""
    import asyncio
    import json
    import urllib.request
    from ai_interview.server.websocket import broadcast
    from ai_interview.metrics import metrics
    _t0 = time.monotonic()
    _system_prompt = system_prompt or config.system_prompt

    model = config.local_model

    # Ensure Ollama is ready (install/start/pull in background thread)
    ready = await asyncio.get_event_loop().run_in_executor(None, _ensure_ollama, model)
    if not ready:
        await broadcast({"type": "error", "message": "Ollama setup failed. Install manually: brew install ollama"})
        return

    try:
        # Convert messages to OpenAI format (text only — Ollama doesn't support images)
        ollama_messages = [{"role": "system", "content": _system_prompt}]
        for msg in messages:
            role = msg["role"]
            content = msg.get("content", "")
            if isinstance(content, str):
                ollama_messages.append({"role": role, "content": content})
            elif isinstance(content, list):
                # Extract text blocks, skip images
                text_parts = [b["text"] for b in content if b.get("type") == "text"]
                if text_parts:
                    ollama_messages.append({"role": role, "content": "\n\n".join(text_parts)})

        # Stream from Ollama's chat API
        full_text = ""
        _first_chunk_ms = None

        def _stream_sync():
            nonlocal full_text, _first_chunk_ms
            body = json.dumps({
                "model": model,
                "messages": ollama_messages,
                "stream": True,
            }).encode()
            req = urllib.request.Request(
                "http://localhost:11434/api/chat",
                data=body,
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=120) as resp:
                for line in resp:
                    if not line.strip():
                        continue
                    try:
                        chunk = json.loads(line)
                        text = chunk.get("message", {}).get("content", "")
                        if text:
                            if _first_chunk_ms is None:
                                _first_chunk_ms = int((time.monotonic() - _t0) * 1000)
                            full_text += text
                    except json.JSONDecodeError:
                        pass

        # Run sync streaming in a thread, poll for chunks
        loop = asyncio.get_event_loop()
        prev_len = 0
        task = loop.run_in_executor(None, _stream_sync)

        while not task.done():
            await asyncio.sleep(0.05)
            if len(full_text) > prev_len:
                await broadcast({"type": "chunk", "text": full_text[prev_len:]})
                prev_len = len(full_text)

        await task  # raise any exception

        # Flush remaining
        if len(full_text) > prev_len:
            await broadcast({"type": "chunk", "text": full_text[prev_len:]})

        state.last_response = full_text
        state.conversation_history.append(current_user_turn)
        state.conversation_history.append({"role": "assistant", "content": full_text})
        if len(state.conversation_history) > config.max_history_turns * 2:
            state.conversation_history = state.conversation_history[-(config.max_history_turns * 2):]

        await broadcast({"type": "done", "full_text": full_text})

        _dur = int((time.monotonic() - _t0) * 1000)
        logger.info("Local query complete (%d chars, %dms, model=%s)", len(full_text), _dur, model)
        metrics.record("local_query.duration_ms", val=_dur, provider="local", ok=True)
        metrics.record("local_query.first_chunk_ms", val=_first_chunk_ms or 0, provider="local", ok=True)
        metrics.record("local_query.chars", val=len(full_text), provider="local", ok=True)

    except Exception as exc:
        logger.error("Local (Ollama) error: %s", exc, exc_info=True)
        await broadcast({"type": "error", "message": f"Local AI error: {exc}"})
        metrics.record("local_query.duration_ms", val=int((time.monotonic() - _t0) * 1000),
                       provider="local", ok=False)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

async def handle_query(state: "AppState", config: "Config") -> None:
    """Assemble context and stream AI response to all connected viewers.

    Auto-selects provider based on available API keys (Claude preferred).
    """
    from ai_interview.server.websocket import broadcast

    if state.status == "processing":
        logger.debug("Query already in progress, ignoring duplicate trigger")
        return

    state.status = "processing"
    await broadcast({"type": "status", "value": "processing"})
    await broadcast({"type": "start"})

    messages = _assemble_messages(state, config)
    current_user_turn = messages[-1]

    # Build ephemeral system prompt — explicitly set mode for every query
    system_prompt = config.system_prompt
    if getattr(state, "response_mode", "auto") == "code":
        system_prompt += """

=== CODE MODE IS ACTIVE ===
You MUST write code. Give approach in 1 sentence, then clean minimal code, then time/space complexity on one line.
No docstrings, no inline comments, no usage examples. Just the code."""
    else:
        system_prompt += """

=== AUTO MODE (NO CODE) ===
You MUST NOT write any code, code blocks, code snippets, or pseudocode.
Answer with bullet points ONLY. 3-5 bullets, each one sentence.
First person, as if speaking out loud. Short and dense.
The ONLY exception: if the interviewer EXPLICITLY says "write code", "implement", or "code this up"."""

    try:
        provider = config.provider
        if provider == "local":
            await _stream_local(state, config, messages, current_user_turn, system_prompt)
        elif provider == "claude":
            try:
                await _stream_claude(state, config, messages, current_user_turn, system_prompt)
            except Exception as exc:
                if config.google_api_key:
                    logger.warning("Claude failed (%s), falling back to Gemini", exc)
                    await broadcast({"type": "chunk", "text": "\n\n*[Switched to Gemini — Claude unavailable]*\n\n"})
                    await _stream_gemini(state, config, messages, current_user_turn, system_prompt)
                else:
                    raise
        elif provider == "gemini":
            try:
                await _stream_gemini(state, config, messages, current_user_turn, system_prompt)
            except Exception as exc:
                if config.anthropic_api_key:
                    logger.warning("Gemini failed (%s), falling back to Claude", exc)
                    await broadcast({"type": "chunk", "text": "\n\n*[Switched to Claude — Gemini unavailable]*\n\n"})
                    await _stream_claude(state, config, messages, current_user_turn, system_prompt)
                else:
                    raise
        else:
            await broadcast({"type": "error", "message": "No API key configured. Run: ai-interview setup"})
    finally:
        state.status = "listening" if state.audio_active else "idle"
        await broadcast({"type": "status", "value": state.status})
