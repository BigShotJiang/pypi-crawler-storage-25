"""Daemon process management: double-fork, PID files, signal handling.

IMPORTANT: Audio modules (sounddevice, ScreenCaptureKit, deepgram, faster_whisper)
must NOT be imported at module level here. They are imported inside run_daemon()
which is called only after daemonize(). This prevents CoreAudio IPC crashes
that occur when Python forks after loading audio libraries.
"""

from __future__ import annotations

import asyncio
import atexit
import json
import logging
import os
import signal
import sys
import time
from typing import Optional

from ai_interview.config import LOG_FILE, META_FILE, PID_FILE, Config

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# PID file helpers
# ---------------------------------------------------------------------------

def write_pid_file(pid: Optional[int] = None) -> None:
    pid = pid or os.getpid()
    PID_FILE.write_text(str(pid))


def remove_pid_file() -> None:
    try:
        PID_FILE.unlink(missing_ok=True)
    except Exception:
        pass


def read_pid() -> Optional[int]:
    try:
        return int(PID_FILE.read_text().strip())
    except Exception:
        return None


def is_process_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError):
        return False


def kill_existing() -> bool:
    """Kill any running daemon. Returns True if a process was killed."""
    pid = read_pid()
    if pid is None:
        return False
    if not is_process_running(pid):
        remove_pid_file()
        return False
    try:
        os.kill(pid, signal.SIGTERM)
        for _ in range(50):
            time.sleep(0.1)
            if not is_process_running(pid):
                break
        else:
            os.kill(pid, signal.SIGKILL)
    except Exception:
        pass
    remove_pid_file()
    return True


# ---------------------------------------------------------------------------
# Metadata helpers (for `ai-interview status`)
# ---------------------------------------------------------------------------

def write_meta(config: Config, transcriber_name: str = "") -> None:
    meta = {
        "started_at": time.time(),
        "port": config.port,
        "pid": os.getpid(),
        "provider": config.provider,
        "model": config.model,
        "transcriber": transcriber_name,
        "interview_language": config.interview_language,
        "challenge_type": config.challenge_type,
        "context_path": config.context_path,
    }
    META_FILE.write_text(json.dumps(meta))


def read_meta() -> Optional[dict]:
    try:
        return json.loads(META_FILE.read_text())
    except Exception:
        return None


def remove_meta() -> None:
    try:
        META_FILE.unlink(missing_ok=True)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# daemonize: double-fork to detach from terminal
# ---------------------------------------------------------------------------

def daemonize() -> None:
    """Double-fork to create a true background daemon.

    Call this BEFORE importing any audio libraries.
    After this returns we are in the grandchild (daemon) process.
    """
    try:
        pid = os.fork()
        if pid > 0:
            sys.exit(0)
    except OSError as exc:
        sys.stderr.write(f"First fork failed: {exc}\n")
        sys.exit(1)

    os.setsid()

    try:
        pid = os.fork()
        if pid > 0:
            sys.exit(0)
    except OSError as exc:
        sys.stderr.write(f"Second fork failed: {exc}\n")
        sys.exit(1)

    os.umask(0)
    os.chdir("/")

    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    sys.stdout.flush()
    sys.stderr.flush()

    with open(os.devnull, "r") as f:
        os.dup2(f.fileno(), sys.stdin.fileno())
    with open(LOG_FILE, "a") as f:
        os.dup2(f.fileno(), sys.stdout.fileno())
        os.dup2(f.fileno(), sys.stderr.fileno())


# ---------------------------------------------------------------------------
# Main daemon entrypoint
# ---------------------------------------------------------------------------

def run_daemon(config: Config) -> None:
    """Entry point for the daemon process.

    Called from the subprocess spawned by `ai-interview start --daemon`.
    All audio / Deepgram imports happen here, safely after daemonize().
    """
    _t_daemon_start = time.monotonic()
    daemonize()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[logging.StreamHandler()],
    )
    logger.info("Daemon started (pid=%d)", os.getpid())

    write_pid_file()
    atexit.register(remove_pid_file)
    atexit.register(remove_meta)

    # Hide from macOS Dock
    try:
        from AppKit import NSApplication, NSApplicationActivationPolicyProhibited
        NSApplication.sharedApplication().setActivationPolicy_(
            NSApplicationActivationPolicyProhibited
        )
    except Exception:
        pass

    # Auto-terminate after timeout
    def _alarm_handler(signum, frame):
        logger.info("Auto-terminate timeout reached")
        sys.exit(0)

    signal.signal(signal.SIGALRM, _alarm_handler)
    signal.alarm(config.timeout_hours * 3600)

    shutdown_flag = {"stop": False}

    def _term_handler(signum, frame):
        logger.info("SIGTERM received, shutting down")
        shutdown_flag["stop"] = True
        from ai_interview.metrics import metrics
        metrics.stop()

    signal.signal(signal.SIGTERM, _term_handler)

    # -----------------------------------------------------------------------
    # NOW safe to import audio and network libraries
    # -----------------------------------------------------------------------
    from ai_interview.buffer import RollingTranscriptBuffer, ScreenshotBuffer
    from ai_interview.state import state
    from ai_interview.audio.capture import CombinedAudioCapture
    from ai_interview.audio.transcriber import create_transcriber, DeepgramTranscriber
    from ai_interview.screenshot import ensure_screenshots_dir
    from ai_interview.server.app import create_app
    from ai_interview.hotkeys import start_hotkey_listener

    ensure_screenshots_dir()

    state.started_at = time.time()
    state.transcript_buffer = RollingTranscriptBuffer(config.buffer_minutes)
    state.screenshot_buffer = ScreenshotBuffer()

    # Start audio capture
    audio_capture = CombinedAudioCapture(sample_rate=16000)
    try:
        audio_capture.start()
        state.audio_active = True
        logger.info("Audio capture started")
    except Exception as exc:
        logger.error("Audio capture failed: %s — continuing without audio", exc)

    # Start transcriber (Deepgram preferred, Whisper fallback)
    transcriber = create_transcriber(
        audio_capture=audio_capture,
        transcript_buffer=state.transcript_buffer,
        deepgram_api_key=config.deepgram_api_key,
        transcription_language=config.transcription_language,
        preferred_transcriber=config.preferred_transcriber,
    )
    if transcriber is None:
        transcriber_name = "none (screenshots only)"
    elif isinstance(transcriber, DeepgramTranscriber):
        transcriber_name = "Deepgram"
    else:
        transcriber_name = "Whisper (local)"
    write_meta(config, transcriber_name=transcriber_name)
    logger.info("Transcriber: %s", transcriber_name)
    state.transcriber_name = transcriber_name
    state.ai_model = config.model

    # -----------------------------------------------------------------------
    # Start Datadog metrics + structured logging (no-op if dd_api_key absent)
    # -----------------------------------------------------------------------
    from ai_interview.metrics import metrics
    metrics.start(config)
    logging.getLogger().addHandler(metrics.make_log_handler())

    metrics.record(
        "daemon_start",
        val=int((time.monotonic() - _t_daemon_start) * 1000),
        transcriber=transcriber_name.split()[0].lower(),  # "deepgram" / "whisper" / "none"
        provider=config.provider,
    )

    start_hotkey_listener(config)

    async def _main():
        import aiohttp.web as web

        loop = asyncio.get_running_loop()
        state.asyncio_loop = loop
        state.shutdown_event = asyncio.Event()

        app = create_app(config)
        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, "0.0.0.0", config.port)
        await site.start()
        logger.info("Viewer server on 0.0.0.0:%d", config.port)

        _MAX_IDLE_S = 30 * 60  # 30 min idle → auto-shutdown
        state.last_activity_at = time.time()  # initialise so first check is fair
        _last_heartbeat_uptime = -1
        _last_cpu_broadcast = 0.0

        # Prime psutil baseline — first call always returns 0.0, real values start from second call
        try:
            import psutil as _psutil
            _psutil_proc = _psutil.Process()
            _psutil_proc.cpu_percent(interval=None)  # discard — establishes baseline
            _psutil.cpu_percent(interval=None)        # discard — establishes baseline
        except Exception:
            _psutil_proc = None

        # Periodic health check — keeps the event loop responsive
        while not shutdown_flag["stop"]:
            await asyncio.sleep(0.5)
            now    = time.time()
            uptime = int(now - state.started_at)
            idle   = int(now - state.last_activity_at)

            # Log a heartbeat every 5 minutes (guard against double-fire in 0.5s loop)
            heartbeat_slot = uptime // 300
            if heartbeat_slot != _last_heartbeat_uptime and uptime % 300 < 1:
                _last_heartbeat_uptime = heartbeat_slot
                logger.info("Daemon heartbeat — uptime %ds  idle %ds", uptime, idle)

            # Broadcast CPU usage every 10s
            if now - _last_cpu_broadcast >= 10:
                _last_cpu_broadcast = now
                try:
                    from ai_interview.server.websocket import broadcast
                    proc_cpu = _psutil_proc.cpu_percent(interval=None) if _psutil_proc else 0.0
                    host_cpu = _psutil.cpu_percent(interval=None)
                    proc_rss_mb = round(_psutil_proc.memory_info().rss / (1024 ** 2), 1) if _psutil_proc else 0.0
                    asyncio.ensure_future(broadcast({
                        "type": "cpu",
                        "process": round(proc_cpu, 1),
                        "host": round(host_cpu, 1),
                        "proc_rss_mb": proc_rss_mb,
                    }))
                except Exception:
                    pass

            # Auto-shutdown after 30 min of no hotkeys / queries / transcripts
            if idle >= _MAX_IDLE_S:
                logger.info("30-minute idle limit reached — shutting down automatically")
                shutdown_flag["stop"] = True

        await runner.cleanup()

    try:
        asyncio.run(_main())
    except Exception as exc:
        logger.error("Event loop error: %s", exc)
    finally:
        if transcriber is not None:
            transcriber.stop()
        audio_capture.stop()
        # Clean up all screenshots captured during this session
        try:
            from ai_interview.config import SCREENSHOTS_DIR
            deleted = 0
            for f in SCREENSHOTS_DIR.glob("*.jpg"):
                f.unlink(missing_ok=True)
                deleted += 1
            if deleted:
                logger.info("Cleaned up %d screenshot(s)", deleted)
        except Exception as exc:
            logger.warning("Screenshot cleanup failed: %s", exc)
        # Stop Ollama if we manage it and provider is local
        if config.ollama_managed and config.provider == "local":
            try:
                from ai_interview.ollama_utils import stop_ollama
                stop_ollama()
                logger.info("Ollama server stopped")
            except Exception:
                pass
        logger.info("Daemon exited cleanly")
