"""AI Interview Assistant — ghost background tool for live code challenges."""

__version__ = "2.0.0"
