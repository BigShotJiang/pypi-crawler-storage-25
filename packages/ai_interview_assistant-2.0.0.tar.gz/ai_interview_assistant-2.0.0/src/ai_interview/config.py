"""Configuration: dataclass, persisted config file, and dynamic system prompt."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

HOME = Path.home()
PID_FILE          = HOME / ".ai-interview.pid"
WATCHDOG_PID_FILE = HOME / ".ai-interview-watchdog.pid"
META_FILE         = HOME / ".ai-interview.meta.json"
LOG_FILE          = HOME / ".ai-interview.log"
SCREENSHOTS_DIR = HOME / ".ai-interview" / "screenshots"
CONFIG_FILE = HOME / ".config" / "ai-interview" / "v3" / "config.json"

CHALLENGE_TYPES = ["code_challenge", "system_design", "general"]

CHALLENGE_TYPE_LABELS = {
    "code_challenge": "Code Challenge",
    "system_design":  "System Design",
    "general":        "General",
}

CHALLENGE_TYPE_DESCS = {
    "code_challenge": "algorithms, data structures, coding problems",
    "system_design":  "architecture, scalability, infrastructure",
    "general":        "behavioral, conceptual, open-ended",
}
CLAUDE_MODELS = {
    "sonnet": "claude-sonnet-4-6",   # fast
    "opus": "claude-opus-4-6",       # smarter, slower
    "haiku": "claude-haiku-4-5-20251001",  # fastest, lighter
}


def read_codebase_context(path: str, max_chars: int = 40_000) -> str:
    """Read directory tree + key source files from a repo and return as a text block."""
    root = Path(path).expanduser().resolve()
    if not root.is_dir():
        return ""

    SKIP_DIRS = {
        ".git", "__pycache__", "node_modules", ".venv", "venv",
        "dist", "build", ".next", "target", ".idea", ".gradle",
    }
    CODE_EXT = {".py", ".java", ".ts", ".tsx", ".js", ".go", ".rs",
                ".kt", ".swift", ".cpp", ".c", ".cs", ".rb", ".scala"}

    # --- File tree (depth ≤ 4) ---
    tree_lines: list[str] = []

    def _tree(d: Path, prefix: str = "", depth: int = 0) -> None:
        if depth > 4:
            return
        try:
            children = sorted(d.iterdir(), key=lambda p: (p.is_file(), p.name))
        except PermissionError:
            return
        for i, child in enumerate(children):
            if child.name.startswith(".") or child.name in SKIP_DIRS:
                continue
            connector = "└── " if i == len(children) - 1 else "├── "
            tree_lines.append(prefix + connector + child.name)
            if child.is_dir() and depth < 4 and len(tree_lines) < 200:
                ext = "    " if i == len(children) - 1 else "│   "
                _tree(child, prefix + ext, depth + 1)

    _tree(root)
    sections: list[str] = [
        f"# Codebase: {root.name}\n",
        "## File tree\n```\n" + root.name + "/\n" + "\n".join(tree_lines) + "\n```\n",
    ]
    total = sum(len(s) for s in sections)

    # --- Key doc files ---
    for fname in ("README.md", "README.rst", "package.json", "pyproject.toml", "pom.xml"):
        fpath = root / fname
        if fpath.exists() and total < max_chars:
            try:
                content = fpath.read_text(errors="ignore")[:5_000]
                sec = f"## {fname}\n```\n{content}\n```\n"
                sections.append(sec)
                total += len(sec)
            except Exception:
                pass

    # --- Source files (entry points first, then by size) ---
    source_files = [
        p for p in root.rglob("*")
        if p.suffix in CODE_EXT
        and not any(s in p.parts for s in SKIP_DIRS)
    ]

    def _priority(p: Path) -> tuple:
        if p.stem.lower() in ("main", "app", "index", "server", "api", "application"):
            return (0, p.stat().st_size)
        return (1, p.stat().st_size)

    source_files.sort(key=_priority)

    for fpath in source_files[:40]:
        if total >= max_chars:
            break
        try:
            content = fpath.read_text(errors="ignore")
            rel = fpath.relative_to(root)
            remaining = max_chars - total
            excerpt = content[: min(4_000, remaining)]
            sec = f"## {rel}\n```{fpath.suffix[1:]}\n{excerpt}\n```\n"
            sections.append(sec)
            total += len(sec)
        except Exception:
            pass

    return "\n".join(sections)


_TYPE_RULES = {
    "code_challenge": """\
- NEVER write code unless you are in Code Mode (you will be told explicitly).
- Default: bullet points ONLY. 3-5 bullets max. First person. No headers.
- Each bullet = one thing to say out loud. Short sentences.
- NO code snippets, NO code blocks, NO pseudocode, NO examples with code.
- If the interviewer asks "how would you approach this?", answer in words, not code.
- Only when explicitly in Code Mode: give clean minimal code, no docstrings, no comments, complexity on one line after.""",

    "system_design": """\
- NEVER write code. System design is about architecture, not implementation.
- Start with 1-2 key clarifying assumptions (scope, scale, SLA).
- List high-level components as bullet points (service names, not paragraphs).
- Call out the single most important design decision and why (DB choice, caching, queue, etc.).
- End with one trade-off acknowledgement.
- Bullets only. No prose. No code.
- When asked "how would you design this", use simple ASCII diagrams to show component relationships (arrows, boxes).""",

    "general": """\
- NEVER write code. This is a behavioural/general interview.
- 3-5 bullet points max. Each bullet = one thing to say out loud.
- No frameworks, no section headers, no tips, no code examples.
- Speak as if answering out loud — first person, natural, conversational.""",
}


def _read_cv_text(cv_path: str) -> str:
    """Extract text from a PDF CV/resume."""
    if not cv_path:
        return ""
    try:
        from pathlib import Path
        p = Path(cv_path)
        if not p.exists() or p.suffix.lower() != ".pdf":
            return ""
        # Try PyPDF2 first (lighter), fall back to pdfplumber
        try:
            from PyPDF2 import PdfReader
            reader = PdfReader(str(p))
            text = "\n".join(page.extract_text() or "" for page in reader.pages)
        except ImportError:
            try:
                import pdfplumber
                with pdfplumber.open(str(p)) as pdf:
                    text = "\n".join(page.extract_text() or "" for page in pdf.pages)
            except ImportError:
                import subprocess
                r = subprocess.run(["textutil", "-convert", "txt", "-stdout", str(p)],
                                   capture_output=True, text=True, timeout=10)
                text = r.stdout if r.returncode == 0 else ""
        return text.strip()[:8000]  # cap at 8k chars
    except Exception:
        return ""


def _build_system_prompt(
    language: str = "",
    challenge_type: str = "",
    codebase_context: str = "",
    role_context: str = "",
    response_language: str = "en",
    cv_text: str = "",
) -> str:
    context_lines = []
    if language:
        context_lines.append(f"- Programming language: {language}")

    context_block = ""
    if context_lines:
        context_block = "\nInterview context:\n" + "\n".join(context_lines) + "\n"

    # Interview brief — injected only if provided (per-session, from GUI or CLI)
    brief_block = ""
    if role_context:
        brief_block = (
            "\n\nInterview brief (provided by the candidate):\n"
            f"{role_context}\n\n"
            "Use this context to tailor your answers — match the seniority level, "
            "focus areas, and constraints described above.\n"
        )

    rules = _TYPE_RULES.get(challenge_type, _TYPE_RULES["general"])

    codebase_block = ""
    if codebase_context:
        codebase_block = (
            "\n\n---\nThe interview is about the following codebase. "
            "Use it to answer questions about the code directly.\n\n"
            + codebase_context
        )

    cv_block = ""
    if cv_text:
        cv_block = (
            "\n\nCandidate's CV/Resume:\n"
            f"{cv_text}\n\n"
            "When answering behavioural or experience questions, reference real projects "
            "and roles from this CV. Keep answers first-person as if the candidate is speaking.\n"
        )

    lang_rule = f"- Reply in the same language as the user ({response_language}). Never switch to English unless the user writes in English.\n" if response_language and response_language != "en" else ""

    return f"""\
You are a silent assistant helping during a live technical interview. The user needs to answer NOW.
{context_block}{brief_block}{cv_block}
Rules — follow strictly:
{lang_rule}- Give ONLY what the user should say or do. Nothing else.
{rules}
- Never use headers like "Answer Framework", "Key Tips", "Suggested Response". Just the answer.
- Never explain what you're doing. Never add "want me to tailor this?" or similar.
- When screenshots are provided, they show the interviewer's screen (challenge problem, constraints, examples). Cross-reference them with the audio transcript to get the full picture — do not answer from transcript alone if screenshots are present.
- Mobile screen width. Short lines. Dense.{codebase_block}"""


# ---------------------------------------------------------------------------
# Persisted config (stored in ~/.config/ai-interview/config.json)
# ---------------------------------------------------------------------------

def load_saved_config() -> dict:
    """Load saved config. Returns {} if not found."""
    try:
        return json.loads(CONFIG_FILE.read_text())
    except Exception:
        return {}


def save_config(data: dict) -> None:
    """Save config dict to disk."""
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(data, indent=2))


# ---------------------------------------------------------------------------
# Runtime config dataclass
# ---------------------------------------------------------------------------

GEMINI_MODELS = {
    "flash": "gemini-2.5-flash",
    "pro": "gemini-2.5-pro",
}


@dataclass
class Config:
    anthropic_api_key: str = ""
    google_api_key: str = ""
    deepgram_api_key: str = ""
    dd_api_key: str = ""
    dd_app_key: str = ""
    port: int = 7890
    buffer_minutes: int = 10
    context_minutes: int = 5
    timeout_hours: int = 8
    claude_model: str = "claude-sonnet-4-6"
    gemini_model: str = "gemini-2.5-flash"
    max_tokens: int = 4096
    interview_language: str = ""
    challenge_type: str = "general"
    role_context: str = ""               # optional job title / role info
    transcription_language: str = "auto"  # language code or "auto" (Whisper auto-detect)
    context_path: str = ""               # optional repo path for codebase context
    cv_path: str = ""                    # optional CV/resume PDF path
    max_history_turns: int = 10
    preferred_provider: str = "local"    # "claude", "gemini", "local" (ollama)
    preferred_transcriber: str = "whisper"  # "deepgram", "whisper"
    local_model: str = "qwen2.5-coder:3b"  # Ollama model for local provider
    ollama_managed: bool = False            # True if we installed/manage ollama lifecycle
    show_menubar_icon: bool = True
    system_prompt: str = field(default="")

    @property
    def provider(self) -> str:
        """Resolve active provider: preferred > auto-detect from keys."""
        if self.preferred_provider == "local":
            return "local"
        if self.preferred_provider == "claude" and self.anthropic_api_key:
            return "claude"
        if self.preferred_provider == "gemini" and self.google_api_key:
            return "gemini"
        # Auto-detect fallback
        if self.anthropic_api_key:
            return "claude"
        if self.google_api_key:
            return "gemini"
        return "none"

    @property
    def model(self) -> str:
        """Resolve active model name based on current provider."""
        p = self.provider
        if p == "claude":
            return self.claude_model
        if p == "gemini":
            return self.gemini_model
        if p == "local":
            return self.local_model
        return ""

    def __post_init__(self):
        if not self.system_prompt:
            codebase = read_codebase_context(self.context_path) if self.context_path else ""
            cv_text = _read_cv_text(self.cv_path)
            self.system_prompt = _build_system_prompt(
                self.interview_language, self.challenge_type, codebase,
                self.role_context, self.transcription_language, cv_text,
            )

    @classmethod
    def from_saved(cls, overrides: Optional[dict] = None) -> "Config":
        """Build Config from saved file, with optional CLI overrides."""
        saved = load_saved_config()
        merged = {**saved, **(overrides or {})}

        anthropic_key = (merged.get("anthropic_api_key") or os.environ.get("ANTHROPIC_API_KEY", "")).strip()
        google_key = (merged.get("google_api_key") or os.environ.get("GOOGLE_API_KEY", "")).strip()
        deepgram_key = merged.get("deepgram_api_key", "").strip()
        dd_api_key = (merged.get("dd_api_key") or os.environ.get("DD_API_KEY", "")).strip()
        dd_app_key = (merged.get("dd_app_key") or os.environ.get("DD_APP_KEY", "")).strip()
        language = merged.get("interview_language", "")
        challenge = merged.get("challenge_type", "general")
        role_context = merged.get("role_context", "")
        model_alias = merged.get("claude_model", "sonnet")
        claude_model = CLAUDE_MODELS.get(model_alias, model_alias)
        gemini_alias = merged.get("gemini_model", "flash")
        gemini_model = GEMINI_MODELS.get(gemini_alias, gemini_alias)
        transcription_language = merged.get("transcription_language", "auto")
        context_path = merged.get("context_path", "")

        return cls(
            anthropic_api_key=anthropic_key,
            google_api_key=google_key,
            deepgram_api_key=deepgram_key,
            dd_api_key=dd_api_key,
            dd_app_key=dd_app_key,
            port=int(merged.get("port", 7890)),
            buffer_minutes=int(merged.get("buffer_minutes", 10)),
            timeout_hours=int(merged.get("timeout_hours", 8)),
            claude_model=claude_model,
            gemini_model=gemini_model,
            interview_language=language,
            challenge_type=challenge,
            role_context=role_context,
            transcription_language=transcription_language,
            context_path=context_path,
            cv_path=merged.get("_session_cv_path", merged.get("cv_path", "")),
            preferred_provider=merged.get("preferred_provider", "local"),
            preferred_transcriber=merged.get("preferred_transcriber", "whisper"),
            local_model=merged.get("local_model", "qwen2.5-coder:3b"),
            ollama_managed=merged.get("ollama_managed", False),
            show_menubar_icon=merged.get("show_menubar_icon", True),
        )
