"""Settings screen — API keys, provider, transcriber, preferences."""

from __future__ import annotations

import os
import sys
from pathlib import Path

import flet as ft
from ai_interview.i18n import t

from ai_interview.config import save_config

TEAL = "#4ec9b0"
MUTED = "#8b949e"
SZ = 13


def _section(title: str) -> ft.Text:
    return ft.Text(title, size=12, weight=ft.FontWeight.W_600, color=MUTED)


class SettingsScreen(ft.Column):
    """API keys, model, transcriber, and other preferences."""

    def __init__(self, page: ft.Page, saved_config: dict):
        super().__init__(
            expand=True,
            scroll=ft.ScrollMode.AUTO,
            spacing=20,
            horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
        )
        self._page = page
        self._config = saved_config

        # --- API Keys ---
        self._anthropic_key = ft.TextField(
            label=t("anthropic_api_key"), password=True, can_reveal_password=True,
            hint_text="sk-ant-...", value=saved_config.get("anthropic_api_key", ""),
            border_radius=8, text_size=SZ, expand=True, on_blur=lambda _: self._autosave(),
        )
        self._google_key = ft.TextField(
            label=t("google_api_key"), password=True, can_reveal_password=True,
            hint_text=t("hint_google"),
            value=saved_config.get("google_api_key", ""),
            border_radius=8, text_size=SZ, expand=True, on_blur=lambda _: self._autosave(),
        )
        self._deepgram_key = ft.TextField(
            label=t("deepgram_api_key"), password=True, can_reveal_password=True,
            hint_text=t("hint_deepgram"),
            value=saved_config.get("deepgram_api_key", ""),
            border_radius=8, text_size=SZ, expand=True, on_blur=lambda _: self._autosave(),
        )

        api_card = ft.Card(
            content=ft.Container(
                content=ft.Column([
                    _section(t("api_keys")),
                    self._anthropic_key,
                    ft.Row([self._google_key, self._deepgram_key], spacing=12),
                ], spacing=10),
                padding=20,
            ),
        )

        # --- AI Provider ---
        self._provider_dropdown = ft.Dropdown(
            label=t("default_provider"),
            value=saved_config.get("preferred_provider", "local") or "local",
            options=[
                ft.dropdown.Option("local", t("ollama_free")),
                ft.dropdown.Option("claude", "Claude"),
                ft.dropdown.Option("gemini", "Gemini"),
            ],
            border_radius=8, text_size=SZ, expand=True,
            on_select=self._on_provider_change,
        )
        self._claude_model = ft.Dropdown(
            label=t("claude_model"),
            value=saved_config.get("claude_model", "sonnet"),
            options=[ft.dropdown.Option(m) for m in ["sonnet", "opus", "haiku"]],
            border_radius=8, text_size=SZ, expand=True,
        )
        self._gemini_model = ft.Dropdown(
            label=t("gemini_model"),
            value=saved_config.get("gemini_model", "flash"),
            options=[ft.dropdown.Option(m) for m in ["flash", "pro"]],
            border_radius=8, text_size=SZ, expand=True,
        )
        self._all_local_models = [
            "qwen2.5-coder:3b", "qwen2.5-coder:7b", "qwen2.5-coder:14b", "qwen2.5-coder:32b",
            "deepseek-coder-v2:16b", "codellama:7b", "codellama:13b",
        ]
        self._local_model = ft.Dropdown(
            label=t("local_model"),
            value=saved_config.get("local_model", "qwen2.5-coder:3b"),
            options=[ft.dropdown.Option(m) for m in self._all_local_models],
            border_radius=8, text_size=SZ, expand=True,
            on_select=self._on_local_model_change,
        )
        self._download_btn = ft.OutlinedButton(
            t("download"), icon=ft.Icons.DOWNLOAD,
            on_click=self._download_model,
        )
        self._download_status = ft.Text("", size=11, color=MUTED)
        self._installed_models: set[str] = set()
        self._refresh_installed_models()
        self._check_active_downloads()
        self._update_model_visibility()

        self._model_row = ft.Row([self._provider_dropdown, self._claude_model, self._gemini_model, self._local_model, self._download_btn], spacing=12)

        provider_card = ft.Card(
            content=ft.Container(
                content=ft.Column([
                    _section(t("ai_provider")),
                    self._model_row,
                    self._download_status,
                ], spacing=10),
                padding=20,
            ),
        )

        # --- Transcription ---
        self._all_trans_langs = ["en", "es", "pt", "fr", "de", "it", "ja", "ko", "zh", "auto"]
        self._transcriber_dropdown = ft.Dropdown(
            label=t("default_transcriber"),
            value=saved_config.get("preferred_transcriber", "whisper") or "whisper",
            options=[
                ft.dropdown.Option("whisper", t("whisper_free")),
                ft.dropdown.Option("deepgram", "Deepgram"),
            ],
            border_radius=8, text_size=SZ, expand=True,
            on_select=self._on_transcriber_change,
        )
        self._trans_lang_dropdown = ft.Dropdown(
            label=t("transcription_language"),
            value=saved_config.get("transcription_language", "auto"),
            options=[ft.dropdown.Option(lang) for lang in self._all_trans_langs],
            border_radius=8, text_size=SZ, expand=True,
        )
        self._update_trans_lang_options()

        transcription_card = ft.Card(
            content=ft.Container(
                content=ft.Column([
                    _section(t("transcription")),
                    ft.Row([self._transcriber_dropdown, self._trans_lang_dropdown], spacing=12),
                ], spacing=10),
                padding=20,
            ),
        )

        # --- CV / Resume ---
        self._cv_path = ft.TextField(
            label=t("cv_pdf"),
            value=saved_config.get("cv_path", ""),
            hint_text=t("hint_cv"),
            border_radius=8, text_size=SZ, expand=True,
        )
        self._cv_picker = ft.FilePicker()
        page.services.append(self._cv_picker)
        cv_browse = ft.OutlinedButton(t("browse"), icon=ft.Icons.UPLOAD_FILE, on_click=self._browse_cv)
        cv_clear = ft.OutlinedButton(t("clear"), icon=ft.Icons.CLEAR, on_click=self._clear_cv)

        cv_card = ft.Card(
            content=ft.Container(
                content=ft.Column([
                    _section(t("cv_resume")),
                    ft.Row([self._cv_path, cv_browse, cv_clear], spacing=12),
                ], spacing=10),
                padding=20,
            ),
        )

        # --- General ---
        self._theme_dropdown = ft.Dropdown(
            label=t("theme"),
            value=saved_config.get("gui_theme", "system"),
            options=[ft.dropdown.Option(t) for t in ["system", "dark", "light"]],
            border_radius=8, text_size=SZ, expand=True,
            on_select=self._on_theme_change,
        )
        self._port_field = ft.TextField(
            label=t("viewer_port"),
            value=str(saved_config.get("port", 7890)),
            border_radius=8, text_size=SZ, expand=True,
            keyboard_type=ft.KeyboardType.NUMBER,
        )
        self._menubar_check = ft.Checkbox(
            label=t("show_menubar"),
            value=saved_config.get("show_menubar_icon", True),
        )
        self._menubar_icon = ft.Dropdown(
            label=t("menubar_icon"),
            value=saved_config.get("menubar_icon", "●"),
            options=[ft.dropdown.Option(k) for k in ["AI", "◆", "⚡", "●", "▶", "☰"]],
            border_radius=8, text_size=SZ, expand=True,
        )

        self._lang_dropdown = ft.Dropdown(
            label=t("interface_language"),
            value=saved_config.get("gui_language", "en"),
            options=[
                ft.dropdown.Option("en", "English"),
                ft.dropdown.Option("es", "Español"),
                ft.dropdown.Option("pt", "Português"),
            ],
            border_radius=8, text_size=SZ, expand=True,
            on_select=self._on_lang_change,
        )
        self._lang_note = ft.Text("", size=10, color=TEAL, visible=False)

        # Check if LaunchAgent is installed
        self._plist_path = Path.home() / "Library" / "LaunchAgents" / "com.ai-interview-assistant.menubar.plist"
        self._autostart_check = ft.Checkbox(
            label=t("autostart_login"),
            value=self._plist_path.exists(),
        )

        general_card = ft.Card(
            content=ft.Container(
                content=ft.Column([
                    _section(t("general")),
                    ft.Row([self._theme_dropdown, self._lang_dropdown, self._port_field], spacing=12),
                    self._lang_note,
                    ft.Row([self._menubar_check, self._menubar_icon], spacing=12),
                    self._autostart_check,
                ], spacing=10),
                padding=20,
            ),
        )

        self._save_status = ft.Text("", size=11, color=MUTED)

        self.controls = [
            ft.Container(
                content=ft.Column([
                    ft.Text(t("settings"), size=22, weight=ft.FontWeight.W_600),
                    api_card,
                    provider_card,
                    transcription_card,
                    cv_card,
                    general_card,
                    self._save_status,
                ], spacing=14, horizontal_alignment=ft.CrossAxisAlignment.STRETCH),
                padding=30,
            ),
        ]

    def _update_model_visibility(self):
        prov = self._provider_dropdown.value
        self._claude_model.visible = prov == "claude"
        self._gemini_model.visible = prov == "gemini"
        self._local_model.visible = prov == "local"
        self._update_download_btn()

    def _check_active_downloads(self):
        """If an ollama pull is running, show status and start polling."""
        try:
            import subprocess as _sp
            r = _sp.run(["pgrep", "-af", "ollama pull"], capture_output=True, text=True, timeout=3)
            if r.returncode == 0 and r.stdout.strip():
                for line in r.stdout.strip().split("\n"):
                    parts = line.split("ollama pull ")
                    if len(parts) > 1:
                        downloading = parts[1].strip()
                        self._downloading_model = downloading
                        self._download_status.value = f"{downloading} — downloading…"
                        self._download_status.color = TEAL
                        self._download_status.visible = True
                        self._download_btn.visible = False
                        self._download_btn.disabled = True
                        # Start polling in background
                        self._page.run_thread(self._poll_download, downloading)
                        break
            else:
                self._downloading_model = None
        except Exception:
            self._downloading_model = None

    def _poll_download(self, model: str):
        """Poll until model appears in ollama list."""
        import subprocess as _sp
        import time
        for _ in range(360):
            time.sleep(3)
            try:
                r = _sp.run(["ollama", "list"], capture_output=True, text=True, timeout=5)
                if model in r.stdout:
                    self._downloading_model = None
                    self._refresh_installed_models()
                    self._update_download_btn()
                    try:
                        self._page.update()
                    except Exception:
                        pass
                    return
                # Check if pull process still alive
                r2 = _sp.run(["pgrep", "-f", f"ollama pull {model}"], capture_output=True, text=True)
                if r2.returncode != 0:
                    self._downloading_model = None
                    self._download_status.value = f"{model} — download failed"
                    self._download_status.color = "#f14c4c"
                    self._download_btn.disabled = False
                    try:
                        self._page.update()
                    except Exception:
                        pass
                    return
            except Exception:
                pass

    def _refresh_installed_models(self):
        """Check which Ollama models are locally available."""
        from ai_interview.ollama_utils import get_installed_models
        self._installed_models = set(get_installed_models())

    def _is_model_installed(self, model: str) -> bool:
        return model in self._installed_models

    def _update_download_btn(self):
        model = self._local_model.value or ""
        # Don't overwrite if a download is in progress
        if getattr(self, "_downloading_model", None):
            self._download_btn.visible = False
            self._download_status.visible = self._local_model.visible
            return
        installed = self._is_model_installed(model)
        self._download_btn.visible = self._local_model.visible and not installed
        self._download_btn.disabled = False
        if installed:
            self._download_status.value = f"{model} — ready"
            self._download_status.color = TEAL
        else:
            self._download_status.value = f"{model} — not downloaded"
            self._download_status.color = "#d29922"
        self._download_status.visible = self._local_model.visible

    def _on_local_model_change(self, e):
        self._update_download_btn()
        self._autosave()
        self._page.update()

    def _download_model(self, e):
        model = self._local_model.value or "qwen2.5-coder:3b"
        self._download_btn.disabled = True
        self._download_status.value = f"Downloading {model}…"
        self._download_status.color = TEAL
        self._page.update()

        def _do_download():
            import shutil
            import subprocess as _sp
            import time

            try:
                from ai_interview.ollama_utils import is_ollama_installed, start_ollama
                if not is_ollama_installed():
                    self._download_status.value = "Ollama not installed. Run: ai-interview version"
                    self._download_status.color = "#f14c4c"
                    self._download_btn.disabled = False
                    try:
                        self._page.update()
                    except Exception:
                        pass
                    return

                start_ollama()

                # Launch pull as detached process (survives GUI close)
                _sp.Popen(["ollama", "pull", model], start_new_session=True,
                           stdout=_sp.DEVNULL, stderr=_sp.DEVNULL)

                self._downloading_model = model
                self._download_status.value = f"{model} — downloading…"
                self._download_btn.visible = False
                try:
                    self._page.update()
                except Exception:
                    pass

                # Poll until done
                self._poll_download(model)

            except Exception as exc:
                self._download_status.value = f"Error: {exc}"
                self._download_status.color = "#f14c4c"
                self._download_btn.disabled = False
                try:
                    self._page.update()
                except Exception:
                    pass

        self._page.run_thread(_do_download)

    def _update_trans_lang_options(self):
        """Hide 'auto' language when Deepgram is selected (requires explicit language)."""
        is_deepgram = self._transcriber_dropdown.value == "deepgram"
        langs = [l for l in self._all_trans_langs if l != "auto"] if is_deepgram else self._all_trans_langs
        self._trans_lang_dropdown.options = [ft.dropdown.Option(l) for l in langs]
        if is_deepgram and self._trans_lang_dropdown.value == "auto":
            self._trans_lang_dropdown.value = "en"

    def _on_transcriber_change(self, e):
        self._update_trans_lang_options()
        self._autosave()
        self._page.update()

    def _on_provider_change(self, e):
        self._update_model_visibility()
        self._autosave()
        self._page.update()

    def _update_autostart(self):
        import subprocess as _sp
        import shutil

        if self._autostart_check.value:
            # Install LaunchAgent
            cli = shutil.which("ai-interview") or str(Path(sys.executable).parent / "ai-interview")
            plist_content = f"""\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.ai-interview-assistant.menubar</string>
    <key>ProgramArguments</key>
    <array>
        <string>{cli}</string>
        <string>menubar</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <false/>
</dict>
</plist>"""
            self._plist_path.parent.mkdir(parents=True, exist_ok=True)
            self._plist_path.write_text(plist_content)
            _sp.run(["launchctl", "load", str(self._plist_path)], capture_output=True)
        else:
            # Remove LaunchAgent
            if self._plist_path.exists():
                _sp.run(["launchctl", "unload", str(self._plist_path)], capture_output=True)
                self._plist_path.unlink(missing_ok=True)

    async def _browse_cv(self, e):
        result = await self._cv_picker.pick_files(
            dialog_title=t("cv_pdf"),
            allowed_extensions=["pdf"],
            allow_multiple=False,
        )
        if result:
            files = result if isinstance(result, list) else getattr(result, "files", result)
            if files and len(files) > 0:
                self._cv_path.value = files[0].path
                self._autosave()
                self._page.update()

    def update_session_state(self, running: bool):
        """No-op — settings doesn't need session state."""
        pass

    def _clear_cv(self, e):
        self._cv_path.value = ""
        self._autosave()
        self._page.update()

    def _on_lang_change(self, e):
        from ai_interview.i18n import set_language
        set_language(e.control.value or "en")
        self._autosave()
        # Restart menubar to pick up new language
        self._restart_menubar()
        # Rebuild entire GUI with new language
        self._page.controls.clear()
        from ai_interview.flet_gui.app import build_page
        build_page(self._page, self._config)

    def _restart_menubar(self):
        import subprocess as _sp
        import signal as _sig
        menubar_pid_file = Path.home() / ".ai-interview-menubar.pid"
        if menubar_pid_file.exists():
            try:
                pid = int(menubar_pid_file.read_text().strip())
                os.kill(pid, _sig.SIGTERM)
            except Exception:
                pass
            menubar_pid_file.unlink(missing_ok=True)
            import time; time.sleep(0.3)
        if self._config.get("show_menubar_icon", True):
            _sp.Popen(
                [sys.executable, "-m", "ai_interview.menubar"],
                start_new_session=True,
                stdout=_sp.DEVNULL, stderr=_sp.DEVNULL, stdin=_sp.DEVNULL,
            )

    def _on_theme_change(self, e):
        theme_map = {"dark": ft.ThemeMode.DARK, "light": ft.ThemeMode.LIGHT, "system": ft.ThemeMode.SYSTEM}
        self._page.theme_mode = theme_map.get(e.control.value, ft.ThemeMode.SYSTEM)
        self._autosave()
        self._page.update()

    def _autosave(self):
        """Save all settings to config immediately."""
        self._config["anthropic_api_key"] = (self._anthropic_key.value or "").strip()
        self._config["google_api_key"] = (self._google_key.value or "").strip()
        self._config["deepgram_api_key"] = (self._deepgram_key.value or "").strip()
        self._config["gui_theme"] = self._theme_dropdown.value or "system"
        prov = self._provider_dropdown.value
        self._config["preferred_provider"] = "" if prov == "auto" else prov
        self._config["claude_model"] = self._claude_model.value or "sonnet"
        self._config["gemini_model"] = self._gemini_model.value or "flash"
        self._config["local_model"] = self._local_model.value or "qwen2.5-coder:3b"
        trans = self._transcriber_dropdown.value
        self._config["preferred_transcriber"] = "" if trans == "auto" else trans
        self._config["transcription_language"] = self._trans_lang_dropdown.value or "auto"
        self._config["port"] = int(self._port_field.value or 7890)
        self._config["cv_path"] = (self._cv_path.value or "").strip()
        self._config["gui_language"] = self._lang_dropdown.value or "en"
        self._config["show_menubar_icon"] = self._menubar_check.value
        self._config["menubar_icon"] = self._menubar_icon.value or "●"
        save_config(self._config)
        self._save_status.value = t("saved")
        try:
            self._page.update()
        except Exception:
            pass

    def _save(self, e):
        self._autosave()

        # Restart or stop menu bar icon immediately (restart picks up new icon)
        import subprocess as _sp
        import signal as _sig
        menubar_pid_file = Path.home() / ".ai-interview-menubar.pid"

        # Kill existing if running
        if menubar_pid_file.exists():
            try:
                pid = int(menubar_pid_file.read_text().strip())
                os.kill(pid, _sig.SIGTERM)
            except Exception:
                pass
            menubar_pid_file.unlink(missing_ok=True)
            import time; time.sleep(0.3)

        # Restart if enabled
        if self._menubar_check.value:
            _sp.Popen(
                [sys.executable, "-m", "ai_interview.menubar"],
                start_new_session=True,
                stdout=_sp.DEVNULL, stderr=_sp.DEVNULL, stdin=_sp.DEVNULL,
            )

        # Install or remove LaunchAgent for auto-start on login
        # Force off if menubar is disabled
        if not self._menubar_check.value:
            self._autostart_check.value = False
        self._update_autostart()

        self._save_status.value = "Settings saved!"
        self._save_status.color = TEAL
        self._page.update()
