/**
 * Svelte stores for canvas state: nodes, edges, run state, selection.
 */
import { writable, derived, get } from 'svelte/store';
import type { Node, Edge } from '@xyflow/svelte';
import type { CanvasNodeData, WorkflowRunState, ModuleDef, RunStatus, SampleInfo } from './types.js';

// ---------- Core graph stores ----------
export const nodes = writable<Node<CanvasNodeData>[]>([]);
export const edges = writable<Edge[]>([]);

// ---------- Selection ----------
export const selectedNodeId = writable<string | null>(null);
export const selectedNode = derived(
  [nodes, selectedNodeId],
  ([$nodes, $id]) => $id ? $nodes.find(n => n.id === $id) ?? null : null
);

// ---------- Module registry ----------
export const modules = writable<ModuleDef[]>([]);

// ---------- Registered samples ----------
// Loaded once at app start; refreshed on demand. CustomNode reads this to
// show file_type per sample on Input Selector nodes.
export const samples = writable<SampleInfo[]>([]);

export async function loadSamples(): Promise<void> {
  try {
    const resp = await fetch('/api/pm/samples');
    if (resp.ok) samples.set(await resp.json());
  } catch { /* noop */ }
}

// ---------- Run state ----------
export const runState = writable<WorkflowRunState>({
  jobId: null,
  running: false,
  nodeStates: {},
});

// ---------- Pipeline name ----------
export const pipelineName = writable<string>('My Pipeline');

// ---------- Helpers ----------
let nodeCounter = 0;
export function nextNodeId(): string {
  nodeCounter += 1;
  return `node_${nodeCounter}`;
}

export function resetNodeCounter(max: number = 0): void {
  nodeCounter = max;
}

export function updateNodeData(nodeId: string, partial: Partial<CanvasNodeData>): void {
  nodes.update($nodes => {
    const node = $nodes.find(n => n.id === nodeId);
    if (node) {
      // Mutate data in place — spreading the node object creates a new
      // reference that makes SvelteFlow lose its internally tracked
      // drag position, causing the node to jump.
      Object.assign(node.data, partial);
    }
    return [...$nodes];
  });
}

export function setNodeRunStatus(
  nodeId: string,
  status: RunStatus,
  error?: string,
  tally?: import('./types.js').RunTally,
  runIds?: string[],
): void {
  updateNodeData(nodeId, { runStatus: status, runTally: tally });
  runState.update(rs => ({
    ...rs,
    nodeStates: {
      ...rs.nodeStates,
      [nodeId]: { status, error, tally, runIds },
    },
  }));
}

export function deleteNodes(nodeIds: string[]): void {
  const ids = new Set(nodeIds);
  nodes.update(ns => ns.filter(n => !ids.has(n.id)));
  edges.update(es => es.filter(e => !ids.has(e.source) && !ids.has(e.target)));
  selectedNodeId.update(id => id && ids.has(id) ? null : id);
}

export function clearRunState(): void {
  runState.set({ jobId: null, running: false, nodeStates: {} });
  nodes.update($nodes => {
    for (const n of $nodes) {
      n.data.runStatus = 'idle';
      n.data.runTally = undefined;
    }
    return [...$nodes];
  });
}

// ---------- Param editing state (ValueList / Lock All / Run validation) ----------
// Bumping this counter asks every mounted ValueList to commit its dirty rows.
export const commitAllSignal = writable(0);
export function requestCommitAll(): void {
  commitAllSignal.update(n => n + 1);
}

// Keys of the form `${nodeId}::${paramName}` that currently have at least
// one row in edit-mode. Used by Lock All visibility and Run validation.
export const dirtyParams = writable<Set<string>>(new Set());
export function markDirty(key: string, dirty: boolean): void {
  dirtyParams.update(s => {
    const next = new Set(s);
    if (dirty) next.add(key); else next.delete(key);
    return next;
  });
}
