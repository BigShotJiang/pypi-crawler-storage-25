<script lang="ts">
  import { get } from 'svelte/store';
  import { nodes, requestCommitAll } from './stores.js';
  import { loadPipeline, runPipeline } from './pipeline.js';
  import type { PipelineJSON } from './types.js';

  let { fitView }: { fitView: (() => Promise<boolean>) | null } = $props();

  type ModuleForm = 'decorated' | 'ctx' | 'mixed' | 'raw';
  type Topology =
    | 'fan_in'
    | 'keep_going'
    | 'node_sweep'
    | 'sample_override'
    | 'sample_sweep'
    | 'combined_sweep'
    | 'dedup_check'
    | 'sweep_with_failure'
    | 'streaming'
    | 'cancelled_stream';

  let resetLabel = $state('Reset DB');
  let refreshLabel = $state('Refresh');
  let moduleForm = $state<ModuleForm>('decorated');
  let topology = $state<Topology>('fan_in');

  async function fetchDemoPipeline(): Promise<PipelineJSON> {
    const resp = await fetch(
      `/api/dev/demo-pipeline?module=${moduleForm}&topology=${topology}`
    );
    if (!resp.ok) throw new Error('Failed to fetch demo pipeline');
    return resp.json();
  }

  async function handleLoadDemo() {
    try {
      const pipeline = await fetchDemoPipeline();
      loadPipeline(pipeline);
      if (fitView) await fitView();
    } catch (err) {
      alert('Load demo failed: ' + err);
    }
  }

  async function handleRunDemo() {
    try {
      // Load demo pipeline if canvas is empty
      if (get(nodes).length === 0) {
        const pipeline = await fetchDemoPipeline();
        loadPipeline(pipeline);
        if (fitView) await fitView();
        // Small delay so SvelteFlow registers the nodes before run reads them
        await new Promise(r => setTimeout(r, 100));
      }
      // Dev shortcut: force-commit every dirty row before running so the
      // tester doesn't have to click Lock on each node. Microtask waits for
      // the signal-driven commits to flush to graph state.
      requestCommitAll();
      await new Promise(r => setTimeout(r, 0));
      await runPipeline();
    } catch (err) {
      alert('Run demo failed: ' + err);
    }
  }

  async function handleResetDb() {
    try {
      await fetch('/api/dev/reset-db', { method: 'POST' });
      await fetch('/api/pm/refresh', { method: 'POST' });
      resetLabel = 'Done!';
      setTimeout(() => { resetLabel = 'Reset DB'; }, 1000);
    } catch (err) {
      alert('Reset failed: ' + err);
    }
  }

  async function handleRefresh() {
    try {
      await fetch('/api/pm/refresh', { method: 'POST' });
      refreshLabel = 'Done!';
      setTimeout(() => { refreshLabel = 'Refresh'; }, 1000);
    } catch (err) {
      alert('Refresh failed: ' + err);
    }
  }

  const MODULE_OPTIONS: { value: ModuleForm; label: string; hint: string }[] = [
    { value: 'decorated', label: 'Decorated', hint: '@pm_method fixtures' },
    { value: 'ctx',       label: 'RunContext', hint: 'RunContext-driven fixtures' },
    { value: 'mixed',     label: 'Mixed',     hint: 'Alternates decorated/ctx across the chain' },
    { value: 'raw',       label: 'Raw',       hint: 'Original bare-script fixtures' },
  ];

  const TOPOLOGY_OPTIONS: { value: Topology; label: string; hint: string }[] = [
    {
      value: 'fan_in',
      label: 'Fan-in chain',
      hint: 'input_selector(fan_mode=in, 4 samples) → merge → filter → scale → transform → qc',
    },
    {
      value: 'keep_going',
      label: 'Keep-going (1/4 fail)',
      hint: 'input_selector(fan_mode=out, 4 samples) → faulty; ctrl_01 overridden to crash. Toggle the toolbar keep-going checkbox to see mixed state instead of pipeline failure.',
    },
    {
      value: 'node_sweep',
      label: 'Node sweep (3× threshold)',
      hint: 'Fan-out, filter.threshold swept over {5, 10, 15}. Expect 12 runs (4 samples × 3 variants).',
    },
    {
      value: 'sample_override',
      label: 'Sample override',
      hint: 'Fan-out, ctrl_01 overrides threshold=1 (others use 10). Expect 4 runs (3 default + 1 override).',
    },
    {
      value: 'sample_sweep',
      label: 'Sample sweep (3× on ctrl_01)',
      hint: 'Fan-out, ctrl_01 sweeps threshold {1,2,5}; others use baseline 10. Expect 6 runs (3 default + 3 ctrl_01).',
    },
    {
      value: 'combined_sweep',
      label: 'Combined (node+sample)',
      hint: 'Fan-out, global sweep {5,10} AND ctrl_01 adds {1,20}. Expect 10 runs (4×2 + 2 ctrl_01 extras).',
    },
    {
      value: 'dedup_check',
      label: 'Dedup check',
      hint: 'Fan-out, global sweep {5,10} ships as-if ctrl_01 override=5 was deduped against v1. Expect 8 runs.',
    },
    {
      value: 'sweep_with_failure',
      label: 'Sweep + 1 failing sample',
      hint: 'Fan-out, filter sweeps {5,10} → faulty; ctrl_01 overrides failure_mode=crash. Enable keep-going; expect 6/8 faulty runs succeed.',
    },
    {
      value: 'streaming',
      label: 'Streaming (heartbeat)',
      hint: 'Single sample → heartbeat. 15 timed stdout ticks over ~5s for SSE log-stream dogfood. Click Run, open Output tab on the heartbeat node to see lines arrive.',
    },
    {
      value: 'cancelled_stream',
      label: 'Cancelled heartbeat (upstream crash)',
      hint: 'Single sample → faulty(crash) → heartbeat. Faulty fails; heartbeat never runs. Open heartbeat Output tab to see the "Cancelled because faulty failed" banner.',
    },
  ];
</script>

<div class="dev-toolbar">
  <span class="dev-label">DEV</span>

  <span class="seg-label">Fixtures:</span>
  <div class="seg" role="group" aria-label="Demo fixture module">
    {#each MODULE_OPTIONS as opt}
      <button
        type="button"
        class="seg-btn"
        class:active={moduleForm === opt.value}
        title={opt.hint}
        onclick={() => { moduleForm = opt.value; }}
      >
        {opt.label}
      </button>
    {/each}
  </div>

  <span class="seg-label">Topology:</span>
  <select
    class="topology-select"
    aria-label="Demo topology"
    title={TOPOLOGY_OPTIONS.find(o => o.value === topology)?.hint ?? ''}
    value={topology}
    onchange={(e) => { topology = (e.currentTarget as HTMLSelectElement).value as Topology; }}
  >
    {#each TOPOLOGY_OPTIONS as opt}
      <option value={opt.value} title={opt.hint}>{opt.label}</option>
    {/each}
  </select>

  <button class="dev-btn" onclick={handleLoadDemo}>Load Demo</button>
  <button class="dev-btn dev-btn-run" onclick={handleRunDemo}>Run Demo</button>
  <button class="dev-btn" onclick={() => requestCommitAll()} title="Commit every dirty row across all nodes">Lock All</button>
  <button class="dev-btn" onclick={handleResetDb}>{resetLabel}</button>
  <button class="dev-btn" onclick={handleRefresh}>{refreshLabel}</button>
</div>

<style>
  .dev-toolbar {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 10;
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 6px 12px;
    background: #2d2d30;
    border-top: 1px solid #3e3e42;
  }
  .dev-label {
    font-size: 10px;
    font-weight: 700;
    color: #E9A847;
    letter-spacing: 1px;
    padding: 2px 6px;
    background: rgba(233, 168, 71, 0.15);
    border-radius: 3px;
  }
  .seg-label {
    font-size: 10px;
    color: #999;
    letter-spacing: 0.5px;
    text-transform: uppercase;
  }
  .seg {
    display: inline-flex;
    border: 1px solid #3e3e42;
    border-radius: 3px;
    overflow: hidden;
  }
  .topology-select {
    background: #1e1e1e;
    border: 1px solid #3e3e42;
    color: #ccc;
    font-size: 11px;
    padding: 3px 22px 3px 8px;
    border-radius: 3px;
    outline: none;
    cursor: pointer;
    font-family: inherit;
    appearance: none;
    -webkit-appearance: none;
    background-image:
      linear-gradient(45deg, transparent 50%, #888 50%),
      linear-gradient(135deg, #888 50%, transparent 50%);
    background-position: calc(100% - 12px) 50%, calc(100% - 7px) 50%;
    background-size: 5px 5px;
    background-repeat: no-repeat;
    min-width: 200px;
  }
  .topology-select:hover { border-color: #555; }
  .seg-btn {
    padding: 3px 8px;
    background: #2d2d30;
    border: none;
    border-right: 1px solid #3e3e42;
    font-size: 11px;
    color: #ccc;
    cursor: pointer;
  }
  .seg-btn:last-child { border-right: none; }
  .seg-btn:hover { background: #3e3e42; }
  .seg-btn.active {
    background: #1e7a3e;
    color: white;
  }
  .dev-btn {
    padding: 3px 8px;
    background: #3e3e42;
    border: none;
    border-radius: 3px;
    font-size: 11px;
    color: #ccc;
    cursor: pointer;
  }
  .dev-btn:hover {
    background: #505054;
  }
  .dev-btn-run {
    background: #1e7a3e;
    color: white;
  }
  .dev-btn-run:hover {
    background: #259a4e;
  }
</style>
