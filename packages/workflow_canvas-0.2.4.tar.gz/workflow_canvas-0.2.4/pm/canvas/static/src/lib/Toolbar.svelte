<script lang="ts">
  import { nodes, edges, runState, pipelineName, clearRunState,
           dirtyParams, requestCommitAll } from './stores.js';
  import { pushState } from './history.js';
  import { undo, redo } from './history.js';
  import { exportPipeline, loadPipeline, runPipeline, stopPolling } from './pipeline.js';
  import type { PipelineJSON, CanvasNodeData } from './types.js';
  import { get } from 'svelte/store';

  export let activeTab: 'builder' | 'registry' | 'history' = 'builder';
  export let onTabChange: ((tab: 'builder' | 'registry' | 'history') => void) | undefined = undefined;

  function doExport() {
    const pipeline = exportPipeline();
    const blob = new Blob([JSON.stringify(pipeline, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${pipeline.name || 'pipeline'}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function doImport() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;
      const text = await file.text();
      const pipeline: PipelineJSON = JSON.parse(text);
      pushState();
      loadPipeline(pipeline);
    };
    input.click();
  }

  async function doValidate() {
    const pipeline = exportPipeline();
    try {
      const resp = await fetch('/api/workflow/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(pipeline),
      });
      const result = await resp.json();
      if (result.valid) {
        alert('Workflow is valid!');
      } else {
        alert('Validation errors:\n' + (result.errors ?? []).join('\n'));
      }
    } catch (err) {
      alert('Validation failed: ' + err);
    }
  }

  function doClear() {
    pushState();
    nodes.set([]);
    edges.set([]);
    clearRunState();
  }

  /**
   * Pre-Run validation. Returns an error string to block the run, or
   * null if OK. Dirty rows trigger a confirm-and-lock dialog rather
   * than an outright block.
   */
  function collectRequiredErrors(): string[] {
    const errors: string[] = [];
    for (const n of get(nodes)) {
      const d = n.data as CanvasNodeData;
      if (!d?.params || d.nodeType !== 'method') continue;
      const label = d.label || n.id;
      for (const p of d.params) {
        if (!p.required) continue;
        const base = d.paramValues?.[p.name];
        const hasBase = base !== undefined && base !== null && base !== '';
        const hasDefault = p.default !== undefined && p.default !== null && p.default !== '';
        const variants = d.variants?.[p.name] ?? {};
        const hasVariant = Object.keys(variants).length > 0;
        if (!hasBase && !hasDefault && !hasVariant) {
          errors.push(`${label}.${p.name} is required`);
        }
      }
    }
    return errors;
  }

  function doRun() {
    const dirty = get(dirtyParams);
    if (dirty.size > 0) {
      const msg = `${dirty.size} param row${dirty.size === 1 ? '' : 's'} still in edit mode. ` +
                  `OK to lock them and run; Cancel to return to the canvas.`;
      if (!window.confirm(msg)) return;
      requestCommitAll();
      // After commit, any rows that failed validation remain dirty.
      const stillDirty = get(dirtyParams);
      if (stillDirty.size > 0) {
        alert('Some rows have validation errors and could not be committed. Fix them before running.');
        return;
      }
    }
    const required = collectRequiredErrors();
    if (required.length > 0) {
      alert('Cannot run — required params missing:\n' + required.join('\n'));
      return;
    }
    runPipeline();
  }
</script>

<div class="toolbar">
  <span class="title">Workflow Canvas</span>
  <div class="tabs">
    <button class="tab" class:active={activeTab === 'builder'} onclick={() => onTabChange?.('builder')}>Builder</button>
    <button class="tab" class:active={activeTab === 'registry'} onclick={() => onTabChange?.('registry')}>Registry</button>
    <button class="tab" class:active={activeTab === 'history'} onclick={() => onTabChange?.('history')}>History</button>
  </div>
  <div class="spacer"></div>
  <input class="pipeline-name" type="text" value={$pipelineName}
    oninput={(e: Event) => pipelineName.set((e.target as HTMLInputElement).value)} />
  <div class="actions">
    <button class="btn" onclick={doImport}>Import</button>
    <button class="btn" onclick={doValidate}>Validate</button>
    <button class="btn" onclick={doExport}>Export</button>
    {#if $runState.running}
      <button class="btn btn-stop" onclick={() => { stopPolling(); runState.update(rs => ({ ...rs, running: false })); }}>Stop</button>
    {:else}
      <button class="btn btn-run" onclick={doRun}>&#9654; Run</button>
    {/if}
    <button class="btn btn-muted" onclick={doClear}>Clear</button>
    <button class="btn btn-muted" onclick={undo} title="Undo (Ctrl+Z)">&#8630;</button>
    <button class="btn btn-muted" onclick={redo} title="Redo (Ctrl+Y)">&#8631;</button>
  </div>
</div>

<!-- Status bar -->
{#if $runState.running}
  <div class="status-bar">
    <span>&#9654; Running... {#if $runState.currentStep}step {$runState.completedSteps ?? 0}/{$runState.totalSteps ?? '?'} — {$runState.currentStep}{/if}</span>
    <span>Nodes: {$nodes.length}</span>
  </div>
{/if}

<style>
  .toolbar {
    display: flex;
    align-items: center;
    padding: 10px 14px;
    background: #252526;
    border-bottom: 1px solid #3e3e42;
    gap: 14px;
    flex-shrink: 0;
  }
  .title { color: #ccc; font-size: 22px; font-weight: 600; white-space: nowrap; }
  .tabs {
    display: flex;
    gap: 2px;
    background: #1e1e1e;
    padding: 4px;
    border-radius: 6px;
  }
  .tab {
    padding: 6px 16px;
    color: #888;
    font-size: 13px;
    background: none;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  .tab.active { background: #4A90D9; color: white; }
  .spacer { flex: 1; }
  .pipeline-name {
    background: #2d2d30;
    padding: 6px 12px;
    border-radius: 4px;
    border: 1px solid #3e3e42;
    color: #ccc;
    font-size: 13px;
    /* 140px was too short for most pipeline names; 320 + min gives
       enough room without pushing the action buttons off-screen on
       narrow viewports. */
    width: 320px;
    min-width: 180px;
    outline: none;
  }
  .actions { display: flex; gap: 8px; align-items: center; }
  .btn {
    padding: 6px 10px;
    background: #2d2d30;
    border-radius: 4px;
    font-size: 13px;
    color: #ccc;
    border: none;
    cursor: pointer;
  }
  .btn:hover { background: #3e3e42; }
  .btn-run { background: #50C878; color: white; font-weight: 600; padding: 6px 12px; }
  .btn-stop { background: #E74C3C; color: white; font-weight: 600; }
  .btn-muted { color: #888; }
  .status-bar {
    padding: 5px 14px;
    background: #1e7a3e;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-shrink: 0;
    color: white;
    font-size: 12px;
  }
</style>
