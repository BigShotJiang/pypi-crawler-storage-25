"""Process Manager MVP — track pipeline runs with full lineage."""

# NOTE: Only pm.method is imported here.
#
# snakemake_gen, cli, and init all depend on dflow (or pull in modules that
# do), which is only installed in the outer dev environment — NOT in the
# isolated pixi envs used by train_classifier / plot_decision_boundary.
#
# Method scripts do:
#   from pm.method import pm_method, pm_method_main
# That import resolves to this __init__ first. Keeping it dflow-free means
# the pixi-isolated methods can import pm without blowing up.
#
# Callers that need the orchestration layer should import directly:
#   from pm.snakemake_gen import load_pipeline, generate_snakefile
#   from pm.cli import register_sample, run_pipeline
#   from pm.init import init_project

from .method import pm_method, pm_method_main, ContractViolation

__all__ = [
    "pm_method",
    "pm_method_main",
    "ContractViolation",
]
