# CLI Reference

## Overview

All commands are invoked via `pm <command>` (or `python -m pm <command>`). The CLI is the primary developer interface to the core pipeline, covering project setup, registration, execution, caching, and lineage.

## Project Commands

### pm init

Scaffold a new project directory structure (`.pm/`, `modules/`, `methods/`, `.runs/`, `data/samples/`). Auto-initializes DVC when a `[dvc]` section is present in `wf-canvas.toml`.

| Arg | Description |
|---|---|
| `--dir` | Target directory (default: current directory) |
| `--git` | Initialize a git repository |

### pm canvas

Launch the Canvas web UI -- a browser-based visual pipeline builder and run history viewer.

| Arg | Description |
|---|---|
| `--host` | Bind address (default: `0.0.0.0`) |
| `--port` | Port number (default: `8500`) |
| `--reload` | Enable auto-reload for development |
| `--project-root` | Override the project root for auto-load |

## Registration Commands

### pm register-module

Create a module with input/output contracts. Contracts can be provided via `module.yaml` in the module directory or directly via CLI.

| Arg | Description |
|---|---|
| `--name` | Module name |
| `--module-dir` | Path to the module directory |
| `--contracts` | JSON contracts (optional if `module.yaml` exists) |
| `--description` | Module description |

### pm register-method

Register a method: performs AST scan of the method script, reads `method.yaml`, validates against module contracts, and creates a git commit.

| Arg | Description |
|---|---|
| `method_dir` | Path to the method directory (positional) |
| `--module` | Parent module name |
| `--name` | Method name |
| `--script` | Script filename to scan |

### pm register-sample

Import a data file into the project. Content-hashes the file via DVC and records the hash in the database. Requires a `[dvc]` section in `wf-canvas.toml`.

| Arg | Description |
|---|---|
| `--name` | Sample name |
| `--source` | Path to the source data file |

### pm restore-sample

Restore a registered sample from the DVC cache to `data/samples/{name}/`. Verifies integrity automatically (skips if hash matches, replaces if mismatched).

| Arg | Description |
|---|---|
| `--name` | Sample name |
| `--hash` | Content hash to restore |

## Pipeline Commands

### pm run-pipeline

Generate a Snakefile from a pipeline JSON and execute it via Snakemake. After the pipeline completes, outputs are auto-archived unless `--no-archive` is passed.

| Arg | Description |
|---|---|
| `--pipeline` | Path to the pipeline JSON file |
| `--cores` | Number of Snakemake cores (default: 4) |
| `--project-root` | Project root directory |
| `--pm-root` | Directory added to PYTHONPATH for workers so they can `import pm`. Defaults to pm's installed location. |
| `--snakefile` | Where to write the generated Snakefile (default: `<project-root>/Snakefile`) |
| `--archive` / `--no-archive` | Enable or disable auto-archiving of outputs after completion |

**Running from CLI vs Canvas:** From the command line, use `pm run-pipeline --pipeline path/to/pipeline.json`. From Canvas, click the Run button in the Builder toolbar -- this calls the same underlying pipeline execution through the web API (`POST /api/workflow/run`).

## Cache Commands

### pm cache archive

Hash and cache all un-archived run outputs (those with `content_hash = NULL`) into the DVC cache. Shows per-file progress. Use this after running a pipeline with `--no-archive`, or to archive a specific run.

| Arg | Description |
|---|---|
| `--run-id` | Optional: limit archiving to a specific run |

### pm cache prune

Remove old run archives and optionally DVC local cache entries to reclaim disk space. Before pruning, verifies the DVC remote is reachable (skipped with `--force`). Runs with un-archived outputs are skipped with a warning.

| Arg | Description |
|---|---|
| `--all` | Remove all archives regardless of reference status |
| `--include-local` | Also prune `.dvc/cache/` unreferenced hashes |
| `--dry-run` | Print what would be deleted without deleting |
| `--force` | Skip the confirmation prompt and remote reachability check |
